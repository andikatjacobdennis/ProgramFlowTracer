﻿using System;
using System.Collections.Generic;
using System.Linq;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Baseline;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Component;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Component.Tea2;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Component.Tea2Plus;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Conditions;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Node;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.NonDownloadableTemplate;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Notifications;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.OrganizeHardware;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Parts;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ProductDefinition;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.RepositoryInterfaces;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Slot;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Sources;
using Volvo.SoftwareBreakdown.UtilityComponent.Linq;
using DependencyContainer = Volvo.SoftwareBreakdown.BreakdownDomain.Model.Dependencies.DependencyContainer;

namespace Volvo.SoftwareBreakdown.BreakdownDomain.Model.NodeTemplate
{

    public class NodeTemplateIssue : BaseConditionalEntity<string>
    {
        public NodeTemplateIssue(string guid, int id, int documentNumber, int issueNumber, string name,
            string releaseNotes, TemplateType templateType, Context context, string dependencyContainerId, bool performsCanIdTransformation, IList<ParentNode> parentNodes,
            IList<BaseCondition> conditions, IEnumerable<ParameterGroup> parameterGroups, IList<IComponent> components,
            bool allowForUpdatePreReleased, bool allowForUpdateReleased, string preferredHardwareVersionGuid,
            DateTime? amWithdrawalDate, DateTime? prdWithdrawalDate,
            NodeTemplateStatus statusCode = NodeTemplateStatus.ReleasedPrd, DateTime? introductionDate = null,
            DateTime? rejectionDate = null, IList<NodePosition> nodePositions = null, DependencyContainer nodeDependencyContainer = null)
            : this(guid, id, documentNumber, issueNumber, name, releaseNotes, templateType, context, dependencyContainerId, performsCanIdTransformation, parentNodes, conditions, parameterGroups, components, allowForUpdatePreReleased, allowForUpdateReleased, new List<NodeTemplateIssue>(), preferredHardwareVersionGuid, amWithdrawalDate, prdWithdrawalDate, statusCode: statusCode, introductionDate: introductionDate, rejectionDate: rejectionDate, nodePositions: nodePositions, nodeDependencyContainer)
        {
        }


        protected NodeTemplateIssue(string guid, int id, int documentNumber, int issueNumber, string name,
            string releaseNotes, TemplateType templateType, Context context, string dependencyContainerId, bool performsCanIdTransformation, IList<ParentNode> parentNodes,
            IList<BaseCondition> conditions, IEnumerable<ParameterGroup> parameterGroups, IList<IComponent> components,
            bool allowForUpdatePreReleased, bool allowForUpdateReleased,
            IEnumerable<NodeTemplateIssue> subNodeTemplateIssue, string preferredHardwareVersionGuid,
            DateTime? amWithdrawalDate, DateTime? prdWithdrawalDate,
            NodeTemplateStatus statusCode = NodeTemplateStatus.ReleasedPrd, DateTime? introductionDate = null,
            DateTime? rejectionDate = null, IList<NodePosition> nodePositions = null,
            DependencyContainer nodeDependencyContainer = null)
            : base(guid, conditions)
        {
            InternalId = id;
            DocumentNumber = documentNumber;
            IssueNumber = issueNumber;
            Name = name;
            ReleaseNotes = releaseNotes;
            TemplateType = templateType;
            DependencyContainerId = dependencyContainerId;
            NodeDependencyContainer = nodeDependencyContainer;
            ParentNodes = parentNodes;
            _parameterGroups = parameterGroups;
            PerformsCanIdTransformation = CalculatePerformsCanIdTransformation(performsCanIdTransformation, context, templateType);
            StatusCode = statusCode;
            IntroductionDate = introductionDate;
            RejectionDate = rejectionDate;
            _components = components;
            AllowForUpdatePreReleased = allowForUpdatePreReleased;
            AllowForUpdateReleased = allowForUpdateReleased;
            Context = context;
            SubNodeTemplateIssues = subNodeTemplateIssue ?? new List<NodeTemplateIssue>();
            AmWithdrawalDate = amWithdrawalDate;
            PrdWithdrawalDate = prdWithdrawalDate;
            PreferredHardwareVersionGuid = preferredHardwareVersionGuid;
            NodePositions = nodePositions;
        }

        protected NodeTemplateIssue() : base("", null)
        {
        }

        public int InternalId { get; private set; }

        public NodeTemplateIssue CloneWithSubTemplates(IEnumerable<NodeTemplateIssue> subNodeTemplateIssues, bool keepExisting)
        {
            var allSubNodeTemplateIssues = subNodeTemplateIssues.Concat(keepExisting ? SubNodeTemplateIssues : new List<NodeTemplateIssue>());
            return new NodeTemplateIssue(Id, InternalId, DocumentNumber,
                IssueNumber, Name, ReleaseNotes, TemplateType, Context, DependencyContainerId, PerformsCanIdTransformation, ParentNodes, Conditions, _parameterGroups, _components, AllowForUpdatePreReleased, AllowForUpdateReleased, allSubNodeTemplateIssues, PreferredHardwareVersionGuid, AmWithdrawalDate, PrdWithdrawalDate, statusCode: StatusCode, introductionDate: IntroductionDate, rejectionDate: RejectionDate, nodePositions: NodePositions, nodeDependencyContainer: NodeDependencyContainer);
        }

        public static bool CalculatePerformsCanIdTransformation(bool performsCanIdTransformation, Context context, TemplateType templateType)
        {
            if (context != null && templateType != null)
            {
                if (context.PerformsCANIDTransformationNodeDefinition != null)
                {
                    return templateType.NodeDefinition.Equals(context.PerformsCANIDTransformationNodeDefinition);
                }
            }

            return performsCanIdTransformation;
        }

        public override int GetHashCode()
        {
            var baseHashCode = base.GetHashCode();

            var hashCode = SubNodeTemplateIssues.Aggregate(baseHashCode, (current, ntp) => current ^ ntp.GetHashCode());
            return hashCode != 0 ? hashCode : baseHashCode;
        }

        public override bool Equals(object obj)
        {
            if (obj is not NodeTemplateIssue other)
            {
                return false;
            }

            if (!base.Equals(obj))
            {
                return false;
            }

            return
                SubNodeTemplateIssues.OrderBy(ntp => ntp.Id)
                    .SequenceEqual(other.SubNodeTemplateIssues.OrderBy(ntp => ntp.Id));
        }

        public string Name { get; }
        public string ReleaseNotes { get; }

        public int DocumentNumber { get; }
        public int IssueNumber { get; }
        public TemplateType TemplateType { get; }
        public Context Context { get; }
        public string DependencyContainerId { get; }
        public DependencyContainer NodeDependencyContainer { get; }
        public IList<ParentNode> ParentNodes { get; }
        public IList<NodePosition> NodePositions { get; }
        public bool PerformsCanIdTransformation { get; }
        public NodeTemplateStatus StatusCode { get; }
        public bool AllowForUpdateReleased { get; }
        public bool AllowForUpdatePreReleased { get; }
        internal DateTime? IntroductionDate { get; private set; }
        internal DateTime? RejectionDate { get; private set; }
        public DateTime? AmWithdrawalDate { get; private set; }
        public DateTime? PrdWithdrawalDate { get; private set; }

        public string PreferredHardwareVersionGuid { get; }

        public IEnumerable<NodeTemplateIssue> SubNodeTemplateIssues { get; }

        public IEnumerable<NodeTemplateIssue> SelfAndSubNodeTemplateIssues => SubNodeTemplateIssues.Union(new List<NodeTemplateIssue>() { this });

        public IList<ParameterGroup> ParameterGroups
        {
            get { return _parameterGroups.Concat(SubNodeTemplateIssues.SelectMany(ntp => ntp.ParameterGroups)).ToList(); }
        }

        public virtual IList<IComponent> Components
        {
            get
            {
                if (_components == null)
                    return new List<IComponent>();
                return
                    _components
                        .Concat(SubNodeTemplateIssues.SelectMany(ntp => ntp.Components))
                        .ToList();
            }
        }

        public BaseLink Link { get; private set; }
        private readonly IEnumerable<ParameterGroup> _parameterGroups;
        private readonly IList<IComponent> _components;

        public override string ToString()
        {
            return $"{DocumentNumber.ToPartNumber()}.{IssueNumber}";
        }

        public NodeTemplateIssue CloneWithLink(BaseLink link)
        {
            return new NodeTemplateIssue(Id, InternalId, DocumentNumber,
                IssueNumber, Name, ReleaseNotes, TemplateType, Context, DependencyContainerId, PerformsCanIdTransformation, ParentNodes, Conditions, _parameterGroups, _components, AllowForUpdatePreReleased, AllowForUpdateReleased, SubNodeTemplateIssues, PreferredHardwareVersionGuid, AmWithdrawalDate, PrdWithdrawalDate, statusCode: StatusCode, introductionDate: IntroductionDate, rejectionDate: RejectionDate, nodePositions: NodePositions, nodeDependencyContainer: NodeDependencyContainer)
            {
                Link = link
            };
        }

        private static void CheckNodeTemplateConditions(IProduct product, BaseCanNode node, NodeTemplateIssue nodeTemplateIssue)
        {
            var matchingCondition = nodeTemplateIssue.Match(product);
            if (matchingCondition == null)
            {
                var mismatchingVariants =
                    product.ProductSpecification.VariantsInFamilies(
                        nodeTemplateIssue.Conditions.AllUniqueVariantFamilies());
                node.NodeVersionNotifications.Add(new NodeTemplateMismatch(nodeTemplateIssue,
                    mismatchingVariants, nodeTemplateIssue.Conditions));
            }
        }

        public BaseCanNode ApplyNodeTemplateToNode(IProduct product, BaseCanNode originalNode, IHardwareConsistencyChecker hardwareConsistencyChecker, ISoftwareConsistencyChecker softwareConsistencyChecker, bool isAftermarketContext, ICompatibleHardwareFilter compatibleHardwareFilter, NotProgrammableInAftermarketScenario notProgrammableInAftermarketScenario)
        {
            var node = originalNode.Clone(this);

            var clonedNode = node.Clone(this, false);

            CheckNodeTemplateConditions(product, clonedNode, this);

            foreach (var nodeTemplateIssue in SubNodeTemplateIssues)
            {
                CheckNodeTemplateConditions(product, clonedNode, nodeTemplateIssue);
            }

            CheckHardware(product, node, hardwareConsistencyChecker, clonedNode, isAftermarketContext, compatibleHardwareFilter);
            CheckSoftware(product, node, clonedNode, softwareConsistencyChecker, notProgrammableInAftermarketScenario, compatibleHardwareFilter.IsUsingPreReleasedSoftwareStructureComponents);

            softwareConsistencyChecker.SetRestrictedMswInfo(clonedNode, compatibleHardwareFilter.IsUsingPreReleasedSoftwareStructureComponents);

            return clonedNode;
        }

        public BaseCanNode AssignHardwareToNode(IProduct product, BaseCanNode node, INonDownloadableTemplateContainer nonDownloadableTemplateContainer, IConditionMatcher conditionMatcher, IEnumerable<string> hardwareVersionGuids, bool isPreRelease)
        {
            var clonedNode = node.Clone(this, false);

            var matchingCondition = Match(product);
            if (matchingCondition == null)
            {
                var mismatchingVariants =
                    product.ProductSpecification.VariantsInFamilies(
                        Conditions.AllUniqueVariantFamilies());
                clonedNode.NodeVersionNotifications.Add(new NodeTemplateMismatch(this,
                    mismatchingVariants, Conditions));
            }

            var hardwareVersions = hardwareVersionGuids
                .Select(nonDownloadableTemplateContainer.GetVersion)
                .Where(x => x.TemplateType.NodeDefinition.Equals(TemplateType.NodeDefinition));

            foreach (var version in hardwareVersions)
            {
                var items = conditionMatcher.Execute(product, version, true);

                if (version.Type.ComponentTypeCode == ComponentTypeCode.Tea2PlusSubHardware)
                {
                    clonedNode.AddHardwareSlot(CreateDecoratedHardwarePart(product.ProductSpecification.ProductClassCode, version,
                        items, clonedNode.NodeIdentification,
                        (artifactVersion, assemblyPartNumber, quantity, projectStage, type) =>
                            new SubHardwarePart(artifactVersion, assemblyPartNumber, quantity, projectStage, type, null)));
                }
                else
                {
                    clonedNode.AddHardwareSlot(CreateDecoratedHardwarePart(product.ProductSpecification.ProductClassCode, version,
                        items, clonedNode.NodeIdentification,
                        (artifactVersion, assemblyPartNumber, quantity, projectStage, type) =>
                            new ECUHardwarePart(artifactVersion, assemblyPartNumber, quantity, projectStage, type, null)));
                }
            }

            foreach (var softwareComponent in Components.OfType<ISoftwareComponent>())
            {
                clonedNode.AddSoftwareSlot(softwareComponent.DeriveSlot(product, TemplateType, null, isPreRelease));
            }

            return clonedNode;
        }

        private BillOfMaterialContent<PartDecorator<BaseHardwarePart>> CreateDecoratedHardwarePart(string productClass,
            NonDownloadableVersion version, IList<ItemConditionContainer<NonDownloadableVersionItem>> items,
            BaseNodeIdentification nodeIdentification, Func<ArtifactVersion, int, int, string, NonDownloadableComponentType, BaseHardwarePart> createPart)
        {
            var type = version.Type;
            var source = new HardwareItemSource(productClass, items.Count > 0 ? items[0].Condition : null, System.Guid.Empty, DocumentNumber, "",
                       type.Name);

            if (items.Count == 0 || items[0].Item.IsIntentionallyEmpty)
            {
                return
                    new BillOfMaterialContent<PartDecorator<BaseHardwarePart>>(
                        new IntentionallyEmptyPartDecorator<BaseHardwarePart>(createPart(new NullArtifactVersion(), 0, 0, string.Empty, type)), source, nodeIdentification);
            }

            var item = items.OrderBy(i => i.Item.PartNumber).First();
            return
                new BillOfMaterialContent<PartDecorator<BaseHardwarePart>>(
                    new FilledPartDecorator<BaseHardwarePart>(
                        createPart(item.Item.PartNumber.ToArtifactVersion(), 0, item.Item.Quantity, item.Item.ProjectStage, type), item.Item.Quantity), source, nodeIdentification);
        }

        private static void CreateEmptyForMissingNonProgrammableSlots(IProductSpecification productSpecification, BaseCanNode node, NotProgrammableInAftermarketScenario notProgrammableInAftermarketScenario)
        {
            if (!node.NodeTemplates.Any())
            {
                return;
            }
            foreach (var component in node.NodeTemplates.SelectMany(ntp => ntp.Components).OfType<BaseSoftwareComponent>())
            {
                var isNonProgrammable = component is IDownloadableComponent downloadableComponent &&
                                        downloadableComponent.IsNotProgrammableInAftermarket(notProgrammableInAftermarketScenario);

                if (isNonProgrammable)
                {
                    var slot = component.GetMatchingSlot(node);
                    if (slot == null)
                    {
                        slot = component.CreateEmptySlot(node.RootNodeTemplate, productSpecification.ProductClassCode, node.RootNodeTemplate.DocumentNumber.ToArtifactVersion());
                        node.AddSoftwareSlot(slot);
                    }
                }
            }
        }

        private void CheckSoftware(IProduct product, BaseCanNode node, BaseCanNode clonedNode, ISoftwareConsistencyChecker softwareConsistencyChecker, NotProgrammableInAftermarketScenario notProgrammableInAftermarketScenario, bool isPreRelease)
        {
            AssignNonProgrammableSlots(product, node, notProgrammableInAftermarketScenario);
            CreateEmptyForMissingNonProgrammableSlots(product.ProductSpecification, node, notProgrammableInAftermarketScenario);

            softwareConsistencyChecker.CheckPartsInNode(product, node, this, isPreRelease, notProgrammableInAftermarketScenario);

            foreach (var component in Components)
            {
                var isNonProgrammable = component is IDownloadableComponent downloadableComponent &&
                                        downloadableComponent.IsNotProgrammableInAftermarket(notProgrammableInAftermarketScenario);

                if (isNonProgrammable)
                {
                    CopySlotFromOriginalToClone(node, clonedNode, component, product.RequestMetadata);
                }
                else
                {
                    if (component is ISoftwareComponent softwareComponent)
                    {
                        clonedNode.AddSoftwareSlot(softwareComponent.DeriveSlot(product, TemplateType, null, isPreRelease));
                    }
                }
            }
        }

        private void AssignNonProgrammableSlots(IProduct product, BaseCanNode node, NotProgrammableInAftermarketScenario notProgrammableInAftermarketScenario)
        {
            var nonProgrammableComponents =
                Components.Where(
                    x => x is IDownloadableComponent downloadableComponent && downloadableComponent.IsNotProgrammableInAftermarket(notProgrammableInAftermarketScenario)).Cast<BaseSoftwareComponent>().ToList();

            var componentGroups = nonProgrammableComponents.GroupBy(x => x.GetType());

            foreach (var componentGroup in componentGroups)
            {
                var components = componentGroup.ToList();

                var slots = node.AnonymousSlots.Where(x => x.IsMatchingComponentType(componentGroup.Key)).ToList();

                var slotPartNumbers = slots.ConvertAll(CreatePartNumberContainerFromSlot);

                var allPartNumberCombinations = GetAllPossiblePartNumberCombinations(product, components);

                var bestNumberOfSuccessfullyAssignedPartNumbersWeight = 0;
                IList<ArtifactVersionContainer> bestCombination = Array.Empty<ArtifactVersionContainer>();

                foreach (var combination in allPartNumberCombinations)
                {
                    var successfullyAssignedPartNumbersWeight = 0;
                    var combinationList = combination.ToList();
                    var partNumbersToAssign = slotPartNumbers.ToList();

                    successfullyAssignedPartNumbersWeight = AssignAvailablePartNumbers(combinationList, partNumbersToAssign,
                        successfullyAssignedPartNumbersWeight);

                    if (bestNumberOfSuccessfullyAssignedPartNumbersWeight < successfullyAssignedPartNumbersWeight)
                    {
                        AssignRemainingPartNumbers(partNumbersToAssign, combinationList);

                        bestNumberOfSuccessfullyAssignedPartNumbersWeight = successfullyAssignedPartNumbersWeight;
                        bestCombination = combinationList;
                    }
                }

                for (var i = 0; i < bestCombination.Count; ++i)
                {
                    var component = components[i];

                    if (!(bestCombination[i]?.ArtifactVersion.IsEmpty ?? true))
                    {
                        var artifactVersion = bestCombination[i].ArtifactVersion;
                        var patches = bestCombination[i].Patches;

                        var slot = component.CreateFilledSlot(component.Parent, artifactVersion,
                            patches, null);
                        node.AddSoftwareSlot(slot);

                        var anonymousSlotToDrop =
                            node.AnonymousSlots.FirstOrDefault(
                                x => x.IsMatchingComponentType(componentGroup.Key) && x.ArtifactVersion.Equals(slot.ArtifactVersion));
                        if (anonymousSlotToDrop != null)
                        {
                            node.AnonymousSlots.Remove(anonymousSlotToDrop);
                        }
                    }
                }
            }

            foreach (var component in nonProgrammableComponents)
            {
                var matchingSlot = component.GetMatchingSlot(node);
                if (matchingSlot == null)
                {
                    var slot = component.CreateEmptySlot(component.Parent, product.ProductSpecification.ProductClassCode, component.Parent.DocumentNumber.ToArtifactVersion());
                    node.AddSoftwareSlot(slot);
                }
            }
        }

        private static ArtifactVersionContainer CreatePartNumberContainerFromSlot(BaseSlot slot)
        {
            IEnumerable<ArtifactVersion> patches = null;

            if (slot is Tea2PlusDataSlot dataSlot && dataSlot.DataPatches != null)
            {
                patches = dataSlot.DataPatches.Select(x => x.ArtifactVersion);
            }

            return new ArtifactVersionContainer(slot.ArtifactVersion, true, patches);
        }

        private IEnumerable<IEnumerable<ArtifactVersionContainer>> GetAllPossiblePartNumberCombinations(IProduct product, IList<BaseSoftwareComponent> components)
        {
            var componentsWithCompatibleItems = new List<Tuple<BaseSoftwareComponent, List<ComponentItem>>>();

            foreach (var component in components)
            {
                var matchedItems = component.Items.ToList();

                if (matchedItems.Count == 0)
                    matchedItems.Add(null);

                componentsWithCompatibleItems.Add(Tuple.Create(component, matchedItems));
            }

            var compatiblePartnumbers =
                componentsWithCompatibleItems.Select(x => x.Item2.Select(item =>
                {
                    if (item == null)
                        return null;

                    List<ArtifactVersion> patches = null;
                    if (x.Item1 is Tea2PlusDataComponent dataComponent)
                    {
                        patches =
                            dataComponent.Patches
                                .SelectMany(
                                    patch =>
                                        patch.Items.Where(i => i.Match(product) != null)
                                            .Select(i => i.ArtifactVersion)).ToList();
                    }

                    var itemConditionMatched = item.Match(product) != null;

                    var buildDeliveryFiles = product?.RequestMetadata?.GetBuildDeliveryFilesForNodeTemplate(DocumentNumber).ToList() ??
                        new List<BuildDeliveryFile>();

                    var artifactVersion = item.ArtifactVersion.ReplaceByBuildDeliveryFile(DocumentNumber, buildDeliveryFiles);

                    return new ArtifactVersionContainer(artifactVersion, itemConditionMatched, patches);
                }));

            var allPartNumberCombinations = compatiblePartnumbers.CartesianProduct();
            return allPartNumberCombinations;
        }

        private static int AssignAvailablePartNumbers(List<ArtifactVersionContainer> combinationList, List<ArtifactVersionContainer> partNumbersToAssign,
            int successfullyAssignedPartNumbersWeight)
        {
            for (var i = 0; i < combinationList.Count; ++i)
            {
                if (partNumbersToAssign.Contains(combinationList[i]))
                {
                    partNumbersToAssign.Remove(combinationList[i]);
                    successfullyAssignedPartNumbersWeight += 10;
                    if (combinationList[i].ConditionMatched)
                    {
                        successfullyAssignedPartNumbersWeight += 1000;
                    }
                }
                else
                {
                    if (combinationList[i]?.ArtifactVersion.IsEmpty == true)
                    {
                        successfullyAssignedPartNumbersWeight++;
                        if (combinationList[i].ConditionMatched)
                        {
                            successfullyAssignedPartNumbersWeight += 100;
                        }
                    }
                    else
                    {
                        combinationList[i] = null;
                    }
                }
            }
            return successfullyAssignedPartNumbersWeight;
        }

        private static void AssignRemainingPartNumbers(List<ArtifactVersionContainer> partNumbersToAssign, List<ArtifactVersionContainer> combinationList)
        {
            foreach (var remainingPartNumber in partNumbersToAssign)
            {
                for (var i = 0; i < combinationList.Count; ++i)
                {
                    if (combinationList[i] == null)
                    {
                        combinationList[i] = remainingPartNumber;
                        break;
                    }
                }
            }
        }

        private void CheckHardware(IProduct product, BaseCanNode node, IHardwareConsistencyChecker hardwareConsistencyChecker, BaseCanNode clonedNode, bool isAftermarketContext, ICompatibleHardwareFilter compatibleHardwareFilter)
        {
            var hardwareParts = ExtractHardware(node);

            var organizer = new HardwareOrganizer();
            var organizedHardwareParts = organizer.Organize(product, Context, hardwareParts,
                hardwareConsistencyChecker.HardwareContainer, new List<NodeTemplateIssue>() { this },
                new List<BaseNodeIdentification>() { node.NodeIdentification }, compatibleHardwareFilter, isAftermarketContext);

            // If the Ecu hardware is not for the found as a valid part number for the requested node and therefor not typed -> 
            // force it to the node since we only process one node and that will result in an incompatible notification
            organizedHardwareParts = organizedHardwareParts.Select(x =>
            {
                if (x.Value is ECUHardwarePart)
                {
                    var part = x.Value.Clone(type: hardwareConsistencyChecker
                        .HardwareContainer
                        .GetEcuHardwareType(Context, node.NodeDefinition));

                    return new BillOfMaterialContent<BaseHardwarePart>(part, x.Source, node.NodeIdentification, x.Notifications, x.State);
                }

                return new BillOfMaterialContent<BaseHardwarePart>(x.Value, x.Source, node.NodeIdentification, x.Notifications, x.State);
            }).ToList();

            var checkedHardwareParts = hardwareConsistencyChecker.CheckHardwareConsistency(
                new[] { clonedNode.NodeIdentification },
                SubNodeTemplateIssues.Concat(new List<NodeTemplateIssue>() { this }).ToList(),
                organizedHardwareParts,
                null,
                null,
                compatibleHardwareFilter, true, false);

            foreach (var part in checkedHardwareParts)
            {
                clonedNode.AddHardwareSlot(part);
            }

            HandleLimitedValidation(clonedNode, product.RequestMetadata);
        }

        private static void HandleLimitedValidation(BaseCanNode node, IRequestMetadata metadata)
        {
            if (!metadata.LimitedValidation)
            {
                return;
            }

            var hwSlots = node.GetHardwareSlots();
            var subHwNotifications = hwSlots.SelectMany(x => x.Notifications)
                .Where(x => x is BaseHardwareNotification baseHardwareNotification &&
                            (baseHardwareNotification).HardwareType == HardwareType.SubHardware)
                .ToList();
            if (subHwNotifications.Count > 0)
            {
                metadata.LimitedValidationUsed = true;
                foreach (var hwSlot in hwSlots)
                {
                    foreach (var subHwNotification in subHwNotifications)
                    {
                        hwSlot.Notifications.Remove(subHwNotification);
                    }
                }
            }
        }

        private static List<BillOfMaterialContent<BaseHardwarePart>> ExtractHardware(BaseCanNode node)
        {
            var hardwareSlots = node.GetHardwareSlots()
                .Concat(node.AnonymousSlots.Where(x => x.IsHardware));
            var hardwareParts =
                hardwareSlots.Select(
                    x =>
                        new BillOfMaterialContent<BaseHardwarePart>((BaseHardwarePart)x.DecoratedPart.Value, x.Source,
                            node.NodeIdentification, x.Notifications)).ToList();
            return hardwareParts;
        }

        private static void CopySlotFromOriginalToClone(BaseCanNode node, BaseCanNode clonedNode, IComponent component, IRequestMetadata metadata)
        {
            if (node is Tea2PlusNode tea2PlusNode)
                CopySlotFromOriginalToCloneTea2Plus(tea2PlusNode, (Tea2PlusNode)clonedNode, component, metadata);

            if (node is Tea2Node tea2Node)
                CopySlotFromOriginalToCloneTea2(tea2Node, clonedNode, component);
        }

        private static void CopySlotFromOriginalToCloneTea2(Tea2Node tea2Node, BaseCanNode clonedNode, IComponent component)
        {
            if (component is Tea2DataSet1Component)
            {
                clonedNode.AddSoftwareSlot(tea2Node.DataSet1);
            }
            else if (component is Tea2DataSet2Component)
            {
                clonedNode.AddSoftwareSlot(tea2Node.DataSet2);
            }
            else if (component is Tea2DownloaderComponent)
            {
                clonedNode.AddSoftwareSlot(tea2Node.Downloader);
            }
            else if (component is Tea2MainSoftwareComponent)
            {
                clonedNode.AddSoftwareSlot(tea2Node.MainSoftware);
            }
        }

        private static void CopySlotFromOriginalToCloneTea2Plus(Tea2PlusNode tea2PlusNode, Tea2PlusNode clonedNode, IComponent component, IRequestMetadata metadata)
        {
            if (component is Tea2PlusMainSoftwareComponent)
            {
                clonedNode.AddSoftwareSlot(tea2PlusNode.MainSoftware);
                HandleLimitedValidation(clonedNode.MainSoftware, metadata);
            }
            else if (component is Tea2PlusPrimaryBootLoaderComponent)
            {
                clonedNode.AddSoftwareSlot(tea2PlusNode.PrimaryBootLoader);
                HandleLimitedValidation(clonedNode.PrimaryBootLoader, metadata);
            }
            else if (component is Tea2PlusSecondaryBootLoaderComponent)
            {
                clonedNode.AddSoftwareSlot(tea2PlusNode.SecondaryBootLoader);
                HandleLimitedValidation(clonedNode.SecondaryBootLoader, metadata);
            }
            else if (component is Tea2PlusComplementarySoftwareComponent)
            {
                var slot = tea2PlusNode.ComplementarySoftwares.First(x => x.Name == component.Name);
                clonedNode.AddSoftwareSlot(slot);

                // SEM CSW is always fully validated: limited validation must not hide its notifications.
                if (!IsExcludedFromCswLimitedValidation(tea2PlusNode))
                {
                    HandleLimitedValidation(clonedNode.ComplementarySoftwares.First(x => x.Name == component.Name), metadata);
                }
            }
            else if (component is Tea2PlusDataComponent)
            {
                var slot = tea2PlusNode.Data.First(x => x.Name == component.Name);
                clonedNode.AddSoftwareSlot(slot);
                HandleLimitedValidation(clonedNode.Data.First(x => x.Name == component.Name), metadata);
            }
        }

        private static readonly HashSet<string> NodesExcludedFromCswLimitedValidation =
            new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "SEM" };

        private static bool IsExcludedFromCswLimitedValidation(BaseCanNode node)
        {
            var nodeName = node.NodeDefinition?.Name;
            return nodeName != null && NodesExcludedFromCswLimitedValidation.Contains(nodeName);
        }

        private static void HandleLimitedValidation(Tea2PlusSoftwareSlot slot, IRequestMetadata metadata)
        {
            if (metadata.LimitedValidation && slot.Notifications.Count > 0)
            {
                metadata.LimitedValidationUsed = true;
                slot.Notifications.Clear();
            }
        }

        private class ArtifactVersionContainer : IEquatable<ArtifactVersionContainer>
        {
            public ArtifactVersionContainer(ArtifactVersion artifactVersion, bool conditionMatched, IEnumerable<ArtifactVersion> patches)
            {
                ArtifactVersion = artifactVersion;
                ConditionMatched = conditionMatched;

                Patches = patches?.OrderBy(x => x) ?? Enumerable.Empty<ArtifactVersion>();
            }

            public ArtifactVersion ArtifactVersion { get; }

            public bool ConditionMatched { get; }

            public IEnumerable<ArtifactVersion> Patches { get; }

            public bool Equals(ArtifactVersionContainer other)
            {
                if (other == null)
                {
                    return false;
                }

                if (!ArtifactVersion.Equals(other.ArtifactVersion))
                {
                    return false;
                }

                if (Patches == null)
                {
                    return other.Patches == null;
                }

                if (other.Patches == null)
                {
                    return false;
                }

                return Patches.FullIntersect(other.Patches);
            }
        }

        public bool IsAfterMarketEquivalent(NodeTemplateIssue other)
        {
            if (other == null)
            {
                return false;
            }

            if (!TemplateType.Equals(other.TemplateType))
            {
                return false;
            }

            if (!Conditions.SequenceEquals(other.Conditions))
            {
                return false;
            }

            if (!ParentNodes.SequenceEquals(other.ParentNodes))
            {
                return false;
            }

            if (!ParameterGroups.AreAfterMarketEquivalent(other.ParameterGroups))
            {
                return false;
            }

            if (!Components.AreAfterMarketEquivalent(other.Components))
            {
                return false;
            }

            return true;
        }

        public IList<CompatibilityCondition> DeriveCompatibilityConditions(IProduct product, ICompatibleHardwareFilter compatibleHardwareFilter)
        {
            var itemLists = new List<List<CompatibilityConditionItem>>()
            {
                new List<CompatibilityConditionItem>()
            };

            if (compatibleHardwareFilter.NodeTemplateIssueIsWithdrawn(this))
            {
                return null;
            }

            foreach (var component in Components.OfType<BaseSoftwareComponent>())
            {
                var slot = component.DeriveSlot(product, TemplateType, null, compatibleHardwareFilter.IsUsingPreReleasedSoftwareStructureComponents);

                if (slot.IsFilled)
                {
                    foreach (var itemList in itemLists)
                    {
                        itemList.Add(new CompatibilityConditionItem(slot.TypeName, slot.Name, slot.ArtifactVersion, 1, DocumentNumber,
                            slot.Source, slot));
                    }
                }
                if (slot.IsOverflow)
                {
                    var items = new List<CompatibilityConditionItem>
                    {
                        new CompatibilityConditionItem(slot.TypeName, slot.Name, slot.ArtifactVersion, 1, DocumentNumber,
                            slot.Source, slot)
                    };

                    if (slot.DecoratedPart is OverflowPartDecorator<BasePart> overflowPart)
                    {
                        foreach (var otherValue in overflowPart.OtherValues)
                        {
                            items.Add(new CompatibilityConditionItem(slot.TypeName, slot.Name,
                                otherValue.Part.ArtifactVersion, 1, DocumentNumber, otherValue.Source, slot));
                        }
                    }

                    var newLists = new List<List<CompatibilityConditionItem>>();
                    foreach (var item in items)
                    {
                        var tempLists = itemLists.ConvertAll(il => il.ToList());
                        foreach (var tempList in tempLists)
                        {
                            tempList.Add(item);
                        }
                        newLists.AddRange(tempLists);
                    }
                    itemLists = newLists;
                }
                if (slot.IsEmpty)
                {
                    return null;
                }
            }
            return itemLists.ConvertAll(il => new CompatibilityCondition(il));
        }

        public IEnumerable<BaseSlot> MatchedSlots(IProduct product, IEnumerable<BaseSlot> slotsToMatch, bool isPreRelease)
        {
            var matchedSlots = new List<BaseSlot>();

            var derivedSlots = Components.Select(c => c.DeriveSlot(product, TemplateType, null, isPreRelease))
                .ToList();

            foreach (var slot in slotsToMatch)
            {
                var matchingSlot = derivedSlots.Find(s => s.Equals(slot));

                if (slot.IsMatchingSlot(matchingSlot))
                {
                    matchedSlots.Add(matchingSlot);
                }
            }

            return matchedSlots;
        }

        private IEnumerable<int> GetAllPartnumbers()
        {
            return Components?.SelectMany(c => { if (c is Tea2PlusDataComponent dataComponent) { return dataComponent.Items
                    .Union(dataComponent.Patches.SelectMany(p => p.Items)); } else return c.Items; })
                .Where(i => i.ArtifactVersion.PartNumber.HasValue)
                .Select(i => i.ArtifactVersion.PartNumber.Value).Distinct();

        }

        private IEnumerable<int> GetAllEstablishedParts()
        {
            return Components?.SelectMany(c => {
                if (c is Tea2PlusDataComponent dataComponent)
                {
                    return dataComponent.Items
                    .Union(dataComponent.Patches.SelectMany(p => p.Items));
                }
                else return c.Items;
            })
                .Select(i=>i.ArtifactVersion).OfType<ArtifactClassArtifact>()
                .Where(a => a.EstablishedArtifactVersion is { PartNumber: { } })
                .Select(a=>a.EstablishedArtifactVersion.PartNumber ?? 0).Distinct();

        }

        public bool IsAllPartsHavingPrereleaseSSC(ISoftwareMetaDataLoader metaDataLoader)
        {
            if (metaDataLoader == null)
                return false;
            var partNumbers = GetAllPartnumbers().Union(GetAllEstablishedParts()).Distinct().ToList();
            if (partNumbers == null || !partNumbers.Any())
                return false;

            var sscParts = metaDataLoader.LoadSoftwareMetaDataAsync(partNumbers.Select(pn => pn.ToArtifactVersion()), true).GetAwaiter().GetResult().ToList();
            foreach (var partNumber in partNumbers)
            {
                if (!sscParts.Any(s => s?.ArtifactVersion?.PartNumber?.Equals(partNumber) ?? false))
                {
                    return false;
                }
            }
            return true;
        }
    }
}