using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Component;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Conditions;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.NodeTemplate;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ProductDefinition;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Sources;
using Volvo.SoftwareBreakdown.GatewayComponents.Request.Listener.Aftermarket.ProductUpdateService_2_0.Translators;

namespace Volvo.SoftwareBreakdown.GatewayComponents.Request.Listener.UnitTests.Aftermarket.ProductUpdateService_2_0
{
    /// <summary>
    /// Bug 141903: nodeTemplateSource.documentNumber must never be "0" (schema: VolvoPartNumber = \d{7,10}).
    /// </summary>
    [TestClass]
    public class SourceResolverTest
    {
        private static readonly IEnumerable<BaseNodeIdentification> NodeIdentifications =
            new List<BaseNodeIdentification> { new NodeName(2, 1, "SEM") };

        [TestMethod]
        public void Resolve_node_source_with_node_template_returns_node_template_source()
        {
            var ntp = new NodeTemplateIssue("", 1, 24976197, 1, "", "", (TemplateType)null, (Context)null, 0.ToString(), true,
                (IList<ParentNode>)null, (IList<BaseCondition>)null, (IEnumerable<ParameterGroup>)null, (IList<IComponent>)null,
                true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var source = new ReleaseNoteContainerNodeSource("B1", NodeIdentifications, ntp);

            var resolved = new SourceResolver().Resolve(source);

            Assert.AreEqual(SourceTypeNames.NodeTemplateSource, resolved.Type);
            Assert.AreEqual("24976197", resolved.DocumentNumber);
        }

        [TestMethod]
        public void Resolve_node_source_without_node_template_falls_back_to_context_source()
        {
            var source = new ReleaseNoteContainerNodeSource("B1", NodeIdentifications, null);

            var resolved = new SourceResolver().Resolve(source);

            Assert.AreEqual(SourceTypeNames.ContextSource, resolved.Type);
            Assert.AreEqual("unknown", resolved.ContextName);
            Assert.IsNull(resolved.DocumentNumber);
        }
    }
}
