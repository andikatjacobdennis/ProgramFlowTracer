using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Component;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Conditions;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ConversionKit;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ConversionKit.Conditions;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Node;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.NodeTemplate;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ProductDefinition;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Sources;
using Volvo.SoftwareBreakdown.TestUtilityComponent;

namespace Volvo.SoftwareBreakdown.BreakdownDomain.Model.UnitTests.DomainLayer.ConversionKit
{
    /// <summary>
    /// Bug 141903: release notes attached to a node's release-note container must carry the node template
    /// document number of the node on the (updated) product, never 0.
    /// </summary>
    [TestClass]
    public class ReleaseNoteContainerNodeTransitionTest
    {
        private const int NewNodeTemplateDocumentNumber = 24976197;

        [TestMethod]
        public void CreateSource_uses_node_template_document_number_of_matching_node()
        {
            var nodeName = new NodeName(2, 1, "SEM");
            var product = CreateProduct(CreateNode(nodeName, NewNodeTemplateDocumentNumber));
            var transition = new TestableTransition(new List<BaseNodeIdentification> { new NodeName(2, 1, "SEM") });

            var source = transition.InvokeCreateSource(product);

            Assert.IsInstanceOfType(source, typeof(ReleaseNoteContainerNodeSource));
            Assert.AreEqual(NewNodeTemplateDocumentNumber, source.PartNumber);
        }

        [TestMethod]
        public void CreateSource_returns_zero_document_number_when_no_node_matches()
        {
            var product = CreateProduct(CreateNode(new NodeName(2, 1, "SEM"), NewNodeTemplateDocumentNumber));
            var transition = new TestableTransition(new List<BaseNodeIdentification> { new NodeName(3, 1, "OTHER") });

            var source = transition.InvokeCreateSource(product);

            Assert.AreEqual(0, source.PartNumber);
        }

        [TestMethod]
        public void CreateSource_does_not_throw_when_product_has_no_bill_of_material()
        {
            var productSpecification = new Mock<IProductSpecification>();
            productSpecification.Setup(p => p.ProductClassCode).Returns("B1");
            var product = new Mock<IProduct>();
            product.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);
            product.Setup(p => p.BillOfMaterial).Returns((IBillOfMaterial)null);
            var transition = new TestableTransition(new List<BaseNodeIdentification> { new NodeName(2, 1, "SEM") });

            var source = transition.InvokeCreateSource(product.Object);

            Assert.AreEqual(0, source.PartNumber);
        }

        private static IProduct CreateProduct(BaseCanNode node)
        {
            var productSpecification = new Mock<IProductSpecification>();
            productSpecification.Setup(p => p.ProductClassCode).Returns("B1");
            var billOfMaterial = new Mock<IBillOfMaterial>();
            billOfMaterial.Setup(b => b.Nodes).Returns(new List<BaseCanNode> { node });
            var product = new Mock<IProduct>();
            product.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);
            product.Setup(p => p.BillOfMaterial).Returns(billOfMaterial.Object);
            return product.Object;
        }

        private static Tea2PlusNode CreateNode(NodeName nodeName, int documentNumber)
        {
            var context = Helper.CreateContext("2", "B1", "context1", false, true);
            var nodeDefinition = nodeName.ToTea2PlusNodeDefinition();
            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var nodeTemplate = new NodeTemplateIssue("", 1, documentNumber, 1, "", "", templateType, context, 0.ToString(), false,
                Array.Empty<Model.NodeTemplate.ParentNode>(), Array.Empty<BaseCondition>(), Array.Empty<ParameterGroup>(), Array.Empty<IComponent>(),
                true, true, null, null, null, NodeTemplateStatus.ReleasedPrd, null, null, null);

            return new Tea2PlusNode(documentNumber, nodeName, nodeDefinition, nodeTemplate, new TestSource(), false);
        }

        private sealed class TestableTransition : ReleaseNoteContainerNodeTransition
        {
            public TestableTransition(IEnumerable<BaseNodeIdentification> nodeIdentifications)
                : base(new ReleaseNoteContainer(1, 1, false, false, false), nodeIdentifications)
            {
            }

            public BaseSource InvokeCreateSource(IProduct product) =>
                CreateSource(product, 0, null, Array.Empty<KitConditionGroup>());
        }
    }
}
