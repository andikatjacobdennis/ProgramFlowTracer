using System;
using System.Collections.Generic;
using System.Linq;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ConversionKit.Conditions;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ConversionKit.Operations;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.NodeTemplate;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ProductDefinition;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.RepositoryInterfaces;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Sources;

namespace Volvo.SoftwareBreakdown.BreakdownDomain.Model.ConversionKit
{

    public class ReleaseNoteContainerNodeTransition : Transition
    {
        public IEnumerable<BaseNodeIdentification> NodeIdentifications { get; }

        public ReleaseNoteContainerNodeTransition(ReleaseNoteContainer releaseNoteContainer, IEnumerable<BaseNodeIdentification> baseNodeIdentifications) : base(releaseNoteContainer.Id, 0, releaseNoteContainer?.Kit?.KitOperationGroups)
        {
            NodeIdentifications = baseNodeIdentifications;
        }

        protected override BaseSource CreateSource(IProduct product, int partNumber,
            KitOperationGroup kitOperationGroup, IEnumerable<KitConditionGroup> matchedKitConditionGroups)
        {
            // Bug 141903: the node template used to be passed as null here, so the source's PartNumber
            // (serialized as nodeTemplateSource.documentNumber) was always 0 and failed the response
            // schema (VolvoPartNumber = \d{7,10}). Resolve the node template from the product's node instead.
            return new ReleaseNoteContainerNodeSource(product.ProductSpecification.ProductClassCode,
               NodeIdentifications, ResolveNodeTemplate(product));
        }

        private NodeTemplateIssue ResolveNodeTemplate(IProduct product)
        {
            var nodes = product?.BillOfMaterial?.Nodes;
            if (nodes == null || NodeIdentifications == null)
                return null;

            var matchedNode = nodes.FirstOrDefault(node =>
                node?.NodeIdentification != null &&
                node.DocumentNumber > 0 &&
                NodeIdentifications.Any(ni => ni != null && ni.Equals(node.NodeIdentification)));

            var nodeTemplate = matchedNode?.RootNodeTemplate;
            return nodeTemplate != null && nodeTemplate.DocumentNumber > 0 ? nodeTemplate : null;
        }

        public IEnumerable<KitOperationSourcePair> GetReleaseNotes(IProduct product, IRepositoryCarrier repositoryCarrier)
        {
            var operations = FilterOutApplicableOperations(product, repositoryCarrier);
            if (GetStaggeredAvailability(operations))
            {
                return operations.Where(p => p.KitOperation is AssignReleaseNoteKitOperation);
            }
            return new List<KitOperationSourcePair>();
        }
    }
}