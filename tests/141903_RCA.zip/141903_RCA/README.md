# Bug 141903 – T3 Conversion Kit: Assign Node Template not working

| | |
|---|---|
| Work item | User Story / Bug **141903** (child task 142126 "Identify the root cause") |
| Iteration | PI26EW46-47 |
| Kit | Conversion kit **85671251** (QA), operation *Introduced / Update* |
| Expected | Node template **24759479 → 24976197** |
| Observed | Response contains only `errors[]` – `InvalidOperationException: Response schema validation failed` |
| traceId | `492de248-5d72-45e9-9858-8cc49bf581e7` |
| Repo / base | `swb-stable1` @ `1fb1300` |

---

## 1. TL;DR

The kit evaluation itself works. The response then fails **its own JSON schema validation**, so the
service discards the result and returns only an error.

The one hard schema failure is:

```
#/productUpdate/releaseNotes/0/source/documentNumber
  esw-node.schema.json#/$defs/VolvoPartNumber
  pattern - "0" did not match '\d{7,10}'
```

A release note attached to the updated node gets the source `{ "$type": "nodeTemplateSource", "documentNumber": "0" }`.
The `"0"` comes from `ReleaseNoteContainerNodeTransition.CreateSource`, which always builds
`ReleaseNoteContainerNodeSource` with `ntp: null`, so its `PartNumber` is always `0`.

* `RequestSoftware` has a later step that patches this (SOURCE 3 in `AftermarketService`).
* **`RequestKit` has no such step**, and `SourceResolver` writes `"0"` to the response without checking it.
  That is why conversion kits that update a node with a release-note container fail.

---

## 2. Reading the error (191 messages → 1 real problem)

The validator reports every alternative it tried inside each `oneOf`/`anyOf`, so most of the 191 messages are noise.
After decoding them (see [`evidence/decoded-schema-errors.txt`](evidence/decoded-schema-errors.txt)):

| Instance path | Messages | Verdict |
|---|---|---|
| `customerAdaptations/*/source` | `contextSource` ≠ `conversionKitSource` / `nodeTemplateSource` / … | Noise: the `contextSource` alternative (anyOf/0) matches |
| `parameters/*/source`, `parameters/*/parameterValue` | other alternatives not matched | Noise: the `scalar`/`struct`/`array` alternative matches |
| `nodes/0` | `hpcNode` not present | Noise: the `tea2PlusNode` alternative matches |
| `nodes/0/tea2PlusNode/parentNode` | `rootNode` not present, `nodeName` should be null | Noise: ParentNode oneOf/0 matches, oneOf/1 is the expected miss |
| **`releaseNotes/0/source/documentNumber`** | **minLength 7, pattern `\d{7,10}` on value `"0"`** | **Real failure.** Every alternative of `Source` fails → `anyOf - did not validate` |
| `#` | `ProductUpdateResponse oneOf` – neither `productUpdate` nor `errors` branch valid | Consequence of the row above |

`releaseNotes` is the only path that ends in `anyOf - did not validate against the schema`. Every other path has one alternative that matches.

---

## 3. Root cause

### 3.1 Where the 0 is created

`src/NVSComponents/BreakdownDomain/BreakdownDomain.Model/ConversionKit/ReleaseNoteContainerNodeTransition.cs`

```csharp
protected override BaseSource CreateSource(IProduct product, int partNumber, ...)
{
    return new ReleaseNoteContainerNodeSource(product.ProductSpecification.ProductClassCode,
       NodeIdentifications, null);                         // <-- ntp is always null
}
```

`src/NVSComponents/BreakdownDomain/BreakdownDomain.Model/Sources/ReleaseNoteContainerNodeSource.cs`

```csharp
PartNumber = ntp?.DocumentNumber ?? 0;                     // <-- therefore always 0
```

### 3.2 Why the software flow hides it but the kit flow does not

`src/NVSComponents/BreakdownDomain/BreakdownDomain.Services/AftermarketService.cs`

* `RequestSoftware` (lines ~193-214): the **SOURCE 3** step (`ResolveNodeTemplateTransitionSource`) looks up the
  added node and replaces the source with one that has a real `NodeTemplateIssue`. Any release note this step
  cannot match still keeps `PartNumber = 0`.
* `RequestKit` (lines ~647-666): only unions kit-container, node-container and service-pack release notes. **There is no
  enrichment step**, so every node release note keeps `PartNumber = 0`.

### 3.3 Where the 0 reaches the response

`src/NVSComponents/GatewayComponents/Request.Listener/Aftermarket/ProductUpdateService_2_0/Translators/SourceResolver.cs`
(and the same code in `ProductUpdateService_1_0`)

```csharp
private static SourceInfo CreateNodeTemplateSource(ReleaseNoteContainerNodeSource nodeSource)
    => new SourceInfo { Type = NodeTemplateSource, DocumentNumber = nodeSource.PartNumber.ToString() }; // "0"
```

`SourceTranslator.CreateNodeTemplateSource` writes `documentNumber` for any non-empty string, so `"0"` goes into the
JSON. `Handler.ValidateResponse` then throws.

### 3.4 Diagrams

```mermaid
flowchart TD
    A["Kit 85671251<br/>Update 24759479 → 24976197"] --> B["AftermarketService.RequestKit"]
    B --> D["GetReleaseNotesFromReleaseNoteNodeContainers"]
    D --> F["ReleaseNoteContainerNodeTransition.CreateSource<br/><b>ntp: null → PartNumber 0</b>"]
    F --> H{"RequestKit: no node-template<br/>enrichment (RequestSoftware has one)"}
    H --> K["SourceResolver<br/><b>documentNumber = &quot;0&quot;</b>"]
    K --> M["Handler.ValidateResponse"]
    M --> N["VolvoPartNumber \\d{7,10} ✖<br/>Source anyOf ✖ → Response oneOf ✖"]
    N --> P["errors[] returned<br/><b>node update looks 'not working'</b>"]
    classDef bad fill:#fde2e1,stroke:#c0392b,color:#000;
    class F,K,N,P bad;
```

```mermaid
sequenceDiagram
    autonumber
    participant C as Client (QA)
    participant H as Handler
    participant AS as AftermarketService
    participant T as ReleaseNoteContainerNodeTransition
    participant SR as SourceResolver
    participant V as Corvus Validate
    C->>H: kit 85671251
    H->>AS: RequestKit
    AS->>T: GetReleaseNotes(product)
    T->>T: CreateSource → NodeSource(ntp = null)
    Note right of T: PartNumber = 0
    T-->>AS: release note + source(0)
    Note over AS: no enrichment in RequestKit
    AS-->>H: WorkFlow.ReleaseNotes
    H->>SR: Resolve(source)
    SR-->>H: nodeTemplateSource "0"
    H->>V: Validate(Verbose)
    V-->>H: ✖ VolvoPartNumber
    H-->>C: errors[] only
```

The source files for these diagrams (and the fixed-flow diagram below) are in [`diagrams/`](diagrams/).

---

## 4. Fix

Two changes: fix the value where it is created, and stop the response layer from ever writing `"0"`.

```mermaid
flowchart TD
    E["CreateSource(product)"] --> R["<b>FIX 1</b> ResolveNodeTemplate(product)<br/>matching node in BillOfMaterial.Nodes → RootNodeTemplate"]
    R -->|found| S1["PartNumber = 24976197"]
    R -->|not found| S0["PartNumber = 0"]
    S1 --> G{"<b>FIX 2</b> SourceResolver<br/>PartNumber &gt; 0 ?"}
    S0 --> G
    G -->|yes| OK1["nodeTemplateSource / &quot;24976197&quot;"]
    G -->|no| OK2["Log.Warning → contextSource / &quot;unknown&quot;"]
    OK1 --> V["ValidateResponse ✔"]
    OK2 --> V
    classDef good fill:#e3f6e5,stroke:#2e7d32,color:#000;
    class R,G,OK1,OK2,V good;
```

| # | File (relative to repo root) | Change |
|---|---|---|
| 1 | `src/NVSComponents/BreakdownDomain/BreakdownDomain.Model/ConversionKit/ReleaseNoteContainerNodeTransition.cs` | `CreateSource` now looks up the node on the product whose `NodeIdentification` is one of the container's `NodeIdentifications` and that has a `DocumentNumber > 0`. It passes that node's `RootNodeTemplate` instead of `null`. This covers **every** flow that uses node release-note containers (`RequestKit`, `RequestSoftware`, `AvailableUpdatesService`). `RequestSoftware`'s SOURCE 3 step keeps working and is now a fallback. |
| 2 | `src/NVSComponents/GatewayComponents/Request.Listener/Aftermarket/ProductUpdateService_2_0/Translators/SourceResolver.cs` | `CreateNodeTemplateSource` returns a `contextSource` (`contextName: "unknown"`) and logs a warning when `PartNumber <= 0`. It never writes a `documentNumber` that breaks the schema. |
| 3 | `src/NVSComponents/GatewayComponents/Request.Listener/Aftermarket/ProductUpdateService_1_0/Translators/SourceResolver.cs` | Same guard for the 1.0 contract. |
| T1 | `src/Tests/UnitTests/BreakdownDomain/BreakdownDomain.Model.UnitTests/DomainLayer/ConversionKit/ReleaseNoteContainerNodeTransitionTest.cs` | New tests: matching node → 24976197; no matching node → 0; no BOM → no exception. |
| T2 | `src/Tests/UnitTests/GatewayComponents/Request.Listener.UnitTests/Aftermarket/ProductUpdateService_2_0/SourceResolverTest.cs` | New tests: valid NTP → `nodeTemplateSource "24976197"`; null NTP → `contextSource "unknown"`, no `documentNumber`. |

Both side effects are safe:
* `BaseSource.Equals/GetHashCode` include `PartNumber`. Release-note dedup is by **release-note guid**
  (`GroupBy(x => x.Key.Guid)`), not by source equality, so the result does not change.
* The AMT/DEV translator (`AmtDevCommon/Extensions.cs`) reads only `NodeIdentifications` from
  `ReleaseNoteContainerNodeSource`, not `PartNumber`.

---

## 5. Package layout

```
141903_RCA/
├── README.md                      ← this file
├── fix/                           ← changed/new files at their repo-relative paths (copy over repo root)
│   └── src/...
├── original/                      ← the same production files at 1fb1300, for side-by-side comparison
│   └── src/...
├── patches/141903.diff            ← unified diff; apply with:  git apply patches/141903.diff
├── diagrams/
│   ├── 01-failure-flow.mmd
│   ├── 02-fixed-flow.mmd
│   └── 03-sequence.mmd
└── evidence/
    └── decoded-schema-errors.txt  ← the 191 validator messages decoded and deduplicated
```

### Apply

From the repository root (on a feature branch such as
`feature/141903-4.47-T3_ConversionKit_AssignNodeTemplate_NotWorking`):

```bash
git apply --check <path-to>/141903_RCA/patches/141903.diff && git apply <path-to>/141903_RCA/patches/141903.diff
```

or copy the contents of `fix/` over the repository root.

---

## 6. Verification

| Check | Result |
|---|---|
| Decoded the QA response (`evidence/decoded-schema-errors.txt`) | Only hard failure is `releaseNotes/0/source/documentNumber = "0"` |
| `git apply --check patches/141903.diff` on `1fb1300` | ✅ applies cleanly |
| Static review: every type, namespace and constructor the new code uses exists (single `NodeTemplateIssue` ctor, `NodeName(short,short,string)`, `Tea2PlusNode(int, NodeName, def, ntp, source, bool)`, `SourceInfo.ContextName`, Serilog already imported in both resolvers) | ✅ |
| `dotnet test` (new tests) | ⚠️ **Not run.** Restore fails on this machine because the private Volvo NuGet feed is not configured: `NU1101 Volvo.NVS.Messaging`, `Volvo.Esw.SoftwareBreakdown.Contracts`, … `src/nuget.config` lists only nuget.org. **Run these on a machine or pipeline with feed access:** |

```bash
dotnet test src/Tests/UnitTests/BreakdownDomain/BreakdownDomain.Model.UnitTests/BreakdownDomain.Model.UnitTests.csproj --filter "FullyQualifiedName~ReleaseNoteContainerNodeTransitionTest"
dotnet test src/Tests/UnitTests/GatewayComponents/Request.Listener.UnitTests/Request.Listener.UnitTests.csproj --filter "FullyQualifiedName~ProductUpdateService_2_0.SourceResolverTest"
```

Run the full `BreakdownDomain.Model.UnitTests` and `Request.Listener.UnitTests` suites as well, since FIX 1 changes the
`PartNumber` of every `ReleaseNoteContainerNodeSource`.

### Recommended QA re-test

1. Deploy the fix to QA.
2. Send `Conversion_Kit_85671251_Request.json` again (chassis NR 999222).
3. Expect a `productUpdate` response (no `errors[]`). The release note should have
   `source: { "$type": "nodeTemplateSource", "documentNumber": "24976197" }`, and the node should move from **24759479 → 24976197**.

---

## 7. Notes and follow-ups

* **The KitRequestService 1.0 handler is not in this repository snapshot.** The error text, schema names
  (`product-update-response.schema.json`, `esw-node.schema.json`) and `ValidateResponse` wording match the
  `ProductUpdateService_2_0` contract and `ResponseBuilder` / `SourceResolver` stack. The domain call for kits is
  `AftermarketService.RequestKit`. FIX 1 lives in the shared domain model, so it applies whichever handler QA routes to.
  If that handler has its own copy of `SourceResolver`, add the FIX 2 guard there too.
* `RequestKit` still has no SOURCE 3 enrichment. After FIX 1 it does not need one, but you could remove
  `ResolveNodeTemplateTransitionSource` from `RequestSoftware` later to keep the two flows the same.
* The `ProductUpdateService_2_0` handler logs every validator message, including the alternatives that matched. Logging
  only the leaf failures (`!x.Valid` under `anyOf`/`oneOf` that failed overall) would have pointed straight at
  `releaseNotes/0/source/documentNumber`.
