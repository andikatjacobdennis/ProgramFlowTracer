﻿using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ParameterData;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ProductDefinition;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Sources;
using Volvo.SoftwareBreakdown.GatewayComponents.Request.Listener.Aftermarket.ProductUpdateService_1_0.Interfaces;

namespace Volvo.SoftwareBreakdown.GatewayComponents.Request.Listener.Aftermarket.ProductUpdateService_1_0.Translators
{
    public class SourceResolver : ISourceResolver
    {
        public SourceInfo Resolve(BaseSource source)
        {
            if (source == null)
            {
                return CreateContextSource();
            }

            Log.Information("Resolving source type {SourceType} with value {SourceValue}", source.GetType().FullName, source);

            return source switch
            {
                ReleaseNoteContainerNodeSource nodeSource => CreateNodeTemplateSource(nodeSource),
                ServicePackSource sp => CreateServicePackSource(sp),
                ConversionKitSource ck => CreateConversionKitSource(ck),
                SoftwareProductTemplateSource spt => CreateSoftwareProductTemplateSource(spt),
                _ => CreateContextSource()
            };
        }

        public SourceInfo ResolveFromVariant(string variant)
        {
            return new SourceInfo
            {
                Type = SourceTypeNames.ContextSource,
                Identifier = variant
            };
        }

        public SourceInfo ResolveFromSNote(string snote)
        {
            return new SourceInfo
            {
                Type = SourceTypeNames.ContextSource,
                Identifier = snote
            };
        }

        public SourceInfo ResolveFromParameter(BaseParameter parameter, WorkFlow workflow)
        {
            return new SourceInfo
            {
                Type = SourceTypeNames.ContextSource,
                Identifier = parameter?.ParameterCode
            };
        }

        private static SourceInfo CreateNodeTemplateSource(ReleaseNoteContainerNodeSource nodeSource)
        {
            return new SourceInfo
            {
                Type = SourceTypeNames.NodeTemplateSource,
                DocumentNumber = nodeSource.PartNumber.ToString(),
            };
        }

        private static SourceInfo CreateServicePackSource(ServicePackSource sp)
        {
            return new SourceInfo
            {
                Type = SourceTypeNames.ServicePackSource,
                Name = sp.ShortName,
                Guid = sp.Guid
            };
        }

        private static SourceInfo CreateConversionKitSource(ConversionKitSource ck)
        {
            return new SourceInfo
            {
                Type = SourceTypeNames.ConversionKitSource,
                PartNumber = ck.PartNumber > 0 ? ck.PartNumber.ToString() : null
            };
        }

        private static SourceInfo CreateSoftwareProductTemplateSource(SoftwareProductTemplateSource spt)
        {
            return new SourceInfo
            {
                Type = SourceTypeNames.SoftwareProductTemplateSource,
                Identifier = spt.Identifier
            };
        }

        private static SourceInfo CreateContextSource()
        {
            return new SourceInfo
            {
                Type = SourceTypeNames.ContextSource
            };
        }
    }
}
