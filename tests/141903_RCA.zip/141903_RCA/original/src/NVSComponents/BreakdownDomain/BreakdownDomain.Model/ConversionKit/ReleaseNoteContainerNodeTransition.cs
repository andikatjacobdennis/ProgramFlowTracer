using System;
using System.Collections.Generic;
using System.Linq;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ConversionKit.Conditions;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ConversionKit.Operations;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ProductDefinition;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.RepositoryInterfaces;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Sources;

namespace Volvo.SoftwareBreakdown.BreakdownDomain.Model.ConversionKit
{

    public class ReleaseNoteContainerNodeTransition : Transition
    {
        public IEnumerable<BaseNodeIdentification> NodeIdentifications { get; }

        public ReleaseNoteContainerNodeTransition(ReleaseNoteContainer releaseNoteContainer, IEnumerable<BaseNodeIdentification> baseNodeIdentifications) : base(releaseNoteContainer.Id, 0, releaseNoteContainer?.Kit?.KitOperationGroups)
        {
            NodeIdentifications = baseNodeIdentifications;
        }

        protected override BaseSource CreateSource(IProduct product, int partNumber,
            KitOperationGroup kitOperationGroup, IEnumerable<KitConditionGroup> matchedKitConditionGroups)
        {

            return new ReleaseNoteContainerNodeSource(product.ProductSpecification.ProductClassCode,
               NodeIdentifications, null);
        }

        public IEnumerable<KitOperationSourcePair> GetReleaseNotes(IProduct product, IRepositoryCarrier repositoryCarrier)
        {
            var operations = FilterOutApplicableOperations(product, repositoryCarrier);
            if (GetStaggeredAvailability(operations))
            {
                return operations.Where(p => p.KitOperation is AssignReleaseNoteKitOperation);
            }
            return new List<KitOperationSourcePair>();
        }
    }
}