using Corvus.Json;
using Newtonsoft.Json.Schema;
using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using System.Threading.Tasks;
using Volvo.Esw.SoftwareBreakdown.Contracts.Json.v1;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Baseline;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Node;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Parts;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ProductDefinition;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.RepositoryInterfaces;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Request;
using Volvo.SoftwareBreakdown.BreakdownDomain.Services;
using Volvo.SoftwareBreakdown.GatewayComponents.Request.Listener.Aftermarket.ProductUpdateService_1_0.Interfaces;
using Volvo.SoftwareBreakdown.ProxyComponents.Proxy.RepoLib;
using static Volvo.Esw.SoftwareBreakdown.Contracts.Json.v1.ProductUpdateResponse.Tea2PlusEcuHardwareExtended;
using JsonNodeName = Volvo.Esw.SoftwareBreakdown.Contracts.Json.v1.NodeName;
using NodeName = Volvo.SoftwareBreakdown.BreakdownDomain.Model.ProductDefinition.NodeName;

namespace Volvo.SoftwareBreakdown.GatewayComponents.Request.Listener.Aftermarket.ProductUpdateService_1_0.Translators
{
	public interface INodeTranslator
	{
		ProductUpdateResponse.Node? TranslateNode(BaseCanNode node, HpcHardwareSnapshot hardwareSnapshot = null, List<RepoLibIdentifierLink> repoLibIdentifiers = null, IProduct productSpec = null);
		ProductUpdateResponse.Node? TranslateNodeWithoutCanNode(HpcNode node, HpcHardwareSnapshot hardwareSnapshot = null, List<RepoLibIdentifierLink> repoLibIdentifiers = null, IProduct productSpec = null);
	}

	public class NodeTranslator : INodeTranslator
	{
		private readonly ISlotTranslator _slotTranslator;
		private readonly IEvalService _evalService;
		private readonly IRepoLibProxy _repoLibService;
        private readonly IBaselineRepository _baselineRepository;
        private readonly IServicePackCompatibilityResolver _servicePackCompatibilityResolver;

        public NodeTranslator(ISlotTranslator slotTranslator, IEvalService evalService, IRepoLibProxy repoLibService,IBaselineRepository baselineRepository, IServicePackCompatibilityResolver servicePackCompatibilityResolver)
        {
			_slotTranslator = slotTranslator ?? throw new ArgumentNullException(nameof(slotTranslator));
			_evalService = evalService ?? throw new ArgumentNullException(nameof(evalService));
			_repoLibService = repoLibService ?? throw new ArgumentNullException(nameof(repoLibService));
            _baselineRepository = baselineRepository ?? throw new ArgumentNullException(nameof(baselineRepository));
            _servicePackCompatibilityResolver = servicePackCompatibilityResolver ?? throw new ArgumentNullException(nameof(servicePackCompatibilityResolver));
        }

		public ProductUpdateResponse.Node? TranslateNode(BaseCanNode node, HpcHardwareSnapshot hardwareSnapshot = null, List<RepoLibIdentifierLink> repoLibIdentifiers = null, IProduct productSpec = null)
		{
			if (node.NodeDefinition.LogicalEcuDefinition != null &&
				node.NodeDefinition.LogicalEcuDefinition.HasExecutionEnvironment)
				return TranslateHpcNodeAsync(node, hardwareSnapshot, repoLibIdentifiers, productSpec).GetAwaiter().GetResult();
			if (node is Tea2PlusNode tea2PlusNode)
				return TranslateTea2PlusNode(tea2PlusNode);

			return null;
		}

		public ProductUpdateResponse.Node? TranslateNodeWithoutCanNode(HpcNode node, HpcHardwareSnapshot hardwareSnapshot = null, List<RepoLibIdentifierLink> repoLibIdentifiers = null, IProduct productSpec = null)
		{
			if ((node.ExecutionEnvironments != null && node.ExecutionEnvironments.Any()) && (node.Tea2PlusNodes == null || !node.Tea2PlusNodes.Any()))
				return TranslateNodeWithoutCanNodeAsync(node, hardwareSnapshot, repoLibIdentifiers, productSpec).GetAwaiter().GetResult();
			else
				return null;
		}

		#region HPC Node Translation

		private async Task<ProductUpdateResponse.Node> TranslateHpcNodeAsync(BaseCanNode node, HpcHardwareSnapshot hardwareSnapshot, List<RepoLibIdentifierLink> repoLibIdentifiers, IProduct productSpec)
		{
			if (node is not Tea2PlusNode virtualTea2PlusNode)
			{
				Serilog.Log.Warning($"Node with LogicalEcuDefinition is not Tea2PlusNode: {node.GetType().Name}");
				return null;
			}

			var logicalEcuDef = virtualTea2PlusNode.NodeDefinition.LogicalEcuDefinition as NodeNameLogicalEcuDefinition;

			if (logicalEcuDef == null)
			{
				Serilog.Log.Warning($"HpcNode does not have valid NodeNameLogicalEcuDefinition");
				return null;
			}

			NodeName nodeName = logicalEcuDef.NodeName;
			if (nodeName == null)
			{
				Serilog.Log.Warning($"HpcNode does not have valid NodeName");
				return null;
			}

			var (hasAnySoftwareProductsForEE, executionEnvironments) = await BuildExecutionEnvironmentsAsync(
			   logicalEcuDef.ExecutionEnvironments,
			   repoLibIdentifiers,
			   productSpec).ConfigureAwait(false);

			var hpcNode = logicalEcuDef.CreateHpcNode(
				tea2PlusNodes: new[] { virtualTea2PlusNode },
				executionEnvironments: executionEnvironments,
				nodeIdentification: logicalEcuDef.ToNodeIdentification(),
				nodeDefinition: logicalEcuDef,
				source: virtualTea2PlusNode.Source,
				hardwareNode: null
			);

			var hpcNodeData = ProductUpdateResponse.HpcNode.Create(
				CreateEcuHardwareForHpc(hpcNode, hardwareSnapshot),
				CreateExecutionEnvironments(hpcNode.ExecutionEnvironments),
				CreateNodeName(nodeName),
				CreateSubHardwaresForHpc(hpcNode, hardwareSnapshot),
				CreateVirtualTea2PlusNodes(hpcNode.Tea2PlusNodes)
			);

			return ProductUpdateResponse.Node.Create(hpcNode: hpcNodeData);
		}

		 private async Task<ProductUpdateResponse.Node> TranslateNodeWithoutCanNodeAsync(HpcNode hpcNode, HpcHardwareSnapshot hardwareSnapshot, List<RepoLibIdentifierLink> repoLibIdentifiers, IProduct productSpec)
		 {
			if (hpcNode.NodeIdentification is not NodeName nodeNameIdentification)
			{
				Serilog.Log.Warning($"HpcNode : {hpcNode.GetType().Name} does not have valid NodeName.");
				return null;
			}

			NodeName nodeName = new NodeName(
				nodeNameIdentification.Family,
				nodeNameIdentification.Type,
				nodeNameIdentification.Position,
				nodeNameIdentification.Name);

			var (hasAnySoftwareProductsForEE, executionEnvironments) = await BuildExecutionEnvironmentsAsync(
				hpcNode.ExecutionEnvironments,
				repoLibIdentifiers,
				productSpec).ConfigureAwait(false);

			if (!hasAnySoftwareProductsForEE)
			{
				Serilog.Log.Warning($"HpcNode : {hpcNode.GetType().Name} is not HPCNodeWithoutCanNode");
				return null;
			}

			var hpcNodeData = ProductUpdateResponse.HpcNode.Create(
				CreateEcuHardwareForHpc(hpcNode, hardwareSnapshot),
				CreateExecutionEnvironments(hpcNode.ExecutionEnvironments),
				CreateNodeName(nodeName),
				CreateSubHardwaresForHpc(hpcNode, hardwareSnapshot),
				CreateVirtualTea2PlusNodes(hpcNode.Tea2PlusNodes)
			);

			return ProductUpdateResponse.Node.Create(hpcNode: hpcNodeData);
		}

		private async Task<IList<SoftwareProduct>> EvaluateAllSoftwareProductsFromRepoLibAsync(IList<string> repoLibPackages, IProduct productSpec)
		{
			if (repoLibPackages == null || !repoLibPackages.Any())
				return new List<SoftwareProduct>();

			try
			{
				// Evaluate software products using RepoLib eval service
				var softwareProductRepoLinks = await _evalService
					.EvaluateSoftwareProductsAsync(repoLibPackages, productSpec.ProductSpecification)
					.ConfigureAwait(false);

				// Convert to SoftwareProduct objects
				var softwareProducts = ConvertToSoftwareProduct(
					softwareProductRepoLinks.Select(x => x.Value)
				);

				return softwareProducts;
			}
			catch (Exception ex)
			{
				Serilog.Log.Error(ex, "Failed to evaluate software products from RepoLib");
				return new List<SoftwareProduct>();
			}
		}

		private IList<SoftwareProduct> ConvertToSoftwareProduct(IEnumerable<SoftwareProductConditionalEntity> repoLinks)
		{
			if (repoLinks == null || !repoLinks.Any())
				return new List<SoftwareProduct>();

			var softwareProducts = new List<SoftwareProduct>();
			var allSoftwareProductEntities = repoLinks.ToList();

			// Group all available SoftwareProducts by Name and Deployer
			var groupedSoftwareProducts = allSoftwareProductEntities
				.GroupBy(sp => new { sp.Name, sp.Deployer })
				.ToList();

			foreach (var groupedSoftwareProduct in groupedSoftwareProducts)
			{
				try
				{
					// Take the first entity from the group as the representative
					var softwareConditionalEntity = groupedSoftwareProduct.First();

					var softwareProduct = new SoftwareProduct(softwareConditionalEntity);

					softwareProducts.Add(softwareProduct);
				}
				catch (Exception ex)
				{
					var entityName = groupedSoftwareProduct.FirstOrDefault()?.Name ?? "Unknown";
					Serilog.Log.Error(ex, $"Failed to convert RepoLib entity to SoftwareProduct: {entityName}");
				}
			}

			return softwareProducts;
		}

		private ProductUpdateResponse.Tea2PlusEcuHardwareExtended CreateEcuHardwareForHpc(HpcNode hpcNode, HpcHardwareSnapshot hardwareSnapshot)
		{
			var hardwarePartNumber = 0;
			var compatibleHardware = Enumerable.Empty<int>();

			if (hpcNode != null)
			{
				if (hardwareSnapshot != null &&
					hardwareSnapshot.HardwarePartNumbers?.Count > 0 &&
					hardwareSnapshot.HardwarePartNumbers.Any(x => !string.IsNullOrEmpty(x)))
				{
					// Get the first valid hardware part number from the list
					var validHwPn = hardwareSnapshot.HardwarePartNumbers
						.FirstOrDefault(x => !string.IsNullOrEmpty(x) && int.TryParse(x, out var pn) && pn > 0);

					if (!string.IsNullOrEmpty(validHwPn) && int.TryParse(validHwPn, out var snapshotHwPn))
					{
						hardwarePartNumber = snapshotHwPn;
						Serilog.Log.Debug($"Using HPC hardware snapshot for node {hardwareSnapshot.NodeName}: PN={hardwarePartNumber}");
					}
				}

				if (hardwarePartNumber == 0)
				{
					hardwarePartNumber = hpcNode.Hardware?.ArtifactVersion?.PartNumber ?? 0;
				}

				compatibleHardware = _slotTranslator.GetCompatibleHardware(hpcNode);
			}

			return Create(VolvoPartNumber.Parse($"\"{hardwarePartNumber}\""),
				VolvoPartNumberArray.FromRange(compatibleHardware.Select(pn => VolvoPartNumber.Parse($"\"{pn}\"")))
			);
		}

		private ProductUpdateResponse.HpcNode.Tea2PlusEcuHardwareArray CreateSubHardwaresForHpc(HpcNode hpcNode, HpcHardwareSnapshot hardwareSnapshot)
		{
			if (hardwareSnapshot != null &&
				hardwareSnapshot.SubHardwarePartNumbers?.Count > 0 &&
				hardwareSnapshot.SubHardwarePartNumbers.Any(x => !string.IsNullOrEmpty(x)))
			{
				var snapshotSubHardwares = hardwareSnapshot.SubHardwarePartNumbers
					.Where(x => !string.IsNullOrEmpty(x) && int.TryParse(x, out var pn) && pn > 0)
					.Select(x =>
					{
						int.TryParse(x, out var snapshotSubHwPn);
						Serilog.Log.Debug($"Using HPC sub-hardware snapshot for node {hardwareSnapshot.NodeName}: SubPN={snapshotSubHwPn}");
						return Tea2PlusEcuHardware.Create(
							VolvoPartNumber.Parse($"\"{snapshotSubHwPn}\""));
					})
					.ToList();

				if (snapshotSubHardwares.Any())
				{
					return ProductUpdateResponse.HpcNode.Tea2PlusEcuHardwareArray.FromRange(snapshotSubHardwares);
				}
			}

			// Fallback to node sub-hardware
			var subHardwares = hpcNode.SubHardware?
				.Where(sh => sh?.ArtifactVersion != null && !sh.IsEmpty)
				.Select(sh => Tea2PlusEcuHardware.Create(
					VolvoPartNumber.Parse($"\"{sh.ArtifactVersion.PartNumber ?? 0}\"")))
				?? Enumerable.Empty<Tea2PlusEcuHardware>();

			return ProductUpdateResponse.HpcNode.Tea2PlusEcuHardwareArray.FromRange(subHardwares);
		}

		private ProductUpdateResponse.HpcNode.ExecutionEnvironmentArray CreateExecutionEnvironments(
			IList<ExecutionEnvironment> executionEnvironments)
		{
			if (executionEnvironments == null || !executionEnvironments.Any())
				return ProductUpdateResponse.HpcNode.ExecutionEnvironmentArray.FromRange(
					Enumerable.Empty<ProductUpdateResponse.ExecutionEnvironment>());

			var eeList = executionEnvironments.Select(CreateExecutionEnvironment);

			return ProductUpdateResponse.HpcNode.ExecutionEnvironmentArray.FromRange(eeList);
		}

		private ProductUpdateResponse.ExecutionEnvironment CreateExecutionEnvironment(ExecutionEnvironment ee)
		{
			return ProductUpdateResponse.ExecutionEnvironment.Create(
				CreateAllowedTspkiCertificateTypes(ee),
				CreateNestedExecutionEnvironments(ee.ExecutionEnvironments),
				CreateNodeName(ee.NodeName),
				CreateSoftwareProducts(ee.SoftwareProducts)
			);
		}

		private ProductUpdateResponse.ExecutionEnvironment.SoftwareProductArray CreateSoftwareProducts(
			List<BreakdownDomain.Model.Parts.SoftwareProduct> softwareProducts)
		{
			if (softwareProducts == null || !softwareProducts.Any())
				return ProductUpdateResponse.ExecutionEnvironment.SoftwareProductArray.FromRange(
					Enumerable.Empty<ProductUpdateResponse.SoftwareProduct>());

			var spList = softwareProducts.Select(sp => _slotTranslator.TranslateSoftwareProduct(sp));

			return ProductUpdateResponse.ExecutionEnvironment.SoftwareProductArray.FromRange(spList);
		}

		private ProductUpdateResponse.ExecutionEnvironment.ExecutionEnvironmentArray CreateNestedExecutionEnvironments(
			List<ExecutionEnvironment> executionEnvironments)
		{
			if (executionEnvironments == null || !executionEnvironments.Any())
				return ProductUpdateResponse.ExecutionEnvironment.ExecutionEnvironmentArray.FromRange(
					Enumerable.Empty<ProductUpdateResponse.ExecutionEnvironment>());

			var eeList = executionEnvironments.Select(ee => CreateExecutionEnvironment(ee));

			return ProductUpdateResponse.ExecutionEnvironment.ExecutionEnvironmentArray.FromRange(eeList);
		}

		private ProductUpdateResponse.ExecutionEnvironment.JsonStringArray CreateAllowedTspkiCertificateTypes(
			ExecutionEnvironment ee)
		{
			var certificates = string.IsNullOrEmpty(ee.AllowedTspkiCertificates)
				? Enumerable.Empty<string>()
				: ee.AllowedTspkiCertificates.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

			return ProductUpdateResponse.ExecutionEnvironment.JsonStringArray.FromRange(certificates.Select(cert => (JsonString)cert));
		}

		private ProductUpdateResponse.HpcNode.VirtualTea2PlusNodeArray CreateVirtualTea2PlusNodes(
			IList<Tea2PlusNode> tea2PlusNodes)
		{
			if (tea2PlusNodes == null || !tea2PlusNodes.Any())
				return ProductUpdateResponse.HpcNode.VirtualTea2PlusNodeArray.FromRange(
					Enumerable.Empty<ProductUpdateResponse.VirtualTea2PlusNode>());

			var vnodeList = tea2PlusNodes
				.Select(vnode => CreateVirtualTea2PlusNode(vnode))
				.Where(vnode => vnode.HasValue)
				.Select(vnode => vnode.Value);

			return ProductUpdateResponse.HpcNode.VirtualTea2PlusNodeArray.FromRange(vnodeList);
		}

		private ProductUpdateResponse.VirtualTea2PlusNode? CreateVirtualTea2PlusNode(Tea2PlusNode vnode)
		{
			var nodeName = vnode.NodeName;
			if (nodeName == null)
				return null;

			return ProductUpdateResponse.VirtualTea2PlusNode.Create(
				CreateVirtualComplementarySoftwares(vnode.ComplementarySoftwares),
				CreateVirtualDatas(vnode.Data),
				_slotTranslator.TranslateMainSoftware(vnode.MainSoftware),
				CreateNodeName(nodeName),
				VolvoPartNumber.Parse($"\"{vnode.DocumentNumber}\""),
				CreateParentNode(nodeName),
				$"/{nodeName.Family}.{nodeName.Type}.{nodeName.Position}/",
				_slotTranslator.TranslatePrimaryBootloader(vnode.PrimaryBootLoader),
				_slotTranslator.TranslateSecondaryBootloader(vnode.SecondaryBootLoader)
			);
		}

		private ParentNode CreateParentNode(NodeName parentNode)
		{
			var jsonNodeName = CreateNodeName(parentNode);
			var nodeNameEntity = ParentNode.NodeNameEntity.FromAny(jsonNodeName.AsAny);

			return ParentNode.Create(nodeNameEntity);
		}

        private async Task<(bool hasSoftwareProductsForEE, IList<ExecutionEnvironment> ExecutionEnvironments)> BuildExecutionEnvironmentsAsync(
            IEnumerable<ExecutionEnvironmentDefinition> execEnvsDefinitions,
            List<RepoLibIdentifierLink> repoLibIdentifiers,
            IProduct productSpec)
        {
            Boolean hasSoftwareProductsForExecutionEnvironment = false;

            // Step 1: Fetch RepoLib package for the identifiers linked to service packs
            var (repoLibPackages, _, _) = await _servicePackCompatibilityResolver.ExpandRepoLibEntitiesAsync(
                      repoLibIdentifiers,
                      _baselineRepository).ConfigureAwait(false);

            // Step 2: Evaluate all software products from RepoLib
            var allSoftwareProducts = await EvaluateAllSoftwareProductsFromRepoLibAsync(repoLibPackages.Distinct().ToList(), productSpec).ConfigureAwait(false);

            // Step 4: Create and populate execution environments with matching software products
            var executionEnvironments = new List<ExecutionEnvironment>();

            foreach (var exEnvDef in execEnvsDefinitions)
            {
                var executionEnvironment = new ExecutionEnvironment(
                    exEnvDef.Family,
                    exEnvDef.Type,
                    exEnvDef.Name,
                    exEnvDef.Parent)
                {
                    Parent = exEnvDef.ParentNode
                };

                var matchingSoftwareProducts = allSoftwareProducts
                    .Where(sp => sp.ExecutionEnvironment != null
                        && sp.ExecutionEnvironment.Family == executionEnvironment.Family
                        && sp.ExecutionEnvironment.Type == executionEnvironment.Type)
                    .ToList();

                if (matchingSoftwareProducts.Any())
                {
                    hasSoftwareProductsForExecutionEnvironment = true;
                    executionEnvironment.SoftwareProducts = matchingSoftwareProducts;
                    executionEnvironments.Add(executionEnvironment);
                }
            }

            return (hasSoftwareProductsForExecutionEnvironment, executionEnvironments);
        }
        #endregion

        #region Tea2Plus Node Translation

        private ProductUpdateResponse.Node TranslateTea2PlusNode(Tea2PlusNode tea2PlusNode)
		{
			var nodeName = tea2PlusNode.NodeName;
			if (nodeName == null)
			{
				Serilog.Log.Warning($"Tea2PlusNode does not have valid NodeName");
				return default;
			}

			var nodeData = ProductUpdateResponse.Tea2PlusNode.Create(
				CreateComplementarySoftwares(tea2PlusNode.ComplementarySoftwares),
				CreateDatas(tea2PlusNode.Data),
				CreateEcuHardwareForTea2Plus(tea2PlusNode),
				_slotTranslator.TranslateMainSoftware(tea2PlusNode.MainSoftware),
				CreateNodeName(nodeName),
				VolvoPartNumber.Parse($"\"{tea2PlusNode.DocumentNumber}\""),
				CreateParentNode(nodeName),
				$"/{nodeName.Family}.{nodeName.Type}.{nodeName.Position}/",
				_slotTranslator.TranslatePrimaryBootloader(tea2PlusNode.PrimaryBootLoader),
				_slotTranslator.TranslateSecondaryBootloader(tea2PlusNode.SecondaryBootLoader),
				CreateSubHardwaresForTea2Plus(tea2PlusNode)
			);

			return ProductUpdateResponse.Node.Create(tea2PlusNode: nodeData);
		}

		private ProductUpdateResponse.Tea2PlusEcuHardwareExtended CreateEcuHardwareForTea2Plus(Tea2PlusNode node)
		{
			var hardwarePartNumber = node.Hardware?.ArtifactVersion?.PartNumber ?? 0;
			var compatibleHardware = _slotTranslator.GetCompatibleHardware(node);

			return Create(
				VolvoPartNumber.Parse($"\"{hardwarePartNumber}\""),
				VolvoPartNumberArray.FromRange(
					compatibleHardware.Select(pn => VolvoPartNumber.Parse($"\"{pn}\""))
				)
			);
		}

		private ProductUpdateResponse.Tea2PlusNode.Tea2PlusEcuHardwareExtendedArray CreateSubHardwaresForTea2Plus(Tea2PlusNode node)
		{
			var subHardwares = node.SubHardware?
				.Where(sh => sh?.ArtifactVersion != null && !sh.IsEmpty
				&& sh.ArtifactVersion.PartNumber.HasValue
				&& sh.ArtifactVersion.PartNumber.Value > 0)
				.Select(sh => Create(VolvoPartNumber.Parse($"\"{sh.ArtifactVersion.PartNumber ?? 0}\"")))
				?? Enumerable.Empty<ProductUpdateResponse.Tea2PlusEcuHardwareExtended>();

			return ProductUpdateResponse.Tea2PlusNode.Tea2PlusEcuHardwareExtendedArray.FromRange(subHardwares);
		}

		private ProductUpdateResponse.VirtualTea2PlusNode.ComplementarySoftwareArray CreateComplementarySoftwares(
			IList<BreakdownDomain.Model.Slot.Tea2PlusComplementarySoftwareSlot> complementarySoftwares)
		{
			var csList = complementarySoftwares?
				.Where(cs => cs != null && !cs.IsEmpty)
				.Select(_slotTranslator.TranslateComplementarySoftware).ToList()
				?? Enumerable.Empty<ProductUpdateResponse.ComplementarySoftware>();

			return ProductUpdateResponse.VirtualTea2PlusNode.ComplementarySoftwareArray.From(
				csList.Select(cs => cs.AsAny).ToImmutableList());
		}

		private ProductUpdateResponse.VirtualTea2PlusNode.ComplementarySoftwareArray CreateVirtualComplementarySoftwares(
			IList<BreakdownDomain.Model.Slot.Tea2PlusComplementarySoftwareSlot> complementarySoftwares)
		{
			var csList = complementarySoftwares?
				.Where(cs => cs != null && !cs.IsEmpty)
				.Select(_slotTranslator.TranslateComplementarySoftware).ToList()
				?? Enumerable.Empty<ProductUpdateResponse.ComplementarySoftware>();

			return ProductUpdateResponse.VirtualTea2PlusNode.ComplementarySoftwareArray.From(
				csList.Select(cs => cs.AsAny).ToImmutableList());
		}

		private ProductUpdateResponse.VirtualTea2PlusNode.DataArray CreateDatas(
			IList<BreakdownDomain.Model.Slot.Tea2PlusDataSlot> datas)
		{
			var dataList = datas?
				.Where(d => d != null && !d.IsEmpty)
				.Select(_slotTranslator.TranslateData).ToList()
				?? Enumerable.Empty<ProductUpdateResponse.Data>();

			return ProductUpdateResponse.VirtualTea2PlusNode.DataArray.From(
				dataList.Select(d => d.AsAny).ToImmutableList());
		}

		private ProductUpdateResponse.VirtualTea2PlusNode.DataArray CreateVirtualDatas(
			IList<BreakdownDomain.Model.Slot.Tea2PlusDataSlot> datas)
		{
			var dataList = datas?
				.Where(d => d != null && !d.IsEmpty)
				.Select(_slotTranslator.TranslateData).ToList()
				?? Enumerable.Empty<ProductUpdateResponse.Data>();

			return ProductUpdateResponse.VirtualTea2PlusNode.DataArray.From(
				dataList.Select(d => d.AsAny).ToImmutableList());
		}

		#endregion

		#region Helper Methods

		private JsonNodeName CreateNodeName(NodeName nodeName)
		{
			return JsonNodeName.Create(
				nodeName.Family,
				nodeName.Type,
				nodeName.Position
			);
		}

		#endregion
	}
}