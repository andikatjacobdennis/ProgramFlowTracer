# Lower-risk variant — paste onto the dev machine

This replaces the `Intersect` → `Union` change with something far easier to defend, **without
changing the outcome**. Everything else in your current branch stays exactly as it is.

---

## The one file that matters

```
BreakdownDomain/BreakdownDomain.Services/SoftwareUpgradeService.cs
```

Paste it over the file of the same name. That is the whole essential change.

### What it does instead of Union

`Intersect` comes back, and the only difference from the original code is that a node reaching
**zero** service packs is skipped rather than intersected in:

```csharp
if (servicePackReferencesFromChain.Count == 0)
{
    continue;
}
```

A node that reaches no service pack at all takes no part in service packs — the HPC-derived VCM
nodes get their software from RepoLib packages, not from chain-connected node templates. Their empty
list was emptying the result for the whole vehicle. Every node that *does* take part still has to
reach a pack for that pack to be offered, which is the rule this method has always applied.

### Why this is safer than Union

**Union widened candidate selection for every request in the system. This doesn't widen it at all.**

- A vehicle where every node participates → `Intersect` behaves exactly as before. **Zero behavioural
  change.** That is most of the fleet, and it's the case the reviewer is worried about.
- A vehicle with HPC-derived nodes → the empty list no longer destroys the result.

Nothing is ever *added* to the candidate list that wasn't there before. The change can only prevent a
list from being wrongly emptied.

### And it gives the same answer

The trace from chassis NR-999222 shows Union surfaced five candidates and then rejected three of
them:

```
Version5 (526670) sortOrder=11   rejected — node 9.1.0 EBS
Version4 (526619) sortOrder=10   rejected — node 9.1.0 EBS
Version3 (521458) sortOrder=4    rejected — node 9.1.0 EBS
Version2 (521444) sortOrder=3    ACCEPTED
```

The three rejected are precisely the three EBS cannot reach. Under the participating-node
intersection they are never candidates in the first place — EBS participates, so a pack it can't
reach is excluded up front instead of being attempted and thrown out.

**Result: `Version2` either way, three doomed breakdown attempts avoided.**

That is the argument worth making to the reviewer: under the `servicePackNodeDefinitions` scoping
that ships alongside this, *any* pack Union added beyond this intersection is guaranteed to be
rejected downstream, because a participating node vetoes it. Union was doing work that could never
change the answer.

### If the data gap is fixed later

If node 9.1 EBS is linked to Version4 as QA expects, Version4 lands **inside** the intersection and
is tried first on `SortOrder`. The fallback QA wants works without needing Union at all.

---

## Optional — two one-line fixes

In `optional/`. Neither changes behaviour; both remove a blocking call inside an `async` method that
already awaits on the next line, which risks thread starvation under load.

| File | Paste over |
|---|---|
| `optional/BreakdownDomain.Services/ServicePackCompatibilityResolver.cs` | `BreakdownDomain/BreakdownDomain.Services/ServicePackCompatibilityResolver.cs` |
| `optional/Request.Listener/NodeTranslator.cs` | `GatewayComponents/Request.Listener/Aftermarket/ProductUpdateService_1_0/Translators/NodeTranslator.cs` |

```diff
- var (repoLibPackages, sibBaselines, duplicatePackages) = ExpandRepoLibEntitiesAsync(...)
-     .GetAwaiter().GetResult();
+ var (repoLibPackages, _, _) = await ExpandRepoLibEntitiesAsync(...).ConfigureAwait(false);
```

The `_, _` also clears two unused-variable warnings. The resolver copy additionally completes a
comment that was truncated mid-word (`// Step 1: Fetch RepoLib pa`).

Skip these if you'd rather keep the diff to one file — they are genuinely independent.

---

## What is NOT in this zip, and stays as-is on your machine

These are unchanged and still needed. Don't revert them:

| Change | Why it stays |
|---|---|
| `ServicePackUpdater` — `nodesTakingPartInServicePacks` scoping | Stops the HPC-derived nodes vetoing every candidate. Required; without it the filter still rejects everything for VCM_C. |
| `ServicePackReplacementChainFilter` — SIB document-number route | Purely additive. An empty set means behaviour identical to before. |
| `ServicePackCompatibilityResolver` — `GetSibDocumentNumbersAsync`, `ExpandRepoLibEntitiesAsync` | Additive: finds node templates and products that were previously invisible. Nothing is lost. |
| `NodeTranslator` — SIB expansion | Additive: SIB-delivered software reaches the response instead of being silently dropped. |
| `ConfiguratorProductUpdater` — applied-pack propagation | Straight bug fix. The reply named a pack the truck was never updated to. |
| DI registrations | Wiring for the above. |

---

## Risk summary after this swap

| Change | Risk | Why |
|---|---|---|
| Participating-node intersection | **Low** | Cannot add candidates. No effect where all nodes participate. |
| Node-definition scoping | **Low** | Where all nodes participate, the governed set is unchanged. |
| SIB routes and resolution | **Low** | Additive; empty inputs give the old behaviour exactly. |
| Applied-pack propagation | **Low** | Reports what was applied instead of re-deriving it. |
| NodeTranslator expansion | **Medium-low** | More products reach the response. Additive, but it changes response content. |

The regression concern raised on `Union` — that packs previously never offered would now be
attempted — **no longer applies.** Nothing is offered that wasn't offered before.

---

## Verify after pasting

1. Re-run the NR-999222 `PreReleaseVerification` request with the client timeout at **125**, not 45.
2. Expect `servicePack` = `B1_T3_CVSU_SWB_Test_Nan_Version2` (`521444`) — the same answer as now.
3. Expect **fewer** "Trying service pack …" attempts in the log: Version5, Version4 and Version3
   should no longer be attempted at all.
4. Sanity-check one non-HPC vehicle and confirm the result is unchanged from before any of this work.
