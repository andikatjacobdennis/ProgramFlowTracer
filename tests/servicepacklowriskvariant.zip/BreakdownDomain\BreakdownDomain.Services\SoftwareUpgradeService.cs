﻿using System;
using System.Collections.Generic;
using System.Linq;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Baseline;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.BuilderInterfaces;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Component;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Configuration;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ConversionKit;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Dependencies;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Node;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.NodeTemplate;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Notifications;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ProductDefinition;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Relations;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ReplacementChains;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.RepositoryInterfaces;

namespace Volvo.SoftwareBreakdown.BreakdownDomain.Services
{
    public class SoftwareUpgradeService : ISoftwareUpgradeService
    {
        private readonly INodeTemplateRepository _nodeTemplateRepository;
        private readonly INodeTemplateBuilder _nodeTemplateBuilder;

        public SoftwareUpgradeService(INodeTemplateRepository nodeTemplateRepository,
            INodeTemplateBuilder nodeTemplateBuilder)
        {
            _nodeTemplateRepository = nodeTemplateRepository;
            _nodeTemplateBuilder = nodeTemplateBuilder;
        }

        public IDictionary<SoftwareChainIdentifier, IEnumerable<NodeTemplateReplacementChainReference>>
            GetReplacementChains(IProduct product, IEnumerable<BaseCanNode> nodes,
                IDictionary<BaseNodeIdentification, BaseNodeIdentification> crossBorderRequestedNodes)
        {
            var replacementChainContainer = _nodeTemplateRepository.LoadReplacementChainsAsync().GetAwaiter().GetResult();
            var notFoundNodes = new List<Tuple<int, BaseCanNode>>();
            var replacementChains = new Dictionary<SoftwareChainIdentifier, IEnumerable<NodeTemplateReplacementChainReference>>();

            foreach (var node in nodes.Where(n => n.DocumentNumber > 0))
            {
                var crossBorders = crossBorderRequestedNodes.ContainsKey(node.NodeIdentification);

                var documentNumbers = node.GetAllDocumentNumbersAfterKitAssignedSubTemplate(replacementChainContainer);

                foreach (var documentNumber in documentNumbers)
                {
                    var replacementChain = replacementChainContainer.GetReplacementChainFromDocumentNumber(documentNumber, crossBorders).ToList();

                    if (replacementChain.Any())
                    {
                        var softwareChain = new SoftwareChainIdentifier(node.NodeIdentification.WithProduct(product),
                            replacementChain.Select(rc => rc.SoftwareReplacementChain.TemplateType).FirstOrDefault());

                        if (!replacementChains.ContainsKey(softwareChain))
                            replacementChains.Add(softwareChain, replacementChain);
                    }

                    if (!replacementChain.Any())
                    {
                        notFoundNodes.Add(new Tuple<int, BaseCanNode>(documentNumber, node));
                    }
                }
            }

            if (notFoundNodes.Count > 0)
            {
                var notifications =
                    notFoundNodes.ConvertAll(
                        notFoundNode =>
                            new NodeTemplateUnknown(notFoundNode.Item1, notFoundNode.Item2.NodeIdentification.ToString()))
;

                throw new NotificationException(notifications);
            }

            return replacementChains;
        }

        public IDictionary<SoftwareChainIdentifier, IEnumerable<NodeTemplateReplacementChainReference>>
            GetReplacementChainsForCurrentlyUnusedTemplateTypes(IProduct product, IEnumerable<BaseCanNode> nodes,
                IList<TemplateType> usedTemplateTypes)
        {
            var replacementChainContainer = _nodeTemplateRepository.LoadReplacementChainsAsync().GetAwaiter().GetResult();
            var replacementChains =
                new Dictionary<SoftwareChainIdentifier, IEnumerable<NodeTemplateReplacementChainReference>>();

            foreach (var node in nodes.Where(n => n.DocumentNumber > 0))
            {
                var chainHeads = replacementChainContainer.GetPrioritizedChainHeadsForNodeDefinition(node.NodeDefinition, product.BillOfMaterial.Context.Id).ToList();

                var otherTemplateTypes = chainHeads.Select(ch => ch.SoftwareReplacementChain.TemplateType).Distinct().Except(usedTemplateTypes).ToList();

                foreach (var otherTemplateType in otherTemplateTypes)
                {
                    var softwareChain = new SoftwareChainIdentifier(node.NodeIdentification.WithProduct(product), otherTemplateType);

                    var chainHeadsForOtherTemplateType =
                        chainHeads.Where(ch => ch.SoftwareReplacementChain.TemplateType.Equals(otherTemplateType));

                    var replacementChainsForOtherTemplateType =
                        chainHeadsForOtherTemplateType.Select(
                            ch =>
                                replacementChainContainer.GetReplacementChainFromDocumentNumber(ch.DocumentNumber));

                    var replacementChain = new List<NodeTemplateReplacementChainReference>();

                    foreach (var softwareChainSegment in replacementChainsForOtherTemplateType)
                    {
                        replacementChain.AddRange(softwareChainSegment.ToList());
                    }

                    replacementChains.Add(softwareChain, replacementChain);
                }
            }

            return replacementChains;
        }

        public void SetContext(Installation installation, IList<ProductClass> productClasses, IList<Context> contexts,
            IList<NodeTemplateIssue> nodeTemplates, bool ignoreNotifications)
        {
            var possibleContexts = contexts;

            foreach (var product in installation.Products)
            {
                var productContexts =
                    product.BillOfMaterial.CheckProductClassAndLimitPossibleContexts(product,
                        productClasses, contexts, false);

                possibleContexts = possibleContexts.Intersect(productContexts).ToList();
            }

            if (!installation.Products.Any())
            {
                return;
            }

            var productsWithoutNodes = !installation.Products.SelectMany(p => p.BillOfMaterial.Nodes.Where(n => n.HasMainSoftware && n.MainSoftwareArtifactVersion?.IsEmpty == false)).Any();

            installation.SetContext(installation.Products.First().ProductSpecification.ProductClassCode,
                possibleContexts, possibleContexts, nodeTemplates, productsWithoutNodes);
            var message = $"Context set to {installation.Products.First().BillOfMaterial.Context}.";
            Serilog.Log.Information(message);

            if (ignoreNotifications)
            {
                return;
            }

            var notifications = new List<BaseNotification>();
            foreach (var product in installation.Products)
            {
                if (product.BillOfMaterial?.Notifications != null)
                {
                    notifications.AddRange(product.BillOfMaterial.Notifications.Where(n => n.Severity == Severity.Error));
                }

                foreach (var node in product.BillOfMaterial.Nodes.Where(n => n.DocumentNumber > 0))
                {
                    var nodeTemplate = nodeTemplates.FirstOrDefault(ntp => ntp.DocumentNumber.Equals(node.DocumentNumber));
                    if (nodeTemplate?.DocumentNumber == 0)
                    {
                        continue;
                    }

                    if (nodeTemplate != null)
                    {
                        if (!nodeTemplate.TemplateType.NodeDefinition.Equals(node.NodeDefinition))
                        {
                            notifications.Add(new NodeTemplateWrongNode(nodeTemplate,
                                node.NodeDefinition.ToString(),
                                nodeTemplate.TemplateType.NodeDefinition.ToString()));
                        }
                        if (!nodeTemplate.Context.Equals(product.BillOfMaterial.Context))
                        {
                            notifications.Add(new NodeTemplateInvalidContext(nodeTemplate, node.NodeDefinition.ToString(),
                                nodeTemplate.Context, product.BillOfMaterial.Context));
                        }
                    }
                }
            }

            if (notifications.Count > 0)
            {
                throw new NotificationException(notifications);
            }
        }

        public IDictionary<SoftwareChainIdentifier, IBreakdownReplacementChain> BuildBreakdownReplacementChains(
            IProduct product,
            IDictionary<SoftwareChainIdentifier, IEnumerable<NodeTemplateReplacementChainReference>> replacementChains,
            IBreakdownReplacementChainFilter breakdownScenarioFilter,
            SoftwareRequestOperationType operationType,
            NotProgrammableInAftermarketScenario notProgrammableInAftermarketScenario,
            INonDownloadableTemplateContainer nonDownloadableTemplateContainer,
            IDictionary<int, NodeTemplate> nodeTemplates,
            IDictionary<string, DependencyContainer> releases,
            IDictionary<int, IKit> transitions,
            IRepositoryCarrier repositoryCarrier,
            bool buildChainWithUnknownStartingPoint)
        {
            var chainFilter = (operationType == SoftwareRequestOperationType.Update || operationType == SoftwareRequestOperationType.UpdateToServicePack)
                ? new UpdateScenarioFilter() as IBreakdownScenarioFilter
                : new RepairScenarioFilter();

            var replacementChainContainer = _nodeTemplateRepository.LoadReplacementChainsAsync().GetAwaiter().GetResult();

            var breakdownReplacementChains = new Dictionary<SoftwareChainIdentifier, IBreakdownReplacementChain>();

            foreach (var replacementChain in replacementChains)
            {
                var currentSoftwareChainIdentifier = replacementChain.Key;

                var currentDocumentNumbers = product.BillOfMaterial.Nodes.Single(n => n.NodeIdentification.Equals(currentSoftwareChainIdentifier.ProductNodeIdentification.NodeIdentification)).GetAllDocumentNumbersAfterKitAssignedSubTemplate(replacementChainContainer);

                var chainLinks = replacementChain.Value;
                if (operationType == SoftwareRequestOperationType.Refresh)
                {
                    chainLinks = CutChainDoNotAllowUpdate(chainLinks, currentDocumentNumbers);
                }
                var breakdownReplacementChain = new BreakdownReplacementChain(chainLinks, currentSoftwareChainIdentifier,
                    breakdownScenarioFilter,
                    chainFilter, product, nodeTemplates, releases,
                    transitions, nonDownloadableTemplateContainer, repositoryCarrier, replacementChainContainer, buildChainWithUnknownStartingPoint, notProgrammableInAftermarketScenario);

                breakdownReplacementChains.Add(replacementChain.Key, breakdownReplacementChain);
            }

            return breakdownReplacementChains;
        }

        private static IEnumerable<NodeTemplateReplacementChainReference> CutChainDoNotAllowUpdate(
            IEnumerable<NodeTemplateReplacementChainReference> chainLinks, IList<int> currentDocumentNumbers)
        {
            var newChainLinks = new List<NodeTemplateReplacementChainReference>();
            foreach (var chainLink in chainLinks)
            {
                newChainLinks.Add(chainLink);
                if (currentDocumentNumbers.Any(dn => chainLink.DocumentNumber.Equals(dn)))
                {
                    break;
                }
            }
            return newChainLinks;
        }

        public IQueueableConfiguration BuildInitialConfigurationQueue(Installation installation,
            IDictionary<SoftwareChainIdentifier, IBreakdownReplacementChain> breakdownReplacementChains,
            IWeightCalculator weightCalculator, bool excludeCurrentNodeTemplatesFromResult)
        {
            var replacementChainContainer = _nodeTemplateRepository.LoadReplacementChainsAsync().GetAwaiter().GetResult();
            var unpackagedNodeTemplates = new Dictionary<SoftwareChainIdentifier, IBreakdownReplacementChainLink>();
            var packagedNodeTemplateLists = new Dictionary<SoftwareChainIdentifier, IList<IBreakdownReplacementChainLink>>();

            foreach (var chain in breakdownReplacementChains)
            {
                var product = installation.Products.FirstOrDefault(p => chain.Key.ProductNodeIdentification.ForProduct(p));

                if (product != null)
                {
                    var node = product.BillOfMaterial.Nodes.FirstOrDefault(n => n.NodeIdentification.Equals(chain.Key.ProductNodeIdentification.NodeIdentification));
                    var nodeDocumentNumbers = node == null
                        ? new List<int>()
                        : node
                            .GetAllDocumentNumbersAfterKitAssignedSubTemplate(replacementChainContainer).ToList();

                    if (product.RequestMetadata.CurrentlyRequestedNodes.Contains(chain.Key.ProductNodeIdentification.NodeIdentification))
                    {
                        if (chain.Key.TemplateType.IsNodeRoot)
                        {
                            packagedNodeTemplateLists.Add(chain.Key, chain.Value.ChainLinks.ToList());
                        }
                        else
                        {
                            var nodeNodeTemplates = _nodeTemplateBuilder.GetItemsAsync(nodeDocumentNumbers).GetAwaiter().GetResult().Values;
                            if (nodeNodeTemplates.Any(ntp => ntp.Issues.First().TemplateType.Equals(chain.Key.TemplateType)))
                            {
                                packagedNodeTemplateLists.Add(chain.Key, chain.Value.ChainLinks.ToList());
                            }
                        }
                    }
                    else
                    {
                        var chainLink = chain.Value.ChainLinks.FirstOrDefault(cl => nodeDocumentNumbers.Any(dn => cl.DocumentNumber.Equals(dn)));

                        if (chainLink != null)
                        {
                            unpackagedNodeTemplates.Add(chain.Key, chainLink);
                        }
                    }
                }
            }

            packagedNodeTemplateLists = ReduceReplacementChains(packagedNodeTemplateLists);

            if (packagedNodeTemplateLists.Count > 0)
            {
                var emptyChains = packagedNodeTemplateLists.Where(l => l.Value.Count == 0).ToList();
                if (emptyChains.Count > 0)
                {
                    var message = "No valid configurations to consider. " + string.Concat(emptyChains.Select(c =>
                                      $"No node templates available for node {c.Key.ProductNodeIdentification.NodeIdentification} and template type {c.Key.TemplateType.Name} after removing withdrawn and not selectable node templates."));
                    throw new NotificationException(new NoValidConfiguration(false, message, ErrorCode.NoValidConfigurationsError));
                }

                var softwareChainIdentifiers = new List<SoftwareChainIdentifier>();
                var templateTypes = new List<TemplateType>();

                foreach (var product in installation.Products)
                {
                    softwareChainIdentifiers.AddRange(breakdownReplacementChains.Keys.Where(k =>
                        product.RequestMetadata.AllRequestedNodes.Any(rn =>
                            rn.Equals(k.ProductNodeIdentification.NodeIdentification))));

                    templateTypes.AddRange(product.BillOfMaterial.Nodes.SelectMany(n =>
                        n.KitAssignedSubTemplates.Select(kast => kast.Key)));
                }



                if (excludeCurrentNodeTemplatesFromResult)
                {
                    return new NodeTemplateSetConfigurationWrapper(new NodeTemplateSetConfiguration(
                        softwareChainIdentifiers.Select(n => n.ProductNodeIdentification).Distinct().ToList(),
                        unpackagedNodeTemplates,
                        new Dictionary<SoftwareChainIdentifier, IBreakdownReplacementChainLink>(),
                        packagedNodeTemplateLists, templateTypes,
                        weightCalculator),installation, new ConfigurationReducer());
                }
                else
                {
                    return new NodeTemplateSetConfiguration(
                        softwareChainIdentifiers.Select(n => n.ProductNodeIdentification).Distinct().ToList(),
                        unpackagedNodeTemplates,
                        new Dictionary<SoftwareChainIdentifier, IBreakdownReplacementChainLink>(),
                        packagedNodeTemplateLists, templateTypes,
                        weightCalculator);
                }
            }
            else
            {
                return new NodeTemplateConfiguration(new List<ProductNodeIdentification>(), unpackagedNodeTemplates, new Dictionary<SoftwareChainIdentifier, IBreakdownReplacementChainLink>(),
                    new List<IGrouping<ProductNodeDefinition, RelationInterfaceVersionInProduct>>(), weightCalculator);
            }
        }

        private static Dictionary<SoftwareChainIdentifier, IList<IBreakdownReplacementChainLink>> ReduceReplacementChains(
            IDictionary<SoftwareChainIdentifier, IList<IBreakdownReplacementChainLink>> packagedNodeTemplateLists)
        {
            return
                packagedNodeTemplateLists.Keys
                    .ToDictionary<SoftwareChainIdentifier, SoftwareChainIdentifier, IList<IBreakdownReplacementChainLink>>(
                        requestedNode => requestedNode,
                        requestedNode => packagedNodeTemplateLists[requestedNode].ToList());
        }

        public IEnumerable<ConfiguratorBaselineReference> GetAvailableBaselineReferences(Installation installation)
        {
            var baselineReferences = new List<ConfiguratorBaselineReference>();
            return baselineReferences;
        }

        public Tuple<IEnumerable<ServicePackReference>,
                IDictionary<ServicePackReference, Dictionary<ProductNodeIdentification, int>>>
            GetAvailableServicePackReferences(Installation installation)
        {
            var replacementChainContainer = _nodeTemplateRepository.LoadReplacementChainsAsync().GetAwaiter().GetResult();
            var servicePackReferences = new List<ServicePackReference>();
            var first = true;
            IDictionary<ServicePackReference, Dictionary<ProductNodeIdentification, int>> servicePackNodes = new Dictionary<ServicePackReference, Dictionary<ProductNodeIdentification, int>>();

            foreach (var product in installation.Products)
            {
                foreach (var node in product.BillOfMaterial.ServicePackNodes.Where(n => n.DocumentNumber > 0))
                {
                    var replacementChain =
                        replacementChainContainer.GetReplacementChainFromDocumentNumber(node.DocumentNumber, true);

                    var passedCurrent = false;
                    var servicePackReferencesFromChain = new List<ServicePackReference>();
                    foreach (var link in replacementChain)
                    {
                        if (link.DocumentNumber.Equals(node.DocumentNumber))
                        {
                            passedCurrent = true;
                        }

                        if (passedCurrent)
                        {
                            // Include if not included by supersession, but include by supersession if it is the current
                            servicePackReferencesFromChain =
                                servicePackReferencesFromChain.Union(link.ConnectedServicePacks
                                    .Where(sp =>
                                        link.DocumentNumber.Equals(node.DocumentNumber) || !sp.IncludedBySupersession)
                                    .Select(sp => sp.ServicePackReference)).ToList();

                            AddNodesToServicePack(servicePackNodes, link, node.DocumentNumber, node.NodeIdentification.WithProduct(product));
                        }
                    }

                    // A node that reaches no service pack at all takes no part in service packs: the
                    // HPC derived nodes get their software from RepoLib packages rather than from
                    // chain connected node templates. Intersecting its empty list in emptied the
                    // result for the whole vehicle, so it is skipped here. Every node that does take
                    // part still has to reach a pack for that pack to be offered, which is the rule
                    // this method has always applied.
                    if (servicePackReferencesFromChain.Count == 0)
                    {
                        continue;
                    }

                    if (first)
                    {
                        servicePackReferences = servicePackReferencesFromChain;
                        first = false;
                    }
                    else
                    {
                        servicePackReferences = servicePackReferences.Intersect(servicePackReferencesFromChain).ToList();
                    }
                }
            }

            Serilog.Log.Information(
                "Service pack lookup finished: {Count} candidate service pack(s): {ServicePacks}.",
                servicePackReferences.Count,
                string.Join(", ", servicePackReferences.Select(sp => $"{sp.Name} ({sp.Id})")));

            return new Tuple<IEnumerable<ServicePackReference>,
                IDictionary<ServicePackReference, Dictionary<ProductNodeIdentification, int>>>(servicePackReferences, servicePackNodes);
        }

        private static void AddNodesToServicePack(
            IDictionary<ServicePackReference, Dictionary<ProductNodeIdentification, int>> servicePackNodes,
            NodeTemplateReplacementChainReference link, int currentDocumentNumber,
            ProductNodeIdentification productNodeIdentification)
        {
            foreach (var linkConnectedServicePack in link.ConnectedServicePacks)
            {
                if (link.DocumentNumber.Equals(currentDocumentNumber) || !linkConnectedServicePack.IncludedBySupersession)
                {
                    if (servicePackNodes.ContainsKey(linkConnectedServicePack.ServicePackReference))
                    {
                        var value = servicePackNodes[linkConnectedServicePack.ServicePackReference];
                        if (value == null)
                        {
                            servicePackNodes[linkConnectedServicePack.ServicePackReference] = new Dictionary<ProductNodeIdentification, int>();
                        }
                    }
                    else
                    {
                        servicePackNodes.Add(linkConnectedServicePack.ServicePackReference, new Dictionary<ProductNodeIdentification, int>());
                    }

                    if (servicePackNodes[linkConnectedServicePack.ServicePackReference].ContainsKey(productNodeIdentification))
                    {
                        if (!servicePackNodes[linkConnectedServicePack.ServicePackReference]
                                [productNodeIdentification].Equals(currentDocumentNumber))
                        {
                            servicePackNodes[linkConnectedServicePack.ServicePackReference][productNodeIdentification] = link.DocumentNumber;
                        }
                    }
                    else
                    {
                        servicePackNodes[linkConnectedServicePack.ServicePackReference].Add(productNodeIdentification, link.DocumentNumber);
                    }
                }
            }
        }

        public IEnumerable<IBreakdownReplacementChainLink> GetBreakdownReplacementChainLinksForDocumentNumbers(
            IList<NodeTemplateIssue> nodeTemplates,
            IDictionary<SoftwareChainIdentifier, IBreakdownReplacementChain> breakdownReplacementChains)
        {
            var breakdownNodeTemplates = new List<IBreakdownReplacementChainLink>();
            foreach (var chain in breakdownReplacementChains)
            {
                var nodeTemplate = nodeTemplates.FirstOrDefault(ntp => chain.Key.ProductNodeIdentification.IsForNodeDefinition(ntp.TemplateType.NodeDefinition));
                if (nodeTemplate != null)
                {
                    var breakdownNodeTemplate =
                        chain.Value.ChainLinks.FirstOrDefault(cl => cl.DocumentNumber.Equals(nodeTemplate.DocumentNumber));
                    if (breakdownNodeTemplate != null)
                    {
                        breakdownNodeTemplates.Add(breakdownNodeTemplate);
                    }
                }
            }
            return breakdownNodeTemplates;
        }

        public IEnumerable<ProductNodeIdentification> WithdrawnRequestedNodes(Installation installation,
            IDictionary<SoftwareChainIdentifier, IBreakdownReplacementChain> breakdownReplacementChains)
        {
            var withdrawnRequestedNodes = new List<ProductNodeIdentification>();

            foreach (var product in installation.Products)
            {
                foreach (var requestedNode in product.RequestMetadata.CurrentlyRequestedNodes)
                {
                    var originalNode =
                        product.BillOfMaterial.Nodes.Single(n => n.NodeIdentification.Equals(requestedNode));

                    var originalDocumentNumbers = originalNode.GetAllDocumentNumbers();

                    var keys =
                        breakdownReplacementChains.Keys.Where(
                            k => k.ProductNodeIdentification.NodeIdentification.Equals(requestedNode));

                    foreach (var key in keys)
                    {
                        var chain = breakdownReplacementChains[key];
                        if (chain.ChainLinks.Any(cl => originalDocumentNumbers.Any(dn => dn.Equals(cl.DocumentNumber)) && cl.IsWithdrawn))
                        {
                            withdrawnRequestedNodes.Add(key.ProductNodeIdentification);
                            break;
                        }
                    }
                }
            }

            return withdrawnRequestedNodes.Distinct();
        }
    }
}