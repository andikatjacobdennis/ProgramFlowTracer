﻿using Proxy.Matrix;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Volvo.Esw.SoftwareBreakdown.Pdm.Links;
using Volvo.SoftwareBreakdown.BreakdownDomain.Infrastructure.Repositories;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Baseline;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Node;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Parts;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ProductDefinition;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.RepositoryInterfaces;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Request;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.UpgradePath;
using Volvo.SoftwareBreakdown.ProxyComponents.Proxy.RepoLib;
using Volvo.SoftwareBreakdown.UtilityComponent;

namespace Volvo.SoftwareBreakdown.BreakdownDomain.Services
{
    public class ServicePackCompatibilityResolver : IServicePackCompatibilityResolver
    {
        private readonly IRepoLibProxy _repoLibProxy;
        private readonly IEvalService _evalService;
        private readonly IBaselineRepository _baselineRepository;

        public ServicePackCompatibilityResolver(IRepoLibProxy repoLibProxy, IEvalService evalService,
            IBaselineRepository baselineRepository = null)
        {
            _repoLibProxy = repoLibProxy ?? throw new ArgumentNullException(nameof(repoLibProxy));
            _evalService = evalService ?? throw new ArgumentNullException(nameof(evalService));
            _baselineRepository = baselineRepository;
        }

        public async Task<CompatibleServicePackResult<UpgradePathWalkResult>> FindFirstCompatibleServicePackAsync(
            IUpgradePathWalkerService upgradePathWalker,
            IEnumerable<ServicePackReference> servicePackReferencesTarget,
            IEnumerable<IProductContainer> products,
            IProductSpecification productSpecification,
            CancellationToken cancellationToken = default)
        {
            var requestedProducts = GetRequestedSoftwareProducts(products);

            foreach (var servicePackReference in servicePackReferencesTarget)
            {
                var targetProducts = await GetTargetSoftwareProductsFromServicePackAsync(
                    servicePackReference, productSpecification).ConfigureAwait(false);

                var (requestedProductsMapped, targetProductsMapped) =
                    MapMissingProductsBetweenLists(requestedProducts, targetProducts);

                var productResults = new List<PerProductUpgradeResult<UpgradePathWalkResult>>();
                var upgradePathExceptionOccurred = false;

                foreach (var requestedProduct in requestedProductsMapped)
                {
                    var skipProduct = false;
                    var targetProduct = targetProductsMapped.FirstOrDefault(tp =>
                        !string.IsNullOrWhiteSpace(tp.SoftwareProductName) &&
                        tp.SoftwareProductName.Contains(requestedProduct.SoftwareProductName, StringComparison.OrdinalIgnoreCase));

                    var fromSnapshotPackageId = requestedProduct?.FromSnapshotPackageId?.Trim();
                    var toSnapshotPackageId = targetProduct?.ToSnapshotPackageId?.Trim();

                    UpgradePathWalkResult upgradeResult = null;
                    string errorMessage = null;
                    var success = false;

                    try
                    {
                        // Case 1: if in request none of the node has execution environment -> retain target service pack, skip WalkAsync
                        if (!CheckIfRequestHasAnyHpcNode(products))
                        {
                            Serilog.Log.Information(
                                "Upgrade path walker skipped. No HPC node was found in the software request. Retaining target service pack.");
                        }
                        // Case 2: both same -> retain target service pack, skip WalkAsync
                        else if (!string.IsNullOrWhiteSpace(fromSnapshotPackageId) &&
                                 !string.IsNullOrWhiteSpace(toSnapshotPackageId) &&
                                 string.Equals(fromSnapshotPackageId, toSnapshotPackageId, StringComparison.OrdinalIgnoreCase))
                        {
                            Serilog.Log.Information(
                                "Upgrade path walker skipped. Source snapshot package id '{SourceSnapshotPackageId}' matches target snapshot package id '{TargetSnapshotPackageId}'. Retaining target service pack.",
                                fromSnapshotPackageId,
                                toSnapshotPackageId);
                            success = true;
                        }
                        // Case 3: request present, target empty -> target service pack not usable
                        // and dont add in productResults
                        else if (!string.IsNullOrWhiteSpace(fromSnapshotPackageId) &&
                                 string.IsNullOrWhiteSpace(toSnapshotPackageId))
                        {
                            Serilog.Log.Warning(
                                "Upgrade path walker and product add skipped. Source snapshot package id '{SourceSnapshotPackageId}' is present, but target snapshot package id is missing. Target service pack is not usable.",
                                fromSnapshotPackageId);
                            skipProduct = true;
                        }
                        else
                        {
                            upgradeResult = await upgradePathWalker.WalkAsync(
                                fromSnapshotPackageId,
                                toSnapshotPackageId,
                                productSpecification,
                                cancellationToken).ConfigureAwait(false);

                            success = IsUpgradePathSuccess(upgradeResult, out errorMessage);
                        }
                    }
                    catch (Exception ex)
                    {
                        upgradePathExceptionOccurred = true;
                        errorMessage = ex.Message;

                        Serilog.Log.Error(
                            ex,
                            "Failed to resolve upgrade path for product {ProductName} from {FromSnapshotPackageId} to {ToSnapshotPackageId}. Going to next target service pack.",
                            requestedProduct.SoftwareProductName, fromSnapshotPackageId, toSnapshotPackageId);
                        break;
                    }

                    if (!skipProduct)
                    {
                        productResults.Add(new PerProductUpgradeResult<UpgradePathWalkResult>
                        {
                            ProductName = requestedProduct.SoftwareProductName,
                            FromSnapshotPackageId = fromSnapshotPackageId,
                            ToSnapshotPackageId = toSnapshotPackageId,
                            Result = upgradeResult,
                            Success = success,
                            ErrorMessage = errorMessage
                        });
                    }
                }

                if (upgradePathExceptionOccurred) continue;

                Serilog.Log.Information(
                    "Compatible service pack {ServicePackId} found for requested software products.",
                    servicePackReference.Id);

                return new CompatibleServicePackResult<UpgradePathWalkResult>
                {
                    Success = true,
                    ServicePackReference = servicePackReference,
                    ProductResults = productResults
                };
            }

            Serilog.Log.Information("No compatible service pack found where all software products have a valid upgrade path.");

            return new CompatibleServicePackResult<UpgradePathWalkResult>
            {
                Success = false,
                ErrorMessage = "No compatible service pack found where all software products have a valid upgrade path."
            };
        }

        private (List<RequestedSoftwareProduct> requestedProductsMapped, List<TargetSoftwareProduct> targetProductsMapped)
            MapMissingProductsBetweenLists(List<RequestedSoftwareProduct> requestedProducts, List<TargetSoftwareProduct> targetProducts)
        {
            var requestedProductsMapped = new List<RequestedSoftwareProduct>(
                requestedProducts ?? Enumerable.Empty<RequestedSoftwareProduct>());

            var targetProductsMapped = new List<TargetSoftwareProduct>(
                targetProducts ?? Enumerable.Empty<TargetSoftwareProduct>());

            // Add target products that don't exist in request
            foreach (var target in targetProducts ?? Enumerable.Empty<TargetSoftwareProduct>())
            {
                if (string.IsNullOrWhiteSpace(target?.SoftwareProductName))
                    continue;

                var exists = requestedProductsMapped.Any(r =>
                    !string.IsNullOrWhiteSpace(r.SoftwareProductName) &&
                    (target.SoftwareProductName.Contains(r.SoftwareProductName, StringComparison.OrdinalIgnoreCase) ||
                     r.SoftwareProductName.Contains(target.SoftwareProductName, StringComparison.OrdinalIgnoreCase)));

                if (!exists)
                {
                    requestedProductsMapped.Add(new RequestedSoftwareProduct
                    {
                        SoftwareProductName = target.SoftwareProductName,
                        FromSnapshotPackageId = string.Empty
                    });
                }
            }

            // Add requested products that don't exist in target
            foreach (var request in requestedProducts ?? Enumerable.Empty<RequestedSoftwareProduct>())
            {
                if (string.IsNullOrWhiteSpace(request?.SoftwareProductName))
                    continue;

                var exists = targetProductsMapped.Any(t =>
                    !string.IsNullOrWhiteSpace(t.SoftwareProductName) &&
                    (t.SoftwareProductName.Contains(request.SoftwareProductName, StringComparison.OrdinalIgnoreCase) ||
                     request.SoftwareProductName.Contains(t.SoftwareProductName, StringComparison.OrdinalIgnoreCase)));

                if (!exists)
                {
                    targetProductsMapped.Add(new TargetSoftwareProduct
                    {
                        SoftwareProductName = request.SoftwareProductName,
                        ToSnapshotPackageId = string.Empty
                    });
                }
            }

            return (requestedProductsMapped, targetProductsMapped);
        }

        private async Task<List<TargetSoftwareProduct>> GetTargetSoftwareProductsFromServicePackAsync(
            ServicePackReference servicePackReference,
            IProductSpecification productSpecification)
        {
            if (servicePackReference?.RepoLibIdentifiers == null || !servicePackReference.RepoLibIdentifiers.Any())
                return new List<TargetSoftwareProduct>();

            // Step 1: the pack's own RepoLib packages, plus the ones carried inside its SIBs.
            var (repoLibPackages, _, _) = await ExpandRepoLibEntitiesAsync(
                servicePackReference.RepoLibIdentifiers,
                _baselineRepository).ConfigureAwait(false);

            // Step 2: Evaluate all software products from RepoLib against the product specification
            var softwareProducts = await EvaluateSoftwareProductsAsync(repoLibPackages.Distinct().ToList(), productSpecification)
                .ConfigureAwait(false);

            // Map SoftwareProduct -> TargetSoftwareProduct
            return softwareProducts
                .Where(sp => sp != null)
                .Select(sp => new TargetSoftwareProduct
                {
                    SoftwareProductName = sp.Name?.Trim(),
                    ToSnapshotPackageId = sp.Id?.Trim()
                })
                .ToList();
        }

        /// <summary>
        /// Step 1: Resolves raw RepoLib package strings from the given identifiers.
        /// Mirrors NodeTranslator.GetRepoLibEntitiesAsync.
        /// </summary>
        private async Task<IList<string>> GetRepoLibPackagesAsync(IList<RepoLibIdentifierLink> repoLibIdentifiers)
        {
            if (repoLibIdentifiers == null || !repoLibIdentifiers.Any())
                return new List<string>();

            try
            {
                var packageIds = repoLibIdentifiers
                    .Select(r => r.Identifier)
                    .Where(id => !string.IsNullOrWhiteSpace(id))
                    .Distinct()
                    .ToList();

                var packages = await _repoLibProxy.GetPackages(packageIds).ConfigureAwait(false);
                return packages.ToList();
            }
            catch (Exception ex)
            {
                Serilog.Log.Error(ex, "Failed to fetch RepoLib packages for service pack identifiers.");
                return new List<string>();
            }
        }

        /// <summary>
        /// Step 2: Evaluates resolved RepoLib packages into SoftwareProduct domain objects.
        /// Mirrors NodeTranslator.EvaluateAllSoftwareProductsFromRepoLibAsync.
        /// </summary>
        private async Task<IList<SoftwareProduct>> EvaluateSoftwareProductsAsync(
            IList<string> repoLibPackages,
            IProductSpecification productSpecification)
        {
            if (repoLibPackages == null || !repoLibPackages.Any())
                return new List<SoftwareProduct>();

            try
            {
                var softwareProductRepoLinks = await _evalService
                    .EvaluateSoftwareProductsAsync(repoLibPackages, productSpecification)
                    .ConfigureAwait(false);

                return softwareProductRepoLinks
                    .Select(x => x.Value)
                    .Where(entity => entity != null)
                    .GroupBy(sp => new { sp.Name, sp.Deployer })
                    .Select(g =>
                    {
                        try { return new SoftwareProduct(g.First()); }
                        catch (Exception ex)
                        {
                            Serilog.Log.Error(ex, "Failed to convert RepoLib entity to SoftwareProduct: {Name}", g.Key.Name);
                            return null;
                        }
                    })
                    .Where(sp => sp != null)
                    .ToList();
            }
            catch (Exception ex)
            {
                Serilog.Log.Error(ex, "Failed to evaluate software products from RepoLib for service pack.");
                return new List<SoftwareProduct>();
            }
        }

        private List<RequestedSoftwareProduct> GetRequestedSoftwareProducts(IEnumerable<IProductContainer> products)
        {
            var result = new List<RequestedSoftwareProduct>();

            if (products == null)
                return result;

            var allSoftwareProducts = products?
                                    .SelectMany(p => p.ProductHpcNodes?.OfType<HpcNode>() ?? Enumerable.Empty<HpcNode>())
                                    .SelectMany(hpc => hpc.ExecutionEnvironments ?? Enumerable.Empty<ExecutionEnvironment>())
                                    .SelectMany(ee => ee.SoftwareProducts ?? Enumerable.Empty<SoftwareProduct>())
                                    .ToList() ?? new List<SoftwareProduct>();

            foreach (var sp in allSoftwareProducts)
            {
                if (sp == null)
                    continue;

                if (string.IsNullOrWhiteSpace(sp.Name) || string.IsNullOrWhiteSpace(sp.Version))
                    continue;

                result.Add(new RequestedSoftwareProduct
                {
                    SoftwareProductName = sp.Name?.Trim(),
                    FromSnapshotPackageId = sp.Id?.Trim()
                });
            }

            return result;
        }

        private bool IsUpgradePathSuccess(UpgradePathWalkResult upgradeResult, out string errorMessage)
        {
            errorMessage = null;

            if (upgradeResult == null)
            {
                errorMessage = "Upgrade path result is null.";
                return false;
            }

            var successProperty = upgradeResult.GetType().GetProperty("Success");
            if (successProperty != null && successProperty.PropertyType == typeof(bool))
            {
                var success = (bool)successProperty.GetValue(upgradeResult);
                if (!success)
                {
                    errorMessage = "Upgrade path did not complete successfully.";
                }

                return success;
            }

            return true;
        }

        /// <inheritdoc/>
        public async Task<IReadOnlyCollection<int>> GetSibDocumentNumbersAsync(ServicePackReference servicePack)
        {
            if (servicePack?.RepoLibIdentifiers == null || !servicePack.RepoLibIdentifiers.Any())
            {
                return Array.Empty<int>();
            }

            if (_baselineRepository == null)
            {
                Serilog.Log.Warning(
                    "No baseline repository available, the SIBs of service pack {ServicePackId} cannot be resolved.",
                    servicePack.Id);
                return Array.Empty<int>();
            }

            var documentNumbers = new HashSet<int>();

            await CollectSibDocumentNumbersAsync(servicePack.RepoLibIdentifiers,
                new HashSet<string>(StringComparer.OrdinalIgnoreCase), documentNumbers).ConfigureAwait(false);

            Serilog.Log.Information(
                "Service pack {ServicePackId} carries {DocumentNumberCount} node template document number(s) in its SIBs.",
                servicePack.Id, documentNumbers.Count);

            return documentNumbers;
        }

        /// <summary>
        /// Walks the SIB packages behind these RepoLib links, and the SIBs nested inside those,
        /// collecting the document numbers every resolved baseline names.
        /// </summary>
        /// <remarks>
        /// <paramref name="visitedSibGuids"/> carries the cycle detection through the recursion, so a
        /// SIB that references itself is skipped rather than looping forever.
        /// </remarks>
        private async Task CollectSibDocumentNumbersAsync(IList<RepoLibIdentifierLink> repoLibIdentifiers,
            HashSet<string> visitedSibGuids, HashSet<int> documentNumbers)
        {
            var packages = await GetRepoLibPackagesAsync(repoLibIdentifiers).ConfigureAwait(false);

            foreach (var packageJson in packages)
            {
                if (!TryExtractSibGuid(packageJson, out var sibGuid))
                {
                    continue;
                }

                if (!visitedSibGuids.Add(sibGuid))
                {
                    continue;
                }

                var sibBaseline = await _baselineRepository.GetConfiguratorBaselineAsync(sibGuid).ConfigureAwait(false);

                if (sibBaseline is null)
                {
                    Serilog.Log.Warning("SIB {SibGuid} referenced from a service pack has no baseline.", sibGuid);
                    continue;
                }

                var linksFromThisBaseline = sibBaseline.DocumentNumberLinks
                    .Select(link => link.PartNumber)
                    .Where(documentNumber => documentNumber > 0)
                    .ToList();

                foreach (var documentNumber in linksFromThisBaseline)
                {
                    documentNumbers.Add(documentNumber);
                }

                if (sibBaseline.RepoLibLinks.Count > 0)
                {
                    await CollectSibDocumentNumbersAsync(sibBaseline.RepoLibLinks.ToList(), visitedSibGuids,
                        documentNumbers).ConfigureAwait(false);
                }
            }
        }

        /// <summary>
        /// Reads the baseline GUID out of a SIB package, or returns <see langword="false"/> when the
        /// package is not a SIB.
        /// </summary>
        /// <remarks>
        /// The shape confirmed from live RepoLib data is a top-level <c>type</c> of
        /// <c>SoftwareIntegrationBundle</c> and a <c>content</c> object holding a <c>guid</c>. Note
        /// that an earlier attempt tested for <c>"sib"</c> here, which matches nothing, and that
        /// <c>BaseService</c> keeps its own copy of this for the development and production
        /// breakdown.
        /// </remarks>
        private static bool TryExtractSibGuid(string packageJson, out string sibGuid)
        {
            sibGuid = string.Empty;

            if (string.IsNullOrWhiteSpace(packageJson))
                return false;

            try
            {
                using var document = JsonDocument.Parse(packageJson);
                var root = document.RootElement;

                if (!root.TryGetProperty("type", out var typeProperty) ||
                    !string.Equals(typeProperty.GetString(), "SoftwareIntegrationBundle", StringComparison.OrdinalIgnoreCase))
                    return false;

                if (!root.TryGetProperty("content", out var contentProperty))
                    return false;

                if (!contentProperty.TryGetProperty("guid", out var guidProperty))
                    return false;

                var extracted = guidProperty.GetString();

                if (string.IsNullOrEmpty(extracted))
                    return false;

                sibGuid = extracted;
                return true;
            }
            catch (JsonException)
            {
                return false;
            }
        }

        public bool CheckIfRequestHasAnyHpcNode(IEnumerable<IProductContainer> products)
        {
            return products?
                .SelectMany(p => p.ProductHpcNodes?.OfType<HpcNode>() ?? Enumerable.Empty<HpcNode>())
                .Any() == true;
        }
        
        protected async Task<IEnumerable<string>> GetRepoLibEntities(IEnumerable<RepoLibIdentifierLink> repoLibLinks)
        {
            return (await _repoLibProxy.GetPackages(repoLibLinks.Select(l => l.Identifier))).ToList();
        }

        /// <summary>
        /// Recursively expands a collection of RepoLib identifier links, resolving any SIB (Software Integration Baseline)
        /// references into their constituent packages and nested baselines.
        /// </summary>
        /// <remarks>
        /// Non-SIB packages are collected as-is into the flat package list. SIB packages are resolved by looking up
        /// the corresponding baseline from the repository and recursively expanding its own RepoLib links.
        /// Circular SIB references are detected via <paramref name="visitedSibGuids"/> and skipped to prevent
        /// infinite recursion. Duplicate packages (identical JSON strings seen more than once across the entire
        /// expansion) are tracked in <paramref name="duplicatePackages"/> and excluded from the returned
        /// <c>Packages</c> list.
        /// </remarks>
        /// <param name="repoLibLinks">The initial collection of RepoLib identifier links to expand.</param>
        /// <param name="baselineRepository">
        /// Repository used to fetch <see cref="BaseBaseline"/> instances for resolved SIB GUIDs.
        /// </param>
        /// <param name="visitedSibGuids">
        /// Optional set of SIB GUIDs already visited in the current recursion chain. When <see langword="null"/>,
        /// a new case-insensitive set is created automatically. Pass the same instance across recursive calls
        /// to maintain cycle-detection state.
        /// </param>
        /// <param name="seenPackages">
        /// Optional set of package JSON strings already encountered. When <see langword="null"/>,
        /// a new case-insensitive set is created automatically. Used to detect duplicate packages across
        /// all levels of recursion.
        /// </param>
        /// <param name="duplicatePackages">
        /// Optional list that accumulates duplicate package JSON strings. When <see langword="null"/>,
        /// a new list is created automatically.
        /// </param>
        /// <returns>
        /// A tuple containing:
        /// <list type="bullet">
        ///   <item><description><c>Packages</c> – the de-duplicated, flat list of resolved non-SIB package JSON strings.</description></item>
        ///   <item><description><c>SibBaselines</c> – all <see cref="BaseBaseline"/> instances resolved during expansion, including nested ones.</description></item>
        ///   <item><description><c>DuplicatePackages</c> – package JSON strings that were encountered more than once and excluded from <c>Packages</c>.</description></item>
        /// </list>
        /// </returns>
        public async Task<(IReadOnlyList<string> Packages, IReadOnlyList<BaseBaseline> SibBaselines, IReadOnlyList<string> DuplicatePackages)>
            ExpandRepoLibEntitiesAsync(
                IEnumerable<RepoLibIdentifierLink> repoLibLinks,
                IBaselineRepository baselineRepository,
                HashSet<string>? visitedSibGuids = null,
                HashSet<string>? seenPackages = null,
                List<string>? duplicatePackages = null)
        {
            visitedSibGuids ??= new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            seenPackages ??= new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            duplicatePackages ??= new List<string>();

            var rawPackages = (await GetRepoLibEntities(repoLibLinks)).ToList();
            var flatPackages = new List<string>();
            var sibBaselines = new List<BaseBaseline>();

            foreach (var packageJson in rawPackages)
            {
                // For Non-SIB keep as it is.
                if (!TryExtractSibGuid(packageJson, out var sibGuid))
                {
                    if (!seenPackages.Add(packageJson))
                        duplicatePackages.Add(packageJson);
                    else
                        flatPackages.Add(packageJson);
                    continue;
                }

                // Guard against circular SIB references.
                if (!visitedSibGuids.Add(sibGuid))
                    continue;

                // Look up the SIB baseline from the database.
                var sibBaseline = await baselineRepository.GetConfiguratorBaselineAsync(sibGuid);
                if (sibBaseline is null)
                    continue;

                sibBaselines.Add(sibBaseline);

                // Evaluate the SIB baseline's own RepoLib links recursively.
                if (sibBaseline.RepoLibLinks.Count > 0)
                {
                    var (nestedPackages, nestedBaselines, _) = await ExpandRepoLibEntitiesAsync(
                        sibBaseline.RepoLibLinks,
                        baselineRepository,
                        visitedSibGuids,
                        seenPackages,
                        duplicatePackages);

                    flatPackages.AddRange(nestedPackages);
                    sibBaselines.AddRange(nestedBaselines);
                }
            }

            return (flatPackages, sibBaselines, duplicatePackages);
        }
    }
}