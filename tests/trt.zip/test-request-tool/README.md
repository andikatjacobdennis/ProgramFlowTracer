# Test Request Tool

Plan software, parameter and variant changes for vehicles, check them, get them approved and send them: as a VDA
update, a conversion kit or an export. Checks are simulations and never install software on a vehicle.

Version 1.0.0. See [CHANGELOG.md](CHANGELOG.md).

## What you need

- Windows 10 or 11.
- The **.NET 10 SDK**, not just the runtime: https://dotnet.microsoft.com/download/dotnet/10.0.
- Access to nuget.org for the first build.
- Microsoft Edge or Google Chrome.
- Optional: **Visual Studio 2026** (18.0 or newer) with the *ASP.NET and web development* workload.
- Optional: Node.js 22 or newer, to run the frontend tests.

## Get started

1. Clone the repository:

   ```bash
   git clone <repository-url> trt_rev0
   ```

2. Set up the data folder, **`C:\trt`**. Extract **`setup\trt.zip`** to `C:\`: right-click it, choose *Extract All…*,
   enter `C:\` and select *Extract*. You get `C:\trt` with the starter data (see [Starter data](#starter-data-ctrt)).
   Or from PowerShell, in the cloned folder:

   ```bash
   powershell -Command "Expand-Archive setup\trt.zip -DestinationPath C:\"
   ```

   If `C:\trt` already exists, keep it: it holds your data. Extract the zip only on a computer that does not have it yet.
3. Open `C:\trt\settings.json` and give every account its own password, replacing each `CHANGE-ME`. Rename or add
   accounts as you need: one per person, each with a role (Admin, Reviewer, Engineer or Viewer). An account that keeps a
   `CHANGE-ME` password cannot sign in.
4. Run `Start.cmd` in the cloned folder and open **http://localhost:5100**. Sign in with one of the accounts.

`Start.cmd` stops and says so when `C:\trt\settings.json` is missing (it then creates it from
`settings.example.json`) or when no account has a real password yet.

**From Visual Studio:**
1. Set up `C:\trt` first, as in steps 2 and 3 above.
2. Open `TestRequestTool.slnx`.
3. `Volvo.TestRequestTool.Web` is the startup project. Press **F5**.

## Starter data (C:\trt)

`setup\trt.zip` contains the `C:\trt` folder a new developer starts from:

| In the zip | What it is |
|------------|------------|
| `trt\settings.json` | The four example sign-in accounts (Admin, Engineer, Reviewer, Viewer), all with `CHANGE-ME` passwords to replace. |
| `trt\repo\catalog` | The reference data: contexts, node templates, baselines, service packs, kits, variants, parameter definitions and factories. |
| `trt\repo\vehicles`, `trt\repo\vehicle-originals` | The seven reference vehicles (for example FH 333333 for T3, FH 123456 for TEA2+/BEA2 and RT 000777 for TEA2), as XML. |
| `trt\repo\repository\info.json` | Marks the repository as filled, so deleted records do not come back. |
| `trt\services` | The file transport for the external services: EDB specifications, CBR spare cab orders, and folders for KAX, VESPA, Dependix and Digital Twin. Its `README.md` explains the layout. |

It holds no people, sessions, audit entries, requests or real passwords. Those are created on each computer as people
sign in and work.

The app also fills an empty `C:\trt\repo` and `C:\trt\services` with the same reference data the first time it starts, so
the zip is a convenience: everything is in place, and readable, before the first start.

**Refreshing the zip** after the reference data changes:
1. Start from an empty folder.
2. Let the app fill it once.
3. Zip the `trt` folder, leaving out `settings.json`, `repo\users`, `repo\sessions`, `repo\audit` and any requests or
   drafts.
4. Add a `settings.json` copied from `settings.example.json`.

**Where things live on each computer:**

| Folder or file | What it holds |
|----------------|---------------|
| `C:\trt\settings.json` | The sign-in accounts, and the settings changed on Administration › Data and services. |
| `C:\trt\repo` | The data: vehicles, requests, reviews, people, the catalog and the audit log. There is one file per record. A new folder is filled with the reference data shipped with the app the first time it starts. |
| `C:\trt\services` | The external services (EDB, CBR, KAX, VESPA, Dependix, Digital Twin) while they are read from files. Its `README.md` explains the layout. |

Back up `C:\trt\repo` like any other data. To move the data, use Administration › Data and services, or change
`Repository:Path` and `Services:Path`.

## Documentation

**Using and setting up:**
- [Sign-in](docs/sign-in.md): accounts, sessions, and replacing the temporary sign-in with a directory or single sign-on.
- [Data and services](docs/data-and-services.md): the repository and the service layer, files now and a database or HTTP later.
- [Rate limiting](docs/rate-limiting.md): the request limits and their settings.

**Inside the app:**
- [Architecture](docs/architecture.md) and the [frontend architecture](docs/ux-architecture.md).
- [T3 services](docs/t3-services.md): the Product Update Service and Available Product Updates contracts.
- [Listener requests](docs/listener.md): every message type of the request listener, its XSDs, and how a family is simulated.
- [Assistant](docs/ai-readiness.md): the simulated assistant, and how a real provider is added.
- [Adding a language](docs/adding-a-language.md).

**Contributing:**
- [Coding standards](docs/coding-standards.md): names, namespaces and layout (they follow swb-stable1).

The UI guide is in the app itself: Help › UI guide, or http://localhost:5100/guide/.

**Abbreviations.** Abbreviations on screen (EMS, ECU, VDA, MSW …) have a dotted underline. Point at one to see what it
stands for. Help › Abbreviations lists and searches all of them. Settings › Accessibility › *Explain abbreviations*
turns the underlines off. The meanings come from two places:
- this tool's own meanings, in `src/Volvo.TestRequestTool.Web/wwwroot/js/app/abbreviations.js` (`APP`), which come first;
- the company list of abbreviations, in `wwwroot/data/abbreviations.json`. To refresh it from a newer `Abbreviations.xlsx`:

```bash
python scripts/import-abbreviations.py "<path to>\Abbreviations.xlsx"
```

Only Open and Internal entries are taken. The script needs `openpyxl` (`pip install openpyxl`).

## Develop

```
src/
  Volvo.TestRequestTool.Domain           records and rules
  Volvo.TestRequestTool.Application      ports, request handlers, validators, services
  Volvo.TestRequestTool.Infrastructure   file repository (JSON/XML), service gateway (files/HTTP), reference catalog,
                                         the listener's contracts (XSDs)
  Volvo.TestRequestTool.Web              API, sign-in, hosting, and the web interface (wwwroot)
tests/
  Volvo.TestRequestTool.UnitTests        domain, handlers, repository
  Volvo.TestRequestTool.IntegrationTests the API end to end (WebApplicationFactory)
  frontend/                              the web interface (Node, no dependencies)
scripts/
  Start-Local.ps1, Assert-Sdk.ps1        what Start.cmd runs
  verify.ps1                             build, then run every test
  guide/                                 regenerates the UI guide screenshots
  i18n-extract.js, i18n-seed.py          language packs (see Adding a language)
  import-abbreviations.py                the company abbreviation list (wwwroot/data/abbreviations.json)
  import-contracts.py                    the listener's message types and XSDs (Infrastructure/Contracts)
```

To build, then run every test (.NET and frontend):

```bash
powershell -ExecutionPolicy Bypass -File scripts/verify.ps1
```

The steps one at a time:

```bash
dotnet build TestRequestTool.slnx -c Release
```

```bash
dotnet test TestRequestTool.slnx -c Release --no-build
```

```bash
node tests/frontend/testrequest.cjs
```

Before committing, run `dotnet format TestRequestTool.slnx`, which applies the layout in `.editorconfig`. Warnings are
errors in this solution.
