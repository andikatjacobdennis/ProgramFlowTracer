# Sign-in

Test Request Tool has its own sign-in page. For now it checks the user name (or email) and password against accounts
written in the settings. This is a temporary arrangement: the design lets a database, a directory or single sign-on
replace it without touching the rest of the app.

## How it fits together

| Part | Where | What it does |
|------|-------|--------------|
| Sign-in page | `wwwroot/login.html`, `js/login.js`, `css/login.css` | The form: user name or email, password, show/hide, field checks, a busy state while signing in, and clear messages. Sends the form to the server; keeps no credential. |
| Credential check | `ICredentialValidator` in `SignIn.cs` | One method: `ValidateAsync(login, password)` returns the account or `null`. The first implementation is `ConfiguredCredentials` (the settings). |
| Session | `SignIn.cs` (cookie authentication, built into ASP.NET Core) | An HttpOnly, SameSite=Strict cookie `trt.session` that holds only who signed in. Sliding expiry (`Authentication:SessionMinutes`, default 480). On every request the person's record is read from the repository, so a role or context change applies at once and a disabled account loses its session immediately. |
| People and roles | Repository `users` collection (`C:\trt\repo\users\<id>.json`) | Role (Admin, Reviewer, Engineer, Viewer), contexts, country, email, enabled. Edited on Administration › Users. The sign-in only proves *who* someone is; this record says what they may do. |
| Protection | `UseSignInRedirect`, the API group's `RequireAuthorization()` | The app page (`/`, `/index.html`) sends anyone without a session to `/login?returnUrl=…`; every `/api/v1` endpoint answers 401 without one (`session_required`). Only the sign-in page, its files, `/api/v1/auth/login`, `/api/v1/auth/logout` and the health checks are open. |
| Client handling | `wwwroot/js/auth.js` | Any 401 from the API (session ended, signed out elsewhere) sends the page to the sign-in page, which brings the person back afterwards. `TR.auth.signOut()` ends the session (profile menu › Sign out). |

### Endpoints

- `POST /api/v1/auth/login` — body `{ "login": "<user name or email>", "password": "…" }`, header `X-Studio-Request: 1`.
  - 200 and the cookie on success.
  - 401 `invalid_credentials` for a wrong password and for an unknown user alike, so the answer does not show which user names exist. The password check takes the same time either way.
  - 403 `account_disabled`.
  - 400 when a field is empty or the header is missing.
  - 429 after too many attempts from one address (`RateLimiting:Policies:auth`, 20 a minute).
  - Every sign-in is recorded in the audit log (`auth.signin`).
- `POST /api/v1/auth/logout` — ends the session (204).
- `GET /login?returnUrl=/…` — the sign-in page. When already signed in, it goes straight to `returnUrl`. Only paths on this site are accepted; anything else goes to `/`.

## Setting the temporary accounts

Accounts are in `Authentication:Accounts`. Each account has:
- `Id` — the user ID in the repository;
- `UserName` and `Email` — either one signs in;
- `Password`;
- `DisplayName`, `Role`, `Contexts` (empty means every context) and `Country`.

```json
{
  "Authentication": {
    "Mode": "Password",
    "SessionMinutes": 480,
    "Accounts": [
      { "Id": "ananya", "UserName": "ananya", "Email": "ananya.iyer@example.com", "Password": "choose-a-long-one",
        "DisplayName": "Ananya Iyer", "Role": "Admin", "Contexts": [], "Country": "IN" }
    ]
  }
}
```

- **Where the accounts go:** in the settings file `C:\trt\settings.json` (start from `settings.example.json` in the repository) or in environment variables (`Authentication__Accounts__0__UserName=…`). The repository has no accounts and no passwords, so nobody can sign in until you add some. Never put real passwords in a file that is committed.
- **Placeholders:** an account whose password is empty or still starts with `CHANGE-ME` cannot sign in (the log says which).
- **When edits apply:** account changes apply on the next sign-in attempt; no restart is needed.
- **First start:** at start-up every account without a user record gets one, so administrators see everyone who can sign in. After that, the record on Administration › Users wins: role, contexts, country, enabled.
- **Plain text, for now:** passwords in the settings are stored as written. This is the temporary part. Keep the settings file readable only by the account the app runs as.

## Replacing the temporary sign-in

**A database or directory check** (same sign-in page, real passwords):
1. Implement `ICredentialValidator`. Look the person up, verify a password hash (for example with `PasswordHasher<T>` from `Microsoft.Extensions.Identity.Core`, which is part of ASP.NET Core), and return a `UserAccount` (or `null`).
2. Register it instead of `ConfiguredCredentials` in `AddStudioSignIn`, for example: `services.AddSingleton<ICredentialValidator, DirectoryCredentials>();`
3. Remove `Authentication:Accounts` from the settings.

The page, the session, the protection and the tests stay as they are.

**Single sign-on (OpenID Connect, for example Entra ID):**
1. Add `Microsoft.AspNetCore.Authentication.OpenIdConnect`.
2. In `Program.cs`, add a mode next to `Password` that registers cookie authentication with `AddOpenIdConnect(...)` as the challenge scheme.
3. Reuse `SignIn.Principal(user)` and the `OnValidatePrincipal` handler: map the token's subject to a user record, creating one on first sign-in as the login endpoint does.
4. The sign-in page is then the identity provider's. `/login` can redirect to the challenge, and `TR.auth.signOut()` keeps working once logout also signs out of the OpenID Connect scheme.

**Bearer tokens (an API gateway in front):** `Authentication:Mode` = `Jwt`, with `Authentication:Authority` and `Authentication:Audience`. This mode existed before and is unchanged. Roles come from the token's `role` claims.

## Tests

`tests/Volvo.TestRequestTool.IntegrationTests/SignInTests.cs` covers:
- signing in by user name and by email;
- wrong and missing credentials, with the same message for unknown users;
- signing out;
- the protected page and API, and the return address (including refusing other sites);
- disabled accounts losing their session at once;
- role changes applying to the next request;
- the attempt limit.

Every other integration test signs in through the same endpoint (`StudioFactory.SignInAsync`). Its test accounts and passwords exist only in the test factory.
