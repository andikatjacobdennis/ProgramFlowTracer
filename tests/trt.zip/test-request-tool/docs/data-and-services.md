# Data and services

Two settings decide where Test Request Tool keeps its data and how it reaches other systems:
- **Repository** (`Repository:*`): everything the tool stores.
- **Services** (`Services:*`): every external system.

Both start as folders on this machine:
- the repository: `C:\trt\repo`;
- the services: `C:\trt\services`.

Either can later move to a database or to live services through the settings.

Change them in **Administration › Data and services**, or in `C:\trt\settings.json`. That file is read last, on top of `appsettings.json` and environment variables, so what it says wins; the page writes to it. Its location is set by `Settings:File` (in `appsettings.json` or as the environment variable `Settings__File`).

## Repository

```json
"Repository": {
  "Provider": "Files",
  "Path": "C:\\trt\\repo",
  "Formats": { "vehicles": "xml", "vehicle-originals": "xml", "vehicle-revisions": "xml" }
}
```

There is one folder per collection and one file per record. Records are JSON, or XML for the collections that `Formats` names. The XML is lossless: the same document, element per field.

| Folder | One file per | Notes |
|--------|--------------|-------|
| `users\<id>.json` | person | role, contexts, country, email, enabled, last sign-in |
| `user-photos\<id>.png` (.jpg, .webp, .svg) | person | optional; initials otherwise |
| `catalog\<section>.json` | catalog section | contexts, templates, baselines, service packs, kits, variants, parameter definitions, factories |
| `vehicles\<series>-<number>.xml` | vehicle | the current product and its revision |
| `vehicle-originals\…xml` | vehicle | the product as first imported |
| `vehicle-revisions\<vehicle>\<revision>.xml` | committed revision | who, when, why, full snapshot |
| `requests\<id>.json` | validation request | |
| `drafts\<user>\<draft>.json` | draft | |
| `proposals\<user>\<proposal>\<n>.json` | proposal revision | |
| `reviews`, `campaigns`, `batches`, `jobs`, `kits`, `feedback` | record | |
| `settings\<key>\<version>.json` | organisation setting version | teams, culture defaults, feature flags |
| `audit\<sequence>.json` | audit entry | hash-chained |
| `pauses\<scope>.json` | operational pause | |
| `repository\info.json` | — | marks the repository as filled once |

**How it behaves**
- **Startup and reads:** start-up reads nothing. Each collection is read once, the first time it is needed (the warm-up loads the common ones in the background). After that it is answered from memory.
- **Writes:** a save writes only the records it changes, through a temporary file that then replaces the record. A record is never half-written, and a crash leaves at most a `.tmp` file, which is cleaned up later.
- **Changing a collection's format:** no migration is needed. Old files are still read, and each record is rewritten in the new format on its next save.
- **A new, empty repository:** it is filled once with the reference data shipped with the app (the catalog and the reference vehicles). `repository\info.json` records this, so records you delete are not brought back.
- **Changing the repository:** changing the path or provider applies at the next start. The page says so.

**Moving to a database later**
1. Implement `IDocumentStore` (`Volvo.TestRequestTool.Application/IDocumentStore.cs`). It has four operations:
   - list a collection;
   - get one document;
   - put one document atomically;
   - delete one document.

   A single table `(collection, key, document, updated_at)` is enough.
2. Register it in `DataSetup.AddStudioData` for a new `Repository:Provider` value (for example `Sql`).
3. Set `Repository:Provider` to that value.

`WorkspaceRepository` and everything above it stay unchanged. Running several app instances also needs the provider's own concurrency control (for example a row version per document), because the in-memory copy assumes one process.

## Services

```json
"Services": {
  "Path": "C:\\trt\\services",
  "Endpoints": {
    "EDB": { "Transport": "Files" },
    "CBR": { "Transport": "Http", "BaseUrl": "https://cbr.example.com/api", "TimeoutSeconds": 30 },
    "KAX": { "Transport": "Off" }
  }
}
```

Every call to an external system goes through `IServiceGateway` (`ServiceGateway.cs`). A call names:
- the service;
- an operation (`specifications`, `orders`, `invoke`);
- optionally a key and a body.

The transport is read on every call, so a change applies to the next call.

| Transport | Reading one item | Sending something | Listing |
|-----------|------------------|-------------------|---------|
| `Files` | `<Path>\<service>\<operation>\<key>.json` (or `.xml`) | written to `<operation>\outbox\<time>-<id>.json`; answered by `<operation>\reply.json` when present, else a receipt | every file in `<operation>` |
| `Http` | `GET {BaseUrl}/{operation}/{key}` | `POST {BaseUrl}/{operation}` with the body | `GET {BaseUrl}/{operation}` |
| `Off` | refused (503; integrations answer 501) | | |

**Error answers**
- **Missing items:** 404.
- **Unreachable services, timeouts or a missing folder:** 503.
- **Answers that cannot be read:** 502.

Integrations also go through the existing adapter health layer: timeouts, retries, a circuit breaker and a concurrency limit.

| Service | Folder | Used by |
|---------|--------|---------|
| EDB | `edb` | New request › from an EDB specification (`specifications\<id>.json`) |
| CBR | `cbr` | Spare cab orders (`orders\<order number>.json`) |
| KAX, VESPA, Dependix, DigitalTwin | `kax`, `vespa`, `dependix`, `digitaltwin` | Integrations (`invoke`) |

A new services folder is filled once with the shipped EDB specifications and CBR orders, plus a `README.md` that describes the layout.
