# Listener requests

Requests › **Listener requests** lists every message type that the request listener in swb-stable1
(`src/NVSComponents/GatewayComponents/Request.Listener`) handles, in every version: 64 message types and versions in
35 families. For each one you can read its contracts, write a request for a vehicle (or start from the contract), send
it and read the reply.

The page and its API (`/api/v1/listener`) work the way the listener does:

1. **Routing.** A message is sent to a message type and version, for example `GetKitEvaluation` 2.1. The listener
   joins them as `GetKitEvaluation_2.1` and finds the handler registered under that key. A key it does not know gets the
   listener's own answer: *Unhandled message type and version …*.
2. **Checking the request.** Before a handler runs, the request is checked in the listener's order:
   - well-formed XML, or error **101 InvalidXml**;
   - the `schemaVersion` attribute, when the request has one, against the contract version (for example 2.1 for the
     namespace `…/KitEvaluation/2_1`), or a version error;
   - the request XSD, or error **107 InvalidMessage**, with each problem and its line.

   A rejected request is not answered.
3. **Answering.** The handler for the message type answers. Every message type and version the listener handles is
   simulated. For a type without a handler, a request that passes the checks would get the notice
   *The tool does not simulate … yet* and no reply: the tool never makes up a reply.
4. **Checking the reply.** The reply is checked against the reply XSD. A simulated reply that does not follow its
   contract is reported, not hidden.

## What is simulated

| Area | Message types | Simulated |
|------|---------------|-----------|
| Audit | Ping 1.0, GetInfo 1.0 | All |
| Aftermarket | 20 message types and versions | All |
| Production | 12 | All |
| Development | 14 | All |
| Service Configurator | 6 | All |
| VCADS | 10 | All |

**Audit:**
- **Ping 1.0** takes any body and answers `OK`, like the listener.
- **GetInfo 1.0** answers with the listener's JSON fields: title, version, environment, machine, process, the message
  types this tool simulates, and the repository as its database. The tool takes messages over HTTP, so
  `messageHandlers` (the listener's message queues) is empty.

**Aftermarket.** Each message type answers from the catalog, with the same rules as the Requests pages. For example,
which node template versions a scenario allows, which hardware they take, and which kits a product class takes.
- **The product.** As in the listener, the product in the request is what is evaluated: its nodes (node template
  document, ECU hardware, main software, primary bootloader) and its variants. When the request lists no nodes, the
  vehicle with the same chassis in the repository is used instead. The reply's summary says which.
- **Vehicle contexts.** A vehicle outside your vehicle contexts is treated as unknown.
- **Writing a request.** *Write the request for this vehicle* writes a request with the vehicle's chassis, VIN, product
  class, variants and every node in Node 2.1 form (TEA2+, TEA2, BEA2 body and T3).
- **Errors.** They carry the listener's codes, in each contract's own error reply, for example:
  - 113, an unknown kit or one not for the product class;
  - 111, a kit state the scenario does not allow;
  - 130, not a service kit when only service kits are allowed;
  - 128, a kit already applied;
  - 103, a product without nodes that the tool does not have.

What each message type answers:

| Message type | Versions | What it answers |
|--------------|----------|-----------------|
| GetNewSoftwareExists | 1.0 | Whether any node has newer software (SoftwarePackage), or whether the newest service pack of the vehicle context changes a node (ServicePack). |
| GetReleaseNotes | 1.0 | The release note texts by id, in the asked language, falling back to the main language and then English. The ids are the ones the other replies give, one per node template version. |
| GetAvailableUpdates | 1.3, 2.1 | Per action criterion: the current software, newer software per node (remote criteria: only what can be downloaded remotely), the service pack, other hardware, and the kits of each type that apply. **DisplayLanguages** has no catalog data, so asking for it makes the reply Modified, with the reason. |
| GetKitEvaluation | 2.1 | The requested kits applied to each product, per criterion: Applicable or NotPossible, and the nodes they assign (hardware change, serial number) and remove. |
| GetCampaignEvaluation | 1.0 | Each kit evaluated on its own. An error becomes that kit's result with its message, not a rejection. |
| ESW_ASSIGNED_NODENAMES_IN_KIT_REQUEST | 1.0, 2.0 | The nodes a kit assigns and removes. Errors are an ErrorReport 1.1. |
| ESW_CONVERSION_KIT_REQUEST | 2.1, 3.0, 3.1 | The kits applied, as ProductUpdate 2.1, ProductsUpdate 1.0 or ProductsUpdate 1.1. |
| ESW_SOFTWARE_CONFIGURATION_REQUEST | 3.1 | Refresh, Repair, Update, Resolve or UpdateToServicePack on the requested nodes, as ProductsUpdate 1.1. |
| ESW_SPARECAB_BREAKDOWN_REQUEST | 2.0, 2.1 | The requested cab nodes broken down from the Baseline (a baseline of the vehicle context), as ProductsUpdate 1.1. |
| ESW_CAMPAIGN_REQUEST | 1.0 | The kit of a KitRequest 1.1 applied, as a CampaignResult. Any error is resultCode Error. |
| ESW_CAMPAIGN_REFRESH_REQUEST | 1.0 | The operation of a SoftwareRequest 1.6, as a CampaignResult. |
| ProductUpdateService | 1.0, 2.0 | The listener's JSON. The vehicle is found by its chassis and the New request simulation answers. |
| GetAvailableProductUpdates | 1.0, 1.1 | The same, answered as ShowAvailableUpdates. |

**The ProductsUpdate replies** give the product delta as the tool computes it:
- assigned and removed variants;
- the nodes that change, with their Node 2.1 body and the other hardware they run on;
- assigned and removed parameters (TEA2+ as ParameterValue 2.1 values, TEA2 as TEA2 values);
- assigned and removed S-notes.

They do not give the parts the catalog has no data for: source information, delta configurations, artifact SHAs,
distribution methods and dependent nodes.

**The T3 JSON services differ from the listener in three ways:**
- The tool answers from the vehicle in its repository, not from the product as sent.
- The nodes in the reply have the shape the New request pages use, for example the node name as text.
- Release note ids are document numbers.

**Production and Development.** These message types break the product down for a requested version, with the same
rules as Requests › New request › Production or Development breakdown:
- **Requested version.** A baseline guid gives each node template the baseline's version. An effectivity (factory and
  date) gives the newest released or introduced version by that week.
- **Node templates.** A template with a variant condition is used only when the product has one of its variants.
- **Requested nodes.** These limit the reply.
- **The bill of material.** Every reply carries one in BreakdownModuleCommon form, for the version of the message:
  - nodes with their hardware, software and data slots;
  - parameters (TEA2 values for TEA2, string values otherwise);
  - the baseline.
  - 2.0 and 2.1 put the T3 nodes under HpcNodes, each with its virtual TEA2+ node.
- **Problems are notifications, as in the listener.** They come in a normal reply, for example BASELINE WRONG CONTEXT,
  BASELINE MISSING, VARIANT UNKNOWN, S-NOTE UNKNOWN or NODE NOT IN BREAKDOWN.
- **Errors.** A request that cannot be read gets one TECHNICAL ERROR notification, or BAD REQUEST for a schemaVersion
  that does not match the message type. These replies carry no error code, as in the listener.

| Message type | Versions | What it answers |
|--------------|----------|-----------------|
| GetProductionSoftwareBreakdown, …TR | 1.4, 1.7, 2.0, 2.1 | The production breakdown of the product specification. TR is the same XML; in the listener it only uses another service behind it. |
| ESW_DEV_SOFTWARE_BREAKDOWN_REQUEST | 1.4 to 2.1 | The development breakdown of the product specification. |
| GetDevelopmentSoftwareBreakdownWithProduct | 1.4 to 2.1 | The same, for a full product (its nodes and variants as sent). |
| GetBOMConsistencyCheck | 1.4, 1.7, 2.0, 2.1 | The bill of material in the request, returned with notifications where it differs from the breakdown. |
| Evaluate | 1.0, 1.1 | Each issue's node. In the tool an issue id is a node template document number, because the catalog has no issue ids. |

**The consistency check** returns the request's own bill of material, as the listener does. It annotates each requested
node with these notifications:
- NODE TEMPLATE NOT OK: another node template document;
- ECU HARDWARE INCOMPATIBLE: hardware the node template does not take;
- SOFTWARE PART NOT OK: software parts other than the node template's;
- NODE NOT IN BREAKDOWN: a node the breakdown does not have.

Nodes of the breakdown that the bill of material lacks are reported on the reply. Nodes that are not requested, and HPC
nodes, are returned unchecked. The notification types are the tool's own words where the listener's exact ones are not
known.

**Version 2.1.** No 2.1 contract is among the files: they are only in the Volvo contracts package, which is not
available here. The listener's 2.1 code is its 2.0 code with 2.1 namespaces, plus two additions:
- an optional ProductSpecification/HWMaturity input;
- a TemplateId on HPC software products.

The tool answers 2.1 in the 2.0 shape with the 2.1 namespaces. The page and every 2.1 reply say that it cannot be
checked. HWMaturity is not read, because the catalog has no hardware maturity.

**What the bill of material leaves out:** compatible items and bootloader conditions, sources beyond the product class
and baseline, production tool operations, extra items, execution environments and software artifacts. The catalog has
no data for these.

**Service Configurator.** These answer from the catalog's node templates, variants, kits and parameter definitions:

| Message type | Versions | What it answers |
|--------------|----------|-----------------|
| GetParameterRecipe | 1.0, 1.1 | The variant changes that give the wanted parameter values (see below). |
| GetNewSalesParameterRecipe | 1.0 | The same, in the BOD form a new sale uses. |
| GetAftermarketParameterRecipe | 1.0 | What to do to the vehicle as it is to get the wanted values (see below). |
| GetCapabilityResourceBreakdown | 1.0, 1.1 | The parameters a product specification gets that are marked as a capability or a resource. |

- **Variant recipes.** A parameter value comes from a node template version of the product class's contexts.
  - A node template with a variant condition is used only with one of its variants. That variant is what to add, and
    another variant of the same family is what to delete.
  - Each combination of variants that does not conflict is one alternative recipe group.
  - A value no node template gives is NO RECIPE, as in the listener. A value the product already gets needs no change.
  - useUnreleasedData also counts versions in progress.
- **Aftermarket recipes** try, in the listener's order:
  1. a software refresh, when the node's current node template already gives the value;
  2. a software update to a newer node template that gives it;
  3. a conversion kit that sets it.

  A value the vehicle already has is left out. A value that nothing gives is NO RECIPE for that parameter.
- **Capabilities and resources** are marked on the parameter definitions in `catalog\paramDefs.json`, with
  `"capability": true` or `"resource": true`.
  - The reference catalog marks none. Until a definition is marked, the capability resource breakdown answers with the
    notification NO CAPABILITY DATA instead of inventing values.
  - Once any definition is marked, the aftermarket recipe refuses unmarked parameters (NOT RESOURCE OR CAPABILITY), as
    the listener does.
- **Error replies** are a TECHNICAL ERROR or BAD REQUEST notification in the reply root, with the service attributes.
  The listener's own CapabilityResourceBreakdown error reply leaves those attributes out, which its XSD requires; the
  tool writes them.

**VCADS.** VCADS names computers by MID and parts by field number, as TEA2 does.
- **Field numbers.** The catalog has field numbers for TEA2 and BEA2 body parts. For TEA2+ and T3 parts the tool numbers
  the slots itself:

  | Slot | Field numbers |
  |------|---------------|
  | ECU hardware | 1 |
  | Node template (NTP) | 2 |
  | Main software | 10 and up |
  | Downloader or primary bootloader | 20 |
  | Secondary bootloader and sub software | 30 and up |
  | Data sets | 40 and up |
  | Complementary software | 50 and up |
  | Sub data sets | 60 and up |
  | Software functions | 70 and up |

- **The vehicle.** It is the one in the repository with the chassis. The complete vehicle versions read the parts as
  the request gives them instead.
- **Replies.** They are the bare Workflow, HardwareResponse or CompleteVehicle, as the listener writes them, with a
  CamsResult:
  - Ok on success;
  - otherwise the listener's error code: VDA_ChassisMissing for an unknown chassis, Configurator_Internal for a missing
    vehicle field, Failed for the rest;
  - always with "Message: " and the text.

| Message type | What it answers |
|--------------|-----------------|
| GetVCADSSoftwareReplacement, …CompleteVehicle…, …TestRequest… | The requested computers updated by the software update rules: one Workflow step per computer, with its part and TEA2 parameter operations. |
| GetVCADSHardwareReplacement, …TestRequest… | Per requested computer, the other ECU hardware that a kit of the catalog fits, with the kits. |
| GetVCADSKitInformation, …CompleteVehicle…, …TestRequest… | Per kit, its step: the computers it affects and its part, variant, S-note and parameter operations. A kit that does not apply is skipped; when none applies, the reply is Failed. |
| GetVCADSCompleteVehicle | The vehicle with its parts (software, then ECU hardware, then node templates), parameters, variants and S-notes. |

The TestRequest versions also allow what the introduction-date-set scenario allows: kits and node templates that are in
progress. As in the listener, the TestRequest software replacement does not.

## Contracts

The XSDs come from SoftwareBreakdown.Contracts (115 files). They are built into
`Volvo.TestRequestTool.Infrastructure`, under `Contracts/Schemas`. `Contracts/listener.json` is the registry: each message
type and version, its area, its handler in the listener, and its request and reply contracts (the file, root element and
namespace).

- **Start from the contract** writes the smallest request the XSD accepts: every required element and attribute, the
  first branch of each choice, and example values. Optional content, such as the nodes or kits to ask about, is left for
  you to fill in. A unit test checks that every sample, request and reply, follows its own contract.
- Two contracts import a patch release that is not among the files (`ReleaseNotes_1.0.0`,
  `BreakdownModuleCommon_1.5.0`). Like `SchemaSet.cs`, the tool uses the newest patch of the same version instead (1.0.2
  and 1.5.2).
- **Missing contracts.** The listener handles some versions for which SoftwareBreakdown.Contracts has no XSD. These are
  listed on the page as *not checked*:
  - both sides of the 2.1 breakdowns and checks: GetProductionSoftwareBreakdown (and TR), GetBOMConsistencyCheck,
    ESW_DEV_SOFTWARE_BREAKDOWN_REQUEST and GetDevelopmentSoftwareBreakdownWithProduct;
  - the reply of GetVCADSCompleteVehicleKitInformation 1.0.
- **Replies taken from the listener.** For two replies, the contract comes from the listener's handler, because
  SchemaSet.cs does not give a usable one. The page says why:
  - ESW_ASSIGNED_NODENAMES_IN_KIT_REQUEST 1.0 uses AssignedNodesInKitReply 1.1.3 (SchemaSet.cs names 1.1.2, which is
    not among the files);
  - ESW_SPARECAB_BREAKDOWN_REQUEST 2.1 uses ProductsUpdate 1.1.
- **Error replies in their own contract.** The assigned-nodes message types answer errors with an ErrorReport 1.1, and
  the check uses that contract for them.
- **The T3 services** (ProductUpdateService 1.0 and 2.0, GetAvailableProductUpdates 1.0 and 1.1) take JSON, so there is
  no XSD to check. MessageTypes.cs in the contracts does not name them, so the page shows their constant names.

## Refreshing the contracts

When the contracts or the listener change:

```bash
python scripts/import-contracts.py "<path to>\SoftwareBreakdown.Contracts" "<path to>\swb-stable1\src"
```

The script reads `MessageTypes.cs` and `SchemaSet.cs` from the contracts, and the registrations in
`NVSComponents/HostCommon/AbstractDependencyInjector.cs` from the listener. It copies the XSDs and writes
`listener.json`, and lists any side that has no contract. It needs only Python's standard library.

## Adding a simulated message type

1. Implement `IListenerHandler` (`Volvo.TestRequestTool.Application`). For XML, derive from `ListenerXmlHandler`,
   which turns a `ListenerFault` into the contract's error reply. Use `ListenerProducts` to read and write products and
   `ListenerCatalog` for the catalog rules. The handler has these parts:
   - `Keys` are the message types and versions it answers, for example `GetKitEvaluation_2.1`;
   - `HandleAsync` answers a checked request;
   - `Reject` answers a request that failed the checks, with the contract's own error reply where it has one (for
     example a Show element with Rejected).
   - `Example` (`IListenerExample`, or `IListenerJsonExample` for JSON) writes a request for a vehicle.
2. Add it to `AftermarketHandlers.Create`, or register it in `Program.cs` for another area.
3. The dispatcher checks both sides. `AftermarketListenerTests` writes a request for every reference vehicle and every
   simulated message type, sends it, and fails on any request or reply that leaves its contract. A new handler is
   covered as soon as it is in the list.
