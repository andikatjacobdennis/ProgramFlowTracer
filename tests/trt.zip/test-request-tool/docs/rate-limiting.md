# Rate limiting

Implemented in `src/Volvo.TestRequestTool.Web/RateLimiting.cs` on ASP.NET Core's RateLimiter middleware and configured in the
`RateLimiting` section of `appsettings.json`. The section is validated at start-up: an invalid rule stops the
application with a message naming the rule.

## Policies

Limits apply per person: the signed-in user's id, or the client address before sign-in. "auth" always partitions by
address.

| Policy | Kind | Default | Applies to |
|---|---|---|---|
| api | sliding window | 1200 / min | every /api call (global) |
| status | fixed window | 6000 / min | GET session and job status, so polling keeps working while throttled elsewhere |
| simulation | token bucket | 60 / min, burst 20 | validations, previews, batch starts |
| reads | sliding window | 240 / min | change impact, readiness, insights, traces, the requests hub |
| writes | fixed window | 60 / min | review requests, comments, decisions, withdrawals, submissions |
| exports | fixed window | 20 / 10 min | logs, receipts, vehicle downloads |
| assistant | token bucket | 30 / min, burst 10 | simulated assistant |
| feedback | fixed window | 10 / 10 min | feedback messages |
| auth | fixed window | 20 / min per address | demo sign-in and switching users |

- Both the global policy and the endpoint's own policy must allow a call.
- Health checks, static files and `/api/v1/loadtest` are outside the global limit. The load-test endpoints have their
  own token bucket and concurrency cap.

## Configuration

Every field of every policy can be overridden, and new policies added:

```json
"RateLimiting": {
  "Enabled": true,
  "Policies": {
    "reads": { "Kind": "sliding", "Limit": 480, "WindowSeconds": 60, "Segments": 6 },
    "exports": { "Kind": "fixed", "Limit": 5, "WindowSeconds": 300, "ExemptRoles": ["Admin"] }
  }
}
```

Each rule takes these fields:

| Field | Values |
|---|---|
| Kind | fixed, sliding, token or concurrency |
| Limit | at least 1 |
| WindowSeconds | at least 1 |
| Segments | for a sliding window |
| Burst | for a token bucket |
| Queue | 0 or more |
| PartitionBy | user or ip |
| ExemptRoles | roles that bypass the rule |

`Enabled: false` keeps every named policy in place but lets every call through.

## What clients see

- Every limited response carries `RateLimit-Policy`, for example `"reads";q=240;w=60, "api";q=1200;w=60`
  (draft-ietf-httpapi-ratelimit-headers).
- A refused call is **429** with:
  - `Retry-After` (seconds);
  - `RateLimit: "reads";r=0;t=12`;
  - a problem body: `{ title: "rate_limited", policy, retryAfterSeconds, retryable: true, detail }`.
- The web client turns a 429 into a message that names the wait time ("Too many requests right now. Try again in
  12 s.").

## Operations

- Metric `testrequest.ratelimit.rejected` (meter `Volvo.TestRequestTool.RateLimiting`), tagged by policy.
- `GET /api/v1/admin/rate-limits` (administrators) lists:
  - each policy with its limits, the number of endpoints using it and rejections in the last hour and since start;
  - the latest 50 rejections, with partition keys hashed.

## Tests

`tests/Volvo.TestRequestTool.IntegrationTests/RateLimitTests.cs` covers:

- the limit, the 429 body and headers, and the policy header;
- independence between policies and between people;
- the per-address "auth" limit;
- the administrators' view and hashing;
- `Enabled: false`;
- refusing an invalid configuration at start-up.
