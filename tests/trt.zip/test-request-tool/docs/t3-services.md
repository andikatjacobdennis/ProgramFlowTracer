# T3 services: Product Update Service and Available Product Updates

Two request kinds model the JSON aftermarket services that support T3 HPC nodes. Both run on the bundled demo catalog. Their request and response field names follow the live contracts; the processing is simulated.

| Request kind | Contract | Versions | Changes the vehicle |
|---|---|---|---|
| `ProductUpdateService` | ProductUpdateService (`ProductUpdateRequest` / `ProductUpdateResponse`) | 1.0, 2.0 | Proposes a product update (validated like a software request; VDA changes only through an explicit commit) |
| `AvailableProductUpdates` | GetAvailableProductUpdates (`GetAvailableUpdates` / `ShowAvailableProductUpdates`) | 1.0, 1.1 | No, it only lists what could be updated |

## Contract references

- **Gateway handlers**, repository `swb-stable1`, folder `src/NVSComponents/GatewayComponents/Request.Listener/Aftermarket/`: `ProductUpdateService_1_0`, `ProductUpdateService_2_0`, `AvailableProductUpdates_1_0`, `AvailableProductUpdates_1_1` (request parsers, `JsonNodeCreator`, response builders and validation message builders). Handler registration is in `src/NVSComponents/HostCommon/AbstractDependencyInjector.cs`.
- **Execution map**: `Sample/Understanding/ProductUpdateService_v1.0_Execution_Map.pdf` in the T3 inputs (processing order, service-pack selection, HPC upgrade-path check, response sections).
- **XSD contracts**: `Sample/SoftwareBreakdown.Contracts` in the T3 inputs. These cover the XML `GetAvailableUpdates` 1.2/1.3/2.1, ProductUpdate 2.0/2.1 and ProductsUpdate 1.0/1.1 contracts. They have **no T3 constructs**, so the action-criteria vocabulary, `Show` status block, `ServicePack{guid,name,exactMatch}` and release-note shapes are taken from them, and the HPC node shape from the JSON gateway handlers.
- The JSON schemas themselves (`Contracts.Json.*`) are published in a separate package that is not part of these inputs. Field names here follow the handlers that read and write them.

## Product Update Service

**Request** (`POST /api/v1/requests`, `kind: "ProductUpdateService"`): `schemaVersion` (`"1.0"` or `"2.0"`, default 2.0), `criteria.scenario`, and for 2.0 `criteria.operation.operationType`. The server builds the contract `product` block (identification, description, specification, `configuration.nodes[]` as `tea2PlusNode` or `hpcNode`) from the loaded vehicle.

- **1.0** always runs `UpdateToServicePack` (the operation is hard-coded, `criteria.updateTo.latestServicePack` is accepted and has no effect).
- **2.0** accepts `UpdateToServicePack` or `Repair`.
- Scenarios: `Introduced`, `IntroductionDateSet`, `Released`, `PreReleaseVerification`, `InProgress` (case-insensitive).

**Processing** (as in the execution map):

1. Candidate service packs are those in the vehicle context that **every** documented node can reach, sorted newest first by SortOrder, then Guid.
2. Each candidate is tried in turn. A node's target version must be allowed by the scenario. Nodes already on or beyond the pack are left as they are.
3. **HPC upgrade-path gate** for T3 nodes: the target version must support the installed ECU hardware, and its dependencies must be met within the same pack. In production this is the Matrix upgrade-path lookup; here it is evaluated against the catalog.
4. The first candidate that passes is applied. Rejected candidates are returned with their reasons in `rejectedCandidates` (a Studio addition, not part of the contract).

**Response** (`serviceResponses.products[].response`): `{schemaVersion, traceId, productUpdate:{customerAdaptationUpdates, nodes, parameterUpdates, releaseNotes, updatePurposes, variantUpdates, servicePack{guid,name}}}`. HPC nodes are returned as `hpcNode` with `executionEnvironments[].softwareProducts[]`. Errors are `{schemaVersion, traceId, errors:[{type, text}]}`.

## Available Product Updates

**Request** (`kind: "AvailableProductUpdates"`): `contractVersion` (`"1.0"` or `"1.1"`, default 1.1), `criteria` with `scenario`, `actionCriteria`, `enableMultiNodeBehavior`, `pblUpdateCapable`, `languageCode`, `semsSupport`, `includeUpdatePurposes`, `includeReleaseNoteSource`, `includeDocumentNumberOnlyChange`, and optional `requestedNodes`.

- **1.0**: `actionCriteria` is a comma-separated string.
- **1.1**: `actionCriteria` is a JSON string array; software products in the response add `id` and `templateId`.
- Action criteria: `SoftwareReplacements.CurrentSoftware`, `.General`, `.RemoteGeneral`, `.RemoteLimited`, `.RemoteCapable`, `.ServicePackGeneral`, `.ServicePackRemoteGeneral`, `.ServicePackRemoteLimited`, `.ServicePackRemoteCapable`, `HardwareReplacements`, `DisplayLanguages`, `AccessoryKits`, `ServiceKits`, `AdministrativeServiceKits`, `CampaignKits`, `HardwareKits` and the `Remote…Kits` variants.

**Response**: `ShowAvailableProductUpdates` with `ApplicationArea` (LogicalID `SWBRKDWN`, service `SRV12921`) and `DataArea`: `Show{ResponseCriteria, StatusCode, StatusText}`, `SoftwareNodeReplacements[]` (`actionCriteria`, `AssignedNodes.Node[]`, optional `ServicePack`, `ReleaseNotes`, `UpdatePurposes`), `HardwareNodeReplacements`, `DisplayLanguages` and `Kits[]`.

`Show` is `Accepted`/`0` when every criterion succeeds, `Modified`/`1` when some fail but there are results, and `Rejected`/`-1` when none produce results. Failed criteria are listed as `ActionCriteria '<name>' failed: <reason>`.

## Error codes

| Code | Meaning | Examples |
|---|---|---|
| 0 | Success | |
| 100 | Unhandled / schema failure | PUS `Schema validation failed: criteria.scenario …`, unknown contract version, APU `Unhandled scenario: …` |
| 107 | Invalid message / no valid configuration | `ProductUpdateService_2_0 only supports UpdateToServicePack or Repair. Received: …`, `Logical ECU definition not found for 50.1`, no valid service pack, APU `Action critera cannot be null or empty.`, `… is not a valid Action criteria type`, `Schema validation failed.` |

Validation messages keep the live spelling, including "critera".

## Simulated, not live

- RepoLib, EvalService/SnapshotRunner and Matrix are not called. Execution environments come from the vehicle's software products and the catalog's node templates.
- `compatibleHardwares` is always empty, and affected/dependent nodes are not emitted, as in the live services.
- Display languages are empty for T3 vehicles, and kits have no remote availability in the demo catalog.
- The upgrade-path gate checks catalog hardware and dependencies only.

## In the application

- **Configure** stage, T3 vehicles: *Update to service pack* and *Available product updates* open the request dialog for the matching kind.
- **Validate** stage: the *Product Update Service* card shows the chosen service pack, software products per execution environment, release notes, rejected candidates and the contract JSON.
- **Available product updates** dialog: results by action criteria, hardware replacements, kits and the contract JSON.
- **Get request JSON** in the request dialog calls `POST /api/v1/requests/preview`, which returns the contract request without running validators or recording history.
