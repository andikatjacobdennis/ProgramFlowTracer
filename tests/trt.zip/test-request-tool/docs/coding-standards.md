# Coding standards

The C# code follows the conventions of the SoftwareBreakdownService code base (swb-stable1). Projects are named like their namespaces, so the project, its folder, its assembly and its root namespace all read `Volvo.TestRequestTool.<Component>`.

## Names and projects

| Item | Convention | Example |
|------|------------|---------|
| Solution | `TestRequestTool.slnx` | |
| Project, its folder and file | `Volvo.TestRequestTool.<Component>` | `src/Volvo.TestRequestTool.Web/Volvo.TestRequestTool.Web.csproj` |
| Assembly | `Volvo.TestRequestTool.<Component>` | `Volvo.TestRequestTool.Web.dll` |
| Root namespace | `Volvo.TestRequestTool.<Component>` | `Volvo.TestRequestTool.Infrastructure` |
| Namespace of a file in a sub-folder | the root namespace plus the folder names | `Volvo.TestRequestTool.Web.Admin` |
| Company, product, copyright | set once in `Directory.Build.props` | AB Volvo, TestRequestTool |

The components are:
- Domain: records and rules;
- Application: ports, handlers and validators;
- Infrastructure: the repository, the service gateway and the catalog;
- Web: the API, sign-in, hosting and the UI;
- UnitTests and IntegrationTests.

## Files and types

- One type per file, and the file is named after the type: `WorkspaceRepository.cs`, `IDocumentStore.cs`, `UserAccount.cs`.
- Interfaces start with `I` and have their own file.
- Nested types stay with the type they belong to.
- The exception is `Program.cs`, which keeps the top-level statements and the `partial class Program`.

## Layout

- **Namespaces:** block-scoped, `namespace Volvo.TestRequestTool.Web { … }`.
- **Usings:** outside the namespace, `System` first.
- **Braces:** on their own line (Allman). `if`, `else`, `for`, `foreach`, `while` and `using` always have braces.
- **Statements:** one per line. A short expression-bodied member (`=> …`) is fine.
- **Spacing:** four spaces of indentation, and spaces around binary operators and after commas.

## Members

- **Dependencies:** injected through an explicit constructor and kept in `private readonly` fields named `_camelCase`. There are no primary constructors on classes; positional records stay as they are.
- **Private instance fields:** `_camelCase`.
- **Private static readonly fields and constants:** `PascalCase`.
- **Asynchronous methods:** end in `Async`.
- **Local variables:** `var` when the type is clear.

## How it is kept

- **`.editorconfig`** holds the layout and naming rules. Run `dotnet format TestRequestTool.slnx` before committing to apply the layout.
- **Build:** warnings are errors (`TreatWarningsAsErrors`).
- **Review:** the one-type-per-file and constructor rules are checked in review.
