# Architecture

The solution keeps web concerns outside the domain and uses application-owned ports for every replaceable adapter. `Program.cs` is the composition root. Project dependencies point inward:

| Project | References | Responsibility |
|---|---|---|
| Domain | .NET BCL only | Product facade, normalized vehicle IDs, issues, request/results, lossless JSON and fingerprints |
| Application | Domain | Request dispatch, six handlers, ordered validation, product deltas, delivery rules, XML codec and ports |
| Infrastructure | Application | Embedded demo catalog, atomic file repository and explicit unconfigured integration adapters |
| Web | Application, Infrastructure | Versioned Minimal APIs, authentication, context permissions, rate limiting, Problem Details, static colour UI and backend bridge |
| UnitTests | Infrastructure transitively references inner layers | Domain, handlers, validation, persistence and extension-point tests |
| IntegrationTests | Web | In-process HTTP tests with WebApplicationFactory and isolated storage |

See `architecture.svg` for the architecture drawing and `architecture.mmd` for editable Mermaid source. Solid paths describe delivered behavior. The dashed extension path describes future adapters.

## Request lifecycle

1. The bridge sends the existing product JSON as an explicit request payload. Unknown product fields remain in the document.
2. The application validates batch size and uniqueness and loads authoritative originals from the repository. It authorizes **all** contexts before invoking handlers or storing a result. The client's context field cannot grant access.
3. The handler prepares a copy. The original document and vehicle repository remain unchanged during simulation.
4. Validators run in deterministic order. The included checks cover documented catalog nodes, hardware, dependencies, parameter constraints and variant families. A blocking issue keeps the input proposal unchanged unless limited validation was explicitly allowed. Limited results cannot use delivery operations.
5. The repository stores an actor-owned execution record with input/proposal hashes, base revision, issues and proposal snapshots.
6. Kit creation derives changes from the repository original, including manual edits. VDA commit uses the stored validated snapshot and a matching base revision. A second commit of the same revision fails with 409.

## Extension recipes

### Add validation

Implement `IProductValidator`, give it a unique `Name` and deterministic `Order`, and register it in the composition root. Return structured issues rather than mutating repository state. `PersistenceAndExtensionTests` demonstrates plug-in validators and ordering. No dispatcher edit is necessary.

### Add or replace an operation

Implement `IRequestHandler` for one `RequestKind`. Register exactly one handler per kind. Keep transport DTOs outside the domain and propagate `CancellationToken`. A custom-handler test demonstrates replacing a handler without modifying `RequestService`.

### Replace persistence

Implement `IWorkspaceStore` with a transactional database. Keep actor isolation and optimistic revision checks. The delivered file adapter uses a semaphore, immutable read copies, a same-directory temporary file and atomic rename. It is designed for **one application process**. Multiple app instances require a database adapter with cross-process transactions. JSON schema version 1 is explicit and unsupported versions fail startup instead of overwriting data.

### Connect external systems

Replace the relevant `IExternalCapability` registration. The supplied KAX, VESPA, Dependix and Digital Twin capability adapters all report `IsConfigured=false` and return 501 when invoked. For real validation, also register an `IProductValidator` that calls the adapter. For Digital Twin delivery, add explicit target authorization, a durable outbox, idempotency and reconciliation against the approved specification. Registering a capability alone does not automatically make it a validation step.

## Authentication and deployment

Development and Testing may use the fixed demo identity. Its permissions come from server configuration, not browser settings or request headers. Production fails startup unless JWT authority/audience are configured. Expected JWT claims are `sub`, repeated `context` values and `role=Writer` for delivery. The static browser client currently demonstrates same-origin development authentication. A production browser deployment needs an OIDC/BFF session or another deliberate token-acquisition integration.

Demo data, mock service semantics and browser compatibility mode are examples, not production integrations. Remove or gate compatibility mode and its static mock data when deploying with real vehicle data. Add field-level redaction, audit/retention policy, operational monitoring and contract validation appropriate to your real adapters.

## Source references

- Supplied `Sample.zip`: “Capability - Test Request Feature needed for T3”, T3EXV-71 / T3EXV-258.
- Supplied `testreq.zip` and the colour simulator created in this conversation.
- Microsoft ASP.NET Core 10 integration testing: https://learn.microsoft.com/aspnet/core/test/integration-tests?view=aspnetcore-10.0
- .NET 10 release metadata used to select SDK/package versions: https://dotnetcli.blob.core.windows.net/dotnet/release-metadata/10.0/releases.json
