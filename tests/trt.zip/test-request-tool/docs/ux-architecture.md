# Pages, settings and the shared UI kit

Everything added in this upgrade lives in `src/Volvo.TestRequestTool.Web/wwwroot/js/app/` and `css/app-shell.css`. The older scripts
(`testrequest.js`, `experience.js`, `polish.js`) are untouched apart from a few hooks. New screens do not wrap those scripts again; they register
with one small registry instead.

| File | What it owns |
|---|---|
| `js/app/core.js` | `TR.prefs` (settings with defaults), `TR.pages` (page registry, breadcrumbs, theme cycle), `TR.pager` (the list pager), `TR.nextStep` (the coloured next-step button), go to top, motion and theme buttons |
| `js/app/culture.js` | Country, language, time zone, currency and date and time formats; flags; the quick switch in the top bar |
| `js/app/settings.js` | The Settings page: one declarative `SETTINGS` list, search across all of it |
| `js/app/vehicle.js` | The Vehicle page: Graph, Roadmap and History tabs |
| `js/app/activity.js` | The Activity page: your requests as a paged table |
| `js/app/about.js` | The About page |
| `css/app-shell.css` | Styles for all of the above, using only the theme tokens from `testrequest.css` |
| `Application/VehicleInsights.cs` | Server side of the Vehicle page: timeline, snapshots and roadmap |
| `Web/InsightEndpoints.cs` | `GET /vehicles/{series}/{number}/timeline`, `/timeline/{entryId}`, `/roadmap` and `GET /about` |

Scripts load in `index.html` after `polish.js` and before `boot.js`: `core.js` first, then the pages.

## Add a page

```js
(function () {
  const { h } = TR.util;
  const { ui } = TR.pages;          // heading, button, chip, api, when, day, motionOn, slashFocus
  TR.pages.register({
    id: 'reports',                  // opens with TR.pages.show('reports') or /?view=reports
    title: 'Reports',
    crumbs: () => [{ label: 'Reports' }],   // Home is added in front automatically
    render: () => h('div', null, ui.heading('Reports', 'One sentence that says what the page is for.')),
  });
})();
```

Add a `<script src="js/app/reports.js">` line to `index.html`. To show it in the sidebar, add a `nav(...)` entry in `testrequest.js` like
the About entry, and a label in `markActiveNav` in `core.js` so it is highlighted.

Long lists use the shared pager so every table behaves the same:

```js
const size = Number(TR.prefs.get('pageSize'));
const { rows, page } = TR.pager.slice(items, state.page, size);
// …render rows…
TR.pager({ total: items.length, page, size, label: 'reports', onPage: (n) => { state.page = n; TR.app.refresh(); }, onSize: (n) => TR.prefs.set('pageSize', n) });
```

It shows "Showing a – b of z", then First, Previous, five page numbers, Next, Last and "of N", the same layout as the DocGen Explorer
token table.

## Add a setting

1. If it stores a value, add a default to `DEFAULTS` in `core.js`. It is saved as `trstudio.<key>` in this browser.
2. Add one entry to `SETTINGS` in `settings.js`:

```js
{ section: 'workspace', id: 'compact', title: 'Compact tables', description: 'Shows more rows on screen.', keywords: 'dense density',
  control: () => toggle('Compact tables', prefs.get('compact'), (v) => prefs.set('compact', v)) },
```

Search covers the title, the description, the keywords and the section name, so add the words a user would type. `prefs.set` saves,
re-applies `data-*` attributes on `<html>` and re-renders. Read the value anywhere with `TR.prefs.get('compact')`.

## The next-step button

`nextStep()` in `core.js` returns one action for the current state, in order: add a vehicle, fix a blocked result, deliver, review,
validate again, validate, plan a change, update to a service pack, choose a change. Blue means continue, green means ready, amber means
something needs attention. Add a state by adding one `if` in the right place; keep the label short and the hint one phrase.

## Help, Asha, the tour and shortcuts

- `js/app/help-articles.js` holds every Help article as data: topic, title, summary, keywords, Asha's tip and sections with
  steps, lists, notes, live tables and *Try it* actions. Add an article by adding an entry; actions and tables are named and
  implemented once in `help.js` (`ACTIONS`, `TABLES`). Search covers titles, keywords and all text.
- `TR.help.persona(mood, size)` draws Asha (moods `wave`, `think`, `cheer`); `TR.help.guide(tip, mood)` adds her speech bubble.
  Use them for empty states and summaries. Her animations stop when motion is off.
- `js/app/tour.js` is the introduction tour: an array of steps `{ page?, prepare?, target, title, text }`. It reads each step
  aloud with the Web Speech API, choosing the most natural voice for the user's language.
- `js/app/shortcuts.js` is the one place for keyboard shortcuts: `TR.shortcuts.add({ keys, label, group, when, run })`. The `?`
  sheet, the Settings row and the Help article list whatever is registered.

## Insights and the dashboard

- `js/app/insights.js`: `TR.insights.model(...)` turns one vehicle's timeline and roadmap into numbers (version periods per
  computer, up-to-date counts, waiting updates, most changed, activity per day); `render(...)` draws the Insights tab.
- `js/app/dashboard.js` runs the same model for every vehicle the user may read and `summarise(...)` adds fleet numbers
  (attention ranking, release pipeline, service packs, request outcomes, people). Both are pure functions with tests.

## Motion and themes

- Pages fade and rise in when they open (`.ap-enter`), lists and cards stagger and lift; see "page motion" in `app-shell.css`.
- Motion off sets `data-motion="reduced"` on `<html>`. One CSS rule in `app-shell.css` removes all animation and smooth scrolling. Code
  that scrolls asks `TR.pages.ui.motionOn()`. The operating system's reduce-motion setting is always honoured.
- Themes are Auto, Light Charcoal and Dark Charcoal. Auto resolves to a palette from the operating system. `data-theme` holds the
  palette, `data-theme-choice` the choice. Palettes are the DocGen Explorer tokens in `testrequest.css`. Use the tokens (`--panel`,
  `--accent`, `--muted` and the rest), never literal colours, and both themes work.
- The UI guide (`guide/theme.js`) reads the same stored choice and motion setting.

## Culture

`culture.js` decides how every date, time, number and amount of money is shown.

- **Default:** the country of the user's account (`country` in `/api/v1/session`, from the `country` claim or the demo account) with that
  country's first language, first time zone and currency. India gives English (India), Asia/Kolkata (IST) and INR. Without a country
  the default is UTC: English, ISO dates (2026-10-19 08:39 UTC) and a 24-hour clock.
- **Settings → Language and region:** country (flags), language, time zone, currency, date format and clock. Choosing a country resets
  language, time zone and currency to its defaults; each can then be changed. **Use system settings** follows the computer instead.
- **Quick switch:** users keep several cultures and switch live with the flag button in the top bar, or Alt+Shift+C.
- Format with `TR.culture.format.dateTime(d)`, `date(d)`, `time(d)`, `number(n)` and `money(n)`; `TR.pages.ui.when` and `day` already do.
  Older screens that call `toLocaleString()` without a locale also get the culture's language, time zone and clock.
- Language controls formats (month names, digit grouping). The application text itself is English.

To add a country, add one entry to `COUNTRIES` (code, name, languages, time zones, currency) and one drawing to `FLAGS` in
`culture.js`. The list holds the Volvo Group markets used in this application; confirm it against the markets you support.

## Vehicle history

The server records every VDA commit with who made it (`Actor.DisplayName`), why (the request kind) and a full snapshot
(`VehicleRevision`). The timeline also shows kits and your own simulations. For catalog vehicles it derives a demo past (factory
build, an optional workshop update and the first VDA record) from the catalog, so a new installation already has history to look at.
The Graph tab can compare the current configuration with any entry that has a snapshot, shown like a code diff: the earlier
value in red with a minus, the value now in green with a plus.

The History tab (`js/app/history-graph.js`) draws the timeline like a git history. Changes to the vehicle are the main line;
simulations and kits started from the same revision share a branch from that revision; a committed simulation has its own branch
that joins the main line at its commit; a kit sits on the branch of the simulation it was made from. The server sends the links
(`lane`, `parent`, `base`, `mergedInto`, `from`) and pages (`?skip=&take=`); the page loads the next page as the end of the list
scrolls into view, with placeholder rows while it loads. Each entry shows a GitHub-style diffstat and, when opened, its changes as
red and green diff lines.

Diff colours are the `--added`, `--removed`, `--replaced` and `--modified` tokens in `testrequest.css`, set to the GitHub palette in both
themes, so the two-pane workbench, the review comparison and the Vehicle page all use the same red and green.
