# Adding an interface language

The code is written in US English. Every other language is a **language pack**: a JSON dictionary from the English
text to the translation. Adding a language needs no code change.

## How it works

- `wwwroot/i18n/languages.json` lists the installed packs: code, native name, English name, locale, direction (`ltr` or
  `rtl`) and file. English is built in. `qps` (Pseudo) is generated for testing.
- A pack (`sv.json`, `de.json`, `hi.json`, …) has `strings`: `{ "Settings": "Inställningar", … }`. Keys are the English
  text exactly as in the code, including `{placeholders}`.
- `TR.i18n.t(text, vars)` returns the translation. When a text is missing, it falls back along the chain:
  `pt-BR` → `pt` → English.
- **Text that never goes through `t()`** (older screens build English strings directly) is translated on screen. A
  MutationObserver looks up each new text node, and the `placeholder`, `title`, `aria-label`, `alt` and `data-tip`
  attributes, in the dictionary:
  - exact text first, then patterns such as `Revision {n}` (which matches "Revision 4");
  - data is never translated: inputs, `code`, `pre`, `kbd`, anything inside `translate="no"` or `data-i18n="off"`, and
    any text not in the dictionary;
  - originals are kept, so switching back to English restores them.
- Packs are fetched only when chosen. While the language is English, nothing extra runs.
- **Plurals:** a value may be `{ "one": "{n} ändring", "other": "{n} ändringar" }`. `Intl.PluralRules` picks the form
  from `n` (or `count`).
- `<html lang>` and `dir` follow the active pack, so screen readers use the right voice and right-to-left languages lay
  out correctly. The tour voice uses the pack's locale.

## Countries with several languages

A country can have several languages. `culture.js` lists them per country, for example:

| Country | Languages |
|---|---|
| India | en-IN, hi-IN, ta-IN, kn-IN, mr-IN |
| Belgium | nl-BE, fr-BE, de-BE |
| Canada | en-CA, fr-CA |
| Sweden | sv-SE, en-SE |

- People choose their country's language under **Settings → Language and region → Language**.
- **App language: Auto** follows that choice when a pack exists for it, for example Hindi for India with hi-IN. Without
  a pack it falls back to English, never to another language of the same country.
- The App language list shows your country's installed languages first, marked "your country". The setting's detail
  line names every language of your country and says which have no pack yet.
- Regional packs win over their base language (`fr-CA` before `fr`). A team or organisation can manage the App language
  for its members (Administration → Teams).

## Adding a language: step by step

1. Run `node scripts/i18n-extract.js`. It writes `wwwroot/i18n/template.json`: every text the code passes to `t()`, with
   empty values and where each is used.
2. Copy it to `wwwroot/i18n/<code>.json` (a BCP 47 code: `ta`, `fr-CA`, `pt-BR`) and translate the values.
   - Keep every `{placeholder}`.
   - Leave a value empty when unsure: English is shown for it.
3. Add one line to `languages.json`, for example
   `{ "code": "ta", "name": "தமிழ்", "english": "Tamil", "locale": "ta-IN", "dir": "ltr", "file": "ta.json" }`.
4. Run `node tests/frontend/i18n.cjs`. It checks that every pack is valid JSON, is listed, keeps every placeholder and
   has complete plural forms.
5. Restart the server: it reads the manifest at start-up (`UiLanguages.cs`), so team and organisation settings accept
   the new code.

## Finding what is still untranslated

- `node scripts/i18n-extract.js --report` prints the coverage of each pack.
- In the app, **Settings → Language and region → Language packs and translation**:
  - **Check coverage** shows the coverage of the active language and the texts seen on screen without a translation;
  - **Download template** gives the pack for the active language with every key, translations already filled in;
  - **Test with pseudo-language** accents, brackets and lengthens every text, so clipped or untranslatable text stands
    out.
- `scripts/i18n-seed.py` seeds the Swedish, German and Hindi packs from one table. It never overwrites a translator's
  work.

## Current state

| Pack | Coverage |
|---|---|
| Svenska (sv-SE) | about 370 strings: navigation, actions, the request journey pages, Logs |
| Deutsch (de-DE) | the same keys |
| हिन्दी (hi-IN) | the same keys |

That is about 23 % of the 881 texts that pass through `t()`, plus the static screen texts the dictionary pass covers.
The rest shows in English until translated. The error pages carry their own English and Swedish texts (`error-art.js`).
