# AI readiness: chat, summaries and agent previews (simulated)

The Test Request Tool has interfaces for generative AI. All AI features are **off by default**. When they are switched on,
a **simulated provider** answers. It is deterministic and rule-based, and needs no AI service, model or credentials.
Nothing here is real AI. Every surface says so: "Simulated assistant — no AI service connected" and "Simulated summary".

## Feature flags

| Flag | Default | Turns on |
|---|---|---|
| `ai` | off | The overall switch. Off hides every AI entry point, refuses every `/api/v1/assistant/*` call (404 `feature_off`) and loads no AI code in the browser. |
| `ai-chat` | off | The assistant panel (header button) and `/assistant/chat`, `/assistant/chat/stream`. |
| `ai-summaries` | off | The "Summarize (simulated)" actions on the proposal, the validation findings and Activity, and `/assistant/summary`. |
| `ai-agent` | off | The "Plan (preview)" tab and `/assistant/agent/plan`. |

A capability needs both `ai` and its own flag.

Flags are not authorisation. Every call still needs sign-in, and context comes only from records the caller may read: the
vehicle's context, and the owner of proposals and requests.

### Enabling a flag

- **In the app (administrators):** More → Administration → Feature flags. Set **AI features (all)** and the capabilities you
  want to **On**, or **Targeted** for chosen people, teams, roles or a percentage of everyone else.
- **Through the API (administrators):**

```http
PUT /api/v1/admin/features/ai
Content-Type: application/json

{ "mode": "on" }
```

Then do the same for `ai-chat`, `ai-summaries` and `ai-agent`. To target instead of switching on for everyone:

```json
{ "mode": "targeted", "groups": ["role:Engineer", "team:sweden-ops"], "users": ["engineer"], "rollout": 10 }
```

Every change is versioned and written to the audit log.

## How the simulation works

`src/Volvo.TestRequestTool.Application/SimulatedAssistant.cs` implements all three provider interfaces.

**Chat** answers from three sources:

- a glossary (NTP, PBL, VDA and so on);
- a workflow FAQ (the five steps, submitting, why a vehicle is blocked);
- the records you include as context (describe the vehicle, what the proposal changes, why a result is blocked).

Anything else gets a plain statement of the simulation's limits, with confidence `unknown`. Each answer carries:

- citations (a record or a Help article);
- a confidence (`confirmed`, `likely` or `unknown`);
- suggested actions that only navigate, never run, save or submit;
- suggested follow-up questions.

`/chat/stream` returns the same answer as Server-Sent Events.

**Summaries** are deterministic statements built from one authorised record: a proposal revision, a validation request,
your activity or a vehicle. They have five sections: identity, changes, findings, limitations and next steps.

- Each statement names its source record.
- Each summary carries the source version (`rev-N` for a proposal, the request id) and the time it was made.
- The page marks a summary **Outdated** when the source version changes.

**Agent plan previews** take a goal and return a preview that never executes:

- the goal;
- the steps;
- the required context and permissions, each marked satisfied or missing for the caller's role;
- proposed actions with their expected outcomes, each with `executes: false`.

The simulated agent never changes, submits, approves or contacts anything.

### Guardrails, for any provider

These are applied in `AssistantEndpoints.cs`, so a real provider gets them too.

- **Untrusted input.** Messages, retrieved content and responses are treated as untrusted. Messages are redacted (tokens,
  secrets, e-mail addresses) and bounded (20 messages, 4,000 characters each).
- **Timeouts.** Calls time out after 15 s with a structured, retryable problem.
- **Rate limits.** The `assistant` policy applies: 30 a minute, burst 10.
- **Audit.** The audit log records who used which capability and how many context items, never message content.
- **Safe rendering.** The browser renders every reply as plain text. No HTML or scripts are executed; only in-app Help
  references become links.
- **Retention.** Conversations are session-scoped. They live in this browser tab (sessionStorage) and are cleared on Clear
  conversation, sign-out and account switch. The server keeps none.

## Integrating a real provider later

1. Implement the interfaces in `src/Volvo.TestRequestTool.Application` (`IChatProvider.cs`, `ISummaryProvider.cs`, `IAgentPlanner.cs`):
   - `IChatProvider`: `ChatAsync` and `StreamAsync`, plus `Info` (name, label, capabilities, retention);
   - `ISummaryProvider`: `SummariseAsync(ContextItem source, DateTimeOffset now, CancellationToken)`;
   - `IAgentPlanner`: `PlanAsync(goal, context, permissions, CancellationToken)`.
   `IAgentActionExecutor` is defined for later and is deliberately not registered: executing actions needs its own
   review, approval and audit design.
2. Register the implementations in `AssistantEndpoints.AddAssistant()` in place of `SimulatedAssistant`. Keep
   `IAssistantContextRetriever`: it is what enforces "only records you may read".
3. Keep credentials out of code. Read them from configuration or a secret store (for example Azure Key Vault with a managed
   identity). Never log prompts or responses by default.
4. Change the label in `Info` from "Simulated" to the provider's name. The interface shows whatever the provider declares.

Nothing else changes: the endpoints, flags, guardrails, panel and summaries stay the same.

## Tests

| Suite | Covers |
|---|---|
| `tests/Volvo.TestRequestTool.IntegrationTests/AssistantApiTests.cs` | Everything off by default; each capability needs its own flag; scripted chat with honest limits; streaming; summaries from authorised records with their source version; isolation between users; missing context; plan previews that execute nothing and respect permissions; no message content in the audit log. |
| `tests/frontend/assistant.cjs` | Lazy loading only when the flags allow it; plain-text rendering (markup shown as text, `javascript:` references not linked); excluded context not sent; cancellation keeps the question; retryable errors offer Retry; conversations cleared on account switch and sign-out; Outdated summaries. |

## What remains simulated

All of it. There is no AI model, no external AI service and no learning from conversations. Answers cover only the
scripted topics and the included records.
