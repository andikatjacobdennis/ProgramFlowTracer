@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Start-Local.ps1"
if errorlevel 1 (
  echo.
  echo Startup failed. Read the message above before closing this window.
  pause
  exit /b 1
)
