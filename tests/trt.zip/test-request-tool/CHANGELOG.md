# Changelog

## Unreleased

- **Listener requests** (Requests menu) lists every message type the request listener in swb-stable1 handles, in every version: 64 in 35 families, with their request and reply contracts (115 XSDs from SoftwareBreakdown.Contracts). Start a request from its contract, send it, and read the reply. Requests are checked the way the listener checks them: well-formed XML (101), the schema version, and the XSD (107), with each problem and its line. Replies are checked against the reply XSD. Ping 1.0 and GetInfo 1.0 are simulated; the other families follow, one area at a time. See docs/listener.md.
- **No personal data in the glossary:** an abbreviation's description no longer gives a person's e-mail address, and `scripts/import-abbreviations.py` now leaves out any sentence that does. Team mailboxes stay.
- **Saved vehicles** shows bookmarked vehicles and recently loaded sources as tables (vehicle, source, when, and the Load vehicle and Remove actions) instead of cards.
- **VCADS listener requests are simulated:** software and hardware replacement, kit information and the complete vehicle, with the complete vehicle and TestRequest versions. All 64 message types and versions of the request listener are now simulated.
  - The replies are the Workflow, HardwareResponse or CompleteVehicle the listener writes, with its CamsResult error codes.
  - The registry now names these replies as the listener writes them, including the one for complete vehicle kit information.
- **Service Configurator listener requests are simulated:** GetParameterRecipe 1.0 and 1.1, GetNewSalesParameterRecipe 1.0, GetAftermarketParameterRecipe 1.0 and GetCapabilityResourceBreakdown 1.0 and 1.1.
  - Variant recipes give the variants to add and delete for the wanted parameter values.
  - Aftermarket recipes give a software refresh, a software update or a conversion kit.
  - Capabilities and resources are the parameters marked so in the catalog's parameter definitions. The reference catalog marks none, and the reply says so.
  - The listener now reads the catalog once per start, not once per lookup.
- **Production and Development listener requests are simulated:** all 26 message types and versions. They are the production software breakdown (with the TR versions), the BOM consistency check, the development software breakdown (also with a product), and Evaluate. The breakdowns use the tool's breakdown rules (baseline or effectivity, variant conditions) and answer a BreakdownModuleCommon bill of material for each version from 1.4 to 2.1. The consistency check returns the request's bill of material with notifications where it differs. Version 2.1 has no contract among the files, so it is answered in the 2.0 shape and marked as not checked.
- **Aftermarket listener requests are simulated:** all 20 message types and versions. They are New software exists, Release notes, Available updates 1.3 and 2.1, Kit evaluation, Campaign evaluation, Assigned nodes in kit 1.0 and 2.0, Conversion kit 2.1, 3.0 and 3.1, Software request 3.1, Spare cab 2.0 and 2.1, Campaign and Campaign refresh, and the T3 Product Update Service and Available Product Updates. Each answers from the catalog with the same rules as the Requests pages. Its reply follows the reply contract, and errors carry the listener's codes. *Write the request for this vehicle* fills a request with a vehicle's chassis, variants and nodes.
- **Abbreviations explain themselves.** Every abbreviation on screen has a dotted underline and a tooltip with what it stands for, a short description and any other meanings: this tool's meaning first, then the company list (4,887 abbreviations, imported from Abbreviations.xlsx). Help › Abbreviations lists and searches them all, and Settings › Accessibility can turn the underlines off.
- **Change impact topology** opens with all levels shown.
- **The product name** reads Test Request Tool in the header too.
- **Help** is the last menu, after Administration.

## 1.0.0 (first release)

**Requests:**
- Plan changes for one vehicle or many: software (by hand or up to the latest service pack), parameters, variants,
  S-Notes, conversion kits, spare cabs and breakdowns.
- T3 vehicles use the Product Update Service and Available Product Updates contracts.
- Checks are simulations: catalog, hardware, dependency, parameter and variant rules. Each result says where it came from.
- Approval: a reviewer approves exactly the checked version (never their own). The change can then be sent: a VDA
  update, a conversion kit, a Digital Twin specification or a file. Reviews can be assigned, and there are queues.
- Campaigns apply one change to many vehicles. Batch runs, drafts and proposal history are kept.

**Vehicles:**
- The vehicle map, topology (top to bottom or left to right), roadmap, history, insights and the fleet dashboard.

**People and sign-in:**
- A sign-in page with the accounts set in `C:\trt\settings.json`.
- Sessions are kept on the server, and sign-out ends them.
- Roles are Admin, Reviewer, Engineer and Viewer, with vehicle contexts per person.
- The Users table pages, searches, filters and sorts on the server, with columns you choose.

**Data and services:**
- The repository is in `C:\trt\repo`, one file per record (vehicles as XML, everything else as JSON). A database can
  be added later as a provider.
- The external services are reached through one service layer: files in `C:\trt\services` now, HTTP or off per service.
- Both are set on Administration › Data and services.

**Speed:**
- The page loads one compressed script and one stylesheet, cached until they change.
- The data is read once, then served from memory.

**Interface:**
- Light Charcoal, Dark Charcoal and Auto themes.
- English, Swedish, German and Hindi.
- Cultures, time zones and number formats per person.
- A Help Center, the introduction tour, the guides Asha, Ravi, Meera and Truxie, and an in-app UI guide with screenshots.

**Code:**
- Projects and namespaces are `Volvo.TestRequestTool.*`, following the swb-stable1 coding standards
  (see docs/coding-standards.md).
