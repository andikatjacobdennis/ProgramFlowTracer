using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.UnitTests
{
    public sealed class RequestTests
    {
        [Fact]
        public async Task Simulation_updates_T3_without_mutating_input_or_VDA()
        {
            using var f = new Fixture();
            var p = f.Product();
            var before = p.Fingerprint();
            var result = await f.Service.ExecuteAsync(f.Writer, Fixture.Command(p), default);
            Assert.Equal(before, p.Fingerprint());
            Assert.All(result.Outcomes, o => Assert.True(o.IsReady));
            Assert.Equal("1.2.0", result.Outcomes[0].Proposal["nodes"]![0]!["softwareProducts"]![0].S("packageVersion"));
            Assert.Equal(1, (await f.Store.VehicleAsync(p.Id, default))!.Revision);
        }

        [Fact]
        public async Task Released_scenario_does_not_select_introduced_packages()
        {
            using var f = new Fixture();
            var r = await f.Service.ExecuteAsync(f.Writer, Fixture.Command(f.Product(), 3, 3), default);
            Assert.Equal("1.1.0", r.Outcomes[0].Proposal["nodes"]![0]!["softwareProducts"]![0].S("packageVersion"));
        }

        [Theory]
        [InlineData(1)]
        [InlineData(2)]
        [InlineData(4)]
        [InlineData(5)]
        public async Task Other_software_operations_return_valid_T3_results(int operation)
        {
            using var f = new Fixture();
            var r = await f.Service.ExecuteAsync(f.Writer, Fixture.Command(f.Product(), operation), default);
            Assert.True(r.Outcomes[0].IsReady);
        }

        [Fact]
        public async Task Resolve_recovers_an_absent_template()
        {
            using var f = new Fixture();
            var p = f.Product();
            p.Nodes[0]!["nodeTemplateDocument"] = null;
            var r = await f.Service.ExecuteAsync(f.Writer, Fixture.Command(p, 4), default);
            Assert.True(r.Outcomes[0].IsReady);
            Assert.NotNull(r.Outcomes[0].Proposal["nodes"]![0]!["nodeTemplateDocument"]);
        }

        [Fact]
        public async Task Unknown_hardware_blocks_atomic_application()
        {
            using var f = new Fixture();
            var p = f.Product();
            p.Nodes[0]!["ecuHardware"]!["number"] = 99999999;
            var r = await f.Service.ExecuteAsync(f.Writer, Fixture.Command(p), default);
            Assert.False(r.Outcomes[0].IsReady);
            Assert.True(JsonNode.DeepEquals(p.Data, r.Outcomes[0].Proposal));
        }

        [Fact]
        public async Task Scope_leaves_unrequested_nodes_unchanged()
        {
            using var f = new Fixture();
            var p = f.Product();
            var command = Fixture.Command(p);
            command.Payload["limitTo"] = "VCM";
            var r = await f.Service.ExecuteAsync(f.Writer, command, default);
            Assert.Equal("1.0.0", r.Outcomes[0].Proposal["nodes"]![1]!["softwareProducts"]![0].S("packageVersion"));
        }

        [Fact]
        public async Task Empty_scope_is_an_error()
        {
            using var f = new Fixture();
            var c = Fixture.Command(f.Product());
            c.Payload["limitTo"] = "DOES-NOT-EXIST";
            var r = await f.Service.ExecuteAsync(f.Writer, c, default);
            Assert.Contains(r.Outcomes[0].Issues, e => e.Code == "empty_scope");
        }

        [Fact]
        public async Task Context_tampering_cannot_grant_access()
        {
            using var f = new Fixture();
            var p = f.Product();
            p.Info["context"]!["id"] = 101;
            var reader = new Actor("limited", new HashSet<int> { 101 }, false);
            var e = await Assert.ThrowsAsync<RequestFault>(() => f.Service.ExecuteAsync(reader, Fixture.Command(p), default));
            Assert.Equal(403, e.Status);
        }

        [Fact]
        public async Task Duplicate_vehicles_are_rejected()
        {
            using var f = new Fixture();
            var c = Fixture.Command(f.Product());
            c.Payload.A("products").Add(f.Product().Data);
            var e = await Assert.ThrowsAsync<RequestFault>(() => f.Service.ExecuteAsync(f.Writer, c, default));
            Assert.Equal("duplicate_vehicle", e.Code);
        }

        [Fact]
        public async Task Unauthorized_batch_writes_no_history()
        {
            using var f = new Fixture();
            var c = Fixture.Command(f.Product());
            c.Payload.A("products").Add(f.Product("000777").Data);
            await Assert.ThrowsAsync<RequestFault>(() => f.Service.ExecuteAsync(new Actor("limited", new HashSet<int> { 104 }, false), c, default));
            Assert.Empty(await f.Store.HistoryAsync("limited", 0, 20, default));
        }

        [Fact]
        public async Task Customized_legacy_parameter_is_preserved()
        {
            using var f = new Fixture();
            var p = f.Product("123456");
            var param = p.Parameters.Objects().First(x => x.S("code") == "P1ALG");
            param["references"]![0]!["value"] = "100";
            var r = await f.Service.ExecuteAsync(f.Writer, Fixture.Command(p), default);
            Assert.Equal("100", r.Outcomes[0].Proposal.A("parameters").Objects().First(x => x.S("code") == "P1ALG")["references"]![0].S("value"));
        }

        [Fact]
        public async Task Invalid_parameter_value_blocks_delivery()
        {
            using var f = new Fixture();
            var p = f.Product("123456");
            p.Parameters.Objects().First(x => x.S("code") == "P1ALG")["references"]![0]!["value"] = "999";
            var r = await f.Service.ExecuteAsync(f.Writer, Fixture.Command(p), default);
            Assert.False(r.Outcomes[0].IsReady);
            Assert.Contains(r.Outcomes[0].Issues, i => i.Code == "parameter_value_invalid");
        }

        [Fact]
        public async Task Blocked_result_cannot_commit()
        {
            using var f = new Fixture();
            var p = f.Product();
            p.Nodes[0]!["ecuHardware"]!["number"] = 1;
            var r = await f.Service.ExecuteAsync(f.Writer, Fixture.Command(p), default);
            var e = await Assert.ThrowsAsync<RequestFault>(() => f.Service.CommitVdaAsync(f.Writer, r.Id, p.Id, 1, default));
            Assert.Equal(409, e.Status);
        }

        [Fact]
        public async Task Optimistic_revision_prevents_double_commit()
        {
            using var f = new Fixture();
            var p = f.Product();
            var r = await f.Service.ExecuteAsync(f.Writer, Fixture.Command(p), default);
            await f.Service.CommitVdaAsync(f.Writer, r.Id, p.Id, 1, default);
            var e = await Assert.ThrowsAsync<RequestFault>(() => f.Service.CommitVdaAsync(f.Writer, r.Id, p.Id, 1, default));
            Assert.Equal(409, e.Status);
        }

        [Fact]
        public async Task A_reader_cannot_commit_even_a_ready_result()
        {
            using var f = new Fixture();
            var p = f.Product();
            var reader = new Actor("reader", new HashSet<int> { 104 }, false);
            var r = await f.Service.ExecuteAsync(reader, Fixture.Command(p), default);
            var e = await Assert.ThrowsAsync<RequestFault>(() => f.Service.CommitVdaAsync(reader, r.Id, p.Id, 1, default));
            Assert.Equal(403, e.Status);
        }

        [Fact]
        public async Task History_is_private_to_the_actor()
        {
            using var f = new Fixture();
            var r = await f.Service.ExecuteAsync(f.Writer, Fixture.Command(f.Product()), default);
            Assert.Null(await f.Store.ExecutionAsync(r.Id, "other", default));
        }

        [Fact]
        public async Task Kit_contains_manual_changes_and_engine_changes()
        {
            using var f = new Fixture();
            var p = f.Product();
            p.Data["productSpecification"]!.A("sNotes").Add(new JsonObject { ["value"] = "S-DEMO" });
            var r = await f.Service.ExecuteAsync(f.Writer, Fixture.Command(p), default);
            var kit = await f.Service.CreateKitAsync(f.Writer, r.Id, [p.Id], "Combined kit", default);
            Assert.NotEmpty(kit.Changes[0]["delta"]!["productSpecification"]!.A("sNotes"));
            Assert.NotEmpty(kit.Changes[0]["delta"]!.A("nodes"));
        }

        [Theory]
        [InlineData(RequestKind.ProductionBreakdown)]
        [InlineData(RequestKind.DevelopmentBreakdown)]
        [InlineData(RequestKind.AvailableUpdates)]
        public async Task Nonsoftware_handlers_keep_T3_architecture(RequestKind kind)
        {
            using var f = new Fixture();
            var c = Fixture.Command(f.Product());
            c = new(kind, c.Payload);
            c.Payload["introductionWeek"] = "202640";
            c.Payload["baselineIdentifier"] = "BL-T3-2610";
            var r = await f.Service.ExecuteAsync(f.Writer, c, default);
            Assert.True(r.Outcomes[0].IsReady);
            Assert.All(r.Outcomes[0].Proposal.A("nodes").Objects(), n => Assert.Equal(3, n.I("electricalArchitecture")));
        }

        [Fact]
        public async Task Cancellation_does_not_create_a_request()
        {
            using var f = new Fixture();
            using var cts = new CancellationTokenSource();
            cts.Cancel();
            await Assert.ThrowsAnyAsync<OperationCanceledException>(() => f.Service.ExecuteAsync(f.Writer, Fixture.Command(f.Product()), cts.Token));
            Assert.Empty(await f.Store.HistoryAsync(f.Writer.Id, 0, 20, default));
        }
    }
}
