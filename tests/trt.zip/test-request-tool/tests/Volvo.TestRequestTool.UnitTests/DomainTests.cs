using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.UnitTests
{
    public sealed class DomainTests
    {
        [Theory]
        [InlineData("fh", "000042", "FH|42")]
        [InlineData("RT", "000777", "RT|777")]
        [InlineData("FH", "333333", "FH|333333")]
        public void Vehicle_keys_are_normalized(string series, string number, string expected) => Assert.Equal(expected, VehicleIdentity.Key(series, number));

        [Theory]
        [InlineData("", "1")]
        [InlineData("FH", "1000000")]
        [InlineData("../", "1")]
        [InlineData("FH", "-1")]
        public void Invalid_vehicle_keys_are_rejected(string series, string number) => Assert.Throws<RequestFault>(() => VehicleIdentity.Key(series, number));

        [Fact]
        public void Products_clone_inputs_and_keep_future_fields()
        {
            using var f = new Fixture();
            var json = f.Product().Data;
            json["futureField"] = new JsonObject { ["value"] = "kept" };
            var p = new ProductDocument(json);
            json["futureField"]!["value"] = "changed";
            Assert.Equal("kept", p.Data["futureField"].S("value"));
        }

        [Fact] public void Fingerprints_ignore_object_property_order() => Assert.Equal(CanonicalJson.Hash(JsonNode.Parse("{\"a\":1,\"b\":2}")!), CanonicalJson.Hash(JsonNode.Parse("{\"b\":2,\"a\":1}")!));

        [Fact]
        public void T3_metadata_changes_generate_a_replacement()
        {
            using var f = new Fixture();
            var before = f.Product();
            var after = before.Copy();
            after.Nodes[0]!["softwareProducts"]![0]!["parameterTemplate"] = "PT-NEW";
            var delta = ProductDelta.Between(before, after);
            Assert.Equal(42, delta.A("nodes")[0].I("type"));
        }

        [Theory]
        [InlineData("123456", 32)]
        [InlineData("000777", 31)]
        public void Legacy_node_changes_keep_their_operation_ids(string number, int op)
        {
            using var f = new Fixture();
            var b = f.Product(number);
            var a = b.Copy();
            a.Nodes[0]!["versionName"] = "different";
            Assert.Equal(op, ProductDelta.Between(b, a).A("nodes")[0].I("type"));
        }

        [Fact]
        public void Product_XML_round_trip_preserves_types_and_unknown_fields()
        {
            using var f = new Fixture();
            var p = f.Product().Data;
            p["future"] = new JsonObject { ["list"] = new JsonArray("true", 3, true, null) };
            Assert.True(JsonNode.DeepEquals(p, ProductXmlCodec.Import(ProductXmlCodec.Export(p))));
        }

        [Fact] public void XML_rejects_external_entities() => Assert.Throws<RequestFault>(() => ProductXmlCodec.Import("<!DOCTYPE x [<!ENTITY ext SYSTEM 'file:///etc/passwd'>]><Product xmlns='urn:test-request-studio:product:1'>&ext;</Product>"));
    }
}
