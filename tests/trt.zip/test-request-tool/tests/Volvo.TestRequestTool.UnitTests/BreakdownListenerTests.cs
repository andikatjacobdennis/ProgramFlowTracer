using System.Xml.Linq;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
using Volvo.TestRequestTool.Infrastructure;

namespace Volvo.TestRequestTool.UnitTests
{
    /// <summary>The rules of the simulated Production and Development message types (the contract checks run in AftermarketListenerTests).</summary>
    public sealed class BreakdownListenerTests : IDisposable
    {
        private static readonly ListenerContracts Contracts = new();
        private readonly Fixture _f = new();
        private readonly ListenerDispatcher _listener;

        public BreakdownListenerTests()
        {
            _listener = new ListenerDispatcher(Contracts, AftermarketHandlers.Create(_f.Catalog, _f.Store, TimeProvider.System));
        }

        public void Dispose() => _f.Dispose();

        [Fact]
        public async Task A_bill_of_material_from_a_breakdown_is_consistent_with_the_same_baseline()
        {
            var vehicle = await Vehicle("FH|123456");
            var breakdown = await Send("ESW_DEV_SOFTWARE_BREAKDOWN_REQUEST", "1.7", Text("ESW_DEV_SOFTWARE_BREAKDOWN_REQUEST", "1.7", vehicle));
            Assert.DoesNotContain("S-NOTE UNKNOWN", breakdown.Reply!.Body);
            var bom = XDocument.Parse(breakdown.Reply.Body).Root!.Elements().First(e => e.Name.LocalName == "SoftwareBillOfMaterial");

            var request = XDocument.Parse(Text("GetBOMConsistencyCheck", "1.7", vehicle));
            var given = request.Root!.Elements().First(e => e.Name.LocalName == "SoftwareBillOfMaterial");
            given.ReplaceNodes(bom.Elements());
            var check = await Send("GetBOMConsistencyCheck", "1.7", request.ToString());
            Assert.Equal("Consistent: 11 node(s) checked.", check.Reply!.Summary[0].Value);
            Assert.DoesNotContain("<Severity>Error</Severity>", check.Reply.Body);
        }

        [Fact]
        public async Task The_vehicles_own_software_against_a_newer_baseline_is_inconsistent()
        {
            var vehicle = await Vehicle("FH|123456");
            var check = await Send("GetBOMConsistencyCheck", "2.0", Text("GetBOMConsistencyCheck", "2.0", vehicle));
            Assert.Contains("NODE TEMPLATE NOT OK", check.Reply!.Body);
            Assert.Contains("inconsistenc", check.Reply.Summary[0].Value);
        }

        [Fact]
        public async Task A_baseline_of_another_context_is_a_notification_not_an_error()
        {
            var vehicle = await Vehicle("FH|123456");
            var request = Text("ESW_DEV_SOFTWARE_BREAKDOWN_REQUEST", "1.4", vehicle);
            var t3 = _f.Catalog.Data.A("baselines").Objects().First(b => b.I("contextId") == 104).S("guid").ToUpperInvariant();
            var doc = XDocument.Parse(request);
            doc.Descendants().First(e => e.Name.LocalName == "Baseline").Value = "{" + t3 + "}";
            var result = await Send("ESW_DEV_SOFTWARE_BREAKDOWN_REQUEST", "1.4", doc.ToString());
            Assert.Empty(result.Notices);
            Assert.Contains("BASELINE WRONG CONTEXT", result.Reply!.Body);
            Assert.Contains("<Nodes xmlns=\"http://esw.volvo.com/breakdownmodulecommon/1_4\" />", result.Reply.Body);
        }

        [Fact]
        public async Task Production_by_effectivity_uses_the_versions_introduced_by_that_week()
        {
            var vehicle = await Vehicle("FH|123456");
            var doc = XDocument.Parse(Text("GetProductionSoftwareBreakdown", "1.4", vehicle));
            doc.Descendants().First(e => e.Name.LocalName == "EffectivityDate").Value = "2025-01-15";
            var old = await Send("GetProductionSoftwareBreakdown", "1.4", doc.ToString());
            Assert.Contains("<DocumentNumber>22100000</DocumentNumber>", old.Reply!.Body);
            Assert.Contains("week 202503", old.Reply.Body);
        }

        [Fact]
        public async Task A_request_that_cannot_be_read_gets_one_technical_error()
        {
            var result = await _listener.DispatchAsync("GetProductionSoftwareBreakdown", "1.7", "<ProductionSoftwareBreakdownRequest xmlns=\"http://esw.volvo.com/productionsoftwarebreakdownrequest/1_7\" transactionId=\"t\" schemaVersion=\"1.7\"/>", _f.Writer, "tests", default);
            Assert.Equal(107, result.Notices[0].Code);
            Assert.Empty(result.ReplyErrors);
            Assert.Contains("<Type>TECHNICAL ERROR</Type>", result.Reply!.Body);
            Assert.Contains("The production breakdown request has an invalid format and could not be processed.", result.Reply.Body);
        }

        [Fact]
        public async Task Evaluate_answers_known_node_templates_and_flags_a_variant_mismatch()
        {
            var vehicle = await Vehicle("FM|654321");
            var tecu = _f.Catalog.Data.A("templates").Objects().First(t => t.S("key") == "TECU");
            var doc = XDocument.Parse(Text("Evaluate", "1.1", vehicle));
            doc.Descendants().First(e => e.Name.LocalName == "IssueId").Value = ListenerCatalog.Versions(tecu)[0].S("doc");
            var result = await Send("Evaluate", "1.1", doc.ToString());
            Assert.Contains("NODE TEMPLATE MISMATCH", result.Reply!.Body);

            doc.Descendants().Where(e => e.Name.LocalName == "IssueId").ToList().ForEach(e => e.Value = "1");
            var unknown = await _listener.DispatchAsync("Evaluate", "1.1", doc.ToString(), _f.Writer, "tests", default);
            Assert.Equal(100, unknown.Notices[0].Code);
        }

        [Fact]
        public async Task Version_2_1_is_answered_in_the_2_0_shape_and_says_it_cannot_be_checked()
        {
            var vehicle = await Vehicle("FH|123456");
            var result = await _listener.DispatchAsync("GetProductionSoftwareBreakdownTR", "2.1", Text("GetProductionSoftwareBreakdownTR", "2.1", vehicle), _f.Writer, "tests", default);
            Assert.Contains("http://esw.volvo.com/productionsoftwarebreakdownresponse/2_1", result.Reply!.Body);
            Assert.Contains("<HpcNodes", result.Reply.Body);
            Assert.Contains(result.Reply.Summary, s => s.Label == "2.1");
            Assert.Contains(result.Notices, n => n.Severity == "Warning");
        }

        private async Task<ProductDocument> Vehicle(string id) => new((await _f.Store.VehicleAsync(id, default))!.Product);

        private string Text(string messageType, string version, ProductDocument vehicle) => _listener.ExampleText(Contracts.Find(messageType, version)!, vehicle)!;

        private async Task<ListenerResult> Send(string messageType, string version, string body)
        {
            var result = await _listener.DispatchAsync(messageType, version, body, _f.Writer, "tests", default);
            Assert.Empty(result.RequestErrors);
            Assert.Empty(result.ReplyErrors);
            Assert.NotNull(result.Reply);
            return result;
        }
    }
}
