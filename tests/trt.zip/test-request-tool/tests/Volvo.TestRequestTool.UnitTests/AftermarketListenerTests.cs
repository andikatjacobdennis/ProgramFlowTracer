using System.Xml.Linq;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
using Volvo.TestRequestTool.Infrastructure;

namespace Volvo.TestRequestTool.UnitTests
{
    /// <summary>
    /// The simulated Aftermarket message types of the listener. Every handler writes a request for every reference vehicle;
    /// the request must follow its contract, and the reply must follow the reply contract. Then the rules of each type.
    /// </summary>
    public sealed class AftermarketListenerTests : IDisposable
    {
        private static readonly ListenerContracts Contracts = new();
        private readonly Fixture _f = new();
        private readonly ListenerDispatcher _listener;
        private readonly IReadOnlyList<IListenerHandler> _handlers;

        public AftermarketListenerTests()
        {
            _handlers = AftermarketHandlers.Create(_f.Catalog, _f.Store, TimeProvider.System);
            _listener = new ListenerDispatcher(Contracts, _handlers);
        }

        public void Dispose() => _f.Dispose();

        public static TheoryData<string> Simulated()
        {
            using var f = new Fixture();
            var data = new TheoryData<string>();
            foreach (var key in AftermarketHandlers.Create(f.Catalog, f.Store, TimeProvider.System).SelectMany(h => h.Keys).Order(StringComparer.Ordinal))
            {
                data.Add(key);
            }

            return data;
        }

        [Theory]
        [MemberData(nameof(Simulated))]
        public async Task Every_vehicle_gets_a_request_and_a_reply_that_follow_their_contracts(string key)
        {
            var type = Contracts.MessageTypes.Single(m => m.Key == key);
            var vehicles = await new ListenerVehicles(_f.Store).ReadableAsync(_f.Writer, default);
            Assert.Equal(7, vehicles.Count);
            foreach (var vehicle in vehicles)
            {
                var request = _listener.ExampleText(type, vehicle);
                Assert.NotNull(request);
                var result = await _listener.DispatchAsync(type.MessageType, type.Version, request, _f.Writer, "tests", default);
                Assert.True(result.RequestErrors.Count == 0, $"{key} for {vehicle.Id}: the request does not follow its contract: {string.Join(" | ", result.RequestErrors)}");
                Assert.True(result.ReplyErrors.Count == 0, $"{key} for {vehicle.Id}: the reply does not follow its contract: {string.Join(" | ", result.ReplyErrors)}\n{result.Reply?.Body}");
                Assert.NotNull(result.Reply);
                Assert.NotEmpty(result.Reply.Body);
            }
        }

        [Fact]
        public async Task The_handlers_only_read_the_catalog()
        {
            var catalog = new SnapshotCatalog(_f.Catalog);
            var listener = new ListenerDispatcher(Contracts, AftermarketHandlers.Create(catalog, _f.Store, TimeProvider.System));
            var before = catalog.Data.DeepClone();
            foreach (var vehicle in await new ListenerVehicles(_f.Store).ReadableAsync(_f.Writer, default))
            {
                foreach (var type in Contracts.MessageTypes.Where(listener.HasExample))
                {
                    await listener.DispatchAsync(type.MessageType, type.Version, listener.ExampleText(type, vehicle)!, _f.Writer, "tests", default);
                }
            }

            Assert.True(System.Text.Json.Nodes.JsonNode.DeepEquals(before, catalog.Data), "A handler changed the catalog.");
        }

        [Fact]
        public async Task New_software_exists_for_a_vehicle_on_old_software_only()
        {
            var old = await Send("GetNewSoftwareExists", "1.0", "FH|123456");
            Assert.Contains("newSoftwareExists=\"true\"", old.Reply!.Body);
            Assert.Contains(old.Reply.Summary, s => s.Label == "Outcome" && s.Value == "New software exists.");
        }

        [Fact]
        public async Task A_product_without_nodes_is_read_from_the_repository_or_refused()
        {
            const string Body = """
                <GetNewSoftwareExists xmlns="http://www.volvo.com/NewSoftwareExists/1_0">
                  <ApplicationArea xmlns="http://www.volvo.com/group/common/1_0"><Sender><LogicalID>T</LogicalID></Sender><CreationDateTime>2026-01-01T00:00:00Z</CreationDateTime><BODID>b-1</BODID></ApplicationArea>
                  <DataArea><Criteria /><Product>
                    <ProductID xmlns="http://esw.volvo.com/products/2_1"><ChassisID><ChassisSeries>{0}</ChassisSeries><ChassisNumber>{1}</ChassisNumber></ChassisID></ProductID>
                    <ProductClassID xmlns="http://esw.volvo.com/products/2_1">FH</ProductClassID>
                    <Variants xmlns="http://esw.volvo.com/products/2_1" /><SalesCodes xmlns="http://esw.volvo.com/products/2_1" /><SNotes xmlns="http://esw.volvo.com/products/2_1" />
                    <ParameterValues xmlns="http://esw.volvo.com/products/2_1" /><Nodes xmlns="http://esw.volvo.com/products/2_1" />
                  </Product></DataArea>
                </GetNewSoftwareExists>
                """;
            var known = await _listener.DispatchAsync("GetNewSoftwareExists", "1.0", string.Format(Body, "FH   ", "123456"), _f.Writer, "tests", default);
            Assert.Empty(known.ReplyErrors);
            Assert.Contains(known.Reply!.Summary, s => s.Value.Contains("the nodes of the vehicle in the repository were used", StringComparison.Ordinal));
            Assert.Contains("<BODID>b-1</BODID>", known.Reply.Body);

            var unknown = await _listener.DispatchAsync("GetNewSoftwareExists", "1.0", string.Format(Body, "FH   ", "999999"), _f.Writer, "tests", default);
            Assert.Empty(unknown.ReplyErrors);
            Assert.Equal(103, Assert.Single(unknown.Notices).Code);
            Assert.Contains("<ResponseCriteria>Rejected</ResponseCriteria>", unknown.Reply!.Body.Replace(" xmlns=\"http://www.volvo.com/group/common/1_0\"", "", StringComparison.Ordinal));

            var outside = new Actor("other", new HashSet<int> { 103 }, false);
            var hidden = await _listener.DispatchAsync("GetNewSoftwareExists", "1.0", string.Format(Body, "FH   ", "123456"), outside, "tests", default);
            Assert.Equal(103, Assert.Single(hidden.Notices).Code);
        }

        [Fact]
        public async Task A_request_that_fails_its_checks_gets_the_contracts_error_reply()
        {
            var result = await _listener.DispatchAsync("GetNewSoftwareExists", "1.0", "<GetNewSoftwareExists xmlns=\"http://www.volvo.com/NewSoftwareExists/1_0\"/>", _f.Writer, "tests", default);
            Assert.Equal(107, result.Notices[0].Code);
            Assert.Empty(result.ReplyErrors);
            Assert.Contains("<StatusCode xmlns=\"http://www.volvo.com/group/common/1_0\">107</StatusCode>", result.Reply!.Body);
        }

        [Fact]
        public async Task Kit_evaluation_rejects_an_unknown_kit_but_campaign_evaluation_reports_it_per_kit()
        {
            static XDocument Kit(XDocument d, string attribute)
            {
                foreach (var kit in d.Descendants().Where(e => e.Name.LocalName == "RequestedKit"))
                {
                    kit.SetAttributeValue(attribute, "1");
                }

                return d;
            }

            var kitEvaluation = await Send("GetKitEvaluation", "2.1", "FH|123456", d => Kit(d, "partNumber"));
            Assert.Equal(113, Assert.Single(kitEvaluation.Notices).Code);
            Assert.Contains("Conversion Kit #00000001 does not exist", kitEvaluation.Reply!.Body);
            Assert.Contains("<KitInformation />", kitEvaluation.Reply.Body);

            var campaign = await Send("GetCampaignEvaluation", "1.0", "FH|123456", d => Kit(d, "partNumber"));
            Assert.Empty(campaign.Notices);
            Assert.Contains("outcome=\"NotPossible\" errorMessage=\"There was a problem applying the kit/transition. Conversion Kit #00000001", campaign.Reply!.Body);
        }

        [Fact]
        public async Task A_criterion_the_catalog_cannot_answer_makes_available_updates_Modified()
        {
            var result = await Send("GetAvailableUpdates", "2.1", "FH|123456", d =>
            {
                d.Descendants().First(e => e.Name.LocalName == "Criteria").SetAttributeValue("actionCriteria", "SoftwareReplacements.General,DisplayLanguages");
                return d;
            });
            Assert.Contains(">Modified</ResponseCriteria>", result.Reply!.Body);
            Assert.Contains("ActionCriteria 'DisplayLanguages' failed", result.Reply.Body);
            Assert.Contains("<SoftwareNodeByNodeReplacements actionCriteria=\"SoftwareReplacements.General\">", result.Reply.Body);
        }

        [Fact]
        public async Task A_kit_already_on_the_vehicle_is_refused_with_128()
        {
            var rules = new ListenerCatalog(_f.Catalog);
            var vehicle = new ProductDocument((await _f.Store.VehicleAsync("FH|123456", default))!.Product);
            var once = rules.ApplyKit(vehicle, 23187001, 1, serviceKitsOnly: false);
            Assert.Contains(once.Assigned, a => a.Node.S("name") == "40.1.1 TGW" && a.HardwareChangeNeeded);
            var twice = Assert.Throws<ListenerFault>(() => rules.ApplyKit(once.After, 23187001, 1, serviceKitsOnly: false));
            Assert.Equal(128, twice.Code);
            Assert.Equal(130, Assert.Throws<ListenerFault>(() => rules.ApplyKit(vehicle, 23187001, 1, serviceKitsOnly: true)).Code);
            Assert.Equal(111, Assert.Throws<ListenerFault>(() => rules.ApplyKit(vehicle, 23187004, 3, serviceKitsOnly: false)).Code);
        }

        [Fact]
        public async Task A_software_update_and_a_campaign_report_the_nodes_that_change()
        {
            var update = await Send("ESW_SOFTWARE_CONFIGURATION_REQUEST", "3.1", "FH|123456");
            Assert.Contains("<NodeTemplateDocumentNumber>22100020</NodeTemplateDocumentNumber>", update.Reply!.Body);
            Assert.Contains(update.Reply.Summary, s => s.Value.Contains("EMS_24.40 → EMS_26.10", StringComparison.Ordinal));

            var refresh = await Send("ESW_CAMPAIGN_REFRESH_REQUEST", "1.0", "FH|123456");
            Assert.Contains("resultCode=\"", refresh.Reply!.Body);
            Assert.Contains("resultMessage=\"Ok\"", refresh.Reply.Body);
        }

        [Fact]
        public async Task Spare_cab_needs_a_baseline_of_the_vehicle_context()
        {
            var result = await Send("ESW_SPARECAB_BREAKDOWN_REQUEST", "2.0", "FH|123456", d =>
            {
                d.Descendants().First(e => e.Name.LocalName == "DataArea").SetAttributeValue("Baseline", "9A983D08-8EE5-465B-A9CB-0EEA6CFD404A");
                return d;
            });
            Assert.Contains("is not for the vehicle context of FH 123456", Assert.Single(result.Notices).Text);
        }

        private async Task<ListenerResult> Send(string messageType, string version, string vehicleId, Func<XDocument, XDocument>? change = null)
        {
            var type = Contracts.Find(messageType, version)!;
            var vehicle = new ProductDocument((await _f.Store.VehicleAsync(vehicleId, default))!.Product);
            var text = _listener.ExampleText(type, vehicle)!;
            if (change is not null)
            {
                text = change(XDocument.Parse(text)).ToString();
            }

            var result = await _listener.DispatchAsync(messageType, version, text, _f.Writer, "tests", default);
            Assert.Empty(result.RequestErrors);
            Assert.Empty(result.ReplyErrors);
            return result;
        }
    }
}
