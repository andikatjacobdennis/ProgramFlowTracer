using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.UnitTests
{
    /// <summary>
    /// Shutdown: background work (a HybridCache fetch, the warm-up) can still be reading when the host disposes the store.
    /// It must see a cancellation, never an ObjectDisposedException; finished writes stay on disk; the fleet computation stops
    /// when its token is cancelled.
    /// </summary>
    public sealed class StoreShutdownTests
    {
        [Fact]
        public async Task A_disposed_store_refuses_reads_and_writes_as_cancelled_not_disposed()
        {
            using var f = new Fixture();
            f.Store.Dispose();
            await Assert.ThrowsAnyAsync<OperationCanceledException>(() => f.Store.VehiclesAsync(default));
            await Assert.ThrowsAnyAsync<OperationCanceledException>(() => f.Store.VehicleAsync("FH|333333", default));
            await Assert.ThrowsAnyAsync<OperationCanceledException>(() => f.Store.SaveDraftAsync("d", "alice", new JsonObject(), null, default));
            f.Store.Dispose();   // disposing twice is harmless
        }

        [Fact]
        public async Task Reads_in_flight_during_shutdown_finish_or_are_cancelled_never_disposed()
        {
            using var f = new Fixture();
            var reads = Enumerable.Range(0, 200).Select(_ => Task.Run(() => f.Store.VehiclesAsync(default))).ToArray();
            f.Store.Dispose();
            foreach (var r in reads)
            {
                var e = await Record.ExceptionAsync(() => r);
                Assert.True(e is null or OperationCanceledException, e?.GetType().Name + ": " + e?.Message);
            }
        }

        [Fact]
        public async Task A_write_finished_before_shutdown_is_on_disk_and_later_writes_leave_no_temporary_files()
        {
            using var f = new Fixture();
            await f.Store.SaveDraftAsync("draft", "alice", new JsonObject { ["label"] = "kept" }, null, default);
            f.Store.Dispose();
            await Assert.ThrowsAnyAsync<OperationCanceledException>(() => f.Store.SaveDraftAsync("draft", "alice", new JsonObject { ["label"] = "too late" }, 1, default));
            Assert.Empty(Directory.GetFiles(f.Directory, "*.tmp", SearchOption.AllDirectories));
            using var reopened = Fixture.Open(f.Directory);
            Assert.Equal("kept", (await reopened.DraftAsync("draft", "alice", default))!.State["label"]!.GetValue<string>());
        }

        [Fact]
        public async Task The_fleet_summary_stops_when_its_token_is_cancelled()
        {
            using var f = new Fixture();
            var insights = new VehicleInsights(f.Store, f.Catalog);
            using var cts = new CancellationTokenSource();
            cts.Cancel();
            await Assert.ThrowsAnyAsync<OperationCanceledException>(() => insights.FleetAsync(new Actor("tester", new HashSet<int> { 101, 102, 103, 104 }, true), false, cts.Token));
        }
    }
}
