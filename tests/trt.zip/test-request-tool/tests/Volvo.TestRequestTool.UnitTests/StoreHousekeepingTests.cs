using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.UnitTests
{
    /// <summary>Housekeeping of the workspace file: idle job polls do not rewrite it; stale temporary copies are removed on open.</summary>
    public sealed class StoreHousekeepingTests
    {
        [Fact]
        public async Task An_idle_job_poll_does_not_rewrite_the_workspace_file()
        {
            using var f = new Fixture();
            await f.Store.SaveDraftAsync("draft", "alice", new JsonObject(), null, default);
            var file = Path.Combine(f.Directory, "workspace.json");
            var before = File.GetLastWriteTimeUtc(file);
            await Task.Delay(50);
            for (var i = 0; i < 5; i++)
            {
                Assert.Null(await f.Store.ClaimJobAsync("w:0", TimeSpan.FromSeconds(30), true, TimeSpan.FromMinutes(5), default));
            }

            Assert.Equal(before, File.GetLastWriteTimeUtc(file));
        }

        [Fact]
        public void Stale_temporary_copies_are_removed_when_the_store_opens_and_recent_ones_are_kept()
        {
            using var f = new Fixture();
            var stale = Path.Combine(f.Directory, "repo", "vehicles", "FH-333333.xml.stale.tmp");
            var recent = Path.Combine(f.Directory, "repo", "drafts", "alice", "d1.json.recent.tmp");
            Directory.CreateDirectory(Path.GetDirectoryName(recent)!);
            File.WriteAllText(stale, "{}");
            File.SetLastWriteTimeUtc(stale, DateTime.UtcNow.AddHours(-1));
            File.WriteAllText(recent, "{}");
            using var reopened = Fixture.Open(f.Directory);
            Assert.False(File.Exists(stale));
            Assert.True(File.Exists(recent));
        }
    }
}
