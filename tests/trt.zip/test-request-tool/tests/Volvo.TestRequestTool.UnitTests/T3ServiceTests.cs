using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.UnitTests
{
    /// <summary>Product Update Service 1.0/2.0 and Available Product Updates 1.0/1.1 over the T3 demo vehicle FH 333333.</summary>
    public sealed class T3ServiceTests
    {
        static RequestCommand Pus(ProductDocument p, string scenario = "Introduced", string version = "2.0", string? operation = "UpdateToServicePack")
        {
            var criteria = new JsonObject { ["scenario"] = scenario };
            if (operation is not null)
            {
                criteria["operation"] = new JsonObject { ["operationType"] = operation };
            }

            return new(RequestKind.ProductUpdateService, new JsonObject { ["schemaVersion"] = version, ["criteria"] = criteria, ["products"] = new JsonArray(p.Data.DeepClone()) });
        }

        static RequestCommand Apu(ProductDocument p, JsonNode actions, string scenario = "InProgress", string version = "1.1") => new(RequestKind.AvailableProductUpdates, new JsonObject
        {
            ["contractVersion"] = version,
            ["products"] = new JsonArray(p.Data.DeepClone()),
            ["criteria"] = new JsonObject { ["scenario"] = scenario, ["actionCriteria"] = actions, ["includeUpdatePurposes"] = true, ["includeReleaseNoteSource"] = true }
        });

        static JsonObject Reply(ExecutionRecord r) => (JsonObject)r.ServiceResponses!["products"]![0]!;
        static JsonObject Node(JsonNode? n) => (JsonObject)((JsonObject)n!).First().Value!;
        static JsonArray Actions(params string[] a) => new(a.Select(x => (JsonNode)x).ToArray());

        [Fact]
        public async Task Pus_2_0_updates_T3_hpc_nodes_to_the_service_pack()
        {
            using var f = new Fixture();
            var p = f.Product();
            var r = await f.Service.ExecuteAsync(f.Writer, Pus(p), default);
            var reply = Reply(r);
            var pu = reply["response"]!["productUpdate"]!;
            Assert.Equal(0, reply.I("aftermarketErrorCode"));
            Assert.True(r.Outcomes[0].IsReady);
            Assert.Equal("T3 SP 2026.1", pu["servicePack"].S("name"));
            var vcm = Node(pu["nodes"]![0]);
            Assert.Equal("50.1.1 VCM", vcm.S("nodeName"));
            var env = vcm["executionEnvironments"]![0]!;
            Assert.Equal("VCM-Linux", env.S("nodeName"));
            Assert.All(env["softwareProducts"]!.AsArray(), s => Assert.Equal("1.2.0", s.S("version")));
            Assert.Equal("1.2.0", r.Outcomes[0].Proposal["nodes"]![0]!["softwareProducts"]![0].S("packageVersion"));
            Assert.Equal("hpcNode", ((JsonObject)reply["request"]!["product"]!["configuration"]!["nodes"]![0]!).First().Key);
            Assert.Equal(1, (await f.Store.VehicleAsync(p.Id, default))!.Revision);
        }

        [Fact]
        public async Task Pus_rejects_service_packs_outside_the_scenario_with_reasons()
        {
            using var f = new Fixture();
            var r = await f.Service.ExecuteAsync(f.Writer, Pus(f.Product(), "Released"), default);
            var reply = Reply(r);
            Assert.Equal(ServiceContract.InvalidMessage, reply.I("aftermarketErrorCode"));
            Assert.False(r.Outcomes[0].IsReady);
            Assert.Contains("outside scenario Released", reply["rejectedCandidates"]![0]!["reasons"]![0]!.ToString());
            Assert.Equal("NotificationException", reply["response"]!["errors"]![0].S("type"));
        }

        [Fact]
        public async Task Pus_schema_failure_returns_code_100()
        {
            using var f = new Fixture();
            var reply = Reply(await f.Service.ExecuteAsync(f.Writer, Pus(f.Product(), "Tomorrow"), default));
            Assert.Equal(ServiceContract.UnhandledError, reply.I("aftermarketErrorCode"));
            Assert.StartsWith("Schema validation failed", reply["response"]!["errors"]![0].S("text"));
        }

        [Fact]
        public async Task Pus_1_0_always_updates_to_the_service_pack()
        {
            using var f = new Fixture();
            var reply = Reply(await f.Service.ExecuteAsync(f.Writer, Pus(f.Product(), version: "1.0", operation: "Repair"), default));
            Assert.Equal("UpdateToServicePack", reply.S("operationType"));
            Assert.Equal("T3 SP 2026.1", reply["response"]!["productUpdate"]!["servicePack"].S("name"));
        }

        [Fact]
        public async Task Pus_2_0_repair_reprograms_current_versions_without_a_service_pack()
        {
            using var f = new Fixture();
            var r = await f.Service.ExecuteAsync(f.Writer, Pus(f.Product(), operation: "Repair"), default);
            var pu = Reply(r)["response"]!["productUpdate"]!;
            Assert.Null(pu["servicePack"]);
            Assert.Equal("1.0.0", Node(pu["nodes"]![0])["executionEnvironments"]![0]!["softwareProducts"]![0].S("version"));
            Assert.True(r.Outcomes[0].IsReady);
        }

        [Fact]
        public async Task Pus_2_0_rejects_other_operations_with_code_107()
        {
            using var f = new Fixture();
            var reply = Reply(await f.Service.ExecuteAsync(f.Writer, Pus(f.Product(), operation: "Update"), default));
            Assert.Equal(ServiceContract.InvalidMessage, reply.I("aftermarketErrorCode"));
            Assert.Equal("ProductUpdateService_2_0 only supports UpdateToServicePack or Repair. Received: Update", reply["response"]!["errors"]![0].S("text"));
        }

        [Fact]
        public async Task Pus_hpc_gate_rejects_hardware_without_an_upgrade_path()
        {
            using var f = new Fixture();
            var p = f.Product();
            p.Nodes[0]!["ecuHardware"]!["number"] = 21609999;
            var reply = Reply(await f.Service.ExecuteAsync(f.Writer, Pus(p), default));
            Assert.Equal(ServiceContract.InvalidMessage, reply.I("aftermarketErrorCode"));
            Assert.Contains(reply["rejectedCandidates"]![0]!["reasons"]!.AsArray(), x => x!.ToString().Contains("no upgrade path for ECU hardware 21609999", StringComparison.Ordinal));
        }

        [Fact]
        public async Task Hpc_node_without_logical_ecu_is_rejected_like_the_gateway()
        {
            using var f = new Fixture();
            var p = f.Product();
            foreach (var s in p.Nodes[0]!["softwareProducts"]!.AsArray())
            {
                s!["logicalEcu"] = "";
            }

            var reply = Reply(await f.Service.ExecuteAsync(f.Writer, Pus(p), default));
            Assert.Equal("Logical ECU definition not found for 50.1", reply["response"]!["errors"]![0].S("text"));
        }

        [Fact]
        public async Task Apu_1_1_lists_T3_software_service_pack_and_hardware_without_changing_the_vehicle()
        {
            using var f = new Fixture();
            var p = f.Product();
            var r = await f.Service.ExecuteAsync(f.Writer, Apu(p, Actions("SoftwareReplacements.General", "SoftwareReplacements.ServicePackGeneral", "HardwareReplacements")), default);
            var d = Reply(r)["response"]!["ShowAvailableProductUpdates"]!["DataArea"]!;
            Assert.Equal("Accepted", d["Show"].S("ResponseCriteria"));
            Assert.Equal("0", d["Show"].S("StatusCode"));
            var general = d["SoftwareNodeReplacements"]![0]!["AssignedNodes"]!["Node"]!.AsArray().Select(Node).ToArray();
            Assert.Equal(22101620, general[0].I("nodeTemplateDocumentNumber"));
            Assert.Equal(22101740, general[1].I("nodeTemplateDocumentNumber"));
            Assert.NotNull(general[0]["executionEnvironments"]![0]!["softwareProducts"]![0]!["id"]);
            Assert.True(d["SoftwareNodeReplacements"]![1]!["ServicePack"].B("exactMatch"));
            Assert.Equal("21601602", d["HardwareNodeReplacements"]!["HardwareNodeReplacement"]![0]!["hardwarePartNumbers"]![0]!.ToString());
            Assert.Equal(p.Fingerprint(), new ProductDocument(r.Outcomes[0].Proposal).Fingerprint());
        }

        [Fact]
        public async Task Apu_1_0_takes_a_comma_separated_string_and_omits_1_1_fields()
        {
            using var f = new Fixture();
            var d = Reply(await f.Service.ExecuteAsync(f.Writer, Apu(f.Product(), "SoftwareReplacements.CurrentSoftware,SoftwareReplacements.General", "Introduced", "1.0"), default))["response"]!["ShowAvailableProductUpdates"]!["DataArea"]!;
            Assert.Equal(2, d["SoftwareNodeReplacements"]!.AsArray().Count);
            Assert.Null(Node(d["SoftwareNodeReplacements"]![0]!["AssignedNodes"]!["Node"]![0])["executionEnvironments"]![0]!["softwareProducts"]![0]!["id"]);
        }

        [Theory]
        [InlineData("1.1", "string", "Schema validation failed.")]
        [InlineData("1.1", "unknown", "SoftwareReplacements.Everything is not a valid Action criteria type")]
        [InlineData("1.1", "empty", "Action critera cannot be null or empty.")]
        [InlineData("1.0", "empty", "Action critera cannot be null or empty.")]
        public async Task Apu_validation_failures_are_rejected_with_code_107(string version, string shape, string text)
        {
            using var f = new Fixture();
            JsonNode actions = shape switch { "string" => JsonValue.Create("SoftwareReplacements.General"), "unknown" => Actions("SoftwareReplacements.Everything"), _ => version == "1.0" ? JsonValue.Create("") : new JsonArray() };
            var show = Reply(await f.Service.ExecuteAsync(f.Writer, Apu(f.Product(), actions, version: version), default))["response"]!["ShowAvailableProductUpdates"]!["DataArea"]!["Show"]!;
            Assert.Equal("Rejected", show.S("ResponseCriteria"));
            Assert.Equal("107", show.S("StatusCode"));
            Assert.Equal(text, show.S("StatusText"));
        }

        [Fact]
        public async Task Apu_partial_failure_is_reported_as_modified()
        {
            using var f = new Fixture();
            var show = Reply(await f.Service.ExecuteAsync(f.Writer, Apu(f.Product(), Actions("SoftwareReplacements.General", "SoftwareReplacements.ServicePackGeneral"), "Released"), default))["response"]!["ShowAvailableProductUpdates"]!["DataArea"]!["Show"]!;
            Assert.Equal("Modified", show.S("ResponseCriteria"));
            Assert.Equal("1", show.S("StatusCode"));
            Assert.StartsWith("ActionCriteria 'SoftwareReplacements.ServicePackGeneral' failed", show.S("StatusText"));
        }

        [Fact]
        public async Task Preview_returns_the_contract_request_without_persisting()
        {
            using var f = new Fixture();
            var requests = await f.Service.PreviewAsync(f.Writer, Apu(f.Product(), Actions("SoftwareReplacements.General")), default);
            Assert.Equal("SWConfig", requests[0]!["GetAvailableUpdates"]!["ApplicationArea"]!["Sender"].S("LogicalID"));
            Assert.Empty(await f.Store.HistoryAsync(f.Writer.Id, 0, 10, default));
        }
    }
}
