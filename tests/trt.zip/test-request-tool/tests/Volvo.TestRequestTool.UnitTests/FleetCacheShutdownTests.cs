using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.UnitTests
{
    /// <summary>
    /// The cached fleet computation never lets a cancellation escape into HybridCache (Visual Studio stopped there on
    /// "The workspace store has shut down" during a background fetch). A recording cache runs the factory like HybridCache does.
    /// </summary>
    public sealed class FleetCacheShutdownTests
    {
        private sealed class RecordingCache : Microsoft.Extensions.Caching.Hybrid.HybridCache
        {
            public Exception? FactoryError;
            public int Removed;

            public override async ValueTask<T> GetOrCreateAsync<TState, T>(string key, TState state, Func<TState, CancellationToken, ValueTask<T>> factory,
                Microsoft.Extensions.Caching.Hybrid.HybridCacheEntryOptions? options = null, IEnumerable<string>? tags = null, CancellationToken cancellationToken = default)
            {
                try
                {
                    return await factory(state, cancellationToken);
                }
                catch (Exception e)
                {
                    FactoryError = e;
                    throw;
                }
            }

            public override ValueTask SetAsync<T>(string key, T value, Microsoft.Extensions.Caching.Hybrid.HybridCacheEntryOptions? options = null, IEnumerable<string>? tags = null, CancellationToken cancellationToken = default) => ValueTask.CompletedTask;

            public override ValueTask RemoveAsync(string key, CancellationToken cancellationToken = default)
            {
                Removed++;
                return ValueTask.CompletedTask;
            }

            public override ValueTask RemoveByTagAsync(string tag, CancellationToken cancellationToken = default) => ValueTask.CompletedTask;
        }

        [Fact]
        public async Task After_shutdown_the_factory_returns_and_the_caller_gets_a_cancellation()
        {
            using var f = new Fixture();
            var cache = new RecordingCache();
            var insights = new VehicleInsights(f.Store, f.Catalog, cache);
            f.Store.Dispose();
            await Assert.ThrowsAnyAsync<OperationCanceledException>(() => insights.FleetAsync(new Actor("tester", new HashSet<int> { 101, 102, 103, 104 }, true), false, default));
            Assert.Null(cache.FactoryError);
            Assert.True(cache.Removed >= 1, "the incomplete result is removed from the cache");
        }

        [Fact]
        public async Task A_normal_computation_is_unchanged()
        {
            using var f = new Fixture();
            var cache = new RecordingCache();
            var fleet = await new VehicleInsights(f.Store, f.Catalog, cache).FleetAsync(new Actor("tester", new HashSet<int> { 101, 102, 103, 104 }, true), false, default);
            Assert.NotNull(fleet["rows"]);
            Assert.Null(fleet["$incomplete"]);
            Assert.Equal(0, cache.Removed);
        }
    }
}
