using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.UnitTests
{
    /// <summary>Vehicle history (who changed what, and when) and roadmap behind the Vehicle page.</summary>
    public sealed class VehicleInsightsTests
    {
        private static VehicleInsights Insights(Fixture f) => new(f.Store, f.Catalog);
        private static string[] Kinds(JsonObject timeline) => timeline.A("entries").Objects().Select(e => e.S("kind")).ToArray();

        [Fact]
        public async Task Timeline_starts_with_the_build_and_the_VDA_record_newest_first()
        {
            using var f = new Fixture();
            var t = await Insights(f).TimelineAsync(f.Writer, f.Product().Id, default);
            Assert.Equal(["VdaRecord", "Delivered", "Built"], Kinds(t).Where(k => k is "VdaRecord" or "Delivered" or "Built"));
            Assert.Equal(1, t.I("currentRevision"));
            // The build date is from the vehicle record; what software it was built with is not known, so it has no snapshot.
            Assert.False(t.A("entries").Objects().Single(e => e.S("kind") == "Built").B("hasSnapshot"));
            Assert.True(t.A("entries").Objects().Single(e => e.S("kind") == "VdaRecord").B("hasSnapshot"));
        }

        [Fact]
        public async Task A_VDA_commit_records_who_made_it_why_and_what_changed()
        {
            using var f = new Fixture();
            var p = f.Product();
            var writer = new Actor("u-42", f.Writer.Contexts, true, "Ananya Rao");
            var result = await f.Service.ExecuteAsync(writer, Fixture.Command(p), default);
            await f.Service.CommitVdaAsync(writer, result.Id, p.Id, 1, default);

            var t = await Insights(f).TimelineAsync(writer, p.Id, default);
            var commit = t.A("entries").Objects().First();
            Assert.Equal("VdaCommit", commit.S("kind"));
            Assert.Equal(2, commit.I("revision"));
            Assert.Equal("Ananya Rao", commit["actor"].S("name"));
            Assert.Contains("committed to VDA", commit.S("summary"));
            Assert.Contains(commit.A("changes").Objects(), c => c.A("packages").Count > 0);
            Assert.Contains(t.A("people").Objects(), person => person.S("id") == "u-42" && person.S("name") == "Ananya Rao");
            Assert.Equal(2, t.I("currentRevision"));

            var snapshot = await Insights(f).SnapshotAsync(writer, p.Id, commit.S("id"), default);
            Assert.True(JsonNode.DeepEquals(result.Outcomes[0].Proposal, snapshot["product"]));
        }

        [Fact]
        public async Task History_links_branches_like_git()
        {
            using var f = new Fixture();
            var p = f.Product();
            var committed = await f.Service.ExecuteAsync(f.Writer, Fixture.Command(p), default);
            await f.Service.CommitVdaAsync(f.Writer, committed.Id, p.Id, 1, default);
            var later = await f.Service.ExecuteAsync(f.Writer, Fixture.Command(p), default);
            await f.Service.CreateKitAsync(f.Writer, later.Id, [p.Id], "Retrofit kit", default);

            var entries = (await Insights(f).TimelineAsync(f.Writer, p.Id, default)).A("entries").Objects().ToDictionary(e => e.S("id"));
            string Id(Guid g) => "req-" + g.ToString("N");
            Assert.Equal("main", entries["rev-2"].S("lane"));
            Assert.Equal("rev-1", entries["rev-2"].S("parent"));
            Assert.Equal(Id(committed.Id), entries["rev-2"].S("from"));
            Assert.Equal("proposal", entries[Id(committed.Id)].S("lane"));
            Assert.Equal("rev-1", entries[Id(committed.Id)].S("base"));
            Assert.Equal("rev-2", entries[Id(committed.Id)].S("mergedInto"));
            Assert.Equal("rev-2", entries[Id(later.Id)].S("base"));
            Assert.Null(entries[Id(later.Id)]["mergedInto"]);
            var kit = entries.Values.Single(e => e.S("kind") == "Kit");
            Assert.Equal(Id(later.Id), kit.S("from"));
            Assert.Equal("built", entries["delivered"].S("parent"));
        }

        [Fact]
        public async Task Timeline_pages_newest_first()
        {
            using var f = new Fixture();
            var p = f.Product("123456");
            var all = await Insights(f).TimelineAsync(f.Writer, p.Id, default);
            var first = await Insights(f).TimelineAsync(f.Writer, p.Id, default, 0, 2);
            var rest = await Insights(f).TimelineAsync(f.Writer, p.Id, default, 2, 50);
            Assert.Equal(all.I("total"), first.I("total"));
            Assert.Equal(2, first.A("entries").Count);
            Assert.True(first.B("hasMore"));
            Assert.False(rest.B("hasMore"));
            Assert.Equal(all.A("entries").Objects().Select(e => e.S("id")), first.A("entries").Objects().Concat(rest.A("entries").Objects()).Select(e => e.S("id")));
        }

        [Fact]
        public async Task Simulations_appear_only_for_the_user_who_ran_them()
        {
            using var f = new Fixture();
            var p = f.Product();
            await f.Service.ExecuteAsync(f.Writer, Fixture.Command(p), default);
            var mine = await Insights(f).TimelineAsync(f.Writer, p.Id, default);
            var theirs = await Insights(f).TimelineAsync(new Actor("bob", f.Writer.Contexts, false), p.Id, default);
            Assert.Contains("Simulation", Kinds(mine));
            Assert.DoesNotContain("Simulation", Kinds(theirs));
        }

        [Fact]
        public async Task Roadmap_explains_what_blocks_an_upcoming_version()
        {
            using var f = new Fixture();
            var road = await Insights(f).RoadmapAsync(f.Writer, f.Product().Id, default);
            var upcoming = road.A("nodes").Objects().SelectMany(n => n.A("upcoming").Objects()).ToArray();
            Assert.NotEmpty(upcoming);
            var blockers = upcoming.SelectMany(u => u.A("blockers").Select(b => b!.ToString())).ToArray();
            Assert.Contains(blockers, b => b.StartsWith("Needs ECU hardware"));
            Assert.DoesNotContain(blockers, b => b.Contains("index"));
            Assert.Contains(road.A("servicePacks").Objects(), sp => sp.S("state") == "Available");
        }

        [Fact]
        public async Task Another_context_cannot_read_the_history_or_roadmap()
        {
            using var f = new Fixture();
            var outsider = new Actor("outsider", new HashSet<int> { 999 }, false);
            var id = f.Product().Id;
            Assert.Equal(403, (await Assert.ThrowsAsync<RequestFault>(() => Insights(f).TimelineAsync(outsider, id, default))).Status);
            Assert.Equal(403, (await Assert.ThrowsAsync<RequestFault>(() => Insights(f).RoadmapAsync(outsider, id, default))).Status);
            Assert.Equal(403, (await Assert.ThrowsAsync<RequestFault>(() => Insights(f).SnapshotAsync(outsider, id, "built", default))).Status);
        }

        [Fact]
        public async Task Unknown_snapshot_is_not_found()
        {
            using var f = new Fixture();
            var e = await Assert.ThrowsAsync<RequestFault>(() => Insights(f).SnapshotAsync(f.Writer, f.Product().Id, "rev-99", default));
            Assert.Equal(404, e.Status);
        }
    }
}
