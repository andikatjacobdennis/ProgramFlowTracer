using System.Xml.Linq;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
using Volvo.TestRequestTool.Infrastructure;

namespace Volvo.TestRequestTool.UnitTests
{
    /// <summary>The listener's registry and contracts (ListenerContracts), the sample writer and the dispatcher's checks.</summary>
    public sealed class ListenerTests
    {
        private static readonly ListenerContracts Contracts = new();
        private static readonly Actor Tester = new("tester", new HashSet<int> { 101, 102, 103, 104 }, true, "Tester");

        public static TheoryData<string> Sides()
        {
            var data = new TheoryData<string>();
            foreach (var m in Contracts.MessageTypes)
            {
                if (m.Request is { CanValidate: true })
                {
                    data.Add(m.Key + " request");
                }

                if (m.Reply is { CanValidate: true })
                {
                    data.Add(m.Key + " reply");
                }
            }

            return data;
        }

        [Fact]
        public void The_registry_has_every_message_type_the_listener_handles()
        {
            Assert.Equal(64, Contracts.MessageTypes.Count);
            Assert.Equal(Contracts.MessageTypes.Count, Contracts.MessageTypes.Select(m => m.Key).Distinct().Count());
            Assert.NotNull(Contracts.Find("Ping", "1.0"));
            Assert.NotNull(Contracts.Find("GetKitEvaluation", "2.1"));
            Assert.NotNull(Contracts.Find("GetVCADSTestRequestKitInformation", "1.0"));
            Assert.Null(Contracts.Find("GetKitEvaluation", "9.9"));
            Assert.Equal(["Audit", "Aftermarket", "Production", "Development", "Service Configurator", "VCADS"], Contracts.MessageTypes.Select(m => m.Area).Distinct());
        }

        [Fact]
        public void Sides_the_contracts_do_not_define_are_marked_missing()
        {
            Assert.True(Contracts.Find("GetProductionSoftwareBreakdown", "2.1")!.Request!.Missing);
            var spareCab = Contracts.Find("ESW_SPARECAB_BREAKDOWN_REQUEST", "2.1")!.Reply!;
            Assert.Equal("ProductsUpdate_1.1.11-Final.xsd", spareCab.File);
            Assert.Contains("ProductsUpdate 1.1", spareCab.Note);
            Assert.Equal("ErrorReport", Contracts.Find("ESW_ASSIGNED_NODENAMES_IN_KIT_REQUEST", "1.0")!.ErrorReply!.Root);
            Assert.False(Contracts.Find("ESW_SPARECAB_BREAKDOWN_REQUEST", "2.1")!.Request!.Missing);
            Assert.Null(Contracts.Find("Ping", "1.0")!.Request);
            Assert.True(Contracts.Find("ProductUpdateService", "2.0")!.Request!.Json);
        }

        [Theory]
        [MemberData(nameof(Sides))]
        public void Every_sample_follows_its_own_contract(string side)
        {
            var key = side[..side.LastIndexOf(' ')];
            var type = Contracts.MessageTypes.Single(m => m.Key == key);
            var contract = side.EndsWith(" request", StringComparison.Ordinal) ? type.Request! : type.Reply!;
            var sample = Contracts.Sample(contract);
            Assert.Equal(contract.Root, sample.Root!.Name.LocalName);
            Assert.Empty(Contracts.Validate(contract, XDocument.Parse(sample.ToString(), LoadOptions.SetLineInfo)));
        }

        [Fact]
        public void Schemas_are_served_by_name_only()
        {
            Assert.Contains("targetNamespace=\"http://www.volvo.com/KitEvaluation/2_1\"", Contracts.Schema("KitEvaluation_2.1.4-Final.xsd"));
            Assert.Null(Contracts.Schema("../listener.json"));
            Assert.Null(Contracts.Schema("Nothing.xsd"));
        }

        [Fact]
        public void A_document_with_another_root_is_refused()
        {
            var contract = Contracts.Find("GetKitEvaluation", "2.1")!.Request!;
            var errors = Contracts.Validate(contract, XDocument.Parse("<GetKitEvaluation/>"));
            Assert.Contains("starts with GetKitEvaluation (http://www.volvo.com/KitEvaluation/2_1)", Assert.Single(errors));
        }

        [Fact]
        public async Task Ping_answers_OK_whatever_the_body()
        {
            var result = await Dispatcher().DispatchAsync("Ping", "1.0", "<not xml", Tester, "tester", CancellationToken.None);
            Assert.True(result.Simulated);
            Assert.Equal("OK", result.Reply!.Body);
            Assert.Equal(ListenerReply.Text, result.Reply.MediaType);
            Assert.Empty(result.Notices);
        }

        [Fact]
        public async Task Unknown_message_types_are_refused_as_the_listener_does()
        {
            var fault = await Assert.ThrowsAsync<RequestFault>(async () => await Dispatcher().DispatchAsync("GetKitEvaluation", "9.9", "", Tester, "tester", CancellationToken.None));
            Assert.Equal(404, fault.Status);
            Assert.Equal("Unhandled message type and version GetKitEvaluation_9.9.", fault.Message);
        }

        [Fact]
        public async Task Requests_are_checked_before_anything_is_answered()
        {
            var dispatcher = Dispatcher();
            var broken = await dispatcher.DispatchAsync("GetKitEvaluation", "2.1", "<GetKitEvaluation", Tester, "tester", CancellationToken.None);
            Assert.Equal(ListenerNotice.InvalidXml, Assert.Single(broken.Notices).Code);

            var wrong = await dispatcher.DispatchAsync("GetKitEvaluation", "2.1", "<GetKitEvaluation xmlns=\"http://www.volvo.com/KitEvaluation/2_1\"/>", Tester, "tester", CancellationToken.None);
            Assert.Equal(ListenerNotice.InvalidMessage, Assert.Single(wrong.Notices).Code);
            Assert.NotEmpty(wrong.RequestErrors);
            Assert.Null(wrong.Reply);

            var version = await dispatcher.DispatchAsync("ESW_CAMPAIGN_REQUEST", "1.0", "<KitRequest xmlns=\"http://esw.volvo.com/kitrequest/1_1\" schemaVersion=\"1.0\"/>", Tester, "tester", CancellationToken.None);
            Assert.Equal("RequestVersionError", Assert.Single(version.Notices).Name);
            Assert.Contains("1.1 does not match the XML schema version 1.0", version.Notices[0].Text);
        }

        [Fact]
        public async Task A_valid_request_of_a_type_not_simulated_yet_says_so()
        {
            var dispatcher = Dispatcher();
            var sample = Contracts.Sample(Contracts.Find("GetKitEvaluation", "2.1")!.Request!).ToString();
            var result = await dispatcher.DispatchAsync("GetKitEvaluation", "2.1", sample, Tester, "tester", CancellationToken.None);
            Assert.False(result.Simulated);
            Assert.Empty(result.RequestErrors);
            Assert.Null(result.Reply);
            Assert.Contains("does not simulate GetKitEvaluation_2.1 yet", Assert.Single(result.Notices).Text);
        }

        [Fact]
        public async Task A_reply_that_leaves_its_contract_is_reported()
        {
            var dispatcher = new ListenerDispatcher(Contracts, [new FixedReply("GetKitEvaluation_2.1", "<ShowKitEvaluation xmlns=\"http://www.volvo.com/KitEvaluation/2_1\"/>")]);
            var sample = Contracts.Sample(Contracts.Find("GetKitEvaluation", "2.1")!.Request!).ToString();
            var result = await dispatcher.DispatchAsync("GetKitEvaluation", "2.1", sample, Tester, "tester", CancellationToken.None);
            Assert.True(result.Simulated);
            Assert.NotEmpty(result.ReplyErrors);
        }

        [Fact]
        public void Contract_versions_come_from_the_namespace()
        {
            Assert.Equal("2.1", ListenerDispatcher.ContractVersion(Contracts.Find("GetKitEvaluation", "2.1")!.Request!));
            Assert.Equal("1.1", ListenerDispatcher.ContractVersion(Contracts.Find("ESW_ASSIGNED_NODENAMES_IN_KIT_REQUEST", "1.0")!.Request!));
        }

        private static ListenerDispatcher Dispatcher() => new(Contracts, [new PingHandler()]);

        private sealed class FixedReply : IListenerHandler
        {
            private readonly string _body;

            public FixedReply(string key, string body)
            {
                Keys = [key];
                _body = body;
            }

            public IReadOnlyCollection<string> Keys { get; }

            public ValueTask<ListenerReply> HandleAsync(ListenerMessage message, CancellationToken ct) => ValueTask.FromResult(new ListenerReply(_body, ListenerReply.Xml, [], []));

            public ListenerReply Reject(ListenerMessage message, ListenerNotice notice) => new(string.Empty, ListenerReply.Xml, [notice], []);
        }
    }
}
