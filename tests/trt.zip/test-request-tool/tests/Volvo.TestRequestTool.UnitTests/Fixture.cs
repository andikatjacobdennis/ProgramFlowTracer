using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
using Volvo.TestRequestTool.Infrastructure;
namespace Volvo.TestRequestTool.UnitTests
{
    public sealed class Fixture : IDisposable
    {
        public string Directory { get; } = Path.Combine(Path.GetTempPath(), "testrequest-" + Guid.NewGuid().ToString("N"));
        public JsonCatalog Catalog { get; } = new();
        public WorkspaceRepository Store { get; }
        public RequestService Service { get; }
        /// <summary>The services folder (EDB, CBR, ...) for the file transport, filled with the shipped reference data.</summary>
        public string Services => Path.Combine(Directory, "services");
        public ServiceGateway Gateway { get; }
        public Actor Writer { get; } = new("alice", new HashSet<int> { 101, 102, 103, 104 }, true);

        public Fixture()
        {
            Store = Open(Directory);
            RepositorySeeder.SeedServicesAsync(Services, default).GetAwaiter().GetResult();
            Gateway = new ServiceGateway(() => new ServiceSettings { Path = Services });
            Service = new RequestService(Store, Catalog, [new SoftwareHandler(Catalog), new ConversionKitHandler(Catalog), new SpareCabHandler(Catalog), new AvailableUpdatesHandler(Catalog), new BreakdownHandler(Catalog, RequestKind.ProductionBreakdown), new BreakdownHandler(Catalog, RequestKind.DevelopmentBreakdown), new ProductUpdateServiceHandler(Catalog), new AvailableProductUpdatesHandler(Catalog)], [new CatalogValidator(), new HardwareValidator(), new DependencyValidator(), new ParameterValidator(), new VariantValidator()], TimeProvider.System);
        }

        public ProductDocument Product(string number = "333333") => new(Catalog.Data.A("vehicles").Objects().First(p => p["productSpecification"]!["productInformation"].S("chassisNumber") == number));
        public static RequestCommand Command(ProductDocument p, int operation = 3, int scenario = 1) => new(RequestKind.Software, new JsonObject { ["products"] = new JsonArray(p.Data.DeepClone()), ["softwareRequestOperation"] = operation, ["scenario"] = scenario, ["pblUpdateCapable"] = true, ["enableMultiNodeBehavior"] = true });

        /// <summary>The repository in a folder (filled with the reference vehicles the first time), as the app opens it.</summary>
        public static WorkspaceRepository Open(string directory)
        {
            var docs = new FileDocumentStore(Path.Combine(directory, "repo"), new Dictionary<string, string> { ["vehicles"] = "xml", ["vehicle-originals"] = "xml", ["vehicle-revisions"] = "xml" });
            RepositorySeeder.SeedRepositoryAsync(docs, TimeProvider.System, default).GetAwaiter().GetResult();
            return new WorkspaceRepository(docs, TimeProvider.System);
        }

        public void Dispose()
        {
            Store.Dispose();
            // A collection may still be loading in the background (a cancelled caller does not stop the shared load): try a few times.
            for (var i = 0; i < 20 && System.IO.Directory.Exists(Directory); i++)
            {
                try
                {
                    System.IO.Directory.Delete(Directory, true);
                }
                catch (IOException)
                {
                    Thread.Sleep(50);
                }
                catch (UnauthorizedAccessException)
                {
                    Thread.Sleep(50);
                }
            }
        }
    }
}
