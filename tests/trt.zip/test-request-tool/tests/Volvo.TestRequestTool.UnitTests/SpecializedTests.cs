using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.UnitTests
{
    public sealed class SpecializedTests
    {
        [Fact]
        public async Task Missing_kit_is_an_error()
        {
            using var f = new Fixture();
            var p = f.Product();
            var c = new RequestCommand(RequestKind.ConversionKit, new JsonObject { ["products"] = new JsonArray(p.Data.DeepClone()), ["conversionKitNumbers"] = new JsonArray(new JsonObject { ["conversionKitNumber"] = "missing" }) });
            var r = await f.Service.ExecuteAsync(f.Writer, c, default);
            Assert.Contains(r.Outcomes[0].Issues, i => i.Code == "kit_missing");
        }

        [Fact]
        public async Task Seed_conversion_kit_changes_variants()
        {
            using var f = new Fixture();
            var p = f.Product("123456");
            var c = new RequestCommand(RequestKind.ConversionKit, new JsonObject { ["products"] = new JsonArray(p.Data.DeepClone()), ["scenario"] = 3, ["conversionKitNumbers"] = new JsonArray(new JsonObject { ["conversionKitNumber"] = "23187002" }) });
            var r = await f.Service.ExecuteAsync(f.Writer, c, default);
            Assert.Contains(r.Outcomes[0].Proposal["productSpecification"]!.A("variants").Objects(), v => v.S("symbol") == "ADR");
        }

        [Fact]
        public async Task Spare_cab_requires_a_baseline()
        {
            using var f = new Fixture();
            var c = new RequestCommand(RequestKind.SpareCab, new JsonObject { ["product"] = f.Product("123456").Data });
            var r = await f.Service.ExecuteAsync(f.Writer, c, default);
            Assert.Contains(r.Outcomes[0].Issues, i => i.Code == "baseline_required");
        }

        [Fact]
        public async Task Edb_source_retains_authorized_reference_identity()
        {
            using var f = new Fixture();
            var source = new Volvo.TestRequestTool.Application.ExternalSources(f.Catalog, f.Store, f.Gateway);
            var p = new ProductDocument(await source.EdbAsync("VSS-12-345", f.Writer, default));
            Assert.Equal("FH|123456", p.Id);
            Assert.Empty(p.Nodes);
        }

        [Fact]
        public async Task CBR_order_lookup_returns_variants_and_parts()
        {
            using var f = new Fixture();
            var source = new Volvo.TestRequestTool.Application.ExternalSources(f.Catalog, f.Store, f.Gateway);
            var r = await source.SpareCabOrderAsync("99850557", f.Writer, default);
            Assert.NotEmpty(r.A("variants"));
            Assert.NotEmpty(r.A("softwareRelatedHardwares"));
        }
    }
}
