using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
using Volvo.TestRequestTool.Infrastructure;
namespace Volvo.TestRequestTool.UnitTests
{
    public sealed class PersistenceAndExtensionTests
    {
        [Fact]
        public async Task Draft_save_requires_the_latest_version()
        {
            using var f = new Fixture();
            var first = await f.Store.SaveDraftAsync("draft", "alice", new JsonObject { ["x"] = 1 }, null, default);
            Assert.Equal(1, first.Version);
            await f.Store.SaveDraftAsync("draft", "alice", new JsonObject { ["x"] = 2 }, 1, default);
            var e = await Assert.ThrowsAsync<RequestFault>(() => f.Store.SaveDraftAsync("draft", "alice", new JsonObject(), 1, default));
            Assert.Equal(409, e.Status);
            Assert.Null(await f.Store.DraftAsync("draft", "bob", default));
        }

        [Fact]
        public async Task Exactly_one_concurrent_save_wins()
        {
            using var f = new Fixture();
            await f.Store.SaveDraftAsync("draft", "alice", new JsonObject(), null, default);
            async Task<bool> Save()
            {
                try
                {
                    await f.Store.SaveDraftAsync("draft", "alice", new JsonObject(), 1, default);
                    return true;
                }
                catch (RequestFault e) when (e.Status == 409)
                {
                    return false;
                }
            }
            var winners = await Task.WhenAll(Save(), Save());
            Assert.Single(winners, x => x);
        }

        [Fact]
        public async Task Drafts_survive_adapter_restart()
        {
            using var f = new Fixture();
            await f.Store.SaveDraftAsync("draft", "alice", new JsonObject { ["label"] = "persisted" }, null, default);
            using var reopened = Fixture.Open(f.Directory);
            Assert.Equal("persisted", (await reopened.DraftAsync("draft", "alice", default))!.State.S("label"));
        }

        [Fact]
        public async Task Reading_does_not_expose_mutable_repository_state()
        {
            using var f = new Fixture();
            var p = (await f.Store.VehicleAsync("FH|333333", default))!;
            p.Product["nodes"]!.AsArray().Clear();
            Assert.NotEmpty((await f.Store.VehicleAsync("FH|333333", default))!.Product.A("nodes"));
        }

        [Fact]
        public async Task Validators_run_in_declared_order_and_can_block_delivery()
        {
            using var f = new Fixture();
            var called = new List<string>();
            var service = new RequestService(f.Store, f.Catalog, [new SoftwareHandler(f.Catalog)], [new ExampleValidator("later", 20, called), new ExampleValidator("first", 1, called)], TimeProvider.System);
            var r = await service.ExecuteAsync(f.Writer, Fixture.Command(f.Product()), default);
            Assert.Equal(new[] { "first", "later" }, called);
            Assert.False(r.Outcomes[0].IsReady);
        }

        [Fact]
        public void Duplicate_validation_names_fail_at_composition()
        {
            using var f = new Fixture();
            Assert.Throws<InvalidOperationException>(() => new RequestService(f.Store, f.Catalog, [new SoftwareHandler(f.Catalog)], [new ExampleValidator("same", 1, []), new ExampleValidator("same", 2, [])], TimeProvider.System));
        }

        [Fact]
        public async Task New_handler_can_replace_a_request_kind_without_dispatch_changes()
        {
            using var f = new Fixture();
            var service = new RequestService(f.Store, f.Catalog, [new ExampleHandler()], [], TimeProvider.System);
            var r = await service.ExecuteAsync(f.Writer, new RequestCommand(RequestKind.AvailableUpdates, Fixture.Command(f.Product()).Payload), default);
            Assert.Equal("custom handler", r.Outcomes[0].Proposal["productSpecification"]!["productInformation"].S("extension"));
        }

        [Fact]
        public async Task Integrations_turned_off_fail_explicitly()
        {
            var settings = new ServiceSettings { Path = Path.GetTempPath() };
            settings.Endpoints["Dependix"] = new ServiceEndpoint { Transport = "Off" };
            var adapter = new GatewayCapability("Dependix", new ServiceGateway(() => settings));
            Assert.False(adapter.IsConfigured);
            var e = await Assert.ThrowsAsync<RequestFault>(() => adapter.InvokeAsync(new JsonObject(), default));
            Assert.Equal(501, e.Status);
        }

        private sealed class ExampleValidator : IProductValidator
        {
            private readonly string _name;
            private readonly int _order;
            private readonly List<string> _calls;

            public ExampleValidator(string name, int order, List<string> calls)
            {
                _name = name;
                _order = order;
                _calls = calls;
            }

            public string Name => _name;
            public int Order => _order;

            public ValueTask<IReadOnlyList<ValidationIssue>> ValidateAsync(ValidationContext context, CancellationToken ct)
            {
                _calls.Add(_name);
                return ValueTask.FromResult<IReadOnlyList<ValidationIssue>>([new("custom_rule", "Custom validation blocked this proposal.")]);
            }
        }

        private sealed class ExampleHandler : IRequestHandler
        {
            public RequestKind Kind => RequestKind.AvailableUpdates;

            public ValueTask<HandlerResult> HandleAsync(ProductDocument original, JsonObject payload, CancellationToken ct)
            {
                var p = original.Copy();
                p.Info["extension"] = "custom handler";
                return ValueTask.FromResult(new HandlerResult(p, []));
            }
        }
    }
}
