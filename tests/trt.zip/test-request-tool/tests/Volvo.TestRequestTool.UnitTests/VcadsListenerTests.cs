using System.Xml.Linq;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
using Volvo.TestRequestTool.Infrastructure;

namespace Volvo.TestRequestTool.UnitTests
{
    /// <summary>The rules of the simulated VCADS message types (the contract checks run in AftermarketListenerTests).</summary>
    public sealed class VcadsListenerTests : IDisposable
    {
        private static readonly ListenerContracts Contracts = new();
        private static readonly XNamespace Ns = "http://www.volvo.com/VCADS/1_0";
        private readonly Fixture _f = new();
        private readonly ListenerDispatcher _listener;

        public VcadsListenerTests()
        {
            _listener = new ListenerDispatcher(Contracts, AftermarketHandlers.Create(_f.Catalog, _f.Store, TimeProvider.System));
        }

        public void Dispose() => _f.Dispose();

        [Fact]
        public async Task A_software_replacement_assigns_the_new_node_template_and_its_parts()
        {
            var result = await Send("GetVCADSSoftwareReplacement", await Vehicle("FH|123456"));
            Assert.Contains("<ErrorCode>Ok</ErrorCode>", result.Reply!.Body);
            Assert.Contains("<Number>22100020</Number>", result.Reply.Body);
            Assert.Contains(result.Reply.Summary, s => s.Value.StartsWith("EMS_24.40 → EMS_26.10", StringComparison.Ordinal));
        }

        [Fact]
        public async Task A_kit_gives_one_step_with_the_computers_it_affects()
        {
            var result = await Send("GetVCADSKitInformation", await Vehicle("FM|654321"));
            Assert.Contains("<RequestedKitPartNumber>23187001</RequestedKitPartNumber>", result.Reply!.Body);
            Assert.Contains("<AffectedMids>", result.Reply.Body);
            Assert.Contains("<VariantOperation>", result.Reply.Body);
        }

        [Fact]
        public async Task The_test_request_versions_also_allow_kits_in_progress()
        {
            var vehicle = await Vehicle("FH|123456");
            var plain = await Send("GetVCADSHardwareReplacement", vehicle);
            var test = await Send("GetVCADSTestRequestHardwareReplacement", vehicle);
            Assert.DoesNotContain("<int>23187004</int>", plain.Reply!.Body);
            Assert.Contains("<int>23187004</int>", test.Reply!.Body);
        }

        [Fact]
        public async Task A_missing_vehicle_field_and_an_unknown_chassis_get_the_listeners_codes()
        {
            var vehicle = await Vehicle("FH|123456");
            var doc = XDocument.Parse(_listener.ExampleText(Contracts.Find("GetVCADSKitInformation", "1.0")!, vehicle)!);
            doc.Descendants(Ns + "ProductClass").First().Value = "";
            var missing = await Dispatch("GetVCADSKitInformation", doc.ToString());
            Assert.Contains("<ErrorCode>Configurator_Internal</ErrorCode>", missing.Reply!.Body);
            Assert.Contains("Message: Mandatory field 'ProductClass' is missing a value.", missing.Reply.Body);

            doc = XDocument.Parse(_listener.ExampleText(Contracts.Find("GetVCADSSoftwareReplacement", "1.0")!, vehicle)!);
            doc.Descendants(Ns + "ChassisNumber").First().Value = "999999";
            var unknown = await Dispatch("GetVCADSSoftwareReplacement", doc.ToString());
            Assert.Contains("<ErrorCode>VDA_ChassisMissing</ErrorCode>", unknown.Reply!.Body);
            Assert.Contains("<Steps xsi:nil=\"true\" />", unknown.Reply.Body);
        }

        [Fact]
        public async Task The_complete_vehicle_lists_software_then_hardware_then_node_templates()
        {
            var result = await Send("GetVCADSCompleteVehicle", await Vehicle("RT|777"));
            var types = XDocument.Parse(result.Reply!.Body).Descendants(Ns + "ComponentType").Select(e => e.Value).ToList();
            Assert.True(types.IndexOf("ECU") > types.IndexOf("MSW") && types.LastIndexOf("NTP") == types.Count - 1, string.Join(",", types));
            Assert.Contains("<AssemblyDate>", result.Reply.Body);
        }

        private async Task<ProductDocument> Vehicle(string id) => new((await _f.Store.VehicleAsync(id, default))!.Product);

        private async Task<ListenerResult> Dispatch(string messageType, string body)
        {
            var result = await _listener.DispatchAsync(messageType, "1.0", body, _f.Writer, "tests", default);
            Assert.Empty(result.RequestErrors);
            Assert.True(result.ReplyErrors.Count == 0, string.Join(" | ", result.ReplyErrors));
            return result;
        }

        private Task<ListenerResult> Send(string messageType, ProductDocument vehicle) => Dispatch(messageType, _listener.ExampleText(Contracts.Find(messageType, "1.0")!, vehicle)!);
    }
}
