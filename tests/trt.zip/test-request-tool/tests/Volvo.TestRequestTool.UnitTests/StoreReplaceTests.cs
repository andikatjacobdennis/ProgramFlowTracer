using Volvo.TestRequestTool.Infrastructure;

namespace Volvo.TestRequestTool.UnitTests
{
    /// <summary>
    /// Replacing the workspace file (FileDocumentStore.ReplaceAsync): a brief lock by another process (antivirus, indexer,
    /// an editor) is retried; a lock that does not go away is still reported.
    /// </summary>
    public sealed class StoreReplaceTests : IDisposable
    {
        private readonly string _dir = Path.Combine(Path.GetTempPath(), "studio-replace-" + Guid.NewGuid().ToString("N"));
        public StoreReplaceTests() => Directory.CreateDirectory(_dir);

        public void Dispose()
        {
            try
            {
                Directory.Delete(_dir, true);
            }
            catch (IOException) { }
        }

        [Fact]
        public async Task A_briefly_locked_target_is_replaced_once_the_lock_goes()
        {
            var target = Path.Combine(_dir, "workspace.json");
            var temporary = target + ".tmp";
            File.WriteAllText(target, "old");
            File.WriteAllText(temporary, "new");
            var holder = new FileStream(target, FileMode.Open, FileAccess.Read, FileShare.None);
            _ = Task.Delay(120).ContinueWith(_ => holder.Dispose());
            await FileDocumentStore.ReplaceAsync(temporary, target, default);
            Assert.Equal("new", File.ReadAllText(target));
            Assert.False(File.Exists(temporary));
        }

        [Fact]
        public async Task A_lock_that_stays_is_reported_and_the_old_file_is_kept()
        {
            var target = Path.Combine(_dir, "workspace.json");
            var temporary = target + ".tmp";
            File.WriteAllText(target, "old");
            File.WriteAllText(temporary, "new");
            using (new FileStream(target, FileMode.Open, FileAccess.Read, FileShare.None))
            {
                var e = await Record.ExceptionAsync(() => FileDocumentStore.ReplaceAsync(temporary, target, default, attempts: 3));
                Assert.True(e is UnauthorizedAccessException or IOException, e?.GetType().Name);
            }
            Assert.Equal("old", File.ReadAllText(target));
        }
    }
}
