using System.Text.Json.Nodes;
using System.Xml.Linq;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
using Volvo.TestRequestTool.Infrastructure;

namespace Volvo.TestRequestTool.UnitTests
{
    /// <summary>The rules of the simulated Service Configurator message types (the contract checks run in AftermarketListenerTests).</summary>
    public sealed class ServiceConfiguratorListenerTests : IDisposable
    {
        private static readonly ListenerContracts Contracts = new();
        private readonly Fixture _f = new();
        private readonly ListenerDispatcher _listener;
        private readonly SnapshotCatalog _catalog;

        public ServiceConfiguratorListenerTests()
        {
            _catalog = new SnapshotCatalog(_f.Catalog);
            _listener = new ListenerDispatcher(Contracts, AftermarketHandlers.Create(_catalog, _f.Store, TimeProvider.System));
        }

        public void Dispose() => _f.Dispose();

        [Fact]
        public async Task A_variant_recipe_adds_the_variant_a_node_template_needs_and_deletes_its_rival()
        {
            var result = await Send("GetParameterRecipe", "1.0", await Vehicle("FM|654321"));
            Assert.Contains("<VariantId>ISH</VariantId>", result.Reply!.Body);
            Assert.Contains("<Delete>", result.Reply.Body);
            Assert.StartsWith("2 alternative recipe group(s)", result.Reply.Summary[0].Value);
        }

        [Fact]
        public async Task A_value_no_node_template_gives_is_NO_RECIPE()
        {
            var vehicle = await Vehicle("FM|654321");
            var doc = XDocument.Parse(_listener.ExampleText(Contracts.Find("GetParameterRecipe", "1.1")!, vehicle)!);
            doc.Descendants().First(e => e.Name.LocalName == "String" || e.Name.LocalName == "Scalar").Value = "NEVER";
            var result = await _listener.DispatchAsync("GetParameterRecipe", "1.1", doc.ToString(), _f.Writer, "tests", default);
            Assert.Empty(result.ReplyErrors);
            Assert.Contains("<Type>NO RECIPE</Type>", result.Reply!.Body);
            Assert.DoesNotContain("AlternativeRecipeGroups", result.Reply.Body);
        }

        [Fact]
        public async Task An_aftermarket_recipe_is_a_refresh_an_update_or_a_kit()
        {
            var result = await Send("GetAftermarketParameterRecipe", "1.0", await Vehicle("FH|123456"));
            Assert.Matches("SoftwareRefresh|SoftwareUpdates|ApplyKit", result.Reply!.Body);
        }

        [Fact]
        public async Task Capabilities_are_the_parameters_the_catalog_marks()
        {
            var vehicle = await Vehicle("FH|123456");
            var none = await Send("GetCapabilityResourceBreakdown", "1.1", vehicle);
            Assert.Contains("NO CAPABILITY DATA", none.Reply!.Body);
            Assert.DoesNotContain("ComponentCapabilities", none.Reply.Body);

            var definitions = (JsonObject)_catalog.Data["paramDefs"]!;
            ((JsonObject)definitions["1:P1ALG"]!)["capability"] = true;
            ((JsonObject)definitions["1:P1BCX"]!)["resource"] = true;
            var marked = await Send("GetCapabilityResourceBreakdown", "1.0", vehicle);
            Assert.Contains(">P1ALG</ParameterCode>", marked.Reply!.Body);
            Assert.Contains("<Resources>", marked.Reply.Body);
            Assert.DoesNotContain("NO CAPABILITY DATA", marked.Reply.Body);

            // P1ALG, the value the example asks for, is no longer marked: the recipe refuses it.
            ((JsonObject)definitions["1:P1ALG"]!)["capability"] = false;
            var recipe = await Send("GetAftermarketParameterRecipe", "1.0", vehicle);
            Assert.Contains("NOT RESOURCE OR CAPABILITY", recipe.Reply!.Body);
        }

        [Fact]
        public async Task A_request_that_cannot_be_read_gets_a_technical_error_within_the_contract()
        {
            var result = await _listener.DispatchAsync("GetCapabilityResourceBreakdown", "1.0", "<CapabilityResourceBreakdownRequest xmlns=\"http://esw.volvo.com/capabilitybreakdownrequest/1_0\"/>", _f.Writer, "tests", default);
            Assert.Equal(107, result.Notices[0].Code);
            Assert.Empty(result.ReplyErrors);
            Assert.Contains("The Capability Breakdown request has an invalid format and could not be processed.", result.Reply!.Body);
        }

        private async Task<ProductDocument> Vehicle(string id) => new((await _f.Store.VehicleAsync(id, default))!.Product);

        private async Task<ListenerResult> Send(string messageType, string version, ProductDocument vehicle)
        {
            var result = await _listener.DispatchAsync(messageType, version, _listener.ExampleText(Contracts.Find(messageType, version)!, vehicle)!, _f.Writer, "tests", default);
            Assert.Empty(result.RequestErrors);
            Assert.True(result.ReplyErrors.Count == 0, string.Join(" | ", result.ReplyErrors) + "\n" + result.Reply?.Body);
            Assert.NotNull(result.Reply);
            return result;
        }
    }
}
