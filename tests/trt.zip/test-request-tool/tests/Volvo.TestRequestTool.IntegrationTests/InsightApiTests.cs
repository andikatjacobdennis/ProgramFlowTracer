using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>Endpoints behind the Vehicle page (timeline, snapshot, roadmap) and the About page.</summary>
    public sealed class InsightApiTests
    {
        [Fact]
        public async Task Timeline_lists_the_history_and_a_commit_adds_who_and_what()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            var before = (await c.GetFromJsonAsync<JsonObject>("/api/v1/vehicles/FH/333333/timeline"))!;
            Assert.Contains(before.A("entries").Objects(), e => e.S("kind") == "Built");

            var product = (JsonObject)(await c.GetFromJsonAsync<JsonObject>("/api/v1/vehicles/FH/333333"))!["product"]!.DeepClone();
            var run = await c.PostAsJsonAsync("/api/v1/requests", new { kind = "Software", payload = new { products = new[] { product }, softwareRequestOperation = 3, scenario = 1, pblUpdateCapable = true, enableMultiNodeBehavior = true } });
            var record = (await run.Content.ReadFromJsonAsync<JsonObject>())!;
            Assert.Equal(HttpStatusCode.OK, (await c.PostAsJsonAsync("/api/v1/vda/commit", new { requestId = record.S("id"), vehicleId = "FH|333333", expectedRevision = 1 })).StatusCode);

            var after = (await c.GetFromJsonAsync<JsonObject>("/api/v1/vehicles/FH/333333/timeline"))!;
            var commit = after.A("entries").Objects().First();
            Assert.Equal("VdaCommit", commit.S("kind"));
            Assert.False(string.IsNullOrWhiteSpace(commit["actor"].S("name")));
            Assert.NotEmpty(commit.A("changes"));
            Assert.Equal(HttpStatusCode.OK, (await c.GetAsync("/api/v1/vehicles/FH/333333/timeline/" + commit.S("id"))).StatusCode);
        }

        [Fact]
        public async Task Timeline_can_be_loaded_a_page_at_a_time()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            var first = (await c.GetFromJsonAsync<JsonObject>("/api/v1/vehicles/FH/123456/timeline?skip=0&take=2"))!;
            Assert.Equal(2, first.A("entries").Count);
            Assert.True(first.B("hasMore"));
            var next = (await c.GetFromJsonAsync<JsonObject>("/api/v1/vehicles/FH/123456/timeline?skip=2&take=100"))!;
            Assert.False(next.B("hasMore"));
            Assert.Equal(first.I("total"), 2 + next.A("entries").Count);
        }

        [Fact]
        public async Task Roadmap_returns_nodes_and_service_packs()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            var road = (await c.GetFromJsonAsync<JsonObject>("/api/v1/vehicles/FH/333333/roadmap"))!;
            Assert.NotEmpty(road.A("nodes"));
            Assert.NotEmpty(road.A("servicePacks"));
        }

        [Fact]
        public async Task Vehicle_insights_respect_the_context()
        {
            using var f = new TestRequestFactory { Contexts = ["101"] };
            using var c = f.CreateClient();
            Assert.Equal(HttpStatusCode.Forbidden, (await c.GetAsync("/api/v1/vehicles/FH/333333/timeline")).StatusCode);
            Assert.Equal(HttpStatusCode.Forbidden, (await c.GetAsync("/api/v1/vehicles/FH/333333/roadmap")).StatusCode);
            Assert.Equal(HttpStatusCode.Forbidden, (await c.GetAsync("/api/v1/vehicles/FH/333333/timeline/built")).StatusCode);
        }

        [Fact]
        public async Task Unknown_vehicle_or_snapshot_is_404()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            Assert.Equal(HttpStatusCode.NotFound, (await c.GetAsync("/api/v1/vehicles/FH/999999/timeline")).StatusCode);
            Assert.Equal(HttpStatusCode.NotFound, (await c.GetAsync("/api/v1/vehicles/FH/333333/timeline/rev-99")).StatusCode);
        }

        [Fact]
        public async Task About_describes_the_installation()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            var about = (await c.GetFromJsonAsync<JsonObject>("/api/v1/about"))!;
            Assert.Equal("Test Request Tool", about.S("name"));
            Assert.False(string.IsNullOrWhiteSpace(about.S("version")));
            Assert.Contains(about.A("contracts").Objects(), x => x.S("name") == "Product Update Service");
        }

        [Fact]
        public async Task Hosted_UI_loads_the_page_modules()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            var ui = await c.GetStringAsync("/");
            // The page loads one script and one stylesheet bundle; each bundle names the files it holds, in order.
            var script = System.Text.RegularExpressions.Regex.Match(ui, "src=\"(/js/app\\.[0-9a-f]{16}\\.js)\"").Groups[1].Value;
            var style = System.Text.RegularExpressions.Regex.Match(ui, "href=\"(/css/app\\.[0-9a-f]{16}\\.css)\"").Groups[1].Value;
            var js = await c.GetStringAsync(script);
            var css = await c.GetStringAsync(style);
            foreach (var module in new[] { "js/app/core.js", "js/app/settings.js", "js/app/vehicle.js", "js/app/activity.js", "js/app/about.js" })
            {
                Assert.Contains("/* " + module + " */", js);
                Assert.Equal(HttpStatusCode.OK, (await c.GetAsync("/" + module)).StatusCode);   // the files stay available one by one
            }
            Assert.Contains("/* css/app-shell.css */", css);
            Assert.True(js.IndexOf("/* js/util.js */", StringComparison.Ordinal) < js.IndexOf("/* js/app/core.js */", StringComparison.Ordinal), "in page order");
            var bundle = await c.GetAsync(script);
            Assert.Contains("immutable", bundle.Headers.CacheControl!.ToString());
        }
    }
}
