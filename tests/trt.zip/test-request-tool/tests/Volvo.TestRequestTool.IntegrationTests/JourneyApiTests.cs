using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>
    /// The request journey pages: execution trace, change impact, fleet readiness, review and approval with separation of
    /// duties, final checks and submission with its receipt, the Requests hub, engineering insights and scoped diagnostic events.
    /// </summary>
    public sealed class JourneyApiTests
    {
        private static async Task<HttpClient> As(TestRequestFactory factory, string id)
        {
            var c = factory.CreateClient();
            c.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            var r = await c.PostAsJsonAsync("/api/v1/auth/login", TestRequestFactory.Login(id));
            c.DefaultRequestHeaders.Remove("Cookie");
            c.DefaultRequestHeaders.Add("Cookie", r.Headers.GetValues("Set-Cookie").Single(x => x.StartsWith("trt.session=", StringComparison.Ordinal)).Split(';')[0]);
            return c;
        }

        /// <summary>A software update validation of FH 333333 (T3) by the given user; returns the request id.</summary>
        private static async Task<(Guid Id, JsonObject Record)> Validate(HttpClient c, string series = "FH", string number = "333333")
        {
            var v = await c.GetFromJsonAsync<JsonObject>($"/api/v1/vehicles/{series}/{number}");
            var r = await c.PostAsJsonAsync("/api/v1/requests", new { kind = "Software", payload = new { products = new[] { v!["product"] }, softwareRequestOperation = 3, scenario = 1, pblUpdateCapable = true, enableMultiNodeBehavior = true } });
            Assert.Equal(HttpStatusCode.Created, r.StatusCode);
            var record = (await r.Content.ReadFromJsonAsync<JsonObject>())!;
            return (Guid.Parse(record["id"]!.GetValue<string>()), record);
        }

        private static async Task<JsonObject> Json(HttpResponseMessage r, HttpStatusCode expected = HttpStatusCode.OK)
        {
            var text = await r.Content.ReadAsStringAsync();
            Assert.True(r.StatusCode == expected, $"{(int)r.StatusCode}: {text}");
            return JsonNode.Parse(text)!.AsObject();
        }

        [Fact]
        public async Task Every_request_carries_its_measured_stages_and_the_trace_endpoint_explains_them()
        {
            using var factory = new TestRequestFactory();
            using var engineer = await As(factory, "engineer");
            var (id, record) = await Validate(engineer);
            Assert.NotNull(record["trace"]);
            var trace = await engineer.GetFromJsonAsync<JsonObject>($"/api/v1/requests/{id}/trace");
            Assert.True(trace!["timed"]!.GetValue<bool>());
            var stages = trace["stages"]!.AsArray().Select(s => s!["id"]!.GetValue<string>()).ToArray();
            Assert.Equal("authorise", stages[0]);
            Assert.Contains("rule:dependencies", stages);
            Assert.Contains("result", stages);
            Assert.True(trace["totals"]!["processingMs"]!.GetValue<double>() >= 0);
            Assert.StartsWith("REQ-", trace["label"]!.GetValue<string>());
            Assert.DoesNotContain("softwareProducts", trace.ToJsonString());   // sanitised: no payload content
            using var viewer = await As(factory, "viewer");
            Assert.Equal(HttpStatusCode.NotFound, (await viewer.GetAsync($"/api/v1/requests/{id}/trace")).StatusCode);   // someone else's request
        }

        [Fact]
        public async Task Change_impact_marks_changed_nodes_and_their_catalog_relationships()
        {
            using var factory = new TestRequestFactory();
            using var engineer = await As(factory, "engineer");
            var none = await Json(await engineer.PostAsJsonAsync("/api/v1/impact", new { vehicleId = "FH|333333" }));
            Assert.Equal("current", none["source"]!.GetValue<string>());
            Assert.Equal(0, none["counts"]!["changes"]!.GetValue<int>());
            Assert.All(none["modules"]!.AsArray(), m => Assert.Equal("unchanged", m!["status"]!.GetValue<string>()));
            var (id, record) = await Validate(engineer);
            var impact = await Json(await engineer.PostAsJsonAsync("/api/v1/impact", new { vehicleId = "FH|333333", requestId = id }));
            Assert.Equal("request", impact["source"]!.GetValue<string>());
            Assert.Equal("T3", impact["vehicle"]!["architecture"]!.GetValue<string>());
            var changed = impact["modules"]!.AsArray().Where(m => m!["status"]!.GetValue<string>() == "changed").ToArray();
            Assert.NotEmpty(changed);
            Assert.Contains(changed, m => m!["components"]!.AsArray().Any(c => c!["status"]!.GetValue<string>() == "changed"));
            // VCM depends on CGW in the catalog: the relationship touches a change, and the validation of this proposal verifies it.
            Assert.Contains(impact["edges"]!.AsArray(), e => e!["rule"]!.GetValue<string>().StartsWith("VCM", StringComparison.Ordinal));
            Assert.True(impact["validation"]!["current"]!.GetValue<bool>());
            Assert.DoesNotContain(impact["edges"]!.AsArray(), e => e!["state"]!.GetValue<string>() == "not-verified");
            using var outsider = await As(factory, "viewer");
            Assert.Equal(HttpStatusCode.NotFound, (await outsider.PostAsJsonAsync("/api/v1/impact", new { vehicleId = "FH|333333", requestId = id })).StatusCode);
        }

        [Fact]
        public async Task Review_needs_another_writer_the_checklist_and_current_evidence_then_submits_once()
        {
            using var factory = new TestRequestFactory();
            using var engineer = await As(factory, "engineer");
            using var reviewer = await As(factory, "reviewer");
            using var admin = await As(factory, "admin");
            var (id, _) = await Validate(engineer);
            var review = await Json(await engineer.PostAsJsonAsync("/api/v1/reviews", new { requestId = id, proposalRevision = 4, note = "Updated platform and gateway together." }), HttpStatusCode.Created);
            var rid = review["id"]!.GetValue<string>();
            Assert.Equal("open", review["status"]!.GetValue<string>());
            Assert.True(review["evidence"]!["totals"]!["changes"]!.GetValue<int>() > 0);
            // The author sees who can decide: the enabled Reviewer and Admin accounts, never the author.
            var pool = review["reviewers"]!.AsArray().Select(x => x!["name"]!.GetValue<string>() + " (" + x["role"]!.GetValue<string>() + ")").ToList();
            Assert.Contains("Kavya Nair (Reviewer)", pool);
            Assert.Contains("Ananya Iyer (Admin)", pool);
            Assert.DoesNotContain(pool, x => x.StartsWith("Rohan Mehta", StringComparison.Ordinal));
            // Assignment: the author routes it to Kavya; Ananya (Admin) takes it; neither the author nor a Viewer can be the assignee.
            var assigned = await Json(await engineer.PostAsJsonAsync($"/api/v1/reviews/{rid}/assign", new { assigneeId = "reviewer", version = review["version"]!.GetValue<long>() }));
            Assert.Equal("Kavya Nair", assigned["assignee"]!["name"]!.GetValue<string>());
            Assert.Equal(HttpStatusCode.BadRequest, (await engineer.PostAsJsonAsync($"/api/v1/reviews/{rid}/assign", new { assigneeId = "engineer", version = assigned["version"]!.GetValue<long>() })).StatusCode);
            Assert.Equal(HttpStatusCode.BadRequest, (await engineer.PostAsJsonAsync($"/api/v1/reviews/{rid}/assign", new { assigneeId = "viewer", version = assigned["version"]!.GetValue<long>() })).StatusCode);
            var queue = await reviewer.GetFromJsonAsync<JsonObject>("/api/v1/requests/overview");
            Assert.Contains(queue!["items"]!.AsArray(), i => i!["reviewId"]?.GetValue<string>() == rid && i["assignee"]?["id"]?.GetValue<string>() == "reviewer");
            var taken = await Json(await admin.PostAsJsonAsync($"/api/v1/reviews/{rid}/assign", new { assigneeId = "admin", version = assigned["version"]!.GetValue<long>() }));
            Assert.Equal("Ananya Iyer", taken["assignee"]!["name"]!.GetValue<string>());
            Assert.Contains(taken["comments"]!.AsArray(), c => c!["kind"]!.GetValue<string>() == "assigned" && c["text"]!.GetValue<string>().Contains("took this review", StringComparison.Ordinal));
            review = taken;
            Assert.Equal(rid, (await Json(await engineer.PostAsJsonAsync("/api/v1/reviews", new { requestId = id }), HttpStatusCode.Created))["id"]!.GetValue<string>());   // asking again: the same review
            var version = review["version"]!.GetValue<long>();
            // The author cannot decide (Engineer has no Writer role either), a Viewer cannot see it differently, the reviewer needs the checklist.
            Assert.Equal(HttpStatusCode.Forbidden, (await engineer.PostAsJsonAsync($"/api/v1/reviews/{rid}/decision", new { decision = "approve", checklist = new[] { "changes", "evidence", "vehicle" }, version })).StatusCode);
            Assert.Equal(HttpStatusCode.BadRequest, (await reviewer.PostAsJsonAsync($"/api/v1/reviews/{rid}/decision", new { decision = "approve", checklist = new[] { "changes" }, version })).StatusCode);
            Assert.Equal(HttpStatusCode.Conflict, (await reviewer.PostAsJsonAsync($"/api/v1/reviews/{rid}/decision", new { decision = "approve", checklist = new[] { "changes", "evidence", "vehicle" }, version = version + 7 })).StatusCode);
            var commented = await Json(await reviewer.PostAsJsonAsync($"/api/v1/reviews/{rid}/comments", new { text = "Validation evidence reviewed." }));
            var approved = await Json(await reviewer.PostAsJsonAsync($"/api/v1/reviews/{rid}/decision", new { decision = "approve", checklist = new[] { "changes", "evidence", "vehicle" }, note = "Looks right.", version = commented["version"]!.GetValue<long>() }));
            Assert.Equal("approved", approved["status"]!.GetValue<string>());
            Assert.False(string.IsNullOrEmpty(approved["decision"]!["actorName"]!.GetValue<string>()));
            // Final checks, then submission: the engineer cannot submit; unconfirmed is refused; confirmed commits once.
            var checks = await reviewer.GetFromJsonAsync<JsonObject>($"/api/v1/reviews/{rid}/checks");
            Assert.True(checks!["ok"]!.GetValue<bool>(), checks.ToJsonString());
            Assert.False((await engineer.GetFromJsonAsync<JsonObject>($"/api/v1/reviews/{rid}/checks"))!["ok"]!.GetValue<bool>());
            Assert.Equal(HttpStatusCode.Forbidden, (await engineer.PostAsJsonAsync($"/api/v1/reviews/{rid}/submit", new { confirmed = true })).StatusCode);
            Assert.Equal(HttpStatusCode.BadRequest, (await reviewer.PostAsJsonAsync($"/api/v1/reviews/{rid}/submit", new { confirmed = false })).StatusCode);
            var before = (await reviewer.GetFromJsonAsync<JsonObject>("/api/v1/vehicles/FH/333333"))!["revision"]!.GetValue<long>();
            var submitted = await Json(await reviewer.PostAsJsonAsync($"/api/v1/reviews/{rid}/submit", new { confirmed = true }));
            Assert.Equal("submitted", submitted["status"]!.GetValue<string>());
            var receipt = submitted["submission"]!;
            Assert.StartsWith("SUB-", receipt["id"]!.GetValue<string>());
            Assert.Equal(before + 1, receipt["vehicles"]![0]!["toRevision"]!.GetValue<long>());
            Assert.Contains(receipt["steps"]!.AsArray(), s => s!["text"]!.GetValue<string>() == "Snapshot committed");
            var again = await Json(await reviewer.PostAsJsonAsync($"/api/v1/reviews/{rid}/submit", new { confirmed = true }));
            Assert.Equal(receipt["id"]!.GetValue<string>(), again["submission"]!["id"]!.GetValue<string>());   // retry: same receipt, no second commit
            Assert.Equal(before + 1, (await reviewer.GetFromJsonAsync<JsonObject>("/api/v1/vehicles/FH/333333"))!["revision"]!.GetValue<long>());
            var file = await reviewer.GetAsync($"/api/v1/reviews/{rid}/receipt");
            Assert.Contains("attachment", file.Content.Headers.ContentDisposition?.ToString() ?? file.Headers.ToString() + string.Join(",", file.Content.Headers.Select(h => h.Key + "=" + string.Join(" ", h.Value))));
            // Readiness: approved and submitted for the revision it created, so the vehicle is ready.
            var readiness = await engineer.GetFromJsonAsync<JsonObject>("/api/v1/fleet/readiness");
            var row = readiness!["vehicles"]!.AsArray().Single(v => v!["id"]!.GetValue<string>() == "FH|333333")!;
            Assert.Equal("submitted", row["cells"]!["approval"]!["state"]!.GetValue<string>());
            Assert.Equal("ready", row["cells"]!["overall"]!["state"]!.GetValue<string>());
            // The audit log has the steps; the events for the request are visible to the author but not to an outsider.
            var audit = (await admin.GetFromJsonAsync<JsonArray>("/api/v1/admin/audit?take=50"))!.ToJsonString();
            Assert.Contains("review.decision", audit);
            Assert.Contains("review.submit", audit);
            var label = "REQ-" + id.ToString("N")[..6].ToUpperInvariant();
            var events = await engineer.GetFromJsonAsync<JsonObject>($"/api/v1/diagnostics/events?request={label}&take=100");
            Assert.True(events!["scoped"]!.GetValue<bool>());
            var items = events["result"]!["items"]!.AsArray();
            Assert.Contains(items, e => e!["service"]?.GetValue<string>() == "Review" && e["message"]!.GetValue<string>().StartsWith("Snapshot committed", StringComparison.Ordinal));
            Assert.All(items, e => Assert.Equal(label, e!["request"]!.GetValue<string>()));
            Assert.DoesNotContain("audience", items.ToJsonString(), StringComparison.OrdinalIgnoreCase);
            using var viewer = await As(factory, "viewer");
            Assert.Empty((await viewer.GetFromJsonAsync<JsonObject>($"/api/v1/diagnostics/events?request={label}"))!["result"]!["items"]!.AsArray());
        }

        [Fact]
        public async Task Authors_cannot_approve_their_own_request_and_stale_evidence_cannot_be_approved()
        {
            using var factory = new TestRequestFactory();
            using var admin = await As(factory, "admin");
            using var reviewer = await As(factory, "reviewer");
            var (id, record) = await Validate(admin);
            var review = await Json(await admin.PostAsJsonAsync("/api/v1/reviews", new { requestId = id }), HttpStatusCode.Created);
            var rid = review["id"]!.GetValue<string>();
            var self = await admin.PostAsJsonAsync($"/api/v1/reviews/{rid}/decision", new { decision = "approve", checklist = new[] { "changes", "evidence", "vehicle" }, version = review["version"]!.GetValue<long>() });
            Assert.Equal(HttpStatusCode.Forbidden, self.StatusCode);
            Assert.Contains("separation_of_duties", await self.Content.ReadAsStringAsync());
            // The vehicle moves on (a direct commit by the admin), so the evidence is stale.
            var revision = record["outcomes"]![0]!["baseRevision"]!.GetValue<long>();
            Assert.Equal(HttpStatusCode.OK, (await admin.PostAsJsonAsync("/api/v1/vda/commit", new { requestId = id, vehicleId = "FH|333333", expectedRevision = revision })).StatusCode);
            var stale = await reviewer.PostAsJsonAsync($"/api/v1/reviews/{rid}/decision", new { decision = "approve", checklist = new[] { "changes", "evidence", "vehicle" }, version = review["version"]!.GetValue<long>() });
            Assert.Equal(HttpStatusCode.Conflict, stale.StatusCode);
            Assert.Contains("evidence_stale", await stale.Content.ReadAsStringAsync());
            Assert.Equal(HttpStatusCode.BadRequest, (await reviewer.PostAsJsonAsync($"/api/v1/reviews/{rid}/decision", new { decision = "request_changes", version = review["version"]!.GetValue<long>() })).StatusCode);   // needs a note
            var changes = await Json(await reviewer.PostAsJsonAsync($"/api/v1/reviews/{rid}/decision", new { decision = "request_changes", note = "Validate again on the new revision.", version = review["version"]!.GetValue<long>() }));
            Assert.Equal("changes_requested", changes["status"]!.GetValue<string>());
        }

        [Fact]
        public async Task With_require_approval_on_direct_commits_are_refused()
        {
            using var factory = new TestRequestFactory();
            using var admin = await As(factory, "admin");
            Assert.Equal(HttpStatusCode.OK, (await admin.PutAsJsonAsync("/api/v1/admin/features/require-approval", new { mode = "on" })).StatusCode);
            var (id, record) = await Validate(admin);
            var r = await admin.PostAsJsonAsync("/api/v1/vda/commit", new { requestId = id, vehicleId = "FH|333333", expectedRevision = record["outcomes"]![0]!["baseRevision"]!.GetValue<long>() });
            Assert.Equal(HttpStatusCode.Conflict, r.StatusCode);
            Assert.Contains("approval_required", await r.Content.ReadAsStringAsync());
        }

        [Fact]
        public async Task The_requests_hub_readiness_and_insights_come_from_records()
        {
            using var factory = new TestRequestFactory();
            using var engineer = await As(factory, "engineer");
            using var reviewer = await As(factory, "reviewer");
            using var admin = await As(factory, "admin");
            var empty = await engineer.GetFromJsonAsync<JsonObject>("/api/v1/fleet/readiness");
            Assert.All(empty!["vehicles"]!.AsArray(), v => Assert.Equal("unknown", v!["cells"]!["overall"]!["state"]!.GetValue<string>()));
            var (id, _) = await Validate(engineer);
            await engineer.PostAsJsonAsync("/api/v1/reviews", new { requestId = id });
            var mine = await engineer.GetFromJsonAsync<JsonObject>("/api/v1/requests/overview");
            var item = mine!["items"]!.AsArray().First(i => i!["id"]?.GetValue<string>() == id.ToString())!;
            Assert.Equal("awaiting-review", item["status"]!.GetValue<string>());
            Assert.True(item["mine"]!.GetValue<bool>());
            var theirs = await reviewer.GetFromJsonAsync<JsonObject>("/api/v1/requests/overview");
            Assert.Equal(1, theirs!["counts"]!["awaitingReview"]!.GetValue<int>());
            Assert.Contains(theirs["items"]!.AsArray(), i => i!["id"]?.GetValue<string>() == id.ToString() && i["action"]!.GetValue<string>() == "Review" && !i["mine"]!.GetValue<bool>());
            var row = (await engineer.GetFromJsonAsync<JsonObject>("/api/v1/fleet/readiness"))!["vehicles"]!.AsArray().Single(v => v!["id"]!.GetValue<string>() == "FH|333333")!;
            Assert.Equal("pending", row["cells"]!["approval"]!["state"]!.GetValue<string>());
            var again = await engineer.GetFromJsonAsync<JsonObject>("/api/v1/fleet/readiness/FH/333333/revalidation");
            Assert.Equal("Software", again!["kind"]!.GetValue<string>());
            Assert.Equal(3, again["payload"]!["softwareRequestOperation"]!.GetValue<int>());
            var insights = await admin.GetFromJsonAsync<JsonObject>("/api/v1/insights/engineering?days=7");
            Assert.Equal("everyone", insights!["scope"]!.GetValue<string>());
            Assert.Equal(1, insights["totals"]!["requests"]!.GetValue<int>());
            Assert.Equal(7, insights["perDay"]!.AsArray().Count);
            Assert.NotNull(insights["totals"]!["medianMs"]);
            Assert.Equal(0, (await reviewer.GetFromJsonAsync<JsonObject>("/api/v1/insights/engineering"))!["totals"]!["requests"]!.GetValue<int>());   // others: only their own
        }
    }
}
