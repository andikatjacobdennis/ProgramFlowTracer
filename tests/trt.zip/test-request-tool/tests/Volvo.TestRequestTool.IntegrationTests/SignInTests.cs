using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
using Microsoft.AspNetCore.Mvc.Testing;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>
    /// The sign-in flow: the accounts in the settings, the session cookie, sign-out, the protected app page and API, and
    /// the way back to where the person was going.
    /// </summary>
    public sealed class SignInTests
    {
        private static HttpClient Anonymous(TestRequestFactory factory) => factory.CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect = false });

        private static async Task<HttpResponseMessage> Post(HttpClient c, object body, bool header = true)
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, "/api/v1/auth/login") { Content = JsonContent.Create(body) };
            if (header)
            {
                request.Headers.Add("X-Studio-Request", "1");
            }

            return await c.SendAsync(request);
        }

        [Fact]
        public async Task Signing_in_with_the_user_name_or_the_email_starts_a_secure_session()
        {
            using var factory = new TestRequestFactory { SignedOut = true };
            using var c = Anonymous(factory);
            var r = await Post(c, TestRequestFactory.Login("engineer"));
            Assert.Equal(HttpStatusCode.OK, r.StatusCode);
            var cookie = r.Headers.GetValues("Set-Cookie").Single(v => v.StartsWith("trt.session=", StringComparison.Ordinal));
            Assert.Contains("httponly", cookie, StringComparison.OrdinalIgnoreCase);
            Assert.Contains("samesite=strict", cookie, StringComparison.OrdinalIgnoreCase);
            var session = (await c.GetFromJsonAsync<JsonObject>("/api/v1/session"))!;
            Assert.Equal("engineer", session["userId"]!.GetValue<string>());
            Assert.Equal("Password", session["authentication"]!.GetValue<string>());
            Assert.True(session["canEdit"]!.GetValue<bool>());

            using var byEmail = Anonymous(factory);
            Assert.Equal(HttpStatusCode.OK, (await Post(byEmail, new { login = "REVIEWER@trt.test", password = TestRequestFactory.Password("reviewer") })).StatusCode);
            Assert.Equal("reviewer", (await byEmail.GetFromJsonAsync<JsonObject>("/api/v1/session"))!["userId"]!.GetValue<string>());
        }

        [Fact]
        public async Task Wrong_or_missing_credentials_are_refused_with_one_message()
        {
            using var factory = new TestRequestFactory { SignedOut = true };
            using var c = Anonymous(factory);
            var wrong = await Post(c, new { login = "engineer", password = "not-the-password" });
            Assert.Equal(HttpStatusCode.Unauthorized, wrong.StatusCode);
            Assert.Equal("invalid_credentials", (await wrong.Content.ReadFromJsonAsync<JsonObject>())!["title"]!.GetValue<string>());
            Assert.False(wrong.Headers.Contains("Set-Cookie"));
            // An unknown user gets exactly the same answer, so it does not reveal which user names exist.
            var unknown = await Post(c, new { login = "nobody", password = "whatever" });
            Assert.Equal(HttpStatusCode.Unauthorized, unknown.StatusCode);
            Assert.Equal("invalid_credentials", (await unknown.Content.ReadFromJsonAsync<JsonObject>())!["title"]!.GetValue<string>());
            Assert.Equal(HttpStatusCode.BadRequest, (await Post(c, new { login = "engineer", password = "" })).StatusCode);
            Assert.Equal(HttpStatusCode.BadRequest, (await Post(c, TestRequestFactory.Login("engineer"), header: false)).StatusCode);   // only from the sign-in page
            Assert.Equal(HttpStatusCode.Unauthorized, (await c.GetAsync("/api/v1/session")).StatusCode);
        }

        [Fact]
        public async Task Signing_out_ends_the_session()
        {
            using var factory = new TestRequestFactory();
            using var c = factory.CreateClient();
            Assert.Equal(HttpStatusCode.OK, (await c.GetAsync("/api/v1/session")).StatusCode);
            var r = await c.PostAsync("/api/v1/auth/logout", null);
            Assert.Equal(HttpStatusCode.NoContent, r.StatusCode);
            var problem = await c.GetAsync("/api/v1/session");
            Assert.Equal(HttpStatusCode.Unauthorized, problem.StatusCode);
            Assert.Equal("session_required", (await problem.Content.ReadFromJsonAsync<JsonObject>())!["title"]!.GetValue<string>());
        }

        [Fact]
        public async Task The_app_page_and_the_API_need_a_session_and_the_sign_in_page_returns_to_the_page_asked_for()
        {
            using var factory = new TestRequestFactory { SignedOut = true };
            using var c = Anonymous(factory);
            var page = await c.GetAsync("/?page=requests");
            Assert.Equal(HttpStatusCode.Redirect, page.StatusCode);
            Assert.Equal("/login?returnUrl=%2F%3Fpage%3Drequests", page.Headers.Location!.OriginalString);
            Assert.Equal(HttpStatusCode.Redirect, (await c.GetAsync("/index.html")).StatusCode);
            var login = await c.GetAsync("/login?returnUrl=%2F%3Fpage%3Drequests");
            Assert.Equal(HttpStatusCode.OK, login.StatusCode);
            Assert.Contains("lg-form", await login.Content.ReadAsStringAsync());
            foreach (var path in new[] { "/api/v1/session", "/api/v1/vehicles", "/api/v1/admin/users/search" })
            {
                Assert.Equal(HttpStatusCode.Unauthorized, (await c.GetAsync(path)).StatusCode);
            }

            Assert.Equal(HttpStatusCode.OK, (await c.GetAsync("/js/login.js")).StatusCode);   // the sign-in page's own files load without a session

            Assert.Equal(HttpStatusCode.OK, (await Post(c, TestRequestFactory.Login("viewer"))).StatusCode);
            Assert.Equal(HttpStatusCode.OK, (await c.GetAsync("/?page=requests")).StatusCode);
            var again = await c.GetAsync("/login?returnUrl=%2F%3Fpage%3Drequests");   // already signed in: straight back
            Assert.Equal("/?page=requests", again.Headers.Location!.OriginalString);
            var elsewhere = await c.GetAsync("/login?returnUrl=https%3A%2F%2Fevil.example%2F");   // never to another site
            Assert.Equal("/", elsewhere.Headers.Location!.OriginalString);
            Assert.Equal(HttpStatusCode.Forbidden, (await c.GetAsync("/api/v1/admin/users/search")).StatusCode);   // signed in, but not an administrator
        }

        [Fact]
        public async Task A_disabled_account_cannot_sign_in_and_loses_its_session()
        {
            using var factory = new TestRequestFactory();
            using var admin = factory.CreateClient();
            using var engineer = factory.CreateClient();
            await TestRequestFactory.SignInAsync(engineer, "engineer");
            admin.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            var off = await admin.PutAsJsonAsync("/api/v1/admin/users/engineer", new { id = "engineer", displayName = "Rohan Mehta", role = "Engineer", contexts = new[] { 101 }, enabled = false });
            Assert.Equal(HttpStatusCode.OK, off.StatusCode);
            Assert.Equal(HttpStatusCode.Unauthorized, (await engineer.GetAsync("/api/v1/session")).StatusCode);   // at once, not when the cookie expires
            using var again = Anonymous(factory);
            var refused = await Post(again, TestRequestFactory.Login("engineer"));
            Assert.Equal(HttpStatusCode.Forbidden, refused.StatusCode);
            Assert.Equal("account_disabled", (await refused.Content.ReadFromJsonAsync<JsonObject>())!["title"]!.GetValue<string>());
        }

        [Fact]
        public async Task A_role_change_applies_to_the_next_request()
        {
            using var factory = new TestRequestFactory();
            using var admin = factory.CreateClient();
            using var viewer = factory.CreateClient();
            await TestRequestFactory.SignInAsync(viewer, "viewer");
            Assert.False((await viewer.GetFromJsonAsync<JsonObject>("/api/v1/session"))!["canEdit"]!.GetValue<bool>());
            admin.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            Assert.Equal(HttpStatusCode.OK, (await admin.PutAsJsonAsync("/api/v1/admin/users/viewer", new { id = "viewer", displayName = "Vikram Rao", role = "Engineer", contexts = new[] { 101, 102 }, enabled = true })).StatusCode);
            var session = (await viewer.GetFromJsonAsync<JsonObject>("/api/v1/session"))!;
            Assert.True(session["canEdit"]!.GetValue<bool>());
            Assert.Equal(new[] { 101, 102 }, session["contexts"]!.AsArray().Select(x => x!.GetValue<int>()));
        }

        [Fact]
        public async Task An_account_still_on_the_example_password_cannot_sign_in()
        {
            // The accounts from settings.example.json keep CHANGE-ME until someone sets a real password.
            using var factory = new TestRequestFactory
            {
                SignedOut = true,
                Settings = { ["Authentication:Accounts:20:Id"] = "example", ["Authentication:Accounts:20:UserName"] = "example", ["Authentication:Accounts:20:Password"] = "CHANGE-ME-admin", ["Authentication:Accounts:20:Role"] = "Admin" },
            };
            using var c = Anonymous(factory);
            Assert.Equal(HttpStatusCode.Unauthorized, (await Post(c, new { login = "example", password = "CHANGE-ME-admin" })).StatusCode);
        }

        [Fact]
        public async Task Sign_in_attempts_are_rate_limited_per_address()
        {
            using var factory = new TestRequestFactory { SignedOut = true, Settings = { ["RateLimiting:Policies:auth:Limit"] = "3" } };
            using var c = Anonymous(factory);
            for (var i = 0; i < 3; i++)
            {
                Assert.Equal(HttpStatusCode.Unauthorized, (await Post(c, new { login = "admin", password = "guess-" + i })).StatusCode);
            }

            Assert.Equal((HttpStatusCode)429, (await Post(c, TestRequestFactory.Login("admin"))).StatusCode);
        }
    }
}
