using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>The usage study: fixed vocabulary only, per-user isolation, opting out, deletion and the admin overview.</summary>
    public sealed class UsageApiTests
    {
        private static async Task<HttpClient> As(TestRequestFactory factory, string id)
        {
            var c = factory.CreateClient();
            c.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            var r = await c.PostAsJsonAsync("/api/v1/auth/login", TestRequestFactory.Login(id));
            c.DefaultRequestHeaders.Remove("Cookie");
            c.DefaultRequestHeaders.Add("Cookie", r.Headers.GetValues("Set-Cookie").Single(x => x.StartsWith("trt.session=", StringComparison.Ordinal)).Split(';')[0]);
            return c;
        }

        private static object Batch(params (string e, string k)[] items) => new { events = items.Select(x => new { e = x.e, k = x.k }).ToArray() };

        [Fact]
        public async Task Only_the_fixed_vocabulary_is_accepted_never_free_text()
        {
            using var factory = new TestRequestFactory();
            using var c = await As(factory, "engineer");
            Assert.Equal(HttpStatusCode.OK, (await c.PostAsJsonAsync("/api/v1/usage/events", Batch(("page", "dashboard"), ("action", "nav.vehicle")))).StatusCode);
            Assert.Equal(HttpStatusCode.BadRequest, (await c.PostAsJsonAsync("/api/v1/usage/events", Batch(("action", "Typed FH 123456 into search")))).StatusCode);
            Assert.Equal(HttpStatusCode.BadRequest, (await c.PostAsJsonAsync("/api/v1/usage/events", Batch(("keystroke", "a")))).StatusCode);
            var mine = await c.GetFromJsonAsync<JsonObject>("/api/v1/usage/mine");
            Assert.Equal(2, mine!["events"]!.GetValue<int>());
            Assert.DoesNotContain("FH 123456", mine.ToJsonString());
        }

        [Fact]
        public async Task People_see_only_their_own_data_and_can_stop_and_delete_it()
        {
            using var factory = new TestRequestFactory();
            using var engineer = await As(factory, "engineer");
            using var reviewer = await As(factory, "reviewer");
            await engineer.PostAsJsonAsync("/api/v1/usage/events", Batch(("page", "health")));
            Assert.Equal(0, (await reviewer.GetFromJsonAsync<JsonObject>("/api/v1/usage/mine"))!["events"]!.GetValue<int>());
            // Stop recording: the server drops new events.
            await engineer.PutAsJsonAsync("/api/v1/usage/mine/consent", new { record = false });
            var dropped = await (await engineer.PostAsJsonAsync("/api/v1/usage/events", Batch(("page", "logs")))).Content.ReadFromJsonAsync<JsonObject>();
            Assert.Equal(0, dropped!["accepted"]!.GetValue<int>());
            Assert.Equal(1, (await engineer.GetFromJsonAsync<JsonObject>("/api/v1/usage/mine"))!["events"]!.GetValue<int>());
            // Delete: everything goes; the choice not to record stays.
            Assert.Equal(HttpStatusCode.NoContent, (await engineer.DeleteAsync("/api/v1/usage/mine")).StatusCode);
            var after = await engineer.GetFromJsonAsync<JsonObject>("/api/v1/usage/mine");
            Assert.Equal(0, after!["events"]!.GetValue<int>());
            Assert.False(after["recording"]!.GetValue<bool>());
        }

        [Fact]
        public async Task Only_administrators_see_the_overview_with_the_step_funnel()
        {
            using var factory = new TestRequestFactory();
            using var engineer = await As(factory, "engineer");
            await engineer.PostAsJsonAsync("/api/v1/usage/events", Batch(("step", "vehicle"), ("step", "prepare"), ("step", "validate"), ("error", "toast")));
            Assert.Equal(HttpStatusCode.Forbidden, (await engineer.GetAsync("/api/v1/admin/usage")).StatusCode);
            using var admin = await As(factory, "admin");
            var overview = await admin.GetFromJsonAsync<JsonObject>("/api/v1/admin/usage");
            var funnel = overview!["funnel"]!.AsArray().ToDictionary(x => x!["step"]!.GetValue<string>(), x => x!["count"]!.GetValue<int>());
            Assert.Equal(1, funnel["validate"]);
            Assert.Equal(0, funnel["submit"]);
            Assert.Contains(overview["people"]!.AsArray(), p => p!["id"]!.GetValue<string>() == "engineer");
        }
    }
}
