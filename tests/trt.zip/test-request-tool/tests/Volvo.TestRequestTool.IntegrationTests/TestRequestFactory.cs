using System.Net.Http.Json;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;

namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>
    /// The app with its repository, services folder and settings file in a temporary folder, and sign-in accounts for the
    /// tests: tester (the default; Admin, or Engineer when Writer is false), admin, engineer, reviewer, viewer, new-viewer and
    /// no-photo. Every client starts signed in as tester through the real sign-in endpoint; <see cref="SignInAsync"/> switches.
    /// </summary>
    public sealed class TestRequestFactory : WebApplicationFactory<Program>
    {
        private readonly string _directory = Path.Combine(Path.GetTempPath(), "studio-api-" + Guid.NewGuid().ToString("N"));
        public string Directory => _directory;
        public bool Writer { get; init; } = true;
        public string[] Contexts { get; init; } = ["101", "102", "103", "104"];
        /// <summary>Extra configuration for one test (for example tiny rate limits).</summary>
        public Dictionary<string, string?> Settings { get; init; } = [];
        /// <summary>The hosting environment (Development turns on the Visual Studio Hot Reload accommodations).</summary>
        public string Environment { get; init; } = "Testing";
        /// <summary>Clients start signed out instead of signed in as tester.</summary>
        public bool SignedOut { get; init; }
        public static readonly string[] Accounts = ["tester", "admin", "engineer", "reviewer", "viewer", "new-viewer", "no-photo"];
        public static string Password(string id) => "pw-" + id + "-7Qx";
        /// <summary>The sign-in body for one of the test accounts.</summary>
        public static object Login(string id) => new { login = id, password = Password(id) };

        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.UseContentRoot(Path.GetFullPath("../../../../../src/Volvo.TestRequestTool.Web", AppContext.BaseDirectory));
            builder.UseEnvironment(Environment);
            // Read while the app is built (before ConfigureAppConfiguration applies), so they are host settings.
            builder.UseSetting("Repository:Path", Path.Combine(_directory, "repo"));
            builder.UseSetting("Services:Path", Path.Combine(_directory, "services"));
            builder.UseSetting("Settings:File", Path.Combine(_directory, "settings.json"));
            builder.ConfigureAppConfiguration((_, config) =>
            {
                var values = new Dictionary<string, string?> { { "Repository:Path", Path.Combine(_directory, "repo") }, { "Services:Path", Path.Combine(_directory, "services") }, { "Settings:File", Path.Combine(_directory, "settings.json") } };
                var contexts = Contexts.Where(c => int.TryParse(c, out var n) && n > 0).ToArray();
                string Role(string id) => id switch { "tester" => Writer ? "Admin" : "Engineer", "admin" => "Admin", "reviewer" => "Reviewer", "viewer" or "new-viewer" => "Viewer", _ => "Engineer" };
                for (var i = 0; i < Accounts.Length; i++)
                {
                    var id = Accounts[i];
                    var key = "Authentication:Accounts:" + i + ":";
                    values[key + "Id"] = id;
                    values[key + "UserName"] = id;
                    values[key + "Email"] = id + "@trt.test";
                    values[key + "Password"] = Password(id);
                    values[key + "DisplayName"] = id switch { "tester" => "Tara Tester", "admin" => "Ananya Iyer", "engineer" => "Rohan Mehta", "reviewer" => "Kavya Nair", "viewer" => "Vikram Rao", "no-photo" => "Neha Joshi", _ => "New viewer" };
                    values[key + "Role"] = Role(id);
                    values[key + "Country"] = id switch { "viewer" => "US", "admin" => "SE", "reviewer" => "", _ => "IN" };
                    for (var c = 0; c < contexts.Length; c++)
                    {
                        values[key + "Contexts:" + c] = contexts[c];
                    }
                }
                foreach (var (k, v) in Settings)
                {
                    values[k] = v;
                }

                config.AddInMemoryCollection(values);
            });
        }

        protected override void ConfigureClient(HttpClient client)
        {
            base.ConfigureClient(client);
            if (SignedOut)
            {
                return;
            }
            // Signed in on a separate connection, so this client has sent nothing yet (the factory still sets its address).
            using var other = Server.CreateClient();
            var response = Task.Run(() => Post(other, "tester")).GetAwaiter().GetResult();
            client.DefaultRequestHeaders.Add("Cookie", SessionCookie(response));
        }

        private static async Task<HttpResponseMessage> Post(HttpClient client, string id)
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, "/api/v1/auth/login") { Content = JsonContent.Create(Login(id)) };
            request.Headers.Add("X-Studio-Request", "1");
            var response = await client.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                throw new InvalidOperationException($"Signing in as {id} failed: {(int)response.StatusCode} {await response.Content.ReadAsStringAsync()}");
            }

            return response;
        }

        /// <summary>"trt.session=…" from a sign-in answer.</summary>
        public static string SessionCookie(HttpResponseMessage response) => response.Headers.GetValues("Set-Cookie").Single(x => x.StartsWith("trt.session=", StringComparison.Ordinal)).Split(';')[0];

        /// <summary>Signs the client in as a test account: its session cookie replaces the one it had.</summary>
        public static async Task<HttpResponseMessage> SignInAsync(HttpClient client, string id)
        {
            var response = await Post(client, id);
            client.DefaultRequestHeaders.Remove("Cookie");
            client.DefaultRequestHeaders.Add("Cookie", SessionCookie(response));
            return response;
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
            if (disposing && System.IO.Directory.Exists(_directory))
            {
                try
                {
                    System.IO.Directory.Delete(_directory, true);
                }
                catch (IOException) { }
            }
        }
    }
}
