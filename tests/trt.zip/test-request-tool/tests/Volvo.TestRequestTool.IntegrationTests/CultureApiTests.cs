using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>The account country sets the default culture (culture.js); without a country the default is UTC.</summary>
    public sealed class CultureApiTests
    {
        private static async Task Switch(HttpClient client, string id)
        {
            client.DefaultRequestHeaders.Remove("X-Studio-Request");
            client.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            var response = await client.PostAsJsonAsync("/api/v1/auth/login", TestRequestFactory.Login(id));
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            var cookie = response.Headers.GetValues("Set-Cookie").Single(x => x.StartsWith("trt.session="));
            client.DefaultRequestHeaders.Remove("Cookie");
            client.DefaultRequestHeaders.Add("Cookie", cookie.Split(';')[0]);
        }

        private static async Task<string?> Country(HttpClient c) => (await c.GetFromJsonAsync<JsonObject>("/api/v1/session"))!["country"]?.GetValue<string>();

        [Fact]
        public async Task Session_carries_the_account_country()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            Assert.Equal("IN", await Country(c));
            await Switch(c, "admin");
            Assert.Equal("SE", await Country(c));
            await Switch(c, "reviewer");
            Assert.Null(await Country(c));
        }

        [Fact]
        public async Task Admin_can_set_or_clear_a_country_and_invalid_codes_are_rejected()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            await Switch(c, "admin");
            var ok = await c.PutAsJsonAsync("/api/v1/admin/users/new-viewer", new { id = "new-viewer", displayName = "Kavya Menon", role = "Viewer", contexts = new[] { 104 }, enabled = true, country = "BR" });
            Assert.Equal(HttpStatusCode.OK, ok.StatusCode);
            await Switch(c, "new-viewer");
            Assert.Equal("BR", await Country(c));

            await Switch(c, "admin");
            var cleared = await c.PutAsJsonAsync("/api/v1/admin/users/new-viewer", new { id = "new-viewer", displayName = "Kavya Menon", role = "Viewer", contexts = new[] { 104 }, enabled = true, country = "" });
            Assert.Equal(HttpStatusCode.OK, cleared.StatusCode);
            var bad = await c.PutAsJsonAsync("/api/v1/admin/users/new-viewer", new { id = "new-viewer", displayName = "Kavya Menon", role = "Viewer", contexts = new[] { 104 }, enabled = true, country = "india" });
            Assert.Equal(HttpStatusCode.BadRequest, bad.StatusCode);
            await Switch(c, "new-viewer");
            Assert.Null(await Country(c));
        }
    }
}
