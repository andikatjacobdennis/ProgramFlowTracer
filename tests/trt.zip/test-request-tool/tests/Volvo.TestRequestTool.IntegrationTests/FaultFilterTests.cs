using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>
    /// Expected faults (not found, conflict, not allowed) are answered by the API's endpoint filter with the same problem
    /// response as before: status, code as the title, the message as the detail, and the trace id.
    /// </summary>
    public sealed class FaultFilterTests
    {
        [Fact]
        public async Task An_unknown_request_on_change_impact_is_a_404_problem_with_code_and_trace_id()
        {
            using var factory = new TestRequestFactory();
            var c = factory.CreateClient();
            c.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            var r = await c.PostAsJsonAsync("/api/v1/impact", new { vehicleId = "FH|333333", requestId = Guid.NewGuid() });
            Assert.Equal(HttpStatusCode.NotFound, r.StatusCode);
            Assert.Equal("application/problem+json", r.Content.Headers.ContentType?.MediaType);
            var body = (await r.Content.ReadFromJsonAsync<JsonObject>())!;
            Assert.Equal(404, body["status"]!.GetValue<int>());
            Assert.False(string.IsNullOrEmpty(body["title"]?.GetValue<string>()));
            Assert.Equal("Request was not found.", body["detail"]!.GetValue<string>());
            Assert.False(string.IsNullOrEmpty(body["traceId"]?.GetValue<string>()));
        }

        [Fact]
        public async Task A_missing_vehicle_is_still_a_400_problem()
        {
            using var factory = new TestRequestFactory();
            var c = factory.CreateClient();
            c.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            var r = await c.PostAsJsonAsync("/api/v1/impact", new { });
            Assert.Equal(HttpStatusCode.BadRequest, r.StatusCode);
            Assert.Equal("vehicle_required", (await r.Content.ReadFromJsonAsync<JsonObject>())!["title"]!.GetValue<string>());
        }
    }
}
