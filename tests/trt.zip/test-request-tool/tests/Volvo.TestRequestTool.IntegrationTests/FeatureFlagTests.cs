using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>Feature flags (Microsoft.FeatureManagement): defaults, switching off closes the endpoint, targeting, preview, access, audit.</summary>
    public sealed class FeatureFlagTests
    {
        private static async Task<HttpClient> As(TestRequestFactory factory, string id)
        {
            var c = factory.CreateClient();
            c.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            var r = await c.PostAsJsonAsync("/api/v1/auth/login", TestRequestFactory.Login(id));
            c.DefaultRequestHeaders.Remove("Cookie");
            c.DefaultRequestHeaders.Add("Cookie", r.Headers.GetValues("Set-Cookie").Single(x => x.StartsWith("trt.session=", StringComparison.Ordinal)).Split(';')[0]);
            return c;
        }

        [Fact]
        public async Task Flags_have_their_defaults_and_switching_one_off_closes_its_endpoint()
        {
            using var factory = new TestRequestFactory();
            using var admin = await As(factory, "admin");
            var flags = await admin.GetFromJsonAsync<JsonObject>("/api/v1/features");
            static bool OffByDefault(string k) => k.StartsWith("ai", StringComparison.Ordinal) || k == "require-approval";
            Assert.All(flags!.Where(kv => !OffByDefault(kv.Key)), kv => Assert.True(kv.Value!.GetValue<bool>(), kv.Key));
            Assert.All(flags!.Where(kv => OffByDefault(kv.Key)), kv => Assert.False(kv.Value!.GetValue<bool>(), kv.Key + " (off by default)"));
            Assert.Equal(HttpStatusCode.OK, (await admin.GetAsync("/api/v1/diagnostics/logs?take=1")).StatusCode);
            Assert.Equal(HttpStatusCode.OK, (await admin.PutAsJsonAsync("/api/v1/admin/features/logs-viewer", new { mode = "off" })).StatusCode);
            var off = await admin.GetAsync("/api/v1/diagnostics/logs?take=1");
            Assert.Equal(HttpStatusCode.NotFound, off.StatusCode);
            Assert.Contains("feature_off", await off.Content.ReadAsStringAsync());
            Assert.False((await admin.GetFromJsonAsync<JsonObject>("/api/v1/features"))!["logs-viewer"]!.GetValue<bool>());
            var audit = await admin.GetFromJsonAsync<JsonArray>("/api/v1/admin/audit?take=5");
            Assert.Contains(audit!, e => e!["action"]!.GetValue<string>() == "features.change");
        }

        [Fact]
        public async Task Targeting_by_role_turns_a_feature_on_only_for_that_role_and_preview_agrees()
        {
            using var factory = new TestRequestFactory();
            using var admin = await As(factory, "admin");
            await admin.PutAsJsonAsync("/api/v1/admin/features/service-health", new { mode = "targeted", rollout = 0, groups = new[] { "role:Admin" } });
            using var engineer = await As(factory, "engineer");
            Assert.Equal(HttpStatusCode.OK, (await admin.GetAsync("/api/v1/monitor/services?window=1h")).StatusCode);
            Assert.Equal(HttpStatusCode.NotFound, (await engineer.GetAsync("/api/v1/monitor/services?window=1h")).StatusCode);
            Assert.False((await engineer.GetFromJsonAsync<JsonObject>("/api/v1/features"))!["service-health"]!.GetValue<bool>());
            var preview = await admin.GetFromJsonAsync<JsonArray>("/api/v1/admin/features/service-health/preview");
            Assert.True(preview!.Single(p => p!["id"]!.GetValue<string>() == "admin")!["on"]!.GetValue<bool>());
            Assert.False(preview!.Single(p => p!["id"]!.GetValue<string>() == "engineer")!["on"]!.GetValue<bool>());
            // A named person can be let in; an exclusion wins over a group.
            await admin.PutAsJsonAsync("/api/v1/admin/features/service-health", new { mode = "targeted", rollout = 0, groups = new[] { "role:Admin" }, users = new[] { "engineer" }, exclude = new[] { "admin" } });
            Assert.Equal(HttpStatusCode.OK, (await engineer.GetAsync("/api/v1/monitor/services?window=1h")).StatusCode);
            Assert.Equal(HttpStatusCode.NotFound, (await admin.GetAsync("/api/v1/monitor/services?window=1h")).StatusCode);
        }

        [Fact]
        public async Task Only_administrators_change_flags_and_bad_values_are_refused()
        {
            using var factory = new TestRequestFactory();
            using var engineer = await As(factory, "engineer");
            Assert.Equal(HttpStatusCode.Forbidden, (await engineer.PutAsJsonAsync("/api/v1/admin/features/teams", new { mode = "off" })).StatusCode);
            using var admin = await As(factory, "admin");
            Assert.Equal(HttpStatusCode.BadRequest, (await admin.PutAsJsonAsync("/api/v1/admin/features/teams", new { mode = "sometimes" })).StatusCode);
            Assert.Equal(HttpStatusCode.BadRequest, (await admin.PutAsJsonAsync("/api/v1/admin/features/teams", new { mode = "targeted", rollout = 150 })).StatusCode);
            Assert.Equal(HttpStatusCode.NotFound, (await admin.PutAsJsonAsync("/api/v1/admin/features/no-such-flag", new { mode = "on" })).StatusCode);
        }
    }
}
