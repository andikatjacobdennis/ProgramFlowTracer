using System.Diagnostics;
using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>Batch runs: one request per vehicle in order, the pause after each, per-item results, report, retry of failures only.</summary>
    public sealed class BatchApiTests
    {
        private static readonly object Template = new { softwareRequestOperation = 3, scenario = 1, pblUpdateCapable = true, enableMultiNodeBehavior = true };

        private static async Task<JsonObject> WaitFor(HttpClient c, string id, TimeSpan timeout)
        {
            var sw = Stopwatch.StartNew();
            JsonObject b;
            do
            {
                await Task.Delay(200);
                b = (await c.GetFromJsonAsync<JsonObject>($"/api/v1/batches/{id}"))!;
            }
            while (b["status"]!.GetValue<string>() is "queued" or "running" && sw.Elapsed < timeout);
            return b;
        }

        [Fact]
        public async Task A_batch_runs_each_vehicle_in_turn_with_the_pause_and_retries_only_failures()
        {
            using var factory = new TestRequestFactory();
            using var c = factory.CreateClient();
            var sw = Stopwatch.StartNew();
            var created = await c.PostAsJsonAsync("/api/v1/batches", new { name = "Three plus one missing", vehicleIds = new[] { "FH|123456", "FH|333333", "XX|000000" }, kind = "Software", template = Template, delayMs = 400 });
            Assert.Equal(HttpStatusCode.Accepted, created.StatusCode);
            var id = (await created.Content.ReadFromJsonAsync<JsonObject>())!["id"]!.GetValue<string>();
            var b = await WaitFor(c, id, TimeSpan.FromSeconds(60));
            Assert.Equal("finished", b["status"]!.GetValue<string>());
            Assert.True(sw.Elapsed >= TimeSpan.FromMilliseconds(800), "two pauses of 400 ms between three items");
            var items = b["items"]!.AsArray();
            Assert.Equal(3, items.Count);
            Assert.All(items.Take(2), x => Assert.Contains(x!["status"]!.GetValue<string>(), new[] { "ready", "limited", "blocked" }));
            Assert.Equal("failed", items[2]!["status"]!.GetValue<string>());   // the vehicle does not exist: explained, not fatal
            Assert.Equal(1.0, b["progress"]!.GetValue<double>());
            var firstJobs = items.Take(2).Select(x => x!["jobId"]!.GetValue<string>()).ToArray();

            var csv = await c.GetStringAsync($"/api/v1/batches/{id}/report?format=csv");
            Assert.StartsWith("#,vehicle,status,seconds,issues,attempts", csv);
            Assert.Equal(4, csv.Trim().Split('\n').Length);

            // Retry: only the failed item runs again; the successful items keep their jobs and results.
            Assert.Equal(HttpStatusCode.Accepted, (await c.PostAsync($"/api/v1/batches/{id}/retry-failed", null)).StatusCode);
            b = await WaitFor(c, id, TimeSpan.FromSeconds(30));
            items = b["items"]!.AsArray();
            Assert.Equal(firstJobs, items.Take(2).Select(x => x!["jobId"]!.GetValue<string>()).ToArray());
            Assert.Equal(2, items[2]!["attempts"]!.GetValue<int>());
            Assert.Equal(2, b["round"]!.GetValue<int>());
        }

        [Fact]
        public async Task Batches_are_validated_and_owned()
        {
            using var factory = new TestRequestFactory();
            using var c = factory.CreateClient();
            Assert.Equal(HttpStatusCode.BadRequest, (await c.PostAsJsonAsync("/api/v1/batches", new { vehicleIds = Array.Empty<string>() })).StatusCode);
            Assert.Equal(HttpStatusCode.BadRequest, (await c.PostAsJsonAsync("/api/v1/batches", new { vehicleIds = Enumerable.Range(0, 201).Select(i => "FH|" + i).ToArray() })).StatusCode);
            Assert.Equal(HttpStatusCode.NotFound, (await c.GetAsync($"/api/v1/batches/{Guid.NewGuid()}")).StatusCode);
        }
    }
}
