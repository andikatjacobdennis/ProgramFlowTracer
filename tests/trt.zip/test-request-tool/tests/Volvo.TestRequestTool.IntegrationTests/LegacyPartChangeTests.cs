using System.Net.Http.Json;
using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>A changed legacy part (here the main software of EMS) is a change everywhere: the diff, the computer and its parts.</summary>
    public sealed class LegacyPartChangeTests
    {
        [Fact]
        public async Task A_changed_main_software_marks_the_computer_the_software_group_and_the_part()
        {
            using var factory = new TestRequestFactory();
            var c = factory.CreateClient();
            c.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            var vehicle = (await c.GetFromJsonAsync<JsonObject>("/api/v1/vehicles/FM/654321"))!;
            var product = (vehicle["product"] ?? vehicle["item"] ?? vehicle)!.DeepClone().AsObject();
            var ems = product["nodes"]!.AsArray().OfType<JsonObject>().First(n => n["name"]!.GetValue<string>() == "16.1.1 EMS");
            ems["mainSoftware"]!["number"] = 23199999;
            var r = await c.PostAsJsonAsync("/api/v1/impact", new { vehicleId = "FM|654321", product });
            r.EnsureSuccessStatusCode();
            var impact = (await r.Content.ReadFromJsonAsync<JsonObject>())!;
            Assert.Equal(1, impact["counts"]!["changes"]!.GetValue<int>());
            var row = impact["changes"]![0]!;
            Assert.Equal("EMS Main software", row["component"]!.GetValue<string>());
            Assert.Equal("23100021", row["from"]!.GetValue<string>());
            Assert.Equal("23199999", row["to"]!.GetValue<string>());
            var module = impact["modules"]!.AsArray().OfType<JsonObject>().First(m => m["short"]!.GetValue<string>() == "EMS");
            Assert.Equal("changed", module["status"]!.GetValue<string>());
            var software = module["parts"]!.AsArray().OfType<JsonObject>().First(p => p["name"]!.GetValue<string>() == "Software");
            Assert.Equal("changed", software["status"]!.GetValue<string>());
            Assert.Equal("changed", software["children"]!.AsArray().OfType<JsonObject>().First(p => p["name"]!.GetValue<string>() == "MSW")["status"]!.GetValue<string>());
        }
    }
}
