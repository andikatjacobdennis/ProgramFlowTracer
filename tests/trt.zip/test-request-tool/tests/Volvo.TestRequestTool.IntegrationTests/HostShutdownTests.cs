using System.Reflection;
using Microsoft.Extensions.Caching.Hybrid;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
using Volvo.TestRequestTool.Infrastructure;
using Volvo.TestRequestTool.Web;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>
    /// Stopping the host (for example ending a Visual Studio debugging session) while background work runs is normal: the
    /// warm-up, the batch runner and the service monitor end quietly instead of letting the cancellation escape, which made
    /// the debugger stop on an "unhandled" OperationCanceledException.
    /// </summary>
    public sealed class HostShutdownTests
    {
        private static Task Execute(BackgroundService service, CancellationToken stop) =>
            (Task)typeof(BackgroundService).GetMethod("ExecuteAsync", BindingFlags.NonPublic | BindingFlags.Instance)!.Invoke(service, [stop])!;

        [Fact]
        public async Task The_warm_up_ends_quietly_when_the_host_stops()
        {
            using var factory = new TestRequestFactory();
            var warmup = ActivatorUtilities.CreateInstance<Warmup>(factory.Services);
            using var stop = new CancellationTokenSource();
            stop.Cancel();
            await Execute(warmup, stop.Token);   // must not throw
            Assert.True(warmup.Done);
        }

        [Fact]
        public async Task The_service_monitor_ends_quietly_when_the_host_stops()
        {
            using var factory = new TestRequestFactory();
            var monitor = ActivatorUtilities.CreateInstance<ServiceMonitor>(factory.Services);
            using var stop = new CancellationTokenSource();
            stop.Cancel();
            await Execute(monitor, stop.Token);
        }

        [Fact]
        public async Task The_batch_runner_ends_quietly_when_the_host_stops()
        {
            using var factory = new TestRequestFactory();
            var runner = ActivatorUtilities.CreateInstance<BatchRunner>(factory.Services);
            using var stop = new CancellationTokenSource(TimeSpan.FromMilliseconds(30));
            await Execute(runner, stop.Token).WaitAsync(TimeSpan.FromSeconds(10));
        }

        /// <summary>
        /// The cached fleet summary after the store has shut down: the caller gets a cancellation (not an error from inside
        /// HybridCache, where the debugger stopped), and no half-computed summary is left in the cache.
        /// </summary>
        [Fact]
        public async Task The_cached_fleet_summary_reports_shutdown_as_a_cancellation_and_caches_nothing()
        {
            using var factory = new TestRequestFactory();
            var insights = factory.Services.GetRequiredService<VehicleInsights>();
            var cache = factory.Services.GetRequiredService<HybridCache>();
            var actor = new Actor("shutdown-user", new HashSet<int> { 101, 102, 103, 104 }, true);
            ((WorkspaceRepository)factory.Services.GetRequiredService<IWorkspaceStore>()).Dispose();
            var e = await Record.ExceptionAsync(() => insights.FleetAsync(actor, false, default));
            Assert.IsAssignableFrom<OperationCanceledException>(e);
            var cached = await cache.GetOrCreateAsync("fleet:shutdown-user:101,102,103,104", _ => ValueTask.FromResult(new System.Text.Json.Nodes.JsonObject { ["fresh"] = true }));
            Assert.True(cached["fresh"]?.GetValue<bool>(), "the incomplete result was not kept in the cache");
        }

        [Fact]
        public async Task A_caller_that_leaves_does_not_leave_an_incomplete_summary_for_the_next()
        {
            using var factory = new TestRequestFactory();
            var insights = factory.Services.GetRequiredService<VehicleInsights>();
            var actor = new Actor("leaving-user", new HashSet<int> { 101, 102, 103, 104 }, true);
            using var gone = new CancellationTokenSource();
            gone.Cancel();
            await Assert.ThrowsAnyAsync<OperationCanceledException>(() => insights.FleetAsync(actor, false, gone.Token));
            var next = await insights.FleetAsync(actor, false, default);
            Assert.Null(next["$incomplete"]);
            Assert.NotNull(next["rows"]);
        }
    }
}
