using System.Net;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>
    /// Page delivery (StartupPerformance.cs): in Development, HTML pages are sent uncompressed so Visual Studio's Hot Reload
    /// can inject its script (a compressed page left a blank screen); scripts and styles stay compressed. Other environments are
    /// unchanged.
    /// </summary>
    public sealed class PageDeliveryTests
    {
        private static HttpRequestMessage Get(string path, string accept)
        {
            var m = new HttpRequestMessage(HttpMethod.Get, path);
            m.Headers.TryAddWithoutValidation("Accept", accept);
            m.Headers.TryAddWithoutValidation("Accept-Encoding", "br, gzip");
            return m;
        }

        private const string Page = "text/html,application/xhtml+xml,*/*;q=0.8";

        [Theory]
        [InlineData("/")]
        [InlineData("/index.html")]
        public async Task In_development_pages_are_sent_uncompressed(string path)
        {
            using var factory = new TestRequestFactory { Environment = "Development" };
            using var client = factory.CreateClient();
            var r = await client.SendAsync(Get(path, Page));
            Assert.Equal(HttpStatusCode.OK, r.StatusCode);
            Assert.Empty(r.Content.Headers.ContentEncoding);
            Assert.Contains("<html", await r.Content.ReadAsStringAsync(), StringComparison.OrdinalIgnoreCase);
        }

        [Fact]
        public async Task In_development_scripts_stay_compressed()
        {
            using var factory = new TestRequestFactory { Environment = "Development" };
            using var client = factory.CreateClient();
            var r = await client.SendAsync(Get("/js/shell.js", "*/*"));
            Assert.Equal(HttpStatusCode.OK, r.StatusCode);
            Assert.NotEmpty(r.Content.Headers.ContentEncoding);
        }

        [Theory]
        [InlineData("/", "*/*", true)]
        [InlineData("/index.html", "*/*", true)]
        [InlineData("/guide/", "*/*", true)]
        [InlineData("/requests", Page, true)]
        [InlineData("/js/shell.js", "*/*", false)]
        [InlineData("/css/app-shell.css", "text/css,*/*;q=0.1", false)]
        [InlineData("/api/v1/requests", Page, false)]
        public void Page_requests_are_recognised(string path, string accept, bool page)
        {
            var ctx = new Microsoft.AspNetCore.Http.DefaultHttpContext();
            ctx.Request.Path = path;
            ctx.Request.Headers.Accept = accept;
            Assert.Equal(page, Volvo.TestRequestTool.Web.StartupPerformance.IsPageRequest(ctx.Request));
        }
    }
}
