using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>Campaigns: create, validate as a batch, approve the exact revision (separation of duties), edits clear the
    /// approval, submit commits the approved vehicles once.</summary>
    public sealed class CampaignApiTests
    {
        private static async Task<HttpClient> As(TestRequestFactory factory, string id)
        {
            var c = factory.CreateClient();
            c.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            var r = await c.PostAsJsonAsync("/api/v1/auth/login", TestRequestFactory.Login(id));
            c.DefaultRequestHeaders.Remove("Cookie");
            c.DefaultRequestHeaders.Add("Cookie", r.Headers.GetValues("Set-Cookie").Single(x => x.StartsWith("trt.session=", StringComparison.Ordinal)).Split(';')[0]);
            return c;
        }

        private static async Task<JsonObject> Json(HttpResponseMessage r, HttpStatusCode expected = HttpStatusCode.OK)
        {
            var text = await r.Content.ReadAsStringAsync();
            Assert.True(r.StatusCode == expected, $"{(int)r.StatusCode}: {text}");
            return JsonNode.Parse(text)!.AsObject();
        }

        /// <summary>Waits until no vehicle of the campaign is still waiting or running (the batch runner works in the background).</summary>
        private static async Task<JsonObject> Settled(HttpClient c, string id)
        {
            for (var i = 0; i < 80; i++)
            {
                var x = await c.GetFromJsonAsync<JsonObject>($"/api/v1/campaigns/{id}");
                if (x!["vehicles"]!.AsArray().All(v => v!["validation"]!.GetValue<string>() != "running"))
                {
                    return x;
                }

                await Task.Delay(250);
            }
            throw new TimeoutException("The campaign validation did not finish.");
        }

        [Fact]
        public async Task A_campaign_is_validated_approved_for_its_exact_revision_and_submitted_once()
        {
            using var factory = new TestRequestFactory();
            using var engineer = await As(factory, "engineer");
            using var reviewer = await As(factory, "reviewer");
            Assert.Empty((await engineer.GetFromJsonAsync<JsonArray>("/api/v1/campaigns"))!);   // a new repository has no campaigns
            var created = await Json(await engineer.PostAsJsonAsync("/api/v1/campaigns", new { name = "Gateway compatibility update", vehicleIds = new[] { "FH|333333", "FH|123456" }, kind = "Software", template = new { softwareRequestOperation = 3, scenario = 1, pblUpdateCapable = true, enableMultiNodeBehavior = true } }), HttpStatusCode.Created);
            var id = created["id"]!.GetValue<string>();
            Assert.Equal("draft", created["status"]!.GetValue<string>());
            Assert.All(created["vehicles"]!.AsArray(), v => Assert.Equal("unknown", v!["validation"]!.GetValue<string>()));
            Assert.Equal(HttpStatusCode.Conflict, (await reviewer.PostAsJsonAsync($"/api/v1/campaigns/{id}/decision", new { decision = "approve", version = created["version"]!.GetValue<long>() })).StatusCode);   // nothing validated yet

            var validating = await Json(await engineer.PostAsJsonAsync($"/api/v1/campaigns/{id}/validate", new { version = created["version"]!.GetValue<long>() }));
            Assert.Equal("active", validating["status"]!.GetValue<string>());
            var settled = await Settled(engineer, id);
            Assert.Contains(settled["vehicles"]!.AsArray(), v => v!["validation"]!.GetValue<string>() == "ready");
            var version = settled["version"]!.GetValue<long>();
            // The owner (an Engineer, and the owner) cannot approve; the reviewer can.
            Assert.Equal(HttpStatusCode.Forbidden, (await engineer.PostAsJsonAsync($"/api/v1/campaigns/{id}/decision", new { decision = "approve", version })).StatusCode);
            var approved = await Json(await reviewer.PostAsJsonAsync($"/api/v1/campaigns/{id}/decision", new { decision = "approve", note = "Pilot looks right.", version }));
            Assert.Equal("approved", approved["status"]!.GetValue<string>());
            Assert.True(approved["approval"]!["current"]!.GetValue<bool>());

            // An edit is a new revision: the approval no longer applies and submission is refused.
            var edited = await Json(await engineer.PutAsJsonAsync($"/api/v1/campaigns/{id}", new { description = "Now with release notes.", version = approved["version"]!.GetValue<long>() }));
            Assert.Equal(2, edited["revision"]!.GetValue<int>());
            Assert.Null(edited["approval"]);
            Assert.Equal(HttpStatusCode.Conflict, (await reviewer.PostAsJsonAsync($"/api/v1/campaigns/{id}/submit", new { confirmed = true })).StatusCode);
            Assert.All(edited["vehicles"]!.AsArray(), v => Assert.Equal("unknown", v!["validation"]!.GetValue<string>()));   // revision 2 is not validated yet

            await Json(await engineer.PostAsJsonAsync($"/api/v1/campaigns/{id}/validate", new { version = edited["version"]!.GetValue<long>() }));
            settled = await Settled(engineer, id);
            var ready = settled["vehicles"]!.AsArray().Where(v => v!["validation"]!.GetValue<string>() == "ready").Select(v => v!["id"]!.GetValue<string>()).ToArray();
            approved = await Json(await reviewer.PostAsJsonAsync($"/api/v1/campaigns/{id}/decision", new { decision = "approve", version = settled["version"]!.GetValue<long>() }));
            Assert.Equal(HttpStatusCode.Forbidden, (await engineer.PostAsJsonAsync($"/api/v1/campaigns/{id}/submit", new { confirmed = true })).StatusCode);
            Assert.Equal(HttpStatusCode.BadRequest, (await reviewer.PostAsJsonAsync($"/api/v1/campaigns/{id}/submit", new { confirmed = false })).StatusCode);
            var before = (await reviewer.GetFromJsonAsync<JsonObject>("/api/v1/vehicles/FH/333333"))!["revision"]!.GetValue<long>();
            var submitted = await Json(await reviewer.PostAsJsonAsync($"/api/v1/campaigns/{id}/submit", new { confirmed = true }));
            Assert.Equal("submitted", submitted["status"]!.GetValue<string>());
            var results = submitted["submission"]!["vehicles"]!.AsArray();
            Assert.Equal(ready.Length, results.Count(r => r!["outcome"]!.GetValue<string>() == "committed"));
            if (ready.Contains("FH|333333"))
            {
                Assert.Equal(before + 1, (await reviewer.GetFromJsonAsync<JsonObject>("/api/v1/vehicles/FH/333333"))!["revision"]!.GetValue<long>());
            }

            var again = await Json(await reviewer.PostAsJsonAsync($"/api/v1/campaigns/{id}/submit", new { confirmed = true }));
            Assert.Equal(submitted["submission"]!["id"]!.GetValue<string>(), again["submission"]!["id"]!.GetValue<string>());   // the same result; nothing committed twice
            Assert.Contains(again["events"]!.AsArray(), e => e!["text"]!.GetValue<string>().StartsWith("Submitted as", StringComparison.Ordinal));
        }

        [Fact]
        public async Task Campaigns_refuse_unreadable_vehicles_and_unknown_kinds()
        {
            using var factory = new TestRequestFactory();
            using var engineer = await As(factory, "engineer");
            Assert.Equal(HttpStatusCode.BadRequest, (await engineer.PostAsJsonAsync("/api/v1/campaigns", new { name = "x", vehicleIds = Array.Empty<string>() })).StatusCode);
            Assert.Equal(HttpStatusCode.NotFound, (await engineer.PostAsJsonAsync("/api/v1/campaigns", new { name = "x", vehicleIds = new[] { "ZZ|1" } })).StatusCode);
            Assert.Equal(HttpStatusCode.BadRequest, (await engineer.PostAsJsonAsync("/api/v1/campaigns", new { name = "x", vehicleIds = new[] { "FH|333333" }, kind = "Teleport" })).StatusCode);
            Assert.Equal(HttpStatusCode.BadRequest, (await engineer.PostAsJsonAsync("/api/v1/campaigns", new { name = " ", vehicleIds = new[] { "FH|333333" } })).StatusCode);
        }
    }
}
