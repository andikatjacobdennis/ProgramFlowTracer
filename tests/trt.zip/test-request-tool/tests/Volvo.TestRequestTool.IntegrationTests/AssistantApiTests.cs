using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>
    /// The AI-ready API with the simulated provider: off by default (every endpoint 404), each capability behind its own flag,
    /// scripted chat with honest limits, summaries from authorised records with source versions (staleness), plan previews
    /// that execute nothing, isolation between users, missing context, streaming, and no message content in the audit log.
    /// </summary>
    public sealed class AssistantApiTests
    {
        private static async Task<HttpClient> As(TestRequestFactory factory, string id)
        {
            var c = factory.CreateClient();
            c.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            var r = await c.PostAsJsonAsync("/api/v1/auth/login", TestRequestFactory.Login(id));
            c.DefaultRequestHeaders.Remove("Cookie");
            c.DefaultRequestHeaders.Add("Cookie", r.Headers.GetValues("Set-Cookie").Single(x => x.StartsWith("trt.session=", StringComparison.Ordinal)).Split(';')[0]);
            return c;
        }

        private static async Task Enable(HttpClient admin, params string[] flags)
        {
            foreach (var f in flags)
            {
                Assert.Equal(HttpStatusCode.OK, (await admin.PutAsJsonAsync($"/api/v1/admin/features/{f}", new { mode = "on" })).StatusCode);
            }
        }

        private static object Ask(string q, params object[] include) => new { messages = new[] { new { role = "user", text = q } }, include };

        private static async Task<string> Validate(HttpClient c)
        {
            var v = await c.GetFromJsonAsync<JsonObject>("/api/v1/vehicles/FH/123456");
            var r = await c.PostAsJsonAsync("/api/v1/requests", new { kind = "Software", payload = new { products = new[] { v!["product"] }, softwareRequestOperation = 3, scenario = 1, pblUpdateCapable = true, enableMultiNodeBehavior = true } });
            Assert.Equal(HttpStatusCode.Created, r.StatusCode);
            return (await r.Content.ReadFromJsonAsync<JsonObject>())!["id"]!.GetValue<string>();
        }

        [Fact]
        public async Task Everything_is_off_by_default_and_each_capability_needs_its_own_flag()
        {
            using var factory = new TestRequestFactory();
            using var admin = await As(factory, "admin");
            foreach (var (method, path, body) in new (string, string, object?)[] { ("GET", "/api/v1/assistant/info", null), ("POST", "/api/v1/assistant/chat", Ask("hi")), ("POST", "/api/v1/assistant/summary", new { kind = "activity", id = "mine" }), ("POST", "/api/v1/assistant/agent/plan", new { goal = "validate" }), ("POST", "/api/v1/assistant/context", new { include = Array.Empty<object>() }) })
            {
                var r = await admin.SendAsync(new HttpRequestMessage(new HttpMethod(method), path) { Content = body is null ? null : JsonContent.Create(body) });
                Assert.Equal(HttpStatusCode.NotFound, r.StatusCode);
                Assert.Contains("feature_off", await r.Content.ReadAsStringAsync());
            }
            // A capability flag alone is not enough: the overall AI switch must be on too.
            await Enable(admin, "ai-chat");
            Assert.Equal(HttpStatusCode.NotFound, (await admin.PostAsJsonAsync("/api/v1/assistant/chat", Ask("hi"))).StatusCode);
            await Enable(admin, "ai");
            Assert.Equal(HttpStatusCode.OK, (await admin.PostAsJsonAsync("/api/v1/assistant/chat", Ask("What are the steps?"))).StatusCode);
            Assert.Equal(HttpStatusCode.NotFound, (await admin.PostAsJsonAsync("/api/v1/assistant/summary", new { kind = "activity", id = "mine" })).StatusCode);   // summaries still off
            Assert.Equal(HttpStatusCode.NotFound, (await admin.PostAsJsonAsync("/api/v1/assistant/agent/plan", new { goal = "validate" })).StatusCode);         // agent still off
        }

        [Fact]
        public async Task Simulated_chat_answers_from_scripts_and_records_and_admits_its_limits()
        {
            using var factory = new TestRequestFactory();
            using var admin = await As(factory, "admin");
            await Enable(admin, "ai", "ai-chat");
            var info = await admin.GetFromJsonAsync<JsonObject>("/api/v1/assistant/info");
            Assert.True(info!["simulated"]!.GetValue<bool>());
            Assert.Equal("Simulated assistant — no AI service connected", info["label"]!.GetValue<string>());
            var term = await (await admin.PostAsJsonAsync("/api/v1/assistant/chat", Ask("What is an NTP?"))).Content.ReadFromJsonAsync<JsonObject>();
            Assert.StartsWith("NTP is", term!["text"]!.GetValue<string>());
            Assert.Equal("confirmed", term["confidence"]!.GetValue<string>());
            var vehicle = await (await admin.PostAsJsonAsync("/api/v1/assistant/chat", Ask("Describe this vehicle", new { kind = "vehicle", id = "FH|123456" }))).Content.ReadFromJsonAsync<JsonObject>();
            Assert.Contains("FH 123456", vehicle!["text"]!.GetValue<string>());
            Assert.Contains(vehicle["citations"]!.AsArray(), x => x!["kind"]!.GetValue<string>() == "record");
            var unknown = await (await admin.PostAsJsonAsync("/api/v1/assistant/chat", Ask("Write me a poem about the weather"))).Content.ReadFromJsonAsync<JsonObject>();
            Assert.Equal("unknown", unknown!["confidence"]!.GetValue<string>());
            Assert.Contains("simulated assistant", unknown["text"]!.GetValue<string>());
            Assert.Equal(HttpStatusCode.BadRequest, (await admin.PostAsJsonAsync("/api/v1/assistant/chat", Ask("   "))).StatusCode);
            // Streaming: pieces of text, then the full reply.
            var stream = await admin.PostAsJsonAsync("/api/v1/assistant/chat/stream", Ask("How do I submit?"));
            Assert.Equal("text/event-stream", stream.Content.Headers.ContentType!.MediaType);
            var sse = await stream.Content.ReadAsStringAsync();
            Assert.Contains("\"text\":", sse);
            Assert.Contains("\"done\":", sse);
        }

        [Fact]
        public async Task Summaries_come_from_authorised_records_with_their_version_and_users_are_isolated()
        {
            using var factory = new TestRequestFactory();
            using var admin = await As(factory, "admin");
            await Enable(admin, "ai", "ai-summaries", "ai-chat");
            using var engineer = await As(factory, "engineer");
            var requestId = await Validate(engineer);
            var summary = await (await engineer.PostAsJsonAsync("/api/v1/assistant/summary", new { kind = "request", id = requestId })).Content.ReadFromJsonAsync<JsonObject>();
            Assert.True(summary!["simulated"]!.GetValue<bool>());
            Assert.EndsWith("(simulated)", summary["title"]!.GetValue<string>());
            Assert.Equal(requestId.Replace("-", "")[..12], summary["sourceVersion"]!.GetValue<string>());
            var sections = summary["statements"]!.AsArray().Select(s => s!["section"]!.GetValue<string>()).ToHashSet();
            Assert.Superset(new HashSet<string> { "identity", "findings", "limitations", "next" }, sections);
            Assert.Contains("FH 123456", summary["statements"]![0]!["text"]!.GetValue<string>());
            // Another user cannot summarise or chat about the engineer's request.
            Assert.Equal(HttpStatusCode.NotFound, (await admin.PostAsJsonAsync("/api/v1/assistant/summary", new { kind = "request", id = requestId })).StatusCode);
            var ctx = await (await admin.PostAsJsonAsync("/api/v1/assistant/context", new { include = new[] { new { kind = "request", id = requestId } } })).Content.ReadFromJsonAsync<JsonObject>();
            Assert.Empty(ctx!["items"]!.AsArray());
            Assert.Contains("not available", ctx["unavailable"]![0]!.GetValue<string>());
            // Missing context: nothing to summarise.
            Assert.Equal(HttpStatusCode.NotFound, (await admin.PostAsJsonAsync("/api/v1/assistant/summary", new { kind = "proposal", id = "workspace" })).StatusCode);
        }

        [Fact]
        public async Task A_summary_names_the_revision_so_a_newer_revision_makes_it_outdated()
        {
            using var factory = new TestRequestFactory();
            using var admin = await As(factory, "admin");
            await Enable(admin, "ai", "ai-summaries");
            using var engineer = await As(factory, "engineer");
            await engineer.PostAsJsonAsync("/api/v1/proposals/workspace/revisions", new { state = new { v = 1 }, baseRevision = 0, summary = new { changes = 1, vehicle = "FH 123456" } });
            var first = await (await engineer.PostAsJsonAsync("/api/v1/assistant/summary", new { kind = "proposal", id = "workspace" })).Content.ReadFromJsonAsync<JsonObject>();
            Assert.Equal("rev-1", first!["sourceVersion"]!.GetValue<string>());
            await engineer.PostAsJsonAsync("/api/v1/proposals/workspace/revisions", new { state = new { v = 2 }, baseRevision = 1, summary = new { changes = 2, vehicle = "FH 123456" } });
            var now = await (await engineer.PostAsJsonAsync("/api/v1/assistant/context", new { include = new[] { new { kind = "proposal", id = "workspace" } } })).Content.ReadFromJsonAsync<JsonObject>();
            Assert.NotEqual(first["sourceVersion"]!.GetValue<string>(), now!["items"]![0]!["version"]!.GetValue<string>());   // the interface marks the first summary outdated
        }

        [Fact]
        public async Task Agent_plans_are_previews_that_execute_nothing_and_respect_permissions()
        {
            using var factory = new TestRequestFactory();
            using var admin = await As(factory, "admin");
            await Enable(admin, "ai", "ai-agent");
            using var viewer = await As(factory, "viewer");
            var plan = await (await viewer.PostAsJsonAsync("/api/v1/assistant/agent/plan", new { goal = "Update FH 123456 to the latest service pack", include = new[] { new { kind = "vehicle", id = "FH|123456" } } })).Content.ReadFromJsonAsync<JsonObject>();
            Assert.True(plan!["preview"]!.GetValue<bool>());
            Assert.All(plan["actions"]!.AsArray(), a => Assert.False(a!["executes"]!.GetValue<bool>()));
            Assert.Contains(plan["requires"]!.AsArray(), r => r!["kind"]!.GetValue<string>() == "permission" && !r["satisfied"]!.GetValue<bool>());   // a Viewer cannot validate
            var versionBefore = (await viewer.GetFromJsonAsync<JsonObject>("/api/v1/vehicles/FH/123456"))!["revision"]!.GetValue<int>();
            Assert.Equal(versionBefore, (await viewer.GetFromJsonAsync<JsonObject>("/api/v1/vehicles/FH/123456"))!["revision"]!.GetValue<int>());   // nothing changed
            // The audit log records the use, never the goal or message text.
            var audit = (await admin.GetFromJsonAsync<JsonArray>("/api/v1/admin/audit?take=50"))!.ToJsonString();
            Assert.Contains("assistant.agent.plan", audit);
            Assert.DoesNotContain("latest service pack", audit);
        }
    }
}
