using System.Net;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging.Abstractions;
using Volvo.TestRequestTool.Web;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>
    /// Profile photos: the API with photos kept in the repository, and the Microsoft Graph source against a fake Graph and token endpoint
    /// (photo found, no photo, permission denied, network failure, token caching, no token in any URL).
    /// </summary>
    public sealed class ProfilePhotoTests
    {
        // ---------------------------------------------------------------- the API (photos kept with the repository)
        private const string Svg = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"96\" height=\"96\"><circle cx=\"48\" cy=\"48\" r=\"40\" fill=\"#0f6cbd\"/></svg>";

        private static void PutPhoto(TestRequestFactory factory, string id)
        {
            var folder = Path.Combine(factory.Directory, "repo", "user-photos");
            Directory.CreateDirectory(folder);
            File.WriteAllText(Path.Combine(folder, id + ".svg"), Svg);
        }

        [Fact]
        public async Task A_person_with_a_photo_file_gets_it_privately_cached()
        {
            using var factory = new TestRequestFactory();
            PutPhoto(factory, "tester");
            using var c = factory.CreateClient();
            var r = await c.GetAsync("/api/v1/me/photo?size=70");
            Assert.Equal(HttpStatusCode.OK, r.StatusCode);
            Assert.Equal("image/svg+xml", r.Content.Headers.ContentType!.MediaType);
            Assert.Contains("private", r.Headers.CacheControl!.ToString());
            Assert.Contains("Cookie", r.Headers.Vary);
            Assert.Contains("<circle", await r.Content.ReadAsStringAsync());
            Assert.NotNull(r.Headers.ETag);
        }

        [Fact]
        public async Task People_without_a_photo_get_no_content_and_signing_out_ends_the_session()
        {
            using var factory = new TestRequestFactory();
            PutPhoto(factory, "reviewer");
            using var c = factory.CreateClient();
            await TestRequestFactory.SignInAsync(c, "admin");
            Assert.Equal(HttpStatusCode.OK, (await c.GetAsync("/api/v1/admin/users/reviewer/photo?size=48")).StatusCode);   // the user list shows each photo
            Assert.Equal(HttpStatusCode.NoContent, (await c.GetAsync("/api/v1/admin/users/no-photo/photo")).StatusCode);
            await TestRequestFactory.SignInAsync(c, "no-photo");
            var none = await c.GetAsync("/api/v1/me/photo?size=96");
            Assert.Equal(HttpStatusCode.NoContent, none.StatusCode);   // no photo is not an error: nothing is logged as failed
            Assert.Empty(await none.Content.ReadAsByteArrayAsync());
            var signout = await c.PostAsync("/api/v1/auth/logout", null);
            Assert.Equal(HttpStatusCode.NoContent, signout.StatusCode);
            Assert.Contains(signout.Headers.GetValues("Set-Cookie"), v => v.StartsWith("trt.session=;", StringComparison.Ordinal));   // the session cookie is removed
            Assert.Equal(HttpStatusCode.Unauthorized, (await c.GetAsync("/api/v1/me/photo")).StatusCode);
        }

        // ---------------------------------------------------------------- the Graph source
        private sealed class FakeHandler : HttpMessageHandler
        {
            private readonly Func<HttpRequestMessage, HttpResponseMessage> _answer;
            public readonly List<HttpRequestMessage> Requests = [];
            public readonly List<string> Bodies = [];

            public FakeHandler(Func<HttpRequestMessage, HttpResponseMessage> answer)
            {
                _answer = answer;
            }

            protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken ct)
            {
                Requests.Add(request);
                Bodies.Add(request.Content is null ? "" : await request.Content.ReadAsStringAsync(ct));
                return _answer(request);
            }
        }

        private sealed class Factory : IHttpClientFactory
        {
            private readonly HttpMessageHandler _handler;

            public Factory(HttpMessageHandler handler)
            {
                _handler = handler;
            }

            public HttpClient CreateClient(string name) => new(_handler, false);
        }

        private static (GraphPhotoSource Source, FakeHandler Handler) Graph(HttpStatusCode photo, bool failNetwork = false)
        {
            var handler = new FakeHandler(req =>
            {
                if (failNetwork && req.RequestUri!.Host == "graph.microsoft.com")
                {
                    throw new HttpRequestException("no route");
                }

                if (req.RequestUri!.AbsolutePath.EndsWith("/oauth2/v2.0/token", StringComparison.Ordinal))
                {
                    return new(HttpStatusCode.OK) { Content = new StringContent("{\"access_token\":\"graph-secret-token\",\"expires_in\":3600}", Encoding.UTF8, "application/json") };
                }

                return photo == HttpStatusCode.OK ? new(HttpStatusCode.OK) { Content = new ByteArrayContent([1, 2, 3]) { Headers = { ContentType = new("image/jpeg") } } } : new(photo);
            });
            var config = new ConfigurationBuilder().AddInMemoryCollection(new Dictionary<string, string?> { ["AzureAd:TenantId"] = "tenant-1", ["AzureAd:ClientId"] = "client-1", ["AzureAd:ClientSecret"] = "s3cret" }).Build();
            return (new GraphPhotoSource(new Factory(handler), config, TimeProvider.System, NullLogger<GraphPhotoSource>.Instance), handler);
        }

        private static HttpContext Caller(string user = "u-1", string? bearer = "incoming-user-token")
        {
            var ctx = new DefaultHttpContext { User = new ClaimsPrincipal(new ClaimsIdentity([new Claim(ClaimTypes.NameIdentifier, user), new Claim(ClaimTypes.Name, "Meera Pillai")], "Test")) };
            if (bearer is not null)
            {
                ctx.Request.Headers.Authorization = "Bearer " + bearer;
            }

            return ctx;
        }

        [Fact]
        public async Task Graph_photo_is_read_on_behalf_of_the_user_with_User_Read_only()
        {
            var (source, handler) = Graph(HttpStatusCode.OK);
            var result = await source.GetAsync(Caller(), 96, CancellationToken.None);
            Assert.Equal("ok", result.Status);
            Assert.Equal([1, 2, 3], result.Bytes);
            var token = handler.Bodies[0];
            Assert.Contains("grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer", token);
            Assert.Contains("requested_token_use=on_behalf_of", token);
            Assert.Contains("scope=https%3A%2F%2Fgraph.microsoft.com%2FUser.Read", token);
            var graph = handler.Requests[1];
            Assert.Equal("/v1.0/me/photos/96x96/$value", graph.RequestUri!.AbsolutePath);
            Assert.Equal("graph-secret-token", graph.Headers.Authorization!.Parameter);
            Assert.DoesNotContain(handler.Requests, r => r.RequestUri!.ToString().Contains("token", StringComparison.OrdinalIgnoreCase) && r.RequestUri.Host == "graph.microsoft.com");   // never in a URL
            // The Graph token is reused for the same user, not requested again.
            await source.GetAsync(Caller(), 48, CancellationToken.None);
            Assert.Equal(1, handler.Requests.Count(r => r.RequestUri!.AbsolutePath.EndsWith("/token", StringComparison.Ordinal)));
        }

        [Theory]
        [InlineData(HttpStatusCode.NotFound, "none")]
        [InlineData(HttpStatusCode.Forbidden, "forbidden")]
        [InlineData(HttpStatusCode.Unauthorized, "forbidden")]
        [InlineData(HttpStatusCode.ServiceUnavailable, "unavailable")]
        public async Task Graph_answers_map_to_fallback_states(HttpStatusCode answer, string status)
        {
            var (source, _) = Graph(answer);
            Assert.Equal(status, (await source.GetAsync(Caller(), 96, CancellationToken.None)).Status);
        }

        [Fact]
        public async Task Network_failure_and_missing_delegated_token_fall_back()
        {
            var (source, _) = Graph(HttpStatusCode.OK, failNetwork: true);
            Assert.Equal("unavailable", (await source.GetAsync(Caller(), 96, CancellationToken.None)).Status);
            var (cookieOnly, handler) = Graph(HttpStatusCode.OK);
            Assert.Equal("forbidden", (await cookieOnly.GetAsync(Caller(bearer: null), 96, CancellationToken.None)).Status);
            Assert.Empty(handler.Requests);   // nothing is sent without a delegated identity
        }

        [Theory]
        [InlineData(1, 48)]
        [InlineData(32, 48)]
        [InlineData(70, 96)]
        [InlineData(96, 96)]
        [InlineData(5000, 648)]
        public void Sizes_snap_up_to_Graph_sizes(int asked, int expected) => Assert.Equal(expected, ProfilePhotoEndpoints.Snap(asked));
    }
}
