using System.Net.Http.Json;
using System.Text.Json.Nodes;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>
    /// The topology levels below each computer (POST /api/v1/impact, module.parts), straight from the product schema:
    /// legacy computers have Hardware, Software and Data sets (with patches); T3 computers have logical ECUs, execution
    /// environments and software products. Each part is compared with the stored vehicle.
    /// </summary>
    public sealed class TopologyTests
    {
        private static async Task<JsonObject> Impact(object body)
        {
            using var factory = new TestRequestFactory();
            var c = factory.CreateClient();
            c.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            var r = await c.PostAsJsonAsync("/api/v1/impact", body);
            r.EnsureSuccessStatusCode();
            return (await r.Content.ReadFromJsonAsync<JsonObject>())!;
        }

        private static JsonObject Module(JsonObject impact, string shortName) => impact["modules"]!.AsArray().OfType<JsonObject>().First(m => m["short"]!.GetValue<string>() == shortName);
        private static string[] Names(JsonNode? list) => list!.AsArray().OfType<JsonObject>().Select(x => x["name"]!.GetValue<string>()).ToArray();

        [Fact]
        public async Task A_legacy_computer_has_hardware_software_and_data_sets_with_patches()
        {
            var impact = await Impact(new { vehicleId = "FM|654321" });
            var ems = Module(impact, "EMS");
            Assert.False(ems["cab"]!.GetValue<bool>());
            Assert.Equal(["Hardware", "Software", "Data sets"], Names(ems["parts"]));
            var software = ems["parts"]![1]!;
            Assert.Contains("MSW", Names(software["children"]));
            Assert.Equal("unchanged", software["status"]!.GetValue<string>());
            var data = ems["parts"]![2]!["children"]!.AsArray().OfType<JsonObject>().First(d => d["children"] is JsonArray);
            Assert.Equal("patch", data["children"]![0]!["kind"]!.GetValue<string>());
            var ic = Module(impact, "IC");
            Assert.True(ic["cab"]!.GetValue<bool>(), "the instrument cluster is a cab computer");
            Assert.Contains("Display unit", Names(ic["parts"]![0]!["children"]));
        }

        [Fact]
        public async Task A_T3_computer_has_logical_ECUs_execution_environments_and_software_products()
        {
            var impact = await Impact(new { vehicleId = "FH|333333" });
            var vcm = Module(impact, "VCM");
            var lecu = vcm["parts"]![0]!;
            Assert.Equal("logical-ecu", lecu["kind"]!.GetValue<string>());
            Assert.Equal("VCM-LECU", lecu["name"]!.GetValue<string>());
            var env = lecu["children"]![0]!;
            Assert.Equal("environment", env["kind"]!.GetValue<string>());
            Assert.Equal(["Platform", "Application"], Names(env["children"]));
        }
    }
}
