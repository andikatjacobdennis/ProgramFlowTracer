using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
using Microsoft.Extensions.DependencyInjection;
namespace Volvo.TestRequestTool.IntegrationTests
{
    public sealed class UserRoleTests
    {
        private static async Task Switch(HttpClient client, string id)
        {
            client.DefaultRequestHeaders.Remove("X-Studio-Request");
            client.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            var response = await client.PostAsJsonAsync("/api/v1/auth/login", TestRequestFactory.Login(id));
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            var cookie = response.Headers.GetValues("Set-Cookie").Single(x => x.StartsWith("trt.session="));
            client.DefaultRequestHeaders.Remove("Cookie");
            client.DefaultRequestHeaders.Add("Cookie", cookie.Split(';')[0]);
        }

        [Fact]
        public async Task Viewer_cannot_simulate_save_drafts_or_manage_users()
        {
            using var factory = new TestRequestFactory();
            using var c = factory.CreateClient();
            await Switch(c, "viewer");
            Assert.Equal(HttpStatusCode.Forbidden, (await c.PostAsJsonAsync("/api/v1/requests", new { kind = "Software", payload = new { } })).StatusCode);
            Assert.Equal(HttpStatusCode.Forbidden, (await c.PutAsJsonAsync("/api/v1/drafts/current", new { state = new { tab = "map" }, expectedVersion = (long?)null })).StatusCode);
            Assert.Equal(HttpStatusCode.Forbidden, (await c.GetAsync("/api/v1/admin/users")).StatusCode);
        }

        [Fact]
        public async Task Engineer_can_edit_but_not_commit()
        {
            using var factory = new TestRequestFactory();
            using var c = factory.CreateClient();
            await Switch(c, "engineer");
            var s = (await c.GetFromJsonAsync<JsonObject>("/api/v1/session"))!;
            Assert.True(s["canEdit"]!.GetValue<bool>());
            Assert.False(s["canWrite"]!.GetValue<bool>());
            Assert.Equal(HttpStatusCode.Forbidden, (await c.PostAsJsonAsync("/api/v1/vda/commit", new { requestId = Guid.NewGuid(), vehicleId = "FH|333333", expectedRevision = 1 })).StatusCode);
        }

        [Fact]
        public async Task Reviewer_can_write_but_cannot_edit_drafts()
        {
            using var factory = new TestRequestFactory();
            using var c = factory.CreateClient();
            await Switch(c, "reviewer");
            var s = (await c.GetFromJsonAsync<JsonObject>("/api/v1/session"))!;
            Assert.False(s["canEdit"]!.GetValue<bool>());
            Assert.True(s["canWrite"]!.GetValue<bool>());
            Assert.Equal(HttpStatusCode.Forbidden, (await c.PutAsJsonAsync("/api/v1/drafts/current", new { state = new { tab = "map" }, expectedVersion = (long?)null })).StatusCode);
        }

        [Fact]
        public async Task Admin_can_create_user_and_cannot_disable_self()
        {
            using var factory = new TestRequestFactory();
            using var c = factory.CreateClient();
            await Switch(c, "admin");
            var response = await c.PutAsJsonAsync("/api/v1/admin/users/new-viewer", new { id = "new-viewer", displayName = "New viewer", role = "Viewer", contexts = new[] { 104 }, enabled = true });
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            Assert.Equal(HttpStatusCode.Conflict, (await c.PutAsJsonAsync("/api/v1/admin/users/admin", new { id = "admin", displayName = "Alex", role = "Viewer", contexts = new[] { 104 }, enabled = false })).StatusCode);
            await Switch(c, "new-viewer");
            Assert.Equal(HttpStatusCode.OK, (await c.GetAsync("/api/v1/vehicles/FH/333333")).StatusCode);
        }

        /// <summary>The user list: server-side search, filters, sorting and paging over the repository's users.</summary>
        [Fact]
        public async Task User_search_pages_filters_and_sorts_on_the_server()
        {
            using var factory = new TestRequestFactory();
            using var c = factory.CreateClient();
            await Switch(c, "admin");
            var store = factory.Services.GetRequiredService<Volvo.TestRequestTool.Application.IWorkspaceStore>();
            for (var i = 0; i < 600; i++)
            {
                await store.SaveUserAsync(new Volvo.TestRequestTool.Domain.UserAccount($"u{i:D4}", $"Person {i:D4}", i % 7 == 0 ? "Reviewer" : "Engineer", [101], i % 23 != 0, i % 2 == 0 ? "IN" : "SE"), default);
            }

            var all = (await c.GetFromJsonAsync<JsonObject>("/api/v1/admin/users/search?take=25"))!;
            Assert.Equal(600 + TestRequestFactory.Accounts.Length, all["all"]!.GetValue<int>());
            Assert.Equal(25, all["items"]!.AsArray().Count);
            Assert.Equal(all["all"]!.GetValue<int>(), all["total"]!.GetValue<int>());
            var kavya = (await c.GetFromJsonAsync<JsonObject>("/api/v1/admin/users/search?q=Kavya%20Nair&role=Reviewer"))!;
            Assert.Contains(kavya["items"]!.AsArray(), u => u!["id"]!.GetValue<string>() == "reviewer" && u["email"]!.GetValue<string>() == "reviewer@trt.test");
            Assert.All(kavya["items"]!.AsArray(), u => Assert.Equal("Reviewer", u!["role"]!.GetValue<string>()));
            var page2 = (await c.GetFromJsonAsync<JsonObject>("/api/v1/admin/users/search?sort=id&skip=25&take=25"))!;
            var page1 = (await c.GetFromJsonAsync<JsonObject>("/api/v1/admin/users/search?sort=id&take=25"))!;
            Assert.DoesNotContain(page2["items"]!.AsArray(), u => page1["items"]!.AsArray().Any(v => v!["id"]!.GetValue<string>() == u!["id"]!.GetValue<string>()));
            var desc = (await c.GetFromJsonAsync<JsonObject>("/api/v1/admin/users/search?sort=id&order=desc&take=2"))!["items"]!.AsArray().Select(u => u!["id"]!.GetValue<string>()).ToArray();
            Assert.True(string.CompareOrdinal(desc[0], desc[1]) >= 0, "highest id first when descending");
            var disabled = (await c.GetFromJsonAsync<JsonObject>("/api/v1/admin/users/search?status=disabled&country=IN&take=50"))!;
            Assert.NotEmpty(disabled["items"]!.AsArray());
            Assert.All(disabled["items"]!.AsArray(), u =>
            {
                Assert.False(u!["enabled"]!.GetValue<bool>());
                Assert.Equal("IN", u["country"]!.GetValue<string>());
            });
            Assert.Equal(200, (await c.GetFromJsonAsync<JsonObject>("/api/v1/admin/users/search?take=5000"))!["take"]!.GetValue<int>());
            var byName = (await c.GetFromJsonAsync<JsonObject>("/api/v1/admin/users/search?q=Person&sort=name&take=200"))!["items"]!.AsArray().Select(u => u!["displayName"]!.GetValue<string>()).ToArray();
            Assert.Equal(byName.Order(StringComparer.OrdinalIgnoreCase), byName);
            await Switch(c, "viewer");
            Assert.Equal(HttpStatusCode.Forbidden, (await c.GetAsync("/api/v1/admin/users/search")).StatusCode);
        }
    }
}
