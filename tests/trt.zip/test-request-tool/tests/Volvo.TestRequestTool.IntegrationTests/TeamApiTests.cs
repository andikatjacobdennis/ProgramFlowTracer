using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>Teams and managed settings: layering, locking, bulk changes with preview, validation, versions and access.</summary>
    public sealed class TeamApiTests
    {
        private static async Task<HttpClient> As(TestRequestFactory factory, string id)
        {
            var c = factory.CreateClient();
            c.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            var r = await c.PostAsJsonAsync("/api/v1/auth/login", TestRequestFactory.Login(id));
            c.DefaultRequestHeaders.Remove("Cookie");
            c.DefaultRequestHeaders.Add("Cookie", r.Headers.GetValues("Set-Cookie").Single(x => x.StartsWith("trt.session=", StringComparison.Ordinal)).Split(';')[0]);
            return c;
        }

        /// <summary>The teams these tests start from (a new repository has none).</summary>
        private static async Task Teams(HttpClient admin)
        {
            foreach (var (id, name, members) in new[] { ("powertrain", "Powertrain software", new[] { "tester", "engineer" }), ("aftermarket", "Aftermarket", new[] { "reviewer" }), ("sweden-ops", "Operations Sweden", new[] { "viewer" }), ("quality", "Quality and audit", new[] { "reviewer", "admin" }) })
            {
                Assert.Equal(HttpStatusCode.OK, (await admin.PutAsJsonAsync("/api/v1/admin/teams/" + id, new { name, description = "", members })).StatusCode);
            }
        }

        [Fact]
        public async Task Bulk_change_previews_then_applies_to_several_teams_in_one_version()
        {
            using var factory = new TestRequestFactory();
            using var admin = await As(factory, "admin");
            await Teams(admin);
            var before = await admin.GetFromJsonAsync<JsonObject>("/api/v1/admin/teams");
            var version = before!["version"]!.GetValue<int>();
            var body = new { teamIds = new[] { "powertrain", "aftermarket" }, set = new { calm = new { value = true, locked = true } }, preview = true };
            var preview = await (await admin.PostAsJsonAsync("/api/v1/admin/teams/bulk-settings", body)).Content.ReadFromJsonAsync<JsonObject>();
            Assert.True(preview!["preview"]!.GetValue<bool>());
            Assert.Equal(2, preview["teams"]!.GetValue<int>());
            Assert.Equal(2, preview["changes"]!.AsArray().Count);
            Assert.Equal(version, (await admin.GetFromJsonAsync<JsonObject>("/api/v1/admin/teams"))!["version"]!.GetValue<int>());   // a preview changes nothing
            var applied = await admin.PostAsJsonAsync("/api/v1/admin/teams/bulk-settings", new { teamIds = new[] { "powertrain", "aftermarket" }, set = new { calm = new { value = true, locked = true } }, preview = false });
            Assert.Equal(HttpStatusCode.OK, applied.StatusCode);
            var after = await admin.GetFromJsonAsync<JsonObject>("/api/v1/admin/teams");
            Assert.Equal(version + 1, after!["version"]!.GetValue<int>());   // both teams in one version
            foreach (var team in after["teams"]!.AsArray().Where(t => t!["id"]!.GetValue<string>() is "powertrain" or "aftermarket"))
            {
                Assert.True(team!["settings"]!["calm"]!["locked"]!.GetValue<bool>());
            }

            var history = await admin.GetFromJsonAsync<JsonArray>("/api/v1/admin/teams/history");
            Assert.Contains("Bulk change", history![0]!["note"]!.GetValue<string>());
        }

        [Fact]
        public async Task Members_see_their_team_settings_and_locks_and_others_do_not()
        {
            using var factory = new TestRequestFactory();
            using var admin = await As(factory, "admin");
            await Teams(admin);
            await admin.PostAsJsonAsync("/api/v1/admin/teams/bulk-settings", new { teamIds = new[] { "sweden-ops" }, set = new { motion = new { value = "off", locked = true } }, preview = false });
            using var op = await As(factory, "viewer");   // a member of Operations Sweden
            var mine = await op.GetFromJsonAsync<JsonObject>("/api/v1/settings/effective");
            Assert.Equal("off", mine!["settings"]!["motion"]!["value"]!.GetValue<string>());
            Assert.True(mine["settings"]!["motion"]!["locked"]!.GetValue<bool>());
            Assert.Contains("Operations Sweden", mine["settings"]!["motion"]!["source"]!.GetValue<string>());
            using var other = await As(factory, "engineer");   // not in Operations Sweden
            Assert.Null((await other.GetFromJsonAsync<JsonObject>("/api/v1/settings/effective"))!["settings"]!["motion"]);
        }

        [Fact]
        public async Task Unknown_settings_and_values_are_refused_and_non_admins_cannot_manage_teams()
        {
            using var factory = new TestRequestFactory();
            using var admin = await As(factory, "admin");
            await Teams(admin);
            Assert.Equal(HttpStatusCode.BadRequest, (await admin.PostAsJsonAsync("/api/v1/admin/teams/bulk-settings", new { teamIds = new[] { "powertrain" }, set = new { canWrite = new { value = true } } })).StatusCode);   // permissions are not settings
            Assert.Equal(HttpStatusCode.BadRequest, (await admin.PostAsJsonAsync("/api/v1/admin/teams/bulk-settings", new { teamIds = new[] { "powertrain" }, set = new { pageSize = new { value = 7 } } })).StatusCode);
            Assert.Equal(HttpStatusCode.NotFound, (await admin.PostAsJsonAsync("/api/v1/admin/teams/bulk-settings", new { teamIds = new[] { "no-such-team" }, set = new { calm = new { value = true } } })).StatusCode);
            using var engineer = await As(factory, "engineer");
            Assert.Equal(HttpStatusCode.Forbidden, (await engineer.GetAsync("/api/v1/admin/teams")).StatusCode);
            Assert.Equal(HttpStatusCode.Forbidden, (await engineer.PostAsJsonAsync("/api/v1/admin/teams/bulk-settings", new { teamIds = new[] { "powertrain" }, set = new { calm = new { value = true } }, preview = false })).StatusCode);
        }

        [Fact]
        public async Task A_stale_base_version_is_refused_instead_of_overwriting()
        {
            using var factory = new TestRequestFactory();
            using var admin = await As(factory, "admin");
            await Teams(admin);
            await admin.PutAsJsonAsync("/api/v1/admin/teams/new-team", new { name = "New team", members = new[] { "engineer" } });
            var stale = await admin.PostAsJsonAsync("/api/v1/admin/teams/bulk-settings", new { teamIds = new[] { "new-team" }, set = new { calm = new { value = true } }, preview = false, baseVersion = 0 });
            Assert.Equal(HttpStatusCode.Conflict, stale.StatusCode);
        }
    }
}
