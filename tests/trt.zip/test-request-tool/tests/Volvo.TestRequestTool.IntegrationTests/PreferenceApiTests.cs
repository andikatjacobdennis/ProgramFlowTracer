using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>Navigation preferences: saved per signed-in user, isolated between users, validated and resettable.</summary>
    public sealed class PreferenceApiTests
    {
        private static async Task<HttpClient> As(TestRequestFactory factory, string id)
        {
            var c = factory.CreateClient();
            c.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            var response = await c.PostAsJsonAsync("/api/v1/auth/login", TestRequestFactory.Login(id));
            Assert.Equal(HttpStatusCode.OK, response.StatusCode);
            var cookie = response.Headers.GetValues("Set-Cookie").Single(x => x.StartsWith("trt.session=", StringComparison.Ordinal));
            c.DefaultRequestHeaders.Remove("Cookie");
            c.DefaultRequestHeaders.Add("Cookie", cookie.Split(';')[0]);
            return c;
        }

        [Fact]
        public async Task Navigation_preference_is_saved_and_returned_on_the_next_session()
        {
            using var factory = new TestRequestFactory();
            using var a = await As(factory, "engineer");
            var saved = await a.PutAsJsonAsync("/api/v1/me/preferences/navigation", new { mode = "compact", autoHide = false });
            Assert.Equal(HttpStatusCode.OK, saved.StatusCode);
            // A second client for the same user (another device) sees the same preference.
            using var again = await As(factory, "engineer");
            var prefs = await again.GetFromJsonAsync<JsonObject>("/api/v1/me/preferences");
            Assert.Equal("compact", prefs!["navigation"]!["mode"]!.GetValue<string>());
            Assert.False(prefs["navigation"]!["autoHide"]!.GetValue<bool>());
        }

        [Fact]
        public async Task Preferences_are_isolated_between_users()
        {
            using var factory = new TestRequestFactory();
            using var engineer = await As(factory, "engineer");
            using var reviewer = await As(factory, "reviewer");
            await engineer.PutAsJsonAsync("/api/v1/me/preferences/navigation", new { mode = "hidden" });
            await reviewer.PutAsJsonAsync("/api/v1/me/preferences/navigation", new { mode = "compact" });
            Assert.Equal("hidden", (await engineer.GetFromJsonAsync<JsonObject>("/api/v1/me/preferences"))!["navigation"]!["mode"]!.GetValue<string>());
            Assert.Equal("compact", (await reviewer.GetFromJsonAsync<JsonObject>("/api/v1/me/preferences"))!["navigation"]!["mode"]!.GetValue<string>());
            using var viewer = await As(factory, "viewer");
            Assert.Null((await viewer.GetFromJsonAsync<JsonObject>("/api/v1/me/preferences"))!["navigation"]);
        }

        [Fact]
        public async Task Unknown_modes_are_refused_and_reset_restores_defaults()
        {
            using var factory = new TestRequestFactory();
            using var c = await As(factory, "engineer");
            Assert.Equal(HttpStatusCode.BadRequest, (await c.PutAsJsonAsync("/api/v1/me/preferences/navigation", new { mode = "sideways" })).StatusCode);
            await c.PutAsJsonAsync("/api/v1/me/preferences/navigation", new { mode = "compact" });
            Assert.Equal(HttpStatusCode.NoContent, (await c.DeleteAsync("/api/v1/me/preferences/navigation")).StatusCode);
            Assert.Null((await c.GetFromJsonAsync<JsonObject>("/api/v1/me/preferences"))!["navigation"]);
        }
    }
}
