using System.Net;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json.Nodes;
using Microsoft.AspNetCore.Mvc.Testing;

namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>The simulated request listener over HTTP: the registry, contracts, samples and sending a message.</summary>
    public sealed class ListenerApiTests
    {
        private static Task<HttpResponseMessage> Send(HttpClient c, string path, string body) =>
            c.PostAsync("/api/v1/listener/" + path, new StringContent(body, Encoding.UTF8, "application/xml"));

        [Fact]
        public async Task The_registry_lists_every_message_type_and_what_the_tool_simulates()
        {
            using var factory = new TestRequestFactory();
            using var c = factory.CreateClient();
            var data = (await c.GetFromJsonAsync<JsonObject>("/api/v1/listener"))!;
            var types = data["messageTypes"]!.AsArray();
            Assert.Equal(64, types.Count);
            var simulated = types.Where(t => t!["simulated"]!.GetValue<bool>()).ToList();
            Assert.Equal(64, simulated.Count);
            Assert.All(types, t => Assert.True(t!["simulated"]!.GetValue<bool>(), t!["key"]!.GetValue<string>()));
            Assert.All(simulated.Where(t => t!["area"]!.GetValue<string>() == "Aftermarket"), t => Assert.True(t!["fromVehicle"]!.GetValue<bool>()));
            Assert.Equal(7, data["vehicles"]!.AsArray().Count);
            var kit = types.Single(t => t!["key"]!.GetValue<string>() == "GetKitEvaluation_2.1")!;
            Assert.Equal("KitEvaluation_2.1.4-Final.xsd", kit["request"]!["file"]!.GetValue<string>());
            Assert.Equal("ShowKitEvaluation", kit["reply"]!["root"]!.GetValue<string>());
        }

        [Fact]
        public async Task Ping_answers_OK_and_GetInfo_describes_the_service()
        {
            using var factory = new TestRequestFactory();
            using var c = factory.CreateClient();
            var ping = (await (await Send(c, "Ping/1.0", "")).Content.ReadFromJsonAsync<JsonObject>())!;
            Assert.Equal("OK", ping["reply"]!["body"]!.GetValue<string>());
            Assert.True(ping["simulated"]!.GetValue<bool>());

            var info = (await (await Send(c, "GetInfo/1.0", "")).Content.ReadFromJsonAsync<JsonObject>())!;
            Assert.Equal("application/json", info["reply"]!["mediaType"]!.GetValue<string>());
            var body = JsonNode.Parse(info["reply"]!["body"]!.GetValue<string>())!;
            Assert.Equal("Test Request Tool", body["title"]!.GetValue<string>());
            Assert.Contains(body["services"]!.AsArray(), s => s!["name"]!.GetValue<string>() == "Ping" && s["version"]!.GetValue<string>() == "1.0");
            Assert.Empty(body["messageHandlers"]!.AsArray());
        }

        [Fact]
        public async Task The_smallest_request_of_a_contract_is_checked_and_answered()
        {
            using var factory = new TestRequestFactory();
            using var c = factory.CreateClient();
            var sample = await c.GetStringAsync("/api/v1/listener/GetVCADSSoftwareReplacement/1.0/sample");
            Assert.Contains("<GetSWReplacement", sample);
            var result = (await (await Send(c, "GetVCADSSoftwareReplacement/1.0", sample)).Content.ReadFromJsonAsync<JsonObject>())!;
            Assert.True(result["simulated"]!.GetValue<bool>());
            Assert.Empty(result["requestErrors"]!.AsArray());
            Assert.Empty(result["replyErrors"]!.AsArray());
            Assert.Contains("Mandatory field", result["reply"]!["body"]!.GetValue<string>());

            var invalid = (await (await Send(c, "GetKitEvaluation/2.1", "<GetKitEvaluation xmlns=\"http://www.volvo.com/KitEvaluation/2_1\"/>")).Content.ReadFromJsonAsync<JsonObject>())!;
            Assert.Equal(107, invalid["notices"]![0]!["code"]!.GetValue<int>());
            Assert.NotEmpty(invalid["requestErrors"]!.AsArray());
        }

        [Fact]
        public async Task A_request_written_for_a_vehicle_is_answered_within_its_contracts()
        {
            using var factory = new TestRequestFactory();
            using var c = factory.CreateClient();
            var request = await c.GetStringAsync("/api/v1/listener/GetKitEvaluation/2.1/sample?vehicle=FH%7C123456");
            Assert.Contains("<ChassisNumber>123456</ChassisNumber>", request);
            var result = (await (await Send(c, "GetKitEvaluation/2.1", request)).Content.ReadFromJsonAsync<JsonObject>())!;
            Assert.True(result["simulated"]!.GetValue<bool>());
            Assert.Empty(result["requestErrors"]!.AsArray());
            Assert.Empty(result["replyErrors"]!.AsArray());
            Assert.Contains("outcome=\"Applicable\"", result["reply"]!["body"]!.GetValue<string>());

            var json = await c.GetAsync("/api/v1/listener/ProductUpdateService/2.0/sample?vehicle=FH%7C333333");
            Assert.Equal("application/json", json.Content.Headers.ContentType!.MediaType);
            var update = (await (await c.PostAsync("/api/v1/listener/ProductUpdateService/2.0", new StringContent(await json.Content.ReadAsStringAsync(), Encoding.UTF8, "application/json"))).Content.ReadFromJsonAsync<JsonObject>())!;
            Assert.Contains("\"productUpdate\"", update["reply"]!["body"]!.GetValue<string>());

            Assert.Equal(HttpStatusCode.NotFound, (await c.GetAsync("/api/v1/listener/GetKitEvaluation/2.1/sample?vehicle=FH%7C999999")).StatusCode);
        }

        [Fact]
        public async Task Unknown_types_missing_contracts_and_other_files_are_refused()
        {
            using var factory = new TestRequestFactory();
            using var c = factory.CreateClient();
            Assert.Equal(HttpStatusCode.NotFound, (await Send(c, "GetKitEvaluation/9.9", "")).StatusCode);
            Assert.Equal(HttpStatusCode.NotFound, (await c.GetAsync("/api/v1/listener/GetProductionSoftwareBreakdown/2.1/sample")).StatusCode);
            Assert.Equal(HttpStatusCode.NotFound, (await c.GetAsync("/api/v1/listener/schemas/..%2Flistener.json")).StatusCode);
            var schema = await c.GetAsync("/api/v1/listener/schemas/VCADS-1.0.1.xsd");
            Assert.Equal(HttpStatusCode.OK, schema.StatusCode);
            Assert.Equal("application/xml", schema.Content.Headers.ContentType!.MediaType);
        }

        [Fact]
        public async Task Viewers_can_read_the_contracts_but_not_send()
        {
            using var factory = new TestRequestFactory { SignedOut = true };
            using var c = factory.CreateClient(new WebApplicationFactoryClientOptions { AllowAutoRedirect = false });
            Assert.Equal(HttpStatusCode.Unauthorized, (await c.GetAsync("/api/v1/listener")).StatusCode);
            await TestRequestFactory.SignInAsync(c, "viewer");
            Assert.Equal(HttpStatusCode.OK, (await c.GetAsync("/api/v1/listener")).StatusCode);
            Assert.Equal(HttpStatusCode.Forbidden, (await Send(c, "Ping/1.0", "")).StatusCode);
        }
    }
}
