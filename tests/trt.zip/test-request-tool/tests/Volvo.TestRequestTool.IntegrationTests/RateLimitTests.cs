using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>
    /// Rate limiting (RateLimiting.cs): limits from configuration, per person; 429 with Retry-After, RateLimit headers and a
    /// problem body naming the policy; RateLimit-Policy on ordinary responses; per-address limit on switching users; limits are
    /// independent per policy and per person; the administrators' view; invalid configuration refuses to start.
    /// </summary>
    public sealed class RateLimitTests
    {
        private static async Task<HttpClient> As(TestRequestFactory factory, string id)
        {
            var c = factory.CreateClient();
            c.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            var r = await c.PostAsJsonAsync("/api/v1/auth/login", TestRequestFactory.Login(id));
            c.DefaultRequestHeaders.Remove("Cookie");
            c.DefaultRequestHeaders.Add("Cookie", r.Headers.GetValues("Set-Cookie").Single(x => x.StartsWith("trt.session=", StringComparison.Ordinal)).Split(';')[0]);
            return c;
        }

        [Fact]
        public async Task A_policy_refuses_calls_over_its_limit_with_retry_guidance_and_names_itself()
        {
            using var factory = new TestRequestFactory { Settings = { ["RateLimiting:Policies:reads:Limit"] = "3", ["RateLimiting:Policies:reads:Kind"] = "fixed" } };
            using var engineer = await As(factory, "engineer");
            for (var i = 0; i < 3; i++)
            {
                var ok = await engineer.GetAsync("/api/v1/fleet/readiness");
                Assert.Equal(HttpStatusCode.OK, ok.StatusCode);
                Assert.Contains("\"reads\";q=3;w=60", string.Join(",", ok.Headers.GetValues("RateLimit-Policy")));
            }
            var refused = await engineer.GetAsync("/api/v1/fleet/readiness");
            Assert.Equal((HttpStatusCode)429, refused.StatusCode);
            Assert.True(int.Parse(refused.Headers.RetryAfter!.ToString()) >= 1);
            Assert.StartsWith("\"reads\";r=0;t=", string.Join(",", refused.Headers.GetValues("RateLimit")));
            var body = await refused.Content.ReadFromJsonAsync<JsonObject>();
            Assert.Equal("rate_limited", body!["title"]!.GetValue<string>());
            Assert.Equal("reads", body["policy"]!.GetValue<string>());
            Assert.True(body["retryable"]!.GetValue<bool>());
            // Other policies and other people are not affected.
            Assert.Equal(HttpStatusCode.OK, (await engineer.GetAsync("/api/v1/features")).StatusCode);
            using var reviewer = await As(factory, "reviewer");
            Assert.Equal(HttpStatusCode.OK, (await reviewer.GetAsync("/api/v1/fleet/readiness")).StatusCode);
            // Administrators see the policy and the rejection; the partition key is hashed.
            using var admin = await As(factory, "admin");
            var view = await admin.GetFromJsonAsync<JsonObject>("/api/v1/admin/rate-limits");
            var reads = view!["policies"]!.AsArray().Single(p => p!["name"]!.GetValue<string>() == "reads")!;
            Assert.Equal(3, reads["limit"]!.GetValue<int>());
            Assert.Equal(1, reads["rejectedSinceStart"]!.GetValue<long>());
            Assert.True(reads["endpoints"]!.GetValue<int>() >= 5);
            Assert.DoesNotContain("engineer", view["recent"]!.ToJsonString());
            Assert.Equal(HttpStatusCode.Forbidden, (await engineer.GetAsync("/api/v1/admin/rate-limits")).StatusCode);
        }

        [Fact]
        public async Task Switching_users_is_limited_per_address_and_writes_have_their_own_allowance()
        {
            using var factory = new TestRequestFactory { SignedOut = true, Settings = { ["RateLimiting:Policies:auth:Limit"] = "2", ["RateLimiting:Policies:writes:Limit"] = "1" } };
            var c = factory.CreateClient();
            c.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            Assert.Equal(HttpStatusCode.OK, (await c.PostAsJsonAsync("/api/v1/auth/login", TestRequestFactory.Login("engineer"))).StatusCode);
            Assert.Equal(HttpStatusCode.OK, (await c.PostAsJsonAsync("/api/v1/auth/login", TestRequestFactory.Login("reviewer"))).StatusCode);
            var third = await c.PostAsJsonAsync("/api/v1/auth/login", TestRequestFactory.Login("admin"));
            Assert.Equal((HttpStatusCode)429, third.StatusCode);
            Assert.Contains("auth", await third.Content.ReadAsStringAsync());
            using var factory2 = new TestRequestFactory { Settings = { ["RateLimiting:Policies:writes:Limit"] = "1" } };
            using var engineer = await As(factory2, "engineer");
            var r = await engineer.PostAsJsonAsync("/api/v1/reviews", new { requestId = Guid.NewGuid() });
            Assert.Equal(HttpStatusCode.NotFound, r.StatusCode);   // counted, and refused for its own reason
            Assert.Equal((HttpStatusCode)429, (await engineer.PostAsJsonAsync("/api/v1/reviews", new { requestId = Guid.NewGuid() })).StatusCode);
        }

        [Fact]
        public async Task Turning_rate_limiting_off_removes_the_limits_and_bad_settings_refuse_to_start()
        {
            using (var off = new TestRequestFactory { Settings = { ["RateLimiting:Enabled"] = "false", ["RateLimiting:Policies:reads:Limit"] = "1" } })
            {
                using var engineer = await As(off, "engineer");
                for (var i = 0; i < 4; i++)
                {
                    Assert.Equal(HttpStatusCode.OK, (await engineer.GetAsync("/api/v1/fleet/readiness")).StatusCode);
                }
            }
            using var bad = new TestRequestFactory { Settings = { ["RateLimiting:Policies:reads:Kind"] = "sometimes" } };
            var e = Assert.ThrowsAny<Exception>(() => bad.CreateClient());
            Assert.Contains("RateLimiting:Policies:reads", e.ToString());
        }
    }
}
