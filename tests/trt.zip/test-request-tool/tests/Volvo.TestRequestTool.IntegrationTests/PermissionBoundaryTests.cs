using System.Net;
using System.Net.Http.Json;
using System.Text.Json.Nodes;
namespace Volvo.TestRequestTool.IntegrationTests
{
    /// <summary>
    /// Permission boundaries at the API for Engineer, Reviewer, Admin and Viewer: the interface hiding a button is never the
    /// control. Also: another user's job or proposal is invisible (404), and cross-site writes are refused.
    /// </summary>
    public sealed class PermissionBoundaryTests
    {
        private static async Task<HttpClient> As(TestRequestFactory factory, string id)
        {
            var c = factory.CreateClient();
            c.DefaultRequestHeaders.Add("X-Studio-Request", "1");
            var r = await c.PostAsJsonAsync("/api/v1/auth/login", TestRequestFactory.Login(id));
            Assert.Equal(HttpStatusCode.OK, r.StatusCode);
            c.DefaultRequestHeaders.Remove("Cookie");
            c.DefaultRequestHeaders.Add("Cookie", r.Headers.GetValues("Set-Cookie").Single(x => x.StartsWith("trt.session=", StringComparison.Ordinal)).Split(';')[0]);
            return c;
        }

        public static IEnumerable<object[]> Matrix() => new[]
        {
            // role, method, path, allowed
            new object[] { "viewer", "GET", "/api/v1/admin/teams", false }, new object[] { "viewer", "GET", "/api/v1/admin/audit", false }, new object[] { "viewer", "GET", "/api/v1/diagnostics/logs", false },
            new object[] { "viewer", "GET", "/api/v1/security/self-test", false }, new object[] { "viewer", "POST", "/api/v1/proposals/workspace/revisions", false }, new object[] { "viewer", "POST", "/api/v1/jobs/requests", false },
            new object[] { "viewer", "GET", "/api/v1/monitor/services", true }, new object[] { "viewer", "GET", "/api/v1/me/preferences", true },
            new object[] { "engineer", "POST", "/api/v1/proposals/workspace/revisions", true }, new object[] { "engineer", "GET", "/api/v1/admin/teams", false },
            new object[] { "engineer", "PUT", "/api/v1/admin/operations/pauses/submissions", false }, new object[] { "engineer", "GET", "/api/v1/diagnostics/system", false },
            new object[] { "reviewer", "GET", "/api/v1/admin/audit", false }, new object[] { "reviewer", "POST", "/api/v1/proposals/workspace/revisions", false },
            new object[] { "admin", "GET", "/api/v1/admin/teams", true }, new object[] { "admin", "GET", "/api/v1/admin/audit", true }, new object[] { "admin", "GET", "/api/v1/diagnostics/logs", true },
        };

        [Theory]
        [MemberData(nameof(Matrix))]
        public async Task Each_role_reaches_only_what_it_may(string role, string method, string path, bool allowed)
        {
            using var factory = new TestRequestFactory();
            using var c = await As(factory, role);
            var body = path.Contains("/revisions", StringComparison.Ordinal) ? JsonContent.Create(new { state = new { x = 1 }, baseRevision = 0 })
                : path.Contains("/pauses/", StringComparison.Ordinal) ? JsonContent.Create(new { reason = "test" })
                : path.Contains("/jobs/", StringComparison.Ordinal) ? JsonContent.Create(new { kind = "Software", payload = new { products = Array.Empty<object>() } }) : null;
            var response = await c.SendAsync(new HttpRequestMessage(new HttpMethod(method), path) { Content = body });
            if (allowed)
            {
                Assert.True(response.StatusCode is not (HttpStatusCode.Forbidden or HttpStatusCode.Unauthorized), $"{role} {method} {path}: {response.StatusCode}");
            }
            else
            {
                Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
            }
        }

        [Fact]
        public async Task Another_users_jobs_and_proposals_are_invisible()
        {
            using var factory = new TestRequestFactory();
            using var engineer = await As(factory, "engineer");
            using var admin = await As(factory, "admin");
            await engineer.PostAsJsonAsync("/api/v1/proposals/workspace/revisions", new { state = new { secret = "engineer's draft" }, baseRevision = 0 });
            // Same proposal id, different user: the admin sees only their own (none), never the engineer's.
            var adminsView = await admin.GetFromJsonAsync<JsonArray>("/api/v1/proposals/workspace/revisions");
            Assert.Empty(adminsView!);
            Assert.Equal(HttpStatusCode.NotFound, (await admin.GetAsync("/api/v1/proposals/workspace/revisions/1")).StatusCode);
            Assert.Equal(HttpStatusCode.NotFound, (await engineer.GetAsync($"/api/v1/jobs/{Guid.NewGuid()}")).StatusCode);
        }

        [Fact]
        public async Task Cross_site_writes_are_refused_before_any_handler()
        {
            using var factory = new TestRequestFactory();
            using var c = await As(factory, "admin");
            var request = new HttpRequestMessage(HttpMethod.Post, "/api/v1/proposals/workspace/revisions") { Content = JsonContent.Create(new { state = new { x = 1 } }) };
            request.Headers.Add("Sec-Fetch-Site", "cross-site");
            var response = await c.SendAsync(request);
            Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
            Assert.Contains("cross_site_request", await response.Content.ReadAsStringAsync());
            Assert.Empty((await c.GetFromJsonAsync<JsonArray>("/api/v1/proposals/workspace/revisions"))!);   // nothing was written
        }

        [Fact]
        public async Task Security_headers_are_on_every_answer()
        {
            using var factory = new TestRequestFactory();
            using var c = factory.CreateClient();
            foreach (var path in new[] { "/", "/api/v1/session", "/does-not-exist" })
            {
                var r = await c.GetAsync(path);
                Assert.Contains("script-src 'self'", r.Headers.GetValues("Content-Security-Policy").Single());
                Assert.Equal("nosniff", r.Headers.GetValues("X-Content-Type-Options").Single());
                Assert.Equal("DENY", r.Headers.GetValues("X-Frame-Options").Single());
                Assert.False(r.Headers.Contains("Server"));
            }
        }
    }
}
