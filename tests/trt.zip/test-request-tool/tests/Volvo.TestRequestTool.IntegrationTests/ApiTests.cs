using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.IntegrationTests
{
    public sealed class ApiTests
    {
        [Fact]
        public async Task Hosted_UI_and_health_are_available()
        {
            using var f = new TestRequestFactory();
            using var client = f.CreateClient();
            Assert.Equal(HttpStatusCode.OK, (await client.GetAsync("/health")).StatusCode);
            var ui = await client.GetStringAsync("/");
            Assert.Contains("Test Request Tool", ui);
            Assert.Matches("src=\"/js/app\\.[0-9a-f]{16}\\.js\"", ui);
            Assert.DoesNotContain("<script>", ui);
            Assert.Equal(HttpStatusCode.NotFound, (await client.GetAsync("/legacy.html")).StatusCode);
        }

        [Fact]
        public async Task Session_permissions_come_from_server_configuration()
        {
            using var f = new TestRequestFactory { Writer = false };
            using var c = f.CreateClient();
            using var d = JsonDocument.Parse(await c.GetStringAsync("/api/v1/session"));
            Assert.False(d.RootElement.GetProperty("canWrite").GetBoolean());
        }

        [Fact]
        public async Task Forbidden_context_returns_403()
        {
            using var f = new TestRequestFactory { Contexts = ["101"] };
            using var c = f.CreateClient();
            Assert.Equal(HttpStatusCode.Forbidden, (await c.GetAsync("/api/v1/vehicles/FH/333333")).StatusCode);
        }

        [Fact]
        public async Task Client_headers_do_not_grant_writer_permissions()
        {
            using var f = new TestRequestFactory { Writer = false };
            using var c = f.CreateClient();
            c.DefaultRequestHeaders.Add("X-Role", "Writer");
            var r = await c.PostAsJsonAsync("/api/v1/vda/commit", new { requestId = Guid.NewGuid(), vehicleId = "FH|333333", expectedRevision = 1 });
            Assert.Equal(HttpStatusCode.Forbidden, r.StatusCode);
        }

        [Fact]
        public async Task Simulation_is_persisted_and_does_not_write_VDA()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            var p = await Product(c);
            var r = await Simulate(c, p);
            Assert.Equal(HttpStatusCode.Created, r.StatusCode);
            var record = (await r.Content.ReadFromJsonAsync<JsonObject>())!;
            Assert.NotEmpty(record["outcomes"]!.AsArray());
            Assert.Equal(HttpStatusCode.OK, (await c.GetAsync("/api/v1/requests/" + record["id"])).StatusCode);
            var current = (await c.GetFromJsonAsync<JsonObject>("/api/v1/vehicles/FH/333333"))!;
            Assert.Equal(1, current.I("revision"));
        }

        [Fact]
        public async Task Draft_conflicts_return_409_problem_details()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            Assert.Equal(HttpStatusCode.OK, (await c.PutAsJsonAsync("/api/v1/drafts/current", new { state = new { tab = "software" }, expectedVersion = (long?)null })).StatusCode);
            var conflict = await c.PutAsJsonAsync("/api/v1/drafts/current", new { state = new { tab = "params" }, expectedVersion = (long?)null });
            Assert.Equal(HttpStatusCode.Conflict, conflict.StatusCode);
            Assert.Equal("application/problem+json", conflict.Content.Headers.ContentType?.MediaType);
        }

        [Fact]
        public async Task Validated_VDA_commit_increments_revision_and_rejects_replay()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            var response = await Simulate(c, await Product(c));
            var record = (await response.Content.ReadFromJsonAsync<JsonObject>())!;
            var body = new { requestId = record.S("id"), vehicleId = "FH|333333", expectedRevision = 1 };
            Assert.Equal(HttpStatusCode.OK, (await c.PostAsJsonAsync("/api/v1/vda/commit", body)).StatusCode);
            Assert.Equal(HttpStatusCode.Conflict, (await c.PostAsJsonAsync("/api/v1/vda/commit", body)).StatusCode);
        }

        [Fact]
        public async Task Create_kit_uses_a_validated_record()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            var response = await Simulate(c, await Product(c));
            var record = (await response.Content.ReadFromJsonAsync<JsonObject>())!;
            var kit = await c.PostAsJsonAsync("/api/v1/kits", new { requestId = record.S("id"), vehicleIds = new[] { "FH|333333" }, name = "T3 kit" });
            Assert.Equal(HttpStatusCode.OK, kit.StatusCode);
        }

        [Fact]
        public async Task Digital_Twin_turned_off_does_not_report_success()
        {
            using var f = new TestRequestFactory { Settings = { ["Services:Endpoints:DigitalTwin:Transport"] = "Off" } };
            using var c = f.CreateClient();
            var r = await c.PostAsJsonAsync("/api/v1/integrations/DigitalTwin", new { });
            Assert.Equal(HttpStatusCode.NotImplemented, r.StatusCode);
        }

        [Fact]
        public async Task Digital_Twin_through_files_writes_the_call_to_its_outbox()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            var r = await c.PostAsJsonAsync("/api/v1/integrations/DigitalTwin", new { vehicle = "FH|333333" });
            Assert.Equal(HttpStatusCode.OK, r.StatusCode);
            var outbox = Path.Combine(f.Directory, "services", "digitaltwin", "invoke", "outbox");
            Assert.Single(Directory.GetFiles(outbox, "*.json"));
            Assert.Contains("FH|333333", File.ReadAllText(Directory.GetFiles(outbox)[0]));
        }

        [Fact]
        public async Task Missing_API_route_does_not_return_the_SPA()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            Assert.Equal(HttpStatusCode.NotFound, (await c.GetAsync("/api/v1/does-not-exist")).StatusCode);
        }

        [Fact]
        public async Task XML_import_rejects_DTD()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            var r = await c.PostAsync("/api/v1/xml/import", new StringContent("<!DOCTYPE p [<!ENTITY x SYSTEM 'file:///etc/passwd'>]><Product xmlns='urn:test-request-studio:product:1'>&x;</Product>", System.Text.Encoding.UTF8, "application/xml"));
            Assert.Equal(HttpStatusCode.BadRequest, r.StatusCode);
        }

        [Fact]
        public async Task Invalid_request_body_returns_400()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            var r = await c.PostAsync("/api/v1/requests", new StringContent("{bad", System.Text.Encoding.UTF8, "application/json"));
            Assert.Equal(HttpStatusCode.BadRequest, r.StatusCode);
        }

        private static async Task<JsonObject> Product(HttpClient c)
        {
            var v = (await c.GetFromJsonAsync<JsonObject>("/api/v1/vehicles/FH/333333"))!;
            return (JsonObject)v["product"]!.DeepClone();
        }

        [Fact]
        public async Task Product_update_service_returns_the_T3_contract_reply()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            var p = await Product(c);
            var r = await c.PostAsJsonAsync("/api/v1/requests", new { kind = "ProductUpdateService", payload = new { schemaVersion = "2.0", criteria = new { scenario = "Introduced", operation = new { operationType = "UpdateToServicePack" } }, products = new[] { p } } });
            Assert.Equal(HttpStatusCode.Created, r.StatusCode);
            var record = (await r.Content.ReadFromJsonAsync<JsonObject>())!;
            var reply = record["serviceResponses"]!["products"]![0]!;
            Assert.Equal("ProductUpdateService", reply["contract"]!.ToString());
            Assert.Equal("T3 SP 2026.1", reply["response"]!["productUpdate"]!["servicePack"]!["name"]!.ToString());
        }

        [Fact]
        public async Task Contract_preview_returns_the_request_and_records_nothing()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            var p = await Product(c);
            var r = await c.PostAsJsonAsync("/api/v1/requests/preview", new { kind = "AvailableProductUpdates", payload = new { contractVersion = "1.1", criteria = new { scenario = "Introduced", actionCriteria = new[] { "SoftwareReplacements.General" } }, products = new[] { p } } });
            Assert.Equal(HttpStatusCode.OK, r.StatusCode);
            var body = (await r.Content.ReadFromJsonAsync<JsonArray>())!;
            Assert.NotNull(body[0]!["GetAvailableUpdates"]);
            Assert.Empty((await c.GetFromJsonAsync<JsonArray>("/api/v1/requests"))!);
        }

        [Fact]
        public async Task Static_assets_revalidate_and_the_UI_guide_is_served()
        {
            using var f = new TestRequestFactory();
            using var c = f.CreateClient();
            var js = await c.GetAsync("/js/testrequest.js");
            Assert.Equal("no-cache", js.Headers.CacheControl!.ToString());
            var guide = await c.GetStringAsync("/guide/");
            Assert.Contains("UI Guide", guide);
            Assert.Contains("guide-data.js", guide);
        }

        private static Task<HttpResponseMessage> Simulate(HttpClient c, JsonObject p) => c.PostAsJsonAsync("/api/v1/requests", new { kind = "Software", payload = new { products = new[] { p }, softwareRequestOperation = 3, scenario = 1, pblUpdateCapable = true, enableMultiNodeBehavior = true } });
    }
}
