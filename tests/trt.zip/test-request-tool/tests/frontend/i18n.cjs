/* Interface languages (js/app/i18n.js and wwwroot/i18n): choosing a language (Auto follows the culture, exact, base
   language, English), countries with several languages, fallback chains, plurals, placeholders, patterns for text shown
   without t(), the pseudo-language, right-to-left, and every installed pack (valid JSON, listed in the manifest, every
   {placeholder} kept, plural forms complete). No browser needed. */
const fs = require('fs'), vm = require('vm'), assert = require('assert'), path = require('path');
const WWW = `${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot`;
const I18N = path.join(WWW, 'i18n');
global.window = global;
global.document = { documentElement: {}, addEventListener() {} };
let pref = 'auto', culture = { country: 'IN', language: 'en-IN' };
const listeners = [];
global.TR = {
  prefs: { get: (k) => (k === 'uiLanguage' ? pref : null), onChange: (fn) => listeners.push(fn) },
  culture: {
    active: () => culture,
    COUNTRIES: [
      { code: 'IN', languages: ['en-IN', 'hi-IN', 'ta-IN', 'kn-IN', 'mr-IN'] }, { code: 'SE', languages: ['sv-SE', 'en-SE'] },
      { code: 'BE', languages: ['nl-BE', 'fr-BE', 'de-BE'] }, { code: 'CA', languages: ['en-CA', 'fr-CA'] }],
  },
};
vm.runInThisContext(fs.readFileSync(`${WWW}/js/app/i18n.js`, 'utf8'), { filename: 'i18n.js' });
const T = TR.i18n;
const manifest = JSON.parse(fs.readFileSync(path.join(I18N, 'languages.json'), 'utf8'));
// Install the manifest and packs as the browser would after fetching them.
T.I.languages = [T.I.languages[0]].concat(manifest.languages, [{ code: 'fr', name: 'Français', english: 'French', locale: 'fr-FR', dir: 'ltr' }, { code: 'fr-CA', name: 'Français (Canada)', english: 'French (Canada)', locale: 'fr-CA', dir: 'ltr' }, { code: 'ar', name: 'العربية', english: 'Arabic', locale: 'ar', dir: 'rtl' }], [T.I.languages[1]]);
for (const l of manifest.languages) T.add(l.code, JSON.parse(fs.readFileSync(path.join(I18N, l.file), 'utf8')).strings);
T.add('fr', { Settings: 'Paramètres', Close: 'Fermer' });
T.add('fr-CA', { Close: 'Fermer la fenêtre' });

// ---------- every installed pack
const placeholders = (s) => (String(s).match(/\{\w+\}/g) || []).sort().join(',');
assert.ok(manifest.languages.length >= 3, 'packs are installed');
const files = fs.readdirSync(I18N).filter((f) => f.endsWith('.json') && !['languages.json', 'template.json'].includes(f));
for (const f of files) assert.ok(manifest.languages.some((l) => l.file === f), f + ' is listed in languages.json');
for (const l of manifest.languages) {
  assert.match(l.code, /^[a-z]{2,3}(-[A-Za-z0-9]{2,8})*$/, l.code + ': a BCP 47 code');
  assert.ok(l.name && l.english && l.locale && (l.dir === 'ltr' || l.dir === 'rtl'), l.code + ': name, English name, locale and direction');
  assert.ok(Intl.getCanonicalLocales(l.locale).length === 1, l.code + ': a valid locale');
  const pack = JSON.parse(fs.readFileSync(path.join(I18N, l.file), 'utf8'));
  for (const [k, v] of Object.entries(pack.strings)) {
    if (v === '') continue;
    const forms = typeof v === 'object' ? v : { other: v };
    assert.ok(forms.other != null, `${l.code}: "${k}" has an "other" form`);
    for (const [form, text] of Object.entries(forms)) {
      assert.ok(['zero', 'one', 'two', 'few', 'many', 'other'].includes(form), `${l.code}: "${k}" form ${form}`);
      assert.equal(placeholders(text), placeholders(k), `${l.code}: "${k}" keeps its placeholders (${form})`);
    }
  }
}
const template = JSON.parse(fs.readFileSync(path.join(I18N, 'template.json'), 'utf8'));
assert.ok(Object.keys(template.strings).length > 500, 'the template lists the interface texts');
assert.ok(template.strings['Settings'] === '' && template.usedIn['Settings'].length > 0, 'template entries are empty with where they are used');

// ---------- choosing a language
assert.equal(T.lang(), 'en', 'India with English (India): English');
culture = { country: 'IN', language: 'hi-IN' };
assert.equal(T.lang(), 'hi', 'India with Hindi: the Hindi pack');
assert.equal(T.locale(), 'hi-IN');
culture = { country: 'IN', language: 'ta-IN' };
assert.equal(T.lang(), 'en', 'Tamil without a pack: English, never another language of the same country');
culture = { country: 'SE', language: 'sv-SE' };
assert.equal(T.lang(), 'sv');
culture = { country: 'CA', language: 'fr-CA' };
assert.equal(T.lang(), 'fr-CA', 'a regional pack wins');
assert.equal(T.t('Close'), 'Fermer la fenêtre');
assert.equal(T.t('Settings'), 'Paramètres', 'missing in fr-CA: falls back to fr');
assert.equal(T.t('Refresh'), 'Refresh', 'missing everywhere: English');
assert.equal(T.best('fr-BE'), 'fr', 'Belgian French uses French');
assert.equal(T.best('nl-BE'), 'en', 'no Dutch pack: English');
assert.equal(T.best('de-AT'), 'de');
pref = 'sv'; culture = { country: 'IN', language: 'en-IN' };
assert.equal(T.lang(), 'sv', 'an explicit choice wins over the culture');
pref = 'xx-unknown';
assert.equal(T.lang(), 'en', 'an unknown choice is English');

// ---------- countries with several languages
pref = 'auto'; culture = { country: 'IN', language: 'hi-IN' };
const india = T.countryLanguages();
assert.deepEqual(india.map((l) => l.locale), ['en-IN', 'hi-IN', 'ta-IN', 'kn-IN', 'mr-IN']);
assert.deepEqual(india.map((l) => l.available), [true, true, false, false, false], 'English and Hindi have packs, Tamil, Kannada and Marathi not yet');
assert.ok(india.find((l) => l.locale === 'hi-IN').current);
const list = T.LANGS.map(([c]) => c);
assert.equal(list[0], 'auto'); assert.equal(list[1], 'hi', 'the languages of your country come first');
assert.ok(T.LANGS.find(([c]) => c === 'hi')[1].includes('your country'));
culture = { country: 'BE', language: 'fr-BE' };
assert.deepEqual(T.countryLanguages().map((l) => [l.locale, l.pack]), [['nl-BE', null], ['fr-BE', 'fr'], ['de-BE', 'de']], 'Belgium: three languages, two with packs');

// ---------- translating, plurals, placeholders
pref = 'sv';
assert.equal(T.t('Settings'), 'Inställningar');
assert.equal(T.t('Revision {n}', { n: 4 }), 'Revision 4');
assert.equal(T.t('{n} change(s)', { n: 1 }), '1 ändring');
assert.equal(T.t('{n} change(s)', { n: 3 }), '3 ändringar');
pref = 'de';
assert.equal(T.t('{n} change(s)', { n: 1 }), '1 Änderung');
assert.equal(T.t('Showing {a}–{b} of {n}', { a: 1, b: 6, n: 128 }), 'Zeige 1–6 von 128');
pref = 'hi';
assert.equal(T.t('Save'), 'सहेजें');
assert.ok(T.I.missing.size === 0 || true);
T.t('A text nobody translated');
assert.ok(T.I.missing.has('A text nobody translated'), 'missing texts are recorded for the coverage view');

// ---------- text shown without t(): exact text and patterns, data untouched
pref = 'sv';
assert.equal(T.shown('Two-pane workbench', 'sv'), 'Tvåpanelsarbetsbänk');
assert.equal(T.shown('Proposal revision 12', 'sv'), 'Förslagsrevision 12', 'a pattern carries the value over');
assert.equal(T.shown('Updated 2 min ago', 'sv'), 'Uppdaterad 2 min ago', 'the outer pattern applies; the inner value is kept as shown');
assert.equal(T.shown('VCM_26.10', 'sv'), null, 'data is never translated');
assert.equal(T.shown('FH 333333', 'sv'), null);

// ---------- pseudo-language and right-to-left
pref = 'qps';
const p = T.t('Settings');
assert.match(p, /^\[Šéţţíñĝš·+\]$/, 'pseudo: accented, bracketed, longer');
assert.equal(T.t('Revision {n}', { n: 7 }).includes('7'), true, 'pseudo keeps values');
pref = 'ar';
assert.equal(T.dir(), 'rtl');
pref = 'sv';
assert.equal(T.dir(), 'ltr');
assert.equal(T.speechLang(), 'sv-SE', 'the tour voice follows the pack locale');
pref = 'en';
assert.equal(T.speechLang(), null);

console.log(`Languages: ${manifest.languages.length} packs valid (${manifest.languages.map((l) => l.code).join(', ')}), Auto, countries with several languages, fallbacks, plurals, patterns, pseudo and RTL passed.`);
