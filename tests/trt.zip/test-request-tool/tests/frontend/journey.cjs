/* The journey and redesigned pages, pure parts: Requests (tabs, filters, sorting), Request execution (axis ticks, stage
   filters), Change impact (tree layout and compatibility lanes), Fleet readiness (filters, counts), Compare breakdown
   (kinds counted B against A, components), Vehicle architecture (computers, runtimes, packages) and Campaigns (tabs).
   No browser needed. */
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const WWW = `${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot`;
const h = (tag, attrs, ...kids) => ({ tag, attrs: attrs || {}, kids: kids.flat(Infinity) });
global.window = global;
global.document = { addEventListener() {}, querySelector: () => null, createElementNS: (ns, tag) => ({ tag, setAttribute() {}, appendChild() {} }), createTextNode: (s) => s };
global.location = { search: '', href: 'http://x/' }; global.history = { replaceState() {} };
const pages = new Map();
global.TR = {
  util: { h, splitList: (s, re) => String(s || '').split(re || /[,\s]+/).map((x) => x.trim()).filter(Boolean), uniq: (a) => [...new Set(a)], store: { get: (k, d) => d, set() {} } },
  icon: () => h('i'), i18n: { t: (s, v) => String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)) },
  pages: { register: (p) => pages.set(p.id, p), get: (id) => pages.get(id), show() {}, current: () => 'x', ui: { button: (l) => h('button', null, l), day: (d) => String(d), when: (d) => String(d) } },
  app: { refresh() {}, shell: { left: null } }, backend: { session: { userId: 'engineer' } }, testRequest: { frame: (c) => c, page() {} }, enums: {}, prefs: { get: () => 1 },
};
TR.server = { apiLog: [], state: { settings: { latency: 0 } }, persist() {} }; TR.ui = { jsonViewer: () => h('pre') }; TR.uiDrawer = { open: true, toggle() {} };
for (const f of ['app/journey', 'app/requests', 'app/home', 'app/adminusers', 'app/execution', 'app/impact', 'app/readiness', 'compare', 'app/architecture', 'app/campaigns', 'app/review', 'app/servercalls', 'app/newrequest', 'app/gettingstarted', 'app/uiguide']) vm.runInThisContext(fs.readFileSync(`${WWW}/js/${f}.js`, 'utf8'), { filename: f + '.js' });

// ---------- shared helpers
const J = TR.journey;
assert.equal(J.label('54f258c0-3266-4296-8cc8-989cbfe4d887'), 'REQ-54F258');
assert.equal(J.secs(19.2), '19.2 ms'); assert.equal(J.secs(8400), '8.4 s'); assert.equal(J.secs(42000), '42 s');
assert.equal(J.csv([['=1+2', 'a,b', 'x"y']]), "'=1+2,\"a,b\",\"x\"\"y\"", 'CSV quotes and neutralises formulas');
for (const s of ['ready', 'blocked', 'stale', 'unknown', 'approved', 'awaiting-review', 'needs-revalidation', 'changed', 'check']) assert.ok(J.STATE[s], s + ' has a label, icon and tone');

// ---------- Requests: tabs, filters, sorting
const items = [
  { id: 'a', label: 'REQ-A', kind: 'Software', vehicles: [{ id: 'FH|1', title: 'FH 1', architecture: 'T3' }], status: 'awaiting-review', owner: { id: 'x', name: 'Ravi' }, mine: false, updatedAt: '2026-10-20T10:00:00Z' },
  { id: 'b', label: 'REQ-B', kind: 'Software', vehicles: [{ id: 'FM|2', title: 'FM 2', architecture: 'Legacy' }], status: 'completed', owner: { id: 'me', name: 'Asha' }, mine: true, updatedAt: '2026-10-20T11:00:00Z' },
  { id: 'c', label: 'REQ-C', kind: 'Software', vehicles: [{ id: 'FH|3', title: 'FH 3', architecture: 'T3' }], status: 'blocked', owner: { id: 'me', name: 'Asha' }, mine: true, updatedAt: '2026-10-20T09:00:00Z' }];
const F = (o) => TR.requestsHub.filter(items, Object.assign({ tab: 'all', q: '', status: '', arch: '', owner: '', sort: 'updatedAt', dir: 'desc' }, o)).map((i) => i.id);
assert.deepEqual(F({}), ['b', 'a', 'c'], 'newest first');
assert.deepEqual(F({ tab: 'assigned' }), [], 'Assigned to me: only reviews assigned to you');
assert.deepEqual(F({ tab: 'queue' }), ['a'], 'Unassigned: others awaiting review that nobody has taken');
items[0].assignee = { id: 'engineer', name: 'Rohan Mehta' };
assert.deepEqual(F({ tab: 'assigned' }), ['a'], 'assigned to me (the session user)');
assert.deepEqual(F({ tab: 'queue' }), []);
delete items[0].assignee;
assert.deepEqual(F({ tab: 'mine' }), ['c'], 'My work: mine and not completed');
assert.deepEqual(F({ tab: 'completed' }), ['b']);
assert.deepEqual(F({ arch: 'T3', sort: 'label', dir: 'asc' }), ['a', 'c']);
assert.deepEqual(F({ q: 'fm2' }), ['b'], 'search finds the chassis without the space');

// ---------- Request execution: axis and stage filters
const ticks = TR.execution.ticks(19.2);
assert.equal(ticks[0], 0); assert.equal(ticks[ticks.length - 1], 19.2); assert.ok(ticks.length <= 7, 'a few readable ticks');
assert.ok(ticks.every((v, i) => i === 0 || v > ticks[i - 1]), 'ascending');
const stages = [{ id: 'q', kind: 'queue', outcome: 'completed' }, { id: 'p', kind: 'service', outcome: 'warning', vehicleId: 'FH|1' }, { id: 'r', kind: 'stage', outcome: 'completed', vehicleId: 'FH|2' }];
assert.deepEqual(TR.execution.visible(stages, 'warnings', true).map((s) => s.id), ['p']);
assert.deepEqual(TR.execution.visible(stages, 'all', false).map((s) => s.id), ['q', 'r'], 'Show service calls off hides integration calls');
assert.deepEqual(TR.execution.visible(stages, 'FH|2', true).map((s) => s.id), ['q', 'r'], 'one vehicle (plus shared stages)');

// ---------- Users (Administration): the query sent to the server (search, filters, sort, page); columns; what each role may do
{
  const A = TR.adminUsers, base = { q: '', role: '', status: '', country: '', sort: 'name', dir: 'asc', page: 1, size: 25 };
  assert.equal(A.query(base), 'sort=name&order=asc&skip=0&take=25');
  assert.equal(A.query(Object.assign({}, base, { q: ' Kavya ', role: 'Reviewer', status: 'enabled', country: 'IN', sort: 'id', dir: 'desc', page: 3, size: 50 })),
    'q=Kavya&role=Reviewer&status=enabled&country=IN&sort=id&order=desc&skip=100&take=50', 'page 3 of 50 skips 100');
  assert.equal(A.query(Object.assign({}, base, { source: 'demo' })), 'sort=name&order=asc&skip=0&take=25', 'there is no Source filter');
  assert.ok(!A.COLS.some((x) => x[0] === 'source'), 'there is no Source column');
  assert.ok(A.DEFAULT_COLS.every((c) => A.COLS.some((x) => x[0] === c)), 'default columns exist');
  assert.ok(A.CAN.every((row) => row.length === 1 + A.ROLES.length), 'every ability says yes or no for each role');
  assert.deepEqual(A.CAN.find((r) => r[0].startsWith('Approve')).slice(1), [1, 1, 0, 0], 'only Admin and Reviewer approve');
}

// ---------- Home: what needs you (your next steps, newest first) and your recent requests
{
  const H = TR.home, it = (label, action, updatedAt, mine = true) => ({ label, action, updatedAt, mine, status: 'x', vehicles: [] });
  const items = [it('A', 'Track', '2026-10-20'), it('B', 'Review', '2026-10-19', false), it('C', 'Submit', '2026-10-21'), it('D', 'Continue', '2026-10-18'), it('E', 'Inspect', '2026-10-22')];
  assert.deepEqual(H.needsYou(items).map((x) => x.label), ['C', 'B', 'D'], 'a decision, a send or a draft needs you; tracking or inspecting does not');
  assert.deepEqual(H.recent(items).map((x) => x.label), ['E', 'C', 'A', 'D'], 'your own requests, newest first');
  assert.equal(H.needsYou(items, 1).length, 1);
  items[1].assignee = { id: 'someone', name: 'Kavya' };
  assert.deepEqual(H.needsYou(items, 5, 'me').map((x) => x.label), ['C', 'D'], 'a decision assigned to someone else does not need you');
  assert.deepEqual(H.needsYou(items, 5, 'someone').map((x) => x.label), ['C', 'B', 'D'], 'but it needs them');
}

// ---------- Changes requested: the reviewer's note is pinned for the author's vehicle until asked again or dismissed
{
  const mem = new Map(), store = TR.util.store; TR.util.store = { get: (k, d) => (mem.has(k) ? mem.get(k) : d), set: (k, v) => mem.set(k, v) };
  const R = TR.review, rec = { id: 'rv-9', label: 'REQ-9', status: 'changes_requested', authorId: 'engineer', decision: { actorName: 'Kavya Nair', note: 'Keep CGW on 1.1.0.', at: '2026-10-21T05:00:00Z' }, evidence: { vehicles: [{ title: 'FH 333333' }] } };
  R.pin(Object.assign({}, rec, { authorId: 'someone-else' }));
  assert.equal(R.pinned('FH 333333'), null, 'only the author gets the note');
  R.pin(rec);
  assert.ok(R.pinned('FH333333'), 'pinned for that vehicle (spaces do not matter)');
  assert.equal(R.pinned('FH 123456'), null, 'and only for that vehicle');
  R.pin(Object.assign({}, rec, { status: 'approved' })); assert.ok(R.pinned('FH 333333'), 'another status does not unpin it');
  R.unpin(); assert.equal(R.pinned('FH 333333'), null, 'asking for approval again (or Dismiss) removes it');
  TR.util.store = store;
}

// ---------- Send: how to send an approved request, the vehicle record preselected; every workspace delivery kept
assert.deepEqual(TR.review.DELIVERY.map((d) => d[0]), ['vda', 'kit', 'twin', 'xml'], 'the delivery choices at Send');
assert.equal(TR.review.V.deliver, 'vda', 'the usual one (update the vehicle record) is preselected');

// ---------- Change impact: the topology tree (vehicle → zone → computer → group → part → patch) and its layout
const legacyParts = [
  { id: 'g:hardware', kind: 'group', label: 'Hardware', name: 'Hardware', status: 'unchanged', children: [{ id: 'hw', kind: 'hardware', label: 'ECU hardware', name: 'ECU', from: '1', to: '1', status: 'unchanged' }] },
  { id: 'g:software', kind: 'group', label: 'Software', name: 'Software', status: 'changed', children: [{ id: 'sw:mainSoftware', kind: 'software', label: 'Main software', name: 'MSW', from: '10', to: '11', status: 'changed' }] },
  { id: 'g:data', kind: 'group', label: 'Data sets', name: 'Data sets', status: 'unchanged', children: [{ id: 'data:0', kind: 'data', label: 'Data set', name: 'Data 1', from: '5', to: '5', status: 'unchanged',
    children: [{ id: 'data:0:patch:0', kind: 'patch', label: 'Patch', name: 'Patch 1', from: '7', to: '7', status: 'unchanged' }] }] }];
const data = { vehicle: { title: 'FM 1' }, modules: [
  { key: 'a', short: 'EMS', status: 'changed', architecture: 'Legacy', cab: false, path: '/16/1/1', parts: legacyParts, components: [] },
  { key: 'b', short: 'IC', status: 'check', architecture: 'Legacy', cab: true, path: '/30/2/1', parts: [], components: [] },
  { key: 'c', short: 'BBM', status: 'unchanged', architecture: 'Legacy', cab: false, path: '', parts: [], components: [] }],
  edges: [{ from: 'a', to: 'b', state: 'not-verified' }] };
const I = TR.impact;
assert.equal(I.zoneOf(data.modules[0]), 'chassis'); assert.equal(I.zoneOf(data.modules[1]), 'cab'); assert.equal(I.zoneOf(data.modules[2]), 'other', 'no node path: other computers');
assert.equal(I.zoneOf({ architecture: 'T3' }), 'hpc');
let root = I.fullTree(data, { view: 'topology', filter: 'all' });
assert.deepEqual(root.children.map((z) => z.zone), ['chassis', 'cab', 'other'], 'zones in a fixed order');
const ems = root.children[0].children[0];
assert.equal(ems.children.length, 3, 'a legacy computer: hardware, software, data sets');
assert.equal(ems.children[2].children[0].children[0].kind, 'patch', 'data sets carry their patches: six levels');
assert.equal(ems.children[2].children[0].children[0].level, 5);
const T3 = I.fullTree({ vehicle: { title: 'FH 3' }, modules: [{ key: 't', short: 'VCM', status: 'unchanged', architecture: 'T3', components: [{ name: 'VCM-Platform', from: '1', to: '1', status: 'unchanged' }] }], edges: [] }, { view: 'topology', filter: 'all' });
assert.equal(T3.children[0].children[0].children[0].kind, 'package', 'without parts, a computer falls back to its software products');
// change-impact view: unchanged computers and unchanged parts are left out
root = I.fullTree(data, { view: 'impact', filter: 'affected' });
const shownComputers = root.children.flatMap((z) => z.children.map((m) => m.id));
assert.deepEqual(shownComputers, ['a', 'b'], 'Changed + affected hides unchanged computers');
assert.deepEqual(root.children[0].children[0].children.map((g) => g.title), ['Software'], 'only the groups that changed');
// depth and search
assert.ok(I.openTo(root, 2).has('zone:chassis') && !I.openTo(root, 2).has('a'), 'Computers: zones open, computers closed');
assert.ok(I.openTo(I.fullTree(data, { view: 'topology', filter: 'all' }), 6).has('a/g:data/data:0'), 'All levels opens down to the patches');
assert.ok(I.pathsTo(I.fullTree(data, { view: 'topology', filter: 'all' }), 'patch 1').has('a/g:data'), 'a search opens the path to its match');
// layout
const full = I.fullTree(data, { view: 'topology', filter: 'all' });
let L = I.layout(full, I.openTo(full, 6), data.edges);
assert.equal(Math.max(...L.nodes.map((n) => n.n.level)), 5, 'six levels drawn');
for (const lvl of [0, 1, 2]) assert.equal(new Set(L.nodes.filter((n) => n.n.level === lvl).map((n) => n.y)).size, 1, 'vehicle, zones and computers each have a row');
const computers = L.nodes.filter((n) => n.n.level === 2).sort((x, y) => x.x - y.x);
computers.forEach((n, i) => { if (i) assert.ok(n.x >= computers[i - 1].x + computers[i - 1].w, 'computer columns do not overlap'); });
L.links.forEach(({ a: pa, b: pb, stacked }) => { assert.ok(pb.y > pa.y, 'a child sits below its parent'); if (stacked) assert.equal(pb.x, pa.x + 18, 'below a computer, contents are indented'); });
const column = L.nodes.filter((n) => n.n.level >= 2 && (n.n.id === 'a' || n.n.id.startsWith('a/'))).sort((x, y) => x.y - y.y);
column.forEach((n, i) => { if (i) assert.ok(n.y >= column[i - 1].y + column[i - 1].h, 'the list under a computer does not overlap'); });
assert.ok(L.width < 3 * 260 + 100, 'however deep, the tree is only as wide as its computers');
assert.equal(L.edges.length, 1); assert.match(L.edges[0].d, /^M[\d.]+,[\d.]+ V[\d.]+ H[\d.]+ V[\d.]+$/, 'the compatibility arrow runs in its own lane');
assert.ok(Number(/V([\d.]+)/.exec(L.edges[0].d)[1]) < L.rowY[2], 'the lane is above the computer row, clear of their contents');
// left to right: one column per level, every child to the right of its parent, no overlaps in a column, lanes before the computers
{
  const R = I.layoutLR(full, I.openTo(full, 6), data.edges);
  R.links.forEach(({ a: pa, b: pb }) => assert.ok(pb.x > pa.x + pa.w, 'a child sits right of its parent'));
  for (let lvl = 0; lvl <= 5; lvl++) {
    const col = R.nodes.filter((n) => n.n.level === lvl).sort((x, y) => x.y - y.y);
    assert.ok(new Set(col.map((n) => n.x)).size <= 1, 'one column per level ' + lvl);
    col.forEach((n, i) => { if (i) assert.ok(n.y >= col[i - 1].y + col[i - 1].h, 'cards in a column do not overlap (level ' + lvl + ')'); });
  }
  assert.equal(R.edges.length, 1); assert.match(R.edges[0].d, /^M[\d.]+,[\d.-]+ H[\d.]+ V[\d.-]+ H[\d.]+$/, 'the relationship runs in a lane');
  assert.ok(Number(/H([\d.]+)/.exec(R.edges[0].d)[1]) < R.colX[2], 'the lane is left of the computer column');
  assert.equal(I.ZOOM, 0.7, 'the tree opens at 70 %');
}
L = I.layout(full, I.openTo(full, 2), []);
assert.equal(Math.max(...L.nodes.map((n) => n.n.level)), 2, 'Computers shows three levels');
assert.ok(L.nodes.filter((n) => n.n.level === 2).every((n) => n.more !== undefined));

// ---------- Fleet readiness
const fleet = [
  { id: 'FH|1', title: 'FH 1', architecture: 'T3', context: { id: 104, name: 'T3' }, cells: { overall: { state: 'ready' } } },
  { id: 'FM|2', title: 'FM 2', architecture: 'Legacy', context: { id: 101, name: 'EU' }, cells: { overall: { state: 'blocked' } } },
  { id: 'FM|3', title: 'FM 3', architecture: 'Legacy', context: { id: 101, name: 'EU' }, cells: { overall: { state: 'unknown' } } }];
const RF = (o) => TR.readiness.filter(fleet, Object.assign({ group: '', arch: '', status: '', q: '' }, o)).map((v) => v.id);
assert.deepEqual(RF({ group: '101' }), ['FM|2', 'FM|3']); assert.deepEqual(RF({ status: 'blocked' }), ['FM|2']); assert.deepEqual(RF({ q: 'fh1' }), ['FH|1']);
assert.deepEqual(TR.readiness.counts(fleet), { ready: 1, pending: 0, blocked: 1, unknown: 1, stale: 0 });

// ---------- Compare breakdown: B against A
const diff = { key: 'FH 1 ↔ FH 2', type: 'Change', children: [
  { key: 'Nodes', type: 'Change', children: [{ key: '16.1.1 EMS', type: 'Change', children: [{ key: 'Version', type: 'Change', source: 'EMS_24.40', target: 'EMS_26.10' }] },
    { key: '40.1.1 TGW', type: 'Remove', children: [{ key: 'Version', type: 'Remove', source: null, target: 'TGW_26.10' }] }] },
  { key: 'ProductSpecification', type: 'Change', children: [{ key: 'Variants', type: 'Change', children: [{ key: 'D13K500', type: 'Add', source: 'D13', target: null }] }, { key: 'vin', type: 'Equal', source: 'X', target: 'X' }] }] };
const leaves = TR.compare.leaves(diff);
assert.deepEqual(TR.compare.counts(leaves), { added: 1, removed: 1, modified: 1, unchanged: 1 }, 'only in B is added, only in A is removed');
assert.deepEqual(leaves.map((l) => l.component), ['16.1.1 EMS', '40.1.1 TGW', 'Variants', 'Specification']);
assert.equal(leaves.find((l) => l.component === '40.1.1 TGW').kind, 'added');

// ---------- Vehicle architecture
const nodes = [
  { name: '50.1.1 VCM', electricalArchitecture: 3, nodeIdentifier: { name: 'VCM' }, versionName: 'VCM_24.40', ecuHardware: { number: 21601601 }, nodeTemplateDocument: { number: 22101600 },
    softwareProducts: [{ name: 'Platform', packageVersion: '1.0.0', executionEnvironment: 'VCM-Linux', logicalEcu: 'VCM-LECU' }, { name: 'Application', packageVersion: '1.0.0', executionEnvironment: 'VCM-Linux' }] },
  { name: '16.1.1 EMS', electricalArchitecture: 1, nodeIdentifier: { name: 'EMS' }, versionName: 'EMS_24.40', ecuHardware: { number: 21600001 }, softwareProducts: [{ name: 'MSW', number: 23100001 }] }];
const impact = { modules: [{ key: 'k1', name: '50.1.1 VCM', status: 'changed', from: 'VCM_24.40', to: 'VCM_26.10', components: [{ name: 'Platform', status: 'changed', from: '1.0.0', to: '1.2.0', changes: [] }, { name: 'Application', status: 'unchanged' }] }, { key: 'k2', name: '16.1.1 EMS', status: 'unchanged', components: [] }], edges: [] };
const comps = TR.architecture.model(nodes, impact);
assert.equal(comps[0].arch, 'T3'); assert.equal(comps[1].arch, 'Legacy');
assert.deepEqual(comps[0].runtimes.map((r) => r.name), ['VCM-Linux'], 'runtimes are the execution environments of the software');
assert.equal(comps[0].packages[0].status, 'changed'); assert.equal(comps[0].packages[0].to, '1.2.0'); assert.equal(comps[0].packages[0].logicalEcu, 'VCM-LECU');
assert.equal(comps[1].runtimes.length, 0, 'legacy software has no runtime in the data');
assert.ok(comps[0].config.some((c) => c.name === 'ECU hardware'), 'configuration items');
assert.equal(TR.architecture.allItems(comps).length, 2 + 1 + 3 + comps[0].config.length + comps[1].config.length);

// ---------- Campaigns
const camps = [{ id: 1, name: 'Pilot', code: 'CMP-001', owner: { id: 'engineer', name: 'Asha' }, status: 'active' }, { id: 2, name: 'Old', code: 'CMP-002', owner: { id: 'x', name: 'Ravi' }, status: 'archived' }, { id: 3, name: 'Draft', code: 'CMP-003', owner: { id: 'x', name: 'Ravi' }, status: 'draft' }];
const CF = (o) => TR.campaigns.filterList(camps, Object.assign({ tab: 'all', q: '', status: '', me: 'engineer' }, o)).map((c) => c.id);
assert.deepEqual(CF({}), [1, 3], 'All hides archived'); assert.deepEqual(CF({ tab: 'archived' }), [2]); assert.deepEqual(CF({ tab: 'mine' }), [1]); assert.deepEqual(CF({ tab: 'active' }), [1]); assert.deepEqual(CF({ q: 'cmp-003' }), [3]);
for (const id of ['requests', 'execution', 'impact', 'readiness', 'campaigns']) assert.ok(pages.has(id), id + ' page registered');

// ---------- Page parameters belong to their page: Change impact never takes the review id as a request id
J.open('review', { rid: 'review-1' });
assert.equal(J.param('rid', 'review'), 'review-1');
assert.equal(J.param('rid', 'impact'), null, 'another page does not see the review id');
J.open('impact', { vid: 'FH|333333' });
assert.equal(J.param('rid', 'impact'), null); assert.equal(J.param('vid', 'impact'), 'FH|333333');
J.open('impact', { rid: 'req-1', vid: 'FH|1' });
assert.equal(J.param('rid', 'impact'), 'req-1', 'a request opened for Change impact is used');
assert.equal(J.param('rid', 'execution'), null);
J.open('review', { rid: 'review-2' }); TR.pages.show('impact');
assert.equal(J.P.rid, null, 'opening another page any other way drops the previous id');
assert.equal(J.param('rid', 'impact'), null);

// ---------- Server calls page: method and endpoint, filters, and the drawer replaced by the page
const SC = TR.serverCalls;
assert.deepEqual(SC.parts({ name: 'GET api/v1/session' }), { method: 'GET', path: '/api/v1/session' }, 'server API calls keep their method (the drawer showed POST /GET …)');
assert.deepEqual(SC.parts({ name: 'TestRequest2000/Compare' }), { method: 'POST', path: '/TestRequest2000/Compare' }, 'simulated service calls are POSTs');
const calls = [{ id: 1, name: 'GET api/v1/session', success: true }, { id: 2, name: 'TestRequest2000/Compare', success: false }, { id: 3, name: 'Permission/Get', success: null }];
assert.deepEqual(SC.filtered(calls, { q: '', outcome: '' }).map((x) => x.id), [3, 2, 1], 'newest first');
assert.deepEqual(SC.filtered(calls, { q: 'compare', outcome: '' }).map((x) => x.id), [2]);
assert.deepEqual(SC.filtered(calls, { q: '', outcome: 'pending' }).map((x) => x.id), [3]);
assert.deepEqual(SC.filtered(calls, { q: '', outcome: 'failed' }).map((x) => x.id), [2]);
assert.equal(TR.uiDrawer.open, false, 'the bottom drawer is not shown');
// measured figures: percentiles, totals, buckets, insights and the simulated timing split
assert.equal(SC.percentile([100, 200, 300, 400, 500], 0.5), 300);
assert.equal(SC.percentile([100, 200, 300, 400, 500], 0.95), 480, 'interpolated p95');
assert.equal(SC.percentile([], 0.5), null);
// axis ticks: whole, round steps from zero; one call is a short bar on a 0–4 axis, never a full-height block
assert.deepEqual(SC.ticks(1, true), [0, 1, 2, 3, 4], 'counts: no repeated 0, 0, 1, 1, 1 labels');
assert.deepEqual(SC.ticks(9, true), [0, 5, 10]);
assert.deepEqual(SC.ticks(314, false), [0, 100, 200, 300, 400], 'latency: round milliseconds');
assert.ok(SC.ticks(37, true).every((v) => Number.isInteger(v)));
assert.match(SC.barPath(10, 20, 8, 100, 4), /^M10,100 V24 Q10,20 14,20 H14 Q18,20 18,24 V100 Z$/, 'rounded top, square base');
const T0 = Date.parse('2026-10-20T06:00:00Z');
const log = [
  { id: 1, time: new Date(T0), name: 'GET api/v1/session', kind: 'server', success: true, ms: 120 },
  { id: 2, time: new Date(T0 + 20000), name: 'TestRequest2000/Compare', kind: 'simulated', success: true, ms: 1400, simLatency: 1200 },
  { id: 3, time: new Date(T0 + 30000), name: 'TestRequest2000/Compare', kind: 'simulated', success: false, ms: 1100, simLatency: 900 },
  { id: 4, time: new Date(T0 + 40000), name: 'TestRequest2000/Compare', kind: 'simulated', success: false, ms: 300, simLatency: 250 },
  { id: 5, time: new Date(T0 + 50000), name: 'Permission/Get', kind: 'simulated', success: null, ms: 0 }];
const sum = SC.summary(log);
assert.deepEqual([sum.total, sum.done, sum.ok, sum.failed], [5, 4, 2, 2], 'waiting calls count in the total, not in the rate');
assert.equal(sum.rate, 50); assert.equal(sum.median, 700);
const bs = SC.buckets(log, T0, T0 + 60000);
assert.ok(bs.length >= 2 && bs.length <= 60, 'between 2 and 60 buckets');
assert.equal(bs.reduce((a, b) => a + b.total, 0), 5, 'every call is in a bucket');
assert.deepEqual(SC.matching(log, { method: 'GET' }).map((x) => x.id), [1]);
assert.deepEqual(SC.matching(log, { source: 'simulated', duration: '1000' }).map((x) => x.id), [2, 3]);
assert.deepEqual(SC.matching(log, { duration: 'fast' }).map((x) => x.id), [1], 'under 300 ms: 300 ms itself and waiting calls are not');
const found = SC.insights(log, 1000);
assert.match(found[0].title, /2 slow calls share one endpoint/); assert.deepEqual(found[0].apply, { tab: 'slow', q: 'TestRequest2000/Compare' });
assert.ok(found.some((i) => /Failure spike/.test(i.title) && i.apply.tab === 'failed'), 'two failures in one minute');
assert.ok(found.some((i) => /simulated delay/.test(i.title)), 'most of the simulated time is the simulated latency');
assert.ok(!SC.insights([log[0]], 0).some((i) => /slow|Failure/.test(i.title)) && /The call succeeded/.test(SC.insights([log[0]], 0)[0].title));
const tm = SC.timing(log[1]);
assert.deepEqual(tm.parts.map((q) => q[1]), [1200, 200], 'simulated: the delay and the processing, adding up to the duration');
assert.equal(SC.source({ name: 'GET api/v1/x' }), 'server'); assert.equal(SC.source({ name: 'Permission/Get' }), 'simulated');
assert.ok(pages.has('calls'), 'Server calls is a page');

// ---------- Create a test request: what the search field accepts
const P2 = TR.newRequest.parse;
assert.deepEqual(P2('FH 333333'), { kind: 'VDA', series: 'FH', number: '333333' });
assert.deepEqual(P2(' fh333333 '), { kind: 'VDA', series: 'FH', number: '333333' }, 'case and spaces do not matter');
assert.deepEqual(P2('RT-000777'), { kind: 'VDA', series: 'RT', number: '000777' }, 'leading zeros are kept');
assert.deepEqual(P2('yv2rt40a5ja123456'), { kind: 'VIN', vin: 'YV2RT40A5JA123456' }, '17 characters is a VIN');
assert.equal(P2('hello'), null); assert.equal(P2('FH'), null); assert.equal(P2('IOQ45678901234567'), null, 'a VIN never contains I, O or Q');
assert.ok(pages.has('new'), 'Create a test request is a page');

// ---------- Getting started: suggestions from Help articles and the glossary, five steps, five checks
TR.help = { find: (q) => (/valid/.test(q) ? [{ id: 'validate', title: 'Validate a proposal' }] : []), open() {}, search() {} };
TR.ux = { GLOSSARY: { VDA: 'Vehicle data record|The official record of each vehicle’s configuration.', NTP: 'Node template (NTP)|The approved software set.' } };
const GS = TR.gettingStarted;
assert.deepEqual(GS.suggestions('valid').map((x) => x.kind + ':' + x.label), ['Guide:Validate a proposal']);
assert.deepEqual(GS.suggestions('official').map((x) => x.kind + ':' + x.label), ['Term:Vehicle data record'], 'glossary terms are found by their meaning');
assert.ok(GS.suggestions('plan').some((x) => x.label === 'Simulation'), 'the key terms on the page are searchable too');
assert.deepEqual(GS.suggestions('v'), [], 'one letter suggests nothing');
assert.equal(GS.STEPS.length, 5); assert.equal(GS.CHECKS.length, 5);
assert.deepEqual(GS.STEPS.map((x) => x[3]), ['load-vehicle', 'change-software', 'validate', 'stages', 'vda'], 'each step opens the Help article that explains it');
assert.ok(pages.has('learn'), 'Getting started is a page');

// ---------- UI guide inside the application: a page, and search marks every match
assert.ok(pages.has('guide'), 'the UI guide is a page, not a separate tab');
const mk = TR.uiGuide.marked('Validate, then validate again', 'valid');
assert.equal(mk.filter((x) => x && x.tag === 'mark').length, 2, 'both matches are marked, whatever their case');
assert.equal(mk.filter((x) => typeof x === 'string').join(''), 'ate, then ate again', 'text around the marks is kept');
assert.deepEqual(mk.filter((x) => x && x.tag === 'mark').map((x) => x.kids.join('')), ['Valid', 'valid'], 'marks keep the original case');
assert.equal(TR.uiGuide.marked('No query', ''), 'No query');

// ---------- Zero counts are neutral: colour is kept for something to look at
const tiles = J.stats([{ n: 0, label: 'Need attention', tone: 'warning' }, { n: 3, label: 'Blocked', tone: 'warning' }, { n: '0', label: 'Failed', tone: 'danger' }]);
const cls = (n) => [].concat(n.attrs.class).filter(Boolean).join(' ');
assert.match(cls(tiles.kids[0]), /tone-neutral/); assert.match(cls(tiles.kids[0]), /is-zero/);
assert.match(cls(tiles.kids[1]), /tone-warning/, 'a count above zero keeps its colour');
assert.match(cls(tiles.kids[2]), /tone-neutral/, 'a zero given as text is neutral too');

// ---------- Nobody is left on a page whose only button cannot work
const flat = (n) => (n && typeof n === 'object' ? [n, ...(n.kids || []).flatMap(flat)] : [n]);
const words = (n) => flat(n).filter((x) => typeof x === 'string').join(' ');
const missing = J.failed('not_found', () => {});
assert.match(words(missing), /This item was not found/, 'a missing item gets a sentence, not the code');
assert.match(words(missing), /Go to Requests/, 'and the way back');
assert.doesNotMatch(words(missing), /Try again/, 'retrying cannot find a missing item');
assert.match(words(J.failed('This item was not found. The link may be out of date, or the item was removed.', () => {})), /Go to Requests/);
assert.match(words(J.failed('forbidden', () => {})), /You do not have access/);
const busy = J.failed('The server is busy.', () => {});
assert.match(words(busy), /Try again/, 'a passing problem keeps Retry');
assert.doesNotMatch(words(busy), /Go to Requests/);
assert.equal(J.demoSwitch, undefined, 'there is no account switching');
// Submit and Submission complete without a chosen review: a heading and a way out, not just a breadcrumb.
for (const id of ['submit', 'outcome']) { const page = pages.get(id); assert.ok(page, id + ' registered'); J.P.rid = null; J.P.sid = null; const out = words(page.render()); assert.match(out, /Go to Requests/, id + ' without a review offers Go to Requests'); }
console.log('Journey pages: helpers, Requests, Execution, Change impact layout, Readiness, Compare (B against A), Architecture, Campaigns and no-dead-end states passed.');

// A destination renders synchronously: it must read its own id, never the previous review id.
{
  const savedHistory = history.replaceState, savedShow = TR.pages.show;
  const savedLocation = { ...location };
  location.href = 'http://x/?view=review&rid=previous-review'; location.search = '?view=review&rid=previous-review';
  history.replaceState = (_, __, url) => { location.href = String(url); location.search = new URL(url).search; };
  let renderedId;
  TR.pages.show = (page) => { savedShow(page); J.readParams(); renderedId = J.param('rid', page); };
  J.open('execution', { rid: 'actual-request' });
  assert.equal(renderedId, 'actual-request', 'execution receives its request id during the first render');
  assert.equal(new URL(location.href).searchParams.get('view'), 'execution');
  TR.pages.show = savedShow; history.replaceState = savedHistory; Object.assign(location, savedLocation);
}
// An empty filtered campaign list must still show the creation editor.
{
 const c=TR.campaigns.C, saved={...c};
 Object.assign(c,{list:[],tab:'archived',vehicles:[],editing:{id:null,name:'',description:'',ids:new Set(),op:3,q:''}});
 assert.match(words(pages.get('campaigns').render()),/Cancel/,'creation remains reachable with no matching campaigns');
 Object.assign(c,saved);
}
// The service returns nested component arrays; render every item and all its part numbers.
{
 vm.runInThisContext(fs.readFileSync(`${WWW}/js/vcads.js`,'utf8'),{filename:'vcads.js'});
 const v=TR.vcads.state; v.series_=['FH'];v.tab='vehicle';
 v.result={completeVehicle:{chassisSeries:'FH',chassisNumber:'123456',parts:[{mid:128,components:[{item:'DATA',parts:['0/23200002','1/23200005']}]}]},workflowList:[]};
 const text=words(TR.vcads.render());
 assert.match(text,/DATA/);assert.match(text,/0\/23200002, 1\/23200005/);
}
