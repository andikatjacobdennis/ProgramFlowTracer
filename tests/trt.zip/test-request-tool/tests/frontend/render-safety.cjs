/* Rendering never leaves a blank screen (shell.js): a view that throws keeps the previous view on screen with a notice; at
   start-up the recovery screen (TRBoot) shows the error instead. No browser needed. */
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const WWW = `${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot`;
class FakeNode {
  constructor(tag) { this.tag = tag; this.nodeType = tag === '#text' ? 3 : 1; this.children = []; this.attributes = {}; this.dataset = {}; this.style = {}; this.className = ''; }
  get classList() { const n = this; return { contains: (c) => n.className.split(/\s+/).includes(c), add(c) { n.className += ' ' + c; }, remove() {}, toggle() {} }; }
  get childNodes() { return this.children.slice(); }
  get firstChild() { return this.children[0] || null; }
  appendChild(n) { if (n.parentNode) n.parentNode.removeChild(n); this.children.push(n); n.parentNode = this; return n; }
  removeChild(n) { this.children = this.children.filter((x) => x !== n); n.parentNode = null; return n; }
  setAttribute(k, v) { this.attributes[k] = v; } getAttribute(k) { return this.attributes[k]; } hasAttribute(k) { return k in this.attributes; }
  addEventListener() {} querySelector() { return null; } querySelectorAll() { return []; }
}
const root = new FakeNode('div'), html = new FakeNode('html');
global.Node = FakeNode; global.window = global;
global.document = { documentElement: html, activeElement: null, createElement: (t) => new FakeNode(t), createTextNode: (t) => Object.assign(new FakeNode('#text'), { text: t }), getElementById: () => root, querySelectorAll: () => [], querySelector: () => null, addEventListener() {} };
global.location = { search: '', href: 'http://localhost/', reload() {} }; global.history = { replaceState() {} };
const errors = []; global.console = Object.assign(Object.create(console), { error: (...a) => errors.push(a) });

const load = (n) => vm.runInThisContext(fs.readFileSync(`${WWW}/js/${n}.js`, 'utf8'), { filename: n });
load('util');
const toasts = [], failures = [];
Object.assign(TR, { enums: {}, model: {}, ui: { summary: { clearAll() {}, listeners: [], render: () => new FakeNode('summary') } }, Pane: function () { this.product = { loaded: () => false }; } });
TR.notify = { toast: (m, kind) => toasts.push([m, kind]) };
window.TRBoot = { fail: (m) => failures.push(m) };
load('shell');
const { h } = TR.util;
let broken = false;
TR.testRequest = { view: 'focused', header: () => h('header', { class: 's-topbar' }, 'header'), frame: (p) => h('div', { class: 's-layout' }, p), workspace: () => { if (broken) throw new Error('workspace exploded'); return h('section', { class: 'ws' }, 'workspace'); } };
TR.compare = { render: () => { throw new Error('compare exploded'); } };
const classes = () => root.children.map((n) => n.className);
const text = (n) => (n.tag === '#text' ? n.text : n.children.map(text).join(' '));

// ---------- start-up failure: the recovery screen, never an empty #app
broken = true;
TR.app.navigate('testrequest');
assert.deepEqual(failures, ['workspace exploded'], 'the start-up recovery screen gets the error');
assert.equal(toasts.length, 0, 'no notice: there was no page to keep');
assert.equal(errors.length, 1, 'the error is written to the console');

// ---------- after start-up, without TRBoot: an inline recovery card with Reload
html.setAttribute('data-booted', 'yes');
TR.app.navigate('testrequest');
assert.equal(failures.length, 1, 'TRBoot is not asked once the app has started');
assert.deepEqual(classes(), ['boot-card'], 'a recovery card instead of a blank screen');
assert.match(text(root.children[0]), /This view could not be shown/);
assert.match(text(root.children[0]), /workspace exploded/);
assert.match(text(root.children[0]), /Reload/);
assert.doesNotMatch(text(root.children[0]), /basic version/, 'the compatibility page is gone');

// ---------- a working page renders normally
broken = false;
TR.app.navigate('testrequest');
assert.deepEqual(classes(), ['s-topbar', 's-layout'], 'header and frame');
const shown = root.children.slice();

// ---------- a view that throws keeps the previous page (the same nodes, so state and edits survive) and says so
TR.app.navigate('compare');
assert.deepEqual(root.children, shown, 'the previous page is put back, node for node');
assert.equal(toasts.length, 1);
assert.equal(toasts[0][1], 'error');
assert.match(toasts[0][0], /previous view is still on screen/);
assert.match(toasts[0][0], /compare exploded/);
assert.equal(TR.app.renderFailures, 3, 'failures are counted');

// ---------- and the next good render replaces it as usual
TR.app.navigate('testrequest');
assert.deepEqual(classes(), ['s-topbar', 's-layout']);
assert.notEqual(root.children[0], shown[0], 'a fresh render');
console.log('render-safety: all checks passed');
