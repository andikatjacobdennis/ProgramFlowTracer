/* Abbreviations (js/app/abbreviations.js): which tokens are marked, what the tooltip says, and the dictionary file. */
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const WWW = path.join(__dirname, '../../src/Volvo.TestRequestTool.Web/wwwroot');

global.window = global;
global.TR = { util: { h: () => ({}) } };
require(path.join(WWW, 'js/app/abbreviations.js'));
const A = TR.abbreviations;

// the company list: valid, sorted, every term with at least one meaning
const data = JSON.parse(fs.readFileSync(path.join(WWW, 'data/abbreviations.json'), 'utf8'));
assert.ok(data.$meta && data.$meta.terms === Object.keys(data.terms).length, 'meta counts the terms');
assert.ok(Object.keys(data.terms).length > 1000, 'the company list is there');
for (const [k, list] of Object.entries(data.terms)) assert.ok(Array.isArray(list) && list.length && list.every((m) => m.standsFor), 'meanings for ' + k);
A.AB.company = data.terms;

// abbreviations, not words
assert.ok(A.looksLikeOne('EMS') && A.looksLikeOne('T3') && A.looksLikeOne('TEA2+') && A.looksLikeOne('S-Note'), 'capitals or a capital and a digit');
assert.ok(!A.looksLikeOne('Kit') && !A.looksLikeOne('OK') && !A.looksLikeOne('IN') && !A.looksLikeOne('ID'), 'words and country codes are not');

// the app's meaning first, then the company list's others
const ems = A.meanings('EMS');
assert.strictEqual(ems.list[0].standsFor, 'Engine Management System', "this tool's meaning first");
assert.ok(ems.list.some((m) => /ElectroMagnetic/i.test(m.standsFor)), 'other meanings follow');
assert.strictEqual(A.meanings('APU').list[0].standsFor, 'Available Product Updates', 'APU means what it means here');
assert.strictEqual(A.meanings('ECUs').key, 'ECU', 'plurals count');
assert.strictEqual(A.meanings('S-Notes').key, 'S-Note');
assert.ok(/^EMS · Engine Management System\|The computer that controls the engine\. Also: /.test(A.explain('EMS')), 'tooltip: name, meaning, description, others');
assert.strictEqual(A.explain('Software'), null);

// finding them in text, and leaving identifiers, versions and file names alone
const tokens = (s) => A.find(s).map((x) => x.token);
assert.deepStrictEqual(tokens('EMS on the FH 333333 needs a new MSW, PBL and SBL.'), ['EMS', 'FH', 'MSW', 'PBL', 'SBL']);
assert.deepStrictEqual(tokens('Original version EMS_26.10 and vcm.EMS and EMS.json'), [], 'identifiers, file names and versions are not marked');
assert.deepStrictEqual(tokens('Send it to VDA. Then check the ECUs (TEA2+ and T3).'), ['VDA', 'ECUs', 'TEA2+', 'T3']);
assert.deepStrictEqual(tokens('OK, it is IN the list'), [], 'everyday words in capitals are left alone');
assert.deepStrictEqual(tokens('lowercase ems and ecu'), [], 'only as written in capitals');
const hit = A.find('Update the EMS now')[0];
assert.strictEqual(hit.index, 11);

// the page lists the app's own terms first
const all = A.all();
assert.ok(all.length > 1000 && all.some((r) => r.key === 'EMS' && r.list[0].app));
console.log(`Abbreviations: ${Object.keys(data.terms).length} in the company list, ${Object.keys(A.APP).length} with this tool's meaning; marking skips words, identifiers, versions and file names.`);
