/* Logic and render-structure checks without a browser. */
const fs=require('fs'),vm=require('vm'),assert=require('assert');
class FakeNode{
 constructor(tag){this.tag=tag;this.children=[];this.attributes={};this.dataset={};this.style={};this.events={};this.classList={add(){},remove(){}};}
 appendChild(n){this.children.push(n);n.parentNode=this;return n;}
 setAttribute(k,v){this.attributes[k]=v;}
 addEventListener(k,v){this.events[k]=v;}
 get firstChild(){return this.children[0]||null;}
 removeChild(n){this.children=this.children.filter(x=>x!==n);}
 querySelector(){return null;} querySelectorAll(){return [];} focus(){} scrollIntoView(){}
}
global.Node=FakeNode;global.window=global;global.crypto=require('crypto').webcrypto;global.localStorage={getItem(){return null},setItem(){},removeItem(){}};
global.document={addEventListener(){},documentElement:{dataset:{}},createElement:t=>new FakeNode(t),createElementNS:(_,t)=>new FakeNode(t),createTextNode:t=>Object.assign(new FakeNode('#text'),{text:t}),getElementById:()=>new FakeNode('div')};
global.location={search:'',href:'file:///test/index.html'};global.history={replaceState(){}};
for(const n of ['util','enums','chassis','model','mockdata','xml','engine','server','ui','productvm','editors','pane','request','shell','compare','vcads','icons','testrequest'])vm.runInThisContext(fs.readFileSync(`${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot/js/${n}.js`,'utf8'),{filename:n});
TR.app.refresh=()=>{};TR.app.shell.left=new TR.Pane('left');TR.app.shell.right=new TR.Pane('right');TR.ui.summary={render:()=>new FakeNode('summary'),clearAll(){},displayResult(){},addInformation(){},addWarning(){},addError(){}};TR.ui.progress={show(){},hide(){}};TR.server.state.settings.latency=0;
const L=TR.app.shell.left,R=TR.app.shell.right;
const walk=n=>[n,...(n?.children||[]).flatMap(walk)];
const strings=n=>walk(n).filter(n=>n.tag==='#text').map(n=>n.text).join(' ');

const storage=new Map();global.localStorage={getItem:k=>storage.get(k)||null,setItem:(k,v)=>storage.set(k,v),removeItem:k=>storage.delete(k)};
TR.backend={session:{userId:'engineer',displayName:'Sam',role:'Engineer',canEdit:true,canWrite:false,canSimulate:true},start:init=>init()};
TR.app.navigate=()=>{};
vm.runInThisContext(fs.readFileSync(`${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot/js/experience.js`,'utf8'),{filename:'experience'});
const X=TR.experience;
assert(strings(X.dashboard()).includes('Your workspace'));
assert(!strings(X.dashboard()).includes('The workflow'), 'Home does not repeat the request workflow');
for (const a of ['Password', 'Jwt', undefined]) { TR.backend.session.authentication = a; assert(!/demo/i.test(strings(X.dashboard())), 'Home has no demo entry (' + a + ')'); }
TR.backend.session.authentication = undefined;
assert(strings(X.map()).includes('Load a vehicle'));
const sample=TR.db.vdaSeed.find(p=>TR.model.chassisOf(p).chassisNumber==='333333');
L.setProducts([TR.model.inflate(TR.util.clone(sample))]);
assert(strings(X.map()).includes('Vehicle map'));
assert(strings(X.map()).includes('VCM'));
assert(strings(X.library()).includes('FH'));
const bookmark=walk(X.library()).find(n=>n.tag==='button'&&strings(n).includes('Bookmark current vehicle'));bookmark.events.click();
assert(strings(X.library()).includes('Load vehicle'));
{const nodes=walk(X.library());const table=nodes.find(n=>n.tag==='table');assert(table,'saved vehicles are a table');assert(['Vehicle','Source','Saved'].every(t=>walk(table).some(n=>n.tag==='th'&&strings(n).includes(t))));assert(!nodes.some(n=>n.tag==='article'),'no cards');}
TR.backend.session.userId='viewer';assert(!strings(X.library()).includes('Load vehicle'));
TR.backend.session.userId='engineer';
let modal;TR.ui.modal=o=>{modal=o;return {};};
const computer=walk(X.map()).find(n=>n.tag==='button'&&strings(n).includes('VCM'));
computer.events.click();assert(modal.buttons.some(b=>b.label==='Apply to proposal'));assert(strings(modal.body()).includes('Logical ECU'));
const fields=walk(modal.body()).filter(n=>n.tag==='input');fields[0].events.input({target:{value:'VCM-EDITED'}});fields[1].events.input({target:{value:'Test environment'}});
TR.testRequest.validation={old:true};TR.backend.latest={old:true};modal.buttons.find(b=>b.label==='Apply to proposal').onClick({close(){}});
assert(L.product.get().nodes.some(n=>(n.softwareProducts||[]).some(p=>p.logicalEcu==='VCM-EDITED')));assert.equal(TR.testRequest.validation,null);assert.equal(TR.backend.latest,null);

TR.backend.session.canEdit=false;computer.events.click();assert(!modal.buttons.some(b=>b.label==='Apply to proposal'));
X.show('map');assert.equal(X.page,'map');TR.testRequest.page();assert.equal(X.page,null);
console.log('Experience dashboard, graphical map details, per-user bookmark isolation, read-only roles and navigation passed.');
vm.runInThisContext(fs.readFileSync(`${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot/js/polish.js`,'utf8'),{filename:'polish'});
assert(!('scenarios' in TR.polish) && !('demos' in TR.polish), 'no demo scenario catalogue');
assert.equal(typeof TR.polish.setEffects, 'function');
X.show('demo');assert(!/demo/i.test(strings(TR.testRequest.workspace())), 'no Demo scenarios page');X.page=null;
console.log('No demo scenarios page or catalogue; navigation enhancements load.');
