/* Listener requests (js/app/listener.js): families and versions, search and filters, outcomes and the XML formatter. */
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '../..');

global.window = global;
global.TR = { util: { h: () => ({}) }, pages: { register: () => {} } };
require(path.join(ROOT, 'src/Volvo.TestRequestTool.Web/wwwroot/js/app/listener.js'));
const L = TR.listener.logic;

// the registry the server sends, as built by scripts/import-contracts.py
const registry = JSON.parse(fs.readFileSync(path.join(ROOT, 'src/Volvo.TestRequestTool.Infrastructure/Contracts/listener.json'), 'utf8'));
const types = registry.messages.map((m) => Object.assign({ simulated: ['Ping_1.0', 'GetInfo_1.0'].includes(m.messageType + '_' + m.version) }, m));

// versions in number order
assert.ok(L.compareVersions('1.7', '2.0') < 0 && L.compareVersions('2.1', '2.0') > 0 && L.compareVersions('10.0', '2.1') > 0 && L.compareVersions('1.0', '1.0') === 0);

// one family per message type, every version once, by area
const families = L.families(types);
assert.strictEqual(families.reduce((n, f) => n + f.versions.length, 0), types.length, 'every version belongs to one family');
assert.strictEqual(families[0].area, 'Audit', 'Audit first');
const dev = families.find((f) => f.messageType === 'ESW_DEV_SOFTWARE_BREAKDOWN_REQUEST');
assert.deepStrictEqual(dev.versions.map((v) => v.version), ['1.4', '1.5', '1.6', '1.7', '2.0', '2.1']);
const areas = families.map((f) => f.area);
assert.deepStrictEqual([...new Set(areas)], ['Audit', 'Aftermarket', 'Production', 'Development', 'Service Configurator', 'VCADS'], 'areas in order, each together');

// search and filters
assert.deepStrictEqual(L.filter(families, 'getkitevaluation', 'all').map((f) => f.messageType), ['GetKitEvaluation'], 'by message type');
assert.ok(L.filter(families, 'kit evaluation', 'all').some((f) => f.messageType === 'GetCampaignEvaluation'), 'and by what it is for');
assert.ok(L.filter(families, 'vcads test request', 'all').length === 4, 'words in any order');
assert.deepStrictEqual(L.filter(families, '', 'simulated').map((f) => f.messageType).sort(), ['GetInfo', 'Ping']);
assert.strictEqual(L.filter(families, '', 'checked').length, families.length - 2);
assert.strictEqual(L.filter(families, '2.1', 'all').some((f) => f.messageType === 'GetBOMConsistencyCheck'), true, 'a version finds its family');

// what each side can do
assert.strictEqual(L.side(null), 'none');
assert.strictEqual(L.side({ json: true }), 'json');
assert.strictEqual(L.side({ missing: true }), 'missing');
assert.strictEqual(L.side({ file: 'KitEvaluation_2.1.4-Final.xsd', root: 'GetKitEvaluation' }), 'xsd');

// outcomes
assert.strictEqual(L.outcome({ simulated: true, reply: { body: 'OK' }, notices: [], replyErrors: [] }), 'answered');
assert.strictEqual(L.outcome({ simulated: false, reply: null, notices: [{ severity: 'Information' }], replyErrors: [] }), 'checked');
assert.strictEqual(L.outcome({ simulated: true, reply: null, notices: [{ severity: 'Error', code: 107 }], replyErrors: [] }), 'rejected');
assert.strictEqual(L.outcome({ simulated: true, reply: { body: '<a/>' }, notices: [], replyErrors: ['x'] }), 'failed');

// the formatter indents elements and keeps text with its element
assert.strictEqual(L.formatXml('<?xml version="1.0"?><a x="1"><b>text</b><c/><d><e>1</e></d></a>'),
  '<?xml version="1.0"?>\n<a x="1">\n  <b>text</b>\n  <c/>\n  <d>\n    <e>1</e>\n  </d>\n</a>');
assert.strictEqual(L.formatXml('OK'), 'OK', 'not XML: left alone');
assert.strictEqual(L.formatXml(L.formatXml('<a><b>1</b></a>')), '<a>\n  <b>1</b>\n</a>', 'formatting twice changes nothing');

console.log(`Listener requests: ${families.length} message types in ${new Set(areas).size} areas, ${types.length} versions; search, filters, outcomes and the XML formatter.`);
