const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
global.window = global;
global.localStorage = { getItem: () => null, setItem() {}, removeItem() {} };
global.crypto = require('crypto').webcrypto;
for (const f of ['util','enums','chassis','model','mockdata','xml','engine','server']) vm.runInThisContext(fs.readFileSync(`${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot/js/${f}.js`, 'utf8'), { filename: f });
const { model: M, db: D, engine: G, util: U } = TR;
const p = M.inflate(U.clone(D.vdaSeed.find(p => M.chassisOf(p).chassisNumber === '333333')));
assert.equal(p.productSpecification.productInformation.context.id, 104);
assert.equal(p.nodes.length, 2);
assert.equal(new Set(p.nodes.map(M.nodeKey)).size, 2);
assert(p.nodes.every(n => n.softwareProducts.length === 2));
for (const op of [1,2,3,4,5]) {
 const result = G.softwareRequest({ products: [p], softwareRequestOperation: op, scenario: 1, pblUpdateCapable: true })[0];
 assert(!(result.errorReport?.errors || []).some(e => e.severity === 0), JSON.stringify(result.errorReport));
 const out = M.applyDelta(U.clone(p), result.delta);
 assert.equal(out.nodes.length, 2);
 if ([3,5].includes(op)) assert(out.nodes.every(n => n.softwareProducts[0].packageVersion === '1.2.0'));
 assert(TR.xml.productToXml(out).includes('<T3Node>'));
 assert(TR.xml.productToXml(out).includes('<SoftwareProduct>'));
}
const changed = U.clone(p);
changed.nodes[0].softwareProducts[0].packageVersion = 'custom';
let delta = M.computeDelta(changed,p);
assert.equal(delta.nodes[0].type,41);
assert(!M.hasDelta(M.computeDelta(changed,M.applyDelta(U.clone(p),delta))));
assert(!M.hasDelta(M.computeDelta(changed,M.applyDelta(U.clone(p),M.convertAssignToReplace(delta,p)))));
assert.equal(M.computeDelta(p,{nodes:[]}).nodes[0].type,42);
const removed = U.clone(p); removed.nodes[0].softwareProducts.pop();
assert(!M.hasDelta(M.computeDelta(removed,M.applyDelta(U.clone(p),M.computeDelta(removed,p)))));
const resolve = U.clone(p); resolve.nodes.forEach(n => n.nodeTemplateDocument = null);
assert.equal(M.findContext(resolve).context.id,104);
assert(!G.softwareRequest({products:[resolve],softwareRequestOperation:4})[0].errorReport?.errors.some(e => e.severity === 0));
for (const seed of D.vdaSeed.filter(x => M.chassisOf(x).chassisNumber !== '333333')) {
 const old = M.inflate(U.clone(seed));
 const response = G.softwareRequest({products:[old],softwareRequestOperation:3,scenario:1,pblUpdateCapable:true})[0];
 assert(response.delta);
 assert(old.nodes.every(n => n.electricalArchitecture !== 3));
}
console.log('T3 operations, package deltas, remove/copy, context resolution, XML output and legacy request smoke checks passed.');

assert(G.productionBreakdown({product:p}).product.nodes.every(n => n.electricalArchitecture === 3));
assert(G.developmentBreakdown({product:p,baselineIdentifier:'BL-T3-2610'}).product.nodes.every(n => n.electricalArchitecture === 3));
