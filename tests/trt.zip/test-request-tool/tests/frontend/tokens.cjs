/* Design tokens (css/fluent-tokens.css): WCAG 2.2 AA contrast for the text and control pairs the interface uses, in both
   themes. 4.5:1 for text (1.4.3), 3:1 for control boundaries and focus indicators (1.4.11). Disabled controls are exempt.
   This checks token pairs, not every rendered screen: see docs/fluent-accessibility.md for what still needs a manual audit. */
const fs = require('fs'), assert = require('assert');
const css = fs.readFileSync(`${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot/css/fluent-tokens.css`, 'utf8');
function block(selector) {
  const i = css.indexOf(selector + ' {');
  assert(i >= 0, 'token block ' + selector);
  const body = css.slice(css.indexOf('{', i) + 1, css.indexOf('}', i));
  return Object.fromEntries([...body.matchAll(/--(fl-[\w-]+):\s*(#[0-9a-fA-F]{6})/g)].map((m) => [m[1], m[2]]));
}
const lum = (hex) => { const c = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255).map((v) => (v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)); return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]; };
const ratio = (a, b) => { const [x, y] = [lum(a), lum(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };

const TEXT = [
  ['fl-neutral-fg1', 'fl-neutral-bg1'], ['fl-neutral-fg1', 'fl-neutral-bg2'], ['fl-neutral-fg1', 'fl-neutral-bg3'],
  ['fl-neutral-fg2', 'fl-neutral-bg1'], ['fl-neutral-fg3', 'fl-neutral-bg1'], ['fl-neutral-fg3', 'fl-neutral-bg2'], ['fl-neutral-fg3', 'fl-neutral-bg3'],
  ['fl-brand-fg1', 'fl-neutral-bg1'], ['fl-brand-fg1', 'fl-neutral-bg2'], ['fl-brand-fg-link', 'fl-neutral-bg1'], ['fl-neutral-fg-on-brand', 'fl-brand-bg'], ['fl-neutral-fg-on-brand', 'fl-brand-bg-hover'],
  ['fl-success-fg', 'fl-success-bg'], ['fl-warning-fg', 'fl-warning-bg'], ['fl-danger-fg', 'fl-danger-bg'],
  ['fl-success-fg', 'fl-neutral-bg1'], ['fl-warning-fg', 'fl-neutral-bg1'], ['fl-danger-fg', 'fl-neutral-bg1'],
  ['fl-brand-fg1', 'fl-brand-bg2'], ['fl-neutral-fg1', 'fl-subtle-bg-selected'],
];
const UI = [['fl-stroke-accessible', 'fl-neutral-bg1'], ['fl-stroke-focus2', 'fl-neutral-bg1'], ['fl-stroke-focus2', 'fl-neutral-bg2'], ['fl-brand-stroke', 'fl-neutral-bg1'], ['fl-brand-bg', 'fl-neutral-bg2']];

const report = [];
for (const [name, sel] of [['light', ':root, :root[data-theme="charcoal-light"]'], ['dark', ':root[data-theme="charcoal"]']]) {
  const t = block(sel);
  for (const [fg, bg] of TEXT) { const r = ratio(t[fg], t[bg]); report.push(`${name} ${fg}/${bg} ${r.toFixed(2)}`); assert(r >= 4.5, `${name}: ${fg} on ${bg} is ${r.toFixed(2)}:1, needs 4.5:1`); }
  for (const [fg, bg] of UI) { const r = ratio(t[fg], t[bg]); assert(r >= 3, `${name}: ${fg} against ${bg} is ${r.toFixed(2)}:1, needs 3:1`); }
}
// Minimum target size token: 24 px (2.5.8 Target Size, Minimum).
assert(/--fl-target-min:\s*24px/.test(css));
// Reduced motion stops animations and transitions.
assert(/data-motion="reduced"\][^{]*\{[^}]*animation-duration:\s*1ms/.test(css));
console.log(`Design tokens: ${TEXT.length * 2} text pairs at 4.5:1 or more and ${UI.length * 2} control pairs at 3:1 or more in light and dark themes; 24 px targets; reduced motion.`);
