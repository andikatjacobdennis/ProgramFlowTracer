/* Page modules in js/app/: preferences, pager, breadcrumbs, next step, Settings search, Vehicle, Activity and About. No browser needed. */
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const WWW = `${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot`;
class FakeNode {
  constructor(tag) { this.tag = tag; this.children = []; this.attributes = {}; this.dataset = {}; this.style = {}; this.events = {}; this.classList = { add() {}, remove() {}, toggle() {} }; }
  appendChild(n) { this.children.push(n); n.parentNode = this; return n; }
  setAttribute(k, v) { this.attributes[k] = v; } getAttribute(k) { return this.attributes[k]; }
  addEventListener(k, v) { this.events[k] = v; }
  get firstChild() { return this.children[0] || null; }
  removeChild(n) { this.children = this.children.filter((x) => x !== n); }
  querySelector() { return null; } querySelectorAll() { return []; } focus() {} scrollIntoView() {}
}
const storage = new Map();
global.Node = FakeNode; global.window = global; global.crypto = require('crypto').webcrypto;
global.localStorage = { getItem: (k) => (storage.has(k) ? storage.get(k) : null), setItem: (k, v) => storage.set(k, v), removeItem: (k) => storage.delete(k) };
global.document = { addEventListener() {}, documentElement: { dataset: {} }, createElement: (t) => new FakeNode(t), createElementNS: (_, t) => new FakeNode(t), createTextNode: (t) => Object.assign(new FakeNode('#text'), { text: t }), getElementById: () => new FakeNode('div') };
global.location = { search: '', href: 'http://localhost/' }; global.history = { replaceState() {} };

// Server API stub: answers the JSON the page modules ask for.
const api = {};
global.fetch = async (url) => { const body = api[url.replace('/api/v1', '')]; return { ok: body !== undefined, json: async () => body ?? { title: 'Not found' } }; };

const load = (n) => vm.runInThisContext(fs.readFileSync(`${WWW}/js/${n}.js`, 'utf8'), { filename: n });
['util', 'enums', 'chassis', 'model', 'mockdata', 'xml', 'engine', 'server', 'ui', 'productvm', 'editors', 'pane', 'request', 'shell', 'compare', 'vcads', 'icons', 'testrequest'].forEach(load);
TR.app.refresh = () => {}; TR.app.refreshSoon = () => {}; TR.app.navigate = () => {};
TR.app.shell.left = new TR.Pane('left'); TR.app.shell.right = new TR.Pane('right');
TR.ui.summary = { render: () => new FakeNode('summary'), clearAll() {}, displayResult() {}, addInformation() {}, addWarning() {}, addError() {} }; TR.ui.progress = { show() {}, hide() {} }; TR.server.state.settings.latency = 0;
TR.backend = { session: { userId: 'engineer', displayName: 'Meera Pillai', role: 'Engineer', canEdit: true, canWrite: true, canSimulate: true }, start: (init) => init() };
load('experience');
['core', 'i18n', 'ml', 'shortcuts', 'culture', 'timezones', 'settings', 'history-graph', 'insights', 'vehicle', 'dashboard', 'activity', 'about', 'personas', 'help-articles', 'help-scenarios', 'help', 'tour'].forEach((n) => load('app/' + n));

const L = TR.app.shell.left, X = TR.experience, root = document.documentElement;
const walk = (n) => [n, ...((n && n.children) || []).flatMap(walk)];
const strings = (n) => walk(n).filter((x) => x.tag === '#text').map((x) => x.text).join(' ');
const tick = () => new Promise((r) => setTimeout(r, 0));

(async () => {
  // ---------- preferences and motion
  assert.equal(TR.prefs.get('pageSize'), 25, 'default rows per page');
  assert.equal(root.dataset.motion, 'full', 'motion is on by default');
  TR.prefs.set('motion', 'off');
  assert.equal(root.dataset.motion, 'reduced', 'motion off marks <html> as reduced');
  assert.equal(TR.pages.ui.motionOn(), false);
  TR.prefs.set('motion', 'on'); TR.prefs.set('textSize', 'large');
  assert.equal(root.dataset.motion, 'full'); assert.equal(root.dataset.textSize, 'large');
  TR.prefs.reset();
  assert.equal(TR.prefs.get('textSize'), 'default', 'reset restores defaults');
  assert.equal(TR.testRequest.theme, 'auto', 'reset restores the Auto theme');

  // ---------- theme cycle: Auto → Light → Dark → Auto
  const seen = [];
  for (let i = 0; i < 3; i++) { TR.pages.cycleTheme(); seen.push(TR.testRequest.theme); }
  assert.deepEqual(seen, ['charcoal-light', 'charcoal', 'auto']);

  // ---------- pager (DocGen Explorer token table)
  const { pageWindow, slice } = TR.pager;
  assert.deepEqual(pageWindow(1, 10), { first: 1, last: 5 });
  assert.deepEqual(pageWindow(5, 10), { first: 3, last: 7 });
  assert.deepEqual(pageWindow(10, 10), { first: 6, last: 10 });
  assert.deepEqual(pageWindow(2, 3), { first: 1, last: 3 });
  const items = Array.from({ length: 120 }, (_, i) => i);
  assert.deepEqual(slice(items, 9, 25).page, 5, 'a page past the end is clamped');
  assert.deepEqual(slice(items, 2, 25).rows[0], 25);
  let asked = null;
  const pager = TR.pager({ total: 120, page: 3, size: 25, onPage: (n) => { asked = n; } });
  assert(strings(pager).includes('Showing 51 – 75 of 120'));
  assert(strings(pager).includes('of 5'));
  const buttons = walk(pager).filter((n) => n.tag === 'button');
  assert.deepEqual(buttons.map((b) => b.attributes['aria-label']), ['First page', 'Previous page', 'Page 1', 'Page 2', 'Page 3', 'Page 4', 'Page 5', 'Next page', 'Last page']);
  assert.equal(buttons.find((b) => b.attributes['aria-current'] === 'page').attributes['aria-label'], 'Page 3');
  buttons.find((b) => b.attributes['aria-label'] === 'Next page').events.click();
  assert.equal(asked, 4);
  assert(strings(TR.pager({ total: 0, page: 1, size: 25, onPage() {} })).includes('Showing 0 – 0 of 0'));

  // ---------- next step and breadcrumbs without a vehicle
  assert.equal(TR.nextStep().label, 'Add a vehicle');
  assert.equal(TR.nextStep().tone, 'primary');
  X.page = 'settings';
  assert.deepEqual(TR.pages.crumbs().map((c) => c.label), ['Home', 'Settings']);
  assert(walk(TR.pages.breadcrumbBar()).some((n) => n.attributes && n.attributes['aria-current'] === 'page'), 'a page under Home has a breadcrumb bar');
  X.page = 'about';
  assert.deepEqual(TR.pages.crumbs().map((c) => c.label), ['Home', 'Settings', 'About']);
  // Home is the root: no breadcrumb bar that would only repeat its own title above the heading.
  X.page = 'home';
  assert.equal(TR.pages.breadcrumbBar(), null, 'no breadcrumb on Home');
  X.page = 'vehicle';
  assert(strings(TR.testRequest.workspace()).includes('No vehicle loaded'), 'Vehicle page has an empty state');

  // ---------- Settings search
  const SP = TR.settingsPage;
  SP.state.query = 'motion';
  assert.deepEqual(SP.visibleSettings().map((s) => s.id).sort(), ['motion'], 'the 3D preview setting is gone; motion covers all animation');
  X.page = 'settings';
  let page = TR.testRequest.workspace();
  assert(walk(page).some((n) => n.tag === 'mark'), 'matches are highlighted');
  assert(strings(page).includes('1 setting match'));
  SP.state.query = 'zzz';
  assert(strings(TR.testRequest.workspace()).includes('No settings match'));
  SP.state.query = 'Accessibility';
  assert(SP.visibleSettings().every((s) => s.section === 'accessibility'), 'searching a section name shows that section');
  SP.state.query = '';
  assert.equal(SP.visibleSettings().length, SP.SETTINGS.length);
  page = TR.testRequest.workspace();
  const motionSwitch = walk(page).find((n) => n.attributes.role === 'switch' && n.attributes['aria-label'] === 'Animations and motion');
  motionSwitch.events.click();
  assert.equal(TR.prefs.get('motion'), 'off', 'the motion switch turns motion off');
  TR.prefs.set('motion', 'on');

  // ---------- Vehicle page: graph, roadmap and history
  const seed = TR.db.vdaSeed.find((p) => TR.model.chassisOf(p).chassisNumber === '333333');
  L.setProducts([TR.model.inflate(TR.util.clone(seed))]);
  const vcm = L.product.current.nodes[0];
  const builtProduct = TR.util.clone(seed); builtProduct.nodes[0].versionName = 'VCM_23.10';
  const person = { id: 'u-7', name: 'Rahul Iyer' }, me = { id: 'engineer', name: 'Meera Pillai' };
  // History, newest first: a kit made from simulation A, VDA revision 2 committed from simulation B, both simulations started
  // from revision 1, then revision 1 and the build. The server sends it in pages; the second page comes when the user scrolls.
  const all = [
    { id: 'kit-1', kind: 'Kit', lane: 'proposal', base: 'rev-1', from: 'req-a', at: '2026-05-03T10:00:00Z', actor: me, title: 'Kit created: Retrofit', summary: 'A kit.', hasSnapshot: false, changes: [] },
    { id: 'rev-2', kind: 'VdaCommit', lane: 'main', parent: 'rev-1', from: 'req-b', at: '2026-05-02T10:00:00Z', actor: person, title: 'VDA revision 2', summary: 'Software update committed.', revision: 2, hasSnapshot: true,
      changes: [{ node: vcm.name, kind: 'Software update', from: 'VCM_23.10', to: vcm.versionName, packages: [{ name: 'VCM-Platform', from: '0.9.0', to: '1.0.0' }] }] },
    { id: 'req-a', kind: 'Simulation', lane: 'proposal', base: 'rev-1', at: '2026-05-01T12:00:00Z', actor: me, title: 'Simulation A', summary: 'Only a simulation.', onlyYou: true, hasSnapshot: false, changes: [], source: { status: 'Ready' } },
    { id: 'req-b', kind: 'Simulation', lane: 'proposal', base: 'rev-1', mergedInto: 'rev-2', at: '2026-05-01T10:00:00Z', actor: me, title: 'Simulation B', summary: 'Only a simulation.', onlyYou: true, hasSnapshot: false, changes: [] },
    { id: 'rev-1', kind: 'VdaRecord', lane: 'main', parent: 'built', at: '2026-04-02T10:00:00Z', actor: { id: 'system', name: 'VDA' }, title: 'VDA revision 1', summary: 'Recorded.', revision: 1, hasSnapshot: true, changes: [] },
    { id: 'built', kind: 'Built', lane: 'main', at: '2026-03-14T10:00:00Z', actor: { id: 'system', name: 'Tuve assembly' }, title: 'Built at Tuve', summary: 'Software installed at the factory.', hasSnapshot: true, changes: [] },
  ];
  const meta = { vehicleId: 'FH|333333', currentRevision: 2, latestSnapshotEntry: 'rev-2', total: all.length, people: [{ ...person, changes: 1 }, { ...me, changes: 3 }] };
  api['/vehicles/FH/333333/timeline?skip=0&take=12'] = { ...meta, skip: 0, hasMore: true, entries: all.slice(0, 2) };
  api['/vehicles/FH/333333/timeline?skip=2&take=12'] = { ...meta, skip: 2, hasMore: false, entries: all.slice(2) };
  api['/vehicles/FH/333333/timeline/built'] = { entryId: 'built', at: '2026-03-14T10:00:00Z', product: builtProduct };
  api['/vehicles/FH/333333/roadmap'] = {
    nodes: [{ node: vcm.name, key: 'VCM', isHpc: true, current: { versionName: vcm.versionName, status: 'Released' },
      upcoming: [{ versionName: 'VCM_26.30', status: 'Pre-release verification', introductionWeek: '202630', blockers: ['Needs ECU hardware 21601602'], packages: [] }] }],
    servicePacks: [{ name: 'T3 SP 2026.1', state: 'Available', updates: ['VCM'], notCovered: [] }],
  };
  X.page = 'vehicle';
  TR.testRequest.workspace(); await tick(); await tick(); await tick(); await tick();
  const V = TR.vehiclePage.V, G = TR.historyGraph;
  assert(V.timeline, 'history loaded');
  assert.equal(V.entries.length, 2, 'only the first page is loaded at first');
  page = TR.testRequest.workspace();
  assert(strings(page).includes('VCM-Platform'), 'graph lists software packages');
  assert(strings(page).includes('Execution environment'), 'graph has a legend');
  assert.deepEqual(TR.pages.crumbs().map((c) => c.label), ['Home', 'Vehicle', L.product.chassisString(), 'Graph']);
  assert.equal(TR.nextStep().label, 'Plan a change', 'with a vehicle loaded the next step is to plan a change');

  V.compare = 'built';
  page = TR.testRequest.workspace();
  assert(strings(page).includes('− VCM_23.10') && strings(page).includes('+ ' + vcm.versionName), 'comparing shows the earlier value in red and the current one in green');
  assert(walk(page).some((n) => n.tag === 'option' && (n.value ?? n.attributes.value) === 'built'), 'the factory build can be compared even before its history page is loaded');

  V.tab = 'roadmap';
  page = TR.testRequest.workspace();
  assert(strings(page).includes('T3 SP 2026.1'));
  assert(strings(page).includes('Needs ECU hardware 21601602'), 'blockers are explained');
  assert(strings(page).includes('week 30, 2026'), 'introduction weeks are readable');
  assert(strings(page).includes('As built'), 'the lane starts at the as-built version when it differs');

  // ---------- History: git-style graph, loaded a page at a time
  V.tab = 'history';
  page = TR.testRequest.workspace();
  assert(strings(page).includes('Load older history') && strings(page).includes('2 of 6 loaded'));
  let g = G.layout(V.entries, true);
  assert.equal(g.rows[1].main.dot, true);
  assert.equal(g.rows[1].main.down, true, 'the main line continues into history that is not loaded yet');
  assert(g.rows[0].lines.some((l) => l.kind === 'down'), 'the kit line runs on towards its unloaded start');
  await TR.vehiclePage.loadMore();
  assert.equal(V.entries.length, 6); assert.equal(V.hasMore, false);
  page = TR.testRequest.workspace();
  assert(strings(page).includes('Beginning of the history'));
  g = G.layout(V.entries, false);
  const laneOf = (id) => g.rows[V.entries.findIndex((e) => e.id === id)].lane;
  assert.equal(laneOf('kit-1'), laneOf('req-a'), 'a kit sits on the branch of the simulation it was made from');
  assert.notEqual(laneOf('req-b'), laneOf('req-a'), 'a committed simulation has its own branch');
  assert(laneOf('req-a') > 0 && laneOf('rev-2') === 0 && laneOf('built') === 0, 'changes to the vehicle are on the main line');
  assert(g.rows[1].lines.some((l) => l.kind === 'join-below' && l.lane === laneOf('req-b')), 'the committed simulation joins the main line at its commit');
  assert.equal(g.rows[4].lines.filter((l) => l.kind === 'leave-above').length, 2, 'both branches start at revision 1');
  assert.equal(g.lanes, 3);
  assert.equal(g.rows[5].main.down, false, 'the main line ends at the build');
  // Simulations from the same revision share one branch.
  const shared = G.layout([{ id: 's1', lane: 'proposal', base: 'r' }, { id: 's2', lane: 'proposal', base: 'r' }, { id: 'r', lane: 'main' }], false);
  assert.equal(shared.branches, 1); assert.equal(shared.rows[0].lane, shared.rows[1].lane);

  assert(strings(page).includes('Rahul Iyer') && strings(page).includes('committed'), 'history shows who made the change');
  assert(strings(page).includes('Current') && strings(page).includes('rev 2'), 'the current revision is tagged');
  assert(strings(page).includes('started from VDA revision 1') && strings(page).includes('committed as VDA revision 2'), 'branches say where they start and end');
  assert.deepEqual(G.stat(all[1].changes), { additions: 2, deletions: 2 });
  assert(strings(page).includes('+2') && strings(page).includes('−2'), 'the GitHub-style diffstat');
  const diff = walk(page).filter((n) => String(n.className).startsWith('gh-line '));
  assert.deepEqual(diff.map((n) => String(n.className).split(' ').pop()), ['del', 'add', 'del', 'add'], 'red lines before, green lines after');
  assert(strings(page).includes('0.9.0') && strings(page).includes('Software update'), 'history shows what changed');

  V.history.person = 'u-7';
  assert.deepEqual(TR.vehiclePage.filteredHistory().map((e) => e.id), ['rev-2']);
  V.history.person = 'all'; V.history.kind = 'changes';
  assert.deepEqual(TR.vehiclePage.filteredHistory().map((e) => e.id), ['rev-2', 'rev-1', 'built']);
  V.history.kind = 'all'; V.history.query = 'factory';
  assert.deepEqual(TR.vehiclePage.filteredHistory().map((e) => e.id), ['built']);
  V.history.query = '0.9.0';
  assert.deepEqual(TR.vehiclePage.filteredHistory().map((e) => e.id), ['rev-2'], 'search finds package versions');
  V.history.query = '';

  // ---------- Activity
  api['/requests?skip=0&take=100'] = [
    { id: 'a', kind: 'Software', createdAt: '2026-05-01T10:00:00Z', outcomes: [{ vehicleId: 'FH|333333', issues: [], limitedValidation: false }] },
    { id: 'b', kind: 'ProductUpdateService', createdAt: '2026-05-02T10:00:00Z', outcomes: [{ vehicleId: 'FH|123456', issues: [{ severity: 0 }], limitedValidation: false }] },
  ];
  X.page = 'activity';
  TR.testRequest.workspace(); await tick(); await tick();
  page = TR.testRequest.workspace();
  assert(strings(page).includes('Product Update Service'));
  assert(strings(page).includes('Showing 1 – 2 of 2'), 'activity uses the shared pager');
  const A = TR.activityPage;
  assert.deepEqual(A.status(A.A.rows[1]), ['Blocked', 'warning']);
  A.A.query = '123456';
  assert.deepEqual(A.filtered().map((r) => r.id), ['b']);
  A.A.query = ''; A.A.kind = 'Software';
  assert.deepEqual(A.filtered().map((r) => r.id), ['a']);

  // ---------- About
  api['/about'] = { name: 'Test Request Tool', version: '1.0.0', runtime: '.NET', os: 'Test', environment: 'Test', authentication: 'Password', storage: 'File', contracts: [{ name: 'Product Update Service', versions: '1.0, 2.0' }], liveServices: 'Not connected.' };
  X.page = 'about';
  TR.testRequest.workspace(); await tick(); await tick();
  page = TR.testRequest.workspace();
  assert(strings(page).includes('Version 1.0.0'));
  assert(strings(page).includes('Supported contracts'));
  assert(strings(page).includes('User name and password') && !/demo/i.test(strings(page)), 'sign-in is named, with no demo wording');

  console.log('Preferences and motion, theme cycle, DocGen pager, breadcrumbs, next step, Settings search, Vehicle graph diff, roadmap and git-style history with paged loading, Activity and About passed.');
})().catch((e) => { console.error(e); process.exitCode = 1; });
