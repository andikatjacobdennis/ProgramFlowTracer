/* Logic and render-structure checks without a browser. */
const fs=require('fs'),vm=require('vm'),assert=require('assert');
class FakeNode{
 constructor(tag){this.tag=tag;this.children=[];this.attributes={};this.dataset={};this.style={};this.events={};this.classList={add(){},remove(){}};}
 appendChild(n){this.children.push(n);n.parentNode=this;return n;}
 setAttribute(k,v){this.attributes[k]=v;}
 addEventListener(k,v){this.events[k]=v;}
 get firstChild(){return this.children[0]||null;}
 removeChild(n){this.children=this.children.filter(x=>x!==n);}
 querySelector(){return null;} querySelectorAll(){return [];} focus(){} scrollIntoView(){}
}
global.Node=FakeNode;global.window=global;global.crypto=require('crypto').webcrypto;global.localStorage={getItem(){return null},setItem(){},removeItem(){}};
global.document={addEventListener(){},documentElement:{dataset:{}},createElement:t=>new FakeNode(t),createElementNS:(_,t)=>new FakeNode(t),createTextNode:t=>Object.assign(new FakeNode('#text'),{text:t}),getElementById:()=>new FakeNode('div')};
global.location={search:'',href:'file:///test/index.html'};global.history={replaceState(){}};
for(const n of ['util','enums','chassis','model','mockdata','xml','engine','server','ui','productvm','editors','pane','request','shell','compare','vcads','icons','testrequest'])vm.runInThisContext(fs.readFileSync(`${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot/js/${n}.js`,'utf8'),{filename:n});
TR.app.refresh=()=>{};TR.app.shell.left=new TR.Pane('left');TR.app.shell.right=new TR.Pane('right');TR.ui.summary={render:()=>new FakeNode('summary'),clearAll(){},displayResult(){},addInformation(){},addWarning(){},addError(){}};TR.ui.progress={show(){},hide(){}};TR.server.state.settings.latency=0;
const L=TR.app.shell.left,R=TR.app.shell.right;
const walk=n=>[n,...(n?.children||[]).flatMap(walk)];
const strings=n=>walk(n).filter(n=>n.tag==='#text').map(n=>n.text).join(' ');
(async()=>{
 assert(strings(TR.testRequest.workspace()).includes('Explore the change.'));
 assert.equal(document.documentElement.dataset.theme,'charcoal-light','Without a saved choice or a dark OS preference the theme is Light Charcoal');
 const seed=TR.db.vdaSeed.find(p=>TR.model.chassisOf(p).chassisNumber==='333333');
 L.setProducts([TR.model.inflate(TR.util.clone(seed))]);
 for(const tab of ['software','params','variants','snotes','structure','templates','info']){
  TR.testRequest.tab=tab;const tree=TR.testRequest.workspace();assert(tree instanceof FakeNode,tab);assert(strings(tree).includes('What would you like to change?'),tab);
 }
 TR.testRequest.tab='software';
 const nd=L.product.current.nodes[0],key=TR.model.nodeKey(nd),pkg=nd.softwareProducts[0];
 L.product.setListItem(key,'softwareProducts','0',{...pkg,parameterTemplate:'PT-DEMO'});
 assert(L.product.dirty());assert.equal(L.product.delta().nodes[0].type,41);
 await TR.request.runRequest(L,false);
 assert(TR.testRequest.validation,'Results recorded');
 assert(TR.testRequest.fresh(),'Results fresh immediately after simulation');
 assert.equal(TR.testRequest.stage,'validate');
 assert(strings(TR.testRequest.workspace()).includes('Simulation results'));
 TR.testRequest.stage='review';assert(strings(TR.testRequest.workspace()).includes('Digital Twin'));
 L.request.selectedScenario=3;assert(!TR.testRequest.fresh(),'Request setting changes invalidate results');
 TR.testRequest.stage='validate';assert(strings(TR.testRequest.workspace()).includes('You changed something after the check. Check again.'));
 assert.equal(TR.testRequest.resultStatus({limitedValidation:true}),'limited');
 assert.equal(TR.testRequest.resultStatus({errorReport:{errors:[{severity:0}]}}),'blocked');
 assert.equal(TR.testRequest.resultStatus({}),'ready');
 TR.testRequest.frame(TR.testRequest.workspace());
 const hd=TR.testRequest.header();const theme=walk(hd).find(n=>n.tag==='select'&&n.attributes['aria-label']==='Theme');
 assert.deepEqual(walk(theme).filter(n=>n.tag==='option').map(n=>[n.value,strings(n)]),[['auto','Auto (system)'],['charcoal-light','Light Charcoal'],['charcoal','Dark Charcoal']],'Auto and the two charcoal themes are offered');
 theme.events.change({target:{value:'charcoal'}});assert.equal(document.documentElement.dataset.theme,'charcoal');
 assert(walk(hd).some(n=>n.tag==='a'&&String(n.attributes.href).startsWith('/guide/#')),'Header links to the UI guide');
 theme.events.change({target:{value:'charcoal-light'}});assert.equal(document.documentElement.dataset.theme,'charcoal-light');
 TR.testRequest.stage='configure';TR.testRequest.tab='software';
 assert(!strings(TR.testRequest.workspace()).includes('Update to service pack'),'T3 service buttons need the server backend');
 assert.equal(TR.testRequest.guideUrl(),'/guide/#configure');
 const options=walk(TR.testRequest.workspace()).find(n=>n.tag==='select'&&String(n.attributes['aria-label']).includes('proposed version'));
 options.events.change({target:{value:'1.1.0'}});
 assert(L.product.current.nodes.some(n=>n.softwareProducts?.some(x=>x.packageVersion==='1.1.0')));
 assert(!TR.testRequest.fresh());
 const extra=TR.model.inflate(TR.util.clone(TR.db.vdaSeed.find(p=>TR.model.chassisOf(p).chassisNumber==='123456')));
 L.setProducts([TR.model.inflate(TR.util.clone(seed)),extra]);
 await TR.request.runRequest(L,false);assert.equal(TR.testRequest.validation.results.length,2);assert(TR.testRequest.fresh());
 L.selectProduct(1);assert(TR.testRequest.fresh(),'Switching selected vehicle preserves batch validation');
 // A clean check asks for approval on the Check page itself (approval needs a server request: stubbed here).
 {const B0=TR.backend,J0=TR.journey;TR.backend=Object.assign({},B0,{latest:{id:'req-1'}});TR.journey=J0||{};TR.testRequest.stage='validate';
  const allReady=TR.testRequest.validation.results.every(r=>TR.testRequest.resultStatus(r)==='ready');
  assert.equal(strings(TR.testRequest.workspace()).includes('All good. Ask for approval.'),allReady,'the approval card shows exactly when every vehicle is ready');
  L.request.selectedScenario=(L.request.selectedScenario%5)+1;assert(!strings(TR.testRequest.workspace()).includes('All good. Ask for approval.'),'not on an out-of-date check');
  TR.backend=B0;TR.journey=J0;}
 
 const legacy=TR.db.vdaSeed.find(p=>TR.model.chassisOf(p).chassisNumber==='123456');
 L.setProducts([TR.model.inflate(TR.util.clone(legacy))]);TR.testRequest.stage='configure';TR.testRequest.tab='software';assert(strings(TR.testRequest.workspace()).includes('TEA2'));
 // T3 with the T3 services: Make changes asks how first (service pack recommended); by hand shows the editor, tabs collapsed.
 TR.t3services=TR.t3services||{open(){},pusCard(){return null;}};
 L.setProducts([TR.model.inflate(TR.util.clone(seed))]);TR.testRequest.stage='configure';TR.testRequest.tab='software';TR.testRequest.path={};TR.testRequest.allTabs=false;
 let tree=TR.testRequest.workspace();const text=strings;
 assert(text(tree).includes('How do you want to change FH 333333?')&&text(tree).includes('Update to the latest service pack'),'the choice comes first for an unchanged T3 vehicle');
 assert(!walk(tree).some(n=>n.attributes&&n.attributes.role==='tab'),'no editor tabs before a choice');
 walk(tree).find(n=>n.tag==='button'&&text(n).includes('Change by hand')).events.click();
 tree=TR.testRequest.workspace();
 assert(text(tree).includes('What would you like to change?'),'by hand: the editor');
 assert.deepEqual(walk(tree).filter(n=>n.attributes&&n.attributes.role==='tab').map((n)=>text(n).trim()),['Software'],'only Software until more are asked for');
 assert(walk(tree).some(n=>n.tag==='button'&&text(n).includes('More editors (6)')));
 TR.testRequest.allTabs=true;assert.equal(walk(TR.testRequest.workspace()).filter(n=>n.attributes&&n.attributes.role==='tab').length,7,'More editors shows all seven');
 // The request panel asks what to do: one task per request type, each with its contract name.
 assert.deepEqual(TR.request.TASKS.map((x)=>x[0]).sort(),[0,2,4,5,6,7,8,9],'every request type is a task');
 assert(TR.request.TASKS.every((x)=>x[1]&&x[2]&&['change','look'].includes(x[3])),'each task has words, a contract name and a group');
 console.log('Studio empty/configure tabs, T3 template deltas, simulation/review, stale-result detection, sidebar/header and legacy render structure passed.');
})().catch(e=>{console.error(e);process.exitCode=1});
