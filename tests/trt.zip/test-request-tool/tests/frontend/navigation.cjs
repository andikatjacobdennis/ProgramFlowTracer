/* Navigation sidebar rules (js/app/navigation.js): modes, the Menu button, auto-hide, mobile, and per-user preferences.
   The DOM behaviour (focus, flyouts, keyboard) is covered by tests/browser/navigation.cjs with Playwright. No browser needed here. */
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const WWW = `${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot`;
const storage = new Map();
global.window = global;
global.localStorage = { getItem: (k) => (storage.has(k) ? storage.get(k) : null), setItem: (k, v) => storage.set(k, v), removeItem: (k) => storage.delete(k) };
global.document = { addEventListener() {}, querySelector: () => null, documentElement: { dataset: {} }, createElement: () => ({}) };
let refreshed = 0;
global.TR = {
  util: { h: () => ({}), store: { get: (k, d) => (storage.has(k) ? JSON.parse(storage.get(k)) ?? d : d), set: (k, v) => storage.set(k, JSON.stringify(v)) } },
  testRequest: { frame: (c) => c, header: () => ({ querySelector: () => null }) }, experience: {},
  app: { refresh: () => { refreshed++; } }, backend: { session: { userId: 'engineer' } }, pages: { current: () => 'home', get: () => null }, i18n: { t: (s) => s },
};
vm.runInThisContext(fs.readFileSync(`${WWW}/js/app/navigation.js`, 'utf8'), { filename: 'navigation.js' });
const { logic } = TR.navigation;

// ---------- Expert tools: by role (Auto), or as chosen
assert.equal(logic.expertOn('auto', 'Admin'), true, 'administrators see Expert tools');
for (const role of ['Engineer', 'Viewer', 'Reviewer', undefined]) assert.equal(logic.expertOn('auto', role), false, 'requesters do not: ' + role);
assert.equal(logic.expertOn('on', 'Viewer'), true, 'anyone can turn them on');
assert.equal(logic.expertOn('off', 'Admin'), false, 'and off');

// ---------- defaults and cleaning
assert.deepEqual(logic.defaults(), { mode: 'menubar', autoHide: true }, 'the menu bar with auto-hide by default');
// ---------- the menu bar: labels always visible; the Menu button opens the full navigation as a drawer and closes it
assert.equal(logic.effective({ mode: 'menubar', autoHide: true }, false), 'menubar');
assert.equal(logic.effective({ mode: 'menubar', autoHide: true }, true), 'drawer', 'phones keep the drawer');
assert.equal(logic.labelsVisible({ mode: 'menubar' }, false, false), true);
assert.deepEqual(logic.menu({ mode: 'menubar', autoHide: true }, false, false), { prefs: { mode: 'menubar', autoHide: true }, drawerOpen: true }, 'Menu opens the drawer, the mode stays');
assert.equal(logic.menu({ mode: 'menubar', autoHide: true }, false, true).drawerOpen, false);
assert.equal(logic.closeAfterNavigation({ mode: 'menubar', autoHide: true }, false, true), true, 'a menu-bar drawer closes after navigating');
assert.deepEqual(logic.clean({ mode: 'sideways', autoHide: 'yes' }), { mode: 'menubar', autoHide: true }, 'unknown values fall back to the defaults');
assert.deepEqual(logic.clean({ mode: 'compact', autoHide: false }), { mode: 'compact', autoHide: false });

// ---------- the three modes, and mobile
for (const mode of logic.MODES) assert.equal(logic.effective({ mode, autoHide: true }, false), mode, mode + ' on desktop');
for (const mode of logic.MODES) assert.equal(logic.effective({ mode, autoHide: true }, true), 'drawer', 'mobile is always a drawer (' + mode + ')');
assert.equal(logic.labelsVisible({ mode: 'expanded' }, false, false), true, 'Expanded shows labels');
assert.equal(logic.labelsVisible({ mode: 'compact' }, false, false), false, 'Compact shows icons only');
assert.equal(logic.labelsVisible({ mode: 'hidden' }, false, false), false, 'Hidden shows nothing until opened');
assert.equal(logic.labelsVisible({ mode: 'hidden' }, false, true), true, 'an open drawer shows icons and labels');
assert.equal(logic.labelsVisible({ mode: 'compact' }, true, true), true, 'mobile drawer shows icons and labels when opened');

// ---------- the Menu button
let r = logic.menu({ mode: 'expanded', autoHide: true }, false, false);
assert.equal(r.prefs.mode, 'compact', 'Menu collapses Expanded to Compact'); assert.equal(r.drawerOpen, false);
r = logic.menu({ mode: 'compact', autoHide: true }, false, false);
assert.equal(r.prefs.mode, 'expanded', 'Menu expands Compact');
r = logic.menu({ mode: 'hidden', autoHide: true }, false, false);
assert.equal(r.prefs.mode, 'hidden', 'Menu never changes Hidden mode itself…'); assert.equal(r.drawerOpen, true, '…it opens the drawer');
assert.equal(logic.menu({ mode: 'hidden', autoHide: true }, false, true).drawerOpen, false, 'and closes it again');
r = logic.menu({ mode: 'expanded', autoHide: true }, true, false);
assert.equal(r.prefs.mode, 'expanded', 'on mobile the saved desktop mode is untouched'); assert.equal(r.drawerOpen, true, 'Menu opens the mobile drawer');

// ---------- auto-hide
assert.equal(logic.closeAfterNavigation({ mode: 'hidden', autoHide: true }, false, true), true, 'desktop drawer closes after navigating');
assert.equal(logic.closeAfterNavigation({ mode: 'expanded', autoHide: true }, true, true), true, 'mobile drawer closes after navigating');
assert.equal(logic.closeAfterNavigation({ mode: 'hidden', autoHide: false }, false, true), false, 'auto-hide off: it stays');
assert.equal(logic.closeAfterNavigation({ mode: 'expanded', autoHide: true }, false, false), false, 'Expanded never hides');
const leave = (o) => logic.closeOnLeave(Object.assign({ drawerOpen: true, autoHide: true, mobile: false, pointerInside: false, focusInside: false, flyoutOpen: false, overlayOpen: false, pressing: false }, o));
assert.equal(leave({}), true, 'pointer and focus both gone: close');
assert.equal(leave({ pointerInside: true }), false, 'pointer still inside');
assert.equal(leave({ focusInside: true }), false, 'keyboard focus still inside');
assert.equal(leave({ flyoutOpen: true }), false, 'never while a flyout (submenu) is open');
assert.equal(leave({ overlayOpen: true }), false, 'never while a panel or dialog is open');
assert.equal(leave({ pressing: true }), false, 'never during a press inside the navigation');
assert.equal(leave({ autoHide: false }), false, 'auto-hide off');
assert.equal(leave({ mobile: true }), false, 'mobile closes after navigation, not on leave');

// ---------- per-user persistence and isolation in this browser
assert.notEqual(logic.key('engineer'), logic.key('reviewer'), 'each user has their own key');
TR.navigation.setPrefs({ mode: 'compact', autoHide: false }, { local: true });
assert.deepEqual(JSON.parse(storage.get(logic.key('engineer'))), { mode: 'compact', autoHide: false }, 'saved for the engineer');
TR.backend.session.userId = 'reviewer';
assert.deepEqual(TR.navigation.prefs(), { mode: 'menubar', autoHide: true }, 'another user on the same browser gets their own (default) preferences');
TR.navigation.setPrefs({ mode: 'hidden', autoHide: true }, { local: true });
TR.backend.session.userId = 'engineer';
assert.deepEqual(TR.navigation.prefs(), { mode: 'compact', autoHide: false }, 'switching back restores the engineer’s preferences');
assert(refreshed > 0, 'changes re-render the frame (page, edits and scroll are kept by the renderer)');

console.log('Navigation: four modes (menu bar default), mobile drawer, Menu button, auto-hide rules and per-user preference isolation passed.');
