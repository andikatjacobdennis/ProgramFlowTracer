/* Exercise the launch scripts as child processes. These checks do not replace a real .NET build. */
const fs=require('fs'),path=require('path'),cp=require('child_process'),assert=require('assert');
const root=path.resolve(__dirname,'../..');
const config=JSON.parse(fs.readFileSync(path.join(root,'global.json'),'utf8'));
assert.equal(config.sdk.version,'10.0.100');assert.equal(config.sdk.rollForward,'latestFeature');assert.equal(config.sdk.allowPrerelease,false);
if(process.platform==='win32') {console.log('SDK policy verified; shell startup harness runs on Linux.');process.exit(0);}
const scratch=fs.mkdtempSync(path.join(__dirname,'.startup-'));
try {
 const fake=path.join(scratch,'dotnet'),log=path.join(scratch,'calls.log');
 fs.writeFileSync(fake,`#!/bin/bash
printf '%s\\n' "$*" >> "$STARTUP_LOG"
case "$1" in
 --list-sdks) printf '%s\\n' "$MOCK_SDKS" ;;
 --version) printf '%s\\n' "$MOCK_SELECTED" ;;
 restore) exit "\${MOCK_RESTORE_EXIT:-0}" ;;
 build) exit "\${MOCK_BUILD_EXIT:-0}" ;;
 run) test "$ASPNETCORE_ENVIRONMENT" = Development || exit 90 ;;
esac
`,{mode:0o755});
 const env={...process.env,PATH:scratch+path.delimiter+process.env.PATH,STARTUP_LOG:log,MOCK_SDKS:'10.0.100 [/sdk]',MOCK_SELECTED:'10.0.100'};
 function launch(changes={}){fs.writeFileSync(log,'');return cp.spawnSync('bash',['scripts/start-local.sh'],{cwd:root,env:{...env,...changes},encoding:'utf8'});}
 let result=launch();assert.equal(result.status,0,result.stderr);let calls=fs.readFileSync(log,'utf8');assert(calls.includes('restore TestRequestTool.slnx'));assert(calls.includes('build src/Volvo.TestRequestTool.Web/Volvo.TestRequestTool.Web.csproj --no-restore'));assert(calls.includes('--no-launch-profile --urls http://localhost:5100'));
 result=launch({MOCK_SDKS:'10.0.301 [/sdk]',MOCK_SELECTED:'10.0.301'});assert.equal(result.status,0,result.stderr);
 result=launch({MOCK_SDKS:'9.0.300 [/sdk]',MOCK_SELECTED:'9.0.300'});assert.notEqual(result.status,0);assert(!fs.readFileSync(log,'utf8').includes('restore '));assert(result.stderr.includes('stable .NET 10 SDK'));
 result=launch({MOCK_RESTORE_EXIT:'1'});assert.notEqual(result.status,0);assert(!fs.readFileSync(log,'utf8').includes('run '));
 result=launch({MOCK_BUILD_EXIT:'1'});assert.notEqual(result.status,0);assert(!fs.readFileSync(log,'utf8').includes('run '));
 console.log('SDK configuration and launcher regression checks passed: baseline/later SDK, unsupported SDK, restore/build failures, Development startup.');
} finally {fs.rmSync(scratch,{recursive:true,force:true});}
