/* Back to top (js/app/backtotop.js): visibility thresholds with hysteresis, the scroll container it belongs to (main area,
   each pane, panels; never the navigation or a panning graph canvas), focus after activation (the heading, with
   preventScroll), reduced motion, and two panes keeping their own controls. A tiny fake DOM; no browser needed. */
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const WWW = `${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot`;

// ---------- a minimal element: classes, attributes, children, matches/closest for the selectors the module uses
class El {
  constructor(tag, cls, attrs) { this.tagName = tag.toUpperCase(); this.classes = new Set((cls || '').split(' ').filter(Boolean)); this.attrs = Object.assign({}, attrs); this.children = []; this.parent = null; this.scrollTop = 0; this.clientHeight = 500; this.scrolled = []; this.focused = null; this.style = { setProperty() {} }; }
  append(c) { c.parent = this; this.children.push(c); return c; }
  appendChild(c) { return this.append(c); }
  get isConnected() { let n = this; while (n.parent) n = n.parent; return n === ROOT; }
  get classList() { const s = this.classes; return { toggle: (c, on) => (on ? s.add(c) : s.delete(c)), contains: (c) => s.has(c), add: (c) => s.add(c) }; }
  hasAttribute(a) { return a in this.attrs; } setAttribute(a, v) { this.attrs[a] = String(v); } getAttribute(a) { return this.attrs[a]; }
  set tabIndex(v) { this.attrs.tabindex = String(v); } get tabIndex() { return Number(this.attrs.tabindex); }
  matchesOne(sel) {
    sel = sel.trim();
    if (sel.includes(' ')) { const parts = sel.split(/\s+/); if (!this.matchesOne(parts[parts.length - 1])) return false; const up = this.parent && this.parent.closest(parts.slice(0, -1).join(' ')); return !!up; }
    const m = sel.match(/^([a-z0-9]*)((?:\.[\w-]+)*)((?:\[[^\]]+\])*)(?:#([\w-]+))?$/i) || sel.match(/^#([\w-]+)$/);
    if (sel.startsWith('#')) return this.attrs.id === sel.slice(1);
    if (!m) return false;
    const [, tag, classes, attrs] = m;
    if (tag && tag.toUpperCase() !== this.tagName) return false;
    if (classes && !classes.split('.').filter(Boolean).every((c) => this.classes.has(c))) return false;
    if (attrs) for (const a of attrs.match(/\[[^\]]+\]/g)) { const [k, v] = a.slice(1, -1).split('='); if (!(k in this.attrs) || (v && this.attrs[k] !== v.replace(/"/g, ''))) return false; }
    return true;
  }
  matches(sel) { return sel.split(',').some((s) => this.matchesOne(s)); }
  closest(sel) { let n = this; while (n && n instanceof El) { if (n.matches(sel)) return n; n = n.parent; } return null; }
  querySelector(sel) { for (const c of this.children) { if (c.matches(sel)) return c; const f = c.querySelector(sel); if (f) return f; } return null; }
  querySelectorAll() { return []; }
  getBoundingClientRect() { return { left: 0, right: 800, top: 0, bottom: 600, height: 600 }; }
  scrollTo(o) { this.scrolled.push(o); this.scrollTop = o.top; }
  focus(o) { FOCUS.push([this, o]); }
}
const FOCUS = [];
const ROOT = new El('div', 'root');
const doc = new El('html'); doc.scrollTop = 0;
let reduce = false;
global.window = global;
global.document = { scrollingElement: doc, documentElement: doc, body: ROOT, addEventListener: (type, fn) => { if (type === 'scroll') global.__scroll = fn; }, querySelector: (s) => ROOT.querySelector(s) };
global.requestAnimationFrame = (fn) => { fn(); return 0; };   // synchronous here (a browser runs it on the next frame)
global.matchMedia = () => ({ matches: reduce });
global.TR = { util: { h: (tag, attrs, ...kids) => { const e = new El(tag, Array.isArray(attrs.class) ? attrs.class.filter(Boolean).join(' ') : attrs.class, {}); for (const [k, v] of Object.entries(attrs)) if (!['class', 'onClick'].includes(k) && v != null) e.attrs[k] = String(v); e.onClick = attrs.onClick; return e; } },
  icon: () => new El('svg'), pages: { ui: { motionOn: () => !reduce } }, i18n: { t: (s) => s } };
vm.runInThisContext(fs.readFileSync(`${WWW}/js/app/backtotop.js`, 'utf8'), { filename: 'backtotop.js' });
const B = TR.backToTop, L = B.logic;

// ---------- thresholds: about one container height down; hidden again near the top (hysteresis)
assert.equal(L.visible(0, 500, false), false);
assert.equal(L.visible(440, 500, false), false, 'not before ~0.9 of the height');
assert.equal(L.visible(460, 500, false), true, 'shown past ~0.9 of the height');
assert.equal(L.visible(200, 500, true), true, 'stays while still well down (no flicker)');
assert.equal(L.visible(100, 500, true), false, 'hidden near the top');
assert.equal(L.visible(1000, 0, false), true, 'a zero height never divides by zero');

// ---------- the right container
const main = ROOT.append(new El('main', 's-main'));
const h1 = main.append(new El('h1'));
const nav = ROOT.append(new El('nav', 'nv', { id: 'studio-navigation' }));
const split = main.append(new El('div', 'split'));
const leftPane = split.append(new El('section', 'pane left')); const leftBody = leftPane.append(new El('div', 'pane-body'));
const rightPane = split.append(new El('section', 'pane right')); const rightBody = rightPane.append(new El('div', 'pane-body'));
const graph = main.append(new El('div', 'ci-scroll'));
const panned = main.append(new El('div', 'cb-x', { 'data-pan': '' }));
assert.equal(L.container(main, document), main, 'the main content area');
assert.equal(L.container(leftBody, document), leftBody, 'a pane scrolls on its own');
assert.equal(L.container(nav, document), null, 'never the navigation');
assert.equal(L.container(graph, document), null, 'never a panning graph canvas (Fit view / Reset view instead)');
assert.equal(L.container(panned, document), null, 'anything marked data-pan is panning');
assert.equal(L.container(new El('div', 'random'), document), null, 'not every scrolling element');
assert.equal(L.container(doc, document), doc, 'the document when it is the scroller');

// ---------- focus target: the heading of the scrolled container
assert.equal(L.focusTarget(main), h1, 'the content heading');
const paneHead = leftBody.append(new El('h2'));
assert.equal(L.focusTarget(leftBody), paneHead, 'a pane: its own heading');
assert.equal(L.focusTarget(rightBody), rightBody, 'no heading: the container itself');
const rightTitle = rightPane.append(new El('div', 'pane-title'));
assert.equal(L.focusTarget(rightBody), rightTitle, 'a pane without a heading inside: its title above the scrolling body');
rightPane.children.pop();
assert.equal(L.behavior(true), 'auto'); assert.equal(L.behavior(false), 'smooth');

// ---------- the listener: one button per container, created on scroll, toggled by class only
main.scrollTop = 600; __scroll({ target: main });
const mainBtn = main.children.find((c) => c.classes.has('btt'));
assert.ok(mainBtn, 'the main area gets its button when it scrolls');
assert.ok(mainBtn.classes.has('is-visible') && mainBtn.tabIndex === 0 && mainBtn.attrs['aria-label'] === 'Back to top' && mainBtn.attrs['data-tip'] === 'Back to top', 'visible, focusable, named, with a tooltip');
leftBody.scrollTop = 900; __scroll({ target: leftBody });
const leftBtn = leftBody.children.find((c) => c.classes.has('btt'));
assert.ok(leftBtn && leftBtn.classes.has('is-visible'), 'the left pane has its own control');
assert.ok(!rightBody.children.some((c) => c.classes.has('btt')), 'the right pane has none until it scrolls');
main.scrollTop = 50; __scroll({ target: main });
assert.ok(!mainBtn.classes.has('is-visible') && mainBtn.tabIndex === -1 && mainBtn.attrs['aria-hidden'] === 'true', 'hidden near the top and out of the tab order');
assert.equal(main.children.filter((c) => c.classes.has('btt')).length, 1, 'never a second button');
graph.scrollTop = 900; __scroll({ target: graph });
assert.ok(!graph.children.some((c) => c.classes.has('btt')), 'no button on a graph canvas');

// ---------- activation scrolls only that container, then focuses its heading without scrolling again
leftBody.scrollTop = 900; FOCUS.length = 0;
leftBtn.onClick({ stopPropagation() {} });
assert.deepEqual(leftBody.scrolled.pop(), { top: 0, behavior: 'smooth' }, 'smooth scroll to the top of the pane');
assert.equal(main.scrolled.length, 0, 'the main area does not move');
assert.equal(rightBody.scrolled.length, 0, 'the other pane does not move');
assert.equal(FOCUS[0][0], paneHead); assert.deepEqual(FOCUS[0][1], { preventScroll: true }, 'focus causes no second scroll');
assert.equal(paneHead.attrs.tabindex, '-1', 'the heading is made focusable');
reduce = true;
main.scrollTop = 900; __scroll({ target: main });
mainBtn.onClick({ stopPropagation() {} });
assert.deepEqual(main.scrolled.pop(), { top: 0, behavior: 'auto' }, 'reduced motion: instant');
console.log('Back to top: thresholds, containers (main, panes, document; not navigation or graph canvases), one button per container, focus without a second scroll and reduced motion passed.');
