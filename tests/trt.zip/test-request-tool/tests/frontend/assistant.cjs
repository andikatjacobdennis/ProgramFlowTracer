/* The simulated assistant in the browser (js/app/assistant.js, js/app/features.js): the AI module is fetched only when the
   flags allow it, replies are rendered as plain text, summaries say when their source changed, conversations are cleared
   on account switch and sign-out, and cancelling keeps the question. No browser needed. */
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const WWW = `${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot`;

// A tiny element tree: h() records tag, attributes and children; text stays text (no HTML is ever parsed).
const h = (tag, attrs, ...kids) => ({ tag, attrs: attrs || {}, kids: kids.flat(Infinity).filter((k) => k != null && k !== false) });
const text = (n) => (n == null ? '' : typeof n === 'string' || typeof n === 'number' ? String(n) : (n.kids || []).map(text).join(''));
const find = (n, pred) => { if (!n || typeof n !== 'object') return null; if (pred(n)) return n; for (const k of n.kids || []) { const f = find(k, pred); if (f) return f; } return null; };
const store = new Map();
global.window = global;
global.sessionStorage = { get length() { return store.size; }, key: (i) => [...store.keys()][i], getItem: (k) => (store.has(k) ? store.get(k) : null), setItem: (k, v) => store.set(k, String(v)), removeItem: (k) => store.delete(k) };
global.addEventListener = () => {};
const scripts = [];
global.document = { addEventListener() {}, querySelector: () => null, createElement: (tag) => ({ tag }), head: { appendChild: (s) => scripts.push(s.src) } };
let flags = {};
global.location = { protocol: 'http:' };
global.fetch = async (url) => ({ ok: true, json: async () => flags });
const avatarCalls = [];
global.TR = {
  util: { h }, icon: (n) => h('i', { 'data-icon': n }), i18n: { t: (s, v) => String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)) },
  pages: { register() {}, addHeaderItem() {}, current: () => 'home', get: () => null, show() {}, ui: { button: (label, icon, onClick, kind, o) => h('button', Object.assign({ onClick }, o), label), when: (x) => String(x) } },
  testRequest: { frame: (c) => c }, app: { refresh() {}, shell: null }, backend: { session: { userId: 'engineer' } },
  ui: { panel: () => ({ el: {}, render() {}, closed: false }) }, notify: { toast() {} },
  avatar: { changed: () => avatarCalls.push('changed'), signOut: () => avatarCalls.push('signOut') },
};

(async () => {
  // ---------- lazy loading: with the AI flags off (the default) nothing AI-related is fetched
  vm.runInThisContext(fs.readFileSync(`${WWW}/js/app/features.js`, 'utf8'), { filename: 'features.js' });
  for (const f of ['ai', 'ai-chat', 'ai-summaries', 'ai-agent']) assert.equal(TR.features.on(f), false, f + ' is off before the server answers');
  assert.equal(TR.features.on('teams'), true, 'other flags keep their on default');
  flags = { ai: false, 'ai-chat': true }; await TR.features.load();
  assert.deepEqual(scripts, [], 'a capability flag without the overall AI flag loads nothing');
  flags = { ai: true }; await TR.features.load();
  assert.deepEqual(scripts, [], 'the overall flag without any capability loads nothing');
  flags = { ai: true, 'ai-chat': true, 'ai-summaries': true, 'ai-agent': true }; await TR.features.load();
  assert.deepEqual(scripts, ['/js/app/assistant.js'], 'the module is loaded once the flags allow it');
  await TR.features.load();
  assert.equal(scripts.length, 1, 'and only once');

  vm.runInThisContext(fs.readFileSync(`${WWW}/js/app/assistant.js`, 'utf8'), { filename: 'assistant.js' });
  const A = TR.assistant;
  assert.equal(A.LABEL, 'Simulated assistant — no AI service connected');

  // ---------- safe rendering: a reply containing markup is shown as text, links only to Help
  const replies = [];
  global.fetch = async (url, init) => { replies.push({ url, body: JSON.parse(init.body) }); return { ok: true, status: 200, json: async () => ({ text: '<img src=x onerror=alert(1)> <script>bad()</script>', confidence: 'likely', citations: [{ kind: 'help', title: 'Evil', reference: 'javascript:alert(1)' }, { kind: 'help', title: 'Glossary', reference: '?view=help&article=glossary' }], actions: [], suggestedQuestions: [] }) }; };
  await A.ask('hello');
  const last = A.AS.messages[A.AS.messages.length - 1];
  assert.equal(last.role, 'assistant');
  let rendered = null;
  TR.ui.panel = (o) => { rendered = o.body(); return { el: { querySelector: () => null, focus() {} }, render() { rendered = o.body(); }, closed: false }; };
  A.open();
  const p = find(rendered, (n) => n.tag === 'p' && text(n).includes('<img'));
  assert.ok(p, 'the reply is a text node');
  assert.equal(p.kids.length, 1); assert.equal(typeof p.kids[0], 'string', 'never parsed as HTML');
  assert.ok(!find(rendered, (n) => n.attrs && 'innerHTML' in n.attrs), 'no innerHTML anywhere');
  assert.ok(!find(rendered, (n) => n.tag === 'a' && /javascript:/.test(n.attrs.href || '')), 'a javascript: reference is not a link');
  assert.ok(find(rendered, (n) => n.tag === 'a' && n.attrs.href === '/?view=help&article=glossary'), 'a Help reference is a link');
  assert.ok(find(rendered, (n) => text(n) === 'Simulated assistant — no AI service connected'), 'the panel carries the label');
  assert.equal(replies[0].url, '/api/v1/assistant/chat');

  // ---------- context exclusion: an excluded kind is not sent
  A.AS.excluded.add('activity');
  await A.ask('again');
  const chats = replies.filter((r) => r.url.endsWith('/chat'));
  assert.equal(chats.length, 2);
  assert.ok(!chats[1].body.include.some((c) => c.kind === 'activity'), 'excluded context is not sent');
  A.AS.excluded.clear();

  // ---------- cancellation keeps the question and says so
  global.fetch = (url, init) => new Promise((res, rej) => init.signal.addEventListener('abort', () => { const e = new Error('aborted'); e.name = 'AbortError'; rej(e); }));
  const pending = A.ask('slow question');
  assert.equal(A.AS.busy, true); A.cancel(); await pending;
  assert.equal(A.AS.busy, false);
  assert.ok(A.AS.messages.some((m) => m.role === 'user' && m.text === 'slow question'), 'the question is kept');
  assert.match(A.AS.messages[A.AS.messages.length - 1].text, /Cancelled/);

  // ---------- structured errors: retryable server errors show Retry
  global.fetch = async () => ({ ok: false, status: 504, json: async () => ({ title: 'assistant_timeout', detail: 'The assistant did not answer in time.', retryable: true }) });
  await A.ask('time out');
  assert.equal(A.AS.error.message, 'The assistant did not answer in time.'); assert.equal(A.AS.error.retryable, true);
  A.open(); A.AS.panel.render();
  assert.ok(find(rendered, (n) => n.tag === 'button' && text(n) === 'Retry'), 'Retry is offered');

  // ---------- conversations are session-scoped and cleared on account switch and sign-out
  assert.ok(store.get('trstudio.engineer.assistant.chat'), 'kept in this tab while signed in');
  TR.avatar.changed();
  assert.equal(store.size, 0, 'account switch clears it'); assert.equal(A.AS.messages.length, 0); assert.deepEqual(avatarCalls, ['changed']);
  store.set('trstudio.engineer.assistant.chat', '[{"role":"user","text":"x"}]'); A.AS.summaries.x = {};
  TR.avatar.signOut();
  assert.equal(store.size, 0, 'sign-out clears it'); assert.deepEqual(A.AS.summaries, {}); assert.deepEqual(avatarCalls, ['changed', 'signOut']);

  // ---------- summaries: labelled, and outdated once the source version moves on
  A.AS.summaries['proposal:workspace'] = { title: 'Proposal (simulated)', sourceVersion: 'rev-1', generatedAt: '2026-10-20T10:00:00Z', statements: [{ section: 'identity', text: 'FH 123456, 2 changes' }, { section: 'next', text: 'Validate' }] };
  const fresh = A.summaryCard('proposal', 'workspace', 'rev-1');
  assert.ok(find(fresh, (n) => text(n) === 'Simulated summary'), 'labelled Simulated summary');
  assert.ok(!find(fresh, (n) => /Outdated/.test(text(n)) && n.attrs.role === 'status'), 'current source: not outdated');
  const old = A.summaryCard('proposal', 'workspace', 'rev-2');
  assert.ok(find(old, (n) => n.attrs.role === 'status' && /Outdated/.test(text(n))), 'newer revision: outdated');
  assert.ok(find(old, (n) => n.tag === 'button' && text(n) === 'Summarize again'), 'can be summarised again');
  assert.equal(text(find(A.summaryCard('activity', 'none', null), (n) => n.tag === 'button')), 'Summarize (simulated)', 'nothing yet: the entry point');

  console.log('assistant: all checks passed');
})().catch((e) => { console.error(e); process.exit(1); });
