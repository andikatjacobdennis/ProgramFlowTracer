/* Spelling check (js/app/spellcheck.js): tokens, what is skipped, misspellings, suggestions and the personal dictionary,
   with the real bundled word list. No browser needed. */
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const WWW = `${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot`;
global.window = global;
global.document = { addEventListener() {}, body: null, documentElement: {} };
global.TR = { util: { h: () => ({}), store: { get: (k, d) => d, set() {} } }, i18n: { t: (s) => s }, prefs: { get: () => true } };
vm.runInThisContext(fs.readFileSync(`${WWW}/js/app/spellcheck.js`, 'utf8'), { filename: 'spellcheck.js' });
const S = TR.spell;
const list = fs.readFileSync(`${WWW}/spell/words-en.txt`, 'utf8').split(/\r?\n/).filter(Boolean);
const dict = new Set(list.concat(S.TERMS)), rank = new Map(list.map((w, i) => [w, i]));
assert(list.length > 50000, 'the bundled list has ' + list.length + ' words');
assert(fs.existsSync(`${WWW}/spell/COPYRIGHT-SCOWL.txt`), 'the word list licence ships with it');

// ---------- tokens and what is skipped
assert.deepEqual(S.tokenize("It's Åsa's draft").map((x) => x.word), ["It's", "Åsa's", 'draft']);
const skip = (text) => S.tokenize(text).filter((tk) => S.shouldCheck(tk, text)).map((tk) => tk.word);
assert.deepEqual(skip('FH 123456 on EMS_24 for VDA via https://example.org/abc and anna@example.org'), ['on', 'for', 'via', 'and'], 'identifiers, ALL CAPS, URLs and e-mail addresses are skipped');
assert.deepEqual(skip('nodeTemplate x'), [], 'camelCase and single letters are skipped');

// ---------- misspellings
const bad = (text, custom = new Set()) => S.check(text, dict, custom).map((x) => x.word);
assert.deepEqual(bad('The vehicle needs a new software package'), [], 'correct prose has no findings');
assert.deepEqual(bad('The vehcile needs a new sofware package'), ['vehcile', 'sofware']);
assert.deepEqual(bad("The engineer's change"), [], "possessives are fine");
assert.deepEqual(bad('Update the chassis via KAX'), [], 'application terms are known');

// ---------- suggestions: closest first, most common first, capitalisation kept
assert.equal(S.suggest('vehcile', dict, rank)[0], 'vehicle');
assert.equal(S.suggest('sofware', dict, rank)[0], 'software');
assert.equal(S.suggest('Recieve', dict, rank)[0], 'Receive', 'keeps a capital letter');
assert(S.suggest('teh', dict, rank).includes('the'));
assert(S.suggest('qzxjvbk', dict, rank).length <= 5, 'at most five suggestions');

// ---------- the personal dictionary
assert.deepEqual(bad('Göteborg depot', new Set(['göteborg'])), [], 'a word in your dictionary is accepted');
assert.deepEqual(bad('Göteborg depot'), ['Göteborg'], 'and only for you');

console.log(`Spelling check: ${list.length} words, skipped identifiers and abbreviations, misspellings, ranked suggestions and the personal dictionary passed.`);
