/* Avatar (js/app/avatar.js): initials, high-density sizes, photo loading and every fallback, a change of account, sign-out,
   fixed dimensions and the accessible trigger. No browser needed. */
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const WWW = `${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot`;
class FakeNode {
  constructor(tag) { this.tag = tag; this.children = []; this.attributes = {}; this.dataset = {}; this.style = {}; this.events = {}; const self = this; this.classList = { _s: new Set(), add(...c) { c.forEach((x) => this._s.add(x)); }, remove(...c) { c.forEach((x) => this._s.delete(x)); }, contains(c) { return this._s.has(c); }, toggle() {} }; this.parentNode = null; }
  set className(v) { String(v).split(/\s+/).filter(Boolean).forEach((c) => this.classList.add(c)); } get className() { return [...this.classList._s].join(' '); }
  appendChild(n) { if (typeof n === 'string') n = Object.assign(new FakeNode('#text'), { text: n }); this.children.push(n); n.parentNode = this; return n; }
  append(...n) { n.forEach((x) => this.appendChild(x)); }
  setAttribute(k, v) { this.attributes[k] = String(v); } getAttribute(k) { return this.attributes[k]; } removeAttribute(k) { delete this.attributes[k]; } hasAttribute(k) { return k in this.attributes; }
  addEventListener(k, v) { this.events[k] = v; }
  get firstChild() { return this.children[0] || null; } get childNodes() { return this.children; }
  get textContent() { return this.children.map((c) => (c.tag === '#text' ? c.text : c.textContent)).join(''); }
  remove() { if (this.parentNode) this.parentNode.children = this.parentNode.children.filter((x) => x !== this); }
  querySelector() { return null; } querySelectorAll() { return []; } focus() {}
}
const walk = (n, out = []) => { out.push(n); (n.children || []).forEach((c) => walk(c, out)); return out; };
global.Node = FakeNode; global.window = global;
global.document = { addEventListener() {}, querySelector: () => null, querySelectorAll: () => [], documentElement: { dataset: {} }, createElement: (t) => new FakeNode(t), createElementNS: (_, t) => new FakeNode(t), createTextNode: (t) => Object.assign(new FakeNode('#text'), { text: t }) };
const revoked = [];
global.URL = { createObjectURL: (b) => 'blob:photo-' + b.id, revokeObjectURL: (u) => revoked.push(u) };
global.localStorage = { getItem: () => null, setItem() {}, removeItem() {} };
global.location = { href: '/' };
let answer = null; const asked = [];
global.fetch = async (url, opts) => { asked.push({ url, opts }); if (answer instanceof Error) throw answer; return answer; };
const load = (n) => vm.runInThisContext(fs.readFileSync(`${WWW}/js/${n}.js`, 'utf8'), { filename: n });
global.TR = {};
load('util'); load('icons');
let refreshes = 0;
TR.app = { refresh: () => { refreshes++; } };
TR.backend = { session: { userId: 'u-meera', displayName: 'Meera Pillai', role: 'Engineer', authentication: 'Password' } };
TR.testRequest = { header: () => new FakeNode('header') };
TR.pages = { get: () => null, show() {} };
load('app/avatar');
const Av = TR.avatar;

// ---------- initials and the person icon
assert.equal(Av.initials('Meera Pillai'), 'MP');
assert.equal(Av.initials('rahul'), 'R');
assert.equal(Av.initials('Ananya   Rao  Iyer'), 'AI', 'first and last name');
assert.equal(Av.initials('Åsa Öberg'), 'ÅÖ', 'letters in any script');
assert.equal(Av.initials('  '), ''); assert.equal(Av.initials('123 456'), '', 'no letters: no initials');
TR.backend.session.displayName = '';
assert(walk(Av.avatar(32)).some((n) => n.tag === 'svg'), 'no usable name: a neutral person icon');
TR.backend.session.displayName = 'Meera Pillai';

// ---------- high-density sizes
assert.equal(Av.sizeFor(1), 48); assert.equal(Av.sizeFor(1.5), 96); assert.equal(Av.sizeFor(2), 96); assert.equal(Av.sizeFor(3), 240); assert.equal(Av.sizeFor(undefined), 48);
global.devicePixelRatio = 2;

(async () => {
  // ---------- success: the photo shows, cropped and fixed in size; nothing in the URL but size and a user tag
  answer = { ok: true, status: 200, blob: async () => ({ id: 'meera' }) };
  await Av.load();
  assert.equal(Av.A.status, 'ok'); assert.equal(Av.A.url, 'blob:photo-meera');
  assert(/^\/api\/v1\/me\/photo\?size=96&u=[a-z0-9]+$/.test(asked.at(-1).url), 'size for a 2× screen, no token in the URL: ' + asked.at(-1).url);
  let el = Av.avatar(32);
  assert.equal(el.style.width, '32px'); assert.equal(el.style.height, '32px'); assert.equal(el.attributes['aria-hidden'], 'true', 'decorative: the trigger carries the name');
  const img = walk(el).find((n) => n.tag === 'img');
  assert(img && img.attributes.alt === '' && img.attributes.src === 'blob:photo-meera');
  assert(walk(el).some((n) => n.classList && n.classList.contains('av-initials')), 'initials stay underneath, so a failed decode never leaves a blank');
  assert.equal(Av.avatar(48).style.width, '48px', 'menu avatar is 48 × 48');
  // A decode failure falls back at once.
  img.events.error(); assert.equal(Av.A.status, 'error'); assert(revoked.includes('blob:photo-meera'));

  // ---------- missing photo, permission denied, network failure
  for (const [res, status] of [[{ ok: true, status: 204 }, 'none'], [{ ok: false, status: 404 }, 'none'], [{ ok: false, status: 403 }, 'forbidden'], [{ ok: false, status: 502 }, 'error'], [new TypeError('Failed to fetch'), 'error']]) {
    Av.clear(); answer = res; await Av.load();
    assert.equal(Av.A.status, status, 'fallback for ' + (res.status || res.message));
    el = Av.avatar(32);
    assert(!walk(el).some((n) => n.tag === 'img'), 'no image on ' + status);
    assert.equal(el.textContent, 'MP', 'initials on ' + status);
    assert.equal(el.style.width, '32px', 'same size on ' + status);
  }

  // ---------- account switching: the old photo is revoked and never shown for the new account
  Av.clear(); answer = { ok: true, status: 200, blob: async () => ({ id: 'meera2' }) }; await Av.load();
  const firstTag = asked.at(-1).url.split('u=')[1];
  TR.backend.session = { userId: 'u-rahul', displayName: 'Rahul Iyer', role: 'Reviewer', authentication: 'Password' };
  Av.changed();
  assert.equal(Av.A.url, null, 'the previous user’s photo is gone at once'); assert(revoked.includes('blob:photo-meera2'));
  answer = { ok: false, status: 404 }; await Av.load();
  assert.notEqual(asked.at(-1).url.split('u=')[1], firstTag, 'a different cache tag per account');
  assert.equal(Av.avatar(32).textContent, 'RI');
  // A late answer for the previous account is dropped.
  Av.clear(); TR.backend.session.userId = 'u-rahul';
  let release; answer = new Promise((r) => { release = r; });
  const pending = Av.load(); TR.backend.session.userId = 'u-other'; Av.changed();
  release({ ok: true, status: 200, blob: async () => ({ id: 'late' }) }); await pending;
  assert.notEqual(Av.A.url, 'blob:photo-late', 'an answer for an earlier account is never shown');

  // ---------- sign-out clears everything: the app's own sign-in ends the session through TR.auth; organisation sign-in
  // goes to its sign-out address
  const menuLabels = () => walk(TR.testRequest.header()).filter((n) => n.attributes && n.attributes.role === 'menuitem').map((n) => n.textContent);
  Av.clear(); TR.backend.session = { userId: 'u-meera', displayName: 'Meera Pillai', authentication: 'Password' };
  let signedOut = 0; TR.auth = { signOut: () => { signedOut++; } };
  answer = { ok: true, status: 200, blob: async () => ({ id: 'bye' }) }; await Av.load();
  Av.A.open = true; assert(menuLabels().includes('Sign out'), 'Password sign-in: the menu offers Sign out');
  assert(!menuLabels().some((l) => /switch|demo/i.test(l)), 'no account switching');
  Av.A.open = false;
  answer = { ok: true, status: 204 }; await Av.signOut();
  assert.equal(Av.A.url, null); assert(revoked.includes('blob:photo-bye')); assert.equal(signedOut, 1, 'TR.auth.signOut ends the session');
  assert(!asked.some((a) => /\/demo\//.test(a.url)), 'no demo endpoint is called');
  TR.backend.session = { userId: 'u-meera', displayName: 'Meera Pillai', authentication: 'Jwt', signOutUrl: '/signout-oidc' };
  Av.A.open = true; assert(menuLabels().includes('Sign out'), 'Jwt with a sign-out address: Sign out'); Av.A.open = false;
  await Av.signOut(); assert.equal(location.href, '/signout-oidc', 'Jwt: goes to the sign-out address'); assert.equal(signedOut, 1);
  TR.backend.session = { userId: 'u-meera', displayName: 'Meera Pillai', authentication: 'Jwt' };
  Av.A.open = true; assert(!menuLabels().includes('Sign out'), 'Jwt without a sign-out address: no Sign out'); Av.A.open = false;
  TR.backend.session = { userId: 'u-meera', displayName: 'Meera Pillai', authentication: 'Password' };

  // ---------- the trigger: a keyboard-reachable button with a clear name, popup state and controls
  Av.clear(); answer = { ok: false, status: 404 }; await Av.load();
  const header = TR.testRequest.header();
  const trigger = walk(header).find((n) => n.classList && n.classList.contains('av-trigger'));
  assert.equal(trigger.tag, 'button');
  assert.equal(trigger.attributes['aria-label'], 'Open account menu for Meera Pillai');
  assert.equal(trigger.attributes['aria-haspopup'], 'menu'); assert.equal(trigger.attributes['aria-expanded'], 'false'); assert.equal(trigger.attributes['aria-controls'], 'av-menu');
  trigger.events.click({ stopPropagation() {} });
  const open = TR.testRequest.header();
  const menu = walk(open).find((n) => n.attributes && n.attributes.role === 'menu');
  assert(menu, 'the menu opens');
  assert(walk(menu).filter((n) => n.attributes && n.attributes.role === 'menuitem').length >= 2, 'menu items are there with or without a photo');
  assert.equal(walk(open).find((n) => n.classList && n.classList.contains('av-trigger')).attributes['aria-expanded'], 'true');

  console.log('Avatar: initials and person icon, high-density sizes, photo, missing photo, permission denial, network failure, decode failure, a change of account, sign-out (Password and Jwt), fixed sizes and the accessible trigger passed.');
})().catch((e) => { console.error(e); process.exit(1); });
