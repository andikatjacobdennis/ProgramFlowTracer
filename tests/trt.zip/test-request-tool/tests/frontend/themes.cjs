/* Theme selection rules shared by the application (testrequest.js) and the UI guide (guide/theme.js):
   saved choice (Auto by default), retired themes mapped to Light/Dark Charcoal; Auto follows the OS colour-scheme preference. */
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const WWW = `${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot`;

class FakeNode {
  constructor(tag) { this.tag = tag; this.children = []; this.attributes = {}; this.dataset = {}; this.style = {}; this.events = {}; this.classList = { add() {}, remove() {} }; }
  appendChild(n) { this.children.push(n); n.parentNode = this; return n; }
  setAttribute(k, v) { this.attributes[k] = v; } getAttribute(k) { return this.attributes[k]; }
  addEventListener(k, v) { this.events[k] = v; }
  get firstChild() { return this.children[0] || null; }
  removeChild(n) { this.children = this.children.filter((x) => x !== n); }
  querySelector() { return null; } querySelectorAll() { return []; } focus() {} scrollIntoView() {}
}

/** Fresh global context with a given saved theme, OS preference and query string. */
function context(saved, dark = false, search = '') {
  const store = saved === undefined ? {} : { 'trstudio.theme': JSON.stringify(saved) };
  const root = new FakeNode('html');
  const ctx = {
    console, URLSearchParams, crypto: require('crypto').webcrypto,
    localStorage: { getItem: (k) => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = v; }, removeItem: (k) => { delete store[k]; } },
    matchMedia: (q) => ({ matches: dark && q.includes('dark') }),
    location: { search, href: 'http://localhost/' + search }, history: { replaceState() {} },
    document: { addEventListener() {}, documentElement: root, createElement: (t) => new FakeNode(t), createElementNS: (_, t) => new FakeNode(t), createTextNode: (t) => Object.assign(new FakeNode('#text'), { text: t }), getElementById: () => new FakeNode('div') },
    Node: FakeNode, setTimeout, clearTimeout, Promise,
  };
  ctx.window = ctx; vm.createContext(ctx);
  return { ctx, store, root };
}

function appTheme(saved, dark) {
  const { ctx, store, root } = context(saved, dark);
  for (const n of ['util', 'enums', 'chassis', 'model', 'mockdata', 'xml', 'engine', 'server', 'ui', 'productvm', 'editors', 'pane', 'request', 'shell', 'compare', 'vcads', 'icons', 'testrequest'])
    vm.runInContext(fs.readFileSync(`${WWW}/js/${n}.js`, 'utf8'), ctx, { filename: n });
  return { theme: root.dataset.theme, choice: root.dataset.themeChoice, saved: JSON.parse(store['trstudio.theme']) };
}

function guideTheme(saved, dark, search) {
  const { ctx, root } = context(saved, dark, search);
  root.setAttribute = (k, v) => { root.attributes[k] = v; };
  vm.runInContext(fs.readFileSync(`${WWW}/guide/theme.js`, 'utf8'), ctx, { filename: 'theme.js' });
  return { theme: root.attributes['data-theme'], choice: root.attributes['data-theme-choice'] };
}

// [saved choice, OS dark, palette shown, choice stored]. No or unknown choice means Auto, which follows the OS.
for (const [saved, dark, palette, choice] of [
  [undefined, false, 'charcoal-light', 'auto'], [undefined, true, 'charcoal', 'auto'],
  ['auto', false, 'charcoal-light', 'auto'], ['auto', true, 'charcoal', 'auto'],
  ['clay', true, 'charcoal-light', 'charcoal-light'], ['light', true, 'charcoal-light', 'charcoal-light'], ['night', false, 'charcoal', 'charcoal'],
  ['charcoal', false, 'charcoal', 'charcoal'], ['charcoal-light', true, 'charcoal-light', 'charcoal-light'], ['unknown', false, 'charcoal-light', 'auto'],
]) {
  const app = appTheme(saved, dark);
  assert.equal(app.theme, palette, `app: saved ${saved}, dark OS ${dark}`);
  assert.equal(app.choice, choice, `app: choice for ${saved}`);
  assert.equal(app.saved, choice, `app stores the migrated choice for ${saved}`);
  const guide = guideTheme(saved, dark, '');
  assert.equal(guide.theme, palette, `guide: saved ${saved}, dark OS ${dark}`);
  assert.equal(guide.choice, choice, `guide: choice for ${saved}`);
}
assert.equal(guideTheme('charcoal', false, '?theme=charcoal-light').theme, 'charcoal-light', 'guide ?theme= wins');
assert.equal(guideTheme('charcoal', true, '?theme=auto').theme, 'charcoal', 'guide ?theme=auto follows the OS');
console.log('Theme selection (Auto, Light/Dark Charcoal, retired-theme migration, OS preference) matches between the application and the UI guide.');
