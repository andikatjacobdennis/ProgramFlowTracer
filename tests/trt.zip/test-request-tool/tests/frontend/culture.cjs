/* Culture (js/app/culture.js): account country default, UTC fallback, system settings, live switching, formats and flags. */
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const WWW = `${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot`;
class FakeNode {
  constructor(tag) { this.tag = tag; this.children = []; this.attributes = {}; this.dataset = {}; this.style = {}; this.events = {}; this.classList = { add: (c) => { this.attributes.class = ((this.attributes.class || '') + ' ' + c).trim(); }, remove() {}, toggle() {} }; }
  appendChild(n) { this.children.push(n); n.parentNode = this; return n; }
  setAttribute(k, v) { this.attributes[k] = v; } getAttribute(k) { return this.attributes[k]; }
  addEventListener(k, v) { this.events[k] = v; }
  get firstChild() { return this.children[0] || null; }
  removeChild(n) { this.children = this.children.filter((x) => x !== n); }
  querySelector() { return null; } querySelectorAll() { return []; } focus() {} scrollIntoView() {}
}
const storage = new Map();
global.Node = FakeNode; global.window = global; global.crypto = require('crypto').webcrypto;
global.localStorage = { getItem: (k) => (storage.has(k) ? storage.get(k) : null), setItem: (k, v) => storage.set(k, v), removeItem: (k) => storage.delete(k) };
global.document = { addEventListener() {}, documentElement: { dataset: {} }, createElement: (t) => new FakeNode(t), createElementNS: (_, t) => new FakeNode(t), createTextNode: (t) => Object.assign(new FakeNode('#text'), { text: t }), getElementById: () => new FakeNode('div') };
global.location = { search: '', href: 'http://localhost/' }; global.history = { replaceState() {} };
Object.defineProperty(globalThis, 'navigator', { value: { language: 'pt-BR' }, configurable: true });

const load = (n) => vm.runInThisContext(fs.readFileSync(`${WWW}/js/${n}.js`, 'utf8'), { filename: n });
['util', 'enums', 'chassis', 'model', 'mockdata', 'xml', 'engine', 'server', 'ui', 'productvm', 'editors', 'pane', 'request', 'shell', 'compare', 'vcads', 'icons', 'testrequest'].forEach(load);
TR.app.refresh = () => {}; TR.app.refreshSoon = () => {}; TR.app.navigate = () => {};
TR.app.shell.left = new TR.Pane('left'); TR.app.shell.right = new TR.Pane('right');
TR.ui.summary = { render: () => new FakeNode('summary'), clearAll() {}, displayResult() {}, addInformation() {}, addWarning() {}, addError() {} };
TR.backend = { session: { userId: 'u1', displayName: 'Priya Sharma', role: 'Engineer', country: 'IN', canSimulate: true }, start: (init) => init() };
load('experience');
['core', 'i18n', 'ml', 'shortcuts', 'culture', 'timezones', 'personas', 'settings'].forEach((n) => load('app/' + n));

const C = TR.culture, X = TR.experience, root = document.documentElement;
const walk = (n) => [n, ...((n && n.children) || []).flatMap(walk)];
const strings = (n) => walk(n).filter((x) => x.tag === '#text').map((x) => x.text).join(' ');
const at = '2026-10-19T08:39:00Z';

// ---------- the account country is the default
assert.deepEqual(C.active(), { country: 'IN', language: 'en-IN', timeZone: 'Asia/Kolkata', currency: 'INR', dateFormat: 'medium', hourCycle: 'auto' });
assert.equal(C.zoneName(), 'IST');
assert.equal(C.format.dateTime(at), '19 Oct 2026, 2:09 pm IST', 'India shows IST');
assert.equal(C.format.money(123456.78), '₹1,23,456.78', 'India shows rupees with Indian digit grouping');
assert.equal(TR.pages.ui.when(at), C.format.dateTime(at), 'every page date uses the culture');
assert.equal(new Date(at).toLocaleString(), '19/10/2026, 2:09:00 pm', 'older screens calling toLocaleString() get the culture too');
assert.equal(new Date(at).toLocaleString('en-US', { timeZone: 'UTC' }), '10/19/2026, 8:39:00 AM', 'an explicit locale is left alone');

// ---------- no country on the account: the nearest supported country to the computer's region, else UTC
TR.backend.session.country = null;
assert.equal(C.active().country, 'BR', 'pt-BR computer: Brazil');
assert.equal(C.active().timeZone, 'America/Sao_Paulo');
assert.equal(C.nearest('AT'), 'DE', 'Austria uses the nearest supported country, Germany');
assert.equal(C.nearest('NO'), 'SE', 'Norway: Sweden');
assert.equal(C.nearest('ZZ'), '', 'no nearby country: none');
Object.defineProperty(globalThis, 'navigator', { value: { language: 'en' }, configurable: true });
assert.equal(C.active().timeZone, 'UTC', 'no region and no country: UTC');
assert.equal(C.format.dateTime(at), '2026-10-19 08:39 UTC', 'UTC uses ISO dates and a 24-hour clock');
assert.equal(C.format.money(5), '5.00', 'no currency: plain amount');
TR.backend.session.country = 'ZZ';
assert.equal(C.active().country, '', 'an unsupported account country falls back to UTC');
Object.defineProperty(globalThis, 'navigator', { value: { language: 'pt-BR' }, configurable: true });
TR.backend.session.country = 'IN';

// ---------- changing it
C.change('country', 'SE');
assert.equal(TR.prefs.get('cultureMode'), 'custom');
assert.deepEqual([C.active().language, C.active().timeZone, C.active().currency], ['sv-SE', 'Europe/Stockholm', 'SEK'], 'a country brings its own defaults');
C.change('language', 'en-SE');
assert.equal(C.active().country, 'SE', 'changing the language keeps the country');
C.change('hourCycle', 'h12');
assert(/(am|pm)$/i.test(C.format.time(at)), 'a 12-hour clock');
C.change('country', 'IN'); C.change('language', 'hi-IN');
assert(C.format.date(at).includes('2026') && C.format.dateTime(at).endsWith('IST'));

// ---------- system settings
C.useSystem();
assert.equal(C.active().language, 'pt-BR');
assert.equal(C.active().country, 'BR', 'the region of the system language picks the country');
assert.equal(C.active().currency, 'BRL');
C.useAccount();
assert.equal(C.active().language, 'en-IN', 'back to the account default');

// ---------- quick switch between several cultures, live
C.use(C.forCountry('SE')); C.addQuick(); C.addQuick();
C.use(C.forCountry('US')); C.addQuick();
assert.equal(C.quick().length, 2, 'the same culture is kept once');
assert.deepEqual(C.choices().map((c) => c.id + ':' + c.profile.country), ['account:IN', 'custom:SE', 'custom:US', 'system:BR']);
assert(C.isCurrent(C.choices()[2]));
C.cycle(); assert.equal(TR.prefs.get('cultureMode'), 'system', 'cycle moves to the next culture');
C.cycle(); assert.equal(TR.prefs.get('cultureMode'), 'account', 'and wraps round');
C.cycle(); assert.equal(C.active().country, 'SE');
C.removeQuick(C.forCountry('US'));
assert.equal(C.quick().length, 1);

// ---------- invalid stored values never break formatting
assert.deepEqual(C.normalise({ country: 'XX', language: '!!', timeZone: 'Mars/Base', currency: 'rupee', dateFormat: 'odd', hourCycle: 'h99' }), { country: '', language: 'en-GB', timeZone: 'UTC', currency: '', dateFormat: 'medium', hourCycle: 'auto' });

// ---------- flags
for (const c of C.COUNTRIES) {
  assert(C.FLAGS.has(c.code), 'flag for ' + c.code);
  const f = C.flag(c.code);
  assert.equal(f.attributes['aria-label'], c.name + ' flag');
  const img = walk(f).find((n) => n.tag === 'img');
  assert(img && img.attributes.src === '/flags/' + c.code.toLowerCase() + '.svg', 'the exact flag file for ' + c.code);
  assert(require('fs').existsSync(require('path').join(__dirname, '../../src/Volvo.TestRequestTool.Web/wwwroot/flags/' + c.code.toLowerCase() + '.svg')), 'flag file exists for ' + c.code);
}
// Each flag file is the Wikipedia (Wikimedia Commons) SVG at its official proportion, recorded in SOURCES.txt, and is shown
// at that proportion: the img keeps the file's height:width instead of a common 4:3 box.
{
  const fs = require('fs'), path = require('path'), dir = path.join(__dirname, '../../src/Volvo.TestRequestTool.Web/wwwroot/flags');
  const sources = fs.readFileSync(path.join(dir, 'SOURCES.txt'), 'utf8');
  for (const [code, [rh, rw]] of Object.entries(C.FLAG_RATIO)) {
    const svgText = fs.readFileSync(path.join(dir, code.toLowerCase() + '.svg'), 'utf8');
    const vb = svgText.match(/<svg[^>]*viewBox\s*=\s*"([^"]+)"/);
    assert(vb, code + ': the flag has a viewBox so it scales');
    const [, , w, hh] = vb[1].trim().split(/[\s,]+/).map(Number);
    assert(Math.abs(hh / w - rh / rw) < 0.002, `${code}: file proportion ${hh}:${w} is the official ${rh}:${rw}`);
    assert(!/<script|\son[a-z]+\s*=|foreignObject|<!ENTITY/i.test(svgText), code + ': no script, handlers or entities');
    assert(!/(?:href|src)\s*=\s*["'](?!#)/i.test(svgText), code + ': no external references');
    assert(sources.includes(code.toLowerCase() + '.svg') && /Public domain/.test(sources), code + ': source and licence recorded');
    const img = C.flag(code, 24).children.find((k) => k.tag === 'img' || k.tagName === 'IMG' || (k.attributes && k.attributes.src));
    const iw = Number(img.attributes.width), ih = Number(img.attributes.height);
    assert.equal(ih, 16, code + ': every flag has the same height');
    assert(Math.abs(iw - Math.round((16 * rw) / rh)) <= 0, `${code}: shown ${iw}×${ih}, its own proportion`);
  }
  assert.deepEqual(C.flagBox('US', 24), { width: 30, height: 16 }, 'the United States flag is 10:19');
  assert.deepEqual(C.flagBox('SE', 24), { width: 26, height: 16 }, 'Sweden is 5:8');
  assert.deepEqual(C.flagBox('BE', 24), { width: 18, height: 16 }, 'Belgium is 13:15');
}
assert(String(C.flag('').className + ' ' + C.flag('').attributes.class).includes('is-globe'), 'no country shows a globe');

// ---------- Settings: Language and region
X.page = 'settings';
const SP = TR.settingsPage;
let page = TR.testRequest.workspace();
assert(strings(page).includes('Language and region'));
const countryButtons = walk(page).filter((n) => n.attributes.role === 'radio' && String(n.className).includes('cu-country'));
assert.equal(countryButtons.length, C.COUNTRIES.length + 1, 'every supported country plus Not set (UTC)');
countryButtons.find((b) => strings(b).includes('Japan')).events.click();
assert.equal(C.active().timeZone, 'Asia/Tokyo', 'choosing a flag switches the culture');
SP.state.query = 'ist';
assert(SP.visibleSettings().some((s) => s.id === 'timeZone'), 'search finds the time zone setting by IST');
SP.state.query = 'rupee';
assert.deepEqual(SP.visibleSettings().map((s) => s.id), ['currency']);
SP.state.query = '';
page = TR.testRequest.workspace();
assert(strings(page).includes('¥') || strings(page).includes('￥'), 'the preview shows money in the chosen currency');

console.log('Culture: account country default, UTC fallback, country defaults, system settings, quick switch, formats, flags and Language and region settings passed.');
