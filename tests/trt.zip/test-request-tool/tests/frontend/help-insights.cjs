/* Help Center, Asha, first steps, keyboard shortcuts, the introduction tour, vehicle Insights and the fleet Dashboard. */
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const WWW = `${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot`;
class FakeNode {
  constructor(tag) { this.tag = tag; this.children = []; this.attributes = {}; this.dataset = {}; this.style = {}; this.events = {}; this.classList = { add() {}, remove() {}, toggle() {} }; }
  appendChild(n) { this.children.push(n); n.parentNode = this; return n; }
  setAttribute(k, v) { this.attributes[k] = v; } getAttribute(k) { return this.attributes[k]; }
  addEventListener(k, v) { this.events[k] = v; }
  get firstChild() { return this.children[0] || null; }
  removeChild(n) { this.children = this.children.filter((x) => x !== n); }
  querySelector() { return null; } querySelectorAll() { return []; } focus() {} scrollIntoView() {}
}
const storage = new Map();
global.Node = FakeNode; global.window = global; global.crypto = require('crypto').webcrypto;
global.localStorage = { getItem: (k) => (storage.has(k) ? storage.get(k) : null), setItem: (k, v) => storage.set(k, v), removeItem: (k) => storage.delete(k) };
const listeners = {};
global.document = { addEventListener: (k, fn) => { (listeners[k] = listeners[k] || []).push(fn); }, documentElement: { dataset: {} }, createElement: (t) => new FakeNode(t), createElementNS: (_, t) => new FakeNode(t), createTextNode: (t) => Object.assign(new FakeNode('#text'), { text: t }), getElementById: () => new FakeNode('div') };
global.location = { search: '', href: 'http://localhost/' }; global.history = { replaceState() {} };
global.fetch = async () => ({ ok: false, json: async () => ({}) });

const load = (n) => vm.runInThisContext(fs.readFileSync(`${WWW}/js/${n}.js`, 'utf8'), { filename: n });
['util', 'enums', 'chassis', 'model', 'mockdata', 'xml', 'engine', 'server', 'ui', 'productvm', 'editors', 'pane', 'request', 'shell', 'compare', 'vcads', 'icons', 'testrequest'].forEach(load);
TR.app.refresh = () => {}; TR.app.refreshSoon = () => {}; TR.app.navigate = () => {};
TR.app.shell.left = new TR.Pane('left'); TR.app.shell.right = new TR.Pane('right');
TR.ui.summary = { render: () => new FakeNode('summary'), clearAll() {}, displayResult() {}, addInformation() {}, addWarning() {}, addError() {} };
TR.backend = { session: { userId: 'u1', displayName: 'Priya Sharma', role: 'Engineer', country: 'IN', canSimulate: true }, start: (init) => init() };
load('experience');
['core', 'i18n', 'ml', 'shortcuts', 'culture', 'timezones', 'settings', 'history-graph', 'insights', 'vehicle', 'dashboard', 'activity', 'about', 'personas', 'help-articles', 'help-scenarios', 'help', 'tour'].forEach((n) => load('app/' + n));

const X = TR.experience;
const walk = (n) => [n, ...((n && n.children) || []).flatMap(walk)];
const strings = (n) => walk(n).filter((x) => x.tag === '#text').map((x) => x.text).join(' ');
const key = (k, o = {}) => listeners.keydown.forEach((fn) => fn(Object.assign({ key: k, target: { tagName: 'BODY' }, preventDefault() {} }, o)));

// ---------- Help Center
const { TOPICS, ARTICLES } = TR.helpContent;
assert(ARTICLES.every((a) => TOPICS.some((t) => t.id === a.topic)), 'every article belongs to a topic');
assert(ARTICLES.every((a) => (a.related || []).every((id) => ARTICLES.some((b) => b.id === id))), 'related articles exist');
const actions = ARTICLES.flatMap((a) => a.sections.flatMap((s) => s.actions || []));
assert(actions.every((x) => typeof TR.help.ACTIONS[x.run] === 'function'), 'every Try it button has an action');
assert.equal(TR.help.find('time zone')[0].id, 'region', 'searching in plain words finds the right article first');
assert(TR.help.find('kit').some((a) => a.id === 'kit'));
assert.deepEqual(TR.help.find('zzzz'), []);
X.page = 'help';
let page = TR.testRequest.workspace();
assert(strings(page).includes('How can we help you?') && strings(page).includes('Browse help topics'), 'Help home');
assert(strings(page).includes('Take the introduction tour'));
assert(walk(page).some((n) => n.tag === 'svg' && String(n.attributes.class).includes('hp-persona')), 'Asha is on the Help home page');
TR.help.H.query = 'IST';
page = TR.testRequest.workspace();
assert(strings(page).includes('result') && walk(page).some((n) => n.tag === 'mark'), 'search results with marked words');
TR.help.H.query = 'qqqq';
page = TR.testRequest.workspace();
assert(walk(page).some((n) => String(n.attributes.class).includes('mood-think')), 'Asha thinks when nothing matches');
TR.help.H.query = ''; TR.help.H.article = 'scenarios-to-try';
page = TR.testRequest.workspace();
assert(strings(page).includes('16.3.1 TECU') && strings(page).includes('Related articles'), 'article with steps and related articles');
assert.deepEqual(TR.pages.crumbs().map((c) => c.label), ['Home', 'Help', 'Expert tools and sample data', 'Scenarios to try']);
TR.help.H.article = 'shortcuts';
assert(strings(TR.testRequest.workspace()).includes('Go to Vehicle'), 'the shortcuts article lists the registered shortcuts');
TR.help.H.article = '';
assert.equal(typeof TR.shellActions.guidePopup, 'function');

// ---------- first steps
let list = TR.help.checklist(false);
assert(strings(list).includes('Your first steps') && strings(list).includes('0 of 6 done'));
const compact = TR.help.checklist(true);
assert.equal(compact.tag, 'details', 'Home onboarding is an optional disclosure');
assert.equal(compact.attributes.open, undefined, 'Home onboarding starts collapsed');
assert.equal(compact.children[0].tag, 'summary', 'disclosure has a keyboard accessible summary');
assert(strings(compact.children[0]).includes('0 of 6 done'), 'progress is visible without expanding');
TR.help.complete('history');
assert(strings(TR.help.checklist(false)).includes('1 of 6 done'), 'steps stay done');
TR.prefs.set('firstSteps', false);
assert.equal(TR.help.checklist(false), null, 'the checklist can be hidden');
TR.prefs.set('firstSteps', true);

// ---------- Asha
for (const mood of ['wave', 'think', 'cheer']) {
  const svg = TR.help.persona(mood, 100);
  assert(String(svg.attributes.class).includes('mood-' + mood));
  assert(walk(svg).some((n) => String(n.attributes.class).includes('hp-arm')) && walk(svg).some((n) => String(n.attributes.class).includes('hp-eyes')), 'Asha can wave and blink');
}

// ---------- keyboard shortcuts
assert.equal(TR.shortcuts.token({ key: 'C', altKey: true, shiftKey: true }), 'alt+shift+c');
assert.equal(TR.shortcuts.token({ key: '?', shiftKey: true }), '?');
assert.equal(TR.shortcuts.token({ key: 'ArrowRight', altKey: true }), 'alt+arrowright');
const keys = TR.shortcuts.list().map((s) => s.keys);
for (const k of ['?', 'n', 'g h', 'g d', 'g v', 'g s', 'g i', 'w', 'j', 'k', ']', '[']) assert(keys.includes(k), 'shortcut ' + k);
X.page = 'help';
key('g'); key('s');
assert.equal(X.page, 'settings', 'g then s opens Settings');
key('g'); key('d');
assert.equal(X.page, 'dashboard', 'g then d opens the Dashboard');
const theme = TR.testRequest.theme; key('t');
assert.notEqual(TR.testRequest.theme, theme, 't switches the theme');
key('m'); assert.equal(TR.prefs.get('motion'), 'off', 'm turns motion off'); key('m');
X.page = 'settings'; key('g', { target: { tagName: 'INPUT' } }); key('h', { target: { tagName: 'INPUT' } });
assert.equal(X.page, 'settings', 'shortcuts never fire while typing');

// ---------- Insights for one vehicle
assert.equal(TR.insights.weekDate('202630').toISOString().slice(0, 10), '2026-07-20', 'ISO week 30 of 2026 starts on Monday 20 July');
const now = new Date('2026-10-19T12:00:00Z');
const current = { nodes: [{ name: 'EMS', versionName: 'EMS_3' }, { name: 'TECU', versionName: 'TECU_2' }] };
const entries = [
  { id: 'rev-2', kind: 'VdaCommit', lane: 'main', at: '2026-09-01T10:00:00Z', actor: { name: 'Rahul Iyer' }, title: 'VDA revision 2', changes: [{ node: 'EMS', kind: 'Software', from: 'EMS_2', to: 'EMS_3' }] },
  { id: 's1', kind: 'Simulation', lane: 'proposal', mergedInto: 'rev-2', at: '2026-09-01T09:00:00Z', actor: { name: 'Me' }, title: 'Simulation', changes: [] },
  { id: 'workshop', kind: 'Workshop', lane: 'main', at: '2025-08-01T10:00:00Z', actor: { name: 'Kavya Menon' }, title: 'Workshop', changes: [{ node: 'EMS', kind: 'Software', from: 'EMS_1', to: 'EMS_2' }, { node: 'TECU', kind: 'Software', from: 'TECU_1', to: 'TECU_2' }] },
  { id: 'built', kind: 'Built', lane: 'main', at: '2025-03-14T10:00:00Z', actor: { name: 'Factory' }, title: 'Built', changes: [] },
];
const roadmap = { nodes: [
  { node: 'EMS', upcoming: [] },
  { node: 'TECU', upcoming: [{ versionName: 'TECU_3', status: 'Released', introductionWeek: '202630', blockers: [] }, { versionName: 'TECU_4', status: 'In progress', introductionWeek: '202650', blockers: ['Needs ECU hardware 1'] }] },
] };
const m = TR.insights.model({ entries, built: { nodes: [{ name: 'EMS', versionName: 'EMS_1' }, { name: 'TECU', versionName: 'TECU_1' }] }, builtAt: '2025-03-14T10:00:00Z', roadmap, current, now });
assert.deepEqual(m.periods.EMS.map((p) => p.version), ['EMS_1', 'EMS_2', 'EMS_3'], 'the timeline replays every version since the build');
assert.deepEqual(m.periods.TECU.map((p) => p.version), ['TECU_1', 'TECU_2']);
assert.equal(m.periods.EMS[2].to, null, 'the current version is still running');
assert.deepEqual(m.counts, { current: 1, update: 1, blocked: 0, total: 2 });
assert.equal(m.waiting.length, 1, 'TECU_3 was released in July but is not installed');
assert.equal(m.nextUpdate.versionName, 'TECU_3');
assert.deepEqual(m.perNode, { EMS: 2, TECU: 1 });
assert.equal(m.simulations, 1); assert.equal(m.committed, 1);
assert.equal(m.longest.node, 'TECU', 'TECU has run its version longest');
const cards = TR.insights.cards(m).map((c) => c.title);
assert(cards.includes('1 of 2 computers are up to date') && cards.some((t) => t.includes('not installed')) && cards.includes('Next step: TECU_3'));
const view = TR.insights.render({ entries, built: null, builtAt: '2025-03-14T10:00:00Z', roadmap, current, onEntry() {}, onNode() {} });
assert(strings(view).includes('Software timeline') && strings(view).includes('Activity') && strings(view).includes('Most changed'));

// ---------- Fleet dashboard (the server sends the per-vehicle rows from /api/v1/fleet)
const fleet = {
  rows: [
    { id: 'FH|1', label: 'FH 1', t3: true, counts: { current: 1, update: 1, blocked: 0, total: 2 }, waiting: 1 },
    { id: 'FH|2', label: 'FH 2', t3: false, counts: { current: 3, update: 0, blocked: 0, total: 3 }, waiting: 0 },
  ],
  pipeline: { 'In progress': { total: 1, blocked: 1 } }, packs: [{ name: 'SP 1', Available: ['FH 1'], 'Already on it': ['FH 2'] }],
  commits: 1, commits90: 1, people: [['Kavya Menon', 2], ['Rahul Iyer', 1]], days: {}, entries: 2,
};
const requests = [{ kind: 'Software', createdAt: '2026-10-01T10:00:00Z', outcomes: [{ issues: [], limitedValidation: false }] }, { kind: 'Software', createdAt: '2026-10-02T10:00:00Z', outcomes: [{ issues: [{ severity: 0 }] }] }];
const d = TR.dashboard.summarise(fleet, requests, now);
assert.equal(d.vehicles, 2); assert.equal(d.t3, 1); assert.equal(d.computers, 5); assert.equal(d.upToDate, 80);
assert.equal(d.attention.length, 1); assert.equal(d.attention[0].r.label, 'FH 1', 'the vehicle with a waiting update needs attention');
assert.deepEqual(d.pipeline['In progress'], { total: 1, blocked: 1 });
assert.deepEqual(d.packs[0].Available, ['FH 1']); assert.deepEqual(d.packs[0]['Already on it'], ['FH 2']);
assert.equal(d.readyRate, 50); assert.equal(d.outcomes.Blocked, 1);
assert.equal(d.commits, 1); assert.equal(d.commits90, 1);
assert.deepEqual(d.people.map(([n]) => n).sort(), ['Kavya Menon', 'Rahul Iyer']);

// ---------- introduction tour
assert(TR.tour.STEPS.length >= 10 && TR.tour.STEPS[0].title.includes('Welcome') && TR.tour.STEPS.at(-1).mood === 'cheer');
global.speechSynthesis = { getVoices: () => [{ name: 'Basic voice', lang: 'en-US', localService: true }, { name: 'Microsoft Neerja Online (Natural) - English (India)', lang: 'en-IN', localService: false }, { name: 'Basic Hindi', lang: 'hi-IN', localService: true }] };
global.SpeechSynthesisUtterance = function () {};
TR.culture.use(TR.culture.forCountry('IN'));
assert(TR.tour.pickVoice().name.includes('Neerja'), 'the most natural voice for the user’s language is picked');

console.log('Help Center (search, articles, actions, Asha), first steps, keyboard shortcuts, vehicle Insights, the fleet Dashboard and the voice tour passed.');
