/* The test request journey (js/app/workflow.js): step states and the reasons for blocked steps, one current step,
   validation wording for the decision bar, and the classification of findings. No browser needed. */
const fs = require('fs'), vm = require('vm'), assert = require('assert');
const WWW = `${__dirname}/../../src/Volvo.TestRequestTool.Web/wwwroot`;
global.window = global;
global.document = { addEventListener() {}, querySelector: () => null, createElement: () => ({}), body: null };
global.TR = {
  util: { h: () => ({}) }, i18n: { t: (s, v) => String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)) },
  testRequest: { frame: (c) => c, fresh: () => false, resultStatus: () => 'ready' }, experience: {}, model: { deltaCounts: () => ({ nodes: 0, parameters: 0, variants: 0, sNotes: 0 }) },
  request: { runRequest: async () => {} }, app: { refresh() {} }, backend: { session: {} },
};
vm.runInThisContext(fs.readFileSync(`${WWW}/js/app/workflow.js`, 'utf8'), { filename: 'workflow.js' });
const { steps, validationState, explain, CLASS } = TR.workflow;
const base = { loaded: false, changes: { total: 0 }, canSimulate: true, canEdit: true, canWrite: true, role: 'Engineer', validated: false, fresh: false, stale: false, blocked: 0, limited: 0, ready: 0, running: false };
const f = (o) => Object.assign({}, base, o);
const states = (x, view) => steps(x, view).map((s) => s.state);
const current = (x, view) => steps(x, view).filter((s) => s.state === 'current').map((s) => s.id);

// ---------- the order and exactly one current step
assert.deepEqual(steps(f({})).map((s) => s.label), ['Choose vehicle', 'Make changes', 'Check', 'Get approval', 'Send']);
for (const x of [f({}), f({ loaded: true }), f({ loaded: true, changes: { total: 2 } }), f({ loaded: true, changes: { total: 2 }, validated: true, fresh: true, ready: 1 })])
  assert.equal(current(x).length, 1, 'one current step: ' + JSON.stringify(states(x)));

// ---------- nothing loaded: choose a vehicle; everything else says why
assert.deepEqual(states(f({})), ['current', 'blocked', 'blocked', 'blocked', 'blocked']);
assert.match(steps(f({}))[2].why[0], /Choose a vehicle first/);
assert.equal(steps(f({}))[2].why[2], 'vehicle', 'the way forward opens Add a vehicle');

// ---------- loaded, no changes: prepare changes; validation explains it needs a change
assert.deepEqual(states(f({ loaded: true })), ['done', 'current', 'blocked', 'blocked', 'blocked']);
assert.match(steps(f({ loaded: true }))[2].why[0], /Change at least one/);

// ---------- changes, not validated: validate is next
assert.deepEqual(states(f({ loaded: true, changes: { total: 3 } })), ['done', 'done', 'current', 'blocked', 'blocked']);
assert.equal(steps(f({ loaded: true, changes: { total: 3 } }))[3].why[2], 'validate', 'review offers Validate now');

// ---------- a role without simulation: validate is blocked with the reason and no false action
const viewer = steps(f({ loaded: true, changes: { total: 3 }, canSimulate: false, role: 'Viewer' }))[2];
assert.equal(viewer.state, 'blocked'); assert.match(viewer.why[0], /Viewer.*cannot run validations/); assert.equal(viewer.why[1], null);

// ---------- validated and current: review is next; submit available for writers
let x = f({ loaded: true, changes: { total: 3 }, validated: true, fresh: true, ready: 2 });
assert.deepEqual(states(x), ['done', 'done', 'done', 'current', 'available']);
assert.deepEqual(states(x, 'review'), ['done', 'done', 'done', 'current', 'available']);

// ---------- stale: review and submit are blocked until validated again
x = f({ loaded: true, changes: { total: 4 }, validated: true, stale: true });
assert.equal(steps(x)[3].state, 'blocked'); assert.match(steps(x)[3].why[0], /out of date/); assert.equal(steps(x)[4].why[2], 'validate');
assert.equal(current(x)[0], 'validate', 'stale: validating again is the current step');

// ---------- blocked results: submit says how many and points to the findings
x = f({ loaded: true, changes: { total: 1 }, validated: true, fresh: true, blocked: 1, ready: 2 });
assert.match(steps(x)[4].why[0], /1 of 3 vehicles are blocked/); assert.equal(steps(x)[4].why[2], 'findings');

// ---------- not a writer: submit explains the role
x = f({ loaded: true, changes: { total: 1 }, validated: true, fresh: true, ready: 1, canWrite: false, role: 'Engineer' });
assert.match(steps(x)[4].why[0], /Reviewer or Admin role; you are Engineer/);

// ---------- the current step is the page you are on (the stepper showed Prepare changes on the Validate page)
x = f({ loaded: true, changes: { total: 0 }, validated: true, fresh: true, ready: 1 });
assert.deepEqual(current(x, 'validate'), ['validate'], 'on the Validate page, Validate is current');
assert.equal(steps(x, 'validate')[1].state, 'done', 'a validated request counts as prepared, even with no changes');
assert.deepEqual(current(f({ loaded: true, changes: { total: 2 } }), 'configure'), ['prepare'], 'on the change page, Prepare changes is current');
assert.deepEqual(current(f({ loaded: true, changes: { total: 2 }, validated: true, fresh: true, ready: 1 }), 'review'), ['review']);
assert.deepEqual(current(f({ loaded: true, changes: { total: 2 }, validated: true, stale: true }), 'review'), ['validate'], 'a blocked page step falls back to the next step to do');
for (const v of ['configure', 'validate', 'review']) assert.equal(current(f({ loaded: true, changes: { total: 1 }, validated: true, fresh: true, ready: 1 }), v).length, 1, 'one current step on ' + v);

// ---------- while validating, validate is the current step
assert.equal(current(f({ loaded: true, changes: { total: 1 }, running: true }))[0], 'validate');

// ---------- the decision bar's validation wording (text + icon, never colour alone)
assert.deepEqual(validationState(f({})).slice(0, 2), ['Not validated', 'flask']);
assert.equal(validationState(f({ validated: true, stale: true }))[0], 'Out of date: validate again');
assert.equal(validationState(f({ validated: true, fresh: true, blocked: 2 }))[0], '2 blocked');
assert.equal(validationState(f({ validated: true, fresh: true, limited: 1 }))[0], 'Validated with limits (1)');
assert.equal(validationState(f({ validated: true, fresh: true, ready: 3 }))[0], 'Current: 3 ready');
assert.equal(validationState(f({ running: true }))[0], 'Validating…');

// ---------- findings: failure, unknown compatibility and confirmed are kept apart
assert.equal(explain({ text: 'EMS: no software available for ECU hardware 123', severity: 0 }).kind, 'failed');
assert.equal(explain({ text: 'VCM is not part of service pack SP 1', severity: 1 }).kind, 'unknown', 'outside the service pack: compatibility unknown, not confirmed');
assert.equal(explain({ text: 'Limited validation performed. KAX unavailable', severity: 1 }).kind, 'unknown');
assert.equal(explain({ text: 'EMS: resolved node template document 2210 (EMS_25)', severity: 2 }).kind, 'confirmed');
assert.equal(explain({ text: 'Anything the rules refuse', severity: 0 }).kind, 'failed', 'every error is a validation failure');
assert.equal(explain({ text: 'EMS: A newer version requires different hardware', severity: 1 }).kind, 'unknown', 'a warning never says Must fix: it does not block sending');
assert.equal(explain({ text: 'Node template document is unknown.', severity: 0 }).title, 'Unknown software set', 'plain-language title');
assert.deepEqual(Object.keys(CLASS), ['failed', 'unknown', 'confirmed']);
// A finding nothing could confirm is "Couldn't confirm": "Not checked yet" is the state before the first check.
assert.deepEqual(Object.values(CLASS).map((c) => c[0]), ['Must fix', "Couldn't confirm", 'Checked OK']);
assert.ok(!Object.values(CLASS).some((c) => c[0] === TR.workflow.plainState({ validated: false })[0]), 'no finding label repeats a check state');
assert.deepEqual(Object.keys(TR.workflow.MEANS), Object.keys(CLASS), 'every kind explains itself (shown on hover and focus)');
// Findings are grouped by cause: one row for the same rule on several computers and vehicles.
{
  const F = (vehicle, node, title) => ({ kind: 'unknown', title, plain: 'p-' + title, vehicle, node, text: node + ' ' + title, key: vehicle + node + title });
  const groups = TR.workflow.groupFindings([F('FH 123456', '16.1.1 EMS', 'Hardware check'), F('FH 123456', '30.2.1 IC', 'Hardware check'), F('RT 000777', '16.1.1 EMS', 'Hardware check'), F('FH 123456', '20.1.1 EBS', 'Dependency not met')]);
  assert.equal(groups.length, 2, 'two causes');
  assert.equal(groups[0].items.length, 3);
  assert.deepEqual(groups[0].vehicles, ['FH 123456', 'RT 000777']);
  assert.equal(TR.workflow.whereText(groups[0]), 'FH 123456 (EMS, IC), RT 000777 (EMS)', 'where, by vehicle, without node positions');
  assert.equal(TR.workflow.whereText(groups[1]), 'FH 123456 · EBS');
}

console.log('Workflow: five steps with one current step, reasons and next actions for blocked steps, roles, stale and blocked results, validation wording and finding classes passed.');
