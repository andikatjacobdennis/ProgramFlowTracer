namespace Volvo.TestRequestTool.Infrastructure
{
    /// <summary>Settings for the service layer (Services in appsettings).</summary>
    public sealed class ServiceSettings
    {
        /// <summary>Where the file transport finds each service's folder.</summary>
        public string Path { get; set; } = @"C:\trt\services";
        /// <summary>Per service (EDB, CBR, KAX, ...). A service not listed uses the file transport and its own folder.</summary>
        public Dictionary<string, ServiceEndpoint> Endpoints { get; set; } = new(StringComparer.OrdinalIgnoreCase);
        public ServiceEndpoint For(string service) => Endpoints.TryGetValue(service, out var e) ? e : new ServiceEndpoint();
        public string FolderOf(string service) => System.IO.Path.Combine(Path, For(service).Folder ?? (RepositorySeeder.Services.TryGetValue(service, out var f) ? f : service.ToLowerInvariant()));
    }
}
