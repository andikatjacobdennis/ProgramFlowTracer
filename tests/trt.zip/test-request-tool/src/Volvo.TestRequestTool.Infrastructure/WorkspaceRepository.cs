using System.Collections.Concurrent;
using System.Text.Json;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Infrastructure
{
    /// <summary>
    /// The workspace over any <see cref="IDocumentStore"/> (files now, a database later): one document per record.
    /// <list type="bullet">
    /// <item><b>Fast reads.</b> Each collection is read once, the first time it is needed, and then answered from memory, so
    /// start-up reads nothing and a page only waits for the collections it uses.</item>
    /// <item><b>Small writes.</b> A save writes only the records it changes (a request, a draft, a vehicle and its revision),
    /// never the whole workspace, and memory changes only after the store has accepted the write.</item>
    /// <item><b>One writer.</b> Changes go one at a time, so revision, version and conflict checks stay exact. Single
    /// process: for several instances use a database provider with its own concurrency control.</item>
    /// </list>
    /// </summary>
    public sealed class WorkspaceRepository : IWorkspaceStore, IDisposable
    {
        private readonly IDocumentStore _docs;
        private readonly TimeProvider _clock;

        public static class Collections
        {
            public const string Users = "users", Vehicles = "vehicles", Originals = "vehicle-originals", Revisions = "vehicle-revisions",
                Requests = "requests", Drafts = "drafts", Kits = "kits", Feedback = "feedback", Proposals = "proposals", Jobs = "jobs",
                Audit = "audit", Settings = "settings", Batches = "batches", Campaigns = "campaigns", Reviews = "reviews", Pauses = "pauses", Sessions = "sessions";
        }

        private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);
        private readonly SemaphoreSlim _gate = new(1, 1);
        private readonly ConcurrentDictionary<string, Lazy<Task>> _loads = new(StringComparer.Ordinal);

        private readonly Dictionary<string, UserAccount> _users = new(StringComparer.OrdinalIgnoreCase);
        private readonly Dictionary<string, SessionRecord> _sessions = new(StringComparer.Ordinal);
        private readonly Dictionary<string, VersionedProduct> _vehicles = new(StringComparer.Ordinal);
        private readonly Dictionary<string, JsonObject> _originals = new(StringComparer.Ordinal);
        private readonly Dictionary<string, List<VehicleRevision>> _revisions = new(StringComparer.Ordinal);
        private readonly Dictionary<Guid, ExecutionRecord> _requests = [];
        private readonly Dictionary<string, Draft> _drafts = new(StringComparer.Ordinal);
        private readonly Dictionary<Guid, Kit> _kits = [];
        private readonly List<FeedbackItem> _feedback = [];
        private readonly Dictionary<string, List<ProposalRevision>> _proposals = new(StringComparer.Ordinal);
        private readonly Dictionary<Guid, JobRecord> _jobs = [];
        private readonly List<AuditEntry> _audit = [];
        private readonly Dictionary<string, List<SettingVersion>> _settings = new(StringComparer.Ordinal);
        private readonly Dictionary<Guid, BatchRecord> _batches = [];
        private readonly Dictionary<Guid, CampaignRecord> _campaigns = [];
        private readonly Dictionary<Guid, ReviewRecord> _reviews = [];
        private readonly Dictionary<string, PauseRecord> _pauses = new(StringComparer.Ordinal);

        public IDocumentStore Documents => _docs;

        // ------------------------------------------------------------------ loading
        /// <summary>Reads the collections into memory now (the warm-up calls this so the first person does not wait).</summary>
        public Task LoadAllAsync(CancellationToken ct) => Task.WhenAll(new[] { Collections.Users, Collections.Sessions, Collections.Vehicles, Collections.Requests, Collections.Reviews, Collections.Jobs, Collections.Settings, Collections.Pauses }.Select(c => Need(c, ct)));

        private async Task Need(string collection, CancellationToken ct)
        {
            ThrowIfShutDown();
            var load = _loads.GetOrAdd(collection, c => new Lazy<Task>(() => LoadAsync(c)));
            try
            {
                await load.Value.WaitAsync(ct);
            }
            catch when (load.Value.IsFaulted)
            {
                _loads.TryRemove(collection, out _);
                throw;
            } // a fixed file can be read on the next try
        }

        private async Task Need(string a, string b, CancellationToken ct)
        {
            await Need(a, ct);
            await Need(b, ct);
        }

        private async Task LoadAsync(string collection)
        {
            var found = await _docs.ListAsync(collection, CancellationToken.None);
            T To<T>(StoredDocument d) => d.Document.Deserialize<T>(Json) ?? throw new InvalidDataException($"Empty record {collection}/{d.Key}.");
            await _gate.WaitAsync();
            try
            {
                switch (collection)
                {
                    case Collections.Users:
                        foreach (var d in found)
                        {
                            var u = To<UserAccount>(d);
                            _users[u.Id] = u;
                        }
                        break;
                    case Collections.Sessions:
                        foreach (var d in found)
                        {
                            var s = To<SessionRecord>(d);
                            if (s.ExpiresAt > _clock.GetUtcNow())
                            {
                                _sessions[s.Id] = s;
                            }
                            else
                            {
                                await _docs.DeleteAsync(Collections.Sessions, d.Key, CancellationToken.None);   // expired: tidy up
                            }
                        }
                        break;
                    case Collections.Vehicles:
                        foreach (var d in found)
                        {
                            var v = To<VersionedProduct>(d);
                            _vehicles[new ProductDocument(v.Product).Id] = v;
                        }
                        break;
                    case Collections.Originals:
                        foreach (var d in found)
                        {
                            _originals[new ProductDocument(d.Document).Id] = d.Document;
                        }
                        break;
                    case Collections.Revisions:
                        foreach (var g in found.GroupBy(d => d.Key.Split('/')[0]))
                        {
                            _revisions[VehicleId(g.Key)] = g.Select(To<VehicleRevision>).OrderBy(r => r.Revision).ToList();
                        }
                        break;
                    case Collections.Requests:
                        foreach (var d in found)
                        {
                            var r = To<ExecutionRecord>(d);
                            _requests[r.Id] = r;
                        }
                        break;
                    case Collections.Drafts:
                        foreach (var d in found)
                        {
                            var r = To<Draft>(d);
                            _drafts[r.ActorId + ":" + r.Id] = r;
                        }
                        break;
                    case Collections.Kits:
                        foreach (var d in found)
                        {
                            var r = To<Kit>(d);
                            _kits[r.Id] = r;
                        }
                        break;
                    case Collections.Feedback:
                        _feedback.AddRange(found.Select(To<FeedbackItem>).OrderBy(f => f.CreatedAt));
                        break;
                    case Collections.Proposals:
                        foreach (var g in found.Select(To<ProposalRevision>).GroupBy(r => ProposalKey(r.OwnerId, r.ProposalId)))
                        {
                            _proposals[g.Key] = g.OrderBy(r => r.Number).ToList();
                        }
                        break;
                    case Collections.Jobs:
                        foreach (var d in found)
                        {
                            var r = To<JobRecord>(d);
                            _jobs[r.Id] = r;
                        }
                        break;
                    case Collections.Audit:
                        _audit.AddRange(found.Select(To<AuditEntry>).OrderBy(e => e.Sequence));
                        break;
                    case Collections.Settings:
                        foreach (var g in found.Select(To<SettingVersion>).GroupBy(s => s.Key))
                        {
                            _settings[g.Key] = g.OrderBy(s => s.Version).ToList();
                        }
                        break;
                    case Collections.Batches:
                        foreach (var d in found)
                        {
                            var r = To<BatchRecord>(d);
                            _batches[r.Id] = r;
                        }
                        break;
                    case Collections.Campaigns:
                        foreach (var d in found)
                        {
                            var r = To<CampaignRecord>(d);
                            _campaigns[r.Id] = r;
                        }
                        break;
                    case Collections.Reviews:
                        foreach (var d in found)
                        {
                            var r = To<ReviewRecord>(d);
                            _reviews[r.Id] = r;
                        }
                        break;
                    case Collections.Pauses:
                        foreach (var d in found)
                        {
                            var r = To<PauseRecord>(d);
                            _pauses[r.Scope] = r;
                        }
                        break;
                    default:
                        throw new InvalidOperationException("Unknown collection " + collection);
                }
            }
            finally
            {
                _gate.Release();
            }
        }

        /// <summary>"FH|333333" ↔ "FH-333333": a vehicle's file name (series are letters and digits, so this is reversible).</summary>
        public static string VehicleFile(string id) => id.Replace('|', '-');
        private static string VehicleId(string file) => file.Replace('-', '|');
        private static string ProposalKey(string owner, string id) => owner + ":" + id;
        private static JsonObject Doc<T>(T value) => (JsonObject)JsonSerializer.SerializeToNode(value, Json)!;
        private Task Put<T>(string collection, string key, T value, CancellationToken ct) => _docs.PutAsync(collection, key, Doc(value), ct);

        // ------------------------------------------------------------------ people
        public async Task<IReadOnlyList<UserAccount>> UsersAsync(CancellationToken ct)
        {
            await Need(Collections.Users, ct);
            return await Read<IReadOnlyList<UserAccount>>(() => _users.Values.ToArray(), ct);
        }

        public async Task<UserAccount?> UserAsync(string id, CancellationToken ct)
        {
            await Need(Collections.Users, ct);
            return await Read(() => _users.GetValueOrDefault(id), ct);
        }

        public async Task<UserAccount> SaveUserAsync(UserAccount user, CancellationToken ct)
        {
            await Need(Collections.Users, ct);
            return await Write(async () =>
            {
                await Put(Collections.Users, user.Id, user, ct);
                _users[user.Id] = user;
                return user;
            }, ct);
        }

        public async Task<SessionRecord?> SessionAsync(string id, CancellationToken ct)
        {
            await Need(Collections.Sessions, ct);
            return await Read(() => _sessions.TryGetValue(id, out var s) && s.ExpiresAt > _clock.GetUtcNow() ? s : null, ct);
        }

        public async Task SaveSessionAsync(SessionRecord session, CancellationToken ct)
        {
            await Need(Collections.Sessions, ct);
            await Write(async () =>
            {
                await Put(Collections.Sessions, session.Id, session, ct);
                _sessions[session.Id] = session;
                return true;
            }, ct);
        }

        public async Task<bool> EndSessionAsync(string id, CancellationToken ct)
        {
            await Need(Collections.Sessions, ct);
            return await Write(async () =>
            {
                if (!_sessions.Remove(id))
                {
                    return false;
                }
                await _docs.DeleteAsync(Collections.Sessions, id, ct);
                return true;
            }, ct);
        }

        // ------------------------------------------------------------------ vehicles
        public async Task<IReadOnlyList<VersionedProduct>> VehiclesAsync(CancellationToken ct)
        {
            await Need(Collections.Vehicles, ct);
            return await Read<IReadOnlyList<VersionedProduct>>(() => _vehicles.Values.OrderBy(v => new ProductDocument(v.Product).Id, StringComparer.Ordinal).Select(Clone).ToArray(), ct);
        }

        public async Task<VersionedProduct?> VehicleAsync(string id, CancellationToken ct)
        {
            await Need(Collections.Vehicles, ct);
            return await Read(() => _vehicles.TryGetValue(id, out var v) ? Clone(v) : null, ct);
        }

        public async Task<JsonObject?> OriginalAsync(string id, CancellationToken ct)
        {
            await Need(Collections.Originals, ct);
            return await Read(() => _originals.TryGetValue(id, out var p) ? (JsonObject?)p.DeepClone() : null, ct);
        }

        /// <summary>Adds a vehicle to the repository (an import): revision 1, kept as its original too. 409 when it exists.</summary>
        public async Task<VersionedProduct> ImportVehicleAsync(JsonObject product, CancellationToken ct)
        {
            await Need(Collections.Vehicles, Collections.Originals, ct);
            var p = new ProductDocument(product);
            return await Write(async () =>
            {
                if (_vehicles.ContainsKey(p.Id))
                {
                    throw new RequestFault(409, "vehicle_exists", "The vehicle is already in the repository.");
                }

                var v = new VersionedProduct((JsonObject)p.Data.DeepClone(), 1);
                await _docs.PutAsync(Collections.Originals, VehicleFile(p.Id), (JsonObject)p.Data.DeepClone(), ct);
                await Put(Collections.Vehicles, VehicleFile(p.Id), v, ct);
                _originals[p.Id] = (JsonObject)p.Data.DeepClone();
                _vehicles[p.Id] = v;
                return Clone(v);
            }, ct);
        }

        public async Task<VersionedProduct> UpdateVehicleAsync(string id, JsonObject product, long expectedRevision, CancellationToken ct, RevisionNote? note = null)
        {
            await Need(Collections.Vehicles, Collections.Revisions, ct);
            return await Write(async () =>
            {
                var old = _vehicles.GetValueOrDefault(id) ?? throw new RequestFault(404, "vehicle_missing", "Vehicle was not found.");
                if (old.Revision != expectedRevision)
                {
                    throw new RequestFault(409, "revision_conflict", "Vehicle changed after validation. Revalidate the proposal.");
                }

                var p = new ProductDocument(product);
                if (p.Id != id || p.ContextId != new ProductDocument(old.Product).ContextId)
                {
                    throw new RequestFault(400, "identity_changed", "Vehicle identity and context cannot change.");
                }

                var next = new VersionedProduct((JsonObject)p.Data.DeepClone(), old.Revision + 1);
                // Keep who changed the vehicle, when and why, with the full snapshot, so its history can be shown later.
                var author = note ?? new RevisionNote("unknown", "Unknown user", "Vehicle updated");
                var revision = new VehicleRevision(next.Revision, _clock.GetUtcNow(), author.ActorId, author.ActorName, author.Reason, author.Source, (JsonObject)p.Data.DeepClone());
                await Put(Collections.Revisions, VehicleFile(id) + "/" + next.Revision.ToString("D6", System.Globalization.CultureInfo.InvariantCulture), revision, ct);
                await Put(Collections.Vehicles, VehicleFile(id), next, ct);
                _vehicles[id] = next;
                if (!_revisions.TryGetValue(id, out var list))
                {
                    _revisions[id] = list = [];
                }

                list.Add(revision);
                return Clone(next);
            }, ct);
        }

        public async Task<IReadOnlyList<VehicleRevision>> RevisionsAsync(string id, CancellationToken ct)
        {
            await Need(Collections.Revisions, ct);
            return await Read<IReadOnlyList<VehicleRevision>>(() => _revisions.TryGetValue(id, out var list) ? list.Select(Clone).ToArray() : [], ct);
        }

        public async Task<IReadOnlyList<Kit>> KitsForVehicleAsync(string id, CancellationToken ct)
        {
            await Need(Collections.Kits, ct);
            return await Read<IReadOnlyList<Kit>>(() => _kits.Values.Where(k => k.Changes.Any(c => c.S("vehicleId") == id)).OrderByDescending(k => k.CreatedAt).Select(Clone).ToArray(), ct);
        }

        // ------------------------------------------------------------------ requests, drafts, kits, feedback
        public async Task<IReadOnlyList<ExecutionRecord>> ExecutionsForVehicleAsync(string vehicleId, string actorId, CancellationToken ct)
        {
            await Need(Collections.Requests, ct);
            return await Read<IReadOnlyList<ExecutionRecord>>(() => _requests.Values.Where(r => r.ActorId == actorId && r.Outcomes.Any(o => o.VehicleId == vehicleId)).OrderByDescending(r => r.CreatedAt).Take(100).Select(Clone).ToArray(), ct);
        }

        public async Task SaveExecutionAsync(ExecutionRecord record, CancellationToken ct)
        {
            await Need(Collections.Requests, ct);
            await Write(async () =>
            {
                await Put(Collections.Requests, record.Id.ToString(), record, ct);
                _requests[record.Id] = Clone(record);
                return true;
            }, ct);
        }

        public async Task<ExecutionRecord?> ExecutionAsync(Guid id, string actorId, CancellationToken ct)
        {
            await Need(Collections.Requests, ct);
            return await Read(() => _requests.TryGetValue(id, out var r) && r.ActorId == actorId ? Clone(r) : null, ct);
        }

        public async Task<IReadOnlyList<ExecutionRecord>> ExecutionsSinceAsync(string? actorId, DateTimeOffset since, int take, CancellationToken ct)
        {
            await Need(Collections.Requests, ct);
            return await Read<IReadOnlyList<ExecutionRecord>>(() => _requests.Values.Where(r => (actorId is null || r.ActorId == actorId) && r.CreatedAt >= since).OrderByDescending(r => r.CreatedAt).Take(Math.Clamp(take, 1, 100_000)).Select(Clone).ToArray(), ct);
        }

        public async Task<IReadOnlyList<ExecutionRecord>> HistoryAsync(string actorId, int skip, int take, CancellationToken ct)
        {
            await Need(Collections.Requests, ct);
            return await Read<IReadOnlyList<ExecutionRecord>>(() => _requests.Values.Where(r => r.ActorId == actorId).OrderByDescending(r => r.CreatedAt).Skip(Math.Max(0, skip)).Take(Math.Clamp(take, 1, 100)).Select(Clone).ToArray(), ct);
        }

        public async Task<Draft?> DraftAsync(string id, string actorId, CancellationToken ct)
        {
            await Need(Collections.Drafts, ct);
            return await Read(() => _drafts.TryGetValue(actorId + ":" + id, out var d) ? Clone(d) : null, ct);
        }

        public async Task<Draft> SaveDraftAsync(string id, string actorId, JsonObject value, long? expectedVersion, CancellationToken ct)
        {
            await Need(Collections.Drafts, ct);
            return await Write(async () =>
            {
                var key = actorId + ":" + id;
                _drafts.TryGetValue(key, out var old);
                if ((old is null && expectedVersion is not null) || (old is not null && old.Version != expectedVersion))
                {
                    throw new RequestFault(409, "draft_conflict", "The draft was changed by another save. Reload before retrying.");
                }

                var draft = new Draft(id, actorId, (JsonObject)value.DeepClone(), (old?.Version ?? 0) + 1, _clock.GetUtcNow());
                await Put(Collections.Drafts, actorId + "/" + id, draft, ct);
                _drafts[key] = draft;
                return Clone(draft);
            }, ct);
        }

        public async Task<Kit> SaveKitAsync(Kit kit, CancellationToken ct)
        {
            await Need(Collections.Kits, ct);
            return await Write(async () =>
            {
                await Put(Collections.Kits, kit.Id.ToString(), kit, ct);
                _kits[kit.Id] = Clone(kit);
                return Clone(kit);
            }, ct);
        }

        public async Task<FeedbackItem> SaveFeedbackAsync(FeedbackItem item, CancellationToken ct)
        {
            await Need(Collections.Feedback, ct);
            return await Write(async () =>
            {
                await Put(Collections.Feedback, item.Id.ToString(), item, ct);
                _feedback.Add(Clone(item));
                return Clone(item);
            }, ct);
        }

        public async Task<IReadOnlyList<FeedbackItem>> FeedbackAsync(string? actorId, CancellationToken ct)
        {
            await Need(Collections.Feedback, ct);
            return await Read<IReadOnlyList<FeedbackItem>>(() => _feedback.Where(f => actorId is null || f.ActorId == actorId).OrderByDescending(f => f.CreatedAt).Select(Clone).ToArray(), ct);
        }

        public async Task<FeedbackItem?> SetFeedbackStatusAsync(Guid id, string status, CancellationToken ct)
        {
            await Need(Collections.Feedback, ct);
            return await Write(async () =>
            {
                var i = _feedback.FindIndex(f => f.Id == id);
                if (i < 0)
                {
                    return null;
                }

                var next = _feedback[i] with { Status = status };
                await Put(Collections.Feedback, id.ToString(), next, ct);
                _feedback[i] = next;
                return Clone(next);
            }, ct);
        }

        // ------------------------------------------------------------------ proposal revisions (FR-05)
        public async Task<IReadOnlyList<ProposalRevision>> ProposalRevisionsAsync(string ownerId, string proposalId, CancellationToken ct)
        {
            await Need(Collections.Proposals, ct);
            return await Read<IReadOnlyList<ProposalRevision>>(() => _proposals.TryGetValue(ProposalKey(ownerId, proposalId), out var list) ? list.AsEnumerable().Reverse().Select(r => Clone(r.WithoutState())).ToArray() : [], ct);
        }

        public async Task<ProposalRevision?> ProposalRevisionAsync(string ownerId, string proposalId, int number, CancellationToken ct)
        {
            await Need(Collections.Proposals, ct);
            return await Read(() => _proposals.TryGetValue(ProposalKey(ownerId, proposalId), out var list) && list.FirstOrDefault(r => r.Number == number) is { } r ? Clone(r) : null, ct);
        }

        public async Task<ProposalRevision> AddProposalRevisionAsync(ProposalRevision revision, int? expectedLatest, CancellationToken ct)
        {
            await Need(Collections.Proposals, ct);
            return await Write(async () =>
            {
                var key = ProposalKey(revision.OwnerId, revision.ProposalId);
                _proposals.TryGetValue(key, out var list);
                var latest = list?.LastOrDefault();
                if (expectedLatest is not null && (latest?.Number ?? 0) != expectedLatest)
                {
                    throw new RequestFault(409, "proposal_conflict", $"Revision {latest?.Number} was saved by {latest?.ActorName} after the revision you edited ({expectedLatest}).");
                }

                if (latest is not null && latest.Hash == revision.Hash && revision.RestoredFrom is null)
                {
                    return Clone(latest.WithoutState());
                }

                var next = revision with { Number = (latest?.Number ?? 0) + 1, At = _clock.GetUtcNow(), State = (JsonObject?)revision.State?.DeepClone() };
                await Put(Collections.Proposals, revision.OwnerId + "/" + revision.ProposalId + "/" + next.Number.ToString("D5", System.Globalization.CultureInfo.InvariantCulture), next, ct);
                if (list is null)
                {
                    _proposals[key] = list = [];
                }

                list.Add(next);
                return Clone(next.WithoutState());
            }, ct);
        }

        // ------------------------------------------------------------------ jobs (FR-07)
        private Task StoreJob(JobRecord job, CancellationToken ct) => Put(Collections.Jobs, job.Id.ToString(), job, ct);

        public async Task<JobRecord> SaveJobAsync(JobRecord job, CancellationToken ct)
        {
            await Need(Collections.Jobs, ct);
            return await Write(async () =>
            {
                if (_jobs.ContainsKey(job.Id))
                {
                    throw new RequestFault(409, "job_exists", "A job with this id already exists.");
                }

                var stored = job with { Version = 1 };
                await StoreJob(stored, ct);
                _jobs[job.Id] = Clone(stored);
                return Clone(stored);
            }, ct);
        }

        public async Task<JobRecord> TransitionJobAsync(Guid id, long expectedVersion, string toStatus, Func<JobRecord, JobRecord> change, CancellationToken ct)
        {
            await Need(Collections.Jobs, ct);
            return await Write(async () =>
            {
                if (!_jobs.TryGetValue(id, out var job))
                {
                    throw new RequestFault(404, "job_missing", "Job was not found.");
                }

                if (job.Version != expectedVersion)
                {
                    throw new RequestFault(409, "job_changed", $"The job changed (now {job.Status}). Reload it and try again.");
                }

                if (!JobRecord.CanMove(job.Status, toStatus))
                {
                    throw new RequestFault(409, "invalid_transition", $"A {job.Status} job cannot become {toStatus}.");
                }

                var next = change(Clone(job)) with { Status = toStatus, Version = job.Version + 1 };
                await StoreJob(next, ct);
                _jobs[id] = Clone(next);
                return Clone(next);
            }, ct);
        }

        /// <summary>Workers poll every second. An idle poll only reads; a record is written only when a job is actually claimed.</summary>
        public async Task<JobRecord?> ClaimJobAsync(string workerId, TimeSpan lease, bool allowBatch, TimeSpan batchAging, CancellationToken ct)
        {
            await Need(Collections.Jobs, ct);
            if (!await Read(() =>
            {
                var now = _clock.GetUtcNow();
                return _jobs.Values.Any(j => (j.Status == "queued" || j.Status == "running" && j.LeaseUntil <= now) && (allowBatch || j.Lane != "batch"));
            }, ct))
            {
                return null;
            }

            return await Write(async () =>
            {
                var now = _clock.GetUtcNow();
                var running = _jobs.Values.Where(j => j.Status is "running" or "cancelling" && j.LeaseUntil > now).GroupBy(j => j.Actor.Id).ToDictionary(g => g.Key, g => g.Count());
                // An expired lease means its worker stopped: take the job over (it runs again as the same attempt, writing the same result id).
                var job = _jobs.Values.Where(j => j.Status == "running" && j.LeaseUntil <= now && (allowBatch || j.Lane != "batch")).OrderBy(j => j.LeaseUntil).FirstOrDefault()
                    ?? _jobs.Values.Where(j => j.Status == "queued" && (allowBatch || j.Lane != "batch"))
                        .OrderBy(j => j.Lane == "interactive" || now - j.CreatedAt > batchAging ? 0 : 1)
                        .ThenBy(j => running.GetValueOrDefault(j.Actor.Id))
                        .ThenBy(j => j.CreatedAt).FirstOrDefault();
                if (job is null)
                {
                    return null;
                }

                var takeover = job.Status == "running";
                var attempts = (job.Attempts ?? []).ToList();
                if (takeover && attempts.Count > 0 && attempts[^1].FinishedAt is null)
                {
                    attempts[^1] = attempts[^1] with { FinishedAt = now, Status = "lease-expired", ErrorCode = "lease_expired", Error = $"Worker {job.LeaseOwner} stopped; taken over by {workerId}." };
                }

                attempts.Add(new JobAttempt(job.Attempt, now, null, "running", null, null));
                var next = job with { Status = "running", StartedAt = job.StartedAt ?? now, LeaseOwner = workerId, LeaseUntil = now + lease, Attempts = attempts, Version = job.Version + 1 };
                await StoreJob(next, ct);
                _jobs[job.Id] = next;
                return Clone(next);
            }, ct);
        }

        public async Task<bool> RenewLeaseAsync(Guid id, string workerId, TimeSpan lease, CancellationToken ct)
        {
            await Need(Collections.Jobs, ct);
            return await Write(async () =>
            {
                if (!_jobs.TryGetValue(id, out var job) || job.LeaseOwner != workerId || job.Status is not ("running" or "cancelling"))
                {
                    return false;
                }

                var next = job with { LeaseUntil = _clock.GetUtcNow() + lease, Version = job.Version + 1 };
                await StoreJob(next, ct);
                _jobs[id] = next;
                return true;
            }, ct);
        }

        public async Task<(int Queued, int Running, int QueuedForActor, DateTimeOffset? OldestQueued)> JobLoadAsync(string actorId, CancellationToken ct)
        {
            await Need(Collections.Jobs, ct);
            return await Read(() =>
            {
                var queued = _jobs.Values.Where(j => j.Status == "queued").ToArray();
                return (queued.Length, _jobs.Values.Count(j => j.Status is "running" or "cancelling"), queued.Count(j => j.Actor.Id == actorId), queued.Length == 0 ? null : (DateTimeOffset?)queued.Min(j => j.CreatedAt));
            }, ct);
        }

        public async Task<JobRecord?> JobAsync(Guid id, CancellationToken ct)
        {
            await Need(Collections.Jobs, ct);
            return await Read(() => _jobs.TryGetValue(id, out var j) ? Clone(j) : null, ct);
        }

        public async Task<JobRecord?> JobByKeyAsync(string actorId, string key, CancellationToken ct)
        {
            await Need(Collections.Jobs, ct);
            return await Read(() => _jobs.Values.FirstOrDefault(j => j.Actor.Id == actorId && j.IdempotencyKey == key) is { } j ? Clone(j) : null, ct);
        }

        public async Task<IReadOnlyList<JobRecord>> JobsAsync(string? actorId, int take, CancellationToken ct)
        {
            await Need(Collections.Jobs, ct);
            return await Read<IReadOnlyList<JobRecord>>(() => _jobs.Values.Where(j => actorId is null || j.Actor.Id == actorId).OrderByDescending(j => j.CreatedAt).Take(Math.Clamp(take, 1, 200)).Select(Clone).ToArray(), ct);
        }

        // ------------------------------------------------------------------ organisation settings (FR-79)
        public async Task<SettingVersion?> SettingAsync(string key, CancellationToken ct)
        {
            await Need(Collections.Settings, ct);
            return await Read(() => _settings.TryGetValue(key, out var l) && l.Count > 0 ? Clone(l[^1]) : null, ct);
        }

        public async Task<IReadOnlyList<SettingVersion>> SettingHistoryAsync(string key, CancellationToken ct)
        {
            await Need(Collections.Settings, ct);
            return await Read<IReadOnlyList<SettingVersion>>(() => _settings.TryGetValue(key, out var l) ? l.AsEnumerable().Reverse().Select(Clone).ToArray() : [], ct);
        }

        public async Task<SettingVersion> SaveSettingAsync(string key, JsonObject value, string actorId, string actorName, string? note, CancellationToken ct)
        {
            await Need(Collections.Settings, ct);
            return await Write(async () =>
            {
                _settings.TryGetValue(key, out var l);
                var v = new SettingVersion(key, (l?.LastOrDefault()?.Version ?? 0) + 1, (JsonObject)value.DeepClone(), actorId, actorName, _clock.GetUtcNow(), note);
                await Put(Collections.Settings, key + "/" + v.Version.ToString("D6", System.Globalization.CultureInfo.InvariantCulture), v, ct);
                if (l is null)
                {
                    _settings[key] = l = [];
                }

                l.Add(v);
                return Clone(v);
            }, ct);
        }

        // ------------------------------------------------------------------ batch runs (FR-11), campaigns, reviews (FR-06, FR-57)
        public async Task<BatchRecord> SaveBatchAsync(BatchRecord batch, CancellationToken ct)
        {
            await Need(Collections.Batches, ct);
            return await Write(async () =>
            {
                await Put(Collections.Batches, batch.Id.ToString(), batch, ct);
                _batches[batch.Id] = Clone(batch);
                return Clone(batch);
            }, ct);
        }

        public async Task<BatchRecord?> BatchAsync(Guid id, CancellationToken ct)
        {
            await Need(Collections.Batches, ct);
            return await Read(() => _batches.TryGetValue(id, out var b) ? Clone(b) : null, ct);
        }

        public async Task<IReadOnlyList<BatchRecord>> BatchesAsync(string? actorId, int take, CancellationToken ct)
        {
            await Need(Collections.Batches, ct);
            return await Read<IReadOnlyList<BatchRecord>>(() => _batches.Values.Where(b => actorId is null || b.Actor.Id == actorId).OrderByDescending(b => b.CreatedAt).Take(Math.Clamp(take, 1, 200)).Select(Clone).ToArray(), ct);
        }

        public async Task<CampaignRecord> SaveCampaignAsync(CampaignRecord campaign, long? expectedVersion, CancellationToken ct)
        {
            await Need(Collections.Campaigns, ct);
            return await Write(async () =>
            {
                _campaigns.TryGetValue(campaign.Id, out var stored);
                if (expectedVersion is null ? stored is not null : stored is null || stored.Version != expectedVersion)
                {
                    throw new RequestFault(409, "campaign_conflict", "The campaign changed since you opened it. Reload it and try again.");
                }

                var saved = campaign with { Version = (stored?.Version ?? 0) + 1 };
                await Put(Collections.Campaigns, campaign.Id.ToString(), saved, ct);
                _campaigns[campaign.Id] = Clone(saved);
                return Clone(saved);
            }, ct);
        }

        public async Task<CampaignRecord?> CampaignAsync(Guid id, CancellationToken ct)
        {
            await Need(Collections.Campaigns, ct);
            return await Read(() => _campaigns.TryGetValue(id, out var c) ? Clone(c) : null, ct);
        }

        public async Task<IReadOnlyList<CampaignRecord>> CampaignsAsync(CancellationToken ct)
        {
            await Need(Collections.Campaigns, ct);
            return await Read<IReadOnlyList<CampaignRecord>>(() => _campaigns.Values.OrderByDescending(c => c.CreatedAt).Select(Clone).ToArray(), ct);
        }

        public async Task<ReviewRecord> SaveReviewAsync(ReviewRecord review, long? expectedVersion, CancellationToken ct)
        {
            await Need(Collections.Reviews, ct);
            return await Write(async () =>
            {
                _reviews.TryGetValue(review.Id, out var stored);
                if (expectedVersion is null ? stored is not null : stored is null || stored.Version != expectedVersion)
                {
                    throw new RequestFault(409, "review_conflict", "The review changed since you opened it. Reload it and try again.");
                }

                var saved = review with { Version = (stored?.Version ?? 0) + 1 };
                await Put(Collections.Reviews, review.Id.ToString(), saved, ct);
                _reviews[review.Id] = Clone(saved);
                return Clone(saved);
            }, ct);
        }

        public async Task<ReviewRecord?> ReviewAsync(Guid id, CancellationToken ct)
        {
            await Need(Collections.Reviews, ct);
            return await Read(() => _reviews.TryGetValue(id, out var r) ? Clone(r) : null, ct);
        }

        public async Task<ReviewRecord?> ReviewForRequestAsync(Guid requestId, CancellationToken ct)
        {
            await Need(Collections.Reviews, ct);
            return await Read(() => _reviews.Values.Where(r => r.RequestId == requestId).OrderByDescending(r => r.CreatedAt).Select(Clone).FirstOrDefault(), ct);
        }

        public async Task<IReadOnlyList<ReviewRecord>> ReviewsAsync(int take, CancellationToken ct)
        {
            await Need(Collections.Reviews, ct);
            return await Read<IReadOnlyList<ReviewRecord>>(() => _reviews.Values.OrderByDescending(r => r.CreatedAt).Take(Math.Clamp(take, 1, 500)).Select(Clone).ToArray(), ct);
        }

        // ------------------------------------------------------------------ pauses (FR-76)
        public async Task<IReadOnlyList<PauseRecord>> PausesAsync(CancellationToken ct)
        {
            await Need(Collections.Pauses, ct);
            return await Read<IReadOnlyList<PauseRecord>>(() => _pauses.Values.OrderBy(p => p.Scope, StringComparer.Ordinal).Select(Clone).ToArray(), ct);
        }

        public async Task<PauseRecord> SetPauseAsync(PauseRecord pause, CancellationToken ct)
        {
            await Need(Collections.Pauses, ct);
            return await Write(async () =>
            {
                await Put(Collections.Pauses, pause.Scope, pause, ct);
                _pauses[pause.Scope] = Clone(pause);
                return Clone(pause);
            }, ct);
        }

        public async Task<bool> ClearPauseAsync(string scope, CancellationToken ct)
        {
            await Need(Collections.Pauses, ct);
            return await Write(async () =>
            {
                if (!_pauses.ContainsKey(scope))
                {
                    return false;
                }
                await _docs.DeleteAsync(Collections.Pauses, scope, ct);
                return _pauses.Remove(scope);
            }, ct);
        }

        // ------------------------------------------------------------------ audit (FR-19)
        public async Task<AuditEntry> AppendAuditAsync(string actorId, string actorName, string action, string target, JsonObject? details, CancellationToken ct)
        {
            await Need(Collections.Audit, ct);
            return await Write(async () =>
            {
                var last = _audit.LastOrDefault();
                var seq = (last?.Sequence ?? 0) + 1;
                var at = _clock.GetUtcNow();
                var prev = last?.Hash ?? "genesis";
                var entry = new AuditEntry(seq, at, actorId, actorName, action, target, (JsonObject?)details?.DeepClone(), prev, AuditEntry.Compute(seq, at, actorId, action, target, details, prev));
                await Put(Collections.Audit, seq.ToString("D10", System.Globalization.CultureInfo.InvariantCulture), entry, ct);
                _audit.Add(entry);
                return Clone(entry);
            }, ct);
        }

        public async Task<IReadOnlyList<AuditEntry>> AuditAsync(int skip, int take, CancellationToken ct)
        {
            await Need(Collections.Audit, ct);
            return await Read<IReadOnlyList<AuditEntry>>(() => _audit.AsEnumerable().Reverse().Skip(Math.Max(0, skip)).Take(Math.Clamp(take, 1, 500)).Select(Clone).ToArray(), ct);
        }

        public async Task<(int Checked, long? BrokenAt)> VerifyAuditAsync(CancellationToken ct)
        {
            await Need(Collections.Audit, ct);
            return await Read<(int, long?)>(() =>
            {
                var prev = "genesis";
                foreach (var e in _audit)
                {
                    if (e.PreviousHash != prev || e.Hash != AuditEntry.Compute(e.Sequence, e.At, e.ActorId, e.Action, e.Target, e.Details, e.PreviousHash))
                    {
                        return (_audit.Count, e.Sequence);
                    }

                    prev = e.Hash;
                }
                return (_audit.Count, null);
            }, ct);
        }

        /// <summary>How many records each collection holds (loads them all): for the Data and services page.</summary>
        public async Task<IReadOnlyDictionary<string, int>> CountsAsync(CancellationToken ct)
        {
            var names = typeof(Collections).GetFields().Select(f => (string)f.GetValue(null)!).ToArray();
            foreach (var n in names)
            {
                await Need(n, ct);
            }

            return await Read<IReadOnlyDictionary<string, int>>(() => new Dictionary<string, int>
            {
                [Collections.Users] = _users.Count,
                [Collections.Vehicles] = _vehicles.Count,
                [Collections.Originals] = _originals.Count,
                [Collections.Revisions] = _revisions.Values.Sum(l => l.Count),
                [Collections.Requests] = _requests.Count,
                [Collections.Drafts] = _drafts.Count,
                [Collections.Kits] = _kits.Count,
                [Collections.Feedback] = _feedback.Count,
                [Collections.Proposals] = _proposals.Values.Sum(l => l.Count),
                [Collections.Jobs] = _jobs.Count,
                [Collections.Audit] = _audit.Count,
                [Collections.Settings] = _settings.Values.Sum(l => l.Count),
                [Collections.Batches] = _batches.Count,
                [Collections.Campaigns] = _campaigns.Count,
                [Collections.Reviews] = _reviews.Count,
                [Collections.Pauses] = _pauses.Count,
                [Collections.Sessions] = _sessions.Count,
            }, ct);
        }

        // ------------------------------------------------------------------ plumbing
        /// <summary>
        /// After shutdown has begun, new reads and writes are refused as cancelled (callers already treat cancellation as
        /// normal), instead of failing with ObjectDisposedException: background work such as a HybridCache fetch or the warm-up
        /// can still be running when the container disposes this store.
        /// </summary>
        private void ThrowIfShutDown()
        {
            if (_disposed)
            {
                throw new OperationCanceledException("The workspace store has shut down.");
            }
        }

        private async Task<T> Read<T>(Func<T> fn, CancellationToken ct)
        {
            ThrowIfShutDown();
            await _gate.WaitAsync(ct);
            try
            {
                ThrowIfShutDown();
                return fn();
            }
            finally
            {
                _gate.Release();
            }
        }

        private async Task<T> Write<T>(Func<Task<T>> fn, CancellationToken ct)
        {
            ThrowIfShutDown();
            await _gate.WaitAsync(ct);
            try
            {
                ThrowIfShutDown();
                return await fn();
            }
            finally
            {
                _gate.Release();
            }
        }

        private static T Clone<T>(T value) => JsonSerializer.Deserialize<T>(JsonSerializer.Serialize(value, Json), Json)!;
        private volatile bool _disposed;

        public WorkspaceRepository(IDocumentStore docs, TimeProvider clock)
        {
            _docs = docs;
            _clock = clock;
        }

        /// <summary>
        /// Marks the store as shut down. The semaphore itself is not disposed: it never allocates a wait handle, and disposing
        /// it would make in-flight callers fail with ObjectDisposedException. A write already holding the gate finishes, so a
        /// record is never left half-written.
        /// </summary>
        public void Dispose() => _disposed = true;
    }
}
