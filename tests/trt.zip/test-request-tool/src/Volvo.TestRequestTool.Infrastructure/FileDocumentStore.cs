using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
namespace Volvo.TestRequestTool.Infrastructure
{
    /// <summary>
    /// The repository as folders and files: one folder per collection and one file per record, for example
    /// <c>vehicles\FH-333333.xml</c>, <c>requests\0f8f….json</c>, <c>drafts\alice\new-request.json</c>. Each collection is
    /// JSON unless Repository:Formats names XML for it. Switching a collection's format needs no migration: a record is read
    /// in whichever format it was written and rewritten in the new one on its next save.
    /// Writes go to a temporary file first and then replace the record, so a record is never half-written.
    /// </summary>
    public sealed class FileDocumentStore : IDocumentStore
    {
        private static readonly JsonSerializerOptions Indented = new() { WriteIndented = true };
        private readonly IReadOnlyDictionary<string, string> _formats;
        public string Root { get; }

        public FileDocumentStore(string root, IReadOnlyDictionary<string, string>? formats = null)
        {
            Root = Path.GetFullPath(root);
            Directory.CreateDirectory(Root);
            this._formats = formats is null ? new Dictionary<string, string>() : new Dictionary<string, string>(formats, StringComparer.OrdinalIgnoreCase);
            RemoveStaleTemporaryFiles();
        }

        public string Description => _formats.Values.Any(f => f.Equals("xml", StringComparison.OrdinalIgnoreCase)) ? $"Files (JSON, XML) in {Root}" : $"Files (JSON) in {Root}";
        /// <summary>"json" or "xml" for a collection ("vehicles" and "vehicles/…" share one setting).</summary>
        public string FormatOf(string collection) => _formats.TryGetValue(collection.Split('/')[0], out var f) && f.Equals("xml", StringComparison.OrdinalIgnoreCase) ? "xml" : "json";

        public async Task<IReadOnlyList<StoredDocument>> ListAsync(string collection, CancellationToken ct)
        {
            var folder = Folder(collection);
            if (!Directory.Exists(folder))
            {
                return [];
            }
            // One key may exist in both formats after a format change; the newer file wins.
            var files = Directory.EnumerateFiles(folder, "*.*", SearchOption.AllDirectories)
                .Where(f => f.EndsWith(".json", StringComparison.OrdinalIgnoreCase) || f.EndsWith(".xml", StringComparison.OrdinalIgnoreCase))
                .GroupBy(f => KeyOf(folder, f), StringComparer.Ordinal)
                .Select(g => g.OrderByDescending(File.GetLastWriteTimeUtc).First()).ToArray();
            var found = new StoredDocument[files.Length];
            // Many small files: read them in parallel (a cold disk or a network share answers each one slowly).
            await Parallel.ForEachAsync(Enumerable.Range(0, files.Length), new ParallelOptions { MaxDegreeOfParallelism = 16, CancellationToken = ct }, async (i, token) =>
                found[i] = new StoredDocument(KeyOf(folder, files[i]), await ReadAsync(files[i], token)));
            return found;
        }

        public async Task<JsonObject?> GetAsync(string collection, string key, CancellationToken ct)
        {
            var path = PathOf(collection, key, FormatOf(collection));
            if (File.Exists(path))
            {
                return await ReadAsync(path, ct);
            }

            var other = PathOf(collection, key, FormatOf(collection) == "xml" ? "json" : "xml");
            return File.Exists(other) ? await ReadAsync(other, ct) : null;
        }

        public async Task PutAsync(string collection, string key, JsonObject document, CancellationToken ct)
        {
            var format = FormatOf(collection);
            var path = PathOf(collection, key, format);
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            var text = format == "xml" ? ProductXmlCodec.Document(document, RootElement(collection)) : document.ToJsonString(Indented);
            var temporary = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
            try
            {
                await using (var stream = new FileStream(temporary, FileMode.CreateNew, FileAccess.Write, FileShare.None, 8192, true))
                {
                    await stream.WriteAsync(Encoding.UTF8.GetBytes(text), ct);
                    await stream.FlushAsync(ct);
                    stream.Flush(true);
                }
                await ReplaceAsync(temporary, path, ct);
            }
            finally
            {
                if (File.Exists(temporary))
                {
                    File.Delete(temporary);
                }
            }
            var stale = PathOf(collection, key, format == "xml" ? "json" : "xml");
            if (File.Exists(stale))
            {
                File.Delete(stale);
            }
        }

        public Task<bool> DeleteAsync(string collection, string key, CancellationToken ct)
        {
            var deleted = false;
            foreach (var format in new[] { "json", "xml" })
            {
                var path = PathOf(collection, key, format);
                if (File.Exists(path))
                {
                    File.Delete(path);
                    deleted = true;
                }
            }
            return Task.FromResult(deleted);
        }

        private static async Task<JsonObject> ReadAsync(string path, CancellationToken ct)
        {
            var text = await File.ReadAllTextAsync(path, ct);
            try
            {
                return path.EndsWith(".xml", StringComparison.OrdinalIgnoreCase) ? ProductXmlCodec.ReadDocument(text)
                    : JsonNode.Parse(text) as JsonObject ?? throw new InvalidDataException("Not a JSON object.");
            }
            catch (Exception e) when (e is JsonException or InvalidDataException or System.Xml.XmlException)
            {
                throw new InvalidDataException($"The repository file {path} cannot be read: {e.Message}", e);
            }
        }

        /// <summary>"vehicles" → Vehicle, "vehicle-revisions" → VehicleRevision: the XML root element.</summary>
        private static string RootElement(string collection)
        {
            var name = collection.Split('/')[0].TrimEnd('s');
            return string.Concat(name.Split('-', StringSplitOptions.RemoveEmptyEntries).Select(p => char.ToUpperInvariant(p[0]) + p[1..]));
        }

        private string Folder(string collection) => Path.Combine([Root, .. collection.Split('/').Select(Encode)]);
        private string PathOf(string collection, string key, string format) => Path.Combine([Folder(collection), .. key.Split('/').Select(Encode)]) + "." + format;

        private static string KeyOf(string folder, string file)
        {
            var relative = Path.GetRelativePath(folder, file);
            relative = relative[..^Path.GetExtension(relative).Length];
            return string.Join('/', relative.Split(Path.DirectorySeparatorChar).Select(Decode));
        }

        /// <summary>
        /// A key segment as a file name: letters, digits, "-", "_" and "." stay; anything else (":", "\", "|", spaces, …)
        /// becomes %XX, so every key maps to exactly one valid Windows file name and back.
        /// </summary>
        public static string Encode(string segment)
        {
            if (segment.Length == 0)
            {
                return "%";
            }

            var sb = new StringBuilder(segment.Length);
            foreach (var b in Encoding.UTF8.GetBytes(segment))
            {
                var c = (char)b;
                if (b < 128 && (char.IsAsciiLetterOrDigit(c) || c is '-' or '_' || (c == '.' && sb.Length > 0)))
                {
                    sb.Append(c);
                }
                else
                {
                    sb.Append('%').Append(b.ToString("X2", System.Globalization.CultureInfo.InvariantCulture));
                }
            }
            // Windows reserves CON, NUL, COM1 and so on, with or without an extension.
            var name = sb.ToString();
            var stem = name.Split('.')[0].ToUpperInvariant();
            if (stem is "CON" or "PRN" or "AUX" or "NUL" || (stem.Length == 4 && (stem.StartsWith("COM") || stem.StartsWith("LPT")) && char.IsDigit(stem[3])))
            {
                name = "%" + ((byte)name[0]).ToString("X2", System.Globalization.CultureInfo.InvariantCulture) + name[1..];
            }

            if (name.EndsWith('.'))
            {
                name = name[..^1] + "%2E";
            }

            return name;
        }

        public static string Decode(string name)
        {
            if (name == "%")
            {
                return "";
            }

            var bytes = new List<byte>(name.Length);
            for (var i = 0; i < name.Length; i++)
            {
                if (name[i] == '%' && i + 2 < name.Length)
                {
                    bytes.Add(Convert.ToByte(name.Substring(i + 1, 2), 16));
                    i += 2;
                }
                else
                {
                    bytes.AddRange(Encoding.UTF8.GetBytes(name[i].ToString()));
                }
            }
            return Encoding.UTF8.GetString(bytes.ToArray());
        }

        /// <summary>
        /// Replaces a file with its new copy. On Windows the replace can briefly fail with "access denied" or a sharing
        /// violation while another process (antivirus, search indexer, backup, an editor) has the file open; it is retried a
        /// few times with growing pauses (about 1.5 s in all) before the error is reported.
        /// </summary>
        public static async Task ReplaceAsync(string temporary, string target, CancellationToken ct, int attempts = 7)
        {
            for (var attempt = 1; ; attempt++)
            {
                try
                {
                    File.Move(temporary, target, true);
                    return;
                }
                catch (Exception e) when ((e is UnauthorizedAccessException || e is IOException) && attempt < attempts && File.Exists(temporary))
                {
                    await Task.Delay(TimeSpan.FromMilliseconds(25 * (1 << (attempt - 1))), ct);
                }
            }
        }

        /// <summary>A process stopped in the middle of a save leaves its temporary copy; copies older than ten minutes are removed.</summary>
        private void RemoveStaleTemporaryFiles()
        {
            var cutoff = DateTime.UtcNow - TimeSpan.FromMinutes(10);
            foreach (var f in Directory.EnumerateFiles(Root, "*.tmp", SearchOption.AllDirectories))
            {
                try
                {
                    if (File.GetLastWriteTimeUtc(f) < cutoff)
                    {
                        File.Delete(f);
                    }
                }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }
    }
}
