using System.Text.Json;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Infrastructure
{
    /// <summary>
    /// Fills a new repository and services folder with the reference data shipped with the app, once:
    /// <list type="bullet">
    /// <item>repository: the catalog sections (catalog\*.json) and the reference vehicles (vehicles\*.xml, plus their
    /// originals in vehicle-originals);</item>
    /// <item>services: the EDB specifications (edb\specifications\*.json) and CBR spare cab orders (cbr\orders\*.json), and an
    /// empty folder for each other service.</item>
    /// </list>
    /// A marker (repository\info.json) records that this happened, so records people delete later are not brought back.
    /// </summary>
    public static class RepositorySeeder
    {
        public const string Catalog = "catalog";
        private const string Marker = "repository";
        private static readonly JsonSerializerOptions Web = new(JsonSerializerDefaults.Web);
        /// <summary>The catalog sections that are external services' data, not reference data.</summary>
        private static readonly string[] ServiceSections = ["vehicles", "edbSpecs", "spareCabOrders"];

        /// <summary>The external services and their folders under the services path.</summary>
        public static readonly IReadOnlyDictionary<string, string> Services = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            ["EDB"] = "edb",
            ["CBR"] = "cbr",
            ["KAX"] = "kax",
            ["VESPA"] = "vespa",
            ["Dependix"] = "dependix",
            ["DigitalTwin"] = "digitaltwin",
        };

        public static async Task SeedRepositoryAsync(IDocumentStore repository, TimeProvider clock, CancellationToken ct)
        {
            if (await repository.GetAsync(Marker, "info", ct) is not null)
            {
                return;
            }

            var data = JsonCatalog.Embedded();
            if ((await repository.ListAsync(Catalog, ct)).Count == 0)
            {
                foreach (var (section, value) in data.Where(kv => !ServiceSections.Contains(kv.Key)).ToArray())
                {
                    await repository.PutAsync(Catalog, section, new JsonObject { ["items"] = value?.DeepClone() }, ct);
                }
            }

            if ((await repository.ListAsync(WorkspaceRepository.Collections.Vehicles, ct)).Count == 0)
            {
                foreach (var product in data.A("vehicles").Objects())
                {
                    var id = WorkspaceRepository.VehicleFile(new ProductDocument(product).Id);
                    await repository.PutAsync(WorkspaceRepository.Collections.Originals, id, (JsonObject)product.DeepClone(), ct);
                    await repository.PutAsync(WorkspaceRepository.Collections.Vehicles, id, (JsonObject)JsonSerializer.SerializeToNode(new VersionedProduct((JsonObject)product.DeepClone(), 1), Web)!, ct);
                }
            }

            await repository.PutAsync(Marker, "info", new JsonObject { ["schema"] = 1, ["created"] = clock.GetUtcNow().ToString("O"), ["note"] = "Filled with the reference data shipped with Test Request Tool." }, ct);
        }

        public static async Task SeedServicesAsync(string root, CancellationToken ct)
        {
            Directory.CreateDirectory(root);
            if (File.Exists(Path.Combine(root, "README.md")))
            {
                return;
            }

            var data = JsonCatalog.Embedded();
            foreach (var folder in Services.Values)
            {
                Directory.CreateDirectory(Path.Combine(root, folder));
            }

            await Write(Path.Combine(root, "edb", "specifications"), data["edbSpecs"] as JsonObject, ct);
            await Write(Path.Combine(root, "cbr", "orders"), data["spareCabOrders"] as JsonObject, ct);
            await File.WriteAllTextAsync(Path.Combine(root, "README.md"), Readme, ct);
        }

        private static async Task Write(string folder, JsonObject? items, CancellationToken ct)
        {
            Directory.CreateDirectory(folder);
            if (items is null)
            {
                return;
            }

            foreach (var (key, value) in items)
            {
                if (value is JsonObject o)
                {
                    await File.WriteAllTextAsync(Path.Combine(folder, FileDocumentStore.Encode(key) + ".json"), o.ToJsonString(new JsonSerializerOptions { WriteIndented = true }), ct);
                }
            }
        }

        private const string Readme = """
        # External services (file transport)

        Test Request Tool reaches every external service through its service layer. While a service's transport is
        "Files" (the default), its answers are files in this folder; set the transport to "Http" in the settings
        (Administration > Data and services, or Services:Endpoints in appsettings) to call the real service instead.

        Layout: <service>\<operation>\<key>.json (or .xml)

        | Service     | Folder       | Operations                                                      |
        |-------------|--------------|-----------------------------------------------------------------|
        | EDB         | edb          | specifications\<id>.json: an EDB specification                  |
        | CBR         | cbr          | orders\<order number>.json: a spare cab order                   |
        | KAX         | kax          | invoke: calls are written to invoke\outbox; reply.json answers  |
        | VESPA       | vespa        | invoke (as KAX)                                                 |
        | Dependix    | dependix     | invoke (as KAX)                                                 |
        | DigitalTwin | digitaltwin  | invoke (as KAX)                                                 |

        - Reading one item: <service>\<operation>\<key>.json. Missing file: "not found".
        - Sending something: the request is written to <service>\<operation>\outbox\<time>-<id>.json; the answer is
          <service>\<operation>\reply.json when it exists, otherwise a receipt naming the outbox file.
        - Listing: every file in <service>\<operation>.
        Keys use letters, digits, "-", "_" and "."; any other character is written as %XX in the file name.
        """;
    }
}
