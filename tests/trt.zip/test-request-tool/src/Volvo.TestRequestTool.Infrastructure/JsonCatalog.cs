using System.Collections.Frozen;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Infrastructure
{
    /// <summary>
    /// The reference data: contexts, factories, parameter definitions, variants, baselines, service packs, kits and node
    /// templates. It is read from the repository's catalog collection (one file per section, for example
    /// <c>catalog\templates.json</c>), or from the copy built into the app when the repository has none.
    /// </summary>
    public sealed class JsonCatalog : ICatalog
    {
        private readonly JsonObject _root;
        // The catalog never changes after start-up, so its lookups are built once as frozen dictionaries (.NET 8+, faster reads
        // than Dictionary at the cost of a slower build). Validation looks up every computer of every vehicle, so this replaces
        // a linear scan of all templates (and a clone of the whole template) per lookup.
        private readonly FrozenDictionary<string, JsonObject> _templatesByKey;
        private readonly FrozenDictionary<(string Key, int Doc), JsonObject> _versionsByDoc;
        private readonly FrozenDictionary<int, JsonObject[]> _templatesByContext;
        /// <summary>The catalog built into the app.</summary>
        public JsonCatalog() : this(Embedded()) { }
        /// <summary>The catalog from the repository (the catalog collection), or the built-in one when the repository has none.</summary>
        public JsonCatalog(IDocumentStore repository) : this(FromRepository(repository)) { }

        private JsonCatalog(JsonObject data)
        {
            _root = data;
            var templates = _root.A("templates").Objects().ToArray();
            _templatesByKey = templates.GroupBy(t => JsonAccess.NodeKey(t["identifier"]), StringComparer.Ordinal).ToFrozenDictionary(g => g.Key, g => g.First(), StringComparer.Ordinal);
            _versionsByDoc = _templatesByKey.SelectMany(t => t.Value.A("versions").Objects().Select(v => (Key: (t.Key, v.I("doc")), Version: v))).DistinctBy(x => x.Key).ToFrozenDictionary(x => x.Key, x => x.Version);
            _templatesByContext = templates.SelectMany(t => t.A("contexts").Select(c => (Context: int.TryParse(c?.ToString(), out var n) ? n : -1, Template: t))).GroupBy(x => x.Context).ToFrozenDictionary(g => g.Key, g => g.Select(x => x.Template).ToArray());
        }

        /// <summary>The reference data shipped with the app (also the source the repository is first filled from).</summary>
        public static JsonObject Embedded()
        {
            using var stream = typeof(JsonCatalog).Assembly.GetManifestResourceStream("Volvo.TestRequestTool.Infrastructure.Data.catalog.json") ?? throw new InvalidOperationException("Embedded catalog is missing.");
            return JsonNode.Parse(stream) as JsonObject ?? throw new InvalidOperationException("Invalid catalog.");
        }

        /// <summary>Each catalog file holds one section as {"items": ...}; the file name is the section name.</summary>
        private static JsonObject FromRepository(IDocumentStore repository)
        {
            // Start-up only, on a thread-pool thread without a synchronization context, so waiting here cannot deadlock.
            var sections = repository.ListAsync(RepositorySeeder.Catalog, CancellationToken.None).GetAwaiter().GetResult();
            if (sections.Count == 0)
            {
                return Embedded();
            }

            var data = new JsonObject();
            foreach (var s in sections.OrderBy(s => s.Key, StringComparer.Ordinal))
            {
                data[s.Key] = s.Document["items"]?.DeepClone();
            }

            return data;
        }

        public JsonObject Data => (JsonObject)_root.DeepClone();
        // Callers may change what they get, so results are still copies; only the search is faster.
        public JsonObject? FindTemplate(JsonObject node) => Clone(_templatesByKey.GetValueOrDefault(JsonAccess.NodeKeyOf(node)));
        public IReadOnlyList<JsonObject> Templates(int context) => _templatesByContext.TryGetValue(context, out var list) ? list.Select(t => (JsonObject)t.DeepClone()).ToArray() : [];
        public JsonObject? FindVersion(JsonObject node) => Clone(_versionsByDoc.GetValueOrDefault((JsonAccess.NodeKeyOf(node), node["nodeTemplateDocument"].I("number"))));
        private static JsonObject? Clone(JsonObject? o) => o is null ? null : (JsonObject)o.DeepClone();
    }
}
