using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Infrastructure
{
    /// <summary>An external capability (KAX, VESPA, Dependix, Digital Twin) reached through the service layer.</summary>
    public sealed class GatewayCapability : IExternalCapability
    {
        private readonly string _name;
        private readonly IServiceGateway _gateway;

        public GatewayCapability(string name, IServiceGateway gateway)
        {
            _name = name;
            _gateway = gateway;
        }

        public string Name => _name;
        public bool IsConfigured => _gateway.IsConfigured(_name);

        public async Task<JsonObject> InvokeAsync(JsonObject payload, CancellationToken ct)
        {
            if (!IsConfigured)
            {
                throw new RequestFault(501, "integration_not_configured", $"{_name} is turned off in the service settings.");
            }

            return (await _gateway.CallAsync(new ServiceCall(_name, "invoke", null, payload), ct)).Body;
        }
    }
}
