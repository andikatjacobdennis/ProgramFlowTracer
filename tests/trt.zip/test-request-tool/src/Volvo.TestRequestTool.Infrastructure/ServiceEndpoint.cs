namespace Volvo.TestRequestTool.Infrastructure
{
    /// <summary>How one service is reached: Files (a folder), Http (a base URL) or Off.</summary>
    public sealed class ServiceEndpoint
    {
        public string Transport { get; set; } = "Files";
        /// <summary>Http: the service's base address, for example https://edb.example.com/api.</summary>
        public string? BaseUrl { get; set; }
        /// <summary>Files: a folder under Services:Path other than the default (the service's name in lower case).</summary>
        public string? Folder { get; set; }
        public int TimeoutSeconds { get; set; } = 30;
    }
}
