using System.Collections.Concurrent;
using System.Collections.Frozen;
using System.Globalization;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using Volvo.TestRequestTool.Application;

namespace Volvo.TestRequestTool.Infrastructure
{
    /// <summary>
    /// The listener's message types and their XSDs, built into the assembly from <c>Contracts/listener.json</c> and
    /// <c>Contracts/Schemas</c> (scripts/import-contracts.py writes both). Each contract file is compiled once, on first use,
    /// into its own schema set: several versions of a contract share a namespace, so they cannot live in one set. Includes
    /// and imports resolve to the built-in files only; nothing is read from disk or the network.
    /// </summary>
    public sealed partial class ListenerContracts : IListenerContracts
    {
        private const string Prefix = "Contracts/";
        private const int MaxErrors = 50;
        private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);
        private readonly FrozenDictionary<string, ListenerMessageType> _byKey;
        private readonly ConcurrentDictionary<string, XmlSchemaSet> _sets = new(StringComparer.Ordinal);
        private readonly ListenerSamples _samples = new();

        public ListenerContracts()
        {
            using var stream = Open("listener.json") ?? throw new InvalidOperationException("The listener registry is missing.");
            var registry = JsonSerializer.Deserialize<Registry>(stream, Json) ?? throw new InvalidOperationException("The listener registry is empty.");
            MessageTypes = registry.Messages;
            _byKey = registry.Messages.ToFrozenDictionary(m => m.Key, StringComparer.Ordinal);
        }

        public IReadOnlyList<ListenerMessageType> MessageTypes { get; }

        public ListenerMessageType? Find(string messageType, string version) => _byKey.GetValueOrDefault(messageType + "_" + version);

        public IReadOnlyList<string> Validate(ListenerContract contract, XDocument document)
        {
            var set = SetFor(contract);
            var root = document.Root;
            var expected = XName.Get(contract.Root!, contract.Namespace ?? string.Empty);
            if (root is null || root.Name != expected)
            {
                return [$"The root element is {(root is null ? "missing" : Show(root.Name))}; {contract.File} starts with {Show(expected)}."];
            }

            var errors = new List<string>();
            lock (set)
            {
                document.Validate(set, (_, e) =>
                {
                    if (errors.Count < MaxErrors)
                    {
                        var line = e.Exception?.LineNumber > 0 ? $"Line {e.Exception.LineNumber}: " : string.Empty;
                        errors.Add(line + e.Message);
                    }
                }, addSchemaInfo: false);
            }

            return errors;
        }

        public XDocument Sample(ListenerContract contract)
        {
            var set = SetFor(contract);
            var element = set.GlobalElements[new XmlQualifiedName(contract.Root, contract.Namespace)] as XmlSchemaElement
                ?? throw new InvalidOperationException($"{contract.File} has no element {contract.Root}.");
            lock (set)
            {
                return new XDocument(new XDeclaration("1.0", "utf-8", null), _samples.Element(element, set));
            }
        }

        public string? Schema(string file)
        {
            if (!IsSchemaName(file))
            {
                return null;
            }

            using var stream = Open("Schemas/" + file);
            if (stream is null)
            {
                return null;
            }

            using var reader = new StreamReader(stream);
            return reader.ReadToEnd();
        }

        private XmlSchemaSet SetFor(ListenerContract contract)
        {
            if (!contract.CanValidate)
            {
                throw new InvalidOperationException("The contract has no XSD.");
            }

            return _sets.GetOrAdd(contract.File!, Compile);
        }

        private static XmlSchemaSet Compile(string file)
        {
            var resolver = new BuiltInResolver();
            var set = new XmlSchemaSet { XmlResolver = resolver };
            var settings = new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = resolver };
            using var stream = Open("Schemas/" + file) ?? throw new InvalidOperationException($"The contract {file} is missing.");
            using var reader = XmlReader.Create(stream, settings, BuiltInResolver.Base + file);
            set.Add(null, reader);
            set.Compile();
            return set;
        }

        private static bool IsSchemaName(string file) =>
            file.EndsWith(".xsd", StringComparison.OrdinalIgnoreCase) && file.IndexOfAny(['/', '\\', ':']) < 0 && !file.Contains("..", StringComparison.Ordinal);

        private static Stream? Open(string name) => typeof(ListenerContracts).Assembly.GetManifestResourceStream(Prefix + name);

        private static string Show(XName name) => name.NamespaceName.Length == 0 ? name.LocalName : $"{name.LocalName} ({name.NamespaceName})";

        private static readonly string[] SchemaFiles = typeof(ListenerContracts).Assembly.GetManifestResourceNames()
            .Where(n => n.StartsWith(Prefix + "Schemas/", StringComparison.Ordinal)).Select(n => n[(Prefix.Length + "Schemas/".Length)..]).ToArray();

        // Name_major.minor.patch-Final.xsd: group 1 is the name and major.minor with the dot after it, group 2 the patch.
        [GeneratedRegex(@"^(.+_\d+\.\d+\.)(\d+)(-[A-Za-z0-9]+)?\.xsd$")]
        private static partial Regex PatchRelease();

        private sealed record Registry(IReadOnlyList<ListenerMessageType> Messages);

        /// <summary>Resolves schemaLocation to the XSDs built into the assembly, and refuses everything else.</summary>
        private sealed class BuiltInResolver : XmlResolver
        {
            public const string Base = "contracts:///";

            public override object? GetEntity(Uri absoluteUri, string? role, Type? ofObjectToReturn)
            {
                var file = Path.GetFileName(absoluteUri.AbsolutePath);
                if (absoluteUri.Scheme != "contracts" || !IsSchemaName(file))
                {
                    throw new XmlException($"Only the built-in contracts can be included, not {absoluteUri}.");
                }

                return Open("Schemas/" + file) ?? Open("Schemas/" + Substitute(file)) ?? throw new XmlException($"The contract {file} is not built in.");
            }

            /// <summary>
            /// A few contracts import a patch release that is not among the files (ReleaseNotes_1.0.0, BreakdownModuleCommon_1.5.0).
            /// SchemaSet.cs adds the namespace from the newest patch of the same version instead, and so does this: the same name
            /// and major.minor, the highest patch.
            /// </summary>
            private static string Substitute(string file)
            {
                var m = PatchRelease().Match(file);
                if (!m.Success)
                {
                    return file;
                }

                var prefix = m.Groups[1].Value;
                return SchemaFiles.Where(f => f.StartsWith(prefix, StringComparison.Ordinal) && PatchRelease().IsMatch(f))
                    .OrderByDescending(f => int.Parse(PatchRelease().Match(f).Groups[2].Value, CultureInfo.InvariantCulture))
                    .FirstOrDefault() ?? file;
            }

            public override Uri ResolveUri(Uri? baseUri, string? relativeUri) => new(baseUri ?? new Uri(Base), relativeUri ?? string.Empty);
        }
    }
}
