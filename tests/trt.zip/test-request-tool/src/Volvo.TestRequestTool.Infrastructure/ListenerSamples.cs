using System.Text.RegularExpressions;
using System.Xml.Linq;
using System.Xml.Schema;

namespace Volvo.TestRequestTool.Infrastructure
{
    /// <summary>
    /// Writes the smallest document a compiled XSD accepts: every required element and attribute, the first branch of each
    /// choice, and an example value for each simple type (the first enumeration value, a value for each pattern the
    /// contracts use, otherwise a value of the base type within its length and range limits). It is a starting point to
    /// edit, not a meaningful request: optional content (the nodes, kits or products to ask about) is left out.
    /// </summary>
    public sealed class ListenerSamples
    {
        private const int MaxDepth = 40;

        // One example per pattern in the contracts (scripts/import-contracts.py lists them when they change).
        private static readonly Dictionary<string, string> Patterns = new(StringComparer.Ordinal)
        {
            [@"[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}"] = "00000000-0000-0000-0000-000000000001",
            [@"[\da-fA-F]{8}-[\da-fA-F]{4}-[\da-fA-F]{4}-[\da-fA-F]{4}-[\da-fA-F]{12}"] = "00000000-0000-0000-0000-000000000001",
            [@"\{[a-fA-F0-9]{8}-([a-fA-F0-9]{4}-){3}[a-fA-F0-9]{12}\}"] = "{00000000-0000-0000-0000-000000000001}",
            [@"[A-Z0-9][A-Z0-9' ']{4}"] = "FH   ",
            [@"[0-9]{6}"] = "333333",
            [@"[K][0-9]{7}"] = "K0000001",
            [@"\d+\.\d+"] = "1.0",
            [@"\d\.\d"] = "1.0",
            [@"[a-zA-Z_][a-zA-Z0-9_]*"] = "Example",
            [@"[A-Z0-9]{2,5}"] = "EMS",
            [@"[A-Z0-9]{2,5}((\[\d+\]|\.[a-zA-Z_][a-zA-Z0-9_]*)*(\[\d+\]|(\.|:)[a-zA-Z_][a-zA-Z0-9_]*))?"] = "EMS",
            [@"2[0-9]{5}"] = "200001",
            [@"\d{2}"] = "01",
            [@"[0-9]{3}"] = "001",
            [@"[0-9]{4}"] = "0001",
            [@"\d{7,8}"] = "1234567",
            [@"/(\d+.\d+.\d+/)*"] = "/",
            [@"\-?P(\d*D)?(T(\d*H)?(\d*M)?(\d*(\.\d*)?S)?)?"] = "PT0S",
            [@"[a-z]{2}\-[a-z]{2}"] = "en-gb",
            [@"[A-Z0-9]+"] = "A1",
        };

        public XElement Element(XmlSchemaElement element, XmlSchemaSet set) => Element(element, set, 0);

        private XElement Element(XmlSchemaElement element, XmlSchemaSet set, int depth)
        {
            if (element.ElementSchemaType is null && !element.RefName.IsEmpty && set.GlobalElements[element.RefName] is XmlSchemaElement global)
            {
                element = global;
            }

            var name = XName.Get(element.QualifiedName.Name, element.QualifiedName.Namespace);
            var x = new XElement(name);
            if (element.FixedValue is not null || element.DefaultValue is not null)
            {
                x.Value = element.FixedValue ?? element.DefaultValue!;
                return x;
            }

            switch (element.ElementSchemaType)
            {
                case XmlSchemaSimpleType simple:
                    x.Value = Value(simple);
                    break;
                case XmlSchemaComplexType complex:
                    foreach (var use in complex.AttributeUses.Values.OfType<XmlSchemaAttribute>().Where(a => a.Use == XmlSchemaUse.Required))
                    {
                        x.SetAttributeValue(XName.Get(use.QualifiedName.Name, use.QualifiedName.Namespace), use.FixedValue ?? use.DefaultValue ?? Value(use.AttributeSchemaType));
                    }

                    if (complex.ContentType == XmlSchemaContentType.TextOnly)
                    {
                        x.Value = Value(SimpleBase(complex));
                    }
                    else if (depth < MaxDepth)
                    {
                        Particle(complex.ContentTypeParticle, x, set, depth + 1);
                    }

                    break;
            }

            return x;
        }

        private void Particle(XmlSchemaParticle? particle, XElement parent, XmlSchemaSet set, int depth)
        {
            if (particle is null || particle.MinOccurs == 0)
            {
                return;
            }

            for (var i = 0; i < (int)Math.Min(particle.MinOccurs, 3); i++)
            {
                switch (particle)
                {
                    case XmlSchemaElement element when !element.IsAbstract:
                        parent.Add(Element(element, set, depth));
                        break;
                    case XmlSchemaSequence sequence:
                        foreach (var item in sequence.Items.OfType<XmlSchemaParticle>())
                        {
                            Particle(item, parent, set, depth);
                        }

                        break;
                    case XmlSchemaAll all:
                        foreach (var item in all.Items.OfType<XmlSchemaParticle>())
                        {
                            Particle(item, parent, set, depth);
                        }

                        break;
                    case XmlSchemaChoice choice:
                        // The first branch that can be written; an optional branch already satisfies the choice.
                        var first = choice.Items.OfType<XmlSchemaParticle>().FirstOrDefault(p => p is not XmlSchemaAny && p is not XmlSchemaElement { IsAbstract: true });
                        Particle(first, parent, set, depth);
                        break;
                }
            }
        }

        private static XmlSchemaSimpleType? SimpleBase(XmlSchemaComplexType complex)
        {
            XmlSchemaType? type = complex;
            while (type is not null and not XmlSchemaSimpleType)
            {
                type = type.BaseXmlSchemaType;
            }

            return type as XmlSchemaSimpleType;
        }

        /// <summary>An example value of a simple type: the facets of its whole restriction chain decide it.</summary>
        private static string Value(XmlSchemaSimpleType? type)
        {
            if (type is null)
            {
                return "Example";
            }

            if (type.Content is XmlSchemaSimpleTypeUnion union)
            {
                return Value(union.BaseMemberTypes?.FirstOrDefault());
            }

            if (type.Content is XmlSchemaSimpleTypeList list)
            {
                return Value(list.BaseItemType);
            }

            var facets = new List<XmlSchemaFacet>();
            for (var t = type; t is not null; t = t.BaseXmlSchemaType as XmlSchemaSimpleType)
            {
                if (t.Content is XmlSchemaSimpleTypeRestriction r)
                {
                    facets.AddRange(r.Facets.OfType<XmlSchemaFacet>());
                }
            }

            var enumeration = facets.OfType<XmlSchemaEnumerationFacet>().FirstOrDefault();
            if (enumeration?.Value is not null)
            {
                return enumeration.Value;
            }

            var pattern = facets.OfType<XmlSchemaPatternFacet>().Select(p => p.Value).FirstOrDefault(p => p is not null);
            if (pattern is not null && Patterns.TryGetValue(pattern, out var matching))
            {
                return matching;
            }

            string? Facet<T>() where T : XmlSchemaFacet => facets.OfType<T>().Select(f => f.Value).FirstOrDefault();
            var value = type.Datatype?.TypeCode switch
            {
                XmlTypeCode.Boolean => "false",
                XmlTypeCode.DateTime => "2026-01-01T00:00:00Z",
                XmlTypeCode.Date => "2026-01-01",
                XmlTypeCode.Time => "00:00:00",
                XmlTypeCode.GYear => "2026",
                XmlTypeCode.Duration => "PT0S",
                XmlTypeCode.Base64Binary => "AA==",
                XmlTypeCode.HexBinary => "00",
                XmlTypeCode.AnyUri => "urn:example",
                XmlTypeCode.Decimal or XmlTypeCode.Double or XmlTypeCode.Float => Number(Facet<XmlSchemaMinInclusiveFacet>(), Facet<XmlSchemaMinExclusiveFacet>(), 1),
                XmlTypeCode.Integer or XmlTypeCode.Int or XmlTypeCode.Long or XmlTypeCode.Short or XmlTypeCode.Byte
                    or XmlTypeCode.NonNegativeInteger or XmlTypeCode.PositiveInteger or XmlTypeCode.UnsignedInt or XmlTypeCode.UnsignedLong
                    or XmlTypeCode.UnsignedShort or XmlTypeCode.UnsignedByte => Number(Facet<XmlSchemaMinInclusiveFacet>(), Facet<XmlSchemaMinExclusiveFacet>(), 1),
                XmlTypeCode.NonPositiveInteger or XmlTypeCode.NegativeInteger => "-1",
                _ => Text(Facet<XmlSchemaLengthFacet>(), Facet<XmlSchemaMinLengthFacet>(), Facet<XmlSchemaMaxLengthFacet>()),
            };

            // A pattern without an example of its own: keep the value only when it matches (the check will say if not).
            return pattern is null || Regex.IsMatch(value, "^(?:" + pattern + ")$") ? value : string.Empty;
        }

        private static string Number(string? minInclusive, string? minExclusive, int fallback)
        {
            if (decimal.TryParse(minInclusive, System.Globalization.CultureInfo.InvariantCulture, out var min))
            {
                return Math.Max(min, fallback).ToString(System.Globalization.CultureInfo.InvariantCulture);
            }

            if (decimal.TryParse(minExclusive, System.Globalization.CultureInfo.InvariantCulture, out var above))
            {
                return Math.Max(Math.Floor(above) + 1, fallback).ToString(System.Globalization.CultureInfo.InvariantCulture);
            }

            return fallback.ToString(System.Globalization.CultureInfo.InvariantCulture);
        }

        private static string Text(string? length, string? minLength, string? maxLength)
        {
            const string Example = "Example";
            if (int.TryParse(length, out var exact))
            {
                return Example.PadRight(exact, 'X')[..exact];
            }

            var text = Example;
            if (int.TryParse(minLength, out var min) && text.Length < min)
            {
                text = text.PadRight(min, 'X');
            }

            if (int.TryParse(maxLength, out var max) && text.Length > max)
            {
                text = text[..max];
            }

            return text;
        }
    }
}
