using System.Net;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Infrastructure
{
    /// <summary>
    /// The service layer. Each call goes to the transport the settings name for that service, read on every call, so a
    /// change in the settings applies to the next call without a restart.
    /// <list type="bullet">
    /// <item><b>Files</b>: read &lt;folder&gt;\&lt;operation&gt;\&lt;key&gt;.json (or .xml); a call with a body is written to
    /// &lt;operation&gt;\outbox and answered by &lt;operation&gt;\reply.json when it exists; no key and no body lists the operation's files.</item>
    /// <item><b>Http</b>: GET {BaseUrl}/{operation}/{key}, POST {BaseUrl}/{operation} with the body, GET {BaseUrl}/{operation} to list.</item>
    /// <item><b>Off</b>: every call fails with 503.</item>
    /// </list>
    /// </summary>
    public sealed class ServiceGateway : IServiceGateway
    {
        private readonly Func<ServiceSettings> _settings;
        private readonly HttpClient _client;

        public ServiceGateway(Func<ServiceSettings> settings, HttpClient? http = null)
        {
            _settings = settings;
            _client = http ?? new HttpClient(new SocketsHttpHandler { PooledConnectionLifetime = TimeSpan.FromMinutes(5) }) { Timeout = Timeout.InfiniteTimeSpan };
        }

        public bool IsConfigured(string service)
        {
            var s = _settings();
            var e = s.For(service);
            return e.Transport.ToLowerInvariant() switch
            {
                "files" => Directory.Exists(s.FolderOf(service)),
                "http" => Uri.TryCreate(e.BaseUrl, UriKind.Absolute, out _),
                _ => false,
            };
        }

        public Task<ServiceReply> CallAsync(ServiceCall call, CancellationToken ct)
        {
            var s = _settings();
            var e = s.For(call.Service);
            return e.Transport.ToLowerInvariant() switch
            {
                "files" => FilesAsync(s.FolderOf(call.Service), call, ct),
                "http" => HttpAsync(e, call, ct),
                "off" => throw new RequestFault(503, "service_off", $"{call.Service} is turned off in the service settings."),
                _ => throw new RequestFault(503, "service_transport", $"{call.Service} has an unknown transport \"{e.Transport}\". Use Files, Http or Off."),
            };
        }

        private static async Task<ServiceReply> FilesAsync(string folder, ServiceCall call, CancellationToken ct)
        {
            if (!Directory.Exists(folder))
            {
                throw new RequestFault(503, "service_unavailable", $"{call.Service} is not set up: the folder {folder} does not exist.");
            }

            var operation = Path.Combine(folder, FileDocumentStore.Encode(call.Operation));
            if (call.Body is not null)
            {
                var outbox = Path.Combine(operation, "outbox");
                Directory.CreateDirectory(outbox);
                var file = Path.Combine(outbox, $"{DateTime.UtcNow:yyyyMMdd'T'HHmmssfff}-{Guid.NewGuid():N}.json");
                await File.WriteAllTextAsync(file, call.Body.ToJsonString(new JsonSerializerOptions { WriteIndented = true }), ct);
                var reply = Path.Combine(operation, "reply.json");
                return File.Exists(reply) ? new(await ReadAsync(reply, ct), "Files: " + reply)
                    : new(new JsonObject { ["accepted"] = true, ["file"] = file }, "Files: " + file);
            }
            if (call.Key is null)
            {
                var items = new JsonArray();
                if (Directory.Exists(operation))
                {
                    foreach (var f in Directory.EnumerateFiles(operation).Where(f => f.EndsWith(".json", StringComparison.OrdinalIgnoreCase) || f.EndsWith(".xml", StringComparison.OrdinalIgnoreCase)).Order(StringComparer.Ordinal))
                    {
                        items.Add(await ReadAsync(f, ct));
                    }
                }

                return new(new JsonObject { ["items"] = items }, "Files: " + operation);
            }
            foreach (var ext in new[] { ".json", ".xml" })
            {
                var path = Path.Combine(operation, FileDocumentStore.Encode(call.Key) + ext);
                if (File.Exists(path))
                {
                    return new(await ReadAsync(path, ct), "Files: " + path);
                }
            }
            throw new RequestFault(404, "service_item_missing", $"{call.Service} has no {call.Operation} \"{call.Key}\".");
        }

        private static async Task<JsonObject> ReadAsync(string path, CancellationToken ct)
        {
            var text = await File.ReadAllTextAsync(path, ct);
            try
            {
                if (path.EndsWith(".xml", StringComparison.OrdinalIgnoreCase))
                {
                    return ProductXmlCodec.ReadDocument(text);
                }

                return JsonNode.Parse(text) switch { JsonObject o => o, JsonArray a => new JsonObject { ["items"] = a }, _ => throw new InvalidDataException("Not a JSON object.") };
            }
            catch (Exception e) when (e is JsonException or InvalidDataException or System.Xml.XmlException)
            {
                throw new RequestFault(502, "service_answer_invalid", $"The service file {path} cannot be read: {e.Message}");
            }
        }

        private async Task<ServiceReply> HttpAsync(ServiceEndpoint e, ServiceCall call, CancellationToken ct)
        {
            if (!Uri.TryCreate((e.BaseUrl ?? "").TrimEnd('/') + "/", UriKind.Absolute, out var root))
            {
                throw new RequestFault(503, "service_address", $"{call.Service} has no valid base URL in the service settings.");
            }

            var url = new Uri(root, Uri.EscapeDataString(call.Operation) + (call.Key is null ? "" : "/" + Uri.EscapeDataString(call.Key)));
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
            timeout.CancelAfter(TimeSpan.FromSeconds(Math.Clamp(e.TimeoutSeconds, 1, 300)));
            try
            {
                using var response = call.Body is null ? await _client.GetAsync(url, timeout.Token) : await _client.PostAsJsonAsync(url, call.Body, timeout.Token);
                if (response.StatusCode == HttpStatusCode.NotFound)
                {
                    throw new RequestFault(404, "service_item_missing", $"{call.Service} has no {call.Operation} \"{call.Key}\".");
                }

                if (!response.IsSuccessStatusCode)
                {
                    throw new RequestFault(502, "service_failed", $"{call.Service} answered {(int)response.StatusCode} {response.ReasonPhrase}.");
                }

                var node = await response.Content.ReadFromJsonAsync<JsonNode>(timeout.Token);
                var body = node switch { JsonObject o => o, JsonArray a => new JsonObject { ["items"] = a }, null => new JsonObject(), _ => new JsonObject { ["value"] = node } };
                return new(body, "Http: " + url);
            }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested)
            {
                throw new RequestFault(503, "service_timeout", $"{call.Service} did not answer within {e.TimeoutSeconds} s.");
            }
            catch (HttpRequestException x)
            {
                throw new RequestFault(503, "service_unreachable", $"{call.Service} cannot be reached: {x.Message}");
            }
            catch (JsonException)
            {
                throw new RequestFault(502, "service_answer_invalid", $"{call.Service} did not answer with JSON.");
            }
        }
    }
}
