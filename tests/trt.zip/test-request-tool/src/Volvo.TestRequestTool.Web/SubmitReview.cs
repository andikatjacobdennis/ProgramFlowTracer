namespace Volvo.TestRequestTool.Web
{
    public sealed record SubmitReview(bool Confirmed);
}
