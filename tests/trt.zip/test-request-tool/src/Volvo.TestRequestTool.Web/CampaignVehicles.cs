using Volvo.TestRequestTool.Application;

namespace Volvo.TestRequestTool.Web
{
    public sealed record CampaignVehicles([property: System.ComponentModel.DataAnnotations.MaxLength(CampaignService.MaxVehicles)] string[]? VehicleIds, long Version);
}
