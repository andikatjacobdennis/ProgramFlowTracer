namespace Volvo.TestRequestTool.Web
{
    /// <summary>One account in the user list.</summary>
    public sealed record UserRow(string Id, string DisplayName, string Role, int[] Contexts, bool Enabled, string? Country, string? Email, DateTimeOffset? LastSignIn);
}
