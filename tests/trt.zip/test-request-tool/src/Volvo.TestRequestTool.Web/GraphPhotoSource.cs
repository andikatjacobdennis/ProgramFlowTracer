using System.Collections.Concurrent;
using System.Net;
using System.Net.Http.Headers;
using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Microsoft Entra ID / Microsoft 365: the photo from Microsoft Graph (GET /me/photos/{size}/$value) with the delegated
    /// <c>User.Read</c> permission only. The API exchanges the caller's access token for a Graph token with the
    /// on-behalf-of flow; Graph tokens are cached per user in memory until shortly before they expire and are never written to
    /// a log, a URL or the response. Configuration: Graph:Enabled=true, AzureAd:TenantId, AzureAd:ClientId and
    /// AzureAd:ClientSecret (from a secret store), and Graph:Scope (default https://graph.microsoft.com/User.Read).
    /// </summary>
    public sealed class GraphPhotoSource : IProfilePhotoSource
    {
        private readonly IHttpClientFactory _http;
        private readonly IConfiguration _config;
        private readonly TimeProvider _clock;
        private readonly ILogger<GraphPhotoSource> _log;
        public string Name => "Microsoft Graph";
        public static readonly int[] Sizes = [48, 64, 96, 120, 240, 360, 432, 504, 648];
        private readonly ConcurrentDictionary<string, (string Token, DateTimeOffset Until)> _tokens = new(StringComparer.Ordinal);

        public GraphPhotoSource(IHttpClientFactory http, IConfiguration config, TimeProvider clock, ILogger<GraphPhotoSource> log)
        {
            _http = http;
            _config = config;
            _clock = clock;
            _log = log;
        }

        public async Task<PhotoResult> GetAsync(HttpContext ctx, int size, CancellationToken ct)
        {
            var user = ActorFactory.From(ctx.User).Id;
            var incoming = ctx.Request.Headers.Authorization.ToString();
            if (!incoming.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            {
                return PhotoResult.Forbidden;   // no delegated identity to act for
            }

            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
            timeout.CancelAfter(TimeSpan.FromSeconds(5));
            try
            {
                var token = await GraphTokenAsync(user, incoming["Bearer ".Length..].Trim(), timeout.Token);
                if (token is null)
                {
                    return PhotoResult.Forbidden;
                }

                var client = _http.CreateClient("graph");
                using var request = new HttpRequestMessage(HttpMethod.Get, $"https://graph.microsoft.com/v1.0/me/photos/{size}x{size}/$value");
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
                using var response = await client.SendAsync(request, timeout.Token);
                return response.StatusCode switch
                {
                    HttpStatusCode.OK => new("ok", await response.Content.ReadAsByteArrayAsync(timeout.Token), response.Content.Headers.ContentType?.MediaType ?? "image/jpeg"),
                    HttpStatusCode.NotFound => PhotoResult.None,
                    HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden => PhotoResult.Forbidden,
                    _ => PhotoResult.Unavailable,
                };
            }
            catch (Exception e) when (e is HttpRequestException or OperationCanceledException && !ct.IsCancellationRequested)
            {
                _log.LogWarning("Profile photo lookup failed: {Kind}", e.GetType().Name);   // the type only: no tokens, no URLs with secrets
                return PhotoResult.Unavailable;
            }
        }

        private async Task<string?> GraphTokenAsync(string user, string assertion, CancellationToken ct)
        {
            if (_tokens.TryGetValue(user, out var cached) && cached.Until > _clock.GetUtcNow())
            {
                return cached.Token;
            }

            var tenant = _config["AzureAd:TenantId"];
            var clientId = _config["AzureAd:ClientId"];
            var secret = _config["AzureAd:ClientSecret"];
            if (string.IsNullOrWhiteSpace(tenant) || string.IsNullOrWhiteSpace(clientId) || string.IsNullOrWhiteSpace(secret))
            {
                return null;
            }

            var instance = (_config["AzureAd:Instance"] ?? "https://login.microsoftonline.com/").TrimEnd('/');
            var form = new FormUrlEncodedContent(new Dictionary<string, string>
            {
                ["grant_type"] = "urn:ietf:params:oauth:grant-type:jwt-bearer",
                ["client_id"] = clientId,
                ["client_secret"] = secret,
                ["assertion"] = assertion,
                ["scope"] = _config["Graph:Scope"] ?? "https://graph.microsoft.com/User.Read",
                ["requested_token_use"] = "on_behalf_of",
            });
            using var response = await _http.CreateClient("graph").PostAsync($"{instance}/{Uri.EscapeDataString(tenant)}/oauth2/v2.0/token", form, ct);
            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            var body = JsonNode.Parse(await response.Content.ReadAsStringAsync(ct));
            var token = body?["access_token"]?.ToString();
            if (token is null)
            {
                return null;
            }

            var seconds = body?["expires_in"]?.GetValue<int>() ?? 300;
            _tokens[user] = (token, _clock.GetUtcNow().AddSeconds(Math.Max(30, seconds - 60)));
            return token;
        }
    }
}
