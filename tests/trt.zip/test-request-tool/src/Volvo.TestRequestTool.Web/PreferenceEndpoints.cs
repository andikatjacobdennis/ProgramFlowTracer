using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Preferences that follow a person across sessions and devices, stored per authenticated user. The key comes only from
    /// the signed-in identity, so nobody can read or change another person's preferences (there is no user id in the route).
    /// Today: navigation (sidebar mode and auto-hide). Values are checked; anything unknown is refused.
    /// </summary>
    public static class PreferenceEndpoints
    {
        public static readonly string[] NavigationModes = ["menubar", "expanded", "compact", "hidden"];
        private static string Key(HttpContext ctx) => "user-prefs:" + ActorFactory.From(ctx.User).Id;
        private static string Name(HttpContext ctx) => ctx.User.Identity?.Name ?? ActorFactory.From(ctx.User).Id;

        public static RouteGroupBuilder MapPreferences(this RouteGroupBuilder api)
        {
            var me = api.MapGroup("/me/preferences").WithTags("Settings");
            me.MapGet("/", async (HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
                (await store.SettingAsync(Key(ctx), ct))?.Value ?? new JsonObject())
                .WithSummary("Your saved preferences (for example navigation), the same on every device you sign in on.");

            me.MapPut("/navigation", async (NavigationPreference body, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                if (body.Mode is not null && !NavigationModes.Contains(body.Mode))
                {
                    throw new RequestFault(400, "navigation_mode", "Mode must be menubar, expanded, compact or hidden.");
                }

                var current = (await store.SettingAsync(Key(ctx), ct))?.Value ?? new JsonObject();
                var nav = current["navigation"] as JsonObject ?? new JsonObject();
                if (body.Mode is not null)
                {
                    nav["mode"] = body.Mode;
                }

                if (body.AutoHide is not null)
                {
                    nav["autoHide"] = body.AutoHide;
                }

                nav["updatedAt"] = DateTimeOffset.UtcNow;
                current["navigation"] = nav.DeepClone();
                await store.SaveSettingAsync(Key(ctx), current, ActorFactory.From(ctx.User).Id, Name(ctx), "Navigation preference", ct);
                return nav;
            }).WithSummary("Save your navigation mode (menubar, expanded, compact or hidden) and auto-hide.");

            me.MapDelete("/navigation", async (HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                var current = (await store.SettingAsync(Key(ctx), ct))?.Value ?? new JsonObject();
                if (current.Remove("navigation"))
                {
                    await store.SaveSettingAsync(Key(ctx), current, ActorFactory.From(ctx.User).Id, Name(ctx), "Navigation preferences reset", ct);
                }

                return Results.NoContent();
            }).WithSummary("Reset navigation preferences to the defaults (the menu bar on desktop, a hidden drawer on mobile, auto-hide on).");

            // The spelling checker's personal dictionary: words you chose to ignore. Yours only, on every device.
            me.MapPut("/dictionary", async (DictionaryBody body, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                var words = (body.Words ?? []).Select(w => w?.Trim() ?? "").Where(w => w.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
                if (words.Length > 2000)
                {
                    throw new RequestFault(413, "dictionary_full", "A personal dictionary holds up to 2,000 words.");
                }

                if (words.Any(w => w.Length > 40 || !w.All(c => char.IsLetter(c) || c is '\'' or '-')))
                {
                    throw new RequestFault(400, "dictionary_word", "Words may contain letters, hyphens and apostrophes only (up to 40 characters).");
                }

                var current = (await store.SettingAsync(Key(ctx), ct))?.Value ?? new JsonObject();
                current["dictionary"] = new JsonArray(words.Order(StringComparer.OrdinalIgnoreCase).Select(w => (JsonNode)w).ToArray());
                await store.SaveSettingAsync(Key(ctx), current, ActorFactory.From(ctx.User).Id, Name(ctx), "Personal dictionary", ct);
                return Results.Ok(new { words = words.Length });
            }).WithSummary("Replace your personal dictionary (words the spelling check ignores for you).");
            me.MapDelete("/dictionary", async (HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                var current = (await store.SettingAsync(Key(ctx), ct))?.Value ?? new JsonObject();
                if (current.Remove("dictionary"))
                {
                    await store.SaveSettingAsync(Key(ctx), current, ActorFactory.From(ctx.User).Id, Name(ctx), "Personal dictionary reset", ct);
                }

                return Results.NoContent();
            }).WithSummary("Reset your personal dictionary to empty.");
            return api;
        }
    }
}
