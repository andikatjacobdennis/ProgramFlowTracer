namespace Volvo.TestRequestTool.Web
{
    public sealed record ContextRefIn([property: System.ComponentModel.DataAnnotations.StringLength(20)] string? Kind, [property: System.ComponentModel.DataAnnotations.StringLength(80)] string? Id);
}
