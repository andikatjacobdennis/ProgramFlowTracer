namespace Volvo.TestRequestTool.Web
{
    public sealed record SignInRequest([property: System.ComponentModel.DataAnnotations.StringLength(200)] string? Login, [property: System.ComponentModel.DataAnnotations.StringLength(200)] string? Password);
}
