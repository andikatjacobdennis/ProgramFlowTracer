using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Web
{
    public sealed record NewBatch([property: System.ComponentModel.DataAnnotations.StringLength(120)] string? Name, [property: System.ComponentModel.DataAnnotations.MaxLength(200)] string[]? VehicleIds,
        [property: System.ComponentModel.DataAnnotations.StringLength(40)] string? Kind, JsonObject? Template, int? DelayMs, bool? StopOnFailure);
}
