namespace Volvo.TestRequestTool.Web
{
    /// <summary>What the usage study knows about one person: daily counts (kept 90 days), time per page, the latest events, and consent.</summary>
    public sealed class UsageProfile
    {
        public bool OptedOut { get; set; }
        public DateTimeOffset FirstSeen { get; set; }
        public DateTimeOffset LastSeen { get; set; }
        public Dictionary<string, Dictionary<string, int>> Days { get; set; } = new(StringComparer.Ordinal);
        public Dictionary<string, double> Seconds { get; set; } = new(StringComparer.Ordinal);
        public List<UsageEvent> Recent { get; set; } = [];
    }
}
