namespace Volvo.TestRequestTool.Web
{
    /// <summary>Authentication settings: the mode, the session length and (for now) the sign-in accounts.</summary>
    public sealed class SignInSettings
    {
        /// <summary>Password (the app's sign-in page) or Jwt (bearer tokens from an identity provider).</summary>
        public string Mode { get; set; } = "Password";
        /// <summary>How long a session lasts without use; each request within that time extends it.</summary>
        public int SessionMinutes { get; set; } = 480;
        public List<ConfiguredAccount> Accounts { get; set; } = [];
    }
}
