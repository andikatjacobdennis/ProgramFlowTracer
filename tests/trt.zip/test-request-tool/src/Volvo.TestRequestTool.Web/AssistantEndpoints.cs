using System.Runtime.CompilerServices;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// The AI-ready API: chat (with streaming), summaries and agent plan previews. Every endpoint needs sign-in, the overall
    /// "ai" feature flag and its own flag ("ai-chat", "ai-summaries" or "ai-agent"); all are off by default. Flags are not
    /// authorisation: context comes only from records the caller may read (vehicle contexts, ownership).
    ///
    /// The provider is the simulated one (SimulatedAssistant): deterministic, rule-based, no AI, no external service, no
    /// credentials. To add a real provider later, implement IChatProvider, ISummaryProvider and IAgentPlanner and register
    /// them in AddAssistant; nothing else changes (docs/ai-readiness.md).
    ///
    /// Guardrails applied here for any provider: messages are treated as untrusted, redacted (tokens, secrets, e-mail
    /// addresses) and bounded; calls time out after 15 s with a structured, retryable error; nothing is executed; the audit log
    /// records who used which capability, never the message content.
    /// </summary>
    public static class AssistantEndpoints
    {
        public const int MaxMessages = 20, MaxChars = 4000;
        public static readonly TimeSpan Timeout = TimeSpan.FromSeconds(15);

        public static IServiceCollection AddAssistant(this IServiceCollection services)
        {
            services.AddSingleton<IAssistantContextRetriever, AssistantContextRetriever>();
            services.AddSingleton<SimulatedAssistant>();
            services.AddSingleton<IChatProvider>(sp => sp.GetRequiredService<SimulatedAssistant>());
            services.AddSingleton<ISummaryProvider>(sp => sp.GetRequiredService<SimulatedAssistant>());
            services.AddSingleton<IAgentPlanner>(sp => sp.GetRequiredService<SimulatedAssistant>());
            return services;
        }

        private static IReadOnlyList<ContextRef> Refs(ContextRefIn[]? include) =>
            (include ?? []).Where(r => r.Kind is "vehicle" or "proposal" or "request" or "activity").Take(6).Select(r => new ContextRef(r.Kind!, r.Id)).ToArray();

        private static AssistantMessage[] Messages(ChatMessageIn[]? input)
        {
            var list = (input ?? []).TakeLast(MaxMessages).Select(m => new AssistantMessage(m.Role == "assistant" ? "assistant" : "user", TestRequestLogStore.Redact(Bound(m.Text)))).ToArray();
            if (list.Length == 0 || string.IsNullOrWhiteSpace(list.LastOrDefault(m => m.Role == "user")?.Text))
            {
                throw new RequestFault(400, "message_required", "Ask a question.");
            }

            return list;
        }

        private static string Bound(string? s) => (s ?? "").Length > MaxChars ? s![..MaxChars] : s ?? "";

        public static IReadOnlyDictionary<string, bool> Permissions(HttpContext ctx)
        {
            bool Role(string r) => ctx.User.IsInRole(r);
            return new Dictionary<string, bool> { ["simulate"] = Role("Operator") || Role("Writer"), ["edit"] = Role("Editor") || Role("Writer"), ["write"] = Role("Writer"), ["approve"] = Role("Writer") };
        }

        private static Task Audit(HttpContext ctx, string action, string detail) =>
            ctx.RequestServices.GetRequiredService<IWorkspaceStore>().AppendAuditAsync(ActorFactory.From(ctx.User).Id, ctx.User.Identity?.Name ?? "", action, detail, new JsonObject { ["provider"] = "Simulated" }, ctx.RequestAborted);

        /// <summary>Runs a provider call with the timeout; a timeout becomes a structured, retryable error.</summary>
        private static async Task<IResult> Guard<T>(HttpContext ctx, Func<CancellationToken, Task<T>> call)
        {
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(ctx.RequestAborted);
            cts.CancelAfter(Timeout);
            try
            {
                return Results.Ok(await call(cts.Token));
            }
            catch (OperationCanceledException) when (!ctx.RequestAborted.IsCancellationRequested)
            {
                return Results.Problem(statusCode: 504, title: "assistant_timeout", detail: "The assistant did not answer in time. Your conversation is kept; try again.", extensions: new Dictionary<string, object?> { ["retryable"] = true });
            }
            catch (RequestFault f)
            {
                return Results.Problem(statusCode: f.Status, title: f.Code, detail: f.Message, extensions: new Dictionary<string, object?> { ["retryable"] = f.Status >= 500 });
            }
        }

        public static RouteGroupBuilder MapAssistant(this RouteGroupBuilder api)
        {
            var g = api.MapGroup("/assistant").WithTags("Assistant (simulated)").RequireFeature("ai");
            g.MapGet("/info", (IChatProvider p) => p.Info).WithSummary("Which provider answers, its label, capabilities, guardrails and conversation retention.");

            g.MapPost("/context", async (ContextBody body, HttpContext ctx, IAssistantContextRetriever r, CancellationToken ct) =>
            {
                var found = await r.RetrieveAsync(ActorFactory.From(ctx.User), Refs(body.Include), ct);
                return new { items = found.Items.Select(i => new { i.Kind, i.Id, i.Title, i.Version, i.At }), unavailable = found.Unavailable };
            }).WithSummary("What would be included as context: titles and versions of records you may read, and what is not available.");

            var chat = g.MapGroup("/chat").RequireFeature("ai-chat");
            chat.MapPost("/", async (ChatBody body, HttpContext ctx, IAssistantContextRetriever r, IChatProvider p) =>
            {
                var messages = Messages(body.Messages);
                var context = await r.RetrieveAsync(ActorFactory.From(ctx.User), Refs(body.Include), ctx.RequestAborted);
                await Audit(ctx, "assistant.chat", $"{context.Items.Count} context item(s)");
                return await Guard(ctx, ct => p.ChatAsync(new ChatRequest(messages, context), ct));
            }).RequireRateLimiting("assistant").WithSummary("Ask the simulated assistant. The answer cites its sources, states its confidence and may suggest actions; it changes nothing.");
            chat.MapPost("/stream", async (ChatBody body, HttpContext ctx, IAssistantContextRetriever r, IChatProvider p) =>
            {
                var messages = Messages(body.Messages);
                var context = await r.RetrieveAsync(ActorFactory.From(ctx.User), Refs(body.Include), ctx.RequestAborted);
                await Audit(ctx, "assistant.chat", $"{context.Items.Count} context item(s), streamed");
                return TypedResults.ServerSentEvents(Stream(p, new ChatRequest(messages, context), ctx.RequestAborted), eventType: "message");
            }).RequireRateLimiting("assistant").WithSummary("The same answer as a stream (Server-Sent Events): {text} pieces, then {done: reply}.");

            g.MapPost("/summary", async (SummaryBody body, HttpContext ctx, IAssistantContextRetriever r, ISummaryProvider p, TimeProvider clock) =>
            {
                if (body.Kind is not ("proposal" or "request" or "activity" or "vehicle"))
                {
                    throw new RequestFault(400, "summary_kind", "Kind is proposal, request, activity or vehicle.");
                }

                var found = await r.RetrieveAsync(ActorFactory.From(ctx.User), [new ContextRef(body.Kind, body.Id)], ctx.RequestAborted);
                var source = found.Items.FirstOrDefault() ?? throw new RequestFault(404, "summary_source_missing", "There is nothing you may read to summarise here.");
                await Audit(ctx, "assistant.summary", body.Kind);
                return await Guard(ctx, ct => p.SummariseAsync(source, clock.GetUtcNow(), ct));
            }).RequireFeature("ai-summaries").RequireRateLimiting("assistant").WithSummary("A simulated summary of a proposal, validation request, your activity or a vehicle, built from the records you may read, with the source version and generation time.");

            g.MapPost("/agent/plan", async (AgentBody body, HttpContext ctx, IAssistantContextRetriever r, IAgentPlanner p) =>
            {
                var goal = TestRequestLogStore.Redact(Bound(body.Goal)).Trim();
                if (goal.Length == 0)
                {
                    throw new RequestFault(400, "goal_required", "Describe what you want to achieve.");
                }

                var context = await r.RetrieveAsync(ActorFactory.From(ctx.User), Refs(body.Include), ctx.RequestAborted);
                await Audit(ctx, "assistant.agent.plan", $"{context.Items.Count} context item(s)");
                return await Guard(ctx, ct => p.PlanAsync(goal, context, Permissions(ctx), ct));
            }).RequireFeature("ai-agent").RequireRateLimiting("assistant").WithSummary("A plan preview for a goal: steps, required context and permissions, proposed actions and expected outcomes. Nothing is executed.");
            return api;
        }

        private static async IAsyncEnumerable<object> Stream(IChatProvider p, ChatRequest request, [EnumeratorCancellation] CancellationToken ct)
        {
            using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
            cts.CancelAfter(Timeout);
            await foreach (var piece in p.StreamAsync(request, cts.Token))
            {
                yield return new { text = piece };
            }

            yield return new { done = await p.ChatAsync(request, cts.Token) };
        }
    }
}
