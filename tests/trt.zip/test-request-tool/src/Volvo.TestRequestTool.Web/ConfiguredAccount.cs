namespace Volvo.TestRequestTool.Web
{
    /// <summary>One sign-in account in the settings (Authentication:Accounts). Temporary: passwords are stored as written.</summary>
    public sealed class ConfiguredAccount
    {
        public string Id { get; set; } = "";
        public string UserName { get; set; } = "";
        public string? Email { get; set; }
        public string Password { get; set; } = "";
        public string DisplayName { get; set; } = "";
        public string Role { get; set; } = "Viewer";
        public int[] Contexts { get; set; } = [];
        public string? Country { get; set; }

        /// <summary>The placeholder in settings.example.json; an account that still has it cannot sign in.</summary>
        public const string Placeholder = "CHANGE-ME";

        /// <summary>Has a password of its own (not empty and not the example's placeholder).</summary>
        public bool CanSignIn => Password.Length > 0 && !Password.StartsWith(Placeholder, StringComparison.OrdinalIgnoreCase);
    }
}
