using System.Reflection;
using System.Runtime.InteropServices;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>Vehicle history, snapshots, roadmap and the About information. Kept apart from Program.cs so each area is easy to find.</summary>
    public static class InsightEndpoints
    {
        public static RouteGroupBuilder MapInsights(this RouteGroupBuilder api, string authenticationMode)
        {
            // ?skip=&take= returns one page, newest first, for loading as the user scrolls. Without them the whole history is returned.
            api.MapGet("/vehicles/{series}/{number}/timeline", async (string series, string number, int? skip, int? take, HttpContext ctx, VehicleInsights insights, CancellationToken ct) =>
                await insights.TimelineAsync(ActorFactory.From(ctx.User), VehicleIdentity.Key(series, number), ct, skip, take));

            api.MapGet("/vehicles/{series}/{number}/timeline/{entryId}", async (string series, string number, string entryId, HttpContext ctx, VehicleInsights insights, CancellationToken ct) =>
                await insights.SnapshotAsync(ActorFactory.From(ctx.User), VehicleIdentity.Key(series, number), entryId, ct));

            // The dashboard: all vehicles the user may read, summarised in one call (cached a minute; ?refresh=true skips the cache).
            api.MapGet("/fleet", async (bool? refresh, HttpContext ctx, VehicleInsights insights, CancellationToken ct) =>
                await insights.FleetAsync(ActorFactory.From(ctx.User), refresh == true, ct));

            api.MapGet("/vehicles/{series}/{number}/roadmap", async (string series, string number, HttpContext ctx, VehicleInsights insights, CancellationToken ct) =>
                await insights.RoadmapAsync(ActorFactory.From(ctx.User), VehicleIdentity.Key(series, number), ct));

            api.MapGet("/about", (IWebHostEnvironment env, IConfiguration config, Volvo.TestRequestTool.Application.IDocumentStore repository, Microsoft.Extensions.Options.IOptionsMonitor<Volvo.TestRequestTool.Infrastructure.ServiceSettings> services) =>
            {
                var assembly = typeof(InsightEndpoints).Assembly;
                var version = assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion.Split('+')[0]
                    ?? assembly.GetName().Version?.ToString() ?? "unknown";
                return Results.Ok(new
                {
                    name = "Test Request Tool",
                    version,
                    runtime = RuntimeInformation.FrameworkDescription,
                    os = RuntimeInformation.OSDescription,
                    environment = env.EnvironmentName,
                    authentication = authenticationMode,
                    storage = repository.Description + " (single process)",
                    contracts = new[]
                    {
                        new { name = "Product Update Service", versions = "1.0, 2.0" },
                        new { name = "Available Product Updates", versions = "1.0, 1.1" },
                        new { name = "Software, kit, spare cab, breakdown and Available Updates requests", versions = "Test Request Tool JSON" },
                    },
                    liveServices = string.Join(", ", Volvo.TestRequestTool.Infrastructure.RepositorySeeder.Services.Keys.Select(n => $"{n}: {services.CurrentValue.For(n).Transport}")) + ". Files are read from " + services.CurrentValue.Path + "; Http calls the live service; Off is not connected.",
                });
            });
            return api;
        }
    }
}
