using System.Text;
using Volvo.TestRequestTool.Application;
namespace Volvo.TestRequestTool.Web
{
    public static class LogEndpoints
    {
        private static readonly string[] Levels = ["Critical", "Error", "Warning", "Information", "Debug", "Trace"];

        public static WebApplicationBuilder AddTestRequestLogs(this WebApplicationBuilder builder)
        {
            var store = new TestRequestLogStore();
            builder.Logging.AddProvider(store);
            builder.Services.AddSingleton(store);
            return builder;
        }

        private static IEnumerable<LogItem> Filter(TestRequestLogStore store, string? levels, string? q, string? category, string? message, string? exception, string? path, DateTimeOffset? from, DateTimeOffset? to, long? after,
            Func<LogItem, bool>? scope = null, string? request = null, string? service = null)
        {
            scope ??= _ => true;
            bool Req(LogItem e) => string.IsNullOrWhiteSpace(request) || (e.RequestId is Guid g && (g.ToString() == request || e.Request!.Equals(request, StringComparison.OrdinalIgnoreCase))) || (e.TraceId?.Equals(request, StringComparison.OrdinalIgnoreCase) ?? false);
            var lv = string.IsNullOrWhiteSpace(levels) ? null : levels.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToHashSet(StringComparer.OrdinalIgnoreCase);
            bool Has(string? text, string? part) => string.IsNullOrWhiteSpace(part) || (text?.Contains(part, StringComparison.OrdinalIgnoreCase) ?? false);
            return store.All.Where(e => scope(e) && Req(e) && (string.IsNullOrWhiteSpace(service) || string.Equals(e.Service ?? "Server", service, StringComparison.OrdinalIgnoreCase)) && (lv is null || lv.Contains(e.Level)) && (from is null || e.At >= from) && (to is null || e.At <= to) && (after is null || e.Id > after)
                && Has(e.Category, category) && Has(e.Message, message) && Has(e.Exception, exception) && Has(e.Path, path)
                && (string.IsNullOrWhiteSpace(q) || Has(e.Message, q) || Has(e.Category, q) || Has(e.Exception, q) || Has(e.Path, q) || Has(e.TraceId, q) || Has(e.Level, q) || Has(e.Request, q) || Has(e.Service, q)));
        }

        /// <summary>Error groups: problems with the same message once ids, numbers and quoted values are taken out.</summary>
        private static string Shape(string message) => System.Text.RegularExpressions.Regex.Replace(System.Text.RegularExpressions.Regex.Replace(message, @"[0-9a-fA-F]{8}-[0-9a-fA-F-]{27,}|\b[0-9a-f]{12,}\b|\d+(\.\d+)?", "#"), "'[^']*'|\"[^\"]*\"", "…");

        private static object Query(TestRequestLogStore store, TimeProvider clock, Func<LogItem, bool>? scope, string? levels, string? q, string? category, string? message, string? exception, string? path,
            DateTimeOffset? from, DateTimeOffset? to, long? after, string? sort, string? dir, int? skip, int? take, string? request, string? service)
        {
            var all = Filter(store, levels, q, category, message, exception, path, from, to, after, scope, request, service).ToArray();
            var desc = !string.Equals(dir, "asc", StringComparison.OrdinalIgnoreCase);
            IEnumerable<LogItem> sorted = (sort ?? "time").ToLowerInvariant() switch
            {
                "level" => desc ? all.OrderBy(e => Array.IndexOf(Levels, e.Level)).ThenByDescending(e => e.Id) : all.OrderByDescending(e => Array.IndexOf(Levels, e.Level)).ThenByDescending(e => e.Id),
                "category" => desc ? all.OrderByDescending(e => e.Category, StringComparer.Ordinal).ThenByDescending(e => e.Id) : all.OrderBy(e => e.Category, StringComparer.Ordinal).ThenByDescending(e => e.Id),
                "service" => desc ? all.OrderByDescending(e => e.Service ?? "", StringComparer.Ordinal).ThenByDescending(e => e.Id) : all.OrderBy(e => e.Service ?? "", StringComparer.Ordinal).ThenByDescending(e => e.Id),
                "message" => desc ? all.OrderByDescending(e => e.Message, StringComparer.Ordinal) : all.OrderBy(e => e.Message, StringComparer.Ordinal),
                _ => desc ? all.OrderByDescending(e => e.At).ThenByDescending(e => e.Id) : all.OrderBy(e => e.At).ThenBy(e => e.Id),
            };
            // Volume over time, by level: about 60 buckets across the filtered range.
            // The chart starts at the first entry in range, so a few recent entries are not squeezed against the right edge.
            var first = all.Length > 0 ? all.Min(e => e.At) : clock.GetUtcNow().AddMinutes(-30);
            var start = from is { } f && f > first ? f : first;
            var end = to ?? clock.GetUtcNow();
            if (end <= start)
            {
                end = start.AddMinutes(1);
            }

            var bucket = TimeSpan.FromTicks(Math.Max(TimeSpan.FromSeconds(10).Ticks, (end - start).Ticks / 60));
            var histogram = all.GroupBy(e => (long)((e.At - start).Ticks / bucket.Ticks)).OrderBy(g => g.Key)
                .Select(g => new { at = start + TimeSpan.FromTicks(g.Key * bucket.Ticks), counts = g.GroupBy(e => e.Level).ToDictionary(x => x.Key, x => x.Count()) }).ToArray();
            var visible = scope is null ? store.All : store.All.Where(scope).ToArray();
            return new
            {
                total = all.Length,
                captured = visible.Count,
                since = store.Since,
                lastId = visible.Count > 0 ? visible[^1].Id : 0,
                bucketSeconds = bucket.TotalSeconds,
                from = start,
                to = end,
                levels = Levels.ToDictionary(l => l, l => all.Count(e => e.Level == l)),
                categories = all.GroupBy(e => e.Category).Select(g => new { category = g.Key, count = g.Count(), problems = g.Count(e => e.Level is "Error" or "Critical" or "Warning") }).OrderByDescending(x => x.count).Take(12).ToArray(),
                services = all.GroupBy(e => e.Service ?? "Server").Select(g => new { service = g.Key, count = g.Count() }).OrderByDescending(x => x.count).ToArray(),
                errorGroups = all.Where(e => e.Level is "Error" or "Critical" or "Warning").GroupBy(e => (e.Service ?? e.Category, Shape(e.Message)))
                    .Select(g => new { service = g.Key.Item1, message = g.Key.Item2, level = g.Any(e => e.Level is "Error" or "Critical") ? "Error" : "Warning", count = g.Count(), lastId = g.Max(e => e.Id) })
                    .OrderByDescending(x => x.count).Take(6).ToArray(),
                histogram,
                items = sorted.Skip(Math.Max(0, skip ?? 0)).Take(Math.Clamp(take ?? 50, 1, 500)).ToArray(),
            };
        }

        public static RouteGroupBuilder MapLogs(this RouteGroupBuilder api)
        {
            var logs = api.MapGroup("/diagnostics/logs").WithTags("Diagnostics").RequireAuthorization("Admin").RequireFeature("logs-viewer");
            logs.MapGet("/", (TestRequestLogStore store, TimeProvider clock, string? levels, string? q, string? category, string? message, string? exception, string? path,
                DateTimeOffset? from, DateTimeOffset? to, long? after, string? sort, string? dir, int? skip, int? take, string? request, string? service) =>
                Query(store, clock, null, levels, q, category, message, exception, path, from, to, after, sort, dir, skip, take, request, service))
                .WithSummary("Captured log entries (redacted), newest first: filter by levels, words in any column or per column, path and time; sort by time, level, category or message; page with skip and take. after returns only entries newer than an id (live tail).");
            logs.MapGet("/export", (TestRequestLogStore store, string? format, string? levels, string? q, DateTimeOffset? from, DateTimeOffset? to, string? request, string? service) => Export(store, null, format, levels, q, from, to, request, service))
                .Audited("logs.export").RequireRateLimiting("exports").WithSummary("Download the filtered entries as JSON or CSV (already redacted). The download is recorded in the audit log.");

            // Everyone signed in: the same view scoped to the records they may see (administrators see every entry).
            var events = api.MapGroup("/diagnostics/events").WithTags("Diagnostics").RequireFeature("logs-viewer");
            static Func<LogItem, bool>? Scope(HttpContext ctx)
            {
                if (ctx.User.IsInRole("Admin"))
                {
                    return null;
                }

                var me = ActorFactory.From(ctx.User).Id;
                return e => e.Audience is { } a && a.Contains(me);
            }
            events.MapGet("/", (HttpContext ctx, TestRequestLogStore store, TimeProvider clock, string? levels, string? q, string? category, string? message, string? exception, string? path,
                DateTimeOffset? from, DateTimeOffset? to, long? after, string? sort, string? dir, int? skip, int? take, string? request, string? service) =>
            {
                var scope = Scope(ctx);
                return new { scoped = scope is not null, result = Query(store, clock, scope, levels, q, category, message, exception, path, from, to, after, sort, dir, skip, take, request, service) };
            }).WithSummary("Diagnostic events you may see: administrators every entry, others the events of their own requests and reviews. Same filters as the logs API plus request (REQ-…, id or trace id) and service.");
            events.MapGet("/export", (HttpContext ctx, TestRequestLogStore store, string? format, string? levels, string? q, DateTimeOffset? from, DateTimeOffset? to, string? request, string? service) =>
                Export(store, Scope(ctx), format, levels, q, from, to, request, service)).Audited("logs.export").RequireRateLimiting("exports").WithSummary("Download the events you may see (sanitised) as JSON or CSV.");
            return api;
        }

        private static IResult Export(TestRequestLogStore store, Func<LogItem, bool>? scope, string? format, string? levels, string? q, DateTimeOffset? from, DateTimeOffset? to, string? request, string? service)
        {
            var rows = Filter(store, levels, q, null, null, null, null, from, to, null, scope, request, service).OrderByDescending(e => e.Id).Take(TestRequestLogStore.Capacity)
                .Select(e => new { e.Id, e.At, e.Level, service = e.Service ?? "Server", e.Category, e.Message, e.Exception, e.TraceId, e.SpanId, request = e.Request, e.Attempt, e.Path, fields = e.Fields is null ? null : string.Join("; ", e.Fields.Select(kv => kv.Key + "=" + kv.Value)) }).ToArray();
            var json = System.Text.Json.JsonSerializer.SerializeToNode(rows, ProvenanceService.Json)!.AsArray();
            return (format ?? "json").Equals("csv", StringComparison.OrdinalIgnoreCase)
                ? Results.File(Encoding.UTF8.GetBytes(DataConverter.ToCsv(json)), "text/csv", "logs.csv")
                : Results.File(Encoding.UTF8.GetBytes(json.ToJsonString(new System.Text.Json.JsonSerializerOptions { WriteIndented = true })), "application/json", "logs.json");
        }
    }
}
