using System.Collections.Concurrent;
using System.Diagnostics;
using Microsoft.Extensions.Options;
using Volvo.TestRequestTool.Application;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Service monitoring: checks every service every 30 seconds and keeps the history, so the Service health page can show
    /// what happened, when, for how long and why.
    /// <list type="bullet">
    /// <item>Simulated services (VDA, KAX, identity provider …) follow <see cref="ServiceModel"/>: deterministic, so their
    /// history goes back as far as asked and every incident and root cause can be reproduced. Everything about them says
    /// "simulated"; they never stand in for a live check.</item>
    /// <item>Internal services (workspace store, job workers, memory) are probed for real. Their samples are kept in memory
    /// for seven days; a restart starts their history again.</item>
    /// </list>
    /// </summary>
    public sealed class ServiceMonitor : BackgroundService
    {
        private readonly IWorkspaceStore _store;
        private readonly IOptions<JobOptions> _jobs;
        private readonly TimeProvider _clock;
        private readonly ILogger<ServiceMonitor> _log;
        public static readonly TimeSpan Interval = TimeSpan.FromSeconds(30);
        private const int Keep = 7 * 24 * 120;   // seven days of 30-second samples
        private readonly ConcurrentDictionary<string, ConcurrentQueue<ServiceSample>> _live = new(StringComparer.OrdinalIgnoreCase);
        private readonly ConcurrentDictionary<string, ServiceSample> _last = new(StringComparer.OrdinalIgnoreCase);

        public ServiceMonitor(IWorkspaceStore store, IOptions<JobOptions> jobs, TimeProvider clock, ILogger<ServiceMonitor> log)
        {
            _store = store;
            _jobs = jobs;
            _clock = clock;
            _log = log;
        }

        protected override async Task ExecuteAsync(CancellationToken stop)
        {
            using var timer = new PeriodicTimer(Interval, _clock);
            do
            {
                foreach (var s in ServiceModel.Services)
                {
                    try
                    {
                        Record(await CheckAsync(s, stop));
                    }
                    catch (OperationCanceledException) when (stop.IsCancellationRequested)
                    {
                        return;
                    }   // the host is shutting down
                    catch (Exception e)
                    {
                        _log.LogWarning(e, "Check of {Service} failed", s.Id);
                    }
                }
            } while (await Tick(timer, stop));
        }

        private static async Task<bool> Tick(PeriodicTimer timer, CancellationToken stop)
        {
            try
            {
                return await timer.WaitForNextTickAsync(stop);
            }
            catch (OperationCanceledException)
            {
                return false;
            }
        }

        private void Record(ServiceSample sample)
        {
            // A change of state is worth a log line: it shows up in the Logs page next to the API calls around it.
            if (_last.TryGetValue(sample.Service, out var before) && before.Status != sample.Status)
            {
                var svc = ServiceModel.Find(sample.Service)!;
                if (sample.Status == "up")
                {
                    _log.LogInformation("{Service} recovered (was {Before}){Simulated}", svc.Name, before.Status, svc.Simulated ? " [simulated]" : "");
                }
                else
                {
                    _log.LogWarning("{Service} is {Status}: {Detail}{Simulated}", svc.Name, sample.Status, sample.Detail ?? sample.Code, svc.Simulated ? " [simulated]" : "");
                }
            }
            _last[sample.Service] = sample;
            var q = _live.GetOrAdd(sample.Service, _ => new());
            q.Enqueue(sample);
            while (q.Count > Keep && q.TryDequeue(out _))
            { }
        }

        /// <summary>One check now. Simulated services answer from the model; internal ones are measured.</summary>
        public async Task<ServiceSample> CheckAsync(MonitoredService s, CancellationToken ct)
        {
            var now = _clock.GetUtcNow();
            if (s.Simulated)
            {
                return ServiceModel.At(s, now);
            }

            var sw = Stopwatch.StartNew();
            switch (s.Id)
            {
                case "store":
                    using (var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct))
                    {
                        timeout.CancelAfter(TimeSpan.FromSeconds(3));
                        try
                        {
                            await _store.JobLoadAsync("-", timeout.Token);
                        }
                        catch (OperationCanceledException) when (!ct.IsCancellationRequested)
                        {
                            return new(s.Id, now, "down", 3000, "timeout", "The store did not answer within 3 s.");
                        }
                    }
                    var ms = sw.Elapsed.TotalMilliseconds;
                    return new(s.Id, now, ms > 500 ? "degraded" : "up", Math.Round(ms, 2), ms > 500 ? "latency" : null, ms > 500 ? "The store answers slowly." : null);
                case "jobs":
                    var load = await _store.JobLoadAsync("-", ct);
                    var age = load.OldestQueued is { } t ? now - t : TimeSpan.Zero;
                    if (!JobWorker.Started)
                    {
                        return new(s.Id, now, "down", 0, "stopped", "Job workers have not started.");
                    }

                    if (_jobs.Value.Workers > 0 && age > TimeSpan.FromMinutes(5))
                    {
                        return new(s.Id, now, "degraded", age.TotalMilliseconds, "queue_age", $"The oldest job has waited {age.TotalMinutes:0} minutes.");
                    }

                    return new(s.Id, now, "up", Math.Round(sw.Elapsed.TotalMilliseconds, 2), null, $"{load.Queued} queued, {load.Running} running.");
                default:
                    var info = GC.GetGCMemoryInfo();
                    var share = info.TotalAvailableMemoryBytes > 0 ? (double)info.MemoryLoadBytes / info.TotalAvailableMemoryBytes : 0;
                    return new(s.Id, now, share > .9 ? "degraded" : "up", Math.Round(GC.GetTotalMemory(false) / 1048576.0, 1), share > .9 ? "memory" : null, $"Memory load {share:P0}.");
            }
        }

        public ServiceSample? Last(string id) => _last.GetValueOrDefault(id);

        public IReadOnlyList<ServiceSample> Live(string id, DateTimeOffset from, DateTimeOffset to) =>
            _live.TryGetValue(id, out var q) ? q.Where(x => x.At >= from && x.At < to).ToArray() : [];

        /// <summary>Incidents of an internal service: runs of samples that were not "up".</summary>
        public IReadOnlyList<ServiceIncident> LiveIncidents(string id, DateTimeOffset from, DateTimeOffset to)
        {
            var result = new List<ServiceIncident>();
            ServiceSample? first = null;
            ServiceSample? prev = null;
            var worst = "degraded";
            foreach (var x in Live(id, from, to).Append(new ServiceSample(id, to, "up", 0, null, null)))
            {
                if (x.Status != "up")
                {
                    first ??= x;
                    if (x.Status == "down")
                    {
                        worst = "down";
                    }
                }
                else if (first is not null)
                {
                    var minutes = Math.Max(.5, (x.At - first.At).TotalMinutes);
                    result.Add(new($"{id}-{first.At.ToUnixTimeSeconds()}", id, worst, first.At, x.At, Math.Round(minutes, 1), first.Code ?? "unknown", first.Detail ?? "Check failed",
                        first.Detail ?? "A live check did not pass.", null, null, false, "direct", [], [new(first.At, "detected", first.Detail ?? "Check failed."), new(x.At, "resolved", "Checks healthy again.")], false));
                    first = null;
                    worst = "degraded";
                }
                prev = x;
            }
            return result;
        }
    }
}
