using System.ComponentModel.DataAnnotations;
using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>Body of POST /feedback.</summary>
    public sealed record SendFeedback([property: StringLength(20)] string? Kind, [property: Range(0, 5)] int? Rating, [property: StringLength(4000)] string? Message, [property: StringLength(200)] string? Page, JsonObject? Context);
}
