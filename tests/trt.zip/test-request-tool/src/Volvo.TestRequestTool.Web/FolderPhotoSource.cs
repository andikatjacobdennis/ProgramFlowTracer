namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Photos kept with the repository: an image per person in the repository's user-photos folder, named after their user
    /// ID (for example <c>user-photos\ananya.png</c>; .png, .jpg, .jpeg, .webp or .svg). People without one show their initials.
    /// Used when Microsoft Graph is not set up.
    /// </summary>
    public sealed class FolderPhotoSource : IProfilePhotoSource
    {
        private readonly string _folder;
        private static readonly (string Ext, string Type)[] Kinds = [(".png", "image/png"), (".jpg", "image/jpeg"), (".jpeg", "image/jpeg"), (".webp", "image/webp"), (".svg", "image/svg+xml")];

        public FolderPhotoSource(string folder)
        {
            _folder = folder;
        }

        public string Name => "Repository";
        public string Folder => _folder;

        /// <summary>The person's photo file, or null.</summary>
        public PhotoResult Find(string userId)
        {
            foreach (var (ext, type) in Kinds)
            {
                var path = Path.Combine(_folder, Volvo.TestRequestTool.Infrastructure.FileDocumentStore.Encode(userId) + ext);
                if (File.Exists(path))
                {
                    return new("ok", File.ReadAllBytes(path), type);
                }
            }
            return PhotoResult.None;
        }

        public Task<PhotoResult> GetAsync(HttpContext ctx, int size, CancellationToken ct) => Task.FromResult(Find(ActorFactory.From(ctx.User).Id));
    }
}
