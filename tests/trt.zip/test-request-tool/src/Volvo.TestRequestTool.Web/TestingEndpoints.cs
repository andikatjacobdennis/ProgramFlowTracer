using System.Diagnostics;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Http.Json;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Everything needed to test the service from outside, with any HTTP tool (k6, JMeter, bombardier, OWASP ZAP, Burp):
    /// <list type="bullet">
    /// <item><b>Load-test endpoints</b> (/api/v1/loadtest): cheap, bounded operations to measure the framework, CPU, latency,
    /// payload and real read and validation paths. They need the LoadTester or Admin role, have their own rate limit and a
    /// global concurrency cap, and are off in production unless Testing:LoadEndpoints is set.</item>
    /// <item><b>Health checks</b> (ASP.NET Core health checks): /health/live, /health/ready and /health/details. Never rate-limited.</item>
    /// <item><b>Security self-test</b> (/api/v1/security): the attack surface (every endpoint with its access rule) and a set of
    /// checks that the protections are switched on. It reports; it does not attack anything.</item>
    /// </list>
    /// </summary>
    public static class TestingEndpoints
    {
        public const string LoadPolicy = "loadtest";
        private static ConcurrencyLimiter? loadGate;
        private static long served, refused;
        private static readonly long Started = Stopwatch.GetTimestamp();
        private static readonly string Instance = $"{Environment.MachineName}:{Environment.ProcessId}";

        public static WebApplicationBuilder AddTestRequestTesting(this WebApplicationBuilder builder, bool localEnvironment)
        {
            builder.Services.AddOptions<TestingOptions>().Bind(builder.Configuration.GetSection("Testing")).ValidateDataAnnotations().ValidateOnStart();
            var options = builder.Configuration.GetSection("Testing").Get<TestingOptions>() ?? new();
            loadGate = new ConcurrencyLimiter(new ConcurrencyLimiterOptions { PermitLimit = options.MaxConcurrentLoad, QueueLimit = 0 });
            builder.Services.AddAuthorizationBuilder().AddPolicy("LoadTester", p => p.RequireAuthenticatedUser().RequireRole("LoadTester", "Admin"));
            builder.Services.Configure<RateLimiterOptions>(o => o.AddPolicy(LoadPolicy, ctx => RateLimitPartition.GetTokenBucketLimiter("load:" + (ctx.User.Identity?.Name ?? ctx.Connection.RemoteIpAddress?.ToString() ?? "anonymous"),
                _ => new TokenBucketRateLimiterOptions { TokenLimit = options.LoadRequestsPerSecond, TokensPerPeriod = options.LoadRequestsPerSecond, ReplenishmentPeriod = TimeSpan.FromSeconds(1), QueueLimit = 0, AutoReplenishment = true })));

            // Health checks: "live" means the process answers; "ready" means it can take work (FR-47).
            builder.Services.AddHealthChecks()
                .AddCheck("process", () => HealthCheckResult.Healthy("The process answers."), tags: ["live"])
                .AddCheck<StoreHealthCheck>("store", tags: ["ready"])
                .AddCheck<JobsHealthCheck>("jobs", tags: ["ready"])
                .AddCheck<IntegrationsHealthCheck>("integrations", tags: ["ready"])
                .AddCheck<MemoryHealthCheck>("memory", tags: ["ready"]);
            return builder;
        }

        public static WebApplication MapTestRequestHealth(this WebApplication app)
        {
            app.MapHealthChecks("/health/live", new HealthCheckOptions { Predicate = c => c.Tags.Contains("live"), ResponseWriter = WriteSummary }).WithTags("Diagnostics");
            // Degraded still takes traffic (200); only Unhealthy takes the instance out of rotation (503).
            app.MapHealthChecks("/health/ready", new HealthCheckOptions
            {
                Predicate = c => c.Tags.Contains("ready"),
                ResponseWriter = WriteSummary,
                ResultStatusCodes = { [HealthStatus.Healthy] = 200, [HealthStatus.Degraded] = 200, [HealthStatus.Unhealthy] = 503 },
            }).WithTags("Diagnostics");
            // Details name internals (queue sizes, memory, integration errors), so they need an operator or administrator.
            app.MapHealthChecks("/health/details", new HealthCheckOptions { ResponseWriter = WriteDetails, ResultStatusCodes = { [HealthStatus.Degraded] = 200, [HealthStatus.Unhealthy] = 503 } })
                .RequireAuthorization("Operator").WithTags("Diagnostics");
            return app;
        }

        private static Task WriteSummary(HttpContext ctx, HealthReport report)
        {
            ctx.Response.ContentType = "application/json";
            ctx.Response.Headers.CacheControl = "no-store";
            return ctx.Response.WriteAsync(new JsonObject { ["status"] = report.Status.ToString().ToLowerInvariant(), ["ms"] = Math.Round(report.TotalDuration.TotalMilliseconds, 1), ["instance"] = Instance }.ToJsonString());
        }

        private static Task WriteDetails(HttpContext ctx, HealthReport report)
        {
            ctx.Response.ContentType = "application/json";
            ctx.Response.Headers.CacheControl = "no-store";
            var checks = new JsonObject();
            foreach (var (name, e) in report.Entries)
            {
                checks[name] = new JsonObject
                {
                    ["status"] = e.Status.ToString().ToLowerInvariant(),
                    ["description"] = e.Description,
                    ["ms"] = Math.Round(e.Duration.TotalMilliseconds, 1),
                    ["data"] = JsonSerializer.SerializeToNode(e.Data.ToDictionary(d => d.Key, d => d.Value)),
                    ["tags"] = new JsonArray(e.Tags.Select(t => (JsonNode)t).ToArray()),
                };
            }

            return ctx.Response.WriteAsync(new JsonObject { ["status"] = report.Status.ToString().ToLowerInvariant(), ["ms"] = Math.Round(report.TotalDuration.TotalMilliseconds, 1), ["instance"] = Instance, ["checks"] = checks }.ToJsonString());
        }

        public static RouteGroupBuilder MapTestRequestTesting(this RouteGroupBuilder api, WebApplication app, bool localEnvironment, string authenticationMode)
        {
            var options = app.Services.GetRequiredService<IOptions<TestingOptions>>().Value;
            var enabled = options.LoadEndpoints ?? (localEnvironment || app.Environment.IsDevelopment());

            // ---------------------------------------------------------------- load testing
            if (enabled)
            {
                var load = api.MapGroup("/loadtest").WithTags("Load testing").RequireAuthorization("LoadTester").RequireRateLimiting(LoadPolicy).RequireFeature("load-testing")
                    .AddEndpointFilter(async (ctx, next) =>
                    {
                        // A global cap on load-test work in progress: excess calls get 503 at once, so real users keep working (FR-36).
                        using var lease = loadGate!.AttemptAcquire();
                        if (!lease.IsAcquired)
                        {
                            Interlocked.Increment(ref refused);
                            ctx.HttpContext.Response.Headers.RetryAfter = "1";
                            return Results.Problem(statusCode: 503, title: "load_limit", detail: "Too many load-test requests in progress. Slow down or raise Testing:MaxConcurrentLoad.");
                        }
                        Interlocked.Increment(ref served);
                        return await next(ctx);
                    });
                load.MapGet("/ping", () => TypedResults.Ok(new LoadPing(true, DateTimeOffset.UtcNow, Instance)))
                    .WithSummary("The cheapest authenticated call: measures framework, authentication and rate-limiting overhead.");
                load.MapGet("/work", (int? ms) =>
                {
                    var budget = TimeSpan.FromMilliseconds(Math.Clamp(ms ?? 5, 1, 200));
                    var sw = Stopwatch.StartNew();
                    var rounds = 0;
                    Span<byte> buffer = stackalloc byte[32];
                    while (sw.Elapsed < budget)
                    {
                        SHA256.HashData(buffer, buffer);
                        rounds++;
                    }
                    return TypedResults.Ok(new { ms = sw.Elapsed.TotalMilliseconds, rounds, instance = Instance });
                }).WithSummary("CPU-bound work for ms milliseconds (1–200): measures throughput under CPU load.");
                load.MapGet("/delay", async (int? ms, CancellationToken ct) =>
                {
                    var wait = Math.Clamp(ms ?? 50, 0, 5000);
                    await Task.Delay(wait, ct);
                    return TypedResults.Ok(new { waited = wait, instance = Instance });
                }).WithSummary("Waits ms milliseconds (0–5000) without using a thread: measures concurrency and connection handling.");
                load.MapGet("/payload", (int? kb) =>
                {
                    var size = Math.Clamp(kb ?? 10, 1, 1024) * 1024;
                    var bytes = new byte[size];
                    Random.Shared.NextBytes(bytes);
                    return Results.File(bytes, "application/octet-stream");
                }).WithSummary("Returns kb kilobytes (1–1024) of random data: measures bandwidth and response buffering.");
                load.MapPost("/echo", async (HttpRequest request, CancellationToken ct) =>
                {
                    using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
                    var buffer = new byte[16 * 1024];
                    long total = 0;
                    int read;
                    while ((read = await request.Body.ReadAsync(buffer, ct)) > 0)
                    {
                        hash.AppendData(buffer, 0, read);
                        total += read;
                    }
                    return TypedResults.Ok(new { bytes = total, sha256 = Convert.ToHexString(hash.GetHashAndReset()), instance = Instance });
                }).WithSummary("Reads the body (up to the 4 MB limit) and returns its size and SHA-256: measures upload handling.");
                load.MapGet("/read", async (IWorkspaceStore store, HttpContext ctx, int? take, CancellationToken ct) =>
                {
                    var actor = ActorFactory.From(ctx.User);
                    var list = (await store.VehiclesAsync(ct)).Select(v => new ProductDocument(v.Product)).Where(p => actor.Contexts.Contains(p.ContextId)).Take(Math.Clamp(take ?? 20, 1, 200))
                        .Select(p => new { id = p.Id, model = p.Info.S("modelId") }).ToArray();
                    return TypedResults.Ok(new { count = list.Length, items = list });
                }).WithSummary("A real read through the store and authorization (vehicle list, up to 200).");
                load.MapGet("/status", () => TypedResults.Ok(new
                {
                    served = Interlocked.Read(ref served),
                    refused = Interlocked.Read(ref refused),
                    uptimeSeconds = Stopwatch.GetElapsedTime(Started).TotalSeconds,
                    limits = new { options.LoadRequestsPerSecond, options.MaxConcurrentLoad },
                    threadPool = ThreadPoolNow(),
                    instance = Instance,
                })).WithSummary("Load-test counters since start: served and refused calls, limits, thread pool.");
                load.MapPost("/reset", () =>
                {
                    Interlocked.Exchange(ref served, 0);
                    Interlocked.Exchange(ref refused, 0);
                    return TypedResults.NoContent();
                })
                    .RequireAuthorization("Admin").WithSummary("Reset the load-test counters (administrators).");
            }

            // ---------------------------------------------------------------- security self-test (FR-52, FR-55, FR-56, FR-60)
            var sec = api.MapGroup("/security").WithTags("Security testing").RequireAuthorization("Admin");
            sec.MapGet("/endpoints", (EndpointDataSource sources) => Surface(sources))
                .WithSummary("The attack surface: every endpoint with its methods, access rule, rate-limit policy and tags. Anonymous endpoints outside the allow-list are flagged.");
            sec.MapGet("/self-test", async (EndpointDataSource sources, IOptions<JsonOptions> json, IOptions<RateLimiterOptions> limits, IWorkspaceStore store, CancellationToken ct) =>
            {
                var checks = new List<SecurityCheck>();
                void Add(string name, string req, bool ok, string detail, bool warnOnly = false) => checks.Add(new(name, req, ok ? "pass" : warnOnly ? "warn" : "fail", detail));

                var production = app.Environment.IsProduction();
                Add("Sign-in accounts are not kept in the settings in production", "FR-51", !(production && authenticationMode == "Password"), $"Environment {app.Environment.EnvironmentName}, authentication {authenticationMode}. The settings accounts are a temporary sign-in; use a directory or single sign-on in production.", warnOnly: true);
                Add("HTTPS redirection and HSTS outside this machine", "FR-54", localEnvironment || !app.Environment.IsDevelopment(), localEnvironment ? "Development or Testing: plain HTTP is allowed on this machine." : "On.", warnOnly: true);
                var open = Surface(sources).Where(e => e.Flagged).ToArray();
                Add("Every API endpoint requires sign-in", "FR-52", open.Length == 0, open.Length == 0 ? "No anonymous endpoints outside the allow-list (health, OpenAPI, sign-in)." : "Anonymous: " + string.Join(", ", open.Select(e => e.Methods + " " + e.Route)));
                Add("Scripts limited to this site (CSP)", "FR-56", SecurityHardening.ContentSecurityPolicy.Contains("script-src 'self';", StringComparison.Ordinal) && !SecurityHardening.ContentSecurityPolicy.Contains("unsafe-eval", StringComparison.Ordinal), SecurityHardening.ContentSecurityPolicy);
                Add("Framing refused", "FR-56", SecurityHardening.ContentSecurityPolicy.Contains("frame-ancestors 'none'", StringComparison.Ordinal), "frame-ancestors 'none' and X-Frame-Options DENY.");
                var cross = new DefaultHttpContext();
                cross.Request.Method = "POST";
                cross.Request.Headers["Sec-Fetch-Site"] = "cross-site";
                var crossOrigin = new DefaultHttpContext();
                crossOrigin.Request.Method = "POST";
                crossOrigin.Request.Host = new HostString("studio.example");
                crossOrigin.Request.Headers.Origin = "https://evil.example";
                Add("Cross-site writes refused (CSRF)", "FR-56", SecurityHardening.IsCrossSite(cross.Request) && SecurityHardening.IsCrossSite(crossOrigin.Request), "Fetch Metadata and Origin checks both refuse a forged cross-site POST.");
                bool duplicateRefused;
                try
                {
                    JsonSerializer.Deserialize<JsonObject>("{\"a\":1,\"a\":2}", json.Value.SerializerOptions);
                    duplicateRefused = false;
                }
                catch (Exception e) when (e is JsonException or ArgumentException)
                {
                    duplicateRefused = true;
                }
                Add("Duplicate JSON properties refused", "FR-55", duplicateRefused, "{\"a\":1,\"a\":2} is rejected before any handler runs.");
                bool dtdRefused;
                try
                {
                    DataConverter.XmlToJson("<!DOCTYPE a [<!ENTITY e SYSTEM \"file:///etc/passwd\">]><a>&e;</a>");
                    dtdRefused = false;
                }
                catch (RequestFault)
                {
                    dtdRefused = true;
                }
                Add("XML external entities refused (XXE)", "FR-55", dtdRefused, "DTDs are prohibited and nothing external is resolved.");
                bool deepRefused;
                try
                {
                    JsonSerializer.Deserialize<JsonNode>(new string('[', 200) + new string(']', 200), json.Value.SerializerOptions);
                    deepRefused = false;
                }
                catch (JsonException)
                {
                    deepRefused = true;
                }
                Add("Deeply nested JSON refused", "FR-55", deepRefused, $"Maximum depth {json.Value.SerializerOptions.MaxDepth}.");
                Add("Global rate limit configured", "FR-36", limits.Value.GlobalLimiter is not null, "Per-user limit on all API calls, with Retry-After on rejection.");
                var (count, broken) = await store.VerifyAuditAsync(ct);
                Add("Audit log intact", "FR-19", broken is null, broken is null ? $"{count} entries, hash chain verified." : $"Chain broken at entry {broken}.");
                Add("Load-test endpoints off in production", "FR-35", !(production && enabled), enabled ? "Load-test endpoints are on." : "Load-test endpoints are off.", warnOnly: true);
                Add("Request body limit", "FR-35", true, "4 MB per request, 32 KB of headers, 60 s request timeout.");
                return new { passed = checks.Count(c => c.Status == "pass"), failed = checks.Count(c => c.Status == "fail"), warnings = checks.Count(c => c.Status == "warn"), checks };
            }).WithSummary("Checks that the protections are on: sign-in everywhere, CSP, CSRF, JSON and XML hardening, rate limits, audit chain. Reports only; attacks nothing.");
            return api;
        }

        private sealed record LoadPing(bool Ok, DateTimeOffset At, string Instance);
        public sealed record SecurityCheck(string Name, string Requirement, string Status, string Detail);
        public sealed record SurfaceEntry(string Route, string Methods, string Access, string? RateLimit, string Tags, bool Flagged);

        private static readonly string[] AnonymousAllowed = ["/health", "/openapi", "/swagger", "/error.html", "/login", "/api/v1/auth/login", "/api/v1/auth/logout"];

        /// <summary>Every routed endpoint and who may call it. Static files are left out.</summary>
        public static IReadOnlyList<SurfaceEntry> Surface(EndpointDataSource sources) => sources.Endpoints.OfType<RouteEndpoint>()
            .Where(e => e.Metadata.GetMetadata<Microsoft.AspNetCore.StaticAssets.StaticAssetDescriptor>() is null)
            .Select(e =>
            {
                var route = "/" + (e.RoutePattern.RawText ?? "").TrimStart('/');
                var methods = string.Join(",", e.Metadata.GetMetadata<HttpMethodMetadata>()?.HttpMethods ?? ["*"]);
                var auth = e.Metadata.GetOrderedMetadata<IAuthorizeData>();
                var anonymous = e.Metadata.GetMetadata<IAllowAnonymous>() is not null || auth.Count == 0;
                var access = anonymous ? "anonymous" : string.Join(" + ", auth.Select(a => a.Policy ?? a.Roles ?? "signed-in").Distinct());
                var limit = e.Metadata.GetMetadata<EnableRateLimitingAttribute>()?.PolicyName;
                var tags = string.Join(",", e.Metadata.GetOrderedMetadata<Microsoft.AspNetCore.Http.Metadata.ITagsMetadata>().SelectMany(t => t.Tags).Distinct());
                return new SurfaceEntry(route, methods, access, limit, tags, anonymous && !AnonymousAllowed.Any(a => route.StartsWith(a, StringComparison.OrdinalIgnoreCase)) && route is not ("/{*path:nonfile}" or "/{**path:file}"));   // the page fallback and the static-file route
            }).OrderBy(e => e.Route, StringComparer.Ordinal).ToArray();

        public static object ThreadPoolNow()
        {
            ThreadPool.GetAvailableThreads(out var workers, out var io);
            ThreadPool.GetMaxThreads(out var maxWorkers, out var maxIo);
            return new { threads = ThreadPool.ThreadCount, pending = ThreadPool.PendingWorkItemCount, completed = ThreadPool.CompletedWorkItemCount, busyWorkers = maxWorkers - workers, busyIo = maxIo - io };
        }
    }
}
