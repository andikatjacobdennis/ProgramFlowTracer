namespace Volvo.TestRequestTool.Web
{
    // =====================================================================================================================
    // FR-07, FR-33..FR-39, FR-43, FR-45, FR-47 · Durable jobs with leases, bounded admission and fair scheduling
    // =====================================================================================================================
    /// <summary>Limits for jobs (configuration section "Jobs"). Every limit rejects excess work explicitly (FR-35).</summary>
    public sealed class JobOptions
    {
        /// <summary>Workers in this instance (FR-33, FR-43). With more than one, the last never takes batch jobs, so interactive work always has a worker.</summary>
        /// <summary>0 makes the instance API-only, for hosting API and workers separately (FR-63).</summary>
        [System.ComponentModel.DataAnnotations.Range(0, 64)] public int Workers { get; set; } = Math.Clamp(Environment.ProcessorCount / 2, 1, 4);
        [System.ComponentModel.DataAnnotations.Range(1, 1_000_000)] public int MaxQueued { get; set; } = 1000;
        [System.ComponentModel.DataAnnotations.Range(1, 10_000)] public int MaxQueuedPerUser { get; set; } = 20;
        /// <summary>Requests for more vehicles than this run in the batch lane (FR-45).</summary>
        public int BatchThreshold { get; set; } = 5;
        public int MaxVehiclesPerJob { get; set; } = 50;
        public TimeSpan Lease { get; set; } = TimeSpan.FromSeconds(30);
        public TimeSpan MaxDuration { get; set; } = TimeSpan.FromMinutes(2);
        /// <summary>A batch job waiting longer than this is scheduled like interactive work, so it is never delayed indefinitely.</summary>
        public TimeSpan BatchAging { get; set; } = TimeSpan.FromSeconds(30);
    }
}
