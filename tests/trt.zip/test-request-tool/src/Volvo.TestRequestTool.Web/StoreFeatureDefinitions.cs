using System.Text.Json.Nodes;
using Microsoft.FeatureManagement;
using Volvo.TestRequestTool.Application;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>Turns the stored flag states into Microsoft.FeatureManagement definitions (AlwaysOn, or the targeting filter).</summary>
    public sealed class StoreFeatureDefinitions : IFeatureDefinitionProvider
    {
        private readonly IWorkspaceStore _store;

        public StoreFeatureDefinitions(IWorkspaceStore store)
        {
            _store = store;
        }

        public async Task<FeatureDefinition> GetFeatureDefinitionAsync(string featureName)
        {
            var flag = FeatureFlags.Catalogue.FirstOrDefault(f => f.Name == featureName);
            var stored = (await _store.SettingAsync(FeatureFlags.Key, CancellationToken.None))?.Value;
            return Define(featureName, flag is null ? new JsonObject { ["mode"] = "off" } : FeatureFlags.StateOf(stored, flag));
        }

        public async IAsyncEnumerable<FeatureDefinition> GetAllFeatureDefinitionsAsync()
        {
            var stored = (await _store.SettingAsync(FeatureFlags.Key, CancellationToken.None))?.Value;
            foreach (var f in FeatureFlags.Catalogue)
            {
                yield return Define(f.Name, FeatureFlags.StateOf(stored, f));
            }
        }

        private static FeatureDefinition Define(string name, JsonObject state)
        {
            var mode = state["mode"]?.ToString();
            if (mode == "on")
            {
                return new FeatureDefinition { Name = name, EnabledFor = [new FeatureFilterConfiguration { Name = "AlwaysOn" }] };
            }

            if (mode != "targeted")
            {
                return new FeatureDefinition { Name = name, EnabledFor = [] };
            }
            // The targeting filter reads its audience from configuration-shaped parameters.
            var values = new Dictionary<string, string?> { ["Audience:DefaultRolloutPercentage"] = (state["rollout"]?.GetValue<int>() ?? 0).ToString(System.Globalization.CultureInfo.InvariantCulture) };
            var i = 0;
            foreach (var u in state["users"]?.AsArray() ?? [])
            {
                values[$"Audience:Users:{i++}"] = u?.ToString();
            }

            i = 0;
            foreach (var g in state["groups"]?.AsArray() ?? [])
            {
                values[$"Audience:Groups:{i}:Name"] = g?.ToString();
                values[$"Audience:Groups:{i++}:RolloutPercentage"] = "100";
            }
            i = 0;
            foreach (var x in state["exclude"]?.AsArray() ?? [])
            {
                values[$"Audience:Exclusion:Users:{i++}"] = x?.ToString();
            }

            return new FeatureDefinition { Name = name, EnabledFor = [new FeatureFilterConfiguration { Name = "Microsoft.Targeting", Parameters = new ConfigurationBuilder().AddInMemoryCollection(values).Build() }] };
        }
    }
}
