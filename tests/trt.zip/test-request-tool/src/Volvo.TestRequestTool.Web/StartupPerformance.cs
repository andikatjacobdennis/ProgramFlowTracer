using System.IO.Compression;
using Microsoft.AspNetCore.ResponseCompression;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Fast first load and steady responses:
    /// <list type="bullet">
    /// <item><b>Warm-up.</b> Expensive one-time work (the catalog, the repository read into memory, the fleet summary, the OpenAPI
    /// document) runs when the host starts, not on the first person's request. Readiness reports "starting" until it is done,
    /// so a load balancer sends no traffic to a cold instance (FR-47).</item>
    /// <item><b>Compression.</b> Brotli (then gzip) for API answers and any file not already compressed. Published builds serve
    /// static files pre-compressed by MapStaticAssets, which this middleware leaves alone. API answers never mix secrets with
    /// caller-supplied text, so compressing them over HTTPS does not open a BREACH-style leak.</item>
    /// <item><b>Output cache.</b> The OpenAPI document is built once and served from memory.</item>
    /// </list>
    /// </summary>
    public static class StartupPerformance
    {
        public static WebApplicationBuilder AddTestRequestPerformance(this WebApplicationBuilder builder)
        {
            builder.Services.AddResponseCompression(o =>
            {
                o.EnableForHttps = true;
                o.Providers.Add<BrotliCompressionProvider>();
                o.Providers.Add<GzipCompressionProvider>();
                o.MimeTypes = ResponseCompressionDefaults.MimeTypes.Concat(["application/problem+json", "image/svg+xml", "text/csv", "application/xml"]);
            });
            // Fastest keeps CPU low under load; the size difference to Optimal is small for JSON.
            builder.Services.Configure<BrotliCompressionProviderOptions>(o => o.Level = CompressionLevel.Fastest);
            builder.Services.Configure<GzipCompressionProviderOptions>(o => o.Level = CompressionLevel.Fastest);
            builder.Services.AddOutputCache(o => o.AddPolicy("openapi", p => p.Expire(TimeSpan.FromHours(1))));
            builder.Services.AddSingleton<Warmup>();
            builder.Services.AddHostedService(sp => sp.GetRequiredService<Warmup>());
            builder.Services.AddHealthChecks().AddCheck<WarmupHealthCheck>("warm-up", tags: ["ready"]);
            return builder;
        }

        public static WebApplication UseTestRequestPerformance(this WebApplication app)
        {
            // Development only: pages are served uncompressed. Visual Studio's Hot Reload (browser refresh) injects its script
            // into HTML responses and fails on a compressed body, which leaves a blank page. HTML is small; scripts, styles and
            // API answers stay compressed, and production is unchanged.
            if (app.Environment.IsDevelopment())
            {
                app.Use((ctx, next) =>
            {
                if (IsPageRequest(ctx.Request))
                {
                    ctx.Request.Headers.AcceptEncoding = "identity";
                }

                return next(ctx);
            });
            }

            app.UseResponseCompression();
            return app;
        }

        /// <summary>A request for an HTML page: the site root, a .html file, or a browser navigation.</summary>
        public static bool IsPageRequest(HttpRequest request)
        {
            var path = request.Path.Value ?? "";
            if (path is "" or "/" || path.EndsWith('/') || path.EndsWith(".html", StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            return request.Headers.Accept.ToString().Contains("text/html", StringComparison.OrdinalIgnoreCase)
                && !path.StartsWith("/api/", StringComparison.OrdinalIgnoreCase);
        }
    }
}
