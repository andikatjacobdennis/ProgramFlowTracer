namespace Volvo.TestRequestTool.Web
{
    /// <summary>Settings for testing from outside (configuration section "Testing").</summary>
    public sealed class TestingOptions
    {
        /// <summary>The /api/v1/loadtest endpoints. On by default only in Development and Testing.</summary>
        public bool? LoadEndpoints { get; set; }
        /// <summary>Requests per second per caller on the load-test endpoints (token bucket). The global API limit does not apply to them.</summary>
        [System.ComponentModel.DataAnnotations.Range(1, 1_000_000)] public int LoadRequestsPerSecond { get; set; } = 5000;
        /// <summary>Load-test requests in progress at once across all callers; more are refused with 503 so the host stays responsive.</summary>
        [System.ComponentModel.DataAnnotations.Range(1, 100_000)] public int MaxConcurrentLoad { get; set; } = 512;
    }
}
