using System.Globalization;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// The pages behind the request journey, all computed from records:
    /// <list type="bullet">
    /// <item><b>Requests</b> (/requests/overview): your validations, queued jobs and draft, plus the reviews of others you may see,
    /// each with a status from its records (running, draft, blocked, needs revalidation, awaiting review, approved, completed).</item>
    /// <item><b>Request execution</b> (/requests/{id}/trace): the stages timed on the server, queueing from the job, attempts and
    /// events; the sanitised trace holds names, timings, vehicle ids and counts only.</item>
    /// <item><b>Change impact</b> (/impact) and <b>Fleet readiness</b> (/fleet/readiness): see ChangeImpact.</item>
    /// <item><b>Reviews</b> (/reviews): request review, discuss, approve or request changes (separation of duties), final checks,
    /// submit and the receipt. See ReviewService.</item>
    /// </list>
    /// When the "require-approval" flag is on, /vda/commit refuses a request without an approved review (RequireApprovalFilter).
    /// </summary>
    public static class ReviewEndpoints
    {
        public static IServiceCollection AddReviews(this IServiceCollection services)
        {
            services.AddSingleton<ReviewService>();
            services.AddSingleton<IRequestEvents, RequestEventLog>();
            services.AddSingleton<ChangeImpact>();
            services.AddSingleton<EngineeringInsights>();
            return services;
        }

        private static bool CanApprove(HttpContext ctx) => ctx.User.IsInRole("Writer");

        private static async Task<bool> WritesPaused(HttpContext ctx) =>
            (await ctx.RequestServices.GetRequiredService<IWorkspaceStore>().PausesAsync(ctx.RequestAborted)).Any(p => p.Scope == "writes");

        private static string Redact(string? s) => TestRequestLogStore.Redact(s ?? "");

        /// <summary>A review step as a diagnostic event, visible to the author, the person acting and administrators.</summary>
        private static void Log(HttpContext ctx, ReviewRecord r, LogLevel level, string message, DateTimeOffset? at = null, string? detail = null) =>
            ctx.RequestServices.GetService<TestRequestLogStore>()?.Event("Review", level, message, r.RequestId, [r.AuthorId, ActorFactory.From(ctx.User).Id], at,
                fields: new Dictionary<string, string> { ["review"] = r.Id.ToString("N")[..12], ["status"] = r.Status, ["revision"] = r.ProposalRevision?.ToString(CultureInfo.InvariantCulture) ?? "", ["detail"] = detail ?? "" });

        /// <summary>A review as the client needs it: the record plus what this person may do with it now.</summary>
        /// <summary>Everyone who could decide a review (enabled, with the Reviewer or Admin role), from the repository's users.</summary>
        private static async Task<IReadOnlyList<UserAccount>> People(HttpContext ctx) => await ctx.RequestServices.GetRequiredService<IWorkspaceStore>().UsersAsync(ctx.RequestAborted);

        private static object View(ReviewRecord r, HttpContext ctx, IReadOnlyList<UserAccount> people)
        {
            var me = ActorFactory.From(ctx.User).Id;
            var mine = r.AuthorId == me;
            return new
            {
                r.Id,
                r.RequestId,
                label = ReviewService.Label(r.RequestId),
                r.AuthorId,
                r.AuthorName,
                r.CreatedAt,
                r.ProposalRevision,
                r.Status,
                r.Evidence,
                r.Comments,
                r.Decision,
                r.Submission,
                r.Version,
                r.Assignee,
                submissionLabel = r.Submission?.Id,
                can = new { assign = r.Status == "open" && (mine || CanApprove(ctx)), take = r.Status == "open" && !mine && CanApprove(ctx) && r.Assignee?.Id != me, decide = !mine && CanApprove(ctx) && r.Status == "open", comment = r.Status is not ("withdrawn" or "submitted"), withdraw = mine && r.Status is "open" or "approved", submit = CanApprove(ctx) && r.Status == "approved" },
                // Who can decide: the enabled accounts with the Reviewer or Admin role, never the author. Without any (people who
                // sign in through an identity provider and never got an account record) the page names the roles instead (null).
                reviewers = r.Status == "open" && people.Any(u => u.Enabled && u.Role is "Reviewer" or "Admin" && u.Id != r.AuthorId)
                    ? people.Where(u => u.Enabled && (u.Role is "Reviewer" or "Admin") && u.Id != r.AuthorId).OrderBy(u => u.DisplayName, StringComparer.OrdinalIgnoreCase).Take(200).Select(u => new { id = u.Id, name = u.DisplayName, role = u.Role }).ToArray()
                    : null,
                why = mine && r.Status == "open" ? "You can't approve your own change. Someone with the Reviewer or Admin role decides; their decision appears on this page." : !CanApprove(ctx) ? "Deciding and submitting need the Reviewer or Admin role." : null,
            };
        }

        public static RouteGroupBuilder MapReviews(this RouteGroupBuilder api)
        {
            // ------------------------------------------------------------------ requests hub
            api.MapGet("/requests/overview", async (HttpContext ctx, IWorkspaceStore store, ReviewService reviews, TimeProvider clock, CancellationToken ct) =>
            {
                var actor = ActorFactory.From(ctx.User);
                var items = new List<JsonObject>();
                var reviewList = await reviews.ListAsync(actor, "all", ct);
                var currentRevisions = (await store.VehiclesAsync(ct)).ToDictionary(v => new ProductDocument(v.Product).Id, v => v.Revision, StringComparer.Ordinal);
                var jobs = await store.JobsAsync(actor.Id, 200, ct);
                foreach (var e in await store.HistoryAsync(actor.Id, 0, 200, ct))
                {
                    var review = reviewList.Where(r => r.RequestId == e.Id).OrderByDescending(r => r.CreatedAt).FirstOrDefault();
                    var blockers = e.Outcomes.Sum(o => o.Issues.Count(i => i.Severity == 0));
                    var stale = e.Outcomes.Any(o => currentRevisions.TryGetValue(o.VehicleId, out var rev) && rev != o.BaseRevision);
                    var (status, action) = review?.Status switch
                    {
                        "submitted" => ("completed", "Receipt"),
                        "approved" => (stale ? "needs-revalidation" : "approved", stale ? "Resolve" : "Submit"),
                        "open" => (stale ? "needs-revalidation" : "awaiting-review", stale ? "Resolve" : "Track"),
                        "changes_requested" => ("changes-requested", "Resolve"),
                        _ => stale ? ("needs-revalidation", "Resolve") : blockers > 0 ? ("blocked", "Inspect") : ("validated", "Request review"),
                    };
                    var job = jobs.FirstOrDefault(j => j.ResultId == e.Id || j.ResultIdFor == e.Id);
                    items.Add(Item(e.Id, ReviewService.Label(e.Id), e.Kind.ToString(), e.Outcomes.Select(o => (o.VehicleId, ProposalDiff.Title(o.Original), ProposalDiff.Architecture(o.Original))), status, action,
                        actor.Id, actor.DisplayName, true, review?.Comments.LastOrDefault()?.At ?? e.CreatedAt, review, e.Outcomes.Sum(o => ProposalDiff.Rows(o.Original, o.Proposal).Count), blockers, job?.Id));
                }
                foreach (var r in reviewList.Where(r => r.AuthorId != actor.Id))
                {
                    var vehicles = r.Evidence.A("vehicles").Objects().ToArray();
                    var stale = r.Status is "open" or "approved" && vehicles.Any(v => currentRevisions.TryGetValue(v.S("id"), out var rev) && rev != v["baseRevision"]!.GetValue<long>());
                    var (status, action) = r.Status switch
                    {
                        "submitted" => ("completed", "Receipt"),
                        "approved" => (stale ? "needs-revalidation" : "approved", "Submit"),
                        "open" => (stale ? "needs-revalidation" : "awaiting-review", "Review"),
                        "changes_requested" => ("changes-requested", "Open"),
                        _ => ("withdrawn", "Open"),
                    };
                    items.Add(Item(r.RequestId, ReviewService.Label(r.RequestId), r.Evidence.S("requestKind"), vehicles.Select(v => (v.S("id"), v.S("title"), v.S("architecture"))), status, action,
                        r.AuthorId, r.AuthorName, false, r.Comments.LastOrDefault()?.At ?? r.CreatedAt, r, r.Evidence["totals"].I("changes"), r.Evidence["totals"].I("blockers"), null));
                }
                foreach (var j in jobs.Where(j => !j.Finished))
                {
                    items.Add(Item(j.Id, "REQ-" + j.Id.ToString("N")[..6].ToUpperInvariant(), j.Kind, j.Input.A("products").Objects().Select(p =>
                    {
                        var d = new ProductDocument(p);
                        return (d.Id, ProposalDiff.Title(p), ProposalDiff.Architecture(p));
                    }),
                        j.Status == "queued" ? "queued" : "running", "Track", actor.Id, actor.DisplayName, true, j.StartedAt ?? j.CreatedAt, null, 0, 0, j.Id, attempt: j.Attempt));
                }

                var proposals = await store.ProposalRevisionsAsync(actor.Id, "workspace", ct);
                var latestDraft = proposals.LastOrDefault();
                var latestValidation = items.Where(i => i["mine"]!.GetValue<bool>()).Select(i => DateTimeOffset.Parse(i["updatedAt"]!.GetValue<string>(), CultureInfo.InvariantCulture)).DefaultIfEmpty(DateTimeOffset.MinValue).Max();
                var drafts = latestDraft is not null && latestDraft.At > latestValidation ? 1 : 0;
                if (drafts == 1)
                {
                    items.Add(Item(Guid.Empty, "Draft · revision " + latestDraft!.Number, "Draft", latestDraft.Summary.S("vehicle") is { Length: > 0 } v ? [("", v, "")] : [], "draft", "Continue",
                        actor.Id, actor.DisplayName, true, latestDraft.At, null, latestDraft.Summary.I("changes"), 0, null, proposalRevision: latestDraft.Number));
                }

                var today = clock.GetUtcNow().UtcDateTime.Date;
                return new
                {
                    generatedAt = clock.GetUtcNow(),
                    counts = new
                    {
                        drafts,
                        running = items.Count(i => i["status"]!.GetValue<string>() is "running" or "queued"),
                        awaitingReview = reviewList.Count(r => r.Status == "open" && r.AuthorId != actor.Id),
                        completedToday = reviewList.Count(r => r.Status == "submitted" && r.Submission!.At.UtcDateTime.Date == today),
                    },
                    items = items.OrderByDescending(i => i["updatedAt"]!.GetValue<string>(), StringComparer.Ordinal).ToArray(),
                };
            }).RequireFeature("reviews").RequireRateLimiting("reads").WithTags("Requests").WithSummary("Your requests and the reviews you may see, with statuses from their records and the next action.");

            // ------------------------------------------------------------------ request execution
            api.MapGet("/requests/{id:guid}/trace", async (Guid id, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                var actor = ActorFactory.From(ctx.User);
                var e = await store.ExecutionAsync(id, actor.Id, ct) ?? throw new RequestFault(404, "request_missing", "Request was not found.");
                var job = (await store.JobsAsync(actor.Id, 500, ct)).FirstOrDefault(j => j.ResultId == id || j.ResultIdFor == id);
                var queueMs = job?.StartedAt is DateTimeOffset s ? Math.Max(0, (s - job.CreatedAt).TotalMilliseconds) : 0;
                var stages = new List<object>();
                if (job is not null)
                {
                    stages.Add(new { order = 0, id = "queue", name = "Queue", kind = "queue", startMs = 0.0, durationMs = Math.Round(queueMs, 1), outcome = "completed", vehicleId = (string?)null, note = (string?)("lane " + job.Lane) });
                }

                foreach (var st in e.Trace?.Stages ?? [])
                {
                    stages.Add(new { order = st.Order, st.Id, st.Name, st.Kind, startMs = Math.Round(queueMs + st.StartMs, 2), st.DurationMs, st.Outcome, st.VehicleId, st.Note });
                }

                var processing = e.Trace?.TotalMs ?? 0;
                var total = queueMs + processing;
                var warnings = e.Trace?.Stages.Count(st => st.Outcome == "warning") ?? 0;
                var blockers = e.Outcomes.Sum(o => o.Issues.Count(i => i.Severity == 0));
                var events = new List<object> { new { atMs = 0.0, text = "Request accepted", tone = "queue" } };
                if (job is not null)
                {
                    events.Add(new { atMs = Math.Round(queueMs, 1), text = "Worker started" + (job.Attempt > 1 ? $" (attempt {job.Attempt})" : ""), tone = "info" });
                }

                foreach (var st in e.Trace?.Stages.Where(st => st.Outcome != "completed") ?? [])
                {
                    events.Add(new { atMs = Math.Round(queueMs + st.StartMs + st.DurationMs, 1), text = st.Name + (st.VehicleId is null ? "" : " · " + st.VehicleId.Replace('|', ' ')) + ": " + (st.Note ?? st.Outcome), tone = "warning" });
                }

                events.Add(new { atMs = Math.Round(total, 1), text = "Result and evidence saved", tone = "good" });
                return new
                {
                    id = e.Id,
                    label = ReviewService.Label(e.Id),
                    kind = e.Kind.ToString(),
                    createdAt = e.CreatedAt,
                    traceId = e.Id.ToString("N"),
                    timed = e.Trace is not null,
                    status = blockers > 0 ? "blocked" : warnings > 0 ? "warnings" : "completed",
                    vehicles = e.Outcomes.Select(o => new { id = o.VehicleId, title = ProposalDiff.Title(o.Original), architecture = ProposalDiff.Architecture(o.Original), blocking = o.Issues.Count(i => i.Severity == 0), limited = o.LimitedValidation }),
                    totals = new { elapsedMs = Math.Round(total, 1), queueMs = Math.Round(queueMs, 1), processingMs = Math.Round(processing, 1), warnings, blockers },
                    job = job is null ? null : new { job.Id, job.Lane, job.Status, job.Attempt, attempts = job.Attempts?.Count ?? 0 },
                    stages,
                    events,
                    note = e.Trace is null ? "This request was recorded before stage timing existed: no stages are available." : "Times are measured on the server from acceptance. Saving the result is not timed separately.",
                };
            }).RequireFeature("execution-trace").RequireRateLimiting("reads").WithTags("Requests").WithSummary("The timed stages, queueing, attempts and events of one of your requests (sanitised: no payload content).");

            // ------------------------------------------------------------------ change impact and fleet readiness
            api.MapPost("/impact", async (ImpactBody body, HttpContext ctx, ChangeImpact impact, CancellationToken ct) =>
                await impact.ImpactAsync(ActorFactory.From(ctx.User), body.VehicleId ?? throw new RequestFault(400, "vehicle_required", "Choose a vehicle."), body.Product, body.RequestId, ct))
                .RequireFeature("change-impact").RequireRateLimiting("reads").WithTags("Vehicles").WithSummary("The change impact graph of a proposal (the given product, a validation's proposal, or the vehicle as stored).");
            api.MapGet("/fleet/readiness", async (HttpContext ctx, ChangeImpact impact, CancellationToken ct) => await impact.ReadinessAsync(ActorFactory.From(ctx.User), ct))
                .RequireFeature("fleet-readiness").RequireRateLimiting("reads").WithTags("Vehicles").WithSummary("Readiness of every vehicle you may read: checks from your latest validation, approval from its review, overall state.");
            api.MapGet("/fleet/readiness/{series}/{number}/revalidation", async (string series, string number, HttpContext ctx, ChangeImpact impact, CancellationToken ct) =>
                await impact.RevalidationAsync(ActorFactory.From(ctx.User), VehicleIdentity.Key(series, number), ct))
                .RequireFeature("fleet-readiness").RequireRateLimiting("reads").WithTags("Vehicles").WithSummary("The request that validates this vehicle again (your latest options, or a software refresh).");

            api.MapGet("/insights/engineering", async (int? days, int? context, HttpContext ctx, EngineeringInsights insights, CancellationToken ct) =>
                await insights.BuildAsync(ActorFactory.From(ctx.User), ctx.User.IsInRole("Admin"), days ?? 30, context, ct))
                .RequireFeature("engineering-insights").RequireRateLimiting("reads").WithTags("Vehicles").WithSummary("Demand, pass rate, processing time, readiness, blockers, queue pressure and time by stage over a period (administrators: everyone's requests; others: your own).");

            // ------------------------------------------------------------------ reviews
            var g = api.MapGroup("/reviews").WithTags("Reviews").RequireFeature("reviews");
            g.MapPost("/", async (NewReview body, HttpContext ctx, ReviewService reviews, CancellationToken ct) =>
            {
                var r = await reviews.RequestAsync(ActorFactory.From(ctx.User), body.RequestId, body.ProposalRevision, Redact(body.Note), ct);
                Log(ctx, r, LogLevel.Information, "Review requested");
                return Results.Created($"/api/v1/reviews/{r.Id}", View(r, ctx, await People(ctx)));
            }).RequireAuthorization("Operator").RequireRateLimiting("writes").Audited("review.request").WithSummary("Ask for a review of one of your validations. The evidence (revisions, changes, checks) is captured now. Asking again returns the open review.");
            g.MapGet("/", async (string? scope, HttpContext ctx, ReviewService reviews, CancellationToken ct) =>
                {
                    var people = await People(ctx);
                    return (await reviews.ListAsync(ActorFactory.From(ctx.User), scope ?? "all", ct)).Select(r => View(r, ctx, people));
                }).WithSummary("Reviews you may see: scope to-review, mine or all.");
            g.MapGet("/{id:guid}", async (Guid id, HttpContext ctx, ReviewService reviews, CancellationToken ct) => View(await reviews.GetAsync(ActorFactory.From(ctx.User), id, ct), ctx, await People(ctx)));
            g.MapGet("/by-request/{requestId:guid}", async (Guid requestId, HttpContext ctx, ReviewService reviews, CancellationToken ct) =>
                await reviews.ForRequestAsync(ActorFactory.From(ctx.User), requestId, ct) is { } r ? Results.Ok(View(r, ctx, await People(ctx))) : Results.Problem(statusCode: 404, title: "review_missing", detail: "No review for this request yet."));
            g.MapPost("/{id:guid}/comments", async (Guid id, ReviewText body, HttpContext ctx, ReviewService reviews, CancellationToken ct) =>
                View(await reviews.CommentAsync(ActorFactory.From(ctx.User), id, Redact(body.Text), ct), ctx, await People(ctx))).RequireRateLimiting("writes").WithSummary("Add to the review discussion (500 characters).");
            g.MapPost("/{id:guid}/decision", async (Guid id, ReviewDecisionBody body, HttpContext ctx, ReviewService reviews, CancellationToken ct) =>
            {
                var r = await reviews.DecideAsync(ActorFactory.From(ctx.User), CanApprove(ctx), id, body.Decision, body.Checklist, Redact(body.Note), body.Version, ct);
                Log(ctx, r, r.Status == "approved" ? LogLevel.Information : LogLevel.Warning, r.Status == "approved" ? "Approval recorded" : "Changes requested");
                return View(r, ctx, await People(ctx));
            })
                .RequireRateLimiting("writes").Audited("review.decision").WithSummary("Approve (with the checklist) or request changes (with a note). Never by the author; needs the Writer role; refused when the evidence is stale or blocked.");
            // Assign to a reviewer from the pool, take it yourself (a reviewer), or open it to everyone again (no id).
            g.MapPost("/{id:guid}/assign", async (Guid id, ReviewAssignBody body, HttpContext ctx, ReviewService reviews, CancellationToken ct) =>
            {
                var actor = ActorFactory.From(ctx.User);
                string? name = null;
                if (!string.IsNullOrEmpty(body.AssigneeId))
                {
                    if (body.AssigneeId == actor.Id)
                    {
                        name = actor.DisplayName;   // taking it: the service checks the role
                    }
                    else if (await ctx.RequestServices.GetRequiredService<IWorkspaceStore>().UserAsync(body.AssigneeId, ct) is { Enabled: true } u && u.Role is "Reviewer" or "Admin")
                    {
                        name = u.DisplayName;
                    }
                    else
                    {
                        throw new RequestFault(400, "assignee_unknown", "Choose someone with the Reviewer or Admin role.");
                    }
                }
                return View(await reviews.AssignAsync(actor, CanApprove(ctx), id, body.AssigneeId, name, body.Version, ct), ctx, await People(ctx));
            }).RequireRateLimiting("writes").Audited("review.assign");
            g.MapPost("/{id:guid}/withdraw", async (Guid id, ReviewVersion body, HttpContext ctx, ReviewService reviews, CancellationToken ct) =>
                View(await reviews.WithdrawAsync(ActorFactory.From(ctx.User), id, body.Version, ct), ctx, await People(ctx))).RequireRateLimiting("writes").Audited("review.withdraw");
            g.MapGet("/{id:guid}/checks", async (Guid id, HttpContext ctx, ReviewService reviews, CancellationToken ct) =>
                await reviews.ChecksAsync(ActorFactory.From(ctx.User), CanApprove(ctx), await WritesPaused(ctx), id, ct)).WithSummary("The final checks before submitting (run again on submission).");
            g.MapPost("/{id:guid}/submit", async (Guid id, SubmitReview body, HttpContext ctx, ReviewService reviews, Microsoft.Extensions.Caching.Hybrid.HybridCache cache, CancellationToken ct) =>
            {
                var before = (await ctx.RequestServices.GetRequiredService<IWorkspaceStore>().ReviewAsync(id, ct))?.Status;
                var r = await reviews.SubmitAsync(ActorFactory.From(ctx.User), CanApprove(ctx), await WritesPaused(ctx), id, body.Confirmed, ct);
                await cache.RemoveByTagAsync(VehicleInsights.FleetTag, ct);
                if (before != "submitted")
                {
                    foreach (var s in r.Submission!.Steps.Skip(1))
                    {
                        Log(ctx, r, LogLevel.Information, s.Text + " · " + s.Detail, s.At);
                    }
                }

                return View(r, ctx, await People(ctx));
            }).RequireAuthorization("Writer").RequireRateLimiting("writes").Audited("review.submit").Pausable("writes").WithSummary("Commit the approved revision to the VDA repository after the final checks. Submitting again returns the same receipt.");
            g.MapGet("/{id:guid}/receipt", async (Guid id, HttpContext ctx, ReviewService reviews, CancellationToken ct) =>
            {
                var r = await reviews.GetAsync(ActorFactory.From(ctx.User), id, ct);
                if (r.Submission is null)
                {
                    throw new RequestFault(404, "receipt_missing", "This review has not been submitted.");
                }

                var receipt = new
                {
                    submission = r.Submission.Id,
                    request = ReviewService.Label(r.RequestId),
                    requestId = r.RequestId,
                    target = r.Submission.Target,
                    proposalRevision = r.ProposalRevision,
                    approvedBy = r.Decision?.ActorName,
                    approvedAt = r.Decision?.At,
                    submittedBy = r.Submission.ActorName,
                    completedAt = r.Submission.At,
                    vehicles = r.Submission.Vehicles,
                    changes = r.Evidence.A("vehicles").Objects().Select(v => new { vehicle = v.S("title"), changes = v["changes"] }),
                    steps = r.Submission.Steps,
                    note = "This receipt confirms the repository update. No software was installed on a vehicle.",
                };
                ctx.Response.Headers.ContentDisposition = $"attachment; filename=\"{r.Submission.Id}.json\"";
                return Results.Json(receipt);
            }).RequireRateLimiting("exports").WithSummary("The submission receipt as a JSON file.");
            return api;
        }

        private static JsonObject Item(Guid id, string label, string kind, IEnumerable<(string Id, string Title, string Architecture)> vehicles, string status, string action, string ownerId, string ownerName, bool mine,
            DateTimeOffset updated, ReviewRecord? review, int changes, int blockers, Guid? jobId, int? attempt = null, int? proposalRevision = null) => new()
            {
                ["id"] = id == Guid.Empty ? null : id,
                ["label"] = label,
                ["kind"] = kind,
                ["vehicles"] = new JsonArray(vehicles.Select(v => (JsonNode)new JsonObject { ["id"] = v.Id, ["title"] = v.Title, ["architecture"] = v.Architecture }).ToArray()),
                ["status"] = status,
                ["action"] = action,
                ["owner"] = new JsonObject { ["id"] = ownerId, ["name"] = ownerName },
                ["mine"] = mine,
                ["updatedAt"] = updated.ToString("O", CultureInfo.InvariantCulture),
                ["reviewId"] = review?.Id,
                ["reviewer"] = review?.Decision?.ActorName,
                ["assignee"] = review is { Status: "open", Assignee: { } a } ? new JsonObject { ["id"] = a.Id, ["name"] = a.Name } : null,
                ["proposalRevision"] = proposalRevision ?? review?.ProposalRevision,
                ["changes"] = changes,
                ["blockers"] = blockers,
                ["jobId"] = jobId,
                ["attempt"] = attempt,
            };
    }
}
