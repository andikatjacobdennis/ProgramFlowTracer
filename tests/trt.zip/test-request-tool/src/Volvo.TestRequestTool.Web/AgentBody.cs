namespace Volvo.TestRequestTool.Web
{
    public sealed record AgentBody([property: System.ComponentModel.DataAnnotations.StringLength(2000)] string? Goal, [property: System.ComponentModel.DataAnnotations.MaxLength(6)] ContextRefIn[]? Include);
}
