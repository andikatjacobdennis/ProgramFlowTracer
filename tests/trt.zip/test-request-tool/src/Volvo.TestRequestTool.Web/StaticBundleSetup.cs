namespace Volvo.TestRequestTool.Web
{
    public static class StaticBundleSetup
    {
        public static WebApplicationBuilder AddStaticBundles(this WebApplicationBuilder builder)
        {
            builder.Services.AddSingleton<StaticBundles>();
            return builder;
        }

        /// <summary>Serves the page with the bundle tags and the bundles. Place after authentication, before the static files.</summary>
        public static WebApplication UseStaticBundles(this WebApplication app)
        {
            if (!app.Configuration.GetValue("Performance:Bundle", true))
            {
                return app;
            }

            var bundles = app.Services.GetRequiredService<StaticBundles>();
            // Built in the background at start-up, so the first visitor does not wait (not for test hosts, which rarely ask for the page).
            if (!app.Environment.IsEnvironment("Testing"))
            {
                _ = Task.Run(bundles.Prepare);
            }

            app.Use(async (ctx, next) =>
            {
                var path = ctx.Request.Path.Value ?? "";
                if (!HttpMethods.IsGet(ctx.Request.Method) && !HttpMethods.IsHead(ctx.Request.Method))
                {
                    await next(ctx);
                    return;
                }
                if (path is "/" or "/index.html")
                {
                    var (page, tag) = bundles.PageAndTag();
                    ctx.Response.Headers.CacheControl = "no-cache";
                    ctx.Response.Headers.ETag = tag;
                    if (ctx.Request.Headers.IfNoneMatch == tag)
                    {
                        ctx.Response.StatusCode = StatusCodes.Status304NotModified;
                        return;
                    }
                    ctx.Response.ContentType = "text/html; charset=utf-8";
                    await ctx.Response.WriteAsync(page, ctx.RequestAborted);
                    return;
                }
                if (path.StartsWith("/js/app.", StringComparison.Ordinal) || path.StartsWith("/css/app.", StringComparison.Ordinal))
                {
                    if (bundles.Find(path) is { } asset)
                    {
                        await Serve(ctx, asset);
                        return;
                    }
                }
                await next(ctx);
            });
            return app;
        }

        private static async Task Serve(HttpContext ctx, StaticBundles.Asset a)
        {
            var headers = ctx.Response.Headers;
            headers.CacheControl = "public, max-age=31536000, immutable";
            headers.ETag = a.Tag;
            headers.Vary = "Accept-Encoding";
            if (ctx.Request.Headers.IfNoneMatch == a.Tag)
            {
                ctx.Response.StatusCode = StatusCodes.Status304NotModified;
                return;
            }
            var accept = ctx.Request.Headers.AcceptEncoding.ToString();
            var (body, encoding) = accept.Contains("br", StringComparison.OrdinalIgnoreCase) ? (a.Brotli, "br") : accept.Contains("gzip", StringComparison.OrdinalIgnoreCase) ? (a.Gzip, "gzip") : (a.Raw, null);
            if (encoding is not null)
            {
                headers.ContentEncoding = encoding;
            }

            ctx.Response.ContentType = a.ContentType;
            ctx.Response.ContentLength = body.Length;
            if (HttpMethods.IsHead(ctx.Request.Method))
            {
                return;
            }

            await ctx.Response.Body.WriteAsync(body, ctx.RequestAborted);
        }
    }
}
