using System.Collections.Concurrent;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Batch runs (FR-11): one request for each of many vehicles, run one after another. After each request completes the
    /// runner waits (1 second by default) before starting the next, so a batch never floods the system. Every request is an
    /// ordinary tracked job (idempotent per batch item, leased, retried safely), so the batch survives a restart and a
    /// retry runs only the items that did not succeed. Progress streams live (Server-Sent Events); the report at the end can
    /// be downloaded as JSON or CSV.
    /// </summary>
    public sealed class BatchRunner : BackgroundService
    {
        private readonly IWorkspaceStore _store;
        private readonly JobSignal _signal;
        private readonly TimeProvider _clock;
        private readonly ILogger<BatchRunner> _log;
        private readonly ConcurrentDictionary<Guid, Task> _running = new();
        public const int MaxConcurrentBatches = 2;

        public BatchRunner(IWorkspaceStore store, JobSignal signal, TimeProvider clock, ILogger<BatchRunner> log)
        {
            _store = store;
            _signal = signal;
            _clock = clock;
            _log = log;
        }

        protected override async Task ExecuteAsync(CancellationToken stop)
        {
            while (!stop.IsCancellationRequested)
            {
                try
                {
                    foreach (var b in await _store.BatchesAsync(null, 200, stop))
                    {
                        if (b.Status is "queued" or "running" && !_running.ContainsKey(b.Id) && _running.Count < MaxConcurrentBatches)
                        {
                            _running[b.Id] = Task.Run(() => RunAsync(b.Id, stop), stop).ContinueWith(_ => _running.TryRemove(b.Id, out var _), TaskScheduler.Default);
                        }
                    }
                }
                catch (OperationCanceledException) when (stop.IsCancellationRequested)
                {
                    return;
                }   // the host is shutting down
                catch (Exception e)
                {
                    _log.LogError(e, "Batch runner");
                }
                await Task.Delay(TimeSpan.FromSeconds(1), stop).ConfigureAwait(ConfigureAwaitOptions.SuppressThrowing);
            }
        }

        private async Task<BatchRecord?> Update(Guid id, Func<BatchRecord, BatchRecord> change)
        {
            var b = await _store.BatchAsync(id, CancellationToken.None);
            return b is null ? null : await _store.SaveBatchAsync(change(b), CancellationToken.None);
        }

        private async Task RunAsync(Guid id, CancellationToken stop)
        {
            var batch = await Update(id, b => b with { Status = "running", StartedAt = b.StartedAt ?? _clock.GetUtcNow() });
            if (batch is null)
            {
                return;
            }

            for (var i = 0; i < batch.Items.Count && !stop.IsCancellationRequested; i++)
            {
                batch = await _store.BatchAsync(id, stop);
                if (batch is null || batch.Status == "cancelled")
                {
                    return;
                }

                var item = batch.Items[i];
                if (item.Status is not ("waiting" or "running"))
                {
                    continue;
                }

                var started = _clock.GetUtcNow();
                var done = await RunItemAsync(batch, i, item, stop);
                var failed = done.Status is "failed" or "blocked";
                batch = await Update(id, b => b with { Items = b.Items.Select((x, k) => k == i ? done with { StartedAt = done.StartedAt ?? started } : x).ToArray() });
                if (batch is null || batch.Status == "cancelled")
                {
                    return;
                }

                if (failed && batch.StopOnFailure)
                {
                    await Update(id, b => b with { Status = "finished", FinishedAt = _clock.GetUtcNow(), Items = b.Items.Select(x => x.Status == "waiting" ? x with { Status = "skipped", Error = "Stopped after a failure (stop on first failure)." } : x).ToArray() });
                    return;
                }
                // The pause after each completed request (not after the last one).
                if (batch.Items.Skip(i + 1).Any(x => x.Status == "waiting"))
                {
                    await Task.Delay(Math.Max(0, batch.DelayMs), stop).ConfigureAwait(ConfigureAwaitOptions.SuppressThrowing);
                }
            }
            if (!stop.IsCancellationRequested)
            {
                await Update(id, b => b.Status == "cancelled" ? b : b with { Status = "finished", FinishedAt = _clock.GetUtcNow() });
            }
        }

        private async Task<BatchItem> RunItemAsync(BatchRecord batch, int index, BatchItem item, CancellationToken stop)
        {
            var started = _clock.GetUtcNow();
            try
            {
                var actor = batch.Actor.ToActor();
                var vehicle = await _store.VehicleAsync(item.VehicleId, stop) ?? throw new RequestFault(404, "vehicle_missing", "The vehicle no longer exists.");
                actor.DemandRead(new ProductDocument(vehicle.Product).ContextId);
                var payload = (JsonObject)batch.Template.DeepClone();
                payload["products"] = new JsonArray(vehicle.Product.DeepClone());
                // One job per batch item and round: repeating this step (after a restart) finds the same job instead of a second one.
                var key = $"batch:{batch.Id:N}:{index}:{batch.Round}";
                var job = await _store.JobByKeyAsync(actor.Id, key, stop);
                if (job is null)
                {
                    job = new JobRecord(Guid.NewGuid(), batch.Actor, batch.Kind, key, CanonicalJson.Hash(new JsonObject { ["kind"] = batch.Kind, ["payload"] = payload.DeepClone() }), payload, "queued", 1, _clock.GetUtcNow(), Lane: "batch");
                    job = await _store.SaveJobAsync(job, stop);
                    _signal.Notify();
                }
                await Update(batch.Id, b => b with { Items = b.Items.Select((x, k) => k == index ? x with { Status = "running", JobId = job.Id, StartedAt = started, Attempts = x.Attempts + 1 } : x).ToArray() });
                while (!job!.Finished && !stop.IsCancellationRequested)
                {
                    await Task.Delay(300, stop).ConfigureAwait(ConfigureAwaitOptions.SuppressThrowing);
                    if ((await _store.BatchAsync(batch.Id, CancellationToken.None))?.Status == "cancelled")
                    {
                        if (job.Status == "queued")
                        {
                            await _store.TransitionJobAsync(job.Id, job.Version, "cancelled", j => j with { ErrorCode = "job_cancelled", Error = "The batch was cancelled." }, CancellationToken.None);
                        }

                        return item with { Status = "cancelled", JobId = job.Id, FinishedAt = _clock.GetUtcNow(), Error = "The batch was cancelled." };
                    }
                    job = await _store.JobAsync(job.Id, CancellationToken.None) ?? job;
                }
                var seconds = Math.Round((_clock.GetUtcNow() - started).TotalSeconds, 2);
                if (job.Status != "succeeded")
                {
                    return item with { Status = job.Status == "cancelled" ? "cancelled" : "failed", JobId = job.Id, FinishedAt = _clock.GetUtcNow(), Seconds = seconds, Error = job.Error };
                }

                var result = await _store.ExecutionAsync(job.ResultId!.Value, actor.Id, CancellationToken.None);
                var outcomes = result?.Outcomes ?? [];
                var blocked = outcomes.Any(o => !o.LimitedValidation && o.Issues.Any(x => x.Severity == 0));
                var limited = outcomes.Any(o => o.LimitedValidation);
                return item with { Status = blocked ? "blocked" : limited ? "limited" : "ready", JobId = job.Id, ResultId = job.ResultId, FinishedAt = _clock.GetUtcNow(), Seconds = seconds, Issues = outcomes.Sum(o => o.Issues.Count(x => x.Severity <= 1)), Error = null };
            }
            catch (RequestFault f)
            {
                return item with { Status = "failed", FinishedAt = _clock.GetUtcNow(), Error = f.Message, Seconds = Math.Round((_clock.GetUtcNow() - started).TotalSeconds, 2), Attempts = item.Attempts + 1 };
            }   // a failure before the job starts still counts as an attempt
        }
    }
}
