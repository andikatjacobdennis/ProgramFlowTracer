using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;

namespace Volvo.TestRequestTool.Web
{
    public sealed record CampaignBody([property: System.ComponentModel.DataAnnotations.StringLength(80)] string? Name, [property: System.ComponentModel.DataAnnotations.StringLength(400)] string? Description,
        [property: System.ComponentModel.DataAnnotations.MaxLength(CampaignService.MaxVehicles)] string[]? VehicleIds, [property: System.ComponentModel.DataAnnotations.StringLength(40)] string? Kind, JsonObject? Template, long Version = 0);
}
