namespace Volvo.TestRequestTool.Web
{
    public sealed record ReviewAssignBody([property: System.ComponentModel.DataAnnotations.StringLength(60)] string? AssigneeId, long Version);
}
