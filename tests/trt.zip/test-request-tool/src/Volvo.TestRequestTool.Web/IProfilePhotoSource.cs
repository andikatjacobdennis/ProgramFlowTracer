namespace Volvo.TestRequestTool.Web
{
    /// <summary>Where the signed-in user's photo comes from. The user is always the caller; there is no way to ask for someone else.</summary>
    public interface IProfilePhotoSource
    {
        string Name { get; }
        Task<PhotoResult> GetAsync(HttpContext ctx, int size, CancellationToken ct);
    }
}
