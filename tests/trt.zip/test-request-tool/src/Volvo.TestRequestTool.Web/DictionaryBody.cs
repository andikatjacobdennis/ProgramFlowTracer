namespace Volvo.TestRequestTool.Web
{
    public sealed record DictionaryBody([property: System.ComponentModel.DataAnnotations.MaxLength(2000)] string[]? Words);
}
