using Microsoft.Extensions.Options;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// At start-up, every account in the settings that has no user record yet gets one (its role, contexts or every context,
    /// country and email), so administrators see everyone who can sign in before their first sign-in. Existing records are
    /// left alone: what an administrator changed on the Users page wins.
    /// </summary>
    public sealed class AccountSync : IHostedService
    {
        private readonly IOptionsMonitor<SignInSettings> _settings;
        private readonly IWorkspaceStore _store;
        private readonly ICatalog _catalog;
        private readonly ILogger<AccountSync> _log;

        public AccountSync(IOptionsMonitor<SignInSettings> settings, IWorkspaceStore store, ICatalog catalog, ILogger<AccountSync> log)
        {
            _settings = settings;
            _store = store;
            _catalog = catalog;
            _log = log;
        }

        public async Task StartAsync(CancellationToken ct)
        {
            var all = _catalog.Data.A("contexts").Objects().Select(c => c.I("id")).ToArray();
            var added = 0;
            foreach (var a in _settings.CurrentValue.Accounts.Where(a => !string.IsNullOrWhiteSpace(a.UserName)))
            {
                var id = string.IsNullOrWhiteSpace(a.Id) ? a.UserName.ToLowerInvariant() : a.Id;
                if (await _store.UserAsync(id, ct) is not null)
                {
                    continue;
                }

                var role = UserAccount.Roles.Contains(a.Role) ? a.Role : "Viewer";
                await _store.SaveUserAsync(new UserAccount(id, string.IsNullOrWhiteSpace(a.DisplayName) ? a.UserName : a.DisplayName, role, a.Contexts.Length > 0 ? a.Contexts : all, true,
                    string.IsNullOrWhiteSpace(a.Country) ? null : a.Country.ToUpperInvariant(), string.IsNullOrWhiteSpace(a.Email) ? null : a.Email), ct);
                added++;
            }
            foreach (var a in _settings.CurrentValue.Accounts.Where(a => !a.CanSignIn))
            {
                _log.LogWarning("The sign-in account {User} has no password of its own yet (empty or CHANGE-ME), so it cannot sign in. See docs/sign-in.md.", a.UserName);
            }
            if (_settings.CurrentValue.Accounts.Count == 0)
            {
                _log.LogWarning("No sign-in accounts are set (Authentication:Accounts), so nobody can sign in. See docs/sign-in.md.");
            }
            else if (added > 0)
            {
                _log.LogInformation("Added {Count} user record(s) for the sign-in accounts in the settings", added);
            }
        }

        public Task StopAsync(CancellationToken ct) => Task.CompletedTask;
    }
}
