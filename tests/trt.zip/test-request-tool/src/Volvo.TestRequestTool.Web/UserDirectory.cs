using System.Text.RegularExpressions;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// The people who use the tool, from the repository's users collection: searched, filtered, sorted and paged on the server
    /// so the list scales to lakhs of accounts, and edited by administrators (role, contexts, country, enabled).
    /// </summary>
    public sealed partial class UserDirectory
    {
        private readonly IWorkspaceStore _store;
        private readonly ICatalog _catalog;

        public UserDirectory(IWorkspaceStore store, ICatalog catalog)
        {
            _store = store;
            _catalog = catalog;
        }

        public async Task<UserPage> QueryAsync(string? q, string? role, string? status, string? country, string? sort, string? dir, int skip, int take, CancellationToken ct)
        {
            var all = await _store.UsersAsync(ct);
            var s = (q ?? "").Trim();
            bool Matches(UserAccount u) =>
                (s.Length == 0 || u.DisplayName.Contains(s, StringComparison.OrdinalIgnoreCase) || u.Id.Contains(s, StringComparison.OrdinalIgnoreCase)
                    || (u.Email?.Contains(s, StringComparison.OrdinalIgnoreCase) ?? false) || string.Equals(u.Country, s, StringComparison.OrdinalIgnoreCase))
                && (string.IsNullOrEmpty(status) || (status == "enabled") == u.Enabled)
                && (string.IsNullOrEmpty(country) || (country == "none" ? u.Country is null : string.Equals(u.Country, country, StringComparison.OrdinalIgnoreCase)));
            var matching = all.Where(Matches).ToList();
            var roles = UserAccount.Roles.ToDictionary(r => r, r => matching.Count(u => u.Role == r));
            var shown = string.IsNullOrEmpty(role) ? matching : matching.Where(u => u.Role == role).ToList();
            Func<UserAccount, string> key = sort switch
            {
                "id" => u => u.Id,
                "role" => u => u.Role,
                "country" => u => u.Country ?? "~",
                "status" => u => u.Enabled ? "0" : "1",
                "email" => u => u.Email ?? "~",
                _ => u => u.DisplayName,
            };
            // The id breaks ties, so the order stays the same from page to page.
            var ordered = dir == "desc" ? shown.OrderByDescending(key, StringComparer.OrdinalIgnoreCase) : shown.OrderBy(key, StringComparer.OrdinalIgnoreCase);
            var size = Math.Clamp(take, 1, 200);
            var page = ordered.ThenBy(u => u.Id, StringComparer.Ordinal).Skip(Math.Max(0, skip)).Take(size)
                .Select(u => new UserRow(u.Id, u.DisplayName, u.Role, u.Contexts, u.Enabled, u.Country, u.Email, u.LastSignIn)).ToArray();
            return new UserPage(shown.Count, Math.Max(0, skip), size, page, roles, matching.Count(u => u.Enabled), all.Count);
        }

        /// <summary>Creates or changes an account. Keeps at least one enabled administrator and never lets an administrator lock themself out.</summary>
        public async Task<UserAccount> SaveAsync(UserAccount user, string actorId, CancellationToken ct)
        {
            var allowed = _catalog.Data.A("contexts").Objects().Select(c => c.I("id")).ToHashSet();
            if (!IdPattern().IsMatch(user.Id ?? "") || string.IsNullOrWhiteSpace(user.DisplayName) || user.DisplayName.Length > 100 || !UserAccount.Roles.Contains(user.Role)
                || user.Contexts is null || user.Contexts.Length == 0 || user.Contexts.Any(x => !allowed.Contains(x)))
            {
                throw new RequestFault(400, "invalid_user", "Choose a valid ID, name, role and permitted contexts.");
            }

            if (!string.IsNullOrEmpty(user.Country) && !CountryPattern().IsMatch(user.Country))
            {
                throw new RequestFault(400, "invalid_country", "Country must be a two-letter code such as IN, or empty for UTC.");
            }

            if (!string.IsNullOrEmpty(user.Email) && (user.Email.Length > 200 || !user.Email.Contains('@')))
            {
                throw new RequestFault(400, "invalid_email", "Enter a valid email address, or leave it empty.");
            }

            if (user.Id == actorId && (!user.Enabled || user.Role != "Admin"))
            {
                throw new RequestFault(409, "self_lockout", "You cannot disable or demote your current administrator account.");
            }

            var others = (await _store.UsersAsync(ct)).Where(x => !string.Equals(x.Id, user.Id, StringComparison.OrdinalIgnoreCase));
            if (!(user.Enabled && user.Role == "Admin") && !others.Any(x => x.Enabled && x.Role == "Admin"))
            {
                throw new RequestFault(409, "admin_required", "Keep at least one active administrator.");
            }

            var existing = await _store.UserAsync(user.Id!, ct);
            return await _store.SaveUserAsync(user with
            {
                Country = string.IsNullOrEmpty(user.Country) ? null : user.Country,
                Email = string.IsNullOrWhiteSpace(user.Email) ? null : user.Email.Trim(),
                Contexts = user.Contexts.Distinct().ToArray(),
                LastSignIn = existing?.LastSignIn,
            }, ct);
        }

        [GeneratedRegex(@"^[A-Za-z0-9_.@\\-]{1,100}$")] private static partial Regex IdPattern();
        [GeneratedRegex("^[A-Z]{2}$")] private static partial Regex CountryPattern();

        public static void MapUsers(RouteGroupBuilder api)
        {
            var admin = api.MapGroup("/admin/users").RequireAuthorization("Admin").WithTags("Administration");
            admin.MapGet("/", async (IWorkspaceStore store, CancellationToken ct) => (await store.UsersAsync(ct)).OrderBy(u => u.DisplayName, StringComparer.OrdinalIgnoreCase))
                .WithSummary("Every account (for small lists; the Users page uses search).");
            admin.MapGet("/search", (UserDirectory dir, string? q, string? role, string? status, string? country, string? sort, string? order, int? skip, int? take, CancellationToken ct) =>
                dir.QueryAsync(q, role, status, country, sort, order, skip ?? 0, take ?? 25, ct))
                .WithSummary("A page of users with counts by role; filters and sorting run on the server.");
            admin.MapPut("/{id}", async (string id, UserAccount body, UserDirectory dir, HttpContext ctx, CancellationToken ct) =>
            {
                if (ctx.Request.Headers["X-Studio-Request"] != "1")
                {
                    throw new RequestFault(400, "same_origin_request_required", "A same-origin UI request is required.");
                }

                if (id != body.Id)
                {
                    throw new RequestFault(400, "user_id_mismatch", "User ID does not match the route.");
                }

                return await dir.SaveAsync(body, ActorFactory.From(ctx.User).Id, ct);
            }).Audited("user.permissions").WithSummary("Create or change an account: role, contexts, country, email, enabled.");
        }
    }
}
