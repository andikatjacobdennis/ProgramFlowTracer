using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
using Volvo.TestRequestTool.Web;

var builder = WebApplication.CreateBuilder(args);
builder.AddTestRequestPerformance(); // warm-up, compression, output cache: see StartupPerformance.cs
builder.AddTestRequestLogs(); // in-memory, redacted log capture for the Logs page: see LogEndpoints.cs
builder.AddTestRequestSecurity(); // headers, CSRF, HTTPS, limits, validation, audit: see SecurityHardening.cs
builder.Services.ConfigureHttpJsonOptions(o =>
{
    o.SerializerOptions.Converters.Add(new JsonStringEnumConverter());
    // .NET 10: refuse JSON objects that repeat a property ({"a":1,"a":2}); which value wins is ambiguous and a known way to
    // slip a second value past a check (FR-55). Nesting is bounded explicitly.
    o.SerializerOptions.AllowDuplicateProperties = false;
    o.SerializerOptions.MaxDepth = 64;
    // Source-generated serialization for the hot workflow records (TestRequestJsonContext.cs); everything else uses reflection as before.
    o.SerializerOptions.TypeInfoResolverChain.Insert(0, TestRequestJsonContext.Default);
});
builder.Services.AddProblemDetails();
builder.Services.AddExceptionHandler<FaultHandler>();
builder.Services.AddSingleton(TimeProvider.System);
builder.Services.AddSingleton<ApiMetrics>();
builder.Services.AddSingleton<TestRequestMetrics>();
builder.Services.AddServiceMonitor(); // service checks and history: see MonitorEndpoints.cs
builder.Services.AddSingleton<UsageStore>(); // the usage study: see UsageEndpoints.cs
builder.Services.AddTestRequestFeatureFlags(); // feature flags: see FeatureFlags.cs
builder.Services.AddBatches(); // batch runs: see BatchEndpoints.cs
// AI-ready interfaces with the simulated provider, behind feature flags: see AssistantEndpoints.cs
builder.Services.AddAssistant();
builder.Services.AddReviews();
builder.Services.AddCampaigns();
builder.AddStaticBundles(); // one script and one stylesheet for the app page: see StaticBundles.cs
builder.AddTestRequestData(); // the repository (C:\trt\repo), the catalog and the service layer (C:\trt\services): see DataSetup.cs
builder.Services.AddProfilePhotos(builder.Configuration); // profile photos: Microsoft Graph or the repository's user-photos folder, see ProfilePhotoEndpoints.cs
// HybridCache (.NET 9+): in-memory now, a distributed second level (for example Redis) can be added without code changes.
// Entries are limited in size, and concurrent requests for the same key compute it once (FR-41).
builder.Services.AddHybridCache(o =>
{
    o.MaximumPayloadBytes = 8 * 1024 * 1024;
    o.DefaultEntryOptions = new() { Expiration = TimeSpan.FromMinutes(5), LocalCacheExpiration = TimeSpan.FromMinutes(5) };
});
builder.Services.AddWorkflow(builder.Configuration); // jobs, proposal revisions, provenance, adapter health, audit: see WorkflowEndpoints.cs
builder.Services.AddTestRequestOpenApi(); // OpenAPI document at /openapi/v1.json and Swagger UI at /swagger: see OpenApiSetup.cs
builder.Services.AddSingleton<IRequestHandler, SoftwareHandler>();
builder.Services.AddSingleton<IRequestHandler, ConversionKitHandler>();
builder.Services.AddSingleton<IRequestHandler, SpareCabHandler>();
builder.Services.AddSingleton<IRequestHandler, AvailableUpdatesHandler>();
builder.Services.AddSingleton<IRequestHandler, ProductUpdateServiceHandler>();
builder.Services.AddSingleton<IRequestHandler, AvailableProductUpdatesHandler>();
foreach (var kind in new[] { RequestKind.ProductionBreakdown, RequestKind.DevelopmentBreakdown })
{
    builder.Services.AddSingleton<IRequestHandler>(sp => new BreakdownHandler(sp.GetRequiredService<ICatalog>(), kind));
}

builder.Services.AddSingleton<IProductValidator, CatalogValidator>();
builder.Services.AddSingleton<IProductValidator, HardwareValidator>();
builder.Services.AddSingleton<IProductValidator, DependencyValidator>();
builder.Services.AddSingleton<IProductValidator, ParameterValidator>();
builder.Services.AddSingleton<IProductValidator, VariantValidator>();
builder.Services.AddSingleton<RequestService>();
builder.Services.AddSingleton<VehicleInsights>();
// The request listener, simulated: its message types and XSDs, and one handler per simulated message type (ListenerEndpoints.cs).
builder.Services.AddSingleton<IListenerContracts, Volvo.TestRequestTool.Infrastructure.ListenerContracts>();
builder.Services.AddSingleton<IListenerHandler, PingHandler>();
builder.Services.AddSingleton<IListenerHandler, InfoHandler>();
builder.Services.AddSingleton<ListenerVehicles>();
builder.Services.AddSingleton(sp => new ListenerDispatcher(sp.GetRequiredService<IListenerContracts>(),
    sp.GetServices<IListenerHandler>().Concat(AftermarketHandlers.Create(sp.GetRequiredService<ICatalog>(), sp.GetRequiredService<IWorkspaceStore>(), sp.GetRequiredService<TimeProvider>()))));
// Development and Testing run on plain HTTP on this machine; everywhere else HTTPS is required.
var localEnvironment = builder.Environment.IsDevelopment() || builder.Environment.IsEnvironment("Testing");
var mode = builder.Configuration["Authentication:Mode"] ?? "Password";
builder.AddTestRequestTesting(localEnvironment); // load-test endpoints, health checks, security self-test: see TestingEndpoints.cs
if (mode == "Password")
{
    builder.Services.AddTestRequestSignIn(builder.Configuration); // the sign-in page with the accounts in the settings: see SignIn.cs and docs/sign-in.md
}
else if (mode == "Jwt")
{
    var authority = builder.Configuration["Authentication:Authority"];
    var audience = builder.Configuration["Authentication:Audience"];
    if (string.IsNullOrWhiteSpace(authority) || string.IsNullOrWhiteSpace(audience))
    {
        throw new InvalidOperationException("JWT authentication needs Authentication:Authority and Authentication:Audience.");
    }

    builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(o =>
    {
        o.Authority = authority;
        o.Audience = audience;
        o.RequireHttpsMetadata = true;
        o.MapInboundClaims = false;
        o.TokenValidationParameters.RoleClaimType = "role";
        o.TokenValidationParameters.ValidateLifetime = true;
        o.TokenValidationParameters.ValidateIssuer = true;
        o.TokenValidationParameters.ValidateAudience = true;
        o.TokenValidationParameters.ClockSkew = TimeSpan.FromMinutes(1);
    });
}
else
{
    throw new InvalidOperationException("Unknown authentication mode: use Password or Jwt.");
}

builder.Services.AddAuthorization(o =>
{
    o.AddPolicy("Writer", p => p.RequireAuthenticatedUser().RequireRole("Writer"));
    o.AddPolicy("Editor", p => p.RequireAuthenticatedUser().RequireAssertion(c => c.User.IsInRole("Editor") || (!c.User.HasClaim(x => x.Type == "studio_role") && c.User.IsInRole("Writer"))));
    o.AddPolicy("Operator", p => p.RequireAuthenticatedUser().RequireRole("Operator", "Writer"));
    o.AddPolicy("Admin", p => p.RequireAuthenticatedUser().RequireRole("Admin"));
});
var app = builder.Build();
app.UseExceptionHandler();
app.UseTestRequestPerformance();
app.UseTestRequestSecurity(localEnvironment);
app.UseApiMetrics();
app.UseStatusCodePages(async status =>
{
    if (status.HttpContext.Request.Path.StartsWithSegments("/api"))
    {
        await Results.Problem(statusCode: status.HttpContext.Response.StatusCode, title: "request_rejected").ExecuteAsync(status.HttpContext);
    }
    else
    {
        await ErrorPages.WriteAsync(status.HttpContext);
    }
});
// Routing must run after the default-file rewrite, otherwise "/" matches the 404 fallback before index.html is served.
// no-cache makes browsers revalidate (ETag) so an updated script or stylesheet is never served stale.
app.UseTestRequestSwaggerUI();
UiLanguages.Load(app.Environment.WebRootPath); // the installed interface language packs
app.UseDefaultFiles();
app.UseRouting();
app.UseAuthentication();
if (mode == "Password")
{
    app.UseSignInRedirect();
}

app.UseAuthorization();
app.UseStaticBundles();
app.UseRateLimitPolicyHeaders();
app.UseRateLimiter();
app.UseOutputCache();
// MapStaticAssets (.NET 9+) replaces UseStaticFiles: files are indexed at build time with strong ETags, and published builds
// serve pre-compressed Brotli and gzip copies. Unversioned URLs get "no-cache", so browsers revalidate and never run a stale script.
app.MapStaticAssets();
app.MapGet("/health", () => Results.Ok(new { status = "healthy", service = "Test Request Tool" })).WithTags("Diagnostics").WithSummary("Liveness check. No sign-in needed.");
var api = app.MapGroup("/api/v1").RequireAuthorization().AddEndpointFilter(FaultHandler.Filter);
api.MapGet("/session", (HttpContext ctx) =>
{
    var a = ActorFactory.From(ctx.User);
    return Results.Ok(new { userId = a.Id, displayName = ctx.User.Identity?.Name, role = ctx.User.FindFirst("studio_role")?.Value ?? (a.CanWrite ? "Writer" : "Reader"), canEdit = ctx.User.IsInRole("Editor") || (mode == "Jwt" && a.CanWrite), canSimulate = ctx.User.IsInRole("Operator") || a.CanWrite, isAdmin = ctx.User.IsInRole("Admin"), contexts = a.Contexts.Order().ToArray(), canWrite = a.CanWrite, authentication = mode, simulation = true, country = (ctx.User.FindFirst(System.Security.Claims.ClaimTypes.Country)?.Value ?? ctx.User.FindFirst("country")?.Value)?.ToUpperInvariant(), signOutUrl = builder.Configuration["Authentication:SignOutUrl"] });
});
api.MapGet("/capabilities", (IEnumerable<IExternalCapability> adapters) => adapters.Select(a => new { name = a.Name, configured = a.IsConfigured }));
api.MapGet("/vehicles", async (HttpContext ctx, IWorkspaceStore store, string? vin, CancellationToken ct) =>
{
    var actor = ActorFactory.From(ctx.User);
    var vehicles = await store.VehiclesAsync(ct);
    return vehicles.Where(v => actor.Contexts.Contains(new ProductDocument(v.Product).ContextId) && (vin is null || new ProductDocument(v.Product).Info.S("vin").Equals(vin, StringComparison.OrdinalIgnoreCase)));
});
api.MapGet("/vehicles/{series}/{number}", async (string series, string number, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
{
    var v = await store.VehicleAsync(VehicleIdentity.Key(series, number), ct) ?? throw new RequestFault(404, "vehicle_missing", "Vehicle was not found.");
    ActorFactory.From(ctx.User).DemandRead(new ProductDocument(v.Product).ContextId);
    ctx.Response.Headers.ETag = $"\"{v.Revision}\"";
    return Results.Ok(v);
});
api.MapGet("/catalog", (HttpContext ctx, ICatalog catalog) =>
{
    var actor = ActorFactory.From(ctx.User);
    var d = catalog.Data;
    return Results.Ok(new { contexts = d.A("contexts").Objects().Where(c => actor.Contexts.Contains(c.I("id"))), templates = d.A("templates").Objects().Where(t => t.A("contexts").Any(x => int.TryParse(x?.ToString(), out var n) && actor.Contexts.Contains(n))), baselines = d.A("baselines").Objects().Where(b => actor.Contexts.Contains(b.I("contextId"))), servicePacks = d.A("servicePacks").Objects().Where(p => actor.Contexts.Contains(p.I("contextId"))), kits = d["kits"] });
});
api.MapGet("/sources/edb/{id}", async (string id, HttpContext ctx, ExternalSources sources, CancellationToken ct) => await sources.EdbAsync(id, ActorFactory.From(ctx.User), ct));
api.MapGet("/sources/cbr/{id}", async (string id, HttpContext ctx, ExternalSources sources, CancellationToken ct) => await sources.SpareCabOrderAsync(id, ActorFactory.From(ctx.User), ct));
api.MapPost("/requests", async (RequestCommand command, HttpContext ctx, RequestService service, ProvenanceService provenance, CancellationToken ct) =>
{
    var result = await service.ExecuteAsync(ActorFactory.From(ctx.User), command, ct);
    return Results.Created($"/api/v1/requests/{result.Id}", provenance.Attach(result));
}).RequireAuthorization("Operator").RequireRateLimiting("simulation").Pausable("submissions");
api.MapPost("/requests/preview", async (RequestCommand command, HttpContext ctx, RequestService service, CancellationToken ct) => await service.PreviewAsync(ActorFactory.From(ctx.User), command, ct)).RequireAuthorization("Operator").RequireRateLimiting("simulation");
api.MapGet("/requests", async (HttpContext ctx, IWorkspaceStore store, int? skip, int? take, CancellationToken ct) => await store.HistoryAsync(ActorFactory.From(ctx.User).Id, skip ?? 0, take ?? 20, ct));
api.MapGet("/requests/{id:guid}", async (Guid id, HttpContext ctx, IWorkspaceStore store, ProvenanceService provenance, CancellationToken ct) => provenance.Attach(await store.ExecutionAsync(id, ActorFactory.From(ctx.User).Id, ct) ?? throw new RequestFault(404, "request_missing", "Request was not found.")));
api.MapGet("/drafts/{id}", async (string id, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) => await store.DraftAsync(id, ActorFactory.From(ctx.User).Id, ct) ?? throw new RequestFault(404, "draft_missing", "Draft was not found."));
api.MapPut("/drafts/{id}", async (string id, SaveDraft body, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
{
    if (body.State is null)
    {
        throw new RequestFault(400, "state_required", "A draft state is required.");
    }

    if (!System.Text.RegularExpressions.Regex.IsMatch(id, "^[A-Za-z0-9_-]{1,80}$"))
    {
        throw new RequestFault(400, "draft_id", "Draft id must contain 1–80 letters, digits, underscores or hyphens.");
    }

    return await store.SaveDraftAsync(id, ActorFactory.From(ctx.User).Id, body.State, body.ExpectedVersion, ct);
}).RequireAuthorization("Editor");
api.MapPost("/kits", async (CreateKit body, HttpContext ctx, RequestService service, CancellationToken ct) => await service.CreateKitAsync(ActorFactory.From(ctx.User), body.RequestId, body.VehicleIds, body.Name, ct)).RequireAuthorization("Writer").Audited("kit.create").Pausable("writes");
api.MapPost("/vda/commit", async (CommitVda body, HttpContext ctx, RequestService service, Microsoft.Extensions.Caching.Hybrid.HybridCache cache, CancellationToken ct) =>
{
    await RequireApprovalFilter.CheckAsync(ctx, body.RequestId); // with "require-approval" on, only through an approved review
    var committed = await service.CommitVdaAsync(ActorFactory.From(ctx.User), body.RequestId, body.VehicleId, body.ExpectedRevision, ct);
    await cache.RemoveByTagAsync(VehicleInsights.FleetTag, ct); // the vehicle changed: every fleet summary is out of date
    return committed;
}).RequireAuthorization("Writer").Audited("vda.commit").Pausable("writes");
api.MapPost("/xml/export", (JsonObject product) => Results.Text(ProductXmlCodec.Export(product), "application/xml"));
api.MapPost("/xml/import", async (HttpRequest request, CancellationToken ct) =>
{
    using var reader = new StreamReader(request.Body);
    var xml = await reader.ReadToEndAsync(ct);
    return Results.Ok(ProductXmlCodec.Import(xml));
});
api.MapPost("/integrations/{name}", async (string name, JsonObject body, IEnumerable<IExternalCapability> adapters, HttpContext ctx, CancellationToken ct) =>
{
    // Through AdapterHealth: bounded timeout, retries with jitter, circuit breaker and a per-integration concurrency limit (FR-22, FR-44).
    return await ctx.RequestServices.GetRequiredService<AdapterHealth>().InvokeAsync(WorkflowEndpoints.Adapter(adapters, name), body, ct);
}).RequireAuthorization("Writer").Pausable("integration");
if (mode == "Password")
{
    app.MapTestRequestSignIn(api, "login.html");
}

UserDirectory.MapUsers(api);
api.MapTestRequestData();
api.MapInsights(mode);
api.MapFeedback();
api.MapDiagnostics(mode);
api.MapWorkflow();
api.MapOperations();
api.MapMonitoring();
api.MapOrganisationSettings();
api.MapLogs();
api.MapTeams();
api.MapPreferences();
api.MapProfilePhoto();
api.MapUsage();
api.MapFeatureFlags();
api.MapBatches();
api.MapAssistant();
api.MapReviews();
api.MapListener();
api.MapRateLimitAdmin();
api.MapCampaigns();
app.MapTestRequestHealth();
api.MapTestRequestTesting(app, localEnvironment, mode);
api.TagByArea();
app.MapTestRequestOpenApi(localEnvironment);
app.MapFallback(async ctx =>
{
    ctx.Response.StatusCode = 404;
    if (ctx.Request.Path.StartsWithSegments("/api"))
    {
        await Results.Problem(statusCode: 404, title: "not_found").ExecuteAsync(ctx);
    }
    else
    {
        await ErrorPages.WriteAsync(ctx);
    }
});
app.Run();
public partial class Program { }
