/* Applies the application's theme before the guide paints, so it never flashes the wrong palette.
   Same rules as the app: ?theme=, then the saved choice (retired themes map to the nearest one), else Auto.
   Auto follows the operating system and resolves to Light Charcoal or Dark Charcoal. */
(function () {
  'use strict';
  var CHOICES = ['auto', 'charcoal-light', 'charcoal'];
  var RETIRED = { clay: 'charcoal-light', light: 'charcoal-light', night: 'charcoal' };
  var KEY = 'trstudio.theme';
  function systemDark() { return !!(window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches); }
  /** The stored choice: 'auto', 'charcoal-light' or 'charcoal'. */
  function pick() {
    var t = null;
    try {
      var q = new URLSearchParams(location.search).get('theme');
      if (CHOICES.indexOf(q) >= 0) return q;
      var raw = localStorage.getItem(KEY);
      t = raw ? JSON.parse(raw) : null;
    } catch (e) { t = null; }
    t = RETIRED[t] || t;
    return CHOICES.indexOf(t) >= 0 ? t : 'auto';
  }
  /** The palette actually shown for a choice. */
  function resolve(t) { return t === 'auto' ? (systemDark() ? 'charcoal' : 'charcoal-light') : t; }
  function apply(t) {
    document.documentElement.setAttribute('data-theme', resolve(t));
    document.documentElement.setAttribute('data-theme-choice', t);
  }
  apply(pick());
  // Motion off in the application's Settings also applies here.
  try {
    var motion = JSON.parse(localStorage.getItem('trstudio.motion') || '"on"');
    var osReduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    document.documentElement.setAttribute('data-motion', motion === 'off' || osReduce ? 'reduced' : 'full');
  } catch (e) { /* default motion */ }
  window.TR_GUIDE_THEME = {
    themes: [['auto', 'Auto (system)'], ['charcoal-light', 'Light Charcoal'], ['charcoal', 'Dark Charcoal']],
    key: KEY, pick: pick, apply: apply, resolve: resolve, systemDark: systemDark,
    /** The palette in use, used to choose the screenshot set. */
    current: function () { return document.documentElement.getAttribute('data-theme'); },
    choice: function () { return document.documentElement.getAttribute('data-theme-choice') || 'auto'; },
    save: function (t) { try { localStorage.setItem(KEY, JSON.stringify(t)); } catch (e) { /* storage unavailable: theme applies to this page only */ } }
  };
})();
