/* Renders the UI guide from guide-data.js: real screenshots, numbered balloons placed at the
   captured element positions, matching numbered steps and deep links back into the application. */
(function () {
  'use strict';
  const data = window.TR_GUIDE;
  const theme = window.TR_GUIDE_THEME;
  const root = document.getElementById('guide');
  const toc = document.getElementById('toc');
  if (!data) { root.textContent = 'Guide data is missing. Regenerate it with scripts/guide/Capture-Guide.ps1.'; return; }
  /** Screenshot set for the current theme; falls back to whichever set was captured. */
  const shotFor = (ch) => (ch.shots && (ch.shots[theme.current()] || ch.shots[(data.themes || [])[0]])) || ch.shot;

  const el = (tag, attrs, ...kids) => {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (v == null || v === false) continue;
      if (k === 'class') e.className = v; else if (k === 'text') e.textContent = v;
      else if (k.startsWith('on')) e.addEventListener(k.slice(2).toLowerCase(), v); else e.setAttribute(k, v === true ? '' : v);
    }
    for (const kid of kids.flat()) if (kid != null && kid !== false) e.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
    return e;
  };
  const pct = (v, total) => (100 * v / total).toFixed(3) + '%';

  /** Screenshot with highlight frames and numbered balloons; positions are percentages so it scales. */
  function figure(shot, chapterId, interactive = true) {
    const fig = el('figure', { class: 'g-figure', 'data-chapter': chapterId });
    fig.append(el('img', { src: 'img/' + shot.file, alt: shot.alt || '', width: shot.width, height: shot.height, loading: 'lazy' }));
    const placed = [];
    for (const b of shot.balloons) {
      const r = b.rect, pad = 4, R = 17;
      fig.append(el('div', { class: 'g-hl', 'data-n': b.n, style: `left:${pct(r.x - pad, shot.width)};top:${pct(r.y - pad, shot.height)};width:${pct(r.w + 2 * pad, shot.width)};height:${pct(r.h + 2 * pad, shot.height)}` }));
      // Balloon sits just outside the frame's left edge (right edge if there is no room), near its top,
      // so it never covers the control. Overlapping balloons are pushed down until they are clear.
      let bx = r.x - pad - R - 3 < R ? r.x + r.w + pad + R + 3 : r.x - pad - R - 3;
      let by = r.y + Math.min(r.h / 2, 16);
      bx = Math.min(Math.max(bx, R), shot.width - R);
      for (let i = 0; i < 12 && placed.some(([x, y]) => Math.hypot(x - bx, y - by) < 2 * R + 4); i++) by += 2 * R + 6;
      by = Math.min(Math.max(by, R), shot.height - R);
      placed.push([bx, by]);
      fig.append(el('button', { class: 'g-balloon', 'data-n': b.n, title: b.title, 'aria-label': `Step ${b.n}: ${b.title}`, style: `left:${pct(bx, shot.width)};top:${pct(by, shot.height)}`,
        onMouseenter: () => focus(chapterId, b.n), onMouseleave: () => focus(chapterId, null), onFocus: () => focus(chapterId, b.n), onBlur: () => focus(chapterId, null),
        onClick: (e) => { e.stopPropagation(); const s = document.getElementById(`${chapterId}-step-${b.n}`); s?.scrollIntoView({ block: 'nearest', behavior: document.documentElement.dataset.motion === 'reduced' ? 'auto' : 'smooth' }); } }, String(b.n)));
    }
    fig.append(el('figcaption', { text: shot.caption || '' }));
    if (interactive) fig.addEventListener('click', () => openLightbox(shot, chapterId));
    return fig;
  }

  function focus(chapterId, n) {
    document.querySelectorAll(`[data-chapter="${chapterId}"]`).forEach((fig) => {
      fig.classList.toggle('focus', n != null);
      fig.querySelectorAll('[data-n]').forEach((x) => x.classList.toggle('on', String(n) === x.dataset.n));
    });
    document.querySelectorAll(`#${chapterId} .g-step`).forEach((s) => s.classList.toggle('on', String(n) === s.dataset.n));
  }

  function openLightbox(shot, chapterId) {
    const box = document.getElementById('lightbox'), body = box.querySelector('.g-lightbox-body');
    body.replaceChildren(figure(shot, chapterId, false));
    box.hidden = false;
  }
  const lb = document.getElementById('lightbox');
  lb.addEventListener('click', (e) => { if (e.target === lb || e.target.classList.contains('g-close')) lb.hidden = true; });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') lb.hidden = true; });

  // ---------- page ----------
  let io = null;
  function render() {
  root.replaceChildren(); toc.replaceChildren(); if (io) io.disconnect();
  root.append(el('section', { class: 'g-hero' },
    el('h1', { text: data.title }),
    ...data.intro.map((p) => el('p', { text: p })),
    el('div', { class: 'g-legend' },
      el('span', null, el('b', { text: 'Numbered balloons' }), ' mark the controls described in the steps beside each screenshot.'),
      el('span', null, el('b', { text: 'Hover' }), ' a balloon or a step to highlight its partner. ', el('b', { text: 'Click' }), ' a screenshot to enlarge it.'))));

  let part = null, n = 0;
  for (const ch of data.chapters) {
    if (ch.part !== part) {
      part = ch.part;
      root.append(el('div', { class: 'g-part', 'data-part': part, text: part.toUpperCase() }));
      toc.append(el('h2', { 'data-part': part, text: part.toUpperCase() }));
    }
    n++;
    const num = String(n).padStart(2, '0');
    toc.append(el('a', { href: '#' + ch.id, 'data-target': ch.id }, el('span', { text: num }), ch.title));
    const steps = el('ol', { class: 'g-steps' }, ch.steps.map((s) => el('li', { class: 'g-step', id: `${ch.id}-step-${s.n}`, 'data-n': s.n,
      onMouseenter: () => focus(ch.id, s.n), onMouseleave: () => focus(ch.id, null) },
      el('span', { class: 'g-dot', text: s.n }), el('div', null, el('b', { class: 'g-find', text: s.title }), el('p', { class: 'g-find', text: s.text })))));
    const side = el('div', null, steps,
      ch.note ? el('div', { class: 'g-note' }, el('b', { text: 'Note. ' }), ch.note) : null,
      el('div', { class: 'g-actions' }, (ch.links || []).map((l, i) => el('a', { class: 'g-btn' + (i ? ' ghost' : ''), href: l.href, target: '_blank', rel: 'noopener' }, l.label))));
    root.append(el('section', { class: 'g-chapter', id: ch.id, 'data-part': ch.part },
      el('header', null, el('div', null, el('h2', null, el('span', { class: 'g-num', text: num }), el('span', { class: 'g-find', text: ch.title }), ch.tag ? el('span', { class: 'g-tag', text: ch.tag }) : null),
        el('p', { class: 'g-intro g-find', text: ch.intro }))),
      el('div', { class: 'g-figure-row' }, figure(shotFor(ch), ch.id), side)));
  }
  root.append(el('p', { class: 'g-empty', id: 'guide-empty', hidden: true, text: 'Nothing in the guide matches your search. Try a shorter word, for example “kit” or “validate”.' }));
  root.append(el('p', { class: 'g-intro', text: data.footer }));

  // Highlight the chapter in view.
  const links = [...toc.querySelectorAll('a')];
  io = new IntersectionObserver((entries) => {
    for (const e of entries) if (e.isIntersecting) links.forEach((a) => a.classList.toggle('active', a.dataset.target === e.target.id));
  }, { rootMargin: '-30% 0px -60% 0px' });
  document.querySelectorAll('.g-chapter').forEach((s) => io.observe(s));
  search(box.value);
  }

  // ---------- help search ----------
  // Filters chapters and steps as you type and marks every match. "/" focuses the box, Esc clears it.
  const box = document.getElementById('guide-search');
  const status = document.getElementById('guide-search-status');
  /** Replaces an element's text with the same text, every occurrence of q wrapped in <mark>. */
  function mark(node, q) {
    const text = node.dataset.text ?? (node.dataset.text = node.textContent);
    if (!q) { node.textContent = text; return false; }
    const lower = text.toLowerCase(), parts = [];
    let i = 0, hit = false;
    for (let at = lower.indexOf(q); at >= 0; at = lower.indexOf(q, i)) { hit = true; parts.push(text.slice(i, at), el('mark', null, text.slice(at, at + q.length))); i = at + q.length; }
    parts.push(text.slice(i));
    node.replaceChildren(...parts.map((x) => (typeof x === 'string' ? document.createTextNode(x) : x)));
    return hit;
  }
  function search(raw) {
    const q = (raw || '').trim().toLowerCase();
    let chapters = 0, steps = 0;
    const shownParts = new Set();
    document.querySelectorAll('.g-chapter').forEach((sec) => {
      let stepHits = 0;
      sec.querySelectorAll('.g-step').forEach((st) => {
        const hit = [...st.querySelectorAll('.g-find')].map((n) => mark(n, q)).some(Boolean);
        st.classList.toggle('g-hit', !!q && hit);
        if (hit) stepHits++;
      });
      const own = [...sec.querySelectorAll('header .g-find')].map((n) => mark(n, q)).some(Boolean)
        || (!!q && (sec.dataset.part || '').toLowerCase().includes(q));
      const show = !q || own || stepHits > 0;
      sec.hidden = !show;
      toc.querySelector(`a[data-target="${sec.id}"]`).hidden = !show;
      if (show) { chapters++; steps += stepHits; shownParts.add(sec.dataset.part); }
    });
    document.querySelectorAll('[data-part]:not(.g-chapter)').forEach((p) => { p.hidden = !shownParts.has(p.dataset.part); });
    document.querySelector('.g-hero').hidden = !!q;
    document.getElementById('guide-empty').hidden = !q || chapters > 0;
    status.textContent = !q ? '' : chapters ? `${chapters} chapter${chapters === 1 ? '' : 's'} and ${steps} step${steps === 1 ? '' : 's'} match` : 'No matches';
  }
  box.addEventListener('input', () => search(box.value));
  box.addEventListener('keydown', (e) => { if (e.key === 'Escape') { box.value = ''; search(''); } });
  document.addEventListener('keydown', (e) => {
    if (e.key === '/' && !e.ctrlKey && !e.metaKey && !/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName || '')) { e.preventDefault(); box.focus(); }
  });
  const initialQuery = new URLSearchParams(location.search).get('q');
  if (initialQuery) box.value = initialQuery;
  render();

  // Theme: the picker shares the application's saved choice, and a theme change in an open app tab is followed live.
  const picker = document.getElementById('theme');
  picker.replaceChildren(...theme.themes.map(([v, label]) => el('option', { value: v, text: label })));
  picker.value = theme.choice();
  /** t is a choice (auto, charcoal-light or charcoal); the page re-renders only when the palette changes. */
  function switchTheme(t) {
    if (!t) return;
    picker.value = t;
    if (theme.resolve(t) === theme.current()) { theme.apply(t); return; }
    const anchor = [...document.querySelectorAll('.g-chapter')].find((s) => s.getBoundingClientRect().bottom > 90);
    const offset = anchor ? anchor.getBoundingClientRect().top : 0;
    theme.apply(t); render();
    if (anchor) { const again = document.getElementById(anchor.id); window.scrollBy({ top: again.getBoundingClientRect().top - offset, behavior: 'instant' }); }
  }
  picker.addEventListener('change', () => { theme.save(picker.value); switchTheme(picker.value); });
  window.addEventListener('storage', (e) => { if (e.key === theme.key) switchTheme(theme.pick()); });
  if (window.matchMedia) {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const follow = () => { if (theme.choice() === 'auto') switchTheme('auto'); };
    mq.addEventListener ? mq.addEventListener('change', follow) : mq.addListener && mq.addListener(follow);
  }

  // Chapters are rendered by script, so jump to the requested chapter (e.g. /guide/#configure from the app) now.
  const target = location.hash && document.getElementById(decodeURIComponent(location.hash.slice(1)));
  if (target) requestAnimationFrame(() => target.scrollIntoView({ block: 'start', behavior: 'instant' }));
})();
