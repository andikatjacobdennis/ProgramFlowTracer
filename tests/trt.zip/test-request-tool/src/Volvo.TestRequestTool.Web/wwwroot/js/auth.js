/* Sign-in for the app (the sign-in page itself is login.html with js/login.js).
 *
 *  - Every API answer of 401 means there is no valid session (never signed in, signed out elsewhere, or expired): the page
 *    goes to the sign-in page, which brings the person back here afterwards. One wrapper around fetch covers every caller.
 *  - TR.auth.signOut() ends the session on the server and shows the sign-in page.
 * Credentials are never handled here: the sign-in page posts them to the server, which sets an HttpOnly session cookie. */
(function () {
  'use strict';
  const TR = (window.TR = window.TR || {});
  let leaving = false;

  /** The sign-in page, returning to `back` (a path on this site) afterwards. reason: 'expired' or 'signed-out'. */
  function toLogin(reason, back) {
    if (leaving) return;
    leaving = true;
    const here = back || location.pathname + location.search + location.hash;
    const q = new URLSearchParams();
    if (here && here !== '/' && here !== '/index.html') q.set('returnUrl', here);
    if (reason) q.set('reason', reason);
    location.assign('/login' + (q.toString() ? '?' + q : ''));
  }

  const original = window.fetch && window.fetch.bind(window);
  if (original) {
    window.fetch = async function (input, init) {
      const response = await original(input, init);
      const url = typeof input === 'string' ? input : (input && input.url) || '';
      const ours = url.startsWith('/api/') || url.startsWith(location.origin + '/api/');
      if (response.status === 401 && ours && !url.includes('/api/v1/auth/')) toLogin('expired');
      return response;
    };
  }

  async function signOut() {
    try { await original('/api/v1/auth/logout', { method: 'POST', credentials: 'same-origin', headers: { 'X-Studio-Request': '1' } }); } catch (e) { /* the sign-in page still shows */ }
    toLogin('signed-out', '/');
  }

  TR.auth = { signOut, toLogin };
})();
