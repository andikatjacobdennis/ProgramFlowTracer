/* Product domain helpers: naming, comparison, delta (AssignProduct) computation and application,
   inflate/context resolution, baseline & service pack matching, variant expressions, source filter. */
(function () {
  'use strict';
  const TR = window.TR;
  const { clone, deepEqual } = TR.util;
  const E = TR.enums;
  const db = () => TR.db;

  // ---------- naming ----------
  function derivedPosition(id) {
    if (!id) return '';
    if ([E.EA.Tea2Plus, E.EA.T3].includes(id.electricalArchitecture)) return [id.family, id.type, id.position].filter((x) => x !== null && x !== undefined).join('.');
    return id.mid !== null && id.mid !== undefined ? String(id.mid) : '';
  }
  function derivedName(id) { if (!id) return ''; return [derivedPosition(id), id.name].filter(Boolean).join(' '); }
  function idKey(id) {
    if (!id) return '';
    const v = (x) => (x === null || x === undefined ? '' : x);
    return [v(id.electricalArchitecture), v(id.family), v(id.type), v(id.position), v(id.mid)].join('|');
  }
  const nodeKey = (n) => idKey(n && n.nodeIdentifier);
  const idMatch = (a, b) => idKey(a) === idKey(b);

  function chassisOf(p) {
    const i = p && p.productSpecification && p.productSpecification.productInformation;
    return i ? { chassisSeries: i.chassisSeries || '', chassisNumber: i.chassisNumber || '' } : { chassisSeries: '', chassisNumber: '' };
  }
  function chassisText(p) {
    const c = chassisOf(p);
    return c.chassisSeries || c.chassisNumber ? `${c.chassisSeries} ${c.chassisNumber}`.trim() : '(Chassis number unknown)';
  }

  // ---------- node structure ----------
  const NODE_SPEC = {
    0: {
      single: [['mainSoftware', 'Part', 'Main Software', 'MSW'], ['downloader', 'Part', 'Downloader', 'DL'], ['dataSet1', 'Part', 'Data Set 1', 'DST1'], ['dataSet2', 'Part', 'Data Set 2', 'DST2']],
      lists: [['complementarySoftwares', 'Part', 'Complementary Software', 'CSW'], ['subSoftwares', 'Part', 'Sub Software', 'SSW'], ['subDataSets', 'Part', 'Sub Data Sets', 'SDST'], ['subComplementarySoftwares', 'Part', 'Sub Complementary Software', 'SCSW']],
    },
    1: {
      single: [['mainSoftware', 'DownloadablePart', 'Main Software', 'MSW'], ['primaryBootloader', 'DownloadablePart', 'Primary Bootloader', 'PBL'], ['secondaryBootloader', 'DownloadablePart', 'Secondary Bootloader', 'SBL']],
      lists: [['datas', 'Data', 'Data', 'DATA'], ['complementarySoftwares', 'DownloadablePart', 'Complementary Software', 'CSW'], ['subHardwares', 'Hardware', 'Sub Hardware', 'SHW']],
    },
    3: {
      single: [],
      lists: [['softwareProducts', 'DownloadablePart', 'SW Products / Packages', 'SWPKG']],
    },
    2: {
      single: [['mainSoftware', 'Part', 'Main Software', 'MSW']],
      lists: [['subSoftwares', 'Part', 'Sub Software', 'SSW'], ['softwareFunctions', 'Part', 'Software Function', 'SWF']],
    },
  };
  const COMMON_SINGLE = [['ecuHardware', 'Hardware', 'ECU Hardware', 'HW'], ['nodeTemplateDocument', 'Part', 'NTP Document', 'NTP']];
  const NODE_STRINGS = ['versionName', 'replacementChainName', 'nodeTemplateStatus'];
  const singles = (ea) => COMMON_SINGLE.concat(NODE_SPEC[ea] ? NODE_SPEC[ea].single : []);
  const lists = (ea) => (NODE_SPEC[ea] ? NODE_SPEC[ea].lists : []);

  function skeletonNode(identifier, ea) {
    const n = { electricalArchitecture: ea, nodeIdentifier: clone(identifier), name: derivedName(identifier), notifications: [], ecuHardware: null, nodeTemplateDocument: null, versionName: '', replacementChainName: '', nodeTemplateStatus: '' };
    singles(ea).forEach(([k]) => { if (!(k in n)) n[k] = null; });
    lists(ea).forEach(([k]) => { n[k] = []; });
    if (ea === E.EA.Tea2Plus) { n.nodeState = 0; n.nodePath = ''; }
    return n;
  }

  // ---------- comparison ----------
  function partSig(p, type) {
    if (!p) return null;
    const s = { n: Number(p.number) || 0, f: p.fieldNumber ? String(p.fieldNumber) : '' };
    if (type === 'Hardware') s.s = p.serialNumber || '';
    if (type === 'DownloadablePart' || type === 'Data' || type === 'DataPatch') s.d = p.nodeTemplateDocumentNumber || '';
    if (type === 'Data') s.pt = (p.patches || []).map((x) => partSig(x, 'DataPatch')).sort((a, b) => a.n - b.n);
    if (type === 'DownloadablePart') {
      for (const k of ['artifactSHA', 'softwareProduct', 'packageVersion', 'executionEnvironment', 'logicalEcu', 'parameterTemplate']) s[k] = p[k] || '';
    }
    if (p.forceDirty) s.fd = true;
    return s;
  }
  const partsEqual = (a, b, type) => deepEqual(partSig(a, type), partSig(b, type));

  function listMode(a, b) {
    const all = (a || []).concat(b || []);
    if (all.every((x) => x.index !== null && x.index !== undefined)) return 'index';
    if (all.every((x) => x.fieldNumber)) return 'fieldNumber';
    return 'number';
  }

  function listDelta(src, tgt, type) {
    src = src || []; tgt = tgt || [];
    const P = E.PartOps[type];
    const mode = listMode(src, tgt);
    const ops = [];
    const used = new Set();
    for (const s of src) {
      const ti = tgt.findIndex((t, i) => !used.has(i) && String(t[mode]) === String(s[mode]));
      if (ti < 0) { ops.push({ type: P.replace, value: clone(s) }); continue; }
      used.add(ti);
      const t = tgt[ti];
      if (partsEqual(s, t, type)) continue;
      if (type === 'Data' && Number(s.number) === Number(t.number) && (s.nodeTemplateDocumentNumber || '') === (t.nodeTemplateDocumentNumber || '')) {
        ops.push({ type: E.Op.AssignData, identifier: { [mode]: t[mode] }, number: s.number, patches: listDelta(s.patches, t.patches, 'DataPatch') });
      } else {
        ops.push({ type: P.replace, identifier: { [mode]: t[mode] }, value: clone(s) });
      }
    }
    tgt.forEach((t, i) => { if (!used.has(i)) ops.push({ type: P.remove, identifier: { [mode]: t[mode] } }); });
    return ops;
  }

  /** Assign*Node operation turning tgt into src, or null when equal. */
  function nodeAssignOp(src, tgt) {
    const ea = src.electricalArchitecture;
    const op = { type: E.NodeOps.assign[ea], nodeIdentifier: clone(src.nodeIdentifier), documentNumber: (src.nodeTemplateDocument && src.nodeTemplateDocument.number) || 0 };
    let changed = false;
    for (const k of NODE_STRINGS) {
      if ((src[k] || '') !== (tgt[k] || '')) { op[k] = { type: E.Op.AssignString, value: src[k] || '' }; changed = true; }
    }
    for (const [k, T] of singles(ea)) {
      if (!partsEqual(src[k], tgt[k], T)) {
        op[k] = src[k] ? { type: E.PartOps[T].replace, value: clone(src[k]) } : { type: E.PartOps[T].remove };
        changed = true;
      }
    }
    for (const [k, T] of lists(ea)) {
      const ops = listDelta(src[k], tgt[k], T);
      if (ops.length) { op[k] = ops; changed = true; }
    }
    return changed ? op : null;
  }

  const paramKey = (p) => `${p.electricalArchitecture === undefined || p.electricalArchitecture === null ? 1 : p.electricalArchitecture}:${p.code}`;
  function refsSig(p) { return (p.references || []).map((r) => [r.code || '', r.value === undefined ? null : r.value]).sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0)); }
  const paramEqual = (a, b) => a.code === b.code && (a.electricalArchitecture || 0) === (b.electricalArchitecture || 0) && deepEqual(refsSig(a), refsSig(b));

  const variantKey = (v) => v.idVar6 || `${v.familyId || ''}${v.variantId || ''}` || v.symbol;

  function emptyDelta() { return { nodes: [], parameters: [], productSpecification: { variants: [], sNotes: [] } }; }

  /** Operations that turn `target` into `source` (same semantics as AssignProduct.FromDiff). */
  function computeDelta(source, target) {
    const d = emptyDelta();
    if (!source) return d;
    target = target || { nodes: [], parameters: [], productSpecification: { variants: [], sNotes: [] } };
    const tN = new Map((target.nodes || []).map((n) => [nodeKey(n), n]));
    const sKeys = new Set();
    for (const s of source.nodes || []) {
      const k = nodeKey(s);
      sKeys.add(k);
      const t = tN.get(k);
      if (!t || t.electricalArchitecture !== s.electricalArchitecture) d.nodes.push({ type: E.NodeOps.replace[s.electricalArchitecture], value: clone(s) });
      else { const op = nodeAssignOp(s, t); if (op) d.nodes.push(op); }
    }
    for (const t of target.nodes || []) if (!sKeys.has(nodeKey(t))) d.nodes.push({ type: E.Op.RemoveNode, identifier: clone(t.nodeIdentifier) });

    const tP = new Map((target.parameters || []).map((p) => [paramKey(p), p]));
    const sP = new Set();
    for (const s of source.parameters || []) {
      sP.add(paramKey(s));
      const t = tP.get(paramKey(s));
      if (!t || !paramEqual(s, t)) d.parameters.push({ type: E.Op.AssignParameter, value: clone(s) });
    }
    for (const t of target.parameters || []) if (!sP.has(paramKey(t))) d.parameters.push({ type: E.Op.RemoveParameter, value: clone(t) });

    const ss = source.productSpecification || {}, ts = target.productSpecification || {};
    const tV = new Set((ts.variants || []).map(variantKey)), sV = new Set((ss.variants || []).map(variantKey));
    (ss.variants || []).forEach((v) => { if (!tV.has(variantKey(v))) d.productSpecification.variants.push({ type: E.Op.AssignVariant, value: clone(v) }); });
    (ts.variants || []).forEach((v) => { if (!sV.has(variantKey(v))) d.productSpecification.variants.push({ type: E.Op.RemoveVariant, value: clone(v) }); });
    const tS = new Set((ts.sNotes || []).map((s) => s.value)), sS = new Set((ss.sNotes || []).map((s) => s.value));
    (ss.sNotes || []).forEach((s) => { if (!tS.has(s.value)) d.productSpecification.sNotes.push({ type: E.Op.AssignSNote, value: clone(s) }); });
    (ts.sNotes || []).forEach((s) => { if (!sS.has(s.value)) d.productSpecification.sNotes.push({ type: E.Op.RemoveSNote, value: clone(s) }); });
    return d;
  }

  const hasDelta = (d) => !!d && ((d.nodes || []).length + (d.parameters || []).length +
    ((d.productSpecification && d.productSpecification.variants) || []).length + ((d.productSpecification && d.productSpecification.sNotes) || []).length) > 0;

  function partMatch(p, id) {
    if (!p || !id) return false;
    const keys = Object.keys(id).filter((k) => id[k] !== null && id[k] !== undefined);
    if (!keys.length) return false;
    return keys.every((k) => String(p[k]) === String(id[k]));
  }
  const nextIndex = (list) => list.reduce((m, x) => Math.max(m, x.index === undefined || x.index === null ? -1 : x.index), -1) + 1;

  function applyListOps(list, ops, type) {
    const P = E.PartOps[type];
    list = (list || []).slice();
    for (const o of ops.filter((x) => x.type === P.replace)) {
      const v = clone(o.value);
      if (o.identifier) {
        const i = list.findIndex((x) => partMatch(x, o.identifier));
        if (i >= 0) { if (v.index === undefined || v.index === null) v.index = list[i].index; list[i] = v; continue; }
      }
      if (v.index === undefined || v.index === null || list.some((x) => x.index === v.index)) v.index = nextIndex(list);
      list.push(v);
    }
    for (const o of ops.filter((x) => x.type === P.remove)) {
      const i = list.findIndex((x) => partMatch(x, o.identifier));
      if (i >= 0) list.splice(i, 1);
    }
    for (const o of ops.filter((x) => x.type === E.Op.AssignData && type === 'Data')) {
      const item = list.find((x) => partMatch(x, o.identifier));
      if (!item) continue;
      if (o.number !== undefined) item.number = o.number;
      if (o.patches) item.patches = applyListOps(item.patches || [], o.patches, 'DataPatch');
    }
    return list;
  }

  function applyNodeAssign(n, op) {
    const ea = n.electricalArchitecture;
    for (const k of NODE_STRINGS) if (op[k]) n[k] = op[k].value;
    for (const [k, T] of singles(ea)) {
      const o = op[k];
      if (!o) continue;
      if (o.type === E.PartOps[T].remove) n[k] = null;
      else n[k] = clone(o.value);
    }
    for (const [k, T] of lists(ea)) if (op[k]) n[k] = applyListOps(n[k], op[k], T);
    n.name = derivedName(n.nodeIdentifier);
  }

  function compareNodes(a, b) {
    const ia = a.nodeIdentifier || {}, ib = b.nodeIdentifier || {};
    const n = (x) => Number(x) || 0;
    if (ia.mid && ib.mid && ia.mid !== ib.mid) return n(ia.mid) - n(ib.mid);
    return n(ia.family) - n(ib.family) || n(ia.type) - n(ib.type) || n(ia.position) - n(ib.position) || (a.electricalArchitecture || 0) - (b.electricalArchitecture || 0);
  }
  function compareParameters(a, b) {
    return (a.electricalArchitecture || 0) - (b.electricalArchitecture || 0) || (a.code < b.code ? -1 : a.code > b.code ? 1 : 0);
  }
  const variantSortKey = (v) => (v.symbol || v.idVar6 || '').toUpperCase();

  /** Mutates and returns product. */
  function applyDelta(p, delta) {
    if (!delta) return p;
    p.nodes = p.nodes || [];
    p.parameters = p.parameters || [];
    p.productSpecification = p.productSpecification || { productInformation: {}, variants: [], sNotes: [] };
    const spec = p.productSpecification;
    spec.variants = spec.variants || [];
    spec.sNotes = spec.sNotes || [];
    for (const op of delta.nodes || []) {
      if (op.type === E.Op.RemoveNode) p.nodes = p.nodes.filter((n) => !idMatch(n.nodeIdentifier, op.identifier));
      else if ([30, 31, 32, 42].includes(op.type)) {
        p.nodes = p.nodes.filter((n) => !idMatch(n.nodeIdentifier, op.value.nodeIdentifier));
        p.nodes.push(clone(op.value));
      } else if ([21, 22, 23, 41, 38].includes(op.type)) {
        let n = p.nodes.find((x) => idMatch(x.nodeIdentifier, op.nodeIdentifier));
        if (!n) {
          if (op.type === 38) continue;
          n = skeletonNode(op.nodeIdentifier, { 21: 2, 22: 0, 23: 1, 41: 3 }[op.type]);
          p.nodes.push(n);
        }
        applyNodeAssign(n, op);
      }
    }
    p.nodes.sort(compareNodes);
    for (const op of delta.parameters || []) {
      if (op.type === E.Op.AssignParameter) {
        const i = p.parameters.findIndex((x) => paramKey(x) === paramKey(op.value));
        if (i >= 0) p.parameters[i] = clone(op.value); else p.parameters.push(clone(op.value));
      } else if (op.type === E.Op.RemoveParameter) {
        p.parameters = p.parameters.filter((x) => !(x.code === op.value.code && (op.value.electricalArchitecture === undefined || op.value.electricalArchitecture === null || x.electricalArchitecture === op.value.electricalArchitecture)));
      }
    }
    p.parameters.sort(compareParameters);
    const ds = delta.productSpecification || {};
    for (const op of ds.variants || []) {
      if (op.type === E.Op.RemoveVariant) spec.variants = spec.variants.filter((v) => variantKey(v) !== variantKey(op.value));
      else if (!spec.variants.some((v) => variantKey(v) === variantKey(op.value))) spec.variants.push(clone(op.value));
    }
    spec.variants.sort((a, b) => (variantSortKey(a) < variantSortKey(b) ? -1 : 1));
    for (const op of ds.sNotes || []) {
      if (op.type === E.Op.RemoveSNote) spec.sNotes = spec.sNotes.filter((s) => s.value !== op.value.value);
      else if (!spec.sNotes.some((s) => s.value === op.value.value)) spec.sNotes.push(clone(op.value));
    }
    spec.sNotes.sort((a, b) => (a.value < b.value ? -1 : 1));
    const info = spec.productInformation || (spec.productInformation = {});
    ['baselineName', 'baselineGuid', 'servicePackName', 'servicePackGuid'].forEach((k) => { if (ds[k] !== undefined && ds[k] !== null) info[k] = ds[k]; });
    return p;
  }

  /** Replace Assign*Node operations with Replace*Node holding the full applied node (ConvertAssignNodeToReplaceNode). */
  function convertAssignToReplace(delta, reference) {
    const d = clone(delta);
    d.nodes = d.nodes.map((op) => {
      if (![21, 22, 23, 41].includes(op.type)) return op;
      const ref = (reference.nodes || []).find((n) => idMatch(n.nodeIdentifier, op.nodeIdentifier));
      const n = ref ? clone(ref) : skeletonNode(op.nodeIdentifier, { 21: 2, 22: 0, 23: 1, 41: 3 }[op.type]);
      applyNodeAssign(n, op);
      return { type: E.NodeOps.replace[n.electricalArchitecture], value: n };
    });
    return d;
  }

  function deltaCounts(delta) {
    const c = { nodes: 0, parameters: 0, variants: 0, sNotes: 0 };
    if (!delta) return c;
    c.nodes = (delta.nodes || []).length;
    c.parameters = (delta.parameters || []).length;
    c.variants = ((delta.productSpecification || {}).variants || []).length;
    c.sNotes = ((delta.productSpecification || {}).sNotes || []).length;
    return c;
  }

  // ---------- server-side enrichment ----------
  function ensureShape(p) {
    p.productSpecification = p.productSpecification || {};
    const s = p.productSpecification;
    s.productInformation = s.productInformation || {};
    s.variants = s.variants || [];
    s.sNotes = s.sNotes || [];
    s.productInformation.notifications = s.productInformation.notifications || [];
    p.nodes = p.nodes || [];
    p.parameters = p.parameters || [];
    p.softwareRelatedHardwares = p.softwareRelatedHardwares || [];
    p.breakdownInformation = p.breakdownInformation || { notifications: [] };
    p.breakdownInformation.notifications = p.breakdownInformation.notifications || [];
    return p;
  }

  function addNote(list, text, severity, reason) {
    if (!list.some((n) => n.text === text)) list.push({ text, reason: reason || '', action: '', severity, linkLookup: {} });
  }

  function softwareNumbers(n) {
    const out = [];
    singles(n.electricalArchitecture).forEach(([k]) => { if (k !== 'ecuHardware' && k !== 'nodeTemplateDocument' && n[k]) out.push(k + ':' + n[k].number); });
    lists(n.electricalArchitecture).forEach(([k, T]) => { if (T !== 'Hardware') (n[k] || []).forEach((x) => out.push(k + ':' + x.number)); });
    return out.sort().join(',');
  }

  function normalizeAndIndex(n) {
    for (const [k] of lists(n.electricalArchitecture)) {
      let arr = [];
      for (const part of n[k] || []) {
        const q = part.quantity === undefined || part.quantity === null ? 1 : part.quantity;
        if (q === 0) { (part.notifications || []).forEach((x) => n.notifications.push(x)); continue; }
        for (let i = 0; i < q; i++) arr.push(Object.assign(clone(part), { quantity: 1 }));
      }
      if (arr.some((x) => x.index === undefined || x.index === null)) {
        arr.sort((a, b) => (Number(a.number) || 0) - (Number(b.number) || 0));
        arr.forEach((x, i) => { x.index = i; });
      }
      if (k === 'datas') arr.forEach((d) => {
        d.patches = d.patches || [];
        if (d.patches.some((x) => x.index === undefined || x.index === null)) d.patches.forEach((x, i) => { x.index = i; });
      });
      n[k] = arr;
    }
  }

  function inflate(p) {
    ensureShape(p);
    const D = db();
    const spec = p.productSpecification;
    const info = spec.productInformation;
    const seen = new Set();
    spec.variants = spec.variants.map((v) => {
      const known = D.variantByIdVar6(v.idVar6 || `${v.familyId || ''}${v.variantId || ''}`) || D.variantBySymbol(v.symbol);
      return known ? Object.assign({}, known, { source: v.source || null }) : v;
    }).filter((v) => { const k = variantKey(v); if (seen.has(k)) return false; seen.add(k); return true; })
      .sort((a, b) => (variantSortKey(a) < variantSortKey(b) ? -1 : 1));
    spec.sNotes = spec.sNotes.map((s) => Object.assign({}, s, { name: s.name || D.sNoteName(s.value) || '' }));

    for (const n of p.nodes) {
      n.notifications = n.notifications || [];
      const def = D.findDef(n.nodeIdentifier);
      if (def) {
        n.nodeIdentifier.name = n.nodeIdentifier.name || def.name;
        n.isCabNode = !!def.cab;
      }
      n.name = derivedName(n.nodeIdentifier);
      normalizeAndIndex(n);
      const doc = n.nodeTemplateDocument && n.nodeTemplateDocument.number;
      const vi = doc ? D.versionByDoc(doc) : null;
      if (vi) {
        n.versionName = vi.v.versionName;
        n.replacementChainName = vi.v.chain;
        n.nodeTemplateStatus = vi.v.status;
        const expected = D.buildNode(vi.def, vi.idx, {});
        n.isSoftwareSame = softwareNumbers(expected) === softwareNumbers(n);
        if (!n.isSoftwareSame) addNote(n.notifications, `Software in ${n.name} does not match node template document ${doc}`, E.Severity.Warning, 'The software parts differ from the parts specified by the node template version ' + vi.v.versionName + '.');
        const hw = n.ecuHardware && n.ecuHardware.number;
        if (hw && vi.v.hardware.indexOf(Number(hw)) < 0) addNote(n.notifications, `ECU hardware ${hw} is not supported by ${vi.v.versionName}`, E.Severity.Error, 'Hardware replacement is required.');
      } else if (doc) {
        n.isSoftwareSame = false;
        addNote(n.notifications, `Unknown node template document ${doc}`, E.Severity.Warning);
      } else {
        n.isSoftwareSame = false;
        addNote(n.notifications, `${n.name} has no node template document`, E.Severity.Warning, 'Run a Software Resolve request to resolve the node template document.');
      }
    }
    p.nodes.sort(compareNodes);
    p.parameters.forEach((x) => {
      const pd = D.paramDef(x.electricalArchitecture, x.code);
      if (pd) {
        x.packaged = !!pd.packaged;
        x.isGroupAdministrative = !!pd.admin;
        x.isFunction = !!pd.isFunction;
      }
      x.notifications = x.notifications || [];
      x.references = x.references || [];
    });
    p.parameters.sort(compareParameters);
    if (!info.context) {
      const r = findContext(p);
      info.context = r.context;
      r.notes.forEach((n) => addNote(info.notifications, n.text, n.severity));
    }
    return p;
  }

  function findContext(p) {
    const D = db();
    const info = p.productSpecification.productInformation;
    const notes = [];
    const pc = D.productClasses.find((x) => x.id === info.productClassId);
    if (!pc) { notes.push({ text: 'Product class does not exist', severity: E.Severity.Error }); return { context: null, notes }; }
    let ctxs = D.contexts.filter((c) => c.productClassIds.includes(pc.id));
    if (!ctxs.length) { notes.push({ text: 'There are no Contexts for this product class', severity: E.Severity.Error }); return { context: null, notes }; }
    const syms = new Set((p.productSpecification.variants || []).map((v) => v.symbol));
    ctxs = ctxs.filter((c) => !(c.requiredVariants || []).length || c.requiredVariants.every((s) => syms.has(s)));
    if (!ctxs.length) { notes.push({ text: 'No Context was found matching the products variant specification', severity: E.Severity.Error }); return { context: null, notes }; }
    if (info.electricalArchitecture === E.EA.T3 || (p.nodes || []).some((n) => n.electricalArchitecture === E.EA.T3)) ctxs = ctxs.filter((c) => c.id === 104);
    else ctxs = ctxs.filter((c) => c.id !== 104);
    const ntpCtx = [];
    (p.nodes || []).forEach((n) => {
      const vi = n.nodeTemplateDocument ? D.versionByDoc(n.nodeTemplateDocument.number) : null;
      if (vi) ntpCtx.push(ctxs.find((c) => vi.def.contexts.includes(c.id)));
    });
    let ctx = null;
    if (ntpCtx.filter(Boolean).length) {
      ctx = ntpCtx.filter(Boolean)[0];
      if (new Set(ntpCtx.map((c) => c && c.id)).size > 1) notes.push({ text: 'All Node Templates do not belong to the same context.', severity: E.Severity.Warning });
    } else if (!(p.nodes || []).length) ctx = ctxs.find((c) => c.nonVolvoGroup) || ctxs[0];
    else ctx = ctxs.find((c) => c.isOnlyTea2 && p.nodes.every((n) => n.electricalArchitecture === 0)) || ctxs[0];
    return { context: ctx ? { id: ctx.id, name: ctx.name, isOnlyTea2: !!ctx.isOnlyTea2 } : null, notes };
  }

  function ntpDocNumbers(p) {
    return (p.nodes || []).map((n) => n.nodeTemplateDocument && Number(n.nodeTemplateDocument.number)).filter(Boolean);
  }

  function matchBaseline(docs) {
    if (!docs || !docs.length) return null;
    const cands = db().baselines.filter((b) => b.typeCode === 3 && ![6, 7, 8].includes(b.state) && docs.every((d) => b.docs.includes(Number(d))));
    cands.sort((a, b) => b.state * Date.parse(b.introductionDate) - a.state * Date.parse(a.introductionDate));
    return cands[0] || null;
  }

  function matchServicePacks(docs, contextId) {
    if (!docs || !docs.length) throw new Error('Value cannot be null. Parameter name: values');
    let sps = db().servicePacks.filter((s) => (!contextId || s.contextId === contextId) && docs.every((d) => s.docs.includes(Number(d))));
    if (sps.length > 1 && new Set(sps.map((s) => s.branch)).size === 1) sps = [sps.reduce((m, s) => (s.sortOrder > m.sortOrder ? s : m))];
    return sps;
  }

  // ---------- variant expression ----------
  function tokenize(expr) {
    const re = /\s*(\(|\)|&&|\|\||&|\||!|,|[A-Za-z0-9][A-Za-z0-9\-_.+]*)\s*/g;
    const out = [];
    let m, pos = 0;
    const s = String(expr || '');
    while (pos < s.length) {
      re.lastIndex = pos;
      m = re.exec(s);
      if (!m || m.index !== pos) throw new Error(`Unexpected character '${s[pos]}' at position ${pos + 1}`);
      if (m[1]) out.push(m[1]);
      pos = re.lastIndex;
      if (!m[0].length) break;
    }
    return out;
  }

  function evalExpression(expr, present, isKnown) {
    const toks = tokenize(expr);
    const symbols = [];
    let i = 0;
    const peek = () => toks[i];
    const up = (t) => (t || '').toUpperCase();
    function parseOr() {
      let v = parseAnd();
      while (['|', '||', ',', 'OR'].includes(up(peek()))) { i++; const r = parseAnd(); v = v || r; }
      return v;
    }
    function parseAnd() {
      let v = parseUnary();
      while (['&', '&&', 'AND'].includes(up(peek()))) { i++; const r = parseUnary(); v = v && r; }
      return v;
    }
    function parseUnary() {
      const t = peek();
      if (t === undefined) throw new Error('Unexpected end of expression');
      if (t === '!' || up(t) === 'NOT') { i++; return !parseUnary(); }
      if (t === '(') { i++; const v = parseOr(); if (peek() !== ')') throw new Error("Missing ')'"); i++; return v; }
      if (/^[A-Za-z0-9]/.test(t)) { i++; const s = up(t); symbols.push(s); return present.has(s); }
      throw new Error(`Unexpected token '${t}'`);
    }
    const value = parseOr();
    if (i < toks.length) throw new Error(`Unexpected token '${toks[i]}'`);
    const known = symbols.filter((s) => isKnown(s));
    if (!known.length) throw new Error('No known variant found in expression');
    const notInProduct = TR.util.uniq(known.filter((s) => !present.has(s)));
    return { value, symbols: TR.util.uniq(symbols), notInProduct };
  }

  // ---------- source filter ----------
  function makeSourceFilter(variantsText, itemsText) {
    const variants = TR.util.splitList(variantsText).map((x) => x.toUpperCase());
    const items = TR.util.splitList(itemsText);
    if (!variants.length && !items.length) return null;
    return { variants, items, variantsText: variantsText || '', itemsText: itemsText || '' };
  }
  function sourcePasses(filter, source, partNumber) {
    if (!filter) return true;
    let okVar = true, okItem = true;
    if (filter.variants.length) {
      const c = source && source.condition;
      if (!c) okVar = false;
      else if (c.type === E.ConditionType.AlwaysMatch) okVar = true;
      else if (c.type === E.ConditionType.Variant) okVar = (c.variants || []).some((v) => filter.variants.includes(String(v).toUpperCase()));
      else okVar = filter.variants.includes(String(c.sNote || '').toUpperCase());
    }
    if (filter.items.length) {
      okItem = (partNumber !== undefined && filter.items.includes(String(partNumber))) || (!!source && filter.items.includes(String(source.itemNumber)));
    }
    return okVar && okItem;
  }
  function nodePassesFilter(filter, n) {
    if (!filter) return true;
    const parts = [];
    singles(n.electricalArchitecture).forEach(([k]) => { if (n[k]) parts.push(n[k]); });
    lists(n.electricalArchitecture).forEach(([k]) => (n[k] || []).forEach((x) => parts.push(x)));
    return parts.some((x) => sourcePasses(filter, x.source, x.number));
  }
  function conditionText(source) {
    const c = source && source.condition;
    if (!c) return '';
    if (c.type === E.ConditionType.Variant) return (c.variants || []).join(',');
    if (c.type === E.ConditionType.SNote) return c.sNote || '';
    return 'Always match';
  }

  // ---------- request file name (RequestModel.ToFileName + GetRequestFileName) ----------
  function requestFileName(req, chassis) {
    let s = '';
    if (req) {
      s = E.RequestTypeKeys[req.selectedRequestType] || '';
      if (req.selectedRequestType === E.RequestType.Software) {
        if (req.selectedSoftwareRequestOperation) s += E.SoftwareRequestOperationKeys[req.selectedSoftwareRequestOperation] || '';
        if (req.selectedScenario) s += E.ScenarioNames[req.selectedScenario] || '';
      }
      if (req.selectedRequestType === E.RequestType.ConversionKit) {
        if (req.selectedKitScenario) s += E.KitScenarioKeys[req.selectedKitScenario] || '';
        const nums = (req.conversionKitNumbers || []).map((k) => k.conversionKitNumber).filter(Boolean);
        if (nums.length) s += nums.join('-');
        if (req.selectedBaseline) s += req.selectedBaseline;
      }
    }
    if (chassis && chassis.chassisSeries) {
      if (s) s += 'With';
      s += String(chassis.chassisSeries).toUpperCase().trim() + String(chassis.chassisNumber || '').trim().replace(/^0+/, '');
    }
    return (s || 'request') + '.xml';
  }

  function paramDisplay(p) {
    if (p.valueNotVisibleToUser) return `${p.code} = N/A`;
    const refs = p.references || [];
    if (!p.isFunction && refs.length === 1 && refs[0].value !== null && refs[0].value !== undefined) return `${p.code} = ${refs[0].value}`;
    return p.code;
  }
  function paramValue(p) {
    if (p.valueNotVisibleToUser) return 'N/A';
    const refs = p.references || [];
    if (refs.length === 1) { const v = String(refs[0].value === null || refs[0].value === undefined ? '' : refs[0].value); return v.length < 100 ? v : '...'; }
    return refs.map((r) => `${r.code}=${r.value}`).join(', ');
  }

  function nodeSummary(n) {
    const name = n.name || derivedName(n.nodeIdentifier) || (n.nodeIdentifier && n.nodeIdentifier.mid) || '';
    const ntp = n.nodeTemplateDocument ? n.nodeTemplateDocument.number : '';
    return ntp ? `${name}, ${ntp} - ${n.versionName || ''}` : name;
  }

  TR.model = {
    derivedPosition, derivedName, idKey, nodeKey, idMatch, chassisOf, chassisText, NODE_SPEC, COMMON_SINGLE, NODE_STRINGS, singles, lists,
    skeletonNode, partSig, partsEqual, listDelta, nodeAssignOp, paramKey, paramEqual, variantKey, emptyDelta, computeDelta, hasDelta,
    partMatch, applyListOps, applyNodeAssign, applyDelta, convertAssignToReplace, compareNodes, compareParameters, deltaCounts, ensureShape,
    addNote, softwareNumbers, inflate, findContext, ntpDocNumbers, matchBaseline, matchServicePacks, evalExpression, makeSourceFilter,
    sourcePasses, nodePassesFilter, conditionText, requestFileName, paramDisplay, paramValue, nodeSummary,
  };
})();
