/* VCADS request (Views\TestRequest\VCADS.cshtml + Scripts\Pages\TestRequest\VCADS.ts), in the journey design:
 * 1. Request type (software, hardware or conversion kit) with Simulate NAMS, 2. Vehicle (chassis series and number),
 * 3. Computers (all ECUs, or one computer by its MID) or the conversion kit; a Request summary beside it with Run request
 * and Reset form; the Result below with Response, Vehicle and Raw tabs. The simulated VCADS service answers (engine.js):
 * nothing is installed on a vehicle. The last five runs of this session stay listed so they can be compared. */
(function () {
  'use strict';
  const TR = window.TR;
  const { h } = TR.util;
  const ui = TR.ui;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));
  const TYPES = [[1, 'Software Request', 'Request software operations.', 'settings'], [2, 'Hardware Request', 'Request hardware information.', 'chip'], [3, 'Conversion Kit Request', 'Request a conversion kit.', 'wrench']];
  const MIDS = [[128, 'EMS'], [130, 'TECU'], [136, 'EBS'], [144, 'VMCU'], [234, 'IC'], [252, 'TGW'], [249, 'BBM']];
  const fresh = () => ({ type: 1, nams: true, series: 'FH', number: '123456', scope: 'all', mid: '', ck: '', loading: false, errors: [], result: null, tab: 'response', ms: null, runs: [], raw: false, series_: null });
  const st = fresh();

  async function seriesList() {
    if (st.series_) return;
    st.series_ = [];
    try { const r = await (await fetch('/api/v1/vehicles/search?take=500')).json(); st.series_ = [...new Set(r.items.map((v) => v.series))].sort(); TR.app.refresh(); } catch (e) { st.series_ = ['FH', 'FM', 'VNL', 'RT', 'A']; }
  }
  function problems() {
    const list = [];
    if (!String(st.series).trim()) list.push(['series', t('Choose the chassis series.')]);
    if (!String(st.number).trim()) list.push(['number', t('Enter the chassis number.')]);
    else if (!/^\d{1,6}$/.test(String(st.number).trim())) list.push(['number', t('The chassis number has up to six digits.')]);
    if (st.type === 1 && st.scope === 'mid' && !/^\d+$/.test(String(st.mid))) list.push(['mid', t('Choose a computer (MID).')]);
    if (st.type === 3 && !/^\d+$/.test(String(st.ck).trim())) list.push(['ck', t('Enter the conversion kit part number.')]);
    return list;
  }
  async function runRequest() {
    if (st.loading) return;
    const p = problems();
    if (p.length) { st.errors = p.map((x) => x[1]); st.touched = true; TR.app.refresh(); setTimeout(() => { const el = document.getElementById('vc-' + p[0][0]); if (el) el.focus(); }, 0); return; }
    st.loading = true; st.errors = []; st.result = null; TR.app.refresh();
    const started = performance.now();
    const r = await TR.api('TestRequest/VCADSRequest', { requestType: st.type, chassisSeries: String(st.series).trim(), chassisNumber: String(st.number).trim(), mid: st.type === 1 && st.scope === 'mid' ? String(st.mid) : '', ck: st.type === 3 ? st.ck : 0, namsRequest: st.nams });
    st.ms = Math.round(performance.now() - started);
    st.loading = false;
    if (r.success) {
      st.result = r.item; st.tab = 'response';
      st.runs.unshift({ at: new Date(), type: st.type, vehicle: `${st.series} ${st.number}`, scope: st.type === 1 ? (st.scope === 'mid' ? 'MID ' + st.mid : 'All ECUs') : st.type === 3 ? 'Kit ' + st.ck : 'All ECUs', workflows: r.item.workflowList.length, result: r.item });
      st.runs = st.runs.slice(0, 5);
      TR.announce && TR.announce(t('VCADS request finished: {n} workflow(s).', { n: r.item.workflowList.length }));
    } else { st.errors = r.errors || [t('Request failed')]; TR.announce && TR.announce(st.errors.join(' ')); }
    TR.app.refresh();
  }
  const typeName = (n) => t((TYPES.find((x) => x[0] === n) || TYPES[0])[1]);

  // ------------------------------------------------------------------ pieces
  function typeCards() {
    return h('div', { class: 'vc-types', role: 'radiogroup', 'aria-label': t('Request type') }, TYPES.map(([v, l, d, icon]) =>
      h('label', { class: ['vc-type', st.type === v ? 'is-on' : ''] },
        h('input', { type: 'radio', name: 'vc-type', checked: st.type === v, onChange: () => { st.type = v; st.errors = []; TR.app.refresh(); } }),
        h('span', { class: 'vc-type-icon', 'aria-hidden': 'true' }, TR.icon(icon, 22)), h('span', null, h('strong', null, t(l)), h('small', null, t(d))))));
  }
  function field(id, label, control, hint, required) {
    const err = st.touched && problems().find((p) => p[0] === id);
    return h('div', { class: ['vc-field', err ? 'has-error' : ''] }, h('label', { for: 'vc-' + id }, t(label), required ? h('span', { class: 'vc-req', 'aria-hidden': 'true' }, ' *') : null),
      control, err ? h('small', { class: 'vc-err', id: 'vc-' + id + '-err' }, err[1]) : hint ? h('small', { class: 'muted' }, t(hint)) : null);
  }
  function form() {
    const S = st.series_ || [];
    return h('section', { class: 'jr-card vc-form' },
      h('h2', null, '1. ', t('Request type')), typeCards(),
      h('div', { class: 'vc-nams' },
        h('label', { class: 'jr-switch' }, h('input', { type: 'checkbox', role: 'switch', checked: st.nams, onChange: (e) => { st.nams = e.target.checked; TR.app.refresh(); } }), h('span', { class: 'jr-switch-track', 'aria-hidden': 'true' }),
          h('span', null, h('strong', null, t('Simulate NAMS request')), h('small', { class: 'muted' }, t('Uses the configured simulation path.')))),
        h('a', { class: 'vc-how', href: '/guide/#vcads', target: '_blank', rel: 'noopener' }, TR.icon('info', 16), t('How this works'), TR.icon('chevron', 14))),
      h('hr', { class: 'jr-rule' }),
      h('h2', null, '2. ', t('Vehicle')),
      h('div', { class: 'vc-row' },
        field('series', 'Chassis series', h('select', { id: 'vc-series', 'aria-required': 'true', onChange: (e) => { st.series = e.target.value; TR.app.refresh(); } },
          (S.includes(st.series) ? S : [st.series].concat(S)).map((s) => h('option', { value: s, selected: s === st.series }, s))), 'Use the exact chassis identity.', true),
        field('number', 'Chassis number', h('input', { id: 'vc-number', inputmode: 'numeric', maxlength: 6, value: st.number, 'aria-required': 'true', onInput: (e) => { st.number = e.target.value; } }), null, true)),
      h('hr', { class: 'jr-rule' }),
      st.type === 3
        ? [h('h2', null, '3. ', t('Conversion kit')), field('ck', 'Conversion kit part number', h('input', { id: 'vc-ck', list: 'kit-numbers', inputmode: 'numeric', value: st.ck, placeholder: t('For example 23187001'), onInput: (e) => { st.ck = e.target.value; } }), 'Choose from the released kits or type a part number.', true)]
        : [h('h2', null, '3. ', t('Computers'), ' ', h('span', { class: 'muted vc-opt' }, t('(optional)'))),
          st.type === 1 ? h('div', { class: 'vc-row vc-scope' },
            h('div', null,
              h('div', { class: 'vc-seg', role: 'radiogroup', 'aria-label': t('Computers') }, [['all', 'All ECUs'], ['mid', 'Choose MID']].map(([k, l]) => h('label', { class: ['vc-seg-btn', st.scope === k ? 'is-on' : ''] },
                h('input', { type: 'radio', name: 'vc-scope', checked: st.scope === k, onChange: () => { st.scope = k; TR.app.refresh(); } }), t(l)))),
              h('select', { id: 'vc-mid', disabled: st.scope !== 'mid', 'aria-label': t('Computer (MID)'), onChange: (e) => { st.mid = e.target.value; TR.app.refresh(); } },
                [h('option', { value: '' }, t(st.scope === 'mid' ? 'Choose a computer' : 'Choose a MID when selection is enabled'))].concat(MIDS.map(([m, n]) => h('option', { value: m, selected: String(st.mid) === String(m) }, `${m} ${n}`)))),
              h('small', { class: 'muted' }, t(st.scope === 'mid' ? 'Only this computer is requested.' : 'All ECUs is used when no MID is specified.'))),
            h('div', { class: 'vc-examples' }, h('span', { class: 'muted' }, t('Example identifiers')), h('div', null, MIDS.slice(0, 3).map(([m, n]) => h('button', { type: 'button', class: 'vc-chip', onClick: () => { st.scope = 'mid'; st.mid = m; TR.app.refresh(); } }, `${m} ${n}`)))))
            : h('p', { class: 'muted' }, t('A hardware request covers every computer of the vehicle.'))]);
  }
  function summary() {
    const p = problems();
    return h('aside', { class: 'jr-side' },
      h('section', { class: 'jr-card vc-summary', 'aria-label': t('Request summary') },
        h('h2', { class: 'vc-sum-title' }, TR.icon('file', 20), t('Request summary')),
        h('dl', { class: 'vc-sum' },
          h('dt', null, t('Type')), h('dd', null, TR.icon((TYPES.find((x) => x[0] === st.type) || TYPES[0])[3], 16), typeName(st.type)),
          h('dt', null, t('Vehicle')), h('dd', null, TR.icon('truck', 16), `${st.series} ${st.number}`),
          h('dt', null, t(st.type === 3 ? 'Kit' : 'Scope')), h('dd', null, TR.icon('layers', 16), st.type === 3 ? (st.ck || '—') : st.type === 1 && st.scope === 'mid' ? (st.mid ? 'MID ' + st.mid + ' ' + ((MIDS.find((m) => String(m[0]) === String(st.mid)) || [])[1] || '') : '—') : t('All ECUs')),
          h('dt', null, 'NAMS'), h('dd', null, TR.icon('pulse', 16), st.nams ? t('Simulation (enabled)') : t('Off'))),
        h('div', { class: 'jr-banner tone-warning' }, TR.icon('info', 16), h('span', null, h('strong', null, t('Simulated request.')), ' ', t('No software is installed on a vehicle.'))),
        TR.pages.ui.button(st.loading ? t('Running…') : t('Run request'), 'play', runRequest, 'primary rv-wide', { disabled: st.loading, 'aria-describedby': p.length && st.touched ? 'vc-sum-err' : null }),
        st.errors.length ? h('ul', { class: 'vc-errors', id: 'vc-sum-err', role: 'alert' }, st.errors.map((e) => h('li', null, TR.icon('alert', 14), e))) : null,
        h('button', { class: 'jr-link vc-reset', onClick: () => { const runs = st.runs, s = st.series_; Object.assign(st, fresh(), { runs, series_: s }); TR.app.refresh(); } }, t('Reset form')),
        h('p', { class: 'muted jr-small' }, t('Results appear below; your last five runs of this session stay listed.'))));
  }
  function tiles(list) { return (list || []).length ? h('div', { class: 'vc-tiles' }, list.map((x) => h('span', { class: 'vc-tile' }, x))) : h('p', { class: 'muted' }, t('None')); }
  function result() {
    const r = st.result, cv = r && r.completeVehicle;
    const head = h('header', { class: 'jr-card-head' }, h('h2', null, TR.icon('file', 20), ' ', t('Result')),
      r ? h('div', { class: 'jr-tabs vc-tabs', role: 'tablist' }, [['response', 'Response'], ['vehicle', 'Vehicle'], ['raw', 'Raw']].map(([k, l]) => h('button', { role: 'tab', 'aria-selected': String(st.tab === k), class: st.tab === k ? 'is-on' : '', onClick: () => { st.tab = k; TR.app.refresh(); } }, t(l)))) : null);
    if (st.loading) return h('section', { class: 'jr-card' }, head, h('div', { class: 'vc-empty', role: 'status' }, h('span', { class: 'spinner small' }), t('Waiting for the simulated VCADS service…')));
    if (!r) return h('section', { class: 'jr-card' }, head, h('div', { class: 'vc-empty' }, TR.icon('file', 26), h('div', null, h('strong', null, t('No request run yet.')), h('p', { class: 'muted' }, t('Run the request to inspect its response, messages and trace.')))));
    const body = st.tab === 'response'
      ? h('div', null,
        h('div', { class: 'jr-meta' }, J().chip('completed', t('Completed')), h('span', null, r.typeOfCamsRequest + (r.namsRequest ? ' · ' + t('simulated NAMS request') : '')), h('span', null, t('{n} workflow(s)', { n: r.workflowList.length })), st.ms != null ? h('span', { class: 'muted' }, st.ms + ' ms') : null),
        r.workflowList.length ? h('ol', { class: 'vc-workflows' }, r.workflowList.map((w, i) => h('li', null, h('details', { open: i === 0 }, h('summary', null, h('strong', null, (w.name || w.workflowName || t('Workflow')) + (w.mid ? ' · MID ' + w.mid : '')), h('small', { class: 'muted' }, ' ' + (w.description || w.type || ''))),
          ui.jsonViewer(w, { expandDepth: 2 })))))
          : h('p', { class: 'muted' }, t('No replacements available for the vehicle.')))
      : st.tab === 'vehicle'
        ? h('div', { class: 'vc-vehicle' },
          J().facts([['Chassis', cv.chassisSeries + ' ' + cv.chassisNumber], ['Model', cv.model], ['Assembly date', cv.assemblyDate], ['Country', cv.countryCode]]),
          h('h3', { class: 'jr-h4' }, t('Parts')), (cv.parts || []).length ? h('div', { class: 'jr-table-wrap' }, h('table', { class: 'jr-table' }, h('thead', null, h('tr', null, ['MID', 'Item', 'Part'].map((c) => h('th', null, t(c))))),
            h('tbody', null, cv.parts.flatMap((p) => (p.components || [{ item: p.item, parts: [p.part] }]).map((c) => h('tr', null, h('td', null, String(p.mid)), h('td', null, c.item || '—'), h('td', null, h('code', null, (c.parts || []).filter(Boolean).join(', ') || '—'))))))))
            : h('p', { class: 'muted' }, t('None')),
          h('h3', { class: 'jr-h4' }, t('Parameters')), tiles(cv.parameters), h('h3', { class: 'jr-h4' }, t('S-Notes')), tiles(cv.snotes), h('h3', { class: 'jr-h4' }, t('Variants')), tiles(cv.variants))
        : h('pre', { class: 'jr-pre', tabindex: '0', 'aria-label': t('Raw response') }, JSON.stringify(r, null, 2));
    return h('section', { class: 'jr-card' }, head, body,
      st.runs.length > 1 ? h('div', { class: 'vc-runs' }, h('h3', { class: 'jr-h4' }, t('This session')), h('ul', null, st.runs.map((x, i) => h('li', null,
        h('button', { class: 'jr-link', onClick: () => { st.result = x.result; st.tab = 'response'; TR.app.refresh(); }, 'aria-current': x.result === r ? 'true' : null }, `${TR.journey ? TR.journey.time(x.at) : x.at.toLocaleTimeString()} · ${typeName(x.type)} · ${x.vehicle} · ${x.scope} · ${t('{n} workflow(s)', { n: x.workflows })}`))))) : null);
  }
  const J = () => TR.journey || { chip: (s, l) => h('span', null, l), facts: (rows) => h('dl', null, rows.map(([k, v]) => [h('dt', null, k), h('dd', null, v)])) };

  function render() {
    seriesList();
    return h('div', { class: 'jr-page vc-page' },
      h('div', { class: 'jr-head' }, h('div', null, h('h1', null, t('VCADS request')), h('p', { class: 'jr-sub' }, t('Choose a request type, identify the vehicle and select its computers.'))),
        h('div', { class: 'jr-actions' }, h('a', { class: 's-btn secondary', href: '/guide/#vcads', target: '_blank', rel: 'noopener' }, TR.icon('book', 17), t('Open guide')))),
      h('div', { class: 'jr-split' }, form(), summary()),
      result(),
      h('p', { class: 'jr-foot muted' }, t('The simulated VCADS service answers; nothing is sent to a vehicle.')));
  }

  TR.vcads = { render, state: st, problems };
})();
