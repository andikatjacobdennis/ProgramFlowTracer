/* JSON <-> XML serialization used for Product XML, Report XML, request/response XML and XML file loading. */
(function () {
  'use strict';
  const TR = window.TR;

  const NS = {
    product: 'http://www.volvo.com/ProductWithConnectedServices/1_0',
    request: 'http://www.volvo.com/ProductsUpdate/1_1',
  };

  const ARRAY_ITEMS = {
    authorizedProductClasses: 'ProductClass', softwareProducts: 'SoftwareProduct', variants: 'Variant', sNotes: 'SNote', parameters: 'Parameter', references: 'Reference', datas: 'Data', patches: 'Patch',
    complementarySoftwares: 'ComplementarySoftware', subHardwares: 'SubHardware', subSoftwares: 'SubSoftware', subDataSets: 'SubDataSet',
    subComplementarySoftwares: 'SubComplementarySoftware', softwareFunctions: 'SoftwareFunction', notifications: 'Notification',
    fieldNumbers: 'FieldNumber', softwareRelatedHardwares: 'SoftwareRelatedHardware', connectedServices: 'ConnectedService',
    capabilities: 'Capability', linkReferences: 'LinkReference', vdaCampaigns: 'Campaign', operations: 'Operation', products: 'Product',
    requestedNodes: 'RequestedNode', conversionKitNumbers: 'ConversionKitNumber', selectedActionCriteriaTypes: 'ActionCriteriaType',
    actionCriteriaTypes: 'ActionCriteriaType', selectedSpareCabRequestedNodes: 'Node', spareCabNodes: 'SpareCabNode', removedNodes: 'RemovedNode',
    affectedNodes: 'Node', dependentNodes: 'Node', releaseNotes: 'ReleaseNote', errors: 'Error', items: 'Item', nodes: 'Node',
    documentNumbers: 'DocumentNumber', softwareRelatedHardwaresList: 'Hardware', languageComponents: 'LanguageComponent',
  };
  const NUMBER_KEYS = new Set(['number', 'quantity', 'index', 'position', 'type', 'family', 'mid', 'electricalArchitecture', 'severity', 'offsetAddress',
    'compressionMethod', 'encryptionMethod', 'descriptionFileNumber', 'nodeState', 'selectedRequestType', 'selectedSoftwareRequestOperation',
    'selectedScenario', 'selectedRemote', 'selectedKitScenario', 'scenario', 'softwareRequestOperation', 'remoteRequest', 'documentNumber',
    'kitPartNumber', 'no', 'sortOrder', 'actionCriteriaType', 'id', 'contextId', 'previousEcuHardware', 'itemNumberQuantity']);
  const NUMBER_ARRAYS = new Set(['selectedActionCriteriaTypes', 'actionCriteriaTypes', 'documentNumbers']);
  const NODE_ELEMENTS = { 0: 'Tea2Node', 1: 'Tea2PlusNode', 2: 'Bea2BodyNode', 3: 'T3Node' };
  const NODE_EA = { Tea2Node: 0, Tea2PlusNode: 1, Bea2BodyNode: 2, T3Node: 3 };

  const pascal = (k) => k.charAt(0).toUpperCase() + k.slice(1);
  const camel = (k) => k.charAt(0).toLowerCase() + k.slice(1);
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  function el(key, value, ind, nameOverride, opts) {
    const name = nameOverride || pascal(key);
    const pad = '  '.repeat(ind);
    if (value === null || value === undefined) return opts && opts.dropNulls ? '' : `${pad}<${name} nil="true"/>\n`;
    if (Array.isArray(value)) {
      if (!value.length) return opts && opts.dropNulls ? '' : `${pad}<${name}/>\n`;
      return `${pad}<${name}>\n${value.map((v) => {
        let itemName = ARRAY_ITEMS[key] || 'Item';
        if (key === 'nodes' && v && typeof v === 'object' && !(opts && opts.reportNodes)) itemName = NODE_ELEMENTS[v.electricalArchitecture] || 'Node';
        return el('__item_' + key, v, ind + 1, itemName, opts);
      }).join('')}${pad}</${name}>\n`;
    }
    if (typeof value === 'object') {
      const keys = Object.keys(value).filter((k) => value[k] !== undefined);
      if (!keys.length) return `${pad}<${name} kind="object"/>\n`;
      return `${pad}<${name}>\n${keys.map((k) => el(k, value[k], ind + 1, null, opts)).join('')}${pad}</${name}>\n`;
    }
    return `${pad}<${name}>${esc(value)}</${name}>\n`;
  }

  function conv(key, text) {
    if (NUMBER_KEYS.has(key) && text !== '' && !isNaN(Number(text))) return Number(text);
    if (text === 'true') return true;
    if (text === 'false') return false;
    return text;
  }

  function parseEl(node, key) {
    if (node.getAttribute('nil') === 'true') return null;
    const kids = Array.from(node.children);
    if (ARRAY_ITEMS[key] !== undefined) {
      return kids.map((k) => {
        if (!k.children.length && k.getAttribute('kind') !== 'object') return NUMBER_ARRAYS.has(key) ? Number(k.textContent) : conv('', k.textContent);
        const o = parseEl(k, '__obj');
        if (key === 'nodes' && NODE_EA[k.localName] !== undefined) o.electricalArchitecture = NODE_EA[k.localName];
        return o;
      });
    }
    if (!kids.length) {
      if (node.getAttribute('kind') === 'object') return {};
      return conv(key, node.textContent);
    }
    const o = {};
    for (const k of kids) { const ck = camel(k.localName); o[ck] = parseEl(k, ck); }
    return o;
  }

  function serialize(rootName, obj, ns, opts) {
    const body = Object.keys(obj).filter((k) => obj[k] !== undefined).map((k) => el(k, obj[k], 1, null, opts)).join('');
    return `<?xml version="1.0" encoding="utf-8"?>\n<${rootName} xmlns="${ns || NS.product}" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">\n${body}</${rootName}>\n`;
  }

  function parseDoc(xml) {
    const doc = new DOMParser().parseFromString(xml, 'application/xml');
    const err = doc.getElementsByTagName('parsererror')[0];
    if (err) throw new Error('The XML is not well formed: ' + err.textContent.replace(/\s+/g, ' ').trim().slice(0, 200));
    return doc;
  }

  function parseRoot(rootEl) {
    const o = {};
    for (const k of Array.from(rootEl.children)) { const ck = camel(k.localName); o[ck] = parseEl(k, ck); }
    return o;
  }

  const productToXml = (p) => serialize('ProductWithConnectedServices', p, NS.product);

  const REPORT_ORDER = ['name', 'nodeTemplateDocument', 'nodeIdentifier', 'nodeTemplateStatus', 'nodeState', 'nodePath', 'versionName', 'electricalArchitecture',
    'isCabNode', 'replacementChainName', 'ecuHardware', 'primaryBootloader', 'secondaryBootloader', 'mainSoftware', 'notifications'];
  function productToReportXml(p) {
    const c = TR.util.clone(p);
    c.nodes = (c.nodes || []).map((n) => {
      const o = {};
      REPORT_ORDER.forEach((k) => { if (n[k] !== undefined && n[k] !== null) o[k] = n[k]; });
      Object.keys(n).forEach((k) => { if (!(k in o) && n[k] !== null && n[k] !== undefined) o[k] = n[k]; });
      return o;
    });
    return serialize('ProductReport', { product: c }, NS.product, { dropNulls: true, reportNodes: true });
  }

  const REQUEST_ROOTS = {
    0: 'SoftwareRequest', 1: 'HardwareRequest', 2: 'KitRequest', 3: 'LanguageRequest', 4: 'SpareCabRequest',
    5: 'ProductionSoftwareBreakdownRequest', 6: 'DevelopmentSoftwareBreakdownRequest', 7: 'AvailableUpdatesRequest',
  };
  /** payload: the request object posted to AftermarketRequest; requestModel: UI RequestModel (round-tripped for XML file loading). */
  function requestToXml(type, payload, requestModel, header) {
    const obj = Object.assign({ header: header || {} }, payload, { requestModel });
    return serialize(REQUEST_ROOTS[type] || 'Request', obj, NS.request);
  }
  function responseToXml(rootName, items, header) {
    return serialize(rootName, { header: header || {}, items }, NS.request);
  }

  /** XmlFile/Load: returns {products, request, xml} */
  function loadXmlFile(xml) {
    const doc = parseDoc(xml);
    const root = doc.documentElement;
    const name = root.localName;
    if (name === 'ProductWithConnectedServices' || name === 'Product') return { products: [parseRoot(root)], request: null, xml };
    if (name === 'ProductReport') { const o = parseRoot(root); return { products: [o.product], request: null, xml }; }
    if (/Request$/.test(name)) {
      const o = parseRoot(root);
      const products = o.products || (o.product ? [o.product] : []);
      if (!products.length) throw new Error(`The request XML '${name}' does not contain any product.`);
      return { products, request: o.requestModel || null, xml };
    }
    throw new Error(`Unknown XML root element '${name}'. Expected a product XML or a request XML.`);
  }

  /** Parameter import format: <Parameters><Parameter code="" electricalArchitecture="TEA2+"><Reference code="" value=""/></Parameter></Parameters> */
  function parseParametersXml(xml) {
    const doc = parseDoc(xml);
    const errors = [];
    const out = [];
    Array.from(doc.getElementsByTagName('Parameter')).forEach((p, i) => {
      const code = (p.getAttribute('code') || '').trim();
      const eaText = (p.getAttribute('electricalArchitecture') || 'TEA2+').trim().toUpperCase();
      if (!code) { errors.push(`Parameter #${i + 1} has no code`); return; }
      let ea;
      if (eaText === 'TEA2') ea = 0; else if (eaText === 'TEA2+') ea = 1; else { errors.push(`Unknown electrical architecture type '${eaText}' for parameter ${code}`); return; }
      const references = Array.from(p.getElementsByTagName('Reference')).map((r) => ({ code: r.getAttribute('code') || 'VAL', value: r.getAttribute('value') }));
      out.push({ code, electricalArchitecture: ea, references, packaged: p.getAttribute('packaged') === 'true', isGroupAdministrative: false, isFunction: false, valueNotVisibleToUser: false, source: null, notifications: [] });
    });
    if (!out.length && !errors.length) errors.push('No <Parameter> elements found in the file.');
    return { parameters: out, errors };
  }

  function parametersToXml(params) {
    const lines = params.map((p) => `  <Parameter code="${esc(p.code)}" electricalArchitecture="${p.electricalArchitecture === 0 ? 'TEA2' : 'TEA2+'}">\n${(p.references || []).map((r) => `    <Reference code="${esc(r.code)}" value="${esc(r.value == null ? '' : r.value)}"/>\n`).join('')}  </Parameter>\n`);
    return `<?xml version="1.0" encoding="utf-8"?>\n<Parameters>\n${lines.join('')}</Parameters>\n`;
  }

  TR.xml = { NS, serialize, parseDoc, parseRoot, productToXml, productToReportXml, requestToXml, responseToXml, loadXmlFile, parseParametersXml, parametersToXml, REQUEST_ROOTS };
})();
