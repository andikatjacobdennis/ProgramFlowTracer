/* Application shell: page navigation, Test Request page (ShellViewModel), source filter, History (log-product-source),
   Campaigns, VESPA2 round trip simulator, settings, guide/samples and query-string bootstrap. */
(function () {
  'use strict';
  const TR = window.TR;
  const E = TR.enums;
  const M = TR.model;
  const { h, clone, clear } = TR.util;
  const ui = TR.ui;

  const params = new URLSearchParams(location.search);
  const shell = {
    left: null, right: null, fullScreen: null, showSource: false, sourceFilter: null, devMode: params.has('devMode'),
    filterInputs: { variants: '', items: '' },
    history: { requestType: '', from: '', to: '', ignoreTest: false, userId: '', series: '', number: '', baselineGuid: '', page: 0, selectedId: null, loadWhat: 'both', items: [], hits: 0, loading: false, error: '' },
  };

  let pending = false;
  const app = {
    page: params.get('page') || 'testrequest',
    shell,
    async run(fn, text) {
      ui.summary.clearAll();
      ui.progress.show(text);
      let r;
      try { r = await fn(); } catch (e) { r = { success: false, errors: [e.message || String(e)] }; console.error(e); } finally { ui.progress.hide(); }
      if (!r) r = { success: false, errors: ['No response'] };
      ui.summary.displayResult(r);
      app.refresh();
      return r;
    },
    refresh() {
      if (pending) return;
      pending = true;
      Promise.resolve().then(() => { pending = false; render(); });
    },
    ensureVisible(pane) { if (shell.fullScreen && shell.fullScreen !== pane.position) shell.fullScreen = null; },
    navigate(page) {
      app.page = page; ui.summary.clearAll();
      const u = new URL(location.href); u.searchParams.set('page', page);
      // Compare and VCADS are workspaces of their own: a page opened before (Batch runs, Requests…) no longer applies, so its
      // breadcrumb and ?view= must not stay (Compare showed "Batch runs" in the breadcrumb).
      if (page !== 'testrequest') { if (TR.experience) TR.experience.page = null; ['view', 'rid', 'vid'].forEach((k) => u.searchParams.delete(k)); }
      history.replaceState(null, '', u); render();
    },
  };
  app.refreshSoon = TR.util.debounce(() => app.refresh(), 120);
  TR.app = app;

  // ---------- rendering ----------
  function header() {
    if (TR.testRequest) return TR.testRequest.header();
    const st = TR.server.state.settings;
    const nav = [['testrequest', 'Test Request Tool'], ['vcads', 'VCADS Test Request'], ['compare', 'Compare Breakdown']];
    return h('header', { class: 'topbar' },
      h('div', { class: 'brand' }, h('span', { class: 'logo' }, 'SW'), h('span', null, 'Configurator'), h('span', { class: 'sim-badge', title: 'All data and server calls are simulated in the browser' }, 'SIMULATOR')),
      h('nav', { class: 'menu' }, h('span', { class: 'menu-label' }, 'Tools:'), nav.map(([k, label]) => h('button', { class: ['nav-btn', app.page === k && 'active'], onClick: () => app.navigate(k) }, label))),
      h('div', { class: 'spacer' }),
      h('button', { class: 'nav-btn', onClick: guidePopup, title: 'Reference data, scenarios and sample files' }, '❓ Guide'),
      h('button', { class: ['nav-btn', TR.uiDrawer.open && 'active'], onClick: () => TR.uiDrawer.toggle(), title: 'Show the simulated server calls' }, '⇅ Server calls ', h('span', { class: 'count', id: 'apilog-count' }, String(TR.server.apiLog.length))),
      h('button', { class: 'nav-btn user', onClick: settingsPopup, title: 'Simulated user & permissions' }, '👤 ', st.userId));
  }

  /**
   * Draws the header and the page. It never leaves a blank screen: when drawing fails, the page that was showing is put
   * back and a notice says so; when there was none (start-up), the start-up recovery screen (theme-boot.js) shows the error
   * with Reload and Reset my settings.
   */
  function render() {
    const root = document.getElementById('app');
    const before = Array.from(root.childNodes);
    try {
      TR.util.preserve(() => {
        clear(root);
        // The header goes in first: the menu bar (navigation.js) is placed in its slot while the frame is built.
        root.appendChild(header());
        let page;
        if (app.page === 'vcads') page = TR.vcads.render();
        else if (app.page === 'compare') page = TR.compare.render();
        else page = renderTestRequest();
        root.appendChild(TR.testRequest ? TR.testRequest.frame(page) : h('main', { class: 'page' }, page));
      });
    } catch (e) {
      renderFailed(root, before, e);
    }
  }
  app.renderFailures = 0;
  function renderFailed(root, before, e) {
    app.renderFailures++;
    const message = e && e.message ? e.message : String(e);
    if (typeof console !== 'undefined') console.error('The page could not be drawn:', e);
    const hadPage = before.some((n) => n.nodeType === 1 && n.classList && (n.classList.contains('s-layout') || n.classList.contains('page') || n.classList.contains('s-topbar') || n.classList.contains('topbar')));
    clear(root);
    if (hadPage) {
      before.forEach((n) => root.appendChild(n));
      if (TR.notify) TR.notify.toast((TR.i18n ? TR.i18n.t('This view could not be shown, so the previous view is still on screen.') : 'This view could not be shown, so the previous view is still on screen.') + ' ' + message, 'error');
      return;
    }
    if (window.TRBoot && !document.documentElement.hasAttribute('data-booted')) { window.TRBoot.fail(message); return; }
    root.appendChild(h('main', { class: 'boot-card', role: 'alert' },
      h('h1', null, 'This view could not be shown'),
      h('p', null, 'Your work on the server is safe. Reload the page to continue.'),
      h('details', null, h('summary', null, 'Details'), h('pre', null, message)),
      h('div', { class: 'boot-actions' },
        h('button', { type: 'button', class: 'boot-btn primary', onClick: () => location.reload() }, 'Reload'))));
  }
  ui.summary.listeners.push(() => app.refresh());

  function renderTestRequest() {
    if (TR.testRequest && TR.testRequest.view !== 'expert') return TR.testRequest.workspace();
    const left = shell.left, right = shell.right;
    const vdaLeft = left.productVda;
    const hasCampaigns = !!(vdaLeft && (vdaLeft.vdaCampaigns || []).length);
    // The page in the journey design: heading with the Focused / Two-pane switch, the five steps, a short guide, the
    // tools (Show source, Filter, History), the two panes, and the next thing to do.
    const tt = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : s);
    const next = !left.product.loaded() ? 'load a starting vehicle' : !left.product.dirty() && !right.product.loaded() ? 'change the configuration, or create a request' : right.product.loaded() ? 'compare, then commit or export the result' : 'create a request from the starting vehicle';
    const toFocused = () => { if (TR.testRequest) { TR.testRequest.view = 'focused'; TR.testRequest.page(); } };
    shell.guideOpen = shell.guideOpen || false;
    return h('div', { class: 'tr-page tw-page' },
      ui.summary.render(),
      h('header', { class: 'tw-head' },
        h('div', null, h('h1', null, tt('Two-pane workbench')), h('p', null, tt('Load a starting vehicle, then inspect a result or compare another vehicle.'))),
        h('div', { class: 'tw-modes', role: 'group', 'aria-label': tt('Workspace view') },
          h('button', { type: 'button', 'aria-pressed': 'false', onClick: toFocused }, TR.icon('grid', 16), tt('Focused')),
          h('button', { type: 'button', 'aria-pressed': 'true', class: 'is-on' }, TR.icon('compare', 16), tt('Two-pane')))),
      // workflow.js puts the stepper and the decision bar here (the slot keeps them under the heading, as designed).
      h('div', { class: 'tw-steps-slot' }),
      h('div', { class: 'tw-guide', role: 'note' },
        h('div', null, h('span', null, TR.icon('info', 16), ' ', left.product.loaded() ? tt('The left pane holds the vehicle you change; the right pane shows the result or a second vehicle.') : tt('Start by loading a vehicle on the left.')),
          shell.guideOpen ? h('ol', null, h('li', null, tt('Load the starting vehicle (chassis, VIN, EDB or a file).')), h('li', null, tt('Change its software, parameters or variants.')), h('li', null, tt('Choose Request: the response opens on the right.')), h('li', null, tt('Compare, then commit or export.'))) : null),
        h('button', { class: 'jr-link', 'aria-expanded': String(shell.guideOpen), onClick: () => { shell.guideOpen = !shell.guideOpen; app.refresh(); } }, tt(shell.guideOpen ? 'Hide quick guide' : 'Show quick guide'), TR.icon(shell.guideOpen ? 'up' : 'chevron', 13))),
      h('div', { class: 'tw-toolbar' },
        h('label', { class: 'jr-switch' }, h('input', { type: 'checkbox', role: 'switch', checked: shell.showSource, onChange: (e) => { shell.showSource = e.target.checked; app.refresh(); } }), h('span', { class: 'jr-switch-track', 'aria-hidden': 'true' }), tt('Show source')),
        h('button', { class: ['s-btn', 'secondary', shell.sourceFilter && 'active'], onClick: filterPopup, 'data-tip': shell.sourceFilter ? `${tt('Filter')}|${shell.sourceFilter.variantsText} ${shell.sourceFilter.itemsText}` : tt('Filter|Filter nodes, parts and parameters by source') }, TR.icon('filter', 15), tt('Filter'), shell.sourceFilter ? ' •' : ''),
        h('button', { class: 's-btn secondary', onClick: () => TR.shellActions.historyPopup(), 'data-tip': tt('History|Load a request and response from the request log') }, TR.icon('history', 15), tt('History')),
        hasCampaigns ? h('button', { class: 's-btn secondary', onClick: campaignsPopup, 'data-tip': tt('Campaigns|Campaigns of the starting vehicle (from VDA)') }, TR.icon('bell', 15), tt('Campaigns')) : null,
        shell.devMode ? h('span', { class: 's-chip neutral' }, 'devMode') : null),
      h('div', { class: ['split', shell.fullScreen && 'fs-' + shell.fullScreen] }, left.render(), right.render()),
      h('p', { class: 'tw-foot', role: 'status' }, tt('Next: {n}', { n: tt(next) })));
  }

  // ---------- source filter popup ----------
  function filterPopup() {
    const fi = shell.filterInputs;
    const apply = (m) => { shell.sourceFilter = M.makeSourceFilter(fi.variants, fi.items); m.close(); app.refresh(); };
    ui.modal({
      title: 'Source filter', width: 380,
      body: (m) => h('div', { class: 'form' },
        h('label', null, 'Variants', h('input', { class: 'upper', key: 'flt-var', placeholder: 'Enter variant symbols', value: fi.variants, onInput: (e) => { fi.variants = e.target.value; }, onKeydown: (e) => { if (e.key === 'Enter') apply(m); } })),
        h('label', null, 'Part numbers', h('input', { key: 'flt-items', placeholder: 'Enter part numbers', value: fi.items, onInput: (e) => { fi.items = e.target.value; }, onKeydown: (e) => { if (e.key === 'Enter') apply(m); } })),
        h('div', { class: 'small muted' }, 'Only nodes, parts and parameters whose source matches are shown. Sources exist on breakdown products (Production/Development Breakdown, EDB).')),
      buttons: [{ label: 'Clear filter', onClick: (m) => { fi.variants = ''; fi.items = ''; apply(m); } }, { label: 'Apply filter', primary: true, onClick: (m) => apply(m) }],
    });
  }

  // ---------- History (log-product-source) ----------
  async function searchHistory(m) {
    const f = shell.history;
    f.loading = true;
    if (m && !m.closed) m.render();
    const r = await TR.api('RequestLog/List', { requestType: f.requestType, from: f.from || null, to: f.to || null, ignoreTestRequests: f.ignoreTest, userId: f.userId, chassisSeries: f.series, chassisNumber: f.number, baselineGuid: f.baselineGuid, pageSize: 10, index: f.page });
    f.loading = false;
    if (r.success) { f.items = r.items; f.hits = r.numberOfHits; f.error = ''; } else { f.items = []; f.hits = 0; f.error = 'Could not load log entries.'; }
    if (m && !m.closed) m.render();
  }
  /** The request-log search (filters, results, details and Load). host has render() and close(): a panel, or the History page. */
  function historyView() {
    const f = shell.history;
    const pad = TR.util.pad;
    const dtLocal = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    const day = (offset) => { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() + offset); return dtLocal(d); };
    const changed = (m) => { f.page = 0; f.selectedId = null; searchHistory(m); };
    const setF = (k, v, m) => { f[k] = v; changed(m); };
    const linkBtn = (label, fn) => h('button', { class: 'link-btn small', onClick: fn }, label);
    return (mm) => {
        const sel = f.items.find((x) => x.id === f.selectedId);
        const t = f.requestType === '' ? null : Number(f.requestType);
        const pages = Math.max(1, Math.ceil(f.hits / 10));
        const cols = [h('th', null, ''), h('th', null, 'Date/time (UTC)'), t === null ? h('th', null, 'Request type') : null, t === 0 || t === 7 || t === null ? h('th', null, 'Operation') : null, t === 0 || t === 2 || t === null ? h('th', null, 'Scenario') : null, t === 2 ? h('th', null, 'Kit part numbers') : null, h('th', null, 'Chassis series'), h('th', null, 'Chassis number'), h('th', null, 'User')];
        return h('div', { class: 'history-body' },
          h('div', { class: 'hist-filters' },
            h('label', null, 'Request type ', ui.select([['', 'All']].concat([0, 2, 4, 5, 6, 7].map((v) => [v, E.RequestTypeNames[v]])), f.requestType, (v) => setF('requestType', v, mm))),
            h('span', null, 'Date/time ', linkBtn('today', () => { f.from = day(0); f.to = ''; changed(mm); }), ' ', linkBtn('yesterday', () => { f.from = day(-1); f.to = day(0); changed(mm); }), ' ', linkBtn('clear', () => { f.from = ''; f.to = ''; changed(mm); }), ' ',
              h('input', { type: 'datetime-local', placeholder: 'From', value: f.from, onChange: (e) => setF('from', e.target.value, mm) }), ' ', h('input', { type: 'datetime-local', placeholder: 'To', value: f.to, onChange: (e) => setF('to', e.target.value, mm) })),
            h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: f.ignoreTest, onChange: (e) => setF('ignoreTest', e.target.checked, mm) }), ' Ignore test requests')),
          h('div', { class: 'hist-filters' },
            h('span', null, 'User ', linkBtn('me', () => setF('userId', TR.server.state.settings.userId, mm)), ' ', linkBtn('clear', () => setF('userId', '', mm)), ' ', h('input', { key: 'hist-user', size: 10, placeholder: 'User ID', value: f.userId, onChange: (e) => setF('userId', e.target.value.trim(), mm) })),
            h('span', null, 'Chassis ', linkBtn('left', () => { const c = shell.left.product.loaded() ? shell.left.product.chassis() : { chassisSeries: '', chassisNumber: '' }; f.series = c.chassisSeries; f.number = c.chassisNumber; changed(mm); }), ' ', linkBtn('right', () => { const c = shell.right.product.loaded() ? shell.right.product.chassis() : { chassisSeries: '', chassisNumber: '' }; f.series = c.chassisSeries; f.number = c.chassisNumber; changed(mm); }), ' ', linkBtn('clear', () => { f.series = ''; f.number = ''; changed(mm); }), ' ',
              h('input', { key: 'hist-series', size: 5, class: 'upper', placeholder: 'Series', value: f.series, onChange: (e) => setF('series', e.target.value.trim(), mm) }), ' ', h('input', { key: 'hist-number', size: 7, placeholder: 'Number', value: f.number, onChange: (e) => setF('number', e.target.value.trim(), mm) })),
            h('span', null, 'Baseline guid ', linkBtn('clear', () => setF('baselineGuid', '', mm)), ' ', h('input', { key: 'hist-bl', size: 14, value: f.baselineGuid, onChange: (e) => setF('baselineGuid', e.target.value.trim(), mm) })),
            f.loading ? h('span', { class: 'spinner small' }) : null),
          f.error ? h('div', { class: 'error-text' }, f.error) : null,
          h('table', { class: 'grid hist-table' }, h('thead', null, h('tr', null, cols)), h('tbody', null, f.items.map((x) => h('tr', { class: ['clickable', x.id === f.selectedId && 'flash selected'], onClick: () => { f.selectedId = x.id; mm.render(); }, onDblclick: () => { f.selectedId = x.id; loadLog(mm); } },
            h('td', null, x.senderId === 'NAMS' ? h('span', { class: 'badge', title: 'NAMS request' }, 'NAMS') : x.isTestRequest ? h('span', { class: 'badge', title: 'Test request' }, 'TEST') : h('span', { class: 'badge muted' }, x.senderId)),
            h('td', null, TR.util.fmtDateTime(x.receivedAt, true)), t === null ? h('td', null, E.RequestTypeNames[x.requestType]) : null,
            t === 0 || t === 7 || t === null ? h('td', { title: x.operationType }, (x.operationType || '').replace(/SoftwareReplacements\./g, '').slice(0, 40)) : null,
            t === 0 || t === 2 || t === null ? h('td', null, x.scenario) : null, t === 2 ? h('td', null, x.kitPartNumbers) : null,
            h('td', null, x.chassisSeries), h('td', null, x.chassisNumber), h('td', null, x.userId))))),
          !f.items.length && !f.loading ? h('div', { class: 'muted pad' }, 'No log entries match the specified criteria.') : null,
          f.hits > 10 ? h('div', { class: 'pager' }, h('button', { class: 'btn small', disabled: f.page === 0, onClick: () => { f.page--; searchHistory(mm); } }, '◄'), ` Page ${f.page + 1} of ${pages} (${f.hits} entries) `, h('button', { class: 'btn small', disabled: f.page >= pages - 1, onClick: () => { f.page++; searchHistory(mm); } }, '►')) : f.hits ? h('div', { class: 'small muted' }, `${f.hits} entries`) : null,
          sel ? h('div', { class: 'hist-details' }, ui.kv([['Transaction ID', sel.transactionId], ['Incoming message ID', sel.incomingMessageId], ['Outgoing message ID', sel.outgoingMessageId], ['Sender ID', `${sel.senderId} (${sel.sender})`],
            sel.requestType === 0 ? ['Operation', sel.operationType] : null, sel.requestType === 2 ? ['Kit part numbers', sel.kitPartNumbers] : null,
            sel.requestType === 6 && sel.baselineGuid ? ['Baseline', h('a', { href: TR.server.baselineUrl(sel.baselineGuid) }, 'Show baseline')] : null,
            sel.requestType === 0 || sel.requestType === 2 ? ['Scenario', sel.scenario] : null, sel.requestType === 0 ? ['Multi node behavior', sel.multiNodeBehaviour ? 'Yes' : 'No'] : null,
            (sel.requestType === 0 || sel.requestType === 2) && sel.requestedNodes ? ['Requested nodes', sel.requestedNodes] : null])) : null,
          sel ? h('div', { class: 'hist-actions' }, h('button', { class: 'btn primary small', onClick: () => loadLog(mm) }, 'Load'),
            ['request', 'both', 'response'].map((k) => h('label', { class: 'chk' }, h('input', { type: 'radio', name: 'loadwhat', checked: f.loadWhat === k, onChange: () => { f.loadWhat = k; } }), ' ', k[0].toUpperCase() + k.slice(1))),
            h('a', { href: `#/NamsLog?id=${sel.id}` }, 'Show in NAMS log')) : null);
    };
  }
  // History opens as a page (app/history.js replaces this); the panel remains for callers without the page.
  function historyPopup() {
    const m = ui.modal({ title: 'History', width: 860, class: 'history', body: historyView() });
    searchHistory(m);
  }
  async function loadLog(m) {
    const f = shell.history;
    const r = await app.run(() => TR.api('RequestLog/LoadByLogId', { logId: f.selectedId }), 'Loading log entry');
    if (!r.success) return;
    m.close();
    loadBoth(r.item, f.loadWhat);
  }
  function loadBoth(rr, what) {
    what = what || 'both';
    if (what !== 'response') {
      shell.left.setProducts(rr.requestedProducts, { request: rr.request, requestXml: rr.requestXml, requestedNodes: rr.request && rr.request.requestedNodes, mode: 'product' });
      if (rr.request) shell.left.request = Object.assign(TR.defaultRequest(), clone(rr.request));
    }
    if (what !== 'request') {
      if (rr.availableUpdateResponses && rr.availableUpdateResponses.length) shell.right.setProducts([], { availableUpdate: rr.availableUpdateResponses[0], responseXml: rr.responseXml });
      else if (rr.breakdown) shell.right.setProducts(rr.products, { responseXml: rr.responseXml, mode: 'product' });
      else {
        const deltas = {};
        (rr.responses || []).forEach((x) => { deltas[TR.chassis.chassisKey(x)] = x.delta; });
        shell.right.setProducts(rr.requestedProducts, { deltas, response: rr.responses, responseXml: rr.responseXml });
      }
    }
    if (rr.logEntry) ui.summary.addInformation(`Loaded ${E.RequestTypeNames[rr.logEntry.requestType]} request from ${rr.logEntry.sender} (${TR.util.fmtDateTime(rr.logEntry.receivedAt, true)} UTC, transaction ${rr.logEntry.transactionId}).`);
    app.refresh();
  }

  // ---------- Campaigns ----------
  function campaignsPopup() {
    const left = shell.left;
    const camps = (left.productVda && left.productVda.vdaCampaigns) || [];
    let selC = null, selO = null;
    const fd = (d) => (d && new Date(d).getFullYear() >= 1900 ? TR.util.fmtDate(d) : '');
    const kitTxt = (k) => (k > 0 ? String(k) : '');
    const m = ui.modal({
      title: 'Campaigns', width: 760,
      body: () => {
        const c = camps[selC];
        const nodes = c ? c.operations.filter((o) => o.nodeIdentifier) : [];
        const kits = c ? c.operations.filter((o) => o.kitPartNumber > 0) : [];
        return h('div', null,
          h('div', { class: 'row' }, h('strong', null, left.product.chassisString()), h('span', { class: 'spacer' }), c && (nodes.length || kits.length) ? h('button', { class: 'btn primary small', onClick: () => runCampaign(c, nodes, kits) }, 'Run campaign ►') : null),
          h('table', { class: 'grid' }, h('thead', null, h('tr', null, ['SCC No', 'Description', 'Performed', 'Status'].map((x) => h('th', null, x)))), h('tbody', null, camps.map((x, i) => h('tr', { class: ['clickable', i === selC && 'selected'], onClick: () => { selC = i; selO = null; m.render(); } }, h('td', null, x.sccNo), h('td', null, x.description), h('td', null, fd(x.performed)), h('td', null, x.status))))),
          c ? h('div', { class: 'camp-details' }, h('div', null, 'Performing Dealer Id: ', c.performingDealerId || '', '    Repairing Importer Id: ', c.repairingImporterId || ''),
            h('div', { class: 'collection-title' }, 'Operations:'),
            h('table', { class: 'grid' }, h('thead', null, h('tr', null, ['No', 'Description', 'Kit', 'Node', 'Performed', 'Status'].map((x) => h('th', null, x)))), h('tbody', null, c.operations.map((o, i) => h('tr', { class: ['clickable', i === selO && 'selected'], onClick: () => { selO = i; m.render(); } }, h('td', null, o.no), h('td', null, o.description), h('td', null, kitTxt(o.kitPartNumber)), h('td', null, o.nodeIdentifier ? M.derivedName(o.nodeIdentifier) : ''), h('td', null, fd(o.performed)), h('td', null, o.status))))),
            selO !== null ? h('div', { class: 'small' }, 'Dealer Id: ', c.operations[selO].dealerId || '', '    Country Code: ', c.operations[selO].dealerId || '') : null) : null);
      },
    });
    async function runCampaign(c, nodes, kits) {
      m.close();
      const product = left.getCurrentSelectedProduct();
      const ch = M.chassisOf(product);
      let r;
      if (kits.length) {
        const payload = { remoteRequest: 0, scenario: E.KitScenario.Introduced, onlyServiceKitAllowed: false, products: [product], conversionKitNumbers: [{ conversionKitNumber: String(kits[0].kitPartNumber), chassisSeries: ch.chassisSeries, chassisNumber: ch.chassisNumber }], simulationKitName: '', pblUpdateCapable: true };
        r = await app.run(() => TR.api('AftermarketRequest/RequestKit', { request: JSON.stringify(payload) }), `Running campaign ${c.sccNo}`);
        if (kits.length > 1) ui.summary.addError('Request failed. More than one Kit in Campaign.');
      } else {
        const payload = { softwareRequestOperation: E.SoftwareRequestOperation.Update, scenario: E.Scenario.Introduced, enableMultiNodeBehavior: true, remoteRequest: 0, allowLimitedValidation: false, pblUpdateCapable: true, products: [product], requestedNodes: nodes.map((o) => ({ nodeIdentifier: o.nodeIdentifier, previousEcuHardware: null, chassisSeries: ch.chassisSeries, chassisNumber: ch.chassisNumber })), simulationKitName: '', selectedLanguageCode: 'en-GB' };
        r = await app.run(() => TR.api('AftermarketRequest/RequestSoftware', { request: JSON.stringify(payload) }), `Running campaign ${c.sccNo}`);
      }
      if (!r.success) { ui.summary.addError('Request failed.'); app.refresh(); return; }
      const item = r.item[0];
      shell.right.setProducts([product], { deltas: { [TR.chassis.chassisKey(item)]: item.delta }, response: r.item, mode: 'product', vdaByChassis: { [TR.chassis.chassisKey(ch)]: left.productVda } });
      ui.summary.addInformation(`Campaign ${c.sccNo} applied to the right pane product.`);
      app.refresh();
    }
  }

  // ---------- VESPA2 ----------
  function paneState(p) {
    p.saveCurrentProductState();
    return { items: p.items.map((it) => ({ product: it.product, delta: it.delta, requestedNodes: it.requestedNodes, vda: it.vda })), selectedIndex: p.selectedIndex, request: p.request, response: p.response, responseXml: p.responseXml, availableUpdate: p.availableUpdate, requestOrProductXml: p.requestOrProductXml, xmlType: p.xmlType, mode: p.mode, src: p.src, sourceType: p.sourceType };
  }
  function getState() { return { left: paneState(shell.left), right: paneState(shell.right) }; }
  function loadFromState(s) {
    ['left', 'right'].forEach((k) => {
      const p = shell[k], st = s[k];
      if (!st) return;
      p.items = st.items || [];
      p.selectedIndex = st.selectedIndex;
      p.request = Object.assign(TR.defaultRequest(), st.request || {});
      p.response = st.response; p.responseVms = {}; p.responseXml = st.responseXml; p.availableUpdate = st.availableUpdate;
      p.requestOrProductXml = st.requestOrProductXml; p.xmlText = st.requestOrProductXml; p.xmlType = st.xmlType || 'request';
      p.src = st.src || p.src; p.sourceType = st.sourceType || p.sourceType;
      p.product.clear(); p.loadSelected();
      p.mode = st.mode;
      p.loadPermissions();
    });
  }
  async function editInVespa2(pane) {
    const r = await app.run(() => TR.api('TestRequest2000/PrepareForVespa2', { state: JSON.stringify({ shell: getState(), position: pane.position }), product: JSON.stringify(pane.product.get()) }), 'Waiting for VESPA2...');
    if (!r.success) return;
    vespa2Simulator(r.item);
  }
  function vespa2Simulator(data) {
    const cm = clone(data.communicationModel);
    const vars = cm.vars.slice();
    const notes = cm.s_notes.slice();
    const allVariants = TR.db.variants.filter((v) => v.authorizedProductClasses.includes(cm.pc));
    const listEditor = (title, list, ph, describe) => h('div', { class: 'vespa-list' }, h('div', { class: 'collection-title' }, title, ' ', h('button', { class: 'btn small', onClick: () => { list.push(''); m.render(); } }, 'add')),
      list.map((v, i) => h('div', { class: 'vespa-item' }, h('input', { key: `vespa-${title}-${i}`, size: 8, maxlength: title === 'variants' ? 6 : 8, class: 'upper', placeholder: ph, value: v, list: title === 'variants' ? 'vespa-vars' : null, onInput: (e) => { list[i] = e.target.value.toUpperCase(); }, onChange: () => m.render() }),
        h('span', { class: 'small muted' }, ' ', describe(list[i])), h('button', { class: 'icon-btn small danger', title: 'Delete', onClick: () => { list.splice(i, 1); m.render(); } }, '✕'))));
    const send = async (withSNotes) => {
      const spec = Object.assign({}, cm, { vars: vars.filter(Boolean), s_notes: withSNotes ? notes.filter(Boolean) : null });
      m.close();
      const qs = await app.run(() => TR.api('TestRequest2000Callback/Vespa2', { spec: JSON.stringify(spec) }), 'Receiving VESPA2 callback');
      if (qs.success) loadFromVespa2(qs.item);
    };
    const m = ui.modal({
      title: 'VESPA2 (simulated) – Vespa2 Simulator', width: 760, class: 'vespa2',
      body: () => h('div', null,
        h('p', { class: 'small muted' }, `In SW Configurator the specification is posted to ${data.postUrl} in a new window. VESPA2 then posts the edited specification back to `, h('code', null, 'TestRequest2000Callback/Vespa2'), ' which pushes it to this page.'),
        h('div', { class: 'row' }, h('button', { class: 'btn primary small', onClick: () => send(true) }, 'Send To SW Configurator'), h('button', { class: 'btn small', onClick: () => send(false) }, 'Send To SW Configurator without SNote')),
        h('div', { class: 'collection-title' }, 'Data Received:'),
        h('div', { class: 'vespa-fields' }, ['trans_id', 'user_id', 'pc', 'specification_date', 'assembly_date', 'chassis_series', 'chassis_number'].map((k) => h('label', null, k, h('input', { readOnly: true, value: String(cm[k]) })))),
        h('div', { class: 'vespa-lists' }, listEditor('variants', vars, 'IDVAR6', (v) => { const x = TR.db.variantByIdVar6(v); return x ? `${x.symbol} – ${x.description}` : v ? '(unknown)' : ''; }),
          listEditor('S-Notes', notes, 'S-Note', (v) => TR.db.sNoteName(v) || '')),
        h('datalist', { id: 'vespa-vars' }, allVariants.map((v) => h('option', { value: v.idVar6 }, `${v.symbol} – ${v.description}`))),
        h('pre', { class: 'xml-pre small' }, JSON.stringify(Object.assign({}, cm, { vars, s_notes: notes }), null, 2))),
    });
  }
  async function loadFromVespa2(qs) {
    const r = await app.run(() => TR.api('TestRequest2000/LoadTestRequestState', { id: qs.vespa2TransactionId }), 'Restoring test request state');
    if (!r.success) return;
    const st = JSON.parse(r.item);
    loadFromState(st.shell);
    const pane = shell[st.position];
    if (!pane.product.loaded()) return;
    const before = pane.product.current.productSpecification.variants.length;
    pane.product.mergeVariants(qs.variantSpec.filter((v) => v.symbol));
    if (qs.sNoteSpec) pane.product.mergeSNotes(qs.sNoteSpec);
    pane.mode = 'product';
    ui.summary.addInformation(`VESPA2 specification applied to ${pane.product.chassisString()} (${before} → ${pane.product.current.productSpecification.variants.length} variants${qs.sNoteSpec ? ', S-Notes merged' : ', S-Notes unchanged'}).`);
    app.refresh();
  }

  // ---------- settings & guide ----------
  function settingsPopup() {
    const st = TR.server.state.settings;
    const ctxs = TR.db.contexts;
    const toggleIn = (arr, v, on) => { const i = arr.indexOf(v); if (on && i < 0) arr.push(v); if (!on && i >= 0) arr.splice(i, 1); };
    ui.modal({
      title: 'Simulated user & permissions', width: 520,
      body: (m) => h('div', { class: 'form' },
        h('label', null, 'User ID', h('input', { key: 'set-user', class: 'upper', value: st.userId, onChange: (e) => { st.userId = e.target.value.trim().toUpperCase() || 'TESTUSER'; } })),
        h('div', { class: 'collection-title' }, 'Product editor permissions'),
        h('label', { class: 'chk block' }, h('input', { type: 'checkbox', checked: st.perms.updateVda, onChange: (e) => { st.perms.updateVda = e.target.checked; } }), ' VDA Writer (Update VDA) in the contexts checked below'),
        h('label', { class: 'chk block' }, h('input', { type: 'checkbox', checked: st.perms.save, onChange: (e) => { st.perms.save = e.target.checked; } }), ' Save product (StoreProduct)'),
        h('label', { class: 'chk block' }, h('input', { type: 'checkbox', checked: st.perms.toKit, onChange: (e) => { st.perms.toKit = e.target.checked; } }), ' To Kit (create / add to conversion kits)'),
        h('label', { class: 'chk block' }, h('input', { type: 'checkbox', checked: st.perms.configuratorTeam, onChange: (e) => { st.perms.configuratorTeam = e.target.checked; } }), ' Configurator team member (sees hidden parameter values)'),
        h('table', { class: 'grid' }, h('thead', null, h('tr', null, h('th', null, 'Context'), h('th', null, 'Read'), h('th', null, 'VDA write'))), h('tbody', null, ctxs.map((c) => h('tr', null, h('td', null, `${c.name} (${c.productClassIds.join(', ')})`),
          h('td', null, h('input', { type: 'checkbox', checked: st.readContexts.includes(c.id), onChange: (e) => toggleIn(st.readContexts, c.id, e.target.checked) })),
          h('td', null, h('input', { type: 'checkbox', checked: st.writeContexts.includes(c.id), onChange: (e) => toggleIn(st.writeContexts, c.id, e.target.checked) })))))),
        h('div', { class: 'small muted' }, 'Hidden parameters (e.g. P1CZZ, P1TGS, TEA2 LR/BAH) are encrypted and shown as N/A unless you are a Configurator team member or VDA writer for the context.'),
        h('div', { class: 'collection-title' }, 'Simulator data'),
        h('div', { class: 'small' }, `${TR.server.state.log.length} logged request(s) by you, ${TR.server.state.kits.length} conversion kits, ${Object.keys(TR.server.state.swc).length} saved SWC product(s). Data is kept in this browser's localStorage.`),
        h('button', { class: 'btn danger small', onClick: async () => { if (await ui.confirm('Reset all simulator data (VDA changes, kits, log, saved products, settings)?')) { TR.server.reset(); location.reload(); } } }, 'Reset simulator data')),
      buttons: [{ label: 'Close', primary: true, onClick: (m) => { TR.server.persist(); m.close(); shell.left.loadPermissions(); shell.right.loadPermissions(); app.refresh(); } }],
      onClose: () => { TR.server.persist(); app.refresh(); },
    });
  }

  function guidePopup() {
    const D = TR.db;
    const vda = Object.values(TR.server.state.vda);
    const dl = async (kind) => {
      if (kind === 'product') { const p = M.inflate(clone(TR.server.findVda({ chassisSeries: 'FH', chassisNumber: '123456' }))); TR.util.download('FH123456_product.xml', TR.xml.productToXml(p)); }
      if (kind === 'request') {
        const p = M.inflate(clone(TR.server.findVda({ chassisSeries: 'FH', chassisNumber: '123456' })));
        const model = Object.assign(TR.defaultRequest(), { selectedRequestType: 0, selectedSoftwareRequestOperation: 3, selectedScenario: 1, requestedNodes: [] });
        TR.util.download('SoftwareUpdateIntroducedWithFH123456.xml', TR.xml.requestToXml(0, { products: [p], requestedNodes: [], scenario: 1, softwareRequestOperation: 3, remoteRequest: 0, allowLimitedValidation: false, enableMultiNodeBehavior: true, pblUpdateCapable: true, selectedLanguageCode: 'en-GB', simulationKitName: '' }, model, { messageType: 'SoftwareRequest' }));
      }
      if (kind === 'params') TR.util.download('parameters.xml', TR.xml.parametersToXml([{ code: 'P1ALG', electricalArchitecture: 1, references: [{ code: 'VAL', value: '80' }] }, { code: 'P1BCX', electricalArchitecture: 1, references: [{ code: 'VAL', value: '10' }] }, { code: 'P1VML', electricalArchitecture: 1, references: [{ code: 'LOW', value: '40' }, { code: 'HIGH', value: '85' }] }]));
    };
    ui.modal({
      title: 'Test Request Tool – guide', width: 900, class: 'guide',
      body: h('div', null,
        h('p', null, 'This page simulates the SW Configurator ', h('strong', null, 'Test Request'), ' tool (TestRequest2000), the legacy ', h('strong', null, 'VCADS Test Request'), ' and ', h('strong', null, 'Compare Breakdown'), '. All server endpoints run in the browser against a mock database; open ', h('em', null, 'Server calls'), ' to inspect them.'),
        h('h4', null, 'Try these scenarios'),
        h('ol', { class: 'guide-list' },
          h('li', null, 'Left pane: VDA ', h('code', null, 'FH 123456'), ' → Load. Click ', h('em', null, 'Request'), ', type Software / Update / Introduced → ', h('em', null, 'Request ►'), '. The right pane shows the Response and the updated Product (changes highlighted). EMS shows a hardware-replacement warning.'),
          h('li', null, 'Tick only the ', h('code', null, '16.3.1 TECU'), ' node checkbox (requested node), run Update with scenario ', h('em', null, 'InProgress'), ' and Multi node behavior off → error: TECU needs a newer EMS. Turn it on to get EMS as a Dependent Node.'),
          h('li', null, 'Uncheck ', h('em', null, 'PBL update capable'), ' to block versions that need a new primary bootloader.'),
          h('li', null, 'Select a node (checkbox) and tick ', h('em', null, 'Replace hardware'), ', change the ECU hardware number, then run Repair: previousEcuHardware is sent.'),
          h('li', null, 'Conversion Kit request with kit ', h('code', null, '23187002'), ' (ADR) or ', h('code', null, '23187001'), ' (telematics); try scenario Released with ', h('code', null, '23187003'), ' (state Introduced) to get an error.'),
          h('li', null, 'Load ', h('code', null, 'FH 000042'), ' (EMS without NTP) and run Software / Resolve.'),
          h('li', null, 'EDB source ', h('code', null, 'VSS-12-345'), ' gives a specification without nodes → the request type defaults to Production Breakdown. Use ', h('em', null, 'Show source'), ' and ', h('em', null, 'Filter'), ' (e.g. variant ', h('code', null, 'TELM-DYN'), ') on the result.'),
          h('li', null, 'Edit the product (Edit mode, variants, S-Notes, parameters), then ', h('em', null, 'Compare VDA'), ', ', h('em', null, 'Update VDA'), ' → ', h('em', null, 'Send to VDA'), ', or ', h('em', null, 'To Kit'), ' → Create Kit / Add To Kit (try kit 23187004).'),
          h('li', null, h('em', null, 'History'), ' lists seeded NAMS/GeSP/PROTOM requests and your own test requests; Load puts the request left and the response right.'),
          h('li', null, h('em', null, 'Campaigns'), ' (left pane, FH 123456) runs a campaign software or kit request. ', h('em', null, 'VESPA2'), ' opens a simulated VESPA2 round trip. ', h('em', null, 'Request type Spare Cab'), ' uses CBR order ', h('code', null, '99850557'), '.')),
        h('h4', null, 'VDA products'),
        h('table', { class: 'grid small' }, h('thead', null, h('tr', null, ['Chassis', 'VIN', 'Product class', 'Model', 'Nodes', 'Notes'].map((x) => h('th', null, x)))), h('tbody', null, vda.map((p) => {
          const i = p.productSpecification.productInformation;
          return h('tr', null, h('td', null, h('code', null, `${i.chassisSeries} ${i.chassisNumber}`)), h('td', null, i.vin), h('td', null, i.productClassId), h('td', null, i.modelId), h('td', null, String(p.nodes.length)), h('td', null, (p.vdaCampaigns || []).length ? 'campaigns, BEA2 body node' : i.testStatus === 'Design' ? 'design status, EMS without NTP' : i.productClassId === 'RT' ? 'TEA2 only context' : p.nodes.some((n) => n.electricalArchitecture === 3) ? 'T3 HPC: VCM / CGW software packages' : ''));
        }))),
        h('h4', null, 'Other reference data'),
        ui.kv([['EDB specifications', Object.keys(D.edbSpecs).join(', ')], ['Conversion kits', TR.server.state.kits.map((k) => `${k.partNumber} ${k.name} (${k.state})`).join('; ')], ['Spare cab orders', Object.keys(D.spareCabOrders).join(', ')],
          ['Baseline identifiers', TR.util.uniq(D.baselines.map((b) => b.identifier)).join(', ')], ['Factories', D.factories.map((f) => `${f.code} ${f.name}`).join(', ')]]),
        h('h4', null, 'Sample files (for the File source, drag & drop and Import Parameters)'),
        h('div', { class: 'row' }, h('button', { class: 'btn small', onClick: () => dl('product') }, 'Product XML (FH 123456)'), h('button', { class: 'btn small', onClick: () => dl('request') }, 'Software request XML'), h('button', { class: 'btn small', onClick: () => dl('params') }, 'Parameters XML')),
        h('h4', null, 'URL parameters (TestRequestClassic)'),
        h('p', { class: 'small' }, h('code', null, '?chassisSeries=FH&chassisNumber=123456'), ' loads VDA into the left pane; add ', h('code', null, '&source=SWC'), ' to load the saved SWC product; ', h('code', null, '?transactionId=…'), ' / ', h('code', null, 'incomingMessageId'), ' / ', h('code', null, 'outgoingMessageId'), ' load from the request log; ', h('code', null, '?devMode'), ' enables localStorage buttons. Chassis parser self test: ', h('button', { class: 'link-btn small', onClick: () => { const r = TR.chassis.selfTest(); ui.alert(r.map((x) => `${x.ok ? '✔' : '✖'} "${x.input}" → ${x.actual}${x.ok ? '' : ` (expected ${x.expected})`}`).join('\n'), 'ChassisParser test vectors'); } }, 'run'))),
    });
  }

  // ---------- query string bootstrap (ShellViewModel.processQueryString) ----------
  async function processQueryString() {
    const series = params.get('chassisSeries'), number = params.get('chassisNumber');
    const source = (params.get('source') || '').toUpperCase();
    const chassis = series && number ? { chassisSeries: series, chassisNumber: number } : null;
    if (chassis && source !== 'SWC') {
      shell.left.src.series = series; shell.left.src.number = number;
      await shell.left.loadFromSource(false);
      return;
    }
    const logKeys = [['incomingMessageId', 'RequestLog/LoadByIncomingMessageId'], ['outgoingMessageId', 'RequestLog/LoadByOutgoingMessageId'], ['transactionId', 'RequestLog/LoadByTransactionId']];
    for (const [k, ep] of logKeys) {
      if (params.get(k)) {
        TR.server.ensureSeedLog();
        const r = await app.run(() => TR.api(ep, { [k]: params.get(k) }), 'Loading from request log');
        if (r.success) loadBoth(r.item, 'both');
        return;
      }
    }
    if (params.get('productUpdatesId')) {
      const pu = TR.server.state.productUpdates.find((x) => String(x.id) === params.get('productUpdatesId'));
      if (!pu) { ui.summary.addError('Failed to load product updates.'); app.refresh(); return; }
      const [s, n] = pu.chassis.split(' ');
      const r = await app.run(() => TR.api('VdaProduct/LoadFromVda', { chassis: { chassisSeries: s, chassisNumber: n } }), 'Loading product updates');
      if (!r.success) { ui.summary.addError('Failed to compare to VDA.'); return; }
      shell.left.applyLoaded(r.item, 'VDA', false);
      if (pu.assignProduct) shell.left.product.applyDelta(pu.assignProduct, false);
      app.refresh();
      return;
    }
    if (chassis && source === 'SWC') {
      const vda = await app.run(() => TR.api('VdaProduct/LoadFromVda', { chassis }), 'Loading product from VDA');
      if (!vda.success) return;
      shell.left.applyLoaded(vda.item, 'SWC', false);
      const swc = await app.run(() => TR.api('TestRequest2000/LoadSwcProductFromChassis', { chassis }), 'Loading SWC product');
      if (!swc.success) return;
      const d = await app.run(() => TR.api('TestRequest2000/GetDelta', { sourceJson: JSON.stringify(swc.item), targetJson: JSON.stringify(vda.item) }), 'Comparing SWC product with VDA');
      if (!d.success) return;
      shell.left.product.applyDelta(d.item, false);
      ui.summary.addInformation(swc.item.information);
      app.refresh();
    }
  }

  function init() {
    shell.left = new TR.Pane('left');
    shell.right = new TR.Pane('right');
    render();
    processQueryString().then(() => TR.testRequest?.deepLink?.());
  }

  TR.shellActions = { editInVespa2, loadBoth, getState, loadFromState, historyPopup, historyView, searchHistory, loadLog, campaignsPopup, guidePopup, settingsPopup, filterPopup };
  TR.shellInit = init;
})();
