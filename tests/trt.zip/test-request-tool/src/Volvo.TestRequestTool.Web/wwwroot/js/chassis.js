/* Port of Web.UI\Common\TestRequest2000\ChassisParser.cs */
(function () {
  'use strict';
  const TR = window.TR;

  const KNOWN_SERIES = ('A B D E H M N S T W X Y 0 2 6 8 9 C F G K 1 3 4 5 L R U Z 7 B0E B11R B12B B12M B13R B5LH B5RH B5TL B7R B8R B9L ' +
    'B9R B9S B9TL BXRC AC ACL ACM AMTNG AT CACL CH230 C2 C3 DK FB86 FB87 FB88 FE FE4 FE6 FE7 FLC FL10 FL10X FL12 FL4 FL6 FL7 FS10 ' +
    'FS7 F10 F12 F16 F4 F406 F407 F408 F6 F6S F609 F610 F611 F613 F614 F615 F616 F7 F85 F86 F87 F88 F89 G88 G89 L10 L12 L7 NE NL10 ' +
    'NL12 NL7S N10 N12 N7 TER TYLW VNL VNM VV003 VV004 VV006 VWC WAH WC WCA WCL WCM WCS WG WH WHE WHEB WHL WHLB WHM WHR WHS WIA WIL ' +
    'WIM WIS WX WXLL WXLM WXR WXT RIG').split(' ');
  // Stable sort by length descending (same as OrderByDescending(s => s.Length)).
  const SORTED = KNOWN_SERIES.map((s, i) => [s, i]).sort((a, b) => b[0].length - a[0].length || a[1] - b[1]).map((x) => x[0]);

  function create(series, number) {
    const s = series.substring(0, 5);
    const n = number.substring(0, 6).padStart(6, '0');
    return { chassisSeries: s, chassisNumber: n };
  }

  function parse(input) {
    if (input == null) throw new Error('Value cannot be null. Parameter name: input');
    input = String(input).toUpperCase().trim();
    let m = /^([A-Z,0-9]+)[\s-]+([0-9]+)$/.exec(input);
    if (m) return create(m[1], m[2]);
    input = input.replace(/[^A-Z,0-9]/g, '');
    for (const s of SORTED) {
      if (s.length < input.length && input.length - s.length <= 6 && input.startsWith(s) && /^[0-9]+$/.test(input.substring(s.length))) {
        return create(s, input.substring(s.length));
      }
    }
    m = /^(.+?)([0-9]{1,6})$/.exec(input);
    if (m) return create(m[1], m[2]);
    return { chassisSeries: input.substring(0, 5), chassisNumber: '' };
  }

  /** Test vectors from ChassisParserTest.cs - run TR.chassis.selfTest() in the console. */
  const VECTORS = [
    [' A  1 ', 'A', '000001'], ['B 123 456', 'B', '123456'], ['B 123 456 78', 'B12', '345678'], ['B1234567 12345678', 'B1234', '123456'],
    ['F40612345', 'F406', '012345'], ['F4061', 'F406', '000001'], ['F407', 'F4', '000007'], ['F-407', 'F', '000407'],
    ['F40 - 7', 'F40', '000007'], ['F407-', 'F4', '000007'], ['VV00618947', 'VV006', '018947'], ['-NAM--ST-3-4', 'NAMST', '000034'],
    ['', '', ''], ['!!!!', '', ''], ['C0476693870', 'C0476', '693870'],
  ];
  function selfTest() {
    return VECTORS.map(([i, s, n]) => {
      const r = parse(i);
      return { input: i, expected: `${s}|${n}`, actual: `${r.chassisSeries}|${r.chassisNumber}`, ok: r.chassisSeries === s && r.chassisNumber === n };
    });
  }

  const sameChassis = (a, b) => !!a && !!b && String(a.chassisSeries || '').trim().toUpperCase() === String(b.chassisSeries || '').trim().toUpperCase() &&
    parseInt(a.chassisNumber, 10) === parseInt(b.chassisNumber, 10);
  const chassisKey = (c) => (c ? `${String(c.chassisSeries || '').trim().toUpperCase()}|${parseInt(c.chassisNumber, 10) || 0}` : '');

  TR.chassis = { parse, selfTest, sameChassis, chassisKey, KNOWN_SERIES };
})();
