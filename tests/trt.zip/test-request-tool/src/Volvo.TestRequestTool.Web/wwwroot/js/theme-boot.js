/* Runs in <head> before anything paints. Written in plain ES5 so it runs in any browser, even one too old for the app.
 *
 *  1. Theme, motion and text size from the saved settings, so the page never flashes the wrong theme (from DocGen Explorer).
 *  2. Browser features: detected, never guessed from the browser's name. Each one becomes an attribute on <html>
 *     (data-cap-colormix="no" and so on) that the stylesheets adapt to, and window.TRCaps for scripts.
 *  3. A start-up guard: a browser that is too old gets a clear page instead of a broken one, and an error during start-up
 *     shows a recovery screen (reload, reset settings) instead of a blank or frozen page. */
(function () {
  'use strict';
  var root = document.documentElement;
  function read(key, fallback) { try { var raw = localStorage.getItem(key); return raw == null ? fallback : JSON.parse(raw); } catch (e) { return fallback; } }
  function media(q) { try { return !!(window.matchMedia && window.matchMedia(q).matches); } catch (e) { return false; } }

  // ------------------------------------------------------------------ 1. theme, motion, text size
  var RETIRED = { clay: 'charcoal-light', light: 'charcoal-light', night: 'charcoal' };
  var choice = RETIRED[read('trstudio.theme', 'auto')] || read('trstudio.theme', 'auto');
  if (['auto', 'charcoal-light', 'charcoal'].indexOf(choice) < 0) choice = 'auto';
  root.setAttribute('data-theme', choice === 'auto' ? (media('(prefers-color-scheme: dark)') ? 'charcoal' : 'charcoal-light') : choice);
  root.setAttribute('data-theme-choice', choice);
  root.setAttribute('data-motion', read('trstudio.motion', 'on') === 'off' || media('(prefers-reduced-motion: reduce)') ? 'reduced' : 'full');
  root.setAttribute('data-text-size', read('trstudio.textSize', 'default'));

  // ------------------------------------------------------------------ 2. features
  function css(prop, value) { try { return !!(window.CSS && CSS.supports && CSS.supports(prop, value)); } catch (e) { return false; } }
  var storage = (function () { try { localStorage.setItem('trstudio.__probe', '1'); localStorage.removeItem('trstudio.__probe'); return true; } catch (e) { return false; } })();
  var caps = {
    colormix: css('color', 'color-mix(in srgb, red 50%, blue)'),
    backdrop: css('backdrop-filter', 'blur(2px)') || css('-webkit-backdrop-filter', 'blur(2px)'),
    container: css('container-type', 'inline-size'),
    has: css('selector(:has(a))', '') || (function () { try { document.querySelector(':has(a)'); return true; } catch (e) { return false; } })(),
    viewTransitions: typeof document.startViewTransition === 'function',
    speech: typeof window.speechSynthesis !== 'undefined' && typeof window.SpeechSynthesisUtterance === 'function',
    serverEvents: typeof window.EventSource === 'function',
    intlZones: !!(window.Intl && typeof Intl.supportedValuesOf === 'function'),
    observers: typeof window.ResizeObserver === 'function' && typeof window.IntersectionObserver === 'function' && typeof window.MutationObserver === 'function',
    storage: storage,
    touch: media('(pointer: coarse)'),
    hover: media('(hover: hover)'),
    forcedColors: media('(forced-colors: active)'),
    highContrast: media('(prefers-contrast: more)'),
    saveData: !!(navigator.connection && navigator.connection.saveData),
  };
  // The app's scripts use modern JavaScript (optional chaining, class fields, Array.prototype.at …). Script syntax cannot
  // be tested here without eval (the security policy forbids it), so built-ins from the same browser generations stand in:
  // a browser with all of these also parses the app.
  var modern = typeof Array.prototype.at === 'function' && typeof Object.hasOwn === 'function' && typeof String.prototype.replaceAll === 'function'
    && typeof Promise.allSettled === 'function' && typeof window.fetch === 'function' && typeof window.queueMicrotask === 'function' && typeof window.structuredClone === 'function';
  caps.modern = modern;
  for (var k in caps) if (Object.prototype.hasOwnProperty.call(caps, k)) root.setAttribute('data-cap-' + k.toLowerCase(), caps[k] ? 'yes' : 'no');

  // The browser's name and version, for messages only. Behaviour always follows the features above.
  var ua = navigator.userAgent || '', name = 'your browser', engine = 'other', m;
  if ((m = ua.match(/Edg\/(\d+)/))) { name = 'Microsoft Edge ' + m[1]; engine = 'chromium'; }
  else if ((m = ua.match(/OPR\/(\d+)/))) { name = 'Opera ' + m[1]; engine = 'chromium'; }
  else if ((m = ua.match(/Firefox\/(\d+)/))) { name = 'Firefox ' + m[1]; engine = 'gecko'; }
  else if ((m = ua.match(/Chrome\/(\d+)/))) { name = 'Chrome ' + m[1]; engine = 'chromium'; }
  else if ((m = ua.match(/Version\/(\d+[.\d]*).*Safari/))) { name = 'Safari ' + m[1]; engine = 'webkit'; }
  root.setAttribute('data-engine', engine);
  window.TRCaps = { features: caps, browser: name, engine: engine };

  // ------------------------------------------------------------------ 3. start-up guard
  var started = false, shown = false, errors = [];
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function screen(kind, detail) {
    if (shown) return; shown = true;
    var app = document.getElementById('app');
    if (!app) return;
    var old = kind === 'old';
    app.innerHTML =
      '<main class="boot-card" role="alert">' +
      '<div class="boot-mark" aria-hidden="true"></div>' +
      '<h1>' + (old ? 'This browser is too old for Test Request Tool' : kind === 'slow' ? 'Test Request Tool is taking long to start' : 'Test Request Tool could not start') + '</h1>' +
      '<p>' + (old ? 'You are using ' + esc(name) + '. Please update it, or use a current version of Microsoft Edge, Chrome, Firefox or Safari.'
        : kind === 'slow' ? 'The page has not finished loading. The network may be slow, or something blocked a script.'
        : 'Something went wrong while the page was loading. Your work on the server is safe.') + '</p>' +
      (detail ? '<details><summary>Details</summary><pre>' + esc(detail) + '</pre><p>Browser: ' + esc(name) + '</p></details>' : '') +
      '<div class="boot-actions">' +
      (old ? '' : '<button type="button" class="boot-btn primary" data-boot="reload">Reload</button>' +
        '<button type="button" class="boot-btn" data-boot="reset">Reset my settings and reload</button>') +
      '<a class="boot-btn ghost" href="/error.html?code=500">More help</a></div></main>';
    app.addEventListener('click', function (e) {
      var b = e.target && e.target.getAttribute && e.target.getAttribute('data-boot');
      if (b === 'reload') location.reload();
      if (b === 'reset') {
        // Damaged saved settings are a common reason a page will not start: remove this app's keys only.
        try { for (var i = localStorage.length - 1; i >= 0; i--) { var key = localStorage.key(i); if (key && key.indexOf('trstudio.') === 0) localStorage.removeItem(key); } } catch (x) { /* storage blocked */ }
        location.reload();
      }
    });
  }
  window.TRBoot = {
    /** Called once the first screen has rendered (boot.js). */
    ready: function () { started = true; root.setAttribute('data-booted', 'yes'); },
    fail: function (message) { if (!started) screen('error', message); },
    errors: errors,
  };
  if (!modern) {
    root.setAttribute('data-unsupported', 'yes');
    document.addEventListener('DOMContentLoaded', function () { screen('old', ''); });
    // The app's scripts will not run here; their syntax errors are expected and must not replace the message.
    window.addEventListener('error', function (e) { if (e && e.preventDefault) e.preventDefault(); }, true);
    return;
  }
  window.addEventListener('error', function (e) {
    if (started || !e || !e.message) return;   // resource errors (images) have no message
    errors.push(e.message + (e.filename ? ' (' + e.filename.replace(location.origin, '') + ':' + e.lineno + ')' : ''));
    screen('error', errors.join('\n'));
  });
  window.addEventListener('unhandledrejection', function (e) {
    if (started) return;
    var r = e && e.reason;
    errors.push('Unhandled: ' + (r && r.message ? r.message : String(r)));
    screen('error', errors.join('\n'));
  });
  // Nothing on screen after 15 s: say so, with the same ways out.
  setTimeout(function () { if (!started) screen('slow', errors.join('\n')); }, 15000);
})();
