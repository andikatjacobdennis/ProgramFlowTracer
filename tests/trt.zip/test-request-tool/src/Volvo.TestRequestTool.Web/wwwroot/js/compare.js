/* Compare breakdown (Views\TestRequest2000\Compare.cshtml + Shells\CompareBreakdown\App.ts), in the journey design:
 * "See what changed." Two specifications, A (original, the baseline) and B (comparison), each from EDB (specification id)
 * or VDA (chassis), with variants to add and an optional override week; or one specification on its own. The engine's
 * diff tree (engine.js compareBreakdown) becomes counts (added, removed, modified, unchanged — counted on B against A),
 * a Visual diff (components to include, the differences one page at a time, the selected change in detail), a Table of
 * every change and the Source of both products. Filters by variant code and part number; differences only; source info.
 * A difference is not a compatibility result: that needs a validation. */
(function () {
  'use strict';
  const TR = window.TR;
  const E = TR.enums;
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));

  const sel = () => ({ sourceType: 'EDB', specId: '', series: '', number: '', variantsToAdd: '', overriddenSpecWeek: '', open: false });
  const st = {
    single: false, left: Object.assign(sel(), { specId: 'VSS-12-345' }), right: Object.assign(sel(), { sourceType: 'VDA', series: 'FH', number: '123456' }),
    variantFilter: '', partFilter: '', applied: { variants: '', parts: '' }, diffOnly: true, showSource: false, result: null, expanded: new Set(['root']), selectedPath: null,
    tab: 'visual', kind: '', page: 0, size: 6, excluded: new Set(), compq: '', busy: false,
  };
  // The engine names kinds from A's side ('Add' = only in A); the page counts B against A, as people read a comparison.
  const KIND = { Remove: 'added', Add: 'removed', Change: 'modified', Equal: 'unchanged' };
  const KIND_LABEL = { added: 'Added', removed: 'Removed', modified: 'Modified', unchanged: 'Unchanged' };

  function toInput(s) {
    const variantsToAdd = TR.util.splitList(s.variantsToAdd, /[,\s]+/).map((v) => ({ symbol: v.toUpperCase() }));
    const base = { variantsToAdd, overriddenSpecWeek: s.overriddenSpecWeek.trim() || null };
    return s.sourceType === 'EDB' ? Object.assign(base, { specId: s.specId.trim() }) : Object.assign(base, { chassisSeries: s.series.trim(), chassisNumber: s.number.trim() });
  }
  async function compare() {
    if (st.busy) return;
    st.busy = true; TR.app.refresh();
    const r = await TR.app.run(() => TR.api('TestRequest2000/Compare', { left: toInput(st.left), right: st.single ? null : toInput(st.right) }), st.single ? 'Loading product' : 'Comparing products');
    st.busy = false;
    if (!r.success) { TR.app.refresh(); return; }
    st.result = r.item; st.page = 0; st.kind = ''; st.excluded = new Set(); st.selectedPath = null;
    const first = leaves(st.result.diff).find((l) => l.kind !== 'unchanged');
    if (first) st.selectedPath = first.path;
    TR.announce && TR.announce(t('Comparison complete.'));
    TR.app.refresh();
  }
  function swap() { const a = st.left; st.left = st.right; st.right = a; st.result = null; TR.app.refresh(); }

  // ------------------------------------------------------------------ the diff as rows (exported for tests)
  /** Every leaf of the diff tree with its path, parent group, component (top-level part) and kind. */
  function leaves(root) {
    const out = [];
    const walk = (n, path, trail) => {
      const p = path ? path + '/' + n.key : 'root';
      if (n.children && n.children.length) n.children.forEach((c) => walk(c, p, trail.concat(n.key)));
      else out.push({ path: p, key: n.key, parent: trail[trail.length - 1] || '', component: componentOf(trail.concat(n.key)), source: n.source, target: n.target, kind: KIND[n.type] || 'unchanged', meta: n.meta || {} });
    };
    walk(root, '', []);
    return out;
  }
  /** The component a change belongs to: a node name, "Parameters", "Variants", "Specification" or "Vehicle". */
  function componentOf(trail) {
    const [, top, second] = trail;
    if (top === 'Nodes') return second || 'Nodes';
    if (top === 'Parameters') return 'Parameters';
    if (top === 'ProductSpecification') return second === 'Variants' ? 'Variants' : second === 'SNotes' ? 'S-Notes' : 'Specification';
    return 'Vehicle';
  }
  function counts(list) { const c = { added: 0, removed: 0, modified: 0, unchanged: 0 }; list.forEach((l) => { c[l.kind]++; }); return c; }
  function passes(l) {
    const vf = TR.util.splitList(st.applied.variants).map((x) => x.toUpperCase());
    const pf = TR.util.splitList(st.applied.parts);
    const m = l.meta;
    if (vf.length) {
      const c = m.sourceInfo && m.sourceInfo.condition;
      const vs = [].concat(c && c.variants ? c.variants : [], m.variant ? [m.variant] : []).map((x) => String(x).toUpperCase());
      if (!vs.some((v) => vf.includes(v))) return false;
    }
    if (pf.length && !(pf.includes(String(m.partNumber)) || (m.sourceInfo && pf.includes(String(m.sourceInfo.itemNumber))))) return false;
    return true;
  }
  function shown(all) {
    return all.filter((l) => !st.excluded.has(l.component) && passes(l) && (st.single || !st.diffOnly || l.kind !== 'unchanged') && (!st.kind || l.kind === st.kind));
  }
  const fmt = (v) => (v === null || v === undefined || v === '' ? t('Not present') : String(v));

  // ------------------------------------------------------------------ pieces
  function specCard(s, letter, title, sub, product) {
    const set = (k) => (e) => { s[k] = e.target.value; };
    const info = product && product.productSpecification && product.productSpecification.productInformation;
    return h('section', { class: 'jr-card cb-spec', 'aria-label': t(title) },
      h('header', { class: 'cb-spec-head' }, h('span', { class: 'cb-letter', 'aria-hidden': 'true' }, letter), h('div', null, h('h2', null, t(title)), h('p', null, t(sub)))),
      h('div', { class: 'cb-spec-form' },
        h('span', null, t('Source')), h('div', { class: 'cb-radios', role: 'radiogroup', 'aria-label': t('{s}: source', { s: t(title) }) }, ['EDB', 'VDA'].map((x) => h('label', null,
          h('input', { type: 'radio', name: 'cb-src-' + letter, checked: s.sourceType === x, onChange: () => { s.sourceType = x; TR.app.refresh(); } }), x))),
        s.sourceType === 'EDB'
          ? [h('label', { for: 'cb-spec-' + letter }, t('Specification ID')), h('input', { id: 'cb-spec-' + letter, value: s.specId, list: 'edb-specs', placeholder: 'VSS-12-345', onInput: set('specId') })]
          : [h('span', null, t('Chassis')), h('div', { class: 'cb-chassis' }, h('input', { class: 'upper', 'aria-label': t('Chassis series'), placeholder: 'FH', value: s.series, onInput: set('series') }), h('input', { 'aria-label': t('Chassis number'), placeholder: '123456', inputmode: 'numeric', value: s.number, onInput: set('number') }))],
        h('label', { for: 'cb-var-' + letter }, t('Variants')), h('input', { id: 'cb-var-' + letter, class: 'upper', placeholder: t('None (comma separated)'), value: s.variantsToAdd, onInput: set('variantsToAdd') }),
        h('label', { for: 'cb-week-' + letter }, t('Override week')), h('input', { id: 'cb-week-' + letter, inputmode: 'numeric', placeholder: t('Not set (optional) · YYYYWW'), value: s.overriddenSpecWeek, onInput: set('overriddenSpecWeek') })),
      h('div', { class: 'cb-tile', 'aria-label': t('Loaded specification') }, TR.icon('file', 24), h('strong', null, s.sourceType),
        h('span', null, s.sourceType === 'EDB' ? s.specId || '—' : (s.series + ' ' + s.number).trim() || '—'),
        h('small', { class: 'muted' }, info ? t('Week {w}', { w: s.overriddenSpecWeek || info.introductionWeek || '—' }) : t('Not loaded yet'))));
  }
  function countsBar(c) {
    const item = (k, sym, tone) => h('button', { type: 'button', class: ['cb-count', 'tone-' + tone, st.kind === k ? 'is-on' : ''], 'aria-pressed': String(st.kind === k), onClick: () => { st.kind = st.kind === k ? '' : k; if (k === 'unchanged') st.diffOnly = false; st.page = 0; TR.app.refresh(); } },
      h('i', { 'aria-hidden': 'true' }, sym), h('span', null, h('strong', null, String(c[k])), t(KIND_LABEL[k]).toLowerCase()));
    return h('section', { class: 'jr-card cb-counts', 'aria-label': t('Change counts') },
      h('div', null, h('strong', null, t(st.single ? 'Specification loaded' : 'Comparison')), h('p', { class: 'muted jr-small' }, t(st.single ? 'Every value of the specification.' : 'Change counts for the selected specifications (B against A).'))),
      item('added', '+', 'good'), item('removed', '−', 'neutral'), item('modified', '✎', 'modified'), item('unchanged', '=', 'neutral'));
  }
  function componentsPanel(all) {
    const byComp = new Map();
    all.forEach((l) => { if (!byComp.has(l.component)) byComp.set(l.component, []); byComp.get(l.component).push(l); });
    const groups = [...byComp.entries()].filter(([c]) => !st.compq || c.toLowerCase().includes(st.compq.toLowerCase()));
    const kindOf = (list) => (list.some((l) => l.kind === 'modified') ? 'modified' : list.some((l) => l.kind === 'added') ? 'added' : list.some((l) => l.kind === 'removed') ? 'removed' : 'unchanged');
    return h('div', { class: 'cb-components' },
      h('h3', null, t('Components ({n})', { n: byComp.size })),
      J().search('Search components…', st.compq, (v) => { st.compq = v; J().later(() => TR.app.refresh(), 150); }),
      h('ul', { class: 'cb-tree', 'aria-label': t('Components to include') }, groups.map(([c, list]) => {
        const changed = list.filter((l) => l.kind !== 'unchanged').length;
        return h('li', null, h('label', null, h('input', { type: 'checkbox', checked: !st.excluded.has(c), onChange: (e) => { if (e.target.checked) st.excluded.delete(c); else st.excluded.add(c); st.page = 0; TR.app.refresh(); } }),
          h('span', { class: 'cb-group' }, c), h('small', { class: 'muted' }, changed ? '(' + changed + ')' : ''), h('i', { class: 'cb-dot k-' + kindOf(list), 'aria-hidden': 'true' }), h('span', { class: 'nv-sr' }, t(KIND_LABEL[kindOf(list)]))));
      })),
      h('div', { class: 'jr-stack-row' }, h('button', { class: 'jr-link', onClick: () => { st.excluded = new Set(); TR.app.refresh(); } }, t('All')), h('button', { class: 'jr-link', onClick: () => { st.excluded = new Set(byComp.keys()); TR.app.refresh(); } }, t('None'))));
  }
  const specName = (s) => (s.sourceType === 'EDB' ? s.specId : (s.series + ' ' + s.number).trim()) + ' · ' + s.sourceType + (s.overriddenSpecWeek ? ' · ' + t('Week {w}', { w: s.overriddenSpecWeek }) : '');
  function differences(list) {
    const pages = Math.max(1, Math.ceil(list.length / st.size)); st.page = Math.min(st.page, pages - 1);
    const page = list.slice(st.page * st.size, (st.page + 1) * st.size);
    const go = (d) => { st.page = Math.max(0, Math.min(pages - 1, st.page + d)); TR.app.refresh(); };
    return h('div', { class: 'cb-diffs' },
      h('div', { class: 'cb-diffs-head' }, h('h3', null, t(st.single ? 'Configuration' : 'Configuration differences')),
        h('span', { class: 'cb-pager' }, h('span', { class: 'muted', role: 'status' }, list.length ? t('Showing {a}–{b} of {n} changes', { a: st.page * st.size + 1, b: Math.min(list.length, (st.page + 1) * st.size), n: list.length }) : ''),
          h('button', { class: 'ap-icon-btn', 'aria-label': t('Previous page'), disabled: st.page === 0, onClick: () => go(-1) }, TR.icon('left', 16)),
          h('button', { class: 'ap-icon-btn', 'aria-label': t('Next page'), disabled: st.page >= pages - 1, onClick: () => go(1) }, TR.icon('right', 16)))),
      !st.single ? h('div', { class: 'cb-cols cb-cols-head', 'aria-hidden': 'true' }, h('span'), h('span'), h('span', null, h('strong', null, t('Original specification (A)')), specName(st.left)), h('span'), h('span', null, h('strong', null, t('Comparison specification (B)')), specName(st.right)), h('span')) : null,
      list.length ? h('div', { role: 'list', 'aria-label': t('Differences') }, page.map((l) => h('button', { role: 'listitem', class: ['cb-diff', 'cb-cols', st.selectedPath === l.path ? 'is-sel' : ''], 'aria-pressed': String(st.selectedPath === l.path),
        'aria-label': t('{c} {k}: {a} to {b}, {s}', { c: l.parent, k: l.key, a: fmt(l.source), b: fmt(l.target), s: t(KIND_LABEL[l.kind]) }), onClick: () => { st.selectedPath = l.path; TR.app.refresh(); } },
        h('span', { 'aria-hidden': 'true' }, TR.icon(l.component === 'Parameters' ? 'sliders' : l.component === 'Variants' || l.component === 'Specification' ? 'file' : 'box', 18)),
        h('span', null, h('strong', null, l.component !== l.key ? l.component : l.key), h('small', null, l.key + (l.parent && l.parent !== l.component ? ' · ' + l.parent : ''))),
        h('span', null, fmt(l.source), st.showSource && l.meta.sourceInfo ? h('small', null, TR.editors.sourceText(l.meta.sourceInfo)) : null),
        st.single ? h('span') : h('span', { class: 'cb-arrow', 'aria-hidden': 'true' }, '→'),
        st.single ? h('span') : h('span', null, fmt(l.target)),
        st.single ? h('span') : h('span', { class: 'cb-kind k-' + l.kind }, t(KIND_LABEL[l.kind]))))) : J().empty('No differences match', 'Change the filters or include more components.'));
  }
  const MEANING = {
    modified: 'The value differs between these specifications.', added: 'Present in B only: the comparison specification adds it.',
    removed: 'Present in A only: the comparison specification no longer has it.', unchanged: 'The same in both specifications.',
  };
  function details(all) {
    const l = all.find((x) => x.path === st.selectedPath);
    if (!l) return h('aside', { class: 'cb-details' }, h('h3', null, t('Change details')), h('p', { class: 'muted' }, t('Choose a difference.')));
    const notes = l.meta.notifications || [];
    const text = `${l.component} · ${l.key}: ${fmt(l.source)} → ${fmt(l.target)} (${t(KIND_LABEL[l.kind])})`;
    return h('aside', { class: 'cb-details', 'aria-label': t('Change details') },
      h('h3', null, t('Change details')),
      h('div', { class: 'jr-side-title' }, h('span', null, h('strong', null, l.component), h('br'), h('small', { class: 'muted' }, l.key)), st.single ? null : h('span', { class: 'cb-kind k-' + l.kind }, t(KIND_LABEL[l.kind]))),
      h('div', { class: 'cb-detail-vals' }, h('label', null, t(st.single ? 'Value' : 'Original value (A)'), h('input', { readonly: true, value: fmt(l.source) })), st.single ? null : h('label', null, t('Compared value (B)'), h('input', { readonly: true, value: fmt(l.target) }))),
      h('p', { class: 'cb-path' }, l.path.replace(/^root\//, '').split('/').join(' › ')),
      st.single ? null : h('div', { class: 'lg-means' }, h('strong', null, TR.icon('info', 14), ' ', t('Meaning')), h('p', null, t(MEANING[l.kind]))),
      st.single ? null : J().banner('warning', 'alert', t('A difference is not a compatibility result.')),
      l.meta.sourceInfo ? h('p', { class: 'muted jr-small' }, t('Source: {s}', { s: TR.editors.sourceText(l.meta.sourceInfo) })) : null,
      notes.length ? h('ul', { class: 'jr-list' }, notes.map((n) => h('li', null, n.severity === 0 ? J().chip('blocked', t('Error')) : J().chip('warning'), ' ', n.message || n.text || ''))) : null,
      h('h3', { class: 'jr-h4' }, t('Actions')),
      h('div', { class: 'jr-stack-row' },
        TR.pages.ui.button(t('Show in table'), 'external', () => { st.tab = 'table'; TR.app.refresh(); setTimeout(() => { const r = document.querySelector('[data-path="' + CSS.escape(l.path) + '"]'); if (r) { r.scrollIntoView({ block: 'center' }); r.classList.add('flash'); } }, 30); }, 'secondary'),
        TR.pages.ui.button(t('Copy difference'), 'copy', () => J().copy(text, 'Difference'), 'text')));
  }
  function table(list) {
    return list.length ? h('div', { class: 'jr-table-wrap' }, h('table', { class: 'jr-table' },
      h('thead', null, h('tr', null, [t('Component'), t('Item'), t(st.single ? 'Value' : 'Original (A)'), st.single ? null : t('Comparison (B)'), st.single ? null : t('Change')].filter(Boolean).map((c) => h('th', null, c)))),
      h('tbody', null, list.map((l) => h('tr', { 'data-path': l.path, class: st.selectedPath === l.path ? 'is-sel' : '', onClick: () => { st.selectedPath = l.path; st.tab = 'visual'; TR.app.refresh(); } },
        h('td', null, l.component), h('td', null, l.key, l.parent && l.parent !== l.component ? h('small', { class: 'muted' }, ' · ' + l.parent) : null), h('td', null, h('code', null, fmt(l.source))),
        st.single ? null : h('td', { class: l.kind !== 'unchanged' ? 'jr-proposed' : '' }, h('code', null, fmt(l.target))), st.single ? null : h('td', null, h('span', { class: 'cb-kind k-' + l.kind }, t(KIND_LABEL[l.kind])))))))) : J().empty('No differences match', 'Change the filters.');
  }
  function source(r) {
    const pre = (title, p) => h('div', null, h('h3', { class: 'jr-h4' }, t(title)), h('pre', { class: 'jr-pre', tabindex: '0', 'aria-label': t(title) }, JSON.stringify(p, null, 2)));
    return h('div', { class: 'jr-grid2' }, pre('Original specification (A)', r.sourceProduct), st.single ? null : pre('Comparison specification (B)', r.targetProduct));
  }
  function exportCsv(all) {
    const rows = [['Component', 'Item', 'Path', 'Original (A)', 'Comparison (B)', 'Change']].concat(all.map((l) => [l.component, l.key, l.path, fmt(l.source), st.single ? '' : fmt(l.target), st.single ? '' : KIND_LABEL[l.kind]]));
    J().download('comparison.csv', J().csv(rows), 'text/csv');
  }
  const J = () => TR.journey;

  function render() {
    const r = st.result;
    const all = r ? leaves(r.diff) : [];
    const list = shown(all);
    const filterChanged = st.variantFilter !== st.applied.variants || st.partFilter !== st.applied.parts;
    return h('div', { class: 'jr-page cb-page' },
      h('div', { class: 'jr-head' }, h('div', null, h('h1', null, t('See what changed.')), h('p', { class: 'jr-sub' }, t(st.single ? 'Load one specification and explore its values.' : 'Compare two specifications, then explore the differences.'))),
        h('div', { class: 'jr-actions' },
          J().select('Mode', st.single ? 'single' : 'compare', [['compare', 'Compare two specifications'], ['single', 'Load one specification']], (v) => { st.single = v === 'single'; st.result = null; TR.app.refresh(); }),
          r ? TR.pages.ui.button(t('Export comparison'), 'download', () => exportCsv(all), 'secondary') : null,
          h('a', { class: 's-btn secondary', href: '/guide/#compare-breakdown', target: '_blank', rel: 'noopener' }, TR.icon('book', 17), t('Open guide')))),
      h('div', { class: ['cb-specs', st.single ? 'is-single' : ''] },
        specCard(st.left, 'A', 'Original specification', 'Source and specification used as the baseline.', r && r.sourceProduct),
        h('div', { class: 'cb-mid' },
          st.single ? null : h('button', { class: 'cb-swap', 'aria-label': t('Swap A and B'), 'data-tip': t('Swap A and B'), onClick: swap }, TR.icon('compare', 22)),
          TR.pages.ui.button(st.busy ? t('Working…') : t(st.single ? 'Load' : 'Compare'), 'arrow', compare, 'primary', { disabled: st.busy })),
        st.single ? null : specCard(st.right, 'B', 'Comparison specification', 'Source and specification to compare against.', r && r.targetProduct)),
      r ? countsBar(counts(all)) : null,
      r ? h('section', { class: 'jr-card cb-result' },
        h('div', { class: 'cb-toolbar' },
          h('div', { class: 'jr-tabs', role: 'tablist', 'aria-label': t('View') }, [['visual', 'Visual diff', 'compare'], ['table', 'Table', 'grid'], ['source', 'Source', 'file']].map(([k, l, icon]) => h('button', { role: 'tab', 'aria-selected': String(st.tab === k), class: st.tab === k ? 'is-on' : '', onClick: () => { st.tab = k; TR.app.refresh(); } }, TR.icon(icon, 16), t(l)))),
          h('span', { class: 'spacer' }),
          h('label', { class: 'jr-switch' }, h('input', { type: 'checkbox', role: 'switch', checked: st.showSource, onChange: (e) => { st.showSource = e.target.checked; TR.app.refresh(); } }), h('span', { class: 'jr-switch-track', 'aria-hidden': 'true' }), t('Show source')),
          st.single ? null : h('label', { class: 'jr-switch' }, h('input', { type: 'checkbox', role: 'switch', checked: st.diffOnly, onChange: (e) => { st.diffOnly = e.target.checked; st.page = 0; TR.app.refresh(); } }), h('span', { class: 'jr-switch-track', 'aria-hidden': 'true' }), t('Show differences only'))),
        st.tab !== 'source' ? h('div', { class: 'cb-filters' },
          h('label', null, t('Variant code'), h('input', { class: 'upper', list: 'cb-variants', placeholder: t('Enter variant code'), value: st.variantFilter, onInput: (e) => { st.variantFilter = e.target.value.toUpperCase(); } }),
            h('datalist', { id: 'cb-variants' }, TR.util.uniq([].concat(...[r.sourceProduct, r.targetProduct].filter(Boolean).map((p) => p.productSpecification.variants.map((v) => v.symbol)))).map((s) => h('option', { value: s })))),
          h('label', null, t('Part number'), h('input', { placeholder: t('Enter part number'), inputmode: 'numeric', value: st.partFilter, onInput: (e) => { st.partFilter = e.target.value; } })),
          TR.pages.ui.button(t('Apply filters'), null, () => { st.applied = { variants: st.variantFilter, parts: st.partFilter }; st.page = 0; TR.app.refresh(); }, 'secondary'),
          h('button', { class: 'jr-link', onClick: () => { st.variantFilter = st.partFilter = ''; st.applied = { variants: '', parts: '' }; st.kind = ''; st.excluded = new Set(); TR.app.refresh(); } }, t('Clear filters')),
          filterChanged ? h('small', { class: 'muted' }, t('Apply to use the new filters.')) : null) : null,
        st.tab === 'visual' ? h('div', { class: 'cb-visual' }, componentsPanel(all), differences(list), details(all)) : st.tab === 'table' ? table(list) : source(r)) : null,
      r ? h('div', { class: 'cb-status' }, h('span', null, TR.icon('check', 15), t(st.single ? 'Specification loaded' : 'Comparison complete')), h('span', { class: 'muted' }, TR.icon('info', 14), t('Results from the EDB specifications and the vehicle repository.')))
        : J().empty(st.single ? 'Load a specification' : 'Choose two specifications', t('EDB specifications: {l}; or a VDA chassis such as FH 123456.', { l: Object.keys(TR.db.edbSpecs).join(', ') })));
  }

  TR.compare = { render, state: st, leaves, counts, componentOf, KIND };
})();
