/* pane-view: one half of the Test Request split view (PaneViewModel + PaneView template). */
(function () {
  'use strict';
  const TR = window.TR;
  const E = TR.enums;
  const M = TR.model;
  const { h, clone } = TR.util;
  const ui = TR.ui;
  const run = (fn, text) => TR.app.run(fn, text);
  const ck = (p) => TR.chassis.chassisKey(M.chassisOf(p));

  function defaultRequest() {
    return {
      selectedRequestType: 0, selectedSoftwareRequestOperation: 3, selectedScenario: TR.prefs ? Number(TR.prefs.get('scenario')) : 1, selectedKitScenario: 1, selectedRemote: 0,
      allowLimitedValidation: false, enableMultiNodeBehavior: true, onlyServiceKitAllowed: false, pblUpdateCapable: true, selectedLanguageCode: 'en-GB',
      simulationKitName: '', conversionKitNumbers: [], selectedBaselineState: '', selectedBaseline: null, baselineIdentifier: '', baselineVersion: '',
      selectedFactory: '', introductionWeek: '', includePreReleasedSNotes: false, selectedActionCriteriaTypes: [], selectedSpareCabRequestedNodes: [],
      selectedSpareCabRemovedNodes: [], softwareRelatedHardwares: [], limitTo: '', extendedValidation: false, groupAdministrativeParameters: true,
    };
  }

  class Pane {
    constructor(position) {
      this.position = position;
      this.sourceType = 'VDA';
      this.src = { series: '', number: '', vin: '', specId: '' };
      this.items = [];
      this.selectedIndex = -1;
      this.product = new TR.ProductVM('product');
      this.request = defaultRequest();
      this.response = null;
      this.responseXml = null;
      this.responseVms = {};
      this.availableUpdate = null;
      this.requestOrProductXml = null;
      this.xmlText = null;
      this.xmlType = 'request';
      this.reportXml = null;
      this.reportType = 'product';
      this.vdaErrorReport = null;
      this.productDiff = new TR.ProductVM('diff');
      this.diffSource = 'other';
      this.diffOnlyDirty = true;
      this.vdaUpdateProduct = new TR.ProductVM('vda');
      this.vdaOnlyDirty = true;
      this.toKitProduct = new TR.ProductVM('tokit');
      this.mode = null;
      this.permissions = { UpdateVda: false, Save: false, ToKit: false };
      this.disableVdaUpdate = false;
    }
    other() { return TR.app.shell[this.position === 'left' ? 'right' : 'left']; }
    get productVda() { const it = this.items[this.selectedIndex]; return it ? it.vda || null : null; }
    set productVda(v) { const it = this.items[this.selectedIndex]; if (it) it.vda = v ? clone(v) : null; }

    // ---------- product list ----------
    saveCurrentProductState() {
      const it = this.items[this.selectedIndex];
      if (!it || !this.product.loaded()) return;
      it.product = this.product.getOriginal();
      it.delta = this.product.dirty() ? this.product.getDelta() : null;
      it.requestedNodes = this.product.requestedNodes();
      it.ui = this.product.ui;
    }
    loadSelected() {
      const it = this.items[this.selectedIndex];
      if (!it) { this.product.clear(); return; }
      this.product.load(it.product, { requestedNodes: it.requestedNodes });
      if (it.ui) { this.product.ui.expandedNodes = it.ui.expandedNodes; this.product.ui.sections = it.ui.sections; }
      if (it.delta) this.product.applyDelta(it.delta, false);
      this.product.ignoreServicePackChanges = false;
      this.refreshMatches();
    }
    selectProduct(i) {
      if (i === this.selectedIndex) return;
      this.saveCurrentProductState();
      this.selectedIndex = i;
      this.loadSelected();
      const o = this.other();
      if (o.items.length > 1 && !this._syncing) {
        const ch = M.chassisOf(this.items[i].product);
        const j = o.items.findIndex((x) => TR.chassis.sameChassis(M.chassisOf(x.product), ch));
        if (j >= 0 && j !== o.selectedIndex) { o._syncing = true; o.selectProduct(j); o._syncing = false; }
      }
      TR.app.refresh();
    }
    replaceOrAddProduct(product, delta, requestedNodes, vda) {
      const ch = M.chassisOf(product);
      let i = ch.chassisSeries ? this.items.findIndex((x) => TR.chassis.sameChassis(M.chassisOf(x.product), ch)) : -1;
      const item = { product: clone(product), delta: delta || null, requestedNodes: requestedNodes || [], vda: vda ? clone(vda) : null };
      if (i >= 0) this.items[i] = item; else { this.items.push(item); i = this.items.length - 1; }
      return i;
    }
    removeSelectedProduct() {
      if (this.items.length <= 1) return;
      const i = this.selectedIndex;
      this.items.splice(i, 1);
      this.selectedIndex = Math.max(0, i - 1);
      this.loadSelected();
      TR.app.refresh();
    }
    productsWithDeltas() {
      this.saveCurrentProductState();
      return this.items.map((it) => { const vm = new TR.ProductVM().load(it.product); if (it.delta) vm.applyDelta(it.delta, false); return vm.get(); });
    }
    getCurrentProducts() { return this.productsWithDeltas(); }
    getCurrentSelectedProduct() { const all = this.productsWithDeltas(); return all[this.selectedIndex] || null; }
    allRequestedNodes() { this.saveCurrentProductState(); return [].concat(...this.items.map((it) => it.requestedNodes || [])); }
    hasProduct() { return this.product.loaded(); }

    // ---------- state setters ----------
    setProducts(products, opts) {
      opts = opts || {};
      const prevVda = {};
      this.items.forEach((it) => { if (it.vda) prevVda[ck(it.product)] = it.vda; });
      this.items = (products || []).map((p) => ({
        product: clone(p), delta: opts.deltas ? opts.deltas[ck(p)] || null : null,
        requestedNodes: (opts.requestedNodes || []).filter((r) => !r.chassisSeries || TR.chassis.sameChassis(r, M.chassisOf(p))),
        vda: (opts.vdaByChassis && opts.vdaByChassis[ck(p)]) || prevVda[ck(p)] || null,
      }));
      this.selectedIndex = this.items.length ? 0 : -1;
      if (opts.selectChassis) { const j = this.items.findIndex((x) => TR.chassis.sameChassis(M.chassisOf(x.product), opts.selectChassis)); if (j >= 0) this.selectedIndex = j; }
      this.response = opts.response || null;
      this.responseVms = {};
      this.responseXml = opts.responseXml === undefined ? null : opts.responseXml;
      this.availableUpdate = opts.availableUpdate || null;
      if (this.availableUpdate) { this.items = []; this.selectedIndex = -1; }
      this.product.clear();
      this.loadSelected();
      if (opts.request) this.request = Object.assign(defaultRequest(), clone(opts.request));
      if (opts.requestXml !== undefined) { this.requestOrProductXml = opts.requestXml; this.xmlText = opts.requestXml; this.xmlType = opts.request ? 'request' : 'product'; }
      this.vdaErrorReport = null;
      this.vdaUpdateProduct.clear();
      this.productDiff.clear();
      this.toKitProduct.clear();
      this.reportXml = null;
      this.mode = this.availableUpdate ? 'response-tree' : this.response && this.response.length ? 'response' : this.items.length ? 'product' : null;
      if (opts.mode && this.modeEnabled(opts.mode)) this.mode = opts.mode;
      if (this.product.loaded()) this.syncSourceInputs();
      this.loadPermissions();
      TR.app.ensureVisible(this);
    }
    applyLoaded(product, source, add) {
      if (add) this.saveCurrentProductState(); else this.items = [];
      const i = this.replaceOrAddProduct(product, null, [], source === 'VDA' || source === 'SWC' ? product : null);
      this.selectedIndex = i;
      this.response = null; this.responseXml = null; this.availableUpdate = null; this.responseVms = {};
      this.requestOrProductXml = null; this.xmlText = null; this.reportXml = null;
      this.vdaErrorReport = null; this.vdaUpdateProduct.clear(); this.productDiff.clear(); this.toKitProduct.clear();
      this.product.clear();
      this.loadSelected();
      this.setDefaultRequest();
      this.mode = 'product';
      this.syncSourceInputs();
      this.loadPermissions();
      TR.app.ensureVisible(this);
      TR.app.refresh();
    }
    syncSourceInputs() {
      const info = this.product.info();
      if (info.chassisSeries) this.src.series = String(info.chassisSeries).trim();
      if (info.chassisNumber) this.src.number = String(info.chassisNumber).trim();
      if (info.vin) this.src.vin = info.vin;
    }
    setDefaultRequest() {
      const p = this.product.current;
      if (!p) return;
      const info = p.productSpecification.productInformation;
      if (!p.nodes.length && !p.parameters.length) this.request.selectedRequestType = E.RequestType.ProductionBreakdown;
      else if (this.request.selectedRequestType === E.RequestType.ProductionBreakdown) this.request.selectedRequestType = E.RequestType.Software;
      this.request.selectedFactory = info.assemblyFactoryCode || '';
      this.request.introductionWeek = info.introductionWeek || '';
    }
    async loadPermissions() {
      const ctx = this.product.loaded() ? this.product.info().context : null;
      const r = await TR.api('Permission/GetProductEditorPermissions', { contextId: ctx ? ctx.id : null });
      if (r.success) { this.permissions = r.item; TR.app.refresh(); }
    }
    async refreshMatches(pvm) {
      pvm = pvm || this.product;
      if (!pvm.loaded()) return;
      const nodes = pvm.current.nodes;
      const docs = nodes.map((n) => n.nodeTemplateDocument && Number(n.nodeTemplateDocument.number)).filter(Boolean);
      const sig = docs.join(',');
      pvm._matchSig = sig;
      const setInfo = (vals) => [pvm.current, pvm.original].forEach((p) => Object.assign(p.productSpecification.productInformation, vals));
      if (!pvm.ignoreServicePackChanges) {
        if (!nodes.length || docs.length !== nodes.length) setInfo({ servicePackName: '', servicePackUrl: '' });
        else {
          const ctx = pvm.info().context;
          const r = await TR.api('TestRequest2000/GetMatchingServicePackNameAndUrl', { documentNumbers: docs, contextId: ctx ? ctx.id : null });
          if (pvm._matchSig !== sig || !pvm.loaded()) return;
          if (r.success) setInfo({ servicePackName: r.item.name, servicePackUrl: r.item.url });
        }
      }
      const info = pvm.info();
      if (info.baselineGuid && !info.baselineUrl) {
        const r = await TR.api('TestRequest2000/GetBaselineNameAndUrlByGuid', { guid: info.baselineGuid });
        if (r.success && pvm.loaded()) setInfo({ baselineName: r.item.name, baselineUrl: r.item.url });
      } else if (docs.length) {
        const r = await TR.api('TestRequest2000/GetMatchingBaselineNameAndUrl', { documentNumbers: docs });
        if (pvm._matchSig !== sig || !pvm.loaded()) return;
        if (r.success) setInfo({ baselineName: r.item.name, baselineGuid: r.item.guid, baselineUrl: r.item.url });
      }
      TR.app.refresh();
    }

    // ---------- modes ----------
    modes() {
      return [
        { id: 'response', name: 'Response', icon: '🔧', enabled: () => !!(this.response && this.response.length), close: () => { this.response = null; this.responseVms = {}; } },
        { id: 'response-xml', name: 'Response XML', icon: '📄', enabled: () => !!this.responseXml, close: () => { this.responseXml = null; } },
        { id: 'response-tree', name: 'Response Tree', icon: '🌳', enabled: () => !!this.availableUpdate, close: () => { this.availableUpdate = null; } },
        { id: 'product', name: 'Product', icon: '🚚', enabled: () => this.product.loaded(), close: () => { this.items = []; this.selectedIndex = -1; this.product.clear(); } },
        { id: 'request-xml', name: this.xmlType === 'request' ? 'Request XML' : 'Product XML', icon: '📄', enabled: () => this.requestOrProductXml !== null, close: () => { this.requestOrProductXml = null; this.xmlText = null; }, leave: () => this.syncXml() },
        { id: 'product-diff', name: this.diffSource === 'vda' ? 'VDA Diff' : 'Product Diff', icon: '⇄', enabled: () => this.productDiff.loaded(), close: () => this.productDiff.clear() },
        { id: 'vda-update', name: 'VDA Update', icon: '⬆', enabled: () => this.vdaUpdateProduct.loaded() || !!this.vdaErrorReport, close: () => { this.vdaUpdateProduct.clear(); this.vdaErrorReport = null; } },
        { id: 'to-kit', name: 'To Kit', icon: '🧰', enabled: () => this.toKitProduct.loaded(), close: () => this.toKitProduct.clear() },
        { id: 'request-product-xml', name: this.reportType === 'request' ? 'Request Report XML' : 'Report XML', icon: '📄', enabled: () => this.reportXml !== null, close: () => { this.reportXml = null; } },
      ];
    }
    modeEnabled(id) { const m = this.modes().find((x) => x.id === id); return !!(m && m.enabled()); }
    currentMode() {
      const avail = this.modes().filter((m) => m.enabled());
      if (!avail.some((m) => m.id === this.mode)) this.mode = avail.length ? avail[0].id : null;
      return avail.find((m) => m.id === this.mode) || null;
    }
    async selectMode(id) {
      const cur = this.currentMode();
      if (cur && cur.id !== id && cur.leave) { const ok = await cur.leave(); if (ok === false) return false; }
      this.mode = id;
      TR.app.refresh();
      return true;
    }

    // ---------- sources ----------
    async loadFromSource(add) {
      let fn, source = 'VDA';
      const s = this.src;
      if (this.sourceType === 'VDA') fn = () => TR.api('VdaProduct/LoadFromVda', { chassis: { chassisSeries: s.series.trim(), chassisNumber: s.number.trim() } });
      else if (this.sourceType === 'VIN') fn = () => TR.api('VdaProduct/LoadFromVdaByVin', { vin: s.vin.trim() });
      else { fn = () => TR.api('Edb/Load', { specificationId: s.specId.trim() }); source = 'EDB'; }
      const r = await run(fn, `Loading product from ${source}`);
      if (r.success) this.applyLoaded(r.item, source, add);
    }
    async parseChassisAndLoad(input) {
      const r = await TR.api('TestRequest2000/ParseChassis', { input });
      if (!r.success) return;
      this.src.series = r.item.chassisSeries;
      this.src.number = r.item.chassisNumber;
      TR.app.refresh();
      if (r.item.chassisSeries && r.item.chassisNumber) { document.activeElement && document.activeElement.blur(); this.loadFromSource(false); }
      else setTimeout(() => { const el = document.querySelector(`[data-key="${this.position}-${r.item.chassisSeries ? 'number' : 'series'}"]`); if (el) el.focus(); }, 0);
    }
    async loadFileText(text, fileName) {
      const r = await run(() => TR.api('XmlFile/Load', { xml: text }), `Loading ${fileName || 'XML'}`);
      if (r.success) this.loadFileResult(r.item);
      return r.success;
    }
    loadFileResult(res, keepMode) {
      const prevMode = this.mode;
      this.setProducts(res.products, { request: res.request, requestXml: res.xml, requestedNodes: res.request ? res.request.requestedNodes : [] });
      if (res.request) this.request = Object.assign(defaultRequest(), clone(res.request));
      else this.setDefaultRequest();
      this.mode = keepMode && this.modeEnabled(prevMode) ? prevMode : 'product';
      TR.app.refresh();
    }
    async syncXml() {
      if (this.requestOrProductXml === null || this.xmlText === this.requestOrProductXml) return true;
      const r = await run(() => TR.api('XmlFile/Load', { xml: this.xmlText }), 'Reloading pane from edited XML');
      if (!r.success) return false;
      this.loadFileResult(r.item, true);
      return true;
    }
    copyFromOther() {
      const o = this.other();
      const p = o.product.get();
      const vda = o.productVda;
      this.applyLoaded(p, vda ? 'VDA' : 'COPY', false);
      if (vda) this.productVda = vda;
      this.request = clone(o.request);
      TR.app.refresh();
    }

    // ---------- product toolbar actions ----------
    async compareWith(kind) {
      const prevMode = this.mode;
      let target;
      if (kind === 'other') target = this.other().product.get();
      else {
        const r = await run(() => TR.api('VdaProduct/LoadFromVda', { chassis: this.product.chassis() }), 'Loading product from VDA');
        if (!r.success) return;
        target = r.item;
      }
      const d = await run(() => TR.api('TestRequest2000/GetDelta', { sourceJson: JSON.stringify(this.product.get()), targetJson: JSON.stringify(target) }), 'Comparing products');
      if (!d.success) { this.mode = prevMode; return; }
      this.productDiff.load(target);
      this.productDiff.current.productSpecification.productInformation = clone(this.product.info());
      this.productDiff.applyDelta(d.item, false);
      this.productDiff.ui.sections = { info: false, nodes: true, variants: true, snotes: true, params: true, notifications: false };
      this.diffSource = kind;
      this.diffOnlyDirty = true;
      this.mode = 'product-diff';
      TR.app.refresh();
    }
    async prepareVdaUpdate() {
      if (!this.productVda) { ui.summary.addError('You must load the product from VDA before updating it.'); return; }
      const d = await run(() => TR.api('TestRequest2000/GetDelta', { sourceJson: JSON.stringify(this.product.get()), targetJson: JSON.stringify(this.productVda) }), 'Comparing to VDA');
      if (!d.success) return;
      const vu = this.vdaUpdateProduct;
      vu.load(this.productVda);
      vu.applyDelta(d.item, false);
      this.vdaErrorReport = null;
      let refreshed = false;
      const dd = vu.delta();
      if ((dd.nodes.length || dd.productSpecification.variants.length || dd.productSpecification.sNotes.length) && vu.current.nodes.some((n) => n.nodeTemplateDocument)) {
        const info = vu.info();
        const payload = { allowLimitedValidation: false, enableMultiNodeBehavior: false, remoteRequest: 0, softwareRequestOperation: E.SoftwareRequestOperation.Refresh, products: [vu.get()], requestedNodes: vu.requestedNodes(), scenario: String(info.testStatus || '').toLowerCase() === 'design' ? E.Scenario.PreReleaseVerification : E.Scenario.Introduced, simulationKitName: '', pblUpdateCapable: true };
        const rr = await run(() => TR.api('AftermarketRequest/RequestSoftwareWithXml', { request: JSON.stringify(payload) }), 'Running Software Refresh before VDA update');
        if (!rr.success) return;
        const item = rr.item.item[0];
        if (item.errorReport && item.errorReport.errors.some((e) => e.severity === 0)) { this.vdaErrorReport = item.errorReport; this.mode = 'vda-update'; TR.app.refresh(); return; }
        vu.applyDelta(item.delta, false);
        refreshed = true;
      }
      vu.selectAll();
      if (!M.hasDelta(vu.getVdaDelta().assignProduct)) {
        vu.clear();
        ui.summary.addInformation(refreshed ? 'Compared to the product in VDA there were no changes after a Software Refresh was applied to the product.' : 'There are no changes compared to the product in VDA');
        TR.app.refresh();
        return;
      }
      this.vdaOnlyDirty = true;
      this.mode = 'vda-update';
      TR.app.refresh();
    }
    async sendToVda() {
      const vu = this.vdaUpdateProduct;
      if (!vu.loaded()) return;
      const chassis = vu.chassis();
      const fresh = await run(() => TR.api('VdaProduct/LoadFromVda', { chassis }), 'Checking product in VDA');
      if (!fresh.success) return;
      const chk = await run(() => TR.api('TestRequest2000/GetDelta', { sourceJson: JSON.stringify(this.productVda), targetJson: JSON.stringify(fresh.item) }), 'Checking product in VDA');
      if (!chk.success) return;
      if (M.hasDelta(chk.item)) { ui.summary.addError('The product in VDA has been changed. Please do a new compare to VDA.'); TR.app.refresh(); return; }
      const vd = vu.getVdaDelta();
      if (!M.hasDelta(vd.assignProduct)) { ui.summary.addError('Select at least one change to apply to VDA.'); TR.app.refresh(); return; }
      const r = await run(() => TR.api('TestRequest2000/SendToVda', { jsonVdaDelta: JSON.stringify(vd) }), 'Updating VDA');
      if (!r.success) return;
      const re = await run(() => TR.api('VdaProduct/LoadFromVda', { chassis }), 'Reloading product from VDA');
      if (!re.success) { ui.summary.addError('Loading of the updated product failed. Please reload the product.'); TR.app.refresh(); return; }
      this.applyLoaded(re.item, 'VDA', this.items.length > 1);
      ui.summary.addInformation('The product was successfully updated in VDA.');
      TR.app.refresh();
    }
    async toKit() {
      const src = this.mode === 'product-diff' ? this.productDiff : this.product;
      const r = await run(() => TR.api('TestRequest2000/GetDelta', { sourceJson: JSON.stringify(src.get()), targetJson: JSON.stringify(src.getOriginal()), forceIncludeBootloaders: true }), 'Preparing To Kit');
      if (!r.success) return;
      const tk = this.toKitProduct;
      tk.load(src.getOriginal());
      tk.current.productSpecification.productInformation = clone(src.info());
      tk.applyDelta(r.item, false);
      tk.selectAll();
      this.mode = 'to-kit';
      TR.app.refresh();
    }
    async createKit() {
      const sd = await run(() => TR.api('SessionData/Save', { data: JSON.stringify(this.toKitProduct.getKitDelta()) }), 'Saving kit operations');
      if (!sd.success) return;
      const r = await run(() => TR.api('ConversionKit/CreateKitFromDelta', { sessionDataId: sd.item }), 'Creating conversion kit');
      if (!r.success) return;
      const k = r.item;
      ui.modal({ title: 'Create Conversion Kit (simulated new window)', width: 560, body: h('div', null, h('p', null, 'A new conversion kit was created from the selected operations:'), ui.kv([['Part number', h('a', { href: `#/Kit?partNumber=${k.partNumber}` }, String(k.partNumber))], ['Name', k.name], ['State', k.state], ['Operations', JSON.stringify(M.deltaCounts(k.delta))], ['Session data id', sd.item]]), h('p', { class: 'small muted' }, 'The kit can be used in a Conversion Kit request with scenario "In Progress".')) });
    }
    addToKitPopup() {
      let pn = '';
      let msg = 'Disabled since no Conversion Kit Part Number has been entered';
      let valid = false;
      let validating = false;
      let token = 0;
      const check = TR.util.debounce(async (m) => {
        const my = ++token;
        const v = pn.trim();
        valid = false;
        if (!v) msg = 'Disabled since no Conversion Kit Part Number has been entered';
        else if (!/^\d+$/.test(v)) msg = `'${v}' is not a number. Disabled since the Conversion Kit Part Number is not a Number`;
        else if (v.length < 7 || v.length > 8) msg = `'${v}' is not a valid Part Number. Disabled since the Conversion Kit Part Number is not a valid Part Number`;
        else {
          validating = true; msg = `'${v}' is being validated.`; m.render();
          const r = await TR.api('ConversionKit/AddToKitCheckPartNumber', { partNumber: v });
          if (my !== token) return;
          validating = false;
          valid = r.success;
          msg = r.success ? '' : r.errors.join(' ');
        }
        if (!m.closed) m.render();
      }, 250);
      const m = ui.modal({
        title: 'Add To Kit', width: 400,
        body: (mm) => h('div', null, h('input', { class: 'full', key: 'add-to-kit', placeholder: 'Enter Conversion Kit Part Number', maxlength: 8, value: pn, onInput: (e) => { pn = e.target.value; valid = false; check(mm); } }),
          msg ? h('div', { class: validating ? 'muted small' : 'warning-text small' }, msg) : h('div', { class: 'ok-text small' }, '✔ Conversion kit found'),
          h('div', { class: 'small muted' }, 'Existing kits: ', TR.server.state.kits.map((k) => `${k.partNumber} (${k.state})`).join(', '))),
        buttons: () => [{ label: 'Cancel' }, { label: 'OK', primary: true, disabled: !valid, title: msg, onClick: async (mm) => {
          if (!pn.trim()) { ui.summary.addError('Please Enter Conversion Kit Part Number'); return; }
          mm.close();
          const sd = await run(() => TR.api('SessionData/Save', { data: JSON.stringify(this.toKitProduct.getKitDelta()) }), 'Saving kit operations');
          if (!sd.success) return;
          const r = await run(() => TR.api('ConversionKit/AddToKitFromDelta', { sessionDataId: sd.item, partNumber: pn.trim() }), 'Adding operations to kit');
          if (r.success) { ui.summary.addInformation(`The selected operations were added to conversion kit ${r.item.partNumber} (${r.item.name}).`); TR.app.refresh(); }
        } }],
      });
    }
    async productUpdates() {
      const vda = await run(() => TR.api('VdaProduct/LoadFromVda', { chassis: this.product.chassis() }), 'Loading product from VDA');
      if (!vda.success) { ui.summary.addError('Failed to compare to VDA.'); TR.app.refresh(); return; }
      const d = await run(() => TR.api('TestRequest2000/GetDelta', { sourceJson: JSON.stringify(this.product.get()), targetJson: JSON.stringify(vda.item) }), 'Comparing to VDA');
      if (!d.success) { ui.summary.addError('Failed to compare to VDA.'); TR.app.refresh(); return; }
      const has = M.hasDelta(d.item);
      if (has) {
        const c = M.deltaCounts(d.item);
        const ok = await ui.confirm(`Changes compared to VDA: ${c.nodes} node, ${c.parameters} parameter, ${c.variants} variant and ${c.sNotes} S-Note operation(s).\n\nDo you want to proceed with the changes?`, 'VBC Product updates');
        if (!ok) return;
      }
      const r = await run(() => TR.api('ProductUpdates/Create', { productJson: JSON.stringify(this.product.get()), assignProductJson: has ? JSON.stringify(d.item) : '', hasChanges: has }), 'Creating product update tasks');
      if (r.success) { ui.summary.addInformation(`Product update task #${r.item.id} was created${has ? '' : ' (no changes)'} – in SW Configurator you are now redirected to the Product Updates page.`); TR.app.refresh(); }
    }
    async save() {
      const info = this.product.info();
      const r = await run(() => TR.api('TestRequest2000/StoreProduct', { productJson: JSON.stringify(this.product.get()), series: info.chassisSeries, number: info.chassisNumber }), 'Saving product');
      if (r.success) { ui.summary.addInformation(h('span', null, 'Product was successfully stored: ', h('a', { href: r.link }, r.link))); TR.app.refresh(); }
    }
    async getXml(kind) {
      const pj = JSON.stringify(this.product.get());
      if (kind === 'product') {
        const r = await run(() => TR.api('TestRequest2000/GetProductXml', { productJson: pj }), 'Getting product XML');
        if (!r.success) return;
        this.requestOrProductXml = r.item; this.xmlText = r.item; this.xmlType = 'product'; this.mode = 'request-xml';
      } else {
        const r = await run(() => TR.api('TestRequest2000/GetProductReportXml', { productJson: pj }), 'Getting report XML');
        if (!r.success) return;
        this.reportXml = r.item; this.reportType = 'product'; this.mode = 'request-product-xml';
      }
      TR.app.refresh();
    }
    async reloadXml() {
      if (this.xmlType === 'product') return this.getXml('product');
      return TR.request.getRequestXml(this);
    }
    async saveXml(kind) {
      let text, type;
      if (kind === 'response') { TR.util.download('response.xml', this.responseXml); return; }
      if (kind === 'report') { text = this.reportXml; type = this.reportType; } else {
        if (!(await this.syncXml())) return;
        text = this.requestOrProductXml; type = this.xmlType;
      }
      const r = await TR.api('TestRequest2000/GetRequestFileName', { request: type === 'request' ? this.request : null, chassis: this.product.loaded() ? this.product.chassis() : null });
      TR.util.download(r.success ? r.item : `${type}.xml`, text);
    }
    copyResponseToClipboard() {
      const lines = [];
      (this.response || []).forEach((r) => {
        lines.push(`Chassis: ${r.chassisSeries} ${r.chassisNumber}`);
        const nodes = (r.delta.nodes || []).filter((o) => o.value).map((o) => o.value);
        if (nodes.length) {
          lines.push('Assigned  Nodes');
          nodes.forEach((n) => {
            lines.push(n.name);
            lines.push(`\tNTP Document: ${n.nodeTemplateDocument ? n.nodeTemplateDocument.number : ''}`);
            lines.push(`\tECU Hardware: ${n.ecuHardware ? n.ecuHardware.number : ''}`);
            M.singles(n.electricalArchitecture).slice(2).forEach(([k, , label]) => { if (n[k]) lines.push(`\t${label}: ${n[k].number}`); });
            M.lists(n.electricalArchitecture).forEach(([k, , label]) => { if ((n[k] || []).length) { lines.push(`\t${label}:`); n[k].forEach((x) => lines.push(`\t\t${x.name || label}: ${x.number}`)); } });
          });
        }
        if ((r.affectedNodes || []).length) { lines.push('Affected Nodes'); r.affectedNodes.forEach((id) => lines.push(`\t${M.derivedName(id)}`)); }
        const ap = (r.delta.parameters || []).filter((o) => o.type === E.Op.AssignParameter), rp = (r.delta.parameters || []).filter((o) => o.type === E.Op.RemoveParameter);
        if (ap.length) { lines.push('Assigned  Parameters'); ap.forEach((o) => lines.push(`\t${o.value.code}: ${M.paramValue(o.value)}`)); }
        if (rp.length) { lines.push('Removed  Parameters'); rp.forEach((o) => lines.push(`\t${o.value.code}`)); }
        const vs = r.delta.productSpecification.variants || [], ss = r.delta.productSpecification.sNotes || [];
        if (vs.some((o) => o.type === 6)) { lines.push('Assigned Variants'); vs.filter((o) => o.type === 6).forEach((o) => lines.push(`\t${o.value.symbol}`)); }
        if (vs.some((o) => o.type === 7)) { lines.push('Removed Variants'); vs.filter((o) => o.type === 7).forEach((o) => lines.push(`\t${o.value.symbol}`)); }
        if (ss.some((o) => o.type === 8)) { lines.push('Assigned SNotes'); ss.filter((o) => o.type === 8).forEach((o) => lines.push(`\t${o.value.name || o.value.value}`)); }
        if (ss.some((o) => o.type === 9)) { lines.push('Removed SNotes'); ss.filter((o) => o.type === 9).forEach((o) => lines.push(`\t${o.value.name || o.value.value}`)); }
        lines.push('');
      });
      TR.util.copyText(lines.join('\n')).then((ok) => { ui.summary.addInformation(ok ? 'Response copied to clipboard.' : 'Could not copy to clipboard.'); TR.app.refresh(); });
    }
    saveLocal() {
      TR.util.store.set('testRequest', { product: this.product.get(), response: this.response, request: this.request, requestXml: this.requestOrProductXml });
      ui.summary.addInformation(`Pane state saved to localStorage key "testRequest".`);
      TR.app.refresh();
    }
    loadLocal() {
      const s = TR.util.store.get('testRequest', null);
      if (!s || !s.product) { ui.summary.addWarning('Nothing saved in localStorage.'); TR.app.refresh(); return; }
      this.setProducts([s.product], { request: s.request, requestXml: s.requestXml || undefined, response: s.response });
      TR.app.refresh();
    }

    // ---------- copy information ----------
    async openCopyProductInformation() {
      const from = this.product, to = this.other().product;
      const fi = from.info(), ti = to.info();
      const sameCtx = fi.context && ti.context && fi.context.id === ti.context.id;
      const nodes = sameCtx ? from.current.nodes.map((n) => ({ key: M.nodeKey(n), name: n.name, description: n.versionName || '', mswNumber: n.mainSoftware ? n.mainSoftware.number : null, node: n })) : [];
      const params = from.current.parameters.map((p) => ({ key: M.paramKey(p), name: M.paramDisplay(p), code: p.code, p }));
      const snotes = from.current.productSpecification.sNotes.map((s) => ({ key: s.value, name: s.value, description: s.name, s }));
      const vr = await run(() => TR.api('TestRequest2000/ValidateVariantsForProductClass', { variants: from.current.productSpecification.variants.map((v) => ({ familyId: v.familyId, variantId: v.variantId, symbol: v.symbol })), productClassCode: ti.productClassId }), 'Validating variants');
      if (!vr.success) return;
      const variants = vr.item.map((v) => { const full = TR.db.variantByIdVar6(v.familyId + v.variantId); return { key: v.familyId + v.variantId, name: v.symbol, description: full ? full.description : '', v: full || Object.assign({ idVar6: v.familyId + v.variantId }, v) }; });
      const sel = { nodes: new Set(), params: new Set(), snotes: new Set(), variants: new Set() };
      let search = '';
      let includeParams = false;
      const match = (x) => !search || `${x.name} ${x.description || ''}`.toUpperCase().includes(search.toUpperCase());
      const card = (title, key, list, extra) => {
        const shown = list.filter(match);
        if (!shown.length && search) return null;
        return h('div', { class: 'card' }, h('div', { class: 'card-head' }, h('strong', null, title), h('span', { class: 'spacer' }),
          extra || null,
          h('button', { class: 'link-btn small', onClick: () => { shown.forEach((x) => sel[key].add(x.key)); m.render(); } }, 'Select All'),
          h('button', { class: 'link-btn small', onClick: () => { shown.forEach((x) => sel[key].delete(x.key)); m.render(); } }, 'Deselect All')),
          h('div', { class: 'card-body' }, shown.length ? shown.map((x) => h('label', { class: 'chk block' }, h('input', { type: 'checkbox', checked: sel[key].has(x.key), onChange: (e) => { if (e.target.checked) sel[key].add(x.key); else sel[key].delete(x.key); if (key === 'nodes' && includeParams) syncParams(); } }), ' ', h('strong', null, x.name), x.description ? ` - ${x.description}` : '')) : h('div', { class: 'muted small' }, key === 'nodes' && !sameCtx ? 'Nodes can only be copied between products in the same context.' : 'Nothing to copy.')));
      };
      const syncParams = async () => {
        const msws = nodes.filter((n) => sel.nodes.has(n.key) && n.mswNumber).map((n) => n.mswNumber);
        if (!msws.length) return;
        const r = await TR.api('TestRequest2000/GetParameterCodesForMsws', { partNumbers: msws });
        if (r.success) params.filter((p) => r.item.includes(p.code)).forEach((p) => sel.params.add(p.key));
        m.render();
      };
      const doCopy = () => {
        nodes.filter((n) => sel.nodes.has(n.key)).forEach((n) => to.replaceNode(clone(n.node)));
        params.filter((p) => sel.params.has(p.key)).forEach((p) => to.setParam(p.p));
        snotes.filter((s) => sel.snotes.has(s.key)).forEach((s) => to.addSNote(s.s));
        variants.filter((v) => sel.variants.has(v.key)).forEach((v) => to.addVariant(v.v));
        m.close();
        this.other().refreshMatches();
        ui.summary.addInformation(`Copied ${sel.nodes.size} node(s), ${sel.params.size} parameter(s), ${sel.snotes.size} S-Note(s) and ${sel.variants.size} variant(s) to ${to.chassisString()}.`);
        TR.app.refresh();
      };
      const m = ui.modal({
        title: 'Copy Product Information', width: 760, class: 'copy-info',
        body: () => h('div', null,
          h('div', { class: 'row' }, h('strong', null, `Copy product information from ${from.chassisString()} to ${to.chassisString()}`), h('span', { class: 'spacer' }), h('button', { class: 'btn primary small', onClick: doCopy }, 'Copy'), h('button', { class: 'btn small', onClick: () => m.close() }, 'Cancel')),
          h('input', { class: 'full', key: 'copy-search', placeholder: 'Search', value: search, onInput: TR.util.debounce((e) => { search = e.target.value; m.render(); }, 300) }),
          card('Nodes', 'nodes', nodes, sameCtx ? h('label', { class: 'chk small' }, h('input', { type: 'checkbox', checked: includeParams, onChange: (e) => { includeParams = e.target.checked; if (includeParams) syncParams(); } }), ' Include Parameters') : null),
          card('S-Notes', 'snotes', snotes), card('Parameters', 'params', params), card('Variants', 'variants', variants)),
        buttons: [{ label: 'Cancel' }, { label: 'Copy', primary: true, onClick: doCopy }],
      });
    }

    // ---------- render ----------
    render() {
      const shell = TR.app.shell;
      const mode = this.currentMode();
      const other = this.other();
      const hasProd = this.product.loaded();
      const p = this.position;
      const tb = [];
      // 1. source picker
      const s = this.src;
      const loadBtns = (enabled, tip, addTip) => [
        h('button', { class: 'btn small primary', disabled: !enabled, title: enabled ? tip : tip.replace('Load from', 'Enter'), onClick: () => { this.src.chassisText = null; this.loadFromSource(false); } }, 'Load'),
        this.items.length ? h('button', { class: 'btn small', disabled: !enabled, title: addTip, onClick: () => this.loadFromSource(true) }, 'Add') : null,
      ];
      let srcComp;
      if (this.sourceType === 'VDA') {
        const can = !!(s.series.trim() && s.number.trim());
        // Series and chassis number as two labelled fields; pasting "FH 123456" into either fills both and loads.
        const series = [...new Set(['FH', 'FM', 'FMX', 'VNL', 'VNR', 'RT', 'A'].concat(s.series ? [s.series.toUpperCase()] : []))];
        const loadLabel = p === 'left' ? 'Load vehicle' : 'Load comparison';
        const paste = (e) => { const t = (e.clipboardData || window.clipboardData).getData('text'); if (!/\s|-/.test(t.trim())) return; e.preventDefault(); s.chassisText = null; setTimeout(() => this.parseChassisAndLoad(t), 0); };
        srcComp = [h('div', { class: 'tw-chassis' },
          h('label', null, h('span', null, 'Series'), h('select', { key: `${p}-series-sel`, value: s.series, 'aria-label': 'Chassis series', onChange: (e) => { s.series = e.target.value; s.chassisText = null; TR.app.refresh(); } },
            [h('option', { value: '' }, 'Select series')].concat(series.map((x) => h('option', { value: x, selected: x === s.series.toUpperCase() }, x))))),
          h('label', null, h('span', null, 'Chassis number'), h('input', { key: `${p}-number`, inputmode: 'numeric', maxlength: 12, placeholder: 'Enter chassis number', value: s.number, 'aria-label': 'Chassis number', autocomplete: 'off',
            onInput: (e) => { s.number = e.target.value.trim(); s.chassisText = null; TR.app.refreshSoon(); }, onKeydown: (e) => { if (e.key === 'Enter' && can) { e.preventDefault(); this.loadFromSource(false); } }, onPaste: paste })),
          h('button', { class: ['s-btn', p === 'left' ? 'primary' : 'secondary'], disabled: !can, 'data-tip': can ? loadLabel : 'Choose a series and enter the chassis number', onClick: () => { s.chassisText = null; this.loadFromSource(false); } }, loadLabel),
          this.items.length ? h('button', { class: 's-btn text', disabled: !can, 'data-tip': 'Add|Load an additional vehicle into this pane', onClick: () => this.loadFromSource(true) }, 'Add') : null),
          h('small', { class: 'muted tw-hint' }, 'Try FH 333333 for T3 or FH 123456 for legacy.')];
      } else if (this.sourceType === 'VIN') {
        const can = !!s.vin.trim();
        srcComp = [h('input', { key: `${p}-vin`, class: 'upper', size: 19, maxlength: 30, placeholder: 'VIN', value: s.vin, onInput: (e) => { s.vin = e.target.value; TR.app.refreshSoon(); }, onKeydown: (e) => { if (e.key === 'Enter' && s.vin.trim()) this.loadFromSource(false); } }),
          loadBtns(can, can ? 'Load from VDA' : 'Enter VIN', 'Load additional product from VDA')];
      } else if (this.sourceType === 'EDB') {
        const can = !!s.specId.trim();
        srcComp = [h('input', { key: `${p}-spec`, size: 14, maxlength: 30, placeholder: 'Specification ID', title: 'VSS Spec (VSS-xx-xxx), Renault Order (RT_ORDER xxx), OM Order (xxx)', value: s.specId, list: 'edb-specs', onInput: (e) => { s.specId = e.target.value; TR.app.refreshSoon(); }, onKeydown: (e) => { if (e.key === 'Enter' && s.specId.trim()) this.loadFromSource(false); } }),
          loadBtns(can, can ? 'Load from EDB' : 'Enter specification ID', 'Load additional product from EDB')];
      } else {
        srcComp = [h('button', { class: 'btn small primary', onClick: async () => { const f = await TR.util.pickFile('.xml'); if (f) this.loadFileText(await TR.util.readFileText(f), f.name); } }, 'Load File')];
      }
      // The source as a segmented control (all four choices visible at once) instead of a drop-down.
      const SOURCES = [['VDA', 'Chassis', 'Load from VDA by chassis series and number'], ['VIN', 'VIN', 'Load from VDA by vehicle identification number'], ['EDB', 'EDB', 'Load a specification from the engineering database'], ['File', 'File', 'Open a product or request XML file']];
      tb.push(h('div', { class: 'toolbar tp-source' },
        h('div', { class: 'tp-seg', role: 'radiogroup', 'aria-label': 'Product source' }, SOURCES.map(([v, label, tip]) => h('button', { type: 'button', role: 'radio', 'aria-checked': String(this.sourceType === v), class: this.sourceType === v ? 'is-on' : '', 'data-tip': label + '|' + tip, onClick: () => { this.sourceType = v; TR.app.refresh(); } }, label))),
        srcComp));
      // 2. multi product selector
      if (this.items.length > 1) {
        tb.push(h('div', { class: 'toolbar' }, ui.select(this.items.map((it, i) => [i, M.chassisText(it.product) + (it.delta ? ' *' : '')]), this.selectedIndex, (v) => this.selectProduct(Number(v)), { title: 'Selected chassis' }),
          h('button', { class: 'icon-btn danger', title: 'Remove Chassis', onClick: () => this.removeSelectedProduct() }, '🗑')));
      }
      // 3. copy button
      if (!mode && other.product.loaded()) tb.push(h('div', { class: 'toolbar' }, h('button', { class: 'btn small', title: 'Copy product from the other pane', onClick: () => this.copyFromOther() }, p === 'left' ? 'Copy right' : 'Copy left')));
      // 4. product toolbar
      if (mode && (mode.id === 'product' || mode.id === 'product-diff') && hasProd) {
        const perms = this.permissions;
        const vdaTip = !this.productVda ? 'VDA update disabled since the product was not loaded from VDA' : !perms.UpdateVda ? 'VDA update disabled since you are not VDA Writer in the context' : 'Update product in VDA';
        const dirtyForKit = mode.id === 'product' ? this.product.dirty() : this.productDiff.dirty();
        const kitTip = !hasProd ? 'Load product from VDA to enable To Kit operations' : !perms.ToKit ? 'To kit is disabled since you are not Authorized user' : !dirtyForKit ? 'To kit is disabled since there are no changes in the product' : 'Add Product Changes To Kit Or Create a new one';
        const bea = this.product.current.nodes.some((n) => n.electricalArchitecture === 2);
        const beaDirty = this.product.nodeRows().some((r) => r.node.electricalArchitecture === 2 && r.status) || this.product.paramRows().some((r) => (r.p.electricalArchitecture || 0) === 0 && r.status);
        tb.push(h('div', { class: 'toolbar' },
          mode.id === 'product' ? h('button', { class: 'btn small', disabled: !other.product.loaded(), title: 'Compare with the product in the other pane', onClick: () => this.compareWith('other') }, p === 'left' ? 'Compare right' : 'Compare left') : null,
          h('button', { class: 'btn small', onClick: () => this.compareWith('vda'), title: 'Compare with the product in VDA' }, 'Compare VDA'),
          h('button', { class: 'btn small', title: 'Edit variants in VESPA2', onClick: () => TR.shellActions.editInVespa2(this) }, 'VESPA2'),
          h('button', { class: 'btn small', disabled: !this.productVda || !perms.UpdateVda || this.disableVdaUpdate, title: vdaTip, onClick: () => this.prepareVdaUpdate() }, '⬆ Update VDA'),
          p === 'left' && bea ? h('button', { class: 'btn small', disabled: !beaDirty, title: 'Create product update tasks', onClick: () => this.productUpdates() }, 'VBC Product updates') : null,
          h('button', { class: 'btn small', disabled: !perms.ToKit || !dirtyForKit, title: kitTip, onClick: () => this.toKit() }, 'To Kit'),
          other.product.loaded() ? h('button', { class: 'btn small', title: 'Copy product information from one product pane to the other', onClick: () => this.openCopyProductInformation() }, 'Copy Information') : null,
          mode.id === 'product' && perms.Save ? h('button', { class: 'btn small', title: 'Save current product xml', onClick: () => this.save() }, 'Save') : null));
      }
      if (mode && mode.id === 'to-kit') {
        const any = this.toKitProduct.someSelected();
        tb.push(h('div', { class: 'toolbar' }, h('button', { class: 'btn small primary', disabled: !any, title: any ? 'Create a new conversion kit from the selected operations' : 'Disable since no operation is selected', onClick: () => this.createKit() }, 'Create Kit'),
          h('button', { class: 'btn small', disabled: !any, title: any ? 'Add the selected operations to an existing kit' : 'Disable since no operation is selected', onClick: () => this.addToKitPopup() }, 'Add To Kit')));
      }
      if (mode && mode.id === 'response') tb.push(h('div', { class: 'toolbar' }, h('button', { class: 'btn small', title: 'Copy response clipboard', onClick: () => this.copyResponseToClipboard() }, '⧉ Copy')));
      if (mode && mode.id === 'request-xml') tb.push(h('div', { class: 'toolbar' }, h('button', { class: 'btn small', title: this.xmlType === 'product' ? 'Reload XML from product' : 'Reload XML from request', onClick: () => this.reloadXml() }, '⟳ Reload'), h('button', { class: 'btn small', title: 'Save request XML to file', onClick: () => this.saveXml('request') }, 'Save XML')));
      if (mode && mode.id === 'request-product-xml') tb.push(h('div', { class: 'toolbar' }, h('button', { class: 'btn small', title: 'Save XML to file', onClick: () => this.saveXml('report') }, 'Save XML')));
      if (mode && mode.id === 'response-xml') tb.push(h('div', { class: 'toolbar' }, h('button', { class: 'btn small', title: 'Save response XML to file', onClick: () => this.saveXml('response') }, 'Save XML')));
      if (mode && mode.id === 'product-diff') tb.push(h('div', { class: 'toolbar' }, h('button', { class: 'btn small', title: 'Compare again', onClick: () => this.compareWith(this.diffSource) }, '⟳ Reload'),
        h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: this.diffOnlyDirty, onChange: (e) => { this.diffOnlyDirty = e.target.checked; TR.app.refresh(); } }), ' Show differences only')));
      if (mode && mode.id === 'vda-update' && this.vdaUpdateProduct.loaded()) {
        const vu = this.vdaUpdateProduct;
        tb.push(h('div', { class: 'toolbar' }, h('button', { class: 'btn small', onClick: () => { vu.selectAll(); TR.app.refresh(); } }, 'Select all'), h('button', { class: 'btn small', onClick: () => { vu.deselectAll(); TR.app.refresh(); } }, 'Deselect all'),
          h('button', { class: 'btn small', onClick: () => { vu.deselectAllRemoveOperations(); TR.app.refresh(); } }, 'Deselect all remove'),
          h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: this.vdaOnlyDirty, onChange: (e) => { this.vdaOnlyDirty = e.target.checked; TR.app.refresh(); } }), ' Show changes only')));
        tb.push(h('div', { class: 'toolbar' }, h('button', { class: 'btn small primary', disabled: !vu.dirty() || this.disableVdaUpdate, onClick: () => this.sendToVda() }, '⬆ Send to VDA')));
      }
      if (shell.devMode) tb.push(h('div', { class: 'toolbar' }, h('button', { class: 'icon-btn', title: 'Load from localStorage', onClick: () => this.loadLocal() }, '⇩'), h('button', { class: 'icon-btn', title: 'Save to localStorage', onClick: () => this.saveLocal() }, '⇧')));
      if (mode && mode.id === 'product') {
        tb.push(h('div', { class: 'toolbar grow' },
          h('select', { class: 'small-select', value: '', onChange: (e) => { const v = e.target.value; e.target.value = ''; if (v) this.getXml(v); } }, h('option', { value: '' }, 'Get XML'), h('option', { value: 'product' }, 'Product XML'), h('option', { value: 'report' }, 'Report XML')),
          h('button', { class: 'btn small primary', disabled: !hasProd, title: 'Create a test request from this product', onClick: () => TR.request.open(this) }, 'Request')));
      }
      tb.push(h('div', { class: 'toolbar right' }, h('button', { class: 'btn small', title: shell.fullScreen === p ? 'Exit fullscreen' : 'Fullscreen', onClick: () => { shell.fullScreen = shell.fullScreen === p ? null : p; TR.app.refresh(); } }, shell.fullScreen === p ? '⤢ Exit fullscreen' : '⤢')));

      const tabs = h('div', { class: 'pane-mode-bar' }, this.modes().filter((m) => m.enabled()).map((m) => h('div', { class: ['mode-tab', mode && mode.id === m.id && 'selected'], onClick: (e) => { if (!e.target.closest('.tab-close')) this.selectMode(m.id); } },
        h('span', { class: 'tab-icon' }, m.icon), ' ', m.name, h('button', { class: 'tab-close', title: 'Close', onClick: () => { m.close(); TR.app.refresh(); } }, '×'))));

      const body = h('div', { class: 'pane-body', 'data-scroll': `${p}-body-${mode ? mode.id : 'none'}`, tabindex: mode ? null : 0 }, this.renderBody(mode));
      if (!mode) this.attachDrop(body);
      // The title says what the pane is for, then which vehicle it holds and whether it has unsaved changes.
      const role = p === 'left' ? ['Starting vehicle', 'Your original configuration stays available.', 'truck'] : ['Result or comparison', 'Generated result or another vehicle.', 'compare'];
      const head = h('div', { class: 'pane-head' },
        h('div', { class: 'pane-title' },
          h('span', { class: 'tp-badge', 'aria-hidden': 'true' }, TR.icon(role[2], 16)),
          h('span', { class: 'tp-name' }, h('strong', null, role[0]), h('small', null, hasProd ? this.product.chassisString() + ' · ' + role[1] : role[1])),
          hasProd && this.product.dirty() ? h('span', { class: 's-chip warning', 'data-tip': 'Unsaved changes|The proposal differs from the loaded vehicle.' }, 'Modified') : null,
          hasProd && this.items.length > 1 ? h('span', { class: 's-chip neutral' }, this.items.length + ' vehicles') : null),
        h('div', { class: 'toolbars' }, tb));
      return h('section', { class: ['pane', p] }, head, tabs, body);
    }

    attachDrop(body) {
      body.addEventListener('dragover', (e) => { e.preventDefault(); body.classList.add('drag'); });
      body.addEventListener('dragleave', () => body.classList.remove('drag'));
      body.addEventListener('drop', async (e) => {
        e.preventDefault();
        body.classList.remove('drag');
        const f = e.dataTransfer.files[0];
        if (f) this.loadFileText(await TR.util.readFileText(f), f.name);
      });
      body.addEventListener('paste', (e) => {
        const t = (e.clipboardData || window.clipboardData).getData('text');
        if (t && t.trim().startsWith('<')) { e.preventDefault(); this.loadFileText(t, 'pasted XML'); }
      });
    }

    editorCtx(pvm, extra) {
      const shell = TR.app.shell;
      return Object.assign({ pvm, pane: this, prefix: `${this.position}-${pvm.name}`, showSource: shell.showSource, filter: shell.sourceFilter, refresh: () => TR.app.refresh(), onNodesChanged: () => this.refreshMatches(pvm) }, extra || {});
    }

    renderBody(mode) {
      if (!mode) {
        // Empty state: what goes here, and one obvious way to fill it.
        const left = this.position === 'left', other = this.other();
        const pick = async () => { const f = await TR.util.pickFile('.xml'); if (f) this.loadFileText(await TR.util.readFileText(f), f.name); };
        return h('div', { class: 'dropzone tp-empty' },
          h('div', { class: 'tp-empty-art', 'aria-hidden': 'true', html:
            '<svg viewBox="0 0 220 110"><rect x="8" y="88" width="204" height="6" rx="3" class="tp-road"/><g class="tp-truck"><rect x="38" y="40" width="96" height="44" rx="5" class="tp-trailer"/>' +
            '<path d="M134 84V52q0-6 6-6h20q7 0 10 6l8 16v16z" class="tp-cab"/><path d="M148 50h12q4 0 6 4l5 10h-23z" class="tp-glass"/>' +
            '<circle cx="62" cy="88" r="8" class="tp-wheel"/><circle cx="110" cy="88" r="8" class="tp-wheel"/><circle cx="160" cy="88" r="8" class="tp-wheel"/></g>' +
            (left ? '<path d="M86 24v14m-6-6 6 6 6-6" class="tp-arrow"/>' : '<path d="M60 26h50m-8-6 8 6-8 6M160 30h-50" class="tp-arrow"/>') + '</svg>' }),
          h('h3', null, left ? (this.src.series && this.src.number ? 'Ready to load ' + this.src.series.toUpperCase() + ' ' + this.src.number : 'Load a starting vehicle') : 'Your result will appear here'),
          h('p', { class: 'muted' }, left ? 'Load its configuration to begin editing a proposal. You can also drop or paste a product XML file here.'
            : other.product.loaded() ? 'Create a request from the starting vehicle; its response opens in this pane. You can also load a vehicle here for comparison.'
            : 'Load the starting vehicle, then run a request. You can also load a vehicle here for comparison.'),
          h('div', { class: 'tp-empty-actions' },
            left ? [h('button', { class: 'jr-link', onClick: pick }, TR.icon('upload', 15), ' Import XML')]
              : [other.product.loaded() ? h('button', { class: 's-btn primary', onClick: () => TR.request.open(other) }, TR.icon('flask', 15), ' Create a request') : null,
                h('button', { class: 's-btn secondary', onClick: () => { this.sourceType = 'VDA'; TR.app.refresh(); setTimeout(() => { const i = document.querySelector('.pane.right .tw-chassis input'); if (i) i.focus(); }, 0); } }, TR.icon('truck', 15), ' Load comparison vehicle')]));
      }
      switch (mode.id) {
        case 'product': return TR.editors.productEditor(this.editorCtx(this.product, { editable: true }));
        case 'product-diff': return h('div', null, h('div', { class: 'mode-caption' }, `Differences between ${this.product.chassisString()} (this pane) and ${this.diffSource === 'vda' ? 'the product in VDA' : `${this.other().product.chassisString()} (other pane)`}. Changes show what turns the ${this.diffSource === 'vda' ? 'VDA' : 'other'} product into this product.`),
          TR.editors.productEditor(this.editorCtx(this.productDiff, { readOnly: true, onlyDirty: this.diffOnlyDirty })));
        case 'vda-update': return this.renderVdaUpdate();
        case 'to-kit': return this.renderToKit();
        case 'response': return this.renderResponse();
        case 'response-xml': return h('pre', { class: 'xml-pre' }, this.responseXml);
        case 'response-tree': {
          let obj;
          try { obj = JSON.parse(this.availableUpdate.dataArea); } catch (e) { obj = this.availableUpdate.dataArea; }
          return h('div', { id: 'treeView' }, TR.ui.jsonViewer(obj, { expandDepth: 5 }));
        }
        case 'request-xml': return h('textarea', { class: 'xml', key: `${this.position}-xml`, spellcheck: false, value: this.xmlText || '', onInput: (e) => { this.xmlText = e.target.value; } });
        case 'request-product-xml': return h('textarea', { class: 'xml', readOnly: true, spellcheck: false, value: this.reportXml || '' });
        default: return null;
      }
    }

    renderVdaUpdate() {
      const out = [];
      if (this.vdaErrorReport) {
        out.push(h('div', { class: 'error-report' }, h('div', { class: 'collection-title' }, 'Error report from Software Refresh'), errorList(this.vdaErrorReport)));
      }
      if (this.vdaUpdateProduct.loaded()) {
        const c = this.editorCtx(this.vdaUpdateProduct, { readOnly: true, selectable: true, forceExpanded: true, onlyDirty: this.vdaOnlyDirty });
        out.push(h('div', { class: 'mode-caption' }, 'Select the changes to write to VDA. A Software Refresh has been applied to the changed product.'));
        out.push(h('div', { class: 'product-editor' }, [TR.editors.nodesEditor(c), TR.editors.variantEditor(c), TR.editors.sNoteEditor(c), TR.editors.parameterEditor(c)].filter(Boolean)));
      }
      return h('div', null, out);
    }

    renderToKit() {
      const tk = this.toKitProduct;
      const d = tk.delta();
      const info = tk.info();
      const rowsRemove = [], rowsAssign = [], warnings = [];
      const chk = (key, label) => h('label', { class: 'chk block op-line' }, h('input', { type: 'checkbox', checked: !!tk.ui.sel[key], onChange: (e) => { tk.ui.sel[key] = e.target.checked; TR.app.refresh(); } }), ' ', label);
      const tea2Only = tk.isTea2Only();
      d.nodes.forEach((op) => {
        const key = TR.ProductVM.opKey(op);
        if (op.type === E.Op.RemoveNode) { rowsRemove.push(chk(key, `Remove Node ${M.derivedName(op.identifier)}`)); return; }
        const n = tk.current.nodes.find((x) => M.idMatch(x.nodeIdentifier, op.nodeIdentifier || (op.value && op.value.nodeIdentifier)));
        if (!n) return;
        if (tea2Only && op.type === E.Op.AssignTea2Node) {
          const o = tk.original.nodes.find((x) => M.idMatch(x.nodeIdentifier, op.nodeIdentifier));
          const nk = M.idKey(op.nodeIdentifier);
          M.singles(0).forEach(([sk, , , cap]) => {
            if (!op[sk]) return;
            const pk = `part:${nk}:${sk}:`;
            const part = n[sk] || (o && o[sk]);
            if (op[sk].type === E.PartOps.Part.remove || op[sk].type === E.PartOps.Hardware.remove) rowsRemove.push(chk(pk, `Remove P/N ${n.name} [${cap}(${part && part.fieldNumber || ''})]=${o && o[sk] ? o[sk].number : ''}`));
            else rowsAssign.push(chk(pk, `Assign P/N ${n.name} [${cap}(${part && part.fieldNumber || ''})]=${part ? part.number : ''}`));
          });
          M.lists(0).forEach(([lk, , , cap]) => (op[lk] || []).forEach((lo, i) => {
            const pk = `part:${nk}:${lk}:${i}`;
            const val = lo.value || (o && (o[lk] || []).find((x) => M.partMatch(x, lo.identifier)));
            if (lo.type === E.PartOps.Part.remove) {
              const sameField = (op[lk] || []).some((x, j) => j !== i && x.type !== E.PartOps.Part.remove && x.value && val && x.value.fieldNumber === val.fieldNumber);
              if (!sameField) rowsRemove.push(chk(pk, `Remove P/N ${n.name} [${cap}(${val && val.fieldNumber || ''})]=${val ? val.number : ''}`));
            } else rowsAssign.push(chk(pk, `Assign P/N ${n.name} [${cap}(${val && val.fieldNumber || ''})]=${val ? val.number : ''}`));
          }));
          return;
        }
        if (!n.nodeTemplateDocument || !n.nodeTemplateDocument.number) { warnings.push(`No Operation for ${M.nodeSummary(n)} has been added because it doesn't have Document Number`); return; }
        rowsAssign.push(chk(key, `Assign Node Template ${M.nodeSummary(n)}`));
        const nk = M.idKey(n.nodeIdentifier);
        if (op.primaryBootloader) rowsAssign.push(h('div', { class: 'indent' }, chk('pbl:' + nk, `Primary Bootloader ${op.primaryBootloader.value ? op.primaryBootloader.value.number : '(removed)'}`)));
        if (op.secondaryBootloader) rowsAssign.push(h('div', { class: 'indent' }, chk('sbl:' + nk, `Secondary Bootloader ${op.secondaryBootloader.value ? op.secondaryBootloader.value.number : '(removed)'}`)));
      });
      const vrows = tk.variantRows();
      d.productSpecification.variants.forEach((op) => {
        if (op.type === E.Op.RemoveVariant && vrows.some((r) => r.status === 'removed' && r.replacedBy && M.variantKey(r.v) === M.variantKey(op.value))) return;
        (op.type === E.Op.RemoveVariant ? rowsRemove : rowsAssign).push(chk(TR.ProductVM.opKey(op), `${op.type === E.Op.RemoveVariant ? 'Remove' : 'Assign'} Variant ${op.value.symbol}${op.value.description ? ' - ' + op.value.description : ''}`));
      });
      d.productSpecification.sNotes.forEach((op) => (op.type === E.Op.RemoveSNote ? rowsRemove : rowsAssign).push(chk(TR.ProductVM.opKey(op), `${op.type === E.Op.RemoveSNote ? 'Remove' : 'Assign'} S-Note ${op.value.value}${op.value.name ? ' - ' + op.value.name : ''}`)));
      d.parameters.forEach((op) => (op.type === E.Op.RemoveParameter ? rowsRemove : rowsAssign).push(chk(TR.ProductVM.opKey(op), `${op.type === E.Op.RemoveParameter ? 'Remove Parameter ' + op.value.code : 'Assign Parameter ' + M.paramDisplay(op.value)}`)));
      return h('div', { class: 'to-kit' },
        h('h4', null, 'Condition:'), h('ul', null, h('li', null, `Context ${info.context ? info.context.name : '(none)'}`), h('li', null, `Chassis ${tk.chassisString()}`)),
        warnings.map((w) => h('div', { class: 'warning-text' }, '⚠ ', w)),
        h('h4', null, 'Operations:'), rowsRemove.length + rowsAssign.length ? h('div', null, rowsRemove, rowsAssign) : h('div', { class: 'muted' }, 'No operations.'));
    }

    responseVm(r) {
      const key = TR.chassis.chassisKey(r);
      if (this.responseVms[key]) return this.responseVms[key];
      const it = this.items.find((x) => TR.chassis.sameChassis(M.chassisOf(x.product), r)) || this.items[0];
      const vm = new TR.ProductVM('resp' + Object.keys(this.responseVms).length);
      vm.load(it ? it.product : M.ensureShape({}));
      vm.applyDelta(r.delta, false);
      vm.ui.sections = { info: false, nodes: true, variants: true, snotes: true, params: true, notifications: false };
      this.responseVms[key] = vm;
      return vm;
    }

    renderResponse() {
      return h('div', { class: 'response-view' }, (this.response || []).map((r) => {
        const vm = this.responseVm(r);
        const d = r.delta || M.emptyDelta();
        const assignedNodeKeys = new Set(d.nodes.filter((o) => o.value).map((o) => M.idKey(o.value.nodeIdentifier)));
        const ap = d.parameters.filter((o) => o.type === E.Op.AssignParameter), rp = d.parameters.filter((o) => o.type === E.Op.RemoveParameter);
        const vs = d.productSpecification.variants || [], ss = d.productSpecification.sNotes || [];
        const c = this.editorCtx(vm, { readOnly: true, forceExpanded: true, prefix: `${this.position}-resp-${TR.chassis.chassisKey(r).replace('|', '_')}` });
        const tiles = (list, cls, fn) => h('div', { class: 'tile-grid' }, list.map((o) => h('div', { class: ['tile', cls], title: fn(o)[1] }, h('span', { class: 'tile-sym' }, fn(o)[0]))));
        const sectionBox = (title, content) => h('div', { class: 'editor' }, h('div', { class: 'ed-header expanded' }, h('span', { class: 'ed-title' }, title)), h('div', { class: 'ed-body' }, content));
        const groupedNotes = {};
        (r.releaseNotes || []).forEach((n) => { (groupedNotes[n.source] = groupedNotes[n.source] || []).push(n.text); });
        const showInfo = r.limitedValidation || d.productSpecification.baselineName;
        return h('div', { class: 'response-item' },
          h('div', { class: 'chassis-text' }, `Chassis: ${r.chassisSeries} - ${r.chassisNumber}`), h('hr'),
          r.errorReport ? errorList(r.errorReport) : null,
          showInfo ? sectionBox('Response Information', h('table', { class: 'kv' }, h('tbody', null, h('tr', null, h('th', null, 'Limited validation performed'), h('td', null, r.limitedValidation ? 'Yes' : 'No')),
            d.productSpecification.baselineName ? h('tr', null, h('th', null, 'Baseline'), h('td', null, h('a', { href: TR.server.baselineUrl(d.productSpecification.baselineGuid) }, d.productSpecification.baselineName))) : null))) : null,
          assignedNodeKeys.size ? TR.editors.nodesEditor(Object.assign({}, c, { nodeKeys: assignedNodeKeys, titles: { nodes: 'Assigned Nodes' } })) : null,
          (r.affectedNodes || []).length ? sectionBox('Affected Nodes', h('ul', { class: 'plain' }, r.affectedNodes.map((id) => h('li', null, M.derivedName(id))))) : null,
          (r.dependentNodes || []).length ? sectionBox('Dependent Nodes', h('ul', { class: 'plain' }, r.dependentNodes.map((id) => h('li', null, M.derivedName(id))))) : null,
          vs.some((o) => o.type === 6) ? sectionBox('Assigned Variants', tiles(vs.filter((o) => o.type === 6), 'st-added', (o) => [o.value.symbol, o.value.description])) : null,
          vs.some((o) => o.type === 7) ? sectionBox('Removed Variants', tiles(vs.filter((o) => o.type === 7), 'st-removed', (o) => [o.value.symbol, o.value.description])) : null,
          ss.some((o) => o.type === 8) ? sectionBox('Assigned S-Notes', tiles(ss.filter((o) => o.type === 8), 'st-added', (o) => [o.value.value, o.value.name])) : null,
          ss.some((o) => o.type === 9) ? sectionBox('Removed S-Notes', tiles(ss.filter((o) => o.type === 9), 'st-removed', (o) => [o.value.value, o.value.name])) : null,
          ap.length ? TR.editors.parameterEditor(Object.assign({}, c, { paramKeys: new Set(ap.map((o) => M.paramKey(o.value))), titles: { params: 'Assigned Parameters' } })) : null,
          rp.length ? sectionBox('Removed Parameters', tiles(rp, 'st-removed', (o) => [o.value.code, M.paramDisplay(o.value)])) : null,
          Object.keys(groupedNotes).length ? sectionBox('Release Notes', Object.keys(groupedNotes).map((g) => h('div', { class: 'release-group' }, h('strong', null, g), h('ul', null, groupedNotes[g].map((t) => h('li', null, t)))))) : null,
          !M.hasDelta(d) && !r.errorReport ? h('div', { class: 'muted pad' }, 'The response contains no changes.') : null);
      }));
    }
  }

  function errorList(report) {
    return h('ul', { class: 'error-list' }, (report.errors || []).map((e) => h('li', { class: E.SeverityClass[e.severity === undefined ? 0 : e.severity] }, e.severity === 0 ? '⛔ ' : e.severity === 1 ? '⚠ ' : 'ℹ ', e.text)));
  }

  TR.Pane = Pane;
  TR.defaultRequest = defaultRequest;
})();
