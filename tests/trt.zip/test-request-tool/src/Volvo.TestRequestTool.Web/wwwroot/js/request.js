/* request-view popup (RequestViewModel): builds Software / Conversion Kit / Spare Cab / Available Updates /
   Production & Development Breakdown requests, runs them and routes the response to a pane. */
(function () {
  'use strict';
  const TR = window.TR;
  const E = TR.enums;
  const M = TR.model;
  const { h, clone } = TR.util;
  const ui = TR.ui;
  const RT = E.RequestType;

  const ENDPOINTS = {
    0: ['AftermarketRequest/RequestSoftwareWithXml', 'AftermarketRequest/GetSoftwareRequestXml', 'request'],
    2: ['AftermarketRequest/RequestKitWithXml', 'AftermarketRequest/GetKitRequestXml', 'request'],
    4: ['AftermarketRequest/RequestSpareCabWithXml', 'AftermarketRequest/GetSpareCabRequestXml', 'request'],
    7: ['AftermarketRequest/RequestAvailableUpdatesWithXml', 'AftermarketRequest/GetAvailableUpdatesRequestXml', 'request'],
    5: ['SoftwareBreakdown/RequestProductionSoftwareBreakdownWithXml', 'SoftwareBreakdown/GetProductionSoftwareBreakdownRequestXml', 'requestJson'],
    6: ['SoftwareBreakdown/RequestDevelopmentSoftwareBreakdownWithXml', 'SoftwareBreakdown/GetDevelopmentSoftwareBreakdownRequestXml', 'requestJson'],
    8: ['ProductUpdateService/RequestWithXml', 'ProductUpdateService/GetRequestJson', 'request'],
    9: ['AvailableProductUpdates/RequestWithXml', 'AvailableProductUpdates/GetRequestJson', 'request'],
  };
  const vis = {
    operation: [0], scenario: [0, 7, 8, 9], kitScenario: [2], kitNumbers: [2], language: [0, 2, 7, 9], remote: [0, 2], multiNode: [0, 7, 9], serviceKit: [2], pbl: [0, 2, 7, 9],
    pusVersion: [8], pusOperation: [8], apuVersion: [9], apuCriteria: [9], apuFlags: [9],
    simKit: [0, 1, 2, 3], baseline: [4], baselineIdentifier: [6], factory: [5], limited: [0, 2], preReleased: [5], actionCriteria: [7], spareCab: [4], limitTo: [0, 2], extended: [0], groupAdmin: [0, 2],
  };
  const show = (k, t) => vis[k].includes(t);
  /** What the request is for, in plain words: [request type, task, contract name, group]. The service contracts need the server. */
  const TASKS = [
    [8, 'Update to the latest service pack', 'Product Update Service', 'change', true],
    [0, 'Find the software it needs', 'Software request', 'change'],
    [2, 'Fit a conversion kit', 'Conversion kit', 'change'],
    [4, 'Replace the cab', 'Spare cab', 'change'],
    [9, 'See what product updates exist', 'Available Product Updates', 'look', true],
    [7, 'See what updates exist', 'Available updates', 'look'],
    [5, 'List the software it was built with', 'Production breakdown', 'look'],
    [6, 'List the development software', 'Development breakdown', 'look'],
  ];
  const tasks = () => TASKS.filter((x) => !x[4] || TR.backend);
  const DEFAULT_APU = ['SoftwareReplacements.General', 'SoftwareReplacements.ServicePackGeneral', 'HardwareReplacements'];

  let cache = { languages: null, factories: null };

  function kitChassis(pane, rq) {
    const out = [];
    pane.items.forEach((it) => {
      const ch = M.chassisOf(it.product);
      const e = (rq.conversionKitNumbers || []).find((k) => TR.chassis.sameChassis(k, ch));
      TR.util.splitList(e ? e.conversionKitNumber : '', /[,;\s]+/).forEach((n) => out.push({ conversionKitNumber: n, chassisSeries: ch.chassisSeries, chassisNumber: ch.chassisNumber }));
    });
    return out;
  }

  function buildPayload(pane) {
    pane.saveCurrentProductState();
    const rq = pane.request;
    const t = Number(rq.selectedRequestType);
    const products = pane.getCurrentProducts();
    const selected = pane.getCurrentSelectedProduct();
    const requestedNodes = pane.allRequestedNodes();
    const model = Object.assign(clone(rq), { requestedNodes });
    let p;
    if (t === RT.Software) {
      p = { allowLimitedValidation: rq.allowLimitedValidation, enableMultiNodeBehavior: rq.enableMultiNodeBehavior, remoteRequest: Number(rq.selectedRemote), softwareRequestOperation: Number(rq.selectedSoftwareRequestOperation), products, requestedNodes, scenario: Number(rq.selectedScenario), simulationKitName: rq.simulationKitName, pblUpdateCapable: rq.pblUpdateCapable, selectedLanguageCode: rq.selectedLanguageCode, limitTo: rq.limitTo, extendedValidation: !!(rq.limitTo && rq.extendedValidation), groupAdministrativeParameters: rq.groupAdministrativeParameters };
    } else if (t === RT.ConversionKit) {
      p = { remoteRequest: Number(rq.selectedRemote), scenario: Number(rq.selectedKitScenario), onlyServiceKitAllowed: rq.onlyServiceKitAllowed, products, conversionKitNumbers: kitChassis(pane, rq), selectedLanguageCode: rq.selectedLanguageCode, simulationKitName: rq.simulationKitName, pblUpdateCapable: rq.pblUpdateCapable, allowLimitedValidation: rq.allowLimitedValidation, limitTo: rq.limitTo, groupAdministrativeParameters: rq.groupAdministrativeParameters };
    } else if (t === RT.SpareCab) {
      const ch = M.chassisOf(selected);
      p = { baselineGuid: rq.selectedBaseline, product: selected, requestedNodes: requestedNodes.filter((r) => TR.chassis.sameChassis(r, ch)), removedNodes: rq.selectedSpareCabRemovedNodes, spareCabNodes: (rq.selectedSpareCabRequestedNodes || []).map((pos) => { const n = selected.nodes.find((x) => M.derivedPosition(x.nodeIdentifier) === pos); return n ? { nodeIdentifier: n.nodeIdentifier } : null; }).filter(Boolean), softwareRelatedHardwares: rq.softwareRelatedHardwares || [] };
    } else if (t === RT.AvailableUpdates) {
      p = { actionCriteriaTypes: (rq.selectedActionCriteriaTypes || []).map(Number), products, requestedNodes, enableMultiNodeBehavior: rq.enableMultiNodeBehavior, scenario: Number(rq.selectedScenario), pblUpdateCapable: rq.pblUpdateCapable, selectedLanguageCode: rq.selectedLanguageCode };
    } else if (t === RT.ProductUpdateService) {
      // Product Update Service JSON contract: 1.0 always updates to the service pack, 2.0 reads criteria.operation.operationType.
      const version = rq.pusSchemaVersion || (TR.prefs && TR.prefs.get('pusVersion')) || '2.0';
      const criteria = { scenario: E.ScenarioNames[Number(rq.selectedScenario)] };
      if (version === '1.0') criteria.updateTo = { latestServicePack: true }; else criteria.operation = { operationType: rq.pusOperation || 'UpdateToServicePack' };
      p = { schemaVersion: version, criteria, products, languageCode: rq.selectedLanguageCode };
    } else if (t === RT.AvailableProductUpdates) {
      // Available Product Updates JSON contract: actionCriteria is a comma-separated string in 1.0 and a string array in 1.1.
      const version = rq.apuVersion || (TR.prefs && TR.prefs.get('apuVersion')) || '1.1';
      const actions = rq.apuActionCriteria || DEFAULT_APU;
      p = { contractVersion: version, products, requestedNodes, criteria: { scenario: E.ScenarioNames[Number(rq.selectedScenario)], actionCriteria: version === '1.0' ? actions.join(',') : actions,
        enableMultiNodeBehavior: rq.enableMultiNodeBehavior !== false, pblUpdateCapable: !!rq.pblUpdateCapable, languageCode: rq.selectedLanguageCode, semsSupport: rq.apuSemsSupport || 'None',
        includeUpdatePurposes: rq.apuIncludeUpdatePurposes !== false, includeReleaseNoteSource: rq.apuIncludeReleaseNoteSource !== false, includeDocumentNumberOnlyChange: !!rq.apuIncludeDocumentNumberOnlyChange } };
    } else if (t === RT.ProductionBreakdown) {
      p = { product: selected, assemblyFactoryCode: rq.selectedFactory, introductionWeek: rq.introductionWeek, includePreReleasedSNotes: rq.includePreReleasedSNotes };
    } else if (t === RT.DevelopmentBreakdown) {
      p = { product: selected, baselineIdentifier: rq.baselineIdentifier, baselineVersion: rq.baselineVersion };
    } else return null;
    p.requestModel = model;
    return { t, payload: p, products };
  }

  async function runRequest(pane, targetSame) {
    const b = buildPayload(pane);
    if (!b || !ENDPOINTS[b.t]) { ui.alert('Request type not yet implemented.'); return; }
    const [endpoint, , key] = ENDPOINTS[b.t];
    const r = await TR.app.run(() => TR.api(endpoint, { [key]: JSON.stringify(b.payload) }), `Running ${E.RequestTypeNames[b.t]} request...`);
    if (!r.success) return;
    const target = targetSame ? pane : pane.other();
    const vdaByChassis = {};
    pane.items.forEach((it) => { if (it.vda) vdaByChassis[TR.chassis.chassisKey(M.chassisOf(it.product))] = it.vda; });
    if (b.t === RT.ProductionBreakdown || b.t === RT.DevelopmentBreakdown) {
      const item = r.item.item[0];
      target.setProducts([item.product], { responseXml: r.item.xml, mode: 'product' });
      target.setDefaultRequest();
      if (target.request.selectedRequestType === RT.ProductionBreakdown) target.request.selectedRequestType = RT.Software;
      ui.summary.addInformation(`${E.RequestTypeNames[b.t]} completed for ${M.chassisText(item.product)}${item.product.breakdownInformation.baseline ? ` (baseline ${item.product.breakdownInformation.baseline})` : ''}.`);
    } else if (b.t === RT.AvailableUpdates) {
      target.setProducts([], { availableUpdate: r.item.availableUpdateItem, responseXml: r.item.xml });
    } else if (b.t === RT.AvailableProductUpdates) {
      target.setProducts([], { availableUpdate: r.item.availableUpdateItem, responseXml: r.item.xml });
      if (TR.testRequest && TR.testRequest.showServiceResult) TR.testRequest.showServiceResult(r.item.record);
    } else {
      const deltas = {};
      r.item.item.forEach((x) => { deltas[TR.chassis.chassisKey(x)] = x.delta; });
      const selCh = pane.product.loaded() ? pane.product.chassis() : null;
      target.setProducts(b.products, { deltas, response: r.item.item, responseXml: r.item.xml, vdaByChassis, selectChassis: selCh });
      const errs = r.item.item.filter((x) => x.errorReport && x.errorReport.errors.some((e) => e.severity === 0)).length;
      if (errs) ui.summary.addWarning(`The response contains an error report for ${errs} product(s).`);
    }
    // The transaction id is kept in the request (History and Server calls show it); no banner for it.
    TR.app.refresh();
  }

  async function getRequestXml(pane) {
    const b = buildPayload(pane);
    if (!b || !ENDPOINTS[b.t]) { ui.alert('Request type not yet implemented.'); return; }
    const [, endpoint, key] = ENDPOINTS[b.t];
    const r = await TR.app.run(() => TR.api(endpoint, { [key]: JSON.stringify(b.payload) }), 'Getting request XML');
    if (!r.success) return;
    pane.requestOrProductXml = r.item;
    pane.xmlText = typeof r.item === 'string' ? r.item : JSON.stringify(r.item, null, 2);
    pane.xmlType = 'request';
    pane.mode = 'request-xml';
    TR.app.refresh();
  }

  function spareCabPopup(pane, onDone) {
    let order = '';
    let loading = false;
    const m = ui.modal({
      title: 'Get Spare Cab Variants and Parts', width: 420,
      body: () => h('div', { class: 'form' }, h('label', null, 'Order Number', h('input', { key: 'sparecab-order', value: order, placeholder: 'e.g. 99850557', disabled: loading, onInput: (e) => { order = e.target.value; }, onKeydown: (e) => { if (e.key === 'Enter') get(); } })),
        h('div', { class: 'small muted' }, 'Simulated CBR orders: 99850557 (A 550555), 99850558 (FH 123456)')),
      buttons: () => [{ label: 'Cancel', disabled: loading }, { label: 'Get', primary: true, disabled: loading, onClick: () => get() }],
    });
    async function get() {
      loading = true; m.render();
      const r = await TR.app.run(() => TR.api('TestRequest2000/GetSpareCabData', { orderNumber: order.trim() }), 'Getting spare cab data');
      loading = false;
      if (!r.success) { if (!m.closed) m.render(); return; }
      m.close();
      pane.request.softwareRelatedHardwares = r.item.softwareRelatedHardwares;
      let changed = 0;
      r.item.variants.forEach((v) => { if (!pane.product.hasVariant(v)) { pane.product.addVariant(v); changed++; } });
      ui.summary.addInformation(`Spare cab order ${r.item.order.orderNumber} (${r.item.order.chassis}): ${r.item.softwareRelatedHardwares.length} software related hardware part(s) stored, ${changed} variant(s) added or replaced.`);
      onDone();
      TR.app.refresh();
    }
  }

  /** What the request will do, in one plain sentence. Pure apart from reading the product's chassis. */
  function plainSummary(pane, rq, t) {
    const ch = pane.product.chassisString() + (pane.items.length > 1 ? ` and ${pane.items.length - 1} more` : '');
    const pusOp = (rq.pusSchemaVersion || (TR.prefs && TR.prefs.get('pusVersion')) || '2.0') === '2.0' ? (rq.pusOperation || 'UpdateToServicePack') : 'UpdateToServicePack';
    switch (t) {
      case 0: return `Find the software ${ch} needs (${String(E.SoftwareRequestOperationNames[rq.selectedSoftwareRequestOperation] || 'software request').toLowerCase()}).`;
      case 2: return `Fit a conversion kit to ${ch}.`;
      case 4: return `Get the software for a spare cab on ${ch}.`;
      case 5: return `List the software ${ch} was built with.`;
      case 6: return `List the development software for ${ch}.`;
      case 7: return `List the updates available for ${ch}.`;
      case 8: return pusOp === 'Repair' ? `Repair the software on ${ch}.` : `Update ${ch} to the latest service pack.`;
      case 9: return `List the product updates available for ${ch}.`;
      default: return `Send a request for ${ch}.`;
    }
  }

  async function open(pane) {
    const rq = pane.request;
    let baselines = null;
    let blVersions = [];
    const info = pane.product.info();
    const ctx = info.context;
    const loadLists = async () => {
      if (!cache.languages) { const r = await TR.api('TestRequest2000/GetLanguageCodeSelectList', {}); cache.languages = r.success ? r.item : []; }
      if (!cache.factories) { const r = await TR.api('Factory/LoadAll', {}); cache.factories = r.success ? r.item : []; }
      const r = await TR.api('Baseline/GetBaselines', { contextIds: ctx ? [ctx.id] : [], states: [3, 4, 5] });
      baselines = r.success ? r.item : [];
      if (rq.baselineIdentifier) { const v = await TR.api('SoftwareBreakdown/GetBaselineVersions', { baselineIdentifier: rq.baselineIdentifier }); blVersions = v.success ? v.item : []; }
      if (!m.closed) m.render();
    };
    const set = (k, v) => { rq[k] = v; m.render(); };
    const renderSoon = TR.util.debounce(() => { if (!m.closed) m.render(); }, 200);
    const field = (label, ctl, help) => h('div', { class: 'rq-field' }, h('label', { class: 'rq-label' }, label, help ? h('span', { class: 'help', title: help }, ' (?)') : null), ctl);
    const check = (label, k, opts) => h('label', Object.assign({ class: 'chk block' }, opts && opts.title ? { title: opts.title } : {}), h('input', { type: 'checkbox', checked: !!rq[k], disabled: opts && opts.disabled, onChange: (e) => set(k, e.target.checked) }), ' ', label, opts && opts.help ? h('span', { class: 'help', title: opts.help }, ' (?)') : null);
    const removedNodes = pane.product.loaded() ? pane.product.nodeRows().filter((r) => r.status === 'removed').map((r) => r.node) : [];
    const productNodes = pane.product.loaded() ? pane.product.current.nodes : [];
    const multi = (list, k, empty) => h('div', { class: 'multiselect' }, list.length ? list.map(([v, label]) => h('label', { class: 'chk block' }, h('input', { type: 'checkbox', checked: (rq[k] || []).map(String).includes(String(v)), onChange: (e) => { const cur = (rq[k] || []).filter((x) => String(x) !== String(v)); if (e.target.checked) cur.push(v); set(k, cur); } }), ' ', label)) : h('div', { class: 'muted small' }, empty));
    let advanced = false, picking = false;
    const m = ui.modal({
      title: `Request – ${pane.product.chassisString()}`, width: 340, class: 'request-view',
      body: () => {
        const t = Number(rq.selectedRequestType);
        const f = [], a = [];
        // What to do: the chosen task on one line with Change; the list groups changing the software and only looking.
        const task = tasks().find((x) => x[0] === t) || [t, 'Request type ' + t, '', 'change'];
        f.push(field('What to do', !picking
          ? h('div', { class: 'rq-task' }, h('span', null, h('strong', null, task[1]), h('small', { class: 'muted' }, task[2])),
            h('button', { type: 'button', class: 'jr-link', 'aria-expanded': 'false', onClick: () => { picking = true; m.render(); } }, 'Change'))
          : h('div', { class: 'rq-tasks', role: 'radiogroup', 'aria-label': 'What to do' }, [['change', 'Change the software'], ['look', 'Look, without changing']].map(([g, label]) => [
            h('p', { class: 'rq-task-group' }, label),
            tasks().filter((x) => x[3] === g).map((x) => h('label', { class: 'rq-task-opt' + (x[0] === t ? ' is-on' : '') },
              h('input', { type: 'radio', name: 'rq-task', value: String(x[0]), checked: x[0] === t, onChange: () => { picking = false; set('selectedRequestType', x[0]); } }),
              h('span', null, h('strong', null, x[1]), h('small', { class: 'muted' }, x[2]))))]))));
        if (show('pusVersion', t)) a.push(field('Schema version', ui.select([['2.0', '2.0 (Update to service pack or Repair)'], ['1.0', '1.0 (Update to service pack)']], rq.pusSchemaVersion || (TR.prefs && TR.prefs.get('pusVersion')) || '2.0', (v) => set('pusSchemaVersion', v)), 'ProductUpdateService contract version. Supports T3 HPC nodes with execution environments.'));
        if (show('pusOperation', t) && (rq.pusSchemaVersion || (TR.prefs && TR.prefs.get('pusVersion')) || '2.0') === '2.0') a.push(field('Operation', ui.select([['UpdateToServicePack', 'Update to service pack'], ['Repair', 'Repair']], rq.pusOperation || 'UpdateToServicePack', (v) => set('pusOperation', v))));
        if (show('apuVersion', t)) a.push(field('Contract version', ui.select([['1.1', '1.1 (action criteria array)'], ['1.0', '1.0 (comma-separated action criteria)']], rq.apuVersion || (TR.prefs && TR.prefs.get('apuVersion')) || '1.1', (v) => set('apuVersion', v)), 'GetAvailableProductUpdates contract version. Supports T3 HPC nodes.'));
        if (show('apuCriteria', t)) {
          if (!rq.apuActionCriteria) rq.apuActionCriteria = DEFAULT_APU.slice();
          f.push(field('Action criteria', multi(E.ApuActionCriteria.map((a) => [a, a.replace('SoftwareReplacements.', 'Software · ')]), 'apuActionCriteria', '- No action criteria selected -')));
        }
        if (show('operation', t)) a.push(field('Operation', ui.select([1, 2, 3, 4, 5].map((v) => [v, E.SoftwareRequestOperationNames[v]]), rq.selectedSoftwareRequestOperation, (v) => set('selectedSoftwareRequestOperation', Number(v)))));
        if (show('scenario', t)) a.push(field('Scenario', ui.select([1, 2, 3, 4, 5].map((v) => [v, E.ScenarioNames[v]]), rq.selectedScenario, (v) => set('selectedScenario', Number(v)))));
        if (show('kitScenario', t)) a.push(field('Scenario', ui.select([1, 2, 3, 4].map((v) => [v, E.KitScenarioNames[v]]), rq.selectedKitScenario, (v) => set('selectedKitScenario', Number(v)))));
        if (show('kitNumbers', t)) {
          f.push(field('Kit part number', h('div', null, pane.items.map((it) => {
            const ch = M.chassisOf(it.product);
            const e = (rq.conversionKitNumbers || []).find((k) => TR.chassis.sameChassis(k, ch));
            return h('div', null, pane.items.length > 1 ? h('div', { class: 'small muted' }, M.chassisText(it.product)) : null,
              h('input', { size: 28, key: `kit-${TR.chassis.chassisKey(ch)}`, placeholder: 'Kit part number', list: 'kit-numbers', value: e ? e.conversionKitNumber : '', onInput: (ev) => {
                rq.conversionKitNumbers = (rq.conversionKitNumbers || []).filter((k) => !TR.chassis.sameChassis(k, ch)).concat([{ chassisSeries: ch.chassisSeries, chassisNumber: ch.chassisNumber, conversionKitNumber: ev.target.value }]);
              } }));
          }), h('div', { class: 'small muted' }, 'Kits: ', TR.server.state.kits.map((k) => k.partNumber).join(', ')))));
        }
        if (show('language', t)) a.push(field('Language code', ui.select((cache.languages || [{ text: rq.selectedLanguageCode, value: rq.selectedLanguageCode }]).map((l) => [l.value, l.text]), rq.selectedLanguageCode, (v) => set('selectedLanguageCode', v))));
        if (show('remote', t)) a.push(field('Remote availability', ui.select([0, 1, 2, 3].map((v) => [v, E.RemoteNames[v]]), rq.selectedRemote, (v) => set('selectedRemote', Number(v)))));
        if (show('multiNode', t)) a.push(check('Multi node behavior', 'enableMultiNodeBehavior'));
        if (show('serviceKit', t)) a.push(check('Only service kit allowed', 'onlyServiceKitAllowed'));
        if (show('pbl', t)) a.push(check('PBL update capable', 'pblUpdateCapable'));
        if (show('simKit', t)) a.push(field('Simulation kit', h('input', { key: 'rq-simkit', placeholder: 'Simulation kit name', list: 'kit-numbers', value: rq.simulationKitName, onInput: (e) => { rq.simulationKitName = e.target.value; } })));
        if (show('baseline', t)) {
          f.push(field('Baseline state', ui.select([['', 'All'], [3, E.BaselineStateNames[3]], [4, E.BaselineStateNames[4]], [5, E.BaselineStateNames[5]]], rq.selectedBaselineState, (v) => set('selectedBaselineState', v))));
          const bls = (baselines || []).filter((b) => !rq.selectedBaselineState || String(b.state) === String(rq.selectedBaselineState));
          f.push(field('Baseline', baselines === null ? h('span', { class: 'muted small' }, 'Loading...') : ui.select([['', '']].concat(bls.map((b) => [b.guid, `${b.name} (${b.version})`])), rq.selectedBaseline || '', (v) => set('selectedBaseline', v || null), { style: { width: '200px' } })));
        }
        if (show('baselineIdentifier', t)) {
          f.push(field('Baseline identifier', h('input', { key: 'rq-blid', placeholder: 'Enter identifier', list: 'baseline-identifiers', value: rq.baselineIdentifier, onChange: async (e) => {
            rq.baselineIdentifier = e.target.value;
            const v = await TR.api('SoftwareBreakdown/GetBaselineVersions', { baselineIdentifier: rq.baselineIdentifier });
            blVersions = v.success ? v.item : [];
            rq.baselineVersion = blVersions[0] || '';
            m.render();
          } }), h('datalist', { id: 'baseline-identifiers' }, TR.util.uniq(TR.db.baselines.map((b) => b.identifier)).map((x) => h('option', { value: x })))));
          if (blVersions.length) f.push(h('div', { class: 'small muted' }, `Baseline version: ${rq.baselineVersion} (available: ${blVersions.join(', ')})`));
        }
        if (show('factory', t)) {
          f.push(field('Factory', ui.select([['', '']].concat((cache.factories || []).map((x) => [x.code, `${x.name} (${x.code})`])), rq.selectedFactory, (v) => set('selectedFactory', v))));
          f.push(field('Introduction week', h('input', { key: 'rq-week', placeholder: 'YYYYWW', value: rq.introductionWeek, onInput: (e) => { rq.introductionWeek = e.target.value; } })));
        }
        if (show('apuFlags', t)) {
          for (const [k, label] of [['apuIncludeUpdatePurposes', 'Include update purposes'], ['apuIncludeReleaseNoteSource', 'Include release note source'], ['apuIncludeDocumentNumberOnlyChange', 'Include document-number-only changes']]) {
            if (rq[k] === undefined) rq[k] = k !== 'apuIncludeDocumentNumberOnlyChange';
            f.push(check(label, k));
          }
          f.push(field('SEMS support', ui.select([['None', 'None'], ['Inclusive', 'Inclusive'], ['Exclusive', 'Exclusive']], rq.apuSemsSupport || 'None', (v) => set('apuSemsSupport', v))));
        }
        if (show('limited', t)) a.push(check('Allow limited validation', 'allowLimitedValidation'));
        if (show('preReleased', t)) a.push(check('Include PreReleased SNotes', 'includePreReleasedSNotes'));
        if (show('actionCriteria', t)) f.push(field('Action criteria types', multi(E.ActionCriteria.map((a) => [a[0], a[2]]), 'selectedActionCriteriaTypes', '- No Action Criterias Selected -')));
        if (show('spareCab', t)) {
          f.push(field('Removed Nodes', multi(removedNodes.map((n) => [M.derivedPosition(n.nodeIdentifier), n.name]), 'selectedSpareCabRemovedNodes', '- No Nodes Selected -'), 'Nodes that have been removed in the product (they are not part of the new cab).'));
          f.push(field('Parameter Nodes', multi(productNodes.map((n) => [M.derivedPosition(n.nodeIdentifier), n.name]), 'selectedSpareCabRequestedNodes', '- No Nodes Selected -'), 'Nodes whose parameters are kept on the spare cab nodes.'));
          f.push(field('Get Spare Cab Data', h('div', null, h('button', { class: 'btn small', onClick: () => spareCabPopup(pane, () => m.render()) }, 'Get'), (rq.softwareRelatedHardwares || []).length ? h('span', { class: 'ok-text', title: `${rq.softwareRelatedHardwares.length} software related hardware part(s)` }, ' ✔') : null)));
        }
        if (show('limitTo', t)) f.push(field('Limit to', h('input', { key: 'rq-limitto', value: rq.limitTo, placeholder: 'e.g. EMS, TECU', onInput: (e) => { rq.limitTo = e.target.value; renderSoon(); } }), 'Comma separated node names, positions or MIDs. Only these nodes are updated.'));
        if (show('extended', t)) a.push(check('Extended Validation', 'extendedValidation', { disabled: !rq.limitTo, help: "Validate nodes outside 'Limit to' as well (enabled when Limit to is set)." }));
        if (show('groupAdmin', t)) a.push(check('Group Administrative Parameters', 'groupAdministrativeParameters'));
        return h('div', { class: 'rq-form' },
          h('p', { class: 'rq-plain', role: 'status' }, TR.icon('info', 14), plainSummary(pane, rq, t)),
          f,
          a.length ? h('details', { class: 'rq-advanced', open: advanced, onToggle: (e) => { advanced = e.target.open; } },
            h('summary', null, 'Advanced', h('span', { class: 'muted small' }, ` · ${a.length} setting${a.length > 1 ? 's' : ''}, defaults work for most requests`)),
            h('div', { class: 'rq-form' }, a)) : null);
      },
      buttons: () => TR.testRequest && TR.testRequest.view !== 'expert' ? [
        // The focused workspace has one result: run it, the response goes to the Check step.
        { label: 'Run the request', primary: true, title: 'Run the request and show the result in the Check step', onClick: (mm) => { mm.close(); TR.request.runRequest(pane, false); } },
        { label: String((ENDPOINTS[Number(rq.selectedRequestType)] || [])[1] || '').endsWith('Json') ? 'Get request JSON' : 'Get XML', onClick: (mm) => { mm.close(); getRequestXml(pane); } },
      ] : [
        pane.position === 'left' ? { label: 'Request ►', primary: true, title: 'Run request, show the response in the right pane', onClick: (mm) => { mm.close(); TR.request.runRequest(pane, false); } } : null,
        pane.position === 'right' ? { label: '◄ Request', primary: true, title: 'Run request, show the response in the left pane', onClick: (mm) => { mm.close(); TR.request.runRequest(pane, false); } } : null,
        { label: 'Request ▼', title: 'Run request, show the response in this pane', onClick: (mm) => { mm.close(); TR.request.runRequest(pane, true); } },
        { label: String((ENDPOINTS[Number(rq.selectedRequestType)] || [])[1] || '').endsWith('Json') ? 'Get request JSON' : 'Get XML', onClick: (mm) => { mm.close(); getRequestXml(pane); } },
      ],
    });
    loadLists();
  }

  TR.request = { open, runRequest, getRequestXml, buildPayload, spareCabPopup, plainSummary, TASKS };
})();
