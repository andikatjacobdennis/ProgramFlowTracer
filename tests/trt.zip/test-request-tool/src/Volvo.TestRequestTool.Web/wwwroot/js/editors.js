/* Product editor components: product-information-editor, nodes-editor (tea2 / tea2+ / bea2body node editors),
   variant-editor, s-note-editor, parameter-editor, notifications-view2, artifactory-info. */
(function () {
  'use strict';
  const TR = window.TR;
  const E = TR.enums;
  const M = TR.model;
  const { h, clone, fmtDate } = TR.util;
  const ui = () => TR.ui;

  // ---------- shared pieces ----------
  function deltaSummary(c) {
    const parts = [];
    if (c.added) parts.push(h('span', { class: 'ds-added' }, `${c.added} added`));
    if (c.removed) parts.push(h('span', { class: 'ds-removed' }, `${c.removed} removed`));
    if (c.replaced) parts.push(h('span', { class: 'ds-replaced' }, `${c.replaced} replaced`));
    if (c.modified) parts.push(h('span', { class: 'ds-modified' }, `${c.modified} modified`));
    if (!parts.length) return h('span', { class: 'delta-summary' }, `(${c.unchanged || 0})`);
    parts.push(h('span', { class: 'ds-unchanged' }, `${c.unchanged || 0} unchanged`));
    const out = [];
    parts.forEach((p, i) => { if (i) out.push('/'); out.push(p); });
    return h('span', { class: 'delta-summary' }, '(', out, ')');
  }
  const isDirtyCounts = (c) => c && c.added + c.removed + c.replaced + c.modified > 0;

  function section(c, id, title, counts, extraHeader, toolbar, body) {
    const expanded = c.forceExpanded || c.pvm.ui.sections[id];
    const header = h('div', {
      class: ['ed-header', expanded && 'expanded', isDirtyCounts(counts) && 'dirty'],
      onClick: (e) => { if (c.forceExpanded || e.target.closest('.no-toggle')) return; c.pvm.ui.sections[id] = !expanded; c.refresh(); },
    }, h('span', { class: 'ed-toggle' }, expanded ? '▼' : '►'), h('span', { class: 'ed-title' }, title), ' ', counts ? deltaSummary(counts) : null, extraHeader || null);
    return h('div', { class: 'editor', id: `${c.prefix}-sec-${id}` }, header, expanded ? [toolbar && !c.readOnly ? toolbar : null, h('div', { class: 'ed-body' }, body)] : null);
  }

  const partLink = (num) => (num || num === 0 ? h('a', { href: `#/Part?number=${num}`, class: 'part-link', title: 'Show part' }, String(num)) : h('span', { class: 'muted' }, '—'));
  function numInput(value, onCommit, opts) {
    opts = opts || {};
    return h('input', {
      class: 'part-input', value: value === null || value === undefined ? '' : String(value), maxlength: opts.maxlength || 8, size: opts.size || 9, key: opts.key, placeholder: opts.placeholder || '',
      onChange: (e) => {
        const v = e.target.value.trim();
        if (opts.allowEmpty && v === '') return onCommit(null);
        if (!/^\d{1,8}$/.test(v)) { ui().alert(`'${v}' is not a valid Part Number. A part number has up to 8 digits.`); e.target.value = value || ''; return; }
        onCommit(Number(v));
      },
      onKeydown: (e) => { if (e.key === 'Enter') e.target.blur(); },
    });
  }
  function textInput(value, onCommit, opts) {
    opts = opts || {};
    return h('input', { class: 'part-input', value: value || '', size: opts.size || 12, key: opts.key, placeholder: opts.placeholder || '', onChange: (e) => onCommit(e.target.value.trim()), onKeydown: (e) => { if (e.key === 'Enter') e.target.blur(); } });
  }
  function shaCell(sha) {
    if (!sha) return h('span', { class: 'muted' }, '');
    return h('button', { class: 'sha', title: `${sha}\nClick to show Artifactory info`, onClick: () => artifactoryPopup(sha) }, sha.slice(0, 8) + '…');
  }
  function sourceText(source) {
    if (!source) return '';
    const parts = [];
    const cond = M.conditionText(source);
    if (cond) parts.push(cond);
    if (source.itemNumber) parts.push('#' + source.itemNumber);
    if (source.demarcation) parts.push(source.demarcation);
    return parts.join(' · ');
  }
  function sourceCell(source) {
    if (!source) return h('span', { class: 'muted small' }, '');
    return h('span', { class: 'source small', title: `Condition: ${M.conditionText(source) || '-'}\nItem number: ${source.itemNumber || '-'}\nDemarcation: ${source.demarcation || '-'}\nBaseline: ${source.baseline || '-'}` }, sourceText(source));
  }
  function notifIcon(list) {
    if (!list || !list.length) return null;
    const sev = Math.min(...list.map((n) => (n.severity === undefined ? 2 : n.severity)));
    return h('span', { class: ['notif-icon', E.SeverityClass[sev]], title: list.map((n) => `${n.text}${n.reason ? ' – ' + n.reason : ''}`).join('\n') }, sev === 0 ? '⛔' : sev === 1 ? '⚠' : 'ℹ');
  }
  const statusLabel = { added: 'added', removed: 'removed', replaced: 'replaced', dirty: 'modified' };

  // ---------- artifactory-info ----------
  async function artifactoryPopup(sha) {
    let state = { loading: true, results: [], i: 0 };
    const m = ui().modal({
      title: 'Artifactory info', width: 560,
      body: () => {
        if (state.loading) return h('div', { class: 'muted' }, 'Loading Artifactory info...');
        if (!state.results.length) return h('div', null, h('div', { class: 'small muted mono' }, sha), h('p', null, 'Not found in Artifactory'));
        const r = state.results[state.i];
        const name = r.path.split('/').pop();
        const rel = r.path.replace(/^\//, '');
        return h('div', null,
          h('div', { class: 'art-nav' }, state.results.length > 1 ? [h('button', { class: 'link-btn', disabled: state.i === 0, onClick: () => { state.i--; m.render(); } }, '◄'), ` (${state.i + 1} of ${state.results.length}) `, h('button', { class: 'link-btn', disabled: state.i >= state.results.length - 1, onClick: () => { state.i++; m.render(); } }, '►')] : null),
          ui().kv([['Name', h('a', { href: '#', onClick: (e) => { e.preventDefault(); ui().alert(`Simulated download of ${name}\nfrom ${r.downloadUri}`); } }, name)], ['Repository', r.repo], ['Path', h('a', { href: '#', onClick: (e) => { e.preventDefault(); ui().alert(`Show in Artifactory (simulated):\n${r.repo}/${rel}`); } }, 'Show in Artifactory')], ['Modified', TR.util.fmtDateTime(r.lastModified)], ['SHA1', h('span', { class: 'mono small' }, sha)]]));
      },
    });
    const res = await TR.api('Artifactory/ChecksumSearch', { sha });
    state = { loading: false, results: res.success ? res.item.results : [], i: 0 };
    if (!m.closed) m.render();
  }

  // ---------- product-information-editor ----------
  function productInformationEditor(c) {
    const p = c.pvm.current;
    const info = p.productSpecification.productInformation;
    const ch = info.chassisSeries || info.chassisNumber ? `Chassis: ${info.chassisSeries || ''} ${info.chassisNumber || ''}` : null;
    const ctx = info.context;
    const extra = h('span', { class: 'info-head' }, ch ? h('strong', null, ch) : h('em', null, 'Chassis number unknown'), ctx ? h('span', { class: 'muted' }, `  Context: ${info.productClassId}: ${ctx.name}`) : info.productClassId ? h('span', { class: 'muted' }, `  Product class: ${info.productClassId} (no context)`) : null);
    const link = (name, url) => (name ? (url ? h('a', { href: url }, name) : name) : null);
    const rows = [
      ['Chassis Series', info.chassisSeries], ['Chassis Number', info.chassisNumber], ['VIN', info.vin], ['Model ID', info.modelId], ['Product Class', info.productClassId],
      ['Context', ctx ? `${ctx.name} (${ctx.id})${ctx.isOnlyTea2 ? ' – TEA2 only' : ''}` : ''], ['Chassis Type', info.chassisType],
      ['Service pack', link(info.servicePackName, info.servicePackUrl)], ['Baseline', link(info.baselineName, info.baselineUrl)],
      ['Delivery Date', fmtDate(info.deliveryDate)], ['Assembly Date', fmtDate(info.assemblyDate)],
      ['Assembly Factory', info.assemblyFactory ? `${info.assemblyFactory}(${info.assemblyFactoryCode || ''})` : ''], ['Release Factory', info.releaseFactory],
      ['Specification Date', fmtDate(info.specificationDate)], ['Introduction Week', info.introductionWeek], ['Company Code', info.companyCode], ['Country of Operation', info.countryOfOperation],
      ['Registration Number', info.registrationNumber], ['Test Status', info.testStatus], ['Information', p.information],
      ['Software related hardware', (p.softwareRelatedHardwares || []).length ? `${p.softwareRelatedHardwares.length} part(s) from spare cab order` : ''],
    ].filter((r) => r[1] !== null && r[1] !== undefined && r[1] !== '');
    if (c.onlyDirty) return null;
    return section(c, 'info', '', null, extra, null, h('table', { class: 'kv info-table' }, h('tbody', null, rows.map(([k, v]) => h('tr', null, h('th', null, k), h('td', null, v))))));
  }

  // ---------- nodes-editor ----------
  let legendCache = null;
  async function legendPopup() {
    if (!legendCache) { const r = await TR.api('TestRequest2000/NodeVersionStatusLegend', {}); legendCache = r.success ? r.item : []; }
    ui().modal({ title: 'Node template status', width: 480, body: h('table', { class: 'grid' }, h('tbody', null, legendCache.map((l) => h('tr', null, h('td', null, h('span', { class: ['status-dot', 'st-' + (l.key || 'none')] })), h('td', null, l.value))))) });
  }

  function nodeRowsFor(c) {
    let rows = c.pvm.nodeRows();
    if (c.nodeKeys) rows = rows.filter((r) => c.nodeKeys.has(r.key));
    if (c.onlyDirty) rows = rows.filter((r) => r.status);
    if (c.filter) rows = rows.filter((r) => M.nodePassesFilter(c.filter, r.node));
    return rows;
  }

  function nodesEditor(c) {
    const pvm = c.pvm;
    const all = pvm.nodeRows();
    const rows = nodeRowsFor(c);
    const counts = { added: 0, removed: 0, replaced: 0, modified: 0, unchanged: 0 };
    (c.nodeKeys ? all.filter((r) => c.nodeKeys.has(r.key)) : all).forEach((r) => { counts[r.status === 'dirty' ? 'modified' : r.status || 'unchanged']++; });
    if (c.onlyDirty && !rows.length) return null;
    const same = pvm.current.nodes.length && pvm.current.nodes.every((n) => n.isSoftwareSame);
    const extra = same ? h('span', { class: 'same-sw', title: 'Same Software for all Nodes' }, '✔') : null;
    const editable = c.editable && !c.readOnly;
    const selectableNodes = all.filter((r) => r.status !== 'removed');
    const allSel = selectableNodes.length && selectableNodes.every((r) => pvm.ui.selectedNodes[r.key]);
    const toolbar = editable ? h('div', { class: 'ed-toolbar' },
      h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: pvm.ui.nodeEditMode, onChange: (e) => { pvm.ui.nodeEditMode = e.target.checked; c.refresh(); } }), ' Edit mode'),
      h('button', { class: 'btn small', disabled: !pvm.ui.nodeEditMode, onClick: () => addNodePopup(c) }, 'Add node'),
      h('button', { class: 'btn small', onClick: () => { selectableNodes.forEach((r) => { if (allSel) delete pvm.ui.selectedNodes[r.key]; else pvm.ui.selectedNodes[r.key] = true; }); c.refresh(); } }, allSel ? 'Unselect all nodes' : 'Select all nodes'),
      h('button', { class: 'btn small', onClick: () => { selectableNodes.forEach((r) => { if (r.node.isCabNode) pvm.ui.selectedNodes[r.key] = true; }); c.refresh(); } }, 'Select cab nodes'),
      h('span', { class: 'muted small' }, ` ${Object.keys(pvm.ui.selectedNodes).filter((k) => pvm.ui.selectedNodes[k]).length} selected (requested nodes)`),
      h('span', { class: 'spacer' }),
      h('button', { class: 'link-btn small', onClick: legendPopup }, 'Status legend')) : null;
    const body = h('div', { class: 'node-list' }, rows.length ? rows.map((r) => nodeRow(c, r)) : h('div', { class: 'muted pad' }, c.filter ? 'No nodes match the source filter.' : 'No nodes.'));
    return section(c, 'nodes', c.titles && c.titles.nodes || 'Nodes', counts, extra, toolbar, body);
  }

  function nodeRow(c, r) {
    const pvm = c.pvm;
    const n = r.node;
    const expanded = c.forceExpandNodes || !!pvm.ui.expandedNodes[r.key];
    const editable = c.editable && !c.readOnly;
    const desc = n.versionName || n.replacementChainName ? `(${[n.versionName, n.replacementChainName].filter(Boolean).join(' | ')})` : '';
    const st = n.nodeTemplateStatus || 'none';
    const head = h('div', { class: ['node-head', r.status && 'st-' + r.status], id: `${c.prefix}-node-${r.key.replace(/\|/g, '_')}` },
      h('button', { class: 'expand-btn', title: expanded ? 'Collapse' : 'Expand', onClick: () => { pvm.ui.expandedNodes[r.key] = !expanded; c.refresh(); } }, expanded ? '−' : '+'),
      c.selectable ? (r.status ? h('input', { type: 'checkbox', title: 'Select change', checked: !!pvm.ui.sel['node:' + r.key], onChange: (e) => { pvm.ui.sel['node:' + r.key] = e.target.checked; c.refresh(); } }) : h('span', { class: 'chk-spacer' }))
        : editable ? h('input', { type: 'checkbox', title: 'Requested node', disabled: r.status === 'removed', checked: !!pvm.ui.selectedNodes[r.key] && r.status !== 'removed', onChange: (e) => { pvm.ui.selectedNodes[r.key] = e.target.checked; c.refresh(); } }) : null,
      notifIcon(n.notifications) || h('span', { class: 'notif-spacer' }),
      h('span', { class: ['status-dot', 'st-' + st], title: `Node template status: ${n.nodeTemplateStatus || 'unknown'}` }),
      h('span', { class: 'node-name', onClick: () => { pvm.ui.expandedNodes[r.key] = !expanded; c.refresh(); } }, n.name || M.derivedName(n.nodeIdentifier), ' ', h('span', { class: 'node-desc' }, desc)),
      n.isCabNode ? h('span', { class: 'badge', title: 'Cab node' }, 'CAB') : null,
      h('span', { class: 'badge ea' }, E.EANames[n.electricalArchitecture]),
      n.isSoftwareSame === true ? h('span', { class: 'same-sw small', title: 'Same Software as node template' }, '✔') : n.isSoftwareSame === false ? h('span', { class: 'diff-sw small', title: 'Software differs from node template' }, '≠') : null,
      r.status ? h('span', { class: ['badge', 'b-' + r.status] }, statusLabel[r.status]) : null,
      h('span', { class: 'spacer' }),
      editable && pvm.ui.nodeEditMode ? [
        r.status ? h('button', { class: 'icon-btn', title: 'Undo changes', onClick: () => { pvm.undoNode(r.key); c.onNodesChanged && c.onNodesChanged(); c.refresh(); } }, '⟲') : null,
        r.status !== 'removed' ? h('button', { class: 'icon-btn danger', title: 'Remove', onClick: () => { pvm.removeNode(r.key); c.onNodesChanged && c.onNodesChanged(); c.refresh(); } }, '🗑') : null,
      ] : null);
    return h('div', { class: ['node', r.status && 'st-' + r.status] }, head, expanded ? nodeBody(c, r) : null);
  }

  function newPart(T, name, number, fieldNumber) {
    const base = { name, number, quantity: 1, fieldNumber: fieldNumber || null, notifications: [], source: null };
    if (T === 'DownloadablePart' || T === 'Data') Object.assign(base, { softwareDownloadSignature: '', compressionMethod: 0, encryptionMethod: 0, offsetAddress: 0, isNotProgrammable: false, nodeTemplateDocumentNumber: null, artifactSHA: '', descriptionFileNumber: null, descriptionFileSHA: '' });
    if (T === 'Data') Object.assign(base, { isPatchable: true, isCertified: true, patches: [] });
    if (T === 'Hardware') base.serialNumber = '';
    return base;
  }

  function slotStatus(r, slot, T) {
    if (!r.orig || !r.cur) return '';
    const a = r.orig[slot], b = r.cur[slot];
    if (!a && b) return 'added';
    if (a && !b) return 'removed';
    return M.partsEqual(a, b, T) ? '' : 'replaced';
  }

  async function changeNtp(c, r, number) {
    const node = c.pvm.findNode(r.key);
    if (!node) return;
    const res = await TR.app.run(() => TR.api('TestRequest2000/ChangeNodeTemplate', { nodeJson: JSON.stringify(node), nodeTemplateDocumentNumber: number }), 'Changing node template');
    if (!res.success) return;
    const nn = res.item;
    const oldNtp = node.nodeTemplateDocument && String(node.nodeTemplateDocument.number);
    c.pvm.mutate(() => {
      const cur = c.pvm.findNode(r.key);
      ['nodeTemplateDocument', 'versionName', 'replacementChainName', 'nodeTemplateStatus'].forEach((k) => { cur[k] = nn[k]; });
      if (cur.electricalArchitecture === 1 && oldNtp) {
        ['mainSoftware', 'primaryBootloader', 'secondaryBootloader'].forEach((k) => { if (cur[k] && cur[k].nodeTemplateDocumentNumber === oldNtp) cur[k].nodeTemplateDocumentNumber = null; });
        ['datas', 'complementarySoftwares'].forEach((k) => (cur[k] || []).forEach((x) => { if (x.nodeTemplateDocumentNumber === oldNtp) x.nodeTemplateDocumentNumber = null; }));
      }
      cur.isSoftwareSame = undefined;
    });
    if (c.onNodesChanged) c.onNodesChanged();
    c.refresh();
  }

  function nodeBody(c, r) {
    const n = r.node;
    const pvm = c.pvm;
    const editable = c.editable && !c.readOnly;
    const editParts = editable && pvm.ui.nodeEditMode && r.status !== 'removed';
    const ea = n.electricalArchitecture;
    const out = [];
    const replaceHw = !!pvm.ui.replaceHw[r.key];
    if ((editable && r.status !== 'removed' && r.status !== 'added') || replaceHw) {
      out.push(h('label', { class: 'chk replace-hw' }, h('input', { type: 'checkbox', checked: replaceHw, disabled: !editable, onChange: (e) => { pvm.ui.replaceHw[r.key] = e.target.checked; if (e.target.checked) pvm.ui.selectedNodes[r.key] = true; else pvm.undoSlot(r.key, 'ecuHardware'); c.refresh(); } }), ' Replace hardware'));
    }
    // NTP document & ECU hardware blocks
    const ntp = n.nodeTemplateDocument;
    const ntpSt = slotStatus(r, 'nodeTemplateDocument', 'Part');
    out.push(h('div', { class: 'blocks' },
      h('div', { class: ['block', ntpSt && 'st-' + ntpSt] }, h('div', { class: 'block-title' }, 'NTP Document'),
        h('div', null, 'Doc. Number: ', editParts ? numInput(ntp && ntp.number, (v) => changeNtp(c, r, v), { key: `${c.prefix}-ntp-${r.key}` }) : partLink(ntp && ntp.number)),
        ea !== 1 && ntp && ntp.fieldNumber ? h('div', null, 'Field Number: ', ntp.fieldNumber) : null,
        h('div', { class: 'small muted' }, n.versionName || '', n.nodeTemplateStatus ? ` · ${n.nodeTemplateStatus}` : '', n.nodePath ? ` · ${n.nodePath}` : '', ea === 1 && n.nodeState === 1 ? ' · Pending' : '')),
      hardwareBlock(c, r, editParts || (editable && replaceHw))));
    if (ea === 3) out.push(t3Parts(c, r, editParts));
    else if (ea === 1) out.push(tea2PlusParts(c, r, editParts)); else out.push(tea2Parts(c, r, editParts));
    if (r.cur && r.cur.notifications && r.cur.notifications.length) out.push(h('div', { class: 'node-notes' }, r.cur.notifications.map((x) => h('div', { class: ['note', E.SeverityClass[x.severity]] }, x.text, x.reason ? h('span', { class: 'muted' }, ' – ' + x.reason) : null))));
    return h('div', { class: 'node-body' }, out);
  }

  function hardwareBlock(c, r, canEdit) {
    const n = r.node;
    const hw = n.ecuHardware;
    const st = slotStatus(r, 'ecuHardware', 'Hardware');
    const prev = r.orig && r.orig.ecuHardware;
    return h('div', { class: ['block', st && 'st-' + st] }, h('div', { class: 'block-title' }, 'ECU Hardware'),
      h('div', null, 'Part Number: ', canEdit ? numInput(hw && hw.number, (v) => { c.pvm.setSlot(r.key, 'ecuHardware', Object.assign(clone(hw || newPart('Hardware', 'ECU', v)), { number: v })); c.refresh(); }, { key: `${c.prefix}-hw-${r.key}` }) : partLink(hw && hw.number),
        st && prev ? h('span', { class: 'muted small' }, ` (was ${prev.number})`) : null),
      h('div', null, 'Serial Number: ', canEdit ? textInput(hw && hw.serialNumber, (v) => { c.pvm.setSlot(r.key, 'ecuHardware', Object.assign(clone(hw || newPart('Hardware', 'ECU', 0)), { serialNumber: v })); c.refresh(); }, { key: `${c.prefix}-sn-${r.key}` }) : (hw && hw.serialNumber) || ''),
      n.electricalArchitecture !== 1 && hw && hw.fieldNumber ? h('div', null, 'Field Number: ', hw.fieldNumber) : null,
      TR.db.hwNames[hw && hw.number] ? h('div', { class: 'small muted' }, TR.db.hwNames[hw.number]) : null);
  }

  function actionButtons(c, canEdit, status, onUndo, onRemove, hasCur) {
    if (!canEdit) return h('td', { class: 'actions' });
    return h('td', { class: 'actions' },
      status ? h('button', { class: 'icon-btn small', title: 'Undo', onClick: () => { onUndo(); c.refresh(); } }, '⟲') : null,
      hasCur ? h('button', { class: 'icon-btn small danger', title: 'Remove', onClick: () => { onRemove(); c.refresh(); } }, '✕') : null);
  }

  function tea2PlusParts(c, r, editParts) {
    const pvm = c.pvm;
    const showSrc = c.showSource;
    const dpCols = (p) => [h('td', null, h('span', { class: 'mono small' }, p ? shaCell(p.artifactSHA) : '')), h('td', null, p ? shaCell(p.descriptionFileSHA) : ''), h('td', null, p && p.descriptionFileNumber ? partLink(p.descriptionFileNumber) : '')];
    const head = (first, extra) => h('thead', null, h('tr', null, h('th', null, first || ''), h('th', null, 'Doc. Number'), h('th', null, 'Artifact SHA'), h('th', null, 'Desc. File SHA'), h('th', null, 'Desc. File Number'), extra || null, showSrc ? h('th', null, 'Source') : null, h('th', null, '')));
    const singlesRows = [['mainSoftware', 'Main Software'], ['primaryBootloader', 'Primary Bootloader'], ['secondaryBootloader', 'Secondary Bootloader']].map(([slot, label]) => {
      const st = slotStatus(r, slot, 'DownloadablePart');
      const p = (r.cur && r.cur[slot]) || (r.orig && r.orig[slot]);
      const selKey = slot === 'primaryBootloader' ? 'pbl:' + r.key : slot === 'secondaryBootloader' ? 'sbl:' + r.key : null;
      return h('tr', { class: st && 'st-' + st },
        h('td', null, c.selectable && selKey && st ? h('input', { type: 'checkbox', checked: !!pvm.ui.sel[selKey], onChange: (e) => { pvm.ui.sel[selKey] = e.target.checked; c.refresh(); } }) : null, label),
        h('td', null, editParts ? numInput(p && p.number, (v) => { pvm.setSlot(r.key, slot, Object.assign(clone(p || newPart('DownloadablePart', label.split(' ').map((w) => w[0]).join(''), v)), { number: v, artifactSHA: '', descriptionFileSHA: '' })); c.refresh(); }, { key: `${c.prefix}-${r.key}-${slot}` }) : partLink(p && p.number),
          st === 'replaced' && r.orig[slot] ? h('span', { class: 'muted small' }, ` (was ${r.orig[slot].number})`) : null),
        dpCols(p), showSrc ? h('td', null, sourceCell(p && p.source)) : null,
        actionButtons(c, editParts, st, () => pvm.undoSlot(r.key, slot), () => pvm.setSlot(r.key, slot, null), !!(r.cur && r.cur[slot])));
    });
    const blocks = [h('table', { class: 'grid parts' }, head('Software'), h('tbody', null, singlesRows))];
    // collections
    [['datas', 'Data', 'Data'], ['complementarySoftwares', 'DownloadablePart', 'Complementary Software'], ['subHardwares', 'Hardware', 'Sub Hardware']].forEach(([slot, T, label]) => {
      const rows = pvm.listRows(r, slot, T);
      if (!rows.length && !editParts) return;
      const body = [];
      rows.forEach((e) => {
        const p = e.part;
        if (T === 'Hardware') {
          body.push(h('tr', { class: e.status && 'st-' + e.status },
            h('td', null, editParts && e.cur ? numInput(p.number, async (v) => {
              const res = await TR.app.run(() => TR.api('TestRequest2000/CreateHardware', { partNumber: v }), 'Resolving component name');
              if (!res.success) return;
              pvm.setListItem(r.key, slot, e.id, Object.assign(clone(p), { number: v, name: res.item.name })); c.refresh();
            }, { key: `${c.prefix}-${r.key}-${slot}-${e.id}` }) : partLink(p.number)),
            h('td', null, editParts && e.cur ? textInput(p.serialNumber, (v) => { pvm.setListItem(r.key, slot, e.id, Object.assign(clone(p), { serialNumber: v })); c.refresh(); }, { key: `${c.prefix}-${r.key}-${slot}-${e.id}-sn` }) : p.serialNumber || ''),
            h('td', null, p.name || ''), showSrc ? h('td', null, sourceCell(p.source)) : null,
            actionButtons(c, editParts, e.status, () => pvm.undoListItem(r.key, slot, e.id), () => pvm.removeListItem(r.key, slot, e.id), !!e.cur)));
          return;
        }
        body.push(h('tr', { class: e.status && 'st-' + e.status },
          h('td', null, editParts && e.cur ? numInput(p.number, (v) => { pvm.setListItem(r.key, slot, e.id, Object.assign(clone(p), { number: v, artifactSHA: '', descriptionFileSHA: '' })); c.refresh(); }, { key: `${c.prefix}-${r.key}-${slot}-${e.id}` }) : partLink(p.number),
            h('span', { class: 'muted small' }, p.name ? ` ${p.name}` : '')),
          dpCols(p), T === 'Data' ? h('td', null, String((p.patches || []).length)) : null, showSrc ? h('td', null, sourceCell(p.source)) : null,
          actionButtons(c, editParts, e.status, () => pvm.undoListItem(r.key, slot, e.id), () => pvm.removeListItem(r.key, slot, e.id), !!e.cur)));
        if (T === 'Data') {
          (p.patches || []).forEach((pt, pi) => {
            const op = e.orig && (e.orig.patches || []).find((x) => x.index === pt.index);
            const pst = e.orig && e.cur ? (!op ? 'added' : M.partsEqual(op, pt, 'DataPatch') ? '' : 'replaced') : '';
            body.push(h('tr', { class: ['patch-row', pst && 'st-' + pst] },
              h('td', null, '↳ Patch ', editParts && e.cur ? numInput(pt.number, (v) => { const d = clone(p); d.patches[pi] = Object.assign(d.patches[pi], { number: v, artifactSHA: '' }); pvm.setListItem(r.key, slot, e.id, d); c.refresh(); }, { key: `${c.prefix}-${r.key}-patch-${e.id}-${pi}` }) : partLink(pt.number)),
              h('td', null, shaCell(pt.artifactSHA)), h('td', null, shaCell(pt.descriptionFileSHA)), h('td', null, pt.descriptionFileNumber ? partLink(pt.descriptionFileNumber) : ''), h('td', null, pt.offsetAddress ? `@${pt.offsetAddress}` : ''), showSrc ? h('td') : null,
              editParts && e.cur ? h('td', { class: 'actions' }, h('button', { class: 'icon-btn small danger', title: 'Remove patch', onClick: () => { const d = clone(p); d.patches.splice(pi, 1); pvm.setListItem(r.key, slot, e.id, d); c.refresh(); } }, '✕')) : h('td')));
          });
          if (editParts && e.cur) body.push(h('tr', { class: 'patch-row' }, h('td', { colspan: 8 }, h('button', { class: 'link-btn small', onClick: () => promptNumber('Add Patch', 'Enter patch part number', (v) => { const d = clone(p); d.patches = d.patches || []; d.patches.push({ name: 'Patch', number: v, quantity: 1, offsetAddress: 0, nodeTemplateDocumentNumber: null, artifactSHA: '', descriptionFileNumber: null, descriptionFileSHA: '', notifications: [], source: null, index: d.patches.reduce((m, x) => Math.max(m, x.index || 0), -1) + 1 }); pvm.setListItem(r.key, slot, e.id, d); c.refresh(); }) }, '+ Add Patch'))));
        }
      });
      const headRow = T === 'Hardware' ? h('thead', null, h('tr', null, h('th', null, 'Part Number'), h('th', null, 'Serial Number'), h('th', null, 'Name'), showSrc ? h('th', null, 'Source') : null, h('th', null, ''))) : head(label === 'Data' ? 'Doc. Number' : 'Doc. Number', T === 'Data' ? h('th', null, 'Patches') : null);
      if (T !== 'Hardware') headRow.firstChild.removeChild(headRow.firstChild.children[1]);
      blocks.push(h('div', { class: 'collection' }, h('div', { class: 'collection-title' }, label, editParts ? h('button', { class: 'link-btn small', onClick: () => promptNumber(`Add ${label}`, 'Enter part number', async (v) => {
        if (T === 'Hardware') {
          const res = await TR.app.run(() => TR.api('TestRequest2000/CreateHardware', { partNumber: v }), 'Resolving component name');
          if (!res.success) return;
          pvm.addListItem(r.key, slot, Object.assign(res.item, { serialNumber: '' }));
        } else pvm.addListItem(r.key, slot, newPart(T, label === 'Data' ? 'Data' : 'CSW', v));
        c.refresh();
      }) }, `+ Add ${label}`) : null), rows.length ? h('table', { class: 'grid parts' }, headRow, h('tbody', null, body)) : h('div', { class: 'muted small pad' }, 'none')));
    });
    return h('div', { class: 'parts-wrap' }, blocks);
  }

  function t3Parts(c, r, editable) {
    const fields = ['softwareProduct', 'packageVersion', 'executionEnvironment', 'logicalEcu'];
    const rows = c.pvm.listRows(r, 'softwareProducts', 'DownloadablePart');
    return h('div', { class: 'collection' }, h('div', { class: 'collection-title' }, 'SW Products / Packages',
      editable ? h('button', { class: 'link-btn small', onClick: () => promptNumber('Add SW Package', 'Enter package part number', (number) => {
        c.pvm.addListItem(r.key, 'softwareProducts', Object.assign(newPart('DownloadablePart', 'SW Package', number), { softwareProduct: 'New product', packageVersion: '1.0.0', executionEnvironment: '', logicalEcu: '' })); c.refresh();
      }) }, '+ Add SW Package') : null),
      h('table', { class: 'grid parts' }, h('thead', null, h('tr', null, ['Part Number', 'SW Product', 'Package Version', 'Execution Environment', 'Logical ECU', 'Artifact SHA', ''].map((x) => h('th', null, x)))),
        h('tbody', null, rows.map((e) => {
          const update = (key, value) => { c.pvm.setListItem(r.key, 'softwareProducts', e.id, Object.assign(clone(e.part), { [key]: value })); c.refresh(); };
          return h('tr', { class: e.status && 'st-' + e.status },
            h('td', null, editable && e.cur ? numInput(e.part.number, (v) => update('number', v), { key: `${r.key}-${e.id}-number` }) : partLink(e.part.number)),
            fields.map((key) => h('td', null, editable && e.cur ? textInput(e.part[key] || '', (v) => update(key, v), { key: `${r.key}-${e.id}-${key}` }) : e.part[key] || '')),
            h('td', null, shaCell(e.part.artifactSHA)),
            actionButtons(c, editable, e.status, () => c.pvm.undoListItem(r.key, 'softwareProducts', e.id), () => c.pvm.removeListItem(r.key, 'softwareProducts', e.id), !!e.cur));
        }))));
  }

  function tea2Parts(c, r, editParts) {
    const pvm = c.pvm;
    const ea = r.node.electricalArchitecture;
    const showSrc = c.showSource;
    const head = h('thead', null, h('tr', null, h('th', null, ''), h('th', null, 'Part Number'), h('th', null, 'Field Number'), showSrc ? h('th', null, 'Source') : null, h('th', null, '')));
    const singleRows = M.NODE_SPEC[ea].single.map(([slot, T, label]) => {
      const st = slotStatus(r, slot, T);
      const p = (r.cur && r.cur[slot]) || (r.orig && r.orig[slot]);
      return h('tr', { class: st && 'st-' + st }, h('td', null, label),
        h('td', null, editParts ? numInput(p && p.number, (v) => { pvm.setSlot(r.key, slot, Object.assign(clone(p || newPart(T, label, v, '')), { number: v })); c.refresh(); }, { key: `${c.prefix}-${r.key}-${slot}` }) : partLink(p && p.number),
          st === 'replaced' && r.orig[slot] ? h('span', { class: 'muted small' }, ` (was ${r.orig[slot].number})`) : null),
        h('td', null, editParts ? textInput(p && p.fieldNumber, (v) => { pvm.setSlot(r.key, slot, Object.assign(clone(p || newPart(T, label, 0, v)), { fieldNumber: v || null })); c.refresh(); }, { size: 4, key: `${c.prefix}-${r.key}-${slot}-fn` }) : (p && p.fieldNumber) || ''),
        showSrc ? h('td', null, sourceCell(p && p.source)) : null,
        actionButtons(c, editParts, st, () => pvm.undoSlot(r.key, slot), () => pvm.setSlot(r.key, slot, null), !!(r.cur && r.cur[slot])));
    });
    const blocks = [h('table', { class: 'grid parts' }, head, h('tbody', null, singleRows))];
    M.NODE_SPEC[ea].lists.forEach(([slot, T, label]) => {
      const rows = pvm.listRows(r, slot, T);
      if (!rows.length && !editParts) return;
      blocks.push(h('div', { class: 'collection' }, h('div', { class: 'collection-title' }, label, editParts ? h('button', { class: 'link-btn small', onClick: () => promptNumber(`Add ${label}`, 'Enter part number', (v) => { pvm.addListItem(r.key, slot, newPart(T, label, v, String(10 + rows.length))); c.refresh(); }) }, `+ Add ${label}`) : null),
        rows.length ? h('table', { class: 'grid parts' }, h('thead', null, h('tr', null, h('th', null, 'Part Number'), h('th', null, 'Field Number'), showSrc ? h('th', null, 'Source') : null, h('th', null, ''))), h('tbody', null, rows.map((e) => h('tr', { class: e.status && 'st-' + e.status },
          h('td', null, editParts && e.cur ? numInput(e.part.number, (v) => { pvm.setListItem(r.key, slot, e.id, Object.assign(clone(e.part), { number: v })); c.refresh(); }, { key: `${c.prefix}-${r.key}-${slot}-${e.id}` }) : partLink(e.part.number)),
          h('td', null, e.part.fieldNumber || ''), showSrc ? h('td', null, sourceCell(e.part.source)) : null,
          actionButtons(c, editParts, e.status, () => pvm.undoListItem(r.key, slot, e.id), () => pvm.removeListItem(r.key, slot, e.id), !!e.cur))))) : h('div', { class: 'muted small pad' }, 'none')));
    });
    return h('div', { class: 'parts-wrap' }, blocks);
  }

  function promptNumber(title, placeholder, onOk) {
    let val = '';
    let error = '';
    const m = ui().modal({
      title, width: 340,
      body: () => h('div', null, h('input', { key: 'prompt-num', class: 'full', placeholder, maxlength: 8, value: val, onInput: (e) => { val = e.target.value; }, onKeydown: (e) => { if (e.key === 'Enter') ok(); } }), error ? h('div', { class: 'error-text' }, error) : null),
      buttons: [{ label: 'Cancel' }, { label: 'OK', primary: true, onClick: () => ok() }],
    });
    function ok() {
      const v = val.trim();
      if (!/^\d{1,8}$/.test(v)) { error = `'${v}' is not a valid Part Number.`; m.render(); return; }
      m.close();
      onOk(Number(v));
    }
  }

  async function addNodePopup(c) {
    const pvm = c.pvm;
    const info = pvm.info();
    const res = await TR.app.run(() => TR.api('TestRequest2000/GetNodesForContext', { contextId: info.context ? info.context.id : undefined, productClassCode: info.productClassId }), 'Loading nodes');
    if (!res.success) { ui().summary.addError('Failed to get nodes'); return; }
    const existing = new Set(pvm.current.nodes.map(M.nodeKey));
    const avail = res.item.filter((id) => !existing.has(M.idKey(id)));
    let selected = avail.length ? 0 : -1;
    let position = avail.length ? avail[0].position : '';
    ui().modal({
      title: 'Add node', width: 420,
      body: (m) => avail.length ? h('div', { class: 'form' },
        h('label', null, 'Select node', h('select', { value: String(selected), onChange: (e) => { selected = Number(e.target.value); position = avail[selected].position; m.render(); } }, avail.map((id, i) => h('option', { value: String(i) }, `${id.derivedName} – ${id.description}`)))),
        avail[selected] && avail[selected].electricalArchitecture === 1 ? h('label', null, 'Position:', h('input', { type: 'number', min: 1, max: 9, value: String(position), onInput: (e) => { position = e.target.value; } })) : null)
        : h('p', null, 'There are no more nodes to add.'),
      buttons: [{ label: 'Cancel' }, avail.length ? { label: 'Add node', primary: true, onClick: async (m) => {
        const id = clone(avail[selected]);
        if (id.electricalArchitecture === 1 && position) id.position = Number(position);
        m.close();
        const r = await TR.app.run(() => TR.api('TestRequest2000/CreateNodeFromIdentifier', { nodeIdentifier: id, productClassId: info.productClassId }), 'Creating node');
        if (!r.success) return;
        pvm.addNode(r.item);
        pvm.ui.expandedNodes[M.nodeKey(r.item)] = true;
        if (c.onNodesChanged) c.onNodesChanged();
        c.refresh();
      } } : null],
    });
  }

  // ---------- variant-editor ----------
  function variantEditor(c) {
    const pvm = c.pvm;
    const rows = pvm.variantRows();
    const counts = { added: 0, removed: 0, replaced: 0, modified: 0, unchanged: 0 };
    rows.forEach((r) => { if (r.status === 'removed' && r.replacedBy) return; counts[r.status || 'unchanged']++; });
    let shown = rows.filter((r) => !(r.status === 'removed' && r.replacedBy));
    if (c.onlyDirty) shown = shown.filter((r) => r.status);
    const f = pvm.ui.variantFilter.trim().toUpperCase();
    if (f) shown = shown.filter((r) => (r.v.symbol || '').toUpperCase().includes(f) || (r.v.description || '').toUpperCase().includes(f) || (r.v.idVar6 || '').includes(f));
    if (c.onlyDirty && !shown.length) return null;
    const editable = c.editable && !c.readOnly;
    const ex = pvm.ui.exprResult;
    const hl = new Set(ex && ex.symbols ? ex.symbols : []);
    const toolbar = h('div', { class: 'ed-toolbar' },
      editable ? h('button', { class: 'btn small', onClick: () => addVariantsPopup(c) }, 'Add Variants') : null,
      h('label', null, 'Filter: ', h('input', { class: 'small-input', key: `${c.prefix}-varfilter`, value: pvm.ui.variantFilter, onInput: (e) => { pvm.ui.variantFilter = e.target.value; c.refresh(); } })),
      h('label', null, 'Evaluate: ', h('input', { class: 'small-input wide', key: `${c.prefix}-varexpr`, placeholder: 'e.g. D13K500 & (LHD | RHD) & !ADR', value: pvm.ui.variantExpr, onInput: (e) => { pvm.ui.variantExpr = e.target.value; }, onKeydown: (e) => { if (e.key === 'Enter') evaluate(); } })),
      h('button', { class: ['icon-btn', 'expr-icon', ex && (ex.error ? 'failed' : ex.value ? 'success' : 'failed')], title: ex ? (ex.error || (ex.value ? 'Expression is true for the product' : 'Expression is false for the product')) : 'Click to evaluate expression.', onClick: evaluate }, !ex ? '?' : ex.error ? '!' : ex.value ? '✔' : '✖'),
      h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: pvm.ui.showVarDesc, onChange: (e) => { pvm.ui.showVarDesc = e.target.checked; c.refresh(); } }), ' Show descriptions'));
    function evaluate() {
      const present = new Set(pvm.current.productSpecification.variants.map((v) => (v.symbol || '').toUpperCase()));
      try {
        if (!pvm.ui.variantExpr.trim()) { pvm.ui.exprResult = null; c.refresh(); return; }
        const r = M.evalExpression(pvm.ui.variantExpr, present, (s) => !!TR.db.variantBySymbol(s));
        pvm.ui.exprResult = r;
      } catch (e) { pvm.ui.exprResult = { error: e.message, symbols: [] }; }
      c.refresh();
    }
    const msgs = ex ? [ex.error ? h('div', { class: 'error-text small' }, ex.error) : null, ex.notInProduct && ex.notInProduct.length ? h('div', { class: 'warning-text small' }, `Variants not found in product: ${ex.notInProduct.join(', ')}`) : null] : null;
    const grid = h('div', { class: 'tile-grid' }, shown.map((r) => {
      const k = 'var:' + M.variantKey(r.v);
      const selKeyable = c.selectable && r.status;
      return h('div', { class: ['tile', r.status && 'st-' + r.status, hl.has((r.v.symbol || '').toUpperCase()) && 'highlight', pvm.ui.showVarDesc && 'with-desc'], title: `${r.v.symbol} (${r.v.idVar6})${r.replaces ? `\nreplaces ${r.replaces.symbol}` : ''}\n${r.v.description || 'No Symbol'}`, onClick: (e) => { if (e.target.tagName === 'INPUT') return; variantPopup(c, r); } },
        selKeyable ? h('input', { type: 'checkbox', checked: !!pvm.ui.sel[k], onChange: (e) => { pvm.ui.sel[k] = e.target.checked; if (r.replaces) pvm.ui.sel['var:' + M.variantKey(r.replaces)] = false; c.refresh(); } }) : null,
        h('span', { class: 'tile-sym' }, r.v.symbol || r.v.idVar6), r.replaces ? h('span', { class: 'tile-rep small' }, ` ⇄ ${r.replaces.symbol}`) : null,
        pvm.ui.showVarDesc ? h('div', { class: 'tile-desc' }, r.v.description || 'No Symbol') : null,
        c.showSource && r.v.source ? h('div', { class: 'tile-desc' }, sourceText(r.v.source)) : null);
    }));
    return section(c, 'variants', c.titles && c.titles.variants || 'Variants', counts, null, toolbar, [msgs, shown.length ? grid : h('div', { class: 'muted pad' }, 'No variants.')]);
  }

  function addVariantsPopup(c) {
    let val = '';
    ui().modal({
      title: 'Add Variants', width: 400,
      body: () => h('div', null, h('input', { class: 'full upper', key: 'add-variants', placeholder: 'Enter variant symbols', value: val, onInput: (e) => { val = e.target.value; }, onKeydown: (e) => { if (e.key === 'Enter') document.querySelector('.dialog-footer .primary').click(); } }), h('div', { class: 'small muted' }, 'Separate symbols with , or /')),
      buttons: [{ label: 'Cancel' }, { label: 'OK', primary: true, onClick: async (m) => {
        m.close();
        const r = await TR.app.run(() => TR.api('TestRequest2000/GetVariants', { symbols: val.toUpperCase(), productClass: c.pvm.info().productClassId }), 'Validating variants');
        if (!r.success) return;
        r.item.forEach((v) => c.pvm.addVariant(v));
        c.refresh();
      } }],
    });
  }

  async function variantPopup(c, r) {
    const pvm = c.pvm;
    const editable = c.editable && !c.readOnly;
    const v = r.v;
    const present = pvm.hasVariant(v);
    let fam = null;
    let checked = null;
    const m = ui().modal({
      title: `${v.symbol || 'No Symbol'} (${v.idVar6})`, width: 440,
      body: () => h('div', null,
        h('div', null, v.description || 'No Symbol'),
        r.replaces ? h('div', { class: 'small muted' }, `replaces ${r.replaces.symbol} (${r.replaces.idVar6})`) : null,
        r.replacedBy ? h('div', { class: 'small muted' }, `replaced by ${r.replacedBy.symbol}`) : null,
        c.showSource && v.source ? h('div', { class: 'small' }, 'Source: ', sourceText(v.source)) : null,
        editable ? h('div', { class: 'family' }, !fam ? h('div', { class: 'muted small' }, 'Loading variant family...') : [
          h('div', { class: 'family-title' }, fam.familyDescription, fam.familyType === 'E' ? h('span', { class: 'muted small' }, ' (multiple variants allowed)') : null),
          fam.familyType === 'E'
            ? h('div', { class: 'family-list' }, fam.variants.map((fv) => h('label', { class: 'chk block' }, h('input', { type: 'checkbox', checked: checked.has(fv.idVar6), onChange: (e) => { if (e.target.checked) checked.add(fv.idVar6); else checked.delete(fv.idVar6); } }), ` ${fv.symbol} – ${fv.description}`)))
            : h('div', { class: 'family-list' }, fam.variants.map((fv) => h('button', { class: ['family-item', pvm.hasVariant(fv) && 'current'], disabled: pvm.hasVariant(fv), title: 'Replace with this variant', onClick: () => { pvm.addVariant(fv); m.close(); c.refresh(); } }, `${fv.symbol} – ${fv.description}`))),
        ]) : null),
      buttons: () => !editable ? [{ label: 'Close' }] : [
        r.status ? { label: 'Restore', onClick: () => { pvm.restoreVariant(r.status === 'removed' ? v : v); m.close(); c.refresh(); } } : null,
        present ? { label: 'Remove', danger: true, onClick: () => { pvm.removeVariant(v); m.close(); c.refresh(); } } : null,
        fam && fam.familyType === 'E' ? { label: 'Cancel' } : null,
        fam && fam.familyType === 'E' ? { label: 'OK', primary: true, onClick: () => { pvm.setFamilyVariants(v.familyId, fam.variants.filter((x) => checked.has(x.idVar6))); m.close(); c.refresh(); } } : null,
      ],
    });
    if (!editable) return;
    const res = await TR.api('TestRequest2000/GetVariantsInFamily', { variant: v, productClass: pvm.info().productClassId });
    if (res.success) {
      fam = res.item;
      checked = new Set(pvm.current.productSpecification.variants.filter((x) => x.familyId === v.familyId).map((x) => x.idVar6));
    } else fam = { familyDescription: 'Unknown Variant Family', variants: [] };
    if (!m.closed) m.render();
  }

  // ---------- s-note-editor ----------
  function sNoteEditor(c) {
    const pvm = c.pvm;
    const rows = pvm.sNoteRows();
    const counts = { added: 0, removed: 0, replaced: 0, modified: 0, unchanged: 0 };
    rows.forEach((r) => { counts[r.status || 'unchanged']++; });
    const shown = c.onlyDirty ? rows.filter((r) => r.status) : rows;
    if (c.onlyDirty && !shown.length) return null;
    const editable = c.editable && !c.readOnly;
    const toolbar = h('div', { class: 'ed-toolbar' },
      editable ? h('button', { class: 'btn small', onClick: () => addSNotesPopup(c) }, 'Add S-Notes') : null,
      h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: pvm.ui.showSnoteDesc, onChange: (e) => { pvm.ui.showSnoteDesc = e.target.checked; c.refresh(); } }), ' Show descriptions'));
    const grid = h('div', { class: 'tile-grid' }, shown.map((r) => {
      const k = 'snote:' + r.s.value;
      return h('div', { class: ['tile', r.status && 'st-' + r.status, pvm.ui.showSnoteDesc && 'with-desc'], title: r.s.name || '', onClick: (e) => { if (e.target.tagName === 'INPUT') return; sNotePopup(c, r); } },
        c.selectable && r.status ? h('input', { type: 'checkbox', checked: !!pvm.ui.sel[k], onChange: (e) => { pvm.ui.sel[k] = e.target.checked; c.refresh(); } }) : null,
        h('span', { class: 'tile-sym' }, r.s.value), pvm.ui.showSnoteDesc ? h('div', { class: 'tile-desc' }, r.s.name || '(no description)') : null);
    }));
    return section(c, 'snotes', c.titles && c.titles.snotes || 'S-Notes', counts, null, toolbar, shown.length ? grid : h('div', { class: 'muted pad' }, 'No S-Notes.'));
  }
  function addSNotesPopup(c) {
    let val = '';
    ui().modal({
      title: 'Add S-Notes', width: 380,
      body: () => h('input', { class: 'full upper', key: 'add-snotes', placeholder: 'Enter S-Notes', value: val, onInput: (e) => { val = e.target.value; }, onKeydown: (e) => { if (e.key === 'Enter') document.querySelector('.dialog-footer .primary').click(); } }),
      buttons: [{ label: 'Cancel' }, { label: 'OK', primary: true, onClick: async (m) => {
        m.close();
        const r = await TR.app.run(() => TR.api('TestRequest2000/GetSNotes', { sNotes: TR.util.splitList(val.toUpperCase(), /[,;\s/]+/) }), 'Validating S-Notes');
        if (!r.success) return;
        r.item.forEach((s) => c.pvm.addSNote(s));
        c.refresh();
      } }],
    });
  }
  function sNotePopup(c, r) {
    const editable = c.editable && !c.readOnly;
    const present = c.pvm.current.productSpecification.sNotes.some((x) => x.value === r.s.value);
    ui().modal({
      title: 'S-Note', width: 380,
      body: h('div', null, h('strong', null, r.s.value), ' ', h('a', { href: `#/SNote?value=${r.s.value}`, title: 'Show in EDB' }, '🔗'), h('div', null, r.s.name || '(no description)')),
      buttons: !editable ? [{ label: 'Close' }] : [
        r.status ? { label: 'Restore', onClick: (m) => { c.pvm.restoreSNote(r.s); m.close(); c.refresh(); } } : null,
        present ? { label: 'Remove', danger: true, onClick: (m) => { c.pvm.removeSNote(r.s); m.close(); c.refresh(); } } : null,
      ],
    });
  }

  // ---------- parameter-editor ----------
  function parameterEditor(c) {
    const pvm = c.pvm;
    let rows = pvm.paramRows();
    if (c.paramKeys) rows = rows.filter((r) => c.paramKeys.has(r.key));
    const counts = { added: 0, removed: 0, replaced: 0, modified: 0, unchanged: 0 };
    rows.forEach((r) => { counts[r.status || 'unchanged']++; });
    if (c.onlyDirty) rows = rows.filter((r) => r.status);
    const f = pvm.ui.paramFilter.trim().toUpperCase();
    if (f) rows = rows.filter((r) => r.p.code.toUpperCase().includes(f) || M.paramValue(r.p).toUpperCase().includes(f));
    if (c.filter) rows = rows.filter((r) => M.sourcePasses(c.filter, r.p.source));
    if (c.onlyDirty && !rows.length) return null;
    const editable = c.editable && !c.readOnly;
    const view = pvm.ui.paramView;
    const toolbar = h('div', { class: 'ed-toolbar' },
      editable ? h('button', { class: 'btn small', onClick: () => addParameterPopup(c) }, 'Add Parameter') : null,
      h('label', null, 'Filter: ', h('input', { class: 'small-input', key: `${c.prefix}-paramfilter`, value: pvm.ui.paramFilter, onInput: (e) => { pvm.ui.paramFilter = e.target.value; c.refresh(); } })),
      editable ? h('button', { class: 'btn small', onClick: () => importParameters(c) }, 'Import Parameters') : null,
      h('span', { class: 'spacer' }),
      h('span', { class: 'small muted' }, view === 'compact' ? '▦' : '☰', ' '),
      ui().select([['compact', 'Compact'], ['table', 'Table']], view, (v) => { pvm.ui.paramView = v; c.refresh(); }, { class: 'small-select' }));
    const icons = (p) => [p.packaged ? h('span', { class: 'p-icon', title: 'Packaged parameter' }, 'P') : null, p.isGroupAdministrative ? h('span', { class: 'p-icon', title: 'Group administrative parameter' }, 'A') : null, p.isFunction ? h('span', { class: 'p-icon', title: 'Function parameter' }, 'F') : null, p.valueNotVisibleToUser ? h('span', { class: 'p-icon', title: 'Value not visible to users' }, '🔒') : null, notifIcon(p.notifications)];
    const groups = [0, 1].map((ea) => [ea, rows.filter((r) => (r.p.electricalArchitecture || 0) === ea)]).filter((g) => g[1].length);
    const anySource = rows.some((r) => r.p.source);
    const body = groups.map(([ea, list]) => h('div', { class: 'param-group' }, h('div', { class: 'collection-title' }, E.ParamEANames[ea]),
      view === 'compact'
        ? h('div', { class: 'tile-grid' }, list.map((r) => {
          const k = 'param:' + r.key;
          return h('div', { class: ['tile', 'param-tile', r.status && 'st-' + r.status], title: `${r.p.code}${TR.db.paramDef(ea, r.p.code) ? ' – ' + TR.db.paramDef(ea, r.p.code).description : ''}${r.status === 'replaced' && r.orig ? `\nwas: ${M.paramValue(r.orig)}` : ''}`, onClick: (e) => { if (e.target.tagName === 'INPUT') return; paramPopup(c, r); } },
            c.selectable && r.status ? h('input', { type: 'checkbox', checked: !!pvm.ui.sel[k], onChange: (e) => { pvm.ui.sel[k] = e.target.checked; c.refresh(); } }) : null,
            icons(r.p), h('span', { class: 'tile-sym' }, M.paramDisplay(r.p)),
            c.showSource && r.p.source ? h('div', { class: 'tile-desc' }, sourceText(r.p.source)) : null);
        }))
        : h('table', { class: 'grid' }, h('thead', null, h('tr', null, c.selectable ? h('th') : null, h('th'), h('th', null, 'Code'), h('th', null, 'Value'), anySource || c.showSource ? [h('th', null, 'Conditions'), h('th', null, 'Part Number'), h('th', null, 'Demarcation')] : null)),
          h('tbody', null, list.map((r) => h('tr', { class: ['clickable', r.status && 'st-' + r.status], onClick: (e) => { if (e.target.tagName === 'INPUT') return; paramPopup(c, r); } },
            c.selectable ? h('td', null, r.status ? h('input', { type: 'checkbox', checked: !!pvm.ui.sel['param:' + r.key], onChange: (e) => { pvm.ui.sel['param:' + r.key] = e.target.checked; c.refresh(); } }) : null) : null,
            h('td', null, icons(r.p)), h('td', null, r.p.code), h('td', null, M.paramValue(r.p), r.status === 'replaced' && r.orig ? h('span', { class: 'muted small' }, ` (was ${M.paramValue(r.orig)})`) : null),
            anySource || c.showSource ? [h('td', null, M.conditionText(r.p.source)), h('td', null, r.p.source ? r.p.source.itemNumber || '' : ''), h('td', null, r.p.source ? r.p.source.demarcation || '' : '')] : null))))));
    return section(c, 'params', c.titles && c.titles.params || 'Parameters', counts, null, toolbar, rows.length ? body : h('div', { class: 'muted pad' }, 'No parameters.'));
  }

  function addParameterPopup(c) {
    let ea = '1';
    let code = '';
    let error = '';
    const m = ui().modal({
      title: 'Add Parameter', width: 380,
      body: () => h('div', { class: 'form' }, ui().select([['0', 'TEA2'], ['1', 'TEA2+']], ea, (v) => { ea = v; }),
        h('input', { class: 'upper', key: 'add-param-code', placeholder: 'Enter parameter code', value: code, onInput: (e) => { code = e.target.value; }, onKeydown: (e) => { if (e.key === 'Enter') add(); } }),
        error ? h('div', { class: 'error-text' }, error) : null,
        h('div', { class: 'small muted' }, 'Known codes: ', Object.values(TR.db.paramDefs).filter((p) => String(p.ea) === ea).map((p) => p.code).join(', '))),
      buttons: [{ label: 'Cancel' }, { label: 'Add parameter', primary: true, onClick: () => add() }],
    });
    async function add() {
      const cd = code.trim().toUpperCase();
      if (!cd) { error = 'Please enter parameter code'; m.render(); return; }
      const ctx = c.pvm.info().context;
      const r = await TR.api('TestRequest2000/IsParameterDefined', { electricalArchitecture: Number(ea), code: cd, contextId: ctx ? ctx.id : null });
      if (!r.success) { error = r.errors.join('\n'); m.render(); return; }
      m.close();
      const pd = TR.db.paramDef(Number(ea), cd);
      const key = `${ea}:${cd}`;
      const existing = c.pvm.current.parameters.find((x) => M.paramKey(x) === key);
      const p = existing ? clone(existing) : { code: cd, electricalArchitecture: Number(ea), references: pd.isFunction ? [] : pd.refs.map((rc) => ({ code: rc, value: null })), packaged: !!pd.packaged, isGroupAdministrative: !!pd.admin, isFunction: !!pd.isFunction, valueNotVisibleToUser: false, source: null, notifications: [] };
      if (!existing) c.pvm.setParam(p);
      c.refresh();
      const row = c.pvm.paramRows().find((x) => x.key === key);
      if (row && !pd.isFunction) paramPopup(c, row);
    }
  }

  async function importParameters(c) {
    const file = await TR.util.pickFile('.xml');
    if (!file) return;
    const xml = await TR.util.readFileText(file);
    const r = await TR.app.run(() => TR.api('TestRequest2000/UploadAndGetParameters', { parametersXml: xml }), 'Importing parameters');
    if (!r.success) return;
    c.pvm.applyDelta(r.item, false);
    TR.ui.summary.addInformation(`${r.item.parameters.length} parameter(s) imported from ${file.name}.`);
    c.refresh();
  }

  function paramPopup(c, r) {
    const pvm = c.pvm;
    const editable = c.editable && !c.readOnly;
    const p = clone(r.p);
    const ea = p.electricalArchitecture || 0;
    const pd = TR.db.paramDef(ea, p.code);
    const removed = r.status === 'removed';
    let error = '';
    const src = p.source;
    const sourceTable = src ? h('table', { class: 'kv small' }, h('tbody', null, [['Condition', M.conditionText(src)], ['Part Number', src.itemNumber], ['Demarcation', src.demarcation], ['Calculation', src.calculation], ['Link', src.link], ['Baseline', src.baseline]].filter((x) => x[1]).map(([k, v]) => h('tr', null, h('th', null, k), h('td', null, v))))) : null;
    const notes = (p.notifications || []).length ? h('table', { class: 'grid small' }, h('thead', null, h('tr', null, h('th', null, 'Message'), h('th', null, 'Reason'), h('th', null, 'Action'))), h('tbody', null, p.notifications.map((n) => h('tr', null, h('td', null, n.text), h('td', null, n.reason || ''), h('td', null, n.action || ''))))) : null;
    const m = ui().modal({
      title: `${p.code} (${E.ParamEANames[ea]})`, width: 460,
      body: () => {
        const desc = pd ? h('div', { class: 'muted small' }, pd.description, pd.kind === 'int' ? ` – integer ${pd.min}..${pd.max}` : pd.kind === 'enum' ? ` – one of ${pd.values.join(', ')}` : pd.kind === 'bool' ? ' – 0 or 1' : '') : h('div', { class: 'muted small' }, 'Unknown parameter definition');
        let editor;
        if (removed) editor = h('div', null, 'Parameter has been removed. Value was ', h('strong', null, M.paramValue(p)));
        else if (p.valueNotVisibleToUser) editor = h('div', { class: 'warning-text' }, 'Parameter value is not visible to users.');
        else if (p.isFunction) editor = h('div', null, 'Function parameter (no value).');
        else if (!editable) editor = h('div', null, (p.references || []).map((x) => h('div', null, `${x.code} = ${x.value}`)));
        else if (ea === 0) editor = h('label', { class: 'block' }, 'Parameter value', h('input', { class: 'full', key: 'param-value', value: p.references[0] ? p.references[0].value || '' : '', onInput: (e) => { if (!p.references[0]) p.references[0] = { code: 'VAL', value: '' }; p.references[0].value = e.target.value; } }));
        else editor = h('table', { class: 'grid' }, h('thead', null, h('tr', null, h('th', null, 'Reference'), h('th', null, 'Value'))), h('tbody', null, (p.references || []).map((x, i) => h('tr', null, h('td', null, x.code),
          h('td', null, pd && pd.kind === 'enum' ? ui().select([['', '']].concat(pd.values.map((v) => [v, v])), x.value || '', (v) => { p.references[i].value = v; }) : pd && pd.kind === 'bool' ? ui().select([['', ''], ['0', '0'], ['1', '1']], x.value || '', (v) => { p.references[i].value = v; }) : h('input', { key: `param-ref-${i}`, value: x.value || '', onInput: (e) => { p.references[i].value = e.target.value; } }))))));
        return h('div', { class: 'form' }, desc, editor, error ? h('div', { class: 'error-text pre-line' }, error) : null,
          r.status === 'replaced' && r.orig ? h('div', { class: 'small muted' }, 'Original value: ', M.paramValue(r.orig)) : null,
          c.showSource || src ? sourceTable : null, notes);
      },
      buttons: () => {
        if (!editable) return [{ label: 'Close' }];
        const b = [];
        if (r.status) b.push({ label: 'Restore', onClick: () => { pvm.restoreParam(r.key); m.close(); c.refresh(); } });
        if (!removed) b.push({ label: 'Remove', danger: true, onClick: () => { pvm.removeParam(r.key); m.close(); c.refresh(); } });
        if (!removed && !p.isFunction && !p.valueNotVisibleToUser) {
          b.push({ label: 'Cancel' });
          b.push({ label: 'OK', primary: true, onClick: async () => {
            const res = await TR.api('TestRequest2000/ValidateParameterValue', { parameterJson: JSON.stringify(p) });
            if (!res.success) { error = res.errors.join('\n'); m.render(); return; }
            pvm.setParam(p);
            m.close();
            c.refresh();
          } });
        }
        return b;
      },
    });
  }

  // ---------- notifications-view2 ----------
  function notificationsView(c) {
    const list = c.pvm.allNotifications();
    if (!list.length || c.onlyDirty) return null;
    const cnt = [0, 1, 2].map((s) => list.filter((n) => (n.severity === undefined ? 2 : n.severity) === s).length);
    const extra = h('span', { class: 'notif-counts' }, cnt[0] ? h('span', { class: 'error' }, ` ⛔ ${cnt[0]}`) : null, cnt[1] ? h('span', { class: 'warning' }, ` ⚠ ${cnt[1]}`) : null, cnt[2] ? h('span', { class: 'information' }, ` ℹ ${cnt[2]}`) : null);
    return section(c, 'notifications', 'Notifications', null, extra, null, h('table', { class: 'grid notif-table' }, h('tbody', null, list.map((n) => h('tr', { class: ['clickable', E.SeverityClass[n.severity === undefined ? 2 : n.severity]], onClick: () => gotoNotification(c, n) },
      h('td', { class: 'ni' }, n.severity === 0 ? '⛔' : n.severity === 1 ? '⚠' : 'ℹ'), h('td', null, h('div', null, n.text), h('div', { class: 'muted small' }, n.where)), h('td', { class: 'small', html: reasonHtml(n) }))))));
  }
  function reasonHtml(n) {
    let html = TR.util.escapeHtml(n.reason || '');
    Object.keys(n.linkLookup || {}).forEach((k) => { const url = String(n.linkLookup[k]); if (!/^(https?:\/\/|\/(?!\/))/i.test(url)) return; html = html.replace(new RegExp(`\\b${k}\\b`, 'g'), `<a href="${TR.util.escapeHtml(url)}" target="_blank" rel="noopener noreferrer">${TR.util.escapeHtml(k)}</a>`); });
    return html;
  }
  function gotoNotification(c, n) {
    let id = null;
    if (n.section) c.pvm.ui.sections[n.section] = true;
    if (n.nodeKey) { c.pvm.ui.expandedNodes[n.nodeKey] = true; id = `${c.prefix}-node-${n.nodeKey.replace(/\|/g, '_')}`; }
    else if (n.section) id = `${c.prefix}-sec-${n.section}`;
    c.refresh();
    setTimeout(() => {
      const el = id && document.getElementById(id);
      if (!el) return;
      el.scrollIntoView({ block: 'center', behavior: 'smooth' });
      el.classList.add('flash');
      setTimeout(() => el.classList.remove('flash'), 900);
    }, 30);
  }

  // ---------- product-editor ----------
  function productEditor(c) {
    if (!c.pvm.loaded()) return h('div', { class: 'muted pad' }, 'No product loaded.');
    const parts = [productInformationEditor(c), nodesEditor(c), variantEditor(c), sNoteEditor(c), parameterEditor(c), notificationsView(c)].filter(Boolean);
    if (c.onlyDirty && !parts.length) return h('div', { class: 'muted pad' }, 'There are no differences.');
    return h('div', { class: 'product-editor' }, parts);
  }

  TR.editors = { productEditor, productInformationEditor, nodesEditor, variantEditor, sNoteEditor, parameterEditor, notificationsView, deltaSummary, artifactoryPopup, partLink, sourceText, notifIcon };
})();
