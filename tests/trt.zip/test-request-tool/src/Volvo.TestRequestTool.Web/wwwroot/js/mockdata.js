/* Deterministic mock database: product classes, contexts, variants, S-notes, node templates (NTP versions),
   VDA products, EDB specifications, baselines, service packs, conversion kits, campaigns, spare cab orders. */
(function () {
  'use strict';
  const TR = window.TR;
  const E = TR.enums;
  const M = TR.model;
  const { clone } = TR.util;

  // seeded PRNG so generated SHAs / serials are stable between reloads
  let seed = 20261008;
  function rnd() {
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  const hex = (n) => { let s = ''; for (let i = 0; i < n; i++) s += '0123456789abcdef'[Math.floor(rnd() * 16)]; return s; };
  const guid = () => { const h = hex(32); return `${h.slice(0, 8)}-${h.slice(8, 12)}-4${h.slice(13, 16)}-a${h.slice(17, 20)}-${h.slice(20, 32)}`; };

  const productClasses = [
    { id: 'FH', name: 'Volvo FH' }, { id: 'FM', name: 'Volvo FM' }, { id: 'VNL', name: 'Volvo VNL' }, { id: 'RT', name: 'Renault T (legacy)' },
  ];
  const contexts = [
    { id: 101, name: 'EU Heavy Duty TEA2+', productClassIds: ['FH', 'FM'], isOnlyTea2: false, nonVolvoGroup: false },
    { id: 102, name: 'NA Heavy Duty TEA2+', productClassIds: ['VNL'], isOnlyTea2: false, nonVolvoGroup: false },
    { id: 103, name: 'Legacy TEA2', productClassIds: ['RT'], isOnlyTea2: true, nonVolvoGroup: false },
  ];

  contexts.push({ id: 104, name: 'Volvo Trucks T3', productClassIds: ['FH', 'FM'], isOnlyTea2: false, nonVolvoGroup: false });

  // ---------- variants ----------
  const families = [];
  const variants = [];
  function fam(familyId, description, familyType, list, pcs) {
    families.push({ familyId, description, familyType });
    list.forEach(([variantId, symbol, desc, onlyPcs]) => {
      variants.push({ familyId, variantId, familyType, symbol, description: desc, idVar6: familyId + variantId, authorizedProductClasses: onlyPcs || pcs || ['FH', 'FM', 'VNL', 'RT'], source: null });
    });
  }
  fam('ENG', 'Engine', 'S', [['D13', 'D13K500', 'D13K 500 hp diesel engine'], ['D11', 'D11K450', 'D11K 450 hp diesel engine'], ['D16', 'D16K750', 'D16K 750 hp diesel engine'], ['D8K', 'D8K350', 'D8K 350 hp diesel engine', ['FM', 'RT']]]);
  fam('STW', 'Steering wheel position', 'S', [['LHD', 'LHD', 'Left hand drive'], ['RHD', 'RHD', 'Right hand drive']]);
  fam('GBX', 'Gearbox', 'S', [['ISH', 'I-SHIFT', 'I-Shift automated gearbox'], ['MAN', 'MAN-GBX', 'Manual gearbox'], ['ISD', 'I-SHIFTDC', 'I-Shift dual clutch']]);
  fam('AXL', 'Axle configuration', 'S', [['4X2', '4X2', '4x2 tractor'], ['6X2', '6X2', '6x2 tag axle'], ['6X4', '6X4', '6x4 tandem drive'], ['8X4', '8X4', '8x4 rigid']]);
  fam('CAB', 'Cab type', 'S', [['GXL', 'CAB-GLXL', 'Globetrotter XL cab'], ['GLT', 'CAB-GL', 'Globetrotter cab'], ['SLP', 'CAB-SLP', 'Sleeper cab'], ['DAY', 'CAB-DAY', 'Day cab']]);
  fam('TEL', 'Telematics', 'S', [['DYN', 'TELM-DYN', 'Dynafleet telematics gateway'], ['NON', 'TELM-NO', 'Without telematics']]);
  fam('ACC', 'Adaptive cruise control', 'S', [['ADV', 'ACC-ADV', 'ACC with queue assist'], ['BAS', 'ACC-BAS', 'ACC basic'], ['NON', 'ACC-NO', 'Without ACC']]);
  fam('ADR', 'ADR dangerous goods', 'S', [['ADR', 'ADR', 'ADR dangerous goods preparation'], ['NAD', 'ADR-NO', 'Without ADR']]);
  fam('LNG', 'Display language pack', 'E', [['EN1', 'LANG-EN', 'Display language English'], ['SV1', 'LANG-SV', 'Display language Swedish'], ['DE1', 'LANG-DE', 'Display language German'], ['FR1', 'LANG-FR', 'Display language French']]);
  fam('SAF', 'Active safety systems', 'E', [['LKS', 'LKS', 'Lane keeping support'], ['LCS', 'LCS', 'Lane changing support'], ['ESP', 'ESP', 'Electronic stability programme'], ['DAS', 'DAS', 'Driver alert support']]);
  fam('BBM', 'Body builder module', 'S', [['BBA', 'BBM-ADV', 'Body builder module advanced'], ['BBB', 'BBM-BAS', 'Body builder module basic'], ['NON', 'BBM-NO', 'Without body builder module']]);
  fam('MKT', 'Emission legislation', 'S', [['EU6', 'EURO6', 'Euro 6 emission level', ['FH', 'FM', 'RT']], ['US7', 'EPA17', 'EPA 2017 emission level', ['VNL']], ['EU5', 'EURO5', 'Euro 5 emission level', ['FH', 'FM', 'RT']]]);
  fam('FMS', 'FMS gateway', 'S', [['FGW', 'FMS-GW', 'FMS gateway'], ['NOF', 'FMS-NO', 'Without FMS gateway']]);

  const sNotes = [
    { value: 'S93409', name: 'Brake system software update campaign' },
    { value: 'S100234', name: 'Cab tilt sensor modification' },
    { value: 'S200111', name: 'Updated EMS calibration for low sulphur fuel' },
    { value: 'S300456', name: 'Retrofit telematics gateway' },
    { value: 'S410001', name: 'Extended powertrain warranty' },
    { value: 'S512345', name: 'Lane keeping support retrofit' },
    { value: 'S600700', name: 'ADR conversion performed' },
    { value: 'S700001', name: 'Pre-series vehicle - test status' },
  ];

  // ---------- parameter definitions ----------
  const paramDefs = {};
  function pdef(ea, code, desc, kind, opts) {
    paramDefs[`${ea}:${code}`] = Object.assign({ ea, code, description: desc, kind, refs: ['VAL'] }, opts || {});
  }
  pdef(1, 'P1ALG', 'Maximum vehicle speed (km/h)', 'int', { min: 30, max: 130, packaged: true });
  pdef(1, 'P1BCX', 'Idle shutdown time (min)', 'int', { min: 0, max: 60 });
  pdef(1, 'P1CZZ', 'Engine protection key', 'string', { hidden: true });
  pdef(1, 'P1NEW', 'Engine brake auto activation', 'bool');
  pdef(1, 'P1DGA', 'Gear shift strategy', 'enum', { values: ['ECO', 'PERFORMANCE', 'HEAVY'] });
  pdef(1, 'P1DGB', 'Kickdown enabled', 'bool');
  pdef(1, 'P1EBA', 'Brake blending level', 'int', { min: 0, max: 3 });
  pdef(1, 'P1VMA', 'Cruise control maximum speed (km/h)', 'int', { min: 30, max: 130 });
  pdef(1, 'P1VML', 'Speed limiter window (km/h)', 'int', { min: 0, max: 130, refs: ['LOW', 'HIGH'] });
  pdef(1, 'P1VMF', 'Remote immobiliser function', 'function', { isFunction: true, refs: [] });
  pdef(1, 'P1ICL', 'Default display language', 'enum', { values: ['en', 'sv', 'de', 'fr'] });
  pdef(1, 'P1ICU', 'Display units', 'enum', { values: ['METRIC', 'IMPERIAL'] });
  pdef(1, 'P1TGA', 'Telematics reporting interval (s)', 'int', { min: 10, max: 3600 });
  pdef(1, 'P1TGS', 'Telematics service identity', 'string', { hidden: true, admin: true });
  pdef(1, 'P1CCA', 'Climate auto mode', 'bool');
  pdef(1, 'P1LCA', 'Daytime running lights', 'bool');
  pdef(1, 'P1ACA', 'ACC minimum time gap', 'int', { min: 1, max: 5 });
  pdef(1, 'P1ADR', 'ADR main switch configuration', 'bool');
  pdef(1, 'P1LKS', 'Lane keeping support enabled', 'bool');
  pdef(1, 'P1APA', 'Air compressor cut-out pressure (kPa)', 'int', { min: 800, max: 1300 });
  pdef(0, 'LR', 'Legacy road speed limit key', 'string', { hidden: true });
  pdef(0, 'BAH', 'Legacy brake calibration key', 'string', { hidden: true });
  pdef(0, 'AAA', 'Road speed limit', 'int', { min: 30, max: 130 });
  pdef(0, 'ABC', 'Cruise control enabled', 'bool');
  pdef(0, 'BBA', 'Body builder PTO speed', 'int', { min: 500, max: 1800 });
  pdef(0, 'BBB', 'Body builder remote start', 'bool');
  pdef(0, 'ICX', 'Instrument cluster backlight', 'int', { min: 1, max: 10 });
  const TEA2_ENCRYPTED = ['LR', 'BAH', 'BAI', 'BAJ', 'SOK'];

  // ---------- node templates ----------
  const STATUSES = ['released', 'released', 'introduced', 'prereleaseverification', 'inprogress'];
  const WEEKS = ['202440', '202518', '202610', '202630', '202640'];
  const NOTES_EN = ['Initial production release', 'Improved diagnostics and fault code handling', 'Fuel economy calibration update', 'Support for new hardware revision, requires updated bootloader', 'Pre-series validation build'];
  const NOTES_SV = ['Första produktionsversion', 'Förbättrad diagnostik och felkodshantering', 'Uppdaterad kalibrering för bränsleekonomi', 'Stöd för ny hårdvarurevision, kräver uppdaterad bootloader', 'Validering inför serieproduktion'];
  const NOTES_DE = ['Erste Serienfreigabe', 'Verbesserte Diagnose und Fehlercodebehandlung', 'Kalibrierungsupdate für Kraftstoffverbrauch', 'Unterstützung für neue Hardware-Revision, aktualisierter Bootloader erforderlich', 'Vorserien-Validierungsbuild'];
  const NOTES_FR = ['Première version de production', 'Diagnostic amélioré', 'Mise à jour de calibration consommation', 'Prise en charge de la nouvelle révision matérielle', 'Version de validation pré-série'];

  // [key, ea, name, desc, family, type, position, mid, cab, contexts, condition, dependsOn, hwBreak, params]
  const NODE_DEFS = [
    ['EMS', 1, 'EMS', 'Engine Management System', 16, 1, 1, 128, false, [101, 102], null, [], true, [['P1ALG', (v) => (v >= 2 ? '89' : '90')], ['P1BCX', () => '5'], ['P1CZZ', () => 'K9F2-77A1'], ['P1NEW', (v) => (v >= 4 ? '1' : null)]]],
    ['TECU', 1, 'TECU', 'Transmission Control Unit', 16, 3, 1, 130, false, [101, 102], ['I-SHIFT', 'I-SHIFTDC'], ['EMS'], false, [['P1DGA', () => 'ECO'], ['P1DGB', (v) => (v >= 3 ? null : '1')]]],
    ['EBS', 1, 'EBS', 'Electronic Braking System', 20, 1, 1, 136, false, [101, 102], null, [], false, [['P1EBA', (v) => (v >= 1 ? '2' : '1')]]],
    ['VMCU', 1, 'VMCU', 'Vehicle Master Control Unit', 10, 1, 1, 144, false, [101, 102], null, ['EBS'], false, [['P1VMA', () => '85'], ['P1VML', () => ['30', '90']], ['P1VMF', () => []]]],
    ['IC', 1, 'IC', 'Instrument Cluster', 30, 2, 1, 234, true, [101, 102], null, [], true, [['P1ICL', () => 'en'], ['P1ICU', () => 'METRIC']]],
    ['TGW', 1, 'TGW', 'Telematics Gateway', 40, 1, 1, 252, true, [101, 102], ['TELM-DYN'], [], false, [['P1TGA', (v) => (v >= 3 ? '30' : '60')], ['P1TGS', () => 'TGW-SVC-0042']]],
    ['CCM', 1, 'CCM', 'Climate Control Module', 31, 1, 1, 225, true, [101, 102], null, [], false, [['P1CCA', () => '1']]],
    ['LCM', 1, 'LCM', 'Light Control Module', 32, 1, 1, 216, true, [101, 102], null, [], false, [['P1LCA', () => '1']]],
    ['ACC', 1, 'ACC', 'Adaptive Cruise Radar', 21, 4, 1, 219, false, [101, 102], ['ACC-ADV', 'ACC-BAS'], ['VMCU'], false, [['P1ACA', () => '3']]],
    ['APM', 1, 'APM', 'Air Production Module', 22, 1, 1, 150, false, [101, 102], null, [], false, [['P1APA', () => '1250']]],
    ['BBM', 2, 'BBM', 'Body Builder Module', null, null, null, 249, false, [101], ['BBM-ADV', 'BBM-BAS'], [], false, [['BBA', () => '900', 0], ['BBB', () => '0', 0]]],
    ['T2EMS', 0, 'EMS', 'Engine Management System (TEA2)', null, null, null, 128, false, [103], null, [], false, [['AAA', () => '90', 0], ['LR', () => 'LR-33A9', 0]]],
    ['T2TECU', 0, 'TECU', 'Transmission Control Unit (TEA2)', null, null, null, 130, false, [103], ['I-SHIFT'], ['T2EMS'], false, [['BAH', () => 'B7-001', 0]]],
    ['T2EBS', 0, 'EBS', 'Electronic Braking System (TEA2)', null, null, null, 136, false, [103], null, [], false, []],
    ['T2VECU', 0, 'VECU', 'Vehicle ECU (TEA2)', null, null, null, 144, false, [103], null, [], false, [['ABC', () => '1', 0]]],
    ['T2IC', 0, 'IC', 'Instrument Cluster (TEA2)', null, null, null, 140, true, [103], null, [], false, [['ICX', () => '7', 0]]],
    ['VCM', 3, 'VCM', 'Vehicle Control Module HPC', 50, 1, 1, null, false, [104], null, ['CGW'], true, []],
    ['CGW', 3, 'CGW', 'Central Gateway HPC', 51, 1, 1, null, false, [104], null, [], false, []],
  ];
  const hwNames = {};
  const defs = NODE_DEFS.map((d, i) => {
    const [key, ea, name, desc, family, type, position, mid, cab, ctxs, condition, dependsOn, hwBreak, params] = d;
    const hwBase = 21600000 + i * 100;
    const hw = [hwBase + 1, hwBase + 2];
    hwNames[hw[0]] = `${name} ECU rev A`;
    hwNames[hw[1]] = `${name} ECU rev B`;
    const def = { key, index: i, ea, name, description: desc, family, type, position, mid, cab, contexts: ctxs, condition, dependsOn, hwBreak, hw, params, versions: [] };
    if (key === 'IC') { def.subHw = [{ name: 'Display unit', number: 21661001 }]; hwNames[21661001] = 'Display unit'; }
    if (key === 'TGW') { def.subHw = [{ name: 'GNSS antenna', number: 21671001 }, { name: 'LTE modem', number: 21671002 }]; hwNames[21671001] = 'GNSS antenna'; hwNames[21671002] = 'LTE modem'; }
    const docBase = (ea === 0 ? 20100000 : ea === 2 ? 20500000 : 22100000) + i * 100;
    for (let v = 0; v < 5; v++) {
      const status = STATUSES[v];
      const ver = {
        idx: v, doc: docBase + v * 10, status, introductionWeek: WEEKS[v],
        versionName: `${name}_${WEEKS[v].slice(2, 4)}.${WEEKS[v].slice(4)}${ea === 0 ? '_T2' : ''}`,
        chain: v >= 3 ? `${name}-RC2` : `${name}-RC1`,
        hardware: hwBreak && v >= 3 ? [hw[1]] : hw.slice(),
        remoteCapable: v >= 1 && [1, 3].includes(ea),
        requires: v >= 3 ? dependsOn.map((k) => ({ key: k, minIdx: 2 })) : [],
        releaseNotes: { 'en-GB': `${desc} ${name}: ${NOTES_EN[v]}`, 'sv-SE': `${desc} ${name}: ${NOTES_SV[v]}`, 'de-DE': `${desc} ${name}: ${NOTES_DE[v]}`, 'fr-FR': `${desc} ${name}: ${NOTES_FR[v]}` },
        msw: 23100000 + i * 100 + v * 10 + 1,
        pbl: 23500000 + i * 100 + (v >= 3 ? 2 : 1),
        sbl: 23600000 + i * 100 + (v >= 4 ? 3 : v >= 2 ? 2 : 1),
        data1: 23200000 + i * 100 + v * 10 + 2,
        data2: i % 3 === 0 ? 23200000 + i * 100 + 5 : null,
        patch: v >= 2 && i % 2 === 0 ? 23300000 + i * 100 + v * 10 + 3 : null,
        csw: key === 'IC' ? 23400000 + i * 100 + v * 10 + 4 : null,
        sha: {},
      };
      ['msw', 'pbl', 'sbl', 'data1', 'data2', 'patch', 'csw'].forEach((k) => { if (ver[k]) ver.sha[k] = [hex(40), hex(40)]; });
      def.versions.push(ver);
    }
    return def;
  });
  const defByKey = {};
  defs.forEach((d) => { defByKey[d.key] = d; });
  const versionIndex = {};
  defs.forEach((d) => d.versions.forEach((v, idx) => { versionIndex[v.doc] = { def: d, idx, v }; }));

  function serialFor(seedStr) {
    let h = 0;
    for (const c of String(seedStr)) h = (h * 31 + c.charCodeAt(0)) | 0;
    return 'SN' + String(Math.abs(h) % 100000000).padStart(8, '0');
  }

  function dp(name, number, sha, extra) {
    return Object.assign({ name, number, quantity: 1, fieldNumber: null, softwareDownloadSignature: '', compressionMethod: 0, encryptionMethod: 0, offsetAddress: 0, isNotProgrammable: false, nodeTemplateDocumentNumber: null, artifactSHA: sha ? sha[0] : '', descriptionFileNumber: number + 50000000 > 99999999 ? null : number + 50000000, descriptionFileSHA: sha ? sha[1] : '', notifications: [], source: null }, extra || {});
  }
  const part = (name, number, fieldNumber, extra) => Object.assign({ name, number, fieldNumber: fieldNumber || null, quantity: 1, notifications: [], source: null }, extra || {});

  function identifierFor(def) {
    return { position: def.position, type: def.type, family: def.family, mid: def.mid, name: def.name, electricalArchitecture: def.ea, fieldNumbers: [] };
  }

  /** Build a complete node from a node template version. opts: {hw, serial, source} */
  function buildNode(def, vIdx, opts) {
    opts = opts || {};
    const v = def.versions[vIdx];
    const id = identifierFor(def);
    const hwNum = opts.hw || v.hardware[v.hardware.length - 1];
    const n = {
      electricalArchitecture: def.ea, nodeIdentifier: id, name: M.derivedName(id),
      nodeTemplateDocument: part('NTP', v.doc, null), versionName: v.versionName, replacementChainName: v.chain, nodeTemplateStatus: v.status,
      isCabNode: !!def.cab, isSoftwareSame: true, notifications: [],
      ecuHardware: part('ECU', hwNum, def.ea === 1 ? null : '0', { serialNumber: opts.serial || serialFor(def.key + hwNum) }),
    };
    const src = opts.source || null;
    if (def.ea === 3) {
      n.softwareProducts = ['Platform', 'Application'].map((name, index) => Object.assign(
        dp(name, index ? v.data1 : v.msw, index ? v.sha.data1 : v.sha.msw),
        { index, softwareProduct: def.key + '-' + name, packageVersion: '1.' + vIdx + '.0', executionEnvironment: def.key + '-Linux', logicalEcu: def.key + '-LECU', source: src }));
      n.nodePath = '/' + def.name;
    } else if (def.ea === 1) {
      n.mainSoftware = dp('MSW', v.msw, v.sha.msw, { source: src });
      n.primaryBootloader = dp('PBL', v.pbl, v.sha.pbl);
      n.secondaryBootloader = dp('SBL', v.sbl, v.sha.sbl);
      n.datas = [Object.assign(dp('Data 1', v.data1, v.sha.data1, { source: src }), { isPatchable: true, isCertified: true, patches: v.patch ? [Object.assign(part('Patch 1', v.patch, null), { offsetAddress: 4096, nodeTemplateDocumentNumber: null, artifactSHA: v.sha.patch[0], descriptionFileNumber: null, descriptionFileSHA: v.sha.patch[1], index: 0 })] : [] })];
      if (v.data2) n.datas.push(Object.assign(dp('Data 2', v.data2, v.sha.data2, { source: src }), { isPatchable: false, isCertified: true, patches: [] }));
      n.datas.forEach((d, i) => { d.index = i; });
      n.complementarySoftwares = v.csw ? [Object.assign(dp('CSW Language', v.csw, v.sha.csw), { index: 0 })] : [];
      n.subHardwares = (def.subHw || []).map((s, i) => part(s.name, s.number, null, { serialNumber: serialFor(def.key + s.number), index: i }));
      n.nodeState = v.status === 'inprogress' ? 1 : 0;
      n.nodePath = `/${def.family}/${def.type}/${def.position}`;
    } else if (def.ea === 0) {
      n.mainSoftware = part('Main Software', v.msw, '1', { source: src });
      n.downloader = part('Downloader', v.pbl, '2');
      n.dataSet1 = part('Data Set 1', v.data1, '3', { source: src });
      n.dataSet2 = v.data2 ? part('Data Set 2', v.data2, '4') : null;
      n.complementarySoftwares = [];
      n.subSoftwares = [part('Sub Software', v.sbl, '5', { index: 0 })];
      n.subDataSets = v.patch ? [part('Sub Data Set', v.patch, '6', { index: 0 })] : [];
      n.subComplementarySoftwares = [];
    } else {
      n.mainSoftware = part('Main Software', v.msw, '1', { source: src });
      n.subSoftwares = [part('Sub Software', v.sbl, '2', { index: 0 })];
      n.softwareFunctions = [part('Software Function', v.data1, '10', { index: 0 }), part('Software Function', v.pbl + 7, '11', { index: 1 })];
    }
    return n;
  }

  function buildParams(def, vIdx, source) {
    const out = [];
    for (const [code, fn, eaOverride] of def.params) {
      const ea = eaOverride !== undefined ? eaOverride : def.ea === 1 ? 1 : 0;
      const val = fn(vIdx);
      if (val === null) continue;
      const pd = paramDefs[`${ea}:${code}`] || { refs: ['VAL'] };
      let references;
      if (pd.isFunction) references = [];
      else if (Array.isArray(val)) references = pd.refs.map((r, i) => ({ code: r, value: val[i] }));
      else references = [{ code: pd.refs[0] || 'VAL', value: val }];
      out.push({ code, electricalArchitecture: ea, references, packaged: !!pd.packaged, isGroupAdministrative: !!pd.admin, isFunction: !!pd.isFunction, valueNotVisibleToUser: false, source: source || null, notifications: [] });
    }
    return out;
  }

  // ---------- lookups ----------
  const variantByIdVar6 = (id) => { const v = variants.find((x) => x.idVar6 === id); return v ? clone(v) : null; };
  const variantBySymbol = (s) => { if (!s) return null; const v = variants.find((x) => x.symbol === String(s).trim().toUpperCase()); return v ? clone(v) : null; };
  const sNoteName = (v) => { const s = sNotes.find((x) => x.value === v); return s ? s.name : ''; };
  function findDef(id) {
    if (!id) return null;
    return defs.find((d) => d.ea === id.electricalArchitecture && ([1, 3].includes(d.ea) ? d.family === Number(id.family) && d.type === Number(id.type) && d.position === Number(id.position) : d.mid === Number(id.mid))) || null;
  }
  const versionByDoc = (doc) => versionIndex[Number(doc)] || null;
  const paramDef = (ea, code) => paramDefs[`${ea === undefined || ea === null ? 1 : ea}:${code}`] || null;
  const defsForContext = (ctxId) => defs.filter((d) => d.contexts.includes(ctxId));
  const conditionMet = (def, symbols) => !def.condition || def.condition.some((s) => symbols.has(s));

  // ---------- products ----------
  const factories = [
    { code: '58', name: 'Tuve' }, { code: '14', name: 'Ghent' }, { code: '21', name: 'Umeå' }, { code: '72', name: 'New River Valley' }, { code: '30', name: 'Bourg-en-Bresse' },
  ];
  const languageCodes = ['en-GB', 'sv-SE', 'de-DE', 'fr-FR'];

  function makeProduct(cfg) {
    const symbols = new Set(cfg.variants);
    const ctx = contexts.find((c) => c.id === cfg.ctx);
    const factory = factories.find((f) => f.code === cfg.factory) || factories[0];
    const p = {
      productSpecification: {
        productInformation: {
          electricalArchitecture: cfg.ctx === 104 ? 3 : null, chassisSeries: cfg.series, chassisNumber: cfg.number, vin: cfg.vin, productClassId: cfg.pc, modelId: cfg.model, chassisType: cfg.chassisType || 'Normal',
          assemblyDate: cfg.assembly, deliveryDate: cfg.delivery, specificationDate: cfg.specDate || cfg.assembly, introductionWeek: TR.util.yearWeek(cfg.specDate || cfg.assembly),
          assemblyFactory: factory.name, assemblyFactoryCode: factory.code, releaseFactory: factory.name, companyCode: cfg.company || 'VTC', countryOfOperation: cfg.country || 'SE',
          inactiveCode: '', registrationNumber: cfg.reg || '', testStatus: cfg.testStatus || '', notifications: [], context: null,
          baselineName: '', baselineGuid: '', baselineUrl: '', servicePackName: '', servicePackUrl: '', servicePackGuid: '', connectedServices: [],
        },
        variants: cfg.variants.map((s) => variantBySymbol(s)).filter(Boolean),
        sNotes: (cfg.snotes || []).map((v) => ({ value: v, name: sNoteName(v), source: null })),
      },
      softwareRelatedHardwares: [], nodes: [], parameters: [], breakdownInformation: { notifications: [] }, vdaCampaigns: cfg.campaigns || [],
    };
    for (const def of defsForContext(ctx.id)) {
      if (!conditionMet(def, symbols)) continue;
      const vIdx = cfg.versions && cfg.versions[def.key] !== undefined ? cfg.versions[def.key] : cfg.defaultVersion;
      if (vIdx === null) continue;
      const hw = cfg.hw && cfg.hw[def.key] ? def.hw[cfg.hw[def.key]] : def.hw[0];
      p.nodes.push(buildNode(def, vIdx, { hw }));
      buildParams(def, vIdx).forEach((x) => { if (!p.parameters.some((y) => y.code === x.code && y.electricalArchitecture === x.electricalArchitecture)) p.parameters.push(x); });
    }
    (cfg.paramOverrides || []).forEach(([code, value]) => { const x = p.parameters.find((y) => y.code === code); if (x && x.references[0]) x.references[0].value = value; });
    if (cfg.mutate) cfg.mutate(p);
    p.nodes.sort(M.compareNodes);
    p.parameters.sort(M.compareParameters);
    return p;
  }

  const nodeIdOf = (key) => identifierFor(defByKey[key]);
  const campaignsFH = [
    {
      sccNo: 'SC-24-0912', description: 'Brake system software update', performed: null, status: 'Open', performingDealerId: '', repairingImporterId: '',
      operations: [{ no: 1, description: 'Update EBS software to latest released version', kitPartNumber: 0, nodeIdentifier: nodeIdOf('EBS'), performed: null, status: 'Open', dealerId: '', countryCode: '' },
        { no: 2, description: 'Update VMCU software', kitPartNumber: 0, nodeIdentifier: nodeIdOf('VMCU'), performed: null, status: 'Open', dealerId: '', countryCode: '' }],
    },
    {
      sccNo: 'SC-25-0101', description: 'ADR conversion for fleet customer', performed: null, status: 'Open', performingDealerId: '', repairingImporterId: '',
      operations: [{ no: 1, description: 'Install ADR conversion kit', kitPartNumber: 23187002, nodeIdentifier: null, performed: null, status: 'Open', dealerId: '', countryCode: '' }],
    },
    {
      sccNo: 'SC-23-0450', description: 'Instrument cluster display flicker', performed: '2024-05-02T09:30:00Z', status: 'Closed', performingDealerId: 'D-11873', repairingImporterId: 'IMP-SE01',
      operations: [{ no: 1, description: 'Reprogram instrument cluster', kitPartNumber: 0, nodeIdentifier: nodeIdOf('IC'), performed: '2024-05-02T09:30:00Z', status: 'Performed', dealerId: 'D-11873', countryCode: 'SE' }],
    },
  ];

  const vdaSeed = [
    makeProduct({
      series: 'FH', number: '123456', vin: 'YV2RT40A5LB123456', pc: 'FH', model: 'FH 500 4x2T', ctx: 101, factory: '58', assembly: '2025-03-14T00:00:00Z', delivery: '2025-04-02T00:00:00Z', reg: 'ABC 123', country: 'SE',
      variants: ['D13K500', 'LHD', 'I-SHIFT', '6X2', 'CAB-GLXL', 'TELM-DYN', 'ACC-ADV', 'ADR-NO', 'LANG-EN', 'LANG-SV', 'LKS', 'ESP', 'BBM-ADV', 'EURO6', 'FMS-GW'],
      snotes: ['S93409', 'S200111'], defaultVersion: 1, versions: { EMS: 0, TGW: 1, BBM: 1 }, hw: {}, campaigns: campaignsFH, paramOverrides: [['P1ALG', '85'], ['P1TGA', '120']],
      mutate: (p) => { const ic = p.nodes.find((n) => n.nodeIdentifier.name === 'IC'); if (ic) ic.datas[0].number = 23240099; },
    }),
    makeProduct({
      series: 'FM', number: '654321', vin: 'YV2XG30C7MA654321', pc: 'FM', model: 'FM 450 4x2R', ctx: 101, factory: '14', assembly: '2026-02-10T00:00:00Z', delivery: '2026-03-01T00:00:00Z', country: 'BE',
      variants: ['D11K450', 'RHD', 'MAN-GBX', '4X2', 'CAB-DAY', 'TELM-NO', 'ACC-NO', 'ADR-NO', 'LANG-EN', 'BBM-NO', 'EURO6', 'FMS-NO'],
      snotes: ['S100234'], defaultVersion: 2, hw: { EMS: 1, IC: 1 },
    }),
    makeProduct({
      series: 'VNL', number: '700100', vin: '4V4NC9EH5PN700100', pc: 'VNL', model: 'VNL 860', ctx: 102, factory: '72', assembly: '2025-09-22T00:00:00Z', delivery: '2025-10-15T00:00:00Z', country: 'US', company: 'VTNA',
      variants: ['D13K500', 'LHD', 'I-SHIFT', '6X4', 'CAB-SLP', 'TELM-DYN', 'ACC-BAS', 'LANG-EN', 'EPA17', 'FMS-GW'], snotes: [], defaultVersion: 1, hw: {},
    }),
    makeProduct({
      series: 'RT', number: '000777', vin: 'VF611A165KD000777', pc: 'RT', model: 'T 480 4x2', ctx: 103, factory: '30', assembly: '2019-06-11T00:00:00Z', delivery: '2019-07-01T00:00:00Z', country: 'FR', company: 'RTF',
      variants: ['D11K450', 'LHD', 'I-SHIFT', '4X2', 'CAB-SLP', 'EURO6', 'LANG-FR'], snotes: ['S410001'], defaultVersion: 1, hw: {},
    }),
    makeProduct({
      series: 'A', number: '550555', vin: 'YV2RTY0A8MA550555', pc: 'FH', model: 'FH 540 6x4T', ctx: 101, factory: '58', assembly: '2021-03-22T00:00:00Z', delivery: '2021-04-20T00:00:00Z', country: 'SE',
      variants: ['D13K500', 'LHD', 'I-SHIFT', '6X4', 'CAB-GL', 'TELM-DYN', 'ACC-BAS', 'ADR-NO', 'LANG-EN', 'BBM-NO', 'EURO6', 'FMS-GW'], snotes: ['S93409'], defaultVersion: 2, hw: { IC: 1, TGW: 1 },
    }),
    makeProduct({
      series: 'FH', number: '000042', vin: 'YV2RT40A1NB000042', pc: 'FH', model: 'FH 460 4x2T (pre-series)', ctx: 101, factory: '21', assembly: '2026-08-03T00:00:00Z', delivery: null, country: 'SE', testStatus: 'Design', chassisType: 'Development',
      variants: ['D13K500', 'LHD', 'I-SHIFTDC', '4X2', 'CAB-GLXL', 'TELM-DYN', 'ACC-ADV', 'LANG-EN', 'LANG-DE', 'DAS', 'BBM-BAS', 'EURO6', 'FMS-GW'], snotes: ['S700001'], defaultVersion: 3, hw: { EMS: 1, IC: 1 },
      mutate: (p) => { const ems = p.nodes.find((n) => n.nodeIdentifier.name === 'EMS'); if (ems) ems.nodeTemplateDocument = null; },
    }),
  ];

  vdaSeed.push(makeProduct({ series: 'FH', number: '333333', vin: 'YV2RT40A5TB333333', pc: 'FH', model: 'FH T3 HPC', ctx: 104, factory: '58', assembly: '2026-03-14T00:00:00Z', delivery: '2026-04-02T00:00:00Z', variants: ['D13K500', 'LHD', 'I-SHIFT', '4X2', 'CAB-GLXL', 'LANG-EN', 'EURO6'], defaultVersion: 0 }));

  const edbSpecs = {
    'VSS-12-345': { productClassId: 'FH', modelId: 'FH 500 4x2T', factory: '58', specDate: '2026-09-28T00:00:00Z', variants: ['D13K500', 'LHD', 'I-SHIFT', '4X2', 'CAB-GLXL', 'TELM-DYN', 'ACC-ADV', 'LANG-EN', 'LKS', 'ESP', 'BBM-BAS', 'EURO6', 'FMS-GW'], snotes: [] },
    'RT_ORDER 1001': { productClassId: 'RT', modelId: 'T 480 4x2', factory: '30', specDate: '2026-05-04T00:00:00Z', variants: ['D11K450', 'LHD', 'I-SHIFT', '4X2', 'CAB-SLP', 'EURO6', 'LANG-FR'], snotes: [] },
    '88001': { productClassId: 'FM', modelId: 'FM 330 6x2R', factory: '14', specDate: '2026-07-13T00:00:00Z', variants: ['D8K350', 'RHD', 'MAN-GBX', '6X2', 'CAB-DAY', 'TELM-NO', 'ACC-NO', 'LANG-EN', 'BBM-ADV', 'EURO6', 'FMS-NO'], snotes: ['S100234'] },
    'VSS-26-900': { productClassId: 'VNL', modelId: 'VNL 760', factory: '72', specDate: '2026-09-07T00:00:00Z', variants: ['D13K500', 'LHD', 'I-SHIFT', '6X4', 'CAB-SLP', 'TELM-DYN', 'ACC-ADV', 'LANG-EN', 'EPA17', 'FMS-GW'], snotes: [] },
  };

  // ---------- baselines & service packs ----------
  const baselines = [];
  const servicePacks = [];
  const BL = [
    [104, 'T3 Baseline 2026w10', 'BL-T3-2610', 2, 4, '2026-03-05'],
    [101, 'EU HD Baseline 2025w18', 'BL-EU-2518', 1, 5, '2025-05-01'], [101, 'EU HD Baseline 2026w10', 'BL-EU-2610', 2, 4, '2026-03-05'], [101, 'EU HD Baseline 2026w30', 'BL-EU-2630', 3, 3, '2026-07-23'],
    [102, 'NA HD Baseline 2025w18', 'BL-NA-2518', 1, 5, '2025-05-01'], [102, 'NA HD Baseline 2026w10', 'BL-NA-2610', 2, 4, '2026-03-05'],
    [103, 'TEA2 Legacy Baseline 2025w18', 'BL-T2-2518', 1, 5, '2025-05-01'], [103, 'TEA2 Legacy Baseline 2026w10', 'BL-T2-2610', 2, 3, '2026-03-05'],
  ];
  BL.forEach(([ctx, name, identifier, vIdx, state, date]) => {
    ['1.0', '1.1'].forEach((version, vi) => {
      const ntps = {};
      defsForContext(ctx).forEach((d) => { ntps[d.key] = vi === 1 && d.key === 'EBS' ? Math.min(vIdx + 1, 4) : vIdx; });
      baselines.push({ guid: guid(), name: vi === 0 ? name : `${name} (1.1)`, identifier, version, contextId: ctx, state, typeCode: 3, introductionDate: date, ntps, docs: Object.keys(ntps).map((k) => defByKey[k].versions[ntps[k]].doc), category: vi === 0 ? 'Aftermarket' : 'System' });
    });
  });
  [[104, 'T3 SP 2026.1', 'T3', 1, 2], [101, 'SP 2025.2', 'EU', 1, 1], [101, 'SP 2026.1', 'EU', 2, 2], [102, 'NA SP 2025.2', 'NA', 1, 1], [102, 'NA SP 2026.1', 'NA', 2, 2], [103, 'TEA2 SP 2025', 'T2', 1, 1]].forEach(([ctx, name, branch, sortOrder, vIdx]) => {
    const ntps = {};
    defsForContext(ctx).forEach((d) => { ntps[d.key] = vIdx; });
    servicePacks.push({ guid: guid(), name, branch, sortOrder, contextId: ctx, ntps, docs: Object.keys(ntps).map((k) => defByKey[k].versions[ntps[k]].doc) });
  });

  // ---------- conversion kits ----------
  function kitDelta(spec) {
    const d = M.emptyDelta();
    (spec.addVariants || []).forEach((s) => { const v = variantBySymbol(s); if (v) d.productSpecification.variants.push({ type: E.Op.AssignVariant, value: v }); });
    (spec.removeVariants || []).forEach((s) => { const v = variantBySymbol(s); if (v) d.productSpecification.variants.push({ type: E.Op.RemoveVariant, value: v }); });
    (spec.addSNotes || []).forEach((s) => d.productSpecification.sNotes.push({ type: E.Op.AssignSNote, value: { value: s, name: sNoteName(s), source: null } }));
    (spec.nodes || []).forEach(([key, vIdx, hwIdx]) => { const def = defByKey[key]; d.nodes.push({ type: E.NodeOps.replace[def.ea], value: buildNode(def, vIdx, { hw: def.hw[hwIdx || 0] }) }); buildParams(def, vIdx).forEach((p) => d.parameters.push({ type: E.Op.AssignParameter, value: p })); });
    (spec.params || []).forEach(([code, value]) => d.parameters.push({ type: E.Op.AssignParameter, value: { code, electricalArchitecture: 1, references: [{ code: 'VAL', value }], packaged: false, isGroupAdministrative: false, isFunction: false, valueNotVisibleToUser: false, source: null, notifications: [] } }));
    return d;
  }
  const kitsSeed = [
    { partNumber: 23187001, name: 'Telematics retrofit kit', state: 'Released', isServiceKit: false, isCampaignKit: false, productClasses: ['FH', 'FM'], delta: kitDelta({ addVariants: ['TELM-DYN'], removeVariants: ['TELM-NO'], addSNotes: ['S300456'], nodes: [['TGW', 2, 1]] }) },
    { partNumber: 23187002, name: 'ADR conversion kit', state: 'Released', isServiceKit: true, isCampaignKit: true, productClasses: ['FH', 'FM', 'VNL'], delta: kitDelta({ addVariants: ['ADR'], removeVariants: ['ADR-NO'], addSNotes: ['S600700'], params: [['P1ADR', '1']] }) },
    { partNumber: 23187003, name: 'Lane keeping support retrofit', state: 'Introduced', isServiceKit: false, isCampaignKit: false, productClasses: ['FH', 'FM'], delta: kitDelta({ addVariants: ['LKS'], addSNotes: ['S512345'], params: [['P1LKS', '1']] }) },
    { partNumber: 23187004, name: 'EMS hardware upgrade kit', state: 'In Progress', isServiceKit: true, isCampaignKit: false, productClasses: ['FH', 'FM'], delta: kitDelta({ nodes: [['EMS', 3, 1]] }) },
  ];

  // ---------- spare cab orders (shape of the CBR API sample A-550555_OrderNumber_99850557) ----------
  function cbrOrder(orderNumber, type, number, symbols, parts, snotes) {
    return {
      OrderNumber: orderNumber, MainFactory: '58', EndFactory: '58', ChassieType: type, ChassieNumber: number, AssemblyDate: '2021-03-22T00:00:00', PackDate: '2021-03-18T00:00:00', OrderStatus: 'Firm', IdentificationNumber: 'ID' + orderNumber,
      VariantString: { variants: symbols.map((s) => { const v = variantBySymbol(s); return { IdVar6: v.idVar6, Symbol: v.symbol.padEnd(8, ' ') }; }) },
      OrderComponentBom: [{ KolaFactory: '58', ComponentFactory: '1540', ComponentId: 'CAB-' + orderNumber, ComponentType: 'BW', SubComponentType: 'CAB', SerialNumber: serialFor(orderNumber), GateDate: '2021-03-15', Part: parts.map(([pn, desc, q]) => ({ PartNumber: String(pn), PartDescription: desc, Quantity: q, UnitOfMeasure: 'PCE', KolaPartType: 'L', ValidFrom: '2021121 (2021-03-22)', ValidTo: null, FunctionGroup: '36' })) }],
      OrderSnotes: (snotes || []).map((s) => ({ Snote: s, SnoteVersion: null })),
    };
  }
  const spareCabOrders = {
    '99850557': cbrOrder('99850557', 'A', 550555, ['CAB-GLXL', 'LHD', 'TELM-DYN', 'LANG-EN', 'LANG-SV', 'DAS'], [[defByKey.IC.hw[1], 'Instrument cluster rev B', 1], [defByKey.TGW.hw[1], 'Telematics gateway rev B', 1], [defByKey.CCM.hw[1], 'Climate control module rev B', 1], [defByKey.LCM.hw[0], 'Light control module rev A', 0], [82145510, 'Cab wiring harness', 1]], ['S93409']),
    '99850558': cbrOrder('99850558', 'FH', 123456, ['CAB-SLP', 'LHD', 'TELM-DYN', 'LANG-EN'], [[defByKey.IC.hw[1], 'Instrument cluster rev B', 1], [defByKey.TGW.hw[0], 'Telematics gateway rev A', 1]], []),
  };

  const users = ['A123456', 'B654321', 'C111222', 'NAMSUSER'];

  TR.db = {
    productClasses, contexts, families, variants, sNotes, paramDefs, TEA2_ENCRYPTED, defs, defByKey, hwNames, factories, languageCodes,
    vdaSeed, edbSpecs, baselines, servicePacks, kitsSeed, spareCabOrders, users, campaignsFH,
    buildNode, buildParams, identifierFor, variantByIdVar6, variantBySymbol, sNoteName, findDef, versionByDoc, paramDef, defsForContext, conditionMet, serialFor, kitDelta, hex, guid,
  };
})();
