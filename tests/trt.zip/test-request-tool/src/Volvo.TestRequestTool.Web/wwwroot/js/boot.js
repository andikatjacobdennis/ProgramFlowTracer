    (function () {
      var h = TR.util.h;
      var dl = document.getElementById('datalists');
      dl.appendChild(h('datalist', { id: 'edb-specs' }, Object.keys(TR.db.edbSpecs).map(function (k) { return h('option', { value: k }); })));
      dl.appendChild(h('datalist', { id: 'kit-numbers' }, TR.server.state.kits.map(function (k) { return h('option', { value: String(k.partNumber) }, k.name + ' (' + k.state + ')'); })));
      // Tell the start-up guard (theme-boot.js) when the first screen is on the page, so a later error is handled by the app
      // itself and not by the recovery screen.
      var app = document.getElementById('app');
      var done = function () { if (app.querySelector('.s-layout') && window.TRBoot) { window.TRBoot.ready(); return true; } return false; };
      if (!done()) { var watch = new MutationObserver(function () { if (done()) watch.disconnect(); }); watch.observe(app, { childList: true, subtree: true }); }
      Promise.resolve(TR.backend.start(TR.shellInit)).catch(function (e) { if (window.TRBoot) window.TRBoot.fail(e && e.message ? e.message : String(e)); });
    })();
