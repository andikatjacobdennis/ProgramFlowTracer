/* Generic helpers: DOM builder, cloning, equality, dates, downloads, storage. */
(function () {
  'use strict';
  const TR = (window.TR = window.TR || {});

  const PROPS = new Set(['disabled', 'readOnly', 'multiple', 'indeterminate', 'htmlFor', 'tabIndex', 'spellcheck', 'textContent']);
  const DEFERRED = new Set(['value', 'checked', 'selected']);

  function append(el, kids) {
    for (const k of kids) {
      if (k === null || k === undefined || k === false || k === true) continue;
      if (Array.isArray(k)) append(el, k);
      else if (k instanceof Node) el.appendChild(k);
      else el.appendChild(document.createTextNode(String(k)));
    }
  }

  /** Hyperscript: h('div', {class: 'x', onClick: fn}, child, [children]) */
  function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    let deferred = null;
    if (attrs) {
      for (const k of Object.keys(attrs)) {
        const v = attrs[k];
        if (v === undefined || v === null || v === false) continue;
        if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
        else if (k === 'class') {
          const c = Array.isArray(v) ? v.filter(Boolean).join(' ') : v;
          if (c) el.className = c;
        } else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
        else if (k === 'html') el.innerHTML = v;
        else if (k === 'key') el.dataset.key = v;
        else if (DEFERRED.has(k)) (deferred = deferred || {})[k] = v;
        else if (PROPS.has(k)) el[k] = v;
        else el.setAttribute(k, v === true ? '' : String(v));
      }
    }
    append(el, kids);
    if (deferred) for (const k in deferred) el[k] = deferred[k];
    return el;
  }

  function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }

  const clone = (o) => (o === undefined ? undefined : JSON.parse(JSON.stringify(o)));

  function deepEqual(a, b) {
    if (a === b) return true;
    if (a == null || b == null) return a == b;
    if (typeof a !== typeof b) return false;
    if (typeof a !== 'object') return a === b;
    if (Array.isArray(a) !== Array.isArray(b)) return false;
    if (Array.isArray(a)) {
      if (a.length !== b.length) return false;
      for (let i = 0; i < a.length; i++) if (!deepEqual(a[i], b[i])) return false;
      return true;
    }
    const ka = Object.keys(a).filter((k) => a[k] !== undefined);
    const kb = Object.keys(b).filter((k) => b[k] !== undefined);
    if (ka.length !== kb.length) return false;
    for (const k of ka) if (!deepEqual(a[k], b[k])) return false;
    return true;
  }

  function debounce(fn, ms) {
    let t = null;
    return function (...args) { clearTimeout(t); t = setTimeout(() => fn.apply(this, args), ms); };
  }

  const pad = (n, w = 2, c = '0') => String(n).padStart(w, c);

  function toDate(v) { if (!v) return null; const d = v instanceof Date ? v : new Date(v); return isNaN(d) ? null : d; }
  function fmtDate(v) { const d = toDate(v); return d ? `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}` : ''; }
  function fmtDateTime(v, utc) {
    const d = toDate(v);
    if (!d) return '';
    if (utc) return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
    return `${fmtDate(d)} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }
  /** ISO-8601 week -> 'YYYYWW' */
  function yearWeek(v) {
    const d0 = toDate(v);
    if (!d0) return '';
    const d = new Date(Date.UTC(d0.getFullYear(), d0.getMonth(), d0.getDate()));
    const day = d.getUTCDay() || 7;
    d.setUTCDate(d.getUTCDate() + 4 - day);
    const yStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
    const week = Math.ceil(((d - yStart) / 86400000 + 1) / 7);
    return `${d.getUTCFullYear()}${pad(week)}`;
  }

  function uuid() {
    if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      const r = (Math.random() * 16) | 0;
      return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
    });
  }

  function download(fileName, text, mime) {
    const blob = new Blob([text], { type: mime || 'text/xml' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch (e) {
      const ta = h('textarea', { style: { position: 'fixed', left: '-9999px' } });
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      let ok = false;
      try { ok = document.execCommand('copy'); } catch (e2) { ok = false; }
      ta.remove();
      return ok;
    }
  }

  const store = {
    get(key, def) {
      try { const v = localStorage.getItem(key); return v == null ? def : JSON.parse(v); } catch (e) { return def; }
    },
    set(key, val) {
      try { localStorage.setItem(key, JSON.stringify(val)); return true; } catch (e) { return false; }
    },
    remove(key) { try { localStorage.removeItem(key); } catch (e) { /* ignore */ } },
  };

  /** Re-render while keeping focus, caret and scroll positions (elements tagged with data-key / data-scroll). */
  function preserve(fn) {
    const a = document.activeElement;
    const key = a && a.dataset ? a.dataset.key : null;
    let sel = null;
    try { if (key && typeof a.selectionStart === 'number') sel = [a.selectionStart, a.selectionEnd]; } catch (e) { sel = null; }
    const scrolls = {};
    document.querySelectorAll('[data-scroll]').forEach((e) => { scrolls[e.dataset.scroll] = [e.scrollTop, e.scrollLeft]; });
    fn();
    document.querySelectorAll('[data-scroll]').forEach((e) => {
      const s = scrolls[e.dataset.scroll];
      if (s) { e.scrollTop = s[0]; e.scrollLeft = s[1]; }
    });
    if (key) {
      const n = document.querySelector(`[data-key="${CSS.escape(key)}"]`);
      if (n) {
        n.focus();
        if (sel) { try { n.setSelectionRange(sel[0], sel[1]); } catch (e) { /* not a text input */ } }
      }
    }
  }

  function readFileText(file) {
    return new Promise((resolve, reject) => {
      const r = new FileReader();
      r.onload = () => resolve(String(r.result));
      r.onerror = () => reject(r.error);
      r.readAsText(file);
    });
  }

  function pickFile(accept) {
    return new Promise((resolve) => {
      const inp = h('input', { type: 'file', accept: accept || '.xml', style: { display: 'none' } });
      inp.addEventListener('change', () => { resolve(inp.files[0] || null); inp.remove(); });
      document.body.appendChild(inp);
      inp.click();
    });
  }

  const uniq = (arr) => Array.from(new Set(arr));
  const splitList = (s, re) => String(s || '').split(re || /[,\s]+/).map((x) => x.trim()).filter(Boolean);
  const escapeHtml = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  TR.util = { h, clear, clone, deepEqual, debounce, pad, toDate, fmtDate, fmtDateTime, yearWeek, uuid, download, copyText, store, preserve, readFileText, pickFile, uniq, splitList, escapeHtml };
})();
