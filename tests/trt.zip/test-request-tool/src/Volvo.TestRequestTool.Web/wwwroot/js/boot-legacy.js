    (function () {
      var h = TR.util.h;
      var dl = document.getElementById('datalists');
      dl.appendChild(h('datalist', { id: 'edb-specs' }, Object.keys(TR.db.edbSpecs).map(function (k) { return h('option', { value: k }); })));
      dl.appendChild(h('datalist', { id: 'kit-numbers' }, TR.server.state.kits.map(function (k) { return h('option', { value: String(k.partNumber) }, k.name + ' (' + k.state + ')'); })));
      TR.shellInit();
    })();
