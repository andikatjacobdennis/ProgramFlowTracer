/* Error screens: one illustrated road scene per HTTP status, so a failure explains itself at a glance and says what to do next.
 *
 *   400 flat tyre · 401 badge gate · 403 road closed · 404 road to nowhere · 405 wrong lane · 408 waiting at the lights
 *   409 two trucks, one bay · 410 empty bay · 413 weighbridge · 415 wrong cargo · 422 cargo check · 429 slow down
 *   500 engine smoke · 502 broken bridge · 503 workshop · 504 traffic jam · offline tunnel
 *
 * Used by error.html (served by the server for any page error) and, as TR.errors, inside the application. Self-contained:
 * no other script is needed. Animation follows the Motion setting (data-motion="reduced" stops it). English and Swedish. */
(function () {
  'use strict';

  // ------------------------------------------------------------------ text (English, Swedish)
  const TEXT = {
    400: { en: ['Flat tyre', 'The request could not be read.', 'Something in the request was not in the expected shape. Check what you entered and try again.'],
           sv: ['Punktering', 'Begäran kunde inte läsas.', 'Något i begäran hade inte rätt form. Kontrollera det du angav och försök igen.'] },
    401: { en: ['Badge, please', 'You need to sign in.', 'Your session has ended or you are not signed in yet. Sign in and you will be back on the road.'],
           sv: ['Passerkort, tack', 'Du behöver logga in.', 'Din session har gått ut eller så är du inte inloggad. Logga in så är du tillbaka på vägen.'] },
    403: { en: ['Road closed', 'You do not have access here.', 'Your role or vehicle contexts do not include this. Ask an administrator if you need it.'],
           sv: ['Vägen är avstängd', 'Du har inte behörighet här.', 'Din roll eller dina fordonskontexter omfattar inte detta. Fråga en administratör om du behöver det.'] },
    404: { en: ['Road to nowhere', 'This page does not exist.', 'The address may be mistyped, or the page has moved. Head home and search from there.'],
           sv: ['Vägen tar slut', 'Sidan finns inte.', 'Adressen kan vara felskriven eller så har sidan flyttats. Gå till startsidan och sök därifrån.'] },
    405: { en: ['Wrong lane', 'That action is not allowed here.', 'The address exists, but not for this kind of request. Use the application or the API description.'],
           sv: ['Fel körfält', 'Den åtgärden är inte tillåten här.', 'Adressen finns, men inte för den här typen av begäran. Använd programmet eller API-beskrivningen.'] },
    408: { en: ['Waiting at the lights', 'The request took too long to arrive.', 'The connection was slow or paused. Try again.'],
           sv: ['Väntar vid ljusen', 'Begäran tog för lång tid att komma fram.', 'Anslutningen var långsam eller pausad. Försök igen.'] },
    409: { en: ['Two trucks, one bay', 'Someone else changed this first.', 'Your copy is out of date. Reload to get the latest version, then make your change again.'],
           sv: ['Två lastbilar, en plats', 'Någon annan hann ändra först.', 'Din kopia är inaktuell. Ladda om för att få den senaste versionen och gör ändringen igen.'] },
    410: { en: ['Empty bay', 'This is no longer available.', 'It was removed on purpose and will not come back.'],
           sv: ['Tom plats', 'Det här finns inte längre.', 'Det togs bort med avsikt och kommer inte tillbaka.'] },
    413: { en: ['Over the weight limit', 'The upload is too large.', 'Files and requests can be up to 4 MB. Split the data or remove what you do not need.'],
           sv: ['Över viktgränsen', 'Uppladdningen är för stor.', 'Filer och begäranden får vara högst 4 MB. Dela upp datan eller ta bort det du inte behöver.'] },
    415: { en: ['Wrong cargo', 'That file type is not supported.', 'Use JSON, XML or CSV.'],
           sv: ['Fel last', 'Filtypen stöds inte.', 'Använd JSON, XML eller CSV.'] },
    422: { en: ['Cargo check failed', 'The data was read but does not make sense.', 'Some values do not fit together. Check the highlighted fields and try again.'],
           sv: ['Lastkontrollen misslyckades', 'Datan lästes men stämmer inte.', 'Några värden passar inte ihop. Kontrollera de markerade fälten och försök igen.'] },
    429: { en: ['Slow down', 'Too many requests in a short time.', 'Take a short break: the limit resets within a minute.'],
           sv: ['Sakta ner', 'För många begäranden på kort tid.', 'Ta en kort paus: gränsen återställs inom en minut.'] },
    500: { en: ['Engine trouble', 'Something went wrong on our side.', 'This is not your fault. Try again; if it keeps happening, tell us with the details below.'],
           sv: ['Motorproblem', 'Något gick fel hos oss.', 'Det är inte ditt fel. Försök igen; om det fortsätter, berätta för oss med detaljerna nedan.'] },
    502: { en: ['Bridge out', 'A connected system answered with nonsense.', 'A service the application depends on is having trouble. Try again in a moment.'],
           sv: ['Bron är trasig', 'Ett anslutet system svarade konstigt.', 'En tjänst som programmet är beroende av har problem. Försök igen om en stund.'] },
    503: { en: ['In the workshop', 'The service is briefly unavailable.', 'It is being maintained or restarted. It is usually back within a few minutes.'],
           sv: ['På verkstaden', 'Tjänsten är tillfälligt otillgänglig.', 'Den underhålls eller startas om. Den brukar vara tillbaka inom några minuter.'] },
    504: { en: ['Traffic jam', 'A connected system did not answer in time.', 'The road ahead is congested. Try again in a moment.'],
           sv: ['Trafikstockning', 'Ett anslutet system svarade inte i tid.', 'Vägen framåt är igenkorkad. Försök igen om en stund.'] },
    0: { en: ['In the tunnel', 'You are offline.', 'There is no network connection. Your work stays here; it continues when you are back online.'],
         sv: ['I tunneln', 'Du är offline.', 'Det finns ingen nätverksanslutning. Ditt arbete finns kvar och fortsätter när du är online igen.'] },
  };
  const UI = {
    en: { home: 'Go to Home', again: 'Try again', back: 'Go back', signin: 'Sign in', report: 'Report a problem', api: 'Open the API description', details: 'Details',
          code: 'Status', path: 'Address', at: 'Time', gallery: 'All error screens', error: 'Error', offline: 'Offline' },
    sv: { home: 'Till startsidan', again: 'Försök igen', back: 'Gå tillbaka', signin: 'Logga in', report: 'Rapportera ett problem', api: 'Öppna API-beskrivningen', details: 'Detaljer',
          code: 'Status', path: 'Adress', at: 'Tid', gallery: 'Alla felsidor', error: 'Fel', offline: 'Offline' },
  };
  const ACTIONS = { 400: ['back', 'home'], 401: ['signin', 'home'], 403: ['home', 'back'], 404: ['home', 'back'], 405: ['home', 'api'], 408: ['again', 'home'],
    409: ['again', 'home'], 410: ['home', 'back'], 413: ['back', 'home'], 415: ['back', 'home'], 422: ['back', 'home'], 429: ['again', 'home'],
    500: ['again', 'report'], 502: ['again', 'home'], 503: ['again', 'home'], 504: ['again', 'home'], 0: ['again'] };
  const CODES = Object.keys(TEXT).map(Number).filter(Boolean).concat([0]);

  function read(key, fallback) { try { const raw = localStorage.getItem(key); return raw == null ? fallback : JSON.parse(raw); } catch (e) { return fallback; } }
  /** The interface language: the App language setting, or the browser's language when it is Auto. */
  function lang() {
    const pick = read('trstudio.uiLanguage', 'auto');
    if (pick === 'sv' || pick === 'en') return pick;
    const c = read('trstudio.culture', null);
    const tag = (c && c.language) || (typeof navigator !== 'undefined' && navigator.language) || 'en';
    return /^sv/i.test(tag) ? 'sv' : 'en';
  }
  /** The nearest code with a scene: 418 → 400, 507 → 500. */
  const known = (code) => TEXT[code] ? code : code >= 500 ? 500 : code >= 400 ? 400 : 0;
  function info(code, language) {
    const k = known(Number(code) || 0), l = language || lang(), [title, line, help] = TEXT[k][l] || TEXT[k].en;
    return { code: Number(code) || 0, scene: k, title, line, help, actions: ACTIONS[k] || ['home'], ui: UI[l] || UI.en, lang: l };
  }

  // ------------------------------------------------------------------ drawing (SVG strings, theme colours via CSS classes)
  const W = 640, H = 300, ROAD = 228;
  const wheel = (x, y, r, flat) => flat
    ? `<ellipse class="ea-tyre" cx="${x}" cy="${y + r * .25}" rx="${r * 1.12}" ry="${r * .78}"/><circle class="ea-rim" cx="${x}" cy="${y + r * .25}" r="${r * .42}"/>`
    : `<g class="ea-wheel" style="transform-origin:${x}px ${y}px"><circle class="ea-tyre" cx="${x}" cy="${y}" r="${r}"/><circle class="ea-rim" cx="${x}" cy="${y}" r="${r * .5}"/><path class="ea-spoke" d="M${x - r * .5} ${y}h${r}M${x} ${y - r * .5}v${r}"/></g>`;
  /** A modern truck (cab-over, LED light strip, camera mirror, no brand marks), facing right, wheels on the road at y. */
  function truck(x, y, o) {
    o = o || {};
    const s = o.scale || 1, flip = o.left ? ` translate(${2 * x} 0) scale(-1 1)` : '';
    const trailer = o.trailer === false ? '' : `<rect class="ea-trailer" x="${x - 150}" y="${y - 84}" width="146" height="62" rx="5"/><path class="ea-trailer-line" d="M${x - 140} ${y - 60}h126M${x - 140} ${y - 46}h126"/>${o.cargo || ''}
      <rect class="ea-chassis" x="${x - 150}" y="${y - 24}" width="226" height="8" rx="2"/>${wheel(x - 128, y - 12, 12)}${wheel(x - 100, y - 12, 12)}`;
    // The class goes on an outer group: a CSS animation's transform would otherwise replace the scale and flip.
    return `<g class="ea-truck ${o.cls || ''}"><g transform="translate(${x} ${y}) scale(${s}) translate(${-x} ${-y})${flip}">
      ${trailer}
      <path class="ea-cab" d="M${x} ${y - 20}V${y - 86}q0-8 8-8h46q10 0 14 9l8 22v43z"/>
      <path class="ea-glass" d="M${x + 36} ${y - 86}h17q6 0 8 6l7 18h-32z"/>
      <rect class="ea-glass" x="${x + 8}" y="${y - 86}" width="22" height="22" rx="3"/>
      <path class="ea-led" d="M${x + 60} ${y - 38}h15"/><rect class="ea-grille" x="${x + 62}" y="${y - 34}" width="12" height="10" rx="2"/>
      <path class="ea-mirror" d="M${x + 70} ${y - 80}l9-5"/>
      <rect class="ea-chassis" x="${x}" y="${y - 24}" width="76" height="8" rx="2"/>
      ${wheel(x + 18, y - 12, 12, o.flat)}${wheel(x + 58, y - 12, 12)}
    </g></g>`;
  }
  const road = (end) => `<rect class="ea-ground" x="0" y="${ROAD}" width="${end || W}" height="${H - ROAD}"/><path class="ea-lane" d="M0 ${ROAD + 30}H${end || W}"/>`;
  const sky = () => `<circle class="ea-sun" cx="560" cy="62" r="26"/><g class="ea-cloud"><ellipse cx="120" cy="58" rx="34" ry="12"/><ellipse cx="142" cy="50" rx="22" ry="12"/></g><g class="ea-cloud ea-cloud-2"><ellipse cx="400" cy="40" rx="28" ry="10"/><ellipse cx="418" cy="34" rx="18" ry="10"/></g>`;
  const hills = () => `<path class="ea-hill" d="M0 ${ROAD}q120-70 240-30t220-10 180 10V${ROAD}z"/>`;
  const sign = (x, label, cls, post) => `<g class="ea-sign ${cls || ''}"><path class="ea-post" d="M${x} ${ROAD}V${ROAD - (post || 92)}"/><circle class="ea-sign-face" cx="${x}" cy="${ROAD - (post || 92) - 18}" r="22"/><text class="ea-sign-text" x="${x}" y="${ROAD - (post || 92) - 12}" text-anchor="middle">${label}</text></g>`;
  const cone = (x) => `<path class="ea-cone" d="M${x - 9} ${ROAD}l9-26 9 26z"/><path class="ea-cone-band" d="M${x - 5} ${ROAD - 11}h10"/>`;
  const smoke = (x, y) => [0, 1, 2].map((i) => `<circle class="ea-smoke" style="animation-delay:${i * .7}s" cx="${x + i * 6}" cy="${y - i * 4}" r="${9 + i * 4}"/>`).join('');
  const box = (x, y, w, h, cls) => `<rect class="ea-box ${cls || ''}" x="${x}" y="${y}" width="${w}" height="${h}" rx="2"/><path class="ea-box-tape" d="M${x + w / 2} ${y}v${h}"/>`;

  const SCENES = {
    400: () => sky() + hills() + road() + `<g class="ea-tilt">${truck(300, ROAD, { flat: true })}</g>` + `<g class="ea-pop"><path class="ea-spark" d="M318 236l-8 12M330 238l4 14M306 232l-14 4"/></g>` + cone(420),
    401: () => sky() + hills() + road() + truck(250, ROAD, { cls: 'ea-idle' }) +
      `<rect class="ea-booth" x="400" y="${ROAD - 70}" width="40" height="70" rx="4"/><rect class="ea-glass" x="406" y="${ROAD - 62}" width="28" height="20" rx="3"/>
       <rect class="ea-reader" x="384" y="${ROAD - 52}" width="12" height="18" rx="2"/><circle class="ea-reader-led" cx="390" cy="${ROAD - 40}" r="2.5"/>
       <g class="ea-barrier" style="transform-origin:400px ${ROAD - 44}px"><rect class="ea-boom" x="340" y="${ROAD - 48}" width="60" height="8" rx="3"/></g>`,
    403: () => sky() + hills() + road() + truck(210, ROAD, { cls: 'ea-idle' }) +
      `<g class="ea-roadblock"><rect class="ea-stripes" x="360" y="${ROAD - 52}" width="140" height="18" rx="3"/><path class="ea-post" d="M372 ${ROAD}V${ROAD - 34}M488 ${ROAD}V${ROAD - 34}"/></g>` + sign(540, '⛔', 'ea-sign-red') + cone(350) + cone(510),
    404: () => sky() + `<path class="ea-hill" d="M0 ${ROAD}q120-70 240-30t130 0V${ROAD}z"/>` + road(430) +
      `<path class="ea-cliff" d="M430 ${ROAD}l18 ${H - ROAD}H430z"/><g class="ea-dust"><circle cx="470" cy="270" r="3"/><circle cx="486" cy="282" r="2"/></g>` +
      truck(250, ROAD, { cls: 'ea-brake' }) + sign(400, '?', 'ea-sign-blue', 80) +
      `<text class="ea-far" x="560" y="200" text-anchor="middle">?</text>`,
    405: () => sky() + hills() + road() + `<path class="ea-arrow" d="M480 ${ROAD + 16}h-50l10-8m-10 8 10 8"/><path class="ea-arrow" d="M160 ${ROAD + 16}h-50l10-8m-10 8 10 8"/>` +
      truck(330, ROAD, { cls: 'ea-shake' }) + sign(560, '↩', 'ea-sign-blue'),
    408: () => sky() + hills() + road() + truck(260, ROAD, { cls: 'ea-idle' }) +
      `<g class="ea-lights"><path class="ea-post" d="M420 ${ROAD}V${ROAD - 70}"/><rect class="ea-light-box" x="408" y="${ROAD - 128}" width="24" height="60" rx="5"/>
       <circle class="ea-light ea-light-red" cx="420" cy="${ROAD - 114}" r="7"/><circle class="ea-light ea-light-off" cx="420" cy="${ROAD - 98}" r="7"/><circle class="ea-light ea-light-off" cx="420" cy="${ROAD - 82}" r="7"/></g>` +
      `<g class="ea-clock"><circle class="ea-clock-face" cx="540" cy="120" r="26"/><path class="ea-clock-hand ea-spin" style="transform-origin:540px 120px" d="M540 120V100"/><path class="ea-clock-hand" d="M540 120h12"/></g>`,
    409: () => sky() + hills() + road() + truck(170, ROAD, { trailer: false, cls: 'ea-bump-r' }) + truck(470, ROAD, { left: true, trailer: false, cls: 'ea-bump-l' }) +
      `<path class="ea-bay" d="M260 ${ROAD + 4}h120"/><text class="ea-bang" x="320" y="${ROAD - 112}" text-anchor="middle">!</text>`,
    410: () => sky() + hills() + road() + `<rect class="ea-bay-box" x="250" y="${ROAD - 6}" width="200" height="40" rx="3"/><g class="ea-dust ea-drift"><circle cx="300" cy="${ROAD - 12}" r="6"/><circle cx="330" cy="${ROAD - 20}" r="4"/><circle cx="356" cy="${ROAD - 10}" r="5"/></g>` + sign(520, '∅', 'ea-sign-blue'),
    413: () => sky() + hills() + road() +
      `<rect class="ea-scale" x="200" y="${ROAD - 6}" width="260" height="12" rx="3"/><g class="ea-meter"><rect class="ea-booth" x="490" y="${ROAD - 96}" width="70" height="56" rx="6"/>
       <path class="ea-gauge" d="M502 ${ROAD - 52}a23 23 0 0 1 46 0"/><path class="ea-needle ea-wobble" style="transform-origin:525px ${ROAD - 52}px" d="M525 ${ROAD - 52}l20-14"/><path class="ea-post" d="M525 ${ROAD}V${ROAD - 40}"/></g>` +
      `<g class="ea-squash">${truck(340, ROAD, { cargo: box(198, ROAD - 136, 40, 52) + box(242, ROAD - 150, 46, 66, 'ea-box-2') + box(292, ROAD - 128, 40, 44) })}</g>`,
    415: () => sky() + hills() + road() + truck(280, ROAD, { cls: 'ea-idle' }) +
      `<g class="ea-swing"><path class="ea-crane" d="M470 ${ROAD}V60h-120M470 80l-20-20"/><path class="ea-rope" d="M380 60v40"/><circle class="ea-odd" cx="380" cy="120" r="20"/></g>`,
    422: () => sky() + hills() + road() + truck(290, ROAD, { cargo: box(150, ROAD - 136, 40, 52) + box(196, ROAD - 136, 40, 52, 'ea-box-bad') + box(242, ROAD - 136, 40, 52) }) +
      `<g class="ea-clip"><rect class="ea-clipboard" x="470" y="${ROAD - 120}" width="56" height="74" rx="5"/><path class="ea-check" d="M482 ${ROAD - 98}l6 6 10-12M482 ${ROAD - 76}l14 12m0-12-14 12"/></g>`,
    429: () => sky() + hills() + road() + `<g class="ea-zoom">${truck(330, ROAD, { cls: 'ea-shake' })}</g><path class="ea-speed" d="M60 190h60M40 206h70M70 222h50"/>` + sign(560, '30', 'ea-sign-red'),
    500: () => sky() + hills() + road() + truck(300, ROAD, { trailer: true }) + `<g class="ea-smoke-group">${smoke(352, ROAD - 104)}</g>` +
      `<path class="ea-triangle" d="M470 ${ROAD}l18-34 18 34z"/><text class="ea-bang-sm" x="488" y="${ROAD - 6}" text-anchor="middle">!</text>`,
    502: () => sky() + `<rect class="ea-water" x="0" y="${ROAD + 10}" width="${W}" height="${H - ROAD}"/><path class="ea-wave" d="M260 ${ROAD + 34}q10-6 20 0t20 0 20 0 20 0"/>` +
      `<rect class="ea-ground" x="0" y="${ROAD}" width="260" height="14"/><rect class="ea-ground" x="390" y="${ROAD}" width="250" height="14"/>
       <path class="ea-bridge" d="M260 ${ROAD}l24 18M390 ${ROAD}l-30 20"/>` + truck(200, ROAD, { cls: 'ea-brake' }) + cone(250),
    503: () => sky() + hills() + road() +
      `<path class="ea-garage" d="M140 ${ROAD}V110l170-50 170 50V${ROAD}"/><rect class="ea-door" x="190" y="130" width="240" height="${ROAD - 130}" rx="3"/>` +
      truck(360, ROAD - 14, { trailer: false, cls: 'ea-lift' }) + `<rect class="ea-lift-bar" x="340" y="${ROAD - 14}" width="120" height="6" rx="2"/>` +
      `<g class="ea-spanner ea-wobble" style="transform-origin:520px 130px"><path class="ea-tool" d="M520 130l40 40"/><circle class="ea-tool-head" cx="516" cy="126" r="9"/></g>` + cone(110) + cone(520),
    504: () => sky() + hills() + road() + truck(150, ROAD, { scale: .8, cls: 'ea-creep' }) + truck(360, ROAD, { scale: .8, cls: 'ea-creep ea-creep-2' }) + truck(580, ROAD, { scale: .8, trailer: true, cls: 'ea-creep ea-creep-3' }) +
      `<g class="ea-clock"><circle class="ea-clock-face" cx="320" cy="76" r="22"/><path class="ea-clock-hand ea-spin" style="transform-origin:320px 76px" d="M320 76V60"/></g>`,
    0: () => `<rect class="ea-tunnel-wall" x="0" y="0" width="${W}" height="${H}"/><path class="ea-tunnel" d="M120 ${ROAD}V140a200 120 0 0 1 400 0V${ROAD}z"/>` + road() +
      `<g class="ea-lamps">${[180, 260, 340, 420].map((x, i) => `<circle class="ea-lamp" style="animation-delay:${i * .25}s" cx="${x}" cy="62" r="5"/>`).join('')}</g>` +
      truck(380, ROAD, { cls: 'ea-idle' }) + `<g class="ea-signal"><path d="M560 120a26 26 0 0 1 36 0M566 130a16 16 0 0 1 24 0"/><circle cx="578" cy="140" r="4"/><path class="ea-cross" d="M556 104l44 44"/></g>`,
  };
  /** The scene for a status code as an SVG string. */
  function scene(code) {
    const k = known(Number(code) || 0), i = info(code);
    return `<svg class="ea-scene ea-scene-${k}" viewBox="0 0 ${W} ${H}" role="img" aria-label="${i.title}">${SCENES[k]()}</svg>`;
  }

  // ------------------------------------------------------------------ the full page (error.html)
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  function actionHref(a) {
    return { home: '/', signin: '/', report: '/?view=feedback', api: '/swagger', again: location.href, back: 'javascript:history.back()' }[a];
  }
  function card(code, compact) {
    const i = info(code);
    const btn = (a, n) => a === 'back'
      ? `<button type="button" class="ea-btn ${n ? '' : 'primary'}" data-act="back">${esc(i.ui[a])}</button>`
      : a === 'again' ? `<button type="button" class="ea-btn ${n ? '' : 'primary'}" data-act="again">${esc(i.ui[a])}</button>`
      : `<a class="ea-btn ${n ? '' : 'primary'}" href="${actionHref(a)}">${esc(i.ui[a])}</a>`;
    return `<article class="ea-card${compact ? ' is-compact' : ''}">
      <div class="ea-art">${scene(code)}</div>
      <div class="ea-copy">
        <p class="ea-code">${i.code ? esc(i.ui.error) + ' ' + i.code : esc(i.ui.offline)}</p>
        <h1 class="ea-title">${esc(i.title)}</h1>
        <p class="ea-line">${esc(i.line)}</p>
        ${compact ? '' : `<p class="ea-help">${esc(i.help)}</p><div class="ea-actions">${i.actions.map(btn).join('')}${i.actions.includes('report') ? '' : `<a class="ea-btn ghost" href="/?view=feedback">${esc(i.ui.report)}</a>`}</div>`}
      </div></article>`;
  }
  function page() {
    const root = document.documentElement, q = new URLSearchParams(location.search);
    const main = document.getElementById('ea-main');
    if (!main) return;
    const l = lang(); root.lang = l;
    if (q.has('all')) {
      const ui = UI[l];
      document.title = ui.gallery + ' · Test Request Tool';
      main.innerHTML = `<h1 class="ea-gallery-title">${esc(ui.gallery)}</h1><div class="ea-gallery">${CODES.map((c) => `<a class="ea-tile" href="/error.html?code=${c}">${card(c, true)}</a>`).join('')}</div>`;
      return;
    }
    const code = Number(q.get('code') || root.dataset.code || 404);
    const i = info(code);
    document.title = (i.code ? i.code + ' · ' : '') + i.title + ' · Test Request Tool';
    const ui = i.ui, now = new Date();
    main.innerHTML = card(code) + `<details class="ea-details"><summary>${esc(ui.details)}</summary><dl>
      <dt>${esc(ui.code)}</dt><dd>${i.code || '—'}</dd><dt>${esc(ui.path)}</dt><dd>${esc(location.pathname)}</dd>
      <dt>${esc(ui.at)}</dt><dd><time datetime="${now.toISOString()}">${esc(now.toLocaleString(l === 'sv' ? 'sv-SE' : undefined))}</time> (${esc(Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC')})</dd></dl>
      <p><a href="/error.html?all">${esc(ui.gallery)}</a> · <a href="/swagger">${esc(ui.api)}</a></p></details>`;
    main.addEventListener('click', (e) => {
      const b = e.target.closest('[data-act]');
      if (!b) return;
      if (b.dataset.act === 'back') { if (history.length > 1) history.back(); else location.href = '/'; }
      if (b.dataset.act === 'again') location.reload();
    });
    // The truck reacts when the scene is clicked: a small hop.
    const art = main.querySelector('.ea-art');
    if (art) art.addEventListener('click', () => { art.classList.remove('is-hop'); void art.offsetWidth; art.classList.add('is-hop'); });
    if (code === 0) window.addEventListener('online', () => location.reload());
  }

  // ------------------------------------------------------------------ in the application
  /** An inline error panel (a DOM element) for a failed load, with the same scene and words as the full page. */
  function panel(code, detail) {
    const el = document.createElement('section');
    el.className = 'ea-inline';
    el.innerHTML = card(code);
    if (detail) { const p = document.createElement('p'); p.className = 'ea-help'; p.textContent = detail; el.querySelector('.ea-copy').insertBefore(p, el.querySelector('.ea-actions')); }
    el.addEventListener('click', (e) => { const b = e.target.closest('[data-act]'); if (!b) return; if (b.dataset.act === 'back') history.back(); else location.reload(); });
    return el;
  }
  /** "You are offline": a small glass pill with the tunnel scene while the network is gone. */
  function watchOffline() {
    let pill = null;
    const show = () => {
      if (pill) return;
      const i = info(0);
      pill = document.createElement('div');
      pill.className = 'ea-offline'; pill.setAttribute('role', 'status');
      pill.innerHTML = scene(0) + `<span><strong>${esc(i.line)}</strong> ${esc(i.help.split('. ').slice(1).join('. '))}</span>`;
      document.body.appendChild(pill);
    };
    const hide = () => { if (pill) { pill.remove(); pill = null; if (window.TR && TR.notify && TR.notify.toast) TR.notify.toast(lang() === 'sv' ? 'Du är online igen.' : 'You are back online.', 'success'); } };
    window.addEventListener('offline', show);
    window.addEventListener('online', hide);
    if (navigator.onLine === false) show();
  }

  const api = { CODES, info, scene, card, panel, lang, TEXT };
  if (typeof window !== 'undefined') {
    window.TRErrors = api;
    if (document.getElementById('ea-main')) page();
    else if (window.TR) { window.TR.errors = Object.assign(window.TR.errors || {}, api); watchOffline(); }
  }
})();
