/* In-browser mock backend. Mirrors the MVC endpoints used by the Test Request pages
   (TestRequest2000/*, VdaProduct/*, Edb/*, XmlFile/*, RequestLog/*, AftermarketRequest/*, SoftwareBreakdown/*, ...).
   Every call goes through TR.api(name, params) and returns the ObjectResult envelope {success, item, errors, warnings, infos}. */
(function () {
  'use strict';
  const TR = window.TR;
  const E = TR.enums;
  const M = TR.model;
  const X = TR.xml;
  const { clone, store, uuid, splitList, uniq } = TR.util;
  const D = () => TR.db;
  const KEY = 'trsim.state.v1';

  const DEFAULT_SETTINGS = {
    userId: 'TESTUSER', latency: 300, t3ContextMigrated: true,
    perms: { updateVda: true, save: true, toKit: true, configuratorTeam: false },
    readContexts: [101, 102, 103, 104], writeContexts: [101, 102, 104],
  };

  const state = { vda: {}, kits: [], swc: {}, log: [], seedLog: null, sessionData: {}, productUpdates: [], settings: clone(DEFAULT_SETTINGS) };

  function load() {
    D().vdaSeed.forEach((p) => { state.vda[TR.chassis.chassisKey(M.chassisOf(p))] = clone(p); });
    state.kits = clone(D().kitsSeed);
    const saved = store.get(KEY, null);
    if (saved) {
      Object.assign(state.vda, saved.vda || {});
      if (saved.kits) state.kits = saved.kits;
      state.swc = saved.swc || {};
      state.log = saved.log || [];
      state.sessionData = saved.sessionData || {};
      state.productUpdates = saved.productUpdates || [];
      state.settings = Object.assign(clone(DEFAULT_SETTINGS), saved.settings || {});
      state.settings.perms = Object.assign(clone(DEFAULT_SETTINGS.perms), (saved.settings || {}).perms || {});
      if (!saved.settings?.t3ContextMigrated) {
        // Grant the new T3 context once; later user permission changes are retained.
        for (const key of ['readContexts', 'writeContexts']) {
          state.settings[key] = Array.from(new Set([...(state.settings[key] || []), 104]));
        }
        state.settings.t3ContextMigrated = true;
        persist();
      }
    }
  }

  function persist() {
    const seedKeys = new Set(D().vdaSeed.map((p) => TR.chassis.chassisKey(M.chassisOf(p))));
    const changedVda = {};
    Object.keys(state.vda).forEach((k) => {
      const seed = D().vdaSeed.find((p) => TR.chassis.chassisKey(M.chassisOf(p)) === k);
      if (!seedKeys.has(k) || !TR.util.deepEqual(seed, state.vda[k])) changedVda[k] = state.vda[k];
    });
    const sd = {};
    Object.keys(state.sessionData).slice(-30).forEach((k) => { sd[k] = state.sessionData[k]; });
    state.sessionData = sd;
    const ok = store.set(KEY, { vda: changedVda, kits: state.kits, swc: state.swc, log: state.log.slice(-60), sessionData: sd, productUpdates: state.productUpdates.slice(-30), settings: state.settings });
    if (!ok) store.set(KEY, { vda: changedVda, kits: state.kits, swc: state.swc, log: state.log.slice(-10), sessionData: {}, productUpdates: [], settings: state.settings });
  }
  function reset() { store.remove(KEY); state.vda = {}; state.swc = {}; state.log = []; state.seedLog = null; state.sessionData = {}; state.productUpdates = []; state.settings = clone(DEFAULT_SETTINGS); load(); }

  // ---------- permissions & parameter encryption ----------
  const ctxById = (id) => D().contexts.find((c) => c.id === id);
  function ensureRead(p) {
    const info = p.productSpecification.productInformation;
    if (info.context) {
      if (!state.settings.readContexts.includes(Number(info.context.id))) throw new Error(`Access denied. You don't have read permission in context '${info.context.name}'.`);
      return;
    }
    const pc = info.productClassId;
    if (!pc) {
      if (p.productSpecification.variants.length || p.productSpecification.sNotes.length || p.parameters.length) throw new Error('Access to product has been denied because product class code could not be found');
      return;
    }
    const ctxs = D().contexts.filter((c) => c.productClassIds.includes(pc));
    if (!ctxs.length) return;
    if (!ctxs.some((c) => state.settings.readContexts.includes(c.id))) throw new Error(`Access to product as been denied because you don't have permission to access to resources in product class ${pc}`);
  }
  const canWriteVda = (ctxId) => state.settings.perms.updateVda && state.settings.writeContexts.includes(Number(ctxId));
  function privileged(p) {
    const ctx = p && p.productSpecification && p.productSpecification.productInformation.context;
    return state.settings.perms.configuratorTeam || (ctx && canWriteVda(ctx.id));
  }
  function isHiddenParam(x) {
    if ((x.electricalArchitecture || 0) === 0) return D().TEA2_ENCRYPTED.includes(x.code);
    const pd = D().paramDef(1, x.code);
    return !!(pd && pd.hidden);
  }
  const b64e = (s) => btoa(unescape(encodeURIComponent(String(s))));
  const b64d = (s) => decodeURIComponent(escape(atob(s)));
  function encryptParam(x) {
    if (!isHiddenParam(x)) return x;
    x.references = (x.references || []).map((r) => ({ code: r.code, value: r.value === null || r.value === undefined || String(r.value).startsWith('ENC:') ? r.value : 'ENC:' + b64e(r.value) }));
    x.valueNotVisibleToUser = true;
    return x;
  }
  function decryptParam(x) {
    let had = false;
    x.references = (x.references || []).map((r) => {
      if (typeof r.value === 'string' && r.value.startsWith('ENC:')) { had = true; try { return { code: r.code, value: b64d(r.value.slice(4)) }; } catch (e) { return r; } }
      return r;
    });
    if (had) x.valueNotVisibleToUser = false;
    return x;
  }
  function encryptProduct(p, ref) {
    if (!p || privileged(ref || p)) return p;
    (p.parameters || []).forEach(encryptParam);
    return p;
  }
  function decryptProduct(p) { if (p) (p.parameters || []).forEach(decryptParam); return p; }
  function encryptDelta(d, ref) {
    if (!d || privileged(ref)) return d;
    (d.parameters || []).forEach((o) => { if (o.value) encryptParam(o.value); });
    (d.nodes || []).forEach(() => {});
    return d;
  }
  function decryptDelta(d) { if (d) (d.parameters || []).forEach((o) => { if (o.value) decryptParam(o.value); }); return d; }
  /** Prepare a product for the client: inflate, check read access, encrypt hidden parameters. */
  function out(p) { M.inflate(p); ensureRead(p); return encryptProduct(p); }

  // ---------- lookups ----------
  function findVda(chassis) {
    const k = Object.keys(state.vda).find((x) => TR.chassis.sameChassis(M.chassisOf(state.vda[x]), chassis));
    return k ? state.vda[k] : null;
  }
  function edbProduct(specId) {
    const key = Object.keys(D().edbSpecs).find((k) => k.toUpperCase() === String(specId || '').trim().toUpperCase());
    if (!key) throw new Error(`Specification '${specId}' was not found in EDB`);
    const s = D().edbSpecs[key];
    const f = D().factories.find((x) => x.code === s.factory) || D().factories[0];
    const p = M.ensureShape({
      productSpecification: {
        productInformation: { chassisSeries: '', chassisNumber: '', vin: '', productClassId: s.productClassId, modelId: s.modelId, chassisType: 'Normal', specificationDate: s.specDate, introductionWeek: TR.util.yearWeek(s.specDate), assemblyFactory: f.name, assemblyFactoryCode: f.code, releaseFactory: f.name, companyCode: 'VTC', countryOfOperation: '', testStatus: '', notifications: [{ text: `Loaded from EDB specification ${key}`, reason: '', action: '', severity: 2, linkLookup: {} }] },
        variants: s.variants.map((v) => D().variantBySymbol(v)).filter(Boolean),
        sNotes: s.snotes.map((v) => ({ value: v, name: D().sNoteName(v), source: null })),
      },
    });
    return M.inflate(p);
  }
  const baselineUrl = (guid) => `#/BaselineEdit?guid=${guid}`;
  const servicePackUrl = (guid) => `#/ServicePackEdit?guid=${guid}`;

  // ---------- request log ----------
  function header(type) {
    return { messageType: E.RequestTypeKeys[type] + 'Request', messageTypeVersion: '1.1', senderId: 'SWC', userId: state.settings.userId, createdAt: new Date().toISOString() };
  }
  function createLogEntry(type, payload, result, opts) {
    opts = opts || {};
    const products = payload.products || (payload.product ? [payload.product] : []);
    const first = products[0] ? M.chassisOf(products[0]) : { chassisSeries: '', chassisNumber: '' };
    const now = opts.at || new Date();
    const e = {
      id: opts.id || uuid(), transactionId: uuid(), incomingMessageId: 'IN-' + uuid().slice(0, 13).toUpperCase(), outgoingMessageId: 'OUT-' + uuid().slice(0, 13).toUpperCase(),
      senderId: opts.senderId || 'SWC', sender: opts.senderId === 'NAMS' ? 'NAMS dealer tool' : opts.senderId === 'GeSP' ? 'GeSP portal' : opts.senderId === 'PROTOM' ? 'PROTOM' : 'SW Configurator Test Request',
      userId: opts.userId || state.settings.userId, receivedAt: new Date(now).toISOString(), processedAt: new Date(new Date(now).getTime() + 850).toISOString(),
      requestType: type, operationType: type === 0 ? E.SoftwareRequestOperationKeys[payload.softwareRequestOperation] : type === 7 ? (payload.actionCriteriaTypes || []).map(E.actionCriteriaString).join(',') : '',
      scenario: type === 0 || type === 7 ? E.ScenarioNames[payload.scenario] || '' : type === 2 ? E.KitScenarioKeys[payload.scenario] || '' : '',
      kitPartNumbers: (payload.conversionKitNumbers || []).map((k) => k.conversionKitNumber).filter(Boolean).join(', '),
      multiNodeBehaviour: !!payload.enableMultiNodeBehavior,
      requestedNodes: (payload.requestedNodes || []).map((r) => M.derivedName(r.nodeIdentifier)).join(', '),
      chassisSeries: first.chassisSeries, chassisNumber: first.chassisNumber,
      productClass: products[0] ? products[0].productSpecification.productInformation.productClassId : '',
      baselineGuid: payload.baselineGuid || (result && result.baselineGuid) || '',
      isTestRequest: opts.isTestRequest !== false, schemaName: X.REQUEST_ROOTS[type], schemaVersion: '1.1.0', version: 1,
      payload: clone(payload), result: clone(result),
    };
    return e;
  }
  function ensureSeedLog() {
    if (state.seedLog) return state.seedLog;
    const prods = D().vdaSeed;
    const senders = ['NAMS', 'GeSP', 'PROTOM', 'NAMS'];
    const types = [0, 0, 2, 0, 7, 4, 0, 2, 5, 0, 6, 0, 0, 2, 0, 7, 0, 4];
    const list = [];
    const now = Date.now();
    for (let i = 0; i < 26; i++) {
      const p = clone(prods[i % prods.length]);
      M.inflate(p);
      const type = types[i % types.length];
      const ctx = p.productSpecification.productInformation.context;
      let payload, result;
      try {
        if (type === 0) {
          payload = { products: [p], requestedNodes: i % 3 === 0 && p.nodes[1] ? [{ nodeIdentifier: p.nodes[1].nodeIdentifier, previousEcuHardware: null, chassisSeries: M.chassisOf(p).chassisSeries, chassisNumber: M.chassisOf(p).chassisNumber }] : [], scenario: [1, 3, 4][i % 3], softwareRequestOperation: [3, 1, 3, 2][i % 4], remoteRequest: 0, allowLimitedValidation: false, enableMultiNodeBehavior: i % 2 === 0, pblUpdateCapable: true, selectedLanguageCode: 'en-GB', simulationKitName: '' };
          result = { items: TR.engine.softwareRequest(payload) };
        } else if (type === 2) {
          payload = { products: [p], conversionKitNumbers: [{ conversionKitNumber: String([23187002, 23187003, 23187001][i % 3]), chassisSeries: M.chassisOf(p).chassisSeries, chassisNumber: M.chassisOf(p).chassisNumber }], scenario: 1, remoteRequest: 0, onlyServiceKitAllowed: false, pblUpdateCapable: true, selectedLanguageCode: 'en-GB', simulationKitName: '' };
          result = { items: TR.engine.kitRequest(payload) };
        } else if (type === 4) {
          const bl = D().baselines.find((b) => ctx && b.contextId === ctx.id) || D().baselines[0];
          payload = { baselineGuid: bl.guid, product: p, requestedNodes: [], removedNodes: [], spareCabNodes: [], softwareRelatedHardwares: [] };
          result = { items: TR.engine.spareCabRequest(payload), baselineGuid: bl.guid };
        } else if (type === 7) {
          payload = { products: [p], actionCriteriaTypes: [1, 2, 10, 13], requestedNodes: [], enableMultiNodeBehavior: true, scenario: 1, pblUpdateCapable: true, selectedLanguageCode: 'en-GB' };
          result = { items: [], availableUpdateItem: TR.engine.availableUpdates(payload) };
        } else if (type === 5) {
          payload = { product: p, assemblyFactoryCode: p.productSpecification.productInformation.assemblyFactoryCode, introductionWeek: '202610', includePreReleasedSNotes: false };
          result = { breakdown: TR.engine.productionBreakdown(payload) };
        } else {
          const bl = D().baselines.find((b) => ctx && b.contextId === ctx.id) || D().baselines[0];
          payload = { product: p, baselineIdentifier: bl.identifier, baselineVersion: bl.version };
          result = { breakdown: TR.engine.developmentBreakdown(payload), baselineGuid: bl.guid };
        }
      } catch (e) { continue; }
      const userId = i % 5 === 0 ? state.settings.userId : D().users[i % D().users.length];
      list.push(createLogEntry(type, payload, result, { id: D().guid(), at: now - (i * 7 + 1) * 3600 * 1000, senderId: senders[i % senders.length], userId, isTestRequest: i % 5 === 0 }));
    }
    state.seedLog = list;
    return list;
  }
  const allLog = () => ensureSeedLog().concat(state.log).sort((a, b) => (a.receivedAt < b.receivedAt ? 1 : -1));

  function requestResponse(e) {
    const type = e.requestType;
    const reqProducts = (e.payload.products || (e.payload.product ? [e.payload.product] : [])).map((p) => out(clone(p)));
    const rr = { requestedProducts: reqProducts, request: e.payload.requestModel || defaultRequestModelFor(e), requestXml: X.requestToXml(type, stripModel(e.payload), e.payload.requestModel || defaultRequestModelFor(e), headerFor(e)), products: reqProducts, responses: null, responseXml: null, availableUpdateResponses: null, logEntry: listItem(e) };
    if (e.result.items && e.result.items.length) {
      rr.responses = e.result.items.map((r) => Object.assign(clone(r), { delta: encryptDelta(clone(r.delta), reqProducts[0]) }));
      rr.responseXml = X.responseToXml(responseRoot(type), e.result.items, headerFor(e));
    }
    if (e.result.availableUpdateItem) {
      rr.availableUpdateResponses = [e.result.availableUpdateItem];
      rr.responseXml = X.responseToXml('AvailableUpdatesResponse', [{ dataArea: e.result.availableUpdateItem.dataArea }], headerFor(e));
    }
    if (e.result.breakdown) {
      rr.products = [out(clone(e.result.breakdown.product))];
      rr.responseXml = X.productToXml(e.result.breakdown.product);
      rr.breakdown = true;
    }
    return rr;
  }
  const stripModel = (payload) => { const p = clone(payload); delete p.requestModel; return p; };
  const headerFor = (e) => ({ messageType: E.RequestTypeKeys[e.requestType] + 'Request', senderId: e.senderId, userId: e.userId, transactionId: e.transactionId, messageId: e.incomingMessageId, createdAt: e.receivedAt });
  const responseRoot = (type) => ({ 0: 'SoftwareResponse', 2: 'KitResponse', 4: 'SpareCabResponse', 7: 'AvailableUpdatesResponse' }[type] || 'Response');
  function defaultRequestModelFor(e) {
    const p = e.payload;
    return {
      selectedRequestType: e.requestType, selectedSoftwareRequestOperation: p.softwareRequestOperation || 3, selectedScenario: e.requestType === 2 ? 1 : p.scenario || 1, selectedKitScenario: e.requestType === 2 ? p.scenario || 1 : 1,
      selectedRemote: p.remoteRequest || 0, allowLimitedValidation: !!p.allowLimitedValidation, enableMultiNodeBehavior: p.enableMultiNodeBehavior !== false, onlyServiceKitAllowed: !!p.onlyServiceKitAllowed,
      pblUpdateCapable: p.pblUpdateCapable !== false, selectedLanguageCode: p.selectedLanguageCode || 'en-GB', simulationKitName: p.simulationKitName || '', conversionKitNumbers: p.conversionKitNumbers || [],
      selectedBaseline: p.baselineGuid || null, baselineIdentifier: p.baselineIdentifier || '', baselineVersion: p.baselineVersion || '', selectedFactory: p.assemblyFactoryCode || '', introductionWeek: p.introductionWeek || '',
      selectedActionCriteriaTypes: p.actionCriteriaTypes || [], limitTo: p.limitTo || '', groupAdministrativeParameters: p.groupAdministrativeParameters !== false, requestedNodes: p.requestedNodes || [],
    };
  }
  function listItem(e) {
    const r = {};
    ['id', 'transactionId', 'incomingMessageId', 'outgoingMessageId', 'senderId', 'sender', 'userId', 'receivedAt', 'processedAt', 'requestType', 'operationType', 'scenario', 'kitPartNumbers', 'multiNodeBehaviour', 'requestedNodes', 'chassisSeries', 'chassisNumber', 'productClass', 'baselineGuid', 'isTestRequest'].forEach((k) => { r[k] = e[k]; });
    return r;
  }
  function findLog(pred, what) {
    const e = allLog().find(pred);
    if (!e) throw new Error(`No log entry found for ${what}`);
    return requestResponse(e);
  }

  function logRequest(type, payload, result) {
    const e = createLogEntry(type, payload, result, {});
    state.log.push(e);
    persist();
    return e;
  }

  // ---------- validation helpers ----------
  function validateParameter(p) {
    const ea = p.electricalArchitecture || 0;
    const pd = D().paramDef(ea, p.code);
    const msgs = [];
    const refs = p.references || [];
    if (ea === 0 || !pd) {
      const empty = refs.filter((r) => r.value === null || r.value === undefined || String(r.value).trim() === '');
      if (empty.length) msgs.push(`Parameter Value can not be empty. Empty reference(s): ${empty.map((r) => r.code).join(', ')}`);
    }
    if (pd && !pd.isFunction) {
      refs.forEach((r) => {
        const v = r.value === null || r.value === undefined ? '' : String(r.value).trim();
        if (String(v).startsWith('ENC:')) return;
        if (v === '') { if (ea === 1) msgs.push(`${p.code}.${r.code}: a value is required`); return; }
        if (pd.kind === 'int') {
          if (!/^-?\d+$/.test(v)) msgs.push(`${p.code}.${r.code}: '${v}' is not an integer`);
          else if ((pd.min !== undefined && Number(v) < pd.min) || (pd.max !== undefined && Number(v) > pd.max)) msgs.push(`${p.code}.${r.code}: value ${v} is out of range [${pd.min}..${pd.max}]`);
        } else if (pd.kind === 'bool' && !['0', '1'].includes(v)) msgs.push(`${p.code}.${r.code}: value must be 0 or 1`);
        else if (pd.kind === 'enum' && !pd.values.includes(v)) msgs.push(`${p.code}.${r.code}: '${v}' is not one of ${pd.values.join(', ')}`);
      });
      if (pd.code === 'P1VML' && refs.length === 2 && Number(refs[0].value) > Number(refs[1].value)) msgs.push('P1VML: LOW must be less than or equal to HIGH');
    }
    return msgs;
  }

  // ---------- endpoint handlers ----------
  class Result { constructor(item, extra) { this.item = item; Object.assign(this, extra || {}); } }
  const ok = (item, extra) => new Result(item, extra);
  const parse = (j) => (typeof j === 'string' ? JSON.parse(j) : j);

  const H = {};
  // product sources
  H['VdaProduct/LoadFromVda'] = ({ chassis }) => {
    const p = findVda(chassis || {});
    if (!p) throw new Error(`Could not find product ${(chassis || {}).chassisSeries || ''} ${(chassis || {}).chassisNumber || ''} in VDA`);
    return out(clone(p));
  };
  H['VdaProduct/LoadFromVdaByVin'] = ({ vin }) => {
    const v = String(vin || '').trim().toUpperCase();
    const k = Object.keys(state.vda).find((x) => (state.vda[x].productSpecification.productInformation.vin || '').toUpperCase() === v);
    if (!k) throw new Error(`Could not find VIN ${v} in VDA`);
    return out(clone(state.vda[k]));
  };
  H['Edb/Load'] = ({ specificationId }) => { const p = edbProduct(specificationId); ensureRead(p); return encryptProduct(p); };
  H['XmlFile/Load'] = ({ xml }) => {
    const r = X.loadXmlFile(xml);
    r.products = r.products.map((p) => out(M.ensureShape(decryptProduct(p))));
    return r;
  };

  // TestRequest2000 controller
  const T = 'TestRequest2000/';
  H[T + 'ParseChassis'] = ({ input }) => TR.chassis.parse(input);
  H[T + 'GetDelta'] = ({ sourceJson, targetJson, forceIncludeBootloaders }) => {
    const s = decryptProduct(parse(sourceJson)), t = decryptProduct(parse(targetJson));
    const d = M.computeDelta(s, t);
    if (forceIncludeBootloaders) {
      d.nodes.forEach((op) => {
        if (op.type !== E.Op.AssignTea2PlusNode) return;
        const sn = s.nodes.find((n) => M.idMatch(n.nodeIdentifier, op.nodeIdentifier));
        ['primaryBootloader', 'secondaryBootloader'].forEach((k) => {
          if (!op[k] && sn && sn[k]) op[k] = { type: E.Op.ReplaceDownloadablePart, value: Object.assign(clone(sn[k]), { forceDirty: true, name: `${k === 'primaryBootloader' ? 'PBL' : 'SBL'} ${sn.versionName || ''}`.trim() }) };
        });
      });
    }
    return encryptDelta(d, s);
  };
  H[T + 'CompareProducts'] = ({ leftJson, rightJson }) => TR.engine.diffTree(parse(leftJson), parse(rightJson));
  H[T + 'SendToVda'] = ({ jsonVdaDelta }) => {
    const d = parse(jsonVdaDelta);
    const ctx = d.productInformation && d.productInformation.context;
    if (!ctx || !canWriteVda(ctx.id)) throw new Error('No permission to update VDA.');
    const p = findVda(d.productInformation);
    if (!p) throw new Error('The product does not exist in VDA');
    decryptDelta(d.assignProduct);
    M.applyDelta(p, d.assignProduct);
    TR.engine.normalizeFamilies(p, ((d.assignProduct.productSpecification || {}).variants || []).filter((o) => o.type === E.Op.AssignVariant).map((o) => o.value));
    persist();
    return ok(true, { infos: ['VDA was successfully updated.'] });
  };
  H[T + 'GetMatchingServicePackNameAndUrl'] = ({ documentNumbers, contextId }) => {
    const sps = M.matchServicePacks(documentNumbers, contextId);
    return { name: sps.map((s) => s.name).join(', '), url: sps.length === 1 ? servicePackUrl(sps[0].guid) : '', guid: sps.length === 1 ? sps[0].guid : '' };
  };
  H[T + 'GetMatchingBaselineNameAndUrl'] = ({ documentNumbers }) => {
    const b = M.matchBaseline(documentNumbers);
    return b ? { name: b.name, guid: b.guid, url: baselineUrl(b.guid) } : { name: '', guid: '', url: '' };
  };
  H[T + 'GetBaselineNameAndUrlByGuid'] = ({ guid }) => {
    const b = D().baselines.find((x) => x.guid === guid);
    return b ? { name: b.name, guid: b.guid, url: baselineUrl(b.guid) } : { name: '', guid: '', url: '' };
  };
  H[T + 'Compare'] = ({ left, right }) => {
    const r = TR.engine.compareBreakdown(left, right);
    [r.sourceProduct, r.targetProduct].forEach((p) => { if (p) { ensureRead(p); encryptProduct(p); } });
    return r;
  };
  H[T + 'GetProductXml'] = ({ productJson }) => X.productToXml(parse(productJson));
  H[T + 'GetProductReportXml'] = ({ productJson }) => X.productToReportXml(parse(productJson));
  H[T + 'GetVariantsInFamily'] = ({ variant, productClass }) => {
    const fam = D().families.find((f) => f.familyId === variant.familyId);
    let vs = D().variants.filter((v) => v.familyId === variant.familyId && (!productClass || v.authorizedProductClasses.includes(productClass)));
    if (!vs.some((v) => v.idVar6 === variant.idVar6)) vs.push(variant);
    vs = clone(vs).sort((a, b) => (a.symbol < b.symbol ? -1 : 1));
    return { familyDescription: fam ? fam.description : 'Unknown Variant Family', familyType: fam ? fam.familyType : 'S', variants: vs };
  };
  H[T + 'GetVariants'] = ({ symbols, productClass }) => {
    if (!symbols || !String(symbols).trim()) throw new Error('Symbol can not be empty');
    if (!productClass) throw new Error('product class code can not be empty');
    const list = uniq(String(symbols).split(/[,/]/).map((s) => s.trim().toUpperCase()).filter(Boolean));
    if (!list.length) throw new Error('No Symbols in expression');
    const found = [], bad = [];
    list.forEach((s) => { const v = D().variants.find((x) => x.symbol === s && x.authorizedProductClasses.includes(productClass)); if (v) found.push(clone(v)); else bad.push(s); });
    const msg = `The following variant(s) don't exist or are invalid for the product class and have been ignored: ${bad.join(', ')}`;
    if (!found.length) throw new Error(msg);
    return ok(found, { warnings: bad.length ? [msg] : [] });
  };
  H[T + 'GetSNotes'] = ({ sNotes }) => {
    const list = (sNotes || []).map((s) => String(s).trim().toUpperCase()).filter(Boolean);
    if (!list.length) throw new Error('SNotes can not be empty');
    const bad = list.filter((s) => !/^S\d{1,7}$/.test(s));
    const good = list.filter((s) => /^S\d{1,7}$/.test(s));
    const msg = `The following sNote(s) are not correctly formed: ${bad.join(', ')}. S-Note could be up to 8 chars. Must start with a 'S' and the rest should be numeric.`;
    if (!good.length) throw new Error(msg);
    return ok(uniq(good).map((v) => ({ value: v, name: D().sNoteName(v), source: null })), { warnings: bad.length ? [msg] : [] });
  };
  H[T + 'IsParameterDefined'] = ({ electricalArchitecture, code, contextId }) => {
    const c = String(code || '').trim().toUpperCase();
    if (!c) throw new Error('Please enter parameter code');
    if (!D().paramDef(electricalArchitecture, c)) throw new Error(`Parameter ${c} is not defined for ${E.ParamEANames[electricalArchitecture]} in context ${contextId || '(none)'}`);
    return true;
  };
  H[T + 'ValidateParameterValue'] = ({ parameterJson }) => {
    const msgs = validateParameter(parse(parameterJson));
    if (msgs.length) throw new Error(msgs.join('\n'));
    return true;
  };
  H[T + 'UploadAndGetParameters'] = ({ parametersXml }) => {
    const r = X.parseParametersXml(parametersXml);
    if (r.errors.length) throw new Error(r.errors.join('\n'));
    const d = M.emptyDelta();
    r.parameters.forEach((p) => {
      const pd = D().paramDef(p.electricalArchitecture, p.code);
      if (pd) Object.assign(p, { packaged: !!pd.packaged, isGroupAdministrative: !!pd.admin, isFunction: !!pd.isFunction });
      d.parameters.push({ type: E.Op.AssignParameter, value: p });
    });
    return d;
  };
  H[T + 'GetNodesForContext'] = ({ contextId, productClassCode }) => {
    const defs = contextId ? D().defsForContext(contextId) : D().defs.filter((d) => !productClassCode || D().contexts.some((c) => d.contexts.includes(c.id) && c.productClassIds.includes(productClassCode)));
    return defs.map((d) => Object.assign(D().identifierFor(d), { derivedName: M.derivedName(D().identifierFor(d)), description: d.description }));
  };
  H[T + 'CreateNodeFromIdentifier'] = ({ nodeIdentifier }) => {
    const ea = nodeIdentifier.electricalArchitecture;
    if (![0, 1, 2].includes(ea)) throw new Error(`${ea} not supported`);
    const id = clone(nodeIdentifier);
    delete id.derivedName; delete id.description;
    const n = M.skeletonNode(id, ea);
    const def = D().findDef(id);
    n.isCabNode = !!(def && def.cab);
    n.notifications = [];
    return n;
  };
  H[T + 'CreateHardware'] = ({ partNumber }) => {
    const pn = Number(partNumber);
    if (!pn) throw new Error(`Failed to resolve component name (${partNumber})`);
    return { name: D().hwNames[pn] || 'Sub Hardware', number: pn, quantity: 1, fieldNumber: null, serialNumber: '', notifications: [], source: null };
  };
  H[T + 'ChangeNodeTemplate'] = ({ nodeJson, nodeTemplateDocumentNumber }) => {
    const n = parse(nodeJson);
    const doc = Number(nodeTemplateDocumentNumber);
    if (!doc || String(doc).length !== 8) throw new Error(`Failed to change NTP to ${nodeTemplateDocumentNumber}`);
    n.versionName = ''; n.replacementChainName = ''; n.nodeTemplateStatus = '';
    n.nodeTemplateDocument = Object.assign({ name: 'NTP', quantity: 1, fieldNumber: null, notifications: [], source: null }, n.nodeTemplateDocument || {}, { number: doc });
    const vi = D().versionByDoc(doc);
    if (vi) {
      if (vi.def !== D().findDef(n.nodeIdentifier)) throw new Error(`Failed to change NTP to ${doc}: the document belongs to node ${vi.def.name}`);
      n.versionName = vi.v.versionName; n.replacementChainName = vi.v.chain; n.nodeTemplateStatus = vi.v.status;
    }
    return n;
  };
  H[T + 'PrepareForVespa2'] = ({ state: st, product }) => {
    const id = Object.keys(state.sessionData).length + 1000 + Math.floor(Math.random() * 1000);
    state.sessionData[id] = st;
    persist();
    const p = parse(product);
    const info = p.productSpecification.productInformation;
    const yw = (d) => (TR.util.yearWeek(d) || '').slice(2);
    return {
      postUrl: 'https://vespa2.example.invalid/SpecificationEditor', communicationModel: {
        trans_id: id, user_id: state.settings.userId.toUpperCase(), reply_to: `${location.href.split(/[?#]/)[0]}#/TestRequest2000Callback/Vespa2?__cid=${uuid().slice(0, 8)}`,
        pc: info.productClassId, specification_date: yw(info.specificationDate), assembly_date: yw(info.assemblyDate), chassis_series: info.chassisSeries,
        chassis_number: /^\d+$/.test(info.chassisNumber || '') ? Number(info.chassisNumber) : 0,
        vars: p.productSpecification.variants.map((v) => (v.familyId || '') + (v.variantId || '')), s_notes: p.productSpecification.sNotes.map((s) => s.value), sec_hash: '',
      },
    };
  };
  H[T + 'LoadTestRequestState'] = ({ id }) => {
    if (!(id in state.sessionData)) throw new Error(`No saved test request state with id ${id}`);
    return state.sessionData[id];
  };
  H['TestRequest2000Callback/Vespa2'] = ({ spec }) => {
    const m = parse(spec);
    const variantSpec = (m.vars || []).filter(Boolean).map((v) => D().variantByIdVar6(String(v).trim().toUpperCase()) || { idVar6: v, familyId: String(v).slice(0, 3), variantId: String(v).slice(3), symbol: '', description: '' })
      .map((v) => ({ description: v.description, familyId: v.familyId, variantId: v.variantId, symbol: v.symbol, idVar6: v.idVar6, familyType: v.familyType }));
    const sNoteSpec = m.s_notes == null ? null : m.s_notes.filter(Boolean).map((s) => ({ value: s, name: D().sNoteName(s) }));
    return { vespa2TransactionId: m.trans_id, variantSpec, sNoteSpec };
  };
  H[T + 'GetRequestFileName'] = ({ request, chassis }) => M.requestFileName(request, chassis);
  H[T + 'NodeVersionStatusLegend'] = () => E.NodeStatusLegend;
  H[T + 'GetLanguageCodeSelectList'] = () => D().languageCodes.map((l) => ({ text: l, value: l }));
  H[T + 'ValidateVariantsForProductClass'] = ({ variants, productClassCode }) => (variants || []).filter((v) => {
    const d = D().variants.find((x) => x.idVar6 === (v.idVar6 || v.familyId + v.variantId));
    return d && d.authorizedProductClasses.includes(productClassCode);
  }).map((v) => { const d = D().variants.find((x) => x.idVar6 === (v.idVar6 || v.familyId + v.variantId)); return { variantId: d.variantId, familyId: d.familyId, familyType: d.familyType, symbol: d.symbol }; });
  H[T + 'GetParameterCodesForMsws'] = ({ partNumbers }) => {
    const codes = [];
    D().defs.forEach((d) => d.versions.forEach((v, i) => { if ((partNumbers || []).map(Number).includes(v.msw)) D().buildParams(d, i).forEach((p) => codes.push(p.code)); }));
    return uniq(codes);
  };
  H[T + 'StoreProduct'] = ({ productJson, series, number }) => {
    try {
      const p = decryptProduct(parse(productJson));
      const k = TR.chassis.chassisKey({ chassisSeries: series, chassisNumber: number });
      if (!series || !parseInt(number, 10)) throw new Error('bad chassis');
      state.swc[k] = { product: p, modified: new Date().toISOString(), modifier: state.settings.userId };
      persist();
      const link = `${location.href.split(/[?#]/)[0]}?chassisSeries=${encodeURIComponent(series)}&chassisNumber=${encodeURIComponent(number)}&source=SWC`;
      return { success: true, link };
    } catch (e) {
      return { success: false, error: 'Oops, something went wrong when trying to save product xml...' };
    }
  };
  H[T + 'LoadSwcProductFromChassis'] = ({ chassis }) => {
    const k = TR.chassis.chassisKey(chassis || {});
    const s = state.swc[k];
    if (!s) throw new Error(`Could not find SWC product: ${(chassis || {}).chassisSeries} ${(chassis || {}).chassisNumber}`);
    const p = out(clone(s.product));
    p.information = `Saved: ${TR.util.fmtDateTime(s.modified)} by ${s.modifier}`;
    return p;
  };
  H[T + 'GetSpareCabData'] = ({ orderNumber }) => {
    const o = D().spareCabOrders[String(orderNumber || '').trim()];
    if (!o) throw new Error(`Order number ${orderNumber} was not found in the CBR order API`);
    const ids = o.VariantString.variants.map((v) => v.IdVar6);
    const parts = [];
    o.OrderComponentBom.forEach((b) => b.Part.forEach((p) => parts.push({ itemNumber: p.PartNumber, quantity: Math.floor(p.Quantity) })));
    return { variants: D().variants.filter((v) => ids.includes(v.idVar6)).map(clone), softwareRelatedHardwares: parts, order: { orderNumber: o.OrderNumber, chassis: `${o.ChassieType} ${o.ChassieNumber}`, status: o.OrderStatus } };
  };

  // request log
  H['RequestLog/List'] = (p) => {
    let list = allLog();
    if (p.requestType !== null && p.requestType !== undefined && p.requestType !== '') list = list.filter((e) => e.requestType === Number(p.requestType));
    if (p.userId) list = list.filter((e) => e.userId.toUpperCase() === String(p.userId).trim().toUpperCase());
    if (p.chassisSeries) list = list.filter((e) => e.chassisSeries.toUpperCase() === String(p.chassisSeries).trim().toUpperCase());
    if (p.chassisNumber) list = list.filter((e) => parseInt(e.chassisNumber, 10) === parseInt(p.chassisNumber, 10));
    if (p.from) list = list.filter((e) => e.receivedAt >= new Date(p.from).toISOString());
    if (p.to) list = list.filter((e) => e.receivedAt <= new Date(p.to).toISOString());
    if (p.baselineGuid) list = list.filter((e) => e.baselineGuid === p.baselineGuid);
    if (p.ignoreTestRequests) list = list.filter((e) => !e.isTestRequest);
    const size = p.pageSize || 10, idx = p.index || 0;
    return { items: list.slice(idx * size, idx * size + size).map(listItem), numberOfHits: list.length };
  };
  H['RequestLog/LoadByLogId'] = ({ logId }) => findLog((e) => e.id === logId, `log id ${logId}`);
  H['RequestLog/LoadByTransactionId'] = ({ transactionId }) => findLog((e) => e.transactionId === transactionId, `transaction id ${transactionId}`);
  H['RequestLog/LoadByIncomingMessageId'] = ({ incomingMessageId }) => findLog((e) => e.incomingMessageId === incomingMessageId, `incoming message id ${incomingMessageId}`);
  H['RequestLog/LoadByOutgoingMessageId'] = ({ outgoingMessageId }) => findLog((e) => e.outgoingMessageId === outgoingMessageId, `outgoing message id ${outgoingMessageId}`);
  H['RequestLog/GetMessages'] = ({ logId }) => {
    const e = allLog().find((x) => x.id === logId);
    if (!e) throw new Error('Log entry not found');
    const rr = requestResponse(e);
    return { entry: listItem(e), incomingMessage: rr.requestXml, outgoingMessage: rr.responseXml };
  };

  // aftermarket requests
  function runAftermarket(type, request, mode) {
    const payload = parse(request);
    const ref = (payload.products || [payload.product])[0];
    if (mode === 'requestXml') return X.requestToXml(type, stripModel(payload), payload.requestModel, header(type));
    let result;
    if (type === 0) result = { items: TR.engine.softwareRequest(payload) };
    else if (type === 2) result = { items: TR.engine.kitRequest(payload) };
    else if (type === 4) result = { items: TR.engine.spareCabRequest(payload) };
    else if (type === 7) result = { items: [], availableUpdateItem: TR.engine.availableUpdates(payload) };
    else throw new Error('Request type not yet implemented.');
    const entry = logRequest(type, payload, result);
    const xml = type === 7 ? X.responseToXml('AvailableUpdatesResponse', [{ dataArea: result.availableUpdateItem.dataArea }], headerFor(entry)) : X.responseToXml(responseRoot(type), result.items, headerFor(entry));
    if (mode === 'responseXml') return xml;
    const items = result.items.map((r) => Object.assign(clone(r), { delta: encryptDelta(clone(r.delta), ref && M.inflate(clone(ref))) }));
    if (mode === 'plain') return items;
    return { item: items, availableUpdateItem: result.availableUpdateItem || null, xml, transactionId: entry.transactionId };
  }
  [['Software', 0], ['Kit', 2], ['SpareCab', 4], ['AvailableUpdates', 7]].forEach(([n, t]) => {
    H[`AftermarketRequest/Request${n}WithXml`] = ({ request }) => runAftermarket(t, request, 'withXml');
    H[`AftermarketRequest/Request${n}`] = ({ request }) => runAftermarket(t, request, 'plain');
    H[`AftermarketRequest/Request${n}Xml`] = ({ request }) => runAftermarket(t, request, 'responseXml');
    H[`AftermarketRequest/Get${n}RequestXml`] = ({ request }) => runAftermarket(t, request, 'requestXml');
  });
  [['Hardware', 1], ['Language', 3]].forEach(([n]) => {
    ['WithXml', '', 'Xml'].forEach((s) => { H[`AftermarketRequest/Request${n}${s}`] = () => { throw new Error('Request type not yet implemented.'); }; });
    H[`AftermarketRequest/Get${n}RequestXml`] = () => { throw new Error('Request type not yet implemented.'); };
  });
  function runBreakdown(type, requestJson, mode) {
    const payload = parse(requestJson);
    if (mode === 'requestXml') return X.requestToXml(type, stripModel(payload), payload.requestModel, header(type));
    const r = type === 5 ? TR.engine.productionBreakdown(payload) : TR.engine.developmentBreakdown(payload);
    logRequest(type, payload, { breakdown: r, baselineGuid: r.product.productSpecification.productInformation.baselineGuid });
    const xml = X.productToXml(r.product);
    if (mode === 'responseXml') return xml;
    ensureRead(r.product);
    encryptProduct(r.product);
    return { item: [{ product: r.product, baselineUrl: r.baselineUrl }], xml };
  }
  [['Production', 5], ['Development', 6]].forEach(([n, t]) => {
    H[`SoftwareBreakdown/Request${n}SoftwareBreakdownWithXml`] = ({ requestJson }) => runBreakdown(t, requestJson, 'withXml');
    H[`SoftwareBreakdown/Request${n}SoftwareBreakdownXml`] = ({ requestJson }) => runBreakdown(t, requestJson, 'responseXml');
    H[`SoftwareBreakdown/Get${n}SoftwareBreakdownRequestXml`] = ({ requestJson }) => runBreakdown(t, requestJson, 'requestXml');
  });
  H['SoftwareBreakdown/GetBaselineVersions'] = ({ baselineIdentifier }) => D().baselines.filter((b) => b.identifier.toUpperCase() === String(baselineIdentifier || '').trim().toUpperCase()).map((b) => b.version);

  // misc
  H['Baseline/GetBaselines'] = ({ contextIds, states }) => D().baselines.filter((b) => (!contextIds || !contextIds.length || contextIds.includes(b.contextId)) && (!states || states.includes(b.state)))
    .map((b) => ({ guid: b.guid, name: b.name, state: b.state, identifier: b.identifier, version: b.version, contextId: b.contextId, category: b.category }));
  H['Factory/LoadAll'] = () => clone(D().factories);
  H['SessionData/Save'] = ({ data }) => { const id = 'SD' + Date.now().toString(36).toUpperCase(); state.sessionData[id] = data; persist(); return id; };
  H['ConversionKit/AddToKitCheckPartNumber'] = ({ partNumber }) => {
    const k = TR.engine.findKit(partNumber);
    if (!k) throw new Error(`Conversion kit part number ${partNumber} was not found`);
    if (k.state === 'Released') throw new Error(`Conversion kit ${partNumber} is released and can not be changed`);
    return true;
  };
  H['ConversionKit/CreateKitFromDelta'] = ({ sessionDataId }) => {
    const data = parse(state.sessionData[sessionDataId]);
    if (!data) throw new Error('Session data not found');
    const pn = Math.max(...state.kits.map((k) => Number(k.partNumber))) + 1;
    const kit = { partNumber: pn, name: `Kit from ${data.productInformation.chassisSeries} ${data.productInformation.chassisNumber}`, state: 'In Progress', isServiceKit: false, isCampaignKit: false, productClasses: [data.productInformation.productClassId], delta: decryptDelta(data.assignProduct), createdBy: state.settings.userId, createdAt: new Date().toISOString() };
    state.kits.push(kit);
    persist();
    return kit;
  };
  H['ConversionKit/AddToKitFromDelta'] = ({ sessionDataId, partNumber }) => {
    const data = parse(state.sessionData[sessionDataId]);
    const kit = TR.engine.findKit(partNumber);
    if (!kit || !data) throw new Error('Kit or session data not found');
    const add = decryptDelta(data.assignProduct);
    kit.delta.nodes = kit.delta.nodes.concat(add.nodes || []);
    kit.delta.parameters = kit.delta.parameters.concat(add.parameters || []);
    kit.delta.productSpecification.variants = kit.delta.productSpecification.variants.concat((add.productSpecification || {}).variants || []);
    kit.delta.productSpecification.sNotes = kit.delta.productSpecification.sNotes.concat((add.productSpecification || {}).sNotes || []);
    if (!kit.productClasses.includes(data.productInformation.productClassId)) kit.productClasses.push(data.productInformation.productClassId);
    persist();
    return kit;
  };
  H['ConversionKit/List'] = () => clone(state.kits).map((k) => ({ partNumber: k.partNumber, name: k.name, state: k.state, isServiceKit: k.isServiceKit, isCampaignKit: k.isCampaignKit, productClasses: k.productClasses, operations: M.deltaCounts(k.delta) }));
  H['ProductUpdates/Create'] = ({ productJson, assignProductJson, hasChanges }) => {
    const id = state.productUpdates.length + 501;
    const p = parse(productJson);
    state.productUpdates.push({ id, chassis: p ? M.chassisText(p) : '', hasChanges, assignProduct: assignProductJson ? parse(assignProductJson) : null, createdAt: new Date().toISOString(), createdBy: state.settings.userId });
    persist();
    return { id, hasChanges };
  };
  H['Artifactory/ChecksumSearch'] = ({ sha }) => {
    const results = [];
    D().defs.forEach((d) => d.versions.forEach((v) => Object.keys(v.sha).forEach((k) => {
      v.sha[k].forEach((h, i) => {
        if (h !== sha) return;
        const file = `${d.name}_${v.versionName}_${k.toUpperCase()}${i ? '.desc.xml' : '.vbf'}`;
        const path = `/${d.name.toLowerCase()}/${v.versionName}/${file}`;
        results.push({ repo: v.status === 'released' ? 'swc-release-local' : 'swc-dev-local', path, lastModified: `${v.introductionWeek.slice(0, 4)}-0${1 + (v.idx % 9)}-1${v.idx}T10:2${v.idx}:00Z`, downloadUri: `https://artifactory.example.invalid/artifactory${path}` });
        if (i === 0 && v.status !== 'released') results.push({ repo: 'swc-mirror-remote', path, lastModified: `${v.introductionWeek.slice(0, 4)}-0${1 + (v.idx % 9)}-2${v.idx}T08:00:00Z`, downloadUri: `https://artifactory.example.invalid/mirror${path}` });
      });
    })));
    return { results };
  };
  H['Permission/GetProductEditorPermissions'] = ({ contextId }) => ({
    UpdateVda: !!contextId && canWriteVda(contextId), Save: !!state.settings.perms.save, ToKit: !!state.settings.perms.toKit,
  });
  H['TestRequest/VCADSRequest'] = (p) => ({ __raw: TR.engine.vcads(p) });

  // ---------- API dispatcher ----------
  const apiLog = [];
  const listeners = [];
  // Ids keep counting when old entries are dropped (the log keeps the latest 300), so an id never names two calls.
  let seq = 0;
  const nextId = () => ++seq;
  const notify = () => listeners.forEach((f) => f());
  function call(name, params) {
    const started = performance.now();
    const entry = { id: nextId(), time: new Date(), name, kind: 'simulated', params: clone(params || {}), response: null, ms: 0, success: null };
    apiLog.push(entry);
    if (apiLog.length > 300) apiLog.shift();
    listeners.forEach((f) => f());
    const lat = Math.max(0, state.settings.latency * (0.7 + Math.random() * 0.6));
    entry.simLatency = Math.round(lat);   // the simulated network delay of this call; the rest of ms is processing
    return new Promise((resolve) => {
      setTimeout(() => {
        let res;
        try {
          const h = H[name];
          if (!h) throw new Error(`404 - endpoint ${name} not found`);
          const r = h(clone(params || {}));
          if (r instanceof Result) res = Object.assign({ success: true, errors: [], warnings: [], infos: [] }, r);
          else if (r && r.__raw) res = r.__raw;
          else if (r && name === T + 'StoreProduct') res = r;
          else if (r && name === 'RequestLog/List') res = { success: true, items: r.items, numberOfHits: r.numberOfHits, errors: [] };
          else res = { success: true, item: r, errors: [], warnings: [], infos: [] };
        } catch (e) {
          if (!(e instanceof Error) || /is not defined|Cannot read|undefined/.test(e.message)) console.error(e);
          res = { success: false, item: null, errors: [e.message || String(e)], warnings: [], infos: [] };
        }
        entry.response = clone(res);
        entry.success = res.success !== false;
        entry.ms = Math.round(performance.now() - started);
        listeners.forEach((f) => f());
        resolve(res);
      }, lat);
    });
  }

  load();
  TR.server = { state, persist, reset, call, apiLog, nextId, notify, onLog: (f) => listeners.push(f), findVda, edbProduct, decryptProduct, encryptProduct, isHiddenParam, baselineUrl, servicePackUrl, canWriteVda, ensureSeedLog, allLog, handlers: H, validateParameter };
  TR.api = call;
})();
