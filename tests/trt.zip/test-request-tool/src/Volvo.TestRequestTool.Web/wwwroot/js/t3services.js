/* Studio views for the T3-capable JSON services: Product Update Service (result card in the Validate stage)
   and Available Product Updates (results dialog). Both show the exact contract request and response. */
(function () {
  'use strict';
  const { h } = TR.util;
  const button = (label, icon, fn, kind = 'secondary') => h('button', { class: 's-btn ' + kind, onClick: fn }, icon ? TR.icon(icon) : null, label);
  const chip = (label, type = 'neutral') => h('span', { class: 's-chip ' + type }, label);
  const nodeOf = (n) => { const kind = Object.keys(n)[0]; return Object.assign({ kind }, n[kind]); };
  const chassis = (o) => `${String(o.chassisSeries || '').trim()} ${o.chassisNumber || ''}`;

  function open(type) {
    const pane = TR.app.shell.left;
    if (!pane.product.loaded()) { TR.ui.alert('Load a vehicle first.'); return; }
    pane.request.selectedRequestType = type;
    TR.request.open(pane);
  }

  function json(title, obj) {
    TR.ui.modal({ title, width: 920, body: () => h('div', { class: 's-json' }, TR.ui.jsonViewer(obj, { expandDepth: 4 })),
      buttons: [{ label: 'Copy JSON', onClick: () => { if (navigator.clipboard) navigator.clipboard.writeText(JSON.stringify(obj, null, 2)); TR.ui.summary.addInformation('Contract JSON copied.'); } }, { label: 'Close', primary: true }] });
  }

  /** Installed software per node name, from the product that was sent. */
  function installed(product) {
    const map = {};
    (product?.nodes || []).forEach((n) => { map[n.name] = { doc: n.nodeTemplateDocument?.number, version: n.versionName, products: Object.fromEntries((n.softwareProducts || []).map((s) => [s.softwareProduct || s.name, s.packageVersion])) }; });
    return map;
  }

  function contractButtons(reply) {
    return h('div', { class: 's-svc-actions' }, button('Contract request', 'code', () => json(`${reply.contract} ${reply.version} request`, reply.request), 'text'),
      button('Contract response', 'file', () => json(`${reply.contract} ${reply.version} response`, reply.response), 'text'));
  }

  // ---------- Product Update Service: card in the Validate stage ----------
  function pusCard() {
    const rec = TR.backend && TR.backend.latest;
    if (!rec || rec.kind !== 'ProductUpdateService' || !rec.serviceResponses) return null;
    return h('section', { class: 's-result-card s-service-card', 'data-guide': 'pus-card' },
      h('div', { class: 's-card-top' }, h('div', null, h('h2', null, 'Product Update Service'), h('p', { class: 'muted' }, 'Update to service pack, including T3 HPC nodes with execution environments and software products.')), chip('JSON contract', 'simulation')),
      rec.serviceResponses.products.map((reply, i) => pusProduct(reply, rec.outcomes[i])));
  }

  function pusProduct(reply, outcome) {
    const r = reply.response, pu = r.productUpdate, before = installed(outcome && outcome.input), ok = reply.aftermarketErrorCode === 0;
    const rows = [];
    (pu?.nodes || []).map(nodeOf).forEach((n) => {
      const was = before[n.nodeName] || { products: {} };
      if (n.kind === 'hpcNode') (n.executionEnvironments || []).forEach((env) => (env.softwareProducts || []).forEach((s) => rows.push([n.nodeName, env.nodeName, s.name, was.products[s.name] || '—', s.version])));
      else rows.push([n.nodeName, 'TEA2+ slots', 'Node template ' + n.nodeTemplateDocumentNumber, was.doc || '—', n.nodeTemplateDocumentNumber]);
    });
    return h('div', { class: 's-svc-product' },
      h('div', { class: 's-svc-head' }, h('strong', null, TR.icon('truck', 16), chassis(reply)),
        chip(`Schema ${reply.version}`), chip(reply.operationType || 'UpdateToServicePack'), reply.scenario ? chip('Scenario ' + reply.scenario) : null,
        chip(ok ? 'Error code 0' : 'Error code ' + reply.aftermarketErrorCode, ok ? 'good' : 'warning'),
        pu?.servicePack ? h('span', { class: 's-svc-pack', 'data-guide': 'pus-pack' }, TR.icon('layers', 15), pu.servicePack.name) : null),
      !ok ? h('div', { class: 's-banner warning', 'data-guide': 'pus-error' }, TR.icon('alert'), (r.errors || []).map((e) => `${e.type}: ${e.text}`).join(' · ')) : null,
      rows.length ? h('table', { class: 's-table s-svc-table', 'data-guide': 'pus-table' }, h('thead', null, h('tr', null, ['Node', 'Execution environment', 'Software product', 'Installed', 'Service pack'].map((x) => h('th', null, x)))),
        h('tbody', null, rows.map(([node, env, sp, from, to]) => h('tr', null, h('td', null, node), h('td', null, env), h('td', null, h('strong', null, sp)), h('td', { class: 'muted' }, from), h('td', null, String(from) === String(to) ? h('span', { class: 'muted' }, to + ' (same)') : h('span', { class: 's-svc-up' }, to)))))) : null,
      (pu?.releaseNotes || []).length ? h('div', { class: 's-svc-notes', 'data-guide': 'pus-notes' }, h('h4', null, 'Release notes'), h('ul', null, pu.releaseNotes.map((n) => h('li', null, h('strong', null, n.nodeName + ' '), n.text || ('Document ' + n.id))))) : null,
      (reply.rejectedCandidates || []).length ? h('details', { class: 's-svc-rejected', open: !ok, 'data-guide': 'pus-rejected' }, h('summary', null, `Rejected service pack candidates (${reply.rejectedCandidates.length})`),
        h('ul', null, reply.rejectedCandidates.map((c) => h('li', null, h('strong', null, c.servicePack + ': '), c.reasons.join('; '))))) : null,
      contractButtons(reply));
  }

  // ---------- Available Product Updates: results dialog ----------
  function showResult(record) {
    if (!record || !record.serviceResponses) return;
    TR.ui.modal({ title: 'Available product updates', width: 1060, class: 's-svc-modal', body: () => h('div', { class: 's-svc-results', 'data-guide': 'apu-results' },
      h('p', { class: 'muted' }, 'What could be updated on each vehicle, by action criteria. Nothing is changed on the vehicle; use Product Update Service or a software request to apply an update.'),
      record.serviceResponses.products.map((reply, i) => apuProduct(reply, record.outcomes[i]))),
    buttons: [{ label: 'Close', primary: true }] });
  }

  function apuProduct(reply, outcome) {
    const root = reply.response.ShowAvailableProductUpdates, d = root.DataArea, show = d.Show, before = installed(outcome && outcome.input);
    const status = show.ResponseCriteria === 'Accepted' ? 'good' : 'warning';
    const sections = [];
    (d.SoftwareNodeReplacements || []).forEach((s) => {
      const nodes = (s.AssignedNodes?.Node || []).map(nodeOf);
      sections.push(h('section', { class: 's-svc-section', 'data-guide': 'apu-' + s.actionCriteria.split('.').pop() },
        h('div', { class: 's-svc-section-head' }, h('h4', null, s.actionCriteria.replace('SoftwareReplacements.', 'Software replacements · ')),
          s.ServicePack ? h('span', { class: 's-svc-pack' }, TR.icon('layers', 15), s.ServicePack.name, s.ServicePack.exactMatch ? ' · exact match' : '') : null,
          (s.UpdatePurposes?.Purpose || []).map((p) => chip(p))),
        h('table', { class: 's-table s-svc-table' }, h('thead', null, h('tr', null, ['Node', 'Installed', 'Available', 'Status', 'Remote download', 'Software products'].map((x) => h('th', null, x)))),
          h('tbody', null, nodes.map((n) => { const was = before[n.nodeName] || {}; return h('tr', null, h('td', null, h('strong', null, n.nodeName), n.kind === 'hpcNode' ? chip('HPC') : null),
            h('td', { class: 'muted' }, was.doc || '—'), h('td', null, n.isSoftwareSame ? h('span', { class: 'muted' }, (n.nodeTemplateDocumentNumber || '—') + ' (same)') : h('span', { class: 's-svc-up' }, n.nodeTemplateDocumentNumber || '—')),
            h('td', null, n.nodeTemplateStatus), h('td', null, n.remoteSwdlAvailability),
            h('td', { class: 's-svc-sw' }, (n.executionEnvironments || []).map((e) => h('div', null, h('span', { class: 'muted' }, e.nodeName + ': '), e.softwareProducts.map((x) => `${x.name} ${x.version}`).join(', '))))); }))),
        (s.ReleaseNotes?.ReleaseNote || []).length ? h('ul', { class: 's-svc-notes-list' }, s.ReleaseNotes.ReleaseNote.map((n) => h('li', null, n.releaseNote))) : null));
    });
    const hw = d.HardwareNodeReplacements?.HardwareNodeReplacement || [];
    if (d.HardwareNodeReplacements) sections.push(h('section', { class: 's-svc-section', 'data-guide': 'apu-hardware' }, h('h4', null, 'Hardware replacements'),
      hw.length ? h('table', { class: 's-table s-svc-table' }, h('thead', null, h('tr', null, ['Node', 'Replacement hardware part numbers'].map((x) => h('th', null, x)))),
        h('tbody', null, hw.map((x) => h('tr', null, h('td', null, h('strong', null, x.item.nodeName)), h('td', null, x.hardwarePartNumbers.join(', ')))))) : h('p', { class: 'muted' }, 'No hardware replacement is needed for the available software.')));
    (d.Kits || []).forEach((k) => sections.push(h('section', { class: 's-svc-section', 'data-guide': 'apu-kits' }, h('h4', null, k.actionCriteria.replace(/([a-z])([A-Z])/g, '$1 $2')),
      k.Kit.length ? h('ul', { class: 's-svc-kits' }, k.Kit.map((x) => h('li', null, h('strong', null, x.name), ` · ${x.partNumber}`, x.isAvailableRemote ? chip('Remote') : null))) : h('p', { class: 'muted' }, 'No kit matches this vehicle and scenario.'))));
    if (d.DisplayLanguages) sections.push(h('section', { class: 's-svc-section' }, h('h4', null, 'Display languages'), h('p', { class: 'muted' }, (d.DisplayLanguages.LanguageComponents || []).length ? `${d.DisplayLanguages.LanguageComponents.length} language component(s).` : 'No language-capable nodes on this vehicle.')));
    return h('div', { class: 's-svc-product' },
      h('div', { class: 's-svc-head' }, h('strong', null, TR.icon('truck', 16), chassis(reply)), chip(`Contract ${reply.version}`),
        h('span', { 'data-guide': 'apu-status' }, chip(`${show.ResponseCriteria} · status ${show.StatusCode}`, status))),
      show.StatusText ? h('div', { class: 's-banner warning' }, TR.icon('alert'), show.StatusText) : null,
      sections, contractButtons(reply));
  }

  TR.t3services = { open, pusCard, showResult, json };
  if (TR.testRequest) TR.testRequest.showServiceResult = showResult;
})();
