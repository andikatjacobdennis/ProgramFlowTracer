/* Simulated configurator engine: software / kit / spare cab / available updates requests,
   production & development breakdowns, compare-breakdown diff tree and the legacy VCADS request. */
(function () {
  'use strict';
  const TR = window.TR;
  const E = TR.enums;
  const M = TR.model;
  const { clone, uniq, splitList } = TR.util;
  const D = () => TR.db;

  const SCENARIO_STATUSES = {
    1: ['released', 'introduced'], 2: ['released', 'introduced'], 3: ['released'],
    4: ['released', 'introduced', 'prereleaseverification'], 5: ['released', 'introduced', 'prereleaseverification', 'inprogress'],
  };
  const KIT_SCENARIO_STATES = {
    1: ['Released', 'Introduced'], 2: ['Released', 'Introduced', 'Pre Release Verification', 'In Progress'], 3: ['Released'], 4: ['Released', 'Introduced', 'Pre Release Verification'],
  };
  const currentWeek = () => TR.util.yearWeek(new Date());
  const err = (text, node) => ({ severity: E.Severity.Error, text, node: node || '' });
  const warn = (text, node) => ({ severity: E.Severity.Warning, text, node: node || '' });
  const info = (text, node) => ({ severity: E.Severity.Information, text, node: node || '' });

  function versionAllowed(v, scenario) {
    const st = SCENARIO_STATUSES[scenario] || SCENARIO_STATUSES[1];
    if (!st.includes(v.status)) return false;
    if (scenario === E.Scenario.IntroductionDateSet && v.introductionWeek > currentWeek()) return false;
    return true;
  }
  function curIdx(n) {
    const vi = n.nodeTemplateDocument ? D().versionByDoc(n.nodeTemplateDocument.number) : null;
    return vi ? vi.idx : -1;
  }
  function pickVersion(def, n, o) {
    const cur = curIdx(n);
    const curV = cur >= 0 ? def.versions[cur] : null;
    const hw = Number(o.hw || (n.ecuHardware && n.ecuHardware.number));
    const r = { idx: -1, blockedByHw: null, blockedByPbl: null, blockedByRemote: null };
    for (let i = def.versions.length - 1; i >= 0; i--) {
      const v = def.versions[i];
      if (!versionAllowed(v, o.scenario)) continue;
      if (o.remote && !v.remoteCapable) { r.blockedByRemote = r.blockedByRemote || v; continue; }
      if (!v.hardware.includes(hw)) { r.blockedByHw = r.blockedByHw || v; continue; }
      if (o.pblCapable === false && curV && v.pbl !== curV.pbl) { r.blockedByPbl = r.blockedByPbl || v; continue; }
      r.idx = i;
      break;
    }
    return r;
  }
  const latestServicePack = (ctxId) => D().servicePacks.filter((s) => s.contextId === ctxId).sort((a, b) => b.sortOrder - a.sortOrder)[0] || null;

  function findKit(no) {
    const s = String(no || '').trim();
    return TR.server.state.kits.find((k) => String(k.partNumber) === s || k.name.toUpperCase() === s.toUpperCase()) || null;
  }

  /** remove other variants of single-select families when a variant of that family was assigned */
  function normalizeFamilies(p, assigned) {
    const spec = p.productSpecification;
    assigned.forEach((v) => {
      if (v.familyType === 'E') return;
      spec.variants = spec.variants.filter((x) => x.familyId !== v.familyId || x.idVar6 === v.idVar6);
    });
  }

  function rebuildNode(def, idx, old) {
    const n = D().buildNode(def, idx, { hw: old && old.ecuHardware ? old.ecuHardware.number : undefined, serial: old && old.ecuHardware ? old.ecuHardware.serialNumber : undefined });
    if (old && old.ecuHardware) n.ecuHardware = clone(old.ecuHardware);
    if (old && old.subHardwares && n.subHardwares) n.subHardwares = clone(old.subHardwares);
    return n;
  }

  function replaceNode(target, n) {
    const i = target.nodes.findIndex((x) => M.idMatch(x.nodeIdentifier, n.nodeIdentifier));
    if (i >= 0) target.nodes[i] = n; else target.nodes.push(n);
    target.nodes.sort(M.compareNodes);
  }

  function applyParamsForVersion(target, def, oldIdx, newIdx, opts) {
    const oldP = oldIdx >= 0 ? D().buildParams(def, oldIdx) : [];
    const newP = D().buildParams(def, newIdx);
    for (const np of newP) {
      const ex = target.parameters.find((x) => x.code === np.code && x.electricalArchitecture === np.electricalArchitecture);
      const op = oldP.find((x) => x.code === np.code);
      if (!ex) { target.parameters.push(np); continue; }
      const customerValue = !op || !M.paramEqual(ex, op);
      if ((opts && opts.reset) || (!customerValue && !M.paramEqual(ex, np))) Object.assign(ex, clone(np));
    }
    for (const opar of oldP) {
      if (!newP.some((x) => x.code === opar.code)) target.parameters = target.parameters.filter((x) => !(x.code === opar.code && x.electricalArchitecture === opar.electricalArchitecture));
    }
    target.parameters.sort(M.compareParameters);
  }

  function releaseNote(def, idx, lang) {
    const v = def.versions[idx];
    return { text: v.releaseNotes[lang] || v.releaseNotes['en-GB'], source: `${M.derivedName(D().identifierFor(def))} - ${v.versionName}` };
  }

  function finishResponse(src, target, errors, extra) {
    const chassis = M.chassisOf(src);
    const blocking = errors.some((e) => e.severity === E.Severity.Error);
    let delta = M.emptyDelta();
    if (!blocking || extra.limitedValidation) {
      delta = M.computeDelta(target, src);
      delta.nodes = delta.nodes.map((op) => {
        if (![21, 22, 23, 41].includes(op.type)) return op;
        const n = target.nodes.find((x) => M.idMatch(x.nodeIdentifier, op.nodeIdentifier));
        return { type: E.NodeOps.replace[n.electricalArchitecture], value: clone(n) };
      });
      const bl = M.matchBaseline(M.ntpDocNumbers(target));
      delta.productSpecification.baselineName = bl ? bl.name : '';
      delta.productSpecification.baselineGuid = bl ? bl.guid : '';
    }
    const changed = blocking && !extra.limitedValidation ? [] : delta.nodes.map((o) => (o.value ? o.value.nodeIdentifier : o.identifier || o.nodeIdentifier));
    return {
      chassisSeries: chassis.chassisSeries, chassisNumber: chassis.chassisNumber, delta,
      affectedNodes: uniq(changed.concat(extra.affectedExtra || []).map((id) => JSON.stringify(id))).map((s) => JSON.parse(s)),
      dependentNodes: blocking && !extra.limitedValidation ? [] : extra.dependentNodes || [],
      releaseNotes: blocking && !extra.limitedValidation ? [] : extra.releaseNotes || [],
      limitedValidation: !!extra.limitedValidation,
      errorReport: errors.length ? { schemaVersion: '1.1.0', errors } : null,
      connectedServices: [],
    };
  }

  function requestedFor(req, chassis) {
    return (req.requestedNodes || []).filter((r) => !r.chassisSeries || TR.chassis.sameChassis(r, chassis));
  }

  function matchesLimit(n, token) {
    const t = token.toUpperCase();
    const id = n.nodeIdentifier || {};
    return (n.name || '').toUpperCase() === t || String(id.name || '').toUpperCase() === t || M.derivedPosition(id) === token || String(id.mid) === token;
  }

  function prepare(product) {
    const src = M.inflate(TR.server.decryptProduct(clone(product)));
    return { src, target: clone(src) };
  }

  function applySimulationKit(target, name, errors) {
    const kit = findKit(name);
    if (!kit) { errors.push(warn(`Simulation kit '${name}' was not found and has been ignored.`)); return; }
    M.applyDelta(target, kit.delta);
    normalizeFamilies(target, (kit.delta.productSpecification.variants || []).filter((o) => o.type === E.Op.AssignVariant).map((o) => o.value));
    errors.push(info(`Simulation kit ${kit.partNumber} '${kit.name}' applied before the request was evaluated.`));
  }

  // ---------- software request ----------
  function softwareForProduct(product, req) {
    const { src, target } = prepare(product);
    const info0 = src.productSpecification.productInformation;
    const chassis = M.chassisOf(src);
    const errors = [];
    const releaseNotes = [];
    const dependentNodes = [];
    let limited = false;
    const lang = req.selectedLanguageCode || 'en-GB';
    if (req.simulationKitName) applySimulationKit(target, req.simulationKitName, errors);
    const unknownVariants = src.productSpecification.variants.filter((v) => !v.description);
    if (!info0.context || unknownVariants.length) {
      const why = !info0.context ? `No context could be determined for product ${M.chassisText(src)}` : `Unknown variants: ${unknownVariants.map((v) => v.symbol || v.idVar6).join(', ')}`;
      if (req.allowLimitedValidation) { limited = true; errors.push(warn('Limited validation performed. ' + why)); } else errors.push(err(why));
    }
    const reqNodes = requestedFor(req, chassis);
    const prevHw = {};
    reqNodes.forEach((r) => { if (r.previousEcuHardware) prevHw[M.idKey(r.nodeIdentifier)] = r.previousEcuHardware; });
    let scope = reqNodes.length ? target.nodes.filter((n) => reqNodes.some((r) => M.idMatch(r.nodeIdentifier, n.nodeIdentifier))) : target.nodes.slice();
    reqNodes.forEach((r) => { if (!target.nodes.some((n) => M.idMatch(n.nodeIdentifier, r.nodeIdentifier))) errors.push(err(`Requested node ${M.derivedName(r.nodeIdentifier)} does not exist in the product`)); });
    if (req.limitTo) {
      const toks = splitList(req.limitTo, /[,;]+/);
      const outside = scope.filter((n) => !toks.some((t) => matchesLimit(n, t)));
      scope = scope.filter((n) => toks.some((t) => matchesLimit(n, t)));
      if (!scope.length) errors.push(err(`'Limit to' (${req.limitTo}) does not match any of the requested nodes`));
      if (req.extendedValidation) {
        outside.forEach((n) => { if (n.isSoftwareSame === false) errors.push(warn(`Extended validation: software of ${n.name} (outside 'Limit to') does not match its node template`, n.name)); });
        errors.push(info(`Extended validation performed for ${outside.length} node(s) outside 'Limit to'.`));
      }
    }
    const op = req.softwareRequestOperation || E.SoftwareRequestOperation.Update;
    const scenario = req.scenario || E.Scenario.Introduced;
    const sp = op === E.SoftwareRequestOperation.UpdateToServicePack ? latestServicePack(info0.context && info0.context.id) : null;
    if (op === E.SoftwareRequestOperation.UpdateToServicePack && !sp) errors.push(err('No service pack found for the product context'));

    const pending = scope.map((n) => n);
    const handled = new Set();
    while (pending.length) {
      const n = pending.shift();
      const key = M.nodeKey(n);
      if (handled.has(key)) continue;
      handled.add(key);
      const def = D().findDef(n.nodeIdentifier);
      if (!def) { errors.push(err(`${n.name} is not defined in the node template database`, n.name)); continue; }
      const cur = curIdx(n);
      const hw = Number(n.ecuHardware && n.ecuHardware.number);
      let newIdx = null;
      if (op === E.SoftwareRequestOperation.Refresh || op === E.SoftwareRequestOperation.Repair) {
        if (cur < 0) { errors.push(err(`${n.name}: no valid node template document. Use the Resolve operation.`, n.name)); continue; }
        newIdx = cur;
        if (prevHw[key] || !def.versions[cur].hardware.includes(hw)) {
          if (!def.versions[cur].hardware.includes(hw)) {
            const r = pickVersion(def, n, { scenario, pblCapable: req.pblUpdateCapable, hw });
            if (r.idx < 0) { errors.push(err(`${n.name}: no software available for ECU hardware ${hw}`, n.name)); continue; }
            newIdx = r.idx;
            errors.push(info(`${n.name}: hardware ${hw} replaced (previous ${prevHw[key] || 'unknown'}), software selected for the new hardware`, n.name));
          }
        }
      } else if (op === E.SoftwareRequestOperation.Resolve) {
        if (cur >= 0) newIdx = cur;
        else {
          const ms = n.electricalArchitecture === E.EA.T3 ? Number((n.softwareProducts || [])[0]?.number) : n.mainSoftware && Number(n.mainSoftware.number);
          const m = def.versions.findIndex((v) => v.msw === ms);
          if (m < 0) { errors.push(err(`${n.name}: could not resolve a node template document from main software ${ms || '(none)'}`, n.name)); continue; }
          newIdx = m;
          errors.push(info(`${n.name}: resolved node template document ${def.versions[m].doc} (${def.versions[m].versionName})`, n.name));
        }
      } else if (op === E.SoftwareRequestOperation.UpdateToServicePack) {
        if (!sp) continue;
        const spIdx = sp.ntps[def.key];
        if (spIdx === undefined) { errors.push(warn(`${n.name} is not part of service pack ${sp.name}`, n.name)); continue; }
        newIdx = cur > spIdx ? cur : spIdx;
        if (cur > spIdx) errors.push(info(`${n.name} is already newer than service pack ${sp.name}`, n.name));
      } else {
        if (cur < 0) { errors.push(err(`${n.name}: no valid node template document. Use the Resolve operation.`, n.name)); continue; }
        const r = pickVersion(def, n, { scenario, remote: req.remoteRequest, pblCapable: req.pblUpdateCapable, hw });
        newIdx = r.idx > cur ? r.idx : cur;
        if (r.blockedByHw && r.blockedByHw.idx > newIdx) errors.push(warn(`Newer software ${r.blockedByHw.versionName} for ${n.name} requires ECU hardware ${r.blockedByHw.hardware.join('/')}. Hardware replacement required.`, n.name));
        if (r.blockedByPbl && r.blockedByPbl.idx > newIdx) errors.push(warn(`${r.blockedByPbl.versionName} for ${n.name} requires a primary bootloader update, but the vehicle is not PBL update capable.`, n.name));
        if (r.blockedByRemote && r.blockedByRemote.idx > newIdx) errors.push(warn(`${r.blockedByRemote.versionName} for ${n.name} is not available for remote download.`, n.name));
        if (newIdx === cur) errors.push(info(`${n.name} is up to date for scenario ${E.ScenarioNames[scenario]}`, n.name));
      }
      if (newIdx === null) continue;
      const nn = rebuildNode(def, newIdx, n);
      const changed = M.nodeAssignOp(nn, n) !== null;
      if (changed) {
        replaceNode(target, nn);
        applyParamsForVersion(target, def, cur, newIdx, { reset: op === E.SoftwareRequestOperation.Repair });
        if (newIdx !== cur) releaseNotes.push(releaseNote(def, newIdx, lang));
      } else if (op === E.SoftwareRequestOperation.Repair) {
        applyParamsForVersion(target, def, cur, newIdx, { reset: true });
      }
      for (const rq of def.versions[newIdx].requires || []) {
        const depDef = D().defByKey[rq.key];
        const dep = target.nodes.find((x) => D().findDef(x.nodeIdentifier) === depDef);
        if (!dep || curIdx(dep) >= rq.minIdx) continue;
        if (req.enableMultiNodeBehavior) {
          const r = pickVersion(depDef, dep, { scenario, remote: req.remoteRequest, pblCapable: req.pblUpdateCapable });
          if (r.idx >= rq.minIdx) {
            const dn = rebuildNode(depDef, r.idx, dep);
            const dCur = curIdx(dep);
            replaceNode(target, dn);
            applyParamsForVersion(target, depDef, dCur, r.idx);
            releaseNotes.push(releaseNote(depDef, r.idx, lang));
            dependentNodes.push(clone(dn.nodeIdentifier));
            handled.add(M.nodeKey(dn));
          } else errors.push(err(`${n.name} ${def.versions[newIdx].versionName} requires ${dep.name} ${depDef.versions[rq.minIdx].versionName} or later, which is not available for the scenario/hardware`, n.name));
        } else {
          errors.push(err(`${n.name} ${def.versions[newIdx].versionName} requires ${dep.name} ${depDef.versions[rq.minIdx].versionName} or later. Enable multi node behavior to update dependent nodes.`, n.name));
        }
      }
    }
    if (req.groupAdministrativeParameters && target.parameters.some((p) => p.isGroupAdministrative)) errors.push(info('Administrative parameters have been grouped.'));
    return finishResponse(src, target, errors, { limitedValidation: limited, releaseNotes, dependentNodes });
  }

  function softwareRequest(req) {
    if (!(req.products || []).length) throw new Error('The request does not contain any product');
    return req.products.map((p) => softwareForProduct(p, req));
  }

  // ---------- conversion kit request ----------
  function kitForProduct(product, req) {
    const { src, target } = prepare(product);
    const chassis = M.chassisOf(src);
    const pc = src.productSpecification.productInformation.productClassId;
    const errors = [];
    const releaseNotes = [];
    const lang = req.selectedLanguageCode || 'en-GB';
    if (req.simulationKitName) applySimulationKit(target, req.simulationKitName, errors);
    const numbers = (req.conversionKitNumbers || []).filter((k) => !k.chassisSeries || TR.chassis.sameChassis(k, chassis)).map((k) => String(k.conversionKitNumber || '').trim()).filter(Boolean);
    if (!numbers.length) errors.push(err(`No conversion kit part number entered for chassis ${M.chassisText(src)}`));
    const allowed = KIT_SCENARIO_STATES[req.scenario || 1] || KIT_SCENARIO_STATES[1];
    for (const no of numbers) {
      const kit = findKit(no);
      if (!kit) { errors.push(err(`Conversion kit ${no} does not exist`)); continue; }
      if (!kit.productClasses.includes(pc)) { errors.push(err(`Conversion kit ${no} is not valid for product class ${pc}`)); continue; }
      if (!allowed.includes(kit.state)) { errors.push(err(`Conversion kit ${no} has state '${kit.state}' which is not allowed for scenario ${E.KitScenarioNames[req.scenario || 1]}`)); continue; }
      if (req.onlyServiceKitAllowed && !kit.isServiceKit) { errors.push(err(`Conversion kit ${no} is not a service kit`)); continue; }
      const before = clone(target);
      M.applyDelta(target, kit.delta);
      normalizeFamilies(target, (kit.delta.productSpecification.variants || []).filter((o) => o.type === E.Op.AssignVariant).map((o) => o.value));
      (kit.delta.nodes || []).forEach((o) => {
        const nn = o.value || o;
        const def = nn.nodeIdentifier && D().findDef(nn.nodeIdentifier);
        const vi = nn.nodeTemplateDocument && D().versionByDoc(nn.nodeTemplateDocument.number);
        if (def && vi) {
          if (o.value && !req.pblUpdateCapable) {
            const old = before.nodes.find((x) => M.idMatch(x.nodeIdentifier, nn.nodeIdentifier));
            const oldV = old && D().versionByDoc(old.nodeTemplateDocument && old.nodeTemplateDocument.number);
            if (oldV && oldV.v.pbl !== vi.v.pbl) errors.push(warn(`Kit ${no}: ${nn.name} requires a primary bootloader update but the vehicle is not PBL update capable`, nn.name));
          }
          releaseNotes.push(releaseNote(def, vi.idx, lang));
        }
      });
      errors.push(info(`Conversion kit ${kit.partNumber} '${kit.name}' applied.`));
    }
    return finishResponse(src, target, errors, { limitedValidation: false, releaseNotes });
  }
  function kitRequest(req) {
    if (!(req.products || []).length) throw new Error('The request does not contain any product');
    return req.products.map((p) => kitForProduct(p, req));
  }

  // ---------- spare cab request ----------
  function spareCabRequest(req) {
    if (!req.product) throw new Error('The request does not contain any product');
    const { src, target } = prepare(req.product);
    const errors = [];
    const releaseNotes = [];
    const bl = D().baselines.find((b) => b.guid === req.baselineGuid);
    if (!req.baselineGuid) errors.push(err('A baseline must be selected for a spare cab request'));
    else if (!bl) errors.push(err(`Baseline ${req.baselineGuid} was not found`));
    const symbols = new Set(target.productSpecification.variants.map((v) => v.symbol));
    const paramNodes = new Set((req.spareCabNodes || []).map((s) => M.idKey(s.nodeIdentifier)));
    const hwList = (req.softwareRelatedHardwares || []).filter((h) => Number(h.quantity) > 0).map((h) => Number(h.itemNumber));
    if (bl) {
      for (const def of D().defsForContext(bl.contextId).filter((d) => d.cab)) {
        if (!D().conditionMet(def, symbols) || bl.ntps[def.key] === undefined) continue;
        const idx = bl.ntps[def.key];
        const old = target.nodes.find((x) => D().findDef(x.nodeIdentifier) === def);
        const newHw = def.hw.find((h) => hwList.includes(h));
        const nn = D().buildNode(def, idx, { hw: newHw || (old && old.ecuHardware && old.ecuHardware.number) });
        if (!def.versions[idx].hardware.includes(Number(nn.ecuHardware.number))) errors.push(warn(`${nn.name}: hardware ${nn.ecuHardware.number} is not supported by baseline version ${def.versions[idx].versionName}`, nn.name));
        replaceNode(target, nn);
        const oldIdx = old ? curIdx(old) : -1;
        applyParamsForVersion(target, def, oldIdx, idx, { reset: !paramNodes.has(M.idKey(nn.nodeIdentifier)) });
        releaseNotes.push(releaseNote(def, idx, 'en-GB'));
      }
      (req.removedNodes || []).forEach((pos) => {
        const n = target.nodes.find((x) => M.derivedPosition(x.nodeIdentifier) === pos);
        if (n && !n.isCabNode) target.nodes = target.nodes.filter((x) => x !== n);
      });
      if (hwList.length) errors.push(info(`${hwList.length} software related hardware part(s) from the spare cab order were used.`));
    }
    return [finishResponse(src, target, errors, { releaseNotes })];
  }

  // ---------- available updates ----------
  function availableUpdates(req) {
    if (!(req.products || []).length) throw new Error('The request does not contain any product');
    const types = (req.actionCriteriaTypes || []).length ? req.actionCriteriaTypes : E.ActionCriteria.map((a) => a[0]);
    const scenario = req.scenario || E.Scenario.Introduced;
    const out = req.products.map((product) => {
      const { src } = prepare(product);
      const chassis = M.chassisOf(src);
      const pc = src.productSpecification.productInformation.productClassId;
      const ctx = src.productSpecification.productInformation.context;
      const reqNodes = requestedFor(req, chassis);
      const nodes = reqNodes.length ? src.nodes.filter((n) => reqNodes.some((r) => M.idMatch(r.nodeIdentifier, n.nodeIdentifier))) : src.nodes;
      const ntpInfo = (def, idx) => (idx < 0 ? null : { documentNumber: def.versions[idx].doc, versionName: def.versions[idx].versionName, status: def.versions[idx].status, remoteCapable: def.versions[idx].remoteCapable });
      const criterias = types.map((t) => {
        const name = E.actionCriteriaString(t);
        const remote = [3, 4, 5, 7, 8, 9].includes(t);
        const entry = { actionCriteriaType: name };
        if (t === 1) entry.currentSoftware = nodes.map((n) => { const def = D().findDef(n.nodeIdentifier); return { node: n.name, nodeTemplate: def ? ntpInfo(def, curIdx(n)) : null, ecuHardware: n.ecuHardware && n.ecuHardware.number }; });
        else if (t <= 9) {
          const sp = t >= 6 ? latestServicePack(ctx && ctx.id) : null;
          entry.softwareReplacements = nodes.map((n) => {
            const def = D().findDef(n.nodeIdentifier);
            if (!def) return null;
            const cur = curIdx(n);
            let idx;
            if (sp) idx = sp.ntps[def.key] !== undefined ? sp.ntps[def.key] : -1;
            else idx = pickVersion(def, n, { scenario, remote, pblCapable: req.pblUpdateCapable }).idx;
            if (idx < 0 || idx <= cur || (remote && !def.versions[idx].remoteCapable)) return null;
            return { node: n.name, currentNodeTemplate: ntpInfo(def, cur), availableNodeTemplate: ntpInfo(def, idx), servicePack: sp ? sp.name : undefined, remoteAvailability: remote ? E.RemoteNames[t === 3 || t === 7 ? 1 : t === 4 || t === 8 ? 2 : 3] : undefined };
          }).filter(Boolean);
          if (req.enableMultiNodeBehavior) entry.multiNodeBehavior = true;
        } else if (t === 10) {
          entry.hardwareReplacements = nodes.map((n) => {
            const def = D().findDef(n.nodeIdentifier);
            if (!def) return null;
            const r = pickVersion(def, n, { scenario });
            const hw = Number(n.ecuHardware && n.ecuHardware.number);
            if (!r.blockedByHw || r.blockedByHw.idx <= Math.max(r.idx, curIdx(n))) return null;
            return { node: n.name, currentHardware: hw, replacementHardware: r.blockedByHw.hardware.filter((h) => h !== hw), enablesNodeTemplate: ntpInfo(def, r.blockedByHw.idx) };
          }).filter(Boolean);
        } else if (t === 11) {
          const have = new Set(src.productSpecification.variants.map((v) => v.idVar6));
          entry.displayLanguages = D().variants.filter((v) => v.familyId === 'LNG' && !have.has(v.idVar6) && v.authorizedProductClasses.includes(pc)).map((v) => ({ symbol: v.symbol, description: v.description }));
        } else {
          const kits = TR.server.state.kits.filter((k) => k.productClasses.includes(pc) && ['Released', 'Introduced'].includes(k.state));
          let list = [];
          if (t === 12) list = kits.filter((k) => !k.isServiceKit && !k.isCampaignKit);
          else if (t === 13) list = kits.filter((k) => k.isServiceKit);
          else if (t === 14) list = kits.filter((k) => k.isCampaignKit);
          entry.kits = list.map((k) => ({ partNumber: k.partNumber, name: k.name, state: k.state }));
        }
        return entry;
      });
      return { chassisSeries: chassis.chassisSeries, chassisNumber: chassis.chassisNumber, scenario: E.ScenarioNames[scenario], languageCode: req.selectedLanguageCode || 'en-GB', pblUpdateCapable: !!req.pblUpdateCapable, actionCriterias: criterias };
    });
    return { dataArea: JSON.stringify({ AvailableUpdatesResponse: { generatedAt: new Date().toISOString(), products: out } }) };
  }

  // ---------- breakdowns ----------
  function sourceFor(def, symbols, blName, partNumber) {
    return {
      condition: def.condition ? { type: E.ConditionType.Variant, variants: def.condition.filter((s) => symbols.has(s)) } : { type: E.ConditionType.AlwaysMatch },
      itemNumber: String(8100000 + def.index * 10), demarcation: `FG ${30 + def.index}`, baseline: blName || '', link: '',
      linkReferences: [{ entityName: 'Part', values: { PartNumber: String(partNumber || '') } }], calculation: '',
    };
  }

  function breakdownBase(product) {
    const p = M.ensureShape(clone(product));
    if (p.nodes.some((n) => n.electricalArchitecture === E.EA.T3)) p.productSpecification.productInformation.electricalArchitecture = E.EA.T3;
    p.nodes = [];
    p.parameters = [];
    p.breakdownInformation = { baseline: '', notifications: [] };
    p.productSpecification.productInformation.context = null;
    p.productSpecification.productInformation.notifications = [];
    return p;
  }

  function productionBreakdown(req) {
    if (!req.product) throw new Error('The request does not contain any product');
    const p = breakdownBase(TR.server.decryptProduct(req.product));
    M.inflate(p);
    const info0 = p.productSpecification.productInformation;
    const ctx = info0.context;
    if (!ctx) throw new Error(`No context found for product class '${info0.productClassId || ''}'`);
    const week = String(req.introductionWeek || info0.introductionWeek || currentWeek()).trim();
    if (!/^\d{6}$/.test(week)) throw new Error('Introduction week must be in the format YYYYWW');
    const factory = D().factories.find((f) => f.code === String(req.assemblyFactoryCode || info0.assemblyFactoryCode || ''));
    if (!factory) throw new Error('Select a factory for the production breakdown');
    const statuses = ['released', 'introduced'].concat(req.includePreReleasedSNotes ? ['prereleaseverification'] : []);
    const symbols = new Set(p.productSpecification.variants.map((v) => v.symbol));
    const notes = p.breakdownInformation.notifications;
    notes.push({ text: `Production breakdown for week ${week} at ${factory.name} (${factory.code})`, reason: '', action: '', severity: E.Severity.Information, linkLookup: {} });
    const chosen = {};
    for (const def of D().defsForContext(ctx.id)) {
      if (!D().conditionMet(def, symbols)) continue;
      let idx = -1;
      for (let i = def.versions.length - 1; i >= 0; i--) {
        const v = def.versions[i];
        if (v.introductionWeek <= week && statuses.includes(v.status)) { idx = i; break; }
      }
      if (idx < 0) { notes.push({ text: `No released node template for ${def.name} at week ${week}`, reason: `Node ${def.description} is part of the specification but has no released version.`, action: '', severity: E.Severity.Warning, linkLookup: {} }); continue; }
      chosen[def.key] = idx;
    }
    const docs = Object.keys(chosen).map((k) => D().defByKey[k].versions[chosen[k]].doc);
    const bl = M.matchBaseline(docs);
    for (const k of Object.keys(chosen)) {
      const def = D().defByKey[k];
      const v = def.versions[chosen[k]];
      const n = D().buildNode(def, chosen[k], { source: sourceFor(def, symbols, bl && bl.name, v.msw) });
      p.nodes.push(n);
      D().buildParams(def, chosen[k], sourceFor(def, symbols, bl && bl.name, '')).forEach((x) => {
        x.source.itemNumber = String(9100000 + def.index * 10 + p.parameters.length);
        p.parameters.push(x);
      });
    }
    const lang = p.productSpecification.variants.find((v) => v.familyId === 'LNG');
    const icl = p.parameters.find((x) => x.code === 'P1ICL');
    if (lang && icl) { icl.references[0].value = lang.symbol.slice(5).toLowerCase(); icl.source.condition = { type: E.ConditionType.Variant, variants: [lang.symbol] }; }
    if (symbols.has('ADR')) p.parameters.push({ code: 'P1ADR', electricalArchitecture: 1, references: [{ code: 'VAL', value: '1' }], packaged: false, isGroupAdministrative: false, isFunction: false, valueNotVisibleToUser: false, notifications: [], source: { condition: { type: 1, variants: ['ADR'] }, itemNumber: '9199990', demarcation: 'ADR', baseline: '', link: '', linkReferences: [], calculation: '' } });
    if (req.includePreReleasedSNotes && symbols.has('LKS') && !p.productSpecification.sNotes.some((s) => s.value === 'S512345')) p.productSpecification.sNotes.push({ value: 'S512345', name: D().sNoteName('S512345'), source: { condition: { type: 1, variants: ['LKS'] } } });
    p.breakdownInformation.baseline = bl ? bl.name : '';
    info0.introductionWeek = week;
    info0.assemblyFactoryCode = factory.code;
    info0.assemblyFactory = factory.name;
    info0.baselineName = bl ? bl.name : '';
    info0.baselineGuid = bl ? bl.guid : '';
    p.nodes.sort(M.compareNodes);
    p.parameters.sort(M.compareParameters);
    M.inflate(p);
    return { product: p, baselineUrl: bl ? TR.server.baselineUrl(bl.guid) : '' };
  }

  function developmentBreakdown(req) {
    if (!req.product) throw new Error('The request does not contain any product');
    const id = String(req.baselineIdentifier || '').trim();
    if (!id) throw new Error('Enter a baseline identifier');
    const cands = D().baselines.filter((b) => b.identifier.toUpperCase() === id.toUpperCase());
    if (!cands.length) throw new Error(`Baseline '${id}' was not found`);
    const bl = cands.find((b) => b.version === req.baselineVersion) || cands[cands.length - 1];
    const p = breakdownBase(TR.server.decryptProduct(req.product));
    const symbols = new Set(p.productSpecification.variants.map((v) => (v.symbol || '').toUpperCase()));
    for (const k of Object.keys(bl.ntps)) {
      const def = D().defByKey[k];
      if (!D().conditionMet(def, symbols)) continue;
      p.nodes.push(D().buildNode(def, bl.ntps[k], { source: sourceFor(def, symbols, bl.name, def.versions[bl.ntps[k]].msw) }));
      D().buildParams(def, bl.ntps[k]).forEach((x) => p.parameters.push(x));
    }
    p.breakdownInformation.baseline = bl.name;
    p.breakdownInformation.notifications.push({ text: `Development breakdown from baseline ${bl.name} version ${bl.version}`, reason: '', action: '', severity: E.Severity.Information, linkLookup: {} });
    const info0 = p.productSpecification.productInformation;
    info0.baselineName = bl.name;
    info0.baselineGuid = bl.guid;
    M.inflate(p);
    return { product: p, baselineUrl: TR.server.baselineUrl(bl.guid) };
  }

  // ---------- compare breakdown diff tree ----------
  function leaf(key, s, t, meta) {
    let type;
    if (t === undefined) type = 'Equal';
    else if ((s === null || s === undefined || s === '') && t !== null && t !== undefined && t !== '') type = 'Remove';
    else if ((t === null || t === undefined || t === '') && s !== null && s !== undefined && s !== '') type = 'Add';
    else type = String(s === null || s === undefined ? '' : s) === String(t === null || t === undefined ? '' : t) ? 'Equal' : 'Change';
    return { key, type, source: s, target: t, meta: meta || {}, children: [] };
  }
  function group(key, children, presence, meta) {
    let type = children.every((c) => c.type === 'Equal') ? 'Equal' : 'Change';
    if (presence === 'source') type = 'Add';
    if (presence === 'target') type = 'Remove';
    return { key, type, children, meta: meta || {} };
  }
  const partText = (p) => (p ? `${p.number}${p.fieldNumber ? ` (${p.fieldNumber})` : ''}` : null);

  function diffTree(src, tgt) {
    const single = !tgt;
    const T = (x) => (single ? undefined : x);
    const si = src.productSpecification.productInformation, ti = single ? {} : tgt.productSpecification.productInformation;
    const infoKeys = ['assemblyDate', 'specificationDate', 'assemblyFactory', 'releaseFactory', 'companyCode', 'countryOfOperation', 'productClassId', 'modelId', 'chassisType', 'chassisSeries', 'chassisNumber', 'vin'];
    const fmt = (k, v) => (/Date$/.test(k) ? TR.util.fmtDate(v) : v);
    const keyed = (a, b, keyFn) => {
      const keys = uniq((a || []).map(keyFn).concat((b || []).map(keyFn)));
      return keys.map((k) => [k, (a || []).find((x) => keyFn(x) === k), (b || []).find((x) => keyFn(x) === k)]);
    };
    const presence = (s, t) => (single ? null : s && !t ? 'source' : !s && t ? 'target' : null);

    const variantsG = group('Variants', keyed(src.productSpecification.variants, single ? [] : tgt.productSpecification.variants, (v) => v.idVar6).map(([k, s, t]) =>
      leaf(s ? s.symbol : t.symbol, s ? s.description || s.symbol : null, T(t ? t.description || t.symbol : null), { variant: (s || t).symbol, sourceInfo: (s || t).source })));
    const snotesG = group('SNotes', keyed(src.productSpecification.sNotes, single ? [] : tgt.productSpecification.sNotes, (x) => x.value).map(([k, s, t]) => leaf(k, s ? s.name || k : null, T(t ? t.name || k : null))));
    const specG = group('ProductSpecification', infoKeys.map((k) => leaf(k, fmt(k, si[k]), T(fmt(k, ti[k])))).concat([variantsG, snotesG]));

    const nodesG = group('Nodes', keyed(src.nodes, single ? [] : tgt.nodes, M.nodeKey).map(([k, s, t]) => {
      const n = s || t;
      const kids = [leaf('Version', s ? s.versionName : null, T(t ? t.versionName : null))];
      M.singles(n.electricalArchitecture).forEach(([slot, , label]) => {
        const a = s && s[slot], b = t && t[slot];
        kids.push(leaf(label, partText(a), T(partText(b)), { sourceInfo: (a || b || {}).source, partNumber: (a || b || {}).number, notifications: [].concat((a && a.notifications) || []) }));
      });
      M.lists(n.electricalArchitecture).forEach(([slot, , label]) => {
        const items = keyed(s && s[slot], t && t[slot], (x) => String(x.index !== undefined && x.index !== null ? x.index : x.number));
        if (!items.length) return;
        kids.push(group(label, items.map(([ik, a, b]) => leaf(`${(a || b).name || label} [${ik}]`, partText(a), T(partText(b)), { sourceInfo: (a || b).source, partNumber: (a || b).number }))));
      });
      return group(n.name, kids, presence(s, t), { notifications: [].concat((s && s.notifications) || []).concat((t && t.notifications) || []), node: true });
    }));
    const eaGroups = [0, 1].map((ea) => {
      const a = (src.parameters || []).filter((p) => (p.electricalArchitecture || 0) === ea);
      const b = single ? [] : (tgt.parameters || []).filter((p) => (p.electricalArchitecture || 0) === ea);
      return group(E.ParamEANames[ea], keyed(a, b, (p) => p.code).map(([k, s, t]) => leaf(k, s ? M.paramValue(s) : null, T(t ? M.paramValue(t) : null), { sourceInfo: (s || t).source })));
    }).filter((g) => g.children.length);
    const paramsG = group('Parameters', eaGroups);
    const root = group(single ? M.chassisText(src) : `${M.chassisText(src)} ↔ ${M.chassisText(tgt)}`, [
      leaf('Factory', `${si.assemblyFactory || ''} (${si.assemblyFactoryCode || ''})`, T(`${ti.assemblyFactory || ''} (${ti.assemblyFactoryCode || ''})`)),
      leaf('Week', si.introductionWeek, T(ti.introductionWeek)),
      specG, nodesG, paramsG,
    ]);
    return root;
  }

  function compareBreakdown(left, right) {
    const build = (inp) => {
      if (!inp) return null;
      let spec;
      if (inp.specId) {
        const e = TR.server.edbProduct(inp.specId);
        spec = e;
      } else {
        if (!inp.chassisSeries || !inp.chassisNumber) throw new Error('Enter chassis series and number');
        spec = TR.server.findVda({ chassisSeries: inp.chassisSeries, chassisNumber: inp.chassisNumber });
        if (!spec) throw new Error(`Chassis ${inp.chassisSeries} ${inp.chassisNumber} not found in VDA`);
        spec = clone(spec);
      }
      const add = (inp.variantsToAdd || []).map((v) => D().variantBySymbol(v.symbol || v)).filter(Boolean);
      const missing = (inp.variantsToAdd || []).filter((v) => !D().variantBySymbol(v.symbol || v));
      if (missing.length) throw new Error(`Unknown variant(s): ${missing.map((v) => v.symbol || v).join(', ')}`);
      add.forEach((v) => { spec.productSpecification.variants.push(v); });
      normalizeFamilies(spec, add);
      const week = inp.overriddenSpecWeek || spec.productSpecification.productInformation.introductionWeek;
      return productionBreakdown({ product: spec, assemblyFactoryCode: spec.productSpecification.productInformation.assemblyFactoryCode, introductionWeek: week, includePreReleasedSNotes: false }).product;
    };
    const s = build(left);
    const t = build(right);
    return { sourceProduct: s, targetProduct: t, diff: diffTree(s, t) };
  }

  // ---------- legacy VCADS ----------
  function vcads(params) {
    const errors = [];
    const series = String(params.chassisSeries || '').trim();
    const number = String(params.chassisNumber || '').trim();
    if (!series) errors.push('You must specify Chassis Series.');
    if (!number) errors.push('You must specify Chassis Number.');
    else if (!/^\d+$/.test(number)) errors.push('Chassis Number must be a numeric value.');
    const midText = String(params.mid || '').trim();
    if (midText && !/^\d+$/.test(midText)) errors.push('Mid Number must be a numeric value.');
    const type = Number(params.requestType);
    const ck = Number(params.ck || 0);
    if (type === E.TypeOfRequest.ConversionKit && !ck) errors.push('You must specify Conversion Kit Number.');
    if (errors.length) return { success: false, errors, item: null };
    const vda = TR.server.findVda({ chassisSeries: series, chassisNumber: number });
    if (!vda) return { success: false, errors: [`Vehicle ${series} ${number} was not found.`], item: null };
    const p = M.inflate(clone(vda));
    const pi = p.productSpecification.productInformation;
    const mid = midText ? Number(midText) : 0;
    const prefix = pi.companyCode && pi.companyCode[0] === 'P' ? 'VOP' : pi.companyCode && pi.companyCode[0] === 'C' ? 'VOE' : 'VO';
    const comps = [];
    p.nodes.forEach((n) => {
      const m = n.nodeIdentifier.mid;
      const add = (item, part, field) => { if (part) comps.push({ mid: m, item, part: `${field || part.fieldNumber || part.index || 0}/${part.number}` }); };
      add('ECU', n.ecuHardware, 'HW');
      add('NTP', n.nodeTemplateDocument, 'NTP');
      M.singles(n.electricalArchitecture).slice(2).forEach(([k, , , cap]) => add(cap, n[k]));
      M.lists(n.electricalArchitecture).forEach(([k, , , cap]) => (n[k] || []).forEach((x) => add(cap, x)));
    });
    const mids = uniq(comps.map((c) => c.mid)).sort((a, b) => a - b);
    const completeVehicle = {
      assemblyDate: TR.util.fmtDate(pi.assemblyDate), chassisNumber: pi.chassisNumber, chassisSeries: pi.chassisSeries, countryCode: pi.countryOfOperation, model: pi.modelId,
      parameters: p.parameters.map((x) => `${x.code}=${TR.server.isHiddenParam(x) ? 'N/A' : M.paramValue(x)}`),
      parts: mids.map((m) => ({ mid: m, components: uniq(comps.filter((c) => c.mid === m).map((c) => c.item)).map((it) => ({ item: it, parts: comps.filter((c) => c.mid === m && c.item === it).map((c) => c.part) })) })),
      snotes: p.productSpecification.sNotes.map((s) => s.value),
      variants: p.productSpecification.variants.map((v) => v.symbol || v.idVar6).sort(),
    };
    const workflowList = [];
    const stepFromDelta = (delta, kitNo) => {
      const st = { affectedMids: [], parameterOperations: [], partOperations: [], variantOperations: [], sNoteOperation: [], actualKitPartNumber: kitNo || 0 };
      (delta.nodes || []).forEach((o) => {
        const n = o.value;
        if (!n) return;
        st.affectedMids.push(n.nodeIdentifier.mid);
        const old = p.nodes.find((x) => M.idMatch(x.nodeIdentifier, n.nodeIdentifier));
        M.singles(n.electricalArchitecture).forEach(([k, T, , cap]) => { if (!old || !M.partsEqual(n[k], old[k], T)) if (n[k]) st.partOperations.push(`${old && old[k] ? 'Replace' : 'Add'} ${cap} ${n[k].fieldNumber || ''}/${n[k].number}`.replace(' /', ' ')); });
        M.lists(n.electricalArchitecture).forEach(([k, , , cap]) => (n[k] || []).forEach((x) => { if (!old || !(old[k] || []).some((y) => y.number === x.number)) st.partOperations.push(`Add ${cap} ${x.fieldNumber || x.index}/${x.number}`); }));
      });
      (delta.parameters || []).forEach((o) => st.parameterOperations.push(`${o.type === E.Op.AssignParameter ? 'Set' : 'Remove'} ${o.value.code}=${TR.server.isHiddenParam(o.value) ? 'N/A' : M.paramValue(o.value)}`));
      ((delta.productSpecification || {}).variants || []).forEach((o) => st.variantOperations.push(`${o.type === E.Op.AssignVariant ? 'Add' : 'Remove'} ${o.value.symbol}`));
      ((delta.productSpecification || {}).sNotes || []).forEach((o) => st.sNoteOperation.push(`${o.type === E.Op.AssignSNote ? 'Add' : 'Remove'} ${o.value.value}`));
      st.affectedMids = uniq(st.affectedMids);
      return st;
    };
    const ecus = p.nodes.filter((n) => !mid || Number(n.nodeIdentifier.mid) === mid).sort((a, b) => a.nodeIdentifier.mid - b.nodeIdentifier.mid);
    if (mid && !ecus.length) return { success: false, errors: [`No ECU with MID ${mid} found in the vehicle.`], item: null };
    if (type === E.TypeOfRequest.Software) {
      ecus.forEach((n) => {
        const r = softwareForProduct(vda, { requestedNodes: [{ nodeIdentifier: n.nodeIdentifier }], softwareRequestOperation: 3, scenario: E.Scenario.Released, enableMultiNodeBehavior: false, pblUpdateCapable: true });
        const st = stepFromDelta(r.delta);
        if (st.partOperations.length || st.parameterOperations.length) workflowList.push({ workflow: '(Steps 1)', mid: n.nodeIdentifier.mid, steps: [st] });
      });
    } else if (type === E.TypeOfRequest.Hardware) {
      ecus.forEach((n) => {
        const def = D().findDef(n.nodeIdentifier);
        if (!def) return;
        const r = pickVersion(def, n, { scenario: E.Scenario.Released });
        const hw = Number(n.ecuHardware && n.ecuHardware.number);
        const latest = def.versions.filter((v) => v.status === 'released').pop();
        if (latest && !latest.hardware.includes(hw)) {
          workflowList.push({ workflow: '(Steps 1)', mid: n.nodeIdentifier.mid, steps: [{ affectedMids: [n.nodeIdentifier.mid], parameterOperations: [], partOperations: [`Replace ECU HW/${hw} -> HW/${latest.hardware[latest.hardware.length - 1]}`], variantOperations: [], sNoteOperation: [], actualKitPartNumber: 0 }] });
        } else if (r.blockedByHw) {
          workflowList.push({ workflow: '(Steps 1)', mid: n.nodeIdentifier.mid, steps: [{ affectedMids: [n.nodeIdentifier.mid], parameterOperations: [], partOperations: [`Optional: Replace ECU HW/${hw} -> HW/${r.blockedByHw.hardware[0]} to enable ${r.blockedByHw.versionName}`], variantOperations: [], sNoteOperation: [], actualKitPartNumber: 0 }] });
        }
      });
    } else if (type === E.TypeOfRequest.ConversionKit) {
      const kit = findKit(ck);
      if (!kit) return { success: false, errors: [`Conversion kit ${ck} does not exist.`], item: null };
      const r = kitForProduct(vda, { conversionKitNumbers: [{ conversionKitNumber: String(ck) }], scenario: 2, pblUpdateCapable: true });
      if (r.errorReport && r.errorReport.errors.some((e) => e.severity === 0)) return { success: false, errors: r.errorReport.errors.filter((e) => e.severity === 0).map((e) => e.text), item: null };
      workflowList.push({ workflow: '(Steps 1)', steps: [stepFromDelta(r.delta, kit.partNumber)] });
    }
    workflowList.forEach((w) => { w.workflow = `(Steps ${w.steps.length})`; });
    return { success: true, errors: [], item: { completeVehicle, workflowList, namsRequest: !!params.namsRequest, typeOfCamsRequest: ['', 'SoftwareRequest', 'HardwareRequest', 'ConversionKitRequest'][type] || '' } };
  }

  TR.engine = { softwareRequest, kitRequest, spareCabRequest, availableUpdates, productionBreakdown, developmentBreakdown, compareBreakdown, diffTree, vcads, findKit, pickVersion, curIdx, latestServicePack, normalizeFamilies, SCENARIO_STATUSES };
})();
