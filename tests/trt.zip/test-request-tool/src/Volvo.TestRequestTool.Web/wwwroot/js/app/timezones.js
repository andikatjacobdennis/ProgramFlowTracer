/* Other time zones, wherever a time is shown.
 *
 *   – Hover over or focus any time (a <time datetime> element) to see that moment in your other time zones: yours first,
 *     then UTC, your quick-switch cultures and any zones you added, each with its offset from you and "next day" hints.
 *   – Click it (or press Enter) to pin the card; Esc or a click elsewhere closes it.
 *   – The clock in the status bar opens the same card for "now", live.
 *   – Settings → Language and region → Other time zones adds or removes zones.
 *
 *   TR.timezones.zones()        – the zones to show: [{ tz, label, country }]
 *   TR.timezones.rows(date)     – one row per zone: { tz, label, text, diff, day } (used by the card and the tests) */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => TR.i18n.t(s, v);
  const C = () => TR.culture;
  const Z = { card: null, pinned: false, timer: null, anchor: null };

  const city = (tz) => (tz === 'UTC' ? 'UTC' : tz.split('/').pop().replace(/_/g, ' '));
  const countryOf = (tz) => (C().COUNTRIES.find((c) => c.timeZones.includes(tz)) || {}).code || '';
  function zones() {
    const me = C().active(), list = [{ tz: me.timeZone, label: t('Your time'), country: me.country, you: true }];
    const add = (tz, label, country) => { if (tz && !list.some((z) => z.tz === tz)) list.push({ tz, label: label || city(tz), country: country ?? countryOf(tz) }); };
    add('UTC', 'UTC', '');
    for (const p of C().quick()) add(p.timeZone, `${city(p.timeZone)} · ${C().countryName(p.country)}`, p.country);
    for (const tz of TR.prefs.get('worldClocks') || []) add(tz);
    return list;
  }
  /**
   * The zones shown together (status bar, and beside times when that is on): yours first, then your Other time zones in
   * the order you added them, then your quick-switch cultures, then UTC; as many as Settings → Time zones shown together.
   */
  function shown() {
    const me = C().active(), limit = Math.max(1, Math.min(4, Number(TR.prefs.get('clocksShown')) || 1));
    const list = [{ tz: me.timeZone, country: me.country, you: true }];
    const add = (tz, country) => { if (tz && list.length < limit && !list.some((z) => z.tz === tz)) list.push({ tz, country: country ?? countryOf(tz) }); };
    for (const tz of TR.prefs.get('worldClocks') || []) add(tz);
    for (const p of C().quick()) add(p.timeZone, p.country);
    add('UTC', '');
    return list.map((z) => Object.assign(z, { abbr: C().zoneName({ timeZone: z.tz, language: me.language, country: z.country }) }));
  }
  /** A time in one zone, in your language and clock style. */
  const timeIn = (date, z) => C().format.time(date, Object.assign({}, C().active(), { timeZone: z.tz }));

  /** Minutes east of UTC for a zone at a moment. */
  function offsetMinutes(tz, date) {
    try {
      const parts = Object.fromEntries(new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }).formatToParts(date).map((p) => [p.type, p.value]));
      const asUtc = Date.UTC(+parts.year, +parts.month - 1, +parts.day, +parts.hour % 24, +parts.minute);
      return Math.round((asUtc - Math.floor(date.getTime() / 60000) * 60000) / 60000);
    } catch (e) { return 0; }
  }
  const dayKey = (tz, date) => { try { return new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(date); } catch (e) { return ''; } };
  function rows(value) {
    const date = value instanceof Date ? value : new Date(value);
    const me = C().active(), mine = offsetMinutes(me.timeZone, date), myDay = dayKey(me.timeZone, date);
    return zones().map((z) => {
      const profile = Object.assign({}, me, { timeZone: z.tz });
      const diff = offsetMinutes(z.tz, date) - mine, d = dayKey(z.tz, date);
      const hrs = Math.trunc(Math.abs(diff) / 60), mins = Math.abs(diff) % 60;
      return {
        tz: z.tz, label: z.label, country: z.country, you: !!z.you,
        text: C().format.dateTime(date, profile),
        diff: diff === 0 ? (z.you ? '' : t('same time')) : `${diff > 0 ? '+' : '−'}${hrs}h${mins ? ' ' + mins + 'm' : ''}`,
        day: d > myDay ? t('next day') : d < myDay ? t('previous day') : '',
      };
    });
  }
  function relative(date) {
    const s = (Date.now() - date.getTime()) / 1000, abs = Math.abs(s);
    let rtf; try { rtf = new Intl.RelativeTimeFormat(TR.i18n.lang() !== 'en' && TR.i18n.locale ? TR.i18n.locale() : C().active().language, { numeric: 'auto' }); } catch (e) { return ''; }
    const [v, unit] = abs < 60 ? [s, 'second'] : abs < 3600 ? [s / 60, 'minute'] : abs < 86400 ? [s / 3600, 'hour'] : abs < 86400 * 45 ? [s / 86400, 'day'] : abs < 86400 * 540 ? [s / (86400 * 30), 'month'] : [s / (86400 * 365), 'year'];
    return rtf.format(-Math.round(v), unit);
  }

  // ------------------------------------------------------------------ the card
  function cardView(date, live) {
    return h('div', { class: ['tz-card', Z.pinned ? 'is-pinned' : ''], role: Z.pinned ? 'dialog' : 'tooltip', 'aria-label': t('Time in other time zones') },
      h('div', { class: 'tz-head' }, h('strong', null, live ? t('World clock') : t('In other time zones')), h('span', { class: 'muted' }, live ? '' : relative(date))),
      h('ul', { class: 'tz-rows' }, rows(date).map((r) => h('li', { class: r.you ? 'is-you' : '' },
        C().flag(r.country, 18), h('span', { class: 'tz-label' }, r.label), h('span', { class: 'tz-text' }, r.text),
        h('span', { class: 'tz-diff' }, [r.diff, r.day].filter(Boolean).join(' · '))))),
      h('div', { class: 'tz-foot' }, Z.pinned ? h('button', { class: 's-btn text', onClick: () => { close(); TR.pages.show('settings'); setTimeout(() => document.querySelector('[data-setting=worldClocks]')?.scrollIntoView({ block: 'center' }), 0); } }, TR.icon('settings', 14), t('Add or remove time zones')) : h('span', { class: 'muted' }, t('Click to pin · Settings adds more zones'))));
  }
  function place(anchor) {
    const r = anchor.getBoundingClientRect(), w = Z.card.offsetWidth, hh = Z.card.offsetHeight;
    Z.card.style.left = Math.min(Math.max(8, r.left), window.innerWidth - w - 8) + 'px';
    Z.card.style.top = (r.bottom + 8 + hh > window.innerHeight ? Math.max(8, r.top - hh - 8) : r.bottom + 8) + 'px';
  }
  function show(anchor, pinned, live) {
    const iso = anchor.getAttribute('datetime');
    const date = live ? new Date() : new Date(iso);
    if (!live && isNaN(date)) return;
    close();
    Z.pinned = !!pinned; Z.anchor = anchor;
    Z.card = cardView(date, live);
    document.body.appendChild(Z.card);
    place(anchor);
    if (live) Z.live = setInterval(() => { if (Z.card) { const n = cardView(new Date(), true); Z.card.replaceWith(n); Z.card = n; place(anchor); } }, 15000);
  }
  function close() { clearTimeout(Z.timer); clearInterval(Z.live); if (Z.card) { Z.card.remove(); Z.card = null; } Z.pinned = false; Z.anchor = null; }
  const timeOf = (el) => el && el.closest && el.closest('time[datetime], .ap-clock');
  if (typeof document.addEventListener === 'function') {
    document.addEventListener('mouseover', (e) => { const el = timeOf(e.target); if (!el || Z.pinned) return; clearTimeout(Z.timer); Z.timer = setTimeout(() => show(el, false, el.classList.contains('ap-clock')), 400); });
    document.addEventListener('mouseout', (e) => { if (timeOf(e.target) && !Z.pinned) { clearTimeout(Z.timer); close(); } });
    document.addEventListener('focusin', (e) => { const el = timeOf(e.target); if (el && !Z.pinned) show(el, false, el.classList.contains('ap-clock')); });
    document.addEventListener('focusout', (e) => { if (timeOf(e.target) && !Z.pinned) close(); });
    document.addEventListener('click', (e) => {
      const el = timeOf(e.target);
      if (el) { e.preventDefault(); e.stopPropagation(); show(el, true, el.classList.contains('ap-clock')); return; }
      if (Z.pinned && Z.card && !Z.card.contains(e.target)) close();
    }, true);
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && Z.card) close();
      const el = timeOf(e.target); if (el && (e.key === 'Enter' || e.key === ' ')) { e.preventDefault(); show(el, true, el.classList.contains('ap-clock')); }
    });
    document.addEventListener('scroll', () => { if (!Z.pinned) close(); }, true);
  }
  // Times become reachable with the keyboard, and show a dotted underline so users know there is more.
  if (typeof MutationObserver === 'function' && typeof document.body !== 'undefined' && document.body) {
    const mark = () => {
      document.querySelectorAll('time[datetime]:not([tabindex]), .ap-clock:not([tabindex])').forEach((el) => { el.setAttribute('tabindex', '0'); el.classList.add('tz-time'); });
      // Beside times on pages: the other zones you chose, small and quiet ("· 07:27 CET"). Each time element is done once.
      if (!TR.prefs.get('inlineZones')) return;
      const extra = shown().slice(1);
      if (!extra.length) return;
      document.querySelectorAll('time[datetime]:not([data-tz-inline])').forEach((el) => {
        el.setAttribute('data-tz-inline', '1');
        const d = new Date(el.getAttribute('datetime'));
        if (isNaN(d)) return;
        el.after(...extra.map((z) => h('small', { class: 'tz-inline', 'aria-label': z.abbr + ' ' + timeIn(d, z) }, '· ' + timeIn(d, z) + ' ' + z.abbr)));
      });
    };
    new MutationObserver(mark).observe(document.body, { childList: true, subtree: true });
    mark();
  }

  TR.timezones = { zones, shown, timeIn, rows, offsetMinutes, relative, close };
})();
