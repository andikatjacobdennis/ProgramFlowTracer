/* Command palette (Ctrl+K): find any page, action, vehicle, setting, Help article or scenario and open it with Enter.
 *
 * Ranking is local machine learning (ml.js), no AI service:
 *   – fuzzy matching on the name, group and keywords, so a few letters are enough ("dsh" finds Dashboard);
 *   – frecency: what you use often and recently comes first;
 *   – a Markov chain of what you usually do after the current page, shown as "Next for you" before you type;
 *   – favourites you star stay at the top.
 * Everything learned stays in this browser. Settings → Privacy and data → "Forget what the palette learned" clears it. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => TR.i18n.t(s, v);
  const P = { open: false, query: '', index: 0, el: null, vehicles: null, lastPage: null };
  const MAX = 22;
  const use = TR.ml.frecency('palette'), next = TR.ml.markov('pages');
  const favKey = () => 'trstudio.' + ((TR.backend && TR.backend.session && TR.backend.session.userId) || 'user') + '.palette.favourites';
  const favourites = () => TR.util.store.get(favKey(), []) || [];
  const toggleFav = (id) => { const f = favourites(); TR.util.store.set(favKey(), f.includes(id) ? f.filter((x) => x !== id) : f.concat(id)); draw(); };

  // ------------------------------------------------------------------ what can be found
  const L = () => TR.app.shell.left;
  const page = (id, label, icon, keywords = '') => ({ id: 'page:' + id, group: 'Go to', label, icon, keywords, run: () => (id === 'testrequest' ? TR.testRequest.page() : id === 'twopane' ? TR.testRequest.expert() : id === 'compare' || id === 'vcads' ? (TR.experience.page = null, TR.app.navigate(id)) : TR.pages.show(id)) });
  async function vehicles() {
    if (P.vehicles) return;
    P.vehicles = [];
    try { P.vehicles = (await TR.pages.ui.api('/vehicles')).map((v) => v.product.productSpecification.productInformation); } catch (e) { P.vehicles = []; }
    if (P.open) draw();
  }
  function items() {
    const list = [
      page('home', t('Home'), 'grid', 'start workspace'), page('dashboard', t('Dashboard'), 'chart', 'fleet overview kpi'), page('vehicle', t('Vehicle'), 'map', 'graph roadmap history insights'),
      page('testrequest', t('Test request'), 'grid', 'configure validate review'), page('twopane', t('Two-pane workbench'), 'compare', 'expert legacy'), page('activity', t('Activity'), 'clock', 'requests history'),
      page('library', t('Saved vehicles'), 'bookmark', 'bookmarks recent'), page('settings', t('Settings'), 'settings', 'preferences options'), page('help', t('Help'), 'help', 'support faq'),
      page('about', t('About'), 'info', 'version'), page('compare', t('Compare breakdown'), 'layers', 'specification diff'), page('vcads', t('VCADS request'), 'file', 'vcads'),
      { id: 'act:add', group: 'Actions', label: t('Add a vehicle'), icon: 'plus', keywords: 'load open vda vin', run: () => { TR.experience.page = null; TR.testRequest.intake(); } },
      { id: 'act:next', group: 'Actions', label: t('Do the next step') + ' · ' + t(TR.nextStep().label), icon: 'arrow', keywords: 'next continue', run: () => TR.nextStep().run() },
      { id: 'act:theme', group: 'Actions', label: t('Switch theme'), icon: 'sun', keywords: 'dark light auto', run: () => TR.pages.cycleTheme() },
      { id: 'act:motion', group: 'Actions', label: TR.prefs.get('motion') === 'off' ? t('Turn motion on') : t('Turn motion off'), icon: 'motion', keywords: 'animation', run: () => TR.prefs.set('motion', TR.prefs.get('motion') === 'off' ? 'on' : 'off') },
      { id: 'act:tour', group: 'Actions', label: t('Start the introduction tour'), icon: 'play', keywords: 'tutorial wizard walkthrough guide voice', run: () => TR.tour.start() },
      { id: 'act:guide', group: 'Actions', label: t('Choose your guide'), icon: 'people', keywords: 'persona character welcome', run: () => TR.welcome.show() },
      { id: 'act:shortcuts', group: 'Actions', label: t('Show keyboard shortcuts'), icon: 'grid', keywords: 'keys hotkeys', run: () => TR.shortcuts.show() },
      { id: 'act:feedback', group: 'Actions', label: t('Send feedback'), icon: 'people', keywords: 'idea praise support', run: () => TR.feedback.open() },
      { id: 'act:problem', group: 'Actions', label: t('Report a problem'), icon: 'alert', keywords: 'bug issue support', run: () => TR.feedback.open('Problem') },
      { id: 'act:notifications', group: 'Actions', label: t('Show notifications'), icon: 'bell', keywords: 'toast messages', run: () => TR.notify && TR.notify.panel() },
    ];
    if (L() && L().product.loaded()) ['graph', 'roadmap', 'history', 'insights'].forEach((tab, i) => list.push({ id: 'tab:' + tab, group: 'Vehicle', label: `${L().product.chassisString()} › ${t(tab[0].toUpperCase() + tab.slice(1))}`, icon: ['map', 'route', 'history', 'chart'][i], keywords: tab, run: () => { TR.pages.show('vehicle'); TR.vehiclePage.V.tab = tab; TR.app.refresh(); } }));
    for (const c of TR.culture.choices()) list.push({ id: 'culture:' + TR.culture.keyOf(c.profile) + c.id, group: 'Culture', label: t('Switch culture to {name}', { name: (c.label ? t(c.label) + ' · ' : '') + TR.culture.countryName(c.profile.country) }), icon: 'globe', keywords: 'language time zone ' + c.profile.language, run: () => TR.culture.select(c) });
    for (const v of P.vehicles || []) list.push({ id: `veh:${v.chassisSeries}|${v.chassisNumber}`, group: 'Vehicles', label: `${t('Load')} ${v.chassisSeries} ${v.chassisNumber}`, hint: v.modelId, icon: 'truck', keywords: `${v.vin} ${v.modelId} ${v.productClassId}`,
      run: async () => { Object.assign(L().src, { series: v.chassisSeries, number: v.chassisNumber }); await L().loadFromSource(false); TR.pages.show('vehicle'); } });
    for (const s of TR.settingsPage.SETTINGS) list.push({ id: 'set:' + s.id, group: 'Settings', label: t(s.title), icon: 'settings', keywords: s.keywords, run: () => { TR.pages.show('settings'); TR.settingsPage.state.query = t(s.title); TR.app.refresh(); } });
    for (const a of TR.helpContent.ARTICLES) list.push({ id: 'help:' + a.id, group: a.topic === 'scenarios' ? 'Scenarios' : 'Help', label: t(a.title), hint: a.scenario ? `${t(a.scenario.level)} · ${a.scenario.minutes} min` : null, icon: a.topic === 'scenarios' ? 'route' : 'help', keywords: a.keywords + ' ' + a.summary, run: () => TR.help.open(a.id) });
    return list;
  }

  /** Ranked results: favourites, then by fuzzy match blended with how much you use each item. */
  function rank(query) {
    const all = items(), favs = favourites(), q = query.trim();
    if (!q) {
      const here = TR.pages.current() || TR.app.page;
      const byId = Object.fromEntries(all.map((x) => [x.id, x]));
      const out = [], seen = new Set(), take = (x, section) => { if (x && !seen.has(x.id)) { seen.add(x.id); out.push(Object.assign({}, x, { section })); } };
      favs.forEach((id) => take(byId[id], 'Favourites'));
      next.predict(here, 3).forEach((p) => take(byId[p.id], 'Next for you'));
      use.top(6).forEach((id) => take(byId[id], 'Recent'));
      ['act:next', 'page:dashboard', 'act:add', 'act:tour', 'page:help', 'act:feedback'].forEach((id) => take(byId[id], 'Suggested'));
      return out.slice(0, MAX);
    }
    return all.map((x) => {
      const s = Math.max(TR.ml.fuzzy(q, x.label) * 1.4, TR.ml.fuzzy(q, `${t(x.group)} ${x.label}`), TR.ml.fuzzy(q, x.keywords || '') * 0.7);
      return s > 0 ? Object.assign({}, x, { score: s + 0.12 * Math.log1p(use.score(x.id)) + (favs.includes(x.id) ? 0.3 : 0) }) : null;
    }).filter(Boolean).sort((a, b) => b.score - a.score).slice(0, MAX);
  }

  // ------------------------------------------------------------------ the overlay
  function run(x) {
    if (!x) return;
    use.use(x.id);
    next.step(TR.pages.current() || TR.app.page, x.id);
    close();
    Promise.resolve().then(() => x.run());
  }
  function draw() {
    if (!P.el) return;
    const results = rank(P.query);
    P.index = Math.min(P.index, Math.max(0, results.length - 1));
    const list = P.el.querySelector('.pl-list');
    list.replaceChildren(...(results.length ? results.map((x, i) => [
      x.section && (i === 0 || results[i - 1].section !== x.section) ? h('li', { class: 'pl-section', role: 'presentation' }, t(x.section)) : null,
      h('li', { class: ['pl-item', i === P.index ? 'is-on' : ''], role: 'option', id: 'pl-' + i, 'aria-selected': String(i === P.index), onMousemove: () => { if (P.index !== i) { P.index = i; draw(); } }, onClick: () => run(x) },
        h('span', { class: 'pl-icon' }, TR.icon(x.icon || 'arrow', 16)),
        h('span', { class: 'pl-text' }, h('small', null, t(x.group)), h('span', null, x.label)), x.hint ? h('span', { class: 'pl-hint' }, x.hint) : null,
        h('button', { class: ['pl-star', favourites().includes(x.id) ? 'is-on' : ''], 'aria-label': favourites().includes(x.id) ? t('Remove from favourites') : t('Add to favourites'), title: t('Favourite'), onClick: (e) => { e.stopPropagation(); toggleFav(x.id); } }, '★')),
    ]).flat().filter(Boolean) : [h('li', { class: 'pl-empty' }, t('Nothing found. Try fewer letters, or search Help.'), ' ', h('button', { class: 's-btn text', onClick: () => { const q = P.query; close(); TR.help.search(q); } }, t('Search Help for “{q}”', { q: P.query })))]));
    P.el.querySelector('input').setAttribute('aria-activedescendant', 'pl-' + P.index);
    list.querySelector('.is-on')?.scrollIntoView({ block: 'nearest' });
    P.results = results;
  }
  function onKey(e) {
    if (!P.open) return;
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); }
    else if (e.key === 'ArrowDown') { e.preventDefault(); P.index = Math.min((P.results || []).length - 1, P.index + 1); draw(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); P.index = Math.max(0, P.index - 1); draw(); }
    else if (e.key === 'Enter') { e.preventDefault(); run((P.results || [])[P.index]); }
  }
  function open(query = '') {
    if (P.open || !document.body) return;
    P.open = true; P.query = query; P.index = 0;
    vehicles();
    P.el = h('div', { class: 'pl-layer', onMousedown: (e) => { if (e.target === P.el) close(); } },
      h('div', { class: 'pl-box', role: 'dialog', 'aria-modal': 'true', 'aria-label': t('Find anything') },
        h('label', { class: 'pl-search' }, TR.icon('search', 18), h('input', { type: 'search', role: 'combobox', 'aria-expanded': 'true', 'aria-controls': 'pl-list', 'aria-label': t('Find anything'), placeholder: t('Find a page, action, vehicle, setting or help…'), value: query,
          onInput: (e) => { P.query = e.target.value; P.index = 0; draw(); } }), h('kbd', null, 'Esc')),
        h('ul', { class: 'pl-list', id: 'pl-list', role: 'listbox' }),
        h('div', { class: 'pl-foot' }, h('span', null, h('kbd', null, '↑'), h('kbd', null, '↓'), ' ', t('move')), h('span', null, h('kbd', null, 'Enter'), ' ', t('open')), h('span', null, '★ ', t('favourite')), h('span', { class: 'pl-learn' }, t('Learns what you use, in this browser only')))));
    document.body.appendChild(P.el);
    document.addEventListener('keydown', onKey, true);
    draw();
    setTimeout(() => P.el && P.el.querySelector('input').focus(), 0);
  }
  function close() { if (!P.open) return; P.open = false; document.removeEventListener('keydown', onKey, true); if (P.el) P.el.remove(); P.el = null; }

  // Learn page-to-page habits as the user moves around (the top bar renders on every screen).
  TR.pages.addHeaderItem(() => {
    const here = TR.pages.current() || TR.app.page;
    if (here && here !== P.lastPage) { if (P.lastPage) next.step(P.lastPage, 'page:' + here); P.lastPage = here; }
    return h('button', { class: 'ap-icon-btn ap-find', title: t('Find anything (Ctrl+K)'), 'aria-label': t('Find anything (Ctrl+K)'), onClick: () => open() }, TR.icon('search', 18));
  });
  TR.shortcuts.add({ keys: 'ctrl+k', label: 'Find anything (command palette)', run: () => open() });
  TR.shortcuts.add({ keys: 'meta+k', label: 'Find anything (command palette, Mac)', run: () => open() });
  TR.palette = { open, close, rank, items, P };
})();
