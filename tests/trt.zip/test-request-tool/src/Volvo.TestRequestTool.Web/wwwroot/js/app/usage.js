/* The usage study, in the browser (server: UsageEndpoints.cs). Records how the application is used, never what is typed or
 * shown: page views and time per page, navigation choices, journey steps, validation outcomes, errors and recoveries.
 * Event names come from a fixed vocabulary (lower-case words); the server refuses anything else.
 *
 * Off when Settings → Privacy → Usage study is off (or "Don't record" on the My data page): nothing is queued, and the
 * server is told to drop anything that still arrives. Sent in small batches every 20 s and when the page is hidden. */
(function () {
  'use strict';
  const Q = [];
  const on = () => TR.prefs && TR.prefs.get('usageStudy') !== false && (!TR.features || TR.features.on('usage-study'));
  const slug = (s) => String(s || '').toLowerCase().normalize('NFKD').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'unnamed';
  /** Record one event: kind (page, action, step, outcome, error, recover, duration), a name from the app's own labels, optional ms. */
  function track(e, k, ms) {
    if (!on()) return;
    Q.push(ms == null ? { e, k: slug(k).replace(/-/g, '.') } : { e, k: slug(k).replace(/-/g, '.'), ms: Math.round(ms) });
    if (Q.length >= 80) flush();
  }
  function flush(beacon) {
    if (!Q.length || !on() || typeof fetch !== 'function') { Q.length = 0; return; }
    const body = JSON.stringify({ events: Q.splice(0, 100) });
    if (beacon && navigator.sendBeacon) { navigator.sendBeacon('/api/v1/usage/events', new Blob([body], { type: 'application/json' })); return; }
    fetch('/api/v1/usage/events', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body, keepalive: true }).catch(() => { /* lost: the study is best effort */ });
  }
  async function setRecording(record) {
    TR.prefs.set('usageStudy', !!record);
    if (!record) Q.length = 0;
    try { await fetch('/api/v1/usage/mine/consent', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ record: !!record }) }); } catch (e) { /* the local switch already stops recording */ }
  }

  if (typeof setInterval === 'function' && typeof document.addEventListener === 'function') {
    setInterval(() => flush(false), 20000);
    document.addEventListener('visibilitychange', () => { if (document.hidden) { pageDone(); flush(true); } });
    // Navigation and menu choices, by their visible label (never by anything typed).
    document.addEventListener('click', (ev) => {
      const el = ev.target && ev.target.closest ? ev.target.closest('[data-track], .nv-item, .av-item, .wf-step-btn, .ap-next, .tp-seg button, .hl-tabs button') : null;
      if (!el) return;
      const label = el.getAttribute('data-track') || el.getAttribute('aria-label') || el.textContent;
      if (el.classList.contains('wf-step-btn')) track('step', label.split('·')[0].replace(/^\d+/, '').trim());
      else track('action', (el.classList.contains('nv-item') ? 'nav ' : el.classList.contains('ap-next') ? 'next ' : '') + label);
    }, { capture: true, passive: true });
  }
  // Page views and time on each page.
  let page = null, since = Date.now();
  function pageDone() { if (page) track('duration', page, Date.now() - since); since = Date.now(); }
  const baseFrame = TR.testRequest.frame;
  TR.testRequest.frame = (content) => {
    const frame = baseFrame(content);
    const now = (TR.pages && TR.pages.current && TR.pages.current()) || (TR.app && TR.app.page) || 'home';
    const where = now === 'testrequest' && TR.testRequest.view === 'expert' ? 'two-pane' : now;
    if (where !== page) { pageDone(); page = where; track('page', where); }
    return frame;
  };
  // Outcomes, errors and recoveries.
  const run = TR.request.runRequest;
  TR.request.runRequest = async (...args) => {
    const started = Date.now();
    try { const r = await run(...args); const f = TR.workflow && TR.workflow.facts(); if (f && f.validated) track('outcome', f.blocked ? 'validation blocked' : f.limited ? 'validation limited' : 'validation ready', Date.now() - started); return r; }
    catch (e) { track('error', 'validation'); throw e; }
  };
  if (TR.notify && TR.notify.toast) { const toast = TR.notify.toast; TR.notify.toast = (text, tone, opts) => { if (tone === 'error') track('error', 'toast'); return toast(text, tone, opts); }; }

  TR.usage = { track, flush, setRecording, recording: on, queue: Q, slug };
})();
