/* Requests: pick up your work, review others' changes and follow execution (server: /api/v1/requests/overview).
 * Every row comes from a record: your validations and queued jobs, your saved draft, and the reviews of other people you
 * may see. The status is worked out on the server (running, draft, blocked, needs revalidation, awaiting review, approved,
 * completed) and the Action column offers the next step for it. Tabs, search, filters, sorting and paging are local. */
(function () {
  'use strict';
  const { h } = TR.util;
  const J = TR.journey, t = J.t, ui = () => TR.pages.ui;
  const R = { data: null, error: null, loading: false, tab: 'all', q: '', status: '', arch: '', owner: '', sort: 'updatedAt', dir: 'desc', page: 0, size: 25, selected: null, menu: null, timer: null };

  async function load(quiet) {
    if (R.loading) return;
    R.loading = true; if (!quiet) TR.app.refresh();
    try { R.data = await J.api('/requests/overview'); R.error = null; } catch (e) { R.error = e.message; }
    R.loading = false; TR.app.refresh();
    // While something is queued or running, look again every few seconds.
    clearTimeout(R.timer);
    if (R.data && R.data.counts.running && TR.pages.current() === 'requests') R.timer = setTimeout(() => load(true), 3000);
  }

  // ------------------------------------------------------------------ filtering (exported for tests)
  // Reviews waiting on a decision: Assigned to me (explicitly yours) and Unassigned (the queue anyone may take).
  const TABS = [['all', 'All requests'], ['mine', 'My work'], ['assigned', 'Assigned to me'], ['queue', 'Unassigned'], ['completed', 'Recently completed']];
  const me = () => ((TR.backend && TR.backend.session) || {}).userId;
  function inTab(i, tab) {
    if (tab === 'mine') return i.mine && i.status !== 'completed';
    if (tab === 'assigned') return !i.mine && i.status === 'awaiting-review' && !!i.assignee && i.assignee.id === me();
    if (tab === 'queue') return !i.mine && i.status === 'awaiting-review' && !i.assignee;
    if (tab === 'completed') return i.status === 'completed';
    return true;
  }
  /** Reviews waiting on a decision: assigned to me, and unassigned (the queue). */
  const waiting = (items) => ({ assigned: items.filter((i) => inTab(i, 'assigned')).length, queue: items.filter((i) => inTab(i, 'queue')).length });
  function filter(items, f) {
    const q = (f.q || '').trim().toLowerCase();
    const list = items.filter((i) => inTab(i, f.tab) && (!f.status || i.status === f.status) && (!f.owner || i.owner.name === f.owner)
      && (!f.arch || i.vehicles.some((v) => v.architecture === f.arch))
      && (!q || [i.label, i.kind, i.owner.name, ...i.vehicles.map((v) => v.title + ' ' + String(v.id).replace('|', ''))].join(' ').toLowerCase().includes(q)));
    const key = { label: (i) => i.label, vehicle: (i) => (i.vehicles[0] || {}).title || '', status: (i) => J.state(i.status)[0], owner: (i) => i.owner.name, updatedAt: (i) => i.updatedAt }[f.sort] || ((i) => i.updatedAt);
    return list.sort((a, b) => { const x = key(a), y = key(b); return (x < y ? -1 : x > y ? 1 : 0) * (f.dir === 'asc' ? 1 : -1); });
  }

  // ------------------------------------------------------------------ actions
  async function act(i) {
    const S = TR.testRequest;
    try {
      switch (i.action) {
        case 'Review': case 'Open': case 'Track': if (i.reviewId) { J.open('review', { rid: i.reviewId }); return; } R.selected = i.id || i.label; TR.app.refresh(); load(true); return;
        case 'Submit': J.open('submit', { rid: i.reviewId }); return;
        case 'Receipt': J.open('outcome', { rid: i.reviewId }); return;
        case 'Continue': if (TR.experience) TR.experience.page = null; S.page(); return;
        case 'Inspect': J.open('execution', { rid: i.id }); return;
        case 'Resolve': if (i.reviewId) J.open('review', { rid: i.reviewId }); else J.open('impact', { rid: i.id, vid: (i.vehicles[0] || {}).id }); return;
        case 'Request review': { const r = await J.api('/reviews', { method: 'POST', body: { requestId: i.id, proposalRevision: i.proposalRevision } }); TR.announce && TR.announce(t('Review requested.')); J.open('review', { rid: r.id }); return; }
        default: R.selected = i.id; TR.app.refresh();
      }
    } catch (e) { TR.notify.toast(e.message, 'error'); }
  }
  const ACTION_LABEL = { Track: 'Track', Review: 'Review', Continue: 'Continue', Resolve: 'Resolve', Receipt: 'Receipt', Inspect: 'Inspect', 'Request review': 'Request review', Submit: 'Submit', Open: 'Open' };

  // ------------------------------------------------------------------ pieces
  const keyOf = (i) => i.id || i.label;
  function row(i) {
    const v = i.vehicles[0];
    const on = R.selected === keyOf(i);
    const open = () => { R.selected = keyOf(i); R.menu = null; TR.app.refresh(); };
    return h('tr', { class: on ? 'is-sel' : '', onClick: open },
      h('td', null, h('button', { class: 'jr-link', onClick: (e) => { e.stopPropagation(); open(); }, 'aria-pressed': String(on) }, i.label)),
      h('td', null, v ? h('span', { class: 'jr-two' }, h('strong', null, v.title.replace(' ', '')), h('small', { class: 'muted' }, v.architecture)) : '—', i.vehicles.length > 1 ? h('small', { class: 'muted' }, ' +' + (i.vehicles.length - 1)) : null),
      h('td', null, J.chip(i.status), i.status === 'running' && i.attempt ? h('small', { class: 'muted jr-under' }, t('Attempt {n}', { n: i.attempt })) : null),
      h('td', null, h('span', { class: 'jr-owner' }, TR.icon('user', 15), i.owner.name), i.assignee ? h('small', { class: 'muted jr-under' }, i.assignee.id === me() ? t('Assigned to you') : t('Assigned to {p}', { p: i.assignee.name })) : null),
      h('td', null, h('time', { datetime: i.updatedAt, title: ui().when(i.updatedAt) }, J.ago(i.updatedAt))),
      h('td', null, h('button', { class: 'jr-link', onClick: (e) => { e.stopPropagation(); act(i); } }, t(ACTION_LABEL[i.action] || i.action))),
      h('td', { class: 'jr-more-cell' }, h('div', { class: 'jr-menu-wrap' },
        h('button', { class: 'ap-icon-btn', 'aria-label': t('More for {r}', { r: i.label }), 'aria-haspopup': 'true', 'aria-expanded': String(R.menu === keyOf(i)), onClick: (e) => { e.stopPropagation(); R.menu = R.menu === keyOf(i) ? null : keyOf(i); TR.app.refresh(); } }, TR.icon('dots', 18)),
        R.menu === keyOf(i) ? h('div', { class: 'ap-menu jr-menu', role: 'menu', onClick: (e) => e.stopPropagation() },
          i.id && i.mine && i.status !== 'running' && i.status !== 'queued' && i.status !== 'draft' ? h('button', { role: 'menuitem', onClick: () => J.open('execution', { rid: i.id }) }, TR.icon('clock', 15), t('Execution timeline')) : null,
          v && v.id ? h('button', { role: 'menuitem', onClick: () => J.open('impact', { rid: i.mine && i.id ? i.id : null, vid: v.id }) }, TR.icon('graph', 15), t('Change impact')) : null,
          i.id ? h('button', { role: 'menuitem', onClick: () => J.open('logs', { rid: i.label }) }, TR.icon('file', 15), t('Related events')) : null,
          i.id ? h('button', { role: 'menuitem', onClick: () => J.copy(i.id, 'Request id') }, TR.icon('copy', 15), t('Copy request id')) : null) : null)));
  }
  function header(key, labelText) {
    const on = R.sort === key;
    return h('th', { 'aria-sort': on ? (R.dir === 'asc' ? 'ascending' : 'descending') : 'none' },
      h('button', { class: 'jr-sort', onClick: () => { if (on) R.dir = R.dir === 'asc' ? 'desc' : 'asc'; else { R.sort = key; R.dir = key === 'updatedAt' ? 'desc' : 'asc'; } R.page = 0; TR.app.refresh(); } },
        t(labelText), h('span', { 'aria-hidden': 'true', class: 'jr-sort-mark' }, on ? (R.dir === 'asc' ? '▲' : '▼') : '⇅')));
  }
  function side(list) {
    const i = list.find((x) => keyOf(x) === R.selected) || (R.data.items.find((x) => keyOf(x) === R.selected));
    const c = R.data.counts, w = waiting(R.data.items);
    const go = (tab) => () => { R.tab = tab; R.page = 0; TR.app.refresh(); };
    const next = h('section', { class: 'jr-card' }, h('h2', { class: 'jr-h3' }, t('Your next actions')),
      h('ul', { class: 'jr-next' },
        w.assigned ? h('li', null, h('button', { class: 'jr-row-link', onClick: go('assigned') }, TR.icon('clock', 17), h('span', null, t('Review {n} assigned request(s)', { n: w.assigned })), TR.icon('chevron', 15))) : null,
        w.queue ? h('li', null, h('button', { class: 'jr-row-link', onClick: go('queue') }, TR.icon('people', 17), h('span', null, t('{n} unassigned review(s) to take', { n: w.queue })), TR.icon('chevron', 15))) : null,
        c.drafts ? h('li', null, h('button', { class: 'jr-row-link', onClick: () => { if (TR.experience) TR.experience.page = null; TR.testRequest.page(); } }, TR.icon('file', 17), h('span', null, t('Resume your saved draft')), TR.icon('chevron', 15))) : null,
        !w.assigned && !w.queue && !c.drafts ? h('li', { class: 'muted' }, t('Nothing waits on you.')) : null));
    if (!i) return h('aside', { class: 'jr-side' }, h('section', { class: 'jr-card' }, h('h2', { class: 'jr-h3' }, t('Selected request')), h('p', { class: 'muted' }, t('Choose a request to see its details and next step.'))), next);
    const v = i.vehicles[0];
    const note = { 'awaiting-review': 'Approval is required for this exact revision.', approved: 'Approved. An authorised operator can submit it.', 'needs-revalidation': 'The vehicle changed after validation. Validate again before review.',
      blocked: 'Blocking findings: resolve them and validate again.', 'changes-requested': 'The reviewer asked for changes.', completed: 'Committed to the VDA repository.', running: 'Validation is running; this list updates by itself.',
      queued: 'Waiting for a worker.', draft: 'Saved draft, not validated yet.', validated: 'Validated. Ask for a review when ready.' }[i.status];
    return h('aside', { class: 'jr-side' },
      h('section', { class: 'jr-card', 'aria-label': t('Selected request') }, h('h2', { class: 'jr-h3' }, t('Selected request')),
        h('div', { class: 'jr-side-title' }, h('strong', { class: 'jr-big' }, i.label), J.chip(i.status)),
        J.facts([['Vehicle', v ? h('span', { class: 'jr-two' }, h('span', null, v.title), h('small', { class: 'muted' }, v.architecture)) : null], ['Kind', i.kind],
          ['Revision', i.proposalRevision], ['Author', i.owner.name], ['Reviewer', i.reviewer], ['Changes', i.changes], i.blockers ? ['Blockers', String(i.blockers)] : null]),
        note ? J.banner(i.status === 'blocked' || i.status === 'needs-revalidation' ? 'warning' : 'info', 'info', t(note)) : null,
        h('div', { class: 'jr-stack' },
          TR.pages.ui.button(t(i.action === 'Track' ? 'Refresh' : i.action === 'Review' || i.action === 'Open' ? 'Open review' : ACTION_LABEL[i.action] || i.action), i.action === 'Track' ? 'refresh' : 'arrow', () => (i.action === 'Track' ? load() : act(i)), 'primary'),
          v && v.id ? TR.pages.ui.button(t('View changes'), 'graph', () => J.open('impact', { rid: i.mine && i.id ? i.id : null, vid: v.id }), 'secondary') : null)),
      next);
  }

  // ------------------------------------------------------------------ page
  function render() {
    if (!R.data && !R.loading && !R.error) load();
    const d = R.data, w = d ? waiting(d.items) : { assigned: 0, queue: 0 };
    const head = J.pageHead('Requests', 'Pick up your work, review changes and follow execution.', [TR.pages.ui.button(t('Activity log'), 'clock', () => TR.pages.show('activity'), 'secondary'), TR.pages.ui.button(t('New request'), 'plus', () => { if (TR.experience) TR.experience.page = null; TR.testRequest.page(); }, 'primary')]);
    if (!d) return h('div', { class: 'jr-page' }, head, R.error ? J.failed(R.error, () => load()) : J.loading(6));
    const all = d.items;
    const set = (k, v) => { R[k] = v; R.page = 0; TR.app.refresh(); };
    const list = filter(all, R);
    const pages = Math.max(1, Math.ceil(list.length / R.size)); R.page = Math.min(R.page, pages - 1);
    const shown = list.slice(R.page * R.size, (R.page + 1) * R.size);
    const owners = [...new Set(all.map((i) => i.owner.name))].sort();
    const statuses = [...new Set(all.map((i) => i.status))];
    const any = R.q || R.status || R.arch || R.owner;
    return h('div', { class: 'jr-page', onClick: () => { if (R.menu) { R.menu = null; TR.app.refresh(); } } }, head,
      J.stats([
        { n: d.counts.drafts, label: 'My drafts', icon: 'file', tone: 'neutral', onClick: () => set('status', R.status === 'draft' ? '' : 'draft'), on: R.status === 'draft' },
        { n: d.counts.running, label: 'Running', icon: 'play', tone: 'info', onClick: () => set('status', R.status === 'running' ? '' : 'running'), on: R.status === 'running' },
        { n: w.assigned, label: 'Assigned to you', icon: 'clock', tone: 'warning', onClick: () => set('tab', 'assigned'), on: R.tab === 'assigned', sub: w.queue ? t('{n} unassigned', { n: w.queue }) : null },
        { n: d.counts.completedToday, label: 'Completed today', icon: 'check', tone: 'good', onClick: () => set('tab', 'completed'), on: R.tab === 'completed' }]),
      h('div', { class: 'jr-tabs', role: 'tablist', 'aria-label': t('Requests') }, TABS.map(([id, l]) => {
        const n = id === 'assigned' ? w.assigned : id === 'queue' ? w.queue : null;
        return h('button', { role: 'tab', 'aria-selected': String(R.tab === id), class: R.tab === id ? 'is-on' : '', onClick: () => set('tab', id) }, t(l), n ? h('span', { class: 'jr-count' }, String(n)) : null);
      })),
      h('div', { class: 'jr-filters' },
        J.search('Search request or vehicle', R.q, (v) => { R.q = v; R.page = 0; J.later(() => TR.app.refresh()); }),
        J.select('Status', R.status, [['', 'All']].concat(statuses.map((s) => [s, J.state(s)[0]])), (v) => set('status', v)),
        J.select('Architecture', R.arch, [['', 'All'], ['T3', 'T3'], ['Legacy', 'Legacy']], (v) => set('arch', v)),
        J.select('Owner', R.owner, [['', 'Anyone']].concat(owners.map((o) => [o, o])), (v) => set('owner', v)),
        any ? h('button', { class: 'jr-link', onClick: () => { R.q = R.status = R.arch = R.owner = ''; R.page = 0; TR.app.refresh(); } }, t('Clear filters')) : null),
      h('div', { class: 'jr-split' },
        J.card(t('Recent requests'), [h('small', { class: 'muted', role: 'status' }, t('Updated {a}', { a: J.ago(d.generatedAt) })), h('button', { class: 'ap-icon-btn', 'aria-label': t('Refresh'), onClick: () => load() }, TR.icon('refresh', 17))],
          shown.length ? h('div', { class: 'jr-table-wrap' }, h('table', { class: 'jr-table' },
            h('thead', null, h('tr', null, header('label', 'Request'), header('vehicle', 'Vehicle'), header('status', 'Status'), header('owner', 'Owner'), header('updatedAt', 'Updated'), h('th', null, t('Action')), h('th', null, h('span', { class: 'nv-sr' }, t('More'))))),
            h('tbody', null, shown.map(row))))
            : J.empty(all.length ? 'No requests match' : 'No requests yet', all.length ? 'Clear the filters or choose another tab.' : 'Validate a proposal on the test request and it appears here.', all.length ? null : TR.pages.ui.button(t('New request'), 'plus', () => TR.testRequest.page(), 'secondary')),
          h('footer', { class: 'jr-pager' }, h('span', { class: 'muted' }, list.length ? t('Showing {a}–{b} of {n}', { a: R.page * R.size + 1, b: Math.min(list.length, (R.page + 1) * R.size), n: list.length }) : ''),
            h('span', { class: 'spacer' }),
            J.select('Per page', R.size, [[10, '10'], [25, '25'], [50, '50']], (v) => { R.size = Number(v); R.page = 0; TR.app.refresh(); }),
            TR.pages.ui.button(t('Previous'), 'left', () => { R.page--; TR.app.refresh(); }, 'secondary', { disabled: R.page === 0 }),
            TR.pages.ui.button(t('Next'), 'right', () => { R.page++; TR.app.refresh(); }, 'secondary', { disabled: R.page >= pages - 1 }))),
        side(list)),
      h('p', { class: 'jr-foot muted' }, t('Status reflects the latest recorded result. Opening a request checks current permissions.')));
  }
  TR.pages.register({ id: 'requests', title: 'Requests', crumbs: () => [{ label: t('Workspace') }, { label: t('Requests') }], render });
  TR.requestsHub = { R, load, filter, inTab, act, waiting };
})();
