/* Back to top: a compact control for each scroll container, never for the page as a whole when something inside scrolls.
 *
 *   Where     the main content area, each pane of the two-pane workbench, docked panels, the Logs event table, anything
 *             marked data-backtotop, and the document itself when it is the scroller. Graph canvases, where scrolling
 *             means panning (Change impact, the vehicle architecture, anything marked data-pan), never get one: they
 *             have Fit view / Reset view instead.
 *   When      shown once the container has scrolled about one of its own heights; hidden again near the top (a little
 *             hysteresis so it does not flicker).
 *   How       one capture-phase scroll listener for the whole app, throttled to one check per animation frame; the
 *             button is created the first time its container scrolls and only its class changes after that, so nothing
 *             re-renders. Containers re-created by a refresh get a new button on their next scroll event (restoring the
 *             scroll position fires one). Removed containers take their button with them; there is nothing to clean up.
 *   Activate  scrolls only that container to the top, smoothly or instantly with reduced motion; then moves focus to the
 *             container's heading (h1, else h2, else the container) with preventScroll, so focus causes no second scroll.
 *   Place     sticky at the lower right of the container (inside its scrollbar), above the safe area on phones, lifted
 *             above sticky action bars and toasts that would cover it.
 * Filters, selections, expanded sections and edits are untouched: the control only scrolls. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : s);
  const CONTAINERS = '.s-main, .pane-body, .ap-panel-body, .ap-panel .panel-body, .lg-events .lg-table, [data-backtotop]';
  const PANNING = '.ci-scroll, .va-canvas, [data-pan], .lg-chart, svg';

  // ------------------------------------------------------------------ rules (tested in tests/frontend/backtotop.cjs)
  const logic = {
    /** Show past ~0.9 of the container height; once shown, hide only when back within a quarter of it. */
    visible(scrollTop, clientHeight, wasVisible) {
      const height = Math.max(1, clientHeight || 0);
      return wasVisible ? scrollTop > height * 0.25 : scrollTop > height * 0.9;
    },
    /** The container a scroll event belongs to, or null (panning canvases, the sidebar, menus, tiny lists). */
    container(target, doc) {
      if (!target) return null;
      if (target === doc || target === doc.documentElement || target === doc.body || target === doc.scrollingElement) return doc.scrollingElement || doc.documentElement;
      if (typeof target.matches !== 'function') return null;
      if (target.matches(PANNING) || (target.closest && target.closest(PANNING))) return null;
      if (target.closest && target.closest('#studio-navigation, .nv, .mb-menu, .ap-menu, .jr-menu, .lg-menu')) return null;
      return target.matches(CONTAINERS) ? target : null;
    },
    /** Where focus goes after scrolling up: the container's first heading, else the container itself. */
    focusTarget(el) {
      if (!el || typeof el.querySelector !== 'function') return el;
      // A pane's heading is its title above the scrolling body ("Starting vehicle", "Result or comparison").
      const pane = el.matches && el.matches('.pane-body') && el.closest ? el.closest('.pane') : null;
      const title = pane && pane.querySelector('.pane-title');
      if (title) return title;
      return el.querySelector('h1') || el.querySelector('h2, [role="heading"]') || el;
    },
    behavior: (reduced) => (reduced ? 'auto' : 'smooth'),
  };

  const reducedMotion = () => (TR.pages && TR.pages.ui && TR.pages.ui.motionOn ? !TR.pages.ui.motionOn() : typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches);
  const isDocument = (el) => typeof document !== 'undefined' && (el === document.scrollingElement || el === document.documentElement);

  // ------------------------------------------------------------------ the button
  const state = new WeakMap();   // container → { button, visible }
  function make(el) {
    const doc = isDocument(el);
    const b = h('button', { type: 'button', class: ['btt', doc ? 'is-fixed' : ''], 'aria-label': t('Back to top'), 'data-tip': t('Back to top'), tabindex: '-1',
      onClick: (e) => { e.stopPropagation(); goTop(el); } }, TR.icon('up', 18));
    if (doc) document.body.appendChild(b); else el.appendChild(b);
    const s = { button: b, visible: false };
    state.set(el, s);
    return s;
  }
  function goTop(el) {
    el.scrollTo({ top: 0, behavior: logic.behavior(reducedMotion()) });
    // Focus the heading of what was scrolled (for the page itself: the main content) without scrolling again.
    const f = logic.focusTarget(isDocument(el) ? document.querySelector('.s-main, main') || document.body : el);
    if (f && typeof f.focus === 'function') {
      if (!f.hasAttribute('tabindex') && !/^(A|BUTTON|INPUT|SELECT|TEXTAREA)$/.test(f.tagName)) f.setAttribute('tabindex', '-1');
      f.focus({ preventScroll: true });
    }
    TR.announce && TR.announce(t('Back at the top.'));
  }
  /** Lifts the button above things that would cover it: a sticky action bar at the bottom of the container, or toasts. */
  function lift(el, b) {
    let extra = 0;
    const r = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
    if (r) {
      const toasts = document.querySelector('.nt-host');
      if (toasts && toasts.children.length) { const tr = toasts.getBoundingClientRect(); if (tr.left < r.right && tr.top < r.bottom && tr.bottom > r.bottom - 120) extra = Math.max(extra, r.bottom - tr.top + 8); }
      for (const bar of el.querySelectorAll(':scope .is-sticky-bottom, :scope .wf-bar.is-sticky, :scope .cp-submit.is-sticky, :scope .s-footer')) {
        const br = bar.getBoundingClientRect(); if (br.bottom >= r.bottom - 4) extra = Math.max(extra, br.height + 8);
      }
    }
    b.style.setProperty('--btt-lift', extra + 'px');
  }
  function update(el) {
    const s = state.get(el) || (el.scrollTop > 0 ? make(el) : null);
    if (!s) return;
    if (!s.button.isConnected) { state.delete(el); return update(el); }
    const show = logic.visible(el.scrollTop, el.clientHeight, s.visible);
    if (show !== s.visible) {
      s.visible = show;
      s.button.classList.toggle('is-visible', show);
      s.button.tabIndex = show ? 0 : -1;
      s.button.setAttribute('aria-hidden', show ? 'false' : 'true');
    }
    if (show) lift(el, s.button);
  }

  // ------------------------------------------------------------------ one listener, one check per frame
  const pending = new Set();
  let frame = 0;
  function onScroll(e) {
    const el = logic.container(e.target, document);
    if (!el) return;
    pending.add(el);
    if (!frame) frame = (typeof requestAnimationFrame === 'function' ? requestAnimationFrame : setTimeout)(() => { frame = 0; const list = [...pending]; pending.clear(); list.forEach(update); });
  }
  if (typeof document !== 'undefined' && typeof document.addEventListener === 'function') document.addEventListener('scroll', onScroll, { capture: true, passive: true });

  // After each render, containers that come back already scrolled (the refresh restores their position without a scroll
  // event) get their control at once: one pass over the few scroll containers, on the next frame.
  function afterRender() {
    if (typeof document === 'undefined' || typeof document.querySelectorAll !== 'function') return;
    (typeof requestAnimationFrame === 'function' ? requestAnimationFrame : setTimeout)(() => {
      document.querySelectorAll(CONTAINERS).forEach((el) => { if (el.scrollTop > 0 && logic.container(el, document)) update(el); });
    });
  }
  if (TR.testRequest && typeof TR.testRequest.frame === 'function') { const base = TR.testRequest.frame; TR.testRequest.frame = (content) => { const f = base(content); afterRender(); return f; }; }

  TR.backToTop = { logic, update, goTop, afterRender, CONTAINERS, PANNING };
})();
