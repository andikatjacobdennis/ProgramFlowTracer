/* Interface language: US English in the code, any language on screen, from dictionaries.
 *
 *   TR.i18n.t('Settings')                              the text in the chosen language
 *   TR.i18n.t('Showing {from}–{to} of {total}', vars)  {placeholders} are filled after translating
 *   TR.i18n.t('{n} change(s)', { n })                  a pack may give { one, other, few, … } forms (Intl.PluralRules)
 *   TR.i18n.lang() / locale() / dir()                  'sv', 'sv-SE', 'ltr'
 *
 * Language packs are JSON files in /i18n, listed in /i18n/languages.json, and fetched only when chosen, so adding a
 * language needs no code: copy /i18n/template.json (written by scripts/i18n-extract.js) to <code>.json, translate the values,
 * add one line to languages.json. Missing texts fall back along the chain pt-BR → pt → English.
 *
 * Text that never passes through t() (older screens build English strings directly) is translated where it is shown: a
 * MutationObserver looks up each new text node and the placeholder, title, aria-label, alt and data-tip attributes in the
 * dictionary — exact text first, then patterns such as "Revision {n}". Data is never translated: inputs, code, pre, kbd,
 * anything inside translate="no" or data-i18n="off", and every text that is not in the dictionary.
 * The originals are kept, so switching back to English restores them. Nothing runs while the language is English.
 *
 * "Pseudo" (qps) is a test language: every text is accented, bracketed and 30 % longer, so untranslatable or clipped
 * text stands out. Settings → Language and region shows coverage, the texts still missing and a template to download. */
(function () {
  'use strict';
  const MANIFEST = '/i18n/languages.json';
  const BUILT_IN = [{ code: 'en', name: 'English', english: 'English', locale: 'en-US', dir: 'ltr' }, { code: 'qps', name: 'Pseudo', english: 'Pseudo (test)', locale: 'en-US', dir: 'ltr', pseudo: true }];
  const I = { languages: BUILT_IN.slice(), packs: { en: {} }, loading: {}, missing: new Map(), seen: 0, ready: false, active: 'en', observer: null };
  const DICT = I.packs;   // kept for code that reads TR.i18n.DICT

  // ------------------------------------------------------------------ choosing the language
  const known = (code) => I.languages.find((l) => l.code === code);
  /** The best available code for a requested language or culture: exact, then the base language, else English. */
  function best(requested) {
    const want = String(requested || '').trim();
    if (!want) return 'en';
    if (known(want)) return want;
    const lower = want.toLowerCase();
    const exact = I.languages.find((l) => l.code.toLowerCase() === lower || (l.locale || '').toLowerCase() === lower);
    if (exact) return exact.code;
    const base = lower.split(/[-_]/)[0];
    const b = I.languages.find((l) => l.code.toLowerCase() === base || l.code.toLowerCase().split('-')[0] === base);
    return b && !b.pseudo ? b.code : 'en';
  }
  function choice() { try { return TR.prefs ? TR.prefs.get('uiLanguage') : 'auto'; } catch (e) { return 'auto'; } }
  function lang() {
    const c = choice();
    if (c && c !== 'auto') return best(c);
    const culture = TR.culture ? TR.culture.active().language : (typeof navigator !== 'undefined' && navigator.language) || 'en';
    const code = best(culture);
    return known(code) && known(code).pseudo ? 'en' : code;
  }
  const meta = () => known(lang()) || BUILT_IN[0];
  const locale = () => meta().locale || lang();
  const dir = () => (meta().dir === 'rtl' ? 'rtl' : 'ltr');
  /** Codes to try for a language: 'pt-BR' → ['pt-BR', 'pt']. */
  const chain = (code) => { const out = [code]; const base = String(code).split('-')[0]; if (base !== code && known(base)) out.push(base); return out; };

  // ------------------------------------------------------------------ looking up
  const fill = (text, vars) => (vars ? String(text).replace(/\{(\w+)\}/g, (m, k) => (vars[k] != null ? String(vars[k]) : m)) : String(text));
  let rules = null, rulesFor = null;
  function plural(forms, vars) {
    const n = vars && (vars.n != null ? vars.n : vars.count != null ? vars.count : null);
    if (rulesFor !== locale()) { try { rules = new Intl.PluralRules(locale()); } catch (e) { rules = null; } rulesFor = locale(); }
    const cat = n != null && rules ? rules.select(Number(n)) : 'other';
    return forms[cat] != null ? forms[cat] : forms.other != null ? forms.other : forms.one;
  }
  function raw(text, code) {
    for (const c of chain(code)) { const p = I.packs[c]; if (p && p[text] != null && p[text] !== '') return p[text]; }
    return null;
  }
  function note(text) { if (I.missing.size < 3000 && !I.missing.has(text) && !/[<>]/.test(text)) I.missing.set(text, Date.now()); }
  /** The text in the chosen language, with {placeholders} filled. */
  function t(text, vars) {
    const code = lang();
    if (code === 'en') return fill(text, vars);
    if (known(code) && known(code).pseudo) return pseudo(fill(text, vars));
    let hit = raw(text, code);
    if (hit == null) { note(String(text)); return fill(text, vars); }
    if (typeof hit === 'object') hit = plural(hit, vars);
    return fill(hit, vars);
  }
  /** Whether a translation exists (for tests and the coverage view). */
  const has = (text, code) => raw(text, code || lang()) != null;

  // ------------------------------------------------------------------ pseudo-language
  const ACCENT = { a: 'á', b: 'ƀ', c: 'ç', d: 'ď', e: 'é', f: 'ƒ', g: 'ĝ', h: 'ĥ', i: 'í', j: 'ĵ', k: 'ķ', l: 'ĺ', m: 'ɱ', n: 'ñ', o: 'ó', p: 'þ', q: 'ǫ', r: 'ŕ', s: 'š', t: 'ţ', u: 'ú', v: 'ṽ', w: 'ŵ', x: 'ẋ', y: 'ý', z: 'ž',
    A: 'Á', B: 'Ɓ', C: 'Ç', D: 'Ď', E: 'É', F: 'Ƒ', G: 'Ĝ', H: 'Ĥ', I: 'Í', J: 'Ĵ', K: 'Ķ', L: 'Ĺ', M: 'Ṁ', N: 'Ñ', O: 'Ó', P: 'Þ', Q: 'Ǫ', R: 'Ŕ', S: 'Š', T: 'Ţ', U: 'Ú', V: 'Ṽ', W: 'Ŵ', X: 'Ẋ', Y: 'Ý', Z: 'Ž' };
  function pseudo(s) {
    if (!s || /^\[.*\]$/.test(s)) return s;
    const body = String(s).replace(/(\{\w+\})|([A-Za-z])/g, (m, ph, ch) => (ph ? ph : ACCENT[ch] || ch));
    return '[' + body + '·'.repeat(Math.ceil(s.length * 0.3)) + ']';
  }

  // ------------------------------------------------------------------ patterns for shown text ("Revision 4" ↔ "Revision {n}")
  let patterns = null, patternsFor = null;
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  function compile(code) {
    const list = new Map();   // first literal word → [{ re, names, key }]
    for (const c of chain(code)) for (const key of Object.keys(I.packs[c] || {})) {
      if (!key.includes('{') || typeof I.packs[c][key] !== 'string') continue;
      const names = [], parts = key.split(/\{(\w+)\}/);
      const src = parts.map((p, i) => (i % 2 ? (names.push(p), '(.+?)') : esc(p))).join('');
      const word = (parts.filter((p, i) => i % 2 === 0).join(' ').match(/[A-Za-z]{2,}/) || [''])[0].toLowerCase();
      if (!word) continue;
      if (!list.has(word)) list.set(word, []);
      list.get(word).push({ re: new RegExp('^' + src + '$'), names, key });
    }
    patterns = list; patternsFor = code;
  }
  /** The translation of a whole shown text, or null: exact key, else a pattern with its values carried over. */
  function shown(text, code) {
    const exact = raw(text, code);
    if (exact != null) return typeof exact === 'object' ? plural(exact, {}) : exact;
    if (!/[A-Za-z]/.test(text) || text.length > 300) return null;
    if (patternsFor !== code) compile(code);
    const words = new Set((text.match(/[A-Za-z]{2,}/g) || []).map((w) => w.toLowerCase()));
    for (const w of words) for (const p of patterns.get(w) || []) {
      const m = text.match(p.re);
      if (!m) continue;
      const vars = {}; p.names.forEach((n, i) => { vars[n] = m[i + 1]; });
      let v = raw(p.key, code);
      if (typeof v === 'object') v = plural(v, vars);
      return fill(v, vars);
    }
    return null;
  }

  // ------------------------------------------------------------------ translating what is on screen
  const SKIP = 'script,style,noscript,template,code,pre,kbd,samp,textarea,input,select option[value],[translate="no"],[data-i18n="off"],[contenteditable="true"],svg text.ci-raw';
  const ATTRS = ['placeholder', 'title', 'aria-label', 'alt', 'aria-description', 'data-tip'];
  const original = new WeakMap();   // text node → English; element → { attr: English }
  function skip(el) { try { return !!(el && el.closest && el.closest(SKIP)); } catch (e) { return false; } }
  function translateText(node, code) {
    const was = original.has(node) ? original.get(node) : node.nodeValue;
    const text = was.trim();
    if (!text || text.length < 2) return;
    let next = null;
    if (code === 'en') next = original.has(node) ? was : null;
    else if (known(code) && known(code).pseudo) next = was.replace(text, pseudo(text));
    else { const hit = shown(text, code); if (hit != null) next = was.replace(text, hit); else if (/[A-Za-z]{3}/.test(text) && !/^[\w.-]+$/.test(text)) note(text); }
    if (next != null && next !== node.nodeValue) { if (!original.has(node)) original.set(node, was); node.nodeValue = next; }
  }
  function translateAttrs(el, code) {
    let saved = original.get(el);
    for (const a of ATTRS) {
      if (!el.hasAttribute || (!el.hasAttribute(a) && !(saved && saved[a] != null))) continue;
      const was = saved && saved[a] != null ? saved[a] : el.getAttribute(a);
      if (!was) continue;
      let next;
      if (code === 'en') next = saved && saved[a] != null ? was : null;
      else if (a === 'data-tip') next = was.split('|').map((part) => (known(code).pseudo ? pseudo(part) : shown(part.trim(), code) || part)).join('|');
      else next = known(code).pseudo ? pseudo(was) : shown(was.trim(), code);
      if (next != null && next !== el.getAttribute(a)) { if (!saved) { saved = {}; original.set(el, saved); } if (saved[a] == null) saved[a] = was; el.setAttribute(a, next); }
    }
  }
  /** Translates a part of the page (or all of it) into the active language; English restores the originals. */
  function translateTree(root, code) {
    code = code || lang();
    if (!root || typeof document === 'undefined' || !document.createTreeWalker) return;
    if (root.nodeType === 3) { if (!skip(root.parentElement)) translateText(root, code); return; }
    if (root.nodeType !== 1 || skip(root)) return;
    translateAttrs(root, code);
    const walk = document.createTreeWalker(root, 5 /* SHOW_ELEMENT | SHOW_TEXT */, { acceptNode: (n) => (n.nodeType === 1 && n.matches && n.matches(SKIP) ? 2 /* REJECT */ : 1) });
    let n; let count = 0;
    while ((n = walk.nextNode())) { count++; if (n.nodeType === 3) translateText(n, code); else translateAttrs(n, code); }
    I.seen += count;
  }
  let queue = [], scheduled = false;
  function flush() {
    scheduled = false;
    const code = lang(), list = queue; queue = [];
    if (code === 'en') return;
    for (const node of list) if (node.isConnected !== false) translateTree(node, code);
  }
  function watch() {
    if (I.observer || typeof MutationObserver !== 'function' || typeof document === 'undefined' || !document.body) return;
    I.observer = new MutationObserver((records) => {
      if (I.active === 'en') return;
      for (const r of records) {
        if (r.type === 'childList') r.addedNodes.forEach((n) => queue.push(n));
        else if (r.type === 'characterData' && !original.has(r.target)) queue.push(r.target);
        else if (r.type === 'attributes') queue.push(r.target);
      }
      if (!scheduled) { scheduled = true; (typeof requestAnimationFrame === 'function' ? requestAnimationFrame : setTimeout)(flush); }
    });
    I.observer.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  }

  // ------------------------------------------------------------------ loading packs
  async function getJson(url) { const r = await fetch(url, { credentials: 'same-origin' }); if (!r.ok) throw new Error(url + ': ' + r.status); return r.json(); }
  async function loadManifest() {
    if (typeof fetch !== 'function' || typeof location === 'undefined' || !/^https?:$/.test(location.protocol)) return;
    try {
      const m = await getJson(MANIFEST);
      const list = (m.languages || []).filter((l) => l && /^[a-z]{2,3}(-[A-Za-z0-9]{2,8})*$/.test(l.code) && l.code !== 'en' && l.code !== 'qps');
      I.languages = [BUILT_IN[0]].concat(list, [BUILT_IN[1]]);
    } catch (e) { /* English only */ }
    I.ready = true;
    await apply();
  }
  /** Fetches a pack (and its base language) once. */
  async function loadPack(code) {
    const todo = chain(code).filter((c) => c !== 'en' && !I.packs[c] && known(c) && known(c).file);
    await Promise.all(todo.map((c) => (I.loading[c] = I.loading[c] || getJson('/i18n/' + known(c).file).then((p) => { add(c, p.strings || p); }).catch(() => { I.packs[c] = {}; }))));
  }
  /** Adds translations: TR.i18n.add('sv', { 'Settings': 'Inställningar', … }) — also how packs arrive. */
  function add(code, strings) { I.packs[code] = Object.assign(I.packs[code] || {}, strings); if (patternsFor && chain(patternsFor).includes(code)) patternsFor = null; }

  /** Makes the active language take effect: loads its pack, sets lang/dir, re-renders and translates the page. */
  async function apply() {
    const code = lang();
    if (code !== 'en') await loadPack(code);
    const previous = I.active; I.active = code;
    if (typeof document !== 'undefined' && document.documentElement) { document.documentElement.lang = locale(); document.documentElement.dir = dir(); }
    if (TR.app && TR.app.shell && TR.app.shell.left) try { TR.app.refresh(); } catch (e) { /* not started */ }
    if (typeof document !== 'undefined' && document.body && (code !== 'en' || previous !== 'en')) { watch(); translateTree(document.body, code); }
  }

  // ------------------------------------------------------------------ coverage (Settings)
  /** For a language: how many keys of the template it covers and the texts seen on screen without a translation. */
  async function coverage(code) {
    let template = {};
    try { template = (await getJson('/i18n/template.json')).strings || {}; } catch (e) { /* none */ }
    await loadPack(code);
    const keys = Object.keys(template);
    const have = keys.filter((k) => has(k, code));
    return { code, total: keys.length, covered: have.length, percent: keys.length ? Math.round((100 * have.length) / keys.length) : 0, missingKeys: keys.filter((k) => !has(k, code)), seenMissing: [...I.missing.keys()].filter((k) => !has(k, code)) };
  }
  /** The pack for a language as a translator would download it: every template key, existing translations filled in. */
  async function template(code) {
    const c = await coverage(code);
    let tpl = {}; try { tpl = (await getJson('/i18n/template.json')).strings || {}; } catch (e) { /* none */ }
    const strings = {};
    Object.keys(tpl).concat(c.seenMissing).forEach((k) => { strings[k] = raw(k, code) != null ? raw(k, code) : ''; });
    return { $meta: { language: code, note: 'Translate the values; keep the keys and every {placeholder}.', covered: c.covered, total: c.total }, strings };
  }

  // ------------------------------------------------------------------ countries with several languages
  /**
   * The languages of the user's country (culture.js lists them, for example India: en-IN, hi-IN, ta-IN, kn-IN, mr-IN), each
   * with its own name, whether a pack exists for it and which pack answers. Auto follows the culture's own language (the one
   * chosen for the country), never another language of the same country; without a pack for it, English.
   */
  function countryLanguages() {
    const C = TR.culture; if (!C) return [];
    const p = C.active(), c = (C.COUNTRIES || []).find((x) => x.code === p.country);
    if (!c) return [];
    return c.languages.map((loc) => {
      const code = best(loc), base = loc.split('-')[0];
      const pack = code !== 'en' || base === 'en' ? code : null;
      let name = loc; try { name = new Intl.DisplayNames([loc], { type: 'language' }).of(loc); } catch (e) { /* the code */ }
      return { locale: loc, name, pack, available: pack != null, current: p.language === loc };
    });
  }
  const label = (l) => (l.pseudo ? l.english : l.name + (l.english && l.english !== l.name ? ' — ' + l.english : ''));
  /** Auto, then the installed languages of your country, then every other installed language. */
  function LANGS_FN() {
    const mine = new Set(countryLanguages().filter((x) => x.pack && x.pack !== 'en').map((x) => x.pack));
    const ordered = I.languages.filter((l) => mine.has(l.code)).concat(I.languages.filter((l) => !mine.has(l.code)));
    return [['auto', 'Auto (follows your culture)']].concat(ordered.map((l) => [l.code, label(l) + (mine.has(l.code) ? ' · ' + t('your country') : '')]));
  }
  const speechLang = () => (lang() === 'en' || (known(lang()) || {}).pseudo ? null : locale());
  TR.i18n = { t, add, lang, locale, dir, best, has, pseudo, shown, translateTree, apply, loadPack, coverage, template, speechLang, countryLanguages, DICT, I,
    get LANGS() { return LANGS_FN(); }, get languages() { return I.languages.slice(); } };
  // Apply when the preference changes, and once the manifest is known.
  if (TR.prefs && typeof TR.prefs.onChange === 'function') TR.prefs.onChange((k) => { if (k === 'uiLanguage' || ((k === 'culture' || k === 'cultureMode') && choice() === 'auto')) apply(); });
  setTimeout(loadManifest, 0);
})();
