/* Git-style history graph and GitHub-style diffs, used by the Vehicle page.
 *
 *   TR.historyGraph.layout(entries, hasMore) – which lane each entry sits on and which lines pass through each row
 *   TR.historyGraph.gutter(row, lanes)       – the SVG drawn to the left of one row
 *   TR.historyGraph.diff(changes)            – a change list drawn like a GitHub diff: red "−" lines before, green "+" lines after
 *   TR.historyGraph.stat(changes)            – { additions, deletions } for the "+3 −3" summary
 *
 * Entries come newest first from /timeline (VehicleInsights.cs). Changes to the vehicle itself are on the main line (lane 0).
 * Simulations and kits get a side lane that starts at the revision they were based on ("base") and, when a simulation was
 * committed, joins the main line again at that revision ("mergedInto"). */
(function () {
  'use strict';
  const { h } = TR.util;
  const NS = 'http://www.w3.org/2000/svg';
  const MAX_LANES = 4;
  const LANE_W = 16, X0 = 12, DOT_Y = 20;
  const laneX = (l) => X0 + l * LANE_W;

  // ------------------------------------------------------------------ layout
  /**
   * rows[i] = { entry, lane, main: { up, down, dot }, lines: [{ lane, kind }] } where kind is one of
   *   'through' (vertical line across the row), 'up' / 'down' (half line above / below this row's dot),
   *   'join-below' (a side line arriving from below that curves into this row's main dot, used for a merge),
   *   'leave-above' (a side line coming from above that curves into this row's main dot, used for a base).
   *
   * Side entries are grouped into branches, like commits on a git branch:
   *   – simulations and kits that started from the same revision share one branch, which starts at that revision;
   *   – a simulation that was committed gets its own branch that joins the main line at its commit;
   *   – a kit made from a simulation sits on that simulation's branch.
   * Branches whose start is not loaded yet (older pages) run to the bottom when hasMore is true.
   */
  function layout(entries, hasMore) {
    const index = new Map(entries.map((e, i) => [e.id, i]));
    const mains = entries.map((e, i) => (e.lane === 'proposal' ? -1 : i)).filter((i) => i >= 0);
    const firstMain = mains.length ? mains[0] : Infinity;
    const lastMain = mains.length ? (hasMore ? Infinity : mains[mains.length - 1]) : -Infinity;
    const end = (id) => (id == null ? null : index.has(id) ? index.get(id) : hasMore ? Infinity : null);

    // Branches, oldest entry first so a kit finds the branch of its simulation.
    const branches = new Map(), branchOf = new Map();
    for (let i = entries.length - 1; i >= 0; i--) {
      const e = entries[i];
      if (e.lane !== 'proposal') continue;
      const merge = e.mergedInto != null && index.has(e.mergedInto) && index.get(e.mergedInto) < i ? index.get(e.mergedInto) : null;
      const parent = e.from != null && index.has(e.from) ? branchOf.get(index.get(e.from)) : null;
      const key = merge != null ? 'merge:' + e.id : parent && parent.merge == null ? parent.key : 'base:' + (e.base ?? 'none');
      if (!branches.has(key)) branches.set(key, { key, members: [], merge, base: end(e.base) });
      const b = branches.get(key);
      b.members.push(i);
      branchOf.set(i, b);
    }
    // One lane per branch, from its top (merge, or newest member) to its bottom (base, or oldest member). Lanes may touch.
    const occupied = Array.from({ length: MAX_LANES + 1 }, () => []);
    const list = [...branches.values()].map((b) => Object.assign(b, { top: b.merge ?? Math.min(...b.members), bottom: b.base ?? Math.max(...b.members) }))
      .sort((a, b) => b.bottom - a.bottom || a.top - b.top);
    for (const b of list) {
      const free = (l) => !occupied[l].some(([t, u]) => b.top < u && b.bottom > t);
      let lane = 1;
      while (lane < MAX_LANES && !free(lane)) lane++;
      occupied[lane].push([b.top, b.bottom]);
      b.lane = lane;
    }

    const rows = entries.map((entry, r) => ({
      entry, lane: 0, lines: [],
      main: { up: r > firstMain && r <= lastMain, down: r >= firstMain && r < lastMain, dot: entry.lane !== 'proposal' },
    }));
    // The main line also passes behind side entries that sit between two main entries.
    rows.forEach((row, r) => { if (!row.main.dot) { const on = r > firstMain && r < lastMain; row.main.up = on; row.main.down = on; } });
    for (const b of list) {
      const members = new Set(b.members);
      for (let r = b.top; r <= Math.min(b.bottom, rows.length - 1); r++) {
        if (members.has(r)) {
          rows[r].lane = b.lane;
          if (r > b.top) rows[r].lines.push({ lane: b.lane, kind: 'up' });
          if (r < b.bottom) rows[r].lines.push({ lane: b.lane, kind: 'down' });
        } else if (r === b.merge) rows[r].lines.push({ lane: b.lane, kind: 'join-below' });
        else if (r === b.base) rows[r].lines.push({ lane: b.lane, kind: 'leave-above' });
        else rows[r].lines.push({ lane: b.lane, kind: 'through' });
      }
    }
    const lanes = 1 + Math.max(0, ...list.map((b) => b.lane));
    return { rows, lanes, branches: list.length };
  }

  // ------------------------------------------------------------------ drawing
  function svg(tag, attrs) { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, String(v)); return e; }
  const colour = (l) => `var(--lane-${l % 5})`;
  const gutterWidth = (lanes) => X0 * 2 + (lanes - 1) * LANE_W;
  /** The lines and the dot for one row. The dot sits DOT_Y pixels from the top, level with the title. Placed absolutely over
   *  the row's left edge (the row reserves gutterWidth(lanes) for it), so it always spans the row's full height. */
  function gutter(row, lanes) {
    const width = gutterWidth(lanes);
    const g = svg('svg', { class: 'gh-gutter', width, height: '100%', 'aria-hidden': 'true' });
    const line = (x, y1, y2, l) => g.appendChild(svg('line', { x1: x, x2: x, y1, y2, stroke: colour(l), 'stroke-width': 2 }));
    if (row.main.up) line(laneX(0), 0, DOT_Y, 0);
    if (row.main.down) line(laneX(0), DOT_Y, '100%', 0);
    for (const { lane, kind, to = 0 } of row.lines) {
      const x = laneX(lane), x0 = laneX(to);
      if (kind === 'through') line(x, 0, '100%', lane);
      else if (kind === 'up') line(x, 0, DOT_Y, lane);
      else if (kind === 'down') line(x, DOT_Y, '100%', lane);
      else if (kind === 'join-below') { g.appendChild(svg('path', { d: `M${x0},${DOT_Y} C${x0},${DOT_Y + 14} ${x},${DOT_Y + 10} ${x},${DOT_Y + 24}`, stroke: colour(lane), 'stroke-width': 2, fill: 'none' })); line(x, DOT_Y + 24, '100%', lane); }
      else if (kind === 'leave-above') g.appendChild(svg('path', { d: `M${x},0 C${x},${DOT_Y - 8} ${x0},${DOT_Y - 12} ${x0},${DOT_Y}`, stroke: colour(lane), 'stroke-width': 2, fill: 'none' }));
    }
    const x = laneX(row.lane), e = row.entry;
    if (e.kind === 'Kit') g.appendChild(svg('rect', { x: x - 5, y: DOT_Y - 5, width: 10, height: 10, rx: 2, transform: `rotate(45 ${x} ${DOT_Y})`, fill: 'var(--panel)', stroke: colour(row.lane), 'stroke-width': 2.5 }));
    else if (row.lane) g.appendChild(svg('circle', { cx: x, cy: DOT_Y, r: 5, fill: 'var(--panel)', stroke: colour(row.lane), 'stroke-width': 2.5 }));
    else g.appendChild(svg('circle', { cx: x, cy: DOT_Y, r: 6, fill: colour(0), stroke: 'var(--panel)', 'stroke-width': 2.5 }));
    return g;
  }

  // ------------------------------------------------------------------ GitHub-style diff
  /** Lines of one change: [{ type: 'del'|'add'|'note', label, value }]. */
  function lines(c) {
    const out = [];
    const label = c.kind === 'Hardware' ? 'ECU hardware' : c.kind === 'Parameters' ? 'Parameters' : 'Node template';
    if (c.kind === 'Parameters') return [{ type: 'note', label, value: c.to }];
    if (c.from) out.push({ type: 'del', label, value: c.from });
    if (c.to) out.push({ type: 'add', label, value: c.to });
    for (const p of c.packages || []) {
      if (p.from) out.push({ type: 'del', label: p.name, value: p.from });
      if (p.to) out.push({ type: 'add', label: p.name, value: p.to });
    }
    return out;
  }
  function stat(changes) {
    const all = (changes || []).flatMap(lines);
    return { additions: all.filter((l) => l.type === 'add').length, deletions: all.filter((l) => l.type === 'del').length };
  }
  /** "+3 −3" with five little blocks, like the GitHub diffstat. */
  function statView(changes) {
    const { additions, deletions } = stat(changes);
    if (!additions && !deletions) return null;
    const total = additions + deletions, green = Math.round(5 * additions / total);
    return h('span', { class: 'gh-stat', title: `${additions} addition${additions === 1 ? '' : 's'} and ${deletions} deletion${deletions === 1 ? '' : 's'}` },
      h('span', { class: 'gh-add' }, '+' + additions), h('span', { class: 'gh-del' }, '−' + deletions),
      h('span', { class: 'gh-blocks', 'aria-hidden': 'true' }, Array.from({ length: 5 }, (_, i) => h('i', { class: i < green ? 'add' : i < 5 && total ? 'del' : '' }))));
  }
  const SIGN = { del: '−', add: '+', note: '~' };
  function diff(changes) {
    return h('div', { class: 'gh-diff' }, (changes || []).map((c) => h('div', { class: 'gh-file' },
      h('div', { class: 'gh-file-head' }, TR.icon(c.kind === 'Parameters' ? 'sliders' : 'chip', 15), h('strong', null, c.node), h('span', { class: 'gh-file-kind' }, c.kind), statView([c])),
      h('table', { class: 'gh-lines', role: 'presentation' }, h('tbody', null, lines(c).map((l) => h('tr', { class: 'gh-line ' + l.type },
        h('td', { class: 'gh-sign', 'aria-label': { del: 'Before', add: 'After', note: 'Changed' }[l.type] }, SIGN[l.type]),
        h('td', { class: 'gh-label' }, l.label), h('td', { class: 'gh-value' }, h('span', null, l.value)))))))));
  }

  /** Placeholder rows shown while the next page of history loads. */
  function skeleton(count = 3) {
    return Array.from({ length: count }, () => h('li', { class: 'gh-row gh-skeleton', 'aria-hidden': 'true' },
      h('span', { class: 'gh-skel-dot' }), h('div', { class: 'gh-card' }, h('span', { class: 'gh-skel w60' }), h('span', { class: 'gh-skel w35' }), h('span', { class: 'gh-skel w80' }))));
  }

  TR.historyGraph = { layout, gutter, gutterWidth, diff, stat, statView, lines, skeleton, MAX_LANES };
})();
