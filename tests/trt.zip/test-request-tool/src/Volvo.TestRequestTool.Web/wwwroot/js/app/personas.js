/* The animated guides, the same four for every country and culture: Asha (workshop technician), Ravi (software engineer),
 * Meera (data analyst) and Truxie the truck. No flags on any figure. The user picks one on first login or in Settings → Help, and it appears in
 * Help, the tour, empty pages and the dashboard. All are fictional cartoon characters.
 *
 *   TR.personas.LIST()                    – the four guides
 *   TR.personas.current()                 – the chosen guide
 *   TR.personas.draw(mood, size, id?, c?) – an animated SVG; mood is 'wave', 'think' or 'cheer'
 *   TR.personas.country()                 – always 'IN' (kept for older callers)
 *
 * Every figure uses the same class names (hp-body, hp-eyes, hp-arm, hp-mouth, hp-dots, hp-confetti, hp-wheel), so one set of
 * CSS animations in app-shell.css moves them all. With motion off (Settings or the system), nothing moves.
 *
 * People are [name, 'f'|'m', skin, hair, hairStyle, face?]. */
(function () {
  'use strict';
  const NS = 'http://www.w3.org/2000/svg';
  function svg(tag, attrs = {}, kids = []) { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs)) if (v != null) e.setAttribute(k, String(v)); kids.filter(Boolean).forEach((k) => e.appendChild(k)); return e; }

  // ------------------------------------------------------------------ who
  const ROLES = {
    tech: { role: 'Workshop technician', blurb: 'Practical and quick. Knows every truck by its chassis number.', look: { hat: 'hard', jacket: '#1565c0', vest: true, headset: true, prop: 'tablet' } },
    engineer: { role: 'Software engineer', blurb: 'Calm and precise. Loves a clean validation result.', look: { jacket: '#2e7d32', collar: '#a5d6a7', glasses: true, prop: 'wrench' } },
    analyst: { role: 'Data analyst', blurb: 'Curious and cheerful. Reads a dashboard like a story.', look: { jacket: '#8e24aa', collar: '#ffffff', prop: 'laptop' } },
    truck: { role: 'Friendly truck', blurb: 'A modern high-performance truck, happy to help. Has never missed a service pack.', look: { truck: true } },
  };
  const ORDER = ['tech', 'engineer', 'analyst', 'truck'];
  /** Skin tones and hair colours, light to dark. */
  const SKIN = ['#fde6d6', '#f8d6c0', '#f1c6a8', '#e9b897', '#e0aa88', '#d49c7b', '#bf8667', '#a06d52'];
  const HAIR = { black: '#1c1310', brown: '#4a2c1a', dark: '#2b1a12', auburn: '#7a3b1e', blonde: '#d8b467', red: '#a8462a', grey: '#9e9e9e' };
  // Three people: technician, engineer, analyst. Styles: braid, bun, short, curly, bob, long.
  // An optional sixth item sets the face: { moustache: true } (a moustache instead of the default beard rule).
  // The four guides are the same everywhere: Asha, Ravi and Meera from India, and Truxie.
  const PEOPLE = {
    IN: [['Asha', 'f', 4, 'dark', 'long'], ['Ravi', 'm', 5, 'black', 'short', { moustache: true }], ['Meera', 'f', 3, 'dark', 'curly']],
  };
  const VOICE = {
    f: ['female', 'neerja', 'aria', 'jenny', 'sonia', 'libby', 'sofie', 'hillevi', 'katja', 'denise', 'elsa', 'isabella', 'nanami', 'xiaoxiao', 'premwadee', 'natasha', 'dalia', 'clara', 'zira', 'swara', 'emma', 'ava', 'michelle', 'agnieszka', 'fenna', 'emine', 'leah'],
    m: ['male', 'prabhat', 'guy', 'ryan', 'thomas', 'mattias', 'conrad', 'henri', 'diego', 'keita', 'yunxi', 'niwat', 'william', 'jorge', 'liam', 'david', 'mark', 'george', 'hemant', 'andrew', 'marek', 'maarten', 'ahmet', 'luke'],
  };
  // The old guide ids still work.
  const ALIAS = { asha: 'tech', ravi: 'engineer', meera: 'analyst', truxie: 'truck' };
  const roleOf = (id) => (ROLES[ALIAS[id] || id] ? ALIAS[id] || id : 'tech');
  const country = () => 'IN';
  /** The guide for a role. */
  function make(id, c = country()) {
    const role = roleOf(id), people = PEOPLE.IN, r = ROLES[role];
    if (role === 'truck') return { id: role, name: 'Truxie', role: r.role, blurb: r.blurb, country: c, look: r.look, voice: { hints: VOICE.f, pitch: 1.3 } };
    const [name, gender, skin, hair, style, face = {}] = people[ORDER.indexOf(role)];
    const beard = face.beard !== undefined ? face.beard : !face.moustache && gender === 'm' && role === 'engineer' && skin % 2 === 1;
    return { id: role, name, gender, role: r.role, blurb: r.blurb, country: c, look: Object.assign({ skin: SKIN[skin], hair: HAIR[hair], style, beard, moustache: !!face.moustache, earring: gender === 'f' && style !== 'long' }, r.look),
      voice: { hints: VOICE[gender], pitch: gender === 'f' ? 1.08 : 0.95 } };
  }
  const LIST = (c = country()) => ORDER.map((id) => make(id, c));
  const current = () => make((TR.prefs && TR.prefs.get('guide')) || 'tech');

  // ------------------------------------------------------------------ people
  function person(p, mood) {
    const L = p.look, skin = L.skin, hair = L.hair, J = L.jacket;
    const kids = [];
    kids.push(svg('path', { d: 'M54 124 Q44 138 46 152', stroke: J, 'stroke-width': 13, 'stroke-linecap': 'round', fill: 'none' }));
    if (L.prop === 'tablet') kids.push(svg('rect', { x: 28, y: 134, width: 28, height: 36, rx: 4, fill: '#263238' }), svg('rect', { x: 31, y: 138, width: 22, height: 26, rx: 2, fill: '#90caf9' }),
      svg('path', { d: 'M36 152 l4 4 8 -9', stroke: '#1565c0', 'stroke-width': 2.4, fill: 'none', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }));
    if (L.prop === 'wrench') kids.push(svg('path', { d: 'M40 168 L52 136', stroke: '#90a4ae', 'stroke-width': 6, 'stroke-linecap': 'round' }), svg('path', { d: 'M48 132 a7 7 0 1 1 10 4 l-3 -5 -5 1 z', fill: '#90a4ae' }));
    if (L.prop === 'laptop') kids.push(svg('rect', { x: 22, y: 140, width: 38, height: 26, rx: 3, fill: '#37474f' }), svg('rect', { x: 25, y: 143, width: 32, height: 20, rx: 2, fill: '#b3e5fc' }),
      svg('path', { d: 'M29 158 l6 -6 5 4 8 -9', stroke: '#8e24aa', 'stroke-width': 2, fill: 'none', 'stroke-linecap': 'round' }), svg('rect', { x: 18, y: 166, width: 46, height: 4, rx: 2, fill: '#546e7a' }));
    kids.push(svg('circle', { cx: 47, cy: 154, r: 6.5, fill: skin }));
    // long hair falls behind the shoulders
    if (L.style === 'long') kids.push(svg('path', { d: 'M42 66 Q34 120 50 134 L110 134 Q126 120 118 66 Z', fill: hair }));
    kids.push(svg('path', { d: 'M48 122 Q80 106 112 122 L118 180 Q80 188 42 180 Z', fill: J }));
    if (L.vest) kids.push(svg('path', { d: 'M54 118 Q62 112 70 112 L74 182 L46 180 Z', fill: '#ffb300' }), svg('path', { d: 'M106 118 Q98 112 90 112 L86 182 L114 180 Z', fill: '#ffb300' }),
      svg('rect', { x: 47, y: 152, width: 27, height: 5, fill: '#eceff1' }), svg('rect', { x: 86, y: 152, width: 27, height: 5, fill: '#eceff1' }));
    if (L.collar) kids.push(svg('path', { d: 'M68 112 L80 130 L92 112 Z', fill: L.collar }), svg('path', { d: 'M66 112 L76 124 L70 112 Z M94 112 L84 124 L90 112 Z', fill: J, opacity: 0.7 }));
    kids.push(svg('rect', { x: 72, y: 98, width: 16, height: 16, rx: 6, fill: skin }));
    const head = [];
    if (L.style === 'braid') head.push(svg('path', { d: 'M110 78 Q122 96 118 120', stroke: hair, 'stroke-width': 7, 'stroke-linecap': 'round', fill: 'none' }));
    if (L.style === 'bun') head.push(svg('circle', { cx: 80, cy: L.hat ? 22 : 34, r: 11, fill: hair }));
    if (L.style === 'curly') [[48, 60, 12], [58, 46, 13], [74, 38, 14], [92, 38, 14], [106, 46, 13], [114, 60, 12], [46, 76, 9], [116, 76, 9]].forEach(([cx, cy, r]) => head.push(svg('circle', { cx, cy, r, fill: hair })));
    if (L.style === 'bob') head.push(svg('path', { d: 'M42 74 Q38 40 80 36 Q122 40 118 74 L118 92 Q112 96 108 90 L108 70 L52 70 L52 90 Q48 96 42 92 Z', fill: hair }));
    // curly: big, soft volume at the sides down to the shoulders
    if (L.style === 'curly') [[42, 90, 12], [118, 90, 12], [44, 106, 10], [116, 106, 10], [50, 118, 8], [110, 118, 8]].forEach(([cx, cy, r]) => head.push(svg('circle', { cx, cy, r, fill: hair })));
    head.push(svg('circle', { cx: 44, cy: 74, r: 6, fill: skin }), svg('circle', { cx: 116, cy: 74, r: 6, fill: skin }));
    if (L.earring) head.push(svg('circle', { cx: 44, cy: 82, r: 2.2, fill: '#ffca28' }));
    if (L.style === 'long') head.push(
      svg('path', { d: 'M48 64 Q36 92 40 124 Q42 146 54 156 Q62 154 62 146 Q54 128 56 104 Q57 86 62 70 Z', fill: hair }),
      svg('path', { d: 'M112 64 Q124 92 120 124 Q118 146 106 156 Q98 154 98 146 Q106 128 104 104 Q103 86 98 70 Z', fill: hair }),
      svg('path', { d: 'M46 120 Q50 136 56 148 M114 120 Q110 136 104 148', stroke: 'rgba(255,255,255,.12)', 'stroke-width': 2, fill: 'none', 'stroke-linecap': 'round' }));
    head.push(svg('circle', { cx: 80, cy: 72, r: 36, fill: skin }));
    if (['braid', 'bun', 'long'].includes(L.style)) head.push(svg('path', { d: 'M45 70 Q46 46 80 44 Q114 46 115 70 Q108 58 96 56 Q80 52 64 56 Q52 58 45 70 Z', fill: hair }));
    if (L.style === 'short') head.push(svg('path', { d: 'M44 70 Q42 38 80 36 Q118 38 116 70 Q112 54 100 52 Q86 46 70 50 Q54 52 44 70 Z', fill: hair }), svg('rect', { x: 43, y: 64, width: 5, height: 14, rx: 2, fill: hair }), svg('rect', { x: 112, y: 64, width: 5, height: 14, rx: 2, fill: hair }));
    if (L.style === 'curly') {
      head.push(svg('path', { d: 'M43 74 Q38 32 80 30 Q122 32 117 74 Q112 58 98 55 Q80 50 62 55 Q48 58 43 74 Z', fill: hair }));
      [[47, 66, 8], [52, 56, 9], [62, 48, 10], [76, 44, 10], [90, 44, 10], [103, 48, 10], [111, 57, 9], [114, 67, 8], [69, 54, 7], [84, 52, 7], [98, 54, 7]].forEach(([cx, cy, r]) => head.push(svg('circle', { cx, cy, r, fill: hair })));
    }
    if (L.style === 'bob') head.push(svg('path', { d: 'M46 66 Q50 44 80 42 Q110 44 114 66 Q100 54 80 58 Q62 54 46 66 Z', fill: hair }));
    if (L.hat === 'hard') head.push(svg('path', { d: 'M42 58 Q44 22 80 20 Q116 22 118 58 Z', fill: '#ffc107' }), svg('rect', { x: 76, y: 21, width: 8, height: 35, rx: 3, fill: '#ffd54f' }), svg('rect', { x: 36, y: 54, width: 88, height: 8, rx: 4, fill: '#ffb300' }));
    if (L.beard) head.push(svg('path', { d: 'M50 82 Q54 110 80 112 Q106 110 110 82 Q104 98 92 100 Q80 104 68 100 Q56 98 50 82 Z', fill: hair }));
    head.push(svg('path', { class: 'hp-brow', d: 'M60 64 Q66 60 72 63', stroke: hair, 'stroke-width': 2.6, fill: 'none', 'stroke-linecap': 'round' }),
      svg('path', { class: 'hp-brow', d: 'M88 63 Q94 60 100 64', stroke: hair, 'stroke-width': 2.6, fill: 'none', 'stroke-linecap': 'round' }),
      svg('g', { class: 'hp-eyes' }, [svg('ellipse', { cx: 66, cy: 74, rx: 4.2, ry: 5, fill: '#1b0f0a' }), svg('ellipse', { cx: 94, cy: 74, rx: 4.2, ry: 5, fill: '#1b0f0a' }),
        svg('circle', { cx: 67.6, cy: 72.4, r: 1.4, fill: '#fff' }), svg('circle', { cx: 95.6, cy: 72.4, r: 1.4, fill: '#fff' })]));
    if (L.glasses) head.push(svg('circle', { cx: 66, cy: 74, r: 9, fill: 'none', stroke: '#263238', 'stroke-width': 2.4 }), svg('circle', { cx: 94, cy: 74, r: 9, fill: 'none', stroke: '#263238', 'stroke-width': 2.4 }), svg('path', { d: 'M75 73 Q80 70 85 73', stroke: '#263238', 'stroke-width': 2.4, fill: 'none' }));
    head.push(svg('circle', { cx: 57, cy: 86, r: 6, fill: '#ff8a80', opacity: L.beard ? 0 : 0.35 }), svg('circle', { cx: 103, cy: 86, r: 6, fill: '#ff8a80', opacity: L.beard ? 0 : 0.35 }),
      svg('path', { d: 'M80 78 Q77 85 82 86', stroke: 'rgba(90,50,30,.55)', 'stroke-width': 2, fill: 'none', 'stroke-linecap': 'round' }),
      svg('path', { class: 'hp-mouth', d: mood === 'think' ? 'M71 92 Q80 99 89 92' : 'M68 91 Q80 105 92 91 Z', fill: mood === 'think' ? 'none' : '#7b2d26', stroke: '#7b3f2a', 'stroke-width': 2, 'stroke-linecap': 'round' }));
    if (L.moustache) head.push(svg('path', { d: 'M63 91 Q68 82 80 87 Q92 82 97 91 Q93 95 87 92 Q83 90 80 91 Q77 90 73 92 Q67 95 63 91 Z', fill: hair }));
    if (L.headset) head.push(svg('path', { d: 'M116 78 Q112 94 97 96', stroke: '#37474f', 'stroke-width': 2.5, fill: 'none', 'stroke-linecap': 'round' }), svg('circle', { cx: 96, cy: 96, r: 3, fill: '#37474f' }));
    kids.push(svg('g', { class: 'hp-head' }, head));
    kids.push(svg('g', { class: 'hp-arm' }, [svg('path', { d: 'M110 124 Q132 114 138 92', stroke: J, 'stroke-width': 13, 'stroke-linecap': 'round', fill: 'none' }), svg('circle', { cx: 139, cy: 86, r: 8, fill: skin })]));
    return svg('g', { class: 'hp-body' }, kids);
  }

  // ------------------------------------------------------------------ Truxie, a modern high-performance tractor unit
  // A sleek aero cab, two-tone: metallic electric blue over graphite, split by a cyan accent sweep, a raked panoramic windscreen (her face), a
  // full-width LED light bar, slim wrap-around headlights, a closed aero front panel whose LED smile lights up, a roof light
  // bar, camera mirrors, chassis fairings, a side skirt and large aero wheel covers. A generic modern truck: no brand marks.
  function truck(p, mood) {
    const stop = (offset, color) => svg('stop', { offset, 'stop-color': color });
    const defs = svg('defs', {}, [
      svg('linearGradient', { id: 'tx-paint', x1: 0, y1: 0, x2: 0, y2: 1 }, [stop('0', '#5aa2ff'), stop('.5', '#1f66d1'), stop('1', '#0d3a80')]),
      svg('linearGradient', { id: 'tx-glass', x1: 0, y1: 0, x2: 1, y2: 1 }, [stop('0', '#eef8ff'), stop('1', '#86bfec')]),
      svg('linearGradient', { id: 'tx-accent', x1: 0, y1: 0, x2: 1, y2: 0 }, [stop('0', '#0f6cbd'), stop('1', '#22d3ee')]),
    ]);
    const wheel = (cx, cy) => svg('g', { class: 'hp-wheel', style: `transform-origin:${cx}px ${cy}px` }, [
      svg('circle', { cx, cy, r: 15, fill: '#12161c' }),
      svg('circle', { cx, cy, r: 10.5, fill: '#2a333e' }),
      svg('circle', { cx, cy, r: 10.5, fill: 'none', stroke: '#22d3ee', 'stroke-width': 1.3, opacity: 0.85 }),
      svg('path', { d: [0, 60, 120, 180, 240, 300].map((a) => { const r = a * Math.PI / 180; return `M${(cx + 3.5 * Math.cos(r)).toFixed(1)},${(cy + 3.5 * Math.sin(r)).toFixed(1)} L${(cx + 9 * Math.cos(r)).toFixed(1)},${(cy + 9 * Math.sin(r)).toFixed(1)}`; }).join(' '), stroke: '#8a99a6', 'stroke-width': 2.2, 'stroke-linecap': 'round' }),
      svg('circle', { cx, cy, r: 3, fill: '#d5dde3' })]);
    const kids = [
      defs,
      // chassis fairing with the fifth wheel, and the wheel arches
      svg('rect', { x: 26, y: 110, width: 36, height: 6, rx: 2, fill: '#3b4654' }),
      svg('path', { d: 'M12 150 L12 126 Q12 116 22 116 L78 116 L78 158 L22 158 Q12 158 12 150 Z', fill: '#18212c' }),
      svg('rect', { x: 12, y: 140, width: 66, height: 3, fill: 'url(#tx-accent)' }),
      svg('circle', { cx: 40, cy: 163, r: 17, fill: '#090d12' }), svg('circle', { cx: 68, cy: 163, r: 17, fill: '#090d12' }), svg('circle', { cx: 136, cy: 163, r: 17, fill: '#090d12' }),
      // aero side extender behind the cab
      svg('path', { d: 'M78 46 L62 56 Q60 58 60 62 L60 116 L78 116 Z', fill: '#1a2330' }),
      // cab, roof highlight and roof light bar
      svg('path', { d: 'M76 158 L76 60 Q76 38 100 36 L130 36 Q148 37 153 56 L160 98 Q164 112 163 132 L163 150 Q163 158 155 158 Z', fill: 'url(#tx-paint)' }),
      svg('path', { d: 'M84 46 Q92 39 104 39 L128 39 Q140 40 146 49', stroke: '#bfe0ff', 'stroke-width': 2, opacity: 0.7, fill: 'none', 'stroke-linecap': 'round' }),
      svg('rect', { x: 96, y: 31, width: 36, height: 4, rx: 2, fill: '#e6fbff' }),
      svg('rect', { x: 96, y: 31, width: 36, height: 4, rx: 2, fill: '#22d3ee', opacity: 0.35, class: 'tx-led-glow' }),
      // door window and the raked panoramic windscreen
      svg('path', { d: 'M82 52 Q84 46 92 46 L100 46 L100 82 L82 82 Z', fill: 'url(#tx-glass)', opacity: 0.85 }),
      svg('path', { d: 'M104 50 Q106 44 116 44 L136 44 Q146 45 149 58 L155 94 L104 94 Z', fill: 'url(#tx-glass)', stroke: '#0b1119', 'stroke-width': 1.5 }),
      svg('path', { d: 'M110 88 L124 50', stroke: '#fff', 'stroke-width': 3, opacity: 0.4, 'stroke-linecap': 'round' }),
      // her face in the windscreen
      svg('g', { class: 'hp-eyes' }, [svg('ellipse', { cx: 121, cy: 68, rx: 5, ry: 6.5, fill: '#0e2038' }), svg('ellipse', { cx: 140, cy: 68, rx: 5, ry: 6.5, fill: '#0e2038' }),
        svg('circle', { cx: 123, cy: 66, r: 1.8, fill: '#fff' }), svg('circle', { cx: 142, cy: 66, r: 1.8, fill: '#fff' })]),
      svg('path', { class: 'hp-brow', d: 'M115 58 Q121 55 126 58', stroke: '#0b1119', 'stroke-width': 2.4, fill: 'none', 'stroke-linecap': 'round' }),
      svg('path', { class: 'hp-brow', d: 'M134 58 Q140 55 145 58', stroke: '#0b1119', 'stroke-width': 2.4, fill: 'none', 'stroke-linecap': 'round' }),
      svg('circle', { cx: 113, cy: 81, r: 3.8, fill: '#ff8a80', opacity: 0.45 }), svg('circle', { cx: 148, cy: 81, r: 3.8, fill: '#ff8a80', opacity: 0.45 }),
      // full-width LED light bar and slim wrap-around headlight
      svg('path', { d: 'M104 100 L162 100', stroke: '#22d3ee', 'stroke-width': 7, opacity: 0.35, 'stroke-linecap': 'round', class: 'tx-led-glow' }),
      svg('path', { d: 'M104 100 L162 100', stroke: '#e6fbff', 'stroke-width': 2.6, 'stroke-linecap': 'round' }),
      svg('path', { d: 'M151 106 L162 106 L162 122', stroke: '#e6fbff', 'stroke-width': 2.6, fill: 'none', 'stroke-linecap': 'round', 'stroke-linejoin': 'round' }),
      // closed aero front panel with her LED smile
      svg('rect', { x: 110, y: 108, width: 46, height: 26, rx: 8, fill: '#0a0f16' }),
      svg('path', { d: 'M114 114 H152 M114 120 H152 M114 126 H152', stroke: '#16304b', 'stroke-width': 1.2 }),
      svg('path', { class: 'hp-mouth', d: mood === 'think' ? 'M118 120 Q133 128 148 120' : 'M117 117 Q133 132 149 117 Z', fill: mood === 'think' ? 'none' : '#bff4ff', stroke: '#22d3ee', 'stroke-width': 2, 'stroke-linecap': 'round' }),
      // door, accent sweep, side skirt, bumper and camera mirror
      svg('rect', { x: 80, y: 50, width: 22, height: 94, rx: 4, fill: 'none', stroke: '#0b1119', 'stroke-width': 1.2, opacity: 0.55 }),
      svg('rect', { x: 94, y: 98, width: 6, height: 2, rx: 1, fill: '#8a99a6' }),
      svg('path', { d: 'M76 133 Q112 125 163 141 L163 150 Q163 158 155 158 L76 158 Z', fill: '#1a2330' }),
      svg('path', { d: 'M78 132 Q112 124 162 140', stroke: 'url(#tx-accent)', 'stroke-width': 4, fill: 'none', 'stroke-linecap': 'round' }),
      svg('path', { d: 'M90 148 L120 148 L120 158 L90 158 Z', fill: '#0a0f16' }), svg('rect', { x: 90, y: 147, width: 30, height: 2, fill: '#22d3ee', opacity: 0.8 }),
      svg('rect', { x: 108, y: 139, width: 57, height: 9, rx: 4, fill: '#0a0f16' }),
      svg('path', { d: 'M151 56 L165 52', stroke: '#0b1119', 'stroke-width': 3, 'stroke-linecap': 'round' }),
      svg('rect', { x: 162, y: 49, width: 6, height: 12, rx: 2, fill: '#0b1119' }), svg('circle', { cx: 165, cy: 57, r: 1.3, fill: '#22d3ee' }),
      wheel(40, 163), wheel(68, 163), wheel(136, 163),
      // roof antenna with a pennant: her "arm" for waving
      svg('g', { class: 'hp-arm', style: 'transform-origin:110px 34px' }, [svg('path', { d: 'M110 34 L114 10', stroke: '#5b6b7a', 'stroke-width': 2.5, 'stroke-linecap': 'round' }), svg('path', { d: 'M114 10 L134 15 L115 22 Z', fill: '#ffb300' })]),
    ];
    return svg('g', { class: 'hp-body' }, kids);
  }

  /** An animated guide. id is a role ('tech', 'engineer', 'analyst', 'truck', or an old id such as 'asha'); c a country code. */
  function draw(mood = 'wave', size = 150, id, c) {
    if ((TR.prefs && TR.prefs.get('personas') === false) || (TR.features && !TR.features.on('guides'))) return svg('svg', { class: 'hp-persona is-off', width: 0, height: 0, 'aria-hidden': 'true' });
    const p = id ? make(id, c === undefined ? country() : c) : current();
    // Each figure blinks and glances on its own rhythm, so several guides on one page never move in step.
    const delay = ((p.name.length * 7 + size) % 50) / 10;
    return svg('svg', { class: `hp-persona mood-${mood} persona-${p.id}`, style: `--hp-delay:${delay}s`, viewBox: '0 0 170 190', width: size, height: Math.round(size * 190 / 170), role: 'img', 'aria-label': `${p.name}, ${p.role}` }, [
      svg('ellipse', { class: 'hp-shadow', cx: p.look.truck ? 88 : 80, cy: 183, rx: p.look.truck ? 66 : 40, ry: 6, fill: 'rgba(0,0,0,.14)' }),
      p.look.truck ? truck(p, mood) : person(p, mood),
      svg('g', { class: 'hp-dots' }, [svg('circle', { cx: 126, cy: 40, r: 3.5 }), svg('circle', { cx: 136, cy: 28, r: 5 }), svg('circle', { cx: 148, cy: 14, r: 6.5 })]),
      svg('g', { class: 'hp-confetti' }, [['#ef5350', 20, 30], ['#42a5f5', 136, 22], ['#66bb6a', 30, 8], ['#ffca28', 120, 6], ['#ab47bc', 150, 44]].map(([col, x, y], i) =>
        svg('rect', { x, y, width: 6, height: 10, rx: 1.5, fill: col, style: `animation-delay:${i * 0.25}s` }))),
    ]);
  }

  /**
   * Quick, one-off actions after something happens. When idle, only the eyes move.
   *   celebrate – hop, wave and confetti (success)        nod     – a friendly nod (information)
   *   shrug     – arm out, head tilted (nothing found)     wave    – hello
   *   hop · wiggle · peek · stretch                        drive   – Truxie rolls forward and back
   * Clicking a guide makes it do one at random. scope limits the action to one container. Nothing moves with motion off. */
  const ACTIONS = ['celebrate', 'nod', 'shrug', 'wave', 'hop', 'wiggle', 'peek', 'stretch', 'drive'];
  function react(scope, action = 'celebrate') {
    if (typeof document.querySelectorAll !== 'function' || document.documentElement.dataset.motion === 'reduced') return;
    const root = scope && scope.classList && scope.classList.contains('hp-persona') ? { querySelectorAll: () => [scope] } : scope || document;
    root.querySelectorAll('.hp-persona').forEach((el) => {
      const name = action === 'random' ? ACTIONS[Math.floor(Math.random() * ACTIONS.length)] : action;
      const act = el.classList.contains('persona-truck') && ['wave', 'hop', 'celebrate'].includes(name) ? name + ' is-act-drive' : name;
      ACTIONS.forEach((x) => el.classList.remove('is-act-' + x));
      el.classList.remove('is-react');
      void el.getBoundingClientRect(); // restart the animation
      act.split(' ').forEach((c) => el.classList.add(c.startsWith('is-') ? c : 'is-act-' + c));
      clearTimeout(el._actTimer);
      el._actTimer = setTimeout(() => ACTIONS.forEach((x) => el.classList.remove('is-act-' + x)), 1800);
    });
  }
  if (typeof document.addEventListener === 'function') document.addEventListener('click', (e) => { const el = e.target && e.target.closest && e.target.closest('.hp-persona'); if (el) react(el, 'random'); });

  TR.personas = { LIST, current, draw, make, country, react, ACTIONS, PEOPLE, ROLES, ORDER, roleOf, get byId() { return Object.fromEntries(LIST().map((p) => [p.id, p])); } };
})();
