/* Request execution: follow each stage of one of your requests and see where the time went
 * (server: /api/v1/requests/{id}/trace). Stages are measured on the server while the request ran (TimeProvider timestamps);
 * queueing comes from the job when the request went through the queue. The sanitised trace holds stage names, timings,
 * vehicle ids and counts only — no payload content — and can be viewed in a side panel or saved as JSON. */
(function () {
  'use strict';
  const { h } = TR.util;
  const J = TR.journey, t = J.t;
  const E = { id: null, data: null, error: null, review: null, selected: null, filter: 'all', services: true };

  async function load(id) {
    E.id = id; E.data = null; E.error = null; E.review = null; E.selected = null; TR.app.refresh();
    try {
      E.data = await J.api('/requests/' + encodeURIComponent(id) + '/trace');
      const warn = E.data.stages.find((s) => s.outcome !== 'completed');
      E.selected = (warn || E.data.stages[0] || {}).order;
      E.review = await J.api('/reviews/by-request/' + encodeURIComponent(id)).catch(() => null);
    } catch (e) { E.error = e.message; }
    TR.app.refresh();
  }

  // ------------------------------------------------------------------ the timeline scale (exported for tests)
  /** Ticks for an axis from 0 to total ms: a 1-2-5 step giving at most about six ticks, plus the end. */
  function ticks(total) {
    const max = Math.max(1, total);
    const raw = max / 5, pow = Math.pow(10, Math.floor(Math.log10(raw)));
    const step = [1, 2, 5, 10].map((m) => m * pow).find((s) => s >= raw) || raw;
    const list = []; for (let v = 0; v < max - step * 0.6; v += step) list.push(v);
    list.push(max);
    return list;
  }
  const pct = (v, total) => Math.max(0, Math.min(100, (100 * v) / Math.max(1, total)));
  function visible(stages, f, services) {
    return stages.filter((s) => (services || s.kind !== 'service') && (f === 'all' || (f === 'warnings' ? s.outcome !== 'completed' : f === 'services' ? s.kind === 'service' : s.vehicleId === f || s.vehicleId == null)));
  }

  // ------------------------------------------------------------------ pieces
  const tone = (s) => (s.kind === 'queue' ? 'queue' : s.outcome === 'warning' ? 'warning' : s.outcome === 'failed' ? 'danger' : s.kind === 'service' ? 'info' : 'good');
  function timeline(d) {
    const total = d.totals.elapsedMs, ts = ticks(total);
    const list = visible(d.stages, E.filter, E.services);
    const vehicles = d.vehicles.length > 1 ? d.vehicles.map((v) => [v.id, v.title]) : [];
    const keyNav = (e, i) => {
      if (e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
      e.preventDefault();
      const next = list[Math.max(0, Math.min(list.length - 1, i + (e.key === 'ArrowDown' ? 1 : -1)))];
      E.selected = next.order; TR.app.refresh();
      setTimeout(() => { const b = document.querySelector('.ex-row[data-order="' + next.order + '"]'); if (b) b.focus(); }, 0);
    };
    return J.card(t('Execution timeline'), [
      J.select('Stages', E.filter, [['all', 'All stages'], ['warnings', 'Warnings only'], ['services', 'Integration calls']].concat(vehicles), (v) => { E.filter = v; TR.app.refresh(); }),
      h('label', { class: 'jr-switch' }, h('input', { type: 'checkbox', role: 'switch', checked: E.services, onChange: (e) => { E.services = e.target.checked; TR.app.refresh(); } }), h('span', { class: 'jr-switch-track', 'aria-hidden': 'true' }), t('Show service calls')),
      h('span', { class: 'muted jr-hint', 'data-tip': t('Times relative to acceptance|0 s is when the request was accepted; queueing is included.') }, TR.icon('info', 14), t('Times relative to acceptance'))],
      h('div', { class: 'ex-gantt', role: 'list', 'aria-label': t('Stages') },
        h('div', { class: 'ex-axis', 'aria-hidden': 'true' }, h('span', null, '#'), h('span', null, t('Stage')), h('span', { class: 'ex-scale' }, ts.map((v) => h('i', { style: { left: pct(v, total) + '%' } }, J.secs(v)))), h('span', null, t('Duration'))),
        list.length ? list.map((s, i) => h('button', { class: ['ex-row', 'tone-' + tone(s), E.selected === s.order ? 'is-sel' : ''], role: 'listitem', 'data-order': s.order, 'aria-pressed': String(E.selected === s.order),
          'aria-label': t('{n}. {s}: starts at {a}, takes {d}, {o}', { n: i + 1, s: s.name, a: J.secs(s.startMs), d: J.secs(s.durationMs), o: J.state(s.outcome === 'completed' ? 'completed' : s.outcome)[0] }),
          onClick: () => { E.selected = s.order; TR.app.refresh(); }, onKeydown: (e) => keyNav(e, i) },
          h('span', { class: 'ex-n' }, String(i + 1)),
          h('span', { class: 'ex-name' }, s.name.replace(/^Rule check: /, t('Rule check') + ': '), s.vehicleId && d.vehicles.length > 1 ? h('small', { class: 'muted' }, ' · ' + s.vehicleId.replace('|', ' ')) : null),
          h('span', { class: 'ex-track' }, ts.map((v) => h('i', { class: 'ex-grid', style: { left: pct(v, total) + '%' } })),
            h('span', { class: 'ex-bar', style: { left: pct(s.startMs, total) + '%', width: 'max(3px, ' + pct(s.durationMs, total) + '%)' } }, s.outcome === 'warning' ? TR.icon('alert', 12) : null),
            h('span', { class: 'ex-bar-label', style: { left: 'calc(' + pct(s.startMs + s.durationMs, total) + '% + 6px)' } }, J.secs(s.durationMs))),
          h('span', { class: 'ex-dur' }, J.secs(s.durationMs)))) : J.empty('No stages match', 'Choose All stages.')),
      h('h3', { class: 'jr-h4' }, t('Execution events')),
      h('ol', { class: 'ex-events' }, d.events.map((e) => h('li', { class: 'tone-' + e.tone }, h('span', { class: 'ex-at' }, J.secs(e.atMs)), h('i', { class: 'ex-dot', 'aria-hidden': 'true' }), h('span', null, e.text)))));
  }
  function details(d) {
    const s = d.stages.find((x) => x.order === E.selected);
    if (!s) return h('aside', { class: 'jr-side' }, J.card('Stage details', null, h('p', { class: 'muted' }, t('Choose a stage.'))));
    const mine = TR.backend && TR.backend.latest && TR.backend.latest.id === d.id;
    const finding = s.outcome === 'warning' ? (s.note ? t('This stage found something to review: {n}.', { n: s.note }) : t('This stage found something to review.')) + ' ' + t('Review the result before continuing.') : null;
    return h('aside', { class: 'jr-side' },
      J.card(h('h2', null, t('Stage details')), null,
        h('div', { class: 'jr-side-title' }, h('strong', { class: 'jr-big' }, s.name), J.chip(s.kind === 'queue' ? 'queued' : s.outcome === 'completed' ? 'completed' : s.outcome)),
        J.facts([['Started', '+' + J.secs(s.startMs)], ['Duration', J.secs(s.durationMs)], ['Kind', s.kind === 'service' ? t('Integration call') : s.kind === 'queue' ? t('Queue') : t('Processing')],
          ['Attempts', d.job ? String(Math.max(1, d.job.attempts || d.job.attempt)) : '1'], ['Vehicle', s.vehicleId ? s.vehicleId.replace('|', ' ') : t('All')], ['Outcome', s.note || J.state(s.outcome === 'completed' ? 'completed' : s.outcome)[0]]]),
        finding ? h('div', { class: 'jr-finding' }, h('h3', { class: 'jr-h4' }, t('Finding')), h('p', null, finding)) : null,
        h('div', { class: 'jr-stack' },
          TR.pages.ui.button(t('Open validation findings'), 'arrow', () => { if (mine) { if (TR.experience) TR.experience.page = null; TR.testRequest.page(); TR.testRequest.stage = 'validate'; TR.app.refresh(); } else if (E.review) J.open('review', { rid: E.review.id }); else J.open('impact', { rid: d.id, vid: d.vehicles[0] && d.vehicles[0].id }); }, 'primary'),
          TR.pages.ui.button(t('View sanitized trace'), 'code', () => sanitized(d), 'secondary'),
          TR.pages.ui.button(t('Related events'), 'file', () => J.open('logs', { rid: d.label }), 'text')),
        h('div', { class: 'jr-traceid' }, h('span', { class: 'muted' }, t('Trace ID')), h('code', null, d.traceId.slice(0, 4) + '…' + d.traceId.slice(-4)),
          h('button', { class: 'ap-icon-btn', 'aria-label': t('Copy trace ID'), onClick: () => J.copy(d.traceId, 'Trace ID') }, TR.icon('copy', 16)))),
      h('div', { class: 'jr-legend' }, [['good', 'Completed'], ['warning', 'Warning'], ['info', 'Integration call'], ['queue', 'Queue']].map(([k, l]) => h('span', null, h('i', { class: 'tone-' + k }), t(l)))));
  }
  const sanitizedText = (d) => JSON.stringify({ request: d.label, traceId: d.traceId, kind: d.kind, createdAt: d.createdAt, status: d.status, totals: d.totals, job: d.job, vehicles: d.vehicles, stages: d.stages, events: d.events, note: d.note }, null, 2);
  function sanitized(d) {
    TR.ui.panel({ id: 'trace', title: t('Sanitized trace · {r}', { r: d.label }), width: 520, body: () => h('div', { class: 'jr-panel' },
      J.banner('info', 'lock', t('Names, timings, vehicle ids and counts only. No payload content, tokens or personal data.')),
      h('pre', { class: 'jr-pre', tabindex: '0', 'aria-label': t('Sanitized trace') }, sanitizedText(d)),
      h('div', { class: 'jr-stack-row' }, TR.pages.ui.button(t('Copy'), 'copy', () => J.copy(sanitizedText(d), 'Trace'), 'secondary'), TR.pages.ui.button(t('Export trace'), 'download', () => J.download(d.label + '-trace.json', sanitizedText(d)), 'secondary'))) });
  }

  function render() {
    J.readParams();
    const id = J.param('rid', 'execution') || (TR.backend && TR.backend.latest && TR.backend.latest.id);
    if (!id) return h('div', { class: 'jr-page' }, J.pageHead('Request execution', 'Follow each stage and investigate where time was spent.'), J.empty('No request chosen', 'Open a request from Requests, or validate a proposal first.', TR.pages.ui.button(t('Go to Requests'), 'arrow', () => J.open('requests'), 'primary')));
    if (id !== E.id) load(id);
    const d = E.data;
    const head = J.pageHead('Request execution', 'Follow each stage and investigate where time was spent.', [
      d ? TR.pages.ui.button(t('Export trace'), 'download', () => J.download(d.label + '-trace.json', sanitizedText(d)), 'secondary') : null,
      TR.pages.ui.button(t(E.review ? 'Back to review' : 'Back to requests'), 'back', () => (E.review ? J.open('review', { rid: E.review.id }) : J.open('requests')), 'secondary')]);
    if (!d) return h('div', { class: 'jr-page' }, head, E.error ? J.failed(E.error, () => load(id)) : J.loading(6));
    const v = d.vehicles[0];
    return h('div', { class: 'jr-page' }, head,
      h('div', { class: 'jr-meta' }, J.chip(d.status), h('strong', null, d.label), v ? h('span', null, J.vehicleText(v) + (d.vehicles.length > 1 ? ' +' + (d.vehicles.length - 1) : '')) : null,
        E.review && E.review.proposalRevision ? h('span', null, t('Proposal revision {n}', { n: E.review.proposalRevision })) : null, h('span', { class: 'muted' }, J.ago(d.createdAt))),
      J.stats([{ n: J.secs(d.totals.elapsedMs), label: 'Total elapsed' }, { n: J.secs(d.totals.queueMs), label: 'Queue time', sub: d.job ? null : t('Ran directly, not queued') }, { n: J.secs(d.totals.processingMs), label: 'Processing' }, { n: d.totals.warnings, label: 'Warnings', tone: d.totals.warnings ? 'warning' : 'neutral' }]),
      !d.timed ? J.banner('info', 'info', t(d.note)) : null,
      h('div', { class: 'jr-split' }, timeline(d), details(d)),
      h('p', { class: 'jr-foot muted' }, TR.icon('info', 14), ' ', t('Elapsed time includes queueing. This timeline does not represent a vehicle installation.'), ' ', d.timed ? t(d.note) : ''));
  }
  TR.pages.register({ id: 'execution', title: 'Request execution', crumbs: () => [{ label: t('Requests'), open: () => J.open('requests') }, { label: E.data ? E.data.label : t('Request') }, { label: t('Execution') }], render });
  TR.execution = { E, load, ticks, visible, pct };
})();
