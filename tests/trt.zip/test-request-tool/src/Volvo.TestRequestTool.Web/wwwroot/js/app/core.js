/* Shared building blocks for Studio pages. Every new page or setting plugs in here; see docs/ux-architecture.md.
 *
 *   TR.prefs   – user preferences with defaults, saved in this browser
 *   TR.pages   – page registry: id, title, breadcrumbs and render(); pages open with TR.pages.show(id) or ?view=id
 *   TR.pager   – the pager used by every long list (same layout as the DocGen Explorer token table)
 *   TR.nextStep – the single coloured "next step" button in the top bar
 *
 * The module also adds breadcrumbs above every page but Home, a go-to-top button and the theme / motion toggles. */
(function () {
  'use strict';
  const { h } = TR.util;
  const S = TR.testRequest;
  const X = TR.experience;
  const root = document.documentElement;

  // ------------------------------------------------------------------ preferences
  const DEFAULTS = {
    abbreviations: true,   // dotted underline and a tooltip on abbreviations such as EMS (abbreviations.js)
    motion: 'on',          // 'on' | 'off'. Off removes animations everywhere; the OS reduce-motion setting is always honoured.
    textSize: 'default',   // 'default' | 'large' | 'larger'
    nextStep: true,        // show the next-step button
    scenario: 1,           // default scenario for new requests (1 Introduced … 5 In progress)
    pusVersion: '2.0',     // Product Update Service schema
    apuVersion: '1.1',     // Available Product Updates contract
    pageSize: 25,          // rows per page in long lists
    cultureMode: 'account', // 'account' (country of the account, else UTC) | 'custom' | 'system'; see culture.js
    culture: null,         // the culture chosen in Settings or the quick switch
    cultures: [],          // cultures kept for the quick switch in the top bar
    cultureSwitch: true,   // show the culture switch in the top bar
    firstSteps: true,      // show the first-steps checklist on Home and in Help
    tourVoice: true,       // the introduction tour reads each step aloud (browser speech)
    guide: 'asha',         // the animated guide: asha, ravi, meera or truxie (personas.js)
    personas: true,        // show the guide characters at all (Settings → Help → Show guides)
    spellcheck: true,      // wavy underlines and corrections in free-text fields (spellcheck.js)
    usageStudy: true,      // the privacy-friendly usage study (usage.js); offered at first sign-in, changeable on My data
    learning: true,        // Ctrl+K learns what you use most (ml.js); off stops recording
    clocksShown: 2,        // how many time zones the status bar shows together (1–4): yours first, then Other time zones
    inlineZones: false,    // also show those zones beside times on pages
    uiLanguage: 'auto',    // 'auto' | 'en' | any installed language pack (i18n.js, /i18n/languages.json)
    worldClocks: [],       // extra time zones shown for every time (timezones.js)
    experience: 'auto',    // 'auto' | 'beginner' | 'expert' (ux.js)
    expertTools: 'auto',   // 'auto' (administrators) | 'on' | 'off': the Expert tools menu (navigation.js)
    calm: false,           // calm mode: softer colours, no decoration (ux.js)
    nudge: true,           // pulse the next action after a quiet moment (ux.js)
  };
  const listeners = new Set();
  const prefs = {
    defaults: DEFAULTS,
    /**
     * Layers, first that applies: a locked team or organisation setting; your own choice; your team's or the
     * organisation's default; the built-in default (TR.managed, loaded from /api/v1/settings/effective).
     */
    get(key) {
      const m = TR.managed && TR.managed.settings ? TR.managed.settings[key] : null;
      if (m && m.locked) return m.value;
      const NONE = {}, own = TR.util.store.get('trstudio.' + key, NONE);
      if (own !== NONE && own !== undefined) return own;
      return m ? m.value : DEFAULTS[key];
    },
    /** Where the value comes from: 'locked', 'yours', 'managed' or 'default' (with the team or organisation name). */
    source(key) {
      const m = TR.managed && TR.managed.settings ? TR.managed.settings[key] : null;
      if (m && m.locked) return { kind: 'locked', by: m.source };
      const NONE = {}, own = TR.util.store.get('trstudio.' + key, NONE);
      if (own !== NONE && own !== undefined) return { kind: 'yours', by: null, managed: m ? m.source : null };
      return m ? { kind: 'managed', by: m.source } : { kind: 'default', by: null };
    },
    /** Back to the team or organisation default (or the built-in one): forget your own choice. */
    clear(key) { if (TR.util.store.remove) TR.util.store.remove('trstudio.' + key); else localStorage.removeItem('trstudio.' + key); apply(); TR.app.refresh(); },
    set(key, value) {
      const m = TR.managed && TR.managed.settings ? TR.managed.settings[key] : null;
      if (m && m.locked) { if (TR.notify) TR.notify.toast(TR.i18n.t('{s} is set by {by} and cannot be changed.', { s: key, by: m.source }), 'warning'); return; }
      TR.util.store.set('trstudio.' + key, value);
      apply();
      listeners.forEach((fn) => fn(key, value));
      TR.app.refresh();
    },
    reset() {
      Object.keys(DEFAULTS).forEach((k) => TR.util.store.remove ? TR.util.store.remove('trstudio.' + k) : localStorage.removeItem('trstudio.' + k));
      S.setTheme('auto');
      apply();
      TR.app.refresh();
    },
    onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); },
  };

  const osReducedMotion = () => typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches;
  const motionOn = () => prefs.get('motion') !== 'off' && !osReducedMotion();

  /** Mirrors preferences onto <html> so CSS can react: data-motion and data-text-size. */
  function apply() {
    root.dataset.motion = motionOn() ? 'full' : 'reduced';
    root.dataset.textSize = prefs.get('textSize');
  }
  apply();
  // Follow other tabs (for example the UI guide) and OS changes.
  if (typeof addEventListener === 'function') addEventListener('storage', (e) => { if (e.key && e.key.startsWith('trstudio.')) { apply(); TR.app.refresh(); } });
  if (typeof matchMedia === 'function') { const mq = matchMedia('(prefers-reduced-motion: reduce)'); (mq.addEventListener ? mq.addEventListener('change', apply) : mq.addListener && mq.addListener(apply)); }

  // ------------------------------------------------------------------ theme switching (Auto → Light → Dark, like DocGen Explorer)
  const THEME_LABEL = { auto: 'Theme: Auto (follows your system)', 'charcoal-light': 'Theme: Light Charcoal', charcoal: 'Theme: Dark Charcoal' };
  function setTheme(choice) {
    const change = () => { S.setTheme(choice); TR.app.refresh(); };
    // A short cross-fade where the browser supports view transitions and motion is on.
    if (motionOn() && typeof document.startViewTransition === 'function') document.startViewTransition(change); else change();
  }
  function cycleTheme() {
    const order = ['auto', 'charcoal-light', 'charcoal'];
    setTheme(order[(order.indexOf(S.theme) + 1) % order.length]);
  }

  // ------------------------------------------------------------------ page registry
  const pages = new Map();
  function readView() { return new URLSearchParams(location.search).get('view'); }
  function writeView(id) {
    const u = new URL(location.href);
    if (id) u.searchParams.set('view', id); else u.searchParams.delete('view');
    if (id !== 'help') ['article', 'topic', 'q'].forEach((k) => u.searchParams.delete(k)); // Help-only parameters
    // A request or vehicle id belongs to the journey page it was opened for (journey.js); anywhere else it is stale, and a
    // link or reload would carry it to a page that ignores it (the empty Vehicle page with ?vid=…).
    const P = TR.journey && TR.journey.P;
    if (!id || !P || P.page !== id) ['rid', 'vid'].forEach((k) => u.searchParams.delete(k));
    history.replaceState(null, '', u);
  }
  const registry = {
    /** page: { id, title, section?, crumbs?: () => [{label, open?}], render: () => Node } */
    register(page) { pages.set(page.id, page); },
    has(id) { return pages.has(id); },
    get(id) { return pages.get(id); },
    show(id) { writeView(pages.has(id) || ['home','library','admin'].includes(id) ? id : null); X.show(id); },
    current() { return X.page === 'map' ? 'vehicle' : X.page; },
  };

  // Open the page named in ?view= once, after the app has started.
  let initialView = readView();

  const baseWorkspace = S.workspace;
  S.workspace = () => {
    // Scripts load deferred, so an early refresh can come before later pages have registered: keep the link until the
    // page exists or the document has finished loading.
    if (initialView) {
      if (pages.has(initialView) || ['home', 'library', 'learn', 'admin'].includes(initialView)) { X.page = initialView; initialView = null; }
      else if (document.readyState === 'complete') initialView = null;
    }
    if (X.page === 'map') X.page = 'vehicle'; // the old Vehicle map now lives in the Vehicle page
    const page = pages.get(X.page);
    if (!page && readView() && !initialView) writeView(null);
    if (page) return h('div', { class: 'ap-view', 'data-page': page.id }, page.render());
    const view = baseWorkspace();
    // Cards other modules add to Home (for example the first steps from help.js), placed under the heading.
    if (X.page === 'home' && homeCards.length && view && typeof view.querySelector === 'function') {
      const heading = view.querySelector('.s-heading, .jr-head');
      const cards = homeCards.map((fn) => fn()).filter(Boolean);
      if (heading) heading.after(...cards); else if (view.firstElementChild) view.firstElementChild.before(...cards);
    }
    return view;
  };
  const homeCards = [];

  // ------------------------------------------------------------------ breadcrumbs
  const home = () => X.show('home');
  const vehicleLabel = () => { const L = TR.app.shell.left; return L && L.product.loaded() ? L.product.chassisString() : null; };
  const EXPERIENCE_PAGES = { library: 'Saved vehicles', learn: 'Getting started', admin: 'Admin users' };
  const STAGES = { configure: 'Make changes', validate: 'Check', review: 'Get approval' };

  /** Breadcrumb trail for the current screen. The last item is the current location and is not a link. */
  function crumbs() {
    const trail = [{ label: 'Home', open: home }];
    const id = registry.current();
    const page = pages.get(id);
    if (page) return trail.concat(page.crumbs ? page.crumbs() : [{ label: page.title }]);
    if (id === 'home') return [{ label: 'Home' }];
    if (EXPERIENCE_PAGES[id]) return trail.concat({ label: EXPERIENCE_PAGES[id] });
    if (TR.app.page === 'vcads') return trail.concat({ label: 'Expert tools' }, { label: 'VCADS request' });
    if (TR.app.page === 'compare') return trail.concat({ label: 'Expert tools' }, { label: 'Compare breakdown' });
    trail.push({ label: 'Test request', open: () => S.page() });
    if (S.view === 'expert') return trail.concat({ label: 'Two-pane workbench' });
    const v = vehicleLabel();
    if (v) trail.push({ label: v, open: () => registry.show('vehicle') });
    // The last crumb names the stepper's current step: no vehicle yet is Choose vehicle.
    trail.push({ label: v ? STAGES[S.stage] || 'Make changes' : 'Choose vehicle' });
    return trail;
  }

  /** No bar on a root page (Home): a trail of one would only repeat the page's own title. */
  function breadcrumbBar() {
    const trail = crumbs();
    if (trail.length < 2) return null;
    return h('nav', { class: 'ap-crumbs', 'aria-label': 'Breadcrumb' },
      trail.map((c, i) => {
        const last = i === trail.length - 1;
        const item = last || !c.open ? h('span', { 'aria-current': last ? 'page' : null }, c.label) : h('a', { href: '#', onClick: (e) => { e.preventDefault(); c.open(); } }, c.label);
        return i ? [h('span', { class: 'ap-crumb-sep', 'aria-hidden': 'true' }, '/'), item] : item;
      }).flat());
  }

  // ------------------------------------------------------------------ next step
  /**
   * The one thing to do next, so the user never has to work it out. Colour tells the state:
   * blue = continue, green = ready to deliver, amber = needs attention.
   */
  function nextStep() {
    const L = TR.app.shell.left;
    const session = (TR.backend && TR.backend.session) || {};
    if (!L || !L.product.loaded()) return { label: 'Add a vehicle', hint: 'Start by loading a vehicle', tone: 'primary', icon: 'plus', run: () => { X.page = null; S.intake(); } };
    const onTestRequest = !X.page && TR.app.page === 'testrequest' && S.view !== 'expert';
    const changes = (() => { try { const c = TR.model.deltaCounts(L.product.delta()); return c.nodes + c.parameters + c.variants + c.sNotes; } catch (e) { return 0; } })();
    const v = S.validation;
    if (v && S.fresh()) {
      const blocked = v.results.some((r) => S.resultStatus(r) !== 'ready');
      if (blocked) return { label: 'Fix the blocked result', hint: 'Open the validation results', tone: 'attention', icon: 'alert', run: () => { X.page = null; S.stage = 'validate'; S.page(); S.stage = 'validate'; TR.app.refresh(); } };
      if (S.stage === 'review' && onTestRequest) return { label: 'Deliver the result', hint: 'Choose a kit, VDA update or export', tone: 'success', icon: 'check', run: () => document.querySelector('.s-delivery-actions, .s-side-card')?.scrollIntoView({ behavior: motionOn() ? 'smooth' : 'auto', block: 'center' }) };
      return { label: 'Review and deliver', hint: 'Validation is ready', tone: 'success', icon: 'arrow', run: () => { X.page = null; S.page(); S.stage = 'review'; TR.app.refresh(); } };
    }
    if (v && !S.fresh() && changes) return { label: 'Validate again', hint: 'The proposal changed after validation', tone: 'attention', icon: 'flask', run: validate };
    if (changes && session.canSimulate !== false) return { label: 'Validate ' + L.items.length + ' vehicle' + (L.items.length > 1 ? 's' : ''), hint: changes + ' change' + (changes > 1 ? 's' : '') + ' ready to check', tone: 'primary', icon: 'flask', run: validate };
    const t3 = L.product.current.nodes.some((n) => n.electricalArchitecture === 3);
    if (!onTestRequest) return { label: 'Plan a change', hint: 'Open the test request', tone: 'primary', icon: 'arrow', run: () => { X.page = null; S.page(); } };
    if (t3 && TR.t3services && session.canSimulate !== false) return { label: 'Update to service pack', hint: 'Or edit a package version below', tone: 'primary', icon: 'layers', run: () => TR.t3services.open(TR.enums.RequestType.ProductUpdateService) };
    return { label: 'Choose a change', hint: 'Edit software, parameters or variants', tone: 'primary', icon: 'sliders', run: () => document.querySelector('.s-entity-tabs')?.scrollIntoView({ behavior: motionOn() ? 'smooth' : 'auto', block: 'start' }) };
  }
  function validate() { X.page = null; const L = TR.app.shell.left; L.request.selectedRequestType = 0; S.page(); TR.request.runRequest(L, false); }

  function nextStepButton() {
    if (!prefs.get('nextStep')) return null;
    const step = nextStep();
    const t = TR.i18n.t;
    return h('button', { class: 'ap-next ' + step.tone, 'data-tip': t(step.label) + '|' + t(step.hint) + ' · ' + t('press N'), 'aria-label': t('Next step') + ': ' + t(step.label) + '. ' + t(step.hint), onClick: step.run },
      h('span', { class: 'ap-next-kicker' }, t('Next')), TR.icon(step.icon, 17), t(step.label));
  }

  // ------------------------------------------------------------------ header and frame
  /** Extra controls for the top bar, placed before the theme button. fn() returns a node or null. */
  const headerItems = [];
  const baseHeader = S.header;
  S.header = () => {
    const header = baseHeader();
    header.querySelector('.s-breadcrumb')?.remove();          // breadcrumbs now sit above the page content
    // The decorative 3D preview is replaced by page motion (see app-shell.css), so its 3D on/off button goes.
    if (typeof header.querySelectorAll === 'function') [...header.querySelectorAll('button')].filter((b) => /^3D (on|off)$/.test(b.textContent.trim())).forEach((b) => b.remove());
    const themeSelect = header.querySelector('label.s-theme');
    const resolved = S.resolveTheme(S.theme);
    const themeButton = h('button', { class: 'ap-icon-btn ap-theme-toggle', 'data-tip': TR.i18n.t(THEME_LABEL[S.theme]) + '|' + TR.i18n.t('Click or press T to switch'), 'aria-label': TR.i18n.t(THEME_LABEL[S.theme]), onClick: cycleTheme },
      TR.icon(S.theme === 'auto' ? 'spark' : resolved === 'charcoal' ? 'moon' : 'sun', 18));
    const motionButton = h('button', { class: 'ap-icon-btn ap-motion-toggle', 'aria-pressed': String(prefs.get('motion') !== 'off'), 'data-tip': TR.i18n.t(prefs.get('motion') === 'off' ? 'Motion: off' : 'Motion: on') + '|' + TR.i18n.t('Press M to switch'), 'aria-label': 'Motion ' + (prefs.get('motion') === 'off' ? 'off' : 'on'), onClick: () => prefs.set('motion', prefs.get('motion') === 'off' ? 'on' : 'off') },
      TR.icon(prefs.get('motion') === 'off' ? 'still' : 'motion', 18));
    if (themeSelect) themeSelect.replaceWith(themeButton); else header.appendChild(themeButton);
    themeButton.after(motionButton);
    headerItems.map((fn) => fn()).filter(Boolean).forEach((item) => themeButton.before(item));
    const next = nextStepButton();
    if (next) header.querySelector('.spacer')?.after(next);
    return header;
  };

  /** Focused / Two-pane switch, shown in the same place in both views of the test request. */
  function viewSwitch() {
    const expert = S.view === 'expert';
    const focused = () => { if (!expert) return; X.page = null; S.view = 'focused'; TR.app.shell.fullScreen = null; TR.app.navigate('testrequest'); };
    return h('div', { class: 'ap-viewswitch', role: 'group', 'aria-label': 'Workspace view' },
      h('button', { class: expert ? '' : 'is-on', 'aria-pressed': String(!expert), title: 'Guided view: configure, validate, review', onClick: focused }, TR.icon('grid', 16), 'Focused'),
      h('button', { class: expert ? 'is-on' : '', 'aria-pressed': String(expert), title: 'Original vehicle and request response side by side', onClick: () => { if (!expert) S.expert(); } }, TR.icon('compare', 16), 'Two-pane'));
  }
  const onTestRequest = () => !X.page && TR.app.page === 'testrequest';

  let lastWhere = null;
  // The decorative 3D preview is retired: switch it off once the app is running (it would otherwise keep a WebGL loop going).
  let effectsChecked = false;
  const baseFrame = S.frame;
  S.frame = (content) => {
    const frame = baseFrame(content);
    const main = frame.querySelector('.s-main');
    if (!effectsChecked) { effectsChecked = true; if (TR.polish && TR.polish.effectsOn && TR.polish.effectsOn()) setTimeout(() => TR.polish.setEffects(false), 0); }
    if (main) {
      // Page motion: the content fades and rises in when the page changes (not on every refresh).
      const where = [TR.app.page, X.page, S.view, X.page === 'help' && TR.help ? TR.help.H.article + TR.help.H.topic : ''].join('|');
      if (where !== lastWhere) { main.classList.add('ap-enter'); lastWhere = where; }
      const crumbBar = breadcrumbBar();
      // The two-pane page has the switch in its heading (shell.js); other expert screens keep it in the breadcrumb bar.
      if (crumbBar && onTestRequest() && S.view === 'expert' && !main.querySelector('.tw-page')) crumbBar.appendChild(viewSwitch());
      if (crumbBar) main.insertBefore(crumbBar, main.firstChild);
      // The focused view's "Two-pane view" link becomes the same switch.
      if (onTestRequest() && S.view !== 'expert') {
        // Only with expert tools on (navigation.js): the two-pane workbench is an expert tool, so others never see the switch.
        const link = [...main.querySelectorAll('.s-btn')].find((b) => b.textContent.trim() === 'Two-pane view');
        const N = TR.navigation, expertTools = !N || N.logic.expertOn(prefs.get('expertTools'), ((TR.backend && TR.backend.session) || {}).role);
        if (link && typeof link.replaceWith === 'function') { if (expertTools) link.replaceWith(viewSwitch()); else link.remove(); }
      }
      // Back to top: backtotop.js adds one per scroll container when it scrolls (the main area, each pane, panels).
    }
    markActiveNav(frame);
    return frame;
  };

  /** Highlights the sidebar entry of the current page. */
  function markActiveNav(frame) {
    const id = registry.current();
    const labels = { home: 'Home', dashboard: 'Dashboard', vehicle: 'Vehicle', library: 'Saved vehicles', activity: 'Activity', learn: 'Getting started', admin: 'Admin users', settings: 'Settings', about: 'About', help: 'Help', feedback: 'Send feedback' };
    const want = labels[id];
    frame.querySelectorAll('.s-sidebar button').forEach((b) => {
      const on = !!want && b.textContent.trim() === want;
      b.classList.toggle('selected', on);
      if (on) b.setAttribute('aria-current', 'page');
    });
  }

  // ------------------------------------------------------------------ pager (DocGen Explorer token table layout)
  /** First and last page number of the 5-slot window around the current page. */
  function pageWindow(page, pageCount, slots = 5) {
    const first = Math.min(Math.max(page - Math.floor(slots / 2), 1), Math.max(1, pageCount - slots + 1));
    return { first, last: Math.min(pageCount, first + slots - 1) };
  }
  /** Rows of one page plus the clamped page number. */
  function slice(items, page, size) {
    const pageCount = Math.max(1, Math.ceil(items.length / size));
    const current = Math.min(Math.max(1, page), pageCount);
    return { rows: items.slice((current - 1) * size, current * size), page: current, pageCount };
  }
  /**
   * "Showing a – b of z" on the left; First, Prev, five page numbers, Next, Last and "of N" on the right; rows per page select.
   * opts: { total, page, size, onPage(n), onSize(n), label, sizes }
   */
  // Numbers in the culture's style (1,20,005 in India), so lakhs of rows read well.
  const fmt = (n) => { try { return Number(n).toLocaleString((TR.culture && TR.culture.active().language) || undefined); } catch (e) { return String(n); } };
  function pager(opts) {
    const sizes = opts.sizes || [25, 50, 100, 200];
    const pageCount = Math.max(1, Math.ceil(opts.total / opts.size));
    const page = Math.min(Math.max(1, opts.page), pageCount);
    const from = opts.total ? (page - 1) * opts.size + 1 : 0;
    const to = Math.min(opts.total, page * opts.size);
    const link = (content, n, label, extra = '') => {
      const off = n < 1 || n > pageCount || (extra === 'nav' && n === page);
      return h('button', { class: ['ap-page', n === page && extra !== 'nav' ? 'is-on' : '', off ? 'is-off' : ''], 'aria-label': label, 'aria-current': n === page && extra !== 'nav' ? 'page' : null, 'aria-disabled': off ? 'true' : null, disabled: off, onClick: () => opts.onPage(n) }, content);
    };
    const { first, last } = pageWindow(page, pageCount);
    const numbers = [];
    for (let n = first; n <= last; n++) numbers.push(link(String(n), n, 'Page ' + n));
    return h('nav', { class: 'ap-pages', 'aria-label': 'Pages of ' + (opts.label || 'items') },
      h('span', { class: 'ap-pages-count' }, `Showing ${fmt(from)} – ${fmt(to)} of ${fmt(opts.total)}`),
      h('span', { class: 'ap-pages-links' },
        opts.onSize ? h('label', { class: 'ap-pages-size' }, 'Per page ', h('select', { 'aria-label': 'Rows per page', value: String(opts.size), onChange: (e) => opts.onSize(Number(e.target.value)) }, sizes.map((s) => h('option', { value: String(s), selected: s === opts.size }, String(s))))) : null,
        pageCount > 1 ? [
          link(TR.icon('first', 16), 1, 'First page', 'nav'), link(TR.icon('left', 16), page - 1, 'Previous page', 'nav'),
          ...numbers,
          link(TR.icon('right', 16), page + 1, 'Next page', 'nav'), link(TR.icon('last', 16), pageCount, 'Last page', 'nav'),
          h('span', { class: 'ap-pages-of' }, 'of ' + fmt(pageCount)),
        ] : null));
  }

  // ------------------------------------------------------------------ small shared UI helpers for page modules
  const ui = {
    /** Page heading in the Studio style. */
    heading(title, description, actions) {
      return h('div', { class: 's-heading' }, h('div', null, h('h1', null, title), description ? h('p', null, description) : null), actions ? h('div', { class: 's-heading-actions' }, actions) : null);
    },
    button(label, icon, onClick, kind = 'secondary', extra = {}) { return h('button', Object.assign({ type: 'button', class: 's-btn ' + kind, onClick }, extra), icon ? TR.icon(icon, 17) : null, label); },
    chip(label, tone = 'neutral') { return h('span', { class: 's-chip ' + tone }, label); },
    /** Same-origin JSON call to the server API. */
    async api(path) {
      const res = await fetch('/api/v1' + path, { credentials: 'same-origin', headers: { Accept: 'application/json' } });
      const data = await res.json().catch(() => ({}));
      if (res.status === 429) throw Object.assign(new Error(TR.pages.ui.limited(res, data)), { status: 429, retryAfter: Number(res.headers.get('Retry-After')) || null });
      if (!res.ok) throw new Error(data.detail || data.title || 'Server request failed');
      return data;
    },
    motionOn,
    /** The message for a refused call (429): which limit and when to try again (Retry-After). */
    limited(res, data) {
      const after = Number(res.headers.get('Retry-After')) || (data && data.retryAfterSeconds) || 60;
      return 'Too many requests right now. Try again in ' + (after < 90 ? after + ' s' : Math.round(after / 60) + ' min') + '.' + (data && data.policy ? ' (limit: ' + data.policy + ')' : '');
    },
    /** Focuses a page's search box when "/" is pressed outside a text field. */
    slashFocus(selector) {
      if (typeof document.addEventListener !== 'function') return;
      document.addEventListener('keydown', (e) => {
        if (e.key !== '/' || e.ctrlKey || e.metaKey || /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName || '')) return;
        const box = document.querySelector(selector);
        if (box) { e.preventDefault(); box.focus(); }
      });
    },
    /** Date and time, or date only, in the user's culture (culture.js). */
    when(date) { try { return TR.culture ? TR.culture.format.dateTime(date) : new Date(date).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }); } catch (e) { return String(date); } },
    day(date) { try { return TR.culture ? TR.culture.format.date(date) : new Date(date).toLocaleDateString([], { dateStyle: 'medium' }); } catch (e) { return String(date); } },
  };

  TR.prefs = prefs;
  TR.pages = Object.assign(registry, { ui, crumbs, breadcrumbBar, setTheme, cycleTheme, addHeaderItem: (fn) => headerItems.push(fn), addHomeCard: (fn) => homeCards.push(fn) });
  // Header popovers share one open surface, even when their triggers stop click propagation.
  TR.pages.closeHeaderMenus = (except) => {
    if (except !== 'navigation' && TR.navigation) { TR.navigation.N.flyout = null; TR.navigation.N.drawer = false; }
    if (except !== 'account' && TR.avatar) TR.avatar.A.open = false;
    if (except !== 'notifications' && TR.notify) TR.notify.N.open = false;
  };
  TR.pager = Object.assign(pager, { pageWindow, slice });
  TR.nextStep = nextStep;

  // Standard keyboard movement for every ARIA tab group. Individual widgets may handle keys first.
  if (typeof document.addEventListener === 'function') document.addEventListener('keydown', (event) => {
    if (event.defaultPrevented || !['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    const active = event.target && event.target.closest && event.target.closest('[role="tab"]');
    const group = active && active.closest('[role="tablist"]');
    if (!group) return;
    const tabs = [...group.querySelectorAll('[role="tab"]')].filter((tab) => !tab.disabled && tab.getAttribute('aria-disabled') !== 'true');
    const current = tabs.indexOf(active); if (current < 0 || tabs.length < 2) return;
    const next = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : (current + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
    const groupIndex = [...document.querySelectorAll('[role="tablist"]')].indexOf(group);
    event.preventDefault(); tabs[next].click();
    const focus = () => document.querySelectorAll('[role="tablist"]')[groupIndex]?.querySelectorAll('[role="tab"]')[next]?.focus();
    if (typeof requestAnimationFrame === 'function') requestAnimationFrame(focus); else focus();
  });
})();
