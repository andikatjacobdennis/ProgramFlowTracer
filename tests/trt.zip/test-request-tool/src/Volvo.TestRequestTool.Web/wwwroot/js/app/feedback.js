/* Feedback page (not a dialog): users rate the app, choose Idea, Problem, Praise or Question and write a message. Page details
 * are attached only if they keep the box ticked, and they can see exactly what is attached. They see their own earlier
 * feedback; administrators also get an inbox of everyone's feedback with a summary, filters and a status per item.
 *
 * Data: POST /api/v1/feedback, GET /feedback/mine, GET and PUT /admin/feedback (see FeedbackEndpoints.cs).
 * Open with TR.feedback.open(kind?) so the page you came from is attached. */
(function () {
  'use strict';
  const { h } = TR.util;
  const { ui } = TR.pages;
  const t = (s, v) => TR.i18n.t(s, v);
  const KINDS = [['Idea', 'spark'], ['Problem', 'alert'], ['Praise', 'check'], ['Question', 'help']];
  const F = { kind: 'Idea', rating: 0, message: '', attach: true, from: '', sent: null, error: null, sending: false, mine: null, all: null, tab: 'send', filter: { kind: '', status: '' }, page: 1 };
  const session = () => (TR.backend && TR.backend.session) || {};
  const MAX = 4000;

  /** What is attached when "Attach page details" is ticked. Shown to the user before sending. */
  function context() {
    const L = TR.app.shell.left, c = TR.culture ? TR.culture.active() : {};
    return {
      page: F.from || 'unknown',
      vehicle: L && L.product.loaded() ? L.product.chassisString() : null,
      theme: TR.testRequest.theme, language: TR.i18n.lang(), culture: c.language, timeZone: c.timeZone,
      screen: typeof window !== 'undefined' && window.innerWidth ? `${window.innerWidth}×${window.innerHeight}` : null,
      browser: typeof navigator !== 'undefined' ? String(navigator.userAgent || '').replace(/\s*\(.*?\)\s*/g, ' ').slice(0, 160) : null,
    };
  }
  async function loadMine(force) {
    if ((F.mine && !force) || !session().userId) return;
    try { F.mine = await ui.api('/feedback/mine'); } catch (e) { F.mine = []; }
    if (session().isAdmin) { try { F.all = await ui.api('/admin/feedback'); } catch (e) { F.all = null; } }
    TR.app.refresh();
  }
  async function send() {
    if (!F.message.trim() || F.sending) return;
    F.sending = true; F.error = null; TR.app.refresh();
    try {
      const res = await fetch('/api/v1/feedback', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ kind: F.kind, rating: F.rating, message: F.message.trim(), page: F.from || null, context: F.attach ? context() : null }) });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(body.detail || body.title || t('Sending failed'));
      F.sent = body; F.message = ''; F.rating = 0;
      if (TR.notify) TR.notify.toast(t('Feedback sent. Thank you!'), 'success');
      await loadMine(true);
    } catch (e) { F.error = e.message; }
    F.sending = false; TR.app.refresh();
  }
  async function setStatus(item, status) {
    try {
      const res = await fetch('/api/v1/admin/feedback/' + item.id, { method: 'PUT', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) });
      if (!res.ok) throw new Error(t('Could not update the status'));
      item.status = status; TR.app.refresh();
    } catch (e) { TR.ui.alert(e.message); }
  }

  // ------------------------------------------------------------------ rating faces
  const NS = 'http://www.w3.org/2000/svg';
  const sv = (tag, a) => { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(a)) e.setAttribute(k, String(v)); return e; };
  const MOUTHS = { 1: 'M12 24 Q18 18 24 24', 2: 'M12 23 Q18 20 24 23', 3: 'M12 22 L24 22', 4: 'M12 21 Q18 25 24 21', 5: 'M11 20 Q18 28 25 20 Z' };
  const FACE_LABEL = { 1: 'Very poor', 2: 'Poor', 3: 'Okay', 4: 'Good', 5: 'Excellent' };
  function face(n) {
    const g = sv('svg', { viewBox: '0 0 36 36', width: 36, height: 36, 'aria-hidden': 'true' });
    g.appendChild(sv('circle', { cx: 18, cy: 18, r: 16, class: 'fb-face-bg' }));
    g.appendChild(sv('circle', { cx: 12.5, cy: 14, r: 2, class: 'fb-face-eye' })); g.appendChild(sv('circle', { cx: 23.5, cy: 14, r: 2, class: 'fb-face-eye' }));
    g.appendChild(sv('path', { d: MOUTHS[n], class: 'fb-face-mouth' + (n === 5 ? ' is-open' : '') }));
    return g;
  }

  // ------------------------------------------------------------------ views
  const statusTone = { New: 'simulation', Read: 'neutral', Done: 'good' };
  function item(f, admin) {
    return h('li', { class: 'fb-item' },
      h('div', { class: 'fb-item-head' }, ui.chip(t(f.kind), f.kind === 'Problem' ? 'warning' : f.kind === 'Praise' ? 'good' : 'simulation'),
        f.rating ? h('span', { class: 'fb-stars', title: t(FACE_LABEL[f.rating]) }, '★'.repeat(f.rating) + '☆'.repeat(5 - f.rating)) : null,
        admin ? h('strong', null, f.actorName) : null, h('time', { class: 'muted', datetime: f.createdAt }, ui.when(f.createdAt)),
        h('span', { class: 'gh-spacer' }),
        admin ? h('select', { 'aria-label': t('Status'), class: 'st-select', value: f.status, onChange: (e) => setStatus(f, e.target.value) }, ['New', 'Read', 'Done'].map((s) => h('option', { value: s, selected: f.status === s }, t(s)))) : ui.chip(t(f.status), statusTone[f.status])),
      h('p', { class: 'fb-msg' }, f.message),
      f.page || (f.context && f.context.vehicle) ? h('small', { class: 'muted' }, [f.page ? t('From {page}', { page: f.page }) : null, f.context && f.context.vehicle ? f.context.vehicle : null].filter(Boolean).join(' · ')) : null);
  }
  function form() {
    const ctx = context();
    if (F.sent) return h('section', { class: 'fb-card fb-thanks' },
      TR.help ? TR.help.guide(t('Thank you, {name}! Every message is read. You can follow it below.', { name: String(session().displayName || '').split(' ')[0] || '' }), 'cheer', 120) : null,
      h('div', null, h('h2', null, t('Thanks for your feedback')), h('p', null, t('We have it. You can send more at any time.')), ui.button(t('Send more feedback'), 'plus', () => { F.sent = null; TR.app.refresh(); }, 'primary')));
    return h('section', { class: 'fb-card' },
      h('div', { class: 'fb-ask' }, TR.help ? TR.help.guide(t('How is Test Request Tool working for you? Tell us anything: ideas, problems, praise or questions.'), 'wave', 110) : null),
      h('div', { class: 'fb-form' },
        h('h2', null, t('How would you rate it?')),
        h('div', { class: 'fb-faces', role: 'radiogroup', 'aria-label': t('Rating') }, [1, 2, 3, 4, 5].map((n) => h('button', { class: ['fb-face', F.rating === n ? 'is-on' : ''], role: 'radio', 'aria-checked': String(F.rating === n), title: t(FACE_LABEL[n]), 'aria-label': t(FACE_LABEL[n]), onClick: () => { F.rating = F.rating === n ? 0 : n; TR.app.refresh(); } },
          face(n), h('small', null, t(FACE_LABEL[n]))))),
        h('h2', null, t('What is it about?')),
        h('div', { class: 'fb-kinds', role: 'radiogroup', 'aria-label': t('Kind of feedback') }, KINDS.map(([k, icon]) => h('button', { class: ['hp-chip', F.kind === k ? 'is-on' : ''], role: 'radio', 'aria-checked': String(F.kind === k), onClick: () => { F.kind = k; TR.app.refresh(); } }, TR.icon(icon, 14), ' ', t(k)))),
        h('label', { class: 'fb-label', for: 'fb-message' }, t('Your message')),
        h('textarea', { id: 'fb-message', class: 'fb-text', rows: 6, maxlength: MAX, key: 'fb-message', value: F.message,
          placeholder: t({ Idea: 'What would make your work easier?', Problem: 'What happened, and what did you expect?', Praise: 'What do you like?', Question: 'What would you like to know?' }[F.kind]),
          onInput: (e) => { F.message = e.target.value; const c = document.querySelector('.fb-count'); if (c) c.textContent = `${F.message.length} / ${MAX}`; },
          onKeydown: (e) => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); send(); } } }),
        h('div', { class: 'fb-row' }, h('small', { class: 'fb-count muted' }, `${F.message.length} / ${MAX}`), h('small', { class: 'muted' }, t('Ctrl+Enter sends'))),
        h('label', { class: 'fb-attach' }, h('input', { type: 'checkbox', checked: F.attach, onChange: (e) => { F.attach = e.target.checked; TR.app.refresh(); } }), ' ', t('Attach page details to help us understand')),
        F.attach ? h('details', { class: 'fb-details' }, h('summary', null, t('See exactly what is attached')),
          h('dl', null, Object.entries(ctx).filter(([, v]) => v).flatMap(([k, v]) => [h('dt', null, t(k)), h('dd', null, String(v))]))) : null,
        F.error ? h('div', { class: 's-banner warning' }, TR.icon('alert'), F.error) : null,
        h('div', { class: 'fb-actions' }, ui.button(F.sending ? t('Sending…') : t('Send feedback'), 'arrow', send, 'primary', { disabled: !F.message.trim() || F.sending }),
          h('small', { class: 'muted' }, t('Your name is sent with it. Nothing leaves this server.')))));
  }
  function mine() {
    if (!F.mine) return h('p', { class: 'muted' }, t('Loading…'));
    return F.mine.length ? h('ol', { class: 'fb-list' }, F.mine.map((f) => item(f, false))) : h('p', { class: 'muted' }, t('You have not sent any feedback yet.'));
  }
  function inbox() {
    if (!F.all) return h('p', { class: 'muted' }, t('Loading…'));
    const all = F.all, rated = all.filter((f) => f.rating);
    const avg = rated.length ? (rated.reduce((s, f) => s + f.rating, 0) / rated.length).toFixed(1) : '–';
    const list = all.filter((f) => (!F.filter.kind || f.kind === F.filter.kind) && (!F.filter.status || f.status === F.filter.status));
    const size = Number(TR.prefs.get('pageSize'));
    const { rows, page } = TR.pager.slice(list, F.page, size);
    const count = (k) => all.filter((f) => f.kind === k).length;
    return h('div', { class: 'fb-inbox' },
      h('div', { class: 'db-kpis' },
        h('div', { class: 'db-kpi' }, h('span', { class: 'db-kpi-icon' }, TR.icon('people', 20)), h('div', null, h('strong', { class: 'db-kpi-value' }, String(all.length)), h('span', { class: 'db-kpi-label' }, t('messages')), h('small', null, t('{n} new', { n: all.filter((f) => f.status === 'New').length })))),
        h('div', { class: 'db-kpi' }, h('span', { class: 'db-kpi-icon' }, TR.icon('check', 20)), h('div', null, h('strong', { class: 'db-kpi-value' }, avg), h('span', { class: 'db-kpi-label' }, t('average rating')), h('small', null, t('{n} ratings', { n: rated.length })))),
        KINDS.map(([k, icon]) => h('div', { class: 'db-kpi' }, h('span', { class: 'db-kpi-icon' }, TR.icon(icon, 20)), h('div', null, h('strong', { class: 'db-kpi-value' }, String(count(k))), h('span', { class: 'db-kpi-label' }, t(k)))))),
      h('div', { class: 'vh-toolbar' },
        h('label', null, t('Kind') + ' ', h('select', { value: F.filter.kind, onChange: (e) => { F.filter.kind = e.target.value; F.page = 1; TR.app.refresh(); } }, h('option', { value: '' }, t('All')), KINDS.map(([k]) => h('option', { value: k, selected: F.filter.kind === k }, t(k))))),
        h('label', null, t('Status') + ' ', h('select', { value: F.filter.status, onChange: (e) => { F.filter.status = e.target.value; F.page = 1; TR.app.refresh(); } }, h('option', { value: '' }, t('All')), ['New', 'Read', 'Done'].map((s) => h('option', { value: s, selected: F.filter.status === s }, t(s))))),
        h('span', { class: 'muted', role: 'status' }, t('{n} shown', { n: list.length }))),
      rows.length ? h('ol', { class: 'fb-list' }, rows.map((f) => item(f, true))) : h('p', { class: 'muted' }, t('No feedback matches.')),
      TR.pager({ total: list.length, page, size, label: 'feedback', onPage: (n) => { F.page = n; TR.app.refresh(); }, onSize: (n) => TR.prefs.set('pageSize', n) }));
  }
  function render() {
    loadMine();
    const admin = !!session().isAdmin;
    return h('div', { class: 'fb-page' },
      ui.heading(t('Feedback'), t('Tell us what works, what does not and what you would like next.')),
      admin ? h('div', { class: 's-tabs vh-tabs', role: 'tablist' }, [['send', t('Send feedback'), 'arrow'], ['inbox', t('All feedback'), 'people']].map(([id, label, icon]) =>
        h('button', { class: ['s-btn', 'tab', F.tab === id ? 'active' : ''], role: 'tab', 'aria-selected': String(F.tab === id), onClick: () => { F.tab = id; TR.app.refresh(); } }, TR.icon(icon, 16), label,
          id === 'inbox' && F.all ? h('span', { class: 'vh-count' }, String(F.all.filter((f) => f.status === 'New').length)) : null))) : null,
      F.tab === 'inbox' && admin ? inbox() : [form(), h('section', { class: 'fb-mine' }, h('h2', null, t('Your earlier feedback')), mine())]);
  }
  /** Opens the page; kind preselects Idea, Problem, Praise or Question. */
  function open(kind) {
    F.from = TR.pages.current() || TR.app.page || 'unknown';
    if (kind) F.kind = kind;
    F.sent = null; F.tab = 'send';
    TR.pages.show('feedback');
  }
  TR.pages.register({ id: 'feedback', title: 'Feedback', crumbs: () => [{ label: t('Help'), open: () => TR.pages.show('help') }, { label: t('Feedback') }], render });
  if (TR.shortcuts) TR.shortcuts.add({ keys: 'g f', group: 'Go to', label: 'Send feedback', run: () => open() });
  TR.feedback = { F, open, context, send };
})();
