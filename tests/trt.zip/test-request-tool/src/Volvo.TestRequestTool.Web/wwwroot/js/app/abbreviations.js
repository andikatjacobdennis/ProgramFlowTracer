/* Abbreviations: every abbreviation on screen (EMS, ECU, VDA, MSW …) gets a dotted underline and explains itself on hover:
 * what it stands for, a short description and any other meanings, in the app's two-line tooltip (data-tip, notify.js).
 *
 *   APP         the meanings this application uses; they come first (and win where the company list means something else,
 *               such as APU, which here is Available Product Updates)
 *   company     data/abbreviations.json: the company list of abbreviations (scripts/import-abbreviations.py builds it from
 *               Abbreviations.xlsx); loaded once, after the page is up
 *   page        Help › Abbreviations lists and searches all of them (also the way in for keyboard users)
 *   setting     Settings › Accessibility › Explain abbreviations turns the underlines and tooltips off
 * Left alone: form fields, code and XML, anything that has its own tooltip, and the tooltip itself. */
(function () {
  'use strict';
  const TR = window.TR;
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));

  /** Stands for | what it means here. */
  const APP = {
    ECU: 'Electronic Control Unit|One computer in the vehicle, such as EMS for the engine.',
    EMS: 'Engine Management System|The computer that controls the engine.',
    TECU: 'Transmission Electronic Control Unit|The computer that controls the gearbox.',
    VDA: 'Vehicle Data Administration|The official record of each vehicle’s configuration. Sending a change updates it.',
    EDB: 'Engineering Database|Where vehicle specifications come from before production.',
    CBR: 'Common BOM Repository|Where spare cab orders come from.',
    XSD: 'XML Schema Definition|The file that describes what a valid XML message looks like: its elements, attributes and values.',
    HPC: 'High-Performance Computer|A T3 computer that runs several software packages in execution environments.',
    NTP: 'Node Template|The approved software set for one vehicle computer.',
    'S-Note': 'Special note|A short code that records a special build or an exception on a vehicle.',
    T3: 'T3 architecture|The newest electrical architecture, with HPC computers.',
    'TEA2+': 'Truck Electrical Architecture 2+|The previous electrical architecture, with one software set per computer.',
    PUS: 'Product Update Service|Finds the right service pack for a T3 vehicle.',
    APU: 'Available Product Updates|Lists the software, hardware and kits a T3 vehicle can take.',
    SP: 'Service Pack|A tested set of software versions that belong together.',
    MSW: 'Main Software|The main program of a vehicle computer.',
    PBL: 'Primary Boot Loader|The first program that starts on a vehicle computer.',
    SBL: 'Secondary Boot Loader|Started by the primary boot loader; used when software is installed.',
    VIN: 'Vehicle Identification Number|The unique 17-character number of a vehicle.',
    VCADS: 'Volvo Computer Aided Diagnostic System|The workshop tool that reads and programs vehicle computers.',
    KAX: 'KOLA Aided X|A system the tool can check a change against.',
    VESPA: 'Vehicle Specification|A system the tool can check a change against.',
  };
  /** Never marked: everyday words and country codes that happen to be in the company list. */
  const SKIP_WORDS = new Set(['OK', 'OR', 'IT', 'ID', 'AM', 'PM', 'NO', 'ON', 'IN', 'TO', 'BY', 'OF', 'AT', 'AN', 'AS', 'IS', 'BE', 'DO', 'GO', 'UP',
    'US', 'WE', 'IF', 'ALL', 'AND', 'NOT', 'NEW', 'ONE', 'TWO', 'THE', 'FOR', 'ANY', 'SE', 'DE', 'GB', 'BR', 'FR', 'NL', 'PL', 'EN', 'SV', 'HI']);
  const AB = { company: {}, loaded: false, loading: null };

  /** An abbreviation, not a word: two capitals (EMS, S-Note, TEA2+), or a capital and a digit (T3, 3C). */
  function looksLikeOne(token) {
    const caps = (token.match(/[A-Z]/g) || []).length, digits = /\d/.test(token);
    return (caps >= 2 || (caps >= 1 && digits)) && !SKIP_WORDS.has(token.toUpperCase());
  }
  /** Every meaning of an abbreviation, the app's first: [{ standsFor, description, app }]. Plurals (ECUs, S-Notes) count. */
  function meanings(token) {
    for (const key of [token, /s$/.test(token) ? token.slice(0, -1) : null]) {
      if (!key || !looksLikeOne(key)) continue;
      const list = [];
      if (APP[key]) { const [standsFor, description] = APP[key].split('|'); list.push({ standsFor, description, app: true }); }
      for (const m of AB.company[key] || []) if (!list.some((x) => x.standsFor.toLowerCase() === m.standsFor.toLowerCase())) list.push(m);
      if (list.length) return { key, list };
    }
    return null;
  }
  const cut = (s, n) => (s && s.length > n ? s.slice(0, n).replace(/\s+\S*$/, '') + '…' : s || '');
  /** The tooltip: "EMS · Engine Management System|What it is. Also: …". */
  function explain(token) {
    const m = meanings(token);
    if (!m) return null;
    const [first, ...others] = m.list;
    const also = others.length ? ' ' + t('Also: {list}', { list: others.slice(0, 3).map((o) => o.standsFor).join('; ') }) + (others.length > 3 ? ' …' : '') : '';
    return `${m.key} · ${first.standsFor}|${cut(first.description, 220)}${also}`.replace(/\|\s*$/, '');
  }

  // ------------------------------------------------------------------ finding them in text
  // A token is letters, digits and + & / - inside it (S-Note, TEA2+). A token touching _ . @ \ or another word character is
  // part of an identifier, a version, a file name or an address (EMS_26.10, vcm.json), so it is left alone.
  const TOKEN = /[A-Za-z0-9][A-Za-z0-9+&/-]*[A-Za-z0-9+]|[A-Za-z0-9]/g;
  const CANDIDATE = /[A-Z]{2}|[A-Z]\d|\d[A-Z]/;
  /** [{ index, token, tip }] for each abbreviation in a string. */
  function find(text) {
    const out = [];
    if (!CANDIDATE.test(text)) return out;
    TOKEN.lastIndex = 0;
    let m;
    while ((m = TOKEN.exec(text))) {
      const before = text[m.index - 1] || '', after = text[m.index + m[0].length] || '', next = text[m.index + m[0].length + 1] || '';
      if (/[\w.@\\]/.test(before) || /[\w@\\]/.test(after) || (after === '.' && /\w/.test(next))) continue;
      const tip = explain(m[0]);
      if (tip) out.push({ index: m.index, token: m[0], tip });
    }
    return out;
  }

  const SKIP = 'input, textarea, select, option, script, style, code, pre, kbd, samp, svg, abbr, [contenteditable="true"], [data-tip], .no-abbr, .ap-tip';
  const on = () => !TR.prefs || TR.prefs.get('abbreviations') !== false;
  /** Marks the abbreviations under an element. Safe to call again: marked ones are skipped. */
  function mark(root) {
    if (!on() || !root || typeof document === 'undefined' || !document.createTreeWalker) return 0;
    const walker = document.createTreeWalker(root, 4 /* NodeFilter.SHOW_TEXT */, {
      acceptNode: (n) => (CANDIDATE.test(n.data) && n.parentElement && !n.parentElement.closest(SKIP) ? 1 : 3),
    });
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    let count = 0;
    for (const node of nodes) {
      const hits = find(node.data);
      if (!hits.length) continue;
      const frag = document.createDocumentFragment();
      let at = 0;
      for (const hit of hits) {
        if (hit.index > at) frag.appendChild(document.createTextNode(node.data.slice(at, hit.index)));
        const abbr = document.createElement('abbr');
        abbr.className = 'tr-abbr';
        abbr.setAttribute('data-tip', hit.tip);
        abbr.textContent = hit.token;
        frag.appendChild(abbr);
        at = hit.index + hit.token.length;
        count++;
      }
      if (at < node.data.length) frag.appendChild(document.createTextNode(node.data.slice(at)));
      node.parentNode.replaceChild(frag, node);
    }
    return count;
  }
  /** Removes the marks (the setting was turned off). */
  function unmark() {
    document.querySelectorAll('abbr.tr-abbr').forEach((a) => { const p = a.parentNode; p.replaceChild(document.createTextNode(a.textContent), a); p.normalize(); });
  }
  const scope = () => document.getElementById('app') || document.body;

  /** The company list, once. Until it arrives the app's own meanings already work. */
  function load() {
    if (AB.loaded || AB.loading || typeof fetch !== 'function') return AB.loading;
    AB.loading = fetch('/data/abbreviations.json', { credentials: 'same-origin' }).then((r) => (r.ok ? r.json() : null)).then((d) => {
      AB.company = (d && d.terms) || {}; AB.loaded = true; mark(scope());
      if (TR.pages && TR.pages.current && TR.pages.current() === 'abbreviations') TR.app.refresh();
    }).catch(() => { AB.loaded = true; });
    return AB.loading;
  }

  if (typeof MutationObserver === 'function' && typeof document !== 'undefined' && document.body) {
    let pending = false;
    new MutationObserver(() => {
      if (pending || !on()) return;
      pending = true;
      requestAnimationFrame(() => { pending = false; mark(scope()); });
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
    const later = window.requestIdleCallback || ((fn) => setTimeout(fn, 1500));
    later(() => load());
  }

  // ------------------------------------------------------------------ Help › Abbreviations
  const P = { q: '' };
  function all() {
    const keys = new Set(Object.keys(APP).concat(Object.keys(AB.company)));
    return [...keys].filter(looksLikeOne).sort((a, b) => a.localeCompare(b, 'en', { sensitivity: 'base' })).map((k) => ({ key: k, list: meanings(k).list }));
  }
  function page() {
    load();
    const q = P.q.trim().toLowerCase();
    const rows = all().filter((r) => !q || r.key.toLowerCase().includes(q) || r.list.some((m) => (m.standsFor + ' ' + (m.description || '')).toLowerCase().includes(q)));
    const appFirst = q ? rows : rows.filter((r) => r.list[0].app);
    const shown = appFirst.slice(0, 200);
    return h('div', { class: 'st-page ab-page no-abbr' },
      h('div', { class: 'st-head' }, h('h1', null, t('Abbreviations')),
        h('p', { class: 'muted' }, t('Abbreviations on screen have a dotted underline; point at one to see what it means. This list has all of them: the ones this tool uses first, then the company list.'))),
      h('label', { class: 'jr-search ab-search' }, TR.icon('search', 16),
        h('input', { type: 'search', key: 'ab-search', placeholder: t('Find an abbreviation or a word in its meaning'), 'aria-label': t('Find an abbreviation'), value: P.q, onInput: (e) => { P.q = e.target.value; TR.app.refresh(); } })),
      h('p', { class: 'muted', role: 'status' }, q
        ? t('{n} found', { n: rows.length.toLocaleString() }) + (rows.length > shown.length ? ' · ' + t('showing the first {n}', { n: shown.length }) : '')
        : t('{n} used in this tool · {m} in all. Search to see the rest.', { n: appFirst.length, m: all().length.toLocaleString() })),
      h('dl', { class: 'ab-list' }, shown.map((r) => [
        h('dt', null, h('strong', null, r.key), r.list[0].app ? h('span', { class: 'jr-pill tone-info' }, t('Used here')) : null),
        h('dd', null, r.list.map((m) => h('p', null, h('span', { class: 'ab-stands' }, m.standsFor), m.description ? h('span', { class: 'muted' }, ' — ' + cut(m.description, 300)) : null)))])));
  }
  if (TR.pages && TR.pages.register) TR.pages.register({ id: 'abbreviations', title: 'Abbreviations', crumbs: () => [{ label: t('Help'), open: () => TR.pages.show('help') }, { label: t('Abbreviations') }], render: page });

  TR.abbreviations = { APP, AB, looksLikeOne, meanings, explain, find, mark, unmark, load, all, SKIP_WORDS };
})();
