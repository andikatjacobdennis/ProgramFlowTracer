/* Managed settings: what your teams and the organisation set for you (/api/v1/settings/effective). TR.prefs.get reads
   these layers (core.js); Settings shows where each value comes from and locks the ones you cannot change. */
(function () {
  'use strict';
  const M = { settings: {}, teams: [], loaded: false };
  async function load() {
    if (typeof fetch !== 'function' || typeof location === 'undefined' || !/^https?:$/.test(location.protocol)) return;
    try {
      const r = await fetch('/api/v1/settings/effective', { headers: { Accept: 'application/json' } });
      if (!r.ok) return;
      const body = await r.json();
      M.settings = body.settings || {}; M.teams = body.teams || []; M.loaded = true;
      // The theme lives outside TR.prefs (testrequest.js): apply a managed one when it is locked or you have not chosen your own.
      const theme = M.settings.theme;
      if (theme && TR.testRequest && TR.testRequest.setTheme) { let own = null; try { own = localStorage.getItem('trstudio.theme'); } catch (e) { /* none */ } if (theme.locked || own == null) TR.testRequest.setTheme(theme.value); }
      if (TR.app && TR.app.shell && TR.app.shell.left) TR.app.refresh();
    } catch (e) { /* offline: built-in defaults and your own choices still apply */ }
  }
  TR.managed = Object.assign(M, { load });
  setTimeout(load, 0);
})();
