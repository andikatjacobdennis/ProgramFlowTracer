/* Campaigns: coordinate approved changes across eligible vehicles (server: /api/v1/campaigns, CampaignService).
 * A campaign is a request template applied to many vehicles. Validate runs it as a batch; each vehicle shows its
 * validation, approval and next action; someone else with the Writer role approves the exact revision (the ready
 * vehicles); Submit commits each approved vehicle still on its validated revision. Editing makes a new revision and
 * clears the approval. Create and edit happen inline (no dialog). While validations run, the page refreshes itself. */
(function () {
  'use strict';
  const { h } = TR.util;
  const J = TR.journey, t = J.t;
  const OPS = [[3, 'Update'], [5, 'Update to service pack'], [1, 'Refresh'], [2, 'Repair'], [4, 'Resolve']];
  const C = { list: null, error: null, selected: null, detail: null, tab: 'all', q: '', status: '', flag: '', dtab: 'vehicles', vq: '', vstatus: '', picked: new Set(), page: 0, size: 10,
    editing: null, vehicles: null, note: '', confirm: false, busy: false, timer: null };

  async function loadList(keep) {
    try { C.list = await J.api('/campaigns'); C.error = null; if (!C.selected && C.list.length) C.selected = C.list[0].id; } catch (e) { C.error = e.message; }
    if (C.selected) await loadDetail(C.selected, keep); else TR.app.refresh();
  }
  async function loadDetail(id, keep) {
    try { C.detail = await J.api('/campaigns/' + id); if (!keep) { C.picked.clear(); C.page = 0; C.confirm = false; C.note = ''; } } catch (e) { C.detail = null; C.error = e.message; }
    TR.app.refresh();
    clearTimeout(C.timer);
    if (C.detail && C.detail.counts.running && TR.pages.current() === 'campaigns') C.timer = setTimeout(() => loadList(true), 3000);
  }
  async function act(path, body, ok) {
    if (C.busy) return;
    C.busy = true; TR.app.refresh();
    try { C.detail = await J.api('/campaigns/' + C.detail.id + path, { method: 'POST', body: Object.assign({ version: C.detail.version }, body || {}) }); if (ok) { TR.notify.toast(t(ok), 'success'); TR.announce && TR.announce(t(ok)); } C.picked.clear(); await loadList(true); }
    catch (e) { TR.notify.toast(e.message, 'error'); if (e.status === 409) await loadDetail(C.detail.id, true); }
    C.busy = false; TR.app.refresh();
  }
  const me = () => J.me();
  const canWrite = () => !!me().canWrite;

  // ------------------------------------------------------------------ filtering (exported for tests)
  function filterList(list, f) {
    const q = (f.q || '').toLowerCase();
    return list.filter((c) => (f.tab === 'all' ? c.status !== 'archived' : f.tab === 'active' ? ['active', 'approved', 'changes_requested'].includes(c.status) : f.tab === 'mine' ? c.owner.id === f.me : c.status === 'archived')
      && (!f.status || c.status === f.status) && (!q || (c.name + ' ' + c.code + ' ' + c.owner.name).toLowerCase().includes(q))
      && (!f.flag || (f.flag === 'attention' ? attentionOf(c) > 0 : f.flag === 'awaiting' ? !!c.awaitingApproval : f.flag === 'ready' ? (c.counts && c.counts.ready) > 0 : true)));
  }
  /** Vehicles of a campaign that need attention: blocked, stale or not validated yet. */
  const attentionOf = (c) => (c.counts ? c.counts.blocked + c.counts.stale + c.counts.unknown : 0);
  const STATUS = { draft: ['Draft', 'draft'], active: ['Active', 'running'], approved: ['Approved', 'approved'], changes_requested: ['Changes requested', 'changes'], submitted: ['Submitted', 'submitted'], archived: ['Archived', 'withdrawn'] };
  const statusChip = (c) => (c.awaitingApproval ? J.chip('pending', t('Awaiting approval')) : J.chip(STATUS[c.status] ? STATUS[c.status][1] : c.status, t(STATUS[c.status] ? STATUS[c.status][0] : c.status)));

  // ------------------------------------------------------------------ create and edit (inline)
  async function vehicles() { if (C.vehicles) return; try { C.vehicles = (await J.api('/vehicles/search?take=500')).items; } catch (e) { C.vehicles = []; } TR.app.refresh(); }
  function startEdit(c) {
    vehicles();
    C.editing = c ? { id: c.id, version: c.version, name: c.name, description: c.description, ids: new Set(c.vehicles.map((v) => v.id)), op: (c.template && c.template.softwareRequestOperation) || 3, q: '' }
      : { id: null, name: '', description: '', ids: new Set(), op: 3, q: '' };
    TR.app.refresh();
    setTimeout(() => { const i = document.getElementById('cp-name'); if (i) i.focus(); }, 0);
  }
  async function saveEdit() {
    const e = C.editing;
    if (!e.name.trim()) { TR.notify.toast(t('Name the campaign.'), 'error'); return; }
    const body = { name: e.name, description: e.description, vehicleIds: [...e.ids], kind: 'Software', template: { softwareRequestOperation: Number(e.op), scenario: TR.prefs.get('scenario') || 1, pblUpdateCapable: true, enableMultiNodeBehavior: true } };
    try {
      const r = e.id ? await J.api('/campaigns/' + e.id, { method: 'PUT', body: Object.assign(body, { version: e.version }) }) : await J.api('/campaigns', { method: 'POST', body });
      C.editing = null; C.selected = r.id; TR.notify.toast(t(e.id ? 'Saved as revision {n}. Approval cleared.' : 'Campaign created.', { n: r.revision }), 'success');
      await loadList();
    } catch (x) { TR.notify.toast(x.message, 'error'); }
  }
  function editor() {
    const e = C.editing, all = C.vehicles || [];
    const shown = all.filter((v) => !e.q || (v.series + ' ' + v.number + ' ' + (v.model || '')).toLowerCase().includes(e.q.toLowerCase())).slice(0, 200);
    return J.card(t(e.id ? 'Edit campaign' : 'Create campaign'), null,
      h('div', { class: 'cp-form' },
        h('label', null, t('Name'), h('input', { id: 'cp-name', maxlength: 80, value: e.name, onInput: (x) => { e.name = x.target.value; } })),
        h('label', null, t('Description'), h('textarea', { rows: 2, maxlength: 400, 'data-spell': 'on', value: e.description, onInput: (x) => { e.description = x.target.value; } })),
        h('label', null, t('Software operation'), h('select', { onChange: (x) => { e.op = x.target.value; } }, OPS.map(([v, l]) => h('option', { value: v, selected: Number(e.op) === v }, t(l))))),
        h('div', null, h('strong', null, t('Vehicles ({n} chosen)', { n: e.ids.size })),
          J.search('Find vehicle', e.q, (v) => { e.q = v; J.later(() => TR.app.refresh(), 150); }),
          h('div', { class: 'cp-pick', role: 'group', 'aria-label': t('Vehicles') }, !C.vehicles ? J.loading(2) : shown.map((v) => h('label', null,
            h('input', { type: 'checkbox', checked: e.ids.has(v.id), onChange: (x) => { if (x.target.checked) e.ids.add(v.id); else e.ids.delete(v.id); TR.app.refresh(); } }),
            v.series + ' ' + v.number, h('small', { class: 'muted' }, ' · ' + (v.t3 ? 'T3' : 'Legacy') + (v.model ? ' · ' + v.model : '')))))),
        e.id ? J.banner('warning', 'alert', t('Saving makes a new revision: the approval no longer applies and the vehicles need validating again.')) : null,
        h('div', { class: 'jr-stack-row' }, TR.pages.ui.button(t(e.id ? 'Save revision' : 'Create campaign'), 'save', saveEdit, 'primary', { disabled: !e.ids.size }), TR.pages.ui.button(t('Cancel'), null, () => { C.editing = null; TR.app.refresh(); }, 'secondary'))));
  }

  // ------------------------------------------------------------------ detail
  const VAL = { ready: ['Ready', 'good'], blocked: ['Blocked', 'warning'], failed: ['Failed', 'danger'], unknown: ['Unknown', 'neutral'], running: ['Validating', 'info'], stale: ['Stale', 'stale'] };
  const APP = { approved: ['Approved', 'good'], submitted: ['Submitted', 'good'], pending: ['Pending', 'neutral'], 'not-ready': ['Not ready', 'neutral'] };
  const dot = (map, k) => h('span', { class: 'cp-dot tone-' + (map[k] || ['', 'neutral'])[1] }, h('i', { 'aria-hidden': 'true' }), t((map[k] || [k])[0]));
  /** A slim bar in ready / blocked / stale / unknown order with 2 px gaps; the numbers are in the words beside it. */
  function bar(c, total, slim) {
    const seg = (k, n) => (n ? h('i', { class: 'k-' + k, style: { flex: n } }) : null);
    return h('div', { class: ['cp-bar', slim && 'is-slim'], role: 'img', 'aria-label': t('{a} ready, {b} blocked, {c} unknown, {d} stale of {n}', { a: c.ready, b: c.blocked, c: c.unknown + (c.running || 0), d: c.stale, n: total }) },
      total ? [seg('ready', c.ready), seg('blocked', c.blocked), seg('stale', c.stale), seg('unknown', c.unknown + (c.running || 0))] : h('i', { class: 'k-empty', style: { flex: 1 } }));
  }
  function readiness(d) {
    const c = d.counts;
    const legend = [['ready', c.ready, 'Ready'], ['blocked', c.blocked, 'Blocked'], ['stale', c.stale, 'Stale'], ['unknown', c.unknown + c.running, c.running ? 'Unknown or validating' : 'Unknown']];
    return h('section', { class: 'cp-readiness', 'aria-label': t('Readiness') },
      h('div', { class: 'cp-ready-head' },
        h('div', null, h('span', { class: 'cp-label' }, t('Readiness')), h('strong', { class: 'cp-ready-big' }, t('{a} of {n} vehicles ready', { a: c.ready, n: d.total }))),
        c.running ? J.chip('running', t('{n} validating', { n: c.running })) : null),
      bar(c, d.total),
      h('div', { class: 'jr-legend cp-legend' }, legend.map(([k, n, l]) => h('span', { class: n ? '' : 'is-zero' }, h('i', { class: 'cp-key k-' + k, 'aria-hidden': 'true' }), h('strong', null, String(n)), ' ', t(l)))),
      h('small', { class: 'muted' }, t(d.approvalState === 'approved' ? 'Readiness reflects current checks; this revision is approved.' : 'Readiness reflects current checks; approval is still required.')));
  }
  function steps(d) {
    const v = d.counts, validated = d.total && !v.unknown && !v.running;
    const st = [['Define scope', d.total ? 'done' : 'current'], ['Prepare', d.template ? 'done' : 'current'], ['Validate', validated ? 'done' : v.running || d.validations.some((x) => x.current) ? 'current' : 'pending'],
      ['Review', d.approvalState === 'approved' || d.approvalState === 'submitted' ? 'done' : validated ? 'current' : 'pending'], ['Submit', d.status === 'submitted' ? 'done' : d.approvalState === 'approved' ? 'current' : 'pending']];
    const word = { done: 'Completed', current: 'In progress', pending: 'Pending' };
    return h('ol', { class: 'jr-steps cp-steps', 'aria-label': t('Campaign progress') }, st.map(([l, s], i) => h('li', { class: s === 'done' ? 'is-done' : s === 'current' ? 'is-current' : '', 'aria-current': s === 'current' ? 'step' : null },
      h('span', { class: 'jr-step-dot', 'aria-hidden': 'true' }, s === 'done' ? TR.icon('check', 14) : String(i + 1)), h('span', null, t(l)), h('small', { class: 'muted' }, t(word[s])))));
  }
  function nextAction(d, v) {
    const go = {
      Validate: () => act('/validate', { vehicleIds: [v.id] }, 'Validation started.'),
      Track: () => { const b = d.validations.find((x) => x.current); if (b && TR.batch) { TR.batch.follow(b.batchId); TR.pages.show('batch'); } },
      Resolve: () => (v.resultId ? J.open('execution', { rid: v.resultId }) : J.open('impact', { vid: v.id })),
      Review: () => { C.dtab = 'vehicles'; TR.app.refresh(); setTimeout(() => { const el = document.querySelector('.cp-submit'); if (el) el.scrollIntoView({ block: 'center' }); }, 0); },
      Submit: () => { const el = document.querySelector('.cp-submit'); if (el) el.scrollIntoView({ block: 'center' }); },
      Receipt: () => { C.dtab = 'evidence'; TR.app.refresh(); },
    }[v.next];
    return h('button', { class: 'jr-link', onClick: go || null }, t(v.next));
  }
  function vehiclesTab(d) {
    const list = d.vehicles.filter((v) => (!C.vstatus || v.validation === C.vstatus) && (!C.vq || (v.title + v.id).toLowerCase().replace(/\s|\|/g, '').includes(C.vq.toLowerCase().replace(/\s/g, ''))));
    const pages = Math.max(1, Math.ceil(list.length / C.size)); C.page = Math.min(C.page, pages - 1);
    const shown = list.slice(C.page * C.size, (C.page + 1) * C.size);
    const all = shown.length > 0 && shown.every((v) => C.picked.has(v.id));
    return h('div', null,
      h('div', { class: 'jr-filters' }, J.search('Find vehicle', C.vq, (v) => { C.vq = v; C.page = 0; J.later(() => TR.app.refresh(), 150); }),
        J.select('Status', C.vstatus, [['', 'All'], ['ready', 'Ready'], ['blocked', 'Blocked'], ['unknown', 'Unknown'], ['running', 'Validating'], ['stale', 'Stale']], (v) => { C.vstatus = v; C.page = 0; TR.app.refresh(); }),
        h('span', { class: 'spacer' }), C.picked.size ? h('strong', null, t('{n} selected', { n: C.picked.size })) : null,
        TR.pages.ui.button(t(C.picked.size ? 'Validate selected' : 'Validate all'), 'play', () => act('/validate', { vehicleIds: C.picked.size ? [...C.picked] : null }, 'Validation started.'), 'secondary', { disabled: C.busy || d.status === 'submitted' || d.status === 'archived' })),
      h('div', { class: 'jr-table-wrap' }, h('table', { class: 'jr-table cp-table' },
        h('thead', null, h('tr', null, h('th', null, h('input', { type: 'checkbox', checked: all, 'aria-label': t('Select all shown vehicles'), onChange: (e) => { shown.forEach((v) => (e.target.checked ? C.picked.add(v.id) : C.picked.delete(v.id))); TR.app.refresh(); } })),
          ['Vehicle', 'Architecture', 'Validation', 'Approval', 'Next action'].map((c) => h('th', null, t(c))))),
        h('tbody', null, shown.map((v) => h('tr', { class: C.picked.has(v.id) ? 'is-sel' : '' },
          h('td', null, h('input', { type: 'checkbox', checked: C.picked.has(v.id), 'aria-label': t('Select {v}', { v: v.title }), onChange: (e) => { if (e.target.checked) C.picked.add(v.id); else C.picked.delete(v.id); TR.app.refresh(); } })),
          h('td', null, h('strong', null, v.title.replace(' ', '')), v.error ? h('small', { class: 'muted' }, ' · ' + v.error) : null), h('td', null, v.architecture),
          h('td', null, dot(VAL, v.validation), v.blocking ? h('small', { class: 'muted' }, ' · ' + t('{n} blocking', { n: v.blocking })) : null), h('td', null, dot(APP, v.approval)), h('td', null, nextAction(d, v))))))),
      list.length > C.size ? h('footer', { class: 'jr-pager' }, h('span', { class: 'muted' }, t('Showing {a}–{b} of {n}', { a: C.page * C.size + 1, b: Math.min(list.length, (C.page + 1) * C.size), n: list.length })), h('span', { class: 'spacer' }),
        TR.pages.ui.button(t('Previous'), 'left', () => { C.page--; TR.app.refresh(); }, 'secondary', { disabled: C.page === 0 }), TR.pages.ui.button(t('Next'), 'right', () => { C.page++; TR.app.refresh(); }, 'secondary', { disabled: C.page >= pages - 1 })) : null);
  }
  function changesTab(d) {
    const op = OPS.find(([v]) => v === Number(d.template.softwareRequestOperation));
    return h('div', null, J.facts([['Request', d.kind], ['Software operation', op ? t(op[1]) : String(d.template.softwareRequestOperation || '—')], ['Scenario', String(d.template.scenario ?? '—')], ['Revision', String(d.revision)]]),
      h('h3', { class: 'jr-h4' }, t('Template')), h('pre', { class: 'jr-pre', tabindex: '0' }, JSON.stringify(d.template, null, 2)),
      h('p', { class: 'muted jr-small' }, t('Each vehicle gets this request with its own configuration; the exact changes per vehicle appear in its validation and in Change impact.')));
  }
  function evidenceTab(d) {
    return h('div', null,
      h('h3', { class: 'jr-h4' }, t('Validations')), d.validations.length ? h('ul', { class: 'jr-list' }, d.validations.map((v) => h('li', null, t('Revision {r}', { r: v.revision }), ' · ', t('{n} vehicle(s)', { n: v.vehicles }), ' · ', J.ago(v.at), v.current ? ' · ' + t('current') : ' · ' + t('older revision'), ' ',
        h('button', { class: 'jr-link', onClick: () => { if (TR.batch) { TR.batch.follow(v.batchId); TR.pages.show('batch'); } } }, t('Open batch'))))) : h('p', { class: 'muted' }, t('Not validated yet.')),
      h('h3', { class: 'jr-h4' }, t('Approval')), d.approval ? h('p', null, t('Revision {r} approved by {p}, {a}, for {n} vehicle(s).', { r: d.approval.revision, p: d.approval.by, a: J.ago(d.approval.at), n: d.approval.vehicles }), d.approval.note ? h('blockquote', { class: 'rv-quote' }, d.approval.note) : null) : h('p', { class: 'muted' }, t('Not approved.')),
      h('h3', { class: 'jr-h4' }, t('Submission')), d.submission ? h('div', null, h('p', null, t('{s} by {p}, {a}.', { s: d.submission.id, p: d.submission.by, a: J.ago(d.submission.at) })),
        h('ul', { class: 'jr-list' }, d.submission.vehicles.map((v) => h('li', null, v.id.replace('|', ' '), ': ', v.outcome === 'committed' ? J.chip('submitted', t('Committed {a} → {b}', { a: v.from, b: v.to })) : J.chip('stale', t('Skipped')), v.reason ? h('small', { class: 'muted' }, ' ' + v.reason) : null))))
        : h('p', { class: 'muted' }, t('Not submitted.')));
  }
  function activityTab(d) { return h('ol', { class: 'oc-trail' }, d.events.map((e) => h('li', null, h('time', { datetime: e.at }, J.time(e.at)), h('span', { class: 'oc-dot', 'aria-hidden': 'true' }, TR.icon('check', 12)), h('span', null, e.text, h('small', { class: 'muted' }, ' · ' + e.by))))); }
  function submitBar(d) {
    const mine = d.owner.id === me().userId;
    if (d.status === 'submitted') return h('div', { class: 'cp-submit is-ready' }, h('p', null, TR.icon('check', 18), t('Submitted as {s}. No software was installed on a vehicle.', { s: d.submission.id })), TR.pages.ui.button(t('View result'), 'file', () => { C.dtab = 'evidence'; TR.app.refresh(); }, 'secondary'));
    if (d.approvalState === 'approved') return h('div', { class: 'cp-submit is-ready' },
      h('p', null, TR.icon('check', 18), t('Revision {r} is approved for {n} ready vehicle(s). Submitting updates the vehicle repository.', { r: d.revision, n: d.approval.vehicles })),
      canWrite() ? [h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: C.confirm, onChange: (e) => { C.confirm = e.target.checked; const b = document.getElementById('cp-submit'); if (b) b.disabled = !C.confirm || C.busy; } }), t('I confirm the campaign revision.')),
        TR.pages.ui.button(t('Submit campaign'), 'upload', () => act('/submit', { confirmed: true }, 'Campaign submitted.'), 'primary', { id: 'cp-submit', disabled: !C.confirm || C.busy })]
        : h('small', { class: 'muted' }, t('An authorised operator (Reviewer or Admin) submits it.')));
    const ready = d.counts.ready > 0;
    return h('div', { class: 'cp-submit' },
      h('p', null, TR.icon('alert', 18), t('Submission is unavailable until the exact campaign revision is approved.')),
      ready && canWrite() && !mine ? [h('input', { 'aria-label': t('Note'), placeholder: t('Note (required to request changes)'), value: C.note, maxlength: 500, onInput: (e) => { C.note = e.target.value; } }),
        TR.pages.ui.button(t('Approve revision {r}', { r: d.revision }), 'check', () => act('/decision', { decision: 'approve', note: C.note }, 'Approval recorded.'), 'primary', { disabled: C.busy }),
        TR.pages.ui.button(t('Request changes'), 'pencil', () => (C.note.trim() ? act('/decision', { decision: 'request_changes', note: C.note }, 'Changes requested.') : TR.notify.toast(t('Write a note saying what needs to change.'), 'error')), 'secondary', { disabled: C.busy })]
        : [TR.pages.ui.button(t('Submit campaign'), 'upload', null, 'primary', { disabled: true }),
          h('small', { class: 'muted' }, t(!ready ? 'Validate the vehicles first; approval needs at least one ready vehicle.' : mine ? 'You own this campaign, so another reviewer must approve it (separation of duties).' : 'Approval needs the Reviewer or Admin role.'))]);
  }
  function detail() {
    const d = C.detail;
    if (C.editing) return editor();
    if (!d) return J.card(null, null, J.empty('No campaign chosen', 'Choose a campaign or create one.'));
    const closed = d.status === 'submitted' || d.status === 'archived';
    return h('section', { class: 'jr-card', 'aria-label': d.name },
      h('header', { class: 'cp-detail-head' },
        h('div', null, h('h2', null, d.name, h('span', { class: 'jr-pill' }, d.code), statusChip(d)), d.description ? h('p', { class: 'muted' }, d.description) : null),
        h('div', { class: 'jr-actions' },
          !closed ? TR.pages.ui.button(t('Edit'), 'pencil', () => startEdit(d), 'secondary') : null,
          !closed && d.owner.id === me().userId ? TR.pages.ui.button(t('Archive'), 'trash', () => act('/archive', {}, 'Campaign archived.'), 'text') : null)),
      h('dl', { class: 'cp-facts' },
        h('div', null, h('dt', null, t('Campaign revision')), h('dd', null, String(d.revision))),
        h('div', null, h('dt', null, t('Target')), h('dd', null, t('Vehicle repository'))),
        h('div', null, h('dt', null, t('Owner')), h('dd', null, d.owner ? d.owner.name : '—')),
        h('div', null, h('dt', null, t('Approval')), h('dd', null, J.chip(d.approvalState === 'approved' ? 'approved' : d.approvalState === 'submitted' ? 'submitted' : d.approvalState === 'changes' ? 'changes' : 'pending')))),
      readiness(d), steps(d),
      h('div', { class: 'jr-tabs', role: 'tablist' }, [['vehicles', 'Vehicles'], ['changes', 'Changes'], ['evidence', 'Evidence'], ['activity', 'Activity']].map(([k, l]) => h('button', { role: 'tab', 'aria-selected': String(C.dtab === k), class: C.dtab === k ? 'is-on' : '', onClick: () => { C.dtab = k; TR.app.refresh(); } }, t(l)))),
      C.dtab === 'vehicles' ? vehiclesTab(d) : C.dtab === 'changes' ? changesTab(d) : C.dtab === 'evidence' ? evidenceTab(d) : activityTab(d),
      submitBar(d));
  }

  function render() {
    if (!C.list && !C.error) loadList();
    const head = J.pageHead('Campaigns', 'Coordinate approved changes across eligible vehicles.', [
      TR.pages.ui.button(t('Create campaign'), 'plus', () => startEdit(null), 'primary'),
      TR.pages.ui.button(t('How campaigns work'), 'book', () => (TR.help ? TR.help.open('campaigns') : TR.pages.show('help')), 'secondary')]);
    if (!C.list) return h('div', { class: 'jr-page' }, head, C.error ? J.failed(C.error, loadList) : J.loading(5));
    const list = filterList(C.list, Object.assign({}, C, { me: me().userId }));
    const active = C.list.filter((c) => ['active', 'approved', 'changes_requested', 'draft'].includes(c.status));
    const attention = active.reduce((a, c) => a + attentionOf(c), 0);
    const ready = active.reduce((a, c) => a + ((c.counts && c.counts.ready) || 0), 0);
    const awaiting = C.list.filter((c) => c.awaitingApproval).length;
    const flag = (k) => () => { C.flag = C.flag === k ? '' : k; if (k === 'active') { C.flag = ''; C.tab = C.tab === 'active' ? 'all' : 'active'; } TR.app.refresh(); };
    return h('div', { class: 'jr-page cp-page' }, head,
      h('div', { class: 'jr-tabs', role: 'tablist', 'aria-label': t('Campaigns') }, [['all', 'All campaigns'], ['active', 'Active'], ['mine', 'My campaigns'], ['archived', 'Archived']].map(([k, l]) =>
        h('button', { role: 'tab', 'aria-selected': String(C.tab === k), class: C.tab === k ? 'is-on' : '', onClick: () => { C.tab = k; TR.app.refresh(); } }, t(l)))),
      h('div', { class: 'cp-stats' }, J.stats([
        { n: C.list.filter((c) => ['active', 'approved'].includes(c.status)).length, label: 'Active campaigns', icon: 'bell', tone: 'info', on: C.tab === 'active', onClick: flag('active') },
        { n: ready, label: 'Vehicles ready', icon: 'check', tone: 'good', on: C.flag === 'ready', onClick: flag('ready') },
        { n: attention, label: 'Vehicles need attention', icon: 'alert', tone: 'warning', on: C.flag === 'attention', onClick: flag('attention') },
        { n: awaiting, label: 'Awaiting approval', icon: 'clock', tone: 'stale', on: C.flag === 'awaiting', onClick: flag('awaiting') }])),
      h('div', { class: 'cp-layout' },
        h('section', { class: 'jr-card cp-list', 'aria-label': t('Campaigns') },
          h('div', { class: 'cp-list-tools' }, J.search('Find campaign', C.q, (v) => { C.q = v; J.later(() => TR.app.refresh(), 150); }),
            J.select('Status', C.status, [['', 'All'], ['draft', 'Draft'], ['active', 'Active'], ['approved', 'Approved'], ['changes_requested', 'Changes requested'], ['submitted', 'Submitted'], ['archived', 'Archived']], (v) => { C.status = v; TR.app.refresh(); })),
          C.flag ? h('p', { class: 'cp-flag' }, t({ ready: 'Showing campaigns with ready vehicles', attention: 'Showing campaigns whose vehicles need attention', awaiting: 'Showing campaigns awaiting approval' }[C.flag]),
            h('button', { class: 'jr-link', onClick: () => { C.flag = ''; TR.app.refresh(); } }, t('Show all'))) : null,
          list.length ? list.map((c) => h('button', { class: ['cp-item', C.selected === c.id ? 'is-sel' : ''], 'aria-pressed': String(C.selected === c.id), onClick: () => { C.selected = c.id; C.editing = null; C.dtab = 'vehicles'; loadDetail(c.id); } },
            h('span', { class: 'cp-item-top' }, h('strong', null, c.name), statusChip(c)),
            h('span', { class: 'cp-item-meta' }, h('span', { class: 'cp-code' }, c.code), ' · ', t('{n} vehicles', { n: c.total }), ' · ', t('Owner: {o}', { o: c.owner.name })),
            c.counts ? h('span', { class: 'cp-item-ready' }, bar(c.counts, c.total, true), h('small', null, t('{a} of {n} ready', { a: c.counts.ready, n: c.total }), attentionOf(c) ? ' · ' + t('{n} need attention', { n: attentionOf(c) }) : '')) : null))
            : J.empty('No campaigns match', 'Change the tab or filters, or create a campaign.')),
        C.editing || list.some((c) => c.id === C.selected) ? detail() : list.length ? J.empty('Choose a campaign', 'Select a campaign from the list to inspect its revision and evidence.') : null),
      h('p', { class: 'jr-foot muted' }, t('Repository operations do not install software on vehicles. Campaign states come from batch validations, the approval of the exact revision and the submission.')));
  }
  TR.pages.register({ id: 'campaigns', title: 'Campaigns', crumbs: () => [{ label: t('Tools') }, { label: t('Campaigns') }], render });
  TR.campaigns = { C, loadList, filterList };
})();
