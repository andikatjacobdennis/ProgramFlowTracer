/* Vehicle Insights: what the history and roadmap say, at a glance. Used by the Insights tab of the Vehicle page.
 *
 *   Software timeline – every computer as a lane: which version it ran from the factory build until now, and where the
 *                       upcoming versions fall (release week), including versions that are available but not installed.
 *   Activity calendar – a GitHub-style calendar of everything that happened to the vehicle, per day.
 *   Up to date        – how many computers are on their newest version, have an update available or are blocked.
 *   Most changed      – which computers changed most often.
 *   Insight cards     – the same facts as short sentences.
 *
 * TR.insights.model(...) computes the numbers (no drawing, easy to test); TR.insights.render(...) draws them as SVG. */
(function () {
  'use strict';
  const { h } = TR.util;
  const NS = 'http://www.w3.org/2000/svg';
  const DAY = 86400000;

  // ------------------------------------------------------------------ numbers
  /** Monday of an ISO week given as '202630' (week 30 of 2026). */
  function weekDate(w) {
    if (!/^\d{6}$/.test(String(w || ''))) return null;
    const y = Number(String(w).slice(0, 4)), n = Number(String(w).slice(4));
    const jan4 = Date.UTC(y, 0, 4), day = new Date(jan4).getUTCDay() || 7;
    return new Date(jan4 - (day - 1) * DAY + (n - 1) * 7 * DAY);
  }
  /**
   * entries: the whole timeline (newest first). built: the factory configuration and its date. roadmap: /roadmap.
   * current: the vehicle now. now: the date to treat as today.
   */
  function model({ entries, built, builtAt, roadmap, current, now = new Date() }) {
    const names = ((current && current.nodes) || []).map((n) => n.name);
    const oldest = [...entries].reverse();
    const start = builtAt ? new Date(builtAt) : oldest.length ? new Date(oldest[0].at) : new Date(now.getTime() - 365 * DAY);
    // Version periods per computer, replayed from the build through every change to the vehicle.
    const periods = Object.fromEntries(names.map((n) => [n, []]));
    const open = (node, version, from, entry) => { (periods[node] = periods[node] || []).push({ version, from, to: null, entry }); };
    const close = (node, at) => { const p = (periods[node] || []).slice(-1)[0]; if (p && !p.to) p.to = at; };
    const builtNodes = Object.fromEntries(((built && built.nodes) || []).map((n) => [n.name, n.versionName]));
    for (const n of names) {
      const first = oldest.flatMap((e) => e.changes || []).find((c) => c.node === n && c.from);
      open(n, builtNodes[n] || (first && first.from) || ((current.nodes.find((x) => x.name === n) || {}).versionName), start, 'built');
    }
    let changes = 0;
    const perNode = {};
    for (const e of oldest) {
      if (e.lane === 'proposal') continue;
      for (const c of e.changes || []) {
        if (c.kind === 'Parameters') continue;
        const at = new Date(e.at);
        if (c.kind === 'Removed') close(c.node, at);
        else if (c.kind !== 'Hardware') { close(c.node, at); open(c.node, c.to, at, e.id); }
        perNode[c.node] = (perNode[c.node] || 0) + 1; changes++;
      }
    }
    // Upcoming versions per computer, with the date they were (or will be) introduced.
    const upcoming = Object.fromEntries(((roadmap && roadmap.nodes) || []).map((r) => [r.node, (r.upcoming || []).map((u) => ({ ...u, date: weekDate(u.introductionWeek) }))]));
    const status = Object.fromEntries(names.map((n) => {
      const ups = upcoming[n] || [];
      const free = ups.filter((u) => !u.blockers || !u.blockers.length);
      return [n, !ups.length ? 'current' : free.length ? 'update' : 'blocked'];
    }));
    const count = (s) => names.filter((n) => status[n] === s).length;
    // Days with events, for the calendar.
    const days = {};
    for (const e of entries) { const d = new Date(e.at); const key = d.toISOString().slice(0, 10); (days[key] = days[key] || []).push(e); }
    const futureDates = Object.values(upcoming).flat().map((u) => u.date).filter(Boolean);
    const end = new Date(Math.max(now.getTime() + 30 * DAY, ...futureDates.map((d) => d.getTime() + 21 * DAY)));
    const lastChange = entries.find((e) => e.lane !== 'proposal' && (e.changes || []).length);
    const sims = entries.filter((e) => e.kind === 'Simulation');
    const committed = sims.filter((e) => e.mergedInto).length;
    const longest = names.map((n) => { const p = (periods[n] || []).slice(-1)[0]; return p && !p.to ? { node: n, version: p.version, since: p.from } : null; })
      .filter(Boolean).sort((a, b) => a.since - b.since)[0] || null;
    const nextUpdate = names.flatMap((n) => (upcoming[n] || []).filter((u) => !u.blockers.length).map((u) => ({ node: n, ...u })))
      .sort((a, b) => (a.date ? a.date.getTime() : Infinity) - (b.date ? b.date.getTime() : Infinity))[0] || null;
    const waiting = names.flatMap((n) => (upcoming[n] || []).filter((u) => !u.blockers.length && u.date && u.date < now).map((u) => ({ node: n, ...u })));
    return {
      names, start, end, now, periods, upcoming, status, days,
      counts: { current: count('current'), update: count('update'), blocked: count('blocked'), total: names.length },
      perNode, changes, lastChange, simulations: sims.length, committed, longest, nextUpdate, waiting,
    };
  }

  // ------------------------------------------------------------------ drawing helpers
  function svg(tag, attrs = {}, kids = []) {
    const e = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs)) if (v != null) e.setAttribute(k, String(v));
    for (const k of [].concat(kids)) if (k != null) e.appendChild(typeof k === 'string' ? document.createTextNode(k) : k);
    return e;
  }
  const tip = (text) => svg('title', {}, [text]);
  const C = () => TR.culture;
  const day = (d) => (C() ? C().format.date(d) : new Date(d).toDateString());
  const monthLabel = (d) => { try { return new Intl.DateTimeFormat(C() ? C().active().language : 'en-GB', { month: 'short', year: '2-digit', timeZone: C() ? C().active().timeZone : 'UTC' }).format(d); } catch (e) { return d.toISOString().slice(0, 7); } };
  const STATUS_COLOUR = { Released: 'var(--added)', Introduced: 'var(--lane-0)', 'Pre-release verification': 'var(--replaced)', 'In progress': 'var(--muted)' };

  // ------------------------------------------------------------------ software timeline (swimlanes)
  function timeline(m, onEntry, onNode) {
    const W = 1000, LABEL = 150, ROW = 38, TOP = 34, H = TOP + m.names.length * ROW + 16;
    const t0 = m.start.getTime(), t1 = m.end.getTime();
    const x = (d) => LABEL + (W - LABEL - 12) * ((new Date(d).getTime() - t0) / Math.max(1, t1 - t0));
    const g = svg('svg', { class: 'in-timeline', viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': 'Software versions of each computer over time' });
    // Month grid.
    const ticks = [];
    for (let d = new Date(Date.UTC(m.start.getUTCFullYear(), m.start.getUTCMonth(), 1)); d.getTime() <= t1; d = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1))) if (d.getTime() >= t0) ticks.push(d);
    const every = Math.max(1, Math.ceil(ticks.length / 12));
    ticks.forEach((d, i) => {
      g.appendChild(svg('line', { x1: x(d), x2: x(d), y1: TOP - 8, y2: H - 10, class: 'in-grid' }));
      if (i % every === 0) g.appendChild(svg('text', { x: x(d) + 3, y: TOP - 14, class: 'in-axis' }, [monthLabel(d)]));
    });
    m.names.forEach((name, r) => {
      const y = TOP + r * ROW;
      const row = svg('g', { class: 'in-row in-status-' + m.status[name] });
      g.appendChild(row);
      row.appendChild(svg('rect', { x: 0, y: y + 2, width: W, height: ROW - 4, rx: 6, class: 'in-row-bg' }));
      const label = svg('text', { x: 10, y: y + ROW / 2 + 4, class: 'in-label', tabindex: 0, role: 'button' }, [name.length > 18 ? name.slice(0, 17) + '…' : name]);
      label.addEventListener('click', () => onNode(name));
      row.appendChild(label);
      (m.periods[name] || []).forEach((p, i, all) => {
        const a = x(p.from), b = x(p.to || m.now), current = !p.to;
        const bar = svg('g', { class: ['in-bar', current ? 'is-current' : '', p.entry !== 'built' ? 'is-link' : ''].join(' '), style: `animation-delay:${(r * 40 + i * 60)}ms` }, [
          tip(`${name}: ${p.version || 'unknown'}\n${day(p.from)} – ${p.to ? day(p.to) : 'now'}${p.entry !== 'built' ? '\nClick to see the vehicle at this change' : ''}`),
          svg('rect', { x: a, y: y + 8, width: Math.max(3, b - a - 2), height: ROW - 16, rx: 5, class: 'in-bar-fill', fill: `var(--lane-${i % 5})` }),
          b - a > 70 ? svg('text', { x: a + 8, y: y + ROW / 2 + 4, class: 'in-bar-text' }, [p.version || '']) : null,
        ]);
        if (p.entry !== 'built') bar.addEventListener('click', () => onEntry(p.entry));
        row.appendChild(bar);
        if (i < all.length - 1 || p.to) row.appendChild(svg('circle', { cx: b, cy: y + ROW / 2, r: 3.5, class: 'in-change' }));
      });
      for (const u of m.upcoming[name] || []) {
        if (!u.date) continue;
        const cx = x(u.date), blocked = u.blockers && u.blockers.length, waiting = !blocked && u.date < m.now;
        row.appendChild(svg('g', { class: ['in-up', blocked ? 'is-blocked' : '', waiting ? 'is-waiting' : ''].join(' ') }, [
          tip(`${u.versionName} · ${u.status}\n${waiting ? 'Available since' : 'From'} ${day(u.date)}${blocked ? '\nBlocked: ' + u.blockers.join('; ') : waiting ? '\nAvailable but not installed' : ''}`),
          svg('path', { d: `M${cx},${y + 7} l7,${ROW / 2 - 7} l-7,${ROW / 2 - 7} l-7,${-(ROW / 2 - 7)} z`, fill: blocked ? 'var(--panel)' : STATUS_COLOUR[u.status] || 'var(--muted)', stroke: STATUS_COLOUR[u.status] || 'var(--muted)', 'stroke-width': 2, 'stroke-dasharray': blocked ? '3 2' : null }),
        ]));
      }
    });
    const nx = x(m.now);
    g.appendChild(svg('line', { x1: nx, x2: nx, y1: TOP - 10, y2: H - 6, class: 'in-now' }));
    g.appendChild(svg('text', { x: nx + 4, y: H - 8, class: 'in-now-text' }, ['Now']));
    return g;
  }

  // ------------------------------------------------------------------ activity calendar
  function calendar(m, weeks = 26) {
    const CELL = 13, GAP = 3, LEFT = 26, TOP = 18;
    const today = new Date(Date.UTC(m.now.getUTCFullYear(), m.now.getUTCMonth(), m.now.getUTCDate()));
    const startDay = new Date(today.getTime() - ((today.getUTCDay() + 6) % 7) * DAY - (weeks - 1) * 7 * DAY);
    const W = LEFT + weeks * (CELL + GAP), H = TOP + 7 * (CELL + GAP) + 4;
    const g = svg('svg', { class: 'in-calendar', viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': 'Activity per day over the last six months' });
    ['Mon', 'Wed', 'Fri'].forEach((d, i) => g.appendChild(svg('text', { x: 0, y: TOP + (i * 2) * (CELL + GAP) + CELL - 2, class: 'in-axis small' }, [d])));
    let lastMonth = -1;
    for (let w = 0; w < weeks; w++) {
      for (let d = 0; d < 7; d++) {
        const date = new Date(startDay.getTime() + (w * 7 + d) * DAY);
        if (date > today) continue;
        if (d === 0 && date.getUTCMonth() !== lastMonth) { lastMonth = date.getUTCMonth(); g.appendChild(svg('text', { x: LEFT + w * (CELL + GAP), y: TOP - 6, class: 'in-axis small' }, [monthLabel(date).split(' ')[0]])); }
        const events = m.days[date.toISOString().slice(0, 10)] || [];
        const level = Math.min(4, events.length);
        g.appendChild(svg('rect', { x: LEFT + w * (CELL + GAP), y: TOP + d * (CELL + GAP), width: CELL, height: CELL, rx: 3, class: 'in-cell level-' + level, style: `animation-delay:${w * 12}ms` },
          [tip(`${day(date)}: ${events.length ? events.map((e) => e.title).join(', ') : 'nothing'}`)]));
      }
    }
    return g;
  }

  // ------------------------------------------------------------------ up to date ring
  function ring(m) {
    const R = 54, SW = 16, Cf = 2 * Math.PI * R, total = Math.max(1, m.counts.total);
    const g = svg('svg', { class: 'in-ring', viewBox: '0 0 150 150', role: 'img', 'aria-label': `${m.counts.current} of ${m.counts.total} computers are up to date` });
    g.appendChild(svg('circle', { cx: 75, cy: 75, r: R, class: 'in-ring-track', 'stroke-width': SW, fill: 'none' }));
    let offset = 0;
    [['current', 'var(--added)', 'up to date'], ['update', 'var(--lane-0)', 'with an update available'], ['blocked', 'var(--replaced)', 'blocked']].forEach(([k, colour, text]) => {
      const n = m.counts[k]; if (!n) return;
      const len = Cf * n / total;
      g.appendChild(svg('circle', { cx: 75, cy: 75, r: R, fill: 'none', stroke: colour, 'stroke-width': SW, 'stroke-dasharray': `${len} ${Cf - len}`, 'stroke-dashoffset': -offset, transform: 'rotate(-90 75 75)', class: 'in-ring-seg' }, [tip(`${n} ${n === 1 ? 'computer' : 'computers'} ${text}`)]));
      offset += len;
    });
    g.appendChild(svg('text', { x: 75, y: 72, class: 'in-ring-big', 'text-anchor': 'middle' }, [`${m.counts.current}/${m.counts.total}`]));
    g.appendChild(svg('text', { x: 75, y: 92, class: 'in-ring-small', 'text-anchor': 'middle' }, ['up to date']));
    return g;
  }

  // ------------------------------------------------------------------ most changed
  function bars(m, onNode) {
    const rows = Object.entries(m.perNode).sort((a, b) => b[1] - a[1]).slice(0, 6);
    if (!rows.length) return h('p', { class: 'muted' }, 'No computer has changed since the factory build.');
    const max = rows[0][1];
    return h('ol', { class: 'in-bars' }, rows.map(([node, n], i) => h('li', null,
      h('button', { class: 'in-bars-name', onClick: () => onNode(node), title: 'Show ' + node + ' in the graph' }, node),
      h('span', { class: 'in-bars-track' }, h('span', { class: 'in-bars-fill', style: { width: (100 * n / max) + '%', animationDelay: i * 70 + 'ms' } })),
      h('strong', null, String(n)))));
  }

  // ------------------------------------------------------------------ insight cards
  const ago = (d, now) => { const n = Math.round((now - new Date(d)) / DAY); return n <= 0 ? 'today' : n === 1 ? 'yesterday' : n < 60 ? `${n} days ago` : `${Math.round(n / 30)} months ago`; };
  function cards(m) {
    const list = [];
    list.push({ icon: 'check', tone: m.counts.update || m.counts.blocked ? 'info' : 'good', title: `${m.counts.current} of ${m.counts.total} computers are up to date`,
      text: m.counts.update ? `${m.counts.update} can be updated now${m.counts.blocked ? `, ${m.counts.blocked} wait for hardware or another computer` : ''}.` : m.counts.blocked ? `${m.counts.blocked} have newer versions that are blocked.` : 'Nothing newer exists in the catalog.' });
    if (m.waiting.length) list.push({ icon: 'clock', tone: 'warn', title: `${m.waiting.length} available update${m.waiting.length === 1 ? ' is' : 's are'} not installed`, text: m.waiting.slice(0, 3).map((u) => `${u.versionName} since ${day(u.date)}`).join(', ') + (m.waiting.length > 3 ? '…' : '.') });
    if (m.nextUpdate) list.push({ icon: 'route', tone: 'info', title: `Next step: ${m.nextUpdate.versionName}`, text: `${m.nextUpdate.status}${m.nextUpdate.date ? ', from ' + day(m.nextUpdate.date) : ''}. Nothing blocks it.` });
    if (m.longest) list.push({ icon: 'history', tone: 'neutral', title: `${m.longest.node} changed least recently`, text: `On ${m.longest.version} since ${day(m.longest.since)} (${ago(m.longest.since, m.now)}).` });
    if (m.lastChange) list.push({ icon: 'people', tone: 'neutral', title: `Last change ${ago(m.lastChange.at, m.now)}`, text: `${m.lastChange.title} by ${m.lastChange.actor.name}.` });
    if (m.simulations) list.push({ icon: 'flask', tone: 'neutral', title: `${m.simulations} simulation${m.simulations === 1 ? '' : 's'}, ${m.committed} committed`, text: m.committed ? `${Math.round(100 * m.committed / m.simulations)}% of your simulations became a VDA change.` : 'None has been committed to VDA yet.' });
    return list;
  }

  // ------------------------------------------------------------------ page section
  /** ctx: { entries, built, builtAt, roadmap, current, onEntry(entryId), onNode(name), loading } */
  function render(ctx) {
    if (ctx.loading) return h('div', { class: 'in-page' }, h('p', { class: 'muted' }, 'Reading the whole history…'), TR.historyGraph ? h('ol', { class: 'gh-graph' }, TR.historyGraph.skeleton(4)) : null);
    const m = model(ctx);
    return h('div', { class: 'in-page' },
      h('div', { class: 'in-cards' }, cards(m).map((c, i) => h('div', { class: 'in-card tone-' + c.tone, style: { animationDelay: i * 60 + 'ms' } }, h('span', { class: 'in-card-icon' }, TR.icon(c.icon, 18)), h('div', null, h('strong', null, c.title), h('p', null, c.text))))),
      h('section', { class: 'in-panel in-wide' },
        h('div', { class: 'in-panel-head' }, h('h2', null, 'Software timeline'), h('p', null, 'Each bar is the version a computer ran, from the factory build until now. Diamonds are upcoming versions at their release week: filled can be installed, dashed are blocked, amber outlines are available but not installed. Click a bar to see the vehicle at that change.')),
        h('div', { class: 'in-scroll' }, timeline(m, ctx.onEntry, ctx.onNode)),
        h('div', { class: 'in-legend' }, [['var(--added)', 'Released'], ['var(--lane-0)', 'Introduced'], ['var(--replaced)', 'Pre-release verification'], ['var(--muted)', 'In progress']].map(([c, t]) => h('span', null, h('i', { style: { background: c } }), t)))),
      h('div', { class: 'in-grid2' },
        h('section', { class: 'in-panel' }, h('div', { class: 'in-panel-head' }, h('h2', null, 'Up to date'), h('p', null, 'Computers on their newest version, with an update available, or blocked.')),
          h('div', { class: 'in-ring-wrap' }, ring(m), h('ul', { class: 'in-ring-legend' },
            h('li', null, h('i', { style: { background: 'var(--added)' } }), `${m.counts.current} up to date`), h('li', null, h('i', { style: { background: 'var(--lane-0)' } }), `${m.counts.update} update available`), h('li', null, h('i', { style: { background: 'var(--replaced)' } }), `${m.counts.blocked} blocked`)))),
        h('section', { class: 'in-panel' }, h('div', { class: 'in-panel-head' }, h('h2', null, 'Most changed'), h('p', null, 'How often each computer changed since it was built.')), bars(m, ctx.onNode))),
      h('section', { class: 'in-panel in-wide' },
        h('div', { class: 'in-panel-head' }, h('h2', null, 'Activity'), h('p', null, 'Everything that happened to this vehicle in the last six months, one square per day, like a GitHub contribution calendar.')),
        h('div', { class: 'in-scroll' }, calendar(m)),
        h('div', { class: 'in-legend' }, h('span', null, 'Less'), [0, 1, 2, 3, 4].map((l) => h('i', { class: 'in-cell-key level-' + l })), h('span', null, 'More'))));
  }

  TR.insights = { model, render, weekDate, cards, calendar, ring, svg };
})();
