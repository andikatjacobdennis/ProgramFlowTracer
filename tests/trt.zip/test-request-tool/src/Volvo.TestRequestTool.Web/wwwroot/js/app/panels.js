/* Fewer dialogs. Details, forms and results that used to open as modal dialogs now open in a docked side panel:
 *
 *   – the page stays usable and visible: nothing is dimmed or blocked, and the content moves aside instead of being covered;
 *   – one panel at a time; opening another from inside a panel keeps a Back button to the previous one;
 *   – "Wider" gives the panel more room; Esc or ✕ closes it and focus returns to where it was;
 *   – plain messages (TR.ui.alert) become toasts; long ones open in the panel.
 *
 * A real modal remains only where the user must answer before anything else happens: confirming an irreversible action
 * (TR.ui.confirm), or a caller that asks for it with { modal: true }.
 *
 * Also here: the Connections page (FR-21), which replaces the "Service connection status" dialog. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));
  const originalModal = TR.ui.modal;
  const root = document.documentElement;
  const stack = [];
  let host = null;
  const clear = (el) => { while (el.firstChild) el.removeChild(el.firstChild); };

  function container() {
    if (host && host.isConnected) return host;
    host = h('aside', { id: 'ap-panels', class: 'ap-panels', 'aria-live': 'polite' });
    document.body.appendChild(host);
    return host;
  }
  const widthOf = (opts) => {
    const w = typeof opts.width === 'number' ? opts.width : parseInt(opts.width, 10) || 560;
    return Math.max(380, Math.min(w, 880));
  };
  function layout() {
    const top = stack[stack.length - 1];
    root.classList.toggle('has-panel', !!top);
    // At most half the window (70 % when wider), so the page beside it stays usable; narrow windows overlay it (CSS).
    const vw = window.innerWidth || 1280;
    if (top) root.style.setProperty('--ap-panel-w', Math.round(top.wide ? Math.min(Math.max(top.width, 760), vw * 0.7) : Math.min(top.width, top.resized ? vw * 0.8 : vw * 0.5)) + 'px');
    else root.style.removeProperty('--ap-panel-w');
    stack.forEach((p) => { p.el.hidden = p !== top; });
  }

  function panel(opts) {
    const returnFocus = document.activeElement;
    const el = h('section', { class: ['ap-panel', opts.class], role: 'region', 'aria-label': typeof opts.title === 'string' ? opts.title : t('Details'), tabIndex: -1 });
    const api = {
      el, closed: false, width: widthOf(opts), wide: false,
      close(result) {
        if (api.closed) return;
        api.closed = true;
        el.remove();
        const i = stack.indexOf(api);
        if (i >= 0) stack.splice(i, 1);
        layout();
        if (returnFocus && returnFocus.isConnected) returnFocus.focus();
        if (opts.onClose) opts.onClose(result);
      },
      render() {
        TR.util.preserve(() => {
          clear(el);
          const title = typeof opts.title === 'function' ? opts.title() : opts.title;
          const below = stack.indexOf(api) > 0 ? stack[stack.indexOf(api) - 1] : null;
          // Resize: drag the edge, or focus it and use the arrow keys (Home and End for the smallest and largest).
          el.appendChild(h('div', { class: 'ap-panel-resize', role: 'separator', 'aria-orientation': 'vertical', 'aria-label': t('Resize panel'), tabindex: '0', 'aria-valuemin': 320, 'aria-valuemax': Math.round((window.innerWidth || 1280) * 0.8), 'aria-valuenow': api.width,
            onKeydown: (e) => { const step = e.shiftKey ? 80 : 24; const set = (w) => { e.preventDefault(); api.width = Math.max(320, Math.min(Math.round((window.innerWidth || 1280) * 0.8), w)); api.wide = false; api.resized = true; layout(); api.render(); setTimeout(() => { const r = el.querySelector('.ap-panel-resize'); if (r) r.focus(); }, 0); };
              if (e.key === 'ArrowLeft') set(api.width + step); else if (e.key === 'ArrowRight') set(api.width - step); else if (e.key === 'Home') set(320); else if (e.key === 'End') set(99999); },
            onPointerdown: (e) => { e.preventDefault(); const startX = e.clientX, startW = api.width; const move = (m) => { api.width = Math.max(320, Math.min(Math.round((window.innerWidth || 1280) * 0.8), startW + (startX - m.clientX))); api.wide = false; api.resized = true; layout(); }; const up = () => { removeEventListener('pointermove', move); removeEventListener('pointerup', up); api.render(); }; addEventListener('pointermove', move); addEventListener('pointerup', up); } }));
          el.appendChild(h('header', { class: 'ap-panel-head' },
            below ? h('button', { class: 'ap-icon-btn', 'data-tip': t('Back'), 'aria-label': t('Back'), onClick: () => api.close() }, TR.icon('back', 16)) : null,
            h('h2', { class: 'ap-panel-title' }, title || ''),
            h('button', { class: 'ap-icon-btn', 'aria-pressed': String(api.wide), 'data-tip': api.wide ? t('Narrower') : t('Wider'), 'aria-label': api.wide ? t('Narrower') : t('Wider'), onClick: () => { api.wide = !api.wide; layout(); api.render(); } }, TR.icon(api.wide ? 'collapse' : 'expand', 16)),
            h('button', { class: 'ap-icon-btn', 'data-tip': t('Close') + '|Esc', 'aria-label': t('Close'), onClick: () => { while (stack.length && stack[stack.length - 1] !== api) stack[stack.length - 1].close(); api.close(); } }, '✕')));
          const body = h('div', { class: 'ap-panel-body', 'data-scroll': 'panel-' + (opts.id || title) });
          const content = typeof opts.body === 'function' ? opts.body(api) : opts.body;
          if (content) body.appendChild(content);
          el.appendChild(body);
          const suppliedButtons = typeof opts.buttons === 'function' ? opts.buttons(api) : opts.buttons;
          // The persistent header close replaces a redundant plain Close footer action.
          const buttons = (suppliedButtons || []).filter((b) => b && (b instanceof Node || b.onClick || b.danger || !['Close', t('Close')].includes(b.label)));
          if (buttons && buttons.length) {
            el.appendChild(h('footer', { class: 'ap-panel-foot' }, buttons.filter(Boolean).map((b) => (b instanceof Node ? b : h('button', {
              type: 'button', class: ['btn', b.primary && 'primary', b.danger && 'danger'], disabled: !!b.disabled, title: b.title || '', onClick: () => (b.onClick ? b.onClick(api) : api.close()),
            }, b.label)))));
          }
        });
      },
    };
    stack.push(api);
    container().appendChild(el);
    layout();
    api.render();
    if (opts.autofocus !== false) setTimeout(() => {
      if (api.closed) return;
      const first = el.querySelector('.ap-panel-body input:not([type=checkbox]):not([type=radio]):not([disabled]), .ap-panel-body textarea, .ap-panel-body select');
      (first || el).focus({ preventScroll: true });
    }, 0);
    return api;
  }

  window.addEventListener('resize', TR.util.debounce ? TR.util.debounce(layout, 100) : layout);
  TR.ui.modal = (opts) => (opts && opts.modal ? originalModal(opts) : panel(opts || {}));
  TR.ui.panel = panel;
  TR.ui.panels = { stack, closeAll: () => { while (stack.length) stack[stack.length - 1].close(); } };

  // Esc closes the top panel, unless a real dialog or another layer is on top (they handle Esc themselves).
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || !stack.length || e.defaultPrevented) return;
    if (document.querySelector('#overlays .overlay, .tr-layer, .wl-layer, .pl-layer')) return;
    e.preventDefault();
    stack[stack.length - 1].close();
  });

  // Messages: a toast for short text; the panel for long or multi-line text. No OK button to dismiss.
  const originalAlert = TR.ui.alert;
  TR.ui.alert = (text, title) => {
    const s = String(text == null ? '' : text);
    if (!TR.notify || !TR.notify.toast) return originalAlert(s, title);
    if (s.length > 180 || s.includes('\n')) { panel({ title: title || t('Message'), width: 520, body: h('div', { class: 'pre-line' }, s) }); return Promise.resolve(); }
    TR.notify.toast(title ? title + ': ' + s : s, /error|could not|failed|cannot|not allowed|denied/i.test(s) ? 'error' : 'info');
    return Promise.resolve();
  };
  // TR.ui.confirm stays a real dialog: it asks before an irreversible action.

  // ------------------------------------------------------------------ Connections page (FR-21), instead of a dialog
  const C = { rows: null, error: null, loading: false, checking: {} };
  async function loadConnections(force) {
    if ((C.rows && !force) || C.loading) return;
    C.loading = true;
    try { C.rows = await TR.pages.ui.api('/integrations/health'); C.error = null; } catch (e) { C.error = e.message; }
    C.loading = false;
    TR.app.refresh();
  }
  async function check(name) {
    C.checking[name] = true; TR.app.refresh();
    try {
      const r = await fetch('/api/v1/integrations/' + encodeURIComponent(name) + '/check', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
      const state = await r.json();
      if (r.ok) C.rows = (C.rows || []).map((x) => (x.name === state.name ? state : x));
      else TR.notify && TR.notify.toast(state.detail || state.title, 'error');
    } catch (e) { TR.notify && TR.notify.toast(e.message, 'error'); }
    C.checking[name] = false; TR.app.refresh();
  }
  const HEALTH = {
    'not-configured': ['Not connected', 'neutral', 'Not configured, so never asked. Results never claim its checks.'],
    unknown: ['Not checked yet', 'neutral', 'Configured; no call has been made yet.'],
    healthy: ['Healthy', 'good', 'Configured and answering.'],
    degraded: ['Degraded', 'warning', 'Configured, but recent calls failed. It is retried with back-off.'],
    unhealthy: ['Unavailable', 'danger', 'Configured, but failing: calls pause briefly so the workspace stays responsive.'],
  };
  const when = (v) => (v ? TR.pages.ui.when(v) : '—');
  function connections() {
    loadConnections();
    const ui = TR.pages.ui, rows = C.rows || [];
    const configured = rows.filter((r) => r.configured).length;
    return h('div', { class: 'st-page cn-page' },
      h('div', { class: 'st-head' }, h('h1', null, t('Connections')),
        h('p', { class: 'muted' }, t('Each external system, whether it is configured, and whether it is healthy. Configured is not the same as healthy.'))),
      h('section', { class: 'cn-summary' },
        h('div', { class: 'cn-stat' }, h('strong', null, String(rows.length)), h('span', null, t('integrations'))),
        h('div', { class: 'cn-stat' }, h('strong', null, String(configured)), h('span', null, t('configured'))),
        h('div', { class: 'cn-stat' }, h('strong', null, String(rows.filter((r) => r.health === 'healthy').length)), h('span', null, t('healthy'))),
        h('span', { class: 'spacer' }),
        ui.button(t('Refresh'), 'refresh', () => loadConnections(true))),
      configured === 0 && rows.length ? h('div', { class: 's-banner' }, TR.icon('help'), t('No live system is connected in this installation. Every result is a simulation and says so; nothing claims KAX, VESPA, Dependix or Digital Twin checks.')) : null,
      C.error ? h('div', { class: 's-banner warning' }, TR.icon('alert'), C.error) : null,
      !C.rows && !C.error ? h('p', { class: 'muted' }, t('Loading…')) : null,
      h('div', { class: 'cn-grid' }, rows.map((r) => {
        const [label, tone, meaning] = HEALTH[r.health] || [r.health, 'neutral', ''];
        return h('article', { class: ['cn-card', 'tone-' + tone] },
          h('header', null, h('span', { class: 'cn-dot', 'aria-hidden': 'true' }), h('h2', null, r.name), ui.chip(t(label), tone === 'danger' ? 'warning' : tone)),
          h('p', { class: 'muted' }, t(meaning)),
          h('dl', { class: 'cn-facts' },
            h('dt', null, t('Configured')), h('dd', null, r.configured ? t('Yes') : t('No')),
            h('dt', null, t('Reachable')), h('dd', null, r.reachable == null ? t('Unknown') : r.reachable ? t('Yes') : t('No')),
            h('dt', null, t('Signed in')), h('dd', null, r.authenticated == null ? t('Unknown') : r.authenticated ? t('Yes') : t('No')),
            h('dt', null, t('Last success')), h('dd', null, when(r.lastSuccess)),
            h('dt', null, t('Last failure')), h('dd', null, r.lastFailure ? when(r.lastFailure) + (r.lastError ? ' · ' + r.lastError : '') : '—'),
            h('dt', null, t('In progress')), h('dd', null, String(r.inFlight || 0))),
          h('footer', null, r.configured
            ? ui.button(C.checking[r.name] ? t('Checking…') : t('Check now'), 'pulse', () => check(r.name), 'secondary')
            : h('span', { class: 'muted' }, t('Nothing to check until it is configured.'))));
      })));
  }
  TR.pages.register({ id: 'connections', title: 'Connections', crumbs: () => [{ label: t('Connections') }], render: connections });
  TR.connections = { C, load: loadConnections };
})();
