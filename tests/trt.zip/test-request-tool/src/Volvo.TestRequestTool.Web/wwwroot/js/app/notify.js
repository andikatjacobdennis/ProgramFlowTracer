/* Toasts, the notifications panel, the status bar and two-line tooltips.
 *
 *   TR.notify.toast(text, tone?, { action? })  – a short message at the bottom (3.2 s); it is also kept in the panel
 *   TR.notify.panel()                          – the notifications panel (the bell in the top bar)
 *   data-tip="Label|detail"                    – any element gets a two-line tooltip on hover or keyboard focus
 *
 * The status bar along the bottom shows whether the app is working, the vehicle in use (with a dot for unsaved changes),
 * your role and the time in your time zone. Ideas from Thachu Studio, Harness and DocGen Explorer. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => TR.i18n.t(s, v);
  const N = { items: [], unread: 0, open: false, busy: 0, el: null };
  const ICON = { info: 'info', success: 'check', warning: 'alert', error: 'alert' };

  // ------------------------------------------------------------------ toasts and the panel
  function host() { let el = document.querySelector('.nt-host'); if (!el) { el = h('div', { class: 'nt-host', role: 'status', 'aria-live': 'polite' }); document.body.appendChild(el); } return el; }
  function toast(text, tone = 'info', opts = {}) {
    N.items.unshift({ text, tone, at: new Date() }); N.items = N.items.slice(0, 50); N.unread++;
    if (typeof document.body === 'undefined' || !document.body) return;
    const el = h('div', { class: 'nt-toast tone-' + tone }, TR.icon(ICON[tone] || 'info', 16), h('span', null, text),
      opts.action ? h('button', { class: 's-btn text', onClick: () => { opts.action.run(); el.remove(); } }, opts.action.label) : null,
      h('button', { class: 'nt-close', 'aria-label': t('Dismiss'), onClick: () => el.remove() }, TR.icon('close', 14)));
    host().appendChild(el);
    if (TR.personas) TR.personas.react(null, tone === 'success' ? 'celebrate' : tone === 'info' ? 'nod' : 'shrug');
    setTimeout(() => { el.classList.add('is-leaving'); setTimeout(() => el.remove(), 200); }, opts.ms || 3200);
    refreshBadge();
  }
  function refreshBadge() { const b = document.querySelector && document.querySelector('.nt-bell .nt-count'); if (b) { b.textContent = String(N.unread); b.hidden = !N.unread; } }
  function panel() {
    if (!N.open) TR.pages.closeHeaderMenus?.('notifications');
    N.open = !N.open; N.unread = 0;
    TR.app.refresh();
  }
  function panelView() {
    return h('div', { class: 'ap-menu nt-panel', role: 'dialog', tabindex: '-1', 'aria-label': t('Notifications'), onKeydown: (e) => { if (e.key === 'Escape') { e.preventDefault(); N.open = false; TR.app.refresh(); document.querySelector('.nt-bell')?.focus(); } }, onClick: (e) => e.stopPropagation() },
      h('div', { class: 'nt-panel-head' }, h('strong', null, t('Notifications')), h('button', { type: 'button', class: 'ap-icon-btn', 'aria-label': t('Close notifications'), onClick: () => { N.open = false; TR.app.refresh(); document.querySelector('.nt-bell')?.focus(); } }, TR.icon('close', 16)), N.items.length ? h('button', { class: 's-btn text', onClick: () => { N.items = []; TR.app.refresh(); } }, t('Dismiss all')) : null),
      N.items.length ? h('ul', { class: 'nt-list' }, N.items.map((n) => h('li', { class: 'tone-' + n.tone }, TR.icon(ICON[n.tone] || 'info', 15), h('span', null, n.text), h('time', { datetime: n.at.toISOString() }, TR.pages.ui.when(n.at)))))
        : h('p', { class: 'muted' }, t('No notifications yet.')));
  }
  TR.pages.addHeaderItem(() => h('div', { class: 'ap-culture-wrap' },
    h('button', { class: 'ap-icon-btn nt-bell', 'aria-haspopup': 'dialog', 'aria-expanded': String(N.open), 'aria-label': t('Notifications'), 'data-tip': t('Notifications') + '|' + t('Messages from this session'), onClick: (e) => { e.stopPropagation(); panel(); } },
      TR.icon('bell', 18), h('span', { class: 'nt-count', hidden: !N.unread }, String(N.unread))),
    N.open ? panelView() : null));
  if (typeof document.addEventListener === 'function') {
    document.addEventListener('click', () => { if (N.open) { N.open = false; TR.app.refresh(); } });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && N.open) { e.preventDefault(); N.open = false; TR.app.refresh(); document.querySelector('.nt-bell')?.focus(); } });
  }

  // Events worth a toast.
  const wrap = (obj, name, after) => { const fn = obj && obj[name]; if (typeof fn !== 'function') return; obj[name] = async function (...args) { const r = await fn.apply(this, args); try { after.call(this, r, args); } catch (e) { /* never break the action */ } return r; }; };
  wrap(TR.request, 'runRequest', () => { const v = TR.testRequest.validation; if (v && v.results) { const ready = v.results.filter((r) => TR.testRequest.resultStatus(r) === 'ready').length; toast(t('Check finished: {ready} of {total} ready', { ready, total: v.results.length }), ready === v.results.length ? 'success' : 'warning'); } });
  wrap(TR.Pane.prototype, 'loadFromSource', function () { if (this.product && this.product.loaded()) toast(t('Loaded {vehicle}', { vehicle: this.product.chassisString() }), 'success'); });
  TR.prefs.onChange((key, value) => {
    if (key === 'motion') toast(value === 'off' ? t('Motion off: everything stands still') : t('Motion on'), 'info');
    if (key === 'culture' || key === 'cultureMode') { const c = TR.culture.active(); setTimeout(() => toast(t('Culture: {country} · {zone}', { country: TR.culture.countryName(c.country), zone: TR.culture.zoneName(c) }), 'info'), 0); }
    if (key === 'uiLanguage') toast(t('Language changed'), 'success');
  });

  // ------------------------------------------------------------------ status bar
  if (typeof window !== 'undefined' && typeof window.fetch === 'function') {
    const original = window.fetch.bind(window);
    window.fetch = (...args) => { N.busy++; updateStatus(); return original(...args).finally(() => { N.busy = Math.max(0, N.busy - 1); updateStatus(); }); };
  }
  function statusBar() {
    const L = TR.app.shell.left, c = TR.culture.active(), session = (TR.backend && TR.backend.session) || {};
    const vehicle = L && L.product.loaded() ? L.product.chassisString() : null, dirty = vehicle && L.product.dirty();
    return h('footer', { class: 'ap-status', role: 'contentinfo' },
      h('span', { class: 'ap-status-busy', 'aria-live': 'polite' }, h('i', { class: N.busy ? 'is-busy' : 'is-ready' }), N.busy ? t('Working…') : t('Ready')),
      vehicle ? h('span', { 'data-tip': dirty ? t('Unsaved changes|Save a draft or validate to keep them') : t('Vehicle in use') }, TR.icon('truck', 13), vehicle, dirty ? h('b', { class: 'ap-dirty', 'aria-label': t('Unsaved changes') }, '●') : null) : h('span', { class: 'muted' }, t('No vehicle')),
      h('span', { class: 'ap-status-sp' }),
      session.role ? h('span', null, TR.icon('people', 13), t(session.role)) : null,
      // One clock per chosen zone (Settings → Time zones shown together), each opening the world clock.
      h('span', { class: 'ap-clocks' }, (TR.timezones ? TR.timezones.shown() : [{ tz: c.timeZone, abbr: TR.culture.zoneName(c), you: true }]).map((z) =>
        h('button', { class: ['ap-clock', z.you ? 'is-you' : ''], 'data-tz': z.tz, 'aria-label': TR.i18n.t('World clock') + ': ' + z.abbr, title: '' },
          h('span', { class: 'ap-clock-time', 'data-tz': z.tz }, TR.timezones ? TR.timezones.timeIn(new Date(), z) : TR.culture.format.time(new Date())), ' ', z.abbr))));
  }
  function updateStatus() { const b = document.querySelector && document.querySelector('.ap-status-busy'); if (b) { b.lastChild.textContent = N.busy ? t('Working…') : t('Ready'); b.firstChild.className = N.busy ? 'is-busy' : 'is-ready'; } }
  const baseFrame = TR.testRequest.frame;
  TR.testRequest.frame = (content) => { const frame = baseFrame(content); if (frame && typeof frame.appendChild === 'function') frame.appendChild(statusBar()); return frame; };
  // The clock ticks once a minute.
  if (typeof setInterval === 'function' && typeof document.querySelector === 'function') setInterval(() => { document.querySelectorAll('.ap-clock-time[data-tz]').forEach((el) => { el.textContent = TR.timezones ? TR.timezones.timeIn(new Date(), { tz: el.dataset.tz }) : TR.culture.format.time(new Date()); }); }, 30000);

  // ------------------------------------------------------------------ two-line tooltips (DocGen Explorer style)
  let tip = null, timer = null, lastHide = 0;
  function showTip(el) {
    const [label, detail] = String(el.getAttribute('data-tip')).split('|');
    hideTip();
    tip = h('div', { class: 'ap-tip', role: 'tooltip' }, h('strong', null, label), detail ? h('span', null, detail) : null);
    document.body.appendChild(tip);
    const r = el.getBoundingClientRect(), w = tip.offsetWidth, hh = tip.offsetHeight;
    const top = r.bottom + 8 + hh > window.innerHeight ? r.top - hh - 8 : r.bottom + 8;
    tip.style.left = Math.min(Math.max(8, r.left + r.width / 2 - w / 2), window.innerWidth - w - 8) + 'px';
    tip.style.top = top + 'px';
  }
  function hideTip() { clearTimeout(timer); if (tip) { tip.remove(); tip = null; lastHide = Date.now(); } }
  function arm(e) {
    const el = e.target && e.target.closest && e.target.closest('[data-tip]');
    if (!el) return;
    clearTimeout(timer);
    timer = setTimeout(() => showTip(el), Date.now() - lastHide < 800 ? 60 : 350); // warm: neighbouring buttons answer fast
  }
  if (typeof document.addEventListener === 'function') {
    document.addEventListener('mouseover', arm); document.addEventListener('focusin', arm);
    document.addEventListener('mouseout', (e) => { if (e.target && e.target.closest && e.target.closest('[data-tip]')) hideTip(); });
    document.addEventListener('focusout', hideTip); document.addEventListener('scroll', hideTip, true);
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') hideTip(); });
  }

  TR.notify = { toast, panel, N, statusBar };
})();
