/* Help Center content. Plain data, so articles are easy to add and edit; help.js renders and searches them.
 *
 * Article: { id, topic, title, summary, keywords, tip, sections: [Section], related?: [id] }
 * Section: { h?: heading, p?: text, steps?: [text], list?: [text], note?: text, table?: name of a live table in help.js,
 *            actions?: [{ label, icon?, primary?, run: name of an action in help.js, args?: [] }] }
 * Text may use `code`, **bold** and *emphasis*. tip is what the guide character says on that article. */
(function () {
  'use strict';
  const TOPICS = [
    { id: 'start', title: 'Get started', icon: 'help', summary: 'What the studio does, loading a vehicle and the three stages.' },
    { id: 'plan', title: 'Plan and validate', icon: 'flask', summary: 'Change software, choose a scenario and read the results.' },
    { id: 'deliver', title: 'Deliver results', icon: 'box', summary: 'Kits, VDA updates and exports from a validated result.' },
    { id: 't3', title: 'T3 services', icon: 'chip', summary: 'Product Update Service and Available Product Updates.' },
    { id: 'vehicle', title: 'Your vehicle', icon: 'map', summary: 'The vehicle graph, its roadmap and its history.' },
    { id: 'settings', title: 'Settings', icon: 'settings', summary: 'Language and region, theme, motion and more.' },
    { id: 'expert', title: 'Expert tools and sample data', icon: 'database', summary: 'Scenarios to try, sample files and URL parameters.' },
  ];

  const ARTICLES = [
    // ------------------------------------------------------------------ get started
    { id: 'overview', topic: 'start', title: 'What Test Request Tool does', keywords: 'introduction about simulation overview',
      summary: 'Plan a vehicle software change, see what it would do, then deliver it as a kit, a VDA update or an export.',
      tip: 'Nothing here changes a real vehicle. You can try anything!',
      sections: [
        { p: 'Test Request Tool is a simulation workspace for vehicle software changes. It simulates the SW Configurator **Test Request** tool, the legacy **VCADS Test Request** and **Compare Breakdown**.' },
        { h: 'The workflow', steps: ['**Load a vehicle** from VDA, by VIN, from an EDB specification or from an XML file.', '**Plan a change**: software versions, parameters, variants, S-Notes and more.', '**Validate** the proposal. Each vehicle is Ready, Limited validation or Blocked.', '**Review and deliver** the result as a conversion kit, a VDA update or an export.'] },
        { note: 'Simulations never install software and never change VDA unless you commit a validated result. The coloured **Next** button in the top bar always shows what to do next.' },
        { actions: [{ label: 'Add a vehicle', icon: 'plus', primary: true, run: 'addVehicle' }, { label: 'Open the illustrated UI guide', icon: 'book', run: 'uiGuide', args: ['start'] }] },
      ], related: ['load-vehicle', 'stages'] },
    { id: 'tour', topic: 'start', title: 'Take the introduction tour', keywords: 'tour wizard introduction walkthrough voice speech narration onboarding',
      summary: 'Asha highlights each part of the screen and explains it, out loud if you like.',
      tip: 'I can talk! Turn the voice on in the tour and I will read each step.',
      sections: [
        { steps: ['Choose **Take the introduction tour** on this page, or press `g` then `i` anywhere.', 'Asha highlights one part of the screen at a time and explains it.', 'Move on with `→` or **Next**, go back with `←`, and end with `Esc`.', 'Turn the voice on or off with `V`. The tour picks the most natural voice your browser has for your language.'] },
        { note: 'The voice uses your browser’s built-in speech. Nothing is sent to a service. Some browsers have more natural voices than others; Microsoft Edge and Chrome offer online neural voices.' },
        { actions: [{ label: 'Start the tour', icon: 'play', primary: true, run: 'tour' }] },
      ], related: ['overview', 'shortcuts'] },
    { id: 'load-vehicle', topic: 'start', title: 'Load a vehicle', keywords: 'add vehicle vda vin edb xml chassis intake open',
      summary: 'Add a vehicle by chassis, VIN, EDB specification or XML file.',
      tip: 'FH 333333 is my favourite: a T3 truck with two HPC computers.',
      sections: [
        { steps: ['Choose **Add a vehicle** on Home, in the sidebar or with the Next button.', 'Pick the source: VDA, VIN, EDB or File.', 'For VDA, enter the chassis series and number, for example `FH 123456`.', 'Choose **Load vehicle**.'] },
        { note: 'You can load only vehicles in contexts your account may read. The original is kept unchanged, so you can always compare your proposal with it.' },
      ], related: ['stages'] },
    { id: 'stages', topic: 'start', title: 'Configure, validate and review', keywords: 'stages steps workflow stale results',
      summary: 'The test request moves through three stages.',
      tip: 'If you change something after validating, just validate again.',
      sections: [
        { steps: ['**Configure**: edit the proposal on the Software, Parameters, Variants, S-Notes, Structure, Parameter templates and Product info tabs. *Proposed changes* counts what you changed.', '**Validate**: runs the request on the server and shows a result per vehicle.', '**Review**: compares the original and the proposal and offers the delivery options.'] },
        { note: 'A result goes stale as soon as you change the proposal or the request settings. Delivery uses only current, validated results.' },
        { p: 'Prefer the original expert layout? Use the **Focused / Two-pane** switch at the top of the test request.' },
      ], related: ['validate', 'two-pane'] },

    { id: 'shortcuts', topic: 'start', title: 'Keyboard shortcuts', keywords: 'keyboard shortcuts hotkeys keys fast',
      summary: 'Move around and act without the mouse.',
      tip: 'Press ? on any screen and I will show you every shortcut.',
      sections: [
        { p: 'Press `?` anywhere for this list. Type `g` and then a letter to go to a page, for example `g` `v` for Vehicle. Shortcuts are off while you type in a field.' },
        { table: 'shortcuts' },
        { actions: [{ label: 'Show the shortcuts', icon: 'grid', primary: true, run: 'shortcuts' }] },
      ], related: ['overview'] },

    // ------------------------------------------------------------------ plan and validate
    { id: 'change-software', topic: 'plan', title: 'Change a software version', keywords: 'package version software product node template edit',
      summary: 'Pick the proposed version of a computer or software package.',
      tip: 'The version list shows the release status of each version.',
      sections: [
        { steps: ['Load a vehicle and open **Test request**.', 'On the **Software** tab, find the computer.', 'Choose the proposed version. Each version shows its release status.', '*Proposed changes* on the right counts the change.'] },
        { note: 'For T3 vehicles, software products are grouped per HPC computer and execution environment, for example VCM on VCM-Linux.' },
      ], related: ['validate', 'scenarios'] },
    { id: 'validate', topic: 'plan', title: 'Validate a proposal', keywords: 'run request simulate validate check impact',
      summary: 'Check what the change would do on every loaded vehicle.',
      tip: 'The Next button turns green when a result is ready to deliver.',
      sections: [
        { steps: ['Choose **Validate N vehicles** at the bottom, or the Next button.', 'Read the summary: tested, ready and needing attention.', 'Choose **Inspect result** for messages, release notes and the full change list.', 'Use **Request settings** to change the scenario or operation and run again.'] },
      ], related: ['results', 'scenarios'] },
    { id: 'results', topic: 'plan', title: 'Ready, Limited validation and Blocked', keywords: 'result status error blocked limited ready',
      summary: 'What each validation result means.',
      tip: 'Blocked is not bad news: it tells you exactly what to fix.',
      sections: [
        { list: ['**Ready**: the vehicle may continue to delivery.', '**Limited validation**: checks that could not run, because live KAX, Dependix and Digital Twin are not connected.', '**Blocked**: an error, such as missing hardware or a dependency on another computer. Fix it and validate again.'] },
      ], related: ['validate'] },
    { id: 'scenarios', topic: 'plan', title: 'Scenarios and operations', keywords: 'scenario introduced released in progress operation refresh repair update resolve service pack',
      summary: 'Which release states a request may use, and what it does.',
      tip: 'Set your usual scenario once in Settings → Requests.',
      sections: [
        { h: 'Scenarios', table: 'scenarios' },
        { h: 'Software operations', list: ['**Refresh**: reinstall the current software.', '**Repair**: replace broken software, optionally with new ECU hardware.', '**Update**: move to newer versions allowed by the scenario.', '**Resolve**: recover a missing node template.', '**Update to service pack**: move T3 computers to a service pack.'] },
        { actions: [{ label: 'Set the default scenario', icon: 'settings', run: 'settings', args: ['requests'] }] },
      ], related: ['validate', 'pus'] },

    // ------------------------------------------------------------------ deliver
    { id: 'kit', topic: 'deliver', title: 'Create a conversion kit', keywords: 'kit conversion deliver immutable',
      summary: 'Turn a validated result into a kit.',
      tip: 'Kits are immutable: what you validated is what you get.',
      sections: [
        { steps: ['Validate the proposal and go to **Review**.', 'Under **Conversion kits**, choose the vehicles and a name.', 'Choose **Create kit**.'] },
        { note: 'Kits include your manual changes and need writer permission. They appear in the vehicle history.' },
      ], related: ['vda', 'history'] },
    { id: 'vda', topic: 'deliver', title: 'Commit a result to VDA', keywords: 'vda commit update revision write snapshot',
      summary: 'Write the validated configuration to VDA.',
      tip: 'Every commit records who made it and why.',
      sections: [
        { steps: ['Validate the proposal and go to **Review**.', 'Under **VDA update**, preview the snapshot.', 'Commit it.'] },
        { note: 'Committing needs writer permission and a ready, current result. If VDA changed since you loaded the vehicle, the commit is refused so nothing is overwritten.' },
      ], related: ['history', 'kit'] },
    { id: 'campaigns', topic: 'deliver', title: 'Run a campaign across many vehicles', keywords: 'campaign fleet many vehicles batch approve approval submit revision archive',
      summary: 'Apply one software change to many vehicles: validate them together, get the exact revision approved, then submit it.',
      tip: 'Editing a campaign makes a new revision and clears the approval, so what was approved is always what is submitted.',
      sections: [
        { h: 'Create and validate', steps: ['Open **Tools → Campaigns** and choose **Create campaign**.', 'Name it, choose the software operation and tick the vehicles.', 'Choose **Validate all** (or select vehicles and **Validate selected**). Each vehicle becomes Ready, Blocked, Stale or Unknown.'] },
        { h: 'Approve and submit', steps: ['Someone else with the Reviewer or Admin role approves the revision. Approval covers the vehicles that were ready.', 'An authorised operator confirms the revision and chooses **Submit campaign**.', 'Each approved vehicle still on its validated revision is committed to the vehicle repository; the others are skipped with a reason.'] },
        { h: 'Read the page', list: ['**Readiness** shows how many vehicles are ready, blocked, stale or not validated yet.', 'The **tiles** at the top filter the list: active campaigns, ready vehicles, vehicles that need attention, awaiting approval.', '**Next action** on each vehicle says what to do: validate, track, resolve, review or open the receipt.', '**Evidence** lists the validations, the approval and the submission; **Activity** is the full history.'] },
        { note: 'The owner of a campaign cannot approve it (separation of duties): another reviewer approves it. Submitting never installs software on a vehicle.' },
      ], related: ['validate', 'vda'] },
    { id: 'export', topic: 'deliver', title: 'Export or inspect a result', keywords: 'xml export download inspect two-pane',
      summary: 'Download the product XML or open the result side by side.',
      sections: [{ list: ['**Download XML** saves the proposed product.', '**Open in the two-pane workbench** shows the original and the response side by side.'] }],
      related: ['two-pane'] },

    // ------------------------------------------------------------------ T3
    { id: 'pus', topic: 't3', title: 'Update to a service pack (Product Update Service)', keywords: 'pus product update service service pack t3 hpc repair schema',
      summary: 'Ask the T3 service which service pack a vehicle can move to.',
      tip: 'No service pack fits? The result tells you why, per computer.',
      sections: [
        { steps: ['Load a T3 vehicle, for example FH 333333.', 'Choose **Update to service pack** in the Configure stage or on the Vehicle roadmap.', 'Pick schema 2.0 (update or repair) or 1.0, the scenario and the operation.', 'Run it. The result shows the service pack, the computers and the packages.', 'Choose **Contract response** to see the JSON.'] },
        { actions: [{ label: 'Load FH 333333', icon: 'truck', primary: true, run: 'loadVehicle', args: ['FH', '333333'] }, { label: 'See it in the UI guide', icon: 'book', run: 'uiGuide', args: ['pus-request'] }] },
      ], related: ['apu', 'roadmap'] },
    { id: 'apu', topic: 't3', title: 'List available product updates', keywords: 'apu available product updates hardware replacement kits action criteria',
      summary: 'Software replacements, hardware replacements and kits for a T3 vehicle.',
      sections: [
        { steps: ['Load a T3 vehicle.', 'Choose **Available product updates**.', 'Pick contract 1.1 or 1.0 and the action criteria.', 'Run it and read the software replacements, hardware replacements and kits.'] },
        { actions: [{ label: 'See it in the UI guide', icon: 'book', run: 'uiGuide', args: ['apu-request'] }] },
      ], related: ['pus'] },

    // ------------------------------------------------------------------ vehicle
    { id: 'graph', topic: 'vehicle', title: 'See the vehicle as a graph', keywords: 'graph compare diff computers software tree',
      summary: 'Computers, execution environments and software, compared with any earlier state.',
      tip: 'Red with a minus is before, green with a plus is now, just like a code diff.',
      sections: [
        { steps: ['Open **Vehicle** in the sidebar.', 'On the **Graph** tab, use **Compare with** to pick an earlier entry, such as the factory build.', 'Click a computer for its hardware, next versions and history.'] },
        { actions: [{ label: 'Open the Vehicle page', icon: 'map', primary: true, run: 'page', args: ['vehicle'] }] },
      ], related: ['roadmap', 'history'] },
    { id: 'insights', topic: 'vehicle', title: 'Insights for one vehicle', keywords: 'insights timeline chart calendar up to date most changed waiting',
      summary: 'A software timeline, an activity calendar and what needs attention, for the loaded vehicle.',
      tip: 'Amber diamonds on the timeline are updates you could already have installed.',
      sections: [
        { list: ['**Insight cards** sum up what matters: how many computers are up to date, updates waiting, the next unblocked update and the last change.', '**Software timeline**: one lane per computer showing each version it ran since the factory build. Diamonds are upcoming versions at their release week. Click a bar to see the vehicle at that change.', '**Up to date** and **Most changed** show the state of every computer and which change most often.', '**Activity** is a GitHub-style calendar, one square per day.'] },
        { note: 'Press `4` on the Vehicle page to jump to Insights, or `[` and `]` to move between tabs.' },
        { actions: [{ label: 'Open the Vehicle page', icon: 'chart', primary: true, run: 'page', args: ['vehicle'] }] },
      ], related: ['dashboard', 'history'] },
    { id: 'dashboard', topic: 'vehicle', title: 'The fleet dashboard', keywords: 'dashboard fleet overview kpi attention pipeline service pack outcomes',
      summary: 'Every vehicle you can read: what is current, what is waiting and what happened.',
      tip: 'Start with Needs attention: it lists the most urgent vehicle first.',
      sections: [
        { list: ['**Headline numbers**: vehicles, computers, the share up to date, updates waiting, requests and VDA changes.', '**Needs attention** ranks vehicles by updates that are available but not installed, then by blocked ones. Open a vehicle with one click.', '**Release pipeline** counts every upcoming version by release state; the hatched part is blocked.', '**Service packs**, **Request outcomes**, **Fleet activity** and **People** complete the picture.'] },
        { actions: [{ label: 'Open the Dashboard', icon: 'chart', primary: true, run: 'page', args: ['dashboard'] }] },
      ], related: ['insights'] },
    { id: 'roadmap', topic: 'vehicle', title: 'Where the vehicle can go next', keywords: 'roadmap upcoming versions blocked service pack',
      summary: 'Service packs and, per computer, the path from build to future versions.',
      sections: [{ p: 'The **Roadmap** tab shows the service packs that apply and every computer from its as-built version through now to each upcoming version. A lock explains what blocks a version, such as ECU hardware or another computer’s version.' }],
      related: ['graph', 'pus'] },
    { id: 'history', topic: 'vehicle', title: 'Who changed what, and when', keywords: 'history git graph branch commit who changes diff',
      summary: 'The vehicle history drawn like a git history.',
      tip: 'Scroll down and older history loads by itself.',
      sections: [
        { list: ['Changes to the vehicle are on the **main line**.', 'Simulations and kits **branch** from the revision they started from; a committed simulation joins the main line again.', 'Each entry shows who, when and a GitHub-style **+3 −3** count. Click it for the red and green diff.', 'Older entries load as you scroll. Search and filters look at the whole history.'] },
        { actions: [{ label: 'Open the Vehicle page', icon: 'history', primary: true, run: 'page', args: ['vehicle'] }] },
      ], related: ['graph', 'vda'] },

    // ------------------------------------------------------------------ settings
    { id: 'region', topic: 'settings', title: 'Language, time zone and currency', keywords: 'culture language region time zone ist utc currency rupee flag country locale',
      summary: 'How dates, times and money are shown, and switching culture live.',
      tip: 'Press Alt+Shift+C to hop between your cultures.',
      sections: [
        { p: 'Your culture starts from the country on your account. India, for example, gives IST and rupees. Without a country it is UTC.' },
        { steps: ['Open **Settings → Language and region**.', 'Pick a country flag, then adjust the language, time zone, currency, date format and clock.', 'Or turn on **Use system settings** to follow this computer.', 'Keep several cultures for the **quick switch**, then use the flag button in the top bar.'] },
        { actions: [{ label: 'Open Language and region', icon: 'globe', primary: true, run: 'settings', args: ['region'] }] },
      ], related: ['appearance'] },
    { id: 'appearance', topic: 'settings', title: 'Theme, text size and motion', keywords: 'theme dark light auto motion animation text size accessibility',
      summary: 'Auto, Light Charcoal or Dark Charcoal; larger text; animations on or off.',
      sections: [
        { list: ['The round **sun / moon** button cycles Auto, Light Charcoal and Dark Charcoal.', 'The **motion** button turns animations on or off. Your system’s reduce-motion setting is always honoured.', '**Settings → Appearance** also has text size.'] },
        { actions: [{ label: 'Open Appearance', icon: 'sun', run: 'settings', args: ['appearance'] }] },
      ], related: ['region'] },

    // ------------------------------------------------------------------ expert tools and sample data
    { id: 'two-pane', topic: 'expert', title: 'The two-pane workbench', keywords: 'two pane expert workbench focused switch legacy',
      summary: 'The original vehicle on the left, the request response on the right.',
      sections: [
        { p: 'Use the **Focused / Two-pane** switch at the top of the test request to change view at any time. Your loaded vehicles stay loaded.' },
        { actions: [{ label: 'Open the two-pane workbench', icon: 'compare', primary: true, run: 'twoPane' }] },
      ], related: ['scenarios-to-try'] },
    { id: 'scenarios-to-try', topic: 'expert', title: 'Scenarios to try', keywords: 'try scenarios examples tecu ems pbl repair kit resolve edb campaigns vespa spare cab',
      summary: 'Ten short exercises in the two-pane workbench.',
      tip: 'Start with the first one: it shows a hardware-replacement warning.',
      sections: [
        { steps: [
          'Left pane: VDA `FH 123456` → Load. Choose *Request*, type Software / Update / Introduced → *Request*. The right pane shows the response and the updated product. EMS shows a hardware-replacement warning.',
          'Tick only the `16.3.1 TECU` node, run Update with scenario *InProgress* and multi-node behaviour off: TECU needs a newer EMS. Turn it on to get EMS as a dependent node.',
          'Uncheck *PBL update capable* to block versions that need a new primary bootloader.',
          'Select a node, tick *Replace hardware*, change the ECU hardware number and run Repair: the previous ECU hardware is sent.',
          'Conversion Kit request with kit `23187002` (ADR) or `23187001` (telematics); with scenario Released, kit `23187003` (state Introduced) gives an error.',
          'Load `FH 000042` (EMS without NTP) and run Software / Resolve.',
          'EDB source `VSS-12-345` gives a specification without nodes, so the request type becomes Production Breakdown. Use *Show source* and *Filter* (for example variant `TELM-DYN`).',
          'Edit the product, then *Compare VDA*, *Update VDA* → *Send to VDA*, or *To Kit* → Create Kit / Add To Kit (try kit `23187004`).',
          '*History* lists seeded NAMS, GeSP and PROTOM requests and your own; Load puts the request left and the response right.',
          '*Campaigns* (left pane, FH 123456) runs a campaign software or kit request. *VESPA2* opens a simulated round trip. Request type *Spare Cab* uses CBR order `99850557`.',
        ] },
        { actions: [{ label: 'Open the two-pane workbench', icon: 'compare', primary: true, run: 'twoPane' }] },
      ], related: ['sample-files'] },
    { id: 'sample-files', topic: 'expert', title: 'Sample files', keywords: 'download sample xml product request parameters file drag drop import',
      summary: 'Files for the File source, drag and drop and Import Parameters.',
      sections: [{ actions: [{ label: 'Product XML (FH 123456)', icon: 'file', run: 'download', args: ['product'] }, { label: 'Software request XML', icon: 'file', run: 'download', args: ['request'] }, { label: 'Parameters XML', icon: 'file', run: 'download', args: ['params'] }] }],
      related: ['load-vehicle'] },
    { id: 'url-parameters', topic: 'expert', title: 'Link straight to a vehicle or page', keywords: 'url parameters query string link deep chassisSeries view devmode',
      summary: 'Query string parameters for links and bookmarks.',
      sections: [
        { list: ['`?chassisSeries=FH&chassisNumber=123456` loads that vehicle.', '`&view=vehicle`, `&view=settings`, `&view=help` or `&view=activity` opens that page.', '`?view=help&article=region` opens a Help article; `?view=help&q=kit` searches.', '`&open=twopane` opens the two-pane workbench.', 'In the workbench: `&source=SWC` loads the saved SWC product; `?transactionId=…`, `incomingMessageId` or `outgoingMessageId` load from the request log; `?devMode` enables the local storage buttons.'] },
        { actions: [{ label: 'Run the chassis parser self test', icon: 'check', run: 'chassisTest' }] },
      ], related: ['two-pane'] },
  ];

  TR.helpContent = { TOPICS, ARTICLES };
})();
