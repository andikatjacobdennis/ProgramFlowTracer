/* History: a page like the others (it used to be a side panel). Two tabs:
 *   Server requests  – the requests recorded by the server (GET /api/v1/requests). Each row opens its Request execution page,
 *                      and "Details" shows the stored record in place.
 *   Local / NAMS log – the original request-log search (filters, paging, details, Load request / response / both).
 * Every way in (Tools → History, the two-pane History button, ?open=history) opens this page. */
(function () {
  'use strict';
  const { h } = TR.util;
  const J = TR.journey, t = J.t;
  const H = { tab: 'server', rows: null, error: null, loading: false, open: null, logStarted: false };

  async function loadServer() {
    H.loading = true; H.error = null; TR.app.refresh();
    try { H.rows = await J.api('/requests?take=50'); } catch (e) { H.error = e.message; }
    H.loading = false; TR.app.refresh();
  }
  /** The request-log search hosted in the page: re-rendering is a page refresh; loading an entry opens the two-pane workbench. */
  const host = {
    closed: false,
    render: () => TR.app.refresh(),
    close: () => {
      if (TR.experience) TR.experience.page = null;
      // Leaving the page: the address no longer names it, so a reload stays on the workbench.
      try { const u = new URL(location.href); u.searchParams.delete('view'); history.replaceState(null, '', u); } catch (e) { /* no location */ }
      if (TR.testRequest && TR.testRequest.expert) TR.testRequest.expert(); else TR.app.refresh();
    },
  };
  let logView = null;

  function serverTab() {
    if (!H.rows) return H.error ? J.failed(H.error, loadServer) : J.loading(5);
    if (!H.rows.length) return J.empty('No server requests yet', 'Validate a proposal on the test request and it appears here.', TR.pages.ui.button(t('New request'), 'plus', () => TR.header ? TR.header.newRequest() : TR.testRequest.page(), 'secondary'));
    const row = (r) => {
      const open = H.open === r.id;
      return [
        h('tr', null,
          h('td', null, h('button', { class: 'jr-link', onClick: () => J.open('execution', { rid: r.id }) }, J.label(r.id))),
          h('td', null, new Date(r.createdAt).toLocaleString()),
          h('td', null, r.kind),
          h('td', null, String((r.outcomes || []).length)),
          h('td', { class: 'hs-actions' },
            TR.pages.ui.button(t('Open'), 'arrow', () => J.open('execution', { rid: r.id }), 'secondary'),
            h('button', { class: 'jr-link', 'aria-expanded': String(open), onClick: () => { H.open = open ? null : r.id; TR.app.refresh(); } }, t(open ? 'Hide details' : 'Details'), TR.icon(open ? 'up' : 'chevron', 13)))),
        open ? h('tr', { class: 'hs-detail' }, h('td', { colspan: 5 }, h('div', { class: 's-json' }, TR.ui.jsonViewer(r, { expandDepth: 1 })))) : null];
    };
    return h('div', { class: 'jr-table-wrap' }, h('table', { class: 'jr-table' },
      h('thead', null, h('tr', null, ['Request', 'Created', 'Type', 'Vehicles'].map((c) => h('th', null, t(c))), h('th', null, h('span', { class: 'nv-sr' }, t('Actions'))))),
      h('tbody', null, H.rows.map(row))));
  }
  function logTab() {
    const S = TR.shellActions;
    if (!S || !S.historyView) return J.empty('The request log is not available', '');
    logView = logView || S.historyView();
    if (!H.logStarted) { H.logStarted = true; S.searchHistory(host); }
    return h('div', { class: 'hs-log history' }, logView(host));
  }

  function render() {
    if (H.tab === 'server' && !H.rows && !H.loading && !H.error) loadServer();
    const head = J.pageHead('History', 'Requests recorded by the server, and the local / NAMS request log.', [
      TR.pages.ui.button(t('Refresh'), 'refresh', () => { if (H.tab === 'server') loadServer(); else TR.shellActions.searchHistory(host); }, 'secondary')]);
    return h('div', { class: 'jr-page hs-page' }, head,
      h('div', { class: 'jr-tabs', role: 'tablist', 'aria-label': t('History') }, [['server', 'Server requests'], ['log', 'Local / NAMS log']].map(([k, l]) =>
        h('button', { role: 'tab', 'aria-selected': String(H.tab === k), class: H.tab === k ? 'is-on' : '', onClick: () => { H.tab = k; TR.app.refresh(); } }, t(l)))),
      h('section', { class: 'jr-card', role: 'tabpanel' }, H.tab === 'server' ? serverTab() : logTab()));
  }

  TR.pages.register({ id: 'history', title: 'History', crumbs: () => [{ label: t('Expert tools') }, { label: t('History') }], render });
  // Every entry point opens the page; the panel is no longer used.
  if (TR.shellActions) TR.shellActions.historyPopup = () => { H.rows = null; H.logStarted = false; J.open('history'); };
  TR.history = { H, loadServer };
})();
