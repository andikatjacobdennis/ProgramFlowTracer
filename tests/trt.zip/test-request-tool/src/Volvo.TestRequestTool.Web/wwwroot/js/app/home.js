/* Home: one place to start and to pick up work (it replaces the separate Home cards, Dashboard and Activity entry points).
 *
 *   Needs you        requests waiting on you, from /api/v1/requests/overview: a decision to make, an approved change to
 *                    send, a draft to continue, a blocked or out-of-date result to resolve, a check to ask approval for
 *   Recent requests  your latest requests, with All requests and the Activity log one click away
 *   Start            choose a vehicle, the vehicle you have open, saved vehicles, getting started
 *   The fleet        the fleet dashboard (Vehicles → Dashboard) and the service status
 * Cards other modules add to Home (the first steps) appear under the heading (core.js). */
(function () {
  'use strict';
  const { h } = TR.util;
  const J = TR.journey, t = J.t, ui = () => TR.pages.ui;
  const Hm = { data: null, error: null, loading: false, at: 0 };

  async function load() {
    if (Hm.loading || (Hm.data && Date.now() - Hm.at < 15000)) return;
    Hm.loading = true;
    try { Hm.data = await J.api('/requests/overview'); Hm.error = null; } catch (e) { Hm.error = e.message; }
    Hm.loading = false; Hm.at = Date.now();
    TR.app.refresh();
  }

  // ------------------------------------------------------------------ what needs you (pure, tested)
  /** The next steps that are yours: a decision, a send, a draft, something to resolve or to ask approval for. */
  const NEEDS = ['Review', 'Submit', 'Continue', 'Resolve', 'Request review'];
  const WHY = { Review: 'Decide', Submit: 'Send', Continue: 'Continue', Resolve: 'Fix', 'Request review': 'Get approval' };
  const newest = (a, b) => (a.updatedAt < b.updatedAt ? 1 : a.updatedAt > b.updatedAt ? -1 : 0);
  // A decision needs you when it is assigned to you or to nobody yet; one assigned to someone else does not.
  function needsYou(items, max = 5, me = ((TR.backend && TR.backend.session) || {}).userId) { return items.filter((i) => NEEDS.includes(i.action) && !(i.action === 'Review' && i.assignee && i.assignee.id !== me)).sort(newest).slice(0, max); }
  /** Your latest requests, leaving out the ones already under Needs you (pass them as skip). */
  function recent(items, max = 5, skip = []) { return items.filter((i) => i.mine && !skip.includes(i)).sort(newest).slice(0, max); }

  // ------------------------------------------------------------------ the page
  /** "ProductUpdateService" → "Product update service". */
  const words = (k) => { const w = String(k || '').replace(/([a-z])([A-Z])/g, '$1 $2'); return w.charAt(0) + w.slice(1).toLowerCase(); };
  const act = (i) => (TR.requestsHub && TR.requestsHub.act ? TR.requestsHub.act(i) : J.open('requests'));
  function row(i, button) {
    const v = i.vehicles[0];
    return h('li', { class: 'hm-row' },
      J.chip(i.status),
      h('span', { class: 'hm-row-text' }, h('strong', null, i.label), h('small', { class: 'muted' }, [v ? v.title : null, words(i.kind), i.mine ? null : i.owner && i.owner.name, J.ago(i.updatedAt)].filter(Boolean).join(' · '))),
      button ? ui().button(t(button), 'arrow', () => act(i), 'secondary') : ui().button(t('Open'), null, () => act(i), 'text'));
  }
  function list(items, button, emptyText) {
    if (Hm.error) return J.failed(Hm.error, () => { Hm.at = 0; load(); });
    if (!Hm.data) return J.loading(3);
    return items.length ? h('ul', { class: 'hm-list' }, items.map((i) => row(i, button ? WHY[i.action] || i.action : null))) : h('p', { class: 'muted hm-none' }, t(emptyText));
  }
  const link = (label, icon, run) => h('button', { type: 'button', class: 'hm-link', onClick: run }, TR.icon(icon, 18), h('span', null, t(label)), TR.icon('chevron', 14));

  function render() {
    load();
    const s = J.me(), first = String(s.displayName || '').split(' ')[0];
    const items = Hm.data ? Hm.data.items : [];
    const need = needsYou(items), mine = recent(items, 5, need);
    const left = TR.app.shell && TR.app.shell.left, loaded = left && left.product.loaded();
    return h('div', { class: 'gx-page hm-page' },
      J.pageHead('Home', first ? t('Hello {n}. What needs you, and where to start.', { n: first }) : t('What needs you, and where to start.'),
        [ui().button(t('New request'), 'plus', () => TR.header.newRequest(), 'primary')]),
      h('div', { class: 'hm-grid' },
        h('div', { class: 'hm-main' },
          J.card(h('h2', null, t('Needs you')), need.length ? h('span', { class: 'jr-pill tone-warning' }, String(need.length)) : null,
            list(need, true, 'Nothing needs you right now.')),
          J.card(h('h2', null, t('Your recent requests')), h('button', { type: 'button', class: 'jr-link', onClick: () => J.open('requests') }, t('All requests')),
            list(mine, false, need.length ? 'Nothing else recent: the rest is under Needs you.' : 'No requests yet. Start one with New request.'),
            h('p', { class: 'hm-more' }, h('button', { type: 'button', class: 'jr-link', onClick: () => J.open('requests') }, t('All requests')), ' · ',
              h('button', { type: 'button', class: 'jr-link', onClick: () => TR.pages.show('activity') }, t('Activity log'))))),
        h('aside', { class: 'hm-side' },
          J.card('Start', null, h('div', { class: 'hm-links' },
            link('Choose a vehicle', 'truck', () => TR.header.newRequest()),
            loaded ? link(t('Open {v}', { v: left.product.chassisString() }), 'map', () => TR.pages.show('vehicle')) : null,
            link('Saved vehicles', 'bookmark', () => TR.pages.show('library')),
            link('Getting started', 'help', () => TR.pages.show('learn')))),
          J.card('The fleet', null, h('p', { class: 'muted' }, t('Every vehicle you can read: how current the software is and what is waiting.')),
            h('div', { class: 'hm-links' }, link('Fleet dashboard', 'chart', () => TR.pages.show('dashboard')), TR.pages.get('health') ? link('Service status', 'pulse', () => TR.pages.show('health')) : null)))));
  }

  TR.home = { render, needsYou, recent, NEEDS, Hm, load, words };
})();
