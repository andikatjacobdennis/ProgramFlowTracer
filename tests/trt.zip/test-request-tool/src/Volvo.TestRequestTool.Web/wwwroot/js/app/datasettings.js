/* Administration › Data and services: where the repository keeps its data and how each external service is reached.
 *
 *   Repository   provider, folder, the format of each collection (JSON or XML) and how many records each holds;
 *                a change is saved to the settings file and applies when the app next starts
 *   Services     the folder the file transport reads, and per service (EDB, CBR, KAX, VESPA, Dependix, Digital Twin)
 *                Files, Http (with a base URL and timeout) or Off; a change applies to the next call; Check tries it now
 * Server: GET /api/v1/admin/data, PUT /admin/data/repository, PUT /admin/data/services, PUT /admin/data/services/{name},
 * POST /admin/data/services/{name}/check (DataSetup.cs). Everything is edited in place on the page. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));
  const D = { data: null, error: null, loading: false, edits: {}, repo: null, servicesPath: null, busy: {}, checks: {} };
  const COLLECTIONS = [['vehicles', 'Vehicles'], ['vehicle-originals', 'Vehicles as first imported'], ['vehicle-revisions', 'Vehicle revisions'], ['requests', 'Requests'], ['reviews', 'Reviews'], ['campaigns', 'Campaigns'], ['users', 'People']];

  async function call(path, method, body) {
    const r = await fetch('/api/v1/admin/data' + path, { method: method || 'GET', credentials: 'same-origin', headers: { Accept: 'application/json', 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.detail || data.title || r.statusText);
    return data;
  }
  async function load(force) {
    if ((D.data && !force) || D.loading) return;
    D.loading = true;
    try {
      D.data = await call('');
      D.error = null;
      D.repo = { path: D.data.repository.saved.path, formats: Object.assign({}, D.data.repository.formats) };
      D.servicesPath = D.data.services.path;
      D.edits = {};
      D.data.services.endpoints.forEach((e) => { D.edits[e.name] = { transport: e.transport, baseUrl: e.baseUrl || '', timeoutSeconds: e.timeoutSeconds }; });
    } catch (e) { D.error = e.message; }
    D.loading = false;
    TR.app.refresh();
  }
  async function run(key, work, done) {
    D.busy[key] = true; TR.app.refresh();
    try { await work(); TR.notify && TR.notify.toast(t(done), 'success'); await load(true); }
    catch (e) { TR.notify && TR.notify.toast(e.message, 'error'); }
    D.busy[key] = false; TR.app.refresh();
  }
  const saveRepository = () => run('repo', () => call('/repository', 'PUT', { provider: 'Files', path: D.repo.path.trim(), formats: D.repo.formats }), 'Saved. The repository changes when the app next starts.');
  const saveServicesPath = () => run('path', () => call('/services', 'PUT', { path: D.servicesPath.trim() }), 'Saved. The next call uses the new folder.');
  const saveService = (name) => run(name, () => { const e = D.edits[name]; return call('/services/' + encodeURIComponent(name), 'PUT', { transport: e.transport, baseUrl: e.baseUrl || null, timeoutSeconds: Number(e.timeoutSeconds) || 30 }); }, 'Saved. The next call uses it.');
  async function check(name) {
    D.checks[name] = { busy: true }; TR.app.refresh();
    try { D.checks[name] = await call('/services/' + encodeURIComponent(name) + '/check', 'POST'); } catch (e) { D.checks[name] = { ok: false, detail: e.message }; }
    TR.app.refresh();
  }

  const num = (n) => Number(n || 0).toLocaleString((TR.culture && TR.culture.active().language) || undefined);
  const field = (label, input, hint) => h('label', { class: 'ds-field' }, h('span', { class: 'ds-label' }, t(label)), input, hint ? h('small', { class: 'muted' }, t(hint)) : null);
  const text = (value, onInput, attrs) => h('input', Object.assign({ type: 'text', class: 'ds-input', value, onInput: (e) => onInput(e.target.value), spellcheck: 'false' }, attrs || {}));
  const select = (value, options, onChange, label) => h('select', { class: 'ds-input', 'aria-label': label, onChange: (e) => onChange(e.target.value) }, options.map(([v, l]) => h('option', { value: v, selected: v === value }, t(l))));

  function repository(ui) {
    const r = D.data.repository, counts = r.collections || {};
    const changed = D.repo.path !== r.saved.path || COLLECTIONS.some(([c]) => (D.repo.formats[c] || 'json') !== (r.formats[c] || 'json'));
    return h('section', { class: 'ds-card', 'aria-labelledby': 'ds-repo' },
      h('header', { class: 'ds-card-head' }, h('h2', { id: 'ds-repo' }, t('Repository')), ui.chip(r.description, 'neutral')),
      r.restartNeeded ? h('div', { class: 's-banner warning' }, TR.icon('alert'), t('Saved settings name {p}. The app still uses {c} until it restarts.', { p: r.saved.path, c: r.path })) : null,
      h('div', { class: 'ds-grid' },
        field('Provider', select('Files', [['Files', 'Files (JSON and XML)']], () => {}, t('Provider')), 'A database provider is added in code first; see docs/data-and-services.md.'),
        field('Folder', text(D.repo.path, (v) => { D.repo.path = v; }), 'A full path, for example C:\\trt\\repo. Applies when the app next starts.')),
      h('table', { class: 'ds-table' },
        h('caption', { class: 'sr-only' }, t('Collections, their format and how many records each holds')),
        h('thead', null, h('tr', null, h('th', { scope: 'col' }, t('Collection')), h('th', { scope: 'col' }, t('Format')), h('th', { scope: 'col', class: 'num' }, t('Records')))),
        h('tbody', null, COLLECTIONS.map(([c, label]) => h('tr', null,
          h('th', { scope: 'row' }, t(label), h('small', { class: 'muted ds-code' }, c)),
          h('td', null, select(D.repo.formats[c] || 'json', [['json', 'JSON'], ['xml', 'XML']], (v) => { D.repo.formats[c] = v; TR.app.refresh(); }, t('Format of {c}', { c: t(label) }))),
          h('td', { class: 'num' }, num(counts[c])))))),
      h('footer', { class: 'ds-actions' },
        ui.button(D.busy.repo ? t('Saving…') : t('Save repository settings'), 'check', saveRepository, changed ? 'primary' : 'secondary'),
        h('small', { class: 'muted' }, t('Settings file: {f}', { f: D.data.settingsFile }))));
  }

  function services(ui) {
    const s = D.data.services;
    return h('section', { class: 'ds-card', 'aria-labelledby': 'ds-services' },
      h('header', { class: 'ds-card-head' }, h('h2', { id: 'ds-services' }, t('Services'))),
      h('p', { class: 'muted' }, t('Every call to an external system goes through the service layer. Files reads answers from a folder; Http calls the live service; Off refuses calls. A change applies to the next call.')),
      h('div', { class: 'ds-row' },
        field('Folder for the Files transport', text(D.servicesPath, (v) => { D.servicesPath = v; })),
        ui.button(D.busy.path ? t('Saving…') : t('Save folder'), 'check', saveServicesPath, D.servicesPath !== s.path ? 'primary' : 'secondary')),
      h('div', { class: 'ds-services' }, s.endpoints.map((e) => {
        const edit = D.edits[e.name], c = D.checks[e.name];
        const dirty = edit.transport !== e.transport || (edit.baseUrl || '') !== (e.baseUrl || '') || Number(edit.timeoutSeconds) !== e.timeoutSeconds;
        return h('article', { class: 'ds-service' },
          h('header', null, h('h3', null, e.name), ui.chip(e.configured ? t('Ready') : e.transport === 'Off' ? t('Off') : t('Not set up'), e.configured ? 'good' : 'neutral')),
          h('div', { class: 'ds-grid' },
            field('Transport', select(edit.transport, [['Files', 'Files'], ['Http', 'Http'], ['Off', 'Off']], (v) => { edit.transport = v; TR.app.refresh(); }, t('Transport for {s}', { s: e.name }))),
            edit.transport === 'Http'
              ? field('Base URL', text(edit.baseUrl, (v) => { edit.baseUrl = v; }, { type: 'url', placeholder: 'https://' }))
              : edit.transport === 'Files' ? field('Folder', h('code', { class: 'ds-code' }, e.folder)) : null,
            edit.transport === 'Http' ? field('Timeout (seconds)', text(String(edit.timeoutSeconds), (v) => { edit.timeoutSeconds = v; }, { type: 'number', min: '1', max: '300' })) : null),
          c && !c.busy ? h('p', { class: ['ds-check', c.ok ? 'is-ok' : 'is-bad'], role: 'status' }, TR.icon(c.ok ? 'check' : 'alert', 14), c.detail) : null,
          h('footer', { class: 'ds-actions' },
            ui.button(D.busy[e.name] ? t('Saving…') : t('Save'), 'check', () => saveService(e.name), dirty ? 'primary' : 'secondary'),
            ui.button(c && c.busy ? t('Checking…') : t('Check'), 'pulse', () => check(e.name), 'text')));
      })));
  }

  function render() {
    load();
    const ui = TR.pages.ui;
    return h('div', { class: 'st-page ds-page' },
      h('div', { class: 'st-head' }, h('h1', null, t('Data and services')),
        h('p', { class: 'muted' }, t('Where Test Request Tool keeps its data, and how it reaches other systems.'))),
      D.error ? h('div', { class: 's-banner warning' }, TR.icon('alert'), D.error, ui.button(t('Try again'), 'refresh', () => load(true), 'text')) : null,
      !D.data && !D.error ? h('p', { class: 'muted' }, t('Loading…')) : null,
      D.data ? repository(ui) : null,
      D.data ? services(ui) : null);
  }

  TR.pages.register({ id: 'data', title: 'Data and services', crumbs: () => [{ label: t('Administration') }, { label: t('Data and services') }], render });
  TR.dataSettings = { render, D, load };
})();
