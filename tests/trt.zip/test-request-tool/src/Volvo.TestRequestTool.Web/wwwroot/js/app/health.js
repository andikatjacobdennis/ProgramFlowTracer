/* Service health: what happened to every service, when, for how long and why. Data: /api/v1/monitor/*.
 *
 *   Overview   – status now, availability, latency and a status strip per service for the chosen window
 *   Timeline   – one lane per service with every slow spell and outage, plus response time for one service
 *   Incidents  – every incident with its root cause; filter by service, cause, severity, planned and text; open one inline
 *                to see the chain back to the first failure, what it caused and the minutes around it
 *   Insights   – time to recover (MTTR), time between failures (MTBF), error budget against an objective, top causes,
 *                where failures start and when in the week they happen
 *
 * Simulated services stand in for external systems that are not connected and are always labelled so; the
 * workspace store, job workers and memory are checked live. Nothing here is a dialog. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));
  const NS = 'http://www.w3.org/2000/svg';
  const svg = (tag, attrs = {}, kids = []) => { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs)) if (v != null) e.setAttribute(k, String(v)); [].concat(kids).filter(Boolean).forEach((k) => e.appendChild(typeof k === 'string' ? document.createTextNode(k) : k)); return e; };
  const ui = () => TR.pages.ui;
  const WINDOWS = [['1h', '1 h'], ['6h', '6 h'], ['24h', '24 h'], ['7d', '7 days'], ['30d', '30 days'], ['90d', '90 days']];
  const TABS = [['overview', 'Overview', 'grid'], ['timeline', 'Timeline', 'chart'], ['incidents', 'Incidents', 'alert'], ['insights', 'Insights', 'spark']];
  const H = { tab: 'overview', window: '24h', services: null, history: null, incidents: null, insights: null, error: null, loading: {}, filters: { service: '', cause: '', severity: '', planned: '', q: '' }, focus: 'vda', open: null, detail: null, page: 0 };
  const COLOR = { up: 'var(--success)', degraded: 'var(--warning)', down: 'var(--error)', nodata: 'color-mix(in srgb, var(--muted) 30%, transparent)' };

  async function get(key, path) {
    if (H.loading[key]) return;
    H.loading[key] = true;
    try { H[key] = await ui().api(path); H.error = null; } catch (e) { H.error = e.message; }
    H.loading[key] = false;
    TR.app.refresh();
  }
  const query = () => { const f = H.filters, q = new URLSearchParams({ window: H.window === '1h' || H.window === '6h' ? '24h' : H.window, take: '500' }); for (const k of ['service', 'cause', 'severity', 'q']) if (f[k]) q.set(k, f[k]); if (f.planned) q.set('planned', f.planned); return q.toString(); };
  function load(force) {
    if (force) { H.services = H.history = H.incidents = H.insights = null; }
    if (!H.services) get('services', '/monitor/services?window=' + H.window);
    if (H.tab === 'timeline' && !H.history) get('history', '/monitor/history?window=' + H.window);
    if (H.tab === 'incidents' && !H.incidents) get('incidents', '/monitor/incidents?' + query());
    if (H.tab === 'insights' && !H.insights) get('insights', '/monitor/insights?window=' + (H.window === '1h' || H.window === '6h' || H.window === '24h' ? '7d' : H.window));
  }
  const setWindow = (w) => { H.window = w; load(true); };
  const setTab = (tab) => { H.tab = tab; load(false); TR.app.refresh(); };
  const name = (id) => ((H.services && H.services.services.find((s) => s.id === id)) || { name: id }).name;
  const dur = (m) => (m < 1 ? '<1 min' : m < 90 ? Math.round(m) + ' min' : m < 60 * 48 ? (m / 60).toFixed(1) + ' h' : (m / 1440).toFixed(1) + ' days');
  const pct = (v) => (v == null ? '—' : v.toFixed(v >= 99.9 ? 3 : 2) + ' %');
  const when = (v) => h('time', { datetime: v }, ui().when(v));
  const statusChip = (s) => ui().chip(t({ up: 'Up', degraded: 'Degraded', down: 'Down', unknown: 'Unknown' }[s] || s), s === 'up' ? 'good' : s === 'unknown' ? 'neutral' : 'warning');

  // ------------------------------------------------------------------ overview
  function overview() {
    const d = H.services;
    if (!d) return skeleton(6);
    const list = d.services, now = { up: 0, degraded: 0, down: 0 };
    list.forEach((s) => { now[s.status] = (now[s.status] || 0) + 1; });
    const avail = list.filter((s) => s.availability != null);
    const avg = avail.length ? avail.reduce((a, s) => a + s.availability, 0) / avail.length : null;
    return h('div', { class: 'hl-overview' },
      h('div', { class: 'hl-kpis' },
        kpi(t('Up now'), String(now.up), now.up ? 'good' : ''), kpi(t('Degraded'), String(now.degraded || 0), now.degraded ? 'warning' : ''), kpi(t('Down'), String(now.down || 0), now.down ? 'danger' : ''),
        kpi(t('Average availability'), pct(avg), ''), kpi(t('Incidents'), String(list.reduce((a, s) => a + s.incidents, 0)), ''), kpi(t('Downtime'), dur(list.reduce((a, s) => a + s.downMinutes, 0)), '')),
      h('div', { class: 'hl-list', role: 'table', 'aria-label': t('Services') },
        h('div', { class: 'hl-row hl-head', role: 'row' }, ['Service', 'Now', 'Availability', 'p95', 'History', ''].map((x) => h('span', { role: 'columnheader' }, t(x)))),
        list.map((s) => h('div', { class: ['hl-row', 'is-' + s.status], role: 'row' },
          h('span', { class: 'hl-name', role: 'cell' }, h('i', { class: 'hl-dot', 'aria-hidden': 'true' }), h('span', null, h('strong', null, s.name), h('small', null, s.kind + (s.simulated ? ' · ' + t('simulated') : ' · ' + t('live check'))))),
          h('span', { role: 'cell' }, statusChip(s.status)),
          h('span', { role: 'cell', class: 'hl-num' }, pct(s.availability)),
          h('span', { role: 'cell', class: 'hl-num' }, s.p95Ms ? Math.round(s.p95Ms) + ' ms' : '—'),
          h('span', { role: 'cell' }, strip(s.bars, s.name)),
          h('span', { role: 'cell', class: 'hl-actions' },
            ui().button(t('Timeline'), 'chart', () => { H.focus = s.id; setTab('timeline'); }, 'text'),
            ui().button(t('Incidents'), 'alert', () => { H.filters.service = s.id; H.incidents = null; setTab('incidents'); }, 'text'),
            ui().button(t('Check now'), 'pulse', () => check(s.id), 'text'))))),
      h('p', { class: 'muted hl-note' }, t('Checked every {s} seconds. Simulated services stand in for systems this installation does not connect to; their history is generated and repeatable. The store, job workers and memory are checked live.', { s: d.interval })));
  }
  const kpi = (label, value, tone) => h('div', { class: ['hl-kpi', tone ? 'tone-' + tone : ''] }, h('strong', null, value), h('span', null, label));
  function strip(bars, label) {
    return h('span', { class: 'hl-strip', role: 'img', 'aria-label': label + ': ' + t('status over the window') }, (bars || []).map((b) => h('i', { class: 'hl-bar is-' + b })));
  }
  async function check(id) {
    try {
      const r = await fetch('/api/v1/monitor/check/' + encodeURIComponent(id), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
      const s = await r.json();
      TR.notify && TR.notify.toast(`${name(id)}: ${s.status}${s.detail ? ' · ' + s.detail : ''} (${Math.round(s.ms)} ms)`, s.status === 'up' ? 'success' : 'warning');
    } catch (e) { TR.notify && TR.notify.toast(e.message, 'error'); }
  }

  // ------------------------------------------------------------------ timeline
  function timeline() {
    const d = H.history;
    if (!d) return skeleton(8);
    const W = 1000, lane = 26, top = 24, left = 150, series = d.series, n = series[0] ? series[0].points.length : 0;
    const x = (i) => left + (i / Math.max(1, n)) * (W - left - 10);
    const from = new Date(d.from), to = new Date(d.to);
    const ticks = 6, tickEls = [];
    for (let i = 0; i <= ticks; i++) {
      const at = new Date(from.getTime() + (to - from) * i / ticks);
      tickEls.push(svg('line', { x1: left + (W - left - 10) * i / ticks, x2: left + (W - left - 10) * i / ticks, y1: top - 6, y2: top + series.length * lane, class: 'hl-grid' }),
        svg('text', { x: left + (W - left - 10) * i / ticks, y: 14, class: 'hl-axis', 'text-anchor': i === 0 ? 'start' : i === ticks ? 'end' : 'middle' }, label(at, to - from)));
    }
    const lanes = series.map((s, r) => {
      const y = top + r * lane;
      const cells = [];
      s.points.forEach((p, i) => {
        if (p.status === 'up') return;
        cells.push(svg('rect', { x: x(i), y: y + 4, width: Math.max(1.5, x(i + 1) - x(i)), height: lane - 8, rx: 2, fill: COLOR[p.status], class: 'hl-cell' },
          svg('title', {}, `${s.name} · ${p.status} · ${new Date(p.at).toLocaleString()} · ${p.down} min down, ${p.degraded} min slow`)));
      });
      return svg('g', { class: 'hl-lane' + (s.id === H.focus ? ' is-focus' : ''), style: 'cursor:pointer' }, [
        svg('rect', { x: left, y: y + 4, width: W - left - 10, height: lane - 8, rx: 4, class: 'hl-lane-bg' }),
        svg('text', { x: 0, y: y + lane / 2 + 4, class: 'hl-lane-label' }, s.name + (s.simulated ? '' : ' •')),
      ].concat(cells));
    });
    const chart = svg('svg', { viewBox: `0 0 ${W} ${top + series.length * lane + 6}`, class: 'hl-swim', role: 'img', 'aria-label': t('Outages and slow spells per service') }, tickEls.concat(lanes));
    chart.querySelectorAll('.hl-lane').forEach((g, i) => g.addEventListener('click', () => { H.focus = series[i].id; TR.app.refresh(); }));
    const focus = series.find((s) => s.id === H.focus) || series[0];
    return h('div', { class: 'hl-timeline' },
      h('section', { class: 'st-card hl-card' }, h('header', { class: 'hl-card-head' }, h('h2', null, t('Outages and slow spells')), legend()), chart,
        h('p', { class: 'muted hl-note' }, t('Click a service to see its response time below. • marks a live check.'))),
      focus ? h('section', { class: 'st-card hl-card' }, h('header', { class: 'hl-card-head' }, h('h2', null, t('Response time') + ' · ' + focus.name),
        h('select', { 'aria-label': t('Service'), onChange: (e) => { H.focus = e.target.value; TR.app.refresh(); } }, series.map((s) => h('option', { value: s.id, selected: s.id === focus.id }, s.name)))),
        latency(focus, from, to)) : null);
  }
  const legend = () => h('span', { class: 'hl-legend' }, [['up', 'Up'], ['degraded', 'Degraded'], ['down', 'Down']].map(([k, l]) => h('span', null, h('i', { class: 'hl-bar is-' + k }), t(l))));
  function label(d, range) {
    const L = TR.culture ? TR.culture.active() : { language: undefined, timeZone: undefined };
    const o = range > 2 * 864e5 ? { month: 'short', day: 'numeric' } : { hour: '2-digit', minute: '2-digit' };
    try { return new Intl.DateTimeFormat(L.language, Object.assign({ timeZone: L.timeZone }, o)).format(d); } catch (e) { return d.toISOString().slice(5, 16); }
  }
  function latency(s, from, to) {
    const W = 1000, H2 = 200, pad = 36, pts = s.points.filter((p) => p.status !== 'nodata');
    if (!pts.length) return h('p', { class: 'muted' }, t('No samples in this window yet.'));
    const max = Math.max(1, ...pts.map((p) => p.p95Ms)) * 1.1, n = s.points.length;
    const x = (i) => pad + (i / Math.max(1, n - 1)) * (W - pad - 10), y = (v) => H2 - 24 - (v / max) * (H2 - 40);
    const line = (k) => s.points.map((p, i) => (p.status === 'nodata' ? null : `${i === 0 ? 'M' : 'L'}${x(i).toFixed(1)},${y(p[k]).toFixed(1)}`)).filter(Boolean).join(' ').replace(/^L/, 'M');
    const down = s.points.map((p, i) => (p.down ? svg('rect', { x: x(i) - 1, y: 8, width: Math.max(2, (W - pad) / n), height: H2 - 32, fill: COLOR.down, opacity: 0.12 }) : null)).filter(Boolean);
    const grid = [0, .25, .5, .75, 1].map((f) => [svg('line', { x1: pad, x2: W - 10, y1: y(max * f), y2: y(max * f), class: 'hl-grid' }), svg('text', { x: pad - 6, y: y(max * f) + 4, class: 'hl-axis', 'text-anchor': 'end' }, Math.round(max * f) + '')]).flat();
    return svg('svg', { viewBox: `0 0 ${W} ${H2}`, class: 'hl-latency', role: 'img', 'aria-label': t('Response time') }, grid.concat(down, [
      svg('path', { d: line('p95Ms'), class: 'hl-line p95' }), svg('path', { d: line('avgMs'), class: 'hl-line avg' }),
      svg('text', { x: W - 12, y: 20, class: 'hl-axis', 'text-anchor': 'end' }, 'ms · ' + t('average') + ' / p95 · ' + label(from, to - from) + ' – ' + label(to, to - from)),
    ]));
  }

  // ------------------------------------------------------------------ incidents
  function incidents() {
    const f = H.filters, d = H.incidents;
    const services = H.services ? H.services.services : [];
    const reload = () => { H.incidents = null; H.page = 0; load(false); };
    const filters = h('div', { class: 'hl-filters' },
      h('select', { 'aria-label': t('Service'), onChange: (e) => { f.service = e.target.value; reload(); } }, h('option', { value: '' }, t('All services')), services.map((s) => h('option', { value: s.id, selected: f.service === s.id }, s.name))),
      h('select', { 'aria-label': t('Cause'), onChange: (e) => { f.cause = e.target.value; reload(); } }, [['', 'All causes'], ['upstream', 'Another service failed'], ['timeout', 'Timeouts'], ['http_5xx', 'Server errors'], ['latency', 'Slow responses'], ['certificate', 'Certificate'], ['dns', 'Name resolution'], ['maintenance', 'Planned maintenance']].map(([v, l]) => h('option', { value: v, selected: f.cause === v }, t(l)))),
      seg(t('Severity'), [['', 'All'], ['down', 'Down'], ['degraded', 'Degraded']], f.severity, (v) => { f.severity = v; reload(); }),
      seg(t('Planned'), [['', 'All'], ['false', 'Unplanned'], ['true', 'Planned']], f.planned, (v) => { f.planned = v; reload(); }),
      h('label', { class: 'tp-field hl-search' }, TR.icon('search', 15), h('input', { placeholder: t('Search causes'), value: f.q, onChange: (e) => { f.q = e.target.value; reload(); } })),
      Object.values(f).some(Boolean) ? ui().button(t('Clear filters'), 'close', () => { H.filters = { service: '', cause: '', severity: '', planned: '', q: '' }; reload(); }, 'text') : null);
    if (!d) return h('div', null, filters, skeleton(8));
    const size = 25, pages = Math.max(1, Math.ceil(d.items.length / size)), items = d.items.slice(H.page * size, H.page * size + size);
    return h('div', { class: 'hl-incidents' }, filters,
      h('p', { class: 'muted' }, t('{n} incidents', { n: d.total }) + (d.total > d.items.length ? ' · ' + t('showing the newest {m}', { m: d.items.length }) : '')),
      items.length ? h('div', { class: 'hl-table', role: 'table' },
        h('div', { class: 'hl-irow hl-head', role: 'row' }, ['Started', 'Service', 'Severity', 'Cause', 'Root cause', 'Duration', 'Impact'].map((x) => h('span', { role: 'columnheader' }, t(x)))),
        items.map((i) => [
          h('button', { class: ['hl-irow', H.open === i.id ? 'is-open' : ''], role: 'row', 'aria-expanded': String(H.open === i.id), onClick: () => openIncident(i.id) },
            h('span', { role: 'cell' }, when(i.start)), h('span', { role: 'cell' }, h('strong', null, name(i.service))),
            h('span', { role: 'cell' }, ui().chip(i.severity === 'down' ? t('Down') : t('Degraded'), 'warning'), i.planned ? ui().chip(t('Planned'), 'neutral') : null, i.end ? null : ui().chip(t('Ongoing'), 'warning')),
            h('span', { role: 'cell' }, t(i.causeTitle)),
            h('span', { role: 'cell' }, i.rootService ? h('span', { class: 'hl-root' }, TR.icon('arrow', 13), name(i.rootService)) : h('span', { class: 'muted' }, t('This service'))),
            h('span', { role: 'cell', class: 'hl-num' }, dur(i.minutes)),
            h('span', { role: 'cell', class: 'hl-num' }, i.impacted.length ? t('{n} services', { n: i.impacted.length }) : '—')),
          H.open === i.id ? detail(i) : null,
        ])) : h('div', { class: 'tp-empty' }, h('h3', null, t('No incidents match')), h('p', { class: 'muted' }, t('Try another window or clear the filters.'))),
      pages > 1 ? h('div', { class: 'hl-pager' }, ui().button(t('Newer'), 'left', () => { H.page = Math.max(0, H.page - 1); TR.app.refresh(); }, 'text'), h('span', null, `${H.page + 1} / ${pages}`), ui().button(t('Older'), 'right', () => { H.page = Math.min(pages - 1, H.page + 1); TR.app.refresh(); }, 'text')) : null);
  }
  const seg = (label, options, value, set) => h('div', { class: 'tp-seg', role: 'radiogroup', 'aria-label': label }, options.map(([v, l]) => h('button', { type: 'button', role: 'radio', 'aria-checked': String(value === v), class: value === v ? 'is-on' : '', onClick: () => set(v) }, t(l))));
  async function openIncident(id) {
    if (H.open === id) { H.open = null; TR.app.refresh(); return; }
    H.open = id; H.detail = null; TR.app.refresh();
    try { H.detail = await ui().api('/monitor/incidents/' + encodeURIComponent(id)); } catch (e) { H.detail = { error: e.message }; }
    TR.app.refresh();
  }
  /** Root cause analysis, inline under the incident row. */
  function detail(i) {
    const d = H.detail;
    if (!d) return h('div', { class: 'hl-detail' }, skeleton(3));
    if (d.error) return h('div', { class: 'hl-detail s-banner warning' }, d.error);
    const chain = [d.incident].concat(d.rootChain);
    return h('div', { class: 'hl-detail' },
      h('div', { class: 'hl-rca' },
        h('h3', null, t('Root cause')),
        h('p', null, h('strong', null, chain.length > 1 ? name(chain[chain.length - 1].service) + ': ' + t(chain[chain.length - 1].causeTitle) : t(i.causeTitle)), ' — ', chain[chain.length - 1].rootCause),
        h('ol', { class: 'hl-chain', 'aria-label': t('Chain of failures') }, chain.slice().reverse().map((x, k) => h('li', { class: k === 0 ? 'is-root' : '' },
          h('i', { class: 'hl-dot is-' + x.severity }), h('span', null, h('strong', null, name(x.service)), h('small', null, `${t(x.causeTitle)} · ${dur(x.minutes)} · ${ui().when(x.start)}`)),
          x.confidence === 'correlated' ? ui().chip(t('Correlated'), 'neutral') : ui().chip(t('Direct'), 'good')))),
        d.caused.length ? h('p', { class: 'muted' }, t('It also caused: ') + d.caused.map((c) => name(c.service)).join(', ')) : null,
        h('p', { class: 'muted hl-note' }, chain.length > 1 ? t('Found by dependency and time: the upstream service failed first, this one followed within minutes.') : t('No upstream service failed at the same time, so the cause is in this service.'))),
      h('div', { class: 'hl-events' }, h('h3', null, t('What happened')),
        h('ol', null, d.incident.timeline.map((e) => h('li', null, when(e.at), h('span', { class: 'hl-ev-kind' }, t(e.kind)), e.text)))),
      h('div', { class: 'hl-around' }, h('h3', null, t('Minute by minute')), strip(d.history.map((p) => p.status), name(i.service)), h('p', { class: 'muted hl-note' }, t('30 minutes before and after.'))));
  }

  // ------------------------------------------------------------------ insights
  function insights() {
    const d = H.insights;
    if (!d) return skeleton(8);
    const svc = d.services.filter((s) => s.simulated || s.incidents > 0);
    const worst = svc.slice().sort((a, b) => a.availability - b.availability)[0];
    return h('div', { class: 'hl-insights' },
      h('div', { class: 'hl-kpis' },
        kpi(t('Incidents'), String(d.total), ''), kpi(t('Time to recover (MTTR)'), dur(d.mttrMinutes), ''),
        kpi(t('Least available'), worst ? `${worst.name} · ${pct(worst.availability)}` : '—', worst && worst.availability < d.slo ? 'warning' : ''),
        kpi(t('Objective'), d.slo + ' %', '')),
      h('div', { class: 'hl-grid2' },
        card(t('Error budget used'), t('Share of allowed downtime used in the window, against the {slo} % objective.', { slo: d.slo }), bars(svc.map((s) => [s.name, s.budgetUsed, s.budgetUsed > 100 ? 'danger' : s.budgetUsed > 75 ? 'warning' : 'good', Math.round(s.budgetUsed) + ' %']), 150)),
        card(t('Top causes'), t('By minutes of disruption.'), bars(d.causes.map((c) => [t(c.cause), c.minutes, '', dur(c.minutes) + ' · ' + c.count]), Math.max(1, ...d.causes.map((c) => c.minutes)))),
        card(t('Where failures start'), t('Incidents in other services caused by each one.'), d.origins.length ? bars(d.origins.map((o) => [name(o.service), o.caused, 'warning', String(o.caused)]), Math.max(1, ...d.origins.map((o) => o.caused))) : h('p', { class: 'muted' }, t('No failure spread to other services.'))),
        card(t('Recovery and frequency'), t('Mean time to recover, and mean time between failures.'), h('div', { class: 'hl-mini-table' }, svc.map((s) => h('div', null, h('span', null, s.name), h('span', { class: 'hl-num' }, dur(s.mttrMinutes)), h('span', { class: 'hl-num' }, s.mtbfHours == null ? '—' : s.mtbfHours + ' h'))))),
        card(t('When trouble happens'), t('Incident minutes by weekday and hour (UTC).'), heat(d.heat)),
        card(t('Per day'), t('Incidents and minutes of disruption.'), perDay(d.perDay))));
  }
  const card = (title, sub, body) => h('section', { class: 'st-card hl-card' }, h('header', { class: 'hl-card-head' }, h('div', null, h('h2', null, title), h('p', { class: 'muted' }, sub))), body);
  function bars(rows, max) {
    return h('div', { class: 'hl-bars' }, rows.map(([label, v, tone, text]) => h('div', { class: 'hl-barrow' }, h('span', null, label),
      h('span', { class: 'hl-track' }, h('i', { class: 'tone-' + (tone || 'accent'), style: { width: Math.min(100, (v / max) * 100) + '%' } })), h('span', { class: 'hl-num' }, text))));
  }
  function heat(grid) {
    const max = Math.max(1, ...grid.flat()), days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const cells = [];
    grid.forEach((row, d) => row.forEach((v, hr) => cells.push(svg('rect', { x: 34 + hr * 22, y: d * 20, width: 20, height: 18, rx: 3, class: 'hl-heat', style: `fill-opacity:${v ? 0.15 + 0.85 * (v / max) : 0.04}` }, svg('title', {}, `${days[d]} ${hr}:00 · ${Math.round(v)} min`)))));
    const labels = days.map((d, i) => svg('text', { x: 0, y: i * 20 + 13, class: 'hl-axis' }, t(d))).concat([0, 6, 12, 18, 23].map((hr) => svg('text', { x: 34 + hr * 22 + 10, y: 156, class: 'hl-axis', 'text-anchor': 'middle' }, String(hr))));
    return svg('svg', { viewBox: '0 0 566 160', class: 'hl-heatmap', role: 'img', 'aria-label': t('Incident minutes by weekday and hour') }, cells.concat(labels));
  }
  function perDay(rows) {
    if (!rows.length) return h('p', { class: 'muted' }, t('No incidents.'));
    const W = 560, H2 = 140, max = Math.max(1, ...rows.map((r) => r.minutes)), bw = (W - 20) / rows.length;
    return svg('svg', { viewBox: `0 0 ${W} ${H2}`, class: 'hl-perday', role: 'img', 'aria-label': t('Incidents per day') }, rows.map((r, i) => svg('rect', { x: 10 + i * bw, y: H2 - 18 - (r.minutes / max) * (H2 - 30), width: Math.max(2, bw - 2), height: (r.minutes / max) * (H2 - 30), rx: 2, class: 'hl-col' }, svg('title', {}, `${r.day}: ${r.count} · ${Math.round(r.minutes)} min`)))
      .concat([svg('text', { x: 10, y: H2 - 4, class: 'hl-axis' }, rows[0].day), svg('text', { x: W - 10, y: H2 - 4, class: 'hl-axis', 'text-anchor': 'end' }, rows[rows.length - 1].day)]));
  }
  const skeleton = (n) => h('div', { class: 'hl-skeleton', 'aria-busy': 'true' }, Array.from({ length: n }, () => h('div', { class: 'ap-skeleton', style: { height: '34px', marginBottom: '8px' } })));

  // ------------------------------------------------------------------ page
  function render() {
    load(false);
    return h('div', { class: 'st-page hl-page' },
      h('div', { class: 'st-head hl-top' },
        h('div', null, h('h1', null, t('Service health')), h('p', { class: 'muted' }, t('What happened to every service, when, for how long and why.'))),
        h('div', { class: 'hl-controls' },
          h('div', { class: 'tp-seg', role: 'radiogroup', 'aria-label': t('Window') }, WINDOWS.map(([w, l]) => h('button', { type: 'button', role: 'radio', 'aria-checked': String(H.window === w), class: H.window === w ? 'is-on' : '', onClick: () => setWindow(w) }, t(l)))),
          ui().button(t('Refresh'), 'refresh', () => load(true), 'secondary'),
          ui().button(t('Logs'), 'file', () => TR.pages.show('logs'), 'text'),
          ui().button(t('Connections'), 'globe', () => TR.pages.show('connections'), 'text'))),
      h('nav', { class: 'hl-tabs', role: 'tablist' }, TABS.map(([id, l, icon]) => h('button', { role: 'tab', 'aria-selected': String(H.tab === id), class: H.tab === id ? 'is-on' : '', onClick: () => setTab(id) }, TR.icon(icon, 15), t(l)))),
      H.error ? h('div', { class: 's-banner warning' }, TR.icon('alert'), H.error) : null,
      H.tab === 'overview' ? overview() : H.tab === 'timeline' ? timeline() : H.tab === 'incidents' ? incidents() : insights());
  }
  TR.pages.register({ id: 'health', title: 'Service health', crumbs: () => [{ label: t('Service health') }], render });
  TR.health = { H, load };
})();
