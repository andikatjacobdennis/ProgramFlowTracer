/* Users (Administration): the user list as a table that scales to lakhs of accounts. Search, filters (role, status, country),
 * sorting and paging run on the server (/api/v1/admin/users/search), one page at a time. Columns can be shown or hidden
 * (remembered in this browser); the pager shows at most five page numbers. Add user and Edit use the existing form
 * (experience.js); every account can be edited. User ids may contain characters such as \ or @: always encoded in URLs.
 * Below the table: what each role may do. */
(function () {
  'use strict';
  const { h } = TR.util;
  const J = TR.journey, t = J.t, ui = () => TR.pages.ui;
  const X = TR.experience;
  const ROLES = ['Admin', 'Reviewer', 'Engineer', 'Viewer'];
  const TONE = { Admin: 'info', Reviewer: 'good', Engineer: 'warning', Viewer: 'neutral' };
  /** Optional columns: [id, label, sortable]. Name and the action are always shown. */
  const COLS = [['id', 'User ID', true], ['role', 'Role', true], ['country', 'Country', true], ['time', 'Local time', false], ['language', 'Language', false],
    ['contexts', 'Contexts', false], ['status', 'Status', true]];
  const DEFAULT_COLS = ['id', 'role', 'country', 'time', 'contexts', 'status'];
  const COLS_KEY = 'trstudio.userColumns';
  /** What each role may do: [ability, Admin, Reviewer, Engineer, Viewer]. */
  const CAN = [
    ['Look at vehicles, requests and results', 1, 1, 1, 1],
    ['Make changes and save drafts', 1, 0, 1, 0],
    ['Run checks', 1, 1, 1, 0],
    ['Approve or ask for changes (never their own)', 1, 1, 0, 0],
    ['Send approved changes', 1, 1, 0, 0],
    ['Manage users, teams and feature flags', 1, 0, 0, 0],
  ];
  const U = { q: '', role: '', status: '', country: '', sort: 'name', dir: 'asc', page: 1, size: 25, data: null, error: null, loading: false, key: null, seen: null, colsOpen: false };

  const cols = () => { const c = TR.util.store.get(COLS_KEY, null); return Array.isArray(c) ? c.filter((id) => COLS.some((x) => x[0] === id)) : DEFAULT_COLS.slice(); };
  const setCols = (list) => { TR.util.store.set(COLS_KEY, list); TR.app.refresh(); };
  /** The query string for the current filters, sort and page. Pure. */
  function query(s) {
    const p = new URLSearchParams();
    if (s.q.trim()) p.set('q', s.q.trim());
    ['role', 'status', 'country'].forEach((k) => { if (s[k]) p.set(k, s[k]); });
    p.set('sort', s.sort); p.set('order', s.dir); p.set('skip', String((s.page - 1) * s.size)); p.set('take', String(s.size));
    return p.toString();
  }
  function load() {
    // A saved edit (experience.js reloads X.adminUsers) shows at once.
    if (U.seen !== X.adminUsers) { U.seen = X.adminUsers; U.key = null; }
    const key = query(U);
    if (key === U.key) return;
    U.key = key; U.loading = true;
    J.api('/admin/users/search?' + key).then((d) => {
      if (U.key !== key) return;
      // Past the last page (the list shrank, or a stale page number): go to the last page instead of an empty one.
      const last = Math.max(1, Math.ceil(d.total / U.size));
      if (U.page > last) { U.page = last; U.key = null; U.loading = false; TR.app.refresh(); return; }
      U.data = d; U.error = null;
    })
      .catch((e) => { if (U.key === key) U.error = e.message; })
      .finally(() => { if (U.key === key) { U.loading = false; TR.app.refresh(); } });
  }
  const set = (patch, keepPage) => { Object.assign(U, patch); if (!keepPage) U.page = 1; TR.app.refresh(); };
  const num = (n) => Number(n || 0).toLocaleString((TR.culture && TR.culture.active().language) || undefined);

  // ------------------------------------------------------------------ cells
  function photo(u, size) {
    const box = h('span', { class: 'au-photo', style: { width: size + 'px', height: size + 'px' }, 'aria-hidden': 'true' }, h('span', { class: 'au-initials' }, J.initials(u.displayName)));
    // The portrait, when there is one (204 without): the initials stay underneath.
    const img = h('img', { src: '/api/v1/admin/users/' + encodeURIComponent(u.id) + '/photo?size=' + Math.ceil(size * (typeof devicePixelRatio === 'number' ? devicePixelRatio : 1)), alt: '', width: size, height: size, loading: 'lazy', decoding: 'async' });
    img.addEventListener('error', () => img.remove()); img.addEventListener('load', () => box.classList.add('has-photo'));
    box.appendChild(img);
    return box;
  }
  function cultureOf(u) {
    const c = TR.culture && u.country ? TR.culture.forCountry(u.country) : { timeZone: 'UTC', language: 'en' };
    let time = '', lang = c.language || '';
    try { time = new Intl.DateTimeFormat(c.language || undefined, { timeZone: c.timeZone || 'UTC', hour: '2-digit', minute: '2-digit' }).format(new Date()); } catch (e) { /* none */ }
    try { lang = new Intl.DisplayNames([c.language || 'en'], { type: 'language' }).of(c.language) || lang; } catch (e) { /* the code */ }
    return { zone: c.timeZone || 'UTC', time, lang };
  }
  const contextName = (id) => { const c = TR.db && TR.db.contexts.find((x) => x.id === id); return c ? c.name : t('Context {n}', { n: id }); };
  function cell(id, u, c) {
    switch (id) {
      case 'id': return h('code', { class: 'au-id' }, u.id);
      case 'role': return h('span', { class: 'jr-pill tone-' + TONE[u.role] }, t(u.role));
      case 'country': return h('span', { class: 'au-country' }, TR.culture ? TR.culture.flag(u.country || '', 16) : null, TR.culture ? TR.culture.countryName(u.country || '') : (u.country || 'UTC'));
      case 'time': return h('span', null, c.time, h('small', { class: 'muted' }, ' ' + c.zone));
      case 'language': return c.lang;
      case 'contexts': return h('span', { class: 'au-contexts', title: (u.contexts || []).map(contextName).join(', ') }, (u.contexts || []).slice(0, 2).map((x) => h('span', { class: 'au-ctx' }, contextName(x))), (u.contexts || []).length > 2 ? h('span', { class: 'muted' }, ' +' + ((u.contexts || []).length - 2)) : null);
      case 'status': return h('span', { class: 'jr-chip tone-' + (u.enabled ? 'good' : 'neutral') }, TR.icon(u.enabled ? 'check' : 'close', 13), t(u.enabled ? 'Enabled' : 'Disabled'));
      default: return null;
    }
  }

  // ------------------------------------------------------------------ the page
  function columnsMenu(shown) {
    return h('div', { class: 'au-cols' },
      ui().button(t('Columns'), 'sliders', () => set({ colsOpen: !U.colsOpen }, true), 'secondary', { 'aria-expanded': String(U.colsOpen), 'aria-haspopup': 'true' }),
      U.colsOpen ? h('div', { class: 'au-cols-menu', role: 'group', 'aria-label': t('Columns') },
        h('p', { class: 'au-cols-title' }, t('Show columns')),
        COLS.map(([id, label]) => h('label', { class: 'chk block' }, h('input', { type: 'checkbox', checked: shown.includes(id), onChange: (e) => setCols(e.target.checked ? COLS.map((x) => x[0]).filter((x) => x === id || shown.includes(x)) : shown.filter((x) => x !== id)) }), ' ', t(label))),
        h('div', { class: 'au-cols-actions' }, h('button', { type: 'button', class: 'jr-link', onClick: () => setCols(DEFAULT_COLS.slice()) }, t('Reset')), h('button', { type: 'button', class: 'jr-link', onClick: () => set({ colsOpen: false }, true) }, t('Done')))) : null);
  }
  function head(id, label, sortable) {
    if (!sortable) return h('th', { scope: 'col' }, t(label));
    const on = U.sort === id;
    return h('th', { scope: 'col', 'aria-sort': on ? (U.dir === 'asc' ? 'ascending' : 'descending') : 'none' },
      h('button', { type: 'button', class: 'au-sort' + (on ? ' is-on' : ''), onClick: () => set(on ? { dir: U.dir === 'asc' ? 'desc' : 'asc' } : { sort: id, dir: 'asc' }, false) }, t(label), h('span', { class: 'au-sort-mark', 'aria-hidden': 'true' }, on ? (U.dir === 'asc' ? '▲' : '▼') : '⇅')));
  }
  function table(d, shown, me) {
    const visible = COLS.filter(([id]) => shown.includes(id));
    return h('div', { class: 'jr-table-wrap au-table-wrap', 'aria-busy': String(U.loading) },
      h('table', { class: 'jr-table au-table' },
        h('thead', null, h('tr', null, head('name', 'Name', true), visible.map(([id, label, sortable]) => head(id, label, sortable)), h('th', { scope: 'col' }, h('span', { class: 'nv-sr' }, t('Action'))))),
        h('tbody', null, d.items.map((u) => { const c = cultureOf(u);
          return h('tr', { class: u.enabled ? '' : 'is-off' },
            h('td', null, h('span', { class: 'au-name' }, photo(u, 32), h('span', null, h('strong', null, u.displayName), u.id === me ? h('span', { class: 'jr-pill tone-info au-you' }, t('You')) : null))),
            visible.map(([id]) => h('td', null, cell(id, u, c))),
            h('td', { class: 'au-act' }, ui().button(t('Edit'), 'sliders', () => X.editUser && X.editUser({ id: u.id, displayName: u.displayName, role: u.role, contexts: u.contexts, enabled: u.enabled, country: u.country }), 'text')));
        }))));
  }

  function render() {
    load();
    const d = U.data, me = ((TR.backend && TR.backend.session) || {}).userId, shown = cols();
    const filtered = !!(U.q.trim() || U.status || U.country);
    const roles = d ? d.roles : {};
    const countries = TR.culture ? TR.culture.COUNTRIES : [];
    return h('div', { class: 'gx-page au-page', onKeydown: (e) => { if (e.key === 'Escape' && U.colsOpen) set({ colsOpen: false }, true); } },
      J.pageHead('Users', 'Everyone who can sign in: find people, see their role and culture, and what each role may do.',
        [ui().button(t('Add user'), 'plus', () => X.editUser && X.editUser(), 'primary')]),
      d ? J.stats([
        { n: num(d.all), label: 'Accounts', icon: 'people', tone: 'info' },
        { n: num((roles.Admin || 0) + (roles.Reviewer || 0)), label: 'Can approve', icon: 'shield', tone: 'good', sub: filtered ? t('matching the search') : t('{a} admin, {r} reviewer', { a: num(roles.Admin), r: num(roles.Reviewer) }), onClick: () => set({ role: 'Reviewer' }) },
        { n: num(roles.Engineer), label: 'Engineers', icon: 'wrench', tone: 'warning', onClick: () => set({ role: 'Engineer' }) },
        { n: num(roles.Viewer), label: 'Viewers', icon: 'search', tone: 'neutral', onClick: () => set({ role: 'Viewer' }) }]) : null,
      h('section', { class: 'jr-card au-card-table' },
        h('div', { class: 'au-tools' },
          h('label', { class: 'jr-search' }, TR.icon('search', 16), h('input', { type: 'search', key: 'au-search', placeholder: t('Find by name, user ID or country code'), 'aria-label': t('Find a person'), value: U.q, onInput: (e) => { U.q = e.target.value; U.page = 1; J.later(() => TR.app.refresh(), 250); } })),
          J.select('Role', U.role, [['', t('All')]].concat(ROLES.map((r) => [r, r + (d ? ' (' + num(roles[r]) + ')' : '')])), (v) => set({ role: v })),
          J.select('Status', U.status, [['', 'All'], ['enabled', 'Enabled'], ['disabled', 'Disabled']], (v) => set({ status: v })),
          J.select('Country', U.country, [['', 'All'], ['none', 'Not set (UTC)']].concat(countries.map((c) => [c.code, c.name])), (v) => set({ country: v })),
          filtered || U.role ? h('button', { type: 'button', class: 'jr-link', onClick: () => set({ q: '', role: '', status: '', country: '' }) }, t('Clear filters')) : null,
          h('span', { class: 'spacer' }),
          columnsMenu(shown)),
        U.error ? J.failed(U.error, () => { U.key = null; TR.app.refresh(); }) : !d ? J.loading(6)
          : d.items.length ? table(d, shown, me) : J.empty('Nobody matches', 'Try another name, ID or filter.'),
        d && d.total ? TR.pager({ total: d.total, page: U.page, size: U.size, label: 'users', sizes: [10, 25, 50, 100], onPage: (n) => set({ page: n }, true), onSize: (n) => set({ size: n }) }) : null),
      J.card('What each role may do', null, h('div', { class: 'jr-table-wrap' }, h('table', { class: 'jr-table au-matrix' },
        h('thead', null, h('tr', null, h('th', null, t('Ability')), ROLES.map((r) => h('th', null, t(r))))),
        h('tbody', null, CAN.map(([what, ...yes]) => h('tr', null, h('td', null, t(what)), yes.map((y, i) => h('td', { 'aria-label': t(ROLES[i]) + ': ' + t(y ? 'yes' : 'no') },
          y ? h('span', { class: 'au-yes' }, TR.icon('check', 16)) : h('span', { class: 'au-no' }, '—'))))))))),
      h('p', { class: 'muted jr-small' }, t('With a company sign-in, people and roles come from your identity provider.')));
  }

  TR.adminUsers = { render, query, CAN, ROLES, COLS, DEFAULT_COLS, U };
})();
