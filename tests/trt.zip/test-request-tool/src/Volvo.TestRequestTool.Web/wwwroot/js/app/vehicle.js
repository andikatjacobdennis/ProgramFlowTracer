/* Vehicle page: the loaded vehicle as a graph, its roadmap and its full history.
 *
 *   Graph   – vehicle → computers → execution environments → software, with icons per kind. "Compare with" shows how the
 *             vehicle looked at any earlier history entry as a GitHub-style diff: red for the earlier value, green for now.
 *   Roadmap – service packs and, per computer, the path from the as-built version through now to every upcoming version.
 *   History – a git-style graph of everything that happened to the vehicle: who, when and what changed. It loads a page at a
 *             time as you scroll (history-graph.js draws the lines and the diffs).
 *
 * Data comes from /api/v1/vehicles/{series}/{number}/timeline and /roadmap (see VehicleInsights.cs). */
(function () {
  'use strict';
  const { h } = TR.util;
  const { ui } = TR.pages;
  const G = TR.historyGraph;
  const left = () => TR.app.shell.left;
  const session = () => (TR.backend && TR.backend.session) || {};
  /** History entries per request; more load as the user scrolls. */
  const PAGE = 12;

  const V = {
    tab: 'graph', key: null, timeline: null, entries: [], hasMore: false, loadingMore: false, roadmap: null, error: null, loading: false,
    compare: '', snapshots: {}, builtAt: null, selected: null, query: '',
    history: { kind: 'all', person: 'all', query: '', open: new Set() },
  };

  const KINDS = {
    Built: { icon: 'factory', label: 'Built', verb: 'built it' }, Delivered: { icon: 'truck', label: 'Delivered', verb: 'delivered it' },
    Workshop: { icon: 'wrench', label: 'Workshop update', verb: 'updated it' }, VdaRecord: { icon: 'database', label: 'VDA record', verb: 'recorded it' },
    VdaCommit: { icon: 'database', label: 'VDA change', verb: 'committed' }, Kit: { icon: 'box', label: 'Kit', verb: 'created a kit' },
    Simulation: { icon: 'flask', label: 'Simulation', verb: 'simulated' },
  };
  const ARCH = { 0: 'TEA2', 1: 'TEA2+', 2: 'BEA2 body', 3: 'T3 HPC' };

  // ------------------------------------------------------------------ data
  function identity() {
    if (!left().product.loaded()) return null;
    const i = left().product.info();
    return { series: i.chassisSeries, number: i.chassisNumber, key: i.chassisSeries + '|' + i.chassisNumber };
  }
  const path = (id) => `/vehicles/${encodeURIComponent(id.series)}/${encodeURIComponent(id.number)}`;
  async function load(force) {
    const id = identity();
    if (!id || V.loading || (!force && V.key === id.key && V.timeline)) return;
    V.loading = true; V.error = null;
    if (V.key !== id.key) Object.assign(V, { compare: '', snapshots: {}, builtAt: null, selected: null, history: { kind: 'all', person: 'all', query: '', open: new Set() } });
    V.key = id.key;
    try {
      const [first, road] = await Promise.all([ui.api(`${path(id)}/timeline?skip=0&take=${PAGE}`), ui.api(path(id) + '/roadmap')]);
      Object.assign(V, { timeline: first, entries: first.entries, hasMore: first.hasMore, roadmap: road });
      const newest = V.entries.find((e) => (e.changes || []).length);
      if (newest) V.history.open.add(newest.id);
      try { const built = await ui.api(path(id) + '/timeline/built'); V.snapshots.built = built.product; V.builtAt = built.at; } catch (e) { /* not a catalog vehicle */ }
    } catch (e) { V.error = e.message; }
    V.loading = false;
    TR.app.refresh();
  }
  /** Loads the next page of older history. */
  async function loadMore() {
    const id = identity();
    if (!id || !V.hasMore || V.loadingMore) return;
    V.loadingMore = true; TR.app.refresh();
    try {
      const next = await ui.api(`${path(id)}/timeline?skip=${V.entries.length}&take=${PAGE}`);
      const known = new Set(V.entries.map((e) => e.id));
      V.entries = V.entries.concat(next.entries.filter((e) => !known.has(e.id)));
      V.hasMore = next.hasMore && next.entries.length > 0;
    } catch (e) { V.error = e.message; V.hasMore = false; }
    V.loadingMore = false;
    TR.app.refresh();
  }
  async function loadAll() { while (V.hasMore && identity()) { const before = V.entries.length; await loadMore(); if (V.entries.length === before) break; } }
  async function compareWith(entryId) {
    V.compare = entryId;
    const id = identity();
    if (entryId && entryId !== 'original' && !V.snapshots[entryId]) {
      try { V.snapshots[entryId] = (await ui.api(`${path(id)}/timeline/${entryId}`)).product; }
      catch (e) { TR.ui.alert(e.message); V.compare = ''; }
    }
    TR.app.refresh();
  }
  const compareProduct = () => (V.compare === 'original' ? left().product.getOriginal() : V.snapshots[V.compare] || null);
  const titleOf = (id) => (V.entries.find((e) => e.id === id) || {}).title || 'an earlier entry';

  // ------------------------------------------------------------------ helpers
  const isHpc = (n) => n.electricalArchitecture === 3;
  const nodeIcon = (n) => (isHpc(n) ? 'chip' : n.electricalArchitecture === 2 ? 'truck' : 'cpu');
  const pkgName = (s) => s.softwareProduct || s.name;
  function environments(node) {
    const groups = {};
    (node.softwareProducts || []).forEach((s) => { (groups[s.executionEnvironment || 'Default'] = groups[s.executionEnvironment || 'Default'] || []).push(s); });
    return Object.entries(groups).map(([name, items]) => ({ name, logicalEcu: items[0].logicalEcu, items }));
  }
  function legacyParts(node) {
    const parts = [];
    [['mainSoftware', 'Main software'], ['primaryBootloader', 'Primary bootloader'], ['secondaryBootloader', 'Secondary bootloader']].forEach(([k, label]) => { if (node[k]) parts.push({ label, value: node[k].number }); });
    (node.datas || []).forEach((d) => parts.push({ label: d.name || 'Data', value: d.number }));
    (node.complementarySoftwares || []).forEach((d) => parts.push({ label: d.name || 'Complementary', value: d.number }));
    return parts;
  }
  const byName = (product) => Object.fromEntries(((product && product.nodes) || []).map((n) => [n.name, n]));
  function pkgVersions(node) { return Object.fromEntries((node.softwareProducts || []).map((s) => [pkgName(s), s.packageVersion])); }
  const matchesQuery = (text) => !V.query || String(text).toLowerCase().includes(V.query.toLowerCase());
  /** The value now, and the earlier one beside it when it differs: red "−" before, green "+" now. */
  function versus(now, then, changed) {
    if (!changed) return h('code', null, now || '—');
    return h('span', { class: 'gh-pair' }, then ? h('code', { class: 'gh-was', title: 'Before' }, '− ' + then) : null, h('code', { class: 'gh-now', title: 'Now' }, '+ ' + (now || '—')));
  }

  // ------------------------------------------------------------------ page
  function render() {
    if (!left().product.loaded()) {
      return h('div', { class: 'vh-page' }, ui.heading('Vehicle', 'See a vehicle as a graph, where it can go next and everything that happened to it.'),
        h('div', { class: 'vh-empty' }, TR.help ? TR.help.guide('No vehicle yet! Load one and I will draw its computers, roadmap and history for you.', 'wave', 110, 'is-empty') : TR.icon('truck', 40), h('h2', null, 'No vehicle loaded'), h('p', null, 'Load a vehicle to see its computers, software, roadmap and history.'),
          ui.button('Add a vehicle', 'plus', () => { TR.experience.page = null; TR.testRequest.intake(); }, 'primary')));
    }
    load();
    const p = left().product, info = p.info();
    const t3 = p.current.nodes.some(isHpc);
    const tabs = [['graph', 'Graph', 'map'], TR.architecture ? ['map', 'Map', 'graph'] : null, ['roadmap', 'Roadmap', 'route'], ['history', 'History', 'history'], ['insights', 'Insights', 'chart']].filter(Boolean);
    return h('div', { class: 'vh-page' },
      h('section', { class: 'vh-identity' },
        h('div', { class: 'vh-identity-icon' }, TR.icon('truck', 30)),
        h('div', { class: 'vh-identity-main' },
          h('h1', null, p.chassisString()),
          h('div', { class: 'vh-facts' },
            fact('VIN', info.vin || '—'), fact('Model', info.modelId || info.productClassId || '—'), fact('Context', info.context ? info.context.name : '—'),
            fact('VDA revision', V.timeline ? String(V.timeline.currentRevision) : '…'), fact('Built', V.builtAt ? ui.day(V.builtAt) + (info.assemblyFactory ? ' · ' + info.assemblyFactory : '') : '—'))),
        h('div', { class: 'vh-identity-chips' }, ui.chip(t3 ? 'T3' : 'Legacy', t3 ? 'simulation' : 'neutral'), ui.chip(p.current.nodes.length + ' computers'))),
      h('div', { class: 's-tabs vh-tabs', role: 'tablist' }, tabs.map(([id, label, icon]) =>
        h('button', { class: ['s-btn', 'tab', V.tab === id ? 'active' : ''], role: 'tab', 'aria-selected': String(V.tab === id), onClick: () => { V.tab = id; TR.app.refresh(); } },
          TR.icon(icon, 16), label, id === 'history' && V.timeline ? h('span', { class: 'vh-count' }, String(V.timeline.total)) : null))),
      V.error ? h('div', { class: 's-banner warning' }, TR.icon('alert'), 'Could not load the vehicle history: ' + V.error, ui.button('Retry', null, () => load(true), 'text')) : null,
      !V.timeline ? h('p', { class: 'muted' }, 'Loading the vehicle history…') : V.tab === 'graph' ? graph() : V.tab === 'map' && TR.architecture ? TR.architecture.render() : V.tab === 'roadmap' ? roadmap() : V.tab === 'insights' ? insights() : history());
  }
  const fact = (label, value) => h('div', null, h('span', null, label), h('strong', null, value));

  // ------------------------------------------------------------------ graph
  /** History entries the graph can be compared with; the factory build is always offered when it exists. */
  function snapshotChoices() {
    const list = V.entries.filter((e) => e.hasSnapshot);
    if (V.snapshots.built && !list.some((e) => e.id === 'built')) list.push({ id: 'built', title: 'Built at the factory', at: V.builtAt });
    return list;
  }
  function graph() {
    const p = left().product.get();
    const then = compareProduct(), was = byName(then);
    const original = byName(left().product.getOriginal());
    const snapshots = snapshotChoices();
    const nodes = p.nodes.filter((n) => matchesQuery(n.name) || (n.softwareProducts || []).some((s) => matchesQuery(pkgName(s))) || legacyParts(n).some((x) => matchesQuery(x.label)));
    return h('div', { class: 'vh-graph-wrap' },
      h('div', { class: 'vh-toolbar' },
        h('label', { class: 's-search vh-search' }, TR.icon('search', 17), h('input', { placeholder: 'Find a computer or software', 'aria-label': 'Find a computer or software', value: V.query, key: 'vh-search', onInput: (e) => { V.query = e.target.value; TR.app.refreshSoon(); } })),
        h('label', { class: 'vh-compare' }, TR.icon('history', 17), 'Compare with ',
          h('select', { 'aria-label': 'Compare with an earlier state', value: V.compare, onChange: (e) => compareWith(e.target.value) },
            h('option', { value: '' }, 'Nothing (current only)'),
            left().product.dirty() ? h('option', { value: 'original', selected: V.compare === 'original' }, 'Before your proposal') : null,
            snapshots.map((e) => h('option', { value: e.id, selected: V.compare === e.id }, `${e.title} · ${ui.day(e.at)}`)))),
        legend()),
      then ? h('div', { class: 's-banner gh-banner' }, TR.icon('history'), h('span', null, 'Compared with ', h('strong', null, V.compare === 'original' ? 'the vehicle before your proposal' : (snapshots.find((e) => e.id === V.compare) || {}).title),
        ', like a code diff: ', h('code', { class: 'gh-was' }, '− earlier'), ' ', h('code', { class: 'gh-now' }, '+ now'), '. Unchanged values are plain.')) : null,
      h('div', { class: 'vh-graph', role: 'tree', 'aria-label': 'Vehicle structure: containment of computers, execution environments and software (not dependencies)' },
        h('div', { class: 'vh-root' }, TR.icon('truck', 24), h('strong', null, left().product.chassisString()), h('span', null, p.nodes.length + ' computers')),
        h('div', { class: 'vh-branches' }, nodes.length ? nodes.map((n) => nodeCard(n, was[n.name], original[n.name], !!then)) : h('p', { class: 'muted' }, 'Nothing matches “' + V.query + '”.'))),
      V.selected ? detailPanel(p.nodes.find((n) => n.name === V.selected)) : null);
  }

  function legend() {
    return h('div', { class: 'vh-legend', 'aria-label': 'Legend' },
      [['chip', 'T3 HPC computer'], ['cpu', 'ECU'], ['env', 'Execution environment'], ['package', 'Software']].map(([i, t]) => h('span', null, TR.icon(i, 15), t)),
      h('code', { class: 'gh-was' }, '− earlier'), h('code', { class: 'gh-now' }, '+ now'), h('span', { class: 'vh-mark proposal' }, 'In your proposal'),
      // What the lines mean: this tree shows containment (what is inside what), never dependencies between computers.
      h('span', { class: 'vh-legend-note', 'data-tip': 'Containment|Lines show what is inside what: vehicle → computer → execution environment → software. They are not verified dependencies; dependency checks appear in the validation findings.' }, TR.icon('info', 14), 'Lines show containment, not dependencies'));
  }

  function nodeCard(n, then, original, comparing) {
    const nodeChanged = comparing && (!then || then.versionName !== n.versionName);
    const proposed = original && original.versionName !== n.versionName;
    const thenPkgs = then ? pkgVersions(then) : {};
    const origPkgs = original ? pkgVersions(original) : {};
    return h('div', { class: ['vh-node', V.selected === n.name ? 'is-selected' : '', nodeChanged ? 'is-changed' : '', comparing && !then ? 'is-added' : ''], role: 'treeitem', 'aria-expanded': 'true' },
      h('button', { class: 'vh-node-head', onClick: () => { V.selected = V.selected === n.name ? null : n.name; TR.app.refresh(); }, 'aria-label': 'Show details for ' + n.name },
        h('span', { class: 'vh-node-icon' }, TR.icon(nodeIcon(n), 22)),
        h('span', { class: 'vh-node-name' }, h('strong', null, n.name), h('small', null, ARCH[n.electricalArchitecture] || 'ECU')),
        h('span', { class: 'vh-node-version' }, versus(n.versionName, then && then.versionName, nodeChanged),
          proposed ? h('em', { class: 'vh-mark proposal' }, 'proposal · was ' + original.versionName) : null)),
      isHpc(n)
        ? environments(n).map((env) => h('div', { class: 'vh-env' },
            h('div', { class: 'vh-env-head' }, TR.icon('env', 16), h('strong', null, env.name), env.logicalEcu ? h('small', null, env.logicalEcu) : null),
            env.items.map((s) => {
              const name = pkgName(s); const changed = comparing && thenPkgs[name] !== s.packageVersion; const prop = origPkgs[name] && origPkgs[name] !== s.packageVersion;
              return h('div', { class: ['vh-sw', changed ? 'is-changed' : '', matchesQuery(name) && V.query ? 'is-hit' : ''] }, TR.icon('package', 15), h('span', null, name),
                versus(s.packageVersion, thenPkgs[name], changed), prop ? h('em', { class: 'vh-mark proposal' }, 'proposal · was ' + origPkgs[name]) : null);
            })))
        : h('div', { class: 'vh-env' }, legacyParts(n).map((part) => {
            const before = then ? (legacyParts(then).find((x) => x.label === part.label) || {}).value : undefined;
            const changed = comparing && String(before) !== String(part.value);
            return h('div', { class: ['vh-sw', changed ? 'is-changed' : '', matchesQuery(part.label) && V.query ? 'is-hit' : ''] }, TR.icon('package', 15), h('span', null, part.label),
              versus(String(part.value), before == null ? '' : String(before), changed));
          })));
  }

  function detailPanel(n) {
    if (!n) return null;
    const road = (V.roadmap.nodes || []).find((r) => r.node === n.name);
    const events = V.entries.filter((e) => (e.changes || []).some((c) => c.node === n.name));
    const canEdit = session().canEdit !== false;
    return h('aside', { class: 'vh-detail', 'aria-label': n.name + ' details' },
      h('div', { class: 'vh-detail-head' }, h('span', { class: 'vh-node-icon' }, TR.icon(nodeIcon(n), 22)), h('div', null, h('h2', null, n.name), h('span', null, ARCH[n.electricalArchitecture] || 'ECU')),
        h('button', { class: 'icon-btn', 'aria-label': 'Close details', onClick: () => { V.selected = null; TR.app.refresh(); } }, TR.icon('close', 18))),
      h('dl', { class: 'vh-dl' },
        dt('Node template', (n.versionName || '—') + (n.nodeTemplateDocument ? ' · ' + n.nodeTemplateDocument.number : '')),
        dt('Status', n.nodeTemplateStatus || '—'), dt('ECU hardware', n.ecuHardware ? n.ecuHardware.number + (n.ecuHardware.serialNumber ? ' · ' + n.ecuHardware.serialNumber : '') : '—'),
        isHpc(n) ? dt('Logical ECU', (n.softwareProducts && n.softwareProducts[0] && n.softwareProducts[0].logicalEcu) || '—') : null),
      h('h3', null, 'Next versions'),
      road && road.upcoming.length ? h('ol', { class: 'vh-mini-road' }, road.upcoming.map((u) => h('li', { class: u.blockers.length ? 'is-blocked' : '' }, h('strong', null, u.versionName), ' ', statusChip(u.status), u.blockers.length ? h('div', { class: 'vh-blocker' }, TR.icon('lock', 14), u.blockers.join(' · ')) : null)))
        : h('p', { class: 'muted' }, 'No newer version in the catalog.'),
      h('h3', null, 'History of this computer'),
      events.length ? h('ul', { class: 'vh-mini-history' }, events.map((e) => h('li', null, h('strong', null, ui.day(e.at)), ' ', e.title, ' · ', e.actor.name))) : h('p', { class: 'muted' }, 'No changes recorded since it was built.'),
      h('div', { class: 'vh-detail-actions' },
        isHpc(n) && canEdit && TR.experience.nodeDetails ? ui.button('Edit logical ECU', 'sliders', () => TR.experience.nodeDetails(n)) : null,
        ui.button('Edit software', 'sliders', () => { TR.experience.page = null; TR.testRequest.page('software'); })));
  }
  const dt = (label, value) => [h('dt', null, label), h('dd', null, value)];
  function statusChip(status) {
    const tone = { Released: 'good', Introduced: 'simulation', 'Pre-release verification': 'warning', 'In progress': 'neutral' }[status] || 'neutral';
    return ui.chip(status, tone);
  }

  // ------------------------------------------------------------------ roadmap
  function roadmap() {
    const built = byName(V.snapshots.built);
    const canRun = session().canSimulate !== false && TR.t3services;
    return h('div', { class: 'vh-roadmap' },
      h('h2', null, 'Service packs'),
      (V.roadmap.servicePacks || []).length ? h('div', { class: 'vh-packs' }, V.roadmap.servicePacks.map((sp) => h('div', { class: 'vh-pack ' + (sp.state === 'Available' ? 'is-available' : '') },
        h('div', null, TR.icon('layers', 18), h('strong', null, sp.name)),
        ui.chip(sp.state, sp.state === 'Available' ? 'simulation' : sp.state === 'Already on it' ? 'good' : 'neutral'),
        h('p', null, sp.state === 'Available' ? 'Updates ' + sp.updates.join(', ') + '.' : sp.state === 'Already on it' ? 'Every computer is already on this pack or later.' : 'Does not cover ' + sp.notCovered.join(', ') + '.'),
        sp.state === 'Available' && canRun ? ui.button('Update to this service pack', 'arrow', () => { TR.experience.page = null; TR.testRequest.page(); TR.t3services.open(TR.enums.RequestType.ProductUpdateService); }, 'primary') : null)))
        : h('p', { class: 'muted' }, 'No service packs exist for this vehicle context.'),
      h('h2', null, 'Each computer, from build to future'),
      h('p', { class: 'muted' }, 'Green is released, blue introduced, amber in pre-release verification, grey in progress. A lock explains what blocks a version.'),
      h('div', { class: 'vh-lanes' }, (V.roadmap.nodes || []).map((r) => {
        const b = built[r.node];
        return h('div', { class: 'vh-lane' },
          h('div', { class: 'vh-lane-name' }, TR.icon(r.isHpc ? 'chip' : 'cpu', 18), h('strong', null, r.node)),
          h('ol', { class: 'vh-steps' },
            b && r.current && b.versionName !== r.current.versionName ? h('li', { class: 'vh-step past' }, h('small', null, 'As built'), h('strong', null, b.versionName)) : null,
            h('li', { class: 'vh-step now' }, h('small', null, 'Now'), h('strong', null, r.current ? r.current.versionName : 'Undocumented')),
            r.upcoming.map((u) => h('li', { class: ['vh-step', 'status-' + u.status.split(' ')[0].toLowerCase(), u.blockers.length ? 'is-blocked' : ''] },
              h('small', null, u.status + (u.introductionWeek ? ' · ' + week(u.introductionWeek) : '')), h('strong', null, u.versionName),
              u.blockers.map((x) => h('span', { class: 'vh-blocker' }, TR.icon('lock', 13), x))))));
      })));
  }

  // ------------------------------------------------------------------ insights (insights.js draws them)
  function insights() {
    if (V.hasMore && !V.loadingMore) loadAll();
    return TR.insights.render({
      loading: V.hasMore, entries: V.entries, built: V.snapshots.built, builtAt: V.builtAt, roadmap: V.roadmap, current: left().product.get(),
      onEntry: (id) => { V.tab = 'graph'; compareWith(id); },
      onNode: (name) => { V.tab = 'graph'; V.selected = name; TR.app.refresh(); },
    });
  }

  /** '202630' → 'week 30, 2026'. */
  const week = (w) => (/^\d{6}$/.test(w) ? `week ${Number(w.slice(4))}, ${w.slice(0, 4)}` : 'week ' + w);

  // ------------------------------------------------------------------ history (git-style graph)
  const isChange = (k) => ['Built', 'Delivered', 'Workshop', 'VdaRecord', 'VdaCommit'].includes(k);
  const filtering = () => V.history.kind !== 'all' || V.history.person !== 'all' || !!V.history.query.trim();
  function filteredHistory() {
    const f = V.history, q = f.query.trim().toLowerCase();
    return V.entries.filter((e) =>
      (f.kind === 'all' || (f.kind === 'changes' ? isChange(e.kind) : e.kind === f.kind)) &&
      (f.person === 'all' || e.actor.id === f.person) &&
      (!q || [e.title, e.summary, e.actor.name, ...(e.changes || []).flatMap((c) => [c.node, c.from, c.to, ...(c.packages || []).map((p) => p.name + ' ' + p.from + ' ' + p.to)])].join(' ').toLowerCase().includes(q)));
  }

  // Loads the next page when the end of the list comes within 300 px of the bottom of the window: on any scroll, and once
  // after each render in case the list is shorter than the window.
  function checkMore() {
    if (V.tab !== 'history' || !V.hasMore || V.loadingMore || filtering() || typeof document.querySelector !== 'function') return;
    const end = document.querySelector('.gh-more');
    if (end && end.getBoundingClientRect().top < (window.innerHeight || 800) + 300) loadMore();
  }
  if (typeof document.addEventListener === 'function') document.addEventListener('scroll', checkMore, { capture: true, passive: true });
  const watch = () => setTimeout(checkMore, 0);

  function history() {
    if (TR.help) TR.help.complete('history');
    const f = V.history;
    const set = (k, v) => { f[k] = v; TR.app.refresh(); };
    // Filters and search look at the whole history, so the rest of it is loaded first.
    if (filtering() && V.hasMore && !V.loadingMore) loadAll();
    const list = filtering() ? filteredHistory() : V.entries;
    const { rows, lanes } = G.layout(list, V.hasMore && !filtering());
    const people = V.timeline.people || [];
    const status = filtering() ? (V.hasMore ? `Searching all ${V.timeline.total} entries…` : `${list.length} of ${V.timeline.total} match`) : `${V.entries.length} of ${V.timeline.total} loaded`;
    const sentinel = h('li', { class: 'gh-more', 'aria-hidden': 'true' });
    if (V.hasMore && !filtering()) watch();
    return h('div', { class: 'vh-history' },
      people.length ? h('div', { class: 'vh-people' }, h('span', { class: 'muted' }, 'People'), people.map((p) => h('button', { class: ['vh-person', f.person === p.id ? 'is-on' : ''], onClick: () => set('person', f.person === p.id ? 'all' : p.id) },
        h('span', { class: 'vh-avatar' }, initials(p.name)), p.name, h('small', null, p.changes)))) : null,
      h('div', { class: 'vh-toolbar' },
        h('label', { class: 's-search vh-search' }, TR.icon('search', 17), h('input', { type: 'search', placeholder: 'Search history, computers or versions', 'aria-label': 'Search history', value: f.query, key: 'vh-history-search', onInput: (e) => { f.query = e.target.value; TR.app.refreshSoon(); }, onKeydown: (e) => { if (e.key === 'Escape') set('query', ''); } })),
        h('label', null, 'Show ', h('select', { 'aria-label': 'Kind of history entry', value: f.kind, onChange: (e) => set('kind', e.target.value) },
          [['all', 'Everything'], ['changes', 'Changes to the vehicle'], ['Kit', 'Kits'], ['Simulation', 'My simulations']].map(([v, t]) => h('option', { value: v, selected: f.kind === v }, t)))),
        h('span', { class: 'muted', role: 'status' }, status)),
      h('div', { class: 'gh-legend', 'aria-label': 'Graph legend' },
        h('span', null, h('i', { class: 'gh-key main' }), 'Changes to the vehicle'), h('span', null, h('i', { class: 'gh-key side' }), 'Simulations and kits, branching from the revision they started from'),
        h('span', null, h('i', { class: 'gh-key kit' }), 'Kit')),
      rows.length ? h('ol', { class: 'gh-graph', 'aria-label': 'Vehicle history, newest first' },
        rows.map((r) => row(r, lanes)), V.loadingMore ? G.skeleton() : null, V.hasMore && !filtering() ? sentinel : null)
        : h('p', { class: 'muted' }, V.hasMore ? 'Loading…' : 'No history entries match.'),
      V.hasMore && !filtering()
        ? h('div', { class: 'gh-end' }, ui.button(V.loadingMore ? 'Loading older history…' : 'Load older history', 'history', () => loadMore(), 'secondary', { disabled: V.loadingMore }))
        : h('div', { class: 'gh-end muted' }, TR.icon('factory', 16), 'Beginning of the history'));
  }
  const initials = (name) => String(name).replace(/\(.*\)/, '').trim().split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();

  function row(r, lanes) {
    const e = r.entry, kind = KINDS[e.kind] || { icon: 'clock', label: e.kind, verb: '' };
    const open = V.history.open.has(e.id), hasChanges = (e.changes || []).length > 0;
    const toggle = () => { if (open) V.history.open.delete(e.id); else V.history.open.add(e.id); TR.app.refresh(); };
    const relation = [
      e.base ? 'started from ' + titleOf(e.base) : null,
      e.mergedInto ? 'committed as ' + titleOf(e.mergedInto) : null,
      e.from ? 'from ' + titleOf(e.from) : null,
    ].filter(Boolean).join(' · ');
    const isCurrent = e.id === V.timeline.latestSnapshotEntry;
    const status = e.source && e.source.status;
    return h('li', { class: ['gh-row', 'kind-' + e.kind.toLowerCase(), r.lane ? 'is-side' : 'is-main'], 'data-entry': e.id, tabindex: '0', 'aria-label': `${e.title}, ${e.actor.name}, ${ui.when(e.at)}`,
      onKeydown: (ev) => { if (ev.key === 'Enter' && ev.target === ev.currentTarget && hasChanges) toggle(); } },
      G.gutter(r, lanes), h('span', { class: 'gh-gutter-space', style: { width: G.gutterWidth(lanes) + 'px' } }),
      h('div', { class: 'gh-card' },
        h('div', { class: 'gh-head' },
          hasChanges ? h('button', { class: ['gh-toggle', open ? 'is-open' : ''], 'aria-expanded': String(open), 'aria-label': (open ? 'Hide' : 'Show') + ' the changes in ' + e.title, onClick: toggle }, TR.icon('right', 16)) : h('span', { class: 'gh-toggle-space' }),
          h('span', { class: 'gh-kind-icon' }, TR.icon(kind.icon, 16)),
          h('strong', { class: 'gh-title' }, e.title),
          e.revision ? h('span', { class: 'gh-tag' }, TR.icon('database', 12), 'rev ' + e.revision) : null,
          isCurrent ? h('span', { class: 'gh-tag is-head' }, 'Current') : null,
          status ? ui.chip(status, status === 'Ready' ? 'good' : 'warning') : null,
          e.onlyYou ? ui.chip('Only you') : null,
          h('span', { class: 'gh-spacer' }),
          hasChanges ? h('button', { class: 'gh-stat-btn', onClick: toggle, 'aria-label': 'Show the changes' }, G.statView(e.changes)) : null),
        h('div', { class: 'gh-meta' }, h('span', { class: 'vh-avatar small' }, initials(e.actor.name)), h('strong', null, e.actor.name), h('span', null, kind.verb),
          h('time', { datetime: e.at, title: ui.when(e.at) }, ui.when(e.at))),
        relation ? h('div', { class: 'gh-relation' }, TR.icon('route', 13), relation) : null,
        h('p', { class: 'gh-summary' }, e.summary),
        open && hasChanges ? G.diff(e.changes) : null,
        e.hasSnapshot ? h('div', { class: 'gh-actions' }, ui.button('View this configuration', 'map', () => { V.tab = 'graph'; compareWith(e.id); }, 'text')) : null));
  }

  TR.pages.register({
    id: 'vehicle', title: 'Vehicle',
    crumbs: () => [{ label: 'Vehicle', open: () => { V.tab = 'graph'; TR.app.refresh(); } }].concat(left().product.loaded() ? [{ label: left().product.chassisString() }, { label: { graph: 'Graph', map: 'Map', roadmap: 'Roadmap', history: 'History', insights: 'Insights' }[V.tab] }] : []),
    render,
  });
  TR.pages.ui.slashFocus('.vh-search input');
  // A commit or new request changes the history: reload it the next time the page renders.
  const forget = () => { V.timeline = null; V.entries = []; V.hasMore = false; };
  const commit = TR.Pane.prototype.prepareVdaUpdate;
  if (commit) TR.Pane.prototype.prepareVdaUpdate = function (...args) { forget(); return commit.apply(this, args); };
  const run = TR.request.runRequest;
  TR.request.runRequest = async (...args) => { const r = await run(...args); forget(); return r; };
  TR.vehiclePage = { V, load, loadMore, loadAll, compareWith, filteredHistory, environments, legacyParts, PAGE };
})();
