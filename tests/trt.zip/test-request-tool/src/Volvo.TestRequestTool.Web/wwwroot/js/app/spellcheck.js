/* Spelling check for free-text fields: wavy underlines under words that are not in the dictionary, and a click on an
 * underlined word (or Ctrl+. with the caret in it) offers corrections, "Ignore once" and "Add to my dictionary".
 *
 *   Fields      every <textarea> and any <input data-spell="on">, except fields marked data-spell="off", read-only fields
 *               and fields that hold XML or JSON. Technical identifiers (chassis, VIN, part numbers) are never checked.
 *   Words       a bundled English word list (SCOWL, /spell/words-en.txt, loaded only when needed), the application's own
 *               terms, and your personal dictionary. Words with digits, ALL-CAPS abbreviations and words of one letter are
 *               skipped. Suggestions are the dictionary words one or two edits away, the most common first. No AI.
 *   Yours       the personal dictionary is per user, kept on the server (/api/v1/me/preferences/dictionary) and in this
 *               browser; reset it any time in Settings → Workspace → Spelling.
 *   On or off   Settings → Workspace → Spelling check, or per field with data-spell="off".
 *   Access      the field announces how many possible mistakes it has; the correction menu works with the arrow keys,
 *               Enter and Escape (focus and the caret return to the field). The browser's own spelling squiggles are
 *               turned off on checked fields so they are not drawn twice. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));
  const TERMS = ['vda', 'edb', 'cbr', 'ecu', 'ecus', 'hpc', 'ntp', 'kax', 'vespa', 'dependix', 'chassis', 'snote', 'snotes', 'tea', 'pus', 'apu', 'vcm', 'cgw', 'tecu', 'ems', 'ebs', 'logical', 'workflow', 'workflows',
    'dashboard', 'login', 'logout', 'signin', 'checkbox', 'dropdown', 'toolbar', 'backend', 'frontend', 'api', 'apis', 'json', 'xml', 'csv', 'url', 'urls', 'email', 'online', 'offline', 'reupload', 'revalidate', 'revalidation',
    'subfolder', 'timestamp', 'timestamps', 'metadata', 'config', 'configs', 'repo', 'ok', 'okay', 'eg', 'ie', 'etc', 'ui', 'ux', 'sw', 'hw'];
  const SP = { words: null, rank: null, loading: null, custom: new Set(), once: new WeakMap(), menu: null, overlays: new Map(), synced: false };
  const userKey = () => 'trstudio.' + ((TR.backend && TR.backend.session && TR.backend.session.userId) || 'user') + '.spell.dictionary';
  const enabled = () => (!TR.prefs || TR.prefs.get('spellcheck') !== false) && (!TR.features || TR.features.on('spellcheck'));

  // ------------------------------------------------------------------ pure helpers (tests/frontend/spellcheck.cjs)
  /** Words with their positions; letters and apostrophes inside words. */
  function tokenize(text) {
    const out = [], re = /[\p{L}][\p{L}'’]*/gu;
    let m;
    while ((m = re.exec(text))) out.push({ word: m[0].replace(/['’]+$/, ''), start: m.index, end: m.index + m[0].replace(/['’]+$/, '').length });
    return out;
  }
  /** Skip what is not prose: one letter, ALL CAPS (abbreviations), words touching digits, inside URLs or e-mail addresses. */
  let spanText = null, spanList = [];
  /** URLs and e-mail addresses in a text, skipped as a whole. */
  function spans(text) {
    if (text !== spanText) { spanText = text; spanList = [...text.matchAll(/(?:https?:\/\/|www\.)\S+|[^\s@]+@[^\s@]+\.[^\s@]+/g)].map((m) => [m.index, m.index + m[0].length]); }
    return spanList;
  }
  function shouldCheck(token, text) {
    const w = token.word;
    if (spans(text).some(([a, b]) => token.start >= a && token.end <= b)) return false;
    if (w.length < 2 || (w === w.toUpperCase() && /\p{L}{2,}/u.test(w))) return false;
    const before = text[token.start - 1] || '', after = text[token.end] || '';
    if (/[0-9_/@.\\:-]/.test(before) || /[0-9_/@\\]/.test(after)) return false;
    if (/[a-z][A-Z]/.test(w)) return false;                          // camelCase identifiers
    return true;
  }
  function known(word, dict, custom) {
    const w = word.toLowerCase().replace(/’/g, "'");
    if (dict.has(w) || custom.has(w)) return true;
    if (w.endsWith("'s") && (dict.has(w.slice(0, -2)) || custom.has(w.slice(0, -2)))) return true;
    return false;
  }
  /** Misspelled tokens in a text. */
  function check(text, dict, custom) { return tokenize(text).filter((tk) => shouldCheck(tk, text) && !known(tk.word, dict, custom)); }
  const LETTERS = 'abcdefghijklmnopqrstuvwxyz';
  function edits1(w) {
    const out = new Set();
    for (let i = 0; i <= w.length; i++) {
      const a = w.slice(0, i), b = w.slice(i);
      if (b) out.add(a + b.slice(1));                                   // delete
      if (b.length > 1) out.add(a + b[1] + b[0] + b.slice(2));         // transpose
      for (const c of LETTERS) { if (b) out.add(a + c + b.slice(1)); out.add(a + c + b); }   // replace, insert
    }
    return out;
  }
  /** Up to `limit` corrections, closest first, then most common; keeps the word's capitalisation. */
  function suggest(word, dict, rank, limit = 5) {
    const w = word.toLowerCase(), found = new Map();
    const one = edits1(w);
    for (const c of one) if (dict.has(c)) found.set(c, 1);
    if (found.size < limit && w.length <= 12) for (const e of one) for (const c of edits1(e)) if (dict.has(c) && !found.has(c)) found.set(c, 2);
    const cap = (s) => (word[0] === word[0].toUpperCase() ? s[0].toUpperCase() + s.slice(1) : s);
    return [...found.entries()].sort((a, b) => a[1] - b[1] || (rank.get(a[0]) ?? 1e9) - (rank.get(b[0]) ?? 1e9)).slice(0, limit).map(([c]) => cap(c));
  }

  // ------------------------------------------------------------------ dictionary loading and the personal dictionary
  function load() {
    if (SP.words || SP.loading) return SP.loading;
    SP.loading = fetch('/spell/words-en.txt').then((r) => (r.ok ? r.text() : '')).then((text) => {
      const list = text.split(/\r?\n/).filter(Boolean);   // either line ending: a Windows checkout has CRLF
      SP.words = new Set(list.concat(TERMS)); SP.rank = new Map(list.map((w, i) => [w, i]));
      return SP.words;
    }).catch(() => { SP.words = new Set(TERMS); SP.rank = new Map(); return SP.words; });
    syncCustom();
    return SP.loading;
  }
  function readCustom() { try { SP.custom = new Set((TR.util.store.get(userKey(), []) || []).map((w) => w.toLowerCase())); } catch (e) { SP.custom = new Set(); } }
  async function syncCustom() {
    readCustom();
    if (SP.synced || typeof location === 'undefined' || !/^https?:$/.test(location.protocol)) return;
    SP.synced = true;
    try { const r = await fetch('/api/v1/me/preferences'); if (r.ok) { const p = await r.json(); if (Array.isArray(p.dictionary)) { p.dictionary.forEach((w) => SP.custom.add(String(w).toLowerCase())); TR.util.store.set(userKey(), [...SP.custom]); refreshAll(); } } } catch (e) { /* the browser copy still works */ }
  }
  let saveTimer = null;
  function addWord(word) {
    SP.custom.add(word.toLowerCase()); TR.util.store.set(userKey(), [...SP.custom]);
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => fetch('/api/v1/me/preferences/dictionary', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ words: [...SP.custom] }) }).catch(() => {}), 400);
    refreshAll();
  }
  function removeWord(word) { SP.custom.delete(word.toLowerCase()); TR.util.store.set(userKey(), [...SP.custom]); fetch('/api/v1/me/preferences/dictionary', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ words: [...SP.custom] }) }).catch(() => {}); refreshAll(); TR.app.refresh(); }
  async function resetDictionary() { SP.custom = new Set(); TR.util.store.set(userKey(), []); try { await fetch('/api/v1/me/preferences/dictionary', { method: 'DELETE' }); } catch (e) { /* local reset stands */ } refreshAll(); TR.app.refresh(); TR.notify && TR.notify.toast(t('Your dictionary is empty again.'), 'success'); }

  // ------------------------------------------------------------------ overlays
  const eligible = (el) => el && (el.tagName === 'TEXTAREA' || (el.tagName === 'INPUT' && el.getAttribute('data-spell') === 'on'))
    && el.getAttribute('data-spell') !== 'off' && !el.readOnly && !el.disabled && !/^\s*[<{[]/.test(el.value || '') && !(el.className || '').match(/xml|json|code/i);
  const COPY = ['fontFamily', 'fontSize', 'fontWeight', 'fontStyle', 'letterSpacing', 'lineHeight', 'textTransform', 'wordSpacing', 'textIndent', 'textAlign', 'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft',
    'borderTopWidth', 'borderRightWidth', 'borderBottomWidth', 'borderLeftWidth', 'boxSizing', 'tabSize', 'direction'];
  function overlayFor(el) {
    let o = SP.overlays.get(el);
    if (!o) {
      o = { box: h('div', { class: 'sp-mirror', 'aria-hidden': 'true' }), note: h('span', { class: 'nv-sr', id: 'sp-' + Math.random().toString(36).slice(2) }), bad: [] };
      document.body.append(o.box, o.note);
      SP.overlays.set(el, o);
      const prev = el.getAttribute('aria-describedby');
      el.setAttribute('aria-describedby', (prev ? prev + ' ' : '') + o.note.id);
      el.setAttribute('spellcheck', 'false');   // the browser's own squiggles would be drawn twice
      el.addEventListener('input', () => schedule(el));
      el.addEventListener('scroll', () => place(el));
      el.addEventListener('click', () => { const tk = at(el); if (tk) openMenu(el, tk); else closeMenu(false); });
      el.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && e.key === '.') { const tk = at(el); if (tk) { e.preventDefault(); openMenu(el, tk, true); } } });
    }
    return o;
  }
  const esc = (s) => s.replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
  function draw(el) {
    if (!SP.words || !el.isConnected) return;
    const o = overlayFor(el), text = el.value || '', ignored = SP.once.get(el) || new Set();
    o.bad = check(text, SP.words, SP.custom).filter((tk) => !ignored.has(tk.word.toLowerCase()));
    let html = '', last = 0;
    o.bad.forEach((tk, i) => { html += esc(text.slice(last, tk.start)) + `<mark class="sp-bad" data-i="${i}">${esc(text.slice(tk.start, tk.end))}</mark>`; last = tk.end; });
    o.box.innerHTML = html + esc(text.slice(last)) + (el.tagName === 'TEXTAREA' ? '\n' : '');
    o.note.textContent = o.bad.length ? t('{n} possible spelling mistakes. Put the cursor in a word and press Ctrl+. for corrections.', { n: o.bad.length }) : '';
    place(el);
  }
  function place(el) {
    const o = SP.overlays.get(el);
    if (!o) return;
    const r = el.getBoundingClientRect(), cs = getComputedStyle(el);
    if (!r.width || cs.visibility === 'hidden' || cs.display === 'none') { o.box.style.display = 'none'; return; }
    COPY.forEach((p) => { o.box.style[p] = cs[p]; });
    Object.assign(o.box.style, { display: 'block', left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: r.height + 'px', whiteSpace: el.tagName === 'TEXTAREA' ? 'pre-wrap' : 'pre', overflowWrap: el.tagName === 'TEXTAREA' ? 'break-word' : 'normal' });
    o.box.scrollTop = el.scrollTop; o.box.scrollLeft = el.scrollLeft;
  }
  const timers = new WeakMap();
  function schedule(el) { clearTimeout(timers.get(el)); timers.set(el, setTimeout(() => draw(el), 250)); }
  function refreshAll() { for (const el of SP.overlays.keys()) { if (el.isConnected) draw(el); else drop(el); } }
  function drop(el) { const o = SP.overlays.get(el); if (o) { o.box.remove(); o.note.remove(); SP.overlays.delete(el); } }
  /** The misspelled word at the caret, if any. */
  function at(el) { const o = SP.overlays.get(el); if (!o || !o.bad.length) return null; const p = el.selectionStart; return o.bad.find((tk) => p >= tk.start && p <= tk.end) || null; }

  // ------------------------------------------------------------------ the correction menu
  function closeMenu(returnFocus) {
    if (!SP.menu) return;
    const { box, el, caret } = SP.menu; box.remove(); SP.menu = null;
    if (returnFocus && el.isConnected) { el.focus(); el.setSelectionRange(caret, caret); }
  }
  function openMenu(el, tk, fromKeyboard) {
    closeMenu(false);
    const o = SP.overlays.get(el), mark = o.box.querySelector(`mark[data-i="${o.bad.indexOf(tk)}"]`);
    const rect = mark ? mark.getBoundingClientRect() : el.getBoundingClientRect();
    const choices = suggest(tk.word, SP.words, SP.rank);
    const apply = (word) => { el.focus(); el.setRangeText(word, tk.start, tk.end, 'end'); el.dispatchEvent(new Event('input', { bubbles: true })); closeMenu(false); draw(el); };
    const items = [
      ...choices.map((c) => [c, () => apply(c), 'sp-fix']),
      [t('Ignore once'), () => { const s = SP.once.get(el) || new Set(); s.add(tk.word.toLowerCase()); SP.once.set(el, s); closeMenu(true); draw(el); }, ''],
      [t('Add “{w}” to my dictionary', { w: tk.word }), () => { addWord(tk.word); closeMenu(true); }, ''],
    ];
    const box = h('div', { class: 'ap-menu sp-menu', role: 'menu', 'aria-label': t('Spelling: {w}', { w: tk.word }), style: { left: Math.min(innerWidth - 260, rect.left) + 'px', top: rect.bottom + 6 + 'px' },
      onKeydown: (e) => {
        const all = [...box.querySelectorAll('[role="menuitem"]')], i = all.indexOf(document.activeElement);
        if (e.key === 'ArrowDown') { e.preventDefault(); all[(i + 1) % all.length].focus(); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); all[(i - 1 + all.length) % all.length].focus(); }
        else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); closeMenu(true); }
        else if (e.key === 'Tab') closeMenu(false);
      } },
      h('div', { class: 'sp-head' }, choices.length ? t('Did you mean') : t('No suggestions for “{w}”', { w: tk.word })),
      items.map(([label, run, cls]) => h('button', { type: 'button', role: 'menuitem', class: ['ap-menu-item', cls], tabindex: '-1', onClick: run }, label)));
    document.body.appendChild(box);
    SP.menu = { box, el, caret: el.selectionStart };
    if (fromKeyboard) setTimeout(() => { const f = box.querySelector('[role="menuitem"]'); if (f) f.focus(); }, 0);
  }

  // ------------------------------------------------------------------ wiring
  if (typeof document.addEventListener === 'function' && typeof MutationObserver === 'function') {
    document.addEventListener('focusin', (e) => { const el = e.target; if (!enabled() || !eligible(el)) return; load().then(() => draw(el)); }, true);
    // Typing also starts it, in case the field had focus before this script ran.
    document.addEventListener('input', (e) => { const el = e.target; if (!enabled() || !eligible(el) || SP.overlays.has(el)) return; load().then(() => draw(el)); }, true);
    document.addEventListener('mousedown', (e) => { if (SP.menu && !SP.menu.box.contains(e.target) && e.target !== SP.menu.el) closeMenu(false); }, true);
    let pending = false;
    const sweep = () => { pending = false; for (const el of [...SP.overlays.keys()]) if (!el.isConnected || !enabled()) drop(el); else place(el); };
    new MutationObserver(() => { if (!pending) { pending = true; requestAnimationFrame(sweep); } }).observe(document.body || document.documentElement, { childList: true, subtree: true });
    addEventListener('scroll', () => { if (!pending) { pending = true; requestAnimationFrame(sweep); } }, true);
    addEventListener('resize', () => { if (!pending) { pending = true; requestAnimationFrame(sweep); } });
  }
  TR.spell = { tokenize, shouldCheck, check, suggest, edits1, known, load, addWord, removeWord, resetDictionary, custom: () => [...SP.custom].sort(), SP, TERMS };
})();
