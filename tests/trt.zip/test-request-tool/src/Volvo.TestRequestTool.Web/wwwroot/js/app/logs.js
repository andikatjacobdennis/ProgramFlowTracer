/* Logs & diagnostics: search, correlate and investigate (server: /api/v1/diagnostics/events, LogEndpoints.cs).
 * Administrators see every captured entry; everyone else sees the events of their own requests and reviews ("Scoped to
 * your authorised records"). Entries are redacted on the server before they are stored (tokens, secrets, e-mail).
 *
 *   Search      one box across every column ("/" focuses it); a request filter chip (REQ-…, id or trace id), service and
 *               severity chips; time range; More filters (levels, per-column text, refresh interval, columns).
 *   Live        new events are read every few seconds while on; Pause ingestion stops it; selecting an event pauses
 *               auto-scroll until Jump to latest.
 *   Analytics   counts, events over time by level and the top error groups (collapsible).
 *   Details     Overview (request, trace and span ids with copy, timestamp in your zone and UTC, duration, attempt,
 *               revision, what it means) and Structured data (every field). Open trace timeline, Related events, Open request.
 *   Saved views your named sets of filters, kept in this browser. Export sanitised logs as CSV or JSON.
 * The page never opens a dialog. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));
  const NS = 'http://www.w3.org/2000/svg';
  const svg = (tag, attrs = {}, kids = []) => { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs)) if (v != null) e.setAttribute(k, String(v)); [].concat(kids).filter(Boolean).forEach((k) => e.appendChild(typeof k === 'string' ? document.createTextNode(k) : k)); return e; };
  const LEVELS = ['Critical', 'Error', 'Warning', 'Information', 'Debug', 'Trace'];
  const SHORT = { Critical: 'CRIT', Error: 'ERROR', Warning: 'WARN', Information: 'INFO', Debug: 'DEBUG', Trace: 'TRACE' };
  const LEVEL_ICON = { Critical: 'alert', Error: 'alert', Warning: 'alert', Information: 'info', Debug: 'code', Trace: 'code' };
  const RANGES = [['15m', 'Last 15 minutes', 15], ['30m', 'Last 30 minutes', 30], ['1h', 'Last hour', 60], ['6h', 'Last 6 hours', 360], ['24h', 'Last 24 hours', 1440], ['all', 'All time', 0]];
  const COLUMNS = [['time', 'Time'], ['level', 'Level'], ['service', 'Service'], ['message', 'Message'], ['request', 'Request'], ['category', 'Source'], ['trace', 'Trace id']];
  const store = (k, d) => { try { return TR.util.store ? TR.util.store.get('trstudio.logs.' + k, d) : d; } catch (e) { return d; } };
  const save = (k, v) => { try { if (TR.util.store) TR.util.store.set('trstudio.logs.' + k, v); } catch (e) { /* storage blocked */ } };
  const L = {
    data: null, scoped: false, error: null, loading: false, levels: new Set(store('levels', LEVELS.slice(0, 4))), range: store('range', '30m'),
    q: '', request: '', service: '', category: '', message: '', exception: '', path: '', sort: 'time', dir: 'desc', take: 50,
    columns: new Set(store('columns', ['time', 'level', 'service', 'message', 'request'])), live: store('live', true), every: store('every', 5),
    selected: null, tab: 'overview', menu: null, timer: null, newSince: 0, analytics: store('analytics', true), views: store('views', []), naming: false, viewName: '', paramSeen: null,
  };

  function params() {
    const q = new URLSearchParams({ sort: L.sort, dir: L.dir, skip: '0', take: String(L.take) });
    if (L.levels.size !== LEVELS.length) q.set('levels', [...L.levels].join(','));
    for (const k of ['q', 'request', 'service', 'category', 'message', 'exception', 'path']) if (L[k]) q.set(k, L[k]);
    const r = RANGES.find((x) => x[0] === L.range);
    if (r && r[2]) q.set('from', new Date(Date.now() - r[2] * 60000).toISOString());
    return q.toString();
  }
  async function load(quiet) {
    if (L.loading) return;
    L.loading = true;
    if (!quiet) TR.app.refresh();
    try {
      const prev = L.data ? L.data.lastId : 0;
      const r = await TR.pages.ui.api('/diagnostics/events?' + params());
      L.data = r.result; L.scoped = r.scoped;
      L.newSince = quiet && prev && L.selected ? Math.max(0, L.data.lastId - prev) : 0;
      L.error = null;
    } catch (e) { L.error = e.message; }
    L.loading = false;
    TR.app.refresh();
  }
  const reload = () => { load(); };
  let debounce = null;
  const typed = (k) => (e) => { L[k] = e.target.value; clearTimeout(debounce); debounce = setTimeout(reload, 300); };

  // Live ingestion: read the current view every few seconds while the page is open, visible and not paused by a selection.
  function schedule() {
    clearInterval(L.timer); L.timer = null;
    if (!L.live) return;
    L.timer = setInterval(() => {
      if (TR.pages.current && TR.pages.current() !== 'logs') { clearInterval(L.timer); L.timer = null; return; }
      if (!document.hidden) load(true);
    }, Math.max(2, L.every) * 1000);
  }

  // ------------------------------------------------------------------ explanation (exported for tests)
  /** A short "what this means" for an event, from its service, level and fields. */
  function meaning(e) {
    const f = e.fields || {};
    if (e.level === 'Error' || e.level === 'Critical') return e.service === 'Worker' ? t('The attempt did not finish. Your input is kept; the job can be retried.') : t('Something failed on the server. The entry and its trace id help support find the cause.');
    if (e.service === 'Compatibility' && e.level === 'Warning') return t('A compatibility rule found something to review for this proposal. Review the validation finding before proceeding.');
    if (e.service === 'Parameters' && e.level === 'Warning') return t('A parameter check found something to review. Open the findings to see which parameter.');
    if (e.service === 'Integration') return t('The request called an integration service; its time counts as an external call.');
    if (e.service === 'Review') return t('A step of the review and approval of this request.');
    if (f.stage === 'authorise') return t('Access to every vehicle was checked and the stored configurations were loaded.');
    if (e.service === 'Workspace') return t('The result and its evidence were saved; nothing was sent to a vehicle.');
    if (e.level === 'Warning') return t('Worth a look: the stage finished but found something to review.');
    return t('Routine progress of the request.');
  }

  // ------------------------------------------------------------------ pieces
  const ui = () => TR.pages.ui;
  const badge = (l) => h('span', { class: 'lg-badge lv-' + l.toLowerCase() }, TR.icon(LEVEL_ICON[l] || 'info', 13), SHORT[l] || l);
  function zoneTime(at, utc) {
    const p = TR.culture ? TR.culture.active() : {};
    try { return new Intl.DateTimeFormat(utc ? 'en-GB' : p.language, { timeZone: utc ? 'UTC' : p.timeZone, hour: '2-digit', minute: '2-digit', second: '2-digit', fractionalSecondDigits: 3, hour12: false }).format(new Date(at)); } catch (e) { return String(at).slice(11, 23); }
  }
  function fullTime(at) {
    try { return new Intl.DateTimeFormat('en-GB', { timeZone: 'UTC', day: 'numeric', month: 'short', year: 'numeric' }).format(new Date(at)) + ' · ' + zoneTime(at, true) + ' UTC'; } catch (e) { return at; }
  }
  const zoneName = () => { try { return (TR.culture && TR.culture.active().timeZone) || Intl.DateTimeFormat().resolvedOptions().timeZone; } catch (e) { return ''; } };
  function chart(d) {
    const W = 760, H = 150, n = d.histogram.length;
    if (!n) return h('p', { class: 'muted' }, t('No events in this range.'));
    const total = (b) => LEVELS.reduce((a, l) => a + (b.counts[l] || 0), 0);
    const max = Math.max(1, ...d.histogram.map(total));
    const from = new Date(d.from).getTime(), span = Math.max(1, new Date(d.to).getTime() - from), bw = Math.max(4, (W - 50) * (d.bucketSeconds * 1000) / span - 3);
    const bars = d.histogram.map((b) => {
      const x = 40 + (W - 50) * (new Date(b.at).getTime() - from) / span;
      let y = H - 22;
      const parts = LEVELS.slice().reverse().filter((l) => b.counts[l]).map((l) => { const hh = (b.counts[l] / max) * (H - 36); y -= hh; return svg('rect', { x, y, width: bw, height: Math.max(1, hh), class: 'lg-bar lv-' + l.toLowerCase(), rx: 1.5 }); });
      return svg('g', {}, parts.concat(svg('title', {}, `${zoneTime(b.at)} · ` + LEVELS.filter((l) => b.counts[l]).map((l) => `${b.counts[l]} ${t(l).toLowerCase()}`).join(', '))));
    });
    const ticks = [0, 0.5, 1].map((f) => [svg('line', { x1: 40, x2: W - 10, y1: H - 22 - f * (H - 36), y2: H - 22 - f * (H - 36), class: 'hl-grid' }), svg('text', { x: 34, y: H - 18 - f * (H - 36), class: 'hl-axis', 'text-anchor': 'end' }, String(Math.round(max * f)))]);
    const xs = [0, 0.25, 0.5, 0.75, 1].map((f) => svg('text', { x: 40 + f * (W - 50), y: H - 4, class: 'hl-axis', 'text-anchor': f === 0 ? 'start' : f === 1 ? 'end' : 'middle' }, zoneTime(new Date(from + f * span)).slice(0, 5)));
    return svg('svg', { viewBox: `0 0 ${W} ${H}`, class: 'lg-chart', role: 'img', 'aria-label': t('Events over time by level: {n} in range', { n: d.total }) }, [].concat(ticks.flat(), xs, bars));
  }
  function errorGroups(d) {
    if (!d.errorGroups.length) return h('p', { class: 'muted' }, t('No errors or warnings in this range.'));
    const max = Math.max(...d.errorGroups.map((g) => g.count));
    return h('div', { class: 'lg-groups' }, d.errorGroups.map((g) => h('button', { class: 'lg-group', 'data-tip': g.service + '|' + g.message, onClick: () => { L.q = g.message.replace(/[#…].*$/, '').trim().slice(0, 40); reload(); } },
      h('span', { class: 'lg-group-name' }, g.message), h('span', { class: 'lg-group-track' }, h('i', { class: 'lv-' + g.level.toLowerCase(), style: { width: (100 * g.count) / max + '%' } })), h('strong', null, String(g.count)))));
  }
  const menuBtn = (id, label, icon) => h('button', { class: 's-btn secondary lg-menu-btn', 'aria-haspopup': 'true', 'aria-expanded': String(L.menu === id), onClick: (e) => { e.stopPropagation(); L.menu = L.menu === id ? null : id; TR.app.refresh(); } }, icon ? TR.icon(icon, 16) : null, label, TR.icon('chevron', 13));
  function rangeMenu() {
    const cur = RANGES.find((r) => r[0] === L.range) || RANGES[1];
    return h('div', { class: 'lg-menu-wrap' }, menuBtn('range', t(cur[1]), 'clock'),
      L.menu === 'range' ? h('div', { class: 'ap-menu lg-menu', role: 'menu', onClick: (e) => e.stopPropagation() }, RANGES.map(([k, l]) => h('button', { role: 'menuitemradio', 'aria-checked': String(L.range === k), onClick: () => { L.range = k; save('range', k); L.menu = null; reload(); } }, L.range === k ? TR.icon('check', 14) : h('span', { class: 'lg-sp' }), t(l)))) : null);
  }
  function moreMenu() {
    const services = L.data ? L.data.services : [];
    return h('div', { class: 'lg-menu-wrap' }, menuBtn('more', t('More filters'), 'sliders'),
      L.menu === 'more' ? h('div', { class: 'ap-menu lg-menu lg-filters-menu', onClick: (e) => e.stopPropagation() },
        h('fieldset', null, h('legend', null, t('Severity')), LEVELS.map((l) => h('label', { class: 'lg-check' }, h('input', { type: 'checkbox', checked: L.levels.has(l), onChange: (e) => { if (e.target.checked) L.levels.add(l); else L.levels.delete(l); save('levels', [...L.levels]); reload(); } }), badge(l), h('small', { class: 'muted' }, L.data ? String(L.data.levels[l] || 0) : ''))),
          h('div', { class: 'ap-menu-actions' }, ui().button(t('All'), null, () => { L.levels = new Set(LEVELS); save('levels', LEVELS); reload(); }, 'text'), ui().button(t('Problems only'), 'alert', () => { L.levels = new Set(['Critical', 'Error', 'Warning']); save('levels', [...L.levels]); reload(); }, 'text'))),
        h('fieldset', null, h('legend', null, t('Service')), h('select', { 'aria-label': t('Service'), onChange: (e) => { L.service = e.target.value; reload(); } }, [h('option', { value: '' }, t('All services'))].concat(services.map((s) => h('option', { value: s.service, selected: L.service === s.service }, `${s.service} (${s.count})`))))),
        h('fieldset', { class: 'lg-colfilters' }, h('legend', null, t('Column contains')),
          [['category', 'Source'], ['message', 'Message'], ['exception', 'Exception'], ['path', 'Path']].map(([k, l]) => h('input', { placeholder: t(l), value: L[k], 'aria-label': t('{c} contains', { c: t(l) }), onInput: typed(k) }))),
        h('fieldset', null, h('legend', null, t('Columns')), COLUMNS.map(([k, l]) => h('label', { class: 'lg-check' }, h('input', { type: 'checkbox', checked: L.columns.has(k), disabled: k === 'message', onChange: (e) => { if (e.target.checked) L.columns.add(k); else L.columns.delete(k); save('columns', [...L.columns]); TR.app.refresh(); } }), t(l)))),
        h('fieldset', null, h('legend', null, t('Live refresh every')), h('select', { 'aria-label': t('Refresh every'), onChange: (e) => { L.every = Number(e.target.value); save('every', L.every); schedule(); } }, [2, 5, 10, 30, 60].map((s) => h('option', { value: s, selected: L.every === s }, s < 60 ? s + ' s' : '1 min'))))) : null);
  }
  function viewsMenu() {
    const keep = () => ({ q: L.q, request: L.request, service: L.service, levels: [...L.levels], range: L.range, category: L.category, message: L.message, exception: L.exception, path: L.path });
    const apply = (v) => { Object.assign(L, { q: v.q || '', request: v.request || '', service: v.service || '', range: v.range || '30m', category: v.category || '', message: v.message || '', exception: v.exception || '', path: v.path || '' }); L.levels = new Set(v.levels || LEVELS.slice(0, 4)); L.menu = null; reload(); };
    return h('div', { class: 'lg-menu-wrap' }, menuBtn('views', t('Saved views')),
      L.menu === 'views' ? h('div', { class: 'ap-menu lg-menu', onClick: (e) => e.stopPropagation() },
        L.views.length ? L.views.map((v, i) => h('div', { class: 'lg-view' }, h('button', { onClick: () => apply(v.filters) }, TR.icon('bookmark', 14), v.name),
          h('button', { class: 'ap-icon-btn', 'aria-label': t('Delete view {n}', { n: v.name }), onClick: () => { L.views.splice(i, 1); save('views', L.views); TR.app.refresh(); } }, TR.icon('trash', 14)))) : h('p', { class: 'muted lg-pad' }, t('No saved views yet.')),
        L.naming ? h('form', { class: 'lg-view-new', onSubmit: (e) => { e.preventDefault(); const name = L.viewName.trim(); if (!name) return; L.views = L.views.filter((v) => v.name !== name).concat({ name, filters: keep() }); save('views', L.views); L.naming = false; L.viewName = ''; TR.notify && TR.notify.toast(t('View saved.'), 'success'); TR.app.refresh(); } },
          h('input', { 'aria-label': t('View name'), placeholder: t('Name this view'), value: L.viewName, maxlength: 40, onInput: (e) => { L.viewName = e.target.value; } }), ui().button(t('Save'), 'save', null, 'primary', { type: 'submit' }))
          : ui().button(t('Save current view'), 'plus', () => { L.naming = true; TR.app.refresh(); setTimeout(() => { const i = document.querySelector('.lg-view-new input'); if (i) i.focus(); }, 0); }, 'text')) : null);
  }
  function exportMenu() {
    return h('div', { class: 'lg-menu-wrap' }, h('button', { class: 's-btn secondary', 'aria-haspopup': 'true', 'aria-expanded': String(L.menu === 'export'), onClick: (e) => { e.stopPropagation(); L.menu = L.menu === 'export' ? null : 'export'; TR.app.refresh(); } }, TR.icon('download', 16), t('Export sanitized logs')),
      L.menu === 'export' ? h('div', { class: 'ap-menu lg-menu', onClick: (e) => e.stopPropagation() },
        h('a', { href: '/api/v1/diagnostics/events/export?format=csv&' + params(), download: 'logs.csv' }, TR.icon('file', 14), t('CSV (spreadsheet)')),
        h('a', { href: '/api/v1/diagnostics/events/export?format=json&' + params(), download: 'logs.json' }, TR.icon('code', 14), 'JSON'),
        h('p', { class: 'muted lg-pad' }, t('Secrets and e-mail addresses are already masked. The download is recorded in the audit log.'))) : null);
  }
  const sortBy = (k) => { if (L.sort === k) L.dir = L.dir === 'desc' ? 'asc' : 'desc'; else { L.sort = k; L.dir = k === 'time' ? 'desc' : 'asc'; } reload(); };
  const WIDTH = { time: '124px', level: '96px', service: 'minmax(110px, .8fr)', message: 'minmax(240px, 3fr)', request: '108px', category: 'minmax(120px, 1fr)', trace: '140px' };
  const cols = () => COLUMNS.filter(([k]) => L.columns.has(k));
  const grid = () => ({ gridTemplateColumns: cols().map(([k]) => WIDTH[k]).join(' ') });
  function header() {
    return h('div', { class: 'lg-row lg-head', role: 'row', style: grid() }, cols().map(([k, l]) => {
      const sortable = ['time', 'level', 'service', 'message'].includes(k), on = L.sort === k;
      const text = k === 'time' ? t('Time') + ' ' : t(l);
      return sortable ? h('button', { role: 'columnheader', 'aria-sort': on ? (L.dir === 'desc' ? 'descending' : 'ascending') : 'none', class: on ? 'is-sorted' : '', onClick: () => sortBy(k) }, text, k === 'time' ? h('small', { class: 'muted' }, '(' + zoneName() + ')') : null, on ? (L.dir === 'desc' ? ' ↓' : ' ↑') : '')
        : h('span', { role: 'columnheader' }, text);
    }));
  }
  function openRequest(label) { L.request = label; L.selected = null; reload(); }
  function row(e) {
    const cells = { time: h('span', { class: 'lg-time' }, zoneTime(e.at)), level: badge(e.level), service: h('span', null, e.service || h('span', { class: 'muted' }, t('Server'))),
      message: h('span', { class: 'lg-msg' }, e.message, e.exception ? h('span', { class: 'lg-more', 'data-tip': t('More lines|Select the entry to read the exception') }, '⋯') : null),
      request: e.request ? h('span', { class: 'jr-link', role: 'link', tabindex: '-1', onClick: (x) => { x.stopPropagation(); openRequest(e.request); } }, e.request) : h('span', { class: 'muted' }, '—'),
      category: h('span', { class: 'lg-cat', title: e.category }, e.category.replace(/^(Microsoft\.AspNetCore\.|TestRequest\.(Events\.)?)/, '')), trace: h('code', { class: 'lg-trace' }, (e.traceId || '').slice(0, 12)) };
    return h('button', { class: ['lg-row', 'lv-' + e.level.toLowerCase(), L.selected && L.selected.id === e.id ? 'is-sel' : ''], role: 'row', style: grid(), 'aria-pressed': String(!!(L.selected && L.selected.id === e.id)),
      onClick: () => { L.selected = L.selected && L.selected.id === e.id ? null : e; L.tab = 'overview'; TR.app.refresh(); } }, cols().map(([k]) => h('span', { role: 'cell' }, cells[k])));
  }
  const text = (e) => `${e.at} ${e.level} [${e.service || e.category}] ${e.message}${e.request ? ' ' + e.request : ''}${e.traceId ? ' trace=' + e.traceId : ''}${e.exception ? '\n' + e.exception : ''}`;
  const copy = async (s, what) => { try { await navigator.clipboard.writeText(s); TR.notify && TR.notify.toast(what + ' ' + t('copied.'), 'success'); } catch (x) { TR.notify && TR.notify.toast(t('Could not copy.'), 'error'); } };
  const short = (s) => (s && s.length > 12 ? s.slice(0, 4) + '…' + s.slice(-4) : s);
  function detail(e) {
    const f = e.fields || {};
    const idRow = (label, v) => (v ? [h('dt', null, t(label)), h('dd', null, h('code', { title: v }, short(v)), h('button', { class: 'ap-icon-btn', 'aria-label': t('Copy {l}', { l: t(label) }), onClick: () => copy(v, t(label)) }, TR.icon('copy', 14)))] : null);
    const J = TR.journey;
    return h('section', { class: 'lg-detail lv-' + e.level.toLowerCase(), 'aria-label': t('Event details') },
      h('header', null, h('h2', null, t('Event details')), h('button', { class: 'ap-icon-btn', 'aria-label': t('Close event details'), onClick: () => { L.selected = null; TR.app.refresh(); } }, TR.icon('close', 16))),
      h('div', { class: 'lg-detail-meta' }, badge(e.level), h('span', { class: 'muted' }, t('Service')), h('strong', null, e.service || t('Server'))),
      h('p', { class: 'lg-detail-msg' }, e.message),
      h('div', { class: 'jr-tabs lg-tabs', role: 'tablist' }, [['overview', 'Overview'], ['data', 'Structured data']].map(([k, l]) => h('button', { role: 'tab', 'aria-selected': String(L.tab === k), class: L.tab === k ? 'is-on' : '', onClick: () => { L.tab = k; TR.app.refresh(); } }, t(l)))),
      L.tab === 'overview' ? h('div', null,
        h('dl', { class: 'lg-dl' },
          e.request ? [h('dt', null, t('Request')), h('dd', null, h('button', { class: 'jr-link', onClick: () => openRequest(e.request) }, e.request))] : null,
          idRow('Trace ID', e.traceId), idRow('Span ID', e.spanId),
          h('dt', null, t('Timestamp')), h('dd', null, h('time', { datetime: e.at, title: zoneTime(e.at) + ' ' + zoneName() }, fullTime(e.at))),
          f.durationMs ? [h('dt', null, t('Duration')), h('dd', null, J ? J.secs(Number(f.durationMs)) : f.durationMs + ' ms')] : null,
          e.attempt ? [h('dt', null, t('Attempt')), h('dd', null, String(e.attempt))] : null,
          f.revision ? [h('dt', null, t('Revision')), h('dd', null, f.revision)] : null,
          e.path ? [h('dt', null, t('Path')), h('dd', null, h('code', null, e.path))] : null),
        h('div', { class: 'lg-means' }, h('strong', null, t('What this means')), h('p', null, meaning(e))),
        e.exception ? h('pre', { class: 'lg-full' }, e.exception) : null)
        : h('div', null, h('table', { class: 'lg-fields' }, h('tbody', null,
          Object.entries(Object.assign({ level: e.level, service: e.service || 'Server', source: e.category, eventId: String(e.eventId) }, f)).map(([k, v]) => h('tr', null, h('th', null, k), h('td', null, h('code', null, v || '—')))))),
          h('button', { class: 'jr-link', onClick: () => copy(text(e), t('Entry')) }, TR.icon('copy', 14), t('Copy entry'))),
      h('div', { class: 'lg-detail-actions' },
        e.request && e.requestId ? ui().button(t('Open trace timeline'), 'clock', () => J && J.open('execution', { rid: e.requestId }), 'primary') : null,
        ui().button(t('Related events'), 'search', () => { if (e.request) L.request = e.request; else L.q = e.traceId || ''; L.selected = null; reload(); }, 'secondary', { disabled: !e.request && !e.traceId }),
        e.request ? ui().button(t('Open request'), 'arrow', () => J && J.open('requests'), 'secondary') : null),
      h('p', { class: 'muted lg-redacted' }, TR.icon('lock', 13), t('Sensitive fields redacted')));
  }
  function chips() {
    const list = [];
    if (L.request) list.push(['Request', L.request, () => { L.request = ''; reload(); }]);
    list.push(['Service', L.service || t('All'), L.service ? () => { L.service = ''; reload(); } : null]);
    const sev = L.levels.size === LEVELS.length ? t('All') : L.levels.size === 3 && L.levels.has('Error') && L.levels.has('Warning') && L.levels.has('Critical') ? t('Problems') : [...L.levels].map((l) => SHORT[l]).join(', ') || t('None');
    list.push(['Severity', sev, L.levels.size !== LEVELS.length ? () => { L.levels = new Set(LEVELS); save('levels', LEVELS); reload(); } : null]);
    const any = L.q || L.request || L.service || L.category || L.message || L.exception || L.path || L.levels.size !== LEVELS.length;
    return h('div', { class: 'lg-chips' },
      list.map(([k, v, clear]) => h('span', { class: ['lg-chip', clear ? 'is-on' : ''] }, t(k) + ': ' + v, clear ? h('button', { class: 'lg-chip-x', 'aria-label': t('Remove filter {k}', { k: t(k) }), onClick: clear }, TR.icon('close', 12)) : null)),
      any ? h('button', { class: 'jr-link', onClick: () => { L.q = L.request = L.service = L.category = L.message = L.exception = L.path = ''; L.levels = new Set(LEVELS); save('levels', LEVELS); reload(); } }, t('Clear')) : null,
      L.scoped ? h('span', { class: 'muted lg-scope' }, TR.icon('lock', 13), t('Scoped to your authorized records')) : null,
      h('span', { class: 'spacer' }),
      h('span', { class: ['lg-live', L.live ? 'is-on' : ''], role: 'status' }, h('i', { 'aria-hidden': 'true' }), t(L.live ? 'Live ingestion on' : 'Live ingestion paused')),
      ui().button(t(L.live ? 'Pause ingestion' : 'Resume ingestion'), L.live ? 'pause' : 'play', () => { L.live = !L.live; save('live', L.live); schedule(); if (L.live) load(true); TR.app.refresh(); }, 'secondary'));
  }

  // ------------------------------------------------------------------ page
  function render() {
    // A request handed over from another page (?rid=REQ-… via TR.journey.open('logs', { rid })).
    const J = TR.journey;
    if (J) { J.readParams(); const rid = J.param('rid', 'logs'); if (rid && rid !== L.paramSeen) { L.paramSeen = rid; L.request = rid; L.data = null; } }
    if (!L.data && !L.loading && !L.error) load();
    if (L.live && !L.timer) schedule();
    const d = L.data;
    const errors = d ? (d.levels.Error || 0) + (d.levels.Critical || 0) : 0, warnings = d ? d.levels.Warning || 0 : 0;
    // An open menu gets the height that is left below it in the window (it scrolls inside), wherever the page is scrolled.
    if (L.menu && typeof setTimeout === 'function') setTimeout(() => { const m = typeof document.querySelector === 'function' && document.querySelector('.lg-root .lg-menu'); if (m && m.getBoundingClientRect) { const r = m.getBoundingClientRect(); m.style.maxHeight = Math.max(180, (window.innerHeight || 800) - r.top - 40) + 'px'; } }, 0);
    return h('div', { class: 'jr-page lg-root', onClick: () => { if (L.menu) { L.menu = null; TR.app.refresh(); } } },
      h('div', { class: 'jr-head' }, h('div', null, h('h1', null, t('Logs & diagnostics')), h('p', { class: 'jr-sub' }, t('Search, correlate and investigate.'))), h('div', { class: 'jr-actions' }, viewsMenu(), exportMenu())),
      h('div', { class: 'lg-filters' },
        h('label', { class: 'jr-search lg-search' }, TR.icon('search', 16), h('input', { type: 'search', id: 'lg-search', placeholder: t('Search message, service, trace ID or anything… ( / to focus )'), value: L.q, 'aria-label': t('Search events'), onInput: typed('q') }), h('kbd', { 'aria-hidden': 'true' }, '/')),
        rangeMenu(), moreMenu()),
      chips(),
      L.error ? h('div', { class: 'jr-banner tone-danger', role: 'alert' }, TR.icon('alert', 16), L.error) : null,
      d ? h('section', { class: 'jr-card lg-analytics' },
        h('header', { class: 'lg-an-head' },
          h('strong', { class: 'lg-an-n' }, String(d.total)), h('span', null, t('events')),
          h('span', { class: 'lg-an-sep' }), h('span', { class: 'lg-an-c ' + (errors ? 'lv-error' : 'is-zero') }, TR.icon(errors ? 'alert' : 'check', 16), h('strong', null, String(errors)), t('errors')),
          h('span', { class: 'lg-an-c ' + (warnings ? 'lv-warning' : 'is-zero') }, TR.icon(warnings ? 'alert' : 'check', 16), h('strong', null, String(warnings)), t('warnings')),
          h('span', { class: 'lg-an-sep' }), h('span', { class: 'muted' }, L.loading ? t('Updating…') : t('Updated just now')),
          h('span', { class: 'spacer' }),
          h('button', { class: 'jr-link', 'aria-expanded': String(L.analytics), onClick: () => { L.analytics = !L.analytics; save('analytics', L.analytics); TR.app.refresh(); } }, t('Analytics'), ' ', TR.icon(L.analytics ? 'up' : 'chevron', 13))),
        L.analytics ? h('div', { class: 'lg-an-body' },
          h('div', null, h('div', { class: 'lg-an-title' }, h('h2', null, t('Events over time')), h('span', { class: 'hl-legend' }, ['Information', 'Warning', 'Error'].map((l) => h('span', null, h('i', { class: 'lg-swatch lv-' + l.toLowerCase() }), t(l === 'Information' ? 'Info' : l))))), chart(d)),
          h('div', null, h('h2', null, t('Top error groups')), errorGroups(d))) : null) : null,
      d ? h('div', { class: ['lg-layout', L.selected ? 'has-sel' : ''] },
        h('section', { class: 'jr-card lg-events' },
          h('header', { class: 'lg-ev-head' }, h('h2', null, t('Events'), ' ', h('span', { class: 'muted' }, String(d.total))), h('span', { class: 'spacer' }),
            h('select', { 'aria-label': t('Order'), onChange: (e) => { const [s, dir] = e.target.value.split(':'); L.sort = s; L.dir = dir; reload(); } },
              [['time:desc', 'Newest first'], ['time:asc', 'Oldest first'], ['level:desc', 'Most severe first'], ['service:asc', 'By service']].map(([v, l]) => h('option', { value: v, selected: L.sort + ':' + L.dir === v }, t(l))))),
          L.newSince ? h('div', { class: 'lg-new', role: 'status' }, TR.icon('spark', 14), t('{n} new events since you started inspecting', { n: L.newSince })) : null,
          h('div', { class: 'lg-table', role: 'table', 'aria-label': t('Events'), 'aria-busy': String(L.loading) }, header(),
            d.items.length ? d.items.map(row) : h('div', { class: 'jr-empty' }, h('h3', null, t('No events match')), h('p', { class: 'muted' }, L.scoped ? t('You see the events of your own requests and reviews. Validate a proposal, or clear the filters.') : t('Clear the filters or choose a longer time range.')))),
          h('footer', { class: 'lg-ev-foot' }, h('span', { class: 'muted' }, t('Showing latest {a} of {n}', { a: Math.min(d.items.length, d.total), n: d.total })),
            L.selected ? h('span', { class: 'muted' }, TR.icon('pause', 13), t('Auto-scroll paused while inspecting')) : null,
            h('span', { class: 'spacer' }),
            ui().button(t('Jump to latest'), 'up', () => { L.selected = null; L.sort = 'time'; L.dir = 'desc'; L.take = 50; reload(); }, 'secondary'),
            d.items.length < d.total ? ui().button(t('Load older'), 'download', () => { L.take = Math.min(500, L.take + 50); load(); }, 'text') : null)),
        L.selected ? detail(L.selected) : null) : h('div', { class: 'jr-loading' }, Array.from({ length: 8 }, () => h('div', { class: 'ap-skeleton' }))),
      h('p', { class: 'jr-foot muted' }, t('Entries are kept in memory ({n} now) and redacted before they are stored. Access follows your permissions.', { n: d ? d.captured : 0 })));
  }
  TR.pages.register({ id: 'logs', title: 'Logs & diagnostics', crumbs: () => [{ label: t('Operations') }, { label: t('Logs') }], render });
  if (TR.pages.ui.slashFocus) TR.pages.ui.slashFocus('#lg-search');
  TR.logs = { L, load, meaning };
})();
