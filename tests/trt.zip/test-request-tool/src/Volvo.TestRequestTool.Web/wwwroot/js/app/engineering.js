/* Engineering insights: demand, readiness and the causes of delay (server: GET /api/v1/insights/engineering).
 * Everything comes from recorded requests and jobs: administrators see everyone's requests, others their own. Processing
 * times are the server-measured stage timings (requests recorded before timing existed have none). Each chart has a text
 * summary for assistive technologies and a "View details" link to the page behind it. Charts are SVG; no library. */
(function () {
  'use strict';
  const { h } = TR.util;
  const J = TR.journey, t = J.t;
  const NS = 'http://www.w3.org/2000/svg';
  const svg = (tag, attrs = {}, kids = []) => { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs)) if (v != null) e.setAttribute(k, String(v)); [].concat(kids).filter((k) => k != null).forEach((k) => e.appendChild(typeof k === 'string' || typeof k === 'number' ? document.createTextNode(String(k)) : k)); return e; };
  const I = { data: null, error: null, key: null, days: 30, context: '' };

  async function load() {
    I.key = I.days + '|' + I.context; I.data = null; I.error = null; TR.app.refresh();
    try { I.data = await J.api('/insights/engineering?days=' + I.days + (I.context ? '&context=' + encodeURIComponent(I.context) : '')); } catch (e) { I.error = e.message; }
    TR.app.refresh();
  }
  // ------------------------------------------------------------------ helpers (exported for tests)
  /** A rounded maximum for an axis: 1, 2 or 5 times a power of ten, at least the value. */
  function niceMax(v) { if (!(v > 0)) return 1; const p = Math.pow(10, Math.floor(Math.log10(v))); return [1, 2, 5, 10].map((m) => m * p).find((x) => x >= v); }
  const fmtDay = (d) => { try { return new Intl.DateTimeFormat(TR.culture ? TR.culture.active().language : undefined, { month: 'short', day: 'numeric' }).format(new Date(d + 'T00:00:00Z')); } catch (e) { return d.slice(5); } };

  function lineChart(rows, series, opts) {
    const W = 460, H = 210, L = 44, B = 28, T = 10, R = 12;
    const vals = rows.flatMap((r) => series.map((s) => r[s.key])).filter((v) => v != null);
    const max = niceMax(Math.max(0, ...vals) * (opts.scale || 1)) / (opts.scale || 1);
    const x = (i) => L + (rows.length <= 1 ? 0 : (i * (W - L - R)) / (rows.length - 1)), y = (v) => H - B - (v / max) * (H - B - T);
    const grid = [0, 0.25, 0.5, 0.75, 1].map((f) => [svg('line', { x1: L, x2: W - R, y1: y(max * f), y2: y(max * f), class: 'eg-grid' }), svg('text', { x: L - 6, y: y(max * f) + 4, class: 'eg-axis', 'text-anchor': 'end' }, opts.tick(max * f))]);
    const step = Math.max(1, Math.ceil(rows.length / 5));
    const xl = rows.map((r, i) => (i % step === 0 || i === rows.length - 1 ? svg('text', { x: x(i), y: H - 8, class: 'eg-axis', 'text-anchor': 'middle' }, fmtDay(r.day)) : null));
    const lines = series.map((s) => {
      const pts = rows.map((r, i) => (r[s.key] == null ? null : [x(i), y(r[s.key])]));
      const segs = []; let cur = [];
      pts.forEach((p) => { if (p) cur.push(p); else if (cur.length) { segs.push(cur); cur = []; } }); if (cur.length) segs.push(cur);
      return segs.map((seg) => [
        s.area ? svg('path', { d: 'M' + seg.map((p) => p.join(',')).join(' L') + ` L${seg[seg.length - 1][0]},${H - B} L${seg[0][0]},${H - B} Z`, class: 'eg-area ' + s.cls }) : null,
        svg('path', { d: 'M' + seg.map((p) => p.join(',')).join(' L'), class: 'eg-line ' + s.cls }),
        seg.length === 1 ? svg('circle', { cx: seg[0][0], cy: seg[0][1], r: 3, class: 'eg-pt ' + s.cls }) : null]);
    });
    return svg('svg', { viewBox: `0 0 ${W} ${H}`, class: 'eg-chart', role: 'img', 'aria-label': opts.label }, [].concat(grid, xl, lines).flat(3));
  }
  function donut(dist) {
    const parts = [['ready', 'Ready', 'eg-ready'], ['pending', 'Awaiting approval', 'eg-pending'], ['blocked', 'Blocked', 'eg-blocked'], ['unknown', 'Unknown', 'eg-unknown'], ['stale', 'Stale', 'eg-stale']];
    const total = parts.reduce((a, [k]) => a + (dist[k] || 0), 0);
    const R = 70, C = 2 * Math.PI * R; let off = 0;
    const arcs = parts.filter(([k]) => dist[k]).map(([k, , cls]) => { const len = (dist[k] / total) * C; const a = svg('circle', { cx: 90, cy: 90, r: R, class: 'eg-arc ' + cls, 'stroke-dasharray': `${len} ${C - len}`, 'stroke-dashoffset': -off, transform: 'rotate(-90 90 90)' }); off += len; return a; });
    const pctReady = total ? Math.round((100 * (dist.ready || 0)) / total) : 0;
    const label = parts.map(([k, l]) => `${t(l)} ${total ? Math.round((100 * (dist[k] || 0)) / total) : 0}%`).join(', ');
    return h('div', { class: 'eg-donut' },
      svg('svg', { viewBox: '0 0 180 180', role: 'img', 'aria-label': t('Fleet readiness: {l}', { l: label }) }, [svg('circle', { cx: 90, cy: 90, r: R, class: 'eg-arc-bg' })].concat(arcs, [svg('text', { x: 90, y: 88, class: 'eg-big', 'text-anchor': 'middle' }, total ? pctReady + '%' : '—'), svg('text', { x: 90, y: 110, class: 'eg-axis', 'text-anchor': 'middle' }, t('Ready'))])),
      h('ul', { class: 'eg-keys' }, parts.map(([k, l, cls]) => h('li', null, h('i', { class: cls }), h('span', null, t(l)), h('strong', null, total ? Math.round((100 * (dist[k] || 0)) / total) + '%' : '—')))));
  }
  const CAT = { dependencies: 'Dependencies', hardware: 'Hardware compatibility', parameters: 'Parameters', software: 'Software and templates' };
  function bars(list) {
    if (!list.length) return J.empty('No blockers', 'No request in this period had a blocking finding.');
    const max = niceMax(list[0].count);
    return h('div', { class: 'eg-bars', role: 'list' }, list.map((b) => h('div', { class: 'eg-bar-row', role: 'listitem', 'data-tip': t(CAT[b.category] || b.category) + '|' + b.codes.map((c) => c.code.replace(/_/g, ' ') + ': ' + c.count).join(', ') },
      h('span', null, t(CAT[b.category] || b.category)), h('span', { class: 'eg-track' }, h('i', { style: { width: (100 * b.count) / max + '%' } })), h('strong', null, String(b.count)))));
  }
  function heat(rows) {
    const max = Math.max(1, ...rows.flat());
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    const total = rows.flat().reduce((a, b) => a + b, 0);
    return h('div', { class: 'eg-heat', role: 'img', 'aria-label': total ? t('Queued requests by weekday and hour (UTC); busiest {d} {h}:00 with {n}.', (() => { let bi = 0, bj = 0; rows.forEach((r, i) => r.forEach((v, j) => { if (v > rows[bi][bj]) { bi = i; bj = j; } })); return { d: t(days[bi]), h: String(bj).padStart(2, '0'), n: rows[bi][bj] }; })()) : t('No queued requests in this period.') },
      rows.map((r, i) => h('div', { class: 'eg-heat-row' }, h('span', null, t(days[i])), r.map((v, j) => h('i', { style: { opacity: v ? 0.18 + 0.82 * (v / max) : 0.06 }, title: `${t(days[i])} ${String(j).padStart(2, '0')}:00 · ${v}` })))),
      h('div', { class: 'eg-heat-row eg-heat-axis', 'aria-hidden': 'true' }, h('span'), Array.from({ length: 24 }, (_, j) => h('b', null, j % 4 === 0 ? String(j).padStart(2, '0') : ''))),
      h('div', { class: 'eg-scale', 'aria-hidden': 'true' }, h('span', null, t('Low')), h('i'), h('span', null, t('High'))));
  }
  function stages(list) {
    if (!list.length) return J.empty('No timed requests', 'Timing is recorded for requests made from now on.');
    const max = niceMax(Math.max(...list.map((s) => s.queueMs + s.processingMs + s.externalMs)));
    return h('div', null, h('div', { class: 'eg-bars' }, list.map((s) => {
      const tot = s.queueMs + s.processingMs + s.externalMs;
      return h('div', { class: 'eg-bar-row', 'data-tip': `${s.kind}|${t('Queue')} ${J.secs(s.queueMs)} · ${t('Processing')} ${J.secs(s.processingMs)} · ${t('Integration calls')} ${J.secs(s.externalMs)} · ${s.requests} ${t('requests')}` },
        h('span', null, s.kind), h('span', { class: 'eg-track eg-stack' }, h('i', { class: 'eg-q', style: { width: (100 * s.queueMs) / max + '%' } }), h('i', { class: 'eg-p', style: { width: (100 * s.processingMs) / max + '%' } }), h('i', { class: 'eg-x', style: { width: (100 * s.externalMs) / max + '%' } })),
        h('strong', null, J.secs(tot)));
    })), h('div', { class: 'jr-legend' }, h('span', null, h('i', { class: 'eg-q' }), t('Queue')), h('span', null, h('i', { class: 'eg-p' }), t('Processing')), h('span', null, h('i', { class: 'eg-x' }), t('Integration calls'))));
  }
  const panel = (title, sub, go, body) => h('section', { class: 'jr-card eg-panel' }, h('header', { class: 'jr-card-head' }, h('div', null, h('h2', null, t(title)), h('p', { class: 'muted jr-small' }, t(sub))),
    go ? h('button', { class: 'jr-link', onClick: go }, t('View details'), ' ', TR.icon('arrow', 14)) : null), body);

  function exportReport(d) {
    const rows = [['Day', 'Requests', 'Blocked', 'Timed', 'p50 ms', 'p95 ms']].concat(d.perDay.map((r) => [r.day, r.requests, r.blocked, r.timed, r.p50 ?? '', r.p95 ?? '']));
    J.download('engineering-insights-' + d.days + 'd.csv', J.csv(rows), 'text/csv');
  }
  function render() {
    const key = I.days + '|' + I.context;
    if (key !== I.key) load();
    const d = I.data;
    const head = J.pageHead('Engineering insights', 'Understand demand, readiness and the causes of delay.', [
      J.select('Period', I.days, [[7, 'Last 7 days'], [30, 'Last 30 days'], [90, 'Last 90 days']], (v) => { I.days = Number(v); TR.app.refresh(); }),
      J.select('Fleet', I.context, [['', 'All fleets']].concat(d ? d.groups.map((g) => [g.id, g.name]) : []), (v) => { I.context = v; TR.app.refresh(); }),
      d ? TR.pages.ui.button(t('Export report'), 'download', () => exportReport(d), 'primary') : null]);
    if (!d) return h('div', { class: 'jr-page' }, head, I.error ? J.failed(I.error, load) : J.loading(6));
    const tot = d.totals;
    const ms = (v) => (v >= 1000 ? Math.round(v / 100) / 10 + ' s' : Math.round(v) + ' ms');
    return h('div', { class: 'jr-page eg-page' }, head,
      J.stats([{ n: tot.requests.toLocaleString(), label: 'Requests', icon: 'file', tone: 'info' }, { n: tot.passRate == null ? null : tot.passRate + '%', label: 'Validation pass rate', icon: 'check', tone: 'good' },
        { n: tot.medianMs == null ? null : J.secs(tot.medianMs), label: 'Median processing', icon: 'clock', tone: 'info', sub: tot.p95Ms == null ? t('Not measured yet') : t('p95 {v}', { v: J.secs(tot.p95Ms) }) },
        { n: tot.readiness == null ? null : tot.readiness + '%', label: 'Fleet readiness', icon: 'chart', tone: 'good', sub: t('{n} vehicles', { n: tot.vehicles }) }]),
      h('div', { class: 'eg-grid' },
        panel('Request demand', 'Total and blocked requests per day.', () => J.open('requests'), [lineChart(d.perDay, [{ key: 'requests', cls: 'eg-blue', area: true }, { key: 'blocked', cls: 'eg-amber', area: true }],
          { tick: (v) => String(Math.round(v)), label: t('Requests per day over {n} days: {a} in total, {b} blocked.', { n: d.days, a: tot.requests, b: d.perDay.reduce((a, r) => a + r.blocked, 0) }) }),
          h('div', { class: 'jr-legend' }, h('span', null, h('i', { class: 'eg-blue' }), t('Requests')), h('span', null, h('i', { class: 'eg-amber' }), t('Blocked')))]),
        panel('Processing latency', 'Request processing time (p50 and p95), measured on the server.', () => J.open('requests'), [tot.timed ? lineChart(d.perDay, [{ key: 'p50', cls: 'eg-blue' }, { key: 'p95', cls: 'eg-purple' }],
          { tick: ms, label: t('Median processing {a}, 95th percentile {b}.', { a: J.secs(tot.medianMs), b: J.secs(tot.p95Ms) }) }) : J.empty('Not measured yet', 'Processing time is recorded for requests made from now on.'),
          h('div', { class: 'jr-legend' }, h('span', null, h('i', { class: 'eg-blue' }), t('p50 (median)')), h('span', null, h('i', { class: 'eg-purple' }), t('p95 (95th percentile)')))]),
        panel('Fleet readiness', 'Current readiness of the vehicles you may read.', () => J.open('readiness'), donut(d.readinessStates)),
        panel('Top validation blockers', 'Most common reasons requests are blocked.', () => { J.open('readiness'); if (TR.readiness) TR.readiness.F.status = 'blocked'; }, bars(d.blockers)),
        panel('Queue pressure', 'Queued requests by weekday and hour (UTC).', () => TR.pages.show('batch'), heat(d.queueHeat)),
        panel('Time by execution stage', 'Average time in each stage by request kind.', () => J.open('requests'), stages(d.stages))),
      h('p', { class: 'jr-foot muted' }, t(d.scope === 'everyone' ? 'From every recorded request (you are an administrator).' : 'From your own recorded requests.'), ' ', t('Times are measured on the server; readiness is current.')));
  }
  TR.pages.register({ id: 'engineering', title: 'Engineering insights', crumbs: () => [{ label: t('Reports') }, { label: t('Analytics') }], render });
  TR.engineering = { I, load, niceMax };
})();
