/* Help Center, laid out like a Google help centre: one search box, topic cards, articles with steps and "Try it" buttons,
 * related articles, and Asha, an animated guide who gives a tip for every page. Content lives in help-articles.js.
 *
 *   /?view=help                 Help Center home (first steps, topics, popular articles)
 *   /?view=help&topic=t3        one topic
 *   /?view=help&article=region  one article
 *   /?view=help&q=kit           search results
 *
 * TR.help.open(articleId), TR.help.search(text) and TR.help.home() navigate; TR.help.persona(mood) draws Asha. */
(function () {
  'use strict';
  const { h } = TR.util;
  const { ui } = TR.pages;
  const { TOPICS, ARTICLES } = TR.helpContent;
  const NS = 'http://www.w3.org/2000/svg';
  const byId = new Map(ARTICLES.map((a) => [a.id, a]));
  const topicOf = (id) => TOPICS.find((t) => t.id === id);
  const H = { article: '', topic: '', query: '', lastTip: '', area: '', level: '' };

  // ------------------------------------------------------------------ navigation and URL
  function setUrl() {
    if (typeof URL !== 'function' || !location || !location.href) return;
    const u = new URL(location.href);
    u.searchParams.set('view', 'help');
    for (const [k, v] of [['article', H.article], ['topic', H.topic], ['q', H.query.trim()]]) { if (v) u.searchParams.set(k, v); else u.searchParams.delete(k); }
    history.replaceState(null, '', u);
  }
  function go(state) { Object.assign(H, { article: '', topic: '', query: '' }, state); TR.pages.show('help'); setUrl(); scrollTop(); }
  const scrollTop = () => { const m = typeof document.querySelector === 'function' && document.querySelector('.s-main'); if (m) m.scrollTop = 0; };
  const open = (id) => go({ article: byId.has(id) ? id : '' });
  const search = (q) => go({ query: q || '' });
  const home = () => go({});
  // Read the article, topic or search from the address once, when the page first opens.
  (() => { try { const p = new URLSearchParams(location.search); H.article = byId.has(p.get('article')) ? p.get('article') : ''; H.topic = topicOf(p.get('topic')) ? p.get('topic') : ''; H.query = p.get('q') || ''; } catch (e) { /* defaults */ } })();

  // ------------------------------------------------------------------ text helpers
  /** `code`, **bold** and *emphasis* in article text. */
  function rich(text, q) {
    return String(text).split(/(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*)/).filter(Boolean).map((part) => {
      if (part.startsWith('`')) return h('code', null, mark(part.slice(1, -1), q));
      if (part.startsWith('**')) return h('strong', null, mark(part.slice(2, -2), q));
      if (part.startsWith('*') && part.length > 2) return h('em', null, mark(part.slice(1, -1), q));
      return mark(part, q);
    });
  }
  function mark(text, q) {
    if (!q) return text;
    const out = [], lower = text.toLowerCase(); let i = 0;
    for (let at = lower.indexOf(q); at >= 0; at = lower.indexOf(q, i)) { out.push(text.slice(i, at), h('mark', null, text.slice(at, at + q.length))); i = at + q.length; }
    out.push(text.slice(i));
    return out;
  }
  const plain = (t) => String(t || '').replace(/[`*]/g, '');
  /** Everything a search looks at, as plain lower-case text. */
  const textOf = (a) => [a.title, a.summary, a.keywords, topicOf(a.topic).title, ...a.sections.flatMap((s) => [s.h, s.p, s.note, ...(s.steps || []), ...(s.list || [])])].map(plain).join(' ').toLowerCase();
  const index = ARTICLES.map((a) => ({ a, text: textOf(a) }));
  /** Articles matching every word of the query, best first (title matches rank highest). */
  function find(query) {
    const words = query.toLowerCase().split(/\s+/).filter(Boolean);
    if (!words.length) return [];
    return index.filter((x) => words.every((w) => x.text.includes(w)))
      .map((x) => ({ a: x.a, score: words.reduce((s, w) => s + (x.a.title.toLowerCase().includes(w) ? 5 : 0) + (x.a.keywords.includes(w) ? 2 : 0) + 1, 0) }))
      .sort((p, q) => q.score - p.score).map((x) => x.a);
  }
  function snippet(a, q) {
    const text = [a.summary, ...a.sections.flatMap((s) => [s.p, s.note, ...(s.steps || []), ...(s.list || [])])].filter(Boolean).map(plain).join(' ');
    const word = q.toLowerCase().split(/\s+/).filter(Boolean)[0] || '';
    const at = Math.max(0, text.toLowerCase().indexOf(word));
    const start = Math.max(0, at - 60);
    return (start ? '…' : '') + text.slice(start, start + 180) + (start + 180 < text.length ? '…' : '');
  }

  // ------------------------------------------------------------------ Asha, the animated guide
  function svg(tag, attrs, kids = []) { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, String(v)); kids.forEach((k) => e.appendChild(k)); return e; }
  /** The chosen guide, animated (personas.js). mood: 'wave' (hello, and empty pages), 'think' (searching or nothing found; still smiling), 'cheer' (all done). */
  const persona = (mood = 'wave', size = 150, id) => TR.personas.draw(mood, size, id);
  const guideName = () => TR.personas.current().name;

  /** The guide with a speech bubble. The bubble pops in only when its text changes. */
  function guide(tip, mood = 'wave', size = 150, extra = '') {
    const fresh = tip !== H.lastTip; H.lastTip = tip;
    return h('div', { class: ['hp-guide', extra] },
      h('div', { class: ['hp-bubble', fresh ? 'is-new' : ''], role: 'status' }, tip),
      h('div', { class: 'hp-guide-figure' }, persona(mood, size)));
  }

  // ------------------------------------------------------------------ live tables and actions
  const ACTIONS = {
    addVehicle: () => { TR.experience.page = null; TR.testRequest.intake(); },
    loadVehicle: async (series, number) => { const L = TR.app.shell.left; Object.assign(L.src, { series, number }); await L.loadFromSource(false); TR.pages.show('vehicle'); },
    uiGuide: (chapter) => (TR.uiGuide ? TR.uiGuide.open(chapter) : window.open('/guide/#' + chapter, '_blank', 'noopener')),
    page: (id) => TR.pages.show(id),
    settings: (section) => { TR.pages.show('settings'); setTimeout(() => document.getElementById('st-' + section)?.scrollIntoView({ block: 'start' }), 0); },
    twoPane: () => TR.testRequest.expert(),
    download,
    chassisTest: () => { const r = TR.chassis.selfTest(); TR.ui.alert(r.map((x) => `${x.ok ? '✔' : '✖'} "${x.input}" → ${x.actual}${x.ok ? '' : ` (expected ${x.expected})`}`).join('\n'), 'Chassis parser test vectors'); },
    shortcuts: () => TR.shortcuts && TR.shortcuts.show(),
    tour: () => TR.tour && TR.tour.start(),
    pus: async () => { await ACTIONS.loadVehicle('FH', '333333'); TR.experience.page = null; TR.testRequest.page(); TR.t3services.open(TR.enums.RequestType.ProductUpdateService); },
    vehicleTab: async (tab, series, number) => { await ACTIONS.loadVehicle(series, number); if (TR.vehiclePage) { TR.vehiclePage.V.tab = tab; TR.app.refresh(); } },
    compare: () => { TR.experience.page = null; TR.app.navigate('compare'); },
    feedback: (kind) => TR.feedback.open(kind),
    palette: () => TR.palette && TR.palette.open(),
  };
  function download(kind) {
    const M = TR.model, clone = TR.util.clone;
    const p = M.inflate(clone(TR.server.findVda({ chassisSeries: 'FH', chassisNumber: '123456' })));
    if (kind === 'product') TR.util.download('FH123456_product.xml', TR.xml.productToXml(p));
    if (kind === 'request') {
      const model = Object.assign(TR.defaultRequest(), { selectedRequestType: 0, selectedSoftwareRequestOperation: 3, selectedScenario: 1, requestedNodes: [] });
      TR.util.download('SoftwareUpdateIntroducedWithFH123456.xml', TR.xml.requestToXml(0, { products: [p], requestedNodes: [], scenario: 1, softwareRequestOperation: 3, remoteRequest: 0, allowLimitedValidation: false, enableMultiNodeBehavior: true, pblUpdateCapable: true, selectedLanguageCode: 'en-GB', simulationKitName: '' }, model, { messageType: 'SoftwareRequest' }));
    }
    if (kind === 'params') TR.util.download('parameters.xml', TR.xml.parametersToXml([{ code: 'P1ALG', electricalArchitecture: 1, references: [{ code: 'VAL', value: '80' }] }, { code: 'P1BCX', electricalArchitecture: 1, references: [{ code: 'VAL', value: '10' }] }, { code: 'P1VML', electricalArchitecture: 1, references: [{ code: 'LOW', value: '40' }, { code: 'HIGH', value: '85' }] }]));
  }
  const TABLES = {
    scenarios: () => h('table', { class: 's-table hp-table' }, h('thead', null, h('tr', null, h('th', null, 'Number'), h('th', null, 'Scenario'))),
      h('tbody', null, Object.entries(TR.enums.ScenarioNames).map(([n, name]) => h('tr', null, h('td', null, n), h('td', null, name))))),
    shortcuts: () => h('div', { class: 'hp-table-wrap' }, h('table', { class: 's-table hp-table' }, h('thead', null, h('tr', null, h('th', null, 'Keys'), h('th', null, 'What it does'), h('th', null, 'Where'))),
      h('tbody', null, (TR.shortcuts ? TR.shortcuts.list() : []).map((s) => h('tr', null, h('td', null, TR.shortcuts.keysView(s.keys)), h('td', null, s.label), h('td', null, s.group)))))),
  };

  // ------------------------------------------------------------------ first steps checklist (also shown on Home)
  const userKey = () => 'trstudio.' + ((TR.backend && TR.backend.session && TR.backend.session.userId) || 'user') + '.firstSteps';
  const STEPS = [
    { id: 'tour', title: 'Take the 2-minute tour', hint: 'Your guide shows you around, and can read each step aloud.', done: () => false, run: () => TR.tour && TR.tour.start(), label: 'Start the tour' },
    { id: 'vehicle', title: 'Load a vehicle', hint: 'Try the T3 truck FH 333333.', done: () => TR.app.shell.left.product.loaded(), run: () => ACTIONS.loadVehicle('FH', '333333'), label: 'Load FH 333333' },
    { id: 'change', title: 'Plan a change', hint: 'Pick a newer software version.', done: () => { try { const c = TR.model.deltaCounts(TR.app.shell.left.product.delta()); return c.nodes + c.parameters + c.variants + c.sNotes > 0; } catch (e) { return false; } }, run: () => { TR.experience.page = null; TR.testRequest.page('software'); }, label: 'Open the software tab' },
    { id: 'validate', title: 'Validate it', hint: 'See what the change would do.', done: () => !!TR.testRequest.validation, run: () => TR.nextStep().run(), label: 'Validate' },
    { id: 'history', title: 'Explore the vehicle history', hint: 'Who changed what, drawn like git.', done: () => false, run: () => { TR.pages.show('vehicle'); if (TR.vehiclePage) { TR.vehiclePage.V.tab = 'history'; TR.app.refresh(); } }, label: 'Open history' },
    { id: 'personalise', title: 'Make it yours', hint: 'Pick your language, time zone and theme.', done: () => TR.prefs.get('cultureMode') !== 'account' || TR.testRequest.theme !== 'auto', run: () => ACTIONS.settings('region'), label: 'Open settings' },
  ];
  function progress() {
    const saved = TR.util.store.get(userKey(), {}) || {};
    let changed = false;
    // A step's check may run before the app has finished starting (no vehicle pane yet): then it is simply not done.
    const isDone = (s) => { try { return !!s.done(); } catch (e) { return false; } };
    for (const s of STEPS) if (!saved[s.id] && isDone(s)) { saved[s.id] = true; changed = true; }
    if (changed) TR.util.store.set(userKey(), saved);
    return saved;
  }
  /** Marks a step as done from elsewhere, for example when the history tab is opened. */
  function complete(id) { const saved = TR.util.store.get(userKey(), {}) || {}; if (!saved[id]) { saved[id] = true; TR.util.store.set(userKey(), saved); } }
  function checklist(compact) {
    if (TR.prefs.get('firstSteps') === false) return null;
    const done = progress(), count = STEPS.filter((s) => done[s.id]).length, all = count === STEPS.length;
    const stepList = () => h('ol', { class: 'hp-step-list' }, STEPS.map((s, i) => h('li', { class: done[s.id] ? 'is-done' : '' },
        h('span', { class: 'hp-step-dot' }, done[s.id] ? TR.icon('check', 14) : String(i + 1)),
        h('div', null, h('strong', null, s.title), h('small', null, s.hint)),
        done[s.id] ? h('span', { class: 'hp-step-done' }, 'Done') : ui.button(s.label, 'arrow', s.run, compact && i === STEPS.findIndex((x) => !done[x.id]) ? 'primary' : 'secondary'))));
    // Home exposes one optional disclosure; the complete checklist lives in Help.
    if (compact) {
      if (all) return null;
      return h('details', { class: 'hp-steps hp-home-steps' },
        h('summary', null, h('span', null, h('strong', null, 'Your first steps'), h('small', null, `${count} of ${STEPS.length} done`))),
        h('div', { class: 'hp-home-body' }, stepList(),
          ui.button('Hide the first steps', 'close', () => TR.prefs.set('firstSteps', false), 'text')));
    }
    return h('section', { class: ['hp-steps', compact ? 'is-compact' : ''], 'aria-label': 'Your first steps' },
      h('div', { class: 'hp-steps-head' },
        h('div', { class: 'hp-steps-title' }, h('span', { class: 'hp-steps-asha' }, persona(all ? 'cheer' : 'wave', 54)), h('div', null, h('h2', null, all ? 'You know your way around!' : 'Your first steps'), h('p', null, all ? `Every first step is done. ${guideName()} is proud of you.` : `${count} of ${STEPS.length} done. Each step takes under a minute.`))),
        h('div', { class: 'hp-meter', role: 'progressbar', 'aria-valuemin': '0', 'aria-valuemax': String(STEPS.length), 'aria-valuenow': String(count) }, h('span', { style: { width: (100 * count / STEPS.length) + '%' } })),
        h('button', { class: 'icon-btn', 'aria-label': 'Hide the first steps', title: 'Hide (bring it back in Settings → Workspace)', onClick: () => TR.prefs.set('firstSteps', false) }, TR.icon('close', 16))),
      stepList());
  }

  // ------------------------------------------------------------------ page
  function searchBox(big) {
    return h('form', { class: ['hp-search', big ? 'is-big' : ''], role: 'search', onSubmit: (e) => { e.preventDefault(); const v = e.target.querySelector ? e.target.querySelector('input').value : H.query; search(v); } },
      TR.icon('search', big ? 22 : 18),
      h('input', { type: 'search', name: 'q', 'aria-label': 'Search help', placeholder: big ? 'Describe what you want to do, for example “change time zone”' : 'Search help', value: H.query, key: 'help-search',
        onInput: (e) => { H.query = e.target.value; H.article = ''; H.topic = ''; setUrl(); TR.app.refreshSoon(); },
        onKeydown: (e) => {
          if (e.key === 'Escape') { if (H.query) { H.query = ''; setUrl(); TR.app.refresh(); } else e.target.blur(); }
          if (e.key === 'ArrowDown') { const first = document.querySelector('.hp-result a, .hp-topic a'); if (first) { e.preventDefault(); first.focus(); } }
        } }),
      h('kbd', { class: 'hp-kbd', title: 'Press / to search' }, '/'));
  }
  const link = (a, cls = '') => h('a', { href: '?view=help&article=' + a.id, class: cls, onClick: (e) => { e.preventDefault(); open(a.id); } }, a.title);

  function hero(tip, mood) {
    return h('section', { class: 'hp-hero' },
      h('div', { class: 'hp-hero-main' },
        h('h1', null, 'How can we help you?'),
        searchBox(true),
        h('div', { class: 'hp-hero-actions' }, ui.button('Take the introduction tour', 'play', () => TR.tour && TR.tour.start(), 'primary'), h('span', { class: 'muted' }, `Two minutes, with ${guideName()}’s voice if you like. Shortcut: g then i.`), ui.button('Abbreviations', 'file', () => TR.pages.show('abbreviations'), 'secondary'), ui.button('Choose your guide', 'people', () => TR.welcome && TR.welcome.show(), 'text')),
        h('div', { class: 'hp-chips', 'aria-label': 'Popular searches' }, h('span', null, 'Popular:'), ['load a vehicle', 'IST', 'kit', 'service pack', 'history', 'shortcuts'].map((q) =>
          h('button', { class: 'hp-chip', onClick: () => search(q) }, q)))),
      guide(tip, mood, 150, 'is-hero'));
  }

  function homeView() {
    const popular = ['load-vehicle', 'validate', 'pus', 'history', 'region', 'scenarios-to-try'].map((id) => byId.get(id));
    return h('div', { class: 'hp-page' },
      hero(`Hi, I’m ${guideName()}! Type what you want to do, press Ctrl+K to find anything, or ? for the keyboard shortcuts.`, 'wave'),
      checklist(false),
      h('h2', { class: 'hp-section-title' }, 'Browse help topics'),
      h('div', { class: 'hp-topics' }, TOPICS.map((t) => {
        const list = ARTICLES.filter((a) => a.topic === t.id);
        return h('section', { class: 'hp-topic' },
          h('div', { class: 'hp-topic-head' }, h('span', { class: 'hp-topic-icon' }, TR.icon(t.icon, 20)), h('h3', null, h('a', { href: '?view=help&topic=' + t.id, onClick: (e) => { e.preventDefault(); go({ topic: t.id }); } }, t.title))),
          h('p', null, t.summary),
          h('ul', null, list.slice(0, 3).map((a) => h('li', null, link(a)))),
          list.length > 3 ? h('a', { class: 'hp-more', href: '?view=help&topic=' + t.id, onClick: (e) => { e.preventDefault(); go({ topic: t.id }); } }, `See all ${list.length} articles`) : null);
      })),
      h('div', { class: 'hp-section-head' }, h('h2', { class: 'hp-section-title' }, `${ARTICLES.filter((a) => a.topic === 'scenarios').length} things you can do`),
        h('a', { class: 'hp-more', href: '?view=help&topic=scenarios', onClick: (e) => { e.preventDefault(); go({ topic: 'scenarios' }); } }, 'See all scenarios')),
      h('div', { class: 'hp-popular' }, ARTICLES.filter((a) => a.topic === 'scenarios').filter((a, i) => i % 5 === 0).slice(0, 6).map((a) => h('button', { class: 'hp-card hp-scenario', onClick: () => open(a.id) },
        h('small', null, a.scenario.area), h('strong', null, a.title), h('span', null, a.summary), h('span', { class: 'hp-scenario-meta' }, h('i', { class: 'lvl-' + a.scenario.level.toLowerCase() }, a.scenario.level), `${a.scenario.minutes} min`)))),
      h('h2', { class: 'hp-section-title' }, 'Popular articles'),
      h('div', { class: 'hp-popular' }, popular.map((a) => h('button', { class: 'hp-card', onClick: () => open(a.id) }, h('small', null, topicOf(a.topic).title), h('strong', null, a.title), h('span', null, a.summary)))),
      stuck());
  }
  function stuck() {
    return h('section', { class: 'hp-stuck' },
      h('h2', null, 'Need more help? Support'),
      h('div', { class: 'hp-stuck-grid' },
        h('a', { class: 'hp-card', href: '/guide/', target: '_blank', rel: 'noopener' }, TR.icon('book', 20), h('strong', null, 'Illustrated UI guide'), h('span', null, 'Screenshots with numbered steps for every screen.')),
        h('button', { class: 'hp-card', onClick: () => ACTIONS.shortcuts() }, TR.icon('grid', 20), h('strong', null, 'Keyboard shortcuts'), h('span', null, 'Press ? anywhere to see them all.')),
        h('button', { class: 'hp-card', onClick: () => TR.pages.show('learn') }, TR.icon('help', 20), h('strong', null, 'Getting started'), h('span', null, 'The workflow and the meaning of technical labels.')),
        h('button', { class: 'hp-card', onClick: () => TR.feedback.open() }, TR.icon('people', 20), h('strong', null, 'Send feedback'), h('span', null, 'Tell us what works, what does not and what you would like next.')),
        h('button', { class: 'hp-card', onClick: () => TR.feedback.open('Problem') }, TR.icon('alert', 20), h('strong', null, 'Report a problem'), h('span', null, 'Page details are attached for you, so it is quick to fix.'))));
  }

  function scenarioGallery(list) {
    const areas = [...new Set(list.map((a) => a.scenario.area))], levels = ['Beginner', 'Intermediate', 'Expert'];
    const shown = list.filter((a) => (!H.area || a.scenario.area === H.area) && (!H.level || a.scenario.level === H.level));
    const chip = (label, on, run) => h('button', { class: ['hp-chip', on ? 'is-on' : ''], 'aria-pressed': String(on), onClick: run }, label);
    return h('div', { class: 'hp-gallery' },
      h('div', { class: 'hp-filters' }, h('span', null, 'Area:'), chip('All', !H.area, () => { H.area = ''; TR.app.refresh(); }), areas.map((x) => chip(x, H.area === x, () => { H.area = x; TR.app.refresh(); }))),
      h('div', { class: 'hp-filters' }, h('span', null, 'Level:'), chip('All', !H.level, () => { H.level = ''; TR.app.refresh(); }), levels.map((x) => chip(x, H.level === x, () => { H.level = x; TR.app.refresh(); }))),
      h('p', { class: 'hp-count', role: 'status' }, `${shown.length} of ${list.length} scenarios`),
      h('div', { class: 'hp-popular' }, shown.map((a) => h('button', { class: 'hp-card hp-scenario', onClick: () => open(a.id) },
        h('small', null, a.scenario.area), h('strong', null, a.title), h('span', null, a.summary),
        h('span', { class: 'hp-scenario-meta' }, h('i', { class: 'lvl-' + a.scenario.level.toLowerCase() }, a.scenario.level), `${a.scenario.minutes} min`)))));
  }

  function topicView() {
    const t = topicOf(H.topic), list = ARTICLES.filter((a) => a.topic === t.id);
    if (t.id === 'scenarios') return h('div', { class: 'hp-page' }, h('div', { class: 'hp-top' }, searchBox(false)),
      h('div', { class: 'hp-topic-page' }, h('span', { class: 'hp-topic-icon is-big' }, TR.icon(t.icon, 28)), h('div', null, h('h1', null, t.title), h('p', { class: 'hp-lead' }, t.summary))),
      scenarioGallery(list), stuck());
    return h('div', { class: 'hp-page' },
      h('div', { class: 'hp-top' }, searchBox(false)),
      h('div', { class: 'hp-topic-page' },
        h('span', { class: 'hp-topic-icon is-big' }, TR.icon(t.icon, 28)),
        h('div', null, h('h1', null, t.title), h('p', { class: 'hp-lead' }, t.summary))),
      h('ol', { class: 'hp-results' }, list.map((a) => h('li', { class: 'hp-result' }, link(a), h('p', null, a.summary)))),
      stuck());
  }

  function articleView() {
    const a = byId.get(H.article), t = topicOf(a.topic);
    const related = (a.related || []).map((id) => byId.get(id)).filter(Boolean);
    return h('div', { class: 'hp-page' },
      h('div', { class: 'hp-top' }, searchBox(false)),
      h('div', { class: 'hp-article-layout' },
        h('nav', { class: 'hp-nav', 'aria-label': 'Help topics' }, TOPICS.map((x) => h('div', { class: ['hp-nav-group', x.id === t.id ? 'is-open' : ''] },
          h('button', { class: 'hp-nav-topic', onClick: () => go({ topic: x.id }) }, TR.icon(x.icon, 16), x.title),
          x.id === t.id ? h('ul', null, ARTICLES.filter((y) => y.topic === x.id).map((y) => h('li', null, link(y, y.id === a.id ? 'is-on' : '')))) : null))),
        h('article', { class: 'hp-article' },
          h('a', { class: 'hp-eyebrow', href: '?view=help&topic=' + t.id, onClick: (e) => { e.preventDefault(); go({ topic: t.id }); } }, t.title),
          h('h1', null, a.title),
          h('p', { class: 'hp-lead' }, a.summary),
          a.sections.map(section),
          related.length ? h('section', { class: 'hp-related' }, h('h2', null, 'Related articles'), h('div', { class: 'hp-popular' }, related.map((r) => h('button', { class: 'hp-card', onClick: () => open(r.id) }, h('small', null, topicOf(r.topic).title), h('strong', null, r.title), h('span', null, r.summary))))) : null,
          h('p', { class: 'hp-back' }, h('a', { href: '?view=help', onClick: (e) => { e.preventDefault(); home(); } }, TR.icon('back', 15), 'Back to the Help Center'))),
        h('aside', { class: 'hp-rail' }, guide(a.tip || 'Stuck? Search for a word from your screen, or press ? for shortcuts.', 'wave', 120))));
  }
  function section(s) {
    return h('section', { class: 'hp-section' },
      s.h ? h('h2', null, s.h) : null,
      s.p ? h('p', null, rich(s.p)) : null,
      s.steps ? h('ol', { class: 'hp-numbered' }, s.steps.map((x) => h('li', null, rich(x)))) : null,
      s.list ? h('ul', { class: 'hp-bullets' }, s.list.map((x) => h('li', null, rich(x)))) : null,
      s.note ? h('div', { class: 'hp-note' }, TR.icon('info', 18), h('p', null, rich(s.note))) : null,
      s.table && TABLES[s.table] ? TABLES[s.table]() : null,
      s.actions ? h('div', { class: 'hp-actions' }, s.actions.map((x) => ui.button(x.label, x.icon, () => ACTIONS[x.run](...(x.args || [])), x.primary ? 'primary' : 'secondary'))) : null);
  }

  function searchView() {
    const q = H.query.trim(), results = find(q), lower = q.toLowerCase();
    const first = lower.split(/\s+/)[0];
    return h('div', { class: 'hp-page' },
      hero(results.length ? `I found ${results.length} article${results.length === 1 ? '' : 's'} for “${q}”. The best match is first.` : `Hmm, nothing for “${q}” yet. Try a shorter word, or browse the topics below.`, results.length ? 'cheer' : 'think'),
      h('p', { class: 'hp-count', role: 'status' }, results.length ? `${results.length} result${results.length === 1 ? '' : 's'}` : 'No results'),
      results.length
        ? h('ol', { class: 'hp-results' }, results.map((a) => h('li', { class: 'hp-result' }, h('small', null, topicOf(a.topic).title), h('a', { href: '?view=help&article=' + a.id, onClick: (e) => { e.preventDefault(); open(a.id); } }, mark(a.title, first)), h('p', null, mark(snippet(a, q), first)))))
        : h('div', { class: 'hp-topics' }, TOPICS.map((t) => h('section', { class: 'hp-topic' }, h('div', { class: 'hp-topic-head' }, h('span', { class: 'hp-topic-icon' }, TR.icon(t.icon, 20)), h('h3', null, h('a', { href: '#', onClick: (e) => { e.preventDefault(); go({ topic: t.id }); } }, t.title))), h('p', null, t.summary)))));
  }

  function render() {
    if (H.query.trim()) return searchView();
    if (H.article && byId.has(H.article)) return articleView();
    if (H.topic && topicOf(H.topic)) return topicView();
    return homeView();
  }

  TR.pages.register({
    id: 'help', title: 'Help',
    crumbs: () => {
      const trail = [{ label: 'Help', open: home }];
      if (H.query.trim()) return trail.concat({ label: 'Search results' });
      const a = byId.get(H.article), t = topicOf(a ? a.topic : H.topic);
      if (t) trail.push({ label: t.title, open: a ? () => go({ topic: t.id }) : null });
      if (a) trail.push({ label: a.title });
      return trail;
    },
    render,
  });
  TR.pages.ui.slashFocus('.hp-search input');
  // The old guide dialog now opens the Help Center.
  if (TR.shellActions) TR.shellActions.guidePopup = () => home();
  // The first steps also appear on Home.
  if (TR.pages.addHomeCard) TR.pages.addHomeCard(() => checklist(true));

  TR.help = { H, open, search, home, find, persona, guide, guideName, checklist, complete, STEPS, ACTIONS, render };
})();
