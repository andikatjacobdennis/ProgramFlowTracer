/* Settings page, laid out like Google Chrome settings: a section list on the left, cards of settings on the right,
 * and one search box that filters every section. Changes apply immediately; there is no Save button.
 *
 * To add a setting, add one entry to SETTINGS below: { section, id, title, description, keywords, control() }. */
(function () {
  'use strict';
  const { h } = TR.util;
  const { ui } = TR.pages;
  const prefs = TR.prefs;
  const state = { query: '' };

  const SECTIONS = [
    { id: 'appearance', title: 'Appearance', icon: 'sun' },
    { id: 'region', title: 'Language and region', icon: 'globe' },
    { id: 'accessibility', title: 'Accessibility', icon: 'motion' },
    { id: 'workspace', title: 'Workspace', icon: 'grid' },
    { id: 'requests', title: 'Requests', icon: 'flask' },
    { id: 'privacy', title: 'Privacy and data', icon: 'lock' },
    { id: 'help', title: 'Help', icon: 'help' },
    { id: 'about', title: 'About Test Request Tool', icon: 'info' },
  ];

  // ---------- controls
  function toggle(label, on, set) {
    return h('button', { class: 'st-switch', role: 'switch', 'aria-checked': String(!!on), 'aria-label': label, onClick: () => set(!on) }, h('span', { class: 'st-knob' }));
  }
  function select(label, value, options, set) {
    return h('select', { class: 'st-select', 'aria-label': label, value: String(value), onChange: (e) => set(e.target.value) },
      options.map(([v, text]) => h('option', { value: String(v), selected: String(v) === String(value) }, text)));
  }
  function action(label, onClick, kind = 'secondary') { return ui.button(label, null, onClick, kind); }
  const C = () => TR.culture;
  /** Labels for the long time zone list are built once per language. */
  const zoneLabels = new Map();
  function zoneLabel(tz, p) {
    const key = p.language + '|' + tz;
    if (!zoneLabels.has(key)) { const q = Object.assign({}, p, { timeZone: tz }); const name = C().zoneName(q), off = C().offset(q); zoneLabels.set(key, tz.replace(/_/g, ' ') + ' · ' + (name === off ? name : `${name}, ${off}`)); }
    return zoneLabels.get(key);
  }
  const sample = new Date();
  function countryPicker() {
    const p = C().active(), system = prefs.get('cultureMode') === 'system';
    return h('div', { class: 'cu-countries', role: 'radiogroup', 'aria-label': 'Country' }, [''].concat(C().COUNTRIES.map((c) => c.code)).map((code) => {
      const on = !system && p.country === code;
      return h('button', { class: ['cu-country', on ? 'is-on' : ''], role: 'radio', 'aria-checked': String(on), onClick: () => C().change('country', code) },
        C().flag(code, 28), h('span', null, C().countryName(code)));
    }));
  }
  function preview() {
    const p = C().active(), f = C().format;
    const row = (label, value) => [h('dt', null, label), h('dd', null, value)];
    return h('dl', { class: 'cu-preview' },
      row('Date and time', f.dateTime(sample)), row('Date', f.date(sample)), row('Time', f.time(sample)),
      row('Number', f.number(1234567.891)), row('Money', f.money(123456.78)), row('Time zone', `${p.timeZone} · ${C().zoneName(p)} · ${C().offset(p)}`));
  }
  function quickList() {
    const list = C().quick();
    return h('div', { class: 'cu-quick' },
      list.length ? list.map((q) => h('div', { class: ['cu-quick-item', C().keyOf(q) === C().keyOf(C().active()) && prefs.get('cultureMode') === 'custom' ? 'is-on' : ''] },
        C().flag(q.country, 24), h('span', { class: 'cu-quick-text' }, h('strong', null, C().countryName(q.country)), h('small', null, C().summary(q))),
        ui.button('Use', null, () => C().use(q), 'text'), h('button', { class: 'icon-btn', 'aria-label': 'Remove ' + C().countryName(q.country) + ' from the quick switch', onClick: () => C().removeQuick(q) }, TR.icon('close', 16))))
        : h('p', { class: 'st-desc' }, 'No cultures kept yet. Your account default and the system settings are always in the quick switch.'),
      h('div', null, ui.button('Keep the current culture', 'plus', () => C().addQuick())));
  }
  const userKey = (k) => 'trstudio.' + ((TR.backend && TR.backend.session && TR.backend.session.userId) || 'user') + '.' + k;

  // ---------- the settings
  const SETTINGS = [
    { section: 'appearance', id: 'theme', title: 'Theme', description: 'Auto follows your operating system. Light Charcoal and Dark Charcoal stay fixed.', keywords: 'dark light colour color mode auto system',
      wide: true,
      control: () => h('div', { class: 'st-themes', role: 'radiogroup', 'aria-label': 'Theme' }, TR.testRequest.THEMES.map(([id, name]) =>
        h('button', { class: ['st-theme', TR.testRequest.theme === id ? 'is-on' : ''], role: 'radio', 'aria-checked': String(TR.testRequest.theme === id), onClick: () => TR.pages.setTheme(id) },
          h('span', { class: 'st-swatch ' + id }, h('span'), h('span'), h('span')), name))) },
    { section: 'appearance', id: 'calm', title: 'Calm mode', description: 'Softer colours and no decoration or confetti, for long focused sessions.', keywords: 'calm quiet focus minimal soft distraction',
      control: () => toggle('Calm mode', !!prefs.get('calm'), (v) => prefs.set('calm', v)) },
    { section: 'appearance', id: 'textSize', title: 'Text size', description: 'Makes all text and controls larger.', keywords: 'font zoom scale bigger',
      control: () => select('Text size', prefs.get('textSize'), [['default', 'Default'], ['large', 'Large'], ['larger', 'Larger']], (v) => prefs.set('textSize', v)) },

    // Language and region: see culture.js. Changing the country sets its language, time zone and currency, which you can then change.
    { section: 'region', id: 'uiLanguage', title: 'App language', description: 'The language of the menus, Help, the tour and the guide. Auto follows your culture’s language when a language pack exists for it, otherwise English.', keywords: 'language english swedish svenska translation ui',
      // A country can have several languages: show the ones of your country and whether a language pack exists for each.
      detail: () => { const list = TR.i18n.countryLanguages ? TR.i18n.countryLanguages() : []; if (!list.length) return 'Now: ' + TR.i18n.locale();
        return `Languages of ${C().countryName(C().active().country)}: ` + list.map((l) => l.name + (l.available ? '' : ' (no language pack yet)') + (l.current ? ' — your culture' : '')).join(', ') + '. Choose your country’s language under Language below.'; },
      control: () => select('App language', prefs.get('uiLanguage'), TR.i18n.LANGS, (v) => prefs.set('uiLanguage', v)) },
    { section: 'region', id: 'uiLanguagePacks', title: 'Language packs and translation', description: 'How much of the interface each language covers, the texts still missing in yours, and a template translators fill in. Adding a language needs only a pack file (see docs/adding-a-language.md).', keywords: 'translate translation dictionary language pack locale coverage missing template pseudo',
      wide: true,
      detail: () => { const c = TR.settingsPage && TR.settingsPage.coverage; return c ? `${c.code}: ${c.covered} of ${c.total} texts (${c.percent} %). ${c.seenMissing.length} text(s) seen on screen without a translation${c.seenMissing.length ? ': ' + c.seenMissing.slice(0, 12).join(' · ') + (c.seenMissing.length > 12 ? ' …' : '') : ''}.` : 'Installed: ' + TR.i18n.languages.filter((l) => !l.pseudo).map((l) => l.name).join(', ') + '.'; },
      control: () => h('div', { class: 's-inline-actions' },
        TR.pages.ui.button('Check coverage', 'search', async () => { TR.settingsPage = TR.settingsPage || {}; TR.settingsPage.coverage = await TR.i18n.coverage(TR.i18n.lang() === 'en' ? (TR.i18n.languages.find((l) => l.file) || {}).code || 'en' : TR.i18n.lang()); TR.app.refresh(); }, 'secondary'),
        TR.pages.ui.button('Download template', 'download', async () => { const code = TR.i18n.lang() === 'en' ? 'new' : TR.i18n.lang(); const tpl = await TR.i18n.template(code === 'new' ? 'en' : code); const url = URL.createObjectURL(new Blob([JSON.stringify(tpl, null, 1)], { type: 'application/json' })); const a = h('a', { href: url, download: code + '.json' }); document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000); }, 'text'),
        TR.pages.ui.button(prefs.get('uiLanguage') === 'qps' ? 'Stop pseudo-language' : 'Test with pseudo-language', 'flask', () => prefs.set('uiLanguage', prefs.get('uiLanguage') === 'qps' ? 'auto' : 'qps'), 'text')) },
    { section: 'region', id: 'cultureSystem', title: 'Use system settings', description: 'Follow the language and time zone of this computer instead of the choices below.', keywords: 'system computer operating automatic locale culture',
      detail: () => { const x = C().systemProfile(); return `This computer: ${C().languageName(x.language)}, ${x.timeZone} (${C().zoneName(x)})`; },
      control: () => toggle('Use system settings', prefs.get('cultureMode') === 'system', (v) => (v ? C().useSystem() : C().useAccount())) },
    { section: 'region', id: 'orgCulture', title: 'Organisation default', description: 'Used for people who have not chosen a culture and whose account has no country. Set by an administrator.', keywords: 'organisation organization company default admin culture country system',
      wide: true,
      detail: () => {
        const o = C().orgDefault(), src = C().accountSource();
        const now = o && o.value ? `Currently ${C().countryName(o.value.country)} (${o.value.language}, ${o.value.timeZone}), version ${o.version}, set by ${o.actorName}.` : 'Not set: people without a country get the nearest supported country to their computer.';
        return now + (src === 'organisation' ? ' It is your default now.' : '');
      },
      control: () => {
        const session = (TR.backend && TR.backend.session) || {};
        if (!session.isAdmin) return h('span', { class: 'muted' }, 'Only administrators can change this.');
        const o = C().orgDefault();
        const pick = h('select', { 'aria-label': 'Organisation default country', value: o && o.value ? o.value.country : '' },
          h('option', { value: '' }, 'Choose a country'), C().COUNTRIES.map((c) => h('option', { value: c.code, selected: o && o.value && o.value.country === c.code }, c.name)));
        const save = async () => {
          if (!pick.value) return;
          const p = C().forCountry(pick.value);
          const r = await fetch('/api/v1/admin/settings/culture-default', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ country: p.country, language: p.language, timeZone: p.timeZone, currency: p.currency, dateFormat: p.dateFormat, hourCycle: p.hourCycle }) });
          const body = await r.json();
          if (!r.ok) { TR.ui.alert(body.detail || body.title || 'Could not save.'); return; }
          TR.notify && TR.notify.toast('Organisation default set to ' + C().countryName(p.country) + ' (version ' + body.version + ').', 'success');
          C().loadOrgDefault(); state.orgHistory = null;
        };
        const history = async () => {
          const r = await fetch('/api/v1/admin/settings/culture-default/history');
          state.orgHistory = r.ok ? await r.json() : [];
          TR.app.refresh();
        };
        const restore = async (v) => {
          const r = await fetch('/api/v1/admin/settings/culture-default/restore/' + v, { method: 'POST' });
          if (r.ok) { TR.notify && TR.notify.toast('Version ' + v + ' restored as a new version.', 'success'); C().loadOrgDefault(); state.orgHistory = null; history(); }
        };
        return h('div', { class: 'st-org' },
          h('div', { class: 'st-org-row' }, pick, ui.button('Save as organisation default', 'save', save, 'primary'), ui.button(state.orgHistory ? 'Hide versions' : 'Versions', 'history', () => { if (state.orgHistory) { state.orgHistory = null; TR.app.refresh(); } else history(); }, 'text')),
          state.orgHistory ? h('ol', { class: 'st-org-history' }, state.orgHistory.length ? state.orgHistory.map((v, i) => h('li', null,
            C().flag(v.value.country, 20), h('span', null, h('strong', null, 'v' + v.version + ' · ' + C().countryName(v.value.country)), h('small', null, ' ' + v.actorName + ' · ' + ui.when(v.at) + (v.note ? ' · ' + v.note : ''))),
            i === 0 ? ui.chip('Current', 'good') : ui.button('Restore', 'undo', () => restore(v.version), 'text'))) : h('li', { class: 'muted' }, 'No versions yet.')) : null);
      } },
    { section: 'region', id: 'country', title: 'Country', description: 'Sets the language, time zone and currency to the defaults of that country. Not set uses UTC.', keywords: 'country region culture flag locale india ist utc',
      wide: true,
      detail: () => { const a = C().accountProfile().country; return a ? `Your account country is ${C().countryName(a)}, so it is the default.` : 'Your account has no country, so the default is UTC.'; },
      control: countryPicker },
    { section: 'region', id: 'language', title: 'Language', description: 'Used for month and day names and for number formats. The application text stays in English.', keywords: 'language locale hindi english culture',
      control: () => { const p = C().active(); return select('Language', p.language, C().options(p).languages.map((t) => [t, C().languageName(t)]), (v) => C().change('language', v)); } },
    { section: 'region', id: 'timeZone', title: 'Time zone', description: 'Every date and time is shown in this time zone, with its short name such as IST.', keywords: 'time zone timezone ist utc gmt offset clock',
      control: () => { const p = C().active(); return select('Time zone', p.timeZone, C().options(p).timeZones.map((t) => [t, zoneLabel(t, p)]), (v) => C().change('timeZone', v)); } },
    { section: 'region', id: 'currency', title: 'Currency', description: 'Used wherever an amount of money is shown.', keywords: 'currency money rupee inr euro dollar',
      control: () => { const p = C().active(); return select('Currency', p.currency, [['', 'None']].concat(C().options(p).currencies.map((c) => [c, C().currencyName(c)])), (v) => C().change('currency', v)); } },
    { section: 'region', id: 'dateFormat', title: 'Date format', description: 'How dates are written.', keywords: 'date format iso short long',
      control: () => { const p = C().active(); return select('Date format', p.dateFormat, ['iso', 'short', 'medium', 'long'].map((x) => [x, C().format.date(sample, Object.assign({}, p, { dateFormat: x })) + (x === 'iso' ? ' (ISO 8601)' : '')]), (v) => C().change('dateFormat', v)); } },
    { section: 'region', id: 'hourCycle', title: 'Clock', description: '12-hour or 24-hour time.', keywords: 'time format 12 24 hour clock am pm',
      control: () => {
        const p = C().active();
        const ex = (x) => C().format.time(sample, Object.assign({}, p, { hourCycle: x, dateFormat: p.dateFormat === 'iso' ? 'medium' : p.dateFormat }));
        return select('Clock', p.hourCycle, [['auto', 'From the language · ' + ex('auto')], ['h12', '12-hour · ' + ex('h12')], ['h23', '24-hour · ' + ex('h23')]], (v) => C().change('hourCycle', v));
      } },
    { section: 'region', id: 'clocksShown', title: 'Time zones shown together', description: 'How many time zones the status bar shows at once: yours first, then your other time zones in order. For example India and Sweden side by side.', keywords: 'time zones multiple clocks limit india sweden status bar together',
      control: () => h('div', { class: 'tp-seg', role: 'radiogroup', 'aria-label': 'Time zones shown together' }, [1, 2, 3, 4].map((n) =>
        h('button', { type: 'button', role: 'radio', 'aria-checked': String(Number(prefs.get('clocksShown')) === n), class: Number(prefs.get('clocksShown')) === n ? 'is-on' : '', onClick: () => prefs.set('clocksShown', n) }, String(n)))) },
    { section: 'region', id: 'inlineZones', title: 'Also beside times on pages', description: 'Show the same time zones next to every time on a page, small and after your own. Hover or click any time for all zones.', keywords: 'inline time zone beside timestamp second zone',
      control: () => toggle('Also beside times on pages', !!prefs.get('inlineZones'), (v) => prefs.set('inlineZones', v)) },
    { section: 'region', id: 'worldClocks', title: 'Other time zones', description: 'Hover over or click any time to see it in these zones too. UTC and your quick-switch cultures are always included.', keywords: 'world clock time zones timezone other utc colleagues',
      wide: true,
      control: () => {
        const list = prefs.get('worldClocks') || [], p = C().active();
        return h('div', { class: 'tz-settings' },
          h('div', { class: 'tz-chips' }, TR.timezones.zones().map((z) => h('span', { class: ['tz-chip', z.you ? 'is-you' : ''] }, C().flag(z.country, 16), z.label, h('small', null, C().zoneName(Object.assign({}, p, { timeZone: z.tz }))),
            list.includes(z.tz) ? h('button', { class: 'tz-chip-x', 'aria-label': TR.i18n.t('Remove {zone}', { zone: z.label }), onClick: () => prefs.set('worldClocks', list.filter((x) => x !== z.tz)) }, TR.icon('close', 12)) : null))),
          h('label', { class: 'tz-add' }, TR.i18n.t('Add a time zone') + ' ', h('select', { 'aria-label': TR.i18n.t('Add a time zone'), onChange: (e) => { if (e.target.value) prefs.set('worldClocks', list.concat(e.target.value)); } },
            h('option', { value: '' }, TR.i18n.t('Choose…')), C().options(p).timeZones.filter((tz) => !TR.timezones.zones().some((z) => z.tz === tz)).map((tz) => h('option', { value: tz }, zoneLabel(tz, p))))));
      } },
    { section: 'region', id: 'culturePreview', title: 'Preview', description: 'How the current culture shows dates, numbers and money.', keywords: 'example preview sample',
      wide: true, control: preview },
    { section: 'region', id: 'quickSwitch', title: 'Quick switch', description: 'Keep several cultures and switch between them live with the flag button in the top bar, or press Alt+Shift+C.', keywords: 'toggle switch multiple cultures live favourite',
      wide: true, control: quickList },
    { section: 'region', id: 'cultureSwitch', title: 'Show the culture switch in the top bar', description: 'The flag button next to the theme button.', keywords: 'flag header toggle',
      control: () => toggle('Show the culture switch in the top bar', prefs.get('cultureSwitch') !== false, (v) => prefs.set('cultureSwitch', v)) },

    { section: 'accessibility', id: 'motion', title: 'Animations and motion', description: 'Pages fade in, lists and cards slide in one after another, and cards lift under the pointer. Turn off for a completely still screen. Your system’s reduce-motion setting is always honoured.', keywords: 'reduce motion animation transition off on',
      control: () => toggle('Animations and motion', prefs.get('motion') !== 'off', (v) => prefs.set('motion', v ? 'on' : 'off')) },
    { section: 'accessibility', id: 'abbreviations', title: 'Explain abbreviations', description: 'Abbreviations such as EMS or VDA get a dotted underline; point at one to see what it stands for. Help › Abbreviations lists them all.', keywords: 'abbreviation acronym glossary meaning tooltip underline ecu ems',
      control: () => toggle('Explain abbreviations', prefs.get('abbreviations') !== false, (v) => { prefs.set('abbreviations', v); if (TR.abbreviations) { if (v) TR.abbreviations.mark(document.getElementById('app')); else TR.abbreviations.unmark(); } }) },
    { section: 'accessibility', id: 'shortcuts', title: 'Keyboard shortcuts', description: 'Press ? anywhere for the full list. g then a letter goes to a page (g v Vehicle, g s Settings), n does the next step, / searches, Esc closes.', keywords: 'keyboard slash escape shortcut hotkey keys',
      control: () => action('View all', () => TR.shortcuts && TR.shortcuts.show()) },

    { section: 'workspace', id: 'nextStep', title: 'Show the next-step button', description: 'One coloured button in the top bar that always shows what to do next: blue to continue, green when ready, amber when something needs attention.', keywords: 'guide help next action',
      control: () => toggle('Show the next-step button', prefs.get('nextStep'), (v) => prefs.set('nextStep', v)) },
    { section: 'workspace', id: 'experience', title: 'Experience', description: 'Beginner shows quick guides and folds expert tools away. Expert is compact. Auto moves you to Expert once you have validated a few times.', keywords: 'beginner expert adaptive level mode simple advanced',
      control: () => select('Experience', prefs.get('experience'), [['auto', `Auto (now ${TR.ux ? TR.ux.level() : 'beginner'})`], ['beginner', 'Beginner'], ['expert', 'Expert']], (v) => prefs.set('experience', v)) },
    { section: 'workspace', id: 'expertTools', title: 'Expert tools', description: 'The Expert tools menu: the two-pane workbench, VCADS, Compare breakdown, Server calls, History, Logs and Engineering insights. Auto shows it to administrators. Hidden, the pages still open from Help → Show expert tools and from links on other pages.', keywords: 'expert tools workbench vcads compare history logs server calls insights menu advanced',
      control: () => select('Expert tools', prefs.get('expertTools'), [['auto', `Auto (${TR.navigation && TR.navigation.logic.expertOn('auto', ((TR.backend && TR.backend.session) || {}).role) ? 'shown' : 'hidden'} for your role)`], ['on', 'Show'], ['off', 'Hide']], (v) => prefs.set('expertTools', v)) },
    { section: 'workspace', id: 'nudge', title: 'Point out the next step when I pause', description: 'After a quiet moment the Next button pulses gently.', keywords: 'nudge hint blink pulse idle guidance',
      control: () => toggle('Point out the next step when I pause', prefs.get('nudge') !== false, (v) => prefs.set('nudge', v)) },
    { section: 'workspace', id: 'firstSteps', title: 'Show the first steps', description: 'A short checklist on Home and in Help that walks you through your first test request.', keywords: 'onboarding checklist tutorial steps',
      control: () => toggle('Show the first steps', prefs.get('firstSteps') !== false, (v) => prefs.set('firstSteps', v)) },
    { section: 'workspace', id: 'navigation', title: 'Navigation', description: 'Expanded shows icons and labels, Compact icons only (names on hover and focus), Hidden keeps it out of the way: the Menu button brings it back. Saved for your account on every device.', keywords: 'sidebar menu rail navigation compact expanded hidden collapse drawer',
      wide: true,
      control: () => {
        const N = TR.navigation, p = N ? N.prefs() : { mode: 'expanded', autoHide: true };
        return h('div', { class: 'st-org' },
          h('div', { class: 'tp-seg', role: 'radiogroup', 'aria-label': 'Navigation display' }, [['expanded', 'Expanded'], ['compact', 'Compact'], ['hidden', 'Hidden']].map(([m, l]) =>
            h('button', { type: 'button', role: 'radio', 'aria-checked': String(p.mode === m), class: p.mode === m ? 'is-on' : '', onClick: () => N && N.setPrefs(Object.assign({}, p, { mode: m })) }, l))),
          toggle('Auto-hide', p.autoHide, (v) => N && N.setPrefs(Object.assign({}, p, { autoHide: v }))),
          h('small', { class: 'muted' }, 'Auto-hide closes the navigation drawer after you choose a page and, on a computer, when the pointer and keyboard focus have left it. On phones the navigation is always a drawer.'),
          h('div', null, action('Reset navigation preferences', () => N && N.reset(), 'text')));
      } },
    { section: 'workspace', id: 'spellcheck', title: 'Spelling check', description: 'Wavy underlines under misspelled words in comments, descriptions and other free text. Click a word (or press Ctrl+.) for corrections. English. Technical identifiers are never checked.', keywords: 'spelling spell check squiggle dictionary typo',
      control: () => toggle('Spelling check', prefs.get('spellcheck') !== false, (v) => prefs.set('spellcheck', v)) },
    { section: 'workspace', id: 'dictionary', title: 'My dictionary', description: 'Words you told the spelling check to accept. Yours only, on every device you sign in on.', keywords: 'dictionary ignore words spelling reset custom',
      wide: true,
      control: () => {
        const words = TR.spell ? TR.spell.custom() : [];
        return h('div', { class: 'st-org' },
          words.length ? h('div', { class: 'tm-chips' }, words.map((w) => h('span', { class: 'tm-chip' }, w, h('button', { class: 'ap-icon-btn', 'aria-label': 'Remove ' + w + ' from my dictionary', onClick: () => TR.spell.removeWord(w) }, '✕')))) : h('span', { class: 'muted' }, 'No words yet. Choose "Add to my dictionary" on an underlined word.'),
          h('div', null, action('Reset my dictionary', () => TR.spell && TR.spell.resetDictionary(), 'text')));
      } },
    { section: 'workspace', id: 'pageSize', title: 'Rows per page', description: 'How many rows long lists such as Activity and vehicle history show at once.', keywords: 'pagination page size table',
      control: () => select('Rows per page', prefs.get('pageSize'), [[10, '10'], [25, '25'], [50, '50'], [100, '100'], [200, '200']], (v) => prefs.set('pageSize', Number(v))) },

    { section: 'requests', id: 'scenario', title: 'Default scenario', description: 'Which release states new requests may use. You can still change it per request.', keywords: 'released introduced in progress pre-release',
      control: () => select('Default scenario', prefs.get('scenario'), [1, 2, 3, 4, 5].map((n) => [n, TR.enums.ScenarioNames[n]]), (v) => { prefs.set('scenario', Number(v)); applyScenario(Number(v)); }) },
    { section: 'requests', id: 'pusVersion', title: 'Product Update Service version', description: 'Schema used for new Product Update Service requests.', keywords: 'pus t3 service pack schema',
      control: () => select('Product Update Service version', prefs.get('pusVersion'), [['2.0', '2.0 · Update to service pack or Repair'], ['1.0', '1.0 · Update to service pack']], (v) => prefs.set('pusVersion', v)) },
    { section: 'requests', id: 'apuVersion', title: 'Available Product Updates version', description: 'Contract used for new Available Product Updates requests.', keywords: 'apu t3 available updates contract',
      control: () => select('Available Product Updates version', prefs.get('apuVersion'), [['1.1', '1.1 · action criteria array'], ['1.0', '1.0 · comma-separated action criteria']], (v) => prefs.set('apuVersion', v)) },

    { section: 'privacy', id: 'mydata', title: 'What the app knows about me', description: 'See everything kept about you, stop optional recording and delete what you may delete.', keywords: 'privacy data gdpr delete record usage study my data',
      control: () => action('Open', () => TR.pages.show('mydata')) },
    { section: 'privacy', id: 'usageStudy', title: 'Usage study', description: 'Record which pages and features you use, to make the app more useful. Never what you type. Off stops recording at once.', keywords: 'usage analytics telemetry study behaviour privacy record',
      control: () => toggle('Usage study', prefs.get('usageStudy') !== false, (v) => (TR.usage ? TR.usage.setRecording(v) : prefs.set('usageStudy', v))) },
    { section: 'privacy', id: 'recent', title: 'Recently loaded sources', description: 'Shortcuts to vehicles you loaded, stored only in this browser for your account.', keywords: 'history clear recent',
      control: () => action('Clear', () => { TR.util.store.set(userKey('recent'), []); TR.ui.summary.addInformation('Recently loaded sources cleared.'); TR.app.refresh(); }) },
    { section: 'privacy', id: 'bookmarks', title: 'Saved vehicles', description: 'Bookmarked vehicles for your account in this browser. Vehicle records are not affected.', keywords: 'bookmark clear saved',
      control: () => action('Clear', async () => { if (await TR.ui.confirm('Remove all saved vehicle bookmarks for your account in this browser?')) { TR.util.store.set(userKey('bookmarks'), []); TR.app.refresh(); } }) },
    { section: 'privacy', id: 'learning', title: 'Forget what the palette learned', description: 'The command palette ranks what you use often and predicts what you do next, in this browser only. This clears it and your favourites.', keywords: 'machine learning ml palette history frecency favourites privacy',
      control: () => action('Forget', async () => { if (await TR.ui.confirm(TR.i18n.t('Forget what the palette learned about you in this browser?'))) { TR.ml.clearLearning(); TR.util.store.set('trstudio.' + ((TR.backend && TR.backend.session && TR.backend.session.userId) || 'user') + '.palette.favourites', []); TR.notify && TR.notify.toast(TR.i18n.t('Forgotten'), 'success'); } }) },
    { section: 'privacy', id: 'reset', title: 'Reset settings', description: 'Restores every setting on this page to its default.', keywords: 'defaults restore reset',
      control: () => action('Reset', async () => { if (await TR.ui.confirm('Reset all settings to their defaults?')) prefs.reset(); }) },
    { section: 'privacy', id: 'simulator', title: 'Simulator and permissions', description: 'Original simulator options: latency, simulator data and browser-only permission switches.', keywords: 'legacy simulator latency permissions dev mode',
      control: () => action('Open', () => TR.shellActions.settingsPopup()) },

    { section: 'help', id: 'guide', title: 'UI guide', description: 'Illustrated guide with numbered steps for every screen. It follows your theme.', keywords: 'help manual screenshots documentation',
      control: () => h('a', { class: 's-btn secondary', href: TR.testRequest.guideUrl ? TR.testRequest.guideUrl() : '/guide/', target: '_blank', rel: 'noopener' }, 'Open') },
    { section: 'help', id: 'personas', title: 'Show guides', description: 'The illustrated characters in Help, the tour, empty pages and the welcome. Off hides them everywhere; the text stays.', keywords: 'caricature persona character mascot cartoon guide hide show off',
      control: () => toggle('Show guides', prefs.get('personas') !== false, (v) => prefs.set('personas', v)) },
    { section: 'help', id: 'guide', title: 'Your guide', description: 'Who shows you around: in Help, the tour and on empty pages.', keywords: 'persona guide character mascot asha ravi meera truxie avatar',
      wide: true,
      control: () => h('div', { class: 'st-guides', role: 'radiogroup', 'aria-label': 'Your guide' }, TR.personas.LIST().map((p) => {
        const on = TR.personas.current().id === p.id;
        return h('button', { class: ['st-guide', on ? 'is-on' : ''], role: 'radio', 'aria-checked': String(on), onClick: () => prefs.set('guide', p.id) },
          TR.personas.draw(on ? 'wave' : 'think', 70, p.id), h('strong', null, p.name), h('small', null, p.role));
      })) },
    { section: 'help', id: 'welcome', title: 'Show the welcome again', description: 'The first-time welcome: choose a guide and start the tour.', keywords: 'welcome onboarding first time intro',
      control: () => action('Show', () => TR.welcome && TR.welcome.show()) },
    { section: 'help', id: 'tour', title: 'Introduction tour', description: 'Asha walks you through the application, one highlighted part at a time.', keywords: 'tour wizard introduction walkthrough onboarding',
      control: () => action('Start', () => TR.tour && TR.tour.start()) },
    { section: 'help', id: 'tourVoice', title: 'Read the tour aloud', description: 'Uses the most natural voice your browser has for your language. Nothing is sent to a service.', keywords: 'voice speech narration audio read aloud',
      control: () => toggle('Read the tour aloud', prefs.get('tourVoice') !== false, (v) => prefs.set('tourVoice', v)) },
    { section: 'help', id: 'feedback', title: 'Send feedback', description: 'Ideas, problems, praise or questions. Page details are attached only if you want.', keywords: 'feedback support contact report problem idea',
      control: () => action('Open', () => TR.feedback.open()) },
    { section: 'help', id: 'helpCenter', title: 'Help Center', description: 'Search answers, step-by-step articles and sample data.', keywords: 'help support faq articles search',
      control: () => action('Open', () => TR.pages.show('help')) },
    { section: 'help', id: 'learn', title: 'Getting started', description: 'The workflow in five steps and the meaning of technical labels.', keywords: 'tutorial basics glossary',
      control: () => action('Open', () => TR.pages.show('learn')) },

    { section: 'about', id: 'aboutPage', title: 'About Test Request Tool', description: 'Version, runtime, supported contracts and what this application does.', keywords: 'version information licence',
      control: () => action('Open', () => TR.pages.show('about')) },
  ];

  function applyScenario(n) { const L = TR.app.shell.left; if (L) L.request.selectedScenario = n; }

  // ---------- search
  const matches = (s, q) => !q || [s.title, s.description, s.keywords, SECTIONS.find((x) => x.id === s.section).title].join(' ').toLowerCase().includes(q);
  /** Text with every occurrence of the query wrapped in <mark>. */
  function highlight(text, q) {
    if (!q) return text;
    const parts = []; const lower = text.toLowerCase(); let i = 0;
    for (let at = lower.indexOf(q); at >= 0; at = lower.indexOf(q, i)) { parts.push(text.slice(i, at), h('mark', null, text.slice(at, at + q.length))); i = at + q.length; }
    parts.push(text.slice(i));
    return parts;
  }
  function visibleSettings() { const q = state.query.trim().toLowerCase(); return SETTINGS.filter((s) => matches(s, q)); }

  // ---------- page
  function render() {
    const q = state.query.trim().toLowerCase();
    const shown = visibleSettings();
    const session = (TR.backend && TR.backend.session) || {};
    return h('div', { class: 'st-page' },
      h('div', { class: 'st-head' },
        h('h1', null, 'Settings'),
        h('label', { class: 'st-search' }, TR.icon('search', 18),
          h('input', { type: 'search', placeholder: 'Search settings', 'aria-label': 'Search settings', value: state.query, key: 'settings-search',
            onInput: (e) => { state.query = e.target.value; TR.app.refreshSoon ? TR.app.refreshSoon() : TR.app.refresh(); },
            onKeydown: (e) => { if (e.key === 'Escape') { state.query = ''; TR.app.refresh(); } } }))),
      h('p', { class: 'st-status', role: 'status' }, q ? (shown.length ? `${shown.length} setting${shown.length === 1 ? '' : 's'} match “${state.query.trim()}”` : `No settings match “${state.query.trim()}”`) : 'Changes are saved automatically in this browser.'),
      h('div', { class: 'st-layout' },
        h('nav', { class: 'st-nav', 'aria-label': 'Settings sections' }, SECTIONS.map((sec) => {
          const count = shown.filter((s) => s.section === sec.id).length;
          return h('a', { href: '#st-' + sec.id, class: count ? '' : 'is-empty', onClick: (e) => { e.preventDefault(); document.getElementById('st-' + sec.id)?.scrollIntoView({ behavior: ui.motionOn() ? 'smooth' : 'auto', block: 'start' }); } },
            TR.icon(sec.icon, 18), sec.title);
        })),
        h('div', { class: 'st-sections' },
          !q ? h('section', { class: 'st-card st-you' }, TR.personas ? h('span', { class: 'st-asha', 'aria-hidden': 'true' }, TR.personas.draw('wave', 46)) : h('div', { class: 'st-avatar' }, (session.displayName || session.userId || '?').slice(0, 1).toUpperCase()),
            h('div', null, h('strong', null, session.displayName || session.userId || 'Signed in'), h('span', null, session.role || 'User'))) : null,
          SECTIONS.map((sec) => {
            const rows = shown.filter((s) => s.section === sec.id);
            if (!rows.length) return null;
            return h('section', { class: 'st-section', id: 'st-' + sec.id },
              h('h2', null, sec.title),
              h('div', { class: 'st-card' }, rows.map((s) => h('div', { class: ['st-row', s.wide ? 'is-wide' : ''], 'data-setting': s.id },
                h('div', { class: 'st-text' }, h('div', { class: 'st-title' }, highlight(s.title, q)), h('div', { class: 'st-desc' }, highlight(s.description, q)), s.detail ? h('div', { class: 'st-detail' }, s.detail()) : null),
                (() => {
                  const src = prefs.source ? prefs.source(s.id) : { kind: 'default' };
                  const badge = src.kind === 'locked' ? h('span', { class: 'tm-chip is-locked', 'data-tip': TR.i18n.t('Locked|Set by {by}; ask an administrator to change it.', { by: src.by }) }, TR.icon('lock', 12), TR.i18n.t('Set by {by}', { by: src.by }))
                    : src.kind === 'managed' ? h('span', { class: 'tm-chip', 'data-tip': TR.i18n.t('Default from {by}|You can change it; your choice then applies to you.', { by: src.by }) }, TR.i18n.t('Default from {by}', { by: src.by }))
                    : src.kind === 'yours' && src.managed ? h('button', { class: 'tm-chip tm-reset', onClick: () => prefs.clear(s.id), 'data-tip': TR.i18n.t('Your choice|Use the default from {by} again.', { by: src.managed }) }, TR.icon('undo', 12), TR.i18n.t('Use {by} default', { by: src.managed })) : null;
                  return h('div', { class: 'st-control' }, badge, src.kind === 'locked' ? h('div', { class: 'st-locked', inert: '' }, s.control()) : s.control());
                })()))));
          }))));
  }

  TR.pages.register({ id: 'settings', title: 'Settings', crumbs: () => [{ label: 'Settings' }], render });
  TR.pages.ui.slashFocus('.st-search input');
  TR.settingsPage = { SETTINGS, SECTIONS, state, visibleSettings, highlight };
})();
