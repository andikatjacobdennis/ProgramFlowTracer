/* Server calls: understand every request this session made, and resolve issues faster.
 *
 *   Header      Live session (or Paused) with the session's date and time range · Pause / Resume · Export report (JSON, CSV)
 *   Filters     time range · endpoint search · method · outcome · duration · More filters (source, simulated latency,
 *               clear the log) · Save view (remembered in this browser)
 *   Tiles       total calls · success rate · median latency · p95 latency, each with a sparkline over the time range and,
 *               for a time range, the change against the previous range of the same length
 *   Traffic     requests over time, or latency (median and p95) over time: one measure at a time, one axis
 *   Insights    findings computed from the calls: slow endpoints, failure spikes, how much of the time is simulated delay
 *   Calls       All / Failed / Slow, sortable by time and duration, paged
 *   Details     Overview · Request · Response · Timing. Timing is measured, never invented: for server calls the browser's
 *               network timing of that request; for simulated calls the simulated delay and the processing time.
 *
 * Everything comes from TR.server.apiLog: the simulated services and the server API both write to it. Nothing is sample
 * data. Tools → Server calls (and every older entry point) opens this page. */
(function () {
  'use strict';
  const { h } = TR.util;
  const J = TR.journey, t = J.t;
  const NS = 'http://www.w3.org/2000/svg';
  const svg = (tag, attrs = {}, kids = []) => { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs)) if (v != null) e.setAttribute(k, String(v)); [].concat(kids).flat(3).filter(Boolean).forEach((k) => e.appendChild(typeof k === 'string' ? document.createTextNode(k) : k)); return e; };
  const SLOW = 1000;                                          // a call of 1 s or more is slow
  const RANGES = [['session', 'Whole session'], ['60', 'Last 60 min'], ['15', 'Last 15 min'], ['5', 'Last 5 min']];
  const DEFAULTS = { range: 'session', q: '', method: '', outcome: '', duration: '', source: '' };
  const VIEW_KEY = () => 'trstudio.' + ((TR.backend && TR.backend.session && TR.backend.session.userId) || 'user') + '.serverCallsView';
  const C = Object.assign({ tab: 'all', sort: 'time', dir: 'desc', page: 0, size: 10, selected: null, detail: 'overview', chart: 'requests',
    paused: false, pausedAt: null, frozenId: 0, more: false, exportOpen: false, savedNote: false, insightsAll: false, linesAll: {} }, DEFAULTS, TR.util.store.get(VIEW_KEY(), {}));

  // ------------------------------------------------------------------ the data (pure; exported for tests)
  const METHODS = /^(GET|POST|PUT|PATCH|DELETE) +(.*)$/;
  /** The method and path of a log entry. Server API calls are named "GET api/v1/…"; simulated service calls are POSTs. */
  function parts(entry) {
    const m = METHODS.exec(entry.name || '');
    return m ? { method: m[1], path: '/' + m[2].replace(/^\/+/, '') } : { method: 'POST', path: '/' + String(entry.name || '').replace(/^\/+/, '') };
  }
  const outcome = (x) => (x.success === null || x.success === undefined ? 'pending' : x.success ? 'ok' : 'failed');
  const source = (x) => x.kind || (/^(GET|POST|PUT|PATCH|DELETE) api\/v1/.test(x.name || '') ? 'server' : 'simulated');
  const at = (x) => new Date(x.time).getTime();
  /** Calls matching the filters (not the tab), oldest first. */
  function matching(log, f) {
    const q = String(f.q || '').trim().toLowerCase();
    return log.filter((x) => (!q || x.name.toLowerCase().includes(q))
      && (!f.method || parts(x).method === f.method)
      && (!f.outcome || outcome(x) === f.outcome)
      && (!f.source || source(x) === f.source)
      && (!f.duration || (f.duration === 'fast' ? outcome(x) !== 'pending' && x.ms < 300 : x.ms >= Number(f.duration))));
  }
  /** Back-compatible view used by the earlier page and its tests: newest first. */
  const filtered = (log, f) => matching(log, f).slice().reverse();
  function percentile(values, p) {
    const v = values.filter((n) => n != null).sort((a, b) => a - b);
    if (!v.length) return null;
    const i = (v.length - 1) * p, lo = Math.floor(i), hi = Math.ceil(i);
    return Math.round(v[lo] + (v[hi] - v[lo]) * (i - lo));
  }
  /** Totals for a set of calls. Latency and success rate count finished calls only. */
  function summary(calls) {
    const done = calls.filter((x) => outcome(x) !== 'pending'), ok = done.filter((x) => x.success).length;
    return { total: calls.length, done: done.length, ok, failed: done.length - ok, rate: done.length ? (ok / done.length) * 100 : null,
      median: percentile(done.map((x) => x.ms), 0.5), p95: percentile(done.map((x) => x.ms), 0.95) };
  }
  const STEPS = [1, 5, 10, 15, 30, 60, 120, 300, 600, 900, 1800].map((s) => s * 1000);
  /** Equal time buckets over [from, to]: at most `most` (60), on a round step. */
  function buckets(calls, from, to, most = 60) {
    const span = Math.max(60000, to - from), step = STEPS.find((s) => span / s <= most) || 3600000;
    const start = Math.floor(from / step) * step, n = Math.max(1, Math.ceil((to - start) / step));
    const out = Array.from({ length: n }, (_, i) => ({ from: start + i * step, to: start + (i + 1) * step, calls: [] }));
    for (const x of calls) { const i = Math.min(n - 1, Math.max(0, Math.floor((at(x) - start) / step))); out[i].calls.push(x); }
    return out.map((b) => Object.assign(b, summary(b.calls)));
  }
  /** Findings worth acting on, most important first. Each can apply a filter. */
  function insights(calls, latency) {
    const out = [], done = calls.filter((x) => outcome(x) !== 'pending');
    const slow = done.filter((x) => x.ms >= SLOW), failed = done.filter((x) => !x.success);
    if (slow.length) {
      const by = {}; slow.forEach((x) => { const p = parts(x).path; by[p] = (by[p] || 0) + 1; });
      const [path, n] = Object.entries(by).sort((a, b) => b[1] - a[1])[0];
      out.push({ tone: 'warning', icon: 'alert', title: n > 1 ? t('{n} slow calls share one endpoint', { n }) : t('A slow call'), text: t('Calls to {p} took 1 s or more.', { p: path }), action: t('Review slow requests'), apply: { tab: 'slow', q: path.replace(/^\//, '') } });
    }
    if (failed.length) {
      const by = {}; failed.forEach((x) => { const m = Math.floor(at(x) / 60000); by[m] = (by[m] || 0) + 1; });
      const [minute, n] = Object.entries(by).sort((a, b) => b[1] - a[1] || a[0] - b[0])[0];
      const from = new Date(Number(minute) * 60000);
      out.push({ tone: 'danger', icon: 'alert', title: n > 1 ? t('Failure spike at {t}', { t: hm(from) }) : t('A failed call at {t}', { t: hm(from) }),
        text: t(n === 1 ? '1 failed call ({p} of the shown calls) between {a} and {b}.' : '{n} failed calls ({p} of the shown calls) between {a} and {b}.', { n, p: pct((n / Math.max(1, done.length)) * 100), a: hm(from), b: hm(new Date(from.getTime() + 60000)) }), action: t('View failed calls'), apply: { tab: 'failed' } });
    }
    const sim = done.filter((x) => source(x) === 'simulated' && x.simLatency != null), total = sim.reduce((a, x) => a + x.ms, 0), delay = sim.reduce((a, x) => a + Math.min(x.ms, x.simLatency), 0);
    if (sim.length && total > 0 && delay / total >= 0.5) out.push({ tone: 'info', icon: 'info', title: t('Most of the time is simulated delay'), text: t('The simulated latency ({l} ms) makes up {p} of the time of simulated calls. Lower it under More filters to work faster.', { l: latency, p: pct((delay / total) * 100) }), action: t('Show settings'), apply: { more: true } });
    if (done.length && !slow.length && !failed.length) out.push({ tone: 'good', icon: 'check', title: done.length === 1 ? t('The call succeeded') : t('All {n} calls succeeded', { n: done.length }), text: t(done.length === 1 ? 'It took less than 1 s.' : 'None took 1 s or more.') });
    return out;
  }

  // ------------------------------------------------------------------ formatting
  const zone = () => { try { return TR.culture.active(); } catch (e) { return {}; } };
  const fmt = (d, opts) => { const z = zone(); try { return new Intl.DateTimeFormat(z.language || undefined, Object.assign({ timeZone: z.timeZone || undefined, hourCycle: ['h11', 'h12', 'h23', 'h24'].includes(z.hourCycle) ? z.hourCycle : undefined }, opts)).format(d); } catch (e) { return new Date(d).toLocaleString(); } };
  const hm = (d) => fmt(d, { hour: '2-digit', minute: '2-digit' });
  const hms = (d) => fmt(d, { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const day = (d) => fmt(d, { day: 'numeric', month: 'short', year: 'numeric' });
  const zoneAbbr = () => { const z = zone(); try { return TR.culture.zoneName({ timeZone: z.timeZone, language: z.language, country: z.country }); } catch (e) { return ''; } };
  const pct = (n) => (n == null ? '—' : (Math.round(n * 10) / 10).toLocaleString(zone().language || undefined) + ' %');
  const ms = (n) => (n == null ? '—' : n.toLocaleString(zone().language || undefined) + ' ms');

  // ------------------------------------------------------------------ the page
  function data() {
    const all = TR.server.apiLog.filter((x) => !C.paused || x.id <= C.frozenId);
    const now = C.paused ? C.pausedAt : Date.now();
    const minutes = C.range === 'session' ? null : Number(C.range);
    const first = all.length ? at(all[0]) : now;
    const from = minutes ? now - minutes * 60000 : first, to = now;
    const inRange = all.filter((x) => at(x) >= from && at(x) <= to + 1000);
    const calls = matching(inRange, C);
    const prev = minutes ? matching(all.filter((x) => at(x) >= from - minutes * 60000 && at(x) < from), C) : null;
    return { all, calls, prev, from, to, now, minutes, fresh: C.paused ? TR.server.apiLog.filter((x) => x.id > C.frozenId).length : 0 };
  }
  const set = (patch) => { Object.assign(C, patch); TR.app.refresh(); };

  function header(d) {
    const live = !C.paused;
    const first = d.all.length ? new Date(at(d.all[0])) : new Date(d.now);
    const span = `${day(first)} · ${hm(first)}–${hm(new Date(d.now))} ${zoneAbbr()}`.trim();
    return J.pageHead('Server calls', 'Understand every request. Resolve issues faster.', [
      h('div', { class: ['sc-live', live ? 'is-live' : 'is-paused'], role: 'status' }, h('span', { class: 'sc-live-dot', 'aria-hidden': 'true' }),
        h('span', null, h('strong', null, t(live ? 'Live session' : 'Paused')), h('small', null, span))),
      C.paused && d.fresh ? TR.pages.ui.button((d.fresh === 1 ? t('1 new call') : t('{n} new calls', { n: d.fresh })), 'refresh', () => set({ paused: false }), 'secondary') : null,
      TR.pages.ui.button(t(live ? 'Pause' : 'Resume'), live ? 'pause' : 'play', () => set(live ? { paused: true, pausedAt: Date.now(), frozenId: TR.server.apiLog.length ? TR.server.apiLog[TR.server.apiLog.length - 1].id : 0 } : { paused: false }), 'secondary'),
      h('div', { class: 'sc-export' },
        TR.pages.ui.button(t('Export report'), 'download', () => set({ exportOpen: !C.exportOpen }), 'primary', { 'aria-expanded': String(C.exportOpen), 'aria-haspopup': 'menu' }),
        C.exportOpen ? h('div', { class: 'sc-export-menu', role: 'menu' },
          h('button', { role: 'menuitem', onClick: () => { exportJson(d.calls); set({ exportOpen: false }); } }, TR.icon('file', 15), t('Report (JSON)'), h('small', null, t('Summary, insights and every shown call'))),
          h('button', { role: 'menuitem', onClick: () => { exportCsv(d.calls); set({ exportOpen: false }); } }, TR.icon('grid', 15), t('Calls (CSV)'), h('small', null, t('One row per shown call')))) : null)]);
  }

  function filters() {
    const dirty = Object.keys(DEFAULTS).some((k) => String(C[k] || '') !== String(DEFAULTS[k]));
    return h('section', { class: 'jr-card sc-filters', 'aria-label': t('Filters') },
      h('div', { class: 'sc-filter-row' },
        J.select('Time', C.range, RANGES, (v) => set({ range: v, page: 0 })),
        h('label', { class: 'jr-search sc-search' }, TR.icon('search', 16), h('input', { type: 'search', key: 'sc-filter', placeholder: t('Search endpoints (e.g. /api/v1/vehicles)'), 'aria-label': t('Search endpoints'), value: C.q, onInput: (e) => { C.q = e.target.value; C.page = 0; J.later(() => TR.app.refresh(), 120); } })),
        J.select('Method', C.method, [['', 'All'], ['GET', 'GET'], ['POST', 'POST'], ['PUT', 'PUT'], ['PATCH', 'PATCH'], ['DELETE', 'DELETE']], (v) => set({ method: v, page: 0 })),
        J.select('Outcome', C.outcome, [['', 'All'], ['ok', 'Succeeded'], ['failed', 'Failed'], ['pending', 'Waiting']], (v) => set({ outcome: v, page: 0 })),
        J.select('Duration', C.duration, [['', 'Any'], ['fast', 'Under 300 ms'], ['300', '300 ms or more'], ['1000', '1 s or more']], (v) => set({ duration: v, page: 0 })),
        TR.pages.ui.button(t('More filters'), 'filter', () => set({ more: !C.more }), C.more || C.source ? 'secondary is-on' : 'secondary', { 'aria-expanded': String(C.more) }),
        h('span', { class: 'spacer' }),
        dirty ? h('button', { class: 'jr-link', onClick: () => set(Object.assign({}, DEFAULTS, { page: 0 })) }, t('Reset')) : null,
        h('button', { class: 'jr-link', onClick: saveView }, TR.icon('bookmark', 15), t(C.savedNote ? 'View saved' : 'Save view'))),
      C.more ? h('div', { class: 'sc-filter-row sc-more' },
        J.select('Source', C.source, [['', 'All'], ['server', 'Server API'], ['simulated', 'Simulated services']], (v) => set({ source: v, page: 0 })),
        h('label', { class: 'sc-latency' }, h('span', null, t('Simulated latency')),
          h('input', { type: 'range', min: 0, max: 1500, step: 50, value: TR.server.state.settings.latency, 'aria-valuetext': TR.server.state.settings.latency + ' ms', onChange: (e) => { TR.server.state.settings.latency = Number(e.target.value); TR.server.persist(); TR.app.refresh(); } }),
          h('output', null, TR.server.state.settings.latency + ' ms')),
        h('span', { class: 'spacer' }),
        TR.pages.ui.button(t('Clear the log'), 'close', clearLog, 'secondary')) : null);
  }
  /** Clears the log at once, with Undo for a few seconds instead of a confirmation. */
  function clearLog() {
    const kept = TR.server.apiLog.slice();
    TR.server.apiLog.length = 0; set({ selected: null, page: 0, paused: false });
    if (TR.notify) TR.notify.toast((kept.length === 1 ? t('Log cleared (1 call).') : t('Log cleared ({n} calls).', { n: kept.length })), 'info', { ms: 8000, action: { label: t('Undo'), run: () => { TR.server.apiLog.unshift(...kept); TR.app.refresh(); } } });
  }
  function saveView() {
    const v = {}; Object.keys(DEFAULTS).forEach((k) => { v[k] = C[k]; }); v.size = C.size; v.chart = C.chart;
    TR.util.store.set(VIEW_KEY(), v);
    set({ savedNote: true }); setTimeout(() => { C.savedNote = false; TR.app.refresh(); }, 1800);
  }

  // ------------------------------------------------------------------ tiles, sparklines and the traffic chart
  /**
   * A sparkline: bars for counts, a line with a soft area for rates and latency, both from zero (so a flat 100 % sits at the
   * top and a small change looks small). Fewer than three buckets with data say nothing useful: no sparkline then.
   */
  function spark(values, cls, top) {
    const pts = values.map((v, i) => [v, i]).filter(([v]) => v != null && (cls !== 'bars' || v > 0));
    if (pts.length < 3) return h('span', { class: 'sc-spark-none', 'aria-hidden': 'true' });
    const W = 110, H = 34, n = Math.max(1, values.length - 1), max = top || Math.max(1, ...pts.map(([v]) => v));
    const y = (v) => H - 2 - (v / max) * (H - 6), x = (i) => (i / n) * (W - 4) + 2;
    if (cls === 'bars') {
      const cw = W / values.length, bw = Math.max(1, Math.min(6, cw - 2));
      return svg('svg', { viewBox: `0 0 ${W} ${H}`, class: 'sc-spark', 'aria-hidden': 'true' },
        values.map((v, i) => (v ? svg('path', { d: barPath(i * cw + (cw - bw) / 2, y(v), bw, H - 2, Math.min(2, bw / 2)) }) : null)));
    }
    const line = pts.map(([v, i]) => `${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' L');
    const [lv, li] = pts[pts.length - 1];
    return svg('svg', { viewBox: `0 0 ${W} ${H}`, class: 'sc-spark sc-spark-line', 'aria-hidden': 'true' }, [
      svg('path', { class: 'sc-spark-area', d: `M${x(pts[0][1]).toFixed(1)},${H - 2} L${line} L${x(li).toFixed(1)},${H - 2} Z` }),
      svg('path', { class: 'sc-spark-stroke', d: 'M' + line }),
      svg('circle', { class: 'sc-spark-end', cx: x(li), cy: y(lv), r: 2.5 })]);
  }
  /** The bucket size in words: "5 s", "1 min". */
  const bucketText = (bs) => { const sec = bs.length ? (bs[0].to - bs[0].from) / 1000 : 60; return sec < 60 ? sec + ' s' : sec / 60 + ' min'; };
  /** A bar from the baseline up to y, its top corners rounded (the data end), the base square. */
  function barPath(x, y, w, base, r) {
    const hgt = base - y; r = Math.max(0, Math.min(r, w / 2, hgt));
    return `M${x},${base} V${y + r} Q${x},${y} ${x + r},${y} H${x + w - r} Q${x + w},${y} ${x + w},${y + r} V${base} Z`;
  }
  /** Axis ticks from zero on a round step (1, 2 or 5 × 10ⁿ), about four intervals. Counts get whole steps and at least 0–4,
   *  so one call is a short bar, not a full-height block. Pure. */
  function ticks(maxValue, counts) {
    const v = counts ? Math.max(4, maxValue) : Math.max(1, maxValue), raw = v / 4, p = Math.pow(10, Math.floor(Math.log10(raw)));
    let step = [1, 2, 5, 10].map((m) => m * p).find((x) => x >= raw - 1e-9);
    if (counts) step = Math.max(1, Math.round(step));
    const out = []; for (let k = 0; k <= v + step - 1e-9 && out.length < 12; k += step) { out.push(Math.round(k * 1e6) / 1e6); if (k >= v - 1e-9) break; }
    return out;
  }
  function tiles(d, bs) {
    const s = summary(d.calls), p = d.prev && d.prev.length ? summary(d.prev) : null;
    const cmp = (now, before, better) => {
      if (!p || now == null || before == null || before === 0) return null;
      const ch = ((now - before) / before) * 100, good = better === 'up' ? ch >= 0 : ch <= 0;
      return h('span', { class: ['sc-delta', Math.abs(ch) < 0.05 ? '' : good ? 'is-good' : 'is-bad'] }, TR.icon(ch >= 0 ? 'up' : 'down', 13), pct(Math.abs(ch)).replace(' %', '%'), h('small', null, t('vs previous {m} min', { m: d.minutes })));
    };
    const tile = (label, value, delta, chart) => h('div', { class: 'jr-card sc-tile' }, h('span', { class: 'sc-tile-label' }, t(label)),
      h('div', { class: 'sc-tile-row' }, h('strong', { class: 'sc-tile-value' }, value), delta || (d.minutes ? null : h('small', { class: 'muted' }, t('this session'))), chart));
    return h('div', { class: 'sc-tiles' },
      tile('Total calls', s.total.toLocaleString(zone().language || undefined), cmp(s.total, p && p.total, 'up'), spark(bs.map((b) => b.total), 'bars')),
      tile('Success rate', pct(s.rate), cmp(s.rate, p && p.rate, 'up'), spark(bs.map((b) => b.rate), 'line', 100)),
      tile('Median latency', ms(s.median), cmp(s.median, p && p.median, 'down'), spark(bs.map((b) => b.median), 'line')),
      tile('p95 latency', ms(s.p95), cmp(s.p95, p && p.p95, 'down'), spark(bs.map((b) => b.p95), 'line')));
  }
  // The chart is drawn at the width it is shown at, so text stays 11 px and bars keep their size; a resize redraws it.
  // The page may keep or replace the element on a redraw, so the live one is looked up once the redraw is done.
  let chartW = 760, sizer = null, watched = null;
  function watchWidth() {
    if (typeof ResizeObserver !== 'function') return;
    setTimeout(() => {
      const el = document.querySelector('.sc-chart-wrap');
      if (!el) return;
      const fit = (w) => { w = Math.round(w); if (w > 200 && Math.abs(w - chartW) > 12) { chartW = w; TR.app.refresh(); return true; } return false; };
      if (fit(el.clientWidth) || el === watched) return;   // measured now; later size changes come from the observer
      if (sizer) sizer.disconnect();
      watched = el;
      sizer = new ResizeObserver(([e]) => fit(e.contentRect.width));
      sizer.observe(el);
    }, 0);
  }
  function traffic(bs, d) {
    const latency = C.chart === 'latency';
    const W = chartW, H = 260, R = 12, T = 14, B = 30, n = bs.length;
    const yt = ticks(Math.max(0, ...bs.map((b) => (latency ? b.p95 || 0 : b.total))), !latency), max = yt[yt.length - 1];
    const fmtTick = (v) => (latency ? (v >= 1000 ? (v / 1000).toLocaleString(zone().language || undefined) + ' s' : v.toLocaleString(zone().language || undefined)) : v.toLocaleString(zone().language || undefined));
    const L = 14 + Math.max(...yt.map((v) => fmtTick(v).length)) * 7, cw = (W - L - R) / n;
    const y = (v) => H - B - (v / max) * (H - B - T), x = (i) => L + i * cw;
    const grid = yt.map((v) => [svg('line', { x1: L, x2: W - R, y1: y(v), y2: y(v), class: v ? 'sc-grid' : 'sc-baseline' }),
      svg('text', { x: L - 8, y: y(v) + 4, class: 'sc-axis', 'text-anchor': 'end' }, fmtTick(v))]);
    // time labels about every 110 px, never colliding
    const every = Math.max(1, Math.ceil(110 / cw));
    const label = n && bs[0].to - bs[0].from < 60000 ? hms : hm;   // seconds when the buckets are shorter than a minute
    const xl = bs.map((b, i) => (i % every === 0 && x(i) + cw / 2 < W - R - 30 ? [svg('line', { x1: x(i) + cw / 2, x2: x(i) + cw / 2, y1: H - B, y2: H - B + 4, class: 'sc-tick' }),
      svg('text', { x: x(i) + cw / 2, y: H - 10, class: 'sc-axis', 'text-anchor': 'middle' }, label(new Date(b.from)))] : null));
    let marks;
    if (!latency) {
      // Stacked: failed at the base, succeeded above it, a 2 px surface gap between them and between bars.
      const bw = Math.max(1, Math.min(18, cw * 0.7, cw - 2)), r = Math.min(4, bw / 2);
      marks = bs.map((b, i) => {
        if (!b.total) return null;
        const left = x(i) + (cw - bw) / 2, base = H - B, okN = b.total - b.failed;
        const out = [];
        if (b.failed) out.push(svg('path', { d: barPath(left, y(b.failed), bw, base, okN ? 0 : r), class: 'sc-bar-failed' }));
        if (okN) out.push(svg('path', { d: barPath(left, Math.min(y(b.total), (b.failed ? y(b.failed) - 2 : base) - 1), bw, b.failed ? y(b.failed) - 2 : base, r), class: 'sc-bar' }));
        return out;
      });
    } else {
      const line = (key, cls) => { const segs = []; let cur = []; bs.forEach((b, i) => { if (b[key] == null) { if (cur.length) segs.push(cur); cur = []; } else cur.push([x(i) + cw / 2, y(b[key])]); }); if (cur.length) segs.push(cur);
        const few = segs.reduce((a2, q) => a2 + q.length, 0) <= 30;   // few points: mark each one, so isolated buckets show
        return segs.map((q) => [q.length > 1 ? svg('path', { d: 'M' + q.map((pt) => pt.map((v) => v.toFixed(1)).join(',')).join(' L'), class: 'sc-line ' + cls }) : null,
          q.length === 1 || few ? q.map(([cx, cy]) => svg('circle', { cx, cy, r: 4, class: 'sc-pt ' + cls })) : null]); };
      const last = (key) => { for (let i = n - 1; i >= 0; i--) if (bs[i][key] != null) return [x(i) + cw / 2, y(bs[i][key])]; return null; };
      const lbl = (key, text, cls, dy) => { const p = last(key); return p ? svg('text', { x: p[0] > W - R - 60 ? p[0] - 8 : p[0] + 8, y: p[1] + dy, class: 'sc-direct ' + cls, 'text-anchor': p[0] > W - R - 60 ? 'end' : 'start' }, text) : null; };
      marks = [line('p95', 'sc-p95'), line('median', 'sc-median'), lbl('p95', 'p95', 'sc-p95', -8), lbl('median', t('median'), 'sc-median', 16)];
    }
    const cross = svg('line', { x1: 0, x2: 0, y1: T, y2: H - B, class: 'sc-cross', visibility: 'hidden' });
    const hits = bs.map((b, i) => svg('rect', { x: x(i), y: T, width: cw, height: H - B - T, fill: 'transparent', class: 'sc-hit', 'data-i': i }));
    const tip = h('div', { class: 'sc-tip', role: 'status', hidden: true });
    const chart = svg('svg', { viewBox: `0 0 ${W} ${H}`, width: W, height: H, class: 'sc-chart', role: 'img',
      'aria-label': latency ? t('Latency over time. Median {m}, p95 {p}.', { m: ms(summary(d.calls).median), p: ms(summary(d.calls).p95) }) : t('{n} calls over time; {f} failed.', { n: d.calls.length, f: summary(d.calls).failed }) },
      [grid, xl, marks, cross, hits].flat(3));
    const show = (e) => {
      const r = e.target.closest && e.target.closest('.sc-hit'); if (!r) return;
      const b = bs[Number(r.getAttribute('data-i'))], box = chart.getBoundingClientRect(), scale = box.width / W, cx = (x(Number(r.getAttribute('data-i'))) + cw / 2);
      cross.setAttribute('x1', cx); cross.setAttribute('x2', cx); cross.setAttribute('visibility', 'visible');
      tip.hidden = false;
      tip.replaceChildren(h('strong', null, `${hms(new Date(b.from))}–${hms(new Date(b.to))}`),
        h('span', null, (b.total === 1 ? t('1 call') : t('{n} calls', { n: b.total })) + (b.failed ? ' · ' + t('{n} failed', { n: b.failed }) : '')),
        b.median != null ? h('span', null, t('Median {m} · p95 {p}', { m: ms(b.median), p: ms(b.p95) })) : null);
      const left = cx * scale; tip.style.left = Math.min(box.width - 170, Math.max(0, left + 10)) + 'px';
    };
    const hide = () => { tip.hidden = true; cross.setAttribute('visibility', 'hidden'); };
    const wrap = h('div', { class: 'sc-chart-wrap', onMousemove: show, onMouseleave: hide }, chart, tip);
    watchWidth();
    return h('section', { class: 'jr-card sc-traffic' },
      h('div', { class: 'jr-card-head' }, h('div', null, h('h2', { class: 'jr-h3' }, t('Traffic & latency')),
        latency ? h('ul', { class: 'sc-legend' }, h('li', null, h('span', { class: 'sc-key sc-median' }), t('Median latency (ms)')), h('li', null, h('span', { class: 'sc-key sc-p95' }), t('p95 latency (ms)')))
          : h('ul', { class: 'sc-legend' }, h('li', null, h('span', { class: 'sc-key sc-bar' }), t('Succeeded')), h('li', null, h('span', { class: 'sc-key sc-bar-failed' }), t('Failed')), h('li', { class: 'muted' }, t('calls per {s}', { s: bucketText(bs) })))),
        h('div', { class: 'tp-seg sc-seg', role: 'group', 'aria-label': t('Measure') },
          [['requests', 'Requests'], ['latency', 'Latency']].map(([k, l]) => h('button', { type: 'button', class: C.chart === k ? 'is-on' : '', 'aria-pressed': String(C.chart === k), onClick: () => set({ chart: k }) }, t(l))))),
      d.calls.length ? wrap : J.empty('No calls in this range', 'Change the time range or the filters.'));
  }
  function insightsCard(d) {
    const list = insights(d.calls, TR.server.state.settings.latency), shown = C.insightsAll ? list : list.slice(0, 2);
    const tone = { warning: 'is-warning', danger: 'is-danger', info: 'is-info', good: 'is-good' };
    return h('section', { class: 'jr-card sc-insights' },
      h('div', { class: 'sc-insights-head' },
        h('div', null, h('h2', { class: 'jr-h3' }, t('Session insights')), h('p', { class: 'muted' }, t('Key findings from the shown calls.')),
          list.length > 2 ? h('button', { class: 'jr-link', onClick: () => set({ insightsAll: !C.insightsAll }) }, t(C.insightsAll ? 'Show fewer' : 'See all insights ({n})', { n: list.length }), TR.icon('arrow', 14)) : null),
        TR.personas && TR.personas.draw ? h('div', { class: 'sc-guide', 'aria-hidden': 'true' }, TR.personas.draw('think', 76, 'engineer')) : null),
      list.length ? h('ul', { class: 'sc-insight-list' }, shown.map((i) => h('li', { class: ['sc-insight', tone[i.tone]] },
        h('span', { class: 'sc-insight-icon', 'aria-hidden': 'true' }, TR.icon(i.icon, 16)),
        h('div', null, h('strong', null, i.title), h('p', null, i.text),
          i.apply ? h('button', { class: 'jr-link', onClick: () => set(Object.assign({ page: 0 }, i.apply)) }, i.action, TR.icon('arrow', 14)) : null))))
        : J.empty('Nothing to report yet', 'Insights appear once calls have finished.'));
  }

  // ------------------------------------------------------------------ the calls and the details
  const STATUS = { ok: ['check', 'Succeeded'], failed: ['alert', 'Failed'], pending: ['clock', 'Waiting'] };
  const status = (o) => h('span', { class: 'sc-status is-' + o }, TR.icon(STATUS[o][0], 14), t(STATUS[o][1]));
  const methodChip = (m) => h('span', { class: 'sc-method m-' + m.toLowerCase() }, m);
  function sortCalls(calls) {
    const k = C.sort === 'duration' ? (x) => (outcome(x) === 'pending' ? -1 : x.ms) : (x) => at(x) * 1000 + x.id;
    return calls.slice().sort((a, b) => (C.dir === 'asc' ? k(a) - k(b) : k(b) - k(a)));
  }
  function table(d) {
    const done = d.calls.filter((x) => outcome(x) !== 'pending');
    const counts = { all: d.calls.length, failed: done.filter((x) => !x.success).length, slow: done.filter((x) => x.ms >= SLOW).length };
    const tabbed = C.tab === 'failed' ? d.calls.filter((x) => outcome(x) === 'failed') : C.tab === 'slow' ? d.calls.filter((x) => outcome(x) !== 'pending' && x.ms >= SLOW) : d.calls;
    const list = sortCalls(tabbed), pages = Math.max(1, Math.ceil(list.length / C.size));
    if (C.page >= pages) C.page = pages - 1;
    const rows = list.slice(C.page * C.size, (C.page + 1) * C.size);
    if ((C.selected == null || !d.all.some((x) => x.id === C.selected)) && list.length) C.selected = list[0].id;
    const maxMs = Math.max(1, ...rows.map((x) => x.ms || 0));
    const sortBtn = (key, label) => h('button', { class: 'sc-sort', onClick: () => set({ sort: key, dir: C.sort === key && C.dir === 'desc' ? 'asc' : 'desc', page: 0 }), 'aria-label': t('Sort by {c}', { c: t(label) }) },
      t(label), C.sort === key ? TR.icon(C.dir === 'desc' ? 'down' : 'up', 13) : null);
    const th = (label, key) => h('th', { 'aria-sort': key && C.sort === key ? (C.dir === 'desc' ? 'descending' : 'ascending') : null }, key ? sortBtn(key, label) : t(label));
    const row = (x) => {
      const p = parts(x), o = outcome(x), on = x.id === C.selected;
      const pick = () => set({ selected: x.id });
      return h('tr', { class: ['sc-row', on && 'is-selected'], 'aria-selected': String(on), tabindex: 0, onClick: pick, onKeydown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); pick(); } } },
        h('td', { class: 'sc-time' }, hms(new Date(at(x)))), h('td', null, methodChip(p.method)), h('td', { class: 'sc-path', title: p.path }, p.path),
        h('td', { class: 'sc-ms' }, o === 'pending' ? '…' : ms(x.ms)), h('td', null, status(o)),
        h('td', { class: 'sc-latency-cell' }, o === 'pending' ? null : h('span', { class: ['sc-lat', 'is-' + o], 'aria-hidden': 'true' }, h('span', { style: { width: Math.max(3, Math.round((x.ms / maxMs) * 100)) + '%' } })), o === 'pending' ? null : h('span', { class: 'sc-lat-n' }, String(x.ms))));
    };
    const pageList = []; for (let i = 0; i < pages; i++) if (i < 2 || i >= pages - 1 || Math.abs(i - C.page) <= 1) pageList.push(i); else if (pageList[pageList.length - 1] !== '…') pageList.push('…');
    return h('section', { class: 'jr-card sc-calls', 'aria-label': t('Calls') },
      h('div', { class: 'jr-tabs', role: 'tablist', 'aria-label': t('Calls') }, [['all', 'All calls'], ['failed', 'Failed'], ['slow', 'Slow']].map(([k, l]) =>
        h('button', { role: 'tab', 'aria-selected': String(C.tab === k), class: C.tab === k ? 'is-on' : '', onClick: () => set({ tab: k, page: 0 }), title: k === 'slow' ? t('1 s or more') : null }, t(l), h('span', { class: 'sc-count ' + (counts[k] ? 'is-' + k : 'is-zero') }, String(counts[k]))))),
      rows.length ? h('div', { class: 'jr-table-wrap' }, h('table', { class: 'jr-table sc-table' },
        h('thead', null, h('tr', null, th('Time', 'time'), th('Method'), th('Endpoint'), th('Duration', 'duration'), th('Status'), th('Latency (ms)'))),
        h('tbody', null, rows.map(row))))
        : J.empty(TR.server.apiLog.length ? 'No calls match' : 'No calls yet', TR.server.apiLog.length ? 'Change the tab, the time range or the filters.' : 'Calls appear here as you load vehicles, validate and compare.'),
      list.length ? h('footer', { class: 'jr-pager sc-pager' }, h('span', { class: 'muted' }, t('Showing {a}–{b} of {n} calls', { a: C.page * C.size + 1, b: Math.min(list.length, (C.page + 1) * C.size), n: list.length })),
        h('span', { class: 'spacer' }),
        h('button', { class: 'ap-icon-btn', 'aria-label': t('Previous page'), disabled: C.page === 0, onClick: () => set({ page: C.page - 1 }) }, TR.icon('left', 15)),
        pageList.map((i) => (i === '…' ? h('span', { class: 'muted' }, '…') : h('button', { class: ['sc-page', i === C.page && 'is-on'], 'aria-current': i === C.page ? 'page' : null, onClick: () => set({ page: i }) }, String(i + 1)))),
        h('button', { class: 'ap-icon-btn', 'aria-label': t('Next page'), disabled: C.page >= pages - 1, onClick: () => set({ page: C.page + 1 }) }, TR.icon('right', 15)),
        J.select('Per page', C.size, [[10, '10'], [25, '25'], [50, '50']], (v) => set({ size: Number(v), page: 0 }))) : null);
  }

  /** JSON with line numbers and a Copy button; long bodies show the first 300 lines until expanded. */
  function code(id, value) {
    const text = JSON.stringify(value == null ? null : value, null, 2) || 'null', lines = text.split('\n'), all = !!C.linesAll[id], shown = all ? lines : lines.slice(0, 300);
    return h('div', { class: 'sc-code' },
      h('div', { class: 'sc-code-head' }, h('span', null, '{ } JSON'), h('span', { class: 'muted' }, t('{n} lines', { n: lines.length })),
        h('button', { class: 'jr-link', onClick: async (e) => { await TR.util.copyText(text); e.currentTarget.textContent = t('Copied'); } }, TR.icon('copy', 14), t('Copy'))),
      h('pre', { class: 'sc-pre', tabindex: 0 }, shown.map((l, i) => h('span', { class: 'sc-line' }, h('span', { class: 'sc-ln', 'aria-hidden': 'true' }, String(i + 1)), l + '\n'))),
      lines.length > 300 && !all ? h('button', { class: 'jr-link', onClick: () => { C.linesAll[id] = true; TR.app.refresh(); } }, t('Show all {n} lines', { n: lines.length })) : null);
  }
  /** The measured parts of a call's duration. */
  function timing(x) {
    const total = x.ms || 0;
    if (source(x) === 'simulated') {
      const delay = Math.min(total, x.simLatency || 0);
      return { total, parts: [['Simulated network delay', delay, 'sc-t1'], ['Processing in the browser simulator', Math.max(0, total - delay), 'sc-t2']], note: t('Simulated services run in the browser: the delay is the simulated latency setting, the rest is the time to compute the answer.') };
    }
    let e = null;
    try { e = (performance.getEntriesByName(x.url || '') || []).filter((r) => r.startTime >= (x.t0 || 0) - 5).sort((a, b) => a.startTime - b.startTime)[0] || null; } catch (err) { e = null; }
    if (!e || !e.responseEnd) return { total, parts: [['Request and response', total, 'sc-t1']], note: t('The browser kept no network timing for this call (it is cleared after many requests).') };
    const connect = Math.max(0, (e.connectEnd - e.domainLookupStart) || 0), wait = Math.max(0, e.responseStart - e.requestStart), down = Math.max(0, e.responseEnd - e.responseStart);
    const queue = Math.max(0, (e.requestStart || e.startTime) - e.startTime - connect), app = Math.max(0, total - (e.responseEnd - e.startTime));
    return { total, parts: [['Waiting for the server (server time and network)', wait, 'sc-t1'], ['Download', down, 'sc-t2'], ['Connection', connect, 'sc-t3'], ['Queueing', queue, 'sc-t4'], ['Reading the answer in the app', app, 'sc-t5']].filter(([, v]) => v >= 0.5).map(([l, v, c]) => [l, Math.round(v), c]),
      note: t('Measured by the browser for this request (Resource Timing).') };
  }
  function details(d) {
    const sel = d.all.find((x) => x.id === C.selected);
    if (!sel) return h('section', { class: 'jr-card sc-detail' }, J.empty('Choose a call', 'Its overview, request, response and timing appear here.'));
    const p = parts(sel), o = outcome(sel), src = source(sel);
    const code1 = src === 'server' ? (sel.status ? `${sel.status} ${sel.statusText || ''}`.trim() : t(o === 'pending' ? 'Waiting' : 'No answer')) : t('Simulated');
    const errs = sel.response && (sel.response.errors && sel.response.errors.length ? sel.response.errors.join(' ') : sel.response.detail || '');
    const tm = timing(sel), sum = Math.max(1, tm.parts.reduce((a, q) => a + q[1], 0));
    const general = J.facts([['Request ID', '#' + sel.id], ['Source', t(src === 'server' ? 'Server API' : 'Simulated service')], ['Session', t(C.paused ? 'Paused' : 'Live session')],
      ['Request time', hms(new Date(at(sel)))], ['Date', day(new Date(at(sel)))], ['Time zone', (zone().timeZone || '') + (zoneAbbr() ? ' (' + zoneAbbr() + ')' : '')]]);
    const body = {
      overview: h('div', { class: 'sc-pane' },
        o === 'failed' && errs ? J.banner('danger', 'alert', String(errs)) : null,
        J.facts([['Endpoint', p.path], ['Method', p.method], ['Outcome', t(STATUS[o][1])], ['Status', code1], ['Duration', o === 'pending' ? '…' : ms(sel.ms)], ['Started', day(new Date(at(sel))) + ', ' + hms(new Date(at(sel)))]]),
        h('h3', { class: 'jr-h4' }, t('General')), general),
      request: h('div', { class: 'sc-pane' }, code('req-' + sel.id, sel.params || {})),
      response: h('div', { class: 'sc-pane' }, sel.response ? code('res-' + sel.id, sel.response) : h('p', { class: 'muted' }, t(o === 'pending' ? 'Waiting for the response…' : 'No response body.'))),
      timing: h('div', { class: 'sc-pane' },
        h('h3', { class: 'jr-h4' }, t('Duration breakdown')), h('div', { class: 'sc-total' }, t('Total'), h('strong', null, ms(tm.total))),
        h('div', { class: 'sc-stack', role: 'img', 'aria-label': tm.parts.map(([l, v]) => `${t(l)} ${v} ms`).join(', ') }, tm.parts.map(([l, v, c]) => (v ? h('span', { class: c, style: { width: (v / sum) * 100 + '%' }, title: `${t(l)}: ${v} ms` }) : null))),
        h('ul', { class: 'sc-keys' }, tm.parts.map(([l, v, c]) => h('li', null, h('span', { class: 'sc-key ' + c }), h('span', null, t(l)), h('strong', null, v + ' ms'), h('span', { class: 'muted' }, Math.round((v / sum) * 100) + '%')))),
        h('p', { class: 'muted jr-small' }, tm.note),
        h('h3', { class: 'jr-h4' }, t('General')), general),
    };
    return h('section', { class: 'jr-card sc-detail', 'aria-label': t('Call details') },
      h('div', { class: 'sc-detail-head' }, methodChip(p.method), h('strong', { class: 'sc-endpoint', title: p.path }, p.path), status(o)),
      h('div', { class: 'sc-detail-sub' }, h('span', { class: 'sc-code-chip is-' + o }, code1), h('span', null, TR.icon('clock', 14), o === 'pending' ? '…' : ms(sel.ms)), h('span', null, TR.icon('calendar', 14), day(new Date(at(sel))) + ', ' + hms(new Date(at(sel))))),
      h('div', { class: 'jr-tabs', role: 'tablist', 'aria-label': t('Call details') }, [['overview', 'Overview'], ['request', 'Request'], ['response', 'Response'], ['timing', 'Timing']].map(([k, l]) =>
        h('button', { role: 'tab', 'aria-selected': String(C.detail === k), class: C.detail === k ? 'is-on' : '', onClick: () => set({ detail: k }) }, t(l)))),
      body[C.detail] || body.overview);
  }

  // ------------------------------------------------------------------ export
  const rowOf = (x) => { const p = parts(x); return { id: x.id, time: new Date(at(x)).toISOString(), method: p.method, endpoint: p.path, source: source(x), outcome: outcome(x), status: x.status || null, durationMs: outcome(x) === 'pending' ? null : x.ms }; };
  const stamp = () => new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-');
  function exportJson(calls) {
    const s = summary(calls);
    const report = { generatedAt: new Date().toISOString(), filters: Object.fromEntries(Object.keys(DEFAULTS).map((k) => [k, C[k]])), summary: s,
      insights: insights(calls, TR.server.state.settings.latency).map((i) => ({ title: i.title, text: i.text })), calls: calls.map((x) => Object.assign(rowOf(x), { request: x.params || null, response: x.response || null })) };
    TR.util.download(`server-calls-${stamp()}.json`, JSON.stringify(report, null, 2), 'application/json');
  }
  function exportCsv(calls) {
    TR.util.download(`server-calls-${stamp()}.csv`, J.csv([['Id', 'Time', 'Method', 'Endpoint', 'Source', 'Outcome', 'Status', 'Duration (ms)']].concat(calls.map((x) => { const r = rowOf(x); return [r.id, r.time, r.method, r.endpoint, r.source, r.outcome, r.status ?? '', r.durationMs ?? '']; }))), 'text/csv');
  }

  function render() {
    const d = data(), bs = buckets(d.calls, d.from, d.to);
    return h('div', { class: 'jr-page sc-page', onKeydown: (e) => { if (e.key === 'Escape' && C.exportOpen) set({ exportOpen: false }); } }, header(d), filters(), tiles(d, buckets(d.calls, d.from, d.to, 24)),
      h('div', { class: 'sc-mid' }, traffic(bs, d), insightsCard(d)),
      h('div', { class: 'sc-split' }, table(d), details(d)));
  }

  TR.pages.register({ id: 'calls', title: 'Server calls', crumbs: () => [{ label: t('Expert tools') }, { label: t('Server calls') }], render });
  // Follow new and finished calls while the page is open and not paused (both the simulated services and the server API
  // notify the log). A burst of calls re-renders once.
  if (TR.server && TR.server.onLog) TR.server.onLog(TR.util.debounce(() => { if (!C.paused && TR.pages.current && TR.pages.current() === 'calls') TR.app.refresh(); }, 250));
  // Every way in opens the page; the drawer is no longer shown.
  if (TR.uiDrawer) { TR.uiDrawer.open = false; TR.uiDrawer.toggle = () => J.open('calls'); }
  TR.serverCalls = { C, parts, outcome, source, filtered, matching, summary, percentile, buckets, insights, timing, ticks, barPath };
})();
