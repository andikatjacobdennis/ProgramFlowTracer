/* Change impact: understand a proposal before you validate it (server: POST /api/v1/impact).
 *
 *   Topology       the vehicle as a tree, as deep as its data goes: zones (T3 computers; legacy Cab, Chassis), computers,
 *                  then their parts. Legacy: Hardware (ECU hardware, sub-hardware), Software (main software, bootloaders,
 *                  complementary software) and Data sets with their patches. T3: logical ECUs, execution environments
 *                  and software products. "Levels" opens a depth; every card with contents opens on its own too.
 *   Change impact  the same tree narrowed to what changes and what it touches, with compatibility relationships drawn as
 *                  dashed arrows. Relationships come from the catalog (a node template's dependsOn and a version's requires);
 *                  their state comes only from a validation of this exact proposal: Verified, Blocked or Not yet verified.
 *   Compare        every changed property, original against proposed.
 *
 * The proposal is the workspace (when its vehicle is loaded), a validation's proposal (?rid=) or the vehicle as stored.
 * Cards are buttons (Tab, arrow keys between cards, Enter selects); the selected card's details sit on the right. Zoom,
 * Fit view and search do not change the data. layout() is pure and tested in tests/frontend/journey.cjs. */
(function () {
  'use strict';
  const { h } = TR.util;
  const J = TR.journey, t = J.t;
  const NS = 'http://www.w3.org/2000/svg';
  const svg = (tag, attrs = {}, kids = []) => { const e = document.createElementNS(NS, tag); for (const [k, v] of Object.entries(attrs)) if (v != null) e.setAttribute(k, String(v)); [].concat(kids).filter(Boolean).forEach((k) => e.appendChild(k)); return e; };
  // The tree opens at 70 %; Fit view (fitAsked) scales it to the width once. orient: 'tb' top to bottom or 'lr' left to right (remembered).
  const ZOOM = 0.7;
  const G = { key: null, data: null, error: null, view: 'impact', filter: 'affected', q: '', zoom: ZOOM, selected: null, open: new Set(), depth: '6', vehicles: null, fit: true, fitAsked: false,
    orient: TR.util.store.get('trstudio.impactOrient', 'tb') === 'lr' ? 'lr' : 'tb' };

  function workspaceProduct(vid) {
    try {
      const L = TR.app.shell.left;
      if (!L || !L.product.loaded()) return null;
      const p = L.getCurrentSelectedProduct ? L.getCurrentSelectedProduct() : null;
      const info = p && p.productSpecification && p.productSpecification.productInformation;
      return info && (!vid || (info.chassisSeries + '|' + Number(info.chassisNumber)) === vid) ? p : null;
    } catch (e) { return null; }
  }
  async function load(vid, rid) {
    G.key = vid + '|' + (rid || ''); G.data = null; G.error = null; TR.app.refresh();
    try {
      const product = rid ? null : workspaceProduct(vid);
      G.data = await J.api('/impact', { method: 'POST', body: { vehicleId: vid, requestId: rid || null, product } });
      const first = G.data.modules.find((m) => m.status === 'changed') || G.data.modules[0];
      G.selected = first ? first.key : null;
      // Opened at first: every level, down to the patches (Levels narrows it).
      const root = fullTree(G.data, { view: G.view, filter: G.filter });
      G.open = openTo(root, 6); G.depth = '6';
      G.fit = true; G.zoom = ZOOM;
    } catch (e) { G.error = e.message; }
    TR.app.refresh();
  }
  async function vehicles() { if (G.vehicles) return; try { G.vehicles = (await J.api('/vehicles/search?take=200')).items; } catch (e) { G.vehicles = []; } TR.app.refresh(); }

  // ------------------------------------------------------------------ the tree (pure; exported for tests)
  const AFFECTED = new Set(['changed', 'added', 'removed', 'check', 'verified', 'blocked', 'missing']);
  const CHANGED = new Set(['changed', 'added', 'removed']);
  const SIZE = { vw: 250, vh: 72, mw: 232, mh: 76, cw: 196, ch: 92, gap: 24, cgap: 14, top: 24 };
  // Card size per level: vehicle, zone, computer, group, part, patch.
  const LEVEL = [{ w: 250, h: 72 }, { w: 220, h: 60 }, { w: 232, h: 76 }, { w: 214, h: 52 }, { w: 196, h: 58 }, { w: 178, h: 50 }];
  const sizeAt = (level) => LEVEL[Math.min(level, LEVEL.length - 1)];
  function visibleModules(modules, filter) {
    return modules.filter((m) => filter === 'all' || (filter === 'changed' ? CHANGED.has(m.status) : AFFECTED.has(m.status)));
  }
  const ZONES = { hpc: 'High-performance computers', cab: 'Cab', chassis: 'Chassis', other: 'Other computers', missing: 'Not on this vehicle' };
  /** The zone of a computer, from the vehicle data: T3 computers, or a legacy computer's cab flag (isCabNode) and node path. */
  const zoneOf = (m) => (m.status === 'missing' ? 'missing' : m.architecture === 'T3' ? 'hpc' : m.cab ? 'cab' : m.path ? 'chassis' : 'other');
  const worst = (list) => (list.some((s) => CHANGED.has(s)) ? 'changed' : list.some((s) => s === 'blocked') ? 'blocked' : list.some((s) => s === 'check') ? 'check' : list.some((s) => s === 'verified') ? 'verified' : 'unchanged');
  const version = (x) => (x.from && x.to && x.from !== x.to ? x.from + ' → ' + x.to : x.to || x.from || '');
  /**
   * The full tree: vehicle → zones → computers → parts (groups, then their parts, then patches), as the data has them.
   * Parts come from the server (module.parts); a response without them falls back to the software products (components).
   * In the change-impact view, parts that did not change are left out (unless filter is 'all').
   */
  function fullTree(data, opts) {
    const mods = opts.view === 'topology' ? data.modules : visibleModules(data.modules, opts.filter);
    const onlyChanges = opts.view !== 'topology' && opts.filter !== 'all';
    const part = (p, m, parent) => {
      const kids = (p.children || []).filter((c) => !onlyChanges || c.status !== 'unchanged');
      const sub = [p.label && p.label !== p.name ? t(p.label) : '', version(p), kids.length ? t('{n} item(s)', { n: kids.length }) : ''].filter(Boolean).join(' · ');
      const n = { id: parent + '/' + p.id, kind: p.kind, title: p.name, sub, status: p.status, ref: p, module: m };
      n.children = kids.map((c) => part(c, m, n.id));
      return n;
    };
    const zones = [];
    for (const m of mods) {
      const z = zoneOf(m);
      let zone = zones.find((x) => x.zone === z);
      if (!zone) { zone = { id: 'zone:' + z, kind: 'zone', zone: z, title: t(ZONES[z]), children: [] }; zones.push(zone); }
      const parts = (m.parts && m.parts.length ? m.parts : (m.components || []).map((c) => ({ id: 'sw:' + c.name, kind: 'package', label: 'Software product', name: c.name, from: c.from, to: c.to, status: c.status })))
        .filter((p) => !onlyChanges || p.status !== 'unchanged');
      const mod = { id: m.key, kind: 'module', title: m.short, sub: version(m), status: m.status, ref: m, module: m };
      mod.children = parts.map((p) => part(p, m, m.key));
      zone.children.push(mod);
    }
    const order = ['hpc', 'chassis', 'cab', 'other', 'missing'];
    zones.sort((a, b) => order.indexOf(a.zone) - order.indexOf(b.zone));
    zones.forEach((z) => { z.status = worst(z.children.map((c) => c.status)); z.sub = t('{n} computer(s)', { n: z.children.length }); });
    const root = { id: 'vehicle', kind: 'vehicle', title: data.vehicle.title, status: 'unchanged', children: zones };
    const index = (n, level, parent) => { n.level = level; n.parent = parent; n.children.forEach((c) => index(c, level + 1, n)); };
    index(root, 0, null);
    return root;
  }
  /** Ids to open so that a depth shows: 1 zones, 2 computers, 3 groups, 4 parts, 5 every level. */
  function openTo(root, depth) {
    const ids = new Set();
    (function walk(n) { if (n.level < depth && n.children.length) { ids.add(n.id); n.children.forEach(walk); } })(root);
    return ids;
  }
  /** Ids of the nodes that lead to a node matching q (so a search shows its matches). */
  function pathsTo(root, q) {
    const ids = new Set(), s = String(q || '').toLowerCase();
    if (!s) return ids;
    (function walk(n, chain) {
      if (n.level > 0 && (String(n.title) + ' ' + (n.sub || '')).toLowerCase().includes(s)) chain.forEach((x) => ids.add(x));
      n.children.forEach((c) => walk(c, chain.concat(n.id)));
    })(root, []);
    return ids;
  }
  /**
   * Positions: the vehicle, zones and computers as a top-down tree (a parent centred over its children; siblings 18 px apart,
   * zones 40 px); below a computer, its groups, parts and patches hang as an indented list, so the tree is only as wide as
   * its computers however deep it goes. Computer-to-computer relationships use lanes above the computer row. Pure.
   * Returns { width, height, nodes: [{ n, x, y, w, h, open, more }], links: [{ a, b, stacked }], edges: [{ e, d }], rowY }.
   */
  const STACK = 2, INDENT = 18, VGAP = 10;
  function layout(root, open, edges) {
    const visible = (n) => (open.has(n.id) ? n.children : []);
    const gapOf = (n) => (n.level === 0 ? 40 : 18);
    const lanes = (edges || []).length;
    const rowY = [24];
    for (let l = 1; l <= STACK; l++) rowY[l] = rowY[l - 1] + sizeAt(l - 1).h + (l === STACK ? 56 + lanes * 12 : 56);
    const W = new Map(), H = new Map();
    (function measure(n) {
      const kids = visible(n), s = sizeAt(n.level);
      kids.forEach(measure);
      if (n.level >= STACK) {   // an indented list under the card
        W.set(n, Math.max(s.w, ...kids.map((c) => INDENT + W.get(c))));
        H.set(n, s.h + kids.reduce((a, c) => a + VGAP + H.get(c), 0));
      } else {
        const inner = kids.reduce((a, c) => a + W.get(c), 0) + Math.max(0, kids.length - 1) * gapOf(n);
        W.set(n, Math.max(s.w, inner)); H.set(n, s.h);
      }
    })(root);
    const nodes = [], links = [], at = new Map();
    const put = (n, x, y) => { const s = sizeAt(n.level), kids = visible(n); const p = { n, x, y, w: s.w, h: s.h, open: kids.length > 0, more: n.children.length > 0 }; nodes.push(p); at.set(n.id, p); return p; };
    (function place(n, left, top) {
      if (n.level >= STACK) {
        const p = put(n, left, top);
        let y = top + p.h;
        visible(n).forEach((c) => { y += VGAP; place(c, left + INDENT, y); links.push({ a: n.id, b: c.id, stacked: true }); y += H.get(c); });
        return;
      }
      const s = sizeAt(n.level), w = W.get(n), kids = visible(n);
      // a computer column is left-aligned so its list hangs below it; levels above are centred over their children
      put(n, left + (w - s.w) / 2, rowY[n.level]);
      const inner = kids.reduce((a, c) => a + W.get(c), 0) + Math.max(0, kids.length - 1) * gapOf(n);
      let x = left + (w - inner) / 2;
      kids.forEach((c) => { place(c, x, rowY[c.level]); links.push({ a: n.id, b: c.id, stacked: false }); x += W.get(c) + gapOf(n); });
    })(root, 24, rowY[0]);
    const width = W.get(root) + 48;
    const height = Math.max(...nodes.map((p) => p.y + p.h)) + 32;
    const placedEdges = (edges || []).filter((e) => at.has(e.from) && at.has(e.to)).map((e, i) => {
      const a = at.get(e.from), b = at.get(e.to), lane = rowY[STACK] - 16 - i * 12;
      const ax = a.x + a.w / 2 + 10 + (i % 3) * 8, bx = b.x + b.w / 2 - 10 - (i % 3) * 8;
      return { e, d: `M${ax},${a.y} V${lane} H${bx} V${b.y - 6}` };
    });
    return { width, height, nodes, links: links.map((l) => ({ a: at.get(l.a), b: at.get(l.b), stacked: l.stacked })), edges: placedEdges, rowY, at };
  }

  /**
   * Left to right: one column per level (vehicle, zones, computers, groups, parts, patches), a parent centred beside its
   * children (siblings 12 px apart). Computer-to-computer relationships use lanes in the gap before the computer column. Pure.
   * Returns the same shape as layout(), with links marked lr.
   */
  const COLGAP = 56, ROWGAP = 12;
  function layoutLR(root, open, edges) {
    const visible = (n) => (open.has(n.id) ? n.children : []);
    const lanes = (edges || []).length;
    const colX = [24];
    for (let l = 1; l <= 6; l++) colX[l] = colX[l - 1] + sizeAt(l - 1).w + COLGAP + (l === STACK ? lanes * 12 : 0);
    const H = new Map();
    const inner = (kids) => kids.reduce((a, c) => a + H.get(c), 0) + Math.max(0, kids.length - 1) * ROWGAP;
    (function measure(n) { const kids = visible(n); kids.forEach(measure); H.set(n, Math.max(sizeAt(n.level).h, inner(kids))); })(root);
    const nodes = [], links = [], at = new Map();
    (function place(n, top) {
      const s = sizeAt(n.level), kids = visible(n), hh = H.get(n);
      const p = { n, x: colX[n.level], y: top + (hh - s.h) / 2, w: s.w, h: s.h, open: kids.length > 0, more: n.children.length > 0 };
      nodes.push(p); at.set(n.id, p);
      let y = top + (hh - inner(kids)) / 2;
      kids.forEach((c) => { place(c, y); links.push({ a: n.id, b: c.id }); y += H.get(c) + ROWGAP; });
    })(root, 24);
    const width = Math.max(...nodes.map((p) => p.x + p.w)) + 32, height = H.get(root) + 48;
    const placedEdges = (edges || []).filter((e) => at.has(e.from) && at.has(e.to)).map((e, i) => {
      const a = at.get(e.from), b = at.get(e.to), lane = colX[STACK] - 16 - i * 12, off = (i % 3) * 6 - 6;
      return { e, d: `M${a.x},${a.y + a.h / 2 + off} H${lane} V${b.y + b.h / 2 - off} H${b.x - 6}` };
    });
    return { width, height, nodes, links: links.map((l) => ({ a: at.get(l.a), b: at.get(l.b), lr: true })), edges: placedEdges, colX, at, orient: 'lr' };
  }

  // ------------------------------------------------------------------ the graph
  const ICON = { vehicle: 'truck', zone: 'layers', group: 'grid', 'logical-ecu': 'chip', environment: 'layers', package: 'package', hardware: 'cpu', subhardware: 'cpu', software: 'file', bootloader: 'shield', data: 'database', patch: 'pencil' };
  const GROUP_ICON = { 'g:hardware': 'cpu', 'g:software': 'file', 'g:data': 'database' };
  const iconOf = (n) => (n.kind === 'module' ? (n.ref.architecture === 'T3' ? 'chip' : 'cpu') : n.kind === 'group' ? GROUP_ICON[n.ref.id] || 'grid' : ICON[n.kind] || 'package');
  const current = { root: null, open: null, layout: null };
  function card(p, data) {
    const n = p.n, on = G.selected === n.id, plain = G.view === 'topology';
    const dim = G.q && !(String(n.title) + ' ' + (n.sub || '')).toLowerCase().includes(G.q.toLowerCase()) && n.level > 0;
    const st = plain || !n.status ? 'plain' : n.status;
    const sub = n.kind === 'vehicle' ? t('Revision {n}', { n: data.vehicle.revision }) + ' · ' + data.vehicle.architecture + (data.source === 'workspace' ? ' · ' + t('workspace proposal') : data.source === 'request' ? ' · ' + t('validated proposal') : '') : n.sub;
    return h('div', { class: ['ci-card', 'ci-' + n.kind, 'ci-l' + Math.min(n.level, 5), 'st-' + st, on ? 'is-sel' : '', dim ? 'is-dim' : ''], style: { left: p.x + 'px', top: p.y + 'px', width: p.w + 'px', height: p.h + 'px' } },
      h('button', { class: 'ci-hit', 'data-id': n.id, 'data-key': n.kind === 'module' ? n.id : null, 'aria-pressed': String(on), 'aria-level': n.level + 1, 'aria-expanded': p.more ? String(p.open) : null,
        'aria-label': t('{n}, {v}, {s}', { n: (n.kind === 'module' || n.kind === 'vehicle' || n.kind === 'zone' ? '' : (n.ref.label || '') + ' ') + n.title, v: sub || '', s: J.state(n.status || 'unchanged')[0] }), onClick: () => select(n.id), onKeydown: (e) => keys(e, n) },
        h('span', { class: 'ci-icon', 'aria-hidden': 'true' }, TR.icon(iconOf(n), n.level <= 2 ? 20 : 17)),
        h('span', { class: 'ci-text' }, h('strong', null, n.title), sub ? h('small', null, sub) : null, plain || !n.status || n.status === 'unchanged' || n.kind === 'vehicle' ? null : J.chip(n.status))),
      p.more && n.level > 0 ? h('button', { class: 'ci-expand', 'aria-expanded': String(p.open), 'aria-label': t(p.open ? 'Hide the contents of {n}' : 'Show the contents of {n}', { n: n.title }), onClick: () => toggle(n.id) }, TR.icon('chevron', 14), h('span', { class: 'ci-more-n' }, String(n.children.length))) : null);
  }
  function toggle(id) { if (G.open.has(id)) G.open.delete(id); else G.open.add(id); G.depth = 'custom'; G.fit = true; TR.app.refresh(); }
  function select(id) { G.selected = id; TR.app.refresh(); setTimeout(() => { const b = document.querySelector('.ci-hit[data-id="' + CSS.escape(id) + '"]'); if (b) b.focus(); }, 0); }
  function keys(e, n) {
    if (!['ArrowRight', 'ArrowLeft', 'ArrowUp', 'ArrowDown', 'Home', 'End'].includes(e.key)) return;
    e.preventDefault();
    // Left to right turns the keys too: Right opens the children, Left goes to the parent, Up and Down move between siblings.
    const key = G.orient === 'lr' ? ({ ArrowRight: 'ArrowDown', ArrowLeft: 'ArrowUp', ArrowDown: 'ArrowRight', ArrowUp: 'ArrowLeft' }[e.key] || e.key) : e.key;
    e = { key };
    if (e.key === 'ArrowUp') { if (n.parent && n.parent.level > 0) select(n.parent.id); return; }
    if (e.key === 'ArrowDown') { if (n.children.length) { if (!G.open.has(n.id)) { G.open.add(n.id); G.fit = true; } select(n.children[0].id); } return; }
    const sibs = n.parent ? n.parent.children : [n], i = sibs.indexOf(n);
    const next = e.key === 'Home' ? 0 : e.key === 'End' ? sibs.length - 1 : Math.max(0, Math.min(sibs.length - 1, i + (e.key === 'ArrowRight' ? 1 : -1)));
    if (sibs[next]) select(sibs[next].id);
  }
  const DEPTHS = [['2', 'Computers'], ['3', 'Groups'], ['4', 'Parts'], ['6', 'All levels']];
  function graph(data) {
    const root = fullTree(data, { view: G.view, filter: G.filter });
    const open = new Set([...G.open, ...pathsTo(root, G.q)]);
    open.add('vehicle');
    const edges = G.view !== 'topology' ? data.edges : [];
    const L = G.orient === 'lr' ? layoutLR(root, open, edges) : layout(root, open, edges);
    current.root = root; current.layout = L;
    // "Contains" is a plain tree connector, without arrowheads: an arrow means a relationship with a direction (the
    // compatibility edges below), as in the legend. Below a computer: an elbow from the parent's left into each child's
    // left edge, rounded at the bend. Above: a parent-to-children bus, square, meeting the top of each card.
    const R = 6;
    const lines = L.links.map(({ a, b, stacked, lr }) => {
      // Left to right: from the parent's right edge, across half the gap, down or up to the child, into its left edge.
      if (lr) { const ax = a.x + a.w, ay = a.y + a.h / 2, mx = ax + COLGAP / 2, by = b.y + b.h / 2; return svg('path', { d: `M${ax},${ay} H${mx} V${by} H${b.x}`, class: 'ci-contains' }); }
      if (stacked) { const ax = a.x + 10, my = b.y + b.h / 2; return svg('path', { d: `M${ax},${a.y + a.h} V${my - R} Q${ax},${my} ${ax + R},${my} H${b.x}`, class: 'ci-contains' }); }
      const ax = a.x + a.w / 2, ay = a.y + a.h, bus = ay + 22, bx = b.x + b.w / 2;
      return svg('path', { d: `M${ax},${ay} V${bus} H${bx} V${b.y}`, class: 'ci-contains' });
    });
    L.edges.forEach(({ e, d }) => lines.push(svg('path', { d, class: 'ci-compat st-' + e.state, 'marker-end': 'url(#ci-arrow-' + e.state + ')' }, [svg('title', {}, [document.createTextNode(e.rule)])])));
    const defs = svg('defs', {}, ['', '-verified', '-blocked', '-not-verified'].map((k) => svg('marker', { id: 'ci-arrow' + k, viewBox: '0 0 10 10', refX: 8, refY: 5, markerWidth: 7, markerHeight: 7, orient: 'auto-start-reverse' }, [svg('path', { d: 'M0,0 L10,5 L0,10 z', class: 'ci-head' + (k ? ' st' + k : '') })])));
    const canvas = h('div', { class: 'ci-canvas', role: 'tree', 'aria-label': t('Topology of {v}', { v: data.vehicle.title }), style: { width: L.width + 'px', height: L.height + 'px', transform: 'scale(' + G.zoom + ')' } },
      svg('svg', { class: 'ci-lines', width: L.width, height: L.height, 'aria-hidden': 'true' }, [defs].concat(lines)),
      L.nodes.map((p) => card(p, data)));
    const scroller = h('div', { class: 'ci-scroll', tabindex: '-1' }, h('div', { class: 'ci-sizer', style: { width: L.width * G.zoom + 'px', height: L.height * G.zoom + 'px' } }, canvas));
    // Fit view: scale the tree to the width available (at most 100 %).
    // Only when asked (Fit view): otherwise the tree keeps its zoom, 70 % to start with.
    if (G.fit && G.fitAsked) setTimeout(() => { const el = document.querySelector('.ci-scroll'); if (!el || !G.fit) return; G.fit = false; G.fitAsked = false; const z = Math.min(1, Math.max(0.3, Math.min((el.clientWidth - 8) / L.width, G.orient === 'lr' ? (Math.max(360, el.clientHeight) - 8) / L.height : 1))); if (Math.abs(z - G.zoom) > 0.01) { G.zoom = Math.round(z * 100) / 100; TR.app.refresh(); } }, 0);
    const c = data.counts, computers = root.children.reduce((a, z) => a + z.children.length, 0);
    const levels = Math.max(...L.nodes.map((p) => p.n.level)) + 1;
    return h('div', { class: 'ci-graph' },
      h('div', { class: 'ci-badges' }, h('span', { class: c.changes ? 'jr-pill tone-info' : 'jr-pill' }, h('i', { class: 'ci-sq st-changed' }), t('{n} change(s)', { n: c.changes })),
        c.checks ? h('span', { class: 'jr-pill tone-warning' }, h('i', { class: 'ci-dot st-check' }), data.validation && data.validation.current ? t('{n} relationship check(s) from validation', { n: c.checks }) : t('{n} check(s) required', { n: c.checks })) : null,
        G.view !== 'topology' && computers < data.modules.length ? h('span', { class: 'muted' }, t('{a} of {b} nodes shown', { a: computers, b: data.modules.length })) : null,
        h('span', { class: 'spacer' }),
        // Direction of the tree: top to bottom (default) or left to right.
        h('div', { class: 'tp-seg ci-orient', role: 'group', 'aria-label': t('Direction') }, [['tb', 'Top to bottom', 'down'], ['lr', 'Left to right', 'arrow']].map(([k, l, ic]) =>
          h('button', { type: 'button', class: G.orient === k ? 'is-on' : '', 'aria-pressed': String(G.orient === k), title: t(l), onClick: () => { G.orient = k; TR.util.store.set('trstudio.impactOrient', k); TR.app.refresh(); } }, TR.icon(ic, 14), t(l)))),
        J.select('Levels', G.depth, (G.depth === 'custom' ? [['custom', 'As opened']] : []).concat(DEPTHS), (v) => { if (v === 'custom') return; G.depth = v; G.open = openTo(root, Number(v)); G.fit = true; TR.app.refresh(); }),
        h('span', { class: 'muted ci-levels', role: 'status' }, t('{n} levels shown', { n: levels }))),
      computers ? scroller : J.empty('Nothing changes', 'This proposal changes no node. Show all components to see the whole vehicle.', TR.pages.ui.button(t('Show all components'), 'grid', () => { G.filter = 'all'; G.fit = true; TR.app.refresh(); }, 'secondary')),
      h('div', { class: 'ci-foot' },
        h('div', { class: 'jr-legend' }, h('span', null, h('i', { class: 'ln-solid' }), t('Contains')), G.view !== 'topology' ? h('span', null, h('i', { class: 'ln-dashed' }), t('Compatibility relationship')) : null, h('span', null, h('i', { class: 'ci-sq st-changed' }), t('Changed')), h('span', null, h('i', { class: 'ci-dot st-check' }), t('Check required'))),
        h('div', { class: 'ci-zoom', role: 'group', 'aria-label': t('Zoom') },
          h('button', { class: 'ap-icon-btn', 'aria-label': t('Zoom out'), onClick: () => { G.zoom = Math.max(0.3, Math.round((G.zoom - 0.1) * 10) / 10); TR.app.refresh(); } }, '−'),
          h('span', { class: 'ci-zoom-v', 'aria-live': 'polite' }, Math.round(G.zoom * 100) + '%'),
          h('button', { class: 'ap-icon-btn', 'aria-label': t('Zoom in'), onClick: () => { G.zoom = Math.min(1.6, Math.round((G.zoom + 0.1) * 10) / 10); TR.app.refresh(); } }, '+'),
          TR.pages.ui.button(t('Fit view'), 'expand', () => { G.fit = true; G.fitAsked = true; TR.app.refresh(); }, 'secondary'))));
  }
  function compare(data) {
    return data.changes.length ? h('div', { class: 'jr-table-wrap' }, h('table', { class: 'jr-table' },
      h('thead', null, h('tr', null, ['Component', 'Property', 'The vehicle now', 'Your change', ''].map((c) => h('th', null, t(c))))),
      h('tbody', null, data.changes.filter((r) => !G.q || (r.component + ' ' + r.property).toLowerCase().includes(G.q.toLowerCase())).map((r) =>
        h('tr', null, h('td', null, r.component), h('td', null, t(r.property)), h('td', null, h('code', null, r.from || '—')), h('td', { class: 'jr-proposed' }, h('code', null, r.to || '—')), h('td', null, J.chip(r.kind)))))))
      : J.empty('No changes', 'The proposal is the same as the stored vehicle.');
  }
  function find(id) { let hit = null; (function walk(n) { if (!hit && n) { if (n.id === id) hit = n; else n.children.forEach(walk); } })(current.root); return hit; }
  function partSide(n) {
    const p = n.ref || {}, m = n.module;
    const chain = []; for (let x = n.parent; x && x.level > 0; x = x.parent) chain.unshift(x.title);
    return h('aside', { class: 'jr-side' },
      J.card(h('h2', null, t('Selected component')), null,
        h('div', { class: 'ci-sel' }, h('span', { class: 'ci-icon big', 'aria-hidden': 'true' }, TR.icon(iconOf(n), 26)), h('div', null, h('strong', { class: 'jr-big' }, n.title), n.status ? J.chip(n.status) : null)),
        J.facts([['Kind', p.label ? t(p.label) : t(ZONES[n.zone] || n.kind)], ['Where', chain.join(' › ') || null], n.kind === 'zone' ? ['Computers', String(n.children.length)] : null,
          p.from != null || p.to != null ? ['The vehicle now', p.from || '—'] : null, p.from != null || p.to != null ? ['Your change', p.to || '—'] : null, n.children.length && n.kind !== 'zone' ? ['Contains', t('{n} item(s)', { n: n.children.length })] : null]),
        n.children.length ? h('ul', { class: 'ci-impact' }, n.children.slice(0, 12).map((c) => h('li', null, h('button', { class: 'jr-row-link', onClick: () => { G.open.add(n.id); select(c.id); } },
          h('span', { class: 'ci-icon', 'aria-hidden': 'true' }, TR.icon(iconOf(c), 16)), h('span', null, h('strong', null, c.title), h('small', { class: 'muted' }, c.sub || '')))))) : null,
        m ? h('button', { class: 'jr-link', onClick: () => select(m.key) }, TR.icon('cpu', 14), t('Show computer {n}', { n: m.short })) : null));
  }
  function side(data) {
    const node = find(G.selected);
    if (node && node.kind !== 'module') return partSide(node);
    const m = data.modules.find((x) => x.key === G.selected);
    if (!m) return h('aside', { class: 'jr-side' }, J.card('Selected component', null, h('p', { class: 'muted' }, t('Choose a component in the graph.'))));
    const related = data.edges.filter((e) => e.from === m.key || e.to === m.key);
    const other = (e) => data.modules.find((x) => x.key === (e.from === m.key ? e.to : e.from));
    const text = { 'not-verified': 'Compatibility not yet verified', verified: 'Verified by validation of this proposal', blocked: 'Blocked: the validation found the dependency unsatisfied' };
    const v = data.validation;
    return h('aside', { class: 'jr-side' },
      J.card(h('h2', null, t('Selected component')), null,
        h('div', { class: 'ci-sel' }, h('span', { class: 'ci-icon big', 'aria-hidden': 'true' }, TR.icon(m.architecture === 'T3' ? 'chip' : 'cpu', 26)), h('div', null, h('strong', { class: 'jr-big' }, m.short), J.chip(m.status))),
        J.facts([['Node', m.name], ['Original version', m.from], ['Proposed version', m.to], ['ECU hardware', m.hardware]]),
        m.changes.length ? h('details', { class: 'ci-changes', open: true }, h('summary', null, t('{n} changed propert(ies)', { n: m.changes.length })),
          h('ul', null, m.changes.map((r) => h('li', null, h('span', null, r.component + ' · ' + t(r.property)), h('code', null, (r.from || '—') + ' → ' + (r.to || '—')))))) : null,
        m.findings.length ? h('div', { class: 'jr-finding' }, h('h3', { class: 'jr-h4' }, t('Validation findings')), h('ul', null, m.findings.map((f) => h('li', null, f.blocking ? J.chip('blocked') : J.chip('notes'), ' ', f.text)))) : null,
        h('h3', { class: 'jr-h4' }, t('Impact to review')),
        related.length ? h('ul', { class: 'ci-impact' }, related.map((e) => { const o = other(e); return h('li', null, h('button', { class: 'jr-row-link', onClick: () => o && select(o.key) },
          h('span', { class: 'ci-icon', 'aria-hidden': 'true' }, TR.icon('chip', 18)), h('span', null, h('strong', null, o ? o.short : e.to.replace('missing:', '')), h('small', { class: 'tone-' + J.state(e.state)[2] }, TR.icon(J.state(e.state)[1], 13), t(text[e.state] || e.state))))); }))
          : h('p', { class: 'muted' }, t('No catalog relationship touches this component.')),
        h('h3', { class: 'jr-h4' }, t('Why this is shown')),
        h('p', { class: 'muted' }, related.length ? related.map((e) => e.rule + (e.catalogRuleSatisfied ? '' : ' — ' + t('the catalog rule is not met by the proposal'))).join('. ') + '. ' : '',
          v && v.current ? t('Checks come from your validation of this proposal ({a}).', { a: J.ago(v.at) }) : t('Relationships come from the catalog. Validate this proposal to check them.')),
        h('button', { class: 'jr-link', onClick: () => { if (TR.experience) TR.experience.page = null; TR.testRequest.page('software'); } }, TR.icon('external', 14), t('Open software editor')),
        h('div', { class: 'jr-stack-row' },
          TR.pages.ui.button(t('Validate proposal'), 'play', () => { if (TR.experience) TR.experience.page = null; TR.testRequest.page(); TR.testRequest.stage = 'validate'; TR.app.refresh(); }, 'primary'),
          TR.pages.ui.button(t('Compare original'), 'compare', () => { G.view = 'compare'; TR.app.refresh(); }, 'secondary'))));
  }

  function render() {
    J.readParams();
    vehicles();
    let vid = J.param('vid', 'impact');
    const rid = J.param('rid', 'impact');
    if (!vid) { try { const L = TR.app.shell.left; if (L && L.product.loaded()) { const i = L.product.info(); vid = i.chassisSeries + '|' + Number(i.chassisNumber); } } catch (e) { /* none */ } }
    const head = J.pageHead('Change impact', 'Understand the proposal before you validate.');
    const picker = J.select('Vehicle', vid || '', [['', 'Choose a vehicle']].concat((G.vehicles || []).map((v) => [v.id, v.series + ' ' + v.number + (v.t3 ? ' · T3' : '')])), (v) => J.open('impact', { vid: v }), { class: 'jr-select ci-vehicle-pick' });
    if (!vid) return h('div', { class: 'jr-page' }, head, h('div', { class: 'jr-filters' }, picker), J.empty('Choose a vehicle', 'Load a vehicle in the workspace or choose one here to see what its proposal changes.'));
    const key = vid + '|' + (rid || '');
    if (key !== G.key) load(vid, rid);
    const d = G.data;
    const tools = h('div', { class: 'jr-filters' }, picker,
      h('div', { class: 'tp-seg jr-seg', role: 'tablist', 'aria-label': t('View') }, [['topology', 'Topology'], ['impact', 'Change impact'], ['compare', 'Compare']].map(([id, l]) =>
        h('button', { type: 'button', role: 'tab', 'aria-selected': String(G.view === id), class: G.view === id ? 'is-on' : '', onClick: () => { G.view = id; G.fit = true; if (d && id !== 'compare') { G.open = openTo(fullTree(d, { view: id, filter: G.filter }), G.depth === 'custom' ? 6 : Number(G.depth)); if (G.depth === 'custom') G.depth = '6'; } TR.app.refresh(); } }, t(l)))),
      J.search('Find a component', G.q, (v) => { G.q = v; J.later(() => TR.app.refresh(), 200); }),
      G.view === 'impact' ? J.select('Show', G.filter, [['affected', 'Changed + affected'], ['changed', 'Changed only'], ['all', 'All components']], (v) => { G.filter = v; G.fit = true; TR.app.refresh(); }) : null);
    if (!d) return h('div', { class: 'jr-page' }, head, tools, G.error ? J.failed(G.error, () => load(vid, rid)) : J.loading(5));
    return h('div', { class: 'jr-page ci-page' }, head, tools,
      d.validation && !d.validation.current ? J.banner('warning', 'alert', t('The vehicle changed after the validation of this proposal; relationship checks are not current. Validate again.')) : null,
      h('div', { class: 'jr-split' }, J.card(null, null, G.view === 'compare' ? compare(d) : graph(d)), side(d)),
      h('p', { class: 'jr-foot muted' }, TR.icon('info', 14), ' ', t('Relationships come from the catalog; a check is verified only by validating this exact proposal on the current vehicle revision.')));
  }
  TR.pages.register({ id: 'impact', title: 'Change impact', crumbs: () => [{ label: t('Workspace'), open: () => TR.testRequest.page() }, { label: t('Change impact') }], render });
  TR.impact = { G, load, layout, layoutLR, fullTree, openTo, pathsTo, zoneOf, visibleModules, SIZE, LEVEL, ZOOM };
})();
