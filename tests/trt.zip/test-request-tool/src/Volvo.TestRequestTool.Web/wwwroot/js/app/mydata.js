/* My data: everything the application knows about you, where it is kept, for how long, and what you can do about it.
 * Each kind of data has "Don't record from now on" where recording is optional, and "Delete" where deleting is possible.
 * Some records cannot be deleted by you because they protect others (the audit log, committed vehicle revisions); the page
 * says so and why. Offered at first sign-in (welcome) and always from the account menu and Settings → Privacy. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));
  const ui = () => TR.pages.ui;
  const D = { usage: null, prefs: null, feedback: null, revisions: null, jobs: null, loading: false, error: null };
  const session = () => (TR.backend && TR.backend.session) || {};
  async function get(path) { const r = await fetch('/api/v1' + path, { headers: { Accept: 'application/json' } }); return r.ok ? r.json() : null; }
  async function load() {
    if (D.loading) return; D.loading = true;
    try { [D.usage, D.prefs, D.feedback, D.revisions, D.jobs] = await Promise.all([get('/usage/mine'), get('/me/preferences'), get('/feedback/mine'), get('/proposals/workspace/revisions'), get('/jobs?take=50')]); D.error = null; }
    catch (e) { D.error = e.message; }
    D.loading = false; TR.app.refresh();
  }
  /** This browser's own records for you: keys under trstudio.* (excluding the start-up probe). */
  function local() {
    const out = [];
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && k.startsWith('trstudio.') && !k.endsWith('__probe')) out.push([k, localStorage.getItem(k)]); } } catch (e) { /* storage blocked */ }
    return out.sort((a, b) => a[0].localeCompare(b[0]));
  }
  const group = (rows, test) => rows.filter(([k]) => test(k.replace(/^trstudio\.([^.]+\.)?/, '')));
  function forget(keys, what) { keys.forEach(([k]) => { try { localStorage.removeItem(k); } catch (e) { /* ignore */ } }); TR.notify.toast(t('{w}: deleted from this browser.', { w: what }), 'success'); TR.app.refresh(); }

  function card(title, icon, where, keep, body, actions) {
    return h('section', { class: 'st-card hl-card md-card', 'aria-label': title },
      h('header', { class: 'hl-card-head' }, h('div', { class: 'md-title' }, TR.icon(icon, 18), h('h2', null, title)),
        h('div', { class: 'md-meta' }, h('span', { class: 's-chip' }, TR.icon(where === 'browser' ? 'globe' : 'database', 12), ' ', where === 'browser' ? t('This browser') : t('Server')), h('span', { class: 'muted' }, keep))),
      body, actions && actions.length ? h('div', { class: 'tm-actions' }, actions) : null);
  }
  const kv = (rows) => h('dl', { class: 'md-kv' }, rows.map(([k, v]) => [h('dt', null, k), h('dd', null, v)]));

  function render() {
    if (!D.usage && !D.loading && !D.error) load();
    const s = session(), rows = local();
    const recording = TR.prefs.get('usageStudy') !== false;
    const learning = TR.prefs.get('learning') !== false;
    const u = D.usage || {};
    const learned = group(rows, (k) => k.startsWith('learn') || k.startsWith('palette') || k.startsWith('frecency') || k.startsWith('markov'));
    const recent = group(rows, (k) => k.startsWith('recent') || k.startsWith('bookmark'));
    const prefsLocal = rows.filter((r) => !learned.includes(r) && !recent.includes(r));
    return h('div', { class: 'st-page hl-page md-page' },
      h('div', { class: 'st-head' }, h('h1', null, t('What the app knows about me')),
        h('p', { class: 'muted' }, t('Everything this application keeps about you, where it is kept and for how long. You can stop optional recording and delete what you are allowed to delete. Nothing here is shared outside this application.'))),
      D.error ? h('div', { class: 's-banner warning' }, TR.icon('alert'), D.error) : null,
      card(t('Your account'), 'user', 'server', t('While your account exists'),
        kv([[t('Name'), s.displayName || '—'], [t('User id'), s.userId || '—'], [t('Role'), s.role || '—'], [t('Vehicle contexts'), (s.contexts || []).join(', ') || '—'], [t('Country'), s.country || t('not set')], [t('Signed in with'), s.authentication === 'Password' ? t('a user name and password') : t('your organisation account')]]),
        [h('p', { class: 'muted' }, t('This comes from sign-in and is needed to decide what you may see and do. It cannot be switched off here.'))]),
      card(t('Usage study'), 'chart', 'server', t('Daily counts for 90 days; your latest 200 events'),
        h('div', null,
          h('p', null, recording ? t('On. The app records which pages and features you use, the journey steps, validation outcomes, errors and recoveries, never what you type or see.') : t('Off. Nothing new is recorded; the server drops anything that still arrives.')),
          D.usage ? kv([[t('Events kept'), String(u.events || 0)], [t('Days'), String(u.days || 0)], [t('Most used'), (u.top || []).slice(0, 5).map((x) => x.key + ' ×' + x.count).join(', ') || '—']]) : h('p', { class: 'muted' }, t('Loading…')),
          u.recent && u.recent.length ? h('details', null, h('summary', null, t('Show the latest events')), h('ol', { class: 'md-events' }, u.recent.slice(0, 50).map((e) => h('li', null, h('time', { datetime: e.at }, ui().when(e.at)), ' ', h('code', null, e.e + ':' + e.k), e.ms != null ? ' · ' + Math.round(e.ms / 1000) + ' s' : '')))) : null),
        [h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: !recording, onChange: async (e) => { await TR.usage.setRecording(!e.target.checked); D.usage = null; load(); } }), t("Don't record from now on")),
          ui().button(t('Delete my usage data'), 'trash', async () => { if (!(await TR.ui.confirm(t('Delete everything the usage study holds about you? This cannot be undone.')))) return; await fetch('/api/v1/usage/mine', { method: 'DELETE' }); D.usage = null; load(); TR.notify.toast(t('Usage data deleted.'), 'success'); }, 'danger')]),
      card(t('What the search learned'), 'search', 'browser', t('Until you delete it'),
        h('p', null, t('Ctrl+K learns which pages and actions you use most, to put them first. {n} records in this browser.', { n: learned.length })),
        [h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: !learning, onChange: (e) => TR.prefs.set('learning', !e.target.checked) }), t("Don't record from now on")),
          ui().button(t('Delete'), 'trash', () => { if (TR.ml && TR.ml.clearLearning) TR.ml.clearLearning(); forget(learned, t('Search learning')); }, 'text')]),
      card(t('Recent and saved vehicles'), 'bookmark', 'browser', t('Until you delete them'),
        h('p', null, t('{n} records: the vehicles you opened recently and the ones you saved.', { n: recent.length })),
        [ui().button(t('Delete'), 'trash', () => forget(recent, t('Recent and saved vehicles')), 'text')]),
      card(t('Preferences'), 'settings', 'browser', t('Until you reset them'),
        h('div', null, h('p', null, t('{n} settings in this browser (theme, language, layout …). Navigation preferences are also kept on the server so they follow you.', { n: prefsLocal.length })),
          D.prefs && D.prefs.navigation ? kv([[t('Navigation (server)'), (D.prefs.navigation.mode || '') + (D.prefs.navigation.autoHide === false ? ', ' + t('auto-hide off') : '')]]) : null,
          h('details', null, h('summary', null, t('Show the settings in this browser')), h('ul', { class: 'md-events' }, prefsLocal.map(([k, v]) => h('li', null, h('code', null, k.replace(/^trstudio\./, '')), ' = ', h('code', null, String(v).slice(0, 80))))))),
        [ui().button(t('Reset settings'), 'undo', async () => { if (!(await TR.ui.confirm(t('Reset all settings to their defaults?')))) return; TR.prefs.reset(); if (TR.navigation) TR.navigation.reset(); }, 'text')]),
      card(t('Your proposals'), 'save', 'server', t('Kept as a history of revisions'),
        h('p', null, D.revisions ? t('{n} saved revisions of your working proposal.', { n: D.revisions.length }) : t('Loading…')),
        [h('p', { class: 'muted' }, t('Revisions are never deleted, so a review or submission can always point to the exact revision it was based on.'))]),
      card(t('Requests and jobs'), 'flask', 'server', t('Kept with the request history'),
        h('p', null, D.jobs ? t('{n} recent jobs (validations you started).', { n: D.jobs.length }) : t('Loading…')), []),
      card(t('Feedback you sent'), 'people', 'server', t('Until an administrator closes it'),
        h('p', null, D.feedback ? t('{n} messages.', { n: D.feedback.length }) : t('Loading…')), [ui().button(t('Open Feedback'), 'arrow', () => TR.pages.show('feedback'), 'text')]),
      card(t('Audit log'), 'lock', 'server', t('Kept for accountability ({d} days)', { d: 2555 }),
        h('p', null, t('Sensitive actions you take (for example submitting a VDA update, changing permissions or exporting logs) are recorded with your name. You cannot delete these records: they protect others and show who did what.')), []));
  }
  TR.pages.register({ id: 'mydata', title: 'What the app knows about me', crumbs: () => [{ label: t('Settings'), open: () => TR.pages.show('settings') }, { label: t('My data') }], render });
  TR.mydata = { D, load };
})();
