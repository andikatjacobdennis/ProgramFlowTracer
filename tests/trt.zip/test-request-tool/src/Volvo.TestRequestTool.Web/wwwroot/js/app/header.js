/* One header row (with the menu-bar navigation):
 *
 *   Test Request Tool · Workspace · Vehicles · Tools · Reports · More          New request · Search · Notifications · Profile
 *
 * The navigation sections sit in the header (navigation.js places the menu bar in .hd-nav-slot). Secondary controls move
 * into menus, so no destination is lost:
 *   the next-step button        → one primary action, New request (the page's stepper still says what is next)
 *   Simulation chip             → removed (operation modes are shown within the pages)
 *   UI guide, Service status → More (Help & UI guide)
 *   culture and time-zone switch, theme, motion, navigation layout → the profile menu (Language & region, Time zone, Appearance)
 * 56–64 px tall; below 1100 px the sections collapse into the Menu button, and below 640 px New request keeps its icon.
 * In the sidebar layouts the header is unchanged. Keyboard shortcuts (T theme, M motion, Alt+Shift+C culture) still work. */
(function () {
  'use strict';
  const { h } = TR.util;
  const S = TR.testRequest, X = TR.experience;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : s);
  const oneRow = () => !TR.navigation || TR.navigation.prefs().mode === 'menubar';

  /** The single primary action: start a test request (adding a vehicle first when none is loaded). */
  function newRequest() {
    if (X) X.page = null;
    const L = TR.app.shell && TR.app.shell.left;
    if (L && L.product.loaded()) S.page(); else if (S.intake) S.intake(); else S.page();
  }
  const base = S.header;
  S.header = () => {
    const hd = base();
    if (!hd || typeof hd.querySelector !== 'function' || !oneRow()) return hd;
    hd.classList.add('hd-one');
    const brand = hd.querySelector('.s-brand');
    if (brand && !hd.querySelector('.hd-nav-slot')) brand.after(h('div', { class: 'hd-nav-slot' }));
    // Moved into menus (More, profile): removed from the row, never from the app.
    const gone = [hd.querySelector('.ap-next'), hd.querySelector('.s-guide-link'),
      ...[...hd.querySelectorAll('.ap-culture-wrap')].filter((w) => w.querySelector('.ap-culture')),
      ...hd.querySelectorAll('.ap-theme-toggle, .ap-motion-toggle')];
    gone.filter(Boolean).forEach((el) => el.remove());
    const sim = hd.querySelector('.s-chip.simulation');
    if (sim) sim.remove();
    const create = h('button', { type: 'button', class: 's-btn primary hd-new', onClick: () => TR.header.newRequest(), 'aria-label': t('New request') }, TR.icon('plus', 18), h('span', { class: 'hd-new-long' }, t('New request')), h('span', { class: 'hd-new-short', 'aria-hidden': 'true' }, t('New')));
    const find = hd.querySelector('.ap-find');
    if (find) find.before(create); else hd.appendChild(create);
    return hd;
  };
  TR.header = { newRequest, oneRow };
})();
