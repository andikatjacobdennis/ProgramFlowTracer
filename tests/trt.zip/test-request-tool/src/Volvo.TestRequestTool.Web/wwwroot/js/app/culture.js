/* Culture: country, language, time zone, currency and date and time formats, applied live across the application.
 *
 *   TR.culture.active()          – the culture in use: { country, language, timeZone, currency, dateFormat, hourCycle }
 *   TR.culture.format.dateTime(d) / date(d) / time(d) / number(n) / money(n) – format with the active culture
 *   TR.culture.use(profile) / useSystem() / useAccount() – switch live; every screen re-renders in the new culture
 *   TR.culture.flag(code)        – a small flag for a country code ('' gives a globe for "not set")
 *
 * Where the culture comes from, in order: the user's own choice in Settings; otherwise the country of their account
 * (session.country), with that country's language, time zone and currency; otherwise UTC. "Use system settings" follows
 * the language and time zone of the computer instead. Users can keep several cultures for the quick switch in the top bar.
 *
 * To add a country, add one entry to COUNTRIES, its flag file to /flags (the SVG Wikipedia uses, from Wikimedia Commons;
 * record it in /flags/SOURCES.txt) and its official proportion to FLAG_RATIO. */
(function () {
  'use strict';
  const { h } = TR.util;
  const prefs = TR.prefs;
  const root = document.documentElement;

  // ------------------------------------------------------------------ supported countries (Volvo Group markets used in this app)
  // languages and timeZones: the first entry is the default for the country.
  const COUNTRIES = [
    { code: 'SE', name: 'Sweden', languages: ['sv-SE', 'en-SE'], timeZones: ['Europe/Stockholm'], currency: 'SEK' },
    { code: 'IN', name: 'India', languages: ['en-IN', 'hi-IN', 'ta-IN', 'kn-IN', 'mr-IN'], timeZones: ['Asia/Kolkata'], currency: 'INR' },
    { code: 'US', name: 'United States', languages: ['en-US', 'es-US'], timeZones: ['America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles'], currency: 'USD' },
    { code: 'BR', name: 'Brazil', languages: ['pt-BR'], timeZones: ['America/Sao_Paulo', 'America/Manaus'], currency: 'BRL' },
    { code: 'BE', name: 'Belgium', languages: ['nl-BE', 'fr-BE', 'de-BE'], timeZones: ['Europe/Brussels'], currency: 'EUR' },
    { code: 'FR', name: 'France', languages: ['fr-FR'], timeZones: ['Europe/Paris'], currency: 'EUR' },
    { code: 'DE', name: 'Germany', languages: ['de-DE'], timeZones: ['Europe/Berlin'], currency: 'EUR' },
    { code: 'NL', name: 'Netherlands', languages: ['nl-NL'], timeZones: ['Europe/Amsterdam'], currency: 'EUR' },
    { code: 'GB', name: 'United Kingdom', languages: ['en-GB'], timeZones: ['Europe/London'], currency: 'GBP' },
    { code: 'PL', name: 'Poland', languages: ['pl-PL'], timeZones: ['Europe/Warsaw'], currency: 'PLN' },
    { code: 'IT', name: 'Italy', languages: ['it-IT'], timeZones: ['Europe/Rome'], currency: 'EUR' },
    { code: 'ES', name: 'Spain', languages: ['es-ES'], timeZones: ['Europe/Madrid'], currency: 'EUR' },
    { code: 'TR', name: 'Türkiye', languages: ['tr-TR'], timeZones: ['Europe/Istanbul'], currency: 'TRY' },
    { code: 'CN', name: 'China', languages: ['zh-CN'], timeZones: ['Asia/Shanghai'], currency: 'CNY' },
    { code: 'JP', name: 'Japan', languages: ['ja-JP'], timeZones: ['Asia/Tokyo'], currency: 'JPY' },
    { code: 'TH', name: 'Thailand', languages: ['th-TH', 'en-TH'], timeZones: ['Asia/Bangkok'], currency: 'THB' },
    { code: 'AU', name: 'Australia', languages: ['en-AU'], timeZones: ['Australia/Sydney', 'Australia/Brisbane', 'Australia/Adelaide', 'Australia/Perth'], currency: 'AUD' },
    { code: 'ZA', name: 'South Africa', languages: ['en-ZA', 'af-ZA'], timeZones: ['Africa/Johannesburg'], currency: 'ZAR' },
    { code: 'MX', name: 'Mexico', languages: ['es-MX'], timeZones: ['America/Mexico_City', 'America/Tijuana'], currency: 'MXN' },
    { code: 'CA', name: 'Canada', languages: ['en-CA', 'fr-CA'], timeZones: ['America/Toronto', 'America/Vancouver', 'America/Edmonton', 'America/Halifax'], currency: 'CAD' },
  ];
  const byCode = Object.fromEntries(COUNTRIES.map((c) => [c.code, c]));
  /** Older names some systems still report. */
  const ALIASES = { 'Asia/Calcutta': 'Asia/Kolkata', 'Asia/Saigon': 'Asia/Ho_Chi_Minh', 'Europe/Kiev': 'Europe/Kyiv' };
  /** "Not set": UTC, English, ISO dates and a 24-hour clock. */
  const UTC = { country: '', language: 'en-GB', timeZone: 'UTC', currency: '', dateFormat: 'iso', hourCycle: 'h23' };

  // ------------------------------------------------------------------ flags
  // Flags are the SVG files Wikipedia uses (Wikimedia Commons, public domain; sources and checksums in /flags/SOURCES.txt),
  // one per supported country, served from this site and shown at each flag's official proportion — never cropped to a
  // common shape. FLAG_RATIO is height:width as published (Sweden 5:8, United States 10:19, Belgium 13:15, …).
  const FLAG_RATIO = { AU: [1, 2], BE: [13, 15], BR: [7, 10], CA: [1, 2], CN: [2, 3], DE: [3, 5], ES: [2, 3], FR: [2, 3], GB: [3, 5], IN: [2, 3],
    IT: [2, 3], JP: [2, 3], MX: [4, 7], NL: [2, 3], PL: [5, 8], SE: [5, 8], TH: [2, 3], TR: [2, 3], US: [10, 19], ZA: [2, 3] };
  const FLAG_FILES = new Set(Object.keys(FLAG_RATIO));
  /** Width and height for a flag at a size: every flag is size × 2/3 tall and as wide as its proportion makes it. */
  function flagBox(code, size = 24) {
    const [rh, rw] = FLAG_RATIO[code] || [2, 3];
    const height = Math.round((size * 2) / 3);
    return { width: Math.round((height * rw) / rh), height };
  }
  /** A flag for a country code at its official proportion; a globe when no country is set. */
  function flag(code, size = 24) {
    const wrap = h('span', { class: 'cu-flag', role: 'img', 'aria-label': code ? (byCode[code] || { name: code }).name + ' flag' : 'No country (UTC)' });
    if (!FLAG_FILES.has(code)) { wrap.classList.add('is-globe'); wrap.appendChild(TR.icon('globe', Math.round(size * 0.75))); return wrap; }
    const box = flagBox(code, size);
    wrap.style.minWidth = flagBox('US', size).width + 'px';
    wrap.appendChild(h('img', { src: '/flags/' + code.toLowerCase() + '.svg', alt: '', width: box.width, height: box.height, decoding: 'async', draggable: 'false' }));
    return wrap;
  }

  // ------------------------------------------------------------------ resolving the active culture
  const valid = {
    language: (v) => { try { return Intl.getCanonicalLocales(v).length === 1; } catch (e) { return false; } },
    timeZone: (v) => { try { new Intl.DateTimeFormat('en', { timeZone: v }); return true; } catch (e) { return false; } },
    currency: (v) => v === '' || /^[A-Z]{3}$/.test(v),
  };
  /** Fills missing or invalid fields so formatting never fails. */
  function normalise(p) {
    const c = Object.assign({}, UTC, p || {});
    if (c.country && !byCode[c.country]) c.country = '';
    if (!valid.language(c.language)) c.language = UTC.language;
    if (!valid.timeZone(c.timeZone)) c.timeZone = UTC.timeZone;
    if (!valid.currency(c.currency)) c.currency = '';
    if (!['iso', 'short', 'medium', 'long'].includes(c.dateFormat)) c.dateFormat = 'medium';
    if (!['auto', 'h12', 'h23'].includes(c.hourCycle)) c.hourCycle = 'auto';
    return c;
  }
  /** Defaults for a country: its first language, first time zone and its currency. '' gives UTC. */
  function forCountry(code) {
    const c = byCode[code];
    if (!c) return Object.assign({}, UTC);
    return { country: code, language: c.languages[0], timeZone: c.timeZones[0], currency: c.currency, dateFormat: 'medium', hourCycle: 'auto' };
  }
  const accountCountry = () => { const c = String((TR.backend && TR.backend.session && TR.backend.session.country) || '').toUpperCase(); return byCode[c] ? c : ''; };
  // Countries without their own entry use the nearest supported one (same region, language or time zones).
  const NEAREST = {
    AT: 'DE', CH: 'DE', LI: 'DE', LU: 'BE', NO: 'SE', DK: 'SE', FI: 'SE', IS: 'SE', EE: 'SE', IE: 'GB', PT: 'ES', AD: 'ES', MC: 'FR', SM: 'IT', VA: 'IT', MT: 'IT',
    CZ: 'PL', SK: 'PL', LT: 'PL', LV: 'PL', HU: 'PL', RO: 'PL', BG: 'TR', GR: 'TR', CY: 'TR', UA: 'PL', SI: 'IT', HR: 'IT', RS: 'PL', BA: 'PL',
    NZ: 'AU', SG: 'IN', MY: 'TH', ID: 'TH', VN: 'TH', PH: 'TH', KH: 'TH', LA: 'TH', MM: 'TH', BD: 'IN', LK: 'IN', NP: 'IN', PK: 'IN', BT: 'IN', MV: 'IN',
    KR: 'JP', TW: 'CN', HK: 'CN', MO: 'CN', MN: 'CN', AE: 'IN', SA: 'IN', QA: 'IN', OM: 'IN', KW: 'IN', BH: 'IN', IL: 'TR', EG: 'TR',
    AR: 'BR', CL: 'BR', UY: 'BR', PY: 'BR', BO: 'BR', PE: 'BR', CO: 'MX', VE: 'MX', EC: 'MX', GT: 'MX', CR: 'MX', PA: 'MX', CU: 'MX', DO: 'MX',
    NA: 'ZA', BW: 'ZA', ZW: 'ZA', MZ: 'ZA', LS: 'ZA', SZ: 'ZA', KE: 'ZA', NG: 'ZA', GH: 'ZA', MA: 'FR', DZ: 'FR', TN: 'FR', SN: 'FR',
  };
  /** The nearest supported country for any two-letter code ('' when there is none). */
  const nearest = (code) => { const c = String(code || '').toUpperCase(); return byCode[c] ? c : byCode[NEAREST[c]] ? NEAREST[c] : ''; };
  // The organisation default, set by an administrator (Settings → Language and region → Organisation default).
  let orgDefault = null;
  async function loadOrgDefault() {
    try { const r = await fetch('/api/v1/settings/culture-default', { headers: { Accept: 'application/json' } }); if (r.ok) { const v = await r.json(); orgDefault = v && v.value ? v : null; if (TR.app && TR.app.refresh && TR.app.shell && TR.app.shell.left) TR.app.refresh(); } } catch (e) { /* offline: keep the other defaults */ }
  }
  /**
   * The account default, in order: the account's country; the organisation default; the nearest supported country to
   * this computer's region; UTC.
   */
  function accountProfile() {
    if (accountCountry()) return forCountry(accountCountry());
    if (orgDefault && orgDefault.value && byCode[orgDefault.value.country]) return normalise(Object.assign(forCountry(orgDefault.value.country), orgDefault.value));
    let region = '';
    try { region = new Intl.Locale((typeof navigator !== 'undefined' && navigator.language) || 'en').region || ''; } catch (e) { /* none */ }
    return forCountry(nearest(region));
  }
  /** Where the account default comes from, for Settings. */
  const accountSource = () => accountCountry() ? 'account' : orgDefault && orgDefault.value ? 'organisation' : 'nearest';
  /** The computer's own language and time zone. */
  function systemProfile() {
    const language = (typeof navigator !== 'undefined' && navigator.language) || UTC.language;
    let timeZone = 'UTC', region = '';
    try { timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch (e) { /* keep UTC */ }
    timeZone = ALIASES[timeZone] || timeZone;
    try { region = new Intl.Locale(language).region || ''; } catch (e) { /* no region */ }
    const country = nearest(region);
    return normalise({ country, language, timeZone, currency: country ? byCode[country].currency : '', dateFormat: 'medium', hourCycle: 'auto' });
  }
  /** 'account' (the default), 'custom' (chosen in Settings or the quick switch) or 'system'. */
  const mode = () => prefs.get('cultureMode');
  function active() {
    if (mode() === 'system') return systemProfile();
    if (mode() === 'custom' && prefs.get('culture')) return normalise(prefs.get('culture'));
    return normalise(accountProfile());
  }

  // ------------------------------------------------------------------ switching
  function use(profile) { prefs.set('culture', normalise(profile)); prefs.set('cultureMode', 'custom'); }
  function useSystem() { prefs.set('cultureMode', 'system'); }
  function useAccount() { prefs.set('cultureMode', 'account'); }
  /** Changes one field of the active culture; changing the country resets language, time zone and currency to its defaults. */
  function change(field, value) { use(field === 'country' ? forCountry(value) : Object.assign({}, active(), { [field]: value })); }

  const keyOf = (p) => [p.country, p.language, p.timeZone, p.currency, p.dateFormat, p.hourCycle].join('|');
  const quick = () => (prefs.get('cultures') || []).map(normalise);
  function addQuick(p = active()) { const list = quick(); if (!list.some((x) => keyOf(x) === keyOf(p))) prefs.set('cultures', list.concat(normalise(p)).slice(0, 8)); }
  function removeQuick(p) { prefs.set('cultures', quick().filter((x) => keyOf(x) !== keyOf(p))); }
  /** Every culture the quick switch offers: the account default, your saved cultures and the system settings. */
  function choices() {
    const list = [{ id: 'account', label: 'Account default', profile: accountProfile() }];
    quick().forEach((p) => { if (!list.some((x) => x.profile && keyOf(x.profile) === keyOf(p))) list.push({ id: 'custom', profile: p }); });
    const cur = active();
    if (mode() === 'custom' && !list.some((x) => keyOf(x.profile) === keyOf(cur))) list.push({ id: 'custom', profile: cur });
    list.push({ id: 'system', label: 'System settings', profile: systemProfile() });
    return list;
  }
  const isCurrent = (choice) => (choice.id === 'system' ? mode() === 'system' : choice.id === 'account' ? mode() === 'account' : mode() === 'custom' && keyOf(choice.profile) === keyOf(active()));
  function select(choice) { if (choice.id === 'system') useSystem(); else if (choice.id === 'account') useAccount(); else use(choice.profile); }
  /** Moves to the next culture in the quick switch (Alt+Shift+C). */
  function cycle() { const list = choices(); const i = list.findIndex(isCurrent); select(list[(i + 1) % list.length]); }

  // ------------------------------------------------------------------ formatting
  const hour12 = (p) => (p.hourCycle === 'auto' ? undefined : p.hourCycle === 'h12');
  const toDate = (d) => (d instanceof Date ? d : new Date(d));
  /** Short time zone name such as IST or CET; falls back to an offset such as GMT+5:30. */
  function zoneName(p = active(), d = new Date()) {
    if (p.timeZone === 'UTC') return 'UTC';
    const home = COUNTRIES.find((c) => c.timeZones.includes(ALIASES[p.timeZone] || p.timeZone));
    for (const loc of [p.language, 'en-' + (p.country || 'GB'), home ? 'en-' + home.code : 'en-GB', 'en-GB', 'en-US']) {
      try {
        const name = new Intl.DateTimeFormat(loc, { timeZone: p.timeZone, timeZoneName: 'short' }).formatToParts(d).find((x) => x.type === 'timeZoneName')?.value;
        if (name && !/^(GMT|UTC)[+-]/.test(name)) return name;
      } catch (e) { /* try the next locale */ }
    }
    return offset(p, d);
  }
  function offset(p = active(), d = new Date()) {
    try { return new Intl.DateTimeFormat('en-GB', { timeZone: p.timeZone, timeZoneName: 'shortOffset' }).formatToParts(d).find((x) => x.type === 'timeZoneName').value.replace('GMT', 'UTC'); } catch (e) { return ''; }
  }
  function isoParts(d, p) {
    const parts = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { timeZone: p.timeZone, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(d).map((x) => [x.type, x.value]));
    return { date: `${parts.year}-${parts.month}-${parts.day}`, time: `${parts.hour === '24' ? '00' : parts.hour}:${parts.minute}` };
  }
  const STYLE = { short: 'short', medium: 'medium', long: 'long' };
  const format = {
    dateTime(value, p = active()) {
      const d = toDate(value); if (isNaN(d)) return String(value);
      if (p.dateFormat === 'iso') { const x = isoParts(d, p); return `${x.date} ${x.time} ${zoneName(p, d)}`; }
      return new Intl.DateTimeFormat(p.language, { dateStyle: STYLE[p.dateFormat], timeStyle: 'short', timeZone: p.timeZone, hour12: hour12(p) }).format(d) + ' ' + zoneName(p, d);
    },
    date(value, p = active()) {
      const d = toDate(value); if (isNaN(d)) return String(value);
      if (p.dateFormat === 'iso') return isoParts(d, p).date;
      return new Intl.DateTimeFormat(p.language, { dateStyle: STYLE[p.dateFormat], timeZone: p.timeZone }).format(d);
    },
    time(value, p = active()) {
      const d = toDate(value); if (isNaN(d)) return String(value);
      if (p.dateFormat === 'iso') return isoParts(d, p).time;
      return new Intl.DateTimeFormat(p.language, { timeStyle: 'short', timeZone: p.timeZone, hour12: hour12(p) }).format(d);
    },
    number(n, options, p = active()) { return new Intl.NumberFormat(p.language, options).format(n); },
    /** Money in the culture's currency; without a currency, a plain number with two decimals. */
    money(n, currency, p = active()) {
      const cur = currency || p.currency;
      return cur ? new Intl.NumberFormat(p.language, { style: 'currency', currency: cur }).format(n) : new Intl.NumberFormat(p.language, { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n);
    },
  };

  // Older screens call toLocaleString() without a locale; give them the active culture's language, time zone and clock too.
  for (const name of ['toLocaleString', 'toLocaleDateString', 'toLocaleTimeString']) {
    const original = Date.prototype[name];
    Date.prototype[name] = function (locales, options) {
      if (locales !== undefined && !(Array.isArray(locales) && !locales.length)) return original.call(this, locales, options);
      try {
        const p = active(), o = Object.assign({}, options);
        if (!o.timeZone) o.timeZone = p.timeZone;
        if (name !== 'toLocaleDateString' && o.hour12 === undefined && !o.hourCycle && hour12(p) !== undefined) o.hour12 = hour12(p);
        return original.call(this, p.language, o);
      } catch (e) { return original.call(this, locales, options); }
    };
  }

  // ------------------------------------------------------------------ names for pickers
  const displayNames = (() => { try { return new Intl.DisplayNames(['en'], { type: 'language' }); } catch (e) { return null; } })();
  /** "हिन्दी (भारत) · Hindi (India)" or just "English (India)". */
  function languageName(tag) {
    let english = tag, native = tag;
    try { english = displayNames ? displayNames.of(tag) : tag; } catch (e) { /* keep tag */ }
    try { native = new Intl.DisplayNames([tag], { type: 'language' }).of(tag); } catch (e) { native = english; }
    return native && native !== english ? `${native} · ${english}` : english;
  }
  const countryName = (code) => (code ? (byCode[code] || { name: code }).name : 'Not set (UTC)');
  function currencyName(code) {
    if (!code) return 'None';
    try { return `${code} · ${new Intl.DisplayNames(['en'], { type: 'currency' }).of(code)}`; } catch (e) { return code; }
  }
  /** Every language, time zone and currency to offer, the country's own first. */
  function options(p = active()) {
    const c = byCode[p.country];
    const languages = [...new Set([...(c ? c.languages : []), p.language, 'en-GB', ...COUNTRIES.flatMap((x) => x.languages)])];
    let zones = [];
    try { zones = Intl.supportedValuesOf('timeZone'); } catch (e) { zones = COUNTRIES.flatMap((x) => x.timeZones); }
    const timeZones = [...new Set([...(c ? c.timeZones : []), p.timeZone, 'UTC', ...zones])];
    const currencies = [...new Set([...(c ? [c.currency] : []), p.currency, ...COUNTRIES.map((x) => x.currency)].filter(Boolean))];
    return { languages, timeZones, currencies };
  }
  const summary = (p) => `${languageName(p.language).split(' · ').pop()} · ${zoneName(p)} · ${p.currency || 'no currency'}`;

  // ------------------------------------------------------------------ quick switch in the top bar
  let menuOpen = false;
  function closeMenu() { if (menuOpen) { menuOpen = false; TR.app.refresh(); } }
  function switcher() {
    applyLang();
    if (prefs.get('cultureSwitch') === false) return null;
    const p = active();
    const label = mode() === 'system' ? 'System settings' : countryName(p.country);
    const button = h('button', { class: 'ap-culture', 'aria-haspopup': 'menu', 'aria-expanded': String(menuOpen), title: `Culture: ${label} · ${summary(p)} (Alt+Shift+C switches)`, 'aria-label': `Culture: ${label}. Change culture`,
      onClick: (e) => { e.stopPropagation(); menuOpen = !menuOpen; TR.app.refresh(); } },
      h('span', { class: 'ap-culture-code' }, p.country || 'UTC'), h('span', { class: 'ap-culture-zone' }, zoneName(p)));   // flags only in the menu
    return h('div', { class: 'ap-culture-wrap' }, button, menuOpen ? menu() : null);
  }
  function menu() {
    return h('div', { class: 'ap-menu', role: 'menu', 'aria-label': 'Switch culture', onClick: (e) => e.stopPropagation() },
      h('div', { class: 'ap-menu-title' }, 'Switch culture'),
      choices().map((c) => {
        const on = isCurrent(c);
        return h('button', { class: ['ap-menu-item', on ? 'is-on' : ''], role: 'menuitemradio', 'aria-checked': String(on), onClick: () => { menuOpen = false; select(c); } },
          flag(c.profile.country, 22),   // the system entry shows its country's flag too (a globe when the region is unknown)
          h('span', { class: 'ap-menu-text' }, h('strong', null, c.label ? `${c.label} · ${countryName(c.profile.country)}` : countryName(c.profile.country)), h('small', null, summary(c.profile) + ' · ' + format.dateTime(new Date(), c.profile))),
          on ? TR.icon('check', 16) : null);
      }),
      h('div', { class: 'ap-menu-actions' },
        h('button', { class: 's-btn text', onClick: () => { addQuick(); } }, TR.icon('plus', 15), 'Keep this culture in the list'),
        h('button', { class: 's-btn text', onClick: () => { menuOpen = false; TR.pages.show('settings'); setTimeout(() => document.getElementById('st-region')?.scrollIntoView({ block: 'start' }), 0); } }, TR.icon('settings', 15), 'Language and region settings')));
  }
  if (typeof document.addEventListener === 'function') {
    document.addEventListener('click', () => closeMenu());
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeMenu();
      if (e.altKey && e.shiftKey && (e.key === 'C' || e.key === 'c')) { e.preventDefault(); cycle(); }
    });
  }
  TR.pages.addHeaderItem(switcher);

  // <html lang> follows the culture, so screen readers and the browser use the right language.
  // The page language is the interface language when a language pack is active (screen readers read it); else the culture's.
  const applyLang = () => { root.lang = TR.i18n && TR.i18n.lang && TR.i18n.lang() !== 'en' ? TR.i18n.locale() : active().language; };
  applyLang();
  prefs.onChange(applyLang);

  // Fetch the organisation default once the page runs on the server (not in the browser-only tests).
  if (typeof location !== 'undefined' && /^https?:$/.test(location.protocol) && typeof fetch === 'function') setTimeout(loadOrgDefault, 0);
  TR.culture = { COUNTRIES, FLAGS: FLAG_FILES, FLAG_RATIO, flagBox, UTC, flag, active, accountProfile, accountSource, nearest, loadOrgDefault, orgDefault: () => orgDefault, systemProfile, forCountry, normalise, use, useSystem, useAccount, change, cycle, choices, select, isCurrent, quick, addQuick, removeQuick, format, zoneName, offset, languageName, countryName, currencyName, options, summary, keyOf };
})();
