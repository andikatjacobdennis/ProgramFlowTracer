/* Introduction tour: Asha walks the user through the application one highlighted control at a time, and can read each step
 * aloud with the most natural voice the browser offers (Web Speech API, no service is contacted).
 *
 *   TR.tour.start()        – start the introduction tour (also: Help → Take the tour, or press g then i)
 *   TR.tour.stop()         – end it
 *   TR.tour.STEPS          – the steps: { page?, prepare?, target?, title, text, mood? }
 *
 * Keys while the tour runs: → or Enter next, ← back, V voice on or off, Esc end. The tour lives outside #app, so the
 * application can re-render underneath it; the spotlight follows its target. */
(function () {
  'use strict';
  const { h } = TR.util;
  const T = { on: false, i: 0, el: null, timer: null, voice: null };
  const voiceOn = () => TR.prefs.get('tourVoice') !== false;
  const speech = () => (typeof window !== 'undefined' && window.speechSynthesis && typeof window.SpeechSynthesisUtterance === 'function' ? window.speechSynthesis : null);

  // ------------------------------------------------------------------ steps
  const L = () => TR.app.shell.left;
  const ensureVehicle = async () => { if (!L().product.loaded()) { Object.assign(L().src, { series: 'FH', number: '333333' }); await L().loadFromSource(false); } };
  const vehicleTab = (tab) => async () => { await ensureVehicle(); TR.pages.show('vehicle'); TR.vehiclePage.V.tab = tab; TR.app.refresh(); };
  const STEPS = [
    { page: 'home', title: 'Welcome to Test Request Tool', mood: 'wave',
      text: 'Hi, I am {name}. In two minutes I will show you around. You can listen to me or read along, and use the arrow keys to move on. You can skip at any time.' },
    { page: 'home', target: '#studio-navigation', title: 'Go anywhere', text: 'The navigation menus take you to your workspace, vehicles, tools and reports. On smaller screens, open Menu.' },
    { target: '.hd-new', title: 'Start your next request', text: 'New request starts with a vehicle. Within a request, the progress steps show where you are and what comes next.' },
    { target: '.av-trigger', title: 'Your culture', text: 'Open your account menu for Language and region. Choose the language, time zone and formats that work for you.' },
    { target: '.av-trigger', title: 'Theme and motion', text: 'Your account menu includes automatic, light and dark themes. Open Settings for animations and other accessibility preferences.' },
    { page: 'home', target: '.hp-steps', title: 'Your first steps', text: 'Open Your first steps when you want a checklist. It remembers your progress and stays out of the way while you work.' },
    { page: 'dashboard', target: '.db-kpis', title: 'The fleet at a glance', text: 'The dashboard reads every vehicle you may see: how current the software is, what is waiting and what happened.' },
    { page: 'dashboard', target: '.db-attention', title: 'What needs attention', text: 'Vehicles with updates waiting come first. Open one with a single click.' },
    { prepare: vehicleTab('graph'), target: '.vh-tabs', title: 'Explore your vehicle', text: 'I loaded the T3 truck F H 3 3 3 3 3 3 for you. Use the tabs to explore its graph, architecture map, roadmap, history and insights.' },
    { prepare: vehicleTab('graph'), target: '.vh-compare', title: 'Compare with the past', text: 'Pick an earlier moment, such as the factory build. Like a code diff, red shows what it was and green what it is now.' },
    { prepare: vehicleTab('history'), target: '.gh-graph', title: 'History, drawn like git', text: 'Changes to the vehicle run along the main line. Simulations and kits branch off the revision they started from. Older entries load as you scroll.' },
    { prepare: vehicleTab('insights'), target: '.in-cards', title: 'Insights', text: 'These cards sum up what matters, and below them a timeline shows every computer’s versions from the factory until today.' },
    { page: 'help', target: '.hp-search', title: 'Help is always here', text: 'Whenever you are stuck, search Help in plain words. Press the question mark key for every keyboard shortcut.' },
    { page: 'help', title: 'That’s the tour!', mood: 'cheer', text: 'You are ready. Press N for your next step. You can replay this tour from Help at any time. Have fun!' },
  ];

  // ------------------------------------------------------------------ voice
  /** The language the guide speaks: the app language, with the accent of the user's culture where it has one
   *  (Swedish text gets a Swedish voice; English text in India gets an English (India) voice). */
  function voiceLanguage() {
    if (TR.i18n && TR.i18n.speechLang && TR.i18n.speechLang()) return TR.i18n.speechLang();   // any language pack: its locale
    const c = TR.culture ? TR.culture.active() : { language: 'en-GB', country: '' };
    return /^en-/i.test(c.language) ? c.language : 'en-' + (c.country || 'GB');
  }
  /** The most natural voice for that language: neural or online voices first, then one that suits the guide. */
  function pickVoice() {
    const s = speech(); if (!s) return null;
    const voices = s.getVoices() || [];
    if (!voices.length) return null;
    const lang = voiceLanguage().toLowerCase(), base = lang.split('-')[0];
    const natural = (v) => /natural|neural|online|premium|enhanced|google/i.test(v.name);
    const hints = (TR.personas ? TR.personas.current().voice.hints : []);
    const fits = (v) => hints.some((x) => v.name.toLowerCase().includes(x));
    const score = (v) => { const l = v.lang.toLowerCase(); return (l === lang ? 4 : l.startsWith(base) ? 2 : l.startsWith('en') ? 1 : 0) * 10 + (natural(v) ? 5 : 0) + (fits(v) ? 3 : 0) + (v.localService ? 0 : 1); };
    return voices.slice().sort((a, b) => score(b) - score(a))[0] || null;
  }
  function say(text) {
    const s = speech(); if (!s || !voiceOn()) return;
    s.cancel();
    const u = new window.SpeechSynthesisUtterance(text);
    T.voice = T.voice || pickVoice();
    if (T.voice) { u.voice = T.voice; u.lang = T.voice.lang; }
    u.rate = 1; u.pitch = TR.personas ? TR.personas.current().voice.pitch : 1.05;
    u.onstart = () => { if (T.el) T.el.classList.add('is-speaking'); };
    u.onend = () => { if (T.el) T.el.classList.remove('is-speaking'); };
    s.speak(u);
  }
  const hush = () => { const s = speech(); if (s) s.cancel(); if (T.el) T.el.classList.remove('is-speaking'); };
  if (speech() && typeof speech().addEventListener === 'function') speech().addEventListener('voiceschanged', () => { T.voice = pickVoice(); });

  // ------------------------------------------------------------------ overlay
  const find = (sel) => (sel && typeof document.querySelector === 'function' ? [...document.querySelectorAll(sel)].find((e) => e.getClientRects().length) : null);
  function place() {
    if (!T.on || !T.el) return;
    const step = STEPS[T.i], target = find(step.target);
    const spot = T.el.querySelector('.tr-spot'), card = T.el.querySelector('.tr-card');
    if (!target) { spot.style.cssText = 'display:none'; card.classList.add('is-center'); card.style.cssText = ''; T.el.classList.add('is-dim'); return; }
    T.el.classList.remove('is-dim'); card.classList.remove('is-center');
    const r = target.getBoundingClientRect(), pad = 6;
    spot.style.cssText = `display:block;left:${r.left - pad}px;top:${r.top - pad}px;width:${r.width + pad * 2}px;height:${r.height + pad * 2}px`;
    const cw = card.offsetWidth || 380, ch = card.offsetHeight || 240, vw = window.innerWidth, vh = window.innerHeight;
    let left = r.right + 16, top = r.top;
    if (left + cw > vw - 12) left = r.left - cw - 16;
    if (left < 12) { left = Math.min(Math.max(12, r.left), vw - cw - 12); top = r.bottom + 16; if (top + ch > vh - 12) top = r.top - ch - 16; }
    top = Math.min(Math.max(12, top), vh - ch - 12);
    card.style.cssText = `left:${left}px;top:${top}px`;
  }
  /** Step text in the app language (i18n.js). */
  const textOf = (step) => TR.i18n.t(typeof step.text === 'function' ? step.text() : step.text, { name: TR.personas.current().name });
  function card() {
    const step = STEPS[T.i], last = T.i === STEPS.length - 1, s = !!speech();
    return h('div', { class: 'tr-card', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'tr-title', 'aria-describedby': 'tr-text' },
      h('div', { class: 'tr-card-head' },
        h('div', { class: 'tr-figure' }, TR.personas ? TR.personas.draw(step.mood || 'wave', 72) : null, h('span', { class: 'tr-wave', 'aria-hidden': 'true' }, h('i'), h('i'), h('i'))),
        h('div', null, h('small', { class: 'tr-count' }, `Step ${T.i + 1} of ${STEPS.length}`), h('h2', { id: 'tr-title' }, step.title))),
      h('p', { id: 'tr-text' }, textOf(step)),
      h('div', { class: 'tr-dots', 'aria-hidden': 'true' }, STEPS.map((_, j) => h('i', { class: j === T.i ? 'is-on' : j < T.i ? 'is-done' : '' }))),
      h('div', { class: 'tr-actions' },
        s ? h('button', { class: ['s-btn', 'text', 'tr-voice'], 'aria-pressed': String(voiceOn()), title: 'Voice on or off (V)', onClick: () => { TR.prefs.set('tourVoice', !voiceOn()); if (voiceOn()) say(textOf(step)); else hush(); render(); } }, TR.icon(voiceOn() ? 'mic' : 'still', 16), voiceOn() ? 'Voice on' : 'Voice off') : h('small', { class: 'muted' }, 'Voice is not available in this browser.'),
        s && voiceOn() ? h('button', { class: 's-btn text', title: 'Listen again', onClick: () => say(textOf(step)) }, TR.icon('play', 15), 'Again') : null,
        h('span', { class: 'tr-spacer' }),
        h('button', { class: 's-btn text tr-skip', onClick: stop, title: 'End the tour (Esc). You can start it again from Help at any time.' }, 'Skip tour'),
        T.i ? h('button', { class: 's-btn secondary', onClick: () => go(T.i - 1) }, TR.icon('left', 16), 'Back') : null,
        h('button', { class: 's-btn primary', onClick: () => (last ? stop() : go(T.i + 1)) }, last ? 'Finish' : 'Next', TR.icon(last ? 'check' : 'right', 16))));
  }
  function render() {
    if (!T.el) return;
    T.el.replaceChildren(h('div', { class: 'tr-spot' }), card());
    place();
    setTimeout(() => T.el && T.el.querySelector('.tr-card .s-btn.primary')?.focus(), 0);
  }
  async function go(i) {
    T.i = Math.max(0, Math.min(STEPS.length - 1, i));
    const step = STEPS[T.i];
    try {
      if (step.prepare) await step.prepare();
      else if (step.page && TR.pages.current() !== step.page) TR.pages.show(step.page);
    } catch (e) { /* show the step anyway */ }
    await new Promise((r) => setTimeout(r, 180));
    const target = find(step.target);
    if (target) target.scrollIntoView({ block: 'center', behavior: TR.pages.ui.motionOn() ? 'smooth' : 'auto' });
    render();
    if (TR.personas) TR.personas.react(T.el, ['wave', 'nod', 'peek', 'hop', 'wiggle'][T.i % 5]);
    say(textOf(step));
  }
  function onKey(e) {
    if (!T.on) return;
    if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); stop(); }
    else if (e.key === 'ArrowRight' || (e.key === 'Enter' && e.target === document.body)) { e.preventDefault(); e.stopPropagation(); if (T.i < STEPS.length - 1) go(T.i + 1); else stop(); }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); e.stopPropagation(); go(T.i - 1); }
    else if (e.key === 'v' || e.key === 'V') { e.preventDefault(); e.stopPropagation(); TR.prefs.set('tourVoice', !voiceOn()); if (voiceOn()) say(textOf(STEPS[T.i])); else hush(); render(); }
  }
  function start(at = 0) {
    if (TR.features && !TR.features.on('intro-tour')) { if (TR.notify) TR.notify.toast(TR.i18n.t('The introduction tour is switched off. An administrator can turn it on in Feature flags.'), 'info'); return; }
    if (T.on) return;
    T.on = true;
    T.el = h('div', { class: 'tr-layer' });
    document.body.appendChild(T.el);
    document.addEventListener('keydown', onKey, true);
    window.addEventListener('resize', place);
    T.timer = setInterval(place, 250);
    go(at);
  }
  function stop() {
    if (!T.on) return;
    T.on = false; hush();
    clearInterval(T.timer);
    document.removeEventListener('keydown', onKey, true);
    window.removeEventListener('resize', place);
    if (T.el) T.el.remove();
    T.el = null;
    if (TR.help) TR.help.complete('tour');
  }

  if (TR.shortcuts) TR.shortcuts.add({ keys: 'g i', group: 'Go to', label: 'Start the introduction tour', run: () => start() });
  TR.tour = { start, stop, STEPS, T, pickVoice, say, textOf, voiceLanguage };
})();
