/* Fleet readiness: which vehicles can proceed and what needs attention (server: GET /api/v1/fleet/readiness).
 * For every vehicle you may read: software, hardware, dependency and parameter checks from your latest validation of it,
 * its approval from the review, and overall readiness (current checks without blockers and an approval for the same
 * validation). A validation on an older vehicle revision is Stale; no validation is Unknown. Cells are buttons; arrow keys
 * move between them. "Validate selected" runs the chosen vehicles as a batch with your latest options. */
(function () {
  'use strict';
  const { h } = TR.util;
  const J = TR.journey, t = J.t;
  const COLS = [['software', 'Software'], ['hardware', 'Hardware'], ['dependencies', 'Dependencies'], ['parameters', 'Parameters'], ['approval', 'Approval'], ['overall', 'Overall']];
  const F = { data: null, error: null, loading: false, group: '', arch: '', status: '', q: '', picked: new Set(), cell: null, busy: false, page: 0, size: 25 };

  async function load() {
    if (F.loading) return;
    F.loading = true; TR.app.refresh();
    try { F.data = await J.api('/fleet/readiness'); F.error = null; if (!F.cell && F.data.vehicles.length) F.cell = pickFirst(F.data.vehicles.slice(0, F.size)); } catch (e) { F.error = e.message; }
    F.loading = false; TR.app.refresh();
  }
  /** The first cell worth looking at: a blocked one, else a stale or pending overall. */
  function pickFirst(list) {
    for (const v of list) for (const [c] of COLS) if (v.cells[c].state === 'blocked') return { id: v.id, col: c };
    const v = list.find((x) => x.cells.overall.state !== 'ready' && x.cells.overall.state !== 'unknown') || list[0];
    return { id: v.id, col: 'overall' };
  }
  // ------------------------------------------------------------------ filters and counts (exported for tests)
  function filter(list, f) {
    const q = (f.q || '').toLowerCase().replace(/\s+/g, '');
    return list.filter((v) => (!f.group || String(v.context.id) === String(f.group)) && (!f.arch || v.architecture === f.arch) && (!f.status || v.cells.overall.state === f.status)
      && (!q || (v.title + v.id + v.context.name).toLowerCase().replace(/[\s|]+/g, '').includes(q)));
  }
  function counts(list) {
    const c = { ready: 0, pending: 0, blocked: 0, unknown: 0, stale: 0 };
    list.forEach((v) => { c[v.cells.overall.state] = (c[v.cells.overall.state] || 0) + 1; });
    return c;
  }
  const APPROVAL = { approved: 'Approved', submitted: 'Submitted', pending: 'Pending', changes: 'Changes requested', 'not-requested': 'Not requested', 'not-ready': 'Not ready', expired: 'Expired' };
  const OVERALL = { pending: 'Awaiting approval' };

  // ------------------------------------------------------------------ actions
  function exportCsv(list) {
    const rows = [['Vehicle', 'Architecture', 'Context', 'Revision', 'Validated', 'Request'].concat(COLS.map(([, l]) => l))]
      .concat(list.map((v) => [v.title, v.architecture, v.context.name, v.revision, v.validatedAt || '', v.requestId ? J.label(v.requestId) : ''].concat(COLS.map(([c]) => v.cells[c].state))));
    J.download('fleet-readiness.csv', J.csv(rows), 'text/csv');
  }
  async function validateSelected() {
    if (!F.picked.size || F.busy) return;
    F.busy = true; TR.app.refresh();
    try {
      // Group the vehicles by the options of their latest validation: one batch per set of options.
      const groups = new Map();
      for (const id of F.picked) {
        const [s, n] = id.split('|');
        const r = await J.api('/fleet/readiness/' + encodeURIComponent(s) + '/' + encodeURIComponent(n) + '/revalidation');
        const opts = Object.assign({}, r.payload); delete opts.products;
        const key = r.kind + JSON.stringify(opts);
        if (!groups.has(key)) groups.set(key, { kind: r.kind, template: opts, ids: [] });
        groups.get(key).ids.push(id);
      }
      let last = null;
      for (const g of groups.values()) last = await J.api('/batches', { method: 'POST', body: { name: t('Readiness revalidation'), vehicleIds: g.ids, kind: g.kind, delayMs: 1000, stopOnFailure: false, template: g.template } });
      TR.announce && TR.announce(t('Validation started for {n} vehicle(s).', { n: F.picked.size }));
      F.picked.clear();
      if (last && TR.batch) { TR.batch.follow(last.id); TR.pages.show('batch'); }
    } catch (e) { TR.notify.toast(e.message, 'error'); }
    F.busy = false; TR.app.refresh();
  }

  // ------------------------------------------------------------------ table
  function cellLabel(c, s) { return c === 'approval' ? APPROVAL[s] || J.state(s)[0] : c === 'overall' ? OVERALL[s] || J.state(s)[0] : J.state(s)[0]; }
  function cell(v, c, r, ci) {
    const s = v.cells[c].state, on = F.cell && F.cell.id === v.id && F.cell.col === c;
    const tone = c === 'approval' && (s === 'approved' || s === 'submitted') ? 'approved' : s === 'pending' && c === 'approval' ? 'pending' : s;
    return h('td', { class: 'fr-td' }, h('button', { class: ['fr-cell', 'is-' + tone, on ? 'is-sel' : ''], 'data-r': r, 'data-c': ci, tabindex: on || (!F.cell && r === 0 && ci === 0) ? '0' : '-1',
      'aria-label': t('{v}, {c}: {s}', { v: v.title, c: t(COLS[ci][1]), s: t(cellLabel(c, s)) }), 'aria-pressed': String(on),
      onClick: () => { F.cell = { id: v.id, col: c }; TR.app.refresh(); }, onKeydown: (e) => move(e, r, ci) }, J.chip(c === 'approval' && (s === 'approved' || s === 'submitted') ? 'approved' : s, t(cellLabel(c, s)))));
  }
  function move(e, r, c) {
    const d = { ArrowRight: [0, 1], ArrowLeft: [0, -1], ArrowDown: [1, 0], ArrowUp: [-1, 0] }[e.key];
    if (!d) return;
    e.preventDefault();
    const b = document.querySelector('.fr-cell[data-r="' + (r + d[0]) + '"][data-c="' + (c + d[1]) + '"]');
    if (b) b.click(), setTimeout(() => { const n = document.querySelector('.fr-cell[data-r="' + (r + d[0]) + '"][data-c="' + (c + d[1]) + '"]'); if (n) n.focus(); }, 0);
  }
  function table(list) {
    const all = list.length > 0 && list.every((v) => F.picked.has(v.id));
    return h('div', { class: 'jr-table-wrap' }, h('table', { class: 'jr-table fr-table', 'aria-label': t('Readiness by vehicle') },
      h('thead', null, h('tr', null, h('th', { class: 'fr-pick' }, h('input', { type: 'checkbox', checked: all, 'aria-label': t('Select all shown vehicles'), onChange: (e) => { list.forEach((v) => (e.target.checked ? F.picked.add(v.id) : F.picked.delete(v.id))); TR.app.refresh(); } })),
        h('th', null, t('Vehicle')), COLS.map(([, l]) => h('th', null, t(l))))),
      h('tbody', null, list.map((v, r) => h('tr', { class: F.cell && F.cell.id === v.id ? 'is-row' : '' },
        h('td', { class: 'fr-pick' }, h('input', { type: 'checkbox', checked: F.picked.has(v.id), 'aria-label': t('Select {v}', { v: v.title }), onChange: (e) => { if (e.target.checked) F.picked.add(v.id); else F.picked.delete(v.id); TR.app.refresh(); } })),
        h('th', { scope: 'row' }, h('span', { class: 'jr-two' }, h('strong', null, v.title.replace(' ', '')), h('small', { class: 'muted' }, v.architecture))),
        COLS.map(([c], ci) => cell(v, c, r, ci)))))));
  }
  const CATEGORY = { software: 'Software check', hardware: 'Hardware check', dependencies: 'Dependency check', parameters: 'Parameter check', approval: 'Approval', overall: 'Overall readiness' };
  const CODE = { dependency_unsatisfied: 'Dependency not satisfied', hardware_incompatible: 'Hardware compatibility', incompatible_hardware_or_pbl: 'Hardware or PBL compatibility', no_compatible_version: 'No compatible version', parameter_value_required: 'Parameter value required', parameter_value_invalid: 'Parameter value not allowed' };
  function side() {
    const v = F.cell && F.data.vehicles.find((x) => x.id === F.cell.id);
    if (!v) return h('aside', { class: 'jr-side' }, J.card('Details', null, h('p', { class: 'muted' }, t('Choose a cell.'))));
    const c = F.cell.col, cellData = v.cells[c], f = (cellData.findings || [])[0];
    const overall = v.cells.overall.state;
    const next = { unknown: 'Validate this vehicle to learn its readiness.', stale: 'The vehicle changed after validation: validate this revision again.', blocked: 'Resolve the finding, then validate this revision again.',
      pending: 'Checks pass. Ask for a review; readiness needs approval for the same validation.', ready: 'Ready: current checks and approval for the same revision.' }[overall];
    const title = c === 'approval' ? t(APPROVAL[cellData.state] || cellData.state) : c === 'overall' ? t(OVERALL[overall] || J.state(overall)[0]) : f ? t(CODE[f.code] || f.code.replace(/_/g, ' ')) : cellData.state === 'pass' ? t('No findings') : t(J.state(cellData.state)[0]);
    const text = f ? f.text : c === 'approval' ? (cellData.by ? t('Decided by {p}, {a}.', { p: cellData.by, a: J.ago(cellData.at) }) : t('No decision recorded.')) : cellData.state === 'unknown' ? t('No validation of this vehicle yet.') : cellData.state === 'stale' ? t('Based on revision {a}; the vehicle is now at revision {b}.', { a: v.basedOnRevision, b: v.revision }) : t('The latest validation found nothing here.');
    return h('aside', { class: 'jr-side' },
      J.card(null, null,
        h('div', { class: 'jr-side-title' }, h('strong', { class: 'jr-big' }, v.title.replace(' ', ' ')), J.chip(overall, t(OVERALL[overall] || J.state(overall)[0]))),
        h('p', { class: 'muted' }, v.architecture + ' · ' + v.context.name),
        h('hr', { class: 'jr-rule' }),
        h('p', { class: 'jr-eyebrow' }, t(CATEGORY[c])), h('h3', { class: 'jr-title2' }, title), h('p', null, text),
        (cellData.findings || []).length > 1 ? h('ul', { class: 'jr-list' }, cellData.findings.slice(1).map((x) => h('li', null, x.text))) : null,
        J.facts([['Vehicle revision', String(v.revision)], ['Validated', v.validatedAt ? J.ago(v.validatedAt) + (v.requestId ? ' · ' + J.label(v.requestId) : '') : null], ['Proposal revision', v.proposalRevision],
          ['Check status', J.chip(v.cells[c === 'approval' || c === 'overall' ? 'overall' : c].state, t(cellLabel(c === 'approval' ? 'overall' : c, v.cells[c === 'approval' ? 'overall' : c].state)))],
          ['Approval', J.chip(v.cells.approval.state === 'submitted' ? 'approved' : v.cells.approval.state, t(APPROVAL[v.cells.approval.state] || v.cells.approval.state))]]),
        h('div', { class: 'jr-stack' },
          v.reviewId ? TR.pages.ui.button(t('Review finding'), 'arrow', () => J.open('review', { rid: v.reviewId }), 'primary')
            : v.requestId ? TR.pages.ui.button(t('Review finding'), 'arrow', () => J.open('execution', { rid: v.requestId }), 'primary')
              : TR.pages.ui.button(t('Validate this vehicle'), 'play', () => { F.picked = new Set([v.id]); validateSelected(); }, 'primary'),
          TR.pages.ui.button(t('Open vehicle graph'), 'graph', () => J.open('impact', { vid: v.id, rid: v.requestId }), 'secondary')),
        next ? h('p', { class: 'jr-note' }, TR.icon('info', 15), t(next)) : null));
  }

  function render() {
    if (!F.data && !F.loading && !F.error) load();
    const d = F.data;
    const head = J.pageHead('Fleet readiness', 'See which vehicles can proceed and what needs attention.', [
      d ? TR.pages.ui.button(t('Export report'), 'upload', () => exportCsv(filter(d.vehicles, F)), 'secondary') : null,
      TR.pages.ui.button(F.busy ? t('Starting…') : F.picked.size ? t('Validate selected ({n})', { n: F.picked.size }) : t('Validate selected'), 'play', validateSelected, 'primary', { disabled: !F.picked.size || F.busy, 'data-tip': t('Validate selected|Runs the selected vehicles as a batch with your latest options') })]);
    if (!d) return h('div', { class: 'jr-page' }, head, F.error ? J.failed(F.error, load) : J.loading(6));
    const list = filter(d.vehicles, F), c = counts(filter(d.vehicles, Object.assign({}, F, { status: '' })));
    const set = (k, v) => { F[k] = v; F.page = 0; TR.app.refresh(); };
    const pages = Math.max(1, Math.ceil(list.length / F.size)); F.page = Math.min(F.page, pages - 1);
    const shown = list.slice(F.page * F.size, (F.page + 1) * F.size);
    const groupName = (g) => g.name + ' · ' + d.vehicles.filter((v) => v.context.id === g.id).length + ' ' + t('vehicles');
    return h('div', { class: 'jr-page fr-page' }, head,
      h('div', { class: 'jr-filters' },
        J.select('Fleet', F.group, [['', t('All vehicles') + ' · ' + d.vehicles.length + ' ' + t('vehicles')]].concat(d.groups.map((g) => [g.id, groupName(g)])), (v) => set('group', v)),
        J.select('Architecture', F.arch, [['', 'All'], ['T3', 'T3'], ['Legacy', 'Legacy']], (v) => set('arch', v)),
        J.select('Status', F.status, [['', 'All'], ['ready', 'Ready'], ['pending', 'Awaiting approval'], ['blocked', 'Blocked'], ['unknown', 'Unknown'], ['stale', 'Stale']], (v) => set('status', v)),
        J.search('Find vehicle', F.q, (v) => { F.q = v; J.later(() => TR.app.refresh()); }),
        h('span', { class: 'spacer' }), h('span', { class: 'muted', role: 'status' }, t('Updated {a}', { a: J.ago(d.generatedAt) })), h('button', { class: 'ap-icon-btn', 'aria-label': t('Refresh'), onClick: load }, TR.icon('refresh', 17))),
      J.stats([
        { n: c.ready, label: 'Ready', icon: 'check', tone: 'good', onClick: () => set('status', F.status === 'ready' ? '' : 'ready'), on: F.status === 'ready' },
        { n: c.blocked, label: 'Blocked', icon: 'alert', tone: 'warning', onClick: () => set('status', F.status === 'blocked' ? '' : 'blocked'), on: F.status === 'blocked' },
        { n: c.unknown, label: 'Unknown', icon: 'help', tone: 'neutral', onClick: () => set('status', F.status === 'unknown' ? '' : 'unknown'), on: F.status === 'unknown' },
        { n: c.stale, label: 'Stale', icon: 'clock', tone: 'stale', onClick: () => set('status', F.status === 'stale' ? '' : 'stale'), on: F.status === 'stale' },
        c.pending ? { n: c.pending, label: 'Awaiting approval', icon: 'shield', tone: 'info', onClick: () => set('status', F.status === 'pending' ? '' : 'pending'), on: F.status === 'pending' } : null]),
      h('div', { class: 'jr-split' },
        J.card('Readiness by vehicle', F.picked.size ? h('span', { class: 'muted' }, t('{n} selected', { n: F.picked.size })) : null,
          list.length ? table(shown) : J.empty('No vehicles match', 'Clear the filters.'),
          list.length > F.size ? h('footer', { class: 'jr-pager' }, h('span', { class: 'muted' }, t('Showing {a}–{b} of {n}', { a: F.page * F.size + 1, b: Math.min(list.length, (F.page + 1) * F.size), n: list.length })), h('span', { class: 'spacer' }),
            J.select('Per page', F.size, [[25, '25'], [50, '50'], [100, '100']], (v) => { F.size = Number(v); F.page = 0; TR.app.refresh(); }),
            TR.pages.ui.button(t('Previous'), 'left', () => { F.page--; TR.app.refresh(); }, 'secondary', { disabled: F.page === 0 }),
            TR.pages.ui.button(t('Next'), 'right', () => { F.page++; TR.app.refresh(); }, 'secondary', { disabled: F.page >= pages - 1 })) : null,
          h('div', { class: 'jr-legend' }, [['pass', 'Passed'], ['blocked', 'Blocked'], ['unknown', 'Unknown'], ['stale', 'Stale']].map(([s, l]) => h('span', null, J.chip(s, t(l)))))),
        side()),
      h('div', { class: 'jr-foot muted' }, h('span', null, t('Readiness requires current checks and approval for the same validation. Approval comes from Reviews; checks from your latest validation of each vehicle.'))));
  }
  TR.pages.register({ id: 'readiness', title: 'Fleet readiness', crumbs: () => [{ label: t('Fleet') }, { label: t('Readiness') }], render });
  TR.readiness = { F, load, filter, counts, pickFirst };
})();
