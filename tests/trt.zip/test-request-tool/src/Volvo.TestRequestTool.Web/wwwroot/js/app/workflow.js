/* The test request journey, made explicit (FR-01, FR-02, FR-04, FR-05):
 *
 *   Stepper        Choose vehicle → Prepare changes → Validate → Review → Submit. Each step says whether it is done,
 *                  current, available or blocked. A blocked step stays focusable and, when chosen, says why and offers the
 *                  way forward (aria-disabled, not disabled). Going back never loses work: the proposal lives in the panes.
 *   Decision bar   always shows the vehicle and its architecture, the original configuration and its revision, the proposal
 *                  revision (autosaved) and its changes, the service mode (built-in / connected / unavailable) and the
 *                  validation state (not run / current / out of date / blocked / limited). Text and icons, not colour alone.
 *   Findings       on the validation step: every issue in plain language with its vehicle and computer, sorted by severity,
 *                  classified as validation failure, unknown compatibility or confirmed, with a next step; after a rerun,
 *                  "fixed since last run", "still open" and "new".
 *   Autosave       the proposal is saved as numbered revisions (/api/v1/proposals/workspace) a moment after each change,
 *                  with Saving / Saved / Not saved states and a conflict choice when another tab or device saved first.
 *   Safety         a validation cannot be started twice at once; leaving the page with unsaved changes asks first;
 *                  important status changes are announced to assistive technologies (TR.announce).
 *
 * Everything here reads the existing state (TR.testRequest, the panes, TR.backend); it changes no stored data on its own except
 * the proposal revisions. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));
  const S = TR.testRequest, X = TR.experience, M = TR.model;
  const session = () => (TR.backend && TR.backend.session) || {};
  const W = { reason: null, running: false, prev: null, findings: null, save: { state: 'idle', rev: 0, at: null, error: null, conflict: null, hash: null }, original: {}, mode: null };

  // ------------------------------------------------------------------ announcements (polite live region)
  let live = null;
  function announce(text) {
    if (typeof document.createElement !== 'function' || !document.body) return;
    if (!live || !live.isConnected) { live = h('div', { id: 'ap-announcer', class: 'nv-sr', role: 'status', 'aria-live': 'polite', 'aria-atomic': 'true' }); document.body.appendChild(live); }
    live.textContent = '';
    setTimeout(() => { live.textContent = text; }, 30);
  }
  TR.announce = announce;

  // ------------------------------------------------------------------ the facts each screen needs
  const L = () => TR.app && TR.app.shell && TR.app.shell.left;
  function changes() { try { const c = M.deltaCounts(L().product.delta()); return { total: c.nodes + c.parameters + c.variants + c.sNotes, ...c }; } catch (e) { return { total: 0, nodes: 0, parameters: 0, variants: 0, sNotes: 0 }; } }
  function facts() {
    const pane = L(), loaded = !!(pane && pane.product && pane.product.loaded());
    const s = session(), v = S.validation, fresh = !!(v && S.fresh());
    const results = v ? v.results : [];
    const statuses = results.map((r) => S.resultStatus(r));
    return {
      loaded, pane, changes: loaded ? changes() : { total: 0 },
      canSimulate: s.canSimulate !== false, canEdit: s.canEdit !== false, canWrite: !!s.canWrite, role: s.role || 'Viewer',
      validated: !!v, fresh, stale: !!v && !fresh, blocked: statuses.filter((x) => x === 'blocked').length, limited: statuses.filter((x) => x === 'limited').length,
      ready: statuses.filter((x) => x === 'ready').length, vehicles: loaded ? pane.items.length : 0, stage: S.stage, running: W.running,
    };
  }

  // ------------------------------------------------------------------ the five steps (pure: tested in tests/frontend/workflow.cjs)
  /**
   * Each step: state ('done' | 'current' | 'available' | 'blocked') and, when blocked, why: [reason, action label, target].
   * Exactly one step is current: the step of the page you are on (view = the workspace stage) unless it is blocked, otherwise the
   * first step that is neither done nor blocked.
   */
  function steps(f, view) {
    const atReview = view === 'review';
    const needVehicle = ['Choose a vehicle first.', 'Add a vehicle', 'vehicle'];
    const stale = ['You changed something after the check, so the result is out of date.', 'Check again', 'validate'];
    const list = [
      { id: 'vehicle', label: 'Choose vehicle', done: f.loaded, why: null },
      // Prepared once there are changes, or once a request was validated (a service pack request can find nothing to change).
      { id: 'prepare', label: 'Make changes', done: f.loaded && (f.changes.total > 0 || f.fresh), why: f.loaded ? null : needVehicle },
      { id: 'validate', label: 'Check', done: f.fresh && !f.running,
        why: !f.loaded ? needVehicle : !f.changes.total ? ['Change at least one software package, parameter, variant or S-Note: the check needs a change.', 'Make changes', 'prepare']
          : !f.canSimulate ? [`Your role (${f.role}) cannot run validations. Ask an administrator for Engineer or Operator access.`, null, null] : null },
      { id: 'review', label: 'Get approval', done: false,
        why: !f.validated ? ['Check the change first: approval needs a checked result.', f.changes.total && f.canSimulate ? 'Check now' : null, f.changes.total && f.canSimulate ? 'validate' : null] : f.stale ? stale : null },
      { id: 'submit', label: 'Send', done: false,
        why: !f.validated ? ['Check the change and get it approved first.', null, null] : f.stale ? stale
          : f.blocked ? [`${f.blocked} of ${f.blocked + f.ready + f.limited} vehicles are blocked by validation failures. Fix them and check again.`, 'See what to fix', 'findings']
            : !f.canWrite ? [`Submitting needs the Reviewer or Admin role; you are ${f.role}. You can still export or share it.`, 'Get approval', 'review'] : null },
    ];
    // The current step is the page you are on (the workspace stage), unless that step is blocked; without a stage it is the
    // first step that is neither done nor blocked. (The stepper showed Prepare changes on the Validate page.)
    const onStage = { configure: 'prepare', validate: 'validate', review: 'review' }[view];
    const stageStep = onStage && f.loaded ? list.find((x) => x.id === onStage) : null;
    let current = stageStep && (!stageStep.why || stageStep.done) ? onStage : atReview && !list[3].why ? 'review' : (list.find((x) => !x.done && !x.why) || {}).id;
    if (f.running) current = 'validate';
    return list.map((x) => Object.assign(x, { state: x.id === current ? 'current' : x.done ? 'done' : x.why ? 'blocked' : 'available' }));
  }
  /** The check, in plain words, for the one-sentence summary: [words, icon, tone]. */
  function plainState(f) {
    if (f.running) return ['Checking…', 'flask', 'info'];
    if (!f.validated) return ['Not checked yet', 'flask', 'neutral'];
    if (f.stale) return ['Changed since the check', 'alert', 'warning'];
    if (f.blocked) return [f.blocked === 1 ? '1 vehicle must be fixed' : `${f.blocked} vehicles must be fixed`, 'alert', 'danger'];
    if (f.limited) return ['Checked, with limits', 'alert', 'warning'];
    return [f.ready === 1 ? 'Checked: ready' : `Checked: ${f.ready} ready`, 'check', 'good'];
  }
  /** The decision bar's validation wording. */
  function validationState(f) {
    if (f.running) return ['Validating…', 'flask', 'info'];
    if (!f.validated) return ['Not validated', 'flask', 'neutral'];
    if (f.stale) return ['Out of date: validate again', 'alert', 'warning'];
    if (f.blocked) return [`${f.blocked} blocked`, 'alert', 'danger'];
    if (f.limited) return [`Validated with limits (${f.limited})`, 'alert', 'warning'];
    return [`Current: ${f.ready} ready`, 'check', 'good'];
  }

  // ------------------------------------------------------------------ actions behind the steps
  function go(target) {
    W.reason = null;
    if (target === 'vehicle') { X.page = null; S.intake(); return; }
    if (target === 'prepare') { S.page('software'); return; }
    if (target === 'validate') { validate(); return; }
    if (target === 'review') { X.page = null; S.page(); S.stage = 'review'; TR.app.refresh(); return; }
    if (target === 'findings') { X.page = null; S.page(); S.stage = 'validate'; TR.app.refresh(); setTimeout(() => { const el = document.getElementById('wf-findings'); if (el) { el.scrollIntoView({ block: 'start' }); el.focus(); } }, 50); return; }
    if (target === 'submit') { go('review'); setTimeout(() => { const el = document.querySelector('.s-delivery'); if (el) { el.scrollIntoView({ block: 'center' }); el.setAttribute('tabindex', '-1'); el.focus(); } }, 60); }
  }
  function validate() {
    if (W.running) { TR.notify && TR.notify.toast(t('A validation is already running. It continues; the result opens when it is ready.'), 'info'); return; }
    X.page = null; const pane = L(); if (!pane) return; pane.request.selectedRequestType = 0; S.page(); TR.request.runRequest(pane, false);
  }
  // One validation at a time: a second click while one runs is ignored with an explanation (no duplicate submissions).
  const run = TR.request.runRequest;
  TR.request.runRequest = async (...args) => {
    if (W.running) { TR.notify && TR.notify.toast(t('A validation is already running. It continues; the result opens when it is ready.'), 'info'); return undefined; }
    W.running = true; W.prev = S.validation ? findings() : null; announce(t('Validation started.')); TR.app.refresh();
    try { const r = await run(...args); return r; }
    finally {
      W.running = false; W.findings = null;
      const f = facts();
      announce(f.validated ? (f.blocked ? t('Check finished: {n} must be fixed.', { n: f.blocked }) : t('Check finished: {n} ready.', { n: f.ready })) : t('Check finished.'));
      TR.app.refresh();
    }
  };

  // ------------------------------------------------------------------ findings (FR-04)
  const EXPLAIN = [
    [/node template document is unknown/i, 'Unknown software set', 'The software set on this computer is not in the catalog, so it cannot be checked or updated. Choose a released software version.', 'failed', ['Open the Software tab', 'software']],
    [/resolve the node template/i, 'Resolve the software set first', 'The current software set must be resolved before an update can be requested. Use the Resolve operation in the request settings.', 'failed', ['Open request settings', 'request']],
    [/not defined in the node template database/i, 'Unknown computer', 'This computer has no software definition in the catalog, so nothing can be checked for it.', 'unknown', ['Check the computer in the Structure tab', 'structure']],
    [/no valid node template document/i, 'No valid software set', 'The vehicle’s current software set for this computer is not a released version. Use the Resolve operation to pick a valid one.', 'failed', ['Open request settings', 'request']],
    [/no software available for ECU hardware/i, 'Hardware has no software', 'No released software matches this computer’s hardware number. Change the hardware or choose another software version.', 'failed', ['Open the Software tab', 'software']],
    [/could not resolve a node template/i, 'Cannot work out the software set', 'The main software on this computer does not match any known software set.', 'failed', ['Open the Software tab', 'software']],
    [/not part of service pack/i, 'Not in the service pack', 'This computer is not covered by the chosen service pack, so it keeps its current software. Compatibility with the others is not confirmed.', 'unknown', ['Open request settings', 'request']],
    [/No candidate service pack passed/i, 'No service pack fits', 'None of the service packs can be used with the chosen scenario. Choose a scenario that allows more release states, such as InProgress, or change the software by hand.', 'failed', ['Open request settings', 'request']],
    [/Limited validation/i, 'Checked with limits', 'Some checks could not run, so the result is partial. Treat it as unconfirmed until a full validation passes.', 'unknown', ['Open request settings', 'request']],
    [/does not exist in the product/i, 'Computer not on this vehicle', 'The request names a computer this vehicle does not have.', 'failed', ['Open request settings', 'request']],
    [/does not match any of the requested nodes/i, '"Limit to" matches nothing', 'The "Limit to" setting excludes every requested computer.', 'failed', ['Open request settings', 'request']],
    [/already newer than service pack/i, 'Already newer', 'This computer already has newer software than the service pack; nothing changes for it.', 'confirmed', null],
    [/resolved node template document|replaced .*software selected/i, 'Resolved automatically', 'A matching software set was found and selected.', 'confirmed', null],
    [/hardware/i, 'Hardware check', 'The hardware and software combination did not pass the catalog rules.', 'failed', ['Open the Software tab', 'software']],
    [/dependency|depends/i, 'Dependency not met', 'A software package needs another package or version that the proposal does not include.', 'failed', ['Open the Software tab', 'software']],
  ];
  // "Couldn't confirm", not "Not checked": that is the state of a request before its first check (plainState).
  const CLASS = { failed: ['Must fix', 'close', 'danger'], unknown: ["Couldn't confirm", 'help', 'warning'], confirmed: ['Checked OK', 'check', 'good'] };
  const MEANS = { failed: 'This stops you from sending the change.', unknown: 'Nothing could confirm or refuse it: a limited check, or a computer outside the service pack.', confirmed: 'The catalog rules confirmed it.' };
  function explain(issue) {
    const hit = EXPLAIN.find(([re]) => re.test(issue.text));
    const kind = issue.severity === 0 ? 'failed' : hit ? hit[3] : issue.severity === 1 ? 'unknown' : 'confirmed';
    // Must fix means it blocks sending, so only errors are: a warning the table would call a failure is Couldn't confirm.
    return { title: hit ? hit[1] : issue.severity === 0 ? 'Must fix' : issue.severity === 1 ? 'Needs attention' : 'Information', plain: hit ? hit[2] : issue.text, kind: issue.severity === 0 ? 'failed' : kind === 'failed' ? 'unknown' : kind, action: hit ? hit[4] : null };
  }
  /** All issues across the validated vehicles, worst first, with a stable key for "fixed since last run". */
  function findings() {
    const v = S.validation;
    if (!v) return [];
    const list = [];
    v.results.forEach((r) => {
      const vehicle = M.chassisText({ productSpecification: { productInformation: r } });
      ((r.errorReport && r.errorReport.errors) || []).forEach((e) => list.push(Object.assign(explain(e), { vehicle, node: e.node || '', text: e.text, severity: e.severity, key: vehicle + '|' + (e.node || '') + '|' + e.text })));
    });
    return list.sort((a, b) => a.severity - b.severity || a.vehicle.localeCompare(b.vehicle));
  }
  /**
   * Opens Make changes at the computer a finding is about: that vehicle selected, the editor (not the service-pack choice),
   * the tab, the software list filtered to the computer, and the computer scrolled into view and highlighted for a moment.
   */
  /** "16.1.1 EMS" → "EMS": the computer's name without its position. */
  const shortNode = (n) => String(n || '').replace(/^[\d.]+\s+/, '');
  function goTo(x, tab) {
    const pane = L(), name = shortNode(x.node);
    const i = pane.items.findIndex((it) => M.chassisText(it.product) === x.vehicle);
    if (i >= 0 && pane.items.length > 1 && pane.selectProduct) pane.selectProduct(i);
    if (S.path) S.path[pane.product.chassisString()] = 'manual';
    S.search = tab === 'software' && name ? name : '';
    S.page(tab);
    setTimeout(() => {
      const scope = document.querySelector('.s-editor');
      // The smallest element naming the computer: a T3 package group, a legacy node, or a table row.
      const re = name ? new RegExp('\\b' + name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b') : null;
      const hits = re && scope ? [...scope.querySelectorAll('.s-package-group, .node, tr')].filter((e) => re.test(e.textContent)) : [];
      const el = hits.sort((a, b) => a.textContent.length - b.textContent.length)[0] || scope;
      if (!el) return;
      el.scrollIntoView({ block: 'center', behavior: document.documentElement.dataset.motion === 'reduced' ? 'auto' : 'smooth' });
      el.classList.add('is-flash'); setTimeout(() => el.classList.remove('is-flash'), 2200);
      const field = el.querySelector('select, input, button'); if (field) field.focus({ preventScroll: true });
    }, 80);
  }
  /** Findings grouped by cause (kind, title and explanation), in order of the worst first: [{ kind, title, plain, items, vehicles }]. Pure. */
  function groupFindings(list) {
    const groups = new Map();
    for (const x of list) {
      const key = x.kind + '|' + x.title + '|' + x.plain;
      if (!groups.has(key)) groups.set(key, { kind: x.kind, title: x.title, plain: x.plain, items: [], vehicles: [] });
      const g = groups.get(key); g.items.push(x); if (!g.vehicles.includes(x.vehicle)) g.vehicles.push(x.vehicle);
    }
    return [...groups.values()];
  }
  /** Where a cause was found: "FH 123456 · EMS", or "FH 123456 (EMS, IC), RT 000777 (EMS)". */
  function whereText(g) {
    if (g.items.length === 1) return g.items[0].vehicle + (g.items[0].node ? ' · ' + shortNode(g.items[0].node) : '');
    return g.vehicles.map((v) => { const nodes = [...new Set(g.items.filter((i) => i.vehicle === v && i.node).map((i) => shortNode(i.node)))]; return v + (nodes.length ? ' (' + nodes.join(', ') + ')' : ''); }).join(', ');
  }
  function findingsPanel() {
    const list = findings(), prev = W.prev || [];
    const prevKeys = new Set(prev.map((x) => x.key)), nowKeys = new Set(list.map((x) => x.key));
    const fixed = W.prev ? prev.filter((x) => !nowKeys.has(x.key) && x.severity <= 1) : [];
    const counts = { failed: list.filter((x) => x.kind === 'failed').length, unknown: list.filter((x) => x.kind === 'unknown').length, confirmed: list.filter((x) => x.kind === 'confirmed').length };
    // Every finding about a computer says where to fix it: Go to EMS opens the editor at that computer. Request problems open
    // the request settings. A confirmed finding needs nothing.
    const act = (x, many) => {
      const a = x.action;
      if (a && a[1] === 'request') return TR.pages.ui.button(t(a[0]), 'arrow', () => TR.request.open(L()), 'text');
      if ((a && (a[1] === 'software' || a[1] === 'structure')) || (x.node && x.kind !== 'confirmed') || x.kind === 'failed')
        return TR.pages.ui.button(x.node ? (many ? t('Go to {n} on {v}', { n: shortNode(x.node), v: x.vehicle }) : t('Go to {n}', { n: shortNode(x.node) })) : a ? t(a[0]) : t('Go to Make changes'), 'arrow', () => goTo(x, a && a[1] === 'structure' ? 'structure' : 'software'), 'text');
      return null;
    };
    return h('section', { id: 'wf-findings', class: 'st-card hl-card wf-findings', tabindex: '-1', 'aria-labelledby': 'wf-findings-h' },
      h('header', { class: 'hl-card-head' }, h('h2', { id: 'wf-findings-h' }, t('Findings')),
        // Only the kinds that have findings, each explained on hover and focus; none at all: one plain sentence.
        list.length ? h('div', { class: 'wf-legend', role: 'list', 'aria-label': t('Kinds of finding') },
          Object.entries(CLASS).filter(([k]) => counts[k]).map(([k, [label, icon, tone]]) => h('span', { role: 'listitem', tabindex: '0', class: 'wf-kind tone-' + tone, 'data-tip': t(label) + '|' + t(MEANS[k]), 'aria-label': t(label) + ' · ' + counts[k] + '. ' + t(MEANS[k]) }, TR.icon(icon, 13), t(label) + ' · ' + counts[k]))) : null),
      !list.length ? h('p', { class: 'wf-allgood' }, TR.icon('check', 14), ' ', t('All checks passed.')) :
        // One row per cause: "Hardware check · FH 123456 (EMS, IC), RT 000777 (EMS)", with a Go to for each computer.
        h('ol', { class: 'wf-list' }, groupFindings(list).map((g) => {
          const x = g.items[0], many = g.vehicles.length > 1, isNew = W.prev && g.items.some((i) => !prevKeys.has(i.key));
          const goes = g.items[0].action && g.items[0].action[1] === 'request' ? [act(x)] : g.items.filter((i, n, all) => all.findIndex((j) => j.vehicle === i.vehicle && j.node === i.node) === n).map((i) => {
            return act(i, many); }).filter(Boolean);
          return h('li', { class: 'wf-item tone-' + CLASS[g.kind][2] },
            h('span', { class: 'wf-kind tone-' + CLASS[g.kind][2] }, TR.icon(CLASS[g.kind][1], 13), t(CLASS[g.kind][0])),
            h('div', { class: 'wf-body' }, h('strong', null, t(g.title)), g.items.length > 1 ? h('span', { class: 'wf-count' }, String(g.items.length)) : null, h('span', { class: 'muted' }, ' · ' + whereText(g)),
              h('p', null, t(g.plain)), g.items.some((i) => i.plain !== i.text) ? h('details', null, h('summary', null, g.items.length > 1 ? t('Technical messages ({n})', { n: g.items.length }) : t('Technical message')), g.items.map((i) => h('code', null, (g.items.length > 1 ? i.vehicle + ': ' : '') + i.text))) : null),
            h('div', { class: 'wf-tags' }, isNew ? TR.pages.ui.chip(t('New'), 'warning') : W.prev ? TR.pages.ui.chip(t('Still open'), 'neutral') : null, goes.slice(0, 4), goes.length > 4 ? h('span', { class: 'muted' }, t('+{n} more', { n: goes.length - 4 })) : null));
        })),
      fixed.length ? h('div', { class: 's-banner success', role: 'status' }, TR.icon('check'), t('Fixed since the last run: ') + fixed.map((x) => x.title + ' (' + x.vehicle + ')').join(', ')) : null);
  }

  // ------------------------------------------------------------------ original revision, service mode
  async function originalRevision(pane) {
    const info = pane.product.info(), key = (info.chassisSeries || '') + '|' + (info.chassisNumber || '');
    if (!info.chassisSeries || W.original[key] !== undefined) return;
    W.original[key] = null;
    try { const r = await fetch('/api/v1/vehicles/' + encodeURIComponent(info.chassisSeries) + '/' + encodeURIComponent(info.chassisNumber)); if (r.ok) { W.original[key] = (await r.json()).revision; TR.app.refresh(); } } catch (e) { /* unknown */ }
  }
  async function serviceMode() {
    if (W.mode) return;
    W.mode = { label: 'Checking services…', tone: 'neutral', detail: '' };
    try {
      const r = await fetch('/api/v1/integrations/health'); const list = r.ok ? await r.json() : [];
      const configured = list.filter((x) => x.configured), failing = configured.filter((x) => x.health === 'unhealthy' || x.health === 'degraded');
      W.mode = !configured.length
        ? { label: 'Built-in validators', tone: 'neutral', detail: 'The built-in validators only. No live system (KAX, VESPA, Dependix, Digital Twin) is asked, and no result claims their checks.' }
        : failing.length ? { label: 'Connected · ' + failing.length + ' unavailable', tone: 'warning', detail: 'Unavailable: ' + failing.map((x) => x.name).join(', ') + '. Results do not include their checks.' }
          : { label: 'Connected', tone: 'good', detail: 'Configured systems: ' + configured.map((x) => x.name).join(', ') + '.' };
    } catch (e) { W.mode = { label: 'Services unknown', tone: 'warning', detail: 'The service status could not be read.' }; }
    TR.app.refresh();
  }

  // ------------------------------------------------------------------ autosave with revisions (FR-05)
  const PROPOSAL = 'workspace';
  let saveTimer = null;
  function stateHash() { try { const json = JSON.stringify(TR.shellActions.getState()); return json.length + ':' + simpleHash(json); } catch (e) { return null; } }
  function simpleHash(s) { let x = 2166136261; for (let i = 0; i < s.length; i++) { x ^= s.charCodeAt(i); x = Math.imul(x, 16777619); } return (x >>> 0).toString(36); }
  function scheduleSave() {
    if (!session().userId || session().canEdit === false || !L() || !L().product.loaded()) return;
    clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
      const hash = stateHash();
      if (!hash || hash === W.save.hash || W.save.state === 'saving' || W.save.conflict) return;
      // A fresh page builds on the latest saved revision; only a save racing another tab or device is a conflict.
      if (!W.save.known) { try { const list = await (await fetch('/api/v1/proposals/' + PROPOSAL + '/revisions')).json(); W.save.rev = list.length ? list[0].number : 0; } catch (e) { /* first save decides */ } W.save.known = true; }
      await save(hash, 'Autosave');
    }, 1500);
  }
  async function save(hash, reason, base) {
    W.save.state = 'saving'; TR.app.refresh();
    const c = changes();
    try {
      const r = await fetch('/api/v1/proposals/' + PROPOSAL + '/revisions', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ state: TR.shellActions.getState(), baseRevision: base ?? W.save.rev, reason, summary: { changes: c.total, vehicle: L().product.chassisString() } }) });
      const body = await r.json().catch(() => ({}));
      if (r.status === 409) { W.save.state = 'conflict'; W.save.conflict = body.detail || t('Someone saved a newer revision.'); announce(t('Your proposal was not saved: a newer revision exists.')); }
      else if (!r.ok) { W.save.state = 'failed'; W.save.error = body.detail || body.title || r.statusText; }
      else { W.save = { state: 'saved', rev: body.number, at: new Date(), error: null, conflict: null, hash, known: true }; }
    } catch (e) { W.save.state = 'failed'; W.save.error = t('No connection. Your changes are kept in this page and will be saved when you retry.'); }
    TR.app.refresh();
  }
  async function keepMine() {
    try { const list = await (await fetch('/api/v1/proposals/' + PROPOSAL + '/revisions')).json(); W.save.conflict = null; await save(stateHash(), 'Kept my version after a conflict', list.length ? list[0].number : 0); } catch (e) { TR.notify.toast(e.message, 'error'); }
  }
  async function loadTheirs() {
    try {
      const list = await (await fetch('/api/v1/proposals/' + PROPOSAL + '/revisions')).json();
      if (!list.length) return;
      const rev = await (await fetch('/api/v1/proposals/' + PROPOSAL + '/revisions/' + list[0].number)).json();
      TR.shellActions.loadFromState(rev.state); S.validation = null;
      W.save = { state: 'saved', rev: rev.number, at: new Date(rev.at), error: null, conflict: null, hash: stateHash() };
      TR.notify.toast(t('Loaded revision {n}.', { n: rev.number }), 'success'); TR.app.refresh();
    } catch (e) { TR.notify.toast(e.message, 'error'); }
  }
  function revisions() {
    TR.ui.modal({ title: t('Proposal revisions'), width: 520, body: (m) => {
      const box = h('div', { class: 'wf-revs' }, h('p', { class: 'muted' }, t('Loading…')));
      fetch('/api/v1/proposals/' + PROPOSAL + '/revisions').then((r) => r.json()).then((list) => {
        box.textContent = '';
        if (!list.length) { box.appendChild(h('p', { class: 'muted' }, t('No revisions yet. Changes are saved automatically a moment after you make them.'))); return; }
        box.appendChild(h('ol', { class: 'st-org-history' }, list.map((rv, i) => h('li', null,
          h('span', null, h('strong', null, t('Revision {n}', { n: rv.number }) + ' · ' + t(rv.reason)), h('small', null, rv.actorName + ' · ' + TR.pages.ui.when(rv.at) + (rv.summary && rv.summary.changes != null ? ' · ' + t('{n} changes', { n: rv.summary.changes }) : ''))),
          i === 0 ? TR.pages.ui.chip(t('Latest'), 'good') : TR.pages.ui.button(t('Restore'), 'undo', async () => {
            const r = await fetch(`/api/v1/proposals/${PROPOSAL}/revisions/${rv.number}/restore`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ baseRevision: list[0].number }) });
            if (!r.ok) { TR.notify.toast((await r.json()).detail || t('Could not restore.'), 'error'); return; }
            const created = await r.json(), full = await (await fetch(`/api/v1/proposals/${PROPOSAL}/revisions/${created.number}`)).json();
            TR.shellActions.loadFromState(full.state); S.validation = null;
            W.save = { state: 'saved', rev: created.number, at: new Date(), error: null, conflict: null, hash: stateHash() };
            m.close(); TR.notify.toast(t('Revision {o} restored as revision {n}. Validate again before submitting.', { o: rv.number, n: created.number }), 'success'); TR.app.refresh();
          }, 'text')))));
      }).catch(() => { box.textContent = t('Revisions could not be loaded.'); });
      return box;
    } });
  }
  // Leaving with unsaved changes asks first (browsers show their own wording).
  if (typeof addEventListener === 'function') addEventListener('beforeunload', (e) => {
    const unsaved = L() && L().product && L().product.dirty() && (W.save.state === 'failed' || W.save.state === 'conflict' || W.save.state === 'saving' || (session().canEdit === false));
    if (unsaved) { e.preventDefault(); e.returnValue = ''; }
  });

  // ------------------------------------------------------------------ rendering
  function stepper(f, view) {
    const list = steps(f, view);
    return h('nav', { class: 'wf-steps', 'aria-label': t('Test request steps') },
      h('ol', null, list.map((s, i) => h('li', { class: 'wf-step is-' + s.state },
        h('button', { type: 'button', class: 'wf-step-btn', 'aria-current': s.state === 'current' ? 'step' : null, 'aria-disabled': s.state === 'blocked' ? 'true' : null,
          'aria-describedby': W.reason === s.id ? 'wf-reason' : null,
          onClick: () => { if (s.state === 'blocked') { W.reason = W.reason === s.id ? null : s.id; TR.app.refresh(); setTimeout(() => { const el = document.getElementById('wf-reason'); if (el) el.focus(); }, 0); } else go(s.id === 'vehicle' && f.loaded ? 'prepare' : s.id); } },
          h('span', { class: 'wf-dot', 'aria-hidden': 'true' }, s.state === 'done' ? TR.icon('check', 13) : s.state === 'blocked' ? TR.icon('lock', 12) : String(i + 1)),
          h('span', { class: 'wf-label' }, t(s.label)),
          h('span', { class: 'nv-sr' }, ' · ' + t({ done: 'done', current: 'current step', available: 'available', blocked: 'not available yet' }[s.state])))))),
      W.reason ? (() => { const s = list.find((x) => x.id === W.reason); return s && s.why ? h('div', { id: 'wf-reason', class: 'wf-reason', role: 'note', tabindex: '-1' },
        TR.icon('info', 15), h('span', null, h('strong', null, t('{s} is not available yet.', { s: t(s.label) })), ' ', t(s.why[0])),
        s.why[1] ? TR.pages.ui.button(t(s.why[1]), 'arrow', () => go(s.why[2]), 'primary') : null,
        h('button', { class: 'ap-icon-btn', 'aria-label': t('Close'), onClick: () => { W.reason = null; TR.app.refresh(); } }, '✕')) : null; })() : null);
  }
  function decisionBar(f) {
    const pane = f.pane, info = pane.product.info(), key = (info.chassisSeries || '') + '|' + (info.chassisNumber || '');
    originalRevision(pane); serviceMode();
    const t3 = pane.product.current.nodes.some((n) => n.electricalArchitecture === 3);
    const [vLabel, vIcon, vTone] = validationState(f);
    const sv = W.save;
    const saveText = sv.state === 'saving' ? t('Saving…') : sv.state === 'saved' ? t('Revision {n} · saved {at}', { n: sv.rev, at: TR.culture ? TR.culture.format.time(sv.at) : '' }) : sv.state === 'failed' ? t('Not saved') : sv.state === 'conflict' ? t('Not saved: newer revision exists') : f.canEdit ? t('Not saved yet') : t('Read only: not saved');
    const item = (icon, label, value, tone, tip, extra) => h('div', { class: ['wf-fact', tone ? 'tone-' + tone : ''], 'data-tip': tip || null }, TR.icon(icon, 14), h('span', { class: 'wf-fact-text' }, h('small', null, t(label)), h('strong', null, value)), extra || null);
    // One sentence, always: vehicle · changes · check · saved. The eight facts are behind Details; problems (a failed save, a
    // conflict, an out-of-date check) are never hidden.
    const plain = plainState(f);
    const warnSave = sv.state === 'failed' || sv.state === 'conflict';
    const summary = h('div', { class: 'wf-summary' },
      h('p', { class: 'wf-sentence' },
        h('strong', null, pane.product.chassisString() + (pane.items.length > 1 ? ' +' + (pane.items.length - 1) : '')), h('span', { class: 'muted' }, ' (' + (t3 ? 'T3' : 'TEA2+') + ')'), ' · ',
        f.changes.total ? t('{n} change(s)', { n: f.changes.total }) : t(f.validated ? 'No edits of your own' : 'No changes yet'), ' · ',
        h('span', { class: 'wf-plain tone-' + plain[2] }, TR.icon(plain[1], 14), t(plain[0])),
        ' · ', h('span', { class: warnSave ? 'wf-plain tone-warning' : 'muted' }, warnSave ? [TR.icon('alert', 14), saveText] : saveText)),
      h('span', { class: 'wf-summary-actions' },
        f.stale ? TR.pages.ui.button(t('Check again'), 'flask', validate, 'secondary') : null,
        sv.state === 'failed' ? TR.pages.ui.button(t('Retry saving'), 'refresh', () => save(stateHash(), 'Autosave'), 'secondary') : null,
        h('button', { type: 'button', class: 'jr-link', 'aria-expanded': String(!!W.details), onClick: () => { W.details = !W.details; TR.app.refresh(); } }, t(W.details ? 'Hide details' : 'Details'), TR.icon(W.details ? 'up' : 'chevron', 13))));
    return h('section', { class: ['wf-bar', W.details ? 'is-open' : 'is-closed'], 'aria-label': t('About this request') }, summary,
      W.details ? h('div', { class: 'wf-facts' },
      item('truck', 'Vehicle', pane.product.chassisString() + (pane.items.length > 1 ? ' +' + (pane.items.length - 1) : ''), null, t('Architecture') + '|' + (t3 ? t('T3: HPC computers with software packages') : t('TEA2+: one software set per computer'))),
      item(t3 ? 'cpu' : 'chip', 'Architecture', t3 ? 'T3' : 'TEA2+', null),
      item('database', 'The vehicle now', W.original[key] ? t('VDA revision {n}', { n: W.original[key] }) : (pane.sourceType || 'VDA'), null, t('Original configuration|Kept unchanged; the proposal is compared with it.')),
      item('sliders', 'Your changes', t('{n} changes', { n: f.changes.total }), f.changes.total ? 'info' : null, t('Changed values|{a} software, {b} parameters, {c} variants, {d} S-Notes', { a: f.changes.nodes || 0, b: f.changes.parameters || 0, c: f.changes.variants || 0, d: f.changes.sNotes || 0 })),
      item(sv.state === 'failed' || sv.state === 'conflict' ? 'alert' : 'save', 'Saved', saveText, sv.state === 'failed' || sv.state === 'conflict' ? 'warning' : null, null,
        h('span', { class: 'wf-fact-actions' }, sv.state === 'failed' ? TR.pages.ui.button(t('Retry'), 'refresh', () => save(stateHash(), 'Autosave'), 'text') : null,
          f.canEdit ? TR.pages.ui.button(t('Revisions'), 'history', revisions, 'text') : null)),
      item('globe', 'Services', W.mode ? t(W.mode.label) : '…', W.mode ? W.mode.tone : null, W.mode ? t('Service mode') + '|' + t(W.mode.detail) : null),
      item(vIcon, 'Validation', t(vLabel), vTone, null, f.stale ? TR.pages.ui.button(t('Validate again'), 'flask', validate, 'text') : null)) : null,
      sv.state === 'conflict' ? h('div', { class: 's-banner warning wf-conflict', role: 'alert' }, TR.icon('alert'),
        h('span', null, h('strong', null, t('Your latest changes are not saved.')), ' ', sv.conflict, ' ', t('Nothing was overwritten.')),
        TR.pages.ui.button(t('Keep mine as a new revision'), 'save', keepMine, 'primary'), TR.pages.ui.button(t('Load the newer revision'), 'download', loadTheirs, 'secondary')) : null);
  }

  // ------------------------------------------------------------------ frame: on the test request (focused or two-pane)
  const baseFrame = S.frame;
  S.frame = (content) => {
    const frame = baseFrame(content);
    const main = frame && typeof frame.querySelector === 'function' ? frame.querySelector('.s-main') : null;
    if (!main || X.page || TR.app.page !== 'testrequest' || (TR.features && !TR.features.on('guided-journey'))) return frame;
    const f = facts();
    const view = S.view === 'expert' ? 'expert' : S.stage;
    const top = h('div', { class: 'wf-top' }, stepper(f, view), f.loaded ? decisionBar(f) : null);
    const crumbs = main.querySelector('.ap-crumbs'), slot = main.querySelector('.tw-steps-slot');
    if (slot) slot.replaceWith(top); else if (crumbs) crumbs.after(top); else main.prepend(top);
    if (f.loaded && S.view !== 'expert' && S.stage === 'validate' && S.validation) {
      const stats = main.querySelector('.s-stats');
      if (stats) stats.after(findingsPanel());
    }
    // The older six-step journey and the Configure / Validate / Review buttons are replaced by the stepper; the
    // Focused / Two-pane switch next to them stays.
    main.querySelectorAll('.jr, .s-progress > .s-step').forEach((el) => el.remove());
    scheduleSave();
    return frame;
  };

  TR.workflow = { plainState, stepperNow: () => stepper(facts(), S.view === 'expert' ? 'expert' : S.stage), W, facts, steps, validationState, explain, findings, announce, save, validate, CLASS, MEANS, goTo, shortNode, groupFindings, whereText };
})();
