/* Help → Getting started: "Your first test request, made simple". Replaces the earlier plain Getting started view and
 * keeps everything it had (the plain-language terms, the checks before sending, the illustrated guide).
 *
 *   Search            guides and terms as you type (Help articles and the glossary); Enter opens Help search
 *   Learn             Start a request (choose a vehicle) · Open illustrated guide
 *   How it works      the five steps; each opens the Help article that explains it
 *   Before you submit the checks for every request; ticks are remembered per person in this browser
 *   Key terms         six terms in plain language; View glossary lists every term in place */
(function () {
  'use strict';
  const { h } = TR.util;
  const J = TR.journey, t = J.t;
  const G = { q: '', glossary: false };
  const session = () => (TR.backend && TR.backend.session) || {};
  const CHECK_KEY = () => 'trstudio.' + (session().userId || 'user') + '.submitChecks';
  const STEPS = [
    ['truck', 'Choose a vehicle', 'Confirm the vehicle ID and starting configuration.', 'load-vehicle'],
    ['file', 'Prepare changes', 'Create a proposal with the changes you want to test.', 'change-software'],
    ['settings', 'Validate', 'Run a simulation and review errors and warnings.', 'validate'],
    ['search', 'Review', 'Compare the original and proposed configuration.', 'stages'],
    ['upload', 'Submit', 'Confirm the target and delivery with an authorized reviewer.', 'vda'],
  ];
  const CHECKS = [
    ['ids', 'Correct vehicle IDs'], ['values', 'Changed values reviewed'], ['latest', 'Latest proposal validated'],
    ['warnings', 'Errors and limited-validation warnings reviewed'], ['reviewer', 'Target and delivery confirmed by an authorized reviewer'],
  ];
  const TERMS = [
    ['layers', 'The vehicle now', 'The starting configuration.'], ['file', 'Your changes', 'Your planned version with changes.'], ['play', 'Simulation', 'A check of your plan. No software is installed.'],
    ['sliders', 'Parameter', 'A configurable setting or value.'], ['chip', 'Logical ECU', 'The logical identity of a vehicle computer.'], ['status', 'Ready / Blocked', 'Whether a vehicle can continue or needs attention.'],
  ];
  const glossary = () => Object.values((TR.ux && TR.ux.GLOSSARY) || {}).map((v) => { const [term, text] = String(v).split('|'); return { term, text: text || '' }; }).sort((a, b) => a.term.localeCompare(b.term));

  // ------------------------------------------------------------------ search
  function suggestions(q) {
    const s = String(q || '').trim().toLowerCase();
    if (s.length < 2) return [];
    const articles = TR.help && TR.help.find ? TR.help.find(s).slice(0, 5).map((a) => ({ kind: 'Guide', label: a.title, run: () => TR.help.open(a.id) })) : [];
    const terms = glossary().concat(TERMS.map(([, term, text]) => ({ term, text }))).filter((g, i, all) => all.findIndex((x) => x.term === g.term) === i)
      .filter((g) => (g.term + ' ' + g.text).toLowerCase().includes(s)).slice(0, 4).map((g) => ({ kind: 'Term', label: g.term, text: g.text, run: () => { G.glossary = true; G.q = ''; TR.app.refresh(); setTimeout(() => { const el = document.getElementById('gs-glossary'); if (el && el.scrollIntoView) el.scrollIntoView({ block: 'start', behavior: document.documentElement.dataset.motion === 'reduced' ? 'auto' : 'smooth' }); }, 30); } }));
    return articles.concat(terms);
  }
  function searchBox() {
    const list = suggestions(G.q);
    return h('div', { class: 'gs-search-wrap' },
      h('form', { class: 'gs-search', role: 'search', onSubmit: (e) => { e.preventDefault(); if (G.q.trim() && TR.help) TR.help.search(G.q.trim()); } },
        TR.icon('search', 18),
        h('input', { type: 'search', key: 'gs-q', 'aria-label': t('Search guides or terms'), placeholder: t('Search guides or terms'), value: G.q, autocomplete: 'off', 'aria-controls': 'gs-suggest', 'aria-expanded': String(!!list.length),
          onInput: (e) => { G.q = e.target.value; J.later(() => TR.app.refresh(), 120); }, onKeydown: (e) => { if (e.key === 'Escape') { G.q = ''; TR.app.refresh(); } if (e.key === 'ArrowDown') { const f = document.querySelector('#gs-suggest button'); if (f) { e.preventDefault(); f.focus(); } } } })),
      list.length ? h('ul', { id: 'gs-suggest', class: 'gs-suggest', role: 'listbox', 'aria-label': t('Suggestions') }, list.map((s) => h('li', null,
        h('button', { type: 'button', role: 'option', onClick: () => { G.q = ''; s.run(); } }, h('span', { class: 'gs-kind' }, t(s.kind)), h('span', { class: 'gs-label' }, s.label), s.text ? h('small', { class: 'muted' }, s.text) : null))),
        h('li', null, h('button', { type: 'button', class: 'gs-all', onClick: () => TR.help && TR.help.search(G.q.trim()) }, t('Search all of Help for “{q}”', { q: G.q.trim() }), TR.icon('arrow', 14)))) : null);
  }

  // ------------------------------------------------------------------ sections
  function start() {
    if (TR.header) TR.header.newRequest(); else if (TR.newRequest) TR.newRequest.open();
  }
  function hero() {
    const art = TR.personas && TR.personas.draw;
    return h('section', { class: 'gs-hero' },
      h('span', { class: 'gs-hero-icon', 'aria-hidden': 'true' }, TR.icon('book', 30)),
      h('div', { class: 'gs-hero-text' },
        h('h2', null, t('Learn the workflow in a few minutes')), h('p', null, t('Start with a vehicle and explore each step at your own pace.')),
        h('div', { class: 'gs-hero-actions' },
          TR.pages.ui.button(t('Start a request'), 'arrow', start, 'primary'),
          TR.pages.ui.button(t('Open illustrated guide'), 'file', () => (TR.testRequest && TR.testRequest.openGuide ? TR.testRequest.openGuide() : TR.uiGuide.open()), 'secondary'))),
      art ? h('div', { class: 'gs-hero-art', 'aria-hidden': 'true' }, h('span', { class: 'gs-cloud c1' }), h('span', { class: 'gs-cloud c2' }), TR.personas.draw('wave', 150, 'tech'), TR.personas.draw('wave', 190, 'truck')) : null);
  }
  function steps() {
    return h('section', { class: 'jr-card gs-steps', 'aria-labelledby': 'gs-steps-title' },
      h('h2', { id: 'gs-steps-title', class: 'gs-title' }, t('How a test request works')),
      h('ol', { class: 'gs-step-list' }, STEPS.map(([icon, title, text, article], i) => h('li', null,
        h('button', { type: 'button', class: 'gs-step', onClick: () => TR.help && TR.help.open(article), 'aria-label': t('{s}: {d} Open the guide.', { s: t(title), d: t(text) }) },
          h('span', { class: 'gs-n', 'aria-hidden': 'true' }, String(i + 1)), h('span', { class: 'gs-step-icon', 'aria-hidden': 'true' }, TR.icon(icon, 22)),
          h('strong', null, t(title)), h('span', { class: 'gs-step-text' }, t(text)), h('span', { class: 'gs-go', 'aria-hidden': 'true' }, TR.icon('right', 18)))))));
  }
  function checks() {
    const ticked = new Set(TR.util.store.get(CHECK_KEY(), []) || []);
    const toggle = (k, on) => { if (on) ticked.add(k); else ticked.delete(k); TR.util.store.set(CHECK_KEY(), [...ticked]); TR.app.refresh(); };
    return h('section', { class: 'jr-card gs-checks', 'aria-labelledby': 'gs-checks-title' },
      h('div', { class: 'gs-checks-head' }, h('div', null, h('h2', { id: 'gs-checks-title', class: 'gs-title' }, t('Before you submit')), h('p', { class: 'muted' }, t('Review these checks for every request.'))),
        ticked.size ? h('button', { class: 'jr-link', onClick: () => { TR.util.store.set(CHECK_KEY(), []); TR.app.refresh(); } }, t('Clear ticks')) : null),
      h('ul', { class: 'gs-check-list' }, CHECKS.map(([k, l]) => h('li', null, h('label', { class: 'gs-check' },
        h('input', { type: 'checkbox', checked: ticked.has(k), onChange: (e) => toggle(k, e.target.checked) }), h('span', null, t(l)))))),
      h('p', { class: 'gs-note' }, TR.icon('info', 18), t('A simulation checks the plan. It does not install software.')),
      h('small', { class: 'muted' }, t('{n} of {all} checked. Ticks are remembered in this browser.', { n: ticked.size, all: CHECKS.length })));
  }
  function terms() {
    const all = glossary();
    return h('section', { class: 'jr-card gs-terms', 'aria-labelledby': 'gs-terms-title' },
      h('div', { class: 'gs-terms-head' }, h('h2', { id: 'gs-terms-title', class: 'gs-title' }, t('Key terms, in plain language')),
        all.length ? h('button', { class: 'jr-link', 'aria-expanded': String(G.glossary), 'aria-controls': 'gs-glossary', onClick: () => { G.glossary = !G.glossary; TR.app.refresh(); } }, t(G.glossary ? 'Hide glossary' : 'View glossary'), TR.icon(G.glossary ? 'up' : 'arrow', 14)) : null),
      h('ul', { class: 'gs-term-grid' }, TERMS.map(([icon, term, text]) => h('li', { class: 'gs-term' },
        icon === 'status' ? h('span', { class: 'gs-term-icon gs-status', 'aria-hidden': 'true' }, h('span', { class: 'ok' }, TR.icon('check', 14)), '/', h('span', { class: 'warn' }, TR.icon('alert', 14)))
          : h('span', { class: 'gs-term-icon', 'aria-hidden': 'true' }, TR.icon(icon, 22)),
        h('span', null, h('strong', null, t(term)), h('small', { class: 'muted' }, t(text)))))),
      G.glossary ? h('dl', { id: 'gs-glossary', class: 'gs-glossary' }, all.map((g) => [h('dt', null, g.term), h('dd', null, g.text)])) : null);
  }

  function render() {
    return h('div', { class: 'jr-page gs-page' },
      h('div', { class: 'gs-top' }, J.pageHead('Your first test request, made simple', 'Choose a vehicle, prepare a proposal, and validate the impact before you submit.'), searchBox()),
      hero(),
      h('div', { class: 'gs-grid' }, steps(), checks()),
      terms(),
      h('footer', { class: 'gs-foot' },
        h('button', { class: 'jr-link', onClick: () => TR.pages.show('help') }, TR.icon('help', 15), t('Help & support'))));
  }

  TR.pages.register({ id: 'learn', title: 'Getting started', crumbs: () => [{ label: t('Help'), open: () => TR.pages.show('help') }, { label: t('Getting started') }], render });
  TR.gettingStarted = { G, suggestions, STEPS, CHECKS, TERMS };
})();
