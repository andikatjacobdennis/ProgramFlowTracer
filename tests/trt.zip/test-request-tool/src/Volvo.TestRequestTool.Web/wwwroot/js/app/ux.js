/* Low-effort guidance, from the input wireframes and current calm, adaptive UX practice:
 *
 *   Idle nudge      – after a quiet moment the next action (the Next button) pulses gently, so it is obvious what to do.
 *   Adaptive mode   – Beginner shows quick guides and hides expert tools behind "More tools"; Expert is compact and skips the
 *                     hand-holding. Auto starts as Beginner and moves to Expert once you have validated a few times or use the
 *                     expert tools (a simple local rule, no AI). Settings → Workspace → Experience.
 *   Quick guide     – a three-step card at the top of each main screen (as on every wireframe); it can be collapsed.
 *   Journey         – the whole workflow in six steps (Vehicles → Edit → Configure → Validate → Compare → Deliver), with
 *                     where you are now.
 *   Stale results   – "Your validation is out of date" with one button, whenever a proposal changed after validating.
 *   Glossary        – technical words (VDA, ECU, NTP, S-Notes …) explain themselves on hover or focus.
 *   Calm mode       – softer colours, no confetti or decoration; motion that explains only. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => TR.i18n.t(s, v);
  const S = TR.testRequest, X = TR.experience, root = document.documentElement;
  const userKey = (k) => 'trstudio.' + ((TR.backend && TR.backend.session && TR.backend.session.userId) || 'user') + '.' + k;

  // ------------------------------------------------------------------ adaptive mode
  const usage = () => TR.util.store.get(userKey('usage'), { validations: 0, expert: 0 }) || { validations: 0, expert: 0 };
  const bump = (k) => { const u = usage(); u[k] = (u[k] || 0) + 1; TR.util.store.set(userKey('usage'), u); };
  /** 'beginner' or 'expert'. Auto: expert after three validations or two visits to the expert tools. */
  function level() {
    const pick = TR.prefs.get('experience');
    if (pick === 'beginner' || pick === 'expert') return pick;
    const u = usage();
    return u.validations >= 3 || u.expert >= 2 ? 'expert' : 'beginner';
  }
  const run = TR.request.runRequest;
  TR.request.runRequest = async (...args) => { const r = await run(...args); bump('validations'); return r; };
  const expert = S.expert;
  S.expert = (...args) => { bump('expert'); return expert(...args); };
  const apply = () => { root.dataset.experience = level(); root.dataset.calm = TR.prefs.get('calm') ? 'on' : 'off'; };
  apply();
  TR.prefs.onChange(apply);

  // ------------------------------------------------------------------ quick guides (three steps per screen)
  const GUIDES = {
    home: ['Add a vehicle, or open one you saved.', 'Plan a change on the Test request.', 'Validate it and follow the Next button to deliver.'],
    dashboard: ['Start with Needs attention: the most urgent vehicle is first.', 'Groups and Unusual vehicles show patterns across the fleet.', 'Open a vehicle to see its Insights.'],
    vehicle: ['Graph shows the vehicle; Compare with shows what changed.', 'Roadmap shows where it can go next and what blocks it.', 'History shows who changed what; Insights sums it up.'],
    testrequest: ['Configure: pick the changes on the tabs below.', 'Validate: check what they would do on every vehicle.', 'Review: compare and choose how to deliver.'],
    activity: ['Use the tabs to see Ready, Limited or Blocked requests.', 'Search or sort, then click a row to inspect it.', 'Export the list as CSV or JSON.'],
    settings: ['Search any setting at the top.', 'Changes save straight away.', 'Language and region sets your time zone and formats.'],
  };
  const guideKey = (id) => userKey('quickguide.' + id);
  function quickGuide(id) {
    const steps = GUIDES[id];
    if (!steps || level() !== 'beginner') return null;
    const closed = TR.util.store.get(guideKey(id), true);
    const toggle = () => { TR.util.store.set(guideKey(id), !closed); TR.app.refresh(); };
    return h('section', { class: ['qg', closed ? 'is-closed' : ''], 'aria-label': t('Quick guide') },
      h('button', { class: 'qg-head', 'aria-expanded': String(!closed), onClick: toggle }, TR.icon('route', 15), h('strong', null, t('Quick guide')), h('span', { class: 'muted' }, closed ? t('Show') : t('Hide'))),
      closed ? null : h('ol', { class: 'qg-steps' }, steps.map((s, i) => h('li', null, h('span', { class: 'qg-n' }, String(i + 1)), t(s)))));
  }

  // ------------------------------------------------------------------ the journey (six steps)
  const STEPS = [['vehicles', 'Vehicles', 'truck'], ['edit', 'Edit', 'sliders'], ['configure', 'Configure', 'settings'], ['validate', 'Validate', 'flask'], ['compare', 'Compare', 'compare'], ['deliver', 'Deliver', 'box']];
  function where() {
    const L = TR.app.shell.left;
    if (!L || !L.product.loaded()) return 0;
    let changes = 0; try { const c = TR.model.deltaCounts(L.product.delta()); changes = c.nodes + c.parameters + c.variants + c.sNotes; } catch (e) { /* none */ }
    if (S.validation && S.fresh()) return S.stage === 'review' ? 5 : 4;
    if (S.validation) return 3;
    return changes ? 2 : 1;
  }
  function journey() {
    const at = where();
    const go = [() => { X.page = null; S.intake(); }, () => S.page('software'), () => S.page(), () => TR.nextStep().run(), () => { X.page = null; S.page(); S.stage = 'review'; TR.app.refresh(); }, () => { X.page = null; S.page(); S.stage = 'review'; TR.app.refresh(); }];
    return h('nav', { class: 'jr', 'aria-label': t('Your progress') }, STEPS.map(([id, label, icon], i) =>
      h('button', { class: ['jr-step', i < at ? 'is-done' : '', i === at ? 'is-now' : ''], 'aria-current': i === at ? 'step' : null, onClick: go[i], 'data-tip': t(label) + '|' + (i < at ? t('Done') : i === at ? t('You are here') : t('Later')) },
        h('span', { class: 'jr-dot' }, i < at ? TR.icon('check', 13) : TR.icon(icon, 13)), h('span', { class: 'jr-label' }, t(label)))));
  }

  // ------------------------------------------------------------------ frame: journey, quick guide, stale banner
  const base = S.frame;
  S.frame = (content) => {
    const frame = base(content), main = frame && typeof frame.querySelector === 'function' ? frame.querySelector('.s-main') : null;
    if (!main) return frame;
    const page = TR.pages.current() || (TR.app.page === 'testrequest' && S.view !== 'expert' ? 'testrequest' : null);
    const crumbs = main.querySelector('.ap-crumbs');
    const extra = [];
    // The five-step journey (workflow.js) replaces the older six-step one; the test request page adds it itself.
    if (page === 'vehicle') extra.push(TR.workflow && (!TR.features || TR.features.on('guided-journey')) ? TR.workflow.stepperNow() : journey());
    else if ((!TR.workflow || (TR.features && !TR.features.on('guided-journey'))) && page === 'testrequest') extra.push(journey());
    if (S.validation && !S.fresh() && !X.page && TR.app.page === 'testrequest') extra.push(h('div', { class: 's-banner warning ux-stale', role: 'status' }, TR.icon('alert'), h('span', null, h('strong', null, t('Your validation is out of date.')), ' ', t('The proposal or the request settings changed after you validated.')), TR.pages.ui.button(t('Validate again'), 'flask', () => TR.nextStep().run(), 'primary')));
    // Home uses optional onboarding. Request pages own their guidance and stepper.
    const ownsGuidance = page === 'home' || main.querySelector('.tw-page, .jr-page') || (TR.workflow && (!TR.features || TR.features.on('guided-journey')) && page === 'testrequest');
    const qg = ownsGuidance ? null : quickGuide(page || (!X.page && TR.app.page === 'testrequest' ? 'testrequest' : ''));
    if (qg) extra.push(qg);
    if (crumbs) crumbs.after(...extra); else extra.forEach((e) => main.prepend(e));
    // Beginner: expert tools fold away behind "More tools".
    frame.querySelectorAll('.s-rail-section').forEach((sec) => { if (/^tools$/i.test((sec.querySelector('.s-eyebrow') || {}).textContent || '')) sec.classList.add('ux-tools'); });
    return frame;
  };

  // ------------------------------------------------------------------ idle nudge
  let lastInput = Date.now(), nudged = false;
  const IDLE_MS = 25000;
  const input = () => { lastInput = Date.now(); if (nudged) { nudged = false; document.querySelectorAll('.is-nudge').forEach((el) => el.classList.remove('is-nudge')); } };
  if (typeof document.addEventListener === 'function') ['pointerdown', 'keydown', 'wheel', 'touchstart'].forEach((ev) => document.addEventListener(ev, input, { passive: true, capture: true }));
  if (typeof setInterval === 'function' && typeof document.querySelector === 'function') setInterval(() => {
    if (nudged || Date.now() - lastInput < IDLE_MS || TR.prefs.get('nudge') === false || document.hidden) return;
    if (document.querySelector('#overlays .overlay, .tr-layer, .wl-layer, .pl-layer')) return;
    const target = document.querySelector('.ap-next') || document.querySelector('.ap-view .s-btn.primary');
    if (!target) return;
    nudged = true;
    target.classList.add('is-nudge');
    if (TR.personas) TR.personas.react(null, 'stretch');
    setTimeout(() => target.classList.remove('is-nudge'), 6000);
  }, 3000);

  // ------------------------------------------------------------------ glossary: technical words explain themselves
  const GLOSSARY = {
    VDA: 'Vehicle data record|The official record of each vehicle’s configuration.', EDB: 'Engineering database|Where vehicle specifications come from before production.',
    ECU: 'Vehicle computer (ECU)|Electronic control unit: one computer in the vehicle, such as EMS for the engine.', HPC: 'High-performance computer|A T3 computer that runs several software packages in execution environments.',
    NTP: 'Node template (NTP)|The approved software set for one vehicle computer.', 'S-Notes': 'Special notes|Short codes that record special builds or exceptions on a vehicle.',
    CBR: 'Cab order (CBR)|The order number used to plan a spare cab.', T3: 'T3 architecture|The newest electrical architecture, with HPC computers.', 'TEA2+': 'TEA2+ architecture|The previous electrical architecture, with one software set per computer.',
    PUS: 'Product Update Service|Finds the right service pack for a T3 vehicle.', APU: 'Available Product Updates|Lists software, hardware and kits a T3 vehicle can take.',
    'Logical ECU': 'Logical ECU|The logical identity of a T3 computer, used by its software.', Proposal: 'Proposal|Your planned changes. The original is kept unchanged.',
  };
  function tag(scope) {
    if (typeof scope.querySelectorAll !== 'function') return;
    scope.querySelectorAll('.s-chip, th, .s-tab, .tab, .vh-node-name small, .gh-file-kind, .s-eyebrow, .vh-legend span, label > span:first-child').forEach((el) => {
      if (el.hasAttribute('data-tip')) return;
      const text = (el.textContent || '').trim(), key = GLOSSARY[text] ? text : Object.keys(GLOSSARY).find((k) => text.startsWith(k + ' ') || text.endsWith(' ' + k));
      if (key) { el.setAttribute('data-tip', t(GLOSSARY[key])); el.classList.add('ux-term'); }
    });
  }
  if (typeof MutationObserver === 'function' && typeof document.body !== 'undefined' && document.body) {
    let pending = false;
    new MutationObserver(() => { if (pending) return; pending = true; requestAnimationFrame(() => { pending = false; tag(document.getElementById('app') || document.body); }); }).observe(document.body, { childList: true, subtree: true });
  }

  TR.ux = { level, usage, quickGuide, journey, where, GLOSSARY, tag, GUIDES };
})();
