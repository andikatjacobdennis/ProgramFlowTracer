/* Feature flags in the browser (server: FeatureFlags.cs, Microsoft.FeatureManagement). TR.features.on(name) says whether a
 * flag is on for you; until the answer arrives the built-in default applies (all current flags default to on). Pages,
 * navigation and features check it; the server enforces the same flags on its endpoints.
 *
 * The Feature flags page (administrators): each flag Off, On or Targeted (people, teams, roles, a percentage of everyone
 * else, exclusions), with "Who gets it" evaluated by the server exactly as at run time. Changes are versioned and audited. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));
  const F = { flags: null, loaded: false };
  async function load() {
    if (typeof fetch !== 'function' || typeof location === 'undefined' || !/^https?:$/.test(location.protocol)) return;
    try { const r = await fetch('/api/v1/features'); if (r.ok) { F.flags = await r.json(); F.loaded = true; loadAi(); if (TR.app && TR.app.shell && TR.app.shell.left) TR.app.refresh(); } } catch (e) { /* defaults stay */ }
  }
  // Flags whose built-in default is off (the AI features and Require approval): off until the server says otherwise.
  const OFF_BY_DEFAULT = new Set(['ai', 'ai-chat', 'ai-summaries', 'ai-agent', 'require-approval']);
  const on = (name) => (F.flags ? F.flags[name] === true || (F.flags[name] === undefined && !OFF_BY_DEFAULT.has(name)) : !OFF_BY_DEFAULT.has(name));
  /** The AI module is loaded only when the AI flags allow it: nothing AI-related is fetched or run otherwise. */
  let aiLoaded = false;
  function loadAi() {
    if (aiLoaded || !on('ai') || !(on('ai-chat') || on('ai-summaries') || on('ai-agent')) || typeof document.createElement !== 'function') return;
    aiLoaded = true;
    const s = document.createElement('script'); s.src = '/js/app/assistant.js'; s.async = true; document.head.appendChild(s);
  }
  /** The page shown in place of a feature that is switched off. */
  const offPage = (title) => h('div', { class: 'st-page' }, h('h1', null, t(title)),
    h('div', { class: 's-banner' }, TR.icon('info'), h('span', null, t('This feature is switched off for you. An administrator can turn it on in Feature flags.'))),
    TR.pages.ui.button(t('Go to Home'), 'arrow', () => TR.pages.show('home'), 'primary'));
  TR.features = { F, load, on, offPage };
  /** The flag that gates a page, or null. */
  const flagOf = (page) => (GATED_REF[page] ? GATED_REF[page][0] : null);
  const GATED_REF = {};
  TR.features.flagOf = flagOf;
  setTimeout(load, 0);

  // Pages behind a flag show the "switched off" page instead (the server answers 404 for their data anyway).
  const GATED = { health: ['service-health', 'Service health'], logs: ['logs-viewer', 'Logs'], teams: ['teams', 'Teams'], usage: ['usage-study', 'Usage study'],
    requests: ['reviews', 'Requests'], review: ['reviews', 'Get approval'], submit: ['reviews', 'Send'], outcome: ['reviews', 'Submission complete'],
    execution: ['execution-trace', 'Request execution'], impact: ['change-impact', 'Change impact'], readiness: ['fleet-readiness', 'Fleet readiness'], engineering: ['engineering-insights', 'Engineering insights'], campaigns: ['campaigns', 'Campaigns'] };
  Object.assign(GATED_REF, GATED);
  const register = TR.pages.register;
  TR.pages.register = (page) => {
    const gate = GATED[page.id];
    if (gate) { const render = page.render; page = Object.assign({}, page, { render: () => (on(gate[0]) ? render() : offPage(gate[1])) }); }
    return register(page);
  };

  // ------------------------------------------------------------------ the Feature flags page
  const A = { data: null, teams: null, people: null, preview: {}, edit: {}, error: null };
  async function api(path, method, body) {
    const r = await fetch('/api/v1' + path, { method: method || 'GET', headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
    const json = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(json.detail || json.title || r.statusText);
    return json;
  }
  async function loadAdmin() {
    try { A.data = await api('/admin/features'); const teams = await api('/admin/teams').catch(() => null); A.teams = teams ? teams.teams : []; A.people = teams ? teams.people : []; A.error = null; }
    catch (e) { A.error = e.message; }
    TR.app.refresh();
  }
  const ROLES = ['Admin', 'Engineer', 'Reviewer', 'Viewer', 'Writer', 'Operator', 'Editor'];
  function editor(f) {
    const s = A.edit[f.name] || (A.edit[f.name] = JSON.parse(JSON.stringify(Object.assign({ mode: 'off', rollout: 0, users: [], groups: [], exclude: [] }, f.state))));
    const toggleIn = (list, v) => { const i = s[list].indexOf(v); if (i >= 0) s[list].splice(i, 1); else s[list].push(v); TR.app.refresh(); };
    const save = async () => { try { await api('/admin/features/' + encodeURIComponent(f.name), 'PUT', s); delete A.edit[f.name]; A.preview[f.name] = null; await loadAdmin(); await load(); TR.notify.toast(t('{f}: saved.', { f: f.title }), 'success'); } catch (e) { TR.notify.toast(e.message, 'error'); } };
    const preview = async () => { try { A.preview[f.name] = await api('/admin/features/' + encodeURIComponent(f.name) + '/preview'); TR.app.refresh(); } catch (e) { TR.notify.toast(e.message, 'error'); } };
    const changed = JSON.stringify(s) !== JSON.stringify(Object.assign({ mode: 'off', rollout: 0, users: [], groups: [], exclude: [] }, f.state));
    return h('article', { class: 'st-card hl-card ff-flag' },
      h('header', { class: 'hl-card-head' }, h('div', null, h('h2', null, t(f.title), ' ', h('code', { class: 'muted' }, f.name)), h('p', { class: 'muted' }, t(f.description) + ' ' + t('Default: {d}.', { d: f.defaultOn ? t('on') : t('off') }))),
        h('div', { class: 'tp-seg', role: 'radiogroup', 'aria-label': t('{f} state', { f: t(f.title) }) }, [['off', 'Off'], ['on', 'On'], ['targeted', 'Targeted']].map(([m, l]) =>
          h('button', { type: 'button', role: 'radio', 'aria-checked': String(s.mode === m), class: s.mode === m ? 'is-on' : '', onClick: () => { s.mode = m; TR.app.refresh(); } }, t(l))))),
      s.mode === 'targeted' ? h('div', { class: 'ff-target' },
        h('label', { class: 's-field' }, h('span', null, t('Everyone else: {p} %', { p: s.rollout })), h('input', { type: 'range', min: 0, max: 100, step: 5, value: s.rollout, 'aria-valuetext': s.rollout + ' %', onInput: (e) => { s.rollout = Number(e.target.value); TR.app.refresh(); } })),
        h('fieldset', { class: 'tm-people' }, h('legend', null, t('Teams and roles (always on)')),
          (A.teams || []).map((tm) => h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: s.groups.includes('team:' + tm.id), onChange: () => toggleIn('groups', 'team:' + tm.id) }), t('Team') + ' ' + tm.name)),
          ROLES.map((r) => h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: s.groups.includes('role:' + r), onChange: () => toggleIn('groups', 'role:' + r) }), t('Role') + ' ' + t(r)))),
        h('fieldset', { class: 'tm-people' }, h('legend', null, t('People (always on / never)')),
          (A.people || []).map((p) => h('div', { class: 'ff-person' }, h('span', null, p.name + ' · ' + p.role),
            h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: s.users.includes(p.id), onChange: () => toggleIn('users', p.id) }), t('On')),
            h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: s.exclude.includes(p.id), onChange: () => toggleIn('exclude', p.id) }), t('Never')))))) : null,
      h('div', { class: 'tm-actions' },
        TR.pages.ui.button(t('Save'), 'save', save, 'primary', { disabled: !changed }),
        changed ? TR.pages.ui.button(t('Undo changes'), 'undo', () => { delete A.edit[f.name]; TR.app.refresh(); }, 'text') : null,
        TR.pages.ui.button(t('Who gets it'), 'people', preview, 'text')),
      A.preview[f.name] ? h('ul', { class: 'ff-preview', 'aria-label': t('Who gets {f}', { f: t(f.title) }) }, A.preview[f.name].map((p) =>
        h('li', null, p.on ? TR.icon('check', 13) : TR.icon('close', 13), ' ', h('strong', null, p.name), ' · ' + p.role + ': ', p.on ? t('on') : t('off')))) : null);
  }
  function render() {
    if (!(TR.backend && TR.backend.session && TR.backend.session.isAdmin)) return h('div', { class: 'st-page' }, h('h1', null, t('Feature flags')), h('div', { class: 's-banner' }, TR.icon('lock'), t('Only administrators can change feature flags.')));
    if (!A.data && !A.error) loadAdmin();
    return h('div', { class: 'st-page hl-page' },
      h('div', { class: 'st-head' }, h('h1', null, t('Feature flags')), h('p', { class: 'muted' }, t('Turn features on or off for everyone, or for chosen people, teams, roles and a share of everyone else. Takes effect at once; every change is versioned and in the audit log. The server enforces the same flags.'))),
      A.error ? h('div', { class: 's-banner warning' }, TR.icon('alert'), A.error) : null,
      !A.data ? h('p', { class: 'muted' }, t('Loading…')) : h('div', { class: 'ff-list' }, A.data.flags.map(editor)));
  }
  TR.pages.register({ id: 'features', title: 'Feature flags', crumbs: () => [{ label: t('Settings'), open: () => TR.pages.show('settings') }, { label: t('Feature flags') }], render });
})();
