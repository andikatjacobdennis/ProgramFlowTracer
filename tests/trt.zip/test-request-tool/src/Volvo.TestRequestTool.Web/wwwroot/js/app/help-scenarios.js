/* Thirty things you can do: task-sized scenarios for the Help Center. Each becomes a Help article in the "Scenarios"
 * topic, so search finds them, and the Scenarios page lists them as a filterable gallery.
 *
 * Scenario: { id, title, goal, area, level: 'Beginner'|'Intermediate'|'Expert', minutes, steps, try?: action, tip? }
 * try is an action from help.js (ACTIONS) with its arguments. Text may use `code`, **bold** and *emphasis*. */
(function () {
  'use strict';
  const T3 = ['FH', '333333'], LEGACY = ['FH', '123456'];
  const SCENARIOS = [
    // ---------------------------------------------------------------- get started
    { id: 'sc-first-request', area: 'Get started', level: 'Beginner', minutes: 3, title: 'Run your first test request', goal: 'Load a vehicle, change one software version and see the result.',
      steps: ['Load the T3 truck `FH 333333`.', 'On the **Software** tab, choose version `1.2.0` for VCM-Platform.', 'Choose **Validate 1 vehicle**.', 'Read the result, then choose **Review results**.'],
      try: { label: 'Load FH 333333', run: 'loadVehicle', args: T3 }, tip: 'Follow the coloured Next button and you cannot go wrong.' },
    { id: 'sc-draft', area: 'Get started', level: 'Beginner', minutes: 1, title: 'Save your work and continue later', goal: 'Keep a proposal and pick it up another day.',
      steps: ['Plan your change as usual.', 'Choose **Save draft** at the bottom of the test request.', 'Later, choose **Open saved draft** on Home or in the sidebar.'] },
    { id: 'sc-bookmark', area: 'Get started', level: 'Beginner', minutes: 1, title: 'Bookmark vehicles you use often', goal: 'Get back to a vehicle in one click.',
      steps: ['Load the vehicle.', 'Open **Saved vehicles** in the sidebar and bookmark it.', 'Next time, open it from Saved vehicles. Recently loaded sources are listed there too.'], try: { label: 'Open Saved vehicles', run: 'page', args: ['library'] } },
    { id: 'sc-roles', area: 'Get started', level: 'Beginner', minutes: 1, title: 'Understand what your role can do', goal: 'See whether you can edit, simulate or commit.',
      steps: ['Look at the welcome card on **Home**: it lists what your role allows.', 'Engineers edit and simulate, Reviewers simulate and commit, Viewers only look, Admins do everything.', 'An administrator can change your role under **Administration → Users**.'], try: { label: 'Open Home', run: 'page', args: ['home'] } },

    // ---------------------------------------------------------------- software changes
    { id: 'sc-multi-vehicle', area: 'Software changes', level: 'Intermediate', minutes: 3, title: 'Validate one change on several vehicles', goal: 'Check the same proposal on more than one vehicle at once.',
      steps: ['Load the first vehicle, then choose **Add vehicle** in the sidebar for the next one.', 'Plan the change.', 'Choose **Validate N vehicles**: every loaded vehicle is checked.', 'Select a vehicle in the sidebar to read its own result.'] },
    { id: 'sc-released-only', area: 'Software changes', level: 'Intermediate', minutes: 1, title: 'Plan with released versions only', goal: 'Keep pre-release software out of a request.',
      steps: ['Choose **Configure request** at the bottom of the test request.', 'Set the scenario to **Released**.', 'Validate. Only released versions are used.', 'To make it your default, set it in Settings → Requests.'], try: { label: 'Set the default scenario', run: 'settings', args: ['requests'] } },
    { id: 'sc-parameters', area: 'Software changes', level: 'Intermediate', minutes: 2, title: 'Change a parameter value', goal: 'Edit a configured value and check it is allowed.',
      steps: ['Load `FH 123456` and open the **Parameters** tab.', 'Change the value of `P1ALG`.', 'Validate. A value outside the allowed range, such as `999`, blocks delivery with a clear message.'], try: { label: 'Load FH 123456', run: 'loadVehicle', args: LEGACY } },
    { id: 'sc-variants', area: 'Software changes', level: 'Intermediate', minutes: 2, title: 'Add or remove a variant', goal: 'Change the vehicle’s variant codes.',
      steps: ['Open the **Variants** tab.', 'Choose **Add Variants**, or remove one from the list.', 'Use **Evaluate** to test an expression, for example `D13K500 & (LHD | RHD)`.', 'Validate the proposal.'] },
    { id: 'sc-export', area: 'Software changes', level: 'Beginner', minutes: 1, title: 'Export the proposed product as XML', goal: 'Get a file of the proposal for another tool.',
      steps: ['Validate the proposal and go to **Review**.', 'Under **Export & inspect**, download the product XML.'] },
    { id: 'sc-xml', area: 'Software changes', level: 'Intermediate', minutes: 2, title: 'Load a product from an XML file', goal: 'Start from a file instead of VDA.',
      steps: ['Download the sample product XML below.', 'Choose **Add a vehicle** and pick the **File** source.', 'Drop the file or choose it. The vehicle keeps its registered identity and context.'], try: { label: 'Download the sample product XML', run: 'download', args: ['product'] } },

    // ---------------------------------------------------------------- T3
    { id: 'sc-service-pack', area: 'T3', level: 'Beginner', minutes: 2, title: 'Update a T3 truck to the latest service pack', goal: 'Let the Product Update Service pick the right service pack.',
      steps: ['Load the T3 truck `FH 333333`.', 'Choose **Update to service pack**.', 'Keep schema 2.0 and scenario Introduced, then run it.', 'Read the service pack and the packages per HPC computer. **Contract response** shows the JSON.'], try: { label: 'Open Product Update Service', run: 'pus' }, tip: 'Try the Released scenario too: then no service pack fits, and the result explains why.' },
    { id: 'sc-apu-hardware', area: 'T3', level: 'Intermediate', minutes: 2, title: 'Check which hardware a T3 update needs', goal: 'Find hardware replacements before you plan an update.',
      steps: ['Load `FH 333333`.', 'Choose **Available product updates** with the scenario *InProgress*.', 'Scroll to **Hardware replacements**: VCM 26.30 and later need ECU hardware `21601602`.'], try: { label: 'Load FH 333333', run: 'loadVehicle', args: T3 } },
    { id: 'sc-logical-ecu', area: 'T3', level: 'Expert', minutes: 2, title: 'Edit a logical ECU on an HPC computer', goal: 'Change the logical identity of a T3 computer.',
      steps: ['Load `FH 333333` and open **Vehicle → Graph**.', 'Click the VCM computer.', 'Choose **Edit logical ECU** in its details.'], try: { label: 'Open the vehicle graph', run: 'vehicleTab', args: ['graph', ...T3] } },

    // ---------------------------------------------------------------- deliver
    { id: 'sc-commit-vda', area: 'Deliver', level: 'Intermediate', minutes: 3, title: 'Commit a validated change to VDA', goal: 'Write the result to VDA, safely.',
      steps: ['Validate a proposal until it is **Ready**.', 'Go to **Review** and open **VDA update**.', 'Preview the snapshot, then commit it.', 'Open **Vehicle → History**: your commit is on the main line with your name.'], tip: 'If someone else changed VDA in the meantime, the commit is refused so nothing is overwritten.' },
    { id: 'sc-create-kit', area: 'Deliver', level: 'Intermediate', minutes: 3, title: 'Create a conversion kit from a result', goal: 'Package validated changes as an immutable kit.',
      steps: ['Validate the proposal.', 'Go to **Review** and open **Conversion kits**.', 'Choose the vehicles and a name, then **Create kit**.', 'The kit appears in the vehicle history on the branch of its simulation.'] },
    { id: 'sc-reopen-request', area: 'Deliver', level: 'Intermediate', minutes: 1, title: 'Reopen an earlier request', goal: 'Look again at a result you ran before.',
      steps: ['Open **Activity**.', 'Search by vehicle or type, or filter by request type.', 'Click a row to inspect the stored request and result.'], try: { label: 'Open Activity', run: 'page', args: ['activity'] } },

    // ---------------------------------------------------------------- vehicle insight
    { id: 'sc-why-blocked', area: 'Vehicle insight', level: 'Beginner', minutes: 1, title: 'Find out why a newer version is blocked', goal: 'See exactly what stands in the way of an update.',
      steps: ['Open **Vehicle → Roadmap**.', 'Find the computer. A lock under a version explains it, for example *Needs ECU hardware 21601602*.', 'The same reasons appear when you click the computer on the Graph.'], try: { label: 'Open the roadmap for FH 333333', run: 'vehicleTab', args: ['roadmap', ...T3] } },
    { id: 'sc-compare-factory', area: 'Vehicle insight', level: 'Beginner', minutes: 1, title: 'See what changed since the factory', goal: 'Compare today’s vehicle with how it was built.',
      steps: ['Open **Vehicle → Graph**.', 'Set **Compare with** to *Built at the factory*.', 'Red with a minus is how it was built; green with a plus is how it is now.'], try: { label: 'Open the graph for FH 123456', run: 'vehicleTab', args: ['graph', ...LEGACY] } },
    { id: 'sc-who-changed', area: 'Vehicle insight', level: 'Beginner', minutes: 1, title: 'Find who changed a vehicle and when', goal: 'Trace every change to a person and a date.',
      steps: ['Open **Vehicle → History**.', 'Click a person under **People** to see only their changes.', 'Click the **+3 −3** count of an entry to see exactly what changed.'], try: { label: 'Open the history for FH 123456', run: 'vehicleTab', args: ['history', ...LEGACY] } },
    { id: 'sc-waiting', area: 'Vehicle insight', level: 'Beginner', minutes: 1, title: 'Find updates that are available but not installed', goal: 'Spot software the vehicle could already be running.',
      steps: ['Open **Vehicle → Insights**.', 'Read the card *available updates are not installed*.', 'On the software timeline, amber diamonds mark them at their release week.'], try: { label: 'Open insights for FH 123456', run: 'vehicleTab', args: ['insights', ...LEGACY] } },
    { id: 'sc-version-timeline', area: 'Vehicle insight', level: 'Intermediate', minutes: 2, title: 'See how long each computer ran each version', goal: 'Understand a vehicle’s software life since the factory.',
      steps: ['Open **Vehicle → Insights**.', 'Each lane of the **Software timeline** is a computer; each bar is a version, from its start to its end.', 'Click a bar to open the graph compared with the vehicle at that change.'], try: { label: 'Open insights for FH 123456', run: 'vehicleTab', args: ['insights', ...LEGACY] } },
    { id: 'sc-simulation-branch', area: 'Vehicle insight', level: 'Intermediate', minutes: 1, title: 'Tell simulations from real changes', goal: 'Read the git-style history at a glance.',
      steps: ['Open **Vehicle → History**.', 'Filled dots on the main line changed the vehicle. Hollow dots on a branch are simulations; diamonds are kits.', 'A branch that joins the main line was committed.'] },

    // ---------------------------------------------------------------- fleet
    { id: 'sc-fleet-attention', area: 'Fleet', level: 'Intermediate', minutes: 2, title: 'Decide which vehicle to update first', goal: 'Use the dashboard to prioritise.',
      steps: ['Open the **Dashboard**.', 'Look at **Needs attention**: the most urgent vehicle is first.', 'Choose **Open** to go straight to its Insights.'], try: { label: 'Open the Dashboard', run: 'page', args: ['dashboard'] } },
    { id: 'sc-service-pack-coverage', area: 'Fleet', level: 'Intermediate', minutes: 1, title: 'See which vehicles a service pack can update', goal: 'Plan a service pack campaign.',
      steps: ['Open the **Dashboard**.', 'Under **Service packs**, each pack lists the vehicles it can update and those already on it.'], try: { label: 'Open the Dashboard', run: 'page', args: ['dashboard'] } },

    // ---------------------------------------------------------------- expert tools
    { id: 'sc-repair', area: 'Expert tools', level: 'Expert', minutes: 3, title: 'Repair a computer with new ECU hardware', goal: 'Simulate a hardware swap in the workshop.',
      steps: ['Open the **two-pane workbench** and load `FH 123456` on the left.', 'Tick a node and choose *Replace hardware*.', 'Change the ECU hardware number, then run a Software / Repair request. The previous ECU hardware is sent.'], try: { label: 'Open the two-pane workbench', run: 'twoPane' } },
    { id: 'sc-dependency', area: 'Expert tools', level: 'Expert', minutes: 3, title: 'Resolve a dependency between computers', goal: 'See why one computer needs another to update too.',
      steps: ['In the two-pane workbench, load `FH 123456`.', 'Tick only `16.3.1 TECU` and run Update with scenario *InProgress* and multi-node behaviour off: TECU needs a newer EMS.', 'Turn multi-node behaviour on: EMS is added as a dependent node.'], try: { label: 'Open the two-pane workbench', run: 'twoPane' } },
    { id: 'sc-resolve', area: 'Expert tools', level: 'Expert', minutes: 2, title: 'Recover a missing node template', goal: 'Fix a computer that has no node template.',
      steps: ['Load `FH 000042` (EMS without NTP).', 'Run a Software request with the operation **Resolve**.', 'The result recovers the template.'], try: { label: 'Load FH 000042', run: 'loadVehicle', args: ['FH', '000042'] } },
    { id: 'sc-edb', area: 'Expert tools', level: 'Expert', minutes: 2, title: 'Explore a specification from EDB', goal: 'Break down a specification that has no nodes yet.',
      steps: ['In the two-pane workbench, choose the EDB source and `VSS-12-345`.', 'The request type becomes Production Breakdown.', 'Use *Show source* and *Filter* (for example variant `TELM-DYN`) on the result.'], try: { label: 'Open the two-pane workbench', run: 'twoPane' } },
    { id: 'sc-compare-specs', area: 'Expert tools', level: 'Expert', minutes: 2, title: 'Compare two specifications side by side', goal: 'Find the differences between two products.',
      steps: ['Open **Compare breakdown** in the sidebar.', 'Choose EDB or VDA for each side and identify the products.', 'Choose **Compare** and use *Show differences only*.'], try: { label: 'Open Compare breakdown', run: 'compare' } },

    // ---------------------------------------------------------------- personalise
    { id: 'sc-ist-rupees', area: 'Personalise', level: 'Beginner', minutes: 1, title: 'Show times in IST and money in rupees', goal: 'Use Indian formats everywhere.',
      steps: ['Open **Settings → Language and region**.', 'Pick the India flag.', 'Every date now shows IST, and amounts show as ₹1,23,456.78.'], try: { label: 'Open Language and region', run: 'settings', args: ['region'] } },
    { id: 'sc-two-cultures', area: 'Personalise', level: 'Beginner', minutes: 1, title: 'Switch between two countries live', goal: 'Work with colleagues in another time zone.',
      steps: ['In **Language and region**, pick a country and choose **Keep the current culture**; do the same for the second country.', 'Use the flag button in the top bar, or press `Alt+Shift+C`, to switch at once.'], try: { label: 'Open Language and region', run: 'settings', args: ['region'] } },
    { id: 'sc-keyboard', area: 'Personalise', level: 'Intermediate', minutes: 2, title: 'Work without the mouse', goal: 'Move around and act with the keyboard only.',
      steps: ['Press `Ctrl+K` to find any page, action, vehicle or help article.', 'Press `g` then a letter to go to a page, for example `g` `v` for Vehicle.', 'On the Vehicle page, `1` to `4` switch tabs and `j` `k` move through the history.', 'Press `?` for every shortcut.'], try: { label: 'Show the shortcuts', run: 'shortcuts' } },
  ];

  const C = TR.helpContent;
  C.TOPICS.push({ id: 'scenarios', title: `${SCENARIOS.length} things you can do`, icon: 'route', summary: 'Task-sized scenarios, from your first request to expert tools, each with a Try it button.' });
  for (const s of SCENARIOS) {
    C.ARTICLES.push({
      id: s.id, topic: 'scenarios', title: s.title, summary: s.goal, keywords: `scenario how to ${s.area} ${s.level}`.toLowerCase(), tip: s.tip || `About ${s.minutes} minute${s.minutes === 1 ? '' : 's'}. You can do it!`,
      scenario: { area: s.area, level: s.level, minutes: s.minutes },
      sections: [{ steps: s.steps }, s.try ? { actions: [{ label: s.try.label, icon: 'play', primary: true, run: s.try.run, args: s.try.args || [] }] } : null].filter(Boolean),
    });
  }
  C.SCENARIOS = SCENARIOS;
})();
