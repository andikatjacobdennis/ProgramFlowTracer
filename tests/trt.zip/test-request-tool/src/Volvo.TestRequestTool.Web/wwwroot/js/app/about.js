/* About page: what the application does, its version and runtime, and the contracts it supports. Data: /api/v1/about. */
(function () {
  'use strict';
  const { h } = TR.util;
  const { ui } = TR.pages;
  const state = { info: null, error: null, loading: false };

  async function load() {
    if (state.info || state.loading) return;
    state.loading = true;
    try { state.info = await ui.api('/about'); } catch (e) { state.error = e.message; }
    state.loading = false;
    TR.app.refresh();
  }

  const row = (label, value) => h('div', { class: 'st-row' }, h('div', { class: 'st-text' }, h('div', { class: 'st-title' }, label)), h('div', { class: 'st-control ab-value' }, value));

  function render() {
    load();
    const i = state.info;
    return h('div', { class: 'st-page ab-page' },
      h('div', { class: 'st-head' }, h('h1', null, 'About Test Request Tool')),
      h('section', { class: 'st-card ab-hero' },
        TR.help ? h('div', { class: 'ab-asha' }, TR.help.persona('cheer', 96)) : h('div', { class: 'ab-logo' }, TR.icon('truck', 34)),
        h('div', null, h('h2', null, i ? i.name : 'Test Request Tool'), h('p', null, i ? 'Version ' + i.version : 'Loading…'),
          h('p', { class: 'muted' }, 'Plan software, parameter and variant changes for vehicles, validate them, and deliver the result as a kit, a VDA update or an export. Simulations never install software.'))),
      state.error ? h('div', { class: 's-banner warning' }, TR.icon('alert'), 'Could not load the server details: ' + state.error) : null,
      i ? [
        h('section', { class: 'st-section' }, h('h2', null, 'This installation'),
          h('div', { class: 'st-card' }, row('Version', i.version), row('Runtime', i.runtime), row('Operating system', i.os), row('Environment', i.environment),
            row('Sign-in', i.authentication === 'Password' ? 'User name and password' : i.authentication === 'Jwt' ? 'Organisation sign-in' : i.authentication), row('Storage', i.storage), row('Live services', i.liveServices))),
        h('section', { class: 'st-section' }, h('h2', null, 'Supported contracts'),
          h('div', { class: 'st-card' }, i.contracts.map((c) => row(c.name, c.versions)))),
      ] : null,
      h('section', { class: 'st-section' }, h('h2', null, 'Help'),
        h('div', { class: 'st-card' },
          row('UI guide', h('a', { class: 's-btn secondary', href: TR.testRequest.guideUrl(), target: '_blank', rel: 'noopener' }, 'Open')),
          row('Getting started', ui.button('Open', null, () => TR.pages.show('learn'))),
          row('Settings', ui.button('Open', null, () => TR.pages.show('settings'))))));
  }

  TR.pages.register({ id: 'about', title: 'About', crumbs: () => [{ label: 'Settings', open: () => TR.pages.show('settings') }, { label: 'About' }], render });
  TR.aboutPage = { state };
})();
