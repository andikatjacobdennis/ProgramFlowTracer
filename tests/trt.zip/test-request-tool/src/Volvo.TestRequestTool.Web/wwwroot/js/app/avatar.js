/* The signed-in user's avatar in the top bar (32 × 32) and the account menu (48 × 48).
 *
 *   Photo     /api/v1/me/photo (Microsoft Graph or the account's stored photo, through the server). Fetched after the app has rendered,
 *             never blocking sign-in or the first screen. The request carries no token in its URL; the image becomes a
 *             blob: URL kept in memory for this user only. High-density screens get a larger photo (48 × device pixel ratio,
 *             rounded up to a Graph size), cropped with object-fit: cover.
 *   Fallback  initials from the display name while loading and whenever the photo is missing (204; 404 from older servers), not permitted (403),
 *             unreachable (network or 502) or fails to decode; a neutral person icon when there is no usable name.
 *             The circle has a fixed size in every state, so nothing shifts.
 *   Privacy   a change of account or signing out revokes and forgets every cached photo; the server caches per user only.
 *   Sign out  the app's own sign-in (Password) ends the session through TR.auth.signOut(); organisation sign-in (Jwt)
 *             goes to its sign-out address when the server gives one.
 *   Access    the trigger is a button named "Open account menu for <name>" with aria-haspopup, aria-expanded and
 *             aria-controls; the image is decorative (alt="", aria-hidden) so the name is not announced twice. The menu
 *             works with arrow keys, Home, End, Escape (focus returns to the trigger) and Tab, and always works whether or
 *             not a photo loaded. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));
  const SIZES = [48, 64, 96, 120, 240, 360, 432, 504, 648];
  const session = () => (TR.backend && TR.backend.session) || {};

  // ------------------------------------------------------------------ pure helpers (tested in tests/frontend/avatar.cjs)
  /** Up to two initials: first letters of the first and last name parts, letters only, any script. '' when none. */
  function initials(name) {
    const parts = String(name || '').trim().split(/[\s._-]+/).map((p) => (p.match(/\p{L}/u) || [''])[0]).filter(Boolean);
    if (!parts.length) return '';
    return (parts.length === 1 ? parts[0] : parts[0] + parts[parts.length - 1]).toLocaleUpperCase();
  }
  /** The photo size to ask for: the largest shown size (48 px in the menu) times the pixel ratio, rounded up to a Graph size. */
  const sizeFor = (dpr) => SIZES.find((s) => s >= Math.ceil(48 * Math.max(1, Math.min(4, Number(dpr) || 1)))) || 648;
  /** A short, non-reversible tag of the user id, so a browser cache entry for one account is never used for another. */
  function tag(id) { let x = 2166136261; for (const c of String(id)) { x ^= c.charCodeAt(0); x = Math.imul(x, 16777619); } return (x >>> 0).toString(36); }

  // ------------------------------------------------------------------ state and loading
  const A = { user: null, status: 'idle', url: null, open: false, loads: 0 };
  /** Forget every cached photo (account change or sign-out). */
  function clear() {
    if (A.url && typeof URL !== 'undefined' && URL.revokeObjectURL) URL.revokeObjectURL(A.url);
    A.url = null; A.status = 'idle'; A.user = null;
  }
  async function load() {
    const id = session().userId;
    if (!id) return;
    if (A.user !== id) clear();
    if (A.status !== 'idle') return;
    A.user = id; A.status = 'loading'; A.loads++;
    const px = sizeFor(typeof devicePixelRatio === 'number' ? devicePixelRatio : 1);
    try {
      const r = await fetch(`/api/v1/me/photo?size=${px}&u=${tag(id)}`, { credentials: 'same-origin', headers: { Accept: 'image/*' } });
      if (A.user !== id) return;                       // the account changed while loading: drop the answer
      if (r.status === 204 || r.status === 404) { A.status = 'none'; return refresh(); }
      if (r.status === 401 || r.status === 403) { A.status = 'forbidden'; return refresh(); }
      if (!r.ok) { A.status = 'error'; return refresh(); }
      const blob = await r.blob();
      if (A.user !== id) return;
      A.url = URL.createObjectURL(blob);
      A.status = 'ok';
    } catch (e) { if (A.user === id) A.status = 'error'; }
    refresh();
  }
  const refresh = () => { if (TR.app && TR.app.refresh) TR.app.refresh(); };
  /** After a session change (another account signed in), start again for the new user. */
  function changed() { clear(); setTimeout(load, 0); }

  // ------------------------------------------------------------------ rendering
  /** A fixed-size circle: initials (or a person icon) always underneath, the photo on top once it has loaded. */
  function avatar(size) {
    const name = session().displayName || '';
    const ini = initials(name);
    const el = h('span', { class: ['av', 'av-' + size, A.status === 'ok' ? 'has-photo' : ''], style: { width: size + 'px', height: size + 'px' }, 'aria-hidden': 'true' },
      ini ? h('span', { class: 'av-initials' }, ini) : TR.icon('user', Math.round(size * 0.55)));
    if (A.status === 'ok' && A.url) {
      const img = h('img', { class: 'av-img', src: A.url, alt: '', width: size, height: size, decoding: 'async', draggable: 'false' });
      img.addEventListener('error', () => { A.status = 'error'; if (A.url) URL.revokeObjectURL(A.url); A.url = null; img.remove(); el.classList.remove('has-photo'); });
      el.appendChild(img);
    }
    return el;
  }
  /** Settings, opened at a section (Appearance, Language and region). */
  function settingsAt(section) { TR.pages.show('settings'); setTimeout(() => { const el = document.getElementById('st-' + section); if (el) { el.scrollIntoView({ block: 'start' }); const hd = el.querySelector('h2'); if (hd) { hd.setAttribute('tabindex', '-1'); hd.focus({ preventScroll: true }); } } }, 60); }
  function items() {
    const s = session(), list = [];
    // With the one-row header these live here: language and region, time zone (theme and layout are under Appearance).
    const c = TR.culture && TR.culture.active ? TR.culture.active() : null;
    if (c) {
      list.push(['Language & region', 'globe', () => settingsAt('region'), (TR.culture.countryName ? TR.culture.countryName(c.country) : c.country) + ' · ' + (TR.i18n && TR.i18n.lang && TR.i18n.lang() !== 'en' ? TR.i18n.locale() : c.language)]);
      list.push(['Time zone', 'clock', () => settingsAt('region'), c.timeZone]);
    }
    if (TR.pages && TR.pages.get && TR.pages.get('mydata')) list.push(['What the app knows about me', 'lock', () => TR.pages.show('mydata')]);
    list.push(['Account settings', 'settings', () => TR.pages.show('settings')]);
    if (s.authentication === 'Password' || s.signOutUrl) list.push(['Sign out', 'back', signOut]);
    return list;
  }
  async function signOut() {
    clear();
    try { localStorage.removeItem('trstudio.avatar'); } catch (e) { /* nothing stored */ }
    const s = session();
    if (s.authentication === 'Password' && TR.auth) TR.auth.signOut();
    else if (s.signOutUrl) location.href = s.signOutUrl;
  }
  /** Appearance: theme and navigation layout, chosen right in the profile menu (Settings has the rest). */
  function appearance() {
    const theme = TR.testRequest.theme, layout = TR.navigation ? TR.navigation.prefs().mode : 'menubar';
    const radio = (on, label, run) => h('button', { type: 'button', role: 'menuitemradio', 'aria-checked': String(on), class: ['ap-menu-item', 'av-radio', on ? 'is-on' : ''], tabindex: '-1', onClick: run }, on ? TR.icon('check', 14) : h('span', { class: 'av-sp' }), h('span', null, t(label)));
    return h('div', { class: 'av-group', role: 'group', 'aria-label': t('Appearance') },
      h('p', { class: 'av-group-title' }, TR.icon('sun', 15), t('Appearance'), h('small', null, t('Theme · Layout'))),
      h('div', { class: 'av-radios' }, [['auto', 'Auto'], ['charcoal-light', 'Light'], ['charcoal', 'Dark']].map(([v, l]) => radio(theme === v, l, () => { TR.pages.setTheme(v); }))),
      TR.navigation ? h('div', { class: 'av-radios' }, [['menubar', 'Menu bar'], ['expanded', 'Sidebar']].map(([v, l]) => radio(layout === v || (v === 'expanded' && ['compact', 'hidden'].includes(layout)), l, () => { close(false); TR.navigation.setMode(v); }))) : null,
      h('button', { type: 'button', role: 'menuitem', class: 'ap-menu-item av-item', tabindex: '-1', onClick: () => { close(false); settingsAt('appearance'); } }, TR.icon('sliders', 16), h('span', null, t('More appearance settings'))));
  }
  function menu() {
    const s = session(), name = s.displayName || s.userId || t('Signed in');
    const focusItem = (dir) => {
      const all = [...document.querySelectorAll('#av-menu [role="menuitem"], #av-menu [role="menuitemradio"]')];
      const i = all.indexOf(document.activeElement);
      const next = dir === 'first' ? all[0] : dir === 'last' ? all[all.length - 1] : all[(i + dir + all.length) % all.length];
      if (next) next.focus();
    };
    return h('div', { id: 'av-menu', class: 'ap-menu av-menu', role: 'menu', 'aria-label': t('Account'), onClick: (e) => e.stopPropagation(),
      onKeydown: (e) => {
        if (e.key === 'ArrowDown') { e.preventDefault(); focusItem(1); } else if (e.key === 'ArrowUp') { e.preventDefault(); focusItem(-1); }
        else if (e.key === 'Home') { e.preventDefault(); focusItem('first'); } else if (e.key === 'End') { e.preventDefault(); focusItem('last'); }
        else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(true); } else if (e.key === 'Tab') close(false);
      } },
      h('div', { class: 'av-card' }, avatar(48), h('div', { class: 'av-who' }, h('strong', null, name), h('small', null, [s.role, s.userId].filter(Boolean).join(' · ')))),
      appearance(),
      items().map(([label, icon, run, sub]) => h('button', { type: 'button', role: 'menuitem', class: 'ap-menu-item av-item', tabindex: '-1', onClick: () => { close(false); run(); } }, TR.icon(icon, 16), h('span', null, t(label), sub ? h('small', { class: 'av-sub' }, sub) : null))));
  }
  function open() { TR.pages.closeHeaderMenus?.('account'); A.open = true; refresh(); setTimeout(() => { const first = document.querySelector('#av-menu [role="menuitem"], #av-menu [role="menuitemradio"]'); if (first) first.focus(); }, 0); }
  function close(returnFocus) { if (!A.open) return; A.open = false; refresh(); if (returnFocus) setTimeout(() => { const b = document.querySelector('.av-trigger'); if (b) b.focus(); }, 0); }

  const baseHeader = TR.testRequest.header;
  TR.testRequest.header = () => {
    const header = baseHeader();
    const s = session();
    if (!s.userId || typeof header.querySelector !== 'function') return header;
    if (A.user && A.user !== s.userId) changed();
    // The name chip the header already has is replaced by the avatar.
    const name = s.displayName || s.userId;
    const old = [...header.children].reverse().find((el) => el !== header.firstChild && (el.textContent || '').includes(name));
    if (old) old.remove();
    const trigger = h('button', { type: 'button', class: 'av-trigger', 'aria-haspopup': 'menu', 'aria-expanded': String(A.open), 'aria-controls': 'av-menu',
      'aria-label': t('Open account menu for {name}', { name }), 'data-tip': name + '|' + [s.role, t('Account menu')].filter(Boolean).join(' · '),
      onClick: (e) => { e.stopPropagation(); if (A.open) close(false); else open(); },
      onKeydown: (e) => { if (e.key === 'ArrowDown' && !A.open) { e.preventDefault(); open(); } } }, avatar(32));
    header.appendChild(h('div', { class: 'av-wrap' }, trigger, A.open ? menu() : null));
    if (A.status === 'idle') (typeof requestIdleCallback === 'function' ? requestIdleCallback : setTimeout)(load, { timeout: 1500 });
    return header;
  };
  if (typeof document.addEventListener === 'function') document.addEventListener('click', () => { if (A.open) close(false); });

  TR.avatar = { A, initials, sizeFor, tag, load, clear, changed, signOut, avatar, open, close };
})();
