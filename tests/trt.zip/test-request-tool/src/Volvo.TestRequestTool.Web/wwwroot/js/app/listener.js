/* Listener requests: every message type the request listener (swb-stable1 Request.Listener) handles, in every version.
 *
 *   List      the message types by area (Audit, Aftermarket, Production, Development, Service Configurator, VCADS), one row
 *             per type with its versions; search by title or message type; Simulated or Checked only
 *   Message   the chosen version: what it is for, its message type and version as the listener routes them, the handler in
 *             the listener, and the request and reply contracts (each XSD opens in place)
 *   Request   the body to send: start from the contract (the smallest request its XSD accepts), format, send
 *   Reply     the outcome: notifications with the listener's error codes, a readable summary, the reply as the listener sends
 *             it, and what in the request or the reply does not follow its contract
 * Server: GET /api/v1/listener, GET /listener/schemas/{file}, GET /listener/{type}/{version}/sample,
 * POST /listener/{type}/{version} (ListenerEndpoints.cs). Everything is on the page; nothing opens a dialog. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));
  const AREAS = ['Audit', 'Aftermarket', 'Production', 'Development', 'Service Configurator', 'VCADS'];

  // ------------------------------------------------------------------ pure rules (unit-tested in tests/frontend/listener.cjs)
  const logic = {
    /** Version strings in number order: 1.4 < 1.7 < 2.0 < 2.1 < 10.0. */
    compareVersions(a, b) {
      const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
      for (let i = 0; i < Math.max(x.length, y.length); i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0);
      return 0;
    },
    /** One family per message type, its versions in order, the families by area and title. */
    families(messageTypes) {
      const by = new Map();
      for (const m of messageTypes || []) {
        if (!by.has(m.messageType)) by.set(m.messageType, { messageType: m.messageType, title: m.title, about: m.about, area: m.area, versions: [] });
        by.get(m.messageType).versions.push(m);
      }
      const list = [...by.values()];
      list.forEach((f) => f.versions.sort((a, b) => logic.compareVersions(a.version, b.version)));
      const area = (a) => (AREAS.indexOf(a) < 0 ? AREAS.length : AREAS.indexOf(a));
      return list.sort((a, b) => area(a.area) - area(b.area) || a.title.localeCompare(b.title));
    },
    /** Families matching a search (title, message type, about or a version) and a filter: all, simulated or checked. */
    filter(families, q, show) {
      const words = String(q || '').toLowerCase().split(/\s+/).filter(Boolean);
      return families.filter((f) => {
        if (show === 'simulated' && !f.versions.some((v) => v.simulated)) return false;
        if (show === 'checked' && f.versions.every((v) => v.simulated)) return false;
        const text = [f.title, f.messageType, f.about, f.area].concat(f.versions.map((v) => v.version)).join(' ').toLowerCase();
        return words.every((w) => text.includes(w));
      });
    },
    /** What each side of a message can do here: 'xsd' (checked), 'none' (any body), 'json', 'missing'. */
    side(contract) {
      if (!contract) return 'none';
      if (contract.json) return 'json';
      if (contract.missing || !contract.file) return 'missing';
      return 'xsd';
    },
    /** The outcome in one word, for the status line: rejected, answered, checked or failed. */
    outcome(result) {
      if (!result) return null;
      if ((result.notices || []).some((n) => n.severity === 'Error')) return 'rejected';
      if (result.replyErrors && result.replyErrors.length) return 'failed';
      return result.simulated && result.reply ? 'answered' : 'checked';
    },
    /** Indents XML for reading: one element per line, text kept with its element. Leaves anything that is not XML alone. */
    formatXml(text) {
      const s = String(text || '').trim();
      if (!s.startsWith('<')) return text;
      const tokens = s.replace(/>\s+</g, '><').split(/(<[^>]+>)/).filter((x) => x !== '');
      const out = [];
      let depth = 0;
      for (let i = 0; i < tokens.length; i++) {
        const tok = tokens[i];
        const pad = '  '.repeat(depth);
        if (/^<\?|^<!/.test(tok)) { out.push(pad + tok); continue; }
        if (/^<\//.test(tok)) { depth = Math.max(0, depth - 1); out.push('  '.repeat(depth) + tok); continue; }
        if (/^</.test(tok) && /\/>$/.test(tok)) { out.push(pad + tok); continue; }
        if (/^</.test(tok)) {
          // <a>text</a> stays on one line
          if (tokens[i + 1] && !/^</.test(tokens[i + 1]) && tokens[i + 2] && /^<\//.test(tokens[i + 2])) { out.push(pad + tok + tokens[i + 1] + tokens[i + 2]); i += 2; continue; }
          out.push(pad + tok); depth++; continue;
        }
        out.push(pad + tok.trim());
      }
      return out.join('\n');
    },
  };

  // ------------------------------------------------------------------ state and server calls
  const L = { data: null, error: null, loading: false, q: '', show: 'all', family: null, version: null, bodies: {}, results: {}, busy: null, schemas: {}, openSchema: null, vehicle: null };
  const keyOf = (m) => m.messageType + '_' + m.version;
  async function api(path, options) {
    const r = await fetch('/api/v1/listener' + path, Object.assign({ credentials: 'same-origin' }, options || {}));
    const type = r.headers.get('Content-Type') || '';
    const data = type.includes('json') ? await r.json().catch(() => ({})) : await r.text();
    if (r.status === 429) throw new Error(TR.pages.ui.limited(r, data));
    if (!r.ok) throw new Error((data && (data.detail || data.title)) || r.statusText);
    return data;
  }
  async function load(force) {
    if ((L.data && !force) || L.loading) return;
    L.loading = true;
    try { L.data = await api(''); L.error = null; L.families = logic.families(L.data.messageTypes); if (!L.vehicle && L.data.vehicles && L.data.vehicles.length) L.vehicle = L.data.vehicles[0].id; } catch (e) { L.error = e.message; }
    L.loading = false;
    if (!L.family && L.families && L.families.length) choose(L.families[0].messageType);
    TR.app.refresh();
  }
  const family = () => (L.families || []).find((f) => f.messageType === L.family) || null;
  const current = () => { const f = family(); return f ? f.versions.find((v) => v.version === L.version) || f.versions[f.versions.length - 1] : null; };
  function choose(messageType, version) {
    L.family = messageType;
    const f = family();
    L.version = version || (f ? f.versions[f.versions.length - 1].version : null);
    L.openSchema = null;
    TR.app.refresh();
  }
  async function sample(forVehicle) {
    const m = current(); if (!m) return;
    L.busy = forVehicle ? 'vehicle' : 'sample'; TR.app.refresh();
    const query = forVehicle && L.vehicle ? '?vehicle=' + encodeURIComponent(L.vehicle) : '';
    try { L.bodies[keyOf(m)] = logic.formatXml(await api('/' + encodeURIComponent(m.messageType) + '/' + encodeURIComponent(m.version) + '/sample' + query)); }
    catch (e) { TR.notify && TR.notify.toast(e.message, 'error'); }
    L.busy = null; TR.app.refresh();
  }
  async function send() {
    const m = current(); if (!m) return;
    L.busy = 'send'; TR.app.refresh();
    try {
      L.results[keyOf(m)] = await api('/' + encodeURIComponent(m.messageType) + '/' + encodeURIComponent(m.version), {
        method: 'POST', headers: { 'Content-Type': 'application/xml', Accept: 'application/json' }, body: L.bodies[keyOf(m)] || '',
      });
    } catch (e) { L.results[keyOf(m)] = { error: e.message }; }
    L.busy = null; TR.app.refresh();
    focusSoon('#ls-result');
  }
  async function toggleSchema(file) {
    L.openSchema = L.openSchema === file ? null : file;
    TR.app.refresh();
    if (L.openSchema && !L.schemas[file]) {
      try { L.schemas[file] = await api('/schemas/' + encodeURIComponent(file)); } catch (e) { L.schemas[file] = t('The contract could not be loaded: {e}', { e: e.message }); }
      TR.app.refresh();
    }
  }
  function focusSoon(selector) { setTimeout(() => { const el = document.querySelector(selector); if (el) el.focus(); }, 0); }
  async function copy(text) {
    try { await navigator.clipboard.writeText(text); TR.notify && TR.notify.toast(t('Copied.'), 'success'); } catch (e) { TR.notify && TR.notify.toast(t('The browser did not allow copying.'), 'error'); }
  }

  const canSend = () => { const s = (TR.backend && TR.backend.session) || {}; return s.canSimulate !== false; };

  // ------------------------------------------------------------------ rendering
  const ui = () => TR.pages.ui;
  const SIDE = { xsd: 'Checked against {f}', none: 'No contract: any body', json: 'JSON, no XSD', missing: 'No XSD in SoftwareBreakdown.Contracts: not checked' };
  function list() {
    const shown = logic.filter(L.families || [], L.q, L.show);
    const groups = AREAS.concat(['Other']).map((a) => [a, shown.filter((f) => f.area === a)]).filter(([, l]) => l.length);
    return h('nav', { class: 'ls-list', 'aria-label': t('Message types') },
      h('div', { class: 'ls-tools' },
        h('input', { type: 'search', class: 'ds-input ls-search', placeholder: t('Search message types'), 'aria-label': t('Search message types'), value: L.q, onInput: (e) => { L.q = e.target.value; TR.app.refresh(); } }),
        h('div', { class: 'ls-show', role: 'group', 'aria-label': t('Show') },
          [['all', 'All'], ['simulated', 'Simulated'], ['checked', 'Checked only']].map(([v, l]) => h('button', { type: 'button', class: ['ls-pill', L.show === v ? 'is-on' : ''], 'aria-pressed': String(L.show === v), onClick: () => { L.show = v; TR.app.refresh(); } }, t(l))))),
      groups.length ? null : h('p', { class: 'muted' }, t('No message type matches.')),
      groups.map(([area, items]) => h('section', { class: 'ls-group', 'aria-label': t(area) },
        h('h2', { class: 'ls-area' }, t(area), h('span', { class: 'ls-area-count', 'aria-label': t('{n} message types', { n: items.length }) }, String(items.length))),
        h('ul', null, items.map((f) => {
          const on = f.messageType === L.family, simulated = f.versions.filter((v) => v.simulated).length;
          return h('li', null, h('button', { type: 'button', class: ['ls-item', on ? 'is-on' : ''], 'aria-current': on ? 'true' : null, onClick: () => choose(f.messageType) },
            h('span', { class: 'ls-item-title' }, t(f.title)),
            h('span', { class: 'ls-item-meta' }, h('code', null, f.messageType), ' ', f.versions.map((v) => v.version).join(', ')),
            simulated ? h('span', { class: 's-chip good' }, simulated === f.versions.length ? t('Simulated') : t('{n} of {m} simulated', { n: simulated, m: f.versions.length })) : null));
        })))));
  }
  function contract(label, c) {
    const kind = logic.side(c);
    return h('div', { class: 'ls-contract' },
      h('span', { class: 'ds-label' }, t(label)),
      kind === 'xsd'
        ? h('button', { type: 'button', class: 'ls-link', 'aria-expanded': String(L.openSchema === c.file), onClick: () => toggleSchema(c.file) }, TR.icon('code', 14), c.file)
        : h('span', { class: kind === 'missing' ? 'ls-warn' : 'muted' }, t(SIDE[kind])),
      kind === 'xsd' ? h('small', { class: 'muted ds-code' }, (c.root || '') + ' · ' + c.namespace) : null,
      c && c.note ? h('small', { class: 'ls-note' }, TR.icon('info', 12), t(c.note)) : null);
  }
  function message(m, f) {
    const result = L.results[keyOf(m)], body = L.bodies[keyOf(m)] || '';
    const req = logic.side(m.request);
    return h('div', { class: 'ls-main' },
      h('section', { class: 'ds-card', 'aria-labelledby': 'ls-title' },
        h('header', { class: 'ds-card-head' }, h('h2', { id: 'ls-title' }, t(f.title)), ui().chip(m.simulated ? t('Simulated') : t('Checked only'), m.simulated ? 'good' : 'neutral')),
        h('p', null, t(m.about)),
        f.versions.length > 1 ? h('div', { class: 'ls-versions', role: 'group', 'aria-label': t('Version') },
          h('span', { class: 'ds-label' }, t('Version')),
          f.versions.map((v) => h('button', { type: 'button', class: ['ls-pill', v.version === m.version ? 'is-on' : ''], 'aria-pressed': String(v.version === m.version), onClick: () => choose(f.messageType, v.version) }, v.version))) : null,
        h('dl', { class: 'ls-facts' },
          h('dt', null, t('Routed as')), h('dd', null, h('code', { class: 'ds-code' }, keyOf(m))),
          h('dt', null, t('Listener handler')), h('dd', null, h('code', { class: 'ds-code' }, 'Request.Listener/' + m.handler))),
        m.nameAssumed ? h('p', { class: 'ls-warn' }, TR.icon('info', 14), t('MessageTypes.cs in the contracts does not name this message type; its constant name stands in for it.')) : null,
        h('div', { class: 'ls-contracts' }, contract('Request', m.request), contract('Reply', m.reply), m.errorReply ? contract('Error reply', m.errorReply) : null),
        L.openSchema ? h('pre', { class: 'ls-xml ls-schema', tabindex: '0', 'aria-label': t('Contract {f}', { f: L.openSchema }) }, L.schemas[L.openSchema] || t('Loading…')) : null),
      h('section', { class: 'ds-card', 'aria-labelledby': 'ls-request' },
        h('header', { class: 'ds-card-head' }, h('h2', { id: 'ls-request' }, t('Request'))),
        req === 'json' ? h('p', { class: 'muted' }, t('This service takes JSON. Use New request › {t} to build one from a vehicle.', { t: t(f.title) })) : null,
        req === 'none' ? h('p', { class: 'muted' }, t('{k} takes any body, as in the listener. Leave it empty and send.', { k: keyOf(m) })) : null,
        h('label', { class: 'ds-field' }, h('span', { class: 'ds-label' }, t('Body')),
          h('textarea', { class: 'ls-body', rows: '14', spellcheck: 'false', 'aria-describedby': 'ls-body-hint', value: body, onInput: (e) => { L.bodies[keyOf(m)] = e.target.value; } })),
        m.fromVehicle && L.data.vehicles && L.data.vehicles.length ? h('div', { class: 'ls-vehicle' },
          h('label', { class: 'ds-field' }, h('span', { class: 'ds-label' }, t('Vehicle')),
            h('select', { class: 'ds-input', onChange: (e) => { L.vehicle = e.target.value; } }, L.data.vehicles.map((v) => h('option', { value: v.id, selected: v.id === L.vehicle }, v.series + ' ' + v.number + ' · ' + v.productClass + ' · ' + v.context)))),
          ui().button(L.busy === 'vehicle' ? t('Writing…') : t('Write the request for this vehicle'), 'truck', () => sample(true), 'secondary', { disabled: !!L.busy })) : null,
        h('small', { id: 'ls-body-hint', class: 'muted' }, req === 'xsd' ? (m.fromVehicle ? t('Write the request for a vehicle, or start from the contract for the smallest request its XSD accepts.') : t('Start from the contract for the smallest request its XSD accepts, then fill in what to ask about.')) : ''),
        h('footer', { class: 'ds-actions' },
          ui().button(L.busy === 'send' ? t('Sending…') : t('Send'), 'play', send, 'primary', { disabled: !!L.busy || !canSend(), 'aria-busy': String(L.busy === 'send') }),
          req === 'xsd' ? ui().button(L.busy === 'sample' ? t('Writing…') : t('Start from the contract'), 'file', () => sample(false), 'secondary', { disabled: !!L.busy }) : null,
          ui().button(t('Format'), 'code', () => { L.bodies[keyOf(m)] = logic.formatXml(L.bodies[keyOf(m)] || ''); TR.app.refresh(); }, 'text', { disabled: !body.trim().startsWith('<') })),
        canSend() ? null : h('p', { class: 'muted' }, t('Your role can read the message types and contracts. Sending needs the Engineer, Reviewer or Admin role.'))),
      result ? reply(m, result) : null);
  }
  function reply(m, r) {
    if (r.error) return h('section', { class: 'ds-card', id: 'ls-result', tabindex: '-1', 'aria-labelledby': 'ls-reply' }, h('h2', { id: 'ls-reply' }, t('Reply')), h('div', { class: 's-banner warning', role: 'alert' }, TR.icon('alert'), r.error));
    const outcome = logic.outcome(r);
    const STATUS = {
      answered: ['good', 'check', logic.side(m.reply) === 'xsd' ? 'Answered. The reply follows its contract.' : logic.side(m.reply) === 'missing' ? 'Answered. There is no reply contract to check it against.' : 'Answered.'],
      checked: ['neutral', 'info', 'The request follows its contract. The tool does not simulate this message type yet.'],
      rejected: ['bad', 'alert', 'Rejected: the listener would not process this request.'],
      failed: ['bad', 'alert', 'The reply does not follow its contract.'],
    }[outcome];
    const body = r.reply && r.reply.body ? (r.reply.mediaType === 'application/xml' ? logic.formatXml(r.reply.body) : r.reply.body) : '';
    return h('section', { class: 'ds-card', id: 'ls-result', tabindex: '-1', 'aria-labelledby': 'ls-reply' },
      h('header', { class: 'ds-card-head' }, h('h2', { id: 'ls-reply' }, t('Reply')), h('small', { class: 'muted' }, t('{ms} ms', { ms: Math.round(r.milliseconds) }))),
      h('p', { class: ['ls-status', 'is-' + STATUS[0]], role: 'status' }, TR.icon(STATUS[1], 16), t(STATUS[2])),
      r.notices && r.notices.length ? h('ul', { class: 'ls-notices', 'aria-label': t('Notifications') }, r.notices.map((n) => h('li', { class: 'is-' + n.severity.toLowerCase() },
        n.code ? h('code', { class: 'ls-code', 'data-tip': n.name }, String(n.code)) : null, h('strong', null, t(n.severity)), ' ', n.text))) : null,
      r.reply && r.reply.summary && r.reply.summary.length ? h('dl', { class: 'ls-facts' }, r.reply.summary.map((s) => [h('dt', null, t(s.label)), h('dd', null, s.value)])) : null,
      errors('What in the request does not follow its contract', r.requestErrors),
      errors('What in the reply does not follow its contract', r.replyErrors),
      body ? h('div', { class: 'ls-body-head' }, h('span', { class: 'ds-label' }, t('Reply body ({type})', { type: r.reply.mediaType })), ui().button(t('Copy'), 'copy', () => copy(r.reply.body), 'text')) : null,
      body ? h('pre', { class: 'ls-xml', tabindex: '0', 'aria-label': t('Reply body') }, body) : null);
  }
  function errors(title, list) {
    if (!list || !list.length) return null;
    return h('details', { class: 'ls-errors', open: true }, h('summary', null, t(title), ' (' + list.length + ')'), h('ul', null, list.map((e) => h('li', { class: 'ds-code' }, e))));
  }
  function render() {
    load();
    const f = family(), m = current();
    return h('div', { class: 'st-page ds-page ls-page' },
      h('div', { class: 'st-head' }, h('h1', null, t('Listener requests')),
        h('p', { class: 'muted' }, t('Every message type the request listener handles, in every version. Send one: the request is checked against its contract, answered where the tool simulates it, and the reply is checked against its own.'))),
      L.error ? h('div', { class: 's-banner warning' }, TR.icon('alert'), L.error, ui().button(t('Try again'), 'refresh', () => load(true), 'text')) : null,
      !L.data && !L.error ? h('p', { class: 'muted' }, t('Loading…')) : null,
      L.data ? h('p', { class: 'muted ls-count' }, t('{n} message types and versions, {s} simulated. Source: {src}.', { n: L.data.messageTypes.length, s: L.data.messageTypes.filter((x) => x.simulated).length, src: L.data.source })) : null,
      L.data ? h('div', { class: 'ls-layout' }, list(), m ? message(m, f) : null) : null);
  }

  TR.pages.register({ id: 'listener', title: 'Listener requests', crumbs: () => [{ label: t('Requests') }, { label: t('Listener requests') }], render });
  TR.listener = { logic, L, render, load };
})();
