/* Activity page: every request you ran, as a table with search, a type filter and the shared pager.
 * Rows open the stored result. Data comes from /api/v1/requests (your own requests only). */
(function () {
  'use strict';
  const { h } = TR.util;
  const { ui } = TR.pages;
  const A = { rows: null, error: null, loading: false, query: '', kind: 'all', status: 'all', sort: { by: 'when', dir: 'desc' }, page: Number(new URLSearchParams(location.search).get('page')) || 1 };

  const KIND_LABEL = {
    Software: 'Software', ConversionKit: 'Conversion kit', SpareCab: 'Spare cab', ProductionBreakdown: 'Production breakdown', DevelopmentBreakdown: 'Development breakdown',
    AvailableUpdates: 'Available updates', ProductUpdateService: 'Product Update Service', AvailableProductUpdates: 'Available Product Updates',
  };

  /** Loads all of your requests in pages of 100 (the server limit per call). */
  async function load(force) {
    if (A.loading || (A.rows && !force)) return;
    A.loading = true; A.error = null;
    try {
      const all = [];
      for (let skip = 0; skip < 5000; skip += 100) {
        const batch = await ui.api(`/requests?skip=${skip}&take=100`);
        all.push(...batch);
        if (batch.length < 100) break;
      }
      A.rows = all;
    } catch (e) { A.error = e.message; }
    A.loading = false;
    TR.app.refresh();
  }

  const status = (r) => {
    const outcomes = r.outcomes || [];
    if (!outcomes.length) return ['Result only', 'neutral'];
    if (outcomes.some((o) => (o.issues || []).some((i) => i.severity === 0 || i.severity === 'Error'))) return ['Blocked', 'warning'];
    if (outcomes.some((o) => o.limitedValidation)) return ['Limited validation', 'warning'];
    return ['Ready', 'good'];
  };
  const vehicles = (r) => (r.outcomes || []).map((o) => o.vehicleId.replace('|', ' ')).join(', ') || '—';

  // Status tabs (an idea from Harness), sortable columns and export (from DocGen Explorer's usage table).
  const STATUSES = [['all', 'All', 'grid'], ['Ready', 'Ready', 'check'], ['Limited validation', 'Limited validation', 'alert'], ['Blocked', 'Blocked', 'lock'], ['Result only', 'Result only', 'file']];
  const SORTS = { when: (r) => r.createdAt, type: (r) => KIND_LABEL[r.kind] || r.kind, vehicles: (r) => vehicles(r), result: (r) => status(r)[0] };
  function filtered() {
    const q = A.query.trim().toLowerCase();
    const list = (A.rows || []).filter((r) => (A.kind === 'all' || r.kind === A.kind) && (A.status === 'all' || status(r)[0] === A.status) &&
      (!q || [KIND_LABEL[r.kind] || r.kind, vehicles(r), r.id, status(r)[0]].join(' ').toLowerCase().includes(q)));
    const key = SORTS[A.sort.by] || SORTS.when, dir = A.sort.dir === 'asc' ? 1 : -1;
    return list.sort((a, b) => (key(a) < key(b) ? -1 : key(a) > key(b) ? 1 : 0) * dir);
  }
  function setPage(n) {
    A.page = n;
    const u = new URL(location.href); if (n > 1) u.searchParams.set('page', n); else u.searchParams.delete('page'); history.replaceState(null, '', u);
    TR.app.refresh();
  }
  /** Opens the stored request; focus returns to its row when the dialog closes. */
  function inspect(r) {
    TR.ui.modal({ title: (KIND_LABEL[r.kind] || r.kind) + ' · ' + ui.when(r.createdAt), width: 900, body: () => TR.ui.jsonViewer(r), buttons: [{ label: TR.i18n.t('Close') }],
      onClose: () => setTimeout(() => document.querySelector(`.ac-row[data-id="${r.id}"]`)?.focus(), 0) });
  }
  function exportRows(list, format) {
    const rows = list.map((r) => ({ when: r.createdAt, type: KIND_LABEL[r.kind] || r.kind, vehicles: vehicles(r), result: status(r)[0], id: r.id }));
    if (format === 'json') { TR.util.download('activity.json', JSON.stringify(rows, null, 2)); return; }
    const cell = (v) => `"${String(v).replace(/"/g, '""')}"`;
    TR.util.download('activity.csv', ['When,Type,Vehicles,Result,Id'].concat(rows.map((r) => [r.when, r.type, r.vehicles, r.result, r.id].map(cell).join(','))).join('\r\n'));
    if (TR.notify) TR.notify.toast(TR.i18n.t('Exported {n} requests', { n: rows.length }), 'success');
  }
  function sortHeader(key, label) {
    const on = A.sort.by === key, dir = on ? A.sort.dir : null;
    return h('th', { scope: 'col', 'aria-sort': on ? (dir === 'asc' ? 'ascending' : 'descending') : 'none' },
      h('button', { class: ['ac-sort', on ? 'is-on' : ''], onClick: () => { A.sort = { by: key, dir: on && dir === 'desc' ? 'asc' : 'desc' }; TR.app.refresh(); } }, TR.i18n.t(label), h('span', { 'aria-hidden': 'true' }, on ? (dir === 'asc' ? ' ▲' : ' ▼') : ' ↕')));
  }

  function render() {
    load();
    const t = TR.i18n.t;
    const size = Number(TR.prefs.get('pageSize'));
    const list = filtered();
    const { rows, page } = TR.pager.slice(list, A.page, size);
    const kinds = [...new Set((A.rows || []).map((r) => r.kind))];
    const count = (s) => (A.rows || []).filter((r) => s === 'all' || status(r)[0] === s).length;
    return h('div', { class: 'ac-page' },
      ui.heading(t('Activity'), t('Every request you ran, newest first. Only you can see your requests.'), [
        A.rows && A.rows.length ? ui.button(t('Export CSV'), 'file', () => exportRows(list, 'csv'), 'secondary') : null,
        A.rows && A.rows.length ? ui.button(t('Export JSON'), 'file', () => exportRows(list, 'json'), 'text') : null,
        ui.button(t('Refresh'), 'refresh', () => load(true))]),
      A.rows && A.rows.length ? h('div', { class: 's-tabs vh-tabs ac-tabs', role: 'tablist', 'aria-label': t('Result') }, STATUSES.map(([id, label, icon]) =>
        h('button', { class: ['s-btn', 'tab', A.status === id ? 'active' : ''], role: 'tab', 'aria-selected': String(A.status === id), onClick: () => { A.status = id; setPage(1); } }, TR.icon(icon, 15), t(label), h('span', { class: 'vh-count' }, String(count(id)))))) : null,
      h('div', { class: 'vh-toolbar' },
        h('label', { class: 's-search vh-search ac-search' }, TR.icon('search', 17), h('input', { type: 'search', placeholder: t('Search by vehicle, type or status'), 'aria-label': t('Search activity'), value: A.query, key: 'ac-search',
          onInput: (e) => { A.query = e.target.value; A.page = 1; TR.app.refreshSoon(); }, onKeydown: (e) => { if (e.key === 'Escape') { A.query = ''; TR.app.refresh(); } } })),
        h('label', null, t('Type') + ' ', h('select', { 'aria-label': t('Request type'), value: A.kind, onChange: (e) => { A.kind = e.target.value; setPage(1); } },
          h('option', { value: 'all', selected: A.kind === 'all' }, t('All types')), kinds.map((k) => h('option', { value: k, selected: A.kind === k }, KIND_LABEL[k] || k)))),
        h('span', { class: 'muted', role: 'status' }, A.rows ? (list.length === A.rows.length ? t('{n} requests', { n: A.rows.length }) : t('{n} of {total} match', { n: list.length, total: A.rows.length })) : '')),
      A.error ? h('div', { class: 's-banner warning' }, TR.icon('alert'), t('Could not load your activity: {error}', { error: A.error })) : null,
      !A.rows ? h('p', { class: 'muted' }, t('Loading your activity…'))
        : !A.rows.length ? h('div', { class: 'vh-empty' }, TR.help ? TR.help.guide(t('Nothing here yet. Validate a change and every request you run will show up in this list.'), 'wave', 110, 'is-empty') : TR.icon('clock', 40), h('h2', null, t('No requests yet')), h('p', null, t('Add a vehicle and validate a change. Every request you run appears here.')), ui.button(t('Add a vehicle'), 'plus', () => { TR.experience.page = null; TR.testRequest.intake(); }, 'primary'))
          : h('div', { class: 'ac-table-wrap' },
            h('table', { class: 's-table ac-table' },
              h('thead', null, h('tr', null, sortHeader('when', 'When'), sortHeader('type', 'Type'), sortHeader('vehicles', 'Vehicles'), sortHeader('result', 'Result'), h('th', { scope: 'col' }))),
              h('tbody', null, rows.length ? rows.map((r) => {
                const [label, tone] = status(r);
                return h('tr', { class: 'ac-row', tabindex: '0', 'data-id': r.id, onClick: () => inspect(r), onKeydown: (e) => { if (e.key === 'Enter') inspect(r); } },
                  h('td', null, h('time', { datetime: r.createdAt }, ui.when(r.createdAt))), h('td', null, KIND_LABEL[r.kind] || r.kind), h('td', null, vehicles(r)),
                  h('td', null, ui.chip(t(label), tone)), h('td', { class: 'ac-open' }, ui.button(t('Inspect'), 'search', (e) => { e.stopPropagation(); inspect(r); }, 'text')));
              }) : h('tr', null, h('td', { colspan: '5', class: 'muted' }, t('No requests match.'))))),
            TR.pager({ total: list.length, page, size, label: 'activity', onPage: setPage, onSize: (n) => { TR.prefs.set('pageSize', n); setPage(1); } })));
  }

  TR.pages.register({ id: 'activity', title: 'Activity', crumbs: () => [{ label: 'Activity' }], render });
  TR.pages.ui.slashFocus('.ac-search input');
  // A new request belongs in the list.
  const run = TR.request.runRequest;
  TR.request.runRequest = async (...args) => { const r = await run(...args); A.rows = null; return r; };
  TR.activityPage = { A, filtered, status, load, exportRows };
})();
