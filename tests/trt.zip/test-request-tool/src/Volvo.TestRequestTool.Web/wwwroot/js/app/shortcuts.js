/* Keyboard shortcuts for the whole application, in one registry.
 *
 *   TR.shortcuts.add({ keys: 'g v', label: 'Go to Vehicle', group: 'Go to', run, when })   – register one
 *   TR.shortcuts.show()   – the cheat sheet (also: press ?)
 *   TR.shortcuts.list()   – what is registered, for Settings and Help
 *
 * keys is a space-separated sequence of key tokens such as 'n', '?', 'g v', 'alt+shift+c' or 'alt+arrowright'.
 * Shortcuts never fire while you type in a field or while a dialog is open (Escape still closes dialogs).
 * when() limits a shortcut to the screen it belongs to; without run() the entry is only listed (handled elsewhere). */
(function () {
  'use strict';
  const { h } = TR.util;
  const list = [];
  const SEQUENCE_MS = 1200;
  let pending = null, pendingTimer = null, hint = null;

  function add(s) { list.push(Object.assign({ group: 'General', when: () => true }, s)); }
  /** 'alt+shift+c' for Alt+Shift+C, '?' for a question mark, 'arrowright' for →. */
  function token(e) {
    const parts = [];
    if (e.ctrlKey) parts.push('ctrl');
    if (e.altKey) parts.push('alt');
    if (e.metaKey) parts.push('meta');
    const k = String(e.key || '').toLowerCase();
    if (e.shiftKey && (k.length > 1 || parts.length)) parts.push('shift');
    parts.push(k);
    return parts.join('+');
  }
  const typing = (el) => !!el && (/^(INPUT|TEXTAREA|SELECT)$/.test(el.tagName) || el.isContentEditable);
  const dialogOpen = () => typeof document.querySelector === 'function' && !!document.querySelector('#overlays .overlay');
  /** A when() that fails (for example before the app has rendered) just means the shortcut is not available. */
  const usable = (s) => { try { return !!s.when(); } catch (e) { return false; } };
  const active = () => list.filter((s) => s.run && usable(s));

  function clearPending() { pending = null; clearTimeout(pendingTimer); if (hint) { hint.remove(); hint = null; } }
  /** After the first key of a sequence (for example g), a small hint lists what can follow. */
  function showHint(prefix, options) {
    if (typeof document.body === 'undefined' || !document.body) return;
    hint = h('div', { class: 'ks-hint', role: 'status' }, h('kbd', null, prefix), ' then ',
      options.map((s) => h('span', { class: 'ks-hint-item' }, h('kbd', null, display(s.keys.split(' ')[1])), ' ', s.label.replace(/^Go to /, ''))));
    document.body.appendChild(hint);
  }

  function onKey(e) {
    if (e.defaultPrevented) return;
    const t = token(e);
    const command = /^(ctrl|meta)\+/.test(t);
    if ((typing(e.target) || dialogOpen()) && !command) return;
    if (['shift', 'control', 'alt', 'meta'].includes(t.split('+').pop())) return;
    if (pending) {
      const seq = pending + ' ' + t;
      clearPending();
      const s = active().find((x) => x.keys === seq);
      if (s) { e.preventDefault(); s.run(e); }
      return;
    }
    const single = active().find((x) => x.keys === t);
    if (single) { e.preventDefault(); single.run(e); return; }
    const follow = active().filter((x) => x.keys.startsWith(t + ' '));
    if (follow.length) { e.preventDefault(); pending = t; showHint(t, follow); pendingTimer = setTimeout(clearPending, SEQUENCE_MS); }
  }
  if (typeof document.addEventListener === 'function') document.addEventListener('keydown', onKey);

  // ------------------------------------------------------------------ the cheat sheet
  const NAMES = { arrowright: '→', arrowleft: '←', arrowup: '↑', arrowdown: '↓', escape: 'Esc', enter: 'Enter', alt: 'Alt', shift: 'Shift', ctrl: 'Ctrl', meta: '⌘', f1: 'F1' };
  const display = (k) => k.split('+').map((p) => NAMES[p] || p).join('+');
  function keysView(keys) {
    return h('span', { class: 'ks-keys' }, keys.split(' ').map((step, i) => [i ? h('span', { class: 'ks-then' }, 'then') : null,
      step.split('+').map((p, j) => [j ? '+' : null, h('kbd', null, NAMES[p] || p)])]).flat());
  }
  const GROUPS = ['General', 'Go to', 'Test request', 'Vehicle', 'Lists'];
  function sheet(filter = '') {
    const q = filter.trim().toLowerCase();
    const shown = list.filter((s) => !q || (s.label + ' ' + s.keys + ' ' + s.group).toLowerCase().includes(q));
    return h('div', { class: 'ks-sheet' },
      TR.help && !q ? h('div', { class: 'ks-asha' }, TR.help.persona('wave', 52), h('p', null, 'Press g and then a letter to jump to a page, n for the next step and / to search. Shortcuts pause while you type.')) : null,
      h('label', { class: 's-search ks-filter' }, TR.icon('search', 16), h('input', { type: 'search', placeholder: 'Find a shortcut', 'aria-label': 'Find a shortcut', value: filter, key: 'ks-filter',
        onInput: (e) => { state.filter = e.target.value; state.modal && state.modal.render(); } })),
      h('div', { class: 'ks-groups' }, GROUPS.concat([...new Set(list.map((s) => s.group))].filter((g) => !GROUPS.includes(g))).map((g) => {
        const rows = shown.filter((s) => s.group === g);
        return rows.length ? h('section', { class: 'ks-group' }, h('h3', null, g), h('dl', null, rows.map((s) => [h('dt', null, s.label, s.run && !usable(s) ? h('small', null, ' · not on this screen') : null), h('dd', null, keysView(s.keys))]).flat())) : null;
      })),
      shown.length ? null : h('p', { class: 'muted' }, 'No shortcut matches.'),
      h('p', { class: 'ks-foot' }, 'Shortcuts are off while you type in a field. Press ', h('kbd', null, '?'), ' any time to see this list.'));
  }
  const state = { filter: '', modal: null };
  function show() {
    if (state.modal && !state.modal.closed) return;
    state.filter = '';
    state.modal = TR.ui.modal({ title: 'Keyboard shortcuts', width: 820, class: 'ks-dialog', body: () => sheet(state.filter), buttons: [{ label: 'Close', primary: true }] });
  }

  // ------------------------------------------------------------------ the shortcuts
  const X = TR.experience, S = TR.testRequest;
  const page = () => (TR.pages ? TR.pages.current() : X.page);
  const onTestRequest = () => !X.page && TR.app.page === 'testrequest';
  const goto = (id) => () => TR.pages.show(id);
  add({ keys: '?', label: 'Show keyboard shortcuts', run: show });
  add({ keys: '/', label: 'Search on this page (Settings, Help, Activity, Vehicle)' });
  add({ keys: 'escape', label: 'Close a dialog or clear a search' });
  add({ keys: 'n', label: 'Do the next step (the coloured Next button)', run: () => TR.nextStep().run() });
  add({ keys: '+', label: 'Add a vehicle', run: () => { X.page = null; S.intake(); } });
  add({ keys: 't', label: 'Switch theme (Auto, Light, Dark)', run: () => TR.pages.cycleTheme() });
  add({ keys: 'm', label: 'Turn motion on or off', run: () => TR.prefs.set('motion', TR.prefs.get('motion') === 'off' ? 'on' : 'off') });
  add({ keys: 'alt+shift+c', label: 'Switch to the next culture' });
  add({ keys: 'f1', label: 'Open Help', run: goto('help') });

  add({ keys: 'g h', group: 'Go to', label: 'Go to Home', run: goto('home') });
  add({ keys: 'g t', group: 'Go to', label: 'Go to Test request', run: () => S.page() });
  add({ keys: 'g d', group: 'Go to', label: 'Go to Dashboard', run: goto('dashboard') });
  add({ keys: 'g v', group: 'Go to', label: 'Go to Vehicle', run: goto('vehicle') });
  add({ keys: 'g a', group: 'Go to', label: 'Go to Activity', run: goto('activity') });
  add({ keys: 'g s', group: 'Go to', label: 'Go to Settings', run: goto('settings') });
  add({ keys: 'g ?', group: 'Go to', label: 'Go to Help', run: goto('help') });
  add({ keys: 'g b', group: 'Go to', label: 'Go to Saved vehicles', run: goto('library') });

  // An expert tool: only with expert tools on (or to leave the two-pane view).
  const twoPaneAllowed = () => S.view === 'expert' || !TR.navigation || TR.navigation.logic.expertOn(TR.prefs.get('expertTools'), ((TR.backend && TR.backend.session) || {}).role);
  add({ keys: 'w', group: 'Test request', label: 'Switch between Focused and Two-pane', when: () => onTestRequest() && twoPaneAllowed(), run: () => { if (S.view === 'expert') { S.view = 'focused'; TR.app.shell.fullScreen = null; TR.app.navigate('testrequest'); } else S.expert(); } });
  add({ keys: '1', group: 'Test request', label: 'Make changes', when: () => onTestRequest() && S.view !== 'expert', run: () => { S.stage = 'configure'; TR.app.refresh(); } });
  add({ keys: '2', group: 'Test request', label: 'Check', when: () => onTestRequest() && S.view !== 'expert', run: () => { S.stage = 'validate'; TR.app.refresh(); } });
  add({ keys: '3', group: 'Test request', label: 'Get approval', when: () => onTestRequest() && S.view !== 'expert', run: () => { S.stage = 'review'; TR.app.refresh(); } });

  const onVehicle = () => page() === 'vehicle' && TR.vehiclePage && TR.app.shell.left && TR.app.shell.left.product.loaded();
  const TABS = ['graph', 'map', 'roadmap', 'history', 'insights'];   // the Vehicle page's tab order
  const tab = (id) => () => { TR.vehiclePage.V.tab = id; TR.app.refresh(); };
  const step = (d) => () => { const V = TR.vehiclePage.V, i = TABS.indexOf(V.tab); V.tab = TABS[(i + d + TABS.length) % TABS.length]; TR.app.refresh(); };
  add({ keys: '1', group: 'Vehicle', label: 'Graph', when: onVehicle, run: tab('graph') });
  // Number keys follow the tab order: 1 Graph, 2 Map, 3 Roadmap, 4 History, 5 Insights.
  TABS.slice(1).forEach((id, i) => add({ keys: String(i + 2), group: 'Vehicle', label: id.charAt(0).toUpperCase() + id.slice(1), when: onVehicle, run: tab(id) }));
  add({ keys: ']', group: 'Vehicle', label: 'Next tab', when: onVehicle, run: step(1) });
  add({ keys: '[', group: 'Vehicle', label: 'Previous tab', when: onVehicle, run: step(-1) });
  const inHistory = () => onVehicle() && TR.vehiclePage.V.tab === 'history';
  /** Moves the keyboard focus to the next or previous history entry. */
  function moveEntry(d) {
    const rows = [...document.querySelectorAll('.gh-row[data-entry]')];
    if (!rows.length) return;
    const i = rows.indexOf(document.activeElement && document.activeElement.closest && document.activeElement.closest('.gh-row'));
    const next = rows[Math.min(rows.length - 1, Math.max(0, i < 0 ? 0 : i + d))];
    next.focus(); next.scrollIntoView({ block: 'nearest', behavior: TR.pages.ui.motionOn() ? 'smooth' : 'auto' });
  }
  add({ keys: 'j', group: 'Vehicle', label: 'Next history entry', when: inHistory, run: () => moveEntry(1) });
  add({ keys: 'k', group: 'Vehicle', label: 'Previous history entry', when: inHistory, run: () => moveEntry(-1) });
  add({ keys: 'o', group: 'Vehicle', label: 'Show or hide the changes of the focused entry', when: inHistory, run: () => { const row = document.activeElement && document.activeElement.closest && document.activeElement.closest('.gh-row'); const t = row && row.querySelector('.gh-toggle'); if (t) { const id = row.dataset.entry; t.click(); setTimeout(() => document.querySelector(`.gh-row[data-entry="${id}"]`)?.focus(), 0); } } });

  const $ = (sel) => (typeof document.querySelector === 'function' ? document.querySelector(sel) : null);
  const pagerButton = (label) => () => { const b = $(`.ap-pages button[aria-label="${label}"]:not([disabled])`); if (b) b.click(); };
  add({ keys: 'alt+arrowright', group: 'Lists', label: 'Next page of a list', when: () => !!$('.ap-pages'), run: pagerButton('Next page') });
  add({ keys: 'alt+arrowleft', group: 'Lists', label: 'Previous page of a list', when: () => !!$('.ap-pages'), run: pagerButton('Previous page') });

  TR.shortcuts = { add, show, list: () => list.slice(), token, keysView, onKey };
})();
