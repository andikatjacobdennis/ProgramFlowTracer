/* Small, explainable machine-learning helpers that run in the browser. No AI service and no network: every model is a
 * few lines of classic statistics, trained on data that is already on the page or kept in this browser.
 *
 *   tfidf(docs)            – a search index: TF-IDF weights and cosine similarity (Help search)
 *   fuzzy(query, text)     – subsequence score for "type a few letters" matching (command palette)
 *   similar(a, b)          – trigram similarity, and suggest(word, vocabulary) for "Did you mean …?"
 *   frecency(key)          – how often and how recently you used something, with a 7-day half-life (palette ranking)
 *   markov(key)            – first-order Markov chain of what you do next (palette "Next for you")
 *   zscores(values)        – how unusual each value is (dashboard outliers)
 *   linear(points)         – least-squares line and a forecast (dashboard trend)
 *   kmeans(rows, k)        – k-means clustering with a fixed, sorted start so results never jump (dashboard groups)
 *
 * Learned data (frecency, markov) is stored per user in this browser only and can be cleared in Settings → Privacy. */
(function () {
  'use strict';
  const STOP = new Set('a an and are as at be by do for from how i in is it of on or the to what when where which with you your my me can'.split(' '));
  const tokens = (text) => String(text || '').toLowerCase().normalize('NFKD').replace(/[̀-ͯ]/g, '').split(/[^a-z0-9åäö]+/).filter((w) => w && !STOP.has(w));
  /** Very light stemming so "kits", "kit" and "validated", "validate" meet. */
  const stem = (w) => (w.length > 4 ? w.replace(/(ing|ed|es|s)$/, '') : w);

  // ------------------------------------------------------------------ TF-IDF search
  /** docs: [{ id, text, boost? }]. Returns { search(query) → [{ id, score }], vocabulary }. */
  function tfidf(docs) {
    const df = new Map(), vectors = [];
    for (const d of docs) {
      const tf = new Map();
      for (const w of tokens(d.text).map(stem)) tf.set(w, (tf.get(w) || 0) + 1);
      for (const w of tf.keys()) df.set(w, (df.get(w) || 0) + 1);
      vectors.push({ id: d.id, tf, boost: d.boost || {} });
    }
    const N = docs.length, idf = (w) => Math.log(1 + N / (df.get(w) || 0.5));
    for (const v of vectors) {
      v.w = new Map(); let norm = 0;
      for (const [w, n] of v.tf) { const x = (1 + Math.log(n)) * idf(w); v.w.set(w, x); norm += x * x; }
      v.norm = Math.sqrt(norm) || 1;
    }
    const vocabulary = [...df.keys()];
    function search(query) {
      const q = tokens(query).map(stem);
      if (!q.length) return [];
      const qw = new Map(); for (const w of q) qw.set(w, (qw.get(w) || 0) + idf(w));
      const qn = Math.sqrt([...qw.values()].reduce((s, x) => s + x * x, 0)) || 1;
      return vectors.map((v) => {
        let dot = 0;
        for (const [w, x] of qw) dot += x * (v.w.get(w) || 0) * (v.boost[w] || 1);
        return { id: v.id, score: dot / (qn * v.norm) };
      }).filter((r) => r.score > 0).sort((a, b) => b.score - a.score);
    }
    return { search, vocabulary };
  }

  // ------------------------------------------------------------------ fuzzy and similarity
  /** 0 when the letters of query do not appear in order in text; higher for early, consecutive and word-start matches. */
  function fuzzy(query, text) {
    const q = String(query).toLowerCase().replace(/\s+/g, ''), s = String(text).toLowerCase();
    if (!q) return 1;
    let score = 0, at = -1, run = 0;
    for (const ch of q) {
      const i = s.indexOf(ch, at + 1);
      if (i < 0) return 0;
      run = i === at + 1 ? run + 1 : 0;
      score += 1 + run * 2 + (i === 0 || /[\s\-_/›]/.test(s[i - 1]) ? 3 : 0) - Math.min(i - at - 1, 5) * 0.2;
      at = i;
    }
    return score / (q.length * 6) + (s.startsWith(q) ? 0.5 : 0) + (s.includes(q) ? 0.3 : 0);
  }
  const grams = (w) => { const s = `  ${w} `; const g = new Set(); for (let i = 0; i < s.length - 2; i++) g.add(s.slice(i, i + 3)); return g; };
  /** Trigram (Jaccard) similarity between two words, 0 to 1. */
  function similar(a, b) { const A = grams(a), B = grams(b); let n = 0; for (const g of A) if (B.has(g)) n++; return n / (A.size + B.size - n || 1); }
  /** The closest known word, or null when nothing is close enough (for "Did you mean …?"). */
  function suggest(word, vocabulary, min = 0.42) {
    let best = null, score = min;
    for (const v of vocabulary) { if (v === word || Math.abs(v.length - word.length) > 3) continue; const s = similar(word, v); if (s > score) { score = s; best = v; } }
    return best;
  }

  // ------------------------------------------------------------------ learning from use (this browser only)
  const store = TR.util.store;
  const userKey = (name) => 'trstudio.' + ((TR.backend && TR.backend.session && TR.backend.session.userId) || 'user') + '.ml.' + name;
  const HALF_LIFE = 7 * 86400000;
  /** Frequency × recency with exponential decay: a use today counts 1, a use a week ago 0.5. */
  function frecency(name) {
    const key = () => userKey('frecency.' + name);
    const read = () => store.get(key(), {}) || {};
    return {
      use(id, now = Date.now()) { if (TR.prefs && TR.prefs.get('learning') === false) return; const all = read(); const e = all[id] || { s: 0, t: now }; e.s = e.s * Math.pow(0.5, (now - e.t) / HALF_LIFE) + 1; e.t = now; all[id] = e; store.set(key(), all); },
      score(id, now = Date.now()) { const e = read()[id]; return e ? e.s * Math.pow(0.5, (now - e.t) / HALF_LIFE) : 0; },
      top(n = 5, now = Date.now()) { const all = read(); return Object.keys(all).map((id) => [id, this.score(id, now)]).sort((a, b) => b[1] - a[1]).slice(0, n).map(([id]) => id); },
      clear() { store.set(key(), {}); },
    };
  }
  /** Counts of "after A came B", smoothed so a new habit can still win. predict(A) gives the likeliest next steps. */
  function markov(name) {
    const key = () => userKey('markov.' + name);
    const read = () => store.get(key(), {}) || {};
    return {
      step(from, to) { if (TR.prefs && TR.prefs.get('learning') === false) return; if (!from || !to || from === to) return; const all = read(); const row = all[from] || (all[from] = {}); row[to] = (row[to] || 0) + 1; store.set(key(), all); },
      predict(from, n = 3, alpha = 0.5) {
        const row = read()[from] || {}, total = Object.values(row).reduce((s, x) => s + x, 0), k = Object.keys(row).length || 1;
        return Object.entries(row).map(([to, c]) => ({ id: to, p: (c + alpha) / (total + alpha * k) })).sort((a, b) => b.p - a.p).slice(0, n);
      },
      clear() { store.set(key(), {}); },
    };
  }
  function clearLearning() { for (const k of Object.keys((typeof localStorage !== 'undefined' && localStorage) || {})) if (k.startsWith(userKey(''))) store.set(k, {}); }

  // ------------------------------------------------------------------ statistics
  function zscores(values) {
    const n = values.length || 1, mean = values.reduce((s, x) => s + x, 0) / n;
    const sd = Math.sqrt(values.reduce((s, x) => s + (x - mean) ** 2, 0) / n) || 1;
    return values.map((x) => (x - mean) / sd);
  }
  /** Least squares through [x, y] points: { slope, intercept, at(x), r2 }. */
  function linear(points) {
    const n = points.length;
    if (n < 2) return { slope: 0, intercept: n ? points[0][1] : 0, at: () => (n ? points[0][1] : 0), r2: 0 };
    const mx = points.reduce((s, p) => s + p[0], 0) / n, my = points.reduce((s, p) => s + p[1], 0) / n;
    let sxy = 0, sxx = 0, syy = 0;
    for (const [x, y] of points) { sxy += (x - mx) * (y - my); sxx += (x - mx) ** 2; syy += (y - my) ** 2; }
    const slope = sxx ? sxy / sxx : 0, intercept = my - slope * mx;
    return { slope, intercept, at: (x) => intercept + slope * x, r2: sxx && syy ? (sxy * sxy) / (sxx * syy) : 0 };
  }
  /** k-means on numeric rows (already scaled). Starts from rows spread evenly after sorting by the first feature, so the same
   *  data always gives the same groups. Returns { labels, centroids }. */
  function kmeans(rows, k = 3, iterations = 25) {
    if (!rows.length) return { labels: [], centroids: [] };
    k = Math.min(k, rows.length);
    const order = rows.map((r, i) => i).sort((a, b) => rows[a][0] - rows[b][0]);
    let centroids = Array.from({ length: k }, (_, j) => rows[order[Math.floor((j + 0.5) * rows.length / k)]].slice());
    let labels = new Array(rows.length).fill(0);
    const dist = (a, b) => a.reduce((s, x, i) => s + (x - b[i]) ** 2, 0);
    for (let it = 0; it < iterations; it++) {
      const next = rows.map((r) => { let best = 0; for (let j = 1; j < k; j++) if (dist(r, centroids[j]) < dist(r, centroids[best])) best = j; return best; });
      const moved = next.some((l, i) => l !== labels[i]);
      labels = next;
      centroids = centroids.map((c, j) => { const members = rows.filter((_, i) => labels[i] === j); return members.length ? c.map((_, d) => members.reduce((s, m) => s + m[d], 0) / members.length) : c; });
      if (!moved && it) break;
    }
    return { labels, centroids };
  }
  /** Scales each column to 0..1 so no feature dominates the distance. */
  function scale(rows) {
    if (!rows.length) return rows;
    const min = rows[0].map((_, d) => Math.min(...rows.map((r) => r[d]))), max = rows[0].map((_, d) => Math.max(...rows.map((r) => r[d])));
    return rows.map((r) => r.map((x, d) => (max[d] === min[d] ? 0 : (x - min[d]) / (max[d] - min[d]))));
  }

  TR.ml = { tokens, stem, tfidf, fuzzy, similar, suggest, frecency, markov, clearLearning, zscores, linear, kmeans, scale };
})();
