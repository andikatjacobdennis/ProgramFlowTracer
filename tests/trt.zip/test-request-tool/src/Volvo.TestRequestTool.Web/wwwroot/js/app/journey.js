/* Shared pieces of the request journey pages (Requests, Request execution, Change impact, Fleet readiness, Review,
 * Submit, Outcome, Engineering insights): JSON calls, page parameters in the address (?view=…&rid=…&vid=…), status chips
 * with icon and text (colour never carries meaning alone), stat cards, the five-step stepper, cards, copy and download.
 * Every page reads real records from the server; where something is not measured or not recorded it says so.
 *
 * TR.journey.STATE is the one table of states: label, icon and tone for every status the server returns. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));

  // ------------------------------------------------------------------ states
  const STATE = {
    pass: ['Pass', 'check', 'good'], passed: ['Passed', 'check', 'good'], ready: ['Ready', 'check', 'good'], approved: ['Approved', 'check', 'good'], submitted: ['Submitted', 'check', 'good'],
    completed: ['Completed', 'check', 'good'], verified: ['Verified', 'check', 'good'], unchanged: ['Unchanged', 'check', 'good'], validated: ['Validated', 'check', 'info'],
    blocked: ['Blocked', 'alert', 'warning'], warning: ['Warning', 'alert', 'warning'], warnings: ['Completed with warnings', 'alert', 'warning'], notes: ['Passed with notes', 'info', 'warning'], limited: ['Limited evidence', 'alert', 'warning'],
    check: ['Check required', 'alert', 'warning'], pending: ['Pending', 'clock', 'warning'], 'awaiting-review': ['Awaiting review', 'clock', 'warning'], open: ['Awaiting review', 'clock', 'warning'],
    changes: ['Changes requested', 'pencil', 'warning'], 'changes-requested': ['Changes requested', 'pencil', 'warning'], changes_requested: ['Changes requested', 'pencil', 'warning'],
    unknown: ['Unknown', 'help', 'neutral'], 'not-ready': ['Not ready', 'help', 'neutral'], 'not-requested': ['Not requested', 'help', 'neutral'], 'not-verified': ['Not yet verified', 'help', 'neutral'],
    draft: ['Draft', 'file', 'neutral'], withdrawn: ['Withdrawn', 'close', 'neutral'],
    stale: ['Stale', 'clock', 'stale'], expired: ['Expired', 'clock', 'stale'], 'needs-revalidation': ['Needs revalidation', 'refresh', 'stale'],
    running: ['Running', 'play', 'info'], queued: ['Queued', 'clock', 'info'], changed: ['Changed', 'pencil', 'info'], added: ['Added', 'plus', 'info'], modified: ['Modified', 'pencil', 'info'],
    removed: ['Removed', 'trash', 'danger'], missing: ['Not on vehicle', 'alert', 'danger'], failed: ['Failed', 'alert', 'danger'],
  };
  const state = (s) => STATE[s] || [String(s || 'Unknown'), 'help', 'neutral'];
  /** A status chip: icon and words in the state's tone. */
  function chip(s, label, extra) {
    const [l, icon, tone] = state(s);
    return h('span', Object.assign({ class: 'jr-chip tone-' + tone, 'data-state': s }, extra || {}), TR.icon(icon, 13), h('span', null, label || t(l)));
  }

  // ------------------------------------------------------------------ calls
  const NOT_FOUND = 'This item was not found. The link may be out of date, or the item was removed.';
  const NO_ACCESS = 'You do not have access to this item.';
  async function api(path, opts) {
    const o = opts || {};
    const r = await fetch('/api/v1' + path, { method: o.method || 'GET', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: o.body ? JSON.stringify(o.body) : undefined });
    const data = await r.json().catch(() => ({}));
    if (r.status === 429) { const e = new Error(TR.pages.ui.limited ? TR.pages.ui.limited(r, data) : t('Too many requests right now. Try again shortly.')); e.status = 429; e.code = 'rate_limited'; e.retryAfter = Number(r.headers.get('Retry-After')) || data.retryAfterSeconds || null; throw e; }
    if (!r.ok) {
      // Codes such as not_found are for programs: people get a sentence (and no Retry where retrying cannot help, see failed()).
      const human = r.status === 404 ? t(NOT_FOUND) : r.status === 403 ? t(NO_ACCESS) : null;
      const e = new Error(data.detail || human || data.title || r.statusText || t('Server request failed')); e.status = r.status; e.code = data.title; throw e;
    }
    return data;
  }

  // ------------------------------------------------------------------ page parameters (kept in the address so links and reloads work)
  const P = { rid: null, vid: null, page: null };
  // The parameters live here; the address mirrors them for links and reloads. Other modules rewrite the address too, so an
  // address without them never clears what open() set.
  // They belong to the page they were opened for: rid is a review on Review, Submit and Outcome but a request on Change
  // impact, Execution and Logs. A page reads them with param(), so it never takes another page's id (Change impact opened
  // after a review sent the review's id as a request id: "Request was not found").
  function readParams() { try { const q = new URLSearchParams(location.search); if (q.has('rid') || q.has('vid')) { P.rid = q.get('rid'); P.vid = q.get('vid'); P.page = q.get('view'); } } catch (e) { /* no location */ } }
  /** A parameter of this page, or null when the parameters were opened for another page. */
  const param = (name, page) => (P.page === page ? P[name] || null : null);
  function writeParams() {
    try { const u = new URL(location.href); if (P.page) u.searchParams.set('view', P.page); ['rid', 'vid'].forEach((k) => { if (P[k]) u.searchParams.set(k, P[k]); else u.searchParams.delete(k); }); history.replaceState(null, '', u); } catch (e) { /* none */ }
  }
  readParams();
  // Any other way to a different page (the Ctrl+K palette, Help links, older menus) drops the previous page's parameters
  // from memory and from the address, so a reload cannot hand them to the new page either.
  if (TR.pages && typeof TR.pages.show === 'function') {
    const show = TR.pages.show;
    TR.pages.show = (id) => {
      if (id !== P.page) { P.rid = null; P.vid = null; P.page = id; writeParams(); }   // now: pages re-read the address as they render
      return show(id);
    };
  }
  /** Opens a journey page with its parameters. */
  function open(page, params) {
    P.rid = (params && params.rid) || null; P.vid = (params && params.vid) || null; P.page = page;
    if (TR.experience) TR.experience.page = null;
    // Publish the destination and its parameters before synchronous rendering reads the address.
    writeParams(); TR.pages.show(page);
    // After the new page has rendered, start at its top.
    if (typeof scrollTo === 'function') setTimeout(() => { try { scrollTo(0, 0); const m = document.querySelector('.s-main, main'); if (m && m.scrollTo) m.scrollTo(0, 0); } catch (e) { /* none */ } }, 0);
  }

  // ------------------------------------------------------------------ formatting
  const label = (id) => (id ? 'REQ-' + String(id).replace(/-/g, '').slice(0, 6).toUpperCase() : '');
  const vehicleText = (v) => (v ? (v.title || String(v.id || '').replace('|', ' ')) + (v.architecture ? ' · ' + v.architecture : '') : '');
  /** Seconds with sensible precision: 0.42 s, 8.4 s, 42 s; milliseconds below 0.1 s. */
  function secs(ms) {
    if (ms == null || isNaN(ms)) return '—';
    if (ms < 100) return (Math.round(ms * 10) / 10) + ' ms';
    const s = ms / 1000;
    return (s < 10 ? Math.round(s * 100) / 100 : s < 100 ? Math.round(s * 10) / 10 : Math.round(s)) + ' s';
  }
  /** "just now", "2 min ago", "3 h ago", then the date. */
  function ago(at) {
    const d = (Date.now() - new Date(at).getTime()) / 1000;
    if (!isFinite(d)) return '';
    if (d < 45) return t('just now');
    if (d < 3600) return t('{n} min ago', { n: Math.max(1, Math.round(d / 60)) });
    if (d < 86400) return t('{n} h ago', { n: Math.round(d / 3600) });
    return TR.pages.ui.day(at);
  }
  function time(at) {
    const p = TR.culture ? TR.culture.active() : {};
    try { return new Intl.DateTimeFormat(p.language, { timeZone: p.timeZone, hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).format(new Date(at)); } catch (e) { return String(at).slice(11, 19); }
  }
  const initials = (name) => String(name || '?').split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('');

  // ------------------------------------------------------------------ building blocks
  function pageHead(title, subtitle, actions) {
    return h('div', { class: 'jr-head' }, h('div', null, h('h1', null, t(title)), subtitle ? h('p', { class: 'jr-sub' }, t(subtitle)) : null), actions ? h('div', { class: 'jr-actions' }, actions) : null);
  }
  /** Stat cards: [{ n, label, icon, tone, onClick, sub }]. A count of zero is shown neutral: colour is kept for something to look at. */
  function stats(list) {
    return h('div', { class: 'jr-stats' }, list.filter(Boolean).map((s) => h(s.onClick ? 'button' : 'div', { class: ['jr-stat', 'tone-' + (s.n === 0 || s.n === '0' ? 'neutral' : s.tone || 'neutral'), s.n === 0 || s.n === '0' ? 'is-zero' : '', s.on ? 'is-on' : ''], onClick: s.onClick || null, type: s.onClick ? 'button' : null, 'aria-pressed': s.onClick ? String(!!s.on) : null },
      s.icon ? h('span', { class: 'jr-stat-icon', 'aria-hidden': 'true' }, TR.icon(s.icon, 22)) : null,
      h('span', { class: 'jr-stat-text' }, h('strong', null, s.n == null ? '—' : String(s.n)), h('span', null, t(s.label)), s.sub ? h('small', { class: 'muted' }, s.sub) : null),
      s.onClick ? h('span', { class: 'jr-stat-go', 'aria-hidden': 'true' }, TR.icon('chevron', 16)) : null)));
  }
  function card(title, tools, ...body) {
    return h('section', { class: 'jr-card', 'aria-label': typeof title === 'string' ? t(title) : null },
      title || tools ? h('header', { class: 'jr-card-head' }, title ? (typeof title === 'string' ? h('h2', null, t(title)) : title) : null, tools ? h('div', { class: 'jr-card-tools' }, tools) : null) : null, ...body);
  }
  const STEPS = ['Choose vehicle', 'Make changes', 'Check', 'Get approval', 'Send'];
  /** The five-step journey with the current step (0–4); steps before it are done. */
  function stepper(current) {
    return h('ol', { class: 'jr-steps', 'aria-label': t('Progress') }, STEPS.map((s, i) => h('li', { class: i < current ? 'is-done' : i === current ? 'is-current' : '', 'aria-current': i === current ? 'step' : null },
      h('span', { class: 'jr-step-dot', 'aria-hidden': 'true' }, i < current ? TR.icon('check', 14) : String(i + 1)), h('span', null, t(s)), h('span', { class: 'nv-sr' }, i < current ? t(' (done)') : i === current ? t(' (current)') : ''))));
  }
  const banner = (tone, icon, ...text) => h('div', { class: 'jr-banner tone-' + tone, role: tone === 'warning' || tone === 'danger' ? 'status' : null }, TR.icon(icon, 16), h('span', null, ...text));
  const facts = (rows) => h('dl', { class: 'jr-facts' }, rows.filter(Boolean).map(([k, v]) => [h('dt', null, t(k)), h('dd', null, v == null || v === '' ? '—' : v)]));
  const loading = (n) => h('div', { class: 'jr-loading', role: 'status', 'aria-label': t('Loading') }, Array.from({ length: n || 4 }, () => h('div', { class: 'ap-skeleton' })));
  /**
   * A failed load. Retrying helps with a slow or busy server, not with a missing item or missing access: those offer the way
   * back to Requests instead, so nobody is left on a page whose only button cannot work.
   */
  const failed = (msg, retry) => {
    const text = String(msg && msg.message || msg || '');
    const permanent = text === t(NOT_FOUND) || text === t(NO_ACCESS) || /^(not_found|forbidden)$/.test(text);
    return h('div', { class: 'jr-banner tone-danger', role: 'alert' }, TR.icon('alert', 16),
      h('span', null, text === 'not_found' ? t(NOT_FOUND) : text === 'forbidden' ? t(NO_ACCESS) : text),
      permanent ? TR.pages.ui.button(t('Go to Requests'), 'arrow', () => open('requests'), 'text')
        : retry ? TR.pages.ui.button(t('Try again'), 'refresh', retry, 'text') : null);
  };
  const empty = (title, text, action) => h('div', { class: 'jr-empty' }, h('h3', null, t(title)), text ? h('p', { class: 'muted' }, t(text)) : null, action || null);

  async function copy(text, what) {
    try { await navigator.clipboard.writeText(text); TR.notify && TR.notify.toast(t('{w} copied.', { w: t(what) }), 'success'); TR.announce && TR.announce(t('{w} copied.', { w: t(what) })); }
    catch (e) { TR.notify && TR.notify.toast(t('Could not copy.'), 'error'); }
  }
  /** Saves text as a file the person chose to download (nothing leaves the browser). */
  function download(name, text, type) {
    try {
      const url = URL.createObjectURL(new Blob([text], { type: type || 'application/json' }));
      const a = h('a', { href: url, download: name, style: { display: 'none' } }); document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch (e) { TR.notify && TR.notify.toast(t('Could not save the file.'), 'error'); }
  }
  /** CSV from rows of plain values (quotes doubled; formulas neutralised for spreadsheets). */
  function csv(rows) {
    const cell = (v) => { let s = v == null ? '' : String(v); if (/^[=+\-@]/.test(s)) s = "'" + s; return /[",\n;]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
    return rows.map((r) => r.map(cell).join(',')).join('\n');
  }
  /** A select with a visible label inside the control, as in the designs ("Status: All"). */
  function select(lbl, value, options, onChange, extra) {
    return h('label', Object.assign({ class: 'jr-select' }, extra || {}), h('span', { class: 'jr-select-label' }, t(lbl) + ':'),
      h('select', { 'aria-label': t(lbl), onChange: (e) => onChange(e.target.value) }, options.map(([v, l]) => h('option', { value: v, selected: String(v) === String(value) }, t(l)))));
  }
  function search(placeholder, value, onInput, extra) {
    return h('label', Object.assign({ class: 'jr-search' }, extra || {}), TR.icon('search', 16), h('input', { type: 'search', placeholder: t(placeholder), value, 'aria-label': t(placeholder), onInput: (e) => onInput(e.target.value) }));
  }
  /** Debounced refresh for text filters. */
  let timer = null;
  const later = (fn, ms) => { clearTimeout(timer); timer = setTimeout(fn, ms || 250); };
  const me = () => (TR.backend && TR.backend.session) || {};

  TR.journey = { t, STATE, state, chip, api, P, param, open, readParams, label, vehicleText, secs, ago, time, initials, pageHead, stats, card, stepper, banner, facts, loading, failed, empty, copy, download, csv, select, search, later, me };
})();
