/* Create a test request — step 1 of 5, choosing the vehicle. A page like the others (it used to be the "Add a vehicle"
 * side panel). New request, Add vehicle and every other way in open it.
 *
 *   Choose your vehicle   Search vehicle (a chassis such as FH 333333, or a 17-character VIN) · Recent vehicles (loaded
 *                         before in this browser) · Other sources (EDB specification, product or request XML)
 *   Your request          the chosen vehicle (or none yet), and what happens next
 *   Need a hand?          the guide and the quick tour
 *   Bottom bar            Step 1 of 5 · Cancel · Continue to changes (once a vehicle is chosen)
 *
 * Loading uses the workspace's own loaders (the left pane), so a vehicle chosen here is the one the next steps change. */
(function () {
  'use strict';
  const { h } = TR.util;
  const J = TR.journey, t = J.t;
  const N = { tab: 'search', q: '', busy: false, error: '', other: 'EDB', spec: '', xml: '', fileName: '' };
  const L = () => TR.app.shell.left;
  const session = () => (TR.backend && TR.backend.session) || {};
  const recent = () => { try { return TR.util.store.get('trstudio.' + session().userId + '.recent', []) || []; } catch (e) { return []; } };

  /** What was typed: a chassis ("FH 333333", "FH-333333", "fh333333") or a VIN (17 characters, no I, O or Q). */
  function parse(input) {
    const s = String(input || '').trim().toUpperCase();
    if (/^[A-HJ-NPR-Z0-9]{17}$/.test(s)) return { kind: 'VIN', vin: s };
    const m = /^([A-Z]{1,4})[\s|\-_/]*(\d{3,8})$/.exec(s);
    return m ? { kind: 'VDA', series: m[1], number: m[2] } : null;
  }
  const sameChassis = (series, number) => { const p = L() && L().product; if (!p || !p.loaded()) return false; const c = p.chassis(); return c.chassisSeries === series && String(c.chassisNumber) === String(number); };

  async function load(target) {
    const pane = L();
    N.busy = true; N.error = ''; TR.app.refresh();
    try {
      if (target.kind === 'XML') { const ok = await pane.loadFileText(target.xml, target.fileName || 'Imported XML'); if (!ok) throw new Error(t('The XML could not be read as a product or a request.')); }
      else {
        pane.sourceType = target.kind === 'VIN' ? 'VIN' : target.kind === 'EDB' ? 'EDB' : 'VDA';
        Object.assign(pane.src, { series: target.series || '', number: target.number || '', vin: target.vin || '', specId: target.spec || '' });
        await pane.loadFromSource(false);
        const found = target.kind === 'VDA' ? sameChassis(target.series, target.number) : pane.product.loaded();
        if (!found) throw new Error(target.kind === 'VIN' ? t('No vehicle with VIN {v} was found.', { v: target.vin }) : target.kind === 'EDB' ? t('Specification {s} could not be loaded.', { s: target.spec }) : t('No vehicle {s} {n} was found. Check the chassis series and number.', { s: target.series, n: target.number }));
      }
      if (TR.announce) TR.announce(t('Vehicle {v} selected.', { v: vehicleName() }));
    } catch (e) { N.error = e.message || String(e); }
    N.busy = false; TR.app.refresh();
  }
  function find() {
    const p = parse(N.q);
    if (!p) { N.error = t('Enter a chassis such as FH 333333, or a 17-character VIN.'); TR.app.refresh(); return; }
    load(p);
  }
  const vehicleName = () => { const p = L() && L().product; return p && p.loaded() ? TR.model.chassisText(p.get()) : ''; };

  // ------------------------------------------------------------------ choose your vehicle
  function searchTab() {
    return h('div', { class: 'nr-pane' },
      h('form', { class: 'nr-find', onSubmit: (e) => { e.preventDefault(); find(); } },
        h('label', { class: 'nr-label', for: 'nr-q' }, t('Vehicle ID or VIN')),
        h('div', { class: 'nr-find-row' },
          h('input', { id: 'nr-q', key: 'nr-q', class: 'nr-input', autocomplete: 'off', spellcheck: 'false', placeholder: t('e.g. FH 333333'), value: N.q, 'aria-describedby': 'nr-q-help' + (N.error ? ' nr-q-error' : ''), 'aria-invalid': N.error ? 'true' : null, onInput: (e) => { N.q = e.target.value; if (N.error) { N.error = ''; TR.app.refresh(); } } }),
          TR.pages.ui.button(t(N.busy ? 'Finding…' : 'Find vehicle'), 'search', null, 'primary nr-find-btn', { type: 'submit', disabled: N.busy })),
        h('small', { id: 'nr-q-help', class: 'muted' }, t('Enter the complete ID to find a matching vehicle.')),
        N.error ? h('p', { id: 'nr-q-error', class: 'nr-error', role: 'alert' }, TR.icon('alert', 15), N.error) : null));
  }
  function recentTab() {
    const list = recent();
    if (!list.length) return h('div', { class: 'nr-pane' }, J.empty('No recent vehicles yet', 'Vehicles you load appear here, in this browser.'));
    return h('div', { class: 'nr-pane' }, h('ul', { class: 'nr-list' }, list.slice(0, 8).map((e) => h('li', { class: 'nr-item' },
      h('span', { class: 'nr-item-icon', 'aria-hidden': 'true' }, TR.icon('truck', 22)),
      h('span', { class: 'nr-item-text' }, h('strong', null, e.label || e.series + ' ' + e.number), h('small', { class: 'muted' }, t('{s} · loaded {a}', { s: e.source || 'VDA', a: J.ago(e.time) }))),
      sameChassis(e.series, e.number) ? h('span', { class: 'nr-chosen' }, TR.icon('check', 15), t('Selected'))
        : TR.pages.ui.button(t('Use vehicle'), null, () => load({ kind: 'VDA', series: e.series, number: e.number }), 'secondary', { disabled: N.busy })))));
  }
  function otherTab() {
    const xml = N.other === 'XML';
    return h('div', { class: 'nr-pane' },
      h('div', { class: 'tp-seg nr-seg', role: 'group', 'aria-label': t('Source') }, [['EDB', 'EDB specification'], ['XML', 'Product or request XML']].map(([k, l]) =>
        h('button', { type: 'button', class: N.other === k ? 'is-on' : '', 'aria-pressed': String(N.other === k), onClick: () => { N.other = k; N.error = ''; TR.app.refresh(); } }, t(l)))),
      xml ? h('div', { class: 'nr-xml' },
        h('div', { class: 'nr-find-row' }, TR.pages.ui.button(t('Choose XML file'), 'file', async () => { const f = await TR.util.pickFile('.xml'); if (f) { N.xml = await TR.util.readFileText(f); N.fileName = f.name; TR.app.refresh(); } }, 'secondary'),
          N.fileName ? h('span', { class: 'muted' }, N.fileName) : null),
        h('textarea', { key: 'nr-xml', class: 'nr-input nr-textarea', 'aria-label': t('Paste product or request XML'), placeholder: t('…or paste product / request XML here'), value: N.xml, onInput: (e) => { N.xml = e.target.value; N.fileName = ''; } }),
        TR.pages.ui.button(t('Load XML'), 'arrow', () => { if (!N.xml.trim()) { N.error = t('Choose a file or paste XML first.'); TR.app.refresh(); return; } load({ kind: 'XML', xml: N.xml, fileName: N.fileName }); }, 'primary', { disabled: N.busy }))
        : h('form', { class: 'nr-find', onSubmit: (e) => { e.preventDefault(); if (!N.spec.trim()) { N.error = t('Enter an EDB specification ID.'); TR.app.refresh(); return; } load({ kind: 'EDB', spec: N.spec.trim() }); } },
          h('label', { class: 'nr-label', for: 'nr-spec' }, t('EDB specification ID')),
          h('div', { class: 'nr-find-row' }, h('input', { id: 'nr-spec', key: 'nr-spec', class: 'nr-input', placeholder: t('e.g. VSS-12-345'), value: N.spec, onInput: (e) => { N.spec = e.target.value; } }),
            TR.pages.ui.button(t('Load specification'), 'arrow', null, 'primary nr-find-btn', { type: 'submit', disabled: N.busy }))),
      N.error ? h('p', { class: 'nr-error', role: 'alert' }, TR.icon('alert', 15), N.error) : null);
  }
  function chooser() {
    const tabs = [['search', 'Search vehicle', 'search'], ['recent', 'Recent vehicles', 'clock'], ['other', 'Other sources', 'file']];
    return h('section', { class: 'jr-card nr-choose', 'aria-labelledby': 'nr-choose-title' },
      h('h2', { id: 'nr-choose-title', class: 'nr-title' }, t('Choose your vehicle')), h('p', { class: 'muted nr-sub' }, t('Search by vehicle ID or VIN, or choose a recent vehicle.')),
      h('div', { class: 'jr-tabs', role: 'tablist', 'aria-label': t('Choose your vehicle') }, tabs.map(([k, l, i]) =>
        h('button', { role: 'tab', 'aria-selected': String(N.tab === k), class: N.tab === k ? 'is-on' : '', onClick: () => { N.tab = k; N.error = ''; TR.app.refresh(); } }, TR.icon(i, 16), t(l)))),
      N.tab === 'recent' ? recentTab() : N.tab === 'other' ? otherTab() : searchTab(),
      h('p', { class: 'nr-note' }, TR.icon('shield', 16), t('Changes are simulated. Live vehicles are not affected.')));
  }

  // ------------------------------------------------------------------ your request, and help
  function summary() {
    const pane = L(), loaded = pane && pane.product.loaded();
    let chosen;
    if (loaded) {
      const p = pane.product.get(), info = p.productSpecification.productInformation, t3 = p.nodes.some((n) => n.electricalArchitecture === 3);
      chosen = h('div', { class: 'nr-picked' },
        h('span', { class: 'nr-picked-icon', 'aria-hidden': 'true' }, TR.icon('truck', 28)),
        h('strong', { class: 'nr-picked-name' }, TR.model.chassisText(p)),
        J.facts([['Architecture', t3 ? 'T3' : t('Legacy')], ['Model', info.modelId || info.vehicleModel || null], ['Source', pane.sourceType || 'VDA'], pane.items.length > 1 ? ['Vehicles', String(pane.items.length)] : null]),
        h('button', { class: 'jr-link', onClick: () => { pane.setProducts([]); if (TR.testRequest) TR.testRequest.validation = null; N.tab = 'search'; TR.app.refresh(); setTimeout(() => { const i = document.getElementById('nr-q'); if (i) i.focus(); }, 0); } }, TR.icon('close', 14), t('Change vehicle')));
    } else chosen = h('div', { class: 'nr-empty' }, h('span', { class: 'nr-empty-icon', 'aria-hidden': 'true' }, TR.icon('truck', 30)), h('strong', null, t('No vehicle selected')), h('span', { class: 'muted' }, t('Select a vehicle to see its configuration here.')));
    return h('section', { class: 'jr-card nr-request', 'aria-live': 'polite', 'aria-label': t('Your request') },
      h('h2', { class: 'nr-title' }, t('Your request')), chosen);
  }
  function help() {
    return h('button', { class: 'jr-link nr-help-link', onClick: () => (TR.tour && TR.tour.start ? TR.tour.start() : TR.pages.show('learn')) }, TR.icon('help', 16), t('View quick guide'));
  }

  function render() {
    const loaded = L() && L().product.loaded();
    const head = J.pageHead('Create a test request', 'Choose a vehicle to start configuring software changes.',
      [TR.testRequest && TR.testRequest.restoreDraft ? TR.pages.ui.button(t('Open saved draft'), 'save', () => TR.testRequest.restoreDraft(), 'secondary') : null]);
    return h('div', { class: 'jr-page nr-page' }, head, J.stepper(0),
      h('div', { class: 'nr-grid' }, chooser(), h('div', { class: 'nr-side' }, summary(), help())),
      h('footer', { class: 'nr-bar is-sticky-bottom' },
        h('span', { class: 'nr-bar-step' }, h('strong', null, t('Step {a} of {b}', { a: 1, b: 5 })), ' · ', t('Choose a vehicle')),
        h('span', { class: 'spacer' }),
        h('button', { class: 'jr-link', onClick: () => { if (TR.experience) TR.experience.page = null; TR.pages.show('home'); } }, t('Cancel')),
        h('span', { class: 'nr-continue' },
          TR.pages.ui.button(t('Continue to changes'), 'arrow', () => TR.testRequest.page(), 'primary', { disabled: !loaded, 'aria-describedby': loaded ? null : 'nr-continue-hint' }),
          loaded ? null : h('small', { id: 'nr-continue-hint', class: 'muted' }, t('Choose a vehicle to continue.')))));
  }

  TR.pages.register({ id: 'new', title: 'New test request', crumbs: () => [{ label: t('Workspace'), open: () => TR.testRequest && TR.testRequest.page() }, { label: t('New test request') }], render });
  // New request, Add vehicle and every other way in open this page (testrequest.js intake() delegates here).
  const open = () => { N.error = ''; N.tab = 'search'; J.open('new'); setTimeout(() => { const i = document.getElementById('nr-q'); if (i && !L().product.loaded()) i.focus(); }, 60); };
  if (TR.testRequest) TR.testRequest.intakePage = open;
  if (TR.header) TR.header.newRequest = open;
  TR.newRequest = { N, parse, open };
})();
