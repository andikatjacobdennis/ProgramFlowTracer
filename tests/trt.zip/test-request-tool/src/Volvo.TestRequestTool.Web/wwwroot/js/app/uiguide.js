/* The illustrated UI guide, inside the application (Help → UI guide). It used to open as a separate browser tab
 * (/guide/); it is now a page like the others, with the application's header, menus, theme and one scrollbar.
 *
 * The same chapters as /guide/ (guide-data.js, loaded when the page first opens): real screenshots for the current theme,
 * numbered balloons placed on the controls, matching steps (hover either to highlight its partner), notes and links that
 * open in this tab. Contents on the left follow the chapter in view; search filters chapters and marks every match.
 * "Enlarge" widens a screenshot in place (no overlay).
 *
 *   TR.uiGuide.open(chapter?)  – open the page, at a chapter (for example 'compare-breakdown')
 * Any link to /guide/ in the application opens this page instead of a new tab. */
(function () {
  'use strict';
  const { h } = TR.util;
  const J = TR.journey, t = J.t;
  const G = { q: '', target: null, wide: {}, loading: false, error: '' };
  const data = () => window.TR_GUIDE;
  const theme = () => document.documentElement.getAttribute('data-theme') || 'charcoal-light';
  const reduced = () => document.documentElement.dataset.motion === 'reduced';

  function load() {
    if (data() || G.loading) return;
    G.loading = true;
    const s = document.createElement('script');
    s.src = '/guide/guide-data.js';
    s.onload = () => { G.loading = false; TR.app.refresh(); };
    s.onerror = () => { G.loading = false; G.error = t('The guide could not be loaded. Check the connection and try again.'); TR.app.refresh(); };
    document.head.appendChild(s);
  }
  const shotFor = (ch) => (ch.shots && (ch.shots[theme()] || ch.shots[(data().themes || [])[0]])) || ch.shot;
  const pct = (v, total) => (100 * v / total).toFixed(3) + '%';

  /** Text with every occurrence of q marked. */
  function marked(text, q) {
    if (!q) return String(text || '');
    const s = String(text || ''), lower = s.toLowerCase(), out = [];
    let i = 0;
    for (let at = lower.indexOf(q); at >= 0; at = lower.indexOf(q, i)) { out.push(s.slice(i, at), h('mark', null, s.slice(at, at + q.length))); i = at + q.length; }
    out.push(s.slice(i));
    return out;
  }
  const has = (text, q) => !q || String(text || '').toLowerCase().includes(q);

  // Hovering a balloon or a step highlights its partner, without re-rendering.
  function focus(id, n) {
    document.querySelectorAll(`.ug-figure[data-chapter="${id}"]`).forEach((fig) => {
      fig.classList.toggle('focus', n != null);
      fig.querySelectorAll('[data-n]').forEach((x) => x.classList.toggle('on', String(n) === x.dataset.n));
    });
    document.querySelectorAll(`#ug-${id} .ug-step`).forEach((s) => s.classList.toggle('on', String(n) === s.dataset.n));
  }
  function figure(shot, id) {
    const placed = [], kids = [h('img', { src: '/guide/img/' + shot.file, alt: shot.alt || '', width: shot.width, height: shot.height, loading: 'lazy' })];
    for (const b of shot.balloons || []) {
      const r = b.rect, pad = 4, R = 17;
      kids.push(h('div', { class: 'ug-hl', 'data-n': b.n, style: { left: pct(r.x - pad, shot.width), top: pct(r.y - pad, shot.height), width: pct(r.w + 2 * pad, shot.width), height: pct(r.h + 2 * pad, shot.height) } }));
      // The balloon sits just outside the frame (left, or right when there is no room); overlapping balloons move down.
      let bx = r.x - pad - R - 3 < R ? r.x + r.w + pad + R + 3 : r.x - pad - R - 3, by = r.y + Math.min(r.h / 2, 16);
      bx = Math.min(Math.max(bx, R), shot.width - R);
      for (let i = 0; i < 12 && placed.some(([x, y]) => Math.hypot(x - bx, y - by) < 2 * R + 4); i++) by += 2 * R + 6;
      by = Math.min(Math.max(by, R), shot.height - R);
      placed.push([bx, by]);
      kids.push(h('button', { type: 'button', class: 'ug-balloon', 'data-n': b.n, title: b.title, 'aria-label': t('Step {n}: {s}', { n: b.n, s: b.title }), style: { left: pct(bx, shot.width), top: pct(by, shot.height) },
        onMouseenter: () => focus(id, b.n), onMouseleave: () => focus(id, null), onFocus: () => focus(id, b.n), onBlur: () => focus(id, null),
        onClick: () => { const s = document.getElementById(`ug-${id}-step-${b.n}`); if (s) s.scrollIntoView({ block: 'nearest', behavior: reduced() ? 'auto' : 'smooth' }); } }, String(b.n)));
    }
    if (shot.caption) kids.push(h('figcaption', null, shot.caption));
    return h('figure', { class: 'ug-figure', 'data-chapter': id }, kids);
  }
  function chapter(ch, num, q) {
    const shot = shotFor(ch), wide = !!G.wide[ch.id];
    const steps = ch.steps.filter((s) => !q || has(s.title, q) || has(s.text, q) || has(ch.title, q) || has(ch.intro, q) || has(ch.part, q));
    return h('section', { class: ['ug-chapter', wide && 'is-wide'], id: 'ug-' + ch.id, 'data-id': ch.id, 'aria-labelledby': 'ug-' + ch.id + '-title' },
      h('header', null, h('h2', { id: 'ug-' + ch.id + '-title' }, h('span', { class: 'ug-num' }, num), marked(ch.title, q), ch.tag ? h('span', { class: 'ug-tag' }, ch.tag) : null),
        h('p', { class: 'ug-intro' }, marked(ch.intro, q))),
      h('div', { class: 'ug-row' },
        shot ? h('div', { class: 'ug-shot' }, figure(shot, ch.id),
          h('button', { type: 'button', class: 'jr-link ug-enlarge', 'aria-pressed': String(wide), onClick: () => { G.wide[ch.id] = !wide; TR.app.refresh(); } }, TR.icon(wide ? 'compare' : 'expand', 14), t(wide ? 'Show beside the steps' : 'Enlarge screenshot'))) : null,
        h('div', { class: 'ug-side' },
          h('ol', { class: 'ug-steps' }, steps.map((s) => h('li', { class: ['ug-step', q && (has(s.title, q) || has(s.text, q)) && 'is-hit'], id: `ug-${ch.id}-step-${s.n}`, 'data-n': s.n,
            onMouseenter: () => focus(ch.id, s.n), onMouseleave: () => focus(ch.id, null) },
            h('span', { class: 'ug-dot', 'aria-hidden': 'true' }, String(s.n)), h('div', null, h('b', null, marked(s.title, q)), h('p', null, marked(s.text, q)))))),
          ch.note ? h('div', { class: 'ug-note' }, h('b', null, t('Note.') + ' '), ch.note) : null,
          (ch.links || []).length ? h('div', { class: 'ug-actions' }, ch.links.map((l, i) => h('a', { class: ['s-btn', i ? 'secondary' : 'primary'], href: l.href }, l.label))) : null)));
  }

  function render() {
    load();
    const d = data();
    const head = J.pageHead(d ? d.title : 'UI guide', d ? '' : 'The illustrated walkthrough of the application.');
    if (!d) return h('div', { class: 'jr-page ug-page' }, head, G.error ? J.failed(G.error, () => { G.error = ''; load(); TR.app.refresh(); }) : J.loading(4));
    const q = G.q.trim().toLowerCase();
    const shown = [];
    let n = 0;
    for (const ch of d.chapters) {
      n++;
      const hit = !q || has(ch.title, q) || has(ch.intro, q) || has(ch.part, q) || ch.steps.some((s) => has(s.title, q) || has(s.text, q));
      if (hit) shown.push([ch, String(n).padStart(2, '0')]);
    }
    const toc = [], body = [];
    let part = null;
    for (const [ch, num] of shown) {
      if (ch.part !== part) { part = ch.part; toc.push(h('h2', null, part)); body.push(h('div', { class: 'ug-part' }, part)); }
      toc.push(h('a', { href: '#ug-' + ch.id, 'data-target': ch.id, onClick: (e) => { e.preventDefault(); go(ch.id); } }, h('span', null, num), ch.title));
      body.push(chapter(ch, num, q));
    }
    const steps = q ? shown.reduce((a, [ch]) => a + ch.steps.filter((s) => has(s.title, q) || has(s.text, q)).length, 0) : 0;
    if (typeof setTimeout === 'function') setTimeout(afterRender, 0);
    return h('div', { class: 'jr-page ug-page' },
      head,
      h('div', { class: 'ug-layout' },
        h('aside', { class: 'ug-toc', 'aria-label': t('Guide contents') },
          h('label', { class: 'jr-search ug-search' }, TR.icon('search', 16), h('input', { type: 'search', key: 'ug-q', placeholder: t('Search the guide ( / )'), 'aria-label': t('Search the guide'), value: G.q, autocomplete: 'off',
            onInput: (e) => { G.q = e.target.value; J.later(() => TR.app.refresh(), 120); }, onKeydown: (e) => { if (e.key === 'Escape') { G.q = ''; TR.app.refresh(); } } })),
          h('p', { class: 'ug-status muted', role: 'status' }, q ? (shown.length ? t('{c} chapters and {s} steps match', { c: shown.length, s: steps }) : t('No matches')) : ''),
          h('nav', { class: 'ug-toc-list' }, toc)),
        h('div', { class: 'ug-main' },
          q ? null : h('section', { class: 'ug-hero' }, d.intro.map((p) => h('p', null, p)),
            h('div', { class: 'ug-legend' },
              h('span', null, h('b', null, t('Numbered balloons')), ' ', t('mark the controls described in the steps beside each screenshot.')),
              h('span', null, h('b', null, t('Hover')), ' ', t('a balloon or a step to highlight its partner.'), ' ', h('b', null, t('Enlarge')), ' ', t('widens a screenshot.')))),
          body,
          q && !shown.length ? h('p', { class: 'ug-empty' }, t('Nothing in the guide matches your search. Try a shorter word, for example “kit” or “validate”.')) : null,
          h('p', { class: 'ug-foot muted' }, d.footer))));
  }
  /** After drawing: mark the chapter in view in the contents, and jump to a requested chapter. */
  function afterRender() {
    if (!document.querySelector('.ug-toc-list a')) return;
    markActive();
    // Opening a page scrolls it to the top on the next tick (journey.js open()); jump to the chapter after that.
    if (G.target) { const id = G.target; G.target = null; setTimeout(() => { go(id, true); markActive(); }, 60); }
  }
  /** Marks the chapter in view in the contents: the last one whose top has passed a quarter of the content area. */
  function markActive() {
    const main = document.querySelector('.s-main'), links = [...document.querySelectorAll('.ug-toc-list a')];
    if (!main || !links.length) return;
    const line = main.getBoundingClientRect().top + main.clientHeight * 0.25;
    let id = null;
    for (const sec of document.querySelectorAll('.ug-chapter')) { if (sec.getBoundingClientRect().top <= line) id = sec.dataset.id; else break; }
    if (!id) { const first = document.querySelector('.ug-chapter'); id = first && first.dataset.id; }
    links.forEach((a) => { const on = a.dataset.target === id; a.classList.toggle('active', on); if (on) a.setAttribute('aria-current', 'location'); else a.removeAttribute('aria-current'); });
  }
  // One scroll listener for the page (capture: the content area scrolls, not the window), at most once per frame.
  let ticking = false;
  if (typeof document.addEventListener === 'function') document.addEventListener('scroll', () => {
    if (ticking || !(TR.pages.current && TR.pages.current() === 'guide')) return;
    ticking = true; (window.requestAnimationFrame || setTimeout)(() => { ticking = false; markActive(); });
  }, { capture: true, passive: true });
  function go(id, instant) {
    const el = document.getElementById('ug-' + id);
    if (!el) return;
    el.scrollIntoView({ block: 'start', behavior: instant || reduced() ? 'auto' : 'smooth' });
    const hd = el.querySelector('h2'); if (hd) { hd.setAttribute('tabindex', '-1'); hd.focus({ preventScroll: true }); }
  }
  /** Opens the guide page, optionally at a chapter. */
  function open(chapterId) {
    G.target = chapterId ? String(chapterId).replace(/^#/, '') : null;
    if (TR.pages.current && TR.pages.current() === 'guide') { TR.app.refresh(); return; }
    J.open('guide');
  }

  TR.pages.register({ id: 'guide', title: 'UI guide', crumbs: () => [{ label: t('Help'), open: () => TR.pages.show('help') }, { label: t('UI guide') }], render });
  // Links to the guide anywhere in the application open this page in place of a new tab.
  if (typeof document.addEventListener === 'function') document.addEventListener('click', (e) => {
    const a = e.target && e.target.closest && e.target.closest('a[href]');
    if (!a || e.defaultPrevented || e.button > 0 || e.ctrlKey || e.metaKey || e.shiftKey) return;
    const href = a.getAttribute('href') || '';
    const m = /^(?:https?:\/\/[^/]+)?\/guide\/?(?:index\.html)?(?:\?[^#]*)?(?:#(.*))?$/.exec(href);
    if (!m || a.closest('.ug-page')) return;
    e.preventDefault();
    open(m[1] ? decodeURIComponent(m[1]) : null);
  }, true);
  TR.uiGuide = { G, open, marked };
})();
