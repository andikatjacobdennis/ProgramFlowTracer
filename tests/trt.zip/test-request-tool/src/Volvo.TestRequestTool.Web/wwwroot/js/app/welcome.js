/* First-time welcome: on a user's first visit, a friendly full-screen welcome lets them pick an animated guide and start the
 * introduction tour, or explore on their own. Either way they can take the tour later from Help, Settings, Home (first steps),
 * Ctrl+K or g then i. It is shown once per user and browser; Settings → Help → "Show the welcome again" brings it back.
 *
 *   TR.welcome.show()   – open it now
 *   TR.welcome.maybe()  – open it if this user has not seen it yet (called when the top bar renders) */
(function () {
  'use strict';
  const { h } = TR.util;
  const W = { el: null, choice: null };
  const session = () => (TR.backend && TR.backend.session) || {};
  const seenKey = () => 'trstudio.' + (session().userId || 'user') + '.welcomed';
  const speech = () => (typeof window !== 'undefined' && window.speechSynthesis && typeof window.SpeechSynthesisUtterance === 'function' ? window.speechSynthesis : null);
  const firstName = () => String(session().displayName || '').split(/\s+/)[0] || 'there';

  function hello(p) {
    const s = speech(); if (!s) return;
    s.cancel();
    const previous = TR.prefs.get('guide');
    TR.util.store.set('trstudio.guide', p.id);         // pick the voice for this guide without re-rendering the app
    const u = new window.SpeechSynthesisUtterance(`Hi ${firstName()}, I am ${p.name}. ${p.blurb}`);
    const v = TR.tour && TR.tour.pickVoice(); if (v) { u.voice = v; u.lang = v.lang; }
    u.pitch = p.voice.pitch;
    s.speak(u);
    TR.util.store.set('trstudio.guide', previous);
  }

  function view() {
    const choice = W.choice || TR.personas.current().id;
    return h('div', { class: 'wl-card', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': 'wl-title' },
      h('div', { class: 'wl-head' },
        h('h1', { id: 'wl-title' }, `Welcome, ${firstName()}!`),
        h('p', null, 'Test Request Tool helps you plan vehicle software changes, check them and deliver them safely. Pick a guide to show you around. You can change it at any time in Settings.')),
      h('div', { class: 'wl-guides', role: 'radiogroup', 'aria-label': 'Choose your guide' }, TR.personas.LIST().map((p) => {
        const on = p.id === choice;
        return h('div', { class: ['wl-guide', on ? 'is-on' : ''] },
          h('button', { class: 'wl-pick', role: 'radio', 'aria-checked': String(on), onClick: () => { W.choice = p.id; render(); } },
            TR.personas.draw(on ? 'cheer' : 'wave', 118, p.id), h('strong', null, p.name), h('small', null, p.role), h('span', null, p.blurb)),
          speech() ? h('button', { class: 's-btn text wl-hear', onClick: () => hello(p), title: 'Hear ' + p.name }, TR.icon('play', 14), 'Hear me') : null);
      })),
      h('div', { class: 'wl-actions' },
        h('button', { class: 's-btn primary wl-start', onClick: () => finish(true) }, TR.icon('play', 17), 'Start the 2-minute tour'),
        h('button', { class: 's-btn secondary', onClick: () => finish(false) }, 'Explore on my own'),
        h('label', { class: 'wl-voice' }, h('input', { type: 'checkbox', checked: TR.prefs.get('tourVoice') !== false, onChange: (e) => TR.util.store.set('trstudio.tourVoice', e.target.checked) }), ' Read the tour aloud')),
      h('div', { class: 'wl-privacy' },
        h('label', { class: 'wl-voice' }, h('input', { type: 'checkbox', checked: TR.prefs.get('usageStudy') !== false, onChange: (e) => (TR.usage ? TR.usage.setRecording(e.target.checked) : TR.util.store.set('trstudio.usageStudy', e.target.checked)) }),
          ' ' + TR.i18n.t('Help improve the app: record which features I use (never what I type)')),
        h('button', { class: 's-btn text', onClick: () => { finish(false); TR.pages.show('mydata'); } }, TR.icon('lock', 14), TR.i18n.t('See what the app knows about me'))),
      h('p', { class: 'wl-later' }, 'You can skip the tour at any time and take it later from Help, Settings, Ctrl+K or by pressing g then i. You can change the usage study any time on My data.'));
  }
  function render() {
    if (!W.el) return;
    W.el.replaceChildren(view());
    setTimeout(() => { if (!W.el) return; W.el.querySelector('.wl-start')?.focus(); const picked = W.el.querySelector('.wl-guide.is-on'); if (picked && TR.personas) TR.personas.react(picked); }, 0);
  }
  function onKey(e) { if (W.el && e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); finish(false); } }
  function show() {
    if (W.el || typeof document.body === 'undefined' || !document.body) return;
    W.choice = TR.personas.current().id;
    W.el = h('div', { class: 'wl-layer' });
    document.body.appendChild(W.el);
    document.addEventListener('keydown', onKey, true);
    render();
  }
  function finish(tour) {
    if (!W.el) return;
    TR.util.store.set(seenKey(), true);
    document.removeEventListener('keydown', onKey, true);
    W.el.remove(); W.el = null;
    if (speech()) speech().cancel();
    TR.prefs.set('guide', W.choice || 'asha');
    if (tour && TR.tour) TR.tour.start();
  }
  /** Shown once per user, after the server session is known, and never during the tour or a dialog. */
  function maybe() {
    if (W.el || !session().userId || TR.util.store.get(seenKey(), false)) return;
    // Opened on a link to a page (a review to approve, a request to track): let them do that first. The welcome is still
    // unseen, so it appears on the next ordinary visit.
    const view = typeof location !== 'undefined' && location.search ? new URLSearchParams(location.search).get('view') : null;
    if (view && view !== 'home') return;
    if (TR.tour && TR.tour.T.on) return;
    setTimeout(() => { if (!TR.util.store.get(seenKey(), false) && !(typeof document.querySelector === 'function' && document.querySelector('#overlays .overlay'))) show(); }, 400);
  }
  // The top bar renders on every screen once the app runs, which is the right moment to check.
  TR.pages.addHeaderItem(() => { maybe(); return null; });
  TR.welcome = { show, maybe, finish, seenKey };
})();
