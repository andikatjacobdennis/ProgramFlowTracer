/* Teams (administrators): who is in which team, and the settings each team (or the whole organisation) manages.
 *
 *   Select one or more teams (and/or the organisation), add the settings to change, choose "default" (people can still
 *   change it) or "locked" (they cannot), Preview to see every before → after and how many people it affects, then Apply:
 *   all selected teams change in one step, as one version, recorded in the audit log. Versions can be restored.
 *   Managed settings shape the interface only; they never grant or remove permissions.
 *
 * Data: /api/v1/admin/teams (GET, PUT /{id}, DELETE /{id}, POST /bulk-settings, GET /history, POST /restore/{v}). */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));
  const ui = () => TR.pages.ui;
  /** How each manageable setting is shown and edited. */
  const META = {
    theme: ['Theme', [['auto', 'Auto'], ['charcoal-light', 'Light Charcoal'], ['charcoal', 'Dark Charcoal']]],
    motion: ['Motion', [['on', 'On'], ['off', 'Off']]],
    textSize: ['Text size', [['small', 'Small'], ['default', 'Default'], ['large', 'Large'], ['larger', 'Larger']]],
    experience: ['Experience', [['auto', 'Auto'], ['beginner', 'Beginner'], ['expert', 'Expert']]],
    get uiLanguage() { return ['App language', TR.i18n.LANGS.filter(([c]) => c !== 'qps')]; },   // every installed language pack
    guide: ['Guide', [['tech', 'Technician'], ['engineer', 'Engineer'], ['analyst', 'Analyst'], ['truck', 'Truxie']]],
    pageSize: ['Rows per page', [[10, '10'], [25, '25'], [50, '50'], [100, '100']]],
    clocksShown: ['Time zones shown together', [[1, '1'], [2, '2'], [3, '3'], [4, '4']]],
    scenario: ['Default scenario', [[0, 'Scenario 0'], [1, 'Scenario 1'], [2, 'Scenario 2'], [3, 'Scenario 3']]],
    calm: ['Calm mode', 'bool'], nudge: ['Idle nudge', 'bool'], personas: ['Show guides', 'bool'], tourVoice: ['Tour voice', 'bool'], firstSteps: ['First steps on Home', 'bool'],
    nextStep: ['Next step button', 'bool'], cultureSwitch: ['Culture switch in the top bar', 'bool'], inlineZones: ['Time zones beside times', 'bool'],
    spellcheck: ['Spelling check', 'bool'], usageStudy: ['Usage study', 'bool'],
  };
  const T = { data: null, error: null, selected: new Set(), org: false, rows: [{ key: 'experience', value: 'expert', locked: false }], unset: [], preview: null, editing: null, history: null, busy: false };

  async function load() {
    try { T.data = await ui().api('/admin/teams'); T.error = null; } catch (e) { T.error = e.message; }
    TR.app.refresh();
  }
  async function call(path, method, body) {
    const r = await fetch('/api/v1' + path, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
    const json = r.status === 204 ? {} : await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(json.detail || json.title || r.statusText);
    return json;
  }
  const valueText = (key, v) => { const m = META[key]; if (!m) return JSON.stringify(v); if (m[1] === 'bool') return v ? t('On') : t('Off'); const o = m[1].find(([x]) => String(x) === String(v)); return o ? t(o[1]) : String(v); };
  const label = (key) => t((META[key] || [key])[0]);
  function chip(key, s) { return h('span', { class: ['tm-chip', s.locked ? 'is-locked' : ''], 'data-tip': label(key) + '|' + (s.locked ? t('Locked: people cannot change it') : t('Default: people can change it')) }, s.locked ? TR.icon('lock', 12) : null, label(key) + ': ' + valueText(key, s.value)); }

  // ------------------------------------------------------------------ bulk change
  const body = (preview) => ({
    teamIds: [...T.selected], organisation: T.org, preview, baseVersion: T.data.version,
    set: Object.fromEntries(T.rows.filter((r) => r.key).map((r) => [r.key, { value: r.value, locked: r.locked }])), unset: T.unset,
  });
  async function preview() { T.busy = true; TR.app.refresh(); try { T.preview = await call('/admin/teams/bulk-settings', 'POST', body(true)); } catch (e) { TR.notify.toast(e.message, 'error'); } T.busy = false; TR.app.refresh(); }
  async function apply() {
    T.busy = true; TR.app.refresh();
    try {
      const r = await call('/admin/teams/bulk-settings', 'POST', body(false));
      TR.notify.toast(t('Changed {n} team(s), {p} people affected. Version {v}.', { n: r.teams, p: r.people, v: r.version }), 'success');
      T.preview = null; T.history = null; await load();
      if (TR.managed) TR.managed.load();   // your own effective settings may have changed too
    } catch (e) { TR.notify.toast(e.message, 'error'); }
    T.busy = false; TR.app.refresh();
  }
  function valueControl(row) {
    const m = META[row.key];
    if (!m) return null;
    if (m[1] === 'bool') return TR.pages.ui.button(row.value ? t('On') : t('Off'), null, () => { row.value = !row.value; T.preview = null; TR.app.refresh(); }, row.value ? 'secondary' : 'text', { 'aria-pressed': String(!!row.value) });
    return h('select', { 'aria-label': label(row.key) + ' ' + t('value'), onChange: (e) => { const o = m[1].find(([x]) => String(x) === e.target.value); row.value = o ? o[0] : e.target.value; T.preview = null; } },
      m[1].map(([v, l]) => h('option', { value: String(v), selected: String(v) === String(row.value) }, t(l))));
  }
  function bulk() {
    const d = T.data, used = new Set(T.rows.map((r) => r.key));
    const targets = [...T.selected].map((id) => (d.teams.find((x) => x.id === id) || {}).name).filter(Boolean);
    return h('section', { class: 'st-card hl-card tm-bulk', 'aria-label': t('Change settings') },
      h('header', { class: 'hl-card-head' }, h('div', null, h('h2', null, t('Change settings for several teams at once')),
        h('p', { class: 'muted' }, targets.length || T.org ? t('Applies to: ') + [...targets, T.org ? t('Organisation') : null].filter(Boolean).join(', ') : t('Select teams on the left, or the organisation.')))),
      h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: T.org, onChange: (e) => { T.org = e.target.checked; T.preview = null; TR.app.refresh(); } }), t('Also the organisation (everyone)')),
      h('div', { class: 'tm-rows' }, T.rows.map((row, i) => h('div', { class: 'tm-row' },
        h('select', { 'aria-label': t('Setting'), onChange: (e) => { row.key = e.target.value; const m = META[row.key]; row.value = m[1] === 'bool' ? true : m[1][0][0]; T.preview = null; TR.app.refresh(); } },
          (d.catalogue || Object.keys(META)).filter((k) => k === row.key || !used.has(k)).filter((k) => META[k]).map((k) => h('option', { value: k, selected: k === row.key }, label(k)))),
        valueControl(row),
        h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: row.locked, onChange: (e) => { row.locked = e.target.checked; T.preview = null; TR.app.refresh(); } }), t('Locked')),
        h('button', { class: 'ap-icon-btn', 'aria-label': t('Remove this setting'), onClick: () => { T.rows.splice(i, 1); T.preview = null; TR.app.refresh(); } }, '✕')))),
      h('div', { class: 'tm-actions' },
        ui().button(t('Add a setting'), 'plus', () => { const k = Object.keys(META).find((x) => !used.has(x)); if (k) { T.rows.push({ key: k, value: META[k][1] === 'bool' ? true : META[k][1][0][0], locked: false }); T.preview = null; TR.app.refresh(); } }, 'text'),
        h('label', { class: 'tm-unset' }, t('Clear from the teams: '), h('select', { 'aria-label': t('Setting to clear'), onChange: (e) => { if (e.target.value && !T.unset.includes(e.target.value)) T.unset.push(e.target.value); T.preview = null; TR.app.refresh(); } },
          h('option', { value: '' }, t('choose…')), Object.keys(META).map((k) => h('option', { value: k }, label(k))))),
        T.unset.map((k) => h('span', { class: 'tm-chip' }, t('clear') + ' ' + label(k), h('button', { class: 'ap-icon-btn', 'aria-label': t('Keep {s}', { s: label(k) }), onClick: () => { T.unset = T.unset.filter((x) => x !== k); TR.app.refresh(); } }, '✕')))),
      h('div', { class: 'tm-actions' },
        ui().button(T.busy ? t('Working…') : t('Preview'), 'search', preview, 'secondary', { disabled: T.busy || (!T.selected.size && !T.org) }),
        ui().button(t('Apply to all selected'), 'check', apply, 'primary', { disabled: T.busy || !T.preview })),
      T.preview ? h('div', { class: 'tm-preview', role: 'status' },
        h('p', null, h('strong', null, t('{n} team(s)', { n: T.preview.teams }) + (T.preview.organisation ? ' + ' + t('organisation') : '') + ' · ' + t('{p} people', { p: T.preview.people }))),
        T.preview.changes.map((c) => h('div', { class: 'tm-diff' }, h('strong', null, c.target + (c.people >= 0 ? ' · ' + t('{p} people', { p: c.people }) : '')),
          c.changes.length ? h('ul', null, c.changes.map((x) => h('li', null, label(x.setting) + ': ', h('del', null, x.before ? valueText(x.setting, x.before.value) + (x.before.locked ? ' 🔒' : '') : t('not set')), ' → ',
            h('ins', null, x.after ? valueText(x.setting, x.after.value) + (x.after.locked ? ' 🔒' : '') : t('cleared'))))) : h('p', { class: 'muted' }, t('No change.'))))) : null);
  }

  // ------------------------------------------------------------------ team editor (inline)
  function editor(team) {
    const e = T.editing, people = T.data.people;
    const save = async () => {
      try {
        const id = e.id || e.name.toLowerCase().normalize('NFD').replace(/[^\w\s-]/g, '').trim().replace(/\s+/g, '-').slice(0, 40);
        await call('/admin/teams/' + encodeURIComponent(id), 'PUT', { name: e.name, description: e.description, members: [...e.members], baseVersion: T.data.version });
        TR.notify.toast(t('Team saved.'), 'success'); T.editing = null; await load();
      } catch (x) { TR.notify.toast(x.message, 'error'); }
    };
    return h('section', { class: 'st-card hl-card tm-editor', 'aria-label': t('Edit team') },
      h('h2', null, team ? t('Edit {t}', { t: team.name }) : t('New team')),
      h('label', { class: 's-field' }, h('span', null, t('Name')), h('input', { value: e.name, onInput: (x) => { e.name = x.target.value; } })),
      h('label', { class: 's-field' }, h('span', null, t('Description')), h('input', { value: e.description, onInput: (x) => { e.description = x.target.value; } })),
      h('fieldset', { class: 'tm-people' }, h('legend', null, t('Members')), people.map((p) => h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: e.members.has(p.id), onChange: (x) => { if (x.target.checked) e.members.add(p.id); else e.members.delete(p.id); } }), p.name + ' · ' + p.role))),
      h('div', { class: 'tm-actions' }, ui().button(t('Save team'), 'save', save, 'primary', { disabled: !e.name }), ui().button(t('Cancel'), null, () => { T.editing = null; TR.app.refresh(); }, 'text'),
        team ? ui().button(t('Remove team'), 'trash', async () => { if (!(await TR.ui.confirm(t('Remove {t}? Its members keep their own settings; you can restore it from Versions.', { t: team.name })))) return; try { await call('/admin/teams/' + encodeURIComponent(team.id), 'DELETE'); T.editing = null; T.selected.delete(team.id); await load(); } catch (x) { TR.notify.toast(x.message, 'error'); } }, 'danger') : null));
  }

  // ------------------------------------------------------------------ page
  function render() {
    const session = (TR.backend && TR.backend.session) || {};
    if (!session.isAdmin) return h('div', { class: 'st-page' }, h('h1', null, t('Teams')), h('div', { class: 's-banner' }, TR.icon('lock'), t('Only administrators can manage teams.')));
    if (!T.data && !T.error) load();
    const d = T.data;
    const all = d ? d.teams : [];
    return h('div', { class: 'st-page hl-page tm-page' },
      h('div', { class: 'st-head hl-top' },
        h('div', null, h('h1', null, t('Teams')), h('p', { class: 'muted' }, t('Group people and manage their settings: one team or many at once. Locked settings cannot be changed by members; managed settings never change permissions.'))),
        h('div', { class: 'hl-controls' }, ui().button(t('New team'), 'plus', () => { T.editing = { id: '', name: '', description: '', members: new Set() }; TR.app.refresh(); }, 'secondary'),
          ui().button(T.history ? t('Hide versions') : t('Versions'), 'history', async () => { if (T.history) { T.history = null; TR.app.refresh(); return; } T.history = await ui().api('/admin/teams/history'); TR.app.refresh(); }, 'text'))),
      T.error ? h('div', { class: 's-banner warning' }, TR.icon('alert'), T.error) : null,
      !d ? h('p', { class: 'muted' }, t('Loading…')) : h('div', { class: 'tm-layout' },
        h('div', { class: 'tm-teams' },
          h('div', { class: 'tm-select-bar' },
            h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: all.length > 0 && T.selected.size === all.length, onChange: (e) => { T.selected = e.target.checked ? new Set(all.map((x) => x.id)) : new Set(); T.preview = null; TR.app.refresh(); } }), t('Select all')),
            h('span', { class: 'muted' }, t('{n} selected', { n: T.selected.size }))),
          all.map((team) => h('article', { class: ['st-card', 'tm-team', T.selected.has(team.id) ? 'is-selected' : ''] },
            h('label', { class: 'chk tm-pick' }, h('input', { type: 'checkbox', checked: T.selected.has(team.id), 'aria-label': t('Select {t}', { t: team.name }), onChange: (e) => { if (e.target.checked) T.selected.add(team.id); else T.selected.delete(team.id); T.preview = null; TR.app.refresh(); } })),
            h('div', { class: 'tm-team-body' },
              h('h2', null, team.name), h('p', { class: 'muted' }, team.description || ''),
              h('p', { class: 'tm-members' }, TR.icon('people', 14), ' ', t('{n} members', { n: (team.members || []).length }), ': ', (team.members || []).map((m) => (d.people.find((p) => p.id === m) || { name: m }).name).join(', ') || '—'),
              h('div', { class: 'tm-chips' }, Object.entries(team.settings || {}).map(([k, s]) => chip(k, s)))),
            ui().button(t('Edit'), 'sliders', () => { T.editing = { id: team.id, name: team.name, description: team.description || '', members: new Set(team.members || []) }; TR.app.refresh(); }, 'text'))),
          h('article', { class: ['st-card', 'tm-team', 'tm-org', T.org ? 'is-selected' : ''] },
            h('label', { class: 'chk tm-pick' }, h('input', { type: 'checkbox', checked: T.org, 'aria-label': t('Select the organisation'), onChange: (e) => { T.org = e.target.checked; T.preview = null; TR.app.refresh(); } })),
            h('div', { class: 'tm-team-body' }, h('h2', null, t('Organisation')), h('p', { class: 'muted' }, t('Applies to everyone, below any team setting.')),
              h('div', { class: 'tm-chips' }, Object.entries(d.organisation.settings || {}).map(([k, s]) => chip(k, s))))),
          T.history ? h('section', { class: 'st-card hl-card' }, h('h2', null, t('Versions')), h('ol', { class: 'st-org-history' }, T.history.map((v, i) => h('li', null,
            h('span', null, h('strong', null, 'v' + v.version + ' · ' + (v.note || '')), h('small', null, v.actorName + ' · ' + ui().when(v.at))),
            i === 0 ? ui().chip(t('Current'), 'good') : ui().button(t('Restore'), 'undo', async () => { try { await call('/admin/teams/restore/' + v.version, 'POST'); T.history = null; await load(); TR.notify.toast(t('Restored as a new version.'), 'success'); } catch (x) { TR.notify.toast(x.message, 'error'); } }, 'text'))))) : null),
        h('div', { class: 'tm-side' }, T.editing ? editor(all.find((x) => x.id === T.editing.id)) : null, bulk())));
  }
  TR.pages.register({ id: 'teams', title: 'Teams', crumbs: () => [{ label: t('Settings'), open: () => TR.pages.show('settings') }, { label: t('Teams') }], render });
  TR.teams = { T, load, META };
})();
