/* The simulated assistant: chat, summaries and agent plan previews (server: AssistantEndpoints.cs, SimulatedAssistant.cs).
 * Loaded only when the AI feature flags allow it (features.js); with the flags off nothing here is fetched or run.
 *
 *   Label        every surface says "Simulated assistant — no AI service connected" or "Simulated summary", and these never
 *                look like verified engineering results.
 *   Panel        a docked side panel (resizable, not a dialog): context you can include or exclude, conversation history,
 *                suggested questions, a loading state you can cancel, retry after an error, and Clear conversation.
 *   Context      only records you may read (the server retrieves them); you see which are included and can exclude any.
 *   Summaries    "Summarize (simulated)" on the proposal, the validation findings and Activity: deterministic, from your
 *                records, with the source version and time; marked outdated when the source changes.
 *   Agent        "Plan (preview)": goal, steps, required context and permissions, proposed actions with expected outcomes.
 *                Nothing is executed, submitted or approved.
 *   Safety       every message and response is rendered as plain text (no HTML, scripts or links from the provider other than
 *                in-app navigation the person chooses). Conversations live in this tab only (sessionStorage), cleared on
 *                sign-out or account change; the server keeps none. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));
  const LABEL = 'Simulated assistant — no AI service connected';
  const F = (n) => TR.features && TR.features.on('ai') && TR.features.on(n);
  const userId = () => (TR.backend && TR.backend.session && TR.backend.session.userId) || 'anonymous';
  const key = () => 'trstudio.' + userId() + '.assistant.chat';
  const AS = { panel: null, tab: 'chat', messages: [], excluded: new Set(), context: null, busy: false, abort: null, error: null, lastQuestion: null, plan: null, goal: '', summaries: {} };

  // ------------------------------------------------------------------ session-scoped conversation
  function restore() { try { AS.messages = JSON.parse(sessionStorage.getItem(key()) || '[]').slice(-40); } catch (e) { AS.messages = []; } }
  function persist() { try { sessionStorage.setItem(key(), JSON.stringify(AS.messages.slice(-40))); } catch (e) { /* storage blocked: memory only */ } }
  /** Forget every conversation in this tab (sign-out, account change, Clear conversation). */
  function clear() {
    try { for (let i = sessionStorage.length - 1; i >= 0; i--) { const k = sessionStorage.key(i); if (k && k.endsWith('.assistant.chat')) sessionStorage.removeItem(k); } } catch (e) { /* none */ }
    AS.messages = []; AS.plan = null; AS.error = null; AS.summaries = {};
  }

  // ------------------------------------------------------------------ what can be offered as context (the server checks each)
  function candidates() {
    const list = [], pane = TR.app && TR.app.shell && TR.app.shell.left;
    if (pane && pane.product && pane.product.loaded()) {
      const info = pane.product.info();
      list.push({ kind: 'vehicle', id: info.chassisSeries + '|' + info.chassisNumber, label: t('Vehicle {v}', { v: pane.product.chassisString() }) });
      if (TR.workflow && TR.workflow.W.save.rev) list.push({ kind: 'proposal', id: 'workspace', label: t('Proposal revision {n}', { n: TR.workflow.W.save.rev }) });
    }
    const latest = TR.backend && TR.backend.latest;
    if (latest && latest.id) list.push({ kind: 'request', id: latest.id, label: t('Latest validation') });
    list.push({ kind: 'activity', id: 'mine', label: t('Your recent requests') });
    return list;
  }
  const included = () => candidates().filter((c) => !AS.excluded.has(c.kind));

  // ------------------------------------------------------------------ calls
  async function post(path, body, signal) {
    const r = await fetch('/api/v1/assistant' + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal });
    const json = await r.json().catch(() => ({}));
    if (!r.ok) { const e = new Error(json.detail || json.title || r.statusText); e.retryable = json.retryable !== false && r.status >= 500; e.status = r.status; throw e; }
    return json;
  }
  async function ask(text) {
    const q = String(text || '').trim();
    if (!q || AS.busy) return;
    AS.lastQuestion = q; AS.error = null;
    AS.messages.push({ role: 'user', text: q, at: Date.now() }); persist();
    AS.busy = true; AS.abort = new AbortController(); refresh();
    TR.announce && TR.announce(t('Asking the simulated assistant.'));
    try {
      const reply = await post('/chat', { messages: AS.messages.map((m) => ({ role: m.role, text: m.text })), include: included().map((c) => ({ kind: c.kind, id: c.id })) }, AS.abort.signal);
      AS.messages.push({ role: 'assistant', text: reply.text, citations: reply.citations, confidence: reply.confidence, actions: reply.actions, suggested: reply.suggestedQuestions, at: Date.now() });
      persist();
      TR.announce && TR.announce(t('Simulated answer: {a}', { a: reply.text.slice(0, 160) }));
    } catch (e) {
      if (e.name === 'AbortError') { AS.messages.push({ role: 'note', text: t('Cancelled. Your question is kept; ask again when ready.'), at: Date.now() }); }
      else { AS.error = e; TR.announce && TR.announce(t('The assistant could not answer: {e}', { e: e.message })); }
    }
    AS.busy = false; AS.abort = null; refresh();
  }
  function cancel() { if (AS.abort) AS.abort.abort(); }
  async function plan() {
    if (!AS.goal.trim() || AS.busy) return;
    AS.busy = true; AS.error = null; AS.abort = new AbortController(); refresh();
    try { AS.plan = await post('/agent/plan', { goal: AS.goal, include: included().map((c) => ({ kind: c.kind, id: c.id })) }, AS.abort.signal); TR.announce && TR.announce(t('Plan preview ready: {n} steps.', { n: AS.plan.steps.length })); }
    catch (e) { if (e.name !== 'AbortError') AS.error = e; }
    AS.busy = false; AS.abort = null; refresh();
  }
  async function loadContext() {
    try { AS.context = await post('/context', { include: candidates().map((c) => ({ kind: c.kind, id: c.id })) }); } catch (e) { AS.context = { items: [], unavailable: [e.message] }; }
    refresh();
  }

  // ------------------------------------------------------------------ rendering (plain text only)
  const refresh = () => { if (AS.panel && !AS.panel.closed) AS.panel.render(); };
  /** Suggested actions only move you somewhere; they never run, save or submit anything. */
  function navigate(a) {
    const target = a && a.arguments && a.arguments.target, S = TR.testRequest;
    if (!target) return;
    if (TR.experience) TR.experience.page = null;
    if (target === 'vehicle') { S.intake(); return; }
    if (target === 'prepare' || target === 'testrequest') { S.page('software'); return; }
    if (target === 'validate' || target === 'findings') { S.page(); S.stage = 'validate'; TR.app.refresh(); return; }
    if (target === 'review') { S.page(); S.stage = 'review'; TR.app.refresh(); return; }
    if (TR.pages.get(target)) TR.pages.show(target);
  }
  function citation(c) {
    // Only in-app references become links (to Help); anything else is shown as text.
    const ref = typeof c.reference === 'string' && /^\?view=help(&article=[a-z0-9-]+)?$/.test(c.reference) ? c.reference : null;
    return ref ? h('a', { class: 'tm-chip', href: '/' + ref, onClick: (e) => { e.preventDefault(); const m = ref.match(/article=([a-z0-9-]+)/); TR.pages.show('help'); if (m && TR.help && TR.help.open) TR.help.open(m[1]); } }, TR.icon('book', 12), c.title)
      : h('span', { class: 'tm-chip' }, TR.icon(c.kind === 'record' ? 'database' : 'info', 12), c.title);
  }
  function message(m) {
    if (m.role === 'note') return h('li', { class: 'as-msg is-note' }, h('p', null, m.text));
    const mine = m.role === 'user';
    return h('li', { class: ['as-msg', mine ? 'is-user' : 'is-bot'] },
      h('span', { class: 'nv-sr' }, mine ? t('You said: ') : t('Simulated assistant said: ')),
      h('p', null, m.text),
      !mine && m.confidence ? h('div', { class: 'as-meta' }, h('span', { class: 'wf-kind tone-' + (m.confidence === 'confirmed' ? 'good' : m.confidence === 'likely' ? 'warning' : 'danger') }, TR.icon(m.confidence === 'confirmed' ? 'check' : 'help', 12), t({ confirmed: 'Confirmed by a record or rule', likely: 'Likely', unknown: 'Outside the simulation' }[m.confidence] || m.confidence)),
        (m.citations || []).map(citation)) : null,
      !mine && m.actions && m.actions.length ? h('div', { class: 'as-actions' }, m.actions.map((a) => TR.pages.ui.button(t(a.label), 'arrow', () => navigate(a), 'text'))) : null);
  }
  function contextBox() {
    const all = candidates(), items = (AS.context && AS.context.items) || [], unavailable = (AS.context && AS.context.unavailable) || [];
    return h('fieldset', { class: 'as-context' }, h('legend', null, t('Context the assistant may use')),
      all.map((c) => { const ok = items.find((i) => i.kind === c.kind); return h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: !AS.excluded.has(c.kind), onChange: (e) => { if (e.target.checked) AS.excluded.delete(c.kind); else AS.excluded.add(c.kind); refresh(); } }),
        c.label, ok ? h('small', { class: 'muted' }, ' · ' + ok.title) : AS.context ? h('small', { class: 'muted' }, ' · ' + t('not available')) : null); }),
      unavailable.length ? h('small', { class: 'muted' }, unavailable.join(' · ')) : null);
  }
  function chatTab() {
    const last = [...AS.messages].reverse().find((m) => m.role === 'assistant');
    const suggested = (last && last.suggested) || ['What are the steps?', 'What is an NTP?', 'Describe this vehicle', 'Why is a vehicle blocked?'];
    const input = h('textarea', { class: 'as-input', rows: 3, 'data-spell': 'on', placeholder: t('Ask about the workflow, a term or the included vehicle…'), 'aria-label': t('Question for the simulated assistant'),
      onKeydown: (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); const v = e.target.value; e.target.value = ''; ask(v); } } });
    return h('div', { class: 'as-chat' },
      contextBox(),
      h('ol', { class: 'as-log', role: 'log', 'aria-live': 'polite', 'aria-label': t('Conversation') },
        AS.messages.length ? AS.messages.map(message) : h('li', { class: 'as-msg is-note' }, h('p', null, t('Ask a question. Answers are scripted from this application’s records and Help; nothing is changed.')))),
      AS.busy ? h('div', { class: 'as-busy', role: 'status' }, h('span', { class: 'ap-skeleton', style: { width: '120px', height: '12px', display: 'inline-block' } }), ' ', t('Working (simulated)…'), ' ', TR.pages.ui.button(t('Cancel'), 'close', cancel, 'text')) : null,
      AS.error ? h('div', { class: 's-banner warning', role: 'alert' }, TR.icon('alert'), h('span', null, AS.error.message), AS.lastQuestion ? TR.pages.ui.button(t('Retry'), 'refresh', () => { AS.messages = AS.messages.filter((m, i) => !(i === AS.messages.length - 1 && m.role === 'user')); ask(AS.lastQuestion); }, 'text') : null) : null,
      h('div', { class: 'as-suggest', role: 'group', 'aria-label': t('Suggested questions') }, suggested.map((q) => h('button', { type: 'button', class: 'tm-chip as-q', onClick: () => ask(q) }, t(q)))),
      h('div', { class: 'as-compose' }, input,
        h('div', { class: 'tm-actions' }, TR.pages.ui.button(t('Send'), 'arrow', () => { const v = input.value; input.value = ''; ask(v); }, 'primary', { disabled: AS.busy }),
          TR.pages.ui.button(t('Clear conversation'), 'trash', () => { clear(); try { sessionStorage.removeItem(key()); } catch (e) { /* none */ } refresh(); }, 'text', { disabled: !AS.messages.length }))));
  }
  function agentTab() {
    const p = AS.plan;
    return h('div', { class: 'as-agent' },
      h('div', { class: 's-banner' }, TR.icon('info'), t('Preview only: the simulated agent proposes a plan and never executes changes, submits requests, approves proposals or contacts external services.')),
      contextBox(),
      h('label', { class: 's-field' }, h('span', null, t('Your goal')), h('textarea', { rows: 2, 'data-spell': 'on', value: AS.goal, placeholder: t('For example: update FH 123456 to the latest service pack'), onInput: (e) => { AS.goal = e.target.value; } })),
      h('div', { class: 'tm-actions' }, TR.pages.ui.button(AS.busy ? t('Planning…') : t('Preview a plan'), 'route', plan, 'primary', { disabled: AS.busy }), AS.busy ? TR.pages.ui.button(t('Cancel'), 'close', cancel, 'text') : null),
      AS.error ? h('div', { class: 's-banner warning', role: 'alert' }, TR.icon('alert'), AS.error.message) : null,
      p ? h('section', { class: 'as-plan', 'aria-label': t('Plan preview') },
        h('p', null, h('strong', null, t('1. Goal')), ' ', p.goal),
        h('h3', null, t('2. Proposed plan')), h('ol', null, p.steps.map((s) => h('li', null, s.text))),
        h('h3', null, t('3. Required context and permissions')), h('ul', { class: 'as-req' }, p.requires.map((r) => h('li', null, r.satisfied ? TR.icon('check', 13) : TR.icon('close', 13), ' ', h('strong', null, t(r.name)), ' · ', h('span', { class: 'nv-sr' }, r.satisfied ? t('available') : t('missing')), t(r.explanation)))),
        h('h3', null, t('4. Proposed actions and expected outcomes')), p.actions.length ? h('ul', { class: 'as-req' }, p.actions.map((a) => h('li', null, h('strong', null, t(a.label)), ' — ', t(a.expectedOutcome), h('small', { class: 'muted' }, ' · ' + t('through: {w}', { w: t(a.requiresWorkflow) }) + ' · ' + t('not executed'))))) : h('p', { class: 'muted' }, t('No actions proposed.')),
        h('p', { class: 'muted' }, t(p.note))) : null);
  }
  function body() {
    const tabs = [F('ai-chat') ? ['chat', 'Chat'] : null, F('ai-agent') ? ['agent', 'Plan (preview)'] : null].filter(Boolean);
    if (!tabs.find(([id]) => id === AS.tab)) AS.tab = tabs[0] ? tabs[0][0] : 'chat';
    return h('div', { class: 'as-panel' },
      h('p', { class: 'as-label', role: 'note' }, TR.icon('flask', 14), t(LABEL)),
      tabs.length > 1 ? h('div', { class: 'tp-seg', role: 'tablist', 'aria-label': t('Assistant') }, tabs.map(([id, l]) => h('button', { type: 'button', role: 'tab', 'aria-selected': String(AS.tab === id), class: AS.tab === id ? 'is-on' : '', onClick: () => { AS.tab = id; AS.error = null; refresh(); } }, t(l)))) : null,
      AS.tab === 'agent' ? agentTab() : chatTab());
  }
  function open() {
    if (AS.panel && !AS.panel.closed) { AS.panel.el.focus(); return; }
    restore();
    AS.panel = TR.ui.panel({ id: 'assistant', title: t('Assistant (simulated)'), width: 440, body, onClose: () => { cancel(); AS.panel = null; } });
    loadContext();
    setTimeout(() => { const i = AS.panel && AS.panel.el.querySelector('.as-input, textarea'); if (i) i.focus(); }, 30);
  }

  // ------------------------------------------------------------------ the entry point (top bar), secondary to the work
  if (TR.pages.addHeaderItem) TR.pages.addHeaderItem(() => (F('ai-chat') || F('ai-agent') ? h('button', { class: 'ap-icon-btn as-open', 'aria-label': t('Open the simulated assistant'), 'data-tip': t('Assistant|Simulated: no AI service connected'), onClick: open }, TR.icon('spark', 18)) : null));

  // ------------------------------------------------------------------ summaries (proposal, validation, activity)
  function summaryCard(kind, id, currentVersion) {
    const s = AS.summaries[kind + ':' + id];
    const run = async () => {
      AS.summaries[kind + ':' + id] = { loading: true }; TR.app.refresh();
      try { const r = await post('/summary', { kind, id }); AS.summaries[kind + ':' + id] = r; TR.announce && TR.announce(t('Simulated summary ready.')); }
      catch (e) { AS.summaries[kind + ':' + id] = { error: e.message }; }
      TR.app.refresh();
    };
    if (!s) return h('div', { class: 'as-sum-entry' }, TR.pages.ui.button(t('Summarize (simulated)'), 'spark', run, 'text'));
    if (s.loading) return h('div', { class: 'as-sum', role: 'status' }, t('Summarizing (simulated)…'));
    if (s.error) return h('div', { class: 'as-sum s-banner warning' }, TR.icon('alert'), s.error, TR.pages.ui.button(t('Retry'), 'refresh', run, 'text'));
    const outdated = currentVersion != null && String(currentVersion) !== String(s.sourceVersion);
    const sections = [['identity', 'What it is'], ['changes', 'Changes'], ['findings', 'Findings'], ['limitations', 'Limitations'], ['next', 'Next steps']];
    return h('section', { class: ['as-sum', outdated ? 'is-outdated' : ''], 'aria-label': t('Simulated summary') },
      h('header', null, h('strong', null, s.title), h('span', { class: 'wf-kind tone-warning' }, TR.icon('flask', 12), t('Simulated summary')),
        h('small', { class: 'muted' }, t('Source {v} · made {at}', { v: s.sourceVersion, at: TR.pages.ui.when(s.generatedAt) })),
        TR.pages.ui.button(t('Summarize again'), 'refresh', run, 'text')),
      outdated ? h('div', { class: 's-banner warning', role: 'status' }, TR.icon('alert'), t('Outdated: the source changed after this summary was made.')) : null,
      sections.map(([sec, label]) => { const list = s.statements.filter((x) => x.section === sec); return list.length ? h('div', { class: 'as-sum-sec' }, h('h4', null, t(label)), h('ul', null, list.map((x) => h('li', null, x.text, x.source ? h('small', { class: 'muted' }, ' · ' + t('from {k} {i}', { k: x.source.kind, i: String(x.source.id).slice(0, 12) })) : null)))) : null; }));
  }
  const baseFrame = TR.testRequest.frame;
  TR.testRequest.frame = (content) => {
    const frame = baseFrame(content);
    if (!F('ai-summaries') || !frame || typeof frame.querySelector !== 'function') return frame;
    const main = frame.querySelector('.s-main');
    if (!main) return frame;
    // The proposal (decision bar), the validation (findings) and Activity.
    const bar = main.querySelector('.wf-bar');
    if (bar && TR.workflow && TR.workflow.W.save.rev) bar.after(summaryCard('proposal', 'workspace', 'rev-' + TR.workflow.W.save.rev));
    const findings = main.querySelector('#wf-findings');
    const latest = TR.backend && TR.backend.latest;
    if (findings && latest && latest.id) findings.after(summaryCard('request', latest.id, String(latest.id).replace(/-/g, '').slice(0, 12)));
    if (TR.pages.current && TR.pages.current() === 'activity') { const head = main.querySelector('.st-head, h1'); if (head) head.after(summaryCard('activity', 'mine', null)); }
    return frame;
  };
  // An account change and sign-out clear every conversation and summary.
  if (TR.avatar) { const changed = TR.avatar.changed, signOut = TR.avatar.signOut; TR.avatar.changed = (...a) => { clear(); return changed(...a); }; TR.avatar.signOut = (...a) => { clear(); return signOut(...a); }; }
  addEventListener('storage', (e) => { if (e.key && e.key.endsWith('.welcomed')) clear(); });

  TR.assistant = { AS, open, ask, cancel, clear, plan, candidates, summaryCard, LABEL };
  TR.app.refresh();
})();
