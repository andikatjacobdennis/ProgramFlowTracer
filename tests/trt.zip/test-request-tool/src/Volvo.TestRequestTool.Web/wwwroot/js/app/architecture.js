/* Vehicle architecture (the Map tab of the Vehicle page): computers, runtimes and installed software of the loaded vehicle.
 *
 *   Architecture   computers grouped by electrical architecture (T3 high-performance computers, TEA2+ computers), each
 *                  with its runtimes (execution environments of its software), packages and configuration items
 *                  (ECU hardware, node template and the other documents). Changed items come from the workspace proposal
 *                  compared with the stored vehicle (POST /api/v1/impact); dependencies from the catalog.
 *   Software impact  opens Change impact for the same proposal.   List   every item in one sortable table.
 *
 * The vehicle data has no network wiring, so the groups are architectures, not buses, and no links are invented.
 * Filters control visibility, never selection. Packages can be selected (Space) and compared; the focused item's details
 * are on the right. Arrow keys move between items, Enter inspects, Space selects. Views can be saved in this browser. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));
  const J = () => TR.journey;
  const TYPES = [['computer', 'Computers'], ['runtime', 'Runtimes'], ['package', 'Packages'], ['config', 'Configuration']];
  const store = (k, d) => { try { return TR.util.store ? TR.util.store.get('trstudio.arch.' + k, d) : d; } catch (e) { return d; } };
  const save = (k, v) => { try { if (TR.util.store) TR.util.store.set('trstudio.arch.' + k, v); } catch (e) { /* blocked */ } };
  const DEFAULT_VIEW = () => ({ types: ['computer', 'runtime', 'package'], archs: ['T3', 'Legacy'], status: ['changed', 'unchanged'], rels: ['contains', 'dependency'], closed: [], configOpen: [] });
  const A = { key: null, impact: null, error: null, tab: 'architecture', view: Object.assign(DEFAULT_VIEW(), store('view', {})), views: store('views', []), viewName: 'Default', q: '', focus: null, picked: new Set(), zoom: 1, comparing: false };

  function workspace() {
    const L = TR.app.shell.left;
    if (!L || !L.product.loaded()) return null;
    const i = L.product.info();
    let product = null; try { product = L.getCurrentSelectedProduct(); } catch (e) { /* none */ }
    return { id: i.chassisSeries + '|' + Number(i.chassisNumber), title: L.product.chassisString(), product, nodes: (product && product.nodes) || L.product.current.nodes };
  }
  async function load(w) {
    A.key = w.id + ':' + (TR.workflow && TR.workflow.W.save ? TR.workflow.W.save.rev : ''); A.error = null;
    try { A.impact = await J().api('/impact', { method: 'POST', body: { vehicleId: w.id, product: w.product } }); } catch (e) { A.error = e.message; }
    TR.app.refresh();
  }

  // ------------------------------------------------------------------ the model (exported for tests)
  /** Items of the architecture: computers, their runtimes, packages and configuration items, with change status. */
  function model(nodes, impact) {
    const byKey = new Map((impact ? impact.modules : []).map((m) => [m.key, m]));
    const keyOf = (n) => { const id = n.nodeIdentifier || {}; return [id.type, id.family, id.position, id.electricalArchitecture].join('.'); };
    const computers = nodes.map((n) => {
      const m = [...byKey.values()].find((x) => x.name === n.name) || byKey.get(keyOf(n)) || {};
      const arch = n.electricalArchitecture === 3 ? 'T3' : 'Legacy';
      const name = (n.nodeIdentifier && n.nodeIdentifier.name) || n.name;
      const comps = m.components || [];
      const packages = (n.softwareProducts || []).map((sw) => {
        const c = comps.find((x) => x.name === (sw.name || sw.softwareProduct)) || {};
        return { type: 'package', id: n.name + '/' + (sw.name || sw.softwareProduct || sw.number), computer: name, name: name + ' ' + (sw.name || sw.softwareProduct || ''), short: sw.name || sw.softwareProduct || String(sw.number),
          version: sw.packageVersion || String(sw.number || ''), from: c.from, to: c.to, runtime: sw.executionEnvironment || null, logicalEcu: sw.logicalEcu || null, status: c.status === 'changed' || c.status === 'added' ? 'changed' : 'unchanged', changes: c.changes || [], arch };
      });
      const runtimes = [...new Set(packages.map((p) => p.runtime).filter(Boolean))].map((r) => ({ type: 'runtime', id: n.name + '/rt/' + r, computer: name, name: r, status: packages.some((p) => p.runtime === r && p.status === 'changed') ? 'changed' : 'unchanged', arch }));
      const config = [['ECU hardware', n.ecuHardware], ['Node template', n.nodeTemplateDocument]].filter(([, x]) => x).map(([label, x]) => ({ type: 'config', id: n.name + '/cfg/' + label, computer: name, name: label, version: String(x.number || '') + (x.fieldNumber ? ' (' + x.fieldNumber + ')' : ''), status: 'unchanged', arch }))
        .concat(Object.entries(n).filter(([k, v]) => v && typeof v === 'object' && !Array.isArray(v) && v.number && !['ecuHardware', 'nodeTemplateDocument', 'nodeIdentifier'].includes(k)).map(([k, v]) => ({ type: 'config', id: n.name + '/cfg/' + k, computer: name, name: k.replace(/([A-Z])/g, ' $1').replace(/^./, (c) => c.toUpperCase()), version: String(v.number), status: 'unchanged', arch })));
      // Legacy computers: when the impact data has their parts (Hardware, Software, Data sets), use them, with their change
      // status: software and data sets (with patches) are packages; ECU hardware, sub-hardware and the node template are
      // configuration. Without that data the generic reading above stays.
      if (!packages.length && Array.isArray(m.parts) && m.parts.length) {
        const st = (x) => (x.status === 'changed' || x.status === 'added' || x.status === 'removed' ? 'changed' : 'unchanged');
        const group = (id) => (m.parts.find((g) => g.id === id) || { children: [] }).children;
        group('g:software').concat(group('g:data').flatMap((d) => [d].concat((d.children || []).map((pt) => Object.assign({}, pt, { name: d.name + ' › ' + pt.name }))))).forEach((x) => packages.push({
          type: 'package', id: n.name + '/' + x.id, computer: name, name: name + ' ' + x.name, short: x.name, kindLabel: x.label, version: String(x.to || x.from || ''), from: x.from, to: x.to, runtime: null, logicalEcu: null,
          status: st(x), changes: x.status === 'unchanged' ? [] : [{ component: name + ' ' + x.label, property: 'Part number', from: x.from || '', to: x.to || '' }], arch }));
        config.length = 0;
        group('g:hardware').forEach((x) => config.push({ type: 'config', id: n.name + '/cfg/' + x.id, computer: name, name: x.label === 'ECU hardware' ? 'ECU hardware' : x.label + ' · ' + x.name, version: String(x.to || x.from || ''), status: st(x), arch }));
        if (n.nodeTemplateDocument) config.push({ type: 'config', id: n.name + '/cfg/Node template', computer: name, name: 'Node template', version: String(n.nodeTemplateDocument.number || ''), status: 'unchanged', arch });
      }
      return { type: 'computer', id: n.name, key: m.key, name, title: n.name, arch, version: n.versionName, from: m.from, to: m.to, status: m.status && m.status !== 'unchanged' && m.status !== 'verified' && m.status !== 'check' ? 'changed' : 'unchanged', check: m.status === 'check' || m.status === 'blocked' || m.status === 'verified' ? m.status : null, runtimes, packages, config };
    });
    return computers;
  }
  const allItems = (computers) => computers.flatMap((c) => [c].concat(c.runtimes, c.packages, c.config));
  function visible(item, view, q) {
    if (!view.types.includes(item.type) || !view.archs.includes(item.arch) || !view.status.includes(item.status)) return false;
    return true;
  }
  const matches = (item, q) => !q || [item.name, item.type, item.version, item.runtime, item.computer].filter(Boolean).join(' ').toLowerCase().includes(q.toLowerCase());

  // ------------------------------------------------------------------ pieces
  function checkbox(list, value, label, count) {
    const on = A.view[list].includes(value);
    return h('label', null, h('input', { type: 'checkbox', checked: on, onChange: (e) => { A.view[list] = e.target.checked ? A.view[list].concat(value) : A.view[list].filter((x) => x !== value); save('view', A.view); TR.app.refresh(); } }), t(label) + (count != null ? ` (${count})` : ''));
  }
  function filters(items) {
    const n = (f) => items.filter(f).length;
    const section = (title, kids) => h('details', { open: true }, h('summary', null, t(title), TR.icon('chevron', 14)), kids);
    return h('aside', { class: 'va-filters', 'aria-label': t('Filters') },
      h('h2', null, t('Filters'), h('button', { class: 'jr-link', onClick: () => { A.view = DEFAULT_VIEW(); save('view', A.view); TR.app.refresh(); } }, t('Clear all'))),
      section('Component types', TYPES.map(([k, l]) => checkbox('types', k, l, n((i) => i.type === k)))),
      section('Electrical architecture', [checkbox('archs', 'T3', 'T3 high-performance computers', n((i) => i.type === 'computer' && i.arch === 'T3')), checkbox('archs', 'Legacy', 'TEA2+ computers', n((i) => i.type === 'computer' && i.arch === 'Legacy'))]),
      section('Change status', [checkbox('status', 'changed', 'Changed', n((i) => i.status === 'changed')), checkbox('status', 'unchanged', 'Unchanged', n((i) => i.status === 'unchanged'))]),
      section('Relationships', [checkbox('rels', 'contains', 'Contains'), checkbox('rels', 'dependency', 'Catalog dependencies', A.impact ? A.impact.edges.length : 0)]),
      J().banner('info', 'info', t('Filters control visibility, not selection.')),
      h('p', { class: 'muted jr-small' }, t('Showing {a} of {b} items', { a: items.filter((i) => visible(i, A.view)).length, b: items.length })));
  }
  function focusItem(id) { A.focus = id; TR.app.refresh(); setTimeout(() => { const el = document.querySelector('[data-item="' + CSS.escape(id) + '"]'); if (el) el.focus(); }, 0); }
  function keys(e, id, order) {
    const i = order.indexOf(id);
    if (e.key === 'ArrowDown' || e.key === 'ArrowRight') { e.preventDefault(); if (order[i + 1]) focusItem(order[i + 1]); }
    else if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') { e.preventDefault(); if (order[i - 1]) focusItem(order[i - 1]); }
    else if (e.key === ' ' && id.includes('/') && !id.includes('/rt/') && !id.includes('/cfg/')) { e.preventDefault(); if (A.picked.has(id)) A.picked.delete(id); else A.picked.add(id); TR.app.refresh(); }
  }
  function itemButton(item, order, icon, extra) {
    const dim = A.q && !matches(item, A.q);
    return h('div', { class: ['va-item', A.focus === item.id ? 'is-focus' : '', dim ? 'is-dim' : ''], 'data-item': item.id, tabindex: A.focus === item.id || (!A.focus && order[0] === item.id) ? '0' : '-1', role: 'button',
      'aria-label': t('{n}, {v}, {s}', { n: item.name, v: item.version || '', s: t(item.status === 'changed' ? 'Changed' : 'Unchanged') }), onClick: () => { A.focus = item.id; TR.app.refresh(); }, onKeydown: (e) => { if (e.key === 'Enter') { A.focus = item.id; TR.app.refresh(); } else keys(e, item.id, order); } },
      extra, TR.icon(icon, 16), h('span', null, item.short || item.name, item.version ? ' ' + (item.from && item.to && item.from !== item.to ? item.to : item.version) : ''), item.status === 'changed' ? J().chip('changed') : null);
  }
  function computerCard(c, order) {
    const pk = c.packages.filter((p) => visible(p, A.view)), rt = c.runtimes.filter((r) => visible(r, A.view)), cf = c.config.filter((x) => visible(x, A.view));
    const cfgOpen = A.view.configOpen.includes(c.id);
    return h('article', { class: ['va-computer', c.status === 'changed' ? 'is-changed' : ''], 'aria-label': c.title },
      h('header', null, h('span', { 'aria-hidden': 'true', class: 'ci-icon' }, TR.icon(c.arch === 'T3' ? 'chip' : 'cpu', 20)),
        h('span', null, h('button', { class: 'jr-link', 'data-item': c.id, tabindex: A.focus === c.id ? '0' : '-1', onClick: () => { A.focus = c.id; TR.app.refresh(); }, onKeydown: (e) => keys(e, c.id, order) }, h('strong', null, c.name)), h('small', null, c.title + ' · ' + (c.from && c.to && c.from !== c.to ? c.from + ' → ' + c.to : c.version || ''))),
        c.status === 'changed' ? J().chip('changed') : c.check ? J().chip(c.check) : null),
      A.view.types.includes('runtime') ? [h('p', { class: 'va-sub' }, TR.icon('chevron', 12), t('Runtimes ({n})', { n: rt.length })), rt.length ? rt.map((r) => itemButton(r, order, 'settings')) : h('p', { class: 'muted jr-small' }, t(c.packages.some((p) => p.runtime) ? 'Hidden by the filters.' : 'No runtime in the data (legacy software).'))] : null,
      A.view.types.includes('package') ? [h('p', { class: 'va-sub' }, TR.icon('chevron', 12), t('Packages ({n})', { n: pk.length })), pk.map((p) => itemButton(p, order, 'package',
        h('input', { type: 'checkbox', checked: A.picked.has(p.id), 'aria-label': t('Select {n}', { n: p.name }), onClick: (e) => e.stopPropagation(), onChange: (e) => { if (e.target.checked) A.picked.add(p.id); else A.picked.delete(p.id); TR.app.refresh(); } })))] : null,
      A.view.types.includes('config') && c.config.length ? (cfgOpen ? [h('p', { class: 'va-sub' }, TR.icon('chevron', 12), t('Configuration ({n})', { n: cf.length })), cf.map((x) => itemButton(x, order, 'file'))]
        : h('button', { class: 'va-more', onClick: () => { A.view.configOpen = A.view.configOpen.concat(c.id); TR.app.refresh(); } }, TR.icon('plus', 14), t('{n} configuration items', { n: c.config.length }))) : null);
  }
  function architecture(computers, order) {
    const groups = [['T3', 'T3 high-performance computers'], ['Legacy', 'TEA2+ computers']].filter(([a]) => A.view.archs.includes(a)).map(([a, label]) => [a, label, computers.filter((c) => c.arch === a && (visible(c, A.view) || c.packages.some((p) => visible(p, A.view))))]).filter(([, , list]) => list.length);
    return h('div', { class: 'va-canvas' }, h('div', { class: 'va-zoomer', style: { transform: 'scale(' + A.zoom + ')' } },
      h('div', { class: 'va-vehicle' }, TR.icon('truck', 22), h('span', null, h('strong', null, workspace().title), h('br'), h('small', { class: 'muted' }, t('Vehicle')))),
      groups.length ? h('div', { class: 'va-groups' }, groups.map(([a, label, list]) => {
        const closed = A.view.closed.includes(a);
        return h('section', { class: ['va-group', 'arch-' + a.toLowerCase(), closed ? 'is-closed' : ''], 'aria-label': t(label) },
          h('header', null, h('button', { 'aria-expanded': String(!closed), 'aria-label': t(closed ? 'Expand {g}' : 'Collapse {g}', { g: t(label) }), onClick: () => { A.view.closed = closed ? A.view.closed.filter((x) => x !== a) : A.view.closed.concat(a); save('view', A.view); TR.app.refresh(); } }, TR.icon('chevron', 16)),
            TR.icon('grid', 18), h('strong', null, t(label)), h('span', { class: 'muted' }, '· ' + t('{n} computers', { n: list.length }))),
          closed ? null : h('div', { class: 'va-computers' }, list.map((c) => computerCard(c, order))));
      })) : J().empty('Nothing to show', 'Change the filters.'),
      A.view.rels.includes('dependency') && A.impact && A.impact.edges.length ? h('ul', { class: 'jr-list va-deps', 'aria-label': t('Catalog dependencies') }, A.impact.edges.map((e) => h('li', null, TR.icon('route', 13), ' ', e.rule, ' · ', J().chip(e.state)))) : null));
  }
  function list(items) {
    const shown = items.filter((i) => visible(i, A.view) && matches(i, A.q));
    return h('div', { class: 'jr-table-wrap va-list' }, h('table', { class: 'jr-table' },
      h('thead', null, h('tr', null, ['Type', 'Name', 'Computer', 'Runtime', 'Version', 'Status'].map((c) => h('th', null, t(c))))),
      h('tbody', null, shown.map((i) => h('tr', { class: A.focus === i.id ? 'is-sel' : '', onClick: () => { A.focus = i.id; TR.app.refresh(); } },
        h('td', null, t((TYPES.find((x) => x[0] === i.type) || [])[1] || i.type)), h('td', null, i.name), h('td', null, i.computer || i.name), h('td', null, i.runtime || '—'),
        h('td', null, h('code', null, i.from && i.to && i.from !== i.to ? i.from + ' → ' + i.to : i.version || '—')), h('td', null, J().chip(i.status)))))));
  }
  function details(items) {
    const i = items.find((x) => x.id === A.focus);
    const picked = items.filter((x) => A.picked.has(x.id));
    const v = A.impact && A.impact.validation;
    if (A.comparing && picked.length) return h('aside', { class: 'va-details', 'aria-label': t('Compare selected') },
      h('h2', null, t('Compare selected'), h('button', { class: 'ap-icon-btn', 'aria-label': t('Close comparison'), onClick: () => { A.comparing = false; TR.app.refresh(); } }, TR.icon('close', 16))),
      h('div', { class: 'jr-table-wrap' }, h('table', { class: 'jr-table' }, h('thead', null, h('tr', null, ['Package', 'Runtime', 'The vehicle now', 'Your change'].map((c) => h('th', null, t(c))))),
        h('tbody', null, picked.map((p) => h('tr', null, h('td', null, p.name), h('td', null, p.runtime || '—'), h('td', null, p.from || p.version), h('td', { class: p.status === 'changed' ? 'jr-proposed' : '' }, p.to || p.version)))))));
    if (!i) return h('aside', { class: 'va-details' }, h('h2', null, t('Details')), h('p', { class: 'muted' }, t('Choose a computer, runtime or package.')));
    const comp = items.find((x) => x.type === 'computer' && (x.name === i.computer || x.id === i.id));
    const deps = A.impact ? A.impact.edges.filter((e) => comp && (e.from === comp.key || e.to === comp.key)) : [];
    return h('aside', { class: 'va-details', 'aria-label': t('Details') },
      h('h2', null, t(i.type === 'package' ? 'Package details' : i.type === 'computer' ? 'Computer details' : i.type === 'runtime' ? 'Runtime details' : 'Item details'), h('button', { class: 'ap-icon-btn', 'aria-label': t('Close details'), onClick: () => { A.focus = null; TR.app.refresh(); } }, TR.icon('close', 16))),
      h('div', { class: 'jr-side-title' }, h('strong', { class: 'jr-big' }, i.name), J().chip(i.status)),
      J().facts([['Computer', comp ? comp.name : i.computer], i.runtime !== undefined ? ['Runtime', i.runtime || t('None in the data')] : null, i.logicalEcu ? ['Logical ECU', i.logicalEcu] : null,
        ['Original version', i.from || i.version], ['Proposed version', i.to || i.version]]),
      picked.length ? [h('h3', null, t('Selection')), J().banner('info', 'info', t('{n} package(s) selected. Details show the focused item.', { n: picked.length }))] : null,
      h('h3', null, t('Validation')), v ? J().banner(v.current ? (v.blocking ? 'warning' : 'good') : 'warning', v.current ? (v.blocking ? 'alert' : 'check') : 'alert', v.current ? t(v.blocking ? '{n} blocking finding(s) in the validation of this proposal.' : 'Validated: this proposal passed, {a}.', { n: v.blocking, a: J().ago(v.at) }) : t('The vehicle changed after validation.'))
        : J().banner('warning', 'alert', t('Not yet validated.')),
      h('h3', null, t('Relationships')),
      h('ul', { class: 'jr-list' }, i.type === 'package' && i.runtime ? h('li', null, t('Runs in {r}', { r: i.runtime })) : null, i.type !== 'computer' ? h('li', null, t('Contained in {c}', { c: i.computer })) : null,
        deps.map((e) => h('li', null, e.rule, ' · ', J().chip(e.state))), !deps.length && i.type === 'computer' ? h('li', { class: 'muted' }, t('No catalog dependency touches a change.')) : null),
      i.changes && i.changes.length ? [h('h3', null, t('Change information')), h('ul', { class: 'jr-list' }, i.changes.map((c) => h('li', null, t(c.property) + ': ', h('code', null, (c.from || '—') + ' → ' + (c.to || '—')))))] : null,
      h('div', { class: 'jr-stack' },
        TR.pages.ui.button(t(i.type === 'package' ? 'Edit package' : 'Open software editor'), 'pencil', () => { if (TR.experience) TR.experience.page = null; TR.testRequest.page('software'); }, 'primary'),
        TR.pages.ui.button(t('Compare original'), 'compare', () => J().open('impact', { vid: workspace().id }), 'secondary')));
  }

  function render() {
    const w = workspace();
    if (!w) return J().empty('No vehicle loaded', 'Load a vehicle to explore its computers, runtimes and software.');
    const key = w.id + ':' + (TR.workflow && TR.workflow.W.save ? TR.workflow.W.save.rev : '');
    if (key !== A.key) load(w);
    const computers = model(w.nodes, A.impact), items = allItems(computers);
    const order = items.filter((i) => visible(i, A.view) || i.type === 'computer').map((i) => i.id);
    const viewMenu = J().select('Saved view', A.viewName, [['Default', 'Default']].concat(A.views.map((v) => [v.name, v.name])).concat([['__save', 'Save current view…']]), (v) => {
      if (v === '__save') { const name = typeof prompt === 'function' ? null : null; const n = 'View ' + (A.views.length + 1); A.views = A.views.filter((x) => x.name !== n).concat({ name: n, view: JSON.parse(JSON.stringify(A.view)) }); save('views', A.views); A.viewName = n; TR.notify && TR.notify.toast(t('Saved as {n}.', { n }), 'success'); }
      else { A.viewName = v; A.view = v === 'Default' ? DEFAULT_VIEW() : JSON.parse(JSON.stringify((A.views.find((x) => x.name === v) || {}).view || DEFAULT_VIEW())); save('view', A.view); }
      TR.app.refresh();
    });
    return h('div', { class: 'va-page' },
      h('div', { class: 'jr-head' }, h('div', null, h('h2', { class: 'jr-title2' }, t('Vehicle architecture')), h('p', { class: 'jr-sub' }, t('Explore computers, runtimes and installed software.'))),
        h('div', { class: 'jr-actions' }, J().search('Find any component (name, type, version…)', A.q, (v) => { A.q = v; J().later(() => TR.app.refresh(), 150); }, { id: 'va-search' }), viewMenu,
          TR.pages.ui.button(t('Reset view'), 'undo', () => { A.view = DEFAULT_VIEW(); A.viewName = 'Default'; A.q = ''; A.zoom = 1; A.picked.clear(); save('view', A.view); TR.app.refresh(); }, 'secondary'),
          TR.pages.ui.button(t('Open proposal'), 'file', () => { if (TR.experience) TR.experience.page = null; TR.testRequest.page(); }, 'primary'))),
      h('div', { class: 'jr-meta' }, h('strong', null, w.title), h('span', null, computers.some((c) => c.arch === 'T3') ? 'T3' : 'Legacy'), TR.workflow && TR.workflow.W.save.rev ? h('span', null, t('Proposal revision {n}', { n: TR.workflow.W.save.rev })) : null,
        A.impact ? h('span', null, t('{n} change(s)', { n: A.impact.counts.changes })) : null, h('span', { class: 'muted' }, t('Grouped by electrical architecture'))),
      A.error ? J().failed(A.error, () => load(w)) : null,
      h('div', { class: 'va-layout' }, filters(items),
        h('section', { class: 'va-main' },
          h('div', { class: 'jr-tabs', role: 'tablist', 'aria-label': t('View') }, [['architecture', 'Architecture'], ['impact', 'Software impact'], ['list', 'List']].map(([k, l]) =>
            h('button', { role: 'tab', 'aria-selected': String(A.tab === k), class: A.tab === k ? 'is-on' : '', onClick: () => { if (k === 'impact') J().open('impact', { vid: w.id }); else { A.tab = k; TR.app.refresh(); } } }, t(l)))),
          A.picked.size ? h('div', { class: 'va-selbar' }, h('span', { class: 'jr-pill tone-info' }, TR.icon('check', 14), t('{n} packages selected', { n: A.picked.size })),
            TR.pages.ui.button(t('Compare selected'), 'compare', () => { A.comparing = true; TR.app.refresh(); }, 'secondary'), h('button', { class: 'jr-link', onClick: () => { A.picked.clear(); A.comparing = false; TR.app.refresh(); } }, t('Clear selection'))) : null,
          A.tab === 'list' ? list(items) : architecture(computers, order),
          h('div', { class: 'va-foot' },
            h('div', { class: 'jr-legend' }, h('span', null, h('i', { class: 'ln-solid' }), t('Contains')), h('span', null, h('i', { class: 'ln-dashed' }), t('Catalog dependency')), h('span', null, J().chip('changed'))),
            h('div', { class: 'ci-zoom', role: 'group', 'aria-label': t('Zoom') }, h('button', { class: 'ap-icon-btn', 'aria-label': t('Zoom out'), onClick: () => { A.zoom = Math.max(0.5, Math.round((A.zoom - 0.1) * 10) / 10); TR.app.refresh(); } }, '−'),
              h('span', { class: 'ci-zoom-v' }, Math.round(A.zoom * 100) + '%'), h('button', { class: 'ap-icon-btn', 'aria-label': t('Zoom in'), onClick: () => { A.zoom = Math.min(1.5, Math.round((A.zoom + 0.1) * 10) / 10); TR.app.refresh(); } }, '+'),
              TR.pages.ui.button(t('Fit'), null, () => { A.zoom = 1; TR.app.refresh(); }, 'secondary')))),
        details(items)),
      h('div', { class: 'jr-foot muted' }, h('span', null, t('The vehicle data has no network wiring: computers are grouped by electrical architecture, and only catalog dependencies are drawn.')), h('span', { class: 'spacer' }), h('span', null, t('Arrow keys: move · Enter: inspect · Space: select focused package'))));
  }
  TR.architecture = { A, render, model, allItems, visible };
})();
