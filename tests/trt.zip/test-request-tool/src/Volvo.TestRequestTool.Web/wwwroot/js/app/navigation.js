/* Navigation with four display modes and an independent auto-hide preference.
 *
 *   Menu bar  (desktop default) one horizontal bar above the page: each section (Discover, Workspace, Vehicles, Tools,
 *             Reports, Administration, More) is a drop-down menu, so the page keeps the full width. ARIA menubar keys:
 *             Left and Right move between sections, Down, Enter or Space open one, Up and Down move in it, Home and End
 *             jump, Escape closes it and returns focus. The Layout menu at the end switches to the sidebar modes.
 *   Expanded  a sidebar with icons and labels.
 *   Compact   icons only, in the layout. Every item names itself in a tooltip on hover and on keyboard focus, and keeps its
 *             full accessible name. Groups that hold several items (Vehicles, Tools, Administration, More) open as
 *             labelled flyouts.
 *   Hidden    removed from the layout. The Menu button (always in the top bar) opens it as a temporary drawer with icons
 *             and labels.
 *   Mobile    (900 px and narrower) always a drawer, closed until the Menu button opens it.
 *
 *   Auto-hide (on by default, its own preference): a drawer closes after you navigate; on desktop it also closes once both
 *   the pointer and keyboard focus have left it. It never closes while a flyout, a panel, a dialog or a press inside the
 *   navigation is in progress. With auto-hide off, a drawer stays until Menu, Escape or the backdrop closes it.
 *
 *   Menu button: Expanded ↔ Compact on desktop (saved), opens and closes the drawer in Hidden mode and on mobile.
 *   Escape closes a flyout (focus returns to its trigger), then the drawer (focus returns to the Menu button).
 *
 * Mode and auto-hide are saved per signed-in user on the server (/api/v1/me/preferences, the same on every device) and in
 * this browser under the user's own key for an instant first paint. Settings → Workspace → Navigation also has "Reset
 * navigation preferences". Switching modes only re-renders the frame: the page, unsaved edits and scroll position stay.
 *
 * Every original navigation item is kept: its button (and click behaviour) is moved into the new structure. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));
  const S = TR.testRequest, X = TR.experience;
  const MODES = ['menubar', 'expanded', 'compact', 'hidden'];
  const MOBILE = '(max-width: 900px)';

  // ------------------------------------------------------------------ pure rules (unit-tested in tests/frontend/navigation.cjs)
  const logic = {
    /** Expert tools in the menus: 'on' / 'off' as chosen, else (Auto) for administrators only. Pure. */
    expertOn: (setting, role) => setting === 'on' || (setting !== 'off' && role === 'Admin'),
    MODES,
    defaults: () => ({ mode: 'menubar', autoHide: true }),
    /** A saved value, cleaned: unknown modes and types fall back to the defaults. */
    clean(v) {
      const d = logic.defaults();
      return { mode: v && MODES.includes(v.mode) ? v.mode : d.mode, autoHide: v && typeof v.autoHide === 'boolean' ? v.autoHide : d.autoHide };
    },
    /** What is shown: 'drawer' on mobile, otherwise the saved mode. */
    effective: (prefs, mobile) => (mobile ? 'drawer' : prefs.mode),
    /** Labels visible: expanded, or a drawer that is open. Drives aria-expanded on the Menu button. */
    labelsVisible: (prefs, mobile, drawerOpen) => (['expanded', 'menubar'].includes(logic.effective(prefs, mobile)) || ((logic.effective(prefs, mobile) === 'hidden' || mobile) && drawerOpen)),
    /** The Menu button: Expanded ↔ Compact on desktop; open or close the drawer in Hidden mode and on mobile. */
    menu(prefs, mobile, drawerOpen) {
      // Menu bar: the Menu button opens the full navigation as a drawer (everything at once), and closes it again.
      if (mobile || prefs.mode === 'hidden' || prefs.mode === 'menubar') return { prefs, drawerOpen: !drawerOpen };
      return { prefs: Object.assign({}, prefs, { mode: prefs.mode === 'expanded' ? 'compact' : 'expanded' }), drawerOpen: false };
    },
    /** Close a drawer after navigating? Only with auto-hide (a drawer exists only in Hidden mode and on mobile). */
    closeAfterNavigation: (prefs, mobile, drawerOpen) => drawerOpen && prefs.autoHide && (mobile || prefs.mode === 'hidden' || prefs.mode === 'menubar'),
    /** Close a drawer because pointer and focus have both left it (desktop only, never during an interaction). */
    closeOnLeave(s) {
      if (!s.drawerOpen || !s.autoHide || s.mobile) return false;
      if (s.pointerInside || s.focusInside || s.flyoutOpen || s.overlayOpen || s.pressing) return false;
      return true;
    },
    /** The browser cache key: per user, so two people on one browser never share navigation preferences. */
    key: (userId) => 'trstudio.' + (userId || 'anonymous') + '.navigation',
  };

  // ------------------------------------------------------------------ state
  const userId = () => (TR.backend && TR.backend.session && TR.backend.session.userId) || 'anonymous';
  const isMobile = () => typeof matchMedia === 'function' && matchMedia(MOBILE).matches;
  const N = { prefs: null, drawer: false, flyout: null, groups: null, pressing: false, synced: false, loadedFor: null };
  function prefs() {
    if (!N.prefs || N.loadedFor !== userId()) { N.prefs = logic.clean(TR.util.store.get(logic.key(userId()), null)); N.loadedFor = userId(); N.groups = TR.util.store.get(logic.key(userId()) + '.groups', {}) || {}; N.synced = false; migrate(); }
    return N.prefs;
  }
  /** Once per user: the old default (the Expanded sidebar) becomes the menu bar, the new default. Later choices are kept. */
  function migrate() {
    const mark = logic.key(userId()) + '.menubar';
    if (TR.util.store.get(mark, false)) return;
    TR.util.store.set(mark, true);
    N.migrated = true;
    if (N.prefs.mode === 'expanded') { N.prefs = Object.assign({}, N.prefs, { mode: 'menubar' }); TR.util.store.set(logic.key(userId()), N.prefs); clearTimeout(saveTimer); saveTimer = setTimeout(() => send(N.prefs), 300); }
  }
  let saveTimer = null;
  function setPrefs(next, opts = {}) {
    N.prefs = logic.clean(next);
    TR.util.store.set(logic.key(userId()), N.prefs);
    if (!opts.local) { clearTimeout(saveTimer); saveTimer = setTimeout(() => send(N.prefs), 300); }
    TR.app.refresh();
  }
  async function send(p) {
    try { await fetch('/api/v1/me/preferences/navigation', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(p) }); } catch (e) { /* kept locally; sent with the next change */ }
  }
  /** Server copy wins once per session (another device may have changed it). */
  async function sync() {
    if (N.synced || typeof fetch !== 'function' || typeof location === 'undefined' || !/^https?:$/.test(location.protocol)) return;
    N.synced = true;
    try {
      const r = await fetch('/api/v1/me/preferences', { headers: { Accept: 'application/json' } });
      if (!r.ok) return;
      const body = await r.json();
      if (body && body.navigation) { const p = logic.clean(body.navigation); if (N.migrated && p.mode === 'expanded') { N.migrated = false; send(prefs()); return; } if (p.mode !== prefs().mode || p.autoHide !== prefs().autoHide) setPrefs(p, { local: true }); }
    } catch (e) { /* offline: the browser copy stays */ }
  }
  async function reset() {
    TR.util.store.set(logic.key(userId()), null);
    TR.util.store.set(logic.key(userId()) + '.groups', {});
    N.prefs = logic.defaults(); N.groups = {}; N.drawer = false; N.flyout = null;
    try { await fetch('/api/v1/me/preferences/navigation', { method: 'DELETE' }); } catch (e) { /* local reset still applies */ }
    TR.app.refresh();
    TR.notify && TR.notify.toast(t('Navigation preferences reset.'), 'success');
  }
  const groupOpen = (id, fallback) => (N.groups && id in N.groups ? N.groups[id] : fallback);
  const setGroup = (id, open) => { N.groups[id] = open; TR.util.store.set(logic.key(userId()) + '.groups', N.groups); TR.app.refresh(); };
  const overlayOpen = () => typeof document.querySelector === 'function' && !!document.querySelector('#overlays .overlay, .ap-panel, .tr-layer, .wl-layer, .pl-layer');

  // ------------------------------------------------------------------ building the navigation from the existing sidebar
  const slug = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'more';
  const textOf = (el) => (el.textContent || '').replace(/\s+/g, ' ').trim();
  /** Groups shown as flyouts in Compact mode (they hold several items or more than buttons). */
  const NESTED = new Set(['vehicles', 'tools', 'administration', 'more', 'reports', 'expert', 'help', 'admin']);
  const GROUP_ICON = { vehicles: 'truck', tools: 'wrench', administration: 'lock', more: 'settings', reports: 'chart', requests: 'file', expert: 'wrench', help: 'help', admin: 'lock' };

  /** Wraps a button's text in a label span (hidden in Compact, still its accessible name) and gives it a tooltip. */
  function prepare(btn, label) {
    btn.removeAttribute('title');
    btn.classList.add('nv-item');
    if (!btn.querySelector('.nv-label')) {
      const texts = [...btn.childNodes].filter((n) => n.nodeType === 3 || (n.nodeType === 1 && n.tagName === 'SPAN' && !n.classList.contains('s-chip')));
      const span = h('span', { class: 'nv-label' });
      texts.forEach((n) => span.appendChild(n));
      btn.appendChild(span);
    }
    if (prefs().mode === 'compact') btn.setAttribute('data-tip', label); else btn.removeAttribute('data-tip');
    if (btn.classList.contains('selected') && !btn.hasAttribute('aria-current')) btn.setAttribute('aria-current', 'page');
    return btn;
  }
  function adminItems(current) {
    const session = (TR.backend && TR.backend.session) || {};
    if (!session.isAdmin) return [];
    const items = [['health', 'Service health', 'pulse'], ['logs', 'Logs', 'file'], ['connections', 'Connections', 'globe'], ['teams', 'Teams', 'people'], ['usage', 'Usage study', 'chart'], ['features', 'Feature flags', 'sliders'], ['data', 'Data and services', 'layers']].filter(([id]) => TR.pages.get(id) && (!TR.features || TR.features.on({ health: 'service-health', logs: 'logs-viewer', teams: 'teams', usage: 'usage-study' }[id] || '-')));
    const made = items.map(([id, label, icon]) => h('button', { class: 's-nav', 'aria-current': current === id ? 'page' : null, onClick: () => TR.pages.show(id) }, TR.icon(icon), label));
    made.push(h('a', { class: 's-nav', href: '/swagger', target: '_blank', rel: 'noopener' }, TR.icon('code'), t('API (Swagger)')));
    return made;
  }
  /** Reads the original sidebar into groups: { id, label, items: [button], extras: [node] }. */
  function model(rail) {
    const groups = [], current = TR.pages.current ? TR.pages.current() : null;
    const take = (section, label) => {
      const id = slug(label);
      const g = { id, label, items: [], extras: [] };
      [...section.children].forEach((el) => {
        if (el.matches && el.matches('.s-eyebrow, .s-rail-label')) return;
        if (el.matches && el.matches('button.s-nav, button.s-btn, a.s-nav')) g.items.push(prepare(el, textOf(el)));
        else g.extras.push(el);
      });
      return g;
    };
    [...rail.children].forEach((section) => {
      const head = section.querySelector && section.querySelector(':scope > .s-eyebrow, :scope > .s-rail-label');
      const label = head ? textOf(head.cloneNode(true)).replace(/\d+$/, '').trim() : 'More';
      groups.push(take(section, label.charAt(0) + label.slice(1).toLowerCase()));
    });
    // Administration: the new admin pages plus the existing "Admin users" and "Service status" items, in one group.
    const admin = { id: 'administration', label: 'Administration', items: adminItems(current).map((b) => prepare(b, textOf(b))), extras: [] };
    for (const g of groups) g.items = g.items.filter((b) => { const l = textOf(b); if (l === 'Admin users' || (l === 'Service status' && admin.items.length)) { admin.items.splice(1, 0, b); return false; } return true; });
    if (admin.items.length) groups.splice(Math.max(1, groups.length - 1), 0, admin);
    // Batch runs sit with the other workspace tools.
    const work = groups.find((g) => g.items.some((b) => textOf(b) === 'Two-pane workbench'));
    if (work && TR.pages.get('batch')) work.items.push(prepare(h('button', { class: 's-nav', 'aria-current': current === 'batch' ? 'page' : null, onClick: () => TR.pages.show('batch') }, TR.icon('layers'), t('Batch runs')), t('Batch runs')));
    // The request journey: Requests with the workspace, Fleet readiness and Change impact with the vehicles, and the reports
    // (Engineering insights; Logs for people who are not administrators, scoped to their own records). Hidden when off.
    const page = (id, label, icon) => {
      if (!TR.pages.get(id) || (TR.features && TR.features.flagOf && TR.features.flagOf(id) && !TR.features.on(TR.features.flagOf(id)))) return null;
      return prepare(h('button', { class: 's-nav', 'aria-current': current === id ? 'page' : null, onClick: () => { if (TR.journey) TR.journey.open(id); else TR.pages.show(id); } }, TR.icon(icon), t(label)), t(label));
    };
    if (work) { const r = page('requests', 'Requests', 'file'); if (r) work.items.splice(1, 0, r); }
    // Listener requests: every message type of the request listener, after Batch runs.
    if (work) { const l = page('listener', 'Listener requests', 'code'); if (l) work.items.push(l); }
    const vehiclesGroup = groups.find((g) => g.id === 'vehicles');
    if (vehiclesGroup) [page('readiness', 'Fleet readiness', 'check'), page('impact', 'Change impact', 'graph')].filter(Boolean).forEach((b) => vehiclesGroup.items.push(b));
    const reports = { id: 'reports', label: 'Reports', items: [page('engineering', 'Engineering insights', 'chart'), !((TR.backend && TR.backend.session) || {}).isAdmin ? page('logs', 'Logs & diagnostics', 'file') : null].filter(Boolean), extras: [] };
    if (reports.items.length) groups.splice(groups.findIndex((g) => g.id === 'administration') >= 0 ? groups.findIndex((g) => g.id === 'administration') : Math.max(1, groups.length - 1), 0, reports);
    // Mark the current page: items already marked, or the page registry's current page.
    groups.forEach((g) => { g.current = g.items.some((b) => b.getAttribute('aria-current') === 'page'); });
    return groups.filter((g) => g.items.length || g.extras.length);
  }

  // ------------------------------------------------------------------ rendering
  function modeSwitch(p) {
    const items = [['menubar', 'Menu bar', 'One bar above the page; the page keeps the full width'], ['expanded', 'Expanded', 'Icons and labels'], ['compact', 'Compact', 'Icons only, names on hover and focus'], ['hidden', 'Hidden', 'Out of the way; Menu brings it back']];
    return h('div', { class: 'nv-modes', role: 'group', 'aria-label': t('Navigation display') },
      items.map(([m, label, tip]) => h('button', { type: 'button', class: ['nv-mode', p.mode === m ? 'is-on' : ''], 'aria-pressed': String(p.mode === m), 'aria-label': t(label), 'data-tip': t(label) + '|' + t(tip), onClick: () => { N.drawer = false; setPrefs(Object.assign({}, p, { mode: m })); } },
        TR.icon(m === 'menubar' ? 'sliders' : m === 'expanded' ? 'expand' : m === 'compact' ? 'grid' : 'close', 15), h('span', { class: 'nv-label' }, t(label)))));
  }

  // ------------------------------------------------------------------ the menu bar
  const MB_ICON = { discover: 'grid', workspace: 'file', requests: 'file', vehicles: 'truck', tools: 'wrench', expert: 'wrench', reports: 'chart', administration: 'lock', more: 'settings', help: 'help', admin: 'lock' };
  function mbFocus(selector) { focusSoon(selector); }
  /**
   * The main sections from the sidebar groups, keeping every destination:
   *   Requests      Home (what needs you, recent requests, the Activity log), the workspace, Requests, Batch runs,
   *                 Listener requests, Campaigns
   *   Vehicles      Vehicle, Saved vehicles, Add vehicle, Fleet readiness, Change impact and the fleet Dashboard
   *   Expert tools  the two-pane workbench, VCADS, Compare breakdown, Server calls, History, Logs and Engineering insights;
   *                 shown when expert tools are on (logic.expertOn), and always while you are on one of them
   *   Help          Help, the UI guide and Getting started; Service status; Settings, About, feedback and the
   *                 Show / Hide expert tools switch
   *   Administration its own menu, present only for administrators
   * With expert tools off their pages stay reachable: Help → Show expert tools, Settings → Expert tools, and in-page links.
   */
  const EXPERT = /^(Two-pane workbench|VCADS request|Compare breakdown|Server calls|History|Logs|Logs & diagnostics|Engineering insights)$/;
  function sections(groups) {
    const by = Object.fromEntries(groups.map((g) => [g.id, g]));
    const take = (g, test) => { if (!g) return []; const out = g.items.filter((b) => test(textOf(b))); g.items = g.items.filter((b) => !out.includes(b)); return out; };
    const discover = by.discover;
    const more = by.more || { id: 'more', label: 'More', items: [], extras: [] };
    const session = (TR.backend && TR.backend.session) || {};
    const isCurrent = (b) => b.getAttribute('aria-current') === 'page';
    // Expert tools, from every group; Logs once (administrators have Logs, others Logs & diagnostics).
    const expertItems = [].concat(...groups.map((g) => take(g, (l) => EXPERT.test(l))));
    // The expert page you are on, if any: its menu stays visible (and marked current) even with expert tools off.
    const cur = TR.pages.current ? TR.pages.current() : null, app = TR.app || {};
    const here = { calls: 'Server calls', history: 'History', engineering: 'Engineering insights', logs: /^Logs/ }[cur]
      || (app.page === 'vcads' ? 'VCADS request' : app.page === 'compare' ? 'Compare breakdown' : TR.testRequest && TR.testRequest.view === 'expert' && app.page === 'testrequest' && !TR.pages.get(cur) ? 'Two-pane workbench' : null);
    expertItems.forEach((b) => { const l = textOf(b); if (here && (here instanceof RegExp ? here.test(l) : here === l)) b.setAttribute('aria-current', 'page'); });
    const expertShown = logic.expertOn(TR.prefs ? TR.prefs.get('expertTools') : 'auto', session.role) || expertItems.some(isCurrent);
    const extra = (label, icon, run, note) => prepare(h('button', { class: 's-nav', onClick: run }, TR.icon(icon), t(label), note ? h('span', { class: 'mb-tag' }, t(note)) : null), t(label));
    const requests = { id: 'requests', label: 'Requests', extras: by.workspace ? by.workspace.extras : [],
      items: take(discover, (l) => /^Home$/.test(l)).concat(by.workspace ? by.workspace.items : [], by.tools ? take(by.tools, () => true) : [], by.reports ? take(by.reports, () => true) : []) };
    const vehicles = by.vehicles || { id: 'vehicles', label: 'Vehicles', items: [], extras: [] };
    vehicles.items = take(discover, (l) => /^(Vehicle|Vehicle map|Saved vehicles)$/.test(l)).concat(vehicles.items, take(discover, (l) => l === 'Dashboard'));
    // Activity lives on Home and on Requests (Activity log): not a menu of its own any more.
    take(discover, (l) => l === 'Activity');
    // Help: Help, the UI guide and Getting started (the original items, so nothing is duplicated).
    const helpItems = take(discover, () => true).concat(take(more, (l) => /^(Help|UI guide|Getting started)$/.test(l)));
    if (!helpItems.length) helpItems.push(extra('Help & UI guide', 'book', () => (TR.uiGuide ? TR.uiGuide.open() : window.open('/guide/', '_blank', 'noopener'))));
    const adminLabels = by.administration ? by.administration.items.map(textOf) : [];
    // Service status: the existing item (Discover has it for some roles) moves out of Help into its own slot; a new one is
    // added only when no group has it, so it is never listed twice.
    const isService = (b) => /^Service (status|health)$/.test(textOf(b));
    const service = helpItems.filter(isService);
    helpItems.splice(0, helpItems.length, ...helpItems.filter((b) => !isService(b)));
    const elsewhere = adminLabels.concat(...groups.map((g) => g.items.map(textOf))).some((l) => /^Service (status|health)$/.test(l));
    if (!service.length && !elsewhere && TR.pages.get('health')) service.push(extra('Service status', 'pulse', () => TR.pages.show('health')));
    // "Service status" opens the Service health page: left out of the menu when both are there (the destination stays).
    const labels = new Set(groups.flatMap((g) => g.items.map(textOf)));
    const admin = (by.administration ? by.administration.items : []).filter((b) => !(textOf(b) === 'Service status' && labels.has('Service health')));
    const toggle = TR.prefs ? extra(expertShown ? 'Hide expert tools' : 'Show expert tools', 'wrench', () => TR.prefs.set('expertTools', expertShown ? 'off' : 'on')) : null;
    const help = { id: 'help', label: 'Help', extras: more.extras, items: [] };
    help.sub = [['Help', helpItems], ['', service], ['', more.items.concat(toggle ? [toggle] : [])]].filter(([, list]) => list.length);
    help.items = [].concat(...help.sub.map(([, l]) => l));
    const expert = expertShown && expertItems.length ? { id: 'expert', label: 'Expert tools', items: expertItems, extras: [] } : null;
    const workCurrent = !!(by.workspace && by.workspace.current) || !!(discover && discover.current && requests.items.some(isCurrent));
    // Administration has a menu of its own, for administrators only (it was a part of Help).
    const administration = admin.length ? { id: 'admin', label: 'Administration', items: admin, extras: [] } : null;
    return [requests, vehicles, expert, administration, help].filter((g) => g && (g.items.length || g.extras.length))
      .map((g) => Object.assign(g, { current: g.items.some(isCurrent) || (g.id === 'requests' && workCurrent) || (g.id === 'vehicles' && !!g.current) }));
  }
  function menuBar(groups, p) {
    groups = sections(groups);
    const tops = groups.map((g) => g.id);
    const openMenu = (id, which) => { TR.pages.closeHeaderMenus?.('navigation'); N.flyout = id; TR.app.refresh(); mbFocus(`#mb-${id} [role="menuitem"]${which === 'last' ? ':last-of-type' : ''}, #mb-${id} [role="menuitemradio"]`); };
    const topKeys = (e, id) => {
      const i = tops.indexOf(id);
      const go = (j) => { const next = tops[(j + tops.length) % tops.length]; if (N.flyout) { N.flyout = next; TR.app.refresh(); } mbFocus(`[data-mb="${next}"]`); };
      if (e.key === 'ArrowRight') { e.preventDefault(); go(i + 1); }
      else if (e.key === 'ArrowLeft') { e.preventDefault(); go(i - 1); }
      else if (e.key === 'Home') { e.preventDefault(); go(0); }
      else if (e.key === 'End') { e.preventDefault(); go(tops.length - 1); }
      else if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openMenu(id); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); openMenu(id, 'last'); }
    };
    const menuKeys = (e, id) => {
      const items = [...e.currentTarget.querySelectorAll('[role="menuitem"], [role="menuitemradio"]')];
      const i = items.indexOf(document.activeElement);
      if (e.key === 'ArrowDown') { e.preventDefault(); (items[i + 1] || items[0]).focus(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); (items[i - 1] || items[items.length - 1]).focus(); }
      else if (e.key === 'Home') { e.preventDefault(); items[0].focus(); }
      else if (e.key === 'End') { e.preventDefault(); items[items.length - 1].focus(); }
      else if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') { e.preventDefault(); const j = tops.indexOf(id) + (e.key === 'ArrowRight' ? 1 : -1); const next = tops[(j + tops.length) % tops.length]; openMenu(next); }
      else if (e.key === 'Tab') { N.flyout = null; TR.app.refresh(); }
    };
    const top = (id, label, icon, current, menuBody) => {
      const open = N.flyout === id;
      return h('li', { class: ['mb-item', current ? 'is-current' : '', open ? 'is-open' : ''], role: 'none' },
        h('button', { type: 'button', role: 'menuitem', class: 'mb-top', 'data-mb': id, 'aria-haspopup': 'menu', 'aria-expanded': String(open), 'aria-controls': 'mb-' + id,
          tabindex: (N.flyout ? open : tops[0] === id) ? '0' : '-1', 'aria-current': current ? 'true' : null,
          onClick: (e) => { e.stopPropagation(); if (open) { N.flyout = null; TR.app.refresh(); } else openMenu(id); }, onKeydown: (e) => topKeys(e, id) },
          TR.icon(icon, 16), h('span', null, t(label)), current ? h('span', { class: 'nv-sr' }, ' ' + t('(current section)')) : null, TR.icon('chevron', 12)),
        open ? h('div', { id: 'mb-' + id, class: 'mb-menu', role: 'menu', 'aria-label': t(label), onKeydown: (e) => menuKeys(e, id) }, menuBody) : null);
    };
    const itemsOf = (g) => {
      g.items.forEach((b) => { b.setAttribute('role', 'menuitem'); b.setAttribute('tabindex', '-1'); });
      const body = g.sub ? g.sub.map(([title, list], i) => h('div', { class: ['mb-group', i ? 'mb-sep' : ''], role: 'group', 'aria-label': title ? t(title) : null }, title ? h('p', { class: 'mb-note', role: 'presentation' }, t(title)) : null, list))
        : g.items.length ? [h('div', { class: 'mb-group', role: 'group' }, g.items)] : [];
      return body.concat(g.extras.length ? h('div', { class: 'mb-extras' }, g.extras) : null);
    };
    return h('nav', { id: 'studio-navigation', class: ['nv', 'nv-menubar'], 'aria-label': t('Main navigation'),
      onClick: (e) => { const item = e.target.closest && e.target.closest('.mb-menu .nv-item, .mb-menu .s-vehicle, .mb-menu a'); if (item && N.flyout) { N.flyout = null; setTimeout(() => TR.app.refresh(), 0); } } },
      h('ul', { class: 'mb-bar', role: 'menubar', 'aria-label': t('Main navigation') }, groups.map((g) => top(g.id, g.label, MB_ICON[g.id] || GROUP_ICON[g.id] || 'grid', g.current, itemsOf(g)))));
  }
  function groupBlock(g, compactView) {
    const listId = 'nv-' + g.id;
    const heading = h('span', { class: 'nv-heading-text' }, t(g.label), g.current ? h('span', { class: 'nv-sr' }, ' ' + t('(current section)')) : null);
    if (compactView && NESTED.has(g.id)) {
      const open = N.flyout === g.id;
      const trigger = h('button', { type: 'button', class: ['nv-item', 'nv-flyout-trigger', g.current ? 'has-current' : ''], 'aria-haspopup': 'true', 'aria-expanded': String(open), 'aria-controls': listId + '-fly', 'data-tip': t(g.label) + (g.current ? '|' + t('Current section') : ''),
        onClick: (e) => { e.stopPropagation(); N.flyout = open ? null : g.id; TR.app.refresh(); if (!open) focusSoon('#' + listId + '-fly .nv-item, #' + listId + '-fly button, #' + listId + '-fly a'); },
        onKeydown: (e) => { if (e.key === 'ArrowRight' && !open) { e.preventDefault(); e.currentTarget.click(); } } },
        TR.icon(GROUP_ICON[g.id] || 'grid'), h('span', { class: 'nv-label' }, t(g.label)), g.id === 'vehicles' && g.extras.some((x) => x.classList && x.classList.contains('s-vehicle-row')) ? h('span', { class: 'nv-badge', 'aria-hidden': 'true' }, String(g.extras.filter((x) => x.classList && x.classList.contains('s-vehicle-row')).length)) : null);
      const fly = open ? h('div', { id: listId + '-fly', class: 'nv-flyout', role: 'group', 'aria-label': t(g.label), onKeydown: (e) => { if (e.key === 'ArrowLeft') { e.preventDefault(); closeFlyout(true); } } },
        h('h2', { class: 'nv-flyout-title' }, t(g.label)), h('ul', { class: 'nv-list', role: 'list' }, g.items.map((b) => h('li', null, b))), g.extras) : null;
      return h('section', { class: ['nv-group', 'is-nested', g.current ? 'has-current' : ''], 'aria-label': t(g.label) }, trigger, fly);
    }
    if (compactView) return h('section', { class: ['nv-group', g.current ? 'has-current' : ''], 'aria-label': t(g.label) }, h('ul', { class: 'nv-list', role: 'list' }, g.items.map((b) => h('li', null, b))));
    const open = groupOpen(g.id, g.current || !['tools', 'administration', 'expert'].includes(g.id));
    return h('section', { class: ['nv-group', g.current ? 'has-current' : ''], 'aria-labelledby': listId + '-h' },
      h('h2', { class: 'nv-heading' }, h('button', { id: listId + '-h', type: 'button', class: 'nv-group-toggle', 'aria-expanded': String(open), 'aria-controls': listId, onClick: () => setGroup(g.id, !open) },
        g.current ? h('i', { class: 'nv-current-dot', 'aria-hidden': 'true' }) : null, heading, TR.icon('chevron', 14))),
      h('div', { id: listId, class: 'nv-group-body', hidden: !open }, g.items.length ? h('ul', { class: 'nv-list', role: 'list' }, g.items.map((b) => h('li', null, b))) : null, g.extras));
  }
  function focusSoon(selector) { setTimeout(() => { const el = document.querySelector(selector); if (el) el.focus(); }, 0); }
  function closeFlyout(returnFocus) {
    const id = N.flyout;
    if (!id) return false;
    N.flyout = null; TR.app.refresh();
    if (returnFocus) focusSoon(`[aria-controls="nv-${id}-fly"], [data-mb="${id}"]`);
    return true;
  }
  function closeDrawer(returnFocus) {
    if (!N.drawer) return false;
    N.drawer = false; N.flyout = null; TR.app.refresh();
    if (returnFocus) focusSoon('.ux-menu');
    return true;
  }
  function openDrawer() {
    TR.pages.closeHeaderMenus?.('navigation');
    N.drawer = true; TR.app.refresh();
    focusSoon('#studio-navigation [aria-current="page"], #studio-navigation .nv-item');
  }

  // Auto-hide on desktop: pointer and focus both outside, checked shortly after either leaves.
  let leaveTimer = null;
  function maybeLeave(nav) {
    clearTimeout(leaveTimer);
    leaveTimer = setTimeout(() => {
      const state = { drawerOpen: N.drawer, autoHide: prefs().autoHide, mobile: isMobile(), pointerInside: nav.matches(':hover'), focusInside: nav.contains(document.activeElement),
        flyoutOpen: !!N.flyout, overlayOpen: overlayOpen(), pressing: N.pressing };
      if (logic.closeOnLeave(state)) closeDrawer(false);
    }, 350);
  }

  const baseFrame = S.frame;
  S.frame = (content) => {
    const frame = baseFrame(content);
    const rail = frame && typeof frame.querySelector === 'function' ? frame.querySelector('.s-sidebar') : null;
    if (!rail) return frame;
    sync();
    const p = prefs(), mobile = isMobile();
    // Menu bar with the Menu button pressed: the full navigation as a drawer, like Hidden mode.
    const view = logic.effective(p, mobile) === 'menubar' && N.drawer ? 'hidden' : logic.effective(p, mobile);
    if (view === 'menubar') {
      frame.classList.remove('ux-nav-open', 'ux-nav-hidden');
      frame.classList.add('nv-layout', 'nv-layout-menubar');
      const bar = menuBar(model(rail), p);
      rail.remove();
      const slot = typeof document.querySelector === 'function' ? document.querySelector('#app > .s-topbar .hd-nav-slot') : null;
      if (slot) { slot.replaceChildren(bar); frame.classList.add('nv-in-header'); }
      else { const main = frame.querySelector('.s-main'); if (main) main.insertBefore(bar, main.firstChild); else frame.insertBefore(bar, frame.firstChild); }
      return frame;
    }
    const drawer = view === 'drawer' || view === 'hidden';
    const compactView = view === 'compact';
    frame.classList.remove('ux-nav-open', 'ux-nav-hidden');
    frame.classList.add('nv-layout', 'nv-layout-' + view, N.drawer ? 'nv-drawer-open' : 'nv-drawer-closed');
    const groups = sections(model(rail));
    const nav = h('nav', { id: 'studio-navigation', class: ['s-sidebar', 'nv', 'nv-' + view, drawer ? (N.drawer ? 'is-open' : 'is-closed') : ''], 'aria-label': t('Main navigation'), 'data-scroll': 'studio-sidebar',
      hidden: drawer && !N.drawer ? true : null,
      onPointerdown: () => { N.pressing = true; }, onPointerup: () => { N.pressing = false; },
      onClick: (e) => {
        const item = e.target.closest && e.target.closest('.nv-item:not(.nv-flyout-trigger), .s-vehicle');
        if (!item) return;
        // After navigating: close a flyout; close the drawer when auto-hide says so (focus goes to the page).
        if (N.flyout) N.flyout = null;
        if (logic.closeAfterNavigation(p, mobile, N.drawer)) { N.drawer = false; setTimeout(() => { TR.app.refresh(); const main = document.querySelector('.s-main'); if (main) main.focus({ preventScroll: true }); }, 0); }
      } },
      h('div', { class: 'nv-top' }, mobile ? null : modeSwitch(p), drawer ? h('button', { type: 'button', class: 'ap-icon-btn nv-close', 'aria-label': t('Close navigation'), 'data-tip': t('Close navigation') + '|Esc', onClick: () => closeDrawer(true) }, '✕') : null),
      h('div', { class: 'nv-scroll' }, groups.map((g) => groupBlock(g, compactView))));
    nav.addEventListener('pointerleave', () => maybeLeave(nav));
    nav.addEventListener('focusout', () => maybeLeave(nav));
    nav.addEventListener('pointerenter', () => clearTimeout(leaveTimer));
    rail.replaceWith(nav);
    if (drawer && N.drawer) nav.after(h('div', { class: 'nv-scrim', 'aria-hidden': 'true', onClick: () => closeDrawer(true) }));
    return frame;
  };

  // The Menu button: always present, named for what it does, aria-expanded = labels visible, aria-controls = the navigation.
  const baseHeader = S.header;
  S.header = () => {
    const header = baseHeader();
    const old = header.querySelector && header.querySelector('.ux-menu');
    const p = prefs(), mobile = isMobile();
    const expanded = logic.labelsVisible(p, mobile, N.drawer);
    const label = mobile || p.mode === 'hidden' || p.mode === 'menubar' ? (N.drawer ? t('Close navigation') : t('Open navigation')) : (p.mode === 'expanded' ? t('Collapse navigation to icons') : t('Expand navigation'));
    const menu = h('button', { type: 'button', class: 's-btn ux-menu', 'aria-label': label, 'aria-controls': 'studio-navigation', 'aria-expanded': String(expanded), 'data-tip': label,
      onClick: (e) => {
        e.stopPropagation();
        const r = logic.menu(prefs(), isMobile(), N.drawer);
        if (r.prefs !== prefs()) setPrefs(r.prefs);
        if (r.drawerOpen && !N.drawer) openDrawer(); else if (!r.drawerOpen && N.drawer) closeDrawer(true);
      } }, TR.icon('grid', 18), h('span', { class: 'nv-menu-text' }, t('Menu')));
    if (old) old.replaceWith(menu); else if (header.firstChild) header.insertBefore(menu, header.firstChild);
    return header;
  };

  // Escape: a flyout first, then a drawer. Clicks outside close a flyout.
  if (typeof document.addEventListener === 'function') {
    document.addEventListener('keydown', (e) => {
      if (e.key !== 'Escape' || e.defaultPrevented) return;
      if (closeFlyout(true) || closeDrawer(true)) e.preventDefault();
    }, true);
    document.addEventListener('click', (e) => { if (N.flyout && !(e.target.closest && e.target.closest('.nv-group.is-nested, .mb-item'))) closeFlyout(false); });
  }
  // Changing between mobile and desktop width re-renders with the right presentation; a mobile drawer starts closed.
  if (typeof matchMedia === 'function') { const mq = matchMedia(MOBILE); const on = () => { N.drawer = false; N.flyout = null; TR.app.refresh(); }; if (mq.addEventListener) mq.addEventListener('change', on); }

  TR.navigation = { logic, N, prefs, setPrefs, reset, open: openDrawer, close: closeDrawer, setMode: (m) => { N.flyout = null; N.drawer = false; setPrefs(Object.assign({}, prefs(), { mode: m })); } };
  // Older code and Settings call these.
  if (TR.polish) { TR.polish.navigationOpen = () => prefs().mode !== 'hidden'; TR.polish.setNavigation = (v) => setPrefs(Object.assign({}, prefs(), { mode: v ? 'expanded' : 'hidden' })); }
})();
