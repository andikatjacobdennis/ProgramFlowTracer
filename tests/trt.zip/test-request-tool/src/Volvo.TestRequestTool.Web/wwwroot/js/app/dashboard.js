/* Dashboard: the whole fleet you can read, at a glance. One server call (/api/v1/fleet) summarises every vehicle; the page
 * adds your own request outcomes and three small, explainable machine-learning views (ml.js, all in the browser):
 *
 *   Groups      – k-means clusters vehicles by share up to date, updates waiting and time since the last change
 *   Unusual     – z-scores flag vehicles far from the rest (for example, years without a change)
 *   Trend       – a least-squares line through monthly activity, with next month's forecast
 *
 * Also: headline numbers, needs attention, release pipeline, service packs, request outcomes, fleet activity calendar,
 * people and a searchable, sortable, paged list of every vehicle. */
(function () {
  'use strict';
  const { h } = TR.util;
  const { ui } = TR.pages;
  const t = (s, v) => TR.i18n.t(s, v);
  const D = { data: null, loading: false, error: null, loadedAt: null, list: { query: '', sort: 'share', page: 1 } };
  const DAY = 86400000;

  async function load(force) {
    if (D.loading || (D.data && !force)) return;
    D.loading = true; D.error = null; TR.app.refresh();
    try {
      const [fleet, requests] = await Promise.all([ui.api('/fleet' + (force ? '?refresh=true' : '')), allRequests()]);
      D.data = summarise(fleet, requests);
      D.loadedAt = new Date();
    } catch (e) { D.error = e.message; }
    D.loading = false;
    TR.app.refresh();
  }
  async function allRequests() {
    const out = [];
    for (let skip = 0; skip < 2000; skip += 100) { const page = await ui.api(`/requests?skip=${skip}&take=100`); out.push(...page); if (page.length < 100) break; }
    return out;
  }

  // ------------------------------------------------------------------ numbers (pure, tested)
  const share = (r) => (r.counts.total ? r.counts.current / r.counts.total : 1);
  function outcome(r) {
    const os = r.outcomes || [];
    if (!os.length) return 'Result only';
    if (os.some((o) => (o.issues || []).some((i) => i.severity === 0 || i.severity === 'Error'))) return 'Blocked';
    return os.some((o) => o.limitedValidation) ? 'Limited validation' : 'Ready';
  }
  /** fleet: the /fleet response. requests: your requests. */
  function summarise(fleet, requests, now = new Date()) {
    const rows = fleet.rows || [];
    const sum = (f) => rows.reduce((s, r) => s + f(r), 0);
    const computers = sum((r) => r.counts.total), current = sum((r) => r.counts.current);
    const outcomes = { Ready: 0, 'Limited validation': 0, Blocked: 0, 'Result only': 0 };
    requests.forEach((r) => { outcomes[outcome(r)]++; });
    const days = Object.assign({}, fleet.days || {});
    for (const r of requests) { const k = new Date(r.createdAt).toISOString().slice(0, 10); days[k] = (days[k] || 0) + 1; }
    const attention = rows.map((r) => ({ r, score: r.waiting * 2 + r.counts.blocked + r.counts.update })).filter((x) => x.score > 0).sort((a, b) => b.score - a.score);
    return {
      now, rows, vehicles: rows.length, entries: fleet.entries || 0, t3: rows.filter((r) => r.t3).length,
      computers, current, update: sum((r) => r.counts.update), blocked: sum((r) => r.counts.blocked), waiting: sum((r) => r.waiting),
      upToDate: computers ? Math.round(100 * current / computers) : 0,
      simulations: requests.length, ready: outcomes.Ready, readyRate: requests.length ? Math.round(100 * outcomes.Ready / requests.length) : 0,
      commits: fleet.commits || 0, commits90: fleet.commits90 || 0,
      attention, pipeline: fleet.pipeline || {}, packs: fleet.packs || [], outcomes, days, people: fleet.people || [],
      groups: groups(rows), unusual: unusual(rows), trend: trend(days, now),
    };
  }
  /** k-means on [share up to date, updates waiting, years since the last change], named by their centres. */
  function groups(rows) {
    if (rows.length < 3) return [];
    const raw = rows.map((r) => [share(r), r.waiting, Math.min(r.daysSinceChange ?? 0, 3650) / 365]);
    const { labels, centroids } = TR.ml.kmeans(TR.ml.scale(raw), 3);
    const health = centroids.map((c) => c[0] - c[1] - c[2] * 0.5);
    const order = health.map((x, i) => i).sort((a, b) => health[b] - health[a]);
    const names = [['Healthy', 'Mostly up to date and recently changed.', 'good'], ['Needs updates', 'A few updates waiting.', 'info'], ['Falling behind', 'Many updates waiting or no change for a long time.', 'warn']];
    return order.map((g, rank) => {
      const members = rows.filter((_, i) => labels[i] === g);
      const avg = (f) => members.reduce((s, r) => s + f(r), 0) / Math.max(1, members.length);
      return { name: names[rank][0], text: names[rank][1], tone: names[rank][2], count: members.length, share: Math.round(100 * avg(share)), waiting: avg((r) => r.waiting), years: avg((r) => (r.daysSinceChange ?? 0) / 365), members };
    }).filter((g) => g.count);
  }
  /** Vehicles more than two standard deviations from the fleet on waiting updates or time since the last change. */
  function unusual(rows) {
    if (rows.length < 5) return [];
    const zw = TR.ml.zscores(rows.map((r) => r.waiting)), zd = TR.ml.zscores(rows.map((r) => r.daysSinceChange ?? 0));
    return rows.map((r, i) => ({ r, z: Math.max(zw[i], zd[i]), why: zw[i] >= zd[i] ? 'waiting' : 'stale' })).filter((x) => x.z > 2).sort((a, b) => b.z - a.z).slice(0, 6);
  }
  /** Monthly event counts for the last 12 months, a least-squares line through them and next month's forecast. */
  function trend(days, now) {
    const months = [];
    for (let i = 11; i >= 0; i--) { const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - i, 1)); months.push({ key: d.toISOString().slice(0, 7), date: d, count: 0 }); }
    const index = Object.fromEntries(months.map((m, i) => [m.key, i]));
    for (const [day, n] of Object.entries(days)) { const i = index[day.slice(0, 7)]; if (i != null) months[i].count += n; }
    const fit = TR.ml.linear(months.map((m, i) => [i, m.count]));
    const forecast = Math.max(0, Math.round(fit.at(months.length)));
    const avg = months.reduce((s, m) => s + m.count, 0) / months.length || 1;
    return { months, fit, forecast, change: fit.slope / avg, direction: Math.abs(fit.slope / avg) < 0.03 ? 'steady' : fit.slope > 0 ? 'rising' : 'falling' };
  }

  // ------------------------------------------------------------------ drawing
  const openVehicle = (r, tab) => async () => { const L = TR.app.shell.left; Object.assign(L.src, { series: r.series, number: r.number }); await L.loadFromSource(false); TR.pages.show('vehicle'); if (TR.vehiclePage) { TR.vehiclePage.V.tab = tab || 'insights'; TR.app.refresh(); } };
  function kpi(icon, value, label, note, tone = '') {
    return h('div', { class: 'db-kpi ' + tone }, h('span', { class: 'db-kpi-icon' }, TR.icon(icon, 20)), h('div', null, h('strong', { class: 'db-kpi-value' }, value), h('span', { class: 'db-kpi-label' }, label), note ? h('small', null, note) : null));
  }
  function stack(c) {
    const total = Math.max(1, c.total);
    return h('span', { class: 'db-stack', 'data-tip': t('{c} up to date · {u} update available · {b} blocked', { c: c.current, u: c.update, b: c.blocked }) },
      [['current', 'var(--added)'], ['update', 'var(--lane-0)'], ['blocked', 'var(--replaced)']].map(([k, colour]) => (c[k] ? h('i', { style: { width: (100 * c[k] / total) + '%', background: colour } }) : null)));
  }
  const ORDER = ['Released', 'Introduced', 'Pre-release verification', 'In progress'];
  const COLOUR = { Released: 'var(--added)', Introduced: 'var(--lane-0)', 'Pre-release verification': 'var(--replaced)', 'In progress': 'var(--muted)' };
  function pipeline(d) {
    const max = Math.max(1, ...ORDER.map((s) => (d.pipeline[s] || { total: 0 }).total));
    return h('ol', { class: 'db-funnel' }, ORDER.map((s, i) => {
      const p = d.pipeline[s] || { total: 0, blocked: 0 };
      return h('li', null, h('span', { class: 'db-funnel-name' }, t(s)),
        h('span', { class: 'db-funnel-track' }, h('span', { class: 'db-funnel-bar', style: { width: Math.max(4, 100 * p.total / max) + '%', background: COLOUR[s], animationDelay: i * 90 + 'ms' } },
          p.blocked ? h('span', { class: 'db-funnel-blocked', style: { width: (100 * p.blocked / Math.max(1, p.total)) + '%' } }) : null)),
        h('strong', null, String(p.total)), h('small', null, p.blocked ? t('{n} blocked', { n: p.blocked }) : ''));
    }));
  }
  function ring(segments, total, big, small, label) {
    const R = 54, SW = 16, Cf = 2 * Math.PI * R, svg = TR.insights.svg;
    const g = svg('svg', { class: 'in-ring', viewBox: '0 0 150 150', role: 'img', 'aria-label': label }, [svg('circle', { cx: 75, cy: 75, r: R, class: 'in-ring-track', 'stroke-width': SW, fill: 'none' })]);
    let off = 0;
    for (const [n, c, tip] of segments) { if (!n) continue; const len = Cf * n / Math.max(1, total); g.appendChild(svg('circle', { cx: 75, cy: 75, r: R, fill: 'none', stroke: c, 'stroke-width': SW, 'stroke-dasharray': `${len} ${Cf - len}`, 'stroke-dashoffset': -off, transform: 'rotate(-90 75 75)', class: 'in-ring-seg' }, [svg('title', {}, [tip])])); off += len; }
    g.appendChild(svg('text', { x: 75, y: 72, class: 'in-ring-big', 'text-anchor': 'middle' }, [big]));
    g.appendChild(svg('text', { x: 75, y: 92, class: 'in-ring-small', 'text-anchor': 'middle' }, [small]));
    return g;
  }
  function outcomesRing(d) {
    const segs = [['Ready', 'var(--added)'], ['Limited validation', 'var(--replaced)'], ['Blocked', 'var(--removed)'], ['Result only', 'var(--muted)']];
    return h('div', { class: 'in-ring-wrap' }, ring(segs.map(([k, c]) => [d.outcomes[k], c, `${d.outcomes[k]} ${t(k)}`]), d.simulations, d.simulations ? d.readyRate + '%' : '–', t('ready'), t('{r} of {n} requests were ready', { r: d.ready, n: d.simulations })),
      h('ul', { class: 'in-ring-legend' }, segs.map(([k, c]) => h('li', null, h('i', { style: { background: c } }), `${d.outcomes[k]} ${t(k)}`))));
  }
  function trendChart(tr) {
    const svg = TR.insights.svg, W = 520, H = 150, P = 26, max = Math.max(1, ...tr.months.map((m) => m.count), tr.forecast);
    const x = (i) => P + i * ((W - P * 2) / tr.months.length), y = (v) => H - P - (H - P * 2) * (v / max);
    const g = svg('svg', { class: 'db-trend', viewBox: `0 0 ${W} ${H}`, role: 'img', 'aria-label': t('Activity per month with a trend line') });
    tr.months.forEach((m, i) => {
      g.appendChild(svg('rect', { x: x(i) + 3, y: y(m.count), width: (W - P * 2) / tr.months.length - 6, height: Math.max(1, H - P - y(m.count)), rx: 3, class: 'db-trend-bar', style: `animation-delay:${i * 40}ms` }, [svg('title', {}, [`${m.key}: ${m.count}`])]));
      if (i % 2 === 0) g.appendChild(svg('text', { x: x(i) + 4, y: H - 8, class: 'in-axis small' }, [m.key.slice(2)]));
    });
    const w = (W - P * 2) / tr.months.length;
    g.appendChild(svg('line', { x1: x(0) + w / 2, y1: y(tr.fit.at(0)), x2: x(tr.months.length) + w / 2, y2: y(tr.fit.at(tr.months.length)), class: 'db-trend-line' }));
    g.appendChild(svg('circle', { cx: x(tr.months.length) + w / 2, cy: y(tr.forecast), r: 5, class: 'db-trend-forecast' }, [svg('title', {}, [t('Forecast for next month: {n}', { n: tr.forecast })])]));
    return g;
  }
  function vehicleList(d) {
    const L = D.list, q = L.query.trim().toLowerCase();
    const sorters = { share: (a, b) => share(a) - share(b), waiting: (a, b) => b.waiting - a.waiting, stale: (a, b) => (b.daysSinceChange ?? 0) - (a.daysSinceChange ?? 0), name: (a, b) => a.label.localeCompare(b.label) };
    const list = d.rows.filter((r) => !q || `${r.label} ${r.model} ${r.country}`.toLowerCase().includes(q)).sort(sorters[L.sort] || sorters.share);
    const size = Number(TR.prefs.get('pageSize'));
    const { rows, page } = TR.pager.slice(list, L.page, size);
    return h('section', { class: 'in-panel' },
      h('div', { class: 'in-panel-head' }, h('h2', null, t('All vehicles')), h('p', null, t('Search, sort and open any vehicle. The bar shows its computers: green up to date, blue update available, amber blocked.'))),
      h('div', { class: 'vh-toolbar' },
        h('label', { class: 's-search vh-search db-search' }, TR.icon('search', 17), h('input', { type: 'search', placeholder: t('Chassis, model or country'), 'aria-label': t('Search vehicles'), value: L.query, key: 'db-search', onInput: (e) => { L.query = e.target.value; L.page = 1; TR.app.refreshSoon(); } })),
        h('label', null, t('Sort') + ' ', h('select', { value: L.sort, onChange: (e) => { L.sort = e.target.value; L.page = 1; TR.app.refresh(); } },
          [['share', 'Least up to date first'], ['waiting', 'Most updates waiting'], ['stale', 'Longest without a change'], ['name', 'Chassis']].map(([v, l]) => h('option', { value: v, selected: L.sort === v }, t(l))))),
        h('span', { class: 'muted', role: 'status' }, t('{n} of {total} vehicles', { n: list.length, total: d.rows.length }))),
      h('ol', { class: 'db-attention' }, rows.map((r) => h('li', null,
        h('div', { class: 'db-att-main' }, h('strong', null, TR.culture.flag(r.country, 16), ' ', r.label), h('small', null, `${r.model} · ${r.t3 ? 'T3' : t('Legacy')}`)), stack(r.counts),
        h('span', { class: 'db-att-note' }, r.waiting ? t('{n} waiting', { n: r.waiting }) : `${Math.round(100 * share(r))}%`), ui.button(t('Open'), 'arrow', openVehicle(r), 'text')))),
      TR.pager({ total: list.length, page, size, label: 'vehicles', onPage: (n) => { L.page = n; TR.app.refresh(); }, onSize: (n) => TR.prefs.set('pageSize', n) }));
  }
  function ashaSays(d) {
    if (!d.vehicles) return t('There are no vehicles you can read yet.');
    // What can be done first: how many computers can be updated (and how many are blocked), not a bare percentage.
    const worst = d.attention[0], parts = [d.update ? t('{u} of {c} computers across {v} vehicles can be updated now; {b} are blocked.', { u: d.update.toLocaleString(), c: d.computers.toLocaleString(), v: d.vehicles, b: d.blocked.toLocaleString() }) : t('{p}% of {c} computers across {v} vehicles are up to date.', { p: d.upToDate, c: d.computers, v: d.vehicles })];
    if (worst) parts.push(t('{vehicle} needs the most attention.', { vehicle: worst.r.label }));
    parts.push(t('Activity is {dir}: about {n} events next month.', { dir: t(d.trend.direction), n: d.trend.forecast }));
    return parts.join(' ');
  }

  function render() {
    load();
    const head = ui.heading(t('Dashboard'), t('Every vehicle you can read, at a glance: how current the software is, what is waiting and what happened.'),
      ui.button(D.loading ? t('Refreshing…') : t('Refresh'), 'refresh', () => load(true), 'secondary', { disabled: D.loading }));
    if (D.error) return h('div', { class: 'db-page' }, head, h('div', { class: 's-banner warning' }, TR.icon('alert'), t('Could not load the dashboard: {error}', { error: D.error })));
    if (!D.data) return h('div', { class: 'db-page' }, head, h('div', { class: 'db-loading' }, TR.help ? TR.help.guide(t('I am reading every vehicle’s history and roadmap for you…'), 'think', 120) : null, h('ol', { class: 'gh-graph' }, TR.historyGraph.skeleton(4))));
    const d = D.data;
    return h('div', { class: 'db-page' }, head,
      h('section', { class: 'db-hero' },
        h('div', { class: 'db-kpis' },
          kpi('truck', String(d.vehicles), t('vehicles'), t('{t3} T3 · {legacy} legacy', { t3: d.t3, legacy: d.vehicles - d.t3 })),
          kpi('chip', String(d.computers), t('computers'), d.current ? t('{n} on their newest version', { n: d.current }) : t('none on its newest version yet')),
          // The headline is what can be done: computers that can be updated now. Up to date is the detail line.
          d.update ? kpi('check', d.update.toLocaleString(), t('can update now'), t('{b} blocked · {p}% up to date', { b: d.blocked.toLocaleString(), p: d.upToDate }), 'info')
            : kpi('check', d.upToDate + '%', t('up to date'), t('{b} blocked', { b: d.blocked }), d.upToDate >= 80 ? 'good' : d.upToDate >= 40 ? 'info' : 'warn'),
          kpi('clock', String(d.waiting), t('updates waiting'), t('available but not installed'), d.waiting ? 'warn' : 'good'),
          kpi('history', d.entries.toLocaleString(), t('history entries'), t('{n} VDA changes in 90 days', { n: d.commits90 })),
          kpi('flask', String(d.simulations), t('requests run'), d.simulations ? t('{n}% ready', { n: d.readyRate }) : t('none yet'))),
        TR.help ? TR.help.guide(ashaSays(d), d.attention.length ? 'wave' : 'cheer', 120, 'is-dash') : null),
      d.groups.length ? h('section', { class: 'in-panel' },
        h('div', { class: 'in-panel-head' }, h('h2', null, t('Groups')), h('p', null, t('Vehicles grouped by how current they are, updates waiting and time since the last change (k-means, calculated in your browser).'))),
        h('div', { class: 'db-groups' }, d.groups.map((g) => h('div', { class: 'db-group tone-' + g.tone },
          h('strong', null, t(g.name)), h('span', { class: 'db-group-count' }, String(g.count)), h('p', null, t(g.text)),
          h('small', null, t('Typically {s}% up to date · {w} waiting · {y} years since a change', { s: g.share, w: g.waiting.toFixed(1), y: g.years.toFixed(1) })))))) : null,
      h('div', { class: 'in-grid2' },
        h('section', { class: 'in-panel' }, h('div', { class: 'in-panel-head' }, h('h2', null, t('Needs attention')), h('p', null, t('Vehicles with updates waiting or blocked, most urgent first.'))),
          d.attention.length ? h('ol', { class: 'db-attention' }, d.attention.slice(0, 8).map(({ r }) => h('li', null,
            h('div', { class: 'db-att-main' }, h('strong', null, TR.culture.flag(r.country, 16), ' ', r.label), h('small', null, `${r.model} · ${r.t3 ? 'T3' : t('Legacy')}`)), stack(r.counts),
            h('span', { class: 'db-att-note' }, r.waiting ? t('{n} waiting', { n: r.waiting }) : r.counts.update ? t('{n} can update', { n: r.counts.update }) : t('{n} blocked', { n: r.counts.blocked })),
            ui.button(t('Open'), 'arrow', openVehicle(r), 'text')))) : h('p', { class: 'muted' }, t('Every vehicle is up to date.'))),
        h('section', { class: 'in-panel' }, h('div', { class: 'in-panel-head' }, h('h2', null, t('Unusual vehicles')), h('p', null, t('Far from the rest of the fleet (more than two standard deviations).'))),
          d.unusual.length ? h('ol', { class: 'db-attention' }, d.unusual.map(({ r, z, why }) => h('li', null,
            h('div', { class: 'db-att-main' }, h('strong', null, TR.culture.flag(r.country, 16), ' ', r.label), h('small', null, why === 'waiting' ? t('{n} updates waiting', { n: r.waiting }) : t('{n} days without a change', { n: r.daysSinceChange }))),
            h('span', { class: 'db-z', 'data-tip': t('z-score|How many standard deviations from the fleet average') }, 'z ' + z.toFixed(1)), h('span'), ui.button(t('Open'), 'arrow', openVehicle(r), 'text')))) : h('p', { class: 'muted' }, t('No vehicle stands out.')))),
      h('div', { class: 'in-grid2' },
        h('section', { class: 'in-panel' }, h('div', { class: 'in-panel-head' }, h('h2', null, t('Trend')), h('p', null, t('Events per month with a least-squares trend line; the dot is next month’s forecast.'))),
          trendChart(d.trend), h('p', { class: 'db-trend-note' }, t('Activity is {dir}: about {n} events expected next month.', { dir: t(d.trend.direction), n: d.trend.forecast }))),
        h('section', { class: 'in-panel' }, h('div', { class: 'in-panel-head' }, h('h2', null, t('Release pipeline')), h('p', null, t('Every upcoming version in the fleet by release state. Hatched parts are blocked.'))), pipeline(d))),
      h('div', { class: 'in-grid2' },
        h('section', { class: 'in-panel' }, h('div', { class: 'in-panel-head' }, h('h2', null, t('Request outcomes')), h('p', null, t('How your requests ended.'))), outcomesRing(d)),
        h('section', { class: 'in-panel' }, h('div', { class: 'in-panel-head' }, h('h2', null, t('Service packs')), h('p', null, t('Which vehicles each service pack can update.'))),
          d.packs.length ? h('div', { class: 'db-packs' }, d.packs.map((p) => h('div', { class: 'db-pack' }, h('strong', null, TR.icon('layers', 16), p.name),
            [['Available', 'simulation'], ['Already on it', 'good'], ['Not applicable', 'neutral']].map(([k, tone]) => ((p[k] || []).length ? h('div', { class: 'db-pack-row' }, ui.chip(`${p[k].length} ${t(k).toLowerCase()}`, tone), h('span', null, p[k].slice(0, 6).join(', ') + (p[k].length > 6 ? ' …' : ''))) : null)))))
            : h('p', { class: 'muted' }, t('No service packs apply to the vehicles you can read.')))),
      h('section', { class: 'in-panel' }, h('div', { class: 'in-panel-head' }, h('h2', null, t('Fleet activity')), h('p', null, t('Builds, deliveries, workshop visits, VDA changes, kits and your requests, one square per day.'))),
        h('div', { class: 'in-scroll' }, TR.insights.calendar({ days: Object.fromEntries(Object.entries(d.days).map(([k, n]) => [k, Array.from({ length: n }, () => ({ title: '' }))])), now: d.now }, 26)),
        h('div', { class: 'in-legend' }, h('span', null, t('Less')), [0, 1, 2, 3, 4].map((l) => h('i', { class: 'in-cell-key level-' + l })), h('span', null, t('More')))),
      h('div', { class: 'in-grid2' }, vehicleList(d),
        h('section', { class: 'in-panel' }, h('div', { class: 'in-panel-head' }, h('h2', null, t('People')), h('p', null, t('Who changed vehicles: workshop visits, VDA changes and kits.'))),
          d.people.length ? h('ol', { class: 'in-bars' }, d.people.map(([name, n], i) => h('li', null, h('span', { class: 'in-bars-name' }, name),
            h('span', { class: 'in-bars-track' }, h('span', { class: 'in-bars-fill', style: { width: (100 * n / d.people[0][1]) + '%', animationDelay: i * 70 + 'ms' } })), h('strong', null, String(n)))))
            : h('p', { class: 'muted' }, t('Nobody has changed a vehicle yet.')))),
      D.loadedAt ? h('p', { class: 'muted db-foot' }, t('Updated {when}. Press Refresh after you commit or run requests.', { when: ui.when(D.loadedAt) })) : null);
  }

  TR.pages.register({ id: 'dashboard', title: 'Dashboard', crumbs: () => [{ label: t('Dashboard') }], render });
  const run = TR.request.runRequest;
  TR.request.runRequest = async (...args) => { const r = await run(...args); D.data = null; return r; };
  TR.dashboard = { D, load, summarise, groups, unusual, trend };
})();
