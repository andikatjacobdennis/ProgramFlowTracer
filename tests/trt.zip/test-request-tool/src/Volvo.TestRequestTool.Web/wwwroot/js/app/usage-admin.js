/* Usage study for administrators (data: /api/v1/admin/usage). How people use the application, to decide what to improve:
 * the five-step funnel (where people stop), features by use (and those nobody uses), errors and recoveries, each person's
 * activity, and groups of people who use the app in similar ways (k-means on their mix of event kinds, ml.js; no AI).
 * Only interaction events are shown; content was never recorded. People who stopped the study are counted, not shown. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));
  const U = { data: null, error: null };
  const KINDS = ['page', 'action', 'step', 'outcome', 'error', 'recover', 'duration'];
  async function load() { try { U.data = await TR.pages.ui.api('/admin/usage'); U.error = null; } catch (e) { U.error = e.message; } TR.app.refresh(); }
  const bar = (label, v, max, tone, text) => h('div', { class: 'hl-barrow' }, h('span', { title: label }, label), h('span', { class: 'hl-track' }, h('i', { class: 'tone-' + (tone || 'accent'), style: { width: Math.min(100, (v / Math.max(1, max)) * 100) + '%' } })), h('span', { class: 'hl-num' }, text || String(v)));
  /** People with similar habits: k-means on the share of each event kind. */
  function groups(people) {
    if (people.length < 2 || !TR.ml) return [];
    const rows = people.map((p) => { const b = p.summary.byKind || {}, n = Math.max(1, KINDS.reduce((s, k) => s + (b[k] || 0), 0)); return KINDS.map((k) => (b[k] || 0) / n); });
    const k = Math.min(3, people.length), { labels, centroids } = TR.ml.kmeans(TR.ml.scale(rows), k);
    return centroids.map((c, j) => {
      const members = people.filter((_, i) => labels[i] === j);
      const top = KINDS.map((kind, d) => [kind, c[d]]).sort((a, b) => b[1] - a[1])[0][0];
      const name = { page: 'Explorers (mostly moving between pages)', action: 'Doers (mostly using features)', step: 'Journey followers (step by step)', outcome: 'Validators (many validations)', error: 'Struggling (many errors)', recover: 'Recovering (errors, then fixes)', duration: 'Readers (long time on pages)' }[top];
      return { name, members };
    }).filter((g) => g.members.length);
  }
  function render() {
    if (!(TR.backend && TR.backend.session && TR.backend.session.isAdmin)) return h('div', { class: 'st-page' }, h('h1', null, t('Usage study')), h('div', { class: 's-banner' }, TR.icon('lock'), t('Only administrators can see the usage study.')));
    if (!U.data && !U.error) load();
    const d = U.data;
    return h('div', { class: 'st-page hl-page' },
      h('div', { class: 'st-head hl-top' }, h('div', null, h('h1', null, t('Usage study')), h('p', { class: 'muted' }, t('How people use the application: interactions only, never content. People can stop it and delete their data at any time.'))),
        h('div', { class: 'hl-controls' }, TR.pages.ui.button(t('Refresh'), 'refresh', load, 'secondary'))),
      U.error ? h('div', { class: 's-banner warning' }, TR.icon('alert'), U.error) : null,
      !d ? h('p', { class: 'muted' }, t('Loading…')) : [
        h('div', { class: 'hl-kpis' },
          h('div', { class: 'hl-kpi' }, h('strong', null, String(d.people.length)), h('span', null, t('people in the study'))),
          h('div', { class: 'hl-kpi' }, h('strong', null, String(d.optedOut)), h('span', null, t('stopped the study'))),
          h('div', { class: ['hl-kpi', d.errors.reduce((s, e) => s + e.count, 0) ? 'tone-warning' : ''] }, h('strong', null, String(d.errors.reduce((s, e) => s + e.count, 0))), h('span', null, t('errors seen'))),
          h('div', { class: ['hl-kpi', d.recoveries ? 'tone-good' : ''] }, h('strong', null, String(d.recoveries)), h('span', null, t('recoveries')))),
        h('div', { class: 'hl-grid2' },
          h('section', { class: 'st-card hl-card' }, h('header', { class: 'hl-card-head' }, h('div', null, h('h2', null, t('The journey funnel')), h('p', { class: 'muted' }, t('How many times each step was opened: a big drop shows where people stop.')))),
            h('div', { class: 'hl-bars' }, d.funnel.map((f, i) => bar(t(f.step), f.count, Math.max(1, ...d.funnel.map((x) => x.count)), i && f.count < d.funnel[i - 1].count / 2 ? 'warning' : 'accent')))),
          h('section', { class: 'st-card hl-card' }, h('header', { class: 'hl-card-head' }, h('div', null, h('h2', null, t('Features by use')), h('p', { class: 'muted' }, t('Pages and actions, most used first.')))),
            d.features.length ? h('div', { class: 'hl-bars' }, d.features.slice(0, 14).map((f) => bar(f.key.replace(/^(page|action):/, ''), f.count, d.features[0].count))) : h('p', { class: 'muted' }, t('No events yet.'))),
          h('section', { class: 'st-card hl-card' }, h('header', { class: 'hl-card-head' }, h('div', null, h('h2', null, t('Groups of people')), h('p', { class: 'muted' }, t('People who use the app in similar ways (k-means on their mix of interactions).')))),
            (() => { const g = groups(d.people); return g.length ? h('ul', { class: 'md-events' }, g.map((x) => h('li', null, h('strong', null, t(x.name)), ': ', x.members.map((m) => m.name).join(', ')))) : h('p', { class: 'muted' }, t('At least two people are needed.')); })()),
          h('section', { class: 'st-card hl-card' }, h('header', { class: 'hl-card-head' }, h('div', null, h('h2', null, t('Errors')), h('p', { class: 'muted' }, t('What went wrong most often.')))),
            d.errors.length ? h('div', { class: 'hl-bars' }, d.errors.map((e) => bar(e.key.replace(/^error:/, ''), e.count, d.errors[0].count, 'danger'))) : h('p', { class: 'muted' }, t('No errors recorded.')))),
        h('section', { class: 'st-card hl-card' }, h('header', { class: 'hl-card-head' }, h('h2', null, t('People'))),
          h('table', { class: 's-table' }, h('thead', null, h('tr', null, [t('Person'), t('Last seen'), t('Active days'), t('Events'), t('Most used')].map((x) => h('th', { scope: 'col' }, x)))),
            h('tbody', null, d.people.map((p) => h('tr', null, h('td', null, p.name), h('td', null, p.summary.lastSeen ? h('time', { datetime: p.summary.lastSeen }, TR.pages.ui.when(p.summary.lastSeen)) : '—'),
              h('td', { class: 'hl-num' }, String(p.summary.days)), h('td', { class: 'hl-num' }, String(p.summary.events)), h('td', null, (p.summary.top || []).slice(0, 3).map((x) => x.key).join(', ') || '—'))))))],
    );
  }
  TR.pages.register({ id: 'usage', title: 'Usage study', crumbs: () => [{ label: t('Service health'), open: () => TR.pages.show('health') }, { label: t('Usage study') }], render });
})();
