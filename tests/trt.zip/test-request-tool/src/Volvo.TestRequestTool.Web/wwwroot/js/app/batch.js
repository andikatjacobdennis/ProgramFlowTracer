/* Batch runs (server: BatchEndpoints.cs): one software request for each of many vehicles, run one after another with a
 * pause after each completes (1 second by default). Progress is shown live (Server-Sent Events, polling when the browser
 * has no EventSource) and announced to assistive technologies; the report at the end can be downloaded as CSV or JSON,
 * and "Retry failed" runs again only the vehicles that did not succeed. Nothing here is a dialog. */
(function () {
  'use strict';
  const { h } = TR.util;
  const t = (s, v) => (TR.i18n ? TR.i18n.t(s, v) : String(s).replace(/\{(\w+)\}/g, (m, k) => (v && k in v ? v[k] : m)));
  const ui = () => TR.pages.ui;
  const OPS = [[3, 'Update'], [5, 'Update to service pack'], [1, 'Refresh'], [2, 'Repair'], [4, 'Resolve']];
  const B = { q: '', found: null, picked: new Set(), name: '', op: 3, delay: 1, stop: false, current: null, list: null, source: null, busy: false, searching: false };
  const STATUS = { waiting: ['Waiting', 'clock', 'neutral'], running: ['Running', 'refresh', 'info'], ready: ['Ready', 'check', 'good'], limited: ['Limited', 'alert', 'warning'],
    blocked: ['Blocked', 'close', 'danger'], failed: ['Failed', 'alert', 'danger'], cancelled: ['Cancelled', 'close', 'neutral'], skipped: ['Skipped', 'arrow', 'neutral'] };

  async function json(path, opts) { const r = await fetch('/api/v1' + path, Object.assign({ headers: { 'Content-Type': 'application/json' } }, opts)); const body = await r.json().catch(() => ({})); if (!r.ok) throw new Error(body.detail || body.title || r.statusText); return body; }
  async function search() { B.searching = true; TR.app.refresh(); try { B.found = (await json('/vehicles/search?take=100&q=' + encodeURIComponent(B.q))).items; } catch (e) { TR.notify.toast(e.message, 'error'); } B.searching = false; TR.app.refresh(); }
  async function recent() { try { B.list = await json('/batches'); } catch (e) { B.list = []; } TR.app.refresh(); }
  function follow(id) {
    if (B.source) { B.source.close(); B.source = null; }
    let last = null;
    const apply = (b) => {
      B.current = b;
      if (b.status !== last) { last = b.status; if (b.status === 'finished' || b.status === 'cancelled') { TR.announce && TR.announce(t('Batch {s}: {r} ready, {f} not ready.', { s: t(b.status), r: (b.counts.ready || 0) + (b.counts.limited || 0), f: (b.counts.failed || 0) + (b.counts.blocked || 0) })); recent(); } }
      TR.app.refresh();
    };
    if (typeof EventSource === 'function') {
      B.source = new EventSource('/api/v1/batches/' + id + '/events');
      B.source.addEventListener('batch', (e) => { const b = JSON.parse(e.data); apply(b); if (b.status === 'finished' || b.status === 'cancelled') { B.source.close(); B.source = null; } });
      B.source.onerror = () => { if (B.source) { B.source.close(); B.source = null; } poll(id, apply); };
    } else poll(id, apply);
  }
  async function poll(id, apply) {
    for (;;) { let b; try { b = await json('/batches/' + id); } catch (e) { return; } apply(b); if (b.status === 'finished' || b.status === 'cancelled' || !B.current || B.current.id !== id) return; await new Promise((r) => setTimeout(r, 1000)); }
  }
  async function start() {
    if (!B.picked.size || B.busy) return;
    B.busy = true; TR.app.refresh();
    try {
      const b = await json('/batches', { method: 'POST', body: JSON.stringify({ name: B.name || null, vehicleIds: [...B.picked], kind: 'Software', delayMs: Math.round(Number(B.delay) * 1000), stopOnFailure: B.stop,
        template: { softwareRequestOperation: Number(B.op), scenario: TR.prefs.get('scenario') || 1, pblUpdateCapable: true, enableMultiNodeBehavior: true } }) });
      TR.announce && TR.announce(t('Batch started: {n} vehicles.', { n: b.total }));
      B.current = b; follow(b.id);
    } catch (e) { TR.notify.toast(e.message, 'error'); }
    B.busy = false; TR.app.refresh();
  }
  const statusChip = (s) => { const [l, icon, tone] = STATUS[s] || [s, 'info', 'neutral']; return h('span', { class: 'wf-kind tone-' + (tone === 'info' ? 'neutral' : tone) }, TR.icon(icon, 12), t(l)); };

  function form() {
    const disabledWhy = !B.picked.size ? t('Choose at least one vehicle.') : null;
    return h('section', { class: 'st-card hl-card' }, h('h2', null, t('New batch')),
      h('div', { class: 'bt-form' },
        h('label', { class: 's-field' }, h('span', null, t('Name (optional)')), h('input', { value: B.name, 'data-spell': 'on', onInput: (e) => { B.name = e.target.value; } })),
        h('label', { class: 's-field' }, h('span', null, t('Request')), h('select', { onChange: (e) => { B.op = Number(e.target.value); } }, OPS.map(([v, l]) => h('option', { value: v, selected: B.op === v }, t('Software: {o}', { o: t(l) }))))),
        h('label', { class: 's-field' }, h('span', null, t('Pause after each request (seconds)')), h('input', { type: 'number', min: 0, max: 60, step: 0.5, value: B.delay, 'aria-describedby': 'bt-delay-help', onInput: (e) => { B.delay = e.target.value; } }),
          h('small', { id: 'bt-delay-help', class: 'muted' }, t('The next vehicle starts this long after the previous request has completed. Default 1 second.'))),
        h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: B.stop, onChange: (e) => { B.stop = e.target.checked; } }), t('Stop at the first failure'))),
      h('div', { class: 'bt-pick' },
        h('div', { class: 'hl-filters' }, h('label', { class: 'tp-field hl-search' }, TR.icon('search', 15), h('input', { placeholder: t('Find vehicles by chassis, VIN, model or country'), value: B.q, 'aria-label': t('Find vehicles'), onInput: (e) => { B.q = e.target.value; }, onKeydown: (e) => { if (e.key === 'Enter') search(); } })),
          ui().button(B.searching ? t('Searching…') : t('Search'), 'search', search, 'secondary'),
          B.found && B.found.length ? ui().button(t('Select all {n} shown', { n: B.found.length }), 'check', () => { B.found.forEach((v) => B.picked.add(v.id)); TR.app.refresh(); }, 'text') : null,
          B.picked.size ? ui().button(t('Clear selection'), 'close', () => { B.picked.clear(); TR.app.refresh(); }, 'text') : null),
        B.found ? (B.found.length ? h('ul', { class: 'bt-found', 'aria-label': t('Vehicles found') }, B.found.map((v) => h('li', null, h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: B.picked.has(v.id), onChange: (e) => { if (e.target.checked) B.picked.add(v.id); else B.picked.delete(v.id); TR.app.refresh(); } }),
          h('strong', null, v.series + ' ' + v.number), h('span', { class: 'muted' }, ' · ' + (v.model || '') + ' · ' + (v.country || '') + (v.t3 ? ' · T3' : ''))))))
          : h('p', { class: 'muted' }, t('No vehicles match.'))) : h('p', { class: 'muted' }, t('Search to choose vehicles (an empty search lists all you may read).'))),
      h('div', { class: 'tm-actions' },
        ui().button(B.busy ? t('Starting…') : t('Start batch of {n}', { n: B.picked.size }), 'play', start, 'primary', { 'aria-disabled': disabledWhy ? 'true' : null, 'aria-describedby': disabledWhy ? 'bt-why' : null, disabled: B.busy }),
        disabledWhy ? h('span', { id: 'bt-why', class: 'muted' }, disabledWhy) : h('span', { class: 'muted' }, t('{n} vehicles, about {s} s of pauses.', { n: B.picked.size, s: Math.max(0, (B.picked.size - 1) * Number(B.delay || 0)) }))));
  }
  function progress(b) {
    const pct = Math.round(b.progress * 100), running = b.status === 'queued' || b.status === 'running';
    const max = Math.max(1, ...b.items.map((x) => x.seconds || 0));
    return h('section', { class: 'st-card hl-card', 'aria-label': t('Batch {n}', { n: b.name }) },
      h('header', { class: 'hl-card-head' }, h('div', null, h('h2', null, b.name), h('p', { class: 'muted' }, t('{d} of {n} done · round {r} · pause {p} s', { d: b.done, n: b.total, r: b.round, p: b.delayMs / 1000 }) + (b.current ? ' · ' + t('now: {v}', { v: b.current.replace('|', ' ') }) : ''))),
        h('div', { class: 'tm-actions' }, running ? ui().button(t('Cancel batch'), 'close', async () => { try { B.current = await json('/batches/' + b.id + '/cancel', { method: 'POST' }); TR.app.refresh(); } catch (e) { TR.notify.toast(e.message, 'error'); } }, 'danger') : null,
          !running && ((b.counts.failed || 0) + (b.counts.cancelled || 0) + (b.counts.skipped || 0)) ? ui().button(t('Retry failed'), 'refresh', async () => { try { const n = await json('/batches/' + b.id + '/retry-failed', { method: 'POST' }); B.current = n; follow(n.id); } catch (e) { TR.notify.toast(e.message, 'error'); } }, 'primary') : null,
          h('a', { class: 's-btn text', href: '/api/v1/batches/' + b.id + '/report?format=csv', download: '' }, TR.icon('download', 14), 'CSV'),
          h('a', { class: 's-btn text', href: '/api/v1/batches/' + b.id + '/report?format=json', download: '' }, TR.icon('download', 14), 'JSON'))),
      h('div', { class: 'bt-bar', role: 'progressbar', 'aria-valuemin': 0, 'aria-valuemax': 100, 'aria-valuenow': pct, 'aria-label': t('Batch progress') }, h('i', { style: { width: pct + '%' } }), h('span', null, pct + ' %')),
      h('div', { class: 'wf-legend bt-counts' }, Object.entries(b.counts).map(([s, n]) => h('span', null, statusChip(s), ' ', String(n)))),
      !running ? h('div', { class: 'hl-kpis bt-report' },
        h('div', { class: ['hl-kpi', (b.counts.ready || 0) + (b.counts.limited || 0) ? 'tone-good' : ''] }, h('strong', null, String((b.counts.ready || 0) + (b.counts.limited || 0))), h('span', null, t('validated (ready or limited)'))),
        h('div', { class: ['hl-kpi', (b.counts.blocked || 0) + (b.counts.failed || 0) ? 'tone-danger' : ''] }, h('strong', null, String((b.counts.blocked || 0) + (b.counts.failed || 0))), h('span', null, t('blocked or failed'))),
        h('div', { class: 'hl-kpi' }, h('strong', null, b.seconds.average + ' s'), h('span', null, t('average per vehicle'))),
        h('div', { class: 'hl-kpi' }, h('strong', null, b.seconds.slowest + ' s'), h('span', null, t('slowest')))) : null,
      h('table', { class: 's-table bt-table' }, h('caption', { class: 'nv-sr' }, t('Vehicles in this batch')),
        h('thead', null, h('tr', null, ['#', 'Vehicle', 'Status', 'Time', 'Issues', 'Attempts', 'Note'].map((x) => h('th', { scope: 'col' }, t(x))))),
        h('tbody', null, b.items.map((x, i) => h('tr', { class: x.status === 'running' ? 'is-now' : '' }, h('td', { class: 'hl-num' }, String(i + 1)), h('td', null, x.vehicleId.replace('|', ' ')), h('td', null, statusChip(x.status)),
          h('td', null, x.seconds != null ? h('span', { class: 'bt-time' }, h('i', { style: { width: Math.max(2, (x.seconds / max) * 80) + 'px' }, 'aria-hidden': 'true' }), x.seconds + ' s') : '—'),
          h('td', { class: 'hl-num' }, String(x.issues || 0)), h('td', { class: 'hl-num' }, String(x.attempts || 0)), h('td', null, x.error || ''))))));
  }
  function render() {
    if (!B.list) recent();
    return h('div', { class: 'st-page hl-page' },
      h('div', { class: 'st-head' }, h('h1', null, t('Batch runs')), h('p', { class: 'muted' }, t('Run the same request for many vehicles, one after another, with a pause after each. Follow it live and download the report. Simulation only: nothing changes a real vehicle.'))),
      B.current ? progress(B.current) : null,
      form(),
      B.list && B.list.length ? h('section', { class: 'st-card hl-card' }, h('h2', null, t('Recent batches')),
        h('ul', { class: 'st-org-history' }, B.list.map((b) => h('li', null, h('span', null, h('strong', null, b.name), h('small', null, ui().when(b.createdAt) + ' · ' + t('{d} of {n}', { d: b.done, n: b.total }) + ' · ' + t(b.status))),
          ui().button(t('Open'), 'arrow', () => { B.current = b; if (b.status === 'queued' || b.status === 'running') follow(b.id); TR.app.refresh(); }, 'text'))))) : null);
  }
  TR.pages.register({ id: 'batch', title: 'Batch runs', crumbs: () => [{ label: t('Test request'), open: () => TR.testRequest.page() }, { label: t('Batch runs') }], render });
  TR.batch = { B, follow };
})();
