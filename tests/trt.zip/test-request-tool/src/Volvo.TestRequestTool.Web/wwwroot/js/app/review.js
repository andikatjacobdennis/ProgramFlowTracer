/* Get approval (review), Send (submit) and Submission complete (server: /api/v1/reviews, ReviewService).
 *
 *   Review   what exactly changes, the validation evidence captured when the review was requested, the discussion, and the
 *            approval decision. Deciding needs the Writer role and is never open to the author (separation of duties);
 *            approval needs the three checklist items; requesting changes needs a note. The server enforces all of it.
 *   Submit   the final checks (validation and approval match, target is current, your account may submit), run again on
 *            submission, and a confirmation before the approved snapshot is committed to the VDA repository.
 *            Submitting again returns the same receipt, so a retry after a dropped connection is safe.
 *   Outcome  the receipt: submission id, repository revisions, recorded changes and the audit trail, as a downloadable file.
 * None of these pages opens a dialog; the decision and confirmation sit in the side column. */
(function () {
  'use strict';
  const { h } = TR.util;
  const J = TR.journey, t = J.t;
  const V = { id: null, r: null, error: null, checks: null, ticks: new Set(), note: '', comment: '', busy: false, vehicle: 0, discussion: true, confirm: false, submitError: null, problem: null, deliver: 'vda' };
  // How to send an approved request. The vehicle record (the VDA repository) is the usual one and preselected; the
  // others use the workspace's result, so they need the vehicle open there with a fresh check.
  const DELIVERY = [['vda', 'database', 'Update the vehicle record', 'Commits the approved version to the VDA repository. Recommended.'],
    ['kit', 'box', 'Prepare a conversion kit', 'Opens the kit in the workbench to choose operations.'],
    ['twin', 'lock', 'Digital Twin specification', 'A preview to export: no live Digital Twin connection is configured.'],
    ['xml', 'file', 'Download the vehicle file', 'The proposed configuration as product XML.']];
  const CHECKLIST = [['changes', 'I reviewed the proposed changes'], ['evidence', 'I reviewed the validation evidence'], ['vehicle', 'The target vehicle is correct']];

  // ------------------------------------------------------------------ the reviewer's note, pinned in the workspace
  // When a reviewer asks for changes, their note stays at the top of Make changes for that vehicle until the author asks for
  // approval again or dismisses it. Kept per user in this browser.
  const pinKey = () => 'trstudio.' + (J.me().userId || 'user') + '.pinnedNote';
  const sameVehicle = (a, b) => String(a || '').replace(/\s+/g, '') === String(b || '').replace(/\s+/g, '');
  function pin(r) {
    if (!r || r.status !== 'changes_requested' || r.authorId !== J.me().userId || !r.decision) return;
    const now = TR.util.store.get(pinKey(), null);
    if (now && now.rid === r.id && now.at === r.decision.at) return;
    TR.util.store.set(pinKey(), { rid: r.id, label: r.label, who: r.decision.actorName, note: r.decision.note || '', at: r.decision.at, vehicles: vehiclesOf(r).map((v) => v.title) });
  }
  function unpin() { TR.util.store.set(pinKey(), null); }
  /** The pinned note for this vehicle, or null. */
  function pinned(vehicle) {
    const p = TR.util.store.get(pinKey(), null);
    if (!p || (vehicle && !(p.vehicles || []).some((v) => sameVehicle(v, vehicle)))) return null;
    return h('section', { class: 'rv-pinned', role: 'note', 'aria-label': t('Changes requested') },
      h('span', { class: 'rv-pinned-icon', 'aria-hidden': 'true' }, TR.icon('pencil', 18)),
      h('div', { class: 'rv-pinned-text' }, h('strong', null, t('{p} asked for changes to {r}', { p: p.who, r: p.label })),
        p.note ? h('blockquote', { class: 'rv-quote' }, p.note) : h('p', { class: 'muted' }, t('No note was left. Open the approval to see the discussion.')),
        h('small', { class: 'muted' }, t('Make the changes, check again, then ask for approval again.'))),
      h('div', { class: 'rv-pinned-actions' }, TR.pages.ui.button(t('Open the approval'), 'arrow', () => J.open('review', { rid: p.rid }), 'text'),
        h('button', { type: 'button', class: 'jr-link', onClick: () => { unpin(); TR.app.refresh(); } }, t('Dismiss'))));
  }

  async function load(id, withChecks) {
    if (id !== V.id) { V.alsoSend = false; V.ticks = new Set(); V.note = ''; V.comment = ''; V.confirm = false; V.submitError = null; V.problem = null; V.checks = null; V.vehicle = 0; V.deliver = 'vda'; }
    V.id = id; V.error = null; TR.app.refresh();
    try { V.r = await J.api('/reviews/' + encodeURIComponent(id)); pin(V.r); if (withChecks) V.checks = await J.api('/reviews/' + encodeURIComponent(id) + '/checks'); } catch (e) { V.error = e.message; V.r = null; }
    TR.app.refresh();
  }
  async function post(path, body, okText) {
    V.busy = true; V.problem = null; TR.app.refresh();
    try { V.r = await J.api('/reviews/' + encodeURIComponent(V.id) + path, { method: 'POST', body }); if (okText) { TR.notify.toast(t(okText), 'success'); TR.announce && TR.announce(t(okText)); } }
    catch (e) { V.problem = e.message; TR.announce && TR.announce(e.message); if (e.status === 409) await load(V.id).catch(() => null); }
    V.busy = false; TR.app.refresh();
  }
  const rev = (r) => (r.proposalRevision ? t('revision {n}', { n: r.proposalRevision }) : r.label);
  const Rev = (r) => (r.proposalRevision ? t('Revision {n}', { n: r.proposalRevision }) : r.label);
  const sessionName = () => { const s = J.me(); return (s.displayName || s.userId || '') + (s.role ? ' · ' + s.role : ''); };
  const vehiclesOf = (r) => r.evidence.vehicles || [];
  function changeTable(v) {
    return v.changes.length ? h('div', { class: 'jr-table-wrap' }, h('table', { class: 'jr-table' },
      h('thead', null, h('tr', null, ['Component', 'Property', 'The vehicle now', 'Your change'].map((c) => h('th', null, t(c))))),
      h('tbody', null, v.changes.map((c) => h('tr', null, h('td', null, c.component), h('td', null, t(c.property)), h('td', null, c.from || '—'),
        h('td', { class: 'jr-proposed' }, h('span', { class: 'jr-strong-link' }, c.to || '—'), ' ', h('span', { class: 'jr-badge tone-' + J.state(c.kind)[2] }, TR.icon(J.state(c.kind)[1], 12), t(J.state(c.kind)[0]))))))))
      : h('p', { class: 'muted' }, t('No changes for this vehicle.'));
  }
  function vehiclePicker(r) {
    const list = vehiclesOf(r);
    return list.length > 1 ? J.select('Vehicle', V.vehicle, list.map((v, i) => [i, v.title.replace(' ', '')]), (v) => { V.vehicle = Number(v); TR.app.refresh(); }) : h('span', { class: 'jr-pill' }, TR.icon('truck', 14), list[0] ? list[0].title.replace(' ', '') : '');
  }

  /** Enables Approve once every checklist item is ticked, without re-rendering the page. */
  function syncApprove(blockers) {
    const ready = CHECKLIST.every(([k]) => V.ticks.has(k));
    const b = document.getElementById('rv-approve'), hint = document.getElementById('rv-approve-hint');
    if (b) b.disabled = !ready || V.busy || blockers > 0;
    if (hint) hint.textContent = blockers ? t('The validation has blocking findings: request changes instead.') : ready ? (V.alsoSend ? t('Approves this exact revision, then sends it to the vehicle record.') : t('Approval is recorded for this exact revision.')) : t('Complete the checklist to enable approval.');
  }
  // ------------------------------------------------------------------ Review proposal
  function evidence(r) {
    const v = vehiclesOf(r)[V.vehicle] || vehiclesOf(r)[0];
    const mine = r.authorId === J.me().userId;
    return J.card('Validation evidence', null,
      h('ul', { class: 'rv-evidence' }, (v ? v.checks : []).map((c) => h('li', null, h('details', null,
        h('summary', null, h('span', { class: 'rv-ev-icon tone-' + J.state(c.state)[2], 'aria-hidden': 'true' }, TR.icon(J.state(c.state)[1], 16)),
          h('span', { class: 'rv-ev-text' }, h('strong', null, t(c.name)), h('small', { class: 'muted' }, t(J.state(c.state)[0]) + ' · ' + rev(r))),
          mine ? h('button', { class: 'jr-link', onClick: (e) => { e.preventDefault(); J.open('execution', { rid: r.requestId }); } }, t('View evidence')) : null,
          h('time', { class: 'muted', datetime: r.evidence.validatedAt }, J.time(r.evidence.validatedAt))),
        c.findings.length ? h('ul', { class: 'jr-list' }, c.findings.map((f) => h('li', null, f.blocking ? J.chip('blocked') : J.chip('notes'), ' ', f.text, f.node ? h('small', { class: 'muted' }, ' · ' + f.node) : null))) : h('p', { class: 'muted' }, t('No findings in this group.')))))),
      v && v.limited ? J.banner('warning', 'alert', t('Validation ran with limited evidence for this vehicle.')) : null,
      h('p', { class: 'muted jr-small' }, t('Evidence applies to {r} (vehicle revision {b}). Further edits require validation and approval again.', { r: rev(r), b: v ? v.baseRevision : '—' })));
  }
  function discussion(r) {
    return h('section', { class: 'jr-card' },
      h('button', { class: 'rv-toggle', 'aria-expanded': String(V.discussion), onClick: () => { V.discussion = !V.discussion; TR.app.refresh(); } }, TR.icon('chevron', 15), h('h2', null, t('Review discussion')), h('span', { class: 'muted' }, String(r.comments.length))),
      V.discussion ? h('div', null,
        h('ol', { class: 'rv-comments' }, r.comments.map((c) => h('li', { class: 'kind-' + c.kind },
          h('span', { class: 'rv-avatar', 'aria-hidden': 'true' }, J.initials(c.actorName)),
          h('div', null, h('p', { class: 'rv-who' }, h('strong', null, c.actorName), h('time', { class: 'muted', datetime: c.at, title: TR.pages.ui.when(c.at) }, J.ago(c.at)), c.kind !== 'comment' ? J.chip(c.kind === 'requested' ? 'open' : c.kind === 'approved' ? 'approved' : c.kind === 'submitted' ? 'submitted' : c.kind === 'withdrawn' ? 'withdrawn' : 'changes', t({ requested: 'Review requested', approved: 'Approved', changes_requested: 'Changes requested', submitted: 'Submitted', withdrawn: 'Withdrawn' }[c.kind] || c.kind)) : null),
            h('p', null, c.text))))),
        r.can.comment ? h('div', { class: 'rv-compose' },
          h('textarea', { rows: 2, maxlength: 500, 'data-spell': 'on', placeholder: t('Add to the discussion'), 'aria-label': t('Comment'), value: V.comment, onInput: (e) => { V.comment = e.target.value; } }),
          TR.pages.ui.button(t('Add comment'), 'plus', async () => { const text = V.comment.trim(); if (!text) return; V.comment = ''; await post('/comments', { text }, 'Comment added.'); }, 'secondary', { disabled: V.busy })) : null) : null);
  }
  /**
   * While a decision is pending, for the author (or anyone who may not decide): since when, who can decide, a link to send
   * them, and the promise that this page shows the decision by itself (watch() looks again every 15 seconds).
   */
  function waiting(r) {
    const pool = r.reviewers;
    const copy = async () => { try { await navigator.clipboard.writeText(location.origin + '/?view=review&rid=' + encodeURIComponent(r.id)); TR.notify.toast(t('Link copied. Send it to a reviewer.'), 'success'); } catch (e) { TR.notify.toast(t('Copy the address from the address bar.'), 'info'); } };
    return h('div', { class: 'rv-wait' },
      h('p', { class: 'rv-wait-status' }, h('span', { class: 'rv-wait-dot', 'aria-hidden': 'true' }), h('strong', null, r.assignee ? t('Waiting for {p}', { p: r.assignee.name }) : t('Waiting for a decision')),
        h('span', { class: 'muted' }, ' · ' + t('asked {a}', { a: J.ago(r.createdAt) }))),
      h('p', { class: 'muted jr-small' }, t(r.why || 'Waiting for a reviewer.')),
      h('h3', { class: 'jr-h4' }, t('Who can decide')),
      // Assign one of them (they see it under Assigned to me), or leave it to whoever takes it first.
      pool && pool.length ? h('ul', { class: 'rv-pool' }, pool.map((p) => { const on = r.assignee && r.assignee.id === p.id;
        return h('li', { class: on ? 'is-assigned' : '' }, h('span', { class: 'rv-avatar', 'aria-hidden': 'true' }, J.initials(p.name)),
          h('span', { class: 'rv-pool-who' }, h('strong', null, p.name), h('small', { class: 'muted' }, t(p.role))),
          on ? J.chip('approved', t('Assigned')) : r.can.assign && p.id ? h('button', { type: 'button', class: 'jr-link', disabled: V.busy, onClick: () => post('/assign', { assigneeId: p.id, version: r.version }, t('Assigned to {p}.', { p: p.name })) }, t('Assign')) : null); }))
        : h('p', { class: 'muted' }, r.assignee ? t('Assigned to {p}.', { p: r.assignee.name }) : t('Anyone with the Reviewer or Admin role, except you.')),
      r.assignee && r.can.assign ? h('button', { type: 'button', class: 'jr-link rv-unassign', onClick: () => post('/assign', { assigneeId: null, version: r.version }, t('Open to every reviewer again.')) }, t('Open to every reviewer')) : null,
      TR.pages.ui.button(t('Copy link for a reviewer'), 'copy', copy, 'secondary rv-wide'),
      h('p', { class: 'muted jr-small rv-wait-live' }, TR.icon('refresh', 13), t('This page shows their decision by itself.')),
      r.can.withdraw ? TR.pages.ui.button(t('Withdraw review request'), 'undo', () => post('/withdraw', { version: r.version }, 'Review request withdrawn.'), 'secondary rv-wide') : null);
  }
  /** Looks at a pending review again every 15 s while it is on screen; a decision (or a new comment) updates the page. */
  let watchTimer = null;
  function watch(id) {
    if (watchTimer || typeof setTimeout !== 'function') return;
    watchTimer = setTimeout(async () => {
      watchTimer = null;
      const onPage = () => V.id === id && V.r && V.r.status === 'open' && (!TR.pages.current || TR.pages.current() === 'review');
      if (!onPage() || V.busy) return;
      try {
        const next = await J.api('/reviews/' + encodeURIComponent(id));
        if (!onPage()) return;
        if (next.status !== V.r.status) {
          const who = next.decision ? next.decision.actorName : t('A reviewer');
          const msg = next.status === 'approved' ? t('{p} approved {r}.', { p: who, r: next.label }) : next.status === 'changes_requested' ? t('{p} asked for changes to {r}.', { p: who, r: next.label }) : t('{r} changed: {s}.', { r: next.label, s: next.status });
          V.r = next; pin(next); TR.notify && TR.notify.toast(msg, next.status === 'approved' ? 'success' : 'info'); TR.announce && TR.announce(msg); TR.app.refresh();
        } else if (next.comments.length !== V.r.comments.length) { V.r = next; TR.app.refresh(); }
      } catch (e) { /* try again next time */ }
      watch(id);
    }, 15000);
    if (watchTimer && watchTimer.unref) watchTimer.unref();
  }
  /**
   * Approves, and with Also send it now, sends straight away: the final checks run again, then the approved revision goes to the
   * vehicle record and the receipt opens. If the checks or the send fail, the approval stands and the Send page says why.
   */
  async function approve(r) {
    const send = !!V.alsoSend && J.me().canWrite;
    await post('/decision', { decision: 'approve', checklist: [...V.ticks], note: V.note, version: r.version }, send ? null : 'Approval recorded.');
    if (!send || !V.r || V.r.status !== 'approved') return;
    const id = V.r.id;
    V.busy = true; TR.app.refresh();
    try {
      const checks = await J.api('/reviews/' + encodeURIComponent(id) + '/checks');
      if (!checks.ok) { V.checks = checks; V.busy = false; TR.notify.toast(t('Approved. It could not be sent yet: see the final checks.'), 'warning'); J.open('submit', { rid: id }); return; }
      V.r = await J.api('/reviews/' + encodeURIComponent(id) + '/submit', { method: 'POST', body: { confirmed: true } });
      V.busy = false; V.alsoSend = false;
      TR.notify.toast(t('Approved and sent.'), 'success'); TR.announce && TR.announce(t('Approved and sent.'));
      J.open('outcome', { rid: id });
    } catch (e) {
      V.busy = false; TR.notify.toast(t('Approved, but sending failed: {m}', { m: e.message }), 'error'); J.open('submit', { rid: id });
    }
  }
  function decision(r) {
    const ready = CHECKLIST.every(([k]) => V.ticks.has(k));
    const blockers = r.evidence.totals.blockers;
    const status = r.status === 'open' ? (blockers ? 'blocked' : 'ready') : r.status;
    const statusText = { ready: 'Ready for review', blocked: 'Has blockers', approved: 'Approved', submitted: 'Submitted', changes_requested: 'Changes requested', withdrawn: 'Withdrawn' }[status];
    const body = [];
    if (r.status === 'open' && r.can.decide) {
      // Who is expected to decide: assigned to you, to someone else, or to nobody yet (then Take it).
      body.push(h('p', { class: 'rv-assignee' }, TR.icon('user', 15), r.assignee ? (r.assignee.id === J.me().userId ? t('Assigned to you') : t('Assigned to {p}. You can still decide.', { p: r.assignee.name })) : t('Not assigned yet.'),
        r.can.take ? h('button', { type: 'button', class: 'jr-link', disabled: V.busy, onClick: () => post('/assign', { assigneeId: J.me().userId, version: r.version }, t('You took this review.')) }, t('Take it')) : null));
      body.push(h('fieldset', { class: 'rv-checklist' }, h('legend', null, t('Review checklist')),
        // Ticking updates the Approve button in place: re-rendering the page under a click on a label would undo the tick.
        CHECKLIST.map(([k, l]) => h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: V.ticks.has(k), onChange: (e) => { if (e.target.checked) V.ticks.add(k); else V.ticks.delete(k); syncApprove(blockers); } }), t(l)))),
        h('label', { class: 'rv-note' }, h('span', { class: 'jr-h4' }, t('Review note')),
          h('textarea', { rows: 4, maxlength: 500, 'data-spell': 'on', placeholder: t('Add context for the author'), value: V.note, 'aria-describedby': 'rv-count', onInput: (e) => { V.note = e.target.value; const c = document.getElementById('rv-count'); if (c) c.textContent = V.note.length + ' / 500'; } }),
          h('small', { id: 'rv-count', class: 'muted rv-count' }, V.note.length + ' / 500')),
        // Deciding and sending need the same role here, so whoever approves may also send it now: one step, the usual
        // way (the vehicle record). Other ways to send stay on the Send page.
        J.me().canWrite ? h('label', { class: 'chk rv-also-send' }, h('input', { type: 'checkbox', checked: !!V.alsoSend, onChange: (e) => { V.alsoSend = e.target.checked; TR.app.refresh(); } }),
          h('span', null, t('Also send it now'), h('small', { class: 'muted' }, t('Updates the vehicle record (the VDA repository) right after approving. Final checks run again first.')))) : null,
        TR.pages.ui.button(V.alsoSend ? t('Approve and send {r}', { r: rev(r) }) : t('Approve {r}', { r: rev(r) }), V.alsoSend ? 'upload' : 'check', () => approve(r), 'primary rv-wide', { id: 'rv-approve', disabled: !ready || V.busy || blockers > 0 }),
        h('p', { class: 'muted jr-small', id: 'rv-approve-hint', 'aria-live': 'polite' }, blockers ? t('The validation has blocking findings: request changes instead.') : ready ? (V.alsoSend ? t('Approves this exact revision, then sends it to the vehicle record.') : t('Approval is recorded for this exact revision.')) : t('Complete the checklist to enable approval.')),
        TR.pages.ui.button(t('Request changes'), 'pencil', () => { if (!V.note.trim()) { V.problem = t('Write a review note saying what needs to change.'); TR.app.refresh(); return; } post('/decision', { decision: 'request_changes', note: V.note, version: r.version }, 'Changes requested.'); }, 'secondary rv-wide', { disabled: V.busy }));
    } else if (r.status === 'open') {
      body.push(waiting(r));
    } else if (r.status === 'approved') {
      body.push(h('p', null, t('Approved by {p}, {a}.', { p: r.decision.actorName, a: J.ago(r.decision.at) })), r.decision.note ? h('blockquote', { class: 'rv-quote' }, r.decision.note) : null,
        r.can.submit ? TR.pages.ui.button(t('Continue to send'), 'arrow', () => J.open('submit', { rid: r.id }), 'primary rv-wide') : J.banner('info', 'lock', t('An authorised operator (Reviewer or Admin) submits the approved revision.')));
    } else if (r.status === 'submitted') {
      body.push(h('p', null, t('Submitted as {s} by {p}.', { s: r.submission.id, p: r.submission.actorName })), TR.pages.ui.button(t('View receipt'), 'file', () => J.open('outcome', { rid: r.id }), 'primary rv-wide'));
    } else if (r.status === 'changes_requested') {
      body.push(h('p', null, t('{p} asked for changes:', { p: r.decision.actorName })), h('blockquote', { class: 'rv-quote' }, r.decision.note),
        r.authorId === J.me().userId ? TR.pages.ui.button(t('Back to editing'), 'pencil', () => { if (TR.experience) TR.experience.page = null; TR.testRequest.page(); }, 'primary rv-wide') : null);
    }
    return h('aside', { class: 'jr-side' },
      J.card(h('h2', null, t('Get it approved')), null,
        h('div', { class: 'jr-side-title' }, h('span', null, sessionName()), J.chip(status === 'ready' ? 'ready' : status, t(statusText || status))),
        h('p', { class: 'muted jr-small' }, t('Approval is recorded for this exact revision. It does not install software.')),
        V.problem ? h('div', { class: 'jr-banner tone-danger', role: 'alert' }, TR.icon('alert', 16), V.problem) : null,
        body),
      J.card(null, null, h('div', { class: 'rv-next' }, TR.icon('file', 24), h('div', null, h('h2', { class: 'jr-h3' }, t('Next step')),
        h('p', { class: 'muted' }, t({ open: 'A reviewer decides; then an authorised operator can submit the approved revision.', approved: 'An authorised operator can submit the approved revision.', submitted: 'Done. Any new change needs fresh validation and approval.', changes_requested: 'Edit, validate again and request a new review.', withdrawn: 'Validate again and request a new review when ready.' }[r.status] || '')))))
    );
  }
  function renderReview() {
    J.readParams();
    const id = J.param('rid', 'review');
    if (!id) return h('div', { class: 'jr-page' }, J.pageHead('Get approval', 'What changes, then the approval.'), J.empty('No review chosen', 'Open one from Requests.', TR.pages.ui.button(t('Go to Requests'), 'arrow', () => J.open('requests'), 'primary')));
    if (id !== V.id) load(id);
    const r = V.r;
    const head = J.pageHead('Get approval', 'What changes, then the approval.', [
      r ? TR.pages.ui.button(t('Export evidence'), 'upload', () => J.download(r.label + '-evidence.json', JSON.stringify({ review: r.id, request: r.label, status: r.status, author: r.authorName, evidence: r.evidence, decision: r.decision, comments: r.comments }, null, 2)), 'secondary') : null,
      TR.pages.ui.button(t('Back to editing'), 'left', () => { if (TR.experience) TR.experience.page = null; TR.testRequest.page(); }, 'secondary')]);
    if (!r) return h('div', { class: 'jr-page' }, head, V.error ? J.failed(V.error, () => load(id)) : J.loading(6));
    const v = vehiclesOf(r)[V.vehicle] || vehiclesOf(r)[0];
    const tot = r.evidence.totals;
    if (r.status === 'open' && !r.can.decide) watch(id);
    return h('div', { class: 'jr-page rv-page' }, head, J.stepper(r.status === 'submitted' ? 5 : r.status === 'approved' ? 4 : 3),
      h('div', { class: 'jr-split' },
        h('div', { class: 'jr-main' },
          J.stats([{ n: tot.changes, label: tot.changes === 1 ? 'change' : 'changes', icon: 'file', tone: 'info' }, { n: tot.checksPassed, label: 'checks passed', sub: t('of {n}', { n: tot.checks }), icon: 'check', tone: 'good' }, { n: tot.blockers, label: 'must fix', icon: 'shield', tone: tot.blockers ? 'warning' : 'good' }]),
          J.card('Your changes', vehiclePicker(r), v ? changeTable(v) : null),
          evidence(r), discussion(r)),
        decision(r)),
      h('p', { class: 'jr-foot muted' }, t('{r} · requested by {p}, {a}.', { r: r.label, p: r.authorName, a: J.ago(r.createdAt) })));
  }

  // ------------------------------------------------------------------ Submit approved request
  async function submit() {
    if (!V.confirm || V.busy) return;
    V.busy = true; V.submitError = null; TR.app.refresh();
    try {
      V.r = await J.api('/reviews/' + encodeURIComponent(V.id) + '/submit', { method: 'POST', body: { confirmed: true } });
      TR.announce && TR.announce(t('Submission complete.'));
      J.open('outcome', { rid: V.id });
    } catch (e) {
      V.submitError = e.status ? e.message : t('The connection dropped. Reopen this request to check its status before retrying; submitting twice never commits twice.');
      if (e.status === 409 || e.status === 403) V.checks = await J.api('/reviews/' + encodeURIComponent(V.id) + '/checks').catch(() => V.checks);
    }
    V.busy = false; TR.app.refresh();
  }
  /** How to send: a radio list, the vehicle record preselected. The other options act on the workspace's checked result. */
  function deliveryChoice(ok) {
    const D = TR.testRequest && TR.testRequest.delivery ? TR.testRequest.delivery() : { ready: false };
    const pick = DELIVERY.find((d) => d[0] === V.deliver) || DELIVERY[0];
    const run = { kit: D.kit, twin: D.twin, xml: D.xml }[V.deliver];
    return J.card(h('h2', null, t('How to send it')), null,
      h('fieldset', { class: 'sb-deliver' }, h('legend', { class: 'nv-sr' }, t('How to send it')),
        DELIVERY.map(([id, icon, label, help]) => h('label', { class: 'sb-option' + (V.deliver === id ? ' is-on' : '') },
          h('input', { type: 'radio', name: 'sb-deliver', value: id, checked: V.deliver === id, onChange: () => { V.deliver = id; TR.app.refresh(); } }),
          TR.icon(icon, 18), h('span', null, h('strong', null, t(label)), h('small', { class: 'muted' }, t(help)))))),
      V.deliver === 'vda' ? null : h('div', { class: 'sb-deliver-go' },
        TR.pages.ui.button(t(pick[2]), pick[1], () => run && run(), 'primary rv-wide', { disabled: !ok || !D.ready }),
        h('p', { class: 'muted jr-small', role: 'status' }, !ok ? t('Every final check must pass first.') : D.ready ? t('Uses the checked result in your workspace.') : t('Open the vehicle in the workspace and check it again to use this option.'))));
  }
  function renderSubmit() {
    J.readParams();
    const id = J.param('rid', 'submit');
    if (!id) return h('div', { class: 'jr-page' }, J.pageHead('Send', 'Choose how to send the approved version, then confirm.'), J.empty('No review chosen', 'Open one from Requests.', TR.pages.ui.button(t('Go to Requests'), 'arrow', () => J.open('requests'), 'primary')));
    if (id !== V.id || !V.checks) { if (!V.loadingChecks) { V.loadingChecks = true; load(id, true).finally(() => { V.loadingChecks = false; }); } }
    const r = V.r, ch = V.checks;
    const head = J.pageHead('Send', 'Choose how to send the approved version, then confirm.', [TR.pages.ui.button(t('Back to approval'), 'left', () => J.open('review', { rid: id }), 'secondary')]);
    if (!r || !ch) return h('div', { class: 'jr-page' }, head, V.error ? J.failed(V.error, () => load(id, true)) : J.loading(6));
    if (r.status === 'submitted') { setTimeout(() => J.open('outcome', { rid: id }), 0); return h('div', { class: 'jr-page' }, head, J.loading(2)); }
    const vs = vehiclesOf(r), changes = vs.flatMap((v) => v.changes.map((c) => Object.assign({ vehicle: v.title }, c)));
    const ok = ch.ok && r.status === 'approved';
    return h('div', { class: 'jr-page sb-page' }, head, J.stepper(4),
      h('div', { class: 'jr-split' },
        h('div', { class: 'jr-main' },
          J.card('Submission summary', null,
            h('div', { class: 'jr-grid2' }, J.facts([['Vehicle', vs.map((v) => v.title + ' · ' + v.architecture).join(', ')], ['Request', r.label]]), J.facts([['Revision', Rev(r)], ['Target', ch.target]])),
            h('h3', { class: 'jr-h4' }, t('Approved changes ({n})', { n: changes.length })),
            h('ul', { class: 'sb-changes' }, changes.map((c) => h('li', null, h('span', null, c.component + ' · ' + t(c.property)), h('span', null, (c.from || '—') + ' → ' + (c.to || '—')))))),
          J.card('Final checks', null,
            h('ul', { class: 'sb-checks' }, ch.checks.map((c) => h('li', { class: c.ok ? 'is-ok' : 'is-bad' }, h('span', { class: 'sb-icon', 'aria-hidden': 'true' }, TR.icon(c.ok ? 'check' : 'alert', 15)), h('span', null, h('strong', null, t(c.label)), h('small', { class: 'muted' }, c.detail)), h('span', { class: c.ok ? 'tone-good' : 'tone-danger' }, t(c.ok ? 'Verified' : 'Not met'))))),
            h('p', { class: 'muted jr-small' }, t('Checked {a} · checked again on submission.', { a: J.ago(ch.checkedAt) }), ' ', h('button', { class: 'jr-link', onClick: () => load(id, true) }, t('Check again')))),
          J.card('Approval record', null, r.decision ? h('div', { class: 'sb-approval' }, TR.icon('user', 26), h('div', null, h('strong', null, t('Reviewed by {p}', { p: r.decision.actorName })), h('p', { class: 'muted' }, Rev(r) + ' · ' + t('Approved at {a}', { a: J.time(r.decision.at) }))),
            h('button', { class: 'jr-link', onClick: () => J.open('review', { rid: id }) }, t('View approval evidence'), ' ', TR.icon('external', 14))) : h('p', { class: 'muted' }, t('Not approved.')))),
        h('aside', { class: 'jr-side' },
          deliveryChoice(ok),
          V.deliver !== 'vda' ? null : J.card(h('h2', null, t('Confirm submission')), null,
            J.banner('warning', 'alert', t('This updates the vehicle repository. It does not install software on a vehicle.')),
            h('div', { class: 'sb-fields' }, [['Target', ch.target], ['Vehicle', vs.map((v) => v.title.replace(' ', '')).join(', ')], ['Approved revision', r.proposalRevision ? String(r.proposalRevision) : r.label]].map(([k, v]) =>
              h('label', null, h('span', null, t(k)), h('input', { readonly: true, value: v, 'aria-readonly': 'true' })))),
            h('label', { class: 'chk sb-confirm' }, h('input', { type: 'checkbox', checked: V.confirm, disabled: !ok, onChange: (e) => { V.confirm = e.target.checked; TR.app.refresh(); } }), t('I confirm the target and approved revision.')),
            TR.pages.ui.button(V.busy ? t('Sending…') : (r.proposalRevision ? t('Send revision {n} to {v}', { n: r.proposalRevision, v: vs.map((v) => v.title).join(', ') }) : t('Send {r} to {v}', { r: r.label, v: vs.map((v) => v.title).join(', ') })), 'upload', submit, 'primary rv-wide', { disabled: !ok || !V.confirm || V.busy }),
            h('p', { class: 'muted jr-small', role: 'status' }, !ok ? t('Every final check must pass first.') : V.confirm ? t('Ready to submit.') : t('Confirm the target and revision to continue.')),
            V.submitError ? h('div', { class: 'jr-banner tone-danger', role: 'alert' }, TR.icon('alert', 16), V.submitError) : null,
            h('button', { class: 'jr-link', onClick: () => J.open('requests') }, t('Save and return later'))),
          J.card('What happens next', null, h('ol', { class: 'sb-steps' }, ['Request is durably accepted', 'Submission status is tracked', 'An outcome and audit record are recorded'].map((s, i) => h('li', null, h('span', { class: 'sb-num' }, String(i + 1)), t(s)))),
            h('p', { class: 'muted jr-small' }, t('If the connection drops, reopen this request to check its status before retrying.'))))),
      J.banner('info', 'info', t('Changes after approval require revalidation and a new approval.')));
  }

  // ------------------------------------------------------------------ Submission complete
  function renderOutcome() {
    J.readParams();
    const id = J.param('rid', 'outcome');
    if (!id) return h('div', { class: 'jr-page' }, J.pageHead('Submission complete', 'The approved snapshot was committed to the vehicle repository.'), J.empty('No submission chosen', 'Open one from Requests.', TR.pages.ui.button(t('Go to Requests'), 'arrow', () => J.open('requests'), 'primary')));
    if (id !== V.id || !V.r) { if (!V.loadingOutcome) { V.loadingOutcome = true; load(id).finally(() => { V.loadingOutcome = false; }); } }
    const r = V.r;
    const head = (actions) => J.pageHead('Submission complete', 'The approved snapshot was committed to the vehicle repository.', actions);
    if (!r) return h('div', { class: 'jr-page' }, head(), V.error ? J.failed(V.error, () => load(id)) : J.loading(6));
    if (!r.submission) return h('div', { class: 'jr-page' }, J.pageHead('Not submitted yet', 'This review has no receipt.'), TR.pages.ui.button(t('Back to review'), 'left', () => J.open('review', { rid: id }), 'secondary'));
    const s = r.submission, vs = vehiclesOf(r), first = s.vehicles[0];
    const mine = r.authorId === J.me().userId;
    return h('div', { class: 'jr-page oc-page' },
      head([h('a', { class: 's-btn secondary', href: '/api/v1/reviews/' + encodeURIComponent(r.id) + '/receipt', download: s.id + '.json' }, TR.icon('download', 17), t('Download receipt'))]),
      h('div', { class: 'jr-banner tone-good oc-success', role: 'status' }, h('span', { class: 'oc-check', 'aria-hidden': 'true' }, TR.icon('check', 22)), h('span', null, h('strong', null, t('Snapshot committed')), h('br'), t('No software was installed on a vehicle.'))),
      h('div', { class: 'jr-meta' }, h('span', { class: 'jr-pill' }, TR.icon('file', 15), r.label), vs.map((v) => h('span', { class: 'jr-pill' }, TR.icon('truck', 15), v.title.replace(' ', '') + ' · ' + v.architecture)), r.proposalRevision ? h('span', { class: 'jr-pill' }, TR.icon('branch', 15), t('Proposal revision {n}', { n: r.proposalRevision })) : null),
      h('div', { class: 'jr-split' },
        h('div', { class: 'jr-main' },
          J.card('Submission receipt', null, h('div', { class: 'jr-grid2' },
            J.facts([['Submission ID', s.id], ['Target', s.target], ['Approved revision', r.proposalRevision ? String(r.proposalRevision) : r.label]]),
            J.facts([['Repository revision', s.vehicles.map((x) => x.fromRevision + ' → ' + x.toRevision).join(', ')], ['Submitted by', s.actorName], ['Completed at', h('time', { datetime: s.at, title: TR.pages.ui.when(s.at) }, J.time(s.at))]])),
            h('p', { class: 'muted jr-small' }, t('Keep this receipt to trace the exact submitted configuration.'))),
          J.card('Recorded changes', null, h('div', { class: 'jr-table-wrap' }, h('table', { class: 'jr-table' },
            h('thead', null, h('tr', null, ['Component', 'Item', 'Before', '', 'After'].map((c) => h('th', null, c ? t(c) : h('span', { class: 'nv-sr' }, t('to')))))),
            h('tbody', null, vs.flatMap((v) => v.changes).map((c) => h('tr', null, h('td', null, c.component), h('td', null, t(c.property)), h('td', null, h('span', { class: 'oc-pill' }, c.from || '—')), h('td', { 'aria-hidden': 'true' }, '→'), h('td', null, h('span', { class: 'oc-pill is-new' }, c.to || '—')))))))),
          J.card('Audit trail', null, h('ol', { class: 'oc-trail' }, s.steps.map((st) => h('li', null, h('time', { datetime: st.at }, J.time(st.at)), h('span', { class: 'oc-dot', 'aria-hidden': 'true' }, TR.icon('check', 12)), h('span', null, t(st.text), h('small', { class: 'muted' }, ' · ' + st.detail))))))),
        h('aside', { class: 'jr-side' },
          J.card(h('h2', null, t('What would you like to do next?')), null,
            h('div', { class: 'oc-next is-primary' }, TR.icon('truck', 22), h('span', null, h('strong', null, t('Open updated vehicle')), h('small', { class: 'muted' }, t('Inspect repository revision {n}', { n: first ? first.toRevision : '' }))),
              TR.pages.ui.button(t('Open updated vehicle'), null, async () => { const [se, n] = (first.vehicleId || '').split('|'); try { const L = TR.app.shell.left; Object.assign(L.src, { series: se, number: n }); await L.loadFromSource(false); TR.pages.show('vehicle'); } catch (e) { J.open('impact', { vid: first.vehicleId }); } }, 'primary')),
            mine ? h('button', { class: 'oc-next', onClick: () => J.open('execution', { rid: r.requestId }) }, TR.icon('clock', 22), h('span', null, h('strong', null, t('View execution timeline')), h('small', { class: 'muted' }, t('See processing stages and evidence'))), TR.icon('chevron', 16)) : null,
            h('button', { class: 'oc-next', onClick: () => J.open('requests') }, TR.icon('file', 22), h('span', null, h('strong', null, t('Back to requests')), h('small', { class: 'muted' }, t('Continue with another request'))), TR.icon('chevron', 16))),
          h('div', { class: 'jr-banner tone-warning oc-before' }, TR.icon('info', 18), h('span', null, h('strong', null, t('Before another change')), h('br'), t('Start from repository revision {n}. Any new proposal requires fresh validation and approval.', { n: first ? first.toRevision : '' }))),
          TR.pages.ui.button(t('Create follow-up proposal'), 'plus', () => { if (TR.experience) TR.experience.page = null; TR.testRequest.page(); }, 'secondary'))),
      J.banner('info', 'info', t('This receipt confirms a repository update. Vehicle installation and live delivery are separate workflows.')));
  }

  const crumbs = (last) => () => [{ label: t('Requests'), open: () => J.open('requests') }, { label: V.r ? V.r.label : t('Request') }, { label: t(last) }];
  TR.pages.register({ id: 'review', title: 'Get approval', crumbs: crumbs('Get approval'), render: renderReview });
  TR.pages.register({ id: 'submit', title: 'Send', crumbs: crumbs('Send'), render: renderSubmit });
  TR.pages.register({ id: 'outcome', title: 'Submission complete', crumbs: crumbs('Outcome'), render: renderOutcome });
  TR.review = { V, load, CHECKLIST, DELIVERY, pin, unpin, pinned };
})();
