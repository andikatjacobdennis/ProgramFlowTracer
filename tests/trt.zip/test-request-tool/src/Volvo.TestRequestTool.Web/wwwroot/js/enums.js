/* Enums mirrored from the Configurator domain (values match the C#/TS sources). */
(function () {
  'use strict';
  const TR = window.TR;

  const RequestType = { Software: 0, Hardware: 1, ConversionKit: 2, Language: 3, SpareCab: 4, ProductionBreakdown: 5, DevelopmentBreakdown: 6, AvailableUpdates: 7, ProductUpdateService: 8, AvailableProductUpdates: 9 };
  const RequestTypeNames = { 0: 'Software', 1: 'Hardware', 2: 'Conversion Kit', 3: 'Language', 4: 'Spare Cab', 5: 'Production Breakdown', 6: 'Development Breakdown', 7: 'Available Updates', 8: 'Product Update Service', 9: 'Available Product Updates' };
  const RequestTypeKeys = { 0: 'Software', 1: 'Hardware', 2: 'ConversionKit', 3: 'Language', 4: 'SpareCab', 5: 'ProductionBreakdown', 6: 'DevelopmentBreakdown', 7: 'AvailableUpdates', 8: 'ProductUpdateService', 9: 'AvailableProductUpdates' };
  // Wire values of the JSON Available Product Updates contract (criteria.actionCriteria).
  const ApuActionCriteria = ['SoftwareReplacements.CurrentSoftware', 'SoftwareReplacements.General', 'SoftwareReplacements.RemoteGeneral', 'SoftwareReplacements.RemoteLimited', 'SoftwareReplacements.RemoteCapable', 'SoftwareReplacements.ServicePackGeneral', 'SoftwareReplacements.ServicePackRemoteGeneral', 'SoftwareReplacements.ServicePackRemoteLimited', 'SoftwareReplacements.ServicePackRemoteCapable', 'HardwareReplacements', 'DisplayLanguages', 'AccessoryKits', 'ServiceKits', 'AdministrativeServiceKits', 'CampaignKits', 'HardwareKits', 'RemoteAccessoryKits', 'RemoteServiceKits', 'RemoteAdministrativeServiceKits', 'RemoteCampaignKits', 'RemoteHardwareKits'];

  const SoftwareRequestOperation = { Refresh: 1, Repair: 2, Update: 3, Resolve: 4, UpdateToServicePack: 5 };
  const SoftwareRequestOperationNames = { 1: 'Refresh', 2: 'Repair', 3: 'Update', 4: 'Resolve', 5: 'Update to Service Pack' };
  const SoftwareRequestOperationKeys = { 1: 'Refresh', 2: 'Repair', 3: 'Update', 4: 'Resolve', 5: 'UpdateToServicePack' };

  const Scenario = { Introduced: 1, IntroductionDateSet: 2, Released: 3, PreReleaseVerification: 4, InProgress: 5 };
  const ScenarioNames = { 1: 'Introduced', 2: 'IntroductionDateSet', 3: 'Released', 4: 'PreReleaseVerification', 5: 'InProgress' };

  const KitScenario = { Introduced: 1, InProgress: 2, Released: 3, PreReleaseVerification: 4 };
  const KitScenarioNames = { 1: 'Introduced', 2: 'In Progress', 3: 'Released', 4: 'Pre Release Verification' };
  const KitScenarioKeys = { 1: 'Introduced', 2: 'InProgress', 3: 'Released', 4: 'PreReleaseVerification' };

  const RemoteNames = { 0: 'N/A', 1: 'General RSWDL Availability', 2: 'Limited RSWDL Availability', 3: 'RSWDL Capable' };

  const ActionCriteria = [
    [1, 'CurrentSoftware', 'Current Software'], [2, 'General', 'General'], [3, 'RemoteGeneral', 'Remote General'],
    [4, 'RemoteLimited', 'Remote Limited'], [5, 'RemoteCapable', 'Remote Capable'], [6, 'ServicePackGeneral', 'Service Pack General'],
    [7, 'ServicePackRemoteGeneral', 'Service Pack Remote General'], [8, 'ServicePackRemoteLimited', 'Service Pack Remote Limited'],
    [9, 'ServicePackRemoteCapable', 'Service Pack Remote Capable'], [10, 'HardwareReplacements', 'Hardware Replacements'],
    [11, 'DisplayLanguages', 'Display Languages'], [12, 'AccessoryKits', 'Accessory Kits'], [13, 'ServiceKits', 'Service Kits'],
    [14, 'CampaignKits', 'Campaign Kits'], [15, 'RemoteAccessoryKits', 'Remote Accessory Kits'], [16, 'RemoteServiceKits', 'Remote Service Kits'],
    [17, 'RemoteAdministrativeServiceKits', 'Remote Administrative Service Kits'], [18, 'RemoteCampaignKits', 'Remote Campaign Kits'],
    [19, 'RemoteHardwareKits', 'Remote Hardware Kits'],
  ];
  const actionCriteriaString = (v) => {
    const e = ActionCriteria.find((a) => a[0] === v);
    if (!e) return String(v);
    return v <= 9 ? 'SoftwareReplacements.' + e[1] : e[1];
  };

  const BaselineState = { Open: 1, Closed: 2, DevelopmentReleased: 3, ReadyForProduction: 4, InProduction: 5, Rejected: 6, DeletedUsed: 7, DeletedNeverInProduction: 8, None: 9, Immutable: 10 };
  const BaselineStateNames = { 1: 'Open', 2: 'Closed', 3: 'Development Released', 4: 'Ready For Production', 5: 'In Production', 6: 'Rejected', 7: 'Deleted Used', 8: 'Deleted Never In Production', 9: 'None', 10: 'Immutable' };

  const EA = { Tea2: 0, Tea2Plus: 1, Bea2Body: 2, T3: 3 };
  const EANames = { 0: 'TEA2', 1: 'TEA2+', 2: 'BEA2 Body', 3: 'T3' };
  const ParamEANames = { 0: 'TEA2', 1: 'TEA2+' };

  const Severity = { Error: 0, Warning: 1, Information: 2 };
  const SeverityClass = { 0: 'error', 1: 'warning', 2: 'information' };

  const ConditionType = { AlwaysMatch: 0, Variant: 1, SNote: 2 };

  const Op = {
    AssignString: 0, AssignInt: 1, AssignNullableInt: 2, AssignByte: 3, AssignLong: 4, AssignBool: 5,
    AssignVariant: 6, RemoveVariant: 7, AssignSNote: 8, RemoveSNote: 9, AssignParameter: 10, RemoveParameter: 11,
    AssignHardware: 12, AssignPart: 13, RemovePart: 14, AssignDownloadablePart: 15, RemoveDownloadablePart: 16,
    AssignData: 17, RemoveData: 18, AssignDataPatch: 19, RemoveDataPatch: 20,
    AssignBea2BodyNode: 21, AssignTea2Node: 22, AssignTea2PlusNode: 23, RemoveNode: 24, RemoveHardware: 25,
    ReplaceBea2BodyNode: 30, ReplaceTea2Node: 31, ReplaceTea2PlusNode: 32, ReplaceData: 33, ReplacePart: 34,
    ReplaceDownloadablePart: 35, ReplaceDataPatch: 36, ReplaceHardware: 37, AssignBootloaders: 38,
    AssignT3Node: 41, ReplaceT3Node: 42, // simulator-local operation IDs
    AssignConnectedService: 39, RemoveConnectedService: 40,
  };
  const OpNames = {};
  Object.keys(Op).forEach((k) => { OpNames[Op[k]] = k; });

  const PartOps = {
    Part: { assign: 13, replace: 34, remove: 14 },
    Hardware: { assign: 12, replace: 37, remove: 25 },
    DownloadablePart: { assign: 15, replace: 35, remove: 16 },
    Data: { assign: 17, replace: 33, remove: 18 },
    DataPatch: { assign: 19, replace: 36, remove: 20 },
  };
  const NodeOps = { assign: { 0: 22, 1: 23, 2: 21, 3: 41 }, replace: { 0: 31, 1: 32, 2: 30, 3: 42 }, remove: 24 };

  const NodeStatusLegend = [
    { key: 'released', value: 'Released - the node template version is released for aftermarket use' },
    { key: 'introduced', value: 'Introduced - introduced in production, not yet released' },
    { key: 'prereleaseverification', value: 'Pre release verification - under verification' },
    { key: 'inprogress', value: 'In progress - under development' },
    { key: 'obsolete', value: 'Obsolete - replaced by a newer version' },
    { key: '', value: 'Unknown - no node template status' },
  ];

  const TypeOfRequest = { Product: 0, Software: 1, Hardware: 2, ConversionKit: 3, Language: 4, SpareCab: 5, Breakdown: 6, Unknow: 7 };

  TR.enums = {
    RequestType, RequestTypeNames, RequestTypeKeys, ApuActionCriteria, SoftwareRequestOperation, SoftwareRequestOperationNames, SoftwareRequestOperationKeys,
    Scenario, ScenarioNames, KitScenario, KitScenarioNames, KitScenarioKeys, RemoteNames, ActionCriteria, actionCriteriaString,
    BaselineState, BaselineStateNames, EA, EANames, ParamEANames, Severity, SeverityClass, ConditionType, Op, OpNames, PartOps, NodeOps,
    NodeStatusLegend, TypeOfRequest,
  };
})();
