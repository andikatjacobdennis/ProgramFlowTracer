/* Client-side editable product (ProductViewModel): original + current product JSON, change tracking via deltas,
   requested-node selection, operation selection for VDA update / To Kit, variant / S-note / parameter / node editing. */
(function () {
  'use strict';
  const TR = window.TR;
  const E = TR.enums;
  const M = TR.model;
  const { clone } = TR.util;

  function freshUi(old) {
    return {
      sections: old ? old.sections : { info: false, nodes: true, variants: true, snotes: true, params: true, notifications: true },
      expandedNodes: old ? old.expandedNodes : {},
      selectedNodes: {}, replaceHw: {}, sel: {},
      nodeEditMode: false,
      variantFilter: '', variantExpr: old ? old.variantExpr : '', exprResult: null,
      showVarDesc: old ? old.showVarDesc : false, showSnoteDesc: old ? old.showSnoteDesc : false,
      paramFilter: '', paramView: old ? old.paramView : 'compact',
      flash: null,
    };
  }

  class ProductVM {
    constructor(name) {
      this.name = name || 'product';
      this.original = null;
      this.current = null;
      this.ui = freshUi();
      this._delta = null;
      this.ignoreServicePackChanges = false;
    }
    loaded() { return !!this.current; }
    touch() { this._delta = null; }
    clear() { this.original = null; this.current = null; this.ui = freshUi(this.ui); this.touch(); }
    load(product, opts) {
      opts = opts || {};
      const keepExpanded = this.ui.expandedNodes;
      this.original = M.ensureShape(clone(product));
      this.current = M.ensureShape(clone(product));
      [this.original, this.current].forEach((p) => { p.nodes.sort(M.compareNodes); p.parameters.sort(M.compareParameters); });
      this.ui = freshUi(this.ui);
      this.ui.expandedNodes = keepExpanded;
      if (opts.requestedNodes) this.applyRequestedNodes(opts.requestedNodes);
      this.touch();
      return this;
    }
    applyRequestedNodes(list) {
      const ch = this.chassis();
      (list || []).filter((r) => !r.chassisSeries || TR.chassis.sameChassis(r, ch)).forEach((r) => {
        const k = M.idKey(r.nodeIdentifier);
        if (!this.current.nodes.some((n) => M.nodeKey(n) === k)) return;
        this.ui.selectedNodes[k] = true;
        if (r.previousEcuHardware) {
          const o = this.original.nodes.find((n) => M.nodeKey(n) === k);
          if (o && o.ecuHardware) o.ecuHardware.number = Number(r.previousEcuHardware);
          this.ui.replaceHw[k] = true;
        }
      });
      this.touch();
    }
    info() { return this.current ? this.current.productSpecification.productInformation : {}; }
    chassis() { return M.chassisOf(this.current); }
    chassisString() { return this.current ? M.chassisText(this.current) : ''; }
    contextString() { const i = this.info(); return `${i.productClassId || ''} ${(i.context && i.context.name) || ''}`.trim(); }
    get() {
      if (!this.current) return null;
      const p = clone(this.current);
      p.parameters = p.parameters.filter((x) => x.isFunction || (x.references && x.references[0] && x.references[0].value !== null && x.references[0].value !== undefined));
      p.breakdownInformation = Object.assign({}, p.breakdownInformation, { baseline: undefined });
      delete p.information;
      return p;
    }
    getOriginal() { return this.original ? clone(this.original) : null; }
    delta() {
      if (!this._delta) {
        const cur = this.get();
        const orig = clone(this.original);
        orig.parameters = orig.parameters.filter((x) => x.isFunction || (x.references && x.references[0] && x.references[0].value !== null && x.references[0].value !== undefined));
        this._delta = M.computeDelta(cur, orig);
      }
      return this._delta;
    }
    getDelta() { return clone(this.delta()); }
    dirty() { return this.loaded() && M.hasDelta(this.delta()); }
    applyChanges() { this.original = clone(this.current); this.touch(); }
    applyDelta(delta, applyChanges) {
      if (!delta) return;
      if (applyChanges !== false) this.original = clone(this.current);
      const before = this.current.productSpecification.productInformation;
      const bName = before.baselineName, bGuid = before.baselineGuid;
      M.applyDelta(this.current, clone(delta));
      const ds = delta.productSpecification || {};
      const info = this.current.productSpecification.productInformation;
      if ((ds.baselineGuid && ds.baselineGuid !== bGuid) || (ds.baselineName && ds.baselineName !== bName)) info.baselineUrl = ds.baselineGuid ? TR.server.baselineUrl(ds.baselineGuid) : '';
      if (ds.servicePackName) this.ignoreServicePackChanges = true;
      this.touch();
    }
    mutate(fn) { fn(this.current); this.touch(); }

    // ---------- nodes ----------
    nodeRows() {
      const map = new Map();
      (this.original.nodes || []).forEach((n) => map.set(M.nodeKey(n), { key: M.nodeKey(n), orig: n, cur: null }));
      (this.current.nodes || []).forEach((n) => { const k = M.nodeKey(n); const r = map.get(k) || { key: k, orig: null, cur: null }; r.cur = n; map.set(k, r); });
      const rows = Array.from(map.values());
      rows.forEach((r) => { r.status = this.nodeStatus(r); r.node = r.cur || r.orig; });
      rows.sort((a, b) => M.compareNodes(a.node, b.node));
      return rows;
    }
    nodeStatus(r) {
      if (!r.orig) return 'added';
      if (!r.cur) return 'removed';
      const op = M.nodeAssignOp(r.cur, r.orig);
      if (!op) return '';
      const on = r.orig.nodeTemplateDocument && r.orig.nodeTemplateDocument.number, cn = r.cur.nodeTemplateDocument && r.cur.nodeTemplateDocument.number;
      return on !== cn ? 'replaced' : 'dirty';
    }
    findNode(key) { return this.current.nodes.find((n) => M.nodeKey(n) === key) || null; }
    findOrigNode(key) { return this.original.nodes.find((n) => M.nodeKey(n) === key) || null; }
    removeNode(key) { this.mutate((p) => { p.nodes = p.nodes.filter((n) => M.nodeKey(n) !== key); }); delete this.ui.selectedNodes[key]; }
    undoNode(key) {
      const o = this.findOrigNode(key);
      this.mutate((p) => {
        p.nodes = p.nodes.filter((n) => M.nodeKey(n) !== key);
        if (o) { p.nodes.push(clone(o)); p.nodes.sort(M.compareNodes); }
      });
      delete this.ui.replaceHw[key];
    }
    addNode(node) { this.mutate((p) => { p.nodes = p.nodes.filter((n) => M.nodeKey(n) !== M.nodeKey(node)); p.nodes.push(node); p.nodes.sort(M.compareNodes); }); }
    replaceNode(node) { this.addNode(node); }
    setSlot(key, slot, value) { this.mutate(() => { const n = this.findNode(key); if (n) n[slot] = value; }); }
    undoSlot(key, slot) { const o = this.findOrigNode(key); this.setSlot(key, slot, o ? clone(o[slot]) : null); }
    listRows(r, slot, type) {
      const o = (r.orig && r.orig[slot]) || [], c = (r.cur && r.cur[slot]) || [];
      const keyOf = (x) => String(x.index !== undefined && x.index !== null ? x.index : x.number);
      const map = new Map();
      o.forEach((x) => map.set(keyOf(x), { id: keyOf(x), orig: x, cur: null }));
      c.forEach((x) => { const k = keyOf(x); const e = map.get(k) || { id: k, orig: null, cur: null }; e.cur = x; map.set(k, e); });
      return Array.from(map.values()).map((e) => Object.assign(e, { status: !e.orig ? 'added' : !e.cur ? 'removed' : M.partsEqual(e.cur, e.orig, type) ? '' : 'replaced', part: e.cur || e.orig }))
        .sort((a, b) => (Number(a.part.index) || 0) - (Number(b.part.index) || 0));
    }
    setListItem(key, slot, id, value) {
      this.mutate(() => {
        const n = this.findNode(key);
        if (!n) return;
        n[slot] = n[slot] || [];
        const i = n[slot].findIndex((x) => String(x.index !== undefined && x.index !== null ? x.index : x.number) === String(id));
        if (i >= 0) n[slot][i] = value; else n[slot].push(value);
      });
    }
    removeListItem(key, slot, id) {
      this.mutate(() => {
        const n = this.findNode(key);
        if (n) n[slot] = (n[slot] || []).filter((x) => String(x.index !== undefined && x.index !== null ? x.index : x.number) !== String(id));
      });
    }
    undoListItem(key, slot, id) {
      const o = this.findOrigNode(key);
      const ov = o && (o[slot] || []).find((x) => String(x.index !== undefined && x.index !== null ? x.index : x.number) === String(id));
      if (ov) this.setListItem(key, slot, id, clone(ov)); else this.removeListItem(key, slot, id);
    }
    addListItem(key, slot, value) {
      this.mutate(() => {
        const n = this.findNode(key);
        if (!n) return;
        n[slot] = n[slot] || [];
        const o = this.findOrigNode(key);
        const all = n[slot].concat((o && o[slot]) || []);
        value.index = all.reduce((m, x) => Math.max(m, Number(x.index) || 0), -1) + 1;
        n[slot].push(value);
      });
    }
    requestedNodes() {
      if (!this.current) return [];
      const ch = this.chassis();
      return this.current.nodes.filter((n) => this.ui.selectedNodes[M.nodeKey(n)]).map((n) => {
        const k = M.nodeKey(n);
        const o = this.findOrigNode(k);
        return { nodeIdentifier: clone(n.nodeIdentifier), previousEcuHardware: this.ui.replaceHw[k] && o && o.ecuHardware && n.ecuHardware && Number(o.ecuHardware.number) !== Number(n.ecuHardware.number) ? Number(o.ecuHardware.number) : null, chassisSeries: ch.chassisSeries, chassisNumber: ch.chassisNumber };
      });
    }

    // ---------- variants ----------
    variantRows() {
      const o = this.original.productSpecification.variants, c = this.current.productSpecification.variants;
      const ok = new Set(o.map(M.variantKey)), ck = new Set(c.map(M.variantKey));
      const rows = [];
      c.forEach((v) => rows.push({ v, status: ok.has(M.variantKey(v)) ? '' : 'added' }));
      o.forEach((v) => { if (!ck.has(M.variantKey(v))) rows.push({ v, status: 'removed' }); });
      rows.filter((r) => r.status === 'added' && r.v.familyType !== 'E').forEach((a) => {
        const rem = rows.find((r) => r.status === 'removed' && !r.replacedBy && r.v.familyId === a.v.familyId);
        if (rem) { a.replaces = rem.v; rem.replacedBy = a.v; a.status = 'replaced'; }
      });
      rows.sort((a, b) => ((a.v.symbol || a.v.idVar6) < (b.v.symbol || b.v.idVar6) ? -1 : 1));
      return rows;
    }
    hasVariant(v) { return this.current.productSpecification.variants.some((x) => M.variantKey(x) === M.variantKey(v)); }
    addVariant(v) {
      this.mutate((p) => {
        const list = p.productSpecification.variants;
        if (list.some((x) => M.variantKey(x) === M.variantKey(v))) return;
        if (v.familyType !== 'E') p.productSpecification.variants = list.filter((x) => x.familyId !== v.familyId);
        p.productSpecification.variants.push(clone(v));
        p.productSpecification.variants.sort((a, b) => ((a.symbol || a.idVar6) < (b.symbol || b.idVar6) ? -1 : 1));
      });
    }
    removeVariant(v) { this.mutate((p) => { p.productSpecification.variants = p.productSpecification.variants.filter((x) => M.variantKey(x) !== M.variantKey(v)); }); }
    restoreVariant(v) {
      const orig = this.original.productSpecification.variants;
      const inOrig = orig.find((x) => M.variantKey(x) === M.variantKey(v));
      this.mutate((p) => {
        let list = p.productSpecification.variants;
        if (inOrig) {
          if (v.familyType !== 'E') list = list.filter((x) => x.familyId !== v.familyId || orig.some((y) => M.variantKey(y) === M.variantKey(x)));
          if (!list.some((x) => M.variantKey(x) === M.variantKey(v))) list.push(clone(inOrig));
        } else {
          list = list.filter((x) => M.variantKey(x) !== M.variantKey(v));
          const fam = orig.filter((x) => x.familyId === v.familyId && v.familyType !== 'E');
          fam.forEach((x) => { if (!list.some((y) => M.variantKey(y) === M.variantKey(x))) list.push(clone(x)); });
        }
        p.productSpecification.variants = list.sort((a, b) => ((a.symbol || a.idVar6) < (b.symbol || b.idVar6) ? -1 : 1));
      });
    }
    setFamilyVariants(familyId, selected) {
      this.mutate((p) => {
        p.productSpecification.variants = p.productSpecification.variants.filter((x) => x.familyId !== familyId).concat(clone(selected));
        p.productSpecification.variants.sort((a, b) => ((a.symbol || a.idVar6) < (b.symbol || b.idVar6) ? -1 : 1));
      });
    }
    /** Vespa2 merge: replace each missing variant, then remove those that are not in the list. */
    mergeVariants(list) {
      list.forEach((v) => { if (!this.hasVariant(v)) this.addVariant(v); });
      const keys = new Set(list.map(M.variantKey));
      this.mutate((p) => { p.productSpecification.variants = p.productSpecification.variants.filter((x) => keys.has(M.variantKey(x))); });
    }

    // ---------- S-notes ----------
    sNoteRows() {
      const o = this.original.productSpecification.sNotes, c = this.current.productSpecification.sNotes;
      const ok = new Set(o.map((s) => s.value)), ck = new Set(c.map((s) => s.value));
      const rows = c.map((s) => ({ s, status: ok.has(s.value) ? '' : 'added' })).concat(o.filter((s) => !ck.has(s.value)).map((s) => ({ s, status: 'removed' })));
      return rows.sort((a, b) => (a.s.value < b.s.value ? -1 : 1));
    }
    addSNote(s) { this.mutate((p) => { if (!p.productSpecification.sNotes.some((x) => x.value === s.value)) { p.productSpecification.sNotes.push(clone(s)); p.productSpecification.sNotes.sort((a, b) => (a.value < b.value ? -1 : 1)); } }); }
    removeSNote(s) { this.mutate((p) => { p.productSpecification.sNotes = p.productSpecification.sNotes.filter((x) => x.value !== s.value); }); }
    restoreSNote(s) {
      const o = this.original.productSpecification.sNotes.find((x) => x.value === s.value);
      if (o) this.addSNote(o); else this.removeSNote(s);
    }
    mergeSNotes(list) {
      list.forEach((s) => this.addSNote(s));
      const keys = new Set(list.map((s) => s.value));
      this.mutate((p) => { p.productSpecification.sNotes = p.productSpecification.sNotes.filter((x) => keys.has(x.value)); });
    }

    // ---------- parameters ----------
    paramRows() {
      const map = new Map();
      this.original.parameters.forEach((x) => map.set(M.paramKey(x), { key: M.paramKey(x), orig: x, cur: null }));
      this.current.parameters.forEach((x) => { const k = M.paramKey(x); const r = map.get(k) || { key: k, orig: null, cur: null }; r.cur = x; map.set(k, r); });
      return Array.from(map.values()).map((r) => Object.assign(r, { p: r.cur || r.orig, status: !r.orig ? 'added' : !r.cur ? 'removed' : M.paramEqual(r.cur, r.orig) ? '' : 'replaced' }))
        .sort((a, b) => M.compareParameters(a.p, b.p));
    }
    setParam(p) { this.mutate((pr) => { const i = pr.parameters.findIndex((x) => M.paramKey(x) === M.paramKey(p)); if (i >= 0) pr.parameters[i] = clone(p); else pr.parameters.push(clone(p)); pr.parameters.sort(M.compareParameters); }); }
    removeParam(key) { this.mutate((pr) => { pr.parameters = pr.parameters.filter((x) => M.paramKey(x) !== key); }); }
    restoreParam(key) { const o = this.original.parameters.find((x) => M.paramKey(x) === key); if (o) this.setParam(o); else this.removeParam(key); }

    // ---------- notifications ----------
    allNotifications() {
      if (!this.current) return [];
      const out = [];
      const p = this.current;
      (p.breakdownInformation.notifications || []).forEach((n) => out.push(Object.assign({ where: 'Breakdown' }, n)));
      (p.productSpecification.productInformation.notifications || []).forEach((n) => out.push(Object.assign({ where: 'Product information', section: 'info' }, n)));
      p.nodes.forEach((nd) => {
        (nd.notifications || []).forEach((n) => out.push(Object.assign({ where: nd.name, nodeKey: M.nodeKey(nd), section: 'nodes' }, n)));
        M.singles(nd.electricalArchitecture).forEach(([k, , label]) => ((nd[k] && nd[k].notifications) || []).forEach((n) => out.push(Object.assign({ where: `${nd.name} / ${label}`, nodeKey: M.nodeKey(nd), section: 'nodes' }, n))));
        M.lists(nd.electricalArchitecture).forEach(([k, , label]) => (nd[k] || []).forEach((x) => (x.notifications || []).forEach((n) => out.push(Object.assign({ where: `${nd.name} / ${label}`, nodeKey: M.nodeKey(nd), section: 'nodes' }, n)))));
      });
      p.parameters.forEach((x) => (x.notifications || []).forEach((n) => out.push(Object.assign({ where: `Parameter ${x.code}`, paramKey: M.paramKey(x), section: 'params' }, n))));
      return out.sort((a, b) => (a.severity || 0) - (b.severity || 0));
    }

    // ---------- operation selection (VDA update / To Kit) ----------
    static opKey(op) {
      if ([21, 22, 23, 41, 38].includes(op.type)) return 'node:' + M.idKey(op.nodeIdentifier);
      if (op.type === 24) return 'node:' + M.idKey(op.identifier);
      if ([30, 31, 32, 42].includes(op.type)) return 'node:' + M.idKey(op.value.nodeIdentifier);
      if (op.type === 10 || op.type === 11) return 'param:' + M.paramKey(op.value);
      if (op.type === 6 || op.type === 7) return 'var:' + M.variantKey(op.value);
      if (op.type === 8 || op.type === 9) return 'snote:' + op.value.value;
      return 'op:' + op.type;
    }
    isTea2Only() { const c = this.info().context; return !!(c && c.isOnlyTea2); }
    partOpKeys(op) {
      const nk = M.idKey(op.nodeIdentifier);
      const keys = [];
      M.singles(0).forEach(([k]) => { if (op[k]) keys.push(`part:${nk}:${k}:`); });
      M.lists(0).forEach(([k]) => (op[k] || []).forEach((o, i) => keys.push(`part:${nk}:${k}:${i}`)));
      return keys;
    }
    selectAll() {
      const d = this.delta();
      const sel = {};
      const rows = this.variantRows();
      d.nodes.forEach((op) => {
        sel[ProductVM.opKey(op)] = true;
        if (op.type === 23) { if (op.primaryBootloader) sel['pbl:' + M.idKey(op.nodeIdentifier)] = true; if (op.secondaryBootloader) sel['sbl:' + M.idKey(op.nodeIdentifier)] = true; }
        if (op.type === 22 && this.isTea2Only()) this.partOpKeys(op).forEach((k) => { sel[k] = true; });
      });
      d.parameters.forEach((op) => { sel[ProductVM.opKey(op)] = true; });
      d.productSpecification.variants.forEach((op) => {
        if (op.type === 7 && rows.some((r) => r.status === 'removed' && r.replacedBy && M.variantKey(r.v) === M.variantKey(op.value))) return;
        sel[ProductVM.opKey(op)] = true;
      });
      d.productSpecification.sNotes.forEach((op) => { sel[ProductVM.opKey(op)] = true; });
      this.ui.sel = sel;
    }
    deselectAll() { this.ui.sel = {}; }
    deselectAllRemoveOperations() {
      const d = this.delta();
      d.nodes.filter((o) => o.type === 24).forEach((o) => delete this.ui.sel[ProductVM.opKey(o)]);
      d.parameters.filter((o) => o.type === 11).forEach((o) => delete this.ui.sel[ProductVM.opKey(o)]);
      d.productSpecification.variants.filter((o) => o.type === 7).forEach((o) => delete this.ui.sel[ProductVM.opKey(o)]);
      d.productSpecification.sNotes.filter((o) => o.type === 9).forEach((o) => delete this.ui.sel[ProductVM.opKey(o)]);
    }
    someSelected() { return Object.keys(this.ui.sel).some((k) => this.ui.sel[k]); }
    getDeltaSelected(applySubDiffs) {
      const d = this.delta();
      const s = this.ui.sel;
      const out = M.emptyDelta();
      d.nodes.forEach((op) => {
        const k = ProductVM.opKey(op);
        if (op.type === 22 && this.isTea2Only()) {
          const nk = M.idKey(op.nodeIdentifier);
          const f = { type: 22, nodeIdentifier: op.nodeIdentifier, documentNumber: op.documentNumber };
          let any = false;
          M.singles(0).forEach(([sk]) => { if (op[sk] && s[`part:${nk}:${sk}:`]) { f[sk] = op[sk]; any = true; } });
          M.lists(0).forEach(([lk]) => { const sub = (op[lk] || []).filter((o, i) => s[`part:${nk}:${lk}:${i}`]); if (sub.length) { f[lk] = sub; any = true; } });
          if (any) out.nodes.push(f);
          return;
        }
        if (s[k]) { out.nodes.push(clone(op)); return; }
        if (op.type === 23 && applySubDiffs) {
          const nk = M.idKey(op.nodeIdentifier);
          const b = { type: E.Op.AssignBootloaders, nodeIdentifier: clone(op.nodeIdentifier) };
          if (s['pbl:' + nk] && op.primaryBootloader) b.primaryBootloader = clone(op.primaryBootloader);
          if (s['sbl:' + nk] && op.secondaryBootloader) b.secondaryBootloader = clone(op.secondaryBootloader);
          if (b.primaryBootloader || b.secondaryBootloader) out.nodes.push(b);
        }
      });
      d.parameters.forEach((op) => { if (s[ProductVM.opKey(op)]) out.parameters.push(clone(op)); });
      d.productSpecification.variants.forEach((op) => { if (s[ProductVM.opKey(op)]) out.productSpecification.variants.push(clone(op)); });
      d.productSpecification.sNotes.forEach((op) => { if (s[ProductVM.opKey(op)]) out.productSpecification.sNotes.push(clone(op)); });
      return out;
    }
    getVdaDelta() {
      const sel = this.getDeltaSelected(false);
      sel.nodes = sel.nodes.map((op) => {
        if (op.type === 24 || [30, 31, 32, 42].includes(op.type)) return op;
        const n = this.current.nodes.find((x) => M.idMatch(x.nodeIdentifier, op.nodeIdentifier));
        return { type: E.NodeOps.replace[n.electricalArchitecture], value: clone(n) };
      });
      const info = clone(this.info());
      delete info.notifications;
      return { productInformation: info, assignProduct: sel };
    }
    getKitDelta() {
      const info = clone(this.info());
      delete info.notifications;
      return { productInformation: info, assignProduct: this.getDeltaSelected(true) };
    }
    counts() {
      const d = this.delta();
      return M.deltaCounts(d);
    }
  }

  TR.ProductVM = ProductVM;
})();
