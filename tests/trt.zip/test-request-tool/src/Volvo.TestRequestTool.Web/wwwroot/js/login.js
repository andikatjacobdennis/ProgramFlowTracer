/* The sign-in page (login.html). It only collects what the person types and sends it to the server
 * (POST /api/v1/auth/login), which checks it and sets an HttpOnly session cookie; no credential is kept or checked here.
 * Afterwards the page goes back to where the person was going (?returnUrl=, a path on this site only). */
(function () {
  'use strict';
  if (window.TRBoot && window.TRBoot.ready) window.TRBoot.ready();
  const $ = (id) => document.getElementById(id);
  const form = $('lg-form'), login = $('lg-login'), password = $('lg-password'), submit = $('lg-submit'), error = $('lg-error'), notice = $('lg-notice');
  const params = new URLSearchParams(location.search);

  /** A path on this site, never another site ("//host", "/\host", "https://…"); anything else goes to the start page. */
  function safeReturn(url) {
    return typeof url === 'string' && /^\/(?![\/\\])/.test(url) && !/^\/login\b/i.test(url) ? url : '/';
  }
  const back = safeReturn(params.get('returnUrl'));

  const reasons = {
    expired: 'Your session has ended. Sign in again to continue.',
    'signed-out': 'You have signed out.',
  };
  if (reasons[params.get('reason')]) { notice.textContent = reasons[params.get('reason')]; notice.hidden = false; }

  function fieldError(input, text) {
    const p = $(input.id + '-error');
    p.textContent = text || '';
    p.hidden = !text;
    input.setAttribute('aria-invalid', text ? 'true' : 'false');
  }
  function showError(text) { error.textContent = text || ''; error.hidden = !text; }
  function busy(on) {
    submit.disabled = on;
    submit.classList.toggle('is-busy', on);
    submit.querySelector('.lg-submit-text').textContent = on ? 'Signing in…' : 'Sign in';
    form.setAttribute('aria-busy', on ? 'true' : 'false');
  }
  /** Checks both fields; returns the first one that needs attention. */
  function validate() {
    const name = login.value.trim();
    fieldError(login, name ? (name.length > 200 ? 'Use at most 200 characters.' : '') : 'Enter your user name or email.');
    fieldError(password, password.value ? '' : 'Enter your password.');
    return !name || name.length > 200 ? login : !password.value ? password : null;
  }
  login.addEventListener('input', () => { if (login.getAttribute('aria-invalid') === 'true') validate(); showError(''); });
  password.addEventListener('input', () => { if (password.getAttribute('aria-invalid') === 'true') validate(); showError(''); });

  $('lg-reveal').addEventListener('click', (e) => {
    const show = password.type === 'password';
    password.type = show ? 'text' : 'password';
    e.currentTarget.textContent = show ? 'Hide' : 'Show';
    e.currentTarget.setAttribute('aria-pressed', String(show));
    password.focus();
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    showError('');
    const first = validate();
    if (first) { first.focus(); return; }
    busy(true);
    try {
      const r = await fetch('/api/v1/auth/login', {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json', 'X-Studio-Request': '1' },
        body: JSON.stringify({ login: login.value.trim(), password: password.value }),
      });
      if (r.ok) { password.value = ''; location.replace(back); return; }
      const body = await r.json().catch(() => ({}));
      const messages = {
        401: 'The user name or password is incorrect.',
        403: body.detail || 'This account cannot sign in. Ask an administrator.',
        429: 'Too many attempts. Wait a minute, then try again.',
      };
      showError(messages[r.status] || body.detail || 'Signing in did not work. Try again in a moment.');
      password.select();
      password.focus();
    } catch (err) {
      showError('The server cannot be reached. Check your connection and try again.');
    } finally {
      busy(false);
    }
  });
  login.focus();
})();
