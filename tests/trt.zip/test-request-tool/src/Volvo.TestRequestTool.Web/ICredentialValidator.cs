using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Proves who someone is from what they typed on the sign-in page. Returns the account to use the first time that person
    /// signs in (afterwards their record in the repository's users collection wins), or null when the credentials are wrong.
    /// The first implementation checks the accounts in the settings (<see cref="ConfiguredCredentials"/>); a database or
    /// directory check replaces it by registering another implementation. Single sign-on (OpenID Connect) replaces the sign-in
    /// page instead: see docs/sign-in.md.
    /// </summary>
    public interface ICredentialValidator
    {
        Task<UserAccount?> ValidateAsync(string login, string password, CancellationToken ct);
    }
}
