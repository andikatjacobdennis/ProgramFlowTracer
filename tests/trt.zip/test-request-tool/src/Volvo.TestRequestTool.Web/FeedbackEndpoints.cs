using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Feedback from the Feedback page: anyone signed in can send it and see their own; administrators see everyone's and mark
    /// it as read or done. Feedback is stored with the rest of the workspace and never leaves the server.
    /// </summary>
    public static class FeedbackEndpoints
    {
        public static readonly string[] Kinds = ["Idea", "Problem", "Praise", "Question"];
        public static readonly string[] Statuses = ["New", "Read", "Done"];
        private const int MaxMessage = 4000, MaxContext = 4000;

        public static RouteGroupBuilder MapFeedback(this RouteGroupBuilder api)
        {
            api.MapPost("/feedback", async (SendFeedback body, HttpContext ctx, IWorkspaceStore store, TimeProvider clock, CancellationToken ct) =>
            {
                var kind = Kinds.FirstOrDefault(k => string.Equals(k, body.Kind, StringComparison.OrdinalIgnoreCase))
                    ?? throw new RequestFault(400, "feedback_kind", "Choose Idea, Problem, Praise or Question.");
                var message = (body.Message ?? "").Trim();
                if (message.Length is 0 or > MaxMessage)
                {
                    throw new RequestFault(400, "feedback_message", $"Write a message of 1 to {MaxMessage} characters.");
                }

                var rating = body.Rating ?? 0;
                if (rating is < 0 or > 5)
                {
                    throw new RequestFault(400, "feedback_rating", "The rating is from 1 to 5, or 0 for none.");
                }

                if (body.Context is not null && body.Context.ToJsonString().Length > MaxContext)
                {
                    throw new RequestFault(400, "feedback_context", "The page details are too long.");
                }

                var actor = ActorFactory.From(ctx.User);
                var item = new FeedbackItem(Guid.NewGuid(), actor.Id, actor.DisplayName, kind, rating, message, Trim(body.Page, 200), body.Context, clock.GetUtcNow());
                return Results.Created("/api/v1/feedback/" + item.Id, await store.SaveFeedbackAsync(item, ct));
            }).RequireRateLimiting("feedback");
            api.MapGet("/feedback/mine", async (HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
                await store.FeedbackAsync(ActorFactory.From(ctx.User).Id, ct));
            api.MapGet("/admin/feedback", async (IWorkspaceStore store, CancellationToken ct) => await store.FeedbackAsync(null, ct)).RequireAuthorization("Admin");
            api.MapPut("/admin/feedback/{id:guid}", async (Guid id, UpdateFeedback body, IWorkspaceStore store, CancellationToken ct) =>
            {
                var status = Statuses.FirstOrDefault(s => string.Equals(s, body.Status, StringComparison.OrdinalIgnoreCase))
                    ?? throw new RequestFault(400, "feedback_status", "Choose New, Read or Done.");
                return await store.SetFeedbackStatusAsync(id, status, ct) ?? throw new RequestFault(404, "feedback_missing", "Feedback was not found.");
            }).RequireAuthorization("Admin");
            return api;
        }

        private static string? Trim(string? text, int max) => string.IsNullOrWhiteSpace(text) ? null : text.Length <= max ? text : text[..max];
    }
}
