namespace Volvo.TestRequestTool.Web
{
    /// <summary>A page of the user list with the counts the page shows (by role for the current search, enabled, everything).</summary>
    public sealed record UserPage(int Total, int Skip, int Take, IReadOnlyList<UserRow> Items, IReadOnlyDictionary<string, int> Roles, int Enabled, int All);
}
