using System.Text.Json.Nodes;
using Microsoft.FeatureManagement.FeatureFilters;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>Who the caller is for targeting: their user id, and as groups their roles and the ids of their teams.</summary>
    public sealed class TestRequestTargeting : ITargetingContextAccessor
    {
        private readonly IHttpContextAccessor _http;
        private readonly IWorkspaceStore _store;

        public TestRequestTargeting(IHttpContextAccessor http, IWorkspaceStore store)
        {
            _http = http;
            _store = store;
        }

        public async ValueTask<TargetingContext> GetContextAsync()
        {
            var user = _http.HttpContext?.User;
            var id = user?.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value ?? user?.FindFirst("sub")?.Value ?? "anonymous";
            var roles = user?.FindAll(System.Security.Claims.ClaimTypes.Role).Select(c => c.Value).Concat(user.FindAll("role").Select(c => c.Value)).Distinct().ToArray() ?? [];
            return new TargetingContext { UserId = id, Groups = await GroupsFor(_store, id, roles, _http.HttpContext?.RequestAborted ?? default) };
        }

        public static async Task<string[]> GroupsFor(IWorkspaceStore store, string userId, IEnumerable<string> roles, CancellationToken ct)
        {
            var teams = (await store.SettingAsync("teams", ct))?.Value["teams"]?.AsArray().OfType<JsonObject>().Where(t => t.A("members").Any(m => m?.ToString() == userId)).Select(t => "team:" + t.S("id")) ?? [];
            return roles.Select(r => "role:" + r).Concat(teams).ToArray();
        }
    }
}
