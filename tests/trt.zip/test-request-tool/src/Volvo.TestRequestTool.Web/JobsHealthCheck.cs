using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;
using Volvo.TestRequestTool.Application;

namespace Volvo.TestRequestTool.Web
{
    public sealed class JobsHealthCheck : IHealthCheck
    {
        private readonly IWorkspaceStore _store;
        private readonly IOptions<JobOptions> _options;
        private readonly TimeProvider _clock;

        public JobsHealthCheck(IWorkspaceStore store, IOptions<JobOptions> options, TimeProvider clock)
        {
            _store = store;
            _options = options;
            _clock = clock;
        }

        public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken ct = default)
        {
            var o = _options.Value;
            var load = await _store.JobLoadAsync("-", ct);
            var age = load.OldestQueued is { } t ? _clock.GetUtcNow() - t : TimeSpan.Zero;
            var data = new Dictionary<string, object> { ["queued"] = load.Queued, ["running"] = load.Running, ["oldestQueuedSeconds"] = Math.Round(age.TotalSeconds), ["workers"] = o.Workers, ["maxQueued"] = o.MaxQueued };
            if (!JobWorker.Started)
            {
                return HealthCheckResult.Unhealthy("Job workers have not started.", data: data);
            }

            if (load.Queued >= o.MaxQueued * 0.8 || age > TimeSpan.FromMinutes(5))
            {
                return HealthCheckResult.Degraded("The job queue is filling up or old.", data: data);
            }

            return HealthCheckResult.Healthy(o.Workers == 0 ? "API-only instance: jobs run elsewhere." : "Jobs flow.", data);
        }
    }
}
