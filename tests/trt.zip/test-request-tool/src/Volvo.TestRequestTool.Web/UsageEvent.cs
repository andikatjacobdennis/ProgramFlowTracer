namespace Volvo.TestRequestTool.Web
{
    /// <summary>One recorded interaction: a kind and a short name from a fixed vocabulary, never content or typed text.</summary>
    public sealed record UsageEvent(string E, string K, double? Ms, DateTimeOffset At);
}
