namespace Volvo.TestRequestTool.Web
{
    public sealed record UsageIn([property: System.ComponentModel.DataAnnotations.StringLength(10)] string E, [property: System.ComponentModel.DataAnnotations.StringLength(60)] string? K, double? Ms);
}
