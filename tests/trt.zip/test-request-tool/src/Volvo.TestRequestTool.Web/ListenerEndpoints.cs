using System.Text;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// The request listener, simulated (Request.Listener in swb-stable1): every message type and version it handles, their
    /// XSDs, a sample request per contract, and sending a message. A message is checked against its request contract, handled
    /// when the tool simulates its type, and the reply is checked against the reply contract.
    /// </summary>
    public static class ListenerEndpoints
    {
        private const int MaxBody = 4 * 1024 * 1024;

        public static RouteGroupBuilder MapListener(this RouteGroupBuilder api)
        {
            var listener = api.MapGroup("/listener").WithTags("Listener");

            listener.MapGet("", async (HttpContext ctx, ListenerDispatcher dispatcher, ListenerVehicles vehicles, CancellationToken ct) => new
            {
                source = "Request.Listener (swb-stable1) and SoftwareBreakdown.Contracts",
                vehicles = (await vehicles.ReadableAsync(ActorFactory.From(ctx.User), ct)).Select(v => new
                {
                    id = v.Id,
                    series = v.Info.S("chassisSeries"),
                    number = v.Info.S("chassisNumber"),
                    productClass = v.Info.S("productClassId"),
                    context = v.Info["context"].S("name"),
                }),
                messageTypes = dispatcher.Contracts.MessageTypes.Select(m => new
                {
                    key = m.Key,
                    m.MessageType,
                    m.Version,
                    m.Name,
                    m.Title,
                    m.About,
                    m.Area,
                    m.Handler,
                    m.Request,
                    m.Reply,
                    m.ErrorReply,
                    m.NameAssumed,
                    simulated = dispatcher.IsSimulated(m),
                    fromVehicle = dispatcher.HasExample(m),
                }),
            }).WithSummary("Every message type and version the listener handles, with its request and reply contracts.");

            listener.MapGet("/schemas/{file}", (string file, ListenerDispatcher dispatcher) =>
                dispatcher.Contracts.Schema(file) is { } text
                    ? Results.Text(text, "application/xml", Encoding.UTF8)
                    : throw new RequestFault(404, "schema_missing", $"There is no contract {file}."))
                .WithSummary("The text of one XSD.");

            listener.MapGet("/{messageType}/{version}/sample", async (string messageType, string version, string? vehicle, HttpContext ctx, ListenerDispatcher dispatcher, ListenerVehicles vehicles, CancellationToken ct) =>
            {
                var type = dispatcher.Contracts.Find(messageType, version)
                    ?? throw new RequestFault(404, "message_type_unknown", $"Unhandled message type and version {messageType}_{version}.");
                if (!string.IsNullOrWhiteSpace(vehicle))
                {
                    // vehicle is "SERIES|NUMBER", as the vehicle ids are.
                    var parts = vehicle.Split('|');
                    var product = parts.Length == 2 ? await vehicles.FindAsync(parts[0], parts[1], ActorFactory.From(ctx.User), ct) : null;
                    var built = product is null ? null : dispatcher.ExampleText(type, product)
                        ?? throw new RequestFault(404, "example_missing", $"The tool cannot write a {type.Key} request for a vehicle yet.");
                    if (built is null)
                    {
                        throw new RequestFault(404, "vehicle_missing", "There is no such vehicle, or it is outside your vehicle contexts.");
                    }

                    return Results.Text(built, type.Request is { Json: true } ? "application/json" : "application/xml", Encoding.UTF8);
                }

                if (type.Request is null)
                {
                    return Results.Text(string.Empty, "text/plain", Encoding.UTF8);
                }

                if (!type.Request.CanValidate)
                {
                    throw new RequestFault(404, "contract_missing", type.Request.Json
                        ? $"{type.Key} takes JSON: use New request › {type.Title}."
                        : $"SoftwareBreakdown.Contracts has no request contract for {type.Key}.");
                }

                var sample = dispatcher.Contracts.Sample(type.Request);
                return Results.Text(sample.Declaration + Environment.NewLine + sample.Root, "application/xml", Encoding.UTF8);
            }).WithSummary("The smallest request the contract accepts, or with ?vehicle=SERIES|NUMBER a request for that vehicle.");

            listener.MapPost("/{messageType}/{version}", async (string messageType, string version, HttpRequest request, HttpContext ctx, ListenerDispatcher dispatcher, CancellationToken ct) =>
            {
                if (request.ContentLength > MaxBody)
                {
                    throw new RequestFault(413, "message_too_large", "The message is larger than 4 MB.");
                }

                using var reader = new StreamReader(request.Body, Encoding.UTF8);
                var body = await reader.ReadToEndAsync(ct);
                if (body.Length > MaxBody)
                {
                    throw new RequestFault(413, "message_too_large", "The message is larger than 4 MB.");
                }

                var actor = ActorFactory.From(ctx.User);
                var header = request.Headers["X-Sender-Id"].FirstOrDefault();
                var sender = header is { Length: > 0 and <= 100 } ? header : actor.Id;
                return await dispatcher.DispatchAsync(messageType, version, body, actor, sender, ct);
            }).RequireAuthorization("Operator").RequireRateLimiting("simulation")
                .WithSummary("Send a message to the listener: the body as the listener takes it (XML, or JSON for the T3 services).");
            return api;
        }
    }
}
