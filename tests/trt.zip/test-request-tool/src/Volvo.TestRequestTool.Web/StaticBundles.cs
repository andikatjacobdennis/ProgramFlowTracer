using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// One request for the scripts and one for the stylesheets instead of about a hundred: the app page (index.html) lists
    /// its files in order; they are joined into <c>/bundle/app.&lt;hash&gt;.js</c> and <c>/bundle/app.&lt;hash&gt;.css</c>,
    /// compressed once with Brotli and gzip, and served with a one-year immutable cache. The hash changes whenever a file
    /// changes, so the browser never runs a stale copy and never asks again for an unchanged one. The page itself is served
    /// from memory with those two tags in place of the long list (and revalidated on every visit).
    /// When a source file changes on disk (editing in Visual Studio), the bundles are rebuilt on the next page load.
    /// Performance:Bundle=false serves the files one by one, as written, for debugging.
    /// </summary>
    public sealed partial class StaticBundles
    {
        private readonly IWebHostEnvironment _env;
        private readonly ILogger<StaticBundles> _log;
        private sealed record Built(string Page, string PageTag, Asset Script, Asset Style, DateTime Stamp);
        public sealed record Asset(string Path, byte[] Raw, byte[] Brotli, byte[] Gzip, string ContentType, string Tag);
        private readonly object _gate = new();
        private Built? _built;
        private long _checkedAt;

        public StaticBundles(IWebHostEnvironment env, ILogger<StaticBundles> log)
        {
            _env = env;
            _log = log;
        }

        [GeneratedRegex("""^\s*<script defer src="(?<src>[^"]+)"></script>\s*$""", RegexOptions.Multiline)] private static partial Regex ScriptTag();
        [GeneratedRegex("""^\s*<link rel="stylesheet" href="(?<href>css/[^"]+)">\s*$""", RegexOptions.Multiline)] private static partial Regex StyleTag();

        private string Root => _env.WebRootPath;
        private string IndexPath => Path.Combine(Root, "index.html");

        /// <summary>The current bundles, rebuilt when index.html or one of its files changed (checked at most once a second).</summary>
        private Built Current()
        {
            var now = Environment.TickCount64;
            var b = _built;
            if (b is not null && now - Interlocked.Read(ref _checkedAt) < 1000)
            {
                return b;
            }

            Interlocked.Exchange(ref _checkedAt, now);
            var stamp = Stamp();
            if (b is not null && b.Stamp == stamp)
            {
                return b;
            }

            lock (_gate)
            {
                if (_built is not null && _built.Stamp == stamp)
                {
                    return _built;
                }

                var started = System.Diagnostics.Stopwatch.GetTimestamp();
                _built = Build(stamp);
                _log.LogInformation("Bundled the app's scripts ({Js:0} KB, {JsBr:0} KB compressed) and styles ({Css:0} KB, {CssBr:0} KB compressed) in {Ms:0} ms",
                    _built.Script.Raw.Length / 1024.0, _built.Script.Brotli.Length / 1024.0, _built.Style.Raw.Length / 1024.0, _built.Style.Brotli.Length / 1024.0, System.Diagnostics.Stopwatch.GetElapsedTime(started).TotalMilliseconds);
                return _built;
            }
        }

        /// <summary>The newest write time of index.html and every file it lists.</summary>
        private DateTime Stamp()
        {
            var page = File.ReadAllText(IndexPath);
            var newest = File.GetLastWriteTimeUtc(IndexPath);
            foreach (var f in ScriptTag().Matches(page).Select(m => m.Groups["src"].Value).Concat(StyleTag().Matches(page).Select(m => m.Groups["href"].Value)))
            {
                var t = File.GetLastWriteTimeUtc(Path.Combine(Root, f));
                if (t > newest)
                {
                    newest = t;
                }
            }
            return newest;
        }

        private Built Build(DateTime stamp)
        {
            var page = File.ReadAllText(IndexPath);
            var scripts = ScriptTag().Matches(page).Select(m => m.Groups["src"].Value).ToArray();
            var styles = StyleTag().Matches(page).Select(m => m.Groups["href"].Value).ToArray();
            // Each script is its own statement list; the separator keeps a file without a final semicolon from joining the next.
            var js = new StringBuilder();
            foreach (var s in scripts)
            {
                js.Append("/* ").Append(s).Append(" */\n").Append(File.ReadAllText(Path.Combine(Root, s))).Append("\n;\n");
            }

            var css = new StringBuilder();
            foreach (var s in styles)
            {
                css.Append("/* ").Append(s).Append(" */\n").Append(File.ReadAllText(Path.Combine(Root, s))).Append('\n');
            }

            var script = Make("js", js.ToString(), "text/javascript; charset=utf-8");
            var style = Make("css", css.ToString(), "text/css; charset=utf-8");
            // The page: the first listed file's tag becomes the bundle's tag, the others go.
            var firstScript = true;
            var firstStyle = true;
            var rewritten = ScriptTag().Replace(page, _ =>
            {
                if (!firstScript)
                {
                    return "";
                }
                firstScript = false;
                return $"  <script defer src=\"{script.Path}\"></script>";
            });
            rewritten = StyleTag().Replace(rewritten, _ =>
            {
                if (!firstStyle)
                {
                    return "";
                }
                firstStyle = false;
                return $"  <link rel=\"stylesheet\" href=\"{style.Path}\">";
            });
            rewritten = BlankLines().Replace(rewritten, "\n");
            return new Built(rewritten, "\"" + Hash(Encoding.UTF8.GetBytes(rewritten)) + "\"", script, style, stamp);
        }

        [GeneratedRegex(@"\n(\s*\n)+")] private static partial Regex BlankLines();

        private static Asset Make(string kind, string text, string type)
        {
            var raw = Encoding.UTF8.GetBytes(text);
            var hash = Hash(raw);
            // Bundles live in the folder of their sources (css/), so relative url() references in the styles still resolve.
            var path = kind == "js" ? $"/js/app.{hash}.js" : $"/css/app.{hash}.css";
            return new Asset(path, raw, Brotli(raw), Compress(raw, s => new GZipStream(s, CompressionLevel.Optimal, true)), type, "\"" + hash + "\"");
        }

        private static string Hash(byte[] bytes) => Convert.ToHexStringLower(SHA256.HashData(bytes))[..16];

        /// <summary>Brotli quality 9: close to the smallest size (quality 11) at a fraction of the time, so a rebuild stays quick.</summary>
        private static byte[] Brotli(byte[] raw)
        {
            var output = new byte[BrotliEncoder.GetMaxCompressedLength(raw.Length)];
            return BrotliEncoder.TryCompress(raw, output, out var written, 9, 22) ? output[..written] : Compress(raw, s => new BrotliStream(s, CompressionLevel.Optimal, true));
        }

        private static byte[] Compress(byte[] raw, Func<Stream, Stream> wrap)
        {
            using var output = new MemoryStream();
            using (var z = wrap(output))
            {
                z.Write(raw);
            }

            return output.ToArray();
        }

        /// <summary>Builds the bundles at start-up, so the first visitor does not wait for the compression.</summary>
        public void Prepare()
        {
            try
            {
                Current();
            }
            catch (Exception e) when (e is IOException or UnauthorizedAccessException)
            {
                _log.LogWarning(e, "The app's files could not be bundled at start-up");
            }
        }

        /// <summary>The page as served: index.html with the bundle tags.</summary>
        public string Page => Current().Page;

        internal (string Page, string Tag) PageAndTag()
        {
            var b = Current();
            return (b.Page, b.PageTag);
        }

        internal Asset? Find(string path)
        {
            var b = Current();
            return path == b.Script.Path ? b.Script : path == b.Style.Path ? b.Style : null;
        }
    }
}
