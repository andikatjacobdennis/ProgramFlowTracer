using System.Collections.Concurrent;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>The last few thousand API calls, in memory, for the Diagnostics API and the Server calls page.</summary>
    public sealed class ApiMetrics
    {
        private readonly ConcurrentQueue<ApiCall> _calls = new();
        public const int Capacity = 5000;
        public DateTimeOffset Since { get; } = DateTimeOffset.UtcNow;

        public void Add(ApiCall call)
        {
            _calls.Enqueue(call);
            while (_calls.Count > Capacity && _calls.TryDequeue(out _))
            { }
        }

        public IReadOnlyList<ApiCall> Recent(int take) => _calls.Reverse().Take(Math.Clamp(take, 1, Capacity)).ToArray();
        public IReadOnlyList<ApiCall> All => _calls.ToArray();
    }
}
