namespace Volvo.TestRequestTool.Web
{
    public sealed record CampaignDecision([property: System.ComponentModel.DataAnnotations.StringLength(20)] string? Decision, [property: System.ComponentModel.DataAnnotations.StringLength(500)] string? Note, long Version);
}
