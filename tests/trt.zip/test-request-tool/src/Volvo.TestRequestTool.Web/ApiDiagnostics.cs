using System.Diagnostics;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Security.Claims;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// APIs for testing and diagnostics, so the application can be explored and checked directly from Swagger UI or any HTTP
    /// client, not only through the interface. Everything requires a signed-in user; system details require an administrator.
    /// </summary>
    public static class ApiDiagnostics
    {
        public static WebApplication UseApiMetrics(this WebApplication app)
        {
            var metrics = app.Services.GetRequiredService<ApiMetrics>();
            var logs = app.Services.GetRequiredService<TestRequestLogStore>();
            app.Use(async (ctx, next) =>
            {
                if (!ctx.Request.Path.StartsWithSegments("/api"))
                {
                    await next();
                    return;
                }
                var started = Stopwatch.GetTimestamp();
                try
                {
                    await next();
                }
                finally
                {
                    var route = (ctx.GetEndpoint() as RouteEndpoint)?.RoutePattern.RawText ?? ctx.Request.Path.Value ?? "";
                    var ms = Stopwatch.GetElapsedTime(started).TotalMilliseconds;
                    metrics.Add(new ApiCall(DateTimeOffset.UtcNow, ctx.Request.Method, route.StartsWith('/') ? route : "/api/v1/" + route, ctx.Request.Path.Value ?? "", ctx.Response.StatusCode,
                        ms, ctx.Request.ContentLength, ctx.Response.ContentLength, ctx.User.FindFirstValue(ClaimTypes.NameIdentifier) ?? "anonymous"));
                    // One line per call in the Logs page (not the console). The log viewer's own polling is left out.
                    if (!ctx.Request.Path.StartsWithSegments("/api/v1/diagnostics/logs"))
                    {
                        logs.Record("TestRequest.Api", ctx.Response.StatusCode >= 500 ? LogLevel.Error : ctx.Response.StatusCode >= 400 ? LogLevel.Warning : LogLevel.Information,
                            $"{ctx.Request.Method} {ctx.Request.Path.Value} → {ctx.Response.StatusCode} in {ms:0.0} ms", ctx.Request.Path.Value, System.Diagnostics.Activity.Current?.TraceId.ToString() ?? ctx.TraceIdentifier);
                    }
                }
            });
            return app;
        }

        public static RouteGroupBuilder MapDiagnostics(this RouteGroupBuilder api, string authenticationMode)
        {
            var started = DateTimeOffset.UtcNow;
            var diag = api.MapGroup("/diagnostics").WithTags("Diagnostics");

            diag.MapGet("/metrics", (ApiMetrics metrics, int? minutes) => Summarise(metrics.All, Math.Clamp(minutes ?? 60, 1, 24 * 60)))
                .WithSummary("Call statistics per endpoint and per minute: counts, errors, p50/p95/max duration and sizes.");
            diag.MapGet("/calls", (ApiMetrics metrics, int? take) => metrics.Recent(take ?? 200))
                .WithSummary("The most recent API calls (method, route, status, duration, sizes), newest first.");
            diag.MapGet("/echo", (HttpContext ctx) => new
            {
                method = ctx.Request.Method,
                path = ctx.Request.Path.Value,
                query = ctx.Request.Query.ToDictionary(q => q.Key, q => q.Value.ToString()),
                headers = ctx.Request.Headers.Where(h => h.Key is not ("Cookie" or "Authorization")).ToDictionary(h => h.Key, h => h.Value.ToString()),
                user = new { id = ctx.User.FindFirstValue(ClaimTypes.NameIdentifier), name = ctx.User.Identity?.Name, roles = ctx.User.FindAll(ClaimTypes.Role).Select(c => c.Value).Concat(ctx.User.FindAll("role").Select(c => c.Value)).Distinct(), contexts = ctx.User.FindAll("context").Select(c => c.Value) },
                serverTime = DateTimeOffset.UtcNow,
                remoteAddress = ctx.Connection.RemoteIpAddress?.ToString(),
                scheme = ctx.Request.Scheme,
                protocol = ctx.Request.Protocol,
            }).WithSummary("What the server sees for this request: headers (without cookies or tokens), user, roles and contexts.");
            diag.MapGet("/system", async (IWorkspaceStore store, ICatalog catalog, IConfiguration config, IWebHostEnvironment env, CancellationToken ct) =>
            {
                using var process = Process.GetCurrentProcess();
                var data = catalog.Data;
                var vehicles = await store.VehiclesAsync(ct);
                return new
                {
                    application = new { started, uptime = (DateTimeOffset.UtcNow - started).ToString(@"d\.hh\:mm\:ss", CultureInfo.InvariantCulture), environment = env.EnvironmentName, authentication = authenticationMode },
                    runtime = new { framework = RuntimeInformation.FrameworkDescription, os = RuntimeInformation.OSDescription, architecture = RuntimeInformation.ProcessArchitecture.ToString(), processors = Environment.ProcessorCount, serverGc = System.Runtime.GCSettings.IsServerGC },
                    process = new { workingSetMb = process.WorkingSet64 / 1048576, managedMb = GC.GetTotalMemory(false) / 1048576, gc = new[] { GC.CollectionCount(0), GC.CollectionCount(1), GC.CollectionCount(2) }, threads = process.Threads.Count, cpuSeconds = process.TotalProcessorTime.TotalSeconds },
                    time = new { utc = DateTimeOffset.UtcNow, serverZone = TimeZoneInfo.Local.Id },
                    catalog = new { templates = data.A("templates").Count, versions = data.A("templates").Objects().Sum(t => t.A("versions").Count), servicePacks = data.A("servicePacks").Count, contexts = data.A("contexts").Count, catalogVehicles = data.A("vehicles").Count },
                    store = new { vehicles = vehicles.Count, changedVehicles = vehicles.Count(v => v.Revision > 1) },
                };
            }).RequireAuthorization("Admin").WithSummary("Process, runtime, catalog and store statistics. Administrators only.");
            diag.MapPost("/validate", async (JsonObject product, HttpContext ctx, IWorkspaceStore store, ICatalog catalog, IEnumerable<IProductValidator> validators, CancellationToken ct) =>
            {
                var proposal = new ProductDocument(product);
                ActorFactory.From(ctx.User).DemandRead(proposal.ContextId);
                var stored = await store.VehicleAsync(proposal.Id, ct);
                var context = new ValidationContext(stored is null ? proposal : new ProductDocument(stored.Product), proposal, new JsonObject(), catalog);
                var issues = new List<(string Validator, ValidationIssue Issue)>();
                foreach (var v in validators.OrderBy(v => v.Order))
                {
                    foreach (var i in await v.ValidateAsync(context, ct))
                    {
                        issues.Add((v.Name, i));
                    }
                }

                return new { vehicleId = proposal.Id, ready = issues.All(i => i.Issue.Severity != 0), issues = issues.Select(i => new { validator = i.Validator, i.Issue.Code, i.Issue.Text, severity = i.Issue.Severity == 0 ? "Error" : i.Issue.Severity == 1 ? "Warning" : "Information", i.Issue.Node }) };
            }).WithSummary("Run every validator on a product without storing anything (a dry run).");

            var cat = api.MapGroup("/catalog").WithTags("Catalog");
            cat.MapGet("/contexts", (HttpContext ctx, ICatalog catalog) =>
            {
                var a = ActorFactory.From(ctx.User);
                return catalog.Data.A("contexts").Objects().Where(c => a.Contexts.Contains(c.I("id")));
            }).WithSummary("Vehicle contexts you may read.");
            cat.MapGet("/templates", (HttpContext ctx, ICatalog catalog, int? context) =>
            {
                var a = ActorFactory.From(ctx.User);
                return catalog.Data.A("templates").Objects().Where(t => t.A("contexts").Any(x => int.TryParse(x?.ToString(), out var n) && a.Contexts.Contains(n) && (context is null || n == context)))
                    .Select(t => new { key = t.S("key"), name = t["identifier"].S("name"), versions = t.A("versions").Objects().Select(v => new { idx = v.I("idx"), versionName = v.S("versionName"), status = v.S("status"), introductionWeek = v.S("introductionWeek") }) });
            }).WithSummary("Node templates and their versions, optionally for one context.");
            cat.MapGet("/templates/{key}", (string key, HttpContext ctx, ICatalog catalog) =>
            {
                var a = ActorFactory.From(ctx.User);
                var t = catalog.Data.A("templates").Objects().FirstOrDefault(x => string.Equals(x.S("key"), key, StringComparison.OrdinalIgnoreCase) && x.A("contexts").Any(c => int.TryParse(c?.ToString(), out var n) && a.Contexts.Contains(n)));
                return t is null ? Results.Problem(statusCode: 404, title: "template_missing") : Results.Ok(t);
            }).WithSummary("One node template with every version, hardware, dependency and package.");
            cat.MapGet("/service-packs", (HttpContext ctx, ICatalog catalog) =>
            {
                var a = ActorFactory.From(ctx.User);
                return catalog.Data.A("servicePacks").Objects().Where(s => a.Contexts.Contains(s.I("contextId")));
            }).WithSummary("Service packs for the contexts you may read.");

            var veh = api.MapGroup("/vehicles").WithTags("Vehicles");
            veh.MapGet("/search", async (HttpContext ctx, IWorkspaceStore store, string? q, int? skip, int? take, CancellationToken ct) =>
            {
                var a = ActorFactory.From(ctx.User);
                var list = (await store.VehiclesAsync(ct)).Select(v => new ProductDocument(v.Product)).Where(p => a.Contexts.Contains(p.ContextId))
                    .Select(p => new { id = p.Id, series = p.Info.S("chassisSeries"), number = p.Info.S("chassisNumber"), vin = p.Info.S("vin"), model = p.Info.S("modelId"), country = p.Info.S("countryOfOperation"), computers = p.Nodes.Count, t3 = p.Nodes.Objects().Any(n => n.I("electricalArchitecture") == 3) })
                    .Where(v => string.IsNullOrWhiteSpace(q) || $"{v.series} {v.number} {v.vin} {v.model} {v.country}".Contains(q, StringComparison.OrdinalIgnoreCase)).ToArray();
                return new { total = list.Length, skip = skip ?? 0, items = list.Skip(Math.Max(0, skip ?? 0)).Take(Math.Clamp(take ?? 50, 1, 500)) };
            }).WithSummary("Search vehicles by chassis, VIN, model or country, a page at a time.");
            veh.MapGet("/{series}/{number}/export", async (string series, string number, string? format, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                var v = await store.VehicleAsync(VehicleIdentity.Key(series, number), ct) ?? throw new RequestFault(404, "vehicle_missing", "Vehicle was not found.");
                var p = new ProductDocument(v.Product);
                ActorFactory.From(ctx.User).DemandRead(p.ContextId);
                var file = $"{series}-{number}";
                return (format ?? "json").ToLowerInvariant() switch
                {
                    "xml" => Results.File(System.Text.Encoding.UTF8.GetBytes(ProductXmlCodec.Export(v.Product)), "application/xml", file + ".xml"),
                    "csv" => Results.File(System.Text.Encoding.UTF8.GetBytes(DataConverter.ToCsv(new JsonArray(p.Nodes.Objects().Select(n => (JsonNode)new JsonObject { ["computer"] = n.S("name"), ["version"] = n.S("versionName"), ["template"] = n["nodeTemplateDocument"].I("number"), ["hardware"] = n["ecuHardware"].I("number"), ["status"] = n.S("nodeTemplateStatus") }).ToArray()))), "text/csv", file + ".csv"),
                    "json" => Results.File(System.Text.Encoding.UTF8.GetBytes(v.Product.ToJsonString(new System.Text.Json.JsonSerializerOptions { WriteIndented = true })), "application/json", file + ".json"),
                    _ => throw new RequestFault(400, "format_unknown", "Use json, xml or csv."),
                };
            }).RequireRateLimiting("exports").WithSummary("Download a vehicle as JSON, XML (Test Request Tool product format) or CSV (one row per computer).");

            var conv = api.MapGroup("/convert").WithTags("Convert");
            conv.MapPost("/xml-to-json", async (HttpRequest request, CancellationToken ct) =>
            {
                using var r = new StreamReader(request.Body);
                return Results.Ok(DataConverter.XmlToJson(await r.ReadToEndAsync(ct)));
            })
                .WithSummary("Any XML to JSON: attributes as @name, mixed text as #text, repeated elements as arrays. DTDs are refused.");
            conv.MapPost("/json-to-xml", (JsonNode json, string? root) => Results.Text(DataConverter.JsonToXml(json, root), "application/xml"))
                .WithSummary("Any JSON to XML, the reverse mapping of xml-to-json. root names the root element when the JSON has more than one top-level property.");
            conv.MapPost("/json-to-csv", (JsonArray rows, string? separator) => Results.Text(DataConverter.ToCsv(rows, separator == "tab" ? '\t' : separator == ";" ? ';' : ','), "text/csv"))
                .WithSummary("A JSON array of objects to CSV. separator: comma (default), ; or tab.");

            api.MapGet("/time/convert", (DateTimeOffset? at, string? zones) =>
            {
                var when = at ?? DateTimeOffset.UtcNow;
                var list = (zones ?? "UTC,Asia/Kolkata,Europe/Stockholm").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Take(20);
                return new
                {
                    utc = when.ToUniversalTime(),
                    zones = list.Select(z =>
                    {
                        if (!TimeZoneInfo.TryFindSystemTimeZoneById(z, out var tz))
                        {
                            return (object)new { zone = z, error = "unknown time zone" };
                        }

                        var local = TimeZoneInfo.ConvertTime(when, tz);
                        return new { zone = z, local = local.ToString("yyyy-MM-dd'T'HH:mm:sszzz", CultureInfo.InvariantCulture), offset = local.Offset.ToString(@"hh\:mm", CultureInfo.InvariantCulture), daylightSaving = tz.IsDaylightSavingTime(when) };
                    }),
                };
            }).WithTags("Time").WithSummary("One moment in several IANA time zones, for example zones=UTC,Asia/Kolkata,America/Chicago.");
            return api;
        }

        /// <summary>Per-endpoint and per-minute statistics over the last N minutes.</summary>
        public static object Summarise(IReadOnlyList<ApiCall> all, int minutes)
        {
            var since = DateTimeOffset.UtcNow.AddMinutes(-minutes);
            var calls = all.Where(c => c.At >= since).ToArray();
            static double P(double[] sorted, double q) => sorted.Length == 0 ? 0 : sorted[Math.Min(sorted.Length - 1, (int)Math.Ceiling(q * sorted.Length) - 1)];
            return new
            {
                since,
                minutes,
                total = calls.Length,
                errors = calls.Count(c => c.Status >= 400),
                p50 = P(calls.Select(c => c.Ms).Order().ToArray(), .5),
                p95 = P(calls.Select(c => c.Ms).Order().ToArray(), .95),
                byStatus = calls.GroupBy(c => c.Status).OrderBy(g => g.Key).ToDictionary(g => g.Key.ToString(CultureInfo.InvariantCulture), g => g.Count()),
                byEndpoint = calls.GroupBy(c => c.Method + " " + c.Route).Select(g =>
                {
                    var ms = g.Select(c => c.Ms).Order().ToArray();
                    return new { endpoint = g.Key, count = g.Count(), errors = g.Count(c => c.Status >= 400), p50 = P(ms, .5), p95 = P(ms, .95), max = ms.Length == 0 ? 0 : ms[^1], avgBytes = g.Average(c => (double)(c.ResponseBytes ?? 0)) };
                }).OrderByDescending(e => e.count).ToArray(),
                perMinute = calls.GroupBy(c => new DateTimeOffset(c.At.Year, c.At.Month, c.At.Day, c.At.Hour, c.At.Minute, 0, TimeSpan.Zero)).OrderBy(g => g.Key)
                    .Select(g => new { at = g.Key, count = g.Count(), errors = g.Count(c => c.Status >= 400), p95 = P(g.Select(c => c.Ms).Order().ToArray(), .95) }).ToArray(),
            };
        }
    }
}
