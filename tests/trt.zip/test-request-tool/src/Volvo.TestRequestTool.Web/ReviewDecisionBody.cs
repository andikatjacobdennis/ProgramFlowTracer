using Volvo.TestRequestTool.Application;

namespace Volvo.TestRequestTool.Web
{
    public sealed record ReviewDecisionBody([property: System.ComponentModel.DataAnnotations.StringLength(20)] string? Decision, [property: System.ComponentModel.DataAnnotations.MaxLength(5)] string[]? Checklist,
        [property: System.ComponentModel.DataAnnotations.StringLength(ReviewService.MaxText)] string? Note, long Version);
}
