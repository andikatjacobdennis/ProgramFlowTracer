using System.ComponentModel.DataAnnotations;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>Body of PUT /admin/feedback/{id}.</summary>
    public sealed record UpdateFeedback([property: StringLength(10)] string? Status);
}
