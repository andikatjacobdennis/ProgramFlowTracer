using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Keeps the newest log entries in memory for the Logs page and the logs API (the regular log output is unchanged).
    /// Before anything is stored, values that must never be shown are masked: bearer tokens, JWTs, cookies, passwords,
    /// API keys and connection-string secrets, and e-mail addresses are shortened. Holds at most <see cref="Capacity"/> entries.
    /// </summary>
    public sealed partial class TestRequestLogStore : ILoggerProvider, ISupportExternalScope
    {
        public const int Capacity = 20_000;
        private readonly ConcurrentQueue<LogItem> _items = new();
        private long _next;
        private IExternalScopeProvider? _scopes;
        public DateTimeOffset Since { get; } = DateTimeOffset.UtcNow;

        public ILogger CreateLogger(string categoryName) => new Writer(this, categoryName);
        public void SetScopeProvider(IExternalScopeProvider scopeProvider) => _scopes = scopeProvider;
        public void Dispose() { }
        public IReadOnlyList<LogItem> All => _items.ToArray();

        [GeneratedRegex(@"(?i)(bearer\s+)[a-z0-9\-._~+/]+=*")] private static partial Regex Bearer();
        [GeneratedRegex(@"eyJ[a-zA-Z0-9_-]{8,}\.[a-zA-Z0-9_-]{8,}\.[a-zA-Z0-9_-]{8,}")] private static partial Regex Jwt();
        [GeneratedRegex(@"(?i)\b(password|pwd|secret|api[-_]?key|token|cookie|authorization|accountkey|sharedaccesskey)\b(\s*[=:]\s*)(""[^""]*""|'[^']*'|[^\s;,&]+)")] private static partial Regex Secret();
        [GeneratedRegex(@"\b([A-Za-z0-9._%+-])[A-Za-z0-9._%+-]*@([A-Za-z0-9.-]+\.[A-Za-z]{2,})\b")] private static partial Regex Email();

        /// <summary>Masks secrets and shortens e-mail addresses (FR-24, FR-60: logs exclude tokens and sensitive data).</summary>
        public static string Redact(string text)
        {
            if (string.IsNullOrEmpty(text))
            {
                return text;
            }

            text = Bearer().Replace(text, "$1***");
            text = Jwt().Replace(text, "***jwt***");
            text = Secret().Replace(text, "$1$2***");
            return Email().Replace(text, "$1***@$2");
        }

        /// <summary>
        /// Records an entry straight into the store without the console or other providers: used for one line per API call,
        /// which would be too costly to write to the console under load.
        /// </summary>
        public void Record(string category, LogLevel level, string message, string? path, string? traceId) =>
            Enqueue(new(Interlocked.Increment(ref _next), DateTimeOffset.UtcNow, Level(level), category, 0, Redact(message), null, traceId, path));

        /// <summary>A structured event for one request (or review step), visible to administrators and the given people.</summary>
        public void Event(string service, LogLevel level, string message, Guid? requestId, IEnumerable<string> audience, DateTimeOffset? at = null, string? traceId = null,
            string? spanId = null, int? attempt = null, IReadOnlyDictionary<string, string>? fields = null) =>
            Enqueue(new(Interlocked.Increment(ref _next), at ?? DateTimeOffset.UtcNow, Level(level), "TestRequest.Events." + service, 0, Redact(message), null, traceId ?? Activity.Current?.TraceId.ToString(), null,
                service, requestId, spanId, attempt, fields?.ToDictionary(kv => kv.Key, kv => Redact(kv.Value)), audience.Distinct().ToArray()));

        private void Enqueue(LogItem item)
        {
            _items.Enqueue(item);
            while (_items.Count > Capacity && _items.TryDequeue(out _))
            { }
        }

        private void Add(string category, LogLevel level, EventId id, string message, Exception? e)
        {
            string? path = null, trace = Activity.Current?.TraceId.ToString();
            _scopes?.ForEachScope((scope, _) =>
            {
                if (scope is IEnumerable<KeyValuePair<string, object?>> kv)
                {
                    foreach (var (k, v) in kv)
                    {
                        if (k == "RequestPath")
                        {
                            path = v?.ToString();
                        }
                        else if (k == "TraceId" && trace is null)
                        {
                            trace = v?.ToString();
                        }
                    }
                }
            }, (object?)null);
            var ex = e is null ? null : Redact($"{e.GetType().FullName}: {e.Message}\n{e.StackTrace}".Trim());
            if (ex is { Length: > 8000 })
            {
                ex = ex[..8000] + "\n…";
            }

            Enqueue(new(Interlocked.Increment(ref _next), DateTimeOffset.UtcNow, Level(level), category, id.Id, Redact(message.Length > 4000 ? message[..4000] + "…" : message), ex, trace, path));
        }

        public static string Level(LogLevel l) => l switch { LogLevel.Trace => "Trace", LogLevel.Debug => "Debug", LogLevel.Information => "Information", LogLevel.Warning => "Warning", LogLevel.Error => "Error", LogLevel.Critical => "Critical", _ => "None" };

        private sealed class Writer : ILogger
        {
            private readonly TestRequestLogStore _store;
            private readonly string _category;

            public Writer(TestRequestLogStore store, string category)
            {
                _store = store;
                _category = category;
            }

            public IDisposable? BeginScope<TState>(TState state) where TState : notnull => _store._scopes?.Push(state);
            public bool IsEnabled(LogLevel logLevel) => logLevel >= LogLevel.Information && logLevel != LogLevel.None;

            public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
            {
                if (!IsEnabled(logLevel))
                {
                    return;
                }

                _store.Add(_category, logLevel, eventId, formatter(state, exception), exception);
            }
        }
    }
}
