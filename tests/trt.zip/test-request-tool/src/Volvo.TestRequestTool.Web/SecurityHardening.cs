using System.Diagnostics;
using System.Security.Claims;
using Microsoft.AspNetCore.Http.Timeouts;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Security hardening for the web host, built only from ASP.NET Core 10 features and written so each part has an obvious
    /// replacement when the application moves to .NET 11 or later:
    /// <list type="bullet">
    /// <item><b>Headers</b>: a strict Content Security Policy (scripts only from this site, no inline script, no eval, no plugins,
    /// no framing), nosniff, a referrer policy, a permissions policy that switches off camera, microphone, location, payment, USB
    /// and serial, cross-origin isolation (COOP and CORP), and no caching of API responses.</item>
    /// <item><b>Cross-site request forgery</b>: unsafe methods on the API are refused when the browser says the request comes from
    /// another site (Fetch Metadata Sec-Fetch-Site, then Origin). This is the same rule .NET 11 applies automatically for
    /// endpoints that require antiforgery validation; on .NET 11 this middleware can be replaced by the built-in one.</item>
    /// <item><b>Transport</b>: HTTPS redirection and HSTS outside Development and Testing; no Server header.</item>
    /// <item><b>Abuse limits</b>: a per-user limit on all API calls and a tighter one for feedback, request timeouts and a body
    /// size limit.</item>
    /// <item><b>Input</b>: minimal API validation (AddValidation, new in .NET 10) of the DataAnnotations on request bodies.</item>
    /// <item><b>Audit</b>: refused requests (401, 403, 429) are logged with user, method and path, never with bodies.</item>
    /// <item><b>Timing</b>: a Server-Timing header with the server's processing time, used by the Server calls page.</item>
    /// </list>
    /// </summary>
    public static class SecurityHardening
    {
        /// <summary>The Content Security Policy. style-src-attr allows the style="" attributes the interface sets; nothing else is inline.</summary>
        public const string ContentSecurityPolicy =
            "default-src 'self'; script-src 'self'; style-src 'self'; style-src-attr 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; " +
            "connect-src 'self'; media-src 'self'; worker-src 'none'; manifest-src 'self'; object-src 'none'; frame-src 'none'; frame-ancestors 'none'; " +
            "base-uri 'self'; form-action 'self'";

        /// <summary>Swagger UI only: its page carries an inline stylesheet. Scripts stay limited to this site.</summary>
        public const string SwaggerPolicy =
            "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; " +
            "object-src 'none'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'";

        public const string PermissionsPolicy = "camera=(), microphone=(), geolocation=(), payment=(), usb=(), serial=(), bluetooth=(), hid=(), midi=(), display-capture=()";
        private static readonly string[] Unsafe = ["POST", "PUT", "PATCH", "DELETE"];

        public static WebApplicationBuilder AddTestRequestSecurity(this WebApplicationBuilder builder)
        {
            builder.WebHost.ConfigureKestrel(o =>
            {
                o.AddServerHeader = false;
                o.Limits.MaxRequestBodySize = 4_000_000;
                o.Limits.MaxRequestHeadersTotalSize = 32 * 1024;
            });
#pragma warning disable ASP0029 // ValidationOptions.Resolvers is marked experimental in .NET 10
            builder.Services.AddValidation(o => o.Resolvers.Insert(0, new JsonTreesAreData()));
#pragma warning restore ASP0029
            builder.Services.AddRequestTimeouts(o => o.DefaultPolicy = new RequestTimeoutPolicy { Timeout = TimeSpan.FromSeconds(60), TimeoutStatusCode = StatusCodes.Status504GatewayTimeout });
            builder.Services.AddHsts(o =>
            {
                o.MaxAge = TimeSpan.FromDays(365);
                o.IncludeSubDomains = true;
            });
            builder.AddTestRequestRateLimiting(); // per-person policies, headers and the rejection log: RateLimiting.cs
            return builder;
        }

        public static WebApplication UseTestRequestSecurity(this WebApplication app, bool localEnvironment)
        {
            if (!localEnvironment)
            {
                app.UseHsts();
                app.UseHttpsRedirection();
            }
            var log = app.Services.GetRequiredService<ILoggerFactory>().CreateLogger("TestRequest.Security");
            app.Use(async (ctx, next) =>
            {
                var started = Stopwatch.GetTimestamp();
                var headers = ctx.Response.Headers;
                headers.ContentSecurityPolicy = ctx.Request.Path.StartsWithSegments("/swagger") ? SwaggerPolicy : ContentSecurityPolicy;
                headers.XContentTypeOptions = "nosniff";
                headers.XFrameOptions = "DENY";
                headers["Referrer-Policy"] = "same-origin";
                headers["Permissions-Policy"] = PermissionsPolicy;
                headers["Cross-Origin-Opener-Policy"] = "same-origin";
                headers["Cross-Origin-Resource-Policy"] = "same-origin";
                var api = ctx.Request.Path.StartsWithSegments("/api");
                if (api)
                {
                    headers.CacheControl = "no-store";
                }
                // Cross-site request forgery: refuse unsafe API calls that a browser marks as coming from another site.
                if (api && Unsafe.Contains(ctx.Request.Method) && IsCrossSite(ctx.Request))
                {
                    log.LogWarning("Cross-site {Method} {Path} refused for {User}", ctx.Request.Method, ctx.Request.Path, UserKey(ctx));
                    ctx.Response.StatusCode = StatusCodes.Status403Forbidden;
                    await Results.Problem(statusCode: 403, title: "cross_site_request", detail: "Requests that change data must come from this application.").ExecuteAsync(ctx);
                    return;
                }
                ctx.Response.OnStarting(() =>
                {
                    if (api)
                    {
                        headers["Server-Timing"] = $"app;desc=\"server\";dur={Stopwatch.GetElapsedTime(started).TotalMilliseconds:0.0}";
                    }

                    return Task.CompletedTask;
                });
                await next();
                if (api && ctx.Response.StatusCode is 401 or 403 or 429)
                {
                    log.LogWarning("{Status} for {Method} {Path} by {User}", ctx.Response.StatusCode, ctx.Request.Method, ctx.Request.Path, UserKey(ctx));
                }
            });
            app.UseRequestTimeouts();
            return app;
        }

        /// <summary>Fetch Metadata first (Sec-Fetch-Site), then Origin, as .NET 11's automatic protection does. Tools without either are allowed.</summary>
        public static bool IsCrossSite(HttpRequest request)
        {
            var site = request.Headers["Sec-Fetch-Site"].ToString();
            if (site.Length > 0)
            {
                return site is not ("same-origin" or "none");
            }

            var origin = request.Headers.Origin.ToString();
            if (origin.Length == 0 || origin == "null")
            {
                return origin == "null";
            }

            return !Uri.TryCreate(origin, UriKind.Absolute, out var o) || !string.Equals(o.Authority, request.Host.Value, StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        /// JSON bodies (product documents, request payloads) are data checked by the product validators, not objects with
        /// DataAnnotations. Without this, validation would walk JsonNode.Parent and Root until it hits the depth limit.
        /// </summary>
#pragma warning disable ASP0029 // the resolver interface is marked experimental in .NET 10
        private sealed class JsonTreesAreData : Microsoft.Extensions.Validation.IValidatableInfoResolver, Microsoft.Extensions.Validation.IValidatableInfo
        {
            public bool TryGetValidatableTypeInfo(Type type, [System.Diagnostics.CodeAnalysis.NotNullWhen(true)] out Microsoft.Extensions.Validation.IValidatableInfo? info)
            {
                info = typeof(System.Text.Json.Nodes.JsonNode).IsAssignableFrom(type) ? this : null;
                return info is not null;
            }

            public bool TryGetValidatableParameterInfo(System.Reflection.ParameterInfo parameter, [System.Diagnostics.CodeAnalysis.NotNullWhen(true)] out Microsoft.Extensions.Validation.IValidatableInfo? info)
            {
                info = null;
                return false;
            }

            public Task ValidateAsync(object? value, Microsoft.Extensions.Validation.ValidateContext context, CancellationToken cancellationToken) => Task.CompletedTask;
        }

#pragma warning restore ASP0029

        private static string UserKey(HttpContext ctx) =>
            ctx.User.FindFirstValue(ClaimTypes.NameIdentifier) ?? ctx.User.FindFirstValue("sub") ?? ctx.Connection.RemoteIpAddress?.ToString() ?? "anonymous";
    }
}
