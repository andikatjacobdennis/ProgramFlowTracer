namespace Volvo.TestRequestTool.Web
{
    public sealed record UsageBatch([property: System.ComponentModel.DataAnnotations.MaxLength(100)] UsageIn[]? Events);
}
