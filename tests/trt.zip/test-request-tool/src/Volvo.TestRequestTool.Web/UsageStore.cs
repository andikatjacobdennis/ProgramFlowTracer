using System.Collections.Concurrent;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>The usage profiles of this process (one per host; tests get their own).</summary>
    public sealed class UsageStore
    {
        public readonly ConcurrentDictionary<string, UsageProfile> Profiles = new(StringComparer.Ordinal);
        public readonly object Gate = new();
    }
}
