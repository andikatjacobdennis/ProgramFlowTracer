using Microsoft.Extensions.Diagnostics.HealthChecks;
using Volvo.TestRequestTool.Application;

namespace Volvo.TestRequestTool.Web
{
    public sealed class IntegrationsHealthCheck : IHealthCheck
    {
        private readonly IEnumerable<IExternalCapability> _adapters;
        private readonly AdapterHealth _health;

        public IntegrationsHealthCheck(IEnumerable<IExternalCapability> adapters, AdapterHealth health)
        {
            _adapters = adapters;
            _health = health;
        }

        /// <summary>An integration that is turned off is not a fault; a configured, failing one degrades.</summary>
        public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken ct = default)
        {
            var states = _health.All(_adapters);
            var data = states.ToDictionary(s => s.Name, s => (object)s.Health);
            var failing = states.Where(s => s.Configured && s.Health is "unhealthy" or "degraded").Select(s => s.Name).ToArray();
            return Task.FromResult(failing.Length > 0 ? HealthCheckResult.Degraded("Failing: " + string.Join(", ", failing), data: data) : HealthCheckResult.Healthy("No configured integration is failing.", data));
        }
    }
}
