namespace Volvo.TestRequestTool.Web
{
    public sealed record CultureDefault([property: System.ComponentModel.DataAnnotations.StringLength(2)] string? Country, [property: System.ComponentModel.DataAnnotations.StringLength(35)] string? Language,
        [property: System.ComponentModel.DataAnnotations.StringLength(64)] string? TimeZone, [property: System.ComponentModel.DataAnnotations.StringLength(3)] string? Currency,
        [property: System.ComponentModel.DataAnnotations.StringLength(12)] string? DateFormat, [property: System.ComponentModel.DataAnnotations.StringLength(6)] string? HourCycle, [property: System.ComponentModel.DataAnnotations.StringLength(200)] string? Note);
}
