using Microsoft.Extensions.Caching.Hybrid;

namespace Volvo.TestRequestTool.Web
{
    public static class ProfilePhotoEndpoints
    {
        public static IServiceCollection AddProfilePhotos(this IServiceCollection services, IConfiguration config)
        {
            services.AddHttpClient("graph", c =>
            {
                c.Timeout = TimeSpan.FromSeconds(10);
                c.DefaultRequestHeaders.UserAgent.ParseAdd("TestRequestTool/1.0");
            });
            if (config.GetValue("Graph:Enabled", false))
            {
                services.AddSingleton<IProfilePhotoSource, GraphPhotoSource>();
            }
            else
            {
                services.AddSingleton<IProfilePhotoSource>(new FolderPhotoSource(Path.Combine(DataSetup.RepositoryPath(config), "user-photos")));
            }

            return services;
        }

        /// <summary>The nearest Graph photo size at or above the request (48, 64, 96, 120, 240 …).</summary>
        public static int Snap(int? size) => GraphPhotoSource.Sizes.FirstOrDefault(s => s >= Math.Clamp(size ?? 96, 1, 648), 648);

        public static RouteGroupBuilder MapProfilePhoto(this RouteGroupBuilder api)
        {
            api.MapGet("/me/photo", async (HttpContext ctx, IProfilePhotoSource source, HybridCache cache, int? size, CancellationToken ct) =>
            {
                var px = Snap(size);
                var user = ActorFactory.From(ctx.User).Id;
                // Cached per user and size (a photo is never shared between users); a missing photo is remembered for 10 minutes.
                var result = await cache.GetOrCreateAsync($"photo:{user}:{px}", (source, ctx, px), static async (s, token) => await s.source.GetAsync(s.ctx, s.px, token),
                    new HybridCacheEntryOptions { Expiration = TimeSpan.FromHours(1), LocalCacheExpiration = TimeSpan.FromHours(1) }, ["photos", "photos:" + user], ct);
                if (result.Status != "ok" && result.Status != "none")
                {
                    await cache.RemoveAsync($"photo:{user}:{px}", ct);   // do not keep failures
                }

                ctx.Response.Headers.Vary = "Cookie, Authorization";
                switch (result.Status)
                {
                    case "ok":
                        ctx.Response.Headers.CacheControl = "private, max-age=3600";
                        return Results.File(result.Bytes!, result.ContentType ?? "image/jpeg", entityTag: new Microsoft.Net.Http.Headers.EntityTagHeaderValue("\"" + Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(result.Bytes!))[..16] + "\""));
                    case "none":
                        // No photo is a normal answer, not an error: 204, so browsers do not log a failed request on every page.
                        ctx.Response.Headers.CacheControl = "private, max-age=600";
                        return Results.NoContent();
                    case "forbidden":
                        return Results.Problem(statusCode: 403, title: "photo_forbidden", detail: "The photo could not be read with the permissions granted.");
                    default:
                        return Results.Problem(statusCode: 502, title: "photo_unavailable", detail: "The photo service did not answer. Initials are shown instead.");
                }
            }).WithTags("Session").WithSummary("Your profile photo at the nearest available size (48, 64, 96, 120, 240 …). 204 when there is none, 403 without permission, 502 when the photo service is unreachable. Never takes a token in the URL.");
            // Each person's photo for the user list (from the repository's user-photos folder; 204 without one, so the page shows initials).
            api.MapGet("/admin/users/{id}/photo", (string id, IConfiguration config) =>
                new FolderPhotoSource(Path.Combine(DataSetup.RepositoryPath(config), "user-photos")).Find(id) is { Status: "ok" } p ? Results.File(p.Bytes!, p.ContentType) : Results.NoContent())
                .RequireAuthorization("Admin").WithTags("Administration").WithSummary("A person's photo from the repository, or 204 when there is none.");
            return api;
        }
    }
}
