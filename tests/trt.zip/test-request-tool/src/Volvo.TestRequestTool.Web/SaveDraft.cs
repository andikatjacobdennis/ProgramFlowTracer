using System.Text.Json.Nodes;

public sealed record SaveDraft(JsonObject State, long? ExpectedVersion);
