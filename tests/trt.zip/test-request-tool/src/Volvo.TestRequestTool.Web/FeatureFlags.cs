using System.Text.Json.Nodes;
using Microsoft.FeatureManagement;
using Microsoft.FeatureManagement.FeatureFilters;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Feature flags on Microsoft.FeatureManagement (FR-79, FR-83). The flags and their defaults are declared here; what an
    /// administrator changes is stored as a versioned setting ("feature-flags"), audited, and takes effect at once, without a
    /// deployment. Each flag is Off, On, or Targeted: on for chosen people, teams or roles, plus a percentage of everyone else,
    /// decided by Microsoft's targeting filter (stable per person). Server endpoints behind a flag answer 404 while it is off,
    /// so a hidden button is never the only control; the interface follows the same flags (/api/v1/features).
    /// </summary>
    public static class FeatureFlags
    {
        public sealed record Flag(string Name, string Title, string Description, bool DefaultOn);

        public static readonly IReadOnlyList<Flag> Catalogue =
        [
            new("guided-journey", "Guided journey", "The five-step stepper, decision bar and findings on the test request.", true),
            new("spellcheck", "Spelling check", "Wavy underlines and corrections in free-text fields.", true),
            new("usage-study", "Usage study", "Recording how the app is used (people can still opt out).", true),
            new("service-health", "Service health", "The Service health dashboard and the monitoring API.", true),
            new("logs-viewer", "Logs", "The Logs page and the logs API (administrators).", true),
            new("teams", "Teams", "Teams and managed settings (administrators).", true),
            new("guides", "Illustrated guides", "The guide characters in Help, the tour and empty pages.", true),
            new("intro-tour", "Introduction tour", "The voice-guided tour and its first-login offer.", true),
            new("change-impact", "Change impact", "The Change impact graph of a proposal (catalog relationships and validation results).", true),
            new("fleet-readiness", "Fleet readiness", "The Fleet readiness matrix and its export.", true),
            new("execution-trace", "Request execution", "The timed stages of each validation request and the sanitised trace.", true),
            new("engineering-insights", "Engineering insights", "The Engineering insights report (demand, latency, readiness, blockers, queue pressure).", true),
            new("campaigns", "Campaigns", "Campaigns: one change validated, approved and submitted across many vehicles.", true),
            new("reviews", "Reviews and approvals", "Request review, approve with separation of duties, submit the approved revision and the receipt.", true),
            new("require-approval", "Require approval to commit", "When on, a validation can be committed to VDA only through an approved review (direct commits are refused).", false),
            // AI features: all off by default. When on, the simulated provider answers (no AI service, no credentials).
            new("ai", "AI features (all)", "The overall switch for chat, summaries and agent previews. Off hides every AI entry point and refuses every AI call.", false),
            new("ai-chat", "AI chat", "The assistant panel (simulated). Needs the overall AI switch.", false),
            new("ai-summaries", "AI summaries", "Summarise actions on proposals, validation results and activity (simulated). Needs the overall AI switch.", false),
            new("ai-agent", "AI agent preview", "Plan previews for a goal (simulated; nothing is executed). Needs the overall AI switch.", false),
            new("load-testing", "Load-test endpoints", "The /api/v1/loadtest endpoints (also limited by Testing:LoadEndpoints).", true),
        ];

        public const string Key = "feature-flags";

        public static IServiceCollection AddTestRequestFeatureFlags(this IServiceCollection services)
        {
            services.AddHttpContextAccessor();
            services.AddSingleton<IFeatureDefinitionProvider, StoreFeatureDefinitions>();   // before AddFeatureManagement, so it replaces the configuration provider
            services.AddFeatureManagement().WithTargeting<TestRequestTargeting>();
            return services;
        }

        /// <summary>A flag's stored state, or its default.</summary>
        public static JsonObject StateOf(JsonObject? stored, Flag f) => stored?[f.Name] as JsonObject ?? new JsonObject { ["mode"] = f.DefaultOn ? "on" : "off" };

        /// <summary>404 while the flag is off for the caller (as if the endpoint did not exist).</summary>
        public static TBuilder RequireFeature<TBuilder>(this TBuilder builder, string flag) where TBuilder : IEndpointConventionBuilder =>
            builder.AddEndpointFilter(async (ctx, next) =>
                await ctx.HttpContext.RequestServices.GetRequiredService<IFeatureManager>().IsEnabledAsync(flag) ? await next(ctx)
                    : Results.Problem(statusCode: 404, title: "feature_off", detail: $"This feature ({flag}) is switched off."));

        public static RouteGroupBuilder MapFeatureFlags(this RouteGroupBuilder api)
        {
            api.MapGet("/features", async (IFeatureManager features) =>
            {
                var result = new Dictionary<string, bool>();
                foreach (var f in Catalogue)
                {
                    result[f.Name] = await features.IsEnabledAsync(f.Name);
                }

                return result;
            }).WithTags("Settings").WithSummary("The feature flags as they apply to you: name → on or off.");

            var admin = api.MapGroup("/admin/features").WithTags("Administration").RequireAuthorization("Admin");
            admin.MapGet("/", async (IWorkspaceStore store, CancellationToken ct) =>
            {
                var v = await store.SettingAsync(Key, ct);
                return new { version = v?.Version ?? 0, flags = Catalogue.Select(f => new { f.Name, f.Title, f.Description, f.DefaultOn, state = StateOf(v?.Value, f) }) };
            }).WithSummary("Every feature flag with its description, default and current state.");

            admin.MapPut("/{name}", async (string name, FlagBody body, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                var flag = Catalogue.FirstOrDefault(f => f.Name == name) ?? throw new RequestFault(404, "flag_missing", "No such feature flag.");
                if (body.Mode is not ("on" or "off" or "targeted"))
                {
                    throw new RequestFault(400, "flag_mode", "Mode is on, off or targeted.");
                }

                if (body.Rollout is < 0 or > 100)
                {
                    throw new RequestFault(400, "flag_rollout", "Rollout is a percentage from 0 to 100.");
                }

                var current = (await store.SettingAsync(Key, ct))?.Value ?? new JsonObject();
                current[flag.Name] = new JsonObject
                {
                    ["mode"] = body.Mode,
                    ["rollout"] = body.Rollout ?? 0,
                    ["users"] = new JsonArray((body.Users ?? []).Distinct().Select(x => (JsonNode)x).ToArray()),
                    ["groups"] = new JsonArray((body.Groups ?? []).Distinct().Select(x => (JsonNode)x).ToArray()),
                    ["exclude"] = new JsonArray((body.Exclude ?? []).Distinct().Select(x => (JsonNode)x).ToArray()),
                };
                var actor = ActorFactory.From(ctx.User);
                var saved = await store.SaveSettingAsync(Key, current, actor.Id, ctx.User.Identity?.Name ?? actor.Id, $"{flag.Title}: {body.Mode}", ct);
                return Results.Ok(new { version = saved.Version, state = current[flag.Name] });
            }).Audited("features.change").WithSummary("Change one flag: on, off, or targeted (users, groups = team ids or roles, rollout %, exclusions).");

            // Who gets the flag: each account (the first 500 by name) evaluated with Microsoft's targeting, exactly as at run time.
            admin.MapGet("/{name}/preview", async (string name, IFeatureManager features, IWorkspaceStore store, CancellationToken ct) =>
            {
                var flag = Catalogue.FirstOrDefault(f => f.Name == name) ?? throw new RequestFault(404, "flag_missing", "No such feature flag.");
                var list = new List<object>();
                foreach (var u in (await store.UsersAsync(ct)).Where(u => u.Enabled).OrderBy(u => u.DisplayName, StringComparer.OrdinalIgnoreCase).Take(500))
                {
                    var groups = await TestRequestTargeting.GroupsFor(store, u.Id, [u.Role], ct);
                    list.Add(new { u.Id, name = u.DisplayName, u.Role, on = await features.IsEnabledAsync(flag.Name, new TargetingContext { UserId = u.Id, Groups = groups }) });
                }
                return list;
            }).WithSummary("Whether each account gets the flag, evaluated the way it will be at run time.");
            return api;
        }
    }
}
