using Volvo.TestRequestTool.Application;

namespace Volvo.TestRequestTool.Web
{
    public sealed record NewReview(Guid RequestId, int? ProposalRevision, [property: System.ComponentModel.DataAnnotations.StringLength(ReviewService.MaxText)] string? Note);
}
