using System.Collections.Concurrent;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Every call to an external system goes through here: at most four calls at a time per integration, a bounded timeout, at
    /// most two retries of transient failures with exponential back-off and jitter, and a circuit that opens after three
    /// failures in a row so a failing system fails fast instead of freezing the workspace. "Configured" and "healthy" are kept
    /// apart: an adapter can be configured and still be unreachable.
    /// </summary>
    public sealed class AdapterHealth
    {
        private readonly TimeProvider _clock;
        private readonly ILogger<AdapterHealth> _log;
        public static readonly TimeSpan Timeout = TimeSpan.FromSeconds(10), OpenFor = TimeSpan.FromSeconds(30), WaitForSlot = TimeSpan.FromSeconds(2);
        public const int Retries = 2, OpenAfter = 3, MaxConcurrent = 4;
        private readonly ConcurrentDictionary<string, AdapterState> _states = new(StringComparer.OrdinalIgnoreCase);
        private readonly ConcurrentDictionary<string, SemaphoreSlim> _slots = new(StringComparer.OrdinalIgnoreCase);

        public AdapterHealth(TimeProvider clock, ILogger<AdapterHealth> log)
        {
            _clock = clock;
            _log = log;
        }

        public AdapterState State(IExternalCapability a)
        {
            var s = _states.GetOrAdd(a.Name, _ => new AdapterState(a.Name, a.IsConfigured, a.IsConfigured ? "unknown" : "not-configured", null, null, null, null, null, 0, null, null));
            if (s.CircuitOpenUntil is { } until && until <= _clock.GetUtcNow())
            {
                s = s with { CircuitOpenUntil = null, Health = "degraded" };
            }

            var slot = _slots.GetOrAdd(a.Name, _ => new SemaphoreSlim(MaxConcurrent, MaxConcurrent));
            return s with { Configured = a.IsConfigured, InFlight = MaxConcurrent - slot.CurrentCount };
        }

        public IReadOnlyList<AdapterState> All(IEnumerable<IExternalCapability> adapters) => adapters.Select(State).ToArray();

        public async Task<JsonObject> InvokeAsync(IExternalCapability a, JsonObject payload, CancellationToken ct)
        {
            if (!a.IsConfigured)
            {
                throw new RequestFault(501, "integration_not_configured", $"{a.Name} is not configured. Nothing was sent, and no result claims {a.Name} checks.");
            }

            var s = State(a);
            if (s.CircuitOpenUntil is { } open && open > _clock.GetUtcNow())
            {
                throw new RequestFault(503, "integration_unavailable", $"{a.Name} failed {s.ConsecutiveFailures} times in a row. Calls pause until {open:HH:mm:ss} UTC; editing and inspection keep working.");
            }

            var slot = _slots.GetOrAdd(a.Name, _ => new SemaphoreSlim(MaxConcurrent, MaxConcurrent));
            if (!await slot.WaitAsync(WaitForSlot, ct))
            {
                throw new RequestFault(503, "integration_busy", $"{a.Name} already has {MaxConcurrent} calls in progress. Try again in a moment.");
            }

            try
            {
                Exception? last = null;
                for (var attempt = 0; attempt <= Retries; attempt++)
                {
                    if (attempt > 0)
                    {
                        await Task.Delay(TimeSpan.FromMilliseconds(200 * Math.Pow(2, attempt - 1) + Random.Shared.Next(0, 150)), ct);
                    }

                    using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
                    timeout.CancelAfter(Timeout);
                    var started = _clock.GetTimestamp();
                    try
                    {
                        var result = await a.InvokeAsync((JsonObject)payload.DeepClone(), timeout.Token);
                        Record(a, true, null, _clock.GetElapsedTime(started).TotalMilliseconds);
                        return result;
                    }
                    catch (OperationCanceledException) when (!ct.IsCancellationRequested)
                    {
                        last = new TimeoutException($"{a.Name} did not answer within {Timeout.TotalSeconds:0} s.");
                    }
                    catch (RequestFault f) when (f.Status is 502 or 503 or 504)
                    {
                        last = f;
                    }            // transient: retry
                    catch (HttpRequestException e)
                    {
                        last = e;
                    }                                          // transient: retry
                    catch (RequestFault f)
                    {
                        Record(a, false, f.Message, _clock.GetElapsedTime(started).TotalMilliseconds);
                        throw;
                    } // not eligible for retry
                    Record(a, false, last.Message, _clock.GetElapsedTime(started).TotalMilliseconds);
                    if (State(a).CircuitOpenUntil is not null)
                    {
                        break;
                    }
                }
                _log.LogWarning("Integration {Name} failed after retries: {Error}", a.Name, last?.Message);
                throw new RequestFault(502, "integration_failed", $"{a.Name} did not give a usable answer: {last?.Message} Your input is kept; try again later.");
            }
            finally
            {
                slot.Release();
            }
        }

        /// <summary>A safe check: asks the adapter for its health only. Nothing is changed in the external system.</summary>
        public async Task<AdapterState> CheckAsync(IExternalCapability a, CancellationToken ct)
        {
            if (!a.IsConfigured)
            {
                return State(a);
            }

            try
            {
                await InvokeAsync(a, new JsonObject { ["operation"] = "health" }, ct);
            }
            catch (RequestFault) { /* recorded in the state */ }
            return State(a);
        }

        private void Record(IExternalCapability a, bool ok, string? error, double ms)
        {
            var now = _clock.GetUtcNow();
            AdapterState Apply(AdapterState s)
            {
                if (ok)
                {
                    return s with { Health = "healthy", Reachable = true, Authenticated = true, LastSuccess = now, ConsecutiveFailures = 0, CircuitOpenUntil = null, LastMs = ms };
                }

                var failures = s.ConsecutiveFailures + 1;
                var timedOut = error?.Contains("did not answer", StringComparison.Ordinal) == true;
                var denied = error?.Contains("401", StringComparison.Ordinal) == true || error?.Contains("403", StringComparison.Ordinal) == true;
                return s with
                {
                    Health = failures >= OpenAfter ? "unhealthy" : "degraded",
                    LastFailure = now,
                    LastError = error,
                    ConsecutiveFailures = failures,
                    CircuitOpenUntil = failures >= OpenAfter ? now + OpenFor : null,
                    LastMs = ms,
                    Reachable = timedOut ? false : s.Reachable,
                    Authenticated = denied ? false : s.Authenticated
                };
            }
            _states.AddOrUpdate(a.Name, _ => Apply(State(a)), (_, s) => Apply(s));
        }
    }
}
