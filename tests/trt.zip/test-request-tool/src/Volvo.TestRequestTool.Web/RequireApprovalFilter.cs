using Microsoft.FeatureManagement;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>With "require-approval" on, a direct commit needs an approved (not yet submitted) review of the same request.</summary>
    public static class RequireApprovalFilter
    {
        public static async Task CheckAsync(HttpContext ctx, Guid requestId)
        {
            if (!await ctx.RequestServices.GetRequiredService<IFeatureManager>().IsEnabledAsync("require-approval"))
            {
                return;
            }

            var review = await ctx.RequestServices.GetRequiredService<IWorkspaceStore>().ReviewForRequestAsync(requestId, ctx.RequestAborted);
            if (review?.Status != "approved")
            {
                throw new RequestFault(409, "approval_required", "An approved review is required before this request can be committed. Request a review, then submit it from the review.");
            }
        }
    }
}
