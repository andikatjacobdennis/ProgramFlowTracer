namespace Volvo.TestRequestTool.Web
{
    /// <summary>Wakes idle workers when a job is queued; workers also poll, so jobs queued by another instance are found.</summary>
    public sealed class JobSignal
    {
        private readonly SemaphoreSlim _signal = new(0);

        public void Notify()
        {
            if (_signal.CurrentCount == 0)
            {
                _signal.Release();
            }
        }

        public Task WaitAsync(TimeSpan timeout, CancellationToken ct) => _signal.WaitAsync(timeout, ct);
    }
}
