using System.Globalization;
using System.Security.Claims;
using System.Security.Cryptography;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Sessions: an HttpOnly, SameSite=Strict cookie that holds only who signed in. On every request the person's current
    /// record is read from the repository (from memory), so a changed role or contexts applies at once and a disabled or
    /// removed account loses its session immediately.
    /// </summary>
    public static class SignIn
    {
        public const string Scheme = CookieAuthenticationDefaults.AuthenticationScheme;
        public const string CookieName = "trt.session";
        public const string SessionClaim = "sid";

        public static AuthenticationBuilder AddTestRequestSignIn(this IServiceCollection services, IConfiguration config)
        {
            services.Configure<SignInSettings>(config.GetSection("Authentication"));
            services.AddSingleton<ICredentialValidator, ConfiguredCredentials>();
            services.AddHostedService<AccountSync>();
            var minutes = Math.Clamp(config.GetValue("Authentication:SessionMinutes", 480), 5, 7 * 24 * 60);
            return services.AddAuthentication(Scheme).AddCookie(Scheme, o =>
            {
                o.Cookie.Name = CookieName;
                o.Cookie.HttpOnly = true;
                o.Cookie.SameSite = SameSiteMode.Strict;
                o.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
                o.ExpireTimeSpan = TimeSpan.FromMinutes(minutes);
                o.SlidingExpiration = true;
                o.LoginPath = "/login";
                o.Events = new CookieAuthenticationEvents
                {
                    // The API answers 401/403 with a problem; the page (auth.js) then shows the sign-in page.
                    OnRedirectToLogin = ctx => Refuse(ctx, 401, "session_required", "Sign in to continue."),
                    OnRedirectToAccessDenied = ctx => Refuse(ctx, 403, "forbidden", "You do not have permission for this."),
                    OnValidatePrincipal = async ctx =>
                    {
                        var store = ctx.HttpContext.RequestServices.GetRequiredService<IWorkspaceStore>();
                        var id = ctx.Principal?.FindFirstValue(ClaimTypes.NameIdentifier);
                        var sid = ctx.Principal?.FindFirstValue(SessionClaim);
                        // The session must still exist (signing out deletes it) and belong to this person, who must still be enabled.
                        var session = sid is null ? null : await store.SessionAsync(sid, ctx.HttpContext.RequestAborted);
                        var user = id is null || session is null || session.UserId != id ? null : await store.UserAsync(id, ctx.HttpContext.RequestAborted);
                        if (user is null || !user.Enabled)
                        {
                            ctx.RejectPrincipal();
                            await ctx.HttpContext.SignOutAsync(Scheme);
                            return;
                        }
                        ctx.ReplacePrincipal(Principal(user, sid));
                    },
                };
            });
        }

        private static Task Refuse(RedirectContext<CookieAuthenticationOptions> ctx, int status, string title, string detail)
        {
            if (ctx.Request.Path.StartsWithSegments("/api"))
            {
                ctx.Response.StatusCode = status;
                return Results.Problem(statusCode: status, title: title, detail: detail).ExecuteAsync(ctx.HttpContext);
            }
            ctx.Response.Redirect(ctx.RedirectUri);
            return Task.CompletedTask;
        }

        /// <summary>The person's claims: id, name, country, contexts, their role and what it allows (Reader, Editor, Operator, Writer, Admin).</summary>
        public static ClaimsPrincipal Principal(UserAccount user, string? session = null)
        {
            var claims = new List<Claim> { new(ClaimTypes.NameIdentifier, user.Id), new(ClaimTypes.Name, user.DisplayName), new("studio_role", user.Role) };
            if (session is not null)
            {
                claims.Add(new(SessionClaim, session));
            }

            foreach (var context in user.Contexts)
            {
                claims.Add(new("context", context.ToString(CultureInfo.InvariantCulture)));
            }

            if (!string.IsNullOrEmpty(user.Country))
            {
                claims.Add(new(ClaimTypes.Country, user.Country));
            }

            if (!string.IsNullOrEmpty(user.Email))
            {
                claims.Add(new(ClaimTypes.Email, user.Email));
            }

            claims.Add(new(ClaimTypes.Role, "Reader"));
            if (user.Role is "Admin" or "Engineer")
            {
                claims.Add(new(ClaimTypes.Role, "Editor"));
            }

            if (user.Role is "Admin" or "Engineer" or "Reviewer")
            {
                claims.Add(new(ClaimTypes.Role, "Operator"));
            }

            if (user.Role is "Admin" or "Reviewer")
            {
                claims.Add(new(ClaimTypes.Role, "Writer"));
            }

            if (user.Role == "Admin")
            {
                claims.Add(new(ClaimTypes.Role, "Admin"));
            }

            return new ClaimsPrincipal(new ClaimsIdentity(claims, Scheme));
        }

        /// <summary>A path on this site to return to after signing in; anything else (another site, "//host", "/\host") becomes "/".</summary>
        public static string SafeReturn(string? url) =>
            !string.IsNullOrEmpty(url) && url.StartsWith('/') && !url.StartsWith("//") && !url.StartsWith("/\\") && !url.StartsWith("/login", StringComparison.OrdinalIgnoreCase) ? url : "/";

        /// <summary>The sign-in page, sign-in and sign-out, and the redirect of the app page to sign-in for anyone without a session.</summary>
        public static void MapTestRequestSignIn(this WebApplication app, RouteGroupBuilder api, string loginFile)
        {
            // Signed in already: straight back to where they were going.
            app.MapGet("/login", (HttpContext ctx, string? returnUrl) => ctx.User.Identity?.IsAuthenticated == true
                ? Results.Redirect(SafeReturn(returnUrl))
                : Results.File(loginFile, "text/html; charset=utf-8")).AllowAnonymous().ExcludeFromDescription();

            var auth = api.MapGroup("/auth").WithTags("Session");
            auth.MapPost("/login", async (SignInRequest body, HttpContext ctx, ICredentialValidator credentials, IWorkspaceStore store, ICatalog catalog, TimeProvider clock, ILoggerFactory logs, CancellationToken ct) =>
            {
                if (ctx.Request.Headers["X-Studio-Request"] != "1")
                {
                    throw new RequestFault(400, "same_origin_request_required", "A same-origin request from the sign-in page is required.");
                }

                if (string.IsNullOrWhiteSpace(body.Login) || string.IsNullOrEmpty(body.Password))
                {
                    throw new RequestFault(400, "credentials_required", "Enter your user name or email and your password.");
                }

                var proven = await credentials.ValidateAsync(body.Login, body.Password, ct);
                var log = logs.CreateLogger("TestRequest.SignIn");
                if (proven is null)
                {
                    log.LogWarning("Sign-in refused for {Login} from {Address}", body.Login.Trim(), ctx.Connection.RemoteIpAddress);
                    throw new RequestFault(401, "invalid_credentials", "The user name or password is incorrect.");
                }
                // First sign-in: the account from the credentials, with every context when none is set. Afterwards the repository's record wins.
                var all = catalog.Data.A("contexts").Objects().Select(c => c.I("id")).ToArray();
                var user = await store.UserAsync(proven.Id, ct) ?? proven with { Contexts = proven.Contexts.Length > 0 ? proven.Contexts : all };
                if (!user.Enabled)
                {
                    throw new RequestFault(403, "account_disabled", "This account is disabled. Ask an administrator to enable it.");
                }

                user = await store.SaveUserAsync(user with { LastSignIn = clock.GetUtcNow(), Email = user.Email ?? proven.Email }, ct);
                var now = clock.GetUtcNow();
                // The cookie lapses after SessionMinutes without use; however much it is used, a session ends after seven days.
                var session = new SessionRecord(Convert.ToHexStringLower(RandomNumberGenerator.GetBytes(16)), user.Id, now, now.AddDays(7));
                await store.SaveSessionAsync(session, ct);
                await ctx.SignInAsync(Scheme, Principal(user, session.Id), new AuthenticationProperties { AllowRefresh = true });
                await store.AppendAuditAsync(user.Id, user.DisplayName, "auth.signin", user.Id, null, ct);
                log.LogInformation("{User} signed in", user.Id);
                return Results.Ok(new { userId = user.Id, displayName = user.DisplayName });
            }).AllowAnonymous().RequireRateLimiting("auth").WithSummary("Sign in with a user name or email and a password; sets the session cookie.");
            auth.MapPost("/logout", async (HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                // The session record goes too, so this cookie (or a copy of it) no longer works.
                if (ctx.User.FindFirstValue(SessionClaim) is { } sid)
                {
                    await store.EndSessionAsync(sid, ct);
                }

                await ctx.SignOutAsync(Scheme);
                return Results.NoContent();
            }).AllowAnonymous().WithSummary("Sign out: ends the session.");
        }

        /// <summary>Anyone without a session who opens the app page is sent to the sign-in page, which brings them back afterwards.</summary>
        public static WebApplication UseSignInRedirect(this WebApplication app)
        {
            app.Use((ctx, next) =>
            {
                var path = ctx.Request.Path.Value ?? "";
                if ((path is "/" or "/index.html") && HttpMethods.IsGet(ctx.Request.Method) && ctx.User.Identity?.IsAuthenticated != true)
                {
                    var back = ctx.Request.QueryString.HasValue ? "/" + ctx.Request.QueryString.Value : "";
                    ctx.Response.Redirect("/login" + (back.Length > 1 ? "?returnUrl=" + Uri.EscapeDataString(back) : ""));
                    return Task.CompletedTask;
                }
                return next(ctx);
            });
            return app;
        }
    }
}
