using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Text.Json;
using Volvo.TestRequestTool.Application;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// GetInfo 1.0 (Request.Listener/Audit/Info_1_0): the running service as JSON, with the listener's fields
    /// (ServiceInformation.GetInfoAsJson in swb-stable1). Services are the message types this tool simulates. The tool has
    /// no message queues, so messageHandlers is empty, and its database is the repository.
    /// </summary>
    public sealed class InfoHandler : IListenerHandler
    {
        private static readonly JsonSerializerOptions Indented = new() { WriteIndented = true };
        private readonly IHostEnvironment _environment;
        private readonly IDocumentStore _repository;
        private readonly IServiceProvider _services;

        public InfoHandler(IHostEnvironment environment, IDocumentStore repository, IServiceProvider services)
        {
            _environment = environment;
            _repository = repository;
            _services = services;
        }

        public IReadOnlyCollection<string> Keys { get; } = ["GetInfo_1.0"];

        public ValueTask<ListenerReply> HandleAsync(ListenerMessage message, CancellationToken ct)
        {
            // Resolved here, not in the constructor: the handlers include this one.
            var services = _services.GetRequiredService<ListenerDispatcher>().SimulatedKeys.Order(StringComparer.Ordinal).ToList();
            var assembly = typeof(InfoHandler).Assembly;
            var version = assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion.Split('+')[0]
                ?? assembly.GetName().Version?.ToString() ?? "unknown";
            using var process = Process.GetCurrentProcess();
            var info = new
            {
                title = "Test Request Tool",
                version,
                environment = _environment.EnvironmentName,
                noOfProcessingThreads = Environment.ProcessorCount,
                machineEnvironment = new
                {
                    machineName = Environment.MachineName,
                    userAccount = Environment.UserName,
                    dotNetVersion = Environment.Version.ToString(),
                    osVersion = Environment.OSVersion.VersionString,
                    processorCount = Environment.ProcessorCount,
                },
                processInfo = new
                {
                    startedTime = process.StartTime.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture),
                    basePriority = process.BasePriority,
                    name = process.ProcessName,
                    maxWorkingSet = OperatingSystem.IsWindows() ? process.MaxWorkingSet.ToInt64() : 0,
                },
                services = services.Select(s => new { name = s[..s.LastIndexOf('_')], version = s[(s.LastIndexOf('_') + 1)..] }),
                databases = new { connectionString = _repository.Description, logConnectionString = (string?)null },
                messageHandlers = Array.Empty<object>(),
            };
            var summary = new List<ListenerFact>
            {
                new("Service", $"Test Request Tool {version} ({_environment.EnvironmentName})"),
                new("Message types simulated", services.Count.ToString(CultureInfo.InvariantCulture)),
                new("Repository", _repository.Description),
            };
            return ValueTask.FromResult(new ListenerReply(JsonSerializer.Serialize(info, Indented), ListenerReply.JsonText, [], summary));
        }

        public ListenerReply Reject(ListenerMessage message, ListenerNotice notice) => new(string.Empty, ListenerReply.Text, [notice], []);
    }
}
