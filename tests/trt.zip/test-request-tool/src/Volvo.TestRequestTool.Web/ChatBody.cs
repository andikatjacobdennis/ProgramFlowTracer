namespace Volvo.TestRequestTool.Web
{
    public sealed record ChatBody([property: System.ComponentModel.DataAnnotations.MaxLength(50)] ChatMessageIn[]? Messages, [property: System.ComponentModel.DataAnnotations.MaxLength(6)] ContextRefIn[]? Include);
}
