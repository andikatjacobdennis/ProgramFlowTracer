using Microsoft.AspNetCore.Diagnostics;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Web
{
    public sealed class FaultHandler : IExceptionHandler
    {
        private readonly ILogger<FaultHandler> _logger;

        public FaultHandler(ILogger<FaultHandler> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Expected outcomes such as "not found", "conflict" or "not allowed" (RequestFault, status below 500) become the same
        /// problem response here, in the API's own endpoint filter, instead of travelling up to the exception handler middleware.
        /// The response is identical; the difference is that Visual Studio no longer stops on them as "not handled in user
        /// code" while debugging. Server errors (500 and above) still go to the handler, which logs them.
        /// </summary>
        public static async ValueTask<object?> Filter(EndpointFilterInvocationContext ic, EndpointFilterDelegate next)
        {
            try
            {
                return await next(ic);
            }
            catch (RequestFault f) when (f.Status < 500 && !ic.HttpContext.Response.HasStarted)
            {
                return Problem(ic.HttpContext, f);
            }
        }

        public static IResult Problem(HttpContext context, RequestFault fault) =>
            Results.Problem(statusCode: fault.Status, title: fault.Code, detail: fault.Message, extensions: new Dictionary<string, object?> { { "traceId", context.TraceIdentifier } });

        public async ValueTask<bool> TryHandleAsync(HttpContext context, Exception exception, CancellationToken ct)
        {
            if (exception is OperationCanceledException && ct.IsCancellationRequested)
            {
                return false;
            }
            // JsonObject bodies report a repeated property ({"a":1,"a":2}, refused since AllowDuplicateProperties=false) as an
            // ArgumentException from System.Text.Json; that is bad input, not a server error.
            if (exception is ArgumentException && exception.StackTrace?.Contains("System.Text.Json", StringComparison.Ordinal) == true)
            {
                exception = new RequestFault(400, "duplicate_property", "The JSON repeats a property name. Send each property once.");
            }

            var fault = exception as RequestFault;
            var status = fault?.Status ?? (exception is BadHttpRequestException or System.Text.Json.JsonException ? 400 : 500);
            if (status == 500)
            {
                _logger.LogError(exception, "Unhandled request failure {TraceId}", context.TraceIdentifier);
            }

            context.Response.StatusCode = status;
            await Results.Problem(statusCode: status, title: fault?.Code ?? (status == 400 ? "invalid_request" : "server_error"), detail: fault?.Message ?? (status == 400 ? "The request body is invalid." : "An unexpected server error occurred."), extensions: new Dictionary<string, object?> { { "traceId", context.TraceIdentifier } }).ExecuteAsync(context);
            return true;
        }
    }
}
