using System.Text.RegularExpressions;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// The usage study (FR-30): how each person uses the application, so it can be made more useful later. No AI.
    /// <list type="bullet">
    /// <item>Only events from a fixed vocabulary are accepted: kinds page, action, step, outcome, error, recover and duration,
    /// with names of lower-case letters, digits and . : _ - (at most 60 characters). Free text is refused, so nothing typed
    /// (vehicle numbers, messages, search words) can be stored.</item>
    /// <item>People see everything recorded about them (My data), can stop recording at any time (the server then drops
    /// their events) and can delete it all. Administrators see per-person and fleet-wide patterns.</item>
    /// <item>Kept in this process (and summarised in memory) for 90 days; recent events are capped at 200 per person.</item>
    /// </list>
    /// </summary>
    public static partial class UsageEndpoints
    {
        public static readonly string[] Kinds = ["page", "action", "step", "outcome", "error", "recover", "duration"];
        [GeneratedRegex("^[a-z0-9][a-z0-9:._-]{0,59}$")] private static partial Regex Name();
        private const int RecentCap = 200, KeepDays = 90;
        private static string Who(HttpContext ctx) => ActorFactory.From(ctx.User).Id;


        public static RouteGroupBuilder MapUsage(this RouteGroupBuilder api)
        {
            var usage = api.MapGroup("/usage").WithTags("Usage study").RequireFeature("usage-study");
            usage.MapPost("/events", (UsageBatch body, HttpContext ctx, TimeProvider clock, UsageStore u) =>
            {
                var events = body.Events ?? [];
                if (events.Length > 100)
                {
                    throw new RequestFault(413, "too_many_events", "Send at most 100 events at once.");
                }

                foreach (var e in events)
                {
                    if (!Kinds.Contains(e.E) || !Name().IsMatch(e.K ?? "") || e.Ms is < 0 or > 86_400_000)
                    {
                        throw new RequestFault(400, "usage_event", "Events need a known kind and a short name (lower-case letters, digits and . : _ -). Free text is not accepted.");
                    }
                }

                var id = Who(ctx);
                var now = clock.GetUtcNow();
                var p = u.Profiles.GetOrAdd(id, _ => new UsageProfile { FirstSeen = now });
                lock (u.Gate)
                {
                    if (p.OptedOut)
                    {
                        return Results.Ok(new { accepted = 0, recording = false });
                    }

                    foreach (var e in events)
                    {
                        var day = now.UtcDateTime.ToString("yyyy-MM-dd");
                        if (!p.Days.TryGetValue(day, out var counts))
                        {
                            p.Days[day] = counts = new(StringComparer.Ordinal);
                        }

                        var key = e.E + ":" + e.K;
                        counts[key] = counts.GetValueOrDefault(key) + 1;
                        if (e.E == "duration" && e.Ms is { } ms)
                        {
                            p.Seconds[e.K!] = Math.Round(p.Seconds.GetValueOrDefault(e.K!) + ms / 1000, 1);
                        }

                        p.Recent.Add(new UsageEvent(e.E, e.K!, e.Ms, now));
                    }
                    if (p.Recent.Count > RecentCap)
                    {
                        p.Recent.RemoveRange(0, p.Recent.Count - RecentCap);
                    }

                    foreach (var old in p.Days.Keys.Where(d => string.CompareOrdinal(d, now.AddDays(-KeepDays).UtcDateTime.ToString("yyyy-MM-dd")) < 0).ToArray())
                    {
                        p.Days.Remove(old);
                    }

                    p.LastSeen = now;
                }
                return Results.Ok(new { accepted = events.Length, recording = true });
            }).WithSummary("Record a batch of interaction events (at most 100). Only the fixed vocabulary is accepted; free text is refused.");

            usage.MapGet("/mine", (HttpContext ctx, UsageStore u) =>
            {
                var p = u.Profiles.GetValueOrDefault(Who(ctx));
                if (p is null)
                {
                    return Results.Ok(new { recording = true, events = 0, days = 0, top = Array.Empty<object>(), seconds = new Dictionary<string, double>(), recent = Array.Empty<UsageEvent>() });
                }

                lock (u.Gate)
                {
                    return Results.Ok(Summary(p, includeRecent: true));
                }
            }).WithSummary("Everything the usage study holds about you: counts per day, time per page and your latest events.");

            usage.MapPut("/mine/consent", (Consent body, HttpContext ctx, TimeProvider clock, UsageStore u) =>
            {
                var p = u.Profiles.GetOrAdd(Who(ctx), _ => new UsageProfile { FirstSeen = clock.GetUtcNow() });
                lock (u.Gate)
                {
                    p.OptedOut = body.Record != true;
                }

                return Results.Ok(new { recording = !p.OptedOut });
            }).WithSummary("Start or stop recording. When stopped, events you send are dropped by the server.");

            usage.MapDelete("/mine", (HttpContext ctx, UsageStore u) =>
            {
                var id = Who(ctx);
                lock (u.Gate)
                {
                    var optedOut = u.Profiles.TryGetValue(id, out var p) && p.OptedOut;
                    u.Profiles.TryRemove(id, out _);
                    if (optedOut)
                    {
                        u.Profiles[id] = new UsageProfile { OptedOut = true };
                    }
                }
                return Results.NoContent();
            }).WithSummary("Delete everything the usage study holds about you. Your choice to stop recording is kept.");

            api.MapGet("/admin/usage", async (IWorkspaceStore store, UsageStore u, CancellationToken ct) =>
            {
                var names = (await store.UsersAsync(ct)).ToDictionary(u => u.Id, u => u.DisplayName, StringComparer.OrdinalIgnoreCase);
                lock (u.Gate)
                {
                    var people = u.Profiles.Where(kv => !kv.Value.OptedOut || kv.Value.Days.Count > 0).Select(kv => new { id = kv.Key, name = names.GetValueOrDefault(kv.Key, kv.Key), summary = Summary(kv.Value, includeRecent: false) }).ToArray();
                    var totals = u.Profiles.Values.SelectMany(p => p.Days.Values).SelectMany(d => d).GroupBy(kv => kv.Key).ToDictionary(g => g.Key, g => g.Sum(x => x.Value));
                    var step = (string s) => totals.GetValueOrDefault("step:" + s);
                    return Results.Ok(new
                    {
                        people,
                        optedOut = u.Profiles.Count(kv => kv.Value.OptedOut),
                        features = totals.Where(kv => kv.Key.StartsWith("action:", StringComparison.Ordinal) || kv.Key.StartsWith("page:", StringComparison.Ordinal)).OrderByDescending(kv => kv.Value).Select(kv => new { key = kv.Key, count = kv.Value }).ToArray(),
                        funnel = new[] { "vehicle", "prepare", "validate", "review", "submit" }.Select(s => new { step = s, count = step(s) }).ToArray(),
                        errors = totals.Where(kv => kv.Key.StartsWith("error:", StringComparison.Ordinal)).OrderByDescending(kv => kv.Value).Select(kv => new { key = kv.Key, count = kv.Value }).ToArray(),
                        recoveries = totals.Where(kv => kv.Key.StartsWith("recover:", StringComparison.Ordinal)).Sum(kv => kv.Value),
                    });
                }
            }).RequireAuthorization("Admin").WithTags("Usage study").WithSummary("Usage patterns per person and overall: features used, the step funnel, errors and recoveries. Content is never recorded.");
            return api;
        }

        private static object Summary(UsageProfile p, bool includeRecent)
        {
            var all = p.Days.Values.SelectMany(d => d).GroupBy(kv => kv.Key).ToDictionary(g => g.Key, g => g.Sum(x => x.Value));
            var hours = p.Recent.GroupBy(e => e.At.UtcDateTime.Hour).ToDictionary(g => g.Key, g => g.Count());
            return new
            {
                recording = !p.OptedOut,
                firstSeen = p.FirstSeen,
                lastSeen = p.LastSeen,
                days = p.Days.Count,
                events = all.Values.Sum(),
                top = all.OrderByDescending(kv => kv.Value).Take(12).Select(kv => new { key = kv.Key, count = kv.Value }).ToArray(),
                byKind = Kinds.ToDictionary(k => k, k => all.Where(kv => kv.Key.StartsWith(k + ":", StringComparison.Ordinal)).Sum(kv => kv.Value)),
                perDay = p.Days.OrderBy(kv => kv.Key, StringComparer.Ordinal).Select(kv => new { day = kv.Key, count = kv.Value.Values.Sum() }).ToArray(),
                hours = Enumerable.Range(0, 24).Select(h => hours.GetValueOrDefault(h)).ToArray(),
                seconds = p.Seconds,
                all,
                recent = includeRecent ? p.Recent.AsEnumerable().Reverse().Take(RecentCap).ToArray() : null,
            };
        }
    }
}
