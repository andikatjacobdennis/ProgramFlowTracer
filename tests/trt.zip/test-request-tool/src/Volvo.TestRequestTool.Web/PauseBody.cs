namespace Volvo.TestRequestTool.Web
{
    public sealed record PauseBody([property: System.ComponentModel.DataAnnotations.StringLength(300)] string? Reason);
}
