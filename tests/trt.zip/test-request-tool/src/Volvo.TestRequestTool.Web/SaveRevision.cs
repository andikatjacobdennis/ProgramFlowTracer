using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Web
{
    // =====================================================================================================================
    // Endpoints: jobs, proposals, audit, integrations
    // =====================================================================================================================
    public sealed record SaveRevision(JsonObject? State, int? BaseRevision, [property: System.ComponentModel.DataAnnotations.StringLength(120)] string? Reason, JsonObject? Summary);
}
