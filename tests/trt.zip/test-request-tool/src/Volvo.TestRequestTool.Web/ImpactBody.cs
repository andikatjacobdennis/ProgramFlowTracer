using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Web
{
    public sealed record ImpactBody([property: System.ComponentModel.DataAnnotations.StringLength(40)] string? VehicleId, JsonObject? Product, Guid? RequestId);
}
