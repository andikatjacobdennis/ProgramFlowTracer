using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Runs jobs. Each worker claims a job with a lease and renews it while it runs; a job whose worker stops is taken over by
    /// another worker when the lease expires (FR-39). Every attempt writes the same result id, so taking over or retrying never
    /// creates a second result. On shutdown, running jobs are handed back to the queue (FR-47).
    /// </summary>
    public sealed class JobWorker : BackgroundService
    {
        private readonly IWorkspaceStore _store;
        private readonly RequestService _requests;
        private readonly ProvenanceService _provenance;
        private readonly JobSignal _signal;
        private readonly TestRequestMetrics _metrics;
        private readonly TimeProvider _clock;
        private readonly ILogger<JobWorker> _log;
        private readonly TestRequestLogStore? _events;
        private readonly JobOptions _o;
        public static volatile bool Started;

        public JobWorker(IWorkspaceStore store, RequestService requests, ProvenanceService provenance, JobSignal signal, Microsoft.Extensions.Options.IOptions<JobOptions> options, TestRequestMetrics metrics, TimeProvider clock, ILogger<JobWorker> log, TestRequestLogStore? events = null)
        {
            _store = store;
            _requests = requests;
            _provenance = provenance;
            _signal = signal;
            _metrics = metrics;
            _clock = clock;
            _log = log;
            _events = events;
            _o = options.Value;
        }

        protected override Task ExecuteAsync(CancellationToken stop)
        {
            Started = true;
            if (_o.Workers <= 0)
            {
                _log.LogInformation("Jobs:Workers is 0: this instance accepts jobs but does not run them.");
                return Task.CompletedTask;
            }
            var prefix = $"{Environment.MachineName}:{Environment.ProcessId}";
            return Task.WhenAll(Enumerable.Range(0, Math.Max(1, _o.Workers)).Select(i => Loop($"{prefix}:{i}", _o.Workers == 1 || i < _o.Workers - 1, stop)));
        }

        private async Task Loop(string worker, bool allowBatch, CancellationToken stop)
        {
            await Task.Yield();
            while (!stop.IsCancellationRequested)
            {
                try
                {
                    var job = await _store.ClaimJobAsync(worker, _o.Lease, allowBatch, _o.BatchAging, stop);
                    if (job is null)
                    {
                        if (worker.EndsWith(":0", StringComparison.Ordinal))
                        {
                            var load = await _store.JobLoadAsync("-", stop);
                            _metrics.Load(load.Queued, load.Running);
                        }
                        // .NET 8+: SuppressThrowing ends the wait quietly on shutdown instead of throwing and catching.
                        await _signal.WaitAsync(TimeSpan.FromSeconds(1), stop).ConfigureAwait(ConfigureAwaitOptions.SuppressThrowing);
                        continue;
                    }
                    await RunAsync(job, worker, stop);
                }
                catch (OperationCanceledException) when (stop.IsCancellationRequested) { }
                catch (Exception e)
                {
                    _log.LogError(e, "Job worker {Worker} error", worker);
                    await Task.Delay(500, CancellationToken.None);
                }
            }
        }

        private async Task RunAsync(JobRecord job, string worker, CancellationToken stop)
        {
            using var run = CancellationTokenSource.CreateLinkedTokenSource(stop);
            run.CancelAfter(_o.MaxDuration);
            var lost = false;
            // Heartbeat: renew the lease, and notice a cancellation asked for from any instance.
            using var beat = new CancellationTokenSource();
            var heartbeat = Task.Run(async () =>
            {
                while (!beat.IsCancellationRequested)
                {
                    try
                    {
                        await Task.Delay(_o.Lease / 3, beat.Token);
                    }
                    catch (OperationCanceledException)
                    {
                        return;
                    }
                    if (!await _store.RenewLeaseAsync(job.Id, worker, _o.Lease, CancellationToken.None))
                    {
                        lost = true;
                        run.Cancel();
                        return;
                    }
                    if ((await _store.JobAsync(job.Id, CancellationToken.None))?.Status == "cancelling")
                    {
                        run.Cancel();
                    }
                }
            });
            string status;
            string? code = null, error = null;
            ExecutionRecord? record = null;
            try
            {
                var kind = Enum.Parse<RequestKind>(job.Kind, true);
                record = await _requests.ExecuteAsync(job.Actor.ToActor(), new RequestCommand(kind, (JsonObject)job.Input.DeepClone()), run.Token, job.ResultIdFor);
                status = "succeeded";
            }
            catch (RequestFault f)
            {
                status = "failed";
                code = f.Code;
                error = f.Message;
            }
            catch (OperationCanceledException) when (stop.IsCancellationRequested)
            {
                status = "queued";
                code = "worker_stopped";
                error = "The worker stopped; the job goes back to the queue.";
            }
            catch (OperationCanceledException)
            {
                var cancelling = (await _store.JobAsync(job.Id, CancellationToken.None))?.Status == "cancelling";
                (status, code, error) = cancelling ? ("cancelled", "job_cancelled", "Cancelled. Your input is kept.")
                    : ("failed", "job_timeout", $"The job took longer than {_o.MaxDuration.TotalMinutes:0} minutes and was stopped. Your input is kept: retry it.");
            }
            catch (Exception e)
            {
                _log.LogError(e, "Job {Id} failed", job.Id);
                status = "failed";
                code = "job_error";
                error = "Something went wrong on our side. Your input is kept: retry it.";
            }
            beat.Cancel();
            await heartbeat;
            // The attempt as a diagnostic event for the Logs page (author and administrators).
            _events?.Event("Worker", status == "succeeded" ? LogLevel.Information : status == "queued" ? LogLevel.Warning : LogLevel.Error,
                status == "succeeded" ? $"Attempt {job.Attempt} completed" : $"Attempt {job.Attempt} {status}: {error}", job.ResultIdFor, [job.Actor.Id], attempt: job.Attempt,
                fields: new Dictionary<string, string> { ["job"] = job.Id.ToString("N")[..12], ["lane"] = job.Lane, ["status"] = status, ["code"] = code ?? "" });
            if (lost)
            {
                _log.LogWarning("Job {Id}: lease lost by {Worker}; another worker owns it now", job.Id, worker);
                return;
            }
            await CompleteAsync(job.Id, worker, status, code, error, record);
        }

        /// <summary>Writes the outcome with an atomic transition, re-reading when a cancellation request changed the job meanwhile.</summary>
        private async Task CompleteAsync(Guid id, string worker, string status, string? code, string? error, ExecutionRecord? record)
        {
            for (var i = 0; i < 5; i++)
            {
                var current = await _store.JobAsync(id, CancellationToken.None);
                if (current is null || current.LeaseOwner != worker || current.Finished)
                {
                    return;
                }

                var to = current.Status == "cancelling" && status == "queued" ? "cancelled" : status;
                // FR-78: the work finished before the worker saw the cancel request. The result is real, so it is kept and the job says so.
                var lateCancel = current.Status == "cancelling" && to == "succeeded";
                if (lateCancel)
                {
                    code = "cancel_after_finish";
                    error = "Cancellation arrived after the work had finished; the result is kept.";
                }
                if (current.Status == "cancelling" && to is "succeeded" or "failed" or "cancelled" || current.Status == "running")
                {
                    var now = _clock.GetUtcNow();
                    try
                    {
                        await _store.TransitionJobAsync(id, current.Version, to, j =>
                        {
                            var attempts = (j.Attempts ?? []).ToList();
                            if (attempts.Count > 0 && attempts[^1].FinishedAt is null)
                            {
                                attempts[^1] = attempts[^1] with { FinishedAt = now, Status = to == "queued" ? "released" : to, ErrorCode = code, Error = error };
                            }

                            return j with
                            {
                                FinishedAt = to == "queued" ? null : now,
                                ErrorCode = to == "succeeded" && !lateCancel ? null : code,
                                Error = to == "succeeded" && !lateCancel ? null : error,
                                Attempts = attempts,
                                ResultId = record?.Id ?? j.ResultId,
                                Provenance = record is null ? j.Provenance : _provenance.For(record),
                                LeaseOwner = null,
                                LeaseUntil = null,
                            };
                        }, CancellationToken.None);
                        if (to != "queued")
                        {
                            _metrics.Completed(current, to);
                        }

                        return;
                    }
                    catch (RequestFault f) when (f.Code == "job_changed") { /* a heartbeat or a cancel request came in between: read again */ }
                }
                else
                {
                    return;
                }
            }
        }
    }
}
