using System.Text.Json;
using System.Text.Json.Serialization;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Compile-time JSON serialization (System.Text.Json source generation) for the workflow records the API returns most:
    /// jobs (polled and streamed), revisions, audit entries, provenance and adapter state. No reflection at run time, less
    /// start-up work, and ready for native AOT. Inserted first in the HTTP JSON options; all other types use the default.
    /// </summary>
    [JsonSourceGenerationOptions(JsonSerializerDefaults.Web, UseStringEnumConverter = true)]
    [JsonSerializable(typeof(JobRecord))]
    [JsonSerializable(typeof(IEnumerable<JobRecord>))]
    [JsonSerializable(typeof(ProposalRevision))]
    [JsonSerializable(typeof(IReadOnlyList<ProposalRevision>))]
    [JsonSerializable(typeof(IReadOnlyList<AuditEntry>))]
    [JsonSerializable(typeof(Provenance))]
    [JsonSerializable(typeof(IReadOnlyList<AdapterState>))]
    [JsonSerializable(typeof(AdapterState))]
    public sealed partial class TestRequestJsonContext : JsonSerializerContext;
}
