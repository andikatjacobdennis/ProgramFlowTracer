using System.Text.Json;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Web
{
    // =====================================================================================================================
    // FR-02 · Where each result came from
    // =====================================================================================================================
    /// <summary>Builds the provenance shown next to every result. Never claims a service that did not take part.</summary>
    public sealed class ProvenanceService
    {
        private readonly IEnumerable<IExternalCapability> _adapters;
        private readonly AdapterHealth _health;
        private readonly TimeProvider _clock;
        private readonly IWebHostEnvironment _env;
        // The catalog never changes while the process runs, so its fingerprint is computed once.
        private readonly Lazy<string> _catalogFingerprint;

        private static readonly string Application = typeof(ProvenanceService).Assembly.GetCustomAttributes(typeof(System.Reflection.AssemblyInformationalVersionAttribute), false)
            .OfType<System.Reflection.AssemblyInformationalVersionAttribute>().FirstOrDefault()?.InformationalVersion ?? "unknown";

        /// <summary>The version of the built-in validation rules (catalog, hardware, dependency, parameter, variant). Recorded with every result.</summary>
        public const string RuleVersion = "studio-rules-2026.10";
        public const string Engine = "Test Request Tool validators: catalog, hardware, dependency, parameter, variant";
        public static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web) { Converters = { new System.Text.Json.Serialization.JsonStringEnumConverter() } };

        public ProvenanceService(IEnumerable<IExternalCapability> adapters, AdapterHealth health, TimeProvider clock, ICatalog catalog, IWebHostEnvironment env)
        {
            _adapters = adapters;
            _health = health;
            _clock = clock;
            _env = env;
            _catalogFingerprint = new(() => CanonicalJson.Hash(catalog.Data)[..16]);
        }

        /// <summary>Provenance with the full execution manifest (FR-74).</summary>
        public Provenance For(ExecutionRecord record)
        {
            const string contract = "studio-request-v1";   // the /api/v1 request contract (FR-64)
            var manifest = new ExecutionManifest(record.Outcomes.Select(o => new InputRevision(o.VehicleId, o.BaseRevision, o.ProposalHash)).ToArray(), RuleVersion, _catalogFingerprint.Value,
                record.Kind.ToString(), contract, record.InputHash[..Math.Min(16, record.InputHash.Length)], "Test Request Tool " + Application,
                System.Runtime.InteropServices.RuntimeInformation.FrameworkDescription, _env.EnvironmentName);
            return For(record.Outcomes, record.CreatedAt) with { Manifest = manifest };
        }

        public Provenance For(IEnumerable<Outcome> outcomes, DateTimeOffset? at = null)
        {
            var limited = outcomes.Any(o => o.LimitedValidation);
            var services = _adapters.Select(a =>
            {
                var h = _health.State(a);
                return a.IsConfigured
                    ? new ServiceUse(a.Name, h.Health == "healthy" ? "available" : h.Health, $"Configured ({h.Health}), not called by this request type.")
                    : new ServiceUse(a.Name, "not-connected", $"Not configured, so not asked. This result includes no {a.Name} checks.");
            }).ToArray();
            return new Provenance("Repository", limited ? "limited" : "simulation", Engine, services, at ?? _clock.GetUtcNow(), RuleVersion);
        }

        /// <summary>The execution record as JSON with its provenance added, keeping the record's own shape for existing clients.</summary>
        public JsonObject Attach(ExecutionRecord record)
        {
            var json = JsonSerializer.SerializeToNode(record, Json)!.AsObject();
            json["provenance"] = JsonSerializer.SerializeToNode(For(record), Json);
            return json;
        }
    }
}
