namespace Volvo.TestRequestTool.Web
{
    /// <summary>The "RateLimiting" configuration section: on/off and the rules by policy name. Validated at start-up.</summary>
    public sealed class RateLimitSettings
    {
        public bool Enabled { get; set; } = true;
        public Dictionary<string, RateLimitRule> Policies { get; set; } = new(StringComparer.Ordinal);

        /// <summary>The built-in rules; configuration overrides any field of any of them, and may add policies.</summary>
        public static Dictionary<string, RateLimitRule> Defaults() => new(StringComparer.Ordinal)
        {
            ["api"] = new() { Kind = "sliding", Limit = 1200, WindowSeconds = 60, Segments = 6, Description = "Every API call (global, per person)." },
            ["status"] = new() { Kind = "fixed", Limit = 6000, WindowSeconds = 60, Description = "Status reads (session, job status): a larger allowance so polling keeps working while throttled elsewhere." },
            ["simulation"] = new() { Kind = "token", Limit = 60, Burst = 20, WindowSeconds = 60, Description = "Validations, previews and batch starts: 60 a minute, up to 20 at once." },
            ["reads"] = new() { Kind = "sliding", Limit = 240, WindowSeconds = 60, Segments = 6, Description = "Computed views: change impact, readiness, insights, traces, the requests hub." },
            ["writes"] = new() { Kind = "fixed", Limit = 60, WindowSeconds = 60, Description = "Review requests, comments, decisions and submissions." },
            ["exports"] = new() { Kind = "fixed", Limit = 20, WindowSeconds = 600, Description = "Downloads of logs, receipts and vehicles." },
            ["assistant"] = new() { Kind = "token", Limit = 30, Burst = 10, WindowSeconds = 60, Description = "Simulated assistant calls." },
            ["feedback"] = new() { Kind = "fixed", Limit = 10, WindowSeconds = 600, Description = "Feedback messages." },
            ["auth"] = new() { Kind = "fixed", Limit = 20, WindowSeconds = 60, PartitionBy = "ip", Description = "Signing in, per address (brute-force protection)." },
        };
    }
}
