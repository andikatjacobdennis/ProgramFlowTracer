namespace Volvo.TestRequestTool.Web
{
    public sealed record NavigationPreference([property: System.ComponentModel.DataAnnotations.StringLength(10)] string? Mode, bool? AutoHide);
}
