using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace Volvo.TestRequestTool.Web
{
    public sealed class WarmupHealthCheck : IHealthCheck
    {
        private readonly Warmup _warmup;

        public WarmupHealthCheck(Warmup warmup)
        {
            _warmup = warmup;
        }

        public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken ct = default) => Task.FromResult(_warmup.Done
                ? HealthCheckResult.Healthy($"Warmed up in {_warmup.Took.TotalMilliseconds:0} ms.")
                : HealthCheckResult.Unhealthy("Starting: warming up the catalog, store and caches."));
    }
}
