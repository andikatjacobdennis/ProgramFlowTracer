using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Web
{
    public sealed record TeamBody([property: System.ComponentModel.DataAnnotations.StringLength(80)] string? Name, [property: System.ComponentModel.DataAnnotations.StringLength(300)] string? Description,
        [property: System.ComponentModel.DataAnnotations.MaxLength(500)] string[]? Members, JsonObject? Settings, int? BaseVersion);
}
