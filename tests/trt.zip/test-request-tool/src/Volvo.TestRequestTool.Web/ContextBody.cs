namespace Volvo.TestRequestTool.Web
{
    public sealed record ContextBody([property: System.ComponentModel.DataAnnotations.MaxLength(6)] ContextRefIn[]? Include);
}
