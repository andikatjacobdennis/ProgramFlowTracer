namespace Volvo.TestRequestTool.Web
{
    // =====================================================================================================================
    // FR-21 / FR-22 / FR-44 · Adapter health, timeouts, retries with jitter, a circuit breaker and per-integration limits
    // =====================================================================================================================
    public sealed record AdapterState(string Name, bool Configured, string Health, bool? Reachable, bool? Authenticated, DateTimeOffset? LastSuccess,
        DateTimeOffset? LastFailure, string? LastError, int ConsecutiveFailures, DateTimeOffset? CircuitOpenUntil, double? LastMs, int InFlight = 0);
}
