namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// One captured log entry. Message, exception and fields are redacted before they are stored. Request events also carry
    /// the service, request, span, attempt and structured fields; Audience (never sent to clients) lists who may see the entry
    /// besides administrators: the request's author and the person who acted.
    /// </summary>
    public sealed record LogItem(long Id, DateTimeOffset At, string Level, string Category, int EventId, string Message, string? Exception, string? TraceId, string? Path,
        string? Service = null, Guid? RequestId = null, string? SpanId = null, int? Attempt = null, IReadOnlyDictionary<string, string>? Fields = null,
        [property: System.Text.Json.Serialization.JsonIgnore] IReadOnlyList<string>? Audience = null)
    {
        public string? Request => RequestId is Guid g ? "REQ-" + g.ToString("N")[..6].ToUpperInvariant() : null;
    }
}
