using Volvo.TestRequestTool.Application;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// /api/v1/campaigns: one change across many vehicles (CampaignService). List and detail compute each vehicle's
    /// validation, approval and next action from batch results; create and edit (a new revision clears the approval);
    /// validate (a batch run); approve or request changes (Writer, never the owner); submit (Writer); archive.
    /// Behind the "campaigns" feature flag; writes are audited and rate-limited.
    /// </summary>
    public static class CampaignEndpoints
    {
        public static IServiceCollection AddCampaigns(this IServiceCollection services) => services.AddSingleton<CampaignService>();

        public static RouteGroupBuilder MapCampaigns(this RouteGroupBuilder api)
        {
            var g = api.MapGroup("/campaigns").WithTags("Campaigns").RequireFeature("campaigns");
            g.MapGet("/", async (HttpContext ctx, CampaignService s, CancellationToken ct) => await s.ListAsync(ActorFactory.From(ctx.User), ct))
                .RequireRateLimiting("reads").WithSummary("Campaigns you may see, with readiness counts, approval state and stage.");
            g.MapGet("/{id:guid}", async (Guid id, HttpContext ctx, CampaignService s, CancellationToken ct) => await s.GetAsync(ActorFactory.From(ctx.User), id, ct))
                .RequireRateLimiting("reads").WithSummary("One campaign: every vehicle with validation, approval and next action, validations, approval, submission and activity.");
            g.MapPost("/", async (CampaignBody b, HttpContext ctx, CampaignService s, CancellationToken ct) =>
            {
                var c = await s.CreateAsync(ActorFactory.From(ctx.User), b.Name, b.Description, b.VehicleIds, b.Kind, b.Template, ct);
                return Results.Created($"/api/v1/campaigns/{c.Id}", await s.GetAsync(ActorFactory.From(ctx.User), c.Id, ct));
            }).RequireAuthorization("Operator").RequireRateLimiting("writes").Audited("campaign.create").WithSummary("Create a campaign: name, vehicles and the request template.");
            g.MapPut("/{id:guid}", async (Guid id, CampaignBody b, HttpContext ctx, CampaignService s, CancellationToken ct) =>
            {
                await s.UpdateAsync(ActorFactory.From(ctx.User), id, b.Version, b.Name, b.Description, b.VehicleIds, b.Kind, b.Template, ct);
                return await s.GetAsync(ActorFactory.From(ctx.User), id, ct);
            }).RequireAuthorization("Operator").RequireRateLimiting("writes").Audited("campaign.edit").WithSummary("Edit a campaign: a new revision; its approval no longer applies.");
            g.MapPost("/{id:guid}/validate", async (Guid id, CampaignVehicles b, HttpContext ctx, CampaignService s, CancellationToken ct) =>
            {
                await s.ValidateAsync(ActorFactory.From(ctx.User), id, b.Version, b.VehicleIds, ct);
                return await s.GetAsync(ActorFactory.From(ctx.User), id, ct);
            }).RequireAuthorization("Operator").RequireRateLimiting("simulation").Pausable("submissions").Audited("campaign.validate").WithSummary("Validate the current revision for all or the given vehicles (a batch run).");
            g.MapPost("/{id:guid}/decision", async (Guid id, CampaignDecision b, HttpContext ctx, CampaignService s, CancellationToken ct) =>
            {
                await s.DecideAsync(ActorFactory.From(ctx.User), ctx.User.IsInRole("Writer"), id, b.Version, b.Decision, b.Note, ct);
                return await s.GetAsync(ActorFactory.From(ctx.User), id, ct);
            }).RequireRateLimiting("writes").Audited("campaign.decision").WithSummary("Approve the exact revision (covers the ready vehicles) or request changes. Writer role; never the owner.");
            g.MapPost("/{id:guid}/submit", async (Guid id, SubmitReview b, HttpContext ctx, CampaignService s, Microsoft.Extensions.Caching.Hybrid.HybridCache cache, CancellationToken ct) =>
            {
                await s.SubmitAsync(ActorFactory.From(ctx.User), ctx.User.IsInRole("Writer"), id, b.Confirmed, ct);
                await cache.RemoveByTagAsync(VehicleInsights.FleetTag, ct);
                return await s.GetAsync(ActorFactory.From(ctx.User), id, ct);
            }).RequireAuthorization("Writer").RequireRateLimiting("writes").Pausable("writes").Audited("campaign.submit").WithSummary("Commit every approved vehicle still on its validated revision; others are skipped with the reason. Repeating returns the same result.");
            g.MapPost("/{id:guid}/archive", async (Guid id, ReviewVersion b, HttpContext ctx, CampaignService s, CancellationToken ct) =>
            {
                await s.ArchiveAsync(ActorFactory.From(ctx.User), id, b.Version, ct);
                return await s.GetAsync(ActorFactory.From(ctx.User), id, ct);
            }).RequireAuthorization("Operator").RequireRateLimiting("writes").Audited("campaign.archive").WithSummary("Archive a campaign (the owner).");
            return api;
        }
    }
}
