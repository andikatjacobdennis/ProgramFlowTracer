namespace Volvo.TestRequestTool.Web
{
    public sealed record FlagBody([property: System.ComponentModel.DataAnnotations.StringLength(10)] string? Mode, int? Rollout,
        [property: System.ComponentModel.DataAnnotations.MaxLength(200)] string[]? Users, [property: System.ComponentModel.DataAnnotations.MaxLength(100)] string[]? Groups,
        [property: System.ComponentModel.DataAnnotations.MaxLength(200)] string[]? Exclude);
}
