using System.Collections.Concurrent;
using System.Diagnostics.Metrics;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Threading.RateLimiting;
using Microsoft.AspNetCore.RateLimiting;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Rate limiting for the API (FR-36, FR-52), on ASP.NET Core's RateLimiter middleware:
    /// <list type="bullet">
    /// <item>A global sliding window per person on every /api call ("api"), with a larger allowance for status polling ("status");
    /// health checks, static files and the load-test endpoints (own token bucket and concurrency cap) are outside it.</item>
    /// <item>Named policies on endpoint groups: simulation, reads, writes, exports, assistant, feedback, auth. Both the global and
    /// the endpoint policy must allow a call.</item>
    /// <item>Partitions: the signed-in user's id, or the client address before sign-in ("auth" always by address). The key is
    /// hashed before it is kept in the rejection log.</item>
    /// <item>Every response of a limited endpoint names its policy (RateLimit-Policy, IETF draft); a rejection is 429 with
    /// Retry-After, RateLimit and a problem body {title: rate_limited, policy, retryAfterSeconds, retryable}.</item>
    /// <item>Rejections are counted (metric studio.ratelimit.rejected, by policy) and the latest 200 are kept for administrators
    /// (GET /api/v1/admin/rate-limits). Limits come from the "RateLimiting" configuration section.</item>
    /// </list>
    /// </summary>
    public static class RateLimiting
    {
        public const string Global = "api";
        public sealed record Rejection(DateTimeOffset At, string Policy, string Method, string Route, string Partition, int RetryAfterSeconds);
        private static readonly Meter Meter = new("Volvo.TestRequestTool.RateLimiting");
        private static readonly Counter<long> Rejected = Meter.CreateCounter<long>("testrequest.ratelimit.rejected", description: "API calls refused by a rate limit, by policy.");

        /// <summary>The latest 200 rejections and totals by policy, for this application instance.</summary>
        public sealed class Log
        {
            private readonly ConcurrentQueue<Rejection> _recent = new();
            private readonly ConcurrentDictionary<string, long> _totals = new(StringComparer.Ordinal);
            public IReadOnlyList<Rejection> Recent => _recent.ToArray();
            public long Total(string policy) => _totals.GetValueOrDefault(policy);

            public void Record(Rejection r)
            {
                _recent.Enqueue(r);
                while (_recent.Count > 200 && _recent.TryDequeue(out _))
                { }
                _totals.AddOrUpdate(r.Policy, 1, (_, n) => n + 1);
                Rejected.Add(1, new KeyValuePair<string, object?>("policy", r.Policy));
            }
        }

        public static string Key(HttpContext ctx, RateLimitRule rule)
        {
            var user = ctx.User.Identity?.IsAuthenticated == true ? ctx.User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value ?? ctx.User.FindFirst("sub")?.Value : null;
            return rule.PartitionBy == "ip" || user is null ? "ip:" + (ctx.Connection.RemoteIpAddress?.ToString() ?? "unknown") : "user:" + user;
        }

        private static RateLimitPartition<string> Partition(string policy, RateLimitRule rule, HttpContext ctx)
        {
            // The global limiter runs first and the endpoint policy only if it allowed the call, so the last policy recorded
            // here is the one that refused it.
            ctx.Items["ratelimit.policy"] = policy;
            if (rule.ExemptRoles.Any(ctx.User.IsInRole))
            {
                return RateLimitPartition.GetNoLimiter("exempt:" + policy);
            }

            var key = policy + ":" + Key(ctx, rule);
            var window = TimeSpan.FromSeconds(rule.WindowSeconds);
            return rule.Kind switch
            {
                "fixed" => RateLimitPartition.GetFixedWindowLimiter(key, _ => new FixedWindowRateLimiterOptions { PermitLimit = rule.Limit, Window = window, QueueLimit = rule.Queue }),
                // Refilled evenly: Limit tokens per window, a few at a time (at most once a second), never more than Burst held.
                "token" => RateLimitPartition.GetTokenBucketLimiter(key, _ =>
                {
                    var period = TimeSpan.FromSeconds(Math.Max(1.0, (double)rule.WindowSeconds / rule.Limit));
                    return new TokenBucketRateLimiterOptions { TokenLimit = rule.Burst > 0 ? rule.Burst : rule.Limit, TokensPerPeriod = Math.Max(1, (int)Math.Round(rule.Limit * period.TotalSeconds / rule.WindowSeconds)), ReplenishmentPeriod = period, QueueLimit = rule.Queue, AutoReplenishment = true };
                }),
                "concurrency" => RateLimitPartition.GetConcurrencyLimiter(key, _ => new ConcurrencyLimiterOptions { PermitLimit = rule.Limit, QueueLimit = rule.Queue }),
                _ => RateLimitPartition.GetSlidingWindowLimiter(key, _ => new SlidingWindowRateLimiterOptions { PermitLimit = rule.Limit, Window = window, SegmentsPerWindow = Math.Max(1, rule.Segments), QueueLimit = rule.Queue }),
            };
        }

        /// <summary>"name";q=limit;w=window (draft-ietf-httpapi-ratelimit-headers).</summary>
        public static string PolicyHeader(string name, RateLimitRule r) => $"\"{name}\";q={r.Limit};w={r.WindowSeconds}";

        /// <summary>The defaults with the "RateLimiting" section applied over them; throws when a rule is not valid.</summary>
        public static RateLimitSettings Read(IConfiguration configuration)
        {
            var settings = new RateLimitSettings { Policies = RateLimitSettings.Defaults() };
            var section = configuration.GetSection("RateLimiting");
            settings.Enabled = section.GetValue("Enabled", true);
            foreach (var p in section.GetSection("Policies").GetChildren())
            {
                var rule = settings.Policies.TryGetValue(p.Key, out var known) ? known : new RateLimitRule();
                p.Bind(rule);
                settings.Policies[p.Key] = rule;
            }
            foreach (var (name, r) in settings.Policies)
            {
                if (r.Limit < 1 || r.WindowSeconds < 1 || r.Queue < 0 || r.Burst < 0 || r.Kind is not ("fixed" or "sliding" or "token" or "concurrency") || r.PartitionBy is not ("user" or "ip"))
                {
                    throw new InvalidOperationException($"RateLimiting:Policies:{name} is not valid: Kind is fixed, sliding, token or concurrency; Limit and WindowSeconds are at least 1; PartitionBy is user or ip.");
                }
            }

            return settings;
        }

        public static WebApplicationBuilder AddTestRequestRateLimiting(this WebApplicationBuilder builder)
        {
            // Read when the application starts (not here), so configuration added by hosts and tests applies.
            builder.Services.AddSingleton(sp => Read(sp.GetRequiredService<IConfiguration>()));
            builder.Services.AddSingleton<Log>();
            builder.Services.AddRateLimiter(_ => { });
            builder.Services.AddOptions<RateLimiterOptions>().Configure<RateLimitSettings>((o, settings) =>
            {
                o.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
                // Off: every named policy still exists (endpoints refer to them) but never refuses.
                if (!settings.Enabled)
                {
                    foreach (var name in settings.Policies.Keys)
                    {
                        o.AddPolicy(name, _ => RateLimitPartition.GetNoLimiter(name));
                    }
                    return;
                }
                var api = settings.Policies[Global];
                var status = settings.Policies["status"];
                o.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(ctx => !ctx.Request.Path.StartsWithSegments("/api") || ctx.Request.Path.StartsWithSegments("/api/v1/loadtest")
                    ? RateLimitPartition.GetNoLimiter("outside")
                    : HttpMethods.IsGet(ctx.Request.Method) && (ctx.Request.Path.StartsWithSegments("/api/v1/jobs") || ctx.Request.Path.StartsWithSegments("/api/v1/session"))
                        ? Partition("status", status, ctx) : Partition(Global, api, ctx));
                foreach (var (name, rule) in settings.Policies.Where(p => p.Key is not (Global or "status")))
                {
                    o.AddPolicy(name, ctx => Partition(name, rule, ctx));
                }

                o.OnRejected = async (ctx, ct) =>
                {
                    var http = ctx.HttpContext;
                    var policy = http.Items["ratelimit.policy"] as string ?? Global;
                    var rule = settings.Policies.GetValueOrDefault(policy) ?? api;
                    var after = ctx.Lease.TryGetMetadata(MetadataName.RetryAfter, out var ra) ? (int)Math.Ceiling(ra.TotalSeconds) : rule.WindowSeconds;
                    after = Math.Max(1, after);
                    http.Response.Headers.RetryAfter = after.ToString(CultureInfo.InvariantCulture);
                    http.Response.Headers["RateLimit-Policy"] = PolicyHeader(policy, rule);
                    http.Response.Headers["RateLimit"] = $"\"{policy}\";r=0;t={after}";
                    http.RequestServices.GetRequiredService<Log>().Record(new(DateTimeOffset.UtcNow, policy, http.Request.Method, (http.GetEndpoint() as RouteEndpoint)?.RoutePattern.RawText ?? http.Request.Path.Value ?? "", Hash(Key(http, rule)), after));
                    if (http.Request.Path.StartsWithSegments("/api"))
                    {
                        await http.Response.WriteAsJsonAsync(new
                        {
                            type = "https://www.rfc-editor.org/rfc/rfc6585#section-4",
                            title = "rate_limited",
                            status = 429,
                            detail = $"Too many requests ({rule.Limit} per {Describe(rule.WindowSeconds)} for {policy}). Try again in {after} s.",
                            policy,
                            retryAfterSeconds = after,
                            retryable = true,
                        }, ct);
                    }
                };
            });
            return builder;
        }

        private static string Describe(int seconds) => seconds % 3600 == 0 ? (seconds / 3600 == 1 ? "hour" : seconds / 3600 + " hours") : seconds % 60 == 0 ? (seconds / 60 == 1 ? "minute" : seconds / 60 + " minutes") : seconds + " s";
        private static string Hash(string key) => Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(key)))[..12];

        /// <summary>Names the endpoint's policy on every response (RateLimit-Policy), so clients can pace themselves.</summary>
        public static WebApplication UseRateLimitPolicyHeaders(this WebApplication app)
        {
            var settings = app.Services.GetRequiredService<RateLimitSettings>();
            app.Use((ctx, next) =>
            {
                if (settings.Enabled && ctx.Request.Path.StartsWithSegments("/api") && !ctx.Request.Path.StartsWithSegments("/api/v1/loadtest"))
                {
                    ctx.Response.OnStarting(() =>
                    {
                        if (ctx.Response.StatusCode != 429)
                        {
                            var name = ctx.GetEndpoint()?.Metadata.GetMetadata<EnableRateLimitingAttribute>()?.PolicyName;
                            var list = new List<string> { PolicyHeader(Global, settings.Policies[Global]) };
                            if (name is not null && settings.Policies.TryGetValue(name, out var r))
                            {
                                list.Insert(0, PolicyHeader(name, r));
                            }

                            ctx.Response.Headers["RateLimit-Policy"] = string.Join(", ", list);
                        }
                        return Task.CompletedTask;
                    });
                }

                return next(ctx);
            });
            return app;
        }

        public static RouteGroupBuilder MapRateLimitAdmin(this RouteGroupBuilder api)
        {
            api.MapGet("/admin/rate-limits", (RateLimitSettings settings, Log log, EndpointDataSource sources) =>
            {
                var hour = DateTimeOffset.UtcNow.AddHours(-1);
                var recent = log.Recent;
                var routes = sources.Endpoints.OfType<RouteEndpoint>().GroupBy(e => e.Metadata.GetMetadata<EnableRateLimitingAttribute>()?.PolicyName ?? "")
                    .ToDictionary(g => g.Key, g => g.Count());
                return new
                {
                    enabled = settings.Enabled,
                    policies = settings.Policies.Select(p => new
                    {
                        name = p.Key,
                        p.Value.Kind,
                        p.Value.Limit,
                        p.Value.WindowSeconds,
                        p.Value.Burst,
                        p.Value.PartitionBy,
                        p.Value.ExemptRoles,
                        p.Value.Description,
                        header = PolicyHeader(p.Key, p.Value),
                        endpoints = p.Key == Global ? sources.Endpoints.OfType<RouteEndpoint>().Count(e => e.RoutePattern.RawText?.StartsWith("/api", StringComparison.Ordinal) == true) : routes.GetValueOrDefault(p.Key),
                        rejectedLastHour = recent.Count(r => r.Policy == p.Key && r.At >= hour),
                        rejectedSinceStart = log.Total(p.Key),
                    }),
                    recent = recent.Reverse().Take(50),
                    note = "Limits are per person (signed-in id) or per address before sign-in; change them in the RateLimiting configuration section.",
                };
            }).RequireAuthorization("Admin").WithTags("Administration").WithSummary("Rate-limit policies (from configuration), how many endpoints use each, and recent rejections (partition keys are hashed).");
            return api;
        }
    }
}
