using System.Text.Json.Nodes;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// The interface languages installed as packs in wwwroot/i18n (languages.json), so settings accept exactly those codes.
    /// Read once at start-up; adding a language is a new pack file and one line in the manifest (docs/adding-a-language.md).
    /// </summary>
    public static class UiLanguages
    {
        private static IReadOnlySet<string> codes = new HashSet<string>(StringComparer.Ordinal) { "en" };
        public static IReadOnlySet<string> Codes => codes;
        public static bool Has(string? code) => code is not null && codes.Contains(code);

        public static void Load(string? webRoot)
        {
            var path = webRoot is null ? null : Path.Combine(webRoot, "i18n", "languages.json");
            if (path is null || !File.Exists(path))
            {
                return;
            }

            var list = JsonNode.Parse(File.ReadAllText(path))?["languages"]?.AsArray() ?? [];
            var set = new HashSet<string>(StringComparer.Ordinal) { "en" };
            foreach (var l in list)
            {
                if (l?["code"]?.ToString() is { Length: > 0 } c && (l["file"] is null || File.Exists(Path.Combine(webRoot!, "i18n", l["file"]!.ToString()))))
                {
                    set.Add(c);
                }
            }

            codes = set;
        }
    }
}
