using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Web
{
    public static class BatchEndpoints
    {
        public static IServiceCollection AddBatches(this IServiceCollection services) => services.AddHostedService<BatchRunner>();

        private static object Summary(BatchRecord b)
        {
            var done = b.Items.Count(x => x.Status is not ("waiting" or "running"));
            return new
            {
                b.Id,
                b.Name,
                b.Kind,
                b.Status,
                b.DelayMs,
                b.StopOnFailure,
                b.CreatedAt,
                b.StartedAt,
                b.FinishedAt,
                b.Round,
                total = b.Items.Count,
                done,
                progress = b.Items.Count == 0 ? 1 : Math.Round((double)done / b.Items.Count, 3),
                counts = b.Items.GroupBy(x => x.Status).ToDictionary(g => g.Key, g => g.Count()),
                seconds = new { total = Math.Round(b.Items.Sum(x => x.Seconds ?? 0), 2), average = b.Items.Any(x => x.Seconds is not null) ? Math.Round(b.Items.Where(x => x.Seconds is not null).Average(x => x.Seconds!.Value), 2) : 0, slowest = b.Items.Max(x => x.Seconds) ?? 0 },
                current = b.Items.FirstOrDefault(x => x.Status == "running")?.VehicleId,
                items = b.Items,
            };
        }

        private static async Task<BatchRecord> Own(IWorkspaceStore store, Guid id, HttpContext ctx, CancellationToken ct)
        {
            var b = await store.BatchAsync(id, ct);
            return b is not null && b.Actor.Id == ActorFactory.From(ctx.User).Id ? b : throw new RequestFault(404, "batch_missing", "Batch was not found.");
        }

        public static RouteGroupBuilder MapBatches(this RouteGroupBuilder api)
        {
            var g = api.MapGroup("/batches").WithTags("Batch runs");
            g.MapPost("/", async (NewBatch body, HttpContext ctx, IWorkspaceStore store, TimeProvider clock, CancellationToken ct) =>
            {
                var ids = (body.VehicleIds ?? []).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.Ordinal).ToArray();
                if (ids.Length == 0)
                {
                    throw new RequestFault(400, "no_vehicles", "Choose at least one vehicle.");
                }

                if (ids.Length > 200)
                {
                    throw new RequestFault(413, "batch_too_large", "A batch can include up to 200 vehicles.");
                }

                if (!Enum.TryParse<RequestKind>(body.Kind ?? "Software", true, out var kind))
                {
                    throw new RequestFault(400, "request_kind", "Unknown request kind.");
                }

                var delay = Math.Clamp(body.DelayMs ?? 1000, 0, 60_000);
                var actor = ActorFactory.From(ctx.User);
                var batch = new BatchRecord(Guid.NewGuid(), JobActor.From(actor), string.IsNullOrWhiteSpace(body.Name) ? $"Batch of {ids.Length}" : body.Name.Trim(), kind.ToString(),
                    (JsonObject?)body.Template?.DeepClone() ?? new JsonObject(), delay, body.StopOnFailure == true, "queued", clock.GetUtcNow(), ids.Select(v => new BatchItem(v, "waiting")).ToArray());
                batch = await store.SaveBatchAsync(batch, ct);
                return Results.Accepted($"/api/v1/batches/{batch.Id}", Summary(batch));
            }).RequireAuthorization("Operator").RequireRateLimiting("simulation").Pausable("submissions")
              .WithSummary("Start a batch: one request per vehicle, one after another, with delayMs (default 1000) after each completes.");
            g.MapGet("/", async (HttpContext ctx, IWorkspaceStore store, CancellationToken ct) => (await store.BatchesAsync(ActorFactory.From(ctx.User).Id, 30, ct)).Select(Summary))
                .WithSummary("Your recent batches.");
            g.MapGet("/{id:guid}", async (Guid id, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) => Summary(await Own(store, id, ctx, ct)))
                .WithSummary("One batch with every item, its progress and counts.");
            g.MapGet("/{id:guid}/events", async (Guid id, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
                TypedResults.ServerSentEvents(Follow(store, await Own(store, id, ctx, ct), ct), eventType: "batch"))
                .WithSummary("Follow a batch live (Server-Sent Events, event \"batch\") until it finishes.");
            g.MapPost("/{id:guid}/cancel", async (Guid id, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                var b = await Own(store, id, ctx, ct);
                if (b.Status is "finished" or "cancelled")
                {
                    return Results.Ok(Summary(b));
                }

                b = await store.SaveBatchAsync(b with { Status = "cancelled", FinishedAt = DateTimeOffset.UtcNow, Items = b.Items.Select(x => x.Status == "waiting" ? x with { Status = "cancelled" } : x).ToArray() }, ct);
                return Results.Ok(Summary(b));
            }).RequireAuthorization("Operator").WithSummary("Cancel a batch. The request in progress finishes or is cancelled; the rest do not start.");
            g.MapPost("/{id:guid}/retry-failed", async (Guid id, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                var b = await Own(store, id, ctx, ct);
                if (b.Status is "queued" or "running")
                {
                    throw new RequestFault(409, "batch_running", "Wait for the batch to finish before retrying.");
                }

                var again = b.Items.Count(x => x.Status is "failed" or "cancelled" or "skipped");
                if (again == 0)
                {
                    throw new RequestFault(409, "nothing_to_retry", "Every item succeeded; nothing to retry.");
                }

                b = await store.SaveBatchAsync(b with { Status = "queued", Round = b.Round + 1, FinishedAt = null, Items = b.Items.Select(x => x.Status is "failed" or "cancelled" or "skipped" ? x with { Status = "waiting", Error = null } : x).ToArray() }, ct);
                return Results.Accepted($"/api/v1/batches/{b.Id}", Summary(b));
            }).RequireAuthorization("Operator").Pausable("submissions").WithSummary("Run again only the items that failed, were cancelled or skipped. Successful items are not repeated.");
            g.MapGet("/{id:guid}/report", async (Guid id, string? format, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                var b = await Own(store, id, ctx, ct);
                var rows = new JsonArray(b.Items.Select((x, i) => (JsonNode)new JsonObject { ["#"] = i + 1, ["vehicle"] = x.VehicleId, ["status"] = x.Status, ["seconds"] = x.Seconds, ["issues"] = x.Issues, ["attempts"] = x.Attempts, ["started"] = x.StartedAt, ["finished"] = x.FinishedAt, ["error"] = x.Error, ["result"] = x.ResultId?.ToString() }).ToArray());
                var file = $"batch-{b.CreatedAt:yyyyMMdd-HHmm}";
                return (format ?? "json").Equals("csv", StringComparison.OrdinalIgnoreCase)
                    ? Results.File(Encoding.UTF8.GetBytes(DataConverter.ToCsv(rows)), "text/csv", file + ".csv")
                    : Results.File(Encoding.UTF8.GetBytes(System.Text.Json.JsonSerializer.Serialize(Summary(b), ProvenanceService.Json)), "application/json", file + ".json");
            }).WithSummary("The batch report: every item with status, time, issues and attempts, as JSON or CSV.");
            return api;
        }

        private static async IAsyncEnumerable<object> Follow(IWorkspaceStore store, BatchRecord b, [EnumeratorCancellation] CancellationToken ct)
        {
            var until = DateTimeOffset.UtcNow.AddHours(2);
            string? last = null;
            while (!ct.IsCancellationRequested && DateTimeOffset.UtcNow < until)
            {
                var state = string.Join(",", b.Items.Select(x => x.Status)) + b.Status;
                if (state != last)
                {
                    last = state;
                    yield return Summary(b);
                }
                if (b.Status is "finished" or "cancelled")
                {
                    yield break;
                }

                await Task.Delay(500, ct).ConfigureAwait(ConfigureAwaitOptions.SuppressThrowing);
                if (await store.BatchAsync(b.Id, CancellationToken.None) is not { } next)
                {
                    yield break;
                }

                b = next;
            }
        }
    }
}
