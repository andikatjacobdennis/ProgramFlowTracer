using System.Text.Json;
using System.Text.Json.Nodes;
using Microsoft.Extensions.Options;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
using Volvo.TestRequestTool.Infrastructure;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Where the data lives and how external services are reached, both from the settings:
    /// <list type="bullet">
    /// <item><b>Repository</b> (Repository:Provider, Repository:Path, Repository:Formats): the workspace, users and catalog.
    /// Provider "Files" keeps one file per record under the path (JSON, or XML for the collections Formats names). Another
    /// provider (a database) is an <see cref="IDocumentStore"/> registered here; changing the repository needs a restart.</item>
    /// <item><b>Services</b> (Services:Path, Services:Endpoints:&lt;name&gt;): EDB, CBR, KAX, VESPA, Dependix and Digital Twin,
    /// each through files under the path, over HTTP, or off. Changes apply to the next call.</item>
    /// <item><b>Settings file</b> (Settings:File, default C:\trt\settings.json): read on top of appsettings.json, and written
    /// by Administration › Data and services.</item>
    /// </list>
    /// A new repository or services folder is filled once with the reference data shipped with the app (RepositorySeeder).
    /// </summary>
    public static class DataSetup
    {
        public const string DefaultRepository = @"C:\trt\repo", DefaultServices = @"C:\trt\services", DefaultSettingsFile = @"C:\trt\settings.json";

        /// <summary>Collections kept as XML unless the settings say otherwise: vehicles are product documents.</summary>
        private static readonly Dictionary<string, string> DefaultFormats = new(StringComparer.OrdinalIgnoreCase)
        {
            [WorkspaceRepository.Collections.Vehicles] = "xml",
            [WorkspaceRepository.Collections.Originals] = "xml",
            [WorkspaceRepository.Collections.Revisions] = "xml",
        };

        public static string RepositoryPath(IConfiguration config) => Path.GetFullPath(config["Repository:Path"] ?? DefaultRepository);
        public static string RepositoryProvider(IConfiguration config) => config["Repository:Provider"] ?? "Files";
        public static string SettingsFile(IConfiguration config) => Path.GetFullPath(config["Settings:File"] ?? DefaultSettingsFile);

        public static Dictionary<string, string> Formats(IConfiguration config)
        {
            var formats = new Dictionary<string, string>(DefaultFormats, StringComparer.OrdinalIgnoreCase);
            foreach (var c in config.GetSection("Repository:Formats").GetChildren())
            {
                if (c.Value is { } v)
                {
                    formats[c.Key] = v.ToLowerInvariant();
                }
            }

            return formats;
        }

        public static WebApplicationBuilder AddTestRequestData(this WebApplicationBuilder builder)
        {
            var config = builder.Configuration;
            // The settings file comes last, so what an administrator saves wins over appsettings.json.
            config.AddJsonFile(SettingsFile(config), optional: true, reloadOnChange: true);
            var services = builder.Services;
            services.Configure<ServiceSettings>(config.GetSection("Services"));
            services.AddSingleton<IDocumentStore>(sp =>
            {
                var provider = RepositoryProvider(config);
                IDocumentStore docs = provider.Equals("Files", StringComparison.OrdinalIgnoreCase)
                    ? new FileDocumentStore(RepositoryPath(config), Formats(config))
                    : throw new InvalidOperationException($"The repository provider \"{provider}\" is not available. Use Files, or register an IDocumentStore for it (see docs/data-and-services.md).");
                // Start-up only, on a thread-pool thread without a synchronization context, so waiting here cannot deadlock.
                if (config.GetValue("Repository:Seed", true))
                {
                    RepositorySeeder.SeedRepositoryAsync(docs, sp.GetRequiredService<TimeProvider>(), CancellationToken.None).GetAwaiter().GetResult();
                }

                return docs;
            });
            services.AddSingleton<ICatalog>(sp => new JsonCatalog(sp.GetRequiredService<IDocumentStore>()));
            services.AddSingleton(sp => new WorkspaceRepository(sp.GetRequiredService<IDocumentStore>(), sp.GetRequiredService<TimeProvider>()));
            services.AddSingleton<IWorkspaceStore>(sp => sp.GetRequiredService<WorkspaceRepository>());
            services.AddSingleton<IServiceGateway>(sp =>
            {
                var settings = sp.GetRequiredService<IOptionsMonitor<ServiceSettings>>();
                if (config.GetValue("Services:Seed", true))
                {
                    RepositorySeeder.SeedServicesAsync(settings.CurrentValue.Path, CancellationToken.None).GetAwaiter().GetResult();
                }

                return new ServiceGateway(() => settings.CurrentValue);
            });
            services.AddSingleton<ExternalSources>();
            foreach (var name in new[] { "KAX", "VESPA", "Dependix", "DigitalTwin" })
            {
                services.AddSingleton<IExternalCapability>(sp => new GatewayCapability(name, sp.GetRequiredService<IServiceGateway>()));
            }

            services.AddSingleton<UserDirectory>();
            return builder;
        }

        // ------------------------------------------------------------------ Administration › Data and services
        public sealed record ServiceChange(string? Transport, string? BaseUrl, string? Folder, int? TimeoutSeconds);
        public sealed record RepositoryChange(string? Provider, string? Path, Dictionary<string, string>? Formats);
        private static readonly string[] Transports = ["Files", "Http", "Off"];

        public static void MapTestRequestData(this RouteGroupBuilder api)
        {
            var admin = api.MapGroup("/admin/data").RequireAuthorization("Admin").WithTags("Administration");
            admin.MapGet("/", async (IConfiguration config, IDocumentStore docs, WorkspaceRepository repo, IOptionsMonitor<ServiceSettings> services, IServiceGateway gateway, CancellationToken ct) =>
            {
                var counts = await repo.CountsAsync(ct);
                var s = services.CurrentValue;
                // What the settings say now; the running repository was chosen at start-up.
                var savedProvider = RepositoryProvider(config);
                var savedPath = RepositoryPath(config);
                var running = docs is FileDocumentStore files ? ("Files", files.Root) : (docs.GetType().Name, "");
                return Results.Ok(new
                {
                    settingsFile = SettingsFile(config),
                    repository = new
                    {
                        provider = running.Item1,
                        path = running.Item2,
                        description = docs.Description,
                        formats = Formats(config),
                        collections = counts,
                        restartNeeded = !savedProvider.Equals(running.Item1, StringComparison.OrdinalIgnoreCase) || !string.Equals(savedPath, running.Item2, StringComparison.OrdinalIgnoreCase),
                        saved = new { provider = savedProvider, path = savedPath },
                    },
                    services = new
                    {
                        path = s.Path,
                        endpoints = RepositorySeeder.Services.Keys.Select(name =>
                        {
                            var e = s.For(name);
                            return new { name, transport = e.Transport, baseUrl = e.BaseUrl, folder = s.FolderOf(name), timeoutSeconds = e.TimeoutSeconds, configured = gateway.IsConfigured(name) };
                        }),
                    },
                });
            }).WithSummary("The repository (provider, path, formats, record counts) and every external service's transport.");

            admin.MapPut("/services/{name}", async (string name, ServiceChange body, IConfiguration config, CancellationToken ct) =>
            {
                if (!RepositorySeeder.Services.ContainsKey(name))
                {
                    throw new RequestFault(404, "service_unknown", $"There is no service called {name}.");
                }

                var transport = Transports.FirstOrDefault(t => t.Equals(body.Transport ?? "Files", StringComparison.OrdinalIgnoreCase)) ?? throw new RequestFault(400, "service_transport", "Transport must be Files, Http or Off.");
                if (transport == "Http" && !(Uri.TryCreate(body.BaseUrl, UriKind.Absolute, out var u) && u.Scheme is "https" or "http"))
                {
                    throw new RequestFault(400, "service_address", "Enter the service's base URL, for example https://edb.example.com/api.");
                }

                if (body.Folder is { Length: > 0 } f && (f.Length > 100 || f.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0))
                {
                    throw new RequestFault(400, "service_folder", "The folder is a single folder name under the services path.");
                }

                var endpoint = new JsonObject { ["Transport"] = transport, ["BaseUrl"] = string.IsNullOrWhiteSpace(body.BaseUrl) ? null : body.BaseUrl.Trim(), ["Folder"] = string.IsNullOrWhiteSpace(body.Folder) ? null : body.Folder.Trim(), ["TimeoutSeconds"] = Math.Clamp(body.TimeoutSeconds ?? 30, 1, 300) };
                await SaveSettingsAsync(config, root => Section(Section(root, "Services"), "Endpoints")[RepositorySeeder.Services.Keys.First(k => k.Equals(name, StringComparison.OrdinalIgnoreCase))] = endpoint, ct);
                return Results.Ok(new { saved = true, appliesTo = "the next call" });
            }).Audited("data.service").WithSummary("Change how one service is reached: Files, Http (with a base URL) or Off. Applies to the next call.");

            admin.MapPut("/services", async (JsonObject body, IConfiguration config, CancellationToken ct) =>
            {
                var path = body["path"]?.GetValue<string>()?.Trim();
                if (string.IsNullOrEmpty(path) || !Path.IsPathFullyQualified(path))
                {
                    throw new RequestFault(400, "services_path", "Enter a full folder path, for example C:\\trt\\services.");
                }

                await SaveSettingsAsync(config, root => Section(root, "Services")["Path"] = path, ct);
                return Results.Ok(new { saved = true, appliesTo = "the next call" });
            }).Audited("data.services-path").WithSummary("Change the folder the file transport reads services from.");

            admin.MapPut("/repository", async (RepositoryChange body, IConfiguration config, CancellationToken ct) =>
            {
                var provider = string.IsNullOrWhiteSpace(body.Provider) ? "Files" : body.Provider.Trim();
                if (!provider.Equals("Files", StringComparison.OrdinalIgnoreCase))
                {
                    throw new RequestFault(400, "repository_provider", "Only the Files provider is installed. A database provider is added in code first (see docs/data-and-services.md).");
                }

                var path = body.Path?.Trim();
                if (string.IsNullOrEmpty(path) || !Path.IsPathFullyQualified(path))
                {
                    throw new RequestFault(400, "repository_path", "Enter a full folder path, for example C:\\trt\\repo.");
                }

                var formats = new JsonObject();
                foreach (var (collection, format) in body.Formats ?? [])
                {
                    if (format is not ("json" or "xml"))
                    {
                        throw new RequestFault(400, "repository_format", "A collection's format is json or xml.");
                    }

                    formats[collection] = format;
                }
                await SaveSettingsAsync(config, root =>
                {
                    var r = Section(root, "Repository");
                    r["Provider"] = "Files";
                    r["Path"] = path;
                    if (body.Formats is not null)
                    {
                        r["Formats"] = formats;
                    }
                }, ct);
                return Results.Ok(new { saved = true, appliesTo = "the next start" });
            }).Audited("data.repository").WithSummary("Change the repository folder or formats. Applies when the app next starts.");

            admin.MapPost("/services/{name}/check", async (string name, IOptionsMonitor<ServiceSettings> services, CancellationToken ct) =>
            {
                if (!RepositorySeeder.Services.ContainsKey(name))
                {
                    throw new RequestFault(404, "service_unknown", $"There is no service called {name}.");
                }

                var s = services.CurrentValue;
                var e = s.For(name);
                switch (e.Transport.ToLowerInvariant())
                {
                    case "off":
                        return Results.Ok(new { ok = false, detail = $"{name} is turned off." });
                    case "files":
                        var folder = s.FolderOf(name);
                        return Results.Ok(Directory.Exists(folder) ? new { ok = true, detail = $"The folder {folder} is there." } : new { ok = false, detail = $"The folder {folder} does not exist." });
                    default:
                        if (!Uri.TryCreate(e.BaseUrl, UriKind.Absolute, out var url))
                        {
                            return Results.Ok(new { ok = false, detail = "No valid base URL." });
                        }

                        using (var client = new HttpClient { Timeout = TimeSpan.FromSeconds(5) })
                        {
                            try
                            {
                                using var r = await client.GetAsync(url, ct);
                                return Results.Ok(new { ok = true, detail = $"{url} answered {(int)r.StatusCode}." });
                            }
                            catch (Exception x) when (x is HttpRequestException or TaskCanceledException)
                            {
                                return Results.Ok(new { ok = false, detail = $"{url} cannot be reached." });
                            }
                        }
                }
            }).WithSummary("Whether a service can be reached with its current settings.");
        }

        private static JsonObject Section(JsonObject parent, string name)
        {
            if (parent[name] is JsonObject o)
            {
                return o;
            }

            var created = new JsonObject();
            parent[name] = created;
            return created;
        }

        private static readonly SemaphoreSlim SettingsGate = new(1, 1);

        /// <summary>Changes the settings file (keeping everything else in it) and reloads the settings at once.</summary>
        private static async Task SaveSettingsAsync(IConfiguration config, Action<JsonObject> change, CancellationToken ct)
        {
            var file = SettingsFile(config);
            await SettingsGate.WaitAsync(ct);
            try
            {
                var root = File.Exists(file) ? JsonNode.Parse(await File.ReadAllTextAsync(file, ct)) as JsonObject ?? new JsonObject() : new JsonObject();
                change(root);
                Directory.CreateDirectory(Path.GetDirectoryName(file)!);
                var temporary = file + "." + Guid.NewGuid().ToString("N") + ".tmp";
                await File.WriteAllTextAsync(temporary, root.ToJsonString(new JsonSerializerOptions { WriteIndented = true }), ct);
                await FileDocumentStore.ReplaceAsync(temporary, file, ct);
            }
            finally
            {
                SettingsGate.Release();
            }
            (config as IConfigurationRoot)?.Reload();
        }
    }
}
