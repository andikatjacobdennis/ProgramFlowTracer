using System.Diagnostics;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Volvo.TestRequestTool.Application;

namespace Volvo.TestRequestTool.Web
{
    // ------------------------------------------------------------------ health checks
    public sealed class StoreHealthCheck : IHealthCheck
    {
        private readonly IWorkspaceStore _store;

        public StoreHealthCheck(IWorkspaceStore store)
        {
            _store = store;
        }

        public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken ct = default)
        {
            var sw = Stopwatch.StartNew();
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
            timeout.CancelAfter(TimeSpan.FromSeconds(3));
            try
            {
                await _store.JobLoadAsync("-", timeout.Token);
                var data = new Dictionary<string, object> { ["ms"] = Math.Round(sw.Elapsed.TotalMilliseconds, 1) };
                return sw.Elapsed > TimeSpan.FromSeconds(1) ? HealthCheckResult.Degraded("The store answers slowly.", data: data) : HealthCheckResult.Healthy("The store answers.", data);
            }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested)
            {
                return HealthCheckResult.Unhealthy("The store did not answer within 3 s.");
            }
        }
    }
}
