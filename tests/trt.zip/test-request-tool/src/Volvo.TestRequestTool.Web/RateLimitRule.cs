namespace Volvo.TestRequestTool.Web
{
    /// <summary>One limit: how many calls a partition (a person, or an address before sign-in) may make.</summary>
    public sealed class RateLimitRule
    {
        /// <summary>fixed (window), sliding (window in segments), token (bucket: Burst at once, Limit per window) or concurrency (Limit at the same time).</summary>
        public string Kind { get; set; } = "sliding";
        public int Limit { get; set; } = 60;
        public int WindowSeconds { get; set; } = 60;
        public int Segments { get; set; } = 6;
        public int Burst { get; set; }
        public int Queue { get; set; }
        /// <summary>user (signed-in id, else address) or ip (always the address: sign-in and anonymous endpoints).</summary>
        public string PartitionBy { get; set; } = "user";
        /// <summary>Roles that bypass this rule (for example LoadTester on the load endpoints). Empty by default.</summary>
        public string[] ExemptRoles { get; set; } = [];
        public string Description { get; set; } = "";
    }
}
