namespace Volvo.TestRequestTool.Web
{
    public sealed record ChatMessageIn([property: System.ComponentModel.DataAnnotations.StringLength(12)] string? Role, [property: System.ComponentModel.DataAnnotations.StringLength(8000)] string? Text);
}
