namespace Volvo.TestRequestTool.Web
{
    public sealed record Consent(bool? Record);
}
