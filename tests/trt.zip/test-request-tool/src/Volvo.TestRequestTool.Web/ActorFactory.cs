using System.Security.Claims;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Web
{
    public static class ActorFactory
    {
        public static Actor From(ClaimsPrincipal user)
        {
            var id = user.FindFirstValue(ClaimTypes.NameIdentifier) ?? user.FindFirstValue("sub");
            if (string.IsNullOrWhiteSpace(id))
            {
                throw new RequestFault(401, "identity_required", "A subject identifier is required.");
            }

            var contexts = user.FindAll("context").Select(c => int.TryParse(c.Value, out var n) ? n : -1).Where(n => n > 0).ToHashSet();
            return new Actor(id, contexts, user.IsInRole("Writer"), user.FindFirstValue(ClaimTypes.Name) ?? user.FindFirstValue("name"));
        }
    }
}
