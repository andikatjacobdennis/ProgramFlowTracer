namespace Volvo.TestRequestTool.Web
{
    public sealed record ReviewVersion(long Version);
}
