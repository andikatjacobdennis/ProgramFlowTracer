using System.Diagnostics.Metrics;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Application metrics (FR-24, FR-50) on System.Diagnostics.Metrics, created through IMeterFactory so they are scoped to
    /// the host and testable. They sit next to the metrics ASP.NET Core already emits (requests, Kestrel, rate limiting and, new
    /// in .NET 10, authentication and authorization). Watch them locally with
    /// <c>dotnet-counters monitor -n Volvo.TestRequestTool.Web --counters Volvo.TestRequestTool,Microsoft.AspNetCore.Hosting</c>, or export
    /// them with OpenTelemetry in production.
    /// </summary>
    public sealed class TestRequestMetrics
    {
        public const string MeterName = "Volvo.TestRequestTool";
        private readonly Counter<long> _submitted, _completed, _rejected;
        private readonly Histogram<double> _duration, _wait;
        private int _queued, _running;

        public TestRequestMetrics(IMeterFactory factory)
        {
            var meter = factory.Create(MeterName);
            _submitted = meter.CreateCounter<long>("testrequest.jobs.submitted", "{job}", "Jobs accepted, by lane.");
            _rejected = meter.CreateCounter<long>("testrequest.jobs.rejected", "{job}", "Jobs refused by admission control, by reason.");
            _completed = meter.CreateCounter<long>("testrequest.jobs.completed", "{job}", "Jobs finished, by status and lane.");
            _duration = meter.CreateHistogram<double>("testrequest.jobs.duration", "s", "Time a job spent running.");
            _wait = meter.CreateHistogram<double>("testrequest.jobs.queue_wait", "s", "Time from acceptance to the start of the first attempt (queue age).");
            meter.CreateObservableGauge("testrequest.jobs.queued", () => Volatile.Read(ref _queued), "{job}", "Jobs waiting.");
            meter.CreateObservableGauge("testrequest.jobs.running", () => Volatile.Read(ref _running), "{job}", "Jobs running.");
        }

        public void Submitted(string lane) => _submitted.Add(1, new KeyValuePair<string, object?>("lane", lane));
        public void Rejected(string reason) => _rejected.Add(1, new KeyValuePair<string, object?>("reason", reason));

        public void Completed(JobRecord job, string status)
        {
            _completed.Add(1, new("status", status), new("lane", job.Lane));
            if (job.StartedAt is { } started)
            {
                _wait.Record((started - job.CreatedAt).TotalSeconds, new KeyValuePair<string, object?>("lane", job.Lane));
                _duration.Record((DateTimeOffset.UtcNow - started).TotalSeconds, new("status", status), new("lane", job.Lane));
            }
        }

        public void Load(int queuedNow, int runningNow)
        {
            Volatile.Write(ref _queued, queuedNow);
            Volatile.Write(ref _running, runningNow);
        }
    }
}
