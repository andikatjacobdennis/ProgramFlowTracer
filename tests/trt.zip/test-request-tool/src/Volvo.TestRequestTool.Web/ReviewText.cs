using Volvo.TestRequestTool.Application;

namespace Volvo.TestRequestTool.Web
{
    public sealed record ReviewText([property: System.ComponentModel.DataAnnotations.StringLength(ReviewService.MaxText)] string? Text);
}
