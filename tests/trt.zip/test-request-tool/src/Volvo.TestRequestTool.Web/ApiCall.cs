namespace Volvo.TestRequestTool.Web
{
    /// <summary>One finished API call, without bodies or personal data beyond the user id.</summary>
    public sealed record ApiCall(DateTimeOffset At, string Method, string Route, string Path, int Status, double Ms, long? RequestBytes, long? ResponseBytes, string User);
}
