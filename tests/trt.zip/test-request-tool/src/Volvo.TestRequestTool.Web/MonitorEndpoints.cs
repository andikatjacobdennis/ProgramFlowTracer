using Volvo.TestRequestTool.Application;
namespace Volvo.TestRequestTool.Web
{
    public static class MonitorEndpoints
    {
        public static IServiceCollection AddServiceMonitor(this IServiceCollection services)
        {
            services.AddSingleton<ServiceMonitor>();
            services.AddHostedService(sp => sp.GetRequiredService<ServiceMonitor>());
            return services;
        }

        private static (DateTimeOffset From, DateTimeOffset To) Range(TimeProvider clock, DateTimeOffset? from, DateTimeOffset? to, string? window)
        {
            var end = to ?? clock.GetUtcNow();
            var span = window switch { "1h" => TimeSpan.FromHours(1), "6h" => TimeSpan.FromHours(6), "7d" => TimeSpan.FromDays(7), "30d" => TimeSpan.FromDays(30), "90d" => TimeSpan.FromDays(90), _ => TimeSpan.FromHours(24) };
            var start = from ?? end - span;
            if (end - start > TimeSpan.FromDays(92))
            {
                start = end - TimeSpan.FromDays(92);   // bounded work (FR-35)
            }

            if (start >= end)
            {
                throw new Domain.RequestFault(400, "range", "from must be before to.");
            }

            return (start, end);
        }

        private static IReadOnlyList<ServiceIncident> AllIncidents(ServiceMonitor monitor, DateTimeOffset from, DateTimeOffset to, string? service, DateTimeOffset now) =>
            ServiceModel.Incidents(from, to, service, now)
                .Concat(ServiceModel.Services.Where(s => !s.Simulated && (service is null || s.Id.Equals(service, StringComparison.OrdinalIgnoreCase))).SelectMany(s => monitor.LiveIncidents(s.Id, from, to)))
                .OrderByDescending(i => i.Start).ToArray();

        /// <summary>Availability counts degraded minutes as half available.</summary>
        private static object Summary(MonitoredService s, ServiceMonitor monitor, DateTimeOffset from, DateTimeOffset to, DateTimeOffset now)
        {
            var buckets = ServiceModel.History(s, from, to, ServiceModel.BucketFor(to - from), s.Simulated ? null : monitor.Live(s.Id, from, to)).Where(b => b.Status != "nodata").ToArray();
            var incidents = AllIncidents(monitor, from, to, s.Id, now);
            var current = monitor.Last(s.Id) ?? (s.Simulated ? ServiceModel.At(s, now) : null);
            return new
            {
                s.Id,
                s.Name,
                s.Kind,
                s.Simulated,
                s.Description,
                dependsOn = s.DependsOn,
                status = current?.Status ?? "unknown",
                lastCheck = current?.At,
                lastMs = current?.Ms,
                detail = current?.Detail,
                availability = buckets.Length == 0 ? (double?)null : Math.Round(buckets.Average(b => b.Availability) * 100, 3),
                p95Ms = buckets.Length == 0 ? 0 : Math.Round(buckets.Max(b => b.P95Ms), 1),
                incidents = incidents.Count,
                downMinutes = Math.Round(incidents.Where(i => i.Severity == "down").Sum(i => i.Minutes), 1),
                lastIncident = incidents.FirstOrDefault(),
                bars = buckets.Length == 0 ? [] : ServiceModel.History(s, from, to, TimeSpan.FromTicks(Math.Max(TimeSpan.FromMinutes(1).Ticks, (to - from).Ticks / 48)), s.Simulated ? null : monitor.Live(s.Id, from, to)).Select(b => b.Status).ToArray(),
            };
        }

        public static RouteGroupBuilder MapMonitoring(this RouteGroupBuilder api)
        {
            var mon = api.MapGroup("/monitor").WithTags("Monitoring").RequireFeature("service-health");
            mon.MapGet("/services", (ServiceMonitor monitor, TimeProvider clock, string? window) =>
            {
                var (from, to) = Range(clock, null, null, window);
                return new { from, to, interval = ServiceMonitor.Interval.TotalSeconds, services = ServiceModel.Services.Select(s => Summary(s, monitor, from, to, clock.GetUtcNow())) };
            }).WithSummary("Every monitored service: current status, availability, p95 latency, incidents and a status strip for the window (1h, 6h, 24h, 7d, 30d, 90d).");

            mon.MapGet("/history", (ServiceMonitor monitor, TimeProvider clock, string? service, DateTimeOffset? from, DateTimeOffset? to, string? window, int? bucketMinutes) =>
            {
                var (start, end) = Range(clock, from, to, window);
                var bucket = bucketMinutes is > 0 ? TimeSpan.FromMinutes(Math.Clamp(bucketMinutes.Value, 1, 1440)) : ServiceModel.BucketFor(end - start);
                if ((end - start).Ticks / bucket.Ticks > 2000)
                {
                    bucket = TimeSpan.FromTicks((end - start).Ticks / 2000);   // at most 2,000 points
                }

                var list = service is null ? ServiceModel.Services : ServiceModel.Services.Where(s => s.Id.Equals(service, StringComparison.OrdinalIgnoreCase)).ToArray();
                if (list.Count == 0)
                {
                    throw new Domain.RequestFault(404, "service_missing", "No such service.");
                }

                return new { from = start, to = end, bucketMinutes = bucket.TotalMinutes, series = list.Select(s => new { s.Id, s.Name, s.Simulated, points = ServiceModel.History(s, start, end, bucket, s.Simulated ? null : monitor.Live(s.Id, start, end)) }) };
            }).WithSummary("Time series per service: minutes up, degraded and down, availability and latency per bucket.");

            mon.MapGet("/incidents", (ServiceMonitor monitor, TimeProvider clock, string? service, DateTimeOffset? from, DateTimeOffset? to, string? window, string? cause, string? severity, bool? planned, string? q, int? skip, int? take) =>
            {
                var (start, end) = Range(clock, from, to, window ?? "30d");
                var list = AllIncidents(monitor, start, end, service, clock.GetUtcNow()).Where(i =>
                    (cause is null || i.Cause.Equals(cause, StringComparison.OrdinalIgnoreCase)) && (severity is null || i.Severity.Equals(severity, StringComparison.OrdinalIgnoreCase)) &&
                    (planned is null || i.Planned == planned) && (string.IsNullOrWhiteSpace(q) || $"{i.Service} {i.CauseTitle} {i.RootCause}".Contains(q, StringComparison.OrdinalIgnoreCase))).ToArray();
                return new { from = start, to = end, total = list.Length, items = list.Skip(Math.Max(0, skip ?? 0)).Take(Math.Clamp(take ?? 50, 1, 500)) };
            }).WithSummary("Incidents with their root cause: filter by service, cause, severity, planned and text.");

            mon.MapGet("/incidents/{id}", (string id, ServiceMonitor monitor, TimeProvider clock) =>
            {
                var parts = id.Split('-', 2);
                if (parts.Length != 2 || !long.TryParse(parts[1], out var unix))
                {
                    throw new Domain.RequestFault(400, "incident_id", "Incident ids look like vda-1760000000.");
                }

                var at = DateTimeOffset.FromUnixTimeSeconds(unix);
                var all = AllIncidents(monitor, at.AddDays(-1), at.AddDays(2), null, clock.GetUtcNow());
                var incident = all.FirstOrDefault(i => i.Id == id) ?? throw new Domain.RequestFault(404, "incident_missing", "No such incident.");
                // The chain back to the first failure, and everything that failed because of this incident.
                var chain = new List<ServiceIncident>();
                for (var cur = incident; cur.RootIncident is not null;)
                {
                    var root = all.FirstOrDefault(i => i.Id == cur.RootIncident);
                    if (root is null || chain.Contains(root))
                    {
                        break;
                    }

                    chain.Add(root);
                    cur = root;
                }
                var caused = all.Where(i => i.RootIncident == id).ToArray();
                var s = ServiceModel.Find(incident.Service)!;
                var around = ServiceModel.History(s, incident.Start.AddMinutes(-30), (incident.End ?? clock.GetUtcNow()).AddMinutes(30), TimeSpan.FromMinutes(1), s.Simulated ? null : monitor.Live(s.Id, incident.Start.AddMinutes(-30), (incident.End ?? clock.GetUtcNow()).AddMinutes(30)));
                return new { incident, rootChain = chain, caused, history = around };
            }).WithSummary("One incident: root-cause chain back to the first failure, what it caused, and minute-by-minute history around it.");

            mon.MapGet("/insights", (ServiceMonitor monitor, TimeProvider clock, string? window, double? slo) =>
            {
                var (from, to) = Range(clock, null, null, window ?? "30d");
                var target = Math.Clamp(slo ?? 99.5, 90, 99.999);
                var incidents = AllIncidents(monitor, from, to, null, clock.GetUtcNow());
                var span = (to - from).TotalMinutes;
                var perService = ServiceModel.Services.Select(s =>
                {
                    var mine = incidents.Where(i => i.Service == s.Id).OrderBy(i => i.Start).ToArray();
                    var unplanned = mine.Where(i => !i.Planned).ToArray();
                    var down = mine.Where(i => i.Severity == "down" && !i.Planned).Sum(i => i.Minutes) + mine.Where(i => i.Severity == "degraded" && !i.Planned).Sum(i => i.Minutes) * .5;
                    var budget = span * (1 - target / 100);
                    var gaps = unplanned.Zip(unplanned.Skip(1), (a, b) => (b.Start - a.Start).TotalHours).ToArray();
                    return new
                    {
                        s.Id,
                        s.Name,
                        s.Simulated,
                        incidents = unplanned.Length,
                        planned = mine.Length - unplanned.Length,
                        mttrMinutes = unplanned.Length == 0 ? 0 : Math.Round(unplanned.Average(i => i.Minutes), 1),
                        mtbfHours = gaps.Length == 0 ? (double?)null : Math.Round(gaps.Average(), 1),
                        availability = Math.Round(100 - down / span * 100, 3),
                        budgetMinutes = Math.Round(budget, 1),
                        budgetUsed = budget <= 0 ? 0 : Math.Round(down / budget * 100, 1),
                        rootCauseShare = unplanned.Length == 0 ? 0 : Math.Round(unplanned.Count(i => i.RootService is null) * 100.0 / unplanned.Length, 1),
                    };
                }).ToArray();
                var unplannedAll = incidents.Where(i => !i.Planned).ToArray();
                return new
                {
                    from,
                    to,
                    slo = target,
                    total = unplannedAll.Length,
                    mttrMinutes = unplannedAll.Length == 0 ? 0 : Math.Round(unplannedAll.Average(i => i.Minutes), 1),
                    causes = unplannedAll.GroupBy(i => i.CauseTitle).Select(g => new { cause = g.Key, count = g.Count(), minutes = Math.Round(g.Sum(i => i.Minutes), 1) }).OrderByDescending(x => x.minutes).ToArray(),
                    // Which services start trouble: incidents they caused in others.
                    origins = incidents.Where(i => i.RootService is not null).GroupBy(i => i.RootService!).Select(g => new { service = g.Key, caused = g.Count() }).OrderByDescending(x => x.caused).ToArray(),
                    // Incident minutes by weekday and hour (UTC): when trouble happens.
                    heat = Enumerable.Range(0, 7).Select(d => Enumerable.Range(0, 24).Select(h => Math.Round(unplannedAll.Where(i => (int)i.Start.UtcDateTime.DayOfWeek == d && i.Start.UtcDateTime.Hour == h).Sum(i => i.Minutes), 1)).ToArray()).ToArray(),
                    perDay = unplannedAll.GroupBy(i => i.Start.UtcDateTime.Date).OrderBy(g => g.Key).Select(g => new { day = g.Key.ToString("yyyy-MM-dd"), count = g.Count(), minutes = Math.Round(g.Sum(i => i.Minutes), 1) }).ToArray(),
                    services = perService,
                };
            }).WithSummary("Reliability insights: time to recover (MTTR), time between failures (MTBF), error budget against an SLO, top causes, where failures start, and when they happen.");

            mon.MapPost("/check/{service}", async (string service, ServiceMonitor monitor, CancellationToken ct) =>
                await monitor.CheckAsync(ServiceModel.Find(service) ?? throw new Domain.RequestFault(404, "service_missing", "No such service."), ct))
                .WithSummary("Check one service now. Simulated services answer from the simulation; internal ones are measured.");
            return api;
        }
    }
}
