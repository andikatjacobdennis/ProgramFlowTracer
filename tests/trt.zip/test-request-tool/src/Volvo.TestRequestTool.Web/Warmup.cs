using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>Does the one-time work at start-up. Failures are logged and never stop the host: the work then happens on first use.</summary>
    public sealed class Warmup : BackgroundService
    {
        private readonly IServiceProvider _services;
        private readonly ILogger<Warmup> _log;
        public volatile bool Done;

        public Warmup(IServiceProvider services, ILogger<Warmup> log)
        {
            _services = services;
            _log = log;
        }

        public TimeSpan Took { get; private set; }

        protected override async Task ExecuteAsync(CancellationToken stop)
        {
            var started = System.Diagnostics.Stopwatch.GetTimestamp();
            try
            {
                var catalog = _services.GetRequiredService<ICatalog>();    // reads the catalog from the repository
                var repository = _services.GetRequiredService<Volvo.TestRequestTool.Infrastructure.WorkspaceRepository>();
                await repository.LoadAllAsync(stop);                      // users, vehicles, requests, reviews, jobs, settings into memory
                var vehicles = await repository.VehiclesAsync(stop);
                _ = _services.GetRequiredService<IServiceGateway>();       // prepares the services folder
                // Run the fleet summary once (the slowest first call in the application), so its code is compiled before anyone asks.
                var contexts = catalog.Data.A("contexts").Objects().Select(c => c.I("id")).ToHashSet();
                await _services.GetRequiredService<VehicleInsights>().FleetAsync(new Actor("system:warm-up", contexts, true, "Warm-up"), false, stop);
                _log.LogInformation("Warm-up done: {Vehicles} vehicles ready in {Ms:0} ms", vehicles.Count, System.Diagnostics.Stopwatch.GetElapsedTime(started).TotalMilliseconds);
            }
            // Stopping the host (for example ending a debugging session) while the warm-up runs is normal, not an error.
            catch (OperationCanceledException) when (stop.IsCancellationRequested)
            {
                _log.LogDebug("Warm-up stopped: the host is shutting down");
            }
            catch (Exception e)
            {
                _log.LogWarning(e, "Warm-up did not finish; the work will happen on first use");
            }
            finally
            {
                Took = System.Diagnostics.Stopwatch.GetElapsedTime(started);
                Done = true;
            }
        }
    }
}
