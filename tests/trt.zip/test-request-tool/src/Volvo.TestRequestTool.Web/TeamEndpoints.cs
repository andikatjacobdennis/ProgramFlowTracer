using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Teams and managed settings. Settings resolve in layers, the first that applies wins:
    /// <list type="number">
    /// <item>a <b>locked</b> team or organisation setting (people see who set it and cannot change it);</item>
    /// <item>the person's own choice;</item>
    /// <item>their team's default (several teams: the team listed first);</item>
    /// <item>the organisation default;</item>
    /// <item>the built-in default.</item>
    /// </list>
    /// Administrators change one team or many at once: a preview shows which teams and how many people change and every
    /// before → after value, then the change applies to all of them in one step (all or nothing), versioned and audited.
    /// Managed settings only shape the interface; they never grant or remove permissions (FR-25).
    /// </summary>
    public static partial class TeamEndpoints
    {
        public const string OrgKey = "org-settings";

        /// <summary>The settings an organisation or team may manage, with the values each accepts. Anything else is refused.</summary>
        public static readonly IReadOnlyDictionary<string, Func<JsonNode?, bool>> Catalogue = new Dictionary<string, Func<JsonNode?, bool>>
        {
            ["theme"] = v => v?.ToString() is "auto" or "charcoal-light" or "charcoal",
            ["motion"] = v => v?.ToString() is "on" or "off",
            ["textSize"] = v => v?.ToString() is "small" or "default" or "large" or "larger",
            ["experience"] = v => v?.ToString() is "auto" or "beginner" or "expert",
            ["calm"] = IsBool,
            ["nudge"] = IsBool,
            ["personas"] = IsBool,
            ["tourVoice"] = IsBool,
            ["firstSteps"] = IsBool,
            ["nextStep"] = IsBool,
            ["cultureSwitch"] = IsBool,
            ["inlineZones"] = IsBool,
            ["spellcheck"] = IsBool,
            ["usageStudy"] = IsBool,
            ["guide"] = v => v?.ToString() is "asha" or "ravi" or "meera" or "truxie" or "tech" or "engineer" or "analyst" or "truck",
            ["uiLanguage"] = v => v?.ToString() is "auto" or "en" || UiLanguages.Has(v?.ToString()),   // any installed language pack (wwwroot/i18n/languages.json)
            ["pageSize"] = v => v is JsonValue n && n.TryGetValue(out int i) && i is 10 or 25 or 50 or 100,
            ["clocksShown"] = v => v is JsonValue n && n.TryGetValue(out int i) && i is >= 1 and <= 4,
            ["worldClocks"] = v => v is JsonArray a && a.Count <= 12 && a.All(z => TimeZoneInfo.TryFindSystemTimeZoneById(z?.ToString() ?? "", out _)),
            ["scenario"] = v => v is JsonValue n && n.TryGetValue(out int i) && i is >= 0 and <= 5,
        };

        private static bool IsBool(JsonNode? v) => v is JsonValue b && b.TryGetValue(out bool _);

        [GeneratedRegex("^[a-z0-9][a-z0-9-]{1,39}$")] private static partial Regex TeamId();
        private static string Name(HttpContext ctx) => ctx.User.Identity?.Name ?? ActorFactory.From(ctx.User).Id;

        /// <summary>Teams are stored as one versioned setting document (FR-79): every change is a version that can be restored.</summary>
        private static async Task<(JsonArray Teams, int Version)> TeamsAsync(IWorkspaceStore store, CancellationToken ct)
        {
            var v = await store.SettingAsync("teams", ct);
            return ((JsonArray?)v?.Value["teams"]?.DeepClone() ?? [], v?.Version ?? 0);
        }

        private static JsonObject CheckSettings(JsonObject? settings)
        {
            var clean = new JsonObject();
            foreach (var (key, raw) in settings ?? [])
            {
                if (!Catalogue.TryGetValue(key, out var valid))
                {
                    throw new RequestFault(400, "setting_unknown", $"'{key}' cannot be managed. Allowed: {string.Join(", ", Catalogue.Keys)}.");
                }

                var value = raw is JsonObject o && o.ContainsKey("value") ? o["value"] : raw;
                if (!valid(value))
                {
                    throw new RequestFault(400, "setting_value", $"'{value?.ToJsonString()}' is not a valid value for {key}.");
                }

                clean[key] = new JsonObject { ["value"] = value?.DeepClone(), ["locked"] = raw is JsonObject x && x["locked"] is JsonValue l && l.TryGetValue(out bool b) && b };
            }
            return clean;
        }

        public static RouteGroupBuilder MapTeams(this RouteGroupBuilder api)
        {
            // ---------------------------------------------------------------- what applies to me
            api.MapGet("/settings/effective", async (HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                var me = ActorFactory.From(ctx.User).Id;
                var (teams, _) = await TeamsAsync(store, ct);
                var mine = teams.OfType<JsonObject>().Where(t => t.A("members").Any(m => m?.ToString() == me)).ToArray();
                var org = (await store.SettingAsync(OrgKey, ct))?.Value ?? [];
                var merged = new JsonObject();
                // Lowest first: organisation, then teams in reverse order, so the first team wins; a locked value is never overridden by an unlocked one.
                void Layer(JsonObject? settings, string source)
                {
                    foreach (var (k, v) in settings ?? [])
                    {
                        if (v is not JsonObject s)
                        {
                            continue;
                        }

                        if (merged[k] is JsonObject existing && existing["locked"]?.GetValue<bool>() == true && s["locked"]?.GetValue<bool>() != true)
                        {
                            continue;
                        }

                        merged[k] = new JsonObject { ["value"] = s["value"]?.DeepClone(), ["locked"] = s["locked"]?.GetValue<bool>() == true, ["source"] = source };
                    }
                }
                Layer(org, "Organisation");
                foreach (var t in mine.Reverse())
                {
                    Layer(t["settings"] as JsonObject, "Team " + t.S("name"));
                }

                return new { teams = mine.Select(t => new { id = t.S("id"), name = t.S("name") }), settings = merged };
            }).WithTags("Settings").WithSummary("The managed settings that apply to you, with where each comes from and whether it is locked.");

            // ---------------------------------------------------------------- administration
            var admin = api.MapGroup("/admin/teams").WithTags("Administration").RequireAuthorization("Admin").RequireFeature("teams");
            admin.MapGet("/", async (IWorkspaceStore store, CancellationToken ct) =>
            {
                var users = await store.UsersAsync(ct);
                var (teams, version) = await TeamsAsync(store, ct);
                var org = await store.SettingAsync(OrgKey, ct);
                return new { version, teams, organisation = new { settings = org?.Value ?? [], version = org?.Version ?? 0 }, catalogue = Catalogue.Keys, people = users.Where(u => u.Enabled).OrderBy(u => u.DisplayName, StringComparer.OrdinalIgnoreCase).Select(u => new { u.Id, name = u.DisplayName, u.Role }) };
            }).WithSummary("All teams, the organisation layer, the settings that can be managed and the people who can be members.");

            admin.MapPut("/{id}", async (string id, TeamBody body, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                if (!TeamId().IsMatch(id))
                {
                    throw new RequestFault(400, "team_id", "Team ids are 2–40 lower-case letters, digits or hyphens.");
                }

                if (string.IsNullOrWhiteSpace(body.Name))
                {
                    throw new RequestFault(400, "team_name", "A team needs a name.");
                }

                var (teams, version) = await TeamsAsync(store, ct);
                if (body.BaseVersion is { } b && b != version)
                {
                    throw new RequestFault(409, "teams_changed", "Teams were changed by someone else. Reload and try again.");
                }

                var existing = teams.OfType<JsonObject>().FirstOrDefault(t => t.S("id") == id);
                var team = new JsonObject { ["id"] = id, ["name"] = body.Name.Trim(), ["description"] = body.Description?.Trim() ?? "", ["members"] = new JsonArray((body.Members ?? []).Distinct().Select(m => (JsonNode)m).ToArray()), ["settings"] = CheckSettings(body.Settings ?? existing?["settings"]?.DeepClone() as JsonObject) };
                if (existing is not null)
                {
                    teams[teams.IndexOf(existing)] = team;
                }
                else
                {
                    teams.Add(team);
                }

                var saved = await store.SaveSettingAsync("teams", new JsonObject { ["teams"] = teams }, ActorFactory.From(ctx.User).Id, Name(ctx), (existing is null ? "Created " : "Changed ") + team.S("name"), ct);
                return Results.Ok(new { version = saved.Version, team });
            }).Audited("teams.save").WithSummary("Create or change a team: name, description, members and settings. Send baseVersion to avoid overwriting someone else's change.");

            admin.MapDelete("/{id}", async (string id, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                var (teams, _) = await TeamsAsync(store, ct);
                var existing = teams.OfType<JsonObject>().FirstOrDefault(t => t.S("id") == id) ?? throw new RequestFault(404, "team_missing", "No such team.");
                teams.Remove(existing);
                var saved = await store.SaveSettingAsync("teams", new JsonObject { ["teams"] = teams }, ActorFactory.From(ctx.User).Id, Name(ctx), "Removed " + existing.S("name"), ct);
                return Results.Ok(new { version = saved.Version });
            }).Audited("teams.remove").WithSummary("Remove a team. Its members keep their own settings; earlier versions can be restored.");

            // Several teams (and/or the organisation) at once: preview first, then apply all in one versioned step.
            admin.MapPost("/bulk-settings", async (BulkSettings body, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                var targets = (body.TeamIds ?? []).Distinct().ToArray();
                if (targets.Length == 0 && body.Organisation != true)
                {
                    throw new RequestFault(400, "no_targets", "Choose at least one team, or the organisation.");
                }

                var set = CheckSettings(body.Set);
                var unset = (body.Unset ?? []).Where(Catalogue.ContainsKey).ToArray();
                if (set.Count == 0 && unset.Length == 0)
                {
                    throw new RequestFault(400, "no_changes", "Choose at least one setting to set or clear.");
                }

                var (teams, version) = await TeamsAsync(store, ct);
                if (body.BaseVersion is { } b && b != version)
                {
                    throw new RequestFault(409, "teams_changed", "Teams were changed by someone else. Reload and preview again.");
                }

                var missing = targets.Where(id => teams.OfType<JsonObject>().All(t => t.S("id") != id)).ToArray();
                if (missing.Length > 0)
                {
                    throw new RequestFault(404, "team_missing", "No such team: " + string.Join(", ", missing));
                }

                var changes = new List<object>();
                JsonObject Apply(JsonObject settings, string label, int people)
                {
                    var next = (JsonObject)settings.DeepClone();
                    var diff = new List<object>();
                    foreach (var (k, v) in set)
                    {
                        var before = next[k]?.DeepClone();
                        if (before?.ToJsonString() != v?.ToJsonString())
                        {
                            diff.Add(new { setting = k, before, after = v!.DeepClone() });
                        }
                        next[k] = v!.DeepClone();
                    }
                    foreach (var k in unset)
                    {
                        if (next.ContainsKey(k))
                        {
                            diff.Add(new { setting = k, before = next[k]!.DeepClone(), after = (JsonNode?)null });
                            next.Remove(k);
                        }
                    }

                    changes.Add(new { target = label, people, changes = diff });
                    return next;
                }
                foreach (var t in teams.OfType<JsonObject>().Where(t => targets.Contains(t.S("id"))))
                {
                    t["settings"] = Apply(t["settings"] as JsonObject ?? [], t.S("name"), t.A("members").Count);
                }

                var org = await store.SettingAsync(OrgKey, ct);
                JsonObject? orgNext = body.Organisation == true ? Apply(org?.Value ?? [], "Organisation", -1) : null;
                var people = teams.OfType<JsonObject>().Where(t => targets.Contains(t.S("id"))).SelectMany(t => t.A("members").Select(m => m?.ToString())).Distinct().Count();
                if (body.Preview != false)
                {
                    return Results.Ok(new { preview = true, version, teams = targets.Length, people, organisation = body.Organisation == true, changes });
                }

                var actor = ActorFactory.From(ctx.User);
                var note = $"Bulk change of {set.Count + unset.Length} setting(s) for {targets.Length} team(s){(body.Organisation == true ? " and the organisation" : "")}";
                var saved = targets.Length > 0 ? await store.SaveSettingAsync("teams", new JsonObject { ["teams"] = teams }, actor.Id, Name(ctx), note, ct) : null;
                if (orgNext is not null)
                {
                    await store.SaveSettingAsync(OrgKey, orgNext, actor.Id, Name(ctx), note, ct);
                }

                return Results.Ok(new { preview = false, version = saved?.Version ?? version, teams = targets.Length, people, organisation = body.Organisation == true, changes });
            }).Audited("teams.bulk-settings").WithSummary("Change settings for several teams (and the organisation) at once. preview=true (the default) shows every before → after and how many people change; preview=false applies all of it in one step.");

            admin.MapGet("/history", async (IWorkspaceStore store, CancellationToken ct) => (await store.SettingHistoryAsync("teams", ct)).Select(v => new { v.Version, v.ActorName, v.At, v.Note }))
                .WithSummary("Every version of the teams, newest first.");
            admin.MapPost("/restore/{version:int}", async (int version, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                var old = (await store.SettingHistoryAsync("teams", ct)).FirstOrDefault(v => v.Version == version) ?? throw new RequestFault(404, "version_missing", "That version does not exist.");
                var saved = await store.SaveSettingAsync("teams", old.Value, ActorFactory.From(ctx.User).Id, Name(ctx), $"Restored version {version}", ct);
                return Results.Ok(new { version = saved.Version });
            }).Audited("teams.restore").WithSummary("Restore an earlier version of the teams (adds a new version).");
            return api;
        }
    }
}
