using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Options;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Web
{
    /// <summary>Checks the user name or email and password against Authentication:Accounts. Read on every attempt, so edits apply at once.</summary>
    public sealed class ConfiguredCredentials : ICredentialValidator
    {
        private readonly IOptionsMonitor<SignInSettings> _settings;

        public ConfiguredCredentials(IOptionsMonitor<SignInSettings> settings)
        {
            _settings = settings;
        }

        public Task<UserAccount?> ValidateAsync(string login, string password, CancellationToken ct)
        {
            var name = login.Trim();
            var account = _settings.CurrentValue.Accounts.FirstOrDefault(a => a.CanSignIn &&
                (string.Equals(a.UserName, name, StringComparison.OrdinalIgnoreCase) || (!string.IsNullOrEmpty(a.Email) && string.Equals(a.Email, name, StringComparison.OrdinalIgnoreCase))));
            // Compare hashes in constant time whether or not the account exists, so the answer time does not reveal which user names exist.
            var expected = SHA256.HashData(Encoding.UTF8.GetBytes(account?.Password ?? "\u0000no account\u0000"));
            var given = SHA256.HashData(Encoding.UTF8.GetBytes(password));
            var ok = CryptographicOperations.FixedTimeEquals(expected, given) && account is not null;
            return Task.FromResult(ok ? new UserAccount(string.IsNullOrWhiteSpace(account!.Id) ? account.UserName.ToLowerInvariant() : account.Id,
                string.IsNullOrWhiteSpace(account.DisplayName) ? account.UserName : account.DisplayName, account.Role, account.Contexts, true,
                string.IsNullOrWhiteSpace(account.Country) ? null : account.Country.ToUpperInvariant(), account.Email) : null);
        }
    }
}
