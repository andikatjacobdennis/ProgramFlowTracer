using System.Runtime;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace Volvo.TestRequestTool.Web
{
    public sealed class MemoryHealthCheck : IHealthCheck
    {
        public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken ct = default)
        {
            var info = GC.GetGCMemoryInfo();
            var limit = info.TotalAvailableMemoryBytes;
            var used = GC.GetTotalMemory(false);
            var share = limit > 0 ? (double)info.MemoryLoadBytes / limit : 0;
            var data = new Dictionary<string, object> { ["managedMb"] = used / 1048576, ["memoryLoadPercent"] = Math.Round(share * 100, 1), ["availableMb"] = limit / 1048576, ["gen2"] = GC.CollectionCount(2), ["serverGc"] = GCSettings.IsServerGC };
            return Task.FromResult(share > 0.9 ? HealthCheckResult.Degraded("Memory pressure is high.", data: data) : HealthCheckResult.Healthy("Memory is fine.", data));
        }
    }
}
