using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Web
{
    public sealed record BulkSettings([property: System.ComponentModel.DataAnnotations.MaxLength(200)] string[]? TeamIds, bool? Organisation, JsonObject? Set,
        [property: System.ComponentModel.DataAnnotations.MaxLength(50)] string[]? Unset, bool? Preview, int? BaseVersion);
}
