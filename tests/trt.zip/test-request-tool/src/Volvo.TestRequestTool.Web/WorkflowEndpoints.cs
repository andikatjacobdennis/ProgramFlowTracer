using System.Runtime.CompilerServices;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Web
{
    public static partial class WorkflowEndpoints
    {
        [GeneratedRegex("^[A-Za-z0-9_.:-]{1,100}$")] private static partial Regex KeyPattern();
        [GeneratedRegex("^[A-Za-z0-9_-]{1,80}$")] private static partial Regex IdPattern();

        public static IServiceCollection AddWorkflow(this IServiceCollection services, IConfiguration config)
        {
            // FR-69: limits are checked when the host starts, not on first use.
            services.AddOptions<JobOptions>().Bind(config.GetSection("Jobs")).ValidateDataAnnotations()
                .Validate(o => o.Lease >= TimeSpan.FromSeconds(5) && o.MaxDuration > o.Lease, "Jobs:Lease must be at least 5 seconds and shorter than Jobs:MaxDuration.").ValidateOnStart();
            services.AddSingleton<AdapterHealth>();
            services.AddSingleton<ProvenanceService>();
            services.AddSingleton<JobSignal>();
            services.AddHostedService<JobWorker>();
            // Graceful shutdown (FR-47): give running jobs time to hand themselves back to the queue.
            services.Configure<HostOptions>(h => h.ShutdownTimeout = TimeSpan.FromSeconds(20));
            return services;
        }

        private static string Name(HttpContext ctx) => ctx.User.Identity?.Name ?? ActorFactory.From(ctx.User).Id;

        /// <summary>Records a sensitive action in the protected audit log when the endpoint succeeds (FR-19).</summary>
        public static TBuilder Audited<TBuilder>(this TBuilder builder, string action) where TBuilder : IEndpointConventionBuilder =>
            builder.AddEndpointFilter(async (ctx, next) =>
            {
                var result = await next(ctx);
                var http = ctx.HttpContext;
                var status = result is IStatusCodeHttpResult s ? s.StatusCode ?? 200 : 200;
                if (status < 400)
                {
                    var target = string.Join("/", http.Request.RouteValues.Select(r => r.Value?.ToString()));
                    var store = http.RequestServices.GetRequiredService<IWorkspaceStore>();
                    await store.AppendAuditAsync(ActorFactory.From(http.User).Id, Name(http), action, target.Length == 0 ? http.Request.Path.Value ?? "" : target,
                        new JsonObject { ["method"] = http.Request.Method, ["path"] = http.Request.Path.Value, ["traceId"] = http.TraceIdentifier }, http.RequestAborted);
                }
                return result;
            });

        public static RouteGroupBuilder MapWorkflow(this RouteGroupBuilder api)
        {
            // ---------------------------------------------------------------- jobs
            var jobs = api.MapGroup("/jobs").WithTags("Jobs");
            jobs.MapPost("/requests", async (RequestCommand command, HttpContext ctx, IWorkspaceStore store, JobSignal signal, Microsoft.Extensions.Options.IOptions<JobOptions> options, TimeProvider clock, CancellationToken ct) =>
            {
                var o = options.Value;
                var actor = ActorFactory.From(ctx.User);
                var key = ctx.Request.Headers["Idempotency-Key"].ToString();
                if (key.Length == 0)
                {
                    key = Guid.NewGuid().ToString("N");
                }
                else if (!KeyPattern().IsMatch(key))
                {
                    throw new RequestFault(400, "idempotency_key", "Idempotency-Key must be 1–100 letters, digits or . _ : -");
                }

                var hash = CanonicalJson.Hash(new JsonObject { ["kind"] = command.Kind.ToString(), ["payload"] = command.Payload.DeepClone() });
                // FR-37: the key is scoped to the user. The same key and input returns the original job; another input is a conflict.
                if (await store.JobByKeyAsync(actor.Id, key, ct) is { } existing)
                {
                    return existing.InputHash == hash ? Results.Ok(existing) : throw new RequestFault(409, "idempotency_key_reused", "This Idempotency-Key was already used for a different request. Use a new key.");
                }

                var vehicles = command.Payload.A("products").Count;
                if (vehicles > o.MaxVehiclesPerJob)
                {
                    throw new RequestFault(413, "batch_too_large", $"A job can include up to {o.MaxVehiclesPerJob} vehicles. Split the selection.");
                }
                // FR-35 / FR-36: bounded queues, explicit rejection with retry guidance.
                var load = await store.JobLoadAsync(actor.Id, ct);
                var metrics = ctx.RequestServices.GetRequiredService<TestRequestMetrics>();
                if (load.QueuedForActor >= o.MaxQueuedPerUser)
                {
                    metrics.Rejected("per_user");
                    ctx.Response.Headers.RetryAfter = "30";
                    throw new RequestFault(429, "too_many_jobs", $"You already have {load.QueuedForActor} jobs waiting. Wait for some to finish, then try again.");
                }
                if (load.Queued >= o.MaxQueued)
                {
                    metrics.Rejected("queue_full");
                    ctx.Response.Headers.RetryAfter = "60";
                    throw new RequestFault(503, "queue_full", "The service is at its job limit. Your request was not accepted; try again in a minute.");
                }
                var job = new JobRecord(Guid.NewGuid(), JobActor.From(actor), command.Kind.ToString(), key, hash, (JsonObject)command.Payload.DeepClone(), "queued", 1, clock.GetUtcNow(),
                    Lane: vehicles > o.BatchThreshold ? "batch" : "interactive");
                job = await store.SaveJobAsync(job, ct);   // FR-34: stored before it is acknowledged
                metrics.Submitted(job.Lane);
                signal.Notify();
                return Results.Accepted($"/api/v1/jobs/{job.Id}", job);
            }).RequireAuthorization("Operator").RequireRateLimiting("simulation").Pausable("submissions")
              .WithSummary("Start a request as a tracked job. Send an Idempotency-Key header: repeating it returns the same job instead of running again.");
            jobs.MapGet("/", async (HttpContext ctx, IWorkspaceStore store, int? take, CancellationToken ct) => (await store.JobsAsync(ActorFactory.From(ctx.User).Id, take ?? 20, ct)).Select(Slim))
                .WithSummary("Your recent jobs, newest first (without their input).");
            jobs.MapGet("/{id:guid}", async (Guid id, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) => Results.Ok(await Own(store, id, ctx, ct)))
                .WithSummary("One job: status, attempts, result id and provenance. Poll this to follow a running job, also after reloading the page.");
            // .NET 10: Server-Sent Events as a first-class result. The page follows a job live over one connection instead of
            // polling, and EventSource reconnects by itself. The stream ends when the job finishes or after ten minutes.
            jobs.MapGet("/{id:guid}/events", async (Guid id, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
                TypedResults.ServerSentEvents(Follow(store, await Own(store, id, ctx, ct), ct), eventType: "job"))
                .WithSummary("Follow one job as a Server-Sent Events stream (event \"job\"): one message per change until it finishes.");
            jobs.MapPost("/{id:guid}/retry", async (Guid id, HttpContext ctx, IWorkspaceStore store, JobSignal signal, CancellationToken ct) =>
            {
                var job = await Own(store, id, ctx, ct);
                if (job.Status is not ("failed" or "cancelled"))
                {
                    throw new RequestFault(409, "job_not_retryable", $"Only failed or cancelled jobs can be retried. This one is {job.Status}.");
                }

                job = await store.TransitionJobAsync(id, job.Version, "queued", j => j with { Attempt = j.Attempt + 1, ErrorCode = null, Error = null, FinishedAt = null }, ct);
                signal.Notify();
                return Results.Accepted($"/api/v1/jobs/{job.Id}", job);
            }).RequireAuthorization("Operator").Audited("job.retry").WithSummary("Retry a failed or cancelled job with its original input, as a new attempt.");
            jobs.MapPost("/{id:guid}/cancel", async (Guid id, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                var job = await Own(store, id, ctx, ct);
                if (job.Finished || job.Status == "cancelling")
                {
                    return Results.Ok(job);
                }

                job = job.Status == "queued"
                    ? await store.TransitionJobAsync(id, job.Version, "cancelled", j => j with { ErrorCode = "job_cancelled", Error = "Cancelled before it started. Your input is kept.", FinishedAt = DateTimeOffset.UtcNow }, ct)
                    : await store.TransitionJobAsync(id, job.Version, "cancelling", j => j, ct);
                return Results.Ok(job);
            }).RequireAuthorization("Operator").WithSummary("Cancel a queued or running job. Its input is kept so it can be retried.");

            // ---------------------------------------------------------------- proposals (FR-05)
            var proposals = api.MapGroup("/proposals").WithTags("Proposals");
            proposals.MapGet("/{id}/revisions", async (string id, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
                await store.ProposalRevisionsAsync(ActorFactory.From(ctx.User).Id, CheckId(id), ct)).WithSummary("Revisions of a proposal, newest first.");
            proposals.MapGet("/{id}/revisions/{number:int}", async (string id, int number, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
                await store.ProposalRevisionAsync(ActorFactory.From(ctx.User).Id, CheckId(id), number, ct) ?? throw new RequestFault(404, "revision_missing", "That revision does not exist."))
                .WithSummary("One revision with its full state.");
            proposals.MapPost("/{id}/revisions", async (string id, SaveRevision body, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                if (body.State is null)
                {
                    throw new RequestFault(400, "state_required", "A proposal state is required.");
                }

                var actor = ActorFactory.From(ctx.User);
                var rev = await store.AddProposalRevisionAsync(new ProposalRevision(CheckId(id), actor.Id, 0, default, actor.Id, Name(ctx), body.Reason ?? "Autosave",
                    ProposalRevision.HashOf(body.State), null, body.Summary ?? [], body.State), body.BaseRevision, ct);
                return Results.Created($"/api/v1/proposals/{id}/revisions/{rev.Number}", rev);
            }).RequireAuthorization("Editor").WithSummary("Save a revision. Send baseRevision (the revision you edited): if someone saved after it, the answer is 409 and nothing is overwritten.");
            proposals.MapPost("/{id}/revisions/{number:int}/restore", async (string id, int number, RestoreRevision body, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                var actor = ActorFactory.From(ctx.User);
                var old = await store.ProposalRevisionAsync(actor.Id, CheckId(id), number, ct) ?? throw new RequestFault(404, "revision_missing", "That revision does not exist.");
                var rev = await store.AddProposalRevisionAsync(old with { ActorId = actor.Id, ActorName = Name(ctx), Reason = $"Restored revision {number}", RestoredFrom = number }, body.BaseRevision, ct);
                return Results.Created($"/api/v1/proposals/{id}/revisions/{rev.Number}", rev);
            }).RequireAuthorization("Editor").Audited("proposal.restore").WithSummary("Restore an earlier revision. This adds a new revision; nothing is deleted.");

            // ---------------------------------------------------------------- audit (FR-19)
            var audit = api.MapGroup("/admin/audit").WithTags("Administration").RequireAuthorization("Admin");
            audit.MapGet("/", async (HttpContext ctx, IWorkspaceStore store, int? skip, int? take, CancellationToken ct) =>
            {
                await store.AppendAuditAsync(ActorFactory.From(ctx.User).Id, Name(ctx), "audit.read", "audit", null, ct);
                return await store.AuditAsync(skip ?? 0, take ?? 100, ct);
            }).WithSummary("The audit log, newest first. Reading it is itself recorded.");
            audit.MapGet("/verify", async (IWorkspaceStore store, IConfiguration config, CancellationToken ct) =>
            {
                var (count, broken) = await store.VerifyAuditAsync(ct);
                return new { entries = count, intact = broken is null, brokenAt = broken, retentionDays = config.GetValue("Audit:RetentionDays", 2555) };
            }).WithSummary("Recompute the hash chain. intact is false, with the first broken entry, if any record was changed or removed.");
            audit.MapGet("/export", async (HttpContext ctx, IWorkspaceStore store, string? format, CancellationToken ct) =>
            {
                await store.AppendAuditAsync(ActorFactory.From(ctx.User).Id, Name(ctx), "audit.export", format ?? "json", null, ct);
                var rows = JsonSerializer.SerializeToNode(await store.AuditAsync(0, 500, ct), ProvenanceService.Json)!.AsArray();
                return (format ?? "json").Equals("csv", StringComparison.OrdinalIgnoreCase)
                    ? Results.File(Encoding.UTF8.GetBytes(DataConverter.ToCsv(rows)), "text/csv", "audit.csv")
                    : Results.File(Encoding.UTF8.GetBytes(rows.ToJsonString(new JsonSerializerOptions { WriteIndented = true })), "application/json", "audit.json");
            }).WithSummary("Export the newest 500 audit entries as JSON or CSV. The export is itself recorded.");

            // ---------------------------------------------------------------- integrations (FR-21, FR-22)
            var integrations = api.MapGroup("/integrations").WithTags("Integrations");
            integrations.MapGet("/health", (IEnumerable<IExternalCapability> adapters, AdapterHealth health) => health.All(adapters))
                .WithSummary("Each integration: configured, health, reachable, authenticated, calls in progress, last success and last failure.");
            integrations.MapPost("/{name}/check", async (string name, IEnumerable<IExternalCapability> adapters, AdapterHealth health, CancellationToken ct) =>
                await health.CheckAsync(Adapter(adapters, name), ct)).RequireAuthorization("Operator")
                .WithSummary("A safe, read-only health check of one integration. Nothing is changed in the external system.");
            return api;
        }

        public static IExternalCapability Adapter(IEnumerable<IExternalCapability> adapters, string name) =>
            adapters.SingleOrDefault(a => a.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) ?? throw new RequestFault(404, "capability_missing", "No adapter with that name is registered.");

        private static string CheckId(string id) => IdPattern().IsMatch(id) ? id : throw new RequestFault(400, "proposal_id", "Proposal id must contain 1–80 letters, digits, underscores or hyphens.");

        /// <summary>FR-52: another user's job answers 404, exactly like a job that does not exist.</summary>
        private static async Task<JobRecord> Own(IWorkspaceStore store, Guid id, HttpContext ctx, CancellationToken ct)
        {
            var job = await store.JobAsync(id, ct);
            return job is not null && job.Actor.Id == ActorFactory.From(ctx.User).Id ? job : throw new RequestFault(404, "job_missing", "Job was not found.");
        }

        private static async IAsyncEnumerable<object> Follow(IWorkspaceStore store, JobRecord job, [EnumeratorCancellation] CancellationToken ct)
        {
            var until = DateTimeOffset.UtcNow.AddMinutes(10);
            string? last = null;
            while (!ct.IsCancellationRequested && DateTimeOffset.UtcNow < until)
            {
                var state = $"{job.Status}|{job.Attempt}|{job.Attempts?.Count}";   // lease renewals alone are not news
                if (state != last)
                {
                    last = state;
                    yield return Slim(job);
                }
                if (job.Finished)
                {
                    yield break;
                }

                await Task.Delay(400, ct).ConfigureAwait(ConfigureAwaitOptions.SuppressThrowing);
                if (await store.JobAsync(job.Id, CancellationToken.None) is not { } next)
                {
                    yield break;
                }

                job = next;
            }
        }

        private static object Slim(JobRecord j) => new { j.Id, j.Kind, j.Status, j.Lane, j.Attempt, j.CreatedAt, j.StartedAt, j.FinishedAt, j.ResultId, j.ErrorCode, j.Error, j.Provenance, j.Cancellation, vehicles = j.Input.A("products").Count };

        // ---------------------------------------------------------------- FR-76 · controlled pause
        [GeneratedRegex("^(submissions|writes|integration:[A-Za-z0-9_-]{1,40})$")] private static partial Regex ScopePattern();

        /// <summary>
        /// Refuses the call with 503 "paused" while an operator has paused this scope (or, for integrations, all writes). Work
        /// already accepted is not affected: queued and running jobs finish.
        /// </summary>
        public static TBuilder Pausable<TBuilder>(this TBuilder builder, string scope) where TBuilder : IEndpointConventionBuilder =>
            builder.AddEndpointFilter(async (ctx, next) =>
            {
                var http = ctx.HttpContext;
                var actual = scope == "integration" ? "integration:" + http.Request.RouteValues["name"] : scope;
                var pauses = await http.RequestServices.GetRequiredService<IWorkspaceStore>().PausesAsync(http.RequestAborted);
                var hit = pauses.FirstOrDefault(p => p.Scope == actual || (actual.StartsWith("integration:", StringComparison.Ordinal) && p.Scope == "writes"));
                if (hit is null)
                {
                    return await next(ctx);
                }

                http.Response.Headers.RetryAfter = "300";
                return Results.Problem(statusCode: 503, title: "paused", detail: $"{hit.ActorName} paused {hit.Scope} at {hit.At:yyyy-MM-dd HH:mm} UTC: {hit.Reason} Work already accepted continues.");
            });

        // ---------------------------------------------------------------- organisation default culture (versioned, FR-79)
        public const string CultureKey = "culture-default";

        public static RouteGroupBuilder MapOrganisationSettings(this RouteGroupBuilder api)
        {
            api.MapGet("/settings/culture-default", async (IWorkspaceStore store, CancellationToken ct) =>
                (await store.SettingAsync(CultureKey, ct)) is { } v ? Results.Ok(v) : Results.Ok(new { key = CultureKey, version = 0, value = (object?)null }))
                .WithTags("Settings").WithSummary("The organisation's default culture, used for people who have not chosen one and whose account has no country.");
            var admin = api.MapGroup("/admin/settings").WithTags("Administration").RequireAuthorization("Admin");
            admin.MapPut("/culture-default", async (CultureDefault body, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                if (body.Country is not { Length: 2 } || !body.Country.All(char.IsAsciiLetterUpper))
                {
                    throw new RequestFault(400, "country", "Country must be a two-letter code, for example IN or SE.");
                }

                try
                {
                    _ = System.Globalization.CultureInfo.GetCultureInfo(body.Language ?? "", predefinedOnly: true);
                }
                catch (System.Globalization.CultureNotFoundException)
                {
                    throw new RequestFault(400, "language", "Language must be a known language tag, for example en-IN or sv-SE.");
                }
                if (!TimeZoneInfo.TryFindSystemTimeZoneById(body.TimeZone ?? "", out _))
                {
                    throw new RequestFault(400, "time_zone", "Time zone must be an IANA name, for example Asia/Kolkata.");
                }

                var value = new JsonObject { ["country"] = body.Country, ["language"] = body.Language, ["timeZone"] = body.TimeZone, ["currency"] = body.Currency, ["dateFormat"] = body.DateFormat ?? "medium", ["hourCycle"] = body.HourCycle ?? "auto" };
                return await store.SaveSettingAsync(CultureKey, value, ActorFactory.From(ctx.User).Id, Name(ctx), body.Note, ct);
            }).Audited("settings.culture-default").WithSummary("Set the organisation default culture. Every change is a new version.");
            admin.MapGet("/culture-default/history", async (IWorkspaceStore store, CancellationToken ct) => await store.SettingHistoryAsync(CultureKey, ct))
                .WithSummary("Every version of the organisation default culture, newest first.");
            admin.MapPost("/culture-default/restore/{version:int}", async (int version, HttpContext ctx, IWorkspaceStore store, CancellationToken ct) =>
            {
                var old = (await store.SettingHistoryAsync(CultureKey, ct)).FirstOrDefault(v => v.Version == version) ?? throw new RequestFault(404, "version_missing", "That version does not exist.");
                return await store.SaveSettingAsync(CultureKey, old.Value, ActorFactory.From(ctx.User).Id, Name(ctx), $"Restored version {version}", ct);
            }).Audited("settings.culture-default.restore").WithSummary("Restore an earlier version (adds a new version).");
            return api;
        }

        public static RouteGroupBuilder MapOperations(this RouteGroupBuilder api)
        {
            var ops = api.MapGroup("/admin/operations").WithTags("Administration");
            ops.MapGet("/pauses", async (IWorkspaceStore store, CancellationToken ct) => await store.PausesAsync(ct)).RequireAuthorization("Operator")
                .WithSummary("Active pauses: submissions, writes or integration:NAME.");
            ops.MapPut("/pauses/{scope}", async (string scope, PauseBody body, HttpContext ctx, IWorkspaceStore store, TimeProvider clock, CancellationToken ct) =>
            {
                if (!ScopePattern().IsMatch(scope))
                {
                    throw new RequestFault(400, "pause_scope", "Scope must be submissions, writes or integration:NAME.");
                }

                if (string.IsNullOrWhiteSpace(body.Reason))
                {
                    throw new RequestFault(400, "pause_reason", "Say why: the reason is shown to everyone who is refused.");
                }

                var actor = ActorFactory.From(ctx.User);
                return await store.SetPauseAsync(new PauseRecord(scope, body.Reason.Trim(), actor.Id, Name(ctx), clock.GetUtcNow()), ct);
            }).RequireAuthorization("Admin").Audited("operations.pause").WithSummary("Pause new submissions, consequential writes or one integration. Accepted work continues.");
            ops.MapDelete("/pauses/{scope}", async (string scope, IWorkspaceStore store, CancellationToken ct) =>
                await store.ClearPauseAsync(scope, ct) ? Results.NoContent() : Results.Problem(statusCode: 404, title: "pause_missing"))
                .RequireAuthorization("Admin").Audited("operations.resume").WithSummary("Resume a paused scope.");
            return api;
        }
    }
}
