using System.Security.Cryptography;
using System.Text;
using Volvo.TestRequestTool.Application;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// Writes each finished request as structured events (one per timed stage) for the Logs page: the service it belongs to,
    /// the request, a span id per stage, durations and outcomes. Timestamps are reconstructed from the measured offsets.
    /// Nothing from the payload is written. The author of the request may see these events; administrators see all.
    /// </summary>
    public sealed class RequestEventLog : IRequestEvents
    {
        private readonly TestRequestLogStore _store;

        public RequestEventLog(TestRequestLogStore store)
        {
            _store = store;
        }

        public static string Service(TraceStage s) => s.Id switch
        {
            "authorise" => "Access",
            "proposal" => s.Kind == "service" ? "Integration" : "Validation",
            "rule:hardware" or "rule:dependencies" => "Compatibility",
            "rule:parameters" => "Parameters",
            "result" => "Validation",
            _ => "Validation",
        };

        public static string Span(Guid request, int order) => Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(request.ToString("N") + ":" + order)))[..16];

        public void Executed(ExecutionRecord record, string via)
        {
            string[] audience = [record.ActorId];
            var trace = System.Diagnostics.Activity.Current?.TraceId.ToString() ?? record.Id.ToString("N");
            var total = record.Trace?.TotalMs ?? 0;
            var start = record.CreatedAt.AddMilliseconds(-total);
            _store.Event(via == "worker" ? "Worker" : "API", LogLevel.Information, "Request accepted · " + record.Kind, record.Id, audience, start, trace, Span(record.Id, 0),
                fields: new Dictionary<string, string> { ["kind"] = record.Kind.ToString(), ["vehicles"] = record.Outcomes.Count.ToString(System.Globalization.CultureInfo.InvariantCulture), ["via"] = via });
            foreach (var s in record.Trace?.Stages ?? [])
            {
                _store.Event(Service(s), s.Outcome == "completed" ? LogLevel.Information : LogLevel.Warning, s.Name + (s.Note is null ? "" : " · " + s.Note), record.Id, audience,
                    start.AddMilliseconds(s.StartMs + s.DurationMs), trace, Span(record.Id, s.Order), fields: new Dictionary<string, string>
                    {
                        ["stage"] = s.Id,
                        ["outcome"] = s.Outcome,
                        ["durationMs"] = s.DurationMs.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture),
                        ["vehicle"] = s.VehicleId ?? "",
                    });
            }

            var blockers = record.Outcomes.Sum(o => o.Issues.Count(i => i.Severity == 0));
            _store.Event("Workspace", blockers > 0 ? LogLevel.Warning : LogLevel.Information, blockers > 0 ? $"Result and evidence saved · {blockers} blocking finding(s)" : "Result and evidence saved",
                record.Id, audience, record.CreatedAt, trace, Span(record.Id, 999), fields: new Dictionary<string, string> { ["blocking"] = blockers.ToString(System.Globalization.CultureInfo.InvariantCulture) });
        }
    }
}
