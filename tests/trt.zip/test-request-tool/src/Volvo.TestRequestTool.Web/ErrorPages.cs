namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// The illustrated error page (wwwroot/error.html with js/error-art.js) for browser page requests that fail: 404 for an
    /// unknown address, 401/403/429/500 and so on. API calls keep their problem+json responses; requests that do not accept HTML
    /// (scripts, images) get the status alone.
    /// </summary>
    public static class ErrorPages
    {
        private static string? template;

        public static async Task WriteAsync(HttpContext ctx)
        {
            var response = ctx.Response;
            if (response.HasStarted || !ctx.Request.Headers.Accept.ToString().Contains("text/html", StringComparison.OrdinalIgnoreCase))
            {
                return;
            }

            if (template is null)
            {
                var file = ctx.RequestServices.GetRequiredService<IWebHostEnvironment>().WebRootFileProvider.GetFileInfo("error.html");
                if (!file.Exists)
                {
                    return;
                }

                using var reader = new StreamReader(file.CreateReadStream());
                template = await reader.ReadToEndAsync(ctx.RequestAborted);
            }
            response.ContentType = "text/html; charset=utf-8";
            response.Headers.CacheControl = "no-store";
            await response.WriteAsync(template.Replace("data-code=\"404\"", $"data-code=\"{response.StatusCode}\""), ctx.RequestAborted);
        }
    }
}
