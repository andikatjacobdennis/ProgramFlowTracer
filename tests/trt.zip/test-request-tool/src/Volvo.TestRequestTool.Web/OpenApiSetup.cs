using Microsoft.AspNetCore.Http.Metadata;
namespace Volvo.TestRequestTool.Web
{
    /// <summary>
    /// The OpenAPI description (ASP.NET Core 10's built-in generator, Microsoft.AspNetCore.OpenApi) and Swagger UI for trying the
    /// API directly. Swagger UI calls the API as the signed-in user, with the same cookie, roles and limits as the interface, so it
    /// can do nothing the user could not do in the application. Outside Development and Testing the document requires sign-in.
    /// </summary>
    public static class OpenApiSetup
    {
        private static readonly Dictionary<string, string> Areas = new(StringComparer.OrdinalIgnoreCase)
        {
            ["session"] = "Session",
            ["capabilities"] = "Session",
            ["auth"] = "Session",
            ["vehicles"] = "Vehicles",
            ["catalog"] = "Catalog",
            ["sources"] = "Sources",
            ["requests"] = "Requests",
            ["drafts"] = "Requests",
            ["kits"] = "Requests",
            ["vda"] = "Requests",
            ["xml"] = "Convert",
            ["integrations"] = "Integrations",
            ["admin"] = "Administration",
            ["fleet"] = "Insights",
            ["about"] = "Insights",
            ["feedback"] = "Feedback",
        };

        public static IServiceCollection AddTestRequestOpenApi(this IServiceCollection services) => services.AddOpenApi("v1", o => o.AddDocumentTransformer((doc, _, _) =>
        {
            doc.Info.Title = "Test Request Tool API";
            doc.Info.Version = "v1";
            doc.Info.Description = "Every action in the application, as an API: vehicles, the catalog, test requests, insights, feedback, conversions and diagnostics. " +
                "Calls run as the signed-in user, with the same permissions and limits as the interface.";
            return Task.CompletedTask;
        }));

        /// <summary>Endpoints without their own tag are grouped by the first part of their path (vehicles, requests …).</summary>
        public static RouteGroupBuilder TagByArea(this RouteGroupBuilder api)
        {
            ((IEndpointConventionBuilder)api).Finally(b =>
            {
                if (b.Metadata.OfType<ITagsMetadata>().Any() || b is not RouteEndpointBuilder r)
                {
                    return;
                }

                var parts = (r.RoutePattern.RawText ?? "").Split('/', StringSplitOptions.RemoveEmptyEntries).SkipWhile(p => p is "api" or "v1").ToArray();
                var first = parts.FirstOrDefault() ?? "";
                b.Metadata.Add(new TagsAttribute(Areas.GetValueOrDefault(first, first.Length == 0 ? "General" : char.ToUpperInvariant(first[0]) + first[1..])));
            });
            return api;
        }

        public static WebApplication MapTestRequestOpenApi(this WebApplication app, bool localEnvironment)
        {
            var doc = app.MapOpenApi().CacheOutput("openapi");   // built once, then served from memory
            if (!localEnvironment)
            {
                doc.RequireAuthorization();
            }

            return app;
        }

        public static WebApplication UseTestRequestSwaggerUI(this WebApplication app)
        {
            app.UseSwaggerUI(o =>
            {
                o.SwaggerEndpoint("/openapi/v1.json", "Test Request Tool API v1");
                o.RoutePrefix = "swagger";
                o.DocumentTitle = "Test Request Tool · API";
                o.EnableTryItOutByDefault();
                o.DisplayRequestDuration();
                o.EnableFilter();
                o.EnableDeepLinking();
                o.DefaultModelsExpandDepth(0);
            });
            return app;
        }
    }
}
