namespace Volvo.TestRequestTool.Web
{
    /// <summary>The outcome of looking up a profile photo. Status: ok, none (no photo), forbidden (no permission), unavailable (network or service).</summary>
    public sealed record PhotoResult(string Status, byte[]? Bytes = null, string? ContentType = null)
    {
        public static readonly PhotoResult None = new("none"), Forbidden = new("forbidden"), Unavailable = new("unavailable");
    }
}
