namespace Volvo.TestRequestTool.Web
{
    public sealed record RestoreRevision(int? BaseRevision);
}
