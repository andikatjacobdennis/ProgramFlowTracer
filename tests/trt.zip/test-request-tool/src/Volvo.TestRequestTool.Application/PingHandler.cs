namespace Volvo.TestRequestTool.Application
{
    /// <summary>Ping 1.0 (Request.Listener/Audit/Ping_1_0): any body, and the reply is the text OK.</summary>
    public sealed class PingHandler : IListenerHandler
    {
        public IReadOnlyCollection<string> Keys { get; } = ["Ping_1.0"];

        public ValueTask<ListenerReply> HandleAsync(ListenerMessage message, CancellationToken ct) =>
            ValueTask.FromResult(new ListenerReply("OK", ListenerReply.Text, [], [new ListenerFact("Answer", "OK: the listener answers.")]));

        public ListenerReply Reject(ListenerMessage message, ListenerNotice notice) => new(string.Empty, ListenerReply.Text, [notice], []);
    }
}
