using System.Runtime.CompilerServices;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The simulated provider for chat, summaries and agent planning: deterministic and rule-based, not AI, and it contacts no
    /// external service. It answers a fixed set of questions about the workflow, defines technical terms, describes the
    /// selected configuration from authorised records, summarises records with templates, and previews plans without executing
    /// anything. When a question is outside what it can answer, it says so instead of inventing an answer.
    /// </summary>
    public sealed partial class SimulatedAssistant : IChatProvider, ISummaryProvider, IAgentPlanner
    {
        public const string Label = "Simulated assistant — no AI service connected";

        public AssistantInfo Info { get; } = new("Simulated", true, Label,
            "Scripted answers, template summaries and plan previews built from this application's records. No AI is used and no external service is contacted.",
            ["Explain the workflow", "Define technical terms", "Describe the selected vehicle, proposal or request", "Summarise proposals, validations, activity and vehicles", "Preview plans for a goal (nothing is executed)"],
            ["Only records you may read are used as context, and you choose which", "Answers cite their sources and state their confidence", "Nothing is changed, submitted or approved by the assistant", "Messages and responses are treated as untrusted text and shown as plain text", "Message content is not logged; only operational metadata is recorded"],
            "Conversations stay in this browser tab only and are cleared on sign-out or when you switch account. The server keeps no conversation.");

        // ------------------------------------------------------------------ knowledge: workflow and glossary
        private sealed record Faq(string[] Words, string Answer, string Title, string Article, SuggestedAction? Action);
        private static SuggestedAction Go(string label, string target) => new("navigate", label, new JsonObject { ["target"] = target });

        private static readonly Faq[] Workflow =
        [
            new(["workflow", "steps", "start", "how", "begin", "journey"], "The test request has five steps: Choose vehicle, Prepare changes, Validate, Review and Submit. The stepper at the top shows where you are; a step that is not available yet says why and what to do.", "The test request journey", "start", Go("Open the test request", "testrequest")),
            new(["add", "load", "vehicle", "chassis", "vin"], "Choose Add a vehicle, type its chassis (for example FH 123456) or VIN, and choose Load. The original configuration is kept unchanged; your changes become a proposal.", "Getting started", "start", Go("Add a vehicle", "vehicle")),
            new(["change", "prepare", "edit", "software", "parameter", "variant"], "Prepare changes on the tabs of the test request: Software (package versions), Parameters, Variants and S-Notes. Each change is saved as a new revision of your proposal a moment later.", "Prepare changes", "configure", Go("Prepare changes", "prepare")),
            new(["validate", "validation", "check"], "Validate checks your proposal against the catalog rules for every vehicle in the request. It needs at least one change; the result lists findings in plain words with the next step for each.", "Validate a proposal", "validate", Go("Go to Validate", "validate")),
            new(["blocked", "failure", "fail", "finding", "findings", "fix"], "A blocked vehicle has at least one validation failure. Each finding says what is wrong and offers the next step. Fix the failures and validate again before submitting.", "Validation findings", "validate", Go("Open the findings", "findings")),
            new(["review", "submit", "deliver", "kit", "commit"], "After a current validation without blocked vehicles, Review shows the delivery options: a conversion kit, a VDA update (Reviewer or Admin role) or an export. Only the exact validated revision can be committed.", "Review and deliver", "review", Go("Go to Review", "review")),
            new(["revision", "save", "saved", "autosave", "restore", "undo"], "Your proposal is saved automatically as numbered revisions. Revisions lists them; restoring one adds a new revision, so nothing is lost.", "Revisions", "revisions", null),
            new(["batch", "bulk", "many", "several"], "Batch runs send the same request for many vehicles, one after another, with a pause after each. Follow it live and download the report.", "Batch runs", "batch", Go("Open Batch runs", "batch")),
        ];

        private static readonly Dictionary<string, (string Term, string Meaning)> Glossary = new(StringComparer.OrdinalIgnoreCase)
        {
            ["vda"] = ("VDA", "the official record of each vehicle's configuration. A VDA update writes a validated proposal back to it."),
            ["edb"] = ("EDB", "the engineering database: vehicle specifications before production."),
            ["cbr"] = ("CBR", "the cab order number used to plan a spare cab."),
            ["ecu"] = ("ECU", "an electronic control unit: one computer in the vehicle, such as EMS for the engine."),
            ["hpc"] = ("HPC", "a high-performance computer in the T3 architecture that runs several software packages in execution environments."),
            ["ntp"] = ("NTP", "a node template: the approved software set for one vehicle computer."),
            ["snote"] = ("S-Note", "a short code that records a special build or exception on a vehicle."),
            ["snotes"] = ("S-Notes", "short codes that record special builds or exceptions on a vehicle."),
            ["t3"] = ("T3", "the newest electrical architecture, with HPC computers running software packages."),
            ["tea2"] = ("TEA2+", "the previous electrical architecture, with one software set per computer."),
            ["pus"] = ("PUS", "the Product Update Service, which finds the right service pack for a T3 vehicle."),
            ["apu"] = ("APU", "Available Product Updates: the software, hardware and kits a T3 vehicle can take."),
            ["kit"] = ("Conversion kit", "a package of operations that turns a vehicle's configuration into another, prepared from a validated result."),
            ["proposal"] = ("Proposal", "your planned changes to a vehicle. The original is kept unchanged."),
            ["limited"] = ("Limited validation", "a validation where some checks could not run. Its result is partial and should be treated as unconfirmed."),
        };

        [GeneratedRegex(@"[\p{L}\p{N}+]+")] private static partial Regex WordsRe();
        private static HashSet<string> Tokens(string s) => WordsRe().Matches(s.ToLowerInvariant()).Select(m => m.Value.TrimEnd('+')).ToHashSet();

        private static IReadOnlyList<string> Suggestions(RetrievedContext c)
        {
            var list = new List<string>();
            if (c.Items.Any(i => i.Kind == "request"))
            {
                list.Add("Why is a vehicle blocked?");
            }

            if (c.Items.Any(i => i.Kind == "vehicle"))
            {
                list.Add("Describe this vehicle");
            }

            if (c.Items.Any(i => i.Kind == "proposal"))
            {
                list.Add("What did I change?");
            }

            list.AddRange(["What are the steps?", "What is an NTP?", "How do I submit?"]);
            return list.Take(5).ToArray();
        }

        // ------------------------------------------------------------------ chat
        public Task<ChatReply> ChatAsync(ChatRequest request, CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested();
            var question = request.Messages.LastOrDefault(m => m.Role == "user")?.Text ?? "";
            var words = Tokens(question);
            var c = request.Context;
            ChatReply Reply(string text, IEnumerable<Citation> cites, string conf, params SuggestedAction?[] actions) =>
                new(text, cites.ToArray(), conf, actions.Where(a => a is not null).Select(a => a!).ToArray(), Info.Provider, true, Suggestions(c));

            // Definitions: "what is …", "define …", or a single known term.
            var term = words.Select(w => Glossary.TryGetValue(w, out var g) ? g : default).FirstOrDefault(g => g.Term is not null);
            if (term.Term is not null && (words.Overlaps(["what", "define", "meaning", "mean", "is", "explain"]) || words.Count <= 2))
            {
                return Task.FromResult(Reply($"{term.Term} is {term.Meaning}", [new("glossary", term.Term, null)], "confirmed"));
            }

            // The selected configuration and the validation result, from the records included as context.
            var req = c.Items.FirstOrDefault(i => i.Kind == "request");
            if (req is not null && words.Overlaps(["blocked", "why", "result", "validation", "findings", "issues", "failed"]))
            {
                var outcomes = req.Facts["outcomes"]!.AsArray().OfType<JsonObject>().ToArray();
                var blocked = outcomes.Where(o => o["ready"]?.GetValue<bool>() == false && o["limited"]?.GetValue<bool>() != true).ToArray();
                if (blocked.Length == 0)
                {
                    return Task.FromResult(Reply($"No vehicle in this request is blocked: {outcomes.Count(o => o["ready"]?.GetValue<bool>() == true)} ready, {outcomes.Count(o => o["limited"]?.GetValue<bool>() == true)} validated with limits.", [new("record", req.Title, req.Id)], "confirmed", Go("Go to Review", "review")));
                }

                var lines = blocked.Take(3).Select(o => $"{o.S("vehicle")}: " + string.Join("; ", o["issues"]!.AsArray().OfType<JsonObject>().Where(i => i.I("severity") == 0).Take(2).Select(i => i.S("text"))));
                return Task.FromResult(Reply($"{blocked.Length} vehicle(s) are blocked by validation failures. " + string.Join(" ", lines.Select(l => l.TrimEnd('.') + ".")) + " Fix them, then validate again.", [new("record", req.Title, req.Id)], "confirmed", Go("Open the findings", "findings")));
            }
            var veh = c.Items.FirstOrDefault(i => i.Kind == "vehicle");
            if (veh is not null && words.Overlaps(["describe", "vehicle", "configuration", "computers", "software", "this", "selected"]))
            {
                var f = veh.Facts;
                var sw = f["software"]!.AsArray().OfType<JsonObject>().Take(4).Select(n => $"{n.S("computer")} {n.S("version")}");
                return Task.FromResult(Reply($"{f.S("vehicle")} is a {f.S("model")} ({f.S("architecture")}), operated in {f.S("country")}, with {f.S("computers")} computers. The original is at VDA revision {f.S("revision")}. For example: {string.Join(", ", sw)}.", [new("record", veh.Title, veh.Id)], "confirmed"));
            }
            var prop = c.Items.FirstOrDefault(i => i.Kind == "proposal");
            if (prop is not null && words.Overlaps(["change", "changed", "changes", "proposal", "revision"]))
            {
                return Task.FromResult(Reply($"Your proposal is at revision {prop.Facts.S("revision")} ({prop.Facts.S("reason")}) with {prop.Facts.S("changes")} change(s) to {prop.Facts.S("vehicle")}.", [new("record", prop.Title, prop.Id)], "confirmed"));
            }

            // The workflow.
            var best = Workflow.Select(q => (q, score: q.Words.Count(words.Contains))).Where(x => x.score > 0).OrderByDescending(x => x.score).FirstOrDefault();
            if (best.q is not null)
            {
                return Task.FromResult(Reply(best.q.Answer, [new("help", best.q.Title, "?view=help&article=" + best.q.Article)], best.score >= 2 ? "confirmed" : "likely", best.q.Action));
            }

            // Outside the simulation: say so.
            var reason = req is null && veh is null && words.Overlaps(["blocked", "vehicle", "result", "describe"]) ? " No vehicle or request is included as context, so I cannot describe one; include it from the context list." : "";
            return Task.FromResult(Reply("I am a simulated assistant with scripted answers only, and this question is outside them." + reason + " I can explain the workflow, define technical terms (VDA, ECU, NTP, T3 …), and describe the included vehicle, proposal or request. For anything else, Help has the full guide.",
                [], "unknown", new SuggestedAction("navigate", "Search Help", new JsonObject { ["target"] = "help" })));
        }

        public async IAsyncEnumerable<string> StreamAsync(ChatRequest request, [EnumeratorCancellation] CancellationToken ct)
        {
            var reply = await ChatAsync(request, ct);
            foreach (var piece in Regex.Split(reply.Text, @"(?<=\s)"))
            {
                ct.ThrowIfCancellationRequested();
                yield return piece;
                await Task.Delay(15, ct);
            }
        }

        // ------------------------------------------------------------------ summaries
        public Task<SummaryReply> SummariseAsync(ContextItem s, DateTimeOffset now, CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested();
            var st = new List<SummaryStatement>();
            var src = new ContextRef(s.Kind, s.Id);
            void Add(string section, string text, ContextRef? from = null) => st.Add(new(text, section, from ?? src));
            var f = s.Facts;
            string title;
            switch (s.Kind)
            {
                case "request":
                    title = "Validation summary";
                    var outcomes = f["outcomes"]!.AsArray().OfType<JsonObject>().ToArray();
                    int ready = outcomes.Count(o => o["ready"]?.GetValue<bool>() == true), limited = outcomes.Count(o => o["limited"]?.GetValue<bool>() == true), blocked = outcomes.Length - ready - limited;
                    Add("identity", $"{f.S("kind")} request validated on {outcomes.Length} vehicle(s): " + string.Join(", ", outcomes.Select(o => $"{o.S("vehicle")} (VDA revision {o.S("baseRevision")})")) + ".");
                    Add("changes", $"{outcomes.Sum(o => o.I("changes"))} computer change(s) proposed across the vehicles.");
                    Add("findings", $"{ready} ready, {blocked} blocked, {limited} validated with limits.");
                    foreach (var o in outcomes)
                    {
                        foreach (var i in o["issues"]!.AsArray().OfType<JsonObject>().Where(i => i.I("severity") == 0).Take(3))
                        {
                            Add("findings", $"{o.S("vehicle")}: {i.S("text")}");
                        }
                    }

                    if (limited > 0)
                    {
                        Add("limitations", "Some checks could not run on the vehicles validated with limits; treat those results as unconfirmed.");
                    }

                    Add("limitations", "Validated by the built-in catalog rules only: no external system (KAX, Dependix, Digital Twin) took part.");
                    Add("next", blocked > 0 ? "Fix the validation failures, then validate again before submitting." : "Review the result and choose how to deliver it.", null);
                    break;
                case "proposal":
                    title = "Proposal summary";
                    Add("identity", $"Proposal revision {f.S("revision")} for {f.S("vehicle")}, saved {f["at"]} by {f.S("author")} ({f.S("reason")}).");
                    Add("changes", $"{f.S("changes")} change(s) to the original configuration.");
                    Add("findings", "A proposal is not a validation result: validate it to get findings.");
                    Add("next", f.I("changes") > 0 ? "Validate the proposal." : "Make a change, then validate it.", null);
                    break;
                case "activity":
                    title = "Activity summary";
                    Add("identity", $"Your last {f.S("requests")} request(s), the latest on {f["latest"]}.");
                    Add("changes", "By kind: " + string.Join(", ", (f["byKind"] as JsonObject ?? []).Select(kv => $"{kv.Value} {kv.Key}")) + ".");
                    Add("findings", $"{f.S("ready")} fully ready, {f.S("blocked")} with blocked vehicles, {f.S("limited")} with limited validation.");
                    Add("next", f.I("blocked") > 0 ? "Open Activity to inspect the blocked requests." : "Nothing is waiting on you.", null);
                    break;
                case "vehicle":
                    title = "Vehicle summary";
                    Add("identity", $"{f.S("vehicle")}: {f.S("model")}, {f.S("architecture")}, {f.S("computers")} computers, VDA revision {f.S("revision")}.");
                    var released = f["software"]!.AsArray().OfType<JsonObject>().Count(n => n.S("status") == "released");
                    Add("findings", $"{released} of {f["software"]!.AsArray().Count} listed computers run released software sets.");
                    Add("next", "Prepare a change on the test request, then validate it.", null);
                    break;
                default:
                    throw new RequestFault(400, "summary_kind", "Nothing to summarise for this kind.");
            }
            return Task.FromResult(new SummaryReply(title + " (simulated)", s.Kind, s.Id, s.Version, now, st, Info.Provider, true));
        }

        // ------------------------------------------------------------------ agent plan preview
        public Task<AgentPlan> PlanAsync(string goal, RetrievedContext context, IReadOnlyDictionary<string, bool> permissions, CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested();
            var w = Tokens(goal);
            var hasVehicle = context.Items.Any(i => i.Kind is "vehicle" or "proposal");
            bool P(string p) => permissions.TryGetValue(p, out var v) && v;
            var steps = new List<string>();
            var actions = new List<AgentProposedAction>();
            var needs = new List<AgentRequirement>
            {
                new("context", "A vehicle", hasVehicle, hasVehicle ? "Included." : "Include a vehicle or proposal as context, or load one first."),
            };
            if (w.Overlaps(["service", "pack", "update", "upgrade"]))
            {
                steps.AddRange(["Look up the service packs for the vehicle's context", "Propose the software versions the service pack brings", "Validate the proposal", "Show the findings and the review"]);
                actions.Add(new("propose", "Prepare a service pack update", "A proposal with the new software versions; nothing is saved to VDA.", "Proposal revisions (autosave)"));
                actions.Add(new("validate", "Validate the proposal", "Findings for every vehicle.", "Validation (Operator or Engineer)"));
                needs.Add(new("permission", "Run validations", P("simulate"), P("simulate") ? "You may." : "Your role cannot run validations."));
            }
            else if (w.Overlaps(["submit", "deliver", "commit", "vda", "kit"]))
            {
                steps.AddRange(["Check that the validation is current and nothing is blocked", "Open the review", "Prepare the delivery you choose"]);
                actions.Add(new("review", "Open the review", "The validated result and the delivery options.", "Review"));
                actions.Add(new("submit", "Submit the validated revision", "A VDA update or a kit from the exact validated revision.", "Submission (Reviewer or Admin role, and approval when required)"));
                needs.Add(new("permission", "Submit", P("write"), P("write") ? "You may." : "Submitting needs the Reviewer or Admin role."));
            }
            else if (w.Overlaps(["validate", "check", "test"]))
            {
                steps.AddRange(["Use the current proposal", "Run the validation", "Explain the findings"]);
                actions.Add(new("validate", "Validate the proposal", "Findings for every vehicle.", "Validation (Operator or Engineer)"));
                needs.Add(new("permission", "Run validations", P("simulate"), P("simulate") ? "You may." : "Your role cannot run validations."));
            }
            else if (w.Overlaps(["compare", "difference", "diff"]))
            {
                steps.AddRange(["Use the original and the proposal", "Show the differences per computer"]);
                actions.Add(new("navigate", "Open Compare", "A side-by-side view of what changed.", "None (read only)"));
            }
            else
            {
                steps.Add("This simulated agent recognises goals about service pack updates, validation, comparing and submitting. Rephrase the goal with one of those.");
            }
            return Task.FromResult(new AgentPlan(goal, steps.Select((s, i) => new AgentStep(i + 1, s)).ToArray(), needs, actions, true, Info.Provider, true,
                "Preview only: the simulated agent does not execute changes, submit requests, approve proposals or contact external services. To do any of this, use the normal steps of the application."));
        }
    }
}
