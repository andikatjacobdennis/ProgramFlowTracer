namespace Volvo.TestRequestTool.Application
{
    public interface IChatProvider
    {
        AssistantInfo Info { get; }
        Task<ChatReply> ChatAsync(ChatRequest request, CancellationToken ct);
        /// <summary>The answer in pieces as it is produced (for streaming); the final reply comes from ChatAsync.</summary>
        IAsyncEnumerable<string> StreamAsync(ChatRequest request, CancellationToken ct);
    }
}
