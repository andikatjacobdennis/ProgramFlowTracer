using System.Collections.Frozen;
using System.Diagnostics;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The request listener, simulated: like RequestDispatcher in swb-stable1 it routes a message on its type and version
    /// (<see cref="ListenerMessageType.Key"/>). Before the handler runs, the request is checked the way the listener checks
    /// it: well-formed XML (101 InvalidXml), the schemaVersion attribute against the contract version (a version error) and
    /// the XSD (107 InvalidMessage). After it, the reply is checked against the reply XSD, so a simulated reply that leaves
    /// its contract shows up as reply errors instead of passing unnoticed.
    /// </summary>
    public sealed partial class ListenerDispatcher
    {
        private readonly IListenerContracts _contracts;
        private readonly FrozenDictionary<string, IListenerHandler> _handlers;

        public ListenerDispatcher(IListenerContracts contracts, IEnumerable<IListenerHandler> handlers)
        {
            _contracts = contracts;
            _handlers = handlers.SelectMany(h => h.Keys.Select(k => (Key: k, Handler: h))).ToFrozenDictionary(x => x.Key, x => x.Handler, StringComparer.Ordinal);
        }

        public IListenerContracts Contracts => _contracts;

        /// <summary>The message types and versions the tool simulates, for example GetKitEvaluation_2.1.</summary>
        public IReadOnlyCollection<string> SimulatedKeys => _handlers.Keys;

        public bool IsSimulated(ListenerMessageType type) => _handlers.ContainsKey(type.Key);

        /// <summary>True when the handler of the type can write a request for a vehicle.</summary>
        public bool HasExample(ListenerMessageType type) => _handlers.GetValueOrDefault(type.Key) is IListenerExample or IListenerJsonExample;

        /// <summary>A request for the vehicle, written by the type's handler; null when it cannot write one.</summary>
        public XDocument? Example(ListenerMessageType type, ProductDocument vehicle) =>
            _handlers.GetValueOrDefault(type.Key) is IListenerExample example ? example.Example(type, vehicle) : null;

        /// <summary>A request for the vehicle as text: XML with its declaration, or JSON for the T3 services; null when none.</summary>
        public string? ExampleText(ListenerMessageType type, ProductDocument vehicle) => _handlers.GetValueOrDefault(type.Key) switch
        {
            IListenerExample xml when xml.Example(type, vehicle) is { } document => document.Declaration + Environment.NewLine + document.Root,
            IListenerJsonExample json => json.ExampleJson(type, vehicle),
            _ => null,
        };

        public async ValueTask<ListenerResult> DispatchAsync(string messageType, string version, string body, Actor actor, string senderId, CancellationToken ct)
        {
            var started = Stopwatch.GetTimestamp();
            var type = _contracts.Find(messageType, version)
                ?? throw new RequestFault(404, "message_type_unknown", $"Unhandled message type and version {messageType}_{version}.");
            var notices = new List<ListenerNotice>();
            var requestErrors = new List<string>();
            _handlers.TryGetValue(type.Key, out var handler);

            ListenerResult Done(ListenerReply? reply, IReadOnlyList<string> replyErrors) =>
                new(type.MessageType, type.Version, type.Title, handler is not null, requestErrors, reply, replyErrors,
                    notices.Concat(reply?.Notices ?? []).ToList(), Stopwatch.GetElapsedTime(started).TotalMilliseconds);

            // The request: parsed when its contract is XML, or when it has no XSD here but looks like XML. A message type with no
            // contract at all (Ping, GetInfo) takes any body, as in the listener.
            XDocument? xml = null;
            var request = type.Request;
            if (request is { CanValidate: true } || (request is { Json: false } && body.TrimStart().StartsWith('<')))
            {
                try
                {
                    xml = XDocument.Parse(body, LoadOptions.SetLineInfo);
                }
                catch (XmlException e)
                {
                    return Rejected(ListenerNotice.Error(ListenerNotice.InvalidXml, "InvalidXml", "The request is not well-formed XML: " + e.Message));
                }
            }

            var message = new ListenerMessage(type, body, xml, senderId, actor);
            if (request is { CanValidate: true } && xml is not null)
            {
                var expected = ContractVersion(request);
                var sent = xml.Root?.Attribute("schemaVersion")?.Value;
                if (!string.IsNullOrEmpty(sent) && expected is not null && sent != expected)
                {
                    return Rejected(ListenerNotice.Error(ListenerNotice.InvalidMessage, "RequestVersionError", $"The message type version {expected} does not match the XML schema version {sent}."));
                }

                requestErrors.AddRange(_contracts.Validate(request, xml));
                if (requestErrors.Count > 0)
                {
                    return Rejected(ListenerNotice.Error(ListenerNotice.InvalidMessage, "InvalidMessage", $"The request does not follow {request.File}: {Plural(requestErrors.Count, "problem")}."));
                }
            }
            else if (request is { Missing: true })
            {
                notices.Add(ListenerNotice.Warning($"SoftwareBreakdown.Contracts has no request contract for {type.Key}, so the request is not checked."));
            }

            if (handler is null)
            {
                notices.Add(ListenerNotice.Information($"The tool does not simulate {type.Key} yet. The request was checked against its contract; nothing was answered."));
                return Done(null, []);
            }

            var reply = await handler.HandleAsync(message, ct);
            return Done(reply, CheckReply(type, reply));

            ListenerResult Rejected(ListenerNotice notice)
            {
                if (handler is null)
                {
                    notices.Add(notice);
                    return Done(null, []);
                }

                var reply = handler.Reject(new ListenerMessage(type, body, xml, senderId, actor), notice);
                if (!reply.Notices.Contains(notice))
                {
                    notices.Add(notice);
                }

                return Done(reply, CheckReply(type, reply));
            }
        }

        private IReadOnlyList<string> CheckReply(ListenerMessageType type, ListenerReply reply)
        {
            if (type.Reply is not { CanValidate: true } contract || reply.MediaType != ListenerReply.Xml || reply.Body.Length == 0)
            {
                return [];
            }

            try
            {
                var document = XDocument.Parse(reply.Body, LoadOptions.SetLineInfo);
                // An error reply in its own contract (ErrorReport) is checked against that one.
                if (type.ErrorReply is { CanValidate: true } error && document.Root?.Name.LocalName == error.Root)
                {
                    contract = error;
                }

                return _contracts.Validate(contract, document);
            }
            catch (XmlException e)
            {
                return ["The reply is not well-formed XML: " + e.Message];
            }
        }

        /// <summary>The contract version a request names in schemaVersion: the namespace's last part, for example …/2_1 is 2.1.</summary>
        public static string? ContractVersion(ListenerContract contract)
        {
            var m = contract.Namespace is null ? null : NamespaceVersion().Match(contract.Namespace);
            return m is { Success: true } ? m.Groups[1].Value + "." + m.Groups[2].Value : null;
        }

        private static string Plural(int n, string word) => n == 1 ? "1 " + word : n + " " + word + "s";

        [GeneratedRegex(@"(\d+)_(\d+)$")]
        private static partial Regex NamespaceVersion();
    }
}
