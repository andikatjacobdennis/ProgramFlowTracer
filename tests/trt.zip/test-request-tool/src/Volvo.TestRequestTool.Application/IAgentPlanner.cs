namespace Volvo.TestRequestTool.Application
{
    public interface IAgentPlanner
    {
        /// <summary>Permissions: what the caller may do (simulate, edit, write, approve), so the plan can say what is missing.</summary>
        Task<AgentPlan> PlanAsync(string goal, RetrievedContext context, IReadOnlyDictionary<string, bool> permissions, CancellationToken ct);
    }
}
