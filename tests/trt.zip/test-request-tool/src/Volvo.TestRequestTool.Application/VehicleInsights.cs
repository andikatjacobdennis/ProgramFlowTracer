using System.Globalization;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// Read-only views of one vehicle for the Vehicle page:
    /// <list type="bullet">
    /// <item><b>Timeline</b>: where the vehicle has been. Its build and delivery dates and its first VDA record come from the
    /// vehicle itself, then come committed VDA revisions, kits that include the vehicle and the user's own simulations.
    /// Each entry says how it links to the others, so the client can draw it like a git history: the vehicle's own changes form the
    /// main line ("parent" is the previous one); simulations and kits sit on a side line that starts at the revision they were based on
    /// ("base"), and a simulation that was committed joins the main line again ("mergedInto").</item>
    /// <item><b>Snapshot</b>: the full configuration after any timeline entry, so earlier states can be shown and compared.</item>
    /// <item><b>Roadmap</b>: where the vehicle can go next, per node and per service pack, with the reason when something is blocked.</item>
    /// </list>
    /// Every call checks read access to the vehicle's context first.
    /// </summary>
    public sealed class VehicleInsights
    {
        private readonly IWorkspaceStore _store;
        private readonly ICatalog _catalog;
        private readonly Microsoft.Extensions.Caching.Hybrid.HybridCache? _cache;

        private sealed record Entry(string Id, string Kind, DateTimeOffset At, string ActorId, string ActorName, string Title, string Summary,
                        long? Revision, JsonObject? Snapshot, JsonObject? Source, bool OnlyYou = false, long? BaseRevision = null, string? FromRequest = null)
        {
            /// <summary>"main" for changes to the vehicle itself, "proposal" for simulations and kits.</summary>
            public string Lane => Kind is "Simulation" or "Kit" ? "proposal" : "main";
        }

        // ------------------------------------------------------------------ timeline
        /// <summary>History newest first. skip and take return one page of it (for loading as the user scrolls); total counts all entries.</summary>
        public async Task<JsonObject> TimelineAsync(Actor actor, string vehicleId, CancellationToken ct, int? skip = null, int? take = null)
        {
            var current = await AuthorizeAsync(actor, vehicleId, ct);
            var entries = await EntriesAsync(actor, vehicleId, current, ct);
            var people = entries.Where(e => e.ActorId is not ("system" or "")).GroupBy(e => e.ActorId)
                .Select(g => (JsonNode)new JsonObject { ["id"] = g.Key, ["name"] = g.First().ActorName, ["changes"] = g.Count() }).ToArray();
            var list = new JsonArray();
            // Newest first; each snapshot entry is compared with the previous (older) snapshot to describe what changed.
            var ordered = entries.OrderBy(e => e.At).ToList();
            JsonObject? previous = null;
            string? previousMain = null;
            var rendered = new List<JsonObject>();
            var revisionEntry = ordered.Where(e => e.Revision is not null).GroupBy(e => e.Revision!.Value).ToDictionary(g => g.Key, g => g.Last().Id);
            var mergedInto = ordered.Where(e => e.FromRequest is not null && e.Kind == "VdaCommit").GroupBy(e => e.FromRequest!).ToDictionary(g => g.Key, g => g.First().Id);
            foreach (var e in ordered)
            {
                var changes = e.Snapshot is not null && previous is not null ? Changes(previous, e.Snapshot) : new JsonArray();
                if (e.Snapshot is not null)
                {
                    previous = e.Snapshot;
                }
                // A side entry starts at the revision it was based on, or else at the latest change before it.
                var basedOn = e.Lane == "main" ? null : e.BaseRevision is long b && revisionEntry.TryGetValue(b, out var id) ? id : previousMain;
                rendered.Add(new JsonObject
                {
                    ["id"] = e.Id,
                    ["kind"] = e.Kind,
                    ["at"] = e.At.ToString("O", CultureInfo.InvariantCulture),
                    ["actor"] = new JsonObject { ["id"] = e.ActorId, ["name"] = e.ActorName },
                    ["title"] = e.Title,
                    ["summary"] = e.Summary,
                    ["revision"] = e.Revision,
                    ["hasSnapshot"] = e.Snapshot is not null,
                    ["changes"] = changes,
                    ["source"] = e.Source?.DeepClone(),
                    ["onlyYou"] = e.OnlyYou,
                    ["lane"] = e.Lane,
                    ["parent"] = e.Lane == "main" ? previousMain : null,
                    ["base"] = basedOn,
                    ["mergedInto"] = e.Kind == "Simulation" && e.Source?.S("id") is string rid && mergedInto.TryGetValue(rid, out var into) ? into : null,
                    ["from"] = e.FromRequest is string fr && ordered.Any(x => x.Id == "req-" + Guid.Parse(fr).ToString("N")) ? "req-" + Guid.Parse(fr).ToString("N") : null,
                });
                if (e.Lane == "main")
                {
                    previousMain = e.Id;
                }
            }
            foreach (var item in Enumerable.Reverse(rendered))
            {
                list.Add(item);
            }

            var newer = rendered.LastOrDefault(r => r.B("hasSnapshot"));
            var start = Math.Max(0, skip ?? 0);
            var count = Math.Clamp(take ?? list.Count, 0, 200);
            var page = new JsonArray(list.Skip(start).Take(count).Select(x => x!.DeepClone()).ToArray());
            return new JsonObject
            {
                ["vehicleId"] = vehicleId,
                ["currentRevision"] = current.Revision,
                ["latestSnapshotEntry"] = newer?["id"]?.DeepClone(),
                ["total"] = list.Count,
                ["skip"] = start,
                ["hasMore"] = start + page.Count < list.Count,
                ["people"] = new JsonArray(people),
                ["entries"] = page,
            };
        }

        /// <summary>Configuration after a timeline entry. Entries without a snapshot (simulations, kits) return 404.</summary>
        public async Task<JsonObject> SnapshotAsync(Actor actor, string vehicleId, string entryId, CancellationToken ct)
        {
            var current = await AuthorizeAsync(actor, vehicleId, ct);
            var entry = (await EntriesAsync(actor, vehicleId, current, ct)).FirstOrDefault(e => e.Id == entryId);
            if (entry?.Snapshot is null)
            {
                throw new RequestFault(404, "snapshot_missing", "No configuration snapshot exists for this history entry.");
            }

            return new JsonObject { ["entryId"] = entry.Id, ["at"] = entry.At.ToString("O", CultureInfo.InvariantCulture), ["title"] = entry.Title, ["product"] = entry.Snapshot.DeepClone() };
        }

        private async Task<VersionedProduct> AuthorizeAsync(Actor actor, string vehicleId, CancellationToken ct)
        {
            var current = await _store.VehicleAsync(vehicleId, ct) ?? throw new RequestFault(404, "vehicle_missing", "Vehicle was not found.");
            actor.DemandRead(new ProductDocument(current.Product).ContextId);
            return current;
        }

        private async Task<List<Entry>> EntriesAsync(Actor actor, string vehicleId, VersionedProduct current, CancellationToken ct)
        {
            var entries = new List<Entry>();
            var origin = new ProductDocument(await _store.OriginalAsync(vehicleId, ct) ?? current.Product);
            entries.AddRange(RecordedPast(origin));

            foreach (var r in await _store.RevisionsAsync(vehicleId, ct))
            {
                entries.Add(new Entry("rev-" + r.Revision, "VdaCommit", r.At, r.ActorId, r.ActorName, $"VDA revision {r.Revision}", r.Reason,
                    r.Revision, r.Product, r.Source is null ? null : new JsonObject { ["ref"] = r.Source },
                    FromRequest: r.Source is string src && src.StartsWith("request:", StringComparison.Ordinal) && Guid.TryParse(src[8..], out var g) ? g.ToString() : null));
            }

            foreach (var kit in await _store.KitsForVehicleAsync(vehicleId, ct))
            {
                entries.Add(new Entry("kit-" + kit.Id.ToString("N"), "Kit", kit.CreatedAt, kit.ActorId, kit.ActorName ?? kit.ActorId,
                    "Kit created: " + kit.Name, "A conversion kit was created from a validated result that includes this vehicle.", null, null,
                    new JsonObject { ["type"] = "kit", ["id"] = kit.Id.ToString() }, FromRequest: kit.RequestId.ToString()));
            }

            foreach (var record in await _store.ExecutionsForVehicleAsync(vehicleId, actor.Id, ct))
            {
                var outcome = record.Outcomes.First(o => o.VehicleId == vehicleId);
                var status = outcome.Issues.Any(i => i.Severity == 0) && !outcome.LimitedValidation ? "Blocked" : outcome.LimitedValidation ? "Limited validation" : "Ready";
                entries.Add(new Entry("req-" + record.Id.ToString("N"), "Simulation", record.CreatedAt, actor.Id, actor.DisplayName,
                    Label(record.Kind) + " simulated · " + status, "Only a simulation: the vehicle was not changed.", null, null,
                    new JsonObject { ["type"] = "request", ["id"] = record.Id.ToString(), ["status"] = status }, OnlyYou: true, BaseRevision: outcome.BaseRevision));
            }
            return entries;
        }

        /// <summary>
        /// What the repository knows from before its own revisions: the build and delivery dates the vehicle carries (when it
        /// has them) and the record as first imported, revision 1.
        /// </summary>
        private static List<Entry> RecordedPast(ProductDocument origin)
        {
            var info = origin.Info;
            var list = new List<Entry>();
            var built = Date(info.S("assemblyDate"));
            var delivered = Date(info.S("deliveryDate"));
            var factory = string.IsNullOrWhiteSpace(info.S("assemblyFactory")) ? "the factory" : info.S("assemblyFactory");
            if (built is { } b)
            {
                list.Add(new("built", "Built", b, "system", factory + " assembly", "Built at " + factory, "Assembly date from the vehicle record.", null, null, null));
            }

            if (delivered is { } d)
            {
                list.Add(new("delivered", "Delivered", d, "system", "Delivery", "Delivered to the customer", "Delivery date from the vehicle record.", null, null, null));
            }

            var recordedAt = (delivered ?? built ?? new DateTimeOffset(2024, 1, 1, 0, 0, 0, TimeSpan.Zero)).AddDays(1);
            list.Add(new Entry("rev-1", "VdaRecord", recordedAt, "system", "VDA", "VDA revision 1", "Configuration recorded in VDA.", 1, origin.Data, null));
            return list;
        }

        // ------------------------------------------------------------------ fleet summary
        /// <summary>Cache tag of every fleet summary; removing it invalidates them all, for example after a VDA commit.</summary>
        public const string FleetTag = "fleet";
        private static readonly Microsoft.Extensions.Caching.Hybrid.HybridCacheEntryOptions FleetEntry = new() { Expiration = TimeSpan.FromMinutes(1), LocalCacheExpiration = TimeSpan.FromMinutes(1) };

        /// <summary>
        /// The dashboard in one call: every vehicle the user may read with its up-to-date counts, waiting updates and last change,
        /// plus fleet-wide pipeline, service packs, activity per day and people. Cached for a minute per user; refresh skips it.
        /// <para>
        /// HybridCache (.NET 9+) runs the computation once per key however many requests arrive together (no cache stampede),
        /// and hands every caller its own copy. The key includes the user's contexts, so a result is never shared between
        /// users who may see different vehicles (FR-41). Without a cache (unit tests) the summary is computed directly.
        /// </para>
        /// </summary>
        public async Task<JsonObject> FleetAsync(Actor actor, bool refresh, CancellationToken ct)
        {
            if (_cache is null)
            {
                return await ComputeFleetAsync(actor, ct);
            }

            var key = $"fleet:{actor.Id}:{string.Join(',', actor.Contexts.Order())}";
            if (refresh)
            {
                await _cache.RemoveAsync(key, ct);
            }

            for (var attempt = 1; ; attempt++)
            {
                var result = await _cache.GetOrCreateAsync(key, (self: this, actor), static async (s, token) => await s.self.ComputeOrMarkAsync(s.actor, token), FleetEntry, [FleetTag], ct);
                if (result[Incomplete] is null)
                {
                    return result;
                }
                // The computation was cancelled (every caller left, or the host is stopping): never keep or hand out the marker.
                try
                {
                    await _cache.RemoveAsync(key, CancellationToken.None);
                }
                catch (ObjectDisposedException) { }
                ct.ThrowIfCancellationRequested();
                if (attempt == 2)
                {
                    throw new OperationCanceledException("The fleet summary could not be computed because the service is stopping.");
                }
            }
        }

        private const string Incomplete = "$incomplete";

        public VehicleInsights(IWorkspaceStore store, ICatalog catalog, Microsoft.Extensions.Caching.Hybrid.HybridCache? cache = null)
        {
            _store = store;
            _catalog = catalog;
            _cache = cache;
        }

        /// <summary>
        /// The cached computation. HybridCache can keep it running in the background after its callers have gone (for example
        /// the start-up warm-up when the host stops), and the store then refuses reads. A cancellation must not escape into
        /// HybridCache: the debugger reports it there as unhandled. It is returned as a marker instead, which FleetAsync removes.
        /// </summary>
        private async Task<JsonObject> ComputeOrMarkAsync(Actor actor, CancellationToken ct)
        {
            try
            {
                return await ComputeFleetAsync(actor, ct);
            }
            catch (OperationCanceledException)
            {
                return new JsonObject { [Incomplete] = true };
            }
        }

        private async Task<JsonObject> ComputeFleetAsync(Actor actor, CancellationToken ct)
        {
            {
                var data = _catalog.Data;
                var now = DateTimeOffset.UtcNow;
                var rows = new JsonArray();
                var pipeline = new Dictionary<string, (int Total, int Blocked)>();
                var packs = new Dictionary<string, Dictionary<string, List<string>>>();
                var days = new SortedDictionary<string, int>(StringComparer.Ordinal);
                var people = new Dictionary<string, int>(StringComparer.Ordinal);
                int entriesTotal = 0, commits = 0, commits90 = 0;
                foreach (var v in await _store.VehiclesAsync(ct))
                {
                    ct.ThrowIfCancellationRequested();   // hundreds of vehicles: stop promptly at shutdown or when every caller has gone
                    var doc = new ProductDocument(v.Product);
                    if (!actor.Contexts.Contains(doc.ContextId))
                    {
                        continue;
                    }

                    var entries = await EntriesAsync(actor, doc.Id, v, ct);
                    var road = RoadmapFor(doc.Id, v, data);
                    int current = 0, update = 0, blocked = 0, waiting = 0;
                    string? next = null;
                    DateTimeOffset? nextAt = null;
                    foreach (var node in road.A("nodes").Objects())
                    {
                        var ups = node.A("upcoming").Objects().ToArray();
                        var free = ups.Where(u => u.A("blockers").Count == 0).ToArray();
                        if (ups.Length == 0)
                        {
                            current++;
                        }
                        else if (free.Length > 0)
                        {
                            update++;
                        }
                        else
                        {
                            blocked++;
                        }

                        foreach (var u in ups)
                        {
                            var p = pipeline.GetValueOrDefault(u.S("status"));
                            pipeline[u.S("status")] = (p.Total + 1, p.Blocked + (u.A("blockers").Count > 0 ? 1 : 0));
                        }
                        foreach (var u in free)
                        {
                            var at = WeekDate(u.S("introductionWeek"));
                            if (at is not null && at < now)
                            {
                                waiting++;
                            }

                            if (at is not null && (nextAt is null || at < nextAt))
                            {
                                nextAt = at;
                                next = u.S("versionName");
                            }
                        }
                    }
                    foreach (var sp in road.A("servicePacks").Objects())
                    {
                        if (!packs.TryGetValue(sp.S("name"), out var states))
                        {
                            packs[sp.S("name")] = states = new() { ["Available"] = [], ["Already on it"] = [], ["Not applicable"] = [] };
                        }

                        states[sp.S("state")].Add(doc.Info.S("chassisSeries") + " " + doc.Info.S("chassisNumber"));
                    }
                    var last = entries.Where(e => e.Lane == "main" && e.Snapshot is not null).OrderByDescending(e => e.At).FirstOrDefault();
                    foreach (var e in entries)
                    {
                        var key = e.At.UtcDateTime.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                        days[key] = days.GetValueOrDefault(key) + 1;
                        if (e.Kind is "VdaCommit" or "Kit" or "Workshop" or "Service")
                        {
                            var who = e.ActorName.Split(" (")[0];
                            people[who] = people.GetValueOrDefault(who) + 1;
                        }
                        if (e.Kind == "VdaCommit")
                        {
                            commits++;
                            if (now - e.At < TimeSpan.FromDays(90))
                            {
                                commits90++;
                            }
                        }
                    }
                    entriesTotal += entries.Count;
                    rows.Add(new JsonObject
                    {
                        ["id"] = doc.Id,
                        ["series"] = doc.Info.S("chassisSeries"),
                        ["number"] = doc.Info.S("chassisNumber"),
                        ["label"] = doc.Info.S("chassisSeries") + " " + doc.Info.S("chassisNumber"),
                        ["model"] = doc.Info.S("modelId"),
                        ["country"] = doc.Info.S("countryOfOperation"),
                        ["t3"] = doc.Nodes.Objects().Any(n => n.I("electricalArchitecture") == 3),
                        ["counts"] = new JsonObject { ["current"] = current, ["update"] = update, ["blocked"] = blocked, ["total"] = current + update + blocked },
                        ["waiting"] = waiting,
                        ["nextUpdate"] = next,
                        ["entries"] = entries.Count,
                        ["lastChange"] = last is null ? null : new JsonObject { ["at"] = last.At.ToString("O", CultureInfo.InvariantCulture), ["title"] = last.Title, ["actor"] = last.ActorName },
                        ["daysSinceChange"] = last is null ? null : (int)(now - last.At).TotalDays,
                    });
                }
                var result = new JsonObject
                {
                    ["generatedAt"] = now.ToString("O", CultureInfo.InvariantCulture),
                    ["vehicles"] = rows.Count,
                    ["entries"] = entriesTotal,
                    ["commits"] = commits,
                    ["commits90"] = commits90,
                    ["rows"] = rows,
                    ["pipeline"] = new JsonObject(pipeline.Select(kv => KeyValuePair.Create(kv.Key, (JsonNode?)new JsonObject { ["total"] = kv.Value.Total, ["blocked"] = kv.Value.Blocked }))),
                    ["packs"] = new JsonArray(packs.Select(kv => (JsonNode)new JsonObject { ["name"] = kv.Key, ["Available"] = Strings(kv.Value["Available"]), ["Already on it"] = Strings(kv.Value["Already on it"]), ["Not applicable"] = Strings(kv.Value["Not applicable"]) }).ToArray()),
                    ["days"] = new JsonObject(days.Select(kv => KeyValuePair.Create(kv.Key, (JsonNode?)kv.Value))),
                    ["people"] = new JsonArray(people.OrderByDescending(kv => kv.Value).Take(8).Select(kv => (JsonNode)new JsonArray(kv.Key, kv.Value)).ToArray()),
                };
                return result;
            }
        }

        private static JsonArray Strings(IEnumerable<string> items) => new(items.Select(x => (JsonNode)x).ToArray());

        /// <summary>Monday of an ISO week written as '202630'.</summary>
        private static DateTimeOffset? WeekDate(string week) =>
            week.Length == 6 && int.TryParse(week[..4], out var y) && int.TryParse(week[4..], out var w) && w is >= 1 and <= 53
                ? new DateTimeOffset(ISOWeek.ToDateTime(y, w, DayOfWeek.Monday), TimeSpan.Zero) : null;

        /// <summary>Node-level differences between two configurations: changed node template versions and software package versions.</summary>
        private static JsonArray Changes(JsonObject before, JsonObject after)
        {
            var result = new JsonArray();
            var old = new ProductDocument(before).Nodes.Objects().ToDictionary(JsonAccess.NodeKeyOf, StringComparer.Ordinal);
            var now = new ProductDocument(after).Nodes.Objects().ToDictionary(JsonAccess.NodeKeyOf, StringComparer.Ordinal);
            foreach (var (key, node) in now)
            {
                if (!old.TryGetValue(key, out var was))
                {
                    result.Add(Change(node.S("name"), "Added", "", node.S("versionName")));
                    continue;
                }
                if (was.S("versionName") != node.S("versionName") || was["nodeTemplateDocument"].I("number") != node["nodeTemplateDocument"].I("number"))
                {
                    result.Add(Change(node.S("name"), "Software", was.S("versionName"), node.S("versionName"), Packages(was, node)));
                }
                else if (was["ecuHardware"].I("number") != node["ecuHardware"].I("number"))
                {
                    result.Add(Change(node.S("name"), "Hardware", was["ecuHardware"].S("number"), node["ecuHardware"].S("number")));
                }
            }
            foreach (var (key, node) in old)
            {
                if (!now.ContainsKey(key))
                {
                    result.Add(Change(node.S("name"), "Removed", node.S("versionName"), ""));
                }
            }

            var oldParams = new ProductDocument(before).Parameters.Objects().Select(p => p.ToJsonString()).ToHashSet(StringComparer.Ordinal);
            var changedParams = new ProductDocument(after).Parameters.Objects().Count(p => !oldParams.Contains(p.ToJsonString()));
            if (changedParams > 0)
            {
                result.Add(Change("Parameters", "Parameters", "", changedParams + " changed"));
            }

            return result;
        }

        private static JsonArray Packages(JsonObject before, JsonObject after)
        {
            var old = before.A("softwareProducts").Objects().ToDictionary(s => s.S("softwareProduct", s.S("name")), s => s.S("packageVersion"));
            return new JsonArray(after.A("softwareProducts").Objects()
                .Where(s => old.GetValueOrDefault(s.S("softwareProduct", s.S("name"))) != s.S("packageVersion"))
                .Select(s => (JsonNode)new JsonObject { ["name"] = s.S("softwareProduct", s.S("name")), ["from"] = old.GetValueOrDefault(s.S("softwareProduct", s.S("name"))) ?? "", ["to"] = s.S("packageVersion") })
                .ToArray());
        }

        private static JsonObject Change(string node, string kind, string from, string to, JsonArray? packages = null) =>
            new() { ["node"] = node, ["kind"] = kind, ["from"] = from, ["to"] = to, ["packages"] = packages ?? new JsonArray() };

        // ------------------------------------------------------------------ roadmap
        /// <summary>Upcoming node template versions per node and the service packs of the vehicle's context, with blockers.</summary>
        public async Task<JsonObject> RoadmapAsync(Actor actor, string vehicleId, CancellationToken ct) =>
            RoadmapFor(vehicleId, await AuthorizeAsync(actor, vehicleId, ct), _catalog.Data);

        private JsonObject RoadmapFor(string vehicleId, VersionedProduct current, JsonObject data)
        {
            var p = new ProductDocument(current.Product);
            var nodes = new JsonArray();
            var positions = new Dictionary<string, int>(StringComparer.Ordinal);
            foreach (var node in p.Nodes.Objects())
            {
                var template = _catalog.FindTemplate(node);
                if (template is null)
                {
                    nodes.Add(new JsonObject { ["node"] = node.S("name"), ["documented"] = false, ["upcoming"] = new JsonArray() });
                    continue;
                }
                var versions = template.A("versions").Objects().ToArray();
                var cur = Array.FindIndex(versions, v => v.I("doc") == node["nodeTemplateDocument"].I("number"));
                positions[template.S("key")] = cur;
                var upcoming = new JsonArray();
                foreach (var v in versions.Where(v => v.I("idx") > cur))
                {
                    var blockers = new JsonArray();
                    var hw = node["ecuHardware"].I("number");
                    if (!v.A("hardware").Any(h => int.TryParse(h?.ToString(), out var n) && n == hw))
                    {
                        blockers.Add("Needs ECU hardware " + string.Join(" or ", v.A("hardware").Select(h => h?.ToString())));
                    }

                    foreach (var dep in v.A("requires").Objects())
                    {
                        var needed = data.A("templates").Objects().FirstOrDefault(t => t.S("key") == dep.S("key"))
                            ?.A("versions").Objects().FirstOrDefault(x => x.I("idx") == dep.I("minIdx"))?.S("versionName");
                        blockers.Add($"Needs {needed ?? dep.S("key")} or later");
                    }
                    upcoming.Add(new JsonObject
                    {
                        ["versionName"] = v.S("versionName"),
                        ["documentNumber"] = v.I("doc"),
                        ["status"] = Status(v.S("status")),
                        ["introductionWeek"] = v.S("introductionWeek"),
                        ["remoteCapable"] = v.B("remoteCapable"),
                        ["blockers"] = blockers,
                        ["packages"] = new JsonArray(v["node"].A("softwareProducts").Objects().Select(s => (JsonNode)new JsonObject { ["name"] = s.S("softwareProduct", s.S("name")), ["version"] = s.S("packageVersion") }).ToArray()),
                    });
                }
                nodes.Add(new JsonObject
                {
                    ["node"] = node.S("name"),
                    ["key"] = template.S("key"),
                    ["documented"] = true,
                    ["isHpc"] = node.I("electricalArchitecture") == 3,
                    ["current"] = cur < 0 ? null : new JsonObject { ["versionName"] = versions[cur].S("versionName"), ["status"] = Status(versions[cur].S("status")), ["documentNumber"] = versions[cur].I("doc") },
                    ["upcoming"] = upcoming,
                });
            }
            var packs = new JsonArray();
            foreach (var sp in data.A("servicePacks").Objects().Where(s => s.I("contextId") == p.ContextId).OrderBy(s => s.I("sortOrder")))
            {
                var missing = positions.Keys.Where(k => sp["ntps"]?[k] is null).ToArray();
                var behind = positions.Where(kv => sp["ntps"]?[kv.Key] is not null && kv.Value < sp["ntps"].I(kv.Key)).Select(kv => kv.Key).ToArray();
                packs.Add(new JsonObject
                {
                    ["name"] = sp.S("name"),
                    ["guid"] = sp.S("guid"),
                    ["sortOrder"] = sp.I("sortOrder"),
                    ["state"] = missing.Length > 0 ? "Not applicable" : behind.Length == 0 ? "Already on it" : "Available",
                    ["updates"] = new JsonArray(behind.Select(k => (JsonNode)k).ToArray()),
                    ["notCovered"] = new JsonArray(missing.Select(k => (JsonNode)k).ToArray()),
                });
            }
            return new JsonObject { ["vehicleId"] = vehicleId, ["revision"] = current.Revision, ["nodes"] = nodes, ["servicePacks"] = packs };
        }

        private static string Label(RequestKind kind) => kind switch
        {
            RequestKind.ProductUpdateService => "Product Update Service",
            RequestKind.AvailableProductUpdates => "Available Product Updates",
            RequestKind.AvailableUpdates => "Available Updates",
            RequestKind.ConversionKit => "Conversion kit",
            RequestKind.SpareCab => "Spare cab",
            RequestKind.ProductionBreakdown => "Production breakdown",
            RequestKind.DevelopmentBreakdown => "Development breakdown",
            _ => "Software request",
        };

        private static string Status(string status) => status switch
        {
            "released" => "Released",
            "introduced" => "Introduced",
            "prereleaseverification" => "Pre-release verification",
            "inprogress" => "In progress",
            _ => "Unknown",
        };

        private static DateTimeOffset? Date(string value) =>
            DateTimeOffset.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var d) ? d : null;
    }
}
