namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// One side of a listener message, the request or the reply: the XSD that describes it, as SchemaSet.cs in
    /// SoftwareBreakdown.Contracts names it. <see cref="Missing"/> means the listener handles the version but the contracts
    /// have no XSD for this side, so it cannot be checked. <see cref="Json"/> marks the JSON services (no XSD).
    /// <see cref="Note"/> says why a contract other than the one SchemaSet.cs names is used.
    /// </summary>
    public sealed record ListenerContract(string? Namespace, string? Version, string? File, string? Root, bool Json, bool Missing, string? Note = null)
    {
        /// <summary>True when the side has an XSD and a root element, so a message can be checked against it.</summary>
        public bool CanValidate => File is not null && Root is not null;
    }
}
