using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// GetKitEvaluation 2.1 (Request.Listener/Aftermarket/KitEvaluation_2_1, KitEvaluation_2.1.4): the requested kits applied to
    /// each product, per action criterion. KitInformation describes each kit; each SoftwareNodeReplacements says whether the
    /// kits can be applied (outcome) and, when they can, the nodes they assign (their node template, status, remote download,
    /// whether the hardware changes) and remove. As in the listener, a severe error (an unknown kit, a kit already applied, a
    /// kit that is not a service kit when only those are allowed) rejects the whole request.
    /// </summary>
    public sealed class KitEvaluationHandler : ListenerXmlHandler
    {
        private static readonly XNamespace Ns = "http://www.volvo.com/KitEvaluation/2_1";
        private readonly ListenerProducts _products;
        private readonly ListenerCatalog _catalog;

        public KitEvaluationHandler(ListenerProducts products, ListenerCatalog catalog, TimeProvider clock) : base(clock)
        {
            _products = products;
            _catalog = catalog;
        }

        public override IReadOnlyCollection<string> Keys { get; } = ["GetKitEvaluation_2.1"];

        protected override async Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct)
        {
            var data = ListenerXml.Find(message.Xml, "DataArea");
            var criteria = ListenerXml.Child(data, "Criteria");
            var verbs = KitEvaluation.Parse(ListenerXml.Attribute(criteria, "actionCriteria"));
            var scenario = ListenerCatalog.Scenario(ListenerXml.Attribute(criteria, "scenario"));
            var serviceOnly = ListenerXml.Flag(ListenerXml.Attribute(criteria, "allowServiceKitsOnly"));
            var language = ListenerXml.Attribute(criteria, "languageCode") ?? "en-US";
            var requested = ListenerXml.Children(ListenerXml.Child(data, "RequestedKits"), "RequestedKit").ToList();
            var products = new List<ListenerProduct>();
            foreach (var element in ListenerXml.Children(data, "Product"))
            {
                products.Add(await _products.ReadAsync(element, message.Actor, ct));
            }

            var summary = products.Select(p => p.Source).ToList();
            var sections = new List<XElement>();
            foreach (var verb in verbs)
            {
                var assigned = new List<XElement>();
                var removed = new List<XElement>();
                var notes = new List<XElement>();
                var outcome = "Applicable";
                foreach (var p in products)
                {
                    var kits = KitsFor(requested, p);
                    var evaluation = KitEvaluation.Evaluate(_catalog, p.Product, kits, verb, scenario, serviceOnly);
                    if (evaluation.Error is { } error && KitEvaluation.Severe(error))
                    {
                        throw error;
                    }

                    if (evaluation.Result is null)
                    {
                        outcome = evaluation.Outcome;
                        summary.Add(new ListenerFact(verb, $"{p.Shown}: {evaluation.Outcome}. {evaluation.Error?.Message}"));
                        continue;
                    }

                    foreach (var a in evaluation.Result.Assigned)
                    {
                        var template = _catalog.Template(a.Node);
                        var version = _catalog.Catalog.FindVersion(a.Node);
                        assigned.Add(Detailed(p, a, version));
                        var note = ListenerCatalog.ReleaseNote(version, language);
                        if (note is not null && template is not null && version is not null)
                        {
                            notes.Add(new XElement(ReleaseNotesHandler.Rn + "ReleaseNote", new XAttribute("id", ListenerCatalog.ReleaseNoteId(template, version)), new XAttribute("releaseNote", note)));
                        }
                    }

                    removed.AddRange(evaluation.Result.Removed.Select(r => new XElement(Ns + "Node", Chassis(p), ListenerCatalog.NodeId(Ns, r))));
                    summary.Add(new ListenerFact(verb, $"{p.Shown}: Applicable. Assigns {Names(evaluation.Result.Assigned.Select(a => a.Node))}; removes {Names(evaluation.Result.Removed)}."));
                }

                sections.Add(new XElement(Ns + "SoftwareNodeReplacements", new XAttribute("actionCriteria", verb), new XAttribute("outcome", outcome),
                    outcome != "Applicable" || assigned.Count == 0 ? null : new XElement(Ns + "AssignedNodes", assigned),
                    outcome != "Applicable" || removed.Count == 0 ? null : new XElement(Ns + "RemovedNodes", removed),
                    outcome != "Applicable" || notes.Count == 0 ? null : new XElement(Ns + "ReleaseNotes", notes)));
            }

            var info = requested.Select(r => ListenerXml.Number(ListenerXml.Attribute(r, "partNumber")) ?? 0).Distinct().Order()
                .Select(n => _catalog.Kit(n)).Where(k => k is not null)
                .Select(k => new XElement(Ns + "ConversionKit",
                    new XAttribute("partNumber", k!.I("partNumber")),
                    new XAttribute("name", k.S("name")),
                    new XAttribute("kitType", ListenerCatalog.KitType(k!)),
                    new XAttribute("isAvailableRemote", "false"),
                    new XAttribute("hardwareNonControlUnitChangeNeeded", "false")));
            var root = ListenerXml.Bod(Ns, "ShowKitEvaluation", "SRV12930", "2.1", ListenerXml.Transaction(message.Xml), Clock,
                ListenerXml.Accepted(Ns), new XElement(Ns + "KitInformation", info), sections);
            summary.Insert(0, new ListenerFact("Outcome", string.Join(", ", sections.Select(s => s.Attribute("actionCriteria")!.Value.Replace("SoftwareReplacements.", "", StringComparison.Ordinal) + " " + s.Attribute("outcome")!.Value)) + "."));
            return new ListenerAnswer(root, summary, []);
        }

        protected override XElement Error(ListenerMessage message, ListenerNotice notice, string bodId) =>
            ListenerXml.Bod(Ns, "ShowKitEvaluation", "SRV12930", "2.1", bodId, Clock, ListenerXml.Rejected(Ns, notice), new XElement(Ns + "KitInformation"));

        public override XDocument Example(ListenerMessageType type, ProductDocument vehicle) =>
            Document(new XElement(Ns + "GetKitEvaluation",
                ListenerXml.RequestArea(Clock),
                new XElement(Ns + "DataArea",
                    new XElement(Ns + "Criteria", new XAttribute("actionCriteria", "SoftwareReplacements.General,SoftwareReplacements.RemoteGeneral"), new XAttribute("scenario", "Introduced"), new XAttribute("languageCode", "en-GB"), new XAttribute("pblUpdateCapable", "true")),
                    new XElement(Ns + "RequestedKits", ExampleKit(_catalog, vehicle).Select(k => new XElement(Ns + "RequestedKit", new XAttribute("partNumber", k)))),
                    ListenerProducts.ProductElement(Ns, "Product", vehicle))));

        /// <summary>A kit for an example: the first the vehicle's product class takes, or the first kit of the catalog.</summary>
        public static IEnumerable<long> ExampleKit(ListenerCatalog catalog, ProductDocument vehicle)
        {
            var kit = catalog.Kits.FirstOrDefault(k => k.A("productClasses").Any(c => c?.ToString() == vehicle.Info.S("productClassId")) && ListenerCatalog.KitAllowed(k, 1)) ?? catalog.Kits.First();
            return [kit.I("partNumber")];
        }

        private static List<long> KitsFor(List<XElement> requested, ListenerProduct p) =>
            requested.Where(r => ListenerXml.Attribute(r, "chassisSeries") is not { } s || (ListenerProducts.Series(s) == p.ChassisSeries && ListenerProducts.Number(ListenerXml.Attribute(r, "chassisNumber") ?? "") == p.ChassisNumber))
                .Select(r => (long)(ListenerXml.Number(ListenerXml.Attribute(r, "partNumber")) ?? 0)).Distinct().ToList();

        private static XElement Detailed(ListenerProduct p, KitNode a, System.Text.Json.Nodes.JsonObject? version)
        {
            var hardware = ListenerCatalog.CompatibleHardware(version, a.Node).ToList();
            return new XElement(Ns + "Node", Chassis(p),
                version.I("doc") > 0 ? new XAttribute("nodeTemplateDocumentNumber", ListenerXml.PartNumber(version.I("doc"))) : null,
                new XAttribute("IsSoftwareSame", "false"),
                new XAttribute("nodeTemplateStatus", ListenerCatalog.Status(version)),
                new XAttribute("remoteSWDLAvailability", ListenerCatalog.Remote(version)),
                new XAttribute("HardwareChangeNeeded", a.HardwareChangeNeeded ? "true" : "false"),
                new XAttribute("SerialNumberInputNeeded", a.SerialNumberInputNeeded ? "true" : "false"),
                ListenerCatalog.NodeId(Ns, a.Node),
                hardware.Count == 0 ? null : new XElement(Ns + "CompatibleHardwares", hardware.Select(h => new XElement(Ns + "CompatibleHardware", new XAttribute("partNumber", ListenerXml.PartNumber(h.PartNumber)), new XAttribute("compatiblePartNumber", ListenerXml.PartNumber(h.Compatible))))));
        }

        private static object[] Chassis(ListenerProduct p) => [new XAttribute("chassisSeries", p.ChassisSeries), new XAttribute("chassisNumber", p.ChassisNumber)];

        private static string Names(IEnumerable<System.Text.Json.Nodes.JsonObject> nodes)
        {
            var list = nodes.Select(ListenerCatalog.Name).ToList();
            return list.Count == 0 ? "no nodes" : string.Join(", ", list);
        }
    }
}
