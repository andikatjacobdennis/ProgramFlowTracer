using System.Text.Json;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The T3 JSON services of the listener: ProductUpdateService 1.0 and 2.0 and GetAvailableProductUpdates 1.0 and 1.1
    /// (Request.Listener/Aftermarket/ProductUpdateService_1_0, _2_0, AvailableProductUpdates_1_0, _1_1). The request is the
    /// listener's JSON; the vehicle is found by the chassis of its product (product.identification.chassisId), and the tool's
    /// own handlers answer (ProductUpdateServiceHandler and AvailableProductUpdatesHandler, the same as New request). Unlike
    /// the listener, which evaluates the product as sent, the tool uses the vehicle in the repository: the reply says so.
    /// The Available Product Updates reply is ShowAvailableUpdates, with serviceID and serviceVersion only on an error, as the
    /// listener writes it.
    /// </summary>
    public sealed class T3ListenerHandler : IListenerHandler, IListenerJsonExample
    {
        private static readonly JsonSerializerOptions Indented = new() { WriteIndented = true };
        private readonly ListenerVehicles _vehicles;
        private readonly ProductUpdateServiceHandler _productUpdate;
        private readonly AvailableProductUpdatesHandler _available;

        public T3ListenerHandler(ICatalog catalog, ListenerVehicles vehicles)
        {
            _vehicles = vehicles;
            _productUpdate = new ProductUpdateServiceHandler(catalog);
            _available = new AvailableProductUpdatesHandler(catalog);
        }

        public IReadOnlyCollection<string> Keys { get; } = ["ProductUpdateService_1.0", "ProductUpdateService_2.0", "GetAvailableProductUpdates_1.0", "GetAvailableProductUpdates_1.1"];

        private static bool IsProductUpdate(ListenerMessageType type) => type.MessageType == "ProductUpdateService";

        public async ValueTask<ListenerReply> HandleAsync(ListenerMessage message, CancellationToken ct)
        {
            var type = message.Type;
            JsonObject? body;
            try
            {
                body = JsonNode.Parse(message.Body) as JsonObject;
            }
            catch (JsonException)
            {
                body = null;
            }

            if (body is null)
            {
                return Error(type, body, 100, "ArgumentException", "Invalid JSON format");
            }

            var get = IsProductUpdate(type) ? body : body["GetAvailableUpdates"] as JsonObject;
            var productNode = IsProductUpdate(type) ? get?["product"] : get?["DataArea"]?["Product"] is JsonArray list ? list.FirstOrDefault() : get?["DataArea"]?["Product"];
            var chassis = productNode?["identification"]?["chassisId"];
            var vehicle = await _vehicles.FindAsync(chassis.S("series"), chassis.S("number"), message.Actor, ct);
            var shown = $"{chassis.S("series")} {chassis.S("number")}".Trim();
            if (vehicle is null)
            {
                return Error(type, body, 103, "NotificationException", $"Product {shown} is not a vehicle the tool has, or it is outside your vehicle contexts.");
            }

            HandlerResult result;
            if (IsProductUpdate(type))
            {
                var payload = new JsonObject
                {
                    ["schemaVersion"] = type.Version,
                    ["traceId"] = body.S("traceId"),
                    ["criteria"] = body["criteria"]?.DeepClone(),
                    ["previousEcuHardware"] = body["requestedNodes"]?["node"]?[0]?.S("previousECUHardware"),
                    ["languageCode"] = "en-US",
                };
                result = await _productUpdate.HandleAsync(vehicle, payload, ct);
            }
            else
            {
                var requested = new JsonArray();
                foreach (var node in (get?["DataArea"]?["RequestedNodes"]?["Node"] as JsonArray ?? []).OfType<JsonObject>())
                {
                    var name = node["NodeName"];
                    var family = name?["nodeFamily"] ?? name?["family"];
                    var nodeType = name?["nodeType"] ?? name?["type"];
                    var match = vehicle.Nodes.Objects().FirstOrDefault(n => n["nodeIdentifier"].S("family") == family?.ToString() && n["nodeIdentifier"].S("type") == nodeType?.ToString());
                    if (match is not null)
                    {
                        requested.Add(new JsonObject { ["nodeIdentifier"] = match["nodeIdentifier"]!.DeepClone() });
                    }
                }

                var payload = new JsonObject
                {
                    ["contractVersion"] = type.Version,
                    ["transactionId"] = get?["ApplicationArea"]?.S("BODID"),
                    ["criteria"] = get?["DataArea"]?["Criteria"]?.DeepClone(),
                    ["requestedNodes"] = requested,
                };
                result = await _available.HandleAsync(vehicle, payload, ct);
            }

            var response = (JsonObject)result.ServiceResponse!["response"]!.DeepClone();
            if (!IsProductUpdate(type) && response["ShowAvailableProductUpdates"] is JsonObject show)
            {
                response.Remove("ShowAvailableProductUpdates");
                if (show["DataArea"]?["Show"].S("ResponseCriteria") != "Rejected")
                {
                    show.Remove("serviceID");
                    show.Remove("serviceVersion");
                }

                response["ShowAvailableUpdates"] = show;
            }

            var code = result.ServiceResponse.I("aftermarketErrorCode");
            var notices = code == 0 ? new List<ListenerNotice>() : [ListenerNotice.Error(code, code == 107 ? "InvalidMessage" : "Undefined", result.Issues.FirstOrDefault()?.Text ?? "Rejected.")];
            var summary = new List<ListenerFact>
            {
                new("Outcome", code == 0 ? "Answered." : $"Rejected with {code}."),
                new("Product", $"{vehicle.Info.S("chassisSeries")} {vehicle.Info.S("chassisNumber")}: the vehicle in the repository was used, not the product as the request gives it."),
            };
            summary.AddRange(result.Issues.Where(i => i.Severity > 0 || code == 0).Select(i => new ListenerFact(i.Node ?? "Note", i.Text)));
            return new ListenerReply(response.ToJsonString(Indented), ListenerReply.JsonText, notices, summary);
        }

        public ListenerReply Reject(ListenerMessage message, ListenerNotice notice) => Error(message.Type, null, notice.Code, "NotificationException", notice.Text);

        /// <summary>The request the tool's handler sends for the vehicle, as the listener takes it.</summary>
        public string ExampleJson(ListenerMessageType type, ProductDocument vehicle)
        {
            HandlerResult result;
            if (IsProductUpdate(type))
            {
                result = _productUpdate.HandleAsync(vehicle, new JsonObject
                {
                    ["schemaVersion"] = type.Version,
                    ["criteria"] = new JsonObject { ["scenario"] = "Introduced", ["operation"] = type.Version == "2.0" ? new JsonObject { ["operationType"] = "UpdateToServicePack" } : null },
                }, default).AsTask().GetAwaiter().GetResult();
            }
            else
            {
                JsonNode actions = type.Version == "1.0" ? JsonValue.Create("SoftwareReplacements.General")! : new JsonArray("SoftwareReplacements.General");
                result = _available.HandleAsync(vehicle, new JsonObject
                {
                    ["contractVersion"] = type.Version,
                    ["criteria"] = new JsonObject { ["actionCriteria"] = actions, ["scenario"] = "Introduced", ["pblUpdateCapable"] = true, ["languageCode"] = "en-GB" },
                }, default).AsTask().GetAwaiter().GetResult();
            }

            var request = (JsonObject)result.ServiceResponse!["request"]!.DeepClone();
            if (request["criteria"] is JsonObject criteria && criteria["operation"] is null)
            {
                criteria.Remove("operation");
            }

            return request.ToJsonString(Indented);
        }

        private static ListenerReply Error(ListenerMessageType type, JsonObject? body, int code, string kind, string text)
        {
            var notice = ListenerNotice.Error(code, code == 103 ? "InvalidProductError" : code == 107 ? "InvalidMessage" : "Undefined", text);
            JsonObject reply;
            if (IsProductUpdate(type))
            {
                reply = new JsonObject
                {
                    ["schemaVersion"] = type.Version,
                    ["traceId"] = body.S("traceId"),
                    ["errors"] = new JsonArray(new JsonObject { ["type"] = kind, ["text"] = text }),
                };
            }
            else
            {
                reply = new JsonObject
                {
                    ["ShowAvailableUpdates"] = new JsonObject
                    {
                        ["serviceID"] = "SRV12921",
                        ["serviceVersion"] = type.Version,
                        ["ApplicationArea"] = new JsonObject { ["Sender"] = new JsonObject { ["LogicalID"] = "SWBRKDWN" }, ["CreationDateTime"] = DateTimeOffset.UtcNow.ToString("O"), ["BODID"] = body?["GetAvailableUpdates"]?["ApplicationArea"].S("BODID") ?? "" },
                        ["DataArea"] = new JsonObject { ["Show"] = new JsonObject { ["ResponseCriteria"] = "Rejected", ["StatusCode"] = code.ToString(System.Globalization.CultureInfo.InvariantCulture), ["StatusText"] = text } },
                    },
                };
            }

            return new ListenerReply(reply.ToJsonString(Indented), ListenerReply.JsonText, [notice], [new ListenerFact("Outcome", $"Rejected with {code}.")]);
        }
    }
}
