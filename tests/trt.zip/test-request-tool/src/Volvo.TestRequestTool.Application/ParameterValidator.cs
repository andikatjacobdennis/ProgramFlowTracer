using System.Globalization;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Application
{
    public sealed class ParameterValidator : IProductValidator
    {
        public string Name => "parameters";
        public int Order => 40;

        public ValueTask<IReadOnlyList<ValidationIssue>> ValidateAsync(ValidationContext context, CancellationToken ct)
        {
            var definitions = context.Catalog.Data["paramDefs"];
            var issues = new List<ValidationIssue>();
            var keys = new HashSet<string>();
            foreach (var p in context.Proposal.Parameters.Objects())
            {
                ct.ThrowIfCancellationRequested();
                var key = p.I("electricalArchitecture") + ":" + p.S("code");
                if (!keys.Add(key))
                {
                    issues.Add(new("duplicate_parameter", "Parameter codes must be unique per architecture."));
                }

                var def = definitions?[key];
                if (def is null)
                {
                    issues.Add(new("parameter_contract_unknown", "No catalog definition exists for parameter " + p.S("code"), 1));
                    continue;
                }
                if (def.S("kind") == "function")
                {
                    continue;
                }

                foreach (var r in p.A("references").Objects())
                {
                    var value = r.S("value");
                    var valid = def.S("kind") switch
                    {
                        "int" => int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var n) && n >= def.I("min", int.MinValue) && n <= def.I("max", int.MaxValue),
                        "bool" => value is "0" or "1" or "true" or "false",
                        "enum" => def.A("values").Any(v => v?.ToString() == value),
                        _ => true
                    };
                    if (!valid)
                    {
                        issues.Add(new("parameter_value_invalid", $"Parameter {p.S("code")} has an invalid value for reference {r.S("code")}.", 0));
                    }
                }
                if (p.A("references").Count == 0)
                {
                    issues.Add(new("parameter_value_required", "Parameter " + p.S("code") + " requires a value."));
                }
            }
            return ValueTask.FromResult<IReadOnlyList<ValidationIssue>>(issues);
        }
    }
}
