using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// For a future version only; not implemented or registered. An executor would run one accepted agent action, and only
    /// through the existing workflows: the caller's authorisation, a fresh validation and the approval rules. It must refuse
    /// anything the person could not do themselves, and record every execution in the audit log.
    /// </summary>
    public interface IAgentActionExecutor
    {
        Task<JsonObject> ExecuteAsync(AgentProposedAction action, Actor actor, string approvalReference, CancellationToken ct);
    }
}
