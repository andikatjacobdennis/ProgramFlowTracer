using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    public interface IWorkspaceStore
    {
        // People (the repository's users collection).
        Task<IReadOnlyList<UserAccount>> UsersAsync(CancellationToken ct);
        Task<UserAccount?> UserAsync(string id, CancellationToken ct);
        Task<UserAccount> SaveUserAsync(UserAccount user, CancellationToken ct);
        // Sessions: one record per sign-in, removed by signing out (and dropped once expired).
        Task<SessionRecord?> SessionAsync(string id, CancellationToken ct);
        Task SaveSessionAsync(SessionRecord session, CancellationToken ct);
        Task<bool> EndSessionAsync(string id, CancellationToken ct);

        Task<IReadOnlyList<VersionedProduct>> VehiclesAsync(CancellationToken ct);
        Task<VersionedProduct?> VehicleAsync(string id, CancellationToken ct);
        /// <summary>The vehicle as first imported into the repository, before any commit; null when it was never imported.</summary>
        Task<JsonObject?> OriginalAsync(string id, CancellationToken ct);
        /// <summary>Replaces the vehicle snapshot. The note records who made the change and why in the vehicle's revision history.</summary>
        Task<VersionedProduct> UpdateVehicleAsync(string id, JsonObject product, long expectedRevision, CancellationToken ct, RevisionNote? note = null);
        /// <summary>Committed revisions of one vehicle, oldest first. Revisions loaded from the catalog are not included.</summary>
        Task<IReadOnlyList<VehicleRevision>> RevisionsAsync(string id, CancellationToken ct);
        /// <summary>Kits whose changes include this vehicle, from every user.</summary>
        Task<IReadOnlyList<Kit>> KitsForVehicleAsync(string id, CancellationToken ct);
        /// <summary>This user's requests that included the vehicle, newest first.</summary>
        Task<IReadOnlyList<ExecutionRecord>> ExecutionsForVehicleAsync(string vehicleId, string actorId, CancellationToken ct);
        Task SaveExecutionAsync(ExecutionRecord record, CancellationToken ct);
        Task<ExecutionRecord?> ExecutionAsync(Guid id, string actorId, CancellationToken ct);
        Task<IReadOnlyList<ExecutionRecord>> HistoryAsync(string actorId, int skip, int take, CancellationToken ct);
        /// <summary>Requests created since a time, newest first: one person's, or everyone's when actorId is null (aggregated reports for administrators).</summary>
        Task<IReadOnlyList<ExecutionRecord>> ExecutionsSinceAsync(string? actorId, DateTimeOffset since, int take, CancellationToken ct);
        Task<Draft?> DraftAsync(string id, string actorId, CancellationToken ct);
        Task<Draft> SaveDraftAsync(string id, string actorId, JsonObject state, long? expectedVersion, CancellationToken ct);
        Task<Kit> SaveKitAsync(Kit kit, CancellationToken ct);
        Task<FeedbackItem> SaveFeedbackAsync(FeedbackItem item, CancellationToken ct);
        /// <summary>Feedback newest first; actorId null returns everyone's (for administrators).</summary>
        Task<IReadOnlyList<FeedbackItem>> FeedbackAsync(string? actorId, CancellationToken ct);
        Task<FeedbackItem?> SetFeedbackStatusAsync(Guid id, string status, CancellationToken ct);

        // Proposal revisions (FR-05): append-only per owner and proposal.
        /// <summary>Revisions newest first, without their state.</summary>
        Task<IReadOnlyList<ProposalRevision>> ProposalRevisionsAsync(string ownerId, string proposalId, CancellationToken ct);
        Task<ProposalRevision?> ProposalRevisionAsync(string ownerId, string proposalId, int number, CancellationToken ct);
        /// <summary>
        /// Adds a revision. expectedLatest is the revision the client edited: when another save came first this throws 409
        /// (proposal_conflict) and nothing is written. Saving the same content as the latest revision returns the latest.
        /// </summary>
        Task<ProposalRevision> AddProposalRevisionAsync(ProposalRevision revision, int? expectedLatest, CancellationToken ct);

        // Jobs (FR-07, FR-34, FR-38, FR-39, FR-45).
        /// <summary>Stores a new job (Version 1). Throws 409 when a job with the same id exists.</summary>
        Task<JobRecord> SaveJobAsync(JobRecord job, CancellationToken ct);
        /// <summary>
        /// Atomically moves a job from one status to another (FR-38): the change applies only when the job is still at
        /// expectedVersion and the move is allowed, otherwise 409 and nothing changes. Returns the stored job.
        /// </summary>
        Task<JobRecord> TransitionJobAsync(Guid id, long expectedVersion, string toStatus, Func<JobRecord, JobRecord> change, CancellationToken ct);
        /// <summary>
        /// Claims the next job for a worker with a lease (FR-39, FR-45): an expired lease first, then queued jobs, interactive
        /// before batch (batch jobs waiting longer than batchAging go first), and among those the user with the fewest running
        /// jobs. allowBatch false keeps a worker free for interactive work. Null when there is nothing to do.
        /// </summary>
        Task<JobRecord?> ClaimJobAsync(string workerId, TimeSpan lease, bool allowBatch, TimeSpan batchAging, CancellationToken ct);
        /// <summary>Extends a lease. False when the worker no longer owns the job (it expired and was taken over).</summary>
        Task<bool> RenewLeaseAsync(Guid id, string workerId, TimeSpan lease, CancellationToken ct);
        Task<(int Queued, int Running, int QueuedForActor, DateTimeOffset? OldestQueued)> JobLoadAsync(string actorId, CancellationToken ct);
        Task<JobRecord?> JobAsync(Guid id, CancellationToken ct);
        Task<JobRecord?> JobByKeyAsync(string actorId, string idempotencyKey, CancellationToken ct);
        Task<IReadOnlyList<JobRecord>> JobsAsync(string? actorId, int take, CancellationToken ct);

        // Organisation settings, versioned (FR-79).
        Task<SettingVersion?> SettingAsync(string key, CancellationToken ct);
        Task<IReadOnlyList<SettingVersion>> SettingHistoryAsync(string key, CancellationToken ct);
        Task<SettingVersion> SaveSettingAsync(string key, JsonObject value, string actorId, string actorName, string? note, CancellationToken ct);

        // Batch runs (FR-11).
        Task<BatchRecord> SaveBatchAsync(BatchRecord batch, CancellationToken ct);
        Task<BatchRecord?> BatchAsync(Guid id, CancellationToken ct);
        Task<IReadOnlyList<BatchRecord>> BatchesAsync(string? actorId, int take, CancellationToken ct);

        // Campaigns: one change across many vehicles.
        /// <summary>Saves a campaign. expectedVersion null creates it; otherwise the stored version must match (409 campaign_conflict).</summary>
        Task<CampaignRecord> SaveCampaignAsync(CampaignRecord campaign, long? expectedVersion, CancellationToken ct);
        Task<CampaignRecord?> CampaignAsync(Guid id, CancellationToken ct);
        Task<IReadOnlyList<CampaignRecord>> CampaignsAsync(CancellationToken ct);

        // Reviews, approvals and submissions (FR-06, FR-57).
        /// <summary>Saves a review. expectedVersion null creates it (409 if one exists for the id); otherwise the stored version must match (409 review_conflict).</summary>
        Task<ReviewRecord> SaveReviewAsync(ReviewRecord review, long? expectedVersion, CancellationToken ct);
        Task<ReviewRecord?> ReviewAsync(Guid id, CancellationToken ct);
        /// <summary>The newest review of a validation request, or null.</summary>
        Task<ReviewRecord?> ReviewForRequestAsync(Guid requestId, CancellationToken ct);
        Task<IReadOnlyList<ReviewRecord>> ReviewsAsync(int take, CancellationToken ct);

        // Operational pauses (FR-76).
        Task<IReadOnlyList<PauseRecord>> PausesAsync(CancellationToken ct);
        Task<PauseRecord> SetPauseAsync(PauseRecord pause, CancellationToken ct);
        Task<bool> ClearPauseAsync(string scope, CancellationToken ct);

        // Protected audit log (FR-19): append-only and hash-chained.
        Task<AuditEntry> AppendAuditAsync(string actorId, string actorName, string action, string target, JsonObject? details, CancellationToken ct);
        Task<IReadOnlyList<AuditEntry>> AuditAsync(int skip, int take, CancellationToken ct);
        /// <summary>Recomputes the chain. Returns the number of entries checked and the first broken sequence, if any.</summary>
        Task<(int Checked, long? BrokenAt)> VerifyAuditAsync(CancellationToken ct);
    }
}
