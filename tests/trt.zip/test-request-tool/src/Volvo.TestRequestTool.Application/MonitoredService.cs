namespace Volvo.TestRequestTool.Application
{
    /// <summary>A monitored service. Simulated services stand in for external systems that are not connected.</summary>
    public sealed record MonitoredService(string Id, string Name, string Kind, bool Simulated, double BaseMs, double Reliability, string[] DependsOn, string Description);
}
