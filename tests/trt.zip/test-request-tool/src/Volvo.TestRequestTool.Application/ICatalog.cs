using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Application
{
    public interface ICatalog
    {
        JsonObject Data { get; }
        JsonObject? FindTemplate(JsonObject node);
        IReadOnlyList<JsonObject> Templates(int context);
        JsonObject? FindVersion(JsonObject node);
    }
}
