namespace Volvo.TestRequestTool.Application
{
    /// <summary>Structured assistant errors. Retryable tells the interface whether a retry can help.</summary>
    public sealed record AssistantError(string Code, string Message, bool Retryable);
}
