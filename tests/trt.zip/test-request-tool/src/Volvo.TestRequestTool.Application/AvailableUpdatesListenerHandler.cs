using System.Text.Json.Nodes;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// GetAvailableUpdates 1.3 and 2.1 (Request.Listener/Aftermarket/AvailableUpdates_1_3 and _2_1): per action criterion, what
    /// is available for the requested nodes (all nodes when none are requested).
    /// <list type="bullet">
    /// <item>SoftwareReplacements.CurrentSoftware: each node's current node template, and whether newer software exists.</item>
    /// <item>SoftwareReplacements.General and the Remote criteria: per node, the newest version the scenario allows and the
    /// hardware takes (remote: one that can be downloaded remotely), the nodes it brings along, and its release note.</item>
    /// <item>SoftwareReplacements.ServicePack…: the nodes the newest service pack of the vehicle context moves forward.</item>
    /// <item>HardwareReplacements: the other hardware the newest version of each node runs on.</item>
    /// <item>The kit criteria: the catalog's kits of that type that apply to the vehicle, with the nodes they assign and remove.</item>
    /// </list>
    /// A criterion that cannot be answered (DisplayLanguages: the catalog has no language data) makes the reply Modified, with
    /// the reason in StatusText, as the listener does; when nothing can be answered it is Rejected.
    /// </summary>
    public sealed class AvailableUpdatesListenerHandler : ListenerXmlHandler
    {
        // The criteria in the listener's order (its flag values), and the names its Kits elements use.
        private static readonly string[] Order =
        [
            "SoftwareReplacements.CurrentSoftware", "SoftwareReplacements.General", "SoftwareReplacements.RemoteCapable", "SoftwareReplacements.RemoteLimited",
            "SoftwareReplacements.RemoteGeneral", "HardwareReplacements", "DisplayLanguages", "AccessoryKits", "ServiceKits", "AdministrativeServiceKits",
            "CampaignKits", "HardwareKits", "SoftwareReplacements.ServicePackGeneral", "SoftwareReplacements.ServicePackRemoteGeneral",
            "SoftwareReplacements.ServicePackRemoteLimited", "SoftwareReplacements.ServicePackRemoteCapable",
            "RemoteAccessoryKits", "RemoteServiceKits", "RemoteAdministrativeServiceKits", "RemoteCampaignKits", "RemoteHardwareKits",
        ];

        private readonly ListenerProducts _products;
        private readonly ListenerCatalog _catalog;

        public AvailableUpdatesListenerHandler(ListenerProducts products, ListenerCatalog catalog, TimeProvider clock) : base(clock)
        {
            _products = products;
            _catalog = catalog;
        }

        public override IReadOnlyCollection<string> Keys { get; } = ["GetAvailableUpdates_1.3", "GetAvailableUpdates_2.1"];

        private static XNamespace Ns(ListenerMessageType type) => "http://www.volvo.com/AvailableUpdates/" + type.Version.Replace('.', '_');

        private static (string Id, string Version) Service(ListenerMessageType type) => type.Version == "2.1" ? ("SRV12921", "2.1") : ("SRV12008", "1.3");

        protected override async Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct)
        {
            var ns = Ns(message.Type);
            var v21 = message.Type.Version == "2.1";
            var data = ListenerXml.Find(message.Xml, "DataArea");
            var criteria = ListenerXml.Child(data, "Criteria");
            var asked = (v21 ? ListenerXml.Attribute(criteria, "actionCriteria") : ListenerXml.Text(ListenerXml.Child(data, "Get"), "ActionCriteria")) ?? "";
            var tokens = asked.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Distinct().ToList();
            if (tokens.Count == 0)
            {
                throw ListenerFault.Undefined("No action criteria were given.");
            }

            var unknown = tokens.FirstOrDefault(t => !Order.Contains(t) || (!v21 && t.StartsWith("Remote", StringComparison.Ordinal)));
            if (unknown is not null)
            {
                throw ListenerFault.Undefined($"Requested value '{unknown}' was not found.");
            }

            var scenario = ListenerCatalog.Scenario(ListenerXml.Attribute(criteria, "scenario"));
            var pbl = ListenerXml.Flag(ListenerXml.Attribute(criteria, "pblUpdateCapable"));
            var multi = ListenerXml.Attribute(criteria, "enableMultiNodeBehavior") is not { } m || ListenerXml.Flag(m);
            var language = ListenerXml.Attribute(criteria, "languageCode") ?? "en-US";
            var withSource = v21 && ListenerXml.Flag(ListenerXml.Attribute(criteria, "includeReleaseNoteSource"));
            var products = new List<ListenerProduct>();
            foreach (var element in ListenerXml.Children(data, "Product"))
            {
                products.Add(await _products.ReadAsync(element, message.Actor, ct));
            }

            var requested = ListenerXml.Children(ListenerXml.Child(data, "RequestedNodes"), "Node").ToList();
            var summary = products.Select(p => p.Source).ToList();
            var byNode = new List<XElement>();
            var replacements = new List<XElement>();
            XElement? hardware = null;
            var kits = new List<XElement>();
            var failures = new List<string>();
            foreach (var token in Order.Where(tokens.Contains))
            {
                switch (token)
                {
                    case "SoftwareReplacements.CurrentSoftware":
                        replacements.Add(new XElement(ns + "SoftwareNodeReplacements", new XAttribute("actionCriteria", token),
                            new XElement(ns + "AssignedNodes", products.SelectMany(p => Nodes(p, requested, v21).Select(n => Current(ns, v21, p, n, scenario, pbl))))));
                        summary.Add(new ListenerFact(token, "The current node templates, and whether newer software exists."));
                        break;
                    case "SoftwareReplacements.General" or "SoftwareReplacements.RemoteCapable" or "SoftwareReplacements.RemoteLimited" or "SoftwareReplacements.RemoteGeneral":
                        var remote = token != "SoftwareReplacements.General";
                        var changes = new List<string>();
                        byNode.Add(new XElement(ns + "SoftwareNodeByNodeReplacements", new XAttribute("actionCriteria", token),
                            products.SelectMany(p => Nodes(p, requested, v21).Select(n => Replacement(ns, v21, p, n, scenario, remote, pbl, multi, language, withSource, changes))).ToList()));
                        summary.Add(new ListenerFact(token, changes.Count == 0 ? "No newer software." : "Newer software: " + string.Join(", ", changes) + "."));
                        break;
                    case "HardwareReplacements":
                        hardware = new XElement(ns + "HardwareNodeReplacements", products.SelectMany(p => Nodes(p, requested, v21).Select(n => HardwareReplacement(ns, v21, p, n))).Where(x => x is not null));
                        summary.Add(new ListenerFact(token, $"{hardware.Elements().Count()} node(s) with other hardware to choose."));
                        break;
                    case "DisplayLanguages":
                        failures.Add($"ActionCriteria '{token}' failed: the catalog has no display language data.");
                        break;
                    case var pack when pack.StartsWith("SoftwareReplacements.ServicePack", StringComparison.Ordinal):
                        var sp = ServicePack(ns, v21, products, token, out var packText);
                        if (sp is null)
                        {
                            failures.Add($"ActionCriteria '{token}' failed: {packText}");
                        }
                        else
                        {
                            replacements.Add(sp);
                            summary.Add(new ListenerFact(token, packText));
                        }

                        break;
                    default:
                        kits.Add(Kits(ns, v21, products, token, scenario, out var kitText));
                        summary.Add(new ListenerFact(token, kitText));
                        break;
                }
            }

            var answered = byNode.Count + replacements.Count + kits.Count + (hardware is null ? 0 : 1);
            var show = failures.Count == 0 ? ListenerXml.Accepted(ns, string.Empty)
                : answered > 0 ? ListenerXml.Show(ns, "Modified", "1", string.Join(", ", failures))
                : ListenerXml.Show(ns, "Rejected", "-1", string.Join(", ", failures));
            var (id, version) = Service(message.Type);
            var root = ListenerXml.Bod(ns, "ShowAvailableUpdates", id, version, ListenerXml.Transaction(message.Xml), Clock, show, byNode, replacements, hardware, kits);
            summary.Insert(0, new ListenerFact("Outcome", failures.Count == 0 ? "Accepted." : answered > 0 ? "Modified: " + string.Join(" ", failures) : "Rejected: " + string.Join(" ", failures)));
            return new ListenerAnswer(root, summary, failures.Select(ListenerNotice.Warning).ToList());
        }

        protected override XElement Error(ListenerMessage message, ListenerNotice notice, string bodId)
        {
            var (id, version) = Service(message.Type);
            return ListenerXml.Bod(Ns(message.Type), "ShowAvailableUpdates", id, version, bodId, Clock, ListenerXml.Rejected(Ns(message.Type), notice));
        }

        public override XDocument Example(ListenerMessageType type, ProductDocument vehicle)
        {
            var ns = Ns(type);
            const string Asked = "SoftwareReplacements.CurrentSoftware,SoftwareReplacements.General,HardwareReplacements,AccessoryKits,ServiceKits,CampaignKits";
            var criteria = new XElement(ns + "Criteria",
                type.Version == "2.1" ? new XAttribute("actionCriteria", Asked + ",SoftwareReplacements.ServicePackGeneral") : null,
                new XAttribute("scenario", "Introduced"), new XAttribute("languageCode", "en-GB"), new XAttribute("pblUpdateCapable", "true"));

            return Document(new XElement(ns + "GetAvailableUpdates",
                ListenerXml.RequestArea(Clock),
                new XElement(ns + "DataArea",
                    type.Version == "2.1" ? null : new XElement(ns + "Get", new XElement(ListenerXml.Volvo + "ActionCriteria", Asked)),
                    criteria,
                    ListenerProducts.ProductElement(ns, "Product", vehicle))));
        }

        /// <summary>The product's nodes the request asks about: all of them when it names none (2.1 also by chassis).</summary>
        private static IEnumerable<JsonObject> Nodes(ListenerProduct product, List<XElement> requested, bool v21)
        {
            var nodes = product.Product.Nodes.Objects().ToList();
            if (requested.Count == 0)
            {
                return nodes;
            }

            var mine = requested.Where(r => !v21 || ListenerProducts.Series(ListenerXml.Attribute(r, "chassisSeries") ?? "") == product.ChassisSeries && ListenerProducts.Number(ListenerXml.Attribute(r, "chassisNumber") ?? "") == product.ChassisNumber).ToList();
            foreach (var r in mine)
            {
                if (!nodes.Any(n => ListenerCatalog.Matches(r, n)))
                {
                    throw ListenerFault.RequestedNode($"A requested node is not in product {product.Shown}.");
                }
            }

            return nodes.Where(n => mine.Any(r => ListenerCatalog.Matches(r, n)));
        }

        private XElement Current(XNamespace ns, bool v21, ListenerProduct p, JsonObject node, int scenario, bool pbl)
        {
            var template = _catalog.Template(node);
            var current = template is null ? null : ListenerCatalog.Current(template, node);
            var latest = template is null ? null : ListenerCatalog.Latest(template, node, scenario, false, pbl);
            return Detailed(ns, v21, p, node, current, latest is null || current is null || latest.I("idx") == current.I("idx"));
        }

        private XElement Replacement(XNamespace ns, bool v21, ListenerProduct p, JsonObject node, int scenario, bool remote, bool pbl, bool multi, string language, bool withSource, List<string> changes)
        {
            var template = _catalog.Template(node);
            var current = template is null ? null : ListenerCatalog.Current(template, node);
            var target = template is null ? null : ListenerCatalog.Latest(template, node, scenario, remote, pbl);
            var newer = target is not null && (current is null || target.I("idx") > current.I("idx"));
            if (newer)
            {
                changes.Add($"{ListenerCatalog.Name(node)} {current.S("versionName")} → {target.S("versionName")}".Replace("  ", " ", StringComparison.Ordinal));
            }

            var assigned = new List<XElement>();
            if (newer && multi)
            {
                foreach (var key in target!.A("requires").Objects().Select(r => r.S("key")))
                {
                    var other = p.Product.Nodes.Objects().FirstOrDefault(n => _catalog.Template(n)?.S("key") == key);
                    var otherTemplate = other is null ? null : _catalog.Template(other);
                    var otherTarget = otherTemplate is null ? null : ListenerCatalog.Latest(otherTemplate, other!, scenario, remote, pbl);
                    if (otherTarget is not null)
                    {
                        assigned.Add(Detailed(ns, v21, p, other!, otherTarget, ListenerCatalog.Current(otherTemplate!, other!)?.I("idx") == otherTarget.I("idx")));
                    }
                }
            }

            var note = newer ? ListenerCatalog.ReleaseNote(target, language) : null;
            return new XElement(ns + "SoftwareNodeReplacement",
                Detailed(ns, v21, p, node, newer ? target : current, !newer),
                new XElement(ns + "AssignedNodes", assigned),
                note is null ? null : new XElement(ns + "ReleaseNotes", ReleaseNote(template!, target!, note, withSource ? ListenerCatalog.NodeId(ReleaseNotesHandler.Rn, node) : null)));
        }

        private static XElement ReleaseNote(JsonObject template, JsonObject version, string text, XElement? node) =>
            new(ReleaseNotesHandler.Rn + "ReleaseNote",
                new XAttribute("id", ListenerCatalog.ReleaseNoteId(template, version)),
                new XAttribute("releaseNote", text),
                node is null ? null : new XElement(ReleaseNotesHandler.Rn + "Source", new XElement(ReleaseNotesHandler.Rn + "Nodes", new XElement(ReleaseNotesHandler.Rn + "Node", node))));

        private XElement? HardwareReplacement(XNamespace ns, bool v21, ListenerProduct p, JsonObject node)
        {
            var template = _catalog.Template(node);
            var newest = template is null ? null : ListenerCatalog.Versions(template).LastOrDefault(v => SoftwareHandler.Allowed(v, 1));
            var parts = ListenerCatalog.CompatibleHardware(newest, node).Select(h => h.Compatible).Distinct().ToList();
            if (parts.Count == 0)
            {
                return null;
            }

            return new XElement(ns + "HardwareNodeReplacement", Chassis(v21, p),
                ListenerCatalog.NodeId(ns, node),
                new XElement(ns + "HardwarePartNumbers", parts.Select(h => new XElement(ns + "HardwarePartNumber", ListenerXml.PartNumber(h)))));
        }

        private XElement? ServicePack(XNamespace ns, bool v21, List<ListenerProduct> products, string token, out string text)
        {
            var remote = token != "SoftwareReplacements.ServicePackGeneral";
            var assigned = new List<XElement>();
            JsonObject? pack = null;
            foreach (var p in products)
            {
                pack = _catalog.Catalog.Data.A("servicePacks").Objects().Where(x => x.I("contextId") == p.Product.ContextId).OrderByDescending(x => x.I("sortOrder")).FirstOrDefault();
                if (pack is null)
                {
                    text = $"no service pack exists for the vehicle context of {p.Shown}.";
                    return null;
                }

                foreach (var node in p.Product.Nodes.Objects())
                {
                    var template = _catalog.Template(node);
                    var index = template is null ? -1 : pack["ntps"].I(template.S("key"), -1);
                    var version = index < 0 ? null : ListenerCatalog.Versions(template!).FirstOrDefault(v => v.I("idx") == index);
                    var current = template is null ? null : ListenerCatalog.Current(template, node);
                    if (version is null || (current is not null && current.I("idx") >= index) || (remote && !version.B("remoteCapable")))
                    {
                        continue;
                    }

                    assigned.Add(Detailed(ns, v21, p, node, version, false));
                }
            }

            text = $"{pack.S("name")}: {assigned.Count} node(s) to update.";
            return new XElement(ns + "SoftwareNodeReplacements", new XAttribute("actionCriteria", token),
                new XElement(ns + "AssignedNodes", assigned),
                new XElement(ns + "ServicePack", new XAttribute("name", pack.S("name")), new XAttribute("guid", pack.S("guid").ToUpperInvariant())));
        }

        private XElement Kits(XNamespace ns, bool v21, List<ListenerProduct> products, string token, int scenario, out string text)
        {
            var remoteOnly = token.StartsWith("Remote", StringComparison.Ordinal);
            var type = token.Replace("Remote", "", StringComparison.Ordinal) switch
            {
                "AccessoryKits" => "Accessory",
                "ServiceKits" => "Service",
                "CampaignKits" => "Campaign",
                _ => null,
            };
            var found = new List<XElement>();
            var names = new List<string>();
            foreach (var p in products)
            {
                foreach (var kit in _catalog.Kits.Where(k => type is not null && ListenerCatalog.KitType(k) == type).OrderBy(k => k.I("partNumber")))
                {
                    KitResult result;
                    try
                    {
                        result = _catalog.ApplyKit(p.Product, kit.I("partNumber"), scenario, serviceKitsOnly: false);
                    }
                    catch (ListenerFault)
                    {
                        continue;
                    }

                    var remote = result.Assigned.Count > 0 && result.Assigned.All(a => _catalog.Catalog.FindVersion(a.Node).B("remoteCapable"));
                    if (remoteOnly && !remote)
                    {
                        continue;
                    }

                    names.Add($"{kit.S("partNumber")} {kit.S("name")}");
                    found.Add(new XElement(ns + "Kit",
                        new XAttribute("partNumber", ListenerXml.PartNumber(kit.I("partNumber"))),
                        new XAttribute("name", kit.S("name")),
                        new XAttribute("isAvailableRemote", remote ? "true" : "false"),
                        Chassis(v21, p),
                        new XAttribute("affectsSoftware", result.Assigned.Count > 0 ? "true" : "false"),
                        new XAttribute("hardwareNonControlUnitChangeNeeded", "false"),
                        result.Assigned.Count == 0 ? null : new XElement(ns + "AssignedNodes", result.Assigned.Select(a => AssignedNode(ns, v21, p, a))),
                        result.Removed.Count == 0 ? null : new XElement(ns + "RemovedNodes", result.Removed.Select(r => new XElement(ns + "Node", Chassis(v21, p), ListenerCatalog.NodeId(ns, r))))));
                }
            }

            text = type is null ? "The catalog has no kits of this kind." : names.Count == 0 ? "No kit applies." : string.Join(", ", names) + ".";
            return new XElement(ns + "Kits", new XAttribute("actionCriteria", token), found);
        }

        private static XElement AssignedNode(XNamespace ns, bool v21, ListenerProduct p, KitNode a)
        {
            var flags = new object?[]
            {
                new XElement(ns + "HardwareChangeNeeded", a.HardwareChangeNeeded ? "true" : "false"),
                a.SerialNumberInputNeeded ? new XElement(ns + "SerialNumberInputNeeded", "true") : null,
            };
            var id = ListenerCatalog.NodeId(ns, a.Node, "AssignedNodeName", "MID");
            var choice = id.Name.LocalName == "MID" ? new XElement(ns + "AssignedMID", id, flags) : new XElement(id.Name, id.Attributes(), flags);
            return new XElement(ns + "Node", Chassis(v21, p), choice);
        }

        private static XElement Detailed(XNamespace ns, bool v21, ListenerProduct p, JsonObject node, JsonObject? version, bool same)
        {
            var hardware = ListenerCatalog.CompatibleHardware(version, node).ToList();
            return new XElement(ns + "Node",
                Chassis(v21, p),
                version.I("doc") > 0 ? new XAttribute("nodeTemplateDocumentNumber", ListenerXml.PartNumber(version.I("doc"))) : null,
                new XAttribute(v21 ? "isSoftwareSame" : "IsSoftwareSame", same ? "true" : "false"),
                new XAttribute("nodeTemplateStatus", ListenerCatalog.Status(version)),
                new XAttribute("remoteSWDLAvailability", ListenerCatalog.Remote(version)),
                ListenerCatalog.NodeId(ns, node),
                hardware.Count == 0 ? null : new XElement(ns + "CompatibleHardwares", hardware.Select(h => new XElement(ns + "CompatibleHardware", new XAttribute("partNumber", ListenerXml.PartNumber(h.PartNumber)), new XAttribute("compatiblePartNumber", ListenerXml.PartNumber(h.Compatible))))));
        }

        private static object[] Chassis(bool v21, ListenerProduct p) => v21 ? [new XAttribute("chassisSeries", p.ChassisSeries), new XAttribute("chassisNumber", p.ChassisNumber)] : [];
    }
}
