using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Application
{
    public sealed class VariantValidator : IProductValidator
    {
        public string Name => "variants";
        public int Order => 45;

        public ValueTask<IReadOnlyList<ValidationIssue>> ValidateAsync(ValidationContext context, CancellationToken ct)
        {
            var issues = new List<ValidationIssue>();
            var families = new HashSet<string>();
            var catalog = context.Catalog.Data.A("variants").Objects().ToArray();
            foreach (var v in context.Proposal.Data["productSpecification"]!.A("variants").Objects())
            {
                ct.ThrowIfCancellationRequested();
                var known = catalog.FirstOrDefault(k => k.S("idVar6") == v.S("idVar6") || k.S("symbol") == v.S("symbol"));
                if (known is null)
                {
                    issues.Add(new("variant_unknown", "Variant " + v.S("symbol") + " is not in the catalog."));
                    continue;
                }
                if (!known.A("authorizedProductClasses").Any(x => x?.ToString() == context.Proposal.Info.S("productClassId")))
                {
                    issues.Add(new("variant_product_class", "Variant " + known.S("symbol") + " is not allowed for this product class."));
                }

                if (known.S("familyType") != "E" && !families.Add(known.S("familyId")))
                {
                    issues.Add(new("variant_family_conflict", "Multiple variants were selected in family " + known.S("familyId")));
                }
            }
            return ValueTask.FromResult<IReadOnlyList<ValidationIssue>>(issues);
        }
    }
}
