using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// Where the repository keeps its documents: one JSON object per record, grouped in collections ("vehicles", "requests",
    /// "users", ...). A key may contain "/" to group records ("drafts/alice/d1"). Providers: files (JSON or XML) now; a
    /// database provider implements this interface and is chosen with the setting Repository:Provider.
    /// </summary>
    public interface IDocumentStore
    {
        /// <summary>For people, for example "Files (JSON, XML) in" and the folder.</summary>
        string Description { get; }
        /// <summary>Every document of a collection, including grouped keys, in no particular order.</summary>
        Task<IReadOnlyList<StoredDocument>> ListAsync(string collection, CancellationToken ct);
        Task<JsonObject?> GetAsync(string collection, string key, CancellationToken ct);
        /// <summary>Creates or replaces one document atomically: readers see the old or the new document, never part of one.</summary>
        Task PutAsync(string collection, string key, JsonObject document, CancellationToken ct);
        Task<bool> DeleteAsync(string collection, string key, CancellationToken ct);
    }
}
