using System.Text.Json.Nodes;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// ESW_CONVERSION_KIT_REQUEST 2.1, 3.0 and 3.1 (Request.Listener/Aftermarket/KitRequest_2_1, _3_0, _3_1): the requested kits
    /// applied to each product by the tool's ConversionKitHandler (the same rules as a kit request on the Requests pages:
    /// the kit's product classes, its state under the scenario, service kits only). 2.1 answers ProductUpdate 2.1 for the
    /// product; 3.0 and 3.1 answer ProductsUpdate 1.0 and 1.1, one ProductUpdate per product.
    /// </summary>
    public sealed class ConversionKitListenerHandler : ListenerXmlHandler
    {
        private readonly ListenerProducts _products;
        private readonly ListenerCatalog _catalog;
        private readonly ConversionKitHandler _kits;
        private readonly ProductsUpdateWriter _writer;

        public ConversionKitListenerHandler(ListenerProducts products, ListenerCatalog catalog, TimeProvider clock) : base(clock)
        {
            _products = products;
            _catalog = catalog;
            _kits = new ConversionKitHandler(catalog.Catalog);
            _writer = new ProductsUpdateWriter(catalog.Catalog);
        }

        public override IReadOnlyCollection<string> Keys { get; } = ["ESW_CONVERSION_KIT_REQUEST_2.1", "ESW_CONVERSION_KIT_REQUEST_3.0", "ESW_CONVERSION_KIT_REQUEST_3.1"];

        private static XNamespace RequestNs(ListenerMessageType type) => "http://www.volvo.com/KitRequest/" + type.Version.Replace('.', '_');

        /// <summary>The reply: its namespace, root, service id and version.</summary>
        private static (XNamespace Ns, string Root, string Id, string Version) Reply(ListenerMessageType type) => type.Version switch
        {
            "2.1" => ("http://www.volvo.com/ProductUpdate/2_1", "ProductUpdate", "SRV11918", "2.1"),
            "3.0" => ("http://www.volvo.com/ProductsUpdate/1_0", "ProductsUpdate", "SRV12422", "3.0"),
            _ => ("http://www.volvo.com/ProductsUpdate/1_1", "ProductsUpdate", "SRV12926", "3.1"),
        };

        protected override async Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct)
        {
            var data = ListenerXml.Find(message.Xml, "DataArea");
            var criteria = ListenerXml.Child(data, "Criteria");
            var scenario = ListenerCatalog.Scenario(ListenerXml.Attribute(criteria, "scenario"));
            var serviceOnly = ListenerXml.Flag(ListenerXml.Attribute(criteria, "allowServiceKitsOnly"));
            var kitAttribute = message.Type.Version == "3.1" ? "partNumber" : "kitPartNumber";
            var requested = ListenerXml.Children(ListenerXml.Child(data, "RequestedKits"), "RequestedKit").ToList();
            var (ns, rootName, id, version) = Reply(message.Type);
            var summary = new List<ListenerFact>();
            var updates = new List<XElement>();
            var delta = new List<XElement>();
            foreach (var element in ListenerXml.Children(data, "Product"))
            {
                var product = await _products.ReadAsync(element, message.Actor, ct);
                summary.Add(product.Source);
                var kits = requested.Where(r => ListenerXml.Attribute(r, "chassisSeries") is not { } s || (ListenerProducts.Series(s) == product.ChassisSeries && ListenerProducts.Number(ListenerXml.Attribute(r, "chassisNumber") ?? "") == product.ChassisNumber))
                    .Select(r => long.TryParse(ListenerXml.Attribute(r, kitAttribute), out var n) ? n : 0).Distinct().ToList();
                var payload = new JsonObject
                {
                    ["conversionKitNumbers"] = new JsonArray(kits.Select(k => (JsonNode)new JsonObject { ["conversionKitNumber"] = k.ToString(System.Globalization.CultureInfo.InvariantCulture) }).ToArray()),
                    ["scenario"] = scenario,
                    ["onlyServiceKitAllowed"] = serviceOnly,
                };
                var result = await _kits.HandleAsync(product.Product, payload, ct);
                if (ProductsUpdateWriter.Fault(result.Issues) is { } fault)
                {
                    throw fault;
                }

                summary.Add(new ListenerFact(product.Shown, $"Kits {string.Join(", ", kits.Select(k => ListenerXml.PartNumber(k)))}. {ProductsUpdateWriter.Describe(product.Product, result.Proposal)}"));
                var changes = _writer.Delta(ns, product.Product, result.Proposal, message.Type.Version == "3.1", null).ToList();
                if (message.Type.Version == "2.1")
                {
                    delta = changes;
                    break;
                }

                updates.Add(new XElement(ns + "ProductUpdate", new XAttribute("chassisSeries", product.ChassisSeries), new XAttribute("chassisNumber", product.ChassisNumber), changes));
            }

            var root = ListenerXml.Bod(ns, rootName, id, version, ListenerXml.Transaction(message.Xml), Clock, ListenerXml.Accepted(ns), delta, updates);
            summary.Insert(0, new ListenerFact("Outcome", "Accepted: the kits apply."));
            return new ListenerAnswer(root, summary, []);
        }

        protected override XElement Error(ListenerMessage message, ListenerNotice notice, string bodId)
        {
            var (ns, root, id, version) = Reply(message.Type);
            return ListenerXml.Bod(ns, root, id, version, bodId, Clock, ListenerXml.Rejected(ns, notice));
        }

        public override XDocument Example(ListenerMessageType type, ProductDocument vehicle)
        {
            var ns = RequestNs(type);
            var kit = KitEvaluationHandler.ExampleKit(_catalog, vehicle).First();
            var requestedKit = type.Version switch
            {
                "3.1" => new XElement(ns + "RequestedKit", new XAttribute("partNumber", ListenerXml.PartNumber(kit))),
                "3.0" => new XElement(ns + "RequestedKit", new XAttribute("kitPartNumber", ListenerXml.PartNumber(kit))),
                _ => new XElement(ns + "RequestedKit", new XAttribute("kitPartNumber", kit)),
            };
            return Document(new XElement(ns + "GetKit",
                ListenerXml.RequestArea(Clock),
                new XElement(ns + "DataArea",
                    new XElement(ns + "Criteria", new XAttribute("scenario", "Introduced"), new XAttribute("pblUpdateCapable", "true")),
                    new XElement(ns + "RequestedKits", requestedKit),
                    ListenerProducts.ProductElement(ns, "Product", vehicle))));
        }
    }
}
