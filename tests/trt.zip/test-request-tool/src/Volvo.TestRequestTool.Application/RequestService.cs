using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Application
{
    public sealed class RequestService
    {
        private readonly IWorkspaceStore _store;
        private readonly ICatalog _catalog;
        private readonly IReadOnlyDictionary<RequestKind, IRequestHandler> _handlers;
        private readonly IProductValidator[] _validators;
        private readonly TimeProvider _clock;
        private readonly IRequestEvents? _events;

        public RequestService(IWorkspaceStore store, ICatalog catalog, IEnumerable<IRequestHandler> handlers, IEnumerable<IProductValidator> validators, TimeProvider clock, IRequestEvents? events = null)
        {
            this._store = store;
            this._catalog = catalog;
            this._clock = clock;
            this._events = events;
            this._handlers = handlers.ToDictionary(x => x.Kind);
            this._validators = validators.OrderBy(v => v.Order).ThenBy(v => v.Name, StringComparer.Ordinal).ToArray();
            if (this._validators.Select(v => v.Name).Distinct().Count() != this._validators.Length)
            {
                throw new InvalidOperationException("Validation step names must be unique.");
            }
        }

        /// <summary>
        /// Runs the request for every vehicle and saves the result. Each stage is timed with the monotonic clock
        /// (TimeProvider.GetTimestamp) into an ExecutionTrace: access check and loading, building the proposal (a "service"
        /// stage when the handler called an integration), each rule check and the release notes. Saving is not timed.
        /// The request options without the vehicles are kept so the same validation can be run again (Fleet readiness).
        /// </summary>
        public async Task<ExecutionRecord> ExecuteAsync(Actor actor, RequestCommand command, CancellationToken ct, Guid? executionId = null)
        {
            var origin = _clock.GetTimestamp();
            var stages = new List<TraceStage>();
            double Ms(long from) => _clock.GetElapsedTime(origin, from).TotalMilliseconds;
            void Stage(string id, string name, string kind, long from, string outcome, string? vehicle = null, string? note = null) =>
                stages.Add(new(stages.Count + 1, id, name, kind, Math.Round(Ms(from), 2), Math.Round(_clock.GetElapsedTime(from).TotalMilliseconds, 2), outcome, vehicle, note));
            var t = _clock.GetTimestamp();
            var (handler, products, originals) = await AuthorizeAsync(actor, command, ct);
            Stage("authorise", "Check access and load vehicles", "stage", t, "completed", null, products.Length + " vehicle(s)");
            var outcomes = new List<Outcome>();
            var updates = new JsonArray();
            var services = new JsonArray();
            foreach (var product in products)
            {
                ct.ThrowIfCancellationRequested();
                var baseline = originals[product.Id];
                t = _clock.GetTimestamp();
                var result = await handler.HandleAsync(product, command.Payload, ct);
                var issues = result.Issues.ToList();
                var service = result.ServiceResponse is not null;
                Stage("proposal", service ? "Integration service: " + command.Kind : "Build proposal: " + command.Kind, service ? "service" : "stage", t, issues.Count > 0 ? "warning" : "completed", product.Id, issues.Count > 0 ? issues.Count + " finding(s)" : null);
                foreach (var validator in _validators)
                {
                    t = _clock.GetTimestamp();
                    var found = await validator.ValidateAsync(new ValidationContext(product, result.Proposal, command.Payload, _catalog), ct);
                    issues.AddRange(found);
                    Stage("rule:" + validator.Name, "Rule check: " + validator.Name, "stage", t, found.Count > 0 ? "warning" : "completed", product.Id, found.Count > 0 ? found.Count + " finding(s)" : null);
                }
                t = _clock.GetTimestamp();
                var limited = command.Payload.B("allowLimitedValidation") && issues.Any(x => x.Severity == 0);
                var proposal = issues.Any(x => x.Severity == 0) && !limited ? product.Copy() : result.Proposal;
                var notes = new JsonArray();
                var language = command.Payload.S("selectedLanguageCode", "en-GB");
                foreach (var node in proposal.Nodes.Objects())
                {
                    var previous = product.Nodes.Objects().FirstOrDefault(n => JsonAccess.NodeKeyOf(n) == JsonAccess.NodeKeyOf(node));
                    if (previous?["nodeTemplateDocument"].I("number") == node["nodeTemplateDocument"].I("number"))
                    {
                        continue;
                    }

                    var version = _catalog.FindVersion(node);
                    if (version is not null)
                    {
                        notes.Add(new JsonObject { ["text"] = version["releaseNotes"].S(language, version["releaseNotes"].S("en-GB")), ["source"] = node.S("name") + " - " + version.S("versionName") });
                    }
                }
                outcomes.Add(new(product.Id, (JsonObject)product.Data.DeepClone(), (JsonObject)baseline.Product.DeepClone(), proposal.Data, baseline.Revision, proposal.Fingerprint(), ProductDelta.Between(product, proposal), issues, limited, notes));
                if (result.AvailableUpdates is not null)
                {
                    updates.Add(result.AvailableUpdates.DeepClone());
                }

                if (result.ServiceResponse is not null)
                {
                    services.Add(result.ServiceResponse.DeepClone());
                }

                Stage("result", "Build result and release notes", "stage", t, limited ? "warning" : "completed", product.Id, limited ? "Limited evidence" : null);
            }
            var options = (JsonObject)command.Payload.DeepClone();
            options.Remove("products");
            options.Remove("product");
            var trace = new ExecutionTrace(stages, Math.Round(Ms(_clock.GetTimestamp()), 2));
            var record = new ExecutionRecord(executionId ?? Guid.NewGuid(), actor.Id, command.Kind, _clock.GetUtcNow(), CanonicalJson.Hash(command.Payload), outcomes, updates.Count == 0 ? null : new JsonObject { ["products"] = updates }, services.Count == 0 ? null : new JsonObject { ["products"] = services }, trace, options);
            await _store.SaveExecutionAsync(record, ct);
            _events?.Executed(record, executionId is null ? "api" : "worker");
            return record;
        }

        /// <summary>Contract request(s) a JSON service would receive, built without running validators or persisting anything.</summary>
        public async Task<JsonArray> PreviewAsync(Actor actor, RequestCommand command, CancellationToken ct)
        {
            var (handler, products, _) = await AuthorizeAsync(actor, command, ct);
            var requests = new JsonArray();
            foreach (var product in products)
            {
                var result = await handler.HandleAsync(product, command.Payload, ct);
                if (result.ServiceResponse?["request"] is JsonNode request)
                {
                    requests.Add(request.DeepClone());
                }
            }
            if (requests.Count == 0)
            {
                throw new RequestFault(400, "no_contract_request", "This request kind has no JSON contract preview.");
            }

            return requests;
        }

        /// <summary>Validates the command and authorizes every vehicle before any handler runs or any result is persisted.</summary>
        private async Task<(IRequestHandler Handler, ProductDocument[] Products, Dictionary<string, VersionedProduct> Originals)> AuthorizeAsync(Actor actor, RequestCommand command, CancellationToken ct)
        {
            if (command.Payload is null)
            {
                throw new RequestFault(400, "payload_required", "A request payload is required.");
            }

            if (!_handlers.TryGetValue(command.Kind, out var handler))
            {
                throw new RequestFault(400, "unknown_kind", "No handler is registered for this request kind.");
            }

            var raw = command.Payload.A("products").Objects().ToArray();
            if (raw.Length == 0 && command.Payload["product"] is JsonObject single)
            {
                raw = [single];
            }

            if (raw.Length is < 1 or > 50)
            {
                throw new RequestFault(400, "batch_size", "Send between 1 and 50 products.");
            }

            var products = raw.Select(p => new ProductDocument(p)).ToArray();
            if (products.Select(p => p.Id).Distinct().Count() != products.Length)
            {
                throw new RequestFault(400, "duplicate_vehicle", "Each vehicle may appear only once per request.");
            }

            var originals = new Dictionary<string, VersionedProduct>(StringComparer.Ordinal);
            foreach (var product in products)
            {
                var original = await _store.VehicleAsync(product.Id, ct) ?? throw new RequestFault(404, "vehicle_missing", "Vehicle is not registered in the current catalog.");
                var source = new ProductDocument(original.Product);
                actor.DemandRead(source.ContextId);
                if (product.ContextId != source.ContextId || product.Info.S("productClassId") != source.Info.S("productClassId"))
                {
                    throw new RequestFault(400, "identity_changed", "A proposal cannot change product class or security context.");
                }

                foreach (var n in product.Nodes.Objects())
                {
                    if (_catalog.FindTemplate(n) is { } t && !t.A("contexts").Any(x => x?.ToString() == source.ContextId.ToString(System.Globalization.CultureInfo.InvariantCulture)))
                    {
                        throw new RequestFault(400, "foreign_node", "Node does not belong to the vehicle context.");
                    }
                }

                originals.Add(product.Id, original);
            }
            return (handler, products, originals);
        }

        public async Task<VersionedProduct> CommitVdaAsync(Actor actor, Guid requestId, string vehicleId, long expectedRevision, CancellationToken ct)
        {
            var record = await _store.ExecutionAsync(requestId, actor.Id, ct) ?? throw new RequestFault(404, "request_missing", "Request result was not found.");
            var outcome = record.Outcomes.FirstOrDefault(o => o.VehicleId == vehicleId) ?? throw new RequestFault(404, "result_missing", "Vehicle is not in this request.");
            actor.DemandWrite(new ProductDocument(outcome.Original).ContextId);
            if (!outcome.IsReady)
            {
                throw new RequestFault(409, "result_not_ready", "Blocked or limited-validation results cannot update VDA.");
            }

            if (expectedRevision != outcome.BaseRevision)
            {
                throw new RequestFault(409, "stale_result", "Revalidate against the current vehicle revision.");
            }

            var reason = record.Kind switch { RequestKind.ProductUpdateService => "Product Update Service result committed to VDA", RequestKind.Software => "Software request result committed to VDA", _ => record.Kind + " result committed to VDA" };
            return await _store.UpdateVehicleAsync(vehicleId, outcome.Proposal, expectedRevision, ct, new RevisionNote(actor.Id, actor.DisplayName, reason, "request:" + requestId));
        }

        public async Task<Kit> CreateKitAsync(Actor actor, Guid requestId, IReadOnlyList<string> vehicleIds, string name, CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(name) || name.Length > 120)
            {
                throw new RequestFault(400, "kit_name", "Kit name must contain 1 to 120 characters.");
            }

            if (vehicleIds is null)
            {
                throw new RequestFault(400, "kit_scope", "Select vehicles for this kit.");
            }

            if (vehicleIds.Count == 0 || vehicleIds.Count != vehicleIds.Distinct().Count())
            {
                throw new RequestFault(400, "kit_scope", "Select unique vehicles.");
            }

            var record = await _store.ExecutionAsync(requestId, actor.Id, ct) ?? throw new RequestFault(404, "request_missing", "Request result was not found.");
            var changes = new List<JsonObject>();
            foreach (var id in vehicleIds)
            {
                var o = record.Outcomes.FirstOrDefault(x => x.VehicleId == id) ?? throw new RequestFault(400, "invalid_kit_scope", "Selected vehicle is not in this request.");
                actor.DemandWrite(new ProductDocument(o.Original).ContextId);
                if (!o.IsReady || (await _store.VehicleAsync(id, ct))?.Revision != o.BaseRevision)
                {
                    throw new RequestFault(409, "stale_or_blocked_result", "Revalidate this vehicle before creating a kit.");
                }

                changes.Add(new JsonObject { ["vehicleId"] = id, ["delta"] = ProductDelta.Between(new ProductDocument(o.Original), new ProductDocument(o.Proposal)) });
            }
            return await _store.SaveKitAsync(new Kit(Guid.NewGuid(), actor.Id, name.Trim(), requestId, changes, _clock.GetUtcNow(), actor.DisplayName), ct);
        }
    }
}
