namespace Volvo.TestRequestTool.Application
{
    /// <summary>One check result. Status: up, degraded or down.</summary>
    public sealed record ServiceSample(string Service, DateTimeOffset At, string Status, double Ms, string? Code, string? Detail);
}
