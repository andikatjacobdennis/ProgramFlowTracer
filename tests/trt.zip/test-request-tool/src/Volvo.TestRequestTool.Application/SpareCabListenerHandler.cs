using System.Text.Json.Nodes;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// ESW_SPARECAB_BREAKDOWN_REQUEST 2.0 and 2.1 (Request.Listener/Aftermarket/SpareCabBreakdownRequest_2_0 and _2_1): the
    /// software of the requested cab nodes broken down from the Baseline (a baseline guid of the vehicle's context), by the
    /// tool's SpareCabHandler; RemovedNodes leave the product. The product is a hard individual product; its chassis is read,
    /// and its nodes when it has them (otherwise the vehicle's nodes in the repository). Both versions answer ProductsUpdate
    /// 1.1 (2.0 as SRV13570, 2.1 as SRV29074), every node with isSoftwareSame, as the listener does.
    /// </summary>
    public sealed class SpareCabListenerHandler : ListenerXmlHandler
    {
        private static readonly XNamespace Reply = "http://www.volvo.com/ProductsUpdate/1_1";
        private static readonly XNamespace Hip = "http://www.volvo.com/hip/main/1_0";
        private readonly ListenerProducts _products;
        private readonly ListenerCatalog _catalog;
        private readonly SpareCabHandler _spareCab;
        private readonly ProductsUpdateWriter _writer;

        public SpareCabListenerHandler(ListenerProducts products, ListenerCatalog catalog, TimeProvider clock) : base(clock)
        {
            _products = products;
            _catalog = catalog;
            _spareCab = new SpareCabHandler(catalog.Catalog);
            _writer = new ProductsUpdateWriter(catalog.Catalog);
        }

        public override IReadOnlyCollection<string> Keys { get; } = ["ESW_SPARECAB_BREAKDOWN_REQUEST_2.0", "ESW_SPARECAB_BREAKDOWN_REQUEST_2.1"];

        private static (string Id, string Version) Service(ListenerMessageType type) => type.Version == "2.1" ? ("SRV29074", "2.1") : ("SRV13570", "2.0");

        protected override async Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct)
        {
            var data = ListenerXml.Find(message.Xml, "DataArea");
            var baseline = ListenerXml.Attribute(data, "Baseline") ?? "";
            var product = await _products.ReadAsync(ListenerXml.Child(data, "Product")!, message.Actor, ct);
            var requested = ListenerXml.Children(ListenerXml.Child(data, "RequestedNodes"), "Node").ToList();
            var cab = new JsonArray();
            foreach (var r in requested)
            {
                var node = product.Product.Nodes.Objects().FirstOrDefault(n => ListenerCatalog.Matches(r, n)) ?? throw ListenerFault.NodeMissing("A requested node is not in the product.");
                cab.Add(new JsonObject { ["nodeIdentifier"] = node["nodeIdentifier"]!.DeepClone() });
            }

            var removed = new JsonArray();
            foreach (var r in ListenerXml.Children(ListenerXml.Child(data, "RemovedNodes"), "Node"))
            {
                var node = product.Product.Nodes.Objects().FirstOrDefault(n => ListenerCatalog.Matches(r.Elements().FirstOrDefault() ?? r, n));
                if (node is not null)
                {
                    removed.Add(new JsonObject { ["nodeIdentifier"] = node["nodeIdentifier"]!.DeepClone() });
                }
            }

            var known = _catalog.Catalog.Data.A("baselines").Objects().FirstOrDefault(b => b.S("guid").Equals(baseline, StringComparison.OrdinalIgnoreCase));
            var payload = new JsonObject { ["baselineGuid"] = known?.S("guid") ?? baseline, ["spareCabNodes"] = cab, ["removedNodes"] = removed };
            var result = await _spareCab.HandleAsync(product.Product, payload, ct);
            if (ProductsUpdateWriter.Fault(result.Issues) is { } fault)
            {
                throw new ListenerFault(100, "Undefined", known is null ? $"Baseline {baseline} is not known." : $"Baseline {known.S("name")} is not for the vehicle context of {product.Shown}.");
            }

            var delta = _writer.Delta(Reply, product.Product, result.Proposal, v11: true, null).ToList();
            foreach (var node in delta.Where(d => d.Name.LocalName == "AssignedNodes").SelectMany(d => d.Elements()))
            {
                node.SetAttributeValue("isSoftwareSame", "true");
            }

            var (id, version) = Service(message.Type);
            var root = ListenerXml.Bod(Reply, "ProductsUpdate", id, version, ListenerXml.Transaction(message.Xml), Clock, ListenerXml.Accepted(Reply),
                new XElement(Reply + "ProductUpdate", new XAttribute("chassisSeries", product.ChassisSeries), new XAttribute("chassisNumber", product.ChassisNumber), delta));
            var summary = new List<ListenerFact>
            {
                new("Outcome", $"Accepted: spare cab broken down from {known?.S("name")}."),
                product.Source,
                new(product.Shown, ProductsUpdateWriter.Describe(product.Product, result.Proposal)),
            };
            return new ListenerAnswer(root, summary, []);
        }

        protected override XElement Error(ListenerMessage message, ListenerNotice notice, string bodId)
        {
            var (id, version) = Service(message.Type);
            return ListenerXml.Bod(Reply, "ProductsUpdate", id, version, bodId, Clock, ListenerXml.Rejected(Reply, notice));
        }

        /// <summary>The vehicle's cab nodes (all nodes when none is a cab node) and the newest baseline of its context.</summary>
        public override XDocument Example(ListenerMessageType type, ProductDocument vehicle)
        {
            XNamespace ns = "http://esw.volvo.com/sparecabbreakdownrequest/" + type.Version.Replace('.', '_');
            XNamespace product = "http://www.volvo.com/SoftwareBreakdownHardIndividualProduct/" + (type.Version == "2.1" ? "1_1" : "1_0");
            var baseline = _catalog.Catalog.Data.A("baselines").Objects().Where(b => b.I("contextId") == vehicle.ContextId && b.S("category") == "Aftermarket").LastOrDefault()
                ?? _catalog.Catalog.Data.A("baselines").Objects().First();
            var nodes = vehicle.Nodes.Objects().Where(n => n.B("isCabNode")).DefaultIfEmpty(vehicle.Nodes.Objects().First());
            var productClass = vehicle.Info.S("productClassId");
            return Document(new XElement(ns + "GetSpareCabBreakdown",
                ListenerXml.RequestArea(Clock),
                new XElement(ns + "DataArea", new XAttribute("Baseline", baseline.S("guid").ToUpperInvariant()),
                    new XElement(ns + "Product",
                        new XElement(product + "Identification", new XElement(Hip + "ChassisID",
                            new XElement(Hip + "ChassisSeries", vehicle.Info.S("chassisSeries")),
                            new XElement(Hip + "ChassisNumber", ListenerProducts.Number(vehicle.Info.S("chassisNumber"))))),
                        productClass.Length <= 2 ? new XElement(product + "GeneralDescription", new XElement(Hip + "ProductClass", productClass)) : null),
                    new XElement(ns + "RequestedNodes", nodes.Select(n => new XElement(ns + "Node", ListenerCatalog.NodeId(ns, n)))))));
        }
    }
}
