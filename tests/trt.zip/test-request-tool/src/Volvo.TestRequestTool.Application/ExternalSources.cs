using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// EDB specifications and CBR spare cab orders, read through the service layer (files under the services path now,
    /// the live services when their transport is set to Http).
    /// </summary>
    public sealed class ExternalSources
    {
        private readonly ICatalog _catalog;
        private readonly IWorkspaceStore _store;
        private readonly IServiceGateway _gateway;

        public ExternalSources(ICatalog catalog, IWorkspaceStore store, IServiceGateway gateway)
        {
            _catalog = catalog;
            _store = store;
            _gateway = gateway;
        }

        public async Task<JsonObject> EdbAsync(string id, Actor actor, CancellationToken ct)
        {
            var reply = await _gateway.CallAsync(new ServiceCall("EDB", "specifications", id), ct);
            var spec = reply.Body;
            // The reference chassis: a vehicle of the same product class, series vehicles before pre-series ("Design") ones, then the class's own series.
            var reference = (await _store.VehiclesAsync(ct)).Select(v => (Vehicle: v, Info: new ProductDocument(v.Product).Info)).Where(x => x.Info.S("productClassId") == spec.S("productClassId"))
                .OrderBy(x => x.Info.S("testStatus") == "Design" ? 1 : 0).ThenBy(x => x.Info.S("chassisSeries") == spec.S("productClassId") ? 0 : 1).ThenBy(x => new ProductDocument(x.Vehicle.Product).Id, StringComparer.Ordinal)
                .Select(x => x.Vehicle).FirstOrDefault() ?? throw new RequestFault(404, "reference_missing", "No reference chassis in the repository matches this specification's product class.");
            var p = new ProductDocument(reference.Product);
            actor.DemandRead(p.ContextId);
            p.Nodes.Clear();
            p.Parameters.Clear();
            p.Info["modelId"] = spec.S("modelId");
            p.Info["edbSpecificationId"] = id;
            p.Info["specificationDate"] = spec.S("specDate");
            p.Info["assemblyFactoryCode"] = spec.S("factory");
            var data = _catalog.Data;
            var variants = new JsonArray();
            foreach (var symbol in spec.A("variants"))
            {
                var v = data.A("variants").Objects().FirstOrDefault(x => x.S("symbol") == symbol?.ToString());
                if (v is not null)
                {
                    variants.Add(v.DeepClone());
                }
            }
            p.Data["productSpecification"]!["variants"] = variants;
            p.Data["information"] = $"EDB specification {id} applied to reference chassis {p.Id}.";
            return p.Data;
        }

        public async Task<JsonObject> SpareCabOrderAsync(string id, Actor actor, CancellationToken ct)
        {
            var order = (await _gateway.CallAsync(new ServiceCall("CBR", "orders", id), ct)).Body;
            var reference = await _store.VehicleAsync(VehicleIdentity.Key(order.S("ChassieType"), order.S("ChassieNumber")), ct) ?? throw new RequestFault(404, "reference_missing", "The chassis on this CBR order is not in the repository.");
            actor.DemandRead(new ProductDocument(reference.Product).ContextId);
            var data = _catalog.Data;
            var ids = order["VariantString"].A("variants").Objects().Select(x => x.S("IdVar6")).ToHashSet();
            var variants = new JsonArray(data.A("variants").Objects().Where(x => ids.Contains(x.S("idVar6"))).Select(x => x.DeepClone()).ToArray());
            var hardware = new JsonArray();
            foreach (var bom in order.A("OrderComponentBom").Objects())
            {
                foreach (var part in bom.A("Part").Objects())
                {
                    hardware.Add(new JsonObject { ["itemNumber"] = part.S("PartNumber"), ["quantity"] = part.I("Quantity") });
                }
            }

            return new JsonObject { ["variants"] = variants, ["softwareRelatedHardwares"] = hardware, ["order"] = new JsonObject { ["orderNumber"] = order.S("OrderNumber"), ["chassis"] = order.S("ChassieType") + " " + order.S("ChassieNumber"), ["status"] = order.S("OrderStatus") } };
        }
    }
}
