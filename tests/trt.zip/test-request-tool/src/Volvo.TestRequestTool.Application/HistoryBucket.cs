namespace Volvo.TestRequestTool.Application
{
    /// <summary>A time bucket of service history: minutes up, degraded and down, availability and latency.</summary>
    public sealed record HistoryBucket(DateTimeOffset At, string Status, double Availability, double AvgMs, double P95Ms, int Up, int Degraded, int Down);
}
