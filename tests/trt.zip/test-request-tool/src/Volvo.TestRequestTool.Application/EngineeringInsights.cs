using System.Globalization;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// Engineering insights over a period, from recorded requests and jobs only: demand and blocked requests per day, the
    /// validation pass rate, processing time per day (p50 and p95 of the server-measured trace), current fleet readiness,
    /// the most common blocking reasons, queue pressure by weekday and hour (jobs accepted), and the average time per stage
    /// (queue, processing, integration calls) by request kind. Requests recorded before stage timing have no latency.
    /// </summary>
    public sealed class EngineeringInsights
    {
        private readonly IWorkspaceStore _store;
        private readonly ChangeImpact _impact;
        private readonly TimeProvider _clock;

        public EngineeringInsights(IWorkspaceStore store, ChangeImpact impact, TimeProvider clock)
        {
            _store = store;
            _impact = impact;
            _clock = clock;
        }

        public async Task<JsonObject> BuildAsync(Actor actor, bool everyone, int days, int? contextId, CancellationToken ct)
        {
            days = Math.Clamp(days, 1, 365);
            var now = _clock.GetUtcNow();
            var since = new DateTimeOffset(now.UtcDateTime.Date.AddDays(1 - days), TimeSpan.Zero);
            var all = await _store.ExecutionsSinceAsync(everyone ? null : actor.Id, since, 100_000, ct);
            bool InScope(Outcome o)
            {
                var c = new ProductDocument(o.Original).ContextId;
                return actor.Contexts.Contains(c) && (contextId is null || c == contextId);
            }
            var records = all.Where(r => r.Outcomes.Any(InScope)).ToArray();
            var jobs = (await _store.JobsAsync(everyone ? null : actor.Id, 100_000, ct)).Where(j => j.CreatedAt >= since).ToArray();
            static bool Blocked(ExecutionRecord r) => r.Outcomes.Any(o => o.Issues.Any(i => i.Severity == 0));
            static double Pct(IReadOnlyList<double> sorted, double p) => sorted.Count == 0 ? 0 : sorted[Math.Clamp((int)Math.Ceiling(p * sorted.Count) - 1, 0, sorted.Count - 1)];

            var perDay = new JsonArray();
            for (var d = 0; d < days; d++)
            {
                var day = since.AddDays(d);
                var list = records.Where(r => r.CreatedAt >= day && r.CreatedAt < day.AddDays(1)).ToArray();
                var ms = list.Where(r => r.Trace is not null).Select(r => r.Trace!.TotalMs).Order().ToArray();
                perDay.Add(new JsonObject
                {
                    ["day"] = day.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
                    ["requests"] = list.Length,
                    ["blocked"] = list.Count(Blocked),
                    ["timed"] = ms.Length,
                    ["p50"] = ms.Length == 0 ? null : Math.Round(Pct(ms, 0.5), 2),
                    ["p95"] = ms.Length == 0 ? null : Math.Round(Pct(ms, 0.95), 2),
                });
            }
            var timed = records.Where(r => r.Trace is not null).Select(r => r.Trace!.TotalMs).Order().ToArray();
            var blockers = records.SelectMany(r => r.Outcomes.Where(InScope)).SelectMany(o => o.Issues.Where(i => i.Severity == 0))
                .GroupBy(i => ProposalDiff.Category(i.Code)).Select(g => (JsonNode)new JsonObject
                {
                    ["category"] = g.Key,
                    ["count"] = g.Count(),
                    ["codes"] = new JsonArray(g.GroupBy(i => i.Code).OrderByDescending(c => c.Count()).Take(5).Select(c => (JsonNode)new JsonObject { ["code"] = c.Key, ["count"] = c.Count(), ["example"] = c.First().Text }).ToArray()),
                }).OrderByDescending(n => n!["count"]!.GetValue<int>()).ToArray();
            var heat = new JsonArray();
            foreach (var dow in new[] { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday, DayOfWeek.Saturday, DayOfWeek.Sunday })
            {
                heat.Add(new JsonArray(Enumerable.Range(0, 24).Select(hr => (JsonNode)jobs.Count(j => j.CreatedAt.UtcDateTime.DayOfWeek == dow && j.CreatedAt.UtcDateTime.Hour == hr)).ToArray()));
            }

            var jobFor = jobs.Where(j => j.StartedAt is not null).GroupBy(j => j.ResultIdFor).ToDictionary(g => g.Key, g => g.First());
            var stages = records.Where(r => r.Trace is not null).GroupBy(r => r.Kind.ToString()).Select(g =>
            {
                double Avg(Func<ExecutionRecord, double> f) => Math.Round(g.Average(f), 2);
                return (JsonNode)new JsonObject
                {
                    ["kind"] = g.Key,
                    ["requests"] = g.Count(),
                    ["queueMs"] = Avg(r => jobFor.TryGetValue(r.Id, out var j) ? (j.StartedAt!.Value - j.CreatedAt).TotalMilliseconds : 0),
                    ["processingMs"] = Avg(r => r.Trace!.Stages.Where(s => s.Kind != "service").Sum(s => s.DurationMs)),
                    ["externalMs"] = Avg(r => r.Trace!.Stages.Where(s => s.Kind == "service").Sum(s => s.DurationMs)),
                };
            }).ToArray();
            var readiness = await _impact.ReadinessAsync(actor, ct);
            var states = readiness["vehicles"]!.AsArray().Where(v => contextId is null || v!["context"]!["id"]!.GetValue<int>() == contextId)
                .Select(v => v!["cells"]!["overall"]!["state"]!.GetValue<string>()).ToArray();
            var dist = new JsonObject();
            foreach (var s in new[] { "ready", "pending", "blocked", "unknown", "stale" })
            {
                dist[s] = states.Count(x => x == s);
            }

            return new JsonObject
            {
                ["generatedAt"] = now.ToString("O", CultureInfo.InvariantCulture),
                ["from"] = since.ToString("O", CultureInfo.InvariantCulture),
                ["days"] = days,
                ["scope"] = everyone ? "everyone" : "mine",
                ["contextId"] = contextId,
                ["groups"] = readiness["groups"]!.DeepClone(),
                ["totals"] = new JsonObject
                {
                    ["requests"] = records.Length,
                    ["passRate"] = records.Length == 0 ? null : Math.Round(100.0 * records.Count(r => !Blocked(r)) / records.Length, 1),
                    ["medianMs"] = timed.Length == 0 ? null : Math.Round(Pct(timed, 0.5), 2),
                    ["p95Ms"] = timed.Length == 0 ? null : Math.Round(Pct(timed, 0.95), 2),
                    ["timed"] = timed.Length,
                    ["readiness"] = states.Length == 0 ? null : Math.Round(100.0 * states.Count(s => s == "ready") / states.Length, 1),
                    ["vehicles"] = states.Length,
                    ["jobs"] = jobs.Length,
                },
                ["perDay"] = perDay,
                ["readinessStates"] = dist,
                ["blockers"] = new JsonArray(blockers),
                ["queueHeat"] = heat,
                ["stages"] = new JsonArray(stages),
            };
        }
    }
}
