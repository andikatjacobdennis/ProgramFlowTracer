using System.Globalization;
using System.Reflection;
using System.Xml.Linq;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The shape the Production and Development replies share (BreakdownModuleCommon). Versions 1.x are a root with
    /// transactionId, schemaVersion, systemVersion and timeStamp; 2.0 and 2.1 are a BOD: ApplicationArea (Sender with the
    /// module as ComponentID, Receiver SWBRKDWN, an empty BODID guid) and a DataArea with those attributes. The listener puts
    /// no error code in these replies: an error is a reply with one notification, TECHNICAL ERROR (or BAD REQUEST for a
    /// schemaVersion that does not match the message type), and problems of the product are notifications of a normal reply.
    /// </summary>
    public abstract class BreakdownListenerHandler : ListenerXmlHandler
    {
        protected BreakdownListenerHandler(TimeProvider clock) : base(clock)
        {
        }

        /// <summary>The kind of request in the error texts, for example "production breakdown".</summary>
        protected abstract string Kind { get; }

        /// <summary>The module the 2.x replies name as the sender's ComponentID.</summary>
        protected abstract string Component { get; }

        /// <summary>The reply root element.</summary>
        protected abstract string ReplyRoot(ListenerMessageType type);

        /// <summary>The reply namespace for the version.</summary>
        protected abstract XNamespace ReplyNs(ListenerMessageType type);

        protected static bool IsBod(ListenerMessageType type) => type.Version is "2.0" or "2.1";

        protected static BreakdownXml Bmc(ListenerMessageType type) => new(type.Version);

        /// <summary>The request element that holds the content: the root in 1.x, the DataArea in 2.x.</summary>
        protected static XElement Data(ListenerMessage message) =>
            (IsBod(message.Type) ? ListenerXml.Child(message.Xml!.Root, "DataArea") : message.Xml!.Root) ?? throw ListenerFault.InvalidMessage("The request has no DataArea.");

        /// <summary>The reply around its content (a bill of material, tool operations, notifications).</summary>
        protected XElement Reply(ListenerMessage message, string transaction, params object?[] content)
        {
            var type = message.Type;
            var ns = ReplyNs(type);
            var stamp = new object[]
            {
                new XAttribute("schemaVersion", type.Version),
                new XAttribute("systemVersion", SystemVersion),
                new XAttribute("timeStamp", Clock.GetUtcNow().UtcDateTime.ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture)),
            };
            if (!IsBod(type))
            {
                return new XElement(ns + ReplyRoot(type), new XAttribute("transactionId", transaction), stamp, content);
            }

            var sender = ListenerXml.Text(ListenerXml.Find(message.Xml, "Sender"), "UserID") ?? message.SenderId;
            var v = ListenerXml.Volvo;
            return new XElement(ns + ReplyRoot(type),
                new XElement(v + "ApplicationArea",
                    new XElement(v + "Sender", new XElement(v + "LogicalID", sender), new XElement(v + "ComponentID", Component)),
                    new XElement(v + "Receiver", new XElement(v + "LogicalID", "SWBRKDWN")),
                    new XElement(v + "CreationDateTime", Clock.GetUtcNow().UtcDateTime.ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture)),
                    new XElement(v + "BODID", Guid.Empty.ToString()),
                    new XElement(v + "UserArea")),
                new XElement(ns + "DataArea", stamp, content));
        }

        /// <summary>The transaction id of a request: transactionId in 1.x (the 2.x replies carry none).</summary>
        protected static string Transaction(ListenerMessage message) => ListenerXml.Attribute(message.Xml?.Root, "transactionId") ?? "";

        protected override XElement Error(ListenerMessage message, ListenerNotice notice, string bodId)
        {
            var bmc = Bmc(message.Type);
            var stage = bodId.Length == 0 ? "request has an invalid format and could not be processed" : "was stopped by an unexpected technical error";
            var item = notice.Name == "RequestVersionError"
                ? new BreakdownNotice("Error", "BAD REQUEST", "The request does not match the version in the message type header and could not be processed.", notice.Text, "Change the message header type version.")
                : BreakdownNotice.TechnicalError(bodId.Length == 0 ? $"The {Kind} request has an invalid format and could not be processed." : $"The {Kind} {stage}.", notice.Text);
            return Reply(message, bodId.Length == 0 ? "" : Transaction(message), bmc.Notifications(ReplyNs(message.Type) + "Notifications", [item]));
        }

        /// <summary>A summary line for the notifications of a reply.</summary>
        protected static IEnumerable<ListenerFact> Facts(IEnumerable<BreakdownNotice> notices) =>
            notices.Select(n => new ListenerFact($"{n.Severity}: {n.Type}", n.Text));

        /// <summary>The 2.1 note: the reply has the 2.0 shape in the 2.1 namespaces, and there is no XSD to check it against.</summary>
        protected static IEnumerable<ListenerFact> Version21(ListenerMessageType type) => type.Version == "2.1"
            ? [new ListenerFact("2.1", "The 2.1 contracts are not among the files. The reply has the 2.0 shape in the 2.1 namespaces, as the listener's 2.1 code writes it, and cannot be checked.")]
            : [];

        private static string SystemVersion => typeof(BreakdownListenerHandler).Assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion.Split('+')[0] ?? "1.0.0";
    }
}
