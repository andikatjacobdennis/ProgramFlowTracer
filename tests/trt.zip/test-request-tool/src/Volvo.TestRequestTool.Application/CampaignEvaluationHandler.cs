using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// GetCampaignEvaluation 1.0 (Request.Listener/Aftermarket/CampaignEvaluation_1_0, CampaignEvaluation_1.0.2): each requested
    /// kit evaluated on its own against the product, per action criterion. Unlike the kit evaluation, an error does not
    /// reject the request: it becomes the kit's result (AlreadyApplied, NotApplicable or NotPossible) with the error message.
    /// A kit the catalog does not know is still listed, without a name, as the listener does.
    /// </summary>
    public sealed class CampaignEvaluationHandler : ListenerXmlHandler
    {
        private static readonly XNamespace Ns = "http://www.volvo.com/CampaignEvaluation/1_0";
        private readonly ListenerProducts _products;
        private readonly ListenerCatalog _catalog;

        public CampaignEvaluationHandler(ListenerProducts products, ListenerCatalog catalog, TimeProvider clock) : base(clock)
        {
            _products = products;
            _catalog = catalog;
        }

        public override IReadOnlyCollection<string> Keys { get; } = ["GetCampaignEvaluation_1.0"];

        protected override async Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct)
        {
            var data = ListenerXml.Find(message.Xml, "DataArea");
            var criteria = ListenerXml.Child(data, "Criteria");
            var verbs = KitEvaluation.Parse(ListenerXml.Attribute(criteria, "actionCriteria"));
            var scenario = ListenerCatalog.Scenario(ListenerXml.Attribute(criteria, "scenario"));
            var product = await _products.ReadAsync(ListenerXml.Child(data, "Product")!, message.Actor, ct);
            var summary = new List<ListenerFact> { product.Source };
            var kits = new List<XElement>();
            foreach (var number in ListenerXml.Children(ListenerXml.Child(data, "RequestedKits"), "RequestedKit").Select(r => (long)(ListenerXml.Number(ListenerXml.Attribute(r, "partNumber")) ?? 0)).Distinct())
            {
                var kit = _catalog.Kit(number);
                var results = new List<XElement>();
                var remote = true;
                foreach (var verb in verbs)
                {
                    var e = KitEvaluation.Evaluate(_catalog, product.Product, [number], verb, scenario, serviceKitsOnly: false);
                    remote &= verb == "SoftwareReplacements.General" || e.Outcome == "Applicable";
                    results.Add(new XElement(Ns + "Result",
                        new XAttribute("actionCriteria", verb), new XAttribute("outcome", e.Outcome),
                        e.Error is null ? null : new XAttribute("errorMessage", e.Error.Message),
                        e.Result is null || e.Result.Assigned.Count == 0 ? null : new XElement(Ns + "AssignedNodes", e.Result.Assigned.Select(Assigned)),
                        e.Result is null || e.Result.Removed.Count == 0 ? null : new XElement(Ns + "RemovedNodes", e.Result.Removed.Select(r => new XElement(Ns + "Node", ListenerCatalog.NodeId(Ns, r))))));
                    summary.Add(new ListenerFact($"{ListenerXml.PartNumber(number)} {verb}", e.Outcome + (e.Error is null ? "" : ": " + e.Error.Message)));
                }

                kits.Add(new XElement(Ns + "Kit",
                    new XAttribute("partNumber", ListenerXml.PartNumber(number)),
                    new XAttribute("name", kit.S("name")),
                    new XAttribute("kitType", kit is null ? "Accessory" : ListenerCatalog.KitType(kit)),
                    new XAttribute("isAvailableRemote", kit is not null && remote && verbs.Count > 1 ? "true" : "false"),
                    new XAttribute("hardwareNonControlUnitChangeNeeded", "false"),
                    results));
            }

            var root = ListenerXml.Bod(Ns, "ShowCampaignEvaluation", "SRV12807", "1.0", ListenerXml.Transaction(message.Xml), Clock, ListenerXml.Accepted(Ns), kits);
            summary.Insert(0, new ListenerFact("Outcome", $"{kits.Count} kit(s) evaluated."));
            return new ListenerAnswer(root, summary, []);
        }

        protected override XElement Error(ListenerMessage message, ListenerNotice notice, string bodId) =>
            ListenerXml.Bod(Ns, "ShowCampaignEvaluation", "SRV12807", "1.0", bodId, Clock, ListenerXml.Rejected(Ns, notice));

        public override XDocument Example(ListenerMessageType type, ProductDocument vehicle) =>
            Document(new XElement(Ns + "GetCampaignEvaluation",
                ListenerXml.RequestArea(Clock),
                new XElement(Ns + "DataArea",
                    new XElement(Ns + "Criteria", new XAttribute("actionCriteria", "SoftwareReplacements.General,SoftwareReplacements.RemoteGeneral"), new XAttribute("scenario", "Introduced"), new XAttribute("pblUpdateCapable", "true")),
                    new XElement(Ns + "RequestedKits", _catalog.Kits.Where(k => k.B("isCampaignKit")).Select(k => k.I("partNumber")).Concat(KitEvaluationHandler.ExampleKit(_catalog, vehicle).Select(n => (int)n)).Distinct()
                        .Select(n => new XElement(Ns + "RequestedKit", new XAttribute("partNumber", n)))),
                    ListenerProducts.ProductElement(Ns, "Product", vehicle))));

        private XElement Assigned(KitNode a)
        {
            var version = _catalog.Catalog.FindVersion(a.Node);
            return new XElement(Ns + "Node",
                version.I("doc") > 0 ? new XAttribute("nodeTemplateDocumentNumber", ListenerXml.PartNumber(version.I("doc"))) : null,
                new XAttribute("IsSoftwareSame", "false"),
                new XAttribute("nodeTemplateStatus", ListenerCatalog.Status(version)),
                new XAttribute("remoteSWDLAvailability", ListenerCatalog.Remote(version)),
                new XAttribute("HardwareChangeNeeded", a.HardwareChangeNeeded ? "true" : "false"),
                new XAttribute("SerialNumberInputNeeded", a.SerialNumberInputNeeded ? "true" : "false"),
                ListenerCatalog.NodeId(Ns, a.Node));
        }
    }
}
