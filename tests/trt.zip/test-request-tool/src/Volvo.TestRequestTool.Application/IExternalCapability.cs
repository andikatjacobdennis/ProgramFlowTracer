using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Application
{
    public interface IExternalCapability
    {
        string Name { get; }
        bool IsConfigured { get; }
        Task<JsonObject> InvokeAsync(JsonObject payload, CancellationToken ct);
    }
}
