using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// Available Product Updates (GetAvailableProductUpdates 1.0 / 1.1 → ShowAvailableProductUpdates). 1.0 takes actionCriteria as a
    /// comma-separated string, 1.1 as a JSON string array and adds software product id/templateId. Lists what could be updated; never changes the vehicle.
    /// </summary>
    public sealed class AvailableProductUpdatesHandler : IRequestHandler
    {
        private readonly ICatalog _catalog;

        public static readonly string[] ActionCriteria =
                    [
                        "SoftwareReplacements.CurrentSoftware","SoftwareReplacements.General","SoftwareReplacements.RemoteGeneral","SoftwareReplacements.RemoteLimited","SoftwareReplacements.RemoteCapable",
            "SoftwareReplacements.ServicePackGeneral","SoftwareReplacements.ServicePackRemoteGeneral","SoftwareReplacements.ServicePackRemoteLimited","SoftwareReplacements.ServicePackRemoteCapable",
            "HardwareReplacements","DisplayLanguages","AccessoryKits","ServiceKits","AdministrativeServiceKits","CampaignKits","HardwareKits",
            "RemoteAccessoryKits","RemoteServiceKits","RemoteAdministrativeServiceKits","RemoteCampaignKits","RemoteHardwareKits"
                    ];

        public AvailableProductUpdatesHandler(ICatalog catalog)
        {
            _catalog = catalog;
        }

        public RequestKind Kind => RequestKind.AvailableProductUpdates;

        public ValueTask<HandlerResult> HandleAsync(ProductDocument original, JsonObject payload, CancellationToken ct)
        {
            var version = payload.S("contractVersion", "1.1");
            var criteria = (JsonObject?)payload["criteria"]?.DeepClone() ?? new JsonObject();
            var bodId = payload.S("transactionId");
            if (string.IsNullOrWhiteSpace(bodId))
            {
                bodId = Guid.NewGuid().ToString("N");
            }

            var request = new JsonObject
            {
                ["GetAvailableUpdates"] = new JsonObject
                {
                    ["ApplicationArea"] = new JsonObject { ["Sender"] = new JsonObject { ["LogicalID"] = "SWConfig" }, ["CreationDateTime"] = DateTimeOffset.UtcNow.ToString("O"), ["BODID"] = bodId },
                    ["DataArea"] = new JsonObject { ["Criteria"] = criteria, ["Product"] = ServiceContract.Product(original, "APU") }
                }
            };
            var area = new JsonObject { ["Sender"] = new JsonObject { ["LogicalID"] = "SWBRKDWN" }, ["CreationDateTime"] = DateTimeOffset.UtcNow.ToString("O"), ["BODID"] = bodId };
            HandlerResult Reject(int code, string text) => new(original.Copy(), [new("apu_rejected", text + " (error code " + code + ")")],
                ServiceResponse: Envelope(version, request, new JsonObject
                {
                    ["ShowAvailableProductUpdates"] = new JsonObject
                    {
                        ["ApplicationArea"] = area,
                        ["serviceID"] = "SRV12921",
                        ["serviceVersion"] = version,
                        ["DataArea"] = new JsonObject { ["Show"] = new JsonObject { ["ResponseCriteria"] = "Rejected", ["StatusCode"] = code.ToString(System.Globalization.CultureInfo.InvariantCulture), ["StatusText"] = text } }
                    }
                }, code, original));

            if (version is not ("1.0" or "1.1"))
            {
                return ValueTask.FromResult(Reject(ServiceContract.UnhandledError, "No handler is registered for GetAvailableProductUpdates_" + version + "."));
            }
            // actionCriteria: 1.0 comma-separated string, 1.1 JSON string array.
            string[] actions;
            var raw = criteria["actionCriteria"];
            if (version == "1.0")
            {
                if (raw is not JsonValue || string.IsNullOrWhiteSpace(raw.ToString()))
                {
                    return ValueTask.FromResult(Reject(ServiceContract.InvalidMessage, raw is JsonArray ? "Schema validation failed." : "Action critera cannot be null or empty."));
                }

                actions = raw.ToString().Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            }
            else
            {
                if (raw is null)
                {
                    return ValueTask.FromResult(Reject(ServiceContract.InvalidMessage, "Action criteria array cannot be null."));
                }

                if (raw is not JsonArray list)
                {
                    return ValueTask.FromResult(Reject(ServiceContract.InvalidMessage, "Schema validation failed."));
                }

                actions = list.Select(x => x?.ToString() ?? "").ToArray();
                if (actions.Length == 0)
                {
                    return ValueTask.FromResult(Reject(ServiceContract.InvalidMessage, "Action critera cannot be null or empty."));
                }
            }
            var invalid = actions.FirstOrDefault(a => !ActionCriteria.Contains(a, StringComparer.Ordinal));
            if (invalid is not null)
            {
                return ValueTask.FromResult(Reject(ServiceContract.InvalidMessage, invalid + " is not a valid Action criteria type"));
            }

            if (!ServiceContract.TryScenario(criteria, out var scenario, out var scenarioName))
            {
                return ValueTask.FromResult(Reject(ServiceContract.UnhandledError, "Unhandled scenario: " + scenarioName));
            }

            foreach (var hpc in original.Nodes.Objects().Where(n => ServiceContract.IsHpc(n) && n.A("softwareProducts").Objects().All(s => string.IsNullOrEmpty(s.S("logicalEcu")))))
            {
                return ValueTask.FromResult(Reject(ServiceContract.UnhandledError, "Logical ECU definition not found for " + hpc["nodeIdentifier"].I("family") + "." + hpc["nodeIdentifier"].I("type")));
            }

            var pbl = criteria.B("pblUpdateCapable");
            var purposes = criteria.B("includeUpdatePurposes");
            var withSource = criteria.B("includeReleaseNoteSource");
            var v11 = version == "1.1";
            var requested = payload.A("requestedNodes").Objects().Select(r => JsonAccess.NodeKey(r["nodeIdentifier"])).ToHashSet(StringComparer.Ordinal);
            var nodes = original.Nodes.Objects().Where(n => requested.Count == 0 || requested.Contains(JsonAccess.NodeKeyOf(n))).Select(n => (node: n, template: _catalog.FindTemplate(n))).ToArray();
            var software = new JsonArray();
            var kits = new JsonArray();
            var failures = new List<string>();
            JsonObject? hardware = null, languages = null;
            bool Compatible(JsonObject v, JsonObject n) => v.A("hardware").Any(h => int.TryParse(h?.ToString(), out var x) && x == n["ecuHardware"].I("number")) && (pbl || n["primaryBootloader"] is null || n["primaryBootloader"].I("number") == v.I("pbl"));
            JsonObject Notes(IEnumerable<(JsonObject node, JsonObject v)> list, string? spGuid) => new()
            {
                ["ReleaseNote"] = new JsonArray(list.Select(x =>
                {
                    var rn = new JsonObject { ["id"] = x.v.I("doc"), ["releaseNote"] = x.v["releaseNotes"].S(criteria.S("languageCode", "en-US").Replace('_', '-'), x.v["releaseNotes"].S("en-GB")) };
                    if (withSource)
                    {
                        rn["SourceType"] = spGuid is not null ? new JsonObject { ["servicePackGuid"] = spGuid } : v11 && x.node.A("softwareProducts").Count > 0 ? new JsonObject { ["softwareProductTemplateId"] = x.node.S("name") + "-SWPT", ["contextName"] = "unknown" } : new JsonObject { ["nodeName"] = x.node.S("name") };
                    }

                    return (JsonNode)rn;
                }).ToArray())
            };

            foreach (var action in actions)
            {
                ct.ThrowIfCancellationRequested();
                if (action.StartsWith("SoftwareReplacements.", StringComparison.Ordinal))
                {
                    var kind = action["SoftwareReplacements.".Length..];
                    var remote = kind.Contains("Remote", StringComparison.Ordinal);
                    if (kind.StartsWith("ServicePack", StringComparison.Ordinal))
                    {
                        var sp = _catalog.Data.A("servicePacks").Objects().Where(s => s.I("contextId") == original.ContextId).OrderByDescending(s => s.I("sortOrder")).ThenByDescending(s => s.S("guid"), StringComparer.Ordinal)
                            .FirstOrDefault(s => nodes.Where(x => x.template is not null).All(x =>
                            {
                                var vs = x.template!.A("versions").Objects().ToArray();
                                var t = s["ntps"].I(x.template!.S("key"), -1);
                                return t >= 0 && t < vs.Length && SoftwareHandler.Allowed(vs[t], scenario) && Compatible(vs[t], x.node) && (!remote || vs[t].B("remoteCapable"));
                            }));
                        if (sp is null)
                        {
                            failures.Add($"ActionCriteria '{action}' failed: No service pack matches every node for scenario {scenarioName}.");
                            continue;
                        }
                        var assigned = nodes.Where(x => x.template is not null).Select(x =>
                        {
                            var vs = x.template!.A("versions").Objects().ToArray();
                            var v = vs[sp["ntps"].I(x.template!.S("key"))];
                            return (x.node, v);
                        }).ToArray();
                        var entry = new JsonObject
                        {
                            ["actionCriteria"] = action,
                            ["AssignedNodes"] = new JsonObject { ["Node"] = new JsonArray(assigned.Select(a => (JsonNode)ServiceContract.ResponseNode(a.node, a.v, original, a.v.I("doc") == a.node["nodeTemplateDocument"].I("number"), v11)).ToArray()) },
                            ["ServicePack"] = new JsonObject { ["guid"] = sp.S("guid"), ["name"] = sp.S("name"), ["exactMatch"] = true },
                            ["ReleaseNotes"] = Notes(assigned.Where(a => a.v.I("doc") != a.node["nodeTemplateDocument"].I("number")), sp.S("guid"))
                        };
                        if (purposes)
                        {
                            entry["UpdatePurposes"] = new JsonObject { ["Purpose"] = new JsonArray("Enhancement") };
                        }

                        software.Add(entry);
                        continue;
                    }
                    var picked = new List<(JsonObject node, JsonObject v)>();
                    foreach (var (node, template) in nodes)
                    {
                        if (template is null)
                        {
                            continue;
                        }

                        var vs = template.A("versions").Objects().ToArray();
                        var cur = Array.FindIndex(vs, v => v.I("doc") == node["nodeTemplateDocument"].I("number"));
                        JsonObject? v = kind == "CurrentSoftware" ? (cur >= 0 ? vs[cur] : null) : vs.Where(x => SoftwareHandler.Allowed(x, scenario) && Compatible(x, node) && (!remote || x.B("remoteCapable")) && x.I("idx") >= Math.Max(cur, 0)).OrderByDescending(x => x.I("idx")).FirstOrDefault();
                        if (v is not null)
                        {
                            picked.Add((node, v));
                        }
                    }
                    if (picked.Count == 0)
                    {
                        failures.Add($"ActionCriteria '{action}' failed: No node template matches the criteria.");
                        continue;
                    }
                    var sw = new JsonObject
                    {
                        ["actionCriteria"] = action,
                        ["AssignedNodes"] = new JsonObject { ["Node"] = new JsonArray(picked.Select(x => (JsonNode)ServiceContract.ResponseNode(x.node, x.v, original, x.v.I("doc") == x.node["nodeTemplateDocument"].I("number"), v11)).ToArray()) },
                        ["ReleaseNotes"] = Notes(picked.Where(x => x.v.I("doc") != x.node["nodeTemplateDocument"].I("number")), null)
                    };
                    if (purposes)
                    {
                        sw["UpdatePurposes"] = new JsonObject { ["Purpose"] = picked.Any(x => x.v.I("doc") != x.node["nodeTemplateDocument"].I("number")) ? new JsonArray("Enhancement") : new JsonArray() };
                    }

                    software.Add(sw);
                }
                else if (action == "HardwareReplacements")
                {
                    var list = new JsonArray();
                    foreach (var (node, template) in nodes)
                    {
                        if (template is null)
                        {
                            continue;
                        }

                        var hw = node["ecuHardware"].I("number");
                        var newer = template.A("versions").Objects().Where(v => SoftwareHandler.Allowed(v, scenario) && !v.A("hardware").Any(h => h?.ToString() == hw.ToString(System.Globalization.CultureInfo.InvariantCulture))).ToArray();
                        var parts = newer.SelectMany(v => v.A("hardware").Select(h => h?.ToString() ?? "")).Where(h => h.Length > 0 && h != hw.ToString(System.Globalization.CultureInfo.InvariantCulture)).Distinct().ToArray();
                        if (parts.Length > 0)
                        {
                            list.Add(new JsonObject
                            {
                                ["item"] = new JsonObject { ["nodeName"] = node.S("name") },
                                ["hardwarePartNumbers"] = new JsonArray(parts.Select(x => (JsonNode)x).ToArray()),
                                ["subHardwareReplacements"] = new JsonArray(),
                                ["chassisSeries"] = ServiceContract.PadSeries(original.Info.S("chassisSeries")),
                                ["chassisNumber"] = original.Info.S("chassisNumber")
                            });
                        }
                    }
                    hardware = new JsonObject { ["HardwareNodeReplacement"] = list };
                }
                else if (action == "DisplayLanguages")
                {
                    languages = new JsonObject { ["chassisSeries"] = ServiceContract.PadSeries(original.Info.S("chassisSeries")), ["chassisNumber"] = original.Info.S("chassisNumber"), ["LanguageNodes"] = new JsonArray(), ["LanguageComponents"] = new JsonArray() };
                }
                else
                {
                    var remote = action.StartsWith("Remote", StringComparison.Ordinal);
                    var type = remote ? action["Remote".Length..] : action;
                    var states = scenario switch { 3 => new[] { "Released" }, 4 => ["Released", "Introduced", "Pre Release Verification"], 5 => ["Released", "Introduced", "Pre Release Verification", "In Progress"], _ => ["Released", "Introduced"] };
                    var found = _catalog.Data.A("kits").Objects().Where(k => k.A("productClasses").Any(c => c?.ToString() == original.Info.S("productClassId")) && states.Contains(k.S("state")))
                        .Where(k => type switch { "ServiceKits" => k.B("isServiceKit"), "CampaignKits" => k.B("isCampaignKit"), "AccessoryKits" => !k.B("isServiceKit") && !k.B("isCampaignKit"), _ => false })
                        .Where(k => !remote || k.B("isAvailableRemote")).ToArray();
                    kits.Add(new JsonObject
                    {
                        ["actionCriteria"] = action,
                        ["Kit"] = new JsonArray(found.Select(k => (JsonNode)new JsonObject
                        {
                            ["partNumber"] = k.I("partNumber"),
                            ["name"] = k.S("name"),
                            ["isAvailableRemote"] = k.B("isAvailableRemote"),
                            ["affectsSoftware"] = k["delta"] is null ? "notchecked" : "true",
                            ["hardwareNonControlUnitChangeNeeded"] = false,
                            ["eswAlreadyApplied"] = false,
                            ["chassisSeries"] = ServiceContract.PadSeries(original.Info.S("chassisSeries")),
                            ["chassisNumber"] = original.Info.S("chassisNumber")
                        }).ToArray())
                    });
                }
            }
            var results = software.Count + kits.Count + (hardware is null ? 0 : 1) + (languages is null ? 0 : 1);
            var show = failures.Count == 0 ? new JsonObject { ["ResponseCriteria"] = "Accepted", ["StatusCode"] = "0", ["StatusText"] = "" }
                : new JsonObject { ["ResponseCriteria"] = results > 0 ? "Modified" : "Rejected", ["StatusCode"] = results > 0 ? "1" : "-1", ["StatusText"] = string.Join(", ", failures) };
            var data = new JsonObject { ["Show"] = show };
            if (software.Count > 0)
            {
                data["SoftwareNodeReplacements"] = software;
            }

            if (hardware is not null)
            {
                data["HardwareNodeReplacements"] = hardware;
            }

            if (languages is not null)
            {
                data["DisplayLanguages"] = languages;
            }

            if (kits.Count > 0)
            {
                data["Kits"] = kits;
            }

            var reply = new JsonObject { ["ShowAvailableProductUpdates"] = new JsonObject { ["ApplicationArea"] = area, ["serviceID"] = "SRV12921", ["serviceVersion"] = version, ["DataArea"] = data } };
            var issues = failures.Select(f => new ValidationIssue("action_criteria_failed", f, results > 0 ? 1 : 0)).ToList();
            return ValueTask.FromResult(new HandlerResult(original.Copy(), issues, ServiceResponse: Envelope(version, request, reply, show.S("StatusCode") == "-1" ? ServiceContract.InvalidMessage : 0, original)));
        }

        static JsonObject Envelope(string version, JsonObject request, JsonObject reply, int code, ProductDocument p) => new()
        {
            ["contract"] = "AvailableProductUpdates",
            ["version"] = version,
            ["chassisSeries"] = p.Info.S("chassisSeries"),
            ["chassisNumber"] = p.Info.S("chassisNumber"),
            ["aftermarketErrorCode"] = code,
            ["request"] = request,
            ["response"] = reply
        };
    }
}
