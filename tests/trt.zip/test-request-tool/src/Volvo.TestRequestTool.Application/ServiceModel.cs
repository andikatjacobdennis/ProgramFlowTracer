using System.Globalization;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The behaviour of the simulated services, as a pure function of time: the same minute always gives the same state, so a
    /// long, realistic history exists without storing anything, and every chart, incident and root cause can be reproduced.
    /// <list type="bullet">
    /// <item>Each service has a few unplanned incidents per week (timeouts, 5xx after deployments, slow responses at peak,
    /// expired certificates, name resolution failures), seeded per service and day.</item>
    /// <item>Planned maintenance windows: VDA on Sundays 01:00–01:45 UTC, EDB on the first Saturday of the month 02:00–04:00 UTC.</item>
    /// <item>Failures spread along dependencies: when VDA fails, KAX and Digital Twin fail a minute or two later; when the
    /// identity provider fails, every external system rejects sign-in. Root cause analysis follows these links back.</item>
    /// </list>
    /// </summary>
    public static class ServiceModel
    {
        public static readonly IReadOnlyList<MonitoredService> Services =
        [
            new("identity", "Identity provider", "Sign-in", true, 45, .985, [], "Issues the tokens every external system checks."),
            new("vda", "VDA", "Vehicle data", true, 120, .97, ["identity"], "The official record of each vehicle's configuration."),
            new("edb", "EDB", "Engineering data", true, 160, .975, ["identity"], "Specifications before production."),
            new("cbr", "CBR", "Cab orders", true, 95, .985, ["identity"], "Spare cab orders."),
            new("kax", "KAX", "Compatibility", true, 210, .96, ["vda", "identity"], "Checks software and hardware combinations."),
            new("vespa", "VESPA", "Variants", true, 140, .975, ["identity"], "Variant editing."),
            new("dependix", "Dependix", "Dependencies", true, 180, .965, ["edb", "identity"], "Software dependency rules."),
            new("digitaltwin", "Digital Twin", "Specification", true, 260, .96, ["vda", "identity"], "Builds the vehicle's digital specification."),
            new("bus", "Message bus", "Events", true, 12, .99, [], "Delivers events between systems."),
            new("store", "Workspace store", "Internal", false, 2, 1, [], "This application's storage. Checked live."),
            new("jobs", "Job workers", "Internal", false, 1, 1, ["store"], "Runs validations and other jobs. Checked live."),
            new("memory", "Memory", "Internal", false, 0, 1, [], "Memory pressure of this process. Checked live."),
        ];

        public static MonitoredService? Find(string id) => Services.FirstOrDefault(s => s.Id.Equals(id, StringComparison.OrdinalIgnoreCase));

        private static readonly (string Code, string Title, string Text, string Severity)[] Causes =
        [
            ("timeout", "Timeouts", "Requests timed out: the connection pool was exhausted under load.", "down"),
            ("http_5xx", "Server errors", "The service answered 503 during a deployment that was rolled back.", "down"),
            ("latency", "Slow responses", "Responses slowed down (p95 above 2 s) during peak hours.", "degraded"),
            ("certificate", "Certificate", "A certificate on the gateway expired, so connections were refused until it was renewed.", "down"),
            ("dns", "Name resolution", "The service host name did not resolve after a network change.", "down"),
            ("latency", "Slow responses", "A slow database query made responses slow until an index was rebuilt.", "degraded"),
        ];

        // ---------------------------------------------------------------- incidents per service and day
        private static int Seed(string service, long day)
        {
            unchecked
            {
                var h = 17;
                foreach (var c in service)
                {
                    h = h * 31 + c;
                }
                return (int)(h * 397 + day * 7919);
            }
        }

        private static long DayOf(DateTimeOffset t) => (long)Math.Floor((t.ToUniversalTime() - DateTimeOffset.UnixEpoch).TotalDays);
        private static DateTimeOffset DayStart(long day) => DateTimeOffset.UnixEpoch.AddDays(day);

        /// <summary>The service's own incidents that start on this day (unplanned and planned), without spread from dependencies.</summary>
        private static List<ServiceIncident> Own(MonitoredService s, long day)
        {
            var list = new List<ServiceIncident>();
            if (!s.Simulated)
            {
                return list;
            }

            var start = DayStart(day);
            // Planned maintenance.
            if (s.Id == "vda" && start.DayOfWeek == DayOfWeek.Sunday)
            {
                list.Add(Make(s, start.AddHours(1), 45, "maintenance", "Planned maintenance", "Weekly planned maintenance: database patching. Announced a week ahead.", "down", true));
            }

            if (s.Id == "edb" && start.DayOfWeek == DayOfWeek.Saturday && start.Day <= 7)
            {
                list.Add(Make(s, start.AddHours(2), 120, "maintenance", "Planned maintenance", "Monthly planned maintenance: storage upgrade.", "degraded", true));
            }
            // Unplanned: fewer for reliable services; more on weekdays.
            var rng = new Random(Seed(s.Id, day));
            var weekday = start.DayOfWeek is not (DayOfWeek.Saturday or DayOfWeek.Sunday);
            var chance = (1 - s.Reliability) * (weekday ? 3.2 : 1.2);   // a few unplanned incidents a month per service
            var count = rng.NextDouble() < chance ? (rng.NextDouble() < .2 ? 2 : 1) : 0;
            for (var i = 0; i < count; i++)
            {
                var cause = Causes[rng.Next(Causes.Length)];
                // Most incidents happen in working hours (07–18 UTC), when load is highest.
                var minute = rng.NextDouble() < .75 ? rng.Next(7 * 60, 18 * 60) : rng.Next(0, 24 * 60);
                var minutes = cause.Severity == "degraded" ? rng.Next(8, 75) : rng.Next(3, 40);
                if (cause.Code == "certificate")
                {
                    minutes = rng.Next(20, 95);
                }

                list.Add(Make(s, start.AddMinutes(minute), minutes, cause.Code, cause.Title, cause.Text, cause.Severity, false));
            }
            return list;
        }

        private static ServiceIncident Make(MonitoredService s, DateTimeOffset start, double minutes, string code, string title, string text, string severity, bool planned,
            string? rootService = null, string? rootIncident = null, string confidence = "direct") =>
            new($"{s.Id}-{start.ToUnixTimeSeconds()}", s.Id, severity, start, start.AddMinutes(minutes), minutes, code, title, text, rootService, rootIncident, planned, confidence, [], [], true);

        /// <summary>All incidents of a service starting on this day: its own, plus failures spread from the services it depends on.</summary>
        public static List<ServiceIncident> ForDay(MonitoredService s, long day)
        {
            var list = Own(s, day);
            foreach (var upId in s.DependsOn)
            {
                var up = Find(upId);
                if (up is null || !up.Simulated)
                {
                    continue;
                }

                foreach (var u in Own(up, day))
                {
                    // Degraded upstream slows this service; a full upstream outage stops it. Planned work on VDA is absorbed
                    // by caches for slow spells, so only real outages spread.
                    if (u.Severity == "degraded" && u.Planned)
                    {
                        continue;
                    }

                    var rng = new Random(Seed(s.Id + "<" + upId, u.Start.ToUnixTimeSeconds()));
                    var lag = rng.Next(1, 3);
                    var severity = u.Severity == "down" && rng.NextDouble() < .7 ? "down" : "degraded";
                    var cause = upId == "identity" ? "Sign-in rejected" : $"{up.Name} unavailable";
                    list.Add(Make(s, u.Start.AddMinutes(lag), u.Minutes + rng.Next(1, 4), "upstream", cause,
                        upId == "identity" ? $"Tokens from the identity provider could not be checked, so {s.Name} rejected requests." : $"{s.Name} depends on {up.Name}, which was {(u.Severity == "down" ? "down" : "slow")}.",
                        severity, false, upId, u.Id, "correlated"));
                }
            }
            return list;
        }

        /// <summary>Incidents that overlap [from, to], with impact lists and timelines filled in.</summary>
        public static IReadOnlyList<ServiceIncident> Incidents(DateTimeOffset from, DateTimeOffset to, string? service = null, DateTimeOffset? asOf = null)
        {
            var all = new List<ServiceIncident>();
            for (var d = DayOf(from) - 1; d <= DayOf(to); d++)
            {
                foreach (var s in Services.Where(x => x.Simulated))
                {
                    all.AddRange(ForDay(s, d));
                }
            }

            all = all.Where(i => i.Start < to && (i.End ?? to) > from).ToList();
            // Impact: the incidents in other services that this one caused.
            var byRoot = all.Where(i => i.RootIncident is not null).GroupBy(i => i.RootIncident!).ToDictionary(g => g.Key, g => g.Select(x => x.Service).Distinct().ToArray());
            var now = asOf ?? DateTimeOffset.UtcNow;
            all = all.Where(i => i.Start <= now).ToList();   // nothing from the future
            return all.Where(i => service is null || i.Service.Equals(service, StringComparison.OrdinalIgnoreCase))
                .Select(i =>
                {
                    var ongoing = i.End > now;
                    var end = ongoing ? null : i.End;
                    var minutes = ongoing ? Math.Max(0, (now - i.Start).TotalMinutes) : i.Minutes;
                    var timeline = new List<IncidentEvent> { new(i.Start, "detected", i.Planned ? "Maintenance window started." : $"Health checks found {Find(i.Service)!.Name} {(i.Severity == "down" ? "not answering" : "slow")}.") };
                    if (!i.Planned && i.Minutes >= 5)
                    {
                        timeline.Add(new(i.Start.AddMinutes(Math.Min(5, i.Minutes / 3)), "notified", "On-call engineer notified."));
                    }

                    if (i.RootService is not null)
                    {
                        timeline.Add(new(i.Start.AddMinutes(1), "correlated", $"Correlated with {Find(i.RootService)!.Name}, which failed first."));
                    }

                    if (!i.Planned && i.Minutes >= 12)
                    {
                        timeline.Add(new(i.Start.AddMinutes(i.Minutes * .6), "mitigated", i.Cause switch { "timeout" => "Connection pool enlarged; traffic recovering.", "http_5xx" => "Deployment rolled back.", "certificate" => "Certificate renewed.", "dns" => "DNS record restored.", "latency" => "Load shed and caches warmed.", _ => "Upstream recovered." }));
                    }

                    if (!ongoing)
                    {
                        timeline.Add(new(i.End!.Value, "resolved", "Checks healthy again."));
                    }

                    return i with { End = end, Minutes = Math.Round(minutes, 1), Impacted = byRoot.GetValueOrDefault(i.Id, []), Timeline = timeline.Where(e => e.At <= now).OrderBy(e => e.At).ToArray() };
                })
                .OrderByDescending(i => i.Start).ToArray();
        }

        // ---------------------------------------------------------------- state at a minute
        /// <summary>The simulated state and response time of a service at one moment.</summary>
        public static ServiceSample At(MonitoredService s, DateTimeOffset t, IReadOnlyList<ServiceIncident>? dayIncidents = null)
        {
            var incidents = dayIncidents ?? ForDay(s, DayOf(t)).Concat(ForDay(s, DayOf(t) - 1)).ToList();
            var hit = incidents.Where(i => i.Start <= t && i.End > t).OrderBy(i => i.Severity == "down" ? 0 : 1).FirstOrDefault();
            var noise = Noise(s.Id, t);
            var peak = t.UtcDateTime.Hour is >= 8 and <= 16 ? 1.25 : 1;   // busier in working hours
            var ms = s.BaseMs * peak * (0.75 + noise * 0.6);
            if (hit is null)
            {
                return new(s.Id, t, "up", Math.Round(ms, 1), null, null);
            }

            return hit.Severity == "down"
                ? new(s.Id, t, "down", hit.Cause is "timeout" ? 10_000 : Math.Round(ms * 0.2, 1), hit.Cause, hit.CauseTitle)
                : new(s.Id, t, "degraded", Math.Round(ms * (3 + noise * 4), 1), hit.Cause, hit.CauseTitle);
        }

        private static double Noise(string id, DateTimeOffset t)
        {
            unchecked
            {
                var x = (uint)(Seed(id, t.ToUnixTimeSeconds() / 60));
                x ^= x << 13;
                x ^= x >> 17;
                x ^= x << 5;
                return (x % 10_000) / 10_000.0;
            }
        }

        /// <summary>History in buckets (one sample per minute, aggregated). Live samples for internal services come from the caller.</summary>
        public static IReadOnlyList<HistoryBucket> History(MonitoredService s, DateTimeOffset from, DateTimeOffset to, TimeSpan bucket, IReadOnlyList<ServiceSample>? live = null)
        {
            var result = new List<HistoryBucket>();
            var cache = new Dictionary<long, List<ServiceIncident>>();
            List<ServiceIncident> DayList(long d)
            {
                if (!cache.TryGetValue(d, out var l))
                {
                    cache[d] = l = ForDay(s, d).Concat(ForDay(s, d - 1)).ToList();
                }
                return l;
            }
            var liveByBucket = live?.GroupBy(x => (long)((x.At - from).Ticks / bucket.Ticks)).ToDictionary(g => g.Key, g => g.ToArray());
            var index = 0L;
            for (var start = from; start < to; start += bucket, index++)
            {
                ServiceSample[] samples;
                if (s.Simulated)
                {
                    var step = bucket.TotalMinutes <= 60 ? TimeSpan.FromMinutes(1) : TimeSpan.FromMinutes(Math.Max(1, bucket.TotalMinutes / 60));
                    var list = new List<ServiceSample>();
                    for (var t = start; t < start + bucket && t < to; t += step)
                    {
                        list.Add(At(s, t, DayList(DayOf(t))));
                    }

                    samples = list.ToArray();
                }
                else
                {
                    samples = liveByBucket is not null && liveByBucket.TryGetValue(index, out var l) ? l : [];
                }

                if (samples.Length == 0)
                {
                    result.Add(new(start, "nodata", 0, 0, 0, 0, 0, 0));
                    continue;
                }
                int up = samples.Count(x => x.Status == "up"), deg = samples.Count(x => x.Status == "degraded"), down = samples.Count(x => x.Status == "down");
                var ms = samples.Where(x => x.Status != "down").Select(x => x.Ms).Order().ToArray();
                var p95 = ms.Length == 0 ? 0 : ms[Math.Min(ms.Length - 1, (int)Math.Ceiling(.95 * ms.Length) - 1)];
                result.Add(new(start, down > 0 ? "down" : deg > 0 ? "degraded" : "up", Math.Round((up + deg * .5) / samples.Length, 4),
                    Math.Round(ms.Length == 0 ? 0 : ms.Average(), 1), Math.Round(p95, 1), up, deg, down));
            }
            return result;
        }

        /// <summary>A sensible bucket for a range: about 120–300 points.</summary>
        public static TimeSpan BucketFor(TimeSpan range) => range.TotalHours switch
        {
            <= 2 => TimeSpan.FromMinutes(1),
            <= 12 => TimeSpan.FromMinutes(5),
            <= 48 => TimeSpan.FromMinutes(15),
            <= 24 * 8 => TimeSpan.FromHours(1),
            <= 24 * 31 => TimeSpan.FromHours(4),
            _ => TimeSpan.FromDays(1),
        };

        public static string Format(DateTimeOffset t) => t.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);
    }
}
