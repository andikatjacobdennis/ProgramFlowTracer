using System.Text.Json.Nodes;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// Evaluate 1.0 and 1.1 (Request.Listener/Development/Evaluate_1_0 and _1_1): node template issues evaluated against the
    /// product. The listener's issue ids are its database ids; the tool has none, so an issue id is a node template document
    /// number of the catalog. Each issue found is answered with its node (BreakdownModuleCommon 1.4 for 1.0, 1.5 for 1.1) and,
    /// when the product's variants do not meet the node template's condition, a NODE TEMPLATE MISMATCH notification. Unknown
    /// issues are left out, as in the listener. When none is known the reply is Rejected; like the listener's own error reply
    /// it has no Issues, which its XSD requires, so the check reports that.
    /// </summary>
    public sealed class EvaluateHandler : ListenerXmlHandler
    {
        private readonly ListenerProducts _products;
        private readonly ICatalog _catalog;

        public EvaluateHandler(ListenerProducts products, ICatalog catalog, TimeProvider clock) : base(clock)
        {
            _products = products;
            _catalog = catalog;
        }

        public override IReadOnlyCollection<string> Keys { get; } = ["Evaluate_1.0", "Evaluate_1.1"];

        private static XNamespace RequestNs(ListenerMessageType type) => "http://esw.volvo.com/evaluaterequest/" + type.Version.Replace('.', '_');

        private static XNamespace ReplyNs(ListenerMessageType type) => "http://esw.volvo.com/evaluateresponse/" + type.Version.Replace('.', '_');

        private static BreakdownXml Bmc(ListenerMessageType type) => new(type.Version == "1.0" ? "1.4" : "1.5");

        protected override async Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct)
        {
            var ns = ReplyNs(message.Type);
            var bmc = Bmc(message.Type);
            var data = ListenerXml.Find(message.Xml, "DataArea");
            var product = await _products.ReadAsync(ListenerXml.Child(data, "Product")!, message.Actor, ct);
            var symbols = product.Product.Data["productSpecification"].A("variants").Objects().Select(v => v.S("symbol")).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var productClass = BreakdownXml.ProductClass(product.Product.Info.S("productClassId"));
            var issues = new List<XElement>();
            var summary = new List<ListenerFact> { product.Source };
            var asked = ListenerXml.Children(data, "Issues").Select(i => ListenerXml.Number(ListenerXml.Text(i, "IssueId")) ?? 0).ToList();
            foreach (var id in asked)
            {
                var found = _catalog.Data.A("templates").Objects().SelectMany(t => ListenerCatalog.Versions(t).Select(v => (Template: t, Version: v))).FirstOrDefault(x => x.Version.I("doc") == id);
                if (found.Version?["node"] is not JsonObject node)
                {
                    summary.Add(new ListenerFact(id.ToString(System.Globalization.CultureInfo.InvariantCulture), "Not a node template document of the catalog: left out."));
                    continue;
                }

                var condition = found.Template.A("condition").Select(c => c?.ToString() ?? "").Where(c => c.Length > 0).ToList();
                var notices = new List<BreakdownNotice>();
                if (condition.Count > 0 && !condition.Any(symbols.Contains))
                {
                    notices.Add(new BreakdownNotice("Warning", "NODE TEMPLATE MISMATCH", $"Node template {id} needs one of the variants {string.Join(", ", condition)}.", "The product does not have a variant the node template's condition needs.", "Check the product's variants."));
                }

                issues.Add(new XElement(ns + "Issues", new XElement(ns + "IssueId", id), bmc.Node(ns + "Node", node, productClass, "", notices)));
                summary.Add(new ListenerFact(id.ToString(System.Globalization.CultureInfo.InvariantCulture), $"{found.Template.S("key")} {found.Version.S("versionName")}" + (notices.Count > 0 ? ": does not match the product's variants." : ".")));
            }

            if (issues.Count == 0)
            {
                throw ListenerFault.Undefined("None of the requested issues is a node template document of the catalog.");
            }

            var root = new XElement(ns + "EvaluateResponse",
                Area(message),
                new XElement(ns + "DataArea", ListenerXml.Accepted(ns), issues));
            summary.Insert(0, new ListenerFact("Outcome", $"{issues.Count} of {asked.Count} issue(s) evaluated."));
            return new ListenerAnswer(root, summary, []);
        }

        protected override XElement Error(ListenerMessage message, ListenerNotice notice, string bodId) =>
            new(ReplyNs(message.Type) + "EvaluateResponse", Area(message, bodId), new XElement(ReplyNs(message.Type) + "DataArea", ListenerXml.Rejected(ReplyNs(message.Type), notice)));

        /// <summary>The node templates the vehicle has now, as issues.</summary>
        public override XDocument Example(ListenerMessageType type, ProductDocument vehicle)
        {
            var ns = RequestNs(type);
            var ids = vehicle.Nodes.Objects().Select(n => n["nodeTemplateDocument"].I("number")).Where(d => d > 0).Take(3).ToList();
            return Document(new XElement(ns + "EvaluateRequest",
                new XAttribute("transactionId", Guid.NewGuid().ToString()),
                new XAttribute("schemaVersion", type.Version),
                ListenerXml.RequestArea(Clock),
                new XElement(ns + "DataArea",
                    ListenerProducts.ProductElement(ns, "Product", vehicle),
                    ids.Select(id => new XElement(ns + "Issues", new XElement(ns + "IssueId", id))),
                    new XElement(ns + "CheckCompatibility", "true"))));
        }

        private XElement Area(ListenerMessage message, string? bodId = null)
        {
            var v = ListenerXml.Volvo;
            return new XElement(v + "ApplicationArea",
                new XElement(v + "Sender", new XElement(v + "LogicalID", "SWBRKDWN")),
                new XElement(v + "CreationDateTime", Clock.GetUtcNow().UtcDateTime.ToString("yyyy-MM-ddTHH:mm:ss.fffZ", System.Globalization.CultureInfo.InvariantCulture)),
                new XElement(v + "BODID", bodId ?? ListenerXml.Transaction(message.Xml)));
        }
    }
}
