using System.Globalization;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// Change impact (one vehicle) and Fleet readiness (every vehicle the user may read). Both are read-only and computed from
    /// records: relationships come from the catalog (a node template's dependsOn and a version's requires), check results come
    /// only from a validation of that exact proposal, and approval only from a review (Reviews). Nothing here is illustrative.
    /// </summary>
    public sealed class ChangeImpact
    {
        private readonly IWorkspaceStore _store;
        private readonly ICatalog _catalog;
        private readonly TimeProvider _clock;

        public ChangeImpact(IWorkspaceStore store, ICatalog catalog, TimeProvider clock)
        {
            _store = store;
            _catalog = catalog;
            _clock = clock;
        }

        // ------------------------------------------------------------------ change impact
        /// <summary>
        /// The graph for one vehicle: the vehicle, its nodes (modules) and their software products, which ones the proposal
        /// changes, and the compatibility relationships that touch a change. The proposal is the given product (the workspace),
        /// or the proposal of the given validation, or none (the vehicle as stored).
        /// </summary>
        public async Task<JsonObject> ImpactAsync(Actor actor, string vehicleId, JsonObject? product, Guid? requestId, CancellationToken ct)
        {
            var current = await _store.VehicleAsync(vehicleId, ct) ?? throw new RequestFault(404, "vehicle_missing", "Vehicle was not found.");
            actor.DemandRead(new ProductDocument(current.Product).ContextId);
            var executions = await _store.ExecutionsForVehicleAsync(vehicleId, actor.Id, ct);
            JsonObject proposal;
            string source;
            if (product is not null)
            {
                var doc = new ProductDocument(product);
                if (doc.Id != vehicleId)
                {
                    throw new RequestFault(400, "vehicle_mismatch", "The proposal is for another vehicle.");
                }

                proposal = doc.Data;
                source = "workspace";
            }
            else if (requestId is Guid rid)
            {
                var record = executions.FirstOrDefault(e => e.Id == rid) ?? throw new RequestFault(404, "request_missing", "Request was not found.");
                proposal = record.Outcomes.First(o => o.VehicleId == vehicleId).Proposal;
                source = "request";
            }
            else
            {
                proposal = current.Product;
                source = "current";
            }

            var hash = CanonicalJson.Hash(proposal);
            // A validation counts only for this exact proposal on the current revision of the vehicle.
            var match = executions.OrderByDescending(e => e.CreatedAt)
                .Select(e => (Record: e, Outcome: e.Outcomes.FirstOrDefault(o => o.VehicleId == vehicleId)))
                .FirstOrDefault(x => x.Outcome is not null && (requestId == x.Record.Id || x.Outcome.ProposalHash == hash || CanonicalJson.Hash(x.Outcome.Input) == hash));
            var validationCurrent = match.Outcome is not null && match.Outcome.BaseRevision == current.Revision;
            var issues = validationCurrent ? match.Outcome!.Issues : [];

            var rows = ProposalDiff.Rows(current.Product, proposal);
            var changedModules = rows.Where(r => r.ModuleKey != "").Select(r => r.ModuleKey).ToHashSet(StringComparer.Ordinal);
            var nodes = proposal.A("nodes").Objects().ToList();
            foreach (var gone in current.Product.A("nodes").Objects().Where(n => !nodes.Any(x => JsonAccess.NodeKeyOf(x) == JsonAccess.NodeKeyOf(n))))
            {
                nodes.Add(gone);
            }

            var byTemplate = nodes.Select(n => (Node: n, Template: _catalog.FindTemplate(n))).Where(x => x.Template is not null)
                .GroupBy(x => x.Template!.S("key")).ToDictionary(g => g.Key, g => JsonAccess.NodeKeyOf(g.First().Node), StringComparer.Ordinal);

            // Relationships: A depends on B (template) or A's version requires B at a minimum catalog version.
            var edges = new JsonArray();
            var checkNeeded = new Dictionary<string, string>(StringComparer.Ordinal);
            foreach (var node in nodes)
            {
                var template = _catalog.FindTemplate(node);
                if (template is null)
                {
                    continue;
                }

                var key = JsonAccess.NodeKeyOf(node);
                var version = _catalog.FindVersion(node);
                var deps = template.A("dependsOn").Select(d => (Key: d?.ToString() ?? "", Min: -1, Kind: "dependsOn"))
                    .Concat(version is null ? [] : version.A("requires").Objects().Select(r => (Key: r.S("key"), Min: r.I("minIdx"), Kind: "requires")))
                    .GroupBy(d => d.Key).Select(g => g.OrderByDescending(d => d.Min).First());
                foreach (var dep in deps)
                {
                    var hasTarget = byTemplate.TryGetValue(dep.Key, out var target);
                    if (!changedModules.Contains(key) && !(hasTarget && changedModules.Contains(target!)))
                    {
                        continue;   // only relationships that touch a change
                    }

                    var targetNode = hasTarget ? nodes.First(n => JsonAccess.NodeKeyOf(n) == target) : null;
                    var targetVersion = targetNode is null ? null : _catalog.FindVersion(targetNode);
                    var minName = dep.Min < 0 ? null : _catalog.Data.A("templates").Objects().FirstOrDefault(t => t.S("key") == dep.Key)?.A("versions").Objects().FirstOrDefault(v => v.I("idx") == dep.Min)?.S("versionName");
                    var ruleOk = targetVersion is not null && (dep.Min < 0 || targetVersion.I("idx", -1) >= dep.Min);
                    var blocked = issues.Any(i => i.Code == "dependency_unsatisfied" && i.Node == node.S("name"));
                    var state = match.Outcome is null || !validationCurrent ? "not-verified" : blocked ? "blocked" : "verified";
                    edges.Add(new JsonObject
                    {
                        ["from"] = key,
                        ["to"] = hasTarget ? target : "missing:" + dep.Key,
                        ["kind"] = dep.Kind,
                        ["state"] = state,
                        ["catalogRuleSatisfied"] = ruleOk,
                        ["rule"] = dep.Min < 0 ? $"{ProposalDiff.Short(node)} depends on {dep.Key}" : $"{ProposalDiff.Short(node)} {node.S("versionName")} needs {minName ?? dep.Key} or later",
                    });
                    foreach (var other in new[] { key, hasTarget ? target! : "missing:" + dep.Key }.Where(k => !changedModules.Contains(k)))
                    {
                        checkNeeded[other] = state;
                    }
                }
            }
            var modules = new JsonArray();
            foreach (var node in nodes)
            {
                var key = JsonAccess.NodeKeyOf(node);
                var removed = !proposal.A("nodes").Objects().Any(n => JsonAccess.NodeKeyOf(n) == key);
                var added = !current.Product.A("nodes").Objects().Any(n => JsonAccess.NodeKeyOf(n) == key);
                var before = current.Product.A("nodes").Objects().FirstOrDefault(n => JsonAccess.NodeKeyOf(n) == key);
                var moduleIssues = issues.Where(i => i.Node == node.S("name")).ToArray();
                var status = removed ? "removed" : added ? "added" : changedModules.Contains(key) ? "changed" : checkNeeded.TryGetValue(key, out var s) ? (s == "verified" ? "verified" : s == "blocked" ? "blocked" : "check") : "unchanged";
                var oldSw = before?.A("softwareProducts").Objects().GroupBy(ProposalDiff.SoftwareName).ToDictionary(g => g.Key, g => g.First(), StringComparer.Ordinal) ?? [];
                modules.Add(new JsonObject
                {
                    ["key"] = key,
                    ["short"] = ProposalDiff.Short(node),
                    ["name"] = node.S("name"),
                    ["architecture"] = node.I("electricalArchitecture") == 3 ? "T3" : "Legacy",
                    ["template"] = _catalog.FindTemplate(node)?.S("key"),
                    ["from"] = before?.S("versionName"),
                    ["to"] = removed ? null : node.S("versionName"),
                    ["hardware"] = node["ecuHardware"].S("number"),
                    ["status"] = status,
                    ["cab"] = node.B("isCabNode"),
                    ["path"] = node.S("nodePath"),
                    ["parts"] = TopologyParts.Of(node, before, added, removed),
                    ["findings"] = new JsonArray(moduleIssues.Select(i => (JsonNode)new JsonObject { ["code"] = i.Code, ["text"] = i.Text, ["blocking"] = i.Severity == 0 }).ToArray()),
                    ["changes"] = ProposalDiff.ToJson(rows.Where(r => r.ModuleKey == key)),
                    ["components"] = new JsonArray(node.A("softwareProducts").Objects().Select(sw =>
                    {
                        var prev = oldSw.GetValueOrDefault(ProposalDiff.SoftwareName(sw));
                        var v = (Func<JsonObject?, string?>)(x => x is null ? null : x.S("packageVersion", x.S("number")));
                        var componentRows = rows.Where(r => r.ModuleKey == key && r.Component == ProposalDiff.Short(node) + " " + ProposalDiff.SoftwareName(sw)).ToArray();
                        return (JsonNode)new JsonObject
                        {
                            ["name"] = ProposalDiff.SoftwareName(sw),
                            ["title"] = ProposalDiff.Short(node) + " " + ProposalDiff.SoftwareName(sw),
                            ["from"] = v(prev),
                            ["to"] = removed ? null : v(sw),
                            ["environment"] = sw.S("executionEnvironment"),
                            ["status"] = prev is null && !added ? "added" : componentRows.Length > 0 ? "changed" : "unchanged",
                            ["changes"] = ProposalDiff.ToJson(componentRows),
                        };
                    }).ToArray()),
                });
            }
            foreach (var missing in checkNeeded.Keys.Where(k => k.StartsWith("missing:", StringComparison.Ordinal)))
            {
                modules.Add(new JsonObject { ["key"] = missing, ["short"] = missing[8..], ["name"] = missing[8..] + " (not on this vehicle)", ["status"] = "missing", ["components"] = new JsonArray(), ["changes"] = new JsonArray(), ["findings"] = new JsonArray() });
            }

            var info = current.Product["productSpecification"]?["productInformation"];
            return new JsonObject
            {
                ["vehicle"] = new JsonObject { ["id"] = vehicleId, ["title"] = ProposalDiff.Title(current.Product), ["architecture"] = ProposalDiff.Architecture(current.Product), ["revision"] = current.Revision, ["context"] = info?["context"].S("name") },
                ["source"] = source,
                ["proposalHash"] = hash,
                ["validation"] = match.Outcome is null ? null : new JsonObject
                {
                    ["requestId"] = match.Record.Id,
                    ["at"] = match.Record.CreatedAt.ToString("O", CultureInfo.InvariantCulture),
                    ["current"] = validationCurrent,
                    ["blocking"] = match.Outcome.Issues.Count(i => i.Severity == 0),
                    ["notes"] = match.Outcome.Issues.Count(i => i.Severity > 0),
                    ["limited"] = match.Outcome.LimitedValidation,
                },
                ["counts"] = new JsonObject { ["changes"] = rows.Count, ["changedModules"] = changedModules.Count, ["checks"] = checkNeeded.Count, ["unverified"] = checkNeeded.Values.Count(v => v == "not-verified") },
                ["modules"] = modules,
                ["edges"] = edges,
                ["changes"] = ProposalDiff.ToJson(rows),
            };
        }

        // ------------------------------------------------------------------ fleet readiness
        /// <summary>
        /// For every vehicle the user may read: the state of software, hardware, dependency and parameter checks from the user's
        /// latest validation of it, its approval from the review, and overall readiness. A validation based on an older vehicle
        /// revision is stale (unless that revision is the one this review submitted); no validation is unknown.
        /// Readiness needs current checks without blockers and an approval for the same validation.
        /// </summary>
        public async Task<JsonObject> ReadinessAsync(Actor actor, CancellationToken ct)
        {
            var vehicles = (await _store.VehiclesAsync(ct)).Where(v => actor.Contexts.Contains(new ProductDocument(v.Product).ContextId)).ToArray();
            var reviews = await _store.ReviewsAsync(500, ct);
            var list = new JsonArray();
            var groups = new Dictionary<int, string>();
            foreach (var v in vehicles.OrderBy(v => ProposalDiff.Title(v.Product), StringComparer.Ordinal))
            {
                var doc = new ProductDocument(v.Product);
                groups[doc.ContextId] = doc.Info["context"].S("name", "Context " + doc.ContextId);
                var latest = (await _store.ExecutionsForVehicleAsync(doc.Id, actor.Id, ct)).OrderByDescending(e => e.CreatedAt).FirstOrDefault();
                var outcome = latest?.Outcomes.FirstOrDefault(o => o.VehicleId == doc.Id);
                var review = latest is null ? null : reviews.Where(r => r.RequestId == latest.Id).OrderByDescending(r => r.CreatedAt).FirstOrDefault();
                var submittedRevision = review?.Submission?.Vehicles.FirstOrDefault(x => x.VehicleId == doc.Id)?.ToRevision;
                var stale = outcome is not null && outcome.BaseRevision != v.Revision && submittedRevision != v.Revision;
                var cells = new JsonObject();
                foreach (var cat in new[] { "software", "hardware", "dependencies", "parameters" })
                {
                    var found = outcome?.Issues.Where(i => ProposalDiff.Category(i.Code) == cat).ToArray() ?? [];
                    cells[cat] = new JsonObject
                    {
                        ["state"] = outcome is null ? "unknown" : stale ? "stale" : found.Any(i => i.Severity == 0) ? "blocked" : "pass",
                        ["findings"] = new JsonArray(found.Select(i => (JsonNode)new JsonObject { ["code"] = i.Code, ["text"] = i.Text, ["node"] = i.Node, ["blocking"] = i.Severity == 0 }).ToArray()),
                    };
                }
                var approval = outcome is null ? "not-ready" : stale ? "expired" : review?.Status switch
                {
                    "approved" => "approved",
                    "submitted" => "submitted",
                    "open" => "pending",
                    "changes_requested" => "changes",
                    _ => "not-requested",
                };
                var blocked = cells.Any(c => c.Value!["state"]!.GetValue<string>() == "blocked");
                var overall = outcome is null ? "unknown" : stale ? "stale" : blocked ? "blocked" : approval is "approved" or "submitted" ? "ready" : "pending";
                cells["approval"] = new JsonObject { ["state"] = approval, ["by"] = review?.Decision?.ActorName, ["at"] = review?.Decision?.At.ToString("O", CultureInfo.InvariantCulture), ["reviewId"] = review?.Id };
                cells["overall"] = new JsonObject { ["state"] = overall };
                list.Add(new JsonObject
                {
                    ["id"] = doc.Id,
                    ["title"] = ProposalDiff.Title(v.Product),
                    ["architecture"] = ProposalDiff.Architecture(v.Product),
                    ["context"] = new JsonObject { ["id"] = doc.ContextId, ["name"] = groups[doc.ContextId] },
                    ["revision"] = v.Revision,
                    ["requestId"] = latest?.Id,
                    ["requestKind"] = latest?.Kind.ToString(),
                    ["validatedAt"] = latest?.CreatedAt.ToString("O", CultureInfo.InvariantCulture),
                    ["basedOnRevision"] = outcome?.BaseRevision,
                    ["proposalRevision"] = review?.ProposalRevision,
                    ["reviewId"] = review?.Id,
                    ["cells"] = cells,
                    ["canRevalidate"] = latest?.Options is not null || latest is null,
                });
            }
            return new JsonObject
            {
                ["generatedAt"] = _clock.GetUtcNow().ToString("O", CultureInfo.InvariantCulture),
                ["groups"] = new JsonArray(groups.OrderBy(g => g.Value, StringComparer.Ordinal).Select(g => (JsonNode)new JsonObject { ["id"] = g.Key, ["name"] = g.Value }).ToArray()),
                ["vehicles"] = list,
            };
        }

        /// <summary>
        /// The request to validate a vehicle again: the options of the user's latest validation of it with the stored vehicle,
        /// or a software refresh when it has never been validated. Used by "Validate selected" (through a batch run).
        /// </summary>
        public async Task<JsonObject> RevalidationAsync(Actor actor, string vehicleId, CancellationToken ct)
        {
            var current = await _store.VehicleAsync(vehicleId, ct) ?? throw new RequestFault(404, "vehicle_missing", "Vehicle was not found.");
            actor.DemandRead(new ProductDocument(current.Product).ContextId);
            var latest = (await _store.ExecutionsForVehicleAsync(vehicleId, actor.Id, ct)).OrderByDescending(e => e.CreatedAt).FirstOrDefault(e => e.Options is not null);
            var outcome = latest?.Outcomes.FirstOrDefault(o => o.VehicleId == vehicleId);
            var payload = latest?.Options is JsonObject o ? (JsonObject)o.DeepClone() : new JsonObject { ["softwareRequestOperation"] = (int)SoftwareOperation.Refresh, ["scenario"] = 1 };
            // The same proposal on the current revision: the vehicle as stored now with the proposal's changes is what the handler gets.
            payload["products"] = new JsonArray(((JsonObject?)outcome?.Input ?? current.Product).DeepClone());
            return new JsonObject { ["kind"] = (latest?.Kind ?? RequestKind.Software).ToString(), ["payload"] = payload };
        }
    }
}
