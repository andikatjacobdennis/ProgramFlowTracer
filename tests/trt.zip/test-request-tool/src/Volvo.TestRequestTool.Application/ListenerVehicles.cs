using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The vehicles a listener message asks about. The real listener reads the product from its own databases; the tool reads
    /// it from its repository, by chassis series and number. A vehicle outside the sender's vehicle contexts is not found,
    /// the same answer as a vehicle that does not exist, so a message never shows what the person may not read.
    /// </summary>
    public sealed class ListenerVehicles
    {
        private readonly IWorkspaceStore _store;

        public ListenerVehicles(IWorkspaceStore store)
        {
            _store = store;
        }

        public async Task<ProductDocument?> FindAsync(string? series, string? number, Actor actor, CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(series) || string.IsNullOrWhiteSpace(number))
            {
                return null;
            }

            string key;
            try
            {
                key = VehicleIdentity.Key(series.Trim(), number.Trim());
            }
            catch (RequestFault)
            {
                return null;
            }

            var stored = await _store.VehicleAsync(key, ct);
            if (stored is null)
            {
                return null;
            }

            var product = new ProductDocument(stored.Product);
            return actor.Contexts.Contains(product.ContextId) ? product : null;
        }

        /// <summary>
        /// The S-notes of every vehicle in the repository: the S-notes the tool knows. Only their ids are used, so no vehicle
        /// a person may not read is shown.
        /// </summary>
        public async Task<HashSet<string>> SNotesAsync(CancellationToken ct) =>
            (await _store.VehiclesAsync(ct)).SelectMany(v => new ProductDocument(v.Product).Data["productSpecification"].A("sNotes").Objects().Select(n => n.S("value")))
                .Where(n => n.Length > 0).ToHashSet(StringComparer.OrdinalIgnoreCase);

        /// <summary>The vehicles the sender may read, for building example requests.</summary>
        public async Task<IReadOnlyList<ProductDocument>> ReadableAsync(Actor actor, CancellationToken ct) =>
            (await _store.VehiclesAsync(ct)).Select(v => new ProductDocument(v.Product)).Where(p => actor.Contexts.Contains(p.ContextId)).OrderBy(p => p.Id, StringComparer.Ordinal).ToList();
    }
}
