namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// Simulates the listener's handler for one or more message types (<see cref="Keys"/>, for example GetKitEvaluation_2.1).
    /// The dispatcher has already checked the request against its contract, and checks the reply after. A request that
    /// fails the check goes to <see cref="Reject"/>, which answers the way the listener does: with the contract's own error
    /// reply where it has one (for example a Show with Rejected), otherwise with an empty body.
    /// </summary>
    public interface IListenerHandler
    {
        IReadOnlyCollection<string> Keys { get; }

        ValueTask<ListenerReply> HandleAsync(ListenerMessage message, CancellationToken ct);

        ListenerReply Reject(ListenerMessage message, ListenerNotice notice);
    }
}
