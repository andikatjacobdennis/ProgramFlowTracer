using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    public sealed class BreakdownHandler : IRequestHandler
    {
        private readonly ICatalog _catalog;
        private readonly RequestKind _kind;

        public BreakdownHandler(ICatalog catalog, RequestKind kind)
        {
            _catalog = catalog;
            _kind = kind;
        }

        public RequestKind Kind => _kind;

        public ValueTask<HandlerResult> HandleAsync(ProductDocument original, JsonObject payload, CancellationToken ct)
        {
            var p = original.Copy();
            var issues = new List<ValidationIssue>();
            JsonObject? baseline = null;
            if (_kind == RequestKind.DevelopmentBreakdown)
            {
                baseline = _catalog.Data.A("baselines").Objects().FirstOrDefault(b => b.S("identifier").Equals(payload.S("baselineIdentifier"), StringComparison.OrdinalIgnoreCase) && (string.IsNullOrEmpty(payload.S("baselineVersion")) || b.S("version") == payload.S("baselineVersion")));
                if (baseline is null || baseline.I("contextId") != p.ContextId)
                {
                    return ValueTask.FromResult(new HandlerResult(p, [new("baseline_missing", "Select a baseline in the vehicle context.")]));
                }
            }
            if (_kind == RequestKind.ProductionBreakdown)
            {
                var factory = payload.S("assemblyFactoryCode");
                if (string.IsNullOrEmpty(factory))
                {
                    factory = p.Info.S("assemblyFactoryCode");
                }

                if (!_catalog.Data.A("factories").Objects().Any(f => f.S("code") == factory))
                {
                    throw new RequestFault(400, "factory_required", "Select a documented assembly factory.");
                }
            }
            var week = payload.S("introductionWeek", p.Info.S("introductionWeek"));
            if (_kind == RequestKind.ProductionBreakdown && (week.Length != 6 || !int.TryParse(week, out _)))
            {
                throw new RequestFault(400, "invalid_week", "Introduction week must be YYYYWW.");
            }

            p.Nodes.Clear();
            p.Parameters.Clear();
            var variants = p.Data["productSpecification"]!.A("variants").Objects().Select(v => v.S("symbol")).ToHashSet(StringComparer.OrdinalIgnoreCase);
            foreach (var template in _catalog.Templates(p.ContextId))
            {
                ct.ThrowIfCancellationRequested();
                var conditions = template.A("condition");
                if (conditions.Count > 0 && !conditions.Any(v => variants.Contains(v?.ToString() ?? "")))
                {
                    continue;
                }

                JsonObject? version = baseline is null ? template.A("versions").Objects().Where(v => string.CompareOrdinal(v.S("introductionWeek"), week) <= 0 && (v.S("status") is "released" or "introduced" || (payload.B("includePreReleasedSNotes") && v.S("status") == "prereleaseverification"))).OrderByDescending(v => v.I("idx")).FirstOrDefault() : template.A("versions").Objects().FirstOrDefault(v => v.I("idx") == baseline["ntps"].I(template.S("key"), -1));
                if (version is null)
                {
                    issues.Add(new("template_unavailable", "No template is available for " + template.S("key"), 1));
                    continue;
                }
                p.Nodes.Add(version["node"]!.DeepClone());
                foreach (var parameter in version.A("parameters").Objects())
                {
                    if (!p.Parameters.Objects().Any(x => x.S("code") == parameter.S("code") && x.I("electricalArchitecture") == parameter.I("electricalArchitecture")))
                    {
                        p.Parameters.Add(parameter.DeepClone());
                    }
                }
            }
            if (baseline is not null)
            {
                p.Info["baselineName"] = baseline.S("name");
                p.Info["baselineGuid"] = baseline.S("guid");
            }
            return ValueTask.FromResult(new HandlerResult(p, issues));
        }
    }
}
