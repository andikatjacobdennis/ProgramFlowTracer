using System.Globalization;
using System.Text.Json.Nodes;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The software bill of material of the Production and Development replies, in BreakdownModuleCommon 1.4 to 2.0
    /// (http://esw.volvo.com/breakdownmodulecommon/1_4 … 2_0): nodes with their hardware, software and data slots, the
    /// parameters, the baseline, and notifications. Every item carries a Source with the product class and the baseline.
    /// TEA2+ nodes are named by family, type and position; TEA2 and BEA2 body nodes by MID. In 2.0 the T3 (HPC) nodes are
    /// HpcNodes, each with its virtual TEA2+ node; before 2.0 they are written as TEA2+ nodes with their software products
    /// as main software slots. Version differences followed: 1.4 software items carry a Quantity, later ones do not. 2.1
    /// has the 2.0 shape in the 2.1 namespace, as the listener's 2.1 code writes it (its XSD is not among the contracts).
    /// </summary>
    public sealed class BreakdownXml
    {
        private readonly string _version;

        public BreakdownXml(string version)
        {
            _version = version;
            Ns = "http://esw.volvo.com/breakdownmodulecommon/" + version.Replace('.', '_');
        }

        public XNamespace Ns { get; }

        private bool V20 => _version is "2.0" or "2.1";

        private bool SoftwareQuantity => _version == "1.4";

        /// <summary>The SoftwareBillOfMaterial element (named in the reply's namespace) for the product's nodes and parameters.</summary>
        public XElement Bom(XName name, ProductDocument product, string baseline, IReadOnlyDictionary<string, List<BreakdownNotice>>? nodeNotices = null)
        {
            var productClass = ProductClass(product.Info.S("productClassId"));
            var nodes = product.Nodes.Objects().ToList();
            var hpc = V20 ? nodes.Where(n => n.I("electricalArchitecture") == 3).ToList() : [];
            var plain = nodes.Except(hpc).OrderBy(n => n["nodeIdentifier"].I("family") == 0 ? 1 : 0).ThenBy(n => n["nodeIdentifier"].I("family")).ThenBy(n => n["nodeIdentifier"].I("type")).ThenBy(n => n["nodeIdentifier"].I("mid")).ToList();
            return new XElement(name,
                new XElement(Ns + "Nodes", plain.Select(n => Node(Ns + "Node", n, productClass, baseline, nodeNotices?.GetValueOrDefault(JsonAccess.NodeKeyOf(n))))),
                V20 ? new XElement(Ns + "HpcNodes", hpc.Select(n => HpcNode(n, productClass, baseline))) : null,
                new XElement(Ns + "Parameters", product.Parameters.Objects().Where(p => System.Text.RegularExpressions.Regex.IsMatch(p.S("code"), "^[A-Z0-9]{2,5}$"))
                    .OrderBy(p => p.S("code"), StringComparer.Ordinal).Select(p => Parameter(p, productClass, baseline))),
                new XElement(Ns + "Baseline", baseline));
        }

        /// <summary>A Notifications element (named in the caller's namespace), or null when there are none.</summary>
        public XElement? Notifications(XName name, IEnumerable<BreakdownNotice> notices)
        {
            var list = notices.ToList();
            return list.Count == 0 ? null : new XElement(name, list.Select(Notification));
        }

        public XElement Notification(BreakdownNotice notice) => Notification(Ns, notice);

        /// <summary>A notification (the NotificationType of BreakdownModuleCommon and ServiceConfiguratorCommon) in a namespace.</summary>
        public static XElement Notification(XNamespace ns, BreakdownNotice notice) =>
            new(ns + "Notification",
                new XElement(ns + "ID", Guid.NewGuid().ToString().ToUpperInvariant()),
                new XElement(ns + "Timestamp", DateTime.UtcNow.ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture)),
                new XElement(ns + "Severity", notice.Severity),
                new XElement(ns + "Type", notice.Type),
                new XElement(ns + "Text", notice.Text),
                new XElement(ns + "Reason", notice.Reason),
                new XElement(ns + "Action", notice.Action),
                notice.Details is null ? null : new XElement(ns + "Details", Notification(ns, notice.Details)));

        /// <summary>A node identification: NodeName (family, type, position) for TEA2+ and T3, MID for TEA2 and BEA2 body.</summary>
        public XElement Identification(XName name, JsonObject node)
        {
            var id = node["nodeIdentifier"];
            return new XElement(name, id.I("family") > 0
                ? NodeName(Ns + "NodeName", node)
                : new XElement(Ns + "MID", id.I("mid").ToString("000", CultureInfo.InvariantCulture)));
        }

        public XElement NodeName(XName name, JsonObject node)
        {
            var id = node["nodeIdentifier"];
            return new XElement(name,
                new XElement(Ns + "NodeFamily", id.I("family")),
                new XElement(Ns + "NodeType", id.I("type")),
                new XElement(Ns + "NodePosition", Math.Max(0, id.I("position"))));
        }

        /// <summary>The product class as the contracts write it: exactly two characters ("00" when the tool's class is longer).</summary>
        public static string ProductClass(string productClass) => productClass.Length == 2 ? productClass : "00";

        /// <summary>One node (bmc NodeType) under the given element name, with its notifications.</summary>
        public XElement Node(XName name, JsonObject node, string productClass, string baseline, List<BreakdownNotice>? notices)
        {
            var ea = node.I("electricalArchitecture");
            var document = node["nodeTemplateDocument"].I("number");
            return new XElement(name,
                Identification(Ns + "NodeIdentification", node),
                new XElement(Ns + "NodeArchitecture", ea switch { 0 => "TEA2", 2 => "BEA2Body", _ => "TEA2+" }),
                document > 0 ? new XElement(Ns + "NodeVersion", new XElement(Ns + "DocumentNumber", ListenerXml.PartNumber(document)), Source(productClass, baseline, null)) : null,
                notices is { Count: > 0 } ? new XElement(Ns + "Notifications", notices.Select(Notification)) : null,
                HardwareSlot(node, productClass, baseline),
                SoftwareSlots(node, productClass, baseline),
                DataSlots(node, productClass, baseline));
        }

        private XElement HpcNode(JsonObject node, string productClass, string baseline) =>
            new(Ns + "HpcNode",
                NodeName(Ns + "NodeIdentification", node),
                HardwareSlot(node, productClass, baseline),
                new XElement(Ns + "VirtualTea2PlusNodes", new XElement(Ns + "VirtualTea2PlusNode",
                    NodeName(Ns + "NodeName", node),
                    new XElement(Ns + "NodeVersion", new XElement(Ns + "DocumentNumber", ListenerXml.PartNumber(node["nodeTemplateDocument"].I("number"))), Source(productClass, baseline, null)),
                    SoftwareSlots(node, productClass, baseline))));

        private XElement HardwareSlot(JsonObject node, string productClass, string baseline)
        {
            var hardware = node["ecuHardware"].I("number");
            return new XElement(Ns + "HardwareSlot",
                new XElement(Ns + "Type", "HW"),
                new XElement(Ns + "Name", node["nodeIdentifier"].S("name") + " Hardware"),
                new XElement(Ns + "Quantity", 1),
                hardware > 0
                    ? new XElement(Ns + "Filled", new XElement(Ns + "Item", new XElement(Ns + "ItemNumber", ListenerXml.PartNumber(hardware)), new XElement(Ns + "Quantity", 1), Source(productClass, baseline, null)))
                    : new XElement(Ns + "Empty"));
        }

        /// <summary>The software slots of a node: bootloaders and main software (TEA2+), main software, downloader and sub software
        /// (TEA2), main software and software functions (BEA2 body), the software products (T3).</summary>
        private XElement SoftwareSlots(JsonObject node, string productClass, string baseline)
        {
            var slots = new List<XElement>();
            void Add(string type, string name, JsonNode? part)
            {
                if (part.I("number") > 0)
                {
                    slots.Add(SoftwareSlot("Slot", type, name, part.I("number"), productClass, baseline));
                }
            }

            Add("PBL", "Primary Bootloader", node["primaryBootloader"]);
            Add("SBL", "Secondary Bootloader", node["secondaryBootloader"]);
            Add("MSW", "Main Software", node["mainSoftware"]);
            Add("DWN", "Downloader", node["downloader"]);
            foreach (var (product, i) in node.A("softwareProducts").Objects().Select((p, i) => (p, i)))
            {
                Add("MSW", product.S("name").Length > 0 ? product.S("name") : "Software " + (i + 1), product);
            }

            foreach (var (function, i) in node.A("softwareFunctions").Objects().Select((p, i) => (p, i)))
            {
                Add("SWF", "Software Function " + (i + 1), function);
            }

            foreach (var (sub, i) in node.A("subSoftwares").Objects().Select((p, i) => (p, i)))
            {
                Add("SUBSW", "Sub Software " + (i + 1), sub);
            }

            foreach (var (complementary, i) in node.A("complementarySoftwares").Objects().Select((p, i) => (p, i)))
            {
                Add("CSW", "Complementary Software " + (i + 1), complementary);
            }

            if (slots.Count == 0)
            {
                // SoftwareSlots needs a slot: a node without software has its main software slot empty.
                slots.Add(new XElement(Ns + "Slot", new XElement(Ns + "Type", "MSW"), new XElement(Ns + "Name", "Main Software"), SoftwareQuantity ? new XElement(Ns + "Quantity", 1) : null, new XElement(Ns + "Empty")));
            }

            return new XElement(Ns + "SoftwareSlots", slots);
        }

        private XElement? DataSlots(JsonObject node, string productClass, string baseline)
        {
            var parts = node.A("datas").Objects().Select((d, i) => (Name: d.S("name").Length > 0 ? d.S("name") : "Data " + (i + 1), Part: (JsonNode?)d))
                .Concat(new[] { ("Data Set 1", node["dataSet1"]), ("Data Set 2", node["dataSet2"]) })
                .Concat(node.A("subDataSets").Objects().Select((d, i) => ("Sub Data Set " + (i + 1), (JsonNode?)d)))
                .Where(x => x.Item2.I("number") > 0).Select(x => (Name: x.Item1, Part: x.Item2)).ToList();
            return parts.Count == 0 ? null : new XElement(Ns + "DataSlots", parts.Select(p => SoftwareSlot("DataSlot", "DATA", p.Name, p.Part.I("number"), productClass, baseline)));
        }

        private XElement SoftwareSlot(string element, string type, string name, int number, string productClass, string baseline) =>
            new(Ns + element,
                new XElement(Ns + "Type", type),
                new XElement(Ns + "Name", name),
                SoftwareQuantity ? new XElement(Ns + "Quantity", 1) : null,
                new XElement(Ns + "Filled", new XElement(Ns + "Item",
                    new XElement(Ns + "ItemNumber", ListenerXml.PartNumber(number)),
                    SoftwareQuantity ? new XElement(Ns + "Quantity", 1) : null,
                    Source(productClass, baseline, null))));

        private XElement Parameter(JsonObject parameter, string productClass, string baseline)
        {
            var value = parameter.A("references").Objects().FirstOrDefault().S("value");
            var typed = parameter.I("electricalArchitecture") == 0
                ? new XElement(Ns + "TEA2Value", value)
                : new XElement(Ns + "Value", new XElement(ProductsUpdateWriter.Val + "String", value));
            return new XElement(Ns + "Parameter",
                new XElement(Ns + "ParameterCode", parameter.S("code")),
                new XElement(Ns + "ParameterValue", typed, Source(productClass, baseline, null)));
        }

        private XElement Source(string productClass, string baseline, int? item) =>
            new(Ns + "Source",
                new XElement(Ns + "ProductClass", productClass),
                baseline.Length > 0 ? new XElement(Ns + "Baseline", baseline) : null,
                item is > 0 ? new XElement(Ns + "ItemNumber", ListenerXml.PartNumber(item.Value)) : null);
    }
}
