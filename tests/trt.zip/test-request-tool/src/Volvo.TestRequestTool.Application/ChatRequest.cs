namespace Volvo.TestRequestTool.Application
{
    public sealed record ChatRequest(IReadOnlyList<AssistantMessage> Messages, RetrievedContext Context);
}
