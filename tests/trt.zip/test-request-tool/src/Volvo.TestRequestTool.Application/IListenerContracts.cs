using System.Xml.Linq;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>The listener's message types and their XML contracts (the XSDs of SoftwareBreakdown.Contracts).</summary>
    public interface IListenerContracts
    {
        IReadOnlyList<ListenerMessageType> MessageTypes { get; }

        ListenerMessageType? Find(string messageType, string version);

        /// <summary>What does not follow the contract, one line per problem; empty when the document is valid.</summary>
        IReadOnlyList<string> Validate(ListenerContract contract, XDocument document);

        /// <summary>The smallest document the contract accepts: required elements and attributes only, with example values.</summary>
        XDocument Sample(ListenerContract contract);

        /// <summary>The text of one XSD, or null when there is no such file.</summary>
        string? Schema(string file);
    }
}
