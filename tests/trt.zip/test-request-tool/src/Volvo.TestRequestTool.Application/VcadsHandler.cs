using System.Globalization;
using System.Text.Json.Nodes;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The VCADS 1.0 message types (Request.Listener/VCADS_1_0), all in one contract (VCADS-1.0.1, http://www.volvo.com/VCADS/1_0).
    /// VCADS names computers by MID and parts by field number, as TEA2 does. The catalog has field numbers for TEA2 and BEA2
    /// body parts; for TEA2+ and T3 parts the tool numbers the slots itself: ECU 1, node template (NTP) 2, main software 10…,
    /// downloader or primary bootloader 20, sub software 30…, data sets 40…, complementary software 50…, sub data sets 60…,
    /// software functions 70….
    /// <list type="bullet">
    /// <item><b>Software replacement</b> (and the complete vehicle and TestRequest versions): the requested computers updated
    /// by the tool's SoftwareHandler, as a Workflow with one step per computer and its part, parameter (TEA2) operations.</item>
    /// <item><b>Hardware replacement</b>: per requested computer, the other ECU hardware that a kit of the catalog fits.</item>
    /// <item><b>Kit information</b> (and complete vehicle): per kit, the step the kit makes: the computers it affects and its
    /// part, variant, S-note and parameter operations.</item>
    /// <item><b>Complete vehicle</b>: the vehicle with its parts, parameters, variants and S-notes.</item>
    /// </list>
    /// The vehicle is the one in the repository by chassis; the complete vehicle versions read the parts as the request gives
    /// them. Replies are the bare Workflow, HardwareResponse or CompleteVehicle, with CamsResult Ok, or the listener's error
    /// code (Failed, VDA_ChassisMissing, Configurator_Internal …) and "Message: " text. The TestRequest versions also allow
    /// what the introduction date set scenario allows (as in the listener, the software replacement one does not).
    /// </summary>
    public sealed class VcadsHandler : ListenerXmlHandler
    {
        private static readonly XNamespace Ns = "http://www.volvo.com/VCADS/1_0";
        private static readonly XNamespace Xsi = "http://www.w3.org/2001/XMLSchema-instance";
        private readonly ListenerVehicles _vehicles;
        private readonly ListenerCatalog _catalog;
        private readonly SoftwareHandler _software;

        public VcadsHandler(ListenerVehicles vehicles, ListenerCatalog catalog, TimeProvider clock) : base(clock)
        {
            _vehicles = vehicles;
            _catalog = catalog;
            _software = new SoftwareHandler(catalog.Catalog, clock);
        }

        public override IReadOnlyCollection<string> Keys { get; } = new[]
        {
            "SoftwareReplacement", "TestRequestSoftwareReplacement", "CompleteVehicleSoftwareReplacement", "TestRequestCompleteVehicleSoftwareReplacement",
            "HardwareReplacement", "TestRequestHardwareReplacement", "KitInformation", "TestRequestKitInformation", "CompleteVehicleKitInformation", "CompleteVehicle",
        }.Select(k => "GetVCADS" + k + "_1.0").ToArray();

        private static string Operation(ListenerMessageType type) => type.MessageType.Replace("GetVCADS", "", StringComparison.Ordinal).Replace("TestRequest", "", StringComparison.Ordinal);

        /// <summary>The scenario: introduced, or the introduction date set for the TestRequest versions (but not for software replacement).</summary>
        private static int Scenario(ListenerMessageType type) => type.MessageType.Contains("TestRequest", StringComparison.Ordinal) && type.MessageType != "GetVCADSTestRequestSoftwareReplacement" ? 2 : 1;

        protected override async Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct)
        {
            var root = message.Xml!.Root!;
            var summary = new List<ListenerFact>();
            switch (Operation(message.Type))
            {
                case "CompleteVehicle":
                    {
                        var vehicle = await Stored(root, message.Actor, validate: false, ct);
                        summary.Add(new ListenerFact("Outcome", $"{Shown(vehicle)}: {vehicle.Nodes.Count} computer(s), {vehicle.Parameters.Count} parameter(s)."));
                        return new ListenerAnswer(CompleteVehicle(vehicle), summary, []);
                    }

                case "HardwareReplacement":
                    {
                        var basic = Child(root, "basicVehicle");
                        Validate(basic);
                        var parts = Children(Child(Child(root, "hardwareRequest"), "HardwareRequestParts"), "HardwareRequestPart").ToList();
                        var answer = new List<XElement>();
                        foreach (var part in parts)
                        {
                            var mid = Int(part, "Mid");
                            var number = Int(part, "Number");
                            var options = HardwareOptions(mid, number, Scenario(message.Type));
                            summary.Add(new ListenerFact($"MID {mid}", options.Count == 0 ? $"No other hardware for {number}." : $"{options.Count} other hardware: " + string.Join(", ", options.Select(o => $"{o.Number} (kits {string.Join(", ", o.Kits)})")) + "."));
                            answer.Add(new XElement(Ns + "HardwareResponsePart",
                                new XElement(Ns + "FieldNumber", Int(part, "FieldNumber")), new XElement(Ns + "Mid", mid), new XElement(Ns + "Number", number), Text(Ns + "Prefix", ListenerXml.Text(part, "Prefix")),
                                new XElement(Ns + "HardwareReplacementParts", options.Select((o, i) => new XElement(Ns + "HardwareReplacementPart",
                                    new XElement(Ns + "Kitparts", o.Kits.Select(k => new XElement(Ns + "int", k))), new XElement(Ns + "Number", o.Number), new XElement(Ns + "SortOrder", i + 1))))));
                        }

                        summary.Insert(0, new ListenerFact("Outcome", $"{parts.Count} computer(s) asked about."));
                        return new ListenerAnswer(new XElement(Ns + "HardwareResponse", Namespaces, Cams(null), new XElement(Ns + "HardwareResponseParts", answer)), summary, []);
                    }

                case "KitInformation" or "CompleteVehicleKitInformation":
                    {
                        var vehicle = Operation(message.Type) == "KitInformation" ? await Stored(root, message.Actor, validate: true, ct) : await FromCompleteVehicle(root, message.Actor, ct);
                        var kits = Children(Child(Child(root, "kitRequest"), "KitParts"), "int").Select(k => ListenerXml.Number(k.Value.Trim()) ?? 0).ToList();
                        var steps = new List<XElement>();
                        ListenerFault? first = null;
                        foreach (var kit in kits)
                        {
                            if (kit <= 0)
                            {
                                throw new ListenerFault(1001, "Failed", $"Conversion kit number {kit} is not valid.");
                            }

                            try
                            {
                                var result = _catalog.ApplyKit(vehicle, kit, Scenario(message.Type), serviceKitsOnly: false);
                                var patch = Patch(vehicle, result.After);
                                var mids = result.Assigned.Select(a => a.Node).Concat(result.Removed).Select(n => n["nodeIdentifier"].I("mid")).Where(m => m > 0).Distinct().Order().ToList();
                                steps.Add(Step(kit, mids, patch));
                                summary.Add(new ListenerFact($"Kit {ListenerXml.PartNumber(kit)}", $"{result.Kit.S("name")}: affects MID {string.Join(", ", mids)}."));
                            }
                            catch (ListenerFault fault)
                            {
                                first ??= fault;
                                summary.Add(new ListenerFact($"Kit {ListenerXml.PartNumber(kit)}", "Skipped: " + fault.Message));
                            }
                        }

                        if (first is not null && steps.Count == 0)
                        {
                            throw new ListenerFault(1001, "Failed", first.Message);
                        }

                        summary.Insert(0, new ListenerFact("Outcome", $"{steps.Count} of {kits.Count} kit(s) apply to {Shown(vehicle)}."));
                        return new ListenerAnswer(Workflow(kits.Count == 0 ? null : steps), summary, []);
                    }

                default:
                    {
                        var complete = Operation(message.Type) == "CompleteVehicleSoftwareReplacement";
                        var vehicle = complete ? await FromCompleteVehicle(root, message.Actor, ct) : await Stored(root, message.Actor, validate: true, ct);
                        var requests = Children(Child(root, "softwareRequests"), "SoftwareRequest").ToList();
                        if (!complete)
                        {
                            Apply(vehicle, requests);
                        }

                        var mids = requests.Select(Mid).Where(m => m > 0).Distinct().ToList();
                        var nodes = mids.Select(m => vehicle.Nodes.Objects().FirstOrDefault(n => n["nodeIdentifier"].I("mid") == m)
                            ?? throw new ListenerFault(1001, "Failed", $"Mid {m} is not a computer of {Shown(vehicle)}.")).OrderBy(n => n.S("name"), StringComparer.Ordinal).ToList();
                        var payload = new JsonObject
                        {
                            ["softwareRequestOperation"] = 3,
                            ["scenario"] = Scenario(message.Type),
                            ["pblUpdateCapable"] = true,
                            ["requestedNodes"] = new JsonArray(nodes.Select(n => (JsonNode)new JsonObject { ["nodeIdentifier"] = n["nodeIdentifier"]!.DeepClone() }).ToArray()),
                        };
                        var result = await _software.HandleAsync(vehicle, payload, ct);
                        if (ProductsUpdateWriter.Fault(result.Issues) is { } fault)
                        {
                            throw new ListenerFault(1001, "Failed", fault.Message);
                        }

                        var steps = new List<XElement>();
                        foreach (var node in nodes)
                        {
                            var mid = node["nodeIdentifier"].I("mid");
                            var after = result.Proposal.Nodes.Objects().First(n => JsonAccess.NodeKeyOf(n) == JsonAccess.NodeKeyOf(node));
                            var parts = PartOperations(node, after);
                            var parameters = TeaParameters(vehicle, result.Proposal);
                            summary.Add(new ListenerFact($"MID {mid} {node["nodeIdentifier"].S("name")}", parts.Count == 0 ? "No newer software." : $"{node.S("versionName")} → {after.S("versionName")}: {parts.Count} part operation(s)."));
                            if (parts.Count == 0 && parameters.Count == 0)
                            {
                                if (nodes.Count > 1)
                                {
                                    steps.Add(Step(0, [mid], null, actual: 0));
                                }

                                continue;
                            }

                            steps.Add(Step(0, [mid], new Changes(parts, [], [], parameters), actual: 0));
                        }

                        summary.Insert(0, new ListenerFact("Outcome", $"{nodes.Count} computer(s) asked about on {Shown(vehicle)}."));
                        return new ListenerAnswer(Workflow(steps), summary, []);
                    }
            }
        }

        protected override XElement Error(ListenerMessage message, ListenerNotice notice, string bodId)
        {
            var code = notice.Code switch { 99 => "VDA_ChassisMissing", 100 when notice.Name == "VDA_CommError" => "VDA_CommError", 1007 => "Configurator_Internal", _ => "Failed" };
            var cams = Cams(code, "Message: " + (bodId.Length == 0 ? "Error validating xml. " : "") + notice.Text);
            return Operation(message.Type) switch
            {
                "CompleteVehicle" => new XElement(Ns + "CompleteVehicle", Namespaces, new XElement(Ns + "ChassisNumber", 0), Nil("ChassisSeries"), Nil("CompanyCode"), Nil("ProductClass"),
                    new XElement(Ns + "AssemblyDate", 0), Nil("CountryCode"), Nil("Model"), Nil("Parameters"), Nil("Parts"), Nil("SalesCode"), Nil("Snotes"), Nil("Variants")),
                "HardwareReplacement" => new XElement(Ns + "HardwareResponse", Namespaces, cams, Nil("HardwareResponseParts")),
                _ => new XElement(Ns + "Workflow", Namespaces, cams, Nil("Steps")),
            };
        }

        // ------------------------------------------------------------------ examples
        public override XDocument Example(ListenerMessageType type, ProductDocument vehicle)
        {
            var mids = vehicle.Nodes.Objects().Select(n => n["nodeIdentifier"].I("mid")).Where(m => m > 0).Take(2).ToList();
            var user = new XElement(Ns + "serviceUser", new XElement(Ns + "Id", "TestRequestTool"), Nil("Password"));
            var transaction = new XElement(Ns + "transactionId", Guid.NewGuid().ToString());
            var kit = _catalog.Kits.FirstOrDefault(k => k.A("productClasses").Any(c => c?.ToString() == vehicle.Info.S("productClassId")))?.I("partNumber") ?? _catalog.Kits.First().I("partNumber");
            var kits = new XElement(Ns + "kitRequest", new XElement(Ns + "CompanyPrefix", "VO"), new XElement(Ns + "KitParts", new XElement(Ns + "int", kit)));
            XElement Requests() => new(Ns + "softwareRequests", vehicle.Nodes.Objects().Where(n => mids.Contains(n["nodeIdentifier"].I("mid"))).Select(n =>
            {
                var parts = Parts(n);
                var hardware = parts.First(p => p.Type == "ECU");
                return new XElement(Ns + "SoftwareRequest",
                    new XElement(Ns + "HardwarePart", new XElement(Ns + "FieldNumber", hardware.Field), new XElement(Ns + "Mid", hardware.Mid), new XElement(Ns + "Number", hardware.Number)),
                    new XElement(Ns + "Mid", n["nodeIdentifier"].I("mid")),
                    new XElement(Ns + "SoftwareRequestParts", parts.Where(p => p.Type != "ECU").Select(p => new XElement(Ns + "SoftwareRequestPart",
                        new XElement(Ns + "FieldNumber", p.Field), new XElement(Ns + "Mid", p.Mid), new XElement(Ns + "Number", p.Number), new XElement(Ns + "Prefix", "VO")))));
            }));
            return Document(Operation(type) switch
            {
                "CompleteVehicle" => new XElement(Ns + "GetCompleteVehicle", user, Basic(vehicle)),
                "HardwareReplacement" => new XElement(Ns + "GetHWReplacement", user, Basic(vehicle),
                    new XElement(Ns + "hardwareRequest", new XElement(Ns + "HardwareRequestParts", vehicle.Nodes.Objects().Where(n => n["nodeIdentifier"].I("mid") > 0).Select(n => Parts(n).First(p => p.Type == "ECU")).Select(p =>
                        new XElement(Ns + "HardwareRequestPart", new XElement(Ns + "FieldNumber", p.Field), new XElement(Ns + "Mid", p.Mid), new XElement(Ns + "Number", p.Number), new XElement(Ns + "Prefix", "VO"))))),
                    transaction),
                "KitInformation" => new XElement(Ns + "GetKitInformation", user, Basic(vehicle), kits, transaction),
                "CompleteVehicleKitInformation" => new XElement(Ns + "GetCompleteVehicleKitInformation", user, CompleteVehicleBody(Ns + "completeVehicle", vehicle), kits, transaction),
                "CompleteVehicleSoftwareReplacement" => new XElement(Ns + "GetCompleteVehicleSWReplacement", user, CompleteVehicleBody(Ns + "completeVehicle", vehicle), Requests(), transaction),
                _ => new XElement(Ns + "GetSWReplacement", user, Basic(vehicle), Requests(), transaction),
            });
        }

        // ------------------------------------------------------------------ the vehicle
        private async Task<ProductDocument> Stored(XElement root, Actor actor, bool validate, CancellationToken ct)
        {
            var basic = Child(root, "basicVehicle");
            if (validate)
            {
                Validate(basic);
            }

            var series = ListenerXml.Text(basic, "ChassisSeries");
            var number = ListenerXml.Text(basic, "ChassisNumber");
            return await _vehicles.FindAsync(series, number, actor, ct)
                ?? throw new ListenerFault(99, "VDA_ChassisMissing", $"VDA returned an error. Status code: 404 Status Text: Vehicle {series?.Trim()} {number} was not found.");
        }

        /// <summary>The product of a completeVehicle: its parts grouped by MID into computers, its variants and S-notes.</summary>
        private async Task<ProductDocument> FromCompleteVehicle(XElement root, Actor actor, CancellationToken ct)
        {
            var complete = Child(root, "completeVehicle");
            Validate(complete);
            var series = ListenerXml.Text(complete, "ChassisSeries");
            var number = ListenerXml.Text(complete, "ChassisNumber");
            var stored = await _vehicles.FindAsync(series, number, actor, ct);
            var data = stored is not null ? (JsonObject)stored.Data.DeepClone() : new JsonObject
            {
                ["productSpecification"] = new JsonObject
                {
                    ["productInformation"] = new JsonObject { ["chassisSeries"] = series?.Trim() ?? "", ["chassisNumber"] = number ?? "", ["productClassId"] = ListenerXml.Text(complete, "ProductClass") ?? "", ["notifications"] = new JsonArray() },
                    ["variants"] = new JsonArray(),
                    ["sNotes"] = new JsonArray(),
                },
                ["nodes"] = new JsonArray(),
                ["parameters"] = new JsonArray(),
            };
            var parts = Children(Child(complete, "Parts"), "VehiclePart").ToList();
            if (parts.Count > 0)
            {
                var nodes = new JsonArray();
                foreach (var group in parts.GroupBy(p => Int(p, "Mid")))
                {
                    var template = _catalog.Data.A("templates").Objects().Where(t => t["identifier"].I("mid") == group.Key).OrderBy(t => t["identifier"].I("family") == 0 ? 0 : 1).FirstOrDefault()
                        ?? throw new ListenerFault(1001, "Failed", $"Mid {group.Key} is not a computer of the catalog.");
                    var numbers = group.Select(p => Int(p, "Number")).ToHashSet();
                    var version = ListenerCatalog.Versions(template).FirstOrDefault(v => numbers.Contains(v.I("doc"))) ?? ListenerCatalog.Versions(template).FirstOrDefault(v => numbers.Contains(v.I("msw")))
                        ?? throw new ListenerFault(1001, "Failed", $"The parts of mid {group.Key} are not a node template of the catalog.");
                    var node = (JsonObject)version["node"]!.DeepClone();
                    var ecu = group.FirstOrDefault(p => ListenerXml.Text(p, "ComponentType") == "ECU");
                    if (ecu is not null && node["ecuHardware"] is JsonObject hardware)
                    {
                        hardware["number"] = Int(ecu, "Number");
                    }

                    nodes.Add(node);
                }

                data["nodes"] = nodes;
            }

            var variants = Children(Child(complete, "Variants"), "string").Select(v => v.Value.Trim()).Where(v => v.Length > 0).ToList();
            if (variants.Count > 0)
            {
                data["productSpecification"]!["variants"] = new JsonArray(variants.Select(v => (JsonNode)(_catalog.Data.A("variants").Objects().FirstOrDefault(x => x.S("idVar6") == v)?.DeepClone()
                    ?? new JsonObject { ["familyId"] = v[..Math.Min(3, v.Length)], ["variantId"] = v.Length > 3 ? v[3..Math.Min(6, v.Length)] : "", ["idVar6"] = v })).ToArray());
            }

            return new ProductDocument(data);
        }

        /// <summary>The requested parts overwrite the computer: its ECU hardware, and the node template the parts belong to.</summary>
        private void Apply(ProductDocument vehicle, List<XElement> requests)
        {
            foreach (var request in requests)
            {
                var mid = Mid(request);
                var node = vehicle.Nodes.Objects().FirstOrDefault(n => n["nodeIdentifier"].I("mid") == mid);
                var template = node is null ? null : _catalog.Template(node);
                if (node is null || template is null)
                {
                    continue;
                }

                var numbers = Children(Child(request, "SoftwareRequestParts"), "SoftwareRequestPart").Select(p => Int(p, "Number")).ToHashSet();
                var version = ListenerCatalog.Versions(template).FirstOrDefault(v => numbers.Contains(v.I("doc")) || numbers.Contains(v.I("msw")));
                var replacement = version?["node"] is JsonObject known ? (JsonObject)known.DeepClone() : node;
                var hardware = Int(Child(request, "HardwarePart"), "Number");
                if (hardware > 0 && replacement["ecuHardware"] is JsonObject ecu)
                {
                    ecu["number"] = hardware;
                }

                vehicle.Nodes[vehicle.Nodes.IndexOf(node)] = replacement;
            }
        }

        private static void Validate(XElement? vehicle)
        {
            foreach (var field in new[] { "ChassisSeries", "ChassisNumber", "ProductClass", "CompanyCode" })
            {
                var value = ListenerXml.Text(Child(vehicle, field), field);
                if (string.IsNullOrWhiteSpace(value) || (field == "ChassisNumber" && (ListenerXml.Number(value) ?? 0) < 1))
                {
                    throw new ListenerFault(1007, "Configurator_Internal", $"Mandatory field '{field}' is missing a value.");
                }
            }
        }

        // ------------------------------------------------------------------ parts, operations and replies
        /// <summary>A computer's parts as VCADS sees them: field number, MID, part number and component type.</summary>
        private static List<(int Field, int Mid, int Number, string Type)> Parts(JsonObject node)
        {
            var mid = node["nodeIdentifier"].I("mid");
            var list = new List<(int, int, int, string)>();
            void Add(JsonNode? part, int field, string type)
            {
                if (part.I("number") > 0)
                {
                    list.Add((ListenerXml.Number(part.S("fieldNumber")) is int f && f > 0 ? f : field, mid, part.I("number"), type));
                }
            }

            Add(node["ecuHardware"], 1, "ECU");
            Add(node["nodeTemplateDocument"], 2, "NTP");
            Add(node["mainSoftware"], 10, "MSW");
            foreach (var (p, i) in node.A("softwareProducts").Objects().Select((p, i) => (p, i)))
            {
                Add(p, 11 + i, "MSW");
            }

            Add(node["downloader"] ?? node["primaryBootloader"], 20, "DL");
            Add(node["secondaryBootloader"], 30, "SSW");
            foreach (var (p, i) in node.A("subSoftwares").Objects().Select((p, i) => (p, i)))
            {
                Add(p, 31 + i, "SSW");
            }

            Add(node["dataSet1"], 40, "DST1");
            Add(node["dataSet2"], 41, "DST2");
            foreach (var (p, i) in node.A("datas").Objects().Select((p, i) => (p, i)))
            {
                Add(p, 42 + i, i == 0 ? "DST1" : "DST2");
            }

            foreach (var (p, i) in node.A("complementarySoftwares").Objects().Select((p, i) => (p, i)))
            {
                Add(p, 50 + i, "CSW");
            }

            foreach (var (p, i) in node.A("subDataSets").Objects().Select((p, i) => (p, i)))
            {
                Add(p, 60 + i, "SDS");
            }

            foreach (var (p, i) in node.A("softwareFunctions").Objects().Select((p, i) => (p, i)))
            {
                Add(p, 70 + i, "SWF");
            }

            return list.DistinctBy(p => (p.Item1, p.Item3)).ToList();
        }

        private static List<XElement> PartOperations(JsonObject? before, JsonObject? after)
        {
            var old = before is null ? [] : Parts(before);
            var now = after is null ? [] : Parts(after);
            return now.Where(p => !old.Any(o => o.Field == p.Field && o.Number == p.Number)).Select(p => (p.Field, p.Number, Kind: "Assign"))
                .Concat(old.Where(o => !now.Any(p => p.Field == o.Field)).Select(o => (o.Field, o.Number, Kind: "Remove")))
                .OrderBy(p => p.Field).Select(p => new XElement(Ns + "PartOperation", new XElement(Ns + "FieldNumber", p.Field), new XElement(Ns + "Number", p.Number), new XElement(Ns + "OperationType", p.Kind))).ToList();
        }

        /// <summary>The TEA2 parameters that change (VCADS carries only TEA2 parameters): assigned first, then removed.</summary>
        private static List<XElement> TeaParameters(ProductDocument before, ProductDocument after)
        {
            static Dictionary<string, string> Map(ProductDocument p) => p.Parameters.Objects().Where(x => x.I("electricalArchitecture") == 0)
                .GroupBy(x => x.S("code")).ToDictionary(g => g.Key, g => g.First().A("references").Objects().FirstOrDefault().S("value"), StringComparer.Ordinal);
            var old = Map(before);
            var now = Map(after);
            return now.Where(p => !old.TryGetValue(p.Key, out var v) || v != p.Value).OrderBy(p => p.Key, StringComparer.Ordinal).Select(p => Parameter(p.Key, p.Value, "Assign"))
                .Concat(old.Where(p => !now.ContainsKey(p.Key)).OrderBy(p => p.Key, StringComparer.Ordinal).Select(p => Parameter(p.Key, p.Value, "Remove"))).ToList();
        }

        private static XElement Parameter(string code, string value, string kind) =>
            new(Ns + "ParameterOperation", new XElement(Ns + "Code", code), new XElement(Ns + "Value", value), new XElement(Ns + "OperationType", kind));

        /// <summary>What a kit changes on the vehicle: parts of the computers it assigns or removes, variants, S-notes and TEA2 parameters.</summary>
        private static Changes Patch(ProductDocument before, ProductDocument after)
        {
            var parts = new List<XElement>();
            var keys = before.Nodes.Objects().Concat(after.Nodes.Objects()).Select(JsonAccess.NodeKeyOf).Distinct();
            foreach (var key in keys)
            {
                parts.AddRange(PartOperations(before.Nodes.Objects().FirstOrDefault(n => JsonAccess.NodeKeyOf(n) == key), after.Nodes.Objects().FirstOrDefault(n => JsonAccess.NodeKeyOf(n) == key)));
            }

            static HashSet<string> Variants(ProductDocument p) => p.Data["productSpecification"].A("variants").Objects().Select(v => v.S("idVar6")).Where(v => v.Length > 0).ToHashSet(StringComparer.Ordinal);
            static HashSet<string> Notes(ProductDocument p) => p.Data["productSpecification"].A("sNotes").Objects().Select(v => v.S("value")).Where(v => v.Length > 0).ToHashSet(StringComparer.Ordinal);
            XElement Op(string name, string field, string value, string kind) => new(Ns + name, new XElement(Ns + "OperationType", kind), new XElement(Ns + field, value));
            var variants = Variants(after).Except(Variants(before)).Order(StringComparer.Ordinal).Select(v => Op("VariantOperation", "Variant", v, "Assign"))
                .Concat(Variants(before).Except(Variants(after)).Order(StringComparer.Ordinal).Select(v => Op("VariantOperation", "Variant", v, "Remove"))).ToList();
            var notes = Notes(after).Except(Notes(before)).Order(StringComparer.Ordinal).Select(v => Op("SNoteOperation", "SNote", v, "Assign"))
                .Concat(Notes(before).Except(Notes(after)).Order(StringComparer.Ordinal).Select(v => Op("SNoteOperation", "SNote", v, "Remove"))).ToList();
            return new Changes(parts, variants, notes, TeaParameters(before, after));
        }

        private static XElement Step(long kit, IEnumerable<int> mids, Changes? patch, long? actual = null)
        {
            var empty = patch is null || (patch.Parts.Count == 0 && patch.Variants.Count == 0 && patch.Notes.Count == 0 && patch.Parameters.Count == 0);
            var affected = mids.ToList();
            return new XElement(Ns + "Step",
                new XElement(Ns + "ActualKitPartNumber", actual ?? kit),
                affected.Count == 0 ? Nil("AffectedMids") : new XElement(Ns + "AffectedMids", affected.Select(m => new XElement(Ns + "int", m))),
                new XElement(Ns + "IsMandatory", "false"),
                empty ? Nil("NodePatch") : new XElement(Ns + "NodePatch",
                    new XElement(Ns + "FromNodeTemplate", 0),
                    new XElement(Ns + "ParameterOperations", patch!.Parameters),
                    new XElement(Ns + "PartOperations", patch.Parts),
                    new XElement(Ns + "SNoteOperations", patch.Notes),
                    new XElement(Ns + "ToNodeTemplate", 0),
                    new XElement(Ns + "VariantOperations", patch.Variants)),
                new XElement(Ns + "RequestedKitPartNumber", kit));
        }

        private static XElement Workflow(List<XElement>? steps) =>
            new(Ns + "Workflow", Namespaces, Cams(null), steps is null ? Nil("Steps") : new XElement(Ns + "Steps", steps));

        private static XElement Cams(string? error, string? details = null) =>
            new(Ns + "CamsResult", details is null ? Nil("Details") : new XElement(Ns + "Details", details), new XElement(Ns + "ErrorCode", error ?? "Ok"));

        private XElement CompleteVehicle(ProductDocument vehicle) =>
            new(Ns + "CompleteVehicle", Namespaces, CompleteVehicleBody(null, vehicle).Elements());

        /// <summary>A vehicle as VCADS CompleteVehicle content: header, assembly date (YYYYWWD), parts, parameters, variants, S-notes.</summary>
        private static XElement CompleteVehicleBody(XName? name, ProductDocument vehicle)
        {
            var info = vehicle.Info;
            var date = DateTime.TryParse(info.S("assemblyDate"), CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal, out var d) ? d : (DateTime?)null;
            var assembly = date is null ? 2000000 : ISOWeek.GetYear(date.Value) * 1000 + ISOWeek.GetWeekOfYear(date.Value) * 10 + ((int)date.Value.DayOfWeek == 0 ? 7 : (int)date.Value.DayOfWeek);
            var parts = vehicle.Nodes.Objects().SelectMany(Parts).ToList();
            var ordered = parts.Where(p => p.Type is not ("ECU" or "NTP")).Concat(parts.Where(p => p.Type == "ECU")).Concat(parts.Where(p => p.Type == "NTP"));
            return new XElement(name ?? Ns + "CompleteVehicle",
                new XElement(Ns + "ChassisNumber", ListenerXml.Number(info.S("chassisNumber")) ?? 0),
                new XElement(Ns + "ChassisSeries", info.S("chassisSeries")),
                new XElement(Ns + "CompanyCode", CompanyCode(vehicle)),
                new XElement(Ns + "ProductClass", info.S("productClassId")),
                new XElement(Ns + "AssemblyDate", assembly),
                Text(Ns + "CountryCode", info.S("countryOfOperation")),
                Text(Ns + "Model", info.S("modelId")),
                new XElement(Ns + "Parameters", vehicle.Parameters.Objects().Select(p => new XElement(Ns + "Parameter", new XElement(Ns + "Code", p.S("code")), new XElement(Ns + "Value", p.A("references").Objects().FirstOrDefault().S("value"))))),
                new XElement(Ns + "Parts", ordered.Select(p => new XElement(Ns + "VehiclePart", new XElement(Ns + "FieldNumber", p.Field), new XElement(Ns + "Mid", p.Mid), new XElement(Ns + "Number", p.Number), new XElement(Ns + "ComponentType", p.Type), new XElement(Ns + "Prefix", "VO")))),
                new XElement(Ns + "SalesCode"),
                new XElement(Ns + "Snotes", vehicle.Data["productSpecification"].A("sNotes").Objects().Select(n => new XElement(Ns + "string", n.S("value")))),
                new XElement(Ns + "Variants", vehicle.Data["productSpecification"].A("variants").Objects().Select(v => v.S("idVar6")).Where(v => v.Length > 0).Select(v => new XElement(Ns + "string", v))));
        }

        private static XElement Basic(ProductDocument vehicle) =>
            new(Ns + "basicVehicle",
                new XElement(Ns + "ChassisNumber", ListenerXml.Number(vehicle.Info.S("chassisNumber")) ?? 0),
                new XElement(Ns + "ChassisSeries", vehicle.Info.S("chassisSeries")),
                new XElement(Ns + "CompanyCode", CompanyCode(vehicle)),
                new XElement(Ns + "ProductClass", vehicle.Info.S("productClassId")));

        /// <summary>The company code VCADS gives: the first letter of the vehicle's company code (VTC: V), T when it has none.</summary>
        private static string CompanyCode(ProductDocument vehicle) => vehicle.Info.S("companyCode") is { Length: > 0 } c ? c[..1] : "T";

        private List<(int Number, List<long> Kits)> HardwareOptions(int mid, int number, int scenario)
        {
            var options = new Dictionary<int, List<long>>();
            foreach (var kit in _catalog.Kits.Where(k => ListenerCatalog.KitAllowed(k, scenario)))
            {
                foreach (var node in kit["delta"].A("nodes").Objects().Select(o => o["value"] as JsonObject).OfType<JsonObject>().Where(n => n["nodeIdentifier"].I("mid") == mid))
                {
                    var hardware = node["ecuHardware"].I("number");
                    if (hardware > 0 && hardware != number)
                    {
                        (options.TryGetValue(hardware, out var list) ? list : options[hardware] = []).Add(kit.I("partNumber"));
                    }
                }
            }

            return options.OrderBy(o => o.Key).Select(o => (o.Key, o.Value)).ToList();
        }

        private static int Mid(XElement request)
        {
            var mid = Int(request, "Mid");
            if (mid > 0)
            {
                return mid;
            }

            mid = Int(Child(request, "HardwarePart"), "Mid");
            return mid > 0 ? mid : Children(Child(request, "SoftwareRequestParts"), "SoftwareRequestPart").Select(p => Int(p, "Mid")).FirstOrDefault(m => m > 0);
        }

        private static string Shown(ProductDocument vehicle) => $"{vehicle.Info.S("chassisSeries")} {vehicle.Info.S("chassisNumber")}";

        private static XElement? Child(XElement? parent, string name) => ListenerXml.Child(parent, name);

        private static IEnumerable<XElement> Children(XElement? parent, string name) => ListenerXml.Children(parent, name);

        private static int Int(XElement? parent, string name) => ListenerXml.Number(ListenerXml.Child(parent, name)?.Value.Trim()) ?? 0;

        private static XElement Nil(string name) => new(Ns + name, new XAttribute(Xsi + "nil", "true"));

        private static XElement Text(XName name, string? value) => string.IsNullOrEmpty(value) ? new XElement(name, new XAttribute(Xsi + "nil", "true")) : new XElement(name, value);

        private static readonly XAttribute Namespaces = new(XNamespace.Xmlns + "xsi", Xsi);

        private sealed record Changes(List<XElement> Parts, List<XElement> Variants, List<XElement> Notes, List<XElement> Parameters);
    }
}
