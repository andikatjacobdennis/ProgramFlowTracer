using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    public sealed class HardwareValidator : IProductValidator
    {
        public string Name => "hardware";
        public int Order => 20;

        public ValueTask<IReadOnlyList<ValidationIssue>> ValidateAsync(ValidationContext c, CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested();
            IReadOnlyList<ValidationIssue> issues = c.Proposal.Nodes.Objects().Where(n => c.Catalog.FindVersion(n) is { } v && !v.A("hardware").Any(x => x?.ToString() == n["ecuHardware"].S("number"))).Select(n => new ValidationIssue("hardware_incompatible", "Hardware is not supported by the selected template.", 0, n.S("name"))).ToArray();
            return ValueTask.FromResult(issues);
        }
    }
}
