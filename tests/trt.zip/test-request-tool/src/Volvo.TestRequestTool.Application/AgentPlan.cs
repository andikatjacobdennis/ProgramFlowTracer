namespace Volvo.TestRequestTool.Application
{
    /// <summary>An agent's proposed plan. Preview is always true in this version: nothing is executed.</summary>
    public sealed record AgentPlan(string Goal, IReadOnlyList<AgentStep> Steps, IReadOnlyList<AgentRequirement> Requires, IReadOnlyList<AgentProposedAction> Actions, bool Preview, string Provider, bool Simulated, string Note);
}
