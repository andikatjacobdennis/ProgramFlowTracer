using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The catalog for the listener's handlers: one copy of its data, taken on first use, instead of a fresh copy on every
    /// read (JsonCatalog.Data copies the whole catalog each time, and a listener message reads it many times). The catalog
    /// does not change after start-up. The handlers only read the copy; AftermarketListenerTests checks that it stays as it
    /// was. Lookups (FindTemplate, Templates, FindVersion) go to the catalog itself.
    /// </summary>
    public sealed class SnapshotCatalog : ICatalog
    {
        private readonly ICatalog _inner;
        private readonly Lazy<JsonObject> _data;

        public SnapshotCatalog(ICatalog inner)
        {
            _inner = inner;
            _data = new Lazy<JsonObject>(() => inner.Data);
        }

        public JsonObject Data => _data.Value;

        public JsonObject? FindTemplate(JsonObject node) => _inner.FindTemplate(node);

        public IReadOnlyList<JsonObject> Templates(int context) => _inner.Templates(context);

        public JsonObject? FindVersion(JsonObject node) => _inner.FindVersion(node);
    }
}
