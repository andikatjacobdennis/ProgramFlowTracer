using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// A product read from a listener message: the chassis series and number as the request writes them (the series padded to
    /// five characters), the product, and whether its nodes came from the repository because the request listed none.
    /// </summary>
    public sealed record ListenerProduct(string Series, string Number, ProductDocument Product, bool FromRepository)
    {
        /// <summary>"FH 123456", for summaries.</summary>
        public string Shown => $"{Series.Trim()} {Number}";

        /// <summary>The chassis as reply attributes write it.</summary>
        public string ChassisSeries => ListenerProducts.Series(Series.Length > 0 ? Series : Product.Info.S("chassisSeries"));

        public string ChassisNumber => ListenerProducts.Number(Number.Length > 0 ? Number : Product.Info.S("chassisNumber"));

        public ListenerFact Source => new("Product", FromRepository
            ? $"{Shown}: the request lists no nodes, so the nodes of the vehicle in the repository were used."
            : $"{Shown}: the nodes as the request gives them.");
    }
}
