namespace Volvo.TestRequestTool.Application
{
    /// <summary>Context or a permission the plan needs, and whether the caller has it.</summary>
    public sealed record AgentRequirement(string Kind, string Name, bool Satisfied, string Explanation);
}
