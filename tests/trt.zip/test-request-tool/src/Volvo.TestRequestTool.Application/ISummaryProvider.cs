namespace Volvo.TestRequestTool.Application
{
    public interface ISummaryProvider
    {
        Task<SummaryReply> SummariseAsync(ContextItem source, DateTimeOffset now, CancellationToken ct);
    }
}
