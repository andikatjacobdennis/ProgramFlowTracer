using System.Globalization;
using System.Text.Json.Nodes;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The product of a listener message (Products 2.1, http://esw.volvo.com/products/2_1, with nodes in Node 2.1).
    /// <list type="bullet">
    /// <item><b>Reading.</b> As in the listener, the request's own product is what is evaluated: its nodes (node template
    /// document, ECU hardware, main software and primary bootloader) and variants. Each node is matched to the catalog, so a
    /// known document gives the full node. When the request lists no nodes, the vehicle with the same chassis in the
    /// repository is used instead, and the reply says so.</item>
    /// <item><b>Writing.</b> A vehicle from the repository as a request product, for the requests the page writes for a vehicle,
    /// and nodes as ProductsUpdate replies assign them.</item>
    /// </list>
    /// </summary>
    public sealed class ListenerProducts
    {
        private static readonly XNamespace Prod = ListenerXml.Products;
        private static readonly XNamespace NodeNs = ListenerXml.Node;
        private readonly ICatalog _catalog;
        private readonly ListenerVehicles _vehicles;

        public ListenerProducts(ICatalog catalog, ListenerVehicles vehicles)
        {
            _catalog = catalog;
            _vehicles = vehicles;
        }

        /// <summary>
        /// The product of a request element: a Product of type prod:ProductType or cs:ProductWithConnectedServicesType, or a
        /// hard individual product (Identification/ChassisID, GeneralDescription/ProductClass, Configuration/ESWDescription/Nodes).
        /// </summary>
        public async Task<ListenerProduct> ReadAsync(XElement product, Actor actor, CancellationToken ct)
        {
            var (series, number) = ListenerXml.Chassis(product);
            var productClass = ListenerXml.Child(product, "ProductClassID")?.Value.Trim() ?? ListenerXml.Text(product, "ProductClass");
            var vin = ListenerXml.Text(ListenerXml.Child(product, "ProductID"), "VIN");
            if (series is not null)
            {
                series = series.TrimEnd();
            }

            var stored = series is not null
                ? await _vehicles.FindAsync(series, number, actor, ct)
                : vin is null ? null : (await _vehicles.ReadableAsync(actor, ct)).FirstOrDefault(v => v.Info.S("vin").Equals(vin, StringComparison.OrdinalIgnoreCase));
            var shown = series is null ? vin ?? "?" : $"{series.Trim()} {number}";
            // Products 2.1 have Nodes directly; a hard individual product (spare cab) has them under Configuration/ESWDescription.
            var nodes = ListenerXml.Children(ListenerXml.Find(product, "Nodes"), "Node").Where(n => n.Elements().Any(e => e.Name.LocalName.StartsWith("Node", StringComparison.Ordinal))).ToList();
            if (nodes.Count == 0)
            {
                if (stored is null)
                {
                    throw ListenerFault.InvalidProduct($"Product {shown} lists no nodes, and the tool has no vehicle {shown} that you may read.");
                }

                return new ListenerProduct(series ?? stored.Info.S("chassisSeries"), number ?? stored.Info.S("chassisNumber"), stored, true);
            }

            var data = stored is not null ? (JsonObject)stored.Data.DeepClone() : NewProduct(series ?? "", number ?? "", vin, productClass);
            var info = (JsonObject)data["productSpecification"]!["productInformation"]!;
            if (!string.IsNullOrEmpty(productClass))
            {
                info["productClassId"] = productClass;
            }

            var read = new JsonArray();
            foreach (var node in nodes)
            {
                read.Add(NodeFrom(node));
            }

            data["nodes"] = read;
            var variants = ListenerXml.Children(ListenerXml.Child(product, "Variants"), "Variant").ToList();
            if (variants.Count > 0)
            {
                data["productSpecification"]!["variants"] = new JsonArray(variants.Select(v => (JsonNode)Variant(ListenerXml.Attribute(v, "familyID") ?? "", ListenerXml.Attribute(v, "variantID") ?? "")).ToArray());
            }

            if (stored is null)
            {
                info["context"] = Context(read, productClass);
            }

            return new ListenerProduct(series ?? "", number ?? "", new ProductDocument(data), false);
        }

        /// <summary>A product element for a request: the vehicle's chassis, VIN, product class, variants and nodes.</summary>
        public static XElement ProductElement(XNamespace ns, string name, ProductDocument vehicle, bool connectedServices = false)
        {
            var info = vehicle.Info;
            var vin = info.S("vin");
            var product = new XElement(ns + name,
                new XElement(Prod + "ProductID",
                    new XElement(Prod + "ChassisID", new XElement(Prod + "ChassisSeries", Series(info.S("chassisSeries"))), new XElement(Prod + "ChassisNumber", Number(info.S("chassisNumber")))),
                    vin.Length == 17 ? new XElement(Prod + "VIN", vin) : null),
                new XElement(Prod + "ProductClassID", info.S("productClassId")),
                new XElement(Prod + "Variants", vehicle.Data["productSpecification"].A("variants").Objects()
                    .Where(v => v.S("familyId").Length > 0 && v.S("variantId").Length > 0)
                    .Select(v => new XElement(Prod + "Variant", new XAttribute("familyID", v.S("familyId")), new XAttribute("variantID", v.S("variantId")), new XAttribute("schemaVersion", "1.3")))),
                new XElement(Prod + "SalesCodes"),
                new XElement(Prod + "SNotes"),
                new XElement(Prod + "ParameterValues"),
                new XElement(Prod + "Nodes", vehicle.Nodes.Objects().Select(n => NodeElement(Prod + "Node", n))));
            return product;
        }

        /// <summary>A node as Node 2.1 writes it (node:NodeType): NodeTEA2Plus, NodeTEA2 or NodeBEA2Body with its parts.</summary>
        public static XElement NodeElement(XName name, JsonObject node, params object?[] after)
        {
            var element = new XElement(name, new XAttribute("schemaVersion", "2.1"), Body(node));
            element.Add(after);
            return element;
        }

        /// <summary>A chassis series as the contracts write it: five characters, padded with spaces ("FH   ").</summary>
        public static string Series(string series) => series.Trim().ToUpperInvariant().PadRight(5)[..5];

        /// <summary>A chassis number as the contracts write it: six digits.</summary>
        public static string Number(string number) => long.TryParse(number, NumberStyles.None, CultureInfo.InvariantCulture, out var n) ? n.ToString("000000", CultureInfo.InvariantCulture) : number;

        private static XElement Body(JsonObject node)
        {
            var id = node["nodeIdentifier"];
            var ea = node.I("electricalArchitecture");
            var hw = node["ecuHardware"];
            if (id.I("family") > 0)
            {
                var main = node["mainSoftware"] as JsonObject ?? node.A("softwareProducts").Objects().FirstOrDefault();
                return new XElement(NodeNs + "NodeTEA2Plus",
                    new XElement(NodeNs + "NodeTemplateDocumentNumber", ListenerXml.PartNumber(node["nodeTemplateDocument"].I("number"))),
                    ListenerCatalog.NodeId(NodeNs, node),
                    new XElement(NodeNs + "ParentNode", new XElement(NodeNs + "RootNode")),
                    new XElement(NodeNs + "ECUHardware", new XAttribute("partNumber", ListenerXml.PartNumber(hw.I("number"))), new XAttribute("SerialNumber", hw.S("serialNumber"))),
                    Part(NodeNs + "PrimaryBootloader", node["primaryBootloader"]),
                    Part(NodeNs + "SecondaryBootloader", node["secondaryBootloader"]),
                    Part(NodeNs + "MainSoftware", main) ?? new XElement(NodeNs + "MainSoftware", new XAttribute("partNumber", "00000000"), new XAttribute("offsetAddress", "0")),
                    new XElement(NodeNs + "ComplementarySoftwares", node.A("complementarySoftwares").Objects().Select(c => Part(NodeNs + "ComplementarySoftware", c))),
                    new XElement(NodeNs + "Datas", node.A("datas").Objects().Select(d => Part(NodeNs + "Data", d, new XAttribute("isPatchable", d.B("isPatchable") ? "true" : "false")))));
            }

            var mid = new XElement(NodeNs + "MID", id.I("mid").ToString("000", CultureInfo.InvariantCulture));
            var ecu = new XElement(NodeNs + "ECUHardware", new XAttribute("fieldNo", Field(hw, 0)), new XAttribute("partNumber", ListenerXml.PartNumber(hw.I("number"))), new XAttribute("SerialNumber", hw.S("serialNumber")));
            if (ea == 2)
            {
                var functions = node.A("softwareFunctions").Objects().Select(f => Tea2(NodeNs + "SoftwareFunction", f)).ToList();
                return new XElement(NodeNs + "NodeBEA2Body", mid, ecu,
                    Tea2(NodeNs + "MainSoftware", node["mainSoftware"]),
                    new XElement(NodeNs + "SubSoftwares", node.A("subSoftwares").Objects().Select(s => Tea2(NodeNs + "SubSoftware", s))),
                    new XElement(NodeNs + "SoftwareFunctions", functions.Count > 0 ? functions : [Tea2(NodeNs + "SoftwareFunction", node["mainSoftware"])]));
            }

            return new XElement(NodeNs + "NodeTEA2",
                new XElement(NodeNs + "NodeTemplateDocumentReference", new XAttribute("nodeTemplateDocumentNumber", ListenerXml.PartNumber(node["nodeTemplateDocument"].I("number"))), new XAttribute("fieldNo", "0000")),
                mid, ecu,
                Tea2(NodeNs + "MainSoftware", node["mainSoftware"]),
                node["downloader"] is JsonObject downloader ? Tea2(NodeNs + "Downloader", downloader) : null,
                new XElement(NodeNs + "ComplementarySoftwares", node.A("complementarySoftwares").Objects().Select(c => Tea2(NodeNs + "ComplementarySoftware", c))),
                node["dataSet1"] is JsonObject d1 ? Tea2(NodeNs + "DataSet1", d1) : null,
                node["dataSet2"] is JsonObject d2 ? Tea2(NodeNs + "DataSet2", d2) : null,
                new XElement(NodeNs + "SubSoftwares", node.A("subSoftwares").Objects().Select(s => Tea2(NodeNs + "SubSoftware", s))),
                new XElement(NodeNs + "SubDataSets", node.A("subDataSets").Objects().Select(s => Tea2(NodeNs + "SubDataSet", s))),
                new XElement(NodeNs + "SubComplementarySoftwares", node.A("subComplementarySoftwares").Objects().Select(s => Tea2(NodeNs + "SubComplementarySoftware", s))));
        }

        private static XElement? Part(XName name, JsonNode? part, params object[] extra)
        {
            if (part is not JsonObject p || p.I("number") <= 0)
            {
                return null;
            }

            var element = new XElement(name, new XAttribute("partNumber", ListenerXml.PartNumber(p.I("number"))), new XAttribute("offsetAddress", p.I("offsetAddress").ToString(CultureInfo.InvariantCulture)));
            element.Add(extra);
            if (p.B("isNotProgrammable"))
            {
                element.Add(new XAttribute("nonProgrammable", "true"));
            }

            return element;
        }

        private static XElement Tea2(XName name, JsonNode? part) =>
            new(name, new XAttribute("fieldNo", Field(part, 1)), new XAttribute("partNumber", ListenerXml.PartNumber(part.I("number"))));

        private static string Field(JsonNode? part, int fallback) => (ListenerXml.Number(part.S("fieldNumber")) ?? fallback).ToString("0000", CultureInfo.InvariantCulture);

        /// <summary>A request node as a catalog node: the catalog version with the same document when there is one.</summary>
        private JsonObject NodeFrom(XElement node)
        {
            var body = node.Elements().FirstOrDefault() ?? throw ListenerFault.InvalidProduct("A product node is empty.");
            var kind = body.Name.LocalName;
            var template = Template(body, kind);
            var doc = kind == "NodeTEA2Plus" ? ListenerXml.Number(ListenerXml.Child(body, "NodeTemplateDocumentNumber")?.Value.Trim())
                : ListenerXml.Number(ListenerXml.Attribute(ListenerXml.Find(body, "NodeTemplateDocumentReference"), "nodeTemplateDocumentNumber"));
            var ecu = ListenerXml.Child(body, "ECUHardware");
            var hardware = ListenerXml.Number(ListenerXml.Attribute(ecu, "partNumber")) ?? 0;
            var main = ListenerXml.Number(ListenerXml.Attribute(ListenerXml.Child(body, "MainSoftware"), "partNumber")) ?? 0;
            var pbl = ListenerXml.Number(ListenerXml.Attribute(ListenerXml.Child(body, "PrimaryBootloader"), "partNumber"));
            var versions = template is null ? [] : ListenerCatalog.Versions(template);
            var version = versions.FirstOrDefault(v => doc is not null && v.I("doc") == doc) ?? (doc is null ? versions.FirstOrDefault(v => main > 0 && v.I("msw") == main) : null);
            JsonObject result;
            if (version?["node"] is JsonObject known)
            {
                result = (JsonObject)known.DeepClone();
            }
            else
            {
                var id = template?["identifier"]?.DeepClone() as JsonObject ?? Identifier(body, kind);
                result = new JsonObject
                {
                    ["electricalArchitecture"] = id.I("electricalArchitecture"),
                    ["nodeIdentifier"] = id,
                    ["name"] = id.I("family") > 0 ? $"{id.I("family")}.{id.I("type")}.{id.I("position")} {id.S("name")}".TrimEnd() : $"{id.I("mid")} {id.S("name")}".TrimEnd(),
                    ["nodeTemplateDocument"] = new JsonObject { ["name"] = "NTP", ["number"] = doc ?? 0 },
                    ["mainSoftware"] = new JsonObject { ["name"] = "MSW", ["number"] = main },
                };
            }

            if (hardware > 0)
            {
                result["ecuHardware"] = new JsonObject { ["name"] = "ECU", ["number"] = hardware, ["serialNumber"] = ListenerXml.Attribute(ecu, "SerialNumber") ?? "" };
            }

            if (pbl is not null && result["primaryBootloader"] is JsonObject bootloader)
            {
                bootloader["number"] = pbl;
            }

            return result;
        }

        private JsonObject? Template(XElement body, string kind)
        {
            var templates = _catalog.Data.A("templates").Objects();
            if (kind == "NodeTEA2Plus")
            {
                var name = ListenerXml.Child(body, "NodeName");
                var family = ListenerXml.Number(ListenerXml.Attribute(name, "nodeFamily"));
                var type = ListenerXml.Number(ListenerXml.Attribute(name, "nodeType"));
                var position = ListenerXml.Number(ListenerXml.Attribute(name, "nodePosition")) ?? 0;
                return templates.FirstOrDefault(t => t["identifier"].I("family") == family && t["identifier"].I("type") == type && (position == 0 || t["identifier"].I("position") == position));
            }

            var mid = ListenerXml.Number(ListenerXml.Child(body, "MID")?.Value.Trim());
            var architecture = kind == "NodeBEA2Body" ? 2 : 0;
            return templates.FirstOrDefault(t => t["identifier"].I("family") == 0 && t["identifier"].I("mid") == mid && t["identifier"].I("electricalArchitecture") == architecture)
                ?? templates.FirstOrDefault(t => t["identifier"].I("family") == 0 && t["identifier"].I("mid") == mid);
        }

        private static JsonObject Identifier(XElement body, string kind)
        {
            if (kind == "NodeTEA2Plus")
            {
                var name = ListenerXml.Child(body, "NodeName");
                return new JsonObject
                {
                    ["position"] = ListenerXml.Number(ListenerXml.Attribute(name, "nodePosition")) ?? 0,
                    ["type"] = ListenerXml.Number(ListenerXml.Attribute(name, "nodeType")) ?? 0,
                    ["family"] = ListenerXml.Number(ListenerXml.Attribute(name, "nodeFamily")) ?? 0,
                    ["mid"] = null,
                    ["name"] = "",
                    ["electricalArchitecture"] = 1,
                };
            }

            return new JsonObject { ["position"] = null, ["type"] = null, ["family"] = null, ["mid"] = ListenerXml.Number(ListenerXml.Child(body, "MID")?.Value.Trim()) ?? 0, ["name"] = "", ["electricalArchitecture"] = kind == "NodeBEA2Body" ? 2 : 0 };
        }

        private JsonObject Variant(string family, string variant) =>
            _catalog.Data.A("variants").Objects().FirstOrDefault(v => v.S("familyId") == family && v.S("variantId") == variant)?.DeepClone() as JsonObject
            ?? new JsonObject { ["familyId"] = family, ["variantId"] = variant, ["familyType"] = "S", ["symbol"] = family + "-" + variant, ["idVar6"] = family + variant };

        /// <summary>The context of a product the repository does not have: the one whose node templates the nodes belong to.</summary>
        private JsonObject Context(JsonArray nodes, string? productClass)
        {
            var contexts = _catalog.Data.A("contexts").Objects().ToList();
            var templateContexts = nodes.Objects().Select(n => _catalog.FindTemplate(n)).Where(t => t is not null).SelectMany(t => t!.A("contexts").Select(c => int.TryParse(c?.ToString(), out var n) ? n : 0)).ToList();
            var context = contexts.Where(c => templateContexts.Contains(c.I("id"))).OrderByDescending(c => c.A("productClassIds").Any(p => p?.ToString() == productClass)).ThenByDescending(c => templateContexts.Count(x => x == c.I("id"))).FirstOrDefault()
                ?? contexts.FirstOrDefault(c => c.A("productClassIds").Any(p => p?.ToString() == productClass))
                ?? throw ListenerFault.InvalidProduct($"No vehicle context of the catalog has product class {productClass} or these nodes.");
            return new JsonObject { ["id"] = context.I("id"), ["name"] = context.S("name"), ["isOnlyTea2"] = context.B("isOnlyTea2") };
        }

        private static JsonObject NewProduct(string series, string number, string? vin, string? productClass) => new()
        {
            ["productSpecification"] = new JsonObject
            {
                ["productInformation"] = new JsonObject
                {
                    ["chassisSeries"] = series.Trim(),
                    ["chassisNumber"] = number.Trim(),
                    ["vin"] = vin ?? "",
                    ["productClassId"] = productClass ?? "",
                    ["notifications"] = new JsonArray(),
                },
                ["variants"] = new JsonArray(),
                ["sNotes"] = new JsonArray(),
            },
            ["nodes"] = new JsonArray(),
            ["parameters"] = new JsonArray(),
        };
    }
}
