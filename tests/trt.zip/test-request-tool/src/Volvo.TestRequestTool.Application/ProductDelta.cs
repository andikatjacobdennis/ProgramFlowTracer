using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Application
{
    public static class ProductDelta
    {
        // Existing simulator operation IDs. 41/42 are simulator-local T3 extensions.
        public static JsonObject Between(ProductDocument before, ProductDocument after)
        {
            var nodes = new JsonArray();
            foreach (var n in after.Nodes.Objects())
            {
                var old = before.Nodes.Objects().FirstOrDefault(x => JsonAccess.NodeKeyOf(x) == JsonAccess.NodeKeyOf(n));
                if (!JsonNode.DeepEquals(old, n))
                {
                    nodes.Add(new JsonObject { ["type"] = n.I("electricalArchitecture") switch { 0 => 31, 1 => 32, 2 => 30, 3 => 42, _ => throw new RequestFault(400, "unknown_architecture", "Unsupported node architecture.") }, ["value"] = n.DeepClone() });
                }
            }
            foreach (var n in before.Nodes.Objects().Where(n => !after.Nodes.Objects().Any(x => JsonAccess.NodeKeyOf(x) == JsonAccess.NodeKeyOf(n))))
            {
                nodes.Add(new JsonObject { ["type"] = 24, ["identifier"] = n["nodeIdentifier"]?.DeepClone() });
            }

            var parameters = ListDelta(before.Parameters, after.Parameters, p => p.S("electricalArchitecture") + ":" + p.S("code"), 10, 11);
            var bs = before.Data["productSpecification"]!;
            var ps = after.Data["productSpecification"]!;
            var spec = new JsonObject
            {
                ["variants"] = ListDelta(bs.A("variants"), ps.A("variants"), p => p.S("idVar6", p.S("symbol")), 6, 7),
                ["sNotes"] = ListDelta(bs.A("sNotes"), ps.A("sNotes"), p => p.S("value"), 8, 9)
            };
            foreach (var k in new[] { "baselineName", "baselineGuid", "servicePackName", "servicePackGuid" })
            {
                if (before.Info.S(k) != after.Info.S(k))
                {
                    spec[k] = after.Info[k]?.DeepClone();
                }
            }

            return new JsonObject { ["nodes"] = nodes, ["parameters"] = parameters, ["productSpecification"] = spec };
        }

        private static JsonArray ListDelta(JsonArray before, JsonArray after, Func<JsonObject, string> key, int assign, int remove)
        {
            var result = new JsonArray();
            foreach (var p in after.Objects())
            {
                if (!before.Objects().Any(x => key(x) == key(p) && JsonNode.DeepEquals(x, p)))
                {
                    result.Add(new JsonObject { ["type"] = assign, ["value"] = p.DeepClone() });
                }
            }

            foreach (var p in before.Objects())
            {
                if (!after.Objects().Any(x => key(x) == key(p)))
                {
                    result.Add(new JsonObject { ["type"] = remove, ["value"] = p.DeepClone() });
                }
            }

            return result;
        }

        public static void ApplySeedKit(ProductDocument product, JsonObject delta)
        {
            foreach (var op in delta.A("nodes").Objects())
            {
                var value = op["value"] as JsonObject;
                if (value is null)
                {
                    throw new RequestFault(400, "unsupported_kit_operation", "Seed kit requires a complete node replacement.");
                }

                var old = product.Nodes.Objects().FirstOrDefault(x => JsonAccess.NodeKeyOf(x) == JsonAccess.NodeKeyOf(value));
                if (old is not null)
                {
                    product.Nodes.Remove(old);
                }

                product.Nodes.Add(value.DeepClone());
            }
            foreach (var op in delta.A("parameters").Objects())
            {
                var value = (JsonObject)op["value"]!;
                var old = product.Parameters.Objects().FirstOrDefault(x => x.S("code") == value.S("code") && x.I("electricalArchitecture") == value.I("electricalArchitecture"));
                if (old is not null)
                {
                    product.Parameters.Remove(old);
                }

                if (op.I("type") != 11)
                {
                    product.Parameters.Add(value.DeepClone());
                }
            }
            foreach (var (key, remove, family) in new[] { ("variants", 7, true), ("sNotes", 9, false) })
            {
                var list = product.Data["productSpecification"]!.A(key);
                foreach (var op in delta["productSpecification"].A(key).Objects())
                {
                    var value = (JsonObject)op["value"]!;
                    var id = family ? "idVar6" : "value";
                    foreach (var old in list.Objects().Where(x => x.S(id) == value.S(id) || (op.I("type") != remove && family && value.S("familyType") != "E" && x.S("familyId") == value.S("familyId"))).ToArray())
                    {
                        list.Remove(old);
                    }

                    if (op.I("type") != remove)
                    {
                        list.Add(value.DeepClone());
                    }
                }
            }
        }
    }
}
