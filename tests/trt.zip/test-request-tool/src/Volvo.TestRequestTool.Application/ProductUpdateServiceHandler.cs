using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// Product Update Service (ProductUpdateService_1_0 / _2_0). 1.0 always runs UpdateToServicePack; 2.0 reads
    /// criteria.operation.operationType and also accepts Repair. Service-pack candidates must be reachable by every node and
    /// are tried newest first (SortOrder, then Guid); HPC nodes must pass the upgrade-path gate (Matrix in production).
    /// </summary>
    public sealed class ProductUpdateServiceHandler : IRequestHandler
    {
        private readonly ICatalog _catalog;

        public ProductUpdateServiceHandler(ICatalog catalog)
        {
            _catalog = catalog;
        }

        public RequestKind Kind => RequestKind.ProductUpdateService;

        public ValueTask<HandlerResult> HandleAsync(ProductDocument original, JsonObject payload, CancellationToken ct)
        {
            var schemaVersion = payload.S("schemaVersion", "2.0");
            var traceId = payload.S("traceId");
            if (string.IsNullOrWhiteSpace(traceId))
            {
                traceId = Guid.NewGuid().ToString();
            }

            var criteria = payload["criteria"];
            var request = new JsonObject { ["schemaVersion"] = schemaVersion, ["traceId"] = traceId, ["criteria"] = criteria?.DeepClone() ?? new JsonObject(), ["product"] = ServiceContract.Product(original, "PUS") };
            if (schemaVersion == "2.0")
            {
                request["requestedNodes"] = new JsonObject { ["node"] = new JsonArray(original.Nodes.Objects().Select(n => (JsonNode)new JsonObject { ["nodeName"] = n.S("name"), ["previousECUHardware"] = payload.S("previousEcuHardware") is { Length: > 0 } h ? h : null }).ToArray()) };
            }

            HandlerResult Fail(int code, string type, string text, string issue) => new(original.Copy(), [new(issue, text + " (error code " + code + ")")],
                ServiceResponse: Envelope(request, new JsonObject { ["schemaVersion"] = schemaVersion, ["traceId"] = traceId, ["errors"] = new JsonArray(new JsonObject { ["type"] = type, ["text"] = text }) }, code));

            if (schemaVersion is not ("1.0" or "2.0"))
            {
                return ValueTask.FromResult(Fail(ServiceContract.UnhandledError, "InvalidOperationException", "No handler is registered for ProductUpdateService_" + schemaVersion + ".", "unparsable_version"));
            }

            if (!ServiceContract.TryScenario(criteria, out var scenario, out var scenarioName))
            {
                return ValueTask.FromResult(Fail(ServiceContract.UnhandledError, "ArgumentException", "Schema validation failed: criteria.scenario: '" + scenarioName + "' is not one of " + string.Join(", ", ServiceContract.Scenarios.Keys) + ".", "schema_validation"));
            }

            var operation = schemaVersion == "1.0" ? "UpdateToServicePack" : criteria?["operation"].S("operationType", "UpdateToServicePack") ?? "UpdateToServicePack";
            var allowed = schemaVersion == "1.0" ? new[] { "UpdateToServicePack" } : ["UpdateToServicePack", "Repair"];
            if (!allowed.Contains(operation, StringComparer.OrdinalIgnoreCase))
            {
                return ValueTask.FromResult(Fail(ServiceContract.InvalidMessage, "NotificationException", "ProductUpdateService_" + schemaVersion.Replace('.', '_') + " only supports " + string.Join(" or ", allowed) + ". Received: " + operation, "unsupported_operation"));
            }

            var p = original.Copy();
            var issues = new List<ValidationIssue>();
            var rejected = new JsonArray();
            var nodes = p.Nodes.Objects().Select(n => (node: n, template: _catalog.FindTemplate(n))).ToArray();
            foreach (var hpc in nodes.Where(x => ServiceContract.IsHpc(x.node) && x.node.A("softwareProducts").Objects().All(s => string.IsNullOrEmpty(s.S("logicalEcu")))))
            {
                return ValueTask.FromResult(Fail(ServiceContract.InvalidMessage, "NotificationException", "Logical ECU definition not found for " + hpc.node["nodeIdentifier"].I("family") + "." + hpc.node["nodeIdentifier"].I("type"), "logical_ecu_missing"));
            }

            foreach (var unknown in nodes.Where(x => x.template is null))
            {
                issues.Add(new("unknown_node", "Node is not documented in the catalog.", 0, unknown.node.S("name")));
            }

            JsonObject? chosen = null;
            var plan = new List<(JsonObject node, JsonObject[] versions, int current, int target)>();
            if (operation.Equals("Repair", StringComparison.OrdinalIgnoreCase))
            {
                foreach (var (node, template) in nodes.Where(x => x.template is not null).Select(x => (x.node, x.template!)))
                {
                    var versions = template.A("versions").Objects().ToArray();
                    var current = Array.FindIndex(versions, v => v.I("doc") == node["nodeTemplateDocument"].I("number"));
                    if (current < 0)
                    {
                        issues.Add(new("unresolved_template", "Repair needs a documented node template.", 0, node.S("name")));
                    }
                    else
                    {
                        plan.Add((node, versions, current, current));
                    }
                }
            }
            else
            {
                var candidates = _catalog.Data.A("servicePacks").Objects().Where(sp => sp.I("contextId") == p.ContextId)
                    .Where(sp => nodes.Where(x => x.template is not null).All(x => sp["ntps"]?[x.template!.S("key")] is not null))
                    .OrderByDescending(sp => sp.I("sortOrder")).ThenByDescending(sp => sp.S("guid"), StringComparer.Ordinal).ToArray();
                foreach (var sp in candidates)
                {
                    ct.ThrowIfCancellationRequested();
                    var reasons = new List<string>();
                    var steps = new List<(JsonObject, JsonObject[], int, int)>();
                    foreach (var (node, template) in nodes.Where(x => x.template is not null).Select(x => (x.node, x.template!)))
                    {
                        var versions = template.A("versions").Objects().ToArray();
                        var current = Array.FindIndex(versions, v => v.I("doc") == node["nodeTemplateDocument"].I("number"));
                        var target = sp["ntps"].I(template.S("key"), -1);
                        if (target < 0 || target >= versions.Length)
                        {
                            reasons.Add(node.S("name") + ": not part of the service pack");
                            continue;
                        }
                        if (!SoftwareHandler.Allowed(versions[target], scenario))
                        {
                            reasons.Add(node.S("name") + ": " + versions[target].S("versionName") + " is " + ServiceContract.TemplateStatus(versions[target].S("status")) + ", outside scenario " + scenarioName);
                            continue;
                        }
                        if (current >= target)
                        {
                            continue; // Already on or beyond the pack.
                        }

                        if (ServiceContract.IsHpc(node))
                        {
                            if (!versions[target].A("hardware").Any(h => int.TryParse(h?.ToString(), out var n) && n == node["ecuHardware"].I("number")))
                            {
                                reasons.Add(node.S("name") + ": no upgrade path for ECU hardware " + node["ecuHardware"].I("number"));
                                continue;
                            }
                            foreach (var dep in versions[target].A("requires").Objects())
                            {
                                if (sp["ntps"].I(dep.S("key"), -1) < dep.I("minIdx"))
                                {
                                    reasons.Add(node.S("name") + ": requires " + dep.S("key") + " at index " + dep.I("minIdx"));
                                }
                            }
                        }
                        steps.Add((node, versions, current, target));
                    }
                    if (reasons.Count == 0)
                    {
                        chosen = sp;
                        plan = steps;
                        break;
                    }
                    rejected.Add(new JsonObject { ["servicePack"] = sp.S("name"), ["reasons"] = new JsonArray(reasons.Select(r => (JsonNode)r).ToArray()) });
                }
                if (chosen is null)
                {
                    var text = candidates.Length == 0 ? "No service pack is reachable by every node in this context." : "No candidate service pack passed validation for scenario " + scenarioName + ".";
                    var failed = Fail(ServiceContract.InvalidMessage, "NotificationException", text, "no_service_pack");
                    failed.ServiceResponse!["rejectedCandidates"] = rejected;
                    return ValueTask.FromResult(failed with { Issues = [.. issues, .. failed.Issues] });
                }
            }

            var releaseNotes = new JsonArray();
            var changedNodes = new JsonArray();
            var parameterUpdates = new JsonArray();
            var language = payload.S("languageCode", "en-GB");
            foreach (var (node, versions, current, target) in plan)
            {
                var version = versions[target];
                var replacement = (JsonObject)version["node"]!.DeepClone();
                replacement["ecuHardware"] = node["ecuHardware"]?.DeepClone();
                if (node["subHardwares"] is not null && replacement["subHardwares"] is not null)
                {
                    replacement["subHardwares"] = node["subHardwares"]!.DeepClone();
                }

                p.Nodes[p.Nodes.IndexOf(node)] = replacement;
                SoftwareHandler.ApplyParameters(p, current >= 0 ? versions[current].A("parameters") : [], version.A("parameters"), operation.Equals("Repair", StringComparison.OrdinalIgnoreCase), true);
                changedNodes.Add(ServiceContract.ResponseNode(replacement, version, p, current == target, schemaVersion == "2.0"));
                releaseNotes.Add(new JsonObject
                {
                    ["id"] = version.I("doc"),
                    ["nodeName"] = node.S("name"),
                    ["text"] = version["releaseNotes"].S(language, version["releaseNotes"].S("en-GB")),
                    ["source"] = chosen is null ? new JsonObject { ["contextName"] = "unknown" } : new JsonObject { ["servicePackGuid"] = chosen.S("guid") }
                });
            }
            foreach (var param in p.Parameters.Objects().Where(x => !original.Parameters.Objects().Any(o => JsonNode.DeepEquals(o, x))))
            {
                parameterUpdates.Add(new JsonObject { ["parameterCode"] = param.S("code"), ["parameterValue"] = param["references"]?.DeepClone(), ["removed"] = false });
            }

            if (chosen is not null)
            {
                p.Info["servicePackName"] = chosen.S("name");
                p.Info["servicePackGuid"] = chosen.S("guid");
            }
            if (plan.Count == 0)
            {
                issues.Add(new("already_on_service_pack", "All nodes already match or exceed " + chosen?.S("name") + ".", 2));
            }

            var reply = new JsonObject
            {
                ["schemaVersion"] = schemaVersion,
                ["traceId"] = traceId,
                ["productUpdate"] = new JsonObject
                {
                    ["customerAdaptationUpdates"] = new JsonArray(),
                    ["nodes"] = changedNodes,
                    ["parameterUpdates"] = parameterUpdates,
                    ["releaseNotes"] = releaseNotes,
                    ["updatePurposes"] = changedNodes.Count > 0 ? new JsonArray("Enhancement") : new JsonArray(),
                    ["variantUpdates"] = new JsonArray(),
                    ["servicePack"] = chosen is null ? null : new JsonObject { ["guid"] = chosen.S("guid"), ["name"] = chosen.S("name") }
                }
            };
            var envelope = Envelope(request, reply, 0);
            envelope["operationType"] = operation;
            envelope["scenario"] = scenarioName;
            envelope["rejectedCandidates"] = rejected;
            return ValueTask.FromResult(new HandlerResult(p, issues, ServiceResponse: envelope));
        }

        static JsonObject Envelope(JsonObject request, JsonObject reply, int code) => new()
        {
            ["contract"] = "ProductUpdateService",
            ["version"] = request.S("schemaVersion"),
            ["chassisSeries"] = request["product"]?["identification"]?["chassisId"].S("series"),
            ["chassisNumber"] = request["product"]?["identification"]?["chassisId"].S("number"),
            ["aftermarketErrorCode"] = code,
            ["request"] = request,
            ["response"] = reply
        };
    }
}
