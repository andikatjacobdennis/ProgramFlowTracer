using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>Retrieves context with the caller's own permissions (role, vehicle contexts, ownership). Never more.</summary>
    public interface IAssistantContextRetriever
    {
        Task<RetrievedContext> RetrieveAsync(Actor actor, IReadOnlyList<ContextRef> refs, CancellationToken ct);
    }
}
