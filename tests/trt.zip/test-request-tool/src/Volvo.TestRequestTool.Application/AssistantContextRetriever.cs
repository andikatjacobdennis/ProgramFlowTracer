using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// Retrieves assistant context from the application's own records with the caller's permissions: vehicles in the caller's
    /// contexts, the caller's own proposal revisions, the caller's own requests and activity. A record the caller cannot read is
    /// reported as unavailable, never included. Only facts needed for answers are copied (no tokens, no other users' data).
    /// </summary>
    public sealed class AssistantContextRetriever : IAssistantContextRetriever
    {
        private readonly IWorkspaceStore _store;
        public const string ProposalId = "workspace";

        public AssistantContextRetriever(IWorkspaceStore store)
        {
            _store = store;
        }

        public async Task<RetrievedContext> RetrieveAsync(Actor actor, IReadOnlyList<ContextRef> refs, CancellationToken ct)
        {
            var items = new List<ContextItem>();
            var missing = new List<string>();
            foreach (var r in refs.Take(6))
            {
                try
                {
                    var item = r.Kind switch
                    {
                        "vehicle" => await Vehicle(actor, r.Id, ct),
                        "proposal" => await Proposal(actor, ct),
                        "request" => await Request(actor, r.Id, ct),
                        "activity" => await Activity(actor, ct),
                        _ => null,
                    };
                    if (item is null)
                    {
                        missing.Add($"{r.Kind}: not available");
                    }
                    else
                    {
                        items.Add(item);
                    }
                }
                catch (RequestFault f) when (f.Status is 403 or 404)
                {
                    missing.Add($"{r.Kind}: not available to you");
                }
            }
            return new RetrievedContext(items, missing);
        }

        private async Task<ContextItem?> Vehicle(Actor actor, string? id, CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(id))
            {
                return null;
            }

            var v = await _store.VehicleAsync(id, ct);
            if (v is null)
            {
                return null;
            }

            var p = new ProductDocument(v.Product);
            actor.DemandRead(p.ContextId);
            var t3 = p.Nodes.Objects().Any(n => n.I("electricalArchitecture") == 3);
            var facts = new JsonObject
            {
                ["vehicle"] = $"{p.Info.S("chassisSeries")} {p.Info.S("chassisNumber")}",
                ["model"] = p.Info.S("modelId"),
                ["country"] = p.Info.S("countryOfOperation"),
                ["architecture"] = t3 ? "T3" : "TEA2+",
                ["revision"] = v.Revision,
                ["computers"] = p.Nodes.Count,
                ["software"] = new JsonArray(p.Nodes.Objects().Take(30).Select(n => (JsonNode)new JsonObject { ["computer"] = n.S("name"), ["version"] = n.S("versionName"), ["status"] = n.S("nodeTemplateStatus") }).ToArray()),
            };
            return new ContextItem("vehicle", id, $"Vehicle {facts.S("vehicle")}", "vda-" + v.Revision, null, facts);
        }

        private async Task<ContextItem?> Proposal(Actor actor, CancellationToken ct)
        {
            var latest = (await _store.ProposalRevisionsAsync(actor.Id, ProposalId, ct)).FirstOrDefault();
            if (latest is null)
            {
                return null;
            }

            var facts = new JsonObject { ["revision"] = latest.Number, ["reason"] = latest.Reason, ["at"] = latest.At, ["changes"] = latest.Summary["changes"]?.DeepClone(), ["vehicle"] = latest.Summary["vehicle"]?.DeepClone(), ["author"] = latest.ActorName };
            return new ContextItem("proposal", ProposalId, $"Proposal revision {latest.Number}", "rev-" + latest.Number, latest.At, facts);
        }

        private async Task<ContextItem?> Request(Actor actor, string? id, CancellationToken ct)
        {
            if (!Guid.TryParse(id, out var guid))
            {
                return null;
            }

            var r = await _store.ExecutionAsync(guid, actor.Id, ct);   // owner only: another user's request is "not available"
            if (r is null)
            {
                return null;
            }

            var outcomes = new JsonArray(r.Outcomes.Select(o => (JsonNode)new JsonObject
            {
                ["vehicle"] = o.VehicleId.Replace('|', ' '),
                ["ready"] = o.IsReady,
                ["limited"] = o.LimitedValidation,
                ["baseRevision"] = o.BaseRevision,
                ["changes"] = (o.Delta["nodes"] as JsonArray)?.Count ?? 0,
                ["issues"] = new JsonArray(o.Issues.OrderBy(i => i.Severity).Take(10).Select(i => (JsonNode)new JsonObject { ["severity"] = i.Severity, ["text"] = i.Text, ["node"] = i.Node, ["code"] = i.Code }).ToArray()),
            }).ToArray());
            var facts = new JsonObject { ["kind"] = r.Kind.ToString(), ["at"] = r.CreatedAt, ["outcomes"] = outcomes };
            return new ContextItem("request", r.Id.ToString(), $"{r.Kind} request of {r.CreatedAt:yyyy-MM-dd HH:mm} UTC", r.Id.ToString("N")[..12], r.CreatedAt, facts);
        }

        private async Task<ContextItem?> Activity(Actor actor, CancellationToken ct)
        {
            var history = await _store.HistoryAsync(actor.Id, 0, 20, ct);
            if (history.Count == 0)
            {
                return null;
            }

            var facts = new JsonObject
            {
                ["requests"] = history.Count,
                ["latest"] = history[0].CreatedAt,
                ["byKind"] = new JsonObject(history.GroupBy(h => h.Kind.ToString()).Select(g => KeyValuePair.Create(g.Key, (JsonNode?)g.Count()))),
                ["ready"] = history.Count(h => h.Outcomes.All(o => o.IsReady)),
                ["blocked"] = history.Count(h => h.Outcomes.Any(o => !o.LimitedValidation && o.Issues.Any(i => i.Severity == 0))),
                ["limited"] = history.Count(h => h.Outcomes.Any(o => o.LimitedValidation)),
                ["latestId"] = history[0].Id.ToString(),
            };
            return new ContextItem("activity", "mine", "Your recent requests", history[0].Id.ToString("N")[..12], history[0].CreatedAt, facts);
        }
    }
}
