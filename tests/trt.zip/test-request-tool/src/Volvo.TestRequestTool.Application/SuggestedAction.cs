using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>A suggestion. Never executed by the assistant: the person chooses it, and normal workflows (validation, permissions, approval) apply.</summary>
    public sealed record SuggestedAction(string Kind, string Label, JsonObject? Arguments);
}
