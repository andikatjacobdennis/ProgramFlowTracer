using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>The answer and where it came from ("Files: C:\trt\services\edb\specifications\X.json","Http: https://...").</summary>
    public sealed record ServiceReply(JsonObject Body, string Source);
}
