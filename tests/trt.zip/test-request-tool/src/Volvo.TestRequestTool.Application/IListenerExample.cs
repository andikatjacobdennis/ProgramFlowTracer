using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// A handler that can also write a request for a vehicle: the vehicle's chassis, product class and nodes as the sender
    /// would give them, ready to send. The page offers it next to the smallest request the contract accepts.
    /// </summary>
    public interface IListenerExample
    {
        XDocument Example(ListenerMessageType type, ProductDocument vehicle);
    }
}
