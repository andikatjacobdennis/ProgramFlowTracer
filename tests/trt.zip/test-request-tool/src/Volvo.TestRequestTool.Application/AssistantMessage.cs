namespace Volvo.TestRequestTool.Application
{
    // =====================================================================================================================
    // Provider-independent contracts for future generative-AI features: chat, summaries, agent planning and context
    // retrieval. Nothing here depends on an AI vendor or SDK. Today every contract is implemented by SimulatedAssistant
    // (deterministic, rule-based, not AI). A real provider implements the same interfaces and is registered instead; callers,
    // the API and the interface do not change. See docs/ai-readiness.md.
    // =====================================================================================================================

    /// <summary>A message in a conversation. Role: user or assistant. Treated as untrusted text everywhere.</summary>
    public sealed record AssistantMessage(string Role, string Text);
}
