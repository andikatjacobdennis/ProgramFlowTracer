using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The levels below a node for the topology, straight from the product schema, each compared with the stored vehicle:
    /// <list type="bullet">
    /// <item><b>Legacy (TEA2, TEA2+):</b> Hardware (ECU hardware, sub-hardware), Software (main software, primary and secondary
    /// bootloader, complementary software) and Data sets (each with its patches).</item>
    /// <item><b>T3:</b> logical ECUs, their execution environments, and the software products in each (with the package version).</item>
    /// </list>
    /// A part is { id, kind, label, name, from, to, status, children }. Status is added, removed, changed or unchanged, by part
    /// number (package version for T3 software); a group is changed when anything in it changed. Nothing is invented: a slot
    /// that is absent in the data is not shown.
    /// </summary>
    public static class TopologyParts
    {
        public static JsonArray Of(JsonObject node, JsonObject? before, bool added, bool removed)
        {
            var groups = new List<JsonObject>();
            if (node.I("electricalArchitecture") == 3 || node.A("softwareProducts").Count > 0)
            {
                var now = node.A("softwareProducts").Objects().ToList();
                var was = before?.A("softwareProducts").Objects().ToList() ?? [];
                foreach (var lecu in now.Concat(was).Select(sw => sw.S("logicalEcu", "Logical ECU")).Distinct(StringComparer.Ordinal))
                {
                    var envs = new List<JsonObject>();
                    foreach (var env in now.Concat(was).Where(sw => sw.S("logicalEcu", "Logical ECU") == lecu).Select(sw => sw.S("executionEnvironment", "Execution environment")).Distinct(StringComparer.Ordinal))
                    {
                        bool In(JsonObject sw) => sw.S("logicalEcu", "Logical ECU") == lecu && sw.S("executionEnvironment", "Execution environment") == env;
                        var pkgs = Pair(now.Where(In), was.Where(In), ProposalDiff.SoftwareName)
                            .Select(x => Leaf("package:" + lecu + "/" + env + "/" + x.Name, "package", "Software product", x.Name, x.Old?.S("packageVersion", x.Old.S("number")), x.New?.S("packageVersion", x.New.S("number")), added, removed, x.New is null, x.Old is null)).ToList();
                        envs.Add(Group("env:" + lecu + "/" + env, "environment", "Execution environment", env, pkgs));
                    }
                    groups.Add(Group("lecu:" + lecu, "logical-ecu", "Logical ECU", lecu, envs));
                }
                return new JsonArray(groups.Select(g => (JsonNode)g).ToArray());
            }

            // Legacy: hardware, software and data sets.
            var hw = new List<JsonObject>();
            if (node["ecuHardware"] is JsonObject || before?["ecuHardware"] is JsonObject)
            {
                hw.Add(Leaf("hw", "hardware", "ECU hardware", node["ecuHardware"].S("name", before?["ecuHardware"].S("name") ?? "ECU"), before?["ecuHardware"].S("number"), node["ecuHardware"].S("number"), added, removed, node["ecuHardware"] is null, before?["ecuHardware"] is null));
            }

            hw.AddRange(Pair(node.A("subHardwares").Objects(), before?.A("subHardwares").Objects() ?? [], x => x.S("name"))
                .Select(x => Leaf("subhw:" + x.Name, "subhardware", "Sub-hardware", x.Name, x.Old?.S("number"), x.New?.S("number"), added, removed, x.New is null, x.Old is null)));
            if (hw.Count > 0)
            {
                groups.Add(Group("g:hardware", "group", "Hardware", "Hardware", hw));
            }

            var sw = new List<JsonObject>();
            foreach (var (slot, label) in new[] { ("mainSoftware", "Main software"), ("primaryBootloader", "Primary bootloader"), ("secondaryBootloader", "Secondary bootloader") })
            {
                var n = node[slot] as JsonObject;
                var o = before?[slot] as JsonObject;
                if (n is null && o is null)
                {
                    continue;
                }

                sw.Add(Leaf("sw:" + slot, slot == "mainSoftware" ? "software" : "bootloader", label, (n ?? o)!.S("name", label), o?.S("number"), n?.S("number"), added, removed, n is null, o is null));
            }
            sw.AddRange(Pair(node.A("complementarySoftwares").Objects(), before?.A("complementarySoftwares").Objects() ?? [], x => x.S("name"))
                .Select(x => Leaf("csw:" + x.Name, "software", "Complementary software", x.Name, x.Old?.S("number"), x.New?.S("number"), added, removed, x.New is null, x.Old is null)));
            if (sw.Count > 0)
            {
                groups.Add(Group("g:software", "group", "Software", "Software", sw));
            }

            var data = Pair(node.A("datas").Objects(), before?.A("datas").Objects() ?? [], x => x.S("index", x.S("name"))).Select(x =>
            {
                var d = Leaf("data:" + x.Name, "data", "Data set", (x.New ?? x.Old)!.S("name", "Data"), x.Old?.S("number"), x.New?.S("number"), added, removed, x.New is null, x.Old is null);
                var newPatches = x.New?.A("patches").Objects().ToList() ?? [];
                var oldPatches = x.Old?.A("patches").Objects().ToList() ?? [];
                var patches = Enumerable.Range(0, Math.Max(newPatches.Count, oldPatches.Count)).Select(i =>
                {
                    var n = i < newPatches.Count ? newPatches[i] : null;
                    var o = i < oldPatches.Count ? oldPatches[i] : null;
                    return Leaf("data:" + x.Name + ":patch:" + i, "patch", "Patch", (n ?? o)!.S("name", "Patch " + (i + 1)), o?.S("number"), n?.S("number"), added, removed, n is null, o is null);
                }).ToList();
                if (patches.Count > 0)
                {
                    d["children"] = new JsonArray(patches.Select(q => (JsonNode)q).ToArray());
                    if (d.S("status") == "unchanged" && patches.Any(q => q.S("status") != "unchanged"))
                    {
                        d["status"] = "changed";
                    }
                }
                return d;
            }).ToList();
            if (data.Count > 0)
            {
                groups.Add(Group("g:data", "group", "Data sets", "Data sets", data));
            }

            return new JsonArray(groups.Select(g => (JsonNode)g).ToArray());
        }

        /// <summary>Items of a list now and before, paired by a key (unmatched ones are added or removed).</summary>
        static IEnumerable<(string Name, JsonObject? New, JsonObject? Old)> Pair(IEnumerable<JsonObject> now, IEnumerable<JsonObject> was, Func<JsonObject, string> key)
        {
            var a = now.ToList();
            var b = was.ToList();
            foreach (var k in a.Select(key).Concat(b.Select(key)).Distinct(StringComparer.Ordinal))
            {
                yield return (k, a.FirstOrDefault(x => key(x) == k), b.FirstOrDefault(x => key(x) == k));
            }
        }

        static JsonObject Leaf(string id, string kind, string label, string name, string? from, string? to, bool nodeAdded, bool nodeRemoved, bool gone, bool fresh)
        {
            var status = nodeRemoved || gone ? "removed" : nodeAdded || fresh ? "added" : string.Equals(from, to, StringComparison.Ordinal) ? "unchanged" : "changed";
            return new JsonObject { ["id"] = id, ["kind"] = kind, ["label"] = label, ["name"] = name, ["from"] = from, ["to"] = gone ? null : to, ["status"] = status };
        }

        static JsonObject Group(string id, string kind, string label, string name, List<JsonObject> children)
        {
            var status = children.All(c => c.S("status") == "added") ? "added" : children.All(c => c.S("status") == "removed") ? "removed" : children.Any(c => c.S("status") != "unchanged") ? "changed" : "unchanged";
            return new JsonObject { ["id"] = id, ["kind"] = kind, ["label"] = label, ["name"] = name, ["status"] = status, ["count"] = children.Count, ["children"] = new JsonArray(children.Select(c => (JsonNode)c).ToArray()) };
        }
    }
}
