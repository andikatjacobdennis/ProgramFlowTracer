using System.Globalization;
using System.Text.Json.Nodes;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// GetCapabilityResourceBreakdown 1.0 and 1.1 (Request.Listener/ServiceConfigurator/CapabilityResourceBreakdown_1_0 and _1_1):
    /// the product specification broken down by effectivity (factory and date, the tool's production breakdown), and of the
    /// parameters it gets, those whose definition marks them as a capability or a resource. In the catalog a parameter
    /// definition (catalog\paramDefs.json) marks this with "capability": true or "resource": true. The reference catalog marks
    /// none, so until a definition does, the reply says so in a notification instead of inventing capabilities.
    /// useUnreleasedData (1.1) also counts node template versions in progress.
    /// </summary>
    public sealed class CapabilityResourceHandler : ServiceConfiguratorHandler
    {
        private static readonly XNamespace Cap = "http://esw.volvo.com/capabilitiescommon/1_0";
        private readonly ListenerCatalog _catalog;

        public CapabilityResourceHandler(ListenerCatalog catalog, TimeProvider clock) : base(clock)
        {
            _catalog = catalog;
        }

        public override IReadOnlyCollection<string> Keys { get; } = ["GetCapabilityResourceBreakdown_1.0", "GetCapabilityResourceBreakdown_1.1"];

        protected override string ReplyRoot => "CapabilityResourceBreakdownResponse";

        protected override XNamespace ReplyNs(ListenerMessageType type) => "http://esw.volvo.com/capabilitybreakdownresponse/" + type.Version.Replace('.', '_');

        private static XNamespace RequestNs(ListenerMessageType type) => "http://esw.volvo.com/capabilitybreakdownrequest/" + type.Version.Replace('.', '_');

        protected override string Kind(ListenerMessageType type) => "Capability Breakdown";

        protected override (string Schema, string Id, string Version) Service(ListenerMessageType type) => type.Version == "1.1" ? ("1.1", "SRV13087", "1.1") : ("1.0", "SRV06402", "1.0");

        protected override async Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct)
        {
            var root = message.Xml!.Root!;
            var ns = ReplyNs(message.Type);
            var spec = ListenerXml.Child(root, "ProductSpecification");
            var productClass = ListenerXml.Text(ListenerXml.Child(spec, "ProductClass"), "ProductClass") ?? "";
            var unreleased = ListenerXml.Flag(ListenerXml.Attribute(root, "useUnreleasedData"));
            var effectivity = ListenerXml.Child(root, "Effectivity");
            var date = DateTime.TryParse(ListenerXml.Text(effectivity, "Date"), CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal, out var d) ? d : DateTime.UtcNow;
            var week = (ISOWeek.GetYear(date) * 100 + ISOWeek.GetWeekOfYear(date)).ToString(CultureInfo.InvariantCulture);
            var notices = new List<BreakdownNotice>();
            var summary = new List<ListenerFact>();
            var context = _catalog.Catalog.Data.A("contexts").Objects().FirstOrDefault(c => c.A("productClassIds").Any(p => p?.ToString() == productClass));
            var capabilities = new List<XElement>();
            var resources = new List<XElement>();
            if (context is null)
            {
                notices.Add(new("Error", "PRODUCT CLASS UNKNOWN", $"Product class {productClass} is unknown.", "No context of the catalog has this product class.", "Use another product class."));
            }
            else
            {
                var symbols = ListenerXml.Children(ListenerXml.Child(spec, "Variants"), "Variant")
                    .Select(v => _catalog.Catalog.Data.A("variants").Objects().FirstOrDefault(x => x.S("familyId") == ListenerXml.Text(v, "FamilyId") && x.S("variantId") == ListenerXml.Text(v, "VariantId"))?.S("symbol"))
                    .Where(s => s is not null).ToHashSet(StringComparer.OrdinalIgnoreCase);
                var definitions = (_catalog.Catalog.Data["paramDefs"] as JsonObject ?? []).Select(p => p.Value).OfType<JsonObject>().ToList();
                var flagged = definitions.Where(x => x.B("capability") || x.B("resource")).ToDictionary(x => x.I("ea") + ":" + x.S("code"), StringComparer.Ordinal);
                var parameters = new Dictionary<string, (JsonObject Parameter, JsonObject Template)>(StringComparer.Ordinal);
                foreach (var template in _catalog.Catalog.Templates(context.I("id")))
                {
                    var condition = template.A("condition").Select(c => c?.ToString() ?? "").Where(c => c.Length > 0).ToList();
                    if (condition.Count > 0 && !condition.Any(symbols.Contains))
                    {
                        continue;
                    }

                    var version = ListenerCatalog.Versions(template).Where(v => SoftwareHandler.Allowed(v, unreleased ? 5 : 1) && string.CompareOrdinal(v.S("introductionWeek"), week) <= 0).OrderByDescending(v => v.I("idx")).FirstOrDefault();
                    foreach (var parameter in version.A("parameters").Objects().Where(p => p.I("electricalArchitecture") != 0))
                    {
                        parameters.TryAdd(parameter.I("electricalArchitecture") + ":" + parameter.S("code"), (parameter, template));
                    }
                }

                foreach (var (key, (parameter, template)) in parameters.OrderBy(p => p.Value.Parameter.S("code"), StringComparer.Ordinal))
                {
                    if (!flagged.TryGetValue(key, out var definition))
                    {
                        continue;
                    }

                    var condition = template.A("condition").Select(c => c?.ToString() ?? "").Where(c => c.Length > 0).ToList();
                    var element = Value(definition.B("capability") ? Cap + "ComponentCapability" : Cap + "Resource", parameter, definition, productClass, condition);
                    (definition.B("capability") ? capabilities : resources).Add(element);
                }

                summary.Add(new ListenerFact("Breakdown", $"{parameters.Count} TEA2+ parameter(s) for the product class in week {week}."));
                if (flagged.Count == 0)
                {
                    notices.Add(new("Information", "NO CAPABILITY DATA", "The catalog marks no parameter as a capability or a resource.", "No parameter definition in the catalog has \"capability\" or \"resource\" set.", "Mark the parameter definitions in catalog\\paramDefs.json to get them here."));
                }
            }

            var reply = Reply(message, Transaction(message),
                capabilities.Count == 0 ? null : new XElement(ns + "ComponentCapabilities", capabilities),
                resources.Count == 0 ? null : new XElement(ns + "Resources", resources),
                Notifications(message.Type, notices));
            summary.Insert(0, new ListenerFact("Outcome", $"{capabilities.Count} capabilit{(capabilities.Count == 1 ? "y" : "ies")} and {resources.Count} resource(s)."));
            summary.AddRange(notices.Select(n => new ListenerFact($"{n.Severity}: {n.Type}", n.Text)));
            return new ListenerAnswer(reply, summary, []);
        }

        /// <summary>A capability or resource: the parameter code and value, with its source (product class and variant condition).</summary>
        private static XElement Value(XName name, JsonObject parameter, JsonObject definition, string productClass, List<string> condition) =>
            new(name,
                new XElement(Scc + "ParameterCode", parameter.S("code")),
                new XElement(Scc + "ParameterValue",
                    ProductsUpdateWriter.Value(definition, parameter.A("references").Objects().FirstOrDefault().S("value")),
                    new XElement(Scc + "Source",
                        new XElement(Scc + "ProductClass", BreakdownXml.ProductClass(productClass)),
                        new XElement(Scc + "Condition", condition.Count == 0 ? new XElement(Scc + "AlwaysMatch") : null))));

        public override XDocument Example(ListenerMessageType type, ProductDocument vehicle)
        {
            var ns = RequestNs(type);
            var (schema, id, version) = Service(type);
            return Document(new XElement(ns + "CapabilityResourceBreakdownRequest",
                Header(schema, id, version),
                Effectivity(ns + "Effectivity", vehicle),
                Specification(ns + "ProductSpecification", vehicle)));
        }
    }
}
