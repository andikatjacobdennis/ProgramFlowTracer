using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// Vocabulary and translators shared by the JSON aftermarket services that support T3 HPC nodes:
    /// Product Update Service 1.0/2.0 and Available Product Updates 1.0/1.1 (gateway Request.Listener/Aftermarket).
    /// Implementation over the catalog: field names follow the live contracts, the logic is simulated.
    /// </summary>
    public static class ServiceContract
    {
        /// <summary>criteria.scenario wire values mapped to the catalog's scenario scale (1 Introduced … 5 InProgress).</summary>
        public static readonly IReadOnlyDictionary<string, int> Scenarios = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase)
        {
            ["Introduced"] = 1,
            ["IntroductionDateSet"] = 2,
            ["Released"] = 3,
            ["PreReleaseVerification"] = 4,
            ["InProgress"] = 5
        };

        public const int UnhandledError = 100;   // Invalid JSON, schema failure (PUS) or unexpected exception.
        public const int InvalidMessage = 107;   // Request validation failure or unsupported operation.

        public static bool TryScenario(JsonNode? criteria, out int value, out string name)
        {
            name = criteria.S("scenario", "Introduced");
            return Scenarios.TryGetValue(name, out value);
        }

        public static string ScenarioName(int value) => Scenarios.First(x => x.Value == value).Key;
        public static bool IsHpc(JsonObject node) => node.I("electricalArchitecture") == 3;
        public static string PadSeries(string series) => series.PadRight(5);

        public static string TemplateStatus(string status) => status switch
        {
            "released" => "Released",
            "introduced" => "Introduced",
            "prereleaseverification" => "PreReleased",
            "inprogress" => "InProgress",
            "withdrawn" => "Withdrawn",
            _ => "Unknown"
        };

        /// <summary>Contract "product" block: identification, description, specification and configuration.nodes as tea2PlusNode or hpcNode.</summary>
        public static JsonObject Product(ProductDocument p, string service)
        {
            var spec = p.Data["productSpecification"];
            return new JsonObject
            {
                ["identification"] = new JsonObject { ["chassisId"] = new JsonObject { ["series"] = p.Info.S("chassisSeries"), ["number"] = p.Info.S("chassisNumber") }, ["vin"] = p.Info.S("vin") },
                ["description"] = new JsonObject { ["productClassCode"] = p.Info.S("productClassId"), ["countryOfOperation"] = p.Info.S("countryOfOperation", "SWE"), ["specificationDate"] = p.Info.S("specificationDate").Split('T')[0] },
                ["specification"] = new JsonObject
                {
                    ["variants"] = new JsonArray(spec.A("variants").Objects().Select(v => v.S("idVar6")).Where(v => v.Length == 6).Select(v => (JsonNode)v).ToArray()),
                    ["customerAdaptations"] = new JsonArray(spec.A("sNotes").Objects().Select(s => (JsonNode)s.S("id", s.S("sNoteId"))).ToArray())
                },
                ["configuration"] = new JsonObject
                {
                    ["parameterValues"] = new JsonArray(p.Parameters.Objects().Select(x => (JsonNode)new JsonObject { ["parameterCode"] = x.S("code"), ["string"] = new JsonObject { ["value"] = x["references"]?.ToJsonString() ?? "" } }).ToArray()),
                    ["nodes"] = new JsonArray(p.Nodes.Objects().Select(n => (JsonNode)RequestNode(n, service)).ToArray())
                }
            };
        }

        static JsonObject NodeName(JsonObject node) => new() { ["family"] = node["nodeIdentifier"].I("family"), ["type"] = node["nodeIdentifier"].I("type"), ["position"] = node["nodeIdentifier"].I("position") };

        /// <summary>Request-side node. PUS software products carry target and deploymentArtifacts; APU carries id/templateId and artifactInfos.</summary>
        static JsonObject RequestNode(JsonObject node, string service)
        {
            var hardware = new JsonObject { ["partNumber"] = node["ecuHardware"].I("number").ToString(System.Globalization.CultureInfo.InvariantCulture), ["serialNumber"] = node["ecuHardware"].S("serialNumber") };
            if (!IsHpc(node))
            {
                return new JsonObject
                {
                    ["tea2PlusNode"] = new JsonObject
                    {
                        ["nodeName"] = NodeName(node),
                        ["nodeTemplateDocumentNumber"] = node["nodeTemplateDocument"].I("number"),
                        ["ecuHardware"] = hardware,
                        ["mainSoftware"] = node["mainSoftware"] is null ? null : new JsonObject { ["partNumber"] = node["mainSoftware"].I("number") },
                        ["primaryBootloader"] = node["primaryBootloader"] is null ? null : new JsonObject { ["partNumber"] = node["primaryBootloader"].I("number") }
                    }
                };
            }

            var environments = new JsonArray();
            foreach (var env in node.A("softwareProducts").Objects().GroupBy(s => s.S("executionEnvironment", node.S("name"))))
            {
                environments.Add(new JsonObject
                {
                    ["nodeName"] = env.Key,
                    ["softwareProducts"] = new JsonArray(env.Select(s => (JsonNode)(service == "PUS"
                    ? new JsonObject
                    {
                        ["name"] = s.S("softwareProduct"),
                        ["version"] = s.S("packageVersion"),
                        ["deployer"] = "UCM",
                        ["documentNumber"] = s.I("number"),
                        ["target"] = s.S("logicalEcu"),
                        ["deploymentArtifacts"] = new JsonArray(new JsonObject { ["id"] = s.I("number"), ["sha"] = s.S("artifactSHA") })
                    }
                    : new JsonObject
                    {
                        ["id"] = s.I("number"),
                        ["name"] = s.S("softwareProduct"),
                        ["version"] = s.S("packageVersion"),
                        ["deployer"] = "UCM",
                        ["documentNumber"] = s.I("number"),
                        ["templateId"] = s.S("parameterTemplate"),
                        ["artifactInfos"] = new JsonArray(new JsonObject { ["artifactId"] = s.S("artifactSHA"), ["id"] = s.I("number") })
                    })).ToArray()),
                    ["executionEnvironments"] = new JsonArray()
                });
            }

            return new JsonObject
            {
                ["hpcNode"] = new JsonObject
                {
                    ["nodeName"] = NodeName(node),
                    ["logicalEcu"] = node.A("softwareProducts").Objects().Select(s => s.S("logicalEcu")).FirstOrDefault(x => x.Length > 0),
                    ["ecuHardware"] = hardware,
                    ["executionEnvironments"] = environments,
                    ["virtualTea2PlusNodes"] = new JsonArray()
                }
            };
        }

        /// <summary>Response-side node, as in the gateway NodeTranslator. version selects 1.1-only software product fields.</summary>
        public static JsonObject ResponseNode(JsonObject node, JsonObject? version, ProductDocument p, bool sameSoftware, bool withProductIds)
        {
            var o = new JsonObject
            {
                ["chassisSeries"] = PadSeries(p.Info.S("chassisSeries")),
                ["chassisNumber"] = p.Info.S("chassisNumber"),
                ["nodeName"] = node.S("name"),
                ["ecuHardware"] = new JsonObject { ["partNumber"] = node["ecuHardware"].I("number").ToString(System.Globalization.CultureInfo.InvariantCulture), ["serialNumber"] = node["ecuHardware"].S("serialNumber") },
                ["isSoftwareSame"] = sameSoftware,
                ["nodeTemplateDocumentNumber"] = version?.I("doc"),
                ["nodeTemplateStatus"] = TemplateStatus(version?.S("status") ?? node.S("nodeTemplateStatus")),
                ["remoteSwdlAvailability"] = version is null ? "NotSupportedByNodeTemplate" : version.B("remoteCapable") ? "General" : "NotSupportedByNodeTemplate"
            };
            if (!IsHpc(node))
            {
                return new JsonObject { ["tea2PlusNode"] = o };
            }

            var target = (JsonObject?)version?["node"] ?? node;
            o["executionEnvironments"] = new JsonArray(target.A("softwareProducts").Objects().GroupBy(s => s.S("executionEnvironment", node.S("name"))).Select(env => (JsonNode)new JsonObject
            {
                ["nodeName"] = env.Key,
                ["softwareProducts"] = new JsonArray(env.Select(s =>
                {
                    var sp = new JsonObject { ["artifactId"] = s.S("artifactSHA"), ["buildId"] = s.S("packageVersion"), ["name"] = s.S("softwareProduct"), ["version"] = s.S("packageVersion") };
                    if (withProductIds)
                    {
                        sp["id"] = s.I("number");
                        sp["templateId"] = string.IsNullOrEmpty(s.S("parameterTemplate")) ? null : s.S("parameterTemplate");
                    }
                    return (JsonNode)sp;
                }).ToArray())
            }).ToArray());
            return new JsonObject { ["hpcNode"] = o };
        }
    }
}
