using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>A breakdown: the product as broken down (null when the product could not be broken down), the baseline guid, notifications.</summary>
    public sealed record BreakdownResult(ProductDocument? Product, string Baseline, IReadOnlyList<BreakdownNotice> Notices);
}
