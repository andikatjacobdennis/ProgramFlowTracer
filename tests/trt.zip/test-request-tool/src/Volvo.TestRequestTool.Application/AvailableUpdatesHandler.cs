using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    public sealed class AvailableUpdatesHandler : IRequestHandler
    {
        private readonly ICatalog _catalog;

        public AvailableUpdatesHandler(ICatalog catalog)
        {
            _catalog = catalog;
        }

        public RequestKind Kind => RequestKind.AvailableUpdates;

        public ValueTask<HandlerResult> HandleAsync(ProductDocument original, JsonObject payload, CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested();
            var rows = new JsonArray();
            foreach (var node in original.Nodes.Objects())
            {
                var template = _catalog.FindTemplate(node);
                if (template is null)
                {
                    continue;
                }

                var available = template.A("versions").Objects().Where(v => SoftwareHandler.Allowed(v, payload.I("scenario", 1)) && SoftwareHandler.Compatible(v, node, payload)).OrderByDescending(v => v.I("idx")).FirstOrDefault();
                rows.Add(new JsonObject { ["node"] = node.S("name"), ["currentDocument"] = node["nodeTemplateDocument"].I("number"), ["availableNodeTemplate"] = available is null ? null : new JsonObject { ["documentNumber"] = available.I("doc"), ["versionName"] = available.S("versionName"), ["status"] = available.S("status") } });
            }
            return ValueTask.FromResult(new HandlerResult(original.Copy(), [], new JsonObject { ["vehicleId"] = original.Id, ["nodes"] = rows, ["selectedCriteria"] = payload["actionCriteriaTypes"]?.DeepClone(), ["kits"] = _catalog.Data["kits"]?.DeepClone() }));
        }
    }
}
