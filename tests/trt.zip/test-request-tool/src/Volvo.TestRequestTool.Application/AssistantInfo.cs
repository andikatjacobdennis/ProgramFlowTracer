namespace Volvo.TestRequestTool.Application
{
    public sealed record AssistantInfo(string Provider, bool Simulated, string Label, string Description, IReadOnlyList<string> Capabilities, IReadOnlyList<string> Guardrails, string Retention);
}
