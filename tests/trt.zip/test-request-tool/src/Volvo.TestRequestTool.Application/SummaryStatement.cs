namespace Volvo.TestRequestTool.Application
{
    /// <summary>A summary statement and the record it comes from (so the interface can link to it).</summary>
    public sealed record SummaryStatement(string Text, string Section, ContextRef? Source);
}
