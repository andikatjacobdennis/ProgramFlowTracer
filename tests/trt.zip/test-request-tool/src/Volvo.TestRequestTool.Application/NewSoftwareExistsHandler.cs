using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// GetNewSoftwareExists 1.0 (Request.Listener/Aftermarket/NewSoftwareExists_1_0, NewSoftwareExists_1.0.2): whether newer
    /// software exists for any node of the products. SoftwarePackage looks for a newer version in each node's replacement
    /// chain that the scenario allows and the hardware takes; ServicePack looks for a node the newest service pack of the
    /// vehicle context moves forward. The reply is Accepted with Outcome newSoftwareExists true or false.
    /// </summary>
    public sealed class NewSoftwareExistsHandler : ListenerXmlHandler
    {
        private static readonly XNamespace Ns = "http://www.volvo.com/NewSoftwareExists/1_0";
        private readonly ListenerProducts _products;
        private readonly ListenerCatalog _catalog;

        public NewSoftwareExistsHandler(ListenerProducts products, ListenerCatalog catalog, TimeProvider clock) : base(clock)
        {
            _products = products;
            _catalog = catalog;
        }

        public override IReadOnlyCollection<string> Keys { get; } = ["GetNewSoftwareExists_1.0"];

        protected override async Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct)
        {
            var data = ListenerXml.Find(message.Xml, "DataArea");
            var criteria = ListenerXml.Child(data, "Criteria");
            var action = ListenerXml.Attribute(criteria, "action") ?? "SoftwarePackage";
            var scenario = ListenerCatalog.Scenario(ListenerXml.Attribute(criteria, "scenario"));
            var pbl = ListenerXml.Flag(ListenerXml.Attribute(criteria, "pblUpdateCapable"));
            var summary = new List<ListenerFact> { new("Asked", action == "ServicePack" ? "Does the newest service pack change any node?" : "Does newer software exist for any node?") };
            var exists = false;
            foreach (var element in ListenerXml.Children(data, "Product"))
            {
                var product = await _products.ReadAsync(element, message.Actor, ct);
                summary.Add(product.Source);
                var newer = action == "ServicePack" ? ByServicePack(product.Product) : BySoftware(product.Product, scenario, pbl);
                summary.Add(new ListenerFact(product.Shown, newer.Count == 0 ? "No newer software." : "Newer software for " + string.Join(", ", newer) + "."));
                exists |= newer.Count > 0;
            }

            var root = ListenerXml.Bod(Ns, "ShowNewSoftwareExists", "SRV13251", "1.0", ListenerXml.Transaction(message.Xml), Clock,
                ListenerXml.Accepted(Ns, string.Empty),
                new XElement(Ns + "Outcome", new XAttribute("newSoftwareExists", exists ? "true" : "false")));
            summary.Insert(0, new ListenerFact("Outcome", exists ? "New software exists." : "No new software."));
            return new ListenerAnswer(root, summary, []);
        }

        protected override XElement Error(ListenerMessage message, ListenerNotice notice, string bodId) =>
            ListenerXml.Bod(Ns, "ShowNewSoftwareExists", "SRV13251", "1.0", bodId, Clock, ListenerXml.Rejected(Ns, notice));

        public override XDocument Example(ListenerMessageType type, ProductDocument vehicle) =>
            Document(new XElement(Ns + "GetNewSoftwareExists",
                ListenerXml.RequestArea(Clock),
                new XElement(Ns + "DataArea",
                    new XElement(Ns + "Criteria", new XAttribute("action", "SoftwarePackage"), new XAttribute("scenario", "Introduced"), new XAttribute("pblUpdateCapable", "true")),
                    ListenerProducts.ProductElement(Ns, "Product", vehicle, connectedServices: true))));

        private List<string> BySoftware(ProductDocument product, int scenario, bool pbl)
        {
            var newer = new List<string>();
            foreach (var node in product.Nodes.Objects())
            {
                var template = _catalog.Template(node);
                if (template is null)
                {
                    continue;
                }

                var current = ListenerCatalog.Current(template, node);
                var latest = ListenerCatalog.Latest(template, node, scenario, remote: false, pbl);
                if (latest is not null && (current is null || latest.I("idx") > current.I("idx")))
                {
                    newer.Add(ListenerCatalog.Name(node));
                }
            }

            return newer;
        }

        private List<string> ByServicePack(ProductDocument product)
        {
            var pack = _catalog.Catalog.Data.A("servicePacks").Objects().Where(p => p.I("contextId") == product.ContextId).OrderByDescending(p => p.I("sortOrder")).FirstOrDefault();
            if (pack is null)
            {
                return [];
            }

            var newer = new List<string>();
            foreach (var node in product.Nodes.Objects())
            {
                var template = _catalog.Template(node);
                var current = template is null ? null : ListenerCatalog.Current(template, node);
                var target = template is null ? -1 : pack["ntps"].I(template.S("key"), -1);
                if (target >= 0 && (current is null || target > current.I("idx")))
                {
                    newer.Add(ListenerCatalog.Name(node));
                }
            }

            return newer;
        }
    }
}
