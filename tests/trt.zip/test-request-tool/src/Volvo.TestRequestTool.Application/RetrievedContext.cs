namespace Volvo.TestRequestTool.Application
{
    public sealed record RetrievedContext(IReadOnlyList<ContextItem> Items, IReadOnlyList<string> Unavailable);
}
