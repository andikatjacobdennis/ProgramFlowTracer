namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// An outage or slow spell, with its root cause. RootService is set when the cause was another service failing first
    /// (found by dependency and time correlation); Impacted lists the services that failed because of this one.
    /// </summary>
    public sealed record ServiceIncident(string Id, string Service, string Severity, DateTimeOffset Start, DateTimeOffset? End, double Minutes, string Cause, string CauseTitle,
        string RootCause, string? RootService, string? RootIncident, bool Planned, string Confidence, IReadOnlyList<string> Impacted, IReadOnlyList<IncidentEvent> Timeline, bool Simulated);
}
