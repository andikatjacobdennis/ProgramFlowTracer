namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// A notification of a breakdown or consistency check reply (BreakdownModuleCommon NotificationType): severity (Error,
    /// Warning or Information), the type word (for example SLOT EMPTY), text, reason, action, and an optional nested detail.
    /// </summary>
    public sealed record BreakdownNotice(string Severity, string Type, string Text, string Reason, string Action, BreakdownNotice? Details = null)
    {
        /// <summary>The listener's notification for a request it could not process (ErrorNotificationFactory).</summary>
        public static BreakdownNotice TechnicalError(string what, string message) =>
            new("Error", "TECHNICAL ERROR", what, message, "Please contact support. This error has to be resolved by the maintenance organisation.",
                new BreakdownNotice("Error", "TECHNICAL ERROR", message, string.Empty, string.Empty));
    }
}
