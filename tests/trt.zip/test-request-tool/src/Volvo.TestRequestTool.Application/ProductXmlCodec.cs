using System.Text.Json.Nodes;
using System.Xml;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Application
{
    /// <summary>Lossless simulator XML interchange, not a production contract schema.</summary>
    public static class ProductXmlCodec
    {
        private static readonly XNamespace Ns = "urn:test-request-studio:product:1";
        public static string Export(JsonObject product) => Document(product, "Product");
        /// <summary>Any JSON object as XML under the given root element, in the same lossless form (the repository's XML files).</summary>
        public static string Document(JsonObject value, string root) => new XDocument(new XElement(Ns + XmlConvert.EncodeLocalName(root), value.Select(kv => Write(kv.Key, kv.Value)))).ToString();

        /// <summary>Reads what <see cref="Document"/> wrote, whatever its root element.</summary>
        public static JsonObject ReadDocument(string xml)
        {
            using var reader = XmlReader.Create(new StringReader(xml), new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null });
            var doc = XDocument.Load(reader);
            if (doc.Root?.Name.Namespace != Ns)
            {
                throw new InvalidDataException("Not a Test Request Tool XML document.");
            }

            return new JsonObject(doc.Root.Elements().Select(e => KeyValuePair.Create(XmlConvert.DecodeName(e.Name.LocalName), Read(e))));
        }

        public static JsonObject Import(string xml)
        {
            try
            {
                using var reader = XmlReader.Create(new StringReader(xml), new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null, MaxCharactersInDocument = 2_000_000 });
                var doc = XDocument.Load(reader);
                if (doc.Root?.Name != Ns + "Product")
                {
                    throw new RequestFault(400, "xml_root", "Expected Test Request Tool product XML.");
                }

                return new JsonObject(doc.Root.Elements().Select(e => KeyValuePair.Create(XmlConvert.DecodeName(e.Name.LocalName), Read(e))));
            }
            catch (XmlException)
            {
                throw new RequestFault(400, "invalid_xml", "XML is invalid, too large or contains a prohibited DTD.");
            }
        }

        private static XElement Write(string key, JsonNode? value)
        {
            var el = new XElement(Ns + XmlConvert.EncodeLocalName(key));
            if (value is null)
            {
                el.SetAttributeValue("kind", "null");
                return el;
            }
            if (value is JsonObject obj)
            {
                el.SetAttributeValue("kind", "object");
                el.Add(obj.Select(p => Write(p.Key, p.Value)));
            }
            else if (value is JsonArray arr)
            {
                el.SetAttributeValue("kind", "array");
                el.Add(arr.Select(v => Write("Item", v)));
            }
            else
            {
                var json = value.ToJsonString();
                el.SetAttributeValue("kind", json.StartsWith('"') ? "string" : "scalar");
                el.Value = json.StartsWith('"') ? value.ToString() : json;
            }
            return el;
        }

        private static JsonNode? Read(XElement e) => e.Attribute("kind")?.Value switch
        {
            "null" => null,
            "object" => new JsonObject(e.Elements().Select(c => KeyValuePair.Create(XmlConvert.DecodeName(c.Name.LocalName), Read(c)))),
            "array" => new JsonArray(e.Elements().Select(Read).ToArray()),
            "string" => JsonValue.Create(e.Value),
            "scalar" => JsonNode.Parse(e.Value),
            _ => throw new RequestFault(400, "xml_kind", "Unknown Test Request Tool XML value kind.")
        };
    }
}
