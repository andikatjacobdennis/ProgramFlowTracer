namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// What a listener handler answers: the reply body as the listener sends it (<see cref="MediaType"/> is
    /// application/xml, application/json or text/plain), its notifications and a readable summary.
    /// </summary>
    public sealed record ListenerReply(string Body, string MediaType, IReadOnlyList<ListenerNotice> Notices, IReadOnlyList<ListenerFact> Summary)
    {
        public const string Xml = "application/xml";
        public const string JsonText = "application/json";
        public const string Text = "text/plain";
    }
}
