using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>ServiceResponse carries the contract-shaped reply of JSON services such as Product Update Service.</summary>
    public sealed record HandlerResult(ProductDocument Proposal, IReadOnlyList<ValidationIssue> Issues, JsonObject? AvailableUpdates = null, JsonObject? ServiceResponse = null);
}
