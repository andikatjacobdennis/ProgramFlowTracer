namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// A request the listener cannot answer, with the listener's error code (ErrorCode.cs in swb-stable1). Handlers throw it
    /// where the listener throws a NotificationException; the reply then carries the code and text in the contract's own way.
    /// </summary>
    public sealed class ListenerFault : Exception
    {
        public ListenerFault(int code, string name, string message) : base(message)
        {
            Code = code;
            Name = name;
        }

        public int Code { get; }
        public string Name { get; }

        public ListenerNotice Notice => ListenerNotice.Error(Code, Name, Message);

        public static ListenerFault Undefined(string message) => new(100, "Undefined", message);
        public static ListenerFault RequestedNode(string message) => new(102, "RequestedNodeError", message);
        public static ListenerFault InvalidProduct(string message) => new(103, "InvalidProductError", message);
        public static ListenerFault InvalidMessage(string message) => new(107, "InvalidMessage", message);
        public static ListenerFault NoValidConfigurations(string message) => new(110, "NoValidConfigurationsError", message);
        public static ListenerFault KitNotIntroduced(string message) => new(111, "ConversionKitNotIntroduced", message);
        public static ListenerFault KitNotFound(string message) => new(113, "ConversionKitNotFound", message);
        public static ListenerFault NoMatchingKitOperations(string message) => new(117, "NoMatchingKitOperations", message);
        public static ListenerFault NodeMissing(string message) => new(118, "NodeMissing", message);
        public static ListenerFault KitAlreadyApplied(string message) => new(128, "KitAlreadyApplied", message);
        public static ListenerFault KitNotServiceKit(string message) => new(130, "KitNotServiceKit", message);
    }
}
