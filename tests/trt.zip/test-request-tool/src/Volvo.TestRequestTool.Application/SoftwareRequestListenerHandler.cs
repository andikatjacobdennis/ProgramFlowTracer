using System.Text.Json.Nodes;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// ESW_SOFTWARE_CONFIGURATION_REQUEST 3.1 (Request.Listener/Aftermarket/SoftwareRequest_3_1, SoftwareRequest_3.1.12): the
    /// software operation (Refresh, Repair, Update, Resolve or UpdateToServicePack) on the requested nodes of each product,
    /// all nodes when none are requested, by the tool's SoftwareHandler: the same rules as a software request on the
    /// Requests pages. The reply is ProductsUpdate 1.1, with the service pack for UpdateToServicePack.
    /// </summary>
    public sealed class SoftwareRequestListenerHandler : ListenerXmlHandler
    {
        private static readonly XNamespace Ns = "http://www.volvo.com/SoftwareRequest/3_1";
        private static readonly XNamespace Reply = "http://www.volvo.com/ProductsUpdate/1_1";
        private readonly ListenerProducts _products;
        private readonly ListenerCatalog _catalog;
        private readonly SoftwareHandler _software;
        private readonly ProductsUpdateWriter _writer;

        public SoftwareRequestListenerHandler(ListenerProducts products, ListenerCatalog catalog, TimeProvider clock) : base(clock)
        {
            _products = products;
            _catalog = catalog;
            _software = new SoftwareHandler(catalog.Catalog, clock);
            _writer = new ProductsUpdateWriter(catalog.Catalog);
        }

        public override IReadOnlyCollection<string> Keys { get; } = ["ESW_SOFTWARE_CONFIGURATION_REQUEST_3.1"];

        /// <summary>The OperationType of the contracts on the tool's scale (SoftwareOperation).</summary>
        public static int Operation(string? operation) => operation switch
        {
            "Refresh" => 1,
            "Repair" => 2,
            "Update" => 3,
            "Resolve" => 4,
            "UpdateToServicePack" => 5,
            _ => throw ListenerFault.Undefined($"Unhandled operation type: {operation}"),
        };

        protected override async Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct)
        {
            var data = ListenerXml.Find(message.Xml, "DataArea");
            var criteria = ListenerXml.Child(data, "Criteria");
            var operation = Operation(ListenerXml.Attribute(criteria, "operation"));
            var requested = ListenerXml.Children(ListenerXml.Child(data, "RequestedNodes"), "Node").ToList();
            var summary = new List<ListenerFact>();
            var updates = new List<XElement>();
            JsonObject? pack = null;
            foreach (var element in ListenerXml.Children(data, "Product"))
            {
                var product = await _products.ReadAsync(element, message.Actor, ct);
                summary.Add(product.Source);
                var mine = requested.Where(r => ListenerProducts.Series(ListenerXml.Attribute(r, "chassisSeries") ?? "") == product.ChassisSeries && ListenerProducts.Number(ListenerXml.Attribute(r, "chassisNumber") ?? "") == product.ChassisNumber).ToList();
                var payload = Payload(criteria, operation, product.Product, mine);
                var result = await _software.HandleAsync(product.Product, payload, ct);
                if (ProductsUpdateWriter.Fault(result.Issues) is { } fault)
                {
                    throw fault;
                }

                summary.Add(new ListenerFact(product.Shown, ProductsUpdateWriter.Describe(product.Product, result.Proposal)));
                summary.AddRange(result.Issues.Where(i => i.Severity > 0).Select(i => new ListenerFact(i.Node ?? product.Shown, i.Text)));
                if (operation == 5)
                {
                    pack = _catalog.Catalog.Data.A("servicePacks").Objects().FirstOrDefault(p => p.S("guid") == result.Proposal.Info.S("servicePackGuid"));
                }

                updates.Add(new XElement(Reply + "ProductUpdate", new XAttribute("chassisSeries", product.ChassisSeries), new XAttribute("chassisNumber", product.ChassisNumber),
                    _writer.Delta(Reply, product.Product, result.Proposal, v11: true, null)));
            }

            var root = ListenerXml.Bod(Reply, "ProductsUpdate", "SRV12924", "3.1", ListenerXml.Transaction(message.Xml), Clock,
                ListenerXml.Accepted(Reply), updates, pack is null ? null : ProductsUpdateWriter.ServicePack(Reply, pack));
            summary.Insert(0, new ListenerFact("Outcome", $"Accepted: {ListenerXml.Attribute(criteria, "operation")}."));
            return new ListenerAnswer(root, summary, []);
        }

        protected override XElement Error(ListenerMessage message, ListenerNotice notice, string bodId) =>
            ListenerXml.Bod(Reply, "ProductsUpdate", "SRV12924", "3.1", bodId, Clock, ListenerXml.Rejected(Reply, notice));

        public override XDocument Example(ListenerMessageType type, ProductDocument vehicle) =>
            Document(new XElement(Ns + "GetSoftware",
                ListenerXml.RequestArea(Clock),
                new XElement(Ns + "DataArea",
                    new XElement(Ns + "Criteria", new XAttribute("operation", "Update"), new XAttribute("scenario", "Introduced"), new XAttribute("pblUpdateCapable", "true")),
                    ListenerProducts.ProductElement(Ns, "Product", vehicle))));

        /// <summary>The SoftwareHandler payload of a listener request: operation, scenario, the requested nodes and the flags.</summary>
        public static JsonObject Payload(XElement? criteria, int operation, ProductDocument product, IEnumerable<XElement> requested) => new()
        {
            ["softwareRequestOperation"] = operation,
            ["scenario"] = ListenerCatalog.Scenario(ListenerXml.Attribute(criteria, "scenario")),
            ["pblUpdateCapable"] = ListenerXml.Flag(ListenerXml.Attribute(criteria, "pblUpdateCapable")),
            ["enableMultiNodeBehavior"] = ListenerXml.Attribute(criteria, "enableMultiNodeBehavior") is not { } multi || ListenerXml.Flag(multi),
            ["remoteRequest"] = ListenerXml.Attribute(criteria, "remoteSWDLScenario") is null ? 0 : 1,
            ["groupAdministrativeParameters"] = ListenerXml.Flag(ListenerXml.Attribute(criteria, "groupAdministrativeParameters")),
            ["limitTo"] = ListenerXml.Attribute(criteria, "limitTo") ?? "",
            ["requestedNodes"] = new JsonArray(requested.Select(r => product.Nodes.Objects().FirstOrDefault(n => ListenerCatalog.Matches(r, n)) is { } node
                ? (JsonNode)new JsonObject { ["nodeIdentifier"] = node["nodeIdentifier"]!.DeepClone() }
                : throw ListenerFault.NodeMissing("A requested node is not in the product.")).ToArray()),
        };
    }
}
