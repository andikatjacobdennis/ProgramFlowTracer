using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// One call to an external service (EDB, CBR, KAX, ...). Operation names what is asked ("specifications", "orders");
    /// Key picks one item to read; Body is sent for calls that submit something.
    /// </summary>
    public sealed record ServiceCall(string Service, string Operation, string? Key = null, JsonObject? Body = null);
}
