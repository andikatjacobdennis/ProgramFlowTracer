using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Application
{
    public sealed class SoftwareHandler : IRequestHandler
    {
        private readonly ICatalog _catalog;
        private readonly TimeProvider? _clock;

        public SoftwareHandler(ICatalog catalog, TimeProvider? clock = null)
        {
            _catalog = catalog;
            _clock = clock;
        }

        public RequestKind Kind => RequestKind.Software;

        public ValueTask<HandlerResult> HandleAsync(ProductDocument original, JsonObject payload, CancellationToken ct)
        {
            var p = original.Copy();
            var issues = new List<ValidationIssue>();
            var simulationKit = payload.S("simulationKitName");
            if (!string.IsNullOrWhiteSpace(simulationKit))
            {
                var kit = _catalog.Data.A("kits").Objects().FirstOrDefault(k => k.S("partNumber") == simulationKit || k.S("name").Equals(simulationKit, StringComparison.OrdinalIgnoreCase));
                if (kit is null)
                {
                    issues.Add(new("simulation_kit_missing", "Simulation kit was not found.", 1));
                }
                else if (!kit.A("productClasses").Any(x => x?.ToString() == p.Info.S("productClassId")))
                {
                    issues.Add(new("simulation_kit_context", "Simulation kit is incompatible with this product."));
                }
                else
                {
                    ProductDelta.ApplySeedKit(p, (JsonObject)kit["delta"]!);
                }
            }
            var operation = (SoftwareOperation)payload.I("softwareRequestOperation", 3);
            if (!Enum.IsDefined(operation))
            {
                throw new RequestFault(400, "invalid_operation", "Unknown software operation.");
            }

            var scenario = payload.I("scenario", 1);
            if (scenario is < 1 or > 5)
            {
                throw new RequestFault(400, "invalid_scenario", "Scenario must be between 1 and 5.");
            }

            var requested = payload.A("requestedNodes").Objects().Where(r => string.IsNullOrWhiteSpace(r.S("chassisSeries")) || VehicleIdentity.Key(r.S("chassisSeries"), r.S("chassisNumber")) == p.Id).ToArray();
            foreach (var r in requested)
            {
                if (!p.Nodes.Objects().Any(n => JsonAccess.NodeKeyOf(n) == JsonAccess.NodeKey(r["nodeIdentifier"])))
                {
                    issues.Add(new("requested_node_missing", "A requested node does not exist in the proposal."));
                }
            }

            var limit = payload.S("limitTo").Split([',', ' ', ';'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            var scope = p.Nodes.Objects().Where(n => requested.Length == 0 || requested.Any(r => JsonAccess.NodeKey(r["nodeIdentifier"]) == JsonAccess.NodeKeyOf(n)))
                .Where(n => limit.Length == 0 || limit.Any(t => Matches(n, t))).Select(JsonAccess.NodeKeyOf).ToList();
            if (limit.Length > 0 && scope.Count == 0)
            {
                issues.Add(new("empty_scope", "Limit to does not match a requested node."));
            }

            var pack = operation == SoftwareOperation.UpdateToServicePack ? _catalog.Data.A("servicePacks").Objects().Where(x => x.I("contextId") == p.ContextId).OrderByDescending(x => x.I("sortOrder")).FirstOrDefault() : null;
            if (operation == SoftwareOperation.UpdateToServicePack && pack is null)
            {
                issues.Add(new("service_pack_missing", "No service pack exists for this context."));
            }

            var visited = new HashSet<string>(StringComparer.Ordinal);
            for (var i = 0; i < scope.Count; i++)
            {
                ct.ThrowIfCancellationRequested();
                var key = scope[i];
                if (!visited.Add(key))
                {
                    continue;
                }

                var node = p.Nodes.Objects().First(x => JsonAccess.NodeKeyOf(x) == key);
                var template = _catalog.FindTemplate(node);
                if (template is null)
                {
                    issues.Add(new("unknown_node", "Node is not documented in the catalog.", 0, node.S("name")));
                    continue;
                }
                var versions = template.A("versions").Objects().ToArray();
                var cur = Array.FindIndex(versions, v => v.I("doc") == node["nodeTemplateDocument"].I("number"));
                var selected = -1;
                if (operation == SoftwareOperation.Resolve)
                {
                    selected = cur >= 0 ? cur : Array.FindIndex(versions, v => v.I("msw") == node["mainSoftware"].I("number", -1) || v.I("msw") == node.A("softwareProducts").FirstOrDefault().I("number", -1));
                }
                else if (operation is SoftwareOperation.Refresh or SoftwareOperation.Repair)
                {
                    selected = cur;
                }
                else if (cur < 0)
                {
                    issues.Add(new("unresolved_template", "Resolve the node template before requesting an update.", 0, node.S("name")));
                    continue;
                }
                else if (pack is not null)
                {
                    selected = Math.Max(cur, pack["ntps"].I(template.S("key"), cur));
                }
                else
                {
                    selected = Enumerable.Range(0, versions.Length).Where(j => Allowed(versions[j], scenario) && DateAllowed(versions[j], scenario) && Compatible(versions[j], node, payload)).DefaultIfEmpty(-1).Max();
                }

                if (selected < 0 || selected >= versions.Length)
                {
                    issues.Add(new("no_compatible_version", "No compatible template could be selected.", 0, node.S("name")));
                    continue;
                }
                if (operation == SoftwareOperation.Update && selected < cur)
                {
                    selected = cur; // Updates never downgrade.
                }

                var version = versions[selected];
                if (!Compatible(version, node, payload))
                {
                    issues.Add(new("incompatible_hardware_or_pbl", "The selected template is incompatible with hardware, bootloader or remote settings.", 0, node.S("name")));
                    continue;
                }
                var replacement = (JsonObject)version["node"]!.DeepClone();
                replacement["ecuHardware"] = node["ecuHardware"]?.DeepClone();
                if (node["subHardwares"] is not null && replacement["subHardwares"] is not null)
                {
                    replacement["subHardwares"] = node["subHardwares"]!.DeepClone();
                }

                p.Nodes[p.Nodes.IndexOf(node)] = replacement;
                if (operation != SoftwareOperation.Refresh)
                {
                    ApplyParameters(p, cur >= 0 ? versions[cur].A("parameters") : [], version.A("parameters"), operation == SoftwareOperation.Repair, payload.B("groupAdministrativeParameters", true));
                }

                if (payload.B("enableMultiNodeBehavior", true))
                {
                    foreach (var dep in version.A("requires").Objects())
                    {
                        var dt = _catalog.Data.A("templates").Objects().FirstOrDefault(t => t.S("key") == dep.S("key"));
                        var dn = p.Nodes.Objects().FirstOrDefault(n => JsonAccess.NodeKeyOf(n) == JsonAccess.NodeKey(dt?["identifier"]));
                        if (dn is not null && !scope.Contains(JsonAccess.NodeKeyOf(dn)))
                        {
                            scope.Add(JsonAccess.NodeKeyOf(dn));
                        }
                    }
                }
                if (operation == SoftwareOperation.Update && versions.Any(v => v.I("idx") > selected && Allowed(v, scenario)))
                {
                    issues.Add(new("newer_version_unavailable", "A newer version requires different hardware, bootloader or remote capability.", 1, node.S("name")));
                }
            }
            if (pack is not null)
            {
                p.Info["servicePackName"] = pack.S("name");
                p.Info["servicePackGuid"] = pack.S("guid");
            }
            return ValueTask.FromResult(new HandlerResult(p, issues));
        }

        private bool DateAllowed(JsonObject v, int scenario)
        {
            if (scenario != 2)
            {
                return true;
            }

            var d = (_clock ?? TimeProvider.System).GetUtcNow().UtcDateTime;
            var week = System.Globalization.ISOWeek.GetYear(d) * 100 + System.Globalization.ISOWeek.GetWeekOfYear(d);
            return v.I("introductionWeek") <= week;
        }

        public static bool Allowed(JsonObject version, int scenario) => version.S("status") switch
        {
            "released" => true,
            "introduced" => scenario != 3,
            "prereleaseverification" => scenario >= 4,
            "inprogress" => scenario == 5,
            _ => false
        };

        public static bool Compatible(JsonObject version, JsonObject node, JsonObject payload)
        {
            var hw = node["ecuHardware"].I("number");
            if (!version.A("hardware").Any(x => int.TryParse(x?.ToString(), out var h) && h == hw))
            {
                return false;
            }

            if (payload.I("remoteRequest") > 0 && !version.B("remoteCapable"))
            {
                return false;
            }

            return payload.B("pblUpdateCapable", true) || node["primaryBootloader"] is null || node["primaryBootloader"].I("number") == version.I("pbl");
        }

        private static bool Matches(JsonObject n, string token) => n.S("name").Contains(token, StringComparison.OrdinalIgnoreCase) || n["nodeIdentifier"].S("name").Equals(token, StringComparison.OrdinalIgnoreCase) || n["nodeIdentifier"].S("mid") == token || string.Join('.', new[] { "family", "type", "position" }.Select(k => n["nodeIdentifier"].S(k))) == token;
        private static string ParamKey(JsonObject p) => p.S("electricalArchitecture") + ":" + p.S("code");

        internal static void ApplyParameters(ProductDocument p, JsonArray before, JsonArray after, bool reset, bool groupAdmin)
        {
            foreach (var value in after.Objects())
            {
                if (value.B("isGroupAdministrative") && !groupAdmin)
                {
                    continue;
                }

                var old = p.Parameters.Objects().FirstOrDefault(x => ParamKey(x) == ParamKey(value));
                var previous = before.Objects().FirstOrDefault(x => ParamKey(x) == ParamKey(value));
                if (old is null)
                {
                    p.Parameters.Add(value.DeepClone());
                }
                else if (reset || (previous is not null && JsonNode.DeepEquals(old["references"], previous["references"])))
                {
                    p.Parameters[p.Parameters.IndexOf(old)] = value.DeepClone();
                }
            }
            foreach (var oldDefault in before.Objects().Where(x => !after.Objects().Any(y => ParamKey(y) == ParamKey(x))))
            {
                if (oldDefault.B("isGroupAdministrative") && !groupAdmin)
                {
                    continue;
                }

                var current = p.Parameters.Objects().FirstOrDefault(x => ParamKey(x) == ParamKey(oldDefault));
                if (current is not null && (reset || JsonNode.DeepEquals(current["references"], oldDefault["references"])))
                {
                    p.Parameters.Remove(current);
                }
            }
        }
    }
}
