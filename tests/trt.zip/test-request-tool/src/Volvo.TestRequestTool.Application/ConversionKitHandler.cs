using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    public sealed class ConversionKitHandler : IRequestHandler
    {
        private readonly ICatalog _catalog;

        public ConversionKitHandler(ICatalog catalog)
        {
            _catalog = catalog;
        }

        public RequestKind Kind => RequestKind.ConversionKit;

        public ValueTask<HandlerResult> HandleAsync(ProductDocument original, JsonObject payload, CancellationToken ct)
        {
            var p = original.Copy();
            var issues = new List<ValidationIssue>();
            var entries = payload.A("conversionKitNumbers").Objects().Where(x => string.IsNullOrWhiteSpace(x.S("chassisSeries")) || VehicleIdentity.Key(x.S("chassisSeries"), x.S("chassisNumber")) == p.Id).ToArray();
            if (entries.Length == 0)
            {
                issues.Add(new("kit_required", "Select at least one conversion kit."));
            }

            foreach (var entry in entries)
            {
                ct.ThrowIfCancellationRequested();
                var kit = _catalog.Data.A("kits").Objects().FirstOrDefault(k => k.S("partNumber") == entry.S("conversionKitNumber"));
                if (kit is null)
                {
                    issues.Add(new("kit_missing", "The requested kit is not in the catalog."));
                    continue;
                }
                if (!kit.A("productClasses").Any(x => x?.ToString() == p.Info.S("productClassId")))
                {
                    issues.Add(new("kit_product_class", "Kit does not support this product class."));
                    continue;
                }
                var states = payload.I("scenario", 1) switch { 1 => new[] { "Released", "Introduced" }, 2 => new[] { "Released", "Introduced", "Pre Release Verification", "In Progress" }, 3 => new[] { "Released" }, 4 => new[] { "Released", "Introduced", "Pre Release Verification" }, _ => [] };
                if (!states.Contains(kit.S("state")) || (payload.B("onlyServiceKitAllowed") && !kit.B("isServiceKit")))
                {
                    issues.Add(new("kit_not_available", "Kit state or service-kit requirement does not match the request."));
                    continue;
                }
                ProductDelta.ApplySeedKit(p, (JsonObject)kit["delta"]!);
            }
            return ValueTask.FromResult(new HandlerResult(p, issues));
        }
    }
}
