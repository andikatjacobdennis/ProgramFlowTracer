using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    public sealed record ValidationContext(ProductDocument Original, ProductDocument Proposal, JsonObject Payload, ICatalog Catalog);
}
