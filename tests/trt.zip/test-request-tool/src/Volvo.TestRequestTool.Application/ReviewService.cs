using System.Globalization;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// Review, approval and submission of a validation result (FR-06, FR-57).
    /// <list type="bullet">
    /// <item><b>Request review</b>: the author of a validation asks for it. The evidence is captured then: each vehicle's revision and
    /// proposal fingerprint, the exact changes and the checks, so reviewers see what was validated even without access to the
    /// author's private records.</item>
    /// <item><b>Decide</b>: someone else with the Writer role (separation of duties: never the author) approves after confirming the
    /// checklist, or requests changes with a note. Approval is refused while there are blockers or once any vehicle has moved
    /// on from the validated revision.</item>
    /// <item><b>Submit</b>: the final checks run again on the server (validation and approval match, target is current, the account
    /// may submit), then the approved proposal is committed to the VDA repository with each vehicle's expected revision.
    /// Submitting twice returns the first receipt, so a retry after a dropped connection is safe.</item>
    /// </list>
    /// Who may see a review: its author, or anyone who may read every vehicle in it.
    /// </summary>
    public sealed class ReviewService
    {
        private readonly IWorkspaceStore _store;
        private readonly TimeProvider _clock;
        public static readonly string[] Checklist = ["changes", "evidence", "vehicle"];
        public const int MaxText = 500;
        public const string Target = "VDA repository";

        public ReviewService(IWorkspaceStore store, TimeProvider clock)
        {
            _store = store;
            _clock = clock;
        }

        public static string Label(Guid requestId) => "REQ-" + requestId.ToString("N")[..6].ToUpperInvariant();
        public static string SubmissionLabel(Guid reviewId) => "SUB-" + reviewId.ToString("N")[..6].ToUpperInvariant();

        // ------------------------------------------------------------------ requesting
        public async Task<ReviewRecord> RequestAsync(Actor actor, Guid requestId, int? proposalRevision, string? note, CancellationToken ct)
        {
            var record = await _store.ExecutionAsync(requestId, actor.Id, ct) ?? throw new RequestFault(404, "request_missing", "Request was not found.");
            var existing = await _store.ReviewForRequestAsync(requestId, ct);
            if (existing is { Status: "open" or "approved" or "submitted" })
            {
                return existing;
            }

            var now = _clock.GetUtcNow();
            var comments = new List<ReviewComment> { new(Guid.NewGuid(), actor.Id, actor.DisplayName, now, "requested", Bound(note) is { Length: > 0 } n ? n : "Review requested.") };
            return await _store.SaveReviewAsync(new ReviewRecord(Guid.NewGuid(), requestId, actor.Id, actor.DisplayName, now, proposalRevision, "open", Evidence(record, proposalRevision), comments), null, ct);
        }

        /// <summary>What was validated, captured when the review is requested.</summary>
        public static JsonObject Evidence(ExecutionRecord record, int? proposalRevision)
        {
            var vehicles = new JsonArray();
            int checks = 0, passed = 0, blockers = 0, changes = 0;
            foreach (var o in record.Outcomes)
            {
                var rows = ProposalDiff.Rows(o.Original, o.Proposal);
                changes += rows.Count;
                var groups = new[] { ("compatibility", "Compatibility checks", new[] { "hardware", "dependencies" }), ("parameters", "Parameter checks", new[] { "parameters" }), ("integrity", "Configuration integrity", new[] { "software" }) };
                var list = new JsonArray();
                foreach (var (id, name, cats) in groups)
                {
                    var found = o.Issues.Where(i => cats.Contains(ProposalDiff.Category(i.Code))).ToArray();
                    var state = found.Any(i => i.Severity == 0) ? "blocked" : found.Length > 0 ? "notes" : o.LimitedValidation && id == "integrity" ? "limited" : "passed";
                    list.Add(new JsonObject { ["id"] = id, ["name"] = name, ["state"] = state, ["findings"] = new JsonArray(found.Select(i => (JsonNode)new JsonObject { ["code"] = i.Code, ["text"] = i.Text, ["node"] = i.Node, ["blocking"] = i.Severity == 0 }).ToArray()) });
                }
                // Checks passed counts the timed stages of this vehicle that found nothing (or the three groups for older records).
                var stages = record.Trace?.Stages.Where(s => s.VehicleId == o.VehicleId && (s.Id == "proposal" || s.Id.StartsWith("rule:", StringComparison.Ordinal))).ToArray();
                if (stages is { Length: > 0 })
                {
                    checks += stages.Length;
                    passed += stages.Count(s => s.Outcome == "completed");
                }
                else
                {
                    checks += list.Count;
                    passed += list.Count(c => c!["state"]!.GetValue<string>() == "passed");
                }
                var blocking = o.Issues.Count(i => i.Severity == 0);
                blockers += blocking;
                vehicles.Add(new JsonObject
                {
                    ["id"] = o.VehicleId,
                    ["title"] = ProposalDiff.Title(o.Original),
                    ["architecture"] = ProposalDiff.Architecture(o.Original),
                    ["contextId"] = new ProductDocument(o.Original).ContextId,
                    ["baseRevision"] = o.BaseRevision,
                    ["proposalHash"] = o.ProposalHash,
                    ["changes"] = ProposalDiff.ToJson(rows),
                    ["checks"] = list,
                    ["blocking"] = blocking,
                    ["notes"] = o.Issues.Count(i => i.Severity > 0),
                    ["limited"] = o.LimitedValidation,
                });
            }
            return new JsonObject
            {
                ["requestId"] = record.Id,
                ["label"] = Label(record.Id),
                ["requestKind"] = record.Kind.ToString(),
                ["validatedAt"] = record.CreatedAt.ToString("O", CultureInfo.InvariantCulture),
                ["proposalRevision"] = proposalRevision,
                ["vehicles"] = vehicles,
                ["totals"] = new JsonObject { ["changes"] = changes, ["checks"] = checks, ["checksPassed"] = passed, ["blockers"] = blockers },
            };
        }

        // ------------------------------------------------------------------ reading
        public static bool CanSee(Actor actor, ReviewRecord r) => r.AuthorId == actor.Id || ContextIds(r).All(actor.Contexts.Contains);
        private static IEnumerable<int> ContextIds(ReviewRecord r) => r.Evidence.A("vehicles").Objects().Select(v => v.I("contextId"));

        public async Task<ReviewRecord> GetAsync(Actor actor, Guid id, CancellationToken ct)
        {
            var r = await _store.ReviewAsync(id, ct);
            return r is not null && CanSee(actor, r) ? r : throw new RequestFault(404, "review_missing", "Review was not found.");
        }

        public async Task<ReviewRecord?> ForRequestAsync(Actor actor, Guid requestId, CancellationToken ct)
        {
            var r = await _store.ReviewForRequestAsync(requestId, ct);
            return r is not null && CanSee(actor, r) ? r : null;
        }

        /// <summary>scope: "to-review" (open reviews by others you may read), "mine" (yours) or "all" (every review you may see).</summary>
        public async Task<IReadOnlyList<ReviewRecord>> ListAsync(Actor actor, string scope, CancellationToken ct) =>
            (await _store.ReviewsAsync(500, ct)).Where(r => CanSee(actor, r) && scope switch
            {
                "to-review" => r.Status == "open" && r.AuthorId != actor.Id,
                "mine" => r.AuthorId == actor.Id,
                _ => true,
            }).ToArray();

        // ------------------------------------------------------------------ discussion and decisions
        public async Task<ReviewRecord> CommentAsync(Actor actor, Guid id, string? text, CancellationToken ct)
        {
            var r = await GetAsync(actor, id, ct);
            var t = Bound(text);
            if (t.Length == 0)
            {
                throw new RequestFault(400, "comment_required", "Write a comment.");
            }

            return await _store.SaveReviewAsync(r with { Comments = [.. r.Comments, new(Guid.NewGuid(), actor.Id, actor.DisplayName, _clock.GetUtcNow(), "comment", t)] }, r.Version, ct);
        }

        public async Task<ReviewRecord> DecideAsync(Actor actor, bool canApprove, Guid id, string? decision, IReadOnlyList<string>? checklist, string? note, long version, CancellationToken ct)
        {
            var r = await GetAsync(actor, id, ct);
            if (r.Version != version)
            {
                throw new RequestFault(409, "review_conflict", "The review changed since you opened it. Reload it and try again.");
            }

            if (!canApprove)
            {
                throw new RequestFault(403, "approve_denied", "Deciding on a review needs the Reviewer or Admin role.");
            }

            if (r.AuthorId == actor.Id)
            {
                throw new RequestFault(403, "separation_of_duties", "You cannot decide on your own request; another reviewer must.");
            }

            if (r.Status != "open")
            {
                throw new RequestFault(409, "review_closed", "This review is " + r.Status.Replace('_', ' ') + ".");
            }

            var text = Bound(note);
            if (decision == "approve")
            {
                var ticked = (checklist ?? []).ToHashSet(StringComparer.Ordinal);
                if (!Checklist.All(ticked.Contains))
                {
                    throw new RequestFault(400, "checklist_incomplete", "Confirm every item of the review checklist first.");
                }

                if (r.Evidence["totals"].I("blockers") > 0)
                {
                    throw new RequestFault(409, "blockers_present", "The validation has blocking findings; request changes instead.");
                }

                if (await StaleAsync(r, ct) is { } stale)
                {
                    throw new RequestFault(409, "evidence_stale", stale);
                }
            }
            else if (decision == "request_changes")
            {
                if (text.Length == 0)
                {
                    throw new RequestFault(400, "note_required", "Say what needs to change.");
                }
            }
            else
            {
                throw new RequestFault(400, "decision", "Decision is approve or request_changes.");
            }

            var now = _clock.GetUtcNow();
            var approved = decision == "approve";
            var comment = new ReviewComment(Guid.NewGuid(), actor.Id, actor.DisplayName, now, approved ? "approved" : "changes_requested",
                text.Length > 0 ? text : approved ? "Approved." : "Changes requested.");
            return await _store.SaveReviewAsync(r with
            {
                Status = approved ? "approved" : "changes_requested",
                Decision = new ReviewDecision(actor.Id, actor.DisplayName, now, decision, text, approved ? Checklist : []),
                Comments = [.. r.Comments, comment],
            }, r.Version, ct);
        }

        /// <summary>
        /// Routes an open review to one reviewer, or back to every reviewer with no assignee: the author picks someone who may decide,
        /// or a reviewer takes it. Who may be assigned is checked by the caller (the user directory is not known here). Any reviewer
        /// may still decide; this only says who is expected to look.
        /// </summary>
        public async Task<ReviewRecord> AssignAsync(Actor actor, bool canApprove, Guid id, string? assigneeId, string? assigneeName, long version, CancellationToken ct)
        {
            var r = await GetAsync(actor, id, ct);
            if (r.Version != version)
            {
                throw new RequestFault(409, "review_conflict", "The review changed since you opened it. Reload it and try again.");
            }

            if (r.Status != "open")
            {
                throw new RequestFault(409, "review_closed", "This review is " + r.Status.Replace('_', ' ') + ".");
            }

            if (r.AuthorId != actor.Id && !canApprove)
            {
                throw new RequestFault(403, "assign_denied", "Only the author or a reviewer can assign this review.");
            }

            if (assigneeId == r.AuthorId)
            {
                throw new RequestFault(400, "assign_author", "The author cannot review their own change. Choose someone else.");
            }

            if (assigneeId == actor.Id && !canApprove)
            {
                throw new RequestFault(403, "assign_denied", "Taking a review needs the Reviewer or Admin role.");
            }

            var now = _clock.GetUtcNow();
            ReviewAssignee? who = string.IsNullOrEmpty(assigneeId) ? null : new(assigneeId, string.IsNullOrWhiteSpace(assigneeName) ? assigneeId : assigneeName, actor.Id, actor.DisplayName, now);
            var text = who is null ? "Open to every reviewer again." : who.Id == actor.Id ? who.Name + " took this review." : "Assigned to " + who.Name + ".";
            return await _store.SaveReviewAsync(r with { Assignee = who, Comments = [.. r.Comments, new(Guid.NewGuid(), actor.Id, actor.DisplayName, now, "assigned", text)] }, r.Version, ct);
        }

        public async Task<ReviewRecord> WithdrawAsync(Actor actor, Guid id, long version, CancellationToken ct)
        {
            var r = await GetAsync(actor, id, ct);
            if (r.AuthorId != actor.Id)
            {
                throw new RequestFault(403, "withdraw_denied", "Only the author can withdraw a review request.");
            }

            if (r.Status is not ("open" or "approved"))
            {
                throw new RequestFault(409, "review_closed", "This review is " + r.Status.Replace('_', ' ') + ".");
            }

            if (r.Version != version)
            {
                throw new RequestFault(409, "review_conflict", "The review changed since you opened it. Reload it and try again.");
            }

            return await _store.SaveReviewAsync(r with { Status = "withdrawn", Comments = [.. r.Comments, new(Guid.NewGuid(), actor.Id, actor.DisplayName, _clock.GetUtcNow(), "withdrawn", "Review request withdrawn.")] }, r.Version, ct);
        }

        private async Task<string?> StaleAsync(ReviewRecord r, CancellationToken ct)
        {
            foreach (var v in r.Evidence.A("vehicles").Objects())
            {
                var current = await _store.VehicleAsync(v.S("id"), ct);
                if (current is null || current.Revision != v["baseRevision"]!.GetValue<long>())
                {
                    return $"{v.S("title")} changed since it was validated (revision {v.S("baseRevision")} → {current?.Revision}). Validate again and request a new review.";
                }
            }
            return null;
        }

        // ------------------------------------------------------------------ final checks and submission
        /// <summary>The checks shown before submitting and run again on submission.</summary>
        public async Task<JsonObject> ChecksAsync(Actor actor, bool canSubmit, bool writesPaused, Guid id, CancellationToken ct)
        {
            var r = await GetAsync(actor, id, ct);
            var rev = r.ProposalRevision is int n ? "revision " + n : Label(r.RequestId);
            var record = await _store.ExecutionAsync(r.RequestId, r.AuthorId, ct);
            var validationOk = record is not null && r.Evidence.A("vehicles").Objects().All(v => record.Outcomes.Any(o => o.VehicleId == v.S("id") && o.ProposalHash == v.S("proposalHash")));
            var approvalOk = r.Status is "approved" or "submitted" && r.Decision?.Decision == "approve";
            var stale = r.Status == "submitted" ? null : await StaleAsync(r, ct);
            var accountOk = canSubmit && !writesPaused && ContextIds(r).All(actor.Contexts.Contains);
            var checks = new JsonArray(
                Check("validation", $"Validation matches {rev}", validationOk, validationOk ? "The validation result and fingerprints match the reviewed evidence." : "The validation result is missing or differs from the reviewed evidence."),
                Check("approval", $"Approval matches {rev}", approvalOk, approvalOk ? $"Approved by {r.Decision!.ActorName}." : "This revision is not approved."),
                Check("target", "Target configuration is current", r.Status == "submitted" || stale is null, stale ?? "Every vehicle is still on the validated revision."),
                Check("account", "Your account can submit to this target", accountOk, accountOk ? "Reviewer or Admin role and access to every vehicle." : writesPaused ? "Writes are paused by an operator." : "Submitting needs the Writer role and access to every vehicle."));
            return new JsonObject { ["checks"] = checks, ["ok"] = checks.All(c => c!["ok"]!.GetValue<bool>()), ["checkedAt"] = _clock.GetUtcNow().ToString("O", CultureInfo.InvariantCulture), ["target"] = Target };
        }

        private static JsonObject Check(string id, string label, bool ok, string detail) => new() { ["id"] = id, ["label"] = label, ["ok"] = ok, ["detail"] = detail };

        public async Task<ReviewRecord> SubmitAsync(Actor actor, bool canSubmit, bool writesPaused, Guid id, bool confirmed, CancellationToken ct)
        {
            var r = await GetAsync(actor, id, ct);
            if (r.Status == "submitted")
            {
                return r;   // already done: the same receipt (safe to retry)
            }

            if (!confirmed)
            {
                throw new RequestFault(400, "confirm_required", "Confirm the target and approved revision.");
            }

            if (r.Status != "approved")
            {
                throw new RequestFault(409, "approval_required", "Only an approved review can be submitted.");
            }

            var accepted = _clock.GetUtcNow();
            var checks = await ChecksAsync(actor, canSubmit, writesPaused, id, ct);
            if (!checks["ok"]!.GetValue<bool>())
            {
                var failed = checks["checks"]!.AsArray().First(c => !c!["ok"]!.GetValue<bool>())!;
                throw new RequestFault(failed["id"]!.GetValue<string>() == "account" ? 403 : 409, "final_checks_failed", failed["label"] + ": " + failed["detail"]);
            }
            var record = await _store.ExecutionAsync(r.RequestId, r.AuthorId, ct) ?? throw new RequestFault(409, "final_checks_failed", "The validation result is missing.");
            var label = SubmissionLabel(r.Id);
            var steps = new List<SubmissionStep> { new(r.Decision!.At, "Approval recorded", r.ProposalRevision is int pr ? "revision " + pr : Label(r.RequestId)), new(accepted, "Submission accepted", label) };
            var committed = new List<SubmittedVehicle>();
            foreach (var v in r.Evidence.A("vehicles").Objects())
            {
                var outcome = record.Outcomes.First(o => o.VehicleId == v.S("id"));
                actor.DemandWrite(new ProductDocument(outcome.Original).ContextId);
                var expected = v["baseRevision"]!.GetValue<long>();
                steps.Add(new(_clock.GetUtcNow(), "Target revision checked", v.S("title") + " · " + expected));
                var saved = await _store.UpdateVehicleAsync(outcome.VehicleId, outcome.Proposal, expected, ct,
                    new RevisionNote(actor.Id, actor.DisplayName, $"Submitted {label}: approved by {r.Decision.ActorName}", "request:" + r.RequestId));
                committed.Add(new(outcome.VehicleId, expected, saved.Revision));
                steps.Add(new(_clock.GetUtcNow(), "Snapshot committed", v.S("title") + " · " + saved.Revision));
            }
            var now = _clock.GetUtcNow();
            var latest = await _store.ReviewAsync(id, ct) ?? r;
            return await _store.SaveReviewAsync(latest with
            {
                Status = "submitted",
                Submission = new ReviewSubmission(label, actor.Id, actor.DisplayName, now, Target, committed, steps),
                Comments = [.. latest.Comments, new(Guid.NewGuid(), actor.Id, actor.DisplayName, now, "submitted", $"Submitted as {label}.")],
            }, latest.Version, ct);
        }

        private static string Bound(string? s)
        {
            var t = (s ?? "").Trim();
            return t.Length > MaxText ? t[..MaxText] : t;
        }
    }
}
