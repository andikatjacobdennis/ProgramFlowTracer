using System.Globalization;
using System.Xml.Linq;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// Reading listener requests and writing replies. Requests are read by local element names, so a request is understood
    /// whatever prefixes it uses; replies are written in the contract's namespaces. The Volvo envelope
    /// (VolvoCommon_1_0.xsd, namespace http://www.volvo.com/group/common/1_0) is shared by the newer contracts:
    /// ApplicationArea (Sender, CreationDateTime, BODID) and Show (ResponseCriteria Accepted or Rejected, StatusCode, StatusText).
    /// </summary>
    public static class ListenerXml
    {
        public static readonly XNamespace Volvo = "http://www.volvo.com/group/common/1_0";
        public static readonly XNamespace Products = "http://esw.volvo.com/products/2_1";
        public static readonly XNamespace Node = "http://esw.volvo.com/node/2_1";
        public static readonly XNamespace Variant = "http://esw.volvo.com/variant/1_3";

        /// <summary>The first descendant (or the element itself) with this local name, whatever its namespace.</summary>
        public static XElement? Find(XContainer? scope, string localName) =>
            scope is XElement e && e.Name.LocalName == localName ? e : scope?.Descendants().FirstOrDefault(x => x.Name.LocalName == localName);

        public static IEnumerable<XElement> All(XContainer? scope, string localName) =>
            scope?.Descendants().Where(x => x.Name.LocalName == localName) ?? [];

        /// <summary>The direct children with this local name.</summary>
        public static IEnumerable<XElement> Children(XElement? parent, string localName) =>
            parent?.Elements().Where(x => x.Name.LocalName == localName) ?? [];

        public static XElement? Child(XElement? parent, string localName) => Children(parent, localName).FirstOrDefault();

        /// <summary>The trimmed text of a descendant, or null.</summary>
        public static string? Text(XContainer? scope, string localName)
        {
            var value = Find(scope, localName)?.Value.Trim();
            return string.IsNullOrEmpty(value) ? null : value;
        }

        public static string? Attribute(XElement? element, string name)
        {
            var value = element?.Attributes().FirstOrDefault(a => a.Name.LocalName == name)?.Value.Trim();
            return string.IsNullOrEmpty(value) ? null : value;
        }

        public static int? Number(string? value) => int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out var n) ? n : null;

        public static bool Flag(string? value) => value is not null && (value == "1" || value.Equals("true", StringComparison.OrdinalIgnoreCase));

        /// <summary>The chassis series and number of the first ChassisID in the request (ProductID/ChassisID in Products 2.1).</summary>
        public static (string? Series, string? Number) Chassis(XContainer? scope)
        {
            var chassis = Find(scope, "ChassisID");
            return (Text(chassis, "ChassisSeries"), Text(chassis, "ChassisNumber"));
        }

        /// <summary>The BODID of the request's ApplicationArea: the transaction the reply answers.</summary>
        public static string Transaction(XDocument? request) => Text(Find(request, "ApplicationArea"), "BODID") ?? Guid.NewGuid().ToString();

        /// <summary>
        /// ApplicationArea of a reply (declared in VolvoCommon BODType, so in the Volvo namespace): the listener as
        /// sender (SWBRKDWN), now, and the request's BODID.
        /// </summary>
        public static XElement ApplicationArea(XNamespace ns, string bodId, TimeProvider clock) =>
            new(Volvo + "ApplicationArea",
                new XElement(Volvo + "Sender", new XElement(Volvo + "LogicalID", "SWBRKDWN")),
                new XElement(Volvo + "CreationDateTime", clock.GetUtcNow().UtcDateTime.ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture)),
                new XElement(Volvo + "BODID", bodId));

        /// <summary>
        /// The Show element of a reply, in the message namespace: Accepted with StatusCode 0, Modified (1) when some of what
        /// was asked failed, or Rejected with the listener's error code and text.
        /// </summary>
        public static XElement Show(XNamespace ns, string criteria, string code, string? text) =>
            new(ns + "Show",
                new XElement(Volvo + "ResponseCriteria", criteria),
                new XElement(Volvo + "StatusCode", code),
                text is null ? null : new XElement(Volvo + "StatusText", text));

        public static XElement Accepted(XNamespace ns, string? text = null) => Show(ns, "Accepted", "0", text);

        public static XElement Rejected(XNamespace ns, ListenerNotice error) => Show(ns, "Rejected", error.Code.ToString(CultureInfo.InvariantCulture), error.Text);

        /// <summary>A BOD reply root: the element with the listener's service id and version, ApplicationArea and DataArea.</summary>
        public static XElement Bod(XNamespace ns, string root, string serviceId, string serviceVersion, string bodId, TimeProvider clock, params object?[] dataArea) =>
            new(ns + root,
                new XAttribute("serviceID", serviceId),
                new XAttribute("serviceVersion", serviceVersion),
                ApplicationArea(ns, bodId, clock),
                new XElement(ns + "DataArea", dataArea));

        /// <summary>Volvo part numbers are written with eight digits, as the listener does (09872567).</summary>
        public static string PartNumber(long number) => number.ToString("00000000", CultureInfo.InvariantCulture);

        /// <summary>ApplicationArea of a request the tool writes: the tool as sender, now, and a new BODID.</summary>
        public static XElement RequestArea(TimeProvider clock) =>
            new(Volvo + "ApplicationArea",
                new XElement(Volvo + "Sender", new XElement(Volvo + "LogicalID", "TestRequestTool")),
                new XElement(Volvo + "CreationDateTime", clock.GetUtcNow().UtcDateTime.ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture)),
                new XElement(Volvo + "BODID", Guid.NewGuid().ToString()));

        /// <summary>A reply document as text, with the XML declaration.</summary>
        public static string Write(XElement root) => new XDocument(new XDeclaration("1.0", "utf-8", null), root).Declaration + Environment.NewLine + root;
    }
}
