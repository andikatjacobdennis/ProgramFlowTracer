using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// GetReleaseNotes 1.0 (Request.Listener/Aftermarket/GetShowReleaseNotes_1_0): the text of release notes by id, in the
    /// asked language with the listener's fallback (the same main language, then English). The ids are those the tool's
    /// replies give (one per node template version of the catalog); an unknown id is left out. Any failure is Rejected with
    /// StatusCode 1, as in the listener.
    /// </summary>
    public sealed class ReleaseNotesHandler : ListenerXmlHandler
    {
        public static readonly XNamespace Rn = "http://www.volvo.com/ReleaseNotes/1_0";
        private static readonly XNamespace Ns = "http://esw.volvo.com/GetShowReleaseNotes/1_0";
        private readonly ListenerCatalog _catalog;

        public ReleaseNotesHandler(ListenerCatalog catalog, TimeProvider clock) : base(clock)
        {
            _catalog = catalog;
        }

        public override IReadOnlyCollection<string> Keys { get; } = ["GetReleaseNotes_1.0"];

        protected override Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct)
        {
            var data = ListenerXml.Find(message.Xml, "DataArea");
            var language = ListenerXml.Attribute(ListenerXml.Child(data, "Criteria"), "languageCode") ?? "en-US";
            var asked = ListenerXml.Children(ListenerXml.Child(data, "ReleaseNotes"), "ReleaseNote").Select(r => ListenerXml.Attribute(r, "id") ?? "").ToList();
            var known = _catalog.ReleaseNotes().ToDictionary(n => n.Id, StringComparer.OrdinalIgnoreCase);
            var found = asked.Distinct(StringComparer.OrdinalIgnoreCase).Where(known.ContainsKey).Select(id => known[id]).ToList();
            var notes = found.Select(n => new XElement(Rn + "ReleaseNote", new XAttribute("id", n.Id), new XAttribute("releaseNote", ListenerCatalog.ReleaseNote(n.Version, language) ?? ""))).ToList();
            var root = ListenerXml.Bod(Ns, "ShowReleaseNotes", "SRV26176", "1.0", ListenerXml.Transaction(message.Xml), Clock,
                ListenerXml.Accepted(Ns, string.Empty),
                notes.Count > 0 ? new XElement(Ns + "ReleaseNotes", notes) : null);
            var summary = new List<ListenerFact> { new("Outcome", $"{found.Count} of {asked.Count} release notes found, in {language} where translated.") };
            summary.AddRange(found.Select(n => new ListenerFact(n.Template.S("key") + " " + n.Version.S("versionName"), ListenerCatalog.ReleaseNote(n.Version, language) ?? "")));
            return Task.FromResult(new ListenerAnswer(root, summary, []));
        }

        protected override XElement Error(ListenerMessage message, ListenerNotice notice, string bodId) =>
            ListenerXml.Bod(Ns, "ShowReleaseNotes", "SRV26176", "1.0", bodId, Clock, ListenerXml.Show(Ns, "Rejected", "1", notice.Text));

        /// <summary>The release notes of the vehicle's nodes: their current version and the newest one.</summary>
        public override XDocument Example(ListenerMessageType type, ProductDocument vehicle)
        {
            var ids = new List<string>();
            foreach (var node in vehicle.Nodes.Objects())
            {
                var template = _catalog.Template(node);
                if (template is null)
                {
                    continue;
                }

                foreach (var version in new[] { ListenerCatalog.Current(template, node), ListenerCatalog.Versions(template).LastOrDefault() })
                {
                    if (version?["releaseNotes"] is System.Text.Json.Nodes.JsonObject { Count: > 0 })
                    {
                        ids.Add(ListenerCatalog.ReleaseNoteId(template, version));
                    }
                }
            }

            return Document(new XElement(Ns + "GetReleaseNotes",
                ListenerXml.RequestArea(Clock),
                new XElement(Ns + "DataArea",
                    new XElement(Ns + "Criteria", new XAttribute("languageCode", "sv-SE")),
                    new XElement(Ns + "ReleaseNotes", ids.Distinct().Select(id => new XElement(Ns + "ReleaseNote", new XAttribute("id", id)))))));
        }
    }
}
