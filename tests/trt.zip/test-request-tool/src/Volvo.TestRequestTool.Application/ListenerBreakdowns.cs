using System.Globalization;
using System.Text.Json.Nodes;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The breakdown behind the Production and Development messages: the product specification (product class, chassis,
    /// VIN, variants, S-notes) or a full product, the requested version (a baseline guid, or an effectivity factory and
    /// date) and the requested nodes, broken down by the tool's BreakdownHandler. A baseline gives each node template the
    /// baseline's version; an effectivity gives the newest released or introduced version by the effectivity week.
    /// Problems of the product are notifications, as in the listener (VARIANT INVALID, BASELINE WRONG CONTEXT, S-NOTE
    /// UNKNOWN and so on), not errors: the reply still has a bill of material, possibly empty.
    /// </summary>
    public sealed class ListenerBreakdowns
    {
        private readonly ICatalog _catalog;
        private readonly ListenerVehicles _vehicles;
        private readonly ListenerProducts _products;

        public ListenerBreakdowns(ICatalog catalog, ListenerVehicles vehicles, ListenerProducts products)
        {
            _catalog = catalog;
            _vehicles = vehicles;
            _products = products;
        }

        public ICatalog Catalog => _catalog;

        /// <summary>Breaks down the product of a request's data element (a 1.x root, or the DataArea of 2.0).</summary>
        public async Task<BreakdownResult> BreakDownAsync(XElement data, Actor actor, bool development, CancellationToken ct)
        {
            var notices = new List<BreakdownNotice>();
            var product = await ProductAsync(data, actor, notices, ct);
            var version = ListenerXml.Child(data, "RequestedVersion");
            var guid = Guid(ListenerXml.Text(version, "Baseline"));
            var effectivity = ListenerXml.Find(version, "Effectivity");
            var requested = ListenerXml.Child(data, "RequestedNodes");
            var all = requested is null || ListenerXml.Child(requested, "AllNodes") is not null;
            if (product is null)
            {
                return new BreakdownResult(null, guid ?? "", notices);
            }

            JsonObject payload;
            RequestKind kind;
            JsonObject? baseline = null;
            if (guid is not null)
            {
                baseline = _catalog.Data.A("baselines").Objects().FirstOrDefault(b => b.S("guid").Equals(guid, StringComparison.OrdinalIgnoreCase));
                if (baseline is null)
                {
                    notices.Add(new("Error", "BASELINE MISSING", $"Baseline {guid} was not found.", "The baseline does not exist.", "Please use another baseline."));
                    return new BreakdownResult(null, guid, notices);
                }

                if (baseline.I("contextId") != product.ContextId)
                {
                    notices.Add(new("Error", "BASELINE WRONG CONTEXT", "The selected baseline is for the wrong context.", $"The baseline {baseline.S("name")} does not belong to the context {product.Info["context"].S("name")} of the product.", "Please use another baseline."));
                    return new BreakdownResult(null, guid, notices);
                }

                kind = RequestKind.DevelopmentBreakdown;
                payload = new JsonObject { ["baselineIdentifier"] = baseline.S("identifier"), ["baselineVersion"] = baseline.S("version") };
            }
            else
            {
                var factory = ListenerXml.Text(effectivity, "EffectivityFactory") ?? ListenerXml.Text(effectivity, "AssemblyFactory") ?? product.Info.S("assemblyFactoryCode");
                var date = DateTime.TryParse(ListenerXml.Text(effectivity, "EffectivityDate") ?? ListenerXml.Text(effectivity, "AssemblyDate"), CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal, out var d) ? d : DateTime.UtcNow;
                if (!_catalog.Data.A("factories").Objects().Any(f => f.S("code") == factory))
                {
                    notices.Add(new("Error", "FACTORY UNKNOWN", $"Factory {factory} is not known.", "The effectivity factory is not a factory of the catalog.", "Please use another factory."));
                    return new BreakdownResult(null, "", notices);
                }

                kind = RequestKind.ProductionBreakdown;
                payload = new JsonObject
                {
                    ["assemblyFactoryCode"] = factory,
                    ["introductionWeek"] = (ISOWeek.GetYear(date) * 100 + ISOWeek.GetWeekOfYear(date)).ToString(CultureInfo.InvariantCulture),
                    ["includePreReleasedSNotes"] = ListenerXml.Flag(ListenerXml.Attribute(data, "includePreReleasedSNotes")),
                };
            }

            var result = await new BreakdownHandler(_catalog, kind).HandleAsync(product, payload, ct);
            var broken = result.Proposal;
            notices.AddRange(result.Issues.Select(i => new BreakdownNotice("Information", "NODE TEMPLATE UNAVAILABLE", i.Text + ".", "No version of the node template is available for the requested version.", "No action.")));
            if (!all)
            {
                var wanted = ListenerXml.Children(requested, "Node").ToList();
                foreach (var node in wanted.Where(w => !broken.Nodes.Objects().Any(n => ListenerCatalog.Matches(w, n))))
                {
                    notices.Add(new("Warning", "NODE NOT IN BREAKDOWN", $"Requested node {Describe(node)} is not in the breakdown.", "The node is not part of the product's configuration.", "Check the requested nodes."));
                }

                foreach (var node in broken.Nodes.Objects().Where(n => !wanted.Any(w => ListenerCatalog.Matches(w, n))).ToList())
                {
                    broken.Nodes.Remove(node);
                }
            }

            if (kind == RequestKind.ProductionBreakdown && baseline is null)
            {
                notices.Add(new("Information", "EFFECTIVITY", $"Node templates as released or introduced by week {payload.S("introductionWeek")}.", "The effectivity gives the newest version per node template by its introduction week.", "No action."));
            }

            return new BreakdownResult(broken, baseline?.S("guid").ToUpperInvariant() ?? "", notices);
        }

        /// <summary>The product of the request: its full Product (with-product requests), or its ProductSpecification.</summary>
        private async Task<ProductDocument?> ProductAsync(XElement data, Actor actor, List<BreakdownNotice> notices, CancellationToken ct)
        {
            if (ListenerXml.Child(data, "Product") is { } full)
            {
                return (await _products.ReadAsync(full, actor, ct)).Product;
            }

            var spec = ListenerXml.Child(data, "ProductSpecification");
            var (series, number) = ListenerXml.Chassis(spec);
            var stored = await _vehicles.FindAsync(series, number, actor, ct);
            var productClass = ListenerXml.Text(ListenerXml.Child(spec, "ProductClass"), "ProductClass") ?? stored?.Info.S("productClassId");
            var data2 = stored is not null ? (JsonObject)stored.Data.DeepClone() : NewProduct(series ?? "", number ?? "", productClass ?? "");
            var info = (JsonObject)data2["productSpecification"]!["productInformation"]!;
            if (stored is null)
            {
                var context = _catalog.Data.A("contexts").Objects().FirstOrDefault(c => c.A("productClassIds").Any(p => p?.ToString() == productClass));
                if (context is null)
                {
                    notices.Add(new("Error", "VARIANT INVALID", $"Product class {productClass} has no vehicle context.", "No context of the catalog has this product class.", "Please check the product class."));
                    return null;
                }

                info["context"] = new JsonObject { ["id"] = context.I("id"), ["name"] = context.S("name"), ["isOnlyTea2"] = context.B("isOnlyTea2") };
            }

            var variants = ListenerXml.Children(ListenerXml.Child(spec, "Variants"), "Variant").ToList();
            if (variants.Count > 0)
            {
                var list = new JsonArray();
                foreach (var v in variants)
                {
                    var family = ListenerXml.Text(v, "FamilyId") ?? "";
                    var variant = ListenerXml.Text(v, "VariantId") ?? "";
                    var known = _catalog.Data.A("variants").Objects().FirstOrDefault(x => x.S("familyId") == family && x.S("variantId") == variant);
                    if (known is null)
                    {
                        notices.Add(new("Warning", "VARIANT UNKNOWN", $"Variant {family}-{variant} is unknown.", "The variant is not in the catalog.", "Check the variants."));
                    }

                    list.Add(known?.DeepClone() ?? new JsonObject { ["familyId"] = family, ["variantId"] = variant, ["symbol"] = family + "-" + variant, ["idVar6"] = family + variant });
                }

                data2["productSpecification"]!["variants"] = list;
            }

            var known_ = await KnownSNotesAsync(ct);
            foreach (var note in ListenerXml.Children(ListenerXml.Child(spec, "SNotes"), "SNote").Select(s => s.Value.Trim()).Where(s => s.Length > 0))
            {
                if (!known_.Contains(note))
                {
                    notices.Add(new("Error", "S-NOTE UNKNOWN", $"S-Note {note} is invalid.", "The S-Note is not known.", "Please remove the S-Note."));
                }
            }

            if (!string.IsNullOrEmpty(productClass))
            {
                info["productClassId"] = productClass;
            }

            return new ProductDocument(data2);
        }

        /// <summary>The S-notes the tool knows: those of the vehicles in the repository and those the kits add.</summary>
        private async Task<HashSet<string>> KnownSNotesAsync(CancellationToken ct)
        {
            var notes = await _vehicles.SNotesAsync(ct);
            notes.UnionWith(_catalog.Data.A("kits").Objects().SelectMany(k => k["delta"]?["productSpecification"].A("sNotes").Objects() ?? []).Select(o => o["value"].S("value")).Where(n => n.Length > 0));
            return notes;
        }

        /// <summary>A requested-version block for a vehicle: its context's newest baseline.</summary>
        public JsonObject? NewestBaseline(ProductDocument vehicle) =>
            _catalog.Data.A("baselines").Objects().Where(b => b.I("contextId") == vehicle.ContextId).OrderByDescending(b => b.S("identifier"), StringComparer.Ordinal).ThenByDescending(b => b.S("version"), StringComparer.Ordinal).FirstOrDefault();

        /// <summary>A bmc ProductSpecification for a vehicle: product class, chassis, VIN, variants and S-notes.</summary>
        public static XElement Specification(XName name, XNamespace bmc, ProductDocument vehicle) =>
            new(name,
                new XElement(bmc + "ProductClass", BreakdownXml.ProductClass(vehicle.Info.S("productClassId"))),
                new XElement(bmc + "ChassisID",
                    new XElement(bmc + "ChassisSeries", ListenerProducts.Series(vehicle.Info.S("chassisSeries"))),
                    new XElement(bmc + "ChassisNumber", ListenerProducts.Number(vehicle.Info.S("chassisNumber")))),
                vehicle.Info.S("vin").Length == 17 ? new XElement(bmc + "VIN", vehicle.Info.S("vin")) : null,
                Variants(bmc, vehicle),
                vehicle.Data["productSpecification"].A("sNotes").Objects().Any() ? new XElement(bmc + "SNotes", vehicle.Data["productSpecification"].A("sNotes").Objects().Select(n => new XElement(bmc + "SNote", n.S("value")))) : null);

        private static XElement? Variants(XNamespace bmc, ProductDocument vehicle)
        {
            var list = vehicle.Data["productSpecification"].A("variants").Objects().Where(v => v.S("familyId").Length == 3 && v.S("variantId").Length == 3).ToList();
            return list.Count == 0 ? null : new XElement(bmc + "Variants", list.Select(v => new XElement(bmc + "Variant", new XElement(bmc + "FamilyId", v.S("familyId")), new XElement(bmc + "VariantId", v.S("variantId")))));
        }

        private static string Describe(XElement node)
        {
            var name = ListenerXml.Find(node, "NodeName");
            return name is null ? "MID " + ListenerXml.Text(node, "MID") : $"{ListenerXml.Text(name, "NodeFamily")}.{ListenerXml.Text(name, "NodeType")}.{ListenerXml.Text(name, "NodePosition") ?? "0"}";
        }

        private static string? Guid(string? text) => string.IsNullOrWhiteSpace(text) ? null : text.Trim().Trim('{', '}');

        private static JsonObject NewProduct(string series, string number, string productClass) => new()
        {
            ["productSpecification"] = new JsonObject
            {
                ["productInformation"] = new JsonObject { ["chassisSeries"] = series.Trim(), ["chassisNumber"] = number.Trim(), ["productClassId"] = productClass, ["notifications"] = new JsonArray() },
                ["variants"] = new JsonArray(),
                ["sNotes"] = new JsonArray(),
            },
            ["nodes"] = new JsonArray(),
            ["parameters"] = new JsonArray(),
        };
    }
}
