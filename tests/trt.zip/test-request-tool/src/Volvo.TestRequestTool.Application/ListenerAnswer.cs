using System.Xml.Linq;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>What an XML handler answers: the reply root, a readable summary and any notifications.</summary>
    public sealed record ListenerAnswer(XElement Root, IReadOnlyList<ListenerFact> Summary, IReadOnlyList<ListenerNotice> Notices);
}
