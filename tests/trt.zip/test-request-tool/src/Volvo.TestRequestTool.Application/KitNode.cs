using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>A node a kit assigns, whether its ECU hardware changes, and whether a serial number must be given for it.</summary>
    public sealed record KitNode(JsonObject Node, bool HardwareChangeNeeded, bool SerialNumberInputNeeded);
}
