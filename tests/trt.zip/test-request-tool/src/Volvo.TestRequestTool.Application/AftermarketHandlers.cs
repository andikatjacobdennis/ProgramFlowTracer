namespace Volvo.TestRequestTool.Application
{
    /// <summary>The simulated message types of the listener (Aftermarket, Production, Development), built over the catalog and the repository.</summary>
    public static class AftermarketHandlers
    {
        public static IReadOnlyList<IListenerHandler> Create(ICatalog catalog, IWorkspaceStore store, TimeProvider clock)
        {
            catalog = catalog as SnapshotCatalog ?? new SnapshotCatalog(catalog);
            var vehicles = new ListenerVehicles(store);
            var products = new ListenerProducts(catalog, vehicles);
            var rules = new ListenerCatalog(catalog);
            var breakdowns = new ListenerBreakdowns(catalog, vehicles, products);
            return
            [
                new NewSoftwareExistsHandler(products, rules, clock),
                new ReleaseNotesHandler(rules, clock),
                new AvailableUpdatesListenerHandler(products, rules, clock),
                new KitEvaluationHandler(products, rules, clock),
                new CampaignEvaluationHandler(products, rules, clock),
                new AssignedNodesInKitHandler(products, rules, clock),
                new ConversionKitListenerHandler(products, rules, clock),
                new SoftwareRequestListenerHandler(products, rules, clock),
                new SpareCabListenerHandler(products, rules, clock),
                new CampaignListenerHandler(products, rules, clock),
                new T3ListenerHandler(catalog, vehicles),
                new ProductionBreakdownHandler(breakdowns, clock),
                new DevelopmentBreakdownHandler(breakdowns, clock),
                new ConsistencyCheckHandler(breakdowns, clock),
                new EvaluateHandler(products, catalog, clock),
                new ParameterRecipeHandler(products, rules, clock),
                new CapabilityResourceHandler(rules, clock),
                new VcadsHandler(vehicles, rules, clock),
            ];
        }
    }
}
