using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    public sealed class CatalogValidator : IProductValidator
    {
        public string Name => "catalog";
        public int Order => 10;

        public ValueTask<IReadOnlyList<ValidationIssue>> ValidateAsync(ValidationContext c, CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested();
            var issues = new List<ValidationIssue>();
            var keys = new HashSet<string>();
            foreach (var n in c.Proposal.Nodes.Objects())
            {
                if (!keys.Add(JsonAccess.NodeKeyOf(n)))
                {
                    issues.Add(new("duplicate_node", "Node identifiers must be unique.", 0, n.S("name")));
                }

                if (c.Catalog.FindTemplate(n) is null)
                {
                    issues.Add(new("unknown_node", "No node template exists in this catalog.", 0, n.S("name")));
                }
                else if (c.Catalog.FindVersion(n) is null)
                {
                    issues.Add(new("invalid_template", "Node template document is unknown.", 0, n.S("name")));
                }
            }
            return ValueTask.FromResult<IReadOnlyList<ValidationIssue>>(issues);
        }
    }
}
