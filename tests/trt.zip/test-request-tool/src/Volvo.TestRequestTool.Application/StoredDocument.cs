using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Application
{
    public sealed record StoredDocument(string Key, JsonObject Document);
}
