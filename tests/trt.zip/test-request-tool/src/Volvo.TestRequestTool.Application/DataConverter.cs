using System.Globalization;
using System.Text;
using System.Text.Json.Nodes;
using System.Xml;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;
namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// General-purpose conversions behind the Convert tool and the /convert API: any XML to JSON, any JSON to XML, and tabular
    /// data (a JSON array of objects) to CSV. The mapping is the common one: attributes become "@name" properties, element text
    /// next to attributes or children becomes "#text", repeated elements become arrays. XML is read with DTDs prohibited and no
    /// external resolution, so entity-expansion and external-entity attacks are refused.
    /// </summary>
    public static class DataConverter
    {
        public const int MaxChars = 4_000_000;

        // ------------------------------------------------------------------ XML → JSON
        public static JsonObject XmlToJson(string xml)
        {
            if (string.IsNullOrWhiteSpace(xml))
            {
                throw new RequestFault(400, "xml_empty", "Paste or upload some XML.");
            }

            if (xml.Length > MaxChars)
            {
                throw new RequestFault(413, "xml_too_large", "The XML is larger than 4 MB.");
            }

            XDocument doc;
            try
            {
                var settings = new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null, MaxCharactersInDocument = MaxChars, IgnoreComments = true, IgnoreProcessingInstructions = true };
                using var reader = XmlReader.Create(new StringReader(xml), settings);
                doc = XDocument.Load(reader);
            }
            catch (XmlException e)
            {
                throw new RequestFault(400, "xml_invalid", $"The XML is not valid: {e.Message}");
            }
            var root = doc.Root ?? throw new RequestFault(400, "xml_invalid", "The XML has no root element.");
            return new JsonObject { [root.Name.LocalName] = Element(root) };
        }

        private static JsonNode? Element(XElement e)
        {
            var obj = new JsonObject();
            foreach (var a in e.Attributes().Where(a => !a.IsNamespaceDeclaration))
            {
                obj["@" + a.Name.LocalName] = Scalar(a.Value);
            }

            foreach (var group in e.Elements().GroupBy(c => c.Name.LocalName))
            {
                var items = group.Select(Element).ToArray();
                obj[group.Key] = items.Length == 1 ? items[0] : new JsonArray(items);
            }
            var text = string.Concat(e.Nodes().OfType<XText>().Select(t => t.Value)).Trim();
            if (obj.Count == 0)
            {
                return text.Length == 0 ? null : Scalar(text);
            }

            if (text.Length > 0)
            {
                obj["#text"] = Scalar(text);
            }

            return obj;
        }

        /// <summary>Numbers and booleans become JSON numbers and booleans; everything else stays a string.</summary>
        private static JsonNode Scalar(string value)
        {
            if (value is "true" or "false")
            {
                return JsonValue.Create(value == "true");
            }

            if (value.Length is > 0 and < 16 && !value.StartsWith('0') && long.TryParse(value, NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture, out var n))
            {
                return JsonValue.Create(n);
            }

            if (value.Length is > 0 and < 24 && value.Contains('.') && !value.StartsWith('.') && double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var d) && !value.EndsWith('.'))
            {
                return JsonValue.Create(d);
            }

            if (value == "0")
            {
                return JsonValue.Create(0);
            }

            return JsonValue.Create(value);
        }

        // ------------------------------------------------------------------ JSON → XML
        public static string JsonToXml(JsonNode? json, string? rootName = null)
        {
            if (json is null)
            {
                throw new RequestFault(400, "json_empty", "Paste or upload some JSON.");
            }

            XElement root;
            if (json is JsonObject o && o.Count == 1 && rootName is null && o.First().Value is JsonObject)
            {
                root = Build(o.First().Key, o.First().Value);
            }
            else
            {
                root = Build(rootName ?? "root", json);
            }

            return new XDocument(new XDeclaration("1.0", "utf-8", null), root).ToString();
        }

        private static XElement Build(string name, JsonNode? node)
        {
            var e = new XElement(XmlName(name));
            switch (node)
            {
                case JsonObject obj:
                    foreach (var (k, v) in obj)
                    {
                        if (k.StartsWith('@') && v is JsonValue)
                        {
                            e.SetAttributeValue(XmlName(k[1..]), Text(v));
                        }
                        else if (k == "#text")
                        {
                            e.Add(new XText(Text(v)));
                        }
                        else if (v is JsonArray list)
                        {
                            foreach (var item in list)
                            {
                                e.Add(Build(k, item));
                            }
                        }
                        else
                        {
                            e.Add(Build(k, v));
                        }
                    }
                    break;
                case JsonArray arr:
                    foreach (var item in arr)
                    {
                        e.Add(Build("item", item));
                    }
                    break;
                case null:
                    break;
                default:
                    e.Value = Text(node);
                    break;
            }
            return e;
        }

        private static string Text(JsonNode? v) => v is JsonValue jv && jv.TryGetValue(out string? s) ? s : v?.ToJsonString() ?? "";

        /// <summary>A valid XML element or attribute name: invalid characters become '_', and a name cannot start with a digit.</summary>
        public static string XmlName(string name)
        {
            var sb = new StringBuilder();
            foreach (var c in string.IsNullOrEmpty(name) ? "item" : name)
            {
                sb.Append(char.IsLetterOrDigit(c) || c is '_' or '-' or '.' ? c : '_');
            }

            var s = sb.ToString();
            return char.IsLetter(s[0]) || s[0] == '_' ? s : "_" + s;
        }

        // ------------------------------------------------------------------ tables → CSV
        /// <summary>A JSON array of objects as CSV (RFC 4180). Nested values are written as JSON.</summary>
        public static string ToCsv(JsonArray rows, char separator = ',')
        {
            var columns = rows.OfType<JsonObject>().SelectMany(r => r.Select(kv => kv.Key)).Distinct().ToArray();
            var sb = new StringBuilder();
            sb.AppendJoin(separator, columns.Select(c => Cell(c, separator))).Append("\r\n");
            foreach (var row in rows.OfType<JsonObject>())
            {
                sb.AppendJoin(separator, columns.Select(c => Cell(row[c] is JsonValue v ? Text(v) : row[c]?.ToJsonString() ?? "", separator))).Append("\r\n");
            }

            return sb.ToString();
        }

        private static string Cell(string value, char separator)
        {
            // A leading =, +, - or @ would run as a formula in spreadsheets; prefix it so it stays text.
            if (value.Length > 0 && "=+-@".Contains(value[0]))
            {
                value = "'" + value;
            }

            return value.IndexOfAny([separator, '"', '\r', '\n']) >= 0 ? "\"" + value.Replace("\"", "\"\"") + "\"" : value;
        }
    }
}
