using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The shape every XML handler of the listener shares: answer the request, and when the request cannot be answered (a
    /// <see cref="ListenerFault"/>, or a request that failed the dispatcher's checks) answer with the contract's error reply,
    /// as the listener's CreateError does. A request that failed its checks has no transaction, so its BODID is empty.
    /// </summary>
    public abstract class ListenerXmlHandler : IListenerHandler, IListenerExample
    {
        protected ListenerXmlHandler(TimeProvider clock)
        {
            Clock = clock;
        }

        protected TimeProvider Clock { get; }

        public abstract IReadOnlyCollection<string> Keys { get; }

        public async ValueTask<ListenerReply> HandleAsync(ListenerMessage message, CancellationToken ct)
        {
            try
            {
                var answer = await AnswerAsync(message, ct);
                return new ListenerReply(ListenerXml.Write(answer.Root), ListenerReply.Xml, answer.Notices, answer.Summary);
            }
            catch (ListenerFault fault)
            {
                return Refused(message, fault.Notice, ListenerXml.Transaction(message.Xml));
            }
        }

        public ListenerReply Reject(ListenerMessage message, ListenerNotice notice) => Refused(message, notice, string.Empty);

        public abstract XDocument Example(ListenerMessageType type, ProductDocument vehicle);

        protected abstract Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct);

        /// <summary>The contract's error reply for a request that cannot be answered.</summary>
        protected abstract XElement Error(ListenerMessage message, ListenerNotice notice, string bodId);

        private ListenerReply Refused(ListenerMessage message, ListenerNotice notice, string bodId) =>
            new(ListenerXml.Write(Error(message, notice, bodId)), ListenerReply.Xml, [notice], [new ListenerFact("Outcome", $"Rejected with {notice.Code} {notice.Name}.")]);

        /// <summary>A request document for an example, with the XML declaration.</summary>
        protected static XDocument Document(XElement root) => new(new XDeclaration("1.0", "utf-8", null), root);
    }
}
