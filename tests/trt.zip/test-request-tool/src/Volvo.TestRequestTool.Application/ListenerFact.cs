namespace Volvo.TestRequestTool.Application
{
    /// <summary>One line of the readable summary of a listener reply.</summary>
    public sealed record ListenerFact(string Label, string Value);
}
