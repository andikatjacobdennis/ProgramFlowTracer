namespace Volvo.TestRequestTool.Application
{
    /// <summary>What an action would do and what to expect. Executes = false: a future executor would run it through the normal workflows.</summary>
    public sealed record AgentProposedAction(string Kind, string Label, string ExpectedOutcome, string RequiresWorkflow, bool Executes = false);
}
