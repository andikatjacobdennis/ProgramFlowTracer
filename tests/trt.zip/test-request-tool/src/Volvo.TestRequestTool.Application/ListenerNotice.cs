namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// A notification about a listener message. <see cref="Code"/> is the listener's error code (ErrorCode.cs in
    /// swb-stable1, for example 101 InvalidXml or 107 InvalidMessage), 0 when there is no error.
    /// <see cref="Severity"/> is Error, Warning or Information.
    /// </summary>
    public sealed record ListenerNotice(int Code, string Name, string Severity, string Text)
    {
        public const int NoError = 0;
        public const int Undefined = 100;
        public const int InvalidXml = 101;
        public const int InvalidMessage = 107;

        public static ListenerNotice Error(int code, string name, string text) => new(code, name, "Error", text);

        public static ListenerNotice Warning(string text) => new(NoError, "Warning", "Warning", text);

        public static ListenerNotice Information(string text) => new(NoError, "Information", "Information", text);
    }
}
