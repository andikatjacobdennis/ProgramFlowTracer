using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    public sealed class SpareCabHandler : IRequestHandler
    {
        private readonly ICatalog _catalog;

        public SpareCabHandler(ICatalog catalog)
        {
            _catalog = catalog;
        }

        public RequestKind Kind => RequestKind.SpareCab;

        public ValueTask<HandlerResult> HandleAsync(ProductDocument original, JsonObject payload, CancellationToken ct)
        {
            ct.ThrowIfCancellationRequested();
            var p = original.Copy();
            var baseline = _catalog.Data.A("baselines").Objects().FirstOrDefault(x => x.S("guid") == payload.S("baselineGuid") && x.I("contextId") == p.ContextId);
            if (baseline is null)
            {
                return ValueTask.FromResult(new HandlerResult(p, [new("baseline_required", "Select a baseline for the spare cab in the vehicle context.")]));
            }

            var removed = payload.A("removedNodes").Select(x => x is JsonObject ? JsonAccess.NodeKey(x["nodeIdentifier"] ?? x) : x?.ToString()).ToHashSet();
            foreach (var n in p.Nodes.Objects().ToArray())
            {
                if (removed.Contains(JsonAccess.NodeKeyOf(n)) || removed.Contains(Position(n["nodeIdentifier"])))
                {
                    p.Nodes.Remove(n);
                }
            }

            foreach (var requested in payload.A("spareCabNodes").Objects())
            {
                var n = p.Nodes.Objects().FirstOrDefault(x => JsonAccess.NodeKeyOf(x) == JsonAccess.NodeKey(requested["nodeIdentifier"]));
                if (n is null)
                {
                    continue;
                }

                var t = _catalog.FindTemplate(n);
                if (t is null)
                {
                    continue;
                }

                var v = t.A("versions").Objects().FirstOrDefault(v => v.I("idx") == baseline["ntps"].I(t.S("key"), -1));
                if (v is null)
                {
                    continue;
                }

                var replacement = (JsonObject)v["node"]!.DeepClone();
                replacement["ecuHardware"] = n["ecuHardware"]?.DeepClone();
                p.Nodes[p.Nodes.IndexOf(n)] = replacement;
            }
            p.Info["baselineName"] = baseline.S("name");
            p.Info["baselineGuid"] = baseline.S("guid");
            return ValueTask.FromResult(new HandlerResult(p, []));
        }

        private static string Position(JsonNode? n) => n.I("electricalArchitecture") == 1 ? string.Join('.', new[] { "family", "type", "position" }.Select(k => n.S(k))) : n.S("mid");
    }
}
