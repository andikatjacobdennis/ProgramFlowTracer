using System.Globalization;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// ESW_ASSIGNED_NODENAMES_IN_KIT_REQUEST 1.0 and 2.0 (Request.Listener/Aftermarket/AssignedNodeNamesInKitRequest_1_0 and _2_0):
    /// the nodes a kit assigns to the product (whether the ECU hardware changes, whether a serial number must be given) and
    /// the nodes it removes. 1.0 takes a KitRequest 1.1 and answers AssignedNodesInKitResponse 1.1; 2.0 takes
    /// GetAssignedNodesInKit and answers ShowAssignedNodesInKit. Both answer an error with an ErrorReport 1.1, as the
    /// listener's ErrorResponseBuilder does.
    /// </summary>
    public sealed class AssignedNodesInKitHandler : ListenerXmlHandler
    {
        public static readonly XNamespace KitRequest11 = "http://esw.volvo.com/kitrequest/1_1";
        private static readonly XNamespace Reply11 = "http://esw.volvo.com/assignednodesinkit/1_1";
        private static readonly XNamespace V20 = "http://www.volvo.com/AssignedNodesInKit/2_0";
        private static readonly XNamespace Er = "http://esw.volvo.com/errorreport/1_1";
        private readonly ListenerProducts _products;
        private readonly ListenerCatalog _catalog;

        public AssignedNodesInKitHandler(ListenerProducts products, ListenerCatalog catalog, TimeProvider clock) : base(clock)
        {
            _products = products;
            _catalog = catalog;
        }

        public override IReadOnlyCollection<string> Keys { get; } = ["ESW_ASSIGNED_NODENAMES_IN_KIT_REQUEST_1.0", "ESW_ASSIGNED_NODENAMES_IN_KIT_REQUEST_2.0"];

        protected override async Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct)
        {
            var v20 = message.Type.Version == "2.0";
            var root = message.Xml!.Root!;
            var data = v20 ? ListenerXml.Child(root, "DataArea") : root;
            var kit = v20 ? ListenerXml.Number(ListenerXml.Attribute(ListenerXml.Child(data, "RequestedKit"), "partNumber")) : ListenerXml.Number(ListenerXml.Attribute(root, "kitPartNumber"));
            var scenario = ListenerCatalog.Scenario(ListenerXml.Attribute(v20 ? ListenerXml.Child(data, "Criteria") : root, "scenario"));
            var serviceOnly = !v20 && ListenerXml.Flag(ListenerXml.Attribute(root, "allowServiceKitsOnly"));
            var product = await _products.ReadAsync(ListenerXml.Child(data, "Product")!, message.Actor, ct);
            var result = _catalog.ApplyKit(product.Product, kit ?? 0, scenario, serviceOnly);
            var summary = new List<ListenerFact>
            {
                new("Outcome", $"Kit {ListenerXml.PartNumber(kit ?? 0)} {result.Kit.S("name")}: assigns {result.Assigned.Count} node(s), removes {result.Removed.Count}."),
                product.Source,
            };
            summary.AddRange(result.Assigned.Select(a => new ListenerFact(ListenerCatalog.Name(a.Node), a.HardwareChangeNeeded ? "Assigned; the ECU hardware changes and a serial number is needed." : "Assigned; same ECU hardware.")));
            summary.AddRange(result.Removed.Select(r => new ListenerFact(ListenerCatalog.Name(r), "Removed.")));
            XElement reply;
            if (v20)
            {
                reply = ListenerXml.Bod(V20, "ShowAssignedNodesInKit", "SRV?????", "2.0", ListenerXml.Transaction(message.Xml), Clock,
                    ListenerXml.Accepted(V20),
                    new XElement(V20 + "Kit",
                        result.Assigned.Count == 0 ? null : new XElement(V20 + "AssignedNodes", result.Assigned.Select(a => new XElement(V20 + "Node",
                            new XAttribute("HardwareChangeNeeded", a.HardwareChangeNeeded ? "true" : "false"),
                            new XAttribute("SerialNumberInputNeeded", a.SerialNumberInputNeeded ? "true" : "false"),
                            ListenerCatalog.NodeId(V20, a.Node)))),
                        result.Removed.Count == 0 ? null : new XElement(V20 + "RemovedNodes", result.Removed.Select(r => new XElement(V20 + "Node", ListenerCatalog.NodeId(V20, r))))));
            }
            else
            {
                reply = new XElement(Reply11 + "AssignedNodesInKitResponse",
                    new XAttribute("transactionId", ListenerXml.Attribute(root, "transactionId") ?? ""),
                    new XAttribute("schemaVersion", "1.1"),
                    result.Assigned.Count == 0 ? null : new XElement(Reply11 + "AssignedNodes", result.Assigned.Select(a => new XElement(Reply11 + "Node", Assigned11(a)))),
                    result.Removed.Count == 0 ? null : new XElement(Reply11 + "RemovedNodes", result.Removed.Select(r => new XElement(Reply11 + "Node", ListenerCatalog.NodeId(Reply11, r)))));
            }

            return new ListenerAnswer(reply, summary, []);
        }

        protected override XElement Error(ListenerMessage message, ListenerNotice notice, string bodId) =>
            new(Er + "ErrorReport", new XAttribute("schemaVersion", "1.1"),
                new XElement(Er + "Errors", new XElement(Er + "Error",
                    new XAttribute("code", notice.Code.ToString(CultureInfo.InvariantCulture)),
                    new XElement(Er + "System", "Software Breakdown"),
                    new XElement(Er + "DateTime", Clock.GetUtcNow().UtcDateTime.ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture)),
                    new XElement(Er + "Service", "Software Breakdown Service"),
                    new XElement(Er + "Message", notice.Text),
                    new XElement(Er + "Details", string.Empty))));

        public override XDocument Example(ListenerMessageType type, ProductDocument vehicle)
        {
            var kit = KitEvaluationHandler.ExampleKit(_catalog, vehicle).First();
            if (type.Version == "2.0")
            {
                return Document(new XElement(V20 + "GetAssignedNodesInKit",
                    ListenerXml.RequestArea(Clock),
                    new XElement(V20 + "DataArea",
                        new XElement(V20 + "Criteria", new XAttribute("scenario", "Introduced")),
                        new XElement(V20 + "RequestedKit", new XAttribute("partNumber", kit)),
                        ListenerProducts.ProductElement(V20, "Product", vehicle))));
            }

            return Document(KitRequest(kit, vehicle));
        }

        /// <summary>A KitRequest 1.1 for a kit and a vehicle (also the request of ESW_CAMPAIGN_REQUEST 1.0).</summary>
        public static XElement KitRequest(long kit, ProductDocument vehicle) =>
            new(KitRequest11 + "KitRequest",
                new XAttribute("kitPartNumber", kit),
                new XAttribute("scenario", "Introduced"),
                new XAttribute("transactionId", Guid.NewGuid().ToString()),
                new XAttribute("schemaVersion", "1.1"),
                new XAttribute("pblUpdateCapable", "true"),
                ListenerProducts.ProductElement(KitRequest11, "Product", vehicle));

        private static XElement Assigned11(KitNode a)
        {
            var flags = new object?[]
            {
                new XElement(Reply11 + "HardwareChangeNeeded", a.HardwareChangeNeeded ? "true" : "false"),
                a.SerialNumberInputNeeded ? new XElement(Reply11 + "SerialNumberInputNeeded", "true") : null,
            };
            var id = ListenerCatalog.NodeId(Reply11, a.Node, "AssignedNodeName", "MID");
            return id.Name.LocalName == "MID" ? new XElement(Reply11 + "AssignedMID", id, flags) : new XElement(id.Name, id.Attributes(), flags);
        }
    }
}
