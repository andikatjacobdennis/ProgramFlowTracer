using System.Globalization;
using System.Text.Json.Nodes;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The parameter recipes of the Service Configurator (Request.Listener/ServiceConfigurator/ParameterReceipe_1_0, _1_1,
    /// NewSalesParameterReceipe_1_0, AftermarketParameterReceipe_1_0): what to change on a product so that the wanted
    /// parameters get the wanted values.
    /// <list type="bullet">
    /// <item><b>GetParameterRecipe 1.0 and 1.1, GetNewSalesParameterRecipe 1.0</b> answer in variant changes. A parameter value
    /// comes from a node template version of the product class's contexts; a node template with a variant condition is used
    /// only with one of its variants, so that variant is what to add (and another variant of the same family is what to
    /// delete). Each combination of variants that does not conflict is one alternative recipe group. A wanted value that no
    /// node template gives is NO RECIPE, as in the listener. useUnreleasedData also counts versions in progress.</item>
    /// <item><b>GetAftermarketParameterRecipe 1.0</b> answers for the vehicle as it is: a software refresh when its current node
    /// template already gives the value, else a software update to the newest version that gives it, else a conversion kit
    /// that sets it. A parameter the vehicle already has is left out; one nothing gives is NO RECIPE.</item>
    /// </list>
    /// </summary>
    public sealed class ParameterRecipeHandler : ServiceConfiguratorHandler
    {
        private const int MaxGroups = 20;
        private readonly ListenerProducts _products;
        private readonly ListenerCatalog _catalog;

        public ParameterRecipeHandler(ListenerProducts products, ListenerCatalog catalog, TimeProvider clock) : base(clock)
        {
            _products = products;
            _catalog = catalog;
        }

        public override IReadOnlyCollection<string> Keys { get; } = ["GetParameterRecipe_1.0", "GetParameterRecipe_1.1", "GetNewSalesParameterRecipe_1.0", "GetAftermarketParameterRecipe_1.0"];

        protected override string ReplyRoot => "ParameterRecipeResponse";

        protected override XNamespace ReplyNs(ListenerMessageType type) => "http://esw.volvo.com/parameterreciperesponse/" + (type.Key == "GetParameterRecipe_1.1" ? "1_1" : "1_0");

        protected override string Kind(ListenerMessageType type) => type.MessageType switch
        {
            "GetNewSalesParameterRecipe" => "New Sales Parameter Recipe",
            "GetAftermarketParameterRecipe" => "Aftermarket Parameter Recipe",
            _ => "Parameter Recipe",
        };

        protected override (string Schema, string Id, string Version) Service(ListenerMessageType type) => type.Key switch
        {
            "GetParameterRecipe_1.1" => ("1.1", "SRV13088", "1.1"),
            "GetNewSalesParameterRecipe_1.0" => ("1.0", "SRV13677", "1.0"),
            "GetAftermarketParameterRecipe_1.0" => ("1.0", "SRV13678", "1.0"),
            _ => ("1.0", "SRV06404", "1.0"),
        };

        private static bool Aftermarket(ListenerMessageType type) => type.MessageType == "GetAftermarketParameterRecipe";

        protected override async Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct) =>
            Aftermarket(message.Type) ? await AftermarketAsync(message, ct) : Variants(message);

        // ------------------------------------------------------------------ variant recipes
        private ListenerAnswer Variants(ListenerMessage message)
        {
            var ns = ReplyNs(message.Type);
            var data = message.Type.MessageType == "GetNewSalesParameterRecipe" ? ListenerXml.Child(message.Xml!.Root, "DataArea")! : message.Xml!.Root!;
            var unreleased = ListenerXml.Flag(ListenerXml.Attribute(data, "useUnreleasedData"));
            var spec = ListenerXml.Child(data, "ProductSpecification");
            var productClass = ListenerXml.Text(ListenerXml.Child(spec, "ProductClass"), "ProductClass") ?? "";
            var have = ListenerXml.Children(ListenerXml.Child(spec, "Variants"), "Variant").Select(v => (Family: ListenerXml.Text(v, "FamilyId") ?? "", Variant: ListenerXml.Text(v, "VariantId") ?? "")).ToList();
            var week = Week(ListenerXml.Text(ListenerXml.Child(data, "Effectivity"), "Date"));
            var wanted = ListenerXml.Children(ListenerXml.Child(data, "WantedParameterValues"), "ParameterValues")
                .Select(p => (Code: ListenerXml.Text(ListenerXml.Child(p, "ParameterCode"), "ParameterCode") ?? "", Value: ListenerXml.Child(p, "ParameterValue"))).ToList();
            var summary = new List<ListenerFact>();
            var notices = new List<BreakdownNotice>();
            var contexts = _catalog.Catalog.Data.A("contexts").Objects().Where(c => c.A("productClassIds").Any(p => p?.ToString() == productClass)).Select(c => c.I("id")).ToHashSet();
            if (contexts.Count == 0)
            {
                notices.Add(new("Error", "PRODUCT CLASS UNKNOWN", $"Product class {productClass} is unknown.", "No context of the catalog has this product class.", "Use another product class."));
                summary.Add(new ListenerFact("Outcome", "No recipe: the product class is unknown."));
                return new ListenerAnswer(Reply(message, Transaction(message), Notifications(message.Type, notices)), summary, []);
            }

            var symbols = have.Select(h => _catalog.Catalog.Data.A("variants").Objects().FirstOrDefault(v => v.S("familyId") == h.Family && v.S("variantId") == h.Variant)?.S("symbol")).Where(s => s is not null).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var templates = _catalog.Catalog.Data.A("templates").Objects().Where(t => t.A("contexts").Any(c => int.TryParse(c?.ToString(), out var n) && contexts.Contains(n))).ToList();
            var ingredients = new List<(string Code, XElement? Value, List<JsonObject> Adds)>();
            var noRecipe = false;
            foreach (var (code, value) in wanted)
            {
                var text = ProductsUpdateWriter.Text(value);
                var giving = templates.Where(t => ListenerCatalog.Versions(t).Any(v => Allowed(v, unreleased, week) && v.A("parameters").Objects().Any(p => p.S("code") == code && p.A("references").Objects().FirstOrDefault().S("value") == text))).ToList();
                if (giving.Count == 0)
                {
                    noRecipe = true;
                    summary.Add(new ListenerFact($"{code} = {text}", "No node template gives this value."));
                    continue;
                }

                var conditions = giving.Select(t => t.A("condition").Select(c => c?.ToString() ?? "").Where(c => c.Length > 0).ToList()).ToList();
                if (conditions.Any(c => c.Count == 0) || conditions.Any(c => c.Any(symbols.Contains)))
                {
                    summary.Add(new ListenerFact($"{code} = {text}", "The product already gets this value: no change needed."));
                    continue;
                }

                var adds = conditions.SelectMany(c => c).Distinct(StringComparer.OrdinalIgnoreCase)
                    .Select(s => _catalog.Catalog.Data.A("variants").Objects().FirstOrDefault(v => v.S("symbol").Equals(s, StringComparison.OrdinalIgnoreCase))).OfType<JsonObject>().ToList();
                ingredients.Add((code, value, adds));
            }

            var groups = new List<XElement>();
            if (!noRecipe && ingredients.Count > 0)
            {
                foreach (var combination in Combinations(ingredients.Select(i => i.Adds).ToList()).Take(MaxGroups * 5))
                {
                    if (combination.GroupBy(v => v.S("familyId")).Any(g => g.Select(v => v.S("variantId")).Distinct().Count() > 1))
                    {
                        continue;
                    }

                    groups.Add(new XElement(ns + "RecipeGroup", ingredients.Select((ingredient, i) =>
                    {
                        var add = combination[i];
                        var deletes = have.Where(h => h.Family == add.S("familyId") && h.Variant != add.S("variantId")).ToList();
                        return new XElement(ns + "ParameterRecipe",
                            ParameterValue(ns, ingredient.Code, ingredient.Value),
                            new XElement(ns + "Recipe", new XElement(Scc + "VariantChanges",
                                Variant("Add", add.S("familyId"), add.S("variantId")),
                                deletes.Select(d => Variant("Delete", d.Family, d.Variant)))));
                    })));
                    if (groups.Count == MaxGroups)
                    {
                        break;
                    }
                }
            }

            if (noRecipe || (ingredients.Count > 0 && groups.Count == 0))
            {
                groups.Clear();
                notices.Add(new("Warning", "NO RECIPE", "No recipes found for the requested service.", "No combinations of the wanted parameters was valid.", "Modify the wanted parameters."));
            }

            var root = Reply(message, Transaction(message), groups.Count == 0 ? null : new XElement(ns + "AlternativeRecipeGroups", groups), Notifications(message.Type, notices));
            summary.Insert(0, new ListenerFact("Outcome", groups.Count > 0 ? $"{groups.Count} alternative recipe group(s): " + string.Join("; ", groups.Select(Describe)) + "." : notices.Count > 0 ? "No recipe." : "No change needed."));
            return new ListenerAnswer(root, summary, []);
        }

        // ------------------------------------------------------------------ aftermarket recipes
        private async Task<ListenerAnswer> AftermarketAsync(ListenerMessage message, CancellationToken ct)
        {
            var ns = ReplyNs(message.Type);
            var data = ListenerXml.Child(message.Xml!.Root, "DataArea");
            var unreleased = ListenerXml.Flag(ListenerXml.Attribute(ListenerXml.Child(data, "Criteria"), "useUnreleasedData"));
            var scenario = unreleased ? 5 : 1;
            var product = await _products.ReadAsync(ListenerXml.Child(data, "Product")!, message.Actor, ct);
            var summary = new List<ListenerFact> { product.Source };
            var flagged = Flagged();
            var options = new List<(string Code, XElement? Value, List<XElement> Recipes)>();
            var refused = new List<XElement>();
            foreach (var p in ListenerXml.Children(ListenerXml.Child(data, "WantedParameters"), "Parameter"))
            {
                var code = ListenerXml.Attribute(p, "parameterCode") ?? "";
                var value = ListenerXml.Child(p, "Value");
                var text = ProductsUpdateWriter.Text(value);
                if (flagged.Count > 0 && !flagged.Contains(code))
                {
                    refused.Add(new XElement(ns + "ParameterRecipe", ParameterValue(ns, code, value), new XElement(ns + "Notifications", BreakdownXml.Notification(Scc,
                        new BreakdownNotice("Error", "NOT RESOURCE OR CAPABILITY", $"Parameter {code} is not a capability or resource.", $"The parameter definition for {code} might have been changed.", "Revise parameters used in services.")))));
                    continue;
                }

                if (product.Product.Parameters.Objects().Any(x => x.S("code") == code && x.A("references").Objects().FirstOrDefault().S("value") == text))
                {
                    summary.Add(new ListenerFact($"{code} = {text}", "The vehicle already has this value."));
                    continue;
                }

                var recipes = Recipes(ns, product.Product, code, text, scenario, out var how);
                summary.Add(new ListenerFact($"{code} = {text}", how));
                options.Add((code, value, recipes.Count > 0 ? recipes : [new XElement(ns + "Notifications", BreakdownXml.Notification(Scc,
                    new BreakdownNotice("Information", "NO RECIPE", $"There is no way {code}=\"{text}\".", $"There is no part giving  {code}=\"{text}\" and the parameter value is not set by any kit or transition.", "Ask technical support if there is a way to get this capability on the product.")))]));
            }

            var groups = Combinations(options.Select(o => o.Recipes).ToList()).Take(MaxGroups)
                .Select(combination => new XElement(ns + "RecipeGroup", options.Select((o, i) => new XElement(ns + "ParameterRecipe", ParameterValue(ns, o.Code, o.Value), new XElement(combination[i])))))
                .Where(g => g.HasElements).ToList();
            if (refused.Count > 0)
            {
                groups.Add(new XElement(ns + "RecipeGroup", refused));
            }

            if (flagged.Count == 0)
            {
                summary.Add(new ListenerFact("Capabilities", "The catalog marks no parameter as a capability or a resource, so every parameter is taken."));
            }

            var root = Reply(message, Transaction(message), groups.Count == 0 ? null : new XElement(ns + "AlternativeRecipeGroups", groups));
            summary.Insert(0, new ListenerFact("Outcome", groups.Count == 0 ? "The vehicle already has every wanted value." : $"{groups.Count} alternative recipe group(s)."));
            return new ListenerAnswer(root, summary, []);
        }

        /// <summary>The recipes that give a parameter value on the vehicle, in the listener's priority: refresh, update, kit.</summary>
        private List<XElement> Recipes(XNamespace ns, ProductDocument product, string code, string text, int scenario, out string how)
        {
            var recipes = new List<XElement>();
            bool Gives(JsonObject? version) => version.A("parameters").Objects().Any(p => p.S("code") == code && p.A("references").Objects().FirstOrDefault().S("value") == text);
            foreach (var node in product.Nodes.Objects())
            {
                var template = _catalog.Template(node);
                if (template is not null && Gives(ListenerCatalog.Current(template, node)))
                {
                    how = $"A software refresh of {ListenerCatalog.Name(node)} gives it.";
                    return [new XElement(ns + "Recipe", new XElement(Scc + "SoftwareRefresh"))];
                }
            }

            var payload = new JsonObject { ["pblUpdateCapable"] = true };
            foreach (var node in product.Nodes.Objects())
            {
                var template = _catalog.Template(node);
                var current = template is null ? null : ListenerCatalog.Current(template, node);
                var version = template is null ? null : ListenerCatalog.Versions(template)
                    .Where(v => v.I("idx") > (current?.I("idx") ?? -1) && SoftwareHandler.Allowed(v, scenario) && SoftwareHandler.Compatible(v, node, payload) && Gives(v)).OrderByDescending(v => v.I("idx")).FirstOrDefault();
                if (version is not null)
                {
                    recipes.Add(new XElement(ns + "Recipe", new XElement(Scc + "SoftwareUpdates",
                        new XElement(Scc + "Operation", "Update"),
                        new XElement(Scc + "Node", NodeName(node)),
                        new XElement(Scc + "NodeTemplate", ListenerXml.PartNumber(version.I("doc"))))));
                }
            }

            if (recipes.Count > 0)
            {
                how = "A software update gives it: " + recipes.Count + " way(s).";
                return recipes;
            }

            foreach (var kit in _catalog.Kits.Where(k => ListenerCatalog.KitAllowed(k, scenario) && k.A("productClasses").Any(c => c?.ToString() == product.Info.S("productClassId"))))
            {
                if (kit["delta"].A("parameters").Objects().Any(o => o["value"].S("code") == code && o["value"]!.A("references").Objects().FirstOrDefault().S("value") == text))
                {
                    recipes.Add(new XElement(ns + "Recipe", new XElement(Scc + "ApplyKit", ListenerXml.PartNumber(kit.I("partNumber")))));
                }
            }

            how = recipes.Count > 0 ? "A conversion kit gives it." : "Nothing in the catalog gives this value.";
            return recipes;
        }

        // ------------------------------------------------------------------ examples
        public override XDocument Example(ListenerMessageType type, ProductDocument vehicle)
        {
            if (Aftermarket(type))
            {
                XNamespace apr = "http://esw.volvo.com/aftermarketparameterreciperequest/1_0";
                XNamespace hipProduct = "http://www.volvo.com/SoftwareBreakdownHardIndividualProduct/1_0";
                XNamespace hip = "http://www.volvo.com/hip/main/1_0";
                var (code, value, kind) = AftermarketExample(vehicle);
                var productClass = vehicle.Info.S("productClassId");
                return Document(new XElement(apr + "GetAftermarketParameterRecipe",
                    ListenerXml.RequestArea(Clock),
                    new XElement(apr + "DataArea",
                        new XElement(apr + "Criteria"),
                        new XElement(apr + "Product",
                            new XElement(hipProduct + "Identification", new XElement(hip + "ChassisID",
                                new XElement(hip + "ChassisSeries", vehicle.Info.S("chassisSeries")),
                                new XElement(hip + "ChassisNumber", ListenerProducts.Number(vehicle.Info.S("chassisNumber"))))),
                            productClass.Length <= 2 ? new XElement(hipProduct + "GeneralDescription", new XElement(hip + "ProductClass", productClass)) : null),
                        new XElement(apr + "WantedParameters", new XElement(apr + "Parameter",
                            new XAttribute("schemaVersion", "2.1"), new XAttribute("parameterCode", code),
                            new XElement(ProductsUpdateWriter.Pv + "Value", ProductsUpdateWriter.Value(kind, value)))))));
            }

            var (wantedCode, wantedValue, definition) = VariantExample(vehicle);
            var wantedElement = new XElement(RequestNs(type) + "ParameterValues",
                new XElement(Scc + "ParameterCode", wantedCode),
                new XElement(Scc + "ParameterValue", ProductsUpdateWriter.Value(definition, wantedValue)));
            var ns = RequestNs(type);
            var content = new object[]
            {
                new XElement(ns + "WantedParameterValues", wantedElement),
                Specification(ns + "ProductSpecification", vehicle),
                Effectivity(ns + "Effectivity", vehicle),
            };
            if (type.MessageType == "GetNewSalesParameterRecipe")
            {
                return Document(new XElement(ns + "GetNewSalesParameterRecipeRequest", ListenerXml.RequestArea(Clock), new XElement(ns + "DataArea", content)));
            }

            var (schema, id, version) = Service(type);
            return Document(new XElement(ns + "ParameterRecipeRequest", Header(schema, id, version), content));
        }

        private static XNamespace RequestNs(ListenerMessageType type) => type.MessageType == "GetNewSalesParameterRecipe"
            ? "http://esw.volvo.com/newsalesparameterreciperequest/1_0"
            : "http://esw.volvo.com/parameterreciperequest/" + type.Version.Replace('.', '_');

        /// <summary>A value a variant would give the vehicle: a parameter of a node template whose variant it does not have.</summary>
        private (string Code, string Value, JsonNode? Definition) VariantExample(ProductDocument vehicle)
        {
            var symbols = vehicle.Data["productSpecification"].A("variants").Objects().Select(v => v.S("symbol")).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var templates = _catalog.Catalog.Templates(vehicle.ContextId);
            var pick = templates.Where(t => t.A("condition").Any() && !t.A("condition").Any(c => symbols.Contains(c?.ToString() ?? "")))
                .Concat(templates).SelectMany(t => ListenerCatalog.Versions(t).Where(v => SoftwareHandler.Allowed(v, 1)).Reverse()).SelectMany(v => v.A("parameters").Objects()).FirstOrDefault()
                ?? _catalog.Catalog.Data.A("templates").Objects().SelectMany(t => ListenerCatalog.Versions(t)).SelectMany(v => v.A("parameters").Objects()).First();
            return (pick.S("code"), pick.A("references").Objects().FirstOrDefault().S("value"), Definition(pick));
        }

        /// <summary>A value a newer node template or a kit would give the vehicle, for the aftermarket recipe.</summary>
        private (string Code, string Value, JsonNode? Definition) AftermarketExample(ProductDocument vehicle)
        {
            foreach (var node in vehicle.Nodes.Objects())
            {
                var template = _catalog.Template(node);
                var current = template is null ? null : ListenerCatalog.Current(template, node);
                foreach (var version in template is null ? [] : ListenerCatalog.Versions(template).Where(v => v.I("idx") > (current?.I("idx") ?? -1) && SoftwareHandler.Allowed(v, 1)))
                {
                    var changed = version.A("parameters").Objects().FirstOrDefault(p => !vehicle.Parameters.Objects().Any(x => x.S("code") == p.S("code") && JsonNode.DeepEquals(x["references"], p["references"])));
                    if (changed is not null)
                    {
                        return (changed.S("code"), changed.A("references").Objects().FirstOrDefault().S("value"), Definition(changed));
                    }
                }
            }

            var kit = _catalog.Kits.SelectMany(k => k["delta"].A("parameters").Objects()).Select(o => o["value"] as JsonObject).OfType<JsonObject>().FirstOrDefault();
            var any = kit ?? vehicle.Parameters.Objects().FirstOrDefault() ?? new JsonObject { ["code"] = "P1ALG", ["electricalArchitecture"] = 1, ["references"] = new JsonArray(new JsonObject { ["code"] = "VAL", ["value"] = "90" }) };
            return (any.S("code"), any.A("references").Objects().FirstOrDefault().S("value"), Definition(any));
        }

        private JsonNode? Definition(JsonObject parameter) => _catalog.Catalog.Data["paramDefs"]?[parameter.I("electricalArchitecture") + ":" + parameter.S("code")];

        /// <summary>The parameters the catalog marks as a capability or a resource (paramDefs: "capability" or "resource" true).</summary>
        private HashSet<string> Flagged() =>
            (_catalog.Catalog.Data["paramDefs"] as JsonObject ?? []).Select(p => p.Value).OfType<JsonObject>().Where(d => d.B("capability") || d.B("resource")).Select(d => d.S("code")).ToHashSet(StringComparer.Ordinal);

        private static XElement ParameterValue(XNamespace ns, string code, XElement? value) =>
            new(ns + "ParameterValue", new XElement(ns + "ParameterCode", code), new XElement(ns + "ParameterValue", value?.Elements().Where(e => e.Name.LocalName != "Source").Select(e => new XElement(e))));

        private static XElement Variant(string name, string family, string variant) =>
            new(Scc + name, new XElement(Scc + "FamilyId", family), new XElement(Scc + "VariantId", variant));

        private static XElement NodeName(JsonObject node)
        {
            var id = node["nodeIdentifier"];
            return id.I("family") > 0
                ? new XElement(Scc + "NodeName", new XElement(Scc + "NodeFamily", id.I("family")), new XElement(Scc + "NodeType", id.I("type")), id.I("position") > 0 ? new XElement(Scc + "NodePosition", id.I("position")) : null)
                : new XElement(Scc + "MID", id.I("mid").ToString("000", CultureInfo.InvariantCulture));
        }

        private static bool Allowed(JsonObject version, bool unreleased, string week) =>
            SoftwareHandler.Allowed(version, unreleased ? 5 : 1) && string.CompareOrdinal(version.S("introductionWeek"), week) <= 0;

        private static string Week(string? date)
        {
            var d = DateTime.TryParse(date, CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal, out var parsed) ? parsed : DateTime.UtcNow;
            return (ISOWeek.GetYear(d) * 100 + ISOWeek.GetWeekOfYear(d)).ToString(CultureInfo.InvariantCulture);
        }

        private static string Describe(XElement group) => string.Join(", ", group.Descendants().Where(e => e.Name.LocalName is "Add" or "Delete")
            .Select(e => (e.Name.LocalName == "Add" ? "add " : "delete ") + ListenerXml.Text(e, "FamilyId") + "-" + ListenerXml.Text(e, "VariantId")));

        /// <summary>Every combination of one option per list (the Cartesian product), lazily.</summary>
        private static IEnumerable<List<T>> Combinations<T>(List<List<T>> lists)
        {
            if (lists.Count == 0)
            {
                yield break;
            }

            var index = new int[lists.Count];
            while (true)
            {
                yield return lists.Select((l, i) => l[index[i]]).ToList();
                var k = lists.Count - 1;
                while (k >= 0 && ++index[k] == lists[k].Count)
                {
                    index[k] = 0;
                    k--;
                }

                if (k < 0)
                {
                    yield break;
                }
            }
        }
    }
}
