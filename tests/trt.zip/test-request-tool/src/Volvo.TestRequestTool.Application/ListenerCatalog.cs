using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The catalog as the listener's Aftermarket messages see it: node templates and their versions (the replacement chain),
    /// which version a scenario allows, node template status and remote download as the contracts name them, release notes,
    /// and conversion kits. The rules are the tool's own (SoftwareHandler.Allowed and Compatible), so a listener message and a
    /// request made on the Requests pages give the same answer for the same vehicle.
    /// </summary>
    public sealed class ListenerCatalog
    {
        private readonly ICatalog _catalog;

        public ListenerCatalog(ICatalog catalog)
        {
            _catalog = catalog;
        }

        public ICatalog Catalog => _catalog;

        /// <summary>The catalog's data (a snapshot when the catalog is a SnapshotCatalog).</summary>
        public JsonObject Data => _catalog.Data;

        /// <summary>Scenario names of the contracts on the tool's scale: 1 Introduced … 5 InProgress (Introduced when absent).</summary>
        public static int Scenario(string? name) => name is null ? 1 : ServiceContract.Scenarios.TryGetValue(name, out var n) ? n : throw ListenerFault.InvalidMessage($"Unknown scenario '{name}'.");

        public JsonObject? Template(JsonObject node) => _catalog.FindTemplate(node);

        public static JsonObject[] Versions(JsonObject template) => template.A("versions").Objects().ToArray();

        /// <summary>The version the node has now: its node template document, or failing that its main software.</summary>
        public static JsonObject? Current(JsonObject template, JsonObject node)
        {
            var versions = Versions(template);
            var doc = node["nodeTemplateDocument"].I("number");
            return versions.FirstOrDefault(v => v.I("doc") == doc)
                ?? versions.FirstOrDefault(v => v.I("msw") > 0 && (v.I("msw") == node["mainSoftware"].I("number", -1) || v.I("msw") == node.A("softwareProducts").FirstOrDefault().I("number", -1)));
        }

        /// <summary>
        /// The newest version the scenario allows that fits the node's hardware (and, for a remote download, can be downloaded
        /// remotely; without pblUpdateCapable, keeps the primary bootloader). Never older than the current version.
        /// </summary>
        public static JsonObject? Latest(JsonObject template, JsonObject node, int scenario, bool remote, bool pblUpdateCapable)
        {
            var payload = new JsonObject { ["remoteRequest"] = remote ? 1 : 0, ["pblUpdateCapable"] = pblUpdateCapable };
            var current = Current(template, node);
            var best = Versions(template).Where(v => SoftwareHandler.Allowed(v, scenario) && SoftwareHandler.Compatible(v, node, payload)).OrderByDescending(v => v.I("idx")).FirstOrDefault();
            return best is not null && current is not null && best.I("idx") < current.I("idx") ? current : best;
        }

        /// <summary>NodeTemplateStatusType: PreReleased, Released, Introduced, Withdrawn, InProgress or Unknown.</summary>
        public static string Status(JsonObject? version) => version.S("status") switch
        {
            "released" => "Released",
            "introduced" => "Introduced",
            "prereleaseverification" => "PreReleased",
            "inprogress" => "InProgress",
            "withdrawn" => "Withdrawn",
            _ => "Unknown",
        };

        /// <summary>
        /// RemoteSWDLAvailabilityType. The catalog says only whether a version can be downloaded remotely, so the answer is
        /// General or NotSupportedByNodeTemplate.
        /// </summary>
        public static string Remote(JsonObject? version) => version.B("remoteCapable") ? "General" : "NotSupportedByNodeTemplate";

        /// <summary>The hardware a version also runs on, as CompatibleHardware pairs with the node's own hardware.</summary>
        public static IEnumerable<(int PartNumber, int Compatible)> CompatibleHardware(JsonObject? version, JsonObject node)
        {
            var own = node["ecuHardware"].I("number");
            return version.A("hardware").Select(h => int.TryParse(h?.ToString(), out var n) ? n : 0).Where(n => n > 0 && n != own).Select(n => (own, n));
        }

        /// <summary>A stable release note id per template version, so GetReleaseNotes can find it again.</summary>
        public static string ReleaseNoteId(JsonObject template, JsonObject version)
        {
            var hash = MD5.HashData(Encoding.UTF8.GetBytes("release-note:" + template.S("key") + ":" + version.I("idx")));
            return new Guid(hash).ToString().ToUpperInvariant();
        }

        /// <summary>
        /// The release note text in a language, as GetReleaseNotes falls back: the exact code, then the same main language,
        /// then the first English one, then any.
        /// </summary>
        public static string? ReleaseNote(JsonObject? version, string? language)
        {
            if (version?["releaseNotes"] is not JsonObject notes || notes.Count == 0)
            {
                return null;
            }

            var texts = notes.Select(p => (Code: p.Key, Text: p.Value?.ToString() ?? string.Empty)).ToList();
            var code = language ?? "en-US";
            var main = code.Split('-')[0];
            return texts.FirstOrDefault(x => x.Code.Equals(code, StringComparison.OrdinalIgnoreCase)).Text
                ?? texts.FirstOrDefault(x => x.Code.Split('-')[0].Equals(main, StringComparison.OrdinalIgnoreCase)).Text
                ?? texts.Where(x => x.Code.StartsWith("en", StringComparison.OrdinalIgnoreCase)).OrderBy(x => x.Code, StringComparer.Ordinal).FirstOrDefault().Text
                ?? texts[0].Text;
        }

        /// <summary>Every template version with a release note, by its id.</summary>
        public IEnumerable<(string Id, JsonObject Template, JsonObject Version)> ReleaseNotes() =>
            _catalog.Data.A("templates").Objects().SelectMany(t => Versions(t).Where(v => v["releaseNotes"] is JsonObject { Count: > 0 }).Select(v => (ReleaseNoteId(t, v), t, v)));

        public JsonObject? Kit(long partNumber) => _catalog.Data.A("kits").Objects().FirstOrDefault(k => k.I("partNumber") == partNumber);

        public IEnumerable<JsonObject> Kits => _catalog.Data.A("kits").Objects();

        /// <summary>KitType of the contracts: Campaign, Service or Accessory (the catalog has no hardware or simulation kits).</summary>
        public static string KitType(JsonObject kit) => kit.B("isCampaignKit") ? "Campaign" : kit.B("isServiceKit") ? "Service" : "Accessory";

        /// <summary>The kit states a scenario allows, as ConversionKitHandler applies them.</summary>
        public static bool KitAllowed(JsonObject kit, int scenario) => (scenario switch
        {
            1 => new[] { "Released", "Introduced" },
            2 => ["Released", "Introduced", "Pre Release Verification", "In Progress"],
            3 => ["Released"],
            4 => ["Released", "Introduced", "Pre Release Verification"],
            _ => ["Released", "Introduced", "Pre Release Verification", "In Progress"],
        }).Contains(kit.S("state"));

        /// <summary>
        /// Applies a kit to the product, with the listener's errors: 113 when the kit is unknown or not for the product class,
        /// 111 when the scenario does not allow its state, 130 when only service kits are allowed, 128 when it changes nothing.
        /// Returns the product after the kit, the nodes it assigns (whether the ECU hardware changes, and whether a serial number
        /// must be given: the node is new or its hardware changes) and the nodes it removes.
        /// </summary>
        public KitResult ApplyKit(ProductDocument product, long partNumber, int scenario, bool serviceKitsOnly)
        {
            var kit = Kit(partNumber);
            var number = ListenerXml.PartNumber(partNumber);
            if (kit is null || !kit.A("productClasses").Any(c => c?.ToString() == product.Info.S("productClassId")))
            {
                throw ListenerFault.KitNotFound($"There was a problem applying the kit/transition. Conversion Kit #{number} does not exist or is not valid for the specified product class.");
            }

            if (!KitAllowed(kit, scenario))
            {
                throw ListenerFault.KitNotIntroduced($"There was a problem applying the kit/transition. Conversion Kit {number} is {kit.S("state")}, which the scenario does not allow.");
            }

            if (serviceKitsOnly && !kit.B("isServiceKit"))
            {
                throw ListenerFault.KitNotServiceKit($"There was a problem applying the kit/transition. Only service kits are allowed. {number} is not a service kit.");
            }

            var after = product.Copy();
            ProductDelta.ApplySeedKit(after, (JsonObject)kit["delta"]!);
            var before = product.Nodes.Objects().ToDictionary(JsonAccess.NodeKeyOf, StringComparer.Ordinal);
            var assigned = new List<KitNode>();
            foreach (var node in after.Nodes.Objects())
            {
                var key = JsonAccess.NodeKeyOf(node);
                var old = before.GetValueOrDefault(key);
                if (old is not null && JsonNode.DeepEquals(old, node))
                {
                    continue;
                }

                var hardwareChange = old is null || old["ecuHardware"].I("number") != node["ecuHardware"].I("number");
                assigned.Add(new KitNode(node, hardwareChange, hardwareChange));
            }

            var afterKeys = after.Nodes.Objects().Select(JsonAccess.NodeKeyOf).ToHashSet(StringComparer.Ordinal);
            var removed = product.Nodes.Objects().Where(n => !afterKeys.Contains(JsonAccess.NodeKeyOf(n))).ToList();
            if (assigned.Count == 0 && removed.Count == 0 && JsonNode.DeepEquals(product.Data, after.Data))
            {
                throw ListenerFault.KitAlreadyApplied($"There was a problem applying the kit/transition. The Conversion Kit {number} has already been applied.");
            }

            return new KitResult(kit, after, assigned, removed);
        }

        /// <summary>A node as the contracts identify it: NodeName (family, type, position) for TEA2+ and T3, MID for TEA2 and BEA2 body.</summary>
        public static XElement NodeId(XNamespace ns, JsonObject node, string nodeNameElement = "NodeName", string midElement = "MID")
        {
            var id = node["nodeIdentifier"];
            if (id.I("family") > 0)
            {
                var name = new XElement(ns + nodeNameElement, new XAttribute("nodeFamily", id.I("family")), new XAttribute("nodeType", id.I("type")));
                if (id.I("position") > 0)
                {
                    name.Add(new XAttribute("nodePosition", id.I("position")));
                }

                return name;
            }

            return new XElement(ns + midElement, id.I("mid").ToString("000", System.Globalization.CultureInfo.InvariantCulture));
        }

        /// <summary>
        /// Whether a requested node (an element holding NodeName or MID) is this node. A NodeName without a position (0) matches
        /// any position, as nodes are often named by family and type only.
        /// </summary>
        public static bool Matches(XElement requested, JsonObject node)
        {
            var id = node["nodeIdentifier"];
            var name = ListenerXml.Find(requested, "NodeName");
            if (name is not null)
            {
                var position = ListenerXml.Number(ListenerXml.Attribute(name, "nodePosition")) ?? 0;
                return ListenerXml.Number(ListenerXml.Attribute(name, "nodeFamily")) == id.I("family") && ListenerXml.Number(ListenerXml.Attribute(name, "nodeType")) == id.I("type")
                    && (position == 0 || position == id.I("position"));
            }

            var mid = ListenerXml.Number(ListenerXml.Text(requested, "MID"));
            return mid is not null && mid == id.I("mid") && id.I("family") == 0;
        }

        /// <summary>The node in the words of a summary: "16.1.1 EMS".</summary>
        public static string Name(JsonObject node) => node.S("name");
    }
}
