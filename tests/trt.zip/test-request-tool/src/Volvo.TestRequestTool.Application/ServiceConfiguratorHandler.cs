using System.Globalization;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The shape the Service Configurator replies share: a root with the message header attributes (MessageHeaderCommon:
    /// schemaVersion, BODId, CreatedDateTime, serviceId, serviceVersion) and notifications in ServiceConfiguratorCommon. As in
    /// the listener, an error is a reply with one notification, TECHNICAL ERROR (or BAD REQUEST for a schemaVersion that does
    /// not match the message type), and no error code. Unlike the listener's CapabilityResourceBreakdown error reply, the
    /// service attributes are always written, so the error reply follows its contract too.
    /// </summary>
    public abstract class ServiceConfiguratorHandler : ListenerXmlHandler
    {
        public static readonly XNamespace Scc = "http://esw.volvo.com/serviceconfiguratorcommon/1_0";
        public static readonly XNamespace Psc = "http://esw.volvo.com/productspecificationcommon/1_0";
        public static readonly XNamespace Cc = "http://esw.volvo.com/configuratorcommon/1_0";

        protected ServiceConfiguratorHandler(TimeProvider clock) : base(clock)
        {
        }

        /// <summary>The request in the error texts, for example "Parameter Recipe".</summary>
        protected abstract string Kind(ListenerMessageType type);

        protected abstract XNamespace ReplyNs(ListenerMessageType type);

        protected abstract string ReplyRoot { get; }

        /// <summary>The reply's schemaVersion, serviceId and serviceVersion.</summary>
        protected abstract (string Schema, string Id, string Version) Service(ListenerMessageType type);

        /// <summary>The transaction of a request: its BODId attribute, or the BODID of its ApplicationArea.</summary>
        protected static string Transaction(ListenerMessage message) => ListenerXml.Attribute(message.Xml?.Root, "BODId") ?? ListenerXml.Transaction(message.Xml);

        protected XElement Reply(ListenerMessage message, string bodId, params object?[] content)
        {
            var (schema, id, version) = Service(message.Type);
            return new XElement(ReplyNs(message.Type) + ReplyRoot,
                new XAttribute("schemaVersion", schema),
                new XAttribute("BODId", bodId),
                new XAttribute("CreatedDateTime", Clock.GetUtcNow().UtcDateTime.ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture)),
                new XAttribute("serviceId", id),
                new XAttribute("serviceVersion", version),
                content);
        }

        protected XElement? Notifications(ListenerMessageType type, IEnumerable<BreakdownNotice> notices)
        {
            var list = notices.ToList();
            return list.Count == 0 ? null : new XElement(ReplyNs(type) + "Notifications", list.Select(n => BreakdownXml.Notification(Scc, n)));
        }

        protected override XElement Error(ListenerMessage message, ListenerNotice notice, string bodId)
        {
            var kind = Kind(message.Type);
            var item = notice.Name == "RequestVersionError"
                ? new BreakdownNotice("Error", "BAD REQUEST", "The request does not match the version in the message type header and could not be processed.", notice.Text, "Change the message header type version.")
                : BreakdownNotice.TechnicalError(bodId.Length == 0 ? $"The {kind} request has an invalid format and could not be processed." : $"The {kind} was stopped by an unexpected technical error.", notice.Text);
            return Reply(message, bodId.Length == 0 ? "" : Transaction(message), Notifications(message.Type, [item]));
        }

        /// <summary>The message header attributes of a request the tool writes.</summary>
        protected object[] Header(string schemaVersion, string serviceId, string serviceVersion) =>
        [
            new XAttribute("schemaVersion", schemaVersion),
            new XAttribute("BODId", Guid.NewGuid().ToString()),
            new XAttribute("CreatedDateTime", Clock.GetUtcNow().UtcDateTime.ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture)),
            new XAttribute("serviceId", serviceId),
            new XAttribute("serviceVersion", serviceVersion),
        ];

        /// <summary>A ProductSpecification (ProductSpecificationCommon) for a vehicle: product class, variants and S-notes.</summary>
        protected static XElement Specification(XName name, ProductDocument vehicle)
        {
            var variants = vehicle.Data["productSpecification"].A("variants").Objects().Where(v => v.S("familyId").Length == 3 && v.S("variantId").Length == 3).ToList();
            var notes = vehicle.Data["productSpecification"].A("sNotes").Objects().Select(n => n.S("value")).Where(n => n.Length > 0).ToList();
            return new XElement(name,
                new XElement(Psc + "ProductClass", BreakdownXml.ProductClass(vehicle.Info.S("productClassId"))),
                new XElement(Psc + "Variants", variants.Select(v => new XElement(Psc + "Variant", new XElement(Cc + "FamilyId", v.S("familyId")), new XElement(Cc + "VariantId", v.S("variantId"))))),
                notes.Count == 0 ? null : new XElement(Psc + "SNotes", notes.Select(n => new XElement(Psc + "SNote", n))));
        }

        /// <summary>An Effectivity (ServiceConfiguratorCommon): the vehicle's factory and today.</summary>
        protected XElement Effectivity(XName name, ProductDocument vehicle) =>
            new(name,
                new XElement(Scc + "Factory", vehicle.Info.S("assemblyFactoryCode") is { Length: >= 2 and <= 3 } f ? f : "58"),
                new XElement(Scc + "Date", Clock.GetUtcNow().UtcDateTime.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)));
    }
}
