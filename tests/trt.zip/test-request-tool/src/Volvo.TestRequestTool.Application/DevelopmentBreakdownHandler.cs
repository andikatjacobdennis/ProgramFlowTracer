using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// ESW_DEV_SOFTWARE_BREAKDOWN_REQUEST and GetDevelopmentSoftwareBreakdownWithProduct, 1.4 to 2.1 (Request.Listener/Development/
    /// DevelopmentSoftwareBreakdownRequest_* and DevelopmentSoftwareBreakdownWithProductRequest_*). A development breakdown of the
    /// product specification, or of the full product given (with product), for the requested baseline or effectivity. Both
    /// answer DevelopmentSoftwareBreakdownResponse in the version's namespace.
    /// </summary>
    public sealed class DevelopmentBreakdownHandler : BreakdownListenerHandler
    {
        private static readonly string[] Versions = ["1.4", "1.5", "1.6", "1.7", "2.0", "2.1"];
        private readonly ListenerBreakdowns _breakdowns;

        public DevelopmentBreakdownHandler(ListenerBreakdowns breakdowns, TimeProvider clock) : base(clock)
        {
            _breakdowns = breakdowns;
        }

        public override IReadOnlyCollection<string> Keys { get; } = Versions.SelectMany(v => new[] { "ESW_DEV_SOFTWARE_BREAKDOWN_REQUEST_" + v, "GetDevelopmentSoftwareBreakdownWithProduct_" + v }).ToArray();

        protected override string Kind => "development breakdown";

        protected override string Component => "DevelopmentSoftwareBreakdownModule";

        protected override string ReplyRoot(ListenerMessageType type) => "DevelopmentSoftwareBreakdownResponse";

        protected override XNamespace ReplyNs(ListenerMessageType type) => "http://esw.volvo.com/developmentsoftwarebreakdownresponse/" + type.Version.Replace('.', '_');

        private static bool WithProduct(ListenerMessageType type) => type.MessageType == "GetDevelopmentSoftwareBreakdownWithProduct";

        private static XNamespace RequestNs(ListenerMessageType type) =>
            (WithProduct(type) ? "http://esw.volvo.com/developmentsoftwarebreakdownwithproductrequest/" : "http://esw.volvo.com/developmentsoftwarebreakdownrequest/") + type.Version.Replace('.', '_');

        private static string RequestRoot(ListenerMessageType type) => WithProduct(type) ? "DevelopmentSoftwareBreakdownWithProductRequest" : "DevelopmentSoftwareBreakdownRequest";

        protected override async Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct)
        {
            var result = await _breakdowns.BreakDownAsync(Data(message), message.Actor, development: true, ct);
            var bmc = Bmc(message.Type);
            var ns = ReplyNs(message.Type);
            var product = result.Product ?? new ProductDocument(new System.Text.Json.Nodes.JsonObject { ["productSpecification"] = new System.Text.Json.Nodes.JsonObject { ["productInformation"] = new System.Text.Json.Nodes.JsonObject() }, ["nodes"] = new System.Text.Json.Nodes.JsonArray(), ["parameters"] = new System.Text.Json.Nodes.JsonArray() });
            var root = Reply(message, Transaction(message), bmc.Bom(ns + "SoftwareBillOfMaterial", product, result.Baseline), bmc.Notifications(ns + "Notifications", result.Notices));
            var summary = new List<ListenerFact>
            {
                new("Outcome", result.Product is null ? "No breakdown: see the notifications." : $"{product.Nodes.Count} node(s) and {product.Parameters.Count} parameter(s) broken down" + (result.Baseline.Length > 0 ? $" for baseline {result.Baseline}." : ".")),
            };
            summary.AddRange(Version21(message.Type));
            summary.AddRange(Facts(result.Notices));
            return new ListenerAnswer(root, summary, []);
        }

        /// <summary>A request for the vehicle: all nodes, the newest baseline of its context.</summary>
        public override XDocument Example(ListenerMessageType type, ProductDocument vehicle)
        {
            var ns = RequestNs(type);
            var bmc = Bmc(type).Ns;
            var baseline = _breakdowns.NewestBaseline(vehicle);
            var content = new object[]
            {
                new XElement(ns + "RequestedNodes", new XElement(bmc + "AllNodes")),
                new XElement(ns + "RequestedVersion", new XElement(bmc + "Baseline", "{" + baseline?.S("guid").ToUpperInvariant() + "}")),
                WithProduct(type) ? ListenerProducts.ProductElement(ns, "Product", vehicle) : ListenerBreakdowns.Specification(ns + "ProductSpecification", bmc, vehicle),
            };
            return Document(IsBod(type)
                ? new XElement(ns + RequestRoot(type), ListenerXml.RequestArea(Clock), new XElement(ns + "DataArea", new XAttribute("schemaVersion", type.Version), content))
                : new XElement(ns + RequestRoot(type), new XAttribute("transactionId", Guid.NewGuid().ToString()), new XAttribute("schemaVersion", type.Version), content));
        }
    }
}
