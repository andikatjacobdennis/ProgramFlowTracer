using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>A handler of a JSON message type that can write a request for a vehicle, as the listener takes it.</summary>
    public interface IListenerJsonExample
    {
        string ExampleJson(ListenerMessageType type, ProductDocument vehicle);
    }
}
