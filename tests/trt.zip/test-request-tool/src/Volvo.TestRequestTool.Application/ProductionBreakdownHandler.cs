using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// GetProductionSoftwareBreakdown 1.4, 1.7, 2.0 and 2.1, and the TR versions (Request.Listener/Production/
    /// ProductionSoftwareBreakdown_*). The product specification broken down for the requested version: a baseline guid, or an
    /// effectivity (factory and date: the newest released or introduced node template versions by that week). TR is the same
    /// XML; in the listener it differs only in the service behind it (no deferred parameter calculations), which the tool's
    /// breakdown does not have either.
    /// </summary>
    public sealed class ProductionBreakdownHandler : BreakdownListenerHandler
    {
        private readonly ListenerBreakdowns _breakdowns;

        public ProductionBreakdownHandler(ListenerBreakdowns breakdowns, TimeProvider clock) : base(clock)
        {
            _breakdowns = breakdowns;
        }

        public override IReadOnlyCollection<string> Keys { get; } = new[] { "1.4", "1.7", "2.0", "2.1" }
            .SelectMany(v => new[] { "GetProductionSoftwareBreakdown_" + v, "GetProductionSoftwareBreakdownTR_" + v }).ToArray();

        protected override string Kind => "production breakdown";

        protected override string Component => "ProductionSoftwareBreakdownModule";

        protected override string ReplyRoot(ListenerMessageType type) => "ProductionSoftwareBreakdownResponse";

        protected override XNamespace ReplyNs(ListenerMessageType type) => "http://esw.volvo.com/productionsoftwarebreakdownresponse/" + type.Version.Replace('.', '_');

        private static XNamespace RequestNs(ListenerMessageType type) => "http://esw.volvo.com/productionsoftwarebreakdownrequest/" + type.Version.Replace('.', '_');

        protected override async Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct)
        {
            var data = Data(message);
            var result = await _breakdowns.BreakDownAsync(data, message.Actor, development: false, ct);
            var bmc = Bmc(message.Type);
            var ns = ReplyNs(message.Type);
            var product = result.Product ?? new ProductDocument(new System.Text.Json.Nodes.JsonObject { ["productSpecification"] = new System.Text.Json.Nodes.JsonObject { ["productInformation"] = new System.Text.Json.Nodes.JsonObject() }, ["nodes"] = new System.Text.Json.Nodes.JsonArray(), ["parameters"] = new System.Text.Json.Nodes.JsonArray() });
            var root = Reply(message, Transaction(message), bmc.Bom(ns + "SoftwareBillOfMaterial", product, result.Baseline), bmc.Notifications(ns + "Notifications", result.Notices));
            var summary = new List<ListenerFact>
            {
                new("Outcome", result.Product is null ? "No breakdown: see the notifications." : $"{product.Nodes.Count} node(s) and {product.Parameters.Count} parameter(s) broken down."),
            };
            summary.AddRange(Version21(message.Type));
            summary.AddRange(Facts(result.Notices));
            return new ListenerAnswer(root, summary, []);
        }

        /// <summary>A request for the vehicle: all nodes, by effectivity (the vehicle's factory, today) as production asks.</summary>
        public override XDocument Example(ListenerMessageType type, ProductDocument vehicle)
        {
            var ns = RequestNs(type);
            var bmc = Bmc(type).Ns;
            var factory = vehicle.Info.S("assemblyFactoryCode") is { Length: >= 2 and <= 3 } f ? f : "58";
            var content = new object[]
            {
                new XElement(ns + "RequestedNodes", new XElement(bmc + "AllNodes")),
                new XElement(ns + "RequestedVersion", new XElement(bmc + "Effectivity",
                    new XElement(bmc + "EffectivityFactory", factory),
                    new XElement(bmc + "EffectivityDate", Clock.GetUtcNow().UtcDateTime.ToString("yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture)))),
                ListenerBreakdowns.Specification(ns + "ProductSpecification", bmc, vehicle),
            };
            return Document(IsBod(type)
                ? new XElement(ns + "ProductionSoftwareBreakdownRequest", ListenerXml.RequestArea(Clock), new XElement(ns + "DataArea", new XAttribute("schemaVersion", type.Version), content))
                : new XElement(ns + "ProductionSoftwareBreakdownRequest", new XAttribute("transactionId", Guid.NewGuid().ToString()), new XAttribute("schemaVersion", type.Version), content));
        }
    }
}
