using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// A request to the listener: its type, the body as sent, the body as XML when it is XML, the sender, and the person who
    /// sent it from the tool (their vehicle contexts limit which vehicles a handler may read).
    /// </summary>
    public sealed record ListenerMessage(ListenerMessageType Type, string Body, XDocument? Xml, string SenderId, Actor Actor);
}
