using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// Kits applied to a product for one action criterion (SoftwareReplacements.General or one of the Remote criteria), as the
    /// listener's kit and campaign evaluations do. The outcome is Applicable, AlreadyApplied (128), NotApplicable (117) or
    /// NotPossible (any other error, or a remote criterion with a node the kit assigns that cannot be downloaded remotely).
    /// </summary>
    public sealed record KitEvaluation(string ActionCriteria, string Outcome, KitResult? Result, ListenerFault? Error)
    {
        public static readonly string[] Criteria = ["SoftwareReplacements.General", "SoftwareReplacements.RemoteCapable", "SoftwareReplacements.RemoteLimited", "SoftwareReplacements.RemoteGeneral"];

        /// <summary>The criteria of a request, in the listener's order; an unknown one is refused (100).</summary>
        public static IReadOnlyList<string> Parse(string? actionCriteria)
        {
            var tokens = (actionCriteria ?? "").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
            if (tokens.Count == 0)
            {
                throw ListenerFault.Undefined("No action criteria were given.");
            }

            var unknown = tokens.FirstOrDefault(t => !Criteria.Contains(t));
            return unknown is null ? Criteria.Where(tokens.Contains).ToList() : throw ListenerFault.Undefined($"Requested value '{unknown}' was not found.");
        }

        public static KitEvaluation Evaluate(ListenerCatalog catalog, Domain.ProductDocument product, IReadOnlyList<long> kits, string criteria, int scenario, bool serviceKitsOnly)
        {
            try
            {
                KitResult? result = null;
                var current = product;
                var assigned = new Dictionary<string, KitNode>(StringComparer.Ordinal);
                var removed = new List<JsonObject>();
                foreach (var kit in kits)
                {
                    result = catalog.ApplyKit(current, kit, scenario, serviceKitsOnly);
                    foreach (var a in result.Assigned)
                    {
                        assigned[Domain.JsonAccess.NodeKeyOf(a.Node)] = a;
                    }

                    removed.AddRange(result.Removed);
                    current = result.After;
                }

                var all = new KitResult(result!.Kit, current, assigned.Values.ToList(), removed);
                if (criteria != "SoftwareReplacements.General")
                {
                    var blocked = all.Assigned.Where(a => !catalog.Catalog.FindVersion(a.Node).B("remoteCapable")).Select(a => ListenerCatalog.Name(a.Node)).ToList();
                    if (blocked.Count > 0)
                    {
                        var fault = ListenerFault.NoValidConfigurations($"No valid configuration was found. {string.Join(", ", blocked)}: the node template does not support remote software download.");
                        return new KitEvaluation(criteria, "NotPossible", null, fault);
                    }
                }

                return new KitEvaluation(criteria, "Applicable", all, null);
            }
            catch (ListenerFault fault)
            {
                var outcome = fault.Code switch { 128 => "AlreadyApplied", 117 => "NotApplicable", _ => "NotPossible" };
                return new KitEvaluation(criteria, outcome, null, fault);
            }
        }

        /// <summary>Errors that make the whole kit evaluation Rejected, as the listener's KitEvaluation handler treats them.</summary>
        public static bool Severe(ListenerFault fault) => fault.Code is 100 or 101 or 102 or 103 or 104 or 105 or 107 or 108 or 111 or 112 or 113 or 115 or 116 or 117 or 118 or 122 or 125 or 128 or 129 or 130 or 131 or 132;
    }
}
