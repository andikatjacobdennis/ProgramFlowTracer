namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// A message type and version the request listener (swb-stable1 Request.Listener) handles. The listener routes on
    /// <see cref="Key"/>, the message type and version joined by an underscore, for example GetKitEvaluation_2.1.
    /// A null side has no contract at all (Ping and GetInfo take any body). <see cref="NameAssumed"/> marks a message type
    /// that MessageTypes.cs in the contracts does not name, so its constant name stands in for it. <see cref="ErrorReply"/> is
    /// the contract of the error reply when it is not the reply contract (ErrorReport 1.1 for the assigned nodes in a kit).
    /// </summary>
    public sealed record ListenerMessageType(
        string MessageType,
        string Version,
        string Name,
        string Title,
        string About,
        string Area,
        string Handler,
        ListenerContract? Request,
        ListenerContract? Reply,
        bool NameAssumed,
        ListenerContract? ErrorReply = null)
    {
        public string Key => MessageType + "_" + Version;
    }
}
