using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>A kit applied to a product: the kit, the product after it, the nodes it assigns and the nodes it removes.</summary>
    public sealed record KitResult(JsonObject Kit, ProductDocument After, IReadOnlyList<KitNode> Assigned, IReadOnlyList<JsonObject> Removed);
}
