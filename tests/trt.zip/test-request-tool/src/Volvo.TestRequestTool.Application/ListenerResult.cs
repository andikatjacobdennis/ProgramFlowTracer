namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The outcome of one listener message: whether the tool simulates the message type, what does not follow the request
    /// and reply contracts, the reply, every notification (the dispatcher's and the handler's) and the time it took.
    /// </summary>
    public sealed record ListenerResult(
        string MessageType,
        string Version,
        string Title,
        bool Simulated,
        IReadOnlyList<string> RequestErrors,
        ListenerReply? Reply,
        IReadOnlyList<string> ReplyErrors,
        IReadOnlyList<ListenerNotice> Notices,
        double Milliseconds);
}
