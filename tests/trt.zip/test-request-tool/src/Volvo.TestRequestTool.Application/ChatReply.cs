namespace Volvo.TestRequestTool.Application
{
    /// <summary>Confidence: confirmed (from a record or rule), likely, or unknown. Simulated is true for the built-in provider.</summary>
    public sealed record ChatReply(string Text, IReadOnlyList<Citation> Citations, string Confidence, IReadOnlyList<SuggestedAction> Actions, string Provider, bool Simulated, IReadOnlyList<string> SuggestedQuestions);
}
