namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// A summary of one source. SourceVersion and GeneratedAt let the interface mark it outdated when the source changes.
    /// Sections: identity, changes, findings, limitations, next.
    /// </summary>
    public sealed record SummaryReply(string Title, string SourceKind, string SourceId, string SourceVersion, DateTimeOffset GeneratedAt, IReadOnlyList<SummaryStatement> Statements, string Provider, bool Simulated);
}
