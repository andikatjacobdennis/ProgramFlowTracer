namespace Volvo.TestRequestTool.Application
{
    public sealed record AgentStep(int Number, string Text);
}
