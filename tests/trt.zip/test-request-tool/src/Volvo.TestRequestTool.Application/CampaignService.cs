using System.Globalization;
using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// Campaigns: one change coordinated across eligible vehicles.
    /// <list type="bullet">
    /// <item><b>Define and prepare</b>: a name, the vehicles (each must be readable) and a request template (kind and options).
    /// Every edit is a new revision and clears the approval.</item>
    /// <item><b>Validate</b>: a batch run of the current revision for all or some vehicles (BatchRunner), one request per
    /// vehicle. Each vehicle's state comes from its latest batch item of this revision: ready, blocked, running, or unknown;
    /// a validation on an older vehicle revision is stale.</item>
    /// <item><b>Approve</b>: someone else with the Writer role (never the owner) approves the exact revision; the approval
    /// covers the vehicles that are ready then, with their validated results.</item>
    /// <item><b>Submit</b>: each approved vehicle still on its validated revision is committed to the VDA repository;
    /// the others are skipped with the reason. Submitting again returns the same result.</item>
    /// </list>
    /// A campaign is visible to people who may read at least one of its vehicles; changing it needs access to all of them.
    /// </summary>
    public sealed class CampaignService
    {
        private readonly IWorkspaceStore _store;
        private readonly TimeProvider _clock;
        public const int MaxVehicles = 200;

        public CampaignService(IWorkspaceStore store, TimeProvider clock)
        {
            _store = store;
            _clock = clock;
        }

        // ------------------------------------------------------------------ reading
        public static bool CanSee(Actor a, CampaignRecord c, IReadOnlyDictionary<string, int> contexts) =>
            c.OwnerId == a.Id || c.VehicleIds.Any(v => contexts.TryGetValue(v, out var ctx) && a.Contexts.Contains(ctx));

        private async Task<IReadOnlyDictionary<string, VersionedProduct>> VehiclesAsync(CancellationToken ct) =>
            (await _store.VehiclesAsync(ct)).ToDictionary(v => new ProductDocument(v.Product).Id, v => v, StringComparer.Ordinal);

        private static IReadOnlyDictionary<string, int> Contexts(IReadOnlyDictionary<string, VersionedProduct> vehicles) =>
            vehicles.ToDictionary(kv => kv.Key, kv => new ProductDocument(kv.Value.Product).ContextId, StringComparer.Ordinal);

        public async Task<IReadOnlyList<JsonObject>> ListAsync(Actor actor, CancellationToken ct)
        {
            var vehicles = await VehiclesAsync(ct);
            var contexts = Contexts(vehicles);
            var list = new List<JsonObject>();
            foreach (var c in (await _store.CampaignsAsync(ct)).Where(c => CanSee(actor, c, contexts)))
            {
                list.Add(Summary(c, await RowsAsync(actor, c, vehicles, ct)));
            }

            return list;
        }

        public async Task<JsonObject> GetAsync(Actor actor, Guid id, CancellationToken ct)
        {
            var vehicles = await VehiclesAsync(ct);
            var c = await _store.CampaignAsync(id, ct);
            if (c is null || !CanSee(actor, c, Contexts(vehicles)))
            {
                throw new RequestFault(404, "campaign_missing", "Campaign was not found.");
            }

            var rows = await RowsAsync(actor, c, vehicles, ct);
            var o = Summary(c, rows);
            o["vehicles"] = new JsonArray(rows.Select(r => (JsonNode)r.DeepClone()).ToArray());
            o["template"] = c.Template.DeepClone();
            o["kind"] = c.Kind;
            o["validations"] = new JsonArray(c.Validations.OrderByDescending(v => v.At).Select(v => (JsonNode)new JsonObject { ["revision"] = v.Revision, ["batchId"] = v.BatchId, ["vehicles"] = v.VehicleIds.Count, ["at"] = v.At.ToString("O", CultureInfo.InvariantCulture), ["current"] = v.Revision == c.Revision }).ToArray());
            o["approval"] = c.Approval is null ? null : new JsonObject { ["revision"] = c.Approval.Revision, ["by"] = c.Approval.ActorName, ["at"] = c.Approval.At.ToString("O", CultureInfo.InvariantCulture), ["note"] = c.Approval.Note, ["vehicles"] = c.Approval.Vehicles.Count, ["current"] = c.Approval.Revision == c.Revision };
            o["submission"] = c.Submission is null ? null : new JsonObject
            {
                ["id"] = c.Submission.Id,
                ["by"] = c.Submission.ActorName,
                ["at"] = c.Submission.At.ToString("O", CultureInfo.InvariantCulture),
                ["vehicles"] = new JsonArray(c.Submission.Vehicles.Select(v => (JsonNode)new JsonObject { ["id"] = v.VehicleId, ["outcome"] = v.Outcome, ["from"] = v.FromRevision, ["to"] = v.ToRevision, ["reason"] = v.Reason }).ToArray()),
            };
            o["events"] = new JsonArray(c.Events.Reverse().Select(e => (JsonNode)new JsonObject { ["at"] = e.At.ToString("O", CultureInfo.InvariantCulture), ["by"] = e.ActorName, ["text"] = e.Text }).ToArray());
            return o;
        }

        /// <summary>Each vehicle's state for the current revision: validation, approval and the next action.</summary>
        private async Task<IReadOnlyList<JsonObject>> RowsAsync(Actor actor, CampaignRecord c, IReadOnlyDictionary<string, VersionedProduct> vehicles, CancellationToken ct)
        {
            var batches = new List<BatchRecord>();
            foreach (var v in c.Validations.Where(v => v.Revision == c.Revision).OrderByDescending(v => v.At))
            {
                if (await _store.BatchAsync(v.BatchId, ct) is { } b)
                {
                    batches.Add(b);
                }
            }

            var rows = new List<JsonObject>();
            foreach (var id in c.VehicleIds)
            {
                vehicles.TryGetValue(id, out var current);
                var readable = current is not null && actor.Contexts.Contains(new ProductDocument(current.Product).ContextId);
                var item = batches.Select(b => (Batch: b, Item: b.Items.FirstOrDefault(i => i.VehicleId == id))).FirstOrDefault(x => x.Item is not null);
                string validation = "unknown";
                long? baseRevision = null;
                int blocking = 0;
                if (item.Item is { } it)
                {
                    validation = it.Status switch { "ready" or "limited" => "ready", "blocked" => "blocked", "failed" => "failed", "waiting" or "running" => "running", _ => "unknown" };
                    if (it.ResultId is Guid rid && await _store.ExecutionAsync(rid, item.Batch.Actor.Id, ct) is { } rec && rec.Outcomes.FirstOrDefault(o => o.VehicleId == id) is { } outcome)
                    {
                        baseRevision = outcome.BaseRevision;
                        blocking = outcome.Issues.Count(i => i.Severity == 0);
                        if (current is not null && outcome.BaseRevision != current.Revision && !(c.Submission?.Vehicles.Any(s => s.VehicleId == id && s.ToRevision == current.Revision) ?? false))
                        {
                            validation = "stale";
                        }
                    }
                }
                var approved = c.Approval is { } ap && ap.Revision == c.Revision && ap.Vehicles.Any(a => a.VehicleId == id);
                var submitted = c.Submission?.Vehicles.FirstOrDefault(s => s.VehicleId == id);
                var approval = submitted?.Outcome == "committed" ? "submitted" : approved ? "approved" : validation == "ready" ? "pending" : "not-ready";
                var next = submitted?.Outcome == "committed" ? "Receipt" : validation switch { "unknown" or "failed" => "Validate", "running" => "Track", "blocked" => "Resolve", "stale" => "Validate", _ => approved ? (c.Status == "approved" ? "Submit" : "Review") : "Review" };
                var info = current?.Product["productSpecification"]?["productInformation"];
                rows.Add(new JsonObject
                {
                    ["id"] = id,
                    ["title"] = current is null ? id.Replace('|', ' ') : ProposalDiff.Title(current.Product),
                    ["architecture"] = current is null ? "" : ProposalDiff.Architecture(current.Product),
                    ["readable"] = readable,
                    ["validation"] = validation,
                    ["approval"] = approval,
                    ["next"] = next,
                    ["blocking"] = blocking,
                    ["revision"] = current?.Revision,
                    ["basedOn"] = baseRevision,
                    ["resultId"] = item.Item?.ResultId,
                    ["error"] = item.Item?.Error,
                    ["model"] = info.S("modelId"),
                });
            }
            return rows;
        }

        private static JsonObject Summary(CampaignRecord c, IReadOnlyList<JsonObject> rows)
        {
            int Count(string v) => rows.Count(r => r["validation"]!.GetValue<string>() == v);
            var validated = rows.Count > 0 && rows.All(r => r["validation"]!.GetValue<string>() is "ready" or "blocked" or "stale" or "failed");
            var stage = c.Status == "submitted" ? 5 : c.Approval?.Revision == c.Revision ? 4 : validated ? 3 : c.Validations.Any(v => v.Revision == c.Revision) ? 2 : c.VehicleIds.Count > 0 ? 2 : 0;
            return new JsonObject
            {
                ["id"] = c.Id,
                ["code"] = c.Code,
                ["name"] = c.Name,
                ["description"] = c.Description,
                ["owner"] = new JsonObject { ["id"] = c.OwnerId, ["name"] = c.OwnerName },
                ["createdAt"] = c.CreatedAt.ToString("O", CultureInfo.InvariantCulture),
                ["revision"] = c.Revision,
                ["status"] = c.Status,
                ["version"] = c.Version,
                ["total"] = rows.Count,
                ["counts"] = new JsonObject { ["ready"] = Count("ready"), ["blocked"] = Count("blocked") + Count("failed"), ["unknown"] = Count("unknown"), ["running"] = Count("running"), ["stale"] = Count("stale") },
                ["approvalState"] = c.Status == "submitted" ? "submitted" : c.Approval?.Revision == c.Revision ? "approved" : c.Status == "changes_requested" ? "changes" : "pending",
                ["stage"] = stage,
                ["awaitingApproval"] = c.Status is "active" && Count("ready") > 0 && c.Approval?.Revision != c.Revision,
            };
        }

        // ------------------------------------------------------------------ changing
        private async Task<(CampaignRecord C, IReadOnlyDictionary<string, VersionedProduct> V)> EditableAsync(Actor actor, Guid id, long version, CancellationToken ct)
        {
            var vehicles = await VehiclesAsync(ct);
            var c = await _store.CampaignAsync(id, ct);
            if (c is null || !CanSee(actor, c, Contexts(vehicles)))
            {
                throw new RequestFault(404, "campaign_missing", "Campaign was not found.");
            }

            if (c.Version != version)
            {
                throw new RequestFault(409, "campaign_conflict", "The campaign changed since you opened it. Reload it and try again.");
            }

            foreach (var v in c.VehicleIds)
            {
                if (vehicles.TryGetValue(v, out var p))
                {
                    actor.DemandRead(new ProductDocument(p.Product).ContextId);
                }
            }

            return (c, vehicles);
        }

        private static IReadOnlyList<string> CleanVehicles(Actor actor, IEnumerable<string>? ids, IReadOnlyDictionary<string, VersionedProduct> vehicles)
        {
            var list = (ids ?? []).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct(StringComparer.Ordinal).ToArray();
            if (list.Length is 0)
            {
                throw new RequestFault(400, "no_vehicles", "Choose at least one vehicle.");
            }

            if (list.Length > MaxVehicles)
            {
                throw new RequestFault(400, "too_many_vehicles", $"A campaign can include up to {MaxVehicles} vehicles.");
            }

            foreach (var v in list)
            {
                if (!vehicles.TryGetValue(v, out var p))
                {
                    throw new RequestFault(404, "vehicle_missing", $"Vehicle {v.Replace('|', ' ')} was not found.");
                }

                actor.DemandRead(new ProductDocument(p.Product).ContextId);
            }
            return list;
        }

        private static (string Kind, JsonObject Template) CleanTemplate(string? kind, JsonObject? template)
        {
            if (!Enum.TryParse<RequestKind>(kind ?? "Software", true, out var k))
            {
                throw new RequestFault(400, "request_kind", "Unknown request kind.");
            }

            var tpl = (JsonObject?)template?.DeepClone() ?? new JsonObject { ["softwareRequestOperation"] = (int)SoftwareOperation.Update, ["scenario"] = 1, ["pblUpdateCapable"] = true, ["enableMultiNodeBehavior"] = true };
            tpl.Remove("products");
            tpl.Remove("product");
            return (k.ToString(), tpl);
        }

        private static string Bound(string? s, int max)
        {
            var t = (s ?? "").Trim();
            return t.Length > max ? t[..max] : t;
        }

        public async Task<CampaignRecord> CreateAsync(Actor actor, string? name, string? description, IEnumerable<string>? vehicleIds, string? kind, JsonObject? template, CancellationToken ct)
        {
            var vehicles = await VehiclesAsync(ct);
            var n = Bound(name, 80);
            if (n.Length == 0)
            {
                throw new RequestFault(400, "name_required", "Name the campaign.");
            }

            var ids = CleanVehicles(actor, vehicleIds, vehicles);
            var (k, tpl) = CleanTemplate(kind, template);
            var code = "CMP-" + ((await _store.CampaignsAsync(ct)).Count + 1).ToString("000", CultureInfo.InvariantCulture);
            var now = _clock.GetUtcNow();
            return await _store.SaveCampaignAsync(new CampaignRecord(Guid.NewGuid(), code, n, Bound(description, 400), actor.Id, actor.DisplayName, now, 1, "draft", k, tpl, ids, [], null, null,
                [new(now, actor.DisplayName, $"Created with {ids.Count} vehicle(s)")]), null, ct);
        }

        /// <summary>A new revision: the approval no longer applies; validations of older revisions stay as history.</summary>
        public async Task<CampaignRecord> UpdateAsync(Actor actor, Guid id, long version, string? name, string? description, IEnumerable<string>? vehicleIds, string? kind, JsonObject? template, CancellationToken ct)
        {
            var (c, vehicles) = await EditableAsync(actor, id, version, ct);
            if (c.Status is "submitted" or "archived")
            {
                throw new RequestFault(409, "campaign_closed", "This campaign is " + c.Status + ".");
            }

            var ids = vehicleIds is null ? c.VehicleIds : CleanVehicles(actor, vehicleIds, vehicles);
            var (k, tpl) = template is null && kind is null ? (c.Kind, c.Template) : CleanTemplate(kind ?? c.Kind, template ?? c.Template);
            var now = _clock.GetUtcNow();
            return await _store.SaveCampaignAsync(c with
            {
                Name = name is null ? c.Name : Bound(name, 80) is { Length: > 0 } n ? n : c.Name,
                Description = description is null ? c.Description : Bound(description, 400),
                VehicleIds = ids,
                Kind = k,
                Template = tpl,
                Revision = c.Revision + 1,
                Status = "draft",
                Approval = null,
                Events = [.. c.Events, new(now, actor.DisplayName, $"Revision {c.Revision + 1}: edited; approval cleared")],
            }, c.Version, ct);
        }

        /// <summary>Validates the current revision as a batch run (one request per vehicle, one after another).</summary>
        public async Task<CampaignRecord> ValidateAsync(Actor actor, Guid id, long version, IEnumerable<string>? vehicleIds, CancellationToken ct)
        {
            var (c, _) = await EditableAsync(actor, id, version, ct);
            if (c.Status is "submitted" or "archived")
            {
                throw new RequestFault(409, "campaign_closed", "This campaign is " + c.Status + ".");
            }

            var ids = (vehicleIds ?? c.VehicleIds).Where(c.VehicleIds.Contains).Distinct(StringComparer.Ordinal).ToArray();
            if (ids.Length == 0)
            {
                throw new RequestFault(400, "no_vehicles", "Choose vehicles of this campaign to validate.");
            }

            var now = _clock.GetUtcNow();
            var batch = await _store.SaveBatchAsync(new BatchRecord(Guid.NewGuid(), JobActor.From(actor), $"{c.Code} revision {c.Revision}", c.Kind, (JsonObject)c.Template.DeepClone(), 1000, false, "queued", now,
                ids.Select(v => new BatchItem(v, "waiting")).ToArray()), ct);
            return await _store.SaveCampaignAsync(c with
            {
                Status = c.Status == "approved" ? "approved" : "active",
                Validations = [.. c.Validations, new(c.Revision, batch.Id, ids, now, actor.Id)],
                Events = [.. c.Events, new(now, actor.DisplayName, $"Validation started for {ids.Length} vehicle(s), revision {c.Revision}")],
            }, c.Version, ct);
        }

        public async Task<CampaignRecord> DecideAsync(Actor actor, bool canApprove, Guid id, long version, string? decision, string? note, CancellationToken ct)
        {
            var (c, vehicles) = await EditableAsync(actor, id, version, ct);
            if (!canApprove)
            {
                throw new RequestFault(403, "approve_denied", "Deciding on a campaign needs the Reviewer or Admin role.");
            }

            if (c.OwnerId == actor.Id)
            {
                throw new RequestFault(403, "separation_of_duties", "You cannot approve your own campaign; another reviewer must.");
            }

            if (c.Status is "submitted" or "archived")
            {
                throw new RequestFault(409, "campaign_closed", "This campaign is " + c.Status + ".");
            }

            var now = _clock.GetUtcNow();
            var text = Bound(note, 500);
            if (decision == "request_changes")
            {
                if (text.Length == 0)
                {
                    throw new RequestFault(400, "note_required", "Say what needs to change.");
                }

                return await _store.SaveCampaignAsync(c with { Status = "changes_requested", Approval = null, Events = [.. c.Events, new(now, actor.DisplayName, "Changes requested: " + text)] }, c.Version, ct);
            }
            if (decision != "approve")
            {
                throw new RequestFault(400, "decision", "Decision is approve or request_changes.");
            }

            var rows = await RowsAsync(actor, c, vehicles, ct);
            var ready = rows.Where(r => r["validation"]!.GetValue<string>() == "ready" && r["resultId"] is not null && r["basedOn"] is not null).ToArray();
            if (ready.Length == 0)
            {
                throw new RequestFault(409, "nothing_ready", "No vehicle of this revision is validated and ready.");
            }

            var covered = new List<ApprovedVehicle>();
            foreach (var r in ready)
            {
                var vid = r["id"]!.GetValue<string>();
                var v = c.Validations.Where(x => x.Revision == c.Revision && x.VehicleIds.Contains(vid)).OrderByDescending(x => x.At).First();
                covered.Add(new(vid, r["resultId"]!.GetValue<Guid>(), v.ActorId, r["basedOn"]!.GetValue<long>()));
            }
            return await _store.SaveCampaignAsync(c with
            {
                Status = "approved",
                Approval = new(c.Revision, actor.Id, actor.DisplayName, now, text, covered),
                Events = [.. c.Events, new(now, actor.DisplayName, $"Approved revision {c.Revision} for {covered.Count} ready vehicle(s)" + (rows.Count > covered.Count ? $"; {rows.Count - covered.Count} not ready are excluded" : ""))],
            }, c.Version, ct);
        }

        public async Task<CampaignRecord> SubmitAsync(Actor actor, bool canSubmit, Guid id, bool confirmed, CancellationToken ct)
        {
            var vehicles = await VehiclesAsync(ct);
            var c = await _store.CampaignAsync(id, ct);
            if (c is null || !CanSee(actor, c, Contexts(vehicles)))
            {
                throw new RequestFault(404, "campaign_missing", "Campaign was not found.");
            }

            if (c.Status == "submitted")
            {
                return c;   // the same result again: safe to retry
            }

            if (!canSubmit)
            {
                throw new RequestFault(403, "submit_denied", "Submitting needs the Reviewer or Admin role.");
            }

            if (!confirmed)
            {
                throw new RequestFault(400, "confirm_required", "Confirm the campaign revision.");
            }

            if (c.Status != "approved" || c.Approval?.Revision != c.Revision)
            {
                throw new RequestFault(409, "approval_required", "Submission is unavailable until the exact campaign revision is approved.");
            }

            var now = _clock.GetUtcNow();
            var label = "SUB-" + c.Id.ToString("N")[..6].ToUpperInvariant();
            var results = new List<CampaignSubmitted>();
            foreach (var a in c.Approval.Vehicles)
            {
                var current = vehicles.GetValueOrDefault(a.VehicleId);
                var record = await _store.ExecutionAsync(a.ResultId, a.ResultOwnerId, ct);
                var outcome = record?.Outcomes.FirstOrDefault(o => o.VehicleId == a.VehicleId);
                if (current is null || outcome is null)
                {
                    results.Add(new(a.VehicleId, "skipped", null, null, "The validated result is missing."));
                    continue;
                }
                actor.DemandWrite(new ProductDocument(current.Product).ContextId);
                if (current.Revision != a.BaseRevision)
                {
                    results.Add(new(a.VehicleId, "skipped", current.Revision, null, $"The vehicle changed after validation (revision {a.BaseRevision} → {current.Revision})."));
                    continue;
                }
                var saved = await _store.UpdateVehicleAsync(a.VehicleId, outcome.Proposal, a.BaseRevision, ct, new RevisionNote(actor.Id, actor.DisplayName, $"Campaign {c.Code} revision {c.Revision}, approved by {c.Approval.ActorName}", "campaign:" + c.Id));
                results.Add(new(a.VehicleId, "committed", a.BaseRevision, saved.Revision, null));
            }
            var latest = await _store.CampaignAsync(id, ct) ?? c;
            var committed = results.Count(r => r.Outcome == "committed");
            return await _store.SaveCampaignAsync(latest with
            {
                Status = "submitted",
                Submission = new(label, actor.Id, actor.DisplayName, now, results),
                Events = [.. latest.Events, new(now, actor.DisplayName, $"Submitted as {label}: {committed} committed, {results.Count - committed} skipped")],
            }, latest.Version, ct);
        }

        public async Task<CampaignRecord> ArchiveAsync(Actor actor, Guid id, long version, CancellationToken ct)
        {
            var (c, _) = await EditableAsync(actor, id, version, ct);
            if (c.OwnerId != actor.Id)
            {
                throw new RequestFault(403, "archive_denied", "Only the owner can archive a campaign.");
            }

            return await _store.SaveCampaignAsync(c with { Status = "archived", Events = [.. c.Events, new(_clock.GetUtcNow(), actor.DisplayName, "Archived")] }, c.Version, ct);
        }
    }
}
