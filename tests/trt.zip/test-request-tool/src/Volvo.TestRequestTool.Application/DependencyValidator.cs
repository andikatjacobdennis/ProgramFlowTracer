using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    public sealed class DependencyValidator : IProductValidator
    {
        public string Name => "dependencies";
        public int Order => 30;

        public ValueTask<IReadOnlyList<ValidationIssue>> ValidateAsync(ValidationContext c, CancellationToken ct)
        {
            var issues = new List<ValidationIssue>();
            foreach (var n in c.Proposal.Nodes.Objects())
            {
                ct.ThrowIfCancellationRequested();
                var v = c.Catalog.FindVersion(n);
                if (v is null)
                {
                    continue;
                }

                foreach (var dep in v.A("requires").Objects())
                {
                    var node = c.Proposal.Nodes.Objects().FirstOrDefault(x => c.Catalog.FindTemplate(x)?.S("key") == dep.S("key"));
                    var dependencyVersion = node is null ? null : c.Catalog.FindVersion(node);
                    if (dependencyVersion is null || dependencyVersion.I("idx", -1) < dep.I("minIdx"))
                    {
                        issues.Add(new("dependency_unsatisfied", $"{n.S("name")} requires {dep.S("key")} at catalog version {dep.I("minIdx")} or newer.", 0, n.S("name")));
                    }
                }
            }
            return ValueTask.FromResult<IReadOnlyList<ValidationIssue>>(issues);
        }
    }
}
