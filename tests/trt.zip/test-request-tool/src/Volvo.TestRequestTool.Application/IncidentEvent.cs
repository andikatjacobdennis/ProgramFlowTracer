namespace Volvo.TestRequestTool.Application
{
    public sealed record IncidentEvent(DateTimeOffset At, string Kind, string Text);
}
