using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// One piece of context, retrieved by the server from records the caller may read. Version identifies the source state
    /// (a revision number or a record id), so a summary made from it can be recognised as outdated later.
    /// </summary>
    public sealed record ContextItem(string Kind, string Id, string Title, string Version, DateTimeOffset? At, JsonObject Facts);
}
