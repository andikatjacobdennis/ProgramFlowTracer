namespace Volvo.TestRequestTool.Application
{
    /// <summary>A source an answer or statement rests on. Kind: help, glossary, record, finding, rule. Reference is a link or record id.</summary>
    public sealed record Citation(string Kind, string Title, string? Reference);
}
