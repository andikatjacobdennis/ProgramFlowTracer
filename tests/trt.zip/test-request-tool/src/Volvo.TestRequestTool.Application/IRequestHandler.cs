using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>One handler per request kind. Add another handler without changing the dispatcher.</summary>
    public interface IRequestHandler
    {
        RequestKind Kind { get; }
        ValueTask<HandlerResult> HandleAsync(ProductDocument original, JsonObject payload, CancellationToken ct);
    }
}
