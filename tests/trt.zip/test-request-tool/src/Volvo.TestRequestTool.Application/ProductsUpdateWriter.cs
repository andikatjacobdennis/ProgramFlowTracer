using System.Globalization;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The product delta of the Aftermarket update replies: ProductUpdate 2.1 (one product), ProductsUpdate 1.0 and 1.1 (one
    /// ProductUpdate per product, with its chassis). The delta is the difference between the product before and after the
    /// change, as the tool's own handlers compute it: assigned and removed variants, the nodes that change (with their full
    /// Node 2.1 body and the other hardware they run on), assigned and removed parameters, and assigned and removed S-notes.
    /// Errors of those handlers become the listener's error codes, so a refused request is Rejected with the code the
    /// listener would give.
    /// </summary>
    public sealed partial class ProductsUpdateWriter
    {
        public static readonly XNamespace Pv = "http://esw.volvo.com/parametervalue/2_1";
        public static readonly XNamespace Val = "http://esw.volvo.com/value/1_0";

        // The tool's issue codes and the listener's error codes for the same problem.
        private static readonly Dictionary<string, (int Code, string Name)> Codes = new(StringComparer.Ordinal)
        {
            ["kit_required"] = (107, "InvalidMessage"),
            ["kit_missing"] = (113, "ConversionKitNotFound"),
            ["kit_product_class"] = (113, "ConversionKitNotFound"),
            ["simulation_kit_missing"] = (113, "ConversionKitNotFound"),
            ["simulation_kit_context"] = (113, "ConversionKitNotFound"),
            ["kit_not_available"] = (111, "ConversionKitNotIntroduced"),
            ["requested_node_missing"] = (118, "NodeMissing"),
            ["empty_scope"] = (102, "RequestedNodeError"),
            ["unknown_node"] = (105, "UnknownNodeTemplate"),
            ["unresolved_template"] = (105, "UnknownNodeTemplate"),
            ["no_compatible_version"] = (110, "NoValidConfigurationsError"),
            ["incompatible_hardware_or_pbl"] = (114, "InvalidHardwareError"),
        };

        private readonly ICatalog _catalog;

        public ProductsUpdateWriter(ICatalog catalog)
        {
            _catalog = catalog;
        }

        /// <summary>The first blocking issue of a handler result as a listener error, or null when the change can be made.</summary>
        public static ListenerFault? Fault(IEnumerable<ValidationIssue> issues)
        {
            var blocking = issues.FirstOrDefault(i => i.Severity == 0);
            if (blocking is null)
            {
                return null;
            }

            var (code, name) = Codes.GetValueOrDefault(blocking.Code, (100, "Undefined"));
            return new ListenerFault(code, name, blocking.Node is null ? blocking.Text : $"{blocking.Node}: {blocking.Text}");
        }

        /// <summary>
        /// The delta elements of one product, in the contracts' order. <paramref name="v11"/> adds isSoftwareSame to the nodes;
        /// a service pack (1.0 and 2.1 write it here; 1.1 writes it after the products) ends the list.
        /// </summary>
        public IEnumerable<XElement> Delta(XNamespace ns, ProductDocument before, ProductDocument after, bool v11, XElement? servicePack)
        {
            var variantsBefore = Variants(before);
            var variantsAfter = Variants(after);
            var assignedVariants = variantsAfter.Where(v => !variantsBefore.ContainsKey(v.Key)).Select(v => v.Value).ToList();
            var removedVariants = variantsBefore.Where(v => !variantsAfter.ContainsKey(v.Key)).Select(v => v.Value).ToList();
            if (assignedVariants.Count > 0)
            {
                yield return new XElement(ns + "AssignedVariants", assignedVariants.Select(v => Variant(ns, v)));
            }

            if (removedVariants.Count > 0)
            {
                yield return new XElement(ns + "RemovedVariants", removedVariants.Select(v => Variant(ns, v)));
            }

            var nodesBefore = before.Nodes.Objects().ToDictionary(JsonAccess.NodeKeyOf, StringComparer.Ordinal);
            var changed = after.Nodes.Objects().Where(n => !nodesBefore.TryGetValue(JsonAccess.NodeKeyOf(n), out var old) || !JsonNode.DeepEquals(old, n)).ToList();
            if (changed.Count > 0)
            {
                yield return new XElement(ns + "AssignedNodes", changed.Select(n => Node(ns, n, v11)));
            }

            var parametersBefore = Parameters(before);
            var parametersAfter = Parameters(after);
            var assignedParameters = parametersAfter.Where(p => !parametersBefore.TryGetValue(p.Key, out var old) || !JsonNode.DeepEquals(old["references"], p.Value["references"])).Select(p => p.Value).ToList();
            var removedParameters = parametersBefore.Where(p => !parametersAfter.ContainsKey(p.Key)).Select(p => p.Value.S("code")).Distinct().Order(StringComparer.Ordinal).ToList();
            if (assignedParameters.Count > 0)
            {
                yield return AssignedParameters(ns, assignedParameters);
            }

            if (removedParameters.Count > 0)
            {
                yield return new XElement(ns + "RemovedParameters", removedParameters.Select(c => new XElement(ns + "ParameterCode", c)));
            }

            var notesBefore = SNotes(before);
            var notesAfter = SNotes(after);
            var assignedNotes = notesAfter.Where(n => !notesBefore.Contains(n)).ToList();
            var removedNotes = notesBefore.Where(n => !notesAfter.Contains(n)).ToList();
            if (assignedNotes.Count > 0)
            {
                yield return new XElement(ns + "AssignedSNotes", assignedNotes.Select(n => SNote(ns, n)));
            }

            if (removedNotes.Count > 0)
            {
                yield return new XElement(ns + "RemovedSNotes", removedNotes.Select(n => SNote(ns, n)));
            }

            if (servicePack is not null)
            {
                yield return servicePack;
            }
        }

        /// <summary>What changed, in words, for the summary.</summary>
        public static string Describe(ProductDocument before, ProductDocument after)
        {
            var nodesBefore = before.Nodes.Objects().ToDictionary(JsonAccess.NodeKeyOf, StringComparer.Ordinal);
            var nodes = after.Nodes.Objects().Where(n => !nodesBefore.TryGetValue(JsonAccess.NodeKeyOf(n), out var old) || !JsonNode.DeepEquals(old, n))
                .Select(n => nodesBefore.TryGetValue(JsonAccess.NodeKeyOf(n), out var old) && old.S("versionName") != n.S("versionName") ? $"{n.S("name")} {old.S("versionName")} → {n.S("versionName")}" : n.S("name")).ToList();
            var parameters = Parameters(after).Count(p => !Parameters(before).TryGetValue(p.Key, out var old) || !JsonNode.DeepEquals(old["references"], p.Value["references"]));
            var variants = Variants(after).Keys.Except(Variants(before).Keys).Count();
            var parts = new List<string>();
            if (nodes.Count > 0)
            {
                parts.Add("nodes " + string.Join(", ", nodes));
            }

            if (parameters > 0)
            {
                parts.Add($"{parameters} parameter(s)");
            }

            if (variants > 0)
            {
                parts.Add($"{variants} variant(s)");
            }

            return parts.Count == 0 ? "No change." : "Changes " + string.Join("; ", parts) + ".";
        }

        public static XElement ServicePack(XNamespace ns, JsonObject pack) =>
            new(ns + "ServicePack", new XAttribute("name", pack.S("name")), new XAttribute("guid", pack.S("guid").ToUpperInvariant()));

        private XElement Node(XNamespace ns, JsonObject node, bool v11)
        {
            var version = _catalog.FindVersion(node);
            var hardware = ListenerCatalog.CompatibleHardware(version, node).ToList();
            var element = ListenerProducts.NodeElement(ns + "Node", node,
                hardware.Count == 0 ? null : new XElement(ns + "CompatibleHardwares", hardware.Select(h => new XElement(ns + "CompatibleHardware", new XAttribute("partNumber", ListenerXml.PartNumber(h.PartNumber)), new XAttribute("compatiblePartNumber", ListenerXml.PartNumber(h.Compatible))))));
            if (v11)
            {
                element.Add(new XAttribute("isSoftwareSame", node.B("isSoftwareSame") ? "true" : "false"));
            }

            return element;
        }

        private XElement AssignedParameters(XNamespace ns, List<JsonObject> parameters)
        {
            var tea2 = parameters.Where(p => p.I("electricalArchitecture") == 0).OrderBy(p => p.S("code"), StringComparer.Ordinal).ToList();
            var plus = parameters.Where(p => p.I("electricalArchitecture") != 0).OrderBy(p => p.S("code"), StringComparer.Ordinal).ToList();
            XElement? Group(string name, IEnumerable<JsonObject> list, Func<JsonObject, XElement> write)
            {
                var items = list.Select(write).ToList();
                return items.Count == 0 ? null : new XElement(ns + name, items);
            }

            return new XElement(ns + "AssignedParameters",
                Group("PackagedParameters", plus.Where(p => p.B("packaged")), p => Parameter(ns, p)),
                Group("UnpackagedParameters", plus.Where(p => !p.B("packaged")), p => Parameter(ns, p)),
                Group("Tea2Parameters", tea2, p => Tea2Parameter(ns, p)));
        }

        /// <summary>A TEA2+ parameter (ParameterValue 2.1): a scalar with its unit, a boolean or a string, as its definition says.</summary>
        private XElement Parameter(XNamespace ns, JsonObject parameter)
        {
            var code = parameter.S("code");
            var value = parameter.A("references").Objects().FirstOrDefault().S("value");
            var definition = _catalog.Data["paramDefs"]?[parameter.I("electricalArchitecture") + ":" + code];
            return new XElement(ns + "Parameter", new XAttribute("schemaVersion", "2.1"), new XAttribute("parameterCode", code), new XElement(Pv + "Value", Value(definition, value)));
        }

        /// <summary>A value (Value 1.0) as its parameter definition says: a scalar with the unit of its description, a boolean or a string.</summary>
        public static XElement Value(JsonNode? definition, string value) => definition.S("kind") switch
        {
            "int" or "decimal" or "float" or "number" => new XElement(Val + "Scalar", new XAttribute("unit", Unit(definition.S("description"))), value),
            "bool" or "boolean" => new XElement(Val + "Boolean", value is "1" or "true" ? "true" : "false"),
            _ => new XElement(Val + "String", value),
        };

        /// <summary>The text of a Value 1.0 element, as the catalog stores values: "true" and "false" for booleans.</summary>
        public static string Text(XElement? value)
        {
            var typed = value?.Elements().FirstOrDefault();
            return typed?.Name.LocalName switch
            {
                "Boolean" => typed.Value.Trim() is "1" or "true" ? "1" : "0",
                "Enum" => ListenerXml.Text(typed, "Value") ?? "",
                _ => typed?.Value.Trim() ?? "",
            };
        }

        private static XElement Tea2Parameter(XNamespace ns, JsonObject parameter) =>
            new(ns + "Parameter", new XAttribute("parameterCode", parameter.S("code")),
                new XElement(ListenerXml.Products + "TEA2Value", Limit(parameter.A("references").Objects().FirstOrDefault().S("value"), 40)));

        private static XElement Variant(XNamespace ns, JsonObject variant) =>
            new(ns + "Variant", new XAttribute("familyID", variant.S("familyId")), new XAttribute("variantID", variant.S("variantId")), new XAttribute("schemaVersion", "1.3"));

        private static XElement SNote(XNamespace ns, string id) => new(ns + "SNote", new XAttribute("sNoteID", Limit(id, 8)), new XAttribute("schemaVersion", "1.4"));

        private static Dictionary<string, JsonObject> Variants(ProductDocument p) =>
            p.Data["productSpecification"].A("variants").Objects().Where(v => v.S("familyId").Length > 0).GroupBy(v => v.S("familyId") + "|" + v.S("variantId"), StringComparer.Ordinal).ToDictionary(g => g.Key, g => g.First(), StringComparer.Ordinal);

        private static Dictionary<string, JsonObject> Parameters(ProductDocument p) =>
            p.Parameters.Objects().Where(x => ParameterCode().IsMatch(x.S("code"))).GroupBy(x => x.S("electricalArchitecture") + ":" + x.S("code"), StringComparer.Ordinal).ToDictionary(g => g.Key, g => g.First(), StringComparer.Ordinal);

        private static HashSet<string> SNotes(ProductDocument p) =>
            p.Data["productSpecification"].A("sNotes").Objects().Select(n => n.S("value")).Where(v => v.Length >= 2).ToHashSet(StringComparer.Ordinal);

        private static string Unit(string description)
        {
            var m = UnitInDescription().Match(description);
            return m.Success ? m.Groups[1].Value : string.Empty;
        }

        private static string Limit(string text, int length) => text.Length <= length ? text : text[..length];

        [GeneratedRegex(@"^[A-Z0-9]{2,5}$")]
        private static partial Regex ParameterCode();

        [GeneratedRegex(@"\(([^)]+)\)\s*$")]
        private static partial Regex UnitInDescription();
    }
}
