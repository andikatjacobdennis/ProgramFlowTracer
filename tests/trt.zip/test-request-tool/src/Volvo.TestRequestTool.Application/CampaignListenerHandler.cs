using System.Globalization;
using System.Text.Json.Nodes;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// ESW_CAMPAIGN_REQUEST 1.0 and ESW_CAMPAIGN_REFRESH_REQUEST 1.0 (Request.Listener/Aftermarket/CampaignRequest and
    /// CampaignRefreshRequest). A campaign request is a KitRequest 1.1: the kit applied by the tool's ConversionKitHandler. A
    /// refresh is a SoftwareRequest 1.6: the operation on the requested nodes by the tool's SoftwareHandler. Both answer a
    /// CampaignResult 1.0: the nodes that change (with a new hardware part number or node template document when those
    /// change) and the result code, the most severe of NodeModifications, ParameterModificationsOnly,
    /// NoSoftwareModifications and NoModifications. Any error, a request that fails its checks included, is a CampaignResult
    /// with resultCode Error and the message; the listener keeps the error code for its audit only.
    /// </summary>
    public sealed class CampaignListenerHandler : ListenerXmlHandler
    {
        private static readonly XNamespace Ns = "http://esw.volvo.com/campaignresult/1_0";
        private static readonly XNamespace SoftwareRequest16 = "http://esw.volvo.com/softwarerequest/1_6";
        private readonly ListenerProducts _products;
        private readonly ListenerCatalog _catalog;
        private readonly ConversionKitHandler _kits;
        private readonly SoftwareHandler _software;

        public CampaignListenerHandler(ListenerProducts products, ListenerCatalog catalog, TimeProvider clock) : base(clock)
        {
            _products = products;
            _catalog = catalog;
            _kits = new ConversionKitHandler(catalog.Catalog);
            _software = new SoftwareHandler(catalog.Catalog, clock);
        }

        public override IReadOnlyCollection<string> Keys { get; } = ["ESW_CAMPAIGN_REQUEST_1.0", "ESW_CAMPAIGN_REFRESH_REQUEST_1.0"];

        protected override async Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct)
        {
            var started = Clock.GetUtcNow();
            var root = message.Xml!.Root!;
            var refresh = message.Type.Key == "ESW_CAMPAIGN_REFRESH_REQUEST_1.0";
            var product = await _products.ReadAsync(ListenerXml.Child(root, "Product")!, message.Actor, ct);
            HandlerResult result;
            if (refresh)
            {
                var requested = ListenerXml.Children(ListenerXml.Child(root, "RequestedNodes"), "Node");
                result = await _software.HandleAsync(product.Product, SoftwareRequestListenerHandler.Payload(root, SoftwareRequestListenerHandler.Operation(ListenerXml.Attribute(root, "operation")), product.Product, requested), ct);
            }
            else
            {
                var payload = new JsonObject
                {
                    ["conversionKitNumbers"] = new JsonArray(new JsonObject { ["conversionKitNumber"] = ListenerXml.Attribute(root, "kitPartNumber") }),
                    ["scenario"] = ListenerCatalog.Scenario(ListenerXml.Attribute(root, "scenario")),
                    ["onlyServiceKitAllowed"] = ListenerXml.Flag(ListenerXml.Attribute(root, "allowServiceKitsOnly")),
                };
                result = await _kits.HandleAsync(product.Product, payload, ct);
            }

            if (ProductsUpdateWriter.Fault(result.Issues) is { } fault)
            {
                throw fault;
            }

            var before = product.Product.Nodes.Objects().ToDictionary(JsonAccess.NodeKeyOf, StringComparer.Ordinal);
            var nodes = new List<XElement>();
            foreach (var node in result.Proposal.Nodes.Objects())
            {
                before.TryGetValue(JsonAccess.NodeKeyOf(node), out var old);
                if (old is not null && JsonNode.DeepEquals(old, node))
                {
                    continue;
                }

                var hardware = node["ecuHardware"].I("number");
                var document = node["nodeTemplateDocument"].I("number");
                nodes.Add(new XElement(Ns + "Node",
                    new XElement(Ns + "Name", Name(node)),
                    old is not null && old["ecuHardware"].I("number") != hardware && hardware > 0 ? new XElement(Ns + "NewHardwarePartNumber", ListenerXml.PartNumber(hardware)) : null,
                    old is not null && old["nodeTemplateDocument"].I("number") != document && document > 0 ? new XElement(Ns + "NewNodeTemplateDocumentNumber", ListenerXml.PartNumber(document)) : null));
            }

            var parameters = !JsonNode.DeepEquals(product.Product.Parameters, result.Proposal.Parameters);
            var specification = !JsonNode.DeepEquals(product.Product.Data["productSpecification"]?["variants"], result.Proposal.Data["productSpecification"]?["variants"])
                || !JsonNode.DeepEquals(product.Product.Data["productSpecification"]?["sNotes"], result.Proposal.Data["productSpecification"]?["sNotes"]);
            var code = nodes.Count > 0 ? "NodeModifications" : parameters ? "ParameterModificationsOnly" : specification ? "NoSoftwareModifications" : "NoModifications";
            var reply = Result(ListenerXml.Attribute(root, "transactionId") ?? "", started, "Ok", code, nodes);
            var summary = new List<ListenerFact>
            {
                new("Outcome", code + "."),
                product.Source,
                new(product.Shown, ProductsUpdateWriter.Describe(product.Product, result.Proposal)),
            };
            return new ListenerAnswer(reply, summary, []);
        }

        protected override XElement Error(ListenerMessage message, ListenerNotice notice, string bodId) =>
            Result(bodId.Length == 0 ? "" : ListenerXml.Attribute(message.Xml?.Root, "transactionId") ?? "", Clock.GetUtcNow(), notice.Text, "Error", []);

        public override XDocument Example(ListenerMessageType type, ProductDocument vehicle)
        {
            if (type.Key == "ESW_CAMPAIGN_REQUEST_1.0")
            {
                var kit = _catalog.Kits.FirstOrDefault(k => k.B("isCampaignKit") && k.A("productClasses").Any(c => c?.ToString() == vehicle.Info.S("productClassId")))?.I("partNumber")
                    ?? KitEvaluationHandler.ExampleKit(_catalog, vehicle).First();
                return Document(AssignedNodesInKitHandler.KitRequest(kit, vehicle));
            }

            return Document(new XElement(SoftwareRequest16 + "SoftwareRequest",
                new XAttribute("operation", "Refresh"),
                new XAttribute("scenario", "Introduced"),
                new XAttribute("transactionId", Guid.NewGuid().ToString()),
                new XAttribute("schemaVersion", "1.6"),
                new XAttribute("pblUpdateCapable", "true"),
                ListenerProducts.ProductElement(SoftwareRequest16, "Product", vehicle),
                new XElement(SoftwareRequest16 + "RequestedNodes", vehicle.Nodes.Objects().Take(2).Select(n => new XElement(SoftwareRequest16 + "Node", ListenerCatalog.NodeId(SoftwareRequest16, n))))));
        }

        /// <summary>The listener's campaign node names: "family.type.position" for TEA2+, "Mid: n" for TEA2.</summary>
        private static string Name(JsonObject node)
        {
            var id = node["nodeIdentifier"];
            return id.I("family") > 0 ? $"{id.I("family")}.{id.I("type")}.{id.I("position")}" : $"Mid: {id.I("mid")}";
        }

        private XElement Result(string transaction, DateTimeOffset started, string message, string code, IEnumerable<XElement> nodes) =>
            new(Ns + "CampaignResult",
                new XAttribute("schemaVersion", "1.0"),
                new XAttribute("transactionId", transaction),
                new XAttribute("startedDateTime", started.UtcDateTime.ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture)),
                new XAttribute("endedDateTime", Clock.GetUtcNow().UtcDateTime.ToString("yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture)),
                new XAttribute("resultMessage", message),
                new XAttribute("resultCode", code),
                new XElement(Ns + "Nodes", nodes));
    }
}
