namespace Volvo.TestRequestTool.Application
{
    /// <summary>What the caller asks to include as context: kind (vehicle, proposal, request, activity) and an id.</summary>
    public sealed record ContextRef(string Kind, string? Id);
}
