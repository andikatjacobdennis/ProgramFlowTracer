using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>Add validators through DI. Names must be unique and order controls deterministic execution.</summary>
    public interface IProductValidator
    {
        string Name { get; }
        int Order { get; }
        ValueTask<IReadOnlyList<ValidationIssue>> ValidateAsync(ValidationContext context, CancellationToken ct);
    }
}
