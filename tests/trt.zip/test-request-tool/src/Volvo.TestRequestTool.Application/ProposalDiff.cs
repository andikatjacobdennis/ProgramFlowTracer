using System.Text.Json.Nodes;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// What exactly changes between an original and a proposed vehicle, one row per component property: node template versions
    /// and ECU hardware, legacy parts (main software, bootloaders, complementary software, sub-hardware, data sets and patches),
    /// each software product (package version, execution environment, part number, logical ECU), parameters,
    /// variants and the service pack or baseline. Used by Change impact, Review proposal and Submit.
    /// </summary>
    public static class ProposalDiff
    {
        public sealed record Row(string ModuleKey, string Component, string Property, string From, string To, string Kind);

        private static readonly (string Key, string Label)[] SoftwareProps =
            [("packageVersion", "Package version"), ("executionEnvironment", "Execution environment"), ("number", "Part number"), ("logicalEcu", "Logical ECU")];

        public static string Short(JsonObject node) => node["nodeIdentifier"].S("name", node.S("name"));
        public static string SoftwareName(JsonObject sw) => sw.S("name", sw.S("softwareProduct"));

        /// <summary>
        /// Legacy (TEA2, TEA2+) parts of one node, by part number: main software, primary and secondary bootloader,
        /// complementary software and sub-hardware (by name), data sets (by index) and their patches (by position).
        /// </summary>
        private static void LegacyParts(List<Row> rows, string key, string name, JsonObject old, JsonObject node)
        {
            void One(string component, JsonObject? o, JsonObject? n)
            {
                if (o is null && n is null)
                {
                    return;
                }

                if (o is null)
                {
                    rows.Add(new(key, component, "Part number", "", n!.S("number"), "added"));
                }
                else if (n is null)
                {
                    rows.Add(new(key, component, "Part number", o.S("number"), "", "removed"));
                }
                else if (o.S("number") != n.S("number"))
                {
                    rows.Add(new(key, component, "Part number", o.S("number"), n.S("number"), "modified"));
                }
            }
            void Many(string label, JsonArray olds, JsonArray news, Func<JsonObject, string> by, Action<string, JsonObject?, JsonObject?>? inner = null)
            {
                var o = olds.Objects().ToList();
                var n = news.Objects().ToList();
                foreach (var k in o.Select(by).Concat(n.Select(by)).Distinct(StringComparer.Ordinal))
                {
                    var a = o.FirstOrDefault(x => by(x) == k);
                    var b = n.FirstOrDefault(x => by(x) == k);
                    var component = $"{name} {label} {(b ?? a)!.S("name", k)}";
                    One(component, a, b);
                    inner?.Invoke(component, a, b);
                }
            }
            foreach (var (slot, label) in new[] { ("mainSoftware", "Main software"), ("primaryBootloader", "Primary bootloader"), ("secondaryBootloader", "Secondary bootloader") })
            {
                One($"{name} {label}", old[slot] as JsonObject, node[slot] as JsonObject);
            }

            Many("Complementary software", old.A("complementarySoftwares"), node.A("complementarySoftwares"), x => x.S("name"));
            Many("Sub-hardware", old.A("subHardwares"), node.A("subHardwares"), x => x.S("name"));
            Many("Data set", old.A("datas"), node.A("datas"), x => x.S("index", x.S("name")), (component, a, b) =>
            {
                var po = a?.A("patches").Objects().ToList() ?? [];
                var pn = b?.A("patches").Objects().ToList() ?? [];
                for (var i = 0; i < Math.Max(po.Count, pn.Count); i++)
                {
                    One($"{component} {(i < pn.Count ? pn[i] : po[i]).S("name", "Patch " + (i + 1))}", i < po.Count ? po[i] : null, i < pn.Count ? pn[i] : null);
                }
            });
        }

        public static IReadOnlyList<Row> Rows(JsonObject original, JsonObject proposal)
        {
            var rows = new List<Row>();
            var before = original.A("nodes").Objects().ToDictionary(JsonAccess.NodeKeyOf, StringComparer.Ordinal);
            var after = proposal.A("nodes").Objects().ToDictionary(JsonAccess.NodeKeyOf, StringComparer.Ordinal);
            foreach (var (key, node) in after)
            {
                var name = Short(node);
                if (!before.TryGetValue(key, out var old))
                {
                    rows.Add(new(key, name, "Node", "", node.S("versionName"), "added"));
                    continue;
                }
                if (old.S("versionName") != node.S("versionName"))
                {
                    rows.Add(new(key, name, "Node template version", old.S("versionName"), node.S("versionName"), "modified"));
                }

                if (old["ecuHardware"].S("number") != node["ecuHardware"].S("number"))
                {
                    rows.Add(new(key, name, "ECU hardware", old["ecuHardware"].S("number"), node["ecuHardware"].S("number"), "modified"));
                }

                LegacyParts(rows, key, name, old, node);
                var oldSw = old.A("softwareProducts").Objects().GroupBy(SoftwareName).ToDictionary(g => g.Key, g => g.First(), StringComparer.Ordinal);
                foreach (var sw in node.A("softwareProducts").Objects())
                {
                    var component = name + " " + SoftwareName(sw);
                    if (!oldSw.TryGetValue(SoftwareName(sw), out var prev))
                    {
                        rows.Add(new(key, component, "Software product", "", sw.S("packageVersion", sw.S("number")), "added"));
                        continue;
                    }
                    foreach (var (p, label) in SoftwareProps)
                    {
                        if (prev.S(p) != sw.S(p) && (prev[p] is not null || sw[p] is not null))
                        {
                            rows.Add(new(key, component, label, prev.S(p), sw.S(p), "modified"));
                        }
                    }
                }
                foreach (var gone in oldSw.Keys.Except(node.A("softwareProducts").Objects().Select(SoftwareName)))
                {
                    rows.Add(new(key, name + " " + gone, "Software product", oldSw[gone].S("packageVersion", oldSw[gone].S("number")), "", "removed"));
                }
            }
            foreach (var (key, node) in before.Where(kv => !after.ContainsKey(kv.Key)))
            {
                rows.Add(new(key, Short(node), "Node", node.S("versionName"), "", "removed"));
            }

            static string P(JsonObject p) => p.S("electricalArchitecture") + ":" + p.S("code");
            static string V(JsonObject p) => string.Join(", ", p.A("references").Select(r => r is JsonObject o ? o.S("value", o.ToJsonString()) : r?.ToString()));
            var oldParams = original.A("parameters").Objects().GroupBy(P).ToDictionary(g => g.Key, g => g.First(), StringComparer.Ordinal);
            foreach (var p in proposal.A("parameters").Objects())
            {
                if (!oldParams.TryGetValue(P(p), out var prev))
                {
                    rows.Add(new("", "Parameter " + p.S("code"), "Value", "", V(p), "added"));
                }
                else if (!JsonNode.DeepEquals(prev, p))
                {
                    rows.Add(new("", "Parameter " + p.S("code"), "Value", V(prev), V(p), "modified"));
                }
            }
            foreach (var gone in oldParams.Keys.Except(proposal.A("parameters").Objects().Select(P)))
            {
                rows.Add(new("", "Parameter " + oldParams[gone].S("code"), "Value", V(oldParams[gone]), "", "removed"));
            }

            static string Vr(JsonObject v) => v.S("idVar6", v.S("symbol"));
            var bs = original["productSpecification"];
            var ps = proposal["productSpecification"];
            var oldVar = bs.A("variants").Objects().Select(Vr).ToHashSet(StringComparer.Ordinal);
            var newVar = ps.A("variants").Objects().Select(Vr).ToHashSet(StringComparer.Ordinal);
            foreach (var v in newVar.Except(oldVar))
            {
                rows.Add(new("", "Variant", "Variant", "", v, "added"));
            }

            foreach (var v in oldVar.Except(newVar))
            {
                rows.Add(new("", "Variant", "Variant", v, "", "removed"));
            }

            foreach (var (k, label) in new[] { ("servicePackName", "Service pack"), ("baselineName", "Baseline") })
            {
                if (bs?["productInformation"].S(k) != ps?["productInformation"].S(k))
                {
                    rows.Add(new("", "Vehicle", label, bs?["productInformation"].S(k) ?? "", ps?["productInformation"].S(k) ?? "", "modified"));
                }
            }

            return rows;
        }

        public static JsonArray ToJson(IEnumerable<Row> rows) => new(rows.Select(r => (JsonNode)new JsonObject
        { ["moduleKey"] = r.ModuleKey, ["component"] = r.Component, ["property"] = r.Property, ["from"] = r.From, ["to"] = r.To, ["kind"] = r.Kind }).ToArray());

        /// <summary>Which readiness column a validation finding belongs to.</summary>
        public static string Category(string code) => code switch
        {
            "hardware_incompatible" or "incompatible_hardware_or_pbl" => "hardware",
            "dependency_unsatisfied" => "dependencies",
            _ when code.StartsWith("parameter_", StringComparison.Ordinal) || code.StartsWith("variant_", StringComparison.Ordinal) || code == "duplicate_parameter" => "parameters",
            _ => "software",
        };

        public static string Title(JsonObject product)
        {
            var info = product["productSpecification"]?["productInformation"];
            return info.S("chassisSeries") + " " + info.S("chassisNumber");
        }

        public static string Architecture(JsonObject product) =>
            product["productSpecification"]?["productInformation"].I("electricalArchitecture", 0) == 3 || product.A("nodes").Objects().Any(n => n.I("electricalArchitecture") == 3) ? "T3" : "Legacy";
    }
}
