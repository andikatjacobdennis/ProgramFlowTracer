using System.Text.Json.Nodes;
using System.Xml.Linq;
using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// GetBOMConsistencyCheck 1.4, 1.7, 2.0 and 2.1 (Request.Listener/Production/ConsistencyCheck_*). The bill of material in
    /// the request is compared with the breakdown of the product for the requested version, and returned with notifications
    /// where they differ, as the listener does: it answers the request's own bill of material, not a new one. Per requested
    /// node: a node the breakdown does not have, another node template document, ECU hardware the node template does not
    /// take, and software parts other than the node template's. Nodes of the breakdown missing from the bill of material
    /// are reported on the reply. Nodes that are not requested are returned unchecked. The notification types are the
    /// tool's own words where the listener's exact ones are not known.
    /// </summary>
    public sealed class ConsistencyCheckHandler : BreakdownListenerHandler
    {
        private readonly ListenerBreakdowns _breakdowns;

        public ConsistencyCheckHandler(ListenerBreakdowns breakdowns, TimeProvider clock) : base(clock)
        {
            _breakdowns = breakdowns;
        }

        public override IReadOnlyCollection<string> Keys { get; } = ["GetBOMConsistencyCheck_1.4", "GetBOMConsistencyCheck_1.7", "GetBOMConsistencyCheck_2.0", "GetBOMConsistencyCheck_2.1"];

        protected override string Kind => "consistency check";

        protected override string Component => "ConsistencyCheckModule";

        protected override string ReplyRoot(ListenerMessageType type) => "ConsistencyCheckResponse";

        protected override XNamespace ReplyNs(ListenerMessageType type) => "http://esw.volvo.com/consistencycheckresponse/" + type.Version.Replace('.', '_');

        private static XNamespace RequestNs(ListenerMessageType type) => "http://esw.volvo.com/consistencycheckrequest/" + type.Version.Replace('.', '_');

        protected override async Task<ListenerAnswer> AnswerAsync(ListenerMessage message, CancellationToken ct)
        {
            var data = Data(message);
            var bmc = Bmc(message.Type);
            var ns = ReplyNs(message.Type);
            var result = await _breakdowns.BreakDownAsync(data, message.Actor, development: false, ct);
            var given = ListenerXml.Child(data, "SoftwareBillOfMaterial") ?? throw ListenerFault.InvalidMessage("The request has no SoftwareBillOfMaterial.");
            var bom = new XElement(ns + "SoftwareBillOfMaterial", given.Elements().Select(e => new XElement(e)));
            var root = new List<BreakdownNotice>(result.Notices);
            var checkedNodes = 0;
            var problems = 0;
            var requested = ListenerXml.Child(data, "RequestedNodes");
            var all = requested is null || ListenerXml.Child(requested, "AllNodes") is not null;
            var wanted = all ? [] : ListenerXml.Children(requested, "Node").ToList();
            var expected = result.Product?.Nodes.Objects().ToList() ?? [];
            var seen = new HashSet<string>(StringComparer.Ordinal);
            foreach (var node in ListenerXml.Children(ListenerXml.Child(bom, "Nodes"), "Node"))
            {
                var identification = ListenerXml.Child(node, "NodeIdentification");
                if (!all && !wanted.Any(w => SameNode(w, identification)))
                {
                    continue;
                }

                checkedNodes++;
                StripChecks(node);
                var match = expected.FirstOrDefault(n => ListenerCatalog.Matches(Flat(identification), n));
                var notices = match is null ? [new BreakdownNotice("Warning", "NODE NOT IN BREAKDOWN", $"Node {Describe(identification)} is not in the breakdown of the product.", "The node is not part of the configuration for the requested version.", "Remove the node or check the product specification.")] : Compare(node, match);
                if (match is not null)
                {
                    seen.Add(JsonAccess.NodeKeyOf(match));
                }

                problems += notices.Count(n => n.Severity != "Information");
                AddNotifications(bmc, node, notices);
            }

            if (result.Product is not null)
            {
                foreach (var missing in expected.Where(n => !seen.Contains(JsonAccess.NodeKeyOf(n)) && (all || wanted.Any(w => ListenerCatalog.Matches(w, n))) && (!IsBod(message.Type) || n.I("electricalArchitecture") != 3)))
                {
                    root.Add(new BreakdownNotice("Warning", "NODE MISSING", $"Node {missing.S("name")} of the breakdown is not in the bill of material.", "The breakdown has a node the bill of material does not.", "Add the node."));
                    problems++;
                }
            }

            var reply = Reply(message, Transaction(message), bom, bmc.Notifications(ns + "Notifications", root));
            var summary = new List<ListenerFact>
            {
                new("Outcome", problems == 0 && root.All(n => n.Severity == "Information") ? $"Consistent: {checkedNodes} node(s) checked." : $"{problems} inconsistenc{(problems == 1 ? "y" : "ies")} in {checkedNodes} checked node(s)."),
            };
            if (ListenerXml.Children(ListenerXml.Child(bom, "HpcNodes"), "HpcNode").Any())
            {
                summary.Add(new ListenerFact("HPC nodes", "Returned as the request gives them, as the listener does: they are not checked."));
            }

            summary.AddRange(Version21(message.Type));
            summary.AddRange(Facts(root));
            return new ListenerAnswer(reply, summary, []);
        }

        /// <summary>A request for the vehicle: its current nodes as the bill of material, against its context's newest baseline.</summary>
        public override XDocument Example(ListenerMessageType type, ProductDocument vehicle)
        {
            var ns = RequestNs(type);
            var xml = Bmc(type);
            var baseline = _breakdowns.NewestBaseline(vehicle);
            var content = new object[]
            {
                new XElement(ns + "RequestedNodes", new XElement(xml.Ns + "AllNodes")),
                new XElement(ns + "RequestedVersion", new XElement(xml.Ns + "Baseline", "{" + baseline?.S("guid").ToUpperInvariant() + "}")),
                ListenerBreakdowns.Specification(ns + "ProductSpecification", xml.Ns, vehicle),
                xml.Bom(ns + "SoftwareBillOfMaterial", vehicle, baseline?.S("guid") ?? ""),
            };
            return Document(IsBod(type)
                ? new XElement(ns + "ConsistencyCheckRequest", ListenerXml.RequestArea(Clock), new XElement(ns + "DataArea", new XAttribute("schemaVersion", type.Version), content))
                : new XElement(ns + "ConsistencyCheckRequest", new XAttribute("transactionId", Guid.NewGuid().ToString()), new XAttribute("schemaVersion", type.Version), content));
        }

        /// <summary>What differs between a node of the bill of material and the node of the breakdown.</summary>
        private List<BreakdownNotice> Compare(XElement node, JsonObject expected)
        {
            var notices = new List<BreakdownNotice>();
            var name = expected.S("name");
            var document = ListenerXml.Number(ListenerXml.Text(ListenerXml.Child(node, "NodeVersion"), "DocumentNumber"));
            var want = expected["nodeTemplateDocument"].I("number");
            if (document != want)
            {
                notices.Add(new("Error", "NODE TEMPLATE NOT OK", $"Node {name} has node template {document?.ToString(System.Globalization.CultureInfo.InvariantCulture) ?? "none"}; the breakdown gives {want}.", "The node template is not the one of the requested version.", "Perform a new breakdown."));
            }

            var version = _breakdowns.Catalog.FindVersion(expected);
            var hardware = ListenerXml.Number(ListenerXml.Text(ListenerXml.Child(ListenerXml.Child(ListenerXml.Child(node, "HardwareSlot"), "Filled"), "Item"), "ItemNumber"));
            if (hardware is not null && version is not null && !version.A("hardware").Any(h => h?.ToString() == hardware.Value.ToString(System.Globalization.CultureInfo.InvariantCulture)))
            {
                notices.Add(new("Error", "ECU HARDWARE INCOMPATIBLE", $"ECU hardware {hardware} is not compatible with node template {want}.", "The node template does not take this hardware.", "Replace the hardware or choose another node template."));
            }

            var parts = ListenerXml.All(ListenerXml.Child(node, "SoftwareSlots"), "ItemNumber").Concat(ListenerXml.All(ListenerXml.Child(node, "DataSlots"), "ItemNumber"))
                .Where(e => e.Parent?.Name.LocalName == "Item").Select(e => ListenerXml.Number(e.Value.Trim()) ?? 0).ToHashSet();
            var wanted = SoftwareParts(expected);
            var missing = wanted.Where(p => !parts.Contains(p)).ToList();
            var extra = parts.Where(p => !wanted.Contains(p)).ToList();
            if (missing.Count > 0 || extra.Count > 0)
            {
                notices.Add(new("Error", "SOFTWARE PART NOT OK", $"Node {name}: {(missing.Count > 0 ? "missing " + string.Join(", ", missing.Select(m => ListenerXml.PartNumber(m))) : "")}{(missing.Count > 0 && extra.Count > 0 ? "; " : "")}{(extra.Count > 0 ? "not in the node template " + string.Join(", ", extra.Select(m => ListenerXml.PartNumber(m))) : "")}.",
                    "The software parts are not those of the node template.", "Perform a new breakdown."));
            }

            return notices;
        }

        private static HashSet<int> SoftwareParts(JsonObject node)
        {
            var parts = new[] { "primaryBootloader", "secondaryBootloader", "mainSoftware", "downloader", "dataSet1", "dataSet2" }.Select(k => node[k].I("number"))
                .Concat(new[] { "softwareProducts", "softwareFunctions", "subSoftwares", "complementarySoftwares", "datas", "subDataSets" }.SelectMany(k => node.A(k).Objects().Select(p => p.I("number"))));
            return parts.Where(p => p > 0).ToHashSet();
        }

        /// <summary>Warnings and errors already in a requested node are dropped before the check, as the listener does.</summary>
        private static void StripChecks(XElement node)
        {
            var list = ListenerXml.Child(node, "Notifications");
            foreach (var n in ListenerXml.Children(list, "Notification").Where(n => ListenerXml.Text(n, "Severity") is "Error" or "Warning").ToList())
            {
                n.Remove();
            }

            if (list is not null && !list.HasElements)
            {
                list.Remove();
            }
        }

        /// <summary>Adds notifications to a node, in their place: before the first hardware slot.</summary>
        private static void AddNotifications(BreakdownXml bmc, XElement node, List<BreakdownNotice> notices)
        {
            if (notices.Count == 0)
            {
                return;
            }

            var list = ListenerXml.Child(node, "Notifications");
            if (list is null)
            {
                list = new XElement(bmc.Ns + "Notifications");
                var slot = ListenerXml.Child(node, "HardwareSlot");
                if (slot is null)
                {
                    node.Add(list);
                }
                else
                {
                    slot.AddBeforeSelf(list);
                }
            }

            list.Add(notices.Select(bmc.Notification));
        }

        /// <summary>A bmc NodeIdentification as the catalog matcher reads node names: NodeName with nodeFamily attributes.</summary>
        private static XElement Flat(XElement? identification)
        {
            var name = ListenerXml.Child(identification, "NodeName");
            return name is null
                ? new XElement("Node", new XElement("MID", ListenerXml.Text(identification, "MID")))
                : new XElement("Node", new XElement("NodeName",
                    new XAttribute("nodeFamily", ListenerXml.Text(name, "NodeFamily") ?? "0"),
                    new XAttribute("nodeType", ListenerXml.Text(name, "NodeType") ?? "0"),
                    new XAttribute("nodePosition", ListenerXml.Text(name, "NodePosition") ?? "0")));
        }

        private static bool SameNode(XElement requested, XElement? identification)
        {
            var a = Flat(requested);
            var b = Flat(identification);
            return XNode.DeepEquals(a, b) || (ListenerXml.Find(a, "NodeName") is { } x && ListenerXml.Find(b, "NodeName") is { } y
                && x.Attribute("nodeFamily")?.Value == y.Attribute("nodeFamily")?.Value && x.Attribute("nodeType")?.Value == y.Attribute("nodeType")?.Value
                && (x.Attribute("nodePosition")?.Value is "0" || y.Attribute("nodePosition")?.Value is "0" || x.Attribute("nodePosition")?.Value == y.Attribute("nodePosition")?.Value));
        }

        private static string Describe(XElement? identification)
        {
            var name = ListenerXml.Child(identification, "NodeName");
            return name is null ? "MID " + ListenerXml.Text(identification, "MID") : $"{ListenerXml.Text(name, "NodeFamily")}.{ListenerXml.Text(name, "NodeType")}.{ListenerXml.Text(name, "NodePosition") ?? "0"}";
        }
    }
}
