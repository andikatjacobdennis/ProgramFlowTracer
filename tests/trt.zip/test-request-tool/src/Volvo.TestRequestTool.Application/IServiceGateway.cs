namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// The service layer: every call to an external service goes through here. The transport per service comes from settings
    /// (Services:Endpoints): files under Services:Path now, HTTP later, without changing callers.
    /// </summary>
    public interface IServiceGateway
    {
        /// <summary>The answer. Throws RequestFault 404 when the service has no such item, 503 when it cannot be reached or is off.</summary>
        Task<ServiceReply> CallAsync(ServiceCall call, CancellationToken ct);
        /// <summary>Whether the service has a transport set up (not "Off").</summary>
        bool IsConfigured(string service);
    }
}
