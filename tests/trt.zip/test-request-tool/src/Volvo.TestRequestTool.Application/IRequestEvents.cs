using Volvo.TestRequestTool.Domain;

namespace Volvo.TestRequestTool.Application
{
    /// <summary>
    /// Receives each finished request so its stages can be written as structured diagnostic events (Logs page). The Web
    /// layer implements it; it must never record payload content.
    /// </summary>
    public interface IRequestEvents
    {
        void Executed(ExecutionRecord record, string via);
    }
}
