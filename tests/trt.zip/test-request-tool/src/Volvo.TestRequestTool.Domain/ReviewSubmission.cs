namespace Volvo.TestRequestTool.Domain
{
    /// <summary>
    /// The receipt of a submitted review: its id (SUB-…), who, when, the target, the committed revision of each vehicle and
    /// the timed steps (accepted, target revision checked, snapshot committed) for the audit trail on the outcome page.
    /// </summary>
    public sealed record ReviewSubmission(string Id, string ActorId, string ActorName, DateTimeOffset At, string Target, IReadOnlyList<SubmittedVehicle> Vehicles, IReadOnlyList<SubmissionStep> Steps);
}
