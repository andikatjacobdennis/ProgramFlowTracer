namespace Volvo.TestRequestTool.Domain
{
    /// <summary>The user a job runs as, captured when the job was created (contexts as a plain array so it serialises).</summary>
    public sealed record JobActor(string Id, int[] Contexts, bool CanWrite, string? Name)
    {
        public static JobActor From(Actor a) => new(a.Id, a.Contexts.Order().ToArray(), a.CanWrite, a.Name);
        public Actor ToActor() => new(Id, Contexts.ToHashSet(), CanWrite, Name);
    }
}
