namespace Volvo.TestRequestTool.Domain
{
    /// <summary>A batch run that validated some vehicles of one campaign revision.</summary>
    public sealed record CampaignValidation(int Revision, Guid BatchId, IReadOnlyList<string> VehicleIds, DateTimeOffset At, string ActorId);
}
