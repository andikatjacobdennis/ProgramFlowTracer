namespace Volvo.TestRequestTool.Domain
{
    public sealed record JobAttempt(int Number, DateTimeOffset StartedAt, DateTimeOffset? FinishedAt, string Status, string? ErrorCode, string? Error);
}
