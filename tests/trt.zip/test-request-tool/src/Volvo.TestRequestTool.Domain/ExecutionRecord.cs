using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    public sealed record ExecutionRecord(Guid Id, string ActorId, RequestKind Kind, DateTimeOffset CreatedAt,
        string InputHash, IReadOnlyList<Outcome> Outcomes, JsonObject? AvailableUpdates = null, JsonObject? ServiceResponses = null,
        ExecutionTrace? Trace = null, JsonObject? Options = null);
}
