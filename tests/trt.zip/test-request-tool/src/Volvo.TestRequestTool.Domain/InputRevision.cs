namespace Volvo.TestRequestTool.Domain
{
    /// <summary>One vehicle as it was when validated: the stored revision it was based on and the fingerprint of the proposal.</summary>
    public sealed record InputRevision(string VehicleId, long BaseRevision, string ProposalHash);
}
