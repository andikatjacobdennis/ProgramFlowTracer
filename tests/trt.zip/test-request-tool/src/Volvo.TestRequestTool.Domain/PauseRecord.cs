namespace Volvo.TestRequestTool.Domain
{
    /// <summary>An operator's pause of new submissions or consequential writes (FR-76). Scope: submissions, writes or integration:NAME.</summary>
    public sealed record PauseRecord(string Scope, string Reason, string ActorId, string ActorName, DateTimeOffset At);
}
