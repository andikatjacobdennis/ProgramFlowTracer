namespace Volvo.TestRequestTool.Domain
{
    /// <summary>Who changed a vehicle in VDA and why. Recorded with every committed revision.</summary>
    public sealed record RevisionNote(string ActorId, string ActorName, string Reason, string? Source = null);
}
