using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    /// <summary>Lossless boundary for the existing product contract, including future JSON fields.</summary>
    public sealed class ProductDocument
    {
        public JsonObject Data { get; }

        public ProductDocument(JsonObject data)
        {
            Data = (JsonObject)data.DeepClone();
            if (Data["productSpecification"] is not JsonObject spec || spec["productInformation"] is not JsonObject)
            {
                throw new RequestFault(400, "invalid_product", "Product information is required.");
            }

            if (Data["nodes"] is not JsonArray || Data["parameters"] is not JsonArray)
            {
                throw new RequestFault(400, "invalid_product", "Nodes and parameters must be arrays.");
            }
        }

        public JsonObject Info => (JsonObject)Data["productSpecification"]!["productInformation"]!;
        public JsonArray Nodes => (JsonArray)Data["nodes"]!;
        public JsonArray Parameters => (JsonArray)Data["parameters"]!;
        public string Id => VehicleIdentity.Key(Info.S("chassisSeries"), Info.S("chassisNumber"));
        public int ContextId => Info["context"]?.I("id") ?? 0;
        public ProductDocument Copy() => new(Data);
        public string Fingerprint() => CanonicalJson.Hash(Data);
    }
}
