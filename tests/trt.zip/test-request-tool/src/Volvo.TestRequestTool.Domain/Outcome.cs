using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    public sealed record Outcome(string VehicleId, JsonObject Input, JsonObject Original, JsonObject Proposal,
        long BaseRevision, string ProposalHash, JsonObject Delta, IReadOnlyList<ValidationIssue> Issues, bool LimitedValidation, JsonArray? ReleaseNotes = null)
    {
        public bool IsReady => !LimitedValidation && !Issues.Any(i => i.Severity == 0);
    }
}
