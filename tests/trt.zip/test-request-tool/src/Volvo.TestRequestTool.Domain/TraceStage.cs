namespace Volvo.TestRequestTool.Domain
{
    public sealed record TraceStage(int Order, string Id, string Name, string Kind, double StartMs, double DurationMs, string Outcome, string? VehicleId = null, string? Note = null);
}
