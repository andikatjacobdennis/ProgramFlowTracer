using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    public sealed record Kit(Guid Id, string ActorId, string Name, Guid RequestId, IReadOnlyList<JsonObject> Changes, DateTimeOffset CreatedAt, string? ActorName = null);
}
