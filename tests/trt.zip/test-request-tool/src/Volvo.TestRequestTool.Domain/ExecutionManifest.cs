namespace Volvo.TestRequestTool.Domain
{
    /// <summary>
    /// Everything needed to reproduce a result or explain why two results differ (FR-74): the exact input revisions, the rule
    /// version, a fingerprint of the catalog, the request kind and contract, the input hash, and the software and environment.
    /// </summary>
    public sealed record ExecutionManifest(IReadOnlyList<InputRevision> Inputs, string RuleVersion, string CatalogFingerprint, string RequestKind, string RequestContract,
        string InputHash, string Application, string Runtime, string Environment);
}
