namespace Volvo.TestRequestTool.Domain
{
    /// <summary>
    /// Where a result came from (FR-02): the data source, the mode (simulation, limited validation, connected), the engine,
    /// every external service with whether it was used, and when. Shown next to every result so a simulated or partial result can
    /// never pass for a connected, complete one.
    /// </summary>
    public sealed record Provenance(string Source, string Mode, string Engine, IReadOnlyList<ServiceUse> Services, DateTimeOffset At, string RuleVersion, ExecutionManifest? Manifest = null);
}
