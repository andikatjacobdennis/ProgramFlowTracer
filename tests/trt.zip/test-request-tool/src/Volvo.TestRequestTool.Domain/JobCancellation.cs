namespace Volvo.TestRequestTool.Domain
{
    /// <summary>Whether a job can be cancelled now and what cancelling would mean (FR-78).</summary>
    public sealed record JobCancellation(bool Possible, string Meaning);
}
