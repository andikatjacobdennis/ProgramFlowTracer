namespace Volvo.TestRequestTool.Domain
{
    public sealed class RequestFault : Exception
    {
        public RequestFault(int status, string code, string message) : base(message)
        {
            Status = status;
            Code = code;
        }

        public int Status { get; }
        public string Code { get; }
    }
}
