using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    /// <summary>
    /// The review and approval of one validation result (FR-06, FR-57), then its submission. The author asks for a review;
    /// someone else with the Writer role decides (separation of duties); approval needs the checklist and is valid only for the
    /// exact validation, proposal revision and vehicle revisions in Evidence, so any change afterwards needs a new validation and
    /// a new approval. Submission re-checks all of that on the server and is recorded once (retrying returns the same result).
    /// Status: open, approved, changes_requested, withdrawn, submitted. Version increases with every change (optimistic concurrency).
    /// </summary>
    public sealed record ReviewRecord(Guid Id, Guid RequestId, string AuthorId, string AuthorName, DateTimeOffset CreatedAt, int? ProposalRevision,
        string Status, JsonObject Evidence, IReadOnlyList<ReviewComment> Comments, ReviewDecision? Decision = null, ReviewSubmission? Submission = null, long Version = 1,
        ReviewAssignee? Assignee = null);
}
