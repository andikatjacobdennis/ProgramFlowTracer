using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    public sealed record RequestCommand(RequestKind Kind, JsonObject Payload);
}
