using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    public sealed record VersionedProduct(JsonObject Product, long Revision);
}
