namespace Volvo.TestRequestTool.Domain
{
    /// <summary>Authenticated user. Name is the display name shown in vehicle history; it falls back to Id.</summary>
    public sealed record Actor(string Id, IReadOnlySet<int> Contexts, bool CanWrite, string? Name = null)
    {
        public string DisplayName => string.IsNullOrWhiteSpace(Name) ? Id : Name;

        public void DemandRead(int context)
        {
            if (!Contexts.Contains(context))
            {
                throw new RequestFault(403, "context_denied", "Read access to this vehicle context is required.");
            }
        }

        public void DemandWrite(int context)
        {
            DemandRead(context);
            if (!CanWrite)
            {
                throw new RequestFault(403, "write_denied", "Writer authorization is required.");
            }
        }
    }
}
