namespace Volvo.TestRequestTool.Domain
{
    /// <summary>One vehicle in a batch. Status: waiting, running, ready, limited, blocked, failed, cancelled, skipped.</summary>
    public sealed record BatchItem(string VehicleId, string Status, Guid? JobId = null, Guid? ResultId = null, DateTimeOffset? StartedAt = null, DateTimeOffset? FinishedAt = null,
        double? Seconds = null, int Issues = 0, string? Error = null, int Attempts = 0);
}
