using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    public sealed record Draft(string Id, string ActorId, JsonObject State, long Version, DateTimeOffset UpdatedAt);
}
