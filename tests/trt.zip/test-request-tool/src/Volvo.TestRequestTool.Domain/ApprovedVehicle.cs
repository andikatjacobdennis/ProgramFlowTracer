namespace Volvo.TestRequestTool.Domain
{
    public sealed record ApprovedVehicle(string VehicleId, Guid ResultId, string ResultOwnerId, long BaseRevision);
}
