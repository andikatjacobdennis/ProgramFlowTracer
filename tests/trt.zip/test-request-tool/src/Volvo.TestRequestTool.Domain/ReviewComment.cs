namespace Volvo.TestRequestTool.Domain
{
    /// <summary>One entry in the review discussion. Kind: comment, requested, assigned, approved, changes_requested, withdrawn, submitted.</summary>
    public sealed record ReviewComment(Guid Id, string ActorId, string ActorName, DateTimeOffset At, string Kind, string Text);
}
