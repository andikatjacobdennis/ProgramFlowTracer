namespace Volvo.TestRequestTool.Domain
{
    public sealed record CampaignEvent(DateTimeOffset At, string ActorName, string Text);
}
