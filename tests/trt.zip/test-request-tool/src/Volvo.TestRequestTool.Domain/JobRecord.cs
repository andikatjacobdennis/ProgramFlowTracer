using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    /// <summary>
    /// A tracked, resumable operation (FR-07, FR-34, FR-39). It is stored before it is acknowledged. The same idempotency key
    /// returns the same job, so a repeated submission never runs twice (FR-37). A worker owns a running job only while its lease
    /// lasts; when a worker stops, the lease expires and another worker takes the job over (FR-39). A failed job keeps its
    /// input and can be retried; each retry is a new attempt of the same job, and every attempt writes the same result id, so
    /// a retry never produces a second result. Lane is "interactive" or "batch" (FR-45).
    /// </summary>
    public sealed record JobRecord(Guid Id, JobActor Actor, string Kind, string IdempotencyKey, string InputHash, JsonObject Input, string Status, int Attempt,
        DateTimeOffset CreatedAt, DateTimeOffset? StartedAt = null, DateTimeOffset? FinishedAt = null, Guid? ResultId = null, string? ErrorCode = null,
        string? Error = null, IReadOnlyList<JobAttempt>? Attempts = null, Provenance? Provenance = null, string Lane = "interactive",
        string? LeaseOwner = null, DateTimeOffset? LeaseUntil = null, long Version = 0)
    {
        public bool Finished => Status is "succeeded" or "failed" or "cancelled";

        /// <summary>
        /// FR-78: cancellation is a request until a worker confirms it. "cancelling" means requested; only "cancelled" means
        /// stopped. Simulation jobs change nothing outside the workspace, so there are no external effects to undo.
        /// </summary>
        public JobCancellation Cancellation => Status switch
        {
            "queued" => new(true, "It has not started. Cancelling stops it before anything runs; its input is kept for a retry."),
            "running" => new(true, "It is running. Cancelling asks the worker to stop at its next step; anything already saved stays, and nothing outside the workspace has been changed."),
            "cancelling" => new(false, "Cancellation has been requested. The worker confirms it, or finishes first if the work was nearly done."),
            "succeeded" => new(false, "It has finished; its result stays. Finished jobs cannot be cancelled."),
            _ => new(false, $"It is {Status}. Retry it instead if you need it to run."),
        };

        /// <summary>The result id every attempt of this job writes to (derived from the job id).</summary>
        public Guid ResultIdFor => new(System.Security.Cryptography.SHA256.HashData(Id.ToByteArray())[..16]);

        /// <summary>The allowed status changes (FR-38). Anything else is refused by the store.</summary>
        public static readonly IReadOnlyDictionary<string, string[]> Transitions = new Dictionary<string, string[]>
        {
            ["queued"] = ["running", "cancelled"],
            ["running"] = ["succeeded", "failed", "cancelling", "queued"],   // queued: lease released on shutdown
            ["cancelling"] = ["cancelled", "succeeded", "failed"],
            ["failed"] = ["queued"],
            ["cancelled"] = ["queued"],
            ["succeeded"] = [],
        };

        public static bool CanMove(string from, string to) => Transitions.TryGetValue(from, out var next) && next.Contains(to);
    }
}
