namespace Volvo.TestRequestTool.Domain
{
    public sealed record ReviewDecision(string ActorId, string ActorName, DateTimeOffset At, string Decision, string Note, IReadOnlyList<string> Checklist);
}
