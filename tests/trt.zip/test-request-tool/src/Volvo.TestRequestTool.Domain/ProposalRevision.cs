using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    /// <summary>
    /// One saved version of a proposal (FR-05). Revisions are never changed or deleted; restoring an earlier one adds a new
    /// revision with that content. State is left out of list responses.
    /// </summary>
    public sealed record ProposalRevision(string ProposalId, string OwnerId, int Number, DateTimeOffset At, string ActorId, string ActorName,
        string Reason, string Hash, int? RestoredFrom, JsonObject Summary, JsonObject? State = null)
    {
        public ProposalRevision WithoutState() => this with { State = null };
        /// <summary>SHA-256 of the state, so saving the same content twice does not add a revision.</summary>
        public static string HashOf(JsonObject state) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(state.ToJsonString())))[..32];
    }
}
