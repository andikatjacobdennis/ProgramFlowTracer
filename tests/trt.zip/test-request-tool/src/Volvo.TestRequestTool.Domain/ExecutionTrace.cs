namespace Volvo.TestRequestTool.Domain
{
    /// <summary>
    /// Where the time went in one validation request, measured on the server while it ran (the Request execution page).
    /// Offsets and durations are milliseconds from the moment processing started; queueing is added from the job when the
    /// request ran through the queue. Kind is "stage" or "service" (a call to an integration); Outcome is completed, warning
    /// (the stage found something to review) or failed. Holds names, timings, vehicle ids and counts only: no payload content.
    /// </summary>
    public sealed record ExecutionTrace(IReadOnlyList<TraceStage> Stages, double TotalMs);
}
