namespace Volvo.TestRequestTool.Domain
{
    /// <summary>Who is expected to decide on an open review, and who said so. Routing only: any reviewer may still decide.</summary>
    public sealed record ReviewAssignee(string Id, string Name, string ById, string ByName, DateTimeOffset At);
}
