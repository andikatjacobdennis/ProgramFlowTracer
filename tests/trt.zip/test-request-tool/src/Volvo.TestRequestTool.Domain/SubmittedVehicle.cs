namespace Volvo.TestRequestTool.Domain
{
    public sealed record SubmittedVehicle(string VehicleId, long FromRevision, long ToRevision);
}
