using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    /// <summary>
    /// One version of an organisation setting (FR-79): settings are versioned, every change records who and when, and an
    /// earlier version can be restored (which adds a new version).
    /// </summary>
    public sealed record SettingVersion(string Key, int Version, JsonObject Value, string ActorId, string ActorName, DateTimeOffset At, string? Note = null);
}
