namespace Volvo.TestRequestTool.Domain
{
    /// <summary>State is "used", "not-connected" (not configured, so not asked) or "failed".</summary>
    public sealed record ServiceUse(string Name, string State, string Note);
}
