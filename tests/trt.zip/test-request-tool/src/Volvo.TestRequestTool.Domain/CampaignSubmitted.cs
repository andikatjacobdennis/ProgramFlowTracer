namespace Volvo.TestRequestTool.Domain
{
    /// <summary>One vehicle of a submission: committed (with the new revision) or skipped with the reason.</summary>
    public sealed record CampaignSubmitted(string VehicleId, string Outcome, long? FromRevision, long? ToRevision, string? Reason);
}
