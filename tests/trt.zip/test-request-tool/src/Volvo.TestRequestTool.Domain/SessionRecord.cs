namespace Volvo.TestRequestTool.Domain
{
    /// <summary>A signed-in session. Signing out deletes it, so its cookie stops working at once, even if it was copied.</summary>
    public sealed record SessionRecord(string Id, string UserId, DateTimeOffset CreatedAt, DateTimeOffset ExpiresAt);
}
