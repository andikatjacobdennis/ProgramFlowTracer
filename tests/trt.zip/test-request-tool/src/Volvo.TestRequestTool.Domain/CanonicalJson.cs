using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    public static class CanonicalJson
    {
        public static string Hash(JsonNode node) => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(Normalize(node)?.ToJsonString() ?? "null")));

        private static JsonNode? Normalize(JsonNode? node) => node switch
        {
            JsonObject o => new JsonObject(o.OrderBy(p => p.Key, StringComparer.Ordinal).Select(p => KeyValuePair.Create(p.Key, Normalize(p.Value)))),
            JsonArray a => new JsonArray(a.Select(Normalize).ToArray()),
            _ => node?.DeepClone()
        };
    }
}
