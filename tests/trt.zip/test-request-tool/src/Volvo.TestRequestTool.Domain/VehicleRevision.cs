using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    /// <summary>A committed VDA revision: the full product snapshot after the change, with its author and reason.</summary>
    public sealed record VehicleRevision(long Revision, DateTimeOffset At, string ActorId, string ActorName, string Reason, string? Source, JsonObject Product);
}
