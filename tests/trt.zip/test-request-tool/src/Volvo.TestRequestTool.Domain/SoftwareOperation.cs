namespace Volvo.TestRequestTool.Domain
{
    public enum SoftwareOperation { Refresh = 1, Repair, Update, Resolve, UpdateToServicePack }
}
