using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    /// <summary>Feedback from a user: an idea, a problem, praise or a question, with an optional rating from 1 to 5 and the page it came from.</summary>
    public sealed record FeedbackItem(Guid Id, string ActorId, string ActorName, string Kind, int Rating, string Message, string? Page, JsonObject? Context, DateTimeOffset CreatedAt, string Status = "New");
}
