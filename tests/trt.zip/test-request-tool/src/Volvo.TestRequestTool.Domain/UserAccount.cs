namespace Volvo.TestRequestTool.Domain
{
    /// <summary>
    /// A person who can use the tool: their role (Admin, Reviewer, Engineer or Viewer), the vehicle contexts they can see, and
    /// their country (an ISO 3166 two-letter code that sets their default culture; without it the default is UTC).
    /// Kept in the repository (users); the sign-in provider only proves who someone is.
    /// </summary>
    public sealed record UserAccount(string Id, string DisplayName, string Role, int[] Contexts, bool Enabled = true, string? Country = null,
        string? Email = null, DateTimeOffset? LastSignIn = null)
    {
        public static readonly string[] Roles = ["Admin", "Reviewer", "Engineer", "Viewer"];
    }
}
