namespace Volvo.TestRequestTool.Domain
{
    public sealed record CampaignSubmission(string Id, string ActorId, string ActorName, DateTimeOffset At, IReadOnlyList<CampaignSubmitted> Vehicles);
}
