namespace Volvo.TestRequestTool.Domain
{
    /// <summary>The approval of one campaign revision: who, when, and the vehicles (with their validated result and revision) it covers.</summary>
    public sealed record CampaignApproval(int Revision, string ActorId, string ActorName, DateTimeOffset At, string Note, IReadOnlyList<ApprovedVehicle> Vehicles);
}
