namespace Volvo.TestRequestTool.Domain
{
    public sealed record ValidationIssue(string Code, string Text, int Severity = 0, string? Node = null);
}
