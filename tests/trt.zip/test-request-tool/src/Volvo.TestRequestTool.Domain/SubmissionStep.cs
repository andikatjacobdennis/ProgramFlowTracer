namespace Volvo.TestRequestTool.Domain
{
    public sealed record SubmissionStep(DateTimeOffset At, string Text, string Detail);
}
