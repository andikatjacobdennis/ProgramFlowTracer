using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    /// <summary>
    /// A batch run (FR-11): many vehicles, one request each, run one after another with a pause after each completes.
    /// Status: queued, running, finished, cancelled. Items keep their own status, job id, timings and outcome.
    /// </summary>
    public sealed record BatchRecord(Guid Id, JobActor Actor, string Name, string Kind, JsonObject Template, int DelayMs, bool StopOnFailure, string Status,
        DateTimeOffset CreatedAt, IReadOnlyList<BatchItem> Items, DateTimeOffset? StartedAt = null, DateTimeOffset? FinishedAt = null, int Round = 1);
}
