namespace Volvo.TestRequestTool.Domain
{
    public enum RequestKind { Software, ConversionKit, SpareCab, ProductionBreakdown, DevelopmentBreakdown, AvailableUpdates, ProductUpdateService, AvailableProductUpdates }
}
