using System.Security.Cryptography;
using System.Text;
using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    /// <summary>
    /// One entry in the protected audit log (FR-19). Each entry carries the hash of the previous one, so changing or removing
    /// any entry breaks the chain from that point on and verification reports where.
    /// </summary>
    public sealed record AuditEntry(long Sequence, DateTimeOffset At, string ActorId, string ActorName, string Action, string Target, JsonObject? Details, string PreviousHash, string Hash)
    {
        public static string Compute(long sequence, DateTimeOffset at, string actorId, string action, string target, JsonObject? details, string previousHash) =>
            Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes($"{sequence}|{at:O}|{actorId}|{action}|{target}|{details?.ToJsonString() ?? ""}|{previousHash}")));
    }
}
