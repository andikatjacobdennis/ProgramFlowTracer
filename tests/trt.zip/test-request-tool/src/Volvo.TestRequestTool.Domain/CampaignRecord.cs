using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    /// <summary>
    /// A campaign: one change (a request template) coordinated across many vehicles. Every edit of name, vehicles or template
    /// is a new Revision and clears the approval, so an approval always belongs to one exact revision. Validations are batch
    /// runs of that revision; approval is by someone else with the Writer role and covers the vehicles that were ready then;
    /// submission commits each approved vehicle that is still on its validated revision. Status: draft, active, approved,
    /// changes_requested, submitted, archived.
    /// </summary>
    public sealed record CampaignRecord(Guid Id, string Code, string Name, string Description, string OwnerId, string OwnerName, DateTimeOffset CreatedAt,
        int Revision, string Status, string Kind, JsonObject Template, IReadOnlyList<string> VehicleIds, IReadOnlyList<CampaignValidation> Validations,
        CampaignApproval? Approval, CampaignSubmission? Submission, IReadOnlyList<CampaignEvent> Events, long Version = 1);
}
