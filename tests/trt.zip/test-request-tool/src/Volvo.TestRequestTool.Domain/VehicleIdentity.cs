using System.Globalization;

namespace Volvo.TestRequestTool.Domain
{
    public static class VehicleIdentity
    {
        public static string Key(string series, string number)
        {
            if (string.IsNullOrWhiteSpace(series) || series.Length > 30 || !series.All(char.IsAsciiLetterOrDigit) ||
                !long.TryParse(number, NumberStyles.None, CultureInfo.InvariantCulture, out var n) || n is < 0 or > 999999)
            {
                throw new RequestFault(400, "invalid_vehicle_id", "Use a chassis series and a number of up to six digits.");
            }

            return $"{series.Trim().ToUpperInvariant()}|{n}";
        }
    }
}
