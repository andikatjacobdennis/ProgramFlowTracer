using System.Text.Json.Nodes;

namespace Volvo.TestRequestTool.Domain
{
    public static class JsonAccess
    {
        public static string S(this JsonNode? n, string key, string fallback = "") => n?[key]?.ToString() ?? fallback;
        public static int I(this JsonNode? n, string key, int fallback = 0) => int.TryParse(n.S(key), out var v) ? v : fallback;
        public static bool B(this JsonNode? n, string key, bool fallback = false) => bool.TryParse(n.S(key), out var v) ? v : fallback;
        public static JsonArray A(this JsonNode? n, string key) => n?[key] as JsonArray ?? [];
        public static IEnumerable<JsonObject> Objects(this JsonArray n) => n.OfType<JsonObject>();
        public static string NodeKey(JsonNode? id) => string.Join('|', new[] { "electricalArchitecture", "family", "type", "position", "mid" }.Select(k => id.S(k)));
        public static string NodeKeyOf(JsonNode? node) => NodeKey(node?["nodeIdentifier"]);
    }
}
