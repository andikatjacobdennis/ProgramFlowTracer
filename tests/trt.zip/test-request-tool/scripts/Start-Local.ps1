param([ValidateRange(1024,65535)][int]$Port = 5100)
$ErrorActionPreference = 'Stop'
Push-Location (Join-Path $PSScriptRoot '..')
try {
    & (Join-Path $PSScriptRoot 'Assert-Sdk.ps1')
    if ($LASTEXITCODE -ne 0) { throw 'SDK check failed.' }
    # First start on this computer: the sign-in accounts live in C:\trt\settings.json, never in the repository.
    $settings = if ($env:Settings__File) { $env:Settings__File } else { 'C:\trt\settings.json' }
    if (-not (Test-Path $settings)) {
        New-Item -ItemType Directory -Force (Split-Path $settings) | Out-Null
        Copy-Item (Join-Path $PSScriptRoot '..\settings.example.json') $settings
        Write-Host "Created $settings from settings.example.json." -ForegroundColor Yellow
        Write-Host 'Open it, give each account its own password (replace every CHANGE-ME), then run Start.cmd again.' -ForegroundColor Yellow
        return
    }
    # Nobody can sign in while every account still has the example's CHANGE-ME password (or none).
    $accounts = @((Get-Content $settings -Raw | ConvertFrom-Json).Authentication.Accounts)
    $usable = @($accounts | Where-Object { $_.Password -and -not ($_.Password -like 'CHANGE-ME*') })
    if ($usable.Count -eq 0) {
        Write-Host "No account in $settings has a password of its own yet." -ForegroundColor Yellow
        Write-Host 'Replace every CHANGE-ME with a real password, then run Start.cmd again.' -ForegroundColor Yellow
        return
    }
    if ($usable.Count -lt $accounts.Count) { Write-Host "$($accounts.Count - $usable.Count) account(s) in $settings still have CHANGE-ME and cannot sign in." -ForegroundColor Yellow }
    dotnet restore TestRequestTool.slnx
    if ($LASTEXITCODE -ne 0) { throw 'Package restore failed. Check your NuGet connection and the error printed above.' }
    dotnet build src/Volvo.TestRequestTool.Web/Volvo.TestRequestTool.Web.csproj --no-restore
    if ($LASTEXITCODE -ne 0) { throw 'The application did not build. See the compiler error printed above.' }
    Write-Host "Open http://localhost:$Port after the server prints 'Now listening on'. Press Ctrl+C to stop." -ForegroundColor Cyan
    $oldEnvironment = $env:ASPNETCORE_ENVIRONMENT
    try {
        $env:ASPNETCORE_ENVIRONMENT = 'Development'
        dotnet run --project src/Volvo.TestRequestTool.Web --no-build --no-restore --no-launch-profile --urls "http://localhost:$Port"
        if ($LASTEXITCODE -ne 0) { throw 'The server stopped with an error. If the port is already in use, retry with -Port 5101.' }
    } finally { $env:ASPNETCORE_ENVIRONMENT = $oldEnvironment }
} finally { Pop-Location }
