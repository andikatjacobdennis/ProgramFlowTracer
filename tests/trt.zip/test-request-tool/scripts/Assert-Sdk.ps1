$ErrorActionPreference = 'Stop'
if (-not (Get-Command dotnet -ErrorAction SilentlyContinue)) {
    throw 'The .NET SDK is missing. Install the .NET 10 SDK (not just the runtime) from https://dotnet.microsoft.com/download/dotnet/10.0, then reopen your terminal or Visual Studio.'
}
$installed = @(& dotnet --list-sdks)
if ($LASTEXITCODE -ne 0 -or -not ($installed | Where-Object { $_ -match '^10\.0\.\d+\s+\[' })) {
    throw "A stable .NET 10 SDK is required. Installed SDKs: $($installed -join '; '). Install the .NET 10 SDK from https://dotnet.microsoft.com/download/dotnet/10.0. Installing a runtime alone is not enough."
}
$selected = & dotnet --version
if ($LASTEXITCODE -ne 0 -or $selected -notmatch '^10\.0\.\d+$') {
    throw 'SDK selection failed. Run dotnet --list-sdks from this solution folder and check global.json. Visual Studio must support .NET 10; use the command-line launcher if your IDE is older.'
}
Write-Host "Using .NET SDK $selected" -ForegroundColor Green
