#!/usr/bin/env bash
set -euo pipefail
if ! command -v dotnet >/dev/null 2>&1; then
  echo 'Install the .NET 10 SDK (not just the runtime): https://dotnet.microsoft.com/download/dotnet/10.0' >&2
  exit 1
fi
sdks="$(dotnet --list-sdks)"
if ! [[ "$sdks" =~ (^|$'\n')10\.0\.[0-9]+[[:space:]]+\[ ]]; then
  echo 'A stable .NET 10 SDK is required. Installed SDKs:' >&2
  echo "$sdks" >&2
  exit 1
fi
selected="$(dotnet --version)"
if ! [[ "$selected" =~ ^10\.0\.[0-9]+$ ]]; then
  echo "Expected a stable .NET 10 SDK, selected: $selected" >&2
  exit 1
fi
printf 'Using .NET SDK %s\n' "$selected"
