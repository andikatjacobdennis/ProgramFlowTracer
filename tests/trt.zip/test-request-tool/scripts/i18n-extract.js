#!/usr/bin/env node
/* Collects every text the interface passes through t(…) and writes the translation template:
 *
 *   node scripts/i18n-extract.js            writes src/Volvo.TestRequestTool.Web/wwwroot/i18n/template.json
 *   node scripts/i18n-extract.js --report   also prints, for each language pack, how many keys it covers
 *
 * The template maps each US-English text to "" and lists where it is used, so a translator copies it to <code>.json and
 * fills in the values. Keys are the English text exactly as written in the code, including {placeholders}. */
'use strict';
const fs = require('fs'), path = require('path');
const ROOT = path.join(__dirname, '..', 'src', 'Volvo.TestRequestTool.Web', 'wwwroot');
const OUT = path.join(ROOT, 'i18n', 'template.json');

function files(dir) {
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((d) => (d.isDirectory() ? files(path.join(dir, d.name)) : d.name.endsWith('.js') ? [path.join(dir, d.name)] : []));
}
/** String literals passed straight to t( … ): single, double or backtick quotes without ${}. */
function keysIn(source) {
  const found = [];
  const re = /(?:^|[^\w.$])t\(\s*(['"`])((?:\\.|(?!\1)[^\\\n])*)\1\s*[,)]/g;
  let m;
  while ((m = re.exec(source))) {
    if (m[1] === '`' && m[2].includes('${')) continue;
    // Unescape as JavaScript would.
    let text;
    try { text = m[1] === '`' ? m[2].replace(/\\`/g, '`') : JSON.parse('"' + m[2].replace(/\\'/g, "'").replace(/"/g, '\\"') + '"'); } catch (e) { text = m[2]; }
    if (text.trim()) found.push(text);
  }
  return found;
}
function extract() {
  const used = new Map();
  for (const f of files(path.join(ROOT, 'js'))) {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/');
    if (/\/i18n-|guide-data/.test(rel)) continue;
    for (const k of keysIn(fs.readFileSync(f, 'utf8'))) { if (!used.has(k)) used.set(k, new Set()); used.get(k).add(rel); }
  }
  return used;
}
if (require.main === module) {
  const used = extract();
  const keys = [...used.keys()].sort((a, b) => a.localeCompare(b, 'en'));
  const template = { $meta: { generated: new Date().toISOString().slice(0, 10), keys: keys.length, note: 'Copy to <code>.json, keep the keys, translate the values. Keep every {placeholder}. A value may be { "one": "...", "other": "..." } for plurals.' }, strings: Object.fromEntries(keys.map((k) => [k, ''])), usedIn: Object.fromEntries(keys.map((k) => [k, [...used.get(k)].sort()])) };
  fs.writeFileSync(OUT, JSON.stringify(template, null, 2) + '\n');
  console.log(`i18n: ${keys.length} keys written to ${path.relative(process.cwd(), OUT)}`);
  if (process.argv.includes('--report')) {
    const langs = JSON.parse(fs.readFileSync(path.join(ROOT, 'i18n', 'languages.json'), 'utf8')).languages;
    for (const l of langs.filter((x) => x.file)) {
      const pack = JSON.parse(fs.readFileSync(path.join(ROOT, 'i18n', l.file), 'utf8')).strings;
      const have = keys.filter((k) => pack[k] != null && pack[k] !== '').length;
      console.log(`  ${l.code.padEnd(6)} ${l.english.padEnd(10)} ${have}/${keys.length} (${Math.round((100 * have) / keys.length)} %) in code, ${Object.keys(pack).length} in pack`);
    }
  }
}
module.exports = { extract, keysIn };
