// Captures the UI guide: drives the running application in headless Microsoft Edge, takes a screenshot per chapter
// for each theme, measures each balloon target and writes wwwroot/guide/img/<theme>/*.png + guide-data.js.
// Usage (app running on BASE_URL, default http://localhost:5198; Capture-Guide.ps1 starts one):
//   node scripts/guide/capture-guide.mjs [baseUrl] [charcoal-light] [charcoal]
// Themes default to both. guide-data.js is rebuilt from every theme captured so far.
import { launch, by } from './cdp.mjs';
import { writeFileSync, readFileSync, rmSync, mkdirSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { tmpdir } from 'node:os';

const here = dirname(fileURLToPath(import.meta.url));
const OUT = join(here, '..', '..', 'src', 'Volvo.TestRequestTool.Web', 'wwwroot', 'guide');
const IMG = join(OUT, 'img');
const BASE = (process.argv[2] || process.env.BASE_URL || 'http://localhost:5198').replace(/\/$/, '');
const THEMES = ['charcoal-light', 'charcoal'];
const requested = process.argv.slice(3).length ? process.argv.slice(3) : THEMES;
for (const t of requested) if (!THEMES.includes(t)) throw new Error(`Unknown theme ${t}. Use ${THEMES.join(' or ')}.`);
const T3 = '/?chassisSeries=FH&chassisNumber=333333';
// The guide is captured as two people: an administrator who asks for approval and a reviewer who decides. Their sign-in
// accounts come from the settings file the app reads (TRT_SETTINGS, default C:\\trt\\settings.json), or else from
// appsettings.Development.json. Passwords are used only to sign in from here, never written to the page, the output or the guide.
const accountsFrom = (file) => { try { return JSON.parse(readFileSync(file, 'utf8')).Authentication?.Accounts || []; } catch { return []; } };
const ACCOUNTS = [...accountsFrom(process.env.TRT_SETTINGS || 'C:\\trt\\settings.json'), ...accountsFrom(join(here, '..', '..', 'src', 'Volvo.TestRequestTool.Web', 'appsettings.Development.json'))];
const AUTHOR = ACCOUNTS.find((a) => a.Role === 'Admin'), REVIEWER = ACCOUNTS.find((a) => a.Role === 'Reviewer');
if (!AUTHOR || !REVIEWER) throw new Error('No Admin and Reviewer sign-in accounts found (C:\\trt\\settings.json or appsettings.Development.json). See docs/sign-in.md.');
/** Signs in through the sign-in endpoint and returns the session cookie's value. */
async function session(account) {
  const r = await fetch(BASE + '/api/v1/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Studio-Request': '1' }, body: JSON.stringify({ login: account.UserName, password: account.Password }) });
  if (!r.ok) throw new Error(`Signing in as ${account.UserName} failed: ${r.status}`);
  const cookie = (r.headers.getSetCookie ? r.headers.getSetCookie() : [r.headers.get('set-cookie')]).find((c) => c && c.startsWith('trt.session='));
  if (!cookie) throw new Error('The sign-in answer had no session cookie.');
  return cookie.split(';')[0].slice('trt.session='.length);
}

// ---------- DOM finders (evaluated in the page) ----------
const btn = (text, scope = '') => by.exact(`${scope} button`.trim(), text);
const PANEL = ':is(#ap-panels,#overlays)';   // side panels (and the few dialogs left)
const field = (label) => `[...document.querySelectorAll('${PANEL} .rq-field')].find(f=>f.offsetParent&&f.textContent.trim().startsWith(${JSON.stringify(label)}))`;
const dlgBtn = (text) => `[...document.querySelectorAll('${PANEL} button')].find(b=>b.offsetParent&&b.textContent.trim()===${JSON.stringify(text)})`;
/** Closes the open side panel (its ✕), or a dialog's Close button. */
const closePanel = `([...document.querySelectorAll('#ap-panels .ap-panel-head button[aria-label=Close]')].pop()||${dlgBtn('Close')})`;
const css = (sel, nth = 0) => by.css(sel, nth);
/** A Home card by its title. */
const card = (title) => `[...document.querySelectorAll('button.gx-action')].find(b=>b.offsetParent&&b.querySelector('strong,h2,h3,b')?.textContent.trim()===${JSON.stringify(title)})`;

// ---------- chapters (guide order) ----------
const chapters = [];
const chapter = (c) => { chapters.push(c); return c; };

chapter({ id: 'sign-in', part: 'Getting started', title: 'Sign in',
  intro: 'Test Request Tool opens on its sign-in page. After signing in you are taken back to the page you asked for. Your session ends when you sign out, or after eight hours without use.',
  links: [{ label: 'Open the sign-in page', href: '/login' }],
  note: 'Your administrator sets up your account and decides your role (Admin, Reviewer, Engineer or Viewer) and the vehicle contexts you can see.',
  steps: [
    { n: 1, find: `document.getElementById('lg-login')`, title: 'User name or email', text: 'Either one signs you in.' },
    { n: 2, find: `document.getElementById('lg-reveal')`, title: 'Show the password', text: 'Shows what you typed, to check it. Select Hide to cover it again.' },
    { n: 3, find: `document.getElementById('lg-submit')`, title: 'Sign in', text: 'Checks your user name and password on the server. If they are wrong, the page says so and you can try again; after too many attempts it asks you to wait a minute.' },
  ] });

chapter({ id: 'start', part: 'Getting started', title: 'Home',
  intro: 'Test Request Tool is a simulation workspace for vehicle software changes. Nothing you do here changes a real vehicle or VDA unless a change is approved and sent. Home shows what needs you and where to start.',
  links: [{ label: 'Open Home', href: '/' }],
  steps: [
    { n: 1, find: by.text('.hm-main h2', 'Needs you') + `?.closest('section')`, title: 'Needs you', text: 'Requests waiting on you, each with its next step: decide, send, continue, fix or get approval.' },
    { n: 2, find: by.text('.hm-side h2', 'Start') + `?.closest('section')`, title: 'Start', text: 'Choose a vehicle, open the one you have, your saved vehicles and Getting started.' },
    { n: 3, find: by.text('.hm-side h2', 'The fleet') + `?.closest('section')`, title: 'The fleet', text: 'The fleet dashboard (also under Vehicles) and the service status.' },
    { n: 4, find: css('.hd-new'), title: 'New request', text: 'Start another request from anywhere.' },
    { n: 5, find: css('#studio-navigation'), title: 'Navigation menus', text: 'Requests, Vehicles and Help. Administrators also see Expert tools and Administration; anyone can show expert tools from Help or Settings.' },
    { n: 6, find: css('.av-trigger'), title: 'Your account', text: 'Theme, layout, language and region, your data and Settings.' },
  ] });

chapter({ id: 'intake', part: 'Getting started', title: 'Choose a vehicle',
  intro: 'Create a test request starts with the vehicle. The vehicle now is kept unchanged, so you can always compare your changes with it.',
  links: [{ label: 'Create a test request', href: '/?view=new' }],
  steps: [
    { n: 1, find: css('.nr-choose .jr-tabs'), title: 'Choose the source', text: 'Search by vehicle ID or VIN, pick a recent vehicle, or load an EDB specification or an XML file under Other sources.' },
    { n: 2, find: css('.nr-find-row'), title: 'Identify the vehicle', text: 'Enter the complete ID, for example FH 333333, and choose Find vehicle.' },
    { n: 3, find: css('.nr-request'), title: 'Your request', text: 'The chosen vehicle and its configuration, before you make any change.' },
    { n: 4, find: btn('Continue to changes'), title: 'Continue', text: 'Available once a vehicle is chosen. Only vehicles in contexts you are authorized for can be loaded.' },
  ] });

chapter({ id: 'choose-path', part: 'Plan a change', title: 'How to change it',
  intro: 'For a T3 vehicle with no changes yet, Make changes starts with one question: update to the service pack, or change the software by hand.',
  links: [{ label: 'Open FH 333333 in the app', href: T3 }],
  steps: [
    { n: 1, find: css('.s-path-card.is-recommended'), title: 'Update to the latest service pack', text: 'Recommended. One click: the service pack picks the right version for every computer, and the check runs straight away. Choose settings first opens the request panel.' },
    { n: 2, find: by.text('.s-path-card h2', 'Change software by hand') + `?.closest('section')`, title: 'Change software by hand', text: 'Opens the editor: pick package versions yourself, or edit parameters, variants and S-Notes.' },
    { n: 3, find: btn('See what updates exist'), title: 'Only look', text: 'Lists the updates available for the vehicle. Nothing is changed.' },
  ] });

chapter({ id: 'configure', part: 'Plan a change', title: 'Make changes',
  intro: 'Change software by hand opens the editor for the loaded vehicles: “Your changes”. The vehicle now stays as it is. For T3 vehicles the software is shown as software products, grouped per HPC node and execution environment.',
  links: [{ label: 'Open FH 333333 in the app', href: T3 }],
  steps: [
    { n: 1, find: css('.wf-step.is-current'), title: 'Five steps', text: 'Choose vehicle, Make changes, Check, Get approval and Send. The current step is highlighted; a locked step says what it needs.' },
    { n: 2, find: css('.wf-summary'), title: 'One-line summary', text: 'The vehicle, your changes, whether it is checked and when it was saved. Details shows every fact.' },
    { n: 3, find: css('.s-entity-tabs'), title: 'Editors', text: 'Software, plus any editor with changes (with its count). More editors opens Parameters, Variants, S-Notes, Structure, Parameter templates and Product info.' },
    { n: 4, find: css('.s-package-group'), title: 'Software per execution environment', text: 'Each card is one HPC node and its execution environment, for example VCM on VCM-Linux, with its software products.' },
    { n: 5, find: `[...document.querySelectorAll('select')].find(s=>String(s.getAttribute('aria-label')).includes('VCM-Platform proposed version'))`, title: 'Choose a package version', text: 'Pick the proposed version of a software product. The list shows each version’s release status.' },
    { n: 6, find: css('.s-change-panel .s-side-card'), title: 'See what changed', text: 'Counts node, package, parameter, variant and S-Note changes against the vehicle now.' },
    { n: 7, find: btn('Check 1 vehicle'), title: 'Check', text: 'Runs a software request on the server and moves to the Check step.' },
  ] });

chapter({ id: 'validate', part: 'Plan a change', title: 'Check the change',
  intro: 'Check shows the simulated outcome per vehicle. A result goes out of date as soon as you change something, and must be checked again.',
  links: [{ label: 'Open FH 333333 in the app', href: T3 }],
  steps: [
    { n: 1, find: btn('Request settings'), title: 'Adjust the request', text: 'Change the scenario, operation or other request settings and check again.' },
    { n: 2, find: css('.s-stats'), title: 'Summary', text: 'How many vehicles were tested, how many are ready and how many need attention.' },
    { n: 3, find: css('.wf-findings'), title: 'Findings', text: "Must fix stops you from sending. Couldn't confirm means nothing could confirm or refuse it. Checked OK passed the catalog rules. With no findings it simply says: All checks passed." },
    { n: 4, find: by.text('.s-result-card h2, .s-result-card h3', 'Simulation results'), title: 'Result per vehicle', text: 'Below: Ready, Limited validation or Blocked for each vehicle, with Inspect result for its messages, release notes and full delta.' },
    { n: 5, find: css('.s-ready-card'), title: 'All good: ask for approval', text: 'When every vehicle is ready and nothing must be fixed, ask for approval right here. See your changes first shows what changes. Otherwise the button is Continue to approval.' },
  ] });

chapter({ id: 'review', part: 'Plan a change', title: 'Your changes, then get them approved',
  intro: 'The last workspace stage shows what changes on each vehicle, then asks a colleague to approve exactly this version. Nothing is sent until it is approved.',
  links: [{ label: 'Open FH 333333 in the app', href: T3 }],
  steps: [
    { n: 1, find: css('section.s-comparison'), title: 'The vehicle now and your changes', text: 'A side-by-side summary. Detailed comparison shows every field.' },
    { n: 2, find: by.exact('h3', 'Get it approved') + `?.closest('section')`, title: 'Get it approved', text: 'Creates an approval request for this exact checked version and opens it.' },
    { n: 3, find: css('.s-more-delivery > summary'), title: 'Other ways to send or export', text: 'Conversion kits, the VDA update preview, product XML, the result workbench and the Digital Twin preview, for experts and for work without approval.' },
    { n: 4, find: btn('Run again'), title: 'Run again', text: 'Check again after any change to keep the result current.' },
  ] });

chapter({ id: 'waiting', part: 'Plan a change', title: 'Waiting for approval',
  intro: 'After you ask for approval, the Get approval page shows who can decide and keeps itself up to date. You can never approve your own change.',
  links: [{ label: 'Open Requests', href: '/?view=requests' }],
  steps: [
    { n: 1, find: css('.rv-wait-status'), title: 'Waiting for a decision', text: 'Since when you asked.' },
    { n: 2, find: css('.rv-pool'), title: 'Who can decide', text: 'The people with the Reviewer or Admin role, never you. Assign one of them: they find it under Assigned to me. Unassigned reviews wait in the Unassigned queue for anyone to take.' },
    { n: 3, find: btn('Copy link for a reviewer'), title: 'Send them the link', text: 'Copies a link straight to this approval.' },
    { n: 4, find: css('.rv-wait-live'), title: 'Updates by itself', text: 'The decision appears on this page, with a notice, without reloading.' },
  ] });

chapter({ id: 'approval', part: 'Plan a change', title: 'Get approval',
  intro: 'A colleague with the Reviewer or Admin role approves exactly the checked version. The author can never approve their own request. Shown here as the reviewer, Kavya Nair.',
  links: [{ label: 'Open Requests', href: '/?view=requests' }],
  note: 'To see both sides, sign out (in your account menu) and sign in as someone with the Reviewer role.',
  steps: [
    { n: 1, find: css('.rv-assignee'), title: 'Who decides', text: 'Assigned to you, to someone else, or to nobody yet (then Take it). Anyone with the role can still decide.' },
    { n: 2, find: css('.rv-checklist'), title: 'Review checklist', text: 'Approve becomes available once all three items are ticked.' },
    { n: 3, find: css('.rv-also-send'), title: 'Also send it now', text: 'Approve and send in one step: the final checks run again, the vehicle record is updated and the receipt opens. If it cannot be sent yet, the approval stands and Send says why.' },
    { n: 4, find: css('#rv-approve'), title: 'Approve', text: 'Records the approval for this revision (and sends it, with Also send it now). Below it: Request changes, which sends it back with your note.' },
    { n: 5, find: by.text('.jr-main h2', 'Your changes') + `?.closest('section')`, title: 'Your changes', text: 'Each change with the vehicle now and the proposed value.' },
  ] });

chapter({ id: 'send', part: 'Plan a change', title: 'Send',
  intro: 'Once approved, choose how to send it and confirm. The usual way, updating the vehicle record, is preselected.',
  links: [{ label: 'Open Requests', href: '/?view=requests' }],
  steps: [
    { n: 1, find: css('.sb-deliver'), title: 'How to send it', text: 'Update the vehicle record (recommended), prepare a conversion kit, a Digital Twin specification or download the vehicle file.' },
    { n: 2, find: by.text('.jr-main h2', 'Submission summary') + `?.closest('section')`, title: 'Submission summary', text: 'The vehicle, the request, the approved revision and every approved change.' },
    { n: 3, find: css('.sb-option.is-on'), title: 'Preselected', text: 'The usual choice. Below it, tick to confirm the target and the approved revision; the final checks run again on sending.' },
    { n: 4, find: btn('Back to approval'), title: 'Back to approval', text: 'See the approval and its evidence again.' },
  ] });

chapter({ id: 'vehicle-graph', part: 'Your vehicle', title: 'See the whole vehicle',
  intro: 'The Vehicle page draws the loaded vehicle as a graph: the vehicle, its computers, their execution environments and the software in each. Compare it with any earlier state to see exactly what changed.',
  links: [{ label: 'Open the Vehicle page for FH 333333', href: T3 + '&view=vehicle' }],
  steps: [
    { n: 1, find: css('.ap-crumbs'), title: 'Breadcrumbs', text: 'Show where you are. Click any earlier part to go back.' },
    { n: 2, find: css('.vh-identity'), title: 'Vehicle identity', text: 'VIN, model, context, the current VDA revision and where and when it was built.' },
    { n: 3, find: css('.vh-tabs'), title: 'Graph, Map, Roadmap, History, Insights', text: 'Five views of the same vehicle. History shows how many entries there are.' },
    { n: 4, find: css('.vh-compare'), title: 'Compare with an earlier state', text: 'Choose a history entry, for example VDA revision 1, the record as first imported. Like a code diff, the earlier value is red with a minus and the value now is green with a plus.' },
    { n: 5, find: css('.vh-node.is-changed'), title: 'A computer and its software', text: 'Icons tell computer kinds apart. Each card lists execution environments and software versions.' },
    { n: 6, find: css('.vh-detail'), title: 'Details, next versions and history', text: 'Click a computer to see its hardware, the versions it can move to (and what blocks them) and every change made to it.' },
  ] });

chapter({ id: 'vehicle-roadmap', part: 'Your vehicle', title: 'Where the vehicle can go next',
  intro: 'The roadmap shows the service packs that apply and, for every computer, the path from the version it has today to each upcoming version.',
  links: [{ label: 'Open the Vehicle page for FH 333333', href: T3 + '&view=vehicle' }],
  steps: [
    { n: 1, find: css('.vh-pack'), title: 'Service packs', text: 'Available, Already on it or Not applicable. An available pack can be requested straight from here.' },
    { n: 2, find: css('.vh-step.now'), title: 'Now', text: 'The version on the vehicle today.' },
    { n: 3, find: css('.vh-step.is-blocked'), title: 'What blocks a version', text: 'A lock and a plain sentence, such as the ECU hardware or the version of another computer it needs.' },
  ] });

chapter({ id: 'vehicle-history', part: 'Your vehicle', title: 'Who changed what, and when',
  intro: 'History is drawn like a git history, newest first. Changes to the vehicle are on the main line; simulations and kits branch off the revision they started from, and a committed simulation joins the main line again. Older entries load as you scroll.',
  links: [{ label: 'Open the Vehicle page for FH 333333', href: T3 + '&view=vehicle' }],
  note: 'Long pages show a round go-to-top button in the bottom right corner once you scroll down.',
  steps: [
    { n: 1, find: css('.vh-people'), title: 'People', text: 'Everyone in the history and how many entries each has. Click a person to see only their entries.' },
    { n: 2, find: css('.vh-history .vh-search'), title: 'Search and filter', text: 'Search titles, people, computers and versions, and choose which kinds of entries to show.' },
    { n: 3, find: css('.gh-gutter'), title: 'Main line and branches', text: 'Filled dots are changes to the vehicle. Hollow dots are simulations, diamonds are kits, on a branch from the revision they started from.' },
    { n: 4, find: css('.gh-meta'), title: 'Who and when', text: 'The person who made the change and the date and time, in your culture.' },
    { n: 5, find: css('.gh-stat'), title: 'Size of the change', text: 'Additions and deletions, like on GitHub. Click to show or hide the details.' },
    { n: 6, find: css('.gh-diff'), title: 'What changed', text: 'Each computer like a file in a diff: red lines with a minus are before, green lines with a plus are after.' },
  ] });

chapter({ id: 'vehicle-insights', part: 'Your vehicle', title: 'Insights for one vehicle',
  intro: 'Insights sum up the history and the roadmap: what is up to date, what is waiting and how every computer’s software changed over time.',
  links: [{ label: 'Open the Vehicle page for FH 333333', href: T3 + '&view=vehicle' }],
  steps: [
    { n: 1, find: css('.in-cards'), title: 'Insight cards', text: 'The facts that matter, as short sentences: up to date, updates waiting, the next unblocked update and the last change.' },
    { n: 2, find: css('.in-timeline'), title: 'Software timeline', text: 'One lane per computer with each version it has run since its first VDA record. Diamonds are upcoming versions at their release week.' },
    { n: 3, find: css('.vh-tabs'), title: 'Switch with the keyboard', text: 'Press 1 to 5 for Graph, Map, Roadmap, History and Insights, or [ and ] for the previous and next tab.' },
  ] });

chapter({ id: 'dashboard', part: 'Your vehicle', title: 'The fleet dashboard',
  intro: 'The dashboard reads every vehicle you may see and shows how current the software is, what is waiting and what happened.',
  links: [{ label: 'Open the Dashboard', href: '/?view=dashboard' }],
  steps: [
    { n: 1, find: css('.db-kpis'), title: 'Headline numbers', text: 'Vehicles, computers, the share up to date, updates waiting, requests and VDA changes.' },
    { n: 2, find: css('.hp-guide.is-dash'), title: 'Asha sums it up', text: 'One sentence about the fleet and the vehicle that needs the most attention.' },
    { n: 3, find: by.text('.db-page h2', 'Groups') + `?.closest('section, .db-card, .jr-card')`, title: 'Groups', text: 'Vehicles grouped by how current they are, how many updates wait and how long since the last change. Further down: vehicles that need attention, unusual vehicles and the release pipeline.' },
  ] });

chapter({ id: 'pus-request', part: 'T3 services', tag: 'T3 · PUS 1.0 / 2.0', title: 'Product Update Service request',
  intro: 'Product Update Service updates a vehicle to the latest service pack, including T3 HPC nodes. Schema 2.0 also supports Repair. The request follows the ProductUpdateService JSON contract.',
  links: [{ label: 'Open this panel for FH 333333', href: T3 + '&open=request&requestType=8' }],
  note: 'Schema 1.0 always runs Update to service pack. 2.0 reads criteria.operation.operationType and accepts Update to service pack or Repair.',
  steps: [
    { n: 1, find: css(`${PANEL} .rq-plain`), title: 'What it will do', text: 'One plain sentence, for example: Update FH 333333 to the latest service pack.' },
    { n: 2, find: field('What to do'), title: 'What to do', text: 'The task, in plain words, with its contract name below. Change lists every task: change the software, or only look.' },
    { n: 3, find: css(`${PANEL} .rq-advanced > summary`), title: 'Advanced', text: 'The settings below have working defaults. Open Advanced only to change them.' },
    { n: 4, find: field('Schema version'), title: 'Schema version', text: '2.0 is the current contract. 1.0 is kept for compatibility.' },
    { n: 5, find: field('Operation'), title: 'Operation', text: 'Update to service pack, or Repair to reprogram the installed versions.' },
    { n: 6, find: field('Scenario'), title: 'Scenario', text: 'Which release states may be used: Introduced, IntroductionDateSet, Released, PreReleaseVerification or InProgress.' },
    { n: 7, find: `[...document.querySelectorAll('${PANEL} button')].find(b=>b.offsetParent&&(b.textContent.trim()==='Run the request'||b.textContent.includes('►')))`, title: 'Run the request', text: 'Runs the request on the server and shows the result in the Check step.' },
    { n: 8, find: dlgBtn('Get request JSON'), title: 'Preview the contract request', text: 'Shows the exact JSON the service would receive, without running or recording anything.' },
  ] });

chapter({ id: 'pus-result', part: 'T3 services', tag: 'T3 · PUS', title: 'Product Update Service result',
  intro: 'The Product Update Service card appears under the simulation results. It shows the chosen service pack and every software product it changes, per execution environment.',
  links: [{ label: 'Open the request for FH 333333', href: T3 + '&open=request&requestType=8' }],
  note: 'Service-pack candidates must be reachable by every node. They are tried newest first, and T3 HPC nodes must pass the upgrade-path check for their ECU hardware and dependencies.',
  steps: [
    { n: 1, find: css('[data-guide=pus-pack]'), title: 'Chosen service pack', text: 'The newest service pack that every node can reach in the selected scenario.' },
    { n: 2, find: `[...document.querySelectorAll('.s-svc-head .s-chip')].find(c=>c.textContent.startsWith('Error code'))`, title: 'Contract status', text: 'Error code 0 means success. 100 is a schema failure, 107 an invalid request or no valid service pack.' },
    { n: 3, find: css('[data-guide=pus-table]'), title: 'Software products', text: 'Each row is a software product in an execution environment, with the installed and the service-pack version.' },
    { n: 4, find: css('[data-guide=pus-notes]'), title: 'Release notes', text: 'Release notes for every node that changes, in the request language.' },
    { n: 5, find: css('.s-service-card .s-svc-actions'), title: 'Contract JSON', text: 'Open the exact contract request and response.' },
  ] });

chapter({ id: 'contract-json', part: 'T3 services', tag: 'Contracts', title: 'Inspect the contract JSON',
  intro: 'Every T3 service result keeps the contract request and response, so you can compare them with the service specification or reuse them in other tools.',
  steps: [
    { n: 1, find: css(`${PANEL} .ap-panel-title, ${PANEL} .dialog-title`), title: 'Contract and version', text: 'The service and the schema version of this document.' },
    { n: 2, find: css(':is(#ap-panels,#overlays) .s-json'), title: 'Browse the document', text: 'Expand productUpdate to see servicePack, nodes with hpcNode and executionEnvironments, parameterUpdates and releaseNotes.' },
    { n: 3, find: dlgBtn('Copy JSON'), title: 'Copy it', text: 'Copies the formatted JSON to the clipboard.' },
  ] });

chapter({ id: 'pus-rejected', part: 'T3 services', tag: 'T3 · PUS', title: 'When no service pack fits',
  intro: 'If no candidate passes, the service returns an error instead of a product update. The card explains why each candidate was rejected.',
  links: [{ label: 'Open the request for FH 333333', href: T3 + '&open=request&requestType=8' }],
  steps: [
    { n: 1, find: `[...document.querySelectorAll('.s-svc-head .s-chip')].find(c=>c.textContent.startsWith('Error code'))`, title: 'Error code 107', text: 'No valid configuration: the request was valid but no service pack can be applied.' },
    { n: 2, find: css('[data-guide=pus-error]'), title: 'Contract error', text: 'The error type and text from the contract response.' },
    { n: 3, find: css('[data-guide=pus-rejected]'), title: 'Rejected candidates', text: 'For each service pack, the nodes that blocked it. Here the 26.10 versions are only Introduced, outside the Released scenario.' },
    { n: 4, find: css('.s-result-card tbody tr'), title: 'The vehicle is blocked', text: 'A failed service request blocks delivery for this vehicle until it is run again successfully.' },
  ] });

chapter({ id: 'apu-request', part: 'T3 services', tag: 'T3 · APU 1.0 / 1.1', title: 'Available Product Updates request',
  intro: 'Available Product Updates lists what could be updated on a vehicle, including T3 HPC nodes, without changing it. The request follows the GetAvailableProductUpdates JSON contract.',
  links: [{ label: 'Open this panel for FH 333333', href: T3 + '&open=request&requestType=9' }],
  note: 'Contract 1.0 sends actionCriteria as a comma-separated string; 1.1 sends a JSON string array and adds software product id and templateId to the response.',
  steps: [
    { n: 1, find: css(`${PANEL} .rq-plain`), title: 'What it will do', text: 'One plain sentence: list the product updates available for the vehicle.' },
    { n: 2, find: field('Action criteria'), title: 'Action criteria', text: 'Choose what to look for: software replacements (general, remote or by service pack), hardware replacements, display languages or kits.' },
    { n: 3, find: `[...document.querySelectorAll('${PANEL} label.chk')].find(l=>l.offsetParent&&l.textContent.includes('Include update purposes'))`, title: 'Response options', text: 'Include update purposes, release note sources or document-number-only changes, and SEMS support (None, Inclusive or Exclusive).' },
    { n: 4, find: css(`${PANEL} .rq-advanced > summary`), title: 'Advanced', text: 'Contract version (1.1 is current), Scenario (InProgress also shows versions still in progress) and the other defaults.' },
    { n: 5, find: `[...document.querySelectorAll('${PANEL} button')].find(b=>b.offsetParent&&(b.textContent.trim()==='Run the request'||b.textContent.includes('►')))`, title: 'Run the request', text: 'Opens the results panel. The vehicle itself is not changed.' },
  ] });

chapter({ id: 'apu-results', part: 'T3 services', tag: 'T3 · APU', title: 'Read the available updates',
  intro: 'Results are grouped by action criteria. Each node shows its installed node template, the available one and the software products it would bring.',
  links: [{ label: 'Open the request for FH 333333', href: T3 + '&open=request&requestType=9' }],
  steps: [
    { n: 1, find: css('[data-guide=apu-status]'), title: 'Response status', text: 'Accepted (0), Modified (1, some criteria failed) or Rejected (-1, or 107 for an invalid request).' },
    { n: 2, find: css('[data-guide=apu-General] h4'), title: 'Software replacements', text: 'The newest version allowed by the scenario that fits the installed hardware.' },
    { n: 3, find: css('[data-guide=apu-General] .s-svc-up'), title: 'Available node template', text: 'Green numbers are updates. Same means the installed version is already the newest.' },
    { n: 4, find: css('[data-guide=apu-General] .s-svc-sw'), title: 'T3 software products', text: 'For HPC nodes: the software products per execution environment in the available version.' },
    { n: 5, find: css('[data-guide=apu-ServicePackGeneral] .s-svc-pack'), title: 'Service pack', text: 'The service pack that would update every node, with exact match.' },
  ] });

chapter({ id: 'apu-hardware', part: 'T3 services', tag: 'T3 · APU', title: 'Hardware replacements and kits',
  intro: 'Further down, the panel lists hardware that newer software needs and the kits that fit the vehicle.',
  links: [{ label: 'Open the request for FH 333333', href: T3 + '&open=request&requestType=9' }],
  steps: [
    { n: 1, find: css('[data-guide=apu-hardware]'), title: 'Hardware replacements', text: 'VCM versions 26.30 and later need ECU hardware 21601602. The vehicle has 21601601.' },
    { n: 2, find: css('[data-guide=apu-kits]'), title: 'Kits', text: 'Accessory, service and campaign kits for the product class in the selected scenario.' },
    { n: 3, find: css(':is(#ap-panels,#overlays) .s-svc-actions'), title: 'Contract JSON', text: 'Open the GetAvailableUpdates request or the ShowAvailableProductUpdates response.' },
  ] });

chapter({ id: 'two-pane', part: 'Expert tools', title: 'Two-pane workbench',
  intro: 'The original expert workbench is still available: the original vehicle on the left, the request response on the right.',
  links: [{ label: 'Open the workbench for FH 333333', href: T3 + '&open=twopane' }],
  steps: [
    { n: 1, find: css('section.pane.left .toolbar'), title: 'Load into a pane', text: 'Each pane can load its own vehicle from VDA, VIN, EDB or a file.' },
    { n: 2, find: css('section.pane.left .toolbar', 1), title: 'Pane actions', text: 'Compare, VESPA2, VDA update, kits and request actions for the pane.' },
    { n: 3, find: css('section.pane.right .pane-mode-bar'), title: 'Response views', text: 'Switch between the response, the response XML and the resulting product.' },
    { n: 4, find: css('section.pane.right .pane-body'), title: 'Response content', text: 'Assigned nodes and parameter changes from the last request.' },
  ] });

chapter({ id: 'history', part: 'Expert tools', title: 'Request history',
  intro: 'Every server request is recorded for your user. Open any record to inspect its input, outcome and contract responses.',
  links: [{ label: 'Open History', href: '/?view=history' }],
  steps: [
    { n: 1, find: css('.s-main table'), title: 'Your requests', text: 'Newest first, with the request type and the vehicles.' },
    { n: 2, find: by.exact('.s-main button', 'Details'), title: 'Inspect a record', text: 'Shows the full execution record, including serviceResponses for T3 services.' },
    { n: 3, find: by.exact('.s-main [role=tab]', 'Local / NAMS log'), title: 'Local / NAMS log', text: 'The original browser-only log and the NAMS samples.' },
  ] });

chapter({ id: 'server-calls', part: 'Expert tools', title: 'Server calls',
  intro: 'Every call the application makes, to the server API and to the simulated services, with its timing. Use it to see what a step did and why it was slow or failed.',
  links: [{ label: 'Open Server calls', href: '/?view=calls' }],
  steps: [
    { n: 1, find: css('.sc-filters'), title: 'Filters', text: 'Time range, endpoint search, method, outcome and duration. Save view keeps them.' },
    { n: 2, find: css('.sc-tiles'), title: 'Headline numbers', text: 'Total calls, success rate, median and p95 latency, with a small trend each.' },
    { n: 3, find: css('.sc-traffic'), title: 'Traffic and latency', text: 'Succeeded and failed calls over time, or median and p95 latency. Point at a bar for details.' },
    { n: 4, find: css('.sc-insights'), title: 'Session insights', text: 'Findings worth acting on, such as slow endpoints or a failure spike, each with a filter to see the calls.' },
  ] });

chapter({ id: 'vcads', part: 'Expert tools', title: 'VCADS request',
  intro: 'The legacy VCADS test request has its own page, in three short steps with a summary beside them.',
  links: [{ label: 'Open VCADS', href: '/?page=vcads' }],
  steps: [
    { n: 1, find: css('.vc-types'), title: '1. Request type', text: 'Software, hardware or conversion kit request. Simulated NAMS sends it the NAMS way.' },
    { n: 2, find: by.text('.jr-card h2, .jr-card h3', '2. Vehicle') + `?.closest('.jr-card')`, title: '2. Vehicle', text: 'Chassis series and number, with examples to fill in.' },
    { n: 3, find: by.text('.jr-card h2, .jr-card h3', '3. Computers') + `?.closest('.jr-card')`, title: '3. Computers (optional)', text: 'Limit the request to some computers, such as EMS or TECU.' },
    { n: 4, find: css('.vc-sum'), title: 'Request summary', text: 'What will be sent. Run request shows the response below it.' },
  ] });

chapter({ id: 'compare-breakdown', part: 'Expert tools', title: 'Compare breakdown',
  intro: 'Compare two product specifications, from EDB or VDA, as a breakdown tree.',
  links: [{ label: 'Open Compare breakdown', href: '/?page=compare' }],
  steps: [
    { n: 1, find: css('.cb-specs .jr-card', 0), title: 'Original specification', text: 'Choose EDB or VDA and identify the first product.' },
    { n: 2, find: css('.cb-swap'), title: 'Swap', text: 'Exchange the two sides.' },
    { n: 3, find: css('.cb-specs .jr-card', 1), title: 'Comparison specification', text: 'The product to compare against.' },
    { n: 4, find: btn('Compare'), title: 'Compare', text: 'Builds the comparison tree; only-left, only-right and changed values are colour-coded, and filters narrow it down.' },
  ] });

chapter({ id: 'help-center', part: 'Settings and help', title: 'Help Center',
  intro: 'Help works like a search engine for this application: type what you want to do in plain words, or browse the topics.',
  links: [{ label: 'Open Help', href: '/?view=help' }],
  steps: [
    { n: 1, find: css('.hp-search'), title: 'Search in plain words', text: 'For example change time zone or create a kit. Press / to jump here.' },
    { n: 2, find: css('.hp-hero-actions .s-btn'), title: 'Take the tour', text: 'Asha walks you through the application and can read each step aloud.' },
    { n: 3, find: css('.hp-guide'), title: 'The guide', text: 'Asha has a tip on every page, thinks along when a search finds nothing and cheers when you are done.' },
    { n: 4, find: css('.hp-steps'), title: 'Your first steps', text: 'A checklist that ticks itself off as you go.' },
  ] });

chapter({ id: 'tour', part: 'Settings and help', title: 'The introduction tour',
  intro: 'The tour highlights one part of the screen at a time. Asha explains it, out loud if you like, using the most natural voice your browser has.',
  links: [{ label: 'Open Help to start the tour', href: '/?view=help' }],
  note: 'Keys during the tour: → or Enter next, ← back, V voice on or off, Esc end. Press g then i to start it anywhere.',
  steps: [
    { n: 1, find: css('.tr-figure'), title: 'Asha explains', text: 'The part she talks about is highlighted and everything else is dimmed. With the voice on, she reads the step aloud.' },
    { n: 2, find: css('.tr-card h2'), title: 'What it is', text: 'A short title and a sentence or two, read aloud when the voice is on.' },
    { n: 3, find: css('.tr-dots'), title: 'Where you are', text: 'Fourteen short steps, from the menus to Help.' },
    { n: 4, find: css('.tr-actions .s-btn.primary'), title: 'Move on', text: 'Next, Back or Skip. The voice button turns the narration on or off.' },
  ] });

chapter({ id: 'shortcuts', part: 'Settings and help', title: 'Keyboard shortcuts',
  intro: 'Press ? on any screen for the full list. Shortcuts pause while you type in a field.',
  links: [{ label: 'Open the application', href: '/' }],
  steps: [
    { n: 1, find: css('.ks-filter'), title: 'Find a shortcut', text: 'Type a word such as vehicle or theme.' },
    { n: 2, find: css('.ks-groups'), title: 'Grouped by where they work', text: 'General, Go to (g then a letter), Test request, Vehicle and Lists.' },
  ] });

chapter({ id: 'settings', part: 'Settings and help', title: 'Settings',
  intro: 'Settings are laid out like the settings of a web browser: sections on the left, cards on the right. Every change is saved immediately in this browser.',
  links: [{ label: 'Open Settings', href: '/?view=settings' }],
  steps: [
    { n: 1, find: css('.st-search'), title: 'Search settings', text: 'Type any word, for example motion or page. Press / to jump here and Esc to clear.' },
    { n: 2, find: css('.st-nav'), title: 'Sections', text: 'Jump to Appearance, Accessibility, Workspace, Requests, Privacy and data, Help or About.' },
    { n: 3, find: css('.st-themes'), title: 'Theme', text: 'Auto follows your operating system. Light Charcoal and Dark Charcoal stay fixed.' },
    { n: 4, find: css('.st-row[data-setting=textSize] .st-control'), title: 'Text size', text: 'Makes all text and controls larger.' },
  ] });

chapter({ id: 'settings-search', part: 'Settings and help', title: 'Find a setting',
  intro: 'Search filters every section at once and marks the matching words.',
  links: [{ label: 'Open Settings', href: '/?view=settings' }],
  steps: [
    { n: 1, find: css('.st-status'), title: 'How many match', text: 'The count updates as you type.' },
    { n: 2, find: css('.st-row[data-setting=motion] .st-switch'), title: 'Animations and motion', text: 'Turn off to remove transitions and smooth scrolling everywhere. The reduce-motion setting of your system is always honoured.' },
    { n: 3, find: css('.st-nav a.is-empty'), title: 'Sections without matches', text: 'Are dimmed, so you can see where the results are.' },
  ] });

chapter({ id: 'culture-settings', part: 'Settings and help', title: 'Language and region',
  intro: 'Your culture decides how dates, times, numbers and money are shown. It starts from the country on your account, for example India gives IST and rupees. Without a country it is UTC.',
  links: [{ label: 'Open Language and region', href: '/?view=settings' }],
  steps: [
    { n: 1, find: css('.st-row[data-setting=cultureSystem] .st-switch'), title: 'Use system settings', text: 'Follow the language and time zone of this computer instead.' },
    { n: 2, find: css('.st-row[data-setting=country] .st-detail'), title: 'Where the default comes from', text: 'The country on your account. Ask an administrator to change it.' },
    { n: 3, find: css('.cu-countries'), title: 'Country', text: 'Pick a flag. The language, time zone and currency change to that country’s defaults.' },
    { n: 4, find: css('.st-row[data-setting=language] .st-control'), title: 'Language', text: 'Month and day names and number formats, for example Hindi (India).' },
  ] });

chapter({ id: 'culture-formats', part: 'Settings and help', title: 'Time zone, money and formats',
  intro: 'Fine-tune the culture and see the result straight away.',
  links: [{ label: 'Open Language and region', href: '/?view=settings' }],
  steps: [
    { n: 1, find: css('.st-row[data-setting=dateFormat] .st-control'), title: 'Date format', text: 'ISO, short, medium or long.' },
    { n: 2, find: css('.st-row[data-setting=hourCycle] .st-control'), title: 'Clock', text: 'From the language, 12-hour or 24-hour.' },
    { n: 3, find: by.text('.st-row', 'Other time zones'), title: 'Other time zones', text: 'Hover over or click any time to see it in these zones too. UTC and the cultures you keep for the quick switch are always included.' },
    { n: 4, find: css('.cu-preview'), title: 'Preview', text: 'Date, time, number, money and time zone in the current culture.' },
  ] });

chapter({ id: 'culture-switch', part: 'Settings and help', title: 'Switch culture live',
  intro: 'Your account menu shows the culture and time zone in use and opens Language and region. Every date, time and amount on the page follows it at once.',
  links: [{ label: 'Open the application', href: '/' }],
  note: 'Alt+Shift+C moves to the next culture you kept, without opening a menu.',
  steps: [
    { n: 1, find: css('.av-trigger'), title: 'Your account menu', text: 'Opens with a click on your picture or initials.' },
    { n: 2, find: by.text('.av-menu [role=menuitem], .av-menu button', 'Language & region'), title: 'Language and region', text: 'The country and language in use. Opens the settings to change them.' },
    { n: 3, find: by.text('.av-menu [role=menuitem], .av-menu button', 'Time zone'), title: 'Time zone', text: 'The time zone every time is shown in.' },
    { n: 4, find: by.text('.av-menu [role=menuitem], .av-menu button', 'Sign out'), title: 'Sign out', text: 'Ends your session and shows the sign-in page.' },
  ] });

chapter({ id: 'activity', part: 'Settings and help', title: 'Activity',
  intro: 'Every request you ran, newest first. Only you can see your requests. Open it from Home or from Requests (Activity log).',
  links: [{ label: 'Open Activity', href: '/?view=activity' }],
  steps: [
    { n: 1, find: css('.ac-search'), title: 'Search', text: 'By vehicle, request type or result.' },
    { n: 2, find: `document.querySelector('select[aria-label="Request type"]')`, title: 'Filter by type', text: 'Show one request type only.' },
    { n: 3, find: css('.ac-table tbody tr'), title: 'Open a request', text: 'Click a row to inspect the stored request and its result.' },
    { n: 4, find: css('.ap-pages'), title: 'Pages', text: 'Shows which rows you see, with First, Previous, page numbers, Next and Last, and how many rows per page.' },
  ] });

chapter({ id: 'about', part: 'Settings and help', title: 'About',
  intro: 'What the application does, its version and runtime, and the contracts it supports.',
  links: [{ label: 'Open About', href: '/?view=about' }],
  steps: [
    { n: 1, find: css('.ab-hero'), title: 'The application', text: 'Name, version and a one-line description.' },
    { n: 2, find: css('.st-section .st-card'), title: 'This installation', text: 'Runtime, environment, sign-in, storage and which live services are connected.' },
  ] });

chapter({ id: 'guide-search', part: 'Settings and help', title: 'Search this guide',
  intro: 'The box above the contents filters the guide as you type and marks every match.',
  links: [{ label: 'Search the guide for kit', href: '/guide/?q=kit' }],
  steps: [
    { n: 1, find: `document.getElementById('guide-search')`, title: 'Search box', text: 'Press / to jump here. Esc clears the search.' },
    { n: 2, find: `document.getElementById('guide-search-status')`, title: 'Matches', text: 'How many chapters and steps match.' },
    { n: 3, find: css('.g-step.g-hit'), title: 'Matching steps', text: 'Are outlined, with the matching words marked.' },
  ] });

// ---------- capture sequence (one browser profile and one run per theme) ----------
const C = Object.fromEntries(chapters.map((c) => [c.id, c]));
async function captureTheme(theme) {
  const dir = join(IMG, theme), shots = {};
  rmSync(dir, { recursive: true, force: true }); mkdirSync(dir, { recursive: true });
  const b = await launch({ profileDir: join(tmpdir(), `trs-guide-${theme}-${Date.now()}`) });
  const shoot = async (id, caption) => {
    const c = C[id];
    await b.eval(`document.querySelectorAll('.nt-toast').forEach(t=>t.remove())`);   // notices would cover the page
    shots[id] = await b.shot(dir, id, c.steps.map(({ n, find, title }) => ({ n, find, title })));
    Object.assign(shots[id], { file: `${theme}/${id}.png`, caption, alt: c.title + ' screenshot' });
    console.log(`captured ${theme}/${id}`);
  };
  const run = (expr) => b.eval(`(async()=>{${expr};return true;})()`);
  const clickEl = (finder) => run(`const el=(${finder});if(!el)throw new Error('missing '+${JSON.stringify(finder.slice(0, 80))});el.click()`);
  const settle = (ms = 900) => b.sleep(ms);
  const runRequest = `[...document.querySelectorAll(':is(#ap-panels,#overlays) button')].find(b=>b.offsetParent&&(b.textContent.trim()==='Run the request'||b.textContent.includes('\u25ba')))`;
  /** Gives the browser a session for this account (signed in from here, so no password reaches the page). */
  const signInAs = async (account) => {
    await b.send('Network.setCookie', { name: 'trt.session', value: await session(account), url: BASE + '/', httpOnly: true, sameSite: 'Strict' });
  };
  try {
    // Without a session the app opens on the sign-in page: shot first, then sign in as the author.
    await b.goto(BASE + '/');
    await run(`localStorage.setItem('trstudio.theme',JSON.stringify(${JSON.stringify(theme)}))`);
    await b.goto(BASE + '/?page=requests', 1500);
    await b.waitFor(`document.getElementById('lg-form')&&document.documentElement.dataset.theme===${JSON.stringify(theme)}`);
    await shoot('sign-in', 'The sign-in page');
    await signInAs(AUTHOR);
    // The Home shot shows the cards; the first-steps checklist gets its own shot in the Help Center chapter.
    await run(`localStorage.setItem('trstudio.firstSteps','false')`);
    // The first-visit welcome (choose a guide) would cover the pages: mark it seen for both people.
    await run(`${JSON.stringify([AUTHOR.Id, REVIEWER.Id])}.forEach(u=>localStorage.setItem('trstudio.'+u+'.welcomed','true'))`);
    await b.goto(BASE + '/', 2500);
    await run(`TR.pages.show('home')`);
    await b.waitFor(`document.querySelector('.hm-page .hm-list, .hm-page .hm-none')&&document.documentElement.dataset.theme===${JSON.stringify(theme)}`, 20000);
    await shoot('start', 'Home');

    await clickEl(by.text('.hm-link', 'Choose a vehicle')); await settle();
    await b.waitFor(`document.querySelector('.nr-page')&&document.getElementById('nr-q')`); await settle(600);
    // Find FH 333333 by its ID, as a person would.
    await run(`const q=document.getElementById('nr-q');q.value='FH 333333';q.dispatchEvent(new Event('input',{bubbles:true}))`); await settle(300);
    await shoot('intake', 'Create a test request: choose a vehicle');
    await clickEl(css('.nr-find-btn'));
    await b.waitFor(`document.querySelector('.nr-picked')`, 20000); await settle(600);
    await clickEl(btn('Continue to changes')); await settle(2000);
    await b.waitFor(`document.querySelector('.s-path-card')`); await settle(600);
    await shoot('choose-path', 'Make changes for FH 333333: the service pack or by hand');
    await clickEl(btn('Change by hand'));
    await b.waitFor(`document.querySelector('.s-package-group')`);
    await run(`const s=[...document.querySelectorAll('select')].find(x=>String(x.getAttribute('aria-label')).includes('VCM-Platform proposed version'));s.value='1.2.0';s.dispatchEvent(new Event('change',{bubbles:true}))`);
    await settle();
    await shoot('configure', 'Make changes for the T3 vehicle FH 333333, with VCM-Platform proposed at 1.2.0');

    await clickEl(btn('Check 1 vehicle')); await b.waitFor(`document.querySelector('.s-stats')`); await settle(1200);
    await run(`document.querySelectorAll('.nt-toast, .toast').forEach(t=>t.remove())`);
    await shoot('validate', 'Check after a software request');
    await clickEl(btn('See your changes')); await settle(1200);
    await shoot('review', 'Your changes, then get them approved');

    // Get approval and Send: requested by the author, decided by the reviewer, then back to the author.
    await clickEl(by.exact('h3', 'Get it approved') + `?.closest('section')?.querySelector('button')`);
    await b.waitFor(`document.querySelector('.rv-page')&&/[?&]rid=/.test(location.search)`); await settle(800);
    await b.waitFor(`document.querySelector('.rv-pool')`); await settle(400);
    await shoot('waiting', 'Waiting for approval, as the author');
    const reviewUrl = await b.eval('location.href');
    await signInAs(REVIEWER);
    await b.goto(reviewUrl, 3000); await b.waitFor(`document.querySelector('.rv-checklist')`); await settle(600);
    await run(`document.querySelectorAll('.rv-checklist input').forEach(i=>{if(!i.checked)i.click()})`); await settle(400);
    await run(`document.querySelector('.rv-also-send').scrollIntoView({block:'center'})`); await settle(500);
    await shoot('approval', 'Get approval, as the reviewer');
    await clickEl(`document.getElementById('rv-approve')`); await b.waitFor(btn('Continue to send')); await settle(600);
    await clickEl(btn('Continue to send')); await b.waitFor(`document.querySelector('.sb-deliver')`); await settle(900);
    await shoot('send', 'Send, with the vehicle record preselected');
    await signInAs(AUTHOR);

    // T3 services on a fresh copy of the vehicle.
    await b.goto(BASE + T3 + '&open=request&requestType=8', 3500);
    await b.waitFor(`document.querySelector('${PANEL} .rq-advanced')`);
    await run(`document.querySelector('${PANEL} .rq-advanced').open=true`); await b.waitFor(field('Schema version')); await settle(500);
    await shoot('pus-request', 'Product Update Service request, schema 2.0');
    await clickEl(runRequest);
    await b.waitFor(`document.querySelector('[data-guide=pus-table]')`); await settle(1200);
    await run(`document.querySelector('[data-guide=pus-card]').scrollIntoView({block:'start'})`); await settle(500);
    await shoot('pus-result', 'Product Update Service result: T3 SP 2026.1 for FH 333333');
    await clickEl(by.exact('.s-service-card button', 'Contract response')); await settle(1000);
    await shoot('contract-json', 'ProductUpdateService 2.0 contract response');
    await clickEl(closePanel); await settle(600);
    await run(`const L=TR.app.shell.left;L.request.selectedScenario=3;await TR.request.runRequest(L,false)`);
    await b.waitFor(`document.querySelector('[data-guide=pus-rejected]')`); await settle(1200);
    await run(`document.querySelector('.s-main').scrollTop=0;document.querySelector('[data-guide=pus-card]').scrollIntoView({block:'center'})`); await settle(500);
    await shoot('pus-rejected', 'Product Update Service with the Released scenario: no valid service pack');

    await b.goto(BASE + T3, 3500); await b.waitFor(`document.querySelector('.s-path-card')`);
    await run(`const L=TR.app.shell.left;L.request.selectedScenario=5;L.request.apuActionCriteria=['SoftwareReplacements.General','SoftwareReplacements.ServicePackGeneral','HardwareReplacements','AccessoryKits']`);
    await clickEl(btn('See what updates exist')); await b.waitFor(`document.querySelector('${PANEL} .rq-advanced')`); await settle();
    await shoot('apu-request', 'Available Product Updates request, contract 1.1');
    await clickEl(runRequest);
    await b.waitFor(`document.querySelector('[data-guide=apu-results]')`); await settle(1200);
    await shoot('apu-results', 'Available Product Updates results for FH 333333, scenario InProgress');
    await run(`const d=[...document.querySelectorAll('${PANEL} .ap-panel-body, ${PANEL} .dialog-body')].pop();d.scrollTop=d.scrollHeight`); await settle(600);
    await shoot('apu-hardware', 'Hardware replacements and kits');
    await clickEl(closePanel); await settle(600);

    await run(`TR.testRequest.expert()`); await b.waitFor(`document.querySelector('section.pane.right .pane-body')`); await settle(1200);
    await shoot('two-pane', 'Two-pane workbench after the Available Product Updates request');
    await run(`TR.pages.show('history')`); await b.waitFor(`document.querySelector('.s-main table')`); await settle(1000);
    await shoot('history', 'Server request history');
    await run(`TR.pages.show('calls')`); await b.waitFor(`document.querySelector('.sc-traffic .sc-chart')||document.querySelector('.sc-traffic')`); await settle(1500);
    await shoot('server-calls', 'Server calls for the requests run for this guide');
    const fromMenu = (menu, item) => run(`document.querySelector('[data-mb=${menu}]').click();await new Promise(r=>setTimeout(r,250));const it=[...document.querySelectorAll('.mb-menu [role=menuitem]')].find(x=>x.textContent.trim()===${JSON.stringify(item)});if(!it)throw new Error('menu item missing: ${item}');it.click()`);
    await fromMenu('expert', 'VCADS request'); await b.waitFor(`document.querySelector('.vc-types')`); await settle(900);
    await shoot('vcads', 'VCADS test request');
    await fromMenu('expert', 'Compare breakdown'); await b.waitFor(`document.querySelector('.cb-specs')`); await settle(900);
    await shoot('compare-breakdown', 'Compare breakdown');

    // Vehicle page. Commit a validated software update first, so the history shows who changed what.
    await run(`const post=(u,b)=>fetch('/api/v1'+u,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json',Accept:'application/json'},body:JSON.stringify(b)});
      const v=await (await fetch('/api/v1/vehicles/FH/333333')).json();
      const r=await (await post('/requests',{kind:'Software',payload:{products:[v.product],softwareRequestOperation:3,scenario:1,pblUpdateCapable:true,enableMultiNodeBehavior:true}})).json();
      const c=await post('/vda/commit',{requestId:r.id,vehicleId:'FH|333333',expectedRevision:v.revision});if(!c.ok)throw new Error('VDA commit failed: '+c.status)`);
    await b.goto(BASE + T3 + '&view=vehicle', 3500); await b.waitFor(`document.querySelector('.vh-node')`); await settle(900);
    await run(`const s=document.querySelector('select[aria-label="Compare with an earlier state"]');s.value='rev-1';s.dispatchEvent(new Event('change',{bubbles:true}))`);
    await b.waitFor(`document.querySelector('.vh-node.is-changed')`); await settle(600);
    await clickEl(css('.vh-node.is-changed .vh-node-head')); await b.waitFor(`document.querySelector('.vh-detail')`); await settle(600);
    await shoot('vehicle-graph', 'Vehicle graph for FH 333333 compared with VDA revision 1');
    await clickEl(by.text('.vh-tabs button', 'Roadmap')); await b.waitFor(`document.querySelector('.vh-lanes')`); await settle(600);
    await shoot('vehicle-roadmap', 'Roadmap for FH 333333');
    await clickEl(by.text('.vh-tabs button', 'History')); await b.waitFor(`document.querySelector('.gh-graph .gh-diff')`); await settle(600);
    await shoot('vehicle-history', 'History of FH 333333 with the committed software update');
    await clickEl(by.text('.vh-tabs button', 'Insights')); await b.waitFor(`document.querySelector('.in-timeline .in-bar')`); await settle(1200);
    await shoot('vehicle-insights', 'Insights for FH 333333');
    await b.goto(BASE + '/?view=dashboard', 2500); await b.waitFor(`document.querySelector('.db-kpis')&&document.querySelector('.db-funnel')`, 30000); await settle(1200);
    await shoot('dashboard', 'The fleet dashboard');
    await run(`localStorage.setItem('trstudio.firstSteps','true')`);
    await b.goto(BASE + '/?view=help', 2500); await b.waitFor(`document.querySelector('.hp-hero')`); await settle(900);
    await shoot('help-center', 'Help Center home');
    await run(`TR.prefs.set('tourVoice',false);TR.tour.start(2)`); await b.waitFor(`document.querySelector('.tr-card')&&document.querySelector('.tr-spot').style.display==='block'`); await settle(900);
    await shoot('tour', 'The introduction tour, step 3');
    await run(`TR.tour.stop()`); await settle(400);
    await run(`TR.shortcuts.show()`); await b.waitFor(`document.querySelector('.ks-groups')`); await settle(600);
    await shoot('shortcuts', 'Keyboard shortcuts');
    await clickEl(closePanel); await settle(400);

    await b.goto(BASE + '/?view=settings', 2500); await b.waitFor(`document.querySelector('.st-themes')`); await settle(600);
    await shoot('settings', 'Settings');
    await run(`const i=document.querySelector('.st-search input');i.value='motion';i.dispatchEvent(new Event('input',{bubbles:true}))`);
    await b.waitFor(`document.querySelector('.st-row[data-setting=motion] mark')`); await settle(600);
    await shoot('settings-search', 'Settings filtered by motion');
    // Language and region, with two extra cultures kept for the quick switch.
    await b.goto(BASE + '/?view=settings', 2500); await b.waitFor(`document.getElementById('st-region')`);
    await run(`const C=TR.culture;C.use(C.forCountry('SE'));C.addQuick();C.use(Object.assign(C.forCountry('IN'),{language:'hi-IN'}));C.addQuick();C.useAccount()`); await settle(600);
    await run(`document.querySelector('[data-setting=cultureSystem]').scrollIntoView({block:'start'})`); await settle(600);
    await shoot('culture-settings', 'Language and region for an account in India');
    await run(`document.querySelector('[data-setting=dateFormat]').scrollIntoView({block:'start'})`); await settle(600);
    await shoot('culture-formats', 'Formats, preview and quick switch');
    await run(`document.querySelector('.s-main').scrollTop=0`); await settle(300);
    await clickEl(css('.av-trigger')); await b.waitFor(`document.querySelector('.av-menu')`); await settle(500);
    await shoot('culture-switch', 'Language and region in the account menu');
    await run(`document.body.click()`); await settle(300);
    await b.goto(BASE + '/?view=activity', 2500); await b.waitFor(`document.querySelector('.ac-table')`); await settle(600);
    await shoot('activity', 'Activity with the requests run for this guide');
    await b.goto(BASE + '/?view=about', 2500); await b.waitFor(`document.querySelector('.ab-hero')&&document.querySelector('.st-section')`); await settle(600);
    await shoot('about', 'About page');
    await b.goto(BASE + '/guide/?q=kit', 2500); await b.waitFor(`document.querySelector('.g-step.g-hit')`); await settle(600);
    await shoot('guide-search', 'The UI guide filtered by kit');
    if (b.errors.length) console.warn('Page errors during capture:', b.errors);
  } finally { await b.close(); }
  writeFileSync(join(dir, 'shots.json'), JSON.stringify(shots, null, 2) + '\n');
}
for (const theme of requested) await captureTheme(theme);

// ---------- guide data, from every theme captured so far ----------
const byTheme = {};
for (const theme of THEMES) { try { byTheme[theme] = JSON.parse(readFileSync(join(IMG, theme, 'shots.json'), 'utf8')); } catch { /* not captured yet */ } }
const data = {
  title: 'Test Request Tool UI guide',
  themes: Object.keys(byTheme),
  intro: [
    'A visual walkthrough of the application, from choosing a vehicle to sending an approved change, including the T3 Product Update Service and Available Product Updates.',
    'Every screenshot is taken from the running application, in Light Charcoal and in Dark Charcoal. The guide shows the set that matches your theme.',
  ],
  footer: 'Screenshots are regenerated with scripts/guide/Capture-Guide.ps1. The vehicles and people shown are examples.',
  chapters: chapters.map((c) => ({ id: c.id, part: c.part, title: c.title, tag: c.tag, intro: c.intro, note: c.note, links: c.links || [],
    steps: c.steps.map(({ n, title, text }) => ({ n, title, text })), shots: Object.fromEntries(Object.entries(byTheme).map(([t, s]) => [t, s[c.id]])) })),
};
writeFileSync(join(OUT, 'guide-data.js'), '/* Generated by scripts/guide/capture-guide.mjs. Do not edit by hand. */\nwindow.TR_GUIDE = ' + JSON.stringify(data, null, 1) + ';\n');
console.log('wrote', join(OUT, 'guide-data.js'), 'themes:', data.themes.join(', '));
