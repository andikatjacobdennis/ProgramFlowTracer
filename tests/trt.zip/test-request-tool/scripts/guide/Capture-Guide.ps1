param(
    [ValidateRange(1024,65535)][int]$Port = 5198,
    [ValidateSet('charcoal-light', 'charcoal')][string[]]$Theme = @('charcoal-light', 'charcoal')
)
# Regenerates the UI guide screenshots (src/Volvo.TestRequestTool.Web/wwwroot/guide) for Light and Dark Charcoal.
# Each theme is captured from a fresh application instance with an empty temporary repository and services folder
# (never C:\trt), so both sets start from the same shipped reference data. It signs in with the Development accounts in
# appsettings.Development.json. Requires the .NET 10 SDK, Node.js 22+ and Microsoft Edge.
$ErrorActionPreference = 'Stop'
$root = Resolve-Path (Join-Path $PSScriptRoot '..\..')
Push-Location $root
try {
    # Release: Visual Studio keeps the Debug output locked while it runs the app.
    dotnet build src/Volvo.TestRequestTool.Web/Volvo.TestRequestTool.Web.csproj -c Release
    if ($LASTEXITCODE -ne 0) { throw 'The application did not build.' }
    $base = "http://localhost:$Port"
    foreach ($t in $Theme) {
        $data = Join-Path ([IO.Path]::GetTempPath()) ("trs-guide-data-" + [Guid]::NewGuid().ToString('N'))
        $server = $null
        try {
            $env:ASPNETCORE_ENVIRONMENT = 'Development'
            $env:Repository__Path = Join-Path $data 'repo'
            $env:Services__Path = Join-Path $data 'services'
            $env:Settings__File = Join-Path $data 'settings.json'
            # The sign-in accounts from your settings file (if any) go into the capture's own settings, so it can sign in.
            $settings = if ($env:TRT_SETTINGS) { $env:TRT_SETTINGS } else { 'C:\trt\settings.json' }
            New-Item -ItemType Directory -Force $data | Out-Null
            if (Test-Path $settings) { @{ Authentication = (Get-Content $settings -Raw | ConvertFrom-Json).Authentication } | ConvertTo-Json -Depth 6 | Set-Content -Encoding utf8 $env:Settings__File }
            $server = Start-Process dotnet -ArgumentList @('run', '--project', 'src/Volvo.TestRequestTool.Web', '-c', 'Release', '--no-build', '--no-launch-profile', '--urls', $base) -PassThru -WindowStyle Hidden
            $ready = $false
            for ($i = 0; $i -lt 120 -and -not $ready; $i++) {
                try { $ready = (Invoke-WebRequest "$base/health" -UseBasicParsing -TimeoutSec 2).StatusCode -eq 200 } catch { Start-Sleep -Milliseconds 500 }
            }
            if (-not $ready) { throw "The application did not start on $base." }
            node scripts/guide/capture-guide.mjs $base $t
            if ($LASTEXITCODE -ne 0) { throw "Guide capture failed for $t. See the message above." }
        } finally {
            if ($server -and -not $server.HasExited) {
                Get-CimInstance Win32_Process -Filter "ParentProcessId=$($server.Id)" | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
                Stop-Process -Id $server.Id -Force -ErrorAction SilentlyContinue
            }
            'Repository__Path', 'Services__Path', 'Settings__File' | ForEach-Object { Remove-Item "Env:$_" -ErrorAction SilentlyContinue }
            if (Test-Path $data) { Remove-Item $data -Recurse -Force -ErrorAction SilentlyContinue }
        }
    }
    Write-Host 'UI guide updated. Open /guide/ in the running application.' -ForegroundColor Green
} finally { Pop-Location }
