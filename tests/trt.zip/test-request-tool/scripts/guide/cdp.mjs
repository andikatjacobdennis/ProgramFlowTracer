// Minimal Chrome DevTools Protocol driver over Node's built-in WebSocket. No dependencies.
import { spawn } from 'node:child_process';
import { mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export async function launch({ profileDir, port = 9333, width = 1440, height = 900, scale = 1.5 }) {
  mkdirSync(profileDir, { recursive: true });
  const proc = spawn(EDGE, ['--headless=new', `--remote-debugging-port=${port}`, `--user-data-dir=${profileDir}`,
    '--no-first-run', '--no-default-browser-check', '--disable-extensions', '--hide-scrollbars', `--window-size=${width},${height}`, 'about:blank'],
    { stdio: 'ignore' });
  let targets;
  for (let i = 0; i < 80; i++) {
    try { targets = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json(); if (targets.some((t) => t.type === 'page')) break; } catch { }
    await sleep(250);
  }
  const page = targets.find((t) => t.type === 'page');
  const ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
  let id = 0; const waiting = new Map(); const listeners = [];
  ws.onmessage = (m) => {
    const msg = JSON.parse(m.data);
    if (msg.id && waiting.has(msg.id)) { const { res, rej } = waiting.get(msg.id); waiting.delete(msg.id); msg.error ? rej(new Error(msg.error.message)) : res(msg.result); }
    else if (msg.method) listeners.forEach((l) => l(msg));
  };
  const send = (method, params = {}) => new Promise((res, rej) => { const i = ++id; waiting.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method, params })); });
  const errors = [];
  listeners.push((m) => {
    if (m.method === 'Runtime.exceptionThrown') errors.push(m.params.exceptionDetails?.exception?.description || m.params.exceptionDetails?.text);
    if (m.method === 'Runtime.consoleAPICalled' && m.params.type === 'error') errors.push(m.params.args.map((a) => a.value ?? a.description).join(' '));
  });
  await send('Page.enable'); await send('Runtime.enable');
  await send('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: scale, mobile: false });
  const api = {
    send, errors, width, height, scale,
    async eval(expr) {
      const r = await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true });
      if (r.exceptionDetails) throw new Error('eval failed: ' + (r.exceptionDetails.exception?.description || r.exceptionDetails.text) + '\n' + expr.slice(0, 300));
      return r.result.value;
    },
    async goto(url, settle = 1500) { await send('Page.navigate', { url }); await sleep(settle); },
    async waitFor(expr, timeout = 15000) {
      const t0 = Date.now();
      while (Date.now() - t0 < timeout) { if (await api.eval(`!!(${expr})`)) return; await sleep(150); }
      throw new Error('timeout waiting for: ' + expr);
    },
    sleep,
    /** Screenshot the viewport and record each target's rectangle (CSS px). target: {n, find:'js expr returning Element', title, text} */
    async shot(dir, name, targets = []) {
      mkdirSync(dir, { recursive: true });
      await sleep(400);
      const rects = [];
      for (const t of targets) {
        // The target must exist and be visible at its centre (not scrolled away inside a dialog or covered).
        const r = await api.eval(`(()=>{const el=(${t.find});if(!el)return null;const b=el.getBoundingClientRect();const cx=Math.min(Math.max(b.x+Math.min(b.width/2,24),1),innerWidth-1),cy=Math.min(Math.max(b.y+Math.min(b.height/2,14),1),innerHeight-1);const hit=document.elementFromPoint(cx,cy);return {x:b.x,y:b.y,w:b.width,h:b.height,visible:!!hit&&(el===hit||el.contains(hit))};})()`);
        const fail = async (why) => {   // keep what the page looked like, to see what is missing or in the way
          const { data } = await send('Page.captureScreenshot', { format: 'png' }); writeFileSync(join(dir, name + '.failed.png'), Buffer.from(data, 'base64'));
          const cover = await api.eval(`(()=>{const el=(${t.find});if(!el)return '';const b=el.getBoundingClientRect();const h=document.elementFromPoint(Math.max(1,b.x+4),Math.max(1,b.y+4));return h?h.outerHTML.slice(0,200):''})()`).catch(() => '');
          throw new Error(`[${name}] balloon ${t.n} ${why}: ${t.find}${cover ? '\n  covered by: ' + cover : ''}\n  see ${join(dir, name + '.failed.png')}`);
        };
        if (!r || r.w === 0) await fail('target not found');
        if (!r.visible || r.y + r.h < 0 || r.y > height) await fail('target is not visible on screen');
        delete r.visible;
        rects.push({ ...t, find: undefined, rect: r });
      }
      const { data } = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
      writeFileSync(join(dir, name + '.png'), Buffer.from(data, 'base64'));
      return { name, file: name + '.png', width, height, balloons: rects };
    },
    async close() { try { await send('Browser.close'); } catch { } ws.close(); proc.kill(); },
  };
  return api;
}

// DOM helpers injected into the page as strings
export const by = {
  text: (sel, text, nth = 0) => `[...document.querySelectorAll(${JSON.stringify(sel)})].filter(e=>e.offsetParent!==null&&e.textContent.trim().includes(${JSON.stringify(text)}))[${nth}]`,
  exact: (sel, text, nth = 0) => `[...document.querySelectorAll(${JSON.stringify(sel)})].filter(e=>e.offsetParent!==null&&e.textContent.trim()===${JSON.stringify(text)})[${nth}]`,
  css: (sel, nth = 0) => `[...document.querySelectorAll(${JSON.stringify(sel)})].filter(e=>e.offsetParent!==null)[${nth}]`,
};
export const click = (finder) => `(()=>{const el=(${finder});if(!el)throw new Error('click target missing');el.scrollIntoView({block:'center'});el.click();return true;})()`;
