#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
bash scripts/assert-sdk.sh
dotnet restore TestRequestStudio.slnx
dotnet build src/TestRequest.Web/TestRequest.Web.csproj --no-restore
printf 'Open http://localhost:5100 after the server starts. Press Ctrl+C to stop.\n'
ASPNETCORE_ENVIRONMENT=Development dotnet run --project src/TestRequest.Web --no-build --no-restore --no-launch-profile --urls http://localhost:5100
