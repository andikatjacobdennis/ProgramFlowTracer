"""Imports the request listener's message types and their XML contracts into the tool.

    python scripts/import-contracts.py <SoftwareBreakdown.Contracts folder> <swb-stable1 src folder>

Reads:
  <contracts>/SoftwareBreakdown.Contracts/MessageTypes.cs   the message type names
  <contracts>/SoftwareBreakdown.Contracts/SchemaSet.cs      which XSD is the request and which the reply, per version
  <contracts>/SoftwareBreakdown.Contracts/Schemas/*.xsd     the contracts
  <src>/NVSComponents/HostCommon/AbstractDependencyInjector.cs
                                                           the message types the listener handles, and its handler
Writes:
  src/Volvo.TestRequestTool.Infrastructure/Contracts/Schemas/*.xsd   (embedded in the assembly)
  src/Volvo.TestRequestTool.Infrastructure/Contracts/listener.json   (the registry)

Only the standard library is used. Run it again when the contracts or the listener change.
"""
import json
import os
import re
import shutil
import sys
import xml.etree.ElementTree as ET

XS = '{http://www.w3.org/2001/XMLSchema}'
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'src', 'Volvo.TestRequestTool.Infrastructure', 'Contracts')

# What each message type is for, in a sentence. The listener code is the source of truth for the behaviour.
ABOUT = {
    'Ping': ('Ping', 'Checks that the listener answers. The reply is the text OK.'),
    'Info': ('Service information', 'Describes the running service: its version, environment, machine and the message types it handles.'),
    'AvailableUpdates': ('Available updates', 'Lists the software, hardware and kit updates available for a vehicle, per node.'),
    'NewSoftwareExists': ('New software exists', 'Says, per node, whether newer software exists than the software on the vehicle.'),
    'KitEvaluation': ('Kit evaluation', 'Evaluates conversion kits against a vehicle: which kits apply and what they change.'),
    'CampaignEvaluation': ('Campaign evaluation', 'Evaluates a campaign kit against a vehicle: applicable or not, and the nodes it assigns or removes.'),
    'Campaign': ('Campaign request', 'Applies a campaign to a vehicle and returns the campaign result.'),
    'CampaignRefresh': ('Campaign refresh', 'Refreshes the software of a vehicle in a campaign and returns the campaign result.'),
    'AmSoftwareRequest': ('Software request', 'Calculates the software update of a vehicle (aftermarket).'),
    'ConversionKit': ('Conversion kit request', 'Applies a conversion kit to a vehicle and returns the updated product.'),
    'AssignNodeNamesInKit': ('Assigned node names in kit', 'Lists the nodes that a kit assigns.'),
    'SpareCabBreakdownRequest': ('Spare cab breakdown', 'Breaks down the software of a spare cab ordered for a vehicle.'),
    'ReleaseNotes': ('Release notes', 'Returns the release notes of software parts.'),
    'ProdSoftwareBreakdown': ('Production software breakdown', 'Breaks down the software of a vehicle in production.'),
    'ProdConsistencyCheck': ('BOM consistency check', 'Checks that a production bill of material is consistent.'),
    'DevelopmentSoftwareBreakdownRequest': ('Development software breakdown', 'Breaks down the software of a development vehicle.'),
    'DevSoftwareBreakdownWithProduct': ('Development breakdown with product', 'Breaks down the software of a development vehicle given as a full product.'),
    'Evaluate': ('Evaluate', 'Evaluates variant expressions against a vehicle.'),
    'ParameterRecipe': ('Parameter recipe', 'Calculates the parameter recipe of a vehicle (Service Configurator).'),
    'NewSalesParameterRecipe': ('New sales parameter recipe', 'Calculates the parameter recipe of a new vehicle sale.'),
    'AftermarketParameterRecipe': ('Aftermarket parameter recipe', 'Calculates the parameter recipe in the aftermarket.'),
    'CapabilityResourceBreakdown': ('Capability resource breakdown', 'Breaks down the resources behind the capabilities of a vehicle.'),
    'VcadsSoftwareReplacement': ('VCADS software replacement', 'Software replacements for the nodes VCADS gives.'),
    'VcadsCompleteVehicleSoftwareReplacement': ('VCADS complete vehicle software replacement', 'Software replacements for every node of the vehicle.'),
    'VcadsHardwareReplacement': ('VCADS hardware replacement', 'Hardware replacements for the nodes VCADS gives.'),
    'VcadsCompleteVehicleHardwareReplacement': ('VCADS complete vehicle hardware replacement', 'Hardware replacements for every node of the vehicle.'),
    'VcadsKitInformation': ('VCADS kit information', 'Kit information for the kits VCADS gives.'),
    'VcadsCompleteVehicleKitInformation': ('VCADS complete vehicle kit information', 'Kit information for every kit of the vehicle.'),
    'VcadsCompleteVehicle': ('VCADS complete vehicle', 'The complete vehicle as VCADS sees it.'),
    'VcadsTestRequestSoftwareReplacement': ('VCADS software replacement (test request)', 'As VCADS software replacement, for the test request tool.'),
    'VcadsTestRequestCompleteVehicleSoftwareReplacement': ('VCADS complete vehicle software replacement (test request)', 'As VCADS complete vehicle software replacement, for the test request tool.'),
    'VcadsTestRequestHardwareReplacement': ('VCADS hardware replacement (test request)', 'As VCADS hardware replacement, for the test request tool.'),
    'VcadsTestRequestKitInformation': ('VCADS kit information (test request)', 'As VCADS kit information, for the test request tool.'),
    'ProductUpdateService': ('Product Update Service', 'T3: the product update of a vehicle, as JSON.'),
    'GetAvailableProductUpdates': ('Available Product Updates', 'T3: the updates available for a vehicle, as JSON.'),
}
AREA_ORDER = ['Audit', 'Aftermarket', 'Production', 'Development', 'ServiceConfigurator', 'VCADS_1_0']
# Handlers the registration does not name in full (an imported namespace or a factory method).
HANDLER = {
    ('Evaluate', '1.0'): 'Development/Evaluate_1_0',
    ('GetAvailableProductUpdates', '1.0'): 'Aftermarket/AvailableProductUpdates_1_0',
    ('GetAvailableProductUpdates', '1.1'): 'Aftermarket/AvailableProductUpdates_1_1',
}
# VCADS has one contract for every operation: the root elements of each.
VCADS_ROOT = {
    'VcadsSoftwareReplacement': 'GetSWReplacement',
    'VcadsTestRequestSoftwareReplacement': 'GetSWReplacement',
    'VcadsCompleteVehicleSoftwareReplacement': 'GetCompleteVehicleSWReplacement',
    'VcadsTestRequestCompleteVehicleSoftwareReplacement': 'GetCompleteVehicleSWReplacement',
    'VcadsHardwareReplacement': 'GetHWReplacement',
    'VcadsTestRequestHardwareReplacement': 'GetHWReplacement',
    'VcadsKitInformation': 'GetKitInformation',
    'VcadsTestRequestKitInformation': 'GetKitInformation',
    'VcadsCompleteVehicleKitInformation': 'GetCompleteVehicleKitInformation',
    'VcadsCompleteVehicle': 'GetCompleteVehicle',
}
# Replies SchemaSet.cs does not name, taken from the listener's handler instead (with the reason shown on the page).
REPLY = {
    ('AssignNodeNamesInKit', '1.0'): ('AssignedNodesInKitReply_1.1.3-Final.xsd', 'AssignedNodesInKitResponse',
        'SchemaSet.cs names version 1.1.2-Final, which is not among the contracts; the listener writes the 1.1 reply, so 1.1.3 is used.'),
    ('VcadsCompleteVehicleKitInformation', '1.0'): ('VCADS-1.0.1.xsd', 'Workflow',
        'SchemaSet.cs names no reply; the listener answers with a Workflow, as for GetVCADSKitInformation.'),
    ('SpareCabBreakdownRequest', '2.1'): ('ProductsUpdate_1.1.11-Final.xsd', 'ProductsUpdate',
        'SchemaSet.cs names no reply for 2.1; the listener answers with ProductsUpdate 1.1 (ProductsUpdate_1_1 ResponseCreator).'),
}
# Message types whose errors are another contract than their reply: ErrorReport 1.1 (ErrorResponseBuilder in the listener).
ERROR_REPLY = {('AssignNodeNamesInKit', '1.0'), ('AssignNodeNamesInKit', '2.0')}
# The VCADS handlers write the bare result as the reply root (the smoke-test replies and unit tests show it), not a
# …Response element: Workflow, HardwareResponse or CompleteVehicle.
VCADS_REPLY_ROOT = {k: ('HardwareResponse' if 'Hardware' in k else 'CompleteVehicle' if k == 'VcadsCompleteVehicle' else 'Workflow') for k in VCADS_ROOT}
AREA_NAME = {'VCADS_1_0': 'VCADS', 'ServiceConfigurator': 'Service Configurator'}


def read(path):
    with open(path, encoding='utf-8-sig') as f:
        return f.read()


def main(contracts, src):
    project = os.path.join(contracts, 'SoftwareBreakdown.Contracts')
    schemas_dir = os.path.join(project, 'Schemas')
    constants = dict(re.findall(r'public const string (\w+) = "([^"]+)";', read(os.path.join(project, 'MessageTypes.cs'))))

    # Every XSD: its target namespace, version and top-level elements.
    schemas = {}
    for name in sorted(os.listdir(schemas_dir)):
        if not name.endswith('.xsd'):
            continue
        root = ET.parse(os.path.join(schemas_dir, name)).getroot()
        schemas[name] = {
            'file': name,
            'namespace': root.get('targetNamespace') or '',
            'version': root.get('version') or '',
            'elements': [e.get('name') for e in root.findall(XS + 'element')],
        }

    def schema_for(ns, version):
        hits = [s for s in schemas.values() if s['namespace'] == ns and s['version'] == version]
        return hits[0]['file'] if hits else None

    # SchemaSet.cs: the request and the reply contract per message type and version.
    schema_set = read(os.path.join(project, 'SchemaSet.cs'))
    request_part, reply_part = schema_set.split('GetResponseXmlSchema', 1)
    pattern = r'MessageTypes\.(\w+) \+ "_([\d.]+)" => (?:GetSchemaXml\("([^"]+)", "([^"]+)"\)|"")'

    def contracts_of(part):
        found = {}
        for const, version, ns, ver in re.findall(pattern, part):
            if ns:
                file = schema_for(ns, ver)
                found[(const, version)] = {'namespace': ns, 'version': ver, 'file': file}
            else:
                found[(const, version)] = None
        return found
    requests, replies = contracts_of(request_part), contracts_of(reply_part)

    # The listener: every registered message type and the handler folder it resolves to.
    injector = read(os.path.join(src, 'NVSComponents', 'HostCommon', 'AbstractDependencyInjector.cs'))
    blocks = re.split(r'AddSingleton<IRequestMessageHandler>\(', injector)[1:]
    messages = []
    for block in blocks:
        m = re.match(r'\s*MessageTypes\.(\w+)\s*\+\s*"(TR)?_([\d.]+)"', block)
        if not m:
            continue
        const, tr, version = m.group(1), m.group(2), m.group(3)
        handler = re.search(r'Request\.Listener\.\s*(\w+)\.\s*(\w+)', block)
        area, folder = (handler.group(1), handler.group(2)) if handler else ('Other', '')
        if (const, version) in HANDLER:
            area, folder = HANDLER[(const, version)].split('/')
        if area not in AREA_ORDER:  # a handler at the top of the listener (for example VCADS_1_0.X)
            area = 'Other'
        title, about = ABOUT.get(const, (const, ''))
        # The two T3 services are newer than the MessageTypes.cs in the contracts: their constant name stands in for it.
        assumed = const not in constants
        if tr:
            title += ' (test request)'
            about = 'As ' + ABOUT[const][0].lower() + ', for the test request tool.'
        entry = {
            'messageType': constants.get(const, const) + ('TR' if tr else ''),
            'version': version,
            'name': const,
            'title': title,
            'about': about,
            'area': AREA_NAME.get(area, area),
            'handler': area + '/' + folder if folder else area,
            'request': requests.get((const, version), 'missing'),
            'reply': replies.get((const, version), 'missing'),
        }
        if assumed:
            entry['nameAssumed'] = True
        if const in ('ProductUpdateService', 'GetAvailableProductUpdates'):
            entry['request'] = entry['reply'] = {'json': True}
        messages.append(entry)
    order = {a: i for i, a in enumerate(AREA_NAME.get(a, a) for a in AREA_ORDER)}
    messages.sort(key=lambda e: (order.get(e['area'], 99), e['title'], [int(p) for p in e['version'].split('.')]))

    for e in messages:
        key = (e['name'], e['version'])
        if key in REPLY:
            file, root, note = REPLY[key]
            e['reply'] = {'namespace': schemas[file]['namespace'], 'version': schemas[file]['version'], 'file': file, 'root': root, 'note': note}
        if key in ERROR_REPLY:
            f = 'ErrorReport_1.1.0-Final.xsd'
            e['errorReply'] = {'namespace': schemas[f]['namespace'], 'version': schemas[f]['version'], 'file': f, 'root': 'ErrorReport'}

    # A contract SchemaSet.cs does not name is "missing": the listener still answers, the tool cannot check it.
    for e in messages:
        for side in ('request', 'reply'):
            if e[side] == 'missing':
                e[side] = {'missing': True}

    # Root elements: the global element of the contract that starts the message (Get… asks, Show… or …Response answers).
    def root_of(elements, side, name):
        if name in VCADS_ROOT:
            return VCADS_ROOT[name] if side == 'request' else VCADS_REPLY_ROOT[name]
        if len(elements) == 1:
            return elements[0]
        if side == 'request':
            hits = [x for x in elements if x.startswith('Get') and not x.endswith('Response')]
        else:
            hits = [x for x in elements if x.startswith('Show') or x.endswith('Response')]
        return hits[0] if hits else None
    for e in messages:
        for side in ('request', 'reply'):
            c = e[side]
            if c and c.get('file') and not c.get('root'):
                c['root'] = root_of(schemas[c['file']]['elements'], side, e['name'])
                if c['root'] and c['root'] not in schemas[c['file']]['elements']:
                    c['root'] = None

    os.makedirs(os.path.join(OUT, 'Schemas'), exist_ok=True)
    for name in os.listdir(os.path.join(OUT, 'Schemas')):
        os.remove(os.path.join(OUT, 'Schemas', name))
    for name in schemas:
        shutil.copyfile(os.path.join(schemas_dir, name), os.path.join(OUT, 'Schemas', name))

    registry = {
        '$meta': {
            'source': 'Request.Listener (swb-stable1) and SoftwareBreakdown.Contracts',
            'messages': len(messages),
            'schemas': len(schemas),
        },
        'messages': messages,
        'schemas': [{k: v for k, v in s.items() if k != 'elements'} for s in schemas.values()],
    }
    with open(os.path.join(OUT, 'listener.json'), 'w', encoding='utf-8', newline='\n') as f:
        json.dump(registry, f, indent=2, ensure_ascii=False)
        f.write('\n')
    missing = [f"{e['messageType']}_{e['version']} {side}" for e in messages for side in ('request', 'reply') if e[side] and (e[side].get("missing") or (e[side].get("namespace") and not e[side].get("file")))]
    print(f'{len(messages)} message types, {len(schemas)} schemas.')
    if missing:
        print('No contract in SchemaSet.cs for: ' + ', '.join(missing))


if __name__ == '__main__':
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2])
