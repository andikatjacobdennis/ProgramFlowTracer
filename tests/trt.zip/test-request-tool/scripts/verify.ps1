$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
& (Join-Path $PSScriptRoot 'Assert-Sdk.ps1')
dotnet restore TestRequestTool.slnx
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
dotnet build TestRequestTool.slnx --configuration Release --no-restore
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
dotnet test TestRequestTool.slnx --configuration Release --no-build --logger trx '--collect:XPlat Code Coverage'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
if (Get-Command node -ErrorAction SilentlyContinue) {
  foreach ($test in Get-ChildItem tests/frontend/*.cjs) {
    node $test.FullName
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
  }
}
