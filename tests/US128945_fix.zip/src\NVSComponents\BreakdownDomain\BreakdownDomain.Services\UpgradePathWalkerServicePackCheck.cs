﻿using Proxy.Matrix;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Baseline;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Conditions;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ConversionKit;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Notifications;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ParameterData;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ProductDefinition;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Request;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Sources;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.UpgradePath;

namespace Volvo.SoftwareBreakdown.BreakdownDomain.Services
{
    /// <summary>
    /// Concrete <see cref="IServicePackUpgradePathCheck"/> that uses
    /// <see cref="IServicePackCompatibilityResolver"/> and <see cref="IUpgradePathWalkerService"/>
    /// to decide whether a candidate service pack has a valid SW upgrade path
    /// for the current installation.
    /// Register this in DI to activate upgrade-path validation inside
    /// <see cref="ServicePackUpdater.UpdateToServicePack"/>.
    /// </summary>
    public sealed class UpgradePathWalkerServicePackCheck : IServicePackUpgradePathCheck
    {

        private readonly IServicePackCompatibilityResolver _compatibilityResolver;
        private readonly IUpgradePathWalkerService _upgradePathWalker;

        public UpgradePathWalkerServicePackCheck(
            IServicePackCompatibilityResolver compatibilityResolver,
            IUpgradePathWalkerService upgradePathWalker)
        {
            _compatibilityResolver = compatibilityResolver;
            _upgradePathWalker = upgradePathWalker;
        }

        public async Task<ServicePackUpgradePathCheckResult> IsValidUpgradePathAsync(
            ServicePackReference candidate,
            Installation installation,
            IEnumerable<IProductContainer> products,
            IProductSpecification productSpecification,
            CancellationToken cancellationToken = default)
        {
            // HPC Node Check,  no products or no HPC nodes this we can skip then.
            var productList = (products?.ToList() is { Count: > 0 } p)
                ? p
                : installation?.Products.Select(ip => ip.ToProductContainer()).ToList<IProductContainer>()
                    ?? new List<IProductContainer>();

            var installationHpcNodes = installation?.Products
                ?.FirstOrDefault()?.BillOfMaterial?.HpcNodes;

            var hasHpcNodes = _compatibilityResolver.CheckIfRequestHasAnyHpcNode(productList)
                || (installationHpcNodes != null && installationHpcNodes.Any());

            if (!hasHpcNodes)
            {
                Serilog.Log.Information(
                    "Upgrade path check skipped for service pack {Id}: no HPC node found in request.", candidate.Id);
                return ServicePackUpgradePathCheckResult.Skipped("No HPC nodes present in request.");
            }

            // Fallback: derive productSpecification from installation if not provided
            var spec = productSpecification
                ?? installation.Products.FirstOrDefault()?.ProductSpecification;

            // Extract the request Context from the installation's first product BillOfMaterial.
            // Context.Id is used inside FindFirstCompatibleServicePackAsync for install-scenario tracing.
            var requestContext = installation?.Products?.FirstOrDefault()?.BillOfMaterial?.Context;

            if (!Guid.TryParse(requestContext?.Id, out _))
                return ServicePackUpgradePathCheckResult.Invalid("Missing or invalid contextId for upgrade path evaluation.");

            var result = await _compatibilityResolver.FindFirstCompatibleServicePackAsync(
                _upgradePathWalker,
                new List<ServicePackReference> { candidate },
                productList,
                spec,
                requestContext,
                cancellationToken).ConfigureAwait(false);

            if (!result.Success)
                return ServicePackUpgradePathCheckResult.Invalid(result.ErrorMessage);

            ThrowIfSoftwareProductsSetDifferentParameterValues(result.ProductResults, spec?.ProductClassCode);

            var accumulatedTransitions = result.ProductResults
                ?.Where(pr => pr?.Result?.UpgradePathTransitions != null)
                .SelectMany(pr => pr.Result.UpgradePathTransitions)
                .GroupBy(kvp => kvp.Key)
                .ToDictionary(g => g.Key, g => g.Select(kvp => kvp.Value).ToList())
                ?? new Dictionary<int, List<IKit>>();

            var stepExecutionResults = result.ProductResults
                ?.Where(pr => pr?.Result?.StepExecutionResults != null)
                .SelectMany(pr => pr.Result.StepExecutionResults)
                .ToList()
                ?? new List<UpgradePathStepExecutionResult>();

            return ServicePackUpgradePathCheckResult.ValidWithTransitions(accumulatedTransitions, stepExecutionResults);
        }

        /// <summary>
        /// The transitions of all software products are later applied one after the other, where the last
        /// transition silently overwrites a parameter value set by an earlier one. Report it as an error when
        /// two software products set the same parameter to different values.
        /// </summary>
        public static void ThrowIfSoftwareProductsSetDifferentParameterValues(
            IEnumerable<PerProductUpgradeResult<UpgradePathWalkResult>> productResults, string productClassCode)
        {
            var parametersPerSoftwareProduct = (productResults ?? Enumerable.Empty<PerProductUpgradeResult<UpgradePathWalkResult>>())
                .Where(pr => pr?.Result?.StepExecutionResults != null)
                .Select(pr => GetFinalParameters(pr, productClassCode))
                .ToList();

            var notifications = new List<BaseNotification>();
            foreach (var parametersForDefinition in parametersPerSoftwareProduct
                         .SelectMany(p => p)
                         .GroupBy(p => p.Value.ParameterDefinition))
            {
                var parameters = parametersForDefinition.ToList();
                var firstParameter = parameters[0];
                foreach (var otherParameter in parameters.Skip(1))
                {
                    if (firstParameter.Value.EnumerateDifferences(otherParameter.Value).Any())
                    {
                        notifications.Add(new DoubleParameterValues(firstParameter, otherParameter));
                    }
                }
            }

            if (notifications.Count > 0)
            {
                throw new UpgradePathParameterConflictException(notifications);
            }
        }

        /// <summary>
        /// Steps within one software product's upgrade path are applied in order, so the last step
        /// that sets a parameter decides its value for that software product.
        /// </summary>
        private static IEnumerable<BillOfMaterialContent<BaseParameter>> GetFinalParameters(
            PerProductUpgradeResult<UpgradePathWalkResult> productResult, string productClassCode)
        {
            var finalParameters = new Dictionary<BaseParameterDefinition, BillOfMaterialContent<BaseParameter>>();

            foreach (var step in productResult.Result.StepExecutionResults.Where(s => s != null).OrderBy(s => s.StepNumber))
            {
                var parameters = (step.AddedParameters ?? Enumerable.Empty<BillOfMaterialContent<ParameterDataLink>>())
                    .Where(p => p?.Value?.Parameters != null)
                    .SelectMany(p => p.Value.Parameters)
                    .Where(p => p?.ParameterDefinition != null);

                foreach (var parameter in parameters)
                {
                    var source = new SoftwareProductTemplateSource(productClassCode, new AlwaysMatchCondition(),
                        Guid.Empty, GetSoftwareProductDescription(productResult.ProductName, step.TransitionPackageId),
                        step.PackageId);

                    finalParameters[parameter.ParameterDefinition] = new BillOfMaterialContent<BaseParameter>(parameter, source);
                }
            }

            return finalParameters.Values;
        }

        private static string GetSoftwareProductDescription(string productName, string transitionPackageId)
        {
            return string.IsNullOrWhiteSpace(transitionPackageId)
                ? productName
                : $"{productName} (transition {transitionPackageId})";
        }
    }

    public static class ProductContainerExtensions
    {
        /// <summary>
        /// Builds an <see cref="IProductContainer"/> from an <see cref="IProduct"/>,
        /// mapping all properties available on <see cref="IProductSpecification"/>
        /// and <see cref="IBillOfMaterial"/>.
        /// </summary>
        public static IProductContainer ToProductContainer(this IProduct product)
        {
            var spec = product.ProductSpecification;
            var bom = product.BillOfMaterial;

            return new ProductContainer
            {
                ChassisSeries = spec.ChassisSeries,
                ChassisNumber = spec.ChassisNumber,
                Vin = spec.Vin,
                CompanyCode = spec.CompanyCode,
                AssemblyDate = spec.AssemblyDate,
                AssemblyFactory = spec.AssemblyFactory,
                DeliveryDate = spec.DeliveryDate,
                SpecificationDate = spec.SpecificationDate,
                Variants = spec.Variants,
                SNotes = spec.ExtendedSNotes,
                ProductNodes = bom.Nodes,
                ProductHpcNodes = bom.HpcNodes,
                HardwareComponents = product.HardwareComponents,
                // SalesCodes, ModelId, ProductClassId, etc. — populate if available
            };
        }
    }
}