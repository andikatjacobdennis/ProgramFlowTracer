using System.Collections.Generic;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Notifications;

namespace Volvo.SoftwareBreakdown.BreakdownDomain.Services
{
    /// <summary>
    /// Thrown when the upgrade paths of different software products set the same parameter to different values.
    /// Unlike other service pack rejections it must not fall back to an older service pack, since that would
    /// hide the conflict from the requester.
    /// </summary>
    public class UpgradePathParameterConflictException : NotificationException
    {
        public UpgradePathParameterConflictException(IEnumerable<BaseNotification> notifications) : base(notifications)
        {
        }
    }
}
