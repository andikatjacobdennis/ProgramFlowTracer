using Microsoft.VisualStudio.TestTools.UnitTesting;
using Proxy.Matrix;
using System.Collections.Generic;
using System.Linq;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Baseline;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Conditions;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Notifications;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ParameterData;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ProductDefinition;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.UpgradePath;

namespace Volvo.SoftwareBreakdown.BreakdownDomain.Services.UnitTests
{
    [TestClass]
    public class UpgradePathWalkerServicePackCheckTest
    {
        private readonly Tea2ParameterDefinition _chano = new("CHANO", "<xml />", false, true, false);
        private readonly Tea2ParameterDefinition _vinno = new("VINNO", "<xml />", false, true, false);

        [TestMethod]
        public void SameParameterSetToDifferentValuesByDifferentSoftwareProducts_ThrowsDoubleParameterValues()
        {
            var productResults = new List<PerProductUpgradeResult<UpgradePathWalkResult>>
            {
                CreateProductResult("AVAP VCM Linux RootFS", CreateStep(1, "Transition_2", _chano.CreateParameter("CHANO1"))),
                CreateProductResult("AVAP VCM Service Adapter Quality Manager", CreateStep(1, "Transition_33044", _chano.CreateParameter("CHANO2")))
            };

            var exception = Assert.ThrowsException<UpgradePathParameterConflictException>(() =>
                UpgradePathWalkerServicePackCheck.ThrowIfSoftwareProductsSetDifferentParameterValues(productResults, "B1"));

            var notification = exception.Notification as DoubleParameterValues;
            Assert.IsNotNull(notification);
            Assert.AreEqual(ErrorCode.ParameterError, exception.GetErrorCode());
            Assert.AreEqual("CHANO is set to both CHANO1 and CHANO2.", notification.GetText());
            Assert.AreEqual(
                "Software product AVAP VCM Linux RootFS (transition Transition_2) sets CHANO = CHANO1 and " +
                "software product AVAP VCM Service Adapter Quality Manager (transition Transition_33044) sets CHANO = CHANO2.",
                notification.GetReason());
        }

        [TestMethod]
        public void SameParameterSetToSameValueByDifferentSoftwareProducts_DoesNotThrow()
        {
            var productResults = new List<PerProductUpgradeResult<UpgradePathWalkResult>>
            {
                CreateProductResult("Product A", CreateStep(1, "T1", _chano.CreateParameter("CHANO1"))),
                CreateProductResult("Product B", CreateStep(1, "T2", _chano.CreateParameter("CHANO1")))
            };

            UpgradePathWalkerServicePackCheck.ThrowIfSoftwareProductsSetDifferentParameterValues(productResults, "B1");
        }

        [TestMethod]
        public void DifferentParametersSetByDifferentSoftwareProducts_DoesNotThrow()
        {
            var productResults = new List<PerProductUpgradeResult<UpgradePathWalkResult>>
            {
                CreateProductResult("Product A", CreateStep(1, "T1", _chano.CreateParameter("CHANO1"))),
                CreateProductResult("Product B", CreateStep(1, "T2", _vinno.CreateParameter("VIN1")))
            };

            UpgradePathWalkerServicePackCheck.ThrowIfSoftwareProductsSetDifferentParameterValues(productResults, "B1");
        }

        [TestMethod]
        public void LaterStepInSameSoftwareProductOverridesEarlierStep_DoesNotThrow()
        {
            var productResults = new List<PerProductUpgradeResult<UpgradePathWalkResult>>
            {
                CreateProductResult("Product A",
                    CreateStep(1, "T1", _chano.CreateParameter("CHANO1")),
                    CreateStep(2, "T2", _chano.CreateParameter("CHANO2"))),
                CreateProductResult("Product B", CreateStep(1, "T3", _chano.CreateParameter("CHANO2")))
            };

            UpgradePathWalkerServicePackCheck.ThrowIfSoftwareProductsSetDifferentParameterValues(productResults, "B1");
        }

        [TestMethod]
        public void NoProductResults_DoesNotThrow()
        {
            UpgradePathWalkerServicePackCheck.ThrowIfSoftwareProductsSetDifferentParameterValues(null, "B1");
        }

        private static PerProductUpgradeResult<UpgradePathWalkResult> CreateProductResult(string productName,
            params UpgradePathStepExecutionResult[] steps)
        {
            return new PerProductUpgradeResult<UpgradePathWalkResult>
            {
                ProductName = productName,
                Success = true,
                Result = new UpgradePathWalkResult
                {
                    Success = true,
                    StepExecutionResults = steps.ToList()
                }
            };
        }

        private static UpgradePathStepExecutionResult CreateStep(int stepNumber, string transitionPackageId,
            BaseParameter parameter)
        {
            var parameterDataLink = new ParameterDataLink(0, "", "", "B1", 0, 0, 1,
                new List<BaseParameter> { parameter }, new List<BaseCondition>(), "");

            return new UpgradePathStepExecutionResult
            {
                StepNumber = stepNumber,
                PackageId = $"{transitionPackageId}_Snapshot",
                TransitionPackageId = transitionPackageId,
                AddedParameters = new List<BillOfMaterialContent<ParameterDataLink>>
                {
                    new(parameterDataLink)
                }
            };
        }
    }
}
