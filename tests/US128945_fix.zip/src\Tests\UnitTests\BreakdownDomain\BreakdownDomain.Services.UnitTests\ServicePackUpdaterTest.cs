﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Artifacts;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Notifications;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ProductDefinition;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ReplacementChains;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Request;

namespace Volvo.SoftwareBreakdown.BreakdownDomain.Services.UnitTests
{
    [TestClass]
    public class ServicePackUpdaterTest
    {
        [TestMethod]
        [ExpectedException(typeof(NotificationException))]
        public void UpdateToServicePackRequiresMultiNode()
        {
            var sut = new ServicePackUpdater(null,null);

            sut.UpdateToServicePack(null, null, null, null, false, false,
                Model.Request.RemoteSoftwareDownloadScenario
                    .NotApplicable, false, DateTime.MaxValue, true, new List<DistributionMethod>());
        }

        [TestMethod]
        public void UpdateToServicePackOk()
        {
            var productSpecification = new Mock<IProductSpecification>();
            productSpecification.Setup(p => p.PaddedChassisId).Returns("A-123");
            productSpecification.Setup(p => p.ChassisSeries).Returns("A");
            productSpecification.Setup(p => p.ChassisNumber).Returns("123");

            var mockSoftwareUpgrader = new Mock<ISoftwareUpgrader>();
            var mockUpgradePathCheck = new Mock<IServicePackUpgradePathCheck>();
            var mockProduct = new Mock<IProduct>();
            mockProduct.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);

            var sut = new ServicePackUpdater(mockSoftwareUpgrader.Object, mockUpgradePathCheck.Object);

            var servicePackReferences = new List<ServicePackReference>
            {
                new ServicePackReference(1,"GUID1",ServicePackState.Released,"SP1", null,1, 1, new List<(string, string)>()),
                new ServicePackReference(2,"GUID2",ServicePackState.Released,"SP2", DateTime.MinValue,2, 1, new List<(string, string)>()),
            };
            var servicePackNodeDictionary = new Dictionary<ServicePackReference, Dictionary<ProductNodeIdentification, int>>
            {
                {servicePackReferences[0], new Dictionary<ProductNodeIdentification, int>{{new NodeName(1,1,"1.1").WithProduct(mockProduct.Object),12345678}}},
                {servicePackReferences.Last(), new Dictionary<ProductNodeIdentification, int>{{new NodeName(1,1,"1.1").WithProduct(mockProduct.Object), 55724567}}}
            };

            var requestMetaData = new Mock<IRequestMetadata>();

            var billOfMaterial = new Mock<IBillOfMaterial>();

            var mockProductWithServicePackDocumentNumbers = new Mock<IProduct>();
            mockProduct.Setup(p => p.RequestMetadata).Returns(requestMetaData.Object);
            mockProductWithServicePackDocumentNumbers.Setup(p => p.RequestMetadata).Returns(requestMetaData.Object);
            mockProduct.Setup(p => p.BillOfMaterial).Returns(billOfMaterial.Object);
            mockProductWithServicePackDocumentNumbers.Setup(p => p.BillOfMaterial).Returns(billOfMaterial.Object);

            mockUpgradePathCheck.Setup(m => m.IsValidUpgradePathAsync(
                It.IsAny<ServicePackReference>(), It.IsAny<Installation>(), It.IsAny<IEnumerable<IProductContainer>>(),
                It.IsAny<IProductSpecification>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(ServicePackUpgradePathCheckResult.Valid);

            var mockSoftwareUpgradeService = new Mock<ISoftwareUpgradeService>();
            mockSoftwareUpgradeService.Setup(s => s.GetAvailableServicePackReferences(It.IsAny<Installation>())).Returns(
                new System.Tuple<IEnumerable<ServicePackReference>, IDictionary<ServicePackReference, Dictionary<ProductNodeIdentification, int>>>(servicePackReferences, servicePackNodeDictionary));
            mockSoftwareUpgrader.Setup(s => s.BatchUpgradeSoftware(It.IsAny<ISoftwareUpgradeService>(), It.IsAny<Installation>(),
                It.IsAny<IBreakdownReplacementChainFilter>(), It.IsAny<BatchUpgradeOptions>(),
                null, It.IsAny<DateTime>(), false, true, false, false)).Returns(new Installation(mockProduct.Object));

            var (resultInstallation, resultServicePack, resultUpgradePathStepExecutionResults) = sut.UpdateToServicePack(mockSoftwareUpgradeService.Object, new Installation(mockProduct.Object), new IntroducedReplacementChainFilter(), null, false, true,
                    Model.Request.RemoteSoftwareDownloadScenario.NotApplicable, false, DateTime.MaxValue, true, new List<DistributionMethod>());

            Assert.IsNotNull(resultInstallation);
            Assert.AreEqual(mockProduct.Object, resultInstallation.Products.Single());
            Assert.IsNotNull(resultServicePack);
            Assert.AreEqual("GUID2", resultServicePack.Guid);

            mockSoftwareUpgradeService.VerifyAll();
            mockSoftwareUpgrader.VerifyAll();
            requestMetaData.VerifyAll();
            billOfMaterial.VerifyAll();
        }

        [TestMethod]
        public void UpdateToServicePack_HasStaggeredAvailability()
        {
            var productSpecification = new Mock<IProductSpecification>();
            productSpecification.Setup(p => p.PaddedChassisId).Returns("A-123");
            productSpecification.Setup(p => p.ChassisSeries).Returns("A");
            productSpecification.Setup(p => p.ChassisNumber).Returns("123");

            var mockSoftwareUpgrader = new Mock<ISoftwareUpgrader>();
            var mockUpgradePathCheck = new Mock<IServicePackUpgradePathCheck>();
            var mockProduct = new Mock<IProduct>();
            mockProduct.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);

            var sut = new ServicePackUpdater(mockSoftwareUpgrader.Object, mockUpgradePathCheck.Object);

            var servicePackReferences = new List<ServicePackReference>
            {
                new ServicePackReference(1,"GUID1",ServicePackState.Released,"SP1", null,1, 1, new List<(string, string)>()),
                new ServicePackReference(2,"GUID2",ServicePackState.Released,"SP2", DateTime.MinValue,2, 1, new List<(string, string)>()),
            };
            var servicePackNodeDictionary = new Dictionary<ServicePackReference, Dictionary<ProductNodeIdentification, int>>
            {
                {servicePackReferences[0],new Dictionary<ProductNodeIdentification, int>{{new NodeName(1,1,"1.1").WithProduct(mockProduct.Object),12345678}}},
                {servicePackReferences.Last(),new Dictionary<ProductNodeIdentification, int>{{new NodeName(1,1,"1.1").WithProduct(mockProduct.Object), 55724567}}}
            };

            var requestMetaData = new Mock<IRequestMetadata>();

            var billOfMaterial = new Mock<IBillOfMaterial>();

            var mockProductWithServicePackDocumentNumbers = new Mock<IProduct>();
            mockProduct.Setup(p => p.RequestMetadata).Returns(requestMetaData.Object);
            mockProductWithServicePackDocumentNumbers.Setup(p => p.RequestMetadata).Returns(requestMetaData.Object);
            mockProduct.Setup(p => p.BillOfMaterial).Returns(billOfMaterial.Object);
            mockProductWithServicePackDocumentNumbers.Setup(p => p.BillOfMaterial).Returns(billOfMaterial.Object);

            var mockSoftwareUpgradeService = new Mock<ISoftwareUpgradeService>();
            mockSoftwareUpgradeService.Setup(s => s.GetAvailableServicePackReferences(It.IsAny<Installation>())).Returns(
                new System.Tuple<IEnumerable<ServicePackReference>, IDictionary<ServicePackReference, Dictionary<ProductNodeIdentification, int>>>(servicePackReferences, servicePackNodeDictionary));
            mockSoftwareUpgrader.Setup(s => s.BatchUpgradeSoftware(It.IsAny<ISoftwareUpgradeService>(), It.IsAny<Installation>(),
                It.IsAny<IBreakdownReplacementChainFilter>(), It.IsAny<BatchUpgradeOptions>(),
                null, It.IsAny<DateTime>(), false, true, false, false)).Returns(new Installation(mockProduct.Object));
            mockUpgradePathCheck.Setup(c => c.IsValidUpgradePathAsync(It.IsAny<ServicePackReference>(), It.IsAny<Installation>(),
                It.IsAny<IEnumerable<IProductContainer>>(), It.IsAny<IProductSpecification>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(ServicePackUpgradePathCheckResult.Valid);

            var (resultInstallation, resultServicePack, resultUpgradePathStepExecutionResults) = sut.UpdateToServicePack(mockSoftwareUpgradeService.Object, new Installation(mockProduct.Object), new IntroducedReplacementChainFilter(), null, false, true,
                Model.Request.RemoteSoftwareDownloadScenario.NotApplicable, false, DateTime.MaxValue, true, new List<DistributionMethod>());

            Assert.IsNotNull(resultInstallation);
            Assert.AreEqual(mockProduct.Object, resultInstallation.Products.Single());
            Assert.IsNotNull(resultServicePack);
            Assert.AreEqual("GUID2", resultServicePack.Guid);

            mockSoftwareUpgradeService.VerifyAll();
            mockSoftwareUpgrader.VerifyAll();
            requestMetaData.VerifyAll();
            billOfMaterial.VerifyAll();
        }

        [TestMethod]
        public void UpdateToServicePack_ParameterConflictInUpgradePath_DoesNotFallBackToOlderServicePack()
        {
            var productSpecification = new Mock<IProductSpecification>();
            productSpecification.Setup(p => p.PaddedChassisId).Returns("A-123");
            productSpecification.Setup(p => p.ChassisSeries).Returns("A");
            productSpecification.Setup(p => p.ChassisNumber).Returns("123");

            var mockSoftwareUpgrader = new Mock<ISoftwareUpgrader>();
            var mockUpgradePathCheck = new Mock<IServicePackUpgradePathCheck>();
            var mockProduct = new Mock<IProduct>();
            mockProduct.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);
            mockProduct.Setup(p => p.RequestMetadata).Returns(new Mock<IRequestMetadata>().Object);
            mockProduct.Setup(p => p.BillOfMaterial).Returns(new Mock<IBillOfMaterial>().Object);

            var sut = new ServicePackUpdater(mockSoftwareUpgrader.Object, mockUpgradePathCheck.Object);

            var servicePackReferences = new List<ServicePackReference>
            {
                new ServicePackReference(1,"GUID1",ServicePackState.Released,"SP1", null,1, 1, new List<(string, string)>()),
                new ServicePackReference(2,"GUID2",ServicePackState.Released,"SP2", DateTime.MinValue,2, 1, new List<(string, string)>()),
            };
            var servicePackNodeDictionary = new Dictionary<ServicePackReference, Dictionary<ProductNodeIdentification, int>>
            {
                {servicePackReferences[0],new Dictionary<ProductNodeIdentification, int>{{new NodeName(1,1,"1.1").WithProduct(mockProduct.Object),12345678}}},
                {servicePackReferences.Last(),new Dictionary<ProductNodeIdentification, int>{{new NodeName(1,1,"1.1").WithProduct(mockProduct.Object), 55724567}}}
            };

            var mockSoftwareUpgradeService = new Mock<ISoftwareUpgradeService>();
            mockSoftwareUpgradeService.Setup(s => s.GetAvailableServicePackReferences(It.IsAny<Installation>())).Returns(
                new System.Tuple<IEnumerable<ServicePackReference>, IDictionary<ServicePackReference, Dictionary<ProductNodeIdentification, int>>>(servicePackReferences, servicePackNodeDictionary));
            mockUpgradePathCheck.Setup(c => c.IsValidUpgradePathAsync(It.IsAny<ServicePackReference>(), It.IsAny<Installation>(),
                It.IsAny<IEnumerable<IProductContainer>>(), It.IsAny<IProductSpecification>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(ServicePackUpgradePathCheckResult.Valid);
            mockUpgradePathCheck.Setup(c => c.IsValidUpgradePathAsync(It.Is<ServicePackReference>(s => s.Guid == "GUID2"), It.IsAny<Installation>(),
                It.IsAny<IEnumerable<IProductContainer>>(), It.IsAny<IProductSpecification>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new UpgradePathParameterConflictException(new List<BaseNotification>
                {
                    new NoValidConfiguration(false, "CHANO is set to different values.", ErrorCode.ParameterError)
                }));

            var exception = Assert.ThrowsException<NotificationException>(() => sut.UpdateToServicePack(mockSoftwareUpgradeService.Object,
                new Installation(mockProduct.Object), new IntroducedReplacementChainFilter(), null, false, true,
                Model.Request.RemoteSoftwareDownloadScenario.NotApplicable, false, DateTime.MaxValue, true, new List<DistributionMethod>()));

            Assert.AreEqual(ErrorCode.ParameterError, exception.GetErrorCode());
            StringAssert.Contains(exception.Message, "Could not update to SP2!");
            mockSoftwareUpgrader.Verify(s => s.BatchUpgradeSoftware(It.IsAny<ISoftwareUpgradeService>(), It.IsAny<Installation>(),
                It.IsAny<IBreakdownReplacementChainFilter>(), It.IsAny<BatchUpgradeOptions>(), It.IsAny<IAftermarketCalculationService>(),
                It.IsAny<DateTime>(), It.IsAny<bool>(), It.IsAny<bool>(), It.IsAny<bool>(), It.IsAny<bool>()), Times.Never);
        }

        [TestMethod]
        public void UpdateToServicePack_DoesNotHaveStaggeredAvailability()
        {
            var productSpecification = new Mock<IProductSpecification>();
            productSpecification.Setup(p => p.PaddedChassisId).Returns("A-123");
            productSpecification.Setup(p => p.ChassisSeries).Returns("A");
            productSpecification.Setup(p => p.ChassisNumber).Returns("123");

            var billOfMaterial = new Mock<IBillOfMaterial>();

            var mockSoftwareUpgrader = new Mock<ISoftwareUpgrader>();
            var mockUpgradePathCheck = new Mock<IServicePackUpgradePathCheck>();
            var mockProduct = new Mock<IProduct>();
            mockProduct.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);
            mockProduct.Setup(p => p.BillOfMaterial).Returns(billOfMaterial.Object);

            var sut = new ServicePackUpdater(mockSoftwareUpgrader.Object, mockUpgradePathCheck.Object);

            var servicePackReferences = new List<ServicePackReference>
            {
                new ServicePackReference(1,"GUID1",ServicePackState.Released,"SP1", null,1, 1, new List<(string, string)>(){ ("A", "12345") }),
                new ServicePackReference(2,"GUID2",ServicePackState.Released,"SP2", DateTime.MinValue,2, 1, new List<(string, string)>(){ ("A", "12345") }),
            };
            var servicePackNodeDictionary = new Dictionary<ServicePackReference, Dictionary<ProductNodeIdentification, int>>
            {
                {servicePackReferences[0],new Dictionary<ProductNodeIdentification, int>{{new NodeName(1,1,"1.1").WithProduct(mockProduct.Object),12345678}}},
                {servicePackReferences.Last(),new Dictionary<ProductNodeIdentification, int>{{new NodeName(1,1,"1.1").WithProduct(mockProduct.Object), 55724567}}}
            };

            var requestMetaData = new Mock<IRequestMetadata>();

            var mockProductWithServicePackDocumentNumbers = new Mock<IProduct>();
            mockProduct.Setup(p => p.RequestMetadata).Returns(requestMetaData.Object);
            mockProductWithServicePackDocumentNumbers.Setup(p => p.RequestMetadata).Returns(requestMetaData.Object);
            mockProduct.Setup(p => p.BillOfMaterial).Returns(billOfMaterial.Object);
            mockProductWithServicePackDocumentNumbers.Setup(p => p.BillOfMaterial).Returns(billOfMaterial.Object);

            var mockSoftwareUpgradeService = new Mock<ISoftwareUpgradeService>();
            mockSoftwareUpgradeService.Setup(s => s.GetAvailableServicePackReferences(It.IsAny<Installation>())).Returns(
                new Tuple<IEnumerable<ServicePackReference>, IDictionary<ServicePackReference, Dictionary<ProductNodeIdentification, int>>>(servicePackReferences, servicePackNodeDictionary));

            try
            {
                sut.UpdateToServicePack(mockSoftwareUpgradeService.Object, new Installation(mockProduct.Object),
                    new IntroducedReplacementChainFilter(), null, false, true,
                    Model.Request.RemoteSoftwareDownloadScenario
                        .NotApplicable, false, DateTime.MaxValue, true, new List<DistributionMethod>());
                Assert.Fail("Should not reach");
            }
            catch (Exception e)
            {
                Assert.AreEqual("Could not update to SP2! Service pack is blocked since it is not available for the products A-123!", e.Message);
            }

            productSpecification.VerifyAll();
            mockSoftwareUpgradeService.VerifyAll();
            mockSoftwareUpgrader.VerifyAll();
            requestMetaData.VerifyAll();
            billOfMaterial.VerifyAll();
        }

        [TestMethod]
        [ExpectedException(typeof(NotificationException))]
        public void UpdateToServicePackFailNoServicePackFound()
        {
            var mockSoftwareUpgrader = new Mock<ISoftwareUpgrader>();
            var mockUpgradePathCheck = new Mock<IServicePackUpgradePathCheck>();
            var mockProduct = new Mock<IProduct>();

            var sut = new ServicePackUpdater(mockSoftwareUpgrader.Object, mockUpgradePathCheck.Object);

            var servicePackReferences = new List<ServicePackReference>
            {
                new ServicePackReference(1,"GUID1",ServicePackState.Released,"SP1", null,1, 1, new List<(string, string)>()),
                new ServicePackReference(2,"GUID2",ServicePackState.Released,"SP2", null,2, 1, new List<(string, string)>()),
            };
            var servicePackNodeDictionary = new Dictionary<ServicePackReference, Dictionary<ProductNodeIdentification, int>>
            {
                {servicePackReferences[0],new Dictionary<ProductNodeIdentification, int>{{new NodeName(1,1,"1.1").WithProduct(mockProduct.Object), 12345678}}},
                {servicePackReferences.Last(),new Dictionary<ProductNodeIdentification, int>{{new NodeName(1,1,"1.1").WithProduct(mockProduct.Object), 55724567}}}
            };

            var mockProductWithServicePackDocumentNumbers = new Mock<IProduct>();

            var mockSoftwareUpgradeService = new Mock<ISoftwareUpgradeService>();
            mockSoftwareUpgradeService.Setup(s => s.GetAvailableServicePackReferences(It.IsAny<Installation>())).Returns(
                new System.Tuple<IEnumerable<ServicePackReference>, IDictionary<ServicePackReference, Dictionary<ProductNodeIdentification, int>>>(servicePackReferences, servicePackNodeDictionary));

            mockSoftwareUpgrader.Setup(s => s.BatchUpgradeSoftware(It.IsAny<ISoftwareUpgradeService>(), It.IsAny<Installation>(),
                It.IsAny<IBreakdownReplacementChainFilter>(), It.IsAny<BatchUpgradeOptions>(),
                null, It.IsAny<DateTime>(), false, true, false, false)).Throws(new System.Exception());

            var (resultInstallation, resultServicePack, resultUpgradePathStepExecutionResults) = sut.UpdateToServicePack(mockSoftwareUpgradeService.Object,
                new Installation(mockProduct.Object), new ReleasedReplacementChainFilter(), null, false, true,
                Model.Request.RemoteSoftwareDownloadScenario
                    .NotApplicable, false, DateTime.MaxValue, true, new List<DistributionMethod>());
        }

        [TestMethod]
        public void UpdateToServicePackOk_TwoProducts()
        {
            var productSpecification1 = new Mock<IProductSpecification>();
            productSpecification1.Setup(p => p.PaddedChassisId).Returns("A-123");
            productSpecification1.Setup(p => p.ChassisSeries).Returns("A");
            productSpecification1.Setup(p => p.ChassisNumber).Returns("123");

            var productSpecification2 = new Mock<IProductSpecification>();
            productSpecification2.Setup(p => p.PaddedChassisId).Returns("A-456");
            productSpecification2.Setup(p => p.ChassisSeries).Returns("A");
            productSpecification2.Setup(p => p.ChassisNumber).Returns("456");

            var mockSoftwareUpgrader = new Mock<ISoftwareUpgrader>();
            var mockUpgradePathCheck = new Mock<IServicePackUpgradePathCheck>();
            var mockProduct1 = new Mock<IProduct>();
            mockProduct1.Setup(p => p.ProductSpecification).Returns(productSpecification1.Object);
            var mockProduct2 = new Mock<IProduct>();
            mockProduct2.Setup(p => p.ProductSpecification).Returns(productSpecification2.Object);

            var sut = new ServicePackUpdater(mockSoftwareUpgrader.Object, mockUpgradePathCheck.Object);

            var servicePackReferences = new List<ServicePackReference>
            {
                new ServicePackReference(1,"GUID1",ServicePackState.Released,"SP1", null,1, 1, new List<(string, string)>()),
                new ServicePackReference(2,"GUID2",ServicePackState.Released,"SP2", DateTime.MinValue,2, 1, new List<(string, string)>()),
            };
            var servicePackNodeDictionary = new Dictionary<ServicePackReference, Dictionary<ProductNodeIdentification, int>>
            {
                {servicePackReferences[0],new Dictionary<ProductNodeIdentification, int>{{new NodeName(1,1,"1.1").WithProduct(mockProduct1.Object),12345678}}},
                {servicePackReferences.Last(),new Dictionary<ProductNodeIdentification, int>{{new NodeName(1,1,"1.1").WithProduct(mockProduct2.Object), 55724567}}}
            };

            var requestMetaData1 = new Mock<IRequestMetadata>();
            var requestMetaData2 = new Mock<IRequestMetadata>();

            var billOfMaterial1 = new Mock<IBillOfMaterial>();
            var billOfMaterial2 = new Mock<IBillOfMaterial>();

            var mockProductWithServicePackDocumentNumbers1 = new Mock<IProduct>();
            var mockProductWithServicePackDocumentNumbers2 = new Mock<IProduct>();
            mockProduct1.Setup(p => p.RequestMetadata).Returns(requestMetaData1.Object);
            mockProduct2.Setup(p => p.RequestMetadata).Returns(requestMetaData2.Object);
            mockProductWithServicePackDocumentNumbers1.Setup(p => p.RequestMetadata).Returns(requestMetaData1.Object);
            mockProductWithServicePackDocumentNumbers2.Setup(p => p.RequestMetadata).Returns(requestMetaData2.Object);
            mockProduct1.Setup(p => p.BillOfMaterial).Returns(billOfMaterial1.Object);
            mockProduct2.Setup(p => p.BillOfMaterial).Returns(billOfMaterial2.Object);
            mockProductWithServicePackDocumentNumbers1.Setup(p => p.BillOfMaterial).Returns(billOfMaterial1.Object);
            mockProductWithServicePackDocumentNumbers2.Setup(p => p.BillOfMaterial).Returns(billOfMaterial2.Object);

            var mockSoftwareUpgradeService = new Mock<ISoftwareUpgradeService>();
            mockSoftwareUpgradeService.Setup(s => s.GetAvailableServicePackReferences(It.IsAny<Installation>())).Returns(
                new System.Tuple<IEnumerable<ServicePackReference>, IDictionary<ServicePackReference, Dictionary<ProductNodeIdentification, int>>>(servicePackReferences, servicePackNodeDictionary));
            mockSoftwareUpgrader.Setup(s => s.BatchUpgradeSoftware(It.IsAny<ISoftwareUpgradeService>(), It.IsAny<Installation>(),
                It.IsAny<IBreakdownReplacementChainFilter>(), It.IsAny<BatchUpgradeOptions>(),
                null, It.IsAny<DateTime>(), false, true, false, false)).Returns(new Installation(new List<IProduct>() { mockProduct1.Object, mockProduct2.Object }));

            var (resultInstallation, resultServicePack, resultUpgradePathStepExecutionResults) = sut.UpdateToServicePack(mockSoftwareUpgradeService.Object, new Installation(new List<IProduct>() { mockProduct1.Object, mockProduct2.Object }), new IntroducedReplacementChainFilter(), null, false, true,
                Model.Request.RemoteSoftwareDownloadScenario.NotApplicable, false, DateTime.MaxValue, true, new List<DistributionMethod>());

            Assert.IsNotNull(resultInstallation);
            Assert.AreEqual(2, resultInstallation.Products.Count());
            Assert.IsTrue(resultInstallation.Products.Contains(mockProduct1.Object));
            Assert.IsTrue(resultInstallation.Products.Contains(mockProduct2.Object));
            Assert.IsNotNull(resultServicePack);
            Assert.AreEqual("GUID2", resultServicePack.Guid);

            mockSoftwareUpgradeService.VerifyAll();
            mockSoftwareUpgrader.VerifyAll();
            requestMetaData1.VerifyAll();
            billOfMaterial1.VerifyAll();
            requestMetaData2.VerifyAll();
            billOfMaterial2.VerifyAll();
        }
    }
}
