﻿using Proxy.Matrix;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Artifacts;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Configuration;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ConversionKit;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Node;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Notifications;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ProductDefinition;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ReplacementChains;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Request;
using Volvo.SoftwareBreakdown.UtilityComponent;

namespace Volvo.SoftwareBreakdown.BreakdownDomain.Services
{
    public class ServicePackUpdater : IServicePackUpdater
    {
        private readonly ISoftwareUpgrader _softwareUpgrader;
        private readonly IServicePackUpgradePathCheck _upgradePathCheck;

        public ServicePackUpdater(ISoftwareUpgrader softwareUpgrader, IServicePackUpgradePathCheck upgradePathCheck)
        {
            _softwareUpgrader = softwareUpgrader;
            _upgradePathCheck = upgradePathCheck;
        }

        public (Installation, ServicePackReference, IReadOnlyList<UpgradePathStepExecutionResult>)
            UpdateToServicePack(
                ISoftwareUpgradeService softwareUpgradeService,
                Installation installation,
                IBreakdownReplacementChainFilter breakdownScenarioFilter,
                IAftermarketCalculationService calculationService,
                bool ignoreParameterCalculations, bool multiNodeEnabled,
                RemoteSoftwareDownloadScenario remoteSoftwareDownloadScenario,
                bool isPblUpdateCapable, DateTime abortAt,
                bool groupAdminParameters,
                IEnumerable<DistributionMethod> supportedDistributionMethods,
                CancellationToken cancellationToken = default)
        {
            if (!multiNodeEnabled)
            {
                throw new NotificationException(new NoValidConfiguration(false, "Operation type Update To Service Pack requires multi node enabled.",
                    ErrorCode.NoValidConfigurationsError));
            }
            Serilog.Log.Information("Updating to service pack.");

            //Look up all service packs in the chains for this vehicle
            var availableServicePackReferencesBeforeScenarioFilter = softwareUpgradeService.GetAvailableServicePackReferences(installation);

            var availableServicePackReferences = availableServicePackReferencesBeforeScenarioFilter.Item1.Where(servicePack => breakdownScenarioFilter.CheckIfServicePackIsAvailableForUpdateToServicePack(servicePack, installation));

            if (!availableServicePackReferences.Any())
            {
                var notPossibleServicePack =
                    availableServicePackReferencesBeforeScenarioFilter.Item2.Where(i2 => !availableServicePackReferencesBeforeScenarioFilter.Item1.Any(i1 => i1.Equals(i2.Key)) && breakdownScenarioFilter.CheckIfServicePackIsAvailableForUpdateToServicePack(i2.Key, installation))
                        .OrderBy(b =>
                        {
                            var allProductNodes = installation.Products
                                .SelectMany(p => p.BillOfMaterial.Nodes.Select(n => n.NodeIdentification.WithProduct(p))).ToList();
                            return allProductNodes.Except(b.Value.Keys).ToList().Count;
                        })
                        .ThenByDescending(b => b.Key.SortOrder)
                        .ThenByDescending(b => b.Key.Guid).FirstOrDefault();
                if (notPossibleServicePack.Key != null)
                {
                    var allProductNodes = installation.Products
                        .SelectMany(p => p.BillOfMaterial.Nodes.Select(n => n.NodeIdentification.WithProduct(p))).ToList();
                    var nonMatchedNodes = allProductNodes.Except(notPossibleServicePack.Value.Keys).ToList();

                    throw new NotificationException(new NoValidConfiguration(false,
                        $"Service pack {notPossibleServicePack.Key.Name} is not reachable for nodes {nonMatchedNodes.Select(n => n.NodeIdentification).CreateCommaSeparatedList() }.",
                        ErrorCode.NoValidConfigurationsError));
                }

                if (availableServicePackReferencesBeforeScenarioFilter.Item1.Any())
                {
                    var servicePackList = string.Join(", ", availableServicePackReferencesBeforeScenarioFilter.Item1.Select(s => s.Name));

                    throw new NotificationException(new NoValidConfiguration(false,
                        $"Unable to find a valid service pack to update to! {servicePackList} are not available in the {breakdownScenarioFilter.Name} scenario!",
                        ErrorCode.NoValidConfigurationsError));
                }

                throw new NotificationException(new NoValidConfiguration(false,
                    "Unable to find a valid service pack to update to! No potential service packs exist in the replacement chains.",
                    ErrorCode.NoValidConfigurationsError));
            }

            var servicePackReferences = availableServicePackReferences.OrderByDescending(b => b.SortOrder).ThenByDescending(b => b.Guid).ToList();
            

            Exception servicePackNotification = null;
            var productSpecification = installation.Products.FirstOrDefault()?.ProductSpecification;
            var products = installation.Products.OfType<IProductContainer>().ToList();
            IReplacementChainContainer replacementChainContainer = null;

            foreach (var servicePackReference in servicePackReferences)
            {
                try
                {
                    var productsWithUnfulfilledStagerredAvailability = installation.Products.Where(p =>
                        !servicePackReference.IsForChassis(p.ProductSpecification.ChassisSeries, p.ProductSpecification.ChassisNumber)).ToList();

                    if (productsWithUnfulfilledStagerredAvailability.Count > 0)
                    {
                        throw new NotificationException(new NoValidConfiguration(false,
                            $"Service pack is blocked since it is not available for the products {string.Join(", ", productsWithUnfulfilledStagerredAvailability.Select(p => p.ProductSpecification.PaddedChassisId))}!",
                            ErrorCode.NoValidConfigurationsError));
                    }

                    // Here Running upgradepath before upgrade,
                    // We could do it later as well, just thought this is the correct place.
                    IDictionary<int, List<IKit>>? upgradePathTransitions = null;
                    ServicePackUpgradePathCheckResult? checkResult = null;

                    if (_upgradePathCheck != null &&
                            (installation.Products.FirstOrDefault()?.ServicePack is null ||
                            servicePackReference.SortOrder >= installation.Products.FirstOrDefault()?.ServicePack?.SortOrder))
                    {
                        checkResult = _upgradePathCheck.IsValidUpgradePathAsync(
                            servicePackReference, installation, products, productSpecification, cancellationToken)
                            .GetAwaiter().GetResult();

                        if (checkResult != null)
                        {
                            if (!checkResult.IsValid)
                            {
                                Serilog.Log.Information(
                                    "Service pack {id} rejected by upgrade path check: {reason}",
                                    servicePackReference.Id, checkResult.Reason);
                                servicePackNotification ??= new NotificationException(new NoValidConfiguration(false,
                                    $"Could not update to {servicePackReference.Name}! {checkResult.Reason}",
                                    ErrorCode.NoValidConfigurationsError));
                                continue;
                            }

                            // skipped , if product does not have any hpc nodes
                            if (checkResult.Outcome == ServicePackUpgradePathCheckResult.CheckOutcome.Skipped)
                            {
                                Serilog.Log.Information(
                                    "Upgrade path check skipped for service pack {Id}: {Reason}. Proceeding without transitions.",
                                    servicePackReference.Id, checkResult.Reason);
                            }

                            // this is accumalted transitions.
                            upgradePathTransitions = checkResult.UpgradePathTransitions;
                        }
                    }

                    var servicePackNodeDefinitions = new List<BaseNodeDefinition>();
                    foreach (var product in installation.Products)
                    {
                        var nodesInServicePack = product.BillOfMaterial.ServicePackNodes.ToList();

                        product.RequestMetadata.CurrentlyRequestedNodes =
                            nodesInServicePack.ConvertAll(n => n.NodeIdentification);
                        servicePackNodeDefinitions = servicePackNodeDefinitions.Union(nodesInServicePack.Select(n => n.NodeDefinition)).ToList();
                    }

                    replacementChainContainer = _softwareUpgrader.LoadReplacementChainContainer();
                    var sibOwnedDocumentNumbers = replacementChainContainer?.GetAllSibNtpDocumentNumbers(servicePackReference);

                    IBreakdownReplacementChainFilter breakdownReplacementChainFilter = new ServicePackReplacementChainFilter(servicePackReference, servicePackNodeDefinitions, breakdownScenarioFilter, sibOwnedDocumentNumbers);
                    var batchUpgradeOptions = new BatchUpgradeOptions(SoftwareRequestOperationType.UpdateToServicePack, true, remoteSoftwareDownloadScenario, ignoreParameterCalculations, false, isPblUpdateCapable, false, false, false, false, false, supportedDistributionMethods, upgradePathTransitions);
                    var updateInstallation = _softwareUpgrader.BatchUpgradeSoftware(softwareUpgradeService,
                        installation, breakdownReplacementChainFilter, batchUpgradeOptions,
                        calculationService, abortAt, false, groupAdminParameters, false, false);

                    // keeping this just to keep track of all upgrade step results.
                    // we could still optimize this later
                    var stepResults = (checkResult?.StepExecutionResults)
                        ?? new List<UpgradePathStepExecutionResult>();

                    return (updateInstallation, servicePackReference, stepResults);
                }
                catch (UpgradePathParameterConflictException ne)
                {
                    Serilog.Log.Information(ne, $"Software products set conflicting parameter values when updating to service pack {servicePackReference.Id}!");

                    throw new NotificationException(new NoValidConfiguration(false,
                        $"Could not update to {servicePackReference.Name}! {ne.Message}",
                        ne.GetErrorCode()));
                }
                catch (NotificationException ne)
                {
                    Serilog.Log.Information(ne, $"Configuration for service pack {servicePackReference.Id} is invalid! The service pack is rejected.");

                    servicePackNotification ??= new NotificationException(new NoValidConfiguration(false,
                        $"Could not update to {servicePackReference.Name}! {ne.Message}",
                        ne.GetErrorCode()));
                }
                catch (Exception ex)
                {
                    Serilog.Log.Information(ex, $"Configuration for service pack {servicePackReference.Id} is invalid! The service pack is rejected.");

                    servicePackNotification ??= new NotificationException(new NoValidConfiguration(false,
                        $"Could not update to {servicePackReference.Name}! {ex.Message}",
                        ErrorCode.NoValidConfigurationsError));
                }
            }

            if (servicePackNotification != null)
            {
                throw servicePackNotification;
            }

            throw new NotificationException(new NoValidConfiguration(false,
                "Unable to find a valid service pack to update to!",
                ErrorCode.NoValidConfigurationsError));
        }
    }
}