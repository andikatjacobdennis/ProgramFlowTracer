using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using Microsoft.Win32;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// Applies the light or dark token dictionary. "auto" follows the Windows app theme and changes with it, and takes the
/// Windows accent colour (buttons, selection, links, focus) on top of it. The title bar is switched to match (DWM
/// immersive dark mode), so a dark window never has a white frame.
/// </summary>
public static class ThemeManager
{
    private static ResourceDictionary? _current;
    private static ResourceDictionary? _accent;

    public static string Mode { get; private set; } = "auto";

    public static bool IsDark { get; private set; }

    public static event EventHandler? Changed;

    public static void Initialize(string mode)
    {
        SystemEvents.UserPreferenceChanged += (_, e) =>
        {
            // General: light/dark changed; Color and VisualStyle: the accent colour changed.
            if (e.Category is UserPreferenceCategory.General or UserPreferenceCategory.Color or UserPreferenceCategory.VisualStyle && Mode == "auto")
            {
                Ui.Post(() => Apply("auto"));
            }
        };
        Apply(mode);
    }

    public static void Apply(string mode)
    {
        Mode = mode is "light" or "dark" ? mode : "auto";
        var dark = Mode == "dark" || Mode == "auto" && SystemPrefersDark();
        var dictionary = new ResourceDictionary { Source = new Uri($"pack://application:,,,/DocGen.Explorer;component/Themes/{(dark ? "Dark" : "Light")}.xaml") };
        var merged = Application.Current.Resources.MergedDictionaries;
        // Remove every theme dictionary (including the one App.xaml starts with): a later dictionary would win.
        foreach (var old in merged.Where(d => _current == d || d.Source?.OriginalString.Contains("Themes/Light.xaml", StringComparison.OrdinalIgnoreCase) == true
                                                || d.Source?.OriginalString.Contains("Themes/Dark.xaml", StringComparison.OrdinalIgnoreCase) == true).ToList())
        {
            merged.Remove(old);
        }
        merged.Insert(0, dictionary);
        _current = dictionary;
        if (_accent is not null)
        {
            merged.Remove(_accent);
            _accent = null;
        }
        // Following Windows: its accent colour on top of the theme (right after it, so it wins over the theme's own).
        if (Mode == "auto" && SystemAccent(dark) is { } accent)
        {
            merged.Insert(1, accent);
            _accent = accent;
        }
        IsDark = dark;
        foreach (Window window in Application.Current.Windows)
        {
            ApplyTitleBar(window);
        }
        Changed?.Invoke(null, EventArgs.Empty);
    }

    /// <summary>auto → light → dark → auto.</summary>
    public static string Next(string mode) => mode switch
    {
        "auto" => "light",
        "light" => "dark",
        _ => "auto",
    };

    public static string Describe(string mode) => mode switch
    {
        "light" => "Theme: light",
        "dark" => "Theme: dark",
        _ => "Theme: auto (follows your system)",
    };

    /// <summary>
    /// The Windows accent colour as the theme's accent keys, or null when Windows does not say. AccentPalette holds the
    /// accent and its shades (light 3, 2, 1, accent, dark 1, 2, 3); each use takes the shade that reads well on this theme.
    /// </summary>
    private static ResourceDictionary? SystemAccent(bool dark)
    {
        byte[]? palette;
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Accent");
            palette = key?.GetValue("AccentPalette") as byte[];
        }
        catch (Exception ex) when (ex is System.Security.SecurityException or UnauthorizedAccessException or IOException)
        {
            return null;
        }
        if (palette is not { Length: >= 28 })
        {
            return null;
        }
        var shades = Enumerable.Range(0, 7).Select(i => Color.FromRgb(palette[i * 4], palette[i * 4 + 1], palette[i * 4 + 2])).ToArray();
        var background = ((Application.Current.Resources["Brush.Window"] as SolidColorBrush)?.Color) ?? (dark ? Colors.Black : Colors.White);
        // Text-like uses (links, the selected item, focus): the shade nearest the accent that is readable on the window.
        var ordered = dark ? new[] { shades[3], shades[2], shades[1], shades[0] } : new[] { shades[3], shades[4], shades[5], shades[6] };
        var text = ordered.FirstOrDefault(c => Contrast(c, background) >= 4.5, ordered[^1]);
        var hover = dark ? Lerp(text, Colors.White, 0.15) : Lerp(text, Colors.Black, 0.15);
        // Filled buttons: a shade white text reads on.
        var solid = new[] { shades[3], shades[4], shades[5], shades[6] }.FirstOrDefault(c => Contrast(c, Colors.White) >= 4.5, shades[6]);
        var solidHover = Lerp(solid, Colors.Black, 0.15);
        var soft = Lerp(background, shades[3], dark ? 0.22 : 0.12);
        var dictionary = new ResourceDictionary { ["Color.Accent"] = solid };
        void Brush(Color color, params string[] keys)
        {
            var brush = new SolidColorBrush(color);
            brush.Freeze();
            foreach (var k in keys)
            {
                dictionary[k] = brush;
            }
        }
        Brush(text, "AccentPrimary", "Brush.Accent", "Brush.Orange", "FocusRing", "Brush.Focus", "LinkText", "Brush.Link", "TextSelection");
        Brush(hover, "AccentHover", "Brush.AccentHover");
        Brush(solid, "AccentSolid", "Brush.AccentSolid");
        Brush(solidHover, "AccentSolidHover", "Brush.AccentSolidHover");
        Brush(Colors.White, "AccentOnSolid", "Brush.AccentText");
        Brush(soft, "AccentSubtle", "Brush.AccentSoft", "Brush.OrangeSoft");
        Brush(dark ? shades[0] : shades[5], "AccentSubtleText", "Brush.AccentSoftText");
        return dictionary;
    }

    private static Color Lerp(Color a, Color b, double t)
        => Color.FromRgb((byte)(a.R + (b.R - a.R) * t), (byte)(a.G + (b.G - a.G) * t), (byte)(a.B + (b.B - a.B) * t));

    private static double Contrast(Color a, Color b)
    {
        static double Luminance(Color c)
        {
            static double Channel(byte v)
            {
                var x = v / 255.0;
                return x <= 0.03928 ? x / 12.92 : Math.Pow((x + 0.055) / 1.055, 2.4);
            }
            return 0.2126 * Channel(c.R) + 0.7152 * Channel(c.G) + 0.0722 * Channel(c.B);
        }
        var (l1, l2) = (Luminance(a), Luminance(b));
        return (Math.Max(l1, l2) + 0.05) / (Math.Min(l1, l2) + 0.05);
    }

    public static bool SystemPrefersDark()
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");
            return key?.GetValue("AppsUseLightTheme") is int light && light == 0;
        }
        catch (Exception ex) when (ex is System.Security.SecurityException or UnauthorizedAccessException or IOException)
        {
            return false;
        }
    }

    public static void ApplyTitleBar(Window window)
    {
        var handle = new WindowInteropHelper(window).Handle;
        if (handle == IntPtr.Zero)
        {
            return;
        }
        var value = IsDark ? 1 : 0;
        // 20 = DWMWA_USE_IMMERSIVE_DARK_MODE (Windows 10 20H1+); 19 on older builds.
        if (DwmSetWindowAttribute(handle, 20, ref value, sizeof(int)) != 0)
        {
            DwmSetWindowAttribute(handle, 19, ref value, sizeof(int));
        }
    }

    [DllImport("dwmapi.dll")]
    private static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);
}

/// <summary>Icon glyphs (Segoe Fluent Icons / Segoe MDL2 Assets).</summary>
public static class Icons
{
    public const string Search = "";
    public const string Add = "";
    public const string Delete = "";
    public const string Folder = "";
    public const string FolderOpen = "";
    public const string Document = "";
    public const string Code = "";
    public const string Copy = "";
    public const string Download = "";
    public const string Link = "";
    public const string Refresh = "";
    public const string Cancel = "";
    public const string Check = "";
    public const string Play = "";
    public const string Pause = "";
    public const string Stop = "";
    public const string Volume = "";
    public const string Attach = "\uE723";
    public const string Image = "\uEB9F";
    public const string Mic = "";
    public const string Send = "";
    public const string Edit = "";
    public const string Retry = "";
    public const string More = "";
    public const string Chat = "";
    public const string NewChat = "";
    public const string Clear = "";
    public const string Expand = "";
    public const string Collapse = "";
    public const string Close = "";
    public const string Settings = "";
    public const string Help = "";
    // Side panel: the arrow points left (E89F, "close pane") or right (E8A0, "open pane").
    public const string ClosePane = "";
    public const string OpenPane = "";
    public const string Keyboard = "";
    /// <summary>Send feedback.</summary>
    /// <summary>A report page: the log viewer.</summary>
    public const string Logs = "\uE9F9";
    public const string Feedback = "";
    /// <summary>Window: minimise.</summary>
    public const string WindowMinimize = "";
    /// <summary>Window: maximise.</summary>
    public const string WindowMaximize = "";
    /// <summary>Window: restore.</summary>
    public const string WindowRestore = "";
    /// <summary>Window: close.</summary>
    public const string WindowClose = "";
    public const string Sun = "";
    public const string Moon = "";
    public const string Auto = "";
    public const string Lightbulb = "";
    public const string Library = "";
    public const string Usage = "";
    public const string Pane = "";
    public const string Info = "";
    public const string Warning = "";
    public const string Error = "";
    public const string Clock = "";
    public const string People = "";
    public const string Person = "";
    public const string Upload = "";
    public const string ChevronDown = "";
    public const string ChevronRight = "";
    public const string Back = "";
    public const string Forward = "";
    public const string Filter = "";
    public const string Fit = "";
    public const string ZoomIn = "";
    public const string ZoomOut = "";
    public const string Wrap = "";
    public const string FoldAll = "";
    public const string UnfoldAll = "";
    /// <summary>A hub with linked nodes: the knowledge graph.</summary>
    public const string Graph = "";
    public const string ClassDiagram = "";
    public const string Database = "";
    public const string Chunks = "";
    public const string Studio = "";
    public const string Quiz = "";
    public const string Cards = "";
    public const string Path = "";
    public const string Faq = "";
    public const string Motion = "";
    public const string MotionOff = "";
    public const string Git = "";
    public const string Payment = "";
    public const string Globe = "";
}
