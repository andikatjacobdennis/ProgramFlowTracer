using System.Windows.Input;

namespace DocGen.Explorer.Infrastructure;

/// <summary>Find in a page or a file: Ctrl+F opens it, F3 / Shift+F3 go to the next / previous match.</summary>
public static class FindCommands
{
    public static readonly RoutedUICommand Open = new("Find", "FindOpen", typeof(FindCommands));
    public static readonly RoutedUICommand Next = new("Find next", "FindNext", typeof(FindCommands));
    public static readonly RoutedUICommand Previous = new("Find previous", "FindPrevious", typeof(FindCommands));
}
