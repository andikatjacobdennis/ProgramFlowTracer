using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// Small, short-lived animations set from XAML (used by Learning): items fading in one after another, content sliding in
/// when it changes, a press that gives, a pulse for a right answer, a shake for a wrong one and a pop when a number goes
/// up. Every animation ends by itself within a second and leaves the element exactly as it was; with motion reduced
/// (the header button) nothing moves and the final state shows at once.
/// </summary>
public static class Motion
{
    /// <summary>The app-wide "Reduce motion" switch (MainViewModel keeps the avatar faces' copy in step).</summary>
    public static bool Reduced => Avatars.AvatarFace.ReduceMotion;

    // ---------- Reveal: fade and rise in when loaded, a little after the item before it ----------

    public static readonly DependencyProperty RevealProperty =
        DependencyProperty.RegisterAttached("Reveal", typeof(bool), typeof(Motion), new PropertyMetadata(false, OnRevealChanged));

    public static bool GetReveal(DependencyObject d) => (bool)d.GetValue(RevealProperty);

    public static void SetReveal(DependencyObject d, bool value) => d.SetValue(RevealProperty, value);

    private static void OnRevealChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is FrameworkElement element && e.NewValue is true)
        {
            element.Loaded += (_, _) => Reveal(element);
        }
    }

    private static void Reveal(FrameworkElement element)
    {
        if (Reduced || !element.IsVisible)
        {
            return;
        }
        // The item's place in its list decides the delay: a gentle cascade, capped so a long list is not kept waiting.
        var index = 0;
        if (VisualTreeHelper.GetParent(element) is DependencyObject container && ItemsControl.ItemsControlFromItemContainer(container) is { } list)
        {
            index = Math.Max(0, list.ItemContainerGenerator.IndexFromContainer(container));
        }
        var delay = Math.Min(index, 8) * 45.0;
        FadeIn(element, delay, 260, 0, 10);
    }

    // ---------- FadeOnShow: fade and rise in each time the element becomes visible (a phase or a page) ----------

    public static readonly DependencyProperty FadeOnShowProperty =
        DependencyProperty.RegisterAttached("FadeOnShow", typeof(bool), typeof(Motion), new PropertyMetadata(false, OnFadeOnShowChanged));

    public static bool GetFadeOnShow(DependencyObject d) => (bool)d.GetValue(FadeOnShowProperty);

    public static void SetFadeOnShow(DependencyObject d, bool value) => d.SetValue(FadeOnShowProperty, value);

    private static void OnFadeOnShowChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is FrameworkElement element && e.NewValue is true)
        {
            element.IsVisibleChanged += (_, args) =>
            {
                if (args.NewValue is true && !Reduced && element.IsLoaded)
                {
                    FadeIn(element, 0, 220, 0, 8);
                }
            };
        }
    }

    // ---------- SlideIndex: slide in from the side when the number changes (next question, next card) ----------

    public static readonly DependencyProperty SlideIndexProperty =
        DependencyProperty.RegisterAttached("SlideIndex", typeof(int), typeof(Motion), new PropertyMetadata(0, OnSlideIndexChanged));

    public static int GetSlideIndex(DependencyObject d) => (int)d.GetValue(SlideIndexProperty);

    public static void SetSlideIndex(DependencyObject d, int value) => d.SetValue(SlideIndexProperty, value);

    private static void OnSlideIndexChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is FrameworkElement { IsLoaded: true, IsVisible: true } element && !Reduced)
        {
            // Forward comes in from the right, back from the left.
            var from = (int)e.NewValue >= (int)e.OldValue ? 36 : -36;
            FadeIn(element, 0, 280, from, 0);
        }
    }

    // ---------- Press: gives a little under the pointer ----------

    public static readonly DependencyProperty PressProperty =
        DependencyProperty.RegisterAttached("Press", typeof(bool), typeof(Motion), new PropertyMetadata(false, OnPressChanged));

    public static bool GetPress(DependencyObject d) => (bool)d.GetValue(PressProperty);

    public static void SetPress(DependencyObject d, bool value) => d.SetValue(PressProperty, value);

    private static void OnPressChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is not FrameworkElement element || e.NewValue is not true)
        {
            return;
        }
        element.PreviewMouseLeftButtonDown += (_, _) => Scale(element, 0.975, 90);
        MouseButtonEventHandler release = (_, _) => Scale(element, 1, 160);
        element.PreviewMouseLeftButtonUp += release;
        element.MouseLeave += (_, _) => Scale(element, 1, 160);
    }

    // ---------- Verdict: "correct" pulses, "wrong" shakes ----------

    public static readonly DependencyProperty VerdictProperty =
        DependencyProperty.RegisterAttached("Verdict", typeof(string), typeof(Motion), new PropertyMetadata(null, OnVerdictChanged));

    public static string? GetVerdict(DependencyObject d) => (string?)d.GetValue(VerdictProperty);

    public static void SetVerdict(DependencyObject d, string? value) => d.SetValue(VerdictProperty, value);

    private static void OnVerdictChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is not FrameworkElement { IsLoaded: true, IsVisible: true } element || Reduced)
        {
            return;
        }
        var (scale, move) = Transforms(element);
        switch (e.NewValue as string)
        {
            case "correct":
                var pulse = Keys(380, (0, 1), (0.35, 1.035), (1, 1));
                scale.BeginAnimation(ScaleTransform.ScaleXProperty, pulse);
                scale.BeginAnimation(ScaleTransform.ScaleYProperty, pulse);
                break;
            case "wrong":
                move.BeginAnimation(TranslateTransform.XProperty, Keys(420, (0, 0), (0.15, -7), (0.35, 6), (0.55, -4), (0.75, 2), (1, 0)));
                break;
        }
    }

    // ---------- PopOn: a quick pop whenever the bound value changes (a streak going up) ----------

    public static readonly DependencyProperty PopOnProperty =
        DependencyProperty.RegisterAttached("PopOn", typeof(object), typeof(Motion), new PropertyMetadata(null, OnPopOnChanged));

    public static object? GetPopOn(DependencyObject d) => d.GetValue(PopOnProperty);

    public static void SetPopOn(DependencyObject d, object? value) => d.SetValue(PopOnProperty, value);

    private static void OnPopOnChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is not FrameworkElement { IsLoaded: true, IsVisible: true } element || Reduced || Equals(e.OldValue, e.NewValue))
        {
            return;
        }
        var (scale, _) = Transforms(element);
        var pop = Keys(360, (0, 0.7), (0.45, 1.18), (1, 1));
        scale.BeginAnimation(ScaleTransform.ScaleXProperty, pop);
        scale.BeginAnimation(ScaleTransform.ScaleYProperty, pop);
    }

    // ---------- helpers ----------

    /// <summary>Opacity 0→1 and a short slide to rest, after <paramref name="delayMs"/> (held invisible meanwhile).</summary>
    public static void FadeIn(FrameworkElement element, double delayMs, double durationMs, double fromX, double fromY)
    {
        var total = delayMs + durationMs;
        var ease = new CubicEase { EasingMode = EasingMode.EaseOut };
        DoubleAnimationUsingKeyFrames Hold(double from, double to)
        {
            var a = new DoubleAnimationUsingKeyFrames { Duration = TimeSpan.FromMilliseconds(total), FillBehavior = FillBehavior.Stop };
            a.KeyFrames.Add(new DiscreteDoubleKeyFrame(from, KeyTime.FromTimeSpan(TimeSpan.Zero)));
            a.KeyFrames.Add(new DiscreteDoubleKeyFrame(from, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(delayMs))));
            a.KeyFrames.Add(new EasingDoubleKeyFrame(to, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(total)), ease));
            return a;
        }
        element.BeginAnimation(UIElement.OpacityProperty, Hold(0, 1));
        var (_, move) = Transforms(element);
        if (fromX != 0)
        {
            move.BeginAnimation(TranslateTransform.XProperty, Hold(fromX, 0));
        }
        if (fromY != 0)
        {
            move.BeginAnimation(TranslateTransform.YProperty, Hold(fromY, 0));
        }
    }

    private static void Scale(FrameworkElement element, double to, double ms)
    {
        if (Reduced)
        {
            return;
        }
        var (scale, _) = Transforms(element);
        var a = new DoubleAnimation(to, TimeSpan.FromMilliseconds(ms)) { EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut } };
        if (to == 1)
        {
            // Back at rest: let go of the animation so nothing stays held.
            a.Completed += (_, _) =>
            {
                scale.BeginAnimation(ScaleTransform.ScaleXProperty, null);
                scale.BeginAnimation(ScaleTransform.ScaleYProperty, null);
            };
        }
        scale.BeginAnimation(ScaleTransform.ScaleXProperty, a);
        scale.BeginAnimation(ScaleTransform.ScaleYProperty, a);
    }

    /// <summary>Key frames over <paramref name="ms"/>: (fraction of the time, value) pairs, eased, then let go.</summary>
    public static DoubleAnimationUsingKeyFrames Keys(double ms, params (double At, double Value)[] frames)
    {
        var a = new DoubleAnimationUsingKeyFrames { Duration = TimeSpan.FromMilliseconds(ms), FillBehavior = FillBehavior.Stop };
        foreach (var (at, value) in frames)
        {
            a.KeyFrames.Add(new EasingDoubleKeyFrame(value, KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(ms * at)), new QuadraticEase { EasingMode = EasingMode.EaseInOut }));
        }
        return a;
    }

    private static readonly DependencyProperty TransformsProperty =
        DependencyProperty.RegisterAttached("Transforms", typeof(Tuple<ScaleTransform, TranslateTransform>), typeof(Motion));

    /// <summary>The element's own scale and move (made once, centred), so these animations never fight a layout transform.</summary>
    private static (ScaleTransform Scale, TranslateTransform Move) Transforms(FrameworkElement element)
    {
        if (element.GetValue(TransformsProperty) is Tuple<ScaleTransform, TranslateTransform> made)
        {
            return (made.Item1, made.Item2);
        }
        var scale = new ScaleTransform(1, 1);
        var move = new TranslateTransform();
        var group = new TransformGroup();
        group.Children.Add(scale);
        group.Children.Add(move);
        if (element.RenderTransform is { } existing && existing != Transform.Identity)
        {
            group.Children.Insert(0, existing);
        }
        element.RenderTransform = group;
        element.RenderTransformOrigin = new Point(0.5, 0.5);
        element.SetValue(TransformsProperty, Tuple.Create(scale, move));
        return (scale, move);
    }
}
