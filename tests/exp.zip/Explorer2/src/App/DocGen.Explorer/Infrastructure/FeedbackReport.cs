using System.IO.Compression;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// Send feedback: a zip in C:\DocGen-Feedback (DocGen-feedback-yyyy-MM-dd-HHmmss.zip) with what is needed to look into
/// a problem — a picture of every open window of the explorer, what the person wrote, the version, the PC and the
/// explorer's state, its settings file and its recent logs. Keys and tokens are never included: the AI and Confluence
/// settings are left out, and the logs have secrets removed as they are written.
/// </summary>
public static class FeedbackReport
{
    public const string Folder = @"C:\DocGen-Feedback";

    /// <summary>The pictures of the open windows, taken before anything else is shown (so a dialog is not in them).</summary>
    public static List<(string Name, byte[] Png)> CaptureWindows()
    {
        var shots = new List<(string, byte[])>();
        var index = 1;
        foreach (Window window in Application.Current.Windows)
        {
            // Not the off-screen helper windows (the Mermaid renderer lives at -32000).
            if (!window.IsVisible || window.Left < -10000 || window.Top < -10000
                || window.Content is not FrameworkElement content || content.ActualWidth < 1 || content.ActualHeight < 1)
            {
                continue;
            }
            try
            {
                var dpi = VisualTreeHelper.GetDpi(window);
                // The size on screen: with the interface zoomed (Ctrl+=) the window shows the content scaled.
                var shot = content.LayoutTransform.TransformBounds(new Rect(content.RenderSize)).Size;
                var bitmap = new RenderTargetBitmap((int)(shot.Width * dpi.DpiScaleX), (int)(shot.Height * dpi.DpiScaleY),
                    96 * dpi.DpiScaleX, 96 * dpi.DpiScaleY, PixelFormats.Pbgra32);
                var visual = new DrawingVisual();
                using (var dc = visual.RenderOpen())
                {
                    dc.DrawRectangle(window.Background ?? Brushes.White, null, new Rect(0, 0, shot.Width, shot.Height));
                    // Exactly the window's area: by default a VisualBrush fits everything drawn (also what the window clips
                    // off at its edge) into the rectangle, which shrinks and softens the picture.
                    dc.DrawRectangle(new VisualBrush(content)
                    {
                        ViewboxUnits = BrushMappingMode.Absolute,
                        Viewbox = new Rect(0, 0, shot.Width, shot.Height),
                        Stretch = Stretch.None,
                        AlignmentX = AlignmentX.Left,
                        AlignmentY = AlignmentY.Top,
                    }, null, new Rect(0, 0, shot.Width, shot.Height));
                }
                bitmap.Render(visual);
                var encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(bitmap));
                using var stream = new MemoryStream();
                encoder.Save(stream);
                var name = window == Application.Current.MainWindow ? "main-window" : Safe(window.Title, $"window-{index}");
                shots.Add(($"screenshot-{index:00}-{name}.png", stream.ToArray()));
                index++;
            }
            catch (Exception ex) when (ex is not OutOfMemoryException)
            {
                Logging.Error(ex, "Feedback screenshot");
            }
        }
        return shots;
    }

    /// <summary>Writes the zip and returns its path.</summary>
    public static async Task<string> CreateAsync(MainViewModel main, string description, List<(string Name, byte[] Png)> screenshots, string? folderOverride = null)
    {
        var stamp = DateTime.Now.ToString("yyyy-MM-dd-HHmmss", System.Globalization.CultureInfo.InvariantCulture);
        var folder = folderOverride ?? Folder;
        try
        {
            Directory.CreateDirectory(folder);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            // A PC that does not allow folders on C:\ itself: the person's Documents instead.
            folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "DocGen-Feedback");
            Directory.CreateDirectory(folder);
        }
        var path = Path.Combine(folder, $"DocGen-feedback-{stamp}.zip");
        var details = await DetailsAsync(main, description);
        await Task.Run(() =>
        {
            using var zip = ZipFile.Open(path, ZipArchiveMode.Create);
            Add(zip, "details.md", Encoding.UTF8.GetBytes(details));
            foreach (var (name, png) in screenshots)
            {
                Add(zip, name, png);
            }
            var root = main.Engine.Store.Root;
            // The explorer's own settings (theme, panes, chosen model…); never ai.json or confluence.json (keys and tokens).
            AddFile(zip, Path.Combine(root, "settings", "explorer.json"), "settings/explorer.json");
            AddFile(zip, Path.Combine(root, "repositories.json"), "repositories.json");
            // The most recent logs (secrets are removed as they are written).
            var logs = Path.Combine(root, "logs");
            if (Directory.Exists(logs))
            {
                foreach (var log in new DirectoryInfo(logs).GetFiles("*.log").OrderByDescending(f => f.LastWriteTimeUtc).Take(3))
                {
                    AddFile(zip, log.FullName, "logs/" + log.Name, maxBytes: 2_000_000);
                }
            }
        });
        Logging.Info($"Feedback saved to {path}");
        return path;
    }

    private static async Task<string> DetailsAsync(MainViewModel main, string description)
    {
        var sb = new StringBuilder();
        sb.AppendLine("# DocGen Explorer feedback").AppendLine();
        sb.AppendLine("## What happened").AppendLine();
        sb.AppendLine(string.IsNullOrWhiteSpace(description) ? "(nothing written)" : description.Trim()).AppendLine();
        sb.AppendLine("## Where").AppendLine();
        sb.AppendLine($"- Time: {DateTime.Now:yyyy-MM-dd HH:mm:ss zzz}");
        sb.AppendLine($"- Version: DocGen Explorer {AppInfo.Version}");
        sb.AppendLine($"- Windows: {Environment.OSVersion.VersionString}, {(Environment.Is64BitOperatingSystem ? "64-bit" : "32-bit")}");
        sb.AppendLine($"- .NET: {Environment.Version}");
        sb.AppendLine($"- Screen: {SystemParameters.PrimaryScreenWidth:0} × {SystemParameters.PrimaryScreenHeight:0}, scaling {(Application.Current.MainWindow is { } w ? VisualTreeHelper.GetDpi(w).DpiScaleX * 100 : 100):0}%");
        if (Application.Current.MainWindow is { } window)
        {
            sb.AppendLine($"- Window: {window.ActualWidth:0} × {window.ActualHeight:0}, {window.WindowState}");
        }
        sb.AppendLine($"- Memory: {Environment.WorkingSet / (1024 * 1024)} MB");
        sb.AppendLine($"- Theme: {main.ThemeMode}; motion {(main.ReduceMotion ? "reduced" : "on")}");
        sb.AppendLine($"- Section: {main.Section}; panes {main.PaneOrder}; files list {(main.TreeVisible ? "shown" : "hidden")}; Ask {(main.AssistantVisible ? "shown" : "hidden")}");
        if (main.Workspace is { } workspace)
        {
            var record = workspace.Record;
            sb.AppendLine($"- Repository: {record.Title} ({record.Source}{(record.Branch is { Length: > 0 } b ? ", branch " + b : "")}), status {record.Status}");
            sb.AppendLine($"- Index: {record.Counters.Files} files, {record.Counters.Chunks} chunks, {record.Counters.GraphNodes} graph concepts");
        }
        try
        {
            var settings = await main.Engine.Models.GetExplorerSettingsAsync();
            var ai = await main.Engine.Models.Ai.GetAsync();
            sb.AppendLine($"- Chat model: {(string.IsNullOrEmpty(settings.ChatModelId) ? "evidence mode (none)" : settings.ChatModelId)}");
            // Which providers there are, never their keys.
            foreach (var provider in ai.Providers)
            {
                sb.AppendLine($"- Provider {provider.Id}: {provider.Kind}, {(provider.Enabled ? "on" : "off")}, {(provider.ApiKey.Length > 0 ? "key saved" : "no key")}, {ai.Models.Count(m => m.ProviderId == provider.Id)} models");
            }
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            sb.AppendLine($"- Settings could not be read: {ex.Message}");
        }
        sb.AppendLine().AppendLine("Screenshots, the explorer's settings file (no keys or tokens) and its recent logs are in this zip.");
        return sb.ToString();
    }

    private static void Add(ZipArchive zip, string name, byte[] content)
    {
        var entry = zip.CreateEntry(name, CompressionLevel.Optimal);
        using var stream = entry.Open();
        stream.Write(content);
    }

    private static void AddFile(ZipArchive zip, string path, string name, long maxBytes = 5_000_000)
    {
        try
        {
            if (!File.Exists(path))
            {
                return;
            }
            // Shared read: the log may be being written to.
            using var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
            if (file.Length > maxBytes)
            {
                file.Seek(-maxBytes, SeekOrigin.End); // the end of a long log is what matters
            }
            var entry = zip.CreateEntry(name, CompressionLevel.Optimal);
            using var stream = entry.Open();
            file.CopyTo(stream);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            Logging.Error(ex, $"Feedback: {name}");
        }
    }

    private static string Safe(string? title, string fallback)
    {
        var text = new string((title ?? "").Where(c => char.IsLetterOrDigit(c) || c is ' ' or '-').ToArray()).Trim().Replace(' ', '-').ToLowerInvariant();
        return text.Length == 0 ? fallback : text.Length > 40 ? text[..40] : text;
    }
}

/// <summary>The version people see (Directory.Build.props), e.g. "1.0.0" — without the build's commit suffix.</summary>
public static class AppInfo
{
    public static string Version { get; } = Read();

    private static string Read()
    {
        var assembly = typeof(AppInfo).Assembly;
        var informational = assembly.GetCustomAttributes(typeof(System.Reflection.AssemblyInformationalVersionAttribute), false)
            .OfType<System.Reflection.AssemblyInformationalVersionAttribute>().FirstOrDefault()?.InformationalVersion;
        var version = informational?.Split('+')[0];
        return string.IsNullOrWhiteSpace(version) ? assembly.GetName().Version?.ToString(3) ?? "1.0.0" : version;
    }

    /// <summary>"DocGen Explorer 1.0.0": the window's title.</summary>
    public static string Title => $"DocGen Explorer {Version}";
}
