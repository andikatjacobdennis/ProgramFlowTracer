using System.Runtime.InteropServices;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// How loud the sound is right now (0–1), from Windows' audio meters: this app's own sessions and the speakers' overall
/// level (the media player that plays the natural voices is not always counted in the app's session). It is read only
/// while an answer is being read aloud, so it follows that voice; null when Windows has no meter (the oscilloscope then
/// draws its own wave).
/// </summary>
public static class AudioMeter
{
    // Every audio session of this process (the media player and speech synthesis each open their own), and the speakers'
    // meter as a fallback when there is none yet.
    private static List<IAudioMeterInformation> _sessions = [];
    private static IAudioMeterInformation? _speakers;
    private static DateTime _nextLookup;

    /// <summary>Which meter is in use: this app's sessions, the speakers', or none (for checks).</summary>
    public static string Source => $"{_sessions.Count} session(s){(_speakers is null ? "" : " + speakers")}";

    /// <summary>The peak of the last few milliseconds of our sound (the loudest of our sessions), or null when there is no meter.</summary>
    public static double? Peak()
    {
        try
        {
            // Sessions appear when something starts playing: look again every second.
            if (DateTime.UtcNow >= _nextLookup)
            {
                _nextLookup = DateTime.UtcNow.AddSeconds(1);
                _sessions = SessionMeters();
                _speakers ??= EndpointMeter();
            }
            // The louder of this app's sessions and the speakers: Windows does not always count the media player's
            // sound (the natural voices) in the app's own session, but the speakers always hear it.
            double? loudest = null;
            foreach (var meter in _sessions.Concat(_speakers is null ? [] : [_speakers]))
            {
                if (meter.GetPeakValue(out var peak) == 0)
                {
                    loudest = Math.Max(loudest ?? 0, Math.Clamp(peak, 0, 1));
                }
            }
            return loudest;
        }
        catch (Exception ex) when (ex is COMException or InvalidCastException or InvalidComObjectException)
        {
            // The device changed (headphones plugged in…): find the meters again.
            _sessions = [];
            _speakers = null;
            _nextLookup = DateTime.MinValue;
            return null;
        }
    }

    private static IMMDevice? DefaultDevice()
    {
        var enumerator = (IMMDeviceEnumerator)new MMDeviceEnumerator();
        return enumerator.GetDefaultAudioEndpoint(0 /* render */, 1 /* multimedia */, out var device) == 0 ? device : null;
    }

    private static IAudioMeterInformation? EndpointMeter()
    {
        if (DefaultDevice() is not { } device)
        {
            return null;
        }
        var iid = typeof(IAudioMeterInformation).GUID;
        return device.Activate(ref iid, 0x17 /* CLSCTX_ALL */, IntPtr.Zero, out var meter) == 0 ? meter as IAudioMeterInformation : null;
    }

    private static List<IAudioMeterInformation> SessionMeters()
    {
        // Every active playback device: the media player and speech synthesis may not use the same one.
        var meters = new List<IAudioMeterInformation>();
        var enumerator = (IMMDeviceEnumerator)new MMDeviceEnumerator();
        if (enumerator.EnumAudioEndpoints(0 /* render */, 1 /* active */, out var devices) != 0 || devices.GetCount(out var deviceCount) != 0)
        {
            return meters;
        }
        var self = (uint)Environment.ProcessId;
        for (var d = 0; d < deviceCount; d++)
        {
            var iid = typeof(IAudioSessionManager2).GUID;
            if (devices.Item(d, out var device) != 0 || device.Activate(ref iid, 0x17, IntPtr.Zero, out var manager) != 0
                || manager is not IAudioSessionManager2 sessions || sessions.GetSessionEnumerator(out var list) != 0 || list.GetCount(out var count) != 0)
            {
                continue;
            }
            for (var i = 0; i < count; i++)
            {
                if (list.GetSession(i, out var session) == 0 && session.GetProcessId(out var pid) == 0 && pid == self && session is IAudioMeterInformation meter)
                {
                    meters.Add(meter);
                }
            }
        }
        return meters;
    }

    // ----- Windows Core Audio (only the methods used; the others keep their vtable slots) -----

    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    private class MMDeviceEnumerator;

    [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDeviceEnumerator
    {
        [PreserveSig] int EnumAudioEndpoints(int dataFlow, int stateMask, out IMMDeviceCollection devices);
        [PreserveSig] int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice device);
    }

    [ComImport, Guid("0BD7A1BE-7A1A-44DB-8397-CC5392387B5E"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDeviceCollection
    {
        [PreserveSig] int GetCount(out int count);
        [PreserveSig] int Item(int index, out IMMDevice device);
    }

    [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IMMDevice
    {
        [PreserveSig] int Activate(ref Guid iid, int clsCtx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object instance);
    }

    [ComImport, Guid("77AA99A0-1BD6-484F-8BC7-2C654C9A9B6F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioSessionManager2
    {
        [PreserveSig] int GetAudioSessionControl(IntPtr sessionGuid, int flags, out IntPtr control);
        [PreserveSig] int GetSimpleAudioVolume(IntPtr sessionGuid, int flags, out IntPtr volume);
        [PreserveSig] int GetSessionEnumerator(out IAudioSessionEnumerator sessions);
    }

    [ComImport, Guid("E2F5BB11-0570-40CA-ACDD-3AA01277DEE8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioSessionEnumerator
    {
        [PreserveSig] int GetCount(out int count);
        [PreserveSig] int GetSession(int index, out IAudioSessionControl2 session);
    }

    [ComImport, Guid("BFB7FF88-7239-4FC9-8FA2-07C950BE9C6D"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioSessionControl2
    {
        // IAudioSessionControl
        [PreserveSig] int GetState(out int state);
        [PreserveSig] int GetDisplayName(out IntPtr name);
        [PreserveSig] int SetDisplayName(IntPtr name, IntPtr context);
        [PreserveSig] int GetIconPath(out IntPtr path);
        [PreserveSig] int SetIconPath(IntPtr path, IntPtr context);
        [PreserveSig] int GetGroupingParam(out Guid grouping);
        [PreserveSig] int SetGroupingParam(IntPtr grouping, IntPtr context);
        [PreserveSig] int RegisterAudioSessionNotification(IntPtr client);
        [PreserveSig] int UnregisterAudioSessionNotification(IntPtr client);
        // IAudioSessionControl2
        [PreserveSig] int GetSessionIdentifier(out IntPtr id);
        [PreserveSig] int GetSessionInstanceIdentifier(out IntPtr id);
        [PreserveSig] int GetProcessId(out uint processId);
    }

    [ComImport, Guid("C02216F6-8C67-4B5B-9D00-D008E73E0064"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IAudioMeterInformation
    {
        [PreserveSig] int GetPeakValue(out float peak);
    }
}
