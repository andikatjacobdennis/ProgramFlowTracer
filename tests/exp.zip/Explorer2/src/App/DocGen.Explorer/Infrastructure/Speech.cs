using System.Speech.Recognition;
using System.Speech.Synthesis;
using System.Text.RegularExpressions;
using System.Windows.Media;
using DocGen.Explorer.Engine.Speech;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// Speech: reading answers and transcripts aloud (per-persona voice, rate and pitch), saving a transcript as audio, and
/// hold-to-talk dictation for questions. Voices are Microsoft Edge's natural (neural) voices when they are on and the
/// service can be reached, and the installed Windows voices otherwise. Everything degrades to a message when no voice
/// or recogniser is available.
/// </summary>
public sealed partial class SpeechService : IDisposable
{
    private SpeechSynthesizer? _synth;
    private SpeechRecognitionEngine? _recognizer;
    private readonly System.Text.StringBuilder _dictated = new();
    private CancellationTokenSource? _playback;

    public event EventHandler<int>? LineStarted;
    public event EventHandler? PlaybackEnded;

    /// <summary>A word of the text being read aloud is being said: (the text, as given to <see cref="Speak"/>; the word).</summary>
    public static event Action<string, string>? WordSpoken;

    /// <summary>Reading aloud stopped or finished (what was highlighted is cleared).</summary>
    public static event Action? ReadingEnded;

    /// <summary>Reading aloud was paused or resumed.</summary>
    public event EventHandler? PausedChanged;

    /// <summary>Whether something is being read aloud (raises <see cref="SpeakingChanged"/>).</summary>
    public bool IsSpeaking
    {
        get => _isSpeaking;
        private set
        {
            if (_isSpeaking != value)
            {
                _isSpeaking = value;
                Ui.Post(() => SpeakingChanged?.Invoke(this, EventArgs.Empty));
            }
        }
    }

    private bool _isSpeaking;

    /// <summary>Reading aloud started or ended.</summary>
    public event EventHandler? SpeakingChanged;

    /// <summary>Whether reading aloud is paused (<see cref="Pause"/>, <see cref="Resume"/>).</summary>
    public bool IsPaused { get; private set; }

    /// <summary>The text being read aloud by <see cref="Speak"/> (null for a transcript, or when nothing is read).</summary>
    public string? Reading { get; private set; }

    // What is playing now, so it can be paused: the natural voice's player, or a Windows voice.
    private static MediaPlayer? _player;
    private SpeechSynthesizer? _lineSynth;
    private TaskCompletionSource? _resumed;

    /// <summary>Use Edge's natural voices (Settings → Voice).</summary>
    public bool NaturalVoices { get; set; } = true;

    /// <summary>The voice for answers read aloud, and for speakers without a voice of their own.</summary>
    public string? DefaultVoice { get; set; } = EdgeTts.DefaultVoice;

    /// <summary>After the natural voices fail (no connection), the Windows voices are used for a while before trying again.</summary>
    private static DateTime _naturalRetryAt = DateTime.MinValue;

    /// <summary>Edge's natural voices, then the installed Windows voices.</summary>
    public static IReadOnlyList<string> AllVoices() => EdgeTts.Voices.Select(v => v.ShortName).Concat(Voices()).ToList();

    /// <summary>Whether <paramref name="voice"/> is spoken by Edge's service now: a natural voice, the option on, the service not just failed.</summary>
    private bool UsesNatural(string? voice) => NaturalVoices && EdgeTts.IsNatural(voice) && DateTime.UtcNow >= _naturalRetryAt;

    /// <summary>The voice a line is spoken in: its own, else the default; a natural voice when they are off becomes the Windows default.</summary>
    private string? Resolve(string? voice)
    {
        var chosen = string.IsNullOrWhiteSpace(voice) ? DefaultVoice : voice;
        return EdgeTts.IsNatural(chosen) && !NaturalVoices ? null : chosen;
    }

    private static void NaturalFailed(Exception ex)
    {
        Logging.Error(ex, "Edge natural voice");
        if (DateTime.UtcNow >= _naturalRetryAt)
        {
            Ui.Notify("Edge's natural voices could not be reached; using the Windows voices for now.");
        }
        _naturalRetryAt = DateTime.UtcNow.AddMinutes(2);
    }

    public static IReadOnlyList<string> Voices()
    {
        try
        {
            using var synth = new SpeechSynthesizer();
            return synth.GetInstalledVoices().Where(v => v.Enabled).Select(v => v.VoiceInfo.Name).ToList();
        }
        catch (Exception ex) when (ex is PlatformNotSupportedException or InvalidOperationException or System.Runtime.InteropServices.COMException)
        {
            return [];
        }
    }

    private SpeechSynthesizer Synth()
    {
        if (_synth is null)
        {
            _synth = new SpeechSynthesizer();
            _synth.SetOutputToDefaultAudioDevice();
            _synth.SpeakProgress += (_, e) => Said(e.Text);
        }
        return _synth;
    }

    /// <summary>Markdown to speakable text (no code fences, links read by their text).</summary>
    public static string Speakable(string markdown)
    {
        var text = FenceRegex().Replace(markdown, " (code omitted) ");
        text = LinkRegex().Replace(text, "$1");
        text = text.Replace("**", "", StringComparison.Ordinal).Replace("`", "", StringComparison.Ordinal);
        text = HeadingMarkRegex().Replace(text, ""); // "## Title", but "C#" is said as written
        text = CitationRegex().Replace(text, "");
        text = TableRuleRegex().Replace(text, " "); // |---|---| lines
        text = text.Replace("|", ", ", StringComparison.Ordinal); // table cells are read as a list
        text = new string(text.Select(c => char.IsControl(c) ? ' ' : c).ToArray()); // control characters are not speakable
        return WhitespaceRegex().Replace(text, " ").Trim();
    }

    public void Speak(string text, string? voice = null, double rate = 1)
    {
        Stop();
        Reading = text;
        voice = Resolve(voice);
        if (UsesNatural(voice))
        {
            // Long answers are spoken piece by piece, the first piece short so the voice starts quickly; each next piece is
            // fetched while the one before plays.
            var pieces = EdgeTts.SplitProgressive(Speakable(text)).Select(p => (p, (string?)voice, rate, 1.0)).ToList();
            _ = PlayAsync(pieces, 0, raiseLineStarted: false);
            return;
        }
        try
        {
            var synth = Synth();
            SelectVoice(synth, voice);
            synth.Rate = RateFor(rate);
            IsSpeaking = true;
            synth.SpeakCompleted += Completed;
            synth.SpeakAsync(Speakable(text));
        }
        catch (Exception ex) when (ex is InvalidOperationException or PlatformNotSupportedException or System.Runtime.InteropServices.COMException)
        {
            IsSpeaking = false;
            Ui.Notify("No speech voice is available on this PC.");
        }

        void Completed(object? sender, SpeakCompletedEventArgs e)
        {
            ((SpeechSynthesizer)sender!).SpeakCompleted -= Completed;
            if (Reading == text || Reading is null)
            {
                Ended();
            }
        }
    }

    /// <summary>Plays transcript lines one after another, each in its speaker's voice; raises <see cref="LineStarted"/>.</summary>
    public Task PlayAsync(IReadOnlyList<(string Text, string? Voice, double Rate, double Pitch)> lines, int startAt = 0) => PlayAsync(lines, startAt, raiseLineStarted: true);

    private async Task PlayAsync(IReadOnlyList<(string Text, string? Voice, double Rate, double Pitch)> lines, int startAt, bool raiseLineStarted)
    {
        var reading = Reading;
        Stop();
        Reading = raiseLineStarted ? null : reading; // a transcript is not highlighted; an answer read by Speak is
        var mine = _playback = new CancellationTokenSource();
        var token = mine.Token;
        IsSpeaking = true;
        // The next natural line is fetched while this one plays, so there is no gap between speakers.
        Task<SpeechAudio>? prefetch = null;
        Task<SpeechAudio> Fetch(int i)
        {
            var (text, voice, rate, pitch) = lines[i];
            return EdgeTts.SpeakAsync(Speakable(text), Resolve(voice)!, rate, pitch, token);
        }
        bool Natural(int i) => i < lines.Count && UsesNatural(Resolve(lines[i].Voice)) && Speakable(lines[i].Text).Length > 0;
        try
        {
            for (var i = startAt; i < lines.Count && !token.IsCancellationRequested; i++)
            {
                await WhilePausedAsync(token);
                var index = i;
                if (raiseLineStarted)
                {
                    Ui.Post(() => LineStarted?.Invoke(this, index));
                }
                var (text, voice, rate, pitch) = lines[i];
                if (Natural(i))
                {
                    try
                    {
                        var audio = await (prefetch ?? Fetch(i));
                        prefetch = Natural(i + 1) ? Fetch(i + 1) : null;
                        await PlayMp3Async(audio, token, Said);
                        continue;
                    }
                    catch (Exception ex) when (ex is IOException or System.Net.WebSockets.WebSocketException or HttpRequestException
                                                   or TimeoutException or UriFormatException || (ex is OperationCanceledException && !token.IsCancellationRequested))
                    {
                        NaturalFailed(ex);
                        prefetch = null; // and speak this line with a Windows voice below
                    }
                }
                var windowsVoice = EdgeTts.IsNatural(Resolve(voice)) ? null : Resolve(voice);
                await Task.Run(() =>
                {
                    using var synth = new SpeechSynthesizer();
                    synth.SetOutputToDefaultAudioDevice();
                    SelectVoice(synth, windowsVoice);
                    synth.Rate = RateFor(rate);
                    synth.SpeakProgress += (_, e) => Said(e.Text);
                    using var registration = token.Register(() => { try { synth.SpeakAsyncCancelAll(); } catch (ObjectDisposedException) { } });
                    _lineSynth = synth;
                    try
                    {
                        SpeakLine(synth, text);
                    }
                    finally
                    {
                        _lineSynth = null;
                    }
                }, CancellationToken.None);
            }
        }
        catch (Exception ex) when (ex is InvalidOperationException or PlatformNotSupportedException or System.Runtime.InteropServices.COMException or OperationCanceledException)
        {
            if (ex is not OperationCanceledException)
            {
                Ui.Notify("No speech voice is available on this PC.");
            }
        }
        finally
        {
            // Only when this is still the playback (one started since has taken over, and ends on its own).
            if (_playback == mine)
            {
                Ended();
            }
        }
    }

    /// <summary>Reading has ended: nothing is said, nothing is paused, and the highlight goes.</summary>
    private void Ended()
    {
        IsSpeaking = false;
        Reading = null;
        var wasPaused = IsPaused;
        IsPaused = false;
        Ui.Post(() =>
        {
            PlaybackEnded?.Invoke(this, EventArgs.Empty);
            ReadingEnded?.Invoke();
            if (wasPaused)
            {
                PausedChanged?.Invoke(this, EventArgs.Empty);
            }
        });
    }

    /// <summary>A word is being said (of the text being read, if any).</summary>
    private void Said(string word)
    {
        if (Reading is { } reading && !string.IsNullOrWhiteSpace(word))
        {
            Ui.Post(() => WordSpoken?.Invoke(reading, word));
        }
    }

    /// <summary>Waits while reading is paused (between pieces of a long answer).</summary>
    private async Task WhilePausedAsync(CancellationToken token)
    {
        while (IsPaused && !token.IsCancellationRequested)
        {
            var resumed = _resumed ??= new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            using (token.Register(() => resumed.TrySetCanceled(token)))
            {
                await resumed.Task;
            }
        }
    }

    /// <summary>Pauses reading aloud where it is; <see cref="Resume"/> carries on from there.</summary>
    public void Pause()
    {
        if (!IsSpeaking || IsPaused)
        {
            return;
        }
        IsPaused = true;
        Ui.Dispatcher.Invoke(() => _player?.Pause());
        PauseVoice(_synth, pause: true);
        PauseVoice(_lineSynth, pause: true);
        PausedChanged?.Invoke(this, EventArgs.Empty);
    }

    /// <summary>Carries on reading from where it was paused.</summary>
    public void Resume()
    {
        if (!IsPaused)
        {
            return;
        }
        IsPaused = false;
        Ui.Dispatcher.Invoke(() => _player?.Play());
        PauseVoice(_synth, pause: false);
        PauseVoice(_lineSynth, pause: false);
        _resumed?.TrySetResult();
        _resumed = null;
        PausedChanged?.Invoke(this, EventArgs.Empty);
    }

    private static void PauseVoice(SpeechSynthesizer? synth, bool pause)
    {
        try
        {
            if (synth is null)
            {
                return;
            }
            if (pause && synth.State == SynthesizerState.Speaking)
            {
                synth.Pause();
            }
            else if (!pause && synth.State == SynthesizerState.Paused)
            {
                synth.Resume();
            }
        }
        catch (Exception ex) when (ex is InvalidOperationException or ObjectDisposedException)
        {
            // The voice finished meanwhile.
        }
    }

    /// <summary>
    /// Plays MP3 audio through WPF's media player and returns when it ends. The player belongs to the UI thread; the
    /// audio goes through a temporary file, deleted afterwards.
    /// </summary>
    private async Task PlayMp3Async(SpeechAudio speech, CancellationToken token, Action<string> said)
    {
        var audio = speech.Audio;
        var folder = AppCaches.Temp;
        Directory.CreateDirectory(folder);
        var file = Path.Combine(folder, $"speech-{Guid.NewGuid():N}.mp3");
        await File.WriteAllBytesAsync(file, audio, token);
        MediaPlayer? player = null;
        System.Windows.Threading.DispatcherTimer? words = null;
        try
        {
            await WhilePausedAsync(token);
            var done = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            await Ui.Dispatcher.InvokeAsync(() =>
            {
                player = new MediaPlayer();
                player.MediaOpened += (_, _) => Logging.Info($"Speech: playing {audio.Length:N0} bytes ({player.NaturalDuration})");
                player.MediaEnded += (_, _) => done.TrySetResult();
                player.MediaFailed += (_, e) => done.TrySetException(new IOException("The audio could not be played: " + e.ErrorException?.Message, e.ErrorException));
                player.Open(new Uri(file));
                _player = player;
                if (!IsPaused)
                {
                    player.Play();
                }
                // Each word as the playback reaches it (the position stands still while paused).
                if (speech.Words.Count > 0)
                {
                    var next = 0;
                    words = new System.Windows.Threading.DispatcherTimer(System.Windows.Threading.DispatcherPriority.Render) { Interval = TimeSpan.FromMilliseconds(30) };
                    words.Tick += (_, _) =>
                    {
                        var at = player.Position;
                        while (next < speech.Words.Count && speech.Words[next].Offset <= at)
                        {
                            said(speech.Words[next++].Text);
                        }
                    };
                    words.Start();
                }
            });
            using (token.Register(() => done.TrySetCanceled(token)))
            {
                await done.Task;
            }
        }
        finally
        {
            await Ui.Dispatcher.InvokeAsync(() =>
            {
                words?.Stop();
                if (_player == player)
                {
                    _player = null;
                }
                player?.Stop();
                player?.Close();
            });
            try
            {
                File.Delete(file);
            }
            catch (IOException)
            {
                // Still held by the player for a moment: the temp folder is cleaned up eventually.
            }
        }
    }

    /// <summary>
    /// Writes the transcript as one MP3 file in Edge's natural voices (MP3 frames of one format join end to end). Lines
    /// in a Windows voice cannot go into an MP3; the WAV writer is for those.
    /// </summary>
    public async Task SaveMp3Async(string path, IReadOnlyList<(string Text, string? Voice, double Rate, double Pitch)> lines, CancellationToken ct = default)
    {
        await using var output = File.Create(path);
        foreach (var (text, voice, rate, pitch) in lines)
        {
            var speakable = Speakable(text);
            if (speakable.Length == 0)
            {
                continue;
            }
            var chosen = Resolve(voice);
            foreach (var piece in EdgeTts.Split(speakable))
            {
                var audio = await EdgeTts.SynthesizeAsync(piece, EdgeTts.IsNatural(chosen) ? chosen! : EdgeTts.DefaultVoice, rate, pitch, ct);
                await output.WriteAsync(audio, ct);
            }
        }
    }

    /// <summary>Whether saved audio should be MP3 (natural voices on).</summary>
    public bool SavesMp3 => NaturalVoices;

    /// <summary>Writes the transcript as one WAV file.</summary>
    public static void SaveWave(string path, IReadOnlyList<(string Text, string? Voice, double Rate, double Pitch)> lines)
    {
        using var synth = new SpeechSynthesizer();
        synth.SetOutputToWaveFile(path);
        foreach (var (text, voice, rate, pitch) in lines)
        {
            SelectVoice(synth, EdgeTts.IsNatural(voice) ? null : voice);
            synth.Rate = RateFor(rate);
            SpeakLine(synth, text);
        }
        synth.SetOutputToNull();
    }

    /// <summary>
    /// Speaks one line as plain text. (An SSML prompt with an empty style made System.Speech throw "XML content not valid";
    /// plain text never goes through the SSML parser.) A line the engine still rejects is skipped, not fatal.
    /// </summary>
    private static void SpeakLine(SpeechSynthesizer synth, string text)
    {
        var speakable = Speakable(text);
        if (speakable.Length == 0)
        {
            return;
        }
        try
        {
            synth.Speak(speakable);
        }
        catch (Exception ex) when (ex is FormatException or ArgumentException)
        {
            Logging.Error(ex, "A transcript line could not be spoken and was skipped");
        }
    }

    private static int RateFor(double rate) => (int)Math.Clamp(Math.Round((rate - 1) * 10), -10, 10);

    private static void SelectVoice(SpeechSynthesizer synth, string? voice)
    {
        if (string.IsNullOrWhiteSpace(voice) || EdgeTts.IsNatural(voice))
        {
            return;
        }
        try
        {
            synth.SelectVoice(voice);
        }
        catch (ArgumentException)
        {
            // The voice is not installed here: keep the default one.
        }
    }

    public void Stop()
    {
        // A paused Windows voice does not cancel until it carries on: resume it, then cancel.
        if (IsPaused)
        {
            IsPaused = false;
            PauseVoice(_synth, pause: false);
            PauseVoice(_lineSynth, pause: false);
            _resumed?.TrySetResult();
            _resumed = null;
            PausedChanged?.Invoke(this, EventArgs.Empty);
        }
        if (Reading is not null)
        {
            Reading = null;
            Ui.Post(() => ReadingEnded?.Invoke());
        }
        _playback?.Cancel();
        try
        {
            _synth?.SpeakAsyncCancelAll();
        }
        catch (ObjectDisposedException)
        {
        }
        IsSpeaking = false;
    }

    // ----- Dictation (Settings → Voice → Microphone) -----

    /// <summary>The microphone to dictate with (a name from <see cref="Microphone.Devices"/>); empty: the Windows default.</summary>
    public string? MicrophoneName { get; set; }

    /// <summary>The language to dictate in (an installed recogniser's culture, e.g. "en-GB"); empty: Windows'.</summary>
    public string? DictationLanguage { get; set; }

    /// <summary>The microphone button is clicked to start and again to stop (instead of held).</summary>
    public bool MicrophoneToggles { get; set; } = true;

    /// <summary>Dictation stops by itself after this many seconds without sound (0: never).</summary>
    public int SilenceStopSeconds { get; set; } = 5;

    /// <summary>The lowest level that counts as sound at all.</summary>
    public const double SoundLevel = 0.02;

    /// <summary>The level above which the microphone hears sound (speech), given the room's own noise level.</summary>
    public static double SoundAbove(double room) => Math.Max(SoundLevel, room * 3 + 0.03);

    /// <summary>A dictated question is sent as soon as dictation stops.</summary>
    public bool DictationSends { get; set; }

    /// <summary>Dictate with Windows' online speech recognition (else Whisper or the offline recogniser).</summary>
    public bool DictationOnline { get; set; } = true;

    /// <summary>Dictate with a Whisper model on this PC (the microphone chosen; transcribed when dictation stops).</summary>
    public bool DictationWhisper { get; set; } = true;

    /// <summary>The Whisper model used (an id of <see cref="WhisperDictation.Models"/>).</summary>
    public string? WhisperModelId { get; set; }

    private WhisperDictation? _whisper;

    /// <summary>The words heard so far while dictating (online: as they are recognised).</summary>
    public event Action<string>? Hearing;

    /// <summary>The loudest sound just recorded (0–1), while dictating.</summary>
    public double MicrophoneLevel => _whisper?.Level ?? (_microphone ?? _meter)?.Level ?? 0;

    /// <summary>Whether dictation is listening now.</summary>
    public bool IsListening { get; private set; }

    /// <summary>The microphone's level while dictation listens (for the sound's trace), else null.</summary>
    public static double? ListeningLevel => _current is { IsListening: true } speech ? speech.MicrophoneLevel : null;

    private static SpeechService? _current;
    private OnlineDictation? _online;
    private Microphone? _meter;

    /// <summary>
    /// Starts dictation: with Windows' online speech recognition when chosen (it listens to the Windows default
    /// microphone, which is recorded here too, for the level), else — or when it cannot start, said why — offline.
    /// </summary>
    public async Task<bool> StartDictationAsync()
    {
        _current = this;
        if (DictationWhisper)
        {
            var model = WhisperDictation.ModelFor(WhisperModelId);
            if (model.IsInstalled)
            {
                try
                {
                    _whisper = new WhisperDictation();
                    // The words appear while speaking (transcribed every moment); the final text when dictation stops.
                    _whisper.Start(MicrophoneName, model, DictationLanguage, text => Ui.Post(() => Hearing?.Invoke(text)));
                    IsListening = true;
                    return true;
                }
                catch (InvalidOperationException ex)
                {
                    _whisper?.Dispose();
                    _whisper = null;
                    Ui.Notify(ex.Message);
                    return false;
                }
            }
            // Not downloaded yet: Windows' recognition this time (online, then offline), and how to get the model.
            Ui.Notify($"The Whisper model {model.Name} is not downloaded yet (Settings → Voice → Microphone → Download); using Windows' speech recognition for now.");
        }
        if (DictationOnline || DictationWhisper)
        {
            try
            {
                _online = new OnlineDictation();
                _online.Hearing += text => Ui.Post(() => Hearing?.Invoke(text));
                await _online.StartAsync(DictationLanguage);
                try
                {
                    _meter = new Microphone();
                    _meter.Start(null);
                }
                catch (InvalidOperationException)
                {
                    _meter?.Dispose();
                    _meter = null; // no level, still dictation
                }
                IsListening = true;
                return true;
            }
            catch (InvalidOperationException ex)
            {
                Logging.Info("Online dictation: " + ex.Message);
                _online = null;
                Ui.Notify(ex.Message + " Using the offline recogniser for now.");
            }
        }
        IsListening = StartDictation();
        return IsListening;
    }

    /// <summary>The languages speech can be dictated in on this PC (installed recognisers).</summary>
    public static IReadOnlyList<string> DictationLanguages()
    {
        try
        {
            return SpeechRecognitionEngine.InstalledRecognizers().Select(r => r.Culture.Name).Distinct().OrderBy(n => n, StringComparer.Ordinal).ToList();
        }
        catch (Exception ex) when (ex is InvalidOperationException or PlatformNotSupportedException or System.Runtime.InteropServices.COMException)
        {
            return [];
        }
    }

    private Microphone? _microphone;
    private RecordedSound? _sound;
    private TaskCompletionSource? _recognized;

    /// <summary>Starts dictation with the chosen microphone and language; returns false when it cannot.</summary>
    public bool StartDictation()
    {
        try
        {
            _dictated.Clear();
            _recognizer?.Dispose();
            _recognizer = CreateRecognizer();
            _recognized = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            _recognizer.RecognizeCompleted += (_, _) => _recognized?.TrySetResult();
            // The chosen microphone, recorded here; if it cannot be opened, Windows' default microphone directly.
            try
            {
                _microphone = new Microphone();
                _sound = new RecordedSound();
                var sound = _sound;
                _microphone.Recorded += sound.Add;
                _microphone.Start(MicrophoneName);
                _recognizer.SetInputToAudioStream(sound,
                    new System.Speech.AudioFormat.SpeechAudioFormatInfo(Microphone.SampleRate, System.Speech.AudioFormat.AudioBitsPerSample.Sixteen, System.Speech.AudioFormat.AudioChannel.Mono));
            }
            catch (InvalidOperationException ex)
            {
                // No such microphone (unplugged, or a PC without one) is expected: Windows' default input is used instead.
                Logging.Info($"Microphone: {ex.Message} Using Windows' default input.");
                _microphone?.Dispose();
                _microphone = null;
                _sound = null;
                _recognizer.SetInputToDefaultAudioDevice();
            }
            _recognizer.RecognizeAsync(RecognizeMode.Multiple);
            return true;
        }
        catch (Exception ex) when (ex is InvalidOperationException or PlatformNotSupportedException or ArgumentException or System.Runtime.InteropServices.COMException)
        {
            StopMicrophone();
            Ui.Notify("Speech recognition is not available on this PC (Windows Settings → Time & language → Speech).");
            return false;
        }
    }

    /// <summary>Stops dictation and returns what was heard.</summary>
    public async Task<string> StopDictationAsync()
    {
        IsListening = false;
        if (_whisper is { } whisper)
        {
            _whisper = null;
            var model = WhisperDictation.ModelFor(WhisperModelId);
            Ui.Post(() => Hearing?.Invoke($"Transcribing with Whisper ({model.Name})…"));
            try
            {
                var started = System.Diagnostics.Stopwatch.StartNew();
                var text = await whisper.StopAsync(model, DictationLanguage);
                Logging.Info($"Whisper {model.Id}: {whisper.BytesRecorded:N0} bytes transcribed in {started.ElapsedMilliseconds:N0} ms; {text.Length} characters.");
                return text;
            }
            catch (Exception ex) when (ex is InvalidOperationException or IOException or Whisper.net.Wave.CorruptedWaveException or ArgumentException)
            {
                Logging.Error(ex, "Whisper");
                Ui.Notify("Whisper could not transcribe it: " + ex.Message);
                return "";
            }
            finally
            {
                whisper.Dispose();
            }
        }
        if (_online is { } online)
        {
            _online = null;
            var heard = await online.StopAsync();
            if (_meter is { } meter)
            {
                Logging.Info($"Online dictation: {meter.BytesRecorded:N0} bytes from the Windows default microphone; heard {heard.Length} characters.");
                meter.Dispose();
                _meter = null;
            }
            return heard;
        }
        if (_recognizer is null)
        {
            return "";
        }
        try
        {
            if (_sound is not null)
            {
                // The recording ends; the recogniser finishes what it has heard, then completes.
                StopMicrophone();
                await Task.WhenAny(_recognized?.Task ?? Task.CompletedTask, Task.Delay(4000));
            }
            else
            {
                _recognizer.RecognizeAsyncStop();
                await Task.Delay(600); // let the last phrase finish
            }
        }
        catch (InvalidOperationException)
        {
        }
        return _dictated.ToString().Trim();
    }

    private void StopMicrophone()
    {
        if (_microphone is { } microphone)
        {
            Logging.Info($"Microphone: {microphone.BytesRecorded:N0} bytes recorded from {(string.IsNullOrWhiteSpace(MicrophoneName) ? "the Windows default" : MicrophoneName)}.");
        }
        _microphone?.Dispose();
        _microphone = null;
        _sound?.Finish();
        _sound = null;
    }

    private SpeechRecognitionEngine CreateRecognizer()
    {
        var language = DictationLanguage;
        var installed = string.IsNullOrWhiteSpace(language) ? null
            : SpeechRecognitionEngine.InstalledRecognizers().FirstOrDefault(r => r.Culture.Name.Equals(language, StringComparison.OrdinalIgnoreCase));
        var recognizer = installed is null ? new SpeechRecognitionEngine() : new SpeechRecognitionEngine(installed);
        recognizer.LoadGrammar(new DictationGrammar());
        recognizer.SpeechRecognized += (_, e) =>
        {
            if (e.Result.Confidence > 0.3)
            {
                _dictated.Append(e.Result.Text).Append(' ');
            }
        };
        return recognizer;
    }

    public void Dispose()
    {
        Stop();
        StopMicrophone();
        _meter?.Dispose();
        _online?.Dispose();
        _whisper?.Dispose();
        _synth?.Dispose();
        _recognizer?.Dispose();
    }

    [GeneratedRegex(@"```[\s\S]*?```")]
    private static partial Regex FenceRegex();

    [GeneratedRegex(@"\[([^\]]+)\]\([^)]+\)")]
    private static partial Regex LinkRegex();

    [GeneratedRegex(@"^[ \t]*#{1,6}[ \t]+", RegexOptions.Multiline)]
    private static partial Regex HeadingMarkRegex();

    [GeneratedRegex(@"\[\d+\]")]
    private static partial Regex CitationRegex();

    [GeneratedRegex(@"^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)*\|?\s*$", RegexOptions.Multiline)]
    private static partial Regex TableRuleRegex();

    [GeneratedRegex(@"\s+")]
    private static partial Regex WhitespaceRegex();
}
