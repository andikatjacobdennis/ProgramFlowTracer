using System.Collections;
using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace DocGen.Explorer.Infrastructure;

public sealed class BoolToVisibilityConverter : IValueConverter
{
    public bool Invert { get; set; }

    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        => (value is true) ^ Invert ? Visibility.Visible : Visibility.Collapsed;

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
        => value is Visibility.Visible ^ Invert;
}

public sealed class NullToVisibilityConverter : IValueConverter
{
    public bool Invert { get; set; }

    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        => (value is not null && value is not "") ^ Invert ? Visibility.Visible : Visibility.Collapsed;

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class StringToVisibilityConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        => string.IsNullOrWhiteSpace(value as string) ? Visibility.Collapsed : Visibility.Visible;

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class CountToVisibilityConverter : IValueConverter
{
    public bool Invert { get; set; }

    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var count = value switch
        {
            int i => i,
            ICollection c => c.Count,
            IEnumerable e => e.Cast<object>().Any() ? 1 : 0,
            _ => 0,
        };
        return (count > 0) ^ Invert ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class InverseBoolConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) => value is not true;

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) => value is not true;
}

/// <summary>All the bound values are equal (as text): a chip of a list is the chosen one.</summary>
public sealed class AllEqualConverter : IMultiValueConverter
{
    public object Convert(object?[] values, Type targetType, object? parameter, CultureInfo culture)
        => values.Length > 0 && values.Select(v => v?.ToString()).Distinct(StringComparer.Ordinal).Count() == 1;

    public object[] ConvertBack(object? value, Type[] targetTypes, object? parameter, CultureInfo culture) => [];
}

/// <summary>value == parameter (string comparison); ConvertBack returns the parameter when checked (for radio groups).</summary>
public sealed class EqualsConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
        => (parameter?.ToString() ?? "").Split('|').Contains(value?.ToString(), StringComparer.Ordinal);

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        if (value is not true || parameter is null)
        {
            return Binding.DoNothing;
        }
        if (targetType.IsEnum)
        {
            return Enum.Parse(targetType, parameter.ToString()!);
        }
        if (targetType == typeof(int) || targetType == typeof(int?))
        {
            return int.Parse(parameter.ToString()!, CultureInfo.InvariantCulture);
        }
        return parameter;
    }
}

public sealed class EqualsToVisibilityConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var options = (parameter?.ToString() ?? "").Split('|');
        return options.Contains(value?.ToString()) ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class CountToBoolConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) => value is int i && i > 0;

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) => Binding.DoNothing;
}

/// <summary>A 0..100 percentage to a width within the given maximum (parameter).</summary>
public sealed class PercentToWidthConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var max = double.TryParse(parameter?.ToString(), NumberStyles.Float, CultureInfo.InvariantCulture, out var m) ? m : 200;
        return value is double d ? Math.Max(2, d / 100 * max) : 2.0;
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) => Binding.DoNothing;
}

public sealed class UpperCaseConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture) => (value?.ToString() ?? "").ToUpperInvariant();

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) => Binding.DoNothing;
}

/// <summary>True when all the values are the same object (e.g. the item and the selected one).</summary>
public sealed class SameConverter : System.Windows.Data.IMultiValueConverter
{
    public static readonly SameConverter Instance = new();

    public object Convert(object[] values, Type targetType, object? parameter, System.Globalization.CultureInfo culture)
        => values.Length > 1 && values.All(v => ReferenceEquals(v, values[0])) && values[0] is not null;

    public object[] ConvertBack(object value, Type[] targetTypes, object? parameter, System.Globalization.CultureInfo culture) => throw new NotSupportedException();
}

/// <summary>A count in little room: 980, 1,234, then 12.4k, 125k, 1.2M.</summary>
public sealed class CompactCountConverter : IValueConverter
{
    public object Convert(object? value, Type targetType, object? parameter, CultureInfo culture)
    {
        var n = value is int i ? i : 0;
        return n switch
        {
            < 10_000 => n.ToString("N0", culture),
            < 100_000 => (n / 1000.0).ToString("0.#", culture) + "k",
            < 1_000_000 => (n / 1000).ToString(culture) + "k",
            _ => (n / 1_000_000.0).ToString("0.#", culture) + "M",
        };
    }

    public object ConvertBack(object? value, Type targetType, object? parameter, CultureInfo culture) => Binding.DoNothing;
}
