namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// The files the program unpacks from itself for each Windows user: mermaid.js with the ELK layout, and the Whisper
/// engine. They live in %LOCALAPPDATA%\DocGen.Explorer\cache\(kind)\(build) — one folder per build of the program, so a
/// newer or rebuilt program never reads files another build left, and older builds' folders are deleted on start.
/// Uninstalling removes the whole cache folder (and the speech audio in %TEMP%\DocGen.Explorer); settings, data
/// folders and downloaded Whisper models are kept.
/// </summary>
public static class AppCaches
{
    /// <summary>
    /// Tests only: a folder standing in for both %LOCALAPPDATA% and %TEMP% (its LocalAppData and Temp subfolders), so a
    /// test never touches the real ones. Null in the program.
    /// </summary>
    internal static string? TestRoot { get; set; }

    private static string LocalAppData => TestRoot is { } test ? Path.Combine(test, "LocalAppData") : Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);

    /// <summary>%LOCALAPPDATA%\DocGen.Explorer\cache — the setup removes this folder when the program is uninstalled.</summary>
    public static string Root => Path.Combine(LocalAppData, "DocGen.Explorer", "cache");

    /// <summary>%TEMP%\DocGen.Explorer: audio being spoken (each file is deleted after it plays).</summary>
    public static string Temp => Path.Combine(TestRoot is { } test ? Path.Combine(test, "Temp") : Path.GetTempPath(), "DocGen.Explorer");

    /// <summary>This build: its version and its module id, which changes with every build even when the version does not.</summary>
    public static string Build { get; } = BuildName();

    /// <summary>The folder of <paramref name="kind"/> for this build (not created).</summary>
    public static string Folder(string kind) => Path.Combine(Root, kind, Build);

    /// <summary>
    /// Deletes what other builds unpacked, what an earlier version left in its old places, and speech audio older than a
    /// day (left when the program was closed while speaking). A folder in use by another running copy is left for later.
    /// </summary>
    public static void Tidy()
    {
        var local = Path.Combine(LocalAppData, "DocGen.Explorer");
        // Before the cache folder, each kind was unpacked here, named by version only.
        foreach (var old in new[] { Path.Combine(local, "mermaid"), Path.Combine(local, "whisper-native") })
        {
            TryDelete(old);
        }
        if (Directory.Exists(Root))
        {
            foreach (var kind in Directory.EnumerateDirectories(Root))
            {
                foreach (var build in Directory.EnumerateDirectories(kind))
                {
                    if (!string.Equals(Path.GetFileName(build), Build, StringComparison.OrdinalIgnoreCase))
                    {
                        TryDelete(build);
                    }
                }
            }
        }
        if (Directory.Exists(Temp))
        {
            foreach (var file in Directory.EnumerateFiles(Temp, "speech-*.mp3"))
            {
                try
                {
                    if (File.GetLastWriteTimeUtc(file) < DateTime.UtcNow.AddDays(-1))
                    {
                        File.Delete(file);
                    }
                }
                catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
                {
                    // in use: next time
                }
            }
        }
    }

    private static void TryDelete(string folder)
    {
        if (!Directory.Exists(folder))
        {
            return;
        }
        try
        {
            Directory.Delete(folder, recursive: true);
            Logging.Info($"Cache: removed {folder}.");
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            Logging.Info($"Cache: {folder} is in use; it is removed on a later start.");
        }
    }

    private static string BuildName()
    {
        var assembly = typeof(AppCaches).Assembly;
        var version = assembly.GetName().Version?.ToString(3) ?? "1.0.0";
        return $"{version}-{assembly.ManifestModule.ModuleVersionId.ToString("N")[..12]}";
    }
}
