using Microsoft.Extensions.Logging;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// The engine's own logging (indexing, the model gateway, storage…) written to the explorer's log files, so the log
/// viewer shows everything in one place: information and above from the explorer, warnings and above from the framework.
/// </summary>
public sealed class LogFileLoggers : ILoggerFactory
{
    public ILogger CreateLogger(string categoryName) => new FileLogger(categoryName);

    public void AddProvider(ILoggerProvider provider)
    {
    }

    public void Dispose()
    {
    }

    private sealed class FileLogger(string category) : ILogger
    {
        // "DocGen.Explorer.Engine.Indexing.IndexingPipeline" → "IndexingPipeline".
        private readonly string _source = category[(category.LastIndexOf('.') + 1)..];
        private readonly bool _framework = category.StartsWith("Microsoft.", StringComparison.Ordinal) || category.StartsWith("System.", StringComparison.Ordinal);

        public IDisposable? BeginScope<TState>(TState state) where TState : notnull => null;

        public bool IsEnabled(LogLevel logLevel) => logLevel != LogLevel.None && logLevel >= (_framework ? LogLevel.Warning : LogLevel.Information);

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception?, string> formatter)
        {
            if (!IsEnabled(logLevel))
            {
                return;
            }
            var message = formatter(state, exception);
            if (exception is not null)
            {
                message += ": " + exception;
            }
            var level = logLevel switch
            {
                LogLevel.Critical or LogLevel.Error => "ERROR",
                LogLevel.Warning => "WARN",
                LogLevel.Information => "INFO",
                _ => "DEBUG",
            };
            Logging.Write(level, message, _source);
        }
    }
}
