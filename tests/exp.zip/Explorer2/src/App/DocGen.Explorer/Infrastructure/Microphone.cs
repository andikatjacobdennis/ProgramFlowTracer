using System.Runtime.InteropServices;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// The microphones of this PC, and recording from one of them as 16 kHz 16-bit mono PCM (what speech recognition
/// takes). Windows' speech recogniser listens only to the default microphone; recording here lets the person choose
/// one, and gives the sound level for a meter. Uses the Windows wave-in API (winmm), with a thread that hands each
/// filled buffer on and gives it back to the device.
/// </summary>
public sealed class Microphone : IDisposable
{
    public const int SampleRate = 16_000;
    private const int BufferMs = 50;
    private const int BufferCount = 8;
    private const int WaveMapper = -1;

    /// <summary>The name for "the microphone Windows uses by default".</summary>
    public const string WindowsDefault = "Windows default";

    private readonly IntPtr _event = CreateEvent(IntPtr.Zero, false, false, null);
    private readonly List<(IntPtr Header, IntPtr Data)> _buffers = [];
    private IntPtr _device;
    private Thread? _thread;
    private volatile bool _running;

    /// <summary>Recorded sound (16 kHz 16-bit mono PCM), as it arrives (on the recording thread).</summary>
    public event Action<byte[]>? Recorded;

    /// <summary>The loudest sound in the last buffer (0–1), for a level meter.</summary>
    public double Level { get; private set; }

    /// <summary>How much sound has been recorded (bytes), for checks.</summary>
    public long BytesRecorded { get; private set; }

    /// <summary>
    /// Whether Windows lets this app use a microphone: Windows Settings → Privacy &amp; security → Microphone, for everyone
    /// (the PC) and for this user, with "Let desktop apps access your microphone". Read only.
    /// </summary>
    public static bool AccessAllowed()
    {
        const string store = @"Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone";
        static bool Denied(Microsoft.Win32.RegistryKey root, string path)
        {
            try
            {
                using var key = root.OpenSubKey(path);
                return string.Equals(key?.GetValue("Value") as string, "Deny", StringComparison.OrdinalIgnoreCase);
            }
            catch (Exception ex) when (ex is System.Security.SecurityException or UnauthorizedAccessException or IOException)
            {
                return false;
            }
        }
        return !Denied(Microsoft.Win32.Registry.LocalMachine, store)
               && !Denied(Microsoft.Win32.Registry.CurrentUser, store)
               && !Denied(Microsoft.Win32.Registry.CurrentUser, store + @"\NonPackaged");
    }

    /// <summary>Why dictation cannot be used now, or null when it can (a microphone is there and the app may use it).</summary>
    public static string? Unavailable()
        => Devices().Count == 0 ? "No microphone is connected."
            : !AccessAllowed() ? "Windows does not let apps use the microphone (Windows Settings → Privacy & security → Microphone)."
            : null;

    /// <summary>The microphones Windows lists (their names, as short as Windows gives them).</summary>
    public static IReadOnlyList<string> Devices()
    {
        var names = new List<string>();
        var count = waveInGetNumDevs();
        for (var i = 0; i < count; i++)
        {
            var caps = new WAVEINCAPS();
            if (waveInGetDevCaps(i, ref caps, Marshal.SizeOf<WAVEINCAPS>()) == 0 && caps.szPname is { Length: > 0 } name)
            {
                names.Add(name);
            }
        }
        return names;
    }

    /// <summary>Starts recording from <paramref name="name"/> (a name from <see cref="Devices"/>; anything else: the Windows default).</summary>
    public void Start(string? name)
    {
        if (_running)
        {
            return;
        }
        var index = string.IsNullOrWhiteSpace(name) || name == WindowsDefault ? -1 : Devices().ToList().IndexOf(name);
        var format = new WAVEFORMATEX { wFormatTag = 1, nChannels = 1, nSamplesPerSec = SampleRate, wBitsPerSample = 16, nBlockAlign = 2, nAvgBytesPerSec = SampleRate * 2 };
        var result = waveInOpen(out _device, index < 0 ? WaveMapper : index, ref format, _event, IntPtr.Zero, CallbackEvent);
        if (result != 0)
        {
            throw new InvalidOperationException($"The microphone could not be opened (wave-in error {result}).");
        }
        var bytes = SampleRate * 2 * BufferMs / 1000;
        for (var i = 0; i < BufferCount; i++)
        {
            var data = Marshal.AllocHGlobal(bytes);
            var header = Marshal.AllocHGlobal(Marshal.SizeOf<WAVEHDR>());
            Marshal.StructureToPtr(new WAVEHDR { lpData = data, dwBufferLength = bytes }, header, false);
            waveInPrepareHeader(_device, header, Marshal.SizeOf<WAVEHDR>());
            waveInAddBuffer(_device, header, Marshal.SizeOf<WAVEHDR>());
            _buffers.Add((header, data));
        }
        _running = true;
        _thread = new Thread(Pump) { IsBackground = true, Name = "Microphone" };
        _thread.Start();
        waveInStart(_device);
    }

    // Each filled buffer: its sound handed on, then given back to the device.
    private void Pump()
    {
        while (_running)
        {
            WaitForSingleObject(_event, 200);
            foreach (var (header, data) in _buffers)
            {
                var h = Marshal.PtrToStructure<WAVEHDR>(header);
                if ((h.dwFlags & WhdrDone) == 0)
                {
                    continue;
                }
                if (h.dwBytesRecorded > 0)
                {
                    var sound = new byte[h.dwBytesRecorded];
                    Marshal.Copy(data, sound, 0, sound.Length);
                    Level = Peak(sound);
                    BytesRecorded += sound.Length;
                    Recorded?.Invoke(sound);
                }
                if (_running)
                {
                    h.dwFlags &= ~WhdrDone;
                    h.dwBytesRecorded = 0;
                    Marshal.StructureToPtr(h, header, false);
                    waveInAddBuffer(_device, header, Marshal.SizeOf<WAVEHDR>());
                }
            }
        }
    }

    /// <summary>The loudest sample (0–1) of 16-bit PCM.</summary>
    public static double Peak(byte[] pcm)
    {
        var peak = 0;
        for (var i = 0; i + 1 < pcm.Length; i += 2)
        {
            peak = Math.Max(peak, Math.Abs((int)(short)(pcm[i] | (pcm[i + 1] << 8))));
        }
        return Math.Min(1, peak / 32768.0);
    }

    public void Stop()
    {
        if (!_running)
        {
            return;
        }
        _running = false;
        SetEvent(_event);
        _thread?.Join(1000);
        waveInReset(_device);
        foreach (var (header, data) in _buffers)
        {
            waveInUnprepareHeader(_device, header, Marshal.SizeOf<WAVEHDR>());
            Marshal.FreeHGlobal(header);
            Marshal.FreeHGlobal(data);
        }
        _buffers.Clear();
        waveInClose(_device);
        _device = IntPtr.Zero;
        Level = 0;
    }

    public void Dispose()
    {
        Stop();
        CloseHandle(_event);
    }

    private const int CallbackEvent = 0x00050000;
    private const int WhdrDone = 0x00000001;

    [StructLayout(LayoutKind.Sequential)]
    private struct WAVEFORMATEX
    {
        public short wFormatTag;
        public short nChannels;
        public int nSamplesPerSec;
        public int nAvgBytesPerSec;
        public short nBlockAlign;
        public short wBitsPerSample;
        public short cbSize;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct WAVEHDR
    {
        public IntPtr lpData;
        public int dwBufferLength;
        public int dwBytesRecorded;
        public IntPtr dwUser;
        public int dwFlags;
        public int dwLoops;
        public IntPtr lpNext;
        public IntPtr reserved;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct WAVEINCAPS
    {
        public short wMid;
        public short wPid;
        public int vDriverVersion;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string szPname;
        public int dwFormats;
        public short wChannels;
        public short wReserved1;
    }

    [DllImport("winmm.dll")] private static extern int waveInGetNumDevs();
    [DllImport("winmm.dll", CharSet = CharSet.Unicode, EntryPoint = "waveInGetDevCapsW")] private static extern int waveInGetDevCaps(int device, ref WAVEINCAPS caps, int size);
    [DllImport("winmm.dll")] private static extern int waveInOpen(out IntPtr handle, int device, ref WAVEFORMATEX format, IntPtr callback, IntPtr instance, int flags);
    [DllImport("winmm.dll")] private static extern int waveInPrepareHeader(IntPtr handle, IntPtr header, int size);
    [DllImport("winmm.dll")] private static extern int waveInUnprepareHeader(IntPtr handle, IntPtr header, int size);
    [DllImport("winmm.dll")] private static extern int waveInAddBuffer(IntPtr handle, IntPtr header, int size);
    [DllImport("winmm.dll")] private static extern int waveInStart(IntPtr handle);
    [DllImport("winmm.dll")] private static extern int waveInReset(IntPtr handle);
    [DllImport("winmm.dll")] private static extern int waveInClose(IntPtr handle);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] private static extern IntPtr CreateEvent(IntPtr attributes, bool manualReset, bool initialState, string? name);
    [DllImport("kernel32.dll")] private static extern bool SetEvent(IntPtr handle);
    [DllImport("kernel32.dll")] private static extern int WaitForSingleObject(IntPtr handle, int milliseconds);
    [DllImport("kernel32.dll")] private static extern bool CloseHandle(IntPtr handle);
}

/// <summary>
/// Sound recorded from a <see cref="Microphone"/>, read by speech recognition as a stream: a read waits until sound
/// arrives, and ends once the recording is finished and everything has been read.
/// </summary>
public sealed class RecordedSound : Stream
{
    private readonly Queue<byte[]> _chunks = new();
    private byte[]? _current;
    private int _offset;
    private bool _finished;

    public void Add(byte[] sound)
    {
        lock (_chunks)
        {
            _chunks.Enqueue(sound);
            Monitor.PulseAll(_chunks);
        }
    }

    /// <summary>No more sound comes: reads end once what is left has been read.</summary>
    public void Finish()
    {
        lock (_chunks)
        {
            _finished = true;
            Monitor.PulseAll(_chunks);
        }
    }

    public override int Read(byte[] buffer, int offset, int count)
    {
        lock (_chunks)
        {
            while (_current is null || _offset >= _current.Length)
            {
                if (_chunks.Count > 0)
                {
                    _current = _chunks.Dequeue();
                    _offset = 0;
                }
                else if (_finished)
                {
                    return 0;
                }
                else
                {
                    Monitor.Wait(_chunks, 500);
                }
            }
            var n = Math.Min(count, _current.Length - _offset);
            Array.Copy(_current, _offset, buffer, offset, n);
            _offset += n;
            return n;
        }
    }

    public override bool CanRead => true;
    public override bool CanSeek => false;
    public override bool CanWrite => false;
    // Speech recognition asks for these of a live stream: its length is unknown (-1), and it is never moved.
    public override long Length => -1;
    public override long Position { get => 0; set { } }
    public override void Flush() { }
    public override long Seek(long offset, SeekOrigin origin) => 0;
    public override void SetLength(long value) => throw new NotSupportedException();
    public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();
}
