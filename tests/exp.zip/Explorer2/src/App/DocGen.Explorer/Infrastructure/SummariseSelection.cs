using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// Summarise what is selected: in a page or in an answer (right-click → Summarise selection, or the shortcut), and a
/// diagram (its toolbar's Summarise). The summary arrives as a turn of Ask (of Talk when Talk is open), so it can be read
/// aloud, copied and downloaded like any answer.
/// </summary>
public static class SummariseSelection
{
    private static MainViewModel? Main => Application.Current?.MainWindow?.DataContext as MainViewModel;

    /// <summary>The text selected in a page (FlowDocumentScrollViewer) or an answer (RichTextBox), if any.</summary>
    public static string? SelectedText(object? element) => element switch
    {
        RichTextBox box => box.Selection.Text,
        FlowDocumentScrollViewer viewer => viewer.Selection?.Text,
        _ => null,
    };

    /// <summary>The right-click menu of a page or an answer: Copy, Select all, Summarise selection.</summary>
    public static ContextMenu Menu(Control target)
    {
        var menu = new ContextMenu();
        var copy = new MenuItem { Header = "Copy", Icon = "\uE8C8", Command = ApplicationCommands.Copy, CommandTarget = target, InputGestureText = "Ctrl+C" };
        var all = new MenuItem { Header = "Select all", Icon = "\uE8B3", Command = ApplicationCommands.SelectAll, CommandTarget = target, InputGestureText = "Ctrl+A" };
        var summarise = new MenuItem { Header = "Summarise selection", Icon = Glyph(Icons.Lightbulb) };
        summarise.Click += (_, _) => _ = SummariseAsync(target);
        menu.Items.Add(copy);
        menu.Items.Add(all);
        menu.Items.Add(new Separator());
        menu.Items.Add(summarise);
        // Summarise only when something is selected (the menu says so rather than doing nothing).
        menu.Opened += (_, _) =>
        {
            var has = !string.IsNullOrWhiteSpace(SelectedText(target));
            summarise.IsEnabled = has;
            summarise.ToolTip = has ? "A short summary of the selected text, in Ask" : "Select some text first";
        };
        return menu;
    }

    private static TextBlock Glyph(string glyph)
    {
        var text = new TextBlock { Text = glyph, FontSize = 13 };
        text.SetResourceReference(TextBlock.FontFamilyProperty, "Font.Icons");
        return text;
    }

    /// <summary>Summarises the selection in <paramref name="target"/>, or where the keyboard focus is.</summary>
    public static async Task SummariseAsync(object? target = null)
    {
        if (Main is not { Workspace: { } workspace } main)
        {
            return;
        }
        var element = target ?? Keyboard.FocusedElement;
        var text = SelectedText(element);
        if (string.IsNullOrWhiteSpace(text))
        {
            Ui.Notify("Select some text in a page or an answer first, then choose Summarise selection.");
            return;
        }
        // Where it came from, for the request: the page's title, or an answer.
        var source = element is FlowDocumentScrollViewer && workspace.Documentation.PageTitle is { Length: > 0 } title ? $"“{title}”" : element is RichTextBox ? "an answer" : null;
        await Into(main).SummariseAsync(text, diagram: false, source);
    }

    /// <summary>Summarises a Mermaid diagram from its source.</summary>
    public static async Task SummariseDiagramAsync(string code)
    {
        if (Main is { Workspace: not null } main)
        {
            await Into(main).SummariseAsync(code, diagram: true, null);
        }
    }

    /// <summary>A diagram of a page summarised for showing under it (not kept: pages have no conversation).</summary>
    public static async Task<string> SummariseDiagramHereAsync(string code, Action<string> onDelta)
    {
        if (Main is not { Workspace: { } workspace } main)
        {
            return "";
        }
        var answer = await main.Engine.Assistant.SummaryAnswerAsync(workspace.Record.Id, new Engine.Models.SummaryRequest { Selection = code, Diagram = true }, onDelta);
        return answer.Text;
    }

    // Talk's conversation when Talk is open, else Ask's (shown if it was hidden).
    private static AssistantViewModel Into(MainViewModel main)
    {
        if (main.Section == Section.Talk)
        {
            return main.Workspace!.Talk;
        }
        if (!main.AssistantVisible)
        {
            main.AssistantVisible = true;
        }
        return main.Workspace!.Assistant;
    }
}
