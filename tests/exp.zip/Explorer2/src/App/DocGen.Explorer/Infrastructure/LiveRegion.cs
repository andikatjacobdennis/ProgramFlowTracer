using System.ComponentModel;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Automation.Peers;
using System.Windows.Controls;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// A text that screen readers announce when it changes (a polite live region): ui:LiveRegion.Announce="True" on a
/// TextBlock. WPF only marks the setting; the change has to be raised as an event, which this does — once per real change
/// of the text, so a status that is set again to the same words is not read twice.
/// </summary>
public static class LiveRegion
{
    public static readonly DependencyProperty AnnounceProperty = DependencyProperty.RegisterAttached("Announce", typeof(bool), typeof(LiveRegion),
        new PropertyMetadata(false, OnAnnounceChanged));

    public static bool GetAnnounce(DependencyObject element) => (bool)element.GetValue(AnnounceProperty);
    public static void SetAnnounce(DependencyObject element, bool value) => element.SetValue(AnnounceProperty, value);

    private static readonly DependencyPropertyDescriptor TextDescriptor = DependencyPropertyDescriptor.FromProperty(TextBlock.TextProperty, typeof(TextBlock));

    private static void OnAnnounceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is not TextBlock text)
        {
            return;
        }
        if ((bool)e.NewValue)
        {
            AutomationProperties.SetLiveSetting(text, AutomationLiveSetting.Polite);
            TextDescriptor.AddValueChanged(text, OnTextChanged);
        }
        else
        {
            TextDescriptor.RemoveValueChanged(text, OnTextChanged);
        }
    }

    private static void OnTextChanged(object? sender, EventArgs e)
    {
        if (sender is TextBlock { IsLoaded: true } text && !string.IsNullOrWhiteSpace(text.Text)
            && (UIElementAutomationPeer.FromElement(text) ?? UIElementAutomationPeer.CreatePeerForElement(text)) is { } peer)
        {
            peer.RaiseAutomationEvent(AutomationEvents.LiveRegionChanged);
        }
    }
}
