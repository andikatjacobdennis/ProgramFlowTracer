using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// The mouse wheel everywhere: one notch scrolls the lines set in Settings → Reading and writing (two by default,
/// instead of Windows' three), gliding there when smooth scrolling is on. The wheel goes to the innermost area under the
/// pointer that can still scroll that way, so a code block, an outline or a list scrolls first and the page after it.
/// Shift+wheel scrolls sideways; Ctrl+wheel is left to zoom.
/// </summary>
public static class WheelScrolling
{
    private sealed class Glide
    {
        public double Target;
        public bool Horizontal;
        public bool Running;
    }

    private static readonly ConditionalWeakTable<ScrollViewer, Glide> Glides = [];

    /// <summary>Hooks every ScrollViewer of the app (call once, at start).</summary>
    public static void Register()
        => EventManager.RegisterClassHandler(typeof(ScrollViewer), UIElement.PreviewMouseWheelEvent, new MouseWheelEventHandler(OnPreviewWheel));

    private static void OnPreviewWheel(object sender, MouseWheelEventArgs e)
    {
        if (e.Handled || sender is not ScrollViewer viewer || Keyboard.Modifiers.HasFlag(ModifierKeys.Control) || e.Delta == 0)
        {
            return;
        }
        var horizontal = Keyboard.Modifiers.HasFlag(ModifierKeys.Shift);
        var down = e.Delta < 0;
        // The innermost scroller under the pointer that can move this way takes the wheel (it gets its own turn).
        if (Innermost(e.OriginalSource as DependencyObject, viewer, horizontal, down) is not { } target || !ReferenceEquals(target, viewer))
        {
            return;
        }
        if (!ScrollsByPixel(viewer))
        {
            return; // a list that scrolls by item keeps Windows' own wheel
        }
        e.Handled = true;
        var by = -e.Delta / 120.0 * UiPreferences.Current.WheelPixels;
        var glide = Glides.GetValue(viewer, _ => new Glide());
        var current = horizontal ? viewer.HorizontalOffset : viewer.VerticalOffset;
        var max = horizontal ? viewer.ScrollableWidth : viewer.ScrollableHeight;
        var from = glide.Running && glide.Horizontal == horizontal ? glide.Target : current;
        glide.Target = Math.Clamp(from + by, 0, max);
        glide.Horizontal = horizontal;
        if (!UiPreferences.Current.SmoothScrolling || Motion.Reduced)
        {
            Move(viewer, horizontal, glide.Target);
            return;
        }
        if (!glide.Running)
        {
            glide.Running = true;
            var last = DateTime.UtcNow;
            void Step(object? s, EventArgs a)
            {
                var now = DateTime.UtcNow;
                var dt = Math.Clamp((now - last).TotalMilliseconds, 1, 50);
                last = now;
                var position = glide.Horizontal ? viewer.HorizontalOffset : viewer.VerticalOffset;
                var gap = glide.Target - position;
                if (Math.Abs(gap) < 0.6 || !viewer.IsLoaded)
                {
                    Move(viewer, glide.Horizontal, glide.Target);
                    glide.Running = false;
                    CompositionTarget.Rendering -= Step;
                    return;
                }
                // Eases out: about 90% of the way in 100 ms, whatever the frame rate.
                var share = 1 - Math.Exp(-dt / 43.0);
                Move(viewer, glide.Horizontal, position + gap * share);
            }
            CompositionTarget.Rendering += Step;
        }
    }

    private static void Move(ScrollViewer viewer, bool horizontal, double offset)
    {
        if (horizontal)
        {
            viewer.ScrollToHorizontalOffset(offset);
        }
        else
        {
            viewer.ScrollToVerticalOffset(offset);
        }
    }

    /// <summary>The innermost scroller from <paramref name="source"/> up to <paramref name="outer"/> that can move that way.</summary>
    private static ScrollViewer? Innermost(DependencyObject? source, ScrollViewer outer, bool horizontal, bool down)
    {
        for (var node = source; node is not null; node = Parent(node))
        {
            // A diagram or graph that zooms with the wheel keeps it.
            if (node is Controls.GraphCanvas { Compact: false })
            {
                return null;
            }
            if (node is ScrollViewer viewer && CanMove(viewer, horizontal, down))
            {
                return viewer;
            }
            if (ReferenceEquals(node, outer))
            {
                return null;
            }
        }
        return null;
    }

    private static bool CanMove(ScrollViewer viewer, bool horizontal, bool down)
    {
        var (offset, max) = horizontal ? (viewer.HorizontalOffset, viewer.ScrollableWidth) : (viewer.VerticalOffset, viewer.ScrollableHeight);
        var visible = horizontal ? viewer.ComputedHorizontalScrollBarVisibility : viewer.ComputedVerticalScrollBarVisibility;
        if (max <= 0.5 || (visible != Visibility.Visible && (horizontal ? viewer.HorizontalScrollBarVisibility : viewer.VerticalScrollBarVisibility) == ScrollBarVisibility.Disabled))
        {
            return false;
        }
        return down ? offset < max - 0.5 : offset > 0.5;
    }

    /// <summary>Offsets in pixels (not a list scrolled item by item, where an offset is a count of items).</summary>
    private static bool ScrollsByPixel(ScrollViewer viewer)
    {
        // A list that virtualizes by item scrolls in items; a document view or a pixel-unit list scrolls in pixels.
        return !viewer.CanContentScroll || viewer.TemplatedParent is not ItemsControl items || VirtualizingPanel.GetScrollUnit(items) == ScrollUnit.Pixel;
    }

    private static DependencyObject? Parent(DependencyObject node)
        => node is Visual or System.Windows.Media.Media3D.Visual3D ? VisualTreeHelper.GetParent(node) ?? LogicalTreeHelper.GetParent(node) : LogicalTreeHelper.GetParent(node);
}
