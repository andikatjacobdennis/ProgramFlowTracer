using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace DocGen.Explorer.Infrastructure;

/// <summary>Placeholder text and an optional leading icon glyph for text boxes.</summary>
public static class Hint
{
    public static readonly DependencyProperty TextProperty =
        DependencyProperty.RegisterAttached("Text", typeof(string), typeof(Hint), new FrameworkPropertyMetadata(""));

    public static readonly DependencyProperty IconProperty =
        DependencyProperty.RegisterAttached("Icon", typeof(string), typeof(Hint), new FrameworkPropertyMetadata(null));

    public static string GetText(DependencyObject d) => (string)d.GetValue(TextProperty);

    public static void SetText(DependencyObject d, string value) => d.SetValue(TextProperty, value);

    public static string? GetIcon(DependencyObject d) => (string?)d.GetValue(IconProperty);

    public static void SetIcon(DependencyObject d, string? value) => d.SetValue(IconProperty, value);
}

/// <summary>Corner radius for templated buttons and text boxes.</summary>
public static class Corner
{
    public static readonly DependencyProperty RadiusProperty =
        DependencyProperty.RegisterAttached("Radius", typeof(CornerRadius), typeof(Corner), new FrameworkPropertyMetadata(new CornerRadius(6)));

    public static CornerRadius GetRadius(DependencyObject d) => (CornerRadius)d.GetValue(RadiusProperty);

    public static void SetRadius(DependencyObject d, CornerRadius value) => d.SetValue(RadiusProperty, value);
}

/// <summary>Enter runs a command (Shift+Enter inserts a new line in multi-line boxes); Escape runs another.</summary>
public static class KeyCommands
{
    public static readonly DependencyProperty EnterProperty =
        DependencyProperty.RegisterAttached("Enter", typeof(ICommand), typeof(KeyCommands), new PropertyMetadata(null, OnChanged));

    public static readonly DependencyProperty EscapeProperty =
        DependencyProperty.RegisterAttached("Escape", typeof(ICommand), typeof(KeyCommands), new PropertyMetadata(null, OnChanged));

    public static ICommand? GetEnter(DependencyObject d) => (ICommand?)d.GetValue(EnterProperty);

    public static void SetEnter(DependencyObject d, ICommand? value) => d.SetValue(EnterProperty, value);

    public static ICommand? GetEscape(DependencyObject d) => (ICommand?)d.GetValue(EscapeProperty);

    public static void SetEscape(DependencyObject d, ICommand? value) => d.SetValue(EscapeProperty, value);

    private static void OnChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is UIElement element)
        {
            element.PreviewKeyDown -= OnKeyDown;
            element.PreviewKeyDown += OnKeyDown;
        }
    }

    private static void OnKeyDown(object sender, KeyEventArgs e)
    {
        var d = (DependencyObject)sender;
        if (e.Key == Key.Enter && (Keyboard.Modifiers & ModifierKeys.Shift) == 0 && GetEnter(d) is { } enter)
        {
            if (sender is TextBox box)
            {
                box.GetBindingExpression(TextBox.TextProperty)?.UpdateSource();
            }
            if (enter.CanExecute(null))
            {
                enter.Execute(null);
            }
            e.Handled = true;
        }
        else if (e.Key == Key.Escape && GetEscape(d) is { } escape)
        {
            if (escape.CanExecute(null))
            {
                escape.Execute(null);
            }
            e.Handled = true;
        }
    }
}

/// <summary>Moves keyboard focus to the element when the bound value becomes true.</summary>
public static class FocusOn
{
    public static readonly DependencyProperty WhenProperty =
        DependencyProperty.RegisterAttached("When", typeof(bool), typeof(FocusOn), new PropertyMetadata(false, (d, e) =>
        {
            if (e.NewValue is true && d is UIElement element)
            {
                element.Dispatcher.BeginInvoke(() =>
                {
                    element.Focus();
                    Keyboard.Focus(element);
                    if (element is TextBox box)
                    {
                        box.SelectAll();
                    }
                }, System.Windows.Threading.DispatcherPriority.Input);
            }
        }));

    public static bool GetWhen(DependencyObject d) => (bool)d.GetValue(WhenProperty);

    public static void SetWhen(DependencyObject d, bool value) => d.SetValue(WhenProperty, value);
}
