using System.Windows;
using System.Windows.Media;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// The whole interface's size, Ctrl+= / Ctrl+- / Ctrl+0, as in a browser: one scale on the window and on its pop-ups (menus,
/// drop-downs, tooltips), so text, icons and spacing grow together. Remembered in the explorer's settings.
/// </summary>
public static class UiZoom
{
    public static readonly double[] Levels = [0.8, 0.9, 1.0, 1.1, 1.25, 1.5, 1.75, 2.0];

    public const string ResourceKey = "Zoom.Transform";

    public static double Level { get; private set; } = 1.0;

    /// <summary>The nearest level to a stored value (1 for anything unusable).</summary>
    public static double Nearest(double value)
        => double.IsFinite(value) && value > 0 ? Levels.MinBy(l => Math.Abs(l - value)) : 1.0;

    /// <summary>The next level up (+1) or down (-1), staying within the range.</summary>
    public static double Step(double current, int direction)
    {
        var at = Array.IndexOf(Levels, Nearest(current));
        return Levels[Math.Clamp(at + direction, 0, Levels.Length - 1)];
    }

    /// <summary>
    /// Puts the size in the application's resources ({DynamicResource Zoom.Transform} on the window and the pop-ups). A new
    /// transform each time: one used in templates is frozen by WPF and cannot be changed in place.
    /// </summary>
    public static void Apply(double level)
    {
        Level = level;
        var transform = new ScaleTransform(level, level);
        transform.Freeze();
        if (Application.Current is { } app)
        {
            app.Resources[ResourceKey] = transform;
        }
    }

    public static string Label(double level) => $"{level * 100:0}%";
}
