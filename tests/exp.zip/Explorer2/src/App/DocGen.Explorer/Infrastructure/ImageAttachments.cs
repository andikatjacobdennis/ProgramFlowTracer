using System.Windows.Media;
using System.Windows.Media.Imaging;
using DocGen.Explorer.Engine.Assistant;
using DocGen.Explorer.Engine.Models;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// Attached images, made ready for the model: an image larger than the longest side set in Settings → Attachments is
/// scaled down (keeping its shape), and one still over the size set is saved smaller until it fits. A thumbnail is
/// made for its card.
/// </summary>
public static class ImageAttachments
{
    /// <summary>Reads an image for attaching, scaled within <paramref name="rule"/>.</summary>
    public static Attachment Read(string path, AttachmentRule rule)
    {
        var info = new FileInfo(path);
        byte[] original;
        try
        {
            original = File.ReadAllBytes(path);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return new Attachment { Name = info.Name, Size = info.Exists ? info.Length : 0, Kind = Attachments.Image, Status = AttachmentStatus.Unreadable, Note = "The image could not be opened: " + ex.Message };
        }
        return FromBytes(original, info.Name, rule);
    }

    /// <summary>An image (its file's bytes, or a pasted picture as PNG) for attaching, scaled within <paramref name="rule"/>.</summary>
    public static Attachment FromBytes(byte[] original, string name, AttachmentRule rule)
    {
        var path = name;
        var attachment = new Attachment { Name = name, Size = original.Length, Kind = Attachments.Image };
        if (!rule.Enabled)
        {
            return attachment with { Status = AttachmentStatus.TurnedOff, Note = "Reading images is turned off (Settings → Attachments)." };
        }
        BitmapSource picture;
        try
        {
            var decoder = BitmapDecoder.Create(new MemoryStream(original), BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
            picture = decoder.Frames[0];
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or NotSupportedException or FileFormatException or ArgumentException or InvalidOperationException)
        {
            return attachment with { Status = AttachmentStatus.Unreadable, Note = "The image could not be opened: " + ex.Message };
        }

        var limit = (long)(rule.MaxSizeMb * 1024 * 1024);
        var longest = Math.Max(picture.PixelWidth, picture.PixelHeight);
        var target = rule.MaxPixels > 0 && longest > rule.MaxPixels ? rule.MaxPixels : longest;
        var photo = Path.GetExtension(path).ToLowerInvariant() is ".jpg" or ".jpeg";
        if (target == longest && original.Length <= limit)
        {
            return attachment with { Status = AttachmentStatus.Read, MediaType = MediaType(path), ImageBase64 = Convert.ToBase64String(original) };
        }

        // Scaled to the longest side set; then, while it is still over the size set, saved as JPEG and smaller.
        var bytes = Encode(Scale(picture, target), photo ? "jpeg" : "png");
        var format = photo ? "jpeg" : "png";
        if (bytes.Length > limit)
        {
            format = "jpeg";
            bytes = Encode(Scale(picture, target), format);
        }
        while (bytes.Length > limit && target > 256)
        {
            target = (int)(target * 0.75);
            bytes = Encode(Scale(picture, target), format);
        }
        if (bytes.Length > limit)
        {
            return attachment with { Status = AttachmentStatus.TooLarge, Note = $"Still larger than {rule.MaxSizeMb:0.#} MB when scaled down (Settings → Attachments)." };
        }
        var scaled = Scale(picture, target);
        return attachment with
        {
            Status = AttachmentStatus.Read,
            MediaType = format == "jpeg" ? "image/jpeg" : "image/png",
            ImageBase64 = Convert.ToBase64String(bytes),
            Note = $"Scaled from {picture.PixelWidth}×{picture.PixelHeight} to {scaled.PixelWidth}×{scaled.PixelHeight} ({bytes.Length / 1024.0:0} KB), as set in Settings → Attachments.",
        };
    }

    /// <summary>A small picture of an attached image, for its card (null when it cannot be shown).</summary>
    public static ImageSource? Thumbnail(Attachment attachment, int height = 168)
    {
        if (attachment.ImageBase64 is not { Length: > 0 } data)
        {
            return null;
        }
        try
        {
            var image = new BitmapImage();
            image.BeginInit();
            image.CacheOption = BitmapCacheOption.OnLoad;
            image.DecodePixelHeight = height;
            image.StreamSource = new MemoryStream(Convert.FromBase64String(data));
            image.EndInit();
            image.Freeze();
            return image;
        }
        catch (Exception ex) when (ex is NotSupportedException or FileFormatException or FormatException or ArgumentException or InvalidOperationException)
        {
            return null;
        }
    }

    private static BitmapSource Scale(BitmapSource picture, int longest)
    {
        var current = Math.Max(picture.PixelWidth, picture.PixelHeight);
        if (longest >= current)
        {
            return picture;
        }
        var factor = (double)longest / current;
        var scaled = new TransformedBitmap(picture, new ScaleTransform(factor, factor));
        scaled.Freeze();
        return scaled;
    }

    private static byte[] Encode(BitmapSource picture, string format)
    {
        BitmapEncoder encoder = format == "jpeg" ? new JpegBitmapEncoder { QualityLevel = 88 } : new PngBitmapEncoder();
        // JPEG has no transparency: drawn on white first.
        var frame = format == "jpeg" && picture.Format.Masks.Count == 4 ? OnWhite(picture) : picture;
        encoder.Frames.Add(BitmapFrame.Create(frame));
        using var stream = new MemoryStream();
        encoder.Save(stream);
        return stream.ToArray();
    }

    private static BitmapSource OnWhite(BitmapSource picture)
    {
        var visual = new DrawingVisual();
        using (var dc = visual.RenderOpen())
        {
            var rect = new System.Windows.Rect(0, 0, picture.PixelWidth, picture.PixelHeight);
            dc.DrawRectangle(Brushes.White, null, rect);
            dc.DrawImage(picture, rect);
        }
        var target = new RenderTargetBitmap(picture.PixelWidth, picture.PixelHeight, 96, 96, PixelFormats.Pbgra32);
        target.Render(visual);
        target.Freeze();
        return target;
    }

    private static string MediaType(string path) => Path.GetExtension(path).ToLowerInvariant() switch
    {
        ".png" => "image/png",
        ".gif" => "image/gif",
        ".webp" => "image/webp",
        _ => "image/jpeg",
    };
}
