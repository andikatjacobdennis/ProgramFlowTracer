using Whisper.net;

namespace DocGen.Explorer.Infrastructure;

/// <summary>A Whisper model that can be downloaded (whisper.cpp's GGML files, from Hugging Face).</summary>
public sealed record WhisperModel(string Id, string Name, long Bytes, bool EnglishOnly, string Description)
{
    public string FileName => $"ggml-{Id}.bin";
    public string Url => $"https://huggingface.co/ggerganov/whisper.cpp/resolve/main/{FileName}";
    public string Path => System.IO.Path.Combine(WhisperDictation.ModelFolder, FileName);
    public bool IsInstalled => File.Exists(Path) && new FileInfo(Path).Length > Bytes * 9 / 10;
    public string SizeText => Bytes >= 1024L * 1024 * 1024 ? $"{Bytes / 1024.0 / 1024 / 1024:0.0} GB" : $"{Bytes / 1024.0 / 1024:0} MB";
    public string Label => $"{Name} · {SizeText}{(IsInstalled ? " · installed" : "")}";
}

/// <summary>
/// Dictation with Whisper on this PC (Whisper.net, which runs whisper.cpp): the chosen microphone is recorded, and
/// when dictation stops the recording is transcribed by the downloaded model — no connection, nothing sent anywhere.
/// Ollama has no speech models; this is the local one. Models live in
/// %LOCALAPPDATA%\DocGen.Explorer\Models\whisper, shared by every data folder.
/// </summary>
public sealed class WhisperDictation : IDisposable
{
    /// <summary>The models offered (English-only ones are more accurate in English at the same size).</summary>
    public static readonly IReadOnlyList<WhisperModel> Models =
    [
        new("tiny.en", "Tiny (English)", 77_704_715, true, "Fastest, least accurate."),
        new("base.en", "Base (English)", 147_964_211, true, "Good accuracy, quick on a laptop."),
        new("small.en", "Small (English)", 487_614_201, true, "Most accurate here, slower."),
        new("base", "Base (many languages)", 147_951_465, false, "Follows the Language setting."),
    ];

    public const string DefaultModel = "base.en";

    public static string ModelFolder => System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DocGen.Explorer", "Models", "whisper");

    public static WhisperModel ModelFor(string? id) => Models.FirstOrDefault(m => m.Id == id) ?? Models.First(m => m.Id == DefaultModel);

    // A loaded model is kept (loading takes a moment); one at a time.
    private static WhisperFactory? _factory;
    private static string? _factoryPath;
    private static readonly SemaphoreSlim Gate = new(1, 1);

    private readonly MemoryStream _pcm = new();
    private Microphone? _microphone;

    /// <summary>The level of the microphone while recording.</summary>
    public double Level => _microphone?.Level ?? 0;

    public long BytesRecorded => _pcm.Length;

    private CancellationTokenSource? _live;
    private Task? _liveLoop;

    /// <summary>
    /// Starts recording from <paramref name="microphone"/> (a name from <see cref="Microphone.Devices"/>, or the Windows
    /// default). With <paramref name="partial"/>, what has been said so far is transcribed every moment while speaking
    /// (in the background, skipped while the model is busy) and handed to it, so the words appear as they are spoken; the
    /// whole recording is transcribed once more when dictation stops, for the final text.
    /// </summary>
    public void Start(string? microphone, WhisperModel? model = null, string? language = null, Action<string>? partial = null)
    {
        if (partial is not null && model is { IsInstalled: true })
        {
            _live = new CancellationTokenSource();
            var token = _live.Token;
            _liveLoop = Task.Run(async () =>
            {
                long done = 0;
                while (!token.IsCancellationRequested)
                {
                    await Task.Delay(1500, token).ContinueWith(_ => { }, TaskScheduler.Default);
                    byte[] pcm;
                    lock (_pcm)
                    {
                        pcm = _pcm.Length - done > Microphone.SampleRate ? _pcm.ToArray() : [];
                    }
                    if (token.IsCancellationRequested || pcm.Length == 0)
                    {
                        continue;
                    }
                    done = pcm.Length;
                    // The last 30 seconds at most, so a long dictation stays quick to preview.
                    var window = pcm.Length > Microphone.SampleRate * 2 * 30 ? pcm[^(Microphone.SampleRate * 2 * 30)..] : pcm;
                    try
                    {
                        if (await TranscribeAsync(model, language, window, wait: false, token) is { Length: > 0 } text)
                        {
                            partial(text);
                        }
                    }
                    catch (Exception ex) when (ex is not OutOfMemoryException)
                    {
                        // A preview that fails is only a preview: the final transcription still runs.
                    }
                }
            });
        }
        StartRecording(microphone);
    }

    private void StartRecording(string? microphone)
    {
        _microphone = new Microphone();
        _microphone.Recorded += sound =>
        {
            lock (_pcm)
            {
                _pcm.Write(sound);
            }
        };
        _microphone.Start(microphone);
    }

    /// <summary>Stops recording and transcribes it with <paramref name="model"/>; empty when nothing was said.</summary>
    public async Task<string> StopAsync(WhisperModel model, string? language)
    {
        _microphone?.Dispose();
        _microphone = null;
        // The live preview stops (a preview under way finishes first; it shares the model).
        _live?.Cancel();
        if (_liveLoop is { } loop)
        {
            await Task.WhenAny(loop, Task.Delay(10_000));
        }
        byte[] pcm;
        lock (_pcm)
        {
            pcm = _pcm.ToArray();
        }
        // Under a quarter of a second, or silence: nothing to transcribe.
        if (pcm.Length < Microphone.SampleRate / 2 || Microphone.Peak(pcm) < 0.003)
        {
            return "";
        }
        if (!model.IsInstalled)
        {
            throw new InvalidOperationException($"The Whisper model {model.Name} is not downloaded (Settings → Voice → Microphone).");
        }
        return await TranscribeAsync(model, language, pcm, wait: true, CancellationToken.None) ?? "";
    }

    private static bool _nativeReady;

    /// <summary>
    /// Makes sure Whisper.net finds its native engine. Beside the program (a normal build) it is found as it is; a
    /// single-file program carries it inside, so it is unpacked once into
    /// this build's cache folder (<see cref="AppCaches"/>), under runtimes\win-x64, and Whisper.net is pointed there.
    /// </summary>
    public static void EnsureNativeLibrary()
    {
        if (_nativeReady || File.Exists(System.IO.Path.Combine(AppContext.BaseDirectory, "runtimes", "win-x64", "whisper.dll")))
        {
            _nativeReady = true;
            return;
        }
        var assembly = typeof(WhisperDictation).Assembly;
        var names = assembly.GetManifestResourceNames().Where(n => n.StartsWith("whisper-native/", StringComparison.Ordinal)).ToList();
        if (names.Count == 0)
        {
            return; // nothing to unpack: Whisper.net reports what is missing
        }
        var root = AppCaches.Folder("whisper-native");
        var folder = System.IO.Path.Combine(root, "runtimes", "win-x64");
        Directory.CreateDirectory(folder);
        foreach (var name in names)
        {
            var target = System.IO.Path.Combine(folder, name["whisper-native/".Length..]);
            using var source = assembly.GetManifestResourceStream(name)!;
            if (File.Exists(target) && new FileInfo(target).Length == source.Length)
            {
                continue;
            }
            using var file = File.Create(target);
            source.CopyTo(file);
        }
        // Whisper.net looks in runtimes\win-x64 under the folder of this path.
        Whisper.net.LibraryLoader.RuntimeOptions.LibraryPath = System.IO.Path.Combine(root, "whisper.dll");
        Logging.Info($"Whisper: native engine unpacked to {folder}.");
        _nativeReady = true;
    }

    /// <summary>Transcribes 16 kHz PCM with the model (one transcription at a time); null when <paramref name="wait"/> is false and the model is busy.</summary>
    private static async Task<string?> TranscribeAsync(WhisperModel model, string? language, byte[] pcm, bool wait, CancellationToken ct)
    {
        return await Task.Run(async () =>
        {
            if (wait)
            {
                await Gate.WaitAsync(CancellationToken.None);
            }
            else if (!await Gate.WaitAsync(0, ct))
            {
                return null;
            }
            try
            {
                if (_factory is null || _factoryPath != model.Path)
                {
                    EnsureNativeLibrary();
                    _factory?.Dispose();
                    _factory = WhisperFactory.FromPath(model.Path);
                    _factoryPath = model.Path;
                }
                // English models are told English; a multilingual one the language chosen ("en-GB" → "en"), else it detects it.
                var lang = model.EnglishOnly ? "en" : string.IsNullOrWhiteSpace(language) ? "auto" : language.Split('-')[0].ToLowerInvariant();
                await using var processor = _factory.CreateBuilder().WithLanguage(lang).Build();
                using var wave = Wave(pcm);
                var text = new System.Text.StringBuilder();
                await foreach (var segment in processor.ProcessAsync(wave, ct))
                {
                    text.Append(segment.Text);
                }
                return Clean(text.ToString());
            }
            finally
            {
                Gate.Release();
            }
        }, CancellationToken.None);
    }

    /// <summary>Whisper's markers for no speech ("[BLANK_AUDIO]", "(music)") are not words.</summary>
    public static string Clean(string text)
    {
        var cleaned = System.Text.RegularExpressions.Regex.Replace(text, @"\[[^\]]*\]|\([^)]*\)", " ");
        return System.Text.RegularExpressions.Regex.Replace(cleaned, @"\s+", " ").Trim();
    }

    /// <summary>16 kHz 16-bit mono PCM as a WAV stream.</summary>
    public static MemoryStream Wave(byte[] pcm)
    {
        var stream = new MemoryStream();
        using (var writer = new BinaryWriter(stream, System.Text.Encoding.ASCII, leaveOpen: true))
        {
            writer.Write("RIFF"u8);
            writer.Write(36 + pcm.Length);
            writer.Write("WAVE"u8);
            writer.Write("fmt "u8);
            writer.Write(16);
            writer.Write((short)1);
            writer.Write((short)1);
            writer.Write(Microphone.SampleRate);
            writer.Write(Microphone.SampleRate * 2);
            writer.Write((short)2);
            writer.Write((short)16);
            writer.Write("data"u8);
            writer.Write(pcm.Length);
            writer.Write(pcm);
        }
        stream.Position = 0;
        return stream;
    }

    /// <summary>Downloads a model (to a temporary file, kept only when complete), reporting progress 0–1.</summary>
    public static async Task DownloadAsync(WhisperModel model, IProgress<double>? progress, CancellationToken ct)
    {
        Directory.CreateDirectory(ModelFolder);
        var partial = model.Path + ".download";
        using var http = new HttpClient { Timeout = TimeSpan.FromMinutes(30) };
        using var response = await http.GetAsync(model.Url, HttpCompletionOption.ResponseHeadersRead, ct);
        response.EnsureSuccessStatusCode();
        var total = response.Content.Headers.ContentLength ?? model.Bytes;
        await using (var source = await response.Content.ReadAsStreamAsync(ct))
        await using (var target = File.Create(partial))
        {
            var buffer = new byte[1 << 16];
            long done = 0;
            int read;
            while ((read = await source.ReadAsync(buffer, ct)) > 0)
            {
                await target.WriteAsync(buffer.AsMemory(0, read), ct);
                done += read;
                progress?.Report(Math.Min(1, (double)done / total));
            }
        }
        File.Move(partial, model.Path, overwrite: true);
    }

    /// <summary>Removes a downloaded model.</summary>
    public static void Remove(WhisperModel model)
    {
        if (_factoryPath == model.Path)
        {
            _factory?.Dispose();
            _factory = null;
            _factoryPath = null;
        }
        if (File.Exists(model.Path))
        {
            File.Delete(model.Path);
        }
    }

    public void Dispose()
    {
        _live?.Cancel();
        _microphone?.Dispose();
        _microphone = null;
    }
}
