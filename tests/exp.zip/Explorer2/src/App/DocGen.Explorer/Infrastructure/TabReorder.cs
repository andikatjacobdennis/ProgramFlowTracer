using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// Lets the tabs of a strip (a horizontal panel of buttons) be put in another order: drag one sideways — a line shows
/// where it will go — and let go; or press Ctrl+Shift+← / → on a focused tab. A plain click still chooses the tab.
/// The order is kept by the strip's <see cref="KeyProperty"/> (each tab named by its <see cref="IdProperty"/>) through
/// <see cref="Store"/>, and put back when the strip is shown again.
/// <code>&lt;StackPanel ui:TabReorder.Key="header-sections"&gt;&lt;Button ui:TabReorder.Id="graph" …/&gt;</code>
/// </summary>
public static class TabReorder
{
    /// <summary>Where orders are read and saved (the window layout keeps them); null keeps them for this session only.</summary>
    public static ITabOrderStore? Store { get; set; }

    /// <summary>Raised when a strip's order changed (the window layout saves it).</summary>
    public static event Action<string, IReadOnlyList<string>>? OrderChanged;

    public static readonly DependencyProperty KeyProperty = DependencyProperty.RegisterAttached(
        "Key", typeof(string), typeof(TabReorder), new PropertyMetadata(null, OnKeyChanged));

    public static readonly DependencyProperty IdProperty = DependencyProperty.RegisterAttached("Id", typeof(string), typeof(TabReorder));

    public static string? GetKey(DependencyObject d) => (string?)d.GetValue(KeyProperty);
    public static void SetKey(DependencyObject d, string? value) => d.SetValue(KeyProperty, value);
    public static string? GetId(DependencyObject d) => (string?)d.GetValue(IdProperty);
    public static void SetId(DependencyObject d, string? value) => d.SetValue(IdProperty, value);

    private static readonly Dictionary<Panel, Drag> Drags = [];
    private static readonly Dictionary<string, List<string>> Defaults = new(StringComparer.Ordinal);
    private static readonly List<WeakReference<Panel>> Strips = [];

    private sealed class Drag
    {
        public UIElement? Pressed;
        public Point Start;
        public bool Moving;
        public int Target = -1;
        public InsertionAdorner? Adorner;
    }

    private static void OnKeyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is not Panel panel || e.OldValue is not null)
        {
            return;
        }
        Strips.Add(new WeakReference<Panel>(panel));
        panel.Loaded += (_, _) => Restore(panel);
        panel.PreviewMouseLeftButtonDown += OnDown;
        panel.PreviewMouseMove += OnMove;
        panel.PreviewMouseLeftButtonUp += OnUp;
        // Only the strip losing the mouse ends a drag (a tab losing it to the strip, as a drag starts, bubbles up here too).
        panel.LostMouseCapture += (_, e) =>
        {
            if (e.OriginalSource == panel)
            {
                Cancel(panel);
            }
        };
        panel.PreviewKeyDown += OnKey;
    }

    /// <summary>The ids of a strip's tabs, in the order they are shown.</summary>
    public static List<string> OrderOf(Panel panel) => panel.Children.OfType<UIElement>().Select(GetId).OfType<string>().ToList();

    /// <summary>Puts every strip shown back in the order kept for it (after a layout reset, the order it was built in).</summary>
    public static void RestoreAll()
    {
        foreach (var strip in Strips.ToList())
        {
            if (strip.TryGetTarget(out var panel))
            {
                Restore(panel);
            }
            else
            {
                Strips.Remove(strip);
            }
        }
    }

    private static void Restore(Panel panel)
    {
        if (GetKey(panel) is not { } key)
        {
            return;
        }
        if (!Defaults.ContainsKey(key))
        {
            Defaults[key] = OrderOf(panel);
        }
        var order = Store?.Load(key) ?? Defaults[key];
        Arrange(panel, order);
    }

    /// <summary>Moves the tabs into the given order; tabs it does not name keep their place after the named ones.</summary>
    public static void Arrange(Panel panel, IReadOnlyList<string> order)
    {
        var children = panel.Children.OfType<UIElement>().ToList();
        var sorted = children.OrderBy(c => GetId(c) is { } id && order.Contains(id) ? order.ToList().IndexOf(id) : order.Count + children.IndexOf(c)).ToList();
        if (sorted.SequenceEqual(children))
        {
            return;
        }
        panel.Children.Clear();
        foreach (var c in sorted)
        {
            panel.Children.Add(c);
        }
    }

    private static UIElement? TabUnder(Panel panel, DependencyObject? source)
    {
        for (var x = source; x is not null && x != panel; x = x is Visual ? VisualTreeHelper.GetParent(x) : LogicalTreeHelper.GetParent(x))
        {
            if (x is UIElement e && VisualTreeHelper.GetParent(e) == panel && GetId(e) is not null)
            {
                return e;
            }
        }
        return null;
    }

    private static void OnDown(object sender, MouseButtonEventArgs e)
    {
        var panel = (Panel)sender;
        Drags[panel] = new Drag { Pressed = TabUnder(panel, e.OriginalSource as DependencyObject), Start = e.GetPosition(panel) };
    }

    private static void OnMove(object sender, MouseEventArgs e)
    {
        var panel = (Panel)sender;
        if (!Drags.TryGetValue(panel, out var drag) || drag.Pressed is null || e.LeftButton != MouseButtonState.Pressed)
        {
            return;
        }
        var p = e.GetPosition(panel);
        if (!drag.Moving)
        {
            if (Math.Abs(p.X - drag.Start.X) < SystemParameters.MinimumHorizontalDragDistance * 2)
            {
                return;
            }
            // Taking the mouse from the button means the press does not end in a click.
            drag.Moving = true;
            panel.CaptureMouse();
            if (AdornerLayer.GetAdornerLayer(panel) is { } layer)
            {
                drag.Adorner = new InsertionAdorner(panel);
                layer.Add(drag.Adorner);
            }
            Mouse.OverrideCursor = Cursors.SizeWE;
        }
        drag.Target = InsertionIndex(panel, p.X);
        drag.Adorner?.Show(EdgeOf(panel, drag.Target));
        e.Handled = true;
    }

    private static void OnUp(object sender, MouseButtonEventArgs e)
    {
        var panel = (Panel)sender;
        if (!Drags.TryGetValue(panel, out var drag) || !drag.Moving || drag.Pressed is not { } tab)
        {
            Drags.Remove(panel);
            return;
        }
        var target = drag.Target;
        Cancel(panel);
        Move(panel, tab, target);
        e.Handled = true;
    }

    private static void Cancel(Panel panel)
    {
        if (!Drags.Remove(panel, out var drag))
        {
            return;
        }
        if (drag.Adorner is { } adorner)
        {
            AdornerLayer.GetAdornerLayer(panel)?.Remove(adorner);
        }
        if (drag.Moving)
        {
            Mouse.OverrideCursor = null;
            if (panel.IsMouseCaptured)
            {
                panel.ReleaseMouseCapture();
            }
        }
    }

    private static void OnKey(object sender, KeyEventArgs e)
    {
        if (Keyboard.Modifiers != (ModifierKeys.Control | ModifierKeys.Shift) || e.Key is not (Key.Left or Key.Right))
        {
            return;
        }
        var panel = (Panel)sender;
        if (TabUnder(panel, Keyboard.FocusedElement as DependencyObject) is not { } tab)
        {
            return;
        }
        Shift(panel, tab, e.Key == Key.Left ? -1 : 1);
        (tab as IInputElement)?.Focus();
        e.Handled = true;
    }

    /// <summary>Moves a tab one place left (-1) or right (1) among the visible tabs; false at either end.</summary>
    public static bool Shift(Panel panel, UIElement tab, int by)
    {
        var visible = Visible(panel);
        var at = visible.IndexOf(tab);
        var to = by < 0 ? at - 1 : at + 2;
        if (at < 0 || to < 0 || to > visible.Count)
        {
            return false;
        }
        Move(panel, tab, to);
        return true;
    }

    private static List<UIElement> Visible(Panel panel) => panel.Children.OfType<UIElement>().Where(c => c.Visibility == Visibility.Visible && GetId(c) is not null).ToList();

    /// <summary>Where among the visible tabs a drop at <paramref name="x"/> goes: before the first tab whose middle is past it.</summary>
    private static int InsertionIndex(Panel panel, double x)
    {
        var visible = Visible(panel);
        for (var i = 0; i < visible.Count; i++)
        {
            var left = visible[i].TranslatePoint(new Point(0, 0), panel).X;
            if (x < left + visible[i].RenderSize.Width / 2)
            {
                return i;
            }
        }
        return visible.Count;
    }

    private static double EdgeOf(Panel panel, int index)
    {
        var visible = Visible(panel);
        if (visible.Count == 0)
        {
            return 0;
        }
        return index < visible.Count
            ? visible[index].TranslatePoint(new Point(0, 0), panel).X
            : visible[^1].TranslatePoint(new Point(visible[^1].RenderSize.Width, 0), panel).X;
    }

    /// <summary>Moves a tab to before the visible tab at <paramref name="visibleIndex"/> (or to the end), and keeps the order.</summary>
    private static void Move(Panel panel, UIElement tab, int visibleIndex)
    {
        var visible = Visible(panel);
        var before = visibleIndex < visible.Count ? visible[visibleIndex] : null;
        if (before == tab)
        {
            return;
        }
        panel.Children.Remove(tab);
        var index = before is null ? panel.Children.Count : panel.Children.IndexOf(before);
        panel.Children.Insert(Math.Max(0, index), tab);
        if (GetKey(panel) is { } key)
        {
            var order = OrderOf(panel);
            Store?.Save(key, order);
            OrderChanged?.Invoke(key, order);
        }
    }

    /// <summary>A thin accent line where the dragged tab will go.</summary>
    private sealed class InsertionAdorner(UIElement panel) : Adorner(panel)
    {
        private double _x = double.NaN;

        public void Show(double x)
        {
            _x = x;
            InvalidateVisual();
        }

        protected override void OnRender(DrawingContext dc)
        {
            if (double.IsNaN(_x))
            {
                return;
            }
            var brush = (Brush?)TryFindResource("Brush.Accent") ?? Brushes.DodgerBlue;
            var height = AdornedElement.RenderSize.Height;
            dc.DrawRoundedRectangle(brush, null, new Rect(_x - 1.5, 2, 3, Math.Max(0, height - 4)), 1.5, 1.5);
        }
    }
}

/// <summary>Where tab orders are kept between sessions.</summary>
public interface ITabOrderStore
{
    IReadOnlyList<string>? Load(string key);
    void Save(string key, IReadOnlyList<string> order);
}
