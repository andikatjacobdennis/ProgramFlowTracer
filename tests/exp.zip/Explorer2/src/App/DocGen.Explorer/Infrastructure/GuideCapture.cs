using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using DocGen.Explorer.Engine.Confluence;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Storage;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// Screenshots for the user guide (setup.md):
/// <c>DocGen.Explorer.exe --data &lt;empty folder&gt; --guide &lt;folder&gt; [--add &lt;repo&gt;] [--providers &lt;providers .json&gt;]</c>.
/// Walks the guide's steps on a scratch data folder — first start, the gear menu, importing the providers file, adding a
/// Confluence site, a repository's Indexing page, the factory reset — saves a PNG of each, and exits. Nothing is sent
/// anywhere: no key is entered and no connection is tested.
/// </summary>
public static class GuideCapture
{
    public static async Task RunAsync(Window window, MainViewModel main, string folder, string? addPath, string? providersJson)
    {
        Directory.CreateDirectory(folder);
        ThemeManager.Apply("light");

        await CaptureRunner.Shoot(window, folder, "01-first-start", () => main.Navigate(Section.Repositories), 1500);

        main.ToggleAppMenuCommand.Execute(null);
        await CaptureRunner.Shoot(window, folder, "02-gear-menu", () => { }, 900);
        main.ToggleAppMenuCommand.Execute(null);

        main.Navigate(Section.Settings);
        await CaptureRunner.Shoot(window, folder, "03-providers-before-import", () => main.Settings.ShowPage(SettingsPages.Providers), 900);

        if (providersJson is not null && main.Engine.Models.ProvidersKey is { } key)
        {
            // The same as Import from file… with the team's encrypted file.
            await main.Engine.Models.ImportProvidersAsync(EncryptedJson.Encrypt(await File.ReadAllTextAsync(providersJson), key));
            // Ollama on the PC taking the pictures is not the reader's: turned off, so its models stay out of the pictures.
            if ((await main.Engine.Models.Ai.GetAsync()).Providers.Any(p => p.Id == "ollama"))
            {
                await main.Engine.Models.Ai.ApplyEditsAsync([new Engine.Ai.AiProviderEdit("ollama", "", false, new Dictionary<string, bool>())]);
            }
            await main.Engine.Models.UpdateExplorerSettingsAsync(s => s.ChatModelId = "example-chat");
            await main.Settings.ActivateAsync();
            await CaptureRunner.Shoot(window, folder, "04-providers-imported", () =>
            {
                main.Settings.ShowPage(SettingsPages.Providers);
                foreach (var provider in main.Settings.Providers)
                {
                    provider.IsExpanded = provider.Id == "example-ai";
                }
            }, 1200);
        }

        main.Settings.ShowPage(SettingsPages.Confluence);
        await main.Settings.Confluence.LoadAsync();
        await CaptureRunner.Shoot(window, folder, "05-confluence-add-site", () =>
        {
            // An empty page starts with a blank site; otherwise Add site makes one.
            if (!main.Settings.Confluence.Sites.Any(s => s.BaseUrl.Length == 0))
            {
                main.Settings.Confluence.AddSiteCommand.Execute(null);
            }
            var site = main.Settings.Confluence.Sites.First(s => s.BaseUrl.Length == 0);
            site.BaseUrl = "https://confluence.example.com";
            site.Auth = ConfluenceSettingsViewModel.AuthChoices.First(c => c.Kind == ConfluenceAuth.Token);
        }, 1200);
        await main.Settings.Confluence.LoadAsync(); // the example site is not kept

        if (addPath is not null)
        {
            var record = await main.Engine.Repositories.AddLocalAsync(addPath, null);
            await main.Engine.Indexing.StartAsync(record.Id, IndexMode.Full);
            await Task.Delay(2000);
            await main.Repositories.RefreshAsync();
            await main.OpenRepositoryAsync((await main.Engine.Repositories.GetAsync(record.Id))!, Section.Documentation);
            await Task.Delay(1500);

            main.ToggleRepositoryMenuCommand.Execute(null);
            await CaptureRunner.Shoot(window, folder, "06-repository-menu", () => { }, 1200);
            main.ToggleRepositoryMenuCommand.Execute(null);

            main.Navigate(Section.Indexing);
            if (main.Workspace is { } workspace)
            {
                // One space chosen (its card, Sync), then the address box shown with another example.
                workspace.Indexing.NewSpace = "https://confluence.example.com/spaces/TEAM/overview";
                workspace.Indexing.AddSpaceCommand.Execute(null);
                await Task.Delay(800);
                workspace.Indexing.NewSpace = "https://confluence.example.com/spaces/DOCS/overview";
                System.Windows.Input.CommandManager.InvalidateRequerySuggested(); // as typing does: Add is available
            }
            await Task.Delay(1200);
            await CaptureRunner.Shoot(window, folder, "07-indexing-add-space", () => Reveal(window, "Spaces this repository searches"), 900);
        }

        main.Navigate(Section.Settings);
        main.Settings.ShowPage(SettingsPages.Data);
        await Task.Delay(1200);
        await CaptureRunner.Shoot(window, folder, "08-data-danger-zone", () => Reveal(window, "Danger zone"), 1500);

        main.Settings.Data.FactoryResetCommand.Execute(null);
        for (var i = 0; i < 50 && main.Dialog is null; i++)
        {
            await Task.Delay(100);
        }
        await CaptureRunner.Shoot(window, folder, "09-factory-reset-confirm", () =>
        {
            if (main.Dialog is { } dialog)
            {
                dialog.Input = "reset";
            }
        }, 900);
        main.Dialog?.CancelCommand.Execute(null); // nothing is reset

        Logging.Info("Guide capture finished");
        Application.Current.Shutdown(0);
    }

    /// <summary>
    /// Layout check: <c>--layout &lt;folder&gt; --add &lt;repo&gt;</c> shows the assistant at narrow widths — an answer with a
    /// sequence diagram, the composer idle and answering with a long step — and a page after "On this page" was used.
    /// </summary>
    public static async Task LayoutAsync(Window window, MainViewModel main, string folder, string addPath)
    {
        Directory.CreateDirectory(folder);
        ThemeManager.Apply("light");
        var record = await main.Engine.Repositories.AddLocalAsync(addPath, null);
        await main.Engine.Indexing.StartAsync(record.Id, IndexMode.Full);
        await Task.Delay(1500);
        await main.Repositories.RefreshAsync();
        await main.OpenRepositoryAsync((await main.Engine.Repositories.GetAsync(record.Id))!, Section.Documentation);
        await Task.Delay(1500);
        var workspace = main.Workspace!;
        main.AssistantVisible = true;
        workspace.Assistant.Messages.Add(new ChatMessageViewModel(new Engine.Models.ChatMessage
        {
            Role = "assistant",
            Text = """
                ## Sequence

                Here's the sequence of calls from the trace:

                ```mermaid
                sequenceDiagram
                    participant H as Handler
                    participant P as RequestParser
                    participant A as OrderService
                    participant R as ResponseCreator
                    H->>P: Parse(request)
                    P-->>H: IOrderRequest
                    H->>A: PlaceOrder(request)
                    A-->>H: List<OrderLine>
                    H->>R: CreateSuccess(traceId, lines)
                    R-->>H: OrderResponse
                ```

                Execution flows: valid requests are parsed, converted to XML and assembled into structured nodes.
                """,
        }, workspace.Assistant));
        // The assistant's width now comes from the window layout: the pictures are taken at the width it has.
        var column = new ColumnDefinition();
        foreach (var width in new[] { 320, 380, 480 })
        {
            column.Width = new GridLength(width);
            await CaptureRunner.Shoot(window, folder, $"assistant-{width}", () => { }, 9000 / (width == 320 ? 1 : 3));
            foreach (var thread in FindAll<ScrollViewer>(window).Where(v => v.Name == "Thread"))
            {
                thread.ScrollToEnd();
            }
            await CaptureRunner.Shoot(window, folder, $"assistant-{width}-end", () => { }, 900);
            foreach (var viewer in FindAll<Controls.DiagramViewer>(window))
            {
                Logging.Info($"Layout check at {width}: {viewer.Describe()}; parent width {(VisualTreeHelper.GetParent(viewer) as FrameworkElement)?.ActualWidth:0}");
            }
        }
        // Reading aloud: the oscilloscope beside Stop (two moments, to see it move).
        if (workspace.Assistant.Messages.LastOrDefault() is { } spoken)
        {
            spoken.IsSpeaking = true;
            await CaptureRunner.Shoot(window, folder, "read-aloud-1", () => { }, 700);
            await CaptureRunner.Shoot(window, folder, "read-aloud-2", () => { }, 230);
            spoken.IsSpeaking = false;
        }

        // Zooming a diagram the way a wheel does: is it drawn sharp again while the zoom goes on?
        if (FindAll<Controls.DiagramViewer>(window).FirstOrDefault() is { } inline)
        {
            inline.ShowFullScreen();
            await Task.Delay(1500);
            if (Application.Current.Windows.OfType<Window>().LastOrDefault(w => w.Content is Controls.DiagramViewer) is { } full)
            {
                var viewer = (Controls.DiagramViewer)full.Content;
                var clock = System.Diagnostics.Stopwatch.StartNew();
                long? sharpAt = null;
                for (var step = 0; step < 14; step++)
                {
                    viewer.ZoomIn();
                    await Task.Delay(70);
                    if (viewer.IsSharpened && step >= 6)
                    {
                        sharpAt ??= clock.ElapsedMilliseconds;
                    }
                }
                Logging.Info($"Layout check: zooming for {clock.ElapsedMilliseconds} ms; sharp during the zoom: {(sharpAt is { } ms ? $"yes, at {ms} ms" : "no")}; {viewer.Describe()}");
                await CaptureRunner.Shoot(full, folder, "zoom-while-zooming", () => viewer.ZoomIn(), 120);
                await CaptureRunner.Shoot(full, folder, "zoom-at-rest", () => { }, 900);
                full.Close();
            }
        }

        // Answering: the step under way is long; Stop must stay whole.
        var busy = typeof(AssistantViewModel).GetProperty(nameof(AssistantViewModel.IsBusy))!;
        var text = typeof(AssistantViewModel).GetProperty(nameof(AssistantViewModel.BusyText))!;
        busy.SetValue(workspace.Assistant, true);
        text.SetValue(workspace.Assistant, "9 s · Asking Example Chat with about 9,608 tokens of evidence and instructions…");
        foreach (var width in new[] { 320, 480 })
        {
            column.Width = new GridLength(width);
            await CaptureRunner.Shoot(window, folder, $"composer-busy-{width}", () => { }, 900);
        }
        busy.SetValue(workspace.Assistant, false);
        column.Width = new GridLength(320);
        await CaptureRunner.Shoot(window, folder, "composer-idle-320", () => workspace.Assistant.Input = "Summarise the page \"Architecture\" and what it implies for the code.", 900);

        // "On this page": the last heading of a page, chosen.
        main.AssistantVisible = false;
        var page = workspace.Index?.Pages.FirstOrDefault(p => p.Title.StartsWith("Architecture", StringComparison.Ordinal)) ?? workspace.Index?.Pages.FirstOrDefault(p => p.Generated);
        if (page is not null)
        {
            workspace.Documentation.OpenPage(page.Id, null);
            await Task.Delay(2500);
            await CaptureRunner.Shoot(window, folder, "page-top", () => { }, 300);
            if (workspace.Documentation.Outline.LastOrDefault() is { } last)
            {
                await CaptureRunner.Shoot(window, folder, "page-last-heading", () => workspace.Documentation.GoToAnchorCommand.Execute(last.Anchor), 900);
            }
        }
        // Studio: two starters talking in turn, one speech bubble at a time; then a face poked.
        await main.Engine.Studio.AddStarterPersonasAsync();
        main.Navigate(Section.Studio);
        var studio = workspace.Studio;
        await studio.ActivateAsync();
        foreach (var speaker in studio.Speakers)
        {
            speaker.IsChosen = speaker.Name is "Maya" or "Sam";
        }
        studio.Topic = "How the averages are computed and what can go wrong";
        studio.ComposeCommand.Execute(null);
        for (var wait = 0; wait < 300 && studio.Mode != "conversation"; wait++)
        {
            await Task.Delay(100);
        }
        Logging.Info($"Layout check: Studio stage {string.Join(", ", studio.Stage.Select(s => s.Name + "=" + s.AvatarId))}");
        for (var i = 0; i < Math.Min(2, studio.Lines.Count); i++)
        {
            var index = studio.Lines[i].Index;
            await CaptureRunner.Shoot(window, folder, $"studio-line-{i + 1}", () => studio.PreviewLine(index), 1200);
        }
        if (FindAll<Avatars.AvatarFace>(window).FirstOrDefault(f => f.ActualWidth >= 90) is { } face)
        {
            await CaptureRunner.Shoot(window, folder, "studio-poke", () => face.Poke(), 420);
        }

        // Learning: a quiz hosted by a persona (marked after each question) — a question, a right answer, a wrong one and
        // the result with its score ring; then a deck of cards, turned over. Wide first, then narrow (host above).
        main.AssistantVisible = false;
        main.Navigate(Section.Learning);
        var learning = workspace.Learning;
        await learning.ActivateAsync();
        learning.StartGeneratorCommand.Execute("quiz");
        learning.Count = 5;
        learning.Feedback = FeedbackTiming.AfterEachQuestion;
        learning.GenerateCommand.Execute(null);
        for (var wait = 0; wait < 600 && learning.Mode != "quiz"; wait++)
        {
            await Task.Delay(100);
        }
        Logging.Info($"Layout check: Learning host {learning.Coach.HostName}, {learning.Coach.Hosts.Count} to choose from; mode {learning.Mode}");
        if (learning.Quiz is { Questions.Count: > 1 } quiz)
        {
            await CaptureRunner.Shoot(window, folder, "learning-quiz-overview", () => { }, 900);
            await CaptureRunner.Shoot(window, folder, "learning-quiz-question", () => quiz.StartCommand.Execute(null), 900);
            await CaptureRunner.Shoot(window, folder, "learning-quiz-right", () => quiz.Current!.Choose(quiz.Current.Question.CorrectIndex), 900);
            quiz.NextCommand.Execute(null);
            await Task.Delay(400);
            await CaptureRunner.Shoot(window, folder, "learning-quiz-wrong", () => quiz.Current!.Choose((quiz.Current.Question.CorrectIndex + 1) % quiz.Current.Options.Count), 900);
            for (var i = 2; i < quiz.Questions.Count; i++)
            {
                quiz.NextCommand.Execute(null);
                quiz.Current!.Choose(quiz.Current.Question.CorrectIndex);
                await Task.Delay(250);
            }
            await CaptureRunner.Shoot(window, folder, "learning-quiz-streak", () => { }, 500);
            await CaptureRunner.Shoot(window, folder, "learning-quiz-result-counting", () => quiz.FinishCommand.Execute(null), 450);
            await CaptureRunner.Shoot(window, folder, "learning-quiz-result", () => { }, 1800);
            main.AssistantVisible = true;
            await CaptureRunner.Shoot(window, folder, "learning-quiz-result-narrow", () => { }, 900);
            main.AssistantVisible = false;
        }
        learning.StartGeneratorCommand.Execute("cards");
        learning.Count = 8;
        learning.GenerateCommand.Execute(null);
        for (var wait = 0; wait < 600 && learning.Mode != "deck"; wait++)
        {
            await Task.Delay(100);
        }
        if (learning.Deck is { HasCard: true } deck)
        {
            await CaptureRunner.Shoot(window, folder, "learning-cards", () => { }, 900);
            await CaptureRunner.Shoot(window, folder, "learning-cards-flipped", () => deck.FlipCommand.Execute(null), 600);
            await CaptureRunner.Shoot(window, folder, "learning-cards-graded", () => deck.GradeCommand.Execute("Good"), 900);
        }

        // The title bar (name and version once, the window buttons) and two other arrangements of the panes.
        main.Navigate(Section.Documentation);
        main.AssistantVisible = true;
        foreach (var order in new[] { "ask,page,files", "files,ask,page", "files,page,ask" })
        {
            await CaptureRunner.Shoot(window, folder, $"panes-{order.Replace(',', '-')}", () => main.PaneOrder = order, 1200);
        }
        // The interface size (Ctrl+=): 125%, with the app menu open (pop-ups scale too), then back to 100%.
        await CaptureRunner.Shoot(window, folder, "zoom-125", () => { main.Zoom = 1.25; main.AppMenuOpen = true; }, 1200);
        main.AppMenuOpen = false;
        main.Zoom = 1.0;
        // Themes: light (all greys) and following Windows (its accent colour), on the page and on Settings → Shortcuts
        // with one shortcut listening for keys, and Settings → Confluence with its spaces.
        foreach (var theme in new[] { "light", "auto" })
        {
            await CaptureRunner.Shoot(window, folder, $"theme-{theme}", () => { ThemeManager.Apply(theme); main.Navigate(Section.Documentation); }, 1200);
        }
        ThemeManager.Apply("light");
        await CaptureRunner.Shoot(window, folder, "settings-shortcuts", () =>
        {
            main.Navigate(Section.Settings);
            main.Settings.ShowPage(SettingsPages.Shortcuts);
            main.Shortcuts.Items[2].RecordCommand.Execute(null);
        }, 1200);
        main.Shortcuts.Items[2].IsRecording = false;
        await CaptureRunner.Shoot(window, folder, "settings-confluence", () => main.Settings.ShowPage(SettingsPages.Confluence), 1500);
        main.Navigate(Section.Documentation);
        // Token usage with sample calls (only in a scratch data folder, never the real one): colours, search, filters,
        // sorting and pages.
        if (!string.Equals(Path.TrimEndingDirectorySeparator(Path.GetFullPath(main.Engine.Store.Root)), Path.TrimEndingDirectorySeparator(Path.GetFullPath(ExplorerStore.DefaultRoot())), StringComparison.OrdinalIgnoreCase)
            && (await main.Engine.Usage.ReadAllAsync()).Count == 0)
        {
            var random = new Random(7);
            string[] features = ["assistant", "graph-groups", "learning", "studio", "descriptions"];
            string[] models = ["local/example-small", "example/chat-mini", "cloud/example-large"];
            for (var i = 0; i < 64; i++)
            {
                var feature = features[random.Next(features.Length)];
                await main.Engine.Usage.RecordAsync(new Engine.Models.UsageEntry
                {
                    At = DateTime.UtcNow.AddHours(-random.Next(0, 24 * 20)),
                    Feature = feature,
                    ModelId = models[random.Next(models.Length)],
                    InputTokens = random.Next(300, 4000),
                    OutputTokens = random.Next(80, 900),
                    DurationMs = random.Next(800, 60000),
                    Failed = i % 9 == 4,
                    Error = i % 9 == 4 ? "The model did not answer in time (the request timed out)." : null,
                    Purpose = $"Sample {feature} call {i + 1}",
                });
            }
        }
        await CaptureRunner.Shoot(window, folder, "usage", () => main.Navigate(Section.Usage), 1500);
        await CaptureRunner.Shoot(window, folder, "usage-table", () =>
        {
            main.Usage.Table.SortBy("in");
            main.Usage.Table.Features.First().IsChecked = false;
            main.Usage.Table.Page = 1;
            main.Usage.Table.FeatureMenuOpen = true;
            window.UpdateLayout();
            ScrollAllToEnd(window);
        }, 1500);
        main.Usage.Table.FeatureMenuOpen = false;
        await CaptureRunner.Shoot(window, folder, "usage-failed", () => { main.Usage.Table.PageSize = 25; main.Usage.ShowFailedCommand.Execute(null); }, 1200);
        main.Usage.Table.FailedOnly = false;
        main.Navigate(Section.Documentation);
        // Code in colour, Help (plain, full width) and the graph's grouping instructions.
        await CaptureRunner.Shoot(window, folder, "code-file", () =>
        {
            if (main.Workspace?.Index?.Files.FirstOrDefault(f => f.Path.EndsWith(".cs", StringComparison.OrdinalIgnoreCase)) is { } file)
            {
                main.Workspace.Documentation.OpenFile(file.Path, 1);
            }
        }, 1500);
        // The repository's own first page (a table, as the explorer draws one), when it has Markdown of its own.
        await CaptureRunner.Shoot(window, folder, "own-page", () =>
        {
            if (main.Workspace?.Index?.Pages.FirstOrDefault(p => !p.Generated) is { } own)
            {
                main.Workspace.Documentation.OpenPage(own.Id, null);
            }
        }, 4000);
        // Snap layouts: Windows must be told the maximise button is there (HTMAXBUTTON = 9); the empty title bar drags (HTCAPTION = 2).
        if (window is MainWindow shell && shell.FindName("MaximizeButton") is FrameworkElement maximize)
        {
            var handle = new System.Windows.Interop.WindowInteropHelper(window).Handle;
            var centre = maximize.PointToScreen(new Point(maximize.ActualWidth / 2, maximize.ActualHeight / 2));
            var title = window.PointToScreen(new Point(window.ActualWidth / 2, 12));
            IntPtr Hit(Point p) => SendMessage(handle, 0x0084, IntPtr.Zero, new IntPtr(((int)p.Y << 16) | ((int)p.X & 0xFFFF)));
            var state = window.WindowState;
            NativeClick((int)centre.X, (int)centre.Y);
            await Task.Delay(1200);
            Logging.Info($"Layout check: hit test on maximise {Hit(maximize.PointToScreen(new Point(maximize.ActualWidth / 2, maximize.ActualHeight / 2)))}, on the title bar {Hit(title)}; a click went from {state} to {window.WindowState}");
            window.WindowState = state;
            await Task.Delay(800);
        }
        await AskAndTalkAsync(window, main, folder);
        // A large diagram in an answer (as an Architect trace draws one), clicked with the real mouse: it must stay drawn.
        var parts = new[] { "Client", "Gateway", "Auth", "Router", "Service", "Validator", "Cache", "Repository", "Database", "Queue", "Worker", "Notifier" };
        var big = "```mermaid\nsequenceDiagram\n" + string.Join("\n", Enumerable.Range(0, 60).Select(i => $"    {parts[i % 12]}->>{parts[(i * 5 + 3) % 12 == i % 12 ? (i + 1) % 12 : (i * 5 + 3) % 12]}: Step {i + 1} sends the request onwards with details")) + "\n```";
        main.Navigate(Section.Documentation);
        main.AssistantVisible = true;
        main.Workspace!.Assistant.Messages.Add(new ChatMessageViewModel(new ChatMessage { Role = "assistant", Text = "Here is the flow:\n\n" + big }, main.Workspace.Assistant));
        await Task.Delay(4000);
        if (CaptureRunner.FindAll<Controls.DiagramViewer>(window).LastOrDefault(v => v.IsVisible) is { } pageDiagram)
        {
            pageDiagram.BringIntoView();
            await Task.Delay(800);
            Logging.Info("Layout check: page diagram before click: " + pageDiagram.Describe() + $", picture shown {pageDiagram.PictureShown}");
            var centre = pageDiagram.PointToScreen(new Point(pageDiagram.ActualWidth / 2, pageDiagram.ActualHeight / 2));
            NativeClick((int)centre.X, (int)centre.Y);
            await Task.Delay(1500);
            Logging.Info("Layout check: page diagram after click: " + pageDiagram.Describe() + $", picture shown {pageDiagram.PictureShown}");
            await CaptureRunner.Shoot(window, folder, "page-diagram-after-click", () => { }, 300);
        }
        // The same page with Ask closed: On this page moves to the right edge.
        await CaptureRunner.Shoot(window, folder, "own-page-ask-closed", () => { main.Navigate(Section.Documentation); main.AssistantVisible = false; }, 1500);
        main.AssistantVisible = true;
        await CaptureRunner.Shoot(window, folder, "help", () => main.Navigate(Section.Help), 1500);
        await CaptureRunner.Shoot(window, folder, "graph-instructions", () => { main.Navigate(Section.Graph); main.Workspace!.Graph.GroupInstructions = "by feature, keep tests apart"; }, 2500);
        main.Navigate(Section.Documentation);
        // Send feedback, into this folder rather than C:\DocGen-Feedback.
        var feedback = await FeedbackReport.CreateAsync(main, "Layout check", FeedbackReport.CaptureWindows(), folder);
        using (var zip = System.IO.Compression.ZipFile.OpenRead(feedback))
        {
            Logging.Info($"Layout check: feedback {Path.GetFileName(feedback)}: {string.Join(", ", zip.Entries.Select(e => $"{e.FullName} ({e.Length:N0} B)"))}");
        }
        Logging.Info($"Layout check: title \"{window.Title}\"");

        // A new, empty repository folder: the form, then created and opened.
        main.Navigate(Section.Repositories);
        main.Repositories.AddOpen = true;
        main.Repositories.AddMode = "new";
        main.Repositories.NewFolderName = "new-service";
        main.Repositories.NewFolderLocation = Path.Combine(folder, "created");
        Directory.CreateDirectory(main.Repositories.NewFolderLocation);
        await CaptureRunner.Shoot(window, folder, "new-folder-form", () => { }, 900);
        main.Repositories.CreateFolderCommand.Execute(null);
        for (var i = 0; i < 50 && main.Workspace?.Record.Name != "new-service"; i++)
        {
            await Task.Delay(100);
        }
        await CaptureRunner.Shoot(window, folder, "new-folder-opened", () => { }, 2500);
        Logging.Info($"Layout check: new folder opened = {main.Workspace?.Record.Name == "new-service"}, git = {Directory.Exists(Path.Combine(folder, "created", "new-service", ".git"))}");

        Logging.Info("Layout check finished");
        Application.Current.Shutdown(0);
    }

    private static IEnumerable<T> FindAll<T>(DependencyObject parent) where T : DependencyObject
    {
        for (var i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
        {
            var child = VisualTreeHelper.GetChild(parent, i);
            if (child is T match)
            {
                yield return match;
            }
            foreach (var nested in FindAll<T>(child))
            {
                yield return nested;
            }
        }
    }

    /// <summary>Scrolls the page so the text block showing <paramref name="text"/> is in view.</summary>
    private static void Reveal(DependencyObject root, string text)
    {
        if (Find(root, text) is { } element)
        {
            element.BringIntoView(new Rect(0, -40, element.ActualWidth, element.ActualHeight + 400));
        }
    }

    private static FrameworkElement? Find(DependencyObject parent, string text)
    {
        for (var i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
        {
            var child = VisualTreeHelper.GetChild(parent, i);
            if (child is TextBlock block && block.Text == text && block.IsVisible)
            {
                return block;
            }
            if (Find(child, text) is { } found)
            {
                return found;
            }
        }
        return null;
    }

    /// <summary>Scrolls every scroller in the window to its end (to show the bottom of a long page).</summary>
    private static void ScrollAllToEnd(DependencyObject root)
    {
        for (var i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++)
        {
            var child = VisualTreeHelper.GetChild(root, i);
            if (child is System.Windows.Controls.ScrollViewer scroller)
            {
                scroller.ScrollToEnd();
            }
            ScrollAllToEnd(child);
        }
    }

    /// <summary>
    /// Ask's progress (every stage, and still with reduced motion), an answer's Download panel (with and without a
    /// diagram) and every format written out, then Talk: the greeting, a greeting reply, an answer, a persona switch,
    /// dark theme and a narrow window.
    /// </summary>
    private static async Task AskAndTalkAsync(Window window, MainViewModel main, string folder)
    {
        if (main.Workspace is not { } workspace)
        {
            return;
        }
        main.Navigate(Section.Documentation);
        main.AssistantVisible = true;
        var ask = workspace.Assistant;

        async Task Send(AssistantViewModel vm, string text)
        {
            vm.Input = text;
            vm.SendCommand.Execute(null);
            for (var i = 0; i < 600 && (vm.IsBusy || vm.Input.Length > 0); i++)
            {
                await Task.Delay(100);
            }
            await Task.Delay(700);
        }

        // Progress: a pending answer at each stage the assistant reports.
        var files = workspace.Index?.Files.Select(f => Path.GetFileName(f.Path)).Where(n => n.EndsWith(".cs", StringComparison.Ordinal)).Take(4).ToList() ?? [];
        var pending = new ChatMessageViewModel(new ChatMessage { Role = "assistant", Text = "" }, ask) { IsStreaming = true };
        ask.Messages.Add(pending);
        foreach (var stage in new Engine.Assistant.ProgressStage?[] { null, Engine.Assistant.ProgressStage.Understanding, Engine.Assistant.ProgressStage.Finding,
                     Engine.Assistant.ProgressStage.Connecting, Engine.Assistant.ProgressStage.Writing, Engine.Assistant.ProgressStage.Ready })
        {
            await CaptureRunner.Shoot(window, folder, $"progress-{(stage?.ToString() ?? "exploring").ToLowerInvariant()}", () =>
            {
                pending.StageFiles = files;
                pending.Stage = stage;
            }, 1300);
        }
        var motion = Avatars.AvatarFace.ReduceMotion;
        await CaptureRunner.Shoot(window, folder, "progress-still", () => { Avatars.AvatarFace.ReduceMotion = true; pending.Stage = Engine.Assistant.ProgressStage.Finding; pending.IsSlow = true; }, 900);
        Avatars.AvatarFace.ReduceMotion = motion;
        ask.Messages.Remove(pending);

        // Download: an answer with a diagram, and one without.
        await Send(ask, "Generate a Mermaid diagram of what Message depends on.");
        if (ask.Messages.LastOrDefault() is { IsAssistant: true } diagram)
        {
            diagram.DownloadCommand.Execute(null);
            if (diagram.Download is { } download)
            {
                await CaptureRunner.Shoot(window, folder, "download-diagram", () => download.Formats.First(f => f.Format == Engine.Export.ResponseFormat.Mermaid).IsSelected = true, 900);
                var outFolder = Path.Combine(folder, "exports");
                Directory.CreateDirectory(outFolder);
                var export = download.Export();
                foreach (var format in Enum.GetValues<Engine.Export.ResponseFormat>().Where(f => f != Engine.Export.ResponseFormat.Mermaid))
                {
                    await File.WriteAllBytesAsync(Path.Combine(outFolder, Engine.Export.ResponseExporter.FileName(export) + Engine.Export.ResponseExporter.Extension(format)),
                        Engine.Export.ResponseExporter.Write(export, format));
                }
                if (download.Diagrams.Count > 0)
                {
                    await File.WriteAllBytesAsync(Path.Combine(outFolder, "diagram-1.mmd"), Engine.Export.ResponseExporter.MermaidFile(export, 0));
                }
                Logging.Info($"Layout check: exported {Directory.GetFiles(outFolder).Length} files, {download.Diagrams.Count} diagram(s)");
                download.IsOpen = false;
            }
        }
        // A diagram in an answer, clicked once with the real mouse: it must stay drawn.
        if (CaptureRunner.FindAll<Controls.DiagramViewer>(window).LastOrDefault(v => v.IsVisible) is { } viewer)
        {
            viewer.BringIntoView();
            await Task.Delay(600);
            Logging.Info("Layout check: diagram before click: " + viewer.Describe() + $", picture shown {viewer.PictureShown}");
            await CaptureRunner.Shoot(window, folder, "diagram-before-click", () => { }, 300);
            var centre = viewer.PointToScreen(new Point(viewer.ActualWidth / 2, viewer.ActualHeight / 2));
            NativeClick((int)centre.X, (int)centre.Y);
            await Task.Delay(1200);
            Logging.Info("Layout check: diagram after click: " + viewer.Describe() + $", picture shown {viewer.PictureShown}");
            await CaptureRunner.Shoot(window, folder, "diagram-after-click", () => { }, 300);
        }
        await Send(ask, "What does DocGenVersion contain?");
        if (ask.Messages.LastOrDefault() is { IsAssistant: true } plain)
        {
            plain.DownloadCommand.Execute(null);
            await CaptureRunner.Shoot(window, folder, "download-plain", () => { }, 900);
            if (plain.Download is { } d)
            {
                d.IsOpen = false;
            }
        }

        // Summarise: part of a page selected, and a diagram.
        main.Navigate(Section.Documentation);
        await Task.Delay(1200);
        if (CaptureRunner.FindAll<System.Windows.Controls.FlowDocumentScrollViewer>(window).FirstOrDefault(v => v.IsVisible && v.Name == "Viewer") is { Document: { } document } page)
        {
            var from = document.ContentStart.GetPositionAtOffset(40) ?? document.ContentStart;
            var to = from.GetPositionAtOffset(900) ?? document.ContentEnd;
            page.Selection.Select(from, to);
            await SummariseSelection.SummariseAsync(page);
            await CaptureRunner.Shoot(window, folder, "summarise-selection", () => { }, 1200);
        }
        // A diagram's Summarise in an answer: the summary appears under that diagram.
        main.Navigate(Section.Documentation);
        main.AssistantVisible = true;
        await Send(ask, "Generate a Mermaid diagram of what Message depends on.");
        if (CaptureRunner.FindAll<Controls.DiagramViewer>(window).LastOrDefault(v => v.IsVisible) is { SummariseRequested: { } summarise } answerDiagram)
        {
            summarise();
            await Task.Delay(2500);
            // The diagram's block on its own (diagram and summary under it), wherever the thread is scrolled.
            if (VisualTreeHelper.GetParent(VisualTreeHelper.GetParent(answerDiagram)) is FrameworkElement block && block.ActualWidth > 0)
            {
                var bitmap = new System.Windows.Media.Imaging.RenderTargetBitmap((int)block.ActualWidth, (int)block.ActualHeight, 96, 96, PixelFormats.Pbgra32);
                bitmap.Render(block);
                var encoder = new System.Windows.Media.Imaging.PngBitmapEncoder();
                encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(bitmap));
                await using var file = File.Create(Path.Combine(folder, "summarise-diagram-block.png"));
                encoder.Save(file);
            }
        }
        if (ask.Messages.LastOrDefault(m => m.IsAssistant) is { } withPanel)
        {
            withPanel.DownloadCommand.Execute(null);
            await CaptureRunner.Shoot(window, folder, "download-placement", () => { }, 900);
            withPanel.Download!.IsOpen = false;
        }

        // Talk.
        var talk = workspace.Talk;
        await CaptureRunner.Shoot(window, folder, "talk-empty", () => main.Navigate(Section.Talk), 1800);
        await Send(talk, "Good morning!");
        await CaptureRunner.Shoot(window, folder, "talk-greeting", () => { }, 600);
        await Send(talk, "What does DocGenVersion contain?");
        await CaptureRunner.Shoot(window, folder, "talk-answer", () => { }, 900);
        await CaptureRunner.Shoot(window, folder, "talk-switch", () => talk.Persona = Engine.Assistant.TalkPersonas.Find("teacher"), 1200);
        await CaptureRunner.Shoot(window, folder, "talk-dark", () => ThemeManager.Apply("dark"), 1500);
        ThemeManager.Apply("light");
        var size = (window.Width, window.Height, window.WindowState);
        window.WindowState = WindowState.Normal;
        await CaptureRunner.Shoot(window, folder, "talk-narrow", () => { window.Width = 760; window.Height = 820; }, 1500);
        (window.Width, window.Height) = (size.Width, size.Height);
        window.WindowState = size.WindowState;
        Logging.Info($"Layout check: Talk persona {talk.Persona?.Name}, {talk.Messages.Count} messages; Ask {ask.Messages.Count} messages");
        main.Navigate(Section.Documentation);
    }

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern bool SetCursorPos(int x, int y);

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern void mouse_event(uint flags, uint dx, uint dy, uint data, UIntPtr extra);

    /// <summary>A real left click at a screen point (for checks that need the mouse itself, not a raised event).</summary>
    private static void NativeClick(int x, int y)
    {
        SetCursorPos(x, y);
        mouse_event(0x0002, 0, 0, 0, UIntPtr.Zero); // left down
        mouse_event(0x0004, 0, 0, 0, UIntPtr.Zero); // left up
    }

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    private static extern IntPtr SendMessage(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam);
}
