using DocGen.Explorer.Engine.Models;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// Settings → Reading and writing, as the views use them live: XAML binds to <see cref="Current"/>
/// (<c>{Binding Source={x:Static ui:UiPreferences.Current}, Path=SpellCheck}</c>), so a change shows at once.
/// </summary>
public sealed class UiPreferences : ObservableObject
{
    public static UiPreferences Current { get; } = new();

    private double _wheelLines = 2;
    private bool _smoothScrolling = true;
    private bool _spellCheck = true;
    private bool _spellCheckOnClick = true;
    private bool _pasteAsAttachment = true;
    private int _pasteAttachmentChars = 400;
    private int _pasteAttachmentLines = 6;
    private bool _findAsYouType = true;
    private int _logRefreshSeconds = 5;
    private bool _allowFileEditing = true;
    private bool _detailedFileTips = true;

    public double WheelLines { get => _wheelLines; set => Set(ref _wheelLines, Math.Clamp(value, 0.5, 10)); }
    public bool SmoothScrolling { get => _smoothScrolling; set => Set(ref _smoothScrolling, value); }
    public bool SpellCheck { get => _spellCheck; set => Set(ref _spellCheck, value); }
    public bool SpellCheckOnClick { get => _spellCheckOnClick; set => Set(ref _spellCheckOnClick, value); }
    public bool PasteAsAttachment { get => _pasteAsAttachment; set => Set(ref _pasteAsAttachment, value); }
    public int PasteAttachmentChars { get => _pasteAttachmentChars; set => Set(ref _pasteAttachmentChars, Math.Max(1, value)); }
    public int PasteAttachmentLines { get => _pasteAttachmentLines; set => Set(ref _pasteAttachmentLines, Math.Max(1, value)); }
    public bool FindAsYouType { get => _findAsYouType; set => Set(ref _findAsYouType, value); }
    public int LogRefreshSeconds { get => _logRefreshSeconds; set => Set(ref _logRefreshSeconds, Math.Clamp(value, 1, 3600)); }
    public bool AllowFileEditing { get => _allowFileEditing; set => Set(ref _allowFileEditing, value); }
    public bool DetailedFileTips { get => _detailedFileTips; set => Set(ref _detailedFileTips, value); }

    public IReadOnlyList<double> WheelLineChoices { get; } = [1, 1.5, 2, 3, 4, 5];
    public IReadOnlyList<int> PasteCharChoices { get; } = [100, 200, 400, 800, 1500, 3000];
    public IReadOnlyList<int> PasteLineChoices { get; } = [2, 3, 6, 10, 20, 50];
    public IReadOnlyList<int> LogRefreshChoices { get; } = [2, 5, 10, 30, 60];

    /// <summary>Pixels one wheel notch scrolls (a line is 16 px).</summary>
    public double WheelPixels => WheelLines * 16;

    public void Load(ExplorerSettings s)
    {
        WheelLines = s.WheelLines;
        SmoothScrolling = s.SmoothScrolling;
        SpellCheck = s.SpellCheck;
        SpellCheckOnClick = s.SpellCheckOnClick;
        PasteAsAttachment = s.PasteAsAttachment;
        PasteAttachmentChars = s.PasteAttachmentChars;
        PasteAttachmentLines = s.PasteAttachmentLines;
        FindAsYouType = s.FindAsYouType;
        LogRefreshSeconds = s.LogRefreshSeconds;
        AllowFileEditing = s.AllowFileEditing;
        DetailedFileTips = s.DetailedFileTips;
    }

    public void Save(ExplorerSettings s)
    {
        s.WheelLines = WheelLines;
        s.SmoothScrolling = SmoothScrolling;
        s.SpellCheck = SpellCheck;
        s.SpellCheckOnClick = SpellCheckOnClick;
        s.PasteAsAttachment = PasteAsAttachment;
        s.PasteAttachmentChars = PasteAttachmentChars;
        s.PasteAttachmentLines = PasteAttachmentLines;
        s.FindAsYouType = FindAsYouType;
        s.LogRefreshSeconds = LogRefreshSeconds;
        s.AllowFileEditing = AllowFileEditing;
        s.DetailedFileTips = DetailedFileTips;
    }
}
