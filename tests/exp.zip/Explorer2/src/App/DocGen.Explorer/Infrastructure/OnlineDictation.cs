using Windows.Media.SpeechRecognition;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// Dictation with Windows' online speech recognition: Microsoft's cloud engine, the one Windows voice typing (Win+H)
/// uses, far more accurate than the offline recogniser. It listens to the Windows default microphone, and needs
/// "Online speech recognition" on (Windows Settings → Privacy &amp; security → Speech).
/// </summary>
public sealed class OnlineDictation : IDisposable
{
    private readonly System.Text.StringBuilder _heard = new();
    private SpeechRecognizer? _recognizer;
    private TaskCompletionSource? _completed;

    /// <summary>Words heard so far that are not final yet (shown while speaking).</summary>
    public event Action<string>? Hearing;

    /// <summary>The languages the online engine can dictate (BCP-47 tags).</summary>
    public static IReadOnlyList<string> Languages()
    {
        try
        {
            return SpeechRecognizer.SupportedTopicLanguages.Select(l => l.LanguageTag).Distinct().OrderBy(t => t, StringComparer.Ordinal).ToList();
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            return [];
        }
    }

    /// <summary>The name of the Windows default microphone (what the online engine listens to), if it can be found.</summary>
    public static async Task<string?> DefaultMicrophoneAsync()
    {
        try
        {
            var id = Windows.Media.Devices.MediaDevice.GetDefaultAudioCaptureId(Windows.Media.Devices.AudioDeviceRole.Default);
            if (string.IsNullOrEmpty(id))
            {
                return null;
            }
            var device = await Windows.Devices.Enumeration.DeviceInformation.CreateFromIdAsync(id);
            return device.Name;
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            return null;
        }
    }

    /// <summary>
    /// Starts listening; throws <see cref="InvalidOperationException"/> with a reason a person can act on. Windows' calls
    /// run off the UI thread and are given a time limit, so a call Windows never completes cannot leave the app waiting.
    /// </summary>
    public async Task StartAsync(string? language)
    {
        try
        {
            await Task.Run(() => StartCoreAsync(language)).WaitAsync(TimeSpan.FromSeconds(12));
        }
        catch (TimeoutException)
        {
            Dispose();
            throw new InvalidOperationException("Windows did not start online speech recognition in time. If you have just turned it on, restart the app.");
        }
    }

    private async Task StartCoreAsync(string? language)
    {
        _heard.Clear();
        try
        {
            var tag = string.IsNullOrWhiteSpace(language) ? null : SpeechRecognizer.SupportedTopicLanguages.FirstOrDefault(l => l.LanguageTag.Equals(language, StringComparison.OrdinalIgnoreCase));
            _recognizer = tag is null ? new SpeechRecognizer() : new SpeechRecognizer(tag);
            _recognizer.Constraints.Add(new SpeechRecognitionTopicConstraint(SpeechRecognitionScenario.Dictation, "dictation"));
            var compiled = await _recognizer.CompileConstraintsAsync();
            if (compiled.Status != SpeechRecognitionResultStatus.Success)
            {
                throw new InvalidOperationException($"Online speech recognition could not start ({compiled.Status}).");
            }
            // Long pauses do not end it: it listens until stopped.
            _recognizer.ContinuousRecognitionSession.AutoStopSilenceTimeout = TimeSpan.FromMinutes(5);
            _recognizer.Timeouts.EndSilenceTimeout = TimeSpan.FromSeconds(1.2);
            _recognizer.HypothesisGenerated += (_, e) => Hearing?.Invoke((_heard + " " + e.Hypothesis.Text).Trim());
            _recognizer.ContinuousRecognitionSession.ResultGenerated += (_, e) =>
            {
                if (e.Result.Status == SpeechRecognitionResultStatus.Success && e.Result.Confidence != SpeechRecognitionConfidence.Rejected && e.Result.Text.Length > 0)
                {
                    lock (_heard)
                    {
                        _heard.Append(e.Result.Text).Append(' ');
                    }
                    Hearing?.Invoke(_heard.ToString().Trim());
                }
            };
            _completed = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
            _recognizer.ContinuousRecognitionSession.Completed += (_, _) => _completed.TrySetResult();
            await _recognizer.ContinuousRecognitionSession.StartAsync();
        }
        catch (Exception ex) when (ex is not InvalidOperationException && ex is not OutOfMemoryException)
        {
            Dispose();
            throw new InvalidOperationException(Reason(ex), ex);
        }
    }

    /// <summary>Stops listening and returns what was heard (within a time limit, as for starting).</summary>
    public async Task<string> StopAsync()
    {
        if (_recognizer is { } recognizer)
        {
            try
            {
                await Task.Run(async () =>
                {
                    await recognizer.ContinuousRecognitionSession.StopAsync(); // the last words are finished first
                    await Task.WhenAny(_completed?.Task ?? Task.CompletedTask, Task.Delay(3000));
                }).WaitAsync(TimeSpan.FromSeconds(8));
            }
            catch (TimeoutException)
            {
                Logging.Info("Online dictation: Windows did not stop in time; what was heard so far is kept.");
            }
            catch (Exception ex) when (ex is not OutOfMemoryException)
            {
                Logging.Error(ex, "Online dictation stop");
            }
        }
        string text;
        lock (_heard)
        {
            text = _heard.ToString().Trim();
        }
        Dispose();
        return text;
    }

    /// <summary>Why the online engine could not start, in words a person can act on.</summary>
    private static string Reason(Exception ex) => (uint)ex.HResult switch
    {
        0x80045509 => "Online speech recognition is off. Turn it on in Windows Settings → Privacy & security → Speech (if you have just turned it on, restart the app).",
        0x80070005 => "The app may not use the microphone. Allow it in Windows Settings → Privacy & security → Microphone.",
        0x800455A0 => "The language chosen cannot be dictated online.",
        _ => "Online speech recognition is not available: " + ex.Message,
    };

    public void Dispose()
    {
        try
        {
            _recognizer?.Dispose();
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            Logging.Error(ex, "Online dictation dispose");
        }
        _recognizer = null;
    }
}
