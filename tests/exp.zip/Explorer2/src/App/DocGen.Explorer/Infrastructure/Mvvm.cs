using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using Prism.Commands;
using Prism.Mvvm;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// The view models' base: Prism's <see cref="BindableBase"/>, with the explorer's short forms (<c>Set</c> for
/// SetProperty, <c>Notify</c> for several names at once).
/// </summary>
public abstract class ObservableObject : BindableBase
{
    protected bool Set<T>(ref T field, T value, [CallerMemberName] string? name = null) => SetProperty(ref field, value, name);

    protected void OnPropertyChanged([CallerMemberName] string? name = null) => RaisePropertyChanged(name);

    protected void Notify(params string[] names)
    {
        foreach (var name in names)
        {
            RaisePropertyChanged(name);
        }
    }
}

/// <summary>
/// A Prism <see cref="DelegateCommandBase"/> that also re-evaluates whenever WPF asks commands to (focus, input),
/// as the explorer's commands always have, so their buttons enable and disable without explicit calls.
/// </summary>
public abstract class RequeryCommand : DelegateCommandBase
{
    private readonly EventHandler _requery;

    protected RequeryCommand()
    {
        // RequerySuggested holds its handlers weakly: the command keeps this one alive.
        _requery = (_, _) => RaiseCanExecuteChanged();
        CommandManager.RequerySuggested += _requery;
    }

    public void Invoke(object? parameter = null) => ((ICommand)this).Execute(parameter);

    public bool CanInvoke(object? parameter = null) => ((ICommand)this).CanExecute(parameter);
}

public sealed class RelayCommand(Action<object?> execute, Func<object?, bool>? canExecute = null) : RequeryCommand
{
    public RelayCommand(Action execute, Func<bool>? canExecute = null)
        : this(_ => execute(), canExecute is null ? null : _ => canExecute())
    {
    }

    protected override bool CanExecute(object? parameter) => canExecute?.Invoke(parameter) ?? true;

    protected override void Execute(object? parameter) => execute(parameter);
}

/// <summary>
/// An async command that cannot run twice at once, reports failures through <see cref="Ui.ReportError"/> instead of
/// crashing, and re-evaluates CanExecute when it starts and ends.
/// </summary>
public sealed class AsyncCommand(Func<object?, Task> execute, Func<object?, bool>? canExecute = null) : RequeryCommand
{
    private bool _running;

    public AsyncCommand(Func<Task> execute, Func<bool>? canExecute = null)
        : this(_ => execute(), canExecute is null ? null : _ => canExecute())
    {
    }

    public bool IsRunning => _running;

    protected override bool CanExecute(object? parameter) => !_running && (canExecute?.Invoke(parameter) ?? true);

    protected override async void Execute(object? parameter)
    {
        if (_running)
        {
            return;
        }
        _running = true;
        RaiseCanExecuteChanged();
        try
        {
            await execute(parameter);
        }
        catch (OperationCanceledException)
        {
            // Cancelled by the user: nothing to report.
        }
        catch (Exception ex)
        {
            Ui.ReportError(ex);
        }
        finally
        {
            _running = false;
            RaiseCanExecuteChanged();
        }
    }
}

/// <summary>UI-thread helpers and the app-wide error and notification sinks.</summary>
public static class Ui
{
    public static Dispatcher Dispatcher => Application.Current?.Dispatcher ?? Dispatcher.CurrentDispatcher;

    /// <summary>Shows a transient message (set by the shell).</summary>
    public static Action<string, bool>? Notifier { get; set; }

    public static void Post(Action action)
    {
        if (Dispatcher.CheckAccess())
        {
            action();
        }
        else
        {
            Dispatcher.BeginInvoke(action);
        }
    }

    public static void Notify(string message) => Post(() => Notifier?.Invoke(message, false));

    public static void ReportError(Exception ex)
    {
        var message = ex switch
        {
            Engine.Repositories.ExplorerValidationException => ex.Message,
            DocGen.Core.Exceptions.DocGenException h => h.Message,
            UnauthorizedAccessException => "Access was denied: " + ex.Message,
            IOException => "A file could not be read or written: " + ex.Message,
            _ => "Something went wrong: " + ex.Message,
        };
        Logging.Error(ex, "Reported to the user");
        Post(() => Notifier?.Invoke(message, true));
    }

    /// <summary>Copies text to the clipboard, retrying while another program holds it open.</summary>
    public static bool Copy(string text)
    {
        for (var attempt = 0; attempt < 5; attempt++)
        {
            try
            {
                Clipboard.SetDataObject(text, copy: true);
                return true;
            }
            catch (System.Runtime.InteropServices.COMException)
            {
                Thread.Sleep(40);
            }
        }
        Notifier?.Invoke("The clipboard is busy; try again.", true);
        return false;
    }
}

/// <summary>
/// Watches the UI thread: a timer that should tick every 50 ms; when a tick arrives late the UI was blocked, and stalls
/// longer than 250 ms are logged (with what the app was doing), so a freeze can be found from the log.
/// </summary>
public static class StallMonitor
{
    private static DateTime _last = DateTime.UtcNow;

    public static double LongestStallMs { get; private set; }

    public static void Start()
    {
        var timer = new DispatcherTimer(DispatcherPriority.Background) { Interval = TimeSpan.FromMilliseconds(50) };
        timer.Tick += (_, _) =>
        {
            var now = DateTime.UtcNow;
            var gap = (now - _last).TotalMilliseconds - 50;
            _last = now;
            if (gap > 250)
            {
                LongestStallMs = Math.Max(LongestStallMs, gap);
                Logging.Info($"UI stall: {gap:0} ms");
            }
        };
        timer.Start();
    }
}

/// <summary>A minimal rolling log next to the data folder (logs/explorer-yyyyMMdd.log).</summary>
public static class Logging
{
    private static readonly object Gate = new();
    public static string? Folder { get; set; }

    public static void Info(string message) => Write("INFO", message);

    public static void Warn(string message, string? source = null) => Write("WARN", message, source);

    public static void Error(Exception ex, string message)
    {
        Write("ERROR", $"{message}: {ex}");
        ErrorLogged?.Invoke($"{message}: {ex.GetType().Name}: {ex.Message}");
    }

    /// <summary>Every error logged (the UI path test counts them).</summary>
    public static event Action<string>? ErrorLogged;

    /// <summary>A line of the log: "time LEVEL [source] message" (the source in brackets when given).</summary>
    public static void Write(string level, string message, string? source = null)
    {
        if (Folder is null)
        {
            return;
        }
        try
        {
            lock (Gate)
            {
                Directory.CreateDirectory(Folder);
                var path = Path.Combine(Folder, $"explorer-{DateTime.UtcNow:yyyyMMdd}.log");
                var from = string.IsNullOrEmpty(source) ? "" : $"[{source}] ";
                File.AppendAllText(path, $"{DateTime.UtcNow:O} {level} {from}{DocGen.Security.SecretRedactor.Redact(message)}{Environment.NewLine}");
            }
        }
        catch (IOException)
        {
            // Logging must never take the app down.
        }
        catch (UnauthorizedAccessException)
        {
        }
    }
}
