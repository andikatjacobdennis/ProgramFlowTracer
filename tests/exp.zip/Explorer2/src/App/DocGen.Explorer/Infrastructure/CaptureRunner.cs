using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// Screenshot mode for documentation and visual checks: <c>DocGen.Explorer.exe --data &lt;folder&gt; --add &lt;repo&gt; --capture &lt;folder&gt;</c>
/// registers and indexes a repository (when given), walks every screen in light and dark, saves a PNG of each, and exits.
/// </summary>
public static class CaptureRunner
{
    public static async Task RunAsync(Window window, MainViewModel main, string folder, string? addPath, string? theme)
    {
        Directory.CreateDirectory(folder);
        AvatarSheets(folder);
        Directory.CreateDirectory(folder);
        if (addPath is not null)
        {
            var existing = (await main.Engine.Repositories.ListAsync()).FirstOrDefault(r => string.Equals(r.Path, Path.GetFullPath(addPath), StringComparison.OrdinalIgnoreCase));
            var record = existing ?? await main.Engine.Repositories.AddLocalAsync(addPath, null);
            if (existing is null || existing.Status != RepositoryStatus.Indexed)
            {
                // Open the repository while it indexes, as a user would, and show the Documentation page mid-run.
                var run = main.Engine.Indexing.StartAsync(record.Id, IndexMode.Full);
                await main.OpenRepositoryAsync(record, Section.Documentation);
                await Shoot(window, folder, "indexing-in-progress", () => main.Navigate(Section.Documentation), 600);
                await run;
                await Task.Delay(3000); // let the completion handlers run
                Logging.Info($"After indexing: longest UI stall {StallMonitor.LongestStallMs:0} ms");
            }
            await main.Repositories.RefreshAsync();
            await main.OpenRepositoryAsync((await main.Engine.Repositories.GetAsync(record.Id))!, Section.Documentation);
        }
        var themes = theme is null ? new[] { "light", "dark" } : [theme];
        foreach (var mode in themes)
        {
            ThemeManager.Apply(mode);
            await Shoot(window, folder, $"{mode}-repositories", () => main.Navigate(Section.Repositories));
            if (main.Repositories.All.FirstOrDefault(c => c.IsGit) is { } gitCard)
            {
                // The branch picker of a Git clone (cancelled after the shot).
                var picking = main.Repositories.ChangeBranchAsync(gitCard);
                for (var i = 0; i < 100 && main.Dialog is null; i++)
                {
                    await Task.Delay(100);
                }
                await Shoot(window, folder, $"{mode}-change-branch", () => { }, 600);
                main.Dialog?.CancelCommand.Execute(null);
                await picking;
            }
            if (main.Workspace is { } menuSpace)
            {
                // The header's two menus.
                await main.OpenRepositoryAsync(menuSpace.Record, Section.Documentation);
                main.ToggleRepositoryMenuCommand.Execute(null);
                await Shoot(window, folder, $"{mode}-header-repository-menu", () => { }, 900);
                main.CloseMenus();
                await Shoot(window, folder, $"{mode}-header-app-menu", () => main.ToggleAppMenuCommand.Execute(null), 700);
                main.CloseMenus();
            }
            if (main.Workspace is { } workspace)
            {
                await Shoot(window, folder, $"{mode}-documentation", () =>
                {
                    main.Navigate(Section.Documentation);
                    var notes = workspace.Index?.Pages.FirstOrDefault(p => p.SourcePath?.Contains("notes", StringComparison.OrdinalIgnoreCase) == true) ?? workspace.Index?.Pages.FirstOrDefault();
                    if (notes is not null)
                    {
                        workspace.Documentation.OpenPage(notes.Id, null);
                    }
                });
                await Shoot(window, folder, $"{mode}-reference", () =>
                {
                    var page = workspace.Index?.Pages.FirstOrDefault(p => p.Title.StartsWith("API", StringComparison.Ordinal)) ?? workspace.Index?.Pages.FirstOrDefault(p => p.Generated);
                    if (page is not null)
                    {
                        workspace.Documentation.OpenPage(page.Id, null);
                    }
                });
                await Shoot(window, folder, $"{mode}-source", () =>
                {
                    var file = workspace.Index?.Files.FirstOrDefault(f => f.Path.EndsWith("AverageCalculator.cs", StringComparison.Ordinal))
                               ?? workspace.Index?.Files.FirstOrDefault(f => f.Kind == FileKind.Source);
                    if (file is not null)
                    {
                        workspace.Documentation.OpenFile(file.Path, 5);
                    }
                });
                await Shoot(window, folder, $"{mode}-assistant-working", () =>
                {
                    main.Navigate(Section.Documentation);
                    workspace.Assistant.Input = workspace.Assistant.Suggestions.Skip(2).FirstOrDefault() ?? "Explain the architecture of this repository.";
                    workspace.Assistant.SendCommand.Execute(null);
                }, 450);
                await Shoot(window, folder, $"{mode}-assistant", () => { }, 2500);
                await Shoot(window, folder, $"{mode}-assistant-table", () =>
                {
                    const string table = """
                        ## Program flow

                        | Project | Class | Method | Description |
                        |---|---|---|---|
                        | Request.Listener | `OrderService_1_0.Handler` | `Handle` | Receives the request from the queue, validates the envelope and passes the payload on to the parser so it can be translated. |
                        | OrderDomain.Services | `AvailableProductsService` | `GetAvailableProductsAsync` | Looks up the products the customer can order and returns them. |
                        """;
                    workspace.Assistant.Messages.Add(new ChatMessageViewModel(new ChatMessage { Role = "assistant", Text = table }, workspace.Assistant));
                    main.AssistantVisible = true;
                    main.AssistantExpanded = true;
                }, 1200);
                await Shoot(window, folder, $"{mode}-assistant-mermaid", () =>
                {
                    const string diagrams = """
                        ## Diagrams


                        ```mermaid
                        classDiagram
                            class IReadingStore {
                              <<interface>>
                              +All() IReadOnlyList~Reading~
                            }
                            class FileReadingStore
                            class DashboardService
                            IReadingStore <|.. FileReadingStore
                            DashboardService --> IReadingStore : uses
                        ```

                        ```mermaid
                        flowchart TD
                            A[Request] --> B{Valid?}
                            B -- yes --> C[Process]
                            B -- no --> D[Error response]
                        ```

                        ```mermaid
                        sequenceDiagram
                            participant H as Handler
                            participant P as RequestParser
                            participant A as OrderService
                            participant R as ResponseCreator
                            H->>P: Parse(request)
                            P-->>H: IOrderRequest
                            H->>A: PlaceOrder(request)
                            A-->>H: List<OrderLine>
                            H->>R: CreateSuccess(traceId, lines)
                            R-->>H: OrderResponse
                        ```
                        """;
                    workspace.Assistant.Messages.Add(new ChatMessageViewModel(new ChatMessage { Role = "assistant", Text = diagrams }, workspace.Assistant));
                    main.AssistantVisible = true;
                }, 9000);
                if (FindAll<Controls.DiagramViewer>(window).LastOrDefault() is { } viewer)
                {
                    viewer.ShowFullScreen();
                    await Task.Delay(1200);
                    if (Application.Current.Windows.OfType<Window>().LastOrDefault(w => w.Content is Controls.DiagramViewer) is { } full)
                    {
                        var fullViewer = (Controls.DiagramViewer)full.Content;
                        fullViewer.ZoomIn();
                        fullViewer.ZoomIn();
                        await Shoot(full, folder, $"{mode}-diagram-fullscreen", () => { }, 600);
                        // Far in: the picture enlarged at first, then the part in view drawn again, sharp.
                        for (var i = 0; i < 14; i++)
                        {
                            fullViewer.ZoomIn();
                        }
                        await Shoot(full, folder, $"{mode}-diagram-zoomed-blurry", () => { }, 30);
                        for (var wait = 0; wait < 60 && !fullViewer.IsSharpened; wait++)
                        {
                            await Task.Delay(100);
                        }
                        Logging.Info($"Capture: zoomed diagram sharpened = {fullViewer.IsSharpened}");
                        await Shoot(full, folder, $"{mode}-diagram-zoomed-sharp", () => { }, 300);
                        full.Close();
                    }
                }
                main.AssistantExpanded = false;
                await Shoot(window, folder, $"{mode}-composer-empty", () => workspace.Assistant.Input = "");
                // Resizing: mid-drag only the guide moves; on release the columns change.
                if (window.FindName("AssistantThumb") is System.Windows.Controls.Primitives.Thumb assistantThumb
                    && window.FindName("TreeThumb") is System.Windows.Controls.Primitives.Thumb treeThumb)
                {
                    await Shoot(window, folder, $"{mode}-resize-dragging", () =>
                    {
                        assistantThumb.RaiseEvent(new System.Windows.Controls.Primitives.DragStartedEventArgs(0, 0));
                        assistantThumb.RaiseEvent(new System.Windows.Controls.Primitives.DragDeltaEventArgs(-220, 0));
                    }, 500);
                    await Shoot(window, folder, $"{mode}-resize-done", () =>
                    {
                        assistantThumb.RaiseEvent(new System.Windows.Controls.Primitives.DragCompletedEventArgs(-220, 0, false));
                        treeThumb.RaiseEvent(new System.Windows.Controls.Primitives.DragStartedEventArgs(0, 0));
                        treeThumb.RaiseEvent(new System.Windows.Controls.Primitives.DragCompletedEventArgs(90, 0, false));
                    }, 900);
                    var sw = System.Diagnostics.Stopwatch.StartNew();
                    for (var i = 0; i < 60; i++)
                    {
                        assistantThumb.RaiseEvent(new System.Windows.Controls.Primitives.DragDeltaEventArgs(-i * 4, 0));
                        window.UpdateLayout();
                    }
                    Logging.Info($"Resize drag: 60 moves in {sw.ElapsedMilliseconds} ms");
                    assistantThumb.RaiseEvent(new System.Windows.Controls.Primitives.DragCompletedEventArgs(220, 0, false));
                    treeThumb.RaiseEvent(new System.Windows.Input.MouseButtonEventArgs(System.Windows.Input.Mouse.PrimaryDevice, 0, System.Windows.Input.MouseButton.Left)
                        { RoutedEvent = System.Windows.Controls.Control.MouseDoubleClickEvent });
                    window.UpdateLayout();
                }
                await Shoot(window, folder, $"{mode}-composer-typed", () => workspace.Assistant.Input = "Ask anything about this repository…");
                workspace.Assistant.Input = "";
                await Shoot(window, folder, $"{mode}-search", () =>
                {
                    main.SearchQuery = "average";
                }, 1200);
                main.IsSearchOpen = false;
                await Shoot(window, folder, $"{mode}-graph", () => main.Navigate(Section.Graph), 2000);
                // Grouping: the overview of groups, one group opened, then back to the whole graph.
                var graphVm = workspace.Graph;
                graphVm.GroupCommand.Execute(null);
                for (var wait = 0; wait < 600 && (graphVm.IsGrouping || !graphVm.IsGrouped); wait++)
                {
                    await Task.Delay(100);
                }
                await Shoot(window, folder, $"{mode}-graph-groups", () => { }, 2500);
                if (graphVm.Groups.FirstOrDefault() is { } firstGroup)
                {
                    await Shoot(window, folder, $"{mode}-graph-group-open", () => firstGroup.OpenCommand.Execute(null), 2500);
                }
                graphVm.ResetGroupingCommand.Execute(null);
                await Shoot(window, folder, $"{mode}-graph-reset", () => { }, 2500);
                // Show only one part: the first namespace-like word of the repository, its traced flow, then grouped.
                var scopeWord = Environment.GetEnvironmentVariable("DOCGEN_CAPTURE_SCOPE") ?? "AverageCalculator";
                graphVm.ScopeText = scopeWord;
                await Task.Delay(600);
                await Shoot(window, folder, $"{mode}-graph-scope-suggest", () => { }, 300);
                graphVm.ScopeText = scopeWord + " flow without tests";
                graphVm.ApplyScopeCommand.Execute(null);
                for (var wait = 0; wait < 600 && (graphVm.IsScoping || !graphVm.IsScoped); wait++)
                {
                    await Task.Delay(100);
                }
                await Shoot(window, folder, $"{mode}-graph-scoped", () => { }, 2500);
                graphVm.GroupCommand.Execute(null);
                for (var wait = 0; wait < 600 && (graphVm.IsGrouping || !graphVm.IsGrouped); wait++)
                {
                    await Task.Delay(100);
                }
                await Shoot(window, folder, $"{mode}-graph-scoped-groups", () => { }, 2500);
                graphVm.ClearScopeCommand.Execute(null);
                await Shoot(window, folder, $"{mode}-graph-whole", () => { }, 2000);
                await Shoot(window, folder, $"{mode}-indexing", () => main.Navigate(Section.Indexing));
                await Shoot(window, folder, $"{mode}-learning", () => main.Navigate(Section.Learning));
                await Shoot(window, folder, $"{mode}-quiz-form", () => workspace.Learning.StartGeneratorCommand.Execute("quiz"));
                await Shoot(window, folder, $"{mode}-quiz", () => workspace.Learning.GenerateCommand.Execute(null), 1500);
                await Shoot(window, folder, $"{mode}-quiz-taking", () => workspace.Learning.Quiz?.StartCommand.Execute(null));
                await Shoot(window, folder, $"{mode}-studio", () => main.Navigate(Section.Studio));
                if (main.Workspace?.Studio.Speakers.FirstOrDefault() is { } firstSpeaker)
                {
                    // The persona editor window Studio opens for "Add persona" and "Edit".
                    var editorWindow = Views.PersonaEditorWindow.Create(main, firstSpeaker.Persona);
                    editorWindow.Show();
                    await Shoot(editorWindow, folder, $"{mode}-studio-persona-editor", () => { }, 900);
                    editorWindow.Close();
                }
            }
            // Studio: a conversation with faces — the speaker talking with the line's emotion, the others reacting.
            if (main.Workspace is { } studioSpace)
            {
                await main.Engine.Studio.AddStarterPersonasAsync();
                main.Navigate(Section.Studio);
                var studio = studioSpace.Studio;
                await studio.ActivateAsync();
                foreach (var speaker in studio.Speakers.Take(3))
                {
                    speaker.IsChosen = true;
                }
                studio.Topic = "How the averages are computed, what can go wrong, and how it is tested";
                studio.ComposeCommand.Execute(null);
                for (var wait = 0; wait < 300 && studio.Mode != "conversation"; wait++)
                {
                    await Task.Delay(100);
                }
                var emotional = studio.Lines.FirstOrDefault(l => l.Emotion is not "neutral") ?? studio.Lines.FirstOrDefault();
                if (emotional is not null)
                {
                    await Shoot(window, folder, $"{mode}-studio-stage", () => studio.PreviewLine(emotional.Index), 1500);
                }
            }
            await Shoot(window, folder, $"{mode}-personas", () => main.Navigate(Section.Personas));
            await Shoot(window, folder, $"{mode}-persona-editor", () =>
            {
                if (main.Personas.Personas.FirstOrDefault() is { } first)
                {
                    main.Personas.EditCommand.Execute(first);
                    if (main.Personas.Editor is { } editor)
                    {
                        editor.PreviewEmotion = "excited";
                    }
                }
            }, 1500);
            // Usage: sample calls over several days (with details, one failed), the 7-day range, export, a call's details.
            var random = new Random(7);
            string[] features = ["assistant", "studio", "graph-groups", "graph-scope", "describe-graph", "rewrite", "learning"];
            for (var i = 0; i < 40; i++)
            {
                var feature = features[i % features.Length];
                var input = random.Next(400, 9000);
                await main.Engine.Usage.RecordAsync(new UsageEntry
                {
                    At = DateTime.UtcNow.AddDays(-random.Next(0, 26)).AddMinutes(-random.Next(0, 600)),
                    Feature = feature,
                    ModelId = i % 5 == 0 ? "cloud-reasoner" : "cloud-chat",
                    ProviderId = "cloud",
                    RepositoryId = main.Workspace?.Record.Id,
                    InputTokens = input,
                    OutputTokens = random.Next(40, 1800),
                    DurationMs = random.Next(400, 9000),
                    Failed = i == 9,
                    Error = i == 9 ? "HTTP 429 Too Many Requests: rate limit reached for cloud-chat" : null,
                    Purpose = feature switch
                    {
                        "assistant" => "How does AverageCalculator handle an empty list of readings?",
                        "graph-scope" => "only the sensor dashboard flow without tests",
                        "studio" => "Write a technical discussion between Maya and Sam about the averages",
                        _ => $"{feature} request {i}",
                    },
                    Messages =
                    [
                        new UsageMessage { Role = "system", Chars = 1800, Preview = "You are the repository assistant of DocGen Explorer… Rules: answer only from the evidence…" },
                        new UsageMessage { Role = "user", Chars = input * 4, Preview = "Repository: sample-sensor-dashboard — 13 files… Evidence: [1] src/SensorDashboard/AverageCalculator.cs:1-32 … Question: How does AverageCalculator handle an empty list of readings?" },
                    ],
                    Response = "AverageCalculator.Average returns null for an empty list [1]: it materialises the readings and checks Count == 0 before averaging…",
                    ResponseChars = 2400,
                    FinishReason = i == 9 ? null : "stop",
                    MaxOutputTokens = 3000,
                    Streamed = feature == "assistant",
                    ReasoningChars = i % 5 == 0 ? 5200 : 0,
                });
            }
            await Shoot(window, folder, $"{mode}-usage", () => main.Navigate(Section.Usage), 1500);
            main.Usage.SetRangeCommand.Execute("7");
            await Shoot(window, folder, $"{mode}-usage-7days", () => { }, 1500);
            await main.Usage.ExportToAsync(Path.Combine(folder, "usage-export.csv"));
            await main.Usage.ExportToAsync(Path.Combine(folder, "usage-export.json"));
            main.Usage.SetRangeCommand.Execute("30");
            await Task.Delay(800);
            if (main.Usage.Table.Rows.FirstOrDefault(e => e.Entry.HasDetails && !e.Failed) is { } row)
            {
                var entry = row.Entry;
                var details = new UsageDetailsViewModel(entry, main.Workspace?.Title, "Cloud AI");
                var detailsWindow = new Views.UsageDetailsWindow(details) { Owner = window };
                detailsWindow.Show();
                await Task.Delay(900);
                await Shoot(detailsWindow, folder, $"{mode}-usage-details", () => { }, 300);
                detailsWindow.Close();
            }
            await Shoot(window, folder, $"{mode}-help", () => main.Navigate(Section.Help));
            await Shoot(window, folder, $"{mode}-settings", () => main.Navigate(Section.Settings));
            foreach (var settingsPage in ViewModels.SettingsPages.All)
            {
                await Shoot(window, folder, $"{mode}-settings-{settingsPage}", () => main.Settings.ShowPage(settingsPage), 500);
            }
            await Shoot(window, folder, $"{mode}-settings-provider", () =>
            {
                main.Settings.ShowPage(ViewModels.SettingsPages.Providers);
                if (main.Settings.Providers.FirstOrDefault() is { } provider)
                {
                    provider.IsExpanded = true;
                }
            });
            if (main.Settings.Providers.FirstOrDefault() is { } expanded)
            {
                expanded.IsExpanded = false;
            }
            main.Settings.ShowPage(ViewModels.SettingsPages.Confluence);
            await main.Settings.Confluence.LoadAsync();
            await Shoot(window, folder, $"{mode}-settings-confluence-site", () =>
            {
                main.Settings.Confluence.AddSiteCommand.Execute(null);
                var site = main.Settings.Confluence.Sites[^1];
                site.BaseUrl = "https://example.atlassian.net/wiki";
                site.Email = "you@example.com";
            }, 900);
            await main.Settings.Confluence.LoadAsync();
            main.Settings.ShowPage(ViewModels.SettingsPages.Appearance);
        }
        Logging.Info("Capture finished");
        Application.Current.Shutdown(0);
    }

    internal static async Task Shoot(Window window, string folder, string name, Action arrange, int settleMs = 900)
    {
        try
        {
            arrange();
        }
        catch (Exception ex)
        {
            Logging.Error(ex, "Capture step " + name);
        }
        await Task.Delay(settleMs);
        await window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ApplicationIdle);
        var source = PresentationSource.FromVisual(window);
        var dpi = source?.CompositionTarget?.TransformToDevice.M11 ?? 1;
        var content = (FrameworkElement)window.Content;
        // The size on screen: with the interface zoomed (Ctrl+=) the window shows the content scaled.
        var shot = content.LayoutTransform.TransformBounds(new Rect(content.RenderSize)).Size;
        var width = (int)(shot.Width * dpi);
        var height = (int)(shot.Height * dpi);
        var bitmap = new RenderTargetBitmap(width, height, 96 * dpi, 96 * dpi, PixelFormats.Pbgra32);
        var visual = new DrawingVisual();
        using (var dc = visual.RenderOpen())
        {
            dc.DrawRectangle(window.Background, null, new Rect(0, 0, shot.Width, shot.Height));
            // Exactly the window's area: by default a VisualBrush fits everything drawn (also what the window clips
            // off at its edge) into the rectangle, which shrinks and softens the picture.
            dc.DrawRectangle(new VisualBrush(content)
            {
                ViewboxUnits = BrushMappingMode.Absolute,
                Viewbox = new Rect(0, 0, shot.Width, shot.Height),
                Stretch = Stretch.None,
                AlignmentX = AlignmentX.Left,
                AlignmentY = AlignmentY.Top,
            }, null, new Rect(0, 0, shot.Width, shot.Height));
        }
        bitmap.Render(visual);
        // Popups (search results, menus) live in their own windows; render them over the main one.
        foreach (var popup in FindPopups(window).Where(p => p.IsOpen && p.Child is FrameworkElement))
        {
            var child = (FrameworkElement)popup.Child;
            var origin = child.PointToScreen(new Point(0, 0));
            var windowOrigin = content.PointToScreen(new Point(0, 0));
            var offset = new Point((origin.X - windowOrigin.X) / dpi, (origin.Y - windowOrigin.Y) / dpi);
            var overlay = new DrawingVisual();
            using (var dc = overlay.RenderOpen())
            {
                // Its size on screen (pop-ups scale with the interface size too).
                dc.DrawRectangle(new VisualBrush(child), null, new Rect(offset, child.LayoutTransform.TransformBounds(new Rect(child.RenderSize)).Size));
            }
            bitmap.Render(overlay);
        }
        var encoder = new PngBitmapEncoder();
        encoder.Frames.Add(BitmapFrame.Create(bitmap));
        await using var file = File.Create(Path.Combine(folder, name + ".png"));
        encoder.Save(file);
    }

    /// <summary>Every persona picture, and a few in every emotion (shut, talking, blinking), as contact sheets.</summary>
    private static void AvatarSheets(string folder)
    {
        static void Save(string path, int width, int height, Action<DrawingContext> draw)
        {
            var visual = new DrawingVisual();
            using (var context = visual.RenderOpen())
            {
                context.DrawRectangle(Brushes.White, null, new Rect(0, 0, width, height));
                draw(context);
            }
            var bitmap = new RenderTargetBitmap(width, height, 96, 96, PixelFormats.Pbgra32);
            bitmap.Render(visual);
            var encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(bitmap));
            using var file = File.Create(path);
            encoder.Save(file);
        }
        static void Face(DrawingContext context, Drawing drawing, double x, double y, double size)
        {
            context.PushTransform(new TranslateTransform(x, y));
            context.PushTransform(new ScaleTransform(size / 120, size / 120));
            context.DrawDrawing(drawing);
            context.Pop();
            context.Pop();
        }
        var all = Avatars.AvatarCatalog.All;
        var label = new Typeface("Segoe UI");
        Save(Path.Combine(folder, "avatars-all.png"), 10 * 110, (all.Count + 9) / 10 * 124, context =>
        {
            for (var i = 0; i < all.Count; i++)
            {
                var (x, y) = (i % 10 * 110 + 15, i / 10 * 124 + 6);
                Face(context, Avatars.AvatarCatalog.DrawingFor(all[i], "neutral"), x, y, 80);
                context.DrawText(new FormattedText(all[i].Label, System.Globalization.CultureInfo.InvariantCulture, FlowDirection.LeftToRight, label, 11, Brushes.Black, 1.0), new Point(x, y + 84));
            }
        });
        var sample = new[] { "sunny", "captain", "coder", "robot", "cat", "owl", "monster", "p-ada", "p-kofi", "unicorn" }.Select(id => Avatars.AvatarCatalog.Find(id)).ToList();
        var emotions = DocGen.Explorer.Engine.Studio.Emotions.All;
        Save(Path.Combine(folder, "avatars-emotions.png"), (emotions.Count + 2) * 86 + 20, sample.Count * 90 + 40, context =>
        {
            for (var e = 0; e < emotions.Count; e++)
            {
                context.DrawText(new FormattedText(emotions[e], System.Globalization.CultureInfo.InvariantCulture, FlowDirection.LeftToRight, label, 10, Brushes.Black, 1.0), new Point(20 + e * 86, 6));
            }
            context.DrawText(new FormattedText("talking", System.Globalization.CultureInfo.InvariantCulture, FlowDirection.LeftToRight, label, 10, Brushes.Black, 1.0), new Point(20 + emotions.Count * 86, 6));
            context.DrawText(new FormattedText("blink", System.Globalization.CultureInfo.InvariantCulture, FlowDirection.LeftToRight, label, 10, Brushes.Black, 1.0), new Point(20 + (emotions.Count + 1) * 86, 6));
            for (var a = 0; a < sample.Count; a++)
            {
                for (var e = 0; e < emotions.Count; e++)
                {
                    Face(context, Avatars.AvatarCatalog.DrawingFor(sample[a], emotions[e]), 20 + e * 86, 26 + a * 90, 78);
                }
                Face(context, Avatars.AvatarCatalog.DrawingFor(sample[a], "happy", mouthOpen: true), 20 + emotions.Count * 86, 26 + a * 90, 78);
                Face(context, Avatars.AvatarCatalog.DrawingFor(sample[a], "neutral", eyesClosed: true), 20 + (emotions.Count + 1) * 86, 26 + a * 90, 78);
            }
        });
        // Every picture in every state draws (errors are logged and drawn grey).
        foreach (var avatar in all)
        {
            foreach (var emotion in emotions)
            {
                foreach (var (open, closed) in new[] { (false, false), (true, false), (false, true), (true, true) })
                {
                    _ = Avatars.AvatarCatalog.DrawingFor(avatar, emotion, open, closed);
                }
            }
        }
        Logging.Info($"Avatar sheets: {all.Count} pictures × {emotions.Count} emotions drawn");
    }

    internal static IEnumerable<T> FindAll<T>(DependencyObject root) where T : DependencyObject
    {
        if (root is T match)
        {
            yield return match;
        }
        for (var i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++)
        {
            foreach (var nested in FindAll<T>(VisualTreeHelper.GetChild(root, i)))
            {
                yield return nested;
            }
        }
    }

    internal static IEnumerable<System.Windows.Controls.Primitives.Popup> FindPopups(DependencyObject root)
    {
        if (root is System.Windows.Controls.Primitives.Popup popup)
        {
            yield return popup;
        }
        var count = VisualTreeHelper.GetChildrenCount(root);
        for (var i = 0; i < count; i++)
        {
            foreach (var nested in FindPopups(VisualTreeHelper.GetChild(root, i)))
            {
                yield return nested;
            }
        }
        foreach (var logical in LogicalTreeHelper.GetChildren(root).OfType<DependencyObject>())
        {
            if (logical is System.Windows.Controls.Primitives.Popup p)
            {
                yield return p;
            }
        }
    }
}
