using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace DocGen.Explorer.Infrastructure.Docking;

/// <summary>What the dock host needs from the application: a view, a title and an icon glyph for each panel.</summary>
public interface IDockContentProvider
{
    FrameworkElement ViewFor(string panel);
    string TitleFor(string panel);
    string IconFor(string panel);

    /// <summary>Whether a panel can be shown now (the files list needs a repository; a hidden assistant is not drawn).</summary>
    bool IsAvailable(string panel);

    /// <summary>A panel's close button: the application closes it its own way (true), or the layout hides it (false).</summary>
    bool Close(string panel);

    /// <summary>The resource key of the panel's background, which its header shares so the two read as one.</summary>
    string BackgroundFor(string panel);
}

/// <summary>
/// Draws a <see cref="DockLayout"/>: nested splits with draggable dividers, tab groups whose header carries the title,
/// float / close / dock-options buttons, drag-and-drop docking (onto a group's tabs, centre or edges; outside the window
/// to float), and floating groups as their own windows. Every change goes through the layout model and raises
/// <see cref="LayoutChanged"/>; views are created once and moved, so panels keep their state wherever they go.
/// </summary>
public sealed class DockHost : Grid
{
    private const string DragFormat = "docgen/dock-panel";
    private const double HeaderHeight = 32;
    private readonly Dictionary<string, FrameworkElement> _views = new(StringComparer.Ordinal);
    private readonly Dictionary<string, Window> _floatWindows = new(StringComparer.Ordinal);
    private readonly Border _dockArea = new();
    private readonly Canvas _overlay = new() { IsHitTestVisible = false };
    private IDockContentProvider? _provider;
    private DockLayout _layout = new();
    private Point _dragStart;
    private string? _pressedPanel;

    public DockHost()
    {
        Children.Add(_dockArea);
        Children.Add(_overlay);
        AllowDrop = true;
        DragOver += OnDragOver;
        DragLeave += (_, _) => _overlay.Children.Clear();
        Drop += OnDrop;
        AutomationProperties(this, "Window layout");
    }

    public event EventHandler? LayoutChanged;

    public DockLayout Layout => _layout;

    public void Initialize(IDockContentProvider content, DockLayout initial)
    {
        _provider = content;
        _layout = initial;
        Rebuild();
    }

    /// <summary>Replaces the layout (a loaded profile, a reset) and redraws.</summary>
    public void SetLayout(DockLayout next)
    {
        _layout = next;
        _layout.Normalize();
        Rebuild();
        Changed();
    }

    /// <summary>Changes the layout and redraws.</summary>
    public void Apply(Action<DockLayout> change)
    {
        change(_layout);
        _layout.Normalize();
        Rebuild();
        Changed();
    }

    /// <summary>The view of a panel (created on first use), for code that needs to reach it.</summary>
    public FrameworkElement? ViewOf(string panel) => _provider is null ? null : _views.TryGetValue(panel, out var v) ? v : null;

    private void Changed() => LayoutChanged?.Invoke(this, EventArgs.Empty);

    /// <summary>Changes something drawn elsewhere (a tab strip's order) and saves it, without redrawing the panels.</summary>
    public void Touch(Action<DockLayout> change)
    {
        change(_layout);
        Changed();
    }

    private FrameworkElement View(string panel)
    {
        if (!_views.TryGetValue(panel, out var v))
        {
            v = _provider!.ViewFor(panel);
            _views[panel] = v;
        }
        Detach(v);
        return v;
    }

    private static void Detach(FrameworkElement v)
    {
        switch (v.Parent)
        {
            case Border b:
                b.Child = null;
                break;
            case ContentControl c:
                c.Content = null;
                break;
            case Panel p:
                p.Children.Remove(v);
                break;
        }
    }

    // ---------- building the visual tree

    /// <summary>Draws the layout again: what is available now, where the model puts it.</summary>
    public void Rebuild()
    {
        if (_provider is null)
        {
            return;
        }
        var shown = _layout.Visible(_provider.IsAvailable);
        _dockArea.Child = null;
        foreach (var v in _views.Values)
        {
            Detach(v);
        }
        _dockArea.Child = Build(shown.Root);
        SyncFloats(shown);
    }

    private FrameworkElement Build(DockNode node) => node switch
    {
        SplitNode s => BuildSplit(s),
        TabsNode t => BuildGroup(t),
        _ => new Border(),
    };

    private FrameworkElement BuildSplit(SplitNode s)
    {
        var g = new Grid();
        var horizontal = s.Axis == SplitAxis.Horizontal;
        var ratio = Math.Clamp(s.Ratio, DockLayout.MinRatio, DockLayout.MaxRatio);
        var a = new GridLength(ratio, GridUnitType.Star);
        var b = new GridLength(1 - ratio, GridUnitType.Star);
        if (horizontal)
        {
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = a, MinWidth = 180 });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(5) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = b, MinWidth = 180 });
        }
        else
        {
            g.RowDefinitions.Add(new RowDefinition { Height = a, MinHeight = 120 });
            g.RowDefinitions.Add(new RowDefinition { Height = new GridLength(5) });
            g.RowDefinitions.Add(new RowDefinition { Height = b, MinHeight = 120 });
        }
        var first = Build(s.Children[0]);
        var second = Build(s.Children[1]);
        // The divider: a hairline in the middle of a 5-pixel grip, the accent while dragged or focused.
        var line = new Border { IsHitTestVisible = false };
        line.SetResourceReference(Border.BackgroundProperty, "Brush.BorderSubtle");
        if (horizontal)
        {
            line.Width = 1;
        }
        else
        {
            line.Height = 1;
        }
        var splitter = new GridSplitter
        {
            ResizeBehavior = GridResizeBehavior.PreviousAndNext,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            VerticalAlignment = VerticalAlignment.Stretch,
            Background = Brushes.Transparent,
            Focusable = true,
            KeyboardIncrement = 24,
            ShowsPreview = true,
            Cursor = horizontal ? Cursors.SizeWE : Cursors.SizeNS,
            ToolTip = "Drag to resize (arrow keys when focused)",
        };
        splitter.Template = SplitterTemplate();
        AutomationProperties(splitter, "Resize divider");
        if (horizontal)
        {
            SetColumn(second, 2);
            SetColumn(splitter, 1);
            SetColumn(line, 1);
        }
        else
        {
            SetRow(second, 2);
            SetRow(splitter, 1);
            SetRow(line, 1);
        }
        splitter.DragCompleted += (_, _) => SaveRatio(s, g, horizontal);
        splitter.KeyUp += (_, _) => SaveRatio(s, g, horizontal);
        g.Children.Add(first);
        g.Children.Add(line);
        g.Children.Add(splitter);
        g.Children.Add(second);
        return g;
    }

    /// <summary>A transparent grip (the hairline beside it shows the divider) that takes the accent while focused.</summary>
    private static ControlTemplate SplitterTemplate()
    {
        var template = new ControlTemplate(typeof(GridSplitter));
        var border = new FrameworkElementFactory(typeof(Border), "Grip");
        border.SetValue(Border.BackgroundProperty, Brushes.Transparent);
        template.VisualTree = border;
        var focused = new Trigger { Property = UIElement.IsKeyboardFocusedProperty, Value = true };
        focused.Setters.Add(new Setter(Border.BackgroundProperty, new DynamicResourceExtension("Brush.AccentSoft"), "Grip"));
        template.Triggers.Add(focused);
        return template;
    }

    private void SaveRatio(SplitNode s, Grid g, bool horizontal)
    {
        var (one, two) = horizontal
            ? (g.ColumnDefinitions[0].ActualWidth, g.ColumnDefinitions[2].ActualWidth)
            : (g.RowDefinitions[0].ActualHeight, g.RowDefinitions[2].ActualHeight);
        if (one + two > 0)
        {
            _layout.SetRatio(s.Id, one / (one + two));
            Changed();
        }
    }

    private FrameworkElement BuildGroup(TabsNode t)
    {
        var active = t.Tabs.Contains(t.Active ?? "") ? t.Active! : t.Tabs.FirstOrDefault() ?? DockLayout.Viewport;
        var root = new Border { Tag = t, ClipToBounds = true };
        AutomationProperties(root, string.Join(", ", t.Tabs.Select(_provider!.TitleFor)));
        var dock = new DockPanel { LastChildFill = true };
        // The page alone needs no header: it has its own title. Any group of tool panels, or the page tabbed with others, has one.
        if (!(t.Tabs.Count == 1 && active == DockLayout.Viewport))
        {
            dock.Children.Add(Header(t, active));
        }
        dock.Children.Add(new Border { Child = View(active) });
        root.Child = dock;
        return root;
    }

    private Border Header(TabsNode t, string active)
    {
        var head = new DockPanel { Height = HeaderHeight, Margin = new Thickness(8, 0, 4, 0) };
        var actions = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
        if (active != DockLayout.Viewport)
        {
            var floating = _layout.IsFloating(active);
            if (!floating)
            {
                actions.Children.Add(ActionButton("", "Float in its own window", () => Apply(l => l.Dock(active, DockPosition.Float))));
            }
            actions.Children.Add(ActionButton("", $"Close {_provider!.TitleFor(active)}", () => ClosePanel(active)));
        }
        var more = ActionButton("", "Dock options: split, tab, float, close", () => { });
        more.Click += (_, _) => ShowDockMenu(more, active);
        actions.Children.Insert(0, more);
        DockPanel.SetDock(actions, Dock.Right);
        head.Children.Add(actions);
        var tabs = new StackPanel { Orientation = Orientation.Horizontal };
        foreach (var p in t.Tabs)
        {
            tabs.Children.Add(TabHeader(p, p == active, t.Tabs.Count > 1));
        }
        head.Children.Add(new ScrollViewer
        {
            Content = tabs,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Hidden,
            VerticalScrollBarVisibility = ScrollBarVisibility.Disabled,
            Focusable = false,
        });
        var border = new Border { Child = head, BorderThickness = new Thickness(0, 0, 0, 1) };
        border.SetResourceReference(Border.BorderBrushProperty, "Brush.BorderSubtle");
        border.SetResourceReference(Border.BackgroundProperty, _provider!.BackgroundFor(active));
        DockPanel.SetDock(border, Dock.Top);
        return border;
    }

    private void ClosePanel(string panel)
    {
        if (_provider is not null && _provider.Close(panel))
        {
            Rebuild();
            Changed();
            return;
        }
        Apply(l => l.Hide(panel));
    }

    private FrameworkElement TabHeader(string panel, bool selected, bool several)
    {
        var content = new StackPanel { Orientation = Orientation.Horizontal };
        var icon = new TextBlock { Text = _provider!.IconFor(panel), FontSize = 12, Margin = new Thickness(0, 1, 7, 0), VerticalAlignment = VerticalAlignment.Center };
        icon.SetResourceReference(TextBlock.FontFamilyProperty, "Font.Icons");
        content.Children.Add(icon);
        content.Children.Add(new TextBlock { Text = _provider.TitleFor(panel), VerticalAlignment = VerticalAlignment.Center, FontSize = 12.5 });
        var tab = new ToggleButton
        {
            Content = content,
            IsChecked = selected,
            Padding = new Thickness(8, 3, 9, 3),
            Margin = new Thickness(0, 0, 2, 0),
            VerticalAlignment = VerticalAlignment.Center,
            Tag = panel,
            Focusable = true,
            ToolTip = panel == DockLayout.Viewport ? _provider.TitleFor(panel) : $"{_provider.TitleFor(panel)} — drag to dock it elsewhere",
        };
        tab.SetResourceReference(StyleProperty, several ? "Toggle.DockTab" : "Toggle.DockTitle");
        AutomationProperties(tab, _provider.TitleFor(panel));
        tab.Click += (_, _) =>
        {
            tab.IsChecked = true;
            Apply(l => l.Activate(panel));
        };
        // Ctrl+Shift+← / → moves the tab within its group (the keyboard's way to rearrange).
        tab.PreviewKeyDown += (_, e) =>
        {
            if (Keyboard.Modifiers == (ModifierKeys.Control | ModifierKeys.Shift) && e.Key is Key.Left or Key.Right && !_layout.Locked)
            {
                Apply(l => l.MoveTab(panel, e.Key == Key.Left ? -1 : 1));
                e.Handled = true;
            }
        };
        if (panel != DockLayout.Viewport)
        {
            tab.PreviewMouseLeftButtonDown += (_, e) =>
            {
                _dragStart = e.GetPosition(this);
                _pressedPanel = panel;
            };
            tab.PreviewMouseMove += (_, e) =>
            {
                if (_pressedPanel != panel || e.LeftButton != MouseButtonState.Pressed || _layout.Locked)
                {
                    return;
                }
                var d = e.GetPosition(this) - _dragStart;
                if (Math.Abs(d.X) < SystemParameters.MinimumHorizontalDragDistance && Math.Abs(d.Y) < SystemParameters.MinimumVerticalDragDistance)
                {
                    return;
                }
                _pressedPanel = null;
                var result = DragDrop.DoDragDrop(tab, new DataObject(DragFormat, panel), DragDropEffects.Move);
                _overlay.Children.Clear();
                if (result == DragDropEffects.None && Mouse.LeftButton == MouseButtonState.Released && !IsMouseOverWindow())
                {
                    Apply(l => l.Dock(panel, DockPosition.Float));
                }
            };
        }
        return tab;
    }

    private bool IsMouseOverWindow()
    {
        var w = Window.GetWindow(this);
        if (w is null)
        {
            return false;
        }
        var p = Mouse.GetPosition(w);
        return p.X >= 0 && p.Y >= 0 && p.X <= w.ActualWidth && p.Y <= w.ActualHeight;
    }

    private static Button ActionButton(string glyph, string tip, Action click)
    {
        var b = new Button { Content = glyph, ToolTip = tip, Width = 26, Height = 26, FontSize = 11, Margin = new Thickness(1, 0, 0, 0) };
        b.SetResourceReference(StyleProperty, "Button.Icon");
        AutomationProperties(b, tip);
        b.Click += (_, _) => click();
        return b;
    }

    private void ShowDockMenu(FrameworkElement anchor, string panel)
    {
        var menu = new ContextMenu { PlacementTarget = anchor, Placement = PlacementMode.Bottom };
        // Each item with its icon on the left: where the panel goes, the lock, reset and close.
        void Item(string glyph, string text, Action act, bool enabled = true)
        {
            var icon = new TextBlock { Text = glyph, FontSize = 13, VerticalAlignment = VerticalAlignment.Center };
            icon.SetResourceReference(TextBlock.FontFamilyProperty, "Font.Icons");
            var mi = new MenuItem { Header = text, Icon = icon, IsEnabled = enabled };
            mi.Click += (_, _) => act();
            menu.Items.Add(mi);
        }
        var movable = panel != DockLayout.Viewport && !_layout.Locked;
        Item("\uE8A7", "Float in its own window", () => Apply(l => l.Dock(panel, DockPosition.Float)), movable && !_layout.IsFloating(panel));
        Item("\uE90C", "Dock left of the page", () => Apply(l => l.Dock(panel, DockPosition.Left)), movable);
        Item("\uE90D", "Dock right of the page", () => Apply(l => l.Dock(panel, DockPosition.Right)), movable);
        Item("\uE737", "Dock above the page", () => Apply(l => l.Dock(panel, DockPosition.Top)), movable);
        Item("\uE90E", "Dock below the page", () => Apply(l => l.Dock(panel, DockPosition.Bottom)), movable);
        Item("\uE7C4", "Tab with the page", () => Apply(l => l.Dock(panel, DockPosition.Tab)), movable);
        menu.Items.Add(new Separator());
        Item(_layout.Locked ? "\uE785" : "\uE72E", _layout.Locked ? "Unlock the layout" : "Lock the layout", () => Apply(l => l.Locked = !l.Locked));
        Item("\uE777", "Reset the layout", () => Apply(l => l.Reset()));
        if (panel != DockLayout.Viewport)
        {
            menu.Items.Add(new Separator());
            Item("\uE711", "Close", () => ClosePanel(panel));
        }
        menu.IsOpen = true;
    }

    // ---------- drag and drop

    private (TabsNode Group, DockPosition Where, Rect Bounds, string? OnTab, bool Before, Rect TabBounds)? TargetAt(DragEventArgs e)
    {
        if (e.OriginalSource is not DependencyObject d)
        {
            return null;
        }
        string? onTab = null;
        var before = false;
        var tabBounds = Rect.Empty;
        for (var x = d; x is not null; x = x is Visual or System.Windows.Media.Media3D.Visual3D ? VisualTreeHelper.GetParent(x) : LogicalTreeHelper.GetParent(x))
        {
            if (x is ToggleButton { Tag: string tabPanel } tabButton && onTab is null)
            {
                onTab = tabPanel;
                // Dropped on a tab's left half it goes before that tab, on its right half after it.
                before = e.GetPosition(tabButton).X < tabButton.ActualWidth / 2;
                tabBounds = new Rect(tabButton.TransformToAncestor(this).Transform(new Point(0, 0)), new Size(tabButton.ActualWidth, tabButton.ActualHeight));
            }
            if (x is Border { Tag: TabsNode group } b && b.IsDescendantOf(this))
            {
                var p = e.GetPosition(b);
                var (rx, ry) = (p.X / Math.Max(1, b.ActualWidth), p.Y / Math.Max(1, b.ActualHeight));
                var where = onTab is not null ? DockPosition.Tab
                    : rx < 0.22 ? DockPosition.Left : rx > 0.78 ? DockPosition.Right : ry < 0.24 ? DockPosition.Top : ry > 0.8 ? DockPosition.Bottom : DockPosition.Tab;
                var origin = b.TransformToAncestor(this).Transform(new Point(0, 0));
                return (group, where, new Rect(origin, new Size(b.ActualWidth, b.ActualHeight)), onTab, before, tabBounds);
            }
        }
        return null;
    }

    private void OnDragOver(object sender, DragEventArgs e)
    {
        if (!e.Data.GetDataPresent(DragFormat))
        {
            return;
        }
        e.Effects = DragDropEffects.Move;
        e.Handled = true;
        _overlay.Children.Clear();
        if (TargetAt(e) is not { } t)
        {
            return;
        }
        if (t.OnTab is not null && !t.TabBounds.IsEmpty)
        {
            // Onto a tab: a line where the tab will go, before or after it.
            var x = t.Before ? t.TabBounds.Left : t.TabBounds.Right;
            var line = new Rectangle { Width = 3, Height = t.TabBounds.Height, RadiusX = 1.5, RadiusY = 1.5 };
            line.SetResourceReference(Shape.FillProperty, "Brush.Accent");
            Canvas.SetLeft(line, x - 1.5);
            Canvas.SetTop(line, t.TabBounds.Top);
            _overlay.Children.Add(line);
            return;
        }
        var r = t.Bounds;
        r = t.Where switch
        {
            DockPosition.Left => new Rect(r.X, r.Y, r.Width * 0.35, r.Height),
            DockPosition.Right => new Rect(r.X + r.Width * 0.65, r.Y, r.Width * 0.35, r.Height),
            DockPosition.Top => new Rect(r.X, r.Y, r.Width, r.Height * 0.35),
            DockPosition.Bottom => new Rect(r.X, r.Y + r.Height * 0.65, r.Width, r.Height * 0.35),
            _ => new Rect(r.X + r.Width * 0.12, r.Y + r.Height * 0.12, r.Width * 0.76, r.Height * 0.76),
        };
        var mark = new Rectangle { Width = Math.Max(0, r.Width - 8), Height = Math.Max(0, r.Height - 8), RadiusX = 10, RadiusY = 10, StrokeThickness = 2, Opacity = 0.92 };
        mark.SetResourceReference(Shape.StrokeProperty, "Brush.Accent");
        mark.SetResourceReference(Shape.FillProperty, "Brush.AccentSoft");
        Canvas.SetLeft(mark, r.X + 4);
        Canvas.SetTop(mark, r.Y + 4);
        var label = new TextBlock
        {
            Text = t.Where == DockPosition.Tab ? "Group as a tab" : "Dock " + t.Where.ToString().ToLowerInvariant(),
            FontWeight = FontWeights.SemiBold,
            FontSize = 13,
        };
        label.SetResourceReference(TextBlock.ForegroundProperty, "Brush.AccentSoftText");
        Canvas.SetLeft(label, r.X + 18);
        Canvas.SetTop(label, r.Y + 14);
        _overlay.Children.Add(mark);
        _overlay.Children.Add(label);
    }

    private void OnDrop(object sender, DragEventArgs e)
    {
        _overlay.Children.Clear();
        if (e.Data.GetData(DragFormat) is not string panel || _layout.Locked)
        {
            return;
        }
        e.Handled = true;
        if (TargetAt(e) is not { } t)
        {
            Apply(l => l.Dock(panel, DockPosition.Float));
            return;
        }
        if (t.OnTab is { } neighbour)
        {
            if (neighbour != panel)
            {
                Apply(l => l.TabNextTo(panel, neighbour, t.Before));
            }
            return;
        }
        var target = t.Group.Active ?? t.Group.Tabs.FirstOrDefault() ?? DockLayout.Viewport;
        if (target != panel)
        {
            Apply(l => l.Dock(panel, t.Where, target));
        }
    }

    // ---------- floating windows

    private void SyncFloats(DockLayout shown)
    {
        foreach (var gone in _floatWindows.Keys.Where(k => shown.Floats.All(f => f.Id != k)).ToList())
        {
            var w = _floatWindows[gone];
            _floatWindows.Remove(gone);
            w.Tag = "closing";
            w.Close();
        }
        foreach (var f in shown.Floats)
        {
            var model = _layout.Floats.FirstOrDefault(x => x.Id == f.Id) ?? f;
            if (!_floatWindows.TryGetValue(f.Id, out var w))
            {
                w = MakeFloatWindow(model);
                _floatWindows[f.Id] = w;
            }
            w.Content = FloatContent(f, model);
            w.Title = string.Join(" · ", DockLayout.Walk(f.Tree).Select(x => x.Node).OfType<TabsNode>().SelectMany(t => t.Tabs).Select(_provider!.TitleFor));
            if (!w.IsVisible && Window.GetWindow(this) is { IsVisible: true })
            {
                w.Show();
            }
        }
    }

    private FrameworkElement FloatContent(FloatingGroup shown, FloatingGroup model)
    {
        var dock = new DockPanel();
        var bar = new DockPanel { Margin = new Thickness(12, 6, 6, 6) };
        var dockButton = ActionButton("", "Dock it back beside the page", () => Apply(l =>
        {
            if (l.Floats.FirstOrDefault(x => x.Id == model.Id) is { } real)
            {
                l.Redock(real);
            }
        }));
        DockPanel.SetDock(dockButton, Dock.Right);
        bar.Children.Add(dockButton);
        var title = new TextBlock { Text = "Floating panel", VerticalAlignment = VerticalAlignment.Center };
        title.SetResourceReference(StyleProperty, "Text.Caption");
        bar.Children.Add(title);
        DockPanel.SetDock(bar, Dock.Top);
        dock.Children.Add(bar);
        dock.Children.Add(Build(shown.Tree));
        var root = new Border { Child = dock };
        root.SetResourceReference(Border.BackgroundProperty, "Brush.Window");
        root.SetResourceReference(FrameworkElement.LayoutTransformProperty, "Zoom.Transform");
        return root;
    }

    private Window MakeFloatWindow(FloatingGroup f)
    {
        var owner = Window.GetWindow(this);
        var w = new Window
        {
            Owner = owner,
            Left = (owner?.Left ?? 0) + f.X,
            Top = (owner?.Top ?? 0) + f.Y,
            Width = f.Width,
            Height = f.Height,
            ShowInTaskbar = false,
            WindowStyle = WindowStyle.ToolWindow,
            ResizeMode = ResizeMode.CanResizeWithGrip,
            AllowDrop = true,
        };
        w.SetResourceReference(Window.BackgroundProperty, "Brush.Window");
        w.SetResourceReference(System.Windows.Documents.TextElement.ForegroundProperty, "Brush.Text");
        w.SetResourceReference(System.Windows.Documents.TextElement.FontFamilyProperty, "Font.UI");
        w.SourceInitialized += (_, _) => ThemeManager.ApplyTitleBar(w);
        // Maximised, it fills the screen less the taskbar (a tool window would otherwise go under the taskbar).
        WorkAreaMaximize.Attach(w);
        w.LocationChanged += (_, _) => (f.X, f.Y) = (w.Left - (owner?.Left ?? 0), w.Top - (owner?.Top ?? 0));
        w.SizeChanged += (_, _) => (f.Width, f.Height) = (w.ActualWidth, w.ActualHeight);
        w.Deactivated += (_, _) => Changed();
        w.Closing += (_, _) =>
        {
            if (w.Tag as string == "closing")
            {
                return;
            }
            // Closing a floating window docks its panels back beside the page (they are never lost).
            _floatWindows.Remove(f.Id);
            Dispatcher.BeginInvoke(() => Apply(l =>
            {
                if (l.Floats.FirstOrDefault(x => x.Id == f.Id) is { } real)
                {
                    l.Redock(real);
                }
            }));
        };
        return w;
    }

    /// <summary>Closes the floating windows (the main window is closing).</summary>
    public void CloseFloats()
    {
        foreach (var w in _floatWindows.Values.ToList())
        {
            w.Tag = "closing";
            w.Close();
        }
        _floatWindows.Clear();
    }

    private static void AutomationProperties(DependencyObject d, string name) => System.Windows.Automation.AutomationProperties.SetName(d, name);
}
