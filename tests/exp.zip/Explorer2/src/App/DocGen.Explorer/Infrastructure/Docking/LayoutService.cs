using System.Windows.Threading;
using DocGen.Explorer.Engine;
using Prism.Events;

namespace DocGen.Explorer.Infrastructure.Docking;

/// <summary>Published whenever the window layout changes (a panel moved, a divider dragged, a tab chosen).</summary>
public sealed class LayoutChangedEvent : PubSubEvent<DockLayout>;

/// <summary>Asks the window to change its layout: "reset", "reset:files,page,ask", "lock", "unlock", "show:ask", "float:files"…</summary>
public sealed class LayoutCommandEvent : PubSubEvent<string>;

/// <summary>
/// Keeps the window layout: read from <c>settings/layout.json</c> in the data folder at start, saved a moment after
/// each change (and at once when the window closes).
/// </summary>
public sealed class LayoutService
{
    private readonly string _file;
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromMilliseconds(700) };
    private DockLayout? _pending;

    public LayoutService(ExplorerEngine engine, IEventAggregator events)
    {
        _file = Path.Combine(engine.Store.Root, "settings", "layout.json");
        _timer.Tick += (_, _) => SaveNow();
        events.GetEvent<LayoutChangedEvent>().Subscribe(layout =>
        {
            _pending = layout;
            _timer.Stop();
            _timer.Start();
        }, ThreadOption.UIThread);
    }

    public string FilePath => _file;

    /// <summary>The saved layout, or the standard one for the given pane order when there is none (or it cannot be read).</summary>
    public DockLayout Load(string? paneOrder)
    {
        try
        {
            if (File.Exists(_file))
            {
                return DockLayout.Import(File.ReadAllText(_file));
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidDataException or System.Text.Json.JsonException or NotSupportedException)
        {
            Logging.Warn("The saved window layout could not be read; the standard one is used: " + ex.Message, "layout");
        }
        var layout = new DockLayout();
        layout.Reset(paneOrder);
        return layout;
    }

    public void SaveNow()
    {
        _timer.Stop();
        if (_pending is not { } layout)
        {
            return;
        }
        _pending = null;
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(_file)!);
            File.WriteAllText(_file, layout.Export());
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            Logging.Warn("The window layout could not be saved: " + ex.Message, "layout");
        }
    }
}
