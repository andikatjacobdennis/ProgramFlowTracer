using System.Text.Json;
using System.Text.Json.Serialization;
using DocGen.Explorer.Engine.Models;

namespace DocGen.Explorer.Infrastructure.Docking;

public enum SplitAxis
{
    /// <summary>Children side by side (a vertical divider).</summary>
    Horizontal,
    /// <summary>Children one above the other (a horizontal divider).</summary>
    Vertical,
}

/// <summary>Where a dropped panel goes relative to a target group.</summary>
public enum DockPosition
{
    Tab,
    Left,
    Right,
    Top,
    Bottom,
    Float,
}

/// <summary>A node of the layout tree: a split of two children, or a group of tabbed panels.</summary>
[JsonPolymorphic(TypeDiscriminatorPropertyName = "type")]
[JsonDerivedType(typeof(SplitNode), "split")]
[JsonDerivedType(typeof(TabsNode), "tabs")]
public abstract class DockNode
{
    public string Id { get; set; } = "n" + Guid.NewGuid().ToString("N")[..8];
}

public sealed class SplitNode : DockNode
{
    public SplitAxis Axis { get; set; }

    /// <summary>The first child's share, 0.08–0.92.</summary>
    public double Ratio { get; set; } = 0.5;

    public List<DockNode> Children { get; set; } = [];
}

public sealed class TabsNode : DockNode
{
    public List<string> Tabs { get; set; } = [];
    public string? Active { get; set; }
}

/// <summary>A floating group: its own window, its place and size, and its own tree.</summary>
public sealed class FloatingGroup
{
    public string Id { get; set; } = "f" + Guid.NewGuid().ToString("N")[..8];
    public double X { get; set; } = 240;
    public double Y { get; set; } = 160;
    public double Width { get; set; } = 520;
    public double Height { get; set; } = 640;
    public DockNode Tree { get; set; } = new TabsNode();
}

public sealed class DockProfile
{
    public DockNode Root { get; set; } = new TabsNode();
    public List<FloatingGroup> Floats { get; set; } = [];
    public List<string> Hidden { get; set; } = [];
    public List<string> AutoHide { get; set; } = [];
}

/// <summary>
/// The window's layout: one recursive tree of splits and tab groups holding the panels (the page in the middle, the
/// files list and the assistant around it), floating groups, closed and auto-hidden panels, named profiles and a lock.
/// Pure data: the <see cref="DockHost"/> draws it, and it is saved as JSON.
/// </summary>
public sealed class DockLayout
{
    /// <summary>The page (Documentation, Graph, Learning, Studio…): always docked, never floated or closed.</summary>
    public const string Viewport = PaneLayout.Page;
    public const string Files = PaneLayout.Files;
    public const string Ask = PaneLayout.Ask;
    public const double MinRatio = 0.08, MaxRatio = 0.92;

    /// <summary>Every panel the explorer has, in menu order.</summary>
    public static readonly IReadOnlyList<string> Panels = [Files, Viewport, Ask];

    public DockNode Root { get; set; } = Standard();
    public List<FloatingGroup> Floats { get; set; } = [];
    public List<string> Hidden { get; set; } = [];
    public List<string> AutoHide { get; set; } = [];
    public Dictionary<string, DockProfile> Profiles { get; set; } = new(StringComparer.Ordinal);
    public bool Locked { get; set; }

    /// <summary>The order the user dragged each tab strip into ("header-sections" → ["graph", "documentation", …]).</summary>
    public Dictionary<string, List<string>> TabOrders { get; set; } = new(StringComparer.Ordinal);

    public static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web) { WriteIndented = true, Converters = { new JsonStringEnumConverter() } };

    public static TabsNode Tabs(params string[] tabs) => new() { Tabs = [.. tabs], Active = tabs.FirstOrDefault() };

    public static SplitNode Split(SplitAxis axis, DockNode a, DockNode b, double ratio = 0.5) => new() { Axis = axis, Ratio = ratio, Children = [a, b] };

    /// <summary>
    /// The standard layout for a left-to-right order of the three panels ("files,page,ask"): the files list about a
    /// seventh of the width, the assistant about a fifth, the page the rest.
    /// </summary>
    public static DockNode Standard(string? order = null)
    {
        var parts = PaneLayout.Parse(order);
        double Share(string panel) => panel switch { Files => 0.18, Ask => 0.24, _ => 0.58 };
        var first = Share(parts[0]);
        var second = Share(parts[1]) / (Share(parts[1]) + Share(parts[2]));
        return Split(SplitAxis.Horizontal, Tabs(parts[0]), Split(SplitAxis.Horizontal, Tabs(parts[1]), Tabs(parts[2]), second), first);
    }

    public void Reset(string? order = null)
    {
        Root = Standard(order);
        Floats.Clear();
        Hidden.Clear();
        AutoHide.Clear();
        TabOrders.Clear();
    }

    // ---------- queries

    public sealed record Location(TabsNode Group, SplitNode? Parent, int Index, FloatingGroup? Float);

    public static IEnumerable<(DockNode Node, SplitNode? Parent, int Index)> Walk(DockNode node, SplitNode? parent = null, int index = -1)
    {
        yield return (node, parent, index);
        if (node is SplitNode s)
        {
            for (var i = 0; i < s.Children.Count; i++)
            {
                foreach (var x in Walk(s.Children[i], s, i))
                {
                    yield return x;
                }
            }
        }
    }

    public Location? Find(string panel)
    {
        foreach (var (n, p, i) in Walk(Root))
        {
            if (n is TabsNode t && t.Tabs.Contains(panel))
            {
                return new(t, p, i, null);
            }
        }
        foreach (var f in Floats)
        {
            foreach (var (n, p, i) in Walk(f.Tree))
            {
                if (n is TabsNode t && t.Tabs.Contains(panel))
                {
                    return new(t, p, i, f);
                }
            }
        }
        return null;
    }

    public bool IsShown(string panel) => Find(panel) is not null;

    public bool IsFloating(string panel) => Find(panel)?.Float is not null;

    public IEnumerable<string> AllPanels() =>
        Walk(Root).Select(x => x.Node).Concat(Floats.SelectMany(f => Walk(f.Tree).Select(x => x.Node))).OfType<TabsNode>().SelectMany(t => t.Tabs);

    /// <summary>Which side of the page a panel is on in the docked tree: -1 left of it, 1 right of it, 0 above, below or tabbed with it.</summary>
    public int SideOfViewport(string panel)
    {
        var order = Walk(Root).Select(x => x.Node).OfType<TabsNode>().SelectMany(t => t.Tabs).ToList();
        int a = order.IndexOf(panel), v = order.IndexOf(Viewport);
        return a < 0 || v < 0 || a == v ? 0 : a < v ? -1 : 1;
    }

    // ---------- operations

    public void Remove(string panel)
    {
        if (Find(panel) is not { } at)
        {
            return;
        }
        at.Group.Tabs.Remove(panel);
        if (at.Group.Active == panel)
        {
            at.Group.Active = at.Group.Tabs.FirstOrDefault();
        }
        Normalize();
    }

    /// <summary>Docks a panel: tabbed into the target's group, split to one of its sides, or floated.</summary>
    public void Dock(string panel, DockPosition where, string target = Viewport)
    {
        if (panel == Viewport && where == DockPosition.Float)
        {
            return;
        }
        Remove(panel);
        Hidden.Remove(panel);
        AutoHide.Remove(panel);
        if (where == DockPosition.Float)
        {
            Floats.Add(new FloatingGroup { Tree = Tabs(panel) });
            return;
        }
        var at = Find(target) ?? Find(Viewport);
        if (at is null)
        {
            Root = Split(SplitAxis.Horizontal, Root, Tabs(panel), 0.78);
            return;
        }
        if (where == DockPosition.Tab)
        {
            at.Group.Tabs.Add(panel);
            at.Group.Active = panel;
            return;
        }
        var axis = where is DockPosition.Left or DockPosition.Right ? SplitAxis.Horizontal : SplitAxis.Vertical;
        var first = where is DockPosition.Left or DockPosition.Top;
        var split = Split(axis, first ? Tabs(panel) : at.Group, first ? at.Group : Tabs(panel), first ? 0.25 : 0.75);
        Replace(at, split);
    }

    /// <summary>Puts a panel into a group as a tab beside another one (dropped on that tab: before it or after it).</summary>
    public void TabNextTo(string panel, string neighbour, bool before = false)
    {
        if (panel == neighbour || Find(neighbour) is null)
        {
            return;
        }
        Remove(panel);
        Hidden.Remove(panel);
        AutoHide.Remove(panel);
        if (Find(neighbour) is { } at)
        {
            at.Group.Tabs.Insert(at.Group.Tabs.IndexOf(neighbour) + (before ? 0 : 1), panel);
            at.Group.Active = panel;
        }
    }

    /// <summary>Moves a tab one place left or right within its group (Ctrl+Shift+← / → on the tab).</summary>
    public void MoveTab(string panel, int by)
    {
        if (Find(panel) is not { } at)
        {
            return;
        }
        var i = at.Group.Tabs.IndexOf(panel);
        var to = Math.Clamp(i + by, 0, at.Group.Tabs.Count - 1);
        if (to != i)
        {
            at.Group.Tabs.RemoveAt(i);
            at.Group.Tabs.Insert(to, panel);
        }
    }

    public void Hide(string panel, bool autoHide = false)
    {
        if (panel == Viewport)
        {
            return;
        }
        Remove(panel);
        var list = autoHide ? AutoHide : Hidden;
        if (!list.Contains(panel))
        {
            list.Add(panel);
        }
    }

    public void Toggle(string panel)
    {
        if (IsShown(panel))
        {
            Hide(panel);
        }
        else
        {
            Show(panel);
        }
    }

    /// <summary>Shows a closed panel: beside the page on its usual side (files left, assistant right).</summary>
    public void Show(string panel, string? beside = null)
    {
        Hidden.Remove(panel);
        AutoHide.Remove(panel);
        if (IsShown(panel))
        {
            Activate(panel);
            return;
        }
        if (beside is not null && Find(beside) is not null)
        {
            TabNextTo(panel, beside);
            return;
        }
        Dock(panel, panel == Files ? DockPosition.Left : DockPosition.Right, Viewport);
        if (Find(panel)?.Parent is { } split)
        {
            // A panel brought back is narrow, not a quarter of the page.
            split.Ratio = split.Children[0] is TabsNode t && t.Tabs.Contains(panel) ? (panel == Files ? 0.17 : 0.25) : (panel == Files ? 0.83 : 0.75);
        }
    }

    public void Activate(string panel)
    {
        if (Find(panel) is { } at)
        {
            at.Group.Active = panel;
        }
    }

    /// <summary>Brings a floating group back into the dock, each panel on its usual side of the page.</summary>
    public void Redock(FloatingGroup group)
    {
        var panels = Walk(group.Tree).Select(x => x.Node).OfType<TabsNode>().SelectMany(t => t.Tabs).ToList();
        Floats.Remove(group);
        foreach (var p in panels)
        {
            Show(p);
        }
    }

    public void SetRatio(string nodeId, double ratio)
    {
        foreach (var tree in Floats.Select(f => f.Tree).Prepend(Root))
        {
            foreach (var (n, _, _) in Walk(tree))
            {
                if (n is SplitNode s && s.Id == nodeId)
                {
                    s.Ratio = Math.Clamp(ratio, MinRatio, MaxRatio);
                    return;
                }
            }
        }
    }

    /// <summary>Removes empty groups and single-child splits; the page is always somewhere in the docked tree.</summary>
    public void Normalize()
    {
        Root = Prune(Root) ?? Tabs(Viewport);
        foreach (var f in Floats)
        {
            f.Tree = Prune(f.Tree)!;
        }
        Floats.RemoveAll(f => f.Tree is null);
        if (!Walk(Root).Select(x => x.Node).OfType<TabsNode>().Any(t => t.Tabs.Contains(Viewport)))
        {
            Root = Split(SplitAxis.Horizontal, Tabs(Viewport), Root, 0.75);
        }
    }

    private static DockNode? Prune(DockNode? node)
    {
        switch (node)
        {
            case null:
                return null;
            case TabsNode t:
                return t.Tabs.Count > 0 ? t : null;
            case SplitNode s:
                s.Children = [.. s.Children.Select(Prune).OfType<DockNode>()];
                return s.Children.Count switch { 0 => null, 1 => s.Children[0], _ => s };
            default:
                return node;
        }
    }

    private void Replace(Location at, DockNode replacement)
    {
        if (at.Parent is { } p)
        {
            p.Children[at.Index] = replacement;
        }
        else if (at.Float is { } f)
        {
            f.Tree = replacement;
        }
        else
        {
            Root = replacement;
        }
    }

    /// <summary>
    /// The layout as drawn: the panels that cannot be shown now (the files list outside a repository, the assistant
    /// when it is hidden) are left out of a copy, which keeps every node's id so changes made on it can be applied here.
    /// </summary>
    public DockLayout Visible(Func<string, bool> available)
    {
        var copy = Copy();
        foreach (var (node, _, _) in Walk(copy.Root).ToList().Concat(copy.Floats.SelectMany(f => Walk(f.Tree))).ToList())
        {
            if (node is TabsNode t)
            {
                t.Tabs.RemoveAll(p => !available(p));
                if (t.Active is { } a && !t.Tabs.Contains(a))
                {
                    t.Active = t.Tabs.FirstOrDefault();
                }
            }
        }
        copy.Normalize();
        return copy;
    }

    // ---------- profiles and files

    public void SaveProfile(string name)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            return;
        }
        Profiles[name.Trim()] = Clone(new DockProfile { Root = Root, Floats = Floats, Hidden = Hidden, AutoHide = AutoHide });
    }

    public bool LoadProfile(string name)
    {
        if (!Profiles.TryGetValue(name, out var p))
        {
            return false;
        }
        var copy = Clone(p);
        (Root, Floats, Hidden, AutoHide) = (copy.Root, copy.Floats, copy.Hidden, copy.AutoHide);
        return true;
    }

    public string Export() => JsonSerializer.Serialize(this, Json);

    /// <summary>A layout read from JSON; one whose root is not a split or tab group is refused. Unknown panels are dropped.</summary>
    public static DockLayout Import(string json)
    {
        var layout = JsonSerializer.Deserialize<DockLayout>(json, Json) ?? throw new InvalidDataException("Empty layout");
        if (layout.Root is not (SplitNode or TabsNode))
        {
            throw new InvalidDataException("Invalid layout tree");
        }
        foreach (var t in Walk(layout.Root).Select(x => x.Node).Concat(layout.Floats.SelectMany(f => Walk(f.Tree).Select(x => x.Node))).OfType<TabsNode>())
        {
            t.Tabs = [.. t.Tabs.Where(Panels.Contains).Distinct()];
        }
        layout.Normalize();
        return layout;
    }

    public DockLayout Copy() => JsonSerializer.Deserialize<DockLayout>(Export(), Json)!;

    private static T Clone<T>(T value) => JsonSerializer.Deserialize<T>(JsonSerializer.Serialize(value, Json), Json)!;
}
