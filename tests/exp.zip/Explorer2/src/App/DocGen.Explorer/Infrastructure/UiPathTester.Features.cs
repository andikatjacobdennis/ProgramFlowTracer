using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using DocGen.Explorer.Controls;
using DocGen.Explorer.ViewModels;
using DocGen.Explorer.Views;
using Section = DocGen.Explorer.ViewModels.Section;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// The walk of the reading and writing features: the mouse wheel, Find in a page and a file, selecting code, the class
/// diagram of a C# file, adding / editing / renaming / deleting files in Docs and their details, pasting into Ask,
/// spelling, searching a conversation, reading while an answer is written, the log viewer and its settings.
/// </summary>
public sealed partial class UiPathTester
{
    private async Task ReadingAndWritingAsync()
    {
        if (_main.Workspace is not { } workspace || workspace.Index is null)
        {
            Record("Reading and writing features", false, "no indexed repository to walk them on");
            return;
        }
        var root = workspace.Record.Path;

        // ----- Docs: wheel, Find -----
        _main.Navigate(Section.Documentation);
        await Settle(800);
        await Step("Docs → one notch of the mouse wheel scrolls the lines set in Settings → Reading and writing", async () =>
        {
            var view = DocsView();
            if (view is null || view.Viewer.Document is null)
            {
                return "no page shown";
            }
            var scroller = CaptureRunner.FindAll<ScrollViewer>(view.Viewer).FirstOrDefault();
            if (scroller is null || scroller.ScrollableHeight < 200)
            {
                _note = "the page is too short to scroll";
                return null;
            }
            var prefs = UiPreferences.Current;
            var smooth = prefs.SmoothScrolling;
            prefs.SmoothScrolling = false;
            try
            {
                scroller.ScrollToTop();
                await Settle(200);
                var presenter = CaptureRunner.FindAll<ScrollContentPresenter>(scroller).FirstOrDefault() as UIElement ?? scroller;
                presenter.RaiseEvent(new MouseWheelEventArgs(Mouse.PrimaryDevice, Environment.TickCount, -120) { RoutedEvent = UIElement.PreviewMouseWheelEvent });
                await Settle(200);
                var moved = scroller.VerticalOffset;
                return Expect(Math.Abs(moved - prefs.WheelPixels) < 2, $"one notch moved {moved:0} px; {prefs.WheelPixels:0} px expected");
            }
            finally
            {
                prefs.SmoothScrolling = smooth;
                scroller.ScrollToTop();
            }
        });

        await Step("Docs → Find (Ctrl+F): every match marked in yellow, Enter / F3 to the next, Find all lists them, Esc closes", async () =>
        {
            var view = DocsView();
            if (view?.Viewer.Document is not { } document)
            {
                return "no page shown";
            }
            var word = CommonWord(new TextRange(document.ContentStart, document.ContentEnd).Text);
            if (word is null)
            {
                return "the page has no words to find";
            }
            view.OpenFind(word);
            await Settle(600);
            var first = view.FindCount.Text;
            var marks = FindHighlightAdorner.For(view.Viewer, create: false);
            FindCommands.Next.Execute(null, view);
            await Settle(300);
            await CaptureRunner.Shoot(_window, _folder, "feature-find-page", () => { }, 100);
            var second = view.FindCount.Text;
            var problem = Expect(first.StartsWith("1 of ", StringComparison.Ordinal), $"the count reads '{first}' for '{word}'")
                          ?? Expect(marks is not null, "no yellow marks on the page")
                          ?? Expect(second.StartsWith("2 of ", StringComparison.Ordinal) || first == "1 of 1", $"Next did not move on ('{second}')")
                          ?? await Click("Find all");
            if (problem is not null)
            {
                return problem;
            }
            await Settle(400);
            await CaptureRunner.Shoot(_window, _folder, "feature-find-all", () => { }, 100);
            var listed = view.FindResults.Items.Count;
            var total = int.TryParse(first.Split(' ').Last().TrimEnd('+').Replace(",", "", StringComparison.Ordinal), out var n) ? n : -1;
            problem = Expect(view.FindAllPanel.IsVisible, "Find all shows no list") ?? Expect(listed == total, $"Find all lists {listed} of {total}");
            view.FindBox.Focus();
            view.FindBox.RaiseEvent(new KeyEventArgs(Keyboard.PrimaryDevice, PresentationSource.FromVisual(view.FindBox)!, 0, Key.Escape) { RoutedEvent = UIElement.PreviewKeyDownEvent });
            await Settle(300);
            return problem ?? Expect(!view.FindBar.IsVisible, "Esc did not close Find") ?? Expect(FindHighlightAdorner.For(view.Viewer, create: false) is null, "marks left on the page");
        });

        // ----- Files: a Markdown file — its preview, and the source again -----
        var markdownFile = workspace.Index.Files.FirstOrDefault(f => f.Path.EndsWith(".md", StringComparison.OrdinalIgnoreCase));
        if (markdownFile is not null)
        {
            workspace.Documentation.OpenFile(markdownFile.Path, 0);
            await Settle(800);
            await Step("Files → a Markdown file offers Preview: shown rendered, and its source again", async () =>
            {
                var docs = workspace.Documentation;
                var problem = Expect(docs.CanPreviewMarkdown, "no preview offered") ?? await Click("Preview");
                if (problem is not null)
                {
                    return problem;
                }
                await Settle(500);
                var view = DocsView();
                var rendered = view is not null && view.ClassDiagramViewer.IsVisible && view.ClassDiagramViewer.Document?.Blocks.Count > 0 && !view.Code.IsVisible;
                await CaptureRunner.Shoot(_window, _folder, "feature-markdown-preview", () => { }, 100);
                docs.ShowPreview = false;
                await Settle(300);
                return Expect(rendered, "the preview is not shown in place of the source") ?? Expect(DocsView()?.Code.IsVisible == true, "the source did not come back");
            });
        }

        // ----- Changes: a file edited outside the app shows in the Changes tab, and its diff opens -----
        if (markdownFile is not null && await Engine.Repositories.GitChanges.ReadAsync(workspace.Record.Path, CancellationToken.None) is not null)
        {
            var full = Path.Combine(workspace.Record.Path, markdownFile.Path.Replace('/', Path.DirectorySeparatorChar));
            var before = File.ReadAllText(full);
            File.WriteAllText(full, before + "\nA line added by the UI walk.\n");
            try
            {
                await Step("Changes → an edited file is listed with M in the folder tree; its diff opens side by side and inline, and is edited in place", async () =>
                {
                    var tree = workspace.Tree;
                    var problem = await Click("Changes");
                    if (problem is not null)
                    {
                        return problem;
                    }
                    await WaitAsync(() => tree.UnstagedChanges.Any(r => r.Change.Path == markdownFile.Path), 10);
                    var row = tree.UnstagedChanges.FirstOrDefault(r => r.Change.Path == markdownFile.Path);
                    if (row is null)
                    {
                        return "the edited file is not listed";
                    }
                    // The tree: the Changes group, the file under its folders.
                    var inTree = tree.ChangeTree.FirstOrDefault(g => g.Name == "Changes")?.Files().Contains(row) == true;
                    row.OpenCommand.Execute(null);
                    await WaitAsync(() => workspace.Documentation.Mode == "diff", 10);
                    await Settle(500);
                    var docs = workspace.Documentation;
                    var added = docs.Diff?.Added ?? 0;
                    await CaptureRunner.Shoot(_window, _folder, "feature-git-changes", () => { }, 100);
                    // The new side is code: selectable and copyable, as in Visual Studio.
                    var right = DocsView()?.DiffRight;
                    right?.SelectAll();
                    var selectedNew = right?.SelectedText ?? "";
                    right?.ClearSelection();
                    docs.SideBySide = false;
                    await Settle(300);
                    var inline = DocsView()?.DiffInline.IsVisible == true;
                    await CaptureRunner.Shoot(_window, _folder, "feature-git-diff-inline", () => { }, 100);
                    docs.SideBySide = true;
                    await Settle(200);
                    // Edit in the diff: the right side becomes the working copy; the comparison follows the typing; Ctrl+S saves.
                    docs.EditDiffFileCommand.Execute(null);
                    await WaitAsync(() => docs.IsDiffEditing, 5);
                    var edited = docs.IsDiffEditing && DocsView()?.DiffEditor.IsVisible == true;
                    docs.DiffEditorText += "Edited in the diff.\n";
                    await Settle(700);
                    var editedLine = Engine.Repositories.LineDiff.Lines(docs.DiffEditorText).ToList().LastIndexOf("Edited in the diff.");
                    var followed = editedLine >= 0 && editedLine < docs.DiffEditMarks.Count && docs.DiffEditMarks[editedLine] == "Added";
                    await CaptureRunner.Shoot(_window, _folder, "feature-git-diff-edit", () => { }, 100);
                    docs.SaveEditCommand.Execute(null);
                    await WaitAsync(() => !docs.IsDiffEditDirty, 5);
                    var saved = File.ReadAllText(full).Contains("Edited in the diff.", StringComparison.Ordinal);
                    docs.CloseDiffEditCommand.Execute(null);
                    bool Compared() => docs.Mode == "diff" && !docs.IsDiffEditing
                                       && docs.Diff?.Lines.Any(l => l.Kind == Engine.Repositories.DiffLineKind.Added && l.Text == "Edited in the diff.") == true;
                    await WaitAsync(Compared, 10);
                    var back = Compared();
                    // Undo changes: asks, then the file is as committed and the list is empty.
                    var undoProblem = await Click("Undo changes");
                    await WaitAsync(() => _main.Dialog is not null, 5);
                    var asked = _main.Dialog is not null;
                    _main.Dialog?.ConfirmCommand.Execute(null);
                    await WaitAsync(() => !tree.UnstagedChanges.Any(), 10);
                    var restored = File.ReadAllText(full) == before;
                    tree.Tab = "files";
                    await Settle(200);
                    return Expect(row.Letter == "M", $"listed as {row.Letter}") ?? Expect(inTree, "the file is not in the Changes tree") ?? Expect(docs.Mode is "diff" or "file" or "empty", "the diff did not open")
                           ?? Expect(added >= 1, "the added line is not in the diff") ?? Expect(selectedNew.Contains("A line added by the UI walk", StringComparison.Ordinal), "the new side cannot be selected")
                           ?? Expect(inline, "the inline diff is not shown") ?? Expect(edited, "Edit did not make the right side editable") ?? Expect(followed, $"the comparison did not follow the edit ({docs.DiffAdded})")
                           ?? Expect(saved, "Save did not write the file") ?? Expect(back, "Close did not compare again with what was saved")
                           ?? undoProblem ?? Expect(asked, "Undo changes did not ask first") ?? Expect(restored, "Undo changes did not put the file back");
                });
                await Step("Changes → Compare branches lists the branches and compares two", async () =>
                {
                    var tree = workspace.Tree;
                    tree.Tab = "changes";
                    RunGit(workspace.Record.Path, "branch", "-f", "walk-compare");
                    tree.IsComparing = true;
                    await WaitAsync(() => tree.Branches.Contains("walk-compare"), 10);
                    var listed = tree.Branches.Contains("walk-compare");
                    tree.CompareBase = "walk-compare";
                    tree.CompareTarget = tree.Branches.FirstOrDefault(b => b != "walk-compare");
                    await Settle(300);
                    var problem = await Click("Compare the branches");
                    await WaitAsync(() => !tree.CompareSummary.StartsWith("Comparing", StringComparison.Ordinal) && tree.CompareSummary.Length > 0, 10);
                    await CaptureRunner.Shoot(_window, _folder, "feature-compare-branches", () => { }, 100);
                    var summary = tree.CompareSummary;
                    tree.IsComparing = false;
                    tree.Tab = "files";
                    RunGit(workspace.Record.Path, "branch", "-D", "walk-compare");
                    return problem ?? Expect(listed, "the branches are not listed") ?? Expect(summary.Contains("changes nothing", StringComparison.Ordinal), $"the comparison said: {summary}");
                });
            }
            finally
            {
                File.WriteAllText(full, before);
            }
        }

        static void RunGit(string root, params string[] args)
        {
            var info = new System.Diagnostics.ProcessStartInfo("git") { WorkingDirectory = root, UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true };
            foreach (var a in args)
            {
                info.ArgumentList.Add(a);
            }
            using var p = System.Diagnostics.Process.Start(info);
            p?.WaitForExit(10000);
        }

        // ----- The window layout: panels docked anywhere, floated, saved, locked and reset -----
        if (_window is MainWindow shell)
        {
            await Step("Layout → the assistant docks below the page, the files list floats in its own window, and Reset puts them back", async () =>
            {
                var main = (MainViewModel)_window.DataContext;
                var dock = shell.Dock;
                main.DockPanelCommand.Execute("bottom:ask");
                await Settle(500);
                var ask = dock.ViewOf(Infrastructure.Docking.DockLayout.Ask);
                var page = dock.ViewOf(Infrastructure.Docking.DockLayout.Viewport);
                var below = ask is { IsVisible: true } && page is { IsVisible: true }
                            && ask.TranslatePoint(new Point(0, 0), _window).Y > page.TranslatePoint(new Point(0, 0), _window).Y + 40;
                await CaptureRunner.Shoot(_window, _folder, "feature-layout-ask-below", () => { }, 100);
                main.DockPanelCommand.Execute("float:files");
                await Settle(700);
                var floating = Application.Current.Windows.OfType<Window>().Any(w => w != _window && w.IsVisible && w.Title.Contains("Repository", StringComparison.Ordinal));
                await CaptureRunner.Shoot(_window, _folder, "feature-layout-floating", () => { }, 100);
                await Settle(900); // the layout is saved a moment after the change
                var file = Path.Combine(main.Engine.Store.Root, "settings", "layout.json");
                var saved = File.Exists(file) && File.ReadAllText(file).Contains("\"floats\"", StringComparison.Ordinal);
                main.ToggleLayoutLockCommand.Execute(null);
                await Settle(200);
                var locked = dock.Layout.Locked;
                main.ToggleLayoutLockCommand.Execute(null);
                main.ResetLayoutCommand.Execute(null);
                await Settle(600);
                var reset = !dock.Layout.IsFloating(Infrastructure.Docking.DockLayout.Files) && dock.Layout.SideOfViewport(Infrastructure.Docking.DockLayout.Ask) == 1
                            && Application.Current.Windows.OfType<Window>().All(w => w == _window || !w.IsVisible || !w.Title.Contains("Repository", StringComparison.Ordinal));
                return Expect(below, "the assistant is not below the page") ?? Expect(floating, "no floating window for the files list")
                       ?? Expect(saved, "the layout was not saved to layout.json") ?? Expect(locked, "Lock did not lock") ?? Expect(reset, "Reset did not restore the standard layout");
            });
        }

        // ----- A floating panel maximised fits the screen above the taskbar -----
        if (_window is MainWindow floatShell)
        {
            await Step("Layout → a floating panel maximised stays above the taskbar (its bottom is not hidden)", async () =>
            {
                var main = (MainViewModel)_window.DataContext;
                main.DockPanelCommand.Execute("float:ask");
                await Settle(700);
                var floating = Application.Current.Windows.OfType<Window>().FirstOrDefault(w => w != _window && w.IsVisible && w.Title.Contains("Assistant", StringComparison.Ordinal));
                if (floating is null)
                {
                    main.ResetLayoutCommand.Execute(null);
                    return "no floating window for the assistant";
                }
                floating.WindowState = WindowState.Maximized;
                await Settle(600);
                // Where the window really is (Top and Left keep the restore position while it is maximised).
                var work = SystemParameters.WorkArea;
                var content = (FrameworkElement)floating.Content;
                var scale = PresentationSource.FromVisual(floating)?.CompositionTarget?.TransformFromDevice.M22 ?? 1;
                var top = content.PointToScreen(new Point(0, 0)).Y * scale;
                var bottom = content.PointToScreen(new Point(0, content.ActualHeight)).Y * scale;
                var fits = bottom <= work.Bottom + 2 && top >= work.Top - 2;
                var size = $"content from {top:0} to {bottom:0}; work area {work.Top:0} to {work.Bottom:0}";
                floating.WindowState = WindowState.Normal;
                main.ResetLayoutCommand.Execute(null);
                await Settle(500);
                return Expect(fits, "it goes under the taskbar: " + size);
            });
        }

        // ----- Tabs rearranged: the header's sections, kept in the layout and put back by Reset -----
        if (_window is MainWindow tabsShell && tabsShell.FindName("Sections") is StackPanel sections)
        {
            await Step("Tabs → Graph moves before Documentation in the header; the order is saved, and Reset window layout puts it back", async () =>
            {
                var main = (MainViewModel)_window.DataContext;
                var graph = sections.Children.OfType<UIElement>().FirstOrDefault(c => Infrastructure.TabReorder.GetId(c) == "graph");
                if (graph is null)
                {
                    return "no Graph tab in the header";
                }
                var moved = Infrastructure.TabReorder.Shift(sections, graph, -1);
                await Settle(900);
                var order = Infrastructure.TabReorder.OrderOf(sections);
                var first = order.FirstOrDefault();
                await CaptureRunner.Shoot(_window, _folder, "feature-tabs-rearranged", () => { }, 100);
                var file = Path.Combine(main.Engine.Store.Root, "settings", "layout.json");
                var saved = File.Exists(file) && File.ReadAllText(file).Contains("header-sections", StringComparison.Ordinal);
                main.ResetLayoutCommand.Execute(null);
                await Settle(500);
                var back = Infrastructure.TabReorder.OrderOf(sections).FirstOrDefault();
                return Expect(moved, "the tab did not move") ?? Expect(first == "graph", $"first is {first}") ?? Expect(saved, "the order was not saved in layout.json")
                       ?? Expect(back == "documentation", $"after Reset the first is {back}");
            });
        }

        // ----- Files: a C# file — select, copy, find, class diagram, details -----
        var csharp = workspace.Index.Files.Where(f => f.Path.EndsWith(".cs", StringComparison.OrdinalIgnoreCase))
            .FirstOrDefault(f => Engine.Code.FileClassDiagram.HasTypes(workspace.Index.Code, f.Path));
        if (csharp is not null)
        {
            workspace.Documentation.OpenFile(csharp.Path, 0);
            await Settle(800);
            await Step("Files → code can be selected (all, or a word, as with a double-click) and copied", async () =>
            {
                var view = DocsView();
                if (view is null)
                {
                    return "no file shown";
                }
                view.Code.SelectAll();
                await Settle(200);
                await CaptureRunner.Shoot(_window, _folder, "feature-code-selected", () => { }, 100);
                var selected = view.Code.SelectedText;
                var text = string.Join("\n", workspace.Documentation.Lines);
                var marked = CaptureRunner.FindAll<CodeTextBlock>(view.Code).Any(b => b.IsVisible && b.Marks is { Count: > 0 });
                view.Code.Copy();
                await Settle(200);
                var copied = Clipboard.ContainsText() ? Clipboard.GetText().Replace("\r\n", "\n", StringComparison.Ordinal) : "";
                view.Code.ClearSelection();
                return Expect(selected == text, $"Select all took {selected.Length} of {text.Length} characters")
                       ?? Expect(marked, "the selection is not shown")
                       ?? Expect(copied == text, "Ctrl+C did not copy the selection");
            });
            await Step("Files → Find in a file marks the matches and goes to them", async () =>
            {
                var view = DocsView();
                if (view is null)
                {
                    return "no file shown";
                }
                view.OpenFind("class");
                await Settle(500);
                var matches = view.Code.Matches.Count;
                var current = view.Code.CurrentMatch;
                view.FindBox.RaiseEvent(new KeyEventArgs(Keyboard.PrimaryDevice, PresentationSource.FromVisual(view.FindBox)!, 0, Key.Escape) { RoutedEvent = UIElement.PreviewKeyDownEvent });
                await Settle(200);
                return Expect(matches > 0, "no match of 'class' in a C# file") ?? Expect(current >= 0, "no current match");
            });
            await Step("Files → a C# file with classes shows its class diagram, and the code again", async () =>
            {
                var docs = workspace.Documentation;
                var problem = Expect(docs.CanShowClassDiagram, "no class diagram offered") ?? await Click("Class diagram");
                if (problem is not null)
                {
                    return problem;
                }
                await Settle(400);
                var markdown = docs.ClassDiagramMarkdown ?? "";
                await WaitAsync(() => CaptureRunner.FindAll<MermaidView>(_window).Any(m => m.IsVisible), 10);
                var drawn = CaptureRunner.FindAll<MermaidView>(_window).Any(m => m.IsVisible);
                await Settle(800);
                await CaptureRunner.Shoot(_window, _folder, "feature-class-diagram", () => { }, 100);
                docs.ShowClassDiagram = false;
                await Settle(300);
                return Expect(markdown.Contains("classDiagram", StringComparison.Ordinal), "the diagram has no classDiagram")
                       ?? Expect(drawn, "the diagram is not drawn") ?? Expect(DocsView()?.Code.IsVisible == true, "the code did not come back");
            });
            await Step("Docs → a file's tooltip lists its details: size, lines, created and modified", () =>
            {
                var node = workspace.Tree.FilesRoots.SelectMany(n => n.Descendants().Prepend(n)).FirstOrDefault(n => n.Path == csharp.Path);
                if (node is null)
                {
                    return "the file is not in the Files list";
                }
                var labels = node.Details.Select(r => r.Label).ToList();
                return Expect(new[] { "Size", "Lines", "Modified", "Created", "Encoding" }.All(labels.Contains), "the details have only " + string.Join(", ", labels));
            });
        }
        else
        {
            Record("Files → a C# file with classes", false, "the sample has no C# file with types");
        }

        // ----- Docs: add, edit, preview, save, rename, delete -----
        await Step("Docs → New file asks for a name, creates it and opens it in the editor; Save writes it; Preview renders it", async () =>
        {
            var create = workspace.Tree.NewFileAsync(null);
            await WaitAsync(() => _main.Dialog is not null, 5);
            if (_main.Dialog is null)
            {
                return "no name was asked for";
            }
            _main.Dialog.Input = "walk-notes.md";
            var problem = await Click("Create");
            await create;
            await Settle(500);
            var docs = workspace.Documentation;
            var path = Path.Combine(root, "walk-notes.md");
            problem ??= Expect(File.Exists(path), "the file was not created") ?? Expect(docs.Mode == "edit", $"the editor did not open ({docs.Mode})");
            if (problem is not null)
            {
                return problem;
            }
            docs.EditorText = "# Walk notes\n\nWritten by the **UI walk**.\n";
            docs.SaveEditCommand.Execute(null);
            await Settle(500);
            var saved = File.ReadAllText(path).Replace("\r\n", "\n", StringComparison.Ordinal);
            docs.EditTab = "preview";
            await Settle(500);
            await CaptureRunner.Shoot(_window, _folder, "feature-editor-preview", () => { }, 100);
            var preview = DocsView()?.EditPreview.Document is { } d ? new TextRange(d.ContentStart, d.ContentEnd).Text : "";
            docs.EditTab = "edit";
            docs.CloseEditCommand.Execute(null);
            await Settle(400);
            return Expect(saved.Contains("Written by the **UI walk**.", StringComparison.Ordinal), "Save did not write the text")
                   ?? Expect(preview.Contains("Walk notes", StringComparison.Ordinal) && preview.Contains("UI walk", StringComparison.Ordinal), "the preview does not show the text")
                   ?? Expect(docs.Mode != "edit", "the editor did not close");
        });
        await Step("Docs → closing the editor with unsaved changes asks first", async () =>
        {
            var docs = workspace.Documentation;
            docs.BeginEdit("walk-notes.md");
            await Settle(300);
            docs.EditorText += "more";
            var closing = docs.CloseEditAsync();
            await WaitAsync(() => _main.Dialog is not null, 5);
            var asked = _main.Dialog is not null;
            var problem = Expect(asked, "it closed without asking") ?? await Click("Discard");
            await closing;
            await Settle(300);
            return problem ?? Expect(docs.Mode != "edit", "Discard did not close the editor")
                   ?? Expect(!File.ReadAllText(Path.Combine(root, "walk-notes.md")).Contains("more", StringComparison.Ordinal), "the discarded text was saved");
        });
        await Step("Docs → Rename and Delete a file (it goes to the Recycle Bin)", async () =>
        {
            var tree = workspace.Tree;
            var node = tree.FilesRoots.FirstOrDefault(n => n.Path == "walk-notes.md");
            if (node is null)
            {
                return "the new file is not in the Files list";
            }
            var rename = tree.RenameAsync(node);
            await WaitAsync(() => _main.Dialog is not null, 5);
            if (_main.Dialog is null)
            {
                return "Rename asked nothing";
            }
            _main.Dialog.Input = "walk-renamed.md";
            var problem = await Click("Rename");
            await rename;
            await Settle(300);
            problem ??= Expect(File.Exists(Path.Combine(root, "walk-renamed.md")) && !File.Exists(Path.Combine(root, "walk-notes.md")), "the file was not renamed");
            var renamed = tree.FilesRoots.FirstOrDefault(n => n.Path == "walk-renamed.md");
            if (problem is not null || renamed is null)
            {
                return problem ?? "the renamed file is not listed";
            }
            var delete = tree.DeleteAsync(renamed);
            await WaitAsync(() => _main.Dialog is not null, 5);
            problem = Expect(_main.Dialog is not null, "Delete did not ask first") ?? await Click("Delete");
            await delete;
            await Settle(400);
            return problem ?? Expect(!File.Exists(Path.Combine(root, "walk-renamed.md")), "the file was not deleted")
                   ?? Expect(tree.FilesRoots.All(n => n.Path != "walk-renamed.md"), "the deleted file is still listed");
        });

        // ----- Ask: paste, cards, spelling, search, reading while answering -----
        var ask = workspace.Assistant;
        _main.Navigate(Section.Documentation);
        _main.AssistantVisible = true;
        await Settle(500);
        await Step("Ask → pasting JSON, a picture or long text attaches them as square cards with their name and size; short text is typed", async () =>
        {
            var pane = CaptureRunner.FindAll<AssistantPane>(_window).FirstOrDefault(p => p.IsVisible);
            if (pane is null)
            {
                return "Ask is not shown";
            }
            ask.PendingAttachments.Clear();
            ask.Input = "";
            Clipboard.SetText("{ \"orders\": [ { \"id\": 1, \"total\": 9.5 } ] }");
            ApplicationCommands.Paste.Execute(null, pane.InputBox);
            await Settle(400);
            var bitmap = new RenderTargetBitmap(64, 48, 96, 96, PixelFormats.Pbgra32);
            var visual = new DrawingVisual();
            using (var dc = visual.RenderOpen())
            {
                dc.DrawRectangle(Brushes.SteelBlue, null, new Rect(0, 0, 64, 48));
            }
            bitmap.Render(visual);
            Clipboard.SetImage(bitmap);
            ApplicationCommands.Paste.Execute(null, pane.InputBox);
            await Settle(500);
            Clipboard.SetText(string.Join("\n", Enumerable.Range(1, 12).Select(i => $"line {i} of a pasted log")));
            ApplicationCommands.Paste.Execute(null, pane.InputBox);
            await Settle(400);
            Clipboard.SetText("short words");
            ApplicationCommands.Paste.Execute(null, pane.InputBox);
            await Settle(300);
            await CaptureRunner.Shoot(_window, _folder, "feature-attachment-cards", () => { }, 100);
            var names = ask.PendingAttachments.Select(a => a.Name).ToList();
            var cards = CaptureRunner.FindAll<Border>(pane).Where(b => b.Name == "Card" && b.IsVisible).ToList();
            var picture = ask.PendingAttachments.FirstOrDefault(a => a.Name.EndsWith(".png", StringComparison.Ordinal));
            var problem = Expect(names.Contains("Pasted text 1.json"), "the JSON was not attached: " + string.Join(", ", names))
                          ?? Expect(picture is { HasThumbnail: true }, "the picture was not attached with a preview")
                          ?? Expect(names.Any(n => n.StartsWith("Pasted text 2", StringComparison.Ordinal)), "the long text was not attached")
                          ?? Expect(ask.Input.Contains("short words", StringComparison.Ordinal), "short text did not go into the box")
                          ?? Expect(cards.Count == 3 && cards.All(c => Math.Abs(c.ActualWidth - c.ActualHeight) < 1), "the cards are not square")
                          ?? Expect(ask.PendingAttachments.All(a => a.CardDetail.Length > 0 && a.ToolTip.Contains(a.Name, StringComparison.Ordinal)), "a card has no size or tooltip");
            ask.PendingAttachments.Clear();
            ask.Input = "";
            Clipboard.Clear();
            return problem;
        });
        await Step("Ask → spelling mistakes are underlined, with corrections", async () =>
        {
            var pane = CaptureRunner.FindAll<AssistantPane>(_window).FirstOrDefault(p => p.IsVisible);
            if (pane is null)
            {
                return "Ask is not shown";
            }
            ask.Input = "Where is the questoin answred";
            await Settle(800);
            var box = pane.InputBox;
            await CaptureRunner.Shoot(_window, _folder, "feature-spelling", () => { }, 100);
            var at = box.GetNextSpellingErrorCharacterIndex(0, LogicalDirection.Forward);
            var suggestions = at >= 0 ? box.GetSpellingError(at)?.Suggestions.ToList() ?? [] : [];
            ask.Input = "";
            return Expect(SpellCheck.GetIsEnabled(box), "spell check is off") ?? Expect(at >= 0, "no mistake was found")
                   ?? Expect(suggestions.Contains("question"), "no correction offered: " + string.Join(", ", suggestions));
        });
        await Step("Ask → search marks the words in the conversation and goes from message to message", async () =>
        {
            var word = ask.Messages.Where(m => m.IsUser).Select(m => CommonWord(m.Text)).FirstOrDefault(w => w is not null);
            if (word is null)
            {
                return "no question to search";
            }
            var problem = await Click("Open the conversation search") ?? Expect(ask.IsSearchOpen, "the search did not open");
            ask.SearchText = word;
            await ask.ApplySearchAsync();
            await Settle(500);
            await CaptureRunner.Shoot(_window, _folder, "feature-ask-search", () => { }, 100);
            var status = ask.SearchStatus;
            var marked = ask.Messages.Count(m => m.SearchQuery is not null);
            var drawn = CaptureRunner.FindAll<FrameworkElement>(_window).Any(e => e.IsVisible && TextHighlight.GetQuery(e) is { Length: > 0 } && FindHighlightAdorner.For(e, create: false) is not null);
            ask.IsSearchOpen = false;
            await Settle(200);
            return problem ?? Expect(status.Contains(" of ", StringComparison.Ordinal), $"the status reads '{status}'")
                   ?? Expect(marked > 0, "no message marked") ?? Expect(drawn, "no yellow marks drawn")
                   ?? Expect(ask.Messages.All(m => m.SearchQuery is null), "closing the search left marks");
        });
        await Step("Ask → while an answer is written the thread can be scrolled up, and stays there", async () =>
        {
            var thread = CaptureRunner.FindAll<ScrollViewer>(_window).First(v => v.Name == "Thread" && v.IsVisible);
            ask.Input = "What does this repository contain?";
            ask.SendCommand.Execute(null);
            await Settle(150);
            thread.ScrollToTop();
            await WaitAsync(() => !ask.IsBusy, 60);
            await Settle(500);
            return thread.ScrollableHeight < 100 ? null : Expect(thread.VerticalOffset < thread.ScrollableHeight - 40, "the thread jumped back to the end");
        });

        // ----- Logs -----
        await Step("Logs → the log is listed, newest first, in pages; level, words, time and column filters narrow it; columns hide and show", async () =>
        {
            Logging.Info("UI walk marker for the log viewer");
            var problem = await Click("Menu") ?? await Click("Logs");
            if (problem is not null)
            {
                return problem;
            }
            await Settle(800);
            var logs = _main.Logs;
            var all = logs.Rows.Count;
            logs.Search = "UI walk marker";
            await Settle(500);
            var found = logs.Rows.Count > 0 && logs.Rows.All(r => r.Entry.Full.Contains("UI walk marker", StringComparison.Ordinal));
            logs.Search = "";
            logs.Range = "Today";
            await Settle(300);
            var today = logs.Rows.All(r => r.Entry.Time.Date == DateTime.Today);
            logs.Range = "All time";
            foreach (var level in logs.LevelChoices)
            {
                level.IsChecked = level.Level == "ERROR";
            }
            await Settle(300);
            var errorsOnly = logs.Rows.All(r => r.Level == "ERROR");
            logs.ClearFiltersCommand.Execute(null);
            var view = CaptureRunner.FindAll<LogsView>(_window).FirstOrDefault(v => v.IsVisible);
            var before = view?.Grid.Columns.Count ?? 0;
            logs.Columns.First(c => c.Key == "exception").IsVisible = false;
            await Settle(200);
            var after = view?.Grid.Columns.Count ?? 0;
            logs.Columns.First(c => c.Key == "exception").IsVisible = true;
            logs.PageSize = 50;
            await Settle(300);
            // A custom range, with the date and time picker open (in the app's own look).
            logs.Range = "Custom";
            logs.From = DateTime.Today;
            await Settle(400);
            var custom = logs.Rows.All(r => r.Entry.Time >= DateTime.Today);
            var picker = CaptureRunner.FindAll<DateTimePicker>(_window).FirstOrDefault(p => p.IsVisible);
            await CaptureRunner.Shoot(_window, _folder, "feature-logs", () => { }, 100);
            if (picker is not null)
            {
                picker.IsOpen = true;
                await Settle(500);
                await CaptureRunner.Shoot(_window, _folder, "feature-date-picker", () => { }, 100);
                picker.IsOpen = false;
            }
            logs.ClearFiltersCommand.Execute(null);
            await Settle(300);
            if (!custom || picker is null)
            {
                return picker is null ? "no date and time picker for a custom range" : "the custom range let older entries through";
            }
            return Expect(all > 0, "the log is empty") ?? Expect(found, "the search did not find the marker")
                   ?? Expect(today, "Today shows older entries") ?? Expect(errorsOnly, "the level filter let other levels through")
                   ?? Expect(view is not null && after == before - 1, $"hiding a column left {after} of {before}")
                   ?? Expect(logs.Rows.Count <= 50, "a page has more rows than set");
        });
        await Step("Logs → auto refresh shows a new entry by itself", async () =>
        {
            var logs = _main.Logs;
            logs.RefreshSeconds = 2;
            logs.Search = "auto refresh probe";
            logs.AutoRefresh = true;
            await Settle(300);
            Logging.Info("auto refresh probe " + Guid.NewGuid().ToString("N")[..6]);
            await WaitAsync(() => logs.Rows.Count > 0, 8);
            var seen = logs.Rows.Count > 0;
            logs.AutoRefresh = false;
            logs.Search = "";
            logs.RefreshSeconds = 5;
            return Expect(seen, "the new entry did not appear");
        });

        // ----- Settings and the Repositories page -----
        await Step("Settings → Reading and writing opens and keeps what is chosen", async () =>
        {
            _main.Navigate(Section.Settings);
            await Settle(400);
            var problem = await Click("Reading and writing");
            await Settle(300);
            var shown = CaptureRunner.FindAll<TextBlock>(_window).Any(t => t.IsVisible && t.Text == "One notch scrolls");
            var lines = UiPreferences.Current.WheelLines;
            UiPreferences.Current.WheelLines = 3;
            await Settle(600);
            var saved = (await _main.Engine.Models.GetExplorerSettingsAsync()).WheelLines;
            UiPreferences.Current.WheelLines = lines;
            await Settle(300);
            return problem ?? Expect(shown, "the page did not open") ?? Expect(Math.Abs(saved - 3) < 0.01, $"the setting was not saved ({saved})");
        });
        await Step("Repositories → \"Open its graph\" shows the graph icon (linked nodes)", async () =>
        {
            _main.Navigate(Section.Repositories);
            await Settle(500);
            var button = CaptureRunner.FindAll<Button>(_window).FirstOrDefault(b => b.IsVisible && b.ToolTip as string == "Open its graph");
            return Expect(button is not null, "no graph button") ?? Expect(button!.Content as string == Icons.Graph && Icons.Graph == "", "the graph button has another icon");
        });
        _main.Navigate(Section.Documentation);
        await Settle(400);
    }

    private DocumentationView? DocsView() => CaptureRunner.FindAll<DocumentationView>(_window).FirstOrDefault(v => v.IsVisible);

    /// <summary>A word of at least five letters that appears more than once (something worth finding).</summary>
    private static string? CommonWord(string text)
        => System.Text.RegularExpressions.Regex.Matches(text, "[A-Za-z]{5,}").Select(m => m.Value.ToLowerInvariant())
            .GroupBy(w => w).OrderByDescending(g => g.Count()).Select(g => g.Key).FirstOrDefault();
}
