using System.Globalization;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using DocGen.Explorer.Engine.Export;
using DocGen.Explorer.Engine.Graph;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.Controls;

/// <summary>
/// Draws a knowledge graph as cards and curved, arrowed edges. Wheel zooms at the cursor, dragging the background pans,
/// dragging a card moves it, a click selects (its edges light up, the rest fades), a double-click or Enter opens it, Tab
/// and Shift+Tab walk the concepts, arrows pan, + and − zoom, Home fits the view.
/// </summary>
public sealed class GraphCanvas : FrameworkElement
{
    private KnowledgeGraph _graph = new();
    private Dictionary<string, Point> _positions = new(StringComparer.Ordinal);
    private readonly Dictionary<string, (FormattedText Label, FormattedText Type)> _text = new(StringComparer.Ordinal);
    private double _scale = 1;

    /// <summary>Below this zoom the names are too small to read and are not drawn.</summary>
    public const double LabelScale = 0.32;
    private Vector _offset = new(20, 20);
    private Point? _panStart;
    private Vector _panOrigin;
    private string? _dragNode;
    private Point _dragStart;
    private Point _dragNodeOrigin;
    private bool _dragged;
    private HashSet<string> _highlight = new(StringComparer.Ordinal);

    public GraphCanvas()
    {
        Focusable = true;
        FocusVisualStyle = null;
        ClipToBounds = true;
        Cursor = Cursors.Arrow;
        ThemeManager.Changed += (_, _) =>
        {
            _text.Clear();
            InvalidateVisual();
        };
    }

    /// <summary>Smaller cards for diagrams embedded in documents.</summary>
    public bool Compact { get; set; }

    public string? SelectedId { get; private set; }

    public event EventHandler<GraphNode?>? NodeSelected;
    public event EventHandler<GraphNode>? NodeActivated;

    public double Scale => _scale;

    public KnowledgeGraph Graph => _graph;

    public IReadOnlyDictionary<string, NodePosition> Positions => _positions.ToDictionary(p => p.Key, p => new NodePosition(p.Key, p.Value.X, p.Value.Y));

    private double W => Compact ? 160 : GraphLayout.NodeWidth;
    private double H => Compact ? 44 : GraphLayout.NodeHeight;

    public void SetGraph(KnowledgeGraph graph, IReadOnlyDictionary<string, NodePosition> positions)
    {
        _graph = graph;
        var scaleX = Compact ? W / GraphLayout.NodeWidth : 1;
        _positions = positions.ToDictionary(p => p.Key, p => new Point(p.Value.X * scaleX, p.Value.Y * (Compact ? H / GraphLayout.NodeHeight : 1)), StringComparer.Ordinal);
        _text.Clear();
        if (SelectedId is not null && graph.Find(SelectedId) is null)
        {
            SelectedId = null;
        }
        UpdateHighlight();
        InvalidateVisual();
    }

    public void Select(string? id, bool center = false)
    {
        SelectedId = id is not null && _positions.ContainsKey(id) ? id : null;
        UpdateHighlight();
        if (center && SelectedId is not null)
        {
            CenterOn(SelectedId);
        }
        InvalidateVisual();
        NodeSelected?.Invoke(this, SelectedId is null ? null : _graph.Find(SelectedId));
    }

    private void UpdateHighlight()
    {
        _highlight = SelectedId is null ? [] : _graph.Neighbours(SelectedId).Append(SelectedId).ToHashSet(StringComparer.Ordinal);
    }

    public void CenterOn(string id)
    {
        if (!_positions.TryGetValue(id, out var p))
        {
            return;
        }
        if (_scale < 0.7)
        {
            _scale = 0.9;
        }
        _offset = new Vector(ActualWidth / 2 - (p.X + W / 2) * _scale, ActualHeight / 2 - (p.Y + H / 2) * _scale);
        InvalidateVisual();
    }

    public void FitView()
    {
        if (_positions.Count == 0 || ActualWidth < 10 || ActualHeight < 10)
        {
            return;
        }
        var minX = _positions.Values.Min(p => p.X);
        var minY = _positions.Values.Min(p => p.Y);
        var maxX = _positions.Values.Max(p => p.X) + W;
        var maxY = _positions.Values.Max(p => p.Y) + H;
        const double margin = 30;
        _scale = Math.Clamp(Math.Min((ActualWidth - 2 * margin) / Math.Max(1, maxX - minX), (ActualHeight - 2 * margin) / Math.Max(1, maxY - minY)), 0.08, 1.4);
        _offset = new Vector((ActualWidth - (maxX - minX) * _scale) / 2 - minX * _scale, (ActualHeight - (maxY - minY) * _scale) / 2 - minY * _scale);
        InvalidateVisual();
    }

    public void Zoom(double factor, Point? around = null)
    {
        var center = around ?? new Point(ActualWidth / 2, ActualHeight / 2);
        var newScale = Math.Clamp(_scale * factor, 0.05, 3);
        var world = new Point((center.X - _offset.X) / _scale, (center.Y - _offset.Y) / _scale);
        _scale = newScale;
        _offset = new Vector(center.X - world.X * _scale, center.Y - world.Y * _scale);
        InvalidateVisual();
    }

    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo)
    {
        base.OnRenderSizeChanged(sizeInfo);
        InvalidateVisual();
    }

    private Brush Res(string key, Brush fallback) => TryFindResource(key) as Brush ?? fallback;

    private static SolidColorBrush Hex(string hex)
    {
        var brush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(hex));
        brush.Freeze();
        return brush;
    }

    private static Color Blend(Color a, Color b, double t)
        => Color.FromRgb((byte)(a.R + (b.R - a.R) * t), (byte)(a.G + (b.G - a.G) * t), (byte)(a.B + (b.B - a.B) * t));

    private (Brush Fill, Pen Stroke, Brush Accent, Brush Text, Brush Sub) NodeBrushes(string type, bool selected)
    {
        var (fill, stroke, accent) = ConceptPalette.Of(type);
        var fillColor = (Color)ColorConverter.ConvertFromString(fill);
        var strokeColor = (Color)ColorConverter.ConvertFromString(stroke);
        var accentColor = (Color)ColorConverter.ConvertFromString(accent);
        var isRepository = type == ConceptTypes.Repository;
        if (ThemeManager.IsDark && !isRepository)
        {
            var dark = Color.FromRgb(0x30, 0x30, 0x2E); // the dark theme's panel colour
            fillColor = Blend(dark, strokeColor, 0.16);
            strokeColor = Blend(dark, strokeColor, 0.55);
            accentColor = Blend(accentColor, Colors.White, 0.35);
        }
        var text = isRepository ? Brushes.White : Res("Brush.Text", Brushes.Black);
        var sub = isRepository ? Hex("#E2E5E4") : Res("Brush.TextMuted", Brushes.Gray);
        var pen = new Pen(new SolidColorBrush(selected ? (Color)FindResource("Color.Accent") : strokeColor), selected ? 2.4 : 1.1);
        pen.Freeze();
        return (new SolidColorBrush(fillColor), pen, new SolidColorBrush(accentColor), text, sub);
    }

    protected override void OnRender(DrawingContext dc)
    {
        dc.DrawRectangle(Res(Compact ? "Brush.SurfaceAlt" : "Brush.Window", Brushes.White), null, new Rect(RenderSize));
        if (_graph.Nodes.Count == 0)
        {
            return;
        }
        dc.PushTransform(new TranslateTransform(_offset.X, _offset.Y));
        dc.PushTransform(new ScaleTransform(_scale, _scale));
        var dpi = VisualTreeHelper.GetDpi(this).PixelsPerDip;
        var hasSelection = SelectedId is not null;

        // Visible world rectangle, to skip what is off screen.
        var view = new Rect(-_offset.X / _scale - W, -_offset.Y / _scale - H, ActualWidth / _scale + 2 * W, ActualHeight / _scale + 2 * H);

        foreach (var edge in _graph.Edges)
        {
            if (!_positions.TryGetValue(edge.From, out var a) || !_positions.TryGetValue(edge.To, out var b))
            {
                continue;
            }
            if (!view.Contains(a) && !view.Contains(b))
            {
                continue;
            }
            var lit = hasSelection && (edge.From == SelectedId || edge.To == SelectedId);
            var color = (Color)ColorConverter.ConvertFromString(ConceptPalette.EdgeColor(edge.Kind));
            var opacity = hasSelection ? (lit ? 1 : 0.12) : 0.62;
            var brush = new SolidColorBrush(color) { Opacity = opacity };
            var pen = new Pen(brush, lit ? 2 : 1.15);
            var (x1, y1, x2, y2) = SvgGraphWriter.Anchors(new NodePosition(edge.From, a.X, a.Y), new NodePosition(edge.To, b.X, b.Y), W, H);
            var start = new Point(x1, y1);
            var end = new Point(x2, y2);
            var mid = new Point((x1 + x2) / 2, (y1 + y2) / 2 - Math.Min(40, Math.Abs(x2 - x1) * 0.08));
            var geometry = new StreamGeometry();
            using (var ctx = geometry.Open())
            {
                ctx.BeginFigure(start, false, false);
                ctx.QuadraticBezierTo(mid, end, true, false);
            }
            geometry.Freeze();
            dc.DrawGeometry(null, pen, geometry);
            // Arrow head along the curve's final tangent.
            var dir = end - mid;
            if (dir.Length > 0.01)
            {
                dir.Normalize();
                var normal = new Vector(-dir.Y, dir.X);
                var tip = end;
                var left = tip - dir * 8 + normal * 4;
                var right = tip - dir * 8 - normal * 4;
                var head = new StreamGeometry();
                using (var ctx = head.Open())
                {
                    ctx.BeginFigure(tip, true, true);
                    ctx.LineTo(left, false, false);
                    ctx.LineTo(right, false, false);
                }
                head.Freeze();
                dc.DrawGeometry(brush, null, head);
            }
            if (lit && !Compact && _scale > 0.55)
            {
                var label = Text(edge.Kind, 10, Res("Brush.TextMuted", Brushes.Gray), dpi, FontWeights.Normal);
                dc.DrawRectangle(Res("Brush.Window", Brushes.White), null, new Rect(mid.X - label.Width / 2 - 3, mid.Y - label.Height / 2, label.Width + 6, label.Height));
                dc.DrawText(label, new Point(mid.X - label.Width / 2, mid.Y - label.Height / 2));
            }
        }

        foreach (var node in _graph.Nodes)
        {
            if (!_positions.TryGetValue(node.Id, out var p) || !view.Contains(p))
            {
                continue;
            }
            var selected = node.Id == SelectedId;
            var faded = hasSelection && !_highlight.Contains(node.Id);
            if (faded)
            {
                dc.PushOpacity(0.28);
            }
            var (fill, stroke, accent, textBrush, subBrush) = NodeBrushes(node.Type, selected);
            var rect = new Rect(p.X, p.Y, W, H);
            dc.DrawRoundedRectangle(fill, stroke, rect, 8, 8);
            // Icon tile with an accent dot.
            var tile = new Rect(p.X + 10, p.Y + (H - 24) / 2, 24, 24);
            var tileFill = node.Type == ConceptTypes.Repository ? Hex("#46514F") : Res("Brush.Surface", Brushes.White);
            dc.DrawRoundedRectangle(tileFill, new Pen(stroke.Brush, 0.8), tile, 6, 6);
            dc.DrawEllipse(accent, null, new Point(tile.X + 12, tile.Y + 12), 4.5, 4.5);
            if (_scale > LabelScale || Compact)
            {
                var (label, type) = Labels(node, textBrush, subBrush, dpi);
                dc.DrawText(label, new Point(p.X + 44, p.Y + H / 2 - label.Height + 1));
                dc.DrawText(type, new Point(p.X + 44, p.Y + H / 2 + 1));
                if (!Compact && node.Path is not null)
                {
                    var open = Text("↗", 10, subBrush, dpi, FontWeights.Normal);
                    dc.DrawText(open, new Point(p.X + W - 14, p.Y + 4));
                }
            }
            if (faded)
            {
                dc.Pop();
            }
        }
        dc.Pop();
        dc.Pop();
        if (!Compact && _scale <= LabelScale)
        {
            // Names are too small to draw at this size: say so, rather than show cards that look empty.
            var hint = Text("Zoom in (+ or the mouse wheel) to read the names; point at a card to see it.", 11.5, Res("Brush.TextMuted", Brushes.Gray), dpi, FontWeights.Normal);
            var box = new Rect((ActualWidth - hint.Width) / 2 - 12, 14, hint.Width + 24, hint.Height + 10);
            dc.DrawRoundedRectangle(Res("Brush.Surface", Brushes.White), new Pen(Res("Brush.Border", Brushes.LightGray), 1), box, 8, 8);
            dc.DrawText(hint, new Point(box.X + 12, box.Y + 5));
        }
    }

    private (FormattedText Label, FormattedText Type) Labels(GraphNode node, Brush text, Brush sub, double dpi)
    {
        if (_text.TryGetValue(node.Id, out var cached))
        {
            return cached;
        }
        var label = Text(TextUtil.Truncate(node.Label, Compact ? 19 : 22), Compact ? 11.5 : 12, text, dpi, FontWeights.SemiBold);
        label.MaxTextWidth = W - 52;
        label.Trimming = TextTrimming.CharacterEllipsis;
        label.MaxLineCount = 1;
        // A group card says how big it is ("30 concepts · 44% of links inside") rather than "Group".
        var type = Text(node.Type == ConceptTypes.Group && node.Description is { Length: > 0 } size ? size : node.Type, 10, sub, dpi, FontWeights.Normal);
        type.MaxTextWidth = W - 52;
        type.MaxLineCount = 1;
        type.Trimming = TextTrimming.CharacterEllipsis;
        _text[node.Id] = (label, type);
        return (label, type);
    }

    private static FormattedText Text(string text, double size, Brush brush, double dpi, FontWeight weight)
        => new(text, CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, new Typeface(ChartText.UiFont(), FontStyles.Normal, weight, FontStretches.Normal), size, brush, dpi);

    private string? HitTest(Point screen)
    {
        var world = new Point((screen.X - _offset.X) / _scale, (screen.Y - _offset.Y) / _scale);
        // Topmost (last drawn) first.
        for (var i = _graph.Nodes.Count - 1; i >= 0; i--)
        {
            var node = _graph.Nodes[i];
            if (_positions.TryGetValue(node.Id, out var p) && new Rect(p.X, p.Y, W, H).Contains(world))
            {
                return node.Id;
            }
        }
        return null;
    }

    protected override void OnMouseWheel(MouseWheelEventArgs e)
    {
        if (Compact && (Keyboard.Modifiers & ModifierKeys.Control) == 0)
        {
            return; // embedded diagrams let the page scroll unless Ctrl is held
        }
        Zoom(e.Delta > 0 ? 1.12 : 1 / 1.12, e.GetPosition(this));
        e.Handled = true;
    }

    protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
    {
        Focus();
        var position = e.GetPosition(this);
        var hit = HitTest(position);
        if (e.ClickCount == 2 && hit is not null && _graph.Find(hit) is { } node)
        {
            NodeActivated?.Invoke(this, node);
            e.Handled = true;
            return;
        }
        _dragged = false;
        if (hit is not null)
        {
            _dragNode = hit;
            _dragStart = position;
            _dragNodeOrigin = _positions[hit];
        }
        else
        {
            _panStart = position;
            _panOrigin = _offset;
            Cursor = Cursors.SizeAll;
        }
        CaptureMouse();
        e.Handled = true;
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        var position = e.GetPosition(this);
        if (_dragNode is not null && e.LeftButton == MouseButtonState.Pressed)
        {
            var delta = (position - _dragStart) / _scale;
            if (delta.Length > 2)
            {
                _dragged = true;
            }
            _positions[_dragNode] = _dragNodeOrigin + delta;
            InvalidateVisual();
        }
        else if (_panStart is { } start && e.LeftButton == MouseButtonState.Pressed)
        {
            _offset = _panOrigin + (position - start);
            _dragged = true;
            InvalidateVisual();
        }
        else
        {
            Cursor = HitTest(position) is not null ? Cursors.Hand : Cursors.Arrow;
            var hover = HitTest(position);
            ToolTip = hover is not null && _graph.Find(hover) is { } node ? $"{node.Label} ({node.Type})" + (node.Description is { Length: > 0 } d ? "\n" + d : "") : null;
        }
    }

    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
    {
        ReleaseMouseCapture();
        Cursor = Cursors.Arrow;
        if (!_dragged)
        {
            Select(_dragNode);
        }
        _dragNode = null;
        _panStart = null;
    }

    protected override void OnKeyDown(KeyEventArgs e)
    {
        switch (e.Key)
        {
            case Key.Tab:
            {
                var ordered = _graph.Nodes.OrderBy(n => _positions.GetValueOrDefault(n.Id).Y).ThenBy(n => _positions.GetValueOrDefault(n.Id).X).Select(n => n.Id).ToList();
                if (ordered.Count == 0)
                {
                    return;
                }
                var index = SelectedId is null ? -1 : ordered.IndexOf(SelectedId);
                var back = (Keyboard.Modifiers & ModifierKeys.Shift) != 0;
                var next = back ? (index <= 0 ? ordered.Count - 1 : index - 1) : (index + 1) % ordered.Count;
                Select(ordered[next], center: true);
                e.Handled = true;
                break;
            }
            case Key.Enter when SelectedId is not null && _graph.Find(SelectedId) is { } node:
                NodeActivated?.Invoke(this, node);
                e.Handled = true;
                break;
            case Key.Left: _offset += new Vector(60, 0); InvalidateVisual(); e.Handled = true; break;
            case Key.Right: _offset -= new Vector(60, 0); InvalidateVisual(); e.Handled = true; break;
            case Key.Up: _offset += new Vector(0, 60); InvalidateVisual(); e.Handled = true; break;
            case Key.Down: _offset -= new Vector(0, 60); InvalidateVisual(); e.Handled = true; break;
            case Key.OemPlus or Key.Add: Zoom(1.2); e.Handled = true; break;
            case Key.OemMinus or Key.Subtract: Zoom(1 / 1.2); e.Handled = true; break;
            case Key.Home: FitView(); e.Handled = true; break;
            case Key.Escape: Select(null); e.Handled = true; break;
        }
    }
}
