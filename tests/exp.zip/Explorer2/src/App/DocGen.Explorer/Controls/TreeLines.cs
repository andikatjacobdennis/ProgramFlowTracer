using System.Windows;
using System.Windows.Media;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Controls;

/// <summary>
/// The dotted guides of a tree row: a vertical line for every ancestor that has more siblings below it, and an
/// elbow (├ or └) into the row itself. Each row draws its own slice, so the guides join up down the tree and cost
/// nothing for rows that are virtualised away. Reads its <see cref="TreeNodeViewModel"/> from the DataContext.
/// </summary>
public sealed class TreeLines : FrameworkElement
{
    /// <summary>Width of one level of indentation (matches <see cref="TreeNodeViewModel.Indent"/>).</summary>
    public const double LevelWidth = 14;

    /// <summary>Where the expander chevron sits within its 20-pixel column.</summary>
    public const double ChevronCenter = 10;

    public static readonly DependencyProperty StrokeProperty = DependencyProperty.Register(nameof(Stroke), typeof(Brush), typeof(TreeLines),
        new FrameworkPropertyMetadata(Brushes.Gray, FrameworkPropertyMetadataOptions.AffectsRender));

    private static readonly DashStyle Dots = new([1, 2], 0);

    public TreeLines()
    {
        IsHitTestVisible = false;
        SnapsToDevicePixels = true;
        DataContextChanged += (_, _) => InvalidateVisual(); // rows are recycled
    }

    public Brush? Stroke
    {
        get => (Brush?)GetValue(StrokeProperty);
        set => SetValue(StrokeProperty, value);
    }

    /// <summary>For each level 1..depth: whether the line at that level carries on below this row.</summary>
    public static (bool[] Continues, bool IsLast) Layout(TreeNodeViewModel node)
    {
        var continues = new bool[node.Depth];
        var isLast = IsLast(node);
        var ancestor = node.Parent;
        // continues[k] is about the node at depth k+1 on the path to this one (the one whose parent's line is at level k).
        for (var level = node.Depth - 2; level >= 0 && ancestor is not null; level--, ancestor = ancestor.Parent)
        {
            continues[level] = !IsLast(ancestor);
        }
        return (continues, isLast);
    }

    private static bool IsLast(TreeNodeViewModel node)
        => node.Parent is not { } parent || parent.Children.Count == 0 || ReferenceEquals(parent.Children[^1], node);

    protected override Size MeasureOverride(Size availableSize) => new(0, 0);

    protected override void OnRender(DrawingContext dc)
    {
        if (DataContext is not TreeNodeViewModel { Depth: > 0, Parent: not null } node || node.Tree.Filter.Trim().Length > 0 || Stroke is null)
        {
            return;
        }
        var pen = new Pen(Stroke, 1) { DashStyle = Dots };
        pen.Freeze();
        var height = ActualHeight;
        var middle = Math.Round(height / 2) + 0.5;
        var (continues, isLast) = Layout(node);
        double X(int level) => Math.Round(level * LevelWidth + ChevronCenter) + 0.5;

        // Ancestors' lines passing through this row.
        for (var level = 0; level < node.Depth - 1; level++)
        {
            if (continues[level])
            {
                dc.DrawLine(pen, new Point(X(level), 0), new Point(X(level), height));
            }
        }
        // The elbow into this row: down from the parent's chevron, across to this row's chevron (or its icon, for a leaf).
        var x = X(node.Depth - 1);
        dc.DrawLine(pen, new Point(x, 0), new Point(x, isLast ? middle : height));
        var reach = node.Children.Count > 0 ? X(node.Depth) - 6 : X(node.Depth) + 4;
        dc.DrawLine(pen, new Point(x, middle), new Point(reach, middle));
    }
}
