using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using DocGen.Explorer.Engine.Code;
using DocGen.Explorer.Engine.Text;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.Controls;

/// <summary>What a stretch of a line is marked as: selected, a match of Find, or the match Find is on.</summary>
public enum CodeMarkKind { Selection, Match, Current }

/// <summary>A marked stretch of one line (columns are characters of the line).</summary>
public readonly record struct CodeMark(int Start, int Length, CodeMarkKind Kind);

/// <summary>One line of the code view.</summary>
public sealed class CodeLine : ObservableObject
{
    private bool _isFolded;
    private bool _isHighlighted;
    private IReadOnlyList<CodeMark> _marks = [];

    public int Number { get; init; }

    /// <summary>What the gutter shows: the line number, or a diff line's own label ("+ 18", "− 12", nothing for a filler).</summary>
    public string NumberText => Label ?? Number.ToString(System.Globalization.CultureInfo.InvariantCulture);

    /// <summary>A diff line's gutter text (null for an ordinary line).</summary>
    public string? Label { get; init; }

    /// <summary>A diff line's kind — Added, Removed, Filler (no line on this side), Hunk, Note — tinting the row; empty for code.</summary>
    public string DiffKind { get; init; } = "";
    public string Text { get; init; } = "";
    public IReadOnlyList<Engine.Code.Span> Spans { get; init; } = [];
    public int FoldEnd { get; init; }
    public bool IsFoldStart => FoldEnd > Number;

    public bool IsFolded
    {
        get => _isFolded;
        set
        {
            if (Set(ref _isFolded, value))
            {
                OnPropertyChanged(nameof(FoldGlyph));
            }
        }
    }

    public string FoldGlyph => IsFolded ? Icons.ChevronRight : Icons.ChevronDown;

    public bool IsHighlighted
    {
        get => _isHighlighted;
        set => Set(ref _isHighlighted, value);
    }

    /// <summary>The selected and found stretches of this line.</summary>
    public IReadOnlyList<CodeMark> Marks
    {
        get => _marks;
        set => Set(ref _marks, value);
    }
}

/// <summary>A TextBlock that renders highlighted spans (theme-aware brushes), the selection and Find's marks, and a fold marker.</summary>
public sealed class CodeTextBlock : TextBlock
{
    public static readonly DependencyProperty SpansProperty = DependencyProperty.Register(nameof(Spans), typeof(IReadOnlyList<Engine.Code.Span>), typeof(CodeTextBlock),
        new PropertyMetadata(null, (d, _) => ((CodeTextBlock)d).Rebuild()));

    public static readonly DependencyProperty FoldedProperty = DependencyProperty.Register(nameof(Folded), typeof(bool), typeof(CodeTextBlock),
        new PropertyMetadata(false, (d, _) => ((CodeTextBlock)d).Rebuild()));

    public static readonly DependencyProperty MarksProperty = DependencyProperty.Register(nameof(Marks), typeof(IReadOnlyList<CodeMark>), typeof(CodeTextBlock),
        new PropertyMetadata(null, (d, _) => ((CodeTextBlock)d).Rebuild()));

    public IReadOnlyList<Engine.Code.Span>? Spans
    {
        get => (IReadOnlyList<Engine.Code.Span>?)GetValue(SpansProperty);
        set => SetValue(SpansProperty, value);
    }

    public bool Folded
    {
        get => (bool)GetValue(FoldedProperty);
        set => SetValue(FoldedProperty, value);
    }

    public IReadOnlyList<CodeMark>? Marks
    {
        get => (IReadOnlyList<CodeMark>?)GetValue(MarksProperty);
        set => SetValue(MarksProperty, value);
    }

    /// <summary>The number of characters of the line's text (the fold marker is not text).</summary>
    public int TextLength { get; private set; }

    private void Rebuild()
    {
        Inlines.Clear();
        TextLength = 0;
        if (Spans is null)
        {
            return;
        }
        var marks = Marks ?? [];
        var column = 0;
        foreach (var span in Spans)
        {
            // A span is cut where a mark starts or ends, so each piece has one background.
            var at = 0;
            while (at < span.Text.Length)
            {
                var here = column + at;
                var mark = marks.Where(m => m.Start <= here && here < m.Start + m.Length).OrderByDescending(m => m.Kind).Cast<CodeMark?>().FirstOrDefault();
                var next = span.Text.Length;
                foreach (var m in marks)
                {
                    foreach (var edge in new[] { m.Start - column, m.Start + m.Length - column })
                    {
                        if (edge > at && edge < next)
                        {
                            next = edge;
                        }
                    }
                }
                var run = MarkdownRenderer.CodeRun(span with { Text = span.Text[at..next] });
                if (mark is { } found)
                {
                    run.SetResourceReference(TextElement.BackgroundProperty, found.Kind switch
                    {
                        CodeMarkKind.Selection => "Brush.Code.Selection",
                        CodeMarkKind.Current => "Brush.Find.Current",
                        _ => "Brush.Find.Match",
                    });
                }
                Inlines.Add(run);
                at = next;
            }
            column += span.Text.Length;
        }
        TextLength = column;
        // A selection that runs past the end of the line (onto the next) shows a little of its colour there.
        if (marks.Any(m => m.Kind == CodeMarkKind.Selection && m.Start + m.Length > column))
        {
            var eol = new Run(" ");
            eol.SetResourceReference(TextElement.BackgroundProperty, "Brush.Code.Selection");
            Inlines.Add(eol);
        }
        else if (Spans.Count == 0)
        {
            Inlines.Add(new Run(" "));
        }
        if (Folded)
        {
            var marker = new Run("  ⋯ ");
            marker.SetResourceReference(TextElement.ForegroundProperty, "Brush.Accent");
            marker.SetResourceReference(TextElement.BackgroundProperty, "Brush.AccentSoft");
            Inlines.Add(marker);
        }
    }

    /// <summary>The column (character of the line) nearest a point in this block.</summary>
    public int ColumnAt(Point point)
    {
        var pointer = GetPositionFromPoint(point, snapToText: true);
        if (pointer is null)
        {
            return point.X <= Padding.Left ? 0 : TextLength;
        }
        var column = 0;
        foreach (var inline in Inlines)
        {
            if (inline is not Run run)
            {
                continue;
            }
            if (pointer.CompareTo(run.ContentStart) >= 0 && pointer.CompareTo(run.ContentEnd) <= 0)
            {
                return Math.Min(TextLength, column + run.ContentStart.GetOffsetToPosition(pointer));
            }
            column += run.Text.Length;
        }
        return Math.Min(TextLength, column);
    }
}

public partial class CodeView : UserControl
{
    public static readonly DependencyProperty WrapProperty = DependencyProperty.Register(nameof(Wrap), typeof(TextWrapping), typeof(CodeView),
        new PropertyMetadata(TextWrapping.NoWrap, (d, e) =>
        {
            var view = (CodeView)d;
            ScrollViewer.SetHorizontalScrollBarVisibility(view.Lines, (TextWrapping)e.NewValue == TextWrapping.Wrap ? ScrollBarVisibility.Disabled : ScrollBarVisibility.Auto);
        }));

    public static readonly DependencyProperty GutterWidthProperty = DependencyProperty.Register(nameof(GutterWidth), typeof(double), typeof(CodeView), new PropertyMetadata(28.0));

    private List<CodeLine> _all = [];
    private List<CodeLine> _visible = [];

    // The selection: where it started (anchor) and where it is now (caret), as (line index, column).
    private (int Line, int Column) _anchor;
    private (int Line, int Column) _caret;
    private bool _hasSelection;
    private bool _dragging;
    private int _clickMode; // 1 characters, 2 words, 3 lines

    // Find: every match, and the one it is on.
    private List<(int Line, TextMatch Match)> _matches = [];
    private int _current = -1;

    public CodeView()
    {
        InitializeComponent();
        Lines.PreviewMouseLeftButtonDown += OnMouseDown;
        Lines.PreviewMouseMove += OnMouseMove;
        Lines.PreviewMouseLeftButtonUp += OnMouseUp;
        Lines.LostMouseCapture += (_, _) => _dragging = false;
        Lines.PreviewKeyDown += OnKeyDown;
        Lines.ContextMenu = BuildMenu();
    }

    public TextWrapping Wrap
    {
        get => (TextWrapping)GetValue(WrapProperty);
        set => SetValue(WrapProperty, value);
    }

    public double GutterWidth
    {
        get => (double)GetValue(GutterWidthProperty);
        set => SetValue(GutterWidthProperty, value);
    }

    /// <summary>Raised with a line number when its number is clicked.</summary>
    public event EventHandler<int>? LineLinkRequested;

    /// <summary>Raised when Find is asked for (Ctrl+F or the menu), with the selected text to find.</summary>
    public event EventHandler<string>? FindRequested;

    public bool AnyFolded => _all.Any(l => l.IsFolded);

    /// <summary>The selected text (lines joined with a line break); empty when nothing is selected.</summary>
    public string SelectedText
    {
        get
        {
            if (!_hasSelection)
            {
                return "";
            }
            var (from, to) = Ordered();
            if (from.Line == to.Line)
            {
                var text = _all[from.Line].Text;
                return text[Math.Min(from.Column, text.Length)..Math.Min(to.Column, text.Length)];
            }
            var sb = new StringBuilder();
            sb.Append(_all[from.Line].Text[Math.Min(from.Column, _all[from.Line].Text.Length)..]);
            for (var i = from.Line + 1; i < to.Line; i++)
            {
                sb.Append('\n').Append(_all[i].Text);
            }
            sb.Append('\n').Append(_all[to.Line].Text[..Math.Min(to.Column, _all[to.Line].Text.Length)]);
            return sb.ToString();
        }
    }

    public void Load(IReadOnlyList<string> lines, string? language, int highlightLine)
    {
        var spans = SyntaxHighlighter.Highlight(lines, language);
        var regions = Folding.Regions(lines, language)
            .Where(r => r.End - r.Start >= 2)
            .GroupBy(r => r.Start).ToDictionary(g => g.Key, g => g.Max(r => r.End));
        _all = lines.Select((text, i) => new CodeLine
        {
            Number = i + 1,
            Text = text.TrimEnd('\r'),
            Spans = spans[i],
            FoldEnd = regions.GetValueOrDefault(i + 1),
        }).ToList();
        _hasSelection = false;
        _matches = [];
        _current = -1;
        GutterWidth = Math.Max(2, lines.Count.ToString(System.Globalization.CultureInfo.InvariantCulture).Length) * 8 + 4;
        Refresh();
        GoToLine(highlightLine);
    }

    /// <summary>
    /// Shows one side of a diff (or an inline diff): each line coloured by its syntax and tinted by what happened to it,
    /// with its own gutter label; selection, copy and Find work as on a file.
    /// </summary>
    public void LoadDiff(IReadOnlyList<(string Text, string Kind, string Label)> lines, string? language)
    {
        var spans = SyntaxHighlighter.Highlight(lines.Select(l => l.Kind is "Hunk" or "Note" ? "" : l.Text).ToList(), language);
        _all = lines.Select((l, i) => new CodeLine
        {
            Number = i + 1,
            Text = l.Text.TrimEnd('\r'),
            Spans = l.Kind is "Hunk" or "Note" ? [new Engine.Code.Span(Engine.Code.TokenClass.Comment, l.Text)] : spans[i],
            Label = l.Label,
            DiffKind = l.Kind,
        }).ToList();
        _hasSelection = false;
        _matches = [];
        _current = -1;
        GutterWidth = Math.Max(4, lines.Count == 0 ? 4 : lines.Max(l => l.Label.Length)) * 8 + 4;
        Refresh();
    }

    /// <summary>The scroll viewer of the lines (two sides of a diff scroll together).</summary>
    public ScrollViewer? Scroller => FindScroller(Lines);

    private static ScrollViewer? FindScroller(DependencyObject from)
    {
        for (var i = 0; i < System.Windows.Media.VisualTreeHelper.GetChildrenCount(from); i++)
        {
            var child = System.Windows.Media.VisualTreeHelper.GetChild(from, i);
            if (child is ScrollViewer viewer)
            {
                return viewer;
            }
            if (FindScroller(child) is { } inner)
            {
                return inner;
            }
        }
        return null;
    }

    public void GoToLine(int line)
    {
        foreach (var l in _all.Where(l => l.IsHighlighted))
        {
            l.IsHighlighted = false;
        }
        if (line <= 0 || line > _all.Count)
        {
            if (_visible.Count > 0)
            {
                Lines.ScrollIntoView(_visible[0]);
            }
            return;
        }
        Reveal(line);
        _all[line - 1].IsHighlighted = true;
    }

    /// <summary>Unfolds whatever hides the line and scrolls it into view, a little away from the edges.</summary>
    private void Reveal(int line)
    {
        var changed = false;
        foreach (var fold in _all.Where(l => l.IsFolded && l.Number < line && l.FoldEnd >= line))
        {
            fold.IsFolded = false;
            changed = true;
        }
        if (changed)
        {
            Refresh();
        }
        var target = _all[line - 1];
        Dispatcher.BeginInvoke(() =>
        {
            var index = _visible.IndexOf(target);
            if (index < 0)
            {
                return;
            }
            var after = _visible[Math.Min(_visible.Count - 1, index + 12)];
            Lines.ScrollIntoView(after);
            Lines.ScrollIntoView(_visible[Math.Max(0, index - 3)]);
        }, System.Windows.Threading.DispatcherPriority.Loaded);
    }

    public void FoldAll(bool fold)
    {
        foreach (var line in _all.Where(l => l.IsFoldStart))
        {
            line.IsFolded = fold;
        }
        if (fold)
        {
            // Keep the outermost block (namespace/class) open so folding shows the members.
            foreach (var outer in _all.Where(l => l.IsFoldStart && !_all.Any(o => o.IsFoldStart && o.Number < l.Number && o.FoldEnd >= l.FoldEnd)))
            {
                outer.IsFolded = false;
            }
        }
        Refresh();
    }

    private void Refresh()
    {
        var visible = new List<CodeLine>(_all.Count);
        var hideUntil = 0;
        foreach (var line in _all)
        {
            if (line.Number <= hideUntil)
            {
                continue;
            }
            visible.Add(line);
            if (line.IsFolded)
            {
                hideUntil = line.FoldEnd - 1; // keep the closing line visible
            }
        }
        _visible = visible;
        Lines.ItemsSource = _visible;
    }

    private void OnFoldClick(object sender, RoutedEventArgs e)
    {
        if ((sender as FrameworkElement)?.DataContext is CodeLine line)
        {
            line.IsFolded = !line.IsFolded;
            Refresh();
        }
    }

    private void OnLineNumberClick(object sender, MouseButtonEventArgs e)
    {
        if ((sender as FrameworkElement)?.DataContext is CodeLine line)
        {
            foreach (var l in _all.Where(l => l.IsHighlighted))
            {
                l.IsHighlighted = false;
            }
            line.IsHighlighted = true;
            LineLinkRequested?.Invoke(this, line.Number);
        }
    }

    // ---------------------------------------------------------------- selection

    /// <summary>The line and column under a point of the list (above the first line: its start; below the last: its end).</summary>
    private (int Line, int Column)? PositionAt(Point point)
    {
        var clamped = new Point(Math.Max(GutterWidth + 40, point.X), Math.Clamp(point.Y, 1, Math.Max(1, Lines.ActualHeight - 2)));
        CodeTextBlock? block = null;
        VisualTreeHelper.HitTest(Lines, null, r =>
        {
            for (var node = r.VisualHit; node is not null && node != Lines; node = VisualTreeHelper.GetParent(node))
            {
                if (node is CodeTextBlock found)
                {
                    block = found;
                    return HitTestResultBehavior.Stop;
                }
                if (node is ListBoxItem { DataContext: CodeLine } item)
                {
                    block = FindBlock(item);
                    return HitTestResultBehavior.Stop;
                }
            }
            return HitTestResultBehavior.Continue;
        }, new PointHitTestParameters(clamped));
        if (block?.DataContext is not CodeLine line)
        {
            return null;
        }
        var local = Lines.TranslatePoint(point, block);
        var column = block.ColumnAt(new Point(Math.Max(0, local.X), Math.Clamp(local.Y, 0, Math.Max(0, block.ActualHeight - 1))));
        if (point.Y < 0)
        {
            column = 0;
        }
        else if (point.Y > Lines.ActualHeight)
        {
            column = line.Text.Length;
        }
        return (line.Number - 1, column);
    }

    private static CodeTextBlock? FindBlock(DependencyObject from)
    {
        var count = VisualTreeHelper.GetChildrenCount(from);
        for (var i = 0; i < count; i++)
        {
            var child = VisualTreeHelper.GetChild(from, i);
            if (child is CodeTextBlock block)
            {
                return block;
            }
            if (FindBlock(child) is { } found)
            {
                return found;
            }
        }
        return null;
    }

    private static bool InGutter(DependencyObject? source)
    {
        for (var node = source; node is not null; node = node is Visual ? VisualTreeHelper.GetParent(node) : LogicalTreeHelper.GetParent(node))
        {
            if (node is CodeTextBlock)
            {
                return false;
            }
            if (node is Button or System.Windows.Controls.Primitives.ScrollBar || (node is TextBlock { DataContext: CodeLine } t && t is not CodeTextBlock && t.Cursor == Cursors.Hand))
            {
                return true;
            }
            if (node is ListBoxItem)
            {
                return false;
            }
        }
        return true;
    }

    private void OnMouseDown(object sender, MouseButtonEventArgs e)
    {
        if (InGutter(e.OriginalSource as DependencyObject) || PositionAt(e.GetPosition(Lines)) is not { } at)
        {
            return;
        }
        e.Handled = true;
        Lines.Focus();
        _clickMode = Math.Clamp(e.ClickCount, 1, 3);
        if (Keyboard.Modifiers.HasFlag(ModifierKeys.Shift) && _hasSelection)
        {
            _caret = at;
        }
        else
        {
            _anchor = at;
            _caret = at;
        }
        _hasSelection = true;
        ApplyClickMode();
        _dragging = true;
        Lines.CaptureMouse();
    }

    private void OnMouseMove(object sender, MouseEventArgs e)
    {
        if (!_dragging || e.LeftButton != MouseButtonState.Pressed)
        {
            return;
        }
        var point = e.GetPosition(Lines);
        // Dragging past the top or bottom scrolls.
        if (FindScroller() is { } scroller)
        {
            if (point.Y < 0)
            {
                scroller.ScrollToVerticalOffset(scroller.VerticalOffset - 16);
            }
            else if (point.Y > Lines.ActualHeight)
            {
                scroller.ScrollToVerticalOffset(scroller.VerticalOffset + 16);
            }
        }
        if (PositionAt(point) is { } at)
        {
            _caret = at;
            ApplyClickMode();
        }
    }

    private void OnMouseUp(object sender, MouseButtonEventArgs e)
    {
        if (_dragging)
        {
            _dragging = false;
            Lines.ReleaseMouseCapture();
            e.Handled = true;
        }
    }

    /// <summary>Double-click: whole words; triple-click: whole lines — also while dragging.</summary>
    private void ApplyClickMode()
    {
        var anchor = _anchor;
        var caret = _caret;
        if (_clickMode == 2)
        {
            var forward = Compare(caret, anchor) >= 0;
            var (aStart, aEnd) = WordAt(anchor);
            var (cStart, cEnd) = WordAt(caret);
            (anchor, caret) = forward ? ((anchor.Line, aStart), (caret.Line, cEnd)) : ((anchor.Line, aEnd), (caret.Line, cStart));
        }
        else if (_clickMode == 3)
        {
            var forward = Compare(caret, anchor) >= 0;
            var first = forward ? anchor.Line : caret.Line;
            var last = forward ? caret.Line : anchor.Line;
            // A whole line includes its line break: the selection ends at the start of the next line.
            var end = last + 1 < _all.Count ? (last + 1, 0) : (last, _all[last].Text.Length);
            (anchor, caret) = forward ? ((first, 0), end) : (end, (first, 0));
        }
        ShowSelection(anchor, caret);
    }

    private (int Start, int End) WordAt((int Line, int Column) at)
    {
        var text = _all[at.Line].Text;
        if (text.Length == 0)
        {
            return (0, 0);
        }
        var i = Math.Clamp(at.Column, 0, text.Length - 1);
        static bool Word(char c) => char.IsLetterOrDigit(c) || c == '_';
        if (!Word(text[i]) && i > 0 && Word(text[i - 1]))
        {
            i--;
        }
        if (!Word(text[i]))
        {
            // Punctuation or space: that one character (a run of spaces as one).
            var s = i;
            var e = i + 1;
            if (char.IsWhiteSpace(text[i]))
            {
                while (s > 0 && char.IsWhiteSpace(text[s - 1])) { s--; }
                while (e < text.Length && char.IsWhiteSpace(text[e])) { e++; }
            }
            return (s, e);
        }
        var start = i;
        var stop = i;
        while (start > 0 && Word(text[start - 1])) { start--; }
        while (stop < text.Length && Word(text[stop])) { stop++; }
        return (start, stop);
    }

    private static int Compare((int Line, int Column) a, (int Line, int Column) b) => a.Line != b.Line ? a.Line.CompareTo(b.Line) : a.Column.CompareTo(b.Column);

    private ((int Line, int Column) From, (int Line, int Column) To) Ordered()
        => Compare(_shownAnchor, _shownCaret) <= 0 ? (_shownAnchor, _shownCaret) : (_shownCaret, _shownAnchor);

    private (int Line, int Column) _shownAnchor;
    private (int Line, int Column) _shownCaret;
    private readonly HashSet<int> _marked = [];

    private void ShowSelection((int Line, int Column) anchor, (int Line, int Column) caret)
    {
        _shownAnchor = anchor;
        _shownCaret = caret;
        _hasSelection = Compare(anchor, caret) != 0;
        UpdateMarks();
    }

    public void SelectAll()
    {
        if (_all.Count == 0)
        {
            return;
        }
        _anchor = (0, 0);
        _caret = (_all.Count - 1, _all[^1].Text.Length);
        _clickMode = 1;
        ShowSelection(_anchor, _caret);
    }

    public void ClearSelection()
    {
        _hasSelection = false;
        UpdateMarks();
    }

    /// <summary>Gives each line its marks: the selection and Find's matches. Only the lines that change are touched.</summary>
    private void UpdateMarks()
    {
        var marks = new Dictionary<int, List<CodeMark>>();
        void Add(int line, CodeMark mark)
        {
            if (!marks.TryGetValue(line, out var list))
            {
                marks[line] = list = [];
            }
            list.Add(mark);
        }
        for (var i = 0; i < _matches.Count; i++)
        {
            var (line, match) = _matches[i];
            Add(line, new CodeMark(match.Start, match.Length, i == _current ? CodeMarkKind.Current : CodeMarkKind.Match));
        }
        if (_hasSelection)
        {
            var (from, to) = Ordered();
            for (var line = from.Line; line <= to.Line; line++)
            {
                var length = _all[line].Text.Length;
                var start = line == from.Line ? from.Column : 0;
                // A line the selection runs past (onto the next) is marked one character beyond its end.
                var end = line == to.Line ? to.Column : length + 1;
                if (end > start)
                {
                    Add(line, new CodeMark(start, end - start, CodeMarkKind.Selection));
                }
            }
        }
        foreach (var line in _marked.Where(l => !marks.ContainsKey(l)).ToList())
        {
            if (line < _all.Count)
            {
                _all[line].Marks = [];
            }
            _marked.Remove(line);
        }
        foreach (var (line, list) in marks)
        {
            _all[line].Marks = list;
            _marked.Add(line);
        }
    }

    private void OnKeyDown(object sender, KeyEventArgs e)
    {
        if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.C)
        {
            Copy();
            e.Handled = true;
        }
        else if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.A)
        {
            SelectAll();
            e.Handled = true;
        }
        else if (Keyboard.Modifiers == ModifierKeys.Control && e.Key == Key.F)
        {
            FindRequested?.Invoke(this, SelectedText.Contains('\n') ? "" : SelectedText);
            e.Handled = true;
        }
        else if (e.Key == Key.Escape && _hasSelection)
        {
            ClearSelection();
            e.Handled = true;
        }
    }

    /// <summary>Copies the selection (or, with nothing selected, nothing).</summary>
    public void Copy()
    {
        if (SelectedText is { Length: > 0 } text)
        {
            Ui.Copy(text.Replace("\n", Environment.NewLine, StringComparison.Ordinal));
        }
    }

    private ContextMenu BuildMenu()
    {
        var menu = new ContextMenu();
        var copy = new MenuItem { Header = "Copy", Icon = "\uE8C8", InputGestureText = "Ctrl+C" };
        copy.Click += (_, _) => Copy();
        var all = new MenuItem { Header = "Select all", Icon = "\uE8B3", InputGestureText = "Ctrl+A" };
        all.Click += (_, _) => SelectAll();
        var find = new MenuItem { Header = "Find…", Icon = "\uE721", InputGestureText = "Ctrl+F" };
        find.Click += (_, _) => FindRequested?.Invoke(this, SelectedText.Contains('\n') ? "" : SelectedText);
        menu.Items.Add(copy);
        menu.Items.Add(all);
        menu.Items.Add(new Separator());
        menu.Items.Add(find);
        menu.Opened += (_, _) => copy.IsEnabled = _hasSelection;
        return menu;
    }

    private ScrollViewer? FindScroller()
    {
        static ScrollViewer? Find(DependencyObject from)
        {
            var count = VisualTreeHelper.GetChildrenCount(from);
            for (var i = 0; i < count; i++)
            {
                var child = VisualTreeHelper.GetChild(from, i);
                if (child is ScrollViewer viewer)
                {
                    return viewer;
                }
                if (Find(child) is { } found)
                {
                    return found;
                }
            }
            return null;
        }
        return Find(Lines);
    }

    // ---------------------------------------------------------------- find

    /// <summary>Every match of Find, in order (line number from 1, the line's text and where in it), for Find all.</summary>
    public IReadOnlyList<(int Line, string Text, TextMatch Match)> Matches => _matches.Select(m => (m.Line + 1, _all[m.Line].Text, m.Match)).ToList();

    public int CurrentMatch => _current;

    /// <summary>Marks every match of <paramref name="query"/> in yellow; returns how many there are.</summary>
    public int Find(string? query, FindOptions options)
    {
        _matches = [];
        if (!string.IsNullOrEmpty(query))
        {
            for (var i = 0; i < _all.Count && _matches.Count < TextMatcher.MaxMatches; i++)
            {
                foreach (var match in TextMatcher.Matches(_all[i].Text, query, options))
                {
                    _matches.Add((i, match));
                }
            }
        }
        _current = -1;
        UpdateMarks();
        return _matches.Count;
    }

    /// <summary>Goes to a match: marks it in orange, unfolds it and scrolls it into view.</summary>
    public void GoToMatch(int index)
    {
        if (_matches.Count == 0)
        {
            return;
        }
        _current = (index % _matches.Count + _matches.Count) % _matches.Count;
        UpdateMarks();
        Reveal(_matches[_current].Line + 1);
    }

    /// <summary>The first match at or after the selection (or the top), for Find to start from where the reader is.</summary>
    public int FirstMatchFromCaret()
    {
        if (_matches.Count == 0)
        {
            return -1;
        }
        var from = _hasSelection ? Ordered().From : (0, 0);
        var index = _matches.FindIndex(m => Compare((m.Line, m.Match.Start), from) >= 0);
        return index < 0 ? 0 : index;
    }
}
