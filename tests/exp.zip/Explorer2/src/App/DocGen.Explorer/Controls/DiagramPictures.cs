using System.Windows.Media;
using System.Windows.Media.Imaging;
using DocGen.Explorer.Engine.Export;

namespace DocGen.Explorer.Controls;

/// <summary>Mermaid diagrams drawn as pictures for a Word or PowerPoint file (light theme, at most 2400 pixels wide).</summary>
public static class DiagramPictures
{
    private const int MaxPixels = 2400;

    /// <summary>
    /// Each diagram that draws, by its source (trimmed); one that fails is left out and the file shows its source. Call on
    /// the UI thread.
    /// </summary>
    public static async Task<IReadOnlyDictionary<string, DiagramImage>> DrawAsync(IEnumerable<string> diagrams)
    {
        var drawn = new Dictionary<string, DiagramImage>(StringComparer.Ordinal);
        foreach (var code in diagrams.Select(d => d.Trim()).Where(d => d.Length > 0).Distinct(StringComparer.Ordinal))
        {
            var image = await MermaidRenderer.RenderAsync(code, dark: false);
            if (image.Image is not { } bitmap || image.Width <= 0 || image.Height <= 0)
            {
                continue;
            }
            BitmapSource source = bitmap;
            var longest = Math.Max(bitmap.PixelWidth, bitmap.PixelHeight);
            if (longest > MaxPixels)
            {
                var scale = (double)MaxPixels / longest;
                source = new TransformedBitmap(bitmap, new ScaleTransform(scale, scale));
            }
            var encoder = new PngBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(source));
            using var stream = new MemoryStream();
            encoder.Save(stream);
            drawn[code] = new DiagramImage(stream.ToArray(), image.Width, image.Height);
        }
        return drawn;
    }
}
