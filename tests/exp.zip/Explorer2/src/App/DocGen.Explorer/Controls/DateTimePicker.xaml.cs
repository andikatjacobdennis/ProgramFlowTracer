using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace DocGen.Explorer.Controls;

/// <summary>A day in the picker's month grid.</summary>
public sealed record PickerDay(DateTime Date, bool InMonth, bool IsToday, bool IsSelected, bool IsAllowed)
{
    public string Number => Date.Day.ToString(CultureInfo.CurrentCulture);
    public string Name => Date.ToString("dddd d MMMM yyyy", CultureInfo.CurrentCulture) + (IsToday ? ", today" : "");
}

/// <summary>
/// A date and time, chosen in the app's own look (the stock WPF DatePicker ignores the theme): a field showing the
/// choice, and a calendar with the month's days, the hour and minute, quick picks (start of day, now, end of day, today)
/// and Clear. Changes apply at once; Done or a click elsewhere closes it.
/// </summary>
public partial class DateTimePicker : UserControl
{
    public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(nameof(Value), typeof(DateTime?), typeof(DateTimePicker),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, (d, _) => ((DateTimePicker)d).Refresh()));

    public static readonly DependencyProperty PlaceholderProperty = DependencyProperty.Register(nameof(Placeholder), typeof(string), typeof(DateTimePicker),
        new PropertyMetadata("Any time", (d, _) => ((DateTimePicker)d).Refresh()));

    public static readonly DependencyProperty DefaultTimeProperty = DependencyProperty.Register(nameof(DefaultTime), typeof(TimeSpan), typeof(DateTimePicker),
        new PropertyMetadata(TimeSpan.Zero));

    public static readonly DependencyProperty LabelProperty = DependencyProperty.Register(nameof(Label), typeof(string), typeof(DateTimePicker), new PropertyMetadata("Date and time"));

    public static readonly DependencyProperty MinimumProperty = DependencyProperty.Register(nameof(Minimum), typeof(DateTime?), typeof(DateTimePicker),
        new PropertyMetadata(null, (d, _) => ((DateTimePicker)d).ShowMonth()));

    public static readonly DependencyProperty MaximumProperty = DependencyProperty.Register(nameof(Maximum), typeof(DateTime?), typeof(DateTimePicker),
        new PropertyMetadata(null, (d, _) => ((DateTimePicker)d).ShowMonth()));

    private DateTime _month = new(DateTime.Today.Year, DateTime.Today.Month, 1);
    private bool _settingTime;

    public DateTimePicker()
    {
        InitializeComponent();
        Hours.ItemsSource = Enumerable.Range(0, 24).Select(h => h.ToString("00", CultureInfo.InvariantCulture)).ToList();
        Minutes.ItemsSource = Enumerable.Range(0, 60).Select(m => m.ToString("00", CultureInfo.InvariantCulture)).ToList();
        var first = (int)CultureInfo.CurrentCulture.DateTimeFormat.FirstDayOfWeek;
        var names = CultureInfo.CurrentCulture.DateTimeFormat.AbbreviatedDayNames;
        WeekDays.ItemsSource = Enumerable.Range(0, 7).Select(i => names[(first + i) % 7][..Math.Min(2, names[(first + i) % 7].Length)]).ToList();
        Refresh();
    }

    /// <summary>The chosen date and time (local), or null for none.</summary>
    public DateTime? Value
    {
        get => (DateTime?)GetValue(ValueProperty);
        set => SetValue(ValueProperty, value);
    }

    /// <summary>Shown when nothing is chosen ("Any time", "No limit").</summary>
    public string Placeholder
    {
        get => (string)GetValue(PlaceholderProperty);
        set => SetValue(PlaceholderProperty, value);
    }

    /// <summary>The time a day gets when it is picked first (00:00 for a "from", 23:59 for a "to").</summary>
    public TimeSpan DefaultTime
    {
        get => (TimeSpan)GetValue(DefaultTimeProperty);
        set => SetValue(DefaultTimeProperty, value);
    }

    public string Label
    {
        get => (string)GetValue(LabelProperty);
        set => SetValue(LabelProperty, value);
    }

    public DateTime? Minimum
    {
        get => (DateTime?)GetValue(MinimumProperty);
        set => SetValue(MinimumProperty, value);
    }

    public DateTime? Maximum
    {
        get => (DateTime?)GetValue(MaximumProperty);
        set => SetValue(MaximumProperty, value);
    }

    public string ToolTipText => Value is { } v ? $"{Label}: {v.ToString("dddd d MMMM yyyy, HH:mm", CultureInfo.CurrentCulture)}" : $"{Label}: {Placeholder}";

    public bool IsOpen
    {
        get => Picker.IsOpen;
        set => Picker.IsOpen = value;
    }

    private void Refresh()
    {
        if (FaceText is null)
        {
            return;
        }
        if (Value is { } v)
        {
            FaceText.Text = v.ToString("d MMM yyyy  HH:mm", CultureInfo.CurrentCulture);
            FaceText.SetResourceReference(TextBlock.ForegroundProperty, "Brush.Text");
            ClearButton.Visibility = Visibility.Visible;
        }
        else
        {
            FaceText.Text = Placeholder;
            FaceText.SetResourceReference(TextBlock.ForegroundProperty, "Brush.TextFaint");
            ClearButton.Visibility = Visibility.Collapsed;
        }
        Face.ToolTip = ToolTipText;
        var time = Value?.TimeOfDay ?? DefaultTime;
        _settingTime = true;
        Hours.SelectedIndex = time.Hours;
        Minutes.SelectedIndex = time.Minutes;
        _settingTime = false;
        ShowMonth();
    }

    private void ShowMonth()
    {
        if (Days is null)
        {
            return;
        }
        MonthTitle.Text = _month.ToString("MMMM yyyy", CultureInfo.CurrentCulture);
        var first = (int)CultureInfo.CurrentCulture.DateTimeFormat.FirstDayOfWeek;
        var offset = ((int)_month.DayOfWeek - first + 7) % 7;
        var start = _month.AddDays(-offset);
        var selected = Value?.Date;
        Days.ItemsSource = Enumerable.Range(0, 42).Select(i =>
        {
            var day = start.AddDays(i);
            var allowed = (Minimum is not { } min || day >= min.Date) && (Maximum is not { } max || day <= max.Date);
            return new PickerDay(day, day.Month == _month.Month, day == DateTime.Today, day == selected, allowed);
        }).ToList();
    }

    // While open, the field ignores the mouse: a click on it closes the calendar (instead of opening it again).
    private void OnClosed(object? sender, EventArgs e) => Face.IsHitTestVisible = true;

    private void OnOpened(object? sender, EventArgs e)
    {
        Face.IsHitTestVisible = false;
        var shown = Value ?? DateTime.Today;
        _month = new DateTime(shown.Year, shown.Month, 1);
        ShowMonth();
        // The chosen day (or today) takes the keyboard, so arrows and Enter work at once.
        Dispatcher.BeginInvoke(() =>
        {
            var target = Value?.Date ?? DateTime.Today;
            var index = (Days.ItemsSource as IList<PickerDay>)?.ToList().FindIndex(d => d.Date == target) ?? -1;
            if (index >= 0 && Days.ItemContainerGenerator.ContainerFromIndex(index) is ContentPresenter presenter
                && System.Windows.Media.VisualTreeHelper.GetChildrenCount(presenter) > 0 && System.Windows.Media.VisualTreeHelper.GetChild(presenter, 0) is Button button)
            {
                button.Focus();
            }
        }, System.Windows.Threading.DispatcherPriority.Loaded);
    }

    private void OnPreviousMonth(object sender, RoutedEventArgs e)
    {
        _month = _month.AddMonths(-1);
        ShowMonth();
    }

    private void OnNextMonth(object sender, RoutedEventArgs e)
    {
        _month = _month.AddMonths(1);
        ShowMonth();
    }

    private void OnDay(object sender, RoutedEventArgs e)
    {
        if ((sender as FrameworkElement)?.DataContext is PickerDay day)
        {
            Value = Clamp(day.Date + (Value?.TimeOfDay ?? DefaultTime));
            if (!day.InMonth)
            {
                _month = new DateTime(day.Date.Year, day.Date.Month, 1);
                ShowMonth();
            }
        }
    }

    private void OnTimeChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_settingTime || Hours.SelectedIndex < 0 || Minutes.SelectedIndex < 0)
        {
            return;
        }
        var date = Value?.Date ?? DateTime.Today;
        Value = Clamp(date + new TimeSpan(Hours.SelectedIndex, Minutes.SelectedIndex, 0));
    }

    private void OnStartOfDay(object sender, RoutedEventArgs e) => Value = Clamp((Value?.Date ?? DateTime.Today) + TimeSpan.Zero);

    private void OnEndOfDay(object sender, RoutedEventArgs e) => Value = Clamp((Value?.Date ?? DateTime.Today) + new TimeSpan(23, 59, 0));

    private void OnNow(object sender, RoutedEventArgs e)
    {
        var now = DateTime.Now;
        Value = Clamp(new DateTime(now.Year, now.Month, now.Day, now.Hour, now.Minute, 0));
    }

    private void OnToday(object sender, RoutedEventArgs e)
    {
        Value = Clamp(DateTime.Today + (Value?.TimeOfDay ?? DefaultTime));
        _month = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
        ShowMonth();
    }

    private void OnClear(object sender, RoutedEventArgs e)
    {
        Value = null;
        e.Handled = true;
    }

    private void OnDone(object sender, RoutedEventArgs e)
    {
        Picker.IsOpen = false;
        Face.Focus();
    }

    private void OnPickerKey(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape)
        {
            Picker.IsOpen = false;
            Face.Focus();
            e.Handled = true;
        }
        else if (e.Key == Key.PageUp || e.Key == Key.PageDown)
        {
            _month = _month.AddMonths(e.Key == Key.PageUp ? -1 : 1);
            ShowMonth();
            e.Handled = true;
        }
    }

    private DateTime Clamp(DateTime value)
        => Minimum is { } min && value < min ? min : Maximum is { } max && value > max ? max : value;
}
