using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace DocGen.Explorer.Controls;

/// <summary>
/// A border with a soft shadow drawn behind it — for menus, pop-ups and floating panels. A DropShadowEffect would turn
/// everything inside (text and icons) into one bitmap, which blurs it slightly and loses ClearType; this draws the shadow
/// as a few faint rounded layers instead, so the content stays crisp.
/// </summary>
public sealed class ShadowBorder : Border
{
    public static readonly DependencyProperty ShadowBlurProperty = DependencyProperty.Register(nameof(ShadowBlur), typeof(double), typeof(ShadowBorder),
        new FrameworkPropertyMetadata(16.0, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty ShadowDepthProperty = DependencyProperty.Register(nameof(ShadowDepth), typeof(double), typeof(ShadowBorder),
        new FrameworkPropertyMetadata(2.0, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty ShadowOpacityProperty = DependencyProperty.Register(nameof(ShadowOpacity), typeof(double), typeof(ShadowBorder),
        new FrameworkPropertyMetadata(0.12, FrameworkPropertyMetadataOptions.AffectsRender));

    /// <summary>How far the shadow spreads.</summary>
    public double ShadowBlur { get => (double)GetValue(ShadowBlurProperty); set => SetValue(ShadowBlurProperty, value); }

    /// <summary>How far down the shadow falls.</summary>
    public double ShadowDepth { get => (double)GetValue(ShadowDepthProperty); set => SetValue(ShadowDepthProperty, value); }

    /// <summary>How dark the shadow is next to the edge (0–1).</summary>
    public double ShadowOpacity { get => (double)GetValue(ShadowOpacityProperty); set => SetValue(ShadowOpacityProperty, value); }

    protected override void OnRender(DrawingContext dc)
    {
        var size = RenderSize;
        if (size.Width > 0 && size.Height > 0 && ShadowBlur > 0 && ShadowOpacity > 0)
        {
            var radius = CornerRadius.TopLeft;
            var steps = (int)Math.Clamp(ShadowBlur / 2, 3, 12);
            for (var i = steps; i >= 1; i--)
            {
                // Outer layers are faint; together they fade from the edge outwards.
                var spread = ShadowBlur * i / steps;
                var t = 1 - (double)i / (steps + 1);
                var alpha = (byte)Math.Clamp(255 * ShadowOpacity * t * t * 2.2 / steps, 0, 255);
                var brush = new SolidColorBrush(Color.FromArgb(alpha, 0, 0, 0));
                brush.Freeze();
                var rect = new Rect(-spread / 2, -spread / 2 + ShadowDepth, size.Width + spread, size.Height + spread);
                dc.DrawRoundedRectangle(brush, null, rect, radius + spread / 2, radius + spread / 2);
            }
        }
        base.OnRender(dc);
    }
}
