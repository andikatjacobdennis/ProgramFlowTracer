using System.Windows;
using System.Windows.Media;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.Controls;

/// <summary>
/// A small oscilloscope that shows a voice is speaking: a smooth trace in the accent colour with a soft glow, its height
/// following the real loudness of the sound this app is playing (flat while the voice is still being prepared, and in the
/// pauses), tapering to silence at both ends. It moves only while
/// <see cref="IsActive"/> is set and it is on screen; with Motion off it shows a still trace.
/// </summary>
public sealed class Oscilloscope : FrameworkElement
{
    public static readonly DependencyProperty IsActiveProperty = DependencyProperty.Register(nameof(IsActive), typeof(bool), typeof(Oscilloscope),
        new PropertyMetadata(false, (d, _) => ((Oscilloscope)d).Update()));

    /// <summary>Follow the microphone while dictation listens (instead of the sound this app plays).</summary>
    public static readonly DependencyProperty ListeningProperty = DependencyProperty.Register(nameof(Listening), typeof(bool), typeof(Oscilloscope),
        new PropertyMetadata(false));

    public bool Listening
    {
        get => (bool)GetValue(ListeningProperty);
        set => SetValue(ListeningProperty, value);
    }

    private const int Points = 64;
    private readonly System.Diagnostics.Stopwatch _clock = new();
    private bool _animating;

    public Oscilloscope()
    {
        Width = 60;
        Height = 20;
        IsHitTestVisible = false;
        IsVisibleChanged += (_, _) => Update();
        Unloaded += (_, _) => Stop();
        Loaded += (_, _) => Update();
    }

    public bool IsActive
    {
        get => (bool)GetValue(IsActiveProperty);
        set => SetValue(IsActiveProperty, value);
    }

    private static bool ReduceMotion => Avatars.AvatarFace.ReduceMotion;

    private void Update()
    {
        var run = IsActive && IsVisible && IsLoaded && !ReduceMotion;
        if (run && !_animating)
        {
            _clock.Restart();
            Array.Clear(_levels);
            _level = 0;
            _reference = 0;
            CompositionTarget.Rendering += OnFrame;
            _animating = true;
        }
        else if (!run)
        {
            Stop();
        }
        InvalidateVisual();
    }

    private void Stop()
    {
        if (_animating)
        {
            CompositionTarget.Rendering -= OnFrame;
            _animating = false;
        }
    }

    // The real loudness of the voice (Windows' meter for this app's sound): smoothed, and kept for the width of the trace so
    // it travels along it as on a scope. Null when Windows has no meter (the trace then draws its own syllable-like wave).
    private readonly double[] _levels = new double[Points + 1];
    private double _level;
    private double _reference;
    private bool _metered;

    private void OnFrame(object? sender, EventArgs e)
    {
        if ((Listening ? SpeechService.ListeningLevel : AudioMeter.Peak()) is { } peak)
        {
            _metered = true;
            // Quick to rise, a little slower to fall, like a level meter; scaled to the voice's own recent loudness (voices
            // differ a lot in level), so a voice's loud syllables fill the height and its pauses fall flat. A microphone
            // is much quieter than playback: a quiet voice still shows.
            _level = peak > _level ? peak : _level * 0.8 + peak * 0.2;
            _reference = Math.Max(Math.Max(_reference * 0.995, _level), Listening ? 0.015 : 0.08);
            Array.Copy(_levels, 1, _levels, 0, _levels.Length - 1);
            _levels[^1] = Math.Min(1, _level / _reference * 0.95);
        }
        else
        {
            _metered = false;
        }
        InvalidateVisual();
    }

    /// <summary>How loud the voice is at time <paramref name="t"/> (seconds): syllable-like bursts with short pauses.</summary>
    private static double Loudness(double t)
    {
        var syllables = 0.5 + 0.5 * Math.Sin(t * 2 * Math.PI * 3.1) * Math.Sin(t * 2 * Math.PI * 1.3 + 0.7);
        var phrases = 0.55 + 0.45 * Math.Sin(t * 2 * Math.PI * 0.37 + 1.9);
        return Math.Clamp(0.35 + 0.65 * Math.Abs(syllables) * phrases, 0, 1);
    }

    protected override void OnRender(DrawingContext dc)
    {
        var width = ActualWidth;
        var height = ActualHeight;
        if (width <= 0 || height <= 0)
        {
            return;
        }
        var accent = (TryFindResource("Brush.Accent") as SolidColorBrush)?.Color ?? Color.FromRgb(0x1F, 0x5F, 0xCC);
        var mid = height / 2;

        // The resting line, faint.
        var baseline = new Pen(new SolidColorBrush(Color.FromArgb(0x40, accent.R, accent.G, accent.B)), 1);
        baseline.Freeze();
        dc.DrawLine(baseline, new Point(1, mid), new Point(width - 1, mid));

        var t = IsActive && !ReduceMotion ? _clock.Elapsed.TotalSeconds : 0.42;
        var still = !IsActive;
        var geometry = new StreamGeometry();
        using (var context = geometry.Open())
        {
            for (var i = 0; i <= Points; i++)
            {
                var u = (double)i / Points;
                // Tapers to silence at both ends (a Hann window), so the trace rises from the line and falls back to it.
                var window = 0.5 - 0.5 * Math.Cos(2 * Math.PI * u);
                // The loudness travels along the trace, as on a scope sweeping a voice.
                var loud = still ? 0.18 : _metered ? _levels[i] : Loudness(t - u * 0.35);
                var wave = 0.62 * Math.Sin(2 * Math.PI * (2.6 * u - t * 1.9))
                         + 0.28 * Math.Sin(2 * Math.PI * (5.3 * u + t * 2.7) + 1.1)
                         + 0.10 * Math.Sin(2 * Math.PI * (9.7 * u - t * 4.3) + 2.3);
                var y = mid - wave * loud * window * (height / 2 - 1.5);
                var point = new Point(1 + u * (width - 2), y);
                if (i == 0)
                {
                    context.BeginFigure(point, false, false);
                }
                else
                {
                    context.LineTo(point, true, true);
                }
            }
        }
        geometry.Freeze();

        // A soft glow under a crisp trace, the colour deepening towards the middle.
        var glow = new Pen(new SolidColorBrush(Color.FromArgb(0x38, accent.R, accent.G, accent.B)), 3.6) { LineJoin = PenLineJoin.Round, StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
        var stroke = new LinearGradientBrush
        {
            StartPoint = new Point(0, 0),
            EndPoint = new Point(1, 0),
            GradientStops =
            {
                new GradientStop(Color.FromArgb(0x70, accent.R, accent.G, accent.B), 0),
                new GradientStop(accent, 0.5),
                new GradientStop(Color.FromArgb(0x70, accent.R, accent.G, accent.B), 1),
            },
        };
        var trace = new Pen(stroke, 1.5) { LineJoin = PenLineJoin.Round, StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
        dc.DrawGeometry(null, glow, geometry);
        dc.DrawGeometry(null, trace, geometry);
    }
}
