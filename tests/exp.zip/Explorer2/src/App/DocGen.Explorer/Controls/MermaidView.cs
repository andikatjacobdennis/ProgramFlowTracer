using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using DocGen.Explorer.Engine.Code;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.Controls;

/// <summary>
/// A Mermaid diagram in a page or an answer: drawn by mermaid.js (<see cref="MermaidRenderer"/>) and shown as a picture
/// that shrinks to fit (double-click for full size). While an answer is still streaming the diagram waits for a pause
/// before it is drawn; when mermaid.js cannot draw it, a flowchart falls back to the built-in drawing and anything else
/// shows its code with the reason.
/// </summary>
public sealed class MermaidView : Border
{
    private string _code;
    private readonly UIElement _source;
    private bool _drawn;
    private bool _drawing;

    public MermaidView(string code, UIElement source)
    {
        _code = code;
        _source = source;
        Padding = new Thickness(10, 4, 10, 10);
        Child = Waiting();
        Loaded += async (_, _) => await DrawAsync();
    }

    private static UIElement Waiting()
    {
        var panel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(6, 10, 6, 10) };
        panel.Children.Add(new ProgressBar { IsIndeterminate = true, Margin = new Thickness(0, 0, 10, 0) });
        var text = new TextBlock { Text = "Drawing the diagram…", FontSize = 12.5, VerticalAlignment = VerticalAlignment.Center };
        text.SetResourceReference(TextBlock.ForegroundProperty, "Brush.TextMuted");
        panel.Children.Add(text);
        return panel;
    }

    private async Task DrawAsync()
    {
        // Loaded can come again while the first drawing is still on its way: one drawing at a time.
        if (_drawn || _drawing)
        {
            return;
        }
        _drawing = true;
        try
        {
            await DrawOnceAsync();
        }
        finally
        {
            _drawing = false;
        }
    }

    private async Task DrawOnceAsync()
    {
        var dark = ThemeManager.IsDark;
        if (!MermaidRenderer.TryGetCached(_code, dark, out var image))
        {
            // A streaming answer redraws its Markdown many times a second: draw only what stays on screen.
            await Task.Delay(350);
            if (!IsLoaded)
            {
                return;
            }
            image = await MermaidRenderer.RenderAsync(_code, dark);
            if (!IsLoaded)
            {
                return;
            }
        }
        _drawn = true;
        if (image.Image is null && await RepairAsync(image.Error))
        {
            return;
        }
        Child = image.Image is not null ? Picture(image) : Fallback(image.Error);
    }

    // ----- A diagram mermaid.js cannot draw: the chat model is asked to fix it -----

    /// <summary>Diagrams the model could not fix (this session): not asked again each time they are shown.</summary>
    private static readonly HashSet<string> Unfixable = new(StringComparer.Ordinal);

    private int _repairTries;

    /// <summary>
    /// Asks the chat model to fix the diagram, up to the attempts set in Settings → Chat model, drawing each answer. A
    /// fix that draws replaces the diagram (in an answer, the answer keeps it). True when the diagram is shown fixed.
    /// </summary>
    private async Task<bool> RepairAsync(string? error)
    {
        if (Application.Current?.MainWindow?.DataContext is not ViewModels.MainViewModel { Workspace: { } workspace } main
            || DataContext is ViewModels.ChatMessageViewModel { IsStreaming: true } || Unfixable.Contains(_code))
        {
            return false;
        }
        var attempts = (await main.Engine.Models.GetExplorerSettingsAsync()).DiagramRepairAttempts;
        var status = await main.Engine.Models.GetStatusAsync();
        if (attempts <= 0 || !status.Configured)
        {
            return false;
        }
        var code = _code;
        var problem = error;
        for (var attempt = 1; attempt <= attempts; attempt++)
        {
            Child = Repairing(attempt, attempts, status.DisplayName ?? "the model");
            _repairTries = attempt;
            var fixedCode = await main.Engine.Assistant.RepairDiagramAsync(workspace.Record.Id, code, problem, attempt);
            if (!IsLoaded)
            {
                return true;
            }
            if (fixedCode is null)
            {
                break;
            }
            var image = await MermaidRenderer.RenderAsync(fixedCode, ThemeManager.IsDark);
            if (image.Image is not null)
            {
                Logging.Info($"Diagram fixed by the model after {attempt} attempt(s).");
                // In an answer: the answer keeps the fixed diagram and is shown again with it (drawn from the cache).
                if (DataContext is ViewModels.ChatMessageViewModel answer && await answer.ReplaceDiagramAsync(_code, fixedCode))
                {
                    return true;
                }
                _code = fixedCode;
                Child = Picture(image);
                return true;
            }
            Logging.Info($"Diagram fix {attempt} of {attempts} still could not be drawn: {image.Error}");
            code = fixedCode;
            problem = image.Error;
        }
        Unfixable.Add(_code);
        return false;
    }

    private static UIElement Repairing(int attempt, int attempts, string model)
    {
        var panel = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(6, 10, 6, 10) };
        panel.Children.Add(new ProgressBar { IsIndeterminate = true, Margin = new Thickness(0, 0, 10, 0) });
        var text = new TextBlock
        {
            Text = $"Mermaid could not draw this diagram; asking {model} to fix it (attempt {attempt} of {attempts})…",
            FontSize = 12.5, VerticalAlignment = VerticalAlignment.Center, TextWrapping = TextWrapping.Wrap,
        };
        text.SetResourceReference(TextBlock.ForegroundProperty, "Brush.TextMuted");
        LiveRegion.SetAnnounce(text, true);
        panel.Children.Add(text);
        return panel;
    }

    private UIElement Picture(MermaidImage image)
    {
        var viewer = new DiagramViewer(image, _code) { SummariseRequested = () => _ = SummariseAsync() };
        var panel = new StackPanel();
        panel.Children.Add(viewer);
        panel.Children.Add(_summary);
        // A summary made before (kept with the answer) is shown again under its diagram.
        if (DataContext is ViewModels.ChatMessageViewModel answer && answer.DiagramSummary(_code) is { } kept)
        {
            ShowSummary(kept, working: false);
        }
        return panel;
    }

    // ----- The diagram's summary, under it -----

    private readonly Border _summary = new() { Visibility = Visibility.Collapsed, Margin = new Thickness(0, 8, 0, 0), Padding = new Thickness(12, 8, 8, 4), BorderThickness = new Thickness(0, 1, 0, 0) };
    private MarkdownBlock? _summaryText;
    private TextBlock? _summaryStatus;
    private bool _summarising;

    private void ShowSummary(string text, bool working)
    {
        if (_summaryText is null)
        {
            _summary.SetResourceReference(Border.BorderBrushProperty, "Brush.BorderSubtle");
            var header = new DockPanel { Margin = new Thickness(0, 0, 0, 4) };
            var close = new Button { Content = Icons.Close, ToolTip = "Hide the summary", Padding = new Thickness(4) };
            close.SetResourceReference(StyleProperty, "Button.Icon");
            System.Windows.Automation.AutomationProperties.SetName(close, "Hide the summary");
            close.Click += (_, _) => _summary.Visibility = Visibility.Collapsed;
            DockPanel.SetDock(close, Dock.Right);
            header.Children.Add(close);
            var title = new TextBlock { Text = "Summary of the diagram", FontWeight = FontWeights.SemiBold, VerticalAlignment = VerticalAlignment.Center };
            title.SetResourceReference(TextBlock.FontSizeProperty, "FontSize.Small");
            header.Children.Add(title);
            _summaryStatus = new TextBlock { Margin = new Thickness(0, 0, 0, 4), TextWrapping = TextWrapping.Wrap };
            _summaryStatus.SetResourceReference(StyleProperty, "Text.Small");
            LiveRegion.SetAnnounce(_summaryStatus, true);
            _summaryText = new MarkdownBlock();
            var stack = new StackPanel();
            stack.Children.Add(header);
            stack.Children.Add(_summaryStatus);
            stack.Children.Add(_summaryText);
            _summary.Child = stack;
        }
        _summaryStatus!.Text = working ? "Summarising the diagram…" : "";
        _summaryStatus.Visibility = working ? Visibility.Visible : Visibility.Collapsed;
        _summaryText!.Markdown = text;
        _summary.Visibility = Visibility.Visible;
        _summary.BringIntoView();
    }

    /// <summary>
    /// Writes the summary under the diagram: in an answer it is kept with that answer (in that conversation only); on a
    /// page it is shown until the page closes.
    /// </summary>
    private async Task SummariseAsync()
    {
        if (_summarising)
        {
            return;
        }
        _summarising = true;
        var buffer = new System.Text.StringBuilder();
        ShowSummary("", working: true);
        try
        {
            void OnDelta(string delta) => Dispatcher.BeginInvoke(() => { buffer.Append(delta); _summaryText!.Markdown = buffer.ToString(); });
            var text = DataContext is ViewModels.ChatMessageViewModel answer
                ? await answer.SummariseDiagramAsync(_code, OnDelta)
                : await SummariseSelection.SummariseDiagramHereAsync(_code, OnDelta);
            ShowSummary(text, working: false);
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            ShowSummary("_The diagram could not be summarised: " + ex.Message + "_", working: false);
            Logging.Error(ex, "Diagram summary");
        }
        finally
        {
            _summarising = false;
        }
    }

    private UIElement Fallback(string? error)
    {
        var panel = new StackPanel();
        var tried = _repairTries > 0 ? $" (the model tried to fix it {(_repairTries == 1 ? "once" : $"{_repairTries} times")})" : "";
        var note = new TextBlock { Text = "Mermaid could not draw this diagram" + tried + (string.IsNullOrWhiteSpace(error) ? "." : $": {error.Split('\n')[0]}"), FontSize = 12, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(4, 4, 4, 6) };
        note.SetResourceReference(TextBlock.ForegroundProperty, "Brush.Warning");
        if (MermaidFlowchart.Parse(_code, out _) is { } flowchart)
        {
            // A flowchart the built-in drawing understands.
            var diagram = new GraphCanvas { Height = Math.Clamp(140 + flowchart.Nodes.Count * 34, 220, 520), Compact = true };
            diagram.SetGraph(flowchart, Engine.Graph.GraphLayout.Compute(flowchart, 200));
            diagram.Loaded += (_, _) => diagram.FitView();
            panel.Children.Add(diagram);
            return panel;
        }
        panel.Children.Add(note);
        // The code is shown instead (the block's source view).
        _source.Visibility = Visibility.Visible;
        return panel;
    }
}
