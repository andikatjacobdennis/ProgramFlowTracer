using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using DocGen.Explorer.Engine.Speech;

namespace DocGen.Explorer.Controls;

/// <summary>
/// Read aloud: the word being said is highlighted in yellow in the text being read, until reading stops or ends.
/// <para>
/// When reading starts, the words that are spoken (the text as sent to the voice) are lined up once with the words shown,
/// in order (<see cref="WordAlignment.Align"/>). Each word the voice reports is then matched to the next few spoken words only, and
/// shown where it is lined up — so the highlight moves word by word and never jumps to the same word elsewhere. A word
/// that is spoken but not shown (left-out code) moves nothing. The highlight is drawn over the text, which is not changed.
/// </para>
/// </summary>
public sealed class SpokenWordHighlight
{
    /// <summary>How many spoken words ahead a word reported by the voice may be (the voice skips nothing it was sent).</summary>
    private const int Lookahead = 8;

    private readonly RichTextBox _box;
    private readonly Func<string?> _text;
    private string? _reading;
    private List<string> _spoken = [];
    private List<TextRange> _shown = [];
    private int[] _map = [];
    private int _next;
    private TextRange? _current;
    private Marker? _marker;
    private double _lineTop = double.NaN;
    private bool _attached;

    /// <param name="box">The control showing the text.</param>
    /// <param name="text">The text it shows, as given to read aloud (to tell whether it is the one being read).</param>
    public SpokenWordHighlight(RichTextBox box, Func<string?> text)
    {
        _box = box;
        _text = text;
        box.Loaded += (_, _) => Attach();
        box.Unloaded += (_, _) => Detach();
    }

    /// <summary>The highlighted word, if any (for checks).</summary>
    public string? Word { get; private set; }

    /// <summary>Where the highlighted word is among the shown words (for checks), or -1.</summary>
    public int ShownIndex { get; private set; } = -1;

    private void Attach()
    {
        if (_attached)
        {
            return;
        }
        _attached = true;
        Infrastructure.SpeechService.WordSpoken += OnWord;
        Infrastructure.SpeechService.ReadingEnded += Clear;
    }

    private void Detach()
    {
        if (!_attached)
        {
            return;
        }
        _attached = false;
        Infrastructure.SpeechService.WordSpoken -= OnWord;
        Infrastructure.SpeechService.ReadingEnded -= Clear;
        Clear();
    }

    /// <summary>The text was shown again (its document replaced): line the words up again on the next word.</summary>
    public void Reset()
    {
        _reading = null;
        _current = null;
        _marker?.Show(null);
        Word = null;
        ShownIndex = -1;
    }

    private void OnWord(string reading, string word)
    {
        if (!string.Equals(reading, _text(), StringComparison.Ordinal))
        {
            if (_reading is not null)
            {
                Clear();
            }
            return;
        }
        if (!ReferenceEquals(_reading, reading))
        {
            Start(reading);
        }
        // The word as the voice reports it, matched to the next spoken words.
        var i = WordAlignment.Match(_spoken, _next, word, Lookahead);
        if (i < 0)
        {
            return;
        }
        _next = i + 1;
        if (_map[i] >= 0)
        {
            Show(_map[i]);
        }
    }

    /// <summary>Lines up the spoken words of <paramref name="reading"/> with the words shown.</summary>
    private void Start(string reading)
    {
        _reading = reading;
        _spoken = WordAlignment.Tokens(Infrastructure.SpeechService.Speakable(reading)).ToList();
        _shown = ShownWords(_box.Document).ToList();
        _map = WordAlignment.Align(_spoken, _shown.Select(r => r.Text).ToList());
        _next = 0;
        _lineTop = double.NaN;
    }

    private void Show(int index)
    {
        var found = _shown[index];
        _current = found;
        Word = found.Text;
        ShownIndex = index;
        if (_marker is null && AdornerLayer.GetAdornerLayer(_box) is { } layer)
        {
            _marker = new Marker(_box);
            layer.Add(_marker);
        }
        _marker?.Show(found);
        if (OwnerTextBlock(found.Start) is { } cell)
        {
            // A word in a table cell (a table in a narrow answer scrolls sideways): bring the cell's word into view
            // within the table and the answer, then draw the mark where it is now.
            var local = found.Start.GetCharacterRect(LogicalDirection.Forward);
            if (!local.IsEmpty)
            {
                cell.BringIntoView(new Rect(local.X - 24, local.Y - 8, Math.Max(1, local.Width) + 48, local.Height + 24));
                _box.Dispatcher.BeginInvoke(() => _marker?.Show(found), System.Windows.Threading.DispatcherPriority.Render);
            }
            _lineTop = double.NaN;
            return;
        }
        // Keep the word in view: once per line, so the page does not jitter word by word.
        var at = found.Start.GetCharacterRect(LogicalDirection.Forward);
        if (!at.IsEmpty && (double.IsNaN(_lineTop) || Math.Abs(at.Top - _lineTop) > 1))
        {
            _lineTop = at.Top;
            _box.BringIntoView(new Rect(at.X, at.Y - 8, Math.Max(1, at.Width), at.Height + 24));
        }
    }

    /// <summary>The text block a position is in (a table cell drawn as a control), or null for the document's own text.</summary>
    private static TextBlock? OwnerTextBlock(TextPointer pointer)
    {
        DependencyObject? x = pointer.Parent;
        while (x is TextElement element)
        {
            x = element.Parent;
        }
        return x as TextBlock;
    }

    /// <summary>A position's character box in <paramref name="relativeTo"/>'s coordinates (a cell's words are measured in their cell).</summary>
    private static Rect CharacterRect(TextPointer pointer, LogicalDirection direction, Visual relativeTo)
    {
        var rect = pointer.GetCharacterRect(direction);
        if (rect.IsEmpty || OwnerTextBlock(pointer) is not { } cell)
        {
            return rect;
        }
        return cell.IsDescendantOf(relativeTo) ? cell.TransformToAncestor(relativeTo).TransformBounds(rect) : Rect.Empty;
    }

    /// <summary>Reading stopped or finished: the highlight goes, and the next reading lines the words up again.</summary>
    public void Clear()
    {
        _reading = null;
        _current = null;
        _lineTop = double.NaN;
        Word = null;
        ShownIndex = -1;
        if (_marker is not null)
        {
            AdornerLayer.GetAdornerLayer(_box)?.Remove(_marker);
            _marker = null;
        }
    }

    /// <summary>Each word shown in a document, in reading order, with where it is.</summary>
    public static IEnumerable<TextRange> ShownWords(FlowDocument document) => Words(document.ContentStart);

    /// <summary>
    /// The words from a position on, in reading order. A control embedded in the text (a table that scrolls sideways
    /// in a narrow answer) is read too: its cells' text, row by row.
    /// </summary>
    private static IEnumerable<TextRange> Words(TextPointer from)
    {
        for (var p = from; p is not null; p = p.GetNextContextPosition(LogicalDirection.Forward))
        {
            switch (p.GetPointerContext(LogicalDirection.Forward))
            {
                case TextPointerContext.Text:
                    var run = p.GetTextInRun(LogicalDirection.Forward);
                    foreach (var (index, length) in WordAlignment.Spans(run))
                    {
                        if (p.GetPositionAtOffset(index) is { } start && start.GetPositionAtOffset(length) is { } end)
                        {
                            yield return new TextRange(start, end);
                        }
                    }
                    break;
                case TextPointerContext.EmbeddedElement when p.GetAdjacentElement(LogicalDirection.Forward) is DependencyObject embedded:
                    foreach (var cell in TextBlocksIn(embedded))
                    {
                        foreach (var word in Words(cell.ContentStart).Where(w => w.Start.CompareTo(cell.ContentEnd) < 0))
                        {
                            yield return word;
                        }
                    }
                    break;
            }
        }
    }

    /// <summary>The text blocks inside a control, in the order they were added (a table's cells: row by row).</summary>
    private static IEnumerable<TextBlock> TextBlocksIn(DependencyObject root)
    {
        foreach (var child in LogicalTreeHelper.GetChildren(root).OfType<DependencyObject>())
        {
            if (child is TextBlock text)
            {
                yield return text;
                continue;
            }
            foreach (var inner in TextBlocksIn(child))
            {
                yield return inner;
            }
        }
    }

    /// <summary>The word, where it is, and whether it is in view (for checks).</summary>
    public string Describe()
    {
        if (_current is null || Word is null)
        {
            return "no word highlighted";
        }
        var at = _current.Start.GetCharacterRect(LogicalDirection.Forward);
        var scroller = FindScroller(_box);
        var inView = "no scroller";
        if (scroller is not null && !at.IsEmpty)
        {
            var top = _box.TransformToAncestor(scroller).Transform(at.TopLeft).Y;
            inView = $"{top:0} in a viewport of {scroller.ViewportHeight:0} (offset {scroller.VerticalOffset:0})";
        }
        return $"'{Word}' (shown word {ShownIndex}) at {at.Left:0},{at.Top:0} in the answer; {inView}; marker {(_marker is null ? "none" : "shown")}";
    }

    /// <summary>Whether the highlighted word is inside the visible part of what scrolls the text.</summary>
    public bool InView()
    {
        if (_current is null || FindScroller(_box) is not { } scroller)
        {
            return false;
        }
        var at = _current.Start.GetCharacterRect(LogicalDirection.Forward);
        if (at.IsEmpty)
        {
            return false;
        }
        var top = _box.TransformToAncestor(scroller).Transform(at.TopLeft).Y;
        return top >= 0 && top + at.Height <= scroller.ViewportHeight + 1;
    }

    private static ScrollViewer? FindScroller(DependencyObject from)
    {
        for (var p = VisualTreeHelper.GetParent(from); p is not null; p = VisualTreeHelper.GetParent(p))
        {
            if (p is ScrollViewer scroller)
            {
                return scroller;
            }
        }
        return null;
    }

    /// <summary>The yellow mark over the word, drawn above the text.</summary>
    private sealed class Marker : Adorner
    {
        private static readonly Brush Fill = Frozen(Color.FromArgb(0x8C, 0xFF, 0xE0, 0x1A));
        private TextRange? _range;

        public Marker(UIElement adorned) : base(adorned)
        {
            IsHitTestVisible = false;
        }

        public void Show(TextRange? range)
        {
            _range = range;
            InvalidateVisual();
        }

        protected override void OnRender(DrawingContext dc)
        {
            if (_range is null)
            {
                return;
            }
            var start = CharacterRect(_range.Start, LogicalDirection.Forward, AdornedElement);
            var end = CharacterRect(_range.End, LogicalDirection.Backward, AdornedElement);
            if (start.IsEmpty || end.IsEmpty)
            {
                return;
            }
            // One line (a word does not wrap); if the end is on another line, mark to the start's line only.
            var right = Math.Abs(end.Top - start.Top) < start.Height / 2 ? end.Right : start.Right + 40;
            var box = new Rect(start.Left - 1.5, start.Top, Math.Max(2, right - start.Left + 3), start.Height);
            dc.DrawRoundedRectangle(Fill, null, box, 2.5, 2.5);
        }

        private static Brush Frozen(Color color)
        {
            var brush = new SolidColorBrush(color);
            brush.Freeze();
            return brush;
        }
    }
}
