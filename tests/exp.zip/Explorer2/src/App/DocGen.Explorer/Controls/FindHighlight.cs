using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using DocGen.Explorer.Engine.Text;

namespace DocGen.Explorer.Controls;

/// <summary>
/// Find in rendered text (a page's FlowDocument, an answer, a TextBlock): each match as a <see cref="TextRange"/>, found
/// across runs (a word half in bold still matches). Blocks are separated by a line break, so a match never spans two
/// paragraphs.
/// </summary>
public static class TextFind
{
    public static List<TextRange> Find(TextPointer start, TextPointer end, string? query, FindOptions? options = null)
    {
        if (string.IsNullOrEmpty(query))
        {
            return [];
        }
        // The text as one string, with where each piece of it is.
        var text = new StringBuilder();
        var pieces = new List<(int At, TextPointer Pointer, int Length)>();
        // Controls embedded in the text (a table that scrolls sideways in a narrow answer), searched in their own right.
        var embedded = new List<(int At, DependencyObject Element)>();
        for (var p = start; p is not null && p.CompareTo(end) < 0;)
        {
            switch (p.GetPointerContext(LogicalDirection.Forward))
            {
                case TextPointerContext.Text:
                {
                    var run = p.GetTextInRun(LogicalDirection.Forward);
                    var room = p.GetOffsetToPosition(end);
                    if (run.Length > room)
                    {
                        run = run[..Math.Max(0, room)];
                    }
                    pieces.Add((text.Length, p, run.Length));
                    text.Append(run);
                    p = p.GetPositionAtOffset(run.Length) ?? end;
                    if (run.Length == 0)
                    {
                        p = p.GetNextContextPosition(LogicalDirection.Forward);
                    }
                    break;
                }
                case TextPointerContext.EmbeddedElement when p.GetAdjacentElement(LogicalDirection.Forward) is DependencyObject element:
                    embedded.Add((text.Length, element));
                    text.Append('\n');
                    p = p.GetNextContextPosition(LogicalDirection.Forward);
                    break;
                case TextPointerContext.ElementEnd when p.Parent is Block or LineBreak or ListItem or TableCell:
                case TextPointerContext.ElementStart when p.GetAdjacentElement(LogicalDirection.Forward) is LineBreak:
                    text.Append('\n');
                    p = p.GetNextContextPosition(LogicalDirection.Forward);
                    break;
                default:
                    p = p.GetNextContextPosition(LogicalDirection.Forward);
                    break;
            }
        }
        var found = new List<(int At, TextRange Range)>();
        foreach (var match in TextMatcher.Matches(text.ToString(), query, options))
        {
            if (Pointer(pieces, match.Start, forward: true) is { } from && Pointer(pieces, match.Start + match.Length, forward: false) is { } to)
            {
                found.Add((match.Start, new TextRange(from, to)));
            }
        }
        // A table's cells, row by row, at the table's place in the text.
        foreach (var (at, element) in embedded)
        {
            foreach (var cell in TextBlocksIn(element))
            {
                found.AddRange(Find(cell.ContentStart, cell.ContentEnd, query, options).Select(r => (at, r)));
            }
        }
        return found.Select((f, i) => (f, i)).OrderBy(x => x.f.At).ThenBy(x => x.i).Select(x => x.f.Range).ToList();
    }

    /// <summary>The text blocks inside a control, in the order they were added (a table's cells: row by row).</summary>
    public static IEnumerable<TextBlock> TextBlocksIn(DependencyObject root)
    {
        foreach (var child in LogicalTreeHelper.GetChildren(root).OfType<DependencyObject>())
        {
            if (child is TextBlock text)
            {
                yield return text;
                continue;
            }
            foreach (var inner in TextBlocksIn(child))
            {
                yield return inner;
            }
        }
    }

    private static TextPointer? Pointer(List<(int At, TextPointer Pointer, int Length)> pieces, int offset, bool forward)
    {
        // The piece holding the offset (an end offset may sit exactly at a piece's end).
        var lo = 0;
        var hi = pieces.Count - 1;
        while (lo <= hi)
        {
            var mid = (lo + hi) / 2;
            var (at, pointer, length) = pieces[mid];
            if (offset < at)
            {
                hi = mid - 1;
            }
            else if (offset > at + length || (forward && offset == at + length && mid + 1 < pieces.Count && pieces[mid + 1].At == offset))
            {
                lo = mid + 1;
            }
            else
            {
                return pointer.GetPositionAtOffset(offset - at);
            }
        }
        return null;
    }
}

/// <summary>
/// The yellow marks of Find, drawn over text without changing it (as Visual Studio does): every match in yellow, the
/// current one in orange. Redrawn as the text scrolls or reflows.
/// </summary>
public sealed class FindHighlightAdorner : Adorner
{
    private static readonly Brush MatchFill = Frozen(Color.FromArgb(0x99, 0xFF, 0xE0, 0x1A));
    private static readonly Brush CurrentFill = Frozen(Color.FromArgb(0xCC, 0xFF, 0x96, 0x32));
    private static readonly Pen CurrentPen = FrozenPen(Color.FromArgb(0xFF, 0xD9, 0x6A, 0x00));

    private IReadOnlyList<TextRange> _ranges = [];
    private int _current = -1;

    // Each match's boxes where the text lays them out (the document's own view): measured once, then only moved as the
    // view scrolls — measuring forces layout, so it is never done on every frame.
    private List<(int Index, Rect Box)>? _boxes;
    private Visual? _view;
    private bool _redrawQueued;

    private FindHighlightAdorner(UIElement host) : base(host)
    {
        IsHitTestVisible = false;
    }

    /// <summary>Draws again soon (once, however many times it is asked before then).</summary>
    private void Redraw(bool remeasure)
    {
        if (remeasure)
        {
            _boxes = null;
        }
        if (_redrawQueued)
        {
            return;
        }
        _redrawQueued = true;
        Dispatcher.BeginInvoke(() =>
        {
            _redrawQueued = false;
            InvalidateVisual();
        }, System.Windows.Threading.DispatcherPriority.Render);
    }

    /// <summary>The marks over <paramref name="host"/> (made on first use; null when it has no adorner layer yet).</summary>
    public static FindHighlightAdorner? For(UIElement host, bool create = true)
    {
        if (AdornerLayer.GetAdornerLayer(host) is not { } layer)
        {
            return null;
        }
        if (layer.GetAdorners(host)?.OfType<FindHighlightAdorner>().FirstOrDefault() is { } existing)
        {
            return existing;
        }
        if (!create)
        {
            return null;
        }
        var adorner = new FindHighlightAdorner(host);
        layer.Add(adorner);
        if (host is FrameworkElement element)
        {
            // Text reflows when the host's size changes: measure again. Scrolling (inside the host, or of what holds
            // it) only moves the marks.
            element.SizeChanged += (_, _) => adorner.Redraw(remeasure: true);
            element.AddHandler(ScrollViewer.ScrollChangedEvent, new ScrollChangedEventHandler((_, _) => adorner.Redraw(remeasure: false)), handledEventsToo: true);
            if (Ancestor<ScrollViewer>(element) is { } outer)
            {
                outer.ScrollChanged += (_, _) => adorner.Redraw(remeasure: false);
            }
        }
        return adorner;
    }

    /// <summary>Removes the marks from <paramref name="host"/>.</summary>
    public static void Clear(UIElement host)
    {
        if (AdornerLayer.GetAdornerLayer(host) is { } layer && layer.GetAdorners(host) is { } adorners)
        {
            foreach (var adorner in adorners.OfType<FindHighlightAdorner>())
            {
                layer.Remove(adorner);
            }
        }
    }

    public void Show(IReadOnlyList<TextRange> ranges, int current)
    {
        var same = ReferenceEquals(ranges, _ranges) || (ranges.Count == _ranges.Count && ranges.Zip(_ranges).All(p => p.First.Start.CompareTo(p.Second.Start) == 0 && p.First.End.CompareTo(p.Second.End) == 0));
        _ranges = ranges;
        _current = current;
        Redraw(remeasure: !same);
    }

    private static T? Ancestor<T>(DependencyObject from) where T : DependencyObject
    {
        for (var p = VisualTreeHelper.GetParent(from); p is not null; p = VisualTreeHelper.GetParent(p))
        {
            if (p is T found)
            {
                return found;
            }
        }
        return null;
    }

    protected override void OnRender(DrawingContext dc)
    {
        if (_ranges.Count == 0)
        {
            return;
        }
        var host = AdornedElement;
        var clip = new Rect(host.RenderSize);
        // Inside something that scrolls (a code block in a page): only what is in its view.
        for (var p = VisualTreeHelper.GetParent(host); p is not null; p = VisualTreeHelper.GetParent(p))
        {
            if (p is ScrollViewer outer)
            {
                try
                {
                    var view = outer.TransformToDescendant(host).TransformBounds(new Rect(0, 0, outer.ActualWidth, outer.ActualHeight));
                    clip.Intersect(view);
                }
                catch (InvalidOperationException)
                {
                }
                break;
            }
        }
        if (clip.IsEmpty)
        {
            return;
        }
        if (_boxes is null)
        {
            _boxes = [];
            _view = null;
            for (var i = 0; i < _ranges.Count; i++)
            {
                foreach (var box in BoxesInView(_ranges[i], host, out var view))
                {
                    _view ??= view;
                    _boxes.Add((i, box));
                }
            }
        }
        GeneralTransform? toHost = null;
        if (_view is not null && !ReferenceEquals(_view, host))
        {
            try
            {
                toHost = _view.TransformToAncestor(host);
            }
            catch (InvalidOperationException)
            {
                return;
            }
        }
        dc.PushClip(new RectangleGeometry(clip));
        foreach (var (index, inView) in _boxes)
        {
            var box = toHost?.TransformBounds(inView) ?? inView;
            if (!box.IntersectsWith(clip))
            {
                continue;
            }
            if (index == _current)
            {
                dc.DrawRoundedRectangle(CurrentFill, CurrentPen, box, 2, 2);
            }
            else
            {
                dc.DrawRoundedRectangle(MatchFill, null, box, 2, 2);
            }
        }
        dc.Pop();
    }

    /// <summary>A range's boxes in the host's coordinates: one per line it covers.</summary>
    public static IEnumerable<Rect> Boxes(TextRange range, UIElement host)
    {
        var boxes = BoxesInView(range, host, out var view).ToList();
        if (view is null || ReferenceEquals(view, host))
        {
            return boxes;
        }
        try
        {
            var toHost = view.TransformToAncestor(host);
            return boxes.Select(toHost.TransformBounds).ToList();
        }
        catch (InvalidOperationException)
        {
            return [];
        }
    }

    /// <summary>A range's boxes where the text is laid out (its document view, which scrolls inside the host).</summary>
    private static List<Rect> BoxesInView(TextRange range, UIElement host, out Visual? view)
    {
        view = RenderScope(range.Start, host);
        return LineBoxes(range).ToList();
    }

    private static IEnumerable<Rect> LineBoxes(TextRange range)
    {
        static Rect Map(Rect r) => r;

        var start = range.Start.GetCharacterRect(LogicalDirection.Forward);
        var end = range.End.GetCharacterRect(LogicalDirection.Backward);
        if (start.IsEmpty || end.IsEmpty)
        {
            yield break;
        }
        if (Math.Abs(end.Top - start.Top) < start.Height / 2)
        {
            yield return Map(new Rect(start.Left - 1, start.Top, Math.Max(2, end.Right - start.Left + 2), Math.Max(start.Height, end.Height)));
            yield break;
        }
        // Over several lines: walk the characters and start a new box at each line.
        var lineStart = start;
        var last = start;
        var p = range.Start;
        for (var guard = 0; p is not null && p.CompareTo(range.End) < 0 && guard < 2000; guard++)
        {
            var next = p.GetPositionAtOffset(1, LogicalDirection.Forward);
            if (next is null)
            {
                break;
            }
            var r = next.GetCharacterRect(LogicalDirection.Backward);
            if (!r.IsEmpty && Math.Abs(r.Top - lineStart.Top) >= lineStart.Height / 2)
            {
                yield return Map(new Rect(lineStart.Left - 1, lineStart.Top, Math.Max(2, last.Right - lineStart.Left + 2), lineStart.Height));
                lineStart = p.GetCharacterRect(LogicalDirection.Forward) is { IsEmpty: false } s && Math.Abs(s.Top - r.Top) < r.Height / 2 ? s : r;
            }
            if (!r.IsEmpty)
            {
                last = r;
            }
            p = next;
        }
        yield return Map(new Rect(lineStart.Left - 1, lineStart.Top, Math.Max(2, end.Right - lineStart.Left + 2), lineStart.Height));
    }

    /// <summary>The element whose coordinates GetCharacterRect uses: the document's view inside a viewer or a box.</summary>
    private static Visual? RenderScope(TextPointer pointer, UIElement host)
    {
        if (host is TextBlock)
        {
            return host;
        }
        // Text in a control inside the document (a table cell): measured in that cell.
        DependencyObject? owner = pointer.Parent;
        while (owner is TextElement element)
        {
            owner = element.Parent;
        }
        if (owner is TextBlock cell && cell.IsDescendantOf(host))
        {
            return cell;
        }
        // A FlowDocument's view (the internal FlowDocumentView) is the visual whose content is the document's text.
        return FindDescendant(host, v => v.GetType().Name == "FlowDocumentView") ?? host;
    }

    private static Visual? FindDescendant(DependencyObject from, Func<DependencyObject, bool> match)
    {
        var count = VisualTreeHelper.GetChildrenCount(from);
        for (var i = 0; i < count; i++)
        {
            var child = VisualTreeHelper.GetChild(from, i);
            if (match(child))
            {
                return child as Visual;
            }
            if (FindDescendant(child, match) is { } found)
            {
                return found;
            }
        }
        return null;
    }

    private static Brush Frozen(Color color)
    {
        var brush = new SolidColorBrush(color);
        brush.Freeze();
        return brush;
    }

    private static Pen FrozenPen(Color color)
    {
        var pen = new Pen(new SolidColorBrush(color), 1);
        pen.Freeze();
        return pen;
    }
}

/// <summary>
/// <c>ui:TextHighlight.Query</c>: marks every occurrence of a word in a RichTextBox (an answer) or TextBlock (a question)
/// in yellow — the search in Ask.
/// </summary>
public static class TextHighlight
{
    public static readonly DependencyProperty QueryProperty = DependencyProperty.RegisterAttached("Query", typeof(string), typeof(TextHighlight),
        new PropertyMetadata(null, (d, _) => Refresh(d)));

    public static string? GetQuery(DependencyObject d) => (string?)d.GetValue(QueryProperty);
    public static void SetQuery(DependencyObject d, string? value) => d.SetValue(QueryProperty, value);

    private static void Refresh(DependencyObject d)
    {
        if (d is not FrameworkElement element)
        {
            return;
        }
        if (!element.IsLoaded)
        {
            element.Loaded -= OnLoaded;
            element.Loaded += OnLoaded;
            return;
        }
        // After the text is laid out (a new answer renders first).
        element.Dispatcher.BeginInvoke(() => Apply(element), System.Windows.Threading.DispatcherPriority.Loaded);
    }

    private static void OnLoaded(object sender, RoutedEventArgs e)
    {
        var element = (FrameworkElement)sender;
        element.Loaded -= OnLoaded;
        Refresh(element);
    }

    private static void Apply(FrameworkElement element)
    {
        var query = GetQuery(element);
        if (string.IsNullOrWhiteSpace(query))
        {
            FindHighlightAdorner.Clear(element);
            return;
        }
        var ranges = element switch
        {
            RichTextBox box => TextFind.Find(box.Document.ContentStart, box.Document.ContentEnd, query),
            TextBlock block => TextFind.Find(block.ContentStart, block.ContentEnd, query),
            _ => [],
        };
        if (ranges.Count == 0)
        {
            FindHighlightAdorner.Clear(element);
            return;
        }
        FindHighlightAdorner.For(element)?.Show(ranges, -1);
    }
}
