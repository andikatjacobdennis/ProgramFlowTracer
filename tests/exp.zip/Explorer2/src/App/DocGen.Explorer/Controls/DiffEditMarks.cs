using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace DocGen.Explorer.Controls;

/// <summary>
/// Drawn behind a text box being edited in a diff: a gutter of line numbers and, for each line the comparison marks
/// "Added", the green of an added line — kept level with the text box's lines as it scrolls and as the text changes.
/// </summary>
public sealed class DiffEditMarks : FrameworkElement
{
    private TextBox? _editor;
    private IReadOnlyList<string> _marks = [];

    /// <summary>The gutter's width, left of the text box.</summary>
    public double GutterWidth { get; set; } = 52;

    /// <summary>The text box whose lines are marked (it sits right of the gutter, its top level with this element's).</summary>
    public TextBox? Editor
    {
        get => _editor;
        set
        {
            if (_editor is not null)
            {
                _editor.RemoveHandler(ScrollViewer.ScrollChangedEvent, new ScrollChangedEventHandler(OnScroll));
                _editor.TextChanged -= OnTextChanged;
                _editor.SizeChanged -= OnSizeChanged;
            }
            _editor = value;
            if (_editor is not null)
            {
                _editor.AddHandler(ScrollViewer.ScrollChangedEvent, new ScrollChangedEventHandler(OnScroll));
                _editor.TextChanged += OnTextChanged;
                _editor.SizeChanged += OnSizeChanged;
            }
            InvalidateVisual();
        }
    }

    /// <summary>One entry per line of the text: "Added" or "".</summary>
    public IReadOnlyList<string> Marks
    {
        get => _marks;
        set
        {
            _marks = value ?? [];
            InvalidateVisual();
        }
    }

    private void OnScroll(object sender, ScrollChangedEventArgs e) => InvalidateVisual();

    private void OnTextChanged(object sender, TextChangedEventArgs e) => InvalidateVisual();

    private void OnSizeChanged(object sender, SizeChangedEventArgs e) => InvalidateVisual();

    protected override void OnRender(DrawingContext dc)
    {
        dc.DrawRectangle(Brush("Brush.Code.Gutter"), null, new Rect(0, 0, GutterWidth, ActualHeight));
        dc.DrawRectangle(Brush("Brush.Border"), null, new Rect(GutterWidth - 1, 0, 1, ActualHeight));
        if (_editor is not { IsLoaded: true } editor || editor.LineCount <= 0)
        {
            return;
        }
        var first = editor.GetFirstVisibleLineIndex();
        var last = editor.GetLastVisibleLineIndex();
        if (first < 0)
        {
            return;
        }
        var origin = editor.TranslatePoint(new Point(0, 0), this);
        var lineHeight = LineHeightOf(editor);
        var firstRect = editor.GetRectFromCharacterIndex(editor.GetCharacterIndexFromLineIndex(first));
        if (firstRect.IsEmpty)
        {
            return;
        }
        var top = origin.Y + firstRect.Top;
        var clipTop = origin.Y;
        var clipBottom = origin.Y + editor.ViewportHeight();
        var added = Brush("Brush.Diff.AddedLine");
        var addedGutter = Brush("Brush.Diff.AddedGutter");
        var number = Brush("Brush.Code.LineNumber");
        var typeface = new Typeface(editor.FontFamily, FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
        var dpi = VisualTreeHelper.GetDpi(this).PixelsPerDip;
        dc.PushClip(new RectangleGeometry(new Rect(0, clipTop, ActualWidth, Math.Max(0, clipBottom - clipTop))));
        for (var line = first; line <= last + 1 && line < editor.LineCount; line++)
        {
            var y = top + (line - first) * lineHeight;
            if (line < _marks.Count && _marks[line] == "Added")
            {
                dc.DrawRectangle(addedGutter, null, new Rect(0, y, GutterWidth - 1, lineHeight));
                dc.DrawRectangle(added, null, new Rect(GutterWidth, y, Math.Max(0, ActualWidth - GutterWidth), lineHeight));
            }
            var text = new FormattedText((line + 1).ToString(CultureInfo.InvariantCulture), CultureInfo.InvariantCulture, FlowDirection.LeftToRight,
                typeface, editor.FontSize - 1, number, dpi);
            dc.DrawText(text, new Point(GutterWidth - 9 - text.Width, y + (lineHeight - text.Height) / 2));
        }
        dc.Pop();
    }

    private Brush? Brush(string key) => TryFindResource(key) as Brush;

    /// <summary>The height of one line of the text box: its TextBlock.LineHeight when set, else its font's line spacing.</summary>
    public static double LineHeightOf(TextBox editor)
        => TextBlock.GetLineHeight(editor) is var set && !double.IsNaN(set) && set > 0 ? set : editor.FontFamily.LineSpacing * editor.FontSize;
}

internal static class TextBoxViewport
{
    /// <summary>The height of the text box's visible text area (its scroll viewer's viewport), else its own height.</summary>
    public static double ViewportHeight(this TextBox box) => box.ViewportHeight > 0 ? box.ViewportHeight + box.Padding.Top + box.Padding.Bottom : box.ActualHeight;
}
