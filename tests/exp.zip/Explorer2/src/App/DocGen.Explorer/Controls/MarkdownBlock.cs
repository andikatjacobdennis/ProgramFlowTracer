using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace DocGen.Explorer.Controls;

/// <summary>
/// Read-only, selectable Markdown that sizes to its content (for answers, FAQ entries and other inline text).
/// Links are passed to <see cref="LinkCommand"/>.
/// </summary>
public sealed class MarkdownBlock : RichTextBox
{
    public static readonly DependencyProperty MarkdownProperty = DependencyProperty.Register(nameof(Markdown), typeof(string), typeof(MarkdownBlock),
        new PropertyMetadata(null, (d, _) => ((MarkdownBlock)d).Render()));

    public static readonly DependencyProperty LinkCommandProperty = DependencyProperty.Register(nameof(LinkCommand), typeof(ICommand), typeof(MarkdownBlock));

    public static readonly DependencyProperty CitationsProperty = DependencyProperty.Register(nameof(Citations), typeof(bool), typeof(MarkdownBlock), new PropertyMetadata(false));

    public MarkdownBlock()
    {
        IsReadOnly = true;
        // Right-click: Copy, Select all, Summarise selection.
        ContextMenu = Infrastructure.SummariseSelection.Menu(this);
        IsDocumentEnabled = true;
        BorderThickness = new Thickness(0);
        Background = System.Windows.Media.Brushes.Transparent;
        Padding = new Thickness(0);
        VerticalScrollBarVisibility = ScrollBarVisibility.Disabled;
        HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
        FocusVisualStyle = null;
        Cursor = Cursors.Arrow;
        SetResourceReference(ForegroundProperty, "Brush.Text");
        SetResourceReference(SelectionBrushProperty, "Brush.Accent");
        Document = new System.Windows.Documents.FlowDocument();
        // A RichTextBox formats its document at a width of its own choosing, which squeezed the last column of a table
        // to one character. Format at exactly the width shown.
        SizeChanged += (_, e) =>
        {
            if (e.WidthChanged)
            {
                FitPage();
            }
        };
        // Read aloud: the word being said is highlighted.
        Highlight = new SpokenWordHighlight(this, () => Markdown);
        // Let the mouse wheel scroll whatever contains the answer.
        PreviewMouseWheel += (s, e) =>
        {
            e.Handled = true;
            var parent = System.Windows.Media.VisualTreeHelper.GetParent(this) as UIElement;
            parent?.RaiseEvent(new MouseWheelEventArgs(e.MouseDevice, e.Timestamp, e.Delta) { RoutedEvent = MouseWheelEvent, Source = this });
        };
    }

    /// <summary>The highlight of the word being read aloud.</summary>
    public SpokenWordHighlight Highlight { get; }

    public string? Markdown
    {
        get => (string?)GetValue(MarkdownProperty);
        set => SetValue(MarkdownProperty, value);
    }

    public ICommand? LinkCommand
    {
        get => (ICommand?)GetValue(LinkCommandProperty);
        set => SetValue(LinkCommandProperty, value);
    }

    public bool Citations
    {
        get => (bool)GetValue(CitationsProperty);
        set => SetValue(CitationsProperty, value);
    }

    private void Render()
    {
        var rendered = MarkdownRenderer.Render(Markdown ?? "", new MarkdownRenderOptions
        {
            Compact = true,
            Citations = Citations,
            OnLink = url =>
            {
                if (LinkCommand?.CanExecute(url) == true)
                {
                    LinkCommand.Execute(url);
                }
            },
        });
        rendered.Document.SetResourceReference(System.Windows.Documents.FlowDocument.BackgroundProperty, "Brush.Window");
        rendered.Document.Background = System.Windows.Media.Brushes.Transparent;
        Document = rendered.Document;
        Highlight?.Reset();
        FitPage();
    }

    private void FitPage()
    {
        if (ActualWidth > 0 && Document is { } document)
        {
            document.PagePadding = new Thickness(0);
            document.PageWidth = Math.Max(1, ActualWidth - Padding.Left - Padding.Right - BorderThickness.Left - BorderThickness.Right);
        }
    }
}
