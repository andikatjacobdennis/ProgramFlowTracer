using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.Controls;

/// <summary>
/// A quiz score as a ring that fills to <see cref="Percent"/> while the number in the middle counts up from 0; it runs
/// each time it is shown with a new score. With motion reduced it is simply drawn full.
/// </summary>
public sealed class ScoreRing : FrameworkElement
{
    public static readonly DependencyProperty PercentProperty = DependencyProperty.Register(nameof(Percent), typeof(double), typeof(ScoreRing),
        new FrameworkPropertyMetadata(0.0, (d, _) => ((ScoreRing)d).Run()));

    public static readonly DependencyProperty FillProperty = DependencyProperty.Register(nameof(Fill), typeof(Brush), typeof(ScoreRing),
        new FrameworkPropertyMetadata(Brushes.Gray, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty TrackProperty = DependencyProperty.Register(nameof(Track), typeof(Brush), typeof(ScoreRing),
        new FrameworkPropertyMetadata(Brushes.LightGray, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty ForegroundProperty = DependencyProperty.Register(nameof(Foreground), typeof(Brush), typeof(ScoreRing),
        new FrameworkPropertyMetadata(Brushes.Black, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty CaptionProperty = DependencyProperty.Register(nameof(Caption), typeof(string), typeof(ScoreRing),
        new FrameworkPropertyMetadata("", FrameworkPropertyMetadataOptions.AffectsRender));

    /// <summary>What is drawn right now (animated from 0 to <see cref="Percent"/>).</summary>
    private static readonly DependencyProperty ShownProperty = DependencyProperty.Register("Shown", typeof(double), typeof(ScoreRing),
        new FrameworkPropertyMetadata(0.0, FrameworkPropertyMetadataOptions.AffectsRender));

    public ScoreRing()
    {
        IsVisibleChanged += (_, e) =>
        {
            if (e.NewValue is true)
            {
                Run();
            }
        };
        Unloaded += (_, _) => BeginAnimation(ShownProperty, null);
    }

    public double Percent { get => (double)GetValue(PercentProperty); set => SetValue(PercentProperty, value); }
    public Brush Fill { get => (Brush)GetValue(FillProperty); set => SetValue(FillProperty, value); }
    public Brush Track { get => (Brush)GetValue(TrackProperty); set => SetValue(TrackProperty, value); }
    public Brush Foreground { get => (Brush)GetValue(ForegroundProperty); set => SetValue(ForegroundProperty, value); }
    public string Caption { get => (string)GetValue(CaptionProperty); set => SetValue(CaptionProperty, value); }

    private void Run()
    {
        var target = Math.Clamp(Percent, 0, 100);
        if (Motion.Reduced || !IsVisible)
        {
            BeginAnimation(ShownProperty, null);
            SetValue(ShownProperty, target);
            return;
        }
        // Longer for a higher score, so every count-up feels about as quick.
        var ms = 500 + target * 8;
        BeginAnimation(ShownProperty, new DoubleAnimation(0, target, TimeSpan.FromMilliseconds(ms))
        {
            BeginTime = TimeSpan.FromMilliseconds(150),
            EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut },
        });
    }

    protected override Size MeasureOverride(Size availableSize) => new(Math.Min(120, availableSize.Width), Math.Min(120, availableSize.Height));

    protected override void OnRender(DrawingContext dc)
    {
        var size = Math.Min(ActualWidth, ActualHeight);
        if (size < 20)
        {
            return;
        }
        var thickness = Math.Max(4, size / 14);
        var center = new Point(ActualWidth / 2, ActualHeight / 2);
        var radius = (size - thickness) / 2;
        dc.DrawEllipse(null, new Pen(Track, thickness), center, radius, radius);
        var shown = (double)GetValue(ShownProperty);
        var fraction = Math.Clamp(shown / 100, 0, 1);
        if (fraction > 0.999)
        {
            dc.DrawEllipse(null, new Pen(Fill, thickness), center, radius, radius);
        }
        else if (fraction > 0)
        {
            var angle = fraction * 2 * Math.PI;
            var start = new Point(center.X, center.Y - radius);
            var end = new Point(center.X + radius * Math.Sin(angle), center.Y - radius * Math.Cos(angle));
            var figure = new PathFigure { StartPoint = start, IsClosed = false };
            figure.Segments.Add(new ArcSegment(end, new Size(radius, radius), 0, fraction > 0.5, SweepDirection.Clockwise, true));
            var geometry = new PathGeometry([figure]);
            dc.DrawGeometry(null, new Pen(Fill, thickness) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round }, geometry);
        }
        // The number in the middle, in the interface font at the heading size the app uses.
        var big = TryFindResource("FontSize.H1") is double h1 ? h1 : 21;
        var small = TryFindResource("FontSize.Small") is double s ? s : 11.5;
        var number = ChartText.Text(this, $"{Math.Round(shown):0}%", big, Foreground, FontWeights.SemiBold);
        var caption = string.IsNullOrEmpty(Caption) ? null : ChartText.Text(this, Caption, small, ChartText.Resource(this, "Brush.TextMuted", Foreground));
        var height = number.Height + (caption?.Height ?? 0);
        var top = center.Y - height / 2;
        dc.DrawText(number, new Point(center.X - number.Width / 2, top));
        if (caption is not null)
        {
            dc.DrawText(caption, new Point(center.X - caption.Width / 2, top + number.Height));
        }
    }
}

/// <summary>A thin bar that glides to its new <see cref="Value"/> (0–100) instead of jumping (quiz progress).</summary>
public sealed class LinearProgress : FrameworkElement
{
    public static readonly DependencyProperty ValueProperty = DependencyProperty.Register(nameof(Value), typeof(double), typeof(LinearProgress),
        new FrameworkPropertyMetadata(0.0, (d, e) => ((LinearProgress)d).Glide((double)e.NewValue)));

    public static readonly DependencyProperty FillProperty = DependencyProperty.Register(nameof(Fill), typeof(Brush), typeof(LinearProgress),
        new FrameworkPropertyMetadata(Brushes.Gray, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty TrackProperty = DependencyProperty.Register(nameof(Track), typeof(Brush), typeof(LinearProgress),
        new FrameworkPropertyMetadata(Brushes.LightGray, FrameworkPropertyMetadataOptions.AffectsRender));

    private static readonly DependencyProperty ShownProperty = DependencyProperty.Register("Shown", typeof(double), typeof(LinearProgress),
        new FrameworkPropertyMetadata(0.0, FrameworkPropertyMetadataOptions.AffectsRender));

    public LinearProgress()
    {
        Unloaded += (_, _) =>
        {
            BeginAnimation(ShownProperty, null);
            SetValue(ShownProperty, Value);
        };
    }

    public double Value { get => (double)GetValue(ValueProperty); set => SetValue(ValueProperty, value); }
    public Brush Fill { get => (Brush)GetValue(FillProperty); set => SetValue(FillProperty, value); }
    public Brush Track { get => (Brush)GetValue(TrackProperty); set => SetValue(TrackProperty, value); }

    private void Glide(double to)
    {
        to = Math.Clamp(to, 0, 100);
        if (Motion.Reduced || !IsLoaded || !IsVisible)
        {
            BeginAnimation(ShownProperty, null);
            SetValue(ShownProperty, to);
            return;
        }
        BeginAnimation(ShownProperty, new DoubleAnimation(to, TimeSpan.FromMilliseconds(420)) { EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut } });
    }

    protected override Size MeasureOverride(Size availableSize) => new(0, 6);

    protected override void OnRender(DrawingContext dc)
    {
        var w = ActualWidth;
        var h = ActualHeight;
        if (w <= 0 || h <= 0)
        {
            return;
        }
        var r = h / 2;
        dc.DrawRoundedRectangle(Track, null, new Rect(0, 0, w, h), r, r);
        var filled = w * Math.Clamp((double)GetValue(ShownProperty) / 100, 0, 1);
        if (filled > 0.5)
        {
            dc.DrawRoundedRectangle(Fill, null, new Rect(0, 0, Math.Max(filled, h), h), r, r);
        }
    }
}

/// <summary>
/// A light confetti burst for a passed quiz: a few dozen small pieces in the theme's colours thrown up from the middle,
/// falling and fading out over about a second and a half; then it stops drawing and lets go of the frame clock.
/// </summary>
public sealed class ConfettiBurst : FrameworkElement
{
    private sealed class Piece
    {
        public double X, Y, Vx, Vy, Angle, Spin, W, H;
        public Brush Brush = Brushes.Gray;
        public bool Round;
    }

    private const double Seconds = 1.5;
    private readonly List<Piece> _pieces = [];
    private readonly System.Diagnostics.Stopwatch _clock = new();
    private readonly Random _random = new();
    private bool _running;
    private TimeSpan _last;

    public ConfettiBurst()
    {
        IsHitTestVisible = false;
        Unloaded += (_, _) => Stop();
        IsVisibleChanged += (_, e) =>
        {
            if (e.NewValue is false)
            {
                Stop();
            }
        };
    }

    /// <summary>Throws one burst (nothing with motion reduced, or when the control is not on screen).</summary>
    public void Burst()
    {
        if (Motion.Reduced || !IsLoaded || !IsVisible || ActualWidth < 10)
        {
            return;
        }
        var brushes = new[] { "Brush.Accent", "Brush.Success", "Brush.Warning", "Brush.Info", "Brush.TextFaint", "Brush.BorderStrong" }
            .Select(k => TryFindResource(k) as Brush).OfType<Brush>().ToArray();
        if (brushes.Length == 0)
        {
            brushes = [Brushes.Gray];
        }
        _pieces.Clear();
        var originX = ActualWidth / 2;
        var originY = Math.Min(ActualHeight * 0.45, 160);
        for (var i = 0; i < 48; i++)
        {
            var angle = -Math.PI / 2 + (_random.NextDouble() - 0.5) * Math.PI * 1.2;
            var speed = 260 + _random.NextDouble() * 320;
            _pieces.Add(new Piece
            {
                X = originX + (_random.NextDouble() - 0.5) * 40,
                Y = originY,
                Vx = Math.Cos(angle) * speed,
                Vy = Math.Sin(angle) * speed,
                Angle = _random.NextDouble() * 360,
                Spin = (_random.NextDouble() - 0.5) * 720,
                W = 4 + _random.NextDouble() * 5,
                H = 3 + _random.NextDouble() * 4,
                Brush = brushes[_random.Next(brushes.Length)],
                Round = _random.NextDouble() < 0.3,
            });
        }
        _clock.Restart();
        _last = TimeSpan.Zero;
        if (!_running)
        {
            _running = true;
            CompositionTarget.Rendering += OnFrame;
        }
    }

    private void Stop()
    {
        if (_running)
        {
            _running = false;
            CompositionTarget.Rendering -= OnFrame;
        }
        _clock.Reset();
        _pieces.Clear();
        InvalidateVisual();
    }

    private void OnFrame(object? sender, EventArgs e)
    {
        var now = _clock.Elapsed;
        if (now.TotalSeconds >= Seconds)
        {
            Stop();
            return;
        }
        var dt = Math.Min(0.05, (now - _last).TotalSeconds);
        _last = now;
        foreach (var p in _pieces)
        {
            p.Vy += 900 * dt; // gravity
            p.Vx *= 1 - 1.2 * dt; // air
            p.X += p.Vx * dt;
            p.Y += p.Vy * dt;
            p.Angle += p.Spin * dt;
        }
        InvalidateVisual();
    }

    protected override Size MeasureOverride(Size availableSize) => new(0, 0);

    protected override void OnRender(DrawingContext dc)
    {
        if (!_running || _pieces.Count == 0)
        {
            return;
        }
        var t = _clock.Elapsed.TotalSeconds;
        // Full for most of the time, fading over the last half second.
        var opacity = Math.Clamp((Seconds - t) / 0.5, 0, 1);
        dc.PushOpacity(opacity);
        foreach (var p in _pieces)
        {
            dc.PushTransform(new RotateTransform(p.Angle, p.X, p.Y));
            if (p.Round)
            {
                dc.DrawEllipse(p.Brush, null, new Point(p.X, p.Y), p.H / 2 + 0.5, p.H / 2 + 0.5);
            }
            else
            {
                dc.DrawRectangle(p.Brush, null, new Rect(p.X - p.W / 2, p.Y - p.H / 2, p.W, p.H));
            }
            dc.Pop();
        }
        dc.Pop();
    }
}
