using System.Collections.Concurrent;
using System.Text.Json;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using DocGen.Explorer.Infrastructure;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.Wpf;

namespace DocGen.Explorer.Controls;

/// <summary>A drawn Mermaid diagram: the picture at its natural size, or why it could not be drawn.</summary>
/// <param name="Svg">The diagram as SVG (for "Download SVG").</param>
public sealed record MermaidImage(BitmapSource? Image, double Width, double Height, string? Error, string? Svg = null);

/// <summary>
/// Draws Mermaid diagrams with mermaid.js — every kind (flowcharts, sequence, class, state, ER, Gantt, pie…), as a browser
/// does — in one WebView2 kept off screen, and hands back a picture. A picture rather than a live browser
/// in the page: browsers hosted in WPF float above everything and ignore scrolling. One diagram is drawn at a time;
/// drawings are cached by code and theme. Without the WebView2 runtime it says so, and the code is shown instead.
/// </summary>
public static class MermaidRenderer
{
    private const string Host = "docgen-mermaid.local";
    private const int MaxSide = 6000;
    private static readonly SemaphoreSlim Gate = new(1, 1);
    private static readonly ConcurrentDictionary<string, MermaidImage> Cache = new(StringComparer.Ordinal);
    private static Window? _window;
    private static WebView2? _view;
    private static Task? _ready;
    private static TaskCompletionSource<JsonElement>? _pending;
    private static string? _unavailable;
    private static int _requests;

    /// <summary>Whether the ELK layout engine loaded (diagrams whose configuration says <c>layout: elk</c> use it).</summary>
    public static bool ElkAvailable { get; private set; }

    /// <summary>Where WebView2 keeps its profile (set by the app to the data folder).</summary>
    public static string? UserDataFolder { get; set; }

    public static bool TryGetCached(string code, bool dark, out MermaidImage image) => Cache.TryGetValue(Key(code, dark), out image!);

    private static string Key(string code, bool dark) => (dark ? "d:" : "l:") + Prepare(code);

    /// <summary>
    /// The code as drawn: sequence diagrams are numbered (Mermaid's autonumber), so each message in a flow has its step
    /// number, as in a program-flow table.
    /// </summary>
    public static string Prepare(string code)
    {
        var lines = code.Trim().Replace("\r\n", "\n").Split('\n').ToList();
        // After the front matter (the "---" block of configuration), if there is one.
        var body = 0;
        if (lines.Count > 0 && lines[0].Trim() == "---")
        {
            var close = lines.FindIndex(1, l => l.Trim() == "---");
            body = close < 0 ? 0 : close + 1;
        }
        var first = lines.FindIndex(body, l => l.Trim().Length > 0 && !l.TrimStart().StartsWith("%%", StringComparison.Ordinal));
        if (first >= 0 && lines[first].Trim().StartsWith("sequenceDiagram", StringComparison.Ordinal)
            && !lines.Any(l => l.Trim().StartsWith("autonumber", StringComparison.Ordinal)))
        {
            lines.Insert(first + 1, "    autonumber");
        }
        return string.Join("\n", lines);
    }

    /// <summary>How many times larger than shown a diagram is drawn (sharp when zoomed in), within a pixel budget.</summary>
    private static double ScaleFor(double width, double height) => Math.Clamp(Math.Min(8000 / Math.Max(width, 1), 8000 / Math.Max(height, 1)), 1, 3);

    /// <summary>Draws <paramref name="code"/> (call on the UI thread).</summary>
    public static async Task<MermaidImage> RenderAsync(string code, bool dark)
    {
        var key = Key(code, dark);
        if (Cache.TryGetValue(key, out var cached))
        {
            return cached;
        }
        if (_unavailable is not null)
        {
            return new MermaidImage(null, 0, 0, _unavailable);
        }
        await Gate.WaitAsync();
        try
        {
            if (Cache.TryGetValue(key, out cached))
            {
                return cached;
            }
            _ready ??= StartAsync();
            await _ready;
            if (_unavailable is not null || _view?.CoreWebView2 is not { } core)
            {
                return new MermaidImage(null, 0, 0, _unavailable ?? "The diagram renderer is not available.");
            }
            var id = ++_requests;
            _pending = new TaskCompletionSource<JsonElement>(TaskCreationOptions.RunContinuationsAsynchronously);
            // First measure (scale 1), then draw at the sharper scale that fits the pixel budget.
            core.PostWebMessageAsJson(JsonSerializer.Serialize(new { id, code = Prepare(code), dark, scale = 1 }));
            var finished = await Task.WhenAny(_pending.Task, Task.Delay(TimeSpan.FromSeconds(15)));
            if (finished != _pending.Task)
            {
                return Remember(key, new MermaidImage(null, 0, 0, "Drawing the diagram took too long."));
            }
            var reply = _pending.Task.Result;
            if (reply.TryGetProperty("error", out var error))
            {
                return Remember(key, new MermaidImage(null, 0, 0, error.GetString()));
            }
            var width = Math.Clamp(reply.GetProperty("width").GetDouble(), 16, MaxSide);
            var height = Math.Clamp(reply.GetProperty("height").GetDouble(), 16, MaxSide);
            var svg = reply.TryGetProperty("svg", out var svgText) ? svgText.GetString() : null;
            var scale = ScaleFor(width, height);
            if (scale > 1.01)
            {
                // Drawn again at the sharper scale (the page draws the SVG on a canvas; no window size limits).
                _pending = new TaskCompletionSource<JsonElement>(TaskCreationOptions.RunContinuationsAsynchronously);
                core.PostWebMessageAsJson(JsonSerializer.Serialize(new { id = ++_requests, code = Prepare(code), dark, scale }));
                if (await Task.WhenAny(_pending.Task, Task.Delay(TimeSpan.FromSeconds(15))) == _pending.Task)
                {
                    reply = _pending.Task.Result;
                }
            }
            BitmapImage bitmap;
            if (reply.TryGetProperty("png", out var pngText) && pngText.GetString() is { Length: > 0 } base64)
            {
                bitmap = Decode(Convert.FromBase64String(base64));
            }
            else
            {
                // The canvas could not take it: capture the page as shown (size limited to the screen).
                _view.Width = width;
                _view.Height = height;
                _window!.Width = width + 40;
                _window.Height = height + 40;
                _view.UpdateLayout();
                await Task.Delay(150);
                using var png = new MemoryStream();
                await core.CapturePreviewAsync(CoreWebView2CapturePreviewImageFormat.Png, png);
                bitmap = Decode(png.ToArray());
            }
            return Remember(key, new MermaidImage(bitmap, width, height, null, svg));
        }
        catch (Exception ex) when (ex is InvalidOperationException or System.Runtime.InteropServices.COMException or WebView2RuntimeNotFoundException or IOException or NotSupportedException or JsonException)
        {
            Logging.Error(ex, "Mermaid");
            return new MermaidImage(null, 0, 0, "The diagram could not be drawn: " + ex.Message);
        }
        finally
        {
            Gate.Release();
        }
    }

    /// <summary>The diagrams whose SVG the page holds (it keeps six); the SVG is sent only when it is not there.</summary>
    private static readonly List<string> RegionKeys = [];

    /// <summary>
    /// Draws the part <paramref name="region"/> (in the diagram's own units) of a drawn diagram from its SVG, at
    /// <paramref name="scale"/> pixels per unit — what the viewer shows when zoomed in, sharp at any zoom. Null when
    /// it cannot (no SVG, no renderer).
    /// </summary>
    public static async Task<BitmapSource?> RenderRegionAsync(MermaidImage diagram, Rect region, double scale)
    {
        if (diagram.Svg is not { Length: > 0 } svg || _unavailable is not null || region.Width <= 0 || region.Height <= 0)
        {
            return null;
        }
        await Gate.WaitAsync();
        try
        {
            _ready ??= StartAsync();
            await _ready;
            if (_unavailable is not null || _view?.CoreWebView2 is not { } core)
            {
                return null;
            }
            var key = $"{svg.Length}:{svg.GetHashCode()}";
            for (var attempt = 0; attempt < 2; attempt++)
            {
                var send = attempt > 0 || !RegionKeys.Contains(key);
                _pending = new TaskCompletionSource<JsonElement>(TaskCreationOptions.RunContinuationsAsynchronously);
                core.PostWebMessageAsJson(JsonSerializer.Serialize(new
                {
                    kind = "region", id = ++_requests, key, svg = send ? svg : null, pad = Pad,
                    innerWidth = diagram.Width - 2 * Pad, innerHeight = diagram.Height - 2 * Pad,
                    x = region.X, y = region.Y, w = region.Width, h = region.Height, scale,
                }));
                if (await Task.WhenAny(_pending.Task, Task.Delay(TimeSpan.FromSeconds(10))) != _pending.Task)
                {
                    return null;
                }
                var reply = _pending.Task.Result;
                if (reply.TryGetProperty("missing", out _))
                {
                    continue; // the page let it go: send the SVG again
                }
                if (send)
                {
                    RegionKeys.Remove(key);
                    RegionKeys.Add(key);
                    if (RegionKeys.Count > 6)
                    {
                        RegionKeys.Clear(); // the page clears its six at the same point
                        RegionKeys.Add(key);
                    }
                }
                return reply.TryGetProperty("png", out var png) && png.GetString() is { Length: > 0 } base64 ? Decode(Convert.FromBase64String(base64)) : null;
            }
            return null;
        }
        catch (Exception ex) when (ex is InvalidOperationException or System.Runtime.InteropServices.COMException or IOException or NotSupportedException or JsonException or FormatException)
        {
            Logging.Error(ex, "Mermaid region");
            return null;
        }
        finally
        {
            Gate.Release();
        }
    }

    /// <summary>The padding render.html puts around a diagram.</summary>
    private const double Pad = 12;

    private static BitmapImage Decode(byte[] png)
    {
        var bitmap = new BitmapImage();
        bitmap.BeginInit();
        bitmap.CacheOption = BitmapCacheOption.OnLoad;
        bitmap.StreamSource = new MemoryStream(png);
        bitmap.EndInit();
        bitmap.Freeze();
        return bitmap;
    }

    private static MermaidImage Remember(string key, MermaidImage image)
    {
        if (Cache.Count > 300)
        {
            Cache.Clear();
        }
        Cache[key] = image;
        return image;
    }

    /// <summary>
    /// The folder of mermaid.js, its page and the ELK layout: beside the program when it is complete there, else unpacked
    /// from the program itself into this build's cache folder (<see cref="AppCaches"/>) — so a setup that ships only some
    /// of the files still draws every diagram. Null when neither has them.
    /// </summary>
    public static string? Assets()
    {
        var beside = Path.Combine(AppContext.BaseDirectory, "Assets", "mermaid");
        if (File.Exists(Path.Combine(beside, "mermaid.min.js")) && File.Exists(Path.Combine(beside, "elk", "mermaid-layout-elk.esm.min.mjs")))
        {
            return beside;
        }
        var assembly = typeof(MermaidRenderer).Assembly;
        var names = assembly.GetManifestResourceNames().Where(n => n.StartsWith("mermaid/", StringComparison.Ordinal)).ToList();
        if (names.Count == 0)
        {
            return File.Exists(Path.Combine(beside, "mermaid.min.js")) ? beside : null;
        }
        var folder = AppCaches.Folder("mermaid");
        var done = Path.Combine(folder, ".complete");
        try
        {
            if (!File.Exists(done))
            {
                foreach (var name in names)
                {
                    var target = Path.Combine(folder, name["mermaid/".Length..].Replace('\\', Path.DirectorySeparatorChar).Replace('/', Path.DirectorySeparatorChar));
                    Directory.CreateDirectory(Path.GetDirectoryName(target)!);
                    using var source = assembly.GetManifestResourceStream(name)!;
                    using var file = File.Create(target);
                    source.CopyTo(file);
                }
                File.WriteAllText(done, DateTime.UtcNow.ToString("O"));
                Logging.Info($"Mermaid: {names.Count} files unpacked to {folder}.");
            }
            return folder;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            Logging.Error(ex, "Mermaid files");
            return File.Exists(Path.Combine(beside, "mermaid.min.js")) ? beside : null;
        }
    }

    /// <summary>The off-screen window with the WebView2 and mermaid.js loaded.</summary>
    private static async Task StartAsync()
    {
        var assets = Assets();
        if (assets is null)
        {
            _unavailable = "mermaid.js is missing from the app folder.";
            return;
        }
        try
        {
            _ = CoreWebView2Environment.GetAvailableBrowserVersionString();
        }
        catch (WebView2RuntimeNotFoundException)
        {
            _unavailable = "Diagrams need the Microsoft Edge WebView2 runtime (installed with Windows 11; available from Microsoft for Windows 10).";
            return;
        }
        _view = new WebView2 { Width = 800, Height = 600, DefaultBackgroundColor = System.Drawing.Color.Transparent };
        _window = new Window
        {
            Title = "Diagram renderer",
            WindowStyle = WindowStyle.None,
            ShowInTaskbar = false,
            ShowActivated = false,
            Focusable = false,
            ResizeMode = ResizeMode.NoResize,
            Left = -32000,
            Top = -32000,
            Width = 840,
            Height = 640,
            Content = new System.Windows.Controls.Canvas { Children = { _view } },
        };
        _window.Show(); // a WebView2 only paints while its window is shown; this one is far off screen
        var ready = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var environment = await CoreWebView2Environment.CreateAsync(null, UserDataFolder ?? Path.Combine(Path.GetTempPath(), "DocGen.Explorer", "webview2"));
        await _view.EnsureCoreWebView2Async(environment);
        var core = _view.CoreWebView2;
        core.Settings.AreDevToolsEnabled = false;
        core.Settings.AreDefaultContextMenusEnabled = false;
        core.Settings.IsScriptEnabled = true;
        core.SetVirtualHostNameToFolderMapping(Host, assets, CoreWebView2HostResourceAccessKind.DenyCors);
        // Nothing but the local page may load.
        core.NavigationStarting += (_, e) =>
        {
            if (!e.Uri.StartsWith($"https://{Host}/", StringComparison.OrdinalIgnoreCase))
            {
                e.Cancel = true;
            }
        };
        core.WebMessageReceived += (_, e) =>
        {
            using var document = JsonDocument.Parse(e.WebMessageAsJson);
            var message = document.RootElement.Clone();
            if (message.TryGetProperty("ready", out JsonElement _))
            {
                ElkAvailable = message.TryGetProperty("elk", out var elk) && elk.ValueKind == JsonValueKind.True;
                if (!ElkAvailable)
                {
                    Logging.Info("Mermaid: the ELK layout engine did not load; diagrams that ask for it are drawn with the default layout.");
                }
                ready.TrySetResult();
            }
            else
            {
                _pending?.TrySetResult(message);
            }
        };
        core.Navigate($"https://{Host}/render.html");
        // The first start after installing can be slow (WebView2 creates its profile, and the virus scanner reads the
        // new files), so it is given a minute.
        if (await Task.WhenAny(ready.Task, Task.Delay(TimeSpan.FromSeconds(60))) != ready.Task)
        {
            _unavailable = "The diagram renderer did not start.";
            Logging.Info($"Mermaid: the renderer page did not report ready within 60 s (files in {assets}).");
        }
    }

    /// <summary>Closes the off-screen window (when the app exits).</summary>
    public static void Shutdown()
    {
        _view?.Dispose();
        _window?.Close();
        _view = null;
        _window = null;
    }

}
