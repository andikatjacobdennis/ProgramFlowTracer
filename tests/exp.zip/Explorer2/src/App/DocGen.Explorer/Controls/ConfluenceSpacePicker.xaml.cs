using System.Windows.Controls;

namespace DocGen.Explorer.Controls;

/// <summary>Tick boxes for the spaces on the Confluence sites (Settings → Confluence and the Indexing page).</summary>
public partial class ConfluenceSpacePicker : UserControl
{
    public ConfluenceSpacePicker()
    {
        InitializeComponent();
    }
}
