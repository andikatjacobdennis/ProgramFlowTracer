using System.Collections.Specialized;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Controls;

/// <summary>
/// The question rail at the right of a conversation: a short bar for each question asked, the one being read longer and
/// in the accent colour. Pointing at the rail lists the questions by their first words; choosing one scrolls the
/// conversation to it. Shown from two questions on.
/// </summary>
public sealed class QuestionRail : Grid
{
    private const double BarGap = 9;
    private readonly StackPanel _bars = new() { VerticalAlignment = VerticalAlignment.Center, HorizontalAlignment = HorizontalAlignment.Right };
    private readonly StackPanel _list = new();
    private readonly Border _panel;
    private ScrollViewer? _thread;
    private ItemsControl? _messages;
    private INotifyCollectionChanged? _source;
    private List<ChatMessageViewModel> _questions = [];
    private int _current = -1;

    public QuestionRail()
    {
        HorizontalAlignment = HorizontalAlignment.Right;
        VerticalAlignment = VerticalAlignment.Center;
        Background = Brushes.Transparent; // the whole strip answers to the pointer, not only the bars
        AutomationProperties.SetName(this, "Questions in this conversation");
        ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        _panel = new Border
        {
            Child = new ScrollViewer { Content = _list, VerticalScrollBarVisibility = ScrollBarVisibility.Auto, MaxHeight = 360 },
            CornerRadius = new CornerRadius(10),
            BorderThickness = new Thickness(1),
            Padding = new Thickness(6),
            Margin = new Thickness(0, 0, 6, 0),
            MaxWidth = 260,
            VerticalAlignment = VerticalAlignment.Center,
            Visibility = Visibility.Collapsed,
            Effect = new System.Windows.Media.Effects.DropShadowEffect { BlurRadius = 16, ShadowDepth = 2, Opacity = 0.12 },
        };
        _panel.SetResourceReference(Border.BackgroundProperty, "Brush.Surface");
        _panel.SetResourceReference(Border.BorderBrushProperty, "Brush.Border");
        SetColumn(_panel, 0);
        SetColumn(_bars, 1);
        _bars.Margin = new Thickness(4, 8, 2, 8);
        Children.Add(_panel);
        Children.Add(_bars);
        Visibility = Visibility.Collapsed;
        MouseEnter += (_, _) => _panel.Visibility = Visibility.Visible;
        MouseLeave += (_, _) => _panel.Visibility = Visibility.Collapsed;
        // Keyboard: the list opens while one of its questions has the focus.
        IsKeyboardFocusWithinChanged += (_, _) => _panel.Visibility = IsKeyboardFocusWithin || IsMouseOver ? Visibility.Visible : Visibility.Collapsed;
    }

    /// <summary>The conversation's scroll viewer and the items control of its messages.</summary>
    public void Attach(ScrollViewer thread, ItemsControl messages)
    {
        _thread = thread;
        _messages = messages;
        thread.ScrollChanged += (_, _) => UpdateCurrent();
        // The messages' collection is set by binding, after the data context changes: follow the property itself.
        System.ComponentModel.DependencyPropertyDescriptor.FromProperty(ItemsControl.ItemsSourceProperty, typeof(ItemsControl))
            .AddValueChanged(messages, (_, _) => Watch());
        Watch();
    }

    /// <summary>The questions, as the rail lists them (for checks).</summary>
    public IReadOnlyList<string> Labels => _questions.Select(q => Label(q.Text)).ToList();

    /// <summary>The question being read (-1 without questions).</summary>
    public int Current => _current;

    /// <summary>Whether the list of questions is showing (while pointed at).</summary>
    public bool IsListOpen => _panel.Visibility == Visibility.Visible;

    /// <summary>The first words of a question (about six), as shown when pointing at the rail.</summary>
    public static string Label(string question)
    {
        var words = Regex.Split(question.Trim(), @"\s+").Where(w => w.Length > 0).ToList();
        var text = string.Join(" ", words.Take(6));
        if (text.Length > 40)
        {
            text = text[..40].TrimEnd();
        }
        return words.Count > 6 || text.Length < string.Join(" ", words).Length ? text + "…" : text;
    }

    /// <summary>Scrolls the conversation so the question starts at the top.</summary>
    public void GoTo(int index)
    {
        if (_thread?.Content is not UIElement content || index < 0 || index >= _questions.Count
            || _messages?.ItemContainerGenerator.ContainerFromItem(_questions[index]) is not FrameworkElement container)
        {
            return;
        }
        var top = container.TranslatePoint(new Point(0, 0), content).Y;
        _thread.ScrollToVerticalOffset(Math.Max(0, top - 8));
        _current = index;
        Paint();
    }

    private void Watch()
    {
        if (_source is not null)
        {
            _source.CollectionChanged -= OnMessagesChanged;
        }
        _source = _messages?.ItemsSource as INotifyCollectionChanged;
        if (_source is not null)
        {
            _source.CollectionChanged += OnMessagesChanged;
        }
        Rebuild();
    }

    private void OnMessagesChanged(object? sender, NotifyCollectionChangedEventArgs e) => Dispatcher.BeginInvoke(Rebuild, System.Windows.Threading.DispatcherPriority.Background);

    private void Rebuild()
    {
        _questions = (_messages?.ItemsSource as IEnumerable<ChatMessageViewModel> ?? []).Where(m => m.IsUser && !string.IsNullOrWhiteSpace(m.Text)).ToList();
        Visibility = _questions.Count >= 2 ? Visibility.Visible : Visibility.Collapsed;
        _bars.Children.Clear();
        _list.Children.Clear();
        for (var i = 0; i < _questions.Count; i++)
        {
            var index = i;
            var bar = new Border { Height = 3, CornerRadius = new CornerRadius(1.5), HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, i == 0 ? 0 : BarGap, 0, 0) };
            _bars.Children.Add(bar);
            var row = new Button
            {
                Content = new TextBlock { Text = Label(_questions[i].Text), TextTrimming = TextTrimming.CharacterEllipsis },
                HorizontalContentAlignment = HorizontalAlignment.Left,
                Padding = new Thickness(10, 5, 10, 5),
                Cursor = Cursors.Hand,
                ToolTip = _questions[i].Text.Length > 300 ? _questions[i].Text[..300] + "…" : _questions[i].Text,
            };
            row.SetResourceReference(StyleProperty, "Button.Ghost");
            AutomationProperties.SetName(row, "Go to question: " + Label(_questions[i].Text));
            row.Click += (_, _) => GoTo(index);
            _list.Children.Add(row);
        }
        UpdateCurrent();
    }

    /// <summary>The question being read: the last one whose start has scrolled to (or above) the top of the view.</summary>
    private void UpdateCurrent()
    {
        if (_thread?.Content is not UIElement content || _questions.Count == 0)
        {
            return;
        }
        var current = 0;
        for (var i = 0; i < _questions.Count; i++)
        {
            if (_messages?.ItemContainerGenerator.ContainerFromItem(_questions[i]) is FrameworkElement container
                && container.TranslatePoint(new Point(0, 0), content).Y <= _thread.VerticalOffset + _thread.ViewportHeight / 3)
            {
                current = i;
            }
        }
        // At the very end the last question is the one being read, however short its answer.
        if (_thread.ScrollableHeight > 0 && _thread.VerticalOffset >= _thread.ScrollableHeight - 2)
        {
            current = _questions.Count - 1;
        }
        if (current != _current)
        {
            _current = current;
        }
        Paint();
    }

    private void Paint()
    {
        for (var i = 0; i < _bars.Children.Count; i++)
        {
            var bar = (Border)_bars.Children[i];
            var current = i == _current;
            bar.Width = current ? 18 : 12;
            bar.SetResourceReference(Border.BackgroundProperty, current ? "Brush.Accent" : "Brush.BorderStrong");
            if (_list.Children[i] is Button { Content: TextBlock text })
            {
                text.SetResourceReference(TextBlock.ForegroundProperty, current ? "Brush.Accent" : "Brush.TextMuted");
                text.FontWeight = current ? FontWeights.SemiBold : FontWeights.Normal;
            }
        }
    }
}
