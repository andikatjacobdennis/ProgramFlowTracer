﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.Controls;

/// <summary>
/// A drawn diagram you can explore: zoom at the pointer (wheel; Ctrl+wheel inside a page so the page still scrolls),
/// drag to pan, fit, 100 %, full screen, download as SVG or PNG and copy. Inline it fits the column; full screen it
/// fills the window (Esc closes, + − 0 1 and the arrow keys work).
/// </summary>
public sealed class DiagramViewer : Grid
{
    private const double MinZoom = 0.1;
    private const double MaxZoom = 8;
    private readonly MermaidImage _diagram;
    private readonly string _code;
    private readonly bool _fullScreen;
    private readonly Image _picture;
    private readonly ScaleTransform _scale = new(1, 1);
    private readonly TranslateTransform _offset = new();
    private readonly TextBlock _zoomText = new() { FontSize = 12, MinWidth = 42, TextAlignment = TextAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
    private readonly Border _toolbar;
    /// <summary>What is in view, redrawn from the SVG at the zoom it is shown at (on top of the picture, moving with it).</summary>
    private readonly Image _sharp = new() { Stretch = Stretch.Fill, HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top, IsHitTestVisible = false, Visibility = Visibility.Collapsed };
    private readonly TranslateTransform _sharpAt = new();
    private readonly System.Windows.Threading.DispatcherTimer _sharpen = new() { Interval = TimeSpan.FromMilliseconds(90) };
    private bool _sharpening;
    private int _viewGeneration;
    private Point? _dragFrom;
    private bool _dragged;

    // The picture as shown: a large diagram's picture reduced to what a graphics card can always draw.
    private readonly BitmapSource? _shown;
    private const int MaxShownPixels = 4096;

    /// <summary>
    /// A very large diagram is drawn by mermaid as a picture of up to 8,000 pixels a side; some graphics cards cannot draw
    /// one that size at all and show nothing. The view uses a copy of at most 4,096 pixels a side (zooming in still draws
    /// the part in view sharply from the SVG), and the full picture is kept for saving.
    /// </summary>
    private static BitmapSource? Displayable(BitmapSource? picture)
    {
        if (picture is null || Math.Max(picture.PixelWidth, picture.PixelHeight) <= MaxShownPixels)
        {
            return picture;
        }
        var scale = (double)MaxShownPixels / Math.Max(picture.PixelWidth, picture.PixelHeight);
        var reduced = new TransformedBitmap(picture, new ScaleTransform(scale, scale));
        var copy = new WriteableBitmap(reduced);
        copy.Freeze();
        return copy;
    }
    private Point _dragOffset;
    private bool _fitted = true;

    public DiagramViewer(MermaidImage diagram, string code, bool fullScreen = false)
    {
        _diagram = diagram;
        _code = code;
        _fullScreen = fullScreen;
        ClipToBounds = true;
        Background = Brushes.Transparent; // catches the mouse everywhere, for panning
        Focusable = true;
        FocusVisualStyle = null;
        _shown = Displayable(diagram.Image);
        _picture = new Image { Source = _shown, Width = diagram.Width, Height = diagram.Height, Stretch = Stretch.Fill, HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Top };
        RenderOptions.SetBitmapScalingMode(_picture, BitmapScalingMode.HighQuality);
        _picture.RenderTransform = new TransformGroup { Children = { _scale, _offset } };
        RenderOptions.SetBitmapScalingMode(_sharp, BitmapScalingMode.HighQuality);
        _sharp.RenderTransform = new TransformGroup { Children = { _sharpAt, _scale, _offset } };
        // On a canvas: laid out in the grid, a picture larger than the viewer was clipped to the viewer's size before it
        // was scaled down, so a narrow column showed only its top-left corner. The viewer itself clips what is outside.
        var layer = new Canvas();
        layer.Children.Add(_picture);
        layer.Children.Add(_sharp);
        Children.Add(layer);
        _sharpen.Tick += async (_, _) =>
        {
            _sharpen.Stop();
            if (_sharpening)
            {
                _sharpen.Start(); // one drawing at a time: the next one once this arrives
                return;
            }
            var generation = _viewGeneration;
            _sharpening = true;
            try
            {
                await SharpenAsync();
            }
            finally
            {
                _sharpening = false;
            }
            if (generation != _viewGeneration)
            {
                _sharpen.Start(); // the view kept moving: draw what is in view now
            }
        };
        Unloaded += (_, _) => _sharpen.Stop();
        _toolbar = Toolbar();
        Children.Add(_toolbar);
        if (!fullScreen)
        {
            // Inline: as tall as the fitted drawing (at most 560), and the toolbar shows on hover.
            _toolbar.Opacity = 0;
            MouseEnter += (_, _) => _toolbar.Opacity = 1;
            MouseLeave += (_, _) => { if (_dragFrom is null) { _toolbar.Opacity = 0; } };
            Cursor = Cursors.Hand;
            ToolTip = "Ctrl+wheel to zoom, drag to pan, double-click for full screen";
        }
        SizeChanged += (_, _) =>
        {
            if (_fitted)
            {
                Fit();
            }
        };
        MouseWheel += OnWheel;
        MouseLeftButtonDown += OnDown;
        MouseMove += OnMove;
        MouseLeftButtonUp += (_, _) => EndDrag();
        LostMouseCapture += (_, _) => _dragFrom = null;
        KeyDown += OnKey;
    }

    /// <summary>Inline height: the drawing fitted to the column's width, within limits.</summary>
    protected override Size MeasureOverride(Size constraint)
    {
        base.MeasureOverride(constraint);
        if (_fullScreen)
        {
            return new Size(double.IsInfinity(constraint.Width) ? 800 : constraint.Width, double.IsInfinity(constraint.Height) ? 600 : constraint.Height);
        }
        var width = double.IsInfinity(constraint.Width) ? _diagram.Width : constraint.Width;
        var fitted = _diagram.Height * Math.Min(1, width / Math.Max(1, _diagram.Width));
        return new Size(Math.Min(width, Math.Max(_diagram.Width, 1)), Math.Clamp(fitted, 60, 560));
    }

    private Border Toolbar()
    {
        var bar = new StackPanel { Orientation = Orientation.Horizontal };
        Button Tool(string content, string tip, Action action, bool icon = true)
        {
            var b = new Button { Content = content, ToolTip = tip, Padding = new Thickness(8, 4, 8, 4), Margin = new Thickness(1, 0, 1, 0), FontSize = icon ? 12 : 12, Focusable = false };
            b.SetResourceReference(FrameworkElement.StyleProperty, "Button.Ghost");
            if (icon)
            {
                b.SetResourceReference(Control.FontFamilyProperty, "Font.Icons");
            }
            b.Click += (_, e) => { action(); e.Handled = true; };
            return b;
        }
        bar.Children.Add(Tool(Icons.ZoomOut, "Zoom out (−)", () => ZoomBy(1 / 1.25)));
        bar.Children.Add(_zoomText);
        bar.Children.Add(Tool(Icons.ZoomIn, "Zoom in (+)", () => ZoomBy(1.25)));
        bar.Children.Add(Tool(Icons.Fit, "Fit (0)", Fit));
        bar.Children.Add(Tool("1:1", "Actual size (1)", () => ZoomTo(1, Center()), icon: false));
        bar.Children.Add(Tool(_fullScreen ? Icons.Collapse : Icons.Expand, _fullScreen ? "Exit full screen (Esc)" : "Full screen", ToggleFullScreen));
        // Opened from the button's own click action: Tool marks the click handled, so a handler added after it never ran.
        Button? download = null;
        download = Tool(Icons.Download, "Download the diagram (SVG, PNG, JPEG, BMP, GIF, TIFF or the Mermaid source)", () => (DownloadOpen = DownloadMenu(download!)).IsOpen = true);
        System.Windows.Automation.AutomationProperties.SetName(download, "Download the diagram");
        bar.Children.Add(download);
        bar.Children.Add(Tool(Icons.Copy, "Copy the picture (on white, as JPEG)", async () =>
        {
            if ((await ForExportAsync()).Image is { } picture)
            {
                try
                {
                    Clipboard.SetDataObject(PictureForClipboard(picture), copy: true);
                    Ui.Notify("Diagram copied as a picture.");
                }
                catch (System.Runtime.InteropServices.ExternalException ex)
                {
                    Ui.Notify("The picture could not be copied: " + ex.Message);
                }
            }
        }));
        // Summarise: what the diagram shows, in plain words (in Ask; with a model, written by it).
        bar.Children.Add(Tool(Icons.Lightbulb, "Summarise this diagram in plain words (the summary appears under it)", () =>
        {
            if (_fullScreen)
            {
                Window.GetWindow(this)?.Close();
            }
            if (SummariseRequested is { } summarise)
            {
                summarise();
            }
            else
            {
                _ = SummariseSelection.SummariseDiagramAsync(_code);
            }
        }));
        var border = new ShadowBorder
        {
            Child = bar,
            CornerRadius = new CornerRadius(8),
            Padding = new Thickness(4),
            Margin = new Thickness(8),
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Top,
            BorderThickness = new Thickness(1),
        };
        border.SetResourceReference(Border.BackgroundProperty, "Brush.Surface");
        border.SetResourceReference(Border.BorderBrushProperty, "Brush.Border");
        _zoomText.SetResourceReference(TextBlock.ForegroundProperty, "Brush.TextMuted");
        return border;
    }

    /// <summary>The picture formats a diagram downloads as: name, extension, file-dialog filter.</summary>
    public static readonly IReadOnlyList<(string Name, string Extension, string Filter)> PictureFormats =
    [
        ("PNG", ".png", "PNG image (*.png)|*.png"),
        ("JPEG", ".jpg", "JPEG image (*.jpg)|*.jpg;*.jpeg"),
        ("BMP", ".bmp", "Bitmap image (*.bmp)|*.bmp"),
        ("GIF", ".gif", "GIF image (*.gif)|*.gif"),
        ("TIFF", ".tif", "TIFF image (*.tif)|*.tif;*.tiff"),
    ];

    /// <summary>The Download menu last opened (the UI walk checks it).</summary>
    internal ContextMenu? DownloadOpen { get; private set; }

    internal ContextMenu DownloadMenu(UIElement target)
    {
        var menu = new ContextMenu { PlacementTarget = target, Placement = PlacementMode.Bottom };
        var svg = new MenuItem { Header = "SVG (scalable, sharp at any size)", Icon = "\uE91B", IsEnabled = _diagram.Svg is not null };
        svg.Click += async (_, _) =>
        {
            var light = await ForExportAsync();
            Save("SVG image (*.svg)|*.svg", ".svg", path => File.WriteAllText(path, (light.Svg ?? _diagram.Svg)!));
        };
        menu.Items.Add(svg);
        foreach (var (name, extension, filter) in PictureFormats)
        {
            var item = new MenuItem { Header = name, Icon = "\uE91B", IsEnabled = _diagram.Image is not null };
            item.Click += async (_, _) =>
            {
                var light = await ForExportAsync();
                Save(filter, extension, path => File.WriteAllBytes(path, Encode((light.Image ?? _diagram.Image)!, extension, Colors.White)));
            };
            menu.Items.Add(item);
        }
        menu.Items.Add(new Separator());
        var mmd = new MenuItem { Header = "Mermaid source (.mmd)", Icon = "\uE943" };
        mmd.Click += (_, _) => Save("Mermaid diagram (*.mmd)|*.mmd", ".mmd", path => File.WriteAllText(path, _code));
        menu.Items.Add(mmd);
        var source = new MenuItem { Header = "Copy the Mermaid source", Icon = "\uE8C8" };
        source.Click += (_, _) => { if (Ui.Copy(_code)) { Ui.Notify("Mermaid source copied."); } };
        menu.Items.Add(source);
        return menu;
    }

    /// <summary>
    /// The picture in a file format (by extension). PNG and TIFF keep transparency; JPEG, BMP and GIF cannot, so the
    /// picture is laid on <paramref name="background"/> first (a transparent one would turn black).
    /// </summary>
    public static byte[] Encode(BitmapSource image, string extension, Color background)
    {
        BitmapEncoder encoder = extension.ToLowerInvariant() switch
        {
            ".png" => new PngBitmapEncoder(),
            ".jpg" or ".jpeg" => new JpegBitmapEncoder { QualityLevel = 95 },
            ".bmp" => new BmpBitmapEncoder(),
            ".gif" => new GifBitmapEncoder(),
            ".tif" or ".tiff" => new TiffBitmapEncoder { Compression = TiffCompressOption.Lzw },
            _ => throw new ArgumentException($"Not a picture format: {extension}", nameof(extension)),
        };
        var opaque = encoder is JpegBitmapEncoder or BmpBitmapEncoder or GifBitmapEncoder;
        encoder.Frames.Add(BitmapFrame.Create(opaque ? OnBackground(image, background) : image));
        using var stream = new MemoryStream();
        encoder.Save(stream);
        return stream.ToArray();
    }

    /// <summary>
    /// The picture for the clipboard, on white: as JPEG ("JFIF") and as a bitmap for programs that do not take JPEG. A
    /// transparent picture pasted elsewhere would show black where the diagram has no background.
    /// </summary>
    public static DataObject PictureForClipboard(BitmapSource image)
    {
        var data = new DataObject();
        data.SetImage(OnBackground(image, Colors.White));
        data.SetData("JFIF", new MemoryStream(Encode(image, ".jpg", Colors.White)));
        return data;
    }

    private static BitmapSource OnBackground(BitmapSource image, Color background)
    {
        var size = new Rect(0, 0, image.PixelWidth, image.PixelHeight);
        var visual = new DrawingVisual();
        using (var context = visual.RenderOpen())
        {
            context.DrawRectangle(new SolidColorBrush(background), null, size);
            context.DrawImage(image, size);
        }
        var flat = new RenderTargetBitmap(image.PixelWidth, image.PixelHeight, 96, 96, PixelFormats.Pbgra32);
        flat.Render(visual);
        flat.Freeze();
        return flat;
    }

    /// <summary>
    /// The diagram as copied and saved: drawn for a light page (in the dark theme it is shown with light text, which
    /// would vanish on the white it is copied and saved on). The shown drawing when the light one cannot be made.
    /// </summary>
    private async Task<MermaidImage> ForExportAsync()
    {
        var light = await MermaidRenderer.RenderAsync(_code, dark: false);
        return light.Image is not null ? light : _diagram;
    }

    private static void Save(string filter, string extension, Action<string> write)
    {
        var dialog = new Microsoft.Win32.SaveFileDialog { FileName = "diagram" + extension, Filter = filter, AddExtension = true };
        if (dialog.ShowDialog() != true)
        {
            return;
        }
        try
        {
            write(dialog.FileName);
            Ui.Notify("Saved " + Path.GetFileName(dialog.FileName));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            Ui.Notify("The diagram could not be saved: " + ex.Message);
        }
    }

    private Point Center() => new(ActualWidth / 2, ActualHeight / 2);

    /// <summary>The whole drawing in view (never enlarged beyond 100 % inline).</summary>
    public void Fit()
    {
        if (ActualWidth <= 0 || ActualHeight <= 0)
        {
            return;
        }
        var margin = _fullScreen ? 40 : 0;
        var zoom = Math.Min((ActualWidth - margin) / _diagram.Width, (ActualHeight - margin) / _diagram.Height);
        zoom = Math.Clamp(_fullScreen ? Math.Min(zoom, 3) : Math.Min(zoom, 1), MinZoom, MaxZoom);
        _scale.ScaleX = _scale.ScaleY = zoom;
        _offset.X = Math.Max(0, (ActualWidth - _diagram.Width * zoom) / 2);
        _offset.Y = _fullScreen ? Math.Max(0, (ActualHeight - _diagram.Height * zoom) / 2) : 0;
        _fitted = true;
        ShowZoom();
    }

    private void ZoomBy(double factor) => ZoomTo(_scale.ScaleX * factor, Center());

    /// <summary>Zooms keeping the point under <paramref name="anchor"/> where it is.</summary>
    private void ZoomTo(double zoom, Point anchor)
    {
        zoom = Math.Clamp(zoom, MinZoom, MaxZoom);
        var old = _scale.ScaleX;
        var contentX = (anchor.X - _offset.X) / old;
        var contentY = (anchor.Y - _offset.Y) / old;
        _scale.ScaleX = _scale.ScaleY = zoom;
        _offset.X = anchor.X - contentX * zoom;
        _offset.Y = anchor.Y - contentY * zoom;
        _fitted = false;
        ShowZoom();
    }

    private void ShowZoom()
    {
        _zoomText.Text = $"{_scale.ScaleX * 100:0}%";
        ViewChanged();
    }

    /// <summary>
    /// The view moved or zoomed: what is in view is drawn again at the new zoom — while zooming too, a few times a
    /// second, not only once it rests, so the drawing does not stay blurred while the wheel turns.
    /// </summary>
    private void ViewChanged()
    {
        _viewGeneration++;
        // Under the sharp drawing the picture shows wherever the sharp one does not reach.
        _picture.Visibility = SharpCovers() ? Visibility.Hidden : Visibility.Visible;
        if (!_sharpen.IsEnabled)
        {
            _sharpen.Start();
        }
    }

    /// <summary>What is in view, in the drawing's own units.</summary>
    private Rect InView()
    {
        var zoom = _scale.ScaleX;
        var x0 = Math.Max(0, -_offset.X / zoom);
        var y0 = Math.Max(0, -_offset.Y / zoom);
        var x1 = Math.Min(_diagram.Width, (ActualWidth - _offset.X) / zoom);
        var y1 = Math.Min(_diagram.Height, (ActualHeight - _offset.Y) / zoom);
        return x1 - x0 < 1 || y1 - y0 < 1 ? Rect.Empty : new Rect(x0, y0, x1 - x0, y1 - y0);
    }

    /// <summary>The sharp drawing covers all that is in view (so the picture under it can be hidden).</summary>
    private bool SharpCovers()
    {
        if (_sharp.Visibility != Visibility.Visible || _sharp.Source is null)
        {
            return false;
        }
        var view = InView();
        return !view.IsEmpty && new Rect(_sharpAt.X, _sharpAt.Y, _sharp.Width, _sharp.Height).Contains(view);
    }

    /// <summary>
    /// When the zoom is beyond what the picture holds, draws the part in view again from the SVG at the zoom and the
    /// screen's resolution, so lines and text stay crisp however far one zooms in.
    /// </summary>
    private async Task SharpenAsync()
    {
        if (_diagram.Image is not { } picture || _diagram.Svg is null || ActualWidth <= 0 || ActualHeight <= 0)
        {
            return;
        }
        var zoom = _scale.ScaleX;
        var dpi = VisualTreeHelper.GetDpi(this).DpiScaleX;
        // What the shown picture holds per unit (its reduced copy for a very large diagram).
        var held = (_shown?.PixelWidth ?? picture.PixelWidth) / Math.Max(1, _diagram.Width);
        if (zoom * dpi <= held * 1.05)
        {
            _sharp.Visibility = Visibility.Collapsed; // the picture is sharp enough at this zoom
            _picture.Visibility = Visibility.Visible;
            return;
        }
        var view = InView();
        if (view.IsEmpty)
        {
            return;
        }
        // A margin around the view, so small pans and zooms out stay sharp until the next drawing arrives.
        view.Inflate(view.Width * 0.2, view.Height * 0.2);
        view.Intersect(new Rect(0, 0, _diagram.Width, _diagram.Height));
        // About the screen's size in pixels; a very large screen is drawn a little softer rather than not at all.
        var scale = Math.Min(zoom * dpi, 7000 / Math.Max(view.Width, view.Height));
        var region = await MermaidRenderer.RenderRegionAsync(_diagram, view, scale);
        if (region is null || (Math.Abs(_scale.ScaleX - zoom) > zoom * 0.5 && _scale.ScaleX * dpi <= held * 1.05))
        {
            return; // zoomed back out meanwhile: the picture is sharp enough
        }
        // Shown even when the view has moved on since it was asked for: it is placed in the drawing's own units, so it
        // still sits right, and it is sharper than the enlarged picture.
        _sharp.Source = region;
        _sharp.Width = view.Width;
        _sharp.Height = view.Height;
        _sharpAt.X = view.X;
        _sharpAt.Y = view.Y;
        _sharp.Visibility = Visibility.Visible;
        // Where the sharp drawing covers all that is in view, the enlarged picture under it would only blur its edges.
        _picture.Visibility = SharpCovers() ? Visibility.Hidden : Visibility.Visible;
    }

    /// <summary>Sizes and zoom, for layout checks.</summary>
    public string Describe() => $"diagram {_diagram.Width:0}x{_diagram.Height:0} (picture {_diagram.Image?.PixelWidth}x{_diagram.Image?.PixelHeight}), viewer {ActualWidth:0}x{ActualHeight:0}, zoom {_scale.ScaleX:0.00}, offset {_offset.X:0},{_offset.Y:0}, fitted {_fitted}";

    /// <summary>The picture (or the sharp drawing over it) is showing (for tests and captures).</summary>
    public bool PictureShown => _picture.Visibility == Visibility.Visible || IsSharpened;

    /// <summary>The sharp drawing of what is in view is showing (for tests and captures).</summary>
    public bool IsSharpened => _sharp.Visibility == Visibility.Visible && _sharp.Source is not null;

    private void OnWheel(object sender, MouseWheelEventArgs e)
    {
        // Inline, a plain wheel scrolls the page; Ctrl+wheel zooms. Full screen, the wheel zooms.
        if (!_fullScreen && !Keyboard.Modifiers.HasFlag(ModifierKeys.Control))
        {
            return;
        }
        ZoomTo(_scale.ScaleX * (e.Delta > 0 ? 1.15 : 1 / 1.15), e.GetPosition(this));
        e.Handled = true;
    }

    private void OnDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ClickCount == 2)
        {
            if (_fullScreen)
            {
                if (_fitted) { ZoomTo(1, e.GetPosition(this)); } else { Fit(); }
            }
            else
            {
                ToggleFullScreen();
            }
            e.Handled = true;
            return;
        }
        Focus();
        _dragFrom = e.GetPosition(this);
        _dragged = false;
        _dragOffset = new Point(_offset.X, _offset.Y);
        CaptureMouse();
        Cursor = Cursors.SizeAll;
        e.Handled = true;
    }

    private void OnMove(object sender, MouseEventArgs e)
    {
        if (_dragFrom is not { } from || e.LeftButton != MouseButtonState.Pressed)
        {
            return;
        }
        var now = e.GetPosition(this);
        // A click is not a drag: the view only moves once the pointer has really moved (a few pixels).
        if (!_dragged && Math.Abs(now.X - from.X) < 4 && Math.Abs(now.Y - from.Y) < 4)
        {
            return;
        }
        _dragged = true;
        _offset.X = _dragOffset.X + (now.X - from.X);
        _offset.Y = _dragOffset.Y + (now.Y - from.Y);
        _fitted = false;
        ViewChanged();
    }

    private void EndDrag()
    {
        if (_dragFrom is not null)
        {
            // What the view was, after a click or a drag (in the log, for a feedback report).
            Logging.Info($"Diagram {(_dragged ? "dragged" : "clicked")}: {Describe()}, picture shown {PictureShown}");
        }
        _dragFrom = null;
        ReleaseMouseCapture();
        Cursor = _fullScreen ? Cursors.Arrow : Cursors.Hand;
        if (!_fullScreen && !IsMouseOver)
        {
            _toolbar.Opacity = 0;
        }
    }

    private void OnKey(object sender, KeyEventArgs e)
    {
        switch (e.Key)
        {
            case Key.OemPlus or Key.Add: ZoomBy(1.25); break;
            case Key.OemMinus or Key.Subtract: ZoomBy(1 / 1.25); break;
            case Key.D0 or Key.NumPad0: Fit(); break;
            case Key.D1 or Key.NumPad1: ZoomTo(1, Center()); break;
            case Key.Left: _offset.X += 60; break;
            case Key.Right: _offset.X -= 60; break;
            case Key.Up: _offset.Y += 60; break;
            case Key.Down: _offset.Y -= 60; break;
            case Key.F11: ToggleFullScreen(); break;
            case Key.Escape when _fullScreen: Window.GetWindow(this)?.Close(); break;
            default: return;
        }
        if (e.Key is Key.Left or Key.Right or Key.Up or Key.Down)
        {
            ViewChanged();
        }
        e.Handled = true;
    }

    /// <summary>Zoom in by one step (for the capture and keyboard users).</summary>
    public void ZoomIn() => ZoomBy(1.25);

    public void ShowFullScreen() => OpenFullScreen(_diagram, _code, Window.GetWindow(this), SummariseRequested);

    private void ToggleFullScreen()
    {
        if (_fullScreen)
        {
            Window.GetWindow(this)?.Close();
            return;
        }
        OpenFullScreen(_diagram, _code, Window.GetWindow(this), SummariseRequested);
    }

    /// <summary>The diagram in a window filling the screen.</summary>
    /// <summary>Summarise: the diagram's own page or answer writes the summary under it (set by <see cref="MermaidView"/>).</summary>
    public Action? SummariseRequested { get; set; }

    public static void OpenFullScreen(MermaidImage diagram, string code, Window? owner, Action? summarise = null)
    {
        var viewer = new DiagramViewer(diagram, code, fullScreen: true) { SummariseRequested = summarise };
        var window = new Window
        {
            Title = "Diagram — wheel to zoom, drag to pan, Esc to close",
            Content = viewer,
            Owner = owner,
            WindowState = WindowState.Maximized,
            WindowStyle = WindowStyle.SingleBorderWindow,
            ShowInTaskbar = false,
            Icon = new System.Windows.Media.Imaging.BitmapImage(new Uri("pack://application:,,,/Assets/docgen.ico")),
            UseLayoutRounding = true,
        };
        window.SetResourceReference(BackgroundProperty, "Brush.Window");
        TextOptions.SetTextFormattingMode(window, TextFormattingMode.Ideal);
        window.SourceInitialized += (_, _) => ThemeManager.ApplyTitleBar(window);
        window.Loaded += (_, _) => { viewer.Fit(); viewer.Focus(); };
        window.Show();
    }
}
