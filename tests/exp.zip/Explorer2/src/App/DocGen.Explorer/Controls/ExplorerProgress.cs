using System.Globalization;
using System.Windows;
using System.Windows.Media;
using DocGen.Explorer.Engine.Assistant;

namespace DocGen.Explorer.Controls;

/// <summary>
/// The answer being prepared, as a small scene of repository exploration instead of a spinner: a little explorer with a
/// magnifier moves between miniature file cards; the cards light up (named after the files the evidence really came from)
/// once evidence is found; thin threads join them while the architecture trace follows the connections; small blocks then
/// gather into an answer card while the answer is written, which gets a tick when it is ready.
///
/// Every scene follows <see cref="Stage"/>, which is only ever set from what the assistant reports — the motion within a
/// scene is decoration, never a measure of progress (no percentages, nothing simulated). With no stage yet it is an
/// honest "exploring" loop. Reduced motion (the app's Motion setting) draws the same scene still. It runs only while
/// visible and active, and stops its frame clock otherwise.
/// </summary>
public sealed class ExplorerProgress : FrameworkElement
{
    public static readonly DependencyProperty StageProperty = DependencyProperty.Register(nameof(Stage), typeof(ProgressStage?), typeof(ExplorerProgress),
        new PropertyMetadata(null, (d, e) => ((ExplorerProgress)d).OnStageChanged()));

    public static readonly DependencyProperty FilesProperty = DependencyProperty.Register(nameof(Files), typeof(IReadOnlyList<string>), typeof(ExplorerProgress),
        new PropertyMetadata(null, (d, _) => ((ExplorerProgress)d).InvalidateVisual()));

    public static readonly DependencyProperty IsActiveProperty = DependencyProperty.Register(nameof(IsActive), typeof(bool), typeof(ExplorerProgress),
        new PropertyMetadata(true, (d, _) => ((ExplorerProgress)d).Update()));

    /// <summary>A one-line version (for the composer's status line): three tiny cards and the explorer's dot.</summary>
    public static readonly DependencyProperty CompactProperty = DependencyProperty.Register(nameof(Compact), typeof(bool), typeof(ExplorerProgress),
        new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.AffectsMeasure | FrameworkPropertyMetadataOptions.AffectsRender));

    private const int Cards = 5;
    private readonly System.Diagnostics.Stopwatch _clock = new();
    private readonly System.Diagnostics.Stopwatch _sinceStage = new();
    private bool _animating;

    public ExplorerProgress()
    {
        IsHitTestVisible = false;
        SnapsToDevicePixels = false;
        IsVisibleChanged += (_, _) => Update();
        Loaded += (_, _) => Update();
        Unloaded += (_, _) => Stop();
    }

    public ProgressStage? Stage { get => (ProgressStage?)GetValue(StageProperty); set => SetValue(StageProperty, value); }
    public IReadOnlyList<string>? Files { get => (IReadOnlyList<string>?)GetValue(FilesProperty); set => SetValue(FilesProperty, value); }
    public bool IsActive { get => (bool)GetValue(IsActiveProperty); set => SetValue(IsActiveProperty, value); }
    public bool Compact { get => (bool)GetValue(CompactProperty); set => SetValue(CompactProperty, value); }

    private static bool ReduceMotion => Avatars.AvatarFace.ReduceMotion;

    // A fixed height (the layout never jumps as scenes change); the width follows the space up to a comfortable maximum.
    protected override Size MeasureOverride(Size available)
        => Compact ? new Size(30, 14) : new Size(double.IsInfinity(available.Width) ? 340 : Math.Min(available.Width, 380), 72);

    private void OnStageChanged()
    {
        _sinceStage.Restart();
        Update();
    }

    private void Update()
    {
        var run = IsActive && IsVisible && IsLoaded && !ReduceMotion;
        if (run && !_animating)
        {
            _clock.Restart();
            _sinceStage.Restart();
            CompositionTarget.Rendering += OnFrame;
            _animating = true;
        }
        else if (!run)
        {
            Stop();
        }
        InvalidateVisual();
    }

    private void Stop()
    {
        if (_animating)
        {
            CompositionTarget.Rendering -= OnFrame;
            _animating = false;
        }
    }

    private void OnFrame(object? sender, EventArgs e) => InvalidateVisual();

    private Brush Res(string key, Brush fallback) => TryFindResource(key) as Brush ?? fallback;

    protected override void OnRender(DrawingContext dc)
    {
        var still = !_animating;
        // Seconds of gentle, repeating motion (0 when still: the scene's resting pose).
        var t = still ? 0 : _clock.Elapsed.TotalSeconds;
        var s = still ? 10 : _sinceStage.Elapsed.TotalSeconds;
        var accent = Res("Brush.Accent", Brushes.SteelBlue);
        var soft = Res("Brush.AccentSoft", Brushes.AliceBlue);
        var surface = Res("Brush.Surface", Brushes.White);
        var border = Res("Brush.Border", Brushes.LightGray);
        var muted = Res("Brush.TextMuted", Brushes.Gray);
        var faint = Res("Brush.BorderSubtle", Brushes.Gainsboro);
        if (Compact)
        {
            RenderCompact(dc, t, accent, border, surface);
            return;
        }

        var stage = Stage;
        var width = ActualWidth;
        var answerWidth = 70.0;
        var gap = 8.0;
        var cardW = Math.Clamp((width - answerWidth - 24 - gap * (Cards - 1)) / Cards, 26, 46);
        var cardH = 34.0;
        var top = 22.0;
        var files = Files ?? [];
        var found = stage is ProgressStage.Finding or ProgressStage.Connecting or ProgressStage.Writing or ProgressStage.Ready;
        var lit = found ? Math.Min(Cards, Math.Max(1, files.Count)) : 0;

        // The file cards; once evidence is found, as many light up as there were files (they light one after another).
        var centres = new List<Point>();
        for (var i = 0; i < Cards; i++)
        {
            var x = i * (cardW + gap);
            var rect = new Rect(x, top, cardW, cardH);
            centres.Add(new Point(rect.Left + rect.Width / 2, rect.Top + rect.Height / 2));
            var on = i < lit && (still || s > i * 0.18);
            var pen = new Pen(on ? accent : border, on ? 1.3 : 1);
            dc.DrawRoundedRectangle(on ? soft : surface, pen, rect, 4, 4);
            // A folded corner and three lines of "text".
            var fold = new StreamGeometry();
            using (var g = fold.Open())
            {
                g.BeginFigure(new Point(rect.Right - 8, rect.Top), true, true);
                g.LineTo(new Point(rect.Right, rect.Top + 8), true, false);
                g.LineTo(new Point(rect.Right - 8, rect.Top + 8), true, false);
            }
            fold.Freeze();
            dc.DrawGeometry(on ? accent : border, null, fold);
            for (var line = 0; line < 3; line++)
            {
                var lw = (rect.Width - 12) * (line == 2 ? 0.55 : 0.85);
                dc.DrawRoundedRectangle(on ? accent : faint, null, new Rect(rect.Left + 6, rect.Top + 12 + line * 6, lw, 2.4), 1.2, 1.2);
            }
            // The real file name under a lit card.
            if (on && i < files.Count)
            {
                var name = new FormattedText(Shorten(files[i], cardW + gap - 2), CultureInfo.CurrentUICulture, FlowDirection.LeftToRight,
                    new Typeface(ChartText.UiFont(this), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal), 9, muted, VisualTreeHelper.GetDpi(this).PixelsPerDip);
                dc.DrawText(name, new Point(rect.Left + (rect.Width - name.Width) / 2, rect.Bottom + 3));
            }
        }

        // Connecting: thin threads from card to card (only while the trace actually runs, or after it ran).
        if (stage is ProgressStage.Connecting || (stage is ProgressStage.Writing or ProgressStage.Ready && _sawConnecting))
        {
            var thread = new Pen(accent, 1) { DashStyle = new DashStyle([2, 2], still ? 0 : -t * 4) };
            for (var i = 0; i + 1 < Math.Max(lit, 2); i++)
            {
                var a = centres[i];
                var b = centres[i + 1];
                var lift = 10 + 3 * Math.Sin(t * 2 + i);
                var geometry = new StreamGeometry();
                using (var g = geometry.Open())
                {
                    g.BeginFigure(new Point(a.X, top - 2), false, false);
                    g.QuadraticBezierTo(new Point((a.X + b.X) / 2, top - lift), new Point(b.X, top - 2), true, false);
                }
                geometry.Freeze();
                dc.DrawGeometry(null, thread, geometry);
            }
        }

        // The answer card on the right; while writing, small blocks travel into it and stack as lines.
        var answer = new Rect(width - answerWidth, top - 4, answerWidth, cardH + 8);
        var writing = stage is ProgressStage.Writing or ProgressStage.Ready;
        dc.DrawRoundedRectangle(writing ? surface : null, new Pen(writing ? accent : faint, writing ? 1.3 : 1) { DashStyle = writing ? null : DashStyles.Dash }, answer, 6, 6);
        if (writing)
        {
            var lines = stage == ProgressStage.Ready || still ? 4 : Math.Min(4, 1 + (int)(s / 0.9));
            for (var line = 0; line < lines; line++)
            {
                var lw = (answer.Width - 16) * (line == 3 ? 0.5 : 0.9);
                dc.DrawRoundedRectangle(accent, null, new Rect(answer.Left + 8, answer.Top + 9 + line * 7, lw, 3), 1.5, 1.5);
            }
            if (stage == ProgressStage.Writing && !still)
            {
                // Two blocks in flight from the lit cards to the answer, looping softly.
                for (var k = 0; k < 2; k++)
                {
                    var phase = (t * 0.6 + k * 0.5) % 1.0;
                    var from = centres[(k * 2) % Math.Max(1, Math.Max(lit, 1))];
                    var to = new Point(answer.Left + 10, answer.Top + answer.Height / 2);
                    var x = from.X + (to.X - from.X) * Ease(phase);
                    var y = from.Y + (to.Y - from.Y) * Ease(phase) - Math.Sin(phase * Math.PI) * 14;
                    var block = new Rect(x - 4, y - 2.5, 8, 5);
                    dc.PushOpacity(Math.Sin(phase * Math.PI));
                    dc.DrawRoundedRectangle(accent, null, block, 1.5, 1.5);
                    dc.Pop();
                }
            }
            if (stage == ProgressStage.Ready)
            {
                var tick = new StreamGeometry();
                using (var g = tick.Open())
                {
                    g.BeginFigure(new Point(answer.Right - 18, answer.Bottom - 12), false, false);
                    g.LineTo(new Point(answer.Right - 13, answer.Bottom - 7), true, false);
                    g.LineTo(new Point(answer.Right - 5, answer.Bottom - 17), true, false);
                }
                tick.Freeze();
                dc.DrawGeometry(null, new Pen(Res("Brush.Success", Brushes.SeaGreen), 2) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round }, tick);
            }
        }

        // The explorer: a small figure with a magnifier, walking gently over the cards (resting at the answer once ready).
        double ex;
        if (stage == ProgressStage.Ready)
        {
            ex = answer.Left - 14;
        }
        else if (stage == ProgressStage.Writing)
        {
            ex = answer.Left - 16 + (still ? 0 : 2 * Math.Sin(t * 3));
        }
        else
        {
            // Over the cards: before evidence across all five, after it over the lit ones.
            var span = Math.Max(1, (found ? Math.Max(lit, 1) : Cards) - 1) * (cardW + gap);
            var u = still ? 0.5 : (Math.Sin(t * 0.9) + 1) / 2;
            ex = centres[0].X + span * u;
        }
        var bob = still ? 0 : Math.Abs(Math.Sin(t * 5)) * 2;
        DrawExplorer(dc, new Point(ex, 12 - bob), accent, surface, muted);
    }

    private bool _sawConnecting;

    protected override void OnPropertyChanged(DependencyPropertyChangedEventArgs e)
    {
        base.OnPropertyChanged(e);
        if (e.Property == StageProperty)
        {
            if (e.NewValue is ProgressStage.Connecting)
            {
                _sawConnecting = true;
            }
            else if (e.NewValue is null or ProgressStage.Understanding)
            {
                _sawConnecting = false;
            }
        }
    }

    private static void DrawExplorer(DrawingContext dc, Point at, Brush accent, Brush surface, Brush muted)
    {
        // Head and shoulders, and a magnifier held out in front.
        dc.DrawEllipse(accent, null, new Point(at.X, at.Y), 5, 5);
        dc.DrawRoundedRectangle(accent, null, new Rect(at.X - 5, at.Y + 5, 10, 6), 3, 3);
        var lens = new Point(at.X + 9, at.Y + 1);
        dc.DrawLine(new Pen(muted, 1.6) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round }, new Point(at.X + 4, at.Y + 6), new Point(lens.X - 2.5, lens.Y + 2.5));
        dc.DrawEllipse(surface, new Pen(muted, 1.4), lens, 3.6, 3.6);
    }

    private void RenderCompact(DrawingContext dc, double t, Brush accent, Brush border, Brush surface)
    {
        // Three tiny cards; the one the explorer's dot is over is lit.
        var current = _animating ? (int)(t * 1.2) % 3 : 1;
        for (var i = 0; i < 3; i++)
        {
            var rect = new Rect(1.5 + i * 9.5, 4, 7, 9);
            var on = i == current;
            dc.DrawRoundedRectangle(on ? accent : surface, new Pen(on ? accent : border, 1), rect, 1.5, 1.5);
        }
        dc.DrawEllipse(accent, null, new Point(5 + current * 9.5, 1.8), 1.8, 1.8);
    }

    private static double Ease(double x) => x < 0.5 ? 2 * x * x : 1 - Math.Pow(-2 * x + 2, 2) / 2;

    private static string Shorten(string name, double width)
    {
        var max = Math.Max(4, (int)(width / 5));
        return name.Length <= max ? name : name[..(max - 1)] + "…";
    }
}
