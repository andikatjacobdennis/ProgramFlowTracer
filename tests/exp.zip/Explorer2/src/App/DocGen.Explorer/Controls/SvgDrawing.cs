using System.Globalization;
using System.Windows;
using System.Windows.Media;
using System.Xml.Linq;

namespace DocGen.Explorer.Controls;

/// <summary>
/// Draws simple SVG — the illustrations of Help — as a WPF drawing, so mockups of the screens ship as a few KB of
/// vector instead of screenshots, and stay sharp at any size. Understood: svg (viewBox), g (translate, fill, stroke,
/// opacity, font), rect (rounded), circle, ellipse, line, polyline, polygon, path (the d mini-language WPF shares) and
/// text (x, y, size, weight, anchor, italic). Colours are #rgb, #rrggbb, names and "none"; stroke-dasharray works.
/// </summary>
public static class SvgDrawing
{
    private static readonly Dictionary<string, DrawingImage?> Cache = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>The illustration <paramref name="name"/> (Assets/Help/name.svg), or null when it is not there or cannot be read.</summary>
    public static DrawingImage? Illustration(string name)
    {
        if (Cache.TryGetValue(name, out var cached))
        {
            return cached;
        }
        DrawingImage? image = null;
        try
        {
            var info = Application.GetResourceStream(new Uri($"pack://application:,,,/Assets/Help/{name}.svg"));
            if (info is not null)
            {
                using var reader = new StreamReader(info.Stream);
                image = Load(reader.ReadToEnd());
            }
        }
        catch (Exception ex) when (ex is IOException or System.Xml.XmlException or FormatException or InvalidOperationException)
        {
            Infrastructure.Logging.Error(ex, $"Help illustration {name}");
        }
        Cache[name] = image;
        return image;
    }

    /// <summary>The SVG as a frozen drawing.</summary>
    public static DrawingImage Load(string svg)
    {
        var root = XElement.Parse(svg);
        var group = new DrawingGroup();
        var box = Numbers(Attr(root, "viewBox"));
        var width = box.Length == 4 ? box[2] : Number(Attr(root, "width"), 640);
        var height = box.Length == 4 ? box[3] : Number(Attr(root, "height"), 360);
        // The whole canvas, so the picture keeps its proportions and margins.
        group.Children.Add(new GeometryDrawing(Brushes.Transparent, null, new RectangleGeometry(new Rect(0, 0, width, height))));
        Walk(root, group, new Style());
        group.Freeze();
        var image = new DrawingImage(group);
        image.Freeze();
        return image;
    }

    private sealed record Style(string Fill = "#000", string Stroke = "none", double StrokeWidth = 1, double Opacity = 1, double FontSize = 14,
        string FontWeight = "normal", string FontStyle = "normal", string Anchor = "start", string? Dash = null, string Family = "Segoe UI");

    private static void Walk(XElement element, DrawingGroup into, Style inherited)
    {
        foreach (var child in element.Elements())
        {
            var style = Styled(child, inherited);
            switch (child.Name.LocalName)
            {
                case "g":
                    var group = new DrawingGroup { Opacity = Number(Attr(child, "opacity"), 1) };
                    if (Attr(child, "transform") is { } transform && transform.StartsWith("translate", StringComparison.Ordinal))
                    {
                        var t = Numbers(transform[(transform.IndexOf('(') + 1)..transform.IndexOf(')')]);
                        group.Transform = new TranslateTransform(t[0], t.Length > 1 ? t[1] : 0);
                    }
                    Walk(child, group, style with { Opacity = 1 });
                    into.Children.Add(group);
                    break;
                case "rect":
                    var rx = Number(Attr(child, "rx"), 0);
                    Add(into, style, new RectangleGeometry(new Rect(N(child, "x"), N(child, "y"), N(child, "width"), N(child, "height")), rx, Number(Attr(child, "ry"), rx)));
                    break;
                case "circle":
                    Add(into, style, new EllipseGeometry(new Point(N(child, "cx"), N(child, "cy")), N(child, "r"), N(child, "r")));
                    break;
                case "ellipse":
                    Add(into, style, new EllipseGeometry(new Point(N(child, "cx"), N(child, "cy")), N(child, "rx"), N(child, "ry")));
                    break;
                case "line":
                    Add(into, style with { Fill = "none" }, new LineGeometry(new Point(N(child, "x1"), N(child, "y1")), new Point(N(child, "x2"), N(child, "y2"))));
                    break;
                case "polyline" or "polygon":
                    var points = Numbers(Attr(child, "points"));
                    var figure = new PathFigure { IsClosed = child.Name.LocalName == "polygon", StartPoint = new Point(points[0], points[1]) };
                    for (var i = 2; i + 1 < points.Length; i += 2)
                    {
                        figure.Segments.Add(new LineSegment(new Point(points[i], points[i + 1]), true));
                    }
                    Add(into, child.Name.LocalName == "polyline" ? style with { Fill = Attr(child, "fill") ?? "none" } : style, new PathGeometry([figure]));
                    break;
                case "path":
                    Add(into, style, Geometry.Parse(Attr(child, "d") ?? ""));
                    break;
                case "text":
                    Text(child, into, style);
                    break;
            }
        }
    }

    private static void Text(XElement element, DrawingGroup into, Style style)
    {
        var text = string.Concat(element.Nodes().Select(n => n is XText t ? t.Value : (n as XElement)?.Value ?? "")).Trim();
        if (text.Length == 0)
        {
            return;
        }
        var typeface = new Typeface(new FontFamily(style.Family), style.FontStyle == "italic" ? FontStyles.Italic : FontStyles.Normal,
            style.FontWeight is "bold" or "600" or "700" ? FontWeights.SemiBold : style.FontWeight == "500" ? FontWeights.Medium : FontWeights.Normal, FontStretches.Normal);
        var formatted = new FormattedText(text, CultureInfo.InvariantCulture, FlowDirection.LeftToRight, typeface, style.FontSize, Brushes.Black, 1.0);
        var x = N(element, "x");
        x -= style.Anchor switch { "middle" => formatted.Width / 2, "end" => formatted.Width, _ => 0 };
        // SVG places text by its baseline.
        var y = N(element, "y") - formatted.Baseline;
        Add(into, style with { Stroke = "none" }, formatted.BuildGeometry(new Point(x, y)));
    }

    private static void Add(DrawingGroup into, Style style, Geometry geometry)
    {
        var fill = Brush(style.Fill, style.Opacity);
        Pen? pen = null;
        if (Brush(style.Stroke, style.Opacity) is { } stroke)
        {
            pen = new Pen(stroke, style.StrokeWidth) { LineJoin = PenLineJoin.Round, StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
            if (style.Dash is { Length: > 0 } dash)
            {
                pen.DashStyle = new DashStyle(Numbers(dash).Select(d => d / Math.Max(0.1, style.StrokeWidth)), 0);
            }
        }
        into.Children.Add(new GeometryDrawing(fill, pen, geometry));
    }

    private static Style Styled(XElement e, Style s) => s with
    {
        Fill = Attr(e, "fill") ?? s.Fill,
        Stroke = Attr(e, "stroke") ?? s.Stroke,
        StrokeWidth = Number(Attr(e, "stroke-width"), s.StrokeWidth),
        Opacity = e.Name.LocalName == "g" ? s.Opacity : s.Opacity * Number(Attr(e, "opacity"), 1),
        FontSize = Number(Attr(e, "font-size"), s.FontSize),
        FontWeight = Attr(e, "font-weight") ?? s.FontWeight,
        FontStyle = Attr(e, "font-style") ?? s.FontStyle,
        Anchor = Attr(e, "text-anchor") ?? s.Anchor,
        Dash = Attr(e, "stroke-dasharray") ?? s.Dash,
        Family = Attr(e, "font-family") ?? s.Family,
    };

    private static Brush? Brush(string value, double opacity)
    {
        if (value is "none" or "transparent")
        {
            return null;
        }
        var color = (Color)ColorConverter.ConvertFromString(value);
        if (opacity < 1)
        {
            color.A = (byte)(color.A * opacity);
        }
        var brush = new SolidColorBrush(color);
        brush.Freeze();
        return brush;
    }

    private static string? Attr(XElement e, string name) => e.Attribute(name)?.Value;

    private static double N(XElement e, string name) => Number(Attr(e, name), 0);

    private static double Number(string? value, double fallback)
        => double.TryParse(value?.Replace("px", "", StringComparison.Ordinal), NumberStyles.Float, CultureInfo.InvariantCulture, out var n) ? n : fallback;

    private static double[] Numbers(string? value)
        => (value ?? "").Split([' ', ',', '\t', '\n', '\r'], StringSplitOptions.RemoveEmptyEntries)
            .Select(v => double.Parse(v, NumberStyles.Float, CultureInfo.InvariantCulture)).ToArray();
}
