using System.Globalization;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace DocGen.Explorer.Controls;

/// <summary>One column of a <see cref="ColumnChart"/>: a label and its stacked values (bottom first).</summary>
public sealed record ChartColumn(string Label, string Tooltip, IReadOnlyList<double> Values);

/// <summary>One slice of a <see cref="DonutChart"/>.</summary>
public sealed record ChartSlice(string Label, double Value, Brush Brush)
{
    public double Share { get; init; }
    public string ValueText => Value.ToString("N0", CultureInfo.CurrentCulture);
    public string ShareText => Share.ToString("P0", CultureInfo.CurrentCulture);
}

internal static class ChartText
{
    /// <summary>12,345 → 12.3k; 2,500,000 → 2.5M.</summary>
    public static string Compact(double value) => value switch
    {
        >= 1_000_000 => (value / 1_000_000).ToString("0.#", CultureInfo.CurrentCulture) + "M",
        >= 10_000 => (value / 1_000).ToString("0", CultureInfo.CurrentCulture) + "k",
        >= 1_000 => (value / 1_000).ToString("0.#", CultureInfo.CurrentCulture) + "k",
        _ => value.ToString("0", CultureInfo.CurrentCulture),
    };

    public static FormattedText Text(Visual visual, string text, double size, Brush brush, FontWeight? weight = null)
        => new(text, CultureInfo.CurrentCulture, FlowDirection.LeftToRight, new Typeface(UiFont(visual), FontStyles.Normal, weight ?? FontWeights.Normal, FontStretches.Normal),
            size, brush, VisualTreeHelper.GetDpi(visual).PixelsPerDip);

    /// <summary>The interface font (Tokens.xaml, Font.UI), so drawn text matches the rest of the app.</summary>
    public static FontFamily UiFont(Visual? visual = null)
        => (visual as FrameworkElement)?.TryFindResource("Font.UI") as FontFamily
           ?? Application.Current?.TryFindResource("Font.UI") as FontFamily ?? new FontFamily("Segoe UI");

    public static Brush Resource(FrameworkElement element, string key, Brush fallback) => element.TryFindResource(key) as Brush ?? fallback;
}

/// <summary>Stacked columns (e.g. input and output tokens per day), with a value grid, labels and a hover tooltip.</summary>
public sealed class ColumnChart : FrameworkElement
{
    public static readonly DependencyProperty ColumnsProperty = DependencyProperty.Register(nameof(Columns), typeof(IReadOnlyList<ChartColumn>), typeof(ColumnChart),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty SeriesBrushesProperty = DependencyProperty.Register(nameof(SeriesBrushes), typeof(IReadOnlyList<Brush>), typeof(ColumnChart),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender));

    private const double Left = 46;
    private const double Bottom = 26;
    private const double Top = 8;
    private int _hover = -1;

    public ColumnChart()
    {
        MouseMove += OnMouseMove;
        MouseLeave += (_, _) => { _hover = -1; ToolTip = null; InvalidateVisual(); };
        System.Windows.Controls.ToolTipService.SetInitialShowDelay(this, 0);
        Cursor = Cursors.Hand;
    }

    public IReadOnlyList<ChartColumn>? Columns { get => (IReadOnlyList<ChartColumn>?)GetValue(ColumnsProperty); set => SetValue(ColumnsProperty, value); }
    public IReadOnlyList<Brush>? SeriesBrushes { get => (IReadOnlyList<Brush>?)GetValue(SeriesBrushesProperty); set => SetValue(SeriesBrushesProperty, value); }

    protected override Size MeasureOverride(Size availableSize) => new(double.IsInfinity(availableSize.Width) ? 600 : availableSize.Width, 220);

    private Rect Plot => new(Left, Top, Math.Max(10, ActualWidth - Left - 6), Math.Max(10, ActualHeight - Top - Bottom));

    protected override void OnRender(DrawingContext dc)
    {
        var columns = Columns;
        dc.DrawRectangle(Brushes.Transparent, null, new Rect(0, 0, ActualWidth, ActualHeight)); // hit testing everywhere
        if (columns is null || columns.Count == 0)
        {
            return;
        }
        var plot = Plot;
        var grid = ChartText.Resource(this, "Brush.Border", Brushes.LightGray);
        var muted = ChartText.Resource(this, "Brush.TextMuted", Brushes.Gray);
        var max = Math.Max(1, columns.Max(c => c.Values.Sum()));
        var step = NiceStep(max / 4);
        var top = Math.Ceiling(max / step) * step;
        var gridPen = new Pen(grid, 1) { DashStyle = new DashStyle([3, 3], 0) };
        for (var v = 0.0; v <= top + 0.5; v += step)
        {
            var y = Math.Round(plot.Bottom - v / top * plot.Height) + 0.5;
            dc.DrawLine(v == 0 ? new Pen(grid, 1) : gridPen, new Point(plot.Left, y), new Point(plot.Right, y));
            var label = ChartText.Text(this, ChartText.Compact(v), 10.5, muted);
            dc.DrawText(label, new Point(plot.Left - 6 - label.Width, y - label.Height / 2));
        }
        var slot = plot.Width / columns.Count;
        var width = Math.Clamp(slot * 0.62, 2, 36);
        var brushes = SeriesBrushes ?? [Brushes.SteelBlue, Brushes.Orange];
        // Labels: as many as fit.
        var labelEvery = Math.Max(1, (int)Math.Ceiling(columns.Count * 46 / plot.Width));
        for (var i = 0; i < columns.Count; i++)
        {
            var x = plot.Left + slot * i + (slot - width) / 2;
            if (i == _hover)
            {
                dc.DrawRectangle(ChartText.Resource(this, "Brush.Hover", Brushes.WhiteSmoke), null, new Rect(plot.Left + slot * i, plot.Top, slot, plot.Height));
            }
            var y = plot.Bottom;
            for (var s = 0; s < columns[i].Values.Count; s++)
            {
                var h = columns[i].Values[s] / top * plot.Height;
                if (h <= 0)
                {
                    continue;
                }
                var rect = new Rect(x, y - h, width, h);
                var radius = s == columns[i].Values.Count - 1 || columns[i].Values.Skip(s + 1).All(v => v <= 0) ? Math.Min(3, width / 3) : 0;
                dc.DrawRoundedRectangle(brushes[s % brushes.Count], null, rect, radius, radius);
                y -= h;
            }
            if (i % labelEvery == 0)
            {
                var label = ChartText.Text(this, columns[i].Label, 10.5, muted);
                dc.DrawText(label, new Point(plot.Left + slot * i + slot / 2 - label.Width / 2, plot.Bottom + 6));
            }
        }
    }

    private static double NiceStep(double raw)
    {
        if (raw <= 0)
        {
            return 1;
        }
        var magnitude = Math.Pow(10, Math.Floor(Math.Log10(raw)));
        var normalized = raw / magnitude;
        return (normalized <= 1 ? 1 : normalized <= 2 ? 2 : normalized <= 5 ? 5 : 10) * magnitude;
    }

    private void OnMouseMove(object sender, MouseEventArgs e)
    {
        var columns = Columns;
        if (columns is null || columns.Count == 0)
        {
            return;
        }
        var plot = Plot;
        var x = e.GetPosition(this).X;
        var index = x < plot.Left || x > plot.Right ? -1 : (int)((x - plot.Left) / (plot.Width / columns.Count));
        index = Math.Clamp(index, -1, columns.Count - 1);
        if (index != _hover)
        {
            _hover = index;
            ToolTip = index >= 0 ? columns[index].Tooltip : null;
            InvalidateVisual();
        }
    }
}

/// <summary>A donut of shares (e.g. tokens by feature), with the total in the middle and a hover tooltip.</summary>
public sealed class DonutChart : FrameworkElement
{
    public static readonly DependencyProperty SlicesProperty = DependencyProperty.Register(nameof(Slices), typeof(IEnumerable<ChartSlice>), typeof(DonutChart),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty CenterLabelProperty = DependencyProperty.Register(nameof(CenterLabel), typeof(string), typeof(DonutChart),
        new FrameworkPropertyMetadata("", FrameworkPropertyMetadataOptions.AffectsRender));

    private int _hover = -1;

    public DonutChart()
    {
        MouseMove += OnMouseMove;
        MouseLeave += (_, _) => { _hover = -1; ToolTip = null; InvalidateVisual(); };
        System.Windows.Controls.ToolTipService.SetInitialShowDelay(this, 0);
    }

    public IEnumerable<ChartSlice>? Slices { get => (IEnumerable<ChartSlice>?)GetValue(SlicesProperty); set => SetValue(SlicesProperty, value); }
    public string CenterLabel { get => (string)GetValue(CenterLabelProperty); set => SetValue(CenterLabelProperty, value); }

    protected override Size MeasureOverride(Size availableSize) => new(170, 170);

    private (Point Center, double Outer, double Inner) Geometry()
    {
        var side = Math.Min(ActualWidth, ActualHeight);
        return (new Point(ActualWidth / 2, ActualHeight / 2), side / 2 - 4, side / 2 * 0.58);
    }

    protected override void OnRender(DrawingContext dc)
    {
        var slices = Slices?.Where(s => s.Value > 0).ToList() ?? [];
        var (center, outer, inner) = Geometry();
        dc.DrawRectangle(Brushes.Transparent, null, new Rect(0, 0, ActualWidth, ActualHeight));
        var total = slices.Sum(s => s.Value);
        if (total <= 0)
        {
            dc.DrawEllipse(null, new Pen(ChartText.Resource(this, "Brush.Border", Brushes.LightGray), outer - inner), center, (outer + inner) / 2, (outer + inner) / 2);
            return;
        }
        var angle = -90.0;
        for (var i = 0; i < slices.Count; i++)
        {
            var sweep = slices[i].Value / total * 360;
            var grow = i == _hover ? 5 : 0;
            dc.DrawGeometry(slices[i].Brush, new Pen(ChartText.Resource(this, "Brush.Surface", Brushes.White), 1.5), Segment(center, outer + grow, inner, angle, sweep));
            angle += sweep;
        }
        var text = ChartText.Resource(this, "Brush.Text", Brushes.Black);
        var muted = ChartText.Resource(this, "Brush.TextMuted", Brushes.Gray);
        var big = ChartText.Text(this, ChartText.Compact(total), 18, text, FontWeights.SemiBold);
        dc.DrawText(big, new Point(center.X - big.Width / 2, center.Y - big.Height / 2 - 6));
        var small = ChartText.Text(this, CenterLabel, 10.5, muted);
        dc.DrawText(small, new Point(center.X - small.Width / 2, center.Y + big.Height / 2 - 6));
    }

    private static Geometry Segment(Point c, double outer, double inner, double start, double sweep)
    {
        if (sweep >= 359.99)
        {
            var ring = new CombinedGeometry(GeometryCombineMode.Exclude, new EllipseGeometry(c, outer, outer), new EllipseGeometry(c, inner, inner));
            ring.Freeze();
            return ring;
        }
        Point At(double radius, double degrees) => new(c.X + radius * Math.Cos(degrees * Math.PI / 180), c.Y + radius * Math.Sin(degrees * Math.PI / 180));
        var large = sweep > 180;
        var figure = new PathFigure { StartPoint = At(outer, start), IsClosed = true };
        figure.Segments.Add(new ArcSegment(At(outer, start + sweep), new Size(outer, outer), 0, large, SweepDirection.Clockwise, true));
        figure.Segments.Add(new LineSegment(At(inner, start + sweep), true));
        figure.Segments.Add(new ArcSegment(At(inner, start), new Size(inner, inner), 0, large, SweepDirection.Counterclockwise, true));
        var geometry = new PathGeometry([figure]);
        geometry.Freeze();
        return geometry;
    }

    private void OnMouseMove(object sender, MouseEventArgs e)
    {
        var slices = Slices?.Where(s => s.Value > 0).ToList() ?? [];
        var (center, outer, inner) = Geometry();
        var p = e.GetPosition(this);
        var dx = p.X - center.X;
        var dy = p.Y - center.Y;
        var distance = Math.Sqrt(dx * dx + dy * dy);
        var index = -1;
        if (distance >= inner && distance <= outer + 6 && slices.Count > 0)
        {
            var degrees = (Math.Atan2(dy, dx) * 180 / Math.PI + 90 + 360) % 360;
            var total = slices.Sum(s => s.Value);
            var at = 0.0;
            for (var i = 0; i < slices.Count; i++)
            {
                at += slices[i].Value / total * 360;
                if (degrees <= at)
                {
                    index = i;
                    break;
                }
            }
        }
        if (index != _hover)
        {
            _hover = index;
            ToolTip = index >= 0 ? $"{slices[index].Label}: {slices[index].ValueText} ({slices[index].ShareText})" : null;
            InvalidateVisual();
        }
    }
}
