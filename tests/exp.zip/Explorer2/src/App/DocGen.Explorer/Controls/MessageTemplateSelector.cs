using System.Windows;
using System.Windows.Controls;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Controls;

public sealed class MessageTemplateSelector : DataTemplateSelector
{
    public DataTemplate? User { get; set; }
    public DataTemplate? Assistant { get; set; }

    /// <summary>A note in the conversation (Talk: "Now talking with …"), not an answer.</summary>
    public DataTemplate? Notice { get; set; }

    public override DataTemplate? SelectTemplate(object item, DependencyObject container) => item switch
    {
        ChatMessageViewModel { IsUser: true } => User,
        ChatMessageViewModel { IsNotice: true } when Notice is not null => Notice,
        _ => Assistant,
    };
}
