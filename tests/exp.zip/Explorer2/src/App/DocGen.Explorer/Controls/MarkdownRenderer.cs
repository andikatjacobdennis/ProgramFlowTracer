using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Documents;
using System.Windows.Media;
using DocGen.Explorer.Engine.Code;
using DocGen.Explorer.Engine.Markdown;
using DocGen.Explorer.Infrastructure;
using MdInline = DocGen.Explorer.Engine.Markdown.MdInline;
using Span = System.Windows.Documents.Span;

namespace DocGen.Explorer.Controls;

public sealed class MarkdownRenderOptions
{
    /// <summary>Called with a link's target when it is clicked (repo:, page:, cite:, http(s):, relative paths).</summary>
    public Action<string>? OnLink { get; init; }

    /// <summary>Called with a heading's anchor when its "copy link" button is pressed (null hides the button).</summary>
    public Action<string>? OnCopyHeadingLink { get; init; }

    /// <summary>Smaller type and tighter spacing (the assistant panel).</summary>
    public bool Compact { get; init; }

    /// <summary>Turns "[3]" into a clickable citation.</summary>
    public bool Citations { get; init; }

    /// <summary>Optional element placed before the content (the page's title card).</summary>
    public UIElement? Hero { get; init; }
}

public sealed class RenderedMarkdown
{
    public required FlowDocument Document { get; init; }
    public List<(string Anchor, string Text, int Level, Block Block)> Headings { get; } = [];
}

/// <summary>Renders the engine's Markdown AST as a themed WPF FlowDocument.</summary>
public static partial class MarkdownRenderer
{
    public static RenderedMarkdown Render(string? markdown, MarkdownRenderOptions options)
    {
        var (result, pending) = RenderStart(markdown, options, int.MaxValue);
        Append(result, pending, options);
        Finish(result);
        return result;
    }

    /// <summary>
    /// Starts a progressive render: the document with its first <paramref name="firstBlocks"/> blocks, and the blocks still
    /// to add with <see cref="Append"/> (a large page then shows at once and fills in while the UI stays responsive).
    /// </summary>
    public static (RenderedMarkdown Result, List<MdBlock> Pending) RenderStart(string? markdown, MarkdownRenderOptions options, int firstBlocks)
    {
        var parsed = MarkdownDocument.Parse(markdown);
        var document = new FlowDocument
        {
            PagePadding = new Thickness(0),
            TextAlignment = TextAlignment.Left,
            IsOptimalParagraphEnabled = false,
            IsHyphenationEnabled = false,
        };
        document.SetResourceReference(FlowDocument.FontFamilyProperty, options.Compact ? "Font.Conversation" : "Font.Document");
        document.SetResourceReference(FlowDocument.FontSizeProperty, options.Compact ? "FontSize.Conversation" : "FontSize.Document");
        document.SetResourceReference(FlowDocument.LineHeightProperty, options.Compact ? "LineHeight.Conversation" : "LineHeight.Document");
        document.SetResourceReference(TextElement.ForegroundProperty, "Brush.Text");
        document.SetResourceReference(FlowDocument.BackgroundProperty, options.Compact ? "Brush.Window" : "Brush.Window");
        var result = new RenderedMarkdown { Document = document };
        if (options.Hero is not null)
        {
            document.Blocks.Add(new BlockUIContainer(options.Hero) { Margin = new Thickness(0, 0, 0, 18) });
        }
        var count = Math.Min(firstBlocks, parsed.Blocks.Count);
        Append(result, parsed.Blocks.Take(count), options);
        return (result, parsed.Blocks.Skip(count).ToList());
    }

    public static void Append(RenderedMarkdown result, IEnumerable<MdBlock> blocks, MarkdownRenderOptions options)
    {
        foreach (var block in blocks)
        {
            if (RenderBlock(block, options, result, 0) is { } rendered)
            {
                result.Document.Blocks.Add(rendered);
            }
        }
    }

    /// <summary>Removes the trailing space after the last block.</summary>
    public static void Finish(RenderedMarkdown result)
    {
        if (result.Document.Blocks.LastBlock is { } last)
        {
            last.Margin = new Thickness(last.Margin.Left, last.Margin.Top, last.Margin.Right, 0);
        }
    }

    private static Block? RenderBlock(MdBlock block, MarkdownRenderOptions options, RenderedMarkdown result, int depth)
    {
        switch (block)
        {
            case MdHeading h:
                return RenderHeading(h, options, result);
            case MdParagraph p:
            {
                var paragraph = new Paragraph { Margin = new Thickness(0, 0, 0, options.Compact ? 10 : 14) };
                AddInlines(paragraph.Inlines, p.Inlines, options);
                return paragraph;
            }
            case MdCode c:
                return RenderCode(c, options);
            case MdQuote q:
            {
                var section = new Section { Margin = new Thickness(0, 0, 0, 14), Padding = new Thickness(14, 2, 0, 2), BorderThickness = new Thickness(3, 0, 0, 0) };
                section.SetResourceReference(TextElement.ForegroundProperty, "Brush.TextMuted");
                section.SetResourceReference(Section.BorderBrushProperty, "Brush.BorderStrong");
                foreach (var inner in q.Blocks)
                {
                    if (RenderBlock(inner, options, result, depth + 1) is { } b)
                    {
                        section.Blocks.Add(b);
                    }
                }
                if (section.Blocks.LastBlock is { } lastInner)
                {
                    lastInner.Margin = new Thickness(0);
                }
                return section;
            }
            case MdList l:
            {
                var list = new List
                {
                    MarkerStyle = l.Ordered ? TextMarkerStyle.Decimal : depth % 2 == 0 ? TextMarkerStyle.Disc : TextMarkerStyle.Circle,
                    StartIndex = Math.Max(1, l.Start),
                    Margin = new Thickness(0, 0, 0, options.Compact ? 10 : 14),
                    Padding = new Thickness(22, 0, 0, 0),
                };
                foreach (var item in l.Items)
                {
                    var listItem = new ListItem();
                    var first = true;
                    foreach (var inner in item.Blocks)
                    {
                        var rendered = RenderBlock(inner, options, result, depth + 1);
                        if (rendered is null)
                        {
                            continue;
                        }
                        if (first && item.Checked is { } done && rendered is Paragraph para)
                        {
                            para.Inlines.InsertBefore(para.Inlines.FirstInline, new Run(done ? "☑ " : "☐ "));
                        }
                        rendered.Margin = new Thickness(0, 0, 0, 4);
                        listItem.Blocks.Add(rendered);
                        first = false;
                    }
                    list.ListItems.Add(listItem);
                }
                return list;
            }
            case MdTable t:
                return RenderTable(t, options);
            case MdRule:
            {
                var rule = new Border { Height = 1, Margin = new Thickness(0, 8, 0, 8) };
                rule.SetResourceReference(Border.BackgroundProperty, "Brush.Border");
                return new BlockUIContainer(rule);
            }
        }
        return null;
    }

    private static Block RenderHeading(MdHeading h, MarkdownRenderOptions options, RenderedMarkdown result)
    {
        var size = options.Compact
            ? h.Level switch { 1 => 15.5, 2 => 15.0, _ => 14.5 }
            : h.Level switch { 1 => 21.0, 2 => 17.0, 3 => 15.0, _ => 14.5 };
        var paragraph = new Paragraph
        {
            FontSize = size,
            FontWeight = FontWeights.SemiBold,
            Margin = new Thickness(0, options.Compact ? 10 : h.Level <= 2 ? 22 : 16, 0, options.Compact ? 6 : 8),
            LineHeight = size * 1.3,
        };
        paragraph.SetResourceReference(Paragraph.FontFamilyProperty, "Font.Display");
        AddInlines(paragraph.Inlines, h.Inlines, options);
        if (options.OnCopyHeadingLink is { } copy && h.Level >= 2)
        {
            var button = new Button
            {
                Content = Icons.Link,
                ToolTip = "Copy link to this section",
                Width = 26,
                Height = 26,
                FontSize = 12,
                Margin = new Thickness(8, 0, 0, -4),
                Opacity = 0.55,
            };
            button.SetResourceReference(FrameworkElement.StyleProperty, "Button.Icon");
            var anchor = h.Anchor;
            button.Click += (_, _) => copy(anchor);
            paragraph.Inlines.Add(new InlineUIContainer(button) { BaselineAlignment = BaselineAlignment.Center });
        }
        result.Headings.Add((h.Anchor, h.Text, h.Level, paragraph));
        return paragraph;
    }

    private static Block RenderCode(MdCode code, MarkdownRenderOptions options)
    {
        var container = new Border { CornerRadius = new CornerRadius(10), BorderThickness = new Thickness(1) };
        container.SetResourceReference(Border.BorderBrushProperty, "Brush.BorderSubtle");
        container.SetResourceReference(Border.BackgroundProperty, "Brush.Code.Block");
        var grid = new Grid();
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var header = new DockPanel { Margin = new Thickness(12, 4, 6, 0), LastChildFill = false };
        var language = new TextBlock { Text = code.Language.Length > 0 ? code.Language : "text", FontSize = 11.5, VerticalAlignment = VerticalAlignment.Center };
        language.SetResourceReference(TextBlock.ForegroundProperty, "Brush.TextMuted");
        header.Children.Add(language);
        var copyButton = new Button { Content = Icons.Copy, ToolTip = "Copy", Width = 28, Height = 28, FontSize = 12 };
        copyButton.SetResourceReference(FrameworkElement.StyleProperty, "Button.Icon");
        copyButton.Click += (_, _) =>
        {
            if (Ui.Copy(code.Code))
            {
                Ui.Notify("Copied.");
            }
        };
        DockPanel.SetDock(copyButton, Dock.Right);
        header.Children.Add(copyButton);
        Grid.SetRow(header, 0);
        grid.Children.Add(header);

        UIElement body;
        if (code.Language.Equals("mermaid", StringComparison.OrdinalIgnoreCase))
        {
            // Every kind of Mermaid diagram, drawn by mermaid.js; "Show source" switches to the code.
            var source = CodeText(code, options);
            source.Visibility = Visibility.Collapsed;
            var diagram = new MermaidView(code.Code, source);
            var toggle = new Button { Content = "Show source", FontSize = 12, Padding = new Thickness(8, 3, 8, 3), Margin = new Thickness(0, 0, 4, 0) };
            toggle.SetResourceReference(FrameworkElement.StyleProperty, "Button.Ghost");
            toggle.Click += (_, _) =>
            {
                var showSource = source.Visibility != Visibility.Visible;
                source.Visibility = showSource ? Visibility.Visible : Visibility.Collapsed;
                diagram.Visibility = showSource ? Visibility.Collapsed : Visibility.Visible;
                toggle.Content = showSource ? "Show diagram" : "Show source";
            };
            DockPanel.SetDock(toggle, Dock.Right);
            header.Children.Insert(1, toggle);
            var stack = new StackPanel();
            stack.Children.Add(diagram);
            stack.Children.Add(source);
            body = stack;
        }
        else
        {
            body = CodeText(code, options);
        }
        Grid.SetRow(body, 1);
        grid.Children.Add(body);
        container.Child = grid;
        return new BlockUIContainer(container) { Margin = new Thickness(0, 2, 0, options.Compact ? 12 : 16) };
    }

    /// <summary>
    /// A code block's text: coloured, and selectable like any text (drag, double-click a word, triple-click a line,
    /// Ctrl+A, Ctrl+C). Each line is its own paragraph, so a triple-click takes one line. Long lines scroll sideways.
    /// </summary>
    private static FrameworkElement CodeText(MdCode code, MarkdownRenderOptions options)
    {
        var size = options.Compact ? 12.5 : 13;
        var document = new FlowDocument { PagePadding = new Thickness(0), FontSize = size, TextAlignment = TextAlignment.Left };
        document.SetResourceReference(FlowDocument.FontFamilyProperty, "Font.Mono");
        var lines = code.Code.Split('\n');
        var spans = SyntaxHighlighter.Highlight(lines, code.Language);
        var longest = 0;
        for (var i = 0; i < spans.Count; i++)
        {
            var paragraph = new Paragraph { Margin = new Thickness(0), LineHeight = size * 1.42, LineStackingStrategy = LineStackingStrategy.BlockLineHeight };
            foreach (var span in spans[i])
            {
                paragraph.Inlines.Add(CodeRun(span));
            }
            longest = Math.Max(longest, lines[i].TrimEnd('\r').Replace("\t", "    ", StringComparison.Ordinal).Length);
            document.Blocks.Add(paragraph);
        }
        // The page as wide as the longest line, so lines never wrap and scroll sideways instead.
        document.PageWidth = Math.Max(120, longest * size * 0.62 + 24);
        var box = new RichTextBox
        {
            Document = document,
            IsReadOnly = true,
            IsReadOnlyCaretVisible = false,
            BorderThickness = new Thickness(0),
            Background = Brushes.Transparent,
            Padding = new Thickness(0),
            Margin = new Thickness(14, 2, 14, 12),
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
            VerticalScrollBarVisibility = ScrollBarVisibility.Disabled,
            FocusVisualStyle = null,
            Cursor = System.Windows.Input.Cursors.IBeam,
            AutoWordSelection = false,
        };
        box.SetResourceReference(Control.ForegroundProperty, "Brush.Text");
        box.SetResourceReference(TextBoxBase.SelectionBrushProperty, "Brush.Accent");
        box.ContextMenu = SummariseSelection.Menu(box);
        AutomationProperties.SetName(box, "Code" + (code.Language.Length > 0 ? " (" + code.Language + ")" : ""));
        return box;
    }

    public static Run CodeRun(Engine.Code.Span span)
    {
        var run = new Run(span.Text);
        // A diff's added and removed lines: the theme's diff colours.
        if (span.Class is TokenClass.Inserted or TokenClass.Deleted)
        {
            run.SetResourceReference(TextElement.ForegroundProperty, span.Class == TokenClass.Inserted ? "DiffAddedText" : "DiffRemovedText");
            run.SetResourceReference(TextElement.BackgroundProperty, span.Class == TokenClass.Inserted ? "DiffAdded" : "DiffRemoved");
            return run;
        }
        run.SetResourceReference(TextElement.ForegroundProperty, "Brush.Syntax." + span.Class switch
        {
            TokenClass.Keyword => "Keyword",
            TokenClass.Type => "Type",
            TokenClass.String => "String",
            TokenClass.Comment => "Comment",
            TokenClass.Number => "Number",
            TokenClass.Preprocessor => "Preprocessor",
            TokenClass.Tag => "Tag",
            TokenClass.Attribute => "Attribute",
            TokenClass.Heading => "Heading",
            TokenClass.Punctuation => "Punctuation",
            _ => "Plain",
        });
        if (span.Class == TokenClass.Comment)
        {
            run.FontStyle = FontStyles.Italic;
        }
        return run;
    }

    private static Block RenderTable(MdTable table, MarkdownRenderOptions options)
    {
        if (options.Compact)
        {
            return RenderScrollingTable(table, options);
        }
        // A table, drawn calmly: every cell a lightly filled tile with a thin gap around it, the header a shade darker; no lines.
        var flowTable = new Table { CellSpacing = 2, Margin = new Thickness(0, 0, 0, 14) };
        // Columns share the width in proportion to their longest cell (capped), so a short "Kind" column stays narrow.
        // (Weights are normalised to sum to 1: WPF's table layout mis-shares larger star values and starved the last column.)
        var weights = Enumerable.Range(0, table.Header.Count).Select(c => (double)Math.Clamp(table.Rows
            .Select(r => c < r.Count ? MarkdownDocument.PlainText(r[c]).Length : 0)
            .Append(MarkdownDocument.PlainText(table.Header[c]).Length).Max(), 4, 60) + 6).ToList();
        var total = weights.Sum();
        foreach (var weight in weights)
        {
            flowTable.Columns.Add(new TableColumn { Width = new GridLength(weight / total, GridUnitType.Star) });
        }
        var group = new TableRowGroup();
        flowTable.RowGroups.Add(group);
        var headerRow = new TableRow { FontWeight = FontWeights.Medium };
        for (var c = 0; c < table.Header.Count; c++)
        {
            headerRow.Cells.Add(Cell(table.Header[c], table.Alignments.ElementAtOrDefault(c), options, "Brush.Table.Header"));
        }
        group.Rows.Add(headerRow);
        foreach (var row in table.Rows)
        {
            var tableRow = new TableRow();
            for (var c = 0; c < table.Header.Count; c++)
            {
                tableRow.Cells.Add(Cell(c < row.Count ? row[c] : [], table.Alignments.ElementAtOrDefault(c), options, "Brush.Table.Cell"));
            }
            group.Rows.Add(tableRow);
        }
        return flowTable;
    }

    /// <summary>
    /// A table in a narrow place (Ask, Talk): every column as wide as its content needs (a long cell wraps at a
    /// readable width) and, when that is wider than the room, a horizontal scroll bar under the table — instead of
    /// squeezing the columns until each word stands on its own line. The wheel still scrolls the conversation;
    /// Shift+wheel or the bar scrolls the table.
    /// </summary>
    private static Block RenderScrollingTable(MdTable table, MarkdownRenderOptions options)
    {
        const double MaxCellWidth = 340;
        var grid = new Grid { HorizontalAlignment = HorizontalAlignment.Left };
        for (var c = 0; c < table.Header.Count; c++)
        {
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        }
        void AddRow(IReadOnlyList<IReadOnlyList<MdInline>> cells, bool header)
        {
            var r = grid.RowDefinitions.Count;
            grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            for (var c = 0; c < table.Header.Count; c++)
            {
                var alignment = table.Alignments.ElementAtOrDefault(c);
                var text = new TextBlock
                {
                    TextWrapping = TextWrapping.Wrap,
                    MaxWidth = MaxCellWidth,
                    FontSize = 13,
                    FontWeight = header ? FontWeights.Medium : FontWeights.Normal,
                    TextAlignment = alignment switch { "right" => TextAlignment.Right, "center" => TextAlignment.Center, _ => TextAlignment.Left },
                };
                text.SetResourceReference(TextBlock.ForegroundProperty, "Brush.Text");
                AddInlines(text.Inlines, c < cells.Count ? cells[c] : [], options);
                // The same calm tiles as a page's table: filled cells with a thin gap, the header a shade darker.
                var tile = new Border { Child = text, Padding = new Thickness(10, 6, 10, 6), Margin = new Thickness(0, 0, 2, 2) };
                tile.SetResourceReference(Border.BackgroundProperty, header ? "Brush.Table.Header" : "Brush.Table.Cell");
                Grid.SetRow(tile, r);
                Grid.SetColumn(tile, c);
                grid.Children.Add(tile);
            }
        }
        AddRow(table.Header, header: true);
        foreach (var row in table.Rows)
        {
            AddRow(row, header: false);
        }
        var scroller = new ScrollViewer
        {
            Content = grid,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
            VerticalScrollBarVisibility = ScrollBarVisibility.Disabled,
            Focusable = false,
            PanningMode = PanningMode.HorizontalOnly,
        };
        System.Windows.Automation.AutomationProperties.SetName(scroller, "Table");
        return new BlockUIContainer(scroller) { Margin = new Thickness(0, 0, 0, 12) };
    }

    private static TableCell Cell(IReadOnlyList<MdInline> inlines, string? alignment, MarkdownRenderOptions options, string background)
    {
        var paragraph = new Paragraph
        {
            Margin = new Thickness(0),
            FontSize = options.Compact ? 13 : 14,
            TextAlignment = alignment switch { "right" => TextAlignment.Right, "center" => TextAlignment.Center, _ => TextAlignment.Left },
        };
        AddInlines(paragraph.Inlines, inlines, options);
        var cell = new TableCell(paragraph) { Padding = new Thickness(12, 8, 12, 8) };
        cell.SetResourceReference(TableCell.BackgroundProperty, background);
        return cell;
    }

    private static void AddInlines(InlineCollection target, IEnumerable<MdInline> inlines, MarkdownRenderOptions options)
    {
        foreach (var inline in inlines)
        {
            switch (inline)
            {
                case MdText t when options.Citations:
                    AddWithCitations(target, t.Text, options);
                    break;
                case MdText t:
                    target.Add(new Run(t.Text));
                    break;
                case MdStrong s:
                {
                    var bold = new Bold();
                    AddInlines(bold.Inlines, s.Inlines, options);
                    target.Add(bold);
                    break;
                }
                case MdEmphasis e:
                {
                    var italic = new Italic();
                    AddInlines(italic.Inlines, e.Inlines, options);
                    target.Add(italic);
                    break;
                }
                case MdStrike s:
                {
                    var span = new Span { TextDecorations = TextDecorations.Strikethrough };
                    AddInlines(span.Inlines, s.Inlines, options);
                    target.Add(span);
                    break;
                }
                case MdInlineCode c:
                {
                    var run = new Run(c.Code) { FontSize = options.Compact ? 12.5 : 13 };
                    run.SetResourceReference(TextElement.FontFamilyProperty, "Font.Mono");
                    run.SetResourceReference(TextElement.BackgroundProperty, "Brush.Code.Inline");
                    target.Add(run);
                    break;
                }
                case MdLink l:
                {
                    var link = new Hyperlink { TextDecorations = null, Cursor = System.Windows.Input.Cursors.Hand };
                    link.SetResourceReference(TextElement.ForegroundProperty, "Brush.Link");
                    AddInlines(link.Inlines, l.Inlines, NoCitations(options));
                    link.ToolTip = l.Url.StartsWith("repo:", StringComparison.Ordinal) ? l.Url[5..] : l.Url.StartsWith("page:", StringComparison.Ordinal) ? "Open page"
                        : ViewModels.HelpLinks.Find(l.Url) is { } place ? "Go to " + place.Label : l.Url;
                    var url = l.Url;
                    link.Click += (_, _) => options.OnLink?.Invoke(url);
                    link.MouseEnter += (_, _) => link.TextDecorations = TextDecorations.Underline;
                    link.MouseLeave += (_, _) => link.TextDecorations = null;
                    target.Add(link);
                    break;
                }
                case MdImage i:
                {
                    var run = new Run($"[image: {i.Alt}]") { FontStyle = FontStyles.Italic };
                    run.SetResourceReference(TextElement.ForegroundProperty, "Brush.TextMuted");
                    target.Add(run);
                    break;
                }
                case MdLineBreak:
                    target.Add(new LineBreak());
                    break;
            }
        }
    }

    // Links never contain citation links.
    private static MarkdownRenderOptions NoCitations(MarkdownRenderOptions o)
        => o.Citations ? new MarkdownRenderOptions { OnLink = o.OnLink, Compact = o.Compact, Citations = false, OnCopyHeadingLink = o.OnCopyHeadingLink } : o;

    private static void AddWithCitations(InlineCollection target, string text, MarkdownRenderOptions options)
    {
        var last = 0;
        foreach (Match match in CitationRegex().Matches(text))
        {
            if (match.Index > last)
            {
                target.Add(new Run(text[last..match.Index]));
            }
            var number = match.Groups[1].Value;
            var link = new Hyperlink(new Run($"[{number}]")) { TextDecorations = null, FontSize = 11.5, FontWeight = FontWeights.SemiBold };
            link.SetResourceReference(TextElement.ForegroundProperty, "Brush.Link");
            link.ToolTip = $"Evidence {number}";
            link.Click += (_, _) => options.OnLink?.Invoke("cite:" + number);
            target.Add(link);
            last = match.Index + match.Length;
        }
        if (last < text.Length)
        {
            target.Add(new Run(text[last..]));
        }
    }

    [GeneratedRegex(@"\[(\d{1,2})\]")]
    private static partial Regex CitationRegex();
}
