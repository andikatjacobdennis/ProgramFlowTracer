using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace DocGen.Explorer.Avatars;

/// <summary>
/// A persona's animated cartoon face. It shows <see cref="Emotion"/> (eyes, brows, mouth and a little sign), blinks
/// every few seconds, and while <see cref="IsTalking"/> moves its mouth and bobs; when the emotion changes it gives a
/// small pop so the change is noticed. Poked (clicked), it does a little funny turn — a boing, a wiggle or a spin — looks
/// surprised, giggles and says something short. Unknown avatar ids get a stable picture chosen from <see cref="Seed"/>.
/// </summary>
public sealed class AvatarFace : FrameworkElement
{
    public static readonly DependencyProperty AvatarIdProperty = DependencyProperty.Register(nameof(AvatarId), typeof(string), typeof(AvatarFace),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty SeedProperty = DependencyProperty.Register(nameof(Seed), typeof(string), typeof(AvatarFace),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty EmotionProperty = DependencyProperty.Register(nameof(Emotion), typeof(string), typeof(AvatarFace),
        new FrameworkPropertyMetadata("neutral", FrameworkPropertyMetadataOptions.AffectsRender, (d, e) => ((AvatarFace)d).OnEmotionChanged((string?)e.OldValue)));

    public static readonly DependencyProperty IsTalkingProperty = DependencyProperty.Register(nameof(IsTalking), typeof(bool), typeof(AvatarFace),
        new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.AffectsRender, (d, _) => ((AvatarFace)d).UpdateTimers()));

    public static readonly DependencyProperty IsAnimatedProperty = DependencyProperty.Register(nameof(IsAnimated), typeof(bool), typeof(AvatarFace),
        new FrameworkPropertyMetadata(true, (d, _) => ((AvatarFace)d).UpdateTimers()));

    /// <summary>Turned off for everyone when motion is reduced (header button).</summary>
    public static bool ReduceMotion { get; set; }

    private readonly DispatcherTimer _talk = new() { Interval = TimeSpan.FromMilliseconds(120) };
    private readonly DispatcherTimer _blink = new();
    private readonly TranslateTransform _bob = new();
    private readonly ScaleTransform _pop = new(1, 1);
    private readonly ScaleTransform _squash = new(1, 1);
    private readonly RotateTransform _tilt = new();
    private readonly DispatcherTimer _poke = new() { Interval = TimeSpan.FromMilliseconds(33) };
    private readonly System.Diagnostics.Stopwatch _pokeClock = new();
    private string? _pokeEmotion;
    private string? _quip;
    private double _quipOpacity;
    private double _quipRise;
    private static readonly string[] Quips = ["Hehe!", "Hey!", "Oi!", "That tickles!", "Yes?", "Boing!", "Hello there!", "Ha ha!", "Arre, careful!", "Present!"];
    private readonly Random _random;
    private bool _mouthOpen;
    private bool _eyesClosed;
    private int _talkStep;

    public AvatarFace()
    {
        _random = new Random(GetHashCode());
        RenderTransformOrigin = new Point(0.5, 0.5);
        RenderTransform = new TransformGroup { Children = { _pop, _squash, _tilt, _bob } };
        _poke.Tick += (_, _) => PokeStep();
        MouseLeftButtonUp += (_, _) => Poke();
        _talk.Tick += (_, _) => TalkStep();
        _blink.Tick += (_, _) => BlinkStep();
        Loaded += (_, _) => UpdateTimers();
        Unloaded += (_, _) => { _talk.Stop(); _blink.Stop(); EndPoke(); };
        IsVisibleChanged += (_, _) => UpdateTimers();
        SnapsToDevicePixels = true;
    }

    public string? AvatarId { get => (string?)GetValue(AvatarIdProperty); set => SetValue(AvatarIdProperty, value); }

    /// <summary>Picks a stable picture when <see cref="AvatarId"/> is empty or unknown (a persona's name).</summary>
    public string? Seed { get => (string?)GetValue(SeedProperty); set => SetValue(SeedProperty, value); }

    public string? Emotion { get => (string?)GetValue(EmotionProperty); set => SetValue(EmotionProperty, value); }
    public bool IsTalking { get => (bool)GetValue(IsTalkingProperty); set => SetValue(IsTalkingProperty, value); }

    /// <summary>Blinking and the pop on an emotion change (off for small pictures in long lists).</summary>
    public bool IsAnimated { get => (bool)GetValue(IsAnimatedProperty); set => SetValue(IsAnimatedProperty, value); }

    protected override Size MeasureOverride(Size availableSize)
    {
        var w = double.IsInfinity(availableSize.Width) ? 48 : availableSize.Width;
        var h = double.IsInfinity(availableSize.Height) ? 48 : availableSize.Height;
        var side = Math.Min(w, h);
        return new Size(side, side);
    }

    protected override void OnRender(DrawingContext context)
    {
        var side = Math.Min(ActualWidth, ActualHeight);
        if (side <= 0)
        {
            return;
        }
        var avatar = AvatarCatalog.Find(AvatarId, Seed);
        var drawing = AvatarCatalog.DrawingFor(avatar, _pokeEmotion ?? Emotion, (IsTalking || _pokeEmotion is not null) && _mouthOpen, _eyesClosed);
        context.PushTransform(new TranslateTransform((ActualWidth - side) / 2, (ActualHeight - side) / 2));
        context.PushTransform(new ScaleTransform(side / 120, side / 120));
        context.DrawDrawing(drawing);
        context.Pop();
        context.Pop();
        if (_quip is { } quip && _quipOpacity > 0.01 && side >= 28)
        {
            DrawQuip(context, quip, side);
        }
    }

    /// <summary>What the poked face says: a small speech bubble over its top-right, rising and fading.</summary>
    private void DrawQuip(DrawingContext context, string quip, double side)
    {
        var size = Math.Clamp(side * 0.14, 9, 15);
        var text = new FormattedText(quip, System.Globalization.CultureInfo.CurrentUICulture, FlowDirection.LeftToRight,
            new Typeface(Controls.ChartText.UiFont(this), FontStyles.Normal, FontWeights.SemiBold, FontStretches.Normal), size, Brushes.Black,
            VisualTreeHelper.GetDpi(this).PixelsPerDip);
        var pad = size * 0.45;
        var box = new Rect(ActualWidth * 0.55, -text.Height - pad * 2 - 4 - _quipRise, text.Width + pad * 2, text.Height + pad);
        context.PushOpacity(_quipOpacity);
        var outline = new Pen(new SolidColorBrush(Color.FromRgb(0x2B, 0x22, 0x33)), Math.Max(1, size / 9));
        context.DrawRoundedRectangle(Brushes.White, outline, box, box.Height / 2, box.Height / 2);
        context.DrawText(text, new Point(box.X + pad, box.Y + pad / 2));
        context.Pop();
    }

    /// <summary>A poke: one of three little funny turns, a surprised look, then a giggle and a short line.</summary>
    public void Poke()
    {
        if (!IsLoaded || !IsVisible || Math.Min(ActualWidth, ActualHeight) < 24)
        {
            return;
        }
        _quip = Quips[_random.Next(Quips.Length)];
        _pokeEmotion = "surprised";
        _quipOpacity = 0;
        _quipRise = 0;
        _pokeClock.Restart();
        _poke.Start();
        if (!ReduceMotion)
        {
            var duration = new Duration(TimeSpan.FromMilliseconds(600));
            switch (_random.Next(3))
            {
                case 0: // boing: squash, stretch and a hop
                    var x = new DoubleAnimationUsingKeyFrames { Duration = duration, FillBehavior = FillBehavior.Stop };
                    var y = new DoubleAnimationUsingKeyFrames { Duration = duration, FillBehavior = FillBehavior.Stop };
                    foreach (var (t, sx, sy) in new[] { (0.0, 1.0, 1.0), (0.1, 1.18, 0.84), (0.25, 0.9, 1.12), (0.4, 1.05, 0.96), (0.6, 1.0, 1.0) })
                    {
                        x.KeyFrames.Add(new EasingDoubleKeyFrame(sx, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(t))));
                        y.KeyFrames.Add(new EasingDoubleKeyFrame(sy, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(t))));
                    }
                    _squash.BeginAnimation(ScaleTransform.ScaleXProperty, x);
                    _squash.BeginAnimation(ScaleTransform.ScaleYProperty, y);
                    var hop = new DoubleAnimation(0, -Math.Min(ActualWidth, ActualHeight) * 0.14, TimeSpan.FromMilliseconds(170))
                    { BeginTime = TimeSpan.FromMilliseconds(100), AutoReverse = true, FillBehavior = FillBehavior.Stop, EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut } };
                    _bob.BeginAnimation(TranslateTransform.YProperty, hop);
                    break;
                case 1: // a quick head wiggle
                    var wiggle = new DoubleAnimationUsingKeyFrames { Duration = duration, FillBehavior = FillBehavior.Stop };
                    foreach (var (t, angle) in new[] { (0.0, 0.0), (0.1, -14.0), (0.22, 12.0), (0.34, -9.0), (0.46, 5.0), (0.6, 0.0) })
                    {
                        wiggle.KeyFrames.Add(new EasingDoubleKeyFrame(angle, KeyTime.FromTimeSpan(TimeSpan.FromSeconds(t))));
                    }
                    _tilt.BeginAnimation(RotateTransform.AngleProperty, wiggle);
                    break;
                default: // a full spin
                    _tilt.BeginAnimation(RotateTransform.AngleProperty, new DoubleAnimation(0, 360, TimeSpan.FromMilliseconds(650))
                    { FillBehavior = FillBehavior.Stop, EasingFunction = new CubicEase { EasingMode = EasingMode.EaseInOut } });
                    break;
            }
        }
        InvalidateVisual();
    }

    private void PokeStep()
    {
        var ms = _pokeClock.ElapsedMilliseconds;
        // Surprised first, then a giggle (the mouth going), and the line rising and fading.
        if (ms > 380 && _pokeEmotion == "surprised")
        {
            _pokeEmotion = "amused";
        }
        if (_pokeEmotion == "amused" && !ReduceMotion && ms < 1100)
        {
            _mouthOpen = ms / 110 % 2 == 0;
        }
        _quipOpacity = ms < 150 ? ms / 150.0 : ms < 1050 ? 1 : Math.Max(0, 1 - (ms - 1050) / 400.0);
        _quipRise = ReduceMotion ? 0 : Math.Min(10, ms / 60.0);
        if (ms >= 1450)
        {
            EndPoke();
            return;
        }
        InvalidateVisual();
    }

    private void EndPoke()
    {
        _poke.Stop();
        _pokeEmotion = null;
        _quip = null;
        _quipOpacity = 0;
        if (!IsTalking)
        {
            _mouthOpen = false;
        }
        InvalidateVisual();
    }

    private bool Live => IsLoaded && IsVisible && !ReduceMotion;

    private void UpdateTimers()
    {
        if (Live && IsTalking)
        {
            _talkStep = 0;
            _talk.Start();
        }
        else
        {
            _talk.Stop();
            _mouthOpen = false;
            _bob.Y = 0;
            InvalidateVisual();
        }
        if (Live && IsAnimated)
        {
            if (!_blink.IsEnabled)
            {
                _blink.Interval = TimeSpan.FromMilliseconds(_random.Next(1500, 5000));
                _blink.Start();
            }
        }
        else
        {
            _blink.Stop();
            _eyesClosed = false;
        }
    }

    /// <summary>Mouth open and shut in an uneven rhythm (like syllables), with a slight bob.</summary>
    private void TalkStep()
    {
        _talkStep++;
        _mouthOpen = _random.NextDouble() < (_mouthOpen ? 0.45 : 0.75);
        _talk.Interval = TimeSpan.FromMilliseconds(_random.Next(85, 170));
        _bob.Y = Math.Sin(_talkStep * 0.9) * Math.Max(0.6, ActualHeight / 70);
        InvalidateVisual();
    }

    private void BlinkStep()
    {
        _eyesClosed = !_eyesClosed;
        // Shut for a moment, open for a few seconds (sometimes a double blink).
        _blink.Interval = _eyesClosed ? TimeSpan.FromMilliseconds(130) : TimeSpan.FromMilliseconds(_random.NextDouble() < 0.15 ? 220 : _random.Next(2600, 6200));
        InvalidateVisual();
    }

    private void OnEmotionChanged(string? previous)
    {
        if (!Live || !IsAnimated || previous is null || previous == Emotion)
        {
            return;
        }
        var pop = new DoubleAnimation(1, 1.08, TimeSpan.FromMilliseconds(140)) { AutoReverse = true, EasingFunction = new QuadraticEase() };
        _pop.BeginAnimation(ScaleTransform.ScaleXProperty, pop);
        _pop.BeginAnimation(ScaleTransform.ScaleYProperty, pop);
    }
}
