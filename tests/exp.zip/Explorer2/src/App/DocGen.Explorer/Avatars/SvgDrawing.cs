using System.Globalization;
using System.Windows;
using System.Windows.Media;
using System.Xml.Linq;

namespace DocGen.Explorer.Avatars;

/// <summary>
/// Turns the small SVG vocabulary the cartoon faces are written in — circle, ellipse, rect, path, line and g, with fill,
/// stroke, stroke-width, linecap/linejoin, opacity, fill-/stroke-opacity and translate/rotate/scale transforms — into a
/// frozen WPF <see cref="Drawing"/>. Only markup from this app's own catalogue is ever drawn (never user text).
/// </summary>
public static class SvgDrawing
{
    private static readonly CultureInfo Invariant = CultureInfo.InvariantCulture;

    private sealed record Style(string? Fill, string? Stroke, double StrokeWidth, string? LineCap, string? LineJoin, double FillOpacity, double StrokeOpacity)
    {
        public static readonly Style Root = new("#000", null, 1, null, null, 1, 1);
    }

    /// <summary>Draws <paramref name="markup"/> (the inside of a 120×120 svg), clipped to the circle of the face.</summary>
    public static Drawing Draw(string markup, bool clipToCircle = true)
    {
        var root = XElement.Parse($"<svg>{markup}</svg>");
        var group = new DrawingGroup();
        if (clipToCircle)
        {
            group.ClipGeometry = new EllipseGeometry(new Point(60, 60), 60, 60);
        }
        using (var context = group.Append())
        {
            // A transparent square keeps the drawing's bounds 120×120 whatever is drawn.
            context.DrawRectangle(Brushes.Transparent, null, new Rect(0, 0, 120, 120));
        }
        foreach (var element in root.Elements())
        {
            Add(group, element, Style.Root);
        }
        group.Freeze();
        return group;
    }

    private static void Add(DrawingGroup parent, XElement element, Style inherited)
    {
        var style = inherited with
        {
            Fill = Attr(element, "fill") ?? inherited.Fill,
            Stroke = Attr(element, "stroke") ?? inherited.Stroke,
            StrokeWidth = Number(element, "stroke-width") ?? inherited.StrokeWidth,
            LineCap = Attr(element, "stroke-linecap") ?? inherited.LineCap,
            LineJoin = Attr(element, "stroke-linejoin") ?? inherited.LineJoin,
            FillOpacity = Number(element, "fill-opacity") ?? inherited.FillOpacity,
            StrokeOpacity = Number(element, "stroke-opacity") ?? inherited.StrokeOpacity,
        };
        var opacity = Number(element, "opacity") ?? 1;
        var transform = Transform(Attr(element, "transform"));
        var name = element.Name.LocalName;
        if (name == "g")
        {
            var group = new DrawingGroup { Opacity = opacity, Transform = transform };
            foreach (var child in element.Elements())
            {
                Add(group, child, style);
            }
            parent.Children.Add(group);
            return;
        }
        Geometry? geometry = name switch
        {
            "circle" => new EllipseGeometry(new Point(Number(element, "cx") ?? 0, Number(element, "cy") ?? 0), Number(element, "r") ?? 0, Number(element, "r") ?? 0),
            "ellipse" => new EllipseGeometry(new Point(Number(element, "cx") ?? 0, Number(element, "cy") ?? 0), Number(element, "rx") ?? 0, Number(element, "ry") ?? 0),
            "rect" => new RectangleGeometry(new Rect(Number(element, "x") ?? 0, Number(element, "y") ?? 0, Number(element, "width") ?? 0, Number(element, "height") ?? 0),
                Number(element, "rx") ?? Number(element, "ry") ?? 0, Number(element, "ry") ?? Number(element, "rx") ?? 0),
            "line" => new LineGeometry(new Point(Number(element, "x1") ?? 0, Number(element, "y1") ?? 0), new Point(Number(element, "x2") ?? 0, Number(element, "y2") ?? 0)),
            "path" => Path(Attr(element, "d")),
            _ => null,
        };
        if (geometry is null)
        {
            return;
        }
        var fill = name == "line" ? null : Brush(style.Fill, style.FillOpacity);
        var stroke = Brush(style.Stroke, style.StrokeOpacity);
        Pen? pen = null;
        if (stroke is not null && style.StrokeWidth > 0)
        {
            var cap = style.LineCap switch { "round" => PenLineCap.Round, "square" => PenLineCap.Square, _ => PenLineCap.Flat };
            pen = new Pen(stroke, style.StrokeWidth)
            {
                StartLineCap = cap,
                EndLineCap = cap,
                LineJoin = style.LineJoin switch { "round" => PenLineJoin.Round, "bevel" => PenLineJoin.Bevel, _ => PenLineJoin.Miter },
            };
        }
        if (fill is null && pen is null)
        {
            return;
        }
        var drawing = new GeometryDrawing(fill, pen, geometry);
        if (transform is null && opacity >= 0.999)
        {
            parent.Children.Add(drawing);
        }
        else
        {
            parent.Children.Add(new DrawingGroup { Children = { drawing }, Transform = transform, Opacity = opacity });
        }
    }

    private static string? Attr(XElement element, string name) => element.Attribute(name)?.Value;

    private static double? Number(XElement element, string name)
        => double.TryParse(Attr(element, name), NumberStyles.Float, Invariant, out var value) ? value : null;

    /// <summary>SVG path data; filled with SVG's default nonzero rule.</summary>
    private static Geometry? Path(string? data)
    {
        if (string.IsNullOrWhiteSpace(data))
        {
            return null;
        }
        try
        {
            return Geometry.Parse("F1 " + data);
        }
        catch (FormatException)
        {
            return null;
        }
    }

    private static Brush? Brush(string? value, double opacity)
    {
        if (string.IsNullOrWhiteSpace(value) || value == "none")
        {
            return null;
        }
        if (value == "transparent")
        {
            return Brushes.Transparent;
        }
        try
        {
            var color = (Color)ColorConverter.ConvertFromString(value);
            if (opacity < 1)
            {
                color.A = (byte)Math.Round(color.A * Math.Clamp(opacity, 0, 1));
            }
            var brush = new SolidColorBrush(color);
            brush.Freeze();
            return brush;
        }
        catch (FormatException)
        {
            return null;
        }
    }

    /// <summary>translate(x y) · rotate(a cx cy) · scale(s) and their combinations.</summary>
    private static Transform? Transform(string? text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return null;
        }
        var group = new TransformGroup();
        foreach (System.Text.RegularExpressions.Match m in System.Text.RegularExpressions.Regex.Matches(text, @"(translate|rotate|scale)\s*\(([^)]*)\)"))
        {
            var args = m.Groups[2].Value.Split([' ', ','], StringSplitOptions.RemoveEmptyEntries).Select(a => double.Parse(a, Invariant)).ToArray();
            switch (m.Groups[1].Value)
            {
                case "translate":
                    group.Children.Add(new TranslateTransform(args.ElementAtOrDefault(0), args.ElementAtOrDefault(1)));
                    break;
                case "rotate":
                    group.Children.Add(args.Length >= 3 ? new RotateTransform(args[0], args[1], args[2]) : new RotateTransform(args.ElementAtOrDefault(0)));
                    break;
                case "scale":
                    group.Children.Add(new ScaleTransform(args.ElementAtOrDefault(0), args.Length > 1 ? args[1] : args.ElementAtOrDefault(0)));
                    break;
            }
        }
        // SVG applies the list right to left onto the content: WPF's group applies first to last, so reverse.
        var reversed = new TransformGroup();
        foreach (var t in group.Children.Reverse())
        {
            reversed.Children.Add(t);
        }
        return reversed.Children.Count == 0 ? null : reversed;
    }
}
