﻿using System.Globalization;
using System.Text;
using System.Windows.Media;
using DocGen.Explorer.Engine.Studio;

namespace DocGen.Explorer.Avatars;

/// <summary>How a person looks (the avatar options): everything but the eyes, brows and mouth, which follow the emotion.</summary>
internal sealed class HumanLook
{
    public string Bg { get; init; } = "#bde0fe";
    public string Skin { get; init; } = "fair";
    public string? Back { get; init; }
    public string? Front { get; init; }
    public string HairColor { get; init; } = "#3b2a20";
    public string? BrowColor { get; init; }
    public string? Hat { get; init; }
    public string? HatColor { get; init; }
    public string? Glasses { get; init; }
    public string? Beard { get; init; }
    public string Shirt { get; init; } = "#4f7cff";
    public bool Earrings { get; init; }
    public bool Curls { get; init; }
    public bool Bun { get; init; }
    /// <summary>A bald head: no hair, a soft shine on the crown.</summary>
    public bool Bald { get; init; }
    public bool Freckles { get; init; }
    public bool Brows { get; init; } = true;
}

/// <summary>Where a face's eyes and mouth are, and how they look (characters differ from people).</summary>
internal sealed record FaceAnchors(double LeftX, double RightX, double EyeY, double EyeScale, double MouthX, double MouthY, double MouthScale,
    string EyeColor = AvatarParts.Ink, string MouthColor = AvatarParts.Ink, string BrowColor = AvatarParts.Ink, bool SingleEye = false, bool Brows = true, double BrowOpacity = 1)
{
    public static readonly FaceAnchors Person = new(49, 71, 60, 1, 60, 76.5, 1);
}

/// <summary>One cartoon persona picture: drawn for any emotion, mouth open or shut, eyes open or blinking.</summary>
public sealed class Avatar
{
    internal Avatar(string id, string label, string description, Func<string, bool, bool, string> markup)
    {
        Id = id;
        Label = label;
        Description = description;
        _markup = markup;
    }

    private readonly Func<string, bool, bool, string> _markup;

    public string Id { get; }
    public string Label { get; }
    public string Description { get; }

    /// <summary>"Female" or "Male" when the picture shows one (from its description), else null: used to give a voice that fits.</summary>
    public string? Gender => System.Text.RegularExpressions.Regex.IsMatch(Description, @"\b(woman|girl|lady|grandma|queen|female)\b", System.Text.RegularExpressions.RegexOptions.IgnoreCase) ? "Female"
        : System.Text.RegularExpressions.Regex.IsMatch(Description, @"\b(man|boy|guy|grandpa|king|male)\b", System.Text.RegularExpressions.RegexOptions.IgnoreCase) ? "Male" : null;

    /// <summary>The SVG markup for an emotion (mouth open while talking, eyes closed while blinking).</summary>
    public string Markup(string emotion, bool mouthOpen = false, bool eyesClosed = false) => _markup(emotion, mouthOpen, eyesClosed);

    public override string ToString() => Label;
}

internal static partial class AvatarParts
{
    public const string Ink = "#2b2233";

    public static readonly Dictionary<string, string> Skins = new()
    {
        ["light"] = "#f9d7c0", ["fair"] = "#f3c7a5", ["tan"] = "#e0a47c", ["brown"] = "#b87a52", ["deep"] = "#7d4f33", ["olive"] = "#d8b089",
    };
}

/// <summary>
/// The persona pictures: 38 classic cartoon faces (26 people, 12 characters), 8 more characters and 54 more people —
/// 100 in all — each able to show eleven emotions (<see cref="Emotions"/>), talk (mouth open/shut) and blink.
/// </summary>
public static class AvatarCatalog
{
    private static readonly CultureInfo Invariant = CultureInfo.InvariantCulture;
    private static readonly Dictionary<(string, string, bool, bool), Drawing> Drawings = [];
    private static readonly object Gate = new();

    // Built on first use: the tables below are static fields too, initialised in file order.
    private static readonly Lazy<List<Avatar>> Catalogue = new(Build);
    private static readonly Lazy<Dictionary<string, Avatar>> Index = new(() => Catalogue.Value.ToDictionary(a => a.Id, StringComparer.OrdinalIgnoreCase));

    public static IReadOnlyList<Avatar> All => Catalogue.Value;

    private static Dictionary<string, Avatar> ById => Index.Value;

    /// <summary>Ids used by earlier versions of the explorer's starter personas.</summary>
    private static readonly Dictionary<string, string> Aliases = new(StringComparer.OrdinalIgnoreCase)
    {
        ["architect"] = "runner", ["newcomer"] = "buddy", ["tester"] = "sunny", ["product"] = "coach",
    };

    /// <summary>The picture for an id; unknown or empty ids get a stable one picked from <paramref name="fallbackSeed"/> (a name).</summary>
    public static Avatar Find(string? id, string? fallbackSeed = null)
    {
        if (!string.IsNullOrWhiteSpace(id))
        {
            if (ById.TryGetValue(id, out var avatar))
            {
                return avatar;
            }
            if (Aliases.TryGetValue(id, out var alias) && ById.TryGetValue(alias, out avatar))
            {
                return avatar;
            }
        }
        var seed = fallbackSeed ?? id ?? "";
        var hash = 17;
        foreach (var c in seed)
        {
            hash = unchecked(hash * 31 + c);
        }
        return All[Math.Abs(hash % All.Count)];
    }

    /// <summary>The drawing for an avatar in an emotion (cached; frozen, so it can be drawn from any thread).</summary>
    public static Drawing DrawingFor(Avatar avatar, string? emotion, bool mouthOpen = false, bool eyesClosed = false)
    {
        var e = Emotions.Normalize(emotion) ?? Emotions.Neutral;
        var key = (avatar.Id, e, mouthOpen, eyesClosed);
        lock (Gate)
        {
            if (Drawings.TryGetValue(key, out var cached))
            {
                return cached;
            }
        }
        Drawing drawing;
        try
        {
            drawing = SvgDrawing.Draw(avatar.Markup(e, mouthOpen, eyesClosed));
        }
        catch (Exception ex) when (ex is System.Xml.XmlException or FormatException)
        {
            Infrastructure.Logging.Error(ex, $"Avatar {avatar.Id} ({e})");
            drawing = SvgDrawing.Draw($"<circle cx=\"60\" cy=\"60\" r=\"60\" fill=\"#ccc\"/>");
        }
        lock (Gate)
        {
            Drawings[key] = drawing;
        }
        return drawing;
    }

    private static string F(double value) => value.ToString("0.##", Invariant);

    // ---------- the catalogue ----------

    private static List<Avatar> Build()
    {
        var list = new List<Avatar>();
        foreach (var (id, label, description, look) in AvatarParts.ClassicPeople)
        {
            list.Add(Person(id, label, description, look));
        }
        foreach (var (id, label, description, kind, bg) in AvatarParts.ClassicCharacterEntries)
        {
            list.Add(Character(id, label, description, kind, bg));
        }
        foreach (var (id, label, description, kind, bg) in MoreCharacterEntries)
        {
            list.Add(Character(id, label, description, kind, bg));
        }
        list.AddRange(MorePeople(100 - list.Count));
        return list;
    }

    private static Avatar Person(string id, string label, string description, HumanLook look)
        => new(id, label, description, (emotion, open, closed) => DrawPerson(look, emotion, open, closed));

    private static Avatar Character(string id, string label, string description, string kind, string bg)
        => new(id, label, description, (emotion, open, closed) =>
        {
            var anchors = CharacterAnchors[kind];
            var body = string.Format(Invariant, AvatarParts.ClassicCharacters.TryGetValue(kind, out var classic) ? classic : MoreCharacters[kind], bg);
            var sb = new StringBuilder(body);
            sb.Append(CharacterExtras.GetValueOrDefault(kind, ""));
            sb.Append(Face(anchors, emotion, open, closed, blush: false));
            sb.Append(CharacterTop.GetValueOrDefault(kind, ""));
            return sb.ToString();
        });

    /// <summary>The classic human(), with the eyes, brows and mouth drawn for the emotion.</summary>
    private static string DrawPerson(HumanLook o, string emotion, bool open, bool closed)
    {
        var skin = AvatarParts.Skins.GetValueOrDefault(o.Skin, AvatarParts.Skins["fair"]);
        var hair = o.HairColor;
        var p = new StringBuilder();
        p.Append($"<circle cx=\"60\" cy=\"60\" r=\"60\" fill=\"{o.Bg}\"/>");
        if (o.Back is { } back && AvatarParts.HairBack.TryGetValue(back, out var backPath))
        {
            p.Append($"<path d=\"{backPath}\" fill=\"{hair}\"/>");
        }
        if (o.Curls)
        {
            foreach (var (x, y, r) in new[] { (36, 44, 10), (44, 32, 11), (58, 27, 12), (72, 30, 11), (84, 42, 10), (32, 56, 8), (88, 56, 8) })
            {
                p.Append($"<circle cx=\"{x}\" cy=\"{y}\" r=\"{r}\" fill=\"{hair}\"/>");
            }
        }
        if (o.Bun)
        {
            p.Append($"<circle cx=\"60\" cy=\"20\" r=\"11\" fill=\"{hair}\"/>");
        }
        p.Append($"<path d=\"M18 120 C22 96 42 88 60 88 C78 88 98 96 102 120 Z\" fill=\"{o.Shirt}\"/>");
        p.Append($"<rect x=\"52\" y=\"76\" width=\"16\" height=\"16\" rx=\"6\" fill=\"{skin}\"/><path d=\"M52 88 q8 6 16 0\" fill=\"none\" stroke=\"{AvatarParts.Ink}\" stroke-opacity=\".12\" stroke-width=\"3\"/>");
        p.Append($"<circle cx=\"33\" cy=\"62\" r=\"6\" fill=\"{skin}\"/><circle cx=\"87\" cy=\"62\" r=\"6\" fill=\"{skin}\"/>");
        if (o.Earrings)
        {
            p.Append("<circle cx=\"33\" cy=\"70\" r=\"2.6\" fill=\"#f5c542\"/><circle cx=\"87\" cy=\"70\" r=\"2.6\" fill=\"#f5c542\"/>");
        }
        p.Append($"<ellipse cx=\"60\" cy=\"59\" rx=\"27\" ry=\"30\" fill=\"{skin}\"/>");
        if (o.Bald)
        {
            // The crown catches the light, and a little hair is left above the ears.
            p.Append("<ellipse cx=\"50\" cy=\"38\" rx=\"9\" ry=\"5\" fill=\"#ffffff\" opacity=\".35\" transform=\"rotate(-18 50 38)\"/>");
            p.Append($"<path d=\"M33.5 55 C33 50 34 46 36 43 C35.5 48 35.5 52 36.5 57 Z M86.5 55 C87 50 86 46 84 43 C84.5 48 84.5 52 83.5 57 Z\" fill=\"{hair}\" opacity=\".85\"/>");
        }
        if (o.Front is { } front && AvatarParts.HairFront.TryGetValue(front, out var frontPath) && frontPath.Length > 0)
        {
            p.Append($"<path d=\"{frontPath}\" fill=\"{hair}\"/>");
        }
        p.Append($"<path d=\"M60 63 q-3 5 0 7\" fill=\"none\" stroke=\"{AvatarParts.Ink}\" stroke-opacity=\".35\" stroke-width=\"2\" stroke-linecap=\"round\"/>");
        if (o.Freckles)
        {
            p.Append("<g fill=\"#b5673f\" opacity=\".55\"><circle cx=\"43\" cy=\"68\" r=\"1\"/><circle cx=\"47\" cy=\"70\" r=\"1\"/><circle cx=\"45\" cy=\"72\" r=\"1\"/><circle cx=\"77\" cy=\"68\" r=\"1\"/><circle cx=\"73\" cy=\"70\" r=\"1\"/><circle cx=\"75\" cy=\"72\" r=\"1\"/></g>");
        }
        var anchors = FaceAnchors.Person with { BrowColor = o.BrowColor ?? hair, Brows = o.Brows };
        // The eyes and brows, then a beard over the chin, then the mouth over the beard (in the classic drawing order).
        p.Append(Face(anchors, emotion, open, closed, blush: true, mouth: false));
        if (o.Beard is { } beard && AvatarParts.Beards.TryGetValue(beard, out var drawBeard))
        {
            p.Append(drawBeard(hair));
        }
        p.Append(Mouth(anchors, emotion, open));
        if (o.Glasses is { } glasses && AvatarParts.Glasses.TryGetValue(glasses, out var glassesMarkup))
        {
            p.Append(glassesMarkup);
        }
        if (o.Hat is { } hat && AvatarParts.Hats.TryGetValue(hat, out var drawHat))
        {
            p.Append(drawHat(o.HatColor ?? "#e0435a"));
        }
        p.Append(Extras(anchors, emotion));
        return p.ToString();
    }

    // ---------- emotions: eyes, brows, mouth, extras ----------

    /// <summary>Eyes, brows and blush (and the mouth unless <paramref name="mouth"/> is false) for an emotion.</summary>
    private static string Face(FaceAnchors a, string emotion, bool open, bool closed, bool blush, bool mouth = true)
    {
        var sb = new StringBuilder();
        if (blush)
        {
            var strong = emotion is Emotions.Happy or Emotions.Excited or Emotions.Amused;
            sb.Append($"<circle cx=\"43\" cy=\"71\" r=\"4.5\" fill=\"#ff7a8a\" opacity=\"{(strong ? ".45" : ".22")}\"/><circle cx=\"77\" cy=\"71\" r=\"4.5\" fill=\"#ff7a8a\" opacity=\"{(strong ? ".45" : ".22")}\"/>");
        }
        sb.Append(Eyes(a, emotion, closed));
        if (a.Brows)
        {
            sb.Append(Brows(a, emotion));
        }
        if (mouth)
        {
            sb.Append(Mouth(a, emotion, open));
            sb.Append(Extras(a, emotion));
        }
        return sb.ToString();
    }

    private static string Eyes(FaceAnchors a, string emotion, bool closed)
    {
        var k = a.EyeScale;
        var c = a.EyeColor;
        var sb = new StringBuilder();
        var xs = a.SingleEye ? new[] { (a.LeftX + a.RightX) / 2 } : new[] { a.LeftX, a.RightX };
        for (var i = 0; i < xs.Length; i++)
        {
            var x = xs[i];
            var y = a.EyeY;
            var right = i == 1;
            if (closed)
            {
                sb.Append($"<path d=\"M{F(x - 4.5 * k)} {F(y)} q{F(4.5 * k)} {F(2.5 * k)} {F(9 * k)} 0\" fill=\"none\" stroke=\"{c}\" stroke-width=\"{F(2.4 * Math.Max(0.8, k))}\" stroke-linecap=\"round\"/>");
                continue;
            }
            switch (emotion)
            {
                case Emotions.Happy or Emotions.Amused:
                    // Smiling eyes (amused winks the right one).
                    if (emotion == Emotions.Amused && right)
                    {
                        sb.Append($"<path d=\"M{F(x - 4.5 * k)} {F(y + 1 * k)} q{F(4.5 * k)} {F(-5 * k)} {F(9 * k)} 0\" fill=\"none\" stroke=\"{c}\" stroke-width=\"{F(2.6 * Math.Max(0.8, k))}\" stroke-linecap=\"round\"/>");
                    }
                    else
                    {
                        sb.Append($"<path d=\"M{F(x - 4.5 * k)} {F(y + 1.5 * k)} q{F(4.5 * k)} {F(-5.5 * k)} {F(9 * k)} 0\" fill=\"none\" stroke=\"{c}\" stroke-width=\"{F(2.6 * Math.Max(0.8, k))}\" stroke-linecap=\"round\"/>");
                    }
                    break;
                case Emotions.Excited or Emotions.Surprised:
                    var big = emotion == Emotions.Surprised ? 6.2 : 5.4;
                    if (c == AvatarParts.Ink)
                    {
                        sb.Append($"<circle cx=\"{F(x)}\" cy=\"{F(y)}\" r=\"{F(big * k)}\" fill=\"#fff\" stroke=\"{c}\" stroke-width=\"{F(1.2 * k)}\"/>");
                        sb.Append($"<circle cx=\"{F(x + 0.6 * k)}\" cy=\"{F(y + 0.6 * k)}\" r=\"{F((emotion == Emotions.Surprised ? 2.2 : 3) * k)}\" fill=\"{c}\"/>");
                        sb.Append($"<circle cx=\"{F(x + 1.6 * k)}\" cy=\"{F(y - 0.6 * k)}\" r=\"{F(1 * k)}\" fill=\"#fff\"/>");
                    }
                    else
                    {
                        sb.Append($"<circle cx=\"{F(x)}\" cy=\"{F(y)}\" r=\"{F(big * 0.9 * k)}\" fill=\"{c}\"/>");
                    }
                    break;
                case Emotions.Thinking:
                    // Looking up and aside.
                    Dot(sb, x - 1.3 * k, y - 1.6 * k, 3.4 * k, c);
                    break;
                case Emotions.Curious:
                    Dot(sb, x + 0.8 * k, y - 0.4 * k, (right ? 3.9 : 3.4) * k, c);
                    break;
                case Emotions.Sad:
                    Dot(sb, x, y + 1.2 * k, 3.2 * k, c);
                    sb.Append($"<path d=\"M{F(x - 4.5 * k)} {F(y - 2.2 * k)} q{F(4.5 * k)} {F(-1.5 * k)} {F(9 * k)} {F(1.5 * k)}\" fill=\"none\" stroke=\"{c}\" stroke-width=\"{F(1.6 * Math.Max(0.8, k))}\" stroke-linecap=\"round\" opacity=\".6\"/>");
                    break;
                case Emotions.Skeptical when !right && !a.SingleEye:
                    // One eye narrowed.
                    sb.Append($"<path d=\"M{F(x - 4.5 * k)} {F(y)} h{F(9 * k)}\" stroke=\"{c}\" stroke-width=\"{F(2.6 * Math.Max(0.8, k))}\" stroke-linecap=\"round\"/>");
                    break;
                case Emotions.Frustrated:
                    Dot(sb, x, y + 0.6 * k, 3.1 * k, c);
                    break;
                default:
                    Dot(sb, x, y, 3.4 * k, c);
                    break;
            }
        }
        return sb.ToString();
    }

    private static void Dot(StringBuilder sb, double x, double y, double r, string color)
    {
        sb.Append($"<circle cx=\"{F(x)}\" cy=\"{F(y)}\" r=\"{F(r)}\" fill=\"{color}\"/>");
        if (color == AvatarParts.Ink)
        {
            sb.Append($"<circle cx=\"{F(x + r * 0.35)}\" cy=\"{F(y - r * 0.35)}\" r=\"{F(r * 0.3)}\" fill=\"#fff\"/>");
        }
    }

    /// <summary>Brows carry most of an emotion: raised, worried (inner ends up), angry (inner ends down), one raised.</summary>
    private static string Brows(FaceAnchors a, string emotion)
    {
        var k = a.EyeScale;
        var y = a.EyeY - 9 * k;
        var w = 5 * k;
        var sb = new StringBuilder();
        var xs = a.SingleEye ? new[] { (a.LeftX + a.RightX) / 2 } : new[] { a.LeftX, a.RightX };
        for (var i = 0; i < xs.Length; i++)
        {
            var x = xs[i];
            var left = i == 0 && !a.SingleEye;
            var inner = left ? 1 : -1; // direction towards the nose
            // Outer and inner end heights (negative is up).
            var (outer, innerY, curve) = emotion switch
            {
                Emotions.Happy => (-1.5, -1.5, -2.5),
                Emotions.Excited => (-3.5, -3.5, -3),
                Emotions.Amused => (-1.5, -1, -2.5),
                Emotions.Surprised => (-5, -5, -3.5),
                Emotions.Curious => left ? (-1.5, -1.5, -2.5) : (-4, -4, -3),
                Emotions.Thinking => left ? (-3.5, -2.5, -2.5) : (0.5, 1, -1),
                Emotions.Concerned => (1, -3, 0.5),
                Emotions.Sad => (2, -3.5, 1),
                Emotions.Frustrated => (-2, 2.5, 0),
                Emotions.Skeptical => left ? (1.5, 2, 0) : (-4, -3.5, -2.5),
                _ => (0, 0, -1.8),
            };
            var x1 = x - inner * w; // outer end
            var x2 = x + inner * w; // inner end
            var y1 = y + outer * k;
            var y2 = y + innerY * k;
            var cx = (x1 + x2) / 2;
            var cy = (y1 + y2) / 2 + curve * k;
            sb.Append($"<path d=\"M{F(x1)} {F(y1)} Q{F(cx)} {F(cy)} {F(x2)} {F(y2)}\" fill=\"none\" stroke=\"{a.BrowColor}\" stroke-width=\"{F(2.4 * Math.Max(0.85, k * 0.9))}\" stroke-linecap=\"round\" opacity=\"{F(a.BrowOpacity)}\"/>");
        }
        return sb.ToString();
    }

    /// <summary>The mouth for an emotion, shut or open (talking alternates the two).</summary>
    private static string Mouth(FaceAnchors a, string emotion, bool open)
    {
        var k = a.MouthScale;
        var x = a.MouthX;
        var y = a.MouthY;
        var c = a.MouthColor;
        var ink = c;
        var sw = F(2.6 * Math.Max(0.8, Math.Min(k, 1.4)));
        string Curve(double halfWidth, double depth, double dy = 0) =>
            $"<path d=\"M{F(x - halfWidth * k)} {F(y + dy * k)} q{F(halfWidth * k)} {F(depth * k)} {F(2 * halfWidth * k)} 0\" fill=\"none\" stroke=\"{ink}\" stroke-width=\"{sw}\" stroke-linecap=\"round\"/>";
        string OpenShape(double halfWidth, double depth, double dy = 0, bool tongue = true, bool teeth = false)
        {
            var s = $"<path d=\"M{F(x - halfWidth * k)} {F(y + dy * k)} q{F(halfWidth * k)} {F(depth * k)} {F(2 * halfWidth * k)} 0 Z\" fill=\"{ink}\"/>";
            if (teeth)
            {
                s += $"<path d=\"M{F(x - (halfWidth - 1.6) * k)} {F(y + (dy + 0.8) * k)} h{F(2 * (halfWidth - 1.6) * k)} v{F(2.2 * k)} h{F(-2 * (halfWidth - 1.6) * k)} Z\" fill=\"#fff\"/>";
            }
            if (tongue && ink == AvatarParts.Ink)
            {
                s += $"<ellipse cx=\"{F(x)}\" cy=\"{F(y + (dy + depth * 0.36) * k)}\" rx=\"{F(halfWidth * 0.42 * k)}\" ry=\"{F(Math.Abs(depth) * 0.16 * k)}\" fill=\"#e56b7b\"/>";
            }
            return s;
        }
        string Oval(double rx, double ry, double dy = 0) =>
            $"<ellipse cx=\"{F(x)}\" cy=\"{F(y + dy * k)}\" rx=\"{F(rx * k)}\" ry=\"{F(ry * k)}\" fill=\"{ink}\"/>" +
            (ink == AvatarParts.Ink && ry > 2.5 ? $"<ellipse cx=\"{F(x)}\" cy=\"{F(y + (dy + ry * 0.5) * k)}\" rx=\"{F(rx * 0.55 * k)}\" ry=\"{F(ry * 0.38 * k)}\" fill=\"#e56b7b\"/>" : "");
        string Frown(double halfWidth, double depth) =>
            $"<path d=\"M{F(x - halfWidth * k)} {F(y + 2 * k)} q{F(halfWidth * k)} {F(-depth * k)} {F(2 * halfWidth * k)} 0\" fill=\"none\" stroke=\"{ink}\" stroke-width=\"{sw}\" stroke-linecap=\"round\"/>";

        return emotion switch
        {
            Emotions.Happy => open ? OpenShape(8.5, 10, -1.5, teeth: true) : Curve(8, 7.5, -1.5),
            Emotions.Excited => open ? OpenShape(10, 14, -2, teeth: true) : OpenShape(9, 11, -2, teeth: true),
            Emotions.Amused => open ? OpenShape(9, 11, -1.5) : $"<path d=\"M{F(x - 8 * k)} {F(y - 1 * k)} q{F(9 * k)} {F(8 * k)} {F(15 * k)} {F(-3.5 * k)}\" fill=\"none\" stroke=\"{ink}\" stroke-width=\"{sw}\" stroke-linecap=\"round\"/>",
            Emotions.Curious => open ? Oval(3.8, 3.8, 0.5) : Curve(5, 3, 0),
            Emotions.Thinking => open ? Oval(3, 2.8, 0.5) : $"<path d=\"M{F(x - 4 * k)} {F(y + 1 * k)} q{F(5 * k)} {F(-1.5 * k)} {F(10 * k)} {F(-1 * k)}\" fill=\"none\" stroke=\"{ink}\" stroke-width=\"{sw}\" stroke-linecap=\"round\"/>",
            Emotions.Surprised => open ? Oval(5.2, 6.4, 1) : Oval(3.6, 4.4, 1),
            Emotions.Concerned => open ? Oval(4.5, 3.2, 1.5) : $"<path d=\"M{F(x - 7 * k)} {F(y + 1.5 * k)} q{F(3.5 * k)} {F(-2.5 * k)} {F(7 * k)} 0 q{F(3.5 * k)} {F(2.5 * k)} {F(7 * k)} 0\" fill=\"none\" stroke=\"{ink}\" stroke-width=\"{sw}\" stroke-linecap=\"round\"/>",
            Emotions.Sad => open ? $"<path d=\"M{F(x - 6.5 * k)} {F(y + 3 * k)} q{F(6.5 * k)} {F(-8 * k)} {F(13 * k)} 0 Z\" fill=\"{ink}\"/>" : Frown(7, 6),
            Emotions.Frustrated => open
                ? $"<rect x=\"{F(x - 7.5 * k)}\" y=\"{F(y - 2 * k)}\" width=\"{F(15 * k)}\" height=\"{F(7 * k)}\" rx=\"{F(2.5 * k)}\" fill=\"{ink}\"/><path d=\"M{F(x - 6 * k)} {F(y)} h{F(12 * k)}\" stroke=\"#fff\" stroke-width=\"{F(2 * k)}\"/>"
                : Frown(7.5, 4.5),
            Emotions.Skeptical => open ? Oval(3.4, 2.6, 1) : $"<path d=\"M{F(x - 6 * k)} {F(y + 1.5 * k)} q{F(7 * k)} {F(1.5 * k)} {F(13 * k)} {F(-3.5 * k)}\" fill=\"none\" stroke=\"{ink}\" stroke-width=\"{sw}\" stroke-linecap=\"round\"/>",
            _ => open ? Oval(5, 4.2, 0.5) : Curve(6, 3, 0),
        };
    }

    /// <summary>Little signs of the emotion: a tear, a sweat drop, sparkles, a thought bubble, an anger mark, a question mark.</summary>
    private static string Extras(FaceAnchors a, string emotion) => emotion switch
    {
        Emotions.Sad => $"<path d=\"M{F(a.LeftX - 2)} {F(a.EyeY + 6 * a.EyeScale)} q-3 6 0 8.5 q3 -2.5 0 -8.5 Z\" fill=\"#6ec3ff\" opacity=\".9\"/>",
        Emotions.Concerned => "<path d=\"M92 34 q-5 8 0 11 q5 -3 0 -11 Z\" fill=\"#8fd3ff\" stroke=\"#4aa3d8\" stroke-width=\"1\"/>",
        Emotions.Excited => "<path d=\"M92 22 l2 5 5 2 -5 2 -2 5 -2 -5 -5 -2 5 -2 Z\" fill=\"#ffd166\"/><path d=\"M22 30 l1.4 3.6 3.6 1.4 -3.6 1.4 -1.4 3.6 -1.4 -3.6 -3.6 -1.4 3.6 -1.4 Z\" fill=\"#ffd166\"/>",
        Emotions.Thinking => "<circle cx=\"88\" cy=\"38\" r=\"2.2\" fill=\"#fff\" stroke=\"#9aa3b5\" stroke-width=\"1\"/><circle cx=\"92\" cy=\"31\" r=\"3\" fill=\"#fff\" stroke=\"#9aa3b5\" stroke-width=\"1\"/><ellipse cx=\"97\" cy=\"22\" rx=\"6.5\" ry=\"5\" fill=\"#fff\" stroke=\"#9aa3b5\" stroke-width=\"1\"/>",
        Emotions.Frustrated => "<g stroke=\"#e0435a\" stroke-width=\"2.4\" stroke-linecap=\"round\" fill=\"none\"><path d=\"M88 25 q3 3 0 6\"/><path d=\"M96 25 q-3 3 0 6\"/><path d=\"M89 24 q3 -3 6 0\"/><path d=\"M89 32 q3 3 6 0\"/></g>",
        Emotions.Curious => "<path d=\"M88 24 q0 -6 6 -6 q6 0 6 5 q0 4 -5 6 v3\" fill=\"none\" stroke=\"#4f7cff\" stroke-width=\"2.6\" stroke-linecap=\"round\"/><circle cx=\"95\" cy=\"37\" r=\"1.7\" fill=\"#4f7cff\"/>",
        _ => "",
    };

    // ---------- characters ----------

    private static readonly Dictionary<string, FaceAnchors> CharacterAnchors = new()
    {
        ["robot"] = new(50, 70, 54, 1.1, 60, 75, 0.9, EyeColor: "#5ef2ff", MouthColor: "#5ef2ff", BrowColor: "#5ef2ff", BrowOpacity: 0.9),
        ["cat"] = new(48, 72, 60, 1.15, 60, 78, 0.8, BrowOpacity: 0.7),
        ["dog"] = new(48, 72, 56, 1.05, 60, 79, 0.9, BrowOpacity: 0.7),
        ["bear"] = new(47, 73, 58, 1.05, 60, 80, 0.8, BrowOpacity: 0.7),
        ["panda"] = new(47, 73, 58, 0.85, 60, 80, 0.8, EyeColor: "#fff", BrowOpacity: 0.85),
        ["fox"] = new(47, 73, 56, 1.05, 60, 88, 0.65, BrowOpacity: 0.7),
        ["owl"] = new(46, 74, 55, 1.6, 60, 82, 0.6, BrowColor: "#5a3f2c"),
        ["alien"] = new(45, 75, 56, 2, 60, 81, 0.8, BrowColor: "#3a8f3a"),
        ["monster"] = new(50, 70, 51, 2, 60, 80, 1.5, SingleEye: true, BrowColor: "#5b3fb0"),
        ["penguin"] = new(50, 70, 54, 1, 60, 77, 0.6, BrowColor: "#26303f", Brows: false),
        ["frog"] = new(41, 81, 37, 1.2, 60, 70, 1.7, BrowColor: "#3d8a43"),
        ["lion"] = new(49, 71, 58, 1, 60, 80, 0.8, BrowColor: "#8a4b16"),
        ["rabbit"] = new(49, 71, 64, 1, 60, 82, 0.75, BrowOpacity: 0.6),
        ["koala"] = new(48, 72, 60, 1, 60, 84, 0.7, BrowOpacity: 0.7),
        ["tiger"] = new(48, 72, 58, 1.05, 60, 81, 0.8, BrowOpacity: 0.8),
        ["monkey"] = new(50, 70, 58, 1, 60, 82, 0.9, BrowColor: "#5a3a22"),
        ["mouse"] = new(50, 70, 64, 0.95, 60, 82, 0.6, BrowOpacity: 0.6),
        ["pig"] = new(48, 72, 56, 1, 60, 84, 0.8, BrowOpacity: 0.7),
        ["chick"] = new(50, 70, 56, 1, 60, 79, 0.6, Brows: false),
        ["unicorn"] = new(49, 71, 62, 1, 60, 82, 0.75, BrowColor: "#b76ad6"),
    };

    /// <summary>Parts the eyes/mouth groups took with them in the classic drawings (the robot's mouth panel, beaks), drawn under the face.</summary>
    private static readonly Dictionary<string, string> CharacterExtras = new()
    {
        ["robot"] = "<rect x=\"44\" y=\"69\" width=\"32\" height=\"12\" rx=\"4\" fill=\"#1f2d4d\"/>",
        ["owl"] = "<path d=\"M55 66 L65 66 L60 76 Z\" fill=\"#f2a93b\"/>",
        ["penguin"] = "<path d=\"M52 64 L68 64 L60 72 Z\" fill=\"#f2a93b\"/>",
        ["chick"] = "<path d=\"M54 66 L66 66 L60 73 Z\" fill=\"#f28c28\"/>",
    };

    /// <summary>Parts drawn over the face (the cat's whiskers).</summary>
    private static readonly Dictionary<string, string> CharacterTop = new();

    private static readonly (string Id, string Label, string Description, string Kind, string Bg)[] MoreCharacterEntries =
    [
        ("rabbit", "Rabbit", "rabbit, gentle, quick to react", "rabbit", "#e8f4ff"),
        ("koala", "Koala", "koala, sleepy, relaxed", "koala", "#e6f2e6"),
        ("tiger", "Tiger", "tiger, bold, energetic", "tiger", "#fff1d6"),
        ("monkey", "Monkey", "monkey, cheeky, curious", "monkey", "#fde8d0"),
        ("mouse", "Mouse", "little mouse, careful, detail-minded", "mouse", "#f1ecff"),
        ("pig", "Pig", "pig, cheerful, practical", "pig", "#fff0f5"),
        ("chick", "Chick", "chick, young, eager to learn", "chick", "#e3f6ff"),
        ("unicorn", "Unicorn", "unicorn, imaginative, optimistic", "unicorn", "#f6e8ff"),
    ];

    private static readonly Dictionary<string, string> MoreCharacters = new()
    {
        ["rabbit"] = "<circle cx=\"60\" cy=\"60\" r=\"60\" fill=\"{0}\"/><ellipse cx=\"45\" cy=\"26\" rx=\"9\" ry=\"24\" fill=\"#f1f1f4\"/><ellipse cx=\"75\" cy=\"26\" rx=\"9\" ry=\"24\" fill=\"#f1f1f4\"/><ellipse cx=\"45\" cy=\"28\" rx=\"4.5\" ry=\"17\" fill=\"#ffc9d6\"/><ellipse cx=\"75\" cy=\"28\" rx=\"4.5\" ry=\"17\" fill=\"#ffc9d6\"/><ellipse cx=\"60\" cy=\"70\" rx=\"32\" ry=\"30\" fill=\"#f1f1f4\"/><ellipse cx=\"60\" cy=\"80\" rx=\"12\" ry=\"9\" fill=\"#fff\"/><path d=\"M56 74 h8 l-4 4 Z\" fill=\"#ff8fab\"/><circle cx=\"42\" cy=\"76\" r=\"4.5\" fill=\"#ff7a8a\" opacity=\".3\"/><circle cx=\"78\" cy=\"76\" r=\"4.5\" fill=\"#ff7a8a\" opacity=\".3\"/><path d=\"M22 120 C26 102 42 98 60 98 C78 98 94 102 98 120 Z\" fill=\"#a3c9ff\"/>",
        ["koala"] = "<circle cx=\"60\" cy=\"60\" r=\"60\" fill=\"{0}\"/><circle cx=\"30\" cy=\"42\" r=\"16\" fill=\"#9aa0a8\"/><circle cx=\"90\" cy=\"42\" r=\"16\" fill=\"#9aa0a8\"/><circle cx=\"30\" cy=\"42\" r=\"9\" fill=\"#f1e7ee\"/><circle cx=\"90\" cy=\"42\" r=\"9\" fill=\"#f1e7ee\"/><ellipse cx=\"60\" cy=\"64\" rx=\"32\" ry=\"31\" fill=\"#aeb4bc\"/><ellipse cx=\"60\" cy=\"72\" rx=\"7.5\" ry=\"10\" fill=\"#3d3a40\"/><path d=\"M22 120 C26 100 42 96 60 96 C78 96 94 100 98 120 Z\" fill=\"#9aa0a8\"/>",
        ["tiger"] = "<circle cx=\"60\" cy=\"60\" r=\"60\" fill=\"{0}\"/><circle cx=\"34\" cy=\"32\" r=\"10\" fill=\"#f08a24\"/><circle cx=\"86\" cy=\"32\" r=\"10\" fill=\"#f08a24\"/><circle cx=\"34\" cy=\"32\" r=\"5\" fill=\"#fff3e0\"/><circle cx=\"86\" cy=\"32\" r=\"5\" fill=\"#fff3e0\"/><ellipse cx=\"60\" cy=\"62\" rx=\"34\" ry=\"32\" fill=\"#f08a24\"/><path d=\"M60 30 v10 M50 32 l2 8 M70 32 l-2 8 M27 58 h9 M27 66 h8 M93 58 h-9 M93 66 h-8\" stroke=\"#2b2233\" stroke-width=\"3\" stroke-linecap=\"round\"/><ellipse cx=\"60\" cy=\"78\" rx=\"17\" ry=\"12\" fill=\"#fff3e0\"/><path d=\"M55 71 h10 l-5 5 Z\" fill=\"#2b2233\"/>",
        ["monkey"] = "<circle cx=\"60\" cy=\"60\" r=\"60\" fill=\"{0}\"/><circle cx=\"26\" cy=\"62\" r=\"11\" fill=\"#8a5a3b\"/><circle cx=\"94\" cy=\"62\" r=\"11\" fill=\"#8a5a3b\"/><circle cx=\"26\" cy=\"62\" r=\"6\" fill=\"#e8c39e\"/><circle cx=\"94\" cy=\"62\" r=\"6\" fill=\"#e8c39e\"/><ellipse cx=\"60\" cy=\"60\" rx=\"32\" ry=\"33\" fill=\"#8a5a3b\"/><path d=\"M38 64 C38 46 50 44 60 50 C70 44 82 46 82 64 C82 86 70 94 60 94 C50 94 38 86 38 64 Z\" fill=\"#e8c39e\"/><circle cx=\"56\" cy=\"72\" r=\"1.6\" fill=\"#2b2233\"/><circle cx=\"64\" cy=\"72\" r=\"1.6\" fill=\"#2b2233\"/>",
        ["mouse"] = "<circle cx=\"60\" cy=\"60\" r=\"60\" fill=\"{0}\"/><circle cx=\"32\" cy=\"38\" r=\"18\" fill=\"#b9b4c7\"/><circle cx=\"88\" cy=\"38\" r=\"18\" fill=\"#b9b4c7\"/><circle cx=\"32\" cy=\"38\" r=\"11\" fill=\"#ffc9d6\"/><circle cx=\"88\" cy=\"38\" r=\"11\" fill=\"#ffc9d6\"/><ellipse cx=\"60\" cy=\"68\" rx=\"28\" ry=\"27\" fill=\"#c9c4d6\"/><circle cx=\"60\" cy=\"76\" r=\"3.4\" fill=\"#ff8fab\"/><path d=\"M36 76 h14 M36 82 l14 -3 M84 76 h-14 M84 82 l-14 -3\" stroke=\"#2b2233\" stroke-width=\"1.2\" opacity=\".45\"/>",
        ["pig"] = "<circle cx=\"60\" cy=\"60\" r=\"60\" fill=\"{0}\"/><path d=\"M30 40 L32 20 L48 32 Z M90 40 L88 20 L72 32 Z\" fill=\"#f4a7b9\"/><ellipse cx=\"60\" cy=\"62\" rx=\"34\" ry=\"31\" fill=\"#f8bfcc\"/><ellipse cx=\"60\" cy=\"72\" rx=\"12\" ry=\"8.5\" fill=\"#f4a7b9\" stroke=\"#e58aa0\" stroke-width=\"1.5\"/><ellipse cx=\"56\" cy=\"72\" rx=\"2\" ry=\"3\" fill=\"#c95f7c\"/><ellipse cx=\"64\" cy=\"72\" rx=\"2\" ry=\"3\" fill=\"#c95f7c\"/>",
        ["chick"] = "<circle cx=\"60\" cy=\"60\" r=\"60\" fill=\"{0}\"/><path d=\"M56 22 q4 -10 8 0 q4 -8 6 2\" fill=\"#ffd23f\"/><ellipse cx=\"60\" cy=\"66\" rx=\"32\" ry=\"33\" fill=\"#ffd23f\"/><ellipse cx=\"30\" cy=\"74\" rx=\"7\" ry=\"12\" transform=\"rotate(20 30 74)\" fill=\"#f5c400\"/><ellipse cx=\"90\" cy=\"74\" rx=\"7\" ry=\"12\" transform=\"rotate(-20 90 74)\" fill=\"#f5c400\"/><circle cx=\"44\" cy=\"68\" r=\"4.5\" fill=\"#ff7a8a\" opacity=\".3\"/><circle cx=\"76\" cy=\"68\" r=\"4.5\" fill=\"#ff7a8a\" opacity=\".3\"/>",
        ["unicorn"] = "<circle cx=\"60\" cy=\"60\" r=\"60\" fill=\"{0}\"/><path d=\"M54 32 L60 2 L66 32 Z\" fill=\"#ffd166\" stroke=\"#e0a83a\" stroke-width=\"1\"/><path d=\"M55 24 l10 -3 M56 16 l8 -2.5\" stroke=\"#e0a83a\" stroke-width=\"1.4\"/><path d=\"M34 40 L30 22 L46 32 Z M86 40 L90 22 L74 32 Z\" fill=\"#f7f3ff\"/><ellipse cx=\"60\" cy=\"66\" rx=\"31\" ry=\"31\" fill=\"#f7f3ff\"/><path d=\"M30 50 C36 30 52 28 60 34 C50 38 44 46 42 60 C38 56 34 54 30 50 Z\" fill=\"#ff9ad5\"/><path d=\"M34 58 C34 44 44 38 52 38 C46 44 44 52 44 62 Z\" fill=\"#9ad7ff\"/><ellipse cx=\"60\" cy=\"84\" rx=\"14\" ry=\"9\" fill=\"#ffe3f3\"/><circle cx=\"55\" cy=\"84\" r=\"1.6\" fill=\"#c48aa7\"/><circle cx=\"65\" cy=\"84\" r=\"1.6\" fill=\"#c48aa7\"/>",
    };

    // ---------- more people (deterministic, varied) ----------

    private static readonly string[] Names =
    [
        "Ada", "Ben", "Chloe", "Dev", "Elena", "Femi", "Grace", "Hiro", "Isla", "Jonah", "Kavya", "Liam", "Maya", "Noah", "Olu", "Paz",
        "Quinn", "Rosa", "Sami", "Tara", "Umar", "Vera", "Wes", "Ximena", "Yusuf", "Zara", "Arjun", "Bea", "Carlos", "Dina", "Emeka", "Fatima",
        "Gus", "Hana", "Ivan", "Jade", "Kofi", "Lena", "Mateo", "Nia", "Oscar", "Pia", "Rafael", "Sofia", "Theo", "Uma", "Victor", "Wren",
        "Yara", "Zeke", "Amara", "Bruno", "Celia", "Dario",
    ];

    private static readonly string[] Backgrounds = ["#ffe29a", "#9fd3f2", "#d9ccff", "#b8f2e6", "#ffd1dc", "#ffe0b3", "#f7e1c6", "#cde7d8", "#c7f0ff", "#ffcf70", "#e8d5ff", "#d0f4de", "#e0c3fc", "#d7f2ff", "#fff3b0", "#fde2e4", "#cfe1b9", "#bde0fe", "#e2e2ff", "#ffc8dd"];
    private static readonly string[] Shirts = ["#ff8f5a", "#1f2d4d", "#7a5c45", "#2b2233", "#a06cd5", "#e0435a", "#b56576", "#3d8b6d", "#3fa7d6", "#6b5bd6", "#2a9d8f", "#f4a261", "#4cc9f0", "#2ec4b6", "#588157", "#4f7cff", "#8e7dbe", "#ff8c42", "#9d8189", "#264653"];
    private static readonly string[] HairColors = ["#1f1a17", "#3b2a20", "#6b3e26", "#8a5a3b", "#c2512a", "#e0a84b", "#f2c14e", "#9aa0a6", "#e8e8e8", "#4b3b8f", "#2d1b12", "#7b3f00"];
    private static readonly string[] SkinKeys = ["light", "fair", "tan", "brown", "deep", "olive"];

    private static IEnumerable<Avatar> MorePeople(int count)
    {
        // A fixed recipe per index: the same 100 pictures on every machine.
        (string? Back, string? Front, string Hair)[] hairStyles =
        [
            ("long", "swept", "long hair"), (null, "short", "short hair"), ("bob", "bangs", "a bob"), (null, "spiky", "spiky hair"), ("ponytail", "swept", "a ponytail"),
            (null, "side", "side-parted hair"), ("afro", null, "an afro"), ("pigtails", "bangs", "pigtails"), (null, "receding", "a receding hairline"), (null, "mohawk", "a mohawk"),
            ("long", "bangs", "long hair with bangs"), (null, "swept", "swept hair"),
        ];
        (string? Hat, string Text)[] hats = [(null, ""), (null, ""), (null, ""), (null, ""), (null, ""), (null, ""), ("cap", "a cap"), ("beanie", "a beanie"), ("headphones", "headphones"), ("bow", "a bow"), ("flower", "a flower"), (null, "")];
        (string? Glasses, string Text)[] glasses = [(null, ""), (null, ""), (null, ""), (null, ""), ("round", "round glasses"), ("square", "square glasses"), ("round", "round glasses"), ("shades", "sunglasses")];
        (string? Beard, string Text)[] beards = [(null, ""), (null, ""), ("stubble", "stubble"), ("full", "a full beard"), ("mustache", "a mustache"), ("goatee", "a goatee")];
        // A well-mixed pick per face and feature (the same on every machine).
        static int Pick(int index, int salt, int count)
        {
            var z = (ulong)(index * 7919 + salt * 104729) + 0x9E3779B97F4A7C15UL;
            z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
            z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
            z ^= z >> 31;
            return (int)(z % (ulong)count);
        }
        string[] traits = ["thoughtful", "cheerful", "precise", "curious", "calm", "energetic", "witty", "patient", "bold", "kind", "pragmatic", "playful"];
        for (var i = 0; i < count; i++)
        {
            var name = Names[i % Names.Length];
            var hair = hairStyles[Pick(i, 1, hairStyles.Length)];
            var hat = hats[Pick(i, 2, hats.Length)];
            var glass = glasses[Pick(i, 3, glasses.Length)];
            // Beards go with short styles; long hair goes without.
            var beard = hair.Back is "long" or "bob" or "pigtails" or "ponytail" || hat.Hat is "bow" or "flower" ? (null, "") : beards[Pick(i, 4, beards.Length)];
            var hairColor = HairColors[Pick(i, 5, HairColors.Length)];
            var look = new HumanLook
            {
                Bg = Backgrounds[Pick(i, 6, Backgrounds.Length)],
                Skin = SkinKeys[Pick(i, 7, SkinKeys.Length)],
                Back = hair.Back,
                Front = hair.Front,
                HairColor = hairColor,
                BrowColor = hairColor is "#e8e8e8" or "#f2c14e" ? "#8d8d8d" : null,
                Hat = hat.Hat,
                HatColor = Shirts[Pick(i, 8, Shirts.Length)],
                Glasses = glass.Glasses,
                Beard = beard.Item1,
                Shirt = Shirts[Pick(i, 9, Shirts.Length)],
                Earrings = Pick(i, 10, 4) == 0 && beard.Item1 is null,
                Freckles = Pick(i, 11, 6) == 0,
                Curls = Pick(i, 12, 7) == 0 && hair.Back is null && hat.Hat is null,
                Bun = Pick(i, 13, 9) == 0 && hair.Back is null && hat.Hat is null,
            };
            var parts = new[] { hair.Hair, hat.Text, glass.Text, beard.Item2 }.Where(p => p.Length > 0);
            var description = $"{string.Join(", ", parts)}, {traits[Pick(i, 14, traits.Length)]}";
            yield return Person($"p-{name.ToLowerInvariant()}", name, description, look);
        }
    }
}
