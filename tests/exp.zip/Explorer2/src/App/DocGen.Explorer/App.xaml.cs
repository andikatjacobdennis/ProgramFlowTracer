using System.Windows;
using System.Windows.Threading;
using DocGen.Explorer.Engine;
using DocGen.Explorer.Engine.Storage;
using DocGen.Explorer.Infrastructure;
using DocGen.Explorer.Infrastructure.Docking;
using DocGen.Explorer.Modules;
using DocGen.Explorer.ViewModels;
using Prism.Ioc;
using Prism.Modularity;

namespace DocGen.Explorer;

/// <summary>
/// The explorer as a Prism application: the engine and the services are registered with the container, the panels
/// come from <see cref="PanelsModule"/>, and the shell (<see cref="MainWindow"/>) places them with its layout engine.
/// </summary>
public partial class App
{
    private ExplorerEngine? _engine;
    private string[] _args = [];

    protected override void OnStartup(StartupEventArgs e)
    {
        _args = e.Args;
        // The interface size (Ctrl+= / Ctrl+- / Ctrl+0): the window and the pop-ups take this one transform.
        Infrastructure.UiZoom.Apply(1.0);
        // A data folder can be given on the command line: DocGen.Explorer.exe --data "C:\path".
        var dataIndex = Array.FindIndex(e.Args, a => a is "--data" or "-d");
        var dataRoot = dataIndex >= 0 && dataIndex + 1 < e.Args.Length ? Path.GetFullPath(e.Args[dataIndex + 1]) : ExplorerStore.DefaultRoot();
        // A factory reset asked for in Settings runs now, before anything (the log included) opens a file in the folder.
        DataRemoval? reset = null;
        try
        {
            reset = DataMaintenance.RunPendingFactoryReset(dataRoot);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            MessageBox.Show($"The factory reset could not finish:\n\n{ex.Message}", "DocGen Explorer", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        Logging.Folder = Path.Combine(dataRoot, "logs");
        Logging.Info($"Starting DocGen Explorer; data folder {dataRoot}");
        Infrastructure.WheelScrolling.Register();
        // What other builds unpacked is deleted in the background (it is never read by this one).
        _ = Task.Run(Infrastructure.AppCaches.Tidy);
        if (reset is not null)
        {
            Logging.Info($"Factory reset: {reset.FilesDeleted} files deleted ({reset.BytesFreed:N0} bytes); {reset.FilesInUse} in use were left.");
            Ui.Post(() => Ui.Notify(reset.FilesInUse == 0
                ? "Factory reset done: the explorer starts afresh."
                : $"Factory reset done; {reset.FilesInUse} files were in use and were left."));
        }

        DispatcherUnhandledException += OnDispatcherUnhandledException;
        TaskScheduler.UnobservedTaskException += (_, args) =>
        {
            Logging.Error(args.Exception, "Unobserved task exception");
            args.SetObserved();
        };
        AppDomain.CurrentDomain.UnhandledException += (_, args) =>
        {
            if (args.ExceptionObject is Exception ex)
            {
                Logging.Error(ex, "Unhandled exception");
            }
        };

        try
        {
            _engine = new ExplorerEngine(dataRoot, new Infrastructure.LogFileLoggers());
            _engine.Models.ProvidersKey = BuiltInProvidersKey();
            Controls.MermaidRenderer.UserDataFolder = Path.Combine(_engine.Store.Root, "webview2");
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            MessageBox.Show($"The data folder '{dataRoot}' cannot be used:\n\n{ex.Message}", "DocGen Explorer", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown(1);
            return;
        }
        // Prism: the container, the modules and the shell (shown in OnInitialized, once the theme is set).
        base.OnStartup(e);
    }

    protected override void RegisterTypes(IContainerRegistry registry)
    {
        registry.RegisterInstance(_engine!);
        registry.RegisterSingleton<MainViewModel>();
        registry.RegisterSingleton<LayoutService>();
        registry.RegisterSingleton<MainWindow>();
    }

    protected override void ConfigureModuleCatalog(IModuleCatalog moduleCatalog) => moduleCatalog.AddModule<PanelsModule>();

    protected override Window CreateShell()
    {
        var window = Container.Resolve<MainWindow>();
        window.DataContext = Container.Resolve<MainViewModel>();
        return window;
    }

    protected override async void OnInitialized()
    {
        var engine = _engine!;
        var settings = await engine.Models.GetExplorerSettingsAsync();
        ThemeManager.Initialize(settings.Theme);
        StallMonitor.Start();
        var window = (MainWindow)MainWindow;
        var main = Container.Resolve<MainViewModel>();
        main.Events = Container.Resolve<Prism.Events.IEventAggregator>();
        base.OnInitialized(); // shows the window
        try
        {
            await main.StartAsync();
        }
        catch (Exception ex)
        {
            Ui.ReportError(ex);
        }
        await RunCommandLineAsync(window, main, _args);
    }

    /// <summary>The modes the command line can ask for: the UI path test, layout and guide pictures, captures.</summary>
    private async Task RunCommandLineAsync(MainWindow window, MainViewModel main, string[] args)
    {
        var uiTestIndex = Array.IndexOf(args, "--uitest");
        if (uiTestIndex >= 0 && uiTestIndex + 1 < args.Length)
        {
            var addArg = Array.IndexOf(args, "--add");
            var failures = await UiPathTester.RunAsync(window, main, Path.GetFullPath(args[uiTestIndex + 1]),
                addArg >= 0 && addArg + 1 < args.Length ? args[addArg + 1] : null);
            Shutdown(failures);
            return;
        }

        var layoutIndex = Array.IndexOf(args, "--layout");
        var layoutAdd = Array.IndexOf(args, "--add");
        if (layoutIndex >= 0 && layoutIndex + 1 < args.Length && layoutAdd >= 0 && layoutAdd + 1 < args.Length)
        {
            await GuideCapture.LayoutAsync(window, main, Path.GetFullPath(args[layoutIndex + 1]), args[layoutAdd + 1]);
            return;
        }

        var guideIndex = Array.IndexOf(args, "--guide");
        if (guideIndex >= 0 && guideIndex + 1 < args.Length)
        {
            var addArg = Array.IndexOf(args, "--add");
            var providersArg = Array.IndexOf(args, "--providers");
            await GuideCapture.RunAsync(window, main, Path.GetFullPath(args[guideIndex + 1]),
                addArg >= 0 && addArg + 1 < args.Length ? args[addArg + 1] : null,
                providersArg >= 0 && providersArg + 1 < args.Length ? args[providersArg + 1] : null);
            return;
        }

        var captureIndex = Array.IndexOf(args, "--capture");
        if (captureIndex >= 0 && captureIndex + 1 < args.Length)
        {
            var addIndex = Array.IndexOf(args, "--add");
            var themeIndex = Array.IndexOf(args, "--theme");
            await CaptureRunner.RunAsync(window, main, Path.GetFullPath(args[captureIndex + 1]),
                addIndex >= 0 && addIndex + 1 < args.Length ? args[addIndex + 1] : null,
                themeIndex >= 0 && themeIndex + 1 < args.Length ? args[themeIndex + 1] : null);
        }
    }

    /// <summary>The providers key built into this program (secrets\providers.key at build time), or null.</summary>
    private static byte[]? BuiltInProvidersKey()
    {
        using var stream = typeof(App).Assembly.GetManifestResourceStream("DocGen.ProvidersKey");
        if (stream is null)
        {
            Logging.Info("This build has no providers key: providers files cannot be imported.");
            return null;
        }
        using var reader = new StreamReader(stream);
        try
        {
            return Engine.Storage.EncryptedJson.ReadKey(reader.ReadToEnd());
        }
        catch (Engine.Repositories.ExplorerValidationException ex)
        {
            Logging.Info("The built-in providers key is not usable: " + ex.Message);
            return null;
        }
    }

    private static void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        // Report and keep running: one failed action must never take the whole explorer down.
        Ui.ReportError(e.Exception);
        e.Handled = true;
    }
}
