﻿using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Shell;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Infrastructure;
using DocGen.Explorer.Infrastructure.Docking;
using DocGen.Explorer.ViewModels;
using Prism.Events;
using Prism.Ioc;

namespace DocGen.Explorer;

public partial class MainWindow : Window
{
    private LayoutService? _layoutService;
    private IEventAggregator? _events;
    private bool _dockReady;

    public MainWindow()
    {
        InitializeComponent();
        // The name and version, once: in the header (which is the title bar) and for the taskbar.
        Title = AppInfo.Title;
        VersionText.Text = AppInfo.Version;
        // A microphone plugged in, or allowed, while the app was in the background: the microphone button follows.
        Activated += (_, _) => (DataContext as MainViewModel)?.RefreshMicrophone();
        PreviewKeyDown += OnFindKey;
        SourceInitialized += (_, _) =>
        {
            ThemeManager.ApplyTitleBar(this);
            // Windows 11's snap layouts: shown when Windows knows the pointer is on the maximise button.
            System.Windows.Interop.HwndSource.FromHwnd(new System.Windows.Interop.WindowInteropHelper(this).Handle)?.AddHook(SnapLayoutHook);
        };
        DataContextChanged += (_, e) =>
        {
            if (e.OldValue is INotifyPropertyChanged old)
            {
                old.PropertyChanged -= OnViewModelChanged;
            }
            if (e.OldValue is MainViewModel oldMain)
            {
                oldMain.Shortcuts.Changed -= ApplyShortcuts;
            }
            if (e.NewValue is INotifyPropertyChanged vm)
            {
                vm.PropertyChanged += OnViewModelChanged;
                RebuildDock();
            }
            if (e.NewValue is MainViewModel main)
            {
                main.Shortcuts.Changed += ApplyShortcuts;
                ApplyShortcuts();
            }
        };
        SizeChanged += (_, _) =>
        {
            UpdateWidthClasses();
            FitHeader();
        };
        PreviewMouseDown += (_, e) =>
        {
            if (DataContext is not MainViewModel vm)
            {
                return;
            }
            if (e.ChangedButton == MouseButton.XButton1 && vm.BackCommand.CanExecute(null))
            {
                vm.BackCommand.Execute(null);
                e.Handled = true;
            }
            else if (e.ChangedButton == MouseButton.XButton2 && vm.ForwardCommand.CanExecute(null))
            {
                vm.ForwardCommand.Execute(null);
                e.Handled = true;
            }
        };
        Closing += (_, _) =>
        {
            if (DataContext is MainViewModel vm)
            {
                vm.Speech.Dispose();
                Controls.MermaidRenderer.Shutdown(); // its off-screen window must not keep the app running
                // The layout as it is now, saved at once; floating panels close with the window.
                _events?.GetEvent<LayoutChangedEvent>().Publish(Dock.Layout);
                _layoutService?.SaveNow();
                Dock.CloseFloats();
            }
        };
        Loaded += async (_, _) =>
        {
            if (DataContext is MainViewModel vm)
            {
                await vm.Engine.Models.GetExplorerSettingsAsync();
                InitializeDock(vm);
            }
        };
    }

    /// <summary>Narrow and compact layouts by the room the content has: the window's width at the interface size.</summary>
    private void UpdateWidthClasses()
    {
        if (DataContext is MainViewModel vm)
        {
            var width = ActualWidth / UiZoom.Level;
            vm.IsNarrow = width < 1100;
            vm.IsCompact = width < 880;
        }
    }

    /// <summary>
    /// Ctrl+F anywhere: in Ask (or Talk) it searches the conversation; elsewhere it finds in the open page or file
    /// (with the selected word).
    /// </summary>
    private void OnFindKey(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.F || Keyboard.Modifiers != ModifierKeys.Control)
        {
            return;
        }
        for (var node = Keyboard.FocusedElement as DependencyObject; node is not null;
             node = node is System.Windows.Media.Visual or System.Windows.Media.Media3D.Visual3D ? System.Windows.Media.VisualTreeHelper.GetParent(node) : LogicalTreeHelper.GetParent(node))
        {
            if (node is Views.AssistantPane { DataContext: AssistantViewModel ask })
            {
                ask.IsSearchOpen = true;
                ask.FocusSearch = false;
                ask.FocusSearch = true;
                e.Handled = true;
                return;
            }
        }
        if (CaptureRunner.FindAll<Views.DocumentationView>(this).FirstOrDefault(v => v.IsVisible) is { } docs)
        {
            docs.OpenFind();
            e.Handled = true;
        }
    }

    // The key bindings made from Settings → Shortcuts (the size keys' number-pad forms are in the XAML).
    private readonly List<KeyBinding> _shortcutBindings = [];

    private void ApplyShortcuts()
    {
        if (DataContext is not MainViewModel main)
        {
            return;
        }
        foreach (var binding in _shortcutBindings)
        {
            InputBindings.Remove(binding);
        }
        _shortcutBindings.Clear();
        foreach (var (action, gesture) in main.Shortcuts.Bindings())
        {
            // The command is looked up when the keys are pressed: some (Refresh the index) belong to the open repository.
            var run = new RelayCommand(_ =>
            {
                if (action.Command(main) is { } command && command.CanExecute(action.Parameter))
                {
                    command.Execute(action.Parameter);
                }
            });
            var binding = new KeyBinding(run, gesture);
            _shortcutBindings.Add(binding);
            InputBindings.Add(binding);
        }
    }

    // ----- The window's own buttons (the header is the title bar) -----

    private void OnMinimizeWindow(object sender, RoutedEventArgs e) => SystemCommands.MinimizeWindow(this);

    // ----- Snap layouts on the maximise button (Windows 11) -----
    // Windows shows them only over what it is told is the maximise button (HTMAXBUTTON). The button is ours, so the
    // window answers "where is the pointer?" for it, clicks it itself, and shows its hover and pressed look by hand
    // (WPF does not see the pointer there any more).

    private const int WmNcHitTest = 0x0084, WmNcMouseMove = 0x00A0, WmNcLButtonDown = 0x00A1, WmNcLButtonUp = 0x00A2, WmNcMouseLeave = 0x02A2;
    private const int HtMaxButton = 9;
    private bool _maxPressed;

    /// <summary>What Windows is told is under a screen point (for checks).</summary>
    internal bool IsOnMaximizeButton(Point screen) => OverMaximize(screen);

    private bool OverMaximize(Point screen)
    {
        if (!MaximizeButton.IsVisible || MaximizeButton.ActualWidth <= 0)
        {
            return false;
        }
        var local = MaximizeButton.PointFromScreen(screen);
        return local.X >= 0 && local.Y >= 0 && local.X < MaximizeButton.ActualWidth && local.Y < MaximizeButton.ActualHeight;
    }

    private static Point ScreenPoint(IntPtr lParam)
    {
        var value = lParam.ToInt64();
        return new Point((short)(value & 0xFFFF), (short)((value >> 16) & 0xFFFF));
    }

    private void MaximizeLook(bool hover, bool pressed)
    {
        if (hover || pressed)
        {
            MaximizeButton.SetResourceReference(BackgroundProperty, pressed ? "Brush.Pressed" : "Brush.Hover");
        }
        else
        {
            MaximizeButton.ClearValue(BackgroundProperty);
        }
    }

    private IntPtr SnapLayoutHook(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        switch (msg)
        {
            case WmNcHitTest:
                if (OverMaximize(ScreenPoint(lParam)))
                {
                    MaximizeLook(hover: true, pressed: _maxPressed);
                    handled = true;
                    return new IntPtr(HtMaxButton);
                }
                MaximizeLook(hover: false, pressed: false);
                _maxPressed = false;
                break;
            case WmNcLButtonDown when wParam.ToInt32() == HtMaxButton:
                _maxPressed = true;
                MaximizeLook(hover: true, pressed: true);
                handled = true;
                return IntPtr.Zero;
            case WmNcLButtonUp when wParam.ToInt32() == HtMaxButton:
                var click = _maxPressed;
                _maxPressed = false;
                MaximizeLook(hover: true, pressed: false);
                if (click)
                {
                    OnMaximizeWindow(MaximizeButton, new RoutedEventArgs());
                }
                handled = true;
                return IntPtr.Zero;
            case WmNcMouseMove when wParam.ToInt32() != HtMaxButton:
            case WmNcMouseLeave:
                _maxPressed = false;
                MaximizeLook(hover: false, pressed: false);
                break;
        }
        return IntPtr.Zero;
    }

    private void OnMaximizeWindow(object sender, RoutedEventArgs e)
    {
        if (WindowState == WindowState.Maximized)
        {
            SystemCommands.RestoreWindow(this);
        }
        else
        {
            SystemCommands.MaximizeWindow(this);
        }
    }

    private void OnCloseWindow(object sender, RoutedEventArgs e) => SystemCommands.CloseWindow(this);

    /// <summary>
    /// Maximised, a window that draws its own title bar reaches past the screen's edges by the width of its resize
    /// border: the content is inset by that much. The maximise button becomes restore.
    /// </summary>
    private void OnWindowStateChanged(object? sender, EventArgs e)
    {
        var maximized = WindowState == WindowState.Maximized;
        var border = SystemParameters.WindowResizeBorderThickness;
        RootGrid.Margin = maximized ? new Thickness(border.Left + 1, border.Top + 1, border.Right + 1, border.Bottom + 1) : new Thickness(0);
        MaximizeButton.Content = maximized ? Icons.WindowRestore : Icons.WindowMaximize;
        MaximizeButton.ToolTip = maximized ? "Restore" : "Maximise";
        System.Windows.Automation.AutomationProperties.SetName(MaximizeButton, maximized ? "Restore" : "Maximise");
    }

    /// <summary>Shrinks the search box, then folds the sections behind the menu button when they still do not fit.</summary>
    private void FitHeader()
    {
        if (DataContext is not MainViewModel vm || !IsLoaded)
        {
            return;
        }
        SearchBox.Width = ActualWidth > 1700 ? 300 : ActualWidth > 1500 ? 240 : 176;
        vm.NavCollapsed = false;
        Sections.UpdateLayout();
        var infinite = new Size(double.PositiveInfinity, double.PositiveInfinity);
        Sections.Measure(infinite);
        HeaderLeft.Measure(infinite);
        var needed = HeaderLeft.DesiredSize.Width + Sections.DesiredSize.Width + (vm.ShowAssistantButton ? 2 : 1) * 42 + 40;
        vm.NavCollapsed = needed > ActualWidth;
    }

    private void OnViewModelChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName is nameof(MainViewModel.Workspace) or nameof(MainViewModel.Section) or nameof(MainViewModel.RepositoryTitle))
        {
            Dispatcher.BeginInvoke(FitHeader, System.Windows.Threading.DispatcherPriority.Loaded);
        }
        if (e.PropertyName is nameof(MainViewModel.PaneOrder) && _dockReady && DataContext is MainViewModel ordered)
        {
            // A pane order chosen in Settings: the standard layout in that order.
            Dock.Apply(l => l.Reset(ordered.PaneOrder));
        }
        if (e.PropertyName is nameof(MainViewModel.Zoom))
        {
            // The title bar's drag area grows with the header; what fits in the header changes with the size.
            if (WindowChrome.GetWindowChrome(this) is { IsFrozen: false } chrome)
            {
                chrome.CaptionHeight = 47 * UiZoom.Level;
            }
            Dispatcher.BeginInvoke(FitHeader, System.Windows.Threading.DispatcherPriority.Loaded);
            UpdateWidthClasses();
        }
        if (e.PropertyName is nameof(MainViewModel.ShowTreePane) or nameof(MainViewModel.ShowAssistantPane) or nameof(MainViewModel.ShowContentPane)
            or nameof(MainViewModel.Section) or nameof(MainViewModel.Workspace) or nameof(MainViewModel.ShowPanes) or nameof(MainViewModel.AssistantExpanded))
        {
            RebuildDock();
        }
    }

    // ----- The window layout (the panels placed by the layout engine; Prism events carry its changes) -----

    /// <summary>Starts the layout engine: the saved layout (or the standard one in the chosen pane order) and its panels.</summary>
    private void InitializeDock(MainViewModel vm)
    {
        if (_dockReady)
        {
            return;
        }
        var container = Prism.Ioc.ContainerLocator.Container;
        _events = container.Resolve<IEventAggregator>();
        _layoutService = container.Resolve<LayoutService>();
        Dock.Initialize(container.Resolve<IDockContentProvider>(), _layoutService.Load(vm.PaneOrder));
        Dock.LayoutChanged += (_, _) =>
        {
            _events.GetEvent<LayoutChangedEvent>().Publish(Dock.Layout);
            Dispatcher.BeginInvoke(FramePanels, System.Windows.Threading.DispatcherPriority.Loaded);
        };
        _events.GetEvent<LayoutCommandEvent>().Subscribe(OnLayoutCommand, ThreadOption.UIThread);
        // Tab strips dragged into another order (the header's sections, Docs · Files · Changes) are kept in the layout.
        TabReorder.Store = new LayoutTabOrders(Dock);
        TabReorder.RestoreAll();
        _dockReady = true;
        FramePanels();
    }

    /// <summary>The layout commands of the menus: reset (in a pane order), lock, show, float or dock a panel.</summary>
    private void OnLayoutCommand(string command)
    {
        var (verb, arg) = command.IndexOf(':') is var i and >= 0 ? (command[..i], command[(i + 1)..]) : (command, "");
        switch (verb)
        {
            case "reset":
                Dock.Apply(l => l.Reset(arg.Length > 0 ? arg : null));
                TabReorder.RestoreAll();
                break;
            case "toggle-lock":
                Dock.Apply(l => l.Locked = !l.Locked);
                Ui.Notify(Dock.Layout.Locked ? "The window layout is locked: panels cannot be dragged." : "The window layout is unlocked.");
                break;
            case "float" when arg.Length > 0:
                Dock.Apply(l => l.Dock(arg, DockPosition.Float));
                break;
            case "left" or "right" or "top" or "bottom" or "tab" when arg.Length > 0:
                Dock.Apply(l => l.Dock(arg, Enum.Parse<DockPosition>(verb, ignoreCase: true)));
                break;
            case "show" when arg.Length > 0:
                Dock.Apply(l => l.Show(arg));
                break;
        }
    }

    /// <summary>Draws the panels again (one became available or not: the files list, the assistant, the page).</summary>
    private void RebuildDock()
    {
        if (!_dockReady)
        {
            return;
        }
        Dock.Rebuild();
        FramePanels();
    }

    /// <summary>
    /// Each panel's frame by where it is. The files list has its border on the side facing the page. The assistant
    /// beside the page is a card (white, rounded, a thin border and a little room around it) so it reads apart from
    /// the content; full width, tabbed with the page or floating, it is flat.
    /// </summary>
    private void FramePanels()
    {
        if (DataContext is not MainViewModel vm || !_dockReady)
        {
            return;
        }
        var layout = Dock.Layout;
        if (Dock.ViewOf(DockLayout.Files) is Views.TreePane { Content: Border treeBorder })
        {
            var side = layout.IsFloating(DockLayout.Files) ? 0 : layout.SideOfViewport(DockLayout.Files);
            treeBorder.BorderThickness = side < 0 ? new Thickness(0, 0, 1, 0) : side > 0 ? new Thickness(1, 0, 0, 0) : new Thickness(0);
        }
        if (Dock.ViewOf(DockLayout.Ask) is not Views.AssistantPane { Content: Border askBorder })
        {
            return;
        }
        if (!_askClipped)
        {
            // A rounded border does not clip what is inside it: the content is clipped to the card's corners.
            _askClipped = true;
            askBorder.SizeChanged += (_, _) => ClipAsk(askBorder);
        }
        var askSide = layout.IsFloating(DockLayout.Ask) ? 0 : layout.SideOfViewport(DockLayout.Ask);
        if (vm.AssistantExpanded || askSide == 0)
        {
            askBorder.Margin = new Thickness(0);
            askBorder.BorderThickness = new Thickness(0);
            askBorder.CornerRadius = new CornerRadius(0);
            askBorder.SetResourceReference(Border.BackgroundProperty, "Brush.Window");
            ClipAsk(askBorder);
            return;
        }
        askBorder.Margin = askSide < 0 ? new Thickness(10, 10, 4, 10) : new Thickness(4, 10, 10, 10);
        askBorder.BorderThickness = new Thickness(1);
        askBorder.CornerRadius = new CornerRadius(12);
        askBorder.SetResourceReference(Border.BackgroundProperty, "Brush.Surface");
        askBorder.SetResourceReference(Border.BorderBrushProperty, "Brush.Border");
        ClipAsk(askBorder);
    }

    /// <summary>Tab strip orders, kept in the window layout (saved with it, cleared by Reset window layout).</summary>
    private sealed class LayoutTabOrders(DockHost dock) : ITabOrderStore
    {
        public IReadOnlyList<string>? Load(string key) => dock.Layout.TabOrders.TryGetValue(key, out var order) ? order : null;

        public void Save(string key, IReadOnlyList<string> order) => dock.Touch(l => l.TabOrders[key] = [.. order]);
    }

    private bool _askClipped;

    private static void ClipAsk(Border border)
    {
        var radius = border.CornerRadius.TopLeft;
        border.Clip = radius <= 0 || border.ActualWidth <= 0 ? null
            : new System.Windows.Media.RectangleGeometry(new Rect(0, 0, border.ActualWidth, border.ActualHeight), radius, radius);
    }

    private void OnSearchKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Down && SearchList.Items.Count > 0)
        {
            if (DataContext is MainViewModel vm)
            {
                vm.IsSearchOpen = true;
            }
            SearchList.SelectedIndex = 0;
            (SearchList.ItemContainerGenerator.ContainerFromIndex(0) as ListBoxItem)?.Focus();
            e.Handled = true;
        }
    }

    private void OnSearchListKeyDown(object sender, KeyEventArgs e)
    {
        if (DataContext is not MainViewModel vm)
        {
            return;
        }
        if (e.Key == Key.Enter && SearchList.SelectedItem is SearchHit hit)
        {
            vm.OpenSearchResultCommand.Execute(hit);
            e.Handled = true;
        }
        else if (e.Key == Key.Escape)
        {
            vm.IsSearchOpen = false;
            SearchBox.Focus();
            e.Handled = true;
        }
    }

    private void OnSearchListClick(object sender, MouseButtonEventArgs e)
    {
        if (DataContext is MainViewModel vm && (e.OriginalSource as FrameworkElement)?.DataContext is SearchHit hit)
        {
            vm.OpenSearchResultCommand.Execute(hit);
        }
    }
}
