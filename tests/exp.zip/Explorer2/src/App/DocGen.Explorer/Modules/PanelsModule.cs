using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using DocGen.Explorer.Infrastructure.Docking;
using DocGen.Explorer.ViewModels;
using DocGen.Explorer.Views;
using Prism.Ioc;
using Prism.Modularity;

namespace DocGen.Explorer.Modules;

/// <summary>The page in the middle of the window: whichever section is open (Documentation, Graph, Learning…).</summary>
public sealed class PagePanel : ContentControl
{
    public PagePanel()
    {
        Focusable = false;
        SetBinding(ContentProperty, new Binding(nameof(MainViewModel.CurrentPage)));
        System.Windows.Automation.AutomationProperties.SetName(this, "Page");
    }
}

/// <summary>
/// The window's panels, registered with the container by their layout id (as named <see cref="FrameworkElement"/>
/// registrations), so the dock host can place any of them anywhere.
/// </summary>
public sealed class PanelsModule : IModule
{
    public void RegisterTypes(IContainerRegistry registry)
    {
        registry.RegisterPanel<TreePane>(DockLayout.Files);
        registry.RegisterPanel<PagePanel>(DockLayout.Viewport);
        registry.RegisterPanel<AssistantPane>(DockLayout.Ask);
        registry.RegisterSingleton<IDockContentProvider, DockContentProvider>();
    }

    public void OnInitialized(IContainerProvider container)
    {
    }
}

public static class PanelRegistration
{
    public static void RegisterPanel<TView>(this IContainerRegistry registry, string panel) where TView : FrameworkElement
        => registry.Register(typeof(FrameworkElement), typeof(TView), panel);
}

/// <summary>Gives the dock host each panel's view (bound to its part of the main view model), title, icon and availability.</summary>
public sealed class DockContentProvider(IContainerExtension container, MainViewModel main) : IDockContentProvider
{
    public FrameworkElement ViewFor(string panel)
    {
        var view = container.IsRegistered(typeof(FrameworkElement), panel)
            ? (FrameworkElement)container.Resolve(typeof(FrameworkElement), panel)
            : new TextBlock { Text = $"No panel named {panel}", Margin = new Thickness(16) };
        // Each panel shows its part of the main view model; the page binds to the main view model itself.
        var path = panel switch
        {
            DockLayout.Files => "Workspace.Tree",
            DockLayout.Ask => "Workspace.Assistant",
            _ => null,
        };
        if (path is null)
        {
            view.DataContext = main;
        }
        else
        {
            view.SetBinding(FrameworkElement.DataContextProperty, new Binding(path) { Source = main });
        }
        return view;
    }

    public string TitleFor(string panel) => panel switch
    {
        DockLayout.Files => "Repository",
        DockLayout.Ask => "Assistant",
        _ => main.SectionName is { Length: > 0 } name ? name : "Page",
    };

    public string IconFor(string panel) => panel switch
    {
        DockLayout.Files => "",
        DockLayout.Ask => "",
        _ => "",
    };

    public bool IsAvailable(string panel) => panel switch
    {
        DockLayout.Files => main.ShowTreePane,
        DockLayout.Ask => main.ShowAssistantPane,
        _ => main.ShowContentPane,
    };

    public string BackgroundFor(string panel) => panel == DockLayout.Files ? "Brush.Sidebar" : "Brush.Window";

    public bool Close(string panel)
    {
        switch (panel)
        {
            case DockLayout.Files:
                main.TreeVisible = false;
                return true;
            case DockLayout.Ask:
                main.AssistantVisible = false;
                return true;
            default:
                return false;
        }
    }
}
