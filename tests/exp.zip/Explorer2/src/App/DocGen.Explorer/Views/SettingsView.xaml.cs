using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Views;

public partial class SettingsView : UserControl
{
    public SettingsView()
    {
        InitializeComponent();
        // A new page starts at its top, as a new GitHub settings page does.
        DataContextChanged += (_, e) =>
        {
            if (e.OldValue is INotifyPropertyChanged old)
            {
                old.PropertyChanged -= OnViewModelChanged;
            }
            if (e.NewValue is INotifyPropertyChanged now)
            {
                now.PropertyChanged += OnViewModelChanged;
            }
        };
    }

    private void OnViewModelChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(SettingsViewModel.Page))
        {
            PageScroller.ScrollToTop();
        }
    }

    /// <summary>Settings → Shortcuts: while a shortcut is listening, the next keys pressed become its keys (and do nothing else).</summary>
    private void OnShortcutKeyDown(object sender, KeyEventArgs e)
    {
        if (sender is FrameworkElement { DataContext: ShortcutsViewModel shortcuts } && shortcuts.Items.FirstOrDefault(i => i.IsRecording) is { } item)
        {
            // Alt combinations arrive as Key.System.
            e.Handled = item.HandleKey(e.Key == Key.System ? e.SystemKey : e.Key, Keyboard.Modifiers);
        }
    }
}
