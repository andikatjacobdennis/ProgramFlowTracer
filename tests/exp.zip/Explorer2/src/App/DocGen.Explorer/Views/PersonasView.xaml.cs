using System.Windows.Controls;

namespace DocGen.Explorer.Views;

public partial class PersonasView : UserControl
{
    public PersonasView() => InitializeComponent();
}
