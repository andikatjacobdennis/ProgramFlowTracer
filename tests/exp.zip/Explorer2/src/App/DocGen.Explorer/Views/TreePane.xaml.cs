using System.Windows.Controls;
using System.Windows.Input;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Views;

public partial class TreePane : UserControl
{
    public TreePane() => InitializeComponent();

    // ----- The Changes tree, as Visual Studio's Git Changes: selecting a file opens its diff -----

    private void OnChangeSelected(object sender, System.Windows.RoutedPropertyChangedEventArgs<object> e)
    {
        if (e.NewValue is ChangeTreeNode { IsFile: true, Row: { } row })
        {
            row.OpenCommand.Execute(null);
        }
    }

    /// <summary>A click on the file already selected opens its diff again (after reading something else).</summary>
    private void OnChangeClicked(object sender, MouseButtonEventArgs e)
    {
        if (sender is TreeView { SelectedItem: ChangeTreeNode { IsFile: true, Row: { } row } } tree
            && e.OriginalSource is System.Windows.DependencyObject source
            && ItemsControl.ContainerFromElement(tree, source) is not null
            && FindItem(source) is { DataContext: ChangeTreeNode { Row: { } clicked } } && ReferenceEquals(clicked, row)
            && OpenDiffPath() != row.Change.Path)
        {
            row.OpenCommand.Execute(null);
        }
    }

    private void OnChangeKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter && sender is TreeView { SelectedItem: ChangeTreeNode { IsFile: true, Row: { } row } })
        {
            row.OpenCommand.Execute(null);
            e.Handled = true;
        }
    }

    private static TreeViewItem? FindItem(System.Windows.DependencyObject? d)
    {
        while (d is not null and not TreeViewItem)
        {
            d = d is System.Windows.Media.Visual or System.Windows.Media.Media3D.Visual3D ? System.Windows.Media.VisualTreeHelper.GetParent(d) : System.Windows.LogicalTreeHelper.GetParent(d);
        }
        return d as TreeViewItem;
    }

    /// <summary>The path of the change whose diff is open, if one is.</summary>
    private string? OpenDiffPath() => DataContext is RepositoryTreeViewModel tree && tree.DiffOpenPath is { } path ? path : null;

    /// <summary>F2 renames the selected file or folder, Delete deletes it (to the Recycle Bin, after asking).</summary>
    private void OnTreeKeyDown(object sender, KeyEventArgs e)
    {
        if (Tree.SelectedItem is not TreeNodeViewModel node || e.OriginalSource is TextBox)
        {
            return;
        }
        var command = e.Key switch
        {
            Key.F2 => node.RenameCommand,
            Key.Delete => node.DeleteCommand,
            _ => null,
        };
        if (command?.CanExecute(null) == true)
        {
            command.Execute(null);
            e.Handled = true;
        }
    }
}
