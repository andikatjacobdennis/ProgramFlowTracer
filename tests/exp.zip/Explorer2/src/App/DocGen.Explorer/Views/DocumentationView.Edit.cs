using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using DocGen.Explorer.Controls;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Views;

/// <summary>The editor (Edit / Preview), the class diagram of a C# file and the preview of a Markdown file.</summary>
public partial class DocumentationView
{
    private void HookEditing(DocumentationViewModel vm, bool on)
    {
        if (on)
        {
            vm.EditorChanged += OnEditorChanged;
            vm.ClassDiagramChanged += OnClassDiagramChanged;
            vm.DiffChanged += OnDiffChanged;
            vm.DiffEditChanged += OnDiffEditChanged;
        }
        else
        {
            vm.EditorChanged -= OnEditorChanged;
            vm.ClassDiagramChanged -= OnClassDiagramChanged;
            vm.DiffChanged -= OnDiffChanged;
            vm.DiffEditChanged -= OnDiffEditChanged;
        }
    }

    // ----- A Git change's diff: code views, the two sides scrolling together -----

    private bool _diffScrollHooked;
    private bool _syncingScroll;

    private void OnDiffChanged(object? sender, EventArgs e)
    {
        if (_vm is null || _vm.Mode != "diff" || _vm.IsDiffEditing)
        {
            return;
        }
        var language = _vm.DiffLanguage;
        if (_vm.SideBySide)
        {
            DiffLeft.LoadDiff(_vm.DiffOldSide, language);
            DiffRight.LoadDiff(_vm.DiffNewSide, language);
            Dispatcher.BeginInvoke(HookDiffScroll, DispatcherPriority.Loaded);
        }
        else
        {
            DiffInline.LoadDiff(_vm.DiffInlineLines, language);
        }
    }

    /// <summary>Side by side, one side's scrolling moves the other (their rows line up: a filler stands for a missing line).</summary>
    private void HookDiffScroll()
    {
        if (_diffScrollHooked || DiffLeft.Scroller is not { } left || DiffRight.Scroller is not { } right)
        {
            return;
        }
        _diffScrollHooked = true;
        void Follow(ScrollViewer from, ScrollViewer to, ScrollChangedEventArgs e)
        {
            if (_syncingScroll || (e.VerticalChange == 0 && e.HorizontalChange == 0))
            {
                return;
            }
            _syncingScroll = true;
            to.ScrollToVerticalOffset(from.VerticalOffset);
            to.ScrollToHorizontalOffset(from.HorizontalOffset);
            _syncingScroll = false;
        }
        left.ScrollChanged += (_, e) => Follow(left, right, e);
        right.ScrollChanged += (_, e) => Follow(right, left, e);
    }

    // ----- Editing in the diff: the original on the left follows the working copy being edited on the right -----

    private bool _diffEditHooked;
    private DateTime _diffEditScrolledLeft;
    private DateTime _diffEditScrolledRight;
    private bool _wasDiffEditing;

    private void OnDiffEditChanged(object? sender, EventArgs e)
    {
        if (_vm is null)
        {
            return;
        }
        if (!_vm.IsDiffEditing)
        {
            _wasDiffEditing = false;
            return;
        }
        DiffLeft.LoadDiff(_vm.DiffEditOldSide, _vm.DiffLanguage);
        DiffEditMarks.Editor = DiffEditor;
        DiffEditMarks.Marks = _vm.DiffEditMarks;
        if (!_diffEditHooked)
        {
            _diffEditHooked = true;
            DiffEditor.AddHandler(ScrollViewer.ScrollChangedEvent, new ScrollChangedEventHandler(OnDiffEditorScrolled));
        }
        Dispatcher.BeginInvoke(() =>
        {
            if (DiffLeft.Scroller is { } left)
            {
                left.ScrollChanged -= OnDiffOriginalScrolled;
                left.ScrollChanged += OnDiffOriginalScrolled;
                // The editor's lines as tall as the original's rows, so the two sides stay level line for line.
                var count = _vm.DiffEditOldSide.Count;
                if (count > 0 && left.ExtentHeight > 0)
                {
                    TextBlock.SetLineStackingStrategy(DiffEditor, LineStackingStrategy.BlockLineHeight);
                    TextBlock.SetLineHeight(DiffEditor, left.ExtentHeight / count);
                    DiffEditMarks.InvalidateVisual();
                }
            }
            if (!_wasDiffEditing)
            {
                // Just started: the caret at the first change, the original level with it.
                _wasDiffEditing = true;
                var firstAdded = _vm.DiffEditMarks.ToList().IndexOf("Added");
                var line = Math.Max(0, firstAdded);
                if (line < DiffEditor.LineCount)
                {
                    DiffEditor.CaretIndex = DiffEditor.GetCharacterIndexFromLineIndex(line);
                    DiffEditor.ScrollToVerticalOffset(Math.Max(0, line - 3) * EditorLineHeight());
                }
                DiffEditor.Focus();
            }
            FollowEditor();
        }, DispatcherPriority.Loaded);
    }

    private double EditorLineHeight() => DiffEditMarks.LineHeightOf(DiffEditor);

    private void OnDiffEditorScrolled(object sender, ScrollChangedEventArgs e)
    {
        if (e.VerticalChange != 0 && DateTime.UtcNow - _diffEditScrolledRight > TimeSpan.FromMilliseconds(150))
        {
            FollowEditor();
        }
    }

    /// <summary>Scrolls the original so the line beside the editor's top line is at its top.</summary>
    private void FollowEditor()
    {
        if (_vm is not { IsDiffEditing: true } vm || DiffLeft.Scroller is not { } left || DiffEditor.GetFirstVisibleLineIndex() is var first && first < 0)
        {
            return;
        }
        var count = vm.DiffEditOldSide.Count;
        var rowHeight = count == 0 ? 0 : left.ExtentHeight / count;
        _diffEditScrolledLeft = DateTime.UtcNow;
        left.ScrollToVerticalOffset(Math.Max(0, vm.OldLineFor(first)) * rowHeight);
    }

    private void OnDiffOriginalScrolled(object? sender, ScrollChangedEventArgs e)
    {
        if (_vm is not { IsDiffEditing: true } vm || sender is not ScrollViewer left || e.VerticalChange == 0
            || DateTime.UtcNow - _diffEditScrolledLeft < TimeSpan.FromMilliseconds(150))
        {
            return;
        }
        var count = vm.DiffEditOldSide.Count;
        if (count == 0 || left.ExtentHeight <= 0)
        {
            return;
        }
        var oldLine = (int)Math.Round(left.VerticalOffset / (left.ExtentHeight / count));
        _diffEditScrolledRight = DateTime.UtcNow;
        DiffEditor.ScrollToVerticalOffset(vm.NewLineFor(oldLine) * EditorLineHeight());
    }

    private void OnEditorChanged(object? sender, EventArgs e)
    {
        if (_vm is null || _vm.Mode != "edit")
        {
            return;
        }
        if (_vm.IsPreviewTab)
        {
            if (_vm.IsMarkdownEdit)
            {
                var rendered = MarkdownRenderer.Render(_vm.EditorText, new MarkdownRenderOptions { OnLink = url => _vm.Workspace.OpenLink(url) });
                EditPreview.Document = rendered.Document;
            }
            else
            {
                EditPreviewCode.Load(Engine.Text.TextUtil.SplitLines(_vm.EditorText), _vm.EditLanguage, 0);
            }
            return;
        }
        Dispatcher.BeginInvoke(() =>
        {
            Editor.Focus();
            UpdateCaret();
        }, DispatcherPriority.Loaded);
    }

    private void OnEditorCaretMoved(object sender, RoutedEventArgs e) => UpdateCaret();

    /// <summary>"Ln 12, Col 4" under the editor (and the selection's length).</summary>
    private void UpdateCaret()
    {
        var index = Editor.CaretIndex;
        var line = Editor.GetLineIndexFromCharacterIndex(index);
        var column = line < 0 ? 0 : index - Editor.GetCharacterIndexFromLineIndex(line);
        EditorCaret.Text = $"Ln {line + 1}, Col {column + 1}" + (Editor.SelectionLength > 0 ? $" ({Editor.SelectionLength} selected)" : "") + " · Ctrl+S saves";
    }

    private void OnClassDiagramChanged(object? sender, EventArgs e)
    {
        if (_vm?.RenderedMarkdown is { } markdown)
        {
            ClassDiagramViewer.Document = MarkdownRenderer.Render(markdown, new MarkdownRenderOptions { OnLink = url => _vm.Workspace.OpenLink(url) }).Document;
        }
        else
        {
            ClassDiagramViewer.Document = null;
        }
    }

    private void OnOpenFind(object sender, RoutedEventArgs e) => OpenFind(SelectedWord());
}
