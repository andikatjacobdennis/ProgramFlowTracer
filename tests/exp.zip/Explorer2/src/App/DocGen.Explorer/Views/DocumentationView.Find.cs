using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using DocGen.Explorer.Controls;
using DocGen.Explorer.Engine.Text;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.Views;

/// <summary>One line of Find all: where the match is, and the text around it.</summary>
public sealed record FindResult(int Index, string Location, string Before, string Match, string After);

/// <summary>
/// Find in the open page or file, as in Visual Studio: Ctrl+F opens the bar (with the selected word), every match is
/// marked in yellow and the current one in orange, Enter / F3 go to the next and Shift+Enter / Shift+F3 to the previous,
/// and Find all lists every match with its place. A page's code blocks are searched too.
/// </summary>
public partial class DocumentationView
{
    // A page: each match with the text that holds it (the page itself, or one of its code blocks).
    private List<(FrameworkElement Host, TextRange Range)> _pageMatches = [];
    private int _findIndex = -1;
    private DispatcherTimer? _findTimer;
    private bool _findWired;

    private void WireFind()
    {
        if (_findWired)
        {
            return;
        }
        _findWired = true;
        CommandBindings.Add(new CommandBinding(FindCommands.Open, (_, _) => OpenFind(SelectedWord())));
        CommandBindings.Add(new CommandBinding(FindCommands.Next, (_, _) => Step(+1), (_, e) => e.CanExecute = FindBar.Visibility == Visibility.Visible));
        CommandBindings.Add(new CommandBinding(FindCommands.Previous, (_, _) => Step(-1), (_, e) => e.CanExecute = FindBar.Visibility == Visibility.Visible));
        Code.FindRequested += (_, text) => OpenFind(text);
        _findTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(160) };
        _findTimer.Tick += (_, _) =>
        {
            _findTimer.Stop();
            RunFind(keepPlace: false);
        };
    }

    private FindOptions Options => new(FindCase.IsChecked == true, FindWord.IsChecked == true, FindRegex.IsChecked == true);

    private bool IsFile => _vm?.Mode == "file";

    /// <summary>The selected text, when it is one line (what Find starts with).</summary>
    private string SelectedWord()
    {
        var text = IsFile ? Code.SelectedText : Viewer.Selection?.Text ?? "";
        text = text.Trim();
        return text.Contains('\n') || text.Length > 120 ? "" : text;
    }

    public void OpenFind(string? text = null)
    {
        if (_vm?.Mode is not ("page" or "file"))
        {
            return;
        }
        text ??= SelectedWord();
        FindBox.SetValue(Hint.TextProperty, IsFile ? "Find in this file" : "Find in this page");
        FindBar.Visibility = Visibility.Visible;
        if (!string.IsNullOrEmpty(text))
        {
            FindBox.Text = text;
        }
        FindBox.Focus();
        FindBox.SelectAll();
        RunFind(keepPlace: false);
    }

    private void CloseFind()
    {
        FindBar.Visibility = Visibility.Collapsed;
        FindAllPanel.Visibility = Visibility.Collapsed;
        ClearFindMarks();
        if (IsFile)
        {
            Code.Find(null, Options);
            Code.Focus();
        }
        else
        {
            Viewer.Focus();
        }
    }

    private void ClearFindMarks()
    {
        foreach (var host in _pageMatches.Select(m => m.Host).Append(Viewer).Distinct())
        {
            FindHighlightAdorner.Clear(host);
        }
        _pageMatches = [];
        _findIndex = -1;
    }

    /// <summary>The page or file changed (another opened, or the page finished rendering): find again if Find is open.</summary>
    private void RefreshFind()
    {
        if (FindBar.Visibility == Visibility.Visible)
        {
            Dispatcher.BeginInvoke(() => RunFind(keepPlace: false), DispatcherPriority.Background);
        }
        else
        {
            _pageMatches = [];
            _findIndex = -1;
        }
    }

    private void RunFind(bool keepPlace)
    {
        if (FindBar.Visibility != Visibility.Visible || _vm is null)
        {
            return;
        }
        var query = FindBox.Text;
        var problem = TextMatcher.Problem(query, Options);
        FindProblem.Text = problem ?? "";
        FindProblem.Visibility = problem is null ? Visibility.Collapsed : Visibility.Visible;
        var previous = _findIndex;
        ClearFindMarks();
        int count;
        if (IsFile)
        {
            count = Code.Find(query, Options);
            _findIndex = count == 0 ? -1 : keepPlace && previous >= 0 ? Math.Min(previous, count - 1) : Code.FirstMatchFromCaret();
            if (_findIndex >= 0)
            {
                Code.GoToMatch(_findIndex);
            }
        }
        else
        {
            _pageMatches = PageMatches(query);
            count = _pageMatches.Count;
            _findIndex = count == 0 ? -1 : keepPlace && previous >= 0 ? Math.Min(previous, count - 1) : FirstVisibleMatch();
            ShowPageMarks();
            ScrollToMatch();
        }
        UpdateCount(count);
        if (FindAllPanel.Visibility == Visibility.Visible)
        {
            FillFindAll();
        }
    }

    private void UpdateCount(int count)
    {
        FindCount.Text = string.IsNullOrEmpty(FindBox.Text) ? "" : count == 0 ? "No results" : $"{_findIndex + 1} of {count:N0}{(count >= TextMatcher.MaxMatches ? "+" : "")}";
    }

    private void Step(int by)
    {
        var count = IsFile ? Code.Matches.Count : _pageMatches.Count;
        if (count == 0)
        {
            if (FindBar.Visibility != Visibility.Visible)
            {
                OpenFind(SelectedWord());
            }
            return;
        }
        _findIndex = ((_findIndex < 0 ? (by > 0 ? -1 : 0) : _findIndex) + by + count) % count;
        if (IsFile)
        {
            Code.GoToMatch(_findIndex);
        }
        else
        {
            ShowPageMarks();
            ScrollToMatch();
        }
        UpdateCount(count);
        if (FindResults.Items.Count > _findIndex && FindAllPanel.Visibility == Visibility.Visible)
        {
            FindResults.SelectionChanged -= OnFindResultChosen;
            FindResults.SelectedIndex = _findIndex;
            FindResults.ScrollIntoView(FindResults.SelectedItem);
            FindResults.SelectionChanged += OnFindResultChosen;
        }
    }

    // ----- A page: the FlowDocument and the code blocks in it -----

    private List<(FrameworkElement Host, TextRange Range)> PageMatches(string query)
    {
        var matches = new List<(FrameworkElement Host, TextRange Range, TextPointer Order)>();
        if (string.IsNullOrEmpty(query) || Viewer.Document is not { } document)
        {
            return [];
        }
        foreach (var range in TextFind.Find(document.ContentStart, document.ContentEnd, query, Options))
        {
            matches.Add((Viewer, range, range.Start));
        }
        // Code blocks are their own text boxes inside the page: searched too, in their place in the page.
        foreach (var container in document.Blocks.SelectMany(AllBlocks).OfType<BlockUIContainer>())
        {
            foreach (var box in Descendants<RichTextBox>(container.Child))
            {
                foreach (var range in TextFind.Find(box.Document.ContentStart, box.Document.ContentEnd, query, Options))
                {
                    matches.Add((box, range, container.ContentStart));
                }
            }
        }
        return matches.OrderBy(m => document.ContentStart.GetOffsetToPosition(m.Order))
            .ThenBy(m => m.Host is RichTextBox r ? r.Document.ContentStart.GetOffsetToPosition(m.Range.Start) : 0)
            .Select(m => (m.Host, m.Range)).ToList();
    }

    private static IEnumerable<Block> AllBlocks(Block block)
    {
        yield return block;
        IEnumerable<Block> inner = block switch
        {
            Section s => s.Blocks,
            List l => l.ListItems.SelectMany(i => i.Blocks),
            Table t => t.RowGroups.SelectMany(g => g.Rows).SelectMany(r => r.Cells).SelectMany(c => c.Blocks),
            _ => [],
        };
        foreach (var b in inner.SelectMany(AllBlocks))
        {
            yield return b;
        }
    }

    private static IEnumerable<T> Descendants<T>(DependencyObject? from) where T : DependencyObject
    {
        if (from is null)
        {
            yield break;
        }
        if (from is T self)
        {
            yield return self;
        }
        var count = from is Visual ? VisualTreeHelper.GetChildrenCount(from) : 0;
        for (var i = 0; i < count; i++)
        {
            foreach (var found in Descendants<T>(VisualTreeHelper.GetChild(from, i)))
            {
                yield return found;
            }
        }
        if (count == 0)
        {
            foreach (var child in LogicalTreeHelper.GetChildren(from).OfType<DependencyObject>())
            {
                foreach (var found in Descendants<T>(child))
                {
                    yield return found;
                }
            }
        }
    }

    private void ShowPageMarks()
    {
        foreach (var group in _pageMatches.Select((m, i) => (m.Host, m.Range, i)).GroupBy(m => m.Host))
        {
            var ranges = group.Select(g => g.Range).ToList();
            var current = group.Select(g => g.i).ToList().IndexOf(_findIndex);
            FindHighlightAdorner.For(group.Key)?.Show(ranges, current);
        }
    }

    /// <summary>The first match at or below the top of what is shown (Find starts where the reader is).</summary>
    private int FirstVisibleMatch()
    {
        for (var i = 0; i < _pageMatches.Count; i++)
        {
            if (FindHighlightAdorner.Boxes(_pageMatches[i].Range, _pageMatches[i].Host).FirstOrDefault() is { IsEmpty: false } box
                && _pageMatches[i].Host.TranslatePoint(box.TopLeft, Viewer).Y >= 0)
            {
                return i;
            }
        }
        return _pageMatches.Count > 0 ? 0 : -1;
    }

    private void ScrollToMatch()
    {
        if (_findIndex < 0 || _findIndex >= _pageMatches.Count || _scroller is null)
        {
            return;
        }
        var (host, range) = _pageMatches[_findIndex];
        if (FindHighlightAdorner.Boxes(range, host).FirstOrDefault() is not { IsEmpty: false } box)
        {
            range.Start.Paragraph?.BringIntoView();
            return;
        }
        var top = host.TranslatePoint(box.TopLeft, Viewer).Y;
        // In view (away from the edges): leave it; else bring it to a third of the way down.
        if (top < 40 || top > Viewer.ActualHeight - 60)
        {
            _scroller.ScrollToVerticalOffset(Math.Max(0, _scroller.VerticalOffset + top - Viewer.ActualHeight / 3));
        }
        // A code block's own sideways scroll.
        if (host is RichTextBox code)
        {
            code.Selection.Select(range.Start, range.Start);
            range.Start.Paragraph?.BringIntoView();
        }
    }

    // ----- Find all -----

    private void FillFindAll()
    {
        var results = new List<FindResult>();
        if (IsFile)
        {
            var matches = Code.Matches;
            for (var i = 0; i < matches.Count; i++)
            {
                var (line, text, match) = matches[i];
                results.Add(Result(i, $"line {line}", text, match.Start, match.Length));
            }
        }
        else
        {
            for (var i = 0; i < _pageMatches.Count; i++)
            {
                var range = _pageMatches[i].Range;
                var paragraph = range.Start.Paragraph;
                var before = paragraph is null ? "" : new TextRange(paragraph.ContentStart, range.Start).Text;
                var after = paragraph is null ? "" : new TextRange(range.End, paragraph.ContentEnd).Text;
                var text = before + range.Text + after;
                results.Add(Result(i, _pageMatches[i].Host is RichTextBox ? "code" : Heading(range.Start), text, before.Length, range.Text.Length));
            }
        }
        FindResults.SelectionChanged -= OnFindResultChosen;
        FindResults.ItemsSource = results;
        FindResults.SelectedIndex = _findIndex;
        FindResults.SelectionChanged += OnFindResultChosen;
        FindAllHeader.Text = $"Find all “{FindBox.Text}” — {(results.Count == 0 ? "no matches" : $"{results.Count:N0} {(results.Count == 1 ? "match" : "matches")}")}";
    }

    private static FindResult Result(int index, string location, string text, int start, int length)
    {
        text = text.Replace('\t', ' ').Replace('\n', ' ').Replace('\r', ' ');
        start = Math.Clamp(start, 0, text.Length);
        length = Math.Clamp(length, 0, text.Length - start);
        var from = Math.Max(0, start - 60);
        var before = (from > 0 ? "…" : "") + text[from..start].TrimStart();
        var to = Math.Min(text.Length, start + length + 100);
        return new FindResult(index, location, before, text.Substring(start, length), text[(start + length)..to] + (to < text.Length ? "…" : ""));
    }

    /// <summary>The heading a place in the page is under (for Find all's location column).</summary>
    private string Heading(TextPointer at)
    {
        var text = _rendered?.Headings.Where(h => h.Block.ContentStart.CompareTo(at) <= 0).Select(h => h.Text).LastOrDefault() ?? "top";
        return text.Length > 14 ? text[..13] + "…" : text;
    }

    // ----- Handlers -----

    private void OnFindTextChanged(object sender, TextChangedEventArgs e)
    {
        if (!UiPreferences.Current.FindAsYouType)
        {
            return;
        }
        _findTimer?.Stop();
        _findTimer?.Start();
    }

    private void OnFindOptionChanged(object sender, RoutedEventArgs e) => RunFind(keepPlace: false);

    private void OnFindKeyDown(object sender, KeyEventArgs e)
    {
        var shift = Keyboard.Modifiers.HasFlag(ModifierKeys.Shift);
        var alt = Keyboard.Modifiers.HasFlag(ModifierKeys.Alt);
        var key = e.Key == Key.System ? e.SystemKey : e.Key;
        switch (key)
        {
            case Key.Enter:
                if (_findTimer?.IsEnabled == true || !UiPreferences.Current.FindAsYouType)
                {
                    _findTimer?.Stop();
                    RunFind(keepPlace: false);
                }
                else
                {
                    Step(shift ? -1 : +1);
                }
                e.Handled = true;
                break;
            case Key.Escape:
                CloseFind();
                e.Handled = true;
                break;
            case Key.C when alt:
                FindCase.IsChecked = FindCase.IsChecked != true;
                e.Handled = true;
                break;
            case Key.W when alt:
                FindWord.IsChecked = FindWord.IsChecked != true;
                e.Handled = true;
                break;
            case Key.E when alt:
                FindRegex.IsChecked = FindRegex.IsChecked != true;
                e.Handled = true;
                break;
            case Key.A when alt:
                OnFindAll(sender, e);
                e.Handled = true;
                break;
        }
    }

    private void OnFindNext(object sender, RoutedEventArgs e) => Step(+1);

    private void OnFindPrevious(object sender, RoutedEventArgs e) => Step(-1);

    private void OnCloseFind(object sender, RoutedEventArgs e) => CloseFind();

    private void OnFindAll(object sender, RoutedEventArgs e)
    {
        if (_findTimer?.IsEnabled == true || (IsFile ? Code.Matches.Count : _pageMatches.Count) == 0)
        {
            _findTimer?.Stop();
            RunFind(keepPlace: false);
        }
        FindAllPanel.Visibility = Visibility.Visible;
        FillFindAll();
    }

    private void OnCloseFindAll(object sender, RoutedEventArgs e) => FindAllPanel.Visibility = Visibility.Collapsed;

    private void OnFindResultChosen(object sender, EventArgs e)
    {
        if (FindResults.SelectedItem is not FindResult result)
        {
            return;
        }
        _findIndex = result.Index;
        if (IsFile)
        {
            Code.GoToMatch(_findIndex);
            UpdateCount(Code.Matches.Count);
        }
        else
        {
            ShowPageMarks();
            ScrollToMatch();
            UpdateCount(_pageMatches.Count);
        }
    }
}
