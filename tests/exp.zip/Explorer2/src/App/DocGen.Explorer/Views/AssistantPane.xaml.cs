using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using DocGen.Explorer.Infrastructure;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Views;

public partial class AssistantPane : UserControl
{
    private AssistantViewModel? _vm;

    /// <summary>The thread follows an answer being written only while the reader is at its end.</summary>
    private bool _follow = true;

    public AssistantPane()
    {
        InitializeComponent();
        Rail.Attach(Thread, MessageList);
        DataContextChanged += (_, e) =>
        {
            if (_vm is not null)
            {
                _vm.ScrollRequested -= OnScrollRequested;
                _vm.FollowRequested -= OnFollowRequested;
                _vm.RevealRequested -= OnRevealRequested;
            }
            _vm = e.NewValue as AssistantViewModel;
            if (_vm is not null)
            {
                _vm.ScrollRequested += OnScrollRequested;
                _vm.FollowRequested += OnFollowRequested;
                _vm.RevealRequested += OnRevealRequested;
            }
        };
        Thread.ScrollChanged += (_, e) =>
        {
            // The reader scrolled (not the answer growing): follow again only once back at the end.
            if (e.ExtentHeightChange == 0 && e.ViewportHeightChange == 0)
            {
                _follow = Thread.VerticalOffset >= Thread.ScrollableHeight - 24;
            }
        };
        // Pictures, files and long or structured text pasted into the question box become attachments.
        CommandManager.AddPreviewCanExecuteHandler(InputBox, OnPasteCanExecute);
        CommandManager.AddPreviewExecutedHandler(InputBox, OnPasteExecuted);
        InputBox.InputBindings.Add(new KeyBinding(new RelayCommand(PastePlainText), Key.V, ModifierKeys.Control | ModifierKeys.Shift));
    }

    private void OnScrollRequested(object? sender, EventArgs e)
    {
        _follow = true;
        Dispatcher.BeginInvoke(() => Thread.ScrollToEnd(), DispatcherPriority.Background);
    }

    private void OnFollowRequested(object? sender, EventArgs e)
    {
        if (_follow)
        {
            Dispatcher.BeginInvoke(() =>
            {
                if (_follow)
                {
                    Thread.ScrollToEnd();
                }
            }, DispatcherPriority.Background);
        }
    }

    /// <summary>Search: brings the message with the current match into view (its first match near the top).</summary>
    private void OnRevealRequested(object? sender, ChatMessageViewModel message)
    {
        _follow = false;
        Dispatcher.BeginInvoke(() =>
        {
            if (MessageList.ItemContainerGenerator.ContainerFromItem(message) is not FrameworkElement container || !container.IsVisible)
            {
                return;
            }
            var top = container.TransformToAncestor(Thread).Transform(new Point(0, 0)).Y + Thread.VerticalOffset;
            // The first marked word, when it is further down a long answer.
            foreach (var box in FindMarks(container))
            {
                top = box.TransformToAncestor(Thread).Transform(new Point(0, 0)).Y + Thread.VerticalOffset;
                var ranges = box switch
                {
                    RichTextBox rich => Controls.TextFind.Find(rich.Document.ContentStart, rich.Document.ContentEnd, message.SearchQuery),
                    TextBlock block => Controls.TextFind.Find(block.ContentStart, block.ContentEnd, message.SearchQuery),
                    _ => [],
                };
                if (ranges.FirstOrDefault() is { } first && Controls.FindHighlightAdorner.Boxes(first, box).FirstOrDefault() is var rect && !rect.IsEmpty)
                {
                    top += rect.Top;
                }
                break;
            }
            Thread.ScrollToVerticalOffset(Math.Max(0, top - 60));
        }, DispatcherPriority.Loaded);
    }

    private static IEnumerable<FrameworkElement> FindMarks(DependencyObject from)
    {
        var count = System.Windows.Media.VisualTreeHelper.GetChildrenCount(from);
        for (var i = 0; i < count; i++)
        {
            var child = System.Windows.Media.VisualTreeHelper.GetChild(from, i);
            if (child is FrameworkElement element && Controls.TextHighlight.GetQuery(element) is { Length: > 0 })
            {
                yield return element;
            }
            foreach (var inner in FindMarks(child))
            {
                yield return inner;
            }
        }
    }

    private void OnSearchKeyDown(object sender, KeyEventArgs e)
    {
        if (_vm is null)
        {
            return;
        }
        if (e.Key == Key.Enter)
        {
            e.Handled = true;
            (Keyboard.Modifiers.HasFlag(ModifierKeys.Shift) ? _vm.PreviousMatchCommand : _vm.NextMatchCommand).Execute(null);
        }
        else if (e.Key == Key.Escape)
        {
            e.Handled = true;
            _vm.IsSearchOpen = false;
            InputBox.Focus();
        }
    }

    // ----- Pasting: pictures, files and long or structured text become attachments -----

    private void OnPasteCanExecute(object sender, CanExecuteRoutedEventArgs e)
    {
        // A picture or copied files on the clipboard: the box itself would refuse them.
        if (e.Command == ApplicationCommands.Paste && UiPreferences.Current.PasteAsAttachment && (SafeClipboard(Clipboard.ContainsImage) || SafeClipboard(Clipboard.ContainsFileDropList)))
        {
            e.CanExecute = true;
            e.Handled = true;
        }
    }

    private async void OnPasteExecuted(object sender, ExecutedRoutedEventArgs e)
    {
        if (e.Command != ApplicationCommands.Paste || _vm is null || !UiPreferences.Current.PasteAsAttachment)
        {
            return;
        }
        try
        {
            if (SafeClipboard(Clipboard.ContainsFileDropList) && Clipboard.GetFileDropList() is { Count: > 0 } files)
            {
                e.Handled = true;
                await _vm.AttachAsync(files.Cast<string>().ToList());
                return;
            }
            if (SafeClipboard(Clipboard.ContainsImage) && PastedPicture() is { } png)
            {
                e.Handled = true;
                await _vm.AttachPastedImageAsync(png);
                return;
            }
            if (SafeClipboard(Clipboard.ContainsText) && Clipboard.GetText() is { Length: > 0 } text
                && Engine.Assistant.Attachments.PasteAsAttachment(text, UiPreferences.Current.PasteAttachmentChars, UiPreferences.Current.PasteAttachmentLines))
            {
                e.Handled = true;
                await _vm.AttachPastedTextAsync(text);
            }
        }
        catch (System.Runtime.InteropServices.COMException ex)
        {
            // The clipboard is busy (another program holds it): the box pastes as usual.
            Logging.Error(ex, "Paste");
        }
    }

    /// <summary>Ctrl+Shift+V: the clipboard's text into the box as it is, never as an attachment.</summary>
    private void PastePlainText()
    {
        if (SafeClipboard(Clipboard.ContainsText))
        {
            InputBox.SelectedText = Clipboard.GetText();
            InputBox.CaretIndex = InputBox.SelectionStart + InputBox.SelectionLength;
            InputBox.SelectionLength = 0;
        }
    }

    /// <summary>The clipboard's picture as PNG: its own PNG when a program put one there (keeping transparency), else its bitmap.</summary>
    private static byte[]? PastedPicture()
    {
        if (Clipboard.GetData("PNG") is MemoryStream stream && stream.Length > 0)
        {
            return stream.ToArray();
        }
        if (Clipboard.GetImage() is not { } image)
        {
            return null;
        }
        var encoder = new PngBitmapEncoder();
        encoder.Frames.Add(BitmapFrame.Create(image));
        using var output = new MemoryStream();
        encoder.Save(output);
        return output.ToArray();
    }

    private static bool SafeClipboard(Func<bool> check)
    {
        try
        {
            return check();
        }
        catch (System.Runtime.InteropServices.COMException)
        {
            return false;
        }
    }

    // ----- Spelling: clicking an underlined word offers its corrections -----

    private void OnInputClick(object sender, MouseButtonEventArgs e)
    {
        if (!UiPreferences.Current.SpellCheck || !UiPreferences.Current.SpellCheckOnClick || InputBox.SelectionLength > 0)
        {
            return;
        }
        var index = InputBox.GetCharacterIndexFromPoint(e.GetPosition(InputBox), snapToText: false);
        if (index < 0 || InputBox.GetSpellingError(index) is not { } error)
        {
            return;
        }
        var menu = new ContextMenu { PlacementTarget = InputBox, Placement = PlacementMode.MousePoint };
        var suggestions = error.Suggestions.Take(6).ToList();
        foreach (var suggestion in suggestions)
        {
            var item = new MenuItem { Header = suggestion, FontWeight = FontWeights.SemiBold };
            item.Click += (_, _) =>
            {
                error.Correct(suggestion);
                InputBox.Focus();
            };
            menu.Items.Add(item);
        }
        if (suggestions.Count == 0)
        {
            menu.Items.Add(new MenuItem { Header = "No suggestions", IsEnabled = false });
        }
        menu.Items.Add(new Separator());
        var ignore = new MenuItem { Header = "Ignore this word", Icon = "\uE711" };
        ignore.Click += (_, _) =>
        {
            error.IgnoreAll();
            InputBox.Focus();
        };
        menu.Items.Add(ignore);
        menu.IsOpen = true;
        e.Handled = true;
    }

    // ----- Files dropped on the question box are attached -----

    private void OnComposerDragOver(object sender, DragEventArgs e)
    {
        if (e.Data.GetDataPresent(DataFormats.FileDrop))
        {
            e.Effects = DragDropEffects.Copy;
            e.Handled = true;
        }
    }

    private async void OnComposerDrop(object sender, DragEventArgs e)
    {
        if (_vm is not null && e.Data.GetData(DataFormats.FileDrop) is string[] files)
        {
            e.Handled = true;
            await _vm.AttachAsync(files);
        }
    }

    // Settings → Voice → Microphone: hold to talk, or click to start and click again to stop.
    private bool Toggles => _vm?.Workspace.Main.Speech.MicrophoneToggles == true;

    private async void OnMicDown(object sender, MouseButtonEventArgs e)
    {
        if (_vm is null)
        {
            return;
        }
        if (Toggles)
        {
            e.Handled = true;
            if (_vm.IsRecording)
            {
                await _vm.StopRecordingAsync();
            }
            else
            {
                await _vm.StartRecordingAsync();
            }
            return;
        }
        Mouse.Capture(MicButton);
        await _vm.StartRecordingAsync();
    }

    private async void OnMicUp(object sender, MouseButtonEventArgs e)
    {
        if (Toggles)
        {
            return;
        }
        Mouse.Capture(null);
        if (_vm is not null)
        {
            await _vm.StopRecordingAsync();
        }
    }

    private async void OnMicLeave(object sender, MouseEventArgs e)
    {
        if (!Toggles && _vm is { IsRecording: true } && e.LeftButton != MouseButtonState.Pressed)
        {
            await _vm.StopRecordingAsync();
        }
    }
}
