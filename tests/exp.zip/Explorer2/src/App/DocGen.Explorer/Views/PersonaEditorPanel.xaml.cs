using System.Windows.Controls;

namespace DocGen.Explorer.Views;

/// <summary>The persona editor card: on the Personas page, and in the window Studio opens to add or edit a persona.</summary>
public partial class PersonaEditorPanel : UserControl
{
    public PersonaEditorPanel() => InitializeComponent();
}
