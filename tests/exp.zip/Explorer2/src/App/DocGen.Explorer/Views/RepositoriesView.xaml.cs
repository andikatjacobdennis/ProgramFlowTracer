using System.Windows;
using System.Windows.Controls;

namespace DocGen.Explorer.Views;

public partial class RepositoriesView : UserControl
{
    public static readonly DependencyProperty CardWidthProperty = DependencyProperty.Register(nameof(CardWidth), typeof(double), typeof(RepositoriesView), new PropertyMetadata(420.0));

    public RepositoriesView()
    {
        InitializeComponent();
        SizeChanged += (_, _) => Relayout();
    }

    /// <summary>Cards fill the row: three across on wide windows, two or one as it narrows.</summary>
    public double CardWidth
    {
        get => (double)GetValue(CardWidthProperty);
        set => SetValue(CardWidthProperty, value);
    }

    private void Relayout()
    {
        var available = Math.Min(1400, ActualWidth - 72);
        var columns = available > 1200 ? 3 : available > 760 ? 2 : 1;
        CardWidth = Math.Floor((available - 16 * (columns - 1)) / columns) - 1;
        Totals.Columns = available > 820 ? 4 : 2;
    }

    private void OnAddRepositoryClick(object sender, RoutedEventArgs e)
    {
        // The form appears once the command has run: scroll to it then.
        Dispatcher.BeginInvoke(() =>
        {
            AddPanel.BringIntoView();
            LocalPathBox.Focus();
        }, System.Windows.Threading.DispatcherPriority.Loaded);
    }
}
