using System.Windows;
using DocGen.Core.Models;
using DocGen.Explorer.Infrastructure;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Views;

/// <summary>The persona editor as a window over Studio: add a speaker, or change one, without leaving the conversation.</summary>
public partial class PersonaEditorWindow : Window
{
    private Persona? _saved;

    private PersonaEditorWindow(PersonasViewModel host)
    {
        InitializeComponent();
        DataContext = host;
        host.EditorClosed += OnEditorClosed;
        Closed += (_, _) => host.EditorClosed -= OnEditorClosed;
        SourceInitialized += (_, _) => ThemeManager.ApplyTitleBar(this);
    }

    private void OnEditorClosed(Persona? saved)
    {
        _saved = saved;
        Close();
    }

    /// <summary>
    /// Edits <paramref name="persona"/> (or writes a new one when null) and returns what was saved, or null when the
    /// window was cancelled or closed.
    /// </summary>
    public static Persona? Edit(MainViewModel main, Persona? persona)
    {
        var window = Create(main, persona);
        window.ShowDialog();
        return window._saved;
    }

    /// <summary>The window, ready to show (screen captures show it without waiting on it).</summary>
    internal static PersonaEditorWindow Create(MainViewModel main, Persona? persona)
    {
        var host = new PersonasViewModel(main);
        if (persona is null)
        {
            host.StartNew();
        }
        else
        {
            host.StartEdit(persona);
        }
        var window = new PersonaEditorWindow(host)
        {
            Owner = Application.Current.MainWindow,
            Title = persona is null ? "New persona" : $"Edit {persona.Name}",
        };
        return window;
    }
}
