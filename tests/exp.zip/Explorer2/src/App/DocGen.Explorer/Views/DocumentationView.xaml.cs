using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using DocGen.Explorer.Controls;
using DocGen.Explorer.Infrastructure;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Views;

public partial class DocumentationView : UserControl
{
    private DocumentationViewModel? _vm;
    private RenderedMarkdown? _rendered;
    private ScrollViewer? _scroller;
    private string? _pendingAnchor;

    public DocumentationView()
    {
        InitializeComponent();
        Resources["OutlineItemTemplate"] = BuildOutlineTemplate();
        // Right-click on the page: Copy, Select all, Summarise selection.
        Viewer.ContextMenu = SummariseSelection.Menu(Viewer);
        DataContextChanged += (_, e) => Attach(e.NewValue as DocumentationViewModel);
        Loaded += (_, _) =>
        {
            Attach(DataContext as DocumentationViewModel);
            HookScroller();
        };
        Unloaded += (_, _) => Detach();
        SizeChanged += (_, _) => UpdateOutlinePlacement();
        Viewer.SizeChanged += (_, e) =>
        {
            if (e.HeightChanged)
            {
                FitEndSpace();
            }
        };
        Code.LineLinkRequested += (_, line) => _vm?.CopyLineLink(line);
        WireFind();
        ThemeManager.Changed += (_, _) =>
        {
            if (_vm?.Mode == "page")
            {
                RenderPage(force: true);
            }
        };
    }

    private void Attach(DocumentationViewModel? vm)
    {
        if (ReferenceEquals(vm, _vm))
        {
            return;
        }
        Detach();
        _vm = vm;
        if (vm is null)
        {
            return;
        }
        vm.PageChanged += OnPageChanged;
        vm.FileChanged += OnFileChanged;
        vm.AnchorRequested += OnAnchorRequested;
        vm.FoldRequested += OnFoldRequested;
        vm.PropertyChanged += OnVmPropertyChanged;
        HookEditing(vm, true);
        Code.Wrap = vm.Wrap ? TextWrapping.Wrap : TextWrapping.NoWrap;
        // Show what is already open.
        if (vm.Mode == "page")
        {
            RenderPage();
        }
        else if (vm.Mode == "file")
        {
            Code.Load(vm.Lines, vm.FileLanguage, 0);
            OnClassDiagramChanged(vm, EventArgs.Empty);
        }
        else if (vm.Mode == "diff")
        {
            // Back from another section or panel: the diff (or the editing of it) drawn again.
            _wasDiffEditing = false;
            if (vm.IsDiffEditing)
            {
                OnDiffEditChanged(vm, EventArgs.Empty);
            }
            else
            {
                OnDiffChanged(vm, EventArgs.Empty);
            }
        }
    }

    private void Detach()
    {
        if (_vm is null)
        {
            return;
        }
        _vm.PageChanged -= OnPageChanged;
        _vm.FileChanged -= OnFileChanged;
        _vm.AnchorRequested -= OnAnchorRequested;
        _vm.FoldRequested -= OnFoldRequested;
        _vm.PropertyChanged -= OnVmPropertyChanged;
        HookEditing(_vm, false);
        _vm = null;
    }

    private void OnPageChanged(object? sender, EventArgs e) => RenderPage();

    private void OnVmPropertyChanged(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(DocumentationViewModel.Wrap) && _vm is not null)
        {
            Code.Wrap = _vm.Wrap ? TextWrapping.Wrap : TextWrapping.NoWrap;
        }
        else if (e.PropertyName == nameof(DocumentationViewModel.HasOutline))
        {
            UpdateOutlinePlacement();
        }
    }

    private void OnFileChanged(object? sender, int line)
    {
        if (_vm is null)
        {
            return;
        }
        Code.Wrap = _vm.Wrap ? TextWrapping.Wrap : TextWrapping.NoWrap;
        Code.Load(_vm.Lines, _vm.FileLanguage, line);
        RefreshFind();
    }

    private void OnFoldRequested(object? sender, bool fold) => Code.FoldAll(fold);

    private void OnAnchorRequested(object? sender, string anchor)
    {
        _pendingAnchor = anchor;
        Dispatcher.BeginInvoke(ScrollToPendingAnchor, System.Windows.Threading.DispatcherPriority.Loaded);
    }

    private int _renderGeneration;
    private string? _renderedKey;
    private bool _rendering;

    /// <summary>
    /// Renders the open page. A large page shows its first screen at once and the rest is added in small batches that
    /// yield to the UI between them, so a long README never freezes the window. An unchanged page is not rendered again.
    /// </summary>
    private async void RenderPage(bool force = false)
    {
        if (_vm?.Page is null)
        {
            return;
        }
        var markdown = _vm.Markdown ?? "";
        var key = $"{_vm.Page.Id}|{markdown.Length}|{markdown.GetHashCode()}";
        if (!force && key == _renderedKey && Viewer.Document is not null)
        {
            return;
        }
        _renderedKey = key;
        var generation = ++_renderGeneration;
        // The page's own H1 becomes the title card.
        var lines = markdown.Replace("\r\n", "\n", StringComparison.Ordinal).Split('\n').ToList();
        var first = lines.FindIndex(l => l.Trim().Length > 0);
        if (first >= 0 && lines[first].TrimStart().StartsWith("# ", StringComparison.Ordinal))
        {
            lines.RemoveAt(first);
            markdown = string.Join("\n", lines);
        }
        var workspace = _vm.Workspace;
        var sourcePath = _vm.Page.SourcePath;
        var options = new MarkdownRenderOptions
        {
            OnLink = url => workspace.OpenLink(url, sourcePath),
            OnCopyHeadingLink = anchor => _vm?.CopyAnchorLink(anchor),
            Hero = Hero(_vm.PageTitle, _vm.PageSourceText, _vm.PageIsGenerated),
        };
        var (rendered, pending) = MarkdownRenderer.RenderStart(markdown, options, 10);
        _rendered = rendered;
        rendered.Document.PagePadding = new Thickness(0, 4, 18, 0);
        Viewer.Document = rendered.Document;
        FitEndSpace();
        HookScroller();
        _scroller?.ScrollToTop();
        _vm.SetActiveAnchor(_vm.Outline.FirstOrDefault()?.Anchor);
        UpdateOutlinePlacement();

        _rendering = pending.Count > 0;
        var next = 0;
        var clock = System.Diagnostics.Stopwatch.StartNew();
        while (next < pending.Count)
        {
            // Let input and layout run, then add blocks for at most ~20 ms.
            await System.Windows.Threading.Dispatcher.Yield(System.Windows.Threading.DispatcherPriority.Background);
            if (generation != _renderGeneration)
            {
                return; // another page was opened meanwhile
            }
            clock.Restart();
            var batch = new List<Engine.Markdown.MdBlock>();
            while (next < pending.Count && (batch.Count < 4 || clock.ElapsedMilliseconds < 20))
            {
                batch.Add(pending[next++]);
                MarkdownRenderer.Append(rendered, batch.Skip(batch.Count - 1), options);
                if (batch.Count >= 12)
                {
                    break;
                }
            }
        }
        MarkdownRenderer.Finish(rendered);
        _rendering = false;
        if (_pendingAnchor is not null)
        {
            ScrollToPendingAnchor();
        }
        RefreshFind();
    }

    private static UIElement Hero(string title, string source, bool generated)
    {
        var border = new Border { Padding = new Thickness(0, 4, 0, 4) };
                border.SetResourceReference(Border.BorderBrushProperty, "Brush.Border");
        var grid = new Grid();
        grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
        grid.ColumnDefinitions.Add(new ColumnDefinition());
        var tile = new Border { Width = 38, Height = 38, CornerRadius = new CornerRadius(8), Margin = new Thickness(0, 2, 16, 0), VerticalAlignment = VerticalAlignment.Top, BorderThickness = new Thickness(1) };
        tile.SetResourceReference(Border.BackgroundProperty, "Brush.Selected");
        tile.SetResourceReference(Border.BorderBrushProperty, "Brush.Border");
        var glyph = new TextBlock { Text = generated ? Icons.Library : Icons.Document, FontSize = 16, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        glyph.SetResourceReference(TextBlock.FontFamilyProperty, "Font.Icons");
        glyph.SetResourceReference(TextBlock.ForegroundProperty, "Brush.TextMuted");
        tile.Child = glyph;
        grid.Children.Add(tile);
        var stack = new StackPanel();
        var heading = new TextBlock { Text = title, FontWeight = FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap };
        heading.SetResourceReference(TextBlock.FontSizeProperty, "FontSize.H1");
        heading.SetResourceReference(TextBlock.FontFamilyProperty, "Font.Display");
        heading.SetResourceReference(TextBlock.ForegroundProperty, "Brush.Text");
        stack.Children.Add(heading);
        var sub = new TextBlock { Text = source, FontSize = 12.5, Margin = new Thickness(0, 4, 0, 0) };
        sub.SetResourceReference(TextBlock.ForegroundProperty, "Brush.TextMuted");
        stack.Children.Add(sub);
        Grid.SetColumn(stack, 1);
        grid.Children.Add(stack);
        border.Child = grid;
        return border;
    }

    private DataTemplate BuildOutlineTemplate()
    {
        var factory = new FrameworkElementFactory(typeof(Button));
        factory.SetResourceReference(StyleProperty, "Button.Row");
        factory.SetValue(Button.PaddingProperty, new Thickness(10, 5, 10, 5));
        factory.SetBinding(Button.CommandProperty, new System.Windows.Data.Binding("DataContext.GoToAnchorCommand") { RelativeSource = new System.Windows.Data.RelativeSource(System.Windows.Data.RelativeSourceMode.FindAncestor, typeof(UserControl), 1) });
        factory.SetBinding(Button.CommandParameterProperty, new System.Windows.Data.Binding("Anchor"));
        factory.SetBinding(MarginProperty, new System.Windows.Data.Binding("Indent"));
        factory.SetValue(Button.HorizontalContentAlignmentProperty, HorizontalAlignment.Left);
        var text = new FrameworkElementFactory(typeof(TextBlock));
        text.SetBinding(TextBlock.TextProperty, new System.Windows.Data.Binding("Text"));
        text.SetValue(TextBlock.TextWrappingProperty, TextWrapping.Wrap);
        text.SetValue(TextBlock.FontSizeProperty, 13.5);
        var style = new Style(typeof(TextBlock));
        style.Setters.Add(new Setter(TextBlock.ForegroundProperty, new DynamicResourceExtension("Brush.TextMuted")));
        var active = new DataTrigger { Binding = new System.Windows.Data.Binding("IsActive"), Value = true };
        active.Setters.Add(new Setter(TextBlock.ForegroundProperty, new DynamicResourceExtension("Brush.Accent")));
        active.Setters.Add(new Setter(TextBlock.FontWeightProperty, FontWeights.SemiBold));
        style.Triggers.Add(active);
        text.SetValue(StyleProperty, style);
        factory.AppendChild(text);
        return new DataTemplate { VisualTree = factory };
    }

    private void UpdateOutlinePlacement()
    {
        var wide = ActualWidth > 1080 && _vm?.HasOutline == true;
        OutlineColumn.Width = wide ? new GridLength(240) : new GridLength(0);
        OutlineSide.Visibility = wide ? Visibility.Visible : Visibility.Collapsed;
        OutlineTop.Visibility = !wide && _vm?.HasOutline == true ? Visibility.Visible : Visibility.Collapsed;
    }

    private void HookScroller()
    {
        if (_scroller is not null)
        {
            return;
        }
        Viewer.ApplyTemplate();
        _scroller = FindChild<ScrollViewer>(Viewer);
        if (_scroller is not null)
        {
            _scroller.ScrollChanged += (_, e) =>
            {
                TrackActiveHeading();
                // The page or the view changed size: the room after the end may now be needed, or not.
                if (e.ExtentHeightChange != 0 || e.ViewportHeightChange != 0)
                {
                    FitEndSpace();
                }
            };
        }
    }

    private void TrackActiveHeading()
    {
        if (_rendered is null || _scroller is null || _vm is null || _rendered.Headings.Count == 0)
        {
            return;
        }
        string? active = null;
        foreach (var (anchor, _, level, block) in _rendered.Headings)
        {
            if (level is < 2 or > 3)
            {
                continue;
            }
            var top = HeadingTop(block);
            if (top is null)
            {
                continue;
            }
            if (top.Value - _scroller.VerticalOffset <= 90)
            {
                active = anchor;
            }
            else
            {
                break;
            }
        }
        _vm.SetActiveAnchor(active ?? _vm.Outline.FirstOrDefault()?.Anchor);
    }

    /// <summary>
    /// How far down the page a heading is (a scroll offset), measured from the page's own start, so it is the same
    /// wherever the page is scrolled to.
    /// </summary>
    private double? HeadingTop(Block block)
    {
        var rect = block.ContentStart.GetCharacterRect(LogicalDirection.Forward);
        var start = _rendered?.Document.ContentStart.GetCharacterRect(LogicalDirection.Forward) ?? Rect.Empty;
        if (rect.IsEmpty || double.IsInfinity(rect.Top) || start.IsEmpty || double.IsInfinity(start.Top))
        {
            return null;
        }
        return rect.Top - start.Top;
    }

    private void ScrollToPendingAnchor()
    {
        var anchor = _pendingAnchor;
        if (anchor is null || _rendered is null)
        {
            return;
        }
        HookScroller();
        var heading = _rendered.Headings.FirstOrDefault(h => h.Anchor == anchor);
        if (heading.Block is null)
        {
            if (!_rendering)
            {
                _pendingAnchor = null; // not on this page
            }
            return; // still rendering: tried again when the page is complete
        }
        _pendingAnchor = null;
        if (_scroller is null || HeadingTop(heading.Block) is null)
        {
            heading.Block.BringIntoView(); // laid out first, then measured below
        }
        Dispatcher.BeginInvoke(() =>
        {
            if (_scroller is not null && HeadingTop(heading.Block) is { } top)
            {
                ScrollSmoothly(Math.Clamp(top - 12, 0, _scroller.ScrollableHeight));
            }
            Flash(heading.Block);
            _vm?.SetActiveAnchor(anchor);
        }, System.Windows.Threading.DispatcherPriority.Background);
    }

    private EventHandler? _scrollAnimation;

    /// <summary>Scrolls to <paramref name="offset"/> with a short ease-out (at once when Motion is off).</summary>
    private void ScrollSmoothly(double offset)
    {
        if (_scroller is not { } scroller)
        {
            return;
        }
        if (_scrollAnimation is not null)
        {
            System.Windows.Media.CompositionTarget.Rendering -= _scrollAnimation;
            _scrollAnimation = null;
        }
        var from = scroller.VerticalOffset;
        if (_vm?.Workspace.Main.ReduceMotion == true || Math.Abs(offset - from) < 1)
        {
            scroller.ScrollToVerticalOffset(offset);
            return;
        }
        var clock = System.Diagnostics.Stopwatch.StartNew();
        var duration = Math.Clamp(Math.Abs(offset - from) / 6, 220, 420); // ms: longer jumps take a little longer
        _scrollAnimation = (_, _) =>
        {
            var t = Math.Min(1, clock.ElapsedMilliseconds / duration);
            var eased = 1 - Math.Pow(1 - t, 3);
            scroller.ScrollToVerticalOffset(from + (offset - from) * eased);
            if (t >= 1 && _scrollAnimation is { } done)
            {
                System.Windows.Media.CompositionTarget.Rendering -= done;
                _scrollAnimation = null;
            }
        };
        System.Windows.Media.CompositionTarget.Rendering += _scrollAnimation;
    }

    /// <summary>Highlights the heading just jumped to for a moment, so the eye finds it.</summary>
    private void Flash(Block block)
    {
        if (TryFindResource("Brush.AccentSoft") is not SolidColorBrush accent)
        {
            return;
        }
        var brush = new SolidColorBrush(accent.Color);
        block.Background = brush;
        if (_vm?.Workspace.Main.ReduceMotion == true)
        {
            var timer = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromSeconds(1.2) };
            timer.Tick += (_, _) => { timer.Stop(); block.Background = null; };
            timer.Start();
            return;
        }
        var fade = new System.Windows.Media.Animation.DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(900)) { BeginTime = TimeSpan.FromMilliseconds(700) };
        fade.Completed += (_, _) => block.Background = null;
        brush.BeginAnimation(Brush.OpacityProperty, fade);
    }

    /// <summary>
    /// Room after the last line, so that a heading near the end of a page can still be scrolled to the top when it is
    /// chosen under "On this page" — only for a page longer than the view: a page that fits has nothing to scroll, and
    /// the room alone would give it a scroll bar.
    /// </summary>
    private void FitEndSpace()
    {
        if (_rendered is null || Viewer.ActualHeight <= 0)
        {
            return;
        }
        HookScroller();
        var bottom = _rendered.Document.PagePadding.Bottom;
        // The page's own height, without the room added before.
        var page = _scroller is null ? double.MaxValue : _scroller.ExtentHeight - bottom;
        var fits = _scroller is not null && _scroller.ViewportHeight > 0 && page <= _scroller.ViewportHeight + 1;
        var room = fits ? 0 : Math.Max(0, Viewer.ActualHeight - 140);
        if (Math.Abs(room - bottom) > 0.5)
        {
            _rendered.Document.PagePadding = new Thickness(0, 4, 18, room);
        }
    }

    /// <summary>Copy ▾ and Export ▾ open their menu under the button.</summary>
    private void OnMenuButtonClick(object sender, RoutedEventArgs e)
    {
        if (sender is FrameworkElement button && button.ContextMenu is { } menu)
        {
            menu.PlacementTarget = button;
            menu.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
            menu.DataContext = DataContext;
            menu.IsOpen = true;
        }
    }

    private static T? FindChild<T>(DependencyObject parent) where T : DependencyObject
    {
        for (var i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
        {
            var child = VisualTreeHelper.GetChild(parent, i);
            if (child is T match)
            {
                return match;
            }
            if (FindChild<T>(child) is { } nested)
            {
                return nested;
            }
        }
        return null;
    }
}
