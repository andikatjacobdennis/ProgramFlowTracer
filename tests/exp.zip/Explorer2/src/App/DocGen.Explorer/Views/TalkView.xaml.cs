using System.Windows;
using System.Windows.Controls;

namespace DocGen.Explorer.Views;

/// <summary>Talk: personas on the left, the conversation (the same pane as Ask) on the right; on a narrow window the list folds away (the switcher stays).</summary>
public partial class TalkView : UserControl
{
    public TalkView()
    {
        InitializeComponent();
        SizeChanged += (_, _) =>
        {
            var narrow = ActualWidth < 820;
            PersonaColumn.Width = narrow ? new GridLength(0) : new GridLength(300);
            PersonaPanel.Visibility = narrow ? Visibility.Collapsed : Visibility.Visible;
        };
    }
}
