using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using DocGen.Explorer.Infrastructure;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Views;

/// <summary>
/// The Learning host on screen. The bubble pops in with each new line and the face reacts: a nod for a right answer, a
/// small shake for a wrong one, a hop for a streak or a pass, a slump for a miss. Narrow, the bubble sits beside the face
/// instead of over it. All of it stands still with motion reduced.
/// </summary>
public partial class LearningHost : UserControl
{
    public static readonly DependencyProperty IsCompactProperty = DependencyProperty.Register(nameof(IsCompact), typeof(bool), typeof(LearningHost),
        new PropertyMetadata(false, (d, _) => ((LearningHost)d).Arrange()));

    private readonly TranslateTransform _move = new();
    private readonly RotateTransform _tilt = new();
    private readonly ScaleTransform _scale = new(1, 1);
    private LearningCoachViewModel? _coach;

    public LearningHost()
    {
        InitializeComponent();
        FaceHolder.RenderTransformOrigin = new Point(0.5, 0.9);
        FaceHolder.RenderTransform = new TransformGroup { Children = { _scale, _tilt, _move } };
        DataContextChanged += (_, _) => Attach();
        Loaded += (_, _) => Attach();
        Unloaded += (_, _) => Detach();
    }

    /// <summary>Bubble beside the face (a narrow page) rather than over it.</summary>
    public bool IsCompact { get => (bool)GetValue(IsCompactProperty); set => SetValue(IsCompactProperty, value); }

    private void Attach()
    {
        Detach();
        if (IsLoaded && DataContext is LearningCoachViewModel coach)
        {
            _coach = coach;
            coach.Reacted += OnReacted;
            coach.PropertyChanged += OnCoachChanged;
        }
    }

    private void Detach()
    {
        if (_coach is not null)
        {
            _coach.Reacted -= OnReacted;
            _coach.PropertyChanged -= OnCoachChanged;
            _coach = null;
        }
        Still();
    }

    private void Arrange()
    {
        if (IsCompact)
        {
            // Face on the left over both rows; the bubble beside it (a fixed height, so a longer line does not push the
            // quiz down), and who it is under the bubble.
            BubbleRow.Height = new GridLength(58);
            FaceColumn.Width = GridLength.Auto;
            BubbleColumn.Width = new GridLength(1, GridUnitType.Star);
            FaceHolder.Width = FaceHolder.Height = 72;
            FaceHolder.CornerRadius = new CornerRadius(36);
            FaceHolder.Margin = new Thickness(0);
            FaceHolder.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetRow(FaceHolder, 0);
            Grid.SetRowSpan(FaceHolder, 2);
            Grid.SetColumn(Bubble, 1);
            Bubble.HorizontalAlignment = HorizontalAlignment.Left;
            Bubble.VerticalAlignment = VerticalAlignment.Center;
            Bubble.Margin = new Thickness(6, 4, 0, 0);
            Bubble.RenderTransformOrigin = new Point(0, 0.5);
            DockPanel.SetDock(Tail, Dock.Left);
            Tail.Data = Geometry.Parse("M12,0 L0,8 L12,17");
            Tail.Margin = new Thickness(0, 0, -1.6, 0);
            Tail.VerticalAlignment = VerticalAlignment.Center;
            BubbleBox.MaxWidth = 460;
            Grid.SetRow(Who, 1);
            Grid.SetColumn(Who, 1);
            Who.HorizontalAlignment = HorizontalAlignment.Left;
            Who.Margin = new Thickness(22, 2, 0, 0);
            Who.Orientation = Orientation.Horizontal;
        }
        else
        {
            BubbleRow.Height = new GridLength(112);
            FaceColumn.Width = new GridLength(1, GridUnitType.Star);
            BubbleColumn.Width = new GridLength(0);
            FaceHolder.Width = FaceHolder.Height = 96;
            FaceHolder.CornerRadius = new CornerRadius(48);
            FaceHolder.VerticalAlignment = VerticalAlignment.Stretch;
            FaceHolder.Margin = new Thickness(0, 6, 0, 0);
            Grid.SetRow(FaceHolder, 1);
            Grid.SetRowSpan(FaceHolder, 1);
            Grid.SetColumn(Bubble, 0);
            Bubble.HorizontalAlignment = HorizontalAlignment.Center;
            Bubble.VerticalAlignment = VerticalAlignment.Bottom;
            Bubble.Margin = new Thickness(0);
            Bubble.RenderTransformOrigin = new Point(0.5, 1);
            DockPanel.SetDock(Tail, Dock.Bottom);
            Tail.Data = Geometry.Parse("M0,0 L8,12 L17,0");
            Tail.Margin = new Thickness(0, -1.6, 0, 0);
            Tail.VerticalAlignment = VerticalAlignment.Top;
            BubbleBox.MaxWidth = 210;
            Grid.SetRow(Who, 2);
            Grid.SetColumn(Who, 0);
            Who.HorizontalAlignment = HorizontalAlignment.Center;
            Who.Margin = new Thickness(0, 8, 0, 0);
            Who.Orientation = Orientation.Vertical;
        }
    }

    private void OnCoachChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName != nameof(LearningCoachViewModel.Line) || Motion.Reduced || !IsVisible)
        {
            return;
        }
        // A new line: the bubble pops in from its tail.
        var pop = new DoubleAnimation(0.8, 1, TimeSpan.FromMilliseconds(240)) { EasingFunction = new BackEase { Amplitude = 0.45, EasingMode = EasingMode.EaseOut }, FillBehavior = FillBehavior.Stop };
        BubbleScale.BeginAnimation(ScaleTransform.ScaleXProperty, pop);
        BubbleScale.BeginAnimation(ScaleTransform.ScaleYProperty, pop);
        Bubble.BeginAnimation(OpacityProperty, new DoubleAnimation(0.3, 1, TimeSpan.FromMilliseconds(180)) { FillBehavior = FillBehavior.Stop });
    }

    private void OnReacted(object? sender, string reaction)
    {
        if (Motion.Reduced || !IsVisible)
        {
            return;
        }
        Still();
        switch (reaction)
        {
            case "nod": // a happy nod: down-up twice
                _move.BeginAnimation(TranslateTransform.YProperty, Motion.Keys(560, (0, 0), (0.2, 5), (0.4, -6), (0.6, 3), (0.8, -2), (1, 0)));
                _tilt.BeginAnimation(RotateTransform.AngleProperty, Motion.Keys(560, (0, 0), (0.25, -3), (0.6, 2), (1, 0)));
                break;
            case "shake": // a small "no" of the head
                _move.BeginAnimation(TranslateTransform.XProperty, Motion.Keys(460, (0, 0), (0.15, -5), (0.35, 5), (0.55, -4), (0.75, 2), (1, 0)));
                _tilt.BeginAnimation(RotateTransform.AngleProperty, Motion.Keys(460, (0, 0), (0.15, -4), (0.35, 4), (0.55, -3), (1, 0)));
                break;
            case "cheer": // a hop with a wiggle
                _move.BeginAnimation(TranslateTransform.YProperty, Motion.Keys(720, (0, 0), (0.12, 4), (0.35, -18), (0.6, 0), (0.75, -6), (1, 0)));
                _tilt.BeginAnimation(RotateTransform.AngleProperty, Motion.Keys(720, (0, 0), (0.3, -8), (0.55, 8), (0.8, -3), (1, 0)));
                var grow = Motion.Keys(720, (0, 1), (0.35, 1.08), (1, 1));
                _scale.BeginAnimation(ScaleTransform.ScaleXProperty, grow);
                _scale.BeginAnimation(ScaleTransform.ScaleYProperty, grow);
                break;
            case "slump": // a slow, sympathetic droop
                _move.BeginAnimation(TranslateTransform.YProperty, Motion.Keys(1000, (0, 0), (0.35, 5), (0.75, 5), (1, 0)));
                _tilt.BeginAnimation(RotateTransform.AngleProperty, Motion.Keys(1000, (0, 0), (0.35, -6), (0.75, -6), (1, 0)));
                break;
            case "hello": // a friendly tilt
                _tilt.BeginAnimation(RotateTransform.AngleProperty, Motion.Keys(600, (0, 0), (0.3, -7), (0.65, 5), (1, 0)));
                break;
        }
    }

    /// <summary>Every reaction let go of, the face back at rest.</summary>
    private void Still()
    {
        _move.BeginAnimation(TranslateTransform.XProperty, null);
        _move.BeginAnimation(TranslateTransform.YProperty, null);
        _tilt.BeginAnimation(RotateTransform.AngleProperty, null);
        _scale.BeginAnimation(ScaleTransform.ScaleXProperty, null);
        _scale.BeginAnimation(ScaleTransform.ScaleYProperty, null);
    }
}
