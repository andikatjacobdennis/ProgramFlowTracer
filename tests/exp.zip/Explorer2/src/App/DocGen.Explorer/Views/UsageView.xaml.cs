using System.Windows.Controls;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Views;

public partial class UsageView : UserControl
{
    public UsageView()
    {
        InitializeComponent();
        DataContextChanged += (_, e) =>
        {
            if (e.OldValue is UsageViewModel old)
            {
                old.ScrollToCalls -= ShowCalls;
            }
            if (e.NewValue is UsageViewModel now)
            {
                now.ScrollToCalls += ShowCalls;
            }
        };
    }

    // "Show them" on Failed calls: the table, brought into view.
    private void ShowCalls() => Dispatcher.BeginInvoke(() => CallsHeading.BringIntoView(), System.Windows.Threading.DispatcherPriority.Loaded);
}
