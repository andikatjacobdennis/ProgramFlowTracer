using System.Windows.Controls;

namespace DocGen.Explorer.Views;

public partial class IndexingView : UserControl
{
    public IndexingView() => InitializeComponent();
}
