using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Views;

/// <summary>Help: each new page starts at its top, and the search box has the keyboard when Help opens.</summary>
public partial class HelpView : UserControl
{
    private HelpViewModel? _vm;

    public static readonly DependencyProperty CardWidthProperty = DependencyProperty.Register(nameof(CardWidth), typeof(double), typeof(HelpView), new PropertyMetadata(280.0));

    /// <summary>The width of a topic card: the row shared by as many cards as fit (at least 260 each, five at most).</summary>
    public double CardWidth
    {
        get => (double)GetValue(CardWidthProperty);
        set => SetValue(CardWidthProperty, value);
    }

    private void FitCards()
    {
        const double gap = 16;
        var width = TopicCards.ActualWidth;
        if (width <= 0)
        {
            return;
        }
        // Every card carries its gap on its right (the last one too), so a row is columns × (card + gap).
        var columns = Math.Clamp((int)(width / (260 + gap)), 1, 5);
        CardWidth = Math.Floor(width / columns - gap - 1);
    }

    public HelpView()
    {
        InitializeComponent();
        TopicCards.SizeChanged += (_, _) => FitCards();
        DataContextChanged += (_, _) =>
        {
            if (_vm is not null)
            {
                _vm.Navigated -= OnNavigated;
            }
            _vm = DataContext as HelpViewModel;
            if (_vm is not null)
            {
                _vm.Navigated += OnNavigated;
            }
        };
        Loaded += (_, _) => Dispatcher.BeginInvoke(() => Keyboard.Focus(SearchBox), System.Windows.Threading.DispatcherPriority.Input);
        Unloaded += (_, _) =>
        {
            if (_vm is not null)
            {
                _vm.Navigated -= OnNavigated;
            }
        };
    }

    private void OnNavigated(object? sender, EventArgs e) => Scroller.ScrollToTop();
}
