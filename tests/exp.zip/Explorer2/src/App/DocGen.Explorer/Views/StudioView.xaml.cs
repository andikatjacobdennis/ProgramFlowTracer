using System.Windows.Controls;

namespace DocGen.Explorer.Views;

public partial class StudioView : UserControl
{
    public StudioView() => InitializeComponent();
}
