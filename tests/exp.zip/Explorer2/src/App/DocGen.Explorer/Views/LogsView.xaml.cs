using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Views;

public partial class LogsView : UserControl
{
    private LogsViewModel? _vm;
    private readonly Dictionary<string, GridViewColumn> _columns;

    public LogsView()
    {
        InitializeComponent();
        _columns = new Dictionary<string, GridViewColumn>
        {
            ["time"] = TimeColumn,
            ["level"] = LevelColumn,
            ["source"] = SourceColumn,
            ["message"] = MessageColumn,
            ["exception"] = ExceptionColumn,
            ["file"] = FileColumn,
        };
        DataContextChanged += (_, e) =>
        {
            if (_vm is not null)
            {
                _vm.ColumnsChangedEvent -= OnColumnsChanged;
            }
            _vm = e.NewValue as LogsViewModel;
            if (_vm is not null)
            {
                _vm.ColumnsChangedEvent += OnColumnsChanged;
                OnColumnsChanged(null, EventArgs.Empty);
            }
        };
        InputBindings.Add(new KeyBinding(new Infrastructure.RelayCommand(() => _vm?.RefreshCommand.Execute(null)), Key.F5, ModifierKeys.None));
    }

    /// <summary>Shows the ticked columns, in their order, and leaves out the others.</summary>
    private void OnColumnsChanged(object? sender, EventArgs e)
    {
        if (_vm is null)
        {
            return;
        }
        Grid.Columns.Clear();
        foreach (var column in _vm.Columns.Where(c => c.IsVisible))
        {
            Grid.Columns.Add(_columns[column.Key]);
        }
    }

    private void OnColumnsClick(object sender, RoutedEventArgs e) => ColumnsPopup.IsOpen = !ColumnsPopup.IsOpen;
}
