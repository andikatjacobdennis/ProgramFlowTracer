using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using DocGen.Explorer.Infrastructure;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Views;

public partial class LearningView : UserControl
{
    /// <summary>Below this width the host sits above the quiz or cards instead of beside them.</summary>
    private const double HostBesideWidth = 900;

    private LearningCoachViewModel? _coach;
    private bool _flipping;

    public LearningView()
    {
        InitializeComponent();
        SizeChanged += (_, _) =>
        {
            KindsGrid.Columns = ActualWidth > 760 ? 2 : 1;
            ArrangeHosts();
        };
        DataContextChanged += (_, _) => Attach();
        Loaded += (_, _) => Attach();
        Unloaded += (_, _) => Detach();
    }

    private void Attach()
    {
        Detach();
        if (IsLoaded && DataContext is LearningViewModel vm)
        {
            _coach = vm.Coach;
            _coach.Reacted += OnReacted;
        }
    }

    private void Detach()
    {
        if (_coach is not null)
        {
            _coach.Reacted -= OnReacted;
            _coach = null;
        }
        // A turn cut short by leaving the page must not leave the card squeezed flat.
        CardFlip.BeginAnimation(ScaleTransform.ScaleXProperty, null);
        _flipping = false;
    }

    /// <summary>A passed quiz gets the confetti, once the result is laid out (so the burst knows its size).</summary>
    private void OnReacted(object? sender, string reaction)
    {
        if (reaction == "cheer" && DataContext is LearningViewModel { Mode: "quiz", Quiz: { Phase: "result", Passed: true } })
        {
            Dispatcher.BeginInvoke(DispatcherPriority.Loaded, () => Confetti.Burst());
        }
    }

    private void ArrangeHosts()
    {
        var beside = ActualWidth >= HostBesideWidth;
        Arrange(QuizHost, beside);
        Arrange(DeckHost, beside);
    }

    private static void Arrange(LearningHost host, bool beside)
    {
        host.IsCompact = !beside;
        // Beside: its own column after the content. Above: the content's column, in the row over it.
        Grid.SetRow(host, beside ? 1 : 0);
        Grid.SetColumn(host, beside ? 2 : 0);
        host.Width = beside ? 214 : double.NaN;
        host.Margin = beside ? new Thickness(0, 30, 0, 0) : new Thickness(0, 0, 0, 14);
    }

    private void OnItemMenu(object sender, RoutedEventArgs e)
    {
        if (sender is Button { ContextMenu: { } menu } button)
        {
            menu.PlacementTarget = button;
            menu.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
            menu.DataContext = button.DataContext;
            // The detail-view menu reaches the Learning commands through the button's Tag (the view).
            if (button.Tag is not null)
            {
                button.Tag = this;
            }
            menu.IsOpen = true;
        }
    }

    /// <summary>Turns the card over: squeezed to its edge, the other side swapped in, opened out again.</summary>
    private void OnCardClick(object sender, MouseButtonEventArgs e)
    {
        if ((DataContext as LearningViewModel)?.Deck is not { } deck || !deck.FlipCommand.CanExecute(null) || _flipping)
        {
            return;
        }
        if (Motion.Reduced)
        {
            deck.FlipCommand.Execute(null);
            return;
        }
        _flipping = true;
        var close = new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(130)) { EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseIn } };
        close.Completed += (_, _) =>
        {
            try
            {
                if (deck.FlipCommand.CanExecute(null))
                {
                    deck.FlipCommand.Execute(null);
                }
            }
            finally
            {
                var open = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(170)) { EasingFunction = new QuadraticEase { EasingMode = EasingMode.EaseOut }, FillBehavior = FillBehavior.Stop };
                open.Completed += (_, _) => _flipping = false;
                CardFlip.BeginAnimation(ScaleTransform.ScaleXProperty, open);
            }
        };
        CardFlip.BeginAnimation(ScaleTransform.ScaleXProperty, close);
    }
}
