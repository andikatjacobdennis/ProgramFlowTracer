using System.Windows;
using System.Windows.Controls;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Views;

public partial class GraphView : UserControl
{
    private GraphViewModel? _vm;
    private bool _fitPending = true;

    public GraphView()
    {
        InitializeComponent();
        DataContextChanged += (_, e) => Attach(e.NewValue as GraphViewModel);
        Loaded += (_, _) => Attach(DataContext as GraphViewModel);
        Canvas.NodeSelected += (_, node) => _vm?.OnCanvasSelected(node);
        Canvas.NodeActivated += (_, node) => _vm?.Open(node);
        Canvas.SizeChanged += (_, _) =>
        {
            if (_fitPending && Canvas.ActualWidth > 0 && Canvas.Graph.Nodes.Count > 0)
            {
                _fitPending = false;
                Canvas.FitView();
            }
        };
    }

    private void Attach(GraphViewModel? vm)
    {
        if (ReferenceEquals(vm, _vm))
        {
            return;
        }
        if (_vm is not null)
        {
            _vm.GraphReady -= OnGraphReady;
            _vm.FitRequested -= OnFit;
            _vm.SelectRequested -= OnSelect;
            _vm.CurrentPositions = null;
        }
        _vm = vm;
        if (vm is null)
        {
            return;
        }
        vm.GraphReady += OnGraphReady;
        vm.FitRequested += OnFit;
        vm.SelectRequested += OnSelect;
        vm.CurrentPositions = () => Canvas.Positions;
        _fitPending = true;
        vm.Rebuild();
    }

    private void OnGraphReady(object? sender, (KnowledgeGraph Graph, IReadOnlyDictionary<string, NodePosition> Positions) e)
    {
        Canvas.SetGraph(e.Graph, e.Positions);
        if (Canvas.ActualWidth > 0)
        {
            Canvas.FitView();
            _fitPending = false;
        }
        else
        {
            _fitPending = true;
        }
    }

    private void OnFit(object? sender, EventArgs e)
    {
        Canvas.FitView();
        Canvas.Focus();
    }

    private void OnSelect(object? sender, string id)
    {
        Canvas.Select(id, center: true);
        Canvas.Focus();
    }


}
