using System.Windows;
using DocGen.Explorer.Infrastructure;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Views;

/// <summary>Everything recorded about one model call (from the Usage page's table).</summary>
public partial class UsageDetailsWindow : Window
{
    public UsageDetailsWindow(UsageDetailsViewModel details)
    {
        InitializeComponent();
        DataContext = details;
        SourceInitialized += (_, _) => ThemeManager.ApplyTitleBar(this);
    }

    /// <summary>Shows the call's details as a modal window over <paramref name="owner"/>.</summary>
    public static void Show(UsageDetailsViewModel details, Window? owner)
    {
        var window = new UsageDetailsWindow(details) { Owner = owner };
        window.ShowDialog();
    }

    private void OnClose(object sender, RoutedEventArgs e) => Close();
}
