using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Windows.Media;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>A tick box of the calls table's filters: one feature or model, with its colour and how many calls it has.</summary>
public sealed class UsageFilterChoice(string label, Brush brush, int count, Action changed) : ObservableObject
{
    private bool _isChecked = true;

    public string Label { get; } = label;
    public Brush Brush { get; } = brush;
    public int Count { get; } = count;

    public bool IsChecked
    {
        get => _isChecked;
        set
        {
            if (Set(ref _isChecked, value))
            {
                changed();
            }
        }
    }

    internal void SetQuietly(bool value)
    {
        _isChecked = value;
        Notify(nameof(IsChecked));
    }
}

/// <summary>A page number under the calls table.</summary>
public sealed record UsagePageButton(int Number, bool IsCurrent, ICommand Command);

/// <summary>A column heading of the calls table: click to sort by it, again to reverse.</summary>
public sealed class UsageColumn(string key, string label, UsageCallsTable owner) : ObservableObject
{
    public string Key { get; } = key;
    public string Label { get; } = label;
    public string Text => owner.SortKey == Key ? $"{Label} {(owner.SortDescending ? "↓" : "↑")}" : Label;
    public ICommand SortCommand { get; } = new RelayCommand(() => owner.SortBy(key));
    internal void Refresh() => Notify(nameof(Text));
}

/// <summary>
/// The calls table of Token usage: every call of the range, searched, filtered by feature and model (tick boxes), sorted by
/// any column, and shown a page at a time.
/// </summary>
public sealed class UsageCallsTable : ObservableObject
{
    public static readonly IReadOnlyList<int> PageSizes = [25, 50, 100];

    private List<UsageRowViewModel> _all = [];
    private List<UsageRowViewModel> _matching = [];
    private string _search = "";
    private bool _failedOnly;
    private int _pageSize = 25;
    private int _page;
    private bool _quiet;

    public UsageCallsTable()
    {
        Columns =
        [
            new("when", "When", this), new("feature", "Feature", this), new("purpose", "What for", this), new("model", "Model", this),
            new("in", "In", this), new("out", "Out", this), new("time", "Time", this), new("cost", "Cost", this),
        ];
        // Round in a circle: Next on the last page goes to the first, Previous on the first to the last.
        PreviousCommand = new RelayCommand(() => Page = (Page - 1 + PageCount) % PageCount, () => PageCount > 1);
        NextCommand = new RelayCommand(() => Page = (Page + 1) % PageCount, () => PageCount > 1);
        FirstCommand = new RelayCommand(() => Page = 0, () => Page > 0);
        LastCommand = new RelayCommand(() => Page = PageCount - 1, () => Page < PageCount - 1);
        ClearFiltersCommand = new RelayCommand(ClearFilters, () => IsFiltered);
        AllFeaturesCommand = new RelayCommand(() => SetAll(Features, true));
        NoFeaturesCommand = new RelayCommand(() => SetAll(Features, false));
        AllModelsCommand = new RelayCommand(() => SetAll(Models, true));
        NoModelsCommand = new RelayCommand(() => SetAll(Models, false));
    }

    public IReadOnlyList<UsageColumn> Columns { get; }
    public ObservableCollection<UsageRowViewModel> Rows { get; } = [];

    /// <summary>At most five page numbers, around the current page.</summary>
    public ObservableCollection<UsagePageButton> PageNumbers { get; } = [];
    public ObservableCollection<UsageFilterChoice> Features { get; } = [];
    public ObservableCollection<UsageFilterChoice> Models { get; } = [];
    public IReadOnlyList<int> PageSizeChoices => PageSizes;

    public ICommand PreviousCommand { get; }
    public ICommand NextCommand { get; }
    public ICommand FirstCommand { get; }
    public ICommand LastCommand { get; }
    public ICommand ClearFiltersCommand { get; }
    public ICommand AllFeaturesCommand { get; }
    public ICommand NoFeaturesCommand { get; }
    public ICommand AllModelsCommand { get; }
    public ICommand NoModelsCommand { get; }

    private bool _featureMenuOpen;
    private bool _modelMenuOpen;

    /// <summary>The Feature and Model filter lists (tick boxes in a drop-down).</summary>
    public bool FeatureMenuOpen { get => _featureMenuOpen; set => Set(ref _featureMenuOpen, value); }
    public bool ModelMenuOpen { get => _modelMenuOpen; set => Set(ref _modelMenuOpen, value); }
    public ICommand ToggleFeatureMenuCommand => new RelayCommand(() => FeatureMenuOpen = !FeatureMenuOpen);
    public ICommand ToggleModelMenuCommand => new RelayCommand(() => ModelMenuOpen = !ModelMenuOpen);

    public string SortKey { get; private set; } = "when";
    public bool SortDescending { get; private set; } = true;

    public string Search
    {
        get => _search;
        set
        {
            if (Set(ref _search, value ?? ""))
            {
                Apply(resetPage: true);
            }
        }
    }

    public bool FailedOnly
    {
        get => _failedOnly;
        set
        {
            if (Set(ref _failedOnly, value))
            {
                Apply(resetPage: true);
            }
        }
    }

    public int PageSize
    {
        get => _pageSize;
        set
        {
            if (value > 0 && Set(ref _pageSize, value))
            {
                Apply(resetPage: true);
            }
        }
    }

    public int Page
    {
        get => _page;
        set
        {
            var page = Math.Clamp(value, 0, Math.Max(0, PageCount - 1));
            if (Set(ref _page, page))
            {
                ShowPage();
            }
        }
    }

    public int PageCount => Math.Max(1, (int)Math.Ceiling(_matching.Count / (double)PageSize));
    public bool HasPages => PageCount > 1;
    public bool HasRows => Rows.Count > 0;
    public bool NoMatches => _all.Count > 0 && _matching.Count == 0;
    public bool IsFiltered => Search.Length > 0 || FailedOnly || Features.Any(f => !f.IsChecked) || Models.Any(m => !m.IsChecked);

    public string FeatureFilterText => FilterText("All features", Features);
    public string ModelFilterText => FilterText("All models", Models);

    /// <summary>"26–50 of 312 calls" (and how many the filters hide).</summary>
    public string RangeText
    {
        get
        {
            if (_matching.Count == 0)
            {
                return _all.Count == 0 ? "" : $"No calls match (of {_all.Count:N0})";
            }
            var first = Page * PageSize + 1;
            var last = Math.Min(_matching.Count, first + PageSize - 1);
            return $"{first:N0}–{last:N0} of {_matching.Count:N0} call{(_matching.Count == 1 ? "" : "s")}"
                + (_matching.Count < _all.Count ? $" (filtered from {_all.Count:N0})" : "");
        }
    }

    public string PageText => $"Page {Page + 1} of {PageCount}";

    /// <summary>The range's calls; the filters keep what was unticked when the same features and models come back.</summary>
    public void Load(IEnumerable<UsageRowViewModel> rows, Func<string, Brush> featureBrush, Func<string, Brush> modelBrush)
    {
        var hiddenFeatures = Features.Where(f => !f.IsChecked).Select(f => f.Label).ToHashSet(StringComparer.Ordinal);
        var hiddenModels = Models.Where(m => !m.IsChecked).Select(m => m.Label).ToHashSet(StringComparer.Ordinal);
        _all = rows.ToList();
        _quiet = true;
        Features.Clear();
        foreach (var group in _all.GroupBy(r => r.Feature).OrderByDescending(g => g.Count()).ThenBy(g => g.Key, StringComparer.Ordinal))
        {
            var choice = new UsageFilterChoice(group.Key, featureBrush(group.Key), group.Count(), () => Apply(resetPage: true));
            choice.SetQuietly(!hiddenFeatures.Contains(group.Key));
            Features.Add(choice);
        }
        Models.Clear();
        foreach (var group in _all.GroupBy(r => r.ModelId).OrderByDescending(g => g.Count()).ThenBy(g => g.Key, StringComparer.Ordinal))
        {
            var choice = new UsageFilterChoice(group.Key, modelBrush(group.Key), group.Count(), () => Apply(resetPage: true));
            choice.SetQuietly(!hiddenModels.Contains(group.Key));
            Models.Add(choice);
        }
        _quiet = false;
        Apply(resetPage: false);
    }

    public void SortBy(string key)
    {
        // A new column starts with the biggest or latest first for numbers and time, A to Z for text.
        SortDescending = SortKey == key ? !SortDescending : key is "when" or "in" or "out" or "time" or "cost";
        SortKey = key;
        foreach (var column in Columns)
        {
            column.Refresh();
        }
        Apply(resetPage: true);
    }

    private void Apply(bool resetPage)
    {
        if (_quiet)
        {
            return;
        }
        var features = Features.Where(f => f.IsChecked).Select(f => f.Label).ToHashSet(StringComparer.Ordinal);
        var models = Models.Where(m => m.IsChecked).Select(m => m.Label).ToHashSet(StringComparer.Ordinal);
        var words = Search.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        IEnumerable<UsageRowViewModel> rows = _all.Where(r => features.Contains(r.Feature) && models.Contains(r.ModelId) && (!FailedOnly || r.Failed)
            && words.All(w => r.Feature.Contains(w, StringComparison.CurrentCultureIgnoreCase) || r.ModelId.Contains(w, StringComparison.CurrentCultureIgnoreCase)
                              || r.Purpose.Contains(w, StringComparison.CurrentCultureIgnoreCase) || r.WhatFor.Contains(w, StringComparison.CurrentCultureIgnoreCase)));
        rows = SortKey switch
        {
            "feature" => Order(rows, r => r.Feature),
            "purpose" => Order(rows, r => r.Purpose),
            "model" => Order(rows, r => r.ModelId),
            "in" => Order(rows, r => r.InputTokens),
            "out" => Order(rows, r => r.OutputTokens),
            "time" => Order(rows, r => r.DurationMs),
            "cost" => Order(rows, r => r.Cost),
            _ => Order(rows, r => r.At),
        };
        _matching = rows.ToList();
        if (resetPage)
        {
            _page = 0;
        }
        _page = Math.Clamp(_page, 0, PageCount - 1);
        Notify(nameof(Page), nameof(PageCount), nameof(HasPages), nameof(IsFiltered), nameof(NoMatches), nameof(FeatureFilterText), nameof(ModelFilterText));
        ShowPage();
    }

    private IEnumerable<UsageRowViewModel> Order<T>(IEnumerable<UsageRowViewModel> rows, Func<UsageRowViewModel, T> key)
    {
        // Ties keep the latest first, so equal rows do not jump around between sorts.
        var ordered = SortDescending ? rows.OrderByDescending(key) : rows.OrderBy(key);
        return ordered.ThenByDescending(r => r.At);
    }

    private void ShowPage()
    {
        Rows.Clear();
        foreach (var row in _matching.Skip(Page * PageSize).Take(PageSize))
        {
            Rows.Add(row);
        }
        PageNumbers.Clear();
        var first = Math.Clamp(Page - 2, 0, Math.Max(0, PageCount - 5));
        for (var number = first; number < Math.Min(PageCount, first + 5); number++)
        {
            var target = number;
            PageNumbers.Add(new UsagePageButton(number + 1, number == Page, new RelayCommand(() => Page = target)));
        }
        Notify(nameof(RangeText), nameof(PageText), nameof(HasRows));
        CommandManager.InvalidateRequerySuggested();
    }

    private void ClearFilters()
    {
        _quiet = true;
        _search = "";
        _failedOnly = false;
        foreach (var choice in Features.Concat(Models))
        {
            choice.SetQuietly(true);
        }
        _quiet = false;
        Notify(nameof(Search), nameof(FailedOnly));
        Apply(resetPage: true);
    }

    private void SetAll(IEnumerable<UsageFilterChoice> choices, bool value)
    {
        _quiet = true;
        foreach (var choice in choices)
        {
            choice.SetQuietly(value);
        }
        _quiet = false;
        Apply(resetPage: true);
    }

    private static string FilterText(string all, IReadOnlyCollection<UsageFilterChoice> choices)
    {
        var on = choices.Count(c => c.IsChecked);
        return on == choices.Count ? all : on == 0 ? "None" : on == 1 ? choices.First(c => c.IsChecked).Label : $"{on} of {choices.Count}";
    }
}
