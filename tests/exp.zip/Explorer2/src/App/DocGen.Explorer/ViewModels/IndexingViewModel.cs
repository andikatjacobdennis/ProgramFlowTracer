using System.Collections.ObjectModel;
using System.Windows.Input;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Search;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

public sealed class StageViewModel : ObservableObject
{
    private StageStatus _status;
    private string _detail = "";
    private long _durationMs;

    public string Name { get; init; } = "";

    public StageStatus Status
    {
        get => _status;
        set
        {
            if (Set(ref _status, value))
            {
                Notify(nameof(Glyph), nameof(StatusKey));
            }
        }
    }

    public string Detail
    {
        get => _detail;
        set => Set(ref _detail, value);
    }

    public long DurationMs
    {
        get => _durationMs;
        set
        {
            if (Set(ref _durationMs, value))
            {
                OnPropertyChanged(nameof(Duration));
            }
        }
    }

    public string Duration => DurationMs <= 0 ? "" : DurationMs < 1000 ? $"{DurationMs} ms" : $"{DurationMs / 1000.0:0.0} s";
    public string StatusKey => Status.ToString();
    public string Glyph => Status switch
    {
        StageStatus.Done => "✓",
        StageStatus.Running => "●",
        StageStatus.Failed => "✕",
        StageStatus.Skipped => "–",
        _ => "○",
    };
}

public sealed class CounterViewModel(string value, string label)
{
    public string Value { get; } = value;
    public string Label { get; } = label;
}

/// <summary>The Indexing page: actions, counters, the stage list with live progress, Confluence and configuration.</summary>
public sealed class IndexingViewModel : ObservableObject, IActivatable
{
    private readonly WorkspaceViewModel _workspace;
    private double _progress;
    private string _stateText = "";
    private string _stateDetail = "";
    private string _stateKey = "idle";
    private bool _isRunning;
    private string _newSpace = "";
    private string? _confluenceStatus;
    private DateTime _lastUiUpdate;

    public IndexingViewModel(WorkspaceViewModel workspace)
    {
        _workspace = workspace;
        RefreshCommand = new RelayCommand(() => Start(IndexMode.Incremental), () => !IsRunning);
        FullReindexCommand = new RelayCommand(() => Start(IndexMode.Full), () => !IsRunning);
        CancelCommand = new RelayCommand(() => workspace.Main.Engine.Indexing.Cancel(workspace.Record.Id), () => IsRunning);
        ClearCommand = new AsyncCommand(ClearAsync, () => !IsRunning);
        PullCommand = new AsyncCommand(PullAsync, () => !IsRunning && workspace.Record.Source == "git");
        AddSpaceCommand = new AsyncCommand(AddSpaceAsync, () => NewSpace.Trim().Length > 0);
        RemoveSpaceCommand = new AsyncCommand(async p =>
        {
            if (p is string url)
            {
                await workspace.Main.Engine.Confluence.RemoveSpaceAsync(workspace.Record.Id, url);
                await ReloadRecordAsync();
            }
        });
        SyncConfluenceCommand = new AsyncCommand(SyncConfluenceAsync, () => Spaces.Count > 0);
        OpenDataFolderCommand = new RelayCommand(() =>
        {
            var folder = workspace.Main.Engine.Store.RepositoryDirectory(workspace.Record.Id);
            Directory.CreateDirectory(folder);
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("explorer.exe", $"\"{folder}\"") { UseShellExecute = true });
        });
        foreach (var name in IndexStages.All)
        {
            Stages.Add(new StageViewModel { Name = name });
        }
        workspace.Main.Engine.Indexing.Progress += (_, e) =>
        {
            if (e.RepositoryId != workspace.Record.Id)
            {
                return;
            }
            // Throttle: a stage change always shows; otherwise at most ~20 updates a second.
            var now = DateTime.UtcNow;
            if ((now - _lastUiUpdate).TotalMilliseconds < 50 && e.Message is not ("Indexing complete" or "Indexing failed" or "Indexing cancelled"))
            {
                return;
            }
            _lastUiUpdate = now;
            var snapshot = e.Run.Stages.Select(s => (s.Name, s.Status, s.Detail, s.DurationMs)).ToList();
            var state = e.Run.State;
            var error = e.Run.Error;
            Ui.Post(() => Apply(snapshot, state, error, e.Message));
        };
    }

    public ICommand RefreshCommand { get; }
    public ICommand FullReindexCommand { get; }
    public ICommand CancelCommand { get; }
    public ICommand ClearCommand { get; }
    public ICommand PullCommand { get; }
    public ICommand AddSpaceCommand { get; }
    public ICommand RemoveSpaceCommand { get; }
    public ICommand SyncConfluenceCommand { get; }

    /// <summary>Settings → Confluence, where the sites and their sign-in are kept.</summary>
    public ICommand OpenConfluenceSettingsCommand => new RelayCommand(() =>
    {
        _workspace.Main.Navigate(Section.Settings);
        _workspace.Main.Settings.ShowPage(SettingsPages.Confluence);
    });
    public ICommand OpenDataFolderCommand { get; }

    public ObservableCollection<StageViewModel> Stages { get; } = [];
    public ObservableCollection<CounterViewModel> Counters { get; } = [];
    public ObservableCollection<string> Spaces { get; } = [];

    /// <summary>The spaces this repository searches, by name, with their site and what the last sync read from each.</summary>
    public ObservableCollection<ChosenSpace> ChosenSpaces { get; } = [];

    public string RepositoryPath => _workspace.Record.Source == "git" ? $"{_workspace.Record.GitUrl}  →  {_workspace.Record.Path}" : _workspace.Record.Path;
    public bool IsGit => _workspace.Record.Source == "git";

    public double Progress
    {
        get => _progress;
        private set => Set(ref _progress, value);
    }

    public string StateText
    {
        get => _stateText;
        private set => Set(ref _stateText, value);
    }

    public string StateDetail
    {
        get => _stateDetail;
        private set => Set(ref _stateDetail, value);
    }

    public string StateKey
    {
        get => _stateKey;
        private set => Set(ref _stateKey, value);
    }

    public bool IsRunning
    {
        get => _isRunning;
        private set
        {
            if (Set(ref _isRunning, value))
            {
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    public string NewSpace
    {
        get => _newSpace;
        set => Set(ref _newSpace, value);
    }

    public string? ConfluenceStatus
    {
        get => _confluenceStatus;
        private set => Set(ref _confluenceStatus, value);
    }

    public string ConfluenceIntro => Spaces.Count == 0
        ? "This repository is answered from its own files only. Add a Confluence space and it is searched too, each time a question is asked."
        : $"Questions are answered from the repository and {(Spaces.Count == 1 ? "one Confluence space" : $"{Spaces.Count} Confluence spaces")}. Sync fetches their pages and refreshes the index.";

    public string EmbeddingModel => HashingEmbedder.ModelName;
    public string VectorStoreName => VectorStore.Name;
    public string OutputFolder => Path.Combine(_workspace.Main.Engine.Store.RepositoryDirectory(_workspace.Record.Id), "pages");
    public string LastIndexed => _workspace.Record.LastIndexedAt is { } at ? at.ToString("yyyy-MM-dd HH:mm:ss") + " UTC" : "never";

    /// <summary>The spaces on the Confluence sites, ticked for this repository.</summary>
    public ConfluenceSpacePickerViewModel SpacePicker => _workspace.Main.SpacePicker;

    private void OnPickerChanged()
    {
        if (_workspace.Main.Workspace == _workspace)
        {
            _ = ReloadRecordAsync();
        }
    }

    // The spaces on the sites have loaded (their names): the chosen ones are shown by name.
    private void OnPickerLoaded(object? sender, System.ComponentModel.PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(ConfluenceSpacePickerViewModel.Summary) && _workspace.Main.Workspace == _workspace)
        {
            _ = DescribeSpacesAsync();
        }
    }

    public async Task ActivateAsync()
    {
        SpacePicker.SpacesChanged -= OnPickerChanged;
        SpacePicker.SpacesChanged += OnPickerChanged;
        SpacePicker.PropertyChanged -= OnPickerLoaded;
        SpacePicker.PropertyChanged += OnPickerLoaded;
        _ = SpacePicker.EnsureLoadedAsync();
        await ReloadRecordAsync();
        Refresh();
    }

    private async Task ReloadRecordAsync()
    {
        Spaces.Clear();
        if (await _workspace.Main.Engine.Repositories.GetAsync(_workspace.Record.Id) is { } record)
        {
            foreach (var space in record.ConfluenceSpaces)
            {
                Spaces.Add(space);
            }
        }
        Notify(nameof(ConfluenceIntro));
        CommandManager.InvalidateRequerySuggested();
        await DescribeSpacesAsync();
    }

    private async Task DescribeSpacesAsync()
    {
        var synced = await _workspace.Main.Engine.Confluence.GetAsync(_workspace.Record.Id);
        var described = Spaces.Select(url => ChosenSpace.Describe(url, SpacePicker.Choices, synced)).ToList();
        ChosenSpaces.Clear();
        foreach (var space in described)
        {
            ChosenSpaces.Add(space);
        }
    }

    public void Refresh()
    {
        var engine = _workspace.Main.Engine.Indexing;
        var run = engine.CurrentRun(_workspace.Record.Id) ?? _workspace.Index?.LastRun;
        if (run is null)
        {
            _ = LoadRunAsync();
        }
        else
        {
            Apply(run.Stages.Select(s => (s.Name, s.Status, s.Detail, s.DurationMs)).ToList(), run.State, run.Error, null);
        }
        BuildCounters();
        Notify(nameof(RepositoryPath), nameof(LastIndexed), nameof(IsGit), nameof(OutputFolder));
    }

    private async Task LoadRunAsync()
    {
        var run = await _workspace.Main.Engine.Indexing.LoadRunAsync(_workspace.Record.Id);
        if (run is not null)
        {
            Apply(run.Stages.Select(s => (s.Name, s.Status, s.Detail, s.DurationMs)).ToList(), run.State, run.Error, null);
        }
        else
        {
            foreach (var stage in Stages)
            {
                stage.Status = StageStatus.Pending;
                stage.Detail = "";
                stage.DurationMs = 0;
            }
            StateKey = "idle";
            StateText = "Not indexed";
            StateDetail = "Choose Full reindex to build the index.";
            Progress = 0;
            IsRunning = false;
        }
    }

    private void Apply(List<(string Name, StageStatus Status, string Detail, long DurationMs)> stages, RunState state, string? error, string? message)
    {
        foreach (var (name, status, detail, duration) in stages)
        {
            var stage = Stages.FirstOrDefault(s => s.Name == name);
            if (stage is null)
            {
                continue;
            }
            stage.Status = status;
            stage.Detail = detail;
            stage.DurationMs = duration;
        }
        var done = stages.Count(s => s.Status is StageStatus.Done or StageStatus.Skipped);
        Progress = stages.Count == 0 ? 0 : 100.0 * done / stages.Count;
        IsRunning = state == RunState.Running;
        (StateKey, StateText, StateDetail) = state switch
        {
            RunState.Running => ("busy", "Indexing", stages.FirstOrDefault(s => s.Status == StageStatus.Running).Name ?? message ?? ""),
            RunState.Completed => ("ready", "Ready", "Indexing complete"),
            RunState.Cancelled => ("idle", "Cancelled", "The previous index is still in use."),
            RunState.Failed => ("failed", "Failed", error ?? "The run failed."),
            _ => ("idle", "", ""),
        };
        if (state != RunState.Running)
        {
            BuildCounters();
        }
    }

    private void BuildCounters()
    {
        var c = _workspace.Record.Counters;
        Counters.Clear();
        Counters.Add(new CounterViewModel(c.Files.ToString("N0"), "Files"));
        Counters.Add(new CounterViewModel(c.DocumentationFiles.ToString("N0"), "Documentation files"));
        Counters.Add(new CounterViewModel(c.SourceFiles.ToString("N0"), "Source files"));
        Counters.Add(new CounterViewModel(c.Chunks.ToString("N0"), "Chunks"));
        Counters.Add(new CounterViewModel(c.Embeddings.ToString("N0"), "Embeddings"));
        Counters.Add(new CounterViewModel(c.GraphNodes.ToString("N0"), "Graph nodes"));
        Counters.Add(new CounterViewModel(c.GraphEdges.ToString("N0"), "Graph edges"));
        Counters.Add(new CounterViewModel(c.OkfEntities.ToString("N0"), "OKF entities"));
    }

    private void Start(IndexMode mode)
    {
        IsRunning = true;
        StateKey = "busy";
        StateText = "Indexing";
        StateDetail = mode == IndexMode.Full ? "Full reindex" : "Refreshing changed files";
        Progress = 0;
        foreach (var stage in Stages)
        {
            stage.Status = StageStatus.Pending;
            stage.Detail = "";
            stage.DurationMs = 0;
        }
        _ = _workspace.Main.Engine.Indexing.StartAsync(_workspace.Record.Id, mode);
    }

    private async Task ClearAsync()
    {
        var confirmed = await _workspace.Main.ConfirmAsync("Clear the index?",
            "This removes what has been indexed for this repository: files, chunks, embeddings, the graph and the generated pages. The repository stays registered, and its conversations and learning material are kept.",
            _workspace.Record.Path, "Clear index");
        if (!confirmed)
        {
            return;
        }
        await _workspace.Main.Engine.Indexing.ClearAsync(_workspace.Record.Id);
        await _workspace.LoadAsync();
        await LoadRunAsync();
        _workspace.Main.ShowToast("The index was cleared.", false);
    }

    private async Task PullAsync()
    {
        var output = await _workspace.Main.Engine.Repositories.PullAsync(_workspace.Record);
        _workspace.Main.ShowToast(output.Length > 0 ? Engine.Text.TextUtil.Truncate(output, 200) : "Up to date.", false);
        Start(IndexMode.Incremental);
    }

    private async Task AddSpaceAsync()
    {
        await _workspace.Main.Engine.Confluence.AddSpaceAsync(_workspace.Record.Id, NewSpace);
        NewSpace = "";
        await ReloadRecordAsync();
        ConfluenceStatus = "Added. Choose Sync to fetch its pages.";
        _ = SpacePicker.EnsureLoadedAsync();
    }

    private async Task SyncConfluenceAsync()
    {
        ConfluenceStatus = "Syncing…";
        var progress = new Progress<string>(text => ConfluenceStatus = text);
        try
        {
            var pages = await _workspace.Main.Engine.Confluence.SyncAsync(_workspace.Record.Id, progress);
            ConfluenceStatus = $"{pages:N0} pages fetched. Refreshing the index…";
            Start(IndexMode.Incremental);
        }
        catch (Exception ex) when (ex is HttpRequestException or Engine.Repositories.ExplorerValidationException or System.Text.Json.JsonException or TaskCanceledException)
        {
            ConfluenceStatus = "Sync failed: " + ex.Message;
        }
    }
}

/// <summary>A space the repository searches, as the Indexing page shows it.</summary>
/// <param name="Url">Its address as the repository keeps it (what Remove takes).</param>
public sealed record ChosenSpace(string Url, string Name, string Detail, string Pages)
{
    /// <summary>By its name on the site when the sites' spaces are loaded (else its key), and its pages at the last sync.</summary>
    public static ChosenSpace Describe(string url, IEnumerable<ConfluenceSpaceChoice> choices, Engine.Confluence.ConfluenceDocument? synced)
    {
        Engine.Confluence.ConfluenceSpace? space = null;
        try
        {
            space = Engine.Confluence.ConfluenceService.ParseSpaceUrl(url);
        }
        catch (Engine.Repositories.ExplorerValidationException)
        {
            // an address an earlier version accepted: shown as it is
        }
        var id = space is null ? null : Engine.Confluence.ConfluenceService.SpaceId(space);
        var choice = id is null ? null : choices.FirstOrDefault(c => ConfluenceSpacePickerViewModel.Key(c.Space.Url) == id);
        var site = space is null ? "" : Uri.TryCreate(space.BaseUrl, UriKind.Absolute, out var u) ? u.Host : space.BaseUrl;
        var name = choice?.Name ?? space?.SpaceKey ?? url;
        var detail = choice?.Detail ?? (space is null ? url : $"{space.SpaceKey} · {site}");
        string pages;
        if (synced is null || synced.SyncedAt == default)
        {
            pages = "Not synced yet";
        }
        else if (synced.Pages.Any(p => p.Space.Length > 0))
        {
            var count = synced.Pages.Count(p => p.Space == id);
            pages = $"{(count == 0 ? "No pages" : Engine.Text.TextUtil.Plural(count, "page"))} at the last sync, {synced.SyncedAt.ToLocalTime():d MMM HH:mm}";
        }
        else
        {
            pages = $"Synced {synced.SyncedAt.ToLocalTime():d MMM HH:mm}";
        }
        return new ChosenSpace(url, name, detail, pages);
    }
}
