using System.Collections.ObjectModel;
using System.Windows.Input;
using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>
/// A changed file in the Changes tab: its status letter, name and folder; clicking it shows its diff, and its menu
/// opens the file, undoes the change or copies the path.
/// </summary>
public sealed class GitChangeRow(GitChange change, ICommand open, RepositoryTreeViewModel tree)
{
    public GitChange Change => change;
    public string Letter => change.Letter;
    public string Kind => change.Kind.ToString();
    public string FileName => change.FileName;
    public string Folder => change.Folder;
    public bool HasFolder => change.Folder.Length > 0;
    public ICommand OpenCommand => open;

    public bool CanUndo => !change.IsBranchComparison;

    public bool CanOpenFile => change.Kind != GitChangeKind.Deleted;

    public string UndoText => change.Kind == GitChangeKind.Untracked ? "Delete file…" : change.Staged ? "Unstage" : "Undo changes…";

    public ICommand UndoCommand => new RelayCommand(() => _ = tree.UndoChangeAsync(change), () => CanUndo);

    public ICommand OpenFileCommand => new RelayCommand(() => tree.OpenChangedFile(change), () => CanOpenFile);

    public ICommand CopyPathCommand => new RelayCommand(() => Ui.Copy(change.Path));

    public string ToolTip => $"{change.Path}\n{change.KindText}{(change.Staged ? " · staged" : "")}" + (change.OldPath is { } old ? $"\nRenamed from {old}" : "");
}

/// <summary>
/// A node of the Changes tree, as in Visual Studio's Git Changes: a group (Staged changes, Changes, Between branches),
/// a folder (a run of single folders shown as one path, "src/Orders/Api"), or a changed file.
/// </summary>
public sealed class ChangeTreeNode : ObservableObject
{
    private bool _isExpanded = true;
    private bool _isSelected;

    public string Name { get; init; } = "";

    /// <summary>How deep it is (a group is 0), for the row's indent as in the Files tree.</summary>
    public int Depth { get; private set; }

    public System.Windows.GridLength Indent => new(Depth * 14);

    public bool IsSelected
    {
        get => _isSelected;
        set => Set(ref _isSelected, value);
    }

    /// <summary>group | folder | file</summary>
    public string Kind { get; init; } = "folder";

    public GitChangeRow? Row { get; init; }

    public ObservableCollection<ChangeTreeNode> Children { get; } = [];

    public bool IsGroup => Kind == "group";
    public bool IsFolder => Kind == "folder";
    public bool IsFile => Kind == "file";

    /// <summary>How many files are under it (shown beside a group or folder).</summary>
    public int Count { get; set; }

    public string CountText => IsFile ? "" : Count.ToString(System.Globalization.CultureInfo.InvariantCulture);

    public bool IsExpanded
    {
        get => _isExpanded;
        set => Set(ref _isExpanded, value);
    }

    /// <summary>The changes of one group as a folder tree: files under their folders, single-folder runs joined.</summary>
    public static ChangeTreeNode Group(string name, IEnumerable<GitChangeRow> rows)
    {
        var group = new ChangeTreeNode { Name = name, Kind = "group" };
        foreach (var row in rows.OrderBy(r => r.Change.Path, StringComparer.OrdinalIgnoreCase))
        {
            var node = group;
            foreach (var part in row.Folder.Split('/', StringSplitOptions.RemoveEmptyEntries))
            {
                var next = node.Children.FirstOrDefault(c => c.IsFolder && c.Name == part);
                if (next is null)
                {
                    next = new ChangeTreeNode { Name = part, Kind = "folder" };
                    // Folders before files, each in name order.
                    var at = node.Children.TakeWhile(c => c.IsFolder && string.Compare(c.Name, part, StringComparison.OrdinalIgnoreCase) < 0).Count();
                    node.Children.Insert(at, next);
                }
                node = next;
            }
            node.Children.Add(new ChangeTreeNode { Name = row.FileName, Kind = "file", Row = row });
        }
        Compact(group);
        Counted(group);
        Deepen(group, 0);
        return group;
    }

    /// <summary>A folder whose only child is a folder becomes one node named by both ("src/Orders").</summary>
    private static void Compact(ChangeTreeNode node)
    {
        for (var i = 0; i < node.Children.Count; i++)
        {
            var child = node.Children[i];
            if (!child.IsFolder)
            {
                continue;
            }
            while (child.Children.Count == 1 && child.Children[0].IsFolder)
            {
                var only = child.Children[0];
                var merged = new ChangeTreeNode { Name = child.Name + "/" + only.Name, Kind = "folder" };
                foreach (var grandchild in only.Children)
                {
                    merged.Children.Add(grandchild);
                }
                node.Children[i] = merged;
                child = merged;
            }
            Compact(child);
        }
    }

    private static void Deepen(ChangeTreeNode node, int depth)
    {
        node.Depth = depth;
        foreach (var child in node.Children)
        {
            Deepen(child, depth + 1);
        }
    }

    private static int Counted(ChangeTreeNode node)
    {
        node.Count = node.IsFile ? 1 : node.Children.Sum(Counted);
        return node.Count;
    }

    /// <summary>The files under this node, in tree order.</summary>
    public IEnumerable<GitChangeRow> Files() => IsFile && Row is not null ? [Row] : Children.SelectMany(c => c.Files());
}

/// <summary>The Changes tab: the repository's uncommitted changes, as git reports them (read-only).</summary>
public sealed partial class RepositoryTreeViewModel
{
    private GitChangesReport? _changes;
    private bool _changesLoaded;
    private bool _loadingChanges;
    private int _changesVersion;

    public ObservableCollection<GitChangeRow> StagedChanges { get; } = [];
    public ObservableCollection<GitChangeRow> UnstagedChanges { get; } = [];

    /// <summary>The changes as Visual Studio shows them: Staged changes, Changes and Between branches, each a folder tree.</summary>
    public ObservableCollection<ChangeTreeNode> ChangeTree { get; } = [];

    private void BuildChangeTree()
    {
        ChangeTree.Clear();
        if (StagedChanges.Count > 0)
        {
            ChangeTree.Add(ChangeTreeNode.Group("Staged changes", StagedChanges));
        }
        if (UnstagedChanges.Count > 0)
        {
            ChangeTree.Add(ChangeTreeNode.Group("Changes", UnstagedChanges));
        }
        if (ComparedChanges.Count > 0)
        {
            ChangeTree.Add(ChangeTreeNode.Group($"Between {CompareBase} and {CompareTarget}", ComparedChanges));
        }
    }

    public bool IsChangesTab
    {
        get => Tab == "changes";
        set
        {
            if (value)
            {
                Tab = "changes";
            }
        }
    }

    /// <summary>The repository's folder is a git working tree.</summary>
    public bool IsGitRepository => _changes is not null;

    public int ChangesCount => _changes?.Changes.Count ?? 0;

    public bool HasStagedChanges => StagedChanges.Count > 0;

    public bool HasUnstagedChanges => UnstagedChanges.Count > 0;

    public string BranchText => _changes is null ? "" : _changes.Branch.Length > 0 ? _changes.Branch : "(no branch)";

    /// <summary>"↑2 ↓1": commits not pushed and not pulled, when there are any.</summary>
    public string SyncText => _changes is null ? "" : string.Join(" ", new[] { _changes.Ahead > 0 ? $"↑{_changes.Ahead}" : "", _changes.Behind > 0 ? $"↓{_changes.Behind}" : "" }.Where(s => s.Length > 0));

    public string SyncTooltip => _changes is null ? "" : $"{_changes.Ahead} commit(s) to push, {_changes.Behind} to pull (as of the last fetch)";

    /// <summary>What the tab says when it has no list to show.</summary>
    public string ChangesMessage => _loadingChanges && !_changesLoaded ? "Reading the changes…"
        : !IsGitRepository ? "This folder is not a Git repository, or Git is not installed."
        : ChangesCount == 0 ? "No changes: the working tree matches the last commit."
        : "";

    public ICommand RefreshChangesCommand => new RelayCommand(() => _ = RefreshChangesAsync());

    /// <summary>Reads the changes again (the tab opening, Refresh, a file saved or deleted).</summary>
    public async Task RefreshChangesAsync()
    {
        var version = ++_changesVersion;
        _loadingChanges = true;
        Notify(nameof(ChangesMessage));
        var report = await GitChanges.ReadAsync(_workspace.Record.Path, CancellationToken.None);
        if (version != _changesVersion)
        {
            return;
        }
        _changes = report;
        _changesLoaded = true;
        _loadingChanges = false;
        FillChanges();
    }

    private void FillChanges()
    {
        var filter = Filter.Trim();
        bool Shown(GitChange c) => filter.Length == 0 || c.Path.Contains(filter, StringComparison.OrdinalIgnoreCase);
        StagedChanges.Clear();
        UnstagedChanges.Clear();
        foreach (var change in _changes?.Changes ?? [])
        {
            if (!Shown(change))
            {
                continue;
            }
            var row = new GitChangeRow(change, new RelayCommand(() => _ = OpenChangeAsync(change)), this);
            (change.Staged ? StagedChanges : UnstagedChanges).Add(row);
        }
        BuildChangeTree();
        Notify(nameof(IsGitRepository), nameof(ChangesCount), nameof(HasStagedChanges), nameof(HasUnstagedChanges), nameof(BranchText), nameof(SyncText),
            nameof(SyncTooltip), nameof(ChangesMessage));
    }

    /// <summary>Shows a change's diff in the Documentation area.</summary>
    public async Task OpenChangeAsync(GitChange change)
    {
        var docs = _workspace.Documentation;
        if (docs.IsDiffEditing && docs.Mode == "diff")
        {
            // Editing this change already: stay. Another change: leave the editing first (asking when unsaved).
            if (docs.Diff?.Change == change)
            {
                _workspace.Main.Navigate(Section.Documentation);
                return;
            }
            if (!await docs.CloseDiffEditAsync(refresh: false))
            {
                return;
            }
        }
        var diff = await GitChanges.DiffAsync(_workspace.Record.Path, change, CancellationToken.None);
        _workspace.Documentation.ShowDiff(diff);
        _workspace.Main.Navigate(Section.Documentation);
    }

    /// <summary>The path of the change whose diff is on screen (Documentation showing a diff), else null.</summary>
    public string? DiffOpenPath => _workspace.Main.Section == Section.Documentation && _workspace.Documentation is { Mode: "diff", Diff: { } diff } ? diff.Change.Path : null;

    internal async void OpenChangedFile(GitChange change)
    {
        if (!await _workspace.Documentation.CloseDiffEditAsync(refresh: false))
        {
            return;
        }
        _workspace.Documentation.OpenFile(change.Path, 0);
        _workspace.Main.Navigate(Section.Documentation);
    }

    // ----- Undo changes (as Visual Studio's): asks first, then puts the file back, unstages it, or deletes a new one -----

    public async Task UndoChangeAsync(GitChange change)
    {
        if (change.IsBranchComparison)
        {
            return;
        }
        var (title, message, detail, action) = change switch
        {
            { Kind: GitChangeKind.Untracked } => ("Delete the new file?", $"Delete '{change.Path}'?", "It is not in Git yet; it goes to the Recycle Bin, where you can restore it.", "Delete"),
            { Staged: true } => ("Unstage the change?", $"Unstage '{change.Path}'?", "The change leaves the next commit; your edits stay in the file.", "Unstage"),
            { Kind: GitChangeKind.Deleted } => ("Undo the deletion?", $"Bring back '{change.Path}'?", "The file comes back as it was in the last commit (or as staged).", "Undo"),
            _ => ("Undo your changes?", $"Undo your changes to '{change.Path}'?", "The file goes back to the last commit (or to what is staged). Your edits are lost — this cannot be undone here.", "Undo changes"),
        };
        if (!await _workspace.Main.ConfirmAsync(title, message, detail, action))
        {
            return;
        }
        var docs = _workspace.Documentation;
        if (docs.Mode == "edit" && string.Equals(docs.EditPath, change.Path, StringComparison.OrdinalIgnoreCase))
        {
            await docs.CloseEditAsync(reopen: false);
        }
        string? problem;
        if (change.Kind == GitChangeKind.Untracked)
        {
            problem = null;
            try
            {
                var full = Engine.Indexing.FileScanner.SafeResolve(_workspace.Record.Path, change.Path);
                Microsoft.VisualBasic.FileIO.FileSystem.DeleteFile(full, Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs, Microsoft.VisualBasic.FileIO.RecycleOption.SendToRecycleBin);
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or OperationCanceledException)
            {
                problem = ex.Message;
            }
        }
        else
        {
            problem = await GitChanges.UndoAsync(_workspace.Record.Path, change, CancellationToken.None);
        }
        if (problem is not null)
        {
            _workspace.Main.ShowToast($"Could not undo it: {problem}", true);
            return;
        }
        Logging.Info($"Undid the change to {change.Path} ({(change.Staged ? "unstaged" : change.Kind.ToString())}).");
        _workspace.Main.ShowToast(change.Staged ? $"Unstaged {change.FileName}." : $"Undid the changes to {change.FileName}.", false);
        await RefreshChangesAsync();
        docs.QueueReindex();
        if (docs.Mode == "diff" && docs.Diff?.Change.Path == change.Path)
        {
            await docs.RefreshDiffAsync();
        }
    }

    // ----- Compare branches: what one branch changed since it left another, file by file -----

    private bool _comparing;
    private string? _compareBase;
    private string? _compareTarget;
    private string _compareSummary = "";

    public ObservableCollection<string> Branches { get; } = [];
    public ObservableCollection<GitChangeRow> ComparedChanges { get; } = [];

    /// <summary>The Compare branches box is open.</summary>
    public bool IsComparing
    {
        get => _comparing;
        set
        {
            if (Set(ref _comparing, value) && value)
            {
                _ = LoadBranchesAsync();
            }
        }
    }

    // Choosing a branch enables Compare at once.
    public string? CompareBase
    {
        get => _compareBase;
        set
        {
            if (Set(ref _compareBase, value))
            {
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    public string? CompareTarget
    {
        get => _compareTarget;
        set
        {
            if (Set(ref _compareTarget, value))
            {
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    public string CompareSummary { get => _compareSummary; private set => Set(ref _compareSummary, value); }

    public bool HasComparison => ComparedChanges.Count > 0;

    public ICommand ToggleCompareCommand => new RelayCommand(() => IsComparing = !IsComparing);

    public ICommand SwapCompareCommand => new RelayCommand(() => (CompareBase, CompareTarget) = (CompareTarget, CompareBase));

    public ICommand RunCompareCommand => new RelayCommand(() => _ = CompareAsync(), () => !string.IsNullOrEmpty(CompareBase) && !string.IsNullOrEmpty(CompareTarget) && CompareBase != CompareTarget);

    public ICommand ClearCompareCommand => new RelayCommand(() =>
    {
        ComparedChanges.Clear();
        CompareSummary = "";
        Notify(nameof(HasComparison));
        BuildChangeTree();
    });

    private async Task LoadBranchesAsync()
    {
        var (branches, current) = await GitChanges.BranchesAsync(_workspace.Record.Path, CancellationToken.None);
        Branches.Clear();
        foreach (var b in branches)
        {
            Branches.Add(b);
        }
        // A pull request's usual question: what does the current branch change against the main line?
        CompareTarget ??= current ?? branches.FirstOrDefault();
        CompareBase ??= branches.FirstOrDefault(b => b != CompareTarget && b is "main" or "master" or "origin/main" or "origin/master" or "develop")
                        ?? branches.FirstOrDefault(b => b != CompareTarget);
    }

    public async Task CompareAsync()
    {
        if (CompareBase is not { } from || CompareTarget is not { } to)
        {
            return;
        }
        CompareSummary = $"Comparing {from} with {to}…";
        var changes = await GitChanges.CompareAsync(_workspace.Record.Path, from, to, CancellationToken.None);
        ComparedChanges.Clear();
        if (changes is null)
        {
            CompareSummary = $"Git could not compare {from} with {to}.";
            Notify(nameof(HasComparison));
            return;
        }
        foreach (var change in changes)
        {
            ComparedChanges.Add(new GitChangeRow(change, new RelayCommand(() => _ = OpenChangeAsync(change)), this));
        }
        CompareSummary = changes.Count == 0 ? $"{to} changes nothing since it left {from}." : $"{changes.Count} file(s) changed in {to} since it left {from}";
        Notify(nameof(HasComparison));
        BuildChangeTree();
    }
}
