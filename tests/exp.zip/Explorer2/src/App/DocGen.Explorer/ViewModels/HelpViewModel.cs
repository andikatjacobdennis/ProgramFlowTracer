using System.Windows.Input;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>Where Help is: its home (topics and popular articles), a topic, an article, or search results.</summary>
public enum HelpPage
{
    Home,
    Topic,
    Article,
}

/// <summary>
/// Help, as a help centre: a home with a search box, topic cards and popular articles; a topic's articles; and an
/// article with its breadcrumb, "Was this helpful?", related articles and the next one. A question asked in the search
/// box (Enter, or Ask) gets an answer card above the articles: where it is and how to do it, with links that go there.
/// </summary>
public sealed class HelpViewModel : ObservableObject
{
    private HelpPage _page = HelpPage.Home;
    private HelpTopic? _topic;
    private HelpArticle? _article;
    private string _query = "";
    private IReadOnlyList<HelpArticle> _results = [];
    private string? _feedback;
    private HelpAnswer? _answer;
    private bool _isThinking;
    private string _thinkingText = "";
    private CancellationTokenSource? _askCts;

    public HelpViewModel(MainViewModel main)
    {
        Main = main;
        HomeCommand = new RelayCommand(() => Go(HelpPage.Home, null, null));
        OpenTopicCommand = new RelayCommand(p =>
        {
            if (p is HelpTopic topic)
            {
                Go(HelpPage.Topic, topic, null);
            }
        });
        OpenArticleCommand = new RelayCommand(p =>
        {
            if (p is HelpArticle article)
            {
                Go(HelpPage.Article, article.Topic, article);
            }
        });
        HelpfulCommand = new RelayCommand(p =>
        {
            var yes = p as string == "yes";
            Logging.Info($"Help feedback: {Article?.Id} — {(yes ? "helpful" : "not helpful")}");
            Feedback = yes ? "Thanks for letting us know." : "Thanks. Send feedback to tell us what was missing — a few words help.";
        });
        ClearSearchCommand = new RelayCommand(() => Query = "");
        AskCommand = new RelayCommand(() => _ = AskAsync());
        OpenLinkCommand = new RelayCommand(p => HelpLinks.Open(Main, p as string));
    }

    public MainViewModel Main { get; }

    public IReadOnlyList<HelpTopic> Topics => HelpContent.Topics;

    public IReadOnlyList<HelpArticle> Popular { get; } = HelpContent.Articles.Where(a => a.Popular).ToList();

    /// <summary>Searches people often make, offered as chips under the search box.</summary>
    public IReadOnlyList<string> PopularSearches { get; } = ["attach a file", "microphone", "read aloud", "dark theme", "diagram", "shortcuts"];

    /// <summary>A popular search, chosen: it is searched for and asked.</summary>
    public ICommand SearchForCommand => new RelayCommand(p =>
    {
        Query = p as string ?? "";
        _ = AskAsync();
    });

    public HelpPage Page
    {
        get => _page;
        private set
        {
            if (Set(ref _page, value))
            {
                Notify(nameof(IsHome), nameof(IsTopic), nameof(IsArticle), nameof(IsInside));
            }
        }
    }

    public bool IsHome => Page == HelpPage.Home;
    public bool IsTopic => Page == HelpPage.Topic;
    public bool IsArticle => Page == HelpPage.Article;

    /// <summary>In a topic or an article (the topics sidebar shows).</summary>
    public bool IsInside => Page != HelpPage.Home;

    public HelpTopic? Topic
    {
        get => _topic;
        private set => Set(ref _topic, value);
    }

    public HelpArticle? Article
    {
        get => _article;
        private set => Set(ref _article, value);
    }

    /// <summary>The other articles of the article's topic.</summary>
    public IReadOnlyList<HelpArticle> Related => Article is null ? [] : Article.Topic.Articles.Where(a => a != Article).ToList();

    public bool HasRelated => Related.Count > 0;

    /// <summary>The article after this one (the next topic's first after a topic's last), for "Next".</summary>
    public HelpArticle? Next
    {
        get
        {
            var all = HelpContent.Articles.ToList();
            var at = Article is null ? -1 : all.IndexOf(Article);
            return at >= 0 && at + 1 < all.Count ? all[at + 1] : null;
        }
    }

    public HelpArticle? Previous
    {
        get
        {
            var all = HelpContent.Articles.ToList();
            var at = Article is null ? -1 : all.IndexOf(Article);
            return at > 0 ? all[at - 1] : null;
        }
    }

    /// <summary>What was searched for; results follow as it is typed.</summary>
    public string Query
    {
        get => _query;
        set
        {
            if (Set(ref _query, value ?? ""))
            {
                Results = HelpContent.Search(_query);
                // A different question: the answer to the last one goes.
                if (Answer is not null && Answer.Question != _query.Trim())
                {
                    CancelAsking();
                    Answer = null;
                }
                if (_query.Trim().Length > 0 && Page != HelpPage.Home)
                {
                    Go(HelpPage.Home, null, null, keepQuery: true);
                }
                Notify(nameof(IsSearching), nameof(ShowTopics), nameof(ResultsText), nameof(NoResults));
            }
        }
    }

    public IReadOnlyList<HelpArticle> Results
    {
        get => _results;
        private set => Set(ref _results, value);
    }

    public bool IsSearching => Query.Trim().Length > 0;
    public bool ShowTopics => !IsSearching;
    public bool NoResults => IsSearching && Results.Count == 0;

    public string ResultsText => Results.Count switch
    {
        0 => $"No articles match “{Query.Trim()}”. Try fewer or other words, or browse the topics.",
        1 => $"1 article for “{Query.Trim()}”",
        var n => $"{n} articles for “{Query.Trim()}”",
    };

    /// <summary>The thanks after "Was this helpful?" (null until answered).</summary>
    public string? Feedback
    {
        get => _feedback;
        private set
        {
            if (Set(ref _feedback, value))
            {
                OnPropertyChanged(nameof(Asking));
            }
        }
    }

    /// <summary>"Was this helpful?" is still asked.</summary>
    public bool Asking => Feedback is null;

    public ICommand HomeCommand { get; }
    public ICommand OpenTopicCommand { get; }
    public ICommand OpenArticleCommand { get; }
    public ICommand HelpfulCommand { get; }
    public ICommand ClearSearchCommand { get; }

    /// <summary>Answers what is in the search box (Enter, or Ask).</summary>
    public ICommand AskCommand { get; }

    /// <summary>Follows an explorer: link of an answer or an article (a page, a Settings page, an article).</summary>
    public ICommand OpenLinkCommand { get; }

    /// <summary>The answer card above the articles (null until a question is asked).</summary>
    public HelpAnswer? Answer
    {
        get => _answer;
        private set
        {
            if (Set(ref _answer, value))
            {
                OnPropertyChanged(nameof(HasAnswer));
            }
        }
    }

    public bool HasAnswer => Answer is not null;

    /// <summary>The chat model is writing the answer.</summary>
    public bool IsThinking
    {
        get => _isThinking;
        private set => Set(ref _isThinking, value);
    }

    public string ThinkingText
    {
        get => _thinkingText;
        private set => Set(ref _thinkingText, value);
    }

    /// <summary>
    /// Answers the question in the search box: at once from the articles, then — with a chat model — in the model's
    /// words from Help's knowledge. A new question cancels the one before.
    /// </summary>
    public async Task AskAsync()
    {
        var question = Query.Trim();
        CancelAsking();
        if (question.Length == 0)
        {
            Answer = null;
            return;
        }
        var cts = _askCts = new CancellationTokenSource();
        var offline = HelpAnswers.Offline(question);
        Answer = offline;
        try
        {
            var status = await Main.Engine.Models.GetStatusAsync(cts.Token);
            if (!status.Configured || cts.IsCancellationRequested)
            {
                return;
            }
            var name = status.DisplayName ?? status.ModelId ?? "the chat model";
            ThinkingText = $"{name} is writing an answer from Help…";
            IsThinking = true;
            var answer = await HelpAnswers.AskModelAsync(Main.Engine.Models, question, name, offline, cts.Token);
            if (!cts.IsCancellationRequested)
            {
                Answer = answer;
            }
        }
        catch (OperationCanceledException) when (cts.IsCancellationRequested)
        {
            // A newer question, or the search was cleared.
        }
        catch (Exception ex)
        {
            Logging.Error(ex, "Help answer");
            if (!cts.IsCancellationRequested)
            {
                Answer = offline with { Source = $"From Help — the chat model could not answer ({ex.Message})" };
            }
        }
        finally
        {
            if (_askCts == cts)
            {
                IsThinking = false;
            }
        }
    }

    private void CancelAsking()
    {
        _askCts?.Cancel();
        _askCts = null;
        IsThinking = false;
    }

    /// <summary>Raised when another page shows (the view scrolls to its top).</summary>
    public event EventHandler? Navigated;

    /// <summary>Opens an article by its id (for links from elsewhere in the explorer).</summary>
    public void Open(string articleId)
    {
        if (HelpContent.Articles.FirstOrDefault(a => a.Id == articleId) is { } article)
        {
            Go(HelpPage.Article, article.Topic, article);
        }
    }

    private void Go(HelpPage page, HelpTopic? topic, HelpArticle? article, bool keepQuery = false)
    {
        if (!keepQuery && page != HelpPage.Home)
        {
            _query = "";
            Results = [];
            CancelAsking();
            Answer = null;
            Notify(nameof(Query), nameof(IsSearching), nameof(ShowTopics), nameof(NoResults));
        }
        Topic = topic;
        Article = article;
        Page = page;
        Feedback = null;
        Notify(nameof(Related), nameof(HasRelated), nameof(Next), nameof(Previous));
        Navigated?.Invoke(this, EventArgs.Empty);
    }
}
