using System.Globalization;
using DocGen.Explorer.Engine.Assistant;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>A kind of attachment in Settings → Attachments: whether it is read, the largest file, and how much text is sent.</summary>
public sealed class AttachmentRuleRow : ObservableObject
{
    private readonly Action _changed;
    private bool _enabled;
    private string _maxSize;
    private string _maxChars;
    private string _maxPixels;

    public AttachmentRuleRow(AttachmentRule rule, Action changed)
    {
        _changed = changed;
        Kind = rule.Kind;
        _enabled = rule.Enabled;
        _maxSize = rule.MaxSizeMb.ToString("0.#", CultureInfo.CurrentCulture);
        _maxChars = rule.MaxChars.ToString(CultureInfo.CurrentCulture);
        _maxPixels = (rule.Kind == Attachments.Image && rule.MaxPixels == 0 ? 0 : rule.MaxPixels).ToString(CultureInfo.CurrentCulture);
        var kind = Attachments.Kinds.First(k => k.Kind == rule.Kind);
        Name = kind.Name;
        Extensions = string.Join(" ", kind.Extensions.Take(14)) + (kind.Extensions.Length > 14 ? $" and {kind.Extensions.Length - 14} more" : "");
        AllExtensions = string.Join(" ", kind.Extensions);
    }

    public string Kind { get; }
    public string Name { get; }
    public string Extensions { get; }
    public string AllExtensions { get; }

    /// <summary>Images are sent whole (to a model that can view them): no length.</summary>
    public bool HasLength => Kind != Attachments.Image;

    public bool Enabled
    {
        get => _enabled;
        set
        {
            if (Set(ref _enabled, value))
            {
                _changed();
            }
        }
    }

    /// <summary>The largest file read, in MB (0.1 to 500).</summary>
    public string MaxSize
    {
        get => _maxSize;
        set
        {
            if (Set(ref _maxSize, value) && Size() is not null)
            {
                _changed();
            }
        }
    }

    /// <summary>The most characters sent to the model (1,000 to 2,000,000).</summary>
    public string MaxChars
    {
        get => _maxChars;
        set
        {
            if (Set(ref _maxChars, value) && Chars() is not null)
            {
                _changed();
            }
        }
    }

    /// <summary>Images: a larger image is scaled down to this longest side, in pixels (0: never scaled).</summary>
    public string MaxPixels
    {
        get => _maxPixels;
        set
        {
            if (Set(ref _maxPixels, value) && Pixels() is not null)
            {
                _changed();
            }
        }
    }

    private int? Pixels() => int.TryParse(_maxPixels, NumberStyles.Integer, CultureInfo.CurrentCulture, out var n) && n >= 0 ? n == 0 ? 0 : Math.Clamp(n, 256, 8000) : null;

    private double? Size() => double.TryParse(_maxSize, NumberStyles.Float, CultureInfo.CurrentCulture, out var mb) && mb > 0 ? Math.Clamp(mb, 0.1, 500) : null;

    private int? Chars() => int.TryParse(_maxChars.Replace(",", "", StringComparison.Ordinal).Replace(" ", "", StringComparison.Ordinal), NumberStyles.Integer, CultureInfo.CurrentCulture, out var n) && n > 0
        ? Math.Clamp(n, 1_000, 2_000_000) : null;

    public AttachmentRule ToRule()
    {
        var defaults = Attachments.RuleFor(null, Kind);
        return new AttachmentRule
        {
            Kind = Kind, Enabled = Enabled, MaxSizeMb = Size() ?? defaults.MaxSizeMb, MaxChars = HasLength ? Chars() ?? defaults.MaxChars : 0,
            MaxPixels = HasLength ? 0 : Pixels() ?? defaults.MaxPixels,
        };
    }
}
