using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Windows.Media;
using DocGen.Explorer.Engine.Export;
using DocGen.Explorer.Engine.Graph;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

public sealed class ConceptTypeFilter(string type, int count, GraphViewModel owner) : ObservableObject
{
    private bool _isVisible = true;
    private int _count = count;

    public string Type { get; } = type;

    /// <summary>How many there are in what the graph draws from (the scope, when one is shown).</summary>
    public int Count
    {
        get => _count;
        set => Set(ref _count, value);
    }
    public Brush Dot { get; } = new SolidColorBrush((Color)ColorConverter.ConvertFromString(type == ConceptTypes.Repository ? ConceptPalette.Of(type).Fill : ConceptPalette.Of(type).Accent));

    public bool IsVisible
    {
        get => _isVisible;
        set
        {
            if (Set(ref _isVisible, value))
            {
                owner.Rebuild();
            }
        }
    }
}

public sealed class ConnectionViewModel(string direction, string kind, GraphNode node, GraphViewModel owner)
{
    public string Direction { get; } = direction;
    public string Kind { get; } = kind;
    public GraphNode Node { get; } = node;
    public string Label => Node.Label;
    public string Type => Node.Type;
    public ICommand SelectCommand => new RelayCommand(() => owner.SelectNode(Node.Id, center: true));
}

/// <summary>The knowledge graph page: the drawing, its legend filters, search, focus mode, details and SVG export.</summary>
/// <summary>A group in the grouped graph's list.</summary>
public sealed class GraphGroupRowViewModel(GraphGroup group, GraphViewModel owner)
{
    public GraphGroup Group { get; } = group;
    public string Name => Group.Name;
    public string Reason => Group.Reason;
    public string Size => $"{Group.Members.Count}";
    public ICommand OpenCommand => new RelayCommand(() => owner.OpenGroup(Group));
}

public sealed class GraphViewModel : ObservableObject, IActivatable
{
    private GraphScopeResult? _scoped;
    private string _scopeText = "";
    private string _scopeMode = "auto";
    private bool _isScoping;
    private CancellationTokenSource? _suggestCts;
    private GraphGrouping? _grouping;
    private GraphGroup? _openGroup;
    private bool _isGrouping;
    private string _groupStatus = "";
    private bool _hasModel;
    private readonly WorkspaceViewModel _workspace;
    private KnowledgeGraph _full = new();
    private KnowledgeGraph _shown = new();
    private GraphNode? _selected;
    private int _focusDepth;
    private int _maxNodes = 200;
    private bool _isLayingOut;
    private string _summary = "";
    private CancellationTokenSource? _layoutCts;

    public GraphViewModel(WorkspaceViewModel workspace)
    {
        _workspace = workspace;
        FitCommand = new RelayCommand(() => FitRequested?.Invoke(this, EventArgs.Empty));
        DownloadCommand = new AsyncCommand(DownloadAsync);
        OpenSelectedCommand = new RelayCommand(() => { if (Selected is not null) { Open(Selected); } }, () => Selected?.Path is not null || Selected?.Type == ConceptTypes.DocumentationPage);
        AskAboutSelectedCommand = new RelayCommand(AskAboutSelected, () => Selected is not null);
        ShowAllTypesCommand = new RelayCommand(() =>
        {
            foreach (var filter in TypeFilters)
            {
                filter.IsVisible = true;
            }
        });
        ApplyScopeCommand = new AsyncCommand(ApplyScopeAsync, () => !IsScoping && ScopeText.Trim().Length >= 2);
        ShowOnlySelectedCommand = new AsyncCommand(ShowOnlySelectedAsync, () => HasSelectedConcept && !IsScoping);
        ClearScopeCommand = new RelayCommand(() => { ScopeText = ""; SetScope(null); }, () => IsScoped);
        PickScopeCommand = new AsyncCommand(async p =>
        {
            if (p is GraphScopeSuggestion suggestion)
            {
                ScopeText = suggestion.Text;
                ScopeSuggestions.Clear();
                await ApplyScopeAsync(useModel: false);
            }
        });
        GroupCommand = new AsyncCommand(GroupAsync, () => !IsGrouping && _full.Nodes.Count > 0);
        ResetGroupingCommand = new RelayCommand(ResetGrouping, () => IsGrouped && !IsGrouping);
        BackToGroupsCommand = new RelayCommand(() => OpenGroup(null), () => IsGroupOpen);
        OpenSelectedGroupCommand = new RelayCommand(() => { if (SelectedGroup is { } g) { OpenGroup(g); } }, () => SelectedGroup is not null);
    }

    public ICommand FitCommand { get; }
    public ICommand DownloadCommand { get; }
    public ICommand OpenSelectedCommand { get; }
    public ICommand AskAboutSelectedCommand { get; }
    public ICommand ShowAllTypesCommand { get; }
    public ICommand ApplyScopeCommand { get; }
    public ICommand ShowOnlySelectedCommand { get; }
    public ICommand ClearScopeCommand { get; }
    public ICommand PickScopeCommand { get; }

    public ObservableCollection<GraphScopeSuggestion> ScopeSuggestions { get; } = [];

    /// <summary>"Show only": a project, namespace, folder or feature the graph is narrowed to (empty: the whole repository).</summary>
    public string ScopeText
    {
        get => _scopeText;
        set
        {
            if (Set(ref _scopeText, value ?? ""))
            {
                _ = SuggestScopesAsync(_scopeText);
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    /// <summary>auto (the request decides) | matching | linked | flow (see <see cref="GraphScopeMode"/>).</summary>
    public string ScopeMode
    {
        get => _scopeMode;
        set
        {
            if (Set(ref _scopeMode, value))
            {
                OnPropertyChanged(nameof(SelectedReach));
                if (IsScoped)
                {
                    _ = ApplyScopeAsync(useModel: false, reuseRequest: true); // a different reach for the same request
                }
            }
        }
    }

    public bool IsScoped => _scoped is not null;

    public bool IsScoping
    {
        get => _isScoping;
        private set
        {
            if (Set(ref _isScoping, value))
            {
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    public string ScopeSummary => _scoped?.Description ?? "The whole repository.";

    /// <summary>The graph the view draws from: the scope when there is one, else the whole graph.</summary>
    private KnowledgeGraph Source => _scoped?.Graph ?? _full;

    private async Task SuggestScopesAsync(string text)
    {
        _suggestCts?.Cancel();
        var cts = _suggestCts = new CancellationTokenSource();
        var full = _full;
        try
        {
            await Task.Delay(150, cts.Token); // typing: wait for a pause
            var suggestions = await Task.Run(() => GraphScoper.Suggest(full, text), cts.Token);
            if (cts.IsCancellationRequested || !ReferenceEquals(cts, _suggestCts))
            {
                return; // a later keystroke's suggestions win
            }
            ScopeSuggestions.Clear();
            if (_scoped is null || !string.Equals(text.Trim(), _scopedText, StringComparison.Ordinal))
            {
                foreach (var suggestion in suggestions)
                {
                    ScopeSuggestions.Add(suggestion);
                }
            }
        }
        catch (OperationCanceledException)
        {
        }
    }

    private string? _scopedText;

    /// <summary>The reaches the "Reach" list offers.</summary>
    public IReadOnlyList<ReachChoice> ScopeReaches { get; } =
    [
        new("auto", "Reach: auto", "The request decides (\"flow\" traces it, \"uses\" adds what it uses)"),
        new("matching", "Only matching", "What matches and what it contains"),
        new("linked", "+ what it uses", "Also what it uses, calls, inherits or references, and the classes implementing its interfaces (tests left out)"),
        new("flow", "+ traced flow", "Also every type its architecture trace reaches, across projects"),
    ];

    public ReachChoice SelectedReach
    {
        get => ScopeReaches.First(r => r.Key == ScopeMode);
        set
        {
            if (value is not null)
            {
                ScopeMode = value.Key;
            }
        }
    }

    public string ShowButtonText => _hasModel ? "Show with AI" : "Show";

    public string ShowButtonTooltip => _hasModel
        ? "The model reads your request (\"only order service\", \"its flow without tests\") and picks the parts of the repository, how far to reach and what to leave out"
        : "Shows the part of the repository your words name (\"only order service\", \"its flow without tests\")";

    /// <summary>Reads the request (with the model when one is configured) and narrows the graph to what it asks for.</summary>
    private Task ApplyScopeAsync() => ApplyScopeAsync(useModel: true);

    private GraphScopeRequest? _lastRequest;

    private async Task ApplyScopeAsync(bool useModel, bool reuseRequest = false)
    {
        var text = ScopeText.Trim();
        if (text.Length < 2)
        {
            SetScope(null);
            return;
        }
        ScopeSuggestions.Clear();
        _suggestCts?.Cancel();
        IsScoping = true;
        try
        {
            var full = _full;
            var index = _workspace.Index;
            var request = reuseRequest && _lastRequest is not null && text == _scopedText
                ? _lastRequest
                : await _workspace.Main.Engine.GraphScopes.InterpretAsync(text, full, _workspace.Record.Id, useModel && _hasModel);
            _lastRequest = request;
            if (request.Terms.Count == 0)
            {
                Ui.Notify(request.Explanation);
                return;
            }
            // A reach chosen in the list wins over the one read from the request.
            var mode = ScopeMode switch { "linked" => GraphScopeMode.Linked, "flow" => GraphScopeMode.Flow, "matching" => GraphScopeMode.Matching, _ => request.Mode };
            var settings = await _workspace.Main.Engine.Skills.GetSettingsAsync();
            var result = await Task.Run(() => GraphScoper.Scope(full, index, request.Terms, mode, request.ExcludeTypes, settings.TraceMaxSteps, settings.TraceMaxDepth));
            if (result.Graph.Nodes.Count == 0)
            {
                Ui.Notify($"Nothing in the graph matches “{text}”.");
                return;
            }
            _scopedText = text;
            var by = request.By == "words" ? "" : $"{request.By}: {request.Explanation} ";
            SetScope(result with { Description = by + result.Description });
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            Ui.Notify("The graph could not be narrowed: " + ex.Message);
            Logging.Error(ex, "Graph scope");
        }
        finally
        {
            IsScoping = false;
        }
    }

    /// <summary>Narrows the graph to the selected concept and what it uses (replaces the old Focus buttons).</summary>
    private async Task ShowOnlySelectedAsync()
    {
        if (Selected is null || Selected.Type == ConceptTypes.Group)
        {
            return;
        }
        _scopeText = Selected.Key ?? Selected.Label;
        OnPropertyChanged(nameof(ScopeText));
        var reach = _scopeMode;
        _scopeMode = reach == "auto" ? "linked" : reach;
        try
        {
            await ApplyScopeAsync(useModel: false);
        }
        finally
        {
            _scopeMode = reach;
        }
    }

    /// <summary>Shows the scope (or the whole graph); a grouping made for another scope is put away.</summary>
    private void SetScope(GraphScopeResult? scope)
    {
        _scoped = scope;
        if (scope is null)
        {
            _scopedText = null;
        }
        if (_grouping is not null)
        {
            _workspace.Main.Engine.GraphGroups.Reset(_workspace.Record.Id);
            _grouping = null;
            _openGroup = null;
            Groups.Clear();
            NotifyGrouping();
        }
        Selected = null;
        FocusDepth = 0;
        var counts = Source.TypeCounts();
        foreach (var filter in TypeFilters)
        {
            filter.Count = counts.GetValueOrDefault(filter.Type);
        }
        Notify(nameof(IsScoped), nameof(ScopeSummary));
        CommandManager.InvalidateRequerySuggested();
        Rebuild();
    }

    public ICommand GroupCommand { get; }
    public ICommand ResetGroupingCommand { get; }
    public ICommand BackToGroupsCommand { get; }
    public ICommand OpenSelectedGroupCommand { get; }

    public ObservableCollection<GraphGroupRowViewModel> Groups { get; } = [];

    /// <summary>The graph is shown as groups (an overview, or one group opened).</summary>
    public bool IsGrouped => _grouping is not null;

    public bool IsGroupOpen => _openGroup is not null;
    public bool ShowLegend => !IsGrouped;

    /// <summary>The size limit applies to the ungrouped graph only.</summary>
    public bool ShowLimit => !IsGrouped;

    public bool IsGrouping
    {
        get => _isGrouping;
        private set
        {
            if (Set(ref _isGrouping, value))
            {
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    /// <summary>What grouping is doing (the model's progress), shown while it runs.</summary>
    public string GroupStatus
    {
        get => _groupStatus;
        private set => Set(ref _groupStatus, value);
    }

    public string GroupButtonText => _hasModel ? "Group with AI" : "Group";

    private string _groupInstructions = "";

    /// <summary>How to group, in the person's own words (optional; sent to the model with the grouping).</summary>
    public string GroupInstructions { get => _groupInstructions; set => Set(ref _groupInstructions, value ?? ""); }

    public string GroupInstructionsHint => _hasModel ? "How to group (optional): by feature, by layer, keep tests apart…" : "Instructions need a chat model (Settings)";

    public string GroupButtonTooltip => _hasModel
        ? "Break the graph into groups of at most 30 concepts, by how they are linked; the model names each group and explains why its concepts belong together"
        : "Break the graph into groups of at most 30 concepts, by how they are linked (configure a chat model in Settings for named, explained groups)";

    public string GroupingSummary => _grouping is null ? ""
        : $"{_grouping.Groups.Count} groups of at most {GraphGrouper.MaxGroupSize} from {_grouping.ConceptCount:N0} concepts · " +
          (_grouping.By == "structure" ? "grouped by their links" : $"named and checked by {_grouping.By}");

    public string OpenGroupName => _openGroup?.Name ?? "";
    public string OpenGroupReason => _openGroup?.Reason ?? "";

    /// <summary>The selected card when it is a group (the overview).</summary>
    public GraphGroup? SelectedGroup => Selected?.Type == ConceptTypes.Group && _grouping is not null ? _grouping.Groups.FirstOrDefault(g => g.Id == Selected.Key) : null;
    public bool HasSelectedGroup => SelectedGroup is not null;
    public bool HasSelectedConcept => Selected is not null && SelectedGroup is null;

    public string SelectedGroupMembers => SelectedGroup is { } g
        ? string.Join("\n", g.Members.Select(id => _full.Find(id)).Where(n => n is not null).Select(n => $"{n!.Label}  ·  {n.Type}"))
        : "";

    /// <summary>Groups the graph as currently shown (its limit and kinds), with the model when one is configured.</summary>
    private async Task GroupAsync()
    {
        IsGrouping = true;
        GroupStatus = "Finding groups in the links…";
        try
        {
            var visibleTypes = TypeFilters.Where(f => f.IsVisible).Select(f => f.Type).ToHashSet(StringComparer.Ordinal);
            var full = Source;
            var maxNodes = MaxNodes;
            var all = visibleTypes.Count == TypeFilters.Count;
            var scope = await Task.Run(() =>
            {
                var graph = all ? GraphBuilder.Reduce(full, maxNodes) : GraphBuilder.Reduce(full, maxNodes, visibleTypes);
                if (all)
                {
                    return graph;
                }
                var keep = graph.Nodes.Where(n => visibleTypes.Contains(n.Type)).Select(n => n.Id).ToHashSet(StringComparer.Ordinal);
                return new KnowledgeGraph { Nodes = graph.Nodes.Where(n => keep.Contains(n.Id)).ToList(), Edges = graph.Edges.Where(e => keep.Contains(e.From) && keep.Contains(e.To)).ToList() };
            });
            var grouping = await _workspace.Main.Engine.GraphGroups.GroupAsync(_workspace.Record.Id, scope, status => Ui.Post(() => GroupStatus = status),
                instructions: GroupInstructions);
            ApplyGrouping(grouping);
            Ui.Notify($"{grouping.Groups.Count} groups — open one to see its concepts; Reset returns to the whole graph.");
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            Ui.Notify("The graph could not be grouped: " + ex.Message);
            Logging.Error(ex, "Graph grouping");
        }
        finally
        {
            IsGrouping = false;
            GroupStatus = "";
        }
    }

    private void ApplyGrouping(GraphGrouping? grouping)
    {
        _grouping = grouping;
        _openGroup = null;
        Groups.Clear();
        foreach (var group in grouping?.Groups ?? [])
        {
            Groups.Add(new GraphGroupRowViewModel(group, this));
        }
        Selected = null;
        FocusDepth = 0;
        NotifyGrouping();
        Rebuild();
    }

    private void NotifyGrouping()
    {
        Notify(nameof(IsGrouped), nameof(IsGroupOpen), nameof(ShowLegend), nameof(ShowLimit), nameof(GroupingSummary), nameof(OpenGroupName), nameof(OpenGroupReason),
            nameof(SelectedGroup), nameof(HasSelectedGroup), nameof(HasSelectedConcept), nameof(SelectedGroupMembers));
        CommandManager.InvalidateRequerySuggested();
    }

    /// <summary>Back to the whole graph; the saved grouping is removed.</summary>
    private void ResetGrouping()
    {
        _workspace.Main.Engine.GraphGroups.Reset(_workspace.Record.Id);
        ApplyGrouping(null);
        Ui.Notify("Back to the whole graph.");
    }

    /// <summary>Opens a group (its members and their links), or the overview of groups when null.</summary>
    public void OpenGroup(GraphGroup? group)
    {
        _openGroup = group;
        Selected = null;
        NotifyGrouping();
        Rebuild();
    }

    public ObservableCollection<ConceptTypeFilter> TypeFilters { get; } = [];
    public ObservableCollection<ConnectionViewModel> Connections { get; } = [];

    /// <summary>Raised with the graph and positions to draw.</summary>
    public event EventHandler<(KnowledgeGraph Graph, IReadOnlyDictionary<string, NodePosition> Positions)>? GraphReady;
    public event EventHandler? FitRequested;
    public event EventHandler<string>? SelectRequested;

    public KnowledgeGraph Shown => _shown;

    public string Summary
    {
        get => _summary;
        private set => Set(ref _summary, value);
    }

    public bool IsLayingOut
    {
        get => _isLayingOut;
        private set => Set(ref _isLayingOut, value);
    }

    public bool IsEmpty => _full.Nodes.Count == 0;


    public GraphNode? Selected
    {
        get => _selected;
        private set
        {
            if (Set(ref _selected, value))
            {
                Notify(nameof(HasSelection), nameof(SelectedPath), nameof(SelectedGroup), nameof(HasSelectedGroup), nameof(HasSelectedConcept), nameof(SelectedGroupMembers));
                Connections.Clear();
                if (value is not null)
                {
                    foreach (var edge in _full.Edges.Where(e => e.From == value.Id))
                    {
                        if (_full.Find(edge.To) is { } target)
                        {
                            Connections.Add(new ConnectionViewModel("→", edge.Kind, target, this));
                        }
                    }
                    foreach (var edge in _full.Edges.Where(e => e.To == value.Id))
                    {
                        if (_full.Find(edge.From) is { } source)
                        {
                            Connections.Add(new ConnectionViewModel("←", edge.Kind, source, this));
                        }
                    }
                }
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    public bool HasSelection => Selected is not null;
    public string SelectedPath => Selected?.Path is { } path ? path + (Selected.Line is > 1 ? $":{Selected.Line}" : "") : "";

    /// <summary>0 shows everything; 1 or 2 shows the selected concept's neighbourhood.</summary>
    public int FocusDepth
    {
        get => _focusDepth;
        set
        {
            if (Set(ref _focusDepth, value))
            {
                OnPropertyChanged(nameof(IsFocused));
                Rebuild();
            }
        }
    }

    public bool IsFocused => FocusDepth > 0;

    public IReadOnlyList<int> NodeLimits { get; } = [100, 200, 400, 800, 1500, 5000];

    public int MaxNodes
    {
        get => _maxNodes;
        set
        {
            if (Set(ref _maxNodes, value))
            {
                Rebuild();
            }
        }
    }

    public Task ActivateAsync()
    {
        if (_shown.Nodes.Count == 0 && _full.Nodes.Count > 0)
        {
            Rebuild();
        }
        return Task.CompletedTask;
    }

    public void OnIndexChanged()
    {
        _full = _workspace.Index?.Graph ?? new KnowledgeGraph();
        TypeFilters.Clear();
        foreach (var (type, count) in _full.TypeCounts().OrderBy(t => t.Key, StringComparer.Ordinal))
        {
            TypeFilters.Add(new ConceptTypeFilter(type, count, this));
        }
        Selected = null;
        OnPropertyChanged(nameof(IsEmpty));
        _grouping = null;
        _openGroup = null;
        Groups.Clear();
        NotifyGrouping();
        _scoped = null;
        _scopedText = null;
        Notify(nameof(IsScoped), nameof(ScopeSummary));
        Rebuild();
        _ = LoadGroupingAsync();
    }

    /// <summary>A grouping saved earlier comes back (concepts no longer in the graph are left out).</summary>
    private async Task LoadGroupingAsync()
    {
        _hasModel = (await _workspace.Main.Engine.Models.GetStatusAsync()).Configured;
        Notify(nameof(GroupButtonText), nameof(GroupInstructionsHint), nameof(GroupButtonTooltip), nameof(ShowButtonText), nameof(ShowButtonTooltip));
        var saved = await _workspace.Main.Engine.GraphGroups.LoadAsync(_workspace.Record.Id);
        if (saved is null || _full.Nodes.Count == 0)
        {
            return;
        }
        var ids = _full.Nodes.Select(n => n.Id).ToHashSet(StringComparer.Ordinal);
        foreach (var group in saved.Groups)
        {
            group.Members.RemoveAll(m => !ids.Contains(m));
        }
        saved.Groups.RemoveAll(g => g.Members.Count == 0);
        if (saved.Groups.Count > 0)
        {
            ApplyGrouping(saved);
        }
    }

    public void Rebuild()
    {
        // Capture the settings here; reduce, filter and lay out on a background thread (large graphs take a moment).
        var full = Source;
        var scopeText = _scoped is null ? null : _scopedText;
        var visibleTypes = TypeFilters.Where(f => f.IsVisible).Select(f => f.Type).ToHashSet(StringComparer.Ordinal);
        var allVisible = visibleTypes.Count == TypeFilters.Count;
        var focusId = FocusDepth > 0 ? Selected?.Id : null;
        var focusLabel = Selected?.Label;
        var depth = FocusDepth;
        var maxNodes = MaxNodes;
        if (_grouping is { } grouping)
        {
            var open = _openGroup;
            _ = LayoutAsync(() =>
            {
                var graph = open is null ? GraphGrouper.Overview(grouping) : GraphGrouper.Members(full, open);
                var summary = open is null
                    ? $"{grouping.Groups.Count} groups · {grouping.Links.Count} links between them. Double-click a group to open it."
                    : $"{open.Name}: {graph.Nodes.Count} concepts, {graph.Edges.Count} links.";
                return (graph, GraphLayout.Compute(graph), summary);
            });
            return;
        }
        _ = LayoutAsync(() =>
        {
            KnowledgeGraph graph = focusId is not null
                ? GraphBuilder.Focus(full, focusId, depth)
                : allVisible ? GraphBuilder.Reduce(full, maxNodes) : GraphBuilder.Reduce(full, maxNodes, visibleTypes);
            if (!allVisible)
            {
                var keep = graph.Nodes.Where(n => visibleTypes.Contains(n.Type)).Select(n => n.Id).ToHashSet(StringComparer.Ordinal);
                graph = new KnowledgeGraph { Nodes = graph.Nodes.Where(n => keep.Contains(n.Id)).ToList(), Edges = graph.Edges.Where(e => keep.Contains(e.From) && keep.Contains(e.To)).ToList() };
            }
            var within = scopeText is null ? "" : $" in “{scopeText}”";
            var summary = graph.Nodes.Count == full.Nodes.Count
                ? $"{full.Nodes.Count:N0} concepts{within}."
                : $"{graph.Nodes.Count:N0} of {full.Nodes.Count:N0} concepts{within} shown" + (focusId is not null ? $" (around {focusLabel})." : " (the most connected).");
            return (graph, GraphLayout.Compute(graph), summary);
        });
    }

    private async Task LayoutAsync(Func<(KnowledgeGraph Graph, Dictionary<string, NodePosition> Positions, string Summary)> work)
    {
        _layoutCts?.Cancel();
        var cts = _layoutCts = new CancellationTokenSource();
        IsLayingOut = true;
        try
        {
            var (graph, positions, summary) = await Task.Run(work, cts.Token);
            if (cts.IsCancellationRequested)
            {
                return;
            }
            _shown = graph;
            Summary = summary;
            GraphReady?.Invoke(this, (graph, positions));
            if (Selected is not null)
            {
                SelectRequested?.Invoke(this, Selected.Id);
            }
        }
        catch (OperationCanceledException)
        {
        }
        finally
        {
            if (!cts.IsCancellationRequested)
            {
                IsLayingOut = false;
            }
        }
    }

    public void SelectNode(string id, bool center)
    {
        var node = _full.Find(id);
        if (node is null)
        {
            return;
        }
        if (_shown.Find(id) is null && _grouping?.GroupOf(id) is { } home)
        {
            // Grouped: open the group the concept is in, then select it there.
            OpenGroup(home);
            Selected = node;
            return;
        }
        if (_shown.Find(id) is null)
        {
            // Not drawn (filtered or reduced away): focus on it.
            Selected = node;
            if (FocusDepth == 0)
            {
                FocusDepth = 1;
            }
            else
            {
                Rebuild();
            }
            return;
        }
        Selected = node;
        if (center)
        {
            SelectRequested?.Invoke(this, id);
        }
    }

    /// <summary>Called by the view when the canvas selection changes.</summary>
    public void OnCanvasSelected(GraphNode? node)
    {
        if (node?.Id == Selected?.Id)
        {
            return;
        }
        Selected = node is null ? null : _full.Find(node.Id) ?? node;
        if (FocusDepth > 0 && node is not null)
        {
            Rebuild();
        }
    }

    public void Open(GraphNode node)
    {
        if (node.Type == ConceptTypes.Group && _grouping?.Groups.FirstOrDefault(g => g.Id == node.Key) is { } group)
        {
            OpenGroup(group);
            return;
        }
        if (node.Type == ConceptTypes.DocumentationPage && node.Key is not null)
        {
            _workspace.Main.Navigate(Section.Documentation);
            _workspace.Documentation.OpenPage(node.Key, null);
        }
        else if (node.Path is not null)
        {
            _workspace.Main.Navigate(Section.Documentation);
            _workspace.Documentation.OpenFile(node.Path, node.Line ?? 0);
        }
    }

    private void AskAboutSelected()
    {
        if (Selected is null)
        {
            return;
        }
        _workspace.Main.Navigate(Section.Documentation);
        _workspace.Main.AssistantVisible = true;
        _workspace.Assistant.Input = $"What is {Selected.Label} responsible for, and what depends on it?";
        _workspace.Assistant.FocusInput = false;
        _workspace.Assistant.FocusInput = true;
    }

    /// <summary>Set by the view: the positions currently drawn (including dragged nodes).</summary>
    public Func<IReadOnlyDictionary<string, NodePosition>>? CurrentPositions { get; set; }

    private async Task DownloadAsync()
    {
        var dialog = new Microsoft.Win32.SaveFileDialog
        {
            FileName = $"{_workspace.Title}-graph.svg",
            Filter = "SVG image (*.svg)|*.svg",
            AddExtension = true,
        };
        if (dialog.ShowDialog() != true)
        {
            return;
        }
        var positions = CurrentPositions?.Invoke();
        var svg = SvgGraphWriter.Write(_shown, positions, $"{_workspace.Title} — knowledge graph");
        await File.WriteAllTextAsync(dialog.FileName, svg);
        Ui.Notify("Saved " + Path.GetFileName(dialog.FileName));
    }
}

/// <summary>An entry of the graph's "Reach" list.</summary>
public sealed record ReachChoice(string Key, string Label, string Description)
{
    public override string ToString() => Label;
}
