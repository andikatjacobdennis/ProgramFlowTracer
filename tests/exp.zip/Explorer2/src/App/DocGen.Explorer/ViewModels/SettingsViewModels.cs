using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows.Input;
using DocGen.Explorer.Engine.Ai;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Infrastructure;
using DocGen.Core.Abstractions;

namespace DocGen.Explorer.ViewModels;

public sealed class BarViewModel(string label, string value, double fraction)
{
    public string Label { get; } = label;
    public string Value { get; } = value;
    public double Percent { get; } = Math.Clamp(fraction * 100, 0, 100);
}

/// <summary>Token usage: what the configured model was asked to do, and what it cost.</summary>
public sealed class UsageViewModel : ObservableObject, IActivatable
{
    private readonly MainViewModel _main;
    private int _days = 30;
    private UsageSummary _summary = new();

    public UsageViewModel(MainViewModel main)
    {
        _main = main;
        SetRangeCommand = new AsyncCommand(async p =>
        {
            if (int.TryParse(p as string, out var days))
            {
                Days = days;
                await ActivateAsync();
            }
        });
        ExportCommand = new AsyncCommand(ExportAsync, () => _summary.Calls > 0);
        ClearCommand = new AsyncCommand(ClearAsync, () => _summary.Calls > 0);
        main.Engine.Usage.Changed += (_, _) => Ui.Post(() => { if (main.Section == Section.Usage) { _ = ActivateAsync(); } });
    }

    public ICommand SetRangeCommand { get; }
    public ICommand ExportCommand { get; }
    public ICommand ClearCommand { get; }

    /// <summary>The calls of the range: searched, filtered, sorted and paged.</summary>
    public UsageCallsTable Table { get; } = new();

    /// <summary>Tokens per day over the whole range, input and output stacked.</summary>
    public IReadOnlyList<Controls.ChartColumn> DayColumns { get; private set; } = [];

    public IReadOnlyList<System.Windows.Media.Brush> DaySeries { get; } = [ChartPalette.Input, ChartPalette.Output];

    public IReadOnlyList<Controls.ChartSlice> FeatureSlices { get; private set; } = [];
    public IReadOnlyList<Controls.ChartSlice> ModelSlices { get; private set; } = [];

    public string CallsHeading => $"Calls · {_summary.Calls:N0}";

    private Dictionary<string, string> _repositoryNames = new(StringComparer.Ordinal);
    private Dictionary<string, string> _providerNames = new(StringComparer.Ordinal);

    /// <summary>Opens everything recorded about a call in a window.</summary>
    public void OpenDetails(UsageRowViewModel row)
    {
        var entry = row.Entry;
        var details = new UsageDetailsViewModel(entry,
            entry.RepositoryId is null ? null : _repositoryNames.GetValueOrDefault(entry.RepositoryId),
            _providerNames.GetValueOrDefault(entry.ProviderId));
        Views.UsageDetailsWindow.Show(details, System.Windows.Application.Current?.MainWindow);
    }
    public ObservableCollection<BarViewModel> ByFeature { get; } = [];
    public ObservableCollection<BarViewModel> ByModel { get; } = [];
    public ObservableCollection<BarViewModel> ByDay { get; } = [];

    public int Days
    {
        get => _days;
        private set => Set(ref _days, value);
    }

    public bool IsEmpty => _summary.Calls == 0;
    public bool HasData => _summary.Calls > 0;
    public string Calls => _summary.Calls.ToString("N0");
    public string InputTokens => _summary.InputTokens.ToString("N0");
    public string OutputTokens => _summary.OutputTokens.ToString("N0");
    public string TotalTokens => _summary.TotalTokens.ToString("N0");
    public string Cost => _summary.Cost == 0 ? "—" : _summary.Cost.ToString("0.0000");
    public string Failures => _summary.Failures == 0 ? "none" : _summary.Failures.ToString("N0");
    public bool HasFailures => _summary.Failures > 0;

    /// <summary>The calls table with only the failed calls (each says why it failed).</summary>
    public ICommand ShowFailedCommand => new RelayCommand(() =>
    {
        Table.FailedOnly = true;
        ScrollToCalls?.Invoke();
    });

    /// <summary>The view scrolls down to the calls table.</summary>
    public event Action? ScrollToCalls;

    public async Task ActivateAsync()
    {
        _summary = await _main.Engine.Usage.SummarizeAsync(Days);
        _repositoryNames = (await _main.Engine.Repositories.ListAsync()).ToDictionary(r => r.Id, r => r.Title, StringComparer.Ordinal);
        _providerNames = (await _main.Engine.Models.Ai.GetAsync()).Providers.ToDictionary(p => p.Id, p => p.Name, StringComparer.Ordinal);
        // Charts: every day of the range; shares by feature and by model (each keeps one colour).
        var spanLabel = Days <= 31 ? "d MMM" : "d MMM";
        DayColumns = _summary.TokensByDayDetail.Select(d => new Controls.ChartColumn(
            d.Key.ToString(spanLabel, System.Globalization.CultureInfo.CurrentCulture),
            $"{d.Key:dddd d MMM}\n{d.Value.Input + d.Value.Output:N0} tokens — {d.Value.Input:N0} in, {d.Value.Output:N0} out",
            [d.Value.Input, d.Value.Output])).ToList();
        // Features and models start further along the palette than input (blue) and output (orange).
        FeatureSlices = Slices(_summary.TokensByFeature, 2);
        ModelSlices = Slices(_summary.TokensByModel, 5);
        var featureBrushes = FeatureSlices.ToDictionary(s => s.Label, s => s.Brush, StringComparer.Ordinal);
        var modelBrushes = ModelSlices.ToDictionary(s => s.Label, s => s.Brush, StringComparer.Ordinal);
        System.Windows.Media.Brush FeatureBrush(string key) => featureBrushes.GetValueOrDefault(key) ?? ChartPalette.At(7);
        System.Windows.Media.Brush ModelBrush(string key) => modelBrushes.GetValueOrDefault(key) ?? ChartPalette.At(7);
        Table.Load(_summary.Entries.Select(e => new UsageRowViewModel(e, this) { FeatureBrush = FeatureBrush(e.Feature), ModelBrush = ModelBrush(e.ModelId) }),
            FeatureBrush, ModelBrush);
        Notify(nameof(DayColumns), nameof(FeatureSlices), nameof(ModelSlices), nameof(CallsHeading));
        Fill(ByFeature, _summary.TokensByFeature);
        Fill(ByModel, _summary.TokensByModel);
        ByDay.Clear();
        var max = _summary.TokensByDay.Values.DefaultIfEmpty(0).Max();
        foreach (var (day, tokens) in _summary.TokensByDay)
        {
            ByDay.Add(new BarViewModel(day.ToString("d MMM"), tokens.ToString("N0"), max == 0 ? 0 : (double)tokens / max));
        }
        Notify(nameof(IsEmpty), nameof(HasData), nameof(Calls), nameof(InputTokens), nameof(OutputTokens), nameof(TotalTokens), nameof(Cost), nameof(Failures), nameof(HasFailures));
        CommandManager.InvalidateRequerySuggested();
    }

    private static List<Controls.ChartSlice> Slices(Dictionary<string, long> values, int offset)
    {
        var total = Math.Max(1, values.Values.Sum());
        return values.OrderByDescending(v => v.Value).ThenBy(v => v.Key, StringComparer.Ordinal)
            .Select((v, i) => new Controls.ChartSlice(v.Key, v.Value, ChartPalette.At(i + offset)) { Share = (double)v.Value / total }).ToList();
    }

    private static void Fill(ObservableCollection<BarViewModel> target, Dictionary<string, long> values)
    {
        target.Clear();
        var max = values.Values.DefaultIfEmpty(0).Max();
        foreach (var (label, tokens) in values.OrderByDescending(v => v.Value))
        {
            target.Add(new BarViewModel(label, tokens.ToString("N0"), max == 0 ? 0 : (double)tokens / max));
        }
    }

    private async Task ExportAsync()
    {
        var dialog = new Microsoft.Win32.SaveFileDialog
        {
            FileName = $"docgen-usage-{Days}d",
            Filter = "CSV (*.csv)|*.csv|JSON (*.json)|*.json",
            AddExtension = true,
        };
        if (dialog.ShowDialog() != true)
        {
            return;
        }
        await ExportToAsync(dialog.FileName);
        Ui.Notify("Saved " + Path.GetFileName(dialog.FileName));
    }

    /// <summary>Writes the range's calls as CSV, or as JSON when the file ends in .json.</summary>
    internal async Task ExportToAsync(string path)
    {
        var text = path.EndsWith(".json", StringComparison.OrdinalIgnoreCase)
            ? System.Text.Json.JsonSerializer.Serialize(_summary.Entries, DocGen.Core.Json.DocGenJson.Storage)
            : UsageService.ToCsv(_summary.Entries);
        await File.WriteAllTextAsync(path, text);
    }

    private async Task ClearAsync()
    {
        if (await _main.ConfirmAsync("Clear the usage record?", "Every recorded call is deleted. This cannot be undone.", null, "Clear"))
        {
            await _main.Engine.Usage.ClearAsync();
            await ActivateAsync();
        }
    }
}

public sealed class ModelChoice(string? id, string label, string detail)
{
    public string? Id { get; } = id;
    public string Label { get; } = label;
    public string Detail { get; } = detail;
}

public sealed class PriceRow(string modelId) : ObservableObject
{
    private decimal _input;
    private decimal _output;

    public string ModelId { get; } = modelId;

    public decimal Input
    {
        get => _input;
        set => Set(ref _input, value);
    }

    public decimal Output
    {
        get => _output;
        set => Set(ref _output, value);
    }
}

/// <summary>Settings: AI providers and models (settings/ai.json), the chat model, appearance, prices and data.</summary>
public sealed class SettingsViewModel : ObservableObject, IActivatable
{
    private ModelChoice? _selected;
    private string _status = "";
    private bool _describeGraph = true;
    private string? _testResult;
    private bool _loading;
    private bool _isDirty;
    private string _aiStatus = "";

    public SettingsViewModel(MainViewModel main)
    {
        Main = main;
        TestCommand = new AsyncCommand(TestAsync, () => Selected?.Id is not null);
        ImportProvidersCommand = new AsyncCommand(ImportProvidersAsync);
        OpenSettingsFolderCommand = new RelayCommand(() => Open(Path.Combine(main.Engine.Store.Root, "settings")));
        OpenDataFolderCommand = new RelayCommand(() => Open(main.Engine.Store.Root));
        SavePricesCommand = new AsyncCommand(SavePricesAsync);
        SetThemeCommand = new AsyncCommand(async p =>
        {
            var mode = p as string ?? "auto";
            ThemeManager.Apply(mode);
            await main.Engine.Models.UpdateExplorerSettingsAsync(s => s.Theme = mode);
            Ui.Notify(ThemeManager.Describe(mode));
        });
        SaveAiCommand = new AsyncCommand(async () => await SaveAiAsync(quiet: false));
        RevertAiCommand = new AsyncCommand(ActivateAsync, () => IsDirty);
        Skills = new SkillsSettingsViewModel(main);
        Data = new DataSettingsViewModel(main);
        Confluence = new ConfluenceSettingsViewModel(main);
        Groups = BuildNavigation();
        Confluence.DirtyChanged += dirty =>
        {
            if (NavItems.FirstOrDefault(i => i.Key == SettingsPages.Confluence) is { } item)
            {
                item.HasBadge = dirty;
            }
        };
        ShowPage(SettingsPages.Appearance);
    }

    private string _page = SettingsPages.Appearance;
    private SettingsNavItem? _current;

    /// <summary>The sidebar, grouped as GitHub groups its settings.</summary>
    public IReadOnlyList<SettingsNavGroup> Groups { get; }

    private IEnumerable<SettingsNavItem> NavItems => Groups?.SelectMany(g => g.Items) ?? [];

    /// <summary>The page on show (one of <see cref="SettingsPages"/>).</summary>
    public string Page
    {
        get => _page;
        private set => Set(ref _page, value);
    }

    public SettingsNavItem? Current
    {
        get => _current;
        private set => Set(ref _current, value);
    }

    /// <summary>Shows a page of Settings (unknown keys show Appearance).</summary>
    public void ShowPage(string key)
    {
        var item = NavItems.FirstOrDefault(i => !i.IsLink && i.Key == key) ?? NavItems.First(i => !i.IsLink);
        foreach (var other in NavItems)
        {
            other.IsSelected = ReferenceEquals(other, item);
        }
        Current = item;
        Page = item.Key;
        if (item.Key == SettingsPages.Confluence && !Confluence.IsDirty)
        {
            _ = Confluence.LoadAsync();
        }
        if (item.Key == SettingsPages.Data)
        {
            _ = Data.LoadAsync();
        }
    }

    /// <summary>Settings → Reading and writing (saved as soon as they change).</summary>
    public UiPreferences Prefs => UiPreferences.Current;

    public ICommand ResetPrefsCommand => new RelayCommand(() => UiPreferences.Current.Load(new ExplorerSettings()));

    private IReadOnlyList<SettingsNavGroup> BuildNavigation()
    {
        void Select(SettingsNavItem item)
        {
            if (item.IsLink)
            {
                Main.Navigate(Section.Usage);
            }
            else
            {
                ShowPage(item.Key);
            }
        }
        SettingsNavItem Item(string key, string title, string glyph, string description, bool link = false) => new(key, title, glyph, description, Select, link);
        return
        [
            new(null,
            [
                Item(SettingsPages.Appearance, "Appearance", Icons.Sun, "How the explorer looks: follow Windows, or always light or dark."),
                Item(SettingsPages.Shortcuts, "Shortcuts", Icons.Keyboard, "Keys for what you do most. Click a shortcut and press the new keys; one set of keys does one thing."),
                Item(SettingsPages.Editing, "Reading and writing", Icons.Edit, "Scrolling, spelling, pasting into Ask, Find, editing files in Docs, file details and the log viewer."),
                Item(SettingsPages.Voice, "Voice", Icons.Volume, "Answers read aloud, Studio conversations, and the microphone for dictating questions."),
                Item(SettingsPages.Attachments, "Attachments", Icons.Attach, "Files attached to questions in Ask: which kinds are read, the largest file, and how much of each is sent to the model."),
            ]),
            new("AI",
            [
                Item(SettingsPages.Model, "Chat model", Icons.Chat, "The model that writes answers, graph descriptions, learning material and Studio conversations."),
                Item(SettingsPages.Providers, "Providers and models", Icons.Globe, "The providers and models allowed here, from the providers file you import, with their keys."),
                Item(SettingsPages.Skills, "Skills", Icons.Lightbulb, "How the assistant answers particular kinds of question."),
            ]),
            new("Integrations",
            [
                Item(SettingsPages.Confluence, "Confluence", Icons.Link, "The Confluence sites whose spaces are searched with a repository, and how to sign in to each. Each repository chooses its spaces on its Indexing page."),
            ]),
            new("Billing and usage",
            [
                Item(SettingsPages.Prices, "Prices", Icons.Payment, "Per million tokens, in your currency. Usage shows a cost only for models with a price."),
                Item("usage", "Token usage", Icons.Usage, "", link: true),
            ]),
            new("Data",
            [
                Item(SettingsPages.Data, "Data and storage", Icons.Folder, ""),
            ]),
        ];
    }

    /// <summary>Settings → Confluence: sites and their sign-in.</summary>
    public ConfluenceSettingsViewModel Confluence { get; }

    /// <summary>Settings → Data and storage: removing data and the factory reset.</summary>
    public DataSettingsViewModel Data { get; }

    /// <summary>Settings → Skills.</summary>
    public SkillsSettingsViewModel Skills { get; }

    public MainViewModel Main { get; }

    public ICommand TestCommand { get; }
    /// <summary>Import from file…: the providers file replaces the providers and models (the only way they are added).</summary>
    public ICommand ImportProvidersCommand { get; }

    public ICommand OpenSettingsFolderCommand { get; }
    public ICommand OpenDataFolderCommand { get; }
    public ICommand SavePricesCommand { get; }
    public ICommand SetThemeCommand { get; }
    public ICommand SaveAiCommand { get; }
    public ICommand RevertAiCommand { get; }

    public ObservableCollection<ModelChoice> Models { get; } = [];
    public ObservableCollection<PriceRow> Prices { get; } = [];
    public ObservableCollection<ProviderEditorViewModel> Providers { get; } = [];
    public bool HasProviders => Providers.Count > 0;

    public bool NoProviders => Providers.Count == 0;

    public string DataFolder => Main.Engine.Store.Root;
    public string AiFilePath => Main.Engine.Store.Full(AiSettingsService.Path);
    public string Version => typeof(SettingsViewModel).Assembly.GetName().Version?.ToString(3) ?? "1.0.0";

    public bool IsDirty
    {
        get => _isDirty;
        private set
        {
            if (Set(ref _isDirty, value))
            {
                if (NavItems.FirstOrDefault(i => i.Key == SettingsPages.Providers) is { } providers)
                {
                    providers.HasBadge = value;
                }
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    /// <summary>The result of the last save or the problem preventing it.</summary>
    public string AiStatus
    {
        get => _aiStatus;
        private set => Set(ref _aiStatus, value);
    }

    public ModelChoice? Selected
    {
        get => _selected;
        set
        {
            if (Set(ref _selected, value) && !_loading && value is not null)
            {
                _ = ApplyModelAsync(value.Id);
            }
        }
    }

    public string Status
    {
        get => _status;
        private set => Set(ref _status, value);
    }

    public string? TestResult
    {
        get => _testResult;
        private set => Set(ref _testResult, value);
    }

    // ----- Attachments (Settings → Attachments) -----

    private int _maxAttachments = 10;

    /// <summary>Each kind of file there is a reader for, with its limits.</summary>
    public System.Collections.ObjectModel.ObservableCollection<AttachmentRuleRow> AttachmentRules { get; } = [];

    public IReadOnlyList<int> MaxAttachmentChoices { get; } = [1, 2, 3, 5, 10, 15, 20, 30];

    /// <summary>The most files attached to one question.</summary>
    public int MaxAttachments
    {
        get => _maxAttachments;
        set
        {
            if (Set(ref _maxAttachments, value) && !_loading)
            {
                _ = Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.MaxAttachments = value);
            }
        }
    }

    private void LoadAttachmentRules(ExplorerSettings settings)
    {
        AttachmentRules.Clear();
        foreach (var kind in Engine.Assistant.Attachments.Kinds)
        {
            AttachmentRules.Add(new AttachmentRuleRow(Engine.Assistant.Attachments.RuleFor(settings.AttachmentRules, kind.Kind), SaveAttachmentRules));
        }
        MaxAttachments = MaxAttachmentChoices.Contains(settings.MaxAttachments) ? settings.MaxAttachments : 10;
    }

    private void SaveAttachmentRules()
    {
        if (_loading)
        {
            return;
        }
        var rules = AttachmentRules.Select(r => r.ToRule()).ToList();
        _ = Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.AttachmentRules = rules);
    }

    public ICommand ResetAttachmentRulesCommand => new RelayCommand(() =>
    {
        var defaults = new ExplorerSettings();
        LoadAttachmentRules(defaults);
        SaveAttachmentRules();
        MaxAttachments = defaults.MaxAttachments;
    });

    // ----- Microphone (Settings → Voice) -----

    private bool _dictationEnabled = true;

    /// <summary>Questions can be dictated (the microphone button shows in Ask).</summary>
    public bool DictationEnabled
    {
        get => _dictationEnabled;
        set
        {
            if (Set(ref _dictationEnabled, value))
            {
                Main.SetDictation(value);
                Notify(nameof(MicrophoneStatus));
                if (!_loading)
                {
                    _ = Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.DictationEnabled = value);
                }
            }
        }
    }

    /// <summary>Why the microphone button is not shown in Ask, if it is not.</summary>
    public string? MicrophoneStatus => !DictationEnabled ? "The microphone button is hidden in Ask."
        : Infrastructure.Microphone.Unavailable() is { } reason ? reason + " The microphone button shows in Ask once one can be used." : null;

    private const string HoldToTalk = "Hold the microphone button to talk";
    private const string ClickToTalk = "Click to start, click again to stop";
    private const string WindowsLanguage = "Windows default";
    private string _microphone = Infrastructure.Microphone.WindowsDefault;
    private string _microphoneMode = ClickToTalk;
    private bool _dictationSends;
    private string _dictationLanguage = WindowsLanguage;
    private double _microphoneLevel;
    private string? _microphoneTest;
    private bool _testingMicrophone;

    /// <summary>The Windows default, then each microphone Windows lists.</summary>
    public IReadOnlyList<string> MicrophoneChoices { get; } = [Infrastructure.Microphone.WindowsDefault, .. Infrastructure.Microphone.Devices()];

    public IReadOnlyList<string> MicrophoneModeChoices { get; } = [ClickToTalk, HoldToTalk];

    private const string OnlineEngine = "Windows online speech recognition (Microsoft, most accurate)";
    private const string WhisperEngine = "Whisper on this PC (a local model, no connection)";
    private const string OfflineEngine = "Windows offline recogniser on this PC (basic)";
    private string _dictationEngine = WhisperEngine;
    private string? _defaultMicrophone;

    public IReadOnlyList<string> DictationEngineChoices { get; } = [WhisperEngine, OnlineEngine, OfflineEngine];

    /// <summary>Online (Windows' cloud engine; the Windows default microphone) or offline (the microphone chosen here).</summary>
    public string DictationEngine
    {
        get => _dictationEngine;
        set
        {
            if (Set(ref _dictationEngine, value ?? WhisperEngine))
            {
                var online = _dictationEngine == OnlineEngine;
                var whisper = _dictationEngine == WhisperEngine;
                Main.Speech.DictationOnline = online;
                Main.Speech.DictationWhisper = whisper;
                Notify(nameof(DictationIsOnline), nameof(DictationIsOffline), nameof(DictationIsWhisper), nameof(DictationLanguageChoices));
                if (!DictationLanguageChoices.Contains(DictationLanguage))
                {
                    DictationLanguage = WindowsLanguage;
                }
                if (!_loading)
                {
                    _ = Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.DictationEngine = online ? "online" : whisper ? "whisper" : "offline");
                }
            }
        }
    }

    public bool DictationIsOnline => _dictationEngine == OnlineEngine;

    /// <summary>A microphone is chosen here (Whisper and the offline recogniser record it themselves).</summary>
    public bool DictationIsOffline => !DictationIsOnline;

    public bool DictationIsWhisper => _dictationEngine == WhisperEngine;

    // ----- Whisper models (downloaded into %LOCALAPPDATA%\DocGen.Explorer\Models\whisper) -----

    private WhisperModel _whisperModel = WhisperDictation.ModelFor(null);
    private double _whisperProgress;
    private bool _downloadingWhisper;
    private CancellationTokenSource? _whisperDownload;

    public IReadOnlyList<WhisperModel> WhisperModels => WhisperDictation.Models.ToList();

    public WhisperModel WhisperModel
    {
        get => _whisperModel;
        set
        {
            if (value is not null && Set(ref _whisperModel, value))
            {
                Main.Speech.WhisperModelId = value.Id;
                Notify(nameof(WhisperModelStatus), nameof(WhisperModelInstalled), nameof(WhisperModelMissing));
                if (!_loading)
                {
                    _ = Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.WhisperModel = value.Id);
                }
            }
        }
    }

    public bool WhisperModelInstalled => WhisperModel.IsInstalled;
    public bool WhisperModelMissing => !WhisperModel.IsInstalled && !DownloadingWhisper;

    public string WhisperModelStatus => DownloadingWhisper ? $"Downloading {WhisperModel.Name}: {WhisperProgress:P0} of {WhisperModel.SizeText}…"
        : WhisperModel.IsInstalled ? $"{WhisperModel.Name} is installed ({WhisperModel.SizeText}). {WhisperModel.Description} Your words appear as you speak, transcribed on this PC, and are finished when you stop."
        : $"{WhisperModel.Name} is not downloaded yet ({WhisperModel.SizeText}, from Hugging Face). {WhisperModel.Description}";

    public double WhisperProgress
    {
        get => _whisperProgress;
        private set
        {
            if (Set(ref _whisperProgress, value))
            {
                OnPropertyChanged(nameof(WhisperModelStatus));
            }
        }
    }

    public bool DownloadingWhisper
    {
        get => _downloadingWhisper;
        private set
        {
            if (Set(ref _downloadingWhisper, value))
            {
                Notify(nameof(WhisperModelStatus), nameof(WhisperModelMissing));
            }
        }
    }

    public ICommand DownloadWhisperCommand => new AsyncCommand(async () =>
    {
        var model = WhisperModel;
        _whisperDownload = new CancellationTokenSource();
        DownloadingWhisper = true;
        WhisperProgress = 0;
        try
        {
            await WhisperDictation.DownloadAsync(model, new Progress<double>(p => WhisperProgress = p), _whisperDownload.Token);
            Ui.Notify($"{model.Name} is installed: dictation can use it now.");
        }
        catch (OperationCanceledException)
        {
            Ui.Notify("The download was stopped.");
        }
        catch (Exception ex) when (ex is HttpRequestException or IOException or UnauthorizedAccessException)
        {
            Ui.Notify("The model could not be downloaded: " + ex.Message);
        }
        finally
        {
            DownloadingWhisper = false;
            Notify(nameof(WhisperModels), nameof(WhisperModelStatus), nameof(WhisperModelInstalled), nameof(WhisperModelMissing));
        }
    });

    public ICommand CancelWhisperDownloadCommand => new RelayCommand(() => _whisperDownload?.Cancel());

    public ICommand RemoveWhisperCommand => new RelayCommand(() =>
    {
        try
        {
            WhisperDictation.Remove(WhisperModel);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            Ui.Notify("The model could not be removed: " + ex.Message);
        }
        Notify(nameof(WhisperModels), nameof(WhisperModelStatus), nameof(WhisperModelInstalled), nameof(WhisperModelMissing));
    });

    public ICommand OpenWhisperFolderCommand => new RelayCommand(() =>
    {
        Directory.CreateDirectory(WhisperDictation.ModelFolder);
        OpenWindows("explorer.exe", $"\"{WhisperDictation.ModelFolder}\"");
    });

    /// <summary>The Windows default microphone (what online recognition listens to).</summary>
    public string DefaultMicrophoneText => _defaultMicrophone is { Length: > 0 } name
        ? $"Online recognition listens to the Windows default microphone: {name}. To use another one, choose it in Windows' sound settings (Input)."
        : "Online recognition listens to the Windows default microphone, chosen in Windows' sound settings (Input).";

    /// <summary>Finds the Windows default microphone's name (it can change while the app runs).</summary>
    public async Task RefreshDefaultMicrophoneAsync()
    {
        _defaultMicrophone = await OnlineDictation.DefaultMicrophoneAsync();
        OnPropertyChanged(nameof(DefaultMicrophoneText));
    }

    // Windows' own microphone settings (the person changes them there).
    public ICommand OpenSoundSettingsCommand => new RelayCommand(() => OpenWindows("ms-settings:sound"));
    public ICommand OpenRecordingDevicesCommand => new RelayCommand(() => OpenWindows("control.exe", "mmsys.cpl,,1"));
    public ICommand OpenSpeechSettingsCommand => new RelayCommand(() => OpenWindows("ms-settings:privacy-speech"));
    public ICommand OpenMicrophonePrivacyCommand => new RelayCommand(() => OpenWindows("ms-settings:privacy-microphone"));

    private static void OpenWindows(string target, string? arguments = null)
    {
        try
        {
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(target) { Arguments = arguments ?? "", UseShellExecute = true });
        }
        catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or InvalidOperationException)
        {
            Ui.Notify("Windows' settings could not be opened: " + ex.Message);
        }
    }
    public ICommand RefreshDefaultMicrophoneCommand => new AsyncCommand(async () =>
    {
        await RefreshDefaultMicrophoneAsync();
        Main.RefreshMicrophone();
        Notify(nameof(MicrophoneStatus));
    });

    /// <summary>Windows' language, then each language the chosen engine can dictate.</summary>
    public IReadOnlyList<string> DictationLanguageChoices => DictationIsOnline
        ? [WindowsLanguage, .. _onlineLanguages ??= OnlineDictation.Languages()]
        : DictationIsWhisper
            ? [WindowsLanguage, .. _onlineLanguages ??= OnlineDictation.Languages(), .. WhisperLanguages.Except(_onlineLanguages)]
            : [WindowsLanguage, .. _offlineLanguages ??= SpeechService.DictationLanguages()];

    // Common languages a multilingual Whisper model is told (it can also detect the language: Windows default).
    private static readonly string[] WhisperLanguages = ["en", "de", "es", "fr", "it", "pt", "nl", "hi", "ja", "zh", "ko", "ru", "ar", "pl", "sv", "tr"];

    private IReadOnlyList<string>? _onlineLanguages;
    private IReadOnlyList<string>? _offlineLanguages;

    public string Microphone
    {
        get => _microphone;
        set
        {
            if (Set(ref _microphone, value ?? Infrastructure.Microphone.WindowsDefault))
            {
                var name = _microphone == Infrastructure.Microphone.WindowsDefault ? "" : _microphone;
                Main.Speech.MicrophoneName = name;
                if (!_loading)
                {
                    _ = Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.MicrophoneDevice = name);
                }
            }
        }
    }

    public string MicrophoneMode
    {
        get => _microphoneMode;
        set
        {
            if (Set(ref _microphoneMode, value ?? ClickToTalk))
            {
                var toggle = _microphoneMode == ClickToTalk;
                Main.Speech.MicrophoneToggles = toggle;
                if (!_loading)
                {
                    _ = Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.MicrophoneMode = toggle ? "toggle" : "hold");
                }
            }
        }
    }

    private int _silenceStopSeconds = 5;

    /// <summary>The choices for <see cref="SilenceStopSeconds"/> (0: never).</summary>
    public IReadOnlyList<int> SilenceStopChoices { get; } = [0, 2, 3, 5, 8, 10, 15, 30];

    /// <summary>Dictation stops by itself after this many seconds without sound (0: never).</summary>
    public int SilenceStopSeconds
    {
        get => _silenceStopSeconds;
        set
        {
            if (Set(ref _silenceStopSeconds, value))
            {
                Main.Speech.SilenceStopSeconds = value;
                if (!_loading)
                {
                    _ = Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.SilenceStopSeconds = value);
                }
            }
        }
    }

    /// <summary>A dictated question is sent as soon as dictation stops.</summary>
    public bool DictationSends
    {
        get => _dictationSends;
        set
        {
            if (Set(ref _dictationSends, value))
            {
                Main.Speech.DictationSends = value;
                if (!_loading)
                {
                    _ = Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.DictationSends = value);
                }
            }
        }
    }

    public string DictationLanguage
    {
        get => _dictationLanguage;
        set
        {
            if (Set(ref _dictationLanguage, value ?? WindowsLanguage))
            {
                var culture = _dictationLanguage == WindowsLanguage ? "" : _dictationLanguage;
                Main.Speech.DictationLanguage = culture;
                if (!_loading)
                {
                    _ = Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.DictationLanguage = culture);
                }
            }
        }
    }

    /// <summary>The sound level while the microphone is tested (0–1).</summary>
    public double MicrophoneLevel
    {
        get => _microphoneLevel;
        private set => Set(ref _microphoneLevel, value);
    }

    /// <summary>What the microphone test heard.</summary>
    public string? MicrophoneTest
    {
        get => _microphoneTest;
        private set => Set(ref _microphoneTest, value);
    }

    public bool TestingMicrophone
    {
        get => _testingMicrophone;
        private set
        {
            if (Set(ref _testingMicrophone, value))
            {
                OnPropertyChanged(nameof(TestMicrophoneText));
            }
        }
    }

    public string TestMicrophoneText => TestingMicrophone ? "Listening… say something" : "Test microphone";

    private string _microphoneHeard = "";

    /// <summary>The words heard so far while testing.</summary>
    public string MicrophoneHeard
    {
        get => _microphoneHeard;
        private set => Set(ref _microphoneHeard, value);
    }

    /// <summary>Listens for five seconds with the chosen microphone and language, showing the level, then what was heard.</summary>
    public ICommand TestMicrophoneCommand => new AsyncCommand(async () =>
    {
        var speech = Main.Speech;
        MicrophoneTest = null;
        MicrophoneHeard = "";
        await RefreshDefaultMicrophoneAsync();
        void OnHeard(string text) => MicrophoneHeard = text;
        speech.Hearing += OnHeard;
        if (!await speech.StartDictationAsync())
        {
            MicrophoneTest = "The microphone could not be started. Check that one is connected and that apps may use it (Windows Settings → Privacy → Microphone).";
            return;
        }
        TestingMicrophone = true;
        var loudest = 0.0;
        var meter = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromMilliseconds(60) };
        meter.Tick += (_, _) =>
        {
            MicrophoneLevel = speech.MicrophoneLevel;
            loudest = Math.Max(loudest, MicrophoneLevel);
        };
        meter.Start();
        try
        {
            await Task.Delay(5000);
        }
        finally
        {
            meter.Stop();
            MicrophoneLevel = 0;
        }
        var heard = await speech.StopDictationAsync();
        speech.Hearing -= OnHeard;
        MicrophoneHeard = "";
        TestingMicrophone = false;
        MicrophoneTest = heard.Length > 0 ? $"Heard: “{heard}”"
            : loudest > 0.02 ? "Sound arrived, but no words were recognised. Speak a little closer, or choose the language you speak."
            : DictationIsOnline
                ? $"No sound arrived from the Windows default microphone{(_defaultMicrophone is { Length: > 0 } name ? $" ({name})" : "")}. Speak while testing, check it is not muted, or choose another one in Windows' sound settings."
                : "No sound arrived from this microphone. Speak while testing, check it is not muted, or choose another one.";
    });

    private int _diagramRepairAttempts = 2;

    /// <summary>The choices for <see cref="DiagramRepairAttempts"/>.</summary>
    public IReadOnlyList<int> DiagramRepairChoices { get; } = [0, 1, 2, 3, 4, 5];

    /// <summary>How many times the model is asked to fix a diagram that could not be drawn (0: never).</summary>
    public int DiagramRepairAttempts
    {
        get => _diagramRepairAttempts;
        set
        {
            if (Set(ref _diagramRepairAttempts, value) && !_loading)
            {
                _ = Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.DiagramRepairAttempts = value);
            }
        }
    }

    private bool _naturalVoices = true;
    private string _readAloudVoice = Engine.Speech.EdgeTts.DefaultVoice;

    /// <summary>Edge's natural voices, then the installed Windows voices.</summary>
    public IReadOnlyList<string> VoiceChoices { get; } = SpeechService.AllVoices();

    public bool NaturalVoices
    {
        get => _naturalVoices;
        set
        {
            if (Set(ref _naturalVoices, value))
            {
                Main.Speech.NaturalVoices = value;
                if (!_loading)
                {
                    _ = Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.NaturalVoices = value);
                }
            }
        }
    }

    public string ReadAloudVoice
    {
        get => _readAloudVoice;
        set
        {
            if (Set(ref _readAloudVoice, value ?? ""))
            {
                Main.Speech.DefaultVoice = value;
                if (!_loading)
                {
                    _ = Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.ReadAloudVoice = value ?? "");
                }
            }
        }
    }

    public ICommand TestVoiceCommand => new RelayCommand(() =>
        Main.Speech.Speak("Hello. This is how answers and conversations about your repository will sound.", ReadAloudVoice));

    public bool DescribeGraph
    {
        get => _describeGraph;
        set
        {
            if (Set(ref _describeGraph, value) && !_loading)
            {
                _ = Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.DescribeGraphWithModel = value);
            }
        }
    }

    public void MarkDirty()
    {
        if (!_loading)
        {
            IsDirty = true;
            AiStatus = "Unsaved changes.";
        }
    }

    public IEnumerable<ModelEditorViewModel> AllModels() => Providers.SelectMany(p => p.Models);

    public async Task ActivateAsync()
    {
        await ReloadAsync();
        // Providers that list their own models (Ollama): ask their servers, then show what they have.
        if (Providers.Any(p => p.CanDiscover && p.Enabled))
        {
            await DiscoverAsync(null);
        }
    }

    /// <summary>Asks the server of one provider (or of all that list their own models) and shows what it has.</summary>
    public async Task DiscoverAsync(string? providerId)
    {
        foreach (var provider in Providers.Where(p => p.CanDiscover && (providerId is null || p.Id == providerId)))
        {
            provider.IsDiscovering = true;
        }
        await Main.Engine.Models.DiscoverModelsAsync(providerId);
        if (IsDirty)
        {
            // A key is being typed: keep it on screen; only the status lines change.
            foreach (var provider in Providers)
            {
                provider.IsDiscovering = false;
                provider.RefreshDiscovery();
            }
            return;
        }
        await ReloadAsync();
        await RefreshAssistantAsync();
    }

    private async Task ReloadAsync()
    {
        _loading = true;
        try
        {
            var ai = await Main.Engine.Models.Ai.GetAsync();
            Providers.Clear();
            foreach (var provider in ai.Providers)
            {
                Providers.Add(new ProviderEditorViewModel(provider, ai.Models.Where(m => m.ProviderId == provider.Id), this));
            }
            await LoadChoicesAsync();
            var settings = await Main.Engine.Models.GetExplorerSettingsAsync();
            DescribeGraph = settings.DescribeGraphWithModel;
            NaturalVoices = settings.NaturalVoices;
            ReadAloudVoice = settings.ReadAloudVoice;
            DiagramRepairAttempts = Math.Clamp(settings.DiagramRepairAttempts, 0, 5);
            LoadAttachmentRules(settings);
            Microphone = MicrophoneChoices.Contains(settings.MicrophoneDevice) ? settings.MicrophoneDevice : Infrastructure.Microphone.WindowsDefault;
            MicrophoneMode = settings.MicrophoneMode == "hold" ? HoldToTalk : ClickToTalk;
            DictationEnabled = settings.DictationEnabled;
            DictationEngine = settings.DictationEngine switch { "offline" => OfflineEngine, "online" => OnlineEngine, _ => WhisperEngine };
            WhisperModel = WhisperDictation.ModelFor(settings.WhisperModel);
            _ = RefreshDefaultMicrophoneAsync();
            DictationSends = settings.DictationSends;
            SilenceStopSeconds = SilenceStopChoices.Contains(settings.SilenceStopSeconds) ? settings.SilenceStopSeconds : 5;
            DictationLanguage = DictationLanguageChoices.Contains(settings.DictationLanguage) ? settings.DictationLanguage : WindowsLanguage;
            await Skills.LoadAsync();
            Notify(nameof(AiFilePath), nameof(HasProviders), nameof(NoProviders));
            IsDirty = false;
            AiStatus = $"Saved in {AiFilePath} (encrypted for your Windows account).";
        }
        finally
        {
            _loading = false;
        }
    }

    private async Task LoadChoicesAsync()
    {
        var wasLoading = _loading;
        _loading = true;
        try
        {
            var settings = await Main.Engine.Models.GetExplorerSettingsAsync();
            var ai = await Main.Engine.Models.Ai.GetAsync();
            Models.Clear();
            Models.Add(new ModelChoice(null, "Evidence mode (no model)", "Answers are composed from the index offline; nothing leaves this PC."));
            foreach (var model in ai.Models)
            {
                var provider = ai.Providers.FirstOrDefault(p => p.Id == model.ProviderId);
                var state = provider is null ? "" : !provider.Enabled || !model.Enabled ? " · off" : provider.NeedsKey && provider.ApiKey.Length == 0 ? " · needs an API key" : "";
                Models.Add(new ModelChoice(model.Id, $"{(string.IsNullOrWhiteSpace(model.DisplayName) ? model.Id : model.DisplayName)} ({model.Id})", $"{provider?.Name}{state}"));
            }
            Selected = Models.FirstOrDefault(m => string.Equals(m.Id, settings.ChatModelId, StringComparison.OrdinalIgnoreCase)) ?? Models[0];
            Prices.Clear();
            foreach (var model in Models.Where(m => m.Id is not null))
            {
                var price = settings.Prices.FirstOrDefault(p => string.Equals(p.ModelId, model.Id, StringComparison.OrdinalIgnoreCase));
                Prices.Add(new PriceRow(model.Id!) { Input = price?.InputPerMillion ?? 0, Output = price?.OutputPerMillion ?? 0 });
            }
            Status = (await Main.Engine.Models.GetStatusAsync()).Description;
        }
        finally
        {
            _loading = wasLoading;
        }
    }

    public async Task RemoveProviderAsync(ProviderEditorViewModel provider)
    {
        if (!await Main.ConfirmAsync($"Remove {provider.Name}?",
                "Its models and its saved API key are removed now. It comes back only by importing a providers file that lists it.", null, "Remove"))
        {
            return;
        }
        if (IsDirty && !await SaveAiAsync(quiet: true))
        {
            return;
        }
        await Main.Engine.Models.RemoveProviderAsync(provider.Id);
        await ActivateAsync();
        await RefreshAssistantAsync();
        Ui.Notify($"{provider.Name} removed.");
    }

    public async Task UseModelAsync(ModelEditorViewModel model)
    {
        if (!await SaveAiAsync(quiet: true))
        {
            return;
        }
        Selected = Models.FirstOrDefault(m => string.Equals(m.Id, model.Id, StringComparison.OrdinalIgnoreCase)) ?? Selected;
        Ui.Notify($"Answers now use {model.DisplayName}.");
    }

    /// <summary>
    /// Saves what may be changed here — API keys and which providers and models are on — to settings/ai.json; returns
    /// false (with the reason in <see cref="AiStatus"/>) when it cannot.
    /// </summary>
    public async Task<bool> SaveAiAsync(bool quiet)
    {
        try
        {
            await Main.Engine.Models.Ai.ApplyEditsAsync(Providers.Select(p => p.ToEdit()).ToList());
        }
        catch (Engine.Repositories.ExplorerValidationException ex)
        {
            AiStatus = ex.Message;
            if (!quiet)
            {
                Main.ShowToast(ex.Message, true);
            }
            return false;
        }
        IsDirty = false;
        AiStatus = $"Saved in {AiFilePath} at {DateTime.Now:HH:mm:ss}.";
        var chosen = await Main.Engine.Models.EnsureChatModelAsync();
        await LoadChoicesAsync();
        await RefreshAssistantAsync();
        if (chosen is not null)
        {
            Ui.Notify($"Answers now use {(string.IsNullOrWhiteSpace(chosen.DisplayName) ? chosen.Id : chosen.DisplayName)}.");
        }
        if (!quiet)
        {
            Ui.Notify("AI settings saved.");
        }
        return true;
    }

    private async Task ApplyModelAsync(string? id)
    {
        await Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.ChatModelId = id);
        Status = (await Main.Engine.Models.GetStatusAsync()).Description;
        TestResult = null;
        if (Main.Workspace is { } workspace)
        {
            await workspace.Assistant.LoadAsync();
        }
    }

    private async Task TestAsync()
    {
        if (Selected?.Id is not { } id)
        {
            return;
        }
        if (IsDirty && !await SaveAiAsync(quiet: true))
        {
            TestResult = "Fix the settings first: " + AiStatus;
            return;
        }
        TestResult = "Asking the model…";
        try
        {
            var result = await Main.Engine.Models.TestAsync(id);
            TestResult = $"✓ The model answered \"{Engine.Text.TextUtil.Truncate(result.Text.Trim(), 60)}\" in {result.DurationMs:N0} ms ({result.InputTokens + result.OutputTokens} tokens).";
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            TestResult = "✕ The model could not be reached: " + ex.Message;
        }
    }

    private async Task RefreshAssistantAsync()
    {
        if (Main.Workspace is { } workspace)
        {
            await workspace.Assistant.LoadAsync();
        }
    }

    /// <summary>Import from file…: the chosen providers file replaces the providers and models.</summary>
    private async Task ImportProvidersAsync()
    {
        var dialog = new Microsoft.Win32.OpenFileDialog { Title = "Import providers and models", Filter = "Encrypted providers file (*.enc)|*.enc|All files (*.*)|*.*" };
        if (dialog.ShowDialog() != true)
        {
            return;
        }
        if (Providers.Count > 0 && !await Main.ConfirmAsync("Replace the providers?",
                "The file's providers and models replace the ones here. A provider the file lists without a key keeps the key already saved for it.",
                Path.GetFileName(dialog.FileName), "Import", danger: false))
        {
            return;
        }
        try
        {
            var result = await Main.Engine.Models.ImportProvidersAsync(await File.ReadAllTextAsync(dialog.FileName));
            await ActivateAsync();
            await RefreshAssistantAsync();
            var answering = await Main.Engine.Models.GetStatusAsync();
            var message = $"Imported {result.Providers} provider{(result.Providers == 1 ? "" : "s")} and {result.Models} model{(result.Models == 1 ? "" : "s")}."
                + (answering.Configured ? $" Answers use {answering.DisplayName}." : "")
                + (result.KeysKept > 0 ? $" {result.KeysKept} saved key{(result.KeysKept == 1 ? " was" : "s were")} kept." : "")
                + (result.NeedKeys.Count > 0 ? $" Paste a key for {string.Join(", ", result.NeedKeys)}." : "");
            AiStatus = message;
            Ui.Notify(message);
        }
        catch (Engine.Repositories.ExplorerValidationException ex)
        {
            AiStatus = "Nothing was imported: " + ex.Message;
            Main.ShowToast(AiStatus, true);
        }
    }

    private async Task SavePricesAsync()
    {
        var rows = Prices.Where(p => p.Input > 0 || p.Output > 0).Select(p => new ModelPrice { ModelId = p.ModelId, InputPerMillion = p.Input, OutputPerMillion = p.Output }).ToList();
        await Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.Prices = rows);
        Ui.Notify("Prices saved. Costs are worked out for calls made from now on.");
    }

    private static void Open(string folder)
    {
        Directory.CreateDirectory(folder);
        Process.Start(new ProcessStartInfo("explorer.exe", $"\"{folder}\"") { UseShellExecute = true });
    }
}

