using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Windows.Threading;
using DocGen.Explorer.Engine.Learning;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

public sealed class TopicOption(string name) : ObservableObject
{
    private bool _isChecked;

    public string Name { get; } = name;

    public bool IsChecked
    {
        get => _isChecked;
        set => Set(ref _isChecked, value);
    }
}

/// <summary>A row in one of the Learning lists, with its item menu.</summary>
public sealed class LearningItemRow(LearningItem item, string kind, LearningViewModel owner)
{
    public LearningItem Item { get; } = item;
    public string Kind { get; } = kind;
    public string Title => Item.Title;
    public string Meta => Kind switch
    {
        "quiz" when Item is Quiz q => $"{q.Questions.Count} questions · {q.CreatedAt.ToLocalTime():d MMM, HH:mm}" + (q.Attempts.Count > 0 ? $" · best {q.Attempts.Max(a => a.Percent):0}%" : ""),
        "path" when Item is LearningPath p => $"{p.Sessions.Count} sessions · {p.Sessions.Count(s => s.Completed)} done",
        "deck" when Item is FlashcardDeck d => $"{d.Cards.Count} cards · {d.Cards.Count(c => c.DueAt <= DateTime.UtcNow)} due",
        "faq" when Item is Faq f => $"{f.Entries.Count} questions",
        _ => "",
    } + (Item.Archived ? " · archived" : "");
    public ICommand OpenCommand => new RelayCommand(() => owner.Open(this));
    public ICommand RenameCommand => new AsyncCommand(() => owner.RenameAsync(Item));
    public ICommand DuplicateCommand => new AsyncCommand(() => owner.DuplicateAsync(Item));
    public ICommand ArchiveCommand => new AsyncCommand(() => owner.ArchiveAsync(Item));
    public ICommand DeleteCommand => new AsyncCommand(() => owner.DeleteAsync(Item));
    public string ArchiveText => Item.Archived ? "Unarchive" : "Archive";
}

public sealed class QuizOptionViewModel(int index, string text, QuizQuestionViewModel question) : ObservableObject
{
    public int Index { get; } = index;
    public string Text { get; } = text;
    public string Letter => ((char)('A' + Index)).ToString();

    public bool IsChosen
    {
        get => question.Chosen == Index;
        set
        {
            if (value && !question.Locked)
            {
                question.Choose(Index);
            }
        }
    }

    /// <summary>correct | wrong | "" — drives the option's colouring once revealed.</summary>
    public string State => !question.Revealed ? "" : Index == question.Question.CorrectIndex ? "correct" : question.Chosen == Index ? "wrong" : "";

    public void Refresh() => Notify(nameof(IsChosen), nameof(State));
}

public sealed class QuizQuestionViewModel : ObservableObject
{
    private int? _chosen;
    private bool _revealed;

    public QuizQuestionViewModel(QuizQuestion question, int number, QuizSessionViewModel session)
    {
        Question = question;
        Number = number;
        Session = session;
        Options = question.Options.Select((o, i) => new QuizOptionViewModel(i, o, this)).ToList();
    }

    public QuizQuestion Question { get; }
    public QuizSessionViewModel Session { get; }
    public int Number { get; }
    public string Prompt => Question.Prompt;
    public string Topic => Question.Topic;
    public IReadOnlyList<QuizOptionViewModel> Options { get; }
    public int? Chosen => _chosen;
    public bool Locked => Revealed && Session.Feedback == FeedbackTiming.AfterEachQuestion;

    public bool Revealed
    {
        get => _revealed;
        set
        {
            if (Set(ref _revealed, value))
            {
                foreach (var option in Options)
                {
                    option.Refresh();
                }
                Notify(nameof(IsCorrect), nameof(Verdict), nameof(Locked));
            }
        }
    }

    public bool IsCorrect => _chosen == Question.CorrectIndex;
    public string Verdict => !Revealed ? "" : IsCorrect ? "Correct." : _chosen is null ? "Not answered." : "Not quite.";
    public string Explanation => Question.Explanation;
    public string CorrectText => Question.Options[Question.CorrectIndex];
    public string? ChosenText => _chosen is { } c ? Question.Options[c] : null;
    public ICommand OpenEvidenceCommand => new RelayCommand(() => Session.OpenEvidence(Question));

    public void Choose(int index)
    {
        _chosen = index;
        foreach (var option in Options)
        {
            option.Refresh();
        }
        // The review after marking shows what was chosen, so it must hear about the change too.
        Notify(nameof(Chosen), nameof(ChosenText), nameof(IsCorrect));
        if (Session.Feedback == FeedbackTiming.AfterEachQuestion)
        {
            Revealed = true;
        }
        Session.OnAnswered(this);
    }
}

/// <summary>Taking a quiz: one question at a time, an optional time limit, feedback as configured, and the marked result.</summary>
public sealed class QuizSessionViewModel : ObservableObject
{
    private readonly LearningViewModel _owner;
    private string _phase = "overview";
    private int _index;
    private QuizAttempt? _result;
    private DateTime _startedAt;
    private int _streak;
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(1) };

    public QuizSessionViewModel(Quiz quiz, LearningViewModel owner)
    {
        Quiz = quiz;
        _owner = owner;
        Questions = quiz.Questions.Select((q, i) => new QuizQuestionViewModel(q, i + 1, this)).ToList();
        StartCommand = new RelayCommand(Start);
        NextCommand = new RelayCommand(() => Index++, () => Index < Questions.Count - 1);
        PreviousCommand = new RelayCommand(() => Index--, () => Index > 0);
        FinishCommand = new AsyncCommand(FinishAsync, () => Phase == "taking");
        RegenerateCommand = new AsyncCommand(() => owner.RegenerateAsync(Quiz));
        _timer.Tick += async (_, _) =>
        {
            OnPropertyChanged(nameof(TimeLeft));
            if (Quiz.Options.TimeLimitMinutes > 0 && DateTime.UtcNow - _startedAt >= TimeSpan.FromMinutes(Quiz.Options.TimeLimitMinutes))
            {
                _timer.Stop();
                Ui.Notify("Time is up: the quiz was marked as it stood.");
                await FinishAsync();
            }
        };
    }

    public Quiz Quiz { get; }
    public IReadOnlyList<QuizQuestionViewModel> Questions { get; }
    public FeedbackTiming Feedback => Quiz.Options.Feedback;

    public ICommand StartCommand { get; }
    public ICommand NextCommand { get; }
    public ICommand PreviousCommand { get; }
    public ICommand FinishCommand { get; }
    public ICommand RegenerateCommand { get; }

    public string Title => Quiz.Title;
    public string Meta => $"{Quiz.Questions.Count} questions · {Quiz.CreatedAt.ToLocalTime():d MMM, HH:mm}";
    public string Provenance => Quiz.Provenance;
    public string PassMark => $"{Quiz.Options.PassMarkPercent}%";
    public string FeedbackText => Feedback == FeedbackTiming.AfterEachQuestion ? "after each question" : "at the end";
    public string TimeLimitText => Quiz.Options.TimeLimitMinutes > 0 ? $"{Quiz.Options.TimeLimitMinutes} min" : "none";
    public string AttemptsText => Quiz.Attempts.Count == 0 ? "Not taken yet." : $"Taken {Quiz.Attempts.Count} time{(Quiz.Attempts.Count == 1 ? "" : "s")}; best {Quiz.Attempts.Max(a => a.Percent):0}%, last {Quiz.Attempts[^1].Percent:0}%.";

    /// <summary>overview | taking | result</summary>
    public string Phase
    {
        get => _phase;
        private set => Set(ref _phase, value);
    }

    public int Index
    {
        get => _index;
        set
        {
            if (Set(ref _index, Math.Clamp(value, 0, Questions.Count - 1)))
            {
                Notify(nameof(Current), nameof(PositionText), nameof(IsLast));
                CommandManager.InvalidateRequerySuggested();
                if (Phase == "taking")
                {
                    _owner.Coach.QuestionShown(Index + 1, Questions.Count);
                }
            }
        }
    }

    public QuizQuestionViewModel? Current => Questions.Count == 0 ? null : Questions[Index];
    public string PositionText => $"Question {Index + 1} of {Questions.Count}";
    public bool IsLast => Index == Questions.Count - 1;
    public int AnsweredCount => Questions.Count(q => q.Chosen is not null);
    public double ProgressPercent => Questions.Count == 0 ? 0 : 100.0 * AnsweredCount / Questions.Count;

    /// <summary>Right answers in a row (only counted when each answer is marked straight away).</summary>
    public int Streak
    {
        get => _streak;
        private set
        {
            if (Set(ref _streak, value))
            {
                Notify(nameof(HasStreak), nameof(StreakText));
            }
        }
    }

    public bool HasStreak => Streak >= 2;
    public string StreakText => $"{Streak} in a row";

    public string TimeLeft
    {
        get
        {
            if (Quiz.Options.TimeLimitMinutes <= 0 || Phase != "taking")
            {
                return "";
            }
            var left = TimeSpan.FromMinutes(Quiz.Options.TimeLimitMinutes) - (DateTime.UtcNow - _startedAt);
            return left <= TimeSpan.Zero ? "0:00" : $"{(int)left.TotalMinutes}:{left.Seconds:00} left";
        }
    }

    public QuizAttempt? Result
    {
        get => _result;
        private set
        {
            if (Set(ref _result, value))
            {
                Notify(nameof(ScoreText), nameof(ScorePercent), nameof(ScoreCaption), nameof(Passed), nameof(ResultVerdict));
            }
        }
    }

    public string ScoreText => Result is null ? "" : $"{Result.Correct} of {Result.Total} · {Result.Percent:0.#}%";
    public double ScorePercent => Result?.Percent ?? 0;
    public string ScoreCaption => Result is null ? "" : $"{Result.Correct} of {Result.Total}";
    public bool Passed => Result?.Passed == true;
    public string ResultVerdict => Result is null ? "" : Result.Passed ? $"Passed — the pass mark is {Quiz.Options.PassMarkPercent}%." : $"Not passed — the pass mark is {Quiz.Options.PassMarkPercent}%.";

    private void Start()
    {
        foreach (var q in Questions)
        {
            q.Revealed = false;
        }
        Phase = "taking";
        _startedAt = DateTime.UtcNow;
        Streak = 0;
        Index = 0;
        Notify(nameof(Current), nameof(PositionText), nameof(AnsweredCount), nameof(ProgressPercent));
        if (Questions.Count > 0)
        {
            _owner.Coach.QuestionShown(1, Questions.Count);
        }
        if (Quiz.Options.TimeLimitMinutes > 0)
        {
            _timer.Start();
        }
    }

    public void OnAnswered(QuizQuestionViewModel question)
    {
        Notify(nameof(AnsweredCount), nameof(ProgressPercent));
        if (Feedback == FeedbackTiming.AfterEachQuestion)
        {
            // Marked at once, so the host can say so (and count the streak).
            Streak = question.IsCorrect ? Streak + 1 : 0;
            if (question.IsCorrect)
            {
                _owner.Coach.Correct(Streak);
            }
            else
            {
                _owner.Coach.Wrong(((char)('A' + question.Question.CorrectIndex)).ToString(), question.CorrectText);
            }
        }
        else if (IsLast)
        {
            // Marked at the end: the host only notes the answer, it never gives it away.
            _owner.Coach.AnswerNoted();
        }
        if (Feedback == FeedbackTiming.AtTheEnd && !IsLast)
        {
            // Move on by itself after a short pause, so a keyboard user can go quickly.
            var pause = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(350) };
            pause.Tick += (_, _) =>
            {
                pause.Stop();
                if (Phase == "taking")
                {
                    Index++;
                }
            };
            pause.Start();
        }
    }

    private async Task FinishAsync()
    {
        if (Phase != "taking")
        {
            return;
        }
        _timer.Stop();
        var answers = Questions.Select(q => q.Chosen ?? -1).ToList();
        var seconds = (long)(DateTime.UtcNow - _startedAt).TotalSeconds;
        Result = await _owner.SubmitAsync(Quiz, answers, seconds);
        foreach (var q in Questions)
        {
            q.Revealed = true;
        }
        Phase = "result";
        Notify(nameof(AttemptsText));
        _owner.Coach.Finished(Result.Passed, Result.Percent);
    }

    public void OpenEvidence(QuizQuestion question)
    {
        if (question.Path is not null)
        {
            _owner.Workspace.OpenLink($"repo:{question.Path}#L{question.Line}");
        }
    }

    public void Stop() => _timer.Stop();
}

public sealed class DeckReviewViewModel : ObservableObject
{
    private readonly LearningViewModel _owner;
    private readonly Queue<Flashcard> _queue;
    private Flashcard? _current;
    private bool _flipped;
    private int _reviewed;
    private int _shown;

    public DeckReviewViewModel(FlashcardDeck deck, LearningViewModel owner)
    {
        Deck = deck;
        _owner = owner;
        _queue = new Queue<Flashcard>(FlashcardScheduler.Due(deck, DateTime.UtcNow));
        FlipCommand = new RelayCommand(() => Flipped = !Flipped, () => Current is not null);
        GradeCommand = new AsyncCommand(async p =>
        {
            if (Current is null || p is not string s || !Enum.TryParse<RecallGrade>(s, out var grade))
            {
                return;
            }
            var reviewed = await owner.ReviewAsync(Deck, Current, grade);
            owner.Coach.Graded(s);
            // Keep the deck's copy in step with what was saved.
            var local = Deck.Cards.First(c => c.Id == reviewed.Id);
            local.DueAt = reviewed.DueAt;
            local.Ease = reviewed.Ease;
            local.IntervalDays = reviewed.IntervalDays;
            local.Repetitions = reviewed.Repetitions;
            if (grade == RecallGrade.Again)
            {
                _queue.Enqueue(local); // see it again this session
            }
            _reviewed++;
            Next();
            if (Current is null)
            {
                owner.Coach.DeckDone();
            }
        }, _ => Flipped);
        Next();
    }

    public FlashcardDeck Deck { get; }
    public ICommand FlipCommand { get; }
    public ICommand GradeCommand { get; }

    public Flashcard? Current
    {
        get => _current;
        private set
        {
            if (Set(ref _current, value))
            {
                Notify(nameof(HasCard), nameof(Remaining), nameof(DoneText));
            }
        }
    }

    public bool HasCard => Current is not null;

    /// <summary>Counts the cards shown this session, so the view can slide each new one in.</summary>
    public int Shown
    {
        get => _shown;
        private set => Set(ref _shown, value);
    }

    public bool Flipped
    {
        get => _flipped;
        set
        {
            if (Set(ref _flipped, value))
            {
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    public string Remaining => $"{_queue.Count + (Current is null ? 0 : 1)} due · {_reviewed} reviewed this session · {Deck.Cards.Count} in the deck";

    public string DoneText
    {
        get
        {
            var next = Deck.Cards.Where(c => c.DueAt > DateTime.UtcNow).OrderBy(c => c.DueAt).FirstOrDefault();
            return next is null ? "Nothing is due." : $"Nothing more is due. The next card comes back {Describe(next.DueAt)}.";
        }
    }

    private static string Describe(DateTime due)
    {
        var span = due - DateTime.UtcNow;
        return span.TotalHours < 1 ? $"in {Math.Max(1, (int)span.TotalMinutes)} minutes" : span.TotalDays < 1 ? $"in {(int)span.TotalHours} hours" : $"on {due.ToLocalTime():ddd d MMM}";
    }

    public ICommand OpenSourceCommand => new RelayCommand(() =>
    {
        if (Current?.Path is { } path)
        {
            _owner.Workspace.OpenLink($"repo:{path}#L{Current.Line}");
        }
    });

    private void Next()
    {
        Flipped = false;
        Current = _queue.Count > 0 ? _queue.Dequeue() : null;
        Shown++;
        Notify(nameof(Remaining));
    }
}

public sealed class MasteryViewModel(MasteryEntry entry)
{
    public string Name { get; } = entry.Name;
    public double Percent { get; } = entry.Rate * 100;
    public string Text { get; } = entry.Level == MasteryLevel.NotEnoughEvidence
        ? $"{entry.Observations} observation{(entry.Observations == 1 ? "" : "s")} — not enough to judge yet"
        : $"{entry.Rate * 100:0}% of the last {Math.Min(20, entry.Observations)} · {entry.Level}";
    public string Level { get; } = entry.Level.ToString();
    public bool Judged { get; } = entry.Level != MasteryLevel.NotEnoughEvidence;
}

public sealed class LearningViewModel : ObservableObject, IActivatable
{
    private string _mode = "home";
    private string _generatorKind = "quiz";
    private string? _title;
    private int _count = 10;
    private Difficulty _difficulty = Difficulty.Medium;
    private string _audience = "Developer";
    private int _passMark = 70;
    private int _timeLimit;
    private FeedbackTiming _feedback = FeedbackTiming.AtTheEnd;
    private bool _shuffleQuestions = true;
    private bool _shuffleAnswers = true;
    private bool _isGenerating;
    private string? _generateStatus;
    private bool _showArchived;
    private QuizSessionViewModel? _quiz;
    private LearningPath? _path;
    private DeckReviewViewModel? _deck;
    private Faq? _faq;
    private LearningLibrary _library = new();
    private CancellationTokenSource? _generateCts;

    public LearningViewModel(WorkspaceViewModel workspace)
    {
        Workspace = workspace;
        Coach = new LearningCoachViewModel(workspace.Main);
        foreach (var topic in LearningTopics.All)
        {
            Topics.Add(new TopicOption(topic));
        }
        StartGeneratorCommand = new RelayCommand(p =>
        {
            GeneratorKind = p as string ?? "quiz";
            Count = GeneratorKind switch { "path" => 6, "cards" => 30, "faq" => 8, _ => 10 };
            Title = null;
            GenerateStatus = null;
            Mode = "generate";
        });
        GenerateCommand = new AsyncCommand(GenerateAsync, () => !IsGenerating && Workspace.IsIndexed);
        CancelGenerateCommand = new RelayCommand(() =>
        {
            _generateCts?.Cancel();
            Mode = "home";
        });
        HomeCommand = new AsyncCommand(async () =>
        {
            _quiz?.Stop();
            Mode = "home";
            await ReloadAsync();
        });
        OpenKnowledgeCommand = new AsyncCommand(OpenKnowledgeAsync);
        ToggleSessionCommand = new AsyncCommand(async p =>
        {
            if (p is LearningSession session && _path is not null)
            {
                await workspace.Main.Engine.Learning.SetSessionCompletedAsync(workspace.Record.Id, _path.Id, session.Number, session.Completed);
            }
        });
        OpenReferenceCommand = new RelayCommand(p =>
        {
            if (p is not string reference)
            {
                return;
            }
            if (reference.StartsWith("Reference/", StringComparison.Ordinal))
            {
                var name = reference.Split(' ')[0];
                var page = workspace.Index?.Pages.FirstOrDefault(pg => pg.TreePath == name);
                if (page is not null)
                {
                    workspace.OpenLink("page:" + page.Id);
                }
                return;
            }
            var colon = reference.LastIndexOf(':');
            var path = colon > 1 && int.TryParse(reference[(colon + 1)..], out var line) ? reference[..colon] : reference;
            workspace.OpenLink($"repo:{path}#L{(colon > 1 && int.TryParse(reference[(colon + 1)..], out var l) ? l : 0)}");
        });
        OpenCitationCommand = new RelayCommand(p =>
        {
            if (p is Citation c)
            {
                workspace.OpenLink($"repo:{c.Path}#L{c.StartLine}");
            }
        });
        ClearSelectionCommand = new RelayCommand(() => workspace.Tree.ClearSelection());
        RenameItemCommand = new AsyncCommand(async p => { if (p is LearningItem i) { await RenameAsync(i); } });
        DuplicateItemCommand = new AsyncCommand(async p => { if (p is LearningItem i) { await DuplicateAsync(i); } });
        ArchiveItemCommand = new AsyncCommand(async p => { if (p is LearningItem i) { await ArchiveAsync(i); } });
        DeleteItemCommand = new AsyncCommand(async p => { if (p is LearningItem i) { await DeleteAsync(i); } });
        workspace.Tree.ScopeChanged += (_, _) => Notify(nameof(ScopeDescription), nameof(HasScope));
    }

    public ICommand OpenLinkCommand => new RelayCommand(p => { if (p is string url) { Workspace.OpenLink(url); } });

    public ICommand RenameItemCommand { get; }
    public ICommand DuplicateItemCommand { get; }
    public ICommand ArchiveItemCommand { get; }
    public ICommand DeleteItemCommand { get; }

    public WorkspaceViewModel Workspace { get; }

    /// <summary>The persona hosting quizzes and flashcards.</summary>
    public LearningCoachViewModel Coach { get; }

    public ICommand StartGeneratorCommand { get; }
    public ICommand GenerateCommand { get; }
    public ICommand CancelGenerateCommand { get; }
    public ICommand HomeCommand { get; }
    public ICommand OpenKnowledgeCommand { get; }
    public ICommand ToggleSessionCommand { get; }
    public ICommand OpenReferenceCommand { get; }
    public ICommand OpenCitationCommand { get; }
    public ICommand ClearSelectionCommand { get; }

    public ObservableCollection<TopicOption> Topics { get; } = [];
    public ObservableCollection<LearningItemRow> Quizzes { get; } = [];
    public ObservableCollection<LearningItemRow> Paths { get; } = [];
    public ObservableCollection<LearningItemRow> Decks { get; } = [];
    public ObservableCollection<LearningItemRow> Faqs { get; } = [];
    public ObservableCollection<MasteryViewModel> TopicMastery { get; } = [];
    public ObservableCollection<MasteryViewModel> WeakConcepts { get; } = [];

    public IReadOnlyList<string> AudienceOptions => Audiences.All;
    public IReadOnlyList<Difficulty> DifficultyOptions { get; } = Enum.GetValues<Difficulty>();
    public IReadOnlyList<KeyValuePair<FeedbackTiming, string>> FeedbackOptions { get; } =
        [new(FeedbackTiming.AtTheEnd, "At the end"), new(FeedbackTiming.AfterEachQuestion, "After each question")];

    /// <summary>home | generate | quiz | path | deck | faq | knowledge</summary>
    public string Mode
    {
        get => _mode;
        set => Set(ref _mode, value);
    }

    public string GeneratorKind
    {
        get => _generatorKind;
        set
        {
            if (Set(ref _generatorKind, value))
            {
                Notify(nameof(GeneratorTitle), nameof(GeneratorDescription), nameof(GenerateButtonText), nameof(CountLabel), nameof(IsQuizGenerator));
            }
        }
    }

    public bool IsQuizGenerator => GeneratorKind == "quiz";
    public string GeneratorTitle => GeneratorKind switch { "path" => "Plan a path", "cards" => "Generate cards", "faq" => "Generate questions", _ => "Create a quiz" };
    public string GeneratorDescription => GeneratorKind switch
    {
        "path" => "Sessions that build on each other: what to read first, what to read next, and something to try.",
        "cards" => "Cards for the classes, terms and workflows worth recognising. Cards you recall easily come back less often.",
        "faq" => "The questions somebody would actually ask about this repository, answered from its own code and documentation.",
        _ => "Questions with answers to check, marked by arithmetic: the same answers always give the same score.",
    };
    public string GenerateButtonText => GeneratorKind switch { "path" => "Plan path", "cards" => "Generate cards", "faq" => "Generate questions", _ => "Create quiz" };
    public string CountLabel => GeneratorKind switch { "path" => "Sessions", "cards" => "Cards", "faq" => "Questions", _ => "Questions" };

    public string? Title
    {
        get => _title;
        set => Set(ref _title, value);
    }

    public int Count
    {
        get => _count;
        set => Set(ref _count, Math.Clamp(value, 1, 200));
    }

    public Difficulty Difficulty
    {
        get => _difficulty;
        set => Set(ref _difficulty, value);
    }

    public string Audience
    {
        get => _audience;
        set => Set(ref _audience, value);
    }

    public int PassMark
    {
        get => _passMark;
        set => Set(ref _passMark, Math.Clamp(value, 0, 100));
    }

    public int TimeLimit
    {
        get => _timeLimit;
        set => Set(ref _timeLimit, Math.Clamp(value, 0, 600));
    }

    public FeedbackTiming Feedback
    {
        get => _feedback;
        set => Set(ref _feedback, value);
    }

    public bool ShuffleQuestions
    {
        get => _shuffleQuestions;
        set => Set(ref _shuffleQuestions, value);
    }

    public bool ShuffleAnswers
    {
        get => _shuffleAnswers;
        set => Set(ref _shuffleAnswers, value);
    }

    public bool IsGenerating
    {
        get => _isGenerating;
        private set => Set(ref _isGenerating, value);
    }

    public string? GenerateStatus
    {
        get => _generateStatus;
        private set => Set(ref _generateStatus, value);
    }

    public bool ShowArchived
    {
        get => _showArchived;
        set
        {
            if (Set(ref _showArchived, value))
            {
                FillLists();
            }
        }
    }

    public string ScopeDescription => Workspace.Tree.ScopeDescription;
    public bool HasScope => Workspace.Tree.HasScope;

    public QuizSessionViewModel? Quiz
    {
        get => _quiz;
        private set => Set(ref _quiz, value);
    }

    public LearningPath? Path
    {
        get => _path;
        private set => Set(ref _path, value);
    }

    public DeckReviewViewModel? Deck
    {
        get => _deck;
        private set => Set(ref _deck, value);
    }

    public Faq? Faq
    {
        get => _faq;
        private set => Set(ref _faq, value);
    }

    public bool HasKnowledge => TopicMastery.Count > 0;

    public async Task ActivateAsync()
    {
        await Coach.LoadAsync();
        if (Mode == "home")
        {
            await ReloadAsync();
        }
    }

    public void OnIndexChanged() => _ = ReloadAsync();

    private async Task ReloadAsync()
    {
        _library = await Workspace.Main.Engine.Learning.GetLibraryAsync(Workspace.Record.Id);
        FillLists();
    }

    private void FillLists()
    {
        void Fill<T>(ObservableCollection<LearningItemRow> target, IEnumerable<T> items, string kind) where T : LearningItem
        {
            target.Clear();
            foreach (var item in items.Where(i => ShowArchived || !i.Archived))
            {
                target.Add(new LearningItemRow(item, kind, this));
            }
        }
        Fill(Quizzes, _library.Quizzes, "quiz");
        Fill(Paths, _library.Paths, "path");
        Fill(Decks, _library.Decks, "deck");
        Fill(Faqs, _library.Faqs, "faq");
    }

    private GenerationOptions Options() => new()
    {
        Title = string.IsNullOrWhiteSpace(Title) ? null : Title,
        Count = Count,
        Difficulty = Difficulty,
        Audience = Audience,
        Topics = Topics.Where(t => t.IsChecked).Select(t => t.Name).ToList(),
        PassMarkPercent = PassMark,
        TimeLimitMinutes = TimeLimit,
        Feedback = Feedback,
        ShuffleQuestions = ShuffleQuestions,
        ShuffleAnswers = ShuffleAnswers,
        Scope = Workspace.Tree.Scope.ToList(),
        Seed = Environment.TickCount,
    };

    private async Task GenerateAsync()
    {
        IsGenerating = true;
        GenerateStatus = "Working…";
        _generateCts = new CancellationTokenSource();
        var learning = Workspace.Main.Engine.Learning;
        var id = Workspace.Record.Id;
        var options = Options();
        try
        {
            switch (GeneratorKind)
            {
                case "path":
                    var path = await Task.Run(() => learning.CreatePathAsync(id, options, _generateCts.Token));
                    await ReloadAsync();
                    OpenPath(path);
                    break;
                case "cards":
                    var deck = await Task.Run(() => learning.CreateDeckAsync(id, options, _generateCts.Token));
                    await ReloadAsync();
                    OpenDeck(deck);
                    break;
                case "faq":
                    var progress = new Progress<string>(text => GenerateStatus = text);
                    var faq = await Task.Run(() => learning.CreateFaqAsync(id, options, progress, _generateCts.Token));
                    await ReloadAsync();
                    OpenFaq(faq);
                    break;
                default:
                    var quiz = await Task.Run(() => learning.CreateQuizAsync(id, options, _generateCts.Token));
                    await ReloadAsync();
                    OpenQuiz(quiz);
                    break;
            }
            GenerateStatus = null;
        }
        catch (Engine.Repositories.ExplorerValidationException ex)
        {
            GenerateStatus = ex.Message;
        }
        finally
        {
            IsGenerating = false;
        }
    }

    public void Open(LearningItemRow row)
    {
        switch (row.Item)
        {
            case Quiz q: OpenQuiz(q); break;
            case LearningPath p: OpenPath(p); break;
            case FlashcardDeck d: OpenDeck(d); break;
            case Faq f: OpenFaq(f); break;
        }
    }

    private void OpenQuiz(Quiz quiz)
    {
        Quiz?.Stop();
        Quiz = new QuizSessionViewModel(quiz, this);
        Mode = "quiz";
        Coach.QuizOpened(quiz.Questions.Count, quiz.Options.PassMarkPercent);
    }

    private void OpenPath(LearningPath path)
    {
        Path = path;
        Mode = "path";
    }

    private void OpenDeck(FlashcardDeck deck)
    {
        Deck = new DeckReviewViewModel(deck, this);
        Mode = "deck";
        Coach.DeckOpened(Deck.HasCard);
    }

    private void OpenFaq(Faq faq)
    {
        Faq = faq;
        Mode = "faq";
    }

    private async Task OpenKnowledgeAsync()
    {
        var record = await Workspace.Main.Engine.Learning.GetKnowledgeAsync(Workspace.Record.Id);
        TopicMastery.Clear();
        foreach (var entry in KnowledgeTracker.ByTopic(record))
        {
            TopicMastery.Add(new MasteryViewModel(entry));
        }
        WeakConcepts.Clear();
        foreach (var entry in KnowledgeTracker.ByConcept(record).Where(e => e.Level is MasteryLevel.Learning or MasteryLevel.Familiar).Take(15))
        {
            WeakConcepts.Add(new MasteryViewModel(entry) );
        }
        OnPropertyChanged(nameof(HasKnowledge));
        Mode = "knowledge";
    }

    public async Task RegenerateAsync(Quiz quiz)
    {
        var fresh = await Workspace.Main.Engine.Learning.RegenerateQuizAsync(Workspace.Record.Id, quiz.Id);
        await ReloadAsync();
        OpenQuiz(fresh);
    }

    public Task<QuizAttempt> SubmitAsync(Quiz quiz, IReadOnlyList<int> answers, long seconds)
        => Workspace.Main.Engine.Learning.SubmitQuizAsync(Workspace.Record.Id, quiz.Id, answers, seconds);

    public Task<Flashcard> ReviewAsync(FlashcardDeck deck, Flashcard card, RecallGrade grade)
        => Workspace.Main.Engine.Learning.ReviewCardAsync(Workspace.Record.Id, deck.Id, card.Id, grade);

    public async Task RenameAsync(LearningItem item)
    {
        var title = await Workspace.Main.PromptAsync("Rename", "Title", item.Title);
        if (title is { Length: > 0 })
        {
            await Workspace.Main.Engine.Learning.RenameAsync(Workspace.Record.Id, item.Id, title);
            await ReloadAsync();
        }
    }

    public async Task DuplicateAsync(LearningItem item)
    {
        await Workspace.Main.Engine.Learning.DuplicateAsync(Workspace.Record.Id, item.Id);
        await ReloadAsync();
    }

    public async Task ArchiveAsync(LearningItem item)
    {
        await Workspace.Main.Engine.Learning.ArchiveAsync(Workspace.Record.Id, item.Id, !item.Archived);
        await ReloadAsync();
    }

    public async Task DeleteAsync(LearningItem item)
    {
        if (await Workspace.Main.ConfirmAsync($"Delete \"{item.Title}\"?", "This cannot be undone.", null, "Delete"))
        {
            await Workspace.Main.Engine.Learning.DeleteAsync(Workspace.Record.Id, item.Id);
            if (Mode != "home")
            {
                Mode = "home";
            }
            await ReloadAsync();
        }
    }
}
