using System.Collections.ObjectModel;
using System.Windows.Input;
using DocGen.Explorer.Controls;
using DocGen.Explorer.Engine.Export;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>One format in an answer's Download panel; Mermaid is off, with the reason, when the answer has no diagram.</summary>
public sealed class ExportFormatChoice(ResponseFormat format, string label, string description, string? disabledReason, Action<ExportFormatChoice> selected) : ObservableObject
{
    private bool _isSelected;

    public ResponseFormat Format { get; } = format;
    public string Label { get; } = label;
    public string Description { get; } = description;
    public bool IsEnabled => DisabledReason is null;
    public string? DisabledReason { get; } = disabledReason;
    public string ToolTip => DisabledReason ?? Description;

    public bool IsSelected
    {
        get => _isSelected;
        set
        {
            if (Set(ref _isSelected, value) && value)
            {
                selected(this);
            }
        }
    }

    internal void Unselect()
    {
        _isSelected = false;
        Notify(nameof(IsSelected));
    }
}

/// <summary>Which diagram to save when an answer has several: one of them, or all as separate files in a ZIP.</summary>
public sealed record DiagramChoice(int Index, string Label)
{
    public const int All = -1;
    public override string ToString() => Label;
}

/// <summary>
/// Download one answer (Ask or Talk) on its own: Word, PowerPoint, HTML, Markdown, PDF, plain text or its Mermaid diagram(s), with or
/// without the question that produced it. One save at a time; progress, the result and any error are shown in the panel.
/// </summary>
public sealed class ResponseDownloadViewModel : ObservableObject
{
    private readonly ChatMessageViewModel _message;
    private readonly AssistantViewModel _owner;
    private ExportFormatChoice _selected;
    private bool _includeQuestion = true;
    private bool _isOpen;
    private bool _isExporting;
    private string _status = "";
    private bool _statusIsError;
    private string? _savedPath;
    private DiagramChoice? _diagram;

    public ResponseDownloadViewModel(ChatMessageViewModel message, AssistantViewModel owner)
    {
        _message = message;
        _owner = owner;
        Diagrams = ResponseExporter.MermaidDiagrams(message.Text);
        var noDiagram = Diagrams.Count == 0 ? "This response does not contain a Mermaid diagram." : null;
        Formats =
        [
            new(ResponseFormat.Word, "Word", "A .docx document: headings, lists, tables, links, code and diagrams.", null, Select),
            new(ResponseFormat.PowerPoint, "PowerPoint", "A .pptx deck: a title slide, one slide per section (## heading), tables, diagrams and speaker notes.", null, Select),
            new(ResponseFormat.Pdf, "PDF", "A PDF to read or print, with page numbers.", null, Select),
            new(ResponseFormat.Html, "Web page", "A single .html file that opens in any browser.", null, Select),
            new(ResponseFormat.Markdown, "Markdown", "The answer's Markdown (.md), with code and Mermaid blocks as they are.", null, Select),
            new(ResponseFormat.Text, "Plain text", "A simple .txt version.", null, Select),
            new(ResponseFormat.Mermaid, Diagrams.Count > 1 ? $"Mermaid ({Diagrams.Count})" : "Mermaid", "The diagram's Mermaid source (.mmd).", noDiagram, Select),
        ];
        _selected = Formats[0];
        Formats[0].IsSelected = true;
        DiagramChoices = [.. Diagrams.Select((d, i) => new DiagramChoice(i, $"Diagram {i + 1} · {Describe(d)}"))];
        if (Diagrams.Count > 1)
        {
            DiagramChoices.Add(new DiagramChoice(DiagramChoice.All, $"All {Diagrams.Count} diagrams (ZIP)"));
        }
        _diagram = DiagramChoices.FirstOrDefault();
        SaveCommand = new AsyncCommand(SaveAsync, () => !IsExporting);
        CloseCommand = new RelayCommand(() => IsOpen = false);
        OpenFolderCommand = new RelayCommand(() =>
        {
            if (_savedPath is not null && File.Exists(_savedPath))
            {
                System.Diagnostics.Process.Start("explorer.exe", $"/select,\"{_savedPath}\"");
            }
        });
    }

    public IReadOnlyList<ExportFormatChoice> Formats { get; }
    public IReadOnlyList<string> Diagrams { get; }
    public bool HasNoDiagram => Diagrams.Count == 0;
    public ObservableCollection<DiagramChoice> DiagramChoices { get; }
    public ICommand SaveCommand { get; }
    public ICommand CloseCommand { get; }
    public ICommand OpenFolderCommand { get; }

    public bool IsOpen
    {
        get => _isOpen;
        set
        {
            if (Set(ref _isOpen, value) && value)
            {
                Status = "";
                _savedPath = null;
                Notify(nameof(HasSaved));
            }
        }
    }

    public ExportFormatChoice Selected => _selected;
    public bool HasQuestion => _owner.QuestionFor(_message) is not null;

    public bool IncludeQuestion { get => _includeQuestion; set => Set(ref _includeQuestion, value); }

    /// <summary>The diagram picker shows for Mermaid when there is more than one diagram.</summary>
    public bool ShowDiagramPicker => _selected.Format == ResponseFormat.Mermaid && Diagrams.Count > 1;

    public DiagramChoice? Diagram { get => _diagram; set => Set(ref _diagram, value); }

    public bool IsExporting
    {
        get => _isExporting;
        private set
        {
            if (Set(ref _isExporting, value))
            {
                CommandManager.InvalidateRequerySuggested();
                Notify(nameof(SaveText));
            }
        }
    }

    public string SaveText => IsExporting ? "Saving…" : "Save…";

    public string Status { get => _status; private set => Set(ref _status, value); }
    public bool StatusIsError { get => _statusIsError; private set => Set(ref _statusIsError, value); }
    public bool HasSaved => _savedPath is not null;

    private void Select(ExportFormatChoice choice)
    {
        foreach (var other in Formats.Where(f => f != choice))
        {
            other.Unselect();
        }
        _selected = choice;
        Notify(nameof(Selected), nameof(ShowDiagramPicker));
    }

    /// <summary>The answer as the exporter takes it.</summary>
    public ResponseExport Export() => new(
        _message.Text,
        _owner.QuestionFor(_message),
        IncludeQuestion && HasQuestion,
        _owner.Workspace.Record.Title,
        _owner.Workspace.Record.Source == "git" ? _owner.Workspace.Record.Branch : null,
        _message.Message.At,
        _message.Message.Citations,
        _message.Message.Model,
        _message.Message.Persona);

    /// <summary>Saves the answer as the file its skill wrote it for (Word or PowerPoint): that format, without the question.</summary>
    public async Task SaveAsAsync(ResponseFormat format)
    {
        if (Formats.FirstOrDefault(f => f.Format == format) is { } choice)
        {
            choice.IsSelected = true;
        }
        IncludeQuestion = false;
        IsOpen = true;
        await SaveAsync();
    }

    private async Task SaveAsync()
    {
        if (IsExporting)
        {
            return;
        }
        if (!_selected.IsEnabled)
        {
            SetStatus(_selected.DisabledReason!, true);
            return;
        }
        var export = Export();
        var zip = _selected.Format == ResponseFormat.Mermaid && Diagram?.Index == DiagramChoice.All;
        var extension = zip ? ".zip" : ResponseExporter.Extension(_selected.Format);
        var name = ResponseExporter.FileName(export);
        if (_selected.Format == ResponseFormat.Mermaid && !zip && Diagrams.Count > 1)
        {
            name += $" diagram {(Diagram?.Index ?? 0) + 1}";
        }
        var dialog = new Microsoft.Win32.SaveFileDialog
        {
            FileName = name + extension,
            Filter = $"{(zip ? "ZIP" : _selected.Label)} (*{extension})|*{extension}",
            AddExtension = true,
            Title = "Save this answer",
        };
        if (dialog.ShowDialog() != true)
        {
            return;
        }
        IsExporting = true;
        SetStatus($"Saving {Path.GetFileName(dialog.FileName)}…", false);
        try
        {
            var format = _selected.Format;
            var index = Diagram?.Index ?? 0;
            // Word and PowerPoint show the diagrams as pictures: drawn here (on the UI thread, by the diagram renderer).
            IReadOnlyDictionary<string, DiagramImage>? drawn = null;
            if (format is ResponseFormat.Word or ResponseFormat.PowerPoint && Diagrams.Count > 0)
            {
                SetStatus($"Drawing {(Diagrams.Count == 1 ? "the diagram" : $"{Diagrams.Count} diagrams")}…", false);
                drawn = await DiagramPictures.DrawAsync(Diagrams);
                SetStatus($"Saving {Path.GetFileName(dialog.FileName)}…", false);
            }
            var bytes = await Task.Run(() => format switch
            {
                ResponseFormat.Mermaid when zip => ResponseExporter.MermaidZip(export),
                ResponseFormat.Mermaid => ResponseExporter.MermaidFile(export, index),
                _ => ResponseExporter.Write(export, format, drawn),
            });
            await File.WriteAllBytesAsync(dialog.FileName, bytes);
            _savedPath = dialog.FileName;
            Notify(nameof(HasSaved));
            SetStatus($"Saved {Path.GetFileName(dialog.FileName)}.", false);
            Ui.Notify($"Saved {Path.GetFileName(dialog.FileName)}");
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            SetStatus($"Could not save there ({ex.Message}). Close the file if it is open elsewhere, or choose another folder, and try again.", true);
        }
        catch (Exception ex) when (ex is InvalidOperationException or ArgumentException)
        {
            SetStatus(ex.Message, true);
            Logging.Error(ex, "Answer download");
        }
        finally
        {
            IsExporting = false;
        }
    }

    private void SetStatus(string text, bool error)
    {
        StatusIsError = error;
        Status = text;
    }

    // "flowchart TD" → "flowchart"; the kind of diagram, for the picker.
    private static string Describe(string source)
    {
        var first = Engine.Code.MermaidFlowchart.WithoutFrontMatter(source).Split('\n').Select(l => l.Trim()).FirstOrDefault(l => l.Length > 0 && !l.StartsWith("%%", StringComparison.Ordinal)) ?? "diagram";
        var word = first.Split(' ', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault() ?? "diagram";
        return word.Length > 24 ? word[..24] : word;
    }
}
