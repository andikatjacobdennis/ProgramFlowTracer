using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows.Input;
using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Engine.Skills;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>One installed skill in Settings → Skills.</summary>
public sealed class SkillRowViewModel : ObservableObject
{
    private readonly SkillsSettingsViewModel _owner;
    private bool _enabled;
    private bool _showInstructions;
    private string? _instructions;

    public SkillRowViewModel(SkillInfo info, SkillsSettingsViewModel owner)
    {
        Info = info;
        _owner = owner;
        _enabled = info.Enabled;
        ToggleInstructionsCommand = new AsyncCommand(ToggleInstructionsAsync);
        RemoveCommand = new AsyncCommand(() => owner.RemoveAsync(this), () => !info.BuiltIn);
    }

    public SkillInfo Info { get; }
    public string Icon => Info.Icon;
    public string Name => Info.Name;
    public string Description => Info.Manifest.Description;
    public bool IsValid => Info.Manifest.IsValid;

    public string Origin => (Info.BuiltIn ? "built-in" : "imported") + (Info.Manifest.Version is { } v ? $" · v{v}" : "") + (Info.Manifest.Author is { } a ? $" · {a}" : "");

    /// <summary>What the explorer does for this skill beyond its instructions.</summary>
    public string Capability => Info.Capability switch
    {
        "trace" => "Runs the architecture trace (program-flow table across projects)",
        "test-fix" => "Runs your tests, fixes the failure in the local files and verifies it — started with 🧪 in Ask; never commits or pushes. Off until you turn it on",
        null or "" => Info.WrittenForAgent ? "Instructions (written for an agent with tools; the tools are replaced by the evidence)" : "Instructions",
        var other => $"Capability: {other}",
    };

    public string Tags => string.Join(" · ", Info.Manifest.Tags.Take(8));

    public string Problems => string.Join("\n", Info.Manifest.Diagnostics.Where(d => d.Severity != DocGen.Core.Skills.SkillDiagnosticSeverity.Info).Select(d => $"{d.Severity}: {d.Message}"));
    public bool HasProblems => Problems.Length > 0;

    public bool Enabled
    {
        get => _enabled;
        set
        {
            if (Set(ref _enabled, value))
            {
                _ = _owner.SetEnabledAsync(this, value);
            }
        }
    }

    public bool ShowInstructions
    {
        get => _showInstructions;
        private set => Set(ref _showInstructions, value);
    }

    public string? Instructions
    {
        get => _instructions;
        private set => Set(ref _instructions, value);
    }

    public string InstructionsLabel => ShowInstructions ? "Hide instructions" : "Show instructions";

    public ICommand ToggleInstructionsCommand { get; }
    public ICommand RemoveCommand { get; }

    private async Task ToggleInstructionsAsync()
    {
        if (!ShowInstructions && Instructions is null)
        {
            Instructions = await Task.Run(() => DocGen.Core.Skills.SkillPackage.ReadInstructions(Info.Manifest));
        }
        ShowInstructions = !ShowInstructions;
        OnPropertyChanged(nameof(InstructionsLabel));
    }
}

/// <summary>Settings → Skills: which skills are on, automatic selection, the trace size, importing and removing.</summary>
public sealed class SkillsSettingsViewModel : ObservableObject
{
    private readonly MainViewModel _main;
    private bool _autoSelect = true;
    private int _traceMaxSteps = 200;
    private int _traceMaxDepth = 8;
    private bool _loading;
    private string _status = "";

    public SkillsSettingsViewModel(MainViewModel main)
    {
        _main = main;
        ImportFolderCommand = new AsyncCommand(ImportFolderAsync);
        ImportZipCommand = new AsyncCommand(ImportZipAsync);
        ImportCollectionCommand = new AsyncCommand(ImportCollectionAsync);
        OpenFolderCommand = new RelayCommand(() =>
        {
            Directory.CreateDirectory(Skills.ImportedDirectory);
            Process.Start(new ProcessStartInfo(Path.GetDirectoryName(Skills.ImportedDirectory)!) { UseShellExecute = true });
        });
    }

    private SkillService Skills => _main.Engine.Skills;

    public ObservableCollection<SkillRowViewModel> Items { get; } = [];

    public ICommand ImportFolderCommand { get; }
    public ICommand ImportZipCommand { get; }
    public ICommand ImportCollectionCommand { get; }
    public ICommand OpenFolderCommand { get; }

    public string Summary => Items.Count == 0 ? "No skills installed." : $"{Items.Count(i => i.Enabled)} of {Items.Count} skills on.";

    public string Status
    {
        get => _status;
        private set => Set(ref _status, value);
    }

    public bool AutoSelect
    {
        get => _autoSelect;
        set
        {
            if (Set(ref _autoSelect, value) && !_loading)
            {
                _ = Skills.UpdateSettingsAsync(s => s.AutoSelect = value);
            }
        }
    }

    /// <summary>Ask: the model reads each question first and asks back when the request is unclear.</summary>
    public bool ReadQuestionFirst
    {
        get => _readQuestionFirst;
        set
        {
            if (Set(ref _readQuestionFirst, value) && !_loading)
            {
                _ = Skills.UpdateSettingsAsync(s => s.ReadQuestionFirst = value);
            }
        }
    }

    private bool _readQuestionFirst = true;
    private int _testFixMaxIterations = 3;
    private int _testFixTimeoutSeconds = 600;
    private bool _testFixApplyChanges = true;
    private bool _testFixRunCommands = true;

    /// <summary>Test Fix: fix attempts before it stops and reports (1–10).</summary>
    public int TestFixMaxIterations
    {
        get => _testFixMaxIterations;
        set
        {
            var clamped = Math.Clamp(value, 1, 10);
            if (Set(ref _testFixMaxIterations, clamped) && !_loading)
            {
                _ = Skills.UpdateSettingsAsync(s => s.TestFixMaxIterations = clamped);
            }
        }
    }

    /// <summary>Test Fix: the longest a command may run, in minutes (1–120).</summary>
    public int TestFixTimeoutMinutes
    {
        get => _testFixTimeoutSeconds / 60;
        set
        {
            var seconds = Math.Clamp(value, 1, 120) * 60;
            if (Set(ref _testFixTimeoutSeconds, seconds) && !_loading)
            {
                _ = Skills.UpdateSettingsAsync(s => s.TestFixTimeoutSeconds = seconds);
            }
            Notify(nameof(TestFixTimeoutMinutes));
        }
    }

    /// <summary>Test Fix: write the fix to the files (else propose it only).</summary>
    public bool TestFixApplyChanges
    {
        get => _testFixApplyChanges;
        set
        {
            if (Set(ref _testFixApplyChanges, value) && !_loading)
            {
                _ = Skills.UpdateSettingsAsync(s => s.TestFixApplyChanges = value);
            }
        }
    }

    /// <summary>Test Fix: run the tests and builds (else nothing runs; results are unverified).</summary>
    public bool TestFixRunCommands
    {
        get => _testFixRunCommands;
        set
        {
            if (Set(ref _testFixRunCommands, value) && !_loading)
            {
                _ = Skills.UpdateSettingsAsync(s => s.TestFixRunCommands = value);
            }
        }
    }

    public int TraceMaxSteps
    {
        get => _traceMaxSteps;
        set
        {
            var clamped = Math.Clamp(value, SkillSettings.MinTraceSteps, SkillSettings.MaxTraceSteps);
            if (Set(ref _traceMaxSteps, clamped) && !_loading)
            {
                _ = Skills.UpdateSettingsAsync(s => s.TraceMaxSteps = clamped);
            }
        }
    }

    public int TraceMaxDepth
    {
        get => _traceMaxDepth;
        set
        {
            var clamped = Math.Clamp(value, 2, 16);
            if (Set(ref _traceMaxDepth, clamped) && !_loading)
            {
                _ = Skills.UpdateSettingsAsync(s => s.TraceMaxDepth = clamped);
            }
        }
    }

    public async Task LoadAsync()
    {
        _loading = true;
        try
        {
            Skills.Invalidate();
            var settings = await Skills.GetSettingsAsync();
            AutoSelect = settings.AutoSelect;
            ReadQuestionFirst = settings.ReadQuestionFirst;
            TestFixMaxIterations = settings.TestFixMaxIterations;
            TestFixTimeoutMinutes = Math.Max(1, settings.TestFixTimeoutSeconds / 60);
            TestFixApplyChanges = settings.TestFixApplyChanges;
            TestFixRunCommands = settings.TestFixRunCommands;
            TraceMaxSteps = settings.TraceMaxSteps;
            TraceMaxDepth = settings.TraceMaxDepth;
            var list = await Skills.ListAsync();
            Items.Clear();
            foreach (var info in list)
            {
                Items.Add(new SkillRowViewModel(info, this));
            }
            Notify(nameof(Summary));
        }
        finally
        {
            _loading = false;
        }
    }

    internal async Task SetEnabledAsync(SkillRowViewModel row, bool enabled)
    {
        await Skills.SetEnabledAsync(row.Info.Id, enabled);
        Notify(nameof(Summary));
        _main.OnSkillsChanged();
    }

    internal async Task RemoveAsync(SkillRowViewModel row)
    {
        if (!await _main.ConfirmAsync($"Remove the {row.Name} skill?", "Its imported files are deleted from the data folder. Built-in skills stay.", null, "Remove"))
        {
            return;
        }
        await Skills.RemoveAsync(row.Info.Id);
        await LoadAsync();
        _main.OnSkillsChanged();
        Ui.Notify($"{row.Name} removed.");
    }

    private async Task ImportFolderAsync()
    {
        var dialog = new Microsoft.Win32.OpenFolderDialog { Title = "Choose a skill folder (with a SKILL.md), or a folder of skills" };
        if (dialog.ShowDialog() == true)
        {
            await ImportAsync(dialog.FolderName);
        }
    }

    private async Task ImportZipAsync()
    {
        var dialog = new Microsoft.Win32.OpenFileDialog { Title = "Choose a skill package", Filter = "Skill package (*.zip;SKILL.md)|*.zip;SKILL.md|All files (*.*)|*.*" };
        if (dialog.ShowDialog() == true)
        {
            await ImportAsync(dialog.FileName);
        }
    }

    /// <summary>A collection keeps its skills in a skills/ folder next to its solution or app: pick that folder.</summary>
    private async Task ImportCollectionAsync()
    {
        var dialog = new Microsoft.Win32.OpenFolderDialog { Title = "Choose a folder of skills, or the folder that holds a skills/ folder" };
        if (dialog.ShowDialog() != true)
        {
            return;
        }
        if (SkillService.FindSkillCollection(dialog.FolderName) is not { } skills)
        {
            Status = "No skills/ folder with SKILL.md packages was found there.";
            return;
        }
        await ImportAsync(skills, asCollection: true);
    }

    private async Task ImportAsync(string path, bool asCollection = false)
    {
        try
        {
            var imported = await Task.Run(() => Skills.ImportAsync(path, default, onlyReplacementsOn: asCollection));
            await LoadAsync();
            _main.OnSkillsChanged();
            var on = Items.Where(i => imported.Contains(i.Info.Id) && i.Enabled).Select(i => i.Name).ToList();
            Status = $"Imported {imported.Count}: {string.Join(", ", imported)}." +
                     (asCollection ? $" On: {(on.Count > 0 ? string.Join(", ", on) : "none")} (they replace the built-ins and keep their capabilities); turn on the others you want." : "");
            Ui.Notify(Status);
        }
        catch (Exception ex) when (ex is ExplorerValidationException or IOException or UnauthorizedAccessException or InvalidDataException)
        {
            Status = ex.Message;
        }
    }
}
