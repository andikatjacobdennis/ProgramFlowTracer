using System.Windows.Input;
using System.Windows.Threading;
using DocGen.Explorer.Engine.Text;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>
/// Search in Ask: the words are marked in yellow in every question and answer of the conversation, and Next / Previous
/// go from one message that has them to the next. With earlier conversations shown, the list keeps only those that have
/// them, with how many times and where.
/// </summary>
public sealed partial class AssistantViewModel
{
    private bool _isSearchOpen;
    private string _searchText = "";
    private bool _searchMatchCase;
    private bool _searchWholeWord;
    private int _searchIndex = -1;
    private int _searchTotal;
    private List<ChatMessageViewModel> _hits = [];
    private DispatcherTimer? _searchTimer;
    private bool _focusSearch;

    public bool IsSearchOpen
    {
        get => _isSearchOpen;
        set
        {
            if (Set(ref _isSearchOpen, value))
            {
                if (value)
                {
                    FocusSearch = false;
                    FocusSearch = true;
                    ScheduleSearch();
                }
                else
                {
                    ClearSearch();
                    if (ShowHistory)
                    {
                        _ = ReloadHistoryAsync();
                    }
                }
            }
        }
    }

    public bool FocusSearch { get => _focusSearch; set => Set(ref _focusSearch, value); }

    public string SearchText
    {
        get => _searchText;
        set
        {
            if (Set(ref _searchText, value ?? ""))
            {
                ScheduleSearch();
            }
        }
    }

    public bool SearchMatchCase { get => _searchMatchCase; set { if (Set(ref _searchMatchCase, value)) { ScheduleSearch(); } } }
    public bool SearchWholeWord { get => _searchWholeWord; set { if (Set(ref _searchWholeWord, value)) { ScheduleSearch(); } } }

    private FindOptions SearchOptions => new(SearchMatchCase, SearchWholeWord);

    /// <summary>"2 of 5 messages · 9 matches", "No matches", or nothing before anything is typed.</summary>
    public string SearchStatus => SearchText.Trim().Length == 0 ? ""
        : ShowHistory ? (History.Count == 0 ? "No conversations have it" : $"{TextUtil.Plural(History.Count, "conversation")} · {TextUtil.Plural(History.Sum(h => h.Matches), "match", "matches")}")
        : _hits.Count == 0 ? "No matches"
        : $"{Math.Max(_searchIndex, 0) + 1} of {TextUtil.Plural(_hits.Count, "message")} · {TextUtil.Plural(_searchTotal, "match", "matches")}";

    public bool HasSearchHits => _hits.Count > 1 || (_hits.Count == 1 && _searchIndex != 0);

    public ICommand ToggleSearchCommand => new RelayCommand(() => IsSearchOpen = !IsSearchOpen);
    public ICommand CloseSearchCommand => new RelayCommand(() => IsSearchOpen = false);
    public ICommand NextMatchCommand => new RelayCommand(() => Step(+1), () => _hits.Count > 0);
    public ICommand PreviousMatchCommand => new RelayCommand(() => Step(-1), () => _hits.Count > 0);

    /// <summary>Raised to bring a message with a match into view (the pane scrolls to it).</summary>
    public event EventHandler<ChatMessageViewModel>? RevealRequested;

    private void ScheduleSearch()
    {
        if (_searchTimer is null)
        {
            _searchTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(220) };
            _searchTimer.Tick += async (_, _) =>
            {
                _searchTimer.Stop();
                await ApplySearchAsync();
            };
        }
        _searchTimer.Stop();
        _searchTimer.Start();
    }

    /// <summary>Marks the words in the conversation (or narrows the earlier conversations) and goes to the first match.</summary>
    public async Task ApplySearchAsync()
    {
        var query = IsSearchOpen ? SearchText.Trim() : "";
        if (ShowHistory)
        {
            await ReloadHistoryAsync();
            return;
        }
        _hits = [];
        _searchTotal = 0;
        foreach (var message in Messages)
        {
            var count = query.Length == 0 ? 0 : TextMatcher.Matches(message.Text, query, SearchOptions).Count;
            message.SearchQuery = count > 0 ? query : null;
            message.IsCurrentHit = false;
            if (count > 0)
            {
                _hits.Add(message);
                _searchTotal += count;
            }
        }
        // The latest message with the words first, as a search from the end of the conversation.
        _searchIndex = _hits.Count == 0 ? -1 : _hits.Count - 1;
        ShowCurrent();
    }

    private void Step(int by)
    {
        if (_hits.Count == 0)
        {
            return;
        }
        _searchIndex = ((_searchIndex < 0 ? 0 : _searchIndex) + by + _hits.Count) % _hits.Count;
        ShowCurrent();
    }

    private void ShowCurrent()
    {
        for (var i = 0; i < _hits.Count; i++)
        {
            _hits[i].IsCurrentHit = i == _searchIndex;
        }
        if (_searchIndex >= 0 && _searchIndex < _hits.Count)
        {
            RevealRequested?.Invoke(this, _hits[_searchIndex]);
        }
        Notify(nameof(SearchStatus), nameof(HasSearchHits));
        CommandManager.InvalidateRequerySuggested();
    }

    private void ClearSearch()
    {
        foreach (var message in Messages)
        {
            message.SearchQuery = null;
            message.IsCurrentHit = false;
        }
        _hits = [];
        _searchIndex = -1;
        _searchTotal = 0;
        Notify(nameof(SearchStatus), nameof(HasSearchHits));
    }

    /// <summary>The earlier conversations, narrowed to those with the search words while searching.</summary>
    private async Task ReloadHistoryAsync()
    {
        var query = IsSearchOpen ? SearchText.Trim() : "";
        var list = await Service.ListConversationsAsync(Workspace.Record.Id, default, query.Length > 0 ? query : null, SearchOptions);
        History.Clear();
        foreach (var summary in list)
        {
            History.Add(summary);
        }
        Notify(nameof(SearchStatus), nameof(HasSearchHits));
    }
}
