using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Data;
using System.Windows.Input;
using DocGen.Explorer.Engine.Confluence;
using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Engine.Text;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>One space on a site, ticked when the open repository searches it.</summary>
public sealed class ConfluenceSpaceChoice(ConfluenceSpaceInfo space, ConfluenceSpacePickerViewModel owner, bool selected) : ObservableObject
{
    private bool _isSelected = selected;

    public ConfluenceSpaceInfo Space { get; } = space;
    public string Name => Space.Name;
    public string Detail => $"{Space.Key} · {Space.SiteName}{(Space.Personal ? " · personal" : "")}";

    public bool IsSelected
    {
        get => _isSelected;
        set
        {
            if (Set(ref _isSelected, value))
            {
                _ = owner.ChangeAsync(this);
            }
        }
    }

    /// <summary>Sets the tick without adding or removing the space (when loading).</summary>
    internal void Show(bool selected)
    {
        _isSelected = selected;
        Notify(nameof(IsSelected));
    }
}

/// <summary>
/// The spaces on every Confluence site in Settings, each with a tick box for the open repository: nothing is ticked at
/// first (only the spaces the repository already searches), and ticking one adds it, unticking removes it.
/// </summary>
public sealed class ConfluenceSpacePickerViewModel : ObservableObject
{
    private readonly MainViewModel _main;
    private bool _isLoading;
    private string _status = "";
    private string _filter = "";
    private bool _loaded;

    public ConfluenceSpacePickerViewModel(MainViewModel main)
    {
        _main = main;
        View = CollectionViewSource.GetDefaultView(Choices);
        View.Filter = o => o is ConfluenceSpaceChoice c && (Filter.Length == 0
            || c.Name.Contains(Filter, StringComparison.CurrentCultureIgnoreCase) || c.Space.Key.Contains(Filter, StringComparison.OrdinalIgnoreCase));
        ReloadCommand = new AsyncCommand(LoadAsync, () => !IsLoading);
    }

    public ObservableCollection<ConfluenceSpaceChoice> Choices { get; } = [];
    public ICollectionView View { get; }
    public ICommand ReloadCommand { get; }

    /// <summary>The repository's spaces were changed here (the Indexing page lists them).</summary>
    public event Action? SpacesChanged;

    public string? RepositoryId => _main.Workspace?.Record.Id;
    public string RepositoryTitle => _main.Workspace?.Record.Title ?? "";
    public bool HasRepository => RepositoryId is not null;
    public bool HasChoices => Choices.Count > 0;
    public bool ShowFilter => Choices.Count > 8;

    public bool IsLoading
    {
        get => _isLoading;
        private set
        {
            if (Set(ref _isLoading, value))
            {
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    public string Status { get => _status; private set => Set(ref _status, value); }

    public string Filter
    {
        get => _filter;
        set
        {
            if (Set(ref _filter, value ?? ""))
            {
                View.Refresh();
            }
        }
    }

    public string Summary => Choices.Count == 0 ? "" : $"{TextUtil.Plural(Choices.Count, "space")} on your sites: tick one to search it with {RepositoryTitle}, untick it to stop.";

    /// <summary>Loads once; later calls only refresh the ticks (Reload asks the sites again).</summary>
    public async Task EnsureLoadedAsync()
    {
        if (_loaded && _loadedFor == RepositoryId)
        {
            await RefreshTicksAsync();
            return;
        }
        await LoadAsync();
    }

    private string? _loadedFor;

    public async Task LoadAsync()
    {
        Notify(nameof(RepositoryId), nameof(RepositoryTitle), nameof(HasRepository));
        if (!HasRepository)
        {
            Choices.Clear();
            Status = "Open a repository to choose which spaces it searches.";
            NotifyCounts();
            return;
        }
        var sites = (await _main.Engine.Confluence.Settings.GetAsync()).Sites.Where(s => s.HasCredentials).ToList();
        if (sites.Count == 0)
        {
            Choices.Clear();
            Status = "Save a Confluence site with its sign-in (Settings → Confluence) and its spaces are listed here.";
            NotifyCounts();
            return;
        }
        IsLoading = true;
        Status = "Loading the spaces…";
        var problems = new List<string>();
        var found = new List<ConfluenceSpaceInfo>();
        try
        {
            foreach (var site in sites)
            {
                try
                {
                    found.AddRange(await _main.Engine.Confluence.ListSpacesAsync(site));
                }
                catch (ExplorerValidationException ex)
                {
                    problems.Add($"{(string.IsNullOrWhiteSpace(site.Name) ? site.BaseUrl : site.Name)}: {ex.Message}");
                }
            }
            var chosen = await ChosenAsync();
            Choices.Clear();
            foreach (var space in found)
            {
                Choices.Add(new ConfluenceSpaceChoice(space, this, Key(space.Url) is { } key && chosen.Contains(key)));
            }
            _loaded = true;
            _loadedFor = RepositoryId;
            Status = problems.Count > 0 ? string.Join(" ", problems)
                : found.Count == 0 ? "Connected, but the sign-in sees no spaces."
                : "";
        }
        finally
        {
            IsLoading = false;
            NotifyCounts();
        }
    }

    private async Task RefreshTicksAsync()
    {
        Notify(nameof(RepositoryId), nameof(RepositoryTitle), nameof(HasRepository));
        var chosen = await ChosenAsync();
        foreach (var choice in Choices)
        {
            choice.Show(Key(choice.Space.Url) is { } key && chosen.Contains(key));
        }
        NotifyCounts();
    }

    internal async Task ChangeAsync(ConfluenceSpaceChoice choice)
    {
        if (RepositoryId is not { } id)
        {
            return;
        }
        try
        {
            if (choice.IsSelected)
            {
                await _main.Engine.Confluence.AddSpaceAsync(id, choice.Space.Url);
            }
            else if (await _main.Engine.Repositories.GetAsync(id) is { } record)
            {
                // The repository may hold the space under another form of its address: remove every one.
                foreach (var url in record.ConfluenceSpaces.Where(u => Key(u) == Key(choice.Space.Url)).ToList())
                {
                    await _main.Engine.Confluence.RemoveSpaceAsync(id, url);
                }
            }
            SpacesChanged?.Invoke();
        }
        catch (ExplorerValidationException ex)
        {
            choice.Show(!choice.IsSelected);
            Status = ex.Message;
        }
        NotifyCounts();
    }

    private async Task<HashSet<string>> ChosenAsync()
    {
        var record = RepositoryId is { } id ? await _main.Engine.Repositories.GetAsync(id) : null;
        return (record?.ConfluenceSpaces ?? []).Select(Key).OfType<string>().ToHashSet(StringComparer.OrdinalIgnoreCase);
    }

    /// <summary>A space's identity: its site and key, whatever form the address takes.</summary>
    internal static string? Key(string url)
    {
        try
        {
            return ConfluenceService.SpaceId(ConfluenceService.ParseSpaceUrl(url));
        }
        catch (ExplorerValidationException)
        {
            return null;
        }
    }

    private void NotifyCounts() => Notify(nameof(HasChoices), nameof(ShowFilter), nameof(Summary));
}
