using System.Collections.ObjectModel;
using System.Text;
using System.Windows.Input;
using System.Windows.Threading;
using DocGen.Explorer.Engine.Assistant;
using DocGen.Explorer.Engine.Export;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

public sealed class CitationViewModel(Citation citation, WorkspaceViewModel workspace)
{
    public Citation Citation { get; } = citation;
    public string Number => Citation.Number.ToString();
    public string Title => Citation.Title;
    public string Location => Citation.StartLine > 0 ? $"{Citation.Path}:{Citation.StartLine}–{Citation.EndLine}" : Citation.Path;
    public string FileName => Citation.Path.StartsWith("confluence:", StringComparison.Ordinal) ? Citation.Title : Path.GetFileName(Citation.Path);
    public ICommand OpenCommand => new RelayCommand(() => workspace.OpenLink($"repo:{Citation.Path}#L{Citation.StartLine}"));
}

public sealed class ChatMessageViewModel : ObservableObject
{
    private readonly AssistantViewModel _owner;
    private string _text;
    private bool _isStreaming;
    private bool _isSpeaking;

    public ChatMessageViewModel(ChatMessage message, AssistantViewModel owner)
    {
        Message = message;
        _owner = owner;
        // A question back shows its choices as buttons below it, not also as a list.
        _text = message.Clarify is { Options.Count: > 0 } clarify ? clarify.Question + "\n\nChoose one below, or reply in your own words." : message.Text;
        _thinking = message.Thinking ?? "";
        foreach (var step in message.Steps)
        {
            Steps.Add(step);
        }
        Citations = message.Citations.Select(c => new CitationViewModel(c, owner.Workspace)).ToList();
        CopyCommand = new RelayCommand(() => { if (Ui.Copy(Text)) { Ui.Notify(IsUser ? "Question copied." : "Answer copied."); } });
        ReadAloudCommand = new RelayCommand(() => owner.ReadAloud(this));
        PauseCommand = new RelayCommand(owner.TogglePause);
        RetryCommand = new AsyncCommand(() => owner.RetryAsync(this), () => !owner.IsBusy);
        EditCommand = new RelayCommand(() => owner.BeginEdit(this), () => !owner.IsBusy && message.TestFix is null);
        UndoTestFixCommand = new AsyncCommand(() => owner.UndoTestFixAsync(this), () => !owner.IsBusy && IsTestFixReport);
        OpenLinkCommand = new RelayCommand(p =>
        {
            if (p is not string url)
            {
                return;
            }
            if (url.StartsWith("cite:", StringComparison.Ordinal) && int.TryParse(url[5..], out var number))
            {
                if (Citations.FirstOrDefault(c => c.Citation.Number == number) is { } citation)
                {
                    citation.OpenCommand.Execute(null);
                }
                return;
            }
            owner.Workspace.OpenLink(url);
        });
    }

    public ICommand OpenLinkCommand { get; }

    private string _thinking;
    private bool _thinkingExpanded;

    public ChatMessage Message { get; }

    /// <summary>A question back's choices; choosing one sends it as the reply.</summary>
    public IReadOnlyList<string> Choices => Message.Clarify?.Options ?? [];

    public bool HasChoices => Choices.Count > 0;

    /// <summary>What the assistant did, step by step ("Working through this").</summary>
    public System.Collections.ObjectModel.ObservableCollection<string> Steps { get; } = [];

    /// <summary>The model's own reasoning (reasoning models only).</summary>
    public string Thinking
    {
        get => _thinking;
        set
        {
            if (Set(ref _thinking, value))
            {
                OnPropertyChanged(nameof(HasThinking));
            }
        }
    }

    public bool HasThinking => Thinking.Length > 0;

    /// <summary>The skill that shaped this answer ("🏛️ Architect"), or empty.</summary>
    public string SkillName => Message.SkillName ?? "";
    public bool HasSkill => SkillName.Length > 0;
    public bool HasSteps => Steps.Count > 0 || IsStreaming;

    /// <summary>Open while the answer is being written; closed afterwards unless the reader opens it.</summary>
    public bool ThinkingExpanded
    {
        get => _thinkingExpanded;
        set => Set(ref _thinkingExpanded, value);
    }

    public string ThinkingHeader => IsStreaming ? "Working through this…" : HasThinking ? $"Working through this · {Steps.Count} steps · the model's reasoning" : $"Working through this · {Steps.Count} steps";

    public void AddStep(string step)
    {
        Steps.Add(step);
        Notify(nameof(HasSteps), nameof(ThinkingHeader));
    }

    public bool IsUser => Message.Role == "user";
    public bool IsAssistant => !IsUser;

    /// <summary>A note in the conversation rather than an answer (Talk's persona switch).</summary>
    public bool IsNotice => Message.Model == "notice";

    /// <summary>Who answered: the persona in Talk, else "Assistant".</summary>
    public string Speaker => Message.Persona ?? _owner.Persona?.Name ?? "Assistant";
    public IReadOnlyList<CitationViewModel> Citations { get; }
    public IReadOnlyList<string> Diagnostics => Message.Diagnostics;
    public bool HasCitations => Citations.Count > 0;
    public bool HasDiagnostics => Diagnostics.Count > 0;
    public string CitationSummary => string.Join(", ", Citations.Select(c => c.FileName).Distinct().Take(4));
    public bool Failed => Message.Failed;

    public string Text
    {
        get => _text;
        set => Set(ref _text, value);
    }

    private string? _searchQuery;
    private bool _isCurrentHit;

    /// <summary>Ask's search: the words to mark in yellow in this message (null: none).</summary>
    public string? SearchQuery { get => _searchQuery; set => Set(ref _searchQuery, value); }

    /// <summary>The message the search is on (outlined).</summary>
    public bool IsCurrentHit { get => _isCurrentHit; set => Set(ref _isCurrentHit, value); }

    public bool IsStreaming
    {
        get => _isStreaming;
        set
        {
            if (Set(ref _isStreaming, value))
            {
                Notify(nameof(Meta), nameof(HasSteps), nameof(ThinkingHeader));
                ThinkingExpanded = value;
            }
        }
    }

    public bool IsSpeaking
    {
        get => _isSpeaking;
        set
        {
            if (Set(ref _isSpeaking, value))
            {
                OnPropertyChanged(nameof(ReadAloudText));
            }
        }
    }

    public string ReadAloudText => IsSpeaking ? "Stop" : "Read aloud";

    /// <summary>Pause or Resume, while this answer is read aloud.</summary>
    public string PauseText => _owner.IsPaused ? "Resume" : "Pause";

    public string PauseGlyph => _owner.IsPaused ? Icons.Play : Icons.Pause;

    internal void NotifyPause() => Notify(nameof(PauseText), nameof(PauseGlyph));

    /// <summary>"1.0 s · 5,001 tokens · 4,275 in · 726 out" (or "· evidence mode").</summary>
    public string Meta
    {
        get
        {
            if (IsStreaming)
            {
                return "Writing…";
            }
            var parts = new List<string> { $"{Message.DurationMs / 1000.0:0.0} s" };
            if (Message.TotalTokens > 0)
            {
                parts.Add($"{Message.TotalTokens:N0} tokens");
                parts.Add($"{Message.InputTokens:N0} in");
                parts.Add($"{Message.OutputTokens:N0} out");
            }
            else if (Message.Model == "evidence")
            {
                parts.Add("evidence mode · no tokens");
            }
            parts.Add($"depth {Message.Depth}");
            return string.Join(" · ", parts);
        }
    }

    public ICommand CopyCommand { get; }
    public ICommand ReadAloudCommand { get; }
    public ICommand PauseCommand { get; }

    /// <summary>The files attached to this question.</summary>
    public IReadOnlyList<AttachmentChip> Attachments => Message.Attachments?.Select(a => new AttachmentChip(a)).ToList() ?? [];

    public bool HasAttachments => Message.Attachments is { Count: > 0 };
    public ICommand RetryCommand { get; }
    public ICommand EditCommand { get; }

    /// <summary>Puts back the files a Test Fix run changed (those changed since are left alone).</summary>
    public ICommand UndoTestFixCommand { get; }

    /// <summary>A Test Fix report (its run's changes can be undone).</summary>
    public bool IsTestFixReport => !IsUser && Message.TestFixRunId is not null;

    public void Refresh() => Notify(nameof(Meta), nameof(Text));

    // ----- Progress while the answer is prepared (only stages the assistant reports) -----

    private ProgressStage? _stage;
    private IReadOnlyList<string> _stageFiles = [];
    private bool _isSlow;

    public ProgressStage? Stage
    {
        get => _stage;
        set
        {
            if (Set(ref _stage, value))
            {
                Notify(nameof(StageText), nameof(VisualStage));
            }
        }
    }

    /// <summary>The files the evidence came from (the animation lights cards with these names).</summary>
    public IReadOnlyList<string> StageFiles { get => _stageFiles; set => Set(ref _stageFiles, value); }

    /// <summary>No new stage for a while: a calm note, said once.</summary>
    public bool IsSlow
    {
        get => _isSlow;
        set
        {
            if (Set(ref _isSlow, value))
            {
                Notify(nameof(StageText));
            }
        }
    }

    /// <summary>The stage the explorer scene draws (Test Fix's stages are drawn as the nearest of the answer's).</summary>
    public ProgressStage? VisualStage => Stage switch
    {
        ProgressStage.Inspecting => ProgressStage.Understanding,
        ProgressStage.Reproducing => ProgressStage.Finding,
        ProgressStage.Analysing => ProgressStage.Connecting,
        ProgressStage.Patching or ProgressStage.Applying or ProgressStage.Verifying => ProgressStage.Writing,
        _ => Stage,
    };

    /// <summary>What is happening, in plain words; it changes only when the stage does (it is read out by screen readers).</summary>
    public string StageText => (Stage switch
    {
        ProgressStage.Inspecting => "Inspecting project",
        ProgressStage.Reproducing => "Reproducing failures",
        ProgressStage.Analysing => "Analysing root cause",
        ProgressStage.Patching => "Preparing patch",
        ProgressStage.Applying => "Applying changes",
        ProgressStage.Verifying => "Verifying repair",
        ProgressStage.Understanding => "Understanding your question",
        ProgressStage.Finding => StageFiles.Count == 0 ? "Finding relevant files" : $"Finding relevant files · {StageFiles.Count} found",
        ProgressStage.Connecting => "Checking how the pieces connect",
        ProgressStage.Writing => "Preparing a clear explanation",
        ProgressStage.Ready => "Ready",
        _ => "Exploring the repository",
    }) + (IsSlow && Stage != ProgressStage.Ready ? " — this is taking longer than usual; it is still working, or you can stop it." : "");

    // ----- After a failure: ask the same question again -----

    private string? _resendQuestion;

    /// <summary>The question to ask again when this answer failed (an error, not a stop).</summary>
    public string? ResendQuestion
    {
        get => _resendQuestion;
        set
        {
            if (Set(ref _resendQuestion, value))
            {
                Notify(nameof(CanResend));
            }
        }
    }

    public bool CanResend => ResendQuestion is not null;

    // ----- Summaries of this answer's diagrams (shown under each diagram) -----

    /// <summary>The summary kept for one of this answer's diagrams, if one was made.</summary>
    public string? DiagramSummary(string code)
        => Message.DiagramSummaries?.GetValueOrDefault(SummaryRequest.Key(code));

    /// <summary>Summarises one of this answer's diagrams and keeps the summary with the answer.</summary>
    public async Task<string> SummariseDiagramAsync(string code, Action<string> onDelta)
    {
        var summary = await _owner.SummariseDiagramOfAnswerAsync(this, code, onDelta);
        Message.DiagramSummaries ??= [];
        Message.DiagramSummaries[SummaryRequest.Key(code)] = summary;
        return summary;
    }

    // ----- A diagram of this answer fixed by the model -----

    /// <summary>Whether this answer is complete (a diagram still arriving is not "broken").</summary>
    public bool IsComplete => !IsStreaming;

    /// <summary>A diagram of this answer was fixed: the answer shows and keeps the fixed one. False when it is not found.</summary>
    public async Task<bool> ReplaceDiagramAsync(string oldCode, string newCode)
    {
        if (!Text.Contains(oldCode, StringComparison.Ordinal))
        {
            return false;
        }
        Message.Text = Text.Replace(oldCode, newCode, StringComparison.Ordinal);
        Text = Message.Text;
        await _owner.ReplaceDiagramAsync(this, oldCode, newCode);
        return true;
    }

    // ----- Download this answer on its own -----

    private ResponseDownloadViewModel? _download;

    /// <summary>The Download panel (made when first opened: it reads the answer's diagrams).</summary>
    public ResponseDownloadViewModel? Download => _download;

    public ICommand DownloadCommand => new RelayCommand(() =>
    {
        _download ??= new ResponseDownloadViewModel(this, _owner);
        Notify(nameof(Download));
        _download.IsOpen = !_download.IsOpen;
    }, () => !IsStreaming && Text.Length > 0);
    public ICommand ResendCommand => new AsyncCommand(() => _owner.ResendAsync(this), () => !_owner.IsBusy);

    // ----- An answer written as a Word document or a deck (the Word document and PowerPoint skills) -----

    private ResponseFormat? OutputFormat => Message.Output switch { "word" => ResponseFormat.Word, "powerpoint" => ResponseFormat.PowerPoint, _ => null };

    public bool HasOutput => !IsUser && OutputFormat is not null;
    public string OutputText => OutputFormat == ResponseFormat.PowerPoint ? "Save as PowerPoint" : "Save as Word";
    public string OutputToolTip => OutputFormat == ResponseFormat.PowerPoint
        ? "Save this answer as a PowerPoint deck (.pptx): one slide per section, diagrams as pictures, speaker notes"
        : "Save this answer as a Word document (.docx), diagrams as pictures";

    public ICommand SaveOutputCommand => new AsyncCommand(async () =>
    {
        if (OutputFormat is not { } format)
        {
            return;
        }
        _download ??= new ResponseDownloadViewModel(this, _owner);
        Notify(nameof(Download));
        await _download.SaveAsAsync(format);
    }, () => !IsStreaming && Text.Length > 0);
}

/// <summary>The repository assistant panel.</summary>
public sealed partial class AssistantViewModel : ObservableObject
{
    private string _input = "";
    private AnalysisDepth _depth = AnalysisDepth.Auto;
    private bool _isBusy;
    private bool _focusInput;
    private bool _showHistory;
    private bool _isRecording;
    private string? _conversationId;
    private string? _editingMessageId;
    private string _statusNotice = "";
    private bool _modelConfigured;
    private CancellationTokenSource? _cts;
    private ChatMessageViewModel? _speaking;

    /// <param name="talk">Talk: a persona conversation (its own conversations, persona styles, greetings) instead of Ask.</param>
    public AssistantViewModel(WorkspaceViewModel workspace, bool talk = false)
    {
        Workspace = workspace;
        IsTalk = talk;
        _personaId = talk ? workspace.Main.TalkPersonaId : null;
        SendCommand = new AsyncCommand(SendAsync, () => !IsBusy && (Input.Trim().Length > 0 || PendingAttachments.Count > 0));
        StopCommand = new RelayCommand(() => _cts?.Cancel(), () => IsBusy);
        UseSuggestionCommand = new AsyncCommand(async p =>
        {
            Input = p as string ?? "";
            await SendAsync();
        }, _ => !IsBusy);
        NewConversationCommand = new RelayCommand(NewConversation, () => !IsBusy);
        ClearConversationCommand = new AsyncCommand(ClearAsync, () => !IsBusy && Messages.Count > 0);
        ToggleHistoryCommand = new AsyncCommand(async () =>
        {
            ShowHistory = !ShowHistory;
            if (ShowHistory)
            {
                await LoadHistoryAsync();
            }
        });
        OpenConversationCommand = new AsyncCommand(async p =>
        {
            if (p is ConversationSummary summary)
            {
                await OpenConversationAsync(summary.Id);
            }
        });
        DeleteConversationCommand = new AsyncCommand(async p =>
        {
            if (p is ConversationSummary summary)
            {
                await Service.DeleteConversationAsync(workspace.Record.Id, summary.Id);
                if (summary.Id == _conversationId)
                {
                    NewConversation();
                }
                await LoadHistoryAsync();
            }
        });
        CancelEditCommand = new RelayCommand(() => { _editingMessageId = null; Input = ""; OnPropertyChanged(nameof(IsEditing)); });
        ShowDetailsCommand = new RelayCommand(() => ShowDetails = !ShowDetails);
        RewriteCommand = new AsyncCommand(RewriteAsync, () => !IsBusy && !IsRewriting && Input.Trim().Length > 0);
        UndoRewriteCommand = new RelayCommand(() =>
        {
            if (_beforeRewrite is not null)
            {
                Input = _beforeRewrite;
                ClearRewrite();
                FocusInput = true;
            }
        });
        workspace.Main.Speech.PausedChanged += (_, _) =>
        {
            Notify(nameof(IsPaused), nameof(PauseText));
            _speaking?.NotifyPause();
        };
        workspace.Main.Speech.PlaybackEnded += (_, _) =>
        {
            if (_speaking is not null)
            {
                _speaking.IsSpeaking = false;
                _speaking = null;
                Notify(nameof(IsSpeakingAny));
            }
        };
        workspace.Tree.ScopeChanged += (_, _) => OnPropertyChanged(nameof(ScopeText));
        workspace.Main.Engine.Indexing.Progress += (_, e) => { if (e.RepositoryId == workspace.Record.Id) { Ui.Post(() => Notify(nameof(StatusText), nameof(StatusKey))); } };
        workspace.Main.Engine.Indexing.Completed += (_, e) => { if (e.RepositoryId == workspace.Record.Id) { Ui.Post(() => Notify(nameof(StatusText), nameof(StatusKey))); } };
    }

    public WorkspaceViewModel Workspace { get; }

    // ----- Talk -----

    /// <summary>Talk rather than Ask.</summary>
    public bool IsTalk { get; }

    /// <summary>The engine service: Ask's or Talk's (each keeps its own conversations, per repository).</summary>
    private Engine.Assistant.AssistantService Service => IsTalk ? Workspace.Main.Engine.Talk : Workspace.Main.Engine.Assistant;

    private string? _personaId;
    private bool _speakReplies;

    public IReadOnlyList<TalkPersona> Personas => TalkPersonas.All;

    /// <summary>The persona answering (Talk); null in Ask.</summary>
    public TalkPersona? Persona
    {
        get => TalkPersonas.Find(_personaId);
        set
        {
            if (value is null || value.Id == _personaId)
            {
                return;
            }
            var before = Persona;
            _personaId = value.Id;
            Workspace.Main.TalkPersonaId = value.Id;
            Notify(nameof(Persona), nameof(Title), nameof(Greeting), nameof(InputHint));
            ShowStarters();
            // The conversation stays; the switch is said in it, so later answers read in the new voice for a reason.
            if (before is not null && Messages.Count > 0)
            {
                // Switching again before anything is said replaces the last notice rather than stacking another.
                if (Messages[^1].IsNotice)
                {
                    Messages.RemoveAt(Messages.Count - 1);
                }
                // Back to the persona that answered last: nothing to announce.
                if (Messages.LastOrDefault(m => m.IsAssistant && !m.IsNotice)?.Message.Persona != value.Name)
                {
                    Messages.Add(new ChatMessageViewModel(new ChatMessage { Role = "assistant", Model = "notice",
                        Text = $"Now talking with {value.Name}" }, this));
                }
                ScrollRequested?.Invoke(this, EventArgs.Empty);
            }
            Ui.Notify($"Now talking with {value.Name}.");
        }
    }

    /// <summary>The pane's heading: "Repository assistant", or the persona in Talk.</summary>
    public string Title => Persona?.Name ?? "Repository assistant";

    /// <summary>Talk's greeting on an empty conversation, by the time of day on this PC (its own clock and time zone).</summary>
    public string Greeting
    {
        get
        {
            if (!IsTalk || Persona is not { } persona)
            {
                return "";
            }
            var hour = DateTime.Now.Hour;
            var hello = hour switch { >= 5 and < 12 => "Good morning", >= 12 and < 17 => "Good afternoon", >= 17 and < 22 => "Good evening", _ => "Hello" };
            return $"{hello}! I am your {persona.Name}. Ask me anything about {Workspace.Record.Title}, or pick a question below.";
        }
    }

    public bool HasGreeting => IsTalk && !HasMessages;

    public string InputHint => IsTalk && Persona is { } persona ? $"Talk with the {persona.Name} about {Workspace.Record.Title}…"
        : IsTestFixMode ? "Describe the failure — or attach the failing test, its log or stack trace…" : "Ask anything about this repository…";

    /// <summary>The repository and branch a Talk conversation is about (shown, so it is never in doubt).</summary>
    public string ContextText => Workspace.Record.Title + (Workspace.Record.Source == "git" && Workspace.Record.Branch is { Length: > 0 } branch ? $" · branch {branch}" : " · local folder");

    /// <summary>Talk: read each answer aloud when it is ready (off until the person turns it on).</summary>
    public bool SpeakReplies
    {
        get => _speakReplies;
        set
        {
            if (Set(ref _speakReplies, value) && !value)
            {
                StopSpeaking();
            }
        }
    }

    public bool IsSpeakingAny => _speaking is not null;

    /// <summary>Whether reading aloud is paused.</summary>
    public bool IsPaused => Workspace.Main.Speech.IsPaused;

    public string PauseText => IsPaused ? "Resume" : "Pause";

    public ICommand PauseSpeakingCommand => new RelayCommand(TogglePause, () => IsSpeakingAny);

    /// <summary>Pauses reading aloud, or carries on from where it was paused.</summary>
    public void TogglePause()
    {
        var speech = Workspace.Main.Speech;
        if (speech.IsPaused)
        {
            speech.Resume();
        }
        else
        {
            speech.Pause();
        }
    }
    public ICommand StopSpeakingCommand => new RelayCommand(StopSpeaking, () => IsSpeakingAny);

    private void StopSpeaking()
    {
        if (_speaking is not null)
        {
            Workspace.Main.Speech.Stop();
            _speaking.IsSpeaking = false;
            _speaking = null;
            Notify(nameof(IsSpeakingAny));
        }
    }

    private bool _loaded;

    /// <summary>Talk: loads the first time the section opens (its conversation, the persona's starters).</summary>
    public async Task EnsureLoadedAsync()
    {
        if (_loaded)
        {
            return;
        }
        _loaded = true;
        await LoadAsync();
    }

    /// <summary>Talk's starter questions: the persona's own.</summary>
    private void ShowStarters()
    {
        if (!IsTalk || Persona is not { } persona)
        {
            return;
        }
        Suggestions.Clear();
        foreach (var starter in persona.Starters)
        {
            Suggestions.Add(starter);
        }
    }

    public ObservableCollection<ChatMessageViewModel> Messages { get; } = [];
    public ObservableCollection<string> Suggestions { get; } = [];
    public ObservableCollection<ConversationSummary> History { get; } = [];

    public ICommand SendCommand { get; }
    public ICommand StopCommand { get; }
    public ICommand UseSuggestionCommand { get; }
    public ICommand NewConversationCommand { get; }
    public ICommand ClearConversationCommand { get; }
    public ICommand ToggleHistoryCommand { get; }
    public ICommand OpenConversationCommand { get; }
    public ICommand DeleteConversationCommand { get; }
    public ICommand CancelEditCommand { get; }
    public ICommand ShowDetailsCommand { get; }
    public ICommand RewriteCommand { get; }
    public ICommand UndoRewriteCommand { get; }

    private bool _isRewriting;
    private string? _beforeRewrite;
    private string? _rewritten;
    private string _rewriteNote = "";

    /// <summary>The question is being rewritten (by the model, or offline).</summary>
    public bool IsRewriting
    {
        get => _isRewriting;
        private set
        {
            if (Set(ref _isRewriting, value))
            {
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    /// <summary>Who rewrote the question and what changed; shown above the box with an Undo link.</summary>
    public string RewriteNote
    {
        get => _rewriteNote;
        private set
        {
            if (Set(ref _rewriteNote, value))
            {
                OnPropertyChanged(nameof(HasRewrite));
            }
        }
    }

    public bool HasRewrite => RewriteNote.Length > 0;

    private void ClearRewrite()
    {
        _beforeRewrite = null;
        _rewritten = null;
        RewriteNote = "";
    }

    private async Task RewriteAsync()
    {
        var original = Input;
        IsRewriting = true;
        try
        {
            var result = await Service.RewriteAsync(Workspace.Record.Id, original);
            if (Input != original)
            {
                return; // typed over meanwhile: keep what was typed
            }
            if (string.Equals(result.Text.Trim(), original.Trim(), StringComparison.Ordinal))
            {
                Ui.Notify("The question already reads well; nothing to change.");
                return;
            }
            _beforeRewrite = original;
            _rewritten = result.Text;
            Input = result.Text;
            var by = result.By == "offline" ? "Corrected offline" : $"Rewritten by {result.By}";
            RewriteNote = result.Changes.Count > 0 ? $"{by}: {string.Join("; ", result.Changes.Take(4))}" : by;
            FocusInput = true;
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            Ui.Notify("The question could not be rewritten: " + ex.Message);
            Logging.Error(ex, "Rewrite");
        }
        finally
        {
            IsRewriting = false;
        }
    }

    public IReadOnlyList<AnalysisDepth> Depths { get; } = Enum.GetValues<AnalysisDepth>();

    /// <summary>
    /// The composer's model picker: evidence mode, then every model of the imported providers. Choosing one sets the
    /// chat model for the whole explorer (the same choice as Settings → Chat model).
    /// </summary>
    public ObservableCollection<ModelChoice> ModelChoices { get; } = [];

    private ModelChoice? _selectedModelChoice;
    private bool _loadingModels;

    public ModelChoice? SelectedModelChoice
    {
        get => _selectedModelChoice;
        set
        {
            // A null from the picker while its list is rebuilt is not a choice.
            if (value is null || !Set(ref _selectedModelChoice, value) || _loadingModels)
            {
                return;
            }
            _ = ChooseModelAsync(value);
        }
    }

    private async Task ChooseModelAsync(ModelChoice choice)
    {
        await Workspace.Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.ChatModelId = choice.Id);
        await RefreshModelAsync();
        Ui.Notify(choice.Id is null ? "Answers are composed from evidence, offline." : $"Answers now use {choice.Label}.");
    }

    /// <summary>Reads the chat model and what the models can do now: the picker, the notice and its suggestion.</summary>
    private async Task RefreshModelAsync()
    {
        var models = Workspace.Main.Engine.Models;
        var status = await models.GetStatusAsync();
        _modelConfigured = status.Configured;
        StatusNotice = status.Description;
        _suggestedModel = status.Configured ? null : await models.FirstUsableModelAsync();
        var ai = await models.Ai.GetAsync();
        var chosen = (await models.GetExplorerSettingsAsync()).ChatModelId;
        _loadingModels = true;
        try
        {
            ModelChoices.Clear();
            ModelChoices.Add(new ModelChoice(null, "Evidence mode", "Offline: answers are composed from the index; nothing leaves this PC."));
            foreach (var model in ai.Models.Where(m => m.Enabled))
            {
                var provider = ai.Providers.FirstOrDefault(p => p.Id == model.ProviderId);
                if (provider is null || !provider.Enabled)
                {
                    continue;
                }
                var state = provider.Kind == Engine.Ai.AiProviderKinds.Simulator ? " · offline simulator"
                    : provider.NeedsKey && provider.ApiKey.Length == 0 ? " · needs an API key (Settings → Providers and models)" : "";
                ModelChoices.Add(new ModelChoice(model.Id, string.IsNullOrWhiteSpace(model.DisplayName) ? model.Id : model.DisplayName, provider.Name + state));
            }
            _selectedModelChoice = ModelChoices.FirstOrDefault(c => string.Equals(c.Id, chosen, StringComparison.OrdinalIgnoreCase)) ?? ModelChoices[0];
            OnPropertyChanged(nameof(SelectedModelChoice));
        }
        finally
        {
            _loadingModels = false;
        }
        Notify(nameof(ShowNotice), nameof(StatusText), nameof(StatusKey), nameof(DetailsText), nameof(SuggestedModelLabel), nameof(HasSuggestedModel));
    }

    /// <summary>The skill: chosen from the question (Auto), or none. Skills are managed under Settings → Skills.</summary>
    public ObservableCollection<SkillChoice> SkillChoices { get; } = [SkillChoice.Auto, SkillChoice.None];

    private SkillChoice? _selectedSkill = SkillChoice.Auto;

    public SkillChoice? SelectedSkill
    {
        get => _selectedSkill;
        set
        {
            // A null from the picker while its list is rebuilt is not a choice.
            if (value is not null)
            {
                Set(ref _selectedSkill, value);
            }
        }
    }

    /// <summary>Re-reads the skills that are on (after Settings → Skills changes), keeping the choice when it is still there.</summary>
    public async Task LoadSkillsAsync()
    {
        var keep = SelectedSkill?.Id;
        var enabled = await Workspace.Main.Engine.Skills.EnabledAsync();
        // Auto and No skill stay; only the skills after them are replaced (clearing the whole list leaves WPF's picker
        // showing nothing even after its selection is set again).
        if (keep is not ("auto" or "none") && enabled.All(s => s.Id != keep))
        {
            SelectedSkill = SkillChoice.Auto; // the chosen skill was turned off
        }
        for (var i = SkillChoices.Count - 1; i >= 2; i--)
        {
            if (SkillChoices[i].Id != SelectedSkill?.Id)
            {
                SkillChoices.RemoveAt(i);
            }
        }
        var position = 2;
        foreach (var skill in enabled)
        {
            var choice = new SkillChoice(skill.Id, $"{skill.Icon} {skill.Name}", skill.Manifest.Description);
            if (position < SkillChoices.Count && SkillChoices[position].Id == skill.Id)
            {
                position++;
                continue; // the selected one, kept in place
            }
            SkillChoices.Insert(Math.Min(position++, SkillChoices.Count), choice);
        }
        CanTestFix = !IsTalk && enabled.Any(s => s.Capability == "test-fix");
    }

    public string Input
    {
        get => _input;
        set
        {
            if (Set(ref _input, value) && _rewritten is not null && value != _rewritten)
            {
                ClearRewrite(); // edited after the rewrite: the note no longer describes it
            }
        }
    }

    public AnalysisDepth Depth
    {
        get => _depth;
        set => Set(ref _depth, value);
    }

    public bool IsBusy
    {
        get => _isBusy;
        private set
        {
            if (Set(ref _isBusy, value))
            {
                Notify(nameof(StatusText), nameof(StatusKey));
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    private string _busyText = "";

    /// <summary>While answering: the step under way and how long it has taken so far (shown beside the Stop button).</summary>
    public string BusyText
    {
        get => _busyText;
        private set => Set(ref _busyText, value);
    }

    private bool IndexRunning => Workspace.Main.Engine.Indexing.IsRunning(Workspace.Record.Id);
    public string StatusText => IsBusy ? "Thinking" : Workspace.IsLoading ? "Loading index" : IndexRunning ? "Indexing"
        : Workspace.IsIndexed ? (Workspace.IsSearchReady ? "Ready" : "Preparing search") : "Not indexed";
    public string StatusKey => IsBusy || IndexRunning || Workspace.IsLoading || (Workspace.IsIndexed && !Workspace.IsSearchReady) ? "busy" : Workspace.IsIndexed ? "ready" : "idle";

    internal void OnLoadingChanged() => Notify(nameof(StatusText), nameof(StatusKey));

    public bool FocusInput
    {
        get => _focusInput;
        set => Set(ref _focusInput, value);
    }

    public bool ShowHistory
    {
        get => _showHistory;
        set => Set(ref _showHistory, value);
    }

    private bool _showDetails;

    public bool ShowDetails
    {
        get => _showDetails;
        set => Set(ref _showDetails, value);
    }

    public string DetailsText
    {
        get
        {
            var c = Workspace.Record.Counters;
            return $"{c.Files:N0} files · {c.Chunks:N0} chunks · {c.GraphNodes:N0} graph nodes · state {(_modelConfigured ? "model" : "offline")} / {(_modelConfigured ? "generated answers" : "offline-evidence")}";
        }
    }

    public bool IsRecording
    {
        get => _isRecording;
        set => Set(ref _isRecording, value);
    }

    public bool IsEditing => _editingMessageId is not null;

    public bool HasMessages => Messages.Count > 0;

    public string StatusNotice
    {
        get => _statusNotice;
        private set => Set(ref _statusNotice, value);
    }

    public bool ShowNotice => !_modelConfigured;

    private Engine.Ai.AiModel? _suggestedModel;

    /// <summary>A model that could answer now, offered by the evidence-mode notice ("Use Example Chat").</summary>
    public string? SuggestedModelLabel => _suggestedModel is null ? null
        : "Use " + (string.IsNullOrWhiteSpace(_suggestedModel.DisplayName) ? _suggestedModel.Id : _suggestedModel.DisplayName);

    public bool HasSuggestedModel => _suggestedModel is not null;

    public ICommand UseSuggestedModelCommand => new AsyncCommand(async () =>
    {
        if (_suggestedModel is { } model)
        {
            await Workspace.Main.Engine.Models.UpdateExplorerSettingsAsync(s => s.ChatModelId = model.Id);
            await LoadAsync();
            Ui.Notify($"Answers now use {(string.IsNullOrWhiteSpace(model.DisplayName) ? model.Id : model.DisplayName)}.");
        }
    });

    public ICommand ChooseModelCommand => new RelayCommand(() =>
    {
        Workspace.Main.Navigate(Section.Settings);
        Workspace.Main.Settings.ShowPage(SettingsPages.Model);
    });

    public string TokenSummary
    {
        get
        {
            var tokens = Messages.Sum(m => m.Message.TotalTokens);
            var seconds = Messages.Sum(m => m.Message.DurationMs) / 1000.0;
            return Messages.Count == 0 ? "" : tokens > 0 ? $"{tokens:N0} tokens · {seconds:0} s" : $"offline · {seconds:0.#} s";
        }
    }

    public string ScopeText => Workspace.Tree.Scope.Count == 0 ? "" : "Limited to: " + Workspace.Tree.ScopeDescription;

    public async Task LoadAsync()
    {
        await LoadSkillsAsync();
        if (!IsTalk)
        {
            await RecoverTestFixAsync();
        }
        await RefreshModelAsync();
        var index = Workspace.Index;
        var suggestions = await Task.Run(() => Engine.Assistant.AssistantService.Suggestions(index));
        Suggestions.Clear();
        foreach (var suggestion in IsTalk && Persona is { } talker ? talker.Starters : suggestions)
        {
            Suggestions.Add(suggestion);
        }
        Notify(nameof(ShowNotice), nameof(StatusText), nameof(StatusKey), nameof(DetailsText));
        if (_conversationId is null)
        {
            // Re-open the most recent conversation about this repository.
            var recent = (await Service.ListConversationsAsync(Workspace.Record.Id)).FirstOrDefault();
            if (recent is not null && recent.UpdatedAt > DateTime.UtcNow.AddDays(-2))
            {
                await OpenConversationAsync(recent.Id);
            }
        }
    }

    private Task LoadHistoryAsync() => ReloadHistoryAsync();

    private async Task OpenConversationAsync(string id)
    {
        var conversation = await Service.GetOrCreateAsync(Workspace.Record.Id, id);
        _conversationId = conversation.Messages.Count > 0 ? conversation.Id : null;
        Messages.Clear();
        foreach (var message in conversation.Messages)
        {
            Messages.Add(new ChatMessageViewModel(message, this));
        }
        ShowHistory = false;
        Notify(nameof(HasGreeting), nameof(HasMessages), nameof(TokenSummary));
        if (IsSearchOpen && SearchText.Trim().Length > 0)
        {
            // The conversation was opened from a search: its words marked, at the first place they are.
            await ApplySearchAsync();
            return;
        }
        ScrollRequested?.Invoke(this, EventArgs.Empty);
    }

    /// <summary>Raised when the thread should scroll to its end (a question sent, a conversation opened).</summary>
    public event EventHandler? ScrollRequested;

    /// <summary>
    /// Raised while an answer is written: the thread follows it to the end only while the reader is at the end (scrolling up
    /// to read stops the following; scrolling back down resumes it).
    /// </summary>
    public event EventHandler? FollowRequested;

    private void NewConversation()
    {
        _cts?.Cancel();
        _conversationId = null;
        _editingMessageId = null;
        Messages.Clear();
        Input = "";
        Notify(nameof(HasGreeting), nameof(HasMessages), nameof(TokenSummary), nameof(IsEditing));
        FocusInput = false;
        FocusInput = true;
    }

    private async Task ClearAsync()
    {
        if (_conversationId is not null)
        {
            await Service.DeleteConversationAsync(Workspace.Record.Id, _conversationId);
        }
        NewConversation();
    }

    public void BeginEdit(ChatMessageViewModel message)
    {
        _editingMessageId = message.Message.Id;
        Input = message.Text;
        OnPropertyChanged(nameof(IsEditing));
        FocusInput = false;
        FocusInput = true;
    }

    public void ReadAloud(ChatMessageViewModel message)
    {
        var speech = Workspace.Main.Speech;
        if (message.IsSpeaking)
        {
            speech.Stop();
            message.IsSpeaking = false;
            _speaking = null;
            Notify(nameof(IsSpeakingAny));
            return;
        }
        if (_speaking is not null)
        {
            _speaking.IsSpeaking = false;
        }
        _speaking = message;
        message.IsSpeaking = true;
        message.NotifyPause();
        Notify(nameof(IsSpeakingAny));
        speech.Speak(message.Text);
    }

    // ----- Attachments: files sent with the next question -----

    /// <summary>The files attached to the question being written.</summary>
    public System.Collections.ObjectModel.ObservableCollection<AttachmentChip> PendingAttachments { get; } = [];

    public bool HasPendingAttachments => PendingAttachments.Count > 0;

    public ICommand AttachCommand => new AsyncCommand(async () =>
    {
        var readable = string.Join(";", Engine.Assistant.Attachments.Kinds.SelectMany(k => k.Extensions).Select(e => "*" + e));
        var dialog = new Microsoft.Win32.OpenFileDialog
        {
            Title = "Attach files",
            Multiselect = true,
            // Any file can be attached (like a chat app); the ones there is a reader for are read.
            Filter = "All files (*.*)|*.*|Files that can be read|" + readable + "|"
                     + string.Join("|", Engine.Assistant.Attachments.Kinds.Select(k => $"{k.Name}|{string.Join(";", k.Extensions.Select(e => "*" + e))}")),
            FilterIndex = 1,
        };
        if (dialog.ShowDialog() == true)
        {
            await AttachAsync(dialog.FileNames);
        }
    });

    public ICommand RemoveAttachmentCommand => new RelayCommand(p =>
    {
        if (p is AttachmentChip chip)
        {
            PendingAttachments.Remove(chip);
            Notify(nameof(HasPendingAttachments));
        }
    });

    private int _pastedText;
    private int _pastedImages;

    /// <summary>Pasted text as an attachment: "Pasted text 1.json", named by what it is.</summary>
    public async Task AttachPastedTextAsync(string text)
    {
        var settings = await Workspace.Main.Engine.Models.GetExplorerSettingsAsync();
        if (!RoomFor(settings))
        {
            return;
        }
        var kind = Engine.Assistant.Attachments.PastedKind(text);
        var attachment = Engine.Assistant.Attachments.FromText($"Pasted text {++_pastedText}.{kind}", text, settings.AttachmentRules);
        AddAttachment(attachment);
    }

    /// <summary>A pasted picture as an attachment, scaled within Settings → Attachments: "Pasted image 1.png".</summary>
    public async Task AttachPastedImageAsync(byte[] png)
    {
        var settings = await Workspace.Main.Engine.Models.GetExplorerSettingsAsync();
        if (!RoomFor(settings))
        {
            return;
        }
        var name = $"Pasted image {++_pastedImages}.png";
        var rule = Engine.Assistant.Attachments.RuleFor(settings.AttachmentRules, Engine.Assistant.Attachments.Image);
        var attachment = await Task.Run(() => ImageAttachments.FromBytes(png, name, rule));
        AddAttachment(attachment);
    }

    private bool RoomFor(ExplorerSettings settings)
    {
        if (PendingAttachments.Count < settings.MaxAttachments)
        {
            return true;
        }
        Ui.Notify($"At most {settings.MaxAttachments} files can be attached to one question (Settings → Attachments).");
        return false;
    }

    private void AddAttachment(Attachment attachment)
    {
        PendingAttachments.Add(new AttachmentChip(attachment));
        Logging.Info($"Attached {attachment.Name}: {attachment.Status}{(attachment.Note is null ? "" : " — " + attachment.Note)}");
        Notify(nameof(HasPendingAttachments));
        CommandManager.InvalidateRequerySuggested();
        FocusInput = false;
        FocusInput = true;
    }

    /// <summary>Attaches files (from the picker, or dropped on the question box), read within the limits of Settings → Attachments.</summary>
    public async Task AttachAsync(IEnumerable<string> paths)
    {
        var settings = await Workspace.Main.Engine.Models.GetExplorerSettingsAsync();
        foreach (var path in paths.Where(p => !Directory.Exists(p)))
        {
            if (PendingAttachments.Count >= settings.MaxAttachments)
            {
                Ui.Notify($"At most {settings.MaxAttachments} files can be attached to one question (Settings → Attachments).");
                break;
            }
            if (PendingAttachments.Any(a => string.Equals(a.Name, Path.GetFileName(path), StringComparison.OrdinalIgnoreCase) && a.Attachment.Size == new FileInfo(path).Length))
            {
                continue; // the same file twice
            }
            // Images are scaled here (Settings → Attachments); everything else is read by the engine.
            var attachment = await Task.Run(() => Engine.Assistant.Attachments.KindOf(path) == Engine.Assistant.Attachments.Image
                ? ImageAttachments.Read(path, Engine.Assistant.Attachments.RuleFor(settings.AttachmentRules, Engine.Assistant.Attachments.Image))
                : Engine.Assistant.Attachments.Read(path, settings.AttachmentRules));
            PendingAttachments.Add(new AttachmentChip(attachment));
            Logging.Info($"Attached {attachment.Name}: {attachment.Status}{(attachment.Note is null ? "" : " — " + attachment.Note)}");
        }
        Notify(nameof(HasPendingAttachments));
        FocusInput = false;
        FocusInput = true;
    }

    private System.Windows.Threading.DispatcherTimer? _silence;

    /// <summary>
    /// While dictating: stops by itself once nothing has been heard for the seconds set in Settings → Voice → Microphone
    /// (counted from the start, or from the last sound), as if the microphone button were clicked.
    /// </summary>
    private void WatchSilence()
    {
        _silence?.Stop();
        var speech = Workspace.Main.Speech;
        var seconds = speech.SilenceStopSeconds;
        if (seconds <= 0)
        {
            return;
        }
        var lastSound = DateTime.UtcNow;
        var recent = new Queue<double>();
        _silence = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromMilliseconds(200) };
        _silence.Tick += async (_, _) =>
        {
            if (!IsRecording)
            {
                _silence?.Stop();
                return;
            }
            // The room's own noise: the quieter part of the last five seconds (a hum or a fan, not a voice).
            var level = speech.MicrophoneLevel;
            recent.Enqueue(level);
            if (recent.Count > 25)
            {
                recent.Dequeue();
            }
            var room = recent.Order().ElementAt(recent.Count * 3 / 10);
            if (level > SpeechService.SoundAbove(room))
            {
                lastSound = DateTime.UtcNow;
            }
            else if (DateTime.UtcNow - lastSound >= TimeSpan.FromSeconds(seconds))
            {
                _silence?.Stop();
                Logging.Info($"Dictation stopped after {seconds} s without sound.");
                await StopRecordingAsync();
            }
        };
        _silence.Start();
    }

    private string _dictationPreview = "";

    /// <summary>The words heard so far while dictating (shown above the question box).</summary>
    public string DictationPreview
    {
        get => _dictationPreview;
        private set => Set(ref _dictationPreview, value);
    }

    private void OnHearing(string text) => DictationPreview = text;

    public async Task StartRecordingAsync()
    {
        if (IsBusy || IsRecording)
        {
            return;
        }
        DictationPreview = "";
        Workspace.Main.Speech.Hearing -= OnHearing;
        Workspace.Main.Speech.Hearing += OnHearing;
        IsRecording = await Workspace.Main.Speech.StartDictationAsync();
        if (IsRecording)
        {
            WatchSilence();
        }
        if (!IsRecording)
        {
            // No microphone, access refused in Windows' privacy settings, or no speech recogniser: typing still works.
            Ui.Notify("The microphone could not be started. Check that one is connected and that apps may use it (Windows Settings → Privacy → Microphone); you can still type.");
        }
        await Task.CompletedTask;
    }

    public async Task StopRecordingAsync()
    {
        if (!IsRecording)
        {
            return;
        }
        IsRecording = false;
        _silence?.Stop();
        var text = await Workspace.Main.Speech.StopDictationAsync();
        Workspace.Main.Speech.Hearing -= OnHearing;
        DictationPreview = "";
        if (text.Length > 0)
        {
            Input = (Input.Trim() + " " + text).Trim();
            // Settings → Voice: a dictated question can be sent at once.
            if (Workspace.Main.Speech.DictationSends)
            {
                await SendAsync();
            }
        }
        else
        {
            Ui.Notify("Nothing was heard.");
        }
    }

    private async Task SendAsync()
    {
        if (IsTestFixMode && !IsTalk)
        {
            await SendTestFixAsync();
            return;
        }
        var question = Input.Trim();
        var attachments = PendingAttachments.Select(a => a.Attachment).ToList();
        if ((question.Length == 0 && attachments.Count == 0) || IsBusy)
        {
            return;
        }
        if (question.Length == 0)
        {
            question = attachments.Count == 1 ? $"What is in {attachments[0].Name}, and how does it relate to this repository?" : "What is in these files, and how do they relate to this repository?";
        }
        Input = "";
        PendingAttachments.Clear();
        Notify(nameof(HasPendingAttachments));
        ClearRewrite();
        var engine = Service;
        var repositoryId = Workspace.Record.Id;
        var scope = Workspace.Tree.Scope.ToList();
        var skill = SelectedSkill?.Id ?? "auto";
        var editing = _editingMessageId;
        var originalText = editing is null ? null : Messages.FirstOrDefault(m => m.Message.Id == editing)?.Message.Text;
        _editingMessageId = null;
        OnPropertyChanged(nameof(IsEditing));

        if (editing is not null)
        {
            var at = Messages.ToList().FindIndex(m => m.Message.Id == editing);
            while (at >= 0 && Messages.Count > at)
            {
                Messages.RemoveAt(Messages.Count - 1);
            }
        }
        Messages.Add(new ChatMessageViewModel(new ChatMessage { Role = "user", Text = question, Depth = Depth, Attachments = attachments.Count > 0 ? attachments : null }, this));
        var pending = new ChatMessageViewModel(new ChatMessage { Role = "assistant", Text = "" }, this) { IsStreaming = true };
        Messages.Add(pending);
        Notify(nameof(HasGreeting), nameof(HasMessages));
        ScrollRequested?.Invoke(this, EventArgs.Empty);

        await RunAsync(pending, async (onDelta, onThinking, ct) => editing is not null && _conversationId is not null
            ? await engine.EditAsync(repositoryId, _conversationId, editing, question, Depth, scope, onDelta, ct, onThinking, originalText, skill, _personaId)
            : await engine.AskAsync(repositoryId, _conversationId, question, Depth, scope, onDelta, ct, onThinking, skill, _personaId, attachments), question);
    }

    public async Task RetryAsync(ChatMessageViewModel message)
    {
        if (_conversationId is null || IsBusy)
        {
            return;
        }
        var at = Messages.IndexOf(message);
        if (at < 0)
        {
            return;
        }
        while (Messages.Count > at)
        {
            Messages.RemoveAt(Messages.Count - 1);
        }
        var pending = new ChatMessageViewModel(new ChatMessage { Role = "assistant", Text = "" }, this) { IsStreaming = true };
        Messages.Add(pending);
        var engine = Service;
        var scope = Workspace.Tree.Scope.ToList();
        var id = message.Message.Id;
        var skill = SelectedSkill?.Id ?? "auto";
        await RunAsync(pending, (onDelta, onThinking, ct) => engine.RetryAsync(Workspace.Record.Id, _conversationId, id, Depth, scope, onDelta, ct, onThinking, skill, _personaId));
    }

    /// <summary>The question an answer replied to (the user message just before it), if any.</summary>
    public string? QuestionFor(ChatMessageViewModel answer)
    {
        var at = Messages.IndexOf(answer);
        return at > 0 && Messages[at - 1].IsUser ? Messages[at - 1].Text : null;
    }

    /// <summary>A diagram of one of this conversation's answers was fixed: the conversation keeps the fixed one.</summary>
    public Task ReplaceDiagramAsync(ChatMessageViewModel answer, string oldCode, string newCode)
        => Service.ReplaceDiagramAsync(Workspace.Record.Id, _conversationId, answer.Message.Id, oldCode, newCode);

    /// <summary>A diagram of one of this conversation's answers, summarised and kept with that answer.</summary>
    public async Task<string> SummariseDiagramOfAnswerAsync(ChatMessageViewModel answer, string code, Action<string> onDelta)
    {
        var message = await Service.SummariseDiagramOfAnswerAsync(Workspace.Record.Id, _conversationId, answer.Message.Id, code, onDelta, default, _personaId);
        return message.Text;
    }

    /// <summary>Summarises a selection (or a diagram's source) as a turn of this conversation.</summary>
    public async Task SummariseAsync(string selection, bool diagram, string? source)
    {
        if (IsBusy)
        {
            Ui.Notify("Wait for the current answer (or stop it), then summarise.");
            return;
        }
        var preview = diagram ? "Summarise this diagram." : $"Summarise this passage{(source is null ? "" : $" from {source}")}:\n\n> {TextUtil.Truncate(selection.ReplaceLineEndings(" "), 280)}";
        Messages.Add(new ChatMessageViewModel(new ChatMessage { Role = "user", Text = preview }, this));
        var pending = new ChatMessageViewModel(new ChatMessage { Role = "assistant", Text = "" }, this) { IsStreaming = true };
        Messages.Add(pending);
        Notify(nameof(HasGreeting), nameof(HasMessages));
        ScrollRequested?.Invoke(this, EventArgs.Empty);
        var repositoryId = Workspace.Record.Id;
        await RunAsync(pending, (onDelta, onThinking, ct) => Service.SummariseAsync(repositoryId, _conversationId, selection, diagram, source, onDelta, ct, onThinking, _personaId));
    }

    /// <summary>A failed answer's question, asked again (the failed pair is removed first).</summary>
    public async Task ResendAsync(ChatMessageViewModel failed)
    {
        if (IsBusy || failed.ResendQuestion is not { } question)
        {
            return;
        }
        var at = Messages.IndexOf(failed);
        if (at > 0 && Messages[at - 1].IsUser)
        {
            Messages.RemoveAt(at);
            Messages.RemoveAt(at - 1);
        }
        Input = question;
        await SendAsync();
    }

    private async Task RunAsync(ChatMessageViewModel pending,
        Func<Action<string>, Action<Engine.Assistant.ThinkingUpdate>, CancellationToken, Task<(Conversation Conversation, ChatMessage Answer)>> call,
        string? question = null)
    {
        IsBusy = true;
        var started = System.Diagnostics.Stopwatch.StartNew();
        BusyText = "Reading the question…";
        _cts = new CancellationTokenSource();
        var buffer = new StringBuilder();
        var reasoning = new StringBuilder();
        var steps = new List<string>();
        ProgressStage? stage = null;
        IReadOnlyList<string> stageFiles = [];
        var sinceStage = System.Diagnostics.Stopwatch.StartNew();
        var reduceMotion = Workspace.Main.ReduceMotion;
        // Streamed text is flushed to the UI at most every 90 ms (each flush re-renders the Markdown).
        var flush = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(90) };
        flush.Tick += (_, _) =>
        {
            lock (buffer)
            {
                // Steps and reasoning always show as they happen; only the answer text honours reduced motion.
                while (pending.Steps.Count < steps.Count)
                {
                    pending.AddStep(steps[pending.Steps.Count]);
                }
                if (pending.Stage != stage)
                {
                    pending.StageFiles = stageFiles;
                    pending.Stage = stage;
                    pending.IsSlow = false;
                }
                // A calm note when nothing new has been reported for a while (local models can be slow to start).
                if (!pending.IsSlow && sinceStage.Elapsed > TimeSpan.FromSeconds(25) && buffer.Length == 0)
                {
                    pending.IsSlow = true;
                }
                if (reasoning.Length != pending.Thinking.Length)
                {
                    pending.Thinking = reasoning.ToString();
                }
                if (!reduceMotion && buffer.Length != pending.Text.Length)
                {
                    pending.Text = buffer.ToString();
                }
                var step = steps.Count > 0 ? steps[^1] : "Reading the question…";
                if (step.StartsWith("Writing", StringComparison.Ordinal) && buffer.Length > 0)
                {
                    step = $"Writing the answer… {TextUtil.Plural(buffer.Length / 4, "token")}";
                }
                BusyText = $"{started.Elapsed.TotalSeconds:0} s · {TextUtil.Truncate(step, 90)}";
            }
            FollowRequested?.Invoke(this, EventArgs.Empty);
        };
        flush.Start();
        try
        {
            var (conversation, answer) = await Task.Run(() => call(
                delta => { lock (buffer) { buffer.Append(delta); } },
                update =>
                {
                    lock (buffer)
                    {
                        if (update.Kind == Engine.Assistant.ThinkingKind.Step)
                        {
                            steps.Add(update.Text);
                            if (update.Stage is { } reported)
                            {
                                stage = reported;
                                stageFiles = update.Files ?? stageFiles;
                                sinceStage.Restart();
                            }
                        }
                        else
                        {
                            reasoning.Append(update.Text);
                        }
                    }
                },
                _cts.Token));
            _conversationId = conversation.Id;
            // Ready: a moment for the explorer to hand over before the finished answer replaces it.
            pending.Stage = ProgressStage.Ready;
            if (!reduceMotion)
            {
                await Task.Delay(450);
            }
            var index = Messages.IndexOf(pending);
            if (index >= 0)
            {
                Messages[index] = new ChatMessageViewModel(answer, this);
            }
            // Replace the optimistic user message with the stored one (so Edit works on it).
            var stored = conversation.Messages.LastOrDefault(m => m.Role == "user");
            var userIndex = index - 1;
            if (stored is not null && userIndex >= 0 && Messages[userIndex].IsUser)
            {
                Messages[userIndex] = new ChatMessageViewModel(stored, this);
            }
            if (IsTalk && SpeakReplies && index >= 0)
            {
                ReadAloud(Messages[index]);
            }
        }
        catch (OperationCanceledException)
        {
            pending.Text = buffer.Length > 0 ? buffer + "\n\n_Stopped._" : "_Stopped._";
            pending.IsStreaming = false;
        }
        catch (Exception ex)
        {
            pending.Text = "**The question could not be answered.** " + ex.Message + (question is null ? "" : "\n\nChoose **Try again** to ask it once more.");
            pending.IsStreaming = false;
            pending.ResendQuestion = question;
            Logging.Error(ex, "Assistant");
        }
        finally
        {
            flush.Stop();
            IsBusy = false;
            Notify(nameof(TokenSummary), nameof(HasMessages));
            FollowRequested?.Invoke(this, EventArgs.Empty);
        }
    }
}

/// <summary>An entry of the composer's skill picker.</summary>
/// <param name="Id">"auto", "none" or a skill id.</param>
public sealed record SkillChoice(string Id, string Label, string Description)
{
    public static readonly SkillChoice Auto = new("auto", "Auto skill", "The question picks a skill when one fits (Settings → Skills).");
    public static readonly SkillChoice None = new("none", "No skill", "Answer without a skill.");

    public override string ToString() => Label;
}
