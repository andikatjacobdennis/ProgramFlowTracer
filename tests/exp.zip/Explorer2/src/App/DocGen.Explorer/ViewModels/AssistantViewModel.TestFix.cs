using System.Collections.ObjectModel;
using System.Windows.Input;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.TestFix;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>
/// Ask's Test Fix mode: the composer collects what fails (its text and attached tests, logs and stack traces), which
/// tests to run, the command and the configuration; Send asks for confirmation and then runs the Test Fix skill, whose
/// stages and report show as an answer. Offered only when the skill is turned on (Settings → Skills).
/// </summary>
public sealed partial class AssistantViewModel
{
    private bool _canTestFix;
    private bool _isTestFixMode;
    private string _testFixSelection = "";
    private string _testFixCommand = "";
    private string _testFixConfiguration = "";
    private bool _testFixApply = true;
    private bool _testFixRun = true;
    private string _testFixProject = "";

    /// <summary>The Test Fix skill is on (and this is Ask, not Talk).</summary>
    public bool CanTestFix
    {
        get => _canTestFix;
        private set
        {
            if (Set(ref _canTestFix, value))
            {
                if (!value)
                {
                    IsTestFixMode = false;
                }
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    /// <summary>The composer sends to Test Fix instead of asking a question.</summary>
    public bool IsTestFixMode
    {
        get => _isTestFixMode;
        set
        {
            if (Set(ref _isTestFixMode, value && CanTestFix))
            {
                Notify(nameof(InputHint));
                if (_isTestFixMode)
                {
                    _ = PrepareTestFixAsync();
                }
            }
        }
    }

    public ICommand ToggleTestFixCommand => _toggleTestFix ??= new RelayCommand(() => IsTestFixMode = !IsTestFixMode, () => CanTestFix && !IsBusy);
    private ICommand? _toggleTestFix;

    /// <summary>Which tests: a runner filter or test names (empty: the failing tests named in the logs, else all).</summary>
    public string TestFixSelection { get => _testFixSelection; set => Set(ref _testFixSelection, value); }

    /// <summary>The command that runs the tests (empty: the repository's own runner).</summary>
    public string TestFixCommand { get => _testFixCommand; set => Set(ref _testFixCommand, value); }

    /// <summary>The build configuration or environment (Debug, Release, QADebug…).</summary>
    public string TestFixConfiguration { get => _testFixConfiguration; set => Set(ref _testFixConfiguration, value); }

    /// <summary>The configurations the repository defines.</summary>
    public ObservableCollection<string> TestFixConfigurations { get; } = [];

    /// <summary>Write the fix to the files (else it is only proposed).</summary>
    public bool TestFixApply { get => _testFixApply; set => Set(ref _testFixApply, value); }

    /// <summary>Run the tests (else nothing runs and the result is unverified).</summary>
    public bool TestFixRun { get => _testFixRun; set => Set(ref _testFixRun, value); }

    /// <summary>What Test Fix found the repository runs its tests with.</summary>
    public string TestFixProject { get => _testFixProject; private set => Set(ref _testFixProject, value); }

    /// <summary>The defaults from Settings → Skills and what the repository runs its tests with.</summary>
    private async Task PrepareTestFixAsync()
    {
        var settings = await Workspace.Main.Engine.Skills.GetSettingsAsync();
        TestFixApply = settings.TestFixApplyChanges;
        TestFixRun = settings.TestFixRunCommands;
        var profile = await Workspace.Main.Engine.TestFix.InspectAsync(Workspace.Record.Id);
        TestFixConfigurations.Clear();
        foreach (var configuration in profile?.Configurations ?? [])
        {
            TestFixConfigurations.Add(configuration);
        }
        TestFixProject = profile is null ? "The repository's folder could not be read."
            : profile.Runner.Length == 0 ? "No test runner was recognised — give the test command."
            : $"Runs {profile.Runner}" + (profile.Target is { } target ? $" on {target}" : "") + (profile.Frameworks.Count > 0 ? $" ({string.Join(", ", profile.Frameworks)})" : "") + ".";
    }

    private async Task SendTestFixAsync()
    {
        var description = Input.Trim();
        var attachments = PendingAttachments.Select(a => a.Attachment).ToList();
        if (IsBusy)
        {
            return;
        }
        var settings = await Workspace.Main.Engine.Skills.GetSettingsAsync();
        var request = new TestFixRequest
        {
            Description = description, Attachments = attachments,
            TestSelection = TestFixSelection.Trim() is { Length: > 0 } selection ? selection : null,
            TestCommand = TestFixCommand.Trim() is { Length: > 0 } command ? command : null,
            Configuration = TestFixConfiguration.Trim() is { Length: > 0 } configuration ? configuration : null,
            ApplyChanges = TestFixApply, RunCommands = TestFixRun,
            MaxIterations = settings.TestFixMaxIterations, TimeoutSeconds = settings.TestFixTimeoutSeconds,
        };
        if (request.TestCommand is { } own && TestCommandRunner.Refusal(own) is { } refusal)
        {
            Ui.Notify(refusal);
            return;
        }
        // Running commands and changing files is the person's decision, each time.
        var what = request.RunCommands
            ? $"Test Fix will run {(request.TestCommand is { } c ? $"“{c}”" : "the repository's tests")}{(request.Configuration is { } cfg ? $" ({cfg})" : "")} in {Workspace.Record.Path}"
            : "Test Fix will not run anything";
        var change = request.ApplyChanges ? " and change files there to fix the failure." : ", and only propose a fix — no file will be changed.";
        var ok = await Workspace.Main.ConfirmAsync("Run Test Fix?", what + change,
            $"Commands run as you, on this PC, for up to {request.TimeoutSeconds / 60.0:0.#} minutes each; at most {request.MaxIterations} fix attempt(s). Your other edits are kept, and every change can be undone from the report. Test Fix never commits, pushes, publishes or deploys.",
            "Run Test Fix", danger: false);
        if (!ok)
        {
            return;
        }
        Input = "";
        PendingAttachments.Clear();
        Notify(nameof(HasPendingAttachments));
        IsTestFixMode = false;
        var engine = Workspace.Main.Engine.Assistant;
        var repositoryId = Workspace.Record.Id;
        Messages.Add(new ChatMessageViewModel(new ChatMessage
        {
            Role = "user", Text = Engine.Assistant.AssistantService.UserText(request), Attachments = attachments.Count > 0 ? attachments : null, TestFix = request,
        }, this));
        var pending = new ChatMessageViewModel(new ChatMessage { Role = "assistant", Text = "" }, this) { IsStreaming = true };
        Messages.Add(pending);
        Notify(nameof(HasGreeting), nameof(HasMessages));
        ScrollRequested?.Invoke(this, EventArgs.Empty);
        await RunAsync(pending, async (_, onThinking, ct) => await engine.TestFixAsync(repositoryId, _conversationId, request, onThinking, ct));
    }

    /// <summary>Undoes a Test Fix run's changes, after asking.</summary>
    public async Task UndoTestFixAsync(ChatMessageViewModel message)
    {
        if (message.Message.TestFixRunId is not { } runId || _conversationId is null || IsBusy)
        {
            return;
        }
        if (!await Workspace.Main.ConfirmAsync("Undo Test Fix's changes?", "The files this run changed go back to how they were before it.",
                "A file you changed after the run is left as it is.", "Undo changes"))
        {
            return;
        }
        try
        {
            var (restored, kept, report) = await Workspace.Main.Engine.Assistant.UndoTestFixAsync(Workspace.Record.Id, _conversationId, runId);
            message.Text = report;
            Ui.Notify(restored.Count == 0 ? "Nothing to undo: no file is as Test Fix left it." : $"Restored {restored.Count} file(s)" + (kept.Count > 0 ? $"; {kept.Count} changed since were left." : "."));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or Engine.Repositories.ExplorerValidationException)
        {
            Ui.Notify("The changes could not be undone: " + ex.Message);
        }
    }

    /// <summary>Runs the app did not live to finish are reported as interrupted, with what they changed.</summary>
    private async Task RecoverTestFixAsync()
    {
        try
        {
            if (await Workspace.Main.Engine.Assistant.RecoverTestFixAsync(Workspace.Record.Id) is > 0 and var count)
            {
                Ui.Notify(count == 1 ? "A Test Fix run did not finish; its report shows what it changed." : $"{count} Test Fix runs did not finish; their reports show what they changed.");
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            Logging.Error(ex, "Test Fix recovery");
        }
    }
}
