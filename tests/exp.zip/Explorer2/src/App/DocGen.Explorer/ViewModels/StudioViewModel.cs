using System.Collections.ObjectModel;
using System.Text;
using System.Windows.Input;
using System.Windows.Media;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Studio;
using DocGen.Explorer.Infrastructure;
using DocGen.Core.Models;

namespace DocGen.Explorer.ViewModels;

public sealed class SpeakerOption(Persona persona, StudioViewModel owner, int colorIndex) : ObservableObject
{
    private bool _isChosen;

    public Persona Persona { get; } = persona;
    public string Name => Persona.Name;
    public string Tagline => Persona.Tagline;
    public string Initial => Persona.Name.Length > 0 ? Persona.Name[..1].ToUpperInvariant() : "?";
    public Brush Color { get; } = PersonaColors.For(colorIndex);
    public string AvatarId => Persona.Avatar;

    public bool IsChosen
    {
        get => _isChosen;
        set
        {
            if (Set(ref _isChosen, value))
            {
                owner.OnSpeakersChanged();
            }
        }
    }

    public ICommand EditCommand => new AsyncCommand(() => owner.EditPersonaAsync(this));
    public ICommand RemoveCommand => new AsyncCommand(() => owner.RemovePersonaAsync(this));
}

/// <summary>The "Add persona" tile after the speakers.</summary>
public sealed class AddPersonaTile(StudioViewModel owner)
{
    public ICommand AddCommand => new AsyncCommand(owner.AddPersonaAsync);
}

public static class PersonaColors
{
    private static readonly string[] Palette = ["#646B77", "#36403E", "#706167", "#555045", "#7E7B88", "#525C60", "#706661"];

    public static Brush For(int index)
    {
        var brush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(Palette[Math.Abs(index) % Palette.Length]));
        brush.Freeze();
        return brush;
    }
}

public sealed class TranscriptLineViewModel(TranscriptLine line, int index, Brush color, StudioViewModel owner) : ObservableObject
{
    private bool _isPlaying;

    /// <summary>The speaker's picture (their persona's avatar).</summary>
    public string? AvatarId { get; init; }

    /// <summary>How they feel saying it: tagged by the model, or read from the words (older conversations).</summary>
    public string Emotion { get; } = line.Emotion ?? Emotions.Read(line.Text);

    public string EmotionLabel => char.ToUpperInvariant(Emotion[0]) + Emotion[1..];

    public TranscriptLine Line { get; } = line;
    public int Index { get; } = index;
    public string Speaker => Line.Speaker;
    public string Initial => Line.Speaker.Length > 0 ? Line.Speaker[..1].ToUpperInvariant() : "?";
    public string Text => Line.Text;
    public Brush Color { get; } = color;
    public bool HasSource => Line.Path is not null;
    public string SourceText => Line.Path is null ? "" : $"{Path.GetFileName(Line.Path)}:{Line.Line}";
    public ICommand OpenSourceCommand => new RelayCommand(() => owner.Workspace.OpenLink($"repo:{Line.Path}#L{Line.Line}"));
    public ICommand PlayFromHereCommand => new AsyncCommand(() => owner.PlayAsync(Index));

    public bool IsPlaying
    {
        get => _isPlaying;
        set => Set(ref _isPlaying, value);
    }
}

/// <summary>
/// A speaker on the Studio stage: their face, how they feel now, whether they are talking, and — while they talk — the
/// few words of their line being said now, shown in a speech bubble over them.
/// </summary>
public sealed class StageSpeaker(string personaId, string name, string? avatarId, double rate = 1) : ObservableObject
{
    private string _emotion = Emotions.Neutral;
    private bool _isTalking;
    private string? _bubble;

    /// <summary>How fast this speaker talks (1 = normal), to keep the bubble in step with the voice.</summary>
    public double Rate { get; } = rate;

    /// <summary>The words being said now (null when not talking).</summary>
    public string? Bubble
    {
        get => _bubble;
        set
        {
            if (Set(ref _bubble, value))
            {
                OnPropertyChanged(nameof(HasBubble));
            }
        }
    }

    public bool HasBubble => !string.IsNullOrEmpty(Bubble);

    public string PersonaId { get; } = personaId;
    public string Name { get; } = name;
    public string? AvatarId { get; } = avatarId;

    public string Emotion
    {
        get => _emotion;
        set
        {
            if (Set(ref _emotion, value))
            {
                OnPropertyChanged(nameof(EmotionLabel));
            }
        }
    }

    public string EmotionLabel => char.ToUpperInvariant(Emotion[0]) + Emotion[1..];

    public bool IsTalking
    {
        get => _isTalking;
        set => Set(ref _isTalking, value);
    }
}

/// <summary>Studio: compose a spoken conversation about the repository, then read, play or save it.</summary>
public sealed class StudioViewModel : ObservableObject, IActivatable
{
    private string _mode = "compose";
    private string _topic = "";
    private string _style = "Technical discussion";
    private int _length = 10;
    private string? _title;
    private bool _isComposing;
    private string? _composeStatus;
    private StudioConversation? _conversation;
    private bool _isPlaying;
    private List<Persona> _personas = [];

    public StudioViewModel(WorkspaceViewModel workspace)
    {
        Workspace = workspace;
        ComposeCommand = new AsyncCommand(ComposeAsync, () => !IsComposing && CannotComposeReason is null);
        RefineCommand = new AsyncCommand(RefineAsync, () => !IsComposing && Topic.Trim().Length > 0);
        ManagePersonasCommand = new RelayCommand(() => workspace.Main.Navigate(Section.Personas));
        AddStarterPersonasCommand = new AsyncCommand(async () =>
        {
            var added = await workspace.Main.Engine.Studio.AddStarterPersonasAsync();
            Ui.Notify($"{added} personas added.");
            await LoadPersonasAsync();
        });
        BackToComposeCommand = new RelayCommand(() =>
        {
            StopPlayback();
            Mode = "compose";
        });
        OpenConversationCommand = new RelayCommand(p =>
        {
            if (p is StudioConversation conversation)
            {
                Show(conversation);
            }
        });
        DeleteConversationCommand = new AsyncCommand(async p =>
        {
            if (p is StudioConversation conversation && await workspace.Main.ConfirmAsync($"Delete \"{conversation.Title}\"?", "This cannot be undone.", null, "Delete"))
            {
                await workspace.Main.Engine.Studio.DeleteConversationAsync(workspace.Record.Id, conversation.Id);
                await LoadConversationsAsync();
                if (_conversation?.Id == conversation.Id)
                {
                    Mode = "compose";
                }
            }
        });
        PlayCommand = new AsyncCommand(() => PlayAsync(0), () => !IsPlaying && Lines.Count > 0);
        StopCommand = new RelayCommand(StopPlayback, () => IsPlaying);
        SaveAudioCommand = new AsyncCommand(SaveAudioAsync, () => Lines.Count > 0 && !IsPlaying);
        SaveTranscriptCommand = new AsyncCommand(SaveTranscriptAsync, () => Lines.Count > 0);
        CopyTranscriptCommand = new RelayCommand(() => { if (Ui.Copy(TranscriptMarkdown())) { Ui.Notify("Transcript copied."); } });
        ClearSelectionCommand = new RelayCommand(() => workspace.Tree.ClearSelection());
        workspace.Main.Speech.LineStarted += (_, index) =>
        {
            if (!IsPlaying)
            {
                return;
            }
            foreach (var line in Lines)
            {
                line.IsPlaying = line.Index == index;
            }
            PlayingLine = Lines.FirstOrDefault(l => l.Index == index);
            if (PlayingLine is { } playing)
            {
                OnStage(playing);
            }
        };
        workspace.Main.Speech.PlaybackEnded += (_, _) => StopPlaybackUi();
        workspace.Tree.ScopeChanged += (_, _) => Notify(nameof(ScopeDescription), nameof(HasScope));
    }

    public WorkspaceViewModel Workspace { get; }

    public ICommand ComposeCommand { get; }
    public ICommand RefineCommand { get; }
    public ICommand ManagePersonasCommand { get; }
    public ICommand AddStarterPersonasCommand { get; }
    public ICommand BackToComposeCommand { get; }
    public ICommand OpenConversationCommand { get; }
    public ICommand DeleteConversationCommand { get; }
    public ICommand PlayCommand { get; }
    public ICommand StopCommand { get; }
    public ICommand SaveAudioCommand { get; }
    public ICommand SaveTranscriptCommand { get; }
    public ICommand CopyTranscriptCommand { get; }
    public ICommand ClearSelectionCommand { get; }

    public ObservableCollection<SpeakerOption> Speakers { get; } = [];
    public ObservableCollection<StudioConversation> Conversations { get; } = [];
    public ObservableCollection<TranscriptLineViewModel> Lines { get; } = [];

    public IReadOnlyList<string> Styles => ConversationStyles.All;
    public IReadOnlyList<int> Lengths { get; } = [3, 5, 10, 15, 20, 30];

    /// <summary>compose | conversation</summary>
    public string Mode
    {
        get => _mode;
        set => Set(ref _mode, value);
    }

    public string Topic
    {
        get => _topic;
        set
        {
            if (Set(ref _topic, value))
            {
                OnPropertyChanged(nameof(CannotComposeReason));
            }
        }
    }

    public string Style
    {
        get => _style;
        set => Set(ref _style, value);
    }

    public int Length
    {
        get => _length;
        set => Set(ref _length, value);
    }

    public string? Title
    {
        get => _title;
        set => Set(ref _title, value);
    }

    public bool IsComposing
    {
        get => _isComposing;
        private set => Set(ref _isComposing, value);
    }

    public string? ComposeStatus
    {
        get => _composeStatus;
        private set => Set(ref _composeStatus, value);
    }

    /// <summary>The speaker chips followed by the "Add persona" tile.</summary>
    public ObservableCollection<object> SpeakerTiles { get; } = [];

    public bool HasPersonas => _personas.Count > 0;
    public bool NoPersonas => _personas.Count == 0;
    public string ScopeDescription => Workspace.Tree.ScopeDescription;
    public bool HasScope => Workspace.Tree.HasScope;

    public string? CannotComposeReason
    {
        get
        {
            if (!Workspace.IsIndexed)
            {
                return "Index the repository first.";
            }
            var request = Request();
            return StudioService.CannotCompose(request, _personas);
        }
    }

    public StudioConversation? Conversation
    {
        get => _conversation;
        private set => Set(ref _conversation, value);
    }

    public bool IsPlaying
    {
        get => _isPlaying;
        private set
        {
            if (Set(ref _isPlaying, value))
            {
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    private TranscriptLineViewModel? _playingLine;

    public TranscriptLineViewModel? PlayingLine
    {
        get => _playingLine;
        private set => Set(ref _playingLine, value);
    }

    /// <summary>Everyone in the conversation, as faces: the speaker talks with the line's emotion, the others react.</summary>
    public ObservableCollection<StageSpeaker> Stage { get; } = [];

    /// <summary>Shows a line as if it were being spoken (for the capture's screenshots).</summary>
    internal void PreviewLine(int index)
    {
        foreach (var line in Lines)
        {
            line.IsPlaying = line.Index == index;
        }
        if (Lines.FirstOrDefault(l => l.Index == index) is { } playing)
        {
            OnStage(playing);
        }
    }

    /// <summary>The speaker now says the line: their face follows its emotion, and the listeners react to it.</summary>
    private void OnStage(TranscriptLineViewModel line)
    {
        // How listeners take what is said.
        var reaction = line.Emotion switch
        {
            Emotions.Concerned or Emotions.Sad => Emotions.Concerned,
            Emotions.Amused => Emotions.Happy,
            Emotions.Excited or Emotions.Happy => Emotions.Happy,
            Emotions.Surprised => Emotions.Curious,
            Emotions.Frustrated => Emotions.Concerned,
            Emotions.Curious => Emotions.Thinking,
            _ => Emotions.Neutral,
        };
        foreach (var speaker in Stage)
        {
            var talking = speaker.PersonaId == line.Line.PersonaId;
            speaker.IsTalking = talking;
            speaker.Emotion = talking ? line.Emotion : reaction;
            speaker.Bubble = null; // one speaker at a time
        }
        if (Stage.FirstOrDefault(s => s.PersonaId == line.Line.PersonaId) is { } now)
        {
            ShowBubbles(now, line.Text);
        }
    }

    private readonly System.Windows.Threading.DispatcherTimer _bubbleTimer = new();
    private Queue<string> _phrases = new();
    private StageSpeaker? _bubbleSpeaker;

    /// <summary>
    /// The line in the speaker's bubble a few words at a time, in step with how long they take to say (the voices give
    /// no word timings, so the time is worked out from the words and the speaker's rate).
    /// </summary>
    private void ShowBubbles(StageSpeaker speaker, string text)
    {
        _bubbleTimer.Stop();
        _bubbleSpeaker = speaker;
        _phrases = new Queue<string>(Phrases(text));
        NextBubble();
    }

    private void NextBubble()
    {
        _bubbleTimer.Stop();
        if (_bubbleSpeaker is not { } speaker || _phrases.Count == 0)
        {
            return;
        }
        var phrase = _phrases.Dequeue();
        speaker.Bubble = phrase;
        var words = phrase.Split(' ', StringSplitOptions.RemoveEmptyEntries).Length;
        // About two and a half words a second at normal speed, a little longer after a full stop.
        var seconds = words / (2.5 * Math.Max(0.5, speaker.Rate)) + (phrase.EndsWith('.') || phrase.EndsWith('?') || phrase.EndsWith('!') ? 0.35 : 0.1);
        _bubbleTimer.Interval = TimeSpan.FromSeconds(Math.Max(0.9, seconds));
        _bubbleTimer.Tick -= OnBubbleTick;
        _bubbleTimer.Tick += OnBubbleTick;
        if (_phrases.Count > 0 && IsPlaying)
        {
            _bubbleTimer.Start(); // a line chosen without playing shows its first words only
        }
    }

    private void OnBubbleTick(object? sender, EventArgs e) => NextBubble();

    /// <summary>A line cut into short phrases for the bubble: at punctuation, and at most about seven words each.</summary>
    public static List<string> Phrases(string text)
    {
        var phrases = new List<string>();
        var clauses = System.Text.RegularExpressions.Regex.Split(text.Trim(), @"(?<=[.!?;:,])\s+");
        foreach (var clause in clauses.Where(c => c.Length > 0))
        {
            var words = clause.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            var size = words.Length <= 8 ? words.Length : (int)Math.Ceiling(words.Length / Math.Ceiling(words.Length / 7.0));
            for (var i = 0; i < words.Length; i += size)
            {
                phrases.Add(string.Join(' ', words.Skip(i).Take(size)));
            }
        }
        // A phrase of one or two words joins the next one, so the bubble does not flicker.
        for (var i = phrases.Count - 2; i >= 0; i--)
        {
            if (phrases[i].Split(' ').Length <= 2 && phrases[i + 1].Split(' ').Length <= 6)
            {
                phrases[i] = phrases[i] + " " + phrases[i + 1];
                phrases.RemoveAt(i + 1);
            }
        }
        return phrases;
    }

    public string ConversationMeta => Conversation is null ? "" :
        $"{Conversation.Style} · {Conversation.Lines.Count} turns · about {Math.Max(1, Conversation.WordCount / StudioService.WordsPerMinute)} min · {Conversation.CreatedAt.ToLocalTime():d MMM, HH:mm}";

    public async Task ActivateAsync()
    {
        await LoadPersonasAsync();
        await LoadConversationsAsync();
    }

    public void OnIndexChanged() => OnPropertyChanged(nameof(CannotComposeReason));

    private async Task LoadPersonasAsync()
    {
        var chosen = Speakers.Where(s => s.IsChosen).Select(s => s.Persona.Id).ToHashSet();
        _personas = await Workspace.Main.Engine.Studio.ListPersonasAsync();
        Speakers.Clear();
        var i = 0;
        foreach (var persona in _personas)
        {
            var option = new SpeakerOption(persona, this, i++);
            Speakers.Add(option);
            if (chosen.Contains(persona.Id) || chosen.Count == 0 && i <= 2)
            {
                option.IsChosen = true;
            }
        }
        SpeakerTiles.Clear();
        foreach (var speaker in Speakers)
        {
            SpeakerTiles.Add(speaker);
        }
        SpeakerTiles.Add(new AddPersonaTile(this));
        Notify(nameof(HasPersonas), nameof(NoPersonas), nameof(CannotComposeReason));
    }

    /// <summary>Writes a new persona in the editor window; it joins the speakers when there is room.</summary>
    public async Task AddPersonaAsync()
    {
        var saved = Views.PersonaEditorWindow.Edit(Workspace.Main, null);
        if (saved is null)
        {
            return;
        }
        await LoadPersonasAsync();
        if (Speakers.Count(s => s.IsChosen) < StudioRequest.MaxSpeakers && Speakers.FirstOrDefault(s => s.Persona.Id == saved.Id) is { } added)
        {
            added.IsChosen = true;
        }
        Ui.Notify($"{saved.Name} added to the personas.");
    }

    public async Task EditPersonaAsync(SpeakerOption speaker)
    {
        if (Views.PersonaEditorWindow.Edit(Workspace.Main, speaker.Persona) is not null)
        {
            await LoadPersonasAsync();
        }
    }

    /// <summary>Deletes a persona (after asking): it leaves every conversation's speaker list, not only this one.</summary>
    public async Task RemovePersonaAsync(SpeakerOption speaker)
    {
        if (!await Workspace.Main.ConfirmAsync($"Remove {speaker.Name}?",
                $"{speaker.Name} is deleted from your personas, so they can no longer speak in any conversation. Conversations already made keep their transcript.",
                null, "Remove"))
        {
            return;
        }
        await Workspace.Main.Engine.Studio.DeletePersonaAsync(speaker.Persona.Id);
        await LoadPersonasAsync();
        Ui.Notify($"{speaker.Name} removed.");
    }

    private async Task LoadConversationsAsync()
    {
        Conversations.Clear();
        foreach (var conversation in await Workspace.Main.Engine.Studio.ListConversationsAsync(Workspace.Record.Id))
        {
            Conversations.Add(conversation);
        }
    }

    public void OnSpeakersChanged()
    {
        OnPropertyChanged(nameof(CannotComposeReason));
        CommandManager.InvalidateRequerySuggested();
    }

    private StudioRequest Request() => new()
    {
        Topic = Topic,
        PersonaIds = Speakers.Where(s => s.IsChosen).Select(s => s.Persona.Id).ToList(),
        Style = Style,
        LengthMinutes = Length,
        Title = string.IsNullOrWhiteSpace(Title) ? null : Title,
        Scope = Workspace.Tree.Scope.ToList(),
    };

    private async Task ComposeAsync()
    {
        IsComposing = true;
        ComposeStatus = "Starting…";
        try
        {
            var progress = new Progress<string>(text => ComposeStatus = text);
            var request = Request();
            var conversation = await Task.Run(() => Workspace.Main.Engine.Studio.ComposeAsync(Workspace.Record.Id, request, progress));
            await LoadConversationsAsync();
            Show(conversation);
            ComposeStatus = null;
        }
        catch (Engine.Repositories.ExplorerValidationException ex)
        {
            ComposeStatus = ex.Message;
        }
        finally
        {
            IsComposing = false;
        }
    }

    private async Task RefineAsync()
    {
        ComposeStatus = "Refining…";
        try
        {
            Topic = await Workspace.Main.Engine.Studio.RefineTopicAsync(Workspace.Record.Id, Topic);
            ComposeStatus = null;
        }
        catch (Engine.Repositories.ExplorerValidationException ex)
        {
            ComposeStatus = ex.Message;
        }
    }

    private void Show(StudioConversation conversation)
    {
        StopPlayback();
        Conversation = conversation;
        Lines.Clear();
        var colors = conversation.Lines.Select(l => l.PersonaId).Distinct().Select((id, i) => (id, i)).ToDictionary(x => x.id, x => x.i);
        var personas = _personas.ToDictionary(p => p.Id);
        for (var i = 0; i < conversation.Lines.Count; i++)
        {
            var line = conversation.Lines[i];
            Lines.Add(new TranscriptLineViewModel(line, i, PersonaColors.For(colors.GetValueOrDefault(line.PersonaId)), this)
            {
                AvatarId = personas.GetValueOrDefault(line.PersonaId)?.Avatar,
            });
        }
        Stage.Clear();
        foreach (var first in conversation.Lines.GroupBy(l => l.PersonaId).Select(g => g.First()))
        {
            var persona = personas.GetValueOrDefault(first.PersonaId);
            Stage.Add(new StageSpeaker(first.PersonaId, first.Speaker, persona?.Avatar, persona?.Rate ?? 1));
        }
        OnPropertyChanged(nameof(ConversationMeta));
        Mode = "conversation";
    }

    private static readonly string[] FemaleVoices = ["en-IN-NeerjaNeural", "en-GB-SoniaNeural", "en-US-AvaNeural", "en-GB-LibbyNeural"];
    private static readonly string[] MaleVoices = ["en-IN-PrabhatNeural", "en-GB-RyanNeural", "en-US-AndrewNeural", "en-GB-ThomasNeural"];

    private List<(string Text, string? Voice, double Rate, double Pitch)> Voiced()
    {
        var personas = _personas.ToDictionary(p => p.Id);
        // Speakers without a voice of their own get distinct natural voices that fit their picture (a woman's voice for
        // a woman), in order of first appearance; Indian English first.
        var natural = Workspace.Main.Speech.NaturalVoices;
        var given = new Dictionary<string, string?>();
        var used = new Dictionary<string, int>();
        foreach (var id in Lines.Select(l => l.Line.PersonaId).Distinct())
        {
            var persona = personas.GetValueOrDefault(id);
            if (persona?.Voice is { Length: > 0 } own)
            {
                given[id] = own;
                continue;
            }
            var gender = Avatars.AvatarCatalog.Find(persona?.Avatar, persona?.Name).Gender;
            IReadOnlyList<string> pool = gender switch
            {
                "Female" => FemaleVoices,
                "Male" => MaleVoices,
                _ => Engine.Speech.EdgeTts.SpeakerRotation,
            };
            var key = gender ?? "";
            var n = used.GetValueOrDefault(key);
            used[key] = n + 1;
            given[id] = natural ? pool[n % pool.Count] : null;
        }
        return Lines.Select(l =>
        {
            var persona = personas.GetValueOrDefault(l.Line.PersonaId);
            return (l.Text, given.GetValueOrDefault(l.Line.PersonaId), persona?.Rate ?? 1, persona?.Pitch ?? 1);
        }).ToList();
    }

    public async Task PlayAsync(int startAt)
    {
        if (_personas.Count == 0)
        {
            await LoadPersonasAsync();
        }
        IsPlaying = true;
        await Workspace.Main.Speech.PlayAsync(Voiced(), startAt);
    }

    private void StopPlayback()
    {
        Workspace.Main.Speech.Stop();
        StopPlaybackUi();
    }

    private void StopPlaybackUi()
    {
        IsPlaying = false;
        PlayingLine = null;
        _bubbleTimer.Stop();
        _bubbleSpeaker = null;
        foreach (var speaker in Stage)
        {
            speaker.IsTalking = false;
            speaker.Emotion = Emotions.Neutral;
            speaker.Bubble = null;
        }
        foreach (var line in Lines)
        {
            line.IsPlaying = false;
        }
    }

    private async Task SaveAudioAsync()
    {
        var speech = Workspace.Main.Speech;
        // Natural voices save as MP3 (the service speaks MP3); the Windows voices as WAV.
        var dialog = new Microsoft.Win32.SaveFileDialog
        {
            FileName = SafeName(Conversation?.Title ?? "conversation") + (speech.SavesMp3 ? ".mp3" : ".wav"),
            Filter = speech.SavesMp3 ? "MP3 audio, natural voices (*.mp3)|*.mp3|WAV audio, Windows voices (*.wav)|*.wav" : "WAV audio (*.wav)|*.wav",
            AddExtension = true,
        };
        if (dialog.ShowDialog() != true)
        {
            return;
        }
        var lines = Voiced();
        Workspace.Main.ShowToast("Saving the audio…", false);
        try
        {
            if (dialog.FileName.EndsWith(".mp3", StringComparison.OrdinalIgnoreCase))
            {
                await speech.SaveMp3Async(dialog.FileName, lines);
            }
            else
            {
                await Task.Run(() => SpeechService.SaveWave(dialog.FileName, lines));
            }
            Workspace.Main.ShowToast("Saved " + Path.GetFileName(dialog.FileName), false);
        }
        catch (Exception ex) when (ex is InvalidOperationException or PlatformNotSupportedException or IOException or System.Runtime.InteropServices.COMException
                                       or System.Net.WebSockets.WebSocketException or OperationCanceledException)
        {
            Workspace.Main.ShowToast("The audio could not be saved: " + ex.Message, true);
        }
    }

    private string TranscriptMarkdown()
    {
        var sb = new StringBuilder();
        if (Conversation is not null)
        {
            sb.AppendLine($"# {Conversation.Title}").AppendLine();
            sb.AppendLine($"_{Conversation.Style}. {Conversation.Provenance}_").AppendLine();
        }
        foreach (var line in Lines)
        {
            sb.AppendLine($"**{line.Speaker}:** {line.Text}").AppendLine();
        }
        return sb.ToString();
    }

    private async Task SaveTranscriptAsync()
    {
        var dialog = new Microsoft.Win32.SaveFileDialog { FileName = SafeName(Conversation?.Title ?? "conversation") + ".md", Filter = "Markdown (*.md)|*.md", AddExtension = true };
        if (dialog.ShowDialog() == true)
        {
            await File.WriteAllTextAsync(dialog.FileName, TranscriptMarkdown());
            Ui.Notify("Saved " + Path.GetFileName(dialog.FileName));
        }
    }

    private static string SafeName(string name) => string.Concat(name.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '-' : c)).Trim();
}

public sealed class PersonaEditorViewModel : ObservableObject
{
    private string _name;
    private string _tagline;
    private string _profile;
    private string _style;
    private string _greeting;
    private string _voice;
    private double _rate;
    private double _pitch;
    private string _avatar;
    private string _previewEmotion = Emotions.Happy;
    private bool _previewTalking;

    public PersonaEditorViewModel(Persona persona)
    {
        Original = persona;
        _avatar = Avatars.AvatarCatalog.Find(persona.Avatar, persona.Name).Id;
        _name = persona.Name;
        _tagline = persona.Tagline;
        _profile = persona.Profile;
        _style = persona.SpeakingStyle;
        _greeting = persona.Greeting;
        _voice = persona.Voice;
        _rate = persona.Rate;
        _pitch = persona.Pitch;
    }

    public Persona Original { get; }
    public bool IsNew => Original.Version == 0 && string.IsNullOrEmpty(Original.Name);
    public string Heading => IsNew ? "New persona" : $"Edit {Original.Name}";
    public string Name { get => _name; set => Set(ref _name, value); }
    public string Tagline { get => _tagline; set => Set(ref _tagline, value); }
    public string Profile { get => _profile; set => Set(ref _profile, value); }
    public string SpeakingStyle { get => _style; set => Set(ref _style, value); }
    public string Greeting { get => _greeting; set => Set(ref _greeting, value); }
    public string Voice { get => _voice; set => Set(ref _voice, value); }

    /// <summary>The 100 pictures to choose from.</summary>
    public IReadOnlyList<Avatars.Avatar> AvatarChoices => Avatars.AvatarCatalog.All;

    public IReadOnlyList<string> EmotionChoices => Emotions.All;

    public Avatars.Avatar SelectedAvatar
    {
        get => Avatars.AvatarCatalog.Find(_avatar);
        set
        {
            if (value is not null && Set(ref _avatar, value.Id, nameof(Avatar)))
            {
                OnPropertyChanged(nameof(SelectedAvatar));
            }
        }
    }

    public string Avatar => _avatar;

    /// <summary>The preview's emotion (the editor shows how the picture expresses each).</summary>
    public string PreviewEmotion
    {
        get => _previewEmotion;
        set => Set(ref _previewEmotion, value);
    }

    public bool PreviewTalking
    {
        get => _previewTalking;
        set => Set(ref _previewTalking, value);
    }

    public ICommand SetPreviewEmotionCommand => new RelayCommand(p => { if (p is string emotion) { PreviewEmotion = emotion; } });

    public double Rate
    {
        get => _rate;
        set
        {
            if (Set(ref _rate, Math.Round(value, 2)))
            {
                OnPropertyChanged(nameof(RateText));
            }
        }
    }

    public double Pitch
    {
        get => _pitch;
        set
        {
            if (Set(ref _pitch, Math.Round(value, 2)))
            {
                OnPropertyChanged(nameof(PitchText));
            }
        }
    }

    public string RateText => $"{Rate:0.00}×";
    public string PitchText => $"{Pitch:0.00}";

    public Persona ToPersona()
    {
        Original.Name = Name;
        Original.Tagline = Tagline;
        Original.Profile = Profile;
        Original.SpeakingStyle = SpeakingStyle;
        Original.Greeting = Greeting;
        Original.Voice = Voice;
        Original.Rate = Rate;
        Original.Pitch = Pitch;
        Original.Avatar = _avatar;
        return Original;
    }
}

/// <summary>Studio's personas: the people who speak in generated conversations. They belong to no repository.</summary>
public sealed class PersonasViewModel : ObservableObject, IActivatable
{
    private readonly MainViewModel _main;
    private PersonaEditorViewModel? _editor;
    private string? _editorError;

    public PersonasViewModel(MainViewModel main)
    {
        _main = main;
        NewCommand = new RelayCommand(StartNew);
        EditCommand = new RelayCommand(p =>
        {
            if (p is Persona persona)
            {
                StartEdit(persona);
            }
        });
        SaveCommand = new AsyncCommand(SaveAsync, () => Editor is not null);
        CancelCommand = new RelayCommand(() =>
        {
            Editor = null;
            EditorClosed?.Invoke(null);
        });
        DeleteCommand = new AsyncCommand(async p =>
        {
            if (p is Persona persona && await main.ConfirmAsync($"Delete {persona.Name}?", "Conversations already made keep their transcript.", null, "Delete"))
            {
                await main.Engine.Studio.DeletePersonaAsync(persona.Id);
                await ActivateAsync();
            }
        });
        ImportCommand = new AsyncCommand(ImportAsync);
        ExportCommand = new AsyncCommand(ExportAsync, () => Personas.Count > 0);
        StarterCommand = new AsyncCommand(async () =>
        {
            var added = await main.Engine.Studio.AddStarterPersonasAsync();
            Ui.Notify(added == 0 ? "The starter personas are already here." : $"{added} personas added.");
            await ActivateAsync();
        });
        TestVoiceCommand = new RelayCommand(() =>
        {
            if (Editor is not null)
            {
                main.Speech.Speak(Editor.Greeting.Length > 0 ? Editor.Greeting : $"Hello, I'm {Editor.Name}. {Editor.Tagline}", Editor.Voice, Editor.Rate);
            }
        });
        BackToStudioCommand = new RelayCommand(() => main.Navigate(main.Workspace is null ? Section.Repositories : Section.Studio));
    }

    /// <summary>The editor closed: with the saved persona, or null when it was cancelled.</summary>
    public event Action<Persona?>? EditorClosed;

    /// <summary>Opens the editor on a new persona.</summary>
    public void StartNew()
    {
        Editor = new PersonaEditorViewModel(new Persona());
        EditorError = null;
    }

    /// <summary>Opens the editor on a copy of <paramref name="persona"/> (nothing changes until Save).</summary>
    public void StartEdit(Persona persona)
    {
        var copy = System.Text.Json.JsonSerializer.Deserialize<Persona>(System.Text.Json.JsonSerializer.Serialize(persona))!;
        Editor = new PersonaEditorViewModel(copy);
        EditorError = null;
    }

    public ObservableCollection<Persona> Personas { get; } = [];
    /// <summary>Empty (the default), Edge's natural voices, then the installed Windows voices.</summary>
    public IReadOnlyList<string> Voices { get; } = new[] { "" }.Concat(SpeechService.AllVoices()).ToList();

    public ICommand NewCommand { get; }
    public ICommand EditCommand { get; }
    public ICommand SaveCommand { get; }
    public ICommand CancelCommand { get; }
    public ICommand DeleteCommand { get; }
    public ICommand ImportCommand { get; }
    public ICommand ExportCommand { get; }
    public ICommand StarterCommand { get; }
    public ICommand TestVoiceCommand { get; }
    public ICommand BackToStudioCommand { get; }

    public bool IsEmpty => Personas.Count == 0;
    public bool HasWorkspace => _main.Workspace is not null;

    public PersonaEditorViewModel? Editor
    {
        get => _editor;
        private set
        {
            if (Set(ref _editor, value))
            {
                OnPropertyChanged(nameof(IsEditing));
            }
        }
    }

    public bool IsEditing => Editor is not null;

    public string? EditorError
    {
        get => _editorError;
        private set => Set(ref _editorError, value);
    }

    public async Task ActivateAsync()
    {
        Personas.Clear();
        foreach (var persona in await _main.Engine.Studio.ListPersonasAsync())
        {
            Personas.Add(persona);
        }
        Notify(nameof(IsEmpty), nameof(HasWorkspace));
    }

    private async Task SaveAsync()
    {
        if (Editor is null)
        {
            return;
        }
        try
        {
            var saved = await _main.Engine.Studio.SavePersonaAsync(Editor.ToPersona());
            Editor = null;
            await ActivateAsync();
            EditorClosed?.Invoke(saved);
        }
        catch (Engine.Repositories.ExplorerValidationException ex)
        {
            EditorError = ex.Message;
        }
    }

    private async Task ImportAsync()
    {
        var dialog = new Microsoft.Win32.OpenFileDialog { Filter = "Personas (*.json)|*.json|All files (*.*)|*.*", Title = "Import personas" };
        if (dialog.ShowDialog() != true)
        {
            return;
        }
        var added = await _main.Engine.Studio.ImportPersonasAsync(await File.ReadAllTextAsync(dialog.FileName));
        Ui.Notify(added == 0 ? "No new personas were found (names already in use are skipped)." : $"{added} personas imported.");
        await ActivateAsync();
    }

    private async Task ExportAsync()
    {
        var dialog = new Microsoft.Win32.SaveFileDialog { FileName = "personas.json", Filter = "Personas (*.json)|*.json", AddExtension = true };
        if (dialog.ShowDialog() == true)
        {
            await File.WriteAllTextAsync(dialog.FileName, await _main.Engine.Studio.ExportPersonasAsync());
            Ui.Notify("Saved " + Path.GetFileName(dialog.FileName));
        }
    }
}
