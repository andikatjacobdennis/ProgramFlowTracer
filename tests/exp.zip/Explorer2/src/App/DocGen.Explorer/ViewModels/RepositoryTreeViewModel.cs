using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

public enum TreeNodeKind
{
    Folder,
    File,
    Page,
}

public sealed partial class TreeNodeViewModel : ObservableObject
{
    private bool _isExpanded;
    private bool _isSelected;
    private bool? _isChecked = false;
    private bool _suppress;

    public TreeNodeViewModel(RepositoryTreeViewModel tree, TreeNodeViewModel? parent, string name, TreeNodeKind kind, string path, int depth)
    {
        Tree = tree;
        Parent = parent;
        Name = name;
        Kind = kind;
        Path = path;
        Depth = depth;
    }

    public RepositoryTreeViewModel Tree { get; }
    public TreeNodeViewModel? Parent { get; }
    public string Name { get; }
    public TreeNodeKind Kind { get; }

    /// <summary>Folder or file path (relative), or the page's tree path.</summary>
    public string Path { get; }

    public string? PageId { get; init; }
    public string? SourcePath { get; init; }
    public int Depth { get; }
    public GridLength Indent => new(Depth * 14);
    public ObservableCollection<TreeNodeViewModel> Children { get; } = [];
    public string Glyph => Kind switch
    {
        TreeNodeKind.Folder => IsExpanded ? Icons.FolderOpen : Icons.Folder,
        TreeNodeKind.Page => Icons.Document,
        _ => Path.EndsWith(".md", StringComparison.OrdinalIgnoreCase) ? Icons.Document : Icons.Code,
    };
    public string? Tooltip => Kind == TreeNodeKind.Folder ? Path : SourcePath ?? Path;
    public bool ShowCheckBox => Tree.SelectionMode;

    public bool IsExpanded
    {
        get => _isExpanded;
        set
        {
            if (Set(ref _isExpanded, value))
            {
                OnPropertyChanged(nameof(Glyph));
            }
        }
    }

    public bool IsSelected
    {
        get => _isSelected;
        set
        {
            if (Set(ref _isSelected, value) && value && !Tree.Syncing)
            {
                Tree.Activate(this);
            }
        }
    }

    public bool? IsChecked
    {
        get => _isChecked;
        set
        {
            if (_isChecked == value)
            {
                return;
            }
            _isChecked = value;
            OnPropertyChanged();
            if (_suppress)
            {
                return;
            }
            if (value is { } v)
            {
                foreach (var child in Children)
                {
                    child.SetCheckedDown(v);
                }
            }
            Parent?.Recompute();
            Tree.OnCheckedChanged();
        }
    }

    private void SetCheckedDown(bool value)
    {
        _suppress = true;
        IsChecked = value;
        _suppress = false;
        foreach (var child in Children)
        {
            child.SetCheckedDown(value);
        }
    }

    private void Recompute()
    {
        var states = Children.Select(c => c.IsChecked).Distinct().ToList();
        var state = states.Count == 1 ? states[0] : null;
        _suppress = true;
        IsChecked = state;
        _suppress = false;
        Parent?.Recompute();
    }

    public void NotifyCheckBox() => OnPropertyChanged(nameof(ShowCheckBox));

    public IEnumerable<TreeNodeViewModel> Descendants() => Children.SelectMany(c => c.Descendants().Prepend(c));
}

/// <summary>The left pane: documentation pages and indexed files, with an optional selection mode (tick boxes).</summary>
public sealed partial class RepositoryTreeViewModel : ObservableObject
{
    private readonly WorkspaceViewModel _workspace;
    private string _tab = "docs";
    private bool _selectionMode;
    private string _filter = "";
    private List<string> _scope = [];

    public RepositoryTreeViewModel(WorkspaceViewModel workspace)
    {
        _workspace = workspace;
        ToggleSelectionModeCommand = new RelayCommand(() => SelectionMode = !SelectionMode);
        ClearSelectionCommand = new RelayCommand(ClearSelection);
        SetTabCommand = new RelayCommand(p => Tab = p as string ?? "docs");
    }

    public ICommand ToggleSelectionModeCommand { get; }
    public ICommand ClearSelectionCommand { get; }
    public ICommand SetTabCommand { get; }

    public ObservableCollection<TreeNodeViewModel> DocsRoots { get; private set; } = [];
    public ObservableCollection<TreeNodeViewModel> FilesRoots { get; private set; } = [];
    public ObservableCollection<TreeNodeViewModel> FilterResults { get; } = [];

    internal bool Syncing { get; private set; }

    public int DocsCount { get; private set; }
    public int FilesCount { get; private set; }

    public string Tab
    {
        get => _tab;
        set
        {
            if (Set(ref _tab, value))
            {
                Notify(nameof(IsDocsTab), nameof(IsFilesTab), nameof(IsChangesTab), nameof(Roots));
                if (IsChangesTab)
                {
                    _ = RefreshChangesAsync();
                }
            }
        }
    }

    // Settable, so a tab chosen any way (a click, the keyboard, a screen reader selecting it) switches.
    public bool IsDocsTab
    {
        get => Tab == "docs";
        set
        {
            if (value)
            {
                Tab = "docs";
            }
        }
    }

    public bool IsFilesTab
    {
        get => Tab == "files";
        set
        {
            if (value)
            {
                Tab = "files";
            }
        }
    }

    public ObservableCollection<TreeNodeViewModel> Roots => Filter.Trim().Length > 0 ? FilterResults : IsDocsTab ? DocsRoots : FilesRoots;

    public bool SelectionMode
    {
        get => _selectionMode;
        set
        {
            if (Set(ref _selectionMode, value))
            {
                foreach (var node in AllNodes())
                {
                    node.NotifyCheckBox();
                }
                OnPropertyChanged(nameof(SelectionModeTooltip));
            }
        }
    }

    public string SelectionModeTooltip => SelectionMode
        ? "Selection mode is on: questions, quizzes and conversations use only what is ticked"
        : "Limit the assistant to part of the repository";

    public string Filter
    {
        get => _filter;
        set
        {
            if (Set(ref _filter, value))
            {
                ApplyFilter();
                OnPropertyChanged(nameof(Roots));
                if (_changesLoaded)
                {
                    FillChanges();
                }
            }
        }
    }

    public IReadOnlyList<string> Scope => _scope;

    /// <summary>Something is ticked (Clear selection has something to clear).</summary>
    public bool HasScope => _scope.Count > 0;

    public string ScopeDescription => _scope.Count == 0 ? "Whole repository" : _scope.Count <= 3 ? string.Join(", ", _scope) : $"{_scope.Count} selected items";

    public event EventHandler? ScopeChanged;

    /// <summary>Learning and Studio open with the tick boxes showing; elsewhere they stay as the user left them.</summary>
    public void SetSelectionModeHint(bool on)
    {
        if (on && !SelectionMode)
        {
            SelectionMode = true;
        }
    }

    /// <summary>Builds both trees on a background thread (thousands of files), then shows them.</summary>
    public async Task RebuildAsync()
    {
        var index = _workspace.Index;
        var (docs, files) = index is null ? ([], []) : await Task.Run(() => Build(index));
        DocsRoots = docs;
        FilesRoots = files;
        DocsCount = index is null ? 0 : index.Pages.Any(p => !p.Generated) ? index.Pages.Count(p => !p.Generated) : index.Pages.Count;
        FilesCount = index?.Files.Count ?? 0;
        _scope = [];
        FilterResults.Clear();
        Notify(nameof(DocsCount), nameof(FilesCount), nameof(DocsRoots), nameof(FilesRoots), nameof(Roots), nameof(Scope), nameof(ScopeDescription));
        // The Changes tab's count, read in the background.
        _ = RefreshChangesAsync();
    }

    private (ObservableCollection<TreeNodeViewModel> Docs, ObservableCollection<TreeNodeViewModel> Files) Build(RepositoryIndex index)
    {
        var DocsRoots = new ObservableCollection<TreeNodeViewModel>();
        var FilesRoots = new ObservableCollection<TreeNodeViewModel>();

        // Documentation tab: the repository's own pages by folder. The generated reference pages (Overview, Architecture,
        // API, Operations) are not listed when there are own pages — search, links and the assistant still reach them; a
        // repository without Markdown of its own lists them under "Reference" so the tab is never empty.

        // A repository page shows as its file, in its folders, exactly as named on disk (README.md, docs/setup.md), not by its title.
        static string Shown(DocPage p) => !p.Generated && p.SourcePath is { Length: > 0 } source ? source.Replace('\\', '/') : p.TreePath;
        foreach (var page in index.ShownPages().OrderBy(p => p.Generated).ThenBy(p => Shown(p).Count(c => c == '/') == 0 ? 1 : 0).ThenBy(Shown, StringComparer.OrdinalIgnoreCase))
        {
            var segments = Shown(page).Split('/');
            var parent = EnsureFolder(DocsRoots, null, segments[..^1], page.Generated ? "Reference" : null);
            var collection = parent?.Children ?? DocsRoots;
            collection.Add(new TreeNodeViewModel(this, parent, segments[^1], TreeNodeKind.Page, page.TreePath, segments.Length - 1)
            {
                PageId = page.Id,
                SourcePath = page.SourcePath,
                IsGeneratedPage = page.Generated,
            });
        }
        foreach (var folder in DocsRoots.Where(n => n.Kind == TreeNodeKind.Folder && n.Name != "Reference"))
        {
            folder.IsExpanded = true;
        }

        // Files tab: every indexed file as it is on disk.
        foreach (var file in index.Files)
        {
            var segments = file.Path.Split('/');
            var parent = EnsureFolder(FilesRoots, null, segments[..^1], null);
            (parent?.Children ?? FilesRoots).Add(new TreeNodeViewModel(this, parent, segments[^1], TreeNodeKind.File, file.Path, segments.Length - 1) { SourcePath = file.Path });
        }
        SortFolders(FilesRoots);
        return (DocsRoots, FilesRoots);
    }

    private TreeNodeViewModel? EnsureFolder(ObservableCollection<TreeNodeViewModel> roots, TreeNodeViewModel? parent, string[] segments, string? _)
    {
        var current = parent;
        var path = "";
        for (var i = 0; i < segments.Length; i++)
        {
            path = path.Length == 0 ? segments[i] : path + "/" + segments[i];
            var collection = current?.Children ?? roots;
            var existing = collection.FirstOrDefault(n => n.Kind == TreeNodeKind.Folder && n.Name == segments[i]);
            if (existing is null)
            {
                existing = new TreeNodeViewModel(this, current, segments[i], TreeNodeKind.Folder, path, i);
                collection.Add(existing);
            }
            current = existing;
        }
        return current;
    }

    private static void SortFolders(ObservableCollection<TreeNodeViewModel> nodes)
    {
        var sorted = nodes.OrderBy(n => n.Kind == TreeNodeKind.Folder ? 0 : 1).ThenBy(n => n.Name, StringComparer.OrdinalIgnoreCase).ToList();
        nodes.Clear();
        foreach (var node in sorted)
        {
            nodes.Add(node);
            SortFolders(node.Children);
        }
    }

    private IEnumerable<TreeNodeViewModel> AllNodes() => DocsRoots.Concat(FilesRoots).SelectMany(n => n.Descendants().Prepend(n));

    private void ApplyFilter()
    {
        FilterResults.Clear();
        var term = Filter.Trim();
        if (term.Length == 0)
        {
            return;
        }
        var source = IsDocsTab ? DocsRoots : FilesRoots;
        foreach (var node in source.SelectMany(n => n.Descendants().Prepend(n)).Where(n => n.Kind != TreeNodeKind.Folder && (n.Name.Contains(term, StringComparison.OrdinalIgnoreCase) || n.Path.Contains(term, StringComparison.OrdinalIgnoreCase))).Take(300))
        {
            FilterResults.Add(node);
        }
    }

    internal void Activate(TreeNodeViewModel node)
    {
        // Unsaved changes in the editor: asked about first.
        if (node.Kind != TreeNodeKind.Folder && _workspace.Documentation is { Mode: "edit", IsDirty: true })
        {
            _ = ActivateAfterEditAsync(node);
            return;
        }
        Open(node);
    }

    private async Task ActivateAfterEditAsync(TreeNodeViewModel node)
    {
        if (await _workspace.Documentation.CloseEditAsync(reopen: false))
        {
            Open(node);
        }
    }

    private void Open(TreeNodeViewModel node)
    {
        switch (node.Kind)
        {
            case TreeNodeKind.Page when node.PageId is not null:
                if (_workspace.Main.Section != Section.Documentation)
                {
                    _workspace.Main.Navigate(Section.Documentation);
                }
                _workspace.Documentation.OpenPage(node.PageId, null);
                break;
            case TreeNodeKind.File:
                if (_workspace.Main.Section != Section.Documentation)
                {
                    _workspace.Main.Navigate(Section.Documentation);
                }
                _workspace.Documentation.OpenFile(node.Path, 0);
                break;
            case TreeNodeKind.Folder:
                node.IsExpanded = !node.IsExpanded;
                break;
        }
    }

    /// <summary>Marks the node for what is open, expanding its folders, without re-opening it.</summary>
    public void Sync(string? pageId, string? filePath)
    {
        Syncing = true;
        try
        {
            foreach (var node in AllNodes())
            {
                var match = pageId is not null ? node.PageId == pageId && node.Kind == TreeNodeKind.Page
                    : filePath is not null && node.Kind == TreeNodeKind.File && string.Equals(node.Path, filePath, StringComparison.OrdinalIgnoreCase);
                if (match)
                {
                    for (var p = node.Parent; p is not null; p = p.Parent)
                    {
                        p.IsExpanded = true;
                    }
                }
                if (node.IsSelected != match)
                {
                    node.IsSelected = match;
                }
            }
            if (pageId is null && filePath is not null && IsDocsTab)
            {
                Tab = "files";
            }
        }
        finally
        {
            Syncing = false;
        }
    }

    internal void OnCheckedChanged()
    {
        // The scope is the set of top-most fully ticked folders and files (pages count as their source files).
        var scope = new List<string>();
        void Walk(IEnumerable<TreeNodeViewModel> nodes)
        {
            foreach (var node in nodes)
            {
                if (node.IsChecked == true)
                {
                    var path = node.Kind == TreeNodeKind.Page ? node.SourcePath : node.Path;
                    if (path is not null && !(node.Kind == TreeNodeKind.Folder && IsDocsTab && node.Name == "Reference"))
                    {
                        scope.Add(path);
                    }
                    else if (node.Kind == TreeNodeKind.Folder)
                    {
                        Walk(node.Children);
                    }
                }
                else if (node.IsChecked is null)
                {
                    Walk(node.Children);
                }
            }
        }
        Walk(DocsRoots);
        Walk(FilesRoots);
        _scope = scope.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        Notify(nameof(Scope), nameof(ScopeDescription), nameof(HasScope));
        ScopeChanged?.Invoke(this, EventArgs.Empty);
    }

    public void ClearSelection()
    {
        foreach (var root in DocsRoots.Concat(FilesRoots))
        {
            root.IsChecked = false;
        }
        _scope = [];
        Notify(nameof(Scope), nameof(ScopeDescription), nameof(HasScope));
        ScopeChanged?.Invoke(this, EventArgs.Empty);
    }
}
