using System.Diagnostics;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>One open repository: its loaded index, the tree, the assistant and the section pages.</summary>
public sealed class WorkspaceViewModel : ObservableObject
{
    private RepositoryIndex? _index;
    private RepositoryRecord _record;
    // A workspace is loaded as soon as it is opened: until then it is "loading", not "not indexed".
    private bool _isLoading = true;
    private bool _isSearchReady;

    public WorkspaceViewModel(MainViewModel main, RepositoryRecord record)
    {
        Main = main;
        _record = record;
        Tree = new RepositoryTreeViewModel(this);
        Assistant = new AssistantViewModel(this);
        Documentation = new DocumentationViewModel(this);
        Graph = new GraphViewModel(this);
        Indexing = new IndexingViewModel(this);
        Learning = new LearningViewModel(this);
        Studio = new StudioViewModel(this);
        Talk = new AssistantViewModel(this, talk: true);
    }

    public MainViewModel Main { get; }

    public RepositoryRecord Record
    {
        get => _record;
        private set
        {
            if (Set(ref _record, value))
            {
                Notify(nameof(Title));
            }
        }
    }

    public string Title => Record.Title;

    public RepositoryIndex? Index
    {
        get => _index;
        private set
        {
            if (Set(ref _index, value))
            {
                Notify(nameof(IsIndexed));
            }
        }
    }

    public bool IsIndexed => Index is not null;

    /// <summary>The index is being read from disk.</summary>
    public bool IsLoading
    {
        get => _isLoading;
        private set
        {
            if (Set(ref _isLoading, value))
            {
                Assistant.OnLoadingChanged();
            }
        }
    }

    /// <summary>The keyword index is built (it is built in the background after loading; questions wait for it).</summary>
    public bool IsSearchReady
    {
        get => _isSearchReady;
        private set
        {
            if (Set(ref _isSearchReady, value))
            {
                Assistant.OnLoadingChanged();
            }
        }
    }

    public RepositoryTreeViewModel Tree { get; }
    public AssistantViewModel Assistant { get; }
    public DocumentationViewModel Documentation { get; }
    public GraphViewModel Graph { get; }
    public IndexingViewModel Indexing { get; }
    public LearningViewModel Learning { get; }
    public StudioViewModel Studio { get; }

    /// <summary>Talk: a persona conversation about this repository (one per repository, so nothing mixes).</summary>
    public AssistantViewModel Talk { get; }

    /// <summary>What the assistant, Learning and Studio may draw on (empty: everything).</summary>
    public IReadOnlyList<string> Scope => Tree.Scope;

    public async Task LoadAsync()
    {
        IsLoading = true;
        try
        {
            if (await Main.Engine.Repositories.GetAsync(Record.Id) is { } fresh)
            {
                Record = fresh;
            }
            // Reading and deserialising a large index is CPU work: keep it off the UI thread.
            var id = Record.Id;
            var engine = Main.Engine;
            var index = await Task.Run(async () =>
            {
                var loaded = await engine.Indexing.GetAsync(id);
                loaded?.Warm();
                return loaded;
            });
            Index = index;
            // The keyword index takes seconds on a large repository: the documentation shows meanwhile.
            IsSearchReady = index?.IsSearchReady ?? false;
            if (index is { IsSearchReady: false })
            {
                _ = Task.Run(() =>
                {
                    index.WarmSearch();
                    Ui.Post(() => IsSearchReady = ReferenceEquals(Index, index) || IsSearchReady);
                });
            }
            await Tree.RebuildAsync();
            Documentation.OnIndexChanged();
            Graph.OnIndexChanged();
            await Assistant.LoadAsync();
            Indexing.Refresh();
            if (index?.LastRun is { } last && last.ChunkerVersion < Chunker.Version && !Main.Engine.Indexing.IsRunning(Record.Id))
            {
                // Made under older chunking rules (bulk data such as test fixtures cut into thousands of windows): a
                // one-time refresh re-chunks it — smaller, faster to load, better search. Code embeddings are reused.
                Main.ShowToast("Updating this repository's index to the new, smaller format (once). It stays usable meanwhile.", false);
                _ = Main.Engine.Indexing.StartAsync(Record.Id, IndexMode.Incremental);
            }
            if (index is null && !Main.Engine.Indexing.IsRunning(Record.Id) && Record.Status != RepositoryStatus.Indexing)
            {
                // A repository that was never indexed starts indexing as soon as it is opened.
                if (Record.Status is RepositoryStatus.NotIndexed)
                {
                    _ = Main.Engine.Indexing.StartAsync(Record.Id, IndexMode.Full);
                }
            }
        }
        finally
        {
            IsLoading = false;
        }
    }

    public async Task OnIndexCompletedAsync(IndexRun run)
    {
        if (run.State == RunState.Completed)
        {
            // The pipeline already holds the new index in memory; no need to reload it from disk.
            await LoadAsync();
            Learning.OnIndexChanged();
            Studio.OnIndexChanged();
        }
        else
        {
            if (await Main.Engine.Repositories.GetAsync(Record.Id) is { } fresh)
            {
                Record = fresh;
            }
            Indexing.Refresh();
        }
    }

    /// <summary>
    /// Routes a link from a page, an answer or a citation: repo:path#L12 opens a file at a line, page:id#anchor opens a
    /// page, http(s) opens the browser, and a relative path is resolved against the page it was found on.
    /// </summary>
    public void OpenLink(string url, string? fromPath = null)
    {
        if (string.IsNullOrWhiteSpace(url))
        {
            return;
        }
        if (url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) || url.StartsWith("https://", StringComparison.OrdinalIgnoreCase) || url.StartsWith("mailto:", StringComparison.OrdinalIgnoreCase))
        {
            try
            {
                Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
            }
            catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or InvalidOperationException)
            {
                Main.ShowToast("Could not open " + url, true);
            }
            return;
        }
        if (Main.Section is not (Section.Documentation))
        {
            Main.Navigate(Section.Documentation);
        }
        var (target, fragment) = Split(url);
        if (target.StartsWith("repo:", StringComparison.Ordinal))
        {
            Documentation.OpenFile(target[5..], LineOf(fragment));
            return;
        }
        if (target.StartsWith("page:", StringComparison.Ordinal))
        {
            Documentation.OpenPage(target[5..], fragment);
            return;
        }
        if (target.Length == 0 && fragment is not null)
        {
            Documentation.ScrollToAnchor(fragment);
            return;
        }
        // Relative link inside the repository.
        var baseFolder = fromPath is null ? "" : Path.GetDirectoryName(fromPath)?.Replace('\\', '/') ?? "";
        var combined = NormalizeRelative(baseFolder.Length == 0 ? target : baseFolder + "/" + target);
        if (Index?.PageForSource(combined) is { } page)
        {
            Documentation.OpenPage(page.Id, fragment);
        }
        else if (Index?.FindFile(combined) is not null)
        {
            Documentation.OpenFile(combined, LineOf(fragment));
        }
        else if (Index?.FindFile(target) is not null)
        {
            Documentation.OpenFile(target, LineOf(fragment));
        }
        else
        {
            var full = Path.Combine(Record.Path, combined.Replace('/', Path.DirectorySeparatorChar));
            if (File.Exists(full) || Directory.Exists(full))
            {
                Process.Start(new ProcessStartInfo(full) { UseShellExecute = true });
            }
            else
            {
                Main.ShowToast($"'{combined}' is not in the index.", true);
            }
        }
    }

    private static (string Target, string? Fragment) Split(string url)
    {
        var hash = url.IndexOf('#');
        return hash < 0 ? (url, null) : (url[..hash], url[(hash + 1)..]);
    }

    private static int LineOf(string? fragment)
    {
        if (fragment is null)
        {
            return 0;
        }
        var text = fragment.TrimStart('L', 'l');
        var dash = text.IndexOf('-');
        if (dash > 0)
        {
            text = text[..dash];
        }
        return int.TryParse(text, out var line) ? line : 0;
    }

    public static string NormalizeRelative(string path)
    {
        var parts = new List<string>();
        foreach (var part in Uri.UnescapeDataString(path).Replace('\\', '/').Split('/', StringSplitOptions.RemoveEmptyEntries))
        {
            // A drive ("C:") would make the result a path of its own, outside the repository; no file name has a colon.
            if (part == "." || part.Contains(':'))
            {
                continue;
            }
            if (part == "..")
            {
                if (parts.Count > 0)
                {
                    parts.RemoveAt(parts.Count - 1);
                }
                continue;
            }
            parts.Add(part);
        }
        return string.Join('/', parts);
    }
}
