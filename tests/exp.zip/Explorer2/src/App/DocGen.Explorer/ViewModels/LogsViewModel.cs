using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Globalization;
using System.Windows.Input;
using System.Windows.Threading;
using DocGen.Explorer.Engine.Storage;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>A column of the log table: shown or hidden (the Columns menu), sorted by its header.</summary>
public sealed class LogColumn(string key, string title, bool visible, Action changed) : ObservableObject
{
    private bool _visible = visible;

    public string Key { get; } = key;
    public string Title { get; } = title;

    public bool IsVisible
    {
        get => _visible;
        set
        {
            if (Set(ref _visible, value))
            {
                changed();
            }
        }
    }
}

/// <summary>A level the table can show (with how many entries have it), ticked to show it.</summary>
public sealed class LogLevelChoice(string level, Action changed) : ObservableObject
{
    private bool _isChecked = true;
    private int _count;

    public string Level { get; } = level;
    public string Label => Level switch { "ERROR" => "Errors", "WARN" => "Warnings", "INFO" => "Information", _ => "Debug" };

    public int Count
    {
        get => _count;
        set
        {
            if (Set(ref _count, value))
            {
                OnPropertyChanged(nameof(Text));
            }
        }
    }

    public string Text => $"{Label} ({Count:N0})";

    public bool IsChecked
    {
        get => _isChecked;
        set
        {
            if (Set(ref _isChecked, value))
            {
                changed();
            }
        }
    }
}

/// <summary>An entry as a row of the table.</summary>
public sealed class LogRow(LogEntry entry)
{
    public LogEntry Entry { get; } = entry;
    public string Time => Entry.Time.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture);
    public string Level => Entry.Level;
    public string Source => Entry.Source;
    public string Message => Entry.Summary.Replace('\n', ' ');
    public string Exception => Entry.Exception;
    public string File => $"{Entry.File}:{Entry.Line}";
    public bool HasDetails => Entry.Details.Length > 0;
    public string Tip => Entry.Full.Length > 1500 ? Entry.Full[..1499] + "…" : Entry.Full;
}

public sealed record LogPageButton(int Number, bool IsCurrent, ICommand Command);

/// <summary>
/// The log viewer: every entry of the explorer's log (the app and the engine), newest first, in pages. It filters by
/// level, by words (in every column, or a column of its own), and by time — a quick range or from / to a date and time;
/// columns can be shown or hidden and sorted; and it can refresh itself every few seconds.
/// </summary>
public sealed class LogsViewModel : ObservableObject, IActivatable
{
    public static readonly IReadOnlyList<int> PageSizes = [50, 100, 200, 500, 1000];
    public static readonly IReadOnlyList<string> Ranges = ["All time", "15 minutes", "1 hour", "24 hours", "Today", "7 days", "Custom"];
    public static readonly IReadOnlyList<int> RefreshChoices = [2, 5, 10, 30, 60];

    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly DispatcherTimer _refreshTimer;
    private readonly DispatcherTimer _filterTimer;
    private LogReader? _reader;
    private string _search = "";
    private string _sourceFilter = "";
    private string _messageFilter = "";
    private string _exceptionFilter = "";
    private string _fileFilter = "";
    private string _range = "All time";
    private DateTime? _from;
    private DateTime? _to;
    private bool _levelMenuOpen;
    private int _pageSize = 100;
    private int _page;
    private int _pageCount = 1;
    private string _sortBy = "time";
    private bool _descending = true;
    private bool _autoRefresh;
    private string _status = "";
    private LogRow? _selected;
    private bool _loading;

    public LogsViewModel(MainViewModel main)
    {
        Main = main;
        Columns =
        [
            new("time", "Time", true, ColumnsChanged),
            new("level", "Level", true, ColumnsChanged),
            new("source", "Source", true, ColumnsChanged),
            new("message", "Message", true, ColumnsChanged),
            new("exception", "Exception", true, ColumnsChanged),
            new("file", "Log file", false, ColumnsChanged),
        ];
        LevelChoices = [.. LogReader.Levels.Select(l => new LogLevelChoice(l, () =>
        {
            OnPropertyChanged(nameof(LevelsText));
            Apply(resetPage: true);
        }))];
        _refreshTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(UiPreferences.Current.LogRefreshSeconds) };
        _refreshTimer.Tick += async (_, _) =>
        {
            if (Main.Section == Section.Logs)
            {
                await RefreshAsync();
            }
        };
        _filterTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(250) };
        _filterTimer.Tick += (_, _) =>
        {
            _filterTimer.Stop();
            Apply(resetPage: true);
        };
        UiPreferences.Current.PropertyChanged += (_, e) =>
        {
            if (e.PropertyName == nameof(UiPreferences.LogRefreshSeconds))
            {
                _refreshTimer.Interval = TimeSpan.FromSeconds(UiPreferences.Current.LogRefreshSeconds);
                OnPropertyChanged(nameof(RefreshSeconds));
            }
        };
    }

    public MainViewModel Main { get; }
    public ObservableCollection<LogRow> Rows { get; } = [];
    public ObservableCollection<LogPageButton> PageNumbers { get; } = [];
    public IReadOnlyList<LogColumn> Columns { get; }
    public IReadOnlyList<LogLevelChoice> LevelChoices { get; }
    public IReadOnlyList<int> PageSizeChoices => PageSizes;
    public IReadOnlyList<string> RangeChoices => Ranges;
    public IReadOnlyList<int> RefreshSecondChoices => RefreshChoices;

    /// <summary>Raised when the shown columns change (the view adds or removes them).</summary>
    public event EventHandler? ColumnsChangedEvent;

    private void ColumnsChanged()
    {
        ColumnsChangedEvent?.Invoke(this, EventArgs.Empty);
        OnPropertyChanged(nameof(ColumnsText));
    }

    public string ColumnsText => $"Columns ({Columns.Count(c => c.IsVisible)} of {Columns.Count})";

    public string Folder => Logging.Folder ?? "";

    public string Search { get => _search; set { if (Set(ref _search, value ?? "")) { ScheduleFilter(); } } }
    public string SourceFilter { get => _sourceFilter; set { if (Set(ref _sourceFilter, value ?? "")) { ScheduleFilter(); } } }
    public string MessageFilter { get => _messageFilter; set { if (Set(ref _messageFilter, value ?? "")) { ScheduleFilter(); } } }
    public string ExceptionFilter { get => _exceptionFilter; set { if (Set(ref _exceptionFilter, value ?? "")) { ScheduleFilter(); } } }
    public string FileFilter { get => _fileFilter; set { if (Set(ref _fileFilter, value ?? "")) { ScheduleFilter(); } } }

    /// <summary>A quick time range (the chips), or "Custom": from and to a date and time.</summary>
    public string Range
    {
        get => _range;
        set
        {
            if (Set(ref _range, Ranges.Contains(value) ? value : "All time"))
            {
                OnPropertyChanged(nameof(IsCustomRange));
                Apply(resetPage: true);
            }
        }
    }

    public ICommand SetRangeCommand => new RelayCommand(p => Range = p as string ?? "All time");

    public bool IsCustomRange => Range == "Custom";

    /// <summary>The custom range: from this date and time (local; null: from the first entry).</summary>
    public DateTime? From { get => _from; set { if (Set(ref _from, value)) { UseCustom(); } } }

    /// <summary>The custom range: to this date and time (local; null: to the last entry).</summary>
    public DateTime? To { get => _to; set { if (Set(ref _to, value)) { UseCustom(); } } }

    private void UseCustom()
    {
        if (_loading)
        {
            return;
        }
        if (!IsCustomRange)
        {
            _range = "Custom";
            Notify(nameof(Range), nameof(IsCustomRange));
        }
        ScheduleFilter();
    }

    // ----- Levels (a menu, as the Feature and Model filters of Token usage) -----

    public bool LevelMenuOpen { get => _levelMenuOpen; set => Set(ref _levelMenuOpen, value); }
    public ICommand ToggleLevelMenuCommand => new RelayCommand(() => LevelMenuOpen = !LevelMenuOpen);
    public ICommand NoLevelsCommand => new RelayCommand(() => SetLevels(false));

    /// <summary>"All levels", "Errors", "Errors and Warnings", "None"…</summary>
    public string LevelsText
    {
        get
        {
            var on = LevelChoices.Where(l => l.IsChecked).ToList();
            return on.Count == LevelChoices.Count ? "All levels" : on.Count == 0 ? "None" : string.Join(", ", on.Select(l => l.Label));
        }
    }

    public int PageSize
    {
        get => _pageSize;
        set
        {
            if (Set(ref _pageSize, PageSizes.Contains(value) ? value : 100))
            {
                Apply(resetPage: true);
            }
        }
    }

    public int Page => _page;
    public int PageCount => _pageCount;
    public string PageText => $"Page {_page + 1:N0} of {_pageCount:N0}";

    public bool AutoRefresh
    {
        get => _autoRefresh;
        set
        {
            if (Set(ref _autoRefresh, value))
            {
                if (value)
                {
                    _refreshTimer.Start();
                    _ = RefreshAsync();
                }
                else
                {
                    _refreshTimer.Stop();
                }
            }
        }
    }

    /// <summary>How often auto refresh reads the log (Settings → Reading and writing).</summary>
    public int RefreshSeconds
    {
        get => UiPreferences.Current.LogRefreshSeconds;
        set => UiPreferences.Current.LogRefreshSeconds = value;
    }

    public string Status { get => _status; private set => Set(ref _status, value); }

    public LogRow? Selected
    {
        get => _selected;
        set
        {
            if (Set(ref _selected, value))
            {
                Notify(nameof(SelectedText), nameof(HasSelected));
            }
        }
    }

    public bool HasSelected => Selected is not null;
    public string SelectedText => Selected is null ? "" : $"{Selected.Time}  {Selected.Level}  {Selected.Source}\n{Selected.Entry.Full}";

    public string SortBy => _sortBy;
    public bool Descending => _descending;

    /// <summary>The time column's title, with the direction when the table is sorted by time.</summary>
    public string TimeHeader => _sortBy == "time" ? (_descending ? "Time ↓ (newest first)" : "Time ↑ (oldest first)") : "Time";

    public ICommand RefreshCommand => new AsyncCommand(RefreshAsync);
    public ICommand FirstCommand => new RelayCommand(() => GoTo(0), () => _page > 0);
    public ICommand PreviousCommand => new RelayCommand(() => GoTo(_page - 1), () => _page > 0);
    public ICommand NextCommand => new RelayCommand(() => GoTo(_page + 1), () => _page < _pageCount - 1);
    public ICommand LastCommand => new RelayCommand(() => GoTo(_pageCount - 1), () => _page < _pageCount - 1);
    public ICommand SortCommand => new RelayCommand(p => Sort(p as string ?? "time"));
    public ICommand ClearFiltersCommand => new RelayCommand(ClearFilters);
    public ICommand CopySelectedCommand => new RelayCommand(() => { if (Selected is not null && Ui.Copy(SelectedText)) { Ui.Notify("Entry copied."); } }, () => Selected is not null);
    public ICommand CopyPageCommand => new RelayCommand(() =>
    {
        var text = string.Join(Environment.NewLine, Rows.Select(r => $"{r.Time} {r.Level} {(r.Source.Length > 0 ? "[" + r.Source + "] " : "")}{r.Entry.Full}"));
        if (Ui.Copy(text))
        {
            Ui.Notify($"{Rows.Count:N0} entries copied.");
        }
    }, () => Rows.Count > 0);
    public ICommand OpenFolderCommand => new RelayCommand(() =>
    {
        if (Directory.Exists(Folder))
        {
            Process.Start(new ProcessStartInfo("explorer.exe", $"\"{Folder}\"") { UseShellExecute = true });
        }
    });
    public ICommand AllLevelsCommand => new RelayCommand(() => SetLevels(true));
    public ICommand ErrorsOnlyCommand => new RelayCommand(() =>
    {
        foreach (var level in LevelChoices)
        {
            level.IsChecked = level.Level is "ERROR" or "WARN";
        }
    });

    public async Task ActivateAsync()
    {
        if (_reader is null || _reader.Folder != Folder)
        {
            _reader = new LogReader(Folder);
        }
        await RefreshAsync();
        if (AutoRefresh)
        {
            _refreshTimer.Start();
        }
    }

    /// <summary>Reads what is new in the log and shows the page again (keeping the place).</summary>
    public async Task RefreshAsync()
    {
        if (_reader is null)
        {
            return;
        }
        await _gate.WaitAsync();
        try
        {
            var reader = _reader;
            var added = await Task.Run(reader.Refresh);
            foreach (var level in LevelChoices)
            {
                level.Count = reader.Entries.Count(e => e.Level == level.Level);
            }
            Apply(resetPage: false);
            if (added > 0 && AutoRefresh)
            {
                Status = $"{added:N0} new {(added == 1 ? "entry" : "entries")} at {DateTime.Now:HH:mm:ss}";
            }
        }
        finally
        {
            _gate.Release();
        }
    }

    private void ScheduleFilter()
    {
        _filterTimer.Stop();
        _filterTimer.Start();
    }

    private void Sort(string key)
    {
        if (_sortBy == key)
        {
            _descending = !_descending;
        }
        else
        {
            _sortBy = key;
            _descending = key is "time";
        }
        Notify(nameof(SortBy), nameof(Descending), nameof(TimeHeader));
        Apply(resetPage: true);
    }

    private void SetLevels(bool on)
    {
        foreach (var level in LevelChoices)
        {
            level.IsChecked = on;
        }
    }

    private void ClearFilters()
    {
        _loading = true;
        Search = SourceFilter = MessageFilter = ExceptionFilter = FileFilter = "";
        From = To = null;
        _range = "All time";
        _loading = false;
        Notify(nameof(Range), nameof(IsCustomRange));
        SetLevels(true);
        Apply(resetPage: true);
    }

    /// <summary>The time range as UTC bounds (null: open).</summary>
    public (DateTime? From, DateTime? To) Bounds(DateTime now)
    {
        return Range switch
        {
            "15 minutes" => (now.AddMinutes(-15).ToUniversalTime(), null),
            "1 hour" => (now.AddHours(-1).ToUniversalTime(), null),
            "24 hours" => (now.AddDays(-1).ToUniversalTime(), null),
            "Today" => (now.Date.ToUniversalTime(), null),
            "7 days" => (now.AddDays(-7).ToUniversalTime(), null),
            // The "to" minute is included whole (to 14:05 takes 14:05:59).
            "Custom" => (Local(From)?.ToUniversalTime(), Local(To)?.AddSeconds(59.999).ToUniversalTime()),
            _ => (null, null),
        };

        static DateTime? Local(DateTime? value) => value is { } v ? DateTime.SpecifyKind(v, DateTimeKind.Local) : null;
    }

    private void Apply(bool resetPage)
    {
        if (_reader is null || _loading)
        {
            return;
        }
        var (from, to) = Bounds(DateTime.Now);
        var filter = new LogFilter
        {
            Levels = LevelChoices.Where(l => l.IsChecked).Select(l => l.Level).ToHashSet(),
            Search = Search,
            Source = SourceFilter,
            Message = MessageFilter,
            Exception = ExceptionFilter,
            File = FileFilter,
            FromUtc = from,
            ToUtc = to,
        };
        if (LevelChoices.All(l => !l.IsChecked))
        {
            filter = filter with { Levels = new HashSet<string> { "none" } };
        }
        var selectedId = Selected?.Entry.Id;
        var result = _reader.Query(filter, resetPage ? 0 : _page, PageSize, _descending, _sortBy);
        _page = result.Page;
        _pageCount = result.PageCount;
        Rows.Clear();
        foreach (var entry in result.Entries)
        {
            Rows.Add(new LogRow(entry));
        }
        Selected = Rows.FirstOrDefault(r => r.Entry.Id == selectedId);
        PageNumbers.Clear();
        var first = Math.Max(0, Math.Min(_page - 2, _pageCount - 5));
        for (var i = first; i < Math.Min(_pageCount, first + 5); i++)
        {
            var n = i;
            PageNumbers.Add(new LogPageButton(n + 1, n == _page, new RelayCommand(() => GoTo(n))));
        }
        var start = result.Matching == 0 ? 0 : _page * PageSize + 1;
        var end = Math.Min(result.Matching, (_page + 1) * PageSize);
        RangeText = result.Matching == 0
            ? result.Total == 0 ? "The log is empty." : $"No entries match (of {result.Total:N0})."
            : $"{start:N0}–{end:N0} of {result.Matching:N0} entries" + (result.Matching < result.Total ? $" (filtered from {result.Total:N0})" : "");
        Notify(nameof(Page), nameof(PageCount), nameof(PageText), nameof(RangeText), nameof(HasRows), nameof(IsFiltered));
        CommandManager.InvalidateRequerySuggested();
    }

    public string RangeText { get; private set; } = "";
    public bool HasRows => Rows.Count > 0;

    public bool IsFiltered => Search.Length + SourceFilter.Length + MessageFilter.Length + ExceptionFilter.Length + FileFilter.Length > 0 || Range != "All time"
                              || LevelChoices.Any(l => !l.IsChecked);

    private void GoTo(int page)
    {
        _page = Math.Clamp(page, 0, Math.Max(0, _pageCount - 1));
        Apply(resetPage: false);
    }
}
