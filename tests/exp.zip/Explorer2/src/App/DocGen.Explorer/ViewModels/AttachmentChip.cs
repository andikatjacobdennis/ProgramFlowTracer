using System.Windows.Media;
using System.Windows.Media.Imaging;
using DocGen.Explorer.Engine.Assistant;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;

namespace DocGen.Explorer.ViewModels;

/// <summary>
/// An attached file as shown: a square card with its name, type and size (an image shows its picture), and a tooltip
/// with everything the card has no room for — the whole name, the kind, the size, what was read, and a preview.
/// </summary>
public sealed class AttachmentChip(Attachment attachment)
{
    public Attachment Attachment { get; } = attachment;

    public string Name => Attachment.Name;

    /// <summary>An image's small picture, for its card.</summary>
    public ImageSource? Thumbnail => _thumbnail ??= Infrastructure.ImageAttachments.Thumbnail(Attachment);

    private ImageSource? _thumbnail;
    private ImageSource? _preview;

    public bool HasThumbnail => Thumbnail is not null;

    /// <summary>A larger picture of an image, for its tooltip.</summary>
    public ImageSource? Preview => _preview ??= Infrastructure.ImageAttachments.Thumbnail(Attachment, 360);

    /// <summary>The file's type on its card: "PDF", "JSON", "PNG"…</summary>
    public string Badge => Path.GetExtension(Name).TrimStart('.').ToUpperInvariant() is { Length: > 0 and <= 6 } extension ? extension : "FILE";

    /// <summary>The size, in the unit that reads best ("4.2 KB", "1.5 MB").</summary>
    public string SizeText => TextUtil.Size(Attachment.Size);

    /// <summary>The line at the foot of a card: the size, or why the file was not (fully) read.</summary>
    public string CardDetail => Attachment.Status switch
    {
        AttachmentStatus.Read => SizeText,
        AttachmentStatus.Truncated => $"{SizeText} · cut",
        AttachmentStatus.NotSupported => "not supported",
        AttachmentStatus.TurnedOff => "not read",
        AttachmentStatus.TooLarge => $"too large · {SizeText}",
        _ => "not read",
    };

    /// <summary>"PDF · 1.2 MB", or "not supported" / "too large" / … when it was not read.</summary>
    public string Detail => Attachment.Status switch
    {
        AttachmentStatus.Read => $"{Kind} · {TextUtil.SizeWithBytes(Attachment.Size)}",
        AttachmentStatus.Truncated => $"{Kind} · {TextUtil.SizeWithBytes(Attachment.Size)} · first part sent",
        AttachmentStatus.NotSupported => $"{TextUtil.SizeWithBytes(Attachment.Size)} · not supported (attached by name only)",
        AttachmentStatus.TurnedOff => "not read (turned off)",
        AttachmentStatus.TooLarge => $"too large · {TextUtil.SizeWithBytes(Attachment.Size)}",
        _ => "could not be read",
    };

    /// <summary>What was read: "128 lines · 4,301 characters", "1280 × 720 pixels"…</summary>
    public string? Content
    {
        get
        {
            if (Attachment.Text is { Length: > 0 } text)
            {
                var lines = text.Count(c => c == '\n') + 1;
                return $"{TextUtil.Plural(lines, "line")} · {TextUtil.Plural(text.Length, "character")} read";
            }
            if (Preview is BitmapSource picture)
            {
                return $"{Dimensions(Attachment) ?? "image"} · {Attachment.MediaType}";
            }
            return null;
        }
    }

    /// <summary>The first lines of a text attachment, for its tooltip.</summary>
    public string? TextPreview
    {
        get
        {
            if (Attachment.Text is not { Length: > 0 } text)
            {
                return null;
            }
            var lines = text.Replace("\r", "", StringComparison.Ordinal).Split('\n');
            // What fits the tooltip's preview: twelve lines of about 52 characters.
            var shown = lines.Take(12).Select(l => l.Length > 52 ? l[..51] + "…" : l);
            return string.Join("\n", shown) + (lines.Length > 12 ? $"\n… {TextUtil.Plural(lines.Length - 12, "more line")}" : "");
        }
    }

    public bool HasTextPreview => TextPreview is not null;

    /// <summary>Why it was not (fully) read, or how it was changed (an image scaled down).</summary>
    public string? Note => Attachment.Note;

    public bool HasNote => !string.IsNullOrEmpty(Note);

    public string ToolTip => string.Join("\n", new[] { Name, Detail, Content, Note }.Where(s => !string.IsNullOrEmpty(s)));

    /// <summary>Not (fully) read: shown in the warning colour.</summary>
    public bool IsProblem => Attachment.Status is not AttachmentStatus.Read;

    public string Glyph => Attachment.Kind switch
    {
        Attachments.Image => Infrastructure.Icons.Image,
        Attachments.Pdf or Attachments.Word => Infrastructure.Icons.Document,
        Attachments.Text => Infrastructure.Icons.Code,
        _ => Infrastructure.Icons.Attach,
    };

    private string Kind => Attachments.KindName(Attachment.Kind ?? Attachments.Text);

    public static string Size(long bytes) => TextUtil.Size(bytes);

    /// <summary>An image's size in pixels, from its content ("1280 × 720").</summary>
    private static string? Dimensions(Attachment attachment)
    {
        if (attachment.ImageBase64 is not { Length: > 0 } data)
        {
            return null;
        }
        try
        {
            var frame = BitmapDecoder.Create(new MemoryStream(Convert.FromBase64String(data)), BitmapCreateOptions.DelayCreation, BitmapCacheOption.None).Frames[0];
            return $"{frame.PixelWidth} × {frame.PixelHeight} pixels";
        }
        catch (Exception ex) when (ex is NotSupportedException or FileFormatException or FormatException or ArgumentException or InvalidOperationException)
        {
            return null;
        }
    }
}
