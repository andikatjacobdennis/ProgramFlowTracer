namespace DocGen.Explorer.ViewModels;

/// <summary>A place in the explorer Help can take you to: its link, its name, and how to get there by hand.</summary>
public sealed record HelpDestination(string Link, string Label, string Where)
{
    /// <summary>The page belongs to a repository (one must be open).</summary>
    public bool NeedsRepository { get; init; }
}

/// <summary>
/// The places in the explorer that Help's answers link to, as <c>explorer:</c> links: a section
/// (<c>explorer:section/indexing</c>), a page of Settings (<c>explorer:settings/confluence</c>) or a Help article
/// (<c>explorer:help/confluence</c>). <see cref="Open"/> goes there, as the header and the menus would.
/// </summary>
public static class HelpLinks
{
    public const string Scheme = "explorer:";

    /// <summary>The Settings pages by their link name (chat-model is the Chat model page).</summary>
    private static readonly Dictionary<string, string> SettingsByLink = new(StringComparer.OrdinalIgnoreCase)
    {
        ["appearance"] = SettingsPages.Appearance,
        ["shortcuts"] = SettingsPages.Shortcuts,
        ["editing"] = SettingsPages.Editing,
        ["voice"] = SettingsPages.Voice,
        ["attachments"] = SettingsPages.Attachments,
        ["chat-model"] = SettingsPages.Model,
        ["model"] = SettingsPages.Model,
        ["providers"] = SettingsPages.Providers,
        ["skills"] = SettingsPages.Skills,
        ["confluence"] = SettingsPages.Confluence,
        ["prices"] = SettingsPages.Prices,
        ["data"] = SettingsPages.Data,
    };

    private static readonly Dictionary<string, Section> SectionsByLink = new(StringComparer.OrdinalIgnoreCase)
    {
        ["repositories"] = Section.Repositories,
        ["documentation"] = Section.Documentation,
        ["graph"] = Section.Graph,
        ["indexing"] = Section.Indexing,
        ["learning"] = Section.Learning,
        ["studio"] = Section.Studio,
        ["talk"] = Section.Talk,
        ["personas"] = Section.Personas,
        ["usage"] = Section.Usage,
        ["logs"] = Section.Logs,
        ["help"] = Section.Help,
        ["settings"] = Section.Settings,
    };

    /// <summary>Said of a repository's pages (Documentation, Graph, Indexing…): how to open one first.</summary>
    public const string RepositoryFirst = "Open a repository first: on Repositories, choose Open on its card (with only one, the explorer opens it by itself).";
    private const string GearMenu = "the ⚙ menu at the right of the header";

    private static HelpDestination Repo(string name, string label, string where) => new($"{Scheme}section/{name}", label, where) { NeedsRepository = true };

    private static HelpDestination Page(string name, string title, string where) => new($"{Scheme}settings/{name}", "Settings → " + title, $"{GearMenu} → Settings → {where}.");

    /// <summary>Every place an answer can link to (besides the Help articles).</summary>
    public static readonly IReadOnlyList<HelpDestination> Destinations =
    [
        new($"{Scheme}section/repositories", "Repositories", "The list of repositories: DocGen Explorer at the left of the header, or the repository menu → All repositories. Add repository is here."),
        Repo("documentation", "Documentation", "Documentation in the header (Ctrl+1): the files list, the page and Ask beside it."),
        Repo("graph", "Graph", "Graph in the header (Ctrl+2)."),
        Repo("indexing", "Indexing of this repository", "Click the repository's name at the left of the header and choose Indexing of this repository (Ctrl+3). Refresh, Full reindex, Pull latest and the Confluence spaces are here."),
        Repo("learning", "Learning", "Learning in the header (Ctrl+4)."),
        Repo("studio", "Studio", "Studio in the header (Ctrl+5)."),
        Repo("talk", "Talk", "Talk in the header (Ctrl+7)."),
        new($"{Scheme}section/personas", "Personas", $"{GearMenu} → Personas (or Manage personas in Studio)."),
        new($"{Scheme}section/usage", "Token usage", $"{GearMenu} → Token usage (or Settings → Token usage)."),
        new($"{Scheme}section/logs", "Logs", $"{GearMenu} → Logs."),
        Page("appearance", "Appearance", "Appearance"),
        Page("shortcuts", "Shortcuts", "Shortcuts"),
        Page("editing", "Reading and writing", "Reading and writing"),
        Page("voice", "Voice", "Voice (read aloud and the microphone)"),
        Page("attachments", "Attachments", "Attachments"),
        Page("chat-model", "Chat model", "Chat model (under AI)"),
        Page("providers", "Providers and models", "Providers and models (under AI)"),
        Page("skills", "Skills", "Skills (under AI)"),
        Page("confluence", "Confluence", "Confluence (under Integrations): the Confluence sites and their sign-in"),
        Page("prices", "Prices", "Prices (under Billing and usage)"),
        Page("data", "Data and storage", "Data and storage"),
    ];

    /// <summary>Well-known links, for the articles' places.</summary>
    public static string SectionLink(string name) => $"{Scheme}section/{name}";

    public static string SettingsLink(string name) => $"{Scheme}settings/{name}";

    public static string ArticleLink(string id) => $"{Scheme}help/{id}";

    /// <summary>The place a link stands for: one of <see cref="Destinations"/>, or a Help article (its title as the label).</summary>
    public static HelpDestination? Find(string? link)
    {
        if (!TryParse(link, out var kind, out var name))
        {
            return null;
        }
        if (kind == "help")
        {
            return HelpContent.Articles.FirstOrDefault(a => a.Id == name) is { } article
                ? new HelpDestination(ArticleLink(article.Id), article.Title, $"Help (F1, or {GearMenu} → Help) → {article.Topic.Title} → {article.Title}.")
                : null;
        }
        var canonical = kind == "settings" && SettingsByLink.TryGetValue(name, out var page) && page == SettingsPages.Model ? SettingsLink("chat-model") : $"{Scheme}{kind}/{name.ToLowerInvariant()}";
        return Destinations.FirstOrDefault(d => d.Link == canonical)
            ?? (kind == "settings" && name.Equals("usage", StringComparison.OrdinalIgnoreCase) ? Destinations.First(d => d.Link == SectionLink("usage")) : null)
            ?? (kind == "section" && SectionsByLink.ContainsKey(name) ? new HelpDestination(canonical, name, "") : null);
    }

    /// <summary>
    /// Reads an <c>explorer:</c> link into its kind (section, settings or help) and name; false for anything else,
    /// and for a section, Settings page or article that does not exist.
    /// </summary>
    public static bool TryParse(string? link, out string kind, out string name)
    {
        kind = name = "";
        if (link is null || !link.StartsWith(Scheme, StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }
        var parts = link[Scheme.Length..].Trim().Trim('/').Split('/', 2);
        if (parts.Length != 2 || parts[1].Length == 0)
        {
            return false;
        }
        var id = parts[1];
        kind = parts[0].ToLowerInvariant();
        name = id;
        return kind switch
        {
            "section" => SectionsByLink.ContainsKey(id),
            "settings" => SettingsByLink.ContainsKey(id) || id.Equals("usage", StringComparison.OrdinalIgnoreCase),
            "help" => HelpContent.Articles.Any(a => a.Id == id),
            _ => false,
        };
    }

    /// <summary>
    /// Goes where the link points: the section (Repositories, with a word why, when it needs a repository and none is
    /// open), the Settings page, or the Help article. False when it is not an explorer link.
    /// </summary>
    public static bool Open(MainViewModel main, string? link)
    {
        if (!TryParse(link, out var kind, out var name))
        {
            return false;
        }
        main.CloseMenus();
        switch (kind)
        {
            case "section":
                var section = SectionsByLink[name];
                if (main.Workspace is null && section is Section.Documentation or Section.Graph or Section.Indexing or Section.Learning or Section.Studio or Section.Talk)
                {
                    main.ShowToast($"{Find(link)?.Label ?? name} belongs to a repository: open one here first.", false);
                }
                main.Navigate(section);
                break;
            case "settings" when name.Equals("usage", StringComparison.OrdinalIgnoreCase):
                main.Navigate(Section.Usage);
                break;
            case "settings":
                main.Navigate(Section.Settings);
                main.Settings.ShowPage(SettingsByLink[name]);
                break;
            case "help":
                main.Navigate(Section.Help);
                main.Help.Open(name);
                break;
        }
        return true;
    }
}
