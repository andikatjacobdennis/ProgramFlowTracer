using System.Windows.Input;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>The pages of Settings (one shows at a time, chosen in the sidebar).</summary>
public static class SettingsPages
{
    public const string Appearance = "appearance";
    public const string Voice = "voice";
    public const string Attachments = "attachments";
    public const string Model = "model";
    public const string Providers = "providers";
    public const string Skills = "skills";
    public const string Prices = "prices";
    public const string Data = "data";
    public const string Confluence = "confluence";
    public const string Shortcuts = "shortcuts";
    public const string Editing = "editing";

    public static readonly string[] All = [Appearance, Shortcuts, Editing, Voice, Attachments, Model, Providers, Skills, Confluence, Prices, Data];
}

/// <summary>One entry of the Settings sidebar: a page, or a link to another part of the explorer.</summary>
public sealed class SettingsNavItem : ObservableObject
{
    private bool _isSelected;
    private bool _hasBadge;

    public SettingsNavItem(string key, string title, string glyph, string description, Action<SettingsNavItem> select, bool isLink = false)
    {
        Key = key;
        Title = title;
        Glyph = glyph;
        Description = description;
        IsLink = isLink;
        SelectCommand = new RelayCommand(() => select(this));
    }

    public string Key { get; }
    public string Title { get; }
    public string Glyph { get; }

    /// <summary>The line under the page's heading.</summary>
    public string Description { get; }

    /// <summary>Opens another part of the explorer instead of a Settings page.</summary>
    public bool IsLink { get; }

    public bool IsSelected
    {
        get => _isSelected;
        set => Set(ref _isSelected, value);
    }

    /// <summary>A dot beside the title (unsaved changes on that page).</summary>
    public bool HasBadge
    {
        get => _hasBadge;
        set => Set(ref _hasBadge, value);
    }

    public ICommand SelectCommand { get; }
}

/// <summary>A group of the sidebar, with an optional heading (the first group has none, as on GitHub).</summary>
public sealed class SettingsNavGroup(string? heading, IReadOnlyList<SettingsNavItem> items)
{
    public string? Heading { get; } = heading;
    public bool HasHeading => !string.IsNullOrEmpty(Heading);
    public IReadOnlyList<SettingsNavItem> Items { get; } = items;
}
