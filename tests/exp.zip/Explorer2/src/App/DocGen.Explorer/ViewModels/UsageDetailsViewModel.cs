using System.Globalization;
using System.Windows.Input;
using System.Windows.Media;
using DocGen.Explorer.Controls;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>
/// Colours of the usage charts (the same feature or model keeps its colour across charts). Clear, distinct colours in every
/// theme, even the grey light one: on Token usage the colour is what tells input from output and one feature from another.
/// </summary>
public static class ChartPalette
{
    private static readonly string[] Colors = ["#2F6FED", "#F28C28", "#2EAD86", "#B35FD6", "#E0435A", "#14A5C4", "#C9A227", "#6B7A90", "#7A5CFA", "#3FA34D"];

    public static Brush At(int index)
    {
        var brush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(Colors[Math.Abs(index) % Colors.Length]));
        brush.Freeze();
        return brush;
    }

    public static readonly Brush Input = At(0);
    public static readonly Brush Output = At(1);

    // The summary cards' icons.
    public static readonly Brush Calls = At(5);
    public static readonly Brush Tokens = At(3);
    public static readonly Brush Cost = At(2);
    public static readonly Brush Failed = At(4);
}

/// <summary>A row of the calls table.</summary>
public sealed class UsageRowViewModel(UsageEntry entry, UsageViewModel owner)
{
    public UsageEntry Entry { get; } = entry;
    public DateTime At => Entry.At.ToLocalTime();
    public string Feature => Entry.Feature;
    public string ModelId => Entry.ModelId;
    public string Purpose => Entry.Purpose ?? (Entry.HasDetails ? "" : "—");
    public int InputTokens => Entry.InputTokens;
    public int OutputTokens => Entry.OutputTokens;
    public long DurationMs => Entry.DurationMs;
    public decimal Cost => Entry.Cost;
    public bool Failed => Entry.Failed;

    /// <summary>What the table shows under What for: why it failed, for a failed call.</summary>
    public string WhatFor => Failed
        ? "Failed: " + (string.IsNullOrWhiteSpace(Entry.Error) ? "no reason was recorded (older entry)" : Entry.Error.Split('\n')[0].Trim())
        : Purpose;

    public string ToolTip => Failed
        ? $"{Purpose}\n\n{Entry.Error ?? "No reason was recorded."}\n\nClick to see everything recorded about this call."
        : "See everything recorded about this call";

    /// <summary>The colours its feature and model have in the charts.</summary>
    public Brush FeatureBrush { get; set; } = Brushes.Gray;
    public Brush ModelBrush { get; set; } = Brushes.Gray;

    public ICommand OpenCommand => new RelayCommand(() => owner.OpenDetails(this));
}

/// <summary>One message of a call, as the details window lists it.</summary>
public sealed class UsageMessageViewModel(UsageMessage message, int number)
{
    public string Heading => $"{number}. {char.ToUpperInvariant(message.Role[0])}{message.Role[1..]}";
    public string Size => $"{message.Chars:N0} characters · about {message.ApproxTokens:N0} tokens";
    public string Preview => message.Preview + (message.Preview.Length < message.Chars ? $"\n… ({message.Chars - message.Preview.Length:N0} more characters)" : "");
    public string Role => message.Role;
}

/// <summary>Everything recorded about one model call, for the details window.</summary>
public sealed class UsageDetailsViewModel
{
    private readonly UsageEntry _entry;

    public UsageDetailsViewModel(UsageEntry entry, string? repositoryName, string? providerName)
    {
        _entry = entry;
        RepositoryName = repositoryName;
        ProviderName = providerName;
        Messages = (entry.Messages ?? []).Select((m, i) => new UsageMessageViewModel(m, i + 1)).ToList();
        CopyCommand = new RelayCommand(() =>
        {
            if (Ui.Copy(System.Text.Json.JsonSerializer.Serialize(entry, DocGen.Core.Json.DocGenJson.Storage)))
            {
                Ui.Notify("The call's record copied as JSON.");
            }
        });
    }

    private static readonly CultureInfo Culture = CultureInfo.CurrentCulture;

    public string Title => $"{_entry.Feature} · {_entry.ModelId}";
    public string When => $"{_entry.At.ToLocalTime():dddd d MMMM yyyy, HH:mm:ss} (UTC {_entry.At:HH:mm:ss})";
    public bool Failed => _entry.Failed;
    public string Status => _entry.Failed ? "Failed" : _entry.FinishReason is "length" or "max_tokens" ? "Stopped at the output limit" : "Succeeded";
    public string? Error => _entry.Error;
    public bool HasError => !string.IsNullOrWhiteSpace(_entry.Error);
    public bool HasDetails => _entry.HasDetails;

    public string Purpose => _entry.Purpose ?? (HasDetails ? "(not stated)" : "Details are recorded for calls made from this version on; this call was made before.");

    public string FeatureMeaning => _entry.Feature switch
    {
        "assistant" => "The assistant answering a question in the Ask panel.",
        "talk" => "A persona answering in Talk.",
        "rewrite" => "Rewriting a question before it was asked (Rewrite).",
        "understand" => "Reading a question before the search: what it asks for, which part of the code it means, and whether to ask back.",
        "intent" => "A quick check of whether a short message is conversation (a short reply) or a question about the code.",
        "summarise" => "Summarising a selection or a diagram.",
        "diagram-repair" => "Fixing a Mermaid diagram that could not be drawn (Settings → Chat model → attempts).",
        "describe-graph" => "Writing one-line descriptions of graph concepts while indexing.",
        "graph-groups" => "Naming and checking the groups of the knowledge graph (Group with AI).",
        "graph-scope" => "Reading a \"Show only\" request on the Graph page.",
        "studio" => "Writing a Studio conversation between personas.",
        "refine" => "Refining a Studio topic.",
        "learning" => "Writing learning material (paths, quizzes, flashcards, FAQ).",
        "help" => "Help answering a question about using the explorer, from Help's own articles.",
        "test" => "Testing the model from Settings → Providers and models.",
        _ => "",
    };

    public string? RepositoryName { get; }
    public string Repository => _entry.RepositoryId is null ? "None (not about a repository)" : $"{RepositoryName ?? "(removed)"}  ·  {_entry.RepositoryId}";
    public string? ProviderName { get; }
    public string Provider => string.IsNullOrEmpty(ProviderName) || ProviderName == _entry.ProviderId ? _entry.ProviderId : $"{ProviderName} ({_entry.ProviderId})";
    public string Model => _entry.ProviderModelId is { } providerModel ? $"{_entry.ModelId} (sent as {providerModel})" : _entry.ModelId;
    public string CallId => _entry.Id;

    // The numbers.
    public string InputTokens => _entry.InputTokens.ToString("N0", Culture);
    public string OutputTokens => _entry.OutputTokens.ToString("N0", Culture);
    public string CachedTokens => _entry.CachedInputTokens.ToString("N0", Culture);
    public string TotalTokens => _entry.TotalTokens.ToString("N0", Culture);
    public string Duration => _entry.DurationMs >= 1000 ? $"{_entry.DurationMs / 1000.0:0.0} s" : $"{_entry.DurationMs} ms";
    public string Speed => _entry.DurationMs > 0 && _entry.OutputTokens > 0 ? $"{_entry.OutputTokens / (_entry.DurationMs / 1000.0):0} tokens/s" : "—";
    public string Cost => _entry.InputPricePerMillion is { } input && _entry.OutputPricePerMillion is { } output
        ? $"{_entry.Cost:0.0000}  ({_entry.InputTokens:N0} × {input} + {_entry.OutputTokens:N0} × {output} per million)"
        : _entry.Cost > 0 ? _entry.Cost.ToString("0.0000", Culture) : "No price set for this model (Settings → Prices)";
    public string FinishReason => _entry.FinishReason ?? "—";
    public string MaxOutput => _entry.MaxOutputTokens?.ToString("N0", Culture) ?? "—";
    public string Temperature => _entry.Temperature?.ToString("0.##", Culture) ?? "model default";
    public string Delivery => _entry.Streamed ? "Streamed" : "Single response";
    public string Reasoning => _entry.ReasoningChars > 0 ? $"{_entry.ReasoningChars:N0} characters of reasoning before the answer" : "—";
    public string ResponseSize => _entry.ResponseChars > 0 ? $"{_entry.ResponseChars:N0} characters" : "—";

    public IReadOnlyList<UsageMessageViewModel> Messages { get; }
    public bool HasMessages => Messages.Count > 0;
    public string MessagesHeading => $"WHAT WAS SENT — {Messages.Count} MESSAGE{(Messages.Count == 1 ? "" : "S")}";
    public string? Response => _entry.Response is null ? null : _entry.Response + (_entry.Response.Length < _entry.ResponseChars ? $"\n… ({_entry.ResponseChars - _entry.Response.Length:N0} more characters)" : "");
    public bool HasResponse => !string.IsNullOrEmpty(_entry.Response);

    public ICommand CopyCommand { get; }
}
