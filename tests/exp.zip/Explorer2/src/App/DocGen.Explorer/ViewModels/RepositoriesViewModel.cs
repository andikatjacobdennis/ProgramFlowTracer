using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows.Input;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

public sealed class RepositoryCardViewModel(RepositoryRecord record, RepositoriesViewModel owner) : ObservableObject
{
    public RepositoryRecord Record { get; private set; } = record;
    public string Title => Record.Title;
    public string Path => Record.Source == "git" ? Record.GitUrl ?? Record.Path : Record.Path;
    public string StatusText => Record.Status switch
    {
        RepositoryStatus.Indexed => "Indexed",
        RepositoryStatus.Indexing => "Indexing",
        RepositoryStatus.Failed => "Failed",
        _ => "Not indexed",
    };
    public string StatusKey => Record.Status.ToString();
    public string Files => Record.Counters.Files.ToString("N0");
    public string Chunks => Record.Counters.Chunks.ToString("N0");
    public string GraphNodes => Record.Counters.GraphNodes.ToString("N0");
    public string OkfEntities => Record.Counters.OkfEntities.ToString("N0");
    public string LastIndexed => Record.LastIndexedAt is { } at ? at.ToLocalTime().ToString("d MMM yyyy, HH:mm") : "Never";
    public string? Error => Record.Error;
    public bool IsGit => Record.Source == "git";
    public string SourceGlyph => IsGit ? Icons.Git : Icons.Code;
    public string SourceText => IsGit ? "Cloned from Git" : "Local folder";
    public string SourceTip => IsGit
        ? $"Cloned from {Record.GitUrl} into the explorer's data folder:\n{Record.Path}"
        : $"Indexed from the folder as it is on disk:\n{Record.Path}";
    public string? Branch => Record.Branch;
    public bool HasBranch => IsGit && !string.IsNullOrEmpty(Record.Branch);

    private string? _busyText;

    /// <summary>What the card is doing (reading branches, switching), shown with a small progress ring.</summary>
    public string? BusyText
    {
        get => _busyText;
        set
        {
            if (Set(ref _busyText, value))
            {
                Notify(nameof(IsBusy));
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    public bool IsBusy => _busyText is not null;

    public ICommand ChangeBranchCommand => new AsyncCommand(() => owner.ChangeBranchAsync(this), () => IsGit && !IsBusy);

    public ICommand OpenCommand => new AsyncCommand(() => owner.Main.OpenRepositoryAsync(Record, Section.Documentation));
    public ICommand GraphCommand => new AsyncCommand(() => owner.Main.OpenRepositoryAsync(Record, Section.Graph));
    public ICommand IndexingCommand => new AsyncCommand(() => owner.Main.OpenRepositoryAsync(Record, Section.Indexing));
    public ICommand RemoveCommand => new AsyncCommand(() => owner.RemoveAsync(this));
    public ICommand RenameCommand => new AsyncCommand(() => owner.RenameAsync(this));
    public ICommand ReindexCommand => new AsyncCommand(async () =>
    {
        _ = owner.Main.Engine.Indexing.StartAsync(Record.Id, IndexMode.Full);
        await owner.RefreshAsync();
    });
    public ICommand RevealCommand => new RelayCommand(() =>
    {
        if (Directory.Exists(Record.Path))
        {
            Process.Start(new ProcessStartInfo("explorer.exe", $"\"{Record.Path}\"") { UseShellExecute = true });
        }
    });
}

/// <summary>The landing page: registered repositories, their totals, filters and the add form.</summary>
public sealed class RepositoriesViewModel : ObservableObject, IActivatable
{
    private string _search = "";
    private RepositoryFilter _filter = RepositoryFilter.All;
    private RepositorySort _sort = RepositorySort.LastIndexed;
    private string _addMode = "local";
    private string _localPath = "";
    private string _displayName = "";
    private string _gitUrl = "";
    private string _gitBranch = "";
    private string? _addStatus;
    private bool _isAdding;
    private bool _focusAdd;
    private List<RepositoryCardViewModel> _all = [];

    public RepositoriesViewModel(MainViewModel main)
    {
        Main = main;
        AddLocalCommand = new AsyncCommand(AddLocalAsync, () => !IsAdding && LocalPath.Trim().Length > 0);
        AddGitCommand = new AsyncCommand(AddGitAsync, () => !IsAdding && GitUrl.Trim().Length > 0);
        BrowseCommand = new RelayCommand(Browse);
        CreateFolderCommand = new AsyncCommand(CreateFolderAsync, () => !IsAdding && NewFolderName.Trim().Length > 0);
        BrowseLocationCommand = new RelayCommand(() => ChooseLocation());
        ShowAddFormCommand = new RelayCommand(() =>
        {
            AddOpen = true;
            FocusAdd = false;
            FocusAdd = true;
        });
        CloseAddCommand = new RelayCommand(() => AddOpen = false);
        RemoveAllCommand = new AsyncCommand(RemoveAllAsync, () => _all.Count > 0);
        SetFilterCommand = new RelayCommand(p =>
        {
            if (p is string s && Enum.TryParse<RepositoryFilter>(s, out var f))
            {
                Filter = f;
            }
        });
        main.Engine.Repositories.Changed += (_, _) => Ui.Post(() => _ = RefreshAsync());
    }

    public MainViewModel Main { get; }

    public ICommand AddLocalCommand { get; }
    public ICommand AddGitCommand { get; }
    public ICommand BrowseCommand { get; }
    public ICommand CreateFolderCommand { get; }
    public ICommand BrowseLocationCommand { get; }

    private string _newFolderName = "";
    private string _newFolderLocation = DefaultLocation();
    private bool _newFolderGit = true;

    /// <summary>New folder: its name.</summary>
    public string NewFolderName
    {
        get => _newFolderName;
        set => Set(ref _newFolderName, value);
    }

    /// <summary>New folder: where it is created (asked when left empty).</summary>
    public string NewFolderLocation
    {
        get => _newFolderLocation;
        set => Set(ref _newFolderLocation, value);
    }

    /// <summary>New folder: start an empty Git repository in it.</summary>
    public bool NewFolderGit
    {
        get => _newFolderGit;
        set => Set(ref _newFolderGit, value);
    }

    /// <summary>Where new folders go first: source\repos when there is one (Visual Studio's), otherwise Documents.</summary>
    private static string DefaultLocation()
    {
        var repos = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "source", "repos");
        return Directory.Exists(repos) ? repos : Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
    }
    public ICommand ShowAddFormCommand { get; }
    public ICommand CloseAddCommand { get; }

    private bool _addOpen;

    /// <summary>The add form was opened (with repositories registered it is closed until asked for).</summary>
    public bool AddOpen
    {
        get => _addOpen;
        set
        {
            if (Set(ref _addOpen, value))
            {
                Notify(nameof(ShowAddPanel), nameof(ShowAddButton));
            }
        }
    }

    /// <summary>The add form shows when there is nothing yet, or when Add repository was pressed.</summary>
    public bool ShowAddPanel => IsEmpty || AddOpen;

    /// <summary>One way to add at a time: the button only while the form is closed.</summary>
    public bool ShowAddButton => !ShowAddPanel;
    public ICommand RemoveAllCommand { get; }
    public ICommand SetFilterCommand { get; }

    public ObservableCollection<RepositoryCardViewModel> Cards { get; } = [];

    public IReadOnlyList<RepositoryCardViewModel> All => _all;

    public bool IsEmpty => _all.Count == 0;
    public bool HasRepositories => _all.Count > 0;
    public bool NoMatches => _all.Count > 0 && Cards.Count == 0;

    public string TotalRepositories => _all.Count.ToString("N0");
    public string TotalRepositoriesLabel => _all.Count == 1 ? "Repository" : "Repositories";
    public string TotalFiles => _all.Sum(c => (long)c.Record.Counters.Files).ToString("N0");
    public string TotalNodes => _all.Sum(c => (long)c.Record.Counters.GraphNodes).ToString("N0");
    public string TotalChunks => _all.Sum(c => (long)c.Record.Counters.Chunks).ToString("N0");
    public int CountAll => _all.Count;
    public int CountIndexed => _all.Count(c => c.Record.Status == RepositoryStatus.Indexed);
    public int CountIndexing => _all.Count(c => c.Record.Status == RepositoryStatus.Indexing);
    public int CountFailed => _all.Count(c => c.Record.Status == RepositoryStatus.Failed);

    public string Search
    {
        get => _search;
        set
        {
            if (Set(ref _search, value))
            {
                ApplyFilter();
            }
        }
    }

    public RepositoryFilter Filter
    {
        get => _filter;
        set
        {
            if (Set(ref _filter, value))
            {
                ApplyFilter();
            }
        }
    }

    public IReadOnlyList<KeyValuePair<RepositorySort, string>> SortOptions { get; } =
    [
        new(RepositorySort.LastIndexed, "Last indexed"),
        new(RepositorySort.Name, "Name"),
        new(RepositorySort.Files, "Most files"),
        new(RepositorySort.Added, "Recently added"),
    ];

    public RepositorySort Sort
    {
        get => _sort;
        set
        {
            if (Set(ref _sort, value))
            {
                ApplyFilter();
            }
        }
    }

    public string AddMode
    {
        get => _addMode;
        set
        {
            if (Set(ref _addMode, value))
            {
                AddStatus = null;
            }
        }
    }

    public string LocalPath
    {
        get => _localPath;
        set => Set(ref _localPath, value);
    }

    public string DisplayName
    {
        get => _displayName;
        set => Set(ref _displayName, value);
    }

    public string GitUrl
    {
        get => _gitUrl;
        set => Set(ref _gitUrl, value);
    }

    public string GitBranch
    {
        get => _gitBranch;
        set => Set(ref _gitBranch, value);
    }

    public string? AddStatus
    {
        get => _addStatus;
        set => Set(ref _addStatus, value);
    }

    public bool IsAdding
    {
        get => _isAdding;
        set => Set(ref _isAdding, value);
    }

    public bool FocusAdd
    {
        get => _focusAdd;
        set => Set(ref _focusAdd, value);
    }

    public Task ActivateAsync()
    {
        // Coming back to the page: the add form is closed again unless it is asked for (Add repository… in the menus).
        AddOpen = false;
        return RefreshAsync();
    }

    public async Task RefreshAsync()
    {
        var records = await Main.Engine.Repositories.ListAsync();
        // Clones made before branches were recorded: read the branch from Git once (local, quick).
        foreach (var record in records.Where(r => r.Source == "git" && r.Branch is null))
        {
            await Main.Engine.Repositories.CurrentBranchAsync(record);
        }
        _all = records.Select(r => new RepositoryCardViewModel(r, this)).ToList();
        ApplyFilter();
        Notify(nameof(ShowAddPanel), nameof(ShowAddButton));
        Notify(nameof(IsEmpty), nameof(HasRepositories), nameof(TotalRepositories), nameof(TotalRepositoriesLabel), nameof(TotalFiles), nameof(TotalNodes),
            nameof(TotalChunks), nameof(CountAll), nameof(CountIndexed), nameof(CountIndexing), nameof(CountFailed), nameof(All));
    }

    private void ApplyFilter()
    {
        var filtered = RepositoryService.Filter(_all.Select(c => c.Record), Search, Filter, Sort).Select(r => _all.First(c => c.Record.Id == r.Id)).ToList();
        Cards.Clear();
        foreach (var card in filtered)
        {
            Cards.Add(card);
        }
        OnPropertyChanged(nameof(NoMatches));
    }

    private void Browse()
    {
        var dialog = new Microsoft.Win32.OpenFolderDialog { Title = "Choose the repository folder", Multiselect = false };
        if (dialog.ShowDialog() == true)
        {
            LocalPath = dialog.FolderName;
        }
    }

    /// <summary>Asks where to create the new folder; false when the dialog was cancelled.</summary>
    private bool ChooseLocation()
    {
        var dialog = new Microsoft.Win32.OpenFolderDialog { Title = "Choose where to create the repository folder", Multiselect = false };
        if (Directory.Exists(NewFolderLocation))
        {
            dialog.InitialDirectory = NewFolderLocation;
        }
        if (dialog.ShowDialog() != true)
        {
            return false;
        }
        NewFolderLocation = dialog.FolderName;
        return true;
    }

    private async Task CreateFolderAsync()
    {
        if (NewFolderLocation.Trim().Length == 0 && !ChooseLocation())
        {
            return;
        }
        IsAdding = true;
        AddStatus = "Creating the folder…";
        try
        {
            var (record, git) = await Main.Engine.Repositories.CreateLocalAsync(NewFolderLocation, NewFolderName, NewFolderGit);
            _ = Main.Engine.Indexing.StartAsync(record.Id, IndexMode.Full);
            AddStatus = $"Created {record.Path}" + (NewFolderGit && !git ? " (Git is not installed, so it is a plain folder)." : ".");
            NewFolderName = "";
            await RefreshAsync();
            AddOpen = false;
            await Main.OpenRepositoryAsync(record, Section.Documentation);
            Ui.Notify(AddStatus);
        }
        catch (ExplorerValidationException ex)
        {
            AddStatus = ex.Message;
        }
        finally
        {
            IsAdding = false;
        }
    }

    private async Task AddLocalAsync()
    {
        IsAdding = true;
        AddStatus = "Adding…";
        try
        {
            var record = await Main.Engine.Repositories.AddLocalAsync(LocalPath, DisplayName);
            _ = Main.Engine.Indexing.StartAsync(record.Id, IndexMode.Full);
            AddStatus = $"Added {record.Title}; indexing has started.";
            LocalPath = DisplayName = "";
            await RefreshAsync();
            AddOpen = false;
            await Main.OpenRepositoryAsync(record, Section.Documentation);
        }
        catch (ExplorerValidationException ex)
        {
            AddStatus = ex.Message;
        }
        finally
        {
            IsAdding = false;
        }
    }

    private async Task AddGitAsync()
    {
        IsAdding = true;
        AddStatus = "Cloning…";
        try
        {
            var progress = new Progress<string>(line => AddStatus = Engine.Text.TextUtil.Truncate(line, 140));
            var record = await Main.Engine.Repositories.AddGitAsync(GitUrl, DisplayName, GitBranch, progress);
            _ = Main.Engine.Indexing.StartAsync(record.Id, IndexMode.Full);
            AddStatus = $"Cloned {record.Title}; indexing has started.";
            GitUrl = GitBranch = DisplayName = "";
            await RefreshAsync();
            AddOpen = false;
            await Main.OpenRepositoryAsync(record, Section.Documentation);
        }
        catch (ExplorerValidationException ex)
        {
            AddStatus = ex.Message;
        }
        finally
        {
            IsAdding = false;
        }
    }

    public async Task RemoveAsync(RepositoryCardViewModel card)
    {
        var confirmed = await Main.ConfirmAsync($"Remove {card.Title}?",
            "This deletes its index, graph, conversations and attachments. This cannot be undone. The folder itself is left alone.",
            card.Path, "Remove");
        if (!confirmed)
        {
            return;
        }
        await Main.Engine.RemoveRepositoryAsync(card.Record.Id);
        Main.ForgetWorkspace(card.Record.Id);
        await RefreshAsync();
        Main.ShowToast($"Removed {card.Title}.", false);
    }

    /// <summary>Switches a clone to another branch, then reindexes it from that branch.</summary>
    public async Task ChangeBranchAsync(RepositoryCardViewModel card)
    {
        var repositories = Main.Engine.Repositories;
        if (Main.Engine.Indexing.IsRunning(card.Record.Id))
        {
            Main.ShowToast($"{card.Title} is being indexed; change the branch when it has finished.", isError: true);
            return;
        }
        IReadOnlyList<string> names = [];
        string? note = null;
        string? current;
        card.BusyText = "Reading the branches…";
        try
        {
            current = await repositories.CurrentBranchAsync(card.Record);
            try
            {
                var remote = await repositories.ListBranchesAsync(card.Record);
                names = remote.Names;
                note = names.Count == 0 ? "The remote lists no branches; type the name." : $"{names.Count} branch{(names.Count == 1 ? "" : "es")} on the remote" + (remote.Default is null ? "" : $" ({remote.Default} is the default)") + ".";
            }
            catch (ExplorerValidationException ex)
            {
                note = "The branches could not be listed (" + ex.Message.Split('\n')[0] + "). Type the branch name.";
            }
        }
        finally
        {
            card.BusyText = null;
        }
        var chosen = await Main.PromptAsync($"Change the branch of {card.Title}",
            "Branch", current ?? "", "Switch and reindex",
            message: (current is null ? "" : $"Now on {current}. ") + "The clone is switched to the branch you choose and the repository is fully reindexed from it — documentation, graph and search then describe that branch.",
            choices: names, choicesNote: note);
        chosen = chosen?.Trim();
        if (string.IsNullOrEmpty(chosen) || chosen == current)
        {
            return;
        }
        card.BusyText = $"Switching to {chosen}…";
        try
        {
            var progress = new Progress<string>(line => card.BusyText = Engine.Text.TextUtil.Truncate(line, 80));
            await repositories.SwitchBranchAsync(card.Record.Id, chosen, progress);
            _ = Main.Engine.Indexing.StartAsync(card.Record.Id, IndexMode.Full);
            Main.ShowToast($"{card.Title} is now on {chosen}; reindexing has started.", isError: false);
        }
        catch (ExplorerValidationException ex)
        {
            Main.ShowToast(ex.Message, isError: true);
        }
        finally
        {
            card.BusyText = null;
        }
        await RefreshAsync();
    }

    public async Task RenameAsync(RepositoryCardViewModel card)
    {
        var name = await Main.PromptAsync("Rename repository", "Display name (leave empty for the folder name)", card.Record.DisplayName ?? "");
        if (name is null)
        {
            return;
        }
        await Main.Engine.Repositories.RenameAsync(card.Record.Id, name);
        await RefreshAsync();
    }

    private async Task RemoveAllAsync()
    {
        var confirmed = await Main.ConfirmAsync("Remove every repository?",
            $"This deletes the index, graph, conversations and learning material of all {_all.Count} repositories. This cannot be undone. Their folders are left alone.",
            null, "Remove all");
        if (!confirmed)
        {
            return;
        }
        var ids = _all.Select(c => c.Record.Id).ToList();
        await Main.Engine.RemoveAllRepositoriesAsync();
        foreach (var id in ids)
        {
            Main.ForgetWorkspace(id);
        }
        await RefreshAsync();
    }
}
