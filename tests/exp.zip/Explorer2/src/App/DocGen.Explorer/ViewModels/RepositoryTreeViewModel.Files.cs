using System.Diagnostics;
using System.Windows.Input;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>A line of a file's or folder's tooltip: "Size", "4.2 KB (4,301 bytes)".</summary>
public sealed record DetailRow(string Label, string Value)
{
    public bool HasLabel => Label.Length > 0;
}

public sealed partial class TreeNodeViewModel
{
    private IReadOnlyList<DetailRow>? _details;
    private DateTime _detailsAt;

    /// <summary>The file or folder on disk this node stands for (relative to the repository), or null (a generated page).</summary>
    public string? DiskPath => Kind switch
    {
        TreeNodeKind.Page => SourcePath is { Length: > 0 } source && !IsGeneratedPage ? source.Replace('\\', '/') : null,
        TreeNodeKind.Folder => Tree.FolderOnDisk(this) ? Path : null,
        _ => Path,
    };

    /// <summary>A reference page made from the code (Overview, Architecture, API…), with no file of its own.</summary>
    public bool IsGeneratedPage { get; init; }

    public bool IsOnDisk => DiskPath is not null;
    public bool IsFolder => Kind == TreeNodeKind.Folder;
    public bool IsLeaf => Kind != TreeNodeKind.Folder;

    /// <summary>Files can be added, renamed, edited and deleted here (Settings → Reading and writing).</summary>
    public bool CanModify => UiPreferences.Current.AllowFileEditing && IsOnDisk;
    public bool CanEditText => CanModify && IsLeaf;
    public bool IsMarkdownFile => Kind == TreeNodeKind.File && (Path.EndsWith(".md", StringComparison.OrdinalIgnoreCase) || Path.EndsWith(".markdown", StringComparison.OrdinalIgnoreCase));

    /// <summary>The tooltip's details, read from disk when it opens (and again after half a minute).</summary>
    public IReadOnlyList<DetailRow> Details
    {
        get
        {
            if (_details is null || (DateTime.UtcNow - _detailsAt).TotalSeconds > 30)
            {
                _details = Tree.DetailsOf(this);
                _detailsAt = DateTime.UtcNow;
            }
            return _details;
        }
    }

    public string DetailsTitle => Kind == TreeNodeKind.Page && SourcePath is null ? Name : System.IO.Path.GetFileName(DiskPath ?? Path) is { Length: > 0 } n ? n : Name;

    public ICommand OpenCommand => new RelayCommand(() => Tree.Activate(this));
    public ICommand EditCommand => new RelayCommand(() => Tree.Edit(this), () => CanEditText);
    public ICommand PreviewCommand => new RelayCommand(() => Tree.Preview(this), () => IsMarkdownFile);
    public ICommand NewFileCommand => new AsyncCommand(() => Tree.NewFileAsync(this), () => CanModify);
    public ICommand NewFolderCommand => new AsyncCommand(() => Tree.NewFolderAsync(this), () => CanModify);
    public ICommand RenameCommand => new AsyncCommand(() => Tree.RenameAsync(this), () => CanModify);
    public ICommand DeleteCommand => new AsyncCommand(() => Tree.DeleteAsync(this), () => CanModify);
    public ICommand CopyPathCommand => new RelayCommand(() => Tree.CopyPath(this, full: false), () => IsOnDisk);
    public ICommand CopyFullPathCommand => new RelayCommand(() => Tree.CopyPath(this, full: true), () => IsOnDisk);
    public ICommand RevealCommand => new RelayCommand(() => Tree.Reveal(this), () => IsOnDisk);
    public ICommand OpenExternallyCommand => new RelayCommand(() => Tree.OpenExternally(this), () => IsOnDisk && IsLeaf);
}

public sealed partial class RepositoryTreeViewModel
{
    private string Root => _workspace.Record.Path;

    public ICommand NewFileAtRootCommand => new AsyncCommand(() => NewFileAsync(null), () => UiPreferences.Current.AllowFileEditing);
    public ICommand NewFolderAtRootCommand => new AsyncCommand(() => NewFolderAsync(null), () => UiPreferences.Current.AllowFileEditing);
    public bool CanAddFiles => UiPreferences.Current.AllowFileEditing;

    internal bool FolderOnDisk(TreeNodeViewModel node)
    {
        try
        {
            return node.Path.Length > 0 && Directory.Exists(FileScanner.SafeResolve(Root, node.Path));
        }
        catch (Exception ex) when (ex is UnauthorizedAccessException or ArgumentException or NotSupportedException or IOException)
        {
            return false;
        }
    }

    internal IReadOnlyList<DetailRow> DetailsOf(TreeNodeViewModel node)
    {
        if (node.DiskPath is not { } path)
        {
            // A page made from the code: what it is, not a file.
            var page = node.PageId is null ? null : _workspace.Index?.FindPage(node.PageId);
            return
            [
                new("", "Generated from the code index (no file of its own)."),
                new("Page", page?.TreePath ?? node.Path),
                .. page is null ? Array.Empty<DetailRow>() : [new DetailRow("Headings", page.Headings.Count.ToString(System.Globalization.CultureInfo.InvariantCulture))],
            ];
        }
        if (!UiPreferences.Current.DetailedFileTips)
        {
            return [new("Path", path)];
        }
        var language = node.Kind == TreeNodeKind.Folder ? null : _workspace.Index?.FindFile(path)?.Language ?? IngestionFilters.LanguageOf(path);
        return RepositoryFiles.Details(Root, path, language).Rows().Select(r => new DetailRow(r.Label, r.Value)).ToList();
    }

    /// <summary>The folder a new file or folder goes into: the node itself when a folder, else the folder it is in.</summary>
    private static string FolderFor(TreeNodeViewModel? node)
    {
        if (node?.DiskPath is not { } path)
        {
            return "";
        }
        if (node.IsFolder)
        {
            return path;
        }
        var slash = path.LastIndexOf('/');
        return slash < 0 ? "" : path[..slash];
    }

    internal void Edit(TreeNodeViewModel node)
    {
        if (node.DiskPath is { } path)
        {
            _workspace.Main.Navigate(Section.Documentation);
            _workspace.Documentation.BeginEdit(path);
        }
    }

    /// <summary>A Markdown file from the Files tab: shown rendered, as its page.</summary>
    internal void Preview(TreeNodeViewModel node)
    {
        if (_workspace.Index?.PageForSource(node.Path) is { } page)
        {
            _workspace.Main.Navigate(Section.Documentation);
            _workspace.Documentation.OpenPage(page.Id, null);
        }
        else if (node.DiskPath is { } path)
        {
            // Not a page yet (new, or not indexed): its editor, on the Preview tab.
            Edit(node);
            _workspace.Documentation.EditTab = "preview";
        }
    }

    internal async Task NewFileAsync(TreeNodeViewModel? at)
    {
        var folder = FolderFor(at);
        var name = await _workspace.Main.PromptAsync("New file", $"File name, in {(folder.Length == 0 ? "the repository root" : folder)} (use / for new sub-folders)",
            "new-page.md", "Create");
        if (string.IsNullOrWhiteSpace(name))
        {
            return;
        }
        try
        {
            var relative = RepositoryFiles.Combine(folder, name);
            RepositoryFiles.CreateFile(Root, relative, relative.EndsWith(".md", StringComparison.OrdinalIgnoreCase) ? $"# {System.IO.Path.GetFileNameWithoutExtension(relative)}\n\n" : "");
            Logging.Info($"Created {relative}.");
            AddFileNode(relative);
            _workspace.Main.Navigate(Section.Documentation);
            _workspace.Documentation.BeginEdit(relative, isNew: true);
            _workspace.Documentation.QueueReindex();
        }
        catch (Exception ex) when (ex is ExplorerValidationException or IOException or UnauthorizedAccessException)
        {
            _workspace.Main.ShowToast(ex.Message, true);
        }
    }

    internal async Task NewFolderAsync(TreeNodeViewModel? at)
    {
        var folder = FolderFor(at);
        var name = await _workspace.Main.PromptAsync("New folder", $"Folder name, in {(folder.Length == 0 ? "the repository root" : folder)}", "", "Create");
        if (string.IsNullOrWhiteSpace(name))
        {
            return;
        }
        try
        {
            var relative = RepositoryFiles.Combine(folder, name);
            RepositoryFiles.CreateFolder(Root, relative);
            Logging.Info($"Created the folder {relative}.");
            var node = EnsureFolder(FilesRoots, null, relative.Split('/'), null);
            for (var p = node; p is not null; p = p.Parent)
            {
                p.IsExpanded = true;
            }
            Tab = "files";
            _workspace.Main.ShowToast($"Created the folder {relative}. Add a file to it (right-click it → New file).", false);
        }
        catch (Exception ex) when (ex is ExplorerValidationException or IOException or UnauthorizedAccessException)
        {
            _workspace.Main.ShowToast(ex.Message, true);
        }
    }

    internal async Task RenameAsync(TreeNodeViewModel node)
    {
        if (node.DiskPath is not { } path)
        {
            return;
        }
        var current = System.IO.Path.GetFileName(path);
        var name = await _workspace.Main.PromptAsync(node.IsFolder ? "Rename folder" : "Rename file", "New name", current, "Rename");
        if (string.IsNullOrWhiteSpace(name) || name.Trim() == current)
        {
            return;
        }
        if (!await _workspace.Documentation.CloseEditAsync(reopen: false))
        {
            return;
        }
        try
        {
            var renamed = RepositoryFiles.Rename(Root, path, name.Trim());
            Logging.Info($"Renamed {path} to {renamed}.");
            RemoveNode(node);
            if (!node.IsFolder)
            {
                AddFileNode(renamed);
            }
            _workspace.Main.ShowToast($"Renamed to {name.Trim()}. The index is updating.", false);
            _workspace.Documentation.QueueReindex();
        }
        catch (Exception ex) when (ex is ExplorerValidationException or IOException or UnauthorizedAccessException)
        {
            _workspace.Main.ShowToast(ex.Message, true);
        }
    }

    internal async Task DeleteAsync(TreeNodeViewModel node)
    {
        if (node.DiskPath is not { } path)
        {
            return;
        }
        var full = FileScanner.SafeResolve(Root, path);
        var what = node.IsFolder ? $"the folder '{path}' and everything in it" : $"'{path}'";
        if (!await _workspace.Main.ConfirmAsync(node.IsFolder ? "Delete folder?" : "Delete file?", $"Delete {what}?",
                "It goes to the Recycle Bin, where you can restore it.", "Delete"))
        {
            return;
        }
        try
        {
            if (_workspace.Documentation.Mode == "edit" && _workspace.Documentation.EditPath.StartsWith(path, StringComparison.OrdinalIgnoreCase))
            {
                await _workspace.Documentation.CloseEditAsync(reopen: false);
            }
            if (node.IsFolder)
            {
                Microsoft.VisualBasic.FileIO.FileSystem.DeleteDirectory(full, Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs, Microsoft.VisualBasic.FileIO.RecycleOption.SendToRecycleBin);
            }
            else
            {
                Microsoft.VisualBasic.FileIO.FileSystem.DeleteFile(full, Microsoft.VisualBasic.FileIO.UIOption.OnlyErrorDialogs, Microsoft.VisualBasic.FileIO.RecycleOption.SendToRecycleBin);
            }
            Logging.Info($"Deleted {path} (to the Recycle Bin).");
            RemoveNode(node);
            _workspace.Main.ShowToast($"Deleted {System.IO.Path.GetFileName(path)} (it is in the Recycle Bin). The index is updating.", false);
            _workspace.Documentation.QueueReindex();
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or OperationCanceledException)
        {
            _workspace.Main.ShowToast($"Could not delete it: {ex.Message}", true);
        }
    }

    internal void CopyPath(TreeNodeViewModel node, bool full)
    {
        if (node.DiskPath is { } path && Ui.Copy(full ? FileScanner.SafeResolve(Root, path) : path))
        {
            Ui.Notify("Path copied.");
        }
    }

    internal void Reveal(TreeNodeViewModel node)
    {
        if (node.DiskPath is { } path)
        {
            var full = FileScanner.SafeResolve(Root, path);
            Process.Start(new ProcessStartInfo("explorer.exe", node.IsFolder ? $"\"{full}\"" : $"/select,\"{full}\"") { UseShellExecute = true });
        }
    }

    internal void OpenExternally(TreeNodeViewModel node)
    {
        if (node.DiskPath is { } path && File.Exists(FileScanner.SafeResolve(Root, path)))
        {
            Process.Start(new ProcessStartInfo(FileScanner.SafeResolve(Root, path)) { UseShellExecute = true });
        }
    }

    /// <summary>Shows a new file in the Files tab at once (the index adds it a moment later).</summary>
    private void AddFileNode(string relative)
    {
        var segments = relative.Split('/');
        var parent = EnsureFolder(FilesRoots, null, segments[..^1], null);
        var collection = parent?.Children ?? FilesRoots;
        if (collection.Any(n => n.Kind == TreeNodeKind.File && string.Equals(n.Path, relative, StringComparison.OrdinalIgnoreCase)))
        {
            return;
        }
        var node = new TreeNodeViewModel(this, parent, segments[^1], TreeNodeKind.File, relative, segments.Length - 1) { SourcePath = relative };
        // In order: folders first, then files by name.
        var at = 0;
        while (at < collection.Count && (collection[at].Kind == TreeNodeKind.Folder || string.Compare(collection[at].Name, node.Name, StringComparison.OrdinalIgnoreCase) < 0))
        {
            at++;
        }
        collection.Insert(at, node);
        for (var p = parent; p is not null; p = p.Parent)
        {
            p.IsExpanded = true;
        }
        FilesCount++;
        OnPropertyChanged(nameof(FilesCount));
    }

    private void RemoveNode(TreeNodeViewModel node)
    {
        foreach (var roots in new[] { DocsRoots, FilesRoots, FilterResults })
        {
            Remove(roots, node.DiskPath ?? node.Path, node.Kind);
        }

        static void Remove(System.Collections.ObjectModel.ObservableCollection<TreeNodeViewModel> nodes, string path, TreeNodeKind kind)
        {
            foreach (var n in nodes.ToList())
            {
                var p = n.DiskPath ?? n.Path;
                if (string.Equals(p, path, StringComparison.OrdinalIgnoreCase) || p.StartsWith(path + "/", StringComparison.OrdinalIgnoreCase))
                {
                    nodes.Remove(n);
                    continue;
                }
                Remove(n.Children, path, kind);
            }
        }
    }
}
