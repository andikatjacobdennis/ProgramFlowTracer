using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows.Input;
using DocGen.Explorer.Engine.Export;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

public sealed class Breadcrumb(string text, ICommand? command)
{
    public string Text { get; } = text;
    public ICommand? Command { get; } = command;
    public bool IsLink => Command is not null;
    public bool IsLast { get; set; }
}

public sealed class OutlineItem(string anchor, string text, int level) : ObservableObject
{
    private bool _isActive;

    public string Anchor { get; } = anchor;
    public string Text { get; } = text;
    public int Level { get; } = level;
    public System.Windows.Thickness Indent => new((Level - 2) * 14, 0, 0, 0);

    public bool IsActive
    {
        get => _isActive;
        set => Set(ref _isActive, value);
    }
}

/// <summary>A place in the documentation: a page (with an optional anchor) or a file (with an optional line).</summary>
public sealed record DocLocation(string? PageId, string? FilePath, string? Anchor, int Line);

/// <summary>The Documentation page: a documentation page or a source file, its tools, outline and history.</summary>
public sealed partial class DocumentationViewModel : ObservableObject, IActivatable
{
    private readonly WorkspaceViewModel _workspace;
    private readonly Stack<DocLocation> _back = new();
    private readonly Stack<DocLocation> _forward = new();
    private DocLocation? _current;
    private string _mode = "empty";
    private DocPage? _page;
    private string? _markdown;
    private ScannedFile? _file;
    private string[] _lines = [];
    private bool _wrap;
    private bool _folded;
    private bool _outlineExpanded = true;

    public DocumentationViewModel(WorkspaceViewModel workspace)
    {
        _workspace = workspace;
        CopyLinkCommand = new RelayCommand(CopyLink);
        CopyMarkdownCommand = new RelayCommand(() => { if (_markdown is not null && Ui.Copy(_markdown)) { Ui.Notify("Markdown copied."); } });
        DownloadCommand = new AsyncCommand(DownloadAsync);
        ExportCommand = new AsyncCommand(p => ExportAsync(p as string ?? "docx-page"));
        CopyFileCommand = new RelayCommand(() => { if (Ui.Copy(string.Join(Environment.NewLine, _lines))) { Ui.Notify("File copied."); } });
        DownloadFileCommand = new AsyncCommand(DownloadFileAsync);
        ToggleWrapCommand = new RelayCommand(() => Wrap = !Wrap);
        ToggleFoldCommand = new RelayCommand(() =>
        {
            Folded = !Folded;
            FoldRequested?.Invoke(this, Folded);
        });
        OpenExternallyCommand = new RelayCommand(OpenExternally);
        RevealCommand = new RelayCommand(Reveal);
        GoToAnchorCommand = new RelayCommand(p => { if (p is string anchor) { ScrollToAnchor(anchor); } });
        ToggleOutlineCommand = new RelayCommand(() => OutlineExpanded = !OutlineExpanded);
        IndexNowCommand = new RelayCommand(() =>
        {
            // Start the run in the background (do not wait for it), then show its progress.
            _ = workspace.Main.Engine.Indexing.StartAsync(workspace.Record.Id, IndexMode.Full);
            OnIndexingProgress(null, "Starting");
            workspace.Main.Navigate(Section.Indexing);
        }, () => !IsIndexing);
        OpenIndexingCommand = new RelayCommand(() => workspace.Main.Navigate(Section.Indexing));
        AskAboutCommand = new RelayCommand(AskAbout);

        var pipeline = workspace.Main.Engine.Indexing;
        pipeline.Progress += (_, e) =>
        {
            if (e.RepositoryId != workspace.Record.Id)
            {
                return;
            }
            var running = e.Run.Stages.FirstOrDefault(s => s.Status == StageStatus.Running)?.Name;
            var progress = e.Run.Progress * 100;
            Ui.Post(() => OnIndexingProgress(progress, running));
        };
        pipeline.Completed += (_, e) =>
        {
            if (e.RepositoryId == workspace.Record.Id)
            {
                Ui.Post(() => OnIndexingProgress(null, null));
            }
        };
    }

    private bool _isIndexing;
    private double _indexingProgress;
    private string _indexingStage = "";

    public ICommand OpenIndexingCommand { get; }

    /// <summary>A run is in progress for this repository (the "not indexed" state shows its progress instead of "Index now").</summary>
    public bool IsIndexing
    {
        get => _isIndexing;
        private set
        {
            if (Set(ref _isIndexing, value))
            {
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    public double IndexingProgress
    {
        get => _indexingProgress;
        private set => Set(ref _indexingProgress, value);
    }

    public string IndexingStage
    {
        get => _indexingStage;
        private set => Set(ref _indexingStage, value);
    }

    private void OnIndexingProgress(double? progress, string? stage)
    {
        IsIndexing = _workspace.Main.Engine.Indexing.IsRunning(_workspace.Record.Id) || stage == "Starting";
        if (progress is { } p)
        {
            IndexingProgress = p;
        }
        IndexingStage = stage is null or "Starting" ? "Starting…" : $"{stage}…";
    }

    public ICommand CopyLinkCommand { get; }
    public ICommand CopyMarkdownCommand { get; }
    public ICommand DownloadCommand { get; }
    public ICommand ExportCommand { get; }
    public ICommand CopyFileCommand { get; }
    public ICommand DownloadFileCommand { get; }
    public ICommand ToggleWrapCommand { get; }
    public ICommand ToggleFoldCommand { get; }
    public ICommand OpenExternallyCommand { get; }
    public ICommand RevealCommand { get; }
    public ICommand GoToAnchorCommand { get; }
    public ICommand ToggleOutlineCommand { get; }
    public ICommand IndexNowCommand { get; }
    public ICommand AskAboutCommand { get; }

    /// <summary>Raised when a page should be rendered (the view builds the FlowDocument).</summary>
    public event EventHandler? PageChanged;

    /// <summary>Raised when a file should be shown (with the line to go to).</summary>
    public event EventHandler<int>? FileChanged;

    public event EventHandler<string>? AnchorRequested;
    public event EventHandler<bool>? FoldRequested;

    public WorkspaceViewModel Workspace => _workspace;

    /// <summary>What shows without an index: "loading" while it is read from disk, else "notindexed".</summary>
    private string Missing => _workspace.IsLoading ? "loading" : "notindexed";

    /// <summary>page | file | edit | empty | notindexed | loading</summary>
    public string Mode
    {
        get => _mode;
        private set => Set(ref _mode, value);
    }

    public DocPage? Page => _page;
    public string? Markdown => _markdown;
    public string PageTitle => _page?.Title ?? "";
    public bool PageIsGenerated => _page?.Generated == true;
    public string PageSourceText => _page?.SourcePath is { } source ? source : "Generated from the code index";

    public ObservableCollection<Breadcrumb> Breadcrumbs { get; } = [];
    public ObservableCollection<OutlineItem> Outline { get; } = [];
    public bool HasOutline => Outline.Count > 0;

    public bool OutlineExpanded
    {
        get => _outlineExpanded;
        set => Set(ref _outlineExpanded, value);
    }

    public ScannedFile? File => _file;
    public string[] Lines => _lines;
    public string FileName => _file?.Name ?? "";
    public string FileLanguage => _file?.Language ?? "";
    public string FileLength => _file is null ? "" : Engine.Text.TextUtil.Plural(_lines.Length, "line");
    public string FilePath => _file?.Path ?? "";
    public bool FileHasPage => _file is not null && _workspace.Index?.PageForSource(_file.Path) is not null;

    public bool Wrap
    {
        get => _wrap;
        set
        {
            if (Set(ref _wrap, value))
            {
                OnPropertyChanged(nameof(WrapTooltip));
            }
        }
    }

    public string WrapTooltip => Wrap ? "Do not wrap long lines" : "Wrap long lines";

    public bool Folded
    {
        get => _folded;
        set
        {
            if (Set(ref _folded, value))
            {
                Notify(nameof(FoldTooltip), nameof(FoldGlyph));
            }
        }
    }

    public string FoldTooltip => Folded ? "Expand every block" : "Collapse every block";
    public string FoldGlyph => Folded ? Icons.UnfoldAll : Icons.FoldAll;

    public bool CanGoBack => _back.Count > 0;
    public bool CanGoForward => _forward.Count > 0;

    public Task ActivateAsync()
    {
        IsIndexing = _workspace.Main.Engine.Indexing.IsRunning(_workspace.Record.Id);
        if (IsIndexing && _workspace.Main.Engine.Indexing.CurrentRun(_workspace.Record.Id) is { } run)
        {
            IndexingProgress = run.Progress * 100;
            IndexingStage = (run.Stages.FirstOrDefault(s => s.Status == StageStatus.Running)?.Name ?? "Starting") + "…";
        }
        if (_workspace.Index is null)
        {
            Mode = Missing;
        }
        else if (_current is null)
        {
            OpenDefault();
        }
        return Task.CompletedTask;
    }

    public void OnIndexChanged()
    {
        var index = _workspace.Index;
        if (Mode is "edit" or "diff")
        {
            // The index caught up (a saved file re-indexed): the editor, or the diff being read or edited, stays as it is.
            Notify(nameof(CanEdit));
            return;
        }
        if (index is null)
        {
            Mode = Missing;
            return;
        }
        // Re-open what was open (it may have changed), or the default page.
        if (_current is { PageId: { } pageId } && index.FindPage(pageId) is not null)
        {
            ShowPage(pageId, _current.Anchor);
        }
        else if (_current is { FilePath: { } path } && index.FindFile(path) is not null)
        {
            ShowFile(path, _current.Line);
        }
        else
        {
            _current = null;
            OpenDefault();
        }
    }

    private void OpenDefault()
    {
        var index = _workspace.Index;
        if (index is null)
        {
            Mode = Missing;
            return;
        }
        var page = index.Pages.FirstOrDefault(p => p.SourcePath is { } s && s.Equals("README.md", StringComparison.OrdinalIgnoreCase))
                   ?? index.Pages.FirstOrDefault(p => !p.Generated)
                   ?? index.Pages.FirstOrDefault();
        if (page is not null)
        {
            OpenPage(page.Id, null, addHistory: false);
        }
        else
        {
            Mode = "empty";
        }
    }

    public void OpenPage(string pageId, string? anchor, bool addHistory = true)
    {
        if (_workspace.Index?.FindPage(pageId) is null)
        {
            _workspace.Main.ShowToast("That page is not in the index any more.", true);
            return;
        }
        if (addHistory)
        {
            Push();
        }
        ShowPage(pageId, anchor);
    }

    public void OpenFile(string path, int line, bool addHistory = true)
    {
        if (_workspace.Index?.FindFile(path) is null)
        {
            // A Confluence chunk or a removed file: open its URL if the evidence has one.
            var chunk = _workspace.Index?.Chunks.FirstOrDefault(c => c.Path == path && c.Url is not null);
            if (chunk?.Url is { } url)
            {
                _workspace.OpenLink(url);
                return;
            }
            _workspace.Main.ShowToast($"'{path}' is not in the index.", true);
            return;
        }
        if (addHistory)
        {
            Push();
        }
        ShowFile(path, line);
    }

    private void Push()
    {
        if (_current is not null)
        {
            _back.Push(_current);
            _forward.Clear();
        }
        CommandManager.InvalidateRequerySuggested();
    }

    public void Back()
    {
        if (_back.Count == 0)
        {
            return;
        }
        if (_current is not null)
        {
            _forward.Push(_current);
        }
        Go(_back.Pop());
    }

    public void Forward()
    {
        if (_forward.Count == 0)
        {
            return;
        }
        if (_current is not null)
        {
            _back.Push(_current);
        }
        Go(_forward.Pop());
    }

    private void Go(DocLocation location)
    {
        if (location.PageId is not null)
        {
            ShowPage(location.PageId, location.Anchor);
        }
        else if (location.FilePath is not null)
        {
            ShowFile(location.FilePath, location.Line);
        }
        CommandManager.InvalidateRequerySuggested();
    }

    /// <summary>Counts what was opened: a page read in the background shows only if nothing was opened meanwhile.</summary>
    private int _opened;

    private async void ShowPage(string pageId, string? anchor)
    {
        var index = _workspace.Index!;
        var page = index.FindPage(pageId)!;
        var opened = ++_opened;
        _current = new DocLocation(pageId, null, anchor, 0);
        _page = page;
        _file = null;
        var markdown = await _workspace.Main.Engine.Indexing.ReadPageMarkdownAsync(index, page) ?? $"# {page.Title}\n\n_The page's file could not be read._";
        if (opened != _opened)
        {
            return; // something else was opened (the editor, another page) while this one was read
        }
        _markdown = markdown;
        Breadcrumbs.Clear();
        Breadcrumbs.Add(new Breadcrumb(_workspace.Title, new RelayCommand(OpenDefault)));
        // As the Docs list shows it: the file and its folders as named on disk (generated pages by their place in Reference).
        var segments = (!page.Generated && page.SourcePath is { Length: > 0 } source ? source.Replace('\\', '/') : page.TreePath).Split('/');
        for (var i = 0; i < segments.Length - 1; i++)
        {
            Breadcrumbs.Add(new Breadcrumb(segments[i], null));
        }
        Breadcrumbs.Add(new Breadcrumb(segments[^1], null) { IsLast = true });
        Outline.Clear();
        foreach (var heading in page.Headings.Where(h => h.Level is >= 2 and <= 3))
        {
            Outline.Add(new OutlineItem(heading.Anchor, heading.Text, heading.Level));
        }
        Mode = "page";
        Notify(nameof(Page), nameof(Markdown), nameof(PageTitle), nameof(PageIsGenerated), nameof(PageSourceText), nameof(HasOutline), nameof(File), nameof(CanEdit));
        _workspace.Tree.Sync(pageId, null);
        PageChanged?.Invoke(this, EventArgs.Empty);
        if (anchor is not null)
        {
            AnchorRequested?.Invoke(this, anchor);
        }
    }

    private void ShowFile(string path, int line)
    {
        var index = _workspace.Index!;
        var file = index.FindFile(path)!;
        var text = index.ReadText(path);
        if (text is null)
        {
            _workspace.Main.ShowToast($"'{path}' could not be read (it may have been moved or deleted since indexing).", true);
            return;
        }
        _opened++;
        _current = new DocLocation(null, path, null, line);
        _file = file;
        _page = null;
        _markdown = null;
        _lines = Engine.Text.TextUtil.SplitLines(text);
        if (_lines.Length > 1 && _lines[^1].Length == 0)
        {
            _lines = _lines[..^1];
        }
        Breadcrumbs.Clear();
        Breadcrumbs.Add(new Breadcrumb(_workspace.Title, new RelayCommand(OpenDefault)));
        Breadcrumbs.Add(new Breadcrumb(path, null) { IsLast = true });
        Outline.Clear();
        Folded = false;
        Mode = "file";
        ShowClassDiagram = false;
        ShowPreview = false;
        Notify(nameof(File), nameof(Lines), nameof(FileName), nameof(FileLanguage), nameof(FileLength), nameof(FilePath), nameof(FileHasPage), nameof(HasOutline), nameof(Page),
            nameof(CanShowClassDiagram), nameof(CanPreviewMarkdown), nameof(CanEdit), nameof(FileDetailsText));
        _workspace.Tree.Sync(null, path);
        FileChanged?.Invoke(this, line);
    }

    public void ScrollToAnchor(string anchor)
    {
        if (Mode == "page")
        {
            AnchorRequested?.Invoke(this, anchor);
            if (_current is not null)
            {
                _current = _current with { Anchor = anchor };
            }
        }
    }

    public void SetActiveAnchor(string? anchor)
    {
        foreach (var item in Outline)
        {
            item.IsActive = item.Anchor == anchor;
        }
    }

    private void CopyLink()
    {
        string link;
        if (_page is not null)
        {
            var active = Outline.FirstOrDefault(o => o.IsActive)?.Anchor;
            link = (_page.SourcePath ?? "page:" + _page.Id) + (active is null ? "" : "#" + active);
        }
        else if (_file is not null)
        {
            link = _file.Path;
        }
        else
        {
            return;
        }
        if (Ui.Copy(link))
        {
            Ui.Notify("Link copied: " + link);
        }
    }

    public void CopyLineLink(int line)
    {
        if (_file is not null && Ui.Copy($"{_file.Path}#L{line}"))
        {
            Ui.Notify($"Link copied: {_file.Path}#L{line}");
        }
    }

    public void CopyAnchorLink(string anchor)
    {
        if (_page is not null && Ui.Copy((_page.SourcePath ?? "page:" + _page.Id) + "#" + anchor))
        {
            Ui.Notify("Link to the section copied.");
        }
    }

    private static string? SaveDialog(string fileName, string filter)
    {
        var dialog = new Microsoft.Win32.SaveFileDialog { FileName = fileName, Filter = filter, AddExtension = true };
        return dialog.ShowDialog() == true ? dialog.FileName : null;
    }

    private static string SafeName(string name) => string.Concat(name.Select(c => Path.GetInvalidFileNameChars().Contains(c) ? '-' : c)).Trim();

    private async Task DownloadAsync()
    {
        if (_page is null || _markdown is null)
        {
            return;
        }
        var path = SaveDialog(SafeName(_page.Title) + ".md", "Markdown (*.md)|*.md");
        if (path is not null)
        {
            await System.IO.File.WriteAllTextAsync(path, _markdown);
            Ui.Notify("Saved " + Path.GetFileName(path));
        }
    }

    private async Task ExportAsync(string kind)
    {
        var index = _workspace.Index;
        if (index is null)
        {
            return;
        }
        var all = kind.EndsWith("-all", StringComparison.Ordinal);
        var pdf = kind.StartsWith("pdf", StringComparison.Ordinal);
        if (!all && _page is null)
        {
            return;
        }
        var title = all ? $"{_workspace.Title} documentation" : _page!.Title;
        var path = SaveDialog(SafeName(title) + (pdf ? ".pdf" : ".docx"), pdf ? "PDF document (*.pdf)|*.pdf" : "Word document (*.docx)|*.docx");
        if (path is null)
        {
            return;
        }
        var documents = new List<ExportDocument>();
        if (all)
        {
            // What the Docs list shows, in its order: the reference pages only when Docs lists them.
            foreach (var page in index.ShownPages().OrderBy(p => p.Generated).ThenBy(p => p.SourcePath ?? p.TreePath, StringComparer.OrdinalIgnoreCase))
            {
                if (await _workspace.Main.Engine.Indexing.ReadPageMarkdownAsync(index, page) is { } markdown)
                {
                    documents.Add(new ExportDocument(page.Title, markdown));
                }
            }
        }
        else
        {
            documents.Add(new ExportDocument(_page!.Title, _markdown ?? ""));
        }
        // Word shows the diagrams as pictures (drawn here); PDF keeps their source.
        IReadOnlyDictionary<string, DiagramImage>? drawn = null;
        if (!pdf)
        {
            var diagrams = documents.SelectMany(d => ResponseExporter.MermaidDiagrams(d.Markdown)).Distinct().ToList();
            if (diagrams.Count > 0)
            {
                _workspace.Main.ShowToast($"Drawing {(diagrams.Count == 1 ? "the diagram" : $"{diagrams.Count} diagrams")} for the document…", false);
                drawn = await Controls.DiagramPictures.DrawAsync(diagrams);
            }
        }
        var bytes = await Task.Run(() => pdf ? PdfWriter.Write(documents, title) : DocxWriter.Write(documents, title, drawn));
        await System.IO.File.WriteAllBytesAsync(path, bytes);
        _workspace.Main.ShowToast($"Exported {documents.Count} page{(documents.Count == 1 ? "" : "s")} to {Path.GetFileName(path)}.", false);
    }

    private async Task DownloadFileAsync()
    {
        if (_file is null)
        {
            return;
        }
        var path = SaveDialog(_file.Name, "All files (*.*)|*.*");
        if (path is not null)
        {
            var source = FileScanner.SafeResolve(_workspace.Record.Path, _file.Path);
            await using var input = System.IO.File.OpenRead(source);
            await using var output = System.IO.File.Create(path);
            await input.CopyToAsync(output);
            Ui.Notify("Saved " + Path.GetFileName(path));
        }
    }

    private string? CurrentFullPath()
    {
        var relative = _file?.Path ?? _page?.SourcePath;
        return relative is null ? null : FileScanner.SafeResolve(_workspace.Record.Path, relative);
    }

    private void OpenExternally()
    {
        if (CurrentFullPath() is { } full && System.IO.File.Exists(full))
        {
            Process.Start(new ProcessStartInfo(full) { UseShellExecute = true });
        }
    }

    private void Reveal()
    {
        if (CurrentFullPath() is { } full && System.IO.File.Exists(full))
        {
            Process.Start(new ProcessStartInfo("explorer.exe", $"/select,\"{full}\"") { UseShellExecute = true });
        }
    }

    private void AskAbout()
    {
        var subject = _file is not null ? _file.Path : _page?.Title;
        if (subject is null)
        {
            return;
        }
        _workspace.Main.AssistantVisible = true;
        _workspace.Assistant.Input = _file is not null ? $"Explain {_file.Name}: what it is responsible for and how it fits in." : $"Summarise the page \"{_page!.Title}\" and what it implies for the code.";
        _workspace.Assistant.FocusInput = false;
        _workspace.Assistant.FocusInput = true;
    }
}
