using System.Windows.Input;
using System.Windows.Threading;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>
/// Editing in the diff, as in Visual Studio: the right side becomes your working copy, editable in place, and the
/// comparison follows as you type — the whole file, the original on the left with what you removed in red, yours on the
/// right with what you added in green. Save (Ctrl+S) writes the file; Close leaves the editing (asking first when unsaved).
/// </summary>
public sealed partial class DocumentationViewModel
{
    private bool _diffEditing;
    private string _diffBaseText = "";
    private string _diffEditText = "";
    private string _diffEditOriginal = "";
    private DateTime _diffEditModified;
    private DispatcherTimer? _diffEditTimer;
    private IReadOnlyList<DiffLine> _editedDiff = [];
    private int[] _newToOld = [];
    private int[] _oldToNew = [];
    private int _editAdded;
    private int _editRemoved;

    /// <summary>Raised when the comparison of the edited text changed (the view redraws both sides).</summary>
    public event EventHandler? DiffEditChanged;

    /// <summary>The right side is the working copy, being edited.</summary>
    public bool IsDiffEditing => _diffEditing;

    public bool IsNotDiffEditing => !_diffEditing;

    /// <summary>A working-tree change (not staged, not between branches, not deleted): its file can be edited in the diff.</summary>
    public bool CanEditDiffInline => CanEditDiff && _diff is { Change.Staged: false };

    public string DiffEditorText
    {
        get => _diffEditText;
        set
        {
            if (!Set(ref _diffEditText, value ?? ""))
            {
                return;
            }
            Notify(nameof(IsDiffEditDirty), nameof(DiffEditStatus));
            _diffEditTimer ??= NewDiffEditTimer();
            _diffEditTimer.Stop();
            _diffEditTimer.Start();
        }
    }

    public bool IsDiffEditDirty => _diffEditing && !string.Equals(_diffEditText, _diffEditOriginal, StringComparison.Ordinal);

    /// <summary>"Unsaved changes · compared as you type" or "Saved".</summary>
    public string DiffEditStatus => !_diffEditing ? "" : IsDiffEditDirty ? "Unsaved changes · compared as you type" : "No unsaved changes";

    /// <summary>The original, every line, the removed ones marked, numbered as it was.</summary>
    public IReadOnlyList<(string Text, string Kind, string Label)> DiffEditOldSide => _editedDiff
        .Where(l => l.Kind != DiffLineKind.Added)
        .Select(l => (l.Text, l.Kind == DiffLineKind.Removed ? "Removed" : "", l.OldNumber?.ToString(System.Globalization.CultureInfo.InvariantCulture) ?? ""))
        .ToList();

    /// <summary>How each line of the edited text compares: "Added" for a line that is not in the original, else "".</summary>
    public IReadOnlyList<string> DiffEditMarks { get; private set; } = [];

    /// <summary>The line of the original beside a line of the edited text (0-based), to keep the two sides level.</summary>
    public int OldLineFor(int newLine) => _newToOld.Length == 0 ? 0 : _newToOld[Math.Clamp(newLine, 0, _newToOld.Length - 1)];

    /// <summary>The line of the edited text beside a line of the original (0-based).</summary>
    public int NewLineFor(int oldLine) => _oldToNew.Length == 0 ? 0 : _oldToNew[Math.Clamp(oldLine, 0, _oldToNew.Length - 1)];

    public ICommand SaveDiffEditCommand => new AsyncCommand(SaveDiffEditAsync, () => _diffEditing);

    public ICommand CloseDiffEditCommand => new AsyncCommand(async () => await CloseDiffEditAsync(), () => _diffEditing);

    /// <summary>Makes the right side editable: reads the working copy and the version it is compared with.</summary>
    public async Task BeginDiffEditAsync()
    {
        if (_diff is not { } diff || !CanEditDiffInline || _diffEditing)
        {
            return;
        }
        if (!UiPreferences.Current.AllowFileEditing)
        {
            _workspace.Main.ShowToast("Editing files is turned off (Settings → Reading and writing).", true);
            return;
        }
        string text;
        DateTime modified;
        try
        {
            var full = FileScanner.SafeResolve(_workspace.Record.Path, diff.Change.Path);
            text = System.IO.File.ReadAllText(full).Replace("\r\n", "\n", StringComparison.Ordinal);
            modified = System.IO.File.GetLastWriteTimeUtc(full);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ExplorerValidationException)
        {
            _workspace.Main.ShowToast($"'{diff.Change.Path}' could not be opened: {ex.Message}", true);
            return;
        }
        var baseText = await GitChanges.BaseTextAsync(_workspace.Record.Path, diff.Change, CancellationToken.None);
        if (baseText is null)
        {
            _workspace.Main.ShowToast("git could not show the version this file is compared with.", true);
            return;
        }
        if (!ReferenceEquals(_diff, diff) || Mode != "diff")
        {
            return; // something else was opened meanwhile
        }
        _diffBaseText = baseText;
        _diffEditOriginal = text;
        _diffEditText = text;
        _diffEditModified = modified;
        _diffEditing = true;
        SideBySide = true;
        CompareEdited();
        NotifyDiffEditing();
        Logging.Info($"Editing {diff.Change.Path} in its diff.");
    }

    private async Task SaveDiffEditAsync()
    {
        if (_diff is not { } diff || !_diffEditing)
        {
            return;
        }
        var path = diff.Change.Path;
        try
        {
            if (!RepositoryFiles.Save(_workspace.Record.Path, path, _diffEditText, _diffEditModified == default ? null : _diffEditModified))
            {
                var overwrite = await _workspace.Main.ConfirmAsync("The file changed on disk", $"'{path}' was changed outside Explorer after you started editing it.",
                    "Saving replaces those changes with yours.", "Save mine");
                if (!overwrite)
                {
                    return;
                }
                RepositoryFiles.Save(_workspace.Record.Path, path, _diffEditText, overwrite: true);
            }
            _diffEditModified = System.IO.File.GetLastWriteTimeUtc(FileScanner.SafeResolve(_workspace.Record.Path, path));
            _diffEditOriginal = _diffEditText;
            Notify(nameof(IsDiffEditDirty), nameof(DiffEditStatus));
            Ui.Notify($"Saved {Path.GetFileName(path)}.");
            Logging.Info($"Saved {path} from its diff.");
            QueueReindex();
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ExplorerValidationException)
        {
            _workspace.Main.ShowToast($"Could not save: {ex.Message}", true);
        }
    }

    /// <summary>Leaves the editing (asking first when there are unsaved changes) and compares again with what is on disk; true when it closed.</summary>
    public async Task<bool> CloseDiffEditAsync(bool refresh = true)
    {
        if (!_diffEditing)
        {
            return true;
        }
        if (IsDiffEditDirty && !await _workspace.Main.ConfirmAsync("Discard your changes?", $"'{DiffPath}' has changes that are not saved.", null, "Discard"))
        {
            return false;
        }
        EndDiffEdit();
        if (refresh)
        {
            await RefreshDiffAsync();
        }
        return true;
    }

    private void EndDiffEdit()
    {
        _diffEditTimer?.Stop();
        if (!_diffEditing)
        {
            return;
        }
        _diffEditing = false;
        _editedDiff = [];
        _newToOld = [];
        _oldToNew = [];
        DiffEditMarks = [];
        NotifyDiffEditing();
    }

    private DispatcherTimer NewDiffEditTimer()
    {
        var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(250) };
        timer.Tick += (_, _) =>
        {
            timer.Stop();
            if (_diffEditing)
            {
                CompareEdited();
                Notify(nameof(DiffAdded), nameof(DiffRemoved), nameof(DiffEditMarks));
                DiffEditChanged?.Invoke(this, EventArgs.Empty);
            }
        };
        return timer;
    }

    /// <summary>Compares the edited text with the original, line by line, and maps each side's lines to the other's.</summary>
    private void CompareEdited()
    {
        _editedDiff = LineDiff.Compare(_diffBaseText, _diffEditText);
        var marks = new List<string>();
        var newToOld = new List<int>();
        var oldToNew = new List<int>();
        int oldSeen = 0, newSeen = 0;
        foreach (var line in _editedDiff)
        {
            switch (line.Kind)
            {
                case DiffLineKind.Added:
                    marks.Add("Added");
                    newToOld.Add(oldSeen);
                    newSeen++;
                    break;
                case DiffLineKind.Removed:
                    oldToNew.Add(newSeen);
                    oldSeen++;
                    break;
                default:
                    marks.Add("");
                    newToOld.Add(oldSeen);
                    oldToNew.Add(newSeen);
                    oldSeen++;
                    newSeen++;
                    break;
            }
        }
        // The editor always has a line (an empty or newline-ended text shows one more than LineDiff counts).
        marks.Add("");
        newToOld.Add(oldSeen);
        DiffEditMarks = marks;
        _newToOld = [.. newToOld];
        _oldToNew = [.. oldToNew];
        _editAdded = _editedDiff.Count(l => l.Kind == DiffLineKind.Added);
        _editRemoved = _editedDiff.Count(l => l.Kind == DiffLineKind.Removed);
    }

    private void NotifyDiffEditing()
    {
        Notify(nameof(IsDiffEditing), nameof(IsNotDiffEditing), nameof(DiffEditorText), nameof(IsDiffEditDirty), nameof(DiffEditStatus), nameof(DiffEditMarks),
            nameof(DiffAdded), nameof(DiffRemoved), nameof(DiffSidesText), nameof(SaveDiffEditCommand), nameof(CloseDiffEditCommand), nameof(SaveEditCommand));
        CommandManager.InvalidateRequerySuggested();
        DiffEditChanged?.Invoke(this, EventArgs.Empty);
    }
}
