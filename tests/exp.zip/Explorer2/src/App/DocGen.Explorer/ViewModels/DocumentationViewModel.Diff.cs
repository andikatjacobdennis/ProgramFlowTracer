using System.Windows.Input;
using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>One side of a diff row: its line number, text and kind (Context, Added, Removed, Hunk, Note, or Filler for no line).</summary>
public sealed record DiffCell(string Number, string Text, string Kind)
{
    public static readonly DiffCell Filler = new("", "", "Filler");
}

/// <summary>A row of the diff: inline uses Left only (with both numbers in it); side by side pairs the old line with the new.</summary>
public sealed record DiffRow(DiffCell Left, DiffCell Right, string OldNumber, string NewNumber, string Marker, string Kind);

/// <summary>A change's diff in the Documentation area, side by side or inline, as Visual Studio shows it.</summary>
public sealed partial class DocumentationViewModel
{
    private FileDiff? _diff;
    private bool _sideBySide = true;

    public FileDiff? Diff => _diff;

    public string DiffFileName => _diff?.Change.FileName ?? "";

    public string DiffPath => _diff?.Change.Path ?? "";

    public string DiffKind => _diff is null ? "" : _diff.Change.KindText + (_diff.Change.Staged ? " · staged" : "");

    public string DiffLetter => _diff?.Change.Letter ?? "";

    public string DiffKindName => _diff?.Change.Kind.ToString() ?? "";

    public string DiffAdded => _diff is null ? "" : $"+{(_diffEditing ? _editAdded : _diff.Added):N0}";

    public string DiffRemoved => _diff is null ? "" : $"−{(_diffEditing ? _editRemoved : _diff.Removed):N0}";

    public string DiffRenamedFrom => _diff?.Change.OldPath is { } old ? $"Renamed from {old}" : "";

    public IReadOnlyList<DiffRow> DiffRows { get; private set; } = [];

    private bool _editFromDiff;

    /// <summary>Raised when the diff to show changed (the view loads its code views).</summary>
    public event EventHandler? DiffChanged;

    /// <summary>The language of the file compared, for syntax colours.</summary>
    public string? DiffLanguage => _diff is null ? null : _workspace.Index?.FindFile(_diff.Change.Path)?.Language;

    /// <summary>The old side (the last commit, the staged version, or the base branch), line by line, for a code view.</summary>
    public IReadOnlyList<(string Text, string Kind, string Label)> DiffOldSide => DiffRows.Select(r => (r.Left.Text, r.Left.Kind, r.Left.Number)).ToList();

    /// <summary>The new side (the working tree, or the compared branch).</summary>
    public IReadOnlyList<(string Text, string Kind, string Label)> DiffNewSide => DiffRows.Select(r => (r.Right.Text, r.Right.Kind, r.Right.Number)).ToList();

    /// <summary>The inline diff: removed and added lines one under the other, labelled "− 12", "+ 13" or "  14".</summary>
    public IReadOnlyList<(string Text, string Kind, string Label)> DiffInlineLines => DiffRows.Select(r => (r.Left.Text, r.Kind, r.Kind switch
    {
        "Added" => "+ " + r.NewNumber,
        "Removed" => "− " + r.OldNumber,
        "Hunk" or "Note" => "",
        _ => "  " + r.NewNumber,
    })).ToList();

    /// <summary>The change can be edited here (a file in the working tree that still exists).</summary>
    public bool CanEditDiff => _diff is { Change: { IsBranchComparison: false, Kind: not GitChangeKind.Deleted } };

    /// <summary>The change can be undone (a change in the working tree, not one between branches).</summary>
    public bool CanUndoDiff => _diff is { Change.IsBranchComparison: false };

    public string UndoDiffText => _diff?.Change switch
    {
        { Kind: GitChangeKind.Untracked } => "Delete file",
        { Staged: true } => "Unstage",
        _ => "Undo changes",
    };

    public string DiffSidesText => _diff?.Change switch
    {
        _ when _diffEditing => "Compared with your edits as you type",
        { Range: { } range } => $"{range.Replace("...", " → ")}",
        { Staged: true } => "Last commit → staged",
        { Kind: GitChangeKind.Untracked } => "New file",
        _ => "Last commit → working copy",
    };

    /// <summary>
    /// Edit: a working-tree change is edited right here, in the diff's right side; a staged one opens its working copy in
    /// the editor, and closing that comes back to the diff, compared again.
    /// </summary>
    public ICommand EditDiffFileCommand => new RelayCommand(() =>
    {
        if (CanEditDiffInline)
        {
            _ = BeginDiffEditAsync();
        }
        else if (_diff is { } d && CanEditDiff)
        {
            _editFromDiff = true;
            BeginEdit(d.Change.Path);
            if (Mode != "edit")
            {
                _editFromDiff = false;
            }
        }
    }, () => CanEditDiff && !_diffEditing);

    public ICommand UndoDiffCommand => new RelayCommand(() =>
    {
        if (_diff is { } d)
        {
            _ = _workspace.Tree.UndoChangeAsync(d.Change);
        }
    }, () => CanUndoDiff && !_diffEditing);

    public bool SideBySide
    {
        get => _sideBySide;
        set
        {
            if (Set(ref _sideBySide, value))
            {
                BuildDiffRows();
                Notify(nameof(Inline));
            }
        }
    }

    public bool Inline
    {
        get => !_sideBySide;
        set => SideBySide = !value;
    }

    public ICommand OpenDiffFileCommand => new RelayCommand(() =>
    {
        if (_diff is { Change.Kind: not GitChangeKind.Deleted } d)
        {
            OpenFile(d.Change.Path, 0);
        }
    }, () => _diff is { Change.Kind: not GitChangeKind.Deleted });

    public ICommand RefreshDiffCommand => new RelayCommand(() => _ = RefreshDiffAsync());

    /// <summary>Shows a file's diff in place of the page.</summary>
    public void ShowDiff(FileDiff diff)
    {
        EndDiffEdit();
        _opened++;
        _diff = diff;
        BuildDiffRows();
        Breadcrumbs.Clear();
        Breadcrumbs.Add(new Breadcrumb(_workspace.Title, new RelayCommand(OpenDefault)));
        Breadcrumbs.Add(new Breadcrumb("Changes", new RelayCommand(() => _workspace.Tree.Tab = "changes")));
        Breadcrumbs.Add(new Breadcrumb(diff.Change.Path, null) { IsLast = true });
        Outline.Clear();
        Mode = "diff";
        Notify(nameof(Diff), nameof(DiffFileName), nameof(DiffPath), nameof(DiffKind), nameof(DiffLetter), nameof(DiffKindName), nameof(DiffAdded), nameof(DiffRemoved),
            nameof(DiffRenamedFrom), nameof(HasOutline), nameof(CanEditDiff), nameof(CanUndoDiff), nameof(UndoDiffText), nameof(DiffSidesText),
            nameof(EditDiffFileCommand), nameof(UndoDiffCommand), nameof(OpenDiffFileCommand));
        DiffChanged?.Invoke(this, EventArgs.Empty);
    }

    internal async Task RefreshDiffAsync()
    {
        if (_diff is null || _diffEditing)
        {
            return; // while editing, the comparison follows the text being edited
        }
        if (_diff.Change.IsBranchComparison)
        {
            ShowDiff(await GitChanges.DiffAsync(_workspace.Record.Path, _diff.Change, CancellationToken.None));
            return;
        }
        await _workspace.Tree.RefreshChangesAsync();
        var same = _workspace.Tree.StagedChanges.Concat(_workspace.Tree.UnstagedChanges).Select(r => r.Change)
            .FirstOrDefault(c => c.Path == _diff.Change.Path && c.Staged == _diff.Change.Staged);
        if (same is null)
        {
            // Committed, undone or staged since: nothing left to compare — back to the file itself (if it is still there).
            var path = _diff.Change.Path;
            _diff = null;
            if (_workspace.Index?.FindFile(path) is not null && System.IO.File.Exists(System.IO.Path.Combine(_workspace.Record.Path, path)))
            {
                OpenFile(path, 0);
            }
            else
            {
                OpenDefault();
            }
            return;
        }
        ShowDiff(await GitChanges.DiffAsync(_workspace.Record.Path, same, CancellationToken.None));
    }

    private void BuildDiffRows()
    {
        DiffRows = _diff is null ? [] : _sideBySide ? SideRows(_diff.Lines) : InlineRows(_diff.Lines);
        Notify(nameof(DiffRows));
        DiffChanged?.Invoke(this, EventArgs.Empty);
    }

    private static List<DiffRow> InlineRows(IReadOnlyList<DiffLine> lines)
        => lines.Select(l => new DiffRow(Cell(l, l.NewNumber ?? l.OldNumber), DiffCell.Filler, l.OldNumber?.ToString() ?? "", l.NewNumber?.ToString() ?? "",
            l.Kind switch { DiffLineKind.Added => "+", DiffLineKind.Removed => "−", _ => "" }, l.Kind.ToString())).ToList();

    /// <summary>Old on the left, new on the right: a run of removed lines is paired with the run of added lines after it.</summary>
    private static List<DiffRow> SideRows(IReadOnlyList<DiffLine> lines)
    {
        var rows = new List<DiffRow>();
        var i = 0;
        while (i < lines.Count)
        {
            var line = lines[i];
            if (line.Kind is DiffLineKind.Removed or DiffLineKind.Added)
            {
                var removed = new List<DiffLine>();
                var added = new List<DiffLine>();
                while (i < lines.Count && lines[i].Kind == DiffLineKind.Removed)
                {
                    removed.Add(lines[i++]);
                }
                while (i < lines.Count && lines[i].Kind == DiffLineKind.Added)
                {
                    added.Add(lines[i++]);
                }
                for (var k = 0; k < Math.Max(removed.Count, added.Count); k++)
                {
                    var left = k < removed.Count ? Cell(removed[k], removed[k].OldNumber) : DiffCell.Filler;
                    var right = k < added.Count ? Cell(added[k], added[k].NewNumber) : DiffCell.Filler;
                    rows.Add(new DiffRow(left, right, "", "", "", "Change"));
                }
                continue;
            }
            rows.Add(line.Kind is DiffLineKind.Hunk or DiffLineKind.Note
                ? new DiffRow(Cell(line, null), Cell(line, null), "", "", "", line.Kind.ToString())
                : new DiffRow(Cell(line, line.OldNumber), Cell(line, line.NewNumber), "", "", "", line.Kind.ToString()));
            i++;
        }
        return rows;
    }

    private static DiffCell Cell(DiffLine line, int? number) => new(number?.ToString() ?? "", line.Text, line.Kind.ToString());
}
