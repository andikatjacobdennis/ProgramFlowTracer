using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Input;
using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Engine.Storage;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>One kind of data on Settings → Data and storage, with its size and a box to tick for removal.</summary>
public sealed class DataCategoryRow(DataCategoryInfo info, Action changed) : ObservableObject
{
    private bool _isChecked;

    public DataCategory Category => info.Category;
    public string Title => info.Title;
    public string Description => info.Description;
    public bool IsEmpty => info.Files == 0;
    public string Size => IsEmpty ? "Empty" : $"{DataSettingsViewModel.FormatBytes(info.Bytes)} · {info.Files:N0} file{(info.Files == 1 ? "" : "s")}";
    public long Bytes => info.Bytes;

    public bool IsChecked
    {
        get => _isChecked;
        set
        {
            if (Set(ref _isChecked, value))
            {
                changed();
            }
        }
    }
}

/// <summary>Settings → Data and storage: what the data folder holds, removing parts of it, and the factory reset.</summary>
public sealed class DataSettingsViewModel : ObservableObject
{
    public const string ResetWord = "reset";

    private readonly MainViewModel _main;
    private bool _isBusy;
    private bool _keepAiSettings;
    private string _total = "";

    public DataSettingsViewModel(MainViewModel main)
    {
        _main = main;
        RemoveCommand = new AsyncCommand(RemoveAsync, () => !IsBusy && Categories.Any(c => c.IsChecked));
        SelectAllCommand = new RelayCommand(() =>
        {
            var all = Categories.Where(c => !c.IsEmpty).All(c => c.IsChecked);
            foreach (var row in Categories.Where(c => !c.IsEmpty))
            {
                row.IsChecked = !all;
            }
        });
        RefreshCommand = new AsyncCommand(LoadAsync);
        FactoryResetCommand = new AsyncCommand(FactoryResetAsync, () => !IsBusy);
    }

    public ObservableCollection<DataCategoryRow> Categories { get; } = [];

    public ICommand RemoveCommand { get; }
    public ICommand SelectAllCommand { get; }
    public ICommand RefreshCommand { get; }
    public ICommand FactoryResetCommand { get; }

    public string Total
    {
        get => _total;
        private set => Set(ref _total, value);
    }

    public bool IsBusy
    {
        get => _isBusy;
        private set
        {
            if (Set(ref _isBusy, value))
            {
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    /// <summary>The factory reset keeps settings/ai.json (providers, models and API keys).</summary>
    public bool KeepAiSettings
    {
        get => _keepAiSettings;
        set => Set(ref _keepAiSettings, value);
    }

    public string SelectionSummary
    {
        get
        {
            var chosen = Categories.Where(c => c.IsChecked).ToList();
            return chosen.Count == 0 ? "Tick what to remove." : $"{chosen.Count} selected · {FormatBytes(chosen.Sum(c => c.Bytes))}";
        }
    }

    public async Task LoadAsync()
    {
        var chosen = Categories.Where(c => c.IsChecked).Select(c => c.Category).ToHashSet();
        var infos = await _main.Engine.Data.MeasureAsync();
        Categories.Clear();
        foreach (var info in infos)
        {
            Categories.Add(new DataCategoryRow(info, OnSelectionChanged) { IsChecked = chosen.Contains(info.Category) && info.Files > 0 });
        }
        var total = await Task.Run(() => FolderSize(_main.Engine.Store.Root));
        Total = $"{FormatBytes(total)} in the data folder";
        OnSelectionChanged();
    }

    private void OnSelectionChanged()
    {
        Notify(nameof(SelectionSummary));
        CommandManager.InvalidateRequerySuggested();
    }

    private async Task RemoveAsync()
    {
        var chosen = Categories.Where(c => c.IsChecked).ToList();
        if (chosen.Count == 0)
        {
            return;
        }
        var list = string.Join("\n", chosen.Select(c => $"• {c.Title} ({c.Size})"));
        var indexes = chosen.Any(c => c.Category == DataCategory.Indexes);
        if (!await _main.ConfirmAsync("Remove this data?",
                "This cannot be undone." + (indexes ? " The repositories stay registered; index them again to use them." : ""),
                list, "Remove"))
        {
            return;
        }
        IsBusy = true;
        try
        {
            var removal = await _main.Engine.Data.RemoveAsync(chosen.Select(c => c.Category).ToList());
            // Open repositories hold what was removed in memory: they load afresh when opened again.
            foreach (var repository in await _main.Engine.Repositories.ListAsync())
            {
                _main.ForgetWorkspace(repository.Id);
            }
            await _main.Repositories.RefreshAsync();
            await LoadAsync();
            foreach (var row in Categories)
            {
                row.IsChecked = false;
            }
            Ui.Notify($"Removed {FormatBytes(removal.BytesFreed)} ({removal.FilesDeleted:N0} files)"
                + (removal.FilesInUse > 0 ? $"; {removal.FilesInUse} in use were left." : "."));
        }
        catch (ExplorerValidationException ex)
        {
            Ui.Notify(ex.Message);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task FactoryResetAsync()
    {
        var keep = KeepAiSettings;
        var typed = await _main.PromptAsync("Factory reset",
            $"Type {ResetWord} to confirm", "", "Reset and restart",
            message: "The explorer deletes everything it created in its data folder and restarts as if newly installed: every repository registration, index, " +
                     "Git clone, conversation, learning material, Studio conversation, persona, imported skill, setting, usage record and log" +
                     (keep ? ". Your AI providers, models and API keys are kept." : ", and your AI providers, models and API keys.") +
                     " Your repositories' own folders are never touched. This cannot be undone.",
            danger: true);
        if (typed is null)
        {
            return;
        }
        if (!string.Equals(typed.Trim(), ResetWord, StringComparison.OrdinalIgnoreCase))
        {
            Ui.Notify($"Nothing was reset: type {ResetWord} to confirm.");
            return;
        }
        _main.Engine.Data.ScheduleFactoryReset(keep);
        Logging.Info("Factory reset requested; restarting.");
        Restart(_main.Engine.Store.Root);
    }

    /// <summary>Starts the explorer again on the same data folder (where the reset runs first) and closes this one.</summary>
    private static void Restart(string dataRoot)
    {
        if (Environment.ProcessPath is { } exe)
        {
            var info = new ProcessStartInfo(exe) { UseShellExecute = false };
            info.ArgumentList.Add("--data");
            info.ArgumentList.Add(dataRoot);
            Process.Start(info);
        }
        Application.Current.Shutdown();
    }

    public static string FormatBytes(long bytes) => bytes switch
    {
        < 1024 => $"{bytes} B",
        < 1024 * 1024 => $"{bytes / 1024.0:0.#} KB",
        < 1024L * 1024 * 1024 => $"{bytes / (1024.0 * 1024):0.#} MB",
        _ => $"{bytes / (1024.0 * 1024 * 1024):0.##} GB",
    };

    private static long FolderSize(string folder)
    {
        try
        {
            return Directory.EnumerateFiles(folder, "*", new EnumerationOptions { RecurseSubdirectories = true, IgnoreInaccessible = true, AttributesToSkip = 0 })
                .Sum(f =>
                {
                    try
                    {
                        return new FileInfo(f).Length;
                    }
                    catch (IOException)
                    {
                        return 0L;
                    }
                });
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return 0;
        }
    }
}
