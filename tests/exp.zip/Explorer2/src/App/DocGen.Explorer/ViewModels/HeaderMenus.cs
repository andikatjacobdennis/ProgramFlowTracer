using System.Windows.Input;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>A repository in the header's repository menu.</summary>
public sealed class RepositoryChoice(RepositoryRecord record, bool isCurrent, ICommand open)
{
    public string Title => record.Title;
    public string Detail => record.Status switch
    {
        RepositoryStatus.Indexed => $"{record.Counters.Files:N0} files",
        RepositoryStatus.Indexing => "Indexing…",
        RepositoryStatus.Failed => "Indexing failed",
        _ => "Not indexed",
    };
    public bool IsCurrent { get; } = isCurrent;
    public string Glyph => record.Source == "git" ? Icons.Git : Icons.Code;
    public RepositoryRecord Record => record;
    public ICommand OpenCommand { get; } = open;
}
