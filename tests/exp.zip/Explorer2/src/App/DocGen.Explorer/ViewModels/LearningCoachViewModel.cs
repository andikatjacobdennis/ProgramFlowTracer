using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Windows.Threading;
using DocGen.Explorer.Engine.Studio;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>One of the user's personas offered as the Learning host (or the stand-in coach when there are none).</summary>
public sealed class CoachOption(string id, string name, string avatarId)
{
    public string Id { get; } = id;
    public string Name { get; } = name;
    public string AvatarId { get; } = avatarId;

    /// <summary>The stand-in when no personas have been made: a stable face picked from the name.</summary>
    public static CoachOption StandIn { get; } = new("", "Coach", "");
}

/// <summary>
/// The persona who hosts quizzes and flashcards: a short line in a speech bubble and a face that reacts — when a question
/// appears, on a right or wrong answer, on a streak and at the result. The lines are a fixed, varied set picked at random
/// (no model call), so the host is instant and costs nothing. The host is one of the personas Studio uses; the choice is
/// remembered in the explorer settings.
/// </summary>
public sealed class LearningCoachViewModel : ObservableObject
{
    private readonly MainViewModel _main;
    private readonly Random _random = new();
    private readonly DispatcherTimer _talk = new();
    private readonly Dictionary<string, string> _lastLine = [];
    private CoachOption _host = CoachOption.StandIn;
    private string _line = "";
    private string _emotion = Emotions.Happy;
    private bool _isTalking;
    private bool _loading;

    public LearningCoachViewModel(MainViewModel main)
    {
        _main = main;
        // Talking stops by itself once the line has been "said".
        _talk.Tick += (_, _) =>
        {
            _talk.Stop();
            IsTalking = false;
        };
        ManagePersonasCommand = new RelayCommand(() => main.Navigate(Section.Personas));
    }

    /// <summary>A reaction for the view to animate: nod | shake | cheer | slump | hello.</summary>
    public event EventHandler<string>? Reacted;

    public ObservableCollection<CoachOption> Hosts { get; } = [];
    public bool HasChoice => Hosts.Count > 1;
    public bool NoPersonas => Hosts.Count == 0 || Hosts.All(h => h.Id == "");
    public ICommand ManagePersonasCommand { get; }

    public CoachOption Host
    {
        get => _host;
        set
        {
            if (value is null || !Set(ref _host, value))
            {
                return;
            }
            Notify(nameof(HostName), nameof(AvatarId));
            if (!_loading && value.Id != "")
            {
                _ = _main.Engine.Models.UpdateExplorerSettingsAsync(s => s.LearningHostId = value.Id);
                Say(Emotions.Happy, "hello", Pick("switch").Replace("{name}", value.Name));
            }
        }
    }

    public string HostName => Host.Name;
    public string AvatarId => Host.AvatarId;

    public string Line
    {
        get => _line;
        private set => Set(ref _line, value);
    }

    public bool HasLine => Line.Length > 0;

    public string Emotion
    {
        get => _emotion;
        private set => Set(ref _emotion, value);
    }

    public bool IsTalking
    {
        get => _isTalking;
        private set => Set(ref _isTalking, value);
    }

    /// <summary>The personas Studio uses (fresh each time Learning opens, so a new one shows up), and the remembered host.</summary>
    public async Task LoadAsync()
    {
        try
        {
            var personas = await _main.Engine.Studio.ListPersonasAsync();
            var settings = await _main.Engine.Models.GetExplorerSettingsAsync();
            _loading = true;
            Hosts.Clear();
            foreach (var p in personas)
            {
                Hosts.Add(new CoachOption(p.Id, p.Name, p.Avatar));
            }
            if (Hosts.Count == 0)
            {
                Hosts.Add(CoachOption.StandIn);
            }
            Host = Hosts.FirstOrDefault(h => h.Id == settings.LearningHostId) ?? Hosts[0];
            Notify(nameof(HasChoice), nameof(NoPersonas));
        }
        catch (Exception ex)
        {
            // The host is a nicety: Learning works the same without one.
            Logging.Error(ex, "Learning host");
            if (Hosts.Count == 0)
            {
                Hosts.Add(CoachOption.StandIn);
                Host = CoachOption.StandIn;
            }
        }
        finally
        {
            _loading = false;
        }
    }

    // ---------- what happens in a quiz ----------

    public void QuizOpened(int questions, int passMark)
        => Say(Emotions.Happy, "hello", Fill(Pick("quiz-hello"), ("{n}", questions.ToString()), ("{pass}", passMark + "%")));

    public void QuestionShown(int number, int total)
    {
        var kind = number == 1 ? "first" : number == total ? "last" : "next";
        Say(number == 1 ? Emotions.Happy : Emotions.Curious, null, Pick(kind));
    }

    /// <summary>An answer given while the quiz says nothing until the end: the host must not give it away.</summary>
    public void AnswerNoted() => Say(Emotions.Thinking, null, Pick("noted"));

    public void Correct(int streak)
    {
        if (streak >= 3 && (streak == 3 || streak % 5 == 0 || streak == 7))
        {
            Say(Emotions.Excited, "cheer", Pick("streak").Replace("{n}", streak.ToString()));
            return;
        }
        Say(Emotions.Happy, "nod", Pick("correct"));
    }

    public void Wrong(string letter, string answer)
    {
        var shortAnswer = answer.Trim();
        var named = shortAnswer.Length is > 0 and <= 28 && !shortAnswer.Contains('\n') ? $"{letter} ({shortAnswer})" : letter;
        Say(Emotions.Concerned, "shake", Pick("wrong").Replace("{answer}", named));
    }

    public void Finished(bool passed, double percent)
    {
        var score = $"{percent:0.#}%";
        if (passed)
        {
            Say(Emotions.Excited, "cheer", Pick(percent >= 99.9 ? "perfect" : "pass").Replace("{score}", score));
        }
        else
        {
            Say(Emotions.Concerned, "slump", Pick("fail").Replace("{score}", score));
        }
    }

    // ---------- what happens with flashcards ----------

    public void DeckOpened(bool anythingDue) => Say(Emotions.Happy, "hello", Pick(anythingDue ? "deck-hello" : "deck-empty"));

    public void Graded(string grade)
    {
        switch (grade)
        {
            case "Again": Say(Emotions.Concerned, "shake", Pick("again")); break;
            case "Hard": Say(Emotions.Thinking, null, Pick("hard")); break;
            default: Say(Emotions.Happy, "nod", Pick("good")); break;
        }
    }

    public void DeckDone() => Say(Emotions.Excited, "cheer", Pick("deck-done"));

    // ---------- saying it ----------

    private void Say(string emotion, string? reaction, string line)
    {
        Emotion = emotion;
        Line = line;
        OnPropertyChanged(nameof(HasLine));
        // Roughly the time it takes to say the words, so the mouth stops with the bubble's line.
        var words = line.Split(' ', StringSplitOptions.RemoveEmptyEntries).Length;
        _talk.Stop();
        _talk.Interval = TimeSpan.FromMilliseconds(Math.Clamp(words * 230, 600, 2200));
        IsTalking = true;
        _talk.Start();
        if (reaction is not null)
        {
            Reacted?.Invoke(this, reaction);
        }
    }

    /// <summary>A random line of a kind, never the same one twice running.</summary>
    private string Pick(string kind)
    {
        var lines = CoachLines.For(kind);
        if (lines.Count == 1)
        {
            return lines[0];
        }
        string line;
        do
        {
            line = lines[_random.Next(lines.Count)];
        }
        while (_lastLine.TryGetValue(kind, out var last) && last == line);
        _lastLine[kind] = line;
        return line;
    }

    private static string Fill(string line, params (string Key, string Value)[] values)
        => values.Aggregate(line, (text, v) => text.Replace(v.Key, v.Value));

}

/// <summary>
/// What the host says: short, friendly and plain (simple Indian English), never childish. {n}, {pass}, {score},
/// {answer} and {name} are filled in.
/// </summary>
public static class CoachLines
{
    private static readonly Dictionary<string, string[]> Lines = new()
    {
        ["quiz-hello"] =
        [
            "Hi! I'll be your host today. {n} questions, pass mark {pass}.",
            "Ready when you are. {n} questions waiting.",
            "Shall we start? You need {pass} to pass.",
            "Take your time with these. Press Start when you're ready.",
        ],
        ["first"] =
        [
            "Here's the first one. No hurry.",
            "Let's begin. Read it fully once, then answer.",
            "First question. Take your time.",
        ],
        ["next"] =
        [
            "Next one. You're doing fine.",
            "Okay, have a look at this one.",
            "Read the options carefully.",
            "Think it through, then pick.",
            "This one is a good one.",
            "Next question, coming up.",
        ],
        ["last"] =
        [
            "Last question. Finish it off nicely.",
            "Final one now.",
            "Just this one left.",
        ],
        ["noted"] =
        [
            "Noted. Moving on.",
            "Got it. Next one.",
            "Okay, answer saved.",
            "Fine, let's keep going.",
        ],
        ["correct"] =
        [
            "Correct, well done!",
            "Spot on.",
            "Yes, that's right.",
            "Exactly right. Nice.",
            "Good, you got it.",
            "Perfect, that's the one.",
            "Right answer. Keep going.",
        ],
        ["wrong"] =
        [
            "Not this time. It's {answer}.",
            "Close, but the answer is {answer}.",
            "No worries. The right one is {answer}.",
            "Hmm, it's actually {answer}. You'll get the next one.",
            "Not quite. Remember: {answer}.",
        ],
        ["streak"] =
        [
            "{n} in a row! Very nice.",
            "{n} correct in a row. Superb.",
            "You're on a roll: {n} straight.",
            "{n} in a row. Keep it up!",
        ],
        ["pass"] =
        [
            "You passed with {score}! Well done.",
            "Superb, {score}. That's a pass.",
            "Nicely done: {score}. You know this well.",
            "A pass with {score}. Very good work.",
        ],
        ["perfect"] =
        [
            "Full marks! Brilliant work.",
            "All correct. Excellent!",
            "{score}, every single one. Superb!",
        ],
        ["fail"] =
        [
            "{score} this time. Have a look at the review and try again.",
            "Not a pass yet, but you're getting there. Check the review below.",
            "{score} for now. Read the explanations, then take it again.",
            "No problem, everyone starts somewhere. Try once more after the review.",
        ],
        ["deck-hello"] =
        [
            "Let's revise. Say the answer in your head, then turn the card.",
            "Card time. Think first, then flip.",
            "A few cards to go through. Be honest with yourself!",
        ],
        ["deck-empty"] =
        [
            "Nothing is due right now. Come back a little later.",
            "All caught up here. Good going.",
        ],
        ["good"] =
        [
            "Good recall.",
            "Nice, that one has stuck.",
            "Well remembered.",
            "That one you know.",
        ],
        ["hard"] =
        [
            "Fair enough, it'll come back sooner.",
            "Hard is honest. We'll see it again soon.",
            "Okay, a little more practice on that one.",
        ],
        ["again"] =
        [
            "No worries, it'll come around again.",
            "That's how we learn. You'll see it again shortly.",
            "It's fine. Next time it'll be easier.",
        ],
        ["deck-done"] =
        [
            "All caught up! Good session.",
            "That's all for now. Well revised.",
            "Done for today. Nicely done!",
        ],
        ["switch"] =
        [
            "Hi, {name} here. I'll host from now on.",
            "{name} here. Let's learn something.",
        ],
    };

    public static IReadOnlyList<string> Kinds => Lines.Keys.ToList();

    public static IReadOnlyList<string> For(string kind) => Lines.TryGetValue(kind, out var lines) ? lines : [""];
}
