using System.Windows.Input;
using DocGen.Explorer.Engine.Code;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>
/// Editing a file in Docs, as on GitHub: Edit opens the file's text (a page's Markdown, or a source file) with an Edit and
/// a Preview tab; Save writes it to disk (keeping its encoding mark and line endings, and asking first when it was
/// changed elsewhere since it was opened), then the index catches up in the background. And, for a C# file that
/// declares types, the class diagram in place of the code.
/// </summary>
public sealed partial class DocumentationViewModel
{
    private string? _editPath;
    private string _editorText = "";
    private string _editOriginal = "";
    private DateTime _editModified;
    private string _editTab = "edit";
    private DocLocation? _beforeEdit;
    private bool _showClassDiagram;
    private bool _showPreview;
    private string? _classDiagram;

    // ----- Editing -----

    /// <summary>The file Edit would open: the open file, or the open page's own Markdown file (not a generated page).</summary>
    private string? EditablePath => _file?.Path ?? (_page is { Generated: false, SourcePath: { Length: > 0 } source } ? source : null);

    public bool CanEdit => UiPreferences.Current.AllowFileEditing && EditablePath is not null;

    public ICommand EditCommand => new RelayCommand(() =>
    {
        if (EditablePath is { } path)
        {
            BeginEdit(path);
        }
    }, () => CanEdit);

    public ICommand SaveEditCommand => new AsyncCommand(() => Mode == "diff" ? SaveDiffEditAsync() : SaveEditAsync(), () => Mode == "edit" || IsDiffEditing);
    public ICommand CloseEditCommand => new AsyncCommand(() => CloseEditAsync(), () => Mode == "edit");
    public ICommand ShowEditTabCommand => new RelayCommand(p => EditTab = p as string ?? "edit");

    /// <summary>Raised when the editor opens (the view focuses it) or its preview should be drawn.</summary>
    public event EventHandler? EditorChanged;

    public string EditPath => _editPath ?? "";
    public string EditFileName => Path.GetFileName(_editPath ?? "");
    public string EditLanguage => _editPath is null ? "" : IngestionFilters.LanguageOf(_editPath) ?? "text";
    public bool IsMarkdownEdit => _editPath?.EndsWith(".md", StringComparison.OrdinalIgnoreCase) == true || _editPath?.EndsWith(".markdown", StringComparison.OrdinalIgnoreCase) == true;

    public string EditorText
    {
        get => _editorText;
        set
        {
            if (Set(ref _editorText, value ?? ""))
            {
                Notify(nameof(IsDirty), nameof(EditStatus));
            }
        }
    }

    public bool IsDirty => Mode == "edit" && !string.Equals(_editorText, _editOriginal, StringComparison.Ordinal);

    /// <summary>"Unsaved changes · 120 lines" or "Saved · 120 lines".</summary>
    public string EditStatus
    {
        get
        {
            var lines = _editorText.Count(c => c == '\n') + 1;
            return $"{(IsDirty ? "Unsaved changes" : "No changes")} · {Engine.Text.TextUtil.Plural(lines, "line")} · {EditLanguage}";
        }
    }

    /// <summary>edit | preview</summary>
    public string EditTab
    {
        get => _editTab;
        set
        {
            if (Set(ref _editTab, value is "preview" ? "preview" : "edit"))
            {
                Notify(nameof(IsEditTab), nameof(IsPreviewTab));
                EditorChanged?.Invoke(this, EventArgs.Empty);
            }
        }
    }

    public bool IsEditTab => EditTab == "edit";
    public bool IsPreviewTab => EditTab == "preview";

    /// <summary>Opens a file of the repository (relative path) in the editor.</summary>
    public void BeginEdit(string relativePath, bool isNew = false)
    {
        if (!UiPreferences.Current.AllowFileEditing)
        {
            _workspace.Main.ShowToast("Editing files is turned off (Settings → Reading and writing).", true);
            return;
        }
        string full;
        string text;
        try
        {
            full = FileScanner.SafeResolve(_workspace.Record.Path, relativePath);
            text = System.IO.File.Exists(full) ? System.IO.File.ReadAllText(full) : "";
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            _workspace.Main.ShowToast($"'{relativePath}' could not be opened: {ex.Message}", true);
            return;
        }
        if (Mode != "edit")
        {
            _beforeEdit = _current;
        }
        _opened++;
        _editPath = relativePath.Replace('\\', '/');
        _editOriginal = text.Replace("\r\n", "\n", StringComparison.Ordinal);
        _editorText = _editOriginal;
        _editModified = System.IO.File.Exists(full) ? System.IO.File.GetLastWriteTimeUtc(full) : default;
        _editTab = "edit";
        Breadcrumbs.Clear();
        Breadcrumbs.Add(new Breadcrumb(_workspace.Title, new RelayCommand(OpenDefault)));
        Breadcrumbs.Add(new Breadcrumb((isNew ? "New file: " : "Editing ") + _editPath, null) { IsLast = true });
        Outline.Clear();
        Mode = "edit";
        Notify(nameof(EditPath), nameof(EditFileName), nameof(EditLanguage), nameof(IsMarkdownEdit), nameof(EditorText), nameof(IsDirty), nameof(EditStatus),
            nameof(EditTab), nameof(IsEditTab), nameof(IsPreviewTab), nameof(HasOutline));
        CommandManager.InvalidateRequerySuggested();
        EditorChanged?.Invoke(this, EventArgs.Empty);
    }

    private async Task SaveEditAsync()
    {
        if (_editPath is null)
        {
            return;
        }
        try
        {
            var saved = RepositoryFiles.Save(_workspace.Record.Path, _editPath, _editorText, _editModified == default ? null : _editModified);
            if (!saved)
            {
                var overwrite = await _workspace.Main.ConfirmAsync("The file changed on disk", $"'{_editPath}' was changed outside the editor after you opened it.",
                    "Saving replaces those changes with yours.", "Save mine");
                if (!overwrite)
                {
                    return;
                }
                RepositoryFiles.Save(_workspace.Record.Path, _editPath, _editorText, overwrite: true);
            }
            var full = FileScanner.SafeResolve(_workspace.Record.Path, _editPath);
            _editModified = System.IO.File.GetLastWriteTimeUtc(full);
            _editOriginal = _editorText;
            Notify(nameof(IsDirty), nameof(EditStatus));
            Ui.Notify($"Saved {Path.GetFileName(_editPath)}.");
            Logging.Info($"Saved {_editPath} from the editor.");
            QueueReindex();
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or Engine.Repositories.ExplorerValidationException)
        {
            _workspace.Main.ShowToast($"Could not save: {ex.Message}", true);
        }
    }

    /// <summary>Leaves the editor (asking first when there are unsaved changes); true when it closed.</summary>
    public async Task<bool> CloseEditAsync(bool reopen = true)
    {
        if (Mode != "edit")
        {
            return true;
        }
        if (IsDirty && !await _workspace.Main.ConfirmAsync("Discard your changes?", $"'{_editPath}' has changes that are not saved.", null, "Discard"))
        {
            return false;
        }
        var path = _editPath;
        _editPath = null;
        Mode = "empty";
        if (!reopen)
        {
            return true;
        }
        // Opened from a diff: back to the diff, compared again with what was saved.
        if (_editFromDiff)
        {
            _editFromDiff = false;
            _ = RefreshDiffAsync();
            return true;
        }
        // Back to the file or page that was edited (as it is now on disk), else what was open before.
        var index = _workspace.Index;
        if (path is not null && index?.PageForSource(path) is { } page && _beforeEdit?.FilePath is null)
        {
            ShowPage(page.Id, null);
        }
        else if (path is not null && index?.FindFile(path) is not null)
        {
            ShowFile(path, 0);
        }
        else if (_beforeEdit is not null)
        {
            Go(_beforeEdit);
        }
        else
        {
            OpenDefault();
        }
        CommandManager.InvalidateRequerySuggested();
        return true;
    }

    private System.Windows.Threading.DispatcherTimer? _reindexTimer;

    /// <summary>The index catches up with changed files a moment after the last change (a quick incremental run).</summary>
    public void QueueReindex()
    {
        if (_reindexTimer is null)
        {
            _reindexTimer = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
            _reindexTimer.Tick += (_, _) =>
            {
                _reindexTimer.Stop();
                var indexing = _workspace.Main.Engine.Indexing;
                if (indexing.IsRunning(_workspace.Record.Id))
                {
                    _reindexTimer.Start(); // after the run in progress
                    return;
                }
                _ = indexing.StartAsync(_workspace.Record.Id, IndexMode.Incremental);
            };
        }
        _reindexTimer.Stop();
        _reindexTimer.Start();
        // The Changes tab shows the file at once (git status is quick).
        _ = _workspace.Tree.RefreshChangesAsync();
    }

    // ----- The class diagram of a C# file -----

    /// <summary>The open file declares types (classes, interfaces, records…) a class diagram can show.</summary>
    public bool CanShowClassDiagram => _file is not null && FileClassDiagram.HasTypes(_workspace.Index?.Code, _file.Path);

    public bool ShowClassDiagram
    {
        get => _showClassDiagram;
        set
        {
            if (Set(ref _showClassDiagram, value && CanShowClassDiagram))
            {
                _classDiagram = null;
                if (_showClassDiagram)
                {
                    ShowPreview = false;
                }
                Notify(nameof(ClassDiagramMarkdown), nameof(ClassDiagramTooltip), nameof(ShowCode), nameof(ShowRendered));
                ClassDiagramChanged?.Invoke(this, EventArgs.Empty);
            }
        }
    }

    /// <summary>The code, unless the class diagram or the Markdown preview is shown in its place.</summary>
    public bool ShowCode => !ShowClassDiagram && !ShowPreview;

    /// <summary>A rendered page (the class diagram or the Markdown preview) is shown in place of the code.</summary>
    public bool ShowRendered => ShowClassDiagram || ShowPreview;

    // ----- The preview of a Markdown file -----

    /// <summary>The open file is Markdown, which can be shown rendered.</summary>
    public bool CanPreviewMarkdown => _file is not null && IsMarkdownPath(_file.Path);

    public bool ShowPreview
    {
        get => _showPreview;
        set
        {
            if (Set(ref _showPreview, value && CanPreviewMarkdown))
            {
                if (_showPreview)
                {
                    ShowClassDiagram = false;
                }
                Notify(nameof(PreviewTooltip), nameof(ShowCode), nameof(ShowRendered));
                ClassDiagramChanged?.Invoke(this, EventArgs.Empty);
            }
        }
    }

    public string PreviewTooltip => ShowPreview ? "Show the Markdown source" : "Show this file rendered, as it reads on GitHub";

    public ICommand TogglePreviewCommand => new RelayCommand(() => ShowPreview = !ShowPreview, () => CanPreviewMarkdown);

    private static bool IsMarkdownPath(string path)
        => path.EndsWith(".md", StringComparison.OrdinalIgnoreCase) || path.EndsWith(".markdown", StringComparison.OrdinalIgnoreCase);

    /// <summary>What the rendered view shows: the Markdown file itself, or the class diagram; null when neither is on.</summary>
    public string? RenderedMarkdown => ShowPreview ? string.Join("\n", _lines) : ClassDiagramMarkdown;

    public string ClassDiagramTooltip => ShowClassDiagram ? "Show the code" : "Show the class diagram of the types in this file";

    public ICommand ToggleClassDiagramCommand => new RelayCommand(() => ShowClassDiagram = !ShowClassDiagram, () => CanShowClassDiagram);

    /// <summary>Raised when the class diagram is shown or hidden (the view draws it).</summary>
    public event EventHandler? ClassDiagramChanged;

    /// <summary>The diagram as Markdown (a Mermaid block with a line on what it shows), for the view to render.</summary>
    public string? ClassDiagramMarkdown
    {
        get
        {
            if (!ShowClassDiagram || _file is null || _workspace.Index?.Code is not { } code)
            {
                return null;
            }
            _classDiagram ??= FileClassDiagram.Mermaid(code, _file.Path);
            // The key is a quiet line above the diagram (the view's), not a sentence in the document.
            return _classDiagram is null ? null : $"```mermaid\n{_classDiagram}```\n";
        }
    }

    // ----- File details (the file header's tooltip) -----

    public string FileDetailsText => _file is null ? "" : string.Join("\n",
        RepositoryFiles.Details(_workspace.Record.Path, _file.Path, _file.Language).Rows().Select(r => r.Label.Length == 0 ? r.Value : $"{r.Label}: {r.Value}"));
}
