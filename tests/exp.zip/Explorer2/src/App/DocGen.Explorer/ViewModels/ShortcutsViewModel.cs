using System.Collections.ObjectModel;
using System.Windows.Input;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>Something a keyboard shortcut does: its name, its icon, the keys it starts with, and the command it runs.</summary>
public sealed record ShortcutAction(string Id, string Label, string Glyph, string Default, Func<MainViewModel, ICommand?> Command, object? Parameter = null);

/// <summary>Every shortcut the explorer has (Settings → Shortcuts changes the keys).</summary>
public static class ShortcutCatalog
{
    public static readonly IReadOnlyList<ShortcutAction> All =
    [
        new("search", "Search the documentation", Icons.Search, "Ctrl+K", m => m.FocusSearchCommand),
        new("files", "Show or hide the files list", Icons.Pane, "Ctrl+B", m => m.ToggleTreeCommand),
        new("ask", "Show or hide Ask", Icons.Chat, "Ctrl+J", m => m.ToggleAssistantCommand),
        new("summarise", "Summarise the selection", Icons.Lightbulb, "Ctrl+Shift+S", m => m.SummariseSelectionCommand),
        new("back", "Back", Icons.Back, "Alt+Left", m => m.BackCommand),
        new("forward", "Forward", Icons.Forward, "Alt+Right", m => m.ForwardCommand),
        new("documentation", "Documentation", Icons.Document, "Ctrl+1", m => m.NavigateCommand, "Documentation"),
        new("graph", "Graph", Icons.Graph, "Ctrl+2", m => m.NavigateCommand, "Graph"),
        new("indexing", "Indexing", Icons.Database, "Ctrl+3", m => m.NavigateCommand, "Indexing"),
        new("learning", "Learning", Icons.Lightbulb, "Ctrl+4", m => m.NavigateCommand, "Learning"),
        new("studio", "Studio", Icons.Studio, "Ctrl+5", m => m.NavigateCommand, "Studio"),
        new("talk", "Talk", Icons.People, "Ctrl+D7", m => m.NavigateCommand, "Talk"),
        new("repositories", "All repositories", Icons.Library, "Ctrl+6", m => m.NavigateCommand, "Repositories"),
        new("refresh", "Refresh the index", Icons.Refresh, "F5", m => m.Workspace?.Indexing.RefreshCommand),
        new("larger", "Make everything larger", Icons.ZoomIn, "Ctrl+OemPlus", m => m.ZoomInCommand),
        new("smaller", "Make everything smaller", Icons.ZoomOut, "Ctrl+OemMinus", m => m.ZoomOutCommand),
        new("actual", "Back to 100%", Icons.Fit, "Ctrl+D0", m => m.ZoomResetCommand),
        new("settings", "Settings", Icons.Settings, "Ctrl+OemComma", m => m.NavigateCommand, "Settings"),
        new("help", "Help", Icons.Help, "F1", m => m.NavigateCommand, "Help"),
        new("feedback", "Send feedback", Icons.Feedback, "", m => m.SendFeedbackCommand),
    ];

    /// <summary>The keys as text ("Ctrl+K"), or null when they cannot be a shortcut (a letter needs Ctrl or Alt).</summary>
    public static KeyGesture? Parse(string? text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return null;
        }
        try
        {
            return new KeyGestureConverter().ConvertFromInvariantString(text) as KeyGesture;
        }
        catch (Exception ex) when (ex is NotSupportedException or ArgumentException or FormatException)
        {
            return null;
        }
    }

    /// <summary>Whether two texts are the same keys, however written ("Ctrl+7" and "Ctrl+D7"); never for no keys.</summary>
    public static bool Same(string? a, string? b)
        => Parse(a) is { } x && Parse(b) is { } y && x.Key == y.Key && x.Modifiers == y.Modifiers;

    /// <summary>The keys as text from a key press, or null when the press cannot be a shortcut.</summary>
    public static string? FromKeys(Key key, ModifierKeys modifiers)
    {
        if (key is Key.LeftCtrl or Key.RightCtrl or Key.LeftAlt or Key.RightAlt or Key.LeftShift or Key.RightShift or Key.LWin or Key.RWin or Key.System)
        {
            return null;
        }
        try
        {
            var gesture = new KeyGesture(key, modifiers);
            return new KeyGestureConverter().ConvertToInvariantString(gesture);
        }
        catch (NotSupportedException)
        {
            return null;
        }
    }

    /// <summary>How the keys read: "Ctrl+=" rather than "Ctrl+OemPlus".</summary>
    public static string Display(string text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return "Not set";
        }
        var parts = text.Split('+');
        parts[^1] = parts[^1] switch
        {
            "OemPlus" => "=",
            "OemMinus" => "-",
            "OemComma" => ",",
            "OemPeriod" => ".",
            "Add" => "Num +",
            "Subtract" => "Num -",
            var d when d.Length == 2 && d[0] == 'D' && char.IsDigit(d[1]) => d[1..],
            var n when n.StartsWith("NumPad", StringComparison.Ordinal) => "Num " + n[6..],
            var other => other,
        };
        return string.Join(" + ", parts);
    }
}

/// <summary>One row of Settings → Shortcuts.</summary>
public sealed class ShortcutItemViewModel : ObservableObject
{
    private readonly ShortcutsViewModel _owner;
    private string _keys;
    private bool _isRecording;

    public ShortcutItemViewModel(ShortcutAction action, string keys, ShortcutsViewModel owner)
    {
        Action = action;
        _keys = keys;
        _owner = owner;
        RecordCommand = new RelayCommand(() => owner.StartRecording(this));
        ResetCommand = new RelayCommand(() => owner.Assign(this, Action.Default), () => Keys != Action.Default);
        ClearCommand = new RelayCommand(() => owner.Assign(this, ""), () => Keys.Length > 0);
    }

    public ShortcutAction Action { get; }
    public string Label => Action.Label;
    public string Glyph => Action.Glyph;

    public string Keys
    {
        get => _keys;
        set
        {
            if (Set(ref _keys, value))
            {
                Notify(nameof(Display), nameof(IsCustom), nameof(IsSet));
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    public string Display => IsRecording ? "Press the keys…" : ShortcutCatalog.Display(Keys);
    public bool IsSet => Keys.Length > 0;
    public bool IsCustom => Keys != Action.Default;
    public string DefaultText => Action.Default.Length == 0 ? "No default" : "Default: " + ShortcutCatalog.Display(Action.Default);

    public bool IsRecording
    {
        get => _isRecording;
        set
        {
            if (Set(ref _isRecording, value))
            {
                Notify(nameof(Display));
            }
        }
    }

    public ICommand RecordCommand { get; }
    public ICommand ResetCommand { get; }
    public ICommand ClearCommand { get; }

    /// <summary>A key press while recording: Escape stops, Backspace or Delete clears, anything else becomes the shortcut.</summary>
    public bool HandleKey(Key key, ModifierKeys modifiers) => _owner.HandleKey(this, key, modifiers);
}

/// <summary>Settings → Shortcuts: every shortcut with its icon and keys; click one and press new keys to change it.</summary>
public sealed class ShortcutsViewModel : ObservableObject
{
    private readonly MainViewModel _main;
    private string _status = "";

    public ShortcutsViewModel(MainViewModel main)
    {
        _main = main;
        foreach (var action in ShortcutCatalog.All)
        {
            Items.Add(new ShortcutItemViewModel(action, action.Default, this));
        }
        ResetAllCommand = new AsyncCommand(async () =>
        {
            foreach (var item in Items)
            {
                item.IsRecording = false;
                item.Keys = item.Action.Default;
            }
            Status = "Every shortcut is back to its default.";
            await SaveAsync();
        });
    }

    public ObservableCollection<ShortcutItemViewModel> Items { get; } = [];
    public ICommand ResetAllCommand { get; }
    public string Status { get => _status; private set => Set(ref _status, value); }

    /// <summary>The shortcuts changed (the window binds its keys again).</summary>
    public event Action? Changed;

    /// <summary>The keys of each action, as the window binds them.</summary>
    public IEnumerable<(ShortcutAction Action, KeyGesture Gesture)> Bindings()
        => Items.Select(i => (i.Action, Gesture: ShortcutCatalog.Parse(i.Keys))).Where(b => b.Gesture is not null).Select(b => (b.Action, b.Gesture!));

    /// <summary>The saved keys; actions not saved keep their default.</summary>
    public void Load(IReadOnlyDictionary<string, string> saved)
    {
        foreach (var item in Items)
        {
            item.Keys = saved.TryGetValue(item.Action.Id, out var keys) && (keys.Length == 0 || ShortcutCatalog.Parse(keys) is not null) ? keys : item.Action.Default;
        }
        // Keys someone chose win over a default that is the same (one added in a later version): one set of keys, one action.
        var chosen = Items.Where(i => saved.ContainsKey(i.Action.Id) && i.Keys.Length > 0).ToList();
        foreach (var item in Items.Where(i => !saved.ContainsKey(i.Action.Id) && i.Keys.Length > 0))
        {
            if (chosen.Any(c => ShortcutCatalog.Same(c.Keys, item.Keys)))
            {
                item.Keys = "";
            }
        }
        Changed?.Invoke();
    }

    internal void StartRecording(ShortcutItemViewModel item)
    {
        foreach (var other in Items)
        {
            other.IsRecording = other == item && !item.IsRecording;
        }
        Status = item.IsRecording ? $"Press the keys for “{item.Label}”. Escape stops; Backspace leaves it without a shortcut." : "";
    }

    internal bool HandleKey(ShortcutItemViewModel item, Key key, ModifierKeys modifiers)
    {
        if (!item.IsRecording)
        {
            return false;
        }
        if (key == Key.Escape && modifiers == ModifierKeys.None)
        {
            item.IsRecording = false;
            Status = "";
            return true;
        }
        if (key is Key.Back or Key.Delete && modifiers == ModifierKeys.None)
        {
            Assign(item, "");
            return true;
        }
        if (ShortcutCatalog.FromKeys(key, modifiers) is not { } keys || ShortcutCatalog.Parse(keys) is null)
        {
            // A modifier on its own, or a letter without Ctrl or Alt: keep listening.
            Status = "Use Ctrl or Alt with a letter or number, or a function key such as F2.";
            return true;
        }
        Assign(item, keys);
        return true;
    }

    internal void Assign(ShortcutItemViewModel item, string keys)
    {
        item.IsRecording = false;
        // Pressed keys are written as the converter writes them ("Ctrl+7"), the defaults may not be ("Ctrl+D7"): the action's
        // own default keys are its default, not a change.
        if (ShortcutCatalog.Same(keys, item.Action.Default))
        {
            keys = item.Action.Default;
        }
        // One action per set of keys: whatever had them loses them.
        var taken = keys.Length == 0 ? null : Items.FirstOrDefault(i => i != item && ShortcutCatalog.Same(i.Keys, keys));
        if (taken is not null)
        {
            taken.Keys = "";
        }
        item.Keys = keys;
        Status = keys.Length == 0 ? $"“{item.Label}” has no shortcut now."
            : taken is null ? $"“{item.Label}”: {ShortcutCatalog.Display(keys)}."
            : $"“{item.Label}”: {ShortcutCatalog.Display(keys)}. “{taken.Label}” had these keys and now has none.";
        _ = SaveAsync();
    }

    private async Task SaveAsync()
    {
        Changed?.Invoke();
        // Only what differs from the defaults is saved, so new defaults reach everyone else.
        var custom = Items.Where(i => i.IsCustom).ToDictionary(i => i.Action.Id, i => i.Keys);
        await _main.Engine.Models.UpdateExplorerSettingsAsync(s => s.Shortcuts = custom);
    }
}
