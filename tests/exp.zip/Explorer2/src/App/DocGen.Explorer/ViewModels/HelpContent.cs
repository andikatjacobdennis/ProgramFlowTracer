using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>An article of Help: a short answer to one thing a person wants to do.</summary>
public sealed record HelpArticle(string Id, string Title, string Summary, string Markdown, string[] Keywords, bool Popular = false)
{
    /// <summary>The topic it belongs to (set when the library is built).</summary>
    public HelpTopic Topic { get; internal set; } = null!;

    /// <summary>A mockup of the screen it describes (Assets/Help/name.svg), if it has one.</summary>
    public string? Illustration { get; internal set; }

    /// <summary>The mockup, drawn.</summary>
    public System.Windows.Media.ImageSource? Picture => Illustration is null ? null : Controls.SvgDrawing.Illustration(Illustration);

    public bool HasPicture => Picture is not null;

    /// <summary>The places in the explorer it is about, as links (see <see cref="HelpLinks"/>).</summary>
    public IReadOnlyList<HelpDestination> Places { get; internal set; } = [];

    public bool HasPlaces => Places.Count > 0;
}

/// <summary>A topic of Help: a card on the home page, with its articles.</summary>
public sealed record HelpTopic(string Id, string Title, string Glyph, string Summary, string Accent, IReadOnlyList<HelpArticle> Articles)
{
    public string Count => Articles.Count == 1 ? "1 article" : $"{Articles.Count} articles";

    /// <summary>The persona who guides this topic (one of Talk's), and their tip.</summary>
    public string Guide { get; internal set; } = "";

    public string GuideTip { get; internal set; } = "";

    /// <summary>The guide's initials, on their avatar.</summary>
    public string GuideInitials => string.Concat(Guide.Split(' ', StringSplitOptions.RemoveEmptyEntries).Select(w => w[0]));

    public bool HasGuide => Guide.Length > 0;

    /// <summary>The topic's colour, faint (behind its icon).</summary>
    public string AccentSoft => "#26" + Accent.TrimStart('#');
}

/// <summary>
/// The application's own Help, arranged as a help centre: topics, each with short articles that answer one task, and
/// a search over all of them. Articles are Markdown (rendered like the documentation); "&gt; **Tip:**" lines are tips.
/// </summary>
public static class HelpContent
{
    /// <summary>The articles with a mockup of their screen (Assets/Help). Declared first: static fields are set in order.</summary>
    private static readonly Dictionary<string, string> Illustrations = new()
    {
        ["tour"] = "window",
        ["first-repository"] = "window",
        ["search"] = "search",
        ["attach"] = "attach",
        ["dictate"] = "dictate",
        ["recognition"] = "recognition",
        ["read-aloud"] = "readaloud",
        ["answer-tools"] = "readaloud",
        ["mermaid"] = "diagram",
        ["architecture"] = "architecture",
    };

    /// <summary>
    /// Where in the explorer each article's task is done, as <see cref="HelpLinks"/> links (the first is the main place).
    /// Every article that names a page or a Settings page has it here, so answers can link to it.
    /// </summary>
    private static readonly Dictionary<string, string[]> Places = new()
    {
        ["ask-help"] = [HelpLinks.SettingsLink("chat-model")],
        ["first-repository"] = [HelpLinks.SectionLink("repositories")],
        ["tour"] = [HelpLinks.SectionLink("repositories"), HelpLinks.SettingsLink("appearance")],
        ["evidence-mode"] = [HelpLinks.SettingsLink("chat-model"), HelpLinks.SettingsLink("providers")],
        ["clone"] = [HelpLinks.SectionLink("repositories")],
        ["window-layout"] = [HelpLinks.SettingsLink("appearance")],
        ["git-changes"] = [HelpLinks.SectionLink("documentation")],
        ["indexing"] = [HelpLinks.SectionLink("indexing")],
        ["confluence"] = [HelpLinks.SectionLink("indexing"), HelpLinks.SettingsLink("confluence")],
        ["read"] = [HelpLinks.SectionLink("documentation")],
        ["search"] = [HelpLinks.SectionLink("documentation")],
        ["selection"] = [HelpLinks.SectionLink("documentation")],
        ["export"] = [HelpLinks.SectionLink("documentation")],
        ["ask-question"] = [HelpLinks.SectionLink("documentation"), HelpLinks.SettingsLink("skills")],
        ["depth-skills"] = [HelpLinks.SectionLink("documentation"), HelpLinks.SettingsLink("chat-model"), HelpLinks.SettingsLink("skills")],
        ["test-fix"] = [HelpLinks.SettingsLink("skills"), HelpLinks.SectionLink("documentation")],
        ["rewrite"] = [HelpLinks.SectionLink("documentation")],
        ["flows"] = [HelpLinks.SectionLink("documentation"), HelpLinks.SettingsLink("skills")],
        ["answer-tools"] = [HelpLinks.SectionLink("documentation")],
        ["summarise"] = [HelpLinks.SectionLink("documentation")],
        ["attach"] = [HelpLinks.SectionLink("documentation"), HelpLinks.SettingsLink("attachments")],
        ["attachment-limits"] = [HelpLinks.SettingsLink("attachments")],
        ["dictate"] = [HelpLinks.SectionLink("documentation"), HelpLinks.SettingsLink("voice")],
        ["recognition"] = [HelpLinks.SettingsLink("voice")],
        ["read-aloud"] = [HelpLinks.SectionLink("documentation"), HelpLinks.SettingsLink("voice")],
        ["mermaid"] = [HelpLinks.SectionLink("documentation")],
        ["architecture"] = [HelpLinks.SectionLink("documentation")],
        ["diagram-repair"] = [HelpLinks.SettingsLink("chat-model")],
        ["graph"] = [HelpLinks.SectionLink("graph")],
        ["graph-groups"] = [HelpLinks.SectionLink("graph")],
        ["learning"] = [HelpLinks.SectionLink("learning"), HelpLinks.SectionLink("personas")],
        ["talk"] = [HelpLinks.SectionLink("talk")],
        ["studio"] = [HelpLinks.SectionLink("studio"), HelpLinks.SectionLink("personas")],
        ["providers"] = [HelpLinks.SettingsLink("providers"), HelpLinks.SettingsLink("chat-model")],
        ["usage"] = [HelpLinks.SectionLink("usage"), HelpLinks.SettingsLink("prices")],
        ["appearance"] = [HelpLinks.SettingsLink("appearance")],
        ["data"] = [HelpLinks.SettingsLink("data"), HelpLinks.SettingsLink("voice")],
        ["shortcuts"] = [HelpLinks.SettingsLink("shortcuts")],
        ["find"] = [HelpLinks.SectionLink("documentation"), HelpLinks.SettingsLink("editing")],
        ["select-code"] = [HelpLinks.SectionLink("documentation")],
        ["edit-files"] = [HelpLinks.SectionLink("documentation"), HelpLinks.SettingsLink("editing")],
        ["file-details"] = [HelpLinks.SectionLink("documentation"), HelpLinks.SettingsLink("editing")],
        ["class-diagram"] = [HelpLinks.SectionLink("documentation")],
        ["paste"] = [HelpLinks.SectionLink("documentation"), HelpLinks.SettingsLink("editing")],
        ["spelling"] = [HelpLinks.SectionLink("documentation"), HelpLinks.SettingsLink("editing")],
        ["ask-search"] = [HelpLinks.SectionLink("documentation")],
        ["logs"] = [HelpLinks.SectionLink("logs"), HelpLinks.SettingsLink("editing")],
        ["reading-writing"] = [HelpLinks.SettingsLink("editing")],
    };

    /// <summary>
    /// Each topic's guide — one of the personas of Talk — and the tip they would give first, in their own voice.
    /// </summary>
    private static readonly Dictionary<string, (string Guide, string Tip)> Guides = new()
    {
        ["start"] = ("Friendly Guide", "Start with one repository and one question — “What does this project do?” is a great first one. I'll show you where the answer came from."),
        ["repositories"] = ("Patient Teacher", "Indexing is just the explorer reading your files once. After that, Refresh changed files only reads what is new — it takes seconds."),
        ["documentation"] = ("Practical Developer", "Ctrl+K is the fastest way around: type a class name and press Enter. Alt+Left takes you back."),
        ["ask"] = ("Code Detective", "Ask about a symptom, not just a name: “why could saving fail?” Then open the numbered evidence and check each clue yourself."),
        ["attachments"] = ("Code Detective", "Got a stack trace or a log? Attach it. I'll pick out the class names in it and look at that code first."),
        ["voice"] = ("Friendly Guide", "Prefer talking to typing? Click the microphone and just speak — your words appear as you go, and stop when you pause."),
        ["diagrams"] = ("Practical Developer", "Ask “draw the architecture diagram of this repository” — then double-click it for full screen and zoom right in."),
        ["learning"] = ("Patient Teacher", "Ten minutes a day with flashcards beats an hour once a week. The cards come back just when you are about to forget them."),
        ["settings"] = ("Product Companion", "Everything stays on your PC unless you choose a model or an online voice — Settings shows you exactly what goes where."),
        ["keyboard"] = ("Practical Developer", "Learn three keys and you are flying: Ctrl+K to find, Ctrl+J for the assistant, F1 for this Help."),
    };

    public static readonly IReadOnlyList<HelpTopic> Topics = Build(
    [
        new("start", "Get started", Icons.Lightbulb, "Add a repository, find your way around, and choose how answers are written.", "#1A73E8",
        [
            new("ask-help", "Ask Help a question", "Type a question: Help says where to find it in the explorer and how, with links that take you there.", """
                Help answers questions about the explorer itself — "where do I add a Confluence space to a repository?", "how do I change the theme?", "where is token usage?".

                ### Steps

                1. Open Help (**F1**, or the **⚙** menu → **Help**).
                2. Type your question in the search box and press **Enter** (or choose **Ask**).
                3. The answer card says **where** it is and **how** to do it, step by step. Its links go straight there: a page of the explorer, a page of Settings, or the Help article it came from.

                ### Good to know

                - **With a chat model** (Settings → Chat model) the answer is written by the model from Help's own articles, and nothing else; Token usage lists it as *help*.
                - **Without one**, Help finds the article that answers best and shows its steps and its places.
                - The articles that match are listed under the answer.

                > **Tip:** questions about your repository's code — what a class does, where a value is read — are for **Ask** (Ctrl+J) beside the documentation.
                """, ["ask", "question", "help", "where", "how", "find", "links", "answer"], Popular: true),
            new("first-repository", "Add your first repository", "Point the explorer at a folder, clone one with Git, or start a new one.", """
                DocGen Explorer reads a code repository — its documentation, its files and its code — and builds an index you can browse, search and ask about. Nothing is ever written into the repository.

                ### Steps

                1. On **Repositories** (the first page), choose **Add repository**.
                2. Pick how it arrives:
                   - **Local path** — type or **Browse** to a folder.
                     - A `.sln`, `.csproj` or `.vbp` inside it works too.
                     - A path copied with *Copy as path* (quotes and all) is accepted.
                   - **Git URL** — clone from GitHub, GitLab, Bitbucket or Azure DevOps into the explorer's data folder.
                   - **New folder** — start from nothing; keep *Start an empty Git repository* ticked for `git init`.
                3. Choose **Add and index** (**Clone and index** for a Git URL, **Create and open** for a new folder). Indexing starts at once, and the documentation opens when it is ready.

                ### Good to know

                - Indexing reads the code (types, members, calls), the documentation and the configuration, and builds a knowledge graph.
                - Your repository folder is only read — never changed.

                > **Tip:** with exactly one repository, the explorer opens straight on its documentation. **DocGen Explorer** in the header always returns to the list.
                """, ["add", "repository", "folder", "clone", "git", "new", "open", "start"], Popular: true),
            new("tour", "A tour of the window", "The header, the three panes, and where everything lives.", """
                **The header.** On the left, the repository's name is a menu: switch repository (you stay on the same page), open its Indexing, see all repositories, or add one. In the middle: **Documentation**, **Graph**, **Learning**, **Studio**, **Talk** and **All repositories**. On the right: the assistant button and the **⚙** menu — Settings, Token usage, Personas, Help, the theme and motion switches, and Send feedback…

                **The documentation page** has three panes: the **tree** (Docs and Files) on the left, the **page** in the middle, and **Ask** — the assistant — on the right. Drag the dividers to resize; the arrangement can be swapped in Settings → Appearance.

                **While something is read aloud**, a bar with **Pause** and **Stop** stays at the top of the window, wherever you scroll.

                > **Tip:** on a narrow window the pages fold into the **⋯** menu. Ctrl+= and Ctrl+- change the size of everything.
                """, ["window", "layout", "header", "panes", "tour", "menu", "navigate"]),
            new("evidence-mode", "Evidence mode and chat models", "Answers without a model, and what a model adds.", """
                **Without a chat model** the explorer runs in **evidence mode**: answers are composed offline from the code index and the knowledge graph — who declares what, what uses what, which lines connect two types — and say so. Nothing leaves this PC.

                **With a chat model** (Settings → Chat model) the model writes the answer from the same evidence, streamed as it is written, and cites it. It also writes summaries, learning material, graph descriptions and Studio conversations, and can fix diagrams that cannot be drawn.

                The model box beside the depth in Ask switches between them for the next question. When answers are in evidence mode but a model could answer, the notice above the conversation offers it in one click.

                > **Tip:** short greetings ("hi", "thanks") get a quick reply without searching. Other short messages are checked by the model in a few tokens first, so chit-chat never costs a full answer.
                """, ["evidence", "offline", "model", "chat", "ai", "llm", "no model"], Popular: true),
        ]),
        new("repositories", "Repositories and indexing", Icons.Folder, "Add, switch, clone branches, reindex, and bring in Confluence.", "#188038",
        [
            new("clone", "Clone from Git and change branch", "Azure DevOps, GitHub and others; sign-in; switching branches.", """
                Choose **Git URL** when adding a repository and paste its address. For Azure DevOps, the URL from the repository's **Clone** button, the old `org.visualstudio.com` form, the SSH form or the page address in your browser all work — anything after `_git/repo` is dropped, and a branch you were looking at is cloned unless you type another.

                Sign-in is Git's own: Git Credential Manager remembers you, and shows a Microsoft sign-in window the first time.

                **Change branch…** (on the card or its right-click menu) lists the remote's branches — or type one — then switches the clone and fully reindexes it, so documentation, the graph, search and answers describe that branch.

                > **Tip:** never put a password or token in the URL.
                """, ["git", "clone", "branch", "azure devops", "github", "sign in", "credential"]),
            new("indexing", "Indexing: refresh, reindex, clear", "What each button does, and the stages of a run.", """
                - **Refresh changed files** (F5) reads only what changed since the last run.
                - **Full reindex** throws the index away and reads everything again.
                - **Cancel** stops a run; the previous index stays in use.
                - **Clear index** removes the index but keeps the repository.
                - **Pull latest** (Git clones) fetches the remote and refreshes.

                A run goes through Scanning, Classifying (with the C# code index), parsing the documentation, Chunking, Embedding (offline), building the graph, analysing configuration, endpoints and services, describing the graph (by the model when there is one) and writing the generated reference pages.

                > **Tip:** removing a repository (the bin on its card) deletes its index, graph, conversations and learning material — never the folder itself.
                """, ["index", "reindex", "refresh", "clear", "cancel", "stages", "f5"]),
            new("confluence", "Search Confluence spaces with a repository", "Add a space to a repository on its Indexing page, sync it, and sign in to its site.", """
                Confluence spaces are added **to a repository**, on that repository's **Indexing** page, and are then searched with it — by Ask, search and Talk.

                ### Steps

                1. Open the repository: on **Repositories**, choose **Open** on its card.
                2. In the header, click the **repository's name** (at the left) and choose **Indexing of this repository** (or press Ctrl+3).
                3. Scroll to **Confluence**. Under **Add spaces from your sites**, tick the spaces this repository should search (type in the box above the list to narrow it) — or, under **Or add a space by its address**, paste a space's address (such as `https://confluence.example.com/spaces/TEAM/overview`) and choose **Add**.
                4. The chosen spaces are listed by name under **Spaces this repository searches**, each with its site, how many pages the last sync read, and a bin to stop searching it.
                5. Choose **Sync** below them: the pages are fetched, the index is refreshed, and they are searched with the repository.

                ### No spaces listed? Add the site and its sign-in

                The sites and how to sign in to each are kept in **Settings → Confluence** (also **Confluence sites and sign-in…** on the Indexing page). Choose **Add site**, type the site's address, and pick the sign-in: Confluence Cloud with your email and an API token, Server or Data Center with a personal access token, or none for public spaces. **Test connection** says whether the address is a Confluence site, whether the sign-in works and how many spaces it sees; then **Save**. The site's spaces are then listed on every repository's Indexing page, under **Add spaces from your sites**; Settings → Confluence has a button that goes to the open repository's Indexing page.

                > **Tip:** Settings → Confluence → **Syncing** sets how many pages are read per space and how long to wait for the site.
                """, ["confluence", "space", "spaces", "wiki", "sync", "atlassian", "indexing", "site", "sign in"]),
        ]),
        new("documentation", "Documentation and search", Icons.Document, "Read pages and files, search everything, and choose what answers use.", "#E37400",
        [
            new("read", "Read documentation and files", "The Docs and Files tabs, source files, and going back.", """
                The tree's **Docs** tab lists the repository's Markdown files as on disk (README.md, docs/setup.md). The reference pages generated from the code — Overview, Architecture, an API page per project, Operations — are reached through search, links and the assistant. The **Files** tab lists every indexed file.

                A source file opens with line numbers, syntax highlighting and folding: collapse or expand every block, wrap long lines, copy, download, or open it in its own program. Clicking a line number copies a link to that line.

                **On this page** lists a page's sections and follows you as you scroll. **Alt+Left** and **Alt+Right** go back and forward.
                """, ["docs", "files", "tree", "markdown", "source", "line numbers", "back"]),
            new("search", "Search the repository", "Ctrl+K finds documentation, files and symbols as you type.", """
                Press **Ctrl+K** (or click the search box in the header) and type. Results come from the documentation, the files and the code's symbols, each saying what it is, where it is (`path:line`) and how it matched: `symbol`, `heading`, `file`, `exact`, `keyword` or `semantic`.

                **Enter** opens the first result; **Escape** closes the list.

                > **Tip:** to ask *how* something works rather than *where* it is, ask the assistant instead.
                """, ["search", "find", "ctrl+k", "symbol", "where"], Popular: true),
            new("selection", "Limit what answers use (selection mode)", "Tick folders and files; questions and study material use only those.", """
                The tick button beside the Docs and Files tabs turns on **selection mode**. Tick folders and files: the assistant, quizzes, flashcards, learning paths and Studio conversations then use only what is ticked. **Clear selection** goes back to the whole repository.
                """, ["selection", "scope", "tick", "limit", "folders"]),
            new("export", "Copy and export pages", "Links to sections, Markdown, Word and PDF.", """
                A page's **Copy** gives a link to the page and section, or the page as Markdown. **Export** saves the page as Markdown, Word or PDF, or **all the documentation** as Word or PDF — the pages the Docs list shows, in its order (the generated reference pages only when Docs lists them). Word shows the diagrams as pictures. Every section heading has a button that copies a link to it.
                """, ["export", "copy", "word", "pdf", "link", "markdown"]),
            new("find", "Find in a page or a file", "Ctrl+F: every match in yellow, Find all, match case, whole word, regex.", """
                Press **Ctrl+F** (or **Find**) in a page or a file. The bar opens at the top right with the selected word in it:

                - Every match is marked in **yellow**, the one you are on in **orange**; the count says where you are ("3 of 12").
                - **Enter** or **F3** goes to the next match, **Shift+Enter** or **Shift+F3** to the previous.
                - **Aa** matches case (Alt+C), **ab** whole words (Alt+W), **.\*** regular expressions (Alt+E).
                - **Find all** (Alt+A) lists every match with the text around it; click one to go there.
                - **Esc** closes it and clears the marks. A page's code blocks are searched too.

                Settings → Reading and writing chooses whether matches are marked as you type or when you press Enter.
                """, ["find", "search", "ctrl+f", "highlight", "yellow", "find all", "regex", "match case", "whole word", "f3"], Popular: true),
            new("select-code", "Select and copy code", "Drag, double-click a word, triple-click a line, Ctrl+A, Ctrl+C.", """
                Code can be selected like any text — in a file, and in the code blocks of pages and answers:

                - **drag** across it; **Shift+click** extends the selection;
                - **double-click** selects a word, **triple-click** a whole line (keep the button down and drag to select more words or lines);
                - **Ctrl+A** selects everything, **Ctrl+C** copies; right-click has Copy, Select all and Find.
                """, ["select", "copy", "code", "double-click", "triple-click", "ctrl+a", "ctrl+c"]),
            new("edit-files", "Add, edit, rename and delete files", "As on GitHub: Edit and Preview, Save; right-click for more.", """
                Right-click a file or folder in the **Docs** or **Files** list:

                - **Open**, **Edit**, **Preview (rendered)** for a Markdown file, **Open in its own program**;
                - **New file…** and **New folder…** (in that folder; type `guide/setup.md` to make sub-folders too) — the **+** buttons above the list add them at the top;
                - **Rename…** (F2) and **Delete…** (Del) — deleted files go to the **Recycle Bin**;
                - **Copy relative path**, **Copy full path**, **Show in File Explorer**.

                **Edit** (also on a page's or a file's toolbar) opens the file with an **Edit** and a **Preview** tab: a Markdown file is shown rendered, any other file highlighted. **Save** (Ctrl+S) writes it, keeping its line endings and encoding; if the file was changed elsewhere since you opened it, you are asked first. **Close** asks before dropping unsaved changes. The index catches up with what you changed a moment later.

                Settings → Reading and writing can turn editing off.
                """, ["edit", "new file", "new folder", "rename", "delete", "save", "preview", "markdown", "github", "recycle bin"], Popular: true),
            new("file-details", "A file's details", "Point at a file: size, dates, lines, encoding.", """
                Point at a file in the Docs or Files list for its details: **size** (in the unit that fits — bytes, KB, MB, GB… with the exact byte count), **type**, **lines** (and blank lines), **characters**, **encoding** and **line endings**, **modified**, **created** and **accessed** (with how long ago), and whether it is read-only or hidden. A folder shows how many files and folders it holds and their total size. A file's name above its code shows the same.
                """, ["details", "tooltip", "size", "modified", "created", "lines", "encoding", "metadata"]),
            new("class-diagram", "A C# file's class diagram", "Class diagram on a file's toolbar: its types, members and relations.", """
                Open a C# file that declares classes, interfaces, records or enums and press **Class diagram** on its toolbar: the types are drawn with their members (+ public, - private, # protected, ~ internal), what they inherit and implement, the indexed types they hold and the types nested in them. Press it again for the code.
                """, ["class diagram", "uml", "classes", "members", "toggle"]),
            new("markdown-preview", "Previewing a Markdown file", "Preview on a Markdown file's toolbar: the file rendered in place of its source.", """
                Open a Markdown file (.md) in Files and press **Preview** on its toolbar: it is shown rendered — headings, tables, code, links and Mermaid diagrams — as it reads on GitHub. Press it again for the source.
                """, ["preview", "markdown", "render", "readme", "toggle"]),
            new("git-changes", "Git changes", "The Changes tab beside Docs and Files: what changed since the last commit, and each file's diff.", """
                When the repository is a Git working tree, the **Changes** tab beside Docs and Files lists what changed since the last commit, as Visual Studio's Git Changes window does: the branch (with ↑ commits to push and ↓ to pull), **Staged changes**, then **Changes**, each a tree of folders (a run of single folders shown as one path, with how many files changed under it) and files with their status — **M** modified, **A** added, **D** deleted, **R** renamed, **U** new (untracked), **!** a conflict. Click a file for its diff: **Side by side** (the last commit on the left, yours on the right, scrolling together) or **Inline**, added lines green and removed lines red, with line numbers and syntax colours. The diff is code like any file: drag, double-click a word or triple-click a line to select, Ctrl+C to copy, Ctrl+F to find. **Edit** makes the right side your working copy, editable right there as in Visual Studio: the whole file is compared and the comparison follows as you type (the original on the left, what you add in green on the right, the two sides kept level). **Save** (Ctrl+S) writes the file; **Close** stops editing and compares again (asking first when there are unsaved changes). A staged change's Edit opens the file in the editor instead. **Undo changes** (on the diff, or right-click a file) puts a file back as last committed, unstages a staged change (your edits stay), brings back a deleted file, or sends a new file to the Recycle Bin — it asks first. **Compare branches** lists the files one branch changed since it left another (as a pull request shows them); click one for its diff. Refresh reads the changes again; saving a file in the explorer does it for you. Stage and commit in your Git tool.
                """, ["git", "changes", "diff", "edit", "tree", "staged", "commit", "branch", "branches", "compare", "undo", "discard", "revert", "unstage"]),
            new("window-layout", "Arranging the window", "Drag a panel's header to dock it beside, above, below or as a tab — or outside the window to float it.", """
                The window is made of panels — **Repository** (Docs, Files and Changes), the **page** in the middle and the **Assistant** — and each can go anywhere. Drag a panel by its header: dropped on a panel's edge it docks on that side, in its middle it becomes a tab there, outside the window it floats in its own window. The **⋯** button on a header does the same from a menu, **⧉** floats it and **✕** closes it (the header buttons bring it back). Drag a divider to resize. **Tabs can be rearranged too**: drag a tab sideways along its strip — the header's sections, Docs · Files · Changes, or a panel group's tabs — and a line shows where it will go; or press **Ctrl+Shift+←** / **→** on a focused tab. A plain click still opens the tab. The layout and the tab orders are kept for next time. Under ⚙ → **Reset window layout** puts everything back (in the pane order chosen in Settings → Appearance), and **Lock or unlock the layout** stops panels being dragged by accident.
                """, ["layout", "dock", "panel", "float", "split", "tab", "tabs", "reorder", "rearrange", "arrange", "reset", "lock", "window"]),
        ]),
        new("ask", "Ask the assistant", Icons.Chat, "Ask about the code, follow flows, summarise, and download answers.", "#9334E6",
        [
            new("ask-question", "Ask a question", "Grounded answers with numbered evidence you can open.", """
                ### Steps

                1. Open **Ask** (Ctrl+J shows or hides it).
                2. Type your question and press **Enter** (**Shift+Enter** starts a new line).
                3. Read the answer — the numbers in it, like [2], open the evidence they cite.

                ### When the question is unclear

                With a chat model, Ask first reads the question: what it asks for, which part of the code it means and what the answer must contain (for example a table with Project, Class, Method and Description). The first step, **Understood**, says how it was read.

                If the words fit more than one thing (two versions of a service, two features with similar names), Ask asks which one before searching, with the choices as buttons. Choose one, or reply in your own words, and the answer covers your original question.

                Turn this off in [Settings → Skills](explorer:settings/skills) (**Read the question first, and ask me when it is unclear**).

                ### While it works

                - The steps say what it is doing: understanding the question, finding files, checking how they connect, writing.
                - **Working through this** keeps those steps — and a reasoning model's thinking — with the answer.
                - An answer that reaches the model's output limit is continued automatically.

                ### Around the conversation

                - The buttons across the top show earlier conversations, start a new one, widen the panel and hide it.
                - Every answer lists what it used under **Evidence retrieved**.
                - From two questions on, the **question rail** at the right edge has a bar per question — the one you are reading is longer and coloured. Point at it to list the questions by their first words; choose one to scroll back to it.

                > **Tip:** follow-up questions such as "and what calls it?" carry the names from your previous question.
                """, ["ask", "question", "assistant", "answer", "evidence", "citation", "unclear", "clarify", "version", "intent"], Popular: true),
            new("depth-skills", "Depth, models and skills", "How thorough the answer is, which model writes it, and how it is shaped.", """
                - **Depth** — Quick, Balanced, Detailed, Deep or Expert; **Auto** decides from the question.
                - **Model** — evidence mode or any model from your providers file (the same choice as Settings → Chat model).
                - **Skills** shape kinds of question: **Architect** (program-flow tables traced across projects — every step, the table built from the trace itself — with the call chain and a sequence diagram), **Code review**, **Debugging**, **Diagrams**, **Documentation writer**, **Word document** and **PowerPoint presentation**. The question picks one automatically, or choose one; the answer shows which skill shaped it.
                - **Word document** writes a finished document (design document, specification, report, handover or runbook) and **PowerPoint presentation** writes a slide deck — one idea per slide, with tables, diagrams and speaker notes. Their answers have **Save as Word** or **Save as PowerPoint**: one click saves the .docx or .pptx, with the diagrams drawn as pictures. Ask, for example, "make a presentation of the order service for new joiners".
                """, ["depth", "model", "skill", "architect", "quick", "expert", "word", "powerpoint", "ppt", "slides", "deck", "presentation", "document"]),
            new("test-fix", "Fix failing tests (Test Fix)", "Reproduce failing tests, fix the cause in your local files and verify it.", """
                ### Turn it on

                Test Fix runs commands and changes files, so it is off until you turn it on: open [Settings → Skills](explorer:settings/skills) and tick **Test Fix**. The **🧪** button then appears in Ask's question box.

                ### Steps

                1. Choose **🧪** in Ask.
                2. Describe the failure in the question box, and attach what you have: the failing test file, the CI log or the stack trace.
                3. Optionally name the **tests to run** (names or a filter), the **configuration** (Debug, Release, QADebug…) and a **test command** — empty uses the repository's own runner (`dotnet test`, `npm test`, `pytest`, Maven or Gradle).
                4. Press **Enter** and confirm. The stages show as it works: Inspecting project, Reproducing failures, Analysing root cause, Preparing patch, Applying changes, Verifying repair.

                ### What it does

                - Runs the failing tests first and reads the runner's own results (counts and failures). Zero tests run never counts as a pass, and a test that hangs is stopped, named and reported — never counted as passed.
                - Reads what the code logged while the tests ran, so an integration test's "500" comes with the server's own exception.
                - Follows the failure into the code — through services, interfaces and their implementations, across projects — to find the root cause, even several projects below the test.
                - Applies the smallest fix to your files. Your other edits stay; it never skips tests, weakens assertions, hardcodes results, swallows exceptions or adds delays.
                - Reruns the failing tests, then related tests, a build check and the wider suite when practical, and tries again up to the limit you set.

                ### The report

                It says **Fixed and verified**, **Partially resolved** or **Blocked**, with the environment, the failure as it was reproduced (each message, stack trace and the code at those lines), the root cause and its evidence, every attempt, the diff of every change, each command with its exit code and test counts, what was verified and what could not run, and what to do next — enough to fix it by hand without running it again. **Undo these changes** puts the files back.

                > **Never:** Test Fix does not commit, push, publish or deploy. Review the diff and commit it yourself.
                """, ["test", "fix", "failing", "repair", "bug", "unit test", "mstest", "nunit", "xunit", "pytest", "jest", "stack trace", "regression", "verify"]),
            new("rewrite", "Rewrite a question", "Spelling, the code's own names, and clearer wording.", """
                **Rewrite** tidies the question before you send it: spelling fixed against the repository's own words, names written as the code spells them ("order service" → `OrderService`), and — with a chat model — reworded to be clear and specific. **Undo rewrite** puts yours back.
                """, ["rewrite", "spelling", "rephrase", "undo"]),
            new("flows", "Follow a flow across projects", "Trace a request from the handler to the response.", """
                Questions about a flow — "from the handler to the response", "trace", "what happens when" — follow the calls through every layer: helpers, injected services and the classes implementing them. With the Architect skill the answer is a step-by-step table (Step, Project, Class, Method, Description) with the call chain and a numbered sequence diagram.
                """, ["flow", "trace", "call chain", "sequence", "handler", "request"]),
            new("ask-search", "Search a conversation", "The magnifier in Ask: words in yellow, Enter for the next.", """
                The **magnifier** at the top of Ask searches the conversation: the words are marked in **yellow** in every question and answer, the message you are on is outlined, and **Enter** / **Shift+Enter** (or the arrows) go to the next and previous message that has them. **Match case** and **Whole word** narrow it.

                With **earlier conversations** shown (the clock), the search keeps only the conversations that have the words, with how many times and where. While an answer is being written you can scroll up to read; the thread follows the answer again once you scroll back to the end.
                """, ["search", "find", "conversation", "history", "highlight", "scroll"]),
            new("answer-tools", "Read aloud, copy, download or retry an answer", "Everything under a finished answer.", """
                - **Read aloud** speaks the answer; the word being said is highlighted in yellow. See *Read answers aloud*.
                - **Copy** copies it; **Retry** asks again; a question of yours can be copied, or **edited** and asked again (its attachments stay).
                - **Download** saves that answer alone as Word, PowerPoint, PDF, web page, Markdown, plain text, or its Mermaid diagram (all diagrams as a ZIP when there are several). Word and PowerPoint show the diagrams as pictures; a deck has a title slide and a slide for each section (## heading), continued on the next slide when one is full. *Include the question* adds the question it answered.
                """, ["download", "copy", "retry", "edit", "word", "powerpoint", "pptx", "pdf", "answer"]),
            new("summarise", "Summarise a selection or a diagram", "Right-click, Ctrl+Shift+S, or a diagram's Summarise.", """
                Select part of a page or an answer, right-click and choose **Summarise selection** (or press **Ctrl+Shift+S**). The summary arrives in Ask (in Talk when Talk is open) as an answer you can read aloud, copy or download.

                A diagram's toolbar has **Summarise**: the summary appears **under that diagram**, kept with its answer. **Retry** summarises the same selection again.

                > **Tip:** without a chat model, a passage's main sentences are picked and a diagram is described from its source.
                """, ["summarise", "summary", "selection", "ctrl+shift+s", "diagram"]),
        ]),
        new("attachments", "Attachments", Icons.Attach, "Attach files and images to a question.", "#D93025",
        [
            new("attach", "Attach files to a question", "Any file: the paperclip, or drop it on the question box.", """
                ### Steps

                1. Click the **paperclip** beside the question box (the picker opens on *All files*) — or **drag files onto the question box**.
                2. Each file becomes a card:
                   - an image shows its picture;
                   - any other file shows its name, its type (LOG, PDF, ZIP…) and its size.
                3. To remove one, hover over its card and click the round **×**.
                4. Type your question and send — or send the files alone, and the explorer asks what is in them.

                ### What happens to the files

                - **With a chat model**, their content goes with the question **as data from you, never as instructions**.
                - **Names in them** — a stack trace's classes, a log's components — help find the code they are about.
                - **Without a model**, the answer starts with a short summary of each file.
                - The files stay with the question: **Retry** and **Edit** keep them.

                > **Tip:** a file that could not be read keeps a warning border — hover over it to see why.
                """, ["attach", "attachment", "file", "upload", "paperclip", "drop", "image", "log", "pdf"], Popular: true),
            new("paste", "Paste into the question box", "Pictures, files and long or structured text become cards.", """
                **Ctrl+V** in the question box:

                - a **picture** (a screenshot) is attached as *Pasted image 1.png*, with its preview;
                - **copied files** (from File Explorer) are attached;
                - **JSON, XML, a log or stack trace, CSV**, or text longer than the length set, is attached as *Pasted text 1.json* (named by what it is) instead of filling the box;
                - anything shorter is typed into the box as usual. **Ctrl+Shift+V** always pastes plain text.

                Every attachment is a square card with its name and size; point at it for everything else — the whole name, kind, exact size, what was read, and a preview (the picture, or the first lines of the text).
                """, ["paste", "ctrl+v", "screenshot", "json", "clipboard", "image", "attachment", "card"]),
            new("spelling", "Spelling in the question box", "Red underlines; click a word for its corrections.", """
                Spelling mistakes in the question box are underlined in **red**. **Click** an underlined word for its corrections (or right-click it); choose one to replace the word, or **Ignore this word**. Settings → Reading and writing turns either off.
                """, ["spelling", "spell check", "red", "squiggly", "correct", "autocorrect", "typo"]),
            new("attachment-limits", "Which files are read, and how much", "Kinds, sizes and lengths in Settings → Attachments.", """
                Any file can be attached; these kinds are read:

                | Kind | Examples | Read as |
                |---|---|---|
                | Text and code | .txt .md .log .json .xml .cs .py .svg … | its text |
                | PDF | .pdf | its text (scanned PDFs have none) |
                | Word | .docx | its paragraphs |
                | Images | .png .jpg .gif .webp | the picture, for a model that can view images (the providers file marks it so); other models get only its name |

                Anything else (a .zip, a video) is attached **by name only**, marked *not supported*; a file of another kind that is plain text is read as text.

                In **Settings → Attachments**, each kind has **Read** on or off, its **largest file** (MB) and the **most characters** sent to the model — a longer file is cut, and you and the model are told. Images are **scaled down** to the longest side set (1568 px by default) and saved smaller while over their size. There is also a limit on files per question.
                """, ["attachment", "limit", "size", "settings", "pdf", "word", "image", "scale", "supported"]),
        ]),
        new("voice", "Voice and microphone", Icons.Mic, "Dictate questions, and have answers read aloud.", "#12B5CB",
        [
            new("dictate", "Dictate a question", "Click the microphone, speak, and watch the words appear.", """
                ### Steps

                1. Click the **microphone** in the question box.
                2. Speak your question. While it records:
                   - the button turns **red** with a pulse;
                   - a trace follows your voice;
                   - the words appear above the question box as they are recognised.
                3. Click the microphone again — or simply pause — to stop.
                4. The words go into the question box to check and send (or straight to the assistant with *Send the question as soon as I stop speaking*).

                ### Good to know

                - Dictation stops by itself after a few seconds without sound — set how many in **Settings → Voice → Stop listening after** (0 listens until you stop it).
                - Prefer holding the button while you talk? Choose *Hold the microphone button to talk* under **Button**.

                > **Tip:** the microphone button shows only when dictation is on and a microphone can be used (one is connected, and Windows lets apps use it).
                """, ["microphone", "mic", "dictate", "speak", "voice", "record", "speech to text"], Popular: true),
            new("recognition", "Choose how speech is recognised", "Whisper on this PC, Windows online, or Windows offline.", """
                In **Settings → Voice → Microphone → Recognition**:

                - **Whisper on this PC** (the default) — a speech model that runs in the explorer: no connection, nothing sent anywhere, and accurate. Choose its size and **Download** it (Base, 141 MB, is a good start); it listens to the microphone chosen here.
                - **Windows online speech recognition** — Microsoft's service, as Windows voice typing (Win+H) uses. It needs *Online speech recognition* on (the **Speech privacy** button) and listens to the Windows default microphone.
                - **Windows offline recogniser** — basic, on this PC.

                **Test microphone** listens for five seconds with a level meter and shows what it heard. The buttons beside it open Windows' sound, recording devices, speech and microphone settings.

                > **Tip:** if the test says no sound arrived, the Windows default microphone may be a device that is not connected (a phone-camera app, for example) — choose another one.
                """, ["whisper", "online", "offline", "recognition", "language", "test microphone", "privacy", "default microphone"]),
            new("read-aloud", "Read answers aloud", "Natural voices, the yellow highlight, Pause and Stop.", """
                Choose **Read aloud** under an answer. The word being said is **highlighted in yellow**, word by word, and kept in view as the reading moves on. **Pause** holds it where it is and **Resume** carries on; **Stop** ends it.

                While anything is read, a **reading bar** with Pause and Stop stays at the top of the window — so stopping is never far away, wherever you scroll.

                The voice is set in **Settings → Voice**: Microsoft Edge's natural voices (online, the text is sent to Microsoft) or the Windows voices on this PC. Long answers start quickly: the first sentence is spoken first and the rest follows.
                """, ["read aloud", "voice", "speak", "pause", "stop", "highlight", "tts"]),
        ]),
        new("diagrams", "Diagrams and graph", Icons.Graph, "Mermaid diagrams, architecture pictures, and the knowledge graph.", "#F9AB00",
        [
            new("mermaid", "Zoom, pan and download diagrams", "Toolbar, full screen, and saving as SVG, PNG, JPEG and more.", """
                Mermaid diagrams in pages and answers — flowcharts, sequence, class, state, entity-relationship, Gantt, pie and more — are drawn by mermaid.js; large architectures use the ELK layout so groups stay in order and arrows go around them.

                **Ctrl+wheel** zooms a diagram where it is and dragging pans it. Its toolbar (on hover) zooms, fits, shows it at 100 %, opens it **full screen** (or double-click: there the wheel zooms, + − 0 1 and the arrows work, Esc closes), **downloads** it — SVG (sharp at any size), PNG, JPEG, BMP, GIF or TIFF, or its Mermaid source — or **copies** it as a picture to paste elsewhere, and **Summarise** writes a summary under it. Copied and saved pictures are drawn for a white page (also in the dark theme), so nothing turns black when pasted. Diagrams stay sharp at any zoom.
                """, ["diagram", "mermaid", "zoom", "full screen", "svg", "png", "jpg", "jpeg", "bmp", "image", "download"]),
            new("architecture", "Architecture diagram of a C# solution", "Ask for it, and get the projects in layers.", """
                Ask for an architecture diagram of a C# repository ("draw the architecture diagram of this repository"). The answer is drawn from the projects' own references, in layers: Application hosts, Composition root, Request gateway, Domain services, Persistence and infrastructure, Domain models and shared types, External system integrations, Cross-cutting components — tests left out.

                To keep the lines easy to follow, a reference already implied through another arrow is not drawn again, a project that depends on most integrations points once at a dashed hub, and what every integration uses is one arrow from the group.
                """, ["architecture", "c#", "solution", "projects", "layers", "diagram", "dependencies"]),
            new("diagram-repair", "When a diagram cannot be drawn", "The model fixes it, up to the attempts you set.", """
                When mermaid.js cannot draw a diagram and a chat model is set up, the model is sent the diagram and the error and asked to correct only what is wrong; the diagram shows *asking the model to fix it (attempt 1 of 2)*. A fix that draws replaces the diagram in the answer, so it stays fixed.

                Set the number of attempts in **Settings → Chat model** (0 turns it off). If every attempt fails, the diagram's code is shown with the reason.
                """, ["diagram", "error", "fix", "repair", "cannot draw", "mermaid"]),
            new("graph", "Explore the knowledge graph", "Pan, zoom, select, and open what a concept stands for.", """
                The **Graph** page shows the repository, its projects, namespaces, files, types, tests and documentation, connected by containment, declaration, inheritance, use, calls, tests, references and mentions.

                Drag the background to pan, the wheel to zoom, a card to move it. Click a concept to light up its connections (listed on the right); double-click opens its file or page. **Tab** walks the concepts; arrows pan, + and − zoom, **Home** fits. The legend hides or shows kinds of concept.
                """, ["graph", "knowledge graph", "concepts", "zoom", "pan"]),
            new("graph-groups", "Narrow and group the graph", "Show only, reach, and Group with AI.", """
                **Show only** narrows the graph in plain words — "only order service", "what BaseReader uses", "readings and averages" — with **Show with AI** (or without a model). **Reach** sets how far it goes: auto (the request decides), only what matches, + what it uses, or + the traced flow. **Whole repository** goes back.

                **Group with AI** breaks the graph into groups of at most 30 concepts by how strongly they are linked; the model names each group and explains why. The box beside it takes how you want it grouped ("by feature", "keep tests apart"). **Reset** returns to the whole graph.
                """, ["show only", "group", "filter", "narrow", "reach", "graph"]),
        ]),
        new("learning", "Learning, Talk and Studio", Icons.Quiz, "Study the repository, chat with personas, and listen to conversations.", "#E52592",
        [
            new("learning", "Learning paths, quizzes and flashcards", "Study material drawn from the repository.", """
                Nothing is made until you ask for it:

                - **Learning paths** — sessions that build on each other, foundations first.
                - **Quizzes** — multiple-choice questions from facts in the index, marked by arithmetic; choose how many, how hard, the pass mark and a time limit.
                - **Flashcards** — classes, terms and workflows on a spaced-repetition schedule.
                - **What you know** — what quizzes and reviews say you understand, by topic.
                - **FAQ** — the questions somebody would actually ask, answered with citations.

                One of your Studio personas (⚙ → Personas) hosts quizzes and flashcards, and its face reacts to your answers.
                """, ["learning", "quiz", "flashcards", "path", "faq", "study"]),
            new("talk", "Talk with a persona", "A friendly conversation about the repository, for anyone.", """
                **Talk** is for anyone — no programming background needed. Choose who you talk with: the Friendly Guide, the Patient Teacher, the Practical Developer, the Code Detective or the Product Companion. A persona changes the tone, never the facts: answers come from the repository and cite it.

                Switching persona keeps the conversation. **Speak replies** reads each answer aloud; **Pause** and **Stop speaking** are beside it. Passwords, keys and tokens found in the repository are masked in Talk answers.
                """, ["talk", "persona", "conversation", "guide", "teacher"]),
            new("studio", "Studio conversations", "Two to four personas discussing the repository, spoken aloud.", """
                Describe what they should talk about, choose the speakers, the style and the length, and **Compose**. Play it with each persona's voice — their cartoon faces talk with the emotion of each line — save it as audio, or save the transcript as Markdown. **Personas** (⚙ menu, or **Manage personas** in Studio) is where speakers are written, imported and exported.
                """, ["studio", "podcast", "personas", "conversation", "audio"]),
        ]),
        new("settings", "Settings, AI and data", Icons.Settings, "Providers, prices and usage, appearance, and your data.", "#5F6368",
        [
            new("providers", "Providers and models", "Import the providers file, keys, Ollama, and testing a model.", """
                Providers and models come only from an **encrypted providers file** (.enc) from the team that gives you DocGen Explorer: **Settings → Providers and models → Import from file…**. Here you can paste or change a key, turn a provider or model off, **Use** or **Test** a model, or remove a provider. A provider such as **Ollama** lists its own models (**Find models**).

                Everything is saved encrypted for your Windows account; nothing is read from environment variables.
                """, ["provider", "model", "key", "import", "ollama", "enc"]),
            new("logs", "The log viewer", "⚙ menu → Logs: filter, columns, dates, pages, auto refresh.", """
                **Logs** (⚙ menu) lists what the explorer and its engine wrote to the log, newest first:

                - **Search every column**, or narrow one column with the box under its title (Source, Message, Exception, Log file);
                - tick the **levels** to show (Errors, Warnings, Information, Debug) — **Problems only** shows errors and warnings;
                - a **time range** (last 15 minutes, hour, 24 hours, today, 7 days) or a **custom range** from a date and time **to** a date and time;
                - **Columns** shows or hides columns; click a column's title to sort by it (again to reverse);
                - **pages**: rows per page, first, previous, the page numbers, next, last;
                - **Auto refresh** reads new entries every few seconds (the interval beside it, or Settings → Reading and writing); **F5** refreshes now;
                - select an entry for all of it, the stack trace too, with **Copy entry**; **Open folder** shows the log files.
                """, ["logs", "log viewer", "errors", "warnings", "filter", "auto refresh", "columns", "date", "pagination"]),
            new("reading-writing", "Reading and writing settings", "Scrolling, spelling, pasting, Find, editing files.", """
                **Settings → Reading and writing**: how far one notch of the **mouse wheel** scrolls (two lines by default) and whether it glides; **spelling** in the question box; when pasted text becomes an **attachment**; whether **Find** marks matches as you type; whether files can be **edited** in Docs and whether a file's **details** show when you point at it; and how often the **log viewer** refreshes itself.
                """, ["settings", "scroll", "scrolling", "wheel", "smooth", "spelling", "paste", "find", "editing", "logs"]),
            new("usage", "Token usage and prices", "What the model was asked, and what it cost.", """
                **Token usage** (⚙ menu) shows the model's calls over 7, 30 or 90 days: totals, tokens per day, and by feature and model. Every call is listed with what it was for; click one for everything recorded — the messages sent, the reply, tokens, time and cost. Search, filter, sort and page the table; **Export** saves CSV or JSON. Set **prices** per million tokens in Settings → Prices.
                """, ["usage", "tokens", "cost", "price", "calls", "billing"]),
            new("appearance", "Appearance, size and motion", "Theme, zoom, pane order and reduced motion.", """
                **Settings → Appearance**: *Follow Windows* (light or dark, with your accent colour), *Light* is all greys, *Dark* is warm charcoal. **Ctrl+=**, **Ctrl+-** and **Ctrl+0** change the size of everything. The motion switch in the **⚙** menu turns animation and answer streaming on or off.
                """, ["theme", "dark", "light", "zoom", "size", "motion", "appearance"]),
            new("data", "Data, storage and reset", "What is kept, removing it, and factory reset.", """
                Everything the explorer derives lives in its **data folder**. **Settings → Data and storage** shows how much each kind takes; tick what to remove — indexes, Ask and Talk conversations, Studio conversations, learning material, usage history, logs, leftovers from earlier versions — and **Remove selected…**. **Factory reset** (type *reset*) deletes everything the explorer created and restarts it as new. Your repositories' folders are never touched.

                Whisper speech models are kept apart, in `%LOCALAPPDATA%\DocGen.Explorer\Models\whisper`; a factory reset leaves them. Remove one in Settings → Voice → Microphone (Recognition: Whisper) → **Remove**.
                """, ["data", "storage", "remove", "reset", "folder", "delete"]),
        ]),
        new("keyboard", "Keyboard and tips", Icons.Keyboard, "Shortcuts for what you do most.", "#1E8E3E",
        [
            new("shortcuts", "Keyboard shortcuts", "The default keys; change them in Settings → Shortcuts.", """
                | Keys | What they do |
                |---|---|
                | Ctrl+K | Search the repository |
                | Ctrl+J | Show or hide the assistant |
                | Ctrl+B | Show or hide the files list |
                | Alt+Left / Alt+Right | Back and forward |
                | Ctrl+1 … Ctrl+7 | Documentation, Graph, Indexing, Learning, Studio, Repositories, Talk |
                | Ctrl+Shift+S | Summarise the selection |
                | F5 | Refresh changed files |
                | Ctrl+= / Ctrl+- / Ctrl+0 | Larger, smaller, 100 % |
                | Ctrl+, | Settings |
                | F1 | Help |
                | Escape | Close the search results or a dialog |

                > **Tip:** in **Settings → Shortcuts**, click a shortcut and press the new keys; one set of keys does one thing. *Send feedback* has no keys until you give it some.
                """, ["keyboard", "shortcut", "keys", "hotkey", "ctrl"], Popular: true),
        ]),
    ]);

    private static IReadOnlyList<HelpTopic> Build(IReadOnlyList<HelpTopic> topics)
    {
        foreach (var topic in topics)
        {
            if (Guides.TryGetValue(topic.Id, out var guide))
            {
                topic.Guide = guide.Guide;
                topic.GuideTip = guide.Tip;
            }
            foreach (var article in topic.Articles)
            {
                article.Topic = topic;
                article.Illustration = Illustrations.GetValueOrDefault(article.Id);
                article.Places = Places.GetValueOrDefault(article.Id, []).Select(link => HelpLinks.Find(link)!).ToList();
            }
        }
        return topics;
    }

    public static IEnumerable<HelpArticle> Articles => Topics.SelectMany(t => t.Articles);

    /// <summary>
    /// The articles that answer a search, best first. Words such as "where", "how", "the" and "my" are left out, and
    /// each word also matches its other forms and its synonyms ("spaces" → space, "repo" → repository, "wiki" →
    /// Confluence). Articles with every word come first; when none has them all, those with the most words.
    /// </summary>
    public static IReadOnlyList<HelpArticle> Search(string query)
    {
        var ranked = Rank(query);
        if (ranked.Count == 0)
        {
            return [];
        }
        var most = ranked.Max(r => r.Matched);
        return ranked.Where(r => r.Matched == most).Select(r => r.Article).ToList();
    }

    /// <summary>How well an article answers a search: its score, and how many of the search's words it has.</summary>
    public sealed record Match(HelpArticle Article, double Score, int Matched, int Words, bool InTitleOrKeywords);

    /// <summary>
    /// Every article with at least one of the search's words, best first: the most words, then the highest score (a
    /// word in the title counts 6, in the keywords 4, in the summary 2, in the text 1).
    /// </summary>
    public static IReadOnlyList<Match> Rank(string query)
    {
        var words = Words(query);
        if (words.Count == 0)
        {
            return [];
        }
        var articles = Articles.Select(a => (Article: a, Title: a.Title.ToLowerInvariant(), Keys: string.Join(' ', a.Keywords).ToLowerInvariant(),
            Summary: a.Summary.ToLowerInvariant(), Body: a.Markdown.ToLowerInvariant())).ToList();
        int Hit(string[] forms, (HelpArticle Article, string Title, string Keys, string Summary, string Body) a)
            => forms.Max(w => (a.Title.Contains(w) ? 6 : 0) + (a.Keys.Contains(w) ? 4 : 0) + (a.Summary.Contains(w) ? 2 : 0) + (a.Body.Contains(w) ? 1 : 0));
        // A word most articles have ("model") says less than one few have ("cost"): it counts less.
        var weights = words.Select(forms => 1 + Math.Log((double)articles.Count / Math.Max(1, articles.Count(a => Hit(forms, a) > 0)))).ToList();
        return articles
            .Select(a =>
            {
                double score = 0;
                var matched = 0;
                var strong = false;
                for (var i = 0; i < words.Count; i++)
                {
                    var hit = Hit(words[i], a);
                    if (hit > 0)
                    {
                        matched++;
                        score += hit * weights[i];
                        strong |= words[i].Any(w => a.Title.Contains(w) || a.Keys.Contains(w));
                    }
                }
                return new Match(a.Article, score, matched, words.Count, strong);
            })
            .Where(m => m.Matched > 0)
            .OrderByDescending(m => m.Matched)
            .ThenByDescending(m => m.Score)
            .ToList();
    }

    /// <summary>Words that say nothing about what is looked for ("where do I…", "how can I…").</summary>
    private static readonly HashSet<string> StopWords =
    [
        "a", "an", "the", "and", "or", "of", "to", "in", "on", "at", "for", "from", "into", "with", "by", "as", "about", "up",
        "i", "me", "my", "mine", "we", "our", "you", "your", "it", "its", "this", "that", "these", "those", "there", "here",
        "is", "are", "was", "were", "be", "been", "am", "do", "does", "did", "done", "can", "could", "should", "would", "will", "shall", "may", "might", "must",
        "where", "how", "what", "which", "when", "why", "who", "whom",
        "find", "locate", "get", "want", "need", "way", "able", "possible", "please", "tell", "show", "go", "put", "some", "any", "thing", "things",
        "explorer", "docgen", "app", "application", "program", "help", "so", "then", "if", "not", "no", "yes", "also", "just", "only",
    ];

    /// <summary>Other words for the same thing, as Help's articles say it.</summary>
    private static readonly Dictionary<string, string[]> Synonyms = new()
    {
        ["repo"] = ["repository"],
        ["repos"] = ["repository"],
        ["project"] = ["repository"],
        ["codebase"] = ["repository"],
        ["space"] = ["confluence"],
        ["spaces"] = ["confluence"],
        ["wiki"] = ["confluence"],
        ["theme"] = ["appearance"],
        ["colour"] = ["theme", "appearance"],
        ["color"] = ["theme", "appearance"],
        ["dark"] = ["theme"],
        ["light"] = ["theme"],
        ["font"] = ["size"],
        ["bigger"] = ["size", "zoom"],
        ["larger"] = ["size", "zoom"],
        ["smaller"] = ["size", "zoom"],
        ["key"] = ["provider"],
        ["token"] = ["usage", "key"],
        ["tokens"] = ["usage"],
        ["api"] = ["provider", "key"],
        ["ai"] = ["model"],
        ["llm"] = ["model"],
        ["cost"] = ["usage", "price"],
        ["costs"] = ["usage", "price"],
        ["spend"] = ["usage", "cost"],
        ["money"] = ["cost", "price"],
        ["bill"] = ["usage", "price"],
        ["mic"] = ["microphone"],
        ["speech"] = ["dictate", "recognition"],
        ["hotkey"] = ["shortcut"],
        ["hotkeys"] = ["shortcut"],
        ["keys"] = ["shortcut", "key"],
        ["delete"] = ["remove"],
        ["erase"] = ["remove"],
        ["wipe"] = ["remove", "reset"],
        ["upload"] = ["attach"],
        ["picture"] = ["image"],
        ["screenshot"] = ["image"],
        ["photo"] = ["image"],
        ["checkout"] = ["branch"],
        ["preferences"] = ["settings"],
        ["options"] = ["settings"],
        ["configure"] = ["settings"],
        ["login"] = ["sign in"],
        ["password"] = ["sign in", "token"],
        ["credentials"] = ["sign in", "credential"],
        ["chart"] = ["diagram"],
        ["charts"] = ["diagram"],
        ["podcast"] = ["studio"],
        ["save"] = ["download", "export"],
        ["tts"] = ["read aloud"],
        ["aloud"] = ["read aloud"],
    };

    /// <summary>The search's words that say something, each with its other forms and synonyms (lower case).</summary>
    internal static IReadOnlyList<string[]> Words(string query)
    {
        var all = query.ToLowerInvariant().Split([' ', ',', '.', '?', '!', ';', ':', '"', '“', '”', '(', ')'], StringSplitOptions.RemoveEmptyEntries)
            .Select(w => w.Trim('\'', '’')).Where(w => w.Length > 1).ToList();
        var meaningful = all.Where(w => !StopWords.Contains(w)).ToList();
        // A search of only such words ("find", "where") still searches for them.
        return (meaningful.Count > 0 ? meaningful : all).Distinct().Select(Forms).ToList();
    }

    /// <summary>A word, its singular or stem ("spaces" → space, "indexing" → index), and its synonyms.</summary>
    private static string[] Forms(string word)
    {
        var forms = new List<string> { word };
        if (word.Length > 4 && word.EndsWith("ies", StringComparison.Ordinal))
        {
            forms.Add(word[..^3] + "y");
        }
        else if (word.Length > 3 && word.EndsWith('s') && !word.EndsWith("ss", StringComparison.Ordinal))
        {
            forms.Add(word[..^1]);
        }
        if (word.Length > 5 && word.EndsWith("ing", StringComparison.Ordinal))
        {
            forms.Add(word[..^3]);
        }
        if (word.Length > 4 && word.EndsWith("ed", StringComparison.Ordinal))
        {
            forms.Add(word[..^2]);
        }
        forms.AddRange(Synonyms.GetValueOrDefault(word, []));
        return forms.Distinct().ToArray();
    }
}
