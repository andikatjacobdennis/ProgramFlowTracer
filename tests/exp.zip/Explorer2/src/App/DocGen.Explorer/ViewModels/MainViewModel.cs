using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Windows.Threading;
using DocGen.Explorer.Engine;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Search;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

public enum Section
{
    Repositories,
    Documentation,
    Graph,
    Indexing,
    Learning,
    Studio,
    Talk,
    Personas,
    Usage,
    Help,
    Settings,
    Logs,
}

/// <summary>A modal question shown over the window (confirmation or a one-line prompt).</summary>
public sealed class DialogViewModel : ObservableObject
{
    private readonly TaskCompletionSource<string?> _result = new();
    private string _input = "";

    public string Title { get; init; } = "";
    public string Message { get; init; } = "";
    public string? Detail { get; init; }
    public string ConfirmText { get; init; } = "OK";
    public string CancelText { get; init; } = "Cancel";
    public bool IsDanger { get; init; }
    public bool HasInput { get; init; }
    public string InputLabel { get; init; } = "";

    /// <summary>Suggestions listed under the text box (a click fills it in); the text can still be typed.</summary>
    public IReadOnlyList<string> Choices { get; init; } = [];
    public bool HasChoices => Choices.Count > 0;
    public string? ChoicesNote { get; init; }

    public string? SelectedChoice
    {
        get => Choices.Contains(Input) ? Input : null;
        set
        {
            if (value is not null)
            {
                Input = value;
                Notify(nameof(SelectedChoice));
            }
        }
    }

    public string Input
    {
        get => _input;
        set => Set(ref _input, value);
    }

    public Task<string?> Result => _result.Task;

    public ICommand ConfirmCommand => new RelayCommand(() => _result.TrySetResult(HasInput ? Input : "ok"));
    public ICommand CancelCommand => new RelayCommand(() => _result.TrySetResult(null));
}

public sealed class MainViewModel : ObservableObject
{
    private Section _section = Section.Repositories;
    private WorkspaceViewModel? _workspace;
    private object? _currentPage;
    private string _searchQuery = "";
    private bool _isSearchOpen;
    private bool _focusSearch;
    private string _themeMode = "auto";
    private bool _reduceMotion;
    private bool _treeVisible = true;
    private string _paneOrder = PaneLayout.Default;
    private bool _assistantVisible = true;
    private bool _assistantExpanded;
    private bool _isNarrow;
    private bool _isCompact;
    private bool _sectionsMenuOpen;
    private string? _toastMessage;
    private bool _toastIsError;
    private DialogViewModel? _dialog;
    private readonly DispatcherTimer _toastTimer;
    private readonly DispatcherTimer _searchTimer;
    private readonly Dictionary<string, WorkspaceViewModel> _workspaces = new(StringComparer.Ordinal);
    private CancellationTokenSource? _searchCts;

    public MainViewModel(ExplorerEngine engine)
    {
        Engine = engine;
        Speech = new SpeechService();
        Speech.SpeakingChanged += (_, _) => Notify(nameof(IsReadingAloud));
        Speech.PausedChanged += (_, _) => Notify(nameof(ReadingPauseText), nameof(ReadingPauseGlyph));
        Repositories = new RepositoriesViewModel(this);
        Personas = new PersonasViewModel(this);
        Usage = new UsageViewModel(this);
        Logs = new LogsViewModel(this);
        Help = new HelpViewModel(this);
        Settings = new SettingsViewModel(this);
        SpacePicker = new ConfluenceSpacePickerViewModel(this);
        Shortcuts = new ShortcutsViewModel(this);

        _toastTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(4.5) };
        _toastTimer.Tick += (_, _) =>
        {
            _toastTimer.Stop();
            ToastMessage = null;
        };
        _searchTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(140) };
        _searchTimer.Tick += async (_, _) =>
        {
            _searchTimer.Stop();
            await RunSearchAsync();
        };
        Ui.Notifier = ShowToast;

        NavigateCommand = new RelayCommand(p =>
        {
            if (p is string name && Enum.TryParse<Section>(name, out var section))
            {
                Navigate(section);
            }
            CloseMenus();
        });
        ToggleRepositoryMenuCommand = new AsyncCommand(async () =>
        {
            var open = !RepositoryMenuOpen;
            CloseMenus();
            if (open)
            {
                await LoadRepositoryChoicesAsync();
                RepositoryMenuOpen = true;
            }
        });
        ToggleAppMenuCommand = new RelayCommand(() =>
        {
            var open = !AppMenuOpen;
            CloseMenus();
            AppMenuOpen = open;
        });
        AddRepositoryCommand = new RelayCommand(() =>
        {
            CloseMenus();
            Navigate(Section.Repositories);
            Repositories.ShowAddFormCommand.Execute(null);
        });
        GoHomeCommand = new RelayCommand(() => Navigate(Section.Repositories));
        // The toggles never grey out while their choice is saved: it is saved in the background (the last choice wins).
        ToggleThemeCommand = new RelayCommand(() =>
        {
            ThemeMode = ThemeManager.Next(ThemeMode);
            ThemeManager.Apply(ThemeMode);
            var theme = ThemeMode;
            _ = Engine.Models.UpdateExplorerSettingsAsync(s => s.Theme = theme);
        });
        ToggleMotionCommand = new RelayCommand(() =>
        {
            ReduceMotion = !ReduceMotion;
            var reduce = ReduceMotion;
            _ = Engine.Models.UpdateExplorerSettingsAsync(s => s.ReduceMotion = reduce);
            ShowToast(ReduceMotion ? "Motion reduced: answers appear at once." : "Motion on: answers stream as they are written.", false);
        });
        // Shows the Repository panel whatever hid it (closed, or the assistant expanded over it); hides it when it shows.
        ToggleTreeCommand = new RelayCommand(() =>
        {
            if (TreeShown)
            {
                TreeVisible = false;
                return;
            }
            TreeVisible = true;
            AssistantExpanded = false;
            if (IsCompact)
            {
                ShowToast("The window is too narrow for the Repository panel beside the page: widen it, or zoom out (Ctrl+-).", false);
            }
        });
        ZoomInCommand = new RelayCommand(() => ZoomBy(1));
        ZoomOutCommand = new RelayCommand(() => ZoomBy(-1));
        ZoomResetCommand = new RelayCommand(() => ZoomBy(0));
        SendFeedbackCommand = new AsyncCommand(SendFeedbackAsync);
        ToggleAssistantCommand = new RelayCommand(() =>
        {
            AssistantVisible = !AssistantVisible;
            if (!AssistantVisible)
            {
                AssistantExpanded = false;
            }
        });
        ExpandAssistantCommand = new RelayCommand(() =>
        {
            AssistantVisible = true;
            AssistantExpanded = !AssistantExpanded;
        });
        FocusSearchCommand = new RelayCommand(() =>
        {
            FocusSearch = false;
            FocusSearch = true;
        });
        CloseSearchCommand = new RelayCommand(() => IsSearchOpen = false);
        OpenSearchResultCommand = new RelayCommand(p =>
        {
            if (p is SearchHit hit)
            {
                OpenSearchHit(hit);
            }
        });
        OpenFirstSearchResultCommand = new AsyncCommand(async () =>
        {
            _searchTimer.Stop();
            await RunSearchAsync();
            if (SearchResults.FirstOrDefault() is { } first)
            {
                OpenSearchHit(first);
            }
        });
        DismissToastCommand = new RelayCommand(() => ToastMessage = null);
        ToggleSectionsMenuCommand = new RelayCommand(() => SectionsMenuOpen = !SectionsMenuOpen);
        BackCommand = new RelayCommand(() => Workspace?.Documentation.Back(), () => Workspace?.Documentation.CanGoBack == true);
        ForwardCommand = new RelayCommand(() => Workspace?.Documentation.Forward(), () => Workspace?.Documentation.CanGoForward == true);

        Engine.Indexing.Completed += (_, e) => Ui.Post(() => OnIndexCompleted(e));
    }

    public ExplorerEngine Engine { get; }

    /// <summary>Prism's event aggregator (set by the application; a private one when the view model stands alone, as in tests).</summary>
    public Prism.Events.IEventAggregator Events { get; set; } = new Prism.Events.EventAggregator();

    /// <summary>Window layout: back to the standard arrangement (in the chosen pane order), lock or unlock it, bring a panel back.</summary>
    public ICommand ResetLayoutCommand => new RelayCommand(() => Events.GetEvent<Infrastructure.Docking.LayoutCommandEvent>().Publish("reset:" + PaneOrder));

    public ICommand ToggleLayoutLockCommand => new RelayCommand(() => Events.GetEvent<Infrastructure.Docking.LayoutCommandEvent>().Publish("toggle-lock"));

    public ICommand DockPanelCommand => new RelayCommand(p => Events.GetEvent<Infrastructure.Docking.LayoutCommandEvent>().Publish(p as string ?? ""));

    public SpeechService Speech { get; }

    // ----- Dictation: the microphone button shows in Ask only when it can be used -----

    private bool _dictationEnabled = true;

    /// <summary>Dictation is turned on (Settings → Voice) and a microphone can be used: the microphone button shows.</summary>
    public bool CanDictate => _dictationEnabled && Microphone.Unavailable() is null;

    /// <summary>Turns dictation on or off (Settings → Voice), and looks again for a microphone.</summary>
    public void SetDictation(bool enabled)
    {
        _dictationEnabled = enabled;
        RefreshMicrophone();
    }

    /// <summary>Looks again whether a microphone can be used (one may be plugged in or allowed meanwhile).</summary>
    public void RefreshMicrophone() => Notify(nameof(CanDictate));

    // ----- Reading aloud: Pause and Stop, always in view while something is read -----

    /// <summary>Whether something is being read aloud (the reading bar is shown).</summary>
    public bool IsReadingAloud => Speech.IsSpeaking;

    public string ReadingPauseText => Speech.IsPaused ? "Resume" : "Pause";

    public string ReadingPauseGlyph => Speech.IsPaused ? Icons.Play : Icons.Pause;

    public ICommand ReadingPauseCommand => new RelayCommand(() =>
    {
        if (Speech.IsPaused)
        {
            Speech.Resume();
        }
        else
        {
            Speech.Pause();
        }
    });

    public ICommand ReadingStopCommand => new RelayCommand(Speech.Stop);
    public RepositoriesViewModel Repositories { get; }
    public PersonasViewModel Personas { get; }
    public UsageViewModel Usage { get; }

    /// <summary>The log viewer (app menu → Logs).</summary>
    public LogsViewModel Logs { get; }
    public HelpViewModel Help { get; }
    public SettingsViewModel Settings { get; }

    /// <summary>The spaces on the Confluence sites, ticked for the open repository (Settings → Confluence and Indexing).</summary>
    public ConfluenceSpacePickerViewModel SpacePicker { get; }

    private string _talkPersonaId = DocGen.Explorer.Engine.Assistant.TalkPersonas.DefaultId;

    /// <summary>Talk's persona, remembered across repositories and restarts.</summary>
    public string TalkPersonaId
    {
        get => _talkPersonaId;
        set
        {
            if (DocGen.Explorer.Engine.Assistant.TalkPersonas.Find(value) is not null && Set(ref _talkPersonaId, value))
            {
                _ = this.Engine.Models.UpdateExplorerSettingsAsync(s => s.TalkPersona = value);
            }
        }
    }

    /// <summary>The keyboard shortcuts (Settings → Shortcuts); the window binds them.</summary>
    public ShortcutsViewModel Shortcuts { get; }

    public ICommand NavigateCommand { get; }
    public ICommand GoHomeCommand { get; }
    public ICommand ToggleThemeCommand { get; }
    public ICommand ToggleMotionCommand { get; }
    public ICommand ToggleTreeCommand { get; }

    /// <summary>Summarise the text selected in a page or an answer (where the keyboard focus is).</summary>
    public ICommand SummariseSelectionCommand { get; } = new RelayCommand(() => _ = SummariseSelection.SummariseAsync());
    public ICommand ZoomInCommand { get; }
    public ICommand ZoomOutCommand { get; }
    public ICommand ZoomResetCommand { get; }
    public ICommand SendFeedbackCommand { get; }

    /// <summary>
    /// Send feedback: the windows are pictured first (before the dialog covers them), then the person says what went
    /// wrong, and a zip with the pictures, the details and the recent logs is made in C:\DocGen-Feedback.
    /// </summary>
    private async Task SendFeedbackAsync()
    {
        AppMenuOpen = false;
        await System.Windows.Threading.Dispatcher.Yield(DispatcherPriority.ApplicationIdle); // the menu is gone from the pictures
        var screenshots = FeedbackReport.CaptureWindows();
        var description = await PromptAsync("Send feedback", "What went wrong, or what should be better? (optional)", "", "Create the feedback file",
            message: $"A zip file is made in {FeedbackReport.Folder} with a picture of the window, what you write here, the version, "
                   + "the explorer's settings and its recent logs. Keys and tokens are never included. Send the file to your DocGen team.");
        if (description is null)
        {
            return;
        }
        try
        {
            var path = await FeedbackReport.CreateAsync(this, description, screenshots);
            ShowToast($"Feedback saved: {path}", false);
            try
            {
                System.Diagnostics.Process.Start("explorer.exe", $"/select,\"{path}\"");
            }
            catch (System.ComponentModel.Win32Exception)
            {
                // The file is saved; showing it in Explorer is a convenience.
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or InvalidDataException)
        {
            Logging.Error(ex, "Send feedback");
            ShowToast("The feedback file could not be made: " + ex.Message, true);
        }
    }
    public ICommand ToggleAssistantCommand { get; }
    public ICommand ExpandAssistantCommand { get; }
    public ICommand FocusSearchCommand { get; }
    public ICommand CloseSearchCommand { get; }
    public ICommand OpenSearchResultCommand { get; }
    public ICommand OpenFirstSearchResultCommand { get; }
    public ICommand DismissToastCommand { get; }
    public ICommand ToggleSectionsMenuCommand { get; }
    public ICommand ToggleRepositoryMenuCommand { get; }
    public ICommand ToggleAppMenuCommand { get; }
    public ICommand AddRepositoryCommand { get; }

    private bool _repositoryMenuOpen;
    private bool _appMenuOpen;

    /// <summary>The repository menu (switch repository, indexing, all repositories, add one) is open.</summary>
    public bool RepositoryMenuOpen
    {
        get => _repositoryMenuOpen;
        set => Set(ref _repositoryMenuOpen, value);
    }

    /// <summary>The app menu (settings, usage, personas, help, theme, motion) is open.</summary>
    public bool AppMenuOpen
    {
        get => _appMenuOpen;
        set => Set(ref _appMenuOpen, value);
    }

    public System.Collections.ObjectModel.ObservableCollection<RepositoryChoice> RepositoryChoices { get; } = [];

    /// <summary>The page on show lives in the app menu (Settings, Usage, Personas, Help): its button is highlighted.</summary>
    public bool IsAppSection => Section is Section.Settings or Section.Usage or Section.Help or Section.Logs;

    public string ThemeMenuText => ThemeMode switch { "light" => "Theme: light", "dark" => "Theme: dark", _ => "Theme: follow Windows" };
    public string MotionMenuText => ReduceMotion ? "Motion: reduced" : "Motion: on";

    public void CloseMenus()
    {
        SectionsMenuOpen = false;
        RepositoryMenuOpen = false;
        AppMenuOpen = false;
    }

    private async Task LoadRepositoryChoicesAsync()
    {
        RepositoryChoices.Clear();
        foreach (var record in (await Engine.Repositories.ListAsync()).OrderBy(r => r.Title, StringComparer.CurrentCultureIgnoreCase))
        {
            var current = Workspace?.Record.Id == record.Id;
            RepositoryChoices.Add(new RepositoryChoice(record, current, new AsyncCommand(async () =>
            {
                CloseMenus();
                // Switching keeps the section when the other repository has it too.
                var section = Section is Section.Documentation or Section.Graph or Section.Indexing or Section.Learning or Section.Studio or Section.Talk ? Section : Section.Documentation;
                await OpenRepositoryAsync(record, section);
            })));
        }
    }
    public ICommand BackCommand { get; }
    public ICommand ForwardCommand { get; }

    public ObservableCollection<SearchHit> SearchResults { get; } = [];

    public Section Section
    {
        get => _section;
        private set
        {
            if (Set(ref _section, value))
            {
                Notify(nameof(IsRepositorySection), nameof(ShowPanes), nameof(ShowTreePane), nameof(ShowAssistantPane), nameof(ShowContentPane), nameof(SectionName), nameof(ShowAssistantButton), nameof(IsAppSection));
            }
        }
    }

    public string SectionName => Section.ToString();

    public WorkspaceViewModel? Workspace
    {
        get => _workspace;
        private set
        {
            if (Set(ref _workspace, value))
            {
                Notify(nameof(HasWorkspace), nameof(RepositoryTitle));
            }
        }
    }

    public bool HasWorkspace => Workspace is not null;

    public string RepositoryTitle => Workspace?.Title ?? "";

    public object? CurrentPage
    {
        get => _currentPage;
        private set => Set(ref _currentPage, value);
    }

    public bool IsRepositorySection => Workspace is not null && Section is Section.Documentation or Section.Graph or Section.Indexing or Section.Learning or Section.Studio or Section.Talk;

    /// <summary>The documentation tree and the assistant sit beside these sections.</summary>
    public bool ShowPanes => Workspace is not null && Section is Section.Documentation or Section.Learning or Section.Studio;

    public bool ShowTreePane => ShowPanes && TreeVisible && !AssistantExpanded && !IsCompact;
    public bool ShowAssistantPane => ShowPanes && AssistantVisible && !IsNarrow;
    public bool ShowContentPane => !(ShowPanes && AssistantExpanded && AssistantVisible);

    /// <summary>The header's assistant button shows only while the assistant is hidden (it has its own close button).</summary>
    public bool ShowAssistantButton => ShowPanes && !ShowAssistantPane;

    public bool TreeVisible
    {
        get => _treeVisible;
        set
        {
            if (Set(ref _treeVisible, value))
            {
                Notify(nameof(ShowTreePane), nameof(TreeToggleTooltip), nameof(TreeToggleIcon));
                _ = Engine.Models.UpdateExplorerSettingsAsync(s => s.TreeVisible = value);
            }
        }
    }

    /// <summary>The Repository panel is on screen (wanted, and not hidden by the expanded assistant).</summary>
    private bool TreeShown => TreeVisible && !AssistantExpanded;

    public string TreeToggleTooltip => TreeShown ? "Hide the Repository panel (Ctrl+B)" : "Show the Repository panel (Ctrl+B)";

    /// <summary>The order of the panes, left to right ("files,page,ask"); the window lays itself out by it.</summary>
    public string PaneOrder
    {
        get => _paneOrder;
        set
        {
            var order = PaneLayout.Normalize(value);
            if (Set(ref _paneOrder, order))
            {
                Notify(nameof(PaneOrderChoice), nameof(TreeToggleIcon));
                _ = Engine.Models.UpdateExplorerSettingsAsync(s => s.PaneOrder = order);
            }
        }
    }

    /// <summary>The interface's size (1 = 100%); the window and its pop-ups scale by it.</summary>
    public double Zoom
    {
        get => UiZoom.Level;
        set
        {
            var level = UiZoom.Nearest(value);
            if (Math.Abs(level - UiZoom.Level) < 0.001)
            {
                return;
            }
            UiZoom.Apply(level);
            Notify(nameof(Zoom), nameof(ZoomChoice));
            _ = Engine.Models.UpdateExplorerSettingsAsync(s => s.Zoom = level);
        }
    }

    public IReadOnlyList<string> ZoomChoices { get; } = UiZoom.Levels.Select(UiZoom.Label).ToList();

    /// <summary>The size by name (Settings → Appearance), e.g. "110%".</summary>
    public string ZoomChoice
    {
        get => UiZoom.Label(Zoom);
        set
        {
            if (UiZoom.Levels.FirstOrDefault(l => UiZoom.Label(l) == value) is var level and > 0)
            {
                Zoom = level;
            }
        }
    }

    private void ZoomBy(int direction)
    {
        Zoom = direction == 0 ? 1.0 : UiZoom.Step(Zoom, direction);
        ShowToast($"Size {UiZoom.Label(Zoom)}  ·  Ctrl+= larger, Ctrl+- smaller, Ctrl+0 reset", false);
    }


    public IReadOnlyList<string> PaneOrderChoices { get; } = PaneLayout.Choices.Select(c => c.Label).ToList();

    /// <summary>The arrangement by name (Settings → Appearance).</summary>
    public string PaneOrderChoice
    {
        get => PaneLayout.Choices.FirstOrDefault(c => c.Order == PaneOrder).Label ?? PaneLayout.Choices[0].Label;
        set
        {
            if (PaneLayout.Choices.FirstOrDefault(c => c.Label == value) is { Order: { } order })
            {
                PaneOrder = order;
            }
        }
    }

    /// <summary>The list button shows what a click does: "close pane" while the list shows, "open pane" while hidden.</summary>
    /// <summary>
    /// The arrow points the way the list will move: towards its edge to hide it when it is shown, away from the edge to
    /// bring it back — mirrored when the files list is on the right of the page (Settings → Appearance → Arrangement).
    /// </summary>
    public string TreeToggleIcon
    {
        get
        {
            var order = PaneLayout.Parse(PaneOrder);
            var onLeft = Array.IndexOf(order, PaneLayout.Files) < Array.IndexOf(order, PaneLayout.Page);
            return TreeShown == onLeft ? Icons.OpenPane : Icons.ClosePane;
        }
    }

    public bool AssistantVisible
    {
        get => _assistantVisible;
        set
        {
            if (Set(ref _assistantVisible, value))
            {
                Notify(nameof(ShowAssistantPane), nameof(ShowContentPane), nameof(ShowTreePane), nameof(ShowAssistantButton));
                _ = Engine.Models.UpdateExplorerSettingsAsync(s => s.AssistantVisible = value);
            }
        }
    }

    public bool AssistantExpanded
    {
        get => _assistantExpanded;
        set
        {
            if (Set(ref _assistantExpanded, value))
            {
                Notify(nameof(ShowContentPane), nameof(ShowTreePane), nameof(AssistantExpandTooltip), nameof(TreeToggleTooltip), nameof(TreeToggleIcon));
            }
        }
    }

    public string AssistantExpandTooltip => AssistantExpanded ? "Return the assistant to the side" : "Expand the assistant to full width";

    /// <summary>Below ~1100 px the assistant folds away (its button stays in the header).</summary>
    public bool IsNarrow
    {
        get => _isNarrow;
        set
        {
            if (Set(ref _isNarrow, value))
            {
                Notify(nameof(ShowAssistantPane), nameof(ShowAssistantButton));
            }
        }
    }

    /// <summary>Below ~860 px the tree folds too and the sections move behind one menu button.</summary>
    public bool IsCompact
    {
        get => _isCompact;
        set
        {
            if (Set(ref _isCompact, value))
            {
                Notify(nameof(ShowTreePane), nameof(ShowSectionsMenu));
            }
        }
    }

    private bool _navCollapsed;

    /// <summary>The header sections did not fit: they sit behind the menu button.</summary>
    public bool NavCollapsed
    {
        get => _navCollapsed;
        set
        {
            if (Set(ref _navCollapsed, value))
            {
                OnPropertyChanged(nameof(ShowSectionsMenu));
            }
        }
    }

    public bool ShowSectionsMenu => NavCollapsed || IsCompact;

    public bool SectionsMenuOpen
    {
        get => _sectionsMenuOpen;
        set => Set(ref _sectionsMenuOpen, value);
    }

    public string ThemeMode
    {
        get => _themeMode;
        private set
        {
            if (Set(ref _themeMode, value))
            {
                Notify(nameof(ThemeGlyph), nameof(ThemeTooltip), nameof(ThemeMenuText));
            }
        }
    }

    public string ThemeGlyph => ThemeMode switch { "light" => Icons.Sun, "dark" => Icons.Moon, _ => Icons.Auto };
    public string ThemeTooltip => "Switch theme\n" + ThemeManager.Describe(ThemeMode);

    public bool ReduceMotion
    {
        get => _reduceMotion;
        private set
        {
            if (Set(ref _reduceMotion, value))
            {
                Avatars.AvatarFace.ReduceMotion = value; // persona faces stop blinking and talking
                Notify(nameof(MotionTooltip), nameof(MotionGlyph), nameof(MotionMenuText));
            }
        }
    }

    public string MotionGlyph => ReduceMotion ? Icons.MotionOff : Icons.Motion;
    public string MotionTooltip => ReduceMotion ? "Motion: reduced (answers appear at once)" : "Motion: on (answers stream as they are written)";

    public string SearchQuery
    {
        get => _searchQuery;
        set
        {
            if (Set(ref _searchQuery, value))
            {
                _searchTimer.Stop();
                _searchTimer.Start();
            }
        }
    }

    public bool IsSearchOpen
    {
        get => _isSearchOpen;
        set => Set(ref _isSearchOpen, value);
    }

    public bool FocusSearch
    {
        get => _focusSearch;
        set => Set(ref _focusSearch, value);
    }

    public string? ToastMessage
    {
        get => _toastMessage;
        private set => Set(ref _toastMessage, value);
    }

    public bool ToastIsError
    {
        get => _toastIsError;
        private set => Set(ref _toastIsError, value);
    }

    public DialogViewModel? Dialog
    {
        get => _dialog;
        private set => Set(ref _dialog, value);
    }

    public void ShowToast(string message, bool isError)
    {
        ToastIsError = isError;
        ToastMessage = message;
        _toastTimer.Stop();
        _toastTimer.Interval = TimeSpan.FromSeconds(isError ? 8 : 4);
        _toastTimer.Start();
    }

    /// <summary>Skills were turned on or off, imported or removed: the composers' skill pickers follow.</summary>
    public void OnSkillsChanged()
    {
        foreach (var workspace in _workspaces.Values)
        {
            _ = workspace.Assistant.LoadSkillsAsync();
        }
    }

    public async Task<bool> ConfirmAsync(string title, string message, string? detail, string confirmText, bool danger = true)
    {
        var dialog = new DialogViewModel { Title = title, Message = message, Detail = detail, ConfirmText = confirmText, IsDanger = danger };
        Dialog = dialog;
        var result = await dialog.Result;
        Dialog = null;
        return result is not null;
    }

    public async Task<string?> PromptAsync(string title, string label, string initial, string confirmText = "Save",
        string? message = null, IReadOnlyList<string>? choices = null, string? choicesNote = null, bool danger = false)
    {
        var dialog = new DialogViewModel
        {
            Title = title, Message = message ?? "", InputLabel = label, Input = initial, HasInput = true, ConfirmText = confirmText,
            Choices = choices ?? [], ChoicesNote = choicesNote, IsDanger = danger,
        };
        Dialog = dialog;
        var result = await dialog.Result;
        Dialog = null;
        return result;
    }

    /// <summary>Ollama and the like list their own models: ask them in the background once the window is up.</summary>
    private async Task DiscoverModelsAtStartAsync()
    {
        try
        {
            if ((await Engine.Models.DiscoverModelsAsync()).Count > 0 && Workspace is { } workspace)
            {
                await workspace.Assistant.LoadAsync();
            }
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            Logging.Error(ex, "Finding models at start");
        }
    }

    public async Task StartAsync()
    {
        var settings = await Engine.Models.GetExplorerSettingsAsync();
        ThemeMode = settings.Theme;
        ReduceMotion = settings.ReduceMotion;
        UiPreferences.Current.Load(settings);
        // Settings → Reading and writing: saved as soon as they change (the views use them live).
        UiPreferences.Current.PropertyChanged += (_, _) => _ = Engine.Models.UpdateExplorerSettingsAsync(UiPreferences.Current.Save);
        Speech.NaturalVoices = settings.NaturalVoices;
        Speech.DefaultVoice = settings.ReadAloudVoice;
        Speech.MicrophoneName = settings.MicrophoneDevice;
        SetDictation(settings.DictationEnabled);
        Speech.DictationOnline = settings.DictationEngine == "online";
        Speech.DictationWhisper = settings.DictationEngine is not ("online" or "offline");
        Speech.WhisperModelId = settings.WhisperModel;
        Speech.MicrophoneToggles = settings.MicrophoneMode != "hold";
        Speech.DictationSends = settings.DictationSends;
        Speech.SilenceStopSeconds = Math.Max(0, settings.SilenceStopSeconds);
        Speech.DictationLanguage = settings.DictationLanguage;
        _treeVisible = settings.TreeVisible;
        _assistantVisible = settings.AssistantVisible;
        _paneOrder = PaneLayout.Normalize(settings.PaneOrder);
        UiZoom.Apply(UiZoom.Nearest(settings.Zoom));
        Shortcuts.Load(settings.Shortcuts);
        _talkPersonaId = DocGen.Explorer.Engine.Assistant.TalkPersonas.Find(settings.TalkPersona)?.Id ?? DocGen.Explorer.Engine.Assistant.TalkPersonas.DefaultId;
        Notify(nameof(Zoom), nameof(ZoomChoice));
        Notify(nameof(TreeVisible), nameof(AssistantVisible), nameof(ShowTreePane), nameof(ShowAssistantPane), nameof(PaneOrder), nameof(PaneOrderChoice));
        await Engine.Indexing.RecoverInterruptedAsync();
        await Repositories.RefreshAsync();
        _ = DiscoverModelsAtStartAsync();
        // Landing: with exactly one repository registered, go straight to its documentation.
        var list = Repositories.All;
        if (list.Count == 1)
        {
            await OpenRepositoryAsync(list[0].Record, Section.Documentation);
        }
        else
        {
            Navigate(Section.Repositories);
        }
    }

    public void Navigate(Section section)
    {
        if (section is Section.Documentation or Section.Graph or Section.Indexing or Section.Learning or Section.Studio or Section.Talk && Workspace is null)
        {
            section = Section.Repositories;
        }
        Section = section;
        IsSearchOpen = false;
        CurrentPage = section switch
        {
            Section.Repositories => Repositories,
            Section.Documentation => Workspace!.Documentation,
            Section.Graph => Workspace!.Graph,
            Section.Indexing => Workspace!.Indexing,
            Section.Learning => Workspace!.Learning,
            Section.Studio => Workspace!.Studio,
            Section.Talk => Workspace!.Talk,
            Section.Personas => Personas,
            Section.Usage => Usage,
            Section.Logs => Logs,
            Section.Help => Help,
            Section.Settings => Settings,
            _ => Repositories,
        };
        if (CurrentPage is IActivatable activatable)
        {
            _ = activatable.ActivateAsync();
        }
        if (section == Section.Talk)
        {
            _ = Workspace!.Talk.EnsureLoadedAsync();
        }
        Workspace?.Tree.SetSelectionModeHint(section is Section.Learning or Section.Studio);
    }

    public async Task OpenRepositoryAsync(RepositoryRecord record, Section section = Section.Documentation)
    {
        if (!_workspaces.TryGetValue(record.Id, out var workspace))
        {
            workspace = new WorkspaceViewModel(this, record);
            _workspaces[record.Id] = workspace;
        }
        Workspace = workspace;
        await Engine.Models.UpdateExplorerSettingsAsync(s => s.LastRepositoryId = record.Id);
        Navigate(section);
        await workspace.LoadAsync();
        if (Section == section)
        {
            Navigate(section); // re-activate now that the index is loaded
        }
    }

    public void ForgetWorkspace(string repositoryId)
    {
        _workspaces.Remove(repositoryId);
        if (Workspace?.Record.Id == repositoryId)
        {
            Workspace = null;
            Navigate(Section.Repositories);
        }
    }

    private void OnIndexCompleted(IndexProgress progress)
    {
        _ = Repositories.RefreshAsync();
        if (_workspaces.TryGetValue(progress.RepositoryId, out var workspace))
        {
            _ = workspace.OnIndexCompletedAsync(progress.Run);
        }
        var title = _workspaces.GetValueOrDefault(progress.RepositoryId)?.Title ?? "The repository";
        switch (progress.Run.State)
        {
            case RunState.Completed:
                ShowToast($"{title} is indexed.", false);
                break;
            case RunState.Failed:
                ShowToast($"Indexing {title} failed: {progress.Run.Error}", true);
                break;
        }
    }

    private async Task RunSearchAsync()
    {
        var query = SearchQuery.Trim();
        _searchCts?.Cancel();
        if (query.Length < 2 || Workspace?.Index is not { } index)
        {
            SearchResults.Clear();
            IsSearchOpen = false;
            return;
        }
        var cts = _searchCts = new CancellationTokenSource();
        List<SearchHit> hits;
        try
        {
            hits = await Task.Run(() => SearchEngine.Search(index, query, 30), cts.Token);
        }
        catch (OperationCanceledException)
        {
            return;
        }
        if (cts.IsCancellationRequested)
        {
            return;
        }
        SearchResults.Clear();
        foreach (var hit in hits)
        {
            SearchResults.Add(hit);
        }
        IsSearchOpen = true;
    }

    private void OpenSearchHit(SearchHit hit)
    {
        IsSearchOpen = false;
        if (Workspace is null)
        {
            return;
        }
        if (Section != Section.Documentation)
        {
            Navigate(Section.Documentation);
        }
        if (hit.PageId is not null)
        {
            var anchor = Workspace.Index?.FindPage(hit.PageId)?.Headings.FirstOrDefault(h => h.Line == hit.Line)?.Anchor;
            Workspace.Documentation.OpenPage(hit.PageId, anchor);
        }
        else
        {
            Workspace.Documentation.OpenFile(hit.Path, hit.Line);
        }
    }
}

/// <summary>A page that refreshes itself when shown.</summary>
public interface IActivatable
{
    Task ActivateAsync();
}
