using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Windows.Input;
using DocGen.Explorer.Engine.Confluence;
using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>A sign-in choice for a site, with its description.</summary>
public sealed record ConfluenceAuthChoice(string Kind, string Label);

/// <summary>One Confluence site on Settings → Confluence.</summary>
public sealed class ConfluenceSiteViewModel : ObservableObject
{
    private readonly ConfluenceSettingsViewModel _owner;
    private string _name;
    private string _baseUrl;
    private ConfluenceAuthChoice _auth;
    private string _email;
    private string _apiToken;
    private string _personalAccessToken;
    private bool _showToken;
    private bool _isExpanded;
    private bool _isTesting;
    private string? _testResult;
    private bool _testPassed;

    public ConfluenceSiteViewModel(ConfluenceSite site, ConfluenceSettingsViewModel owner, bool expanded = false)
    {
        _owner = owner;
        Id = site.Id;
        _name = site.Name;
        _baseUrl = site.BaseUrl;
        _auth = ConfluenceSettingsViewModel.AuthChoices.FirstOrDefault(c => c.Kind == site.Auth) ?? ConfluenceSettingsViewModel.AuthChoices[0];
        _email = site.Email;
        _apiToken = site.ApiToken;
        _personalAccessToken = site.PersonalAccessToken;
        _isExpanded = expanded;
        TestCommand = new AsyncCommand(TestAsync, () => !IsTesting);
        RemoveCommand = new AsyncCommand(() => owner.RemoveAsync(this));
        ToggleTokenCommand = new RelayCommand(() => ShowToken = !ShowToken);
        OpenTokenPageCommand = new RelayCommand(() => Open(IsCloud ? "https://id.atlassian.com/manage-profile/security/api-tokens" : BaseUrl.TrimEnd('/') + "/plugins/personalaccesstokens/usertokens.action"));
    }

    public string Id { get; }

    public string Name { get => _name; set { if (Set(ref _name, value)) { Changed(); } } }

    public string BaseUrl { get => _baseUrl; set { if (Set(ref _baseUrl, value)) { Changed(); } } }

    public ConfluenceAuthChoice Auth
    {
        get => _auth;
        set
        {
            if (value is not null && Set(ref _auth, value))
            {
                Notify(nameof(IsCloud), nameof(IsToken));
                Changed();
            }
        }
    }

    public string Email { get => _email; set { if (Set(ref _email, value)) { Changed(); } } }
    public string ApiToken { get => _apiToken; set { if (Set(ref _apiToken, value)) { Changed(); } } }
    public string PersonalAccessToken { get => _personalAccessToken; set { if (Set(ref _personalAccessToken, value)) { Changed(); } } }

    public bool IsCloud => Auth.Kind == ConfluenceAuth.Cloud;
    public bool IsToken => Auth.Kind == ConfluenceAuth.Token;

    public bool ShowToken { get => _showToken; set => Set(ref _showToken, value); }
    public bool IsExpanded { get => _isExpanded; set => Set(ref _isExpanded, value); }

    public bool IsTesting
    {
        get => _isTesting;
        private set
        {
            if (Set(ref _isTesting, value))
            {
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    public string? TestResult { get => _testResult; private set => Set(ref _testResult, value); }
    public bool TestPassed { get => _testPassed; private set => Set(ref _testPassed, value); }

    /// <summary>The token being edited, masked unless shown.</summary>
    public string MaskedToken => Mask(IsCloud ? ApiToken : PersonalAccessToken);

    public string Title => string.IsNullOrWhiteSpace(Name) ? (string.IsNullOrWhiteSpace(BaseUrl) ? "New site" : BaseUrl) : Name;

    /// <summary>Nothing has been typed into this site (it is not saved).</summary>
    public bool IsBlank => (string.IsNullOrWhiteSpace(BaseUrl) || BaseUrl.Trim() == "https://") && string.IsNullOrWhiteSpace(Name)
        && string.IsNullOrWhiteSpace(Email) && string.IsNullOrWhiteSpace(ApiToken) && string.IsNullOrWhiteSpace(PersonalAccessToken);

    public string Summary
    {
        get
        {
            var site = ToSite();
            var sign = Auth.Kind switch
            {
                ConfluenceAuth.Cloud => site.HasCredentials ? $"Cloud · {Email}" : "Cloud · no sign-in yet",
                ConfluenceAuth.Token => site.HasCredentials ? "Personal access token" : "No token yet",
                _ => "No sign-in",
            };
            if (IsBlank)
            {
                return "Type the site's address, then the sign-in below, and Save";
            }
            var used = _owner.SpacesUsing(BaseUrl);
            return $"{BaseUrl} · {sign} · {(used.Count == 0 ? "no spaces yet" : $"used by {string.Join(", ", used)}")}";
        }
    }

    public ICommand TestCommand { get; }
    public ICommand RemoveCommand { get; }
    public ICommand ToggleTokenCommand { get; }
    public ICommand OpenTokenPageCommand { get; }

    public ConfluenceSite ToSite() => new()
    {
        Id = Id,
        Name = Name,
        BaseUrl = BaseUrl,
        Auth = Auth.Kind,
        Email = Email,
        ApiToken = ApiToken,
        PersonalAccessToken = PersonalAccessToken,
    };

    private void Changed()
    {
        TestResult = null;
        Notify(nameof(Title), nameof(Summary), nameof(MaskedToken));
        _owner.MarkDirty();
    }

    private async Task TestAsync()
    {
        IsTesting = true;
        TestResult = "Testing…";
        try
        {
            var result = await _owner.Main.Engine.Confluence.TestAsync(ToSite());
            TestPassed = result.Ok;
            TestResult = (result.Ok ? "✓ " : "✕ ") + result.Message;
        }
        finally
        {
            IsTesting = false;
        }
    }

    private static string Mask(string token)
        => token.Length == 0 ? "No token — choose Show / edit to paste one" : token.Length <= 8 ? new string('•', token.Length) : token[..4] + new string('•', 8) + token[^4..];

    private static void Open(string url)
    {
        try
        {
            Process.Start(new ProcessStartInfo(url) { UseShellExecute = true });
        }
        catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or InvalidOperationException)
        {
            Ui.Notify("The page could not be opened: " + url);
        }
    }
}

/// <summary>Settings → Confluence: the sites spaces are read from, their sign-in, and how much a sync reads.</summary>
public sealed class ConfluenceSettingsViewModel : ObservableObject
{
    public static readonly IReadOnlyList<ConfluenceAuthChoice> AuthChoices = ConfluenceAuth.All.Select(k => new ConfluenceAuthChoice(k, ConfluenceAuth.Describe(k))).ToList();

    private bool _loading;
    private bool _isDirty;
    private string _status = "";
    private string _maxPages = "500";
    private string _timeout = "60";
    private List<(string Repository, string BaseUrl, string Key)> _spaces = [];

    public ConfluenceSettingsViewModel(MainViewModel main)
    {
        Main = main;
        AddSiteCommand = new RelayCommand(() =>
        {
            Sites.Add(new ConfluenceSiteViewModel(new ConfluenceSite { BaseUrl = "https://" }, this, expanded: true));
            Notify(nameof(HasSites), nameof(NoSites));
            MarkDirty();
        });
        SaveCommand = new AsyncCommand(SaveAsync);
        RevertCommand = new AsyncCommand(LoadAsync, () => IsDirty);
        OpenFileCommand = new RelayCommand(() =>
        {
            if (File.Exists(FilePath))
            {
                Process.Start(new ProcessStartInfo("notepad.exe", $"\"{FilePath}\"") { UseShellExecute = true });
            }
        });
    }

    public MainViewModel Main { get; }
    public ObservableCollection<ConfluenceSiteViewModel> Sites { get; } = [];
    public bool HasSites => Sites.Count > 0;
    public bool NoSites => Sites.Count == 0;

    public ICommand AddSiteCommand { get; }
    public ICommand SaveCommand { get; }
    public ICommand RevertCommand { get; }
    public ICommand OpenFileCommand { get; }

    public string FilePath => Main.Engine.Store.Full(ConfluenceSettingsService.Path);

    public string MaxPages { get => _maxPages; set { if (Set(ref _maxPages, value)) { MarkDirty(); } } }
    public string TimeoutSeconds { get => _timeout; set { if (Set(ref _timeout, value)) { MarkDirty(); } } }

    public bool IsDirty
    {
        get => _isDirty;
        private set
        {
            if (Set(ref _isDirty, value))
            {
                DirtyChanged?.Invoke(value);
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    /// <summary>Unsaved changes appeared or were saved (the sidebar shows a dot).</summary>
    public event Action<bool>? DirtyChanged;

    public string Status { get => _status; private set => Set(ref _status, value); }

    /// <summary>The spaces, across repositories, that a site serves (for its summary).</summary>
    public List<string> SpacesUsing(string baseUrl)
    {
        string site;
        try
        {
            site = ConfluenceSettingsService.NormalizeBaseUrl(baseUrl).TrimEnd('/') + "/";
        }
        catch (ExplorerValidationException)
        {
            return [];
        }
        return _spaces.Where(s => (s.BaseUrl.TrimEnd('/') + "/").StartsWith(site, StringComparison.OrdinalIgnoreCase))
            .Select(s => $"{s.Repository} ({s.Key})").Distinct().ToList();
    }

    public void MarkDirty()
    {
        if (!_loading)
        {
            IsDirty = true;
            Status = "Unsaved changes.";
        }
    }

    public async Task LoadAsync()
    {
        _loading = true;
        try
        {
            _spaces = [];
            foreach (var repository in await Main.Engine.Repositories.ListAsync())
            {
                foreach (var url in repository.ConfluenceSpaces)
                {
                    try
                    {
                        var space = ConfluenceService.ParseSpaceUrl(url);
                        _spaces.Add((repository.Title, space.BaseUrl, space.SpaceKey));
                    }
                    catch (ExplorerValidationException)
                    {
                    }
                }
            }
            var document = await Main.Engine.Confluence.Settings.GetAsync();
            Sites.Clear();
            foreach (var site in document.Sites)
            {
                Sites.Add(new ConfluenceSiteViewModel(site, this));
            }
            // With no site yet, an empty one is open to fill in — address, email and token — without pressing Add site.
            if (Sites.Count == 0)
            {
                Sites.Add(new ConfluenceSiteViewModel(new ConfluenceSite(), this, expanded: true));
            }
            MaxPages = document.MaxPagesPerSpace.ToString();
            TimeoutSeconds = document.TimeoutSeconds.ToString();
            Notify(nameof(HasSites), nameof(NoSites), nameof(FilePath), nameof(UnmatchedSpaces), nameof(HasUnmatchedSpaces));
            IsDirty = false;
            Status = File.Exists(FilePath) ? $"Saved in {FilePath} (encrypted for your Windows account)." : "Nothing saved yet.";
        }
        finally
        {
            _loading = false;
        }
    }

    /// <summary>Spaces added to repositories whose site is not listed here (they are read with the environment's sign-in, if any).</summary>
    public string UnmatchedSpaces
    {
        get
        {
            var sites = Sites.Select(s => { try { return ConfluenceSettingsService.NormalizeBaseUrl(s.BaseUrl).TrimEnd('/') + "/"; } catch (ExplorerValidationException) { return null; } })
                .OfType<string>().ToList();
            var missing = _spaces.Where(s => !sites.Any(site => (s.BaseUrl.TrimEnd('/') + "/").StartsWith(site, StringComparison.OrdinalIgnoreCase)))
                .Select(s => s.BaseUrl).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            return missing.Count == 0 ? "" : $"Spaces from {string.Join(", ", missing)} have no site here yet; add it so they can be read.";
        }
    }

    public bool HasUnmatchedSpaces => UnmatchedSpaces.Length > 0;

    public async Task RemoveAsync(ConfluenceSiteViewModel site)
    {
        var used = SpacesUsing(site.BaseUrl);
        if (!await Main.ConfirmAsync($"Remove {site.Title}?",
                used.Count == 0 ? "Its sign-in is forgotten when you save." : $"Its sign-in is forgotten when you save; {string.Join(", ", used)} can then no longer be synced.",
                null, "Remove"))
        {
            return;
        }
        Sites.Remove(site);
        Notify(nameof(HasSites), nameof(NoSites), nameof(UnmatchedSpaces), nameof(HasUnmatchedSpaces));
        MarkDirty();
    }

    private async Task SaveAsync()
    {
        if (!int.TryParse(MaxPages.Trim(), out var maxPages) || !int.TryParse(TimeoutSeconds.Trim(), out var timeout))
        {
            Status = "Pages per space and the timeout are whole numbers.";
            return;
        }
        var document = new ConfluenceSettingsDocument
        {
            Sites = Sites.Where(s => !s.IsBlank).Select(s => s.ToSite()).ToList(),
            MaxPagesPerSpace = maxPages,
            TimeoutSeconds = timeout,
        };
        try
        {
            await Main.Engine.Confluence.Settings.SaveAsync(document);
            await LoadAsync();
            // The sites changed: ask them for their spaces again.
            _ = Main.SpacePicker.LoadAsync();
            Ui.Notify("Confluence settings saved.");
        }
        catch (ExplorerValidationException ex)
        {
            Status = ex.Message;
        }
    }
}
