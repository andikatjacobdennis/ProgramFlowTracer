using System.Collections.ObjectModel;
using System.Windows.Input;
using DocGen.Explorer.Engine.Ai;
using DocGen.Explorer.Infrastructure;

namespace DocGen.Explorer.ViewModels;

/// <summary>
/// One model of an imported provider. What it is comes from the providers file and is read-only here; it can be
/// turned off, used, and tested.
/// </summary>
public sealed class ModelEditorViewModel : ObservableObject
{
    private readonly ProviderEditorViewModel _provider;
    private bool _enabled;
    private string? _testResult;
    private bool _testing;

    public ModelEditorViewModel(AiModel model, ProviderEditorViewModel provider)
    {
        _provider = provider;
        Model = model;
        _enabled = model.Enabled;
        TestCommand = new AsyncCommand(TestAsync, () => !_testing);
        UseCommand = new AsyncCommand(() => provider.Owner.UseModelAsync(this));
    }

    public AiModel Model { get; }
    public string Id => Model.Id;
    public string ProviderModelId => Model.ProviderModelId;
    public string DisplayName => string.IsNullOrWhiteSpace(Model.DisplayName) ? Model.Id : Model.DisplayName;
    public string Limits => $"{Model.ContextWindow:N0} context · {Model.MaxOutputTokens:N0} output tokens";

    public ICommand TestCommand { get; }
    public ICommand UseCommand { get; }

    public bool Enabled { get => _enabled; set { if (Set(ref _enabled, value)) { _provider.Owner.MarkDirty(); } } }

    public string? TestResult
    {
        get => _testResult;
        private set => Set(ref _testResult, value);
    }

    private async Task TestAsync()
    {
        _testing = true;
        TestResult = "Saving and asking the model…";
        try
        {
            // Test what is on screen (a key just pasted): save first.
            if (!await _provider.Owner.SaveAiAsync(quiet: true))
            {
                TestResult = "Fix the settings first: " + _provider.Owner.AiStatus;
                return;
            }
            var result = await _provider.Owner.Main.Engine.Models.TestAsync(Id);
            TestResult = $"✓ Answered \"{Engine.Text.TextUtil.Truncate(result.Text.Trim(), 40)}\" in {result.DurationMs:N0} ms ({result.InputTokens + result.OutputTokens} tokens).";
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            TestResult = "✕ " + ex.Message;
        }
        finally
        {
            _testing = false;
            CommandManager.InvalidateRequerySuggested();
        }
    }
}

/// <summary>
/// One provider from the providers file. Its address, format and models are read-only; its API key can be pasted or
/// changed, it can be turned off, and it can be removed (it comes back only by importing the file again).
/// </summary>
public sealed class ProviderEditorViewModel : ObservableObject
{
    private string _apiKey;
    private bool _enabled;
    private bool _showKey;
    private bool _isExpanded;

    public ProviderEditorViewModel(AiProvider provider, IEnumerable<AiModel> models, SettingsViewModel owner, bool expanded = false)
    {
        Owner = owner;
        Provider = provider;
        _apiKey = provider.ApiKey;
        _enabled = provider.Enabled;
        _isExpanded = expanded;
        foreach (var model in models)
        {
            Models.Add(new ModelEditorViewModel(model, this));
        }
        RemoveCommand = new AsyncCommand(() => owner.RemoveProviderAsync(this));
        ToggleKeyCommand = new RelayCommand(() => ShowKey = !ShowKey);
        FindModelsCommand = new AsyncCommand(() => owner.DiscoverAsync(Id), () => !IsDiscovering);
    }

    private bool _isDiscovering;

    /// <summary>The models come from the server (Ollama), not from the providers file: Find models asks it.</summary>
    public bool CanDiscover => Provider.DiscoverModels;

    public ICommand FindModelsCommand { get; }

    public bool IsDiscovering
    {
        get => _isDiscovering;
        set
        {
            if (Set(ref _isDiscovering, value))
            {
                CommandManager.InvalidateRequerySuggested();
            }
        }
    }

    /// <summary>What the last check of the server found ("3 models found at http://127.0.0.1:11434 · 14:02").</summary>
    public string DiscoveryStatus
    {
        get
        {
            var last = Owner.Main.Engine.Models.LastDiscovery(Id);
            return last is null ? $"The models are read from the server at {Provider.BaseUrl}." : $"{last.Message} · {last.At:HH:mm}";
        }
    }

    public bool DiscoveryFailed => Owner.Main.Engine.Models.LastDiscovery(Id) is { Reached: false };

    public void RefreshDiscovery() => Notify(nameof(DiscoveryStatus), nameof(DiscoveryFailed));

    public SettingsViewModel Owner { get; }
    public AiProvider Provider { get; }
    public ObservableCollection<ModelEditorViewModel> Models { get; } = [];

    public ICommand RemoveCommand { get; }
    public ICommand ToggleKeyCommand { get; }

    public string Id => Provider.Id;
    public string Name => Provider.Name;
    public string Kind => Provider.Kind;
    public string Address => IsHttp ? Provider.BaseUrl.TrimEnd('/') + Provider.Endpoint : "Offline — nothing leaves this PC";
    public string KeyHeader => string.IsNullOrEmpty(Provider.ApiKeyPrefix) ? Provider.ApiKeyHeader : $"{Provider.ApiKeyHeader}: {Provider.ApiKeyPrefix.Trim()} …";
    public string Extras => Provider.Headers.Count == 0 ? $"Timeout {Provider.TimeoutSeconds} s" : $"Timeout {Provider.TimeoutSeconds} s · headers: {string.Join(", ", Provider.Headers.Keys)}";

    public string ApiKey { get => _apiKey; set { if (Set(ref _apiKey, value)) { Owner.MarkDirty(); Notify(nameof(KeyState), nameof(Summary), nameof(MaskedKey)); } } }
    public bool Enabled { get => _enabled; set { if (Set(ref _enabled, value)) { Owner.MarkDirty(); OnPropertyChanged(nameof(Summary)); } } }

    public bool ShowKey
    {
        get => _showKey;
        set
        {
            if (Set(ref _showKey, value))
            {
                OnPropertyChanged(nameof(MaskedKey));
            }
        }
    }

    public bool IsExpanded
    {
        get => _isExpanded;
        set => Set(ref _isExpanded, value);
    }

    public bool IsHttp => Kind != AiProviderKinds.Simulator;

    /// <summary>The key box: for providers that need a key (or have one) — not a local server such as Ollama on this PC.</summary>
    public bool ShowKeyBox => IsHttp && (NeedsKey || ApiKey.Length > 0);
    public bool NeedsKey => Provider.NeedsKey;

    public string MaskedKey => ApiKey.Length == 0 ? "" : ApiKey.Length <= 8 ? new string('•', ApiKey.Length) : ApiKey[..4] + new string('•', 12) + ApiKey[^4..];

    public string KeyState => !IsHttp ? "No key needed" : !NeedsKey ? "No key needed (local)" : ApiKey.Length > 0 ? "Key saved" : "No key yet";

    public string Summary => $"{(Enabled ? "" : "Off · ")}{Kind} · {(IsHttp ? Provider.BaseUrl : "offline")} · {KeyState} · {Models.Count} model{(Models.Count == 1 ? "" : "s")}";

    public AiProviderEdit ToEdit() => new(Id, ApiKey.Trim(), Enabled, Models.ToDictionary(m => m.Id, m => m.Enabled));
}
