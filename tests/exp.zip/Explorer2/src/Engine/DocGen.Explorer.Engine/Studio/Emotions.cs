using System.Text.RegularExpressions;

namespace DocGen.Explorer.Engine.Studio;

/// <summary>
/// The emotions a persona's face shows while it speaks a line, and how a line's emotion is read from its words when the
/// model did not tag it. Reading is deliberately simple and explainable: cue words and punctuation, weighted, the
/// strongest wins; nothing found is "neutral".
/// </summary>
public static partial class Emotions
{
    public const string Neutral = "neutral";
    public const string Happy = "happy";
    public const string Excited = "excited";
    public const string Amused = "amused";
    public const string Curious = "curious";
    public const string Thinking = "thinking";
    public const string Surprised = "surprised";
    public const string Concerned = "concerned";
    public const string Sad = "sad";
    public const string Frustrated = "frustrated";
    public const string Skeptical = "skeptical";

    public static readonly IReadOnlyList<string> All = [Neutral, Happy, Excited, Amused, Curious, Thinking, Surprised, Concerned, Sad, Frustrated, Skeptical];

    private static readonly Dictionary<string, string> Synonyms = new(StringComparer.OrdinalIgnoreCase)
    {
        ["calm"] = Neutral, ["matter-of-fact"] = Neutral, ["serious"] = Neutral, ["explaining"] = Neutral,
        ["glad"] = Happy, ["pleased"] = Happy, ["warm"] = Happy, ["friendly"] = Happy, ["confident"] = Happy, ["proud"] = Happy, ["satisfied"] = Happy,
        ["enthusiastic"] = Excited, ["thrilled"] = Excited, ["eager"] = Excited, ["delighted"] = Excited,
        ["laughing"] = Amused, ["playful"] = Amused, ["joking"] = Amused, ["wry"] = Amused, ["funny"] = Amused,
        ["interested"] = Curious, ["inquisitive"] = Curious, ["wondering"] = Curious, ["questioning"] = Curious,
        ["thoughtful"] = Thinking, ["pondering"] = Thinking, ["reflective"] = Thinking, ["considering"] = Thinking,
        ["shocked"] = Surprised, ["astonished"] = Surprised, ["amazed"] = Surprised,
        ["worried"] = Concerned, ["anxious"] = Concerned, ["uneasy"] = Concerned, ["cautious"] = Concerned, ["nervous"] = Concerned,
        ["disappointed"] = Sad, ["unhappy"] = Sad, ["regretful"] = Sad,
        ["angry"] = Frustrated, ["annoyed"] = Frustrated, ["irritated"] = Frustrated, ["exasperated"] = Frustrated,
        ["doubtful"] = Skeptical, ["unconvinced"] = Skeptical, ["sceptical"] = Skeptical, ["dubious"] = Skeptical,
    };

    /// <summary>A tag the model wrote, as one of <see cref="All"/>; null when it is not an emotion.</summary>
    public static string? Normalize(string? tag)
    {
        var t = tag?.Trim().Trim('[', ']', '(', ')').ToLowerInvariant();
        if (string.IsNullOrEmpty(t))
        {
            return null;
        }
        return All.Contains(t) ? t : Synonyms.GetValueOrDefault(t);
    }

    private static readonly (Regex Cue, string Emotion, double Weight)[] Cues =
    [
        (ExcitedRegex(), Excited, 2.2),
        (HappyRegex(), Happy, 1.6),
        (AmusedRegex(), Amused, 2.4),
        (SurprisedRegex(), Surprised, 2.3),
        (ConcernedRegex(), Concerned, 1.8),
        (SadRegex(), Sad, 2.0),
        (FrustratedRegex(), Frustrated, 2.3),
        (SkepticalRegex(), Skeptical, 2.0),
        (ThinkingRegex(), Thinking, 1.7),
        (CuriousRegex(), Curious, 1.5),
    ];

    /// <summary>The emotion a line most likely carries, read from its words and punctuation.</summary>
    public static string Read(string? text)
    {
        if (string.IsNullOrWhiteSpace(text))
        {
            return Neutral;
        }
        var lower = " " + text.ToLowerInvariant() + " ";
        var scores = new Dictionary<string, double>();
        foreach (var (cue, emotion, weight) in Cues)
        {
            var count = cue.Matches(lower).Count;
            if (count > 0)
            {
                scores[emotion] = scores.GetValueOrDefault(emotion) + weight * Math.Min(count, 3);
            }
        }
        var exclamations = text.Count(c => c == '!');
        var questions = text.Count(c => c == '?');
        if (exclamations > 0)
        {
            // "!" lifts whatever is already there; on its own it reads as excitement.
            var top = scores.Count == 0 ? Excited : scores.MaxBy(s => s.Value).Key;
            scores[top] = scores.GetValueOrDefault(top) + 0.9 * Math.Min(exclamations, 3);
        }
        if (questions > 0)
        {
            scores[Curious] = scores.GetValueOrDefault(Curious) + 0.8 * Math.Min(questions, 3);
        }
        if (scores.Count == 0)
        {
            return Neutral;
        }
        var best = scores.OrderByDescending(s => s.Value).ThenBy(s => Array.IndexOf(All.ToArray(), s.Key)).First();
        return best.Value >= 1.2 ? best.Key : Neutral;
    }

    [GeneratedRegex(@"\b(amazing|awesome|fantastic|brilliant|love (it|this|that)|can't wait|incredible|so cool|wow,? (this|that) is great|let's go|exciting|perfect!)")]
    private static partial Regex ExcitedRegex();

    [GeneratedRegex(@"\b(great|good|nice|glad|exactly|right,|thanks|thank you|helpful|clean|elegant|works well|makes sense|neat|well done|happy|i like)\b")]
    private static partial Regex HappyRegex();

    [GeneratedRegex(@"\b(haha|ha ha|lol|funny|joke|kidding|fair enough,? ha|laugh|cheeky|ironic(ally)?)\b|😄|😂")]
    private static partial Regex AmusedRegex();

    [GeneratedRegex(@"\b(wow|whoa|really\?|wait,? what|no way|surprising(ly)?|i didn't expect|didn't know|oh!|huh!|unexpected)")]
    private static partial Regex SurprisedRegex();

    [GeneratedRegex(@"\b(risk|risky|worr(y|ied|ying)|concern(ed|ing)?|careful|danger(ous)?|could break|might break|fragile|bug|leak|race condition|deadlock|security|vulnerab|fail(s|ure|ing)?|unsafe|be wary|watch out)\b")]
    private static partial Regex ConcernedRegex();

    [GeneratedRegex(@"\b(unfortunately|sadly|sorry|too bad|shame|disappoint|regret|missing|lost|gave up)\b")]
    private static partial Regex SadRegex();

    [GeneratedRegex(@"\b(frustrat|annoy|ugh|terrible|awful|hate|mess|nightmare|painful|ridiculous|why on earth|again\?!|drives me)")]
    private static partial Regex FrustratedRegex();

    [GeneratedRegex(@"\b(i'm not sure|not convinced|i doubt|doubtful|really\?|are you sure|but is it|hmm,? but|questionable|suspicious|i'd be careful about|that seems|supposedly|in theory)")]
    private static partial Regex SkepticalRegex();

    [GeneratedRegex(@"\b(hmm|let me think|i think|i guess|i suppose|perhaps|maybe|probably|it depends|on the other hand|let's see|interesting)\b")]
    private static partial Regex ThinkingRegex();

    [GeneratedRegex(@"\b(how does|how do|what does|what happens|why does|why do|where does|which one|can you explain|tell me|i wonder|curious|so what)\b")]
    private static partial Regex CuriousRegex();
}
