using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using DocGen.Explorer.Engine.Ai;
using DocGen.Explorer.Engine.Assistant;
using DocGen.Explorer.Engine.Documentation;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Engine.Search;
using DocGen.Explorer.Engine.Storage;
using DocGen.Explorer.Engine.Text;
using DocGen.Core.Abstractions;
using DocGen.Core.Json;
using DocGen.Core.Models;

namespace DocGen.Explorer.Engine.Studio;

/// <summary>
/// Studio: spoken conversations about a repository between two to four personas, from what is actually in it. Personas
/// are personas (name, tagline, profile, speaking style, voice, rate, pitch) and belong to no repository.
/// With a chat model the transcript is written by the model from retrieved evidence; without one it is scripted offline
/// from the index, so it is still accurate, if less lively.
/// </summary>
public sealed partial class StudioService(ExplorerStore store, IndexingPipeline pipeline, IModelGateway models)
{
    public const string PersonasPath = "studio/personas.json";
    public const int WordsPerMinute = 150;

    private static string ConversationsFolder(string repositoryId) => $"repos/{repositoryId}/studio";

    // ----- Personas ------------------------------------------------------------------------------------------------

    public async Task<List<Persona>> ListPersonasAsync(CancellationToken ct = default)
    {
        var document = await store.ReadAsync<PersonaDocument>(PersonasPath, ct);
        if (document is not null && document.Personas.Any(NeedsStarterRepair))
        {
            await MutatePersonasAsync(list =>
            {
                foreach (var persona in list.Where(NeedsStarterRepair))
                {
                    var starter = StarterPersonas().First(s => s.Name == persona.Name);
                    if (OldStarterAvatars.TryGetValue(persona.Name, out var old) && old.Contains(persona.Avatar, StringComparer.OrdinalIgnoreCase))
                    {
                        persona.Avatar = starter.Avatar;
                    }
                    if (persona.Voice.Length == 0)
                    {
                        persona.Voice = starter.Voice;
                    }
                }
            }, ct);
            document = await store.ReadAsync<PersonaDocument>(PersonasPath, ct);
        }
        return document?.Personas.OrderBy(p => p.Name, StringComparer.OrdinalIgnoreCase).ToList() ?? [];
    }

    /// <summary>The pictures earlier versions gave the starter personas (by name), now replaced.</summary>
    private static readonly Dictionary<string, string[]> OldStarterAvatars = new(StringComparer.Ordinal)
    {
        ["Priya"] = ["scholar", "tester"],
        ["Sam"] = ["student", "newcomer"],
    };

    /// <summary>A starter persona as an earlier version added it (same name and tagline) whose picture or voice is out of date.</summary>
    private static bool NeedsStarterRepair(Persona persona)
    {
        var starter = StarterPersonas().FirstOrDefault(s => s.Name == persona.Name && s.Tagline == persona.Tagline);
        if (starter is null)
        {
            return false;
        }
        var oldPicture = OldStarterAvatars.TryGetValue(persona.Name, out var old) && old.Contains(persona.Avatar, StringComparer.OrdinalIgnoreCase);
        return oldPicture || persona.Voice.Length == 0;
    }

    public async Task<Persona> SavePersonaAsync(Persona persona, CancellationToken ct = default)
    {
        ValidatePersona(persona);
        await MutatePersonasAsync(list =>
        {
            if (list.Any(p => p.Id != persona.Id && string.Equals(p.Name, persona.Name.Trim(), StringComparison.OrdinalIgnoreCase)))
            {
                throw new ExplorerValidationException($"There is already a persona called {persona.Name.Trim()}.");
            }
            persona.Name = persona.Name.Trim();
            persona.UpdatedAt = DateTime.UtcNow;
            var index = list.FindIndex(p => p.Id == persona.Id);
            if (index >= 0)
            {
                persona.Version = list[index].Version + 1;
                list[index] = persona;
            }
            else
            {
                list.Add(persona);
            }
        }, ct);
        return persona;
    }

    public async Task DeletePersonaAsync(string personaId, CancellationToken ct = default)
        => await MutatePersonasAsync(list => list.RemoveAll(p => p.Id == personaId), ct);

    public static void ValidatePersona(Persona persona)
    {
        if (string.IsNullOrWhiteSpace(persona.Name))
        {
            throw new ExplorerValidationException("A persona needs a name.");
        }
        if (persona.Name.Trim().Length > Persona.MaxNameLength || persona.Tagline.Length > Persona.MaxTaglineLength || persona.Profile.Length > Persona.MaxProfileLength
            || persona.SpeakingStyle.Length > Persona.MaxStyleLength || persona.Greeting.Length > Persona.MaxGreetingLength)
        {
            throw new ExplorerValidationException("One of the persona's fields is too long.");
        }
        persona.Rate = Math.Clamp(persona.Rate, 0.5, 2);
        persona.Pitch = Math.Clamp(persona.Pitch, 0, 2);
        if (!Ids.IsValid(persona.Id))
        {
            persona.Id = Ids.New();
        }
    }

    /// <summary>Imports personas from JSON: an array, or an object with a "personas" array. Returns how many were added.</summary>
    public async Task<int> ImportPersonasAsync(string json, CancellationToken ct = default)
    {
        List<Persona>? incoming;
        try
        {
            var trimmed = json.TrimStart();
            incoming = trimmed.StartsWith('[')
                ? JsonSerializer.Deserialize<List<Persona>>(json, DocGenJson.Storage)
                : JsonSerializer.Deserialize<PersonaDocument>(json, DocGenJson.Storage)?.Personas;
        }
        catch (JsonException ex)
        {
            throw new ExplorerValidationException("That file is not a personas file: " + ex.Message);
        }
        if (incoming is null || incoming.Count == 0)
        {
            throw new ExplorerValidationException("The file holds no personas.");
        }
        var added = 0;
        await MutatePersonasAsync(list =>
        {
            foreach (var persona in incoming)
            {
                if (string.IsNullOrWhiteSpace(persona.Name) || list.Any(p => string.Equals(p.Name, persona.Name.Trim(), StringComparison.OrdinalIgnoreCase)))
                {
                    continue;
                }
                persona.Id = Ids.New();
                ValidatePersona(persona);
                persona.Name = persona.Name.Trim();
                list.Add(persona);
                added++;
            }
        }, ct);
        return added;
    }

    public async Task<string> ExportPersonasAsync(CancellationToken ct = default)
        => JsonSerializer.Serialize(new PersonaDocument { Personas = await ListPersonasAsync(ct) }, DocGenJson.Storage);

    /// <summary>Four personas who want different things from the same material.</summary>
    public static List<Persona> StarterPersonas() =>
    [
        new() { Name = "Maya", Tagline = "Principal engineer who has seen every architecture fad", Avatar = "runner", Voice = "en-IN-NeerjaNeural",
            Profile = "Twenty years building systems. Cares about boundaries, coupling and what breaks first under change. Sceptical of cleverness.",
            SpeakingStyle = "Measured, precise, asks 'why' twice. Uses concrete examples from the code.", Rate = 0.95, Pitch = 0.9 },
        new() { Name = "Sam", Tagline = "Two weeks into the team and asking everything", Avatar = "buddy", Voice = "en-IN-PrabhatNeural",
            Profile = "A capable developer new to this codebase. Wants to know where to start, what each part does, and how to run it.",
            SpeakingStyle = "Curious, quick, says when something is unclear. Repeats back what he understood.", Rate = 1.08, Pitch = 1.08 },
        new() { Name = "Priya", Tagline = "QA lead who reads tests first", Avatar = "sunny", Voice = "en-IN-NeerjaNeural",
            Profile = "Thinks in edge cases and failure modes. Wants to know what is tested, what is not, and how errors surface.",
            SpeakingStyle = "Direct, methodical, lists cases. Challenges assumptions politely.", Rate = 1.0, Pitch = 1.1 },
        new() { Name = "Leo", Tagline = "Product manager translating code into features", Avatar = "coach", Voice = "en-IN-PrabhatNeural",
            Profile = "Needs to explain the system to customers and plan work. Cares about what users see and what it costs to change.",
            SpeakingStyle = "Friendly, plain words, summarises often, asks for the user-facing impact.", Rate = 1.02, Pitch = 0.92 },
    ];

    public async Task<int> AddStarterPersonasAsync(CancellationToken ct = default)
        => await ImportPersonasAsync(JsonSerializer.Serialize(StarterPersonas(), DocGenJson.Storage), ct);

    private async Task MutatePersonasAsync(Action<List<Persona>> mutate, CancellationToken ct)
    {
        await using (await store.Json.AcquireLockAsync(PersonasPath, ct))
        {
            var document = await store.ReadAsync<PersonaDocument>(PersonasPath, ct) ?? new PersonaDocument();
            mutate(document.Personas);
            await store.WriteAsync(PersonasPath, document, ct);
        }
    }

    // ----- Conversations -------------------------------------------------------------------------------------------

    public async Task<List<StudioConversation>> ListConversationsAsync(string repositoryId, CancellationToken ct = default)
    {
        var list = new List<StudioConversation>();
        foreach (var file in store.EnumerateFiles(ConversationsFolder(repositoryId), "*.json"))
        {
            if (await store.ReadAsync<StudioConversation>($"{ConversationsFolder(repositoryId)}/{file}", ct) is { } conversation)
            {
                list.Add(conversation);
            }
        }
        return list.OrderByDescending(c => c.CreatedAt).ToList();
    }

    public async Task DeleteConversationAsync(string repositoryId, string conversationId, CancellationToken ct = default)
    {
        ExplorerStore.RequireId(conversationId);
        await store.Json.DeleteAsync($"{ConversationsFolder(repositoryId)}/{conversationId}.json", ct);
    }

    /// <summary>Why a request cannot be composed yet (null when it can).</summary>
    public static string? CannotCompose(StudioRequest request, IReadOnlyCollection<Persona> personas)
    {
        var chosen = request.PersonaIds.Distinct().Where(id => personas.Any(p => p.Id == id)).ToList();
        if (chosen.Count < StudioRequest.MinSpeakers)
        {
            return "Choose at least two speakers.";
        }
        if (chosen.Count > StudioRequest.MaxSpeakers)
        {
            return "Choose at most four speakers — more than that is more than a listener can follow.";
        }
        if (string.IsNullOrWhiteSpace(request.Topic))
        {
            return "Say what they should talk about.";
        }
        if (request.LengthMinutes is < 1 or > 60)
        {
            return "Choose a length between 1 and 60 minutes.";
        }
        return null;
    }

    public async Task<StudioConversation> ComposeAsync(string repositoryId, StudioRequest request, IProgress<string>? progress = null, CancellationToken ct = default)
    {
        var personas = await ListPersonasAsync(ct);
        if (CannotCompose(request, personas) is { } reason)
        {
            throw new ExplorerValidationException(reason);
        }
        var index = await pipeline.GetAsync(repositoryId, ct) ?? throw new ExplorerValidationException("Index the repository first.");
        var speakers = request.PersonaIds.Distinct().Select(id => personas.First(p => p.Id == id)).ToList();
        progress?.Report("Gathering material");
        var retrieval = Retriever.Retrieve(index, request.Topic, AnalysisDepth.Deep, request.Scope);
        var conversation = new StudioConversation
        {
            RepositoryId = repositoryId,
            Title = string.IsNullOrWhiteSpace(request.Title) ? $"{index.Repository.Title}: {TextUtil.Truncate(request.Topic.Trim(), 60)}" : request.Title!.Trim(),
            Topic = request.Topic.Trim(),
            Style = request.Style,
            LengthMinutes = request.LengthMinutes,
        };

        var status = await models.GetStatusAsync(ct);
        if (status.Configured)
        {
            try
            {
                progress?.Report($"Writing the conversation with {status.DisplayName}");
                conversation.Lines = await ComposeWithModelAsync(index, retrieval, request, speakers, ct);
                conversation.Provenance = $"Written by {status.DisplayName} from {TextUtil.Plural(retrieval.Evidence.Count, "piece")} of retrieved evidence.";
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                conversation.Lines = [];
                conversation.Provenance = $"The model was unavailable ({TextUtil.Truncate(ex.Message, 120)}); scripted offline from the index instead.";
            }
        }
        if (conversation.Lines.Count == 0)
        {
            progress?.Report("Scripting the conversation from the index");
            conversation.Lines = Script(index, retrieval, request, speakers);
            conversation.Provenance = conversation.Provenance.Length > 0 ? conversation.Provenance : QuizGeneratorProvenance;
        }
        await store.WriteAsync($"{ConversationsFolder(repositoryId)}/{conversation.Id}.json", conversation, CancellationToken.None);
        return conversation;
    }

    private const string QuizGeneratorProvenance = "Scripted offline from the index and retrieved evidence, without a model.";

    private async Task<List<TranscriptLine>> ComposeWithModelAsync(RepositoryIndex index, RetrievalResult retrieval, StudioRequest request, List<Persona> speakers, CancellationToken ct)
    {
        var words = request.LengthMinutes * WordsPerMinute;
        var prompt = new StringBuilder();
        prompt.AppendLine($"Write a {request.Style.ToLowerInvariant()} between {TextUtil.JoinNatural(speakers.Select(s => s.Name))} about the repository \"{index.Repository.Title}\".");
        prompt.AppendLine($"Topic and order: {request.Topic}");
        prompt.AppendLine($"Length: about {words} words ({request.LengthMinutes} minutes spoken).");
        prompt.AppendLine("Speakers:");
        foreach (var s in speakers)
        {
            prompt.AppendLine($"- {s.Name}: {s.Tagline}. {s.Profile} Speaks: {s.SpeakingStyle}");
        }
        prompt.AppendLine();
        prompt.AppendLine("Rules: discuss only what the evidence shows; name real files, types and members from it; let the speakers want different things;");
        prompt.AppendLine("no stage directions, no sound effects, no markdown. Write one line per turn, exactly `Name [emotion]: what they say`,");
        prompt.AppendLine($"where emotion is how they feel saying it, one of: {string.Join(", ", Emotions.All)}. Let the emotions follow what is said.");
        prompt.AppendLine(Ai.PlainLanguage.Spoken);
        prompt.AppendLine().AppendLine("Evidence:");
        var budget = 14000 * 4;
        foreach (var (e, i) in retrieval.Evidence.Select((e, i) => (e, i)))
        {
            var block = $"[{i + 1}] {e.Chunk.Path}:{e.Chunk.StartLine}-{e.Chunk.EndLine}\n{e.Chunk.Text}\n";
            if (block.Length > budget)
            {
                break;
            }
            prompt.Append(block);
            budget -= block.Length;
        }
        using var purpose = UsagePurpose.Set($"Studio {request.Style.ToLowerInvariant()} ({request.LengthMinutes} min, {TextUtil.JoinNatural(speakers.Select(s => s.Name))}): {request.Topic}");
        var result = await models.CompleteAsync("studio", index.Repository.Id,
        [
            ModelMessage.System("You write natural, accurate spoken dialogue about source code, grounded strictly in the evidence provided. " + Ai.PlainLanguage.Short + " " + Ai.PlainLanguage.Spoken),
            ModelMessage.User(prompt.ToString()),
        ], Math.Min(8000, words * 2), ct);
        return ParseTranscript(result.Text, speakers);
    }

    /// <summary>Parses "Name: text" lines (tolerating bold names and blank lines); unknown names are dropped.</summary>
    public static List<TranscriptLine> ParseTranscript(string text, IReadOnlyList<Persona> speakers)
    {
        var lines = new List<TranscriptLine>();
        foreach (var raw in text.Split('\n'))
        {
            var match = TranscriptLineRegex().Match(raw.Trim());
            if (!match.Success)
            {
                if (lines.Count > 0 && raw.Trim().Length > 0 && !raw.TrimStart().StartsWith('#'))
                {
                    lines[^1].Text += " " + raw.Trim(); // continuation of the previous turn
                }
                continue;
            }
            var name = match.Groups["name"].Value.Trim();
            var persona = speakers.FirstOrDefault(s => string.Equals(s.Name, name, StringComparison.OrdinalIgnoreCase));
            if (persona is null)
            {
                continue;
            }
            var said = match.Groups["text"].Value.Trim();
            lines.Add(new TranscriptLine
            {
                Speaker = persona.Name,
                PersonaId = persona.Id,
                Text = said,
                Emotion = Emotions.Normalize(match.Groups["emotion"].Value),
            });
        }
        // Lines the model did not tag (or tagged with something else) get the emotion their words carry.
        foreach (var line in lines.Where(l => l.Emotion is null))
        {
            line.Emotion = Emotions.Read(line.Text);
        }
        return lines.Where(l => l.Text.Length > 0).ToList();
    }

    [GeneratedRegex(@"^\**(?<name>[\p{L}][\p{L}\p{N} .'-]{0,59}?)\**\s*(?:[\[(](?<emotion>[\p{L} -]{2,20})[\])])?\s*\**\s*:\s*(?<text>.+)$")]
    private static partial Regex TranscriptLineRegex();

    /// <summary>An offline script: an opening, one exchange per piece of evidence, and a close; sized to the requested length.</summary>
    public static List<TranscriptLine> Script(RepositoryIndex index, RetrievalResult retrieval, StudioRequest request, IReadOnlyList<Persona> speakers)
    {
        var lines = new List<TranscriptLine>();
        var targetWords = request.LengthMinutes * WordsPerMinute;
        var host = speakers[0];
        var turn = 0;
        Persona Next() => speakers[++turn % speakers.Count];
        void Say(Persona p, string text, string? path = null, int line = 0) => lines.Add(new TranscriptLine { Speaker = p.Name, PersonaId = p.Id, Text = text, Path = path, Line = line, Emotion = Emotions.Read(text) });
        int Words() => lines.Sum(l => l.Text.Split(' ', StringSplitOptions.RemoveEmptyEntries).Length);

        var opener = request.Style switch
        {
            "Interview" => $"Thanks for joining me. Today we're looking at {index.Repository.Title}, and specifically: {request.Topic.Trim().TrimEnd('.')}.",
            "Debate" => $"Let's argue this out properly. The question on the table for {index.Repository.Title} is: {request.Topic.Trim().TrimEnd('.')}.",
            "Code review" => $"Let's review {index.Repository.Title} together, focusing on {request.Topic.Trim().TrimEnd('.').ToLowerInvariant()}.",
            "Walkthrough" => $"I'll walk us through {index.Repository.Title} — {request.Topic.Trim().TrimEnd('.').ToLowerInvariant()} — one file at a time.",
            "Onboarding chat" => $"Welcome aboard. Let's get you oriented in {index.Repository.Title}: {request.Topic.Trim().TrimEnd('.').ToLowerInvariant()}.",
            _ => $"We're talking about {index.Repository.Title} today: {request.Topic.Trim().TrimEnd('.')}.",
        };
        Say(host, opener);
        var c = index.Repository.Counters;
        Say(Next(), $"Before we dive in, what are we dealing with? How big is it?");
        Say(host, $"It's {TextUtil.Plural(c.Files, "file")} — {TextUtil.Plural(c.SourceFiles, "source file")} and {TextUtil.Plural(c.DocumentationFiles, "documentation file")}" +
                  (index.Code is { } code && code.Manifest.Projects.Count > 0 ? $", in {TextUtil.Plural(code.Manifest.Projects.Count, "project")}: {TextUtil.JoinNatural(code.Manifest.Projects.Select(p => p.Name).Take(5))}." : "."));

        var evidence = retrieval.Evidence;
        var round = 0;
        while (Words() < targetWords && round < evidence.Count * 2 && evidence.Count > 0)
        {
            var e = evidence[round % evidence.Count];
            var chunk = e.Chunk;
            var asker = Next();
            var answerer = Next();
            if (round >= evidence.Count)
            {
                // Second pass: deeper follow-ups on the same material.
                var follow = FollowUp(index, chunk);
                if (follow is null)
                {
                    round++;
                    continue;
                }
                Say(asker, follow.Value.Question, chunk.Path, chunk.StartLine);
                Say(answerer, follow.Value.Answer, chunk.Path, chunk.StartLine);
                round++;
                continue;
            }
            Say(asker, Question(chunk, asker, request.Style), chunk.Path, chunk.StartLine);
            Say(answerer, Explain(index, chunk), chunk.Path, chunk.StartLine);
            if (Words() < targetWords && index.Code is not null && chunk.Symbol is not null)
            {
                var users = index.Graph.Edges.Where(ed => ed.To == "type:" + chunk.Symbol && ed.Kind == EdgeKinds.Uses).Select(ed => index.Graph.Find(ed.From)?.Label).OfType<string>().Take(3).ToList();
                if (users.Count > 0)
                {
                    Say(Next(), $"And who relies on that? If I changed it, what would I have to check?");
                    Say(answerer, $"{TextUtil.JoinNatural(users)} — those refer to it directly, so they're the first places a change would show up.");
                }
            }
            round++;
        }
        if (evidence.Count == 0)
        {
            Say(Next(), "I looked for material on that and the index has nothing that matches. We'd need a different topic, or more of the repository selected.");
        }
        Say(Next(), "So if I had to summarise what we covered…");
        var covered = evidence.Select(e => Path.GetFileName(e.Chunk.Path)).Distinct().Take(5).ToList();
        Say(host, covered.Count > 0
            ? $"We went through {TextUtil.JoinNatural(covered)}. Start there, keep the graph open beside you, and ask the assistant whenever a name is unfamiliar."
            : "There wasn't much to cover — pick a topic that names something in the repository and we'll go again.");
        return lines;
    }

    private static string Question(Chunk chunk, Persona asker, string style)
    {
        var subject = chunk.Symbol is { } s ? CodeIndexHelpers.ShortName(s) : chunk.Title;
        var profile = (asker.Profile + " " + asker.Tagline).ToLowerInvariant();
        if (profile.Contains("test") || profile.Contains("qa") || profile.Contains("edge"))
        {
            return $"What happens in {subject} when things go wrong — and is that tested?";
        }
        if (profile.Contains("product") || profile.Contains("customer"))
        {
            return $"In plain terms, what does {subject} do for someone using this?";
        }
        if (profile.Contains("architect") || profile.Contains("boundar") || profile.Contains("coupling"))
        {
            return $"Why does {subject} exist as its own piece? What does it depend on?";
        }
        return chunk.Kind == "doc" ? $"What does the documentation say in \"{chunk.Title}\"?" : $"Can you walk me through {subject}?";
    }

    private static string Explain(RepositoryIndex index, Chunk chunk)
    {
        var where = $"It's in {Path.GetFileName(chunk.Path)}, around line {chunk.StartLine}.";
        if (chunk.Kind == "doc")
        {
            var text = Markdown.MarkdownDocument.Parse(chunk.Text).Blocks.OfType<Markdown.MdParagraph>().Select(p => Markdown.MarkdownDocument.PlainText(p.Inlines)).FirstOrDefault() ?? "";
            return text.Length > 0 ? $"{TextUtil.Truncate(text, 320)} {where}" : $"That section is short; {where}";
        }
        if (chunk.Symbol is { } symbolName && index.Code?.Resolve(symbolName).FirstOrDefault() is { } symbol)
        {
            var lines = index.ReadLines(symbol.File);
            var summary = lines is null ? null : DocumentationBuilder.XmlDocSummary(lines, symbol.StartLine);
            var parts = new List<string>();
            parts.Add(summary is { Length: > 0 } ? summary : $"{symbol.Name} is a {CodeIndexHelpers.KindLabel(symbol.Kind).ToLowerInvariant()}{(symbol.Namespace.Length > 0 ? " in " + symbol.Namespace : "")}.");
            if (DocGen.Analysis.Indexing.SymbolKinds.IsType(symbol.Kind))
            {
                var members = index.Code.MembersOf(symbol.FullName).Where(m => !DocGen.Analysis.Indexing.SymbolKinds.IsType(m.Kind)).Select(m => m.Name).Distinct().Take(4).ToList();
                if (members.Count > 0)
                {
                    parts.Add($"The members to know are {TextUtil.JoinNatural(members)}.");
                }
            }
            else if (symbol.Calls.Count > 0)
            {
                parts.Add($"It calls {TextUtil.JoinNatural(symbol.Calls.Distinct().Take(4))}.");
            }
            parts.Add(where);
            return string.Join(" ", parts);
        }
        var firstCode = TextUtil.SplitLines(chunk.Text).Select(l => l.Trim()).FirstOrDefault(l => l.Length > 8 && !l.StartsWith("using ", StringComparison.Ordinal) && !l.StartsWith("//", StringComparison.Ordinal));
        return firstCode is null ? where : $"The key line reads: {TextUtil.Truncate(firstCode, 140)}. {where}";
    }

    private static (string Question, string Answer)? FollowUp(RepositoryIndex index, Chunk chunk)
    {
        if (chunk.Symbol is null || index.Code?.Resolve(chunk.Symbol).FirstOrDefault() is not { } symbol)
        {
            return null;
        }
        var tests = index.Graph.Edges.Where(e => e.To == "type:" + symbol.FullName && e.Kind == EdgeKinds.Tests).Select(e => index.Graph.Find(e.From)?.Label).OfType<string>().ToList();
        return tests.Count > 0
            ? ($"Is {symbol.Name} covered by tests?", $"Yes — {TextUtil.JoinNatural(tests)} exercise{(tests.Count == 1 ? "s" : "")} it, so that's the safety net if we change it.")
            : ($"Is {symbol.Name} covered by tests?", $"Not directly — nothing in the index tests {symbol.Name} by name. That's a gap worth noting.");
    }

    /// <summary>"Refine with AI": rewrites the topic into a clear brief (needs a model).</summary>
    public async Task<string> RefineTopicAsync(string repositoryId, string topic, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(topic))
        {
            throw new ExplorerValidationException("Write something to refine first.");
        }
        var status = await models.GetStatusAsync(ct);
        if (!status.Configured)
        {
            throw new ExplorerValidationException("Refine with AI needs a chat model. Choose one under Settings → Chat model.");
        }
        var index = await pipeline.GetAsync(repositoryId, ct);
        var names = index?.Graph.Nodes.Where(n => ConceptTypes.IsType(n.Type)).OrderByDescending(n => index.Graph.Degree(n.Id)).Take(30).Select(n => n.Label) ?? [];
        using var purpose = UsagePurpose.Set($"Refine the Studio topic: {topic}");
        var result = await models.CompleteAsync("refine", repositoryId,
        [
            ModelMessage.System("You turn rough notes into a clear 2-4 sentence brief for a spoken technical conversation. Keep the user's intent; name concrete parts of the code when they fit. Reply with the brief only. " + Ai.PlainLanguage.Short),
            ModelMessage.User($"Repository concepts: {string.Join(", ", names)}\n\nNotes: {topic}"),
        ], 300, ct);
        return result.Text.Trim();
    }
}
