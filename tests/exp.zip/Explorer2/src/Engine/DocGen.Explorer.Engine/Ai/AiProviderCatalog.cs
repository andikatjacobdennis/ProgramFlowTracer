using System.Text.Json;
using System.Text.Json.Serialization;
using DocGen.Explorer.Engine.Repositories;

namespace DocGen.Explorer.Engine.Ai;

/// <summary>
/// The providers file: the only way providers and models reach the explorer (Settings → Providers and models →
/// Import from file…), so that only the providers it lists can be used. Each provider carries its models and its key.
/// </summary>
public sealed class AiProviderCatalog
{
    public List<CatalogProvider> Providers { get; set; } = [];

    /// <summary>The model answers use after the import (optional).</summary>
    public string? DefaultModel { get; set; }
}

public sealed class CatalogProvider
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string Kind { get; set; } = AiProviderKinds.ChatCompletions;
    public string BaseUrl { get; set; } = "";
    public string Endpoint { get; set; } = "/v1/chat/completions";
    public string ApiKey { get; set; } = "";
    public string ApiKeyHeader { get; set; } = "Authorization";
    public string ApiKeyPrefix { get; set; } = "Bearer ";
    public Dictionary<string, string> Headers { get; set; } = [];
    public int TimeoutSeconds { get; set; } = 120;
    public bool Streaming { get; set; } = true;
    public bool Enabled { get; set; } = true;

    /// <summary>Ask the server which models it has (Ollama) instead of listing them here; <see cref="Models"/> may then be empty.</summary>
    public bool DiscoverModels { get; set; }

    public List<CatalogModel> Models { get; set; } = [];
}

public sealed class CatalogModel
{
    public string Id { get; set; } = "";

    /// <summary>The name the provider knows the model by; the id when left out.</summary>
    public string ProviderModelId { get; set; } = "";

    public string DisplayName { get; set; } = "";
    public int ContextWindow { get; set; } = 64_000;
    public int MaxOutputTokens { get; set; }
    public double? Temperature { get; set; }
    public bool Enabled { get; set; } = true;

    /// <summary>The model can view images ("supportsImages": true); attached images are sent only to such a model.</summary>
    public bool SupportsImages { get; set; }
}

/// <summary>What an import did.</summary>
public sealed record AiImportResult(int Providers, int Models, int KeysKept, string? DefaultModel, IReadOnlyList<string> NeedKeys);

/// <summary>An allowed change to an imported provider: its key, and whether it (and each of its models) is on.</summary>
public sealed record AiProviderEdit(string ProviderId, string ApiKey, bool Enabled, IReadOnlyDictionary<string, bool> ModelsEnabled);

public static class AiProviderCatalogFile
{
    public static readonly JsonSerializerOptions Options = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
        ReadCommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = true,
        WriteIndented = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
    };

    /// <summary>Reads a providers file, or says plainly what is wrong with it.</summary>
    public static AiProviderCatalog Parse(string json)
    {
        AiProviderCatalog? catalog;
        try
        {
            catalog = JsonSerializer.Deserialize<AiProviderCatalog>(json, Options);
        }
        catch (JsonException ex)
        {
            throw new ExplorerValidationException($"The providers file is not valid JSON (line {ex.LineNumber + 1}): {ex.Message}");
        }
        if (catalog is null || catalog.Providers.Count == 0)
        {
            throw new ExplorerValidationException("The providers file lists no providers (expected { \"providers\": [ … ] }).");
        }
        return catalog;
    }

    /// <summary>Turns a providers file into the stored settings (checked the same way as before).</summary>
    public static AiSettingsDocument ToDocument(AiProviderCatalog catalog)
    {
        var document = new AiSettingsDocument();
        foreach (var p in catalog.Providers)
        {
            if (!AiProviderKinds.All.Contains(p.Kind))
            {
                throw new ExplorerValidationException($"{Label(p)}: kind must be one of {string.Join(", ", AiProviderKinds.All)}.");
            }
            if (p.Models.Count == 0 && !p.DiscoverModels)
            {
                throw new ExplorerValidationException($"{Label(p)} lists no models (or set \"discoverModels\": true to ask its server).");
            }
            document.Providers.Add(new AiProvider
            {
                Id = p.Id.Trim(),
                Name = string.IsNullOrWhiteSpace(p.Name) ? p.Id.Trim() : p.Name.Trim(),
                Kind = p.Kind,
                BaseUrl = p.BaseUrl.Trim(),
                Endpoint = p.Endpoint.Trim(),
                ApiKey = p.ApiKey.Trim(),
                ApiKeyHeader = p.ApiKeyHeader.Trim(),
                ApiKeyPrefix = p.ApiKeyPrefix,
                Headers = new Dictionary<string, string>(p.Headers, StringComparer.OrdinalIgnoreCase),
                TimeoutSeconds = p.TimeoutSeconds,
                Streaming = p.Streaming,
                Enabled = p.Enabled,
                DiscoverModels = p.DiscoverModels,
            });
            foreach (var m in p.Models)
            {
                var providerModelId = string.IsNullOrWhiteSpace(m.ProviderModelId) ? m.Id.Trim() : m.ProviderModelId.Trim();
                document.Models.Add(new AiModel
                {
                    Id = m.Id.Trim(),
                    ProviderId = p.Id.Trim(),
                    ProviderModelId = providerModelId,
                    DisplayName = string.IsNullOrWhiteSpace(m.DisplayName) ? m.Id.Trim() : m.DisplayName.Trim(),
                    ContextWindow = m.ContextWindow,
                    MaxOutputTokens = m.MaxOutputTokens > 0 ? m.MaxOutputTokens : ModelLimits.UsualMaxOutput(providerModelId),
                    Temperature = m.Temperature,
                    Enabled = m.Enabled,
                    SupportsImages = m.SupportsImages,
                });
            }
        }
        AiSettingsService.Validate(document);
        if (catalog.DefaultModel is { Length: > 0 } chosen && !document.Models.Any(m => string.Equals(m.Id, chosen, StringComparison.OrdinalIgnoreCase)))
        {
            throw new ExplorerValidationException($"defaultModel '{chosen}' is not one of the file's models.");
        }
        return document;
    }

    private static string Label(CatalogProvider p) => string.IsNullOrWhiteSpace(p.Name) ? $"Provider '{p.Id}'" : p.Name;
}
