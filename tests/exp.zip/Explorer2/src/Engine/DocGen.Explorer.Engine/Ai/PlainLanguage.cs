namespace DocGen.Explorer.Engine.Ai;

/// <summary>
/// How everything the explorer has a model write for people should read: natural, simple Indian English that anyone
/// can follow, as a friendly colleague would write it, laid out so it is easy to scan, with little emphasis. Added to
/// the instructions of the assistant, graph descriptions and groups, learning and Studio.
/// </summary>
public static class PlainLanguage
{
    /// <summary>For short texts (a description, a name, a brief, spoken lines).</summary>
    public const string Short =
        "Write the way a friendly Indian colleague talks when explaining something simply: natural, simple Indian English " +
        "that anyone can understand, including people who do not write code. Short sentences, everyday words, active voice, " +
        "British spelling (colour, organise, behaviour). Explain any technical term in a few plain words. No jargon, no " +
        "slang, no idioms, no bold or italics, and nothing that sounds like a template or a sales brochure.";

    /// <summary>For answers: the language, a layout that is easy to scan, and little emphasis.</summary>
    public const string Answer = """
        How to write the answer:
        - Write the way a friendly Indian colleague would explain it to someone sitting next to them: natural, warm and simple. It should not sound like a machine or a template. Simple Indian English that anyone can understand, including people who do not write code.
        - Short sentences, everyday words, active voice, British spelling (colour, organise, behaviour). No jargon, slang or idioms, and no filler such as "Great question" or "In conclusion".
        - Explain each technical term in a few plain words the first time it appears, for example: "an interface (a list of what a class must be able to do)".
        - Say what something does and why it matters before how it works.
        - Start with one or two sentences that answer the question directly.
        - Then, when the answer is longer than a few sentences, use short sections with ## headings, short paragraphs (two or three sentences), bullet points for parts, numbered steps for things that happen in order, and a table when comparing things.
        - Use bold very rarely: at most one or two key words in the whole answer, and never whole sentences. Do not use italics. Do not bold the start of every bullet point.
        - Put names from the code in `backticks`.
        - When the answer is long, end with a line that starts "In short:" and sums it up in one sentence.
        """;

    /// <summary>For spoken conversations (Studio): short turns, one speaker at a time, like people chatting.</summary>
    public const string Spoken =
        "Keep every turn short, like real people chatting: usually one or two short sentences, at most about 25 words. " +
        "One person speaks at a time and the next one answers what was just said. No speeches, no lists, no Markdown.";
}
