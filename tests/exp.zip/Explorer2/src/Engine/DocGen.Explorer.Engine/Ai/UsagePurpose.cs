namespace DocGen.Explorer.Engine.Ai;

/// <summary>
/// What the model calls made in the current flow are for, in words a person reads on the Usage page
/// ("Name and check graph groups 1–8 of 40"). Flows with the call; falls back to the prompt's text when unset.
/// </summary>
public static class UsagePurpose
{
    private static readonly AsyncLocal<string?> Current = new();

    public static string? Value => Current.Value;

    /// <summary>Sets the purpose until the returned handle is disposed (then the previous one applies again).</summary>
    public static IDisposable Set(string purpose)
    {
        var previous = Current.Value;
        Current.Value = TextShorten(purpose);
        return new Restore(previous);
    }

    private static string TextShorten(string text)
    {
        var flat = string.Join(' ', text.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries));
        return flat.Length <= 240 ? flat : flat[..239] + "…";
    }

    private sealed class Restore(string? previous) : IDisposable
    {
        private bool _done;

        public void Dispose()
        {
            if (!_done)
            {
                _done = true;
                Current.Value = previous;
            }
        }
    }
}
