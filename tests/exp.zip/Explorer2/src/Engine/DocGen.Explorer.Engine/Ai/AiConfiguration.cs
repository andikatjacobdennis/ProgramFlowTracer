using System.Text.Json;
using DocGen.Explorer.Engine.Storage;
using DocGen.Core.Abstractions;
using DocGen.Core.Json;
using DocGen.Core.Models;

namespace DocGen.Explorer.Engine.Ai;

/// <summary>How a provider is spoken to.</summary>
public static class AiProviderKinds
{
    /// <summary>The chat-completions format (also Ollama's API).</summary>
    public const string ChatCompletions = "chat-completions";

    /// <summary>The messages format (the system prompt apart from the conversation, content in blocks).</summary>
    public const string Messages = "messages";

    /// <summary>The built-in offline simulator.</summary>
    public const string Simulator = "simulator";

    public static readonly IReadOnlyList<string> All = [ChatCompletions, Messages, Simulator];
}

/// <summary>A model provider, with its API key (settings/ai.json is kept encrypted for the Windows user).</summary>
public sealed class AiProvider
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";
    public string Kind { get; set; } = AiProviderKinds.ChatCompletions;
    public string BaseUrl { get; set; } = "";
    public string Endpoint { get; set; } = "/v1/chat/completions";
    public string ApiKey { get; set; } = "";
    public string ApiKeyHeader { get; set; } = "Authorization";
    public string ApiKeyPrefix { get; set; } = "Bearer ";
    public Dictionary<string, string> Headers { get; set; } = [];
    public int TimeoutSeconds { get; set; } = 120;
    public bool Streaming { get; set; } = true;
    public bool Enabled { get; set; } = true;

    /// <summary>The models come from the server's own list (Ollama: GET /api/tags), not from the providers file.</summary>
    public bool DiscoverModels { get; set; }

    /// <summary>Local servers (Ollama, LM Studio) and the simulator work without a key.</summary>
    [System.Text.Json.Serialization.JsonIgnore]
    public bool NeedsKey => Kind != AiProviderKinds.Simulator && !IsLocal(BaseUrl);

    public static bool IsLocal(string url)
        => Uri.TryCreate(url, UriKind.Absolute, out var uri) && (uri.IsLoopback || uri.Host.Equals("localhost", StringComparison.OrdinalIgnoreCase));
}

public sealed class AiModel
{
    public string Id { get; set; } = "";
    public string ProviderId { get; set; } = "";

    /// <summary>The name the provider knows the model by (e.g. example-chat-model).</summary>
    public string ProviderModelId { get; set; } = "";

    public string DisplayName { get; set; } = "";
    public int ContextWindow { get; set; } = 64_000;
    public int MaxOutputTokens { get; set; } = 8_192;
    public double? Temperature { get; set; }
    public bool Enabled { get; set; } = true;

    /// <summary>The model can view images: attached images are sent to it (to any other model they are only named).</summary>
    public bool SupportsImages { get; set; }
}

public sealed class AiSettingsDocument
{
    public List<AiProvider> Providers { get; set; } = [];
    public List<AiModel> Models { get; set; } = [];
}

/// <summary>
/// Usual output limits by model family, for a model whose providers file gives none. The app has no providers of its
/// own: they come only from an imported providers file.
/// </summary>
public static class ModelLimits
{
    /// <summary>
    /// A reasoning model's thinking counts against the same limit, so those get room for both; answers that still reach
    /// the limit are continued (see the assistant).
    /// </summary>
    public static int UsualMaxOutput(string modelId) => modelId switch
    {
        // Reasoning models think within the same limit: room for both.
        _ when modelId.Contains("reasoner", StringComparison.OrdinalIgnoreCase) || modelId.Contains("thinking", StringComparison.OrdinalIgnoreCase) => 32_000,
        _ when modelId.Contains("r1", StringComparison.OrdinalIgnoreCase) => 16_000,
        _ => 8_192,
    };
}

/// <summary>
/// The explorer's AI configuration, kept in <c>settings/ai.json</c> in the data folder — providers, their API keys (stored
/// in this file only, kept encrypted for the Windows user; no environment variables) and models. It is presented to the provider layer as
/// its <see cref="ISettingsService"/>: each provider becomes a provider configuration whose key is sent as a request header.
/// Application settings (app.json) are delegated unchanged.
/// </summary>
public sealed class AiSettingsService(ExplorerStore store, ISettingsService inner) : ISettingsService
{
    public const string Path = "settings/ai.json";

    private long _generation;

    public long ConfigurationGeneration => Interlocked.Read(ref _generation);

    public event EventHandler? Changed;

    public async Task<AiSettingsDocument> GetAsync(CancellationToken ct = default)
    {
        // A new installation has no providers: they arrive only from a providers file (Import from file…).
        var document = await store.ReadProtectedAsync<AiSettingsDocument>(Path, ct) ?? new AiSettingsDocument();
        // Earlier versions gave every model 4,096 output tokens, which cut long answers (and reasoning models) short:
        // that old default becomes the model's usual limit. A value chosen in Settings is kept.
        foreach (var model in document.Models.Where(m => m.MaxOutputTokens == 4_096))
        {
            model.MaxOutputTokens = ModelLimits.UsualMaxOutput(string.IsNullOrWhiteSpace(model.ProviderModelId) ? model.Id : model.ProviderModelId);
        }
        // The built-in simulator used to carry its engine's name ("… Simulator"): it is the offline simulator now.
        foreach (var provider in document.Providers.Where(p => p.Kind == AiProviderKinds.Simulator && p.Name.EndsWith(" Simulator", StringComparison.Ordinal)))
        {
            provider.Name = OfflineSimulatorName;
        }
        return document;
    }

    /// <summary>The built-in simulator's name.</summary>
    public const string OfflineSimulatorName = "Offline simulator";

    /// <summary>
    /// Writes the whole document. Not for the user interface: providers and models change only by
    /// <see cref="ImportAsync"/>, and afterwards only through <see cref="ApplyEditsAsync"/> and <see cref="RemoveProviderAsync"/>.
    /// </summary>
    internal async Task SaveAsync(AiSettingsDocument document, CancellationToken ct = default)
    {
        Validate(document);
        await store.WriteProtectedAsync(Path, document, ct);
        Interlocked.Increment(ref _generation);
        Changed?.Invoke(this, EventArgs.Empty);
    }

    public static void Validate(AiSettingsDocument document)
    {
        foreach (var provider in document.Providers)
        {
            if (string.IsNullOrWhiteSpace(provider.Id) || provider.Id.Any(c => !(char.IsAsciiLetterOrDigit(c) || c is '-' or '_' or '.')))
            {
                throw new Repositories.ExplorerValidationException($"A provider id may use letters, digits, '-', '_' and '.' only ('{provider.Id}').");
            }
            if (provider.Kind != AiProviderKinds.Simulator && !Uri.TryCreate(provider.BaseUrl, UriKind.Absolute, out var uri))
            {
                throw new Repositories.ExplorerValidationException($"{provider.Name}: the base URL must be a full address such as https://api.example.com.");
            }
            provider.TimeoutSeconds = Math.Clamp(provider.TimeoutSeconds, 5, 3600);
        }
        var duplicate = document.Providers.GroupBy(p => p.Id, StringComparer.OrdinalIgnoreCase).FirstOrDefault(g => g.Count() > 1);
        if (duplicate is not null)
        {
            throw new Repositories.ExplorerValidationException($"Two providers have the id '{duplicate.Key}'.");
        }
        foreach (var model in document.Models)
        {
            if (string.IsNullOrWhiteSpace(model.Id) || string.IsNullOrWhiteSpace(model.ProviderModelId))
            {
                throw new Repositories.ExplorerValidationException("Every model needs an id and the name the provider knows it by.");
            }
            if (!document.Providers.Any(p => p.Id == model.ProviderId))
            {
                throw new Repositories.ExplorerValidationException($"The model '{model.Id}' belongs to a provider that no longer exists.");
            }
            model.MaxOutputTokens = Math.Clamp(model.MaxOutputTokens, 16, 1_000_000);
            model.ContextWindow = Math.Clamp(model.ContextWindow, 1_000, 10_000_000);
        }
        var duplicateModel = document.Models.GroupBy(m => m.Id, StringComparer.OrdinalIgnoreCase).FirstOrDefault(g => g.Count() > 1);
        if (duplicateModel is not null)
        {
            throw new Repositories.ExplorerValidationException($"Two models have the id '{duplicateModel.Key}'.");
        }
    }

    /// <summary>The provider configuration for one provider: the stored key travels as a header.</summary>
    public static ProviderConfiguration ToProviderConfiguration(AiProvider p)
    {
        var headers = new Dictionary<string, string>(p.Headers, StringComparer.OrdinalIgnoreCase);
        if (!string.IsNullOrWhiteSpace(p.ApiKey) && !string.IsNullOrWhiteSpace(p.ApiKeyHeader))
        {
            headers[p.ApiKeyHeader] = p.ApiKeyPrefix + p.ApiKey.Trim();
        }
        return new ProviderConfiguration
        {
            Id = p.Id,
            DisplayName = p.Name,
            Type = p.Kind == AiProviderKinds.Simulator ? "fake" : "http",
            WireFormat = p.Kind == AiProviderKinds.Messages ? "messages" : "chat-completions",
            BaseUrl = p.BaseUrl.TrimEnd('/'),
            Endpoint = p.Endpoint,
            ApiKeyEnvironmentVariable = null,
            Headers = headers,
            TimeoutSeconds = p.TimeoutSeconds,
            Streaming = p.Streaming,
            Enabled = p.Enabled,
        };
    }

    public async Task<IReadOnlyList<ProviderConfiguration>> GetProvidersAsync(CancellationToken ct = default)
        => (await GetAsync(ct)).Providers.Select(ToProviderConfiguration).ToList();

    public async Task<IReadOnlyList<ModelConfiguration>> GetModelsAsync(CancellationToken ct = default)
        => (await GetAsync(ct)).Models.Select((m, i) => new ModelConfiguration
        {
            Id = m.Id,
            ProviderId = m.ProviderId,
            ProviderModelId = m.ProviderModelId,
            DisplayName = string.IsNullOrWhiteSpace(m.DisplayName) ? m.Id : m.DisplayName,
            ContextWindow = m.ContextWindow,
            MaxOutputTokens = m.MaxOutputTokens,
            Temperature = m.Temperature,
            Enabled = m.Enabled,
            SupportsImages = m.SupportsImages,
            SupportsStreaming = true,
            SortOrder = i,
        }).ToList();

    public Task SaveProvidersAsync(IReadOnlyList<ProviderConfiguration> providers, CancellationToken ct = default)
        => throw new NotSupportedException("Providers come from a providers file (Settings → Providers and models → Import from file…).");

    public Task SaveModelsAsync(IReadOnlyList<ModelConfiguration> models, CancellationToken ct = default)
        => throw new NotSupportedException("Models come from a providers file (Settings → Providers and models → Import from file…).");

    public Task<ApplicationSettings> GetAppSettingsAsync(CancellationToken ct = default) => inner.GetAppSettingsAsync(ct);

    public Task<ApplicationSettings> UpdateAppSettingsAsync(Action<ApplicationSettings> mutate, CancellationToken ct = default) => inner.UpdateAppSettingsAsync(mutate, ct);

    /// <summary>
    /// Replaces the providers and models with those of a providers file — the only way they are added. A provider the
    /// file lists without a key keeps the key already typed for it here.
    /// </summary>
    internal async Task<AiImportResult> ImportAsync(string json, CancellationToken ct = default)
    {
        var catalog = AiProviderCatalogFile.Parse(json);
        var document = AiProviderCatalogFile.ToDocument(catalog);
        var current = await GetAsync(ct);
        var kept = 0;
        foreach (var provider in document.Providers.Where(p => p.ApiKey.Length == 0))
        {
            if (current.Providers.FirstOrDefault(c => string.Equals(c.Id, provider.Id, StringComparison.OrdinalIgnoreCase)) is { ApiKey.Length: > 0 } previous)
            {
                provider.ApiKey = previous.ApiKey;
                kept++;
            }
        }
        await SaveAsync(document, ct);
        var needKeys = document.Providers.Where(p => p.Enabled && p.NeedsKey && p.ApiKey.Length == 0).Select(p => p.Name).ToList();
        return new AiImportResult(document.Providers.Count, document.Models.Count, kept, catalog.DefaultModel, needKeys);
    }

    /// <summary>The changes allowed after an import: a provider's key, and whether it and its models are on.</summary>
    public async Task ApplyEditsAsync(IEnumerable<AiProviderEdit> edits, CancellationToken ct = default)
    {
        var document = await GetAsync(ct);
        foreach (var edit in edits)
        {
            var provider = document.Providers.FirstOrDefault(p => p.Id == edit.ProviderId)
                ?? throw new Repositories.ExplorerValidationException($"There is no provider '{edit.ProviderId}' to change; providers are added only from a providers file.");
            provider.ApiKey = edit.ApiKey.Trim();
            provider.Enabled = edit.Enabled;
            foreach (var model in document.Models.Where(m => m.ProviderId == provider.Id))
            {
                if (edit.ModelsEnabled.TryGetValue(model.Id, out var enabled))
                {
                    model.Enabled = enabled;
                }
            }
        }
        await SaveAsync(document, ct);
    }

    /// <summary>Removes a provider and its models (they come back only by importing a providers file again).</summary>
    public async Task RemoveProviderAsync(string providerId, CancellationToken ct = default)
    {
        var document = await GetAsync(ct);
        document.Providers.RemoveAll(p => p.Id == providerId);
        document.Models.RemoveAll(m => m.ProviderId == providerId);
        await SaveAsync(document, ct);
    }
}
