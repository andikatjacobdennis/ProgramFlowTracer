using System.Globalization;
using System.Text;
using System.Text.Json;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Storage;
using DocGen.Core.Json;

namespace DocGen.Explorer.Engine.Ai;

/// <summary>Token usage, recorded as each model call is made (one JSON line per call). Nothing here is estimated.</summary>
public sealed class UsageService(ExplorerStore store)
{
    public const string LogPath = "usage/usage.jsonl";

    private readonly SemaphoreSlim _gate = new(1, 1);

    public event EventHandler? Changed;

    public async Task RecordAsync(UsageEntry entry, CancellationToken ct = default)
    {
        await _gate.WaitAsync(ct);
        try
        {
            await store.AppendLineAsync(LogPath, JsonSerializer.Serialize(entry, DocGenJson.Wire), ct);
        }
        finally
        {
            _gate.Release();
        }
        Changed?.Invoke(this, EventArgs.Empty);
    }

    public async Task<List<UsageEntry>> ReadAllAsync(CancellationToken ct = default)
    {
        var text = await store.ReadTextAsync(LogPath, ct);
        var entries = new List<UsageEntry>();
        if (text is null)
        {
            return entries;
        }
        foreach (var line in text.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            try
            {
                if (JsonSerializer.Deserialize<UsageEntry>(line, DocGenJson.Wire) is { } entry)
                {
                    entries.Add(entry);
                }
            }
            catch (JsonException)
            {
                // A torn last line (crash mid-write) is skipped, never fatal.
            }
        }
        return entries;
    }

    public async Task<UsageSummary> SummarizeAsync(int days, DateTime? now = null, CancellationToken ct = default)
    {
        var until = now ?? DateTime.UtcNow;
        var since = until.AddDays(-days);
        var entries = (await ReadAllAsync(ct)).Where(e => e.At >= since && e.At <= until.AddMinutes(1)).OrderByDescending(e => e.At).ToList();
        var summary = new UsageSummary
        {
            Days = days,
            Calls = entries.Count,
            InputTokens = entries.Sum(e => (long)e.InputTokens),
            OutputTokens = entries.Sum(e => (long)e.OutputTokens),
            Cost = entries.Sum(e => e.Cost),
            Failures = entries.Count(e => e.Failed),
            Entries = entries,
            TokensByFeature = entries.GroupBy(e => e.Feature).ToDictionary(g => g.Key, g => g.Sum(e => (long)e.TotalTokens)),
            TokensByModel = entries.GroupBy(e => e.ModelId).ToDictionary(g => g.Key, g => g.Sum(e => (long)e.TotalTokens)),
        };
        foreach (var group in entries.GroupBy(e => DateOnly.FromDateTime(e.At)))
        {
            summary.TokensByDay[group.Key] = group.Sum(e => (long)e.TotalTokens);
        }
        // Every day of the range, so a chart's axis shows the whole period (days without calls are zero).
        var first = DateOnly.FromDateTime(since.ToLocalTime());
        var last = DateOnly.FromDateTime(until.ToLocalTime());
        for (var day = first.AddDays(1); day <= last; day = day.AddDays(1))
        {
            summary.TokensByDayDetail[day] = (0, 0);
        }
        foreach (var group in entries.GroupBy(e => DateOnly.FromDateTime(e.At.ToLocalTime())))
        {
            summary.TokensByDayDetail[group.Key] = (group.Sum(e => (long)e.InputTokens), group.Sum(e => (long)e.OutputTokens));
        }
        summary.CallsByFeature = entries.GroupBy(e => e.Feature).ToDictionary(g => g.Key, g => g.Count());
        return summary;
    }

    public async Task ClearAsync(CancellationToken ct = default)
    {
        await _gate.WaitAsync(ct);
        try
        {
            store.Delete(LogPath);
        }
        finally
        {
            _gate.Release();
        }
        Changed?.Invoke(this, EventArgs.Empty);
    }

    public static string ToCsv(IEnumerable<UsageEntry> entries)
    {
        var sb = new StringBuilder();
        sb.AppendLine("id,at,feature,model,provider,repository,input_tokens,output_tokens,cached_input_tokens,duration_ms,cost,failed,finish_reason,purpose,error");
        foreach (var e in entries)
        {
            sb.Append(Csv(e.Id)).Append(',').Append(e.At.ToString("o", CultureInfo.InvariantCulture)).Append(',')
              .Append(Csv(e.Feature)).Append(',').Append(Csv(e.ModelId)).Append(',').Append(Csv(e.ProviderId)).Append(',')
              .Append(Csv(e.RepositoryId ?? "")).Append(',')
              .Append(e.InputTokens).Append(',').Append(e.OutputTokens).Append(',').Append(e.CachedInputTokens).Append(',')
              .Append(e.DurationMs).Append(',').Append(e.Cost.ToString(CultureInfo.InvariantCulture)).Append(',')
              .Append(e.Failed ? "true" : "false").Append(',')
              .Append(Csv(e.FinishReason ?? "")).Append(',').Append(Csv(e.Purpose ?? "")).Append(',').AppendLine(Csv(e.Error ?? ""));
        }
        return sb.ToString();
    }

    private static string Csv(string value)
        => value.IndexOfAny([',', '"', '\n', '\r']) >= 0 ? "\"" + value.Replace("\"", "\"\"", StringComparison.Ordinal) + "\"" : value;
}
