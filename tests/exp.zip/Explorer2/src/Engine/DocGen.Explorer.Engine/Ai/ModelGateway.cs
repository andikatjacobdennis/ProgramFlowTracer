using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Storage;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Data.Services;
using DocGen.Providers;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace DocGen.Explorer.Engine.Ai;

/// <summary>A finished model call.</summary>
public sealed record ModelResult(string Text, int InputTokens, int OutputTokens, long DurationMs, string ModelId)
{
    /// <summary>Why the model stopped ("stop", "length", "max_tokens", …), when the provider said.</summary>
    public string? FinishReason { get; init; }

    /// <summary>The model ran out of output tokens: the text stops mid-answer.</summary>
    public bool Truncated => FinishReason is "length" or "max_tokens" or "MAX_TOKENS";
}

/// <summary>What the explorer can say about its chat model.</summary>
public sealed record ModelStatus(bool Configured, string? ModelId, string? DisplayName, string Description);

public interface IModelGateway
{
    Task<ModelStatus> GetStatusAsync(CancellationToken ct = default);

    Task<ModelResult> CompleteAsync(string feature, string? repositoryId, IReadOnlyList<ModelMessage> messages, int maxOutputTokens, CancellationToken ct);

    /// <summary>Streams the answer; <paramref name="onReasoning"/> receives a reasoning model's thinking as it arrives.</summary>
    IAsyncEnumerable<string> StreamAsync(string feature, string? repositoryId, IReadOnlyList<ModelMessage> messages, int maxOutputTokens,
        Action<ModelResult> completed, CancellationToken ct, Action<string>? onReasoning = null);

    /// <summary>Whether the chat model in use can view images.</summary>
    Task<bool> CurrentModelSupportsImagesAsync(CancellationToken ct = default) => Task.FromResult(false);
}

/// <summary>
/// The explorer's door to a chat model, built on the provider layer: models and providers come from the same
/// <c>settings/models.json</c> and <c>settings/providers.json</c> format the provider layer uses (API keys from environment variables,
/// never stored). With no model chosen the explorer runs in evidence mode and makes no calls. Every call is recorded in
/// <see cref="UsageService"/> as it is made.
/// </summary>
public sealed class ModelGateway : IModelGateway
{
    public const string SettingsPath = "settings/explorer.json";

    private readonly ExplorerStore _store;
    private readonly UsageService _usage;
    private readonly AiSettingsService _settings;
    private readonly ProviderRegistry _providers;
    private readonly ModelRegistry _models;

    public ModelGateway(ExplorerStore store, UsageService usage, ILoggerFactory? loggers = null)
    {
        _store = store;
        _usage = usage;
        loggers ??= NullLoggerFactory.Instance;
        _settings = new AiSettingsService(store, new SettingsService(store.Json, loggers.CreateLogger<SettingsService>()));
        var services = new ServiceCollection();
        services.AddSingleton(loggers);
        services.AddHttpClient(ProviderRegistry.HttpClientName, client =>
        {
            client.Timeout = Timeout.InfiniteTimeSpan;
            client.DefaultRequestHeaders.UserAgent.ParseAdd("DocGen.Explorer/1.0");
        });
        var provider = services.BuildServiceProvider();
        _providers = new ProviderRegistry(_settings, provider.GetRequiredService<IHttpClientFactory>(), loggers);
        _models = new ModelRegistry(_settings);
    }

    /// <summary>Providers, keys and models (settings/ai.json).</summary>
    public AiSettingsService Ai => _settings;

    public ProviderRegistry Providers => _providers;

    /// <summary>Registers a provider instance directly (tests, custom hosting).</summary>
    public void RegisterProvider(IAIProvider provider) => _providers.RegisterInstance(provider);

    public async Task<ExplorerSettings> GetExplorerSettingsAsync(CancellationToken ct = default)
        => await _store.ReadAsync<ExplorerSettings>(SettingsPath, ct) ?? new ExplorerSettings();

    public async Task SaveExplorerSettingsAsync(ExplorerSettings settings, CancellationToken ct = default)
        => await _store.WriteAsync(SettingsPath, settings, ct);

    public async Task<ExplorerSettings> UpdateExplorerSettingsAsync(Action<ExplorerSettings> mutate, CancellationToken ct = default)
    {
        await using (await _store.Json.AcquireLockAsync(SettingsPath, ct))
        {
            var settings = await GetExplorerSettingsAsync(ct);
            mutate(settings);
            await SaveExplorerSettingsAsync(settings, ct);
            return settings;
        }
    }

    public Task<IReadOnlyList<ModelConfiguration>> ListModelsAsync(bool includeDisabled = false, CancellationToken ct = default)
        => _models.ListAsync(includeDisabled, ct);

    public async Task<ModelStatus> GetStatusAsync(CancellationToken ct = default)
    {
        var settings = await GetExplorerSettingsAsync(ct);
        if (string.IsNullOrWhiteSpace(settings.ChatModelId))
        {
            return new ModelStatus(false, null, null,
                "Evidence mode: answers report retrieved repository content rather than generated prose. Choose a chat model under Settings → Chat model.");
        }
        return await StatusOfAsync(settings.ChatModelId, ct);
    }

    /// <summary>Whether a given model can be called: it exists, it and its provider are enabled, and it has a key when it needs one.</summary>
    public async Task<ModelStatus> StatusOfAsync(string modelId, CancellationToken ct = default)
    {
        var ai = await _settings.GetAsync(ct);
        var model = ai.Models.FirstOrDefault(m => string.Equals(m.Id, modelId, StringComparison.OrdinalIgnoreCase));
        var provider = model is null ? null : ai.Providers.FirstOrDefault(p => p.Id == model.ProviderId);
        if (model is null || provider is null)
        {
            return new ModelStatus(false, modelId, null, $"The chosen model '{modelId}' is no longer configured, so answers come from evidence mode. Choose another under Settings → Chat model.");
        }
        var name = string.IsNullOrWhiteSpace(model.DisplayName) ? model.Id : model.DisplayName;
        if (!model.Enabled || !provider.Enabled)
        {
            return new ModelStatus(false, model.Id, name, $"{name} is turned off in Settings → Providers and models, so answers come from evidence mode.");
        }
        if (provider.NeedsKey && string.IsNullOrWhiteSpace(provider.ApiKey))
        {
            return new ModelStatus(false, model.Id, name, $"{name} needs an API key for {provider.Name}. Paste it under Settings → Providers and models; until then answers come from evidence mode.");
        }
        return new ModelStatus(true, model.Id, name, $"Answers are written by {name} ({provider.Name}) from retrieved repository evidence.");
    }

    /// <summary>
    /// The first model of a real provider that can answer now — on, its provider on, and with a key when it needs one;
    /// null when there is none. The offline simulator is never chosen for you: its answers are made up for demos.
    /// </summary>
    public async Task<AiModel?> FirstUsableModelAsync(CancellationToken ct = default)
    {
        var ai = await _settings.GetAsync(ct);
        return ai.Models
            .Select(m => (Model: m, Provider: ai.Providers.FirstOrDefault(p => p.Id == m.ProviderId)))
            .Where(x => x.Provider is { Enabled: true } provider && provider.Kind != AiProviderKinds.Simulator
                && x.Model.Enabled && (!provider.NeedsKey || provider.ApiKey.Length > 0))
            .Select(x => x.Model)
            .FirstOrDefault();
    }

    /// <summary>
    /// When no model is chosen, or the chosen one can no longer answer, chooses the first usable model. Returns the model
    /// chosen now, or null when the choice did not change.
    /// </summary>
    public async Task<AiModel?> EnsureChatModelAsync(CancellationToken ct = default)
    {
        var settings = await GetExplorerSettingsAsync(ct);
        if (settings.ChatModelId is { Length: > 0 } current && (await StatusOfAsync(current, ct)).Configured)
        {
            return null;
        }
        var usable = await FirstUsableModelAsync(ct);
        if (usable is null)
        {
            return null;
        }
        await UpdateExplorerSettingsAsync(s => s.ChatModelId = usable.Id, ct);
        return usable;
    }

    /// <summary>Sends a tiny request to one model (Settings → Providers and models → Test).</summary>
    public async Task<ModelResult> TestAsync(string modelId, CancellationToken ct = default)
    {
        var status = await StatusOfAsync(modelId, ct);
        if (!status.Configured)
        {
            throw new ProviderException(status.Description, code: "PROVIDER_NOT_CONFIGURED");
        }
        var model = await _models.ResolveAsync(modelId, ct);
        var provider = await _providers.GetAsync(model.ProviderId, ct);
        using var purpose = UsagePurpose.Set($"Test the model {model.Id}");
        return await CallAsync("test", null, model, provider,
            [ModelMessage.System("You are a connectivity check."), ModelMessage.User("Reply with the single word: ready")], 30, ct);
    }

    /// <summary>Whether the chat model in use can view images (attached images are sent to it).</summary>
    public async Task<bool> CurrentModelSupportsImagesAsync(CancellationToken ct = default)
    {
        try
        {
            return (await ResolveAsync(ct)).Model.SupportsImages;
        }
        catch (ProviderException)
        {
            return false;
        }
    }

    private async Task<(ModelConfiguration Model, IAIProvider Provider)> ResolveAsync(CancellationToken ct)
    {
        var status = await GetStatusAsync(ct);
        if (!status.Configured || status.ModelId is null)
        {
            throw new ProviderException(status.Description, code: "PROVIDER_NOT_CONFIGURED");
        }
        var model = await _models.ResolveAsync(status.ModelId, ct);
        var provider = await _providers.GetAsync(model.ProviderId, ct);
        return (model, provider);
    }

    public async Task<ModelResult> CompleteAsync(string feature, string? repositoryId, IReadOnlyList<ModelMessage> messages, int maxOutputTokens, CancellationToken ct)
    {
        var (model, provider) = await ResolveAsync(ct);
        return await CallAsync(feature, repositoryId, model, provider, messages, maxOutputTokens, ct);
    }

    private async Task<ModelResult> CallAsync(string feature, string? repositoryId, ModelConfiguration model, IAIProvider provider, IReadOnlyList<ModelMessage> messages, int maxOutputTokens, CancellationToken ct)
    {
        var request = BuildRequest(model, messages, maxOutputTokens);
        var sw = Stopwatch.StartNew();
        try
        {
            var response = await provider.GenerateAsync(request, ct);
            var result = new ModelResult(response.Text, response.Usage?.InputTokens ?? 0, response.Usage?.OutputTokens ?? 0, sw.ElapsedMilliseconds, model.Id) { FinishReason = response.FinishReason };
            await RecordAsync(feature, repositoryId, model, result, response.Usage?.CachedInputTokens ?? 0, failed: false, ct, new CallDetails(request, false, 0, null));
            return result;
        }
        catch (Exception ex) when (ex is not OperationCanceledException || !ct.IsCancellationRequested)
        {
            // A timeout arrives as a cancellation nobody asked for: it is a failure too, and says so.
            await RecordAsync(feature, repositoryId, model, new ModelResult("", 0, 0, sw.ElapsedMilliseconds, model.Id), 0, failed: true, CancellationToken.None,
                new CallDetails(request, false, 0, ex is OperationCanceledException ? TimedOut : ex.Message));
            throw;
        }
    }

    public async IAsyncEnumerable<string> StreamAsync(string feature, string? repositoryId, IReadOnlyList<ModelMessage> messages, int maxOutputTokens,
        Action<ModelResult> completed, [EnumeratorCancellation] CancellationToken ct, Action<string>? onReasoning = null)
    {
        var (model, provider) = await ResolveAsync(ct);
        var request = BuildRequest(model, messages, maxOutputTokens);
        var sw = Stopwatch.StartNew();
        var text = new StringBuilder();
        UsageRecord? usage = null;
        string? finish = null;
        string? error = null;
        var reasoningChars = 0;
        var failed = true;
        try
        {
            var stream = model.SupportsStreaming ? provider.StreamAsync(request, ct) : SingleChunk(provider, request, ct);
            await using var chunks = stream.GetAsyncEnumerator(ct);
            while (true)
            {
                // The error, when there is one, is noted for the usage record (an iterator cannot catch around a yield).
                ModelStreamChunk chunk;
                try
                {
                    if (!await chunks.MoveNextAsync())
                    {
                        break;
                    }
                    chunk = chunks.Current;
                }
                catch (Exception ex) when (ex is not OperationCanceledException || !ct.IsCancellationRequested)
                {
                    error = ex is OperationCanceledException ? TimedOut : ex.Message;
                    throw;
                }
                switch (chunk.Kind)
                {
                    case StreamChunkKind.TextDelta when chunk.Text is { Length: > 0 } delta:
                        text.Append(delta);
                        yield return delta;
                        break;
                    case StreamChunkKind.Reasoning when chunk.Text is { Length: > 0 } thought:
                        reasoningChars += thought.Length;
                        onReasoning?.Invoke(thought);
                        break;
                    case StreamChunkKind.Usage:
                        usage = chunk.Usage;
                        break;
                    case StreamChunkKind.Finish:
                        finish = chunk.FinishReason ?? finish;
                        break;
                }
            }
            failed = false;
        }
        finally
        {
            var result = new ModelResult(text.ToString(), usage?.InputTokens ?? 0, usage?.OutputTokens ?? 0, sw.ElapsedMilliseconds, model.Id) { FinishReason = finish };
            if (!ct.IsCancellationRequested || text.Length > 0)
            {
                await RecordAsync(feature, repositoryId, model, result, usage?.CachedInputTokens ?? 0, failed, CancellationToken.None,
                    new CallDetails(request, model.SupportsStreaming, reasoningChars, error ?? (!failed ? null
                        : ct.IsCancellationRequested ? "Stopped before it finished."
                        : "The answer ended before the model finished, and the provider reported no error.")));
            }
            if (!failed)
            {
                completed(result);
            }
        }
    }

    private const string TimedOut = "The model did not answer in time (the request timed out). A local model may still be loading; try again, or allow more time in the provider's settings.";

    private static async IAsyncEnumerable<ModelStreamChunk> SingleChunk(IAIProvider provider, ModelRequest request, [EnumeratorCancellation] CancellationToken ct)
    {
        var response = await provider.GenerateAsync(request, ct);
        yield return ModelStreamChunk.Delta(response.Text);
        if (response.Usage is not null)
        {
            yield return ModelStreamChunk.UsageReport(response.Usage);
        }
        yield return ModelStreamChunk.Finished(response.FinishReason);
    }

    private static ModelRequest BuildRequest(ModelConfiguration model, IReadOnlyList<ModelMessage> messages, int maxOutputTokens) => new()
    {
        ModelId = string.IsNullOrWhiteSpace(model.ProviderModelId) ? model.Id : model.ProviderModelId!,
        Messages = messages.ToList(),
        MaxOutputTokens = Math.Min(maxOutputTokens, model.MaxOutputTokens),
        Temperature = model.Temperature,
    };

    /// <summary>What a call sent and how it went, for the usage record's details.</summary>
    private sealed record CallDetails(ModelRequest Request, bool Streamed, int ReasoningChars, string? Error);

    private const int PreviewChars = 1500;
    private const int ResponsePreviewChars = 4000;

    /// <summary>What a call was for, in one line: the question at the end of the assistant's prompt, else the start of the last request.</summary>
    public static string? PurposeOf(IReadOnlyList<ModelMessage> messages)
    {
        var last = messages.LastOrDefault(m => m.Role == MessageRole.User)?.Content;
        if (string.IsNullOrWhiteSpace(last))
        {
            return null;
        }
        var question = last.LastIndexOf("\nQuestion: ", StringComparison.Ordinal);
        var text = question >= 0 ? last[(question + 11)..] : last.StartsWith("Request: ", StringComparison.Ordinal) ? last[9..] : last;
        var line = text.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).FirstOrDefault(l => !l.StartsWith('#')) ?? text;
        return Text.TextUtil.Truncate(line.Trim(), 240);
    }

    private async Task RecordAsync(string feature, string? repositoryId, ModelConfiguration model, ModelResult result, int cached, bool failed, CancellationToken ct, CallDetails? details = null)
    {
        var settings = await GetExplorerSettingsAsync(ct);
        var price = settings.Prices.FirstOrDefault(p => string.Equals(p.ModelId, model.Id, StringComparison.OrdinalIgnoreCase));
        var cost = price is null ? 0m : (result.InputTokens * price.InputPerMillion + result.OutputTokens * price.OutputPerMillion) / 1_000_000m;
        var messages = details?.Request.Messages;
        await _usage.RecordAsync(new UsageEntry
        {
            ProviderModelId = details?.Request.ModelId is { } providerModel && providerModel != model.Id ? providerModel : null,
            Purpose = UsagePurpose.Value ?? (messages is null ? null : PurposeOf(messages)),
            Messages = messages?.Take(24).Select(m => new UsageMessage
            {
                Role = m.Role.ToString().ToLowerInvariant(),
                Chars = m.Content.Length,
                Preview = Text.TextUtil.Truncate(m.Content, PreviewChars),
            }).ToList(),
            Response = result.Text.Length == 0 ? null : Text.TextUtil.Truncate(result.Text, ResponsePreviewChars),
            ResponseChars = result.Text.Length,
            ReasoningChars = details?.ReasoningChars ?? 0,
            FinishReason = result.FinishReason,
            Error = details?.Error is { } error ? Text.TextUtil.Truncate(error, 1000) : null,
            MaxOutputTokens = details?.Request.MaxOutputTokens,
            Temperature = details?.Request.Temperature,
            Streamed = details?.Streamed ?? false,
            InputPricePerMillion = price?.InputPerMillion,
            OutputPricePerMillion = price?.OutputPerMillion,
            Feature = feature,
            ModelId = model.Id,
            ProviderId = model.ProviderId,
            RepositoryId = repositoryId,
            InputTokens = result.InputTokens,
            OutputTokens = result.OutputTokens,
            CachedInputTokens = cached,
            DurationMs = result.DurationMs,
            Cost = Math.Round(cost, 6),
            Failed = failed,
        }, ct);
    }

    /// <summary>
    /// Imports a providers file (Settings → Providers and models → Import from file…): it replaces the providers and
    /// models. Answers then use the file's default model, or keep the current one when it is still listed and on, and
    /// otherwise fall back to evidence mode.
    /// </summary>
    public async Task<AiImportResult> ImportProvidersAsync(string fileText, CancellationToken ct = default)
    {
        // Only encrypted providers files are imported: a plain one could list any provider at all.
        if (!Storage.EncryptedJson.IsEncrypted(fileText))
        {
            throw new Repositories.ExplorerValidationException(
                "Only encrypted providers files can be imported. Encrypt it with scripts\\providers\\Protect-ProvidersFile.ps1 (or ask the team that gives you DocGen Explorer).");
        }
        if (ProvidersKey is null)
        {
            throw new Repositories.ExplorerValidationException(
                "This build of DocGen Explorer has no providers key, so it cannot read encrypted providers files. Build it with secrets\\providers.key in place.");
        }
        var json = Storage.EncryptedJson.Decrypt(fileText, ProvidersKey);
        var result = await _settings.ImportAsync(json, ct);
        // Providers that list their own models (Ollama) are asked now, so their models can be chosen at once.
        await DiscoverModelsAsync(ct: ct);
        var document = await _settings.GetAsync(ct);
        await UpdateExplorerSettingsAsync(s =>
        {
            if (result.DefaultModel is { } chosen)
            {
                s.ChatModelId = document.Models.First(m => string.Equals(m.Id, chosen, StringComparison.OrdinalIgnoreCase)).Id;
            }
            else if (s.ChatModelId is { } current && !document.Models.Any(m => m.Id == current && m.Enabled))
            {
                s.ChatModelId = null;
            }
        }, ct);
        await EnsureChatModelAsync(ct);
        return result;
    }

    /// <summary>For tests: answers the discovery requests instead of the network.</summary>
    internal HttpMessageHandler? DiscoveryHandler { get; set; }

    private readonly System.Collections.Concurrent.ConcurrentDictionary<string, ModelDiscoveryResult> _discoveries = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>What the last check of a provider's server found (null when it was never asked).</summary>
    public ModelDiscoveryResult? LastDiscovery(string providerId) => _discoveries.GetValueOrDefault(providerId);

    /// <summary>
    /// Asks the servers of the providers that discover their models (Ollama) which models they have, and makes those the
    /// provider's models — keeping whether each was turned off. A server that cannot be reached keeps its last list.
    /// </summary>
    public async Task<IReadOnlyList<ModelDiscoveryResult>> DiscoverModelsAsync(string? providerId = null, CancellationToken ct = default)
    {
        var document = await _settings.GetAsync(ct);
        var providers = document.Providers.Where(p => p.DiscoverModels && p.Enabled && (providerId is null || p.Id == providerId)).ToList();
        var results = new List<ModelDiscoveryResult>();
        if (providers.Count == 0)
        {
            return results;
        }
        using var http = DiscoveryHandler is null ? new HttpClient() : new HttpClient(DiscoveryHandler, disposeHandler: false);
        http.Timeout = TimeSpan.FromSeconds(5);
        var changed = false;
        foreach (var provider in providers)
        {
            var url = ModelDiscovery.TagsUrl(provider.BaseUrl);
            ModelDiscoveryResult result;
            try
            {
                var found = ModelDiscovery.Parse(await http.GetStringAsync(url, ct));
                var before = document.Models.Where(m => m.ProviderId == provider.Id).ToList();
                document.Models.RemoveAll(m => m.ProviderId == provider.Id);
                foreach (var model in found)
                {
                    var previous = before.FirstOrDefault(m => m.ProviderModelId == model.Name);
                    document.Models.Add(new AiModel
                    {
                        Id = ModelDiscovery.ModelId(provider.Id, model.Name),
                        ProviderId = provider.Id,
                        ProviderModelId = model.Name,
                        DisplayName = ModelDiscovery.DisplayName(model),
                        ContextWindow = model.ContextLength ?? previous?.ContextWindow ?? 32_000,
                        MaxOutputTokens = previous?.MaxOutputTokens ?? ModelLimits.UsualMaxOutput(model.Name),
                        Temperature = previous?.Temperature,
                        Enabled = previous?.Enabled ?? true,
                    });
                }
                changed = true;
                result = new ModelDiscoveryResult(provider.Id, provider.Name, true, found.Count,
                    found.Count == 0 ? $"{provider.Name} at {url} has no chat models installed (ollama pull <model>)."
                        : $"{found.Count} model{(found.Count == 1 ? "" : "s")} found at {provider.BaseUrl}.", DateTime.Now);
            }
            catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or System.Text.Json.JsonException or InvalidOperationException)
            {
                if (ct.IsCancellationRequested)
                {
                    throw;
                }
                var kept = document.Models.Count(m => m.ProviderId == provider.Id);
                result = new ModelDiscoveryResult(provider.Id, provider.Name, false, kept,
                    $"{provider.Name} could not be reached at {provider.BaseUrl} ({(ex is TaskCanceledException ? "no answer" : ex.Message)})."
                    + (kept > 0 ? $" The {kept} model{(kept == 1 ? "" : "s")} found before are kept." : " Start it, then Find models."), DateTime.Now);
            }
            _discoveries[provider.Id] = result;
            results.Add(result);
        }
        if (changed)
        {
            await _settings.SaveAsync(document, ct);
            // A chosen model the server no longer has gives way to one that can answer.
            await EnsureChatModelAsync(ct);
        }
        return results;
    }

    /// <summary>The team key providers files are encrypted with (built into the app from secrets\providers.key); null when the build has none.</summary>
    public byte[]? ProvidersKey { get; set; }

    /// <summary>Removes a provider; when answers used one of its models they fall back to evidence mode.</summary>
    public async Task RemoveProviderAsync(string providerId, CancellationToken ct = default)
    {
        var models = (await _settings.GetAsync(ct)).Models.Where(m => m.ProviderId == providerId).Select(m => m.Id).ToHashSet();
        await _settings.RemoveProviderAsync(providerId, ct);
        await UpdateExplorerSettingsAsync(s =>
        {
            if (s.ChatModelId is { } current && models.Contains(current))
            {
                s.ChatModelId = null;
            }
        }, ct);
    }
}
