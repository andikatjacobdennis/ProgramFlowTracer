using System.Text.Json;

namespace DocGen.Explorer.Engine.Ai;

/// <summary>What asking a provider's server for its models found.</summary>
public sealed record ModelDiscoveryResult(string ProviderId, string ProviderName, bool Reached, int Models, string Message, DateTime At);

/// <summary>
/// The models an Ollama server has, read from its own list (GET {address}/api/tags) instead of the providers file — a
/// provider with <c>"discoverModels": true</c>. Models that cannot chat (embedding models) are left out; each model's
/// context length is taken from the server when it says.
/// </summary>
public static class ModelDiscovery
{
    /// <summary>One model the server has.</summary>
    public sealed record Found(string Name, string? ParameterSize, int? ContextLength);

    /// <summary>The server's list address: the provider's address without a trailing /v1 (Ollama's chat-completions API).</summary>
    public static string TagsUrl(string baseUrl)
    {
        var root = baseUrl.Trim().TrimEnd('/');
        if (root.EndsWith("/v1", StringComparison.OrdinalIgnoreCase))
        {
            root = root[..^3];
        }
        return root + "/api/tags";
    }

    /// <summary>Reads Ollama's /api/tags answer.</summary>
    public static List<Found> Parse(string json)
    {
        using var document = JsonDocument.Parse(json);
        var found = new List<Found>();
        if (!document.RootElement.TryGetProperty("models", out var models) || models.ValueKind != JsonValueKind.Array)
        {
            return found;
        }
        foreach (var model in models.EnumerateArray())
        {
            var name = model.TryGetProperty("name", out var n) ? n.GetString() : model.TryGetProperty("model", out var m) ? m.GetString() : null;
            if (string.IsNullOrWhiteSpace(name))
            {
                continue;
            }
            // Servers that list capabilities say which models can chat; embedding models cannot answer a question.
            if (model.TryGetProperty("capabilities", out var capabilities) && capabilities.ValueKind == JsonValueKind.Array
                && !capabilities.EnumerateArray().Any(c => c.GetString() == "completion"))
            {
                continue;
            }
            string? size = null;
            int? context = null;
            if (model.TryGetProperty("details", out var details) && details.ValueKind == JsonValueKind.Object)
            {
                size = details.TryGetProperty("parameter_size", out var s) ? s.GetString() : null;
                context = details.TryGetProperty("context_length", out var c) && c.TryGetInt32(out var length) ? length : null;
            }
            found.Add(new Found(name, size, context));
        }
        return found;
    }

    /// <summary>The model id in the explorer: the provider's id and the server's model name (unique across providers).</summary>
    public static string ModelId(string providerId, string name) => $"{providerId}/{name}";

    public static string DisplayName(Found model)
    {
        var name = model.Name.EndsWith(":latest", StringComparison.Ordinal) ? model.Name[..^":latest".Length] : model.Name;
        return model.ParameterSize is { Length: > 0 } size ? $"{name} ({size})" : name;
    }
}
