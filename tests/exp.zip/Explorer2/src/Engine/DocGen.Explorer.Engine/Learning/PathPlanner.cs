using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;
using DocGen.Analysis.Indexing;

namespace DocGen.Explorer.Engine.Learning;

/// <summary>
/// Plans a learning path: sessions in an order that builds on itself — the documentation first, then the projects from
/// the foundations up (dependency order), and within each the types the rest of the code leans on most.
/// </summary>
public static class PathPlanner
{
    private const int LinesPerMinute = 40;

    public static LearningPath Plan(RepositoryIndex index, GenerationOptions options)
    {
        var sessions = new List<LearningSession>();
        var maxSessions = Math.Clamp(options.Count, 2, 20);
        var scope = options.Scope;
        var graph = index.Graph;

        int InDegree(string id) => graph.Edges.Count(e => e.To == id && e.Kind is EdgeKinds.Uses or EdgeKinds.Inherits or EdgeKinds.Tests or EdgeKinds.Mentions);
        string FileLink(string path, int line = 0) => line > 0 ? $"{path}:{line}" : path;
        int Minutes(IEnumerable<string> paths) => Math.Clamp(paths.Sum(p => index.FindFile(p.Split(':')[0])?.Lines ?? 50) / LinesPerMinute, 10, 60);

        // 1. Start with the documentation.
        var docs = index.Pages.Where(p => !p.Generated && p.SourcePath is not null && RepositoryIndex.InScope(p.SourcePath, scope))
            .OrderBy(p => p.SourcePath!.Contains("README", StringComparison.OrdinalIgnoreCase) ? 0 : 1).ThenBy(p => p.SourcePath!.Count(c => c == '/')).ThenBy(p => p.TreePath, StringComparer.OrdinalIgnoreCase).ToList();
        var entry = index.Okf.FirstOrDefault(o => o.Kind == "entrypoint");
        var testProject = index.Code?.Manifest.Projects.FirstOrDefault(p => p.IsTestProject);
        {
            var readFirst = docs.Take(2).Select(p => p.SourcePath!).ToList();
            if (readFirst.Count == 0)
            {
                readFirst.Add("Reference/Overview (generated page)");
            }
            var readNext = docs.Skip(2).Take(3).Select(p => p.SourcePath!).ToList();
            if (index.Code is { Types: var t } && t.Any())
            {
                readNext.Add("Reference/Architecture (generated page)");
            }
            sessions.Add(new LearningSession
            {
                Title = "What this repository is for",
                Goal = "Know what the repository does, how it is laid out and how to run it.",
                ReadFirst = readFirst,
                ReadNext = readNext,
                TryThis = entry is not null
                    ? $"Find where execution starts ({entry.Name}, {FileLink(entry.Path, entry.Line)}) and run it."
                    : testProject is not null ? $"Run the tests: dotnet test {testProject.Path}." : "Open the Graph and find the repository's most connected concept.",
                Minutes = Minutes(readFirst.Concat(readNext).Where(p => !p.Contains('(')).ToList()),
            });
        }

        // 2. Projects from the foundations up (or top-level folders when there are no projects).
        var units = new List<(string Title, List<GraphNode> Types, bool IsTest)>();
        if (index.Code is { } code && code.Manifest.Projects.Count > 0)
        {
            foreach (var project in TopologicalOrder(code.Manifest.Projects))
            {
                var types = graph.Nodes.Where(n => ConceptTypes.IsType(n.Type) && n.Path is not null && RepositoryIndex.InScope(n.Path, scope)
                                                    && code.Files.TryGetValue(n.Path, out var f) && f.Project == project.Name).ToList();
                if (types.Count > 0)
                {
                    units.Add((project.Name, types, project.IsTestProject));
                }
            }
        }
        else
        {
            foreach (var folder in index.Files.Where(f => f.Kind == FileKind.Source && RepositoryIndex.InScope(f.Path, scope))
                         .GroupBy(f => f.Path.Contains('/') ? f.Path[..f.Path.IndexOf('/')] : "(root)").OrderByDescending(g => g.Count()))
            {
                var nodes = folder.Select(f => graph.Find("file:" + f.Path) ?? new GraphNode { Id = "file:" + f.Path, Label = f.Name, Type = ConceptTypes.File, Path = f.Path, Line = 1 }).ToList();
                units.Add((folder.Key, nodes, folder.Key.Contains("test", StringComparison.OrdinalIgnoreCase)));
            }
        }

        // Audience shapes the order: QA engineers meet the tests early, architects see structure first.
        if (options.Audience == "QA engineer")
        {
            units = units.OrderBy(u => u.IsTest ? 0 : 1).ToList();
        }
        else
        {
            units = units.OrderBy(u => u.IsTest ? 1 : 0).ToList();
        }

        foreach (var unit in units)
        {
            if (sessions.Count >= maxSessions)
            {
                break;
            }
            var ranked = unit.Types.OrderByDescending(n => InDegree(n.Id)).ThenBy(n => n.Label, StringComparer.Ordinal).ToList();
            var perSession = options.Audience is "New developer" or "Product manager" ? 2 : options.Difficulty == Difficulty.Hard ? 4 : 3;
            for (var start = 0; start < ranked.Count && sessions.Count < maxSessions; start += perSession * 2)
            {
                var first = ranked.Skip(start).Take(perSession).ToList();
                var next = ranked.Skip(start + perSession).Take(perSession).ToList();
                if (first.Count == 0)
                {
                    break;
                }
                var lead = first[0];
                var dependsOn = graph.Edges.Where(e => e.From == lead.Id && e.Kind == EdgeKinds.Uses).Select(e => graph.Find(e.To)?.Label).OfType<string>().Take(2).ToList();
                var tests = graph.Edges.Where(e => e.To == lead.Id && e.Kind == EdgeKinds.Tests).Select(e => graph.Find(e.From)).OfType<GraphNode>().FirstOrDefault();
                var tryThis = unit.IsTest
                    ? $"Run {lead.Label} and change one assertion to see it fail, then put it back."
                    : tests is not null
                        ? $"Read {tests.Label} ({FileLink(tests.Path ?? "", tests.Line ?? 0)}) to see {lead.Label} in use, then ask the assistant what would break if {lead.Label} changed."
                        : dependsOn.Count > 0
                            ? $"Ask the assistant: \"How does {lead.Label} use {dependsOn[0]}?\" and check the answer against the code."
                            : $"Find every place {lead.Label} is used (Graph → search \"{lead.Label}\").";
                var readFirst = first.Select(n => FileLink(n.Path ?? "", n.Line ?? 0)).ToList();
                var readNext = next.Select(n => FileLink(n.Path ?? "", n.Line ?? 0)).ToList();
                sessions.Add(new LearningSession
                {
                    Title = start == 0 ? unit.Title : $"{unit.Title} (continued)",
                    Goal = $"Understand {TextUtil.JoinNatural(first.Select(n => n.Label))}" + (dependsOn.Count > 0 ? $" and how they lean on {TextUtil.JoinNatural(dependsOn)}." : "."),
                    ReadFirst = readFirst,
                    ReadNext = readNext,
                    TryThis = tryThis,
                    Minutes = Minutes(readFirst.Concat(readNext)),
                });
                if (options.Difficulty == Difficulty.Easy)
                {
                    break; // an easy path keeps to one session per project
                }
            }
        }

        for (var i = 0; i < sessions.Count; i++)
        {
            sessions[i].Number = i + 1;
        }
        var total = sessions.Sum(s => s.Minutes);
        return new LearningPath
        {
            Title = string.IsNullOrWhiteSpace(options.Title) ? $"{index.Repository.Title}: learning path" : options.Title!.Trim(),
            Options = options,
            Sessions = sessions,
            Introduction = $"{TextUtil.Plural(sessions.Count, "session")} for a {options.Audience.ToLowerInvariant()}, about {total} minutes in all. " +
                           "Each session names what to read first, what to read next, and something to try; later sessions build on earlier ones.",
            Provenance = QuizGenerator.OfflineProvenance,
        };
    }

    /// <summary>Projects ordered so that every project comes after the projects it references (cycles broken by name).</summary>
    public static List<ProjectInfo> TopologicalOrder(IReadOnlyList<ProjectInfo> projects)
    {
        var byName = projects.GroupBy(p => p.Name, StringComparer.OrdinalIgnoreCase).ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
        var result = new List<ProjectInfo>();
        var state = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase); // 1 visiting, 2 done
        void Visit(ProjectInfo project)
        {
            if (state.GetValueOrDefault(project.Name) != 0)
            {
                return;
            }
            state[project.Name] = 1;
            foreach (var reference in project.ProjectReferences.Select(r => Path.GetFileNameWithoutExtension(r)!).OrderBy(r => r, StringComparer.OrdinalIgnoreCase))
            {
                if (byName.TryGetValue(reference, out var dependency))
                {
                    Visit(dependency);
                }
            }
            state[project.Name] = 2;
            result.Add(project);
        }
        foreach (var project in byName.Values.OrderBy(p => p.Name, StringComparer.OrdinalIgnoreCase))
        {
            Visit(project);
        }
        return result;
    }
}
