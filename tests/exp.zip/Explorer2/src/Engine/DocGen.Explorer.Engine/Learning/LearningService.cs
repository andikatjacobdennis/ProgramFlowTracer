using DocGen.Explorer.Engine.Ai;
using DocGen.Explorer.Engine.Assistant;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Engine.Storage;
using DocGen.Explorer.Engine.Text;
using DocGen.Core.Abstractions;

namespace DocGen.Explorer.Engine.Learning;

/// <summary>
/// Study material for a repository — paths, quizzes, flashcards, a FAQ and the knowledge record. Nothing is made until it
/// is asked for. Quizzes and flashcards are always written offline from the index; paths and the FAQ are polished by the
/// chat model when one is configured, and written offline otherwise.
/// </summary>
public sealed class LearningService(ExplorerStore store, IndexingPipeline pipeline, AssistantService assistant, IModelGateway models)
{
    private readonly SemaphoreSlim _gate = new(1, 1);

    private static string LibraryPath(string repositoryId) => $"repos/{repositoryId}/learning.json";

    private static string KnowledgePath(string repositoryId) => $"repos/{repositoryId}/knowledge.json";

    public async Task<LearningLibrary> GetLibraryAsync(string repositoryId, CancellationToken ct = default)
        => await store.ReadAsync<LearningLibrary>(LibraryPath(repositoryId), ct) ?? new LearningLibrary();

    public async Task<KnowledgeRecord> GetKnowledgeAsync(string repositoryId, CancellationToken ct = default)
        => await store.ReadAsync<KnowledgeRecord>(KnowledgePath(repositoryId), ct) ?? new KnowledgeRecord();

    private async Task<T> MutateAsync<T>(string repositoryId, Func<LearningLibrary, T> mutate, CancellationToken ct)
    {
        await _gate.WaitAsync(ct);
        try
        {
            var library = await GetLibraryAsync(repositoryId, ct);
            var result = mutate(library);
            await store.WriteAsync(LibraryPath(repositoryId), library, ct);
            return result;
        }
        finally
        {
            _gate.Release();
        }
    }

    private async Task AddKnowledgeAsync(string repositoryId, IEnumerable<KnowledgeEvent> events, CancellationToken ct)
    {
        await _gate.WaitAsync(ct);
        try
        {
            var record = await GetKnowledgeAsync(repositoryId, ct);
            record.Events.AddRange(events);
            if (record.Events.Count > 20_000)
            {
                record.Events.RemoveRange(0, record.Events.Count - 20_000);
            }
            await store.WriteAsync(KnowledgePath(repositoryId), record, ct);
        }
        finally
        {
            _gate.Release();
        }
    }

    private async Task<RepositoryIndex> RequireIndexAsync(string repositoryId, CancellationToken ct)
        => await pipeline.GetAsync(repositoryId, ct) ?? throw new ExplorerValidationException("Index the repository first (Indexing → Full reindex).");

    public async Task<Quiz> CreateQuizAsync(string repositoryId, GenerationOptions options, CancellationToken ct = default)
    {
        Validate(options);
        var index = await RequireIndexAsync(repositoryId, ct);
        var quiz = QuizGenerator.Generate(index, options);
        if (quiz.Questions.Count == 0)
        {
            throw new ExplorerValidationException("The selection holds nothing a question can be written about. Choose more of the repository or other topics.");
        }
        return await MutateAsync(repositoryId, library => { library.Quizzes.Insert(0, quiz); return quiz; }, ct);
    }

    /// <summary>"Generate again": a new quiz with the same settings and a new seed.</summary>
    public async Task<Quiz> RegenerateQuizAsync(string repositoryId, string quizId, CancellationToken ct = default)
    {
        var library = await GetLibraryAsync(repositoryId, ct);
        var existing = library.Quizzes.FirstOrDefault(q => q.Id == quizId) ?? throw new ExplorerValidationException("That quiz no longer exists.");
        var options = Clone(existing.Options);
        options.Seed = existing.Options.Seed + 1 + library.Quizzes.Count;
        options.Title = existing.Title;
        return await CreateQuizAsync(repositoryId, options, ct);
    }

    public async Task<QuizAttempt> SubmitQuizAsync(string repositoryId, string quizId, IReadOnlyList<int> answers, long durationSeconds, CancellationToken ct = default)
    {
        Quiz? quiz = null;
        var attempt = await MutateAsync(repositoryId, library =>
        {
            quiz = library.Quizzes.FirstOrDefault(q => q.Id == quizId) ?? throw new ExplorerValidationException("That quiz no longer exists.");
            var scored = QuizGenerator.Score(quiz, answers, durationSeconds);
            quiz.Attempts.Add(scored);
            return scored;
        }, ct);
        await AddKnowledgeAsync(repositoryId, KnowledgeTracker.FromAttempt(quiz!, attempt), ct);
        return attempt;
    }

    public async Task<LearningPath> CreatePathAsync(string repositoryId, GenerationOptions options, CancellationToken ct = default)
    {
        Validate(options);
        var index = await RequireIndexAsync(repositoryId, ct);
        var path = PathPlanner.Plan(index, options);
        var status = await models.GetStatusAsync(ct);
        if (status.Configured)
        {
            try
            {
                var outline = string.Join("\n", path.Sessions.Select(s => $"{s.Number}. {s.Title} — {s.Goal} Read: {string.Join(", ", s.ReadFirst)}"));
                using var purpose = UsagePurpose.Set($"Introduce a {path.Sessions.Count}-session learning path for {options.Audience}");
                var result = await models.CompleteAsync("learning", repositoryId,
                [
                    ModelMessage.System("You write short, encouraging introductions to study plans for source code. Use only the facts given. " + Ai.PlainLanguage.Short),
                    ModelMessage.User($"Repository: {index.Repository.Title}. Reader: {options.Audience}. Write a 3-4 sentence introduction to this study plan, saying what the reader will understand by the end.\n\n{outline}"),
                ], 400, ct);
                if (result.Text.Trim().Length > 0)
                {
                    path.Introduction = result.Text.Trim();
                    path.Provenance = $"Planned offline from the index; introduction written by {status.DisplayName}.";
                }
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                path.Provenance += $" (The model was unavailable: {TextUtil.Truncate(ex.Message, 120)})";
            }
        }
        return await MutateAsync(repositoryId, library => { library.Paths.Insert(0, path); return path; }, ct);
    }

    public async Task SetSessionCompletedAsync(string repositoryId, string pathId, int sessionNumber, bool completed, CancellationToken ct = default)
        => await MutateAsync(repositoryId, library =>
        {
            var session = library.Paths.FirstOrDefault(p => p.Id == pathId)?.Sessions.FirstOrDefault(s => s.Number == sessionNumber);
            if (session is not null)
            {
                session.Completed = completed;
            }
            return 0;
        }, ct);

    public async Task<FlashcardDeck> CreateDeckAsync(string repositoryId, GenerationOptions options, CancellationToken ct = default)
    {
        Validate(options);
        var index = await RequireIndexAsync(repositoryId, ct);
        var deck = FlashcardGenerator.Generate(index, options);
        if (deck.Cards.Count == 0)
        {
            throw new ExplorerValidationException("No cards could be written for this selection.");
        }
        return await MutateAsync(repositoryId, library => { library.Decks.Insert(0, deck); return deck; }, ct);
    }

    public async Task<Flashcard> ReviewCardAsync(string repositoryId, string deckId, string cardId, RecallGrade grade, DateTime? now = null, CancellationToken ct = default)
    {
        var card = await MutateAsync(repositoryId, library =>
        {
            var found = library.Decks.FirstOrDefault(d => d.Id == deckId)?.Cards.FirstOrDefault(c => c.Id == cardId) ?? throw new ExplorerValidationException("That card no longer exists.");
            FlashcardScheduler.Review(found, grade, now ?? DateTime.UtcNow);
            return found;
        }, ct);
        await AddKnowledgeAsync(repositoryId, [KnowledgeTracker.FromReview(card, grade)], ct);
        return card;
    }

    public async Task<Faq> CreateFaqAsync(string repositoryId, GenerationOptions options, IProgress<string>? progress = null, CancellationToken ct = default)
    {
        Validate(options);
        var index = await RequireIndexAsync(repositoryId, ct);
        var questions = FaqQuestions(index, Math.Clamp(options.Count, 1, 25));
        var status = await models.GetStatusAsync(ct);
        var faq = new Faq
        {
            Title = string.IsNullOrWhiteSpace(options.Title) ? $"{index.Repository.Title}: FAQ" : options.Title!.Trim(),
            Options = options,
            Provenance = status.Configured ? $"Answered by {status.DisplayName} from retrieved evidence." : QuizGenerator.OfflineProvenance,
        };
        var depth = options.Difficulty switch { Difficulty.Easy => AnalysisDepth.Quick, Difficulty.Hard => AnalysisDepth.Detailed, _ => AnalysisDepth.Balanced };
        var n = 0;
        foreach (var question in questions)
        {
            ct.ThrowIfCancellationRequested();
            progress?.Report($"Answering {++n} of {questions.Count}: {question}");
            var answer = await assistant.AnswerAsync(repositoryId, question, depth, options.Scope, [], null, ct);
            faq.Entries.Add(new FaqEntry
            {
                Question = question,
                Answer = answer.Text.Replace(EvidenceComposer.OfflineNote, "", StringComparison.Ordinal).Trim(),
                Citations = answer.Citations,
            });
        }
        return await MutateAsync(repositoryId, library => { library.Faqs.Insert(0, faq); return faq; }, ct);
    }

    /// <summary>The questions somebody would actually ask about this repository.</summary>
    public static List<string> FaqQuestions(RepositoryIndex index, int count)
    {
        var questions = new List<string> { "What is this repository for, and how is it organised?" };
        questions.Add(index.Code?.Manifest.Projects.Any(p => p.IsTestProject) == true ? "How are the tests organised, and how do I run them?" : "How do I build and run it?");
        if (index.Okf.Any(o => o.Kind == "config") || index.Files.Any(f => f.Name.StartsWith("appsettings", StringComparison.OrdinalIgnoreCase)))
        {
            questions.Add("Where is the configuration defined?");
        }
        if (index.Okf.Any(o => o.Kind == "endpoint"))
        {
            questions.Add("Which HTTP endpoints does it expose?");
        }
        if (index.Okf.Any(o => o.Kind == "entrypoint"))
        {
            questions.Add("Where does execution start?");
        }
        foreach (var suggestion in AssistantService.Suggestions(index).Skip(1))
        {
            questions.Add(suggestion);
        }
        var graph = index.Graph;
        foreach (var node in graph.Nodes.Where(n => ConceptTypes.IsType(n.Type) && n.Type != ConceptTypes.Test)
                     .OrderByDescending(n => graph.Edges.Count(e => e.To == n.Id)).ThenBy(n => n.Label, StringComparer.Ordinal).Take(count))
        {
            questions.Add($"What does {node.Label} do?");
        }
        return questions.Distinct(StringComparer.OrdinalIgnoreCase).Take(count).ToList();
    }

    // Item menu: Rename, Duplicate, Archive, Delete — for every kind of material.
    public Task RenameAsync(string repositoryId, string itemId, string title, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(title))
        {
            throw new ExplorerValidationException("Type a title.");
        }
        return MutateAsync(repositoryId, library => { Find(library, itemId).Title = title.Trim(); return 0; }, ct);
    }

    public Task ArchiveAsync(string repositoryId, string itemId, bool archived, CancellationToken ct = default)
        => MutateAsync(repositoryId, library => { Find(library, itemId).Archived = archived; return 0; }, ct);

    public Task DeleteAsync(string repositoryId, string itemId, CancellationToken ct = default)
        => MutateAsync(repositoryId, library =>
        {
            library.Quizzes.RemoveAll(i => i.Id == itemId);
            library.Paths.RemoveAll(i => i.Id == itemId);
            library.Decks.RemoveAll(i => i.Id == itemId);
            library.Faqs.RemoveAll(i => i.Id == itemId);
            return 0;
        }, ct);

    public Task<LearningItem> DuplicateAsync(string repositoryId, string itemId, CancellationToken ct = default)
        => MutateAsync(repositoryId, library =>
        {
            var item = Find(library, itemId);
            var json = System.Text.Json.JsonSerializer.Serialize(item, item.GetType(), DocGen.Core.Json.DocGenJson.Wire);
            var copy = (LearningItem)System.Text.Json.JsonSerializer.Deserialize(json, item.GetType(), DocGen.Core.Json.DocGenJson.Wire)!;
            copy.Id = Guid.NewGuid().ToString("N");
            copy.Title = item.Title + " (copy)";
            copy.CreatedAt = DateTime.UtcNow;
            switch (copy)
            {
                case Quiz q:
                    q.Attempts.Clear();
                    library.Quizzes.Insert(0, q);
                    break;
                case LearningPath p:
                    p.Sessions.ForEach(s => s.Completed = false);
                    library.Paths.Insert(0, p);
                    break;
                case FlashcardDeck d:
                    foreach (var card in d.Cards)
                    {
                        card.Id = Guid.NewGuid().ToString("N");
                        card.DueAt = DateTime.UtcNow;
                        card.Repetitions = card.Reviews = card.Lapses = card.IntervalDays = 0;
                        card.Ease = 2.5;
                    }
                    library.Decks.Insert(0, d);
                    break;
                case Faq f:
                    library.Faqs.Insert(0, f);
                    break;
            }
            return copy;
        }, ct);

    private static LearningItem Find(LearningLibrary library, string itemId)
        => (LearningItem?)library.Quizzes.FirstOrDefault(i => i.Id == itemId)
           ?? (LearningItem?)library.Paths.FirstOrDefault(i => i.Id == itemId)
           ?? (LearningItem?)library.Decks.FirstOrDefault(i => i.Id == itemId)
           ?? (LearningItem?)library.Faqs.FirstOrDefault(i => i.Id == itemId)
           ?? throw new ExplorerValidationException("That item no longer exists.");

    private static void Validate(GenerationOptions options)
    {
        if (options.Count is < 1 or > 200)
        {
            throw new ExplorerValidationException("Choose between 1 and 200 items.");
        }
        if (options.PassMarkPercent is < 0 or > 100)
        {
            throw new ExplorerValidationException("The pass mark is a percentage between 0 and 100.");
        }
        if (options.TimeLimitMinutes is < 0 or > 600)
        {
            throw new ExplorerValidationException("The time limit is between 0 (none) and 600 minutes.");
        }
        if (!Audiences.All.Contains(options.Audience))
        {
            options.Audience = "Developer";
        }
        options.Topics = options.Topics.Where(t => LearningTopics.All.Contains(t)).Distinct().ToList();
    }

    private static GenerationOptions Clone(GenerationOptions o) => new()
    {
        Title = o.Title,
        Count = o.Count,
        Difficulty = o.Difficulty,
        Audience = o.Audience,
        Topics = [.. o.Topics],
        PassMarkPercent = o.PassMarkPercent,
        TimeLimitMinutes = o.TimeLimitMinutes,
        Feedback = o.Feedback,
        ShuffleQuestions = o.ShuffleQuestions,
        ShuffleAnswers = o.ShuffleAnswers,
        Scope = [.. o.Scope],
        Seed = o.Seed,
    };
}
