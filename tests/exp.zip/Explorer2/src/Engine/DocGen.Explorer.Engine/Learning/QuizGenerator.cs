using DocGen.Explorer.Engine.Documentation;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;
using DocGen.Analysis.Indexing;

namespace DocGen.Explorer.Engine.Learning;

/// <summary>
/// Writes multiple-choice quizzes offline from the index — no model involved, so the questions are verifiable facts
/// (where a type lives, what it derives from, what it returns, what uses it…) and marking is arithmetic.
/// Generation is deterministic for the same repository, settings and seed.
/// </summary>
public static class QuizGenerator
{
    public const string OfflineProvenance = "Written offline from retrieved evidence, without a model.";

    private sealed record Candidate(string Template, string Topic, Difficulty Level, string Concept, string Prompt, string Correct, List<string> Distractors,
        string Explanation, string? Path, int Line, IReadOnlyCollection<string> ExtraTopics);

    private static readonly string[] SecurityWords = ["Auth", "Security", "Token", "Password", "Crypt", "Permission", "Credential", "Secret", "Login", "Claim", "Role", "Hash", "Sign"];
    private static readonly string[] DatabaseWords = ["Db", "Database", "Repository", "Sql", "Context", "Store", "Query", "Entity", "Migration", "Table", "Record", "Persist"];

    public static Quiz Generate(RepositoryIndex index, GenerationOptions options)
    {
        var count = Math.Clamp(options.Count, 1, 50);
        var random = new Random((int)TextUtil.Fnv1a($"{index.Repository.Id}|{options.Seed}|{options.Difficulty}|{options.Audience}|{string.Join(",", options.Topics)}|{string.Join(",", options.Scope)}|{count}"));
        var candidates = Candidates(index, options.Scope);

        var chosenTopics = options.Topics.Count > 0 ? options.Topics.ToHashSet(StringComparer.OrdinalIgnoreCase) : null;
        var audienceBoost = AudienceTopics(options.Audience);
        double Weight(Candidate c)
        {
            var w = 1.0;
            var difference = Math.Abs((int)c.Level - (int)options.Difficulty);
            w *= difference switch { 0 => 3.0, 1 => 1.0, _ => 0.3 };
            if (chosenTopics is null && (audienceBoost.Contains(c.Topic) || c.ExtraTopics.Any(audienceBoost.Contains)))
            {
                w *= 2.0;
            }
            return w * (0.5 + random.NextDouble());
        }

        bool Matches(Candidate c) => chosenTopics is null || chosenTopics.Contains(c.Topic) || c.ExtraTopics.Any(chosenTopics.Contains);
        var primary = candidates.Where(Matches).OrderByDescending(Weight).ToList();
        var secondary = candidates.Where(c => !Matches(c)).OrderByDescending(Weight).ToList();

        var selected = new List<Candidate>();
        var perConcept = new Dictionary<string, int>(StringComparer.Ordinal);
        var usedPrompts = new HashSet<string>(StringComparer.Ordinal);
        var perTemplate = new Dictionary<string, int>(StringComparer.Ordinal);
        void Take(IEnumerable<Candidate> pool, int maxPerTemplate)
        {
            foreach (var c in pool)
            {
                if (selected.Count >= count)
                {
                    return;
                }
                if (usedPrompts.Contains(c.Prompt) || perConcept.GetValueOrDefault(c.Concept) >= 2 || perTemplate.GetValueOrDefault(c.Template) >= maxPerTemplate)
                {
                    continue;
                }
                selected.Add(c);
                usedPrompts.Add(c.Prompt);
                perConcept[c.Concept] = perConcept.GetValueOrDefault(c.Concept) + 1;
                perTemplate[c.Template] = perTemplate.GetValueOrDefault(c.Template) + 1;
            }
        }
        var templateCap = Math.Max(2, (int)Math.Ceiling(count / 3.0));
        Take(primary, templateCap);
        Take(primary, int.MaxValue);
        var fromPrimary = selected.Count;
        Take(secondary, templateCap);
        Take(secondary, int.MaxValue);

        if (!options.ShuffleQuestions)
        {
            selected = selected.OrderBy(c => LearningTopics.All.ToList().IndexOf(c.Topic)).ThenBy(c => c.Level).ToList();
        }

        var quiz = new Quiz
        {
            Title = string.IsNullOrWhiteSpace(options.Title) ? $"{index.Repository.Title}: quiz" : options.Title!.Trim(),
            Options = options,
            Provenance = OfflineProvenance + (chosenTopics is not null && fromPrimary < selected.Count
                ? $" Only {fromPrimary} question{(fromPrimary == 1 ? "" : "s")} could be written for the chosen topics; the rest come from other parts of the repository."
                : "") + (selected.Count < count ? $" The repository supports {selected.Count} distinct question{(selected.Count == 1 ? "" : "s")} for these settings." : ""),
        };
        var n = 0;
        foreach (var c in selected)
        {
            var distractors = c.Distractors.Where(d => !string.Equals(d, c.Correct, StringComparison.Ordinal)).Distinct(StringComparer.Ordinal).OrderBy(_ => random.Next()).Take(3).ToList();
            var optionsList = distractors.Append(c.Correct).ToList();
            int correctIndex;
            if (options.ShuffleAnswers)
            {
                optionsList = optionsList.OrderBy(_ => random.Next()).ToList();
                correctIndex = optionsList.IndexOf(c.Correct);
            }
            else
            {
                optionsList = distractors.OrderBy(d => d, StringComparer.Ordinal).ToList();
                correctIndex = (int)(TextUtil.Fnv1a(c.Prompt) % (uint)(optionsList.Count + 1));
                optionsList.Insert(correctIndex, c.Correct);
            }
            quiz.Questions.Add(new QuizQuestion
            {
                Id = $"q{++n}",
                Prompt = c.Prompt,
                Options = optionsList,
                CorrectIndex = correctIndex,
                Explanation = c.Explanation,
                Topic = c.Topic,
                Path = c.Path,
                Line = c.Line,
                Concept = c.Concept,
            });
        }
        return quiz;
    }

    private static HashSet<string> AudienceTopics(string audience) => audience switch
    {
        "New developer" => [LearningTopics.Setup, LearningTopics.Classes, LearningTopics.Architecture],
        "Senior developer" => [LearningTopics.DomainLogic, LearningTopics.Dependencies, LearningTopics.Services],
        "Architect" => [LearningTopics.Architecture, LearningTopics.Dependencies, LearningTopics.Services],
        "QA engineer" => [LearningTopics.Testing, LearningTopics.DomainLogic],
        "DevOps engineer" => [LearningTopics.Infrastructure, LearningTopics.Configuration, LearningTopics.Setup],
        "Product manager" => [LearningTopics.Setup, LearningTopics.Apis, LearningTopics.Architecture],
        "Security engineer" => [LearningTopics.Security, LearningTopics.Configuration, LearningTopics.Apis],
        _ => [LearningTopics.Classes, LearningTopics.DomainLogic],
    };

    private static string[] ExtraTopicsFor(string name)
    {
        var extra = new List<string>();
        if (SecurityWords.Any(w => name.Contains(w, StringComparison.Ordinal)))
        {
            extra.Add(LearningTopics.Security);
        }
        if (DatabaseWords.Any(w => name.Contains(w, StringComparison.Ordinal)))
        {
            extra.Add(LearningTopics.Database);
        }
        return [.. extra];
    }

    private static List<Candidate> Candidates(RepositoryIndex index, IReadOnlyCollection<string> scope)
    {
        var list = new List<Candidate>();
        var code = index.Code;
        var inScopeFiles = index.Files.Where(f => RepositoryIndex.InScope(f.Path, scope)).ToList();
        var allSourceFiles = index.Files.Where(f => f.Kind == FileKind.Source).Select(f => f.Path).ToList();

        if (code is not null)
        {
            var types = code.Types.Where(t => RepositoryIndex.InScope(t.File, scope)).GroupBy(t => t.FullName).Select(g => g.First()).ToList();
            var allTypes = code.Types.GroupBy(t => t.FullName).Select(g => g.First()).ToList();
            var allTypeNames = allTypes.Select(t => t.Name).Distinct().ToList();
            var namespaces = allTypes.Select(t => t.Namespace).Where(n => n.Length > 0).Distinct().ToList();
            var testContainers = code.TestMethods.Select(m => m.Container).Where(c => c is not null).ToHashSet(StringComparer.Ordinal);
            // Distractor pools are built once; each question samples from them deterministically.
            var memberPool = code.Symbols.Where(s => s.Kind is SymbolKinds.Method or SymbolKinds.Property).Select(s => s.Name).Distinct().OrderBy(n => n, StringComparer.Ordinal).ToList();
            var returnPool = code.Symbols.Where(s => s.Kind == SymbolKinds.Method && s.ReturnType is { Length: > 0 }).Select(s => s.ReturnType!)
                .Concat(["void", "bool", "string", "int", "Task"]).Distinct().OrderBy(n => n, StringComparer.Ordinal).ToList();
            var methodPool = code.Symbols.Where(s => s.Kind == SymbolKinds.Method).Select(s => CodeIndexHelpers.ShortName(s.FullName)).Distinct().OrderBy(n => n, StringComparer.Ordinal).ToList();
            var typeNamePool = allTypeNames.OrderBy(n => n, StringComparer.Ordinal).ToList();
            var filesByExtension = allSourceFiles.GroupBy(f => Path.GetExtension(f), StringComparer.OrdinalIgnoreCase).ToDictionary(g => g.Key, g => g.OrderBy(f => f, StringComparer.Ordinal).ToList(), StringComparer.OrdinalIgnoreCase);

            foreach (var type in types)
            {
                var isTest = type.IsTest || testContainers.Contains(type.FullName);
                var topic = isTest ? LearningTopics.Testing : LearningTopics.Classes;
                var extra = ExtraTopicsFor(type.Name);
                var where = $"`{type.Name}` is declared in `{type.File}` at line {type.StartLine}.";

                // Which file declares it?
                var sameKind = filesByExtension.GetValueOrDefault(Path.GetExtension(type.File)) ?? allSourceFiles;
                var otherFiles = Sample(sameKind, f => f == type.File, type.FullName);
                if (otherFiles.Count >= 1)
                {
                    list.Add(new Candidate("type-file", topic, Difficulty.Easy, type.FullName, $"Which file declares `{type.Name}`?", type.File, otherFiles, where, type.File, type.StartLine, extra));
                }

                // What kind of type is it?
                var kinds = new List<string> { "class", "interface", "record", "struct", "enum" };
                if (kinds.Contains(type.Kind))
                {
                    var label = TypeLabel(type);
                    var distractors = kinds.Where(k => k != type.Kind).ToList();
                    list.Add(new Candidate("type-kind", topic, Difficulty.Easy, type.FullName, $"What kind of type is `{type.Name}`?", label, distractors, where.Replace("is declared", $"is declared as `{label}`", StringComparison.Ordinal), type.File, type.StartLine, extra));
                }

                // Which namespace?
                if (type.Namespace.Length > 0 && namespaces.Count >= 2)
                {
                    list.Add(new Candidate("type-namespace", LearningTopics.Architecture, Difficulty.Medium, type.FullName, $"Which namespace contains `{type.Name}`?", type.Namespace,
                        namespaces.Where(n => n != type.Namespace).ToList(), $"`{type.FullName}` lives in the `{type.Namespace}` namespace.", type.File, type.StartLine, extra));
                }

                var members = code.MembersOf(type.FullName).Where(m => !SymbolKinds.IsType(m.Kind) && m.Kind != SymbolKinds.Constructor && m.Kind != SymbolKinds.EnumMember).ToList();
                // Which of these is a member?
                if (members.Count > 0)
                {
                    var member = members[(int)(TextUtil.Fnv1a(type.FullName) % (uint)members.Count)];
                    var memberNames = members.Select(m => m.Name).ToHashSet(StringComparer.Ordinal);
                    var others = Sample(memberPool, memberNames.Contains, type.FullName);
                    if (others.Count >= 2)
                    {
                        list.Add(new Candidate("member-of", isTest ? LearningTopics.Testing : LearningTopics.DomainLogic, Difficulty.Medium, type.FullName, $"Which of these is a member of `{type.Name}`?",
                            member.Name, others, $"`{type.Name}.{member.Name}` is a {member.Kind} declared at line {member.StartLine} of `{member.File}`.", member.File, member.StartLine, extra));
                    }
                }

                // What does a method return?
                foreach (var method in members.Where(m => m.Kind == SymbolKinds.Method && m.ReturnType is { Length: > 0 } r && r != "void").Take(2))
                {
                    var returnTypes = Sample(returnPool, r => r == method.ReturnType, method.FullName);
                    list.Add(new Candidate("return-type", LearningTopics.DomainLogic, Difficulty.Hard, method.FullName, $"What does `{type.Name}.{method.Name}` return?",
                        method.ReturnType!, returnTypes, $"`{method.Signature}` — line {method.StartLine} of `{method.File}`.", method.File, method.StartLine, extra));
                }

                // Base types.
                if (type.Bases.Count > 0)
                {
                    var baseName = type.Bases[0];
                    var distractors = Sample(typeNamePool.Concat(["IDisposable", "Exception", "object", "IEnumerable"]).ToList(), n => type.Bases.Contains(n) || n == type.Name, type.FullName);
                    list.Add(new Candidate("base-type", LearningTopics.Dependencies, Difficulty.Hard, type.FullName, $"Which type does `{type.Name}` derive from or implement?",
                        baseName, distractors, $"`{type.Name}` is declared as `{type.Name} : {string.Join(", ", type.Bases)}`.", type.File, type.StartLine, extra));
                }

                // Who uses it?
                var nodeId = "type:" + type.FullName;
                var users = index.Graph.Edges.Where(e => e.To == nodeId && e.Kind is EdgeKinds.Uses).Select(e => index.Graph.Find(e.From)).OfType<GraphNode>().ToList();
                if (users.Count > 0)
                {
                    var user = users[0];
                    var userNames = users.Select(u => u.Label).ToHashSet(StringComparer.Ordinal);
                    var distractors = Sample(typeNamePool, n => userNames.Contains(n) || n == type.Name, type.FullName + "#users");
                    if (distractors.Count >= 2)
                    {
                        list.Add(new Candidate("used-by", LearningTopics.Dependencies, Difficulty.Hard, type.FullName, $"Which of these types uses `{type.Name}`?",
                            user.Label, distractors, $"`{user.Label}` refers to `{type.Name}` (see `{user.Path}`).", user.Path, user.Line ?? 0, extra));
                    }
                }

                // What does a test class test?
                if (isTest)
                {
                    var targets = index.Graph.Edges.Where(e => e.From == nodeId && e.Kind == EdgeKinds.Tests).Select(e => index.Graph.Find(e.To)).OfType<GraphNode>().ToList();
                    if (targets.Count > 0)
                    {
                        var targetNames = targets.Select(t => t.Label).ToHashSet(StringComparer.Ordinal);
                        var distractors = allTypes.Where(t => !targetNames.Contains(t.Name) && t.Name != type.Name && !testContainers.Contains(t.FullName)).Select(t => t.Name).ToList();
                        if (distractors.Count >= 1)
                        {
                            list.Add(new Candidate("tests-what", LearningTopics.Testing, Difficulty.Medium, type.FullName, $"Which type does the test class `{type.Name}` exercise?",
                                targets[0].Label, distractors, $"`{type.Name}` refers to `{targets[0].Label}` in its tests.", type.File, type.StartLine, extra));
                        }
                    }
                }
            }

            // Which method calls X?
            foreach (var method in code.Symbols.Where(s => s.Kind == SymbolKinds.Method && RepositoryIndex.InScope(s.File, scope)).Take(400))
            {
                var callers = code.CallersByName(method.Name).Where(c => c.FullName != method.FullName && c.Kind is SymbolKinds.Method or SymbolKinds.Constructor or SymbolKinds.Property).ToList();
                if (callers.Count == 0 || method.Name.Length < 4)
                {
                    continue;
                }
                var callerNames = callers.Select(c => CodeIndexHelpers.ShortName(c.FullName)).ToHashSet(StringComparer.Ordinal);
                var selfName = CodeIndexHelpers.ShortName(method.FullName);
                var distractors = Sample(methodPool, n => callerNames.Contains(n) || n == selfName || code.Resolve(n).Any(s => s.Calls.Contains(method.Name)), method.FullName);
                if (distractors.Count < 2)
                {
                    continue;
                }
                var caller = callers[0];
                list.Add(new Candidate("called-by", LearningTopics.DomainLogic, Difficulty.Hard, method.FullName, $"Which of these calls `{method.Name}`?",
                    CodeIndexHelpers.ShortName(caller.FullName), distractors, $"`{CodeIndexHelpers.ShortName(caller.FullName)}` calls `{method.Name}` (line {caller.StartLine} of `{caller.File}`).",
                    caller.File, caller.StartLine, ExtraTopicsFor(method.Name)));
            }

            // Projects.
            var projects = code.Manifest.Projects;
            foreach (var project in projects.Where(p => p.ProjectReferences.Count > 0 && RepositoryIndex.InScope(p.Path, scope)))
            {
                var referenced = Path.GetFileNameWithoutExtension(project.ProjectReferences[0])!;
                var distractors = projects.Select(p => p.Name).Where(n => n != referenced && n != project.Name && !project.ProjectReferences.Any(r => Path.GetFileNameWithoutExtension(r) == n)).ToList();
                if (distractors.Count >= 1)
                {
                    list.Add(new Candidate("project-ref", LearningTopics.Architecture, Difficulty.Medium, "project:" + project.Name, $"Which project does `{project.Name}` reference?",
                        referenced, distractors, $"`{project.Path}` has a ProjectReference to `{referenced}`.", project.Path, 1, [LearningTopics.Dependencies]));
                }
            }
            var testProjects = projects.Where(p => p.IsTestProject).ToList();
            var otherProjects = projects.Where(p => !p.IsTestProject).Select(p => p.Name).ToList();
            foreach (var testProject in testProjects.Where(p => RepositoryIndex.InScope(p.Path, scope)))
            {
                if (otherProjects.Count >= 1)
                {
                    list.Add(new Candidate("test-project", LearningTopics.Testing, Difficulty.Easy, "project:" + testProject.Name, "Which of these is a test project?",
                        testProject.Name, otherProjects, $"`{testProject.Name}` references a test framework.", testProject.Path, 1, []));
                }
            }
            foreach (var project in projects.Where(p => p.Packages.Count > 0 && RepositoryIndex.InScope(p.Path, scope)))
            {
                var package = project.Packages.FirstOrDefault(p => !p.Transitive);
                if (package is null || projects.Count < 2)
                {
                    continue;
                }
                var distractors = projects.Where(p => p.Packages.All(x => x.Id != package.Id)).Select(p => p.Name).ToList();
                if (distractors.Count >= 1)
                {
                    list.Add(new Candidate("package", LearningTopics.Infrastructure, Difficulty.Easy, "package:" + package.Id, $"Which project uses the package `{package.Id}`?",
                        project.Name, distractors, $"`{project.Path}` references `{package.Id}` {package.Version}.", project.Path, 1, [LearningTopics.Dependencies]));
                }
            }
        }

        // Operational facts.
        var okfFiles = index.Okf.Select(o => o.Path).Where(p => p.Length > 0).Distinct().ToList();
        foreach (var entity in index.Okf.Where(o => RepositoryIndex.InScope(o.Path, scope) && o.Path.Length > 0).Take(300))
        {
            switch (entity.Kind)
            {
                case "config":
                    var configFiles = index.Files.Where(f => f.Kind is FileKind.Config or FileKind.Source && f.Path != entity.Path).Select(f => f.Path).ToList();
                    if (configFiles.Count >= 2)
                    {
                        list.Add(new Candidate("config-key", LearningTopics.Configuration, Difficulty.Medium, "config:" + entity.Name, $"Where does the configuration key `{entity.Name}` appear first?",
                            entity.Path, configFiles, $"`{entity.Name}` — {entity.Detail} — at line {entity.Line} of `{entity.Path}`.", entity.Path, entity.Line, []));
                    }
                    break;
                case "endpoint":
                    var routes = index.Okf.Where(o => o.Kind == "endpoint" && o.Name != entity.Name).Select(o => o.Name).Distinct().ToList();
                    if (routes.Count >= 1)
                    {
                        list.Add(new Candidate("endpoint-route", LearningTopics.Apis, Difficulty.Easy, "endpoint:" + entity.Name, $"Which endpoint is mapped at line {entity.Line} of `{entity.Path}`?",
                            entity.Name, routes, $"Line {entity.Line} of `{entity.Path}` maps `{entity.Name}` to {entity.Detail}.", entity.Path, entity.Line, []));
                    }
                    var handlers = index.Okf.Where(o => o.Kind == "endpoint" && o.Detail != entity.Detail).Select(o => o.Detail).Distinct().ToList();
                    if (handlers.Count >= 1 && !entity.Detail.StartsWith(" (", StringComparison.Ordinal))
                    {
                        list.Add(new Candidate("endpoint", LearningTopics.Apis, Difficulty.Medium, "endpoint:" + entity.Name, $"Which handler serves `{entity.Name}`?",
                            entity.Detail, handlers, $"`{entity.Name}` is mapped at line {entity.Line} of `{entity.Path}`.", entity.Path, entity.Line, []));
                    }
                    break;
                case "service":
                    var implementations = index.Okf.Where(o => o.Kind == "service" && o.Detail != entity.Detail).Select(o => o.Detail).Distinct().ToList();
                    if (implementations.Count >= 1)
                    {
                        list.Add(new Candidate("service", LearningTopics.Services, Difficulty.Medium, "service:" + entity.Name, $"How is `{entity.Name}` registered?",
                            entity.Detail, implementations, $"Registered at line {entity.Line} of `{entity.Path}`.", entity.Path, entity.Line, []));
                    }
                    break;
            }
        }

        // Documentation sections.
        var docPages = index.Pages.Where(p => !p.Generated && p.SourcePath is not null && RepositoryIndex.InScope(p.SourcePath, scope)).ToList();
        var allPageTitles = index.Pages.Where(p => !p.Generated).Select(p => p.Title).Distinct().ToList();
        foreach (var page in docPages)
        {
            foreach (var heading in page.Headings.Where(h => h.Level >= 2).Take(4))
            {
                var distractors = allPageTitles.Where(t => t != page.Title).ToList();
                if (distractors.Count == 0)
                {
                    continue;
                }
                list.Add(new Candidate("doc-section", LearningTopics.Setup, Difficulty.Easy, "page:" + page.Id, $"Which document has a section called \"{heading.Text}\"?",
                    page.Title, distractors, $"\"{heading.Text}\" is a section of *{page.Title}* (`{page.SourcePath}`, line {heading.Line}).", page.SourcePath, heading.Line, [LearningTopics.Architecture]));
            }
        }

        // Infrastructure files.
        var infra = inScopeFiles.Where(f => f.Language is "dockerfile" or "yaml" or "terraform" or "makefile" || f.Name.StartsWith("docker-compose", StringComparison.OrdinalIgnoreCase)).ToList();
        foreach (var file in infra.Take(10))
        {
            var others = index.Files.Where(f => f.Path != file.Path && f.Kind == FileKind.Source).Select(f => f.Path).ToList();
            if (others.Count >= 2)
            {
                var what = file.Language switch { "dockerfile" => "defines a container image", "yaml" => "is a YAML pipeline or configuration file", "terraform" => "declares infrastructure", _ => "drives the build" };
                list.Add(new Candidate("infra-file", LearningTopics.Infrastructure, Difficulty.Easy, "file:" + file.Path, $"Which of these files {what}?",
                    file.Path, others, $"`{file.Path}` is a {file.Language} file.", file.Path, 1, [LearningTopics.Setup]));
            }
        }

        // Files without parsed symbols (other languages): which folder holds the file?
        if (code is null || code.Types.Count() == 0)
        {
            var folders = index.Files.Select(f => Path.GetDirectoryName(f.Path)?.Replace('\\', '/') ?? "").Where(d => d.Length > 0).Distinct().ToList();
            foreach (var file in inScopeFiles.Where(f => f.Kind == FileKind.Source).Take(200))
            {
                var folder = Path.GetDirectoryName(file.Path)?.Replace('\\', '/') ?? "";
                if (folder.Length == 0 || folders.Count < 2)
                {
                    continue;
                }
                list.Add(new Candidate("file-folder", LearningTopics.Architecture, Difficulty.Easy, "file:" + file.Path, $"Which folder holds `{file.Name}`?",
                    folder, folders.Where(f => f != folder).ToList(), $"`{file.Name}` is at `{file.Path}`.", file.Path, 1, [LearningTopics.Classes]));
            }
        }

        return list.Where(c => c.Distractors.Any(d => d != c.Correct)).ToList();
    }

    private static string TypeLabel(SymbolRecord type) => type.Modifiers.Contains("static") && type.Kind == "class" ? "class" : type.Kind;

    /// <summary>Up to <paramref name="count"/> pool entries, starting at a position fixed by <paramref name="key"/>, skipping excluded ones.</summary>
    private static List<string> Sample(IReadOnlyList<string> pool, Func<string, bool> exclude, string key, int count = 24)
    {
        var result = new List<string>(count);
        if (pool.Count == 0)
        {
            return result;
        }
        var start = (int)(TextUtil.Fnv1a(key) % (uint)pool.Count);
        for (var i = 0; i < pool.Count && result.Count < count; i++)
        {
            var candidate = pool[(start + i) % pool.Count];
            if (!exclude(candidate))
            {
                result.Add(candidate);
            }
        }
        return result;
    }

    /// <summary>Marks a set of answers. The same answers always give the same score.</summary>
    public static QuizAttempt Score(Quiz quiz, IReadOnlyList<int> answers, long durationSeconds = 0)
    {
        var correct = 0;
        for (var i = 0; i < quiz.Questions.Count; i++)
        {
            if (i < answers.Count && answers[i] == quiz.Questions[i].CorrectIndex)
            {
                correct++;
            }
        }
        var total = quiz.Questions.Count;
        var percent = total == 0 ? 0 : Math.Round(100.0 * correct / total, 1);
        return new QuizAttempt
        {
            Answers = answers.ToList(),
            Correct = correct,
            Total = total,
            Percent = percent,
            Passed = percent >= quiz.Options.PassMarkPercent,
            DurationSeconds = durationSeconds,
        };
    }
}
