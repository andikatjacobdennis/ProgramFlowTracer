using DocGen.Explorer.Engine.Documentation;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;
using DocGen.Analysis.Indexing;

namespace DocGen.Explorer.Engine.Learning;

/// <summary>Flashcards for the classes, terms and workflows worth recognising, written from the index.</summary>
public static class FlashcardGenerator
{
    public static FlashcardDeck Generate(RepositoryIndex index, GenerationOptions options)
    {
        var count = Math.Clamp(options.Count, 1, 200);
        var cards = new List<(Flashcard Card, double Priority)>();
        var code = index.Code;
        if (code is not null)
        {
            var types = code.Types.Where(t => RepositoryIndex.InScope(t.File, options.Scope)).GroupBy(t => t.FullName).Select(g => g.First());
            foreach (var type in types)
            {
                var nodeId = "type:" + type.FullName;
                var degree = index.Graph.Degree(nodeId);
                var lines = index.ReadLines(type.File);
                var summary = lines is null ? null : DocumentationBuilder.XmlDocSummary(lines, type.StartLine);
                var members = code.MembersOf(type.FullName).Where(m => !SymbolKinds.IsType(m.Kind) && m.Kind != SymbolKinds.Constructor).Select(m => m.Name).Distinct().Take(6).ToList();
                var uses = index.Graph.Edges.Where(e => e.From == nodeId && e.Kind == EdgeKinds.Uses).Select(e => index.Graph.Find(e.To)?.Label).OfType<string>().Take(5).ToList();
                var back = new List<string>
                {
                    $"{TextUtil.Humanize(string.Join(" ", type.Modifiers.Where(m => m is "static" or "abstract" or "sealed").Append(type.Kind)))} in {(type.Namespace.Length > 0 ? type.Namespace : "the global namespace")}.",
                };
                if (summary is { Length: > 0 })
                {
                    back.Add(summary);
                }
                if (type.Bases.Count > 0)
                {
                    back.Add("Derives from / implements: " + string.Join(", ", type.Bases) + ".");
                }
                if (members.Count > 0)
                {
                    back.Add("Members: " + string.Join(", ", members) + ".");
                }
                if (uses.Count > 0)
                {
                    back.Add("Depends on: " + string.Join(", ", uses) + ".");
                }
                back.Add($"{type.File}:{type.StartLine}");
                var topic = type.IsTest ? LearningTopics.Testing : LearningTopics.Classes;
                cards.Add((new Flashcard
                {
                    Front = type.Name,
                    Back = string.Join("\n", back),
                    Topic = topic,
                    Concept = type.FullName,
                    Path = type.File,
                    Line = type.StartLine,
                }, 10 + degree + (summary is null ? 0 : 3)));
            }
        }

        foreach (var entity in index.Okf.Where(o => RepositoryIndex.InScope(o.Path, options.Scope)))
        {
            var (topic, front, priority) = entity.Kind switch
            {
                "endpoint" => (LearningTopics.Apis, entity.Name, 8.0),
                "service" => (LearningTopics.Services, entity.Name, 6.0),
                "config" => (LearningTopics.Configuration, entity.Name, 4.0),
                "entrypoint" => (LearningTopics.Setup, "Entry point: " + entity.Name, 9.0),
                "middleware" => (LearningTopics.Architecture, "Middleware: " + entity.Name, 3.0),
                _ => (LearningTopics.Dependencies, "Package: " + entity.Name, 2.0),
            };
            cards.Add((new Flashcard
            {
                Front = front,
                Back = $"{TextUtil.Humanize(entity.Detail)}.\n{entity.Path}{(entity.Line > 0 ? ":" + entity.Line : "")}",
                Topic = topic,
                Concept = entity.Kind + ":" + entity.Name,
                Path = entity.Path,
                Line = entity.Line,
            }, priority));
        }

        // Terms: bold definitions in the documentation ("**Term** — meaning" or "**Term**: meaning").
        foreach (var page in index.Pages.Where(p => p.SourcePath is not null && RepositoryIndex.InScope(p.SourcePath, options.Scope)))
        {
            var lines = index.ReadLines(page.SourcePath!);
            if (lines is null)
            {
                continue;
            }
            for (var i = 0; i < lines.Length; i++)
            {
                var match = System.Text.RegularExpressions.Regex.Match(lines[i], @"^\s*(?:[-*]\s+)?\*\*(?<term>[^*]{2,60})\*\*\s*(?:—|-|:|–)\s*(?<def>.{10,})$");
                if (match.Success)
                {
                    cards.Add((new Flashcard
                    {
                        Front = match.Groups["term"].Value.Trim(),
                        Back = TextUtil.Truncate(match.Groups["def"].Value.Trim(), 400) + $"\n{page.SourcePath}:{i + 1}",
                        Topic = LearningTopics.Setup,
                        Concept = "term:" + match.Groups["term"].Value.Trim(),
                        Path = page.SourcePath,
                        Line = i + 1,
                    }, 7));
                }
            }
        }

        var topics = options.Topics.Count > 0 ? options.Topics.ToHashSet(StringComparer.OrdinalIgnoreCase) : null;
        var selected = cards
            .Where(c => topics is null || topics.Contains(c.Card.Topic))
            .GroupBy(c => c.Card.Front, StringComparer.Ordinal).Select(g => g.OrderByDescending(c => c.Priority).First())
            .OrderByDescending(c => c.Priority).ThenBy(c => c.Card.Front, StringComparer.Ordinal)
            .Take(count).Select(c => c.Card).ToList();
        var now = DateTime.UtcNow;
        foreach (var card in selected)
        {
            card.DueAt = now;
        }
        return new FlashcardDeck
        {
            Title = string.IsNullOrWhiteSpace(options.Title) ? $"{index.Repository.Title}: flashcards" : options.Title!.Trim(),
            Options = options,
            Cards = selected,
            Provenance = QuizGenerator.OfflineProvenance,
        };
    }
}

/// <summary>SM-2 spaced repetition: cards recalled easily come back less often.</summary>
public static class FlashcardScheduler
{
    public const double MinimumEase = 1.3;

    public static void Review(Flashcard card, RecallGrade grade, DateTime now)
    {
        var q = (int)grade;
        card.Reviews++;
        if (q < 3)
        {
            card.Repetitions = 0;
            card.IntervalDays = 0;
            card.Lapses++;
            card.DueAt = now.AddMinutes(10);
        }
        else
        {
            card.Repetitions++;
            card.IntervalDays = card.Repetitions switch
            {
                1 => 1,
                2 => grade == RecallGrade.Hard ? 3 : 6,
                _ => (int)Math.Max(1, Math.Round(card.IntervalDays * (grade == RecallGrade.Hard ? 1.2 : card.Ease))),
            };
            if (grade == RecallGrade.Easy)
            {
                card.IntervalDays = (int)Math.Round(card.IntervalDays * 1.3);
            }
            card.DueAt = now.AddDays(card.IntervalDays);
        }
        card.Ease = Math.Max(MinimumEase, card.Ease + (0.1 - (5 - q) * (0.08 + (5 - q) * 0.02)));
        card.Ease = Math.Round(card.Ease, 3);
    }

    public static List<Flashcard> Due(FlashcardDeck deck, DateTime now) => deck.Cards.Where(c => c.DueAt <= now).OrderBy(c => c.DueAt).ToList();
}

/// <summary>The knowledge record: what has been understood, judged only when there is enough behind it.</summary>
public static class KnowledgeTracker
{
    public const int MinimumObservations = 3;

    public static List<KnowledgeEvent> FromAttempt(Quiz quiz, QuizAttempt attempt)
        => quiz.Questions.Select((q, i) => new KnowledgeEvent
        {
            At = attempt.At,
            Topic = q.Topic,
            Concept = q.Concept,
            Success = i < attempt.Answers.Count && attempt.Answers[i] == q.CorrectIndex,
            Source = "quiz",
        }).ToList();

    public static KnowledgeEvent FromReview(Flashcard card, RecallGrade grade) => new()
    {
        Topic = card.Topic,
        Concept = card.Concept,
        Success = grade >= RecallGrade.Good,
        Source = "card",
    };

    public static List<MasteryEntry> ByTopic(KnowledgeRecord record) => Summarize(record.Events.GroupBy(e => e.Topic));

    public static List<MasteryEntry> ByConcept(KnowledgeRecord record) => Summarize(record.Events.GroupBy(e => e.Concept));

    private static List<MasteryEntry> Summarize(IEnumerable<IGrouping<string, KnowledgeEvent>> groups)
        => groups.Select(g =>
        {
            // Recent evidence counts more: the last 20 observations decide.
            var recent = g.OrderByDescending(e => e.At).Take(20).ToList();
            var successes = recent.Count(e => e.Success);
            var rate = recent.Count == 0 ? 0 : (double)successes / recent.Count;
            return new MasteryEntry
            {
                Name = g.Key,
                Observations = g.Count(),
                Successes = g.Count(e => e.Success),
                Rate = Math.Round(rate, 3),
                Level = g.Count() < MinimumObservations ? MasteryLevel.NotEnoughEvidence : rate >= 0.8 ? MasteryLevel.Understood : rate >= 0.5 ? MasteryLevel.Familiar : MasteryLevel.Learning,
            };
        }).OrderBy(e => e.Level == MasteryLevel.NotEnoughEvidence).ThenBy(e => e.Rate).ThenBy(e => e.Name, StringComparer.Ordinal).ToList();
}
