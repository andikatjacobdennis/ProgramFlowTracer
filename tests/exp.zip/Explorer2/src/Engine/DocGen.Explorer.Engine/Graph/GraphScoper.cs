using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Search;
using DocGen.Explorer.Engine.Text;

namespace DocGen.Explorer.Engine.Graph;

/// <summary>How far a graph scope reaches beyond the concepts that match it.</summary>
public enum GraphScopeMode
{
    /// <summary>The matching concepts and what they contain.</summary>
    Matching,

    /// <summary>Also what they use, inherit, call or are tested by (one step).</summary>
    Linked,

    /// <summary>Also every type the architecture trace of the scope reaches, across projects.</summary>
    Flow,
}

public sealed record GraphScopeResult(KnowledgeGraph Graph, string Description, int Matched);

/// <summary>A scope to offer while typing: a project, namespace or folder and how many concepts it holds.</summary>
public sealed record GraphScopeSuggestion(string Text, string Kind, int Count)
{
    public string Label => $"{Text}  ·  {Kind} · {Count:N0}";
}

/// <summary>
/// Narrows the knowledge graph to a part of the repository — "orderservice", a project, a namespace, a folder —
/// so the graph shows that part only: the concepts whose name or path contains the text (letters compared, so
/// "order service" and "OrderService_1_0" match), what they contain, and optionally what they link to
/// or the whole traced flow.
/// </summary>
public static class GraphScoper
{
    private static readonly HashSet<string> Structural = new(StringComparer.Ordinal) { EdgeKinds.Contains, EdgeKinds.Declares };
    private static readonly HashSet<string> Behavioural = new(StringComparer.Ordinal) { EdgeKinds.Uses, EdgeKinds.Calls, EdgeKinds.Inherits, EdgeKinds.Tests, EdgeKinds.References };

    /// <summary>Letters and digits, lower case: names, paths and typed words compare alike.</summary>
    public static string Normalize(string? text) => new((text ?? "").Where(char.IsLetterOrDigit).Select(char.ToLowerInvariant).ToArray());

    public static bool Matches(GraphNode node, string normalizedTerm)
        => normalizedTerm.Length > 0 && node.Type != ConceptTypes.Repository
           && (Normalize(node.Label).Contains(normalizedTerm, StringComparison.Ordinal)
               || Normalize(node.Key).Contains(normalizedTerm, StringComparison.Ordinal)
               || Normalize(node.Path).Contains(normalizedTerm, StringComparison.Ordinal));

    /// <summary>Several parts together (a request may name more than one), with kinds of concept left out.</summary>
    public static GraphScopeResult Scope(KnowledgeGraph full, RepositoryIndex? index, IReadOnlyList<string> terms, GraphScopeMode mode, IReadOnlyCollection<string>? excludeTypes,
        int traceSteps = 200, int traceDepth = 8, CancellationToken ct = default)
    {
        var parts = terms.Select(t => Scope(full, index, t, mode, traceSteps, traceDepth, ct)).ToList();
        var keep = parts.SelectMany(p => p.Graph.Nodes).Where(n => excludeTypes is null || !excludeTypes.Contains(n.Type)).Select(n => n.Id).ToHashSet(StringComparer.Ordinal);
        var graph = new KnowledgeGraph
        {
            Nodes = full.Nodes.Where(n => keep.Contains(n.Id)).ToList(),
            Edges = full.Edges.Where(e => keep.Contains(e.From) && keep.Contains(e.To)).ToList(),
        };
        var description = string.Join(" ", parts.Select(p => p.Description));
        if (excludeTypes is { Count: > 0 })
        {
            description += $" Left out: {TextUtil.JoinNatural(excludeTypes.Select(t => t.ToLowerInvariant() + "s"))}.";
        }
        return new GraphScopeResult(graph, description, parts.Sum(p => p.Matched));
    }

    public static GraphScopeResult Scope(KnowledgeGraph full, RepositoryIndex? index, string term, GraphScopeMode mode, int traceSteps = 200, int traceDepth = 8, CancellationToken ct = default)
    {
        var normalized = Normalize(term);
        var keep = new HashSet<string>(StringComparer.Ordinal);
        foreach (var node in full.Nodes.Where(n => Matches(n, normalized)))
        {
            keep.Add(node.Id);
        }
        var matched = keep.Count;

        // What the matches contain: a namespace's types, a project's namespaces and their types, a file's types.
        var children = full.Edges.Where(e => Structural.Contains(e.Kind)).ToLookup(e => e.From, e => e.To, StringComparer.Ordinal);
        var queue = new Queue<string>(keep);
        while (queue.Count > 0)
        {
            foreach (var child in children[queue.Dequeue()])
            {
                if (child != "repo" && keep.Add(child))
                {
                    queue.Enqueue(child);
                }
            }
        }
        var contained = keep.Count;
        var description = $"“{term.Trim()}”: {TextUtil.Plural(matched, "matching concept")}" + (contained > matched ? $" and {TextUtil.Plural(contained - matched, "concept")} they contain" : "");

        if (mode == GraphScopeMode.Linked)
        {
            // What the scope uses, calls, inherits or references, and the classes implementing its interfaces — not
            // everything that uses it (a shared interface is used by thousands of tests).
            var scope = keep.ToHashSet(StringComparer.Ordinal);
            var added = 0;
            foreach (var edge in full.Edges)
            {
                var target = scope.Contains(edge.From) && Behavioural.Contains(edge.Kind) && edge.Kind != EdgeKinds.Tests ? edge.To
                    : scope.Contains(edge.To) && edge.Kind == EdgeKinds.Inherits ? edge.From
                    : null;
                if (target is null || target == "repo" || full.Find(target) is not { } node || node.Type == ConceptTypes.Test)
                {
                    continue;
                }
                if (keep.Add(target))
                {
                    added++;
                }
            }
            description += $", plus {TextUtil.Plural(added, "concept")} they use, inherit or that implement them";
        }
        else if (mode == GraphScopeMode.Flow && index is not null)
        {
            var analysis = Retriever.Analyze(index, $"program flow of {term}", AnalysisDepth.Deep);
            var trace = ArchitectureTraces.Trace(index, analysis, traceSteps, traceDepth, ct);
            if (trace is null)
            {
                description += " (no flow could be traced from it)";
            }
            else
            {
                var added = 0;
                foreach (var step in trace.Trace.Steps)
                {
                    var typeId = step.Symbol.Container is { } container ? "type:" + container : null;
                    if (typeId is not null && full.Find(typeId) is not null && keep.Add(typeId))
                    {
                        added++;
                    }
                }
                description += $", plus {TextUtil.Plural(added, "type")} on its traced flow ({TextUtil.Plural(trace.StepCount, "step")} across {TextUtil.Plural(trace.Projects.Count, "project")})";
            }
        }

        var graph = new KnowledgeGraph
        {
            Nodes = full.Nodes.Where(n => keep.Contains(n.Id)).ToList(),
            Edges = full.Edges.Where(e => keep.Contains(e.From) && keep.Contains(e.To)).ToList(),
        };
        return new GraphScopeResult(graph, description + ".", matched);
    }

    /// <summary>The last two parts of a dotted name or path ("Ordering.OrderService_1_0"): enough to be specific, short to read.</summary>
    private static string Tail(string text, char separator)
    {
        var parts = text.Split(separator, StringSplitOptions.RemoveEmptyEntries);
        return parts.Length <= 2 ? text : string.Join(separator, parts[^2..]);
    }

    /// <summary>Projects, namespaces and folders whose name contains the typed text, biggest first.</summary>
    public static List<GraphScopeSuggestion> Suggest(KnowledgeGraph full, string term, int max = 10)
    {
        var normalized = Normalize(term);
        if (normalized.Length < 2)
        {
            return [];
        }
        var suggestions = new List<GraphScopeSuggestion>();
        foreach (var node in full.Nodes.Where(n => n.Type is ConceptTypes.Project or ConceptTypes.Namespace && Normalize(n.Label).Contains(normalized, StringComparison.Ordinal)))
        {
            var count = full.Nodes.Count(n => (n.Key ?? "").StartsWith(node.Label + ".", StringComparison.Ordinal) || (n.Path ?? "").Contains("/" + node.Label + "/", StringComparison.Ordinal));
            suggestions.Add(new GraphScopeSuggestion(Tail(node.Label, '.'), node.Type.ToLowerInvariant(), Math.Max(1, count)));
        }
        // Folders: the path segments that contain the text, with what lies under them.
        var folders = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        foreach (var node in full.Nodes.Where(n => n.Type == ConceptTypes.File && n.Path is not null))
        {
            var parts = node.Path!.Replace('\\', '/').Split('/');
            for (var i = 0; i < parts.Length - 1; i++)
            {
                if (Normalize(parts[i]).Contains(normalized, StringComparison.Ordinal))
                {
                    var folder = string.Join('/', parts.Take(i + 1));
                    folders[folder] = folders.GetValueOrDefault(folder) + 1;
                    break;
                }
            }
        }
        suggestions.AddRange(folders.Select(f => new GraphScopeSuggestion(Tail(f.Key, '/'), "folder", f.Value)));
        // Single concepts too (the old "search concepts"): types whose name contains the text.
        suggestions.AddRange(full.Nodes.Where(n => ConceptTypes.IsType(n.Type) && n.Type != ConceptTypes.Test && Normalize(n.Label).Contains(normalized, StringComparison.Ordinal))
            .OrderBy(n => Normalize(n.Label) == normalized ? 0 : 1).ThenBy(n => n.Label.Length).Take(4)
            .Select(n => new GraphScopeSuggestion(n.Label, n.Type.ToLowerInvariant(), 1)));
        // A namespace and its folder usually read the same once punctuation is ignored: offer it once.
        return suggestions.DistinctBy(s => Normalize(s.Text))
            .OrderBy(s => Normalize(s.Text).EndsWith(normalized, StringComparison.Ordinal) ? 0 : 1).ThenByDescending(s => s.Count).ThenBy(s => s.Text, StringComparer.Ordinal)
            .Take(max).ToList();
    }
}
