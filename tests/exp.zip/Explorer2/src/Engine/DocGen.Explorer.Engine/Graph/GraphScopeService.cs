using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using DocGen.Explorer.Engine.Ai;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;
using DocGen.Core.Abstractions;

namespace DocGen.Explorer.Engine.Graph;

/// <summary>What a request such as "only order service, without tests" asks the graph to show.</summary>
/// <param name="Terms">The parts of the repository to show (each matched as in <see cref="GraphScoper"/>).</param>
/// <param name="Mode">How far beyond them to reach.</param>
/// <param name="ExcludeTypes">Kinds of concept left out ("Test").</param>
/// <param name="By">"words" (understood without a model) or the model that read it.</param>
public sealed record GraphScopeRequest(IReadOnlyList<string> Terms, GraphScopeMode Mode, IReadOnlyList<string> ExcludeTypes, string Explanation, string By);

/// <summary>
/// Reads a request for part of the graph in plain words — "only order service", "the order service
/// flow without tests", "what BaseReader uses" — and turns it into terms, a reach and exclusions. With a chat model the
/// model reads it, choosing among the projects, namespaces and folders that actually exist; without one (or when the
/// model's choice matches nothing) the words are read directly: filler dropped, "flow"/"uses"/"without tests"
/// recognised. Then <see cref="GraphScoper"/> builds the graph.
/// </summary>
public sealed partial class GraphScopeService(IModelGateway models)
{
    private static readonly HashSet<string> Filler = new(StringComparer.OrdinalIgnoreCase)
    {
        "only", "just", "show", "me", "the", "a", "an", "graph", "graphs", "related", "relating", "to", "of", "for", "about", "around", "all",
        "everything", "anything", "part", "parts", "in", "on", "with", "and", "its", "it", "that", "which", "is", "are", "please", "display",
        "see", "view", "want", "i", "concepts", "code", "classes", "stuff", "things", "connected", "regarding", "concerning", "focus", "draw",
    };

    /// <summary>Reads the request: with the model when one is configured and <paramref name="useModel"/>, else from its words.</summary>
    public async Task<GraphScopeRequest> InterpretAsync(string request, KnowledgeGraph full, string? repositoryId, bool useModel = true, CancellationToken ct = default)
    {
        var offline = Interpret(request, full);
        if (!useModel)
        {
            return offline;
        }
        var status = await models.GetStatusAsync(ct);
        if (!status.Configured)
        {
            return offline;
        }
        try
        {
            var candidates = Candidates(request, full);
            using var purpose = UsagePurpose.Set($"Graph \"Show only\": {request}");
            var result = await models.CompleteAsync("graph-scope", repositoryId,
                [ModelMessage.System(SystemPrompt), ModelMessage.User(Prompt(request, candidates, full))], 600, ct);
            var answer = Parse(result.Text);
            if (answer is null)
            {
                return offline;
            }
            // Only terms that match something in the graph count; the model's words must name real code.
            var terms = (answer.Terms ?? []).Select(t => t.Trim()).Where(t => t.Length >= 2 && full.Nodes.Any(n => GraphScoper.Matches(n, GraphScoper.Normalize(t)))).Distinct(StringComparer.OrdinalIgnoreCase).Take(6).ToList();
            if (terms.Count == 0)
            {
                return offline;
            }
            var mode = answer.Mode?.ToLowerInvariant() switch { "linked" or "uses" => GraphScopeMode.Linked, "flow" => GraphScopeMode.Flow, _ => GraphScopeMode.Matching };
            var exclude = (answer.ExcludeTypes ?? []).Where(t => ConceptTypes.All.Contains(t, StringComparer.OrdinalIgnoreCase))
                .Select(t => ConceptTypes.All.First(a => a.Equals(t, StringComparison.OrdinalIgnoreCase))).Distinct().ToList();
            return new GraphScopeRequest(terms, mode, exclude, TextUtil.Truncate(answer.Explanation?.Trim() ?? "", 240), status.DisplayName ?? "the model");
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            return offline with { Explanation = offline.Explanation + " (the model could not be reached; read from the words)" };
        }
    }

    /// <summary>The request read from its words alone.</summary>
    public static GraphScopeRequest Interpret(string request, KnowledgeGraph full)
    {
        var text = " " + request.ToLowerInvariant().Replace(",", " , ") + " ";
        var mode = FlowRegex().IsMatch(text) ? GraphScopeMode.Flow : UsesRegex().IsMatch(text) ? GraphScopeMode.Linked : GraphScopeMode.Matching;
        var exclude = new List<string>();
        if (NoTestsRegex().IsMatch(text))
        {
            exclude.Add(ConceptTypes.Test);
        }
        if (NoFilesRegex().IsMatch(text))
        {
            exclude.Add(ConceptTypes.File);
        }
        // What is left once the instructions are taken out: the names, split at "and" / commas.
        var cleaned = InstructionRegex().Replace(text, " ");
        var phrases = SplitRegex().Split(cleaned)
            .Select(p => string.Join(' ', WordRegex().Matches(p).Select(m => m.Value).Where(w => !Filler.Contains(w))))
            .Where(p => p.Length >= 2).ToList();
        var terms = new List<string>();
        foreach (var phrase in phrases)
        {
            if (BestMatchingPart(phrase, full) is { } term)
            {
                terms.Add(term);
            }
        }
        var explanation = terms.Count == 0
            ? $"Nothing in the graph matches “{request.Trim()}”."
            : $"Showing {TextUtil.JoinNatural(terms.Select(t => $"“{t}”"))}" + mode switch
            {
                GraphScopeMode.Flow => " and the flow traced from it",
                GraphScopeMode.Linked => " and what it uses",
                _ => "",
            } + (exclude.Count > 0 ? $", without {TextUtil.JoinNatural(exclude.Select(e => e.ToLowerInvariant() + "s"))}" : "") + ".";
        return new GraphScopeRequest(terms, mode, exclude, explanation, "words");
    }

    /// <summary>The phrase if it matches something, else its longest run of words that does ("the order service handler" → "order service handler").</summary>
    private static string? BestMatchingPart(string phrase, KnowledgeGraph full)
    {
        var words = phrase.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        for (var length = words.Length; length >= 1; length--)
        {
            for (var start = 0; start + length <= words.Length; start++)
            {
                var candidate = string.Join(' ', words.Skip(start).Take(length));
                var normalized = GraphScoper.Normalize(candidate);
                if (normalized.Length < 3)
                {
                    continue;
                }
                // "baselines" in a request, Baseline in the code: the singular when it matches more.
                var singular = candidate.EndsWith("ies", StringComparison.Ordinal) ? candidate[..^3] + "y"
                    : candidate.EndsWith('s') && !candidate.EndsWith("ss", StringComparison.Ordinal) ? candidate[..^1] : null;
                var count = full.Nodes.Count(n => GraphScoper.Matches(n, normalized));
                if (singular is not null && GraphScoper.Normalize(singular) is { Length: >= 3 } stem && full.Nodes.Count(n => GraphScoper.Matches(n, stem)) > count)
                {
                    return singular;
                }
                if (count > 0)
                {
                    return candidate;
                }
            }
        }
        return null;
    }

    /// <summary>Areas the request's words point at (namespaces, folders, projects), for the model to choose from.</summary>
    /// <summary>The features, folders, namespaces and types in the graph that the request's words may name (at most 24).</summary>
    public static List<GraphScopeSuggestion> Candidates(string request, KnowledgeGraph full)
    {
        var words = WordRegex().Matches(request.ToLowerInvariant()).Select(m => m.Value).Where(w => !Filler.Contains(w) && w.Length > 2).ToList();
        var probes = new List<string>();
        for (var n = Math.Min(4, words.Count); n >= 1; n--)
        {
            for (var i = 0; i + n <= words.Count; i++)
            {
                probes.Add(string.Join(' ', words.Skip(i).Take(n)));
            }
        }
        return probes.SelectMany(p => GraphScoper.Suggest(full, p, 6)).DistinctBy(s => GraphScoper.Normalize(s.Text)).Take(24).ToList();
    }

    private const string SystemPrompt = """
        You choose which part of a code repository's knowledge graph to show, from a developer's request in plain words.
        Reply with JSON only:
        {"terms": ["OrderService"], "mode": "matching|linked|flow", "exclude_types": ["Test"], "explanation": "one short sentence"}
        - terms: the names to show — a feature, service, project, namespace, folder or type, written as it appears in the
          code (prefer the candidates you are given; a common stem such as "OrderService" covers all its versions).
          Several only when the request names several things.
        - mode: "matching" for the part itself (the default; "only X"), "linked" when the request wants what it uses or
          depends on, "flow" when it asks for a flow, a call chain, how a request travels or what happens end to end.
        - exclude_types: kinds to leave out when the request says so (Test, File, Namespace, Enum, Interface...).
        - explanation: what will be shown, e.g. "OrderService (versions 1.0 and 2.0) and what it contains".
        """;

    private static string Prompt(string request, List<GraphScopeSuggestion> candidates, KnowledgeGraph full)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"Request: {request.Trim()}");
        if (candidates.Count > 0)
        {
            sb.AppendLine().AppendLine("Candidates in this repository (name · kind · concepts):");
            foreach (var c in candidates)
            {
                sb.AppendLine($"- {c.Text} · {c.Kind} · {c.Count}");
            }
        }
        var projects = full.Nodes.Where(n => n.Type == ConceptTypes.Project).Select(n => n.Label).OrderBy(l => l, StringComparer.Ordinal).Take(80).ToList();
        if (projects.Count > 0)
        {
            sb.AppendLine().AppendLine("Projects: " + string.Join(", ", projects));
        }
        return sb.ToString();
    }

    private sealed class Answer
    {
        public List<string>? Terms { get; set; }
        public string? Mode { get; set; }

        [System.Text.Json.Serialization.JsonPropertyName("exclude_types")]
        public List<string>? ExcludeTypes { get; set; }

        public string? Explanation { get; set; }
    }

    private static Answer? Parse(string text)
    {
        var start = text.IndexOf('{');
        var end = text.LastIndexOf('}');
        if (start < 0 || end <= start)
        {
            return null;
        }
        try
        {
            return JsonSerializer.Deserialize<Answer>(text[start..(end + 1)], new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }
        catch (JsonException)
        {
            return null;
        }
    }

    [GeneratedRegex(@"\b(flow|flows|trace|traced|tracing|call chain|end to end|end-to-end|step by step|from \w+ to \w+|what happens)\b")]
    private static partial Regex FlowRegex();

    [GeneratedRegex(@"\b(uses|use|using|depends|dependencies|depend|linked|links|connected to|neighbours|neighbors)\b")]
    private static partial Regex UsesRegex();

    [GeneratedRegex(@"\b(without|no|exclude|excluding|except|minus|skip|hide)\s+(the\s+)?tests?\b")]
    private static partial Regex NoTestsRegex();

    [GeneratedRegex(@"\b(without|no|exclude|excluding|except|hide)\s+(the\s+)?files\b")]
    private static partial Regex NoFilesRegex();

    // Instruction words removed before reading the names: reach words and exclusions.
    [GeneratedRegex(@"\b(program flow|call chain|end to end|end-to-end|step by step|what happens|flows?|traced?|tracing|uses|use|using|depends on|dependencies|depend on|linked to|connected to|neighbou?rs|(without|no|exclude|excluding|except|minus|skip|hide)\s+(the\s+)?(tests?|files))\b")]
    private static partial Regex InstructionRegex();

    [GeneratedRegex(@"\s+and\s+|\s*,\s*|\s+plus\s+|\s*&\s*")]
    private static partial Regex SplitRegex();

    [GeneratedRegex(@"[a-z0-9_.]+")]
    private static partial Regex WordRegex();
}
