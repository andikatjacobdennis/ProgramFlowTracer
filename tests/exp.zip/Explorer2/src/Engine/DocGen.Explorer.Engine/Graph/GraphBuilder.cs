using DocGen.Explorer.Engine.Documentation;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;
using DocGen.Analysis.Indexing;

namespace DocGen.Explorer.Engine.Graph;

/// <summary>
/// Builds the knowledge graph: the repository, its projects, namespaces, source files, types (classes, interfaces,
/// records, structs, enums, tests), Markdown files and documentation pages, connected by containment, declaration,
/// inheritance, use, calls, tests, project references and documentation mentions.
/// </summary>
public static class GraphBuilder
{
    public static KnowledgeGraph Build(RepositoryRecord repository, IReadOnlyList<ScannedFile> files, CodeIndex? code, IReadOnlyList<DocPage> pages,
        Func<string, string?> readText)
    {
        var graph = new KnowledgeGraph();
        var nodes = new Dictionary<string, GraphNode>(StringComparer.Ordinal);
        var edges = new HashSet<(string, string, string)>();

        GraphNode Node(string id, string label, string type, string? path = null, int? line = null, string? key = null)
        {
            if (!nodes.TryGetValue(id, out var node))
            {
                node = new GraphNode { Id = id, Label = label, Type = type, Path = path, Line = line, Key = key };
                nodes[id] = node;
            }
            return node;
        }

        void Edge(string from, string to, string kind)
        {
            if (from != to && nodes.ContainsKey(from) && nodes.ContainsKey(to))
            {
                edges.Add((from, to, kind));
            }
        }

        var repoId = "repo";
        Node(repoId, repository.Title, ConceptTypes.Repository);

        // Projects.
        var projectIds = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (code is not null)
        {
            foreach (var project in code.Manifest.Projects)
            {
                var id = "project:" + project.Name;
                projectIds[project.Name] = id;
                Node(id, project.Name, ConceptTypes.Project, project.Path, 1, project.Name);
                Edge(repoId, id, EdgeKinds.Contains);
            }
            foreach (var project in code.Manifest.Projects)
            {
                foreach (var reference in project.ProjectReferences)
                {
                    if (projectIds.TryGetValue(Path.GetFileNameWithoutExtension(reference), out var target))
                    {
                        Edge(projectIds[project.Name], target, EdgeKinds.References);
                    }
                }
            }
        }

        // Source files (code only: configuration and text files would drown the picture).
        var projectDirs = code?.Manifest.Projects.Select(p => (Dir: p.Directory.Replace('\\', '/').TrimEnd('/') is "." ? "" : p.Directory.Replace('\\', '/').TrimEnd('/'), Id: projectIds[p.Name]))
            .OrderByDescending(p => p.Dir.Length).ToList() ?? [];
        string OwnerOf(string path)
        {
            foreach (var (dir, id) in projectDirs)
            {
                if (dir.Length == 0 || path.StartsWith(dir + "/", StringComparison.OrdinalIgnoreCase))
                {
                    return id;
                }
            }
            return repoId;
        }

        foreach (var file in files.Where(f => f.Kind == FileKind.Source))
        {
            var id = "file:" + file.Path;
            Node(id, file.Name, ConceptTypes.File, file.Path, 1, file.Path);
            Edge(OwnerOf(file.Path), id, EdgeKinds.Contains);
        }

        // Markdown files and their documentation pages.
        foreach (var page in pages)
        {
            var pageId = "page:" + page.Id;
            Node(pageId, page.Title, ConceptTypes.DocumentationPage, page.SourcePath, null, page.Id);
            if (page.SourcePath is { } source)
            {
                var mdId = "md:" + source;
                Node(mdId, Path.GetFileName(source), ConceptTypes.MarkdownFile, source, 1, source);
                Edge(OwnerOf(source), mdId, EdgeKinds.Contains);
                Edge(pageId, mdId, EdgeKinds.Documents);
            }
            else
            {
                Edge(repoId, pageId, EdgeKinds.Contains);
            }
        }

        if (code is not null)
        {
            var types = code.Types.ToList();
            var testTypeNames = code.TestMethods.Select(m => m.Container).Where(c => c is not null).ToHashSet(StringComparer.Ordinal);
            var typeIds = new Dictionary<string, string>(StringComparer.Ordinal);       // full name → node id
            var byName = new Dictionary<string, List<string>>(StringComparer.Ordinal);   // simple name → node ids

            foreach (var type in types)
            {
                var isTest = type.IsTest || testTypeNames.Contains(type.FullName) || code.IsTestProject(type.Project) && type.Name.EndsWith("Tests", StringComparison.Ordinal);
                var conceptType = isTest ? ConceptTypes.Test : CodeIndexHelpers.ConceptType(type);
                var id = "type:" + type.FullName;
                if (nodes.ContainsKey(id))
                {
                    continue; // partial declarations: the first one stands for the type
                }
                Node(id, type.Name, conceptType, type.File, type.StartLine, type.FullName);
                typeIds[type.FullName] = id;
                if (!byName.TryGetValue(type.Name, out var list))
                {
                    byName[type.Name] = list = [];
                }
                list.Add(id);

                // Namespace.
                if (!string.IsNullOrEmpty(type.Namespace))
                {
                    var nsId = "ns:" + type.Namespace;
                    Node(nsId, type.Namespace, ConceptTypes.Namespace, null, null, type.Namespace);
                    Edge(nsId, id, EdgeKinds.Contains);
                    var owner = !string.IsNullOrEmpty(type.Project) && projectIds.TryGetValue(type.Project, out var projectId) ? projectId : repoId;
                    Edge(owner, nsId, EdgeKinds.Contains);
                }
                Edge("file:" + type.File, id, EdgeKinds.Declares);
            }

            string? Resolve(string simpleName, string fromNamespace)
            {
                var name = CodeIndex.StripGeneric(simpleName);
                if (!byName.TryGetValue(name, out var candidates))
                {
                    return null;
                }
                if (candidates.Count == 1)
                {
                    return candidates[0];
                }
                return candidates.FirstOrDefault(c => c.StartsWith("type:" + fromNamespace + ".", StringComparison.Ordinal)) ?? candidates[0];
            }

            foreach (var type in types)
            {
                if (!typeIds.TryGetValue(type.FullName, out var id))
                {
                    continue;
                }
                foreach (var baseName in type.Bases)
                {
                    if (Resolve(baseName, type.Namespace) is { } target)
                    {
                        Edge(id, target, EdgeKinds.Inherits);
                    }
                }
                // Uses and calls of the type's members, folded onto the type.
                var references = new HashSet<string>(StringComparer.Ordinal);
                foreach (var member in code.MembersOf(type.FullName).Append(type))
                {
                    foreach (var used in member.Uses.Concat(member.ParameterTypes).Append(member.ReturnType ?? ""))
                    {
                        if (used.Length > 0 && Resolve(used, type.Namespace) is { } target && target != id)
                        {
                            references.Add(target);
                        }
                    }
                    foreach (var call in member.Calls)
                    {
                        if (byName.ContainsKey(call) && Resolve(call, type.Namespace) is { } ctorTarget && ctorTarget != id)
                        {
                            references.Add(ctorTarget); // new Foo(...) and static Foo(...) calls
                        }
                    }
                }
                var kind = nodes[id].Type == ConceptTypes.Test ? EdgeKinds.Tests : EdgeKinds.Uses;
                foreach (var target in references)
                {
                    Edge(id, target, kind);
                }
            }

            // Documentation mentions: a page that names a type (as a word) documents it.
            var mentionable = byName.Where(kv => kv.Key.Length >= 4 && kv.Value.Count == 1).ToDictionary(kv => kv.Key, kv => kv.Value[0], StringComparer.Ordinal);
            if (mentionable.Count > 0)
            {
                foreach (var page in pages.Where(p => p.SourcePath is not null))
                {
                    var text = readText(page.SourcePath!);
                    if (text is null)
                    {
                        continue;
                    }
                    var words = TextUtil.CandidateIdentifiers(text).Select(w => w.Contains('.') ? w[(w.LastIndexOf('.') + 1)..] : w).ToHashSet(StringComparer.Ordinal);
                    foreach (var word in words)
                    {
                        if (mentionable.TryGetValue(word, out var target))
                        {
                            Edge("page:" + page.Id, target, EdgeKinds.Mentions);
                        }
                    }
                }
            }
        }

        graph.Nodes = nodes.Values.ToList();
        graph.Edges = edges.Select(e => new GraphEdge { From = e.Item1, To = e.Item2, Kind = e.Item3 })
            .OrderBy(e => e.From, StringComparer.Ordinal).ThenBy(e => e.To, StringComparer.Ordinal).ThenBy(e => e.Kind, StringComparer.Ordinal).ToList();
        graph.InvalidateLookup();
        return graph;
    }

    /// <summary>The most connected part of the graph, for drawing large repositories: the top nodes by degree plus the repository.</summary>
    public static KnowledgeGraph Reduce(KnowledgeGraph graph, int maxNodes, ISet<string>? types = null)
    {
        var candidates = graph.Nodes.Where(n => types is null || types.Contains(n.Type)).ToList();
        if (candidates.Count <= maxNodes && types is null)
        {
            return graph;
        }
        var degree = new Dictionary<string, int>(StringComparer.Ordinal);
        foreach (var edge in graph.Edges)
        {
            degree[edge.From] = degree.GetValueOrDefault(edge.From) + 1;
            degree[edge.To] = degree.GetValueOrDefault(edge.To) + 1;
        }
        var keep = candidates
            .OrderByDescending(n => n.Type == ConceptTypes.Repository ? int.MaxValue : degree.GetValueOrDefault(n.Id))
            .ThenBy(n => n.Id, StringComparer.Ordinal)
            .Take(maxNodes)
            .Select(n => n.Id)
            .ToHashSet(StringComparer.Ordinal);
        return new KnowledgeGraph
        {
            Nodes = graph.Nodes.Where(n => keep.Contains(n.Id)).ToList(),
            Edges = graph.Edges.Where(e => keep.Contains(e.From) && keep.Contains(e.To)).ToList(),
        };
    }

    /// <summary>The neighbourhood of one node to the given depth.</summary>
    public static KnowledgeGraph Focus(KnowledgeGraph graph, string nodeId, int depth)
    {
        var keep = new HashSet<string>(StringComparer.Ordinal) { nodeId };
        var frontier = new List<string> { nodeId };
        var adjacency = new Dictionary<string, List<string>>(StringComparer.Ordinal);
        foreach (var edge in graph.Edges)
        {
            (adjacency.TryGetValue(edge.From, out var a) ? a : adjacency[edge.From] = []).Add(edge.To);
            (adjacency.TryGetValue(edge.To, out var b) ? b : adjacency[edge.To] = []).Add(edge.From);
        }
        for (var d = 0; d < depth; d++)
        {
            var next = new List<string>();
            foreach (var id in frontier)
            {
                foreach (var neighbour in adjacency.GetValueOrDefault(id) ?? [])
                {
                    if (keep.Add(neighbour))
                    {
                        next.Add(neighbour);
                    }
                }
            }
            frontier = next;
        }
        return new KnowledgeGraph
        {
            Nodes = graph.Nodes.Where(n => keep.Contains(n.Id)).ToList(),
            Edges = graph.Edges.Where(e => keep.Contains(e.From) && keep.Contains(e.To)).ToList(),
        };
    }
}
