using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;

namespace DocGen.Explorer.Engine.Graph;

/// <summary>A group of at most <see cref="GraphGrouper.MaxGroupSize"/> concepts that belong together, and why.</summary>
public sealed class GraphGroup
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";

    /// <summary>Why these concepts are together: the links that bind them (and, when a model refined it, its explanation).</summary>
    public string Reason { get; set; } = "";

    public List<string> Members { get; set; } = [];

    /// <summary>The member most connected inside the group.</summary>
    public string? Hub { get; set; }

    /// <summary>Share (0–1) of the members' link weight that stays inside the group.</summary>
    public double Cohesion { get; set; }

    public int InternalLinks { get; set; }
}

/// <summary>A link between two groups: how many concept links cross between them, and of which kind mostly.</summary>
public sealed record GroupLink(string From, string To, int Count, string Kind);

/// <summary>A saved grouping of the graph (repos/&lt;id&gt;/graph-groups.json).</summary>
public sealed class GraphGrouping
{
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>"structure" (computed from the links) or the model that named and refined the groups.</summary>
    public string By { get; set; } = "structure";

    /// <summary>How many concepts were grouped (the graph as shown when grouping).</summary>
    public int ConceptCount { get; set; }

    public List<GraphGroup> Groups { get; set; } = [];
    public List<GroupLink> Links { get; set; } = [];

    public GraphGroup? GroupOf(string nodeId) => Groups.FirstOrDefault(g => g.Members.Contains(nodeId));
}

/// <summary>
/// Breaks a graph into groups people can read — at most 30 concepts each — by how strongly the concepts are linked:
/// a modularity-maximising local search (Louvain's first phase) with a size cap, links weighted by meaning (inheriting
/// and using bind more than being declared in the same file or mentioned in a page), then small leftovers folded into
/// the group they are most linked to. Each group gets a name and a reason computed from its links; the model can
/// refine both (see <see cref="GraphGroupingService"/>).
/// </summary>
public static class GraphGrouper
{
    public const int MaxGroupSize = 30;
    public const int MinGroupSize = 3;

    public static double Weight(string kind) => kind switch
    {
        EdgeKinds.Inherits => 3.0,
        EdgeKinds.Uses or EdgeKinds.Calls => 2.0,
        EdgeKinds.Tests => 0.7, // a test touches many types: it should not decide what production code belongs together
        EdgeKinds.Declares => 1.5,
        EdgeKinds.References => 1.2,
        EdgeKinds.Contains => 0.6,
        EdgeKinds.Documents or EdgeKinds.Mentions => 0.8,
        _ => 1.0,
    };

    public static GraphGrouping Group(KnowledgeGraph graph, int maxSize = MaxGroupSize)
    {
        maxSize = Math.Clamp(maxSize, 5, 60);
        // The repository node links to everything: it would glue every group together. It is not grouped.
        var nodes = graph.Nodes.Where(n => n.Type != ConceptTypes.Repository).OrderBy(n => n.Id, StringComparer.Ordinal).ToList();
        var index = nodes.Select((n, i) => (n.Id, i)).ToDictionary(x => x.Id, x => x.i, StringComparer.Ordinal);
        var n = nodes.Count;
        var adjacency = new Dictionary<int, double>[n];
        for (var i = 0; i < n; i++)
        {
            adjacency[i] = [];
        }
        var kinds = new Dictionary<(int, int), string>();
        foreach (var edge in graph.Edges)
        {
            if (!index.TryGetValue(edge.From, out var a) || !index.TryGetValue(edge.To, out var b) || a == b)
            {
                continue;
            }
            var w = Weight(edge.Kind);
            adjacency[a][b] = adjacency[a].GetValueOrDefault(b) + w;
            adjacency[b][a] = adjacency[b].GetValueOrDefault(a) + w;
            var key = a < b ? (a, b) : (b, a);
            if (!kinds.TryGetValue(key, out var existing) || Weight(edge.Kind) > Weight(existing))
            {
                kinds[key] = edge.Kind;
            }
        }
        var degree = adjacency.Select(a => a.Values.Sum()).ToArray();
        var total = Math.Max(1e-9, degree.Sum()); // 2m

        // Louvain phase one with a cap: move each node to the neighbouring community that gains the most modularity.
        var community = Enumerable.Range(0, n).ToArray();
        var size = Enumerable.Repeat(1, n).ToArray();
        var communityDegree = degree.ToArray();
        var order = Enumerable.Range(0, n).OrderByDescending(i => degree[i]).ThenBy(i => nodes[i].Id, StringComparer.Ordinal).ToArray();
        for (var pass = 0; pass < 12; pass++)
        {
            var moved = 0;
            foreach (var i in order)
            {
                var current = community[i];
                var links = new Dictionary<int, double>();
                foreach (var (j, w) in adjacency[i])
                {
                    links[community[j]] = links.GetValueOrDefault(community[j]) + w;
                }
                // Take the node out, then put it where it gains most (staying is an option).
                communityDegree[current] -= degree[i];
                size[current]--;
                var best = current;
                var bestGain = links.GetValueOrDefault(current) - communityDegree[current] * degree[i] / total;
                foreach (var (c, w) in links.OrderBy(l => l.Key))
                {
                    if (c == current || size[c] >= maxSize)
                    {
                        continue;
                    }
                    var gain = w - communityDegree[c] * degree[i] / total;
                    if (gain > bestGain + 1e-12)
                    {
                        (best, bestGain) = (c, gain);
                    }
                }
                community[i] = best;
                communityDegree[best] += degree[i];
                size[best]++;
                if (best != current)
                {
                    moved++;
                }
            }
            if (moved == 0)
            {
                break;
            }
        }

        // Fold small communities into the group they are most linked to (when it has room).
        var members = Enumerable.Range(0, n).GroupBy(i => community[i]).ToDictionary(g => g.Key, g => g.ToList());
        foreach (var small in members.Where(m => m.Value.Count < MinGroupSize).OrderBy(m => m.Value.Count).Select(m => m.Key).ToList())
        {
            if (!members.TryGetValue(small, out var list))
            {
                continue;
            }
            var targets = new Dictionary<int, double>();
            foreach (var i in list)
            {
                foreach (var (j, w) in adjacency[i])
                {
                    var c = community[j];
                    if (c != small && members[c].Count + list.Count <= maxSize)
                    {
                        targets[c] = targets.GetValueOrDefault(c) + w;
                    }
                }
            }
            if (targets.Count == 0)
            {
                continue;
            }
            var target = targets.OrderByDescending(t => t.Value).ThenBy(t => t.Key).First().Key;
            foreach (var i in list)
            {
                community[i] = target;
            }
            members[target].AddRange(list);
            members.Remove(small);
        }

        // Leftovers whose neighbours' groups are full: together, by the group they link to most ("more of" it); those
        // linked to nothing at all: together by area, packed up to maxSize so lone concepts do not each become a group.
        var loose = members.Where(m => m.Value.Count < MinGroupSize).SelectMany(m => m.Value).ToList();
        foreach (var key in members.Where(m => m.Value.Count < MinGroupSize).Select(m => m.Key).ToList())
        {
            members.Remove(key);
        }
        var nextId = n + 1;
        int? StrongestGroup(int i)
        {
            var links = new Dictionary<int, double>();
            foreach (var (j, w) in adjacency[i])
            {
                if (members.ContainsKey(community[j]))
                {
                    links[community[j]] = links.GetValueOrDefault(community[j]) + w;
                }
            }
            return links.Count == 0 ? null : links.OrderByDescending(l => l.Value).ThenBy(l => l.Key).First().Key;
        }
        var byTarget = loose.GroupBy(StrongestGroup).ToList();
        foreach (var bucket in byTarget.Where(b => b.Key is not null).OrderBy(b => b.Key))
        {
            foreach (var chunk in bucket.Chunk(maxSize))
            {
                members[nextId++] = chunk.ToList();
            }
        }
        var unlinked = byTarget.Where(b => b.Key is null).SelectMany(b => b).OrderBy(i => AreaOf(nodes[i]), StringComparer.Ordinal).ThenBy(i => nodes[i].Label, StringComparer.Ordinal).ToList();
        foreach (var chunk in unlinked.Chunk(maxSize))
        {
            members[nextId++] = chunk.ToList();
        }

        return Build(graph, members.Values.Select(l => l.Select(i => nodes[i].Id).ToList()).ToList());
    }

    /// <summary>Describes given groups of concepts (ids) of the graph: names, reasons, cohesion and the links between groups.</summary>
    public static GraphGrouping Build(KnowledgeGraph graph, IReadOnlyList<List<string>> groupsOfIds)
    {
        var nodes = graph.Nodes.Where(n => n.Type != ConceptTypes.Repository).OrderBy(n => n.Id, StringComparer.Ordinal).ToList();
        var index = nodes.Select((n, i) => (n.Id, i)).ToDictionary(x => x.Id, x => x.i, StringComparer.Ordinal);
        var n = nodes.Count;
        var adjacency = new Dictionary<int, double>[n];
        for (var i = 0; i < n; i++)
        {
            adjacency[i] = [];
        }
        var kinds = new Dictionary<(int, int), string>();
        foreach (var edge in graph.Edges)
        {
            if (!index.TryGetValue(edge.From, out var a) || !index.TryGetValue(edge.To, out var b) || a == b)
            {
                continue;
            }
            var w = Weight(edge.Kind);
            adjacency[a][b] = adjacency[a].GetValueOrDefault(b) + w;
            adjacency[b][a] = adjacency[b].GetValueOrDefault(a) + w;
            var key = a < b ? (a, b) : (b, a);
            if (!kinds.TryGetValue(key, out var existing) || Weight(edge.Kind) > Weight(existing))
            {
                kinds[key] = edge.Kind;
            }
        }
        var lists = groupsOfIds.Select(g => g.Where(index.ContainsKey).Distinct(StringComparer.Ordinal).Select(id => index[id]).ToList()).Where(l => l.Count > 0).ToList();

        // Describe each group.
        var grouping = new GraphGrouping { ConceptCount = n };
        var groupOf = new int[n];
        var number = 0;
        foreach (var list in lists.OrderByDescending(l => l.Count).ThenBy(l => nodes[l[0]].Id, StringComparer.Ordinal))
        {
            number++;
            foreach (var i in list)
            {
                groupOf[i] = number;
            }
            grouping.Groups.Add(Describe($"g{number}", list, nodes, adjacency, kinds));
        }

        // Links between groups.
        var crossing = new Dictionary<(int, int), (int Count, Dictionary<string, int> Kinds)>();
        foreach (var ((a, b), kind) in kinds)
        {
            var (ga, gb) = (groupOf[a], groupOf[b]);
            if (ga == gb)
            {
                continue;
            }
            var key = ga < gb ? (ga, gb) : (gb, ga);
            if (!crossing.TryGetValue(key, out var value))
            {
                value = (0, []);
            }
            value.Kinds[kind] = value.Kinds.GetValueOrDefault(kind) + 1;
            crossing[key] = (value.Count + 1, value.Kinds);
        }
        grouping.Links = crossing.OrderByDescending(c => c.Value.Count)
            .Select(c => new GroupLink($"g{c.Key.Item1}", $"g{c.Key.Item2}", c.Value.Count, c.Value.Kinds.OrderByDescending(k => k.Value).First().Key))
            .ToList();

        // Two groups with the same name ("Interfaces · Handler" in two versions of a service): say where each lives.
        var byId = nodes.ToDictionary(x => x.Id, StringComparer.Ordinal);
        foreach (var same in grouping.Groups.GroupBy(g => g.Name).Where(g => g.Count() > 1).SelectMany(g => g))
        {
            var area = same.Members.Select(m => AreaOf(byId[m], 2)).GroupBy(a => a).OrderByDescending(a => a.Count()).ThenBy(a => a.Key, StringComparer.Ordinal).First().Key;
            var hub = same.Hub is { } h ? byId[h].Label : null;
            same.Name = hub is null || area.EndsWith(hub, StringComparison.Ordinal) ? area : $"{area} · {hub}";
        }

        // A group with hardly any links inside but many to one other group is that group's overflow: say so.
        foreach (var group in grouping.Groups.Where(g => g.InternalLinks < g.Members.Count / 2))
        {
            var main = grouping.Links.Where(l => l.From == group.Id || l.To == group.Id)
                .Select(l => (Other: l.From == group.Id ? l.To : l.From, l.Count, l.Kind)).OrderByDescending(l => l.Count).FirstOrDefault();
            if (main.Other is null || main.Count < group.Members.Count)
            {
                continue;
            }
            var other = grouping.Groups.First(g => g.Id == main.Other);
            group.Name = $"More of {other.Name}";
            group.Reason = $"{TextUtil.Plural(group.Members.Count, "concept")} linked mostly to \"{other.Name}\" ({TextUtil.Plural(main.Count, "link")}, mostly {main.Kind}) " +
                           $"rather than to each other; kept beside it because that group is full ({MaxGroupSize} concepts at most).";
        }
        return grouping;
    }

    /// <summary>The project or top folders a concept lives in (for naming groups and gathering loose concepts).</summary>
    public static string AreaOf(GraphNode node) => AreaOf(node, 1);

    /// <summary>The last <paramref name="parts"/> parts of where a concept lives ("OrderService_1_0.Interfaces" for 2).</summary>
    public static string AreaOf(GraphNode node, int parts)
    {
        if (parts > 1 && node.Type is not ConceptTypes.Project and not ConceptTypes.Namespace)
        {
            if (node.Type is not ConceptTypes.File && node.Key is { } k && k.Contains('.') && ConceptTypes.IsType(node.Type))
            {
                var segments = k.Split('.')[..^1];
                return string.Join('.', segments[Math.Max(0, segments.Length - parts)..]);
            }
            if (node.Path is { } p)
            {
                var folders = p.Replace('\\', '/').Split('/')[..^1];
                return folders.Length == 0 ? "(root)" : string.Join('/', folders[Math.Max(0, folders.Length - parts)..]);
            }
        }
        if (node.Type is ConceptTypes.Project or ConceptTypes.Namespace)
        {
            return node.Label;
        }
        if (node.Type is not ConceptTypes.File && node.Key is { } key && key.Contains('.') && ConceptTypes.IsType(node.Type))
        {
            var ns = key[..key.LastIndexOf('.')];
            return ns[(Math.Max(0, ns.LastIndexOf('.') + 1))..];
        }
        if (node.Path is { } path)
        {
            var pieces = path.Replace('\\', '/').Split('/');
            return pieces.Length > 1 ? pieces[^2] : "(root)";
        }
        return node.Type;
    }

    private static GraphGroup Describe(string id, List<int> list, List<GraphNode> nodes, Dictionary<int, double>[] adjacency, Dictionary<(int, int), string> kinds)
    {
        var set = list.ToHashSet();
        var internalWeight = 0.0;
        var externalWeight = 0.0;
        var internalDegree = new Dictionary<int, double>();
        var kindCounts = new Dictionary<string, int>();
        var internalLinks = 0;
        foreach (var i in list)
        {
            foreach (var (j, w) in adjacency[i])
            {
                if (set.Contains(j))
                {
                    internalWeight += w;
                    internalDegree[i] = internalDegree.GetValueOrDefault(i) + w;
                    if (i < j)
                    {
                        internalLinks++;
                        var kind = kinds[(i, j)];
                        kindCounts[kind] = kindCounts.GetValueOrDefault(kind) + 1;
                    }
                }
                else
                {
                    externalWeight += w;
                }
            }
        }
        var hub = internalDegree.Count == 0 ? list[0] : internalDegree.OrderByDescending(d => d.Value).ThenBy(d => nodes[d.Key].Id, StringComparer.Ordinal).First().Key;
        var hubLinks = list.Count(j => j != hub && adjacency[hub].ContainsKey(j));
        var areas = list.Select(i => AreaOf(nodes[i])).GroupBy(a => a).OrderByDescending(g => g.Count()).ThenBy(g => g.Key, StringComparer.Ordinal).ToList();
        var area = areas[0].Key;
        var cohesion = internalWeight + externalWeight == 0 ? 0 : internalWeight / (internalWeight + externalWeight);
        var types = list.GroupBy(i => nodes[i].Type).OrderByDescending(g => g.Count()).Take(3).Select(g => TextUtil.Plural(g.Count(), g.Key.ToLowerInvariant()));

        string reason;
        if (internalLinks == 0)
        {
            reason = $"{TextUtil.Plural(list.Count, "concept")} in {area} with no links among them in this view, gathered by where they live ({string.Join(", ", types)}).";
        }
        else
        {
            var kindText = TextUtil.JoinNatural(kindCounts.OrderByDescending(k => k.Value).Take(3).Select(k => $"{k.Value} {k.Key}"));
            reason = $"{TextUtil.Plural(list.Count, "concept")} bound by {TextUtil.Plural(internalLinks, "link")} among themselves ({kindText}); " +
                     $"{cohesion:P0} of their links stay inside the group. Centred on {nodes[hub].Label}, linked to {TextUtil.Plural(hubLinks, "other member")}" +
                     (areas[0].Count() * 2 > list.Count ? $"; mostly in {area}." : $"; spread over {TextUtil.JoinNatural(areas.Take(3).Select(a => a.Key))}.");
        }
        var name = internalLinks == 0 ? $"{area} (unlinked)" : area == nodes[hub].Label ? area : $"{area} · {nodes[hub].Label}";
        return new GraphGroup
        {
            Id = id,
            Name = name,
            Reason = reason,
            Members = list.Select(i => nodes[i].Id).ToList(),
            Hub = nodes[hub].Id,
            Cohesion = Math.Round(cohesion, 3),
            InternalLinks = internalLinks,
        };
    }

    /// <summary>The overview: one node per group, linked where concepts link across groups.</summary>
    public static KnowledgeGraph Overview(GraphGrouping grouping)
    {
        var graph = new KnowledgeGraph();
        foreach (var group in grouping.Groups)
        {
            graph.Nodes.Add(new GraphNode
            {
                Id = "group:" + group.Id,
                Label = group.Name,
                Type = ConceptTypes.Group,
                Key = group.Id,
                Description = $"{TextUtil.Plural(group.Members.Count, "concept")} · {group.Cohesion:P0} of links inside",
            });
        }
        foreach (var link in grouping.Links)
        {
            graph.Edges.Add(new GraphEdge { From = "group:" + link.From, To = "group:" + link.To, Kind = link.Kind });
        }
        return graph;
    }

    /// <summary>One group's members and the links among them.</summary>
    public static KnowledgeGraph Members(KnowledgeGraph full, GraphGroup group)
    {
        var set = group.Members.ToHashSet(StringComparer.Ordinal);
        return new KnowledgeGraph
        {
            Nodes = full.Nodes.Where(n => set.Contains(n.Id)).ToList(),
            Edges = full.Edges.Where(e => set.Contains(e.From) && set.Contains(e.To)).ToList(),
        };
    }
}
