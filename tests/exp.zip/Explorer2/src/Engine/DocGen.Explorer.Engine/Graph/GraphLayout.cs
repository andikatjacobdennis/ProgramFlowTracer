using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;

namespace DocGen.Explorer.Engine.Graph;

/// <summary>
/// Deterministic force-directed layout (Fruchterman–Reingold with cooling) followed by rectangle overlap removal, sized
/// for card-shaped nodes. The same graph always gets the same picture.
/// </summary>
public static class GraphLayout
{
    public const double NodeWidth = 190;
    public const double NodeHeight = 52;

    /// <summary>
    /// Lays out each connected part on its own and packs the parts in rows, biggest first (one force simulation over
    /// everything pushed small parts and lone concepts far out to the edges). Lone concepts go in a tidy grid at the end.
    /// </summary>
    public static Dictionary<string, NodePosition> Compute(KnowledgeGraph graph, int iterations = 300)
    {
        var components = Components(graph);
        if (components.Count <= 1)
        {
            return ComputeConnected(graph, iterations);
        }
        var parts = new List<(double W, double H, Dictionary<string, NodePosition> Positions)>();
        var singles = new List<GraphNode>();
        foreach (var component in components)
        {
            if (component.Nodes.Count == 1)
            {
                singles.Add(component.Nodes[0]);
                continue;
            }
            var positions = ComputeConnected(component, iterations);
            parts.Add((positions.Values.Max(p => p.X) + NodeWidth, positions.Values.Max(p => p.Y) + NodeHeight, positions));
        }
        if (singles.Count > 0)
        {
            // Lone concepts: a compact grid, ordered by kind and name.
            var columns = Math.Max(1, (int)Math.Ceiling(Math.Sqrt(singles.Count * 1.6)));
            var grid = new Dictionary<string, NodePosition>(StringComparer.Ordinal);
            var ordered = singles.OrderBy(s => TypeRank(s.Type)).ThenBy(s => s.Label, StringComparer.OrdinalIgnoreCase).ToList();
            for (var i = 0; i < ordered.Count; i++)
            {
                grid[ordered[i].Id] = new NodePosition(ordered[i].Id, 20 + i % columns * (NodeWidth + 24), 20 + i / columns * (NodeHeight + 24));
            }
            parts.Add((grid.Values.Max(p => p.X) + NodeWidth, grid.Values.Max(p => p.Y) + NodeHeight, grid));
        }

        // Shelf packing: rows about as wide as a 16:10 picture of everything.
        const double gap = 80;
        var area = parts.Sum(p => (p.W + gap) * (p.H + gap));
        var rowWidth = Math.Max(parts.Max(p => p.W), Math.Sqrt(area * 1.6));
        var result = new Dictionary<string, NodePosition>(StringComparer.Ordinal);
        double x = 0, y = 0, rowHeight = 0;
        foreach (var part in parts.OrderByDescending(p => p.W * p.H))
        {
            if (x > 0 && x + part.W > rowWidth)
            {
                x = 0;
                y += rowHeight + gap;
                rowHeight = 0;
            }
            foreach (var position in part.Positions.Values)
            {
                result[position.Id] = new NodePosition(position.Id, Math.Round(position.X + x, 1), Math.Round(position.Y + y, 1));
            }
            x += part.W + gap;
            rowHeight = Math.Max(rowHeight, part.H);
        }
        return result;
    }

    /// <summary>The connected parts of a graph, biggest first.</summary>
    public static List<KnowledgeGraph> Components(KnowledgeGraph graph)
    {
        var ids = graph.Nodes.Select(n => n.Id).ToHashSet(StringComparer.Ordinal);
        var neighbours = graph.Nodes.ToDictionary(n => n.Id, _ => new List<string>(), StringComparer.Ordinal);
        foreach (var e in graph.Edges.Where(e => ids.Contains(e.From) && ids.Contains(e.To)))
        {
            neighbours[e.From].Add(e.To);
            neighbours[e.To].Add(e.From);
        }
        var seen = new HashSet<string>(StringComparer.Ordinal);
        var parts = new List<KnowledgeGraph>();
        foreach (var start in graph.Nodes.OrderBy(n => n.Id, StringComparer.Ordinal))
        {
            if (!seen.Add(start.Id))
            {
                continue;
            }
            var members = new HashSet<string>(StringComparer.Ordinal) { start.Id };
            var queue = new Queue<string>([start.Id]);
            while (queue.Count > 0)
            {
                foreach (var next in neighbours[queue.Dequeue()])
                {
                    if (seen.Add(next))
                    {
                        members.Add(next);
                        queue.Enqueue(next);
                    }
                }
            }
            parts.Add(new KnowledgeGraph
            {
                Nodes = graph.Nodes.Where(n => members.Contains(n.Id)).ToList(),
                Edges = graph.Edges.Where(e => members.Contains(e.From) && members.Contains(e.To)).ToList(),
            });
        }
        return parts.OrderByDescending(p => p.Nodes.Count).ToList();
    }

    private static Dictionary<string, NodePosition> ComputeConnected(KnowledgeGraph graph, int iterations)
    {
        var nodes = graph.Nodes.OrderBy(n => n.Id, StringComparer.Ordinal).ToList();
        var n = nodes.Count;
        var result = new Dictionary<string, NodePosition>(StringComparer.Ordinal);
        if (n == 0)
        {
            return result;
        }
        var index = new Dictionary<string, int>(StringComparer.Ordinal);
        for (var i = 0; i < n; i++)
        {
            index[nodes[i].Id] = i;
        }
        var edges = graph.Edges.Where(e => index.ContainsKey(e.From) && index.ContainsKey(e.To))
            .Select(e => (index[e.From], index[e.To])).Distinct().ToList();

        // Area grows with the node count; k is the ideal edge length.
        var area = Math.Max(1, n) * NodeWidth * NodeHeight * 3.2;
        var width = Math.Sqrt(area * 1.6);
        var height = area / width;
        var k = Math.Sqrt(area / n) * 0.9;

        var x = new double[n];
        var y = new double[n];
        // Deterministic start: a golden-angle spiral, ordered by type so kinds start near each other.
        var order = Enumerable.Range(0, n).OrderBy(i => TypeRank(nodes[i].Type)).ThenBy(i => nodes[i].Id, StringComparer.Ordinal).ToList();
        for (var r = 0; r < n; r++)
        {
            var i = order[r];
            var radius = k * 0.6 * Math.Sqrt(r + 1);
            var angle = r * 2.399963229728653 + (TextUtil.Fnv1a(nodes[i].Id) % 100) / 1000.0;
            x[i] = Math.Cos(angle) * radius;
            y[i] = Math.Sin(angle) * radius;
        }

        var dx = new double[n];
        var dy = new double[n];
        var temperature = width / 8;
        var steps = n > 600 ? Math.Min(iterations, 120) : iterations;
        for (var step = 0; step < steps; step++)
        {
            Array.Clear(dx);
            Array.Clear(dy);
            for (var i = 0; i < n; i++)
            {
                for (var j = i + 1; j < n; j++)
                {
                    var ddx = x[i] - x[j];
                    var ddy = y[i] - y[j];
                    var dist2 = ddx * ddx + ddy * ddy;
                    if (dist2 < 0.01)
                    {
                        ddx = 0.1 * ((i + j) % 2 == 0 ? 1 : -1);
                        ddy = 0.1;
                        dist2 = 0.02;
                    }
                    var dist = Math.Sqrt(dist2);
                    var force = k * k / dist;
                    var fx = ddx / dist * force;
                    var fy = ddy / dist * force;
                    dx[i] += fx;
                    dy[i] += fy;
                    dx[j] -= fx;
                    dy[j] -= fy;
                }
            }
            foreach (var (a, b) in edges)
            {
                var ddx = x[a] - x[b];
                var ddy = y[a] - y[b];
                var dist = Math.Max(0.01, Math.Sqrt(ddx * ddx + ddy * ddy));
                var force = dist * dist / k;
                var fx = ddx / dist * force;
                var fy = ddy / dist * force;
                dx[a] -= fx;
                dy[a] -= fy;
                dx[b] += fx;
                dy[b] += fy;
            }
            for (var i = 0; i < n; i++)
            {
                // Gentle gravity keeps disconnected parts from drifting away.
                dx[i] -= x[i] * 0.05;
                dy[i] -= y[i] * 0.08; // pull harder vertically: screens are wider than tall
                var length = Math.Sqrt(dx[i] * dx[i] + dy[i] * dy[i]);
                if (length > 0)
                {
                    var move = Math.Min(length, temperature);
                    x[i] += dx[i] / length * move;
                    y[i] += dy[i] / length * move;
                }
            }
            temperature = Math.Max(1, temperature * 0.97);
        }

        RemoveOverlaps(x, y, NodeWidth + 24, NodeHeight + 28);
        Compact(x, y);

        // Screens are wide: squeeze a tall drawing towards 16:10, then separate whatever that made overlap.
        var spanX = x.Max() - x.Min() + NodeWidth;
        var spanY = y.Max() - y.Min() + NodeHeight;
        if (spanY > spanX / 1.6)
        {
            var squeeze = Math.Max(0.45, spanX / 1.6 / spanY);
            var midY = (y.Max() + y.Min()) / 2;
            var stretch = Math.Min(1.35, 1 / Math.Sqrt(squeeze));
            var midX = (x.Max() + x.Min()) / 2;
            for (var i = 0; i < n; i++)
            {
                y[i] = midY + (y[i] - midY) * squeeze;
                x[i] = midX + (x[i] - midX) * stretch;
            }
            RemoveOverlaps(x, y, NodeWidth + 24, NodeHeight + 28);
        }

        var minX = x.Min();
        var minY = y.Min();
        for (var i = 0; i < n; i++)
        {
            result[nodes[i].Id] = new NodePosition(nodes[i].Id, Math.Round(x[i] - minX + 20, 1), Math.Round(y[i] - minY + 20, 1));
        }
        return result;
    }

    /// <summary>
    /// Sparse parts (trees of namespaces, files and classes) come out of the simulation far wider than they need, so a
    /// fitted view is too small to read. Pulls a drawing that gives each card much more room than a dense one does
    /// towards its middle, then separates whatever that made overlap. Dense drawings are left alone.
    /// </summary>
    public static void Compact(double[] x, double[] y)
    {
        var n = x.Length;
        if (n < 3)
        {
            return;
        }
        const double roomPerCard = 7; // card areas per card in a comfortable drawing
        var spanX = x.Max() - x.Min() + NodeWidth;
        var spanY = y.Max() - y.Min() + NodeHeight;
        var room = spanX * spanY / (n * NodeWidth * NodeHeight);
        if (room <= roomPerCard)
        {
            return;
        }
        var factor = Math.Max(0.35, Math.Sqrt(roomPerCard / room));
        var midX = x.Average();
        var midY = y.Average();
        for (var i = 0; i < n; i++)
        {
            x[i] = midX + (x[i] - midX) * factor;
            y[i] = midY + (y[i] - midY) * factor;
        }
        RemoveOverlaps(x, y, NodeWidth + 24, NodeHeight + 28);
    }

    /// <summary>Pushes overlapping rectangles apart along the axis of least overlap until none overlap (bounded passes).</summary>
    public static void RemoveOverlaps(double[] x, double[] y, double w, double h)
    {
        var n = x.Length;
        for (var pass = 0; pass < 200; pass++)
        {
            var moved = false;
            var order = Enumerable.Range(0, n).OrderBy(i => x[i]).ToArray();
            for (var a = 0; a < n; a++)
            {
                var i = order[a];
                for (var b = a + 1; b < n; b++)
                {
                    var j = order[b];
                    if (x[j] - x[i] >= w)
                    {
                        break; // sorted by x: nothing further can overlap i horizontally
                    }
                    var ox = w - Math.Abs(x[i] - x[j]);
                    var oy = h - Math.Abs(y[i] - y[j]);
                    if (ox <= 0 || oy <= 0)
                    {
                        continue;
                    }
                    moved = true;
                    if (ox * 0.5 < oy)
                    {
                        var shift = ox / 2 + 0.5;
                        var dir = x[i] <= x[j] ? -1 : 1;
                        x[i] += dir * shift;
                        x[j] -= dir * shift;
                    }
                    else
                    {
                        var shift = oy / 2 + 0.5;
                        var dir = y[i] <= y[j] ? -1 : 1;
                        y[i] += dir * shift;
                        y[j] -= dir * shift;
                    }
                }
            }
            if (!moved)
            {
                return;
            }
        }
    }

    public static bool AnyOverlap(IReadOnlyCollection<NodePosition> positions)
    {
        var list = positions.ToList();
        for (var i = 0; i < list.Count; i++)
        {
            for (var j = i + 1; j < list.Count; j++)
            {
                if (Math.Abs(list[i].X - list[j].X) < NodeWidth && Math.Abs(list[i].Y - list[j].Y) < NodeHeight)
                {
                    return true;
                }
            }
        }
        return false;
    }

    private static int TypeRank(string type) => type switch
    {
        ConceptTypes.Repository => 0,
        ConceptTypes.Project => 1,
        ConceptTypes.Namespace => 2,
        ConceptTypes.DocumentationPage => 3,
        ConceptTypes.MarkdownFile => 4,
        ConceptTypes.File => 5,
        ConceptTypes.Test => 7,
        _ => 6,
    };
}
