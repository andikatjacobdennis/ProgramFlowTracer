using System.Text;
using System.Text.Json;
using DocGen.Explorer.Engine.Ai;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Storage;
using DocGen.Explorer.Engine.Text;
using DocGen.Core.Abstractions;

namespace DocGen.Explorer.Engine.Graph;

/// <summary>
/// Groups the graph for reading: <see cref="GraphGrouper"/> partitions it by its links (at most 30 concepts a group),
/// then — with a chat model — the model names each group, says why its members belong together from the links it is
/// shown, and may move a concept to a group it clearly belongs with. Every move is checked (the size cap holds, no
/// group is emptied) and a reply that cannot be read leaves the computed groups as they are. Saved per repository.
/// </summary>
public sealed class GraphGroupingService(ExplorerStore store, IModelGateway models)
{
    private const string FileName = "graph-groups.json";
    private const int GroupsPerCall = 8;
    private const int MaxGroupsForModel = 96;

    public Task<GraphGrouping?> LoadAsync(string repositoryId, CancellationToken ct = default)
        => store.ReadLargeAsync<GraphGrouping>(store.RepositoryRelative(repositoryId, FileName), ct);

    public void Reset(string repositoryId) => store.Delete(store.RepositoryRelative(repositoryId, FileName));

    /// <summary>
    /// Groups <paramref name="graph"/> (the graph as shown), refines the groups with the model when one is configured, and saves
    /// the result. <paramref name="instructions"/> (optional, the person's own words: "by feature", "keep tests apart") go to
    /// the model with every batch.
    /// </summary>
    public async Task<GraphGrouping> GroupAsync(string repositoryId, KnowledgeGraph graph, Action<string>? progress = null, bool useModel = true, CancellationToken ct = default,
        string? instructions = null)
    {
        progress?.Invoke("Finding groups in the links…");
        var grouping = await Task.Run(() => GraphGrouper.Group(graph), ct);
        var status = await models.GetStatusAsync(ct);
        if (useModel && status.Configured && grouping.Groups.Count > 0)
        {
            grouping = await RefineAsync(repositoryId, graph, grouping, status.DisplayName ?? status.ModelId ?? "the model", progress, ct, instructions);
        }
        await store.WriteLargeAsync(store.RepositoryRelative(repositoryId, FileName), grouping, ct);
        return grouping;
    }

    private async Task<GraphGrouping> RefineAsync(string repositoryId, KnowledgeGraph graph, GraphGrouping grouping, string modelName, Action<string>? progress, CancellationToken ct,
        string? instructions = null)
    {
        var byId = graph.Nodes.ToDictionary(n => n.Id, StringComparer.Ordinal);
        var lists = grouping.Groups.ToDictionary(g => g.Id, g => g.Members.ToList(), StringComparer.Ordinal);
        var names = new Dictionary<string, (string Name, string Reason)>(StringComparer.Ordinal);
        var groups = grouping.Groups.Take(MaxGroupsForModel).ToList();
        var failures = 0;
        for (var start = 0; start < groups.Count; start += GroupsPerCall)
        {
            ct.ThrowIfCancellationRequested();
            var batch = groups.Skip(start).Take(GroupsPerCall).ToList();
            progress?.Invoke($"Asking {modelName} to name and check groups {start + 1}–{start + batch.Count} of {grouping.Groups.Count}…");
            var (prompt, refs) = Prompt(graph, grouping, batch, byId);
            if (!string.IsNullOrWhiteSpace(instructions))
            {
                // The person's own wish for the grouping, within what the links allow.
                prompt = $"The person asked for this grouping: \"{instructions.Trim()}\". Follow it when naming groups and moving concepts, as far as their links allow.\n\n" + prompt;
            }
            try
            {
                using var purpose = UsagePurpose.Set($"Name and check graph groups {start + 1}–{start + batch.Count} of {grouping.Groups.Count}");
                var result = await models.CompleteAsync("graph-groups", repositoryId,
                    [ModelMessage.System(SystemPrompt), ModelMessage.User(prompt)], 2500, ct);
                foreach (var answer in Parse(result.Text))
                {
                    if (batch.All(g => g.Id != answer.Id))
                    {
                        continue;
                    }
                    if (answer.Name is { Length: > 0 } name && answer.Reason is { Length: > 0 } reason)
                    {
                        names[answer.Id] = (TextUtil.Truncate(name.Trim(), 60), TextUtil.Truncate(reason.Trim(), 400));
                    }
                    foreach (var move in answer.Moves ?? [])
                    {
                        ApplyMove(lists, refs, batch, answer.Id, move);
                    }
                }
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                failures++; // this batch keeps its computed names
            }
        }

        // Rebuild from the (possibly moved) members, then put the model's names and reasons on.
        var rebuilt = GraphGrouper.Build(graph, lists.Values.ToList());
        foreach (var group in rebuilt.Groups)
        {
            // Match a rebuilt group to the original by the most shared members.
            var origin = lists.OrderByDescending(l => l.Value.Count(group.Members.Contains)).First().Key;
            if (names.TryGetValue(origin, out var named))
            {
                group.Name = named.Name;
                group.Reason = named.Reason + $" ({StructureNote(group)})";
            }
        }
        rebuilt.By = failures == (groups.Count + GroupsPerCall - 1) / GroupsPerCall ? "structure" : modelName;
        return rebuilt;
    }

    private static string StructureNote(GraphGroup group)
        => $"{TextUtil.Plural(group.Members.Count, "concept")}, {TextUtil.Plural(group.InternalLinks, "link")} inside, {group.Cohesion:P0} of their links stay in the group";

    private static void ApplyMove(Dictionary<string, List<string>> lists, Dictionary<string, string> refs, List<GraphGroup> batch, string from, MoveAnswer move)
    {
        if (move.Node is null || move.To is null || !refs.TryGetValue(move.Node, out var nodeId) || batch.All(g => g.Id != move.To) || move.To == from)
        {
            return;
        }
        var source = lists.FirstOrDefault(l => l.Value.Contains(nodeId)).Key;
        if (source is null || lists[source].Count <= 2 || lists[move.To].Count >= GraphGrouper.MaxGroupSize)
        {
            return; // the cap holds and no group is emptied
        }
        lists[source].Remove(nodeId);
        lists[move.To].Add(nodeId);
    }

    private const string SystemPrompt = """
        You organise a code repository's knowledge graph into groups a person can take in at a glance (at most 30 concepts each).
        Each group was formed from the links between its concepts. For every group you are given, reply with:
        - "name": at most 6 words saying what the group is about, using the real names in it (e.g. "Order request handling").
        - "reason": one or two sentences explaining why these concepts belong together, citing the links you were given
          (who uses, inherits, calls, tests or declares whom). Never invent links or names.
        - "moves": optional; only when a concept is clearly linked more to another group in this batch than to its own:
          [{"node": "m12", "to": "g4"}]. Keep groups together otherwise.
        Reply with a JSON array only: [{"id": "g1", "name": "...", "reason": "...", "moves": []}, ...]
        For the names and reasons:
        """ + PlainLanguage.Short;

    private static (string Prompt, Dictionary<string, string> Refs) Prompt(KnowledgeGraph graph, GraphGrouping grouping, List<GraphGroup> batch, Dictionary<string, GraphNode> byId)
    {
        var refs = new Dictionary<string, string>(StringComparer.Ordinal);
        var refOf = new Dictionary<string, string>(StringComparer.Ordinal);
        var sb = new StringBuilder();
        var memberSets = batch.ToDictionary(g => g.Id, g => g.Members.ToHashSet(StringComparer.Ordinal));
        foreach (var group in batch)
        {
            sb.AppendLine($"## {group.Id} (computed name: {group.Name})");
            sb.AppendLine("Members:");
            foreach (var id in group.Members)
            {
                var r = "m" + (refs.Count + 1);
                refs[r] = id;
                refOf[id] = r;
                var node = byId[id];
                sb.AppendLine($"- {r} {node.Label} ({node.Type}{(GraphGrouper.AreaOf(node) is { } area && area != node.Label ? ", in " + area : "")})");
            }
            var inside = graph.Edges.Where(e => memberSets[group.Id].Contains(e.From) && memberSets[group.Id].Contains(e.To) && e.From != e.To)
                .OrderByDescending(e => GraphGrouper.Weight(e.Kind)).Take(24).ToList();
            if (inside.Count > 0)
            {
                sb.AppendLine("Links inside: " + string.Join("; ", inside.Select(e => $"{byId[e.From].Label} {e.Kind} {byId[e.To].Label}")));
            }
            var outside = grouping.Links.Where(l => l.From == group.Id || l.To == group.Id).Take(6)
                .Select(l => $"{(l.From == group.Id ? l.To : l.From)} ({l.Count} {l.Kind})").ToList();
            if (outside.Count > 0)
            {
                sb.AppendLine("Links to other groups: " + string.Join(", ", outside));
            }
            sb.AppendLine();
        }
        return (sb.ToString(), refs);
    }

    private sealed class GroupAnswer
    {
        public string Id { get; set; } = "";
        public string? Name { get; set; }
        public string? Reason { get; set; }
        public List<MoveAnswer>? Moves { get; set; }
    }

    private sealed class MoveAnswer
    {
        public string? Node { get; set; }
        public string? To { get; set; }
    }

    /// <summary>The JSON array in a reply (a fenced block or text around it is ignored); empty when there is none.</summary>
    private static List<GroupAnswer> Parse(string text)
    {
        var start = text.IndexOf('[');
        var end = text.LastIndexOf(']');
        if (start < 0 || end <= start)
        {
            return [];
        }
        try
        {
            return JsonSerializer.Deserialize<List<GroupAnswer>>(text[start..(end + 1)], new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? [];
        }
        catch (JsonException)
        {
            return [];
        }
    }
}
