using DocGen.Explorer.Engine.Text;
using DocGen.Analysis.Indexing;

namespace DocGen.Explorer.Engine.Search;

/// <summary>One method on a traced call path.</summary>
public sealed record FlowStep(SymbolRecord Member, int Depth, string? Via)
{
    /// <summary>"Handler.ProcessRequest → IOrderService.PlaceOrder (implemented by OrderService)".</summary>
    public string Describe() => $"{new string(' ', Depth * 2)}- {TypeOf(Member)}.{Member.Name}{(Via is null ? "" : $"  ({Via})")} — {Member.File}:{Member.StartLine}";

    private static string TypeOf(SymbolRecord member)
        => member.Container is { } c ? c[(c.LastIndexOf('.') + 1)..] : member.FullName;
}

/// <summary>
/// Follows a request through the code: from the entry methods of a type (a handler, a controller, a service), through
/// the calls each method makes — to its own helpers, and to the members of the dependencies it is given (constructor
/// and primary-constructor parameters, fields), crossing from an interface to the classes that implement it — the way
/// a reader would trace "from the handler to the response". Everything comes from the code index (each
/// member's calls and parameter types), so it works without a model.
/// </summary>
public static partial class FlowTracer
{
    private static readonly string[] EntryNames = ["Handle", "Process", "Execute", "Run", "Invoke", "Get", "Post", "Put", "Create", "Update", "Request", "Main", "Start"];

    private static readonly HashSet<string> MethodKinds = new(StringComparer.OrdinalIgnoreCase) { "method", "constructor", "localfunction", "operator" };

    public static bool IsMethod(SymbolRecord s) => MethodKinds.Contains(s.Kind);

    private static readonly HashSet<string> ObjectMembers = new(StringComparer.Ordinal) { "ToString", "Equals", "GetHashCode", "GetType", "Dispose", "GetErrorCode" };

    /// <summary>
    /// Types the question names in words: "order service" matches OrderService (or a namespace such
    /// as OrderService_1_0); other words of the question ("handler") pick the types within it.
    /// </summary>
    public static List<SymbolRecord> SeedsFromPhrase(CodeIndex code, string question, int limit = 4)
    {
        var words = TextUtil.Terms(question).Where(w => w.Length > 1 && w.All(char.IsLetterOrDigit)).ToList();
        var phrases = new List<string>();
        for (var n = 4; n >= 1; n--)
        {
            for (var i = 0; i + n <= words.Count; i++)
            {
                // One word only when it is long enough to be a name written in lower case ("orderservice").
                if (n == 1 && words[i].Length < 10)
                {
                    continue;
                }
                phrases.Add(string.Concat(words.Skip(i).Take(n).Select(Capitalise)));
            }
        }
        if (phrases.Count == 0)
        {
            return [];
        }
        var types = code.Types.Where(t => !t.IsTest && !code.IsTestProject(t.Project) && !t.Kind.Equals("enum", StringComparison.OrdinalIgnoreCase)).ToList();
        foreach (var phrase in phrases)
        {
            var matches = types.Where(t => t.FullName.Contains(phrase, StringComparison.OrdinalIgnoreCase)).ToList();
            if (matches.Count == 0)
            {
                continue;
            }
            return Rank(matches, words, phrase, question, limit);
        }
        return [];
    }

    /// <summary>
    /// The seed types of a part of the code named as the code names it — a feature folder, namespace or type name
    /// ("OrderService_2_0", "Orders.Checkout") — ranked as <see cref="SeedsFromPhrase"/> ranks them. Empty when nothing has the name.
    /// </summary>
    public static List<SymbolRecord> SeedsFromName(CodeIndex code, string name, string question, int limit = 4)
    {
        name = name.Trim().Trim('`', '/', '.');
        if (name.Length < 2)
        {
            return [];
        }
        // A folder as written ("Request.Listener") or a namespace written as folders ("Orders.Checkout" → Orders/Checkout).
        var folder = "/" + name.Replace('\\', '/') + "/";
        var nested = folder.Replace('.', '/');
        var types = code.Types.Where(t => !t.IsTest && !code.IsTestProject(t.Project) && !t.Kind.Equals("enum", StringComparison.OrdinalIgnoreCase)).ToList();
        var matches = types.Where(t => t.FullName.Contains(name, StringComparison.OrdinalIgnoreCase)
                                       || ("/" + t.File.Replace('\\', '/')).Contains(folder, StringComparison.OrdinalIgnoreCase)
                                       || ("/" + t.File.Replace('\\', '/')).Contains(nested, StringComparison.OrdinalIgnoreCase)).ToList();
        var words = TextUtil.Terms(question).Where(w => w.Length > 1 && w.All(char.IsLetterOrDigit)).ToList();
        return matches.Count == 0 ? [] : Rank(matches, words, name, question, limit);
    }

    /// <summary>Words that say what is asked for, not what it is about (they must not match a type's name: "ver" in SourceResolver).</summary>
    private static readonly HashSet<string> AskingWords = new(StringComparer.OrdinalIgnoreCase)
    {
        "version", "ver", "write", "show", "draw", "give", "make", "create", "explain", "describe", "table", "tables", "column", "columns", "program", "flow", "flows",
        "trace", "class", "classes", "method", "methods", "project", "projects", "description", "descriptions", "step", "steps", "which", "with", "that", "this",
        "from", "into", "have", "has", "what", "when", "where", "does", "diagram", "sequence", "chart", "list", "detail", "details", "please",
        "across", "different",
    };

    /// <summary>The types that best start a trace: the version the question names, the other words it uses, short concrete names.</summary>
    private static List<SymbolRecord> Rank(List<SymbolRecord> matches, List<string> words, string phrase, string question, int limit)
    {
        var rest = words.Where(w => w.Length >= 4 && !AskingWords.Contains(w) && !w.All(char.IsDigit) && !phrase.Contains(w, StringComparison.OrdinalIgnoreCase)).ToList();
        var version = VersionMark(question);
        return matches
            .Select(t => (Type: t, Score: (version is not null && t.FullName.Contains(version, StringComparison.OrdinalIgnoreCase) ? 40 : 0)
                                          + rest.Count(w => t.Name.Contains(w, StringComparison.OrdinalIgnoreCase)) * 10
                                          + (t.Name.Contains(phrase, StringComparison.OrdinalIgnoreCase) ? 5 : 0)
                                          - t.Name.Length / 10
                                          - (t.Kind.Equals("interface", StringComparison.OrdinalIgnoreCase) ? 3 : 0)))
            .OrderByDescending(x => x.Score).ThenBy(x => x.Type.FullName, StringComparer.Ordinal)
            .Select(x => x.Type).Take(limit).ToList();
    }

    /// <summary>
    /// The version a question names, as versioned folders and namespaces write it: "version 1.0", "ver 1" or "v2.1"
    /// → "_1_0", "_1_" or "_2_1". Null when it names none.
    /// </summary>
    public static string? VersionMark(string question)
    {
        // Written the way the code writes it ("OrderService_2_0").
        if (WrittenVersionRegex().Match(question) is { Success: true } written)
        {
            return $"_{written.Groups[1].Value}_{written.Groups[2].Value}";
        }
        // Else "version 1.0", "ver 1" or "v2.1"; else a bare "2.1" (it only chooses among versions of what the words name).
        var match = VersionRegex().Match(question) is { Success: true } named ? named : BareVersionRegex().Match(question);
        return !match.Success ? null : match.Groups[2].Success ? $"_{match.Groups[1].Value}_{match.Groups[2].Value}" : $"_{match.Groups[1].Value}_";
    }

    [System.Text.RegularExpressions.GeneratedRegex(@"\b(?:version|ver|v)\.?\s*(\d+)(?:[._](\d+))?\b", System.Text.RegularExpressions.RegexOptions.IgnoreCase)]
    private static partial System.Text.RegularExpressions.Regex VersionRegex();

    [System.Text.RegularExpressions.GeneratedRegex(@"(?<![\d.])(\d+)\.(\d+)(?![\d.])")]
    private static partial System.Text.RegularExpressions.Regex BareVersionRegex();

    [System.Text.RegularExpressions.GeneratedRegex(@"[A-Za-z]_(\d+)_(\d+)\b")]
    private static partial System.Text.RegularExpressions.Regex WrittenVersionRegex();

    private static string Capitalise(string word) => word.Length == 0 ? word : char.ToUpperInvariant(word[0]) + word[1..];

    /// <summary>
    /// Traces from the seed types; at most <paramref name="maxSteps"/> methods, <paramref name="maxDepth"/> calls deep.
    /// Breadth first, so every call the entry method makes is on the path before the details of any one of them; the
    /// result is in tree order (each method followed by what it calls).
    /// </summary>
    public static List<FlowStep> Trace(CodeIndex code, IEnumerable<SymbolRecord> seeds, int maxDepth = 4, int maxSteps = 40)
    {
        var nodes = new List<(FlowStep Step, int Parent)>();
        var seen = new HashSet<string>(StringComparer.Ordinal);
        var queue = new Queue<int>();
        var dependencyCache = new Dictionary<string, List<SymbolRecord>>(StringComparer.Ordinal);
        // One busy method (a service with fifteen helpers) must not use up the path before its siblings are reached.
        const int MaxCallsPerMethod = 10;
        var childCount = new Dictionary<int, int>();

        void Add(SymbolRecord member, int depth, string? via, int parent)
        {
            if (nodes.Count >= maxSteps || (parent >= 0 && childCount.GetValueOrDefault(parent) >= MaxCallsPerMethod))
            {
                return;
            }
            if (parent >= 0)
            {
                childCount[parent] = childCount.GetValueOrDefault(parent) + 1;
            }
            if (!seen.Add(member.FullName + ":" + member.File + ":" + member.StartLine))
            {
                // Already on the path (another version of the handler calls it too): listed, not traced twice.
                if (parent >= 0 && nodes[parent].Step.Member.Container != member.Container)
                {
                    nodes.Add((new FlowStep(member, depth, (via is null ? "" : via + "; ") + "traced above"), parent));
                }
                return;
            }
            nodes.Add((new FlowStep(member, depth, via), parent));
            queue.Enqueue(nodes.Count - 1);
        }

        foreach (var seed in seeds)
        {
            var type = SymbolKinds.IsType(seed.Kind) ? seed : code.Resolve(seed.Container ?? "", "type").FirstOrDefault();
            if (type is null)
            {
                continue;
            }
            foreach (var entry in IsMethod(seed) ? [seed] : EntryMethods(code, type))
            {
                Add(entry, 0, null, -1);
            }
        }

        while (queue.Count > 0 && nodes.Count < maxSteps)
        {
            var at = queue.Dequeue();
            var (step, _) = nodes[at];
            var member = step.Member;
            if (step.Depth >= maxDepth || member.Container is null)
            {
                continue;
            }
            if (!dependencyCache.TryGetValue(member.Container, out var dependencies))
            {
                dependencies = dependencyCache[member.Container] = DependenciesOf(code, member.Container, member.Namespace);
            }
            // Types the method names directly (static helpers, objects it creates): their members can be called too.
            var referenced = member.Uses.Distinct(StringComparer.Ordinal)
                .SelectMany(u => Nearest(code.Resolve(u, "type"), member.Namespace, 1))
                .Where(t => t.FullName != member.Container && !dependencies.Any(d => d.FullName == t.FullName) && !t.IsTest)
                .ToList();
            foreach (var call in member.Calls.Distinct(StringComparer.Ordinal))
            {
                foreach (var type in referenced)
                {
                    // Not constructors or object overrides: creating an exception or a result is not a step of the flow.
                    if (code.MembersOf(type.FullName).FirstOrDefault(m => m.Name == call && m.Kind == SymbolKinds.Method && !ObjectMembers.Contains(m.Name)) is { } helper)
                    {
                        Add(helper, step.Depth + 1, null, at);
                    }
                }
                // A helper of the same type.
                foreach (var own in code.MembersOf(member.Container).Where(m => m.Name == call && IsMethod(m) && m.FullName != member.FullName).Take(1))
                {
                    Add(own, step.Depth + 1, null, at);
                }
                // A member of something the type was given: the implementation nearest the caller, else the declaration.
                foreach (var dependency in dependencies)
                {
                    var declared = code.MembersOf(dependency.FullName).FirstOrDefault(m => m.Name == call && IsMethod(m));
                    var implementations = Nearest(Implementations(code, dependency)
                            .Where(impl => code.MembersOf(impl.FullName).Any(m => m.Name == call && IsMethod(m))), member.Namespace, 2)
                        .Select(impl => code.MembersOf(impl.FullName).First(m => m.Name == call && IsMethod(m)))
                        .ToList();
                    if (implementations.Count > 0)
                    {
                        foreach (var impl in implementations)
                        {
                            Add(impl, step.Depth + 1, $"implements {dependency.Name}.{call}", at);
                        }
                    }
                    else if (declared is not null)
                    {
                        Add(declared, step.Depth + 1, IsInterface(dependency) ? $"declared by {dependency.Name}" : null, at);
                    }
                }
            }
        }

        // Tree order: each method followed by what it calls.
        var children = nodes.Select((n, i) => (n.Parent, i)).Where(x => x.Parent >= 0).ToLookup(x => x.Parent, x => x.i);
        var ordered = new List<FlowStep>();
        void Walk(int i)
        {
            ordered.Add(nodes[i].Step);
            foreach (var child in children[i])
            {
                Walk(child);
            }
        }
        for (var i = 0; i < nodes.Count; i++)
        {
            if (nodes[i].Parent < 0)
            {
                Walk(i);
            }
        }
        return ordered;
    }

    /// <summary>Shared leading namespace segments: how close two pieces of code are.</summary>
    public static int Closeness(string a, string b)
    {
        var x = a.Split('.');
        var y = b.Split('.');
        var n = 0;
        while (n < x.Length && n < y.Length && string.Equals(x[n], y[n], StringComparison.Ordinal))
        {
            n++;
        }
        return n;
    }

    /// <summary>
    /// The candidates closest to <paramref name="fromNamespace"/>: with several services each having their own
    /// RequestParser, the one beside the caller is meant, not every one in the repository.
    /// </summary>
    public static List<SymbolRecord> Nearest(IEnumerable<SymbolRecord> candidates, string fromNamespace, int limit)
    {
        var scored = candidates.Select(c => (Symbol: c, Score: Closeness(c.Namespace, fromNamespace))).ToList();
        if (scored.Count == 0)
        {
            return [];
        }
        var best = scored.Max(x => x.Score);
        return scored.Where(x => x.Score == best).Select(x => x.Symbol).DistinctBy(x => x.FullName + x.File).Take(limit).ToList();
    }

    private static bool IsInterface(SymbolRecord type) => type.Kind.Equals("interface", StringComparison.OrdinalIgnoreCase);

    /// <summary>The public methods a caller would start from: entry-like names first, constructors last.</summary>
    public static List<SymbolRecord> EntryMethods(CodeIndex code, SymbolRecord type)
    {
        var methods = code.MembersOf(type.FullName).Where(IsMethod).ToList();
        var ranked = methods
            .OrderBy(m => m.Kind.Equals("constructor", StringComparison.OrdinalIgnoreCase) ? 2 : 0)
            .ThenBy(m => EntryNames.Any(n => m.Name.StartsWith(n, StringComparison.OrdinalIgnoreCase)) ? 0 : 1)
            .ThenBy(m => m.Modifiers.Contains("public") ? 0 : 1)
            .ThenBy(m => m.StartLine)
            .ToList();
        // A type whose entry points are recognisable starts there; otherwise its first few public methods.
        var entries = ranked.Where(m => EntryNames.Any(n => m.Name.StartsWith(n, StringComparison.OrdinalIgnoreCase)) && !m.Kind.Equals("constructor", StringComparison.OrdinalIgnoreCase)).Take(3).ToList();
        return entries.Count > 0 ? entries : ranked.Where(m => m.Modifiers.Contains("public")).Take(3).ToList();
    }

    /// <summary>
    /// Types a type is given or holds: constructor and primary-constructor parameters, field and property types —
    /// resolved in the code index (types outside the repository are skipped).
    /// </summary>
    public static List<SymbolRecord> DependenciesOf(CodeIndex code, string typeFullName, string? fromNamespace = null)
    {
        var names = new HashSet<string>(StringComparer.Ordinal);
        if (code.Resolve(typeFullName, "type").FirstOrDefault() is { } type)
        {
            names.UnionWith(type.ParameterTypes);
        }
        foreach (var member in code.MembersOf(typeFullName))
        {
            if (member.Kind.Equals("constructor", StringComparison.OrdinalIgnoreCase))
            {
                names.UnionWith(member.ParameterTypes);
            }
            else if (!IsMethod(member) && member.ReturnType is { Length: > 0 } returned)
            {
                names.Add(returned);
            }
        }
        var ns = fromNamespace ?? (typeFullName.Contains('.') ? typeFullName[..typeFullName.LastIndexOf('.')] : "");
        return names.Select(CodeIndex.StripGeneric).Select(n => n.TrimEnd('?'))
            .SelectMany(n => Nearest(code.Resolve(n, "type"), ns, 1))
            .Where(t => t.FullName != typeFullName)
            .DistinctBy(t => t.FullName).ToList();
    }

    /// <summary>Classes implementing (or deriving from) a type, tests and mocks left out.</summary>
    public static IEnumerable<SymbolRecord> Implementations(CodeIndex code, SymbolRecord type)
        => code.AllDerived(type.Name, 3).Select(d => d.Type)
            .Where(t => !t.IsTest && !code.IsTestProject(t.Project) && !t.Name.Contains("Mock", StringComparison.OrdinalIgnoreCase) && !t.Name.Contains("Fake", StringComparison.OrdinalIgnoreCase));
}
