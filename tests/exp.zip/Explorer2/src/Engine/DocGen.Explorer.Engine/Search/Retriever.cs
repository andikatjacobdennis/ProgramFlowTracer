using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;
using DocGen.Analysis.Indexing;

namespace DocGen.Explorer.Engine.Search;

/// <summary>What the retriever understood about a question.</summary>
public sealed class QuestionAnalysis
{
    public string Question { get; set; } = "";
    public List<string> Terms { get; set; } = [];

    /// <summary>Types and members the question names that exist in the index.</summary>
    public List<SymbolRecord> Symbols { get; set; } = [];

    /// <summary>Words that look like identifiers but are not in the index.</summary>
    public List<string> UnknownIdentifiers { get; set; } = [];

    /// <summary>overview | flow | relationship | location | configuration | diagram | howto | testing | general</summary>
    public string Intent { get; set; } = "general";

    public AnalysisDepth Depth { get; set; }

    /// <summary>Question terms that occur nowhere in the repository.</summary>
    public List<string> MissingVocabulary { get; set; } = [];

    /// <summary>For flow questions: the call path traced from the named types through their dependencies.</summary>
    public List<FlowStep> Flow { get; set; } = [];

    /// <summary>The symbols were found from the question's words ("order service"), not named exactly.</summary>
    public bool SymbolsFromPhrase { get; set; }

    /// <summary>The parts of the code the model read the question to be about (features, folders, namespaces, types).</summary>
    public List<string> Targets { get; set; } = [];

    /// <summary>The model's reading of the question, when it was read before the search.</summary>
    public Assistant.QuestionUnderstanding? Understood { get; set; }
}

public sealed class RetrievalResult
{
    public QuestionAnalysis Analysis { get; set; } = new();
    public List<Evidence> Evidence { get; set; } = [];
    public List<string> Diagnostics { get; set; } = [];
}

/// <summary>
/// Retrieval for the assistant: symbols named in the question (resolved through the code index), their graph
/// neighbours, BM25 and embedding search, fused by reciprocal rank, then diversified (at most three chunks per file).
/// </summary>
public static class Retriever
{
    public static int EvidenceCount(AnalysisDepth depth) => depth switch
    {
        AnalysisDepth.Quick => 4,
        AnalysisDepth.Balanced => 8,
        AnalysisDepth.Detailed => 12,
        AnalysisDepth.Deep => 22,
        AnalysisDepth.Expert => 34,
        _ => 8,
    };

    /// <param name="understood">The model's reading of the question, when it was read before the search.</param>
    public static QuestionAnalysis Analyze(RepositoryIndex index, string question, AnalysisDepth depth, Assistant.QuestionUnderstanding? understood = null)
    {
        var analysis = new QuestionAnalysis { Question = question, Terms = TextUtil.Terms(question).Distinct(StringComparer.Ordinal).ToList() };
        var lower = question.ToLowerInvariant();
        analysis.Intent =
            lower.Contains("mermaid") || lower.Contains("diagram") ? "diagram"
            : IsFlowQuestion(lower) ? "flow"
            : lower.Contains("architecture") || lower.Contains("overview") || lower.Contains("structure") || lower.Contains("big picture") || lower.Contains("new here") ? "overview"
            : lower.Contains("config") || lower.Contains("setting") || lower.Contains("appsettings") || lower.Contains("environment variable") ? "configuration"
            : lower.Contains("test") ? "testing"
            : lower.StartsWith("where", StringComparison.Ordinal) || lower.Contains("which file") || lower.Contains("defined") || lower.Contains("declared") ? "location"
            : lower.Contains("depend") || lower.Contains(" use ") || lower.Contains(" uses ") || lower.Contains("relat") || lower.Contains("fit together") || lower.Contains("call") || lower.Contains("responsible") ? "relationship"
            : lower.StartsWith("how do i", StringComparison.Ordinal) || lower.Contains("how to") || lower.Contains("run ") || lower.Contains("install") || lower.Contains("build") ? "howto"
            : "general";

        if (index.Code is not null)
        {
            // A plain capitalised word ("Project", "Description", "Explain") is usually English — a sentence start or a
            // column the answer should have — so it counts only when it names a type, and alone only when the question's
            // words name no feature.
            var plainWords = new List<SymbolRecord>();
            foreach (var candidate in TextUtil.CandidateIdentifiers(question))
            {
                var found = index.Code.Resolve(candidate);
                if (found.Count == 0 && candidate.EndsWith("s", StringComparison.Ordinal))
                {
                    found = index.Code.Resolve(candidate[..^1]); // "Readings" → Reading
                }
                // Prefer the type over same-named members.
                var types = found.Where(s => SymbolKinds.IsType(s.Kind)).ToList();
                if (IsPlainWord(candidate))
                {
                    plainWords.AddRange(types.Take(3));
                }
                else if (found.Count > 0)
                {
                    analysis.Symbols.AddRange((types.Count > 0 ? types : found).Take(3));
                }
                else if (char.IsUpper(candidate[0]) && candidate.Skip(1).Any(char.IsUpper))
                {
                    analysis.UnknownIdentifiers.Add(candidate);
                }
            }
            if (analysis.Symbols.Count > 0)
            {
                // Beside real names, a plain word that names a type is one too ("How does AverageCalculator use Reading?").
                analysis.Symbols.AddRange(plainWords);
            }
            else
            {
                // "order service" names OrderService (or its namespace) in words.
                analysis.Symbols = FlowTracer.SeedsFromPhrase(index.Code, question, analysis.Intent == "flow" ? 4 : 3);
                analysis.SymbolsFromPhrase = analysis.Symbols.Count > 0;
                if (analysis.Symbols.Count == 0)
                {
                    analysis.Symbols = plainWords;
                }
            }
            analysis.Symbols = analysis.Symbols.DistinctBy(s => s.FullName + ":" + s.Kind).ToList();
        }

        // Read by the model before the search: its kind of question and the parts of the code it means come first.
        if (understood is not null)
        {
            analysis.Intent = understood.Intent;
            analysis.Targets = understood.Targets.ToList();
            if (index.Code is { } code && understood.Targets.Count > 0)
            {
                var named = new List<SymbolRecord>();
                var byName = false;
                foreach (var target in understood.Targets)
                {
                    var found = code.Resolve(target);
                    var types = found.Where(s => SymbolKinds.IsType(s.Kind)).ToList();
                    if (found.Count > 0)
                    {
                        named.AddRange((types.Count > 0 ? types : found).Take(3));
                    }
                    else if (FlowTracer.SeedsFromName(code, target, question, analysis.Intent == "flow" ? 4 : 3) is { Count: > 0 } seeds)
                    {
                        named.AddRange(seeds);
                        byName = true; // a feature, folder or namespace: the trace follows its folder
                    }
                }
                if (named.Count > 0)
                {
                    analysis.Symbols = named.Concat(analysis.SymbolsFromPhrase ? [] : analysis.Symbols).DistinctBy(s => s.FullName + ":" + s.Kind).ToList();
                    analysis.SymbolsFromPhrase = byName;
                }
            }
        }

        analysis.MissingVocabulary = analysis.Terms.Where(t => t.Length > 2 && index.Keywords.DocumentFrequency(t) == 0).ToList();
        analysis.Depth = depth != AnalysisDepth.Auto ? depth
            : analysis.Intent == "flow" ? AnalysisDepth.Deep
            : analysis.Intent is "overview" or "diagram" ? AnalysisDepth.Detailed
            : question.Split(' ', StringSplitOptions.RemoveEmptyEntries).Length > 30 ? AnalysisDepth.Deep
            : analysis.Symbols.Count >= 2 || analysis.Intent == "relationship" ? AnalysisDepth.Detailed
            : AnalysisDepth.Balanced;
        return analysis;
    }

    /// <summary>One capitalised word with no other capitals, dots, underscores or digits: "Project", not "OrderService" or "order_id".</summary>
    private static bool IsPlainWord(string candidate)
        => candidate.Length > 1 && char.IsUpper(candidate[0]) && candidate.Skip(1).All(char.IsLower);

    /// <summary>"How does it flow from the handler to the response", "trace", "step by step", "what happens when"…</summary>
    public static bool IsFlowQuestion(string lower)
        => lower.Contains("flow") || lower.Contains("trace") || lower.Contains("step by step") || lower.Contains("walk through") || lower.Contains("walkthrough")
           || lower.Contains("end to end") || lower.Contains("end-to-end") || lower.Contains("call chain") || lower.Contains("call path") || lower.Contains("what happens when")
           || lower.Contains("sequence of") || lower.Contains("lifecycle") || lower.Contains("pipeline")
           || (lower.Contains(" from ") && lower.Contains(" to ") && (lower.Contains("request") || lower.Contains("response") || lower.Contains("handler") || lower.Contains("controller")));

    public static RetrievalResult Retrieve(RepositoryIndex index, string question, AnalysisDepth depth, IReadOnlyCollection<string>? scope = null, string? context = null,
        Assistant.QuestionUnderstanding? understood = null)
    {
        var analysis = Analyze(index, question, depth, understood);
        analysis.Understood = understood;
        // A follow-up that names nothing ("and what calls it?") is about what the question before named.
        if (context is not null && analysis.Symbols.Count == 0)
        {
            var before = Analyze(index, context, depth);
            if (before.Symbols.Count > 0)
            {
                analysis.Symbols.AddRange(before.Symbols);
                analysis.SymbolsFromPhrase = before.SymbolsFromPhrase;
            }
        }
        var result = new RetrievalResult { Analysis = analysis };
        var k = EvidenceCount(analysis.Depth);
        bool InScope(string chunkId) => index.ChunksById.TryGetValue(chunkId, out var c) && RepositoryIndex.InScope(c.Path, scope);

        var ranked = new List<(List<string> Ids, double Weight, string Method)>();

        // 0. Flow questions: trace the calls from the named types through their dependencies and implementations, and
        //    give every method on the path as evidence, in order.
        var flowIds = new HashSet<string>(StringComparer.Ordinal);
        if (analysis.Intent == "flow" && index.Code is { } code && analysis.Symbols.Count > 0)
        {
            var (maxDepth, maxSteps) = analysis.Depth switch
            {
                AnalysisDepth.Quick => (2, 10),
                AnalysisDepth.Balanced => (3, 20),
                AnalysisDepth.Detailed => (4, 30),
                AnalysisDepth.Deep => (5, 40),
                _ => (6, 60),
            };
            analysis.Flow = FlowTracer.Trace(code, analysis.Symbols, maxDepth, maxSteps);
            var ordered = new List<string>();
            foreach (var step in analysis.Flow)
            {
                var member = step.Member;
                var chunks = index.ChunksByPath.GetValueOrDefault(member.File)?
                    .Where(c => c.Symbol == member.FullName || (c.StartLine <= member.EndLine && c.EndLine >= member.StartLine && c.Kind == "code"))
                    .OrderBy(c => c.Symbol == member.FullName ? 0 : 1).ThenBy(c => c.StartLine).Take(2) ?? [];
                ordered.AddRange(chunks.Select(c => c.Id).Where(InScope));
            }
            ordered = ordered.Distinct().ToList();
            flowIds.UnionWith(ordered);
            if (ordered.Count > 0)
            {
                ranked.Add((ordered, 2.6, "flow"));
                k = Math.Max(k, Math.Min(ordered.Count + k / 2, k * 2));
                var types = analysis.Flow.Select(s => s.Member.Container).Distinct().Count();
                result.Diagnostics.Add($"Traced the flow through {TextUtil.Plural(analysis.Flow.Count, "method")} in {TextUtil.Plural(types, "type")}, following calls into dependencies and their implementations.");
            }
        }

        // 1. Named symbols: their own chunks first.
        var symbolChunks = new List<string>();
        var neighbourChunks = new List<string>();
        foreach (var symbol in analysis.Symbols)
        {
            var own = index.Chunks.Where(c => c.Symbol is not null && (c.Symbol == symbol.FullName || c.Symbol.StartsWith(symbol.FullName + ".", StringComparison.Ordinal)))
                .OrderBy(c => c.StartLine).Select(c => c.Id).ToList();
            if (own.Count == 0)
            {
                own = index.ChunksByPath.GetValueOrDefault(symbol.File)?.Where(c => c.StartLine <= symbol.EndLine && c.EndLine >= symbol.StartLine).Select(c => c.Id).ToList() ?? [];
            }
            symbolChunks.AddRange(own.Where(InScope));

            // 2. Graph neighbours of named types (what they use, what uses them, tests of them).
            var nodeId = "type:" + symbol.FullName;
            foreach (var neighbour in index.Graph.Neighbours(nodeId).Take(12))
            {
                var node = index.Graph.Find(neighbour);
                if (node?.Key is null || !ConceptTypes.IsType(node.Type))
                {
                    continue;
                }
                var chunk = index.Chunks.FirstOrDefault(c => c.Symbol == node.Key) ?? index.Chunks.FirstOrDefault(c => c.Symbol?.StartsWith(node.Key + ".", StringComparison.Ordinal) == true);
                if (chunk is not null && InScope(chunk.Id))
                {
                    neighbourChunks.Add(chunk.Id);
                }
            }
        }
        if (symbolChunks.Count > 0)
        {
            ranked.Add((symbolChunks.Distinct().ToList(), 2.0, "symbol"));
            result.Diagnostics.Add((analysis.SymbolsFromPhrase ? "Matched the question's words to " : "Resolved ") +
                                   $"{TextUtil.JoinNatural(analysis.Symbols.Select(s => $"{s.Name} ({s.Kind})"))} in the code index.");
        }
        if (neighbourChunks.Count > 0)
        {
            ranked.Add((neighbourChunks.Distinct().ToList(), 0.9, "graph"));
        }

        // 3. Keyword and semantic search over the question (plus conversation context for follow-ups).
        var searchText = context is null ? question : question + " " + context;
        // Bulk data (test fixtures, exports) only when nothing better matches: it is evidence of shape, not behaviour.
        bool NotData(string id) => index.ChunksById.TryGetValue(id, out var c) && c.Kind != "data";
        var keyword = index.Keywords.Search(searchText, 60, InScope).Select(r => r.ChunkId).ToList();
        ranked.Add((keyword.Where(NotData).Take(40).ToList(), 1.0, "keyword"));
        var vector = new HashingEmbedder().Embed(searchText);
        var semantic = index.Vectors.Nearest(vector, 60, InScope).Where(r => r.Score > 0.05).Select(r => r.ChunkId).ToList();
        ranked.Add((semantic.Where(NotData).Take(40).ToList(), 0.7, "semantic"));
        ranked.Add((keyword.Concat(semantic).Where(id => !NotData(id)).Distinct().Take(10).ToList(), 0.25, "data"));

        // 4. Intent-specific material.
        if (analysis.Intent is "overview" or "howto")
        {
            var docs = index.Chunks.Where(c => c.Kind == "doc" && InScope(c.Id))
                .OrderBy(c => c.Path.Contains("README", StringComparison.OrdinalIgnoreCase) ? 0 : 1).ThenBy(c => c.Path.Count(ch => ch == '/')).ThenBy(c => c.StartLine)
                .Select(c => c.Id).Take(10).ToList();
            ranked.Add((docs, analysis.Intent == "howto" ? 1.2 : 1.0, "documentation"));
            var projects = index.Chunks.Where(c => c.Path.EndsWith("proj", StringComparison.OrdinalIgnoreCase) && InScope(c.Id)).Select(c => c.Id).Take(6).ToList();
            ranked.Add((projects, 0.6, "projects"));
        }
        if (analysis.Intent == "configuration")
        {
            var config = index.Chunks.Where(c => c.Kind == "config" && InScope(c.Id) && (c.Path.Contains("appsettings", StringComparison.OrdinalIgnoreCase) || c.Path.EndsWith(".json", StringComparison.OrdinalIgnoreCase) || c.Path.EndsWith(".yml", StringComparison.OrdinalIgnoreCase) || c.Path.EndsWith(".yaml", StringComparison.OrdinalIgnoreCase) || c.Path.EndsWith(".config", StringComparison.OrdinalIgnoreCase)))
                .Select(c => c.Id).Take(10).ToList();
            ranked.Add((config, 1.3, "configuration"));
        }
        if (analysis.Intent == "testing")
        {
            var tests = index.Chunks.Where(c => InScope(c.Id) && (c.Path.Contains("test", StringComparison.OrdinalIgnoreCase))).Select(c => c.Id).Take(12).ToList();
            ranked.Add((tests, 1.0, "tests"));
        }

        // Reciprocal-rank fusion.
        var scores = new Dictionary<string, (double Score, List<string> Methods)>(StringComparer.Ordinal);
        foreach (var (ids, weight, method) in ranked)
        {
            for (var rank = 0; rank < ids.Count; rank++)
            {
                var add = weight / (60 + rank + 1);
                if (scores.TryGetValue(ids[rank], out var existing))
                {
                    existing.Methods.Add(method);
                    scores[ids[rank]] = (existing.Score + add, existing.Methods);
                }
                else
                {
                    scores[ids[rank]] = (add, [method]);
                }
            }
        }

        // A question none of whose words occur in the repository, naming no known symbol, has no evidence: the semantic
        // ranking would otherwise return hash collisions.
        var meaningful = analysis.Terms.Where(t => t.Length > 2).ToList();
        if (analysis.Symbols.Count == 0 && meaningful.Count > 0 && meaningful.All(t => analysis.MissingVocabulary.Contains(t)) && analysis.Intent is "general" or "location" or "relationship")
        {
            scores.Clear();
        }

        // Diversify: at most three chunks per file (six on a traced flow), and never two overlapping chunks.
        var perFile = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        var chosen = new List<Evidence>();
        foreach (var (id, value) in scores.OrderByDescending(s => s.Value.Score).ThenBy(s => s.Key, StringComparer.Ordinal))
        {
            var chunk = index.ChunksById[id];
            if (perFile.GetValueOrDefault(chunk.Path) >= (flowIds.Contains(id) ? 6 : 3))
            {
                continue;
            }
            if (chosen.Any(e => e.Chunk.Path == chunk.Path && e.Chunk.StartLine <= chunk.EndLine && chunk.StartLine <= e.Chunk.EndLine))
            {
                continue;
            }
            perFile[chunk.Path] = perFile.GetValueOrDefault(chunk.Path) + 1;
            chosen.Add(new Evidence { Chunk = chunk, Score = Math.Round(value.Score * 1000, 3), Methods = value.Methods.Distinct().ToList() });
            if (chosen.Count >= k)
            {
                break;
            }
        }
        result.Evidence = chosen;

        if (scope is { Count: > 0 })
        {
            result.Diagnostics.Add($"Limited to {TextUtil.Plural(scope.Count, "selected item")}: {TextUtil.Truncate(string.Join(", ", scope), 120)}.");
        }
        if (analysis.UnknownIdentifiers.Count > 0)
        {
            result.Diagnostics.Add($"Not found in the code index: {string.Join(", ", analysis.UnknownIdentifiers)}.");
        }
        if (analysis.MissingVocabulary.Count > 0 && analysis.MissingVocabulary.Count == analysis.Terms.Count(t => t.Length > 2))
        {
            result.Diagnostics.Add("None of the question's words occur in the repository.");
        }
        result.Diagnostics.Add($"Depth {analysis.Depth} ({analysis.Intent} question): {TextUtil.Plural(chosen.Count, "piece")} of evidence from {TextUtil.Plural(chosen.Select(e => e.Chunk.Path).Distinct().Count(), "file")}.");
        return result;
    }
}
