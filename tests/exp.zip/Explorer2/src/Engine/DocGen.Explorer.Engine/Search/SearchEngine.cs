using DocGen.Explorer.Engine.Documentation;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;
using DocGen.Analysis.Indexing;

namespace DocGen.Explorer.Engine.Search;

/// <summary>
/// The header search: documentation headings, files, symbols and text, matched six ways — exact, file, heading, symbol,
/// keyword (BM25) and semantic (hashing embeddings) — and fused with reciprocal-rank fusion. Each hit says how it matched.
/// </summary>
public static class SearchEngine
{
    private const double RrfK = 60;

    private static readonly Dictionary<string, double> MethodWeights = new(StringComparer.Ordinal)
    {
        ["symbol"] = 1.3, ["heading"] = 1.1, ["file"] = 1.1, ["exact"] = 1.0, ["keyword"] = 0.8, ["semantic"] = 0.55,
    };

    public static List<SearchHit> Search(RepositoryIndex index, string query, int limit = 40, IReadOnlyCollection<string>? scope = null)
    {
        query = query.Trim();
        if (query.Length < 2)
        {
            return [];
        }
        var lists = new List<List<SearchHit>>
        {
            Symbols(index, query, scope),
            FilesMatching(index, query, scope),
            Headings(index, query),
            Exact(index, query, scope),
            Keyword(index, query, scope),
            Semantic(index, query, scope),
        };

        var fused = new Dictionary<string, (SearchHit Hit, double Score)>(StringComparer.OrdinalIgnoreCase);
        foreach (var list in lists)
        {
            for (var rank = 0; rank < list.Count; rank++)
            {
                var hit = list[rank];
                var key = hit.PageId is not null ? "page:" + hit.PageId + hit.Line : $"{hit.Path}:{hit.Line}";
                var score = MethodWeights.GetValueOrDefault(hit.Method, 0.5) / (RrfK + rank + 1);
                if (fused.TryGetValue(key, out var existing))
                {
                    // Keep the most specific description of the hit; add the evidence.
                    var better = Priority(hit.Method) < Priority(existing.Hit.Method) ? hit : existing.Hit;
                    fused[key] = (better, existing.Score + score);
                }
                else
                {
                    fused[key] = (hit, score);
                }
            }
        }
        // A hit whose name is exactly the query (a type, a file, a page) leads.
        foreach (var key in fused.Keys.ToList())
        {
            var (hit, score) = fused[key];
            var name = hit.Method == "file" ? Path.GetFileNameWithoutExtension(hit.Title) : hit.Title;
            if (string.Equals(hit.Title, query, StringComparison.OrdinalIgnoreCase) || string.Equals(name, query, StringComparison.OrdinalIgnoreCase))
            {
                fused[key] = (hit, score + 1.0 / RrfK);
            }
        }
        return fused.Values
            .OrderByDescending(v => v.Score).ThenBy(v => v.Hit.Path, StringComparer.OrdinalIgnoreCase).ThenBy(v => v.Hit.Line)
            .Take(limit)
            .Select(v => { v.Hit.Score = Math.Round(v.Score * 1000, 3); return v.Hit; })
            .ToList();
    }

    private static int Priority(string method) => method switch
    {
        "symbol" => 0,
        "heading" => 1,
        "file" => 2,
        "exact" => 3,
        "keyword" => 4,
        _ => 5,
    };

    internal static List<SearchHit> Symbols(RepositoryIndex index, string query, IReadOnlyCollection<string>? scope)
    {
        if (index.Code is null)
        {
            return [];
        }
        return index.Code.Search(query, null, null, includeTests: true, limit: 25)
            .Where(r => RepositoryIndex.InScope(r.Symbol.File, scope))
            .Select(r => new SearchHit
            {
                Kind = SymbolKinds.IsType(r.Symbol.Kind) ? CodeIndexHelpers.ConceptType(r.Symbol) : CodeIndexHelpers.KindLabel(r.Symbol.Kind),
                Title = SymbolKinds.IsType(r.Symbol.Kind) || r.Symbol.Container is null ? r.Symbol.Name : $"{CodeIndexHelpers.ShortName(r.Symbol.Container).Split('.')[^1]}.{r.Symbol.Name}",
                Path = r.Symbol.File,
                Line = r.Symbol.StartLine,
                Method = "symbol",
                Snippet = r.Symbol.Signature,
            }).ToList();
    }

    internal static List<SearchHit> FilesMatching(RepositoryIndex index, string query, IReadOnlyCollection<string>? scope)
    {
        var q = query.Replace('\\', '/');
        return index.Files
            .Where(f => RepositoryIndex.InScope(f.Path, scope))
            .Select(f =>
            {
                var name = f.Name;
                var score = name.Equals(q, StringComparison.OrdinalIgnoreCase) ? 100
                    : Path.GetFileNameWithoutExtension(name).Equals(q, StringComparison.OrdinalIgnoreCase) ? 95
                    : name.StartsWith(q, StringComparison.OrdinalIgnoreCase) ? 80
                    : name.Contains(q, StringComparison.OrdinalIgnoreCase) ? 60
                    : f.Path.Contains(q, StringComparison.OrdinalIgnoreCase) ? 40 : 0;
                return (File: f, Score: score);
            })
            .Where(x => x.Score > 0)
            .OrderByDescending(x => x.Score).ThenBy(x => x.File.Path.Length).ThenBy(x => x.File.Path, StringComparer.OrdinalIgnoreCase)
            .Take(15)
            .Select(x => new SearchHit
            {
                Kind = x.File.Kind == FileKind.Documentation ? "Documentation file" : "File",
                Title = x.File.Name,
                Path = x.File.Path,
                Line = 0,
                Method = "file",
                Snippet = $"{x.File.Language} · {TextUtil.Plural(x.File.Lines, "line")}",
            }).ToList();
    }

    internal static List<SearchHit> Headings(RepositoryIndex index, string query)
    {
        var hits = new List<SearchHit>();
        foreach (var page in index.Pages)
        {
            if (page.Title.Contains(query, StringComparison.OrdinalIgnoreCase))
            {
                hits.Add(new SearchHit { Kind = "Documentation", Title = page.Title, Path = page.SourcePath ?? page.TreePath, Line = 0, Method = "heading", PageId = page.Id });
            }
            foreach (var heading in page.Headings.Where(h => h.Text.Contains(query, StringComparison.OrdinalIgnoreCase)))
            {
                hits.Add(new SearchHit
                {
                    Kind = "Section",
                    Title = heading.Text,
                    Path = page.SourcePath ?? page.TreePath,
                    Line = heading.Line,
                    Method = "heading",
                    PageId = page.Id,
                    Snippet = page.Title,
                });
            }
        }
        return hits.OrderBy(h => h.Title.Length).Take(15).ToList();
    }

    internal static List<SearchHit> Exact(RepositoryIndex index, string query, IReadOnlyCollection<string>? scope)
    {
        var hits = new List<SearchHit>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var chunk in index.Chunks)
        {
            if (!RepositoryIndex.InScope(chunk.Path, scope) || chunk.Text.IndexOf(query, StringComparison.OrdinalIgnoreCase) < 0)
            {
                continue;
            }
            var lines = TextUtil.SplitLines(chunk.Text);
            for (var i = 0; i < lines.Length; i++)
            {
                if (lines[i].Contains(query, StringComparison.OrdinalIgnoreCase))
                {
                    var line = chunk.StartLine + i;
                    if (seen.Add($"{chunk.Path}:{line}"))
                    {
                        hits.Add(new SearchHit
                        {
                            Kind = "Line",
                            Title = Path.GetFileName(chunk.Path),
                            Path = chunk.Path,
                            Line = line,
                            Method = "exact",
                            Snippet = TextUtil.Truncate(lines[i].Trim(), 160),
                        });
                    }
                }
            }
            if (hits.Count >= 60)
            {
                break;
            }
        }
        // Whole-word and case-exact matches first.
        return hits.OrderByDescending(h => h.Snippet?.Contains(query, StringComparison.Ordinal) == true).ThenBy(h => h.Path, StringComparer.OrdinalIgnoreCase).ThenBy(h => h.Line).Take(30).ToList();
    }

    internal static List<SearchHit> Keyword(RepositoryIndex index, string query, IReadOnlyCollection<string>? scope)
        => index.Keywords.Search(query, 12, id => index.ChunksById.TryGetValue(id, out var c) && RepositoryIndex.InScope(c.Path, scope))
            .Select(r => ChunkHit(index.ChunksById[r.ChunkId], "keyword")).ToList();

    internal static List<SearchHit> Semantic(RepositoryIndex index, string query, IReadOnlyCollection<string>? scope)
    {
        var vector = new HashingEmbedder().Embed(query);
        return index.Vectors.Nearest(vector, 10, id => index.ChunksById.TryGetValue(id, out var c) && RepositoryIndex.InScope(c.Path, scope))
            .Where(r => r.Score >= 0.12)
            .Select(r => ChunkHit(index.ChunksById[r.ChunkId], "semantic")).ToList();
    }

    private static SearchHit ChunkHit(Chunk chunk, string method) => new()
    {
        Kind = chunk.Kind switch { "doc" => "Documentation", "config" => "Configuration", "code" => "Code", _ => "Text" },
        Title = chunk.Title,
        Path = chunk.Path,
        Line = chunk.StartLine,
        Method = method,
        Snippet = TextUtil.Truncate(TextUtil.SplitLines(chunk.Text).Select(l => l.Trim()).FirstOrDefault(l => l.Length > 3) ?? "", 160),
    };
}
