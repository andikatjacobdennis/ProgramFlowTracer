using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;

namespace DocGen.Explorer.Engine.Search;

/// <summary>Okapi BM25 over chunks (k1 = 1.2, b = 0.75). Titles and symbols count double.</summary>
public sealed class KeywordIndex
{
    private const double K1 = 1.2;
    private const double B = 0.75;

    private readonly Dictionary<string, List<(int Doc, int Tf)>> _postings = new(StringComparer.Ordinal);
    private readonly List<string> _ids = [];
    private readonly List<int> _lengths = [];
    private double _averageLength;

    public int Count => _ids.Count;

    /// <summary>Every indexed term (lower case).</summary>
    public IEnumerable<string> Terms => _postings.Keys;

    public static KeywordIndex Build(IEnumerable<Chunk> chunks)
    {
        var index = new KeywordIndex();
        foreach (var chunk in chunks)
        {
            index.Add(chunk);
        }
        index._averageLength = index._lengths.Count == 0 ? 0 : index._lengths.Average();
        return index;
    }

    private void Add(Chunk chunk)
    {
        var doc = _ids.Count;
        _ids.Add(chunk.Id);
        var terms = TextUtil.Terms(chunk.Text);
        var heading = TextUtil.Terms($"{chunk.Title} {chunk.Symbol} {System.IO.Path.GetFileNameWithoutExtension(chunk.Path)}");
        terms.AddRange(heading);
        terms.AddRange(heading);
        _lengths.Add(terms.Count);
        foreach (var group in terms.GroupBy(t => t, StringComparer.Ordinal))
        {
            if (!_postings.TryGetValue(group.Key, out var list))
            {
                _postings[group.Key] = list = [];
            }
            list.Add((doc, group.Count()));
        }
    }

    public List<(string ChunkId, double Score)> Search(string query, int k, Func<string, bool>? filter = null)
    {
        var scores = new Dictionary<int, double>();
        var n = _ids.Count;
        if (n == 0)
        {
            return [];
        }
        foreach (var term in TextUtil.Terms(query).Distinct(StringComparer.Ordinal))
        {
            if (!_postings.TryGetValue(term, out var postings))
            {
                continue;
            }
            var idf = Math.Log(1 + (n - postings.Count + 0.5) / (postings.Count + 0.5));
            foreach (var (doc, tf) in postings)
            {
                var length = _lengths[doc];
                var score = idf * tf * (K1 + 1) / (tf + K1 * (1 - B + B * length / Math.Max(1, _averageLength)));
                scores[doc] = scores.TryGetValue(doc, out var s) ? s + score : score;
            }
        }
        return scores
            .Where(s => filter is null || filter(_ids[s.Key]))
            .OrderByDescending(s => s.Value).ThenBy(s => s.Key)
            .Take(k)
            .Select(s => (_ids[s.Key], s.Value))
            .ToList();
    }

    /// <summary>How many chunks contain the term (used to judge whether a question's vocabulary exists at all).</summary>
    public int DocumentFrequency(string term) => _postings.TryGetValue(term.ToLowerInvariant(), out var list) ? list.Count : 0;
}
