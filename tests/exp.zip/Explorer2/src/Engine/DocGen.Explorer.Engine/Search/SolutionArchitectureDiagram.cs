using System.Text;
using System.Text.RegularExpressions;
using DocGen.Analysis.Indexing;

namespace DocGen.Explorer.Engine.Search;

/// <summary>
/// The architecture diagram of a C# solution, as an enterprise architecture review draws it: the projects (tests left
/// out) in layers — hosts, composition, request gateway, domain services, persistence and infrastructure, domain models
/// and shared types, external system integrations, cross-cutting components — joined by their project references, top
/// to bottom, laid out by ELK. A project that depends on most of the integrations gets one arrow to a hub standing for
/// all of them. Everything comes from the solution's own project files; a project is placed in a layer by its name and
/// role (an executable is a host).
/// </summary>
public static partial class SolutionArchitectureDiagram
{
    /// <summary>A layer of the diagram: its subgraph id and title, the class of its projects, and the group's style.</summary>
    private sealed record Layer(string Id, string Title, string Class, string Style);

    private static readonly Layer Hosts = new("Hosts", "APPLICATION HOSTS", "host", "fill:#F5F8FC,stroke:#CBD5E1,stroke-width:1px");
    private static readonly Layer Composition = new("Composition", "COMPOSITION ROOT", "composition", "fill:#F5F8FC,stroke:#CBD5E1,stroke-width:1px");
    private static readonly Layer Gateway = new("Gateway", "REQUEST GATEWAY", "service", "fill:#F5FAF8,stroke:#C6DDD5,stroke-width:1px");
    private static readonly Layer Domains = new("Domains", "DOMAIN SERVICES", "service", "fill:#F5FAF8,stroke:#C6DDD5,stroke-width:1px");
    private static readonly Layer Persistence = new("Persistence", "PERSISTENCE AND INFRASTRUCTURE", "persistence", "fill:#F8FAFC,stroke:#CBD5E1,stroke-width:1px");
    private static readonly Layer Models = new("Models", "DOMAIN MODELS AND SHARED TYPES", "model", "fill:#FAF8FD,stroke:#D9D0E8,stroke-width:1px");
    private static readonly Layer Integrations = new("Integrations", "EXTERNAL SYSTEM INTEGRATIONS", "proxy", "fill:#FFFBF5,stroke:#E5D3B5,stroke-width:1px");
    private static readonly Layer Shared = new("Shared", "CROSS-CUTTING COMPONENTS", "shared", "fill:#F8FAFC,stroke:#D5DCE5,stroke-width:1px");

    private static readonly Layer[] Order = [Hosts, Composition, Gateway, Domains, Persistence, Models, Integrations, Shared];

    /// <summary>The node that stands for all the integrations at once.</summary>
    private const string HubId = "Integrations_All";

    /// <summary>
    /// The configuration in the diagram's front matter: the ELK layout engine (layered, orthogonal "step" edges) and the
    /// theme. ELK is what keeps the layers in order and the arrows from crossing through the groups.
    /// </summary>
    private const string FrontMatter = """
        ---
        config:
          layout: elk
          theme: base
          flowchart:
            curve: step
            nodeSpacing: 45
            rankSpacing: 85
            padding: 20
          elk:
            mergeEdges: false
            nodePlacementStrategy: NETWORK_SIMPLEX
          themeVariables:
            fontFamily: Arial, sans-serif
            fontSize: 14px
            lineColor: "#64748B"
            primaryTextColor: "#1E293B"
            clusterBkg: "#F8FAFC"
            clusterBorder: "#CBD5E1"
        ---
        """;

    private const string ClassDefinitions = """
            classDef host fill:#17324D,stroke:#17324D,color:#FFFFFF,stroke-width:1.5px
            classDef composition fill:#E8EFF8,stroke:#597899,color:#17324D,stroke-width:1.5px
            classDef service fill:#E8F4F1,stroke:#52877B,color:#214E43,stroke-width:1.5px
            classDef persistence fill:#EDF1F6,stroke:#718198,color:#29384B,stroke-width:1.5px
            classDef model fill:#F0EDF7,stroke:#8A78A8,color:#4D3B65,stroke-width:1.5px
            classDef proxy fill:#FFF4E5,stroke:#B68C50,color:#6B4E24,stroke-width:1.5px
            classDef proxyGroup fill:#F6E7CD,stroke:#B68C50,color:#6B4E24,stroke-width:1.5px,stroke-dasharray:4 3
            classDef shared fill:#F1F4F8,stroke:#8A97A8,color:#354253,stroke-width:1.5px
        """;

    /// <summary>Whether a question asks for an architecture diagram of the whole repository (not of one class or flow).</summary>
    /// <param name="repository">The repository's name: "the architecture of shop-api" means the whole solution.</param>
    public static bool Asks(string question, string? repository = null)
    {
        var q = question.ToLowerInvariant();
        if (Draw().IsMatch(q) && Whole().IsMatch(q))
        {
            return true;
        }
        // "Write / explain / show the architecture of <the repository>": the whole solution, so its diagram too.
        if (!q.Contains("architecture", StringComparison.Ordinal))
        {
            return false;
        }
        var names = (repository ?? "").ToLowerInvariant().Split(['-', '_', '.', ' '], StringSplitOptions.RemoveEmptyEntries).Where(n => n.Length >= 3).Append((repository ?? "").ToLowerInvariant());
        return names.Any(n => n.Length >= 3 && q.Contains(n, StringComparison.Ordinal)) || WholeOnly().IsMatch(q);
    }

    /// <summary>
    /// The answer with the generated diagram in it, whatever the model drew: its first Mermaid block is replaced by the
    /// generated one (models drop and rename projects however they are asked), or the diagram is put after the first paragraph.
    /// </summary>
    public static string WithDiagram(string answer, string diagram)
    {
        var block = MermaidBlock().Match(diagram);
        if (!block.Success)
        {
            return answer;
        }
        var existing = MermaidBlock().Match(answer);
        if (existing.Success)
        {
            return answer[..existing.Index] + block.Value + answer[(existing.Index + existing.Length)..];
        }
        var cut = answer.IndexOf("\n\n", StringComparison.Ordinal);
        return cut < 0 ? answer + "\n\n" + diagram : answer[..cut] + "\n\n" + diagram + answer[cut..];
    }

    /// <summary>The diagram (Markdown: one line on how to read it, then the Mermaid block), or null when there are not two projects.</summary>
    public static string? Build(CodeIndex code)
    {
        var projects = code.Manifest.Projects.Where(p => !IsTest(p)).ToList();
        if (projects.Count < 2)
        {
            return null;
        }
        var names = projects.Select(p => p.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var references = projects.ToDictionary(p => p.Name,
            p => code.ProjectReferencesOf(p.Name).Where(r => names.Contains(r) && !r.Equals(p.Name, StringComparison.OrdinalIgnoreCase)).Distinct(StringComparer.OrdinalIgnoreCase).ToList(),
            StringComparer.OrdinalIgnoreCase);
        var referencedBy = projects.ToDictionary(p => p.Name, p => projects.Count(o => references[o.Name].Contains(p.Name, StringComparer.OrdinalIgnoreCase)), StringComparer.OrdinalIgnoreCase);
        var layers = projects.ToDictionary(p => p.Name, p => LayerOf(p, references[p.Name].Count, referencedBy[p.Name], projects.Count), StringComparer.OrdinalIgnoreCase);

        // The arrows drawn: a reference that another path already implies (A → C when A → B → C) is left out, as
        // references flow through in SDK-style projects; it would only add a line to follow.
        var drawn = Reduce(references);

        // Short, unique node ids from the names (Mermaid ids are letters, digits and underscores).
        var ids = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var p in projects)
        {
            var id = NonWord().Replace(p.Name, "_").Trim('_');
            id = id.Length == 0 || char.IsDigit(id[0]) ? "P_" + id : id;
            var unique = id;
            for (var n = 2; ids.ContainsValue(unique) || unique.Equals(HubId, StringComparison.OrdinalIgnoreCase)
                            || Order.Any(l => l.Id.Equals(unique, StringComparison.OrdinalIgnoreCase)); n++)
            {
                unique = id + n;
            }
            ids[p.Name] = unique;
        }

        // A project that depends on most of the integrations points once at a hub that stands for all of them.
        var integrations = projects.Where(p => layers[p.Name] == Integrations).OrderBy(p => p.Name, StringComparer.OrdinalIgnoreCase).Select(p => p.Name).ToList();
        bool UsesTheGroup(string project)
        {
            var count = drawn[project].Count(integrations.Contains);
            return integrations.Count >= 3 && count >= 2 && count * 2 >= integrations.Count && !integrations.Contains(project, StringComparer.OrdinalIgnoreCase);
        }
        var hub = projects.Any(p => UsesTheGroup(p.Name));
        // What every integration depends on is drawn once, from the group.
        var common = integrations.Count >= 3
            ? integrations.Skip(1).Aggregate(drawn[integrations[0]].ToHashSet(StringComparer.OrdinalIgnoreCase), (all, i) => { all.IntersectWith(drawn[i]); return all; })
            : new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var kind = integrations.All(i => i.StartsWith("Proxy", StringComparison.OrdinalIgnoreCase)) ? "Proxy" : "Integration";

        var sb = new StringBuilder(FrontMatter.Replace("\r", "", StringComparison.Ordinal).Trim()).Append("\nflowchart TB\n");
        var links = 0;
        foreach (var layer in Order)
        {
            var members = projects.Where(p => layers[p.Name] == layer).OrderBy(p => -referencedBy[p.Name]).ThenBy(p => p.Name, StringComparer.OrdinalIgnoreCase).ToList();
            if (members.Count == 0)
            {
                continue;
            }
            if (layer == Integrations)
            {
                members = [.. members.OrderBy(p => p.Name, StringComparer.OrdinalIgnoreCase)];
            }
            sb.Append($"    subgraph {layer.Id}[\"{layer.Title}\"]\n");
            if (layer == Integrations && hub)
            {
                sb.Append($"        {HubId}[\"{kind} Dependencies — All {Count(integrations.Count)}\"]\n");
            }
            foreach (var p in members)
            {
                sb.Append($"        {ids[p.Name]}[\"{p.Name.Replace("\"", "'", StringComparison.Ordinal)}\"]\n");
            }
            if (layer == Integrations && hub)
            {
                // The hub fans out to each integration (dashed): these are the first links, styled by number below.
                sb.Append('\n');
                foreach (var p in members)
                {
                    sb.Append($"        {HubId} --> {ids[p.Name]}\n");
                    links++;
                }
            }
            sb.Append("    end\n\n");
        }

        foreach (var p in projects.OrderBy(p => Array.IndexOf(Order, layers[p.Name])).ThenBy(p => -referencedBy[p.Name]).ThenBy(p => p.Name, StringComparer.OrdinalIgnoreCase))
        {
            var group = hub && UsesTheGroup(p.Name);
            var integration = integrations.Contains(p.Name, StringComparer.OrdinalIgnoreCase);
            var wrote = false;
            foreach (var target in drawn[p.Name].Where(t => !(integration && common.Contains(t))).OrderBy(t => Array.IndexOf(Order, layers[t])).ThenBy(t => -referencedBy[t]).ThenBy(t => t, StringComparer.OrdinalIgnoreCase))
            {
                if (group && integrations.Contains(target, StringComparer.OrdinalIgnoreCase))
                {
                    continue;
                }
                sb.Append($"    {ids[p.Name]} --> {ids[target]}\n");
                wrote = true;
            }
            if (group)
            {
                sb.Append($"    {ids[p.Name]} --> {HubId}\n");
                wrote = true;
            }
            if (wrote)
            {
                sb.Append('\n');
            }
            // After the last integration: what all of them depend on, once from the group.
            if (integration && p.Name.Equals(integrations[^1], StringComparison.OrdinalIgnoreCase) && common.Count > 0)
            {
                foreach (var target in common.OrderBy(t => Array.IndexOf(Order, layers[t])).ThenBy(t => t, StringComparer.OrdinalIgnoreCase))
                {
                    sb.Append($"    {Integrations.Id} --> {ids[target]}\n");
                }
                sb.Append('\n');
            }
        }

        sb.Append(ClassDefinitions.Replace("\r", "", StringComparison.Ordinal).TrimEnd()).Append("\n\n");
        foreach (var layer in Order.DistinctBy(l => l.Class))
        {
            var members = projects.Where(p => layers[p.Name].Class == layer.Class).OrderBy(p => Array.IndexOf(Order, layers[p.Name])).Select(p => ids[p.Name]).ToList();
            if (members.Count > 0)
            {
                sb.Append($"    class {string.Join(",", members)} {layer.Class}\n");
            }
        }
        if (hub)
        {
            sb.Append($"    class {HubId} proxyGroup\n");
        }
        sb.Append('\n');
        foreach (var layer in Order.Where(l => projects.Any(p => layers[p.Name] == l)))
        {
            sb.Append($"    style {layer.Id} {layer.Style}\n");
        }
        sb.Append("\n    linkStyle default stroke:#64748B,stroke-width:1.3px\n");
        if (links > 0)
        {
            sb.Append($"    linkStyle {string.Join(",", Enumerable.Range(0, links))} stroke:#B68C50,stroke-width:1px,stroke-dasharray:4 3\n");
        }

        var reading = "Arrows indicate dependencies (project references); a reference already implied through another arrow is not drawn again"
                      + (hub ? $"; an arrow to **{kind} Dependencies — All {Count(integrations.Count)}** stands for a dependency on every project in **External System Integrations** (the dashed arrows)" : "")
                      + (common.Count > 0 ? "; an arrow from the **External System Integrations** group is a dependency of every project in it" : "")
                      + ".";
        return $"{reading}\n\n```mermaid\n{sb.ToString().TrimEnd()}\n```";
    }

    /// <summary>
    /// The transitive reduction of the references: each project keeps only the references that no other of its
    /// references already reaches.
    /// </summary>
    private static Dictionary<string, List<string>> Reduce(Dictionary<string, List<string>> references)
    {
        var reach = new Dictionary<string, HashSet<string>>(StringComparer.OrdinalIgnoreCase);
        HashSet<string> Reach(string project, HashSet<string> visiting)
        {
            if (reach.TryGetValue(project, out var known))
            {
                return known;
            }
            var all = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (!visiting.Add(project))
            {
                return all; // a cycle (not possible between projects, but never loop)
            }
            foreach (var next in references.GetValueOrDefault(project) ?? [])
            {
                all.Add(next);
                all.UnionWith(Reach(next, visiting));
            }
            visiting.Remove(project);
            return reach[project] = all;
        }
        HashSet<string> From(string project) => Reach(project, new HashSet<string>(StringComparer.OrdinalIgnoreCase));
        return references.ToDictionary(r => r.Key,
            r => r.Value.Where(target => !r.Value.Any(other => !other.Equals(target, StringComparison.OrdinalIgnoreCase)
                                                             && From(other).Contains(target) && !From(target).Contains(r.Key))).ToList(),
            StringComparer.OrdinalIgnoreCase);
    }

    private static string Count(int n) => n switch
    {
        2 => "Two", 3 => "Three", 4 => "Four", 5 => "Five", 6 => "Six", 7 => "Seven", 8 => "Eight", 9 => "Nine", 10 => "Ten", 11 => "Eleven", 12 => "Twelve",
        _ => n.ToString(System.Globalization.CultureInfo.InvariantCulture),
    };

    private static bool IsTest(ProjectInfo p)
        => p.IsTestProject || TestName().IsMatch(p.Name);

    /// <summary>The layer a project belongs to: by its name, else by its role in the references.</summary>
    private static Layer LayerOf(ProjectInfo p, int dependsOn, int usedBy, int total)
    {
        var name = p.Name;
        var executable = p.OutputType is { } output && (output.Equals("Exe", StringComparison.OrdinalIgnoreCase) || output.Equals("WinExe", StringComparison.OrdinalIgnoreCase))
                         || (p.Sdk ?? "").Contains("Web", StringComparison.OrdinalIgnoreCase) || (p.Sdk ?? "").Contains("Worker", StringComparison.OrdinalIgnoreCase);
        if ((executable && usedBy == 0) || HostName().IsMatch(name))
        {
            return Hosts;
        }
        if (CompositionName().IsMatch(name))
        {
            return Composition;
        }
        if (IntegrationName().IsMatch(name))
        {
            return Integrations;
        }
        if (GatewayName().IsMatch(name))
        {
            return Gateway;
        }
        if (PersistenceName().IsMatch(name))
        {
            return Persistence;
        }
        if (ServiceName().IsMatch(name))
        {
            return Domains;
        }
        if (ModelName().IsMatch(name))
        {
            return Models;
        }
        if (SharedName().IsMatch(name))
        {
            return Shared;
        }
        // Nothing in the name: by its place in the references. Wiring for a host depends on most projects; a leaf is shared.
        if (dependsOn >= Math.Max(4, total * 0.4) && usedBy is > 0 and <= 3)
        {
            return Composition;
        }
        return dependsOn == 0 ? Shared : Domains;
    }

    [GeneratedRegex(@"\b(draw|diagram|mermaid|chart|picture|visuali[sz]e|sketch|map out)\b")]
    private static partial Regex Draw();

    [GeneratedRegex(@"\b(architecture|architectural|solution|projects|layers|layered|structure|repository|repo|system|codebase|overall|high[- ]level)\b")]
    private static partial Regex Whole();

    [GeneratedRegex(@"\b(solution|repository|repo|system|codebase|overall|whole|entire|complete|high[- ]level|all projects)\b")]
    private static partial Regex WholeOnly();

    [GeneratedRegex(@"```mermaid\s*\n.*?\n```", RegexOptions.Singleline)]
    private static partial Regex MermaidBlock();

    [GeneratedRegex(@"[^A-Za-z0-9_]+")]
    private static partial Regex NonWord();

    [GeneratedRegex(@"(^|\.)(Tests?|UnitTests?|IntegrationTests?|SmokeTests?|Specs?|Benchmarks?)($|\.)|Tests?$|^Test|ObjectMothers|TestUtility|TestCommon|Mocks?$|Fakes?$", RegexOptions.IgnoreCase)]
    private static partial Regex TestName();

    [GeneratedRegex(@"Host$|\.Host$|^Host\.|\.App$|Application\.Host|\.Console$|\.Cli$|Service\.Host", RegexOptions.IgnoreCase)]
    private static partial Regex HostName();

    [GeneratedRegex(@"HostCommon|Host\.Common|Composition|Bootstrap|Startup|Wiring|DependencyInjection|\.IoC$|CompositionRoot", RegexOptions.IgnoreCase)]
    private static partial Regex CompositionName();

    [GeneratedRegex(@"(^|\.)Prox(y|ies)(\.|$)|Proxy$|Client(s)?$|Adapter(s)?$|Integration(s)?$|Connector(s)?$|Gateway\.Client", RegexOptions.IgnoreCase)]
    private static partial Regex IntegrationName();

    [GeneratedRegex(@"Listener|Gateway|(^|\.)Api(s)?($|\.)|WebApi|Controllers?|Endpoints?|Grpc|Rest($|\.)|Http($|\.)|(^|\.)Web($|\.)", RegexOptions.IgnoreCase)]
    private static partial Regex GatewayName();

    [GeneratedRegex(@"Repositor(y|ies)|DataStores?|Persistence|(^|\.)Data($|\.)|Database|(^|\.)Db($|\.)|Infrastructure|Storage|(^|\.)Dal($|\.)|EntityFramework|(^|\.)Ef($|\.)|Migrations", RegexOptions.IgnoreCase)]
    private static partial Regex PersistenceName();

    [GeneratedRegex(@"Services?$|\.Services?\.|Application$|\.Business|BusinessLogic|\.Logic$|Handlers?$|\.Engine$|Workflows?$|UseCases", RegexOptions.IgnoreCase)]
    private static partial Regex ServiceName();

    [GeneratedRegex(@"Models?$|\.Models?\.|Types$|Contracts?$|Dtos?$|Entities$|Abstractions$|Interfaces$|\.Domain$|Schemas?$", RegexOptions.IgnoreCase)]
    private static partial Regex ModelName();

    [GeneratedRegex(@"Utilit(y|ies)|Util$|Common$|Shared$|Messaging|Logging|Extensions$|Helpers?$|\.Core$|Framework$|Diagnostics$|Telemetry", RegexOptions.IgnoreCase)]
    private static partial Regex SharedName();
}
