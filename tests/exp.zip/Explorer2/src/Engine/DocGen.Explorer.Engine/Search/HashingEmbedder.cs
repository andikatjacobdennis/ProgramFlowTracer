using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;

namespace DocGen.Explorer.Engine.Search;

/// <summary>
/// "hashing-512": a deterministic, offline embedding. Terms (identifiers split on camel humps) and adjacent-term bigrams
/// are hashed into 512 signed buckets with sub-linear term frequency, then L2-normalised. Needs no model and no network,
/// so it gives the same vectors on every machine.
/// </summary>
public sealed class HashingEmbedder
{
    public const string ModelName = "hashing-512";
    public const int Dimensions = 512;

    public float[] Embed(string text)
    {
        var vector = new float[Dimensions];
        var terms = TextUtil.Terms(text);
        if (terms.Count == 0)
        {
            return vector;
        }
        var counts = new Dictionary<string, int>(StringComparer.Ordinal);
        for (var i = 0; i < terms.Count; i++)
        {
            Count(counts, terms[i]);
            if (i + 1 < terms.Count)
            {
                Count(counts, terms[i] + "_" + terms[i + 1]);
            }
        }
        foreach (var (term, count) in counts)
        {
            var hash = TextUtil.Fnv1a(term);
            var bucket = (int)(hash % Dimensions);
            var sign = (hash >> 31) == 0 ? 1f : -1f;
            var weight = 1f + MathF.Log(count);
            if (term.Contains('_'))
            {
                weight *= 0.5f; // bigrams refine, unigrams carry the meaning
            }
            vector[bucket] += sign * weight;
        }
        Normalize(vector);
        return vector;
    }

    /// <summary>The text a chunk is embedded from: its title and path carry as much meaning as its body.</summary>
    public float[] EmbedChunk(Chunk chunk) => Embed($"{chunk.Title} {chunk.Symbol} {chunk.Path.Replace('/', ' ')} {chunk.Text}");

    private static void Count(Dictionary<string, int> counts, string term) => counts[term] = counts.TryGetValue(term, out var c) ? c + 1 : 1;

    public static void Normalize(float[] vector)
    {
        double sum = 0;
        foreach (var v in vector)
        {
            sum += v * v;
        }
        if (sum <= 0)
        {
            return;
        }
        var scale = (float)(1 / Math.Sqrt(sum));
        for (var i = 0; i < vector.Length; i++)
        {
            vector[i] *= scale;
        }
    }

    public static double Cosine(float[] a, float[] b)
    {
        double dot = 0;
        var n = Math.Min(a.Length, b.Length);
        for (var i = 0; i < n; i++)
        {
            dot += a[i] * b[i];
        }
        return dot; // vectors are unit length
    }
}

/// <summary>"inmemory": chunk vectors held in memory, persisted as a flat binary file next to the chunks.</summary>
public sealed class VectorStore
{
    public const string Name = "inmemory";

    private readonly Dictionary<string, float[]> _vectors = new(StringComparer.Ordinal);

    public int Count => _vectors.Count;

    public void Set(string chunkId, float[] vector) => _vectors[chunkId] = vector;

    public bool TryGet(string chunkId, out float[] vector) => _vectors.TryGetValue(chunkId, out vector!);

    public void RemoveWhere(Func<string, bool> predicate)
    {
        foreach (var key in _vectors.Keys.Where(predicate).ToList())
        {
            _vectors.Remove(key);
        }
    }

    public void Retain(IEnumerable<string> ids)
    {
        var keep = ids.ToHashSet(StringComparer.Ordinal);
        RemoveWhere(id => !keep.Contains(id));
    }

    public List<(string ChunkId, double Score)> Nearest(float[] query, int k, Func<string, bool>? filter = null)
    {
        var heap = new PriorityQueue<string, double>();
        foreach (var (id, vector) in _vectors)
        {
            if (filter is not null && !filter(id))
            {
                continue;
            }
            var score = HashingEmbedder.Cosine(query, vector);
            if (score <= 0)
            {
                continue;
            }
            heap.Enqueue(id, score);
            if (heap.Count > k)
            {
                heap.Dequeue();
            }
        }
        var result = new List<(string, double)>(heap.Count);
        while (heap.TryDequeue(out var id, out var score))
        {
            result.Add((id, score));
        }
        result.Reverse();
        return result;
    }

    /// <summary>Format: int32 count, then per entry: int32 id length, UTF-8 id, int32 dimensions, floats.</summary>
    public byte[] Serialize()
    {
        using var stream = new MemoryStream();
        using var writer = new BinaryWriter(stream);
        writer.Write(_vectors.Count);
        foreach (var (id, vector) in _vectors.OrderBy(v => v.Key, StringComparer.Ordinal))
        {
            writer.Write(id);
            writer.Write(vector.Length);
            foreach (var value in vector)
            {
                writer.Write(value);
            }
        }
        writer.Flush();
        return stream.ToArray();
    }

    public static VectorStore Deserialize(byte[]? bytes)
    {
        var store = new VectorStore();
        if (bytes is null || bytes.Length < 4)
        {
            return store;
        }
        try
        {
            using var reader = new BinaryReader(new MemoryStream(bytes));
            var count = reader.ReadInt32();
            for (var i = 0; i < count; i++)
            {
                var id = reader.ReadString();
                var length = reader.ReadInt32();
                if (length is < 0 or > 65536)
                {
                    return new VectorStore();
                }
                var vector = new float[length];
                for (var j = 0; j < length; j++)
                {
                    vector[j] = reader.ReadSingle();
                }
                store._vectors[id] = vector;
            }
        }
        catch (EndOfStreamException)
        {
            return new VectorStore(); // truncated: rebuilt on the next index run
        }
        return store;
    }
}
