using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Text;
using DocGen.Analysis.Architecture;
using DocGen.Analysis.Indexing;
using StaticTracer = DocGen.Analysis.Architecture.FlowTracer;

namespace DocGen.Explorer.Engine.Search;

/// <summary>An architecture trace of the scope a question names, and how it was chosen.</summary>
/// <param name="Scope">What was traced, as given to the scope resolver (a folder, type or words).</param>
/// <param name="Others">Other scopes the question also matches (another version of the same service), not traced.</param>
public sealed record ArchitectureTraceResult(FlowTrace Trace, string Scope, IReadOnlyList<string> Others, long DurationMs)
{
    public int StepCount => Trace.Steps.Count;
    public IReadOnlyList<string> Projects => Trace.Projects.ToList();
}

/// <summary>
/// The Architect skill's capability: the static architecture trace (entry points → every call in source order,
/// interfaces resolved through DI registrations, across projects, with boundaries and uncertain calls) run on the scope
/// a question names, and rendered as the program-flow table, call chain and sequence diagram.
/// </summary>
public static class ArchitectureTraces
{
    // The architecture model (DI registrations, endpoints, handlers) is built once per loaded index.
    private static readonly ConditionalWeakTable<RepositoryIndex, ArchitectureModel> Models = new();
    private static readonly object Gate = new();

    public static ArchitectureModel ModelFor(RepositoryIndex index, CodeIndex code, CancellationToken ct)
    {
        lock (Gate)
        {
            if (Models.TryGetValue(index, out var model))
            {
                return model;
            }
            model = ArchitectureModelBuilder.Build(index.Repository.Title, code, includeTests: false, ct);
            Models.AddOrUpdate(index, model);
            return model;
        }
    }

    /// <summary>
    /// Traces the scope the question names: the folder of the type its words matched (the way the static tracer traced
    /// "OrderService_1_0"), else the named type, else its identifiers and words. Null when nothing resolves
    /// to a scope with an entry point.
    /// </summary>
    public static ArchitectureTraceResult? Trace(RepositoryIndex index, QuestionAnalysis analysis, int maxSteps, int maxDepth, CancellationToken ct = default)
    {
        if (index.Code is not { } code)
        {
            return null;
        }
        var sw = System.Diagnostics.Stopwatch.StartNew();
        var model = ModelFor(index, code, ct);
        var candidates = Candidates(index, analysis).ToList();
        foreach (var candidate in candidates)
        {
            ct.ThrowIfCancellationRequested();
            AnalysisScope? scope;
            try
            {
                scope = ScopeResolver.Resolve(candidate, code, model, index.Root);
            }
            catch (Exception ex) when (ex is DocGen.Core.Exceptions.DocGenException or ArgumentException or InvalidOperationException or IOException)
            {
                // A candidate that names nothing ("Explain" from "Explain the flow of…"): try the next one.
                continue;
            }
            if (scope is null)
            {
                continue;
            }
            var trace = StaticTracer.Trace(scope, code, model, new StaticTracer.Options(MaxDepth: maxDepth, MaxSteps: maxSteps), ct);
            if (trace.Entries.Count == 0)
            {
                continue;
            }
            var others = analysis.Symbols
                .Select(s => Folder(s.File))
                .Where(f => f is not null && !string.Equals(f, candidate, StringComparison.OrdinalIgnoreCase) && !candidate.StartsWith(f!, StringComparison.OrdinalIgnoreCase)
                            && !f!.StartsWith(candidate + "/", StringComparison.OrdinalIgnoreCase))
                .Select(f => f!).Distinct(StringComparer.OrdinalIgnoreCase).Take(4).ToList();
            return new ArchitectureTraceResult(trace, candidate, others, sw.ElapsedMilliseconds);
        }
        return null;
    }

    private static IEnumerable<string> Candidates(RepositoryIndex index, QuestionAnalysis analysis)
    {
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        IEnumerable<string> Ordered()
        {
            foreach (var symbol in analysis.Symbols.Take(4))
            {
                // Matched from words ("order service"): the feature's folder, as the static tracer traces it — when the
                // folder is the feature (OrderService_1_0), not a whole project that happens to hold the type.
                if (analysis.SymbolsFromPhrase && NamedFolder(symbol.File, analysis.Question + " " + string.Join(" ", analysis.Targets)) is { } folder)
                {
                    yield return folder;
                }
                yield return symbol.Container is { } c && !SymbolKinds.IsType(symbol.Kind) ? $"{c[(c.LastIndexOf('.') + 1)..]}.{symbol.Name}" : symbol.FullName;
                // A class scope can have no recognisable entry point; its entry methods (Handle, Process…) still trace.
                if (SymbolKinds.IsType(symbol.Kind) && index.Code is { } code)
                {
                    foreach (var method in FlowTracer.EntryMethods(code, symbol).Take(2))
                    {
                        yield return $"{symbol.Name}.{method.Name}";
                    }
                }
            }
            foreach (var identifier in TextUtil.CandidateIdentifiers(analysis.Question))
            {
                yield return identifier;
            }
        }
        foreach (var candidate in Ordered())
        {
            if (candidate.Length > 0 && seen.Add(candidate))
            {
                yield return candidate;
            }
        }
    }

    /// <summary>Whether the question names the folder ("order service" names OrderService_1_0).</summary>
    private static bool FolderIsNamed(string folder, string question)
    {
        static string Letters(string text) => new(text.Where(char.IsLetter).Select(char.ToLowerInvariant).ToArray());
        var name = folder[(folder.LastIndexOf('/') + 1)..];
        var cut = name.IndexOf('_');
        var letters = Letters(cut > 0 ? name[..cut] : name);
        return letters.Length >= 6 && Letters(question).Contains(letters, StringComparison.Ordinal);
    }

    /// <summary>
    /// The folder the question names, walking up from the file's own folder (a type in OrderService_1_0/Translators
    /// traces OrderService_1_0, not just Translators); null when no folder on the way is named.
    /// </summary>
    private static string? NamedFolder(string file, string question)
    {
        for (var folder = Folder(file); folder is not null; folder = Folder(folder))
        {
            if (FolderIsNamed(folder, question))
            {
                return folder;
            }
        }
        return null;
    }

    /// <summary>The folder of a file (forward slashes), null for a file at the root.</summary>
    private static string? Folder(string file)
    {
        var path = file.Replace('\\', '/');
        var cut = path.LastIndexOf('/');
        return cut > 0 ? path[..cut] : null;
    }

    /// <summary>The program-flow table of one entry point: Step, Project, Class, Method, Description — every step.</summary>
    public static string Table(FlowEntry entry, int maxRows = int.MaxValue)
    {
        var sb = new StringBuilder("| Step | Project | Class | Method | Description |\n|---:|---|---|---|---|\n");
        var steps = PartialWriter.Subtree(entry.Root).ToList();
        foreach (var s in steps.Take(maxRows))
        {
            sb.Append($"| {s.Number} | {Cell(s.Project)} | `{Cell(s.TypeName)}` | `{Cell(s.MethodName)}` | {PartialWriter.DescriptionCell(s)} |\n");
        }
        if (steps.Count > maxRows)
        {
            sb.Append($"\n… {steps.Count - maxRows} more steps (raise the trace size in Settings → Skills).\n");
        }
        return sb.ToString();
    }

    private static string Cell(string text) => text.Replace("|", "\\|").Replace("\n", " ");

    /// <summary>The fenced block in which the model gives one description per step (see <see cref="WithFullTable"/>).</summary>
    public const string DescriptionsFence = "step-descriptions";

    /// <summary>
    /// The model's answer with the complete program-flow table: every traced step, numbered and placed by the trace
    /// itself (a model condenses long tables however it is asked). The model's <c>step-descriptions</c> block — one
    /// <c>n: sentence</c> line per step, and <c># Phase</c> lines that start a phase — is replaced by the table where it
    /// stood; a step it did not describe keeps the trace's own description. Without the block the table is added at the end.
    /// </summary>
    public static string WithFullTable(ArchitectureTraceResult result, string answer)
    {
        var (descriptions, phases, before, after) = ReadDescriptions(answer);
        var table = new StringBuilder();
        foreach (var entry in result.Trace.Entries)
        {
            var steps = PartialWriter.Subtree(entry.Root).ToList();
            table.Append($"### Program flow: {Capitalise(entry.Description)} — `{entry.Root.Display}` ({TextUtil.Plural(steps.Count, "step")})\n\n");
            var header = "| Step | Project | Class | Method | Description |\n|---:|---|---|---|---|\n";
            var first = true;
            foreach (var s in steps)
            {
                if (phases.TryGetValue(s.Number, out var phase))
                {
                    table.Append(first ? "" : "\n").Append($"**{phase}**\n\n").Append(header);
                }
                else if (first)
                {
                    table.Append(header);
                }
                first = false;
                var description = descriptions.TryGetValue(s.Number, out var said) ? Cell(said) : PartialWriter.DescriptionCell(s);
                table.Append($"| {s.Number} | {Cell(s.Project)} | `{Cell(s.TypeName)}` | `{Cell(s.MethodName)}` | {description} |\n");
            }
            table.Append('\n');
        }
        return after is null
            ? before.TrimEnd() + "\n\n" + table.ToString().TrimEnd() + "\n"
            : before.TrimEnd() + "\n\n" + table.ToString().TrimEnd() + "\n\n" + after.TrimStart();
    }

    /// <summary>The descriptions and phase headings of the block, and the answer before and after it (after is null without a block).</summary>
    private static (Dictionary<int, string> Descriptions, Dictionary<int, string> Phases, string Before, string? After) ReadDescriptions(string answer)
    {
        var descriptions = new Dictionary<int, string>();
        var phases = new Dictionary<int, string>();
        var open = Regex.Match(answer, @"^[ \t]*```[ \t]*" + DescriptionsFence + @"[ \t]*\r?\n", RegexOptions.Multiline);
        if (!open.Success)
        {
            return (descriptions, phases, answer, null);
        }
        var bodyStart = open.Index + open.Length;
        var close = Regex.Match(answer[bodyStart..], @"^[ \t]*```[ \t]*\r?$", RegexOptions.Multiline);
        var body = close.Success ? answer.Substring(bodyStart, close.Index) : answer[bodyStart..];
        var after = close.Success ? answer[(bodyStart + close.Index + close.Length)..] : "";
        string? pending = null;
        foreach (var line in body.Split('\n'))
        {
            var heading = Regex.Match(line, @"^\s*#+\s*(.+?)\s*$");
            if (heading.Success)
            {
                pending = heading.Groups[1].Value;
                continue;
            }
            var step = Regex.Match(line, @"^\s*(?:step\s*)?(\d+)\s*[:.)\-–|]\s*(.+?)\s*$", RegexOptions.IgnoreCase);
            if (step.Success && int.TryParse(step.Groups[1].Value, out var number))
            {
                descriptions[number] = step.Groups[2].Value;
                if (pending is not null)
                {
                    phases[number] = pending;
                    pending = null;
                }
            }
        }
        return (descriptions, phases, answer[..open.Index], after);
    }

    /// <summary>What the model is given: the trace as the architect tool reports it (table, chain, sequence, transitions, limits).</summary>
    public static string PromptContext(ArchitectureTraceResult result, int maxRows)
    {
        var sb = new StringBuilder();
        sb.Append(PartialWriter.ChatSummary(result.Trace, maxRows));
        if (result.Others.Count > 0)
        {
            sb.Append("\nAlso matching the question (not traced; mention them): ").Append(string.Join(", ", result.Others)).Append('\n');
        }
        return sb.ToString();
    }

    /// <summary>The answer without a model: the trace itself, as a program-flow document.</summary>
    public static string Compose(ArchitectureTraceResult result)
    {
        var trace = result.Trace;
        var sb = new StringBuilder();
        var projects = trace.Projects.ToList();
        sb.Append($"## Program flow: {trace.Scope.Label}\n\n");
        sb.Append($"Traced **{trace.Scope.Label}** (`{result.Scope}`) with the architecture trace: {TextUtil.Plural(trace.Entries.Count, "entry point")}, " +
                  $"{TextUtil.Plural(trace.Steps.Count, "step")} across {TextUtil.Plural(projects.Count, "project")} ({string.Join(", ", projects)}).\n\n");
        if (result.Others.Count > 0)
        {
            sb.Append($"The question also matches {string.Join(", ", result.Others.Select(o => $"`{o}`"))} — not traced here; ask about it by name for its own table.\n\n");
        }
        foreach (var note in trace.Scope.Notes.Take(3))
        {
            sb.Append($"> {note}\n");
        }
        foreach (var entry in trace.Entries)
        {
            sb.Append($"\n### {Capitalise(entry.Description)} — `{entry.Root.Display}`\n\n");
            sb.Append($"Starts at `{entry.Root.Symbol.File}:{entry.Root.Symbol.StartLine}`. Descriptions are the method's `///` summary, or (in italics) what its code visibly calls, creates and throws.\n\n");
            sb.Append(Table(entry));
            sb.Append($"\n**Call chain** (primary path):\n\n```text\n{PartialWriter.LinearChain(PartialWriter.PrimaryPath(entry.Root), byProject: true)}```\n");
            sb.Append($"\n**Sequence** (calls in source order):\n\n```mermaid\n{PartialWriter.Sequence(entry.Root)}```\n");
        }
        var transitions = trace.Transitions.ToList();
        if (transitions.Count > 0)
        {
            sb.Append("\n### Cross-project boundaries\n\n| Step | From | To | How |\n|---|---|---|---|\n");
            foreach (var (from, to) in transitions.Take(40))
            {
                var how = from.Edges.FirstOrDefault(e => e.Target == to)?.Resolution ?? "direct call";
                sb.Append($"| {from.Number} → {to.Number} | {Cell(from.Project)} · `{Cell(from.Display)}` | {Cell(to.Project)} · `{Cell(to.Display)}` | {Cell(how)} |\n");
            }
        }
        var boundaries = trace.BoundaryEdges.ToList();
        sb.Append("\n### Boundaries\n\n");
        sb.Append(boundaries.Count == 0
            ? "The trace found no database, HTTP, message or file calls on this path.\n"
            : string.Concat(boundaries.Take(25).Select(b => $"- step {b.Step.Number} `{b.Step.Display}`: {b.Edge.Boundary!.Kind} {b.Edge.Boundary.Name} — {b.Edge.Boundary.Detail}\n")));
        if (trace.Ambiguities.Count > 0 || trace.Limits.Count > 0)
        {
            sb.Append("\n### Limits of this trace\n\n");
            foreach (var limit in trace.Limits)
            {
                sb.Append($"- {limit}\n");
            }
            foreach (var ambiguity in trace.Ambiguities.Take(12))
            {
                sb.Append($"- Not followed (several possible targets): {ambiguity}\n");
            }
        }
        sb.Append("\n_Static analysis: reflection, runtime configuration and cache hits are not visible._\n");
        return sb.ToString();
    }

    private static string Capitalise(string s) => s.Length == 0 ? s : char.ToUpperInvariant(s[0]) + s[1..];
}
