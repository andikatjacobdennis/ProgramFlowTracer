using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace DocGen.Explorer.Engine.TestFix;

/// <summary>One find/replace in a file, as the model proposed it.</summary>
public sealed record EditBlock(string Path, string Find, string Replace, string Reason);

/// <summary>The model's diagnosis and patch, read from its reply.</summary>
public sealed record FixProposal(string RootCause, IReadOnlyList<string> Evidence, IReadOnlyList<string> Ambiguities, string TestChanges,
    IReadOnlyList<EditBlock> Edits, IReadOnlyList<string> NeedFiles)
{
    /// <summary>The kind of failure the diagnosis names (null when it names none it can be read as).</summary>
    public FailureClass? Classification { get; init; }
    public string? Confidence { get; init; }
    public string? FixLocation { get; init; }
    public IReadOnlyList<string> Alternatives { get; init; } = [];
}

/// <summary>
/// The patch format Test Fix asks the model for, the rules every edit must pass, and applying edits so that only the
/// exact text named changes: the rest of the file — including the person's own unsaved or uncommitted edits — stays as
/// it is, line endings and encoding included.
/// </summary>
public static partial class Patches
{
    public const string Format = """
        Reply in exactly this Markdown shape:

        ## Classification
        One of: production defect | outdated test expectation | fixture or isolation defect | environment | flaky | unresolved.
        (A test failing does not prove the code is wrong; an assertion existing does not prove it is right.)

        ## Confidence
        high | medium | low — and what evidence is missing for more.

        ## Fix location
        The layer that owns the faulty behaviour (production code, the test's expectation, the test's setup or shared
        state, the environment or configuration) and why that layer, not another.

        ## Alternatives considered
        - Each other plausible explanation, and the evidence that rules it out (or "none").

        ## Root cause
        The defect, where it is (file, type, member, line) and why it makes the test fail.

        ## Evidence
        - Each fact that supports it: the failing assertion or exception, the code line, the requirement or contract, an existing test.

        ## Ambiguities
        - What the evidence does not settle about the intended behaviour (or "none").

        ## Test changes
        "none" — or, only when the evidence shows a test's expectation or setup is wrong, the evidence and each test change.

        ## Edits
        One fenced block per file, the fence's info string being `edit <repository-relative path>`; inside, a `Reason:` line,
        then one or more pairs (FIND must match the file's current text exactly, once; keep it short but unique):

        ```edit src/Orders/PriceCalculator.cs
        Reason: the discount was applied twice.
        <<<<<<< FIND
        exact current lines
        =======
        the replacement lines
        >>>>>>> REPLACE
        ```

        A new file has an empty FIND. When the files you need to see are not in the evidence, reply only with one line
        `NEED: path1, path2` (repository-relative, at most 8) and nothing else.

        The edits must match the classification: production code for a production defect (a regression test may be added);
        test files only for an outdated expectation or a fixture defect; no edits for an environment problem or an
        unresolved one (say what to change or check instead).
        """;

    /// <summary>Reads the model's reply; null when it has neither a diagnosis nor edits nor a request for files.</summary>
    public static FixProposal? Parse(string reply)
    {
        reply = reply.Replace("\r\n", "\n");
        var need = NeedRegex().Match(reply);
        var needFiles = need.Success
            ? need.Groups[1].Value.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Select(p => p.Trim('`', '"', '\'')).Where(p => p.Length > 0).Take(8).ToList()
            : [];
        var edits = new List<EditBlock>();
        foreach (Match block in EditFenceRegex().Matches(reply))
        {
            var path = block.Groups[1].Value.Trim().Trim('`', '"', '\'');
            var body = block.Groups[2].Value;
            var reason = ReasonRegex().Match(body) is { Success: true } r ? r.Groups[1].Value.Trim() : "";
            foreach (Match pair in PairRegex().Matches(body))
            {
                edits.Add(new EditBlock(path, pair.Groups[1].Value, pair.Groups[2].Value, reason));
            }
        }
        var rootCause = Section(reply, "Root cause");
        if (rootCause.Length == 0 && edits.Count == 0 && needFiles.Count == 0)
        {
            return null;
        }
        return new FixProposal(rootCause, Bullets(Section(reply, "Evidence")), Bullets(Section(reply, "Ambiguities")).Where(a => !IsNone(a)).ToList(),
            IsNone(Section(reply, "Test changes")) ? "" : Section(reply, "Test changes"), edits, needFiles)
        {
            Classification = ClassificationOf(Section(reply, "Classification")),
            Confidence = ConfidenceRegex().Match(Section(reply, "Confidence")) is { Success: true } c ? c.Value.ToLowerInvariant() : null,
            FixLocation = Section(reply, "Fix location") is { Length: > 0 } where ? where : null,
            Alternatives = Bullets(Section(reply, "Alternatives considered")).Where(a => !IsNone(a)).ToList(),
        };
    }

    /// <summary>The classification named in a reply's text ("outdated test expectation", "Flaky (timing)"…), or null.</summary>
    public static FailureClass? ClassificationOf(string text)
    {
        var t = text.ToLowerInvariant();
        return t.Length == 0 ? null
            : t.Contains("outdated", StringComparison.Ordinal) || t.Contains("test expectation", StringComparison.Ordinal) || t.Contains("incorrect test", StringComparison.Ordinal) ? FailureClass.OutdatedTestExpectation
            : t.Contains("fixture", StringComparison.Ordinal) || t.Contains("isolation", StringComparison.Ordinal) ? FailureClass.FixtureOrIsolation
            : t.Contains("flaky", StringComparison.Ordinal) || t.Contains("nondetermin", StringComparison.Ordinal) || t.Contains("intermittent", StringComparison.Ordinal) ? FailureClass.Flaky
            : t.Contains("environment", StringComparison.Ordinal) || t.Contains("dependency mismatch", StringComparison.Ordinal) || t.Contains("configuration", StringComparison.Ordinal) ? FailureClass.Environment
            : t.Contains("production", StringComparison.Ordinal) || t.Contains("product defect", StringComparison.Ordinal) || t.Contains("regression", StringComparison.Ordinal) ? FailureClass.ProductionDefect
            : t.Contains("runner", StringComparison.Ordinal) || t.Contains("tool", StringComparison.Ordinal) ? FailureClass.ToolDefect
            : t.Contains("unresolved", StringComparison.Ordinal) || t.Contains("unknown", StringComparison.Ordinal) ? FailureClass.Unresolved
            : null;
    }

    /// <summary>
    /// Why an edit does not belong to the layer the diagnosis names (production code for a production defect, tests for an
    /// expectation or fixture defect, nothing for an environment or unresolved one), or null.
    /// </summary>
    public static string? LayerViolation(FailureClass? classification, bool isTest, bool isNewFile)
        => classification switch
        {
            FailureClass.Environment => "the diagnosis says the environment is at fault, so no file of the repository should change",
            FailureClass.Unresolved => "the diagnosis is unresolved, so there is nothing yet to change",
            FailureClass.OutdatedTestExpectation or FailureClass.FixtureOrIsolation when !isTest => "the diagnosis puts the fault in the test, but this is production code",
            FailureClass.ProductionDefect when isTest && !isNewFile => "the diagnosis puts the fault in production code, but this changes an existing test (a new regression test is allowed)",
            _ => null,
        };

    /// <summary>A test file, by its path ("tests/", "*Tests.cs", "*.spec.ts", "test_*.py", "*Test.java").</summary>
    public static bool IsTestPath(string path, IEnumerable<string>? testProjects = null)
    {
        var p = path.Replace('\\', '/');
        if (testProjects is not null && testProjects.Select(t => t.Replace('\\', '/')).Select(t => t.Contains('/') ? t[..t.LastIndexOf('/')] : "")
                .Any(dir => dir.Length > 0 && p.StartsWith(dir + "/", StringComparison.OrdinalIgnoreCase)))
        {
            return true;
        }
        return TestPathRegex().IsMatch(p);
    }

    /// <summary>Why an edit breaks the rules (skips a test, removes an assertion, adds a delay, swallows an exception, changes a test without evidence), or null.</summary>
    public static string? Violation(EditBlock edit, bool isTest, bool testChangesJustified)
    {
        var added = edit.Replace;
        var removed = edit.Find;
        if (SkipRegex().IsMatch(added) && !SkipRegex().IsMatch(removed))
        {
            return "it would skip or disable a test";
        }
        if (DelayRegex().IsMatch(added) && !DelayRegex().IsMatch(removed))
        {
            return "it adds an arbitrary delay";
        }
        if (SwallowRegex().IsMatch(added) && !SwallowRegex().IsMatch(removed))
        {
            return "it swallows exceptions";
        }
        if (TestMarkerRegex().Matches(removed).Count > TestMarkerRegex().Matches(added).Count)
        {
            return "it removes a test";
        }
        if (isTest)
        {
            if (AssertionRegex().Matches(removed).Count > AssertionRegex().Matches(added).Count)
            {
                return "it removes assertions from a test";
            }
            if (!testChangesJustified)
            {
                return "it changes a test without evidence that the test's expectation or setup is wrong";
            }
        }
        return null;
    }

    /// <summary>A path inside the repository that Test Fix may write (not build output, packages, tool or VCS folders), or null.</summary>
    public static string? Resolve(string root, string relative)
    {
        relative = relative.Replace('\\', '/').TrimStart('/');
        if (relative.Length == 0 || relative.Contains("..", StringComparison.Ordinal) || Path.IsPathRooted(relative)
            || ProtectedPathRegex().IsMatch("/" + relative))
        {
            return null;
        }
        var full = Path.GetFullPath(Path.Combine(root, relative));
        var rootFull = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        return full.StartsWith(rootFull, StringComparison.OrdinalIgnoreCase) ? full : null;
    }

    /// <summary>A file's text and how it is written (BOM, line endings), so a change keeps both.</summary>
    public sealed record FileText(string Text, bool Bom, bool Crlf, string Hash);

    public static FileText ReadFile(string path)
    {
        var bytes = File.ReadAllBytes(path);
        var bom = bytes.Length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF;
        var text = new UTF8Encoding(false).GetString(bytes, bom ? 3 : 0, bytes.Length - (bom ? 3 : 0));
        return new FileText(text, bom, text.Contains("\r\n", StringComparison.Ordinal), Hash(bytes));
    }

    public static string Hash(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes))[..16].ToLowerInvariant();

    /// <summary>
    /// The file's text with the edits made, or why they cannot be: every FIND must be found exactly once (line-ending and
    /// trailing-space differences forgiven), in order. Nothing outside the found text changes.
    /// </summary>
    public static (string? Text, string? Problem) ApplyEdits(string original, IReadOnlyList<EditBlock> edits)
    {
        var crlf = original.Contains("\r\n", StringComparison.Ordinal);
        var text = original.Replace("\r\n", "\n");
        foreach (var edit in edits)
        {
            var find = edit.Find.Replace("\r\n", "\n");
            var replace = edit.Replace.Replace("\r\n", "\n");
            if (find.Length == 0)
            {
                if (text.Length > 0)
                {
                    return (null, "an edit with an empty FIND would replace a file that exists");
                }
                text = replace;
                continue;
            }
            var at = Locate(text, find, out var length, out var problem);
            if (at < 0)
            {
                return (null, problem);
            }
            text = text[..at] + replace + text[(at + length)..];
        }
        return (crlf ? text.Replace("\n", "\r\n") : text, null);
    }

    /// <summary>Where FIND is in the text: exactly once, else once with trailing spaces ignored line by line.</summary>
    private static int Locate(string text, string find, out int length, out string? problem)
    {
        problem = null;
        length = find.Length;
        var first = text.IndexOf(find, StringComparison.Ordinal);
        if (first >= 0)
        {
            if (text.IndexOf(find, first + 1, StringComparison.Ordinal) >= 0)
            {
                problem = "the text to replace occurs more than once";
                return -1;
            }
            return first;
        }
        // Forgiving: the same lines with different trailing whitespace.
        var lines = text.Split('\n');
        var want = find.TrimEnd('\n').Split('\n').Select(l => l.TrimEnd()).ToArray();
        var matches = new List<int>();
        for (var i = 0; i + want.Length <= lines.Length; i++)
        {
            if (Enumerable.Range(0, want.Length).All(k => lines[i + k].TrimEnd() == want[k]))
            {
                matches.Add(i);
            }
        }
        if (matches.Count != 1)
        {
            problem = matches.Count == 0 ? "the text to replace is not in the file (it may have changed)" : "the text to replace occurs more than once";
            return -1;
        }
        var start = lines.Take(matches[0]).Sum(l => l.Length + 1);
        length = Math.Min(text.Length - start, lines.Skip(matches[0]).Take(want.Length).Sum(l => l.Length + 1) - (find.EndsWith('\n') ? 0 : 1));
        return start;
    }

    /// <summary>Writes the new text in the file's own encoding (BOM kept), through a temporary file.</summary>
    public static void WriteFile(string path, string text, bool bom)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var temp = path + ".testfix.tmp";
        File.WriteAllText(temp, text, new UTF8Encoding(bom));
        File.Move(temp, path, overwrite: true);
    }

    /// <summary>A unified diff (3 lines of context) between two texts.</summary>
    public static string UnifiedDiff(string path, string before, string after, bool created = false)
    {
        var a = before.Length == 0 ? [] : before.Replace("\r\n", "\n").TrimEnd('\n').Split('\n');
        var b = after.Length == 0 ? [] : after.Replace("\r\n", "\n").TrimEnd('\n').Split('\n');
        // The common start and end are not compared line by line: an edit is local, the files may be long.
        var prefix = 0;
        while (prefix < a.Length && prefix < b.Length && a[prefix] == b[prefix])
        {
            prefix++;
        }
        var suffix = 0;
        while (suffix < a.Length - prefix && suffix < b.Length - prefix && a[^(suffix + 1)] == b[^(suffix + 1)])
        {
            suffix++;
        }
        var ops = Lcs(a[prefix..(a.Length - suffix)], b[prefix..(b.Length - suffix)]);
        var all = new List<(char Op, string Line)>();
        all.AddRange(a[..prefix].Select(l => (' ', l)));
        all.AddRange(ops);
        all.AddRange(a[(a.Length - suffix)..].Select(l => (' ', l)));

        var sb = new StringBuilder();
        sb.Append(created ? "--- /dev/null\n" : $"--- a/{path}\n").Append($"+++ b/{path}\n");
        var changed = all.Select((x, i) => (x, i)).Where(t => t.x.Op != ' ').Select(t => t.i).ToList();
        var hunkStart = 0;
        while (hunkStart < changed.Count)
        {
            var hunkEnd = hunkStart;
            while (hunkEnd + 1 < changed.Count && changed[hunkEnd + 1] - changed[hunkEnd] <= 7)
            {
                hunkEnd++;
            }
            var from = Math.Max(0, changed[hunkStart] - 3);
            var to = Math.Min(all.Count - 1, changed[hunkEnd] + 3);
            var oldLine = all.Take(from).Count(x => x.Op != '+') + 1;
            var newLine = all.Take(from).Count(x => x.Op != '-') + 1;
            var slice = all.Skip(from).Take(to - from + 1).ToList();
            sb.Append($"@@ -{oldLine},{slice.Count(x => x.Op != '+')} +{newLine},{slice.Count(x => x.Op != '-')} @@\n");
            foreach (var (op, line) in slice)
            {
                sb.Append(op).Append(line).Append('\n');
            }
            hunkStart = hunkEnd + 1;
        }
        return sb.ToString();
    }

    private static List<(char, string)> Lcs(string[] a, string[] b)
    {
        // Large unrelated regions: shown as removed then added (no quadratic table).
        if ((long)a.Length * b.Length > 4_000_000)
        {
            return [.. a.Select(l => ('-', l)), .. b.Select(l => ('+', l))];
        }
        var table = new int[a.Length + 1, b.Length + 1];
        for (var i = a.Length - 1; i >= 0; i--)
        {
            for (var j = b.Length - 1; j >= 0; j--)
            {
                table[i, j] = a[i] == b[j] ? table[i + 1, j + 1] + 1 : Math.Max(table[i + 1, j], table[i, j + 1]);
            }
        }
        var result = new List<(char, string)>();
        int x = 0, y = 0;
        while (x < a.Length && y < b.Length)
        {
            if (a[x] == b[y])
            {
                result.Add((' ', a[x]));
                x++;
                y++;
            }
            else if (table[x + 1, y] >= table[x, y + 1])
            {
                result.Add(('-', a[x++]));
            }
            else
            {
                result.Add(('+', b[y++]));
            }
        }
        while (x < a.Length)
        {
            result.Add(('-', a[x++]));
        }
        while (y < b.Length)
        {
            result.Add(('+', b[y++]));
        }
        return result;
    }

    private static string Section(string reply, string heading)
    {
        var match = Regex.Match(reply, $@"^#{{2,3}}\s*{Regex.Escape(heading)}\s*\n(.*?)(?=^#{{2,3}}\s|\z)", RegexOptions.Multiline | RegexOptions.Singleline | RegexOptions.IgnoreCase);
        return match.Success ? EditFenceRegex().Replace(match.Groups[1].Value, "").Trim() : "";
    }

    private static List<string> Bullets(string section)
        => section.Split('\n').Select(l => l.Trim()).Where(l => l.Length > 0).Select(l => l.TrimStart('-', '*', ' ').Trim()).Where(l => l.Length > 0).ToList();

    private static bool IsNone(string text) => text.Trim().Trim('.', '"', '`').Equals("none", StringComparison.OrdinalIgnoreCase) || text.Trim().Length == 0;

    [GeneratedRegex(@"^\s*NEED:\s*(.+)$", RegexOptions.Multiline)]
    private static partial Regex NeedRegex();

    [GeneratedRegex(@"\b(high|medium|low)\b", RegexOptions.IgnoreCase)]
    private static partial Regex ConfidenceRegex();

    [GeneratedRegex(@"^```+\s*edit\s+([^\n]+)\n(.*?)^```+\s*$", RegexOptions.Multiline | RegexOptions.Singleline)]
    private static partial Regex EditFenceRegex();

    [GeneratedRegex(@"^Reason:\s*(.+)$", RegexOptions.Multiline)]
    private static partial Regex ReasonRegex();

    [GeneratedRegex(@"^<{5,}\s*FIND\s*\n(.*?)\n?^={5,}\s*\n(.*?)\n?^>{5,}\s*REPLACE\s*$", RegexOptions.Multiline | RegexOptions.Singleline)]
    private static partial Regex PairRegex();

    [GeneratedRegex(@"(^|/)(tests?|__tests__|spec|specs|testing)/|Tests?\.(cs|fs|vb|java|kt)$|\.(test|spec)\.[jt]sx?$|(^|/)test_[^/]+\.py$|_test\.(py|go)$", RegexOptions.IgnoreCase)]
    private static partial Regex TestPathRegex();

    [GeneratedRegex(@"[\[,]\s*(Ignore|Skip)\b|\(\s*Skip\s*=|Assert\.Inconclusive|Assert\.Ignore|Assume\.That|\b(it|test|describe)\.skip\(|\bx(it|describe|test)\(|@pytest\.mark\.skip|@unittest\.skip|pytest\.skip\(|@Disabled\b|@Ignore\b|\bTestCategory\(\s*""(Skip|Ignore)", RegexOptions.IgnoreCase)]
    private static partial Regex SkipRegex();

    [GeneratedRegex(@"Thread\.Sleep\s*\(|Task\.Delay\s*\(|time\.sleep\s*\(|Start-Sleep|setTimeout\s*\(|await\s+sleep\s*\(|SpinWait\.SpinUntil")]
    private static partial Regex DelayRegex();

    [GeneratedRegex(@"catch\s*(\([^)]*\))?\s*\{\s*(//[^\n]*\s*)*\}|except[^:\n]*:\s*\n?\s*pass\b|catch\s*\([^)]*\)\s*\{\s*\}|\.catch\(\s*\(\s*\)\s*=>\s*\{\s*\}\s*\)")]
    private static partial Regex SwallowRegex();

    [GeneratedRegex(@"\[\s*(TestMethod|Test|Fact|Theory|TestCase|DataTestMethod)\b|@Test\b|^\s*def\s+test_|\b(it|test)\s*\(\s*['""`]", RegexOptions.Multiline)]
    private static partial Regex TestMarkerRegex();

    [GeneratedRegex(@"\bAssert\.|\bassert\b|\bexpect\s*\(|\.Should\(|\bAssertThat\b|\bassertEquals\b|\bCollectionAssert\.|\bStringAssert\.")]
    private static partial Regex AssertionRegex();

    [GeneratedRegex(@"/(\.git|\.vs|\.idea|bin|obj|node_modules|packages|TestResults|\.venv|venv)/|/\.git$", RegexOptions.IgnoreCase)]
    private static partial Regex ProtectedPathRegex();
}
