using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;
using DocGen.Security;

namespace DocGen.Explorer.Engine.TestFix;

/// <summary>A command to run, and where its result files go.</summary>
public sealed record TestCommand(string CommandLine, string WorkingDirectory, string? Configuration, string ResultsDirectory, IReadOnlyList<string> ResultPatterns);

/// <summary>
/// Builds and runs test and build commands for a repository: the runner its configuration names (or the person's own
/// command), the selected configuration, an isolated results and temp folder, a timeout, cancellation that ends the
/// whole process tree, and output that is redacted before anything keeps or shows it. Commands that commit, push,
/// publish or deploy are refused.
/// </summary>
public static partial class TestCommandRunner
{
    private const int MaxOutputChars = 6_000_000;

    /// <summary>Why a command must not run (it would commit, push, publish, deploy or destroy), or null.</summary>
    public static string? Refusal(string commandLine)
    {
        var match = ForbiddenRegex().Match(commandLine);
        return match.Success ? $"“{match.Value.Trim()}” is not allowed: Test Fix only runs tests and builds locally (it never commits, pushes, publishes or deploys)." : null;
    }

    /// <summary>The test command for the repository, its configuration and a selection of tests.</summary>
    /// <param name="selection">Runner filter or test names (null: all tests).</param>
    /// <param name="target">A project to run instead of the profile's target (related tests).</param>
    public static TestCommand Tests(ProjectProfile profile, string root, string resultsDirectory, string? configuration, string? selection, string? userCommand, string? target = null,
        int hangSeconds = 120, string? extraArguments = null)
    {
        var blame = $" --blame-hang-timeout {Math.Clamp(hangSeconds, 20, 600)}s --blame-hang-dump-type none" + (extraArguments is { Length: > 0 } extra ? " " + extra.Trim() : "");
        Directory.CreateDirectory(resultsDirectory);
        var results = Quote(resultsDirectory);
        if (userCommand is { Length: > 0 })
        {
            var line = userCommand.Trim();
            // The person's own dotnet test still writes result files Test Fix can read (unless it already says where).
            if (DotnetTestRegex().IsMatch(line))
            {
                if (configuration is { Length: > 0 } && !ConfigurationArgRegex().IsMatch(line))
                {
                    line += $" -c {Quote(configuration)}";
                }
                if (selection is { Length: > 0 } && !line.Contains("--filter", StringComparison.OrdinalIgnoreCase))
                {
                    line += $" --filter {Quote(DotnetFilter(selection))}";
                }
                if (!line.Contains("--logger", StringComparison.OrdinalIgnoreCase) && !line.Contains("--results-directory", StringComparison.OrdinalIgnoreCase))
                {
                    line += $" --logger trx --results-directory {results}";
                }
                if (!line.Contains("--blame", StringComparison.OrdinalIgnoreCase))
                {
                    line += blame;
                }
            }
            return new TestCommand(line, root, configuration, resultsDirectory, ["*.trx", "*.xml"]);
        }
        switch (profile.Runner)
        {
            case "dotnet test":
            {
                var sb = new StringBuilder("dotnet test");
                if ((target ?? profile.Target) is { Length: > 0 } t)
                {
                    sb.Append(' ').Append(Quote(t));
                }
                if (configuration is { Length: > 0 })
                {
                    sb.Append(" -c ").Append(Quote(configuration));
                }
                if (selection is { Length: > 0 })
                {
                    sb.Append(" --filter ").Append(Quote(DotnetFilter(selection)));
                }
                sb.Append(" --nologo --logger trx --results-directory ").Append(results).Append(blame);
                return new TestCommand(sb.ToString(), root, configuration, resultsDirectory, ["*.trx"]);
            }
            case "npm test" or "yarn test" or "pnpm test":
            {
                var manager = profile.Runner.Split(' ')[0];
                var line = manager == "npm" ? "npm test --" : $"{manager} test";
                if (selection is { Length: > 0 })
                {
                    line += profile.Frameworks.Any(f => f is "Jest" or "Vitest") ? $" -t {Quote(string.Join("|", Names(selection).Select(Regex.Escape)))}" : " " + Quote(selection);
                }
                return new TestCommand(line, root, configuration, resultsDirectory, ["*.xml"]);
            }
            case "python -m pytest":
            {
                var line = $"python -m pytest -q --junitxml={Quote(Path.Combine(resultsDirectory, "junit.xml"))}";
                if (selection is { Length: > 0 })
                {
                    var names = Names(selection);
                    line += names.All(n => n.Contains("::", StringComparison.Ordinal)) ? " " + string.Join(" ", names.Select(Quote))
                        : $" -k {Quote(string.Join(" or ", names.Select(n => n.Split("::")[^1].Split('.')[^1])))}";
                }
                return new TestCommand(line, root, configuration, resultsDirectory, ["*.xml"]);
            }
            case "mvnw test" or "mvn test":
            {
                var line = (profile.Runner.StartsWith("mvnw", StringComparison.Ordinal) ? (OperatingSystem.IsWindows() ? "mvnw.cmd" : "./mvnw") : "mvn") + " -B test";
                if (selection is { Length: > 0 })
                {
                    line += $" -Dtest={Quote(string.Join(",", Names(selection).Select(JavaTestName)))}";
                }
                return new TestCommand(line, root, configuration, Path.Combine(root, "target", "surefire-reports"), ["*.xml"]);
            }
            case "gradlew test" or "gradle test":
            {
                var line = (profile.Runner.StartsWith("gradlew", StringComparison.Ordinal) ? (OperatingSystem.IsWindows() ? "gradlew.bat" : "./gradlew") : "gradle") + " test";
                foreach (var name in selection is { Length: > 0 } ? Names(selection) : [])
                {
                    line += $" --tests {Quote(name)}";
                }
                return new TestCommand(line, root, configuration, Path.Combine(root, "build", "test-results", "test"), ["*.xml"]);
            }
            default:
                return new TestCommand("", root, configuration, resultsDirectory, []);
        }
    }

    /// <summary>A build check of the whole solution (or project), for runners with a separate build; null when there is none.</summary>
    public static TestCommand? Build(ProjectProfile profile, string root, string resultsDirectory, string? configuration)
    {
        if (profile.Runner != "dotnet test" || profile.Target is not { Length: > 0 } target)
        {
            return null;
        }
        var line = $"dotnet build {Quote(target)} --nologo" + (configuration is { Length: > 0 } ? $" -c {Quote(configuration)}" : "");
        return new TestCommand(line, root, configuration, resultsDirectory, []);
    }

    /// <summary>A dotnet test filter: as given when it is one ("FullyQualifiedName~X", "Category=Y"), else the names joined.</summary>
    public static string DotnetFilter(string selection)
    {
        if (FilterExpressionRegex().IsMatch(selection))
        {
            return selection.Trim();
        }
        return string.Join("|", Names(selection).Select(n => "FullyQualifiedName~" + FilterEscapeRegex().Replace(n.Split('(')[0], m => "\\" + m.Value)));
    }

    /// <summary>The test names in a selection (separated by commas, semicolons, "|" or new lines).</summary>
    public static List<string> Names(string selection)
        => selection.Split([',', ';', '|', '\n', '\r'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Distinct(StringComparer.Ordinal).ToList();

    /// <summary>Runs a command and reads its results; never throws for the command's own failures.</summary>
    /// <param name="logPath">Where the redacted output is written (absolute).</param>
    public static async Task<CommandRun> RunAsync(TestCommand command, string purpose, int iteration, TimeSpan timeout, string tempDirectory, string logPath, CancellationToken ct)
    {
        var run = new CommandRun
        {
            Purpose = purpose, Iteration = iteration, CommandLine = SecretRedactor.Redact(command.CommandLine), WorkingDirectory = command.WorkingDirectory,
            Configuration = command.Configuration,
        };
        if (command.CommandLine.Length == 0)
        {
            run.Outcome = RunOutcome.ConfigurationError;
            run.Problems.Add("No test command: the repository's runner was not recognised and none was given.");
            return run;
        }
        if (Refusal(command.CommandLine) is { } refusal)
        {
            run.Outcome = RunOutcome.ConfigurationError;
            run.Problems.Add(refusal);
            return run;
        }
        Directory.CreateDirectory(tempDirectory);
        var started = DateTime.Now.AddSeconds(-2);
        var output = new StringBuilder();
        var sw = Stopwatch.StartNew();
        var info = OperatingSystem.IsWindows()
            ? new ProcessStartInfo("cmd.exe") { ArgumentList = { "/d", "/s", "/c", command.CommandLine } }
            : new ProcessStartInfo("/bin/sh") { ArgumentList = { "-c", command.CommandLine } };
        info.WorkingDirectory = command.WorkingDirectory;
        info.RedirectStandardOutput = true;
        info.RedirectStandardError = true;
        info.RedirectStandardInput = true;
        info.UseShellExecute = false;
        info.CreateNoWindow = true;
        info.StandardOutputEncoding = Encoding.UTF8;
        info.StandardErrorEncoding = Encoding.UTF8;
        // Non-interactive, English, no colour codes, no lingering build servers; temp files in the run's own folder.
        foreach (var (key, value) in new[]
                 {
                     ("DOTNET_NOLOGO", "1"), ("DOTNET_CLI_TELEMETRY_OPTOUT", "1"), ("DOTNET_CLI_UI_LANGUAGE", "en"), ("MSBUILDDISABLENODEREUSE", "1"),
                     ("DOTNET_SKIP_FIRST_TIME_EXPERIENCE", "1"), ("CI", "true"), ("NO_COLOR", "1"), ("FORCE_COLOR", "0"), ("TEMP", tempDirectory), ("TMP", tempDirectory),
                 })
        {
            info.Environment[key] = value;
        }
        using var process = new Process { StartInfo = info, EnableRaisingEvents = true };
        void Add(string? line)
        {
            if (line is null)
            {
                return;
            }
            lock (output)
            {
                if (output.Length < MaxOutputChars)
                {
                    output.AppendLine(line);
                }
            }
        }
        process.OutputDataReceived += (_, e) => Add(e.Data);
        process.ErrorDataReceived += (_, e) => Add(e.Data);
        try
        {
            process.Start();
        }
        catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or InvalidOperationException)
        {
            run.Outcome = RunOutcome.RunnerUnavailable;
            run.Problems.Add("The command could not be started: " + ex.Message);
            return run;
        }
        process.StandardInput.Close();
        process.BeginOutputReadLine();
        process.BeginErrorReadLine();
        using var limit = CancellationTokenSource.CreateLinkedTokenSource(ct);
        limit.CancelAfter(timeout);
        try
        {
            await process.WaitForExitAsync(limit.Token);
            process.WaitForExit(); // drains the redirected output
            run.ExitCode = process.ExitCode;
        }
        catch (OperationCanceledException)
        {
            try
            {
                process.Kill(entireProcessTree: true);
            }
            catch (Exception ex) when (ex is InvalidOperationException or System.ComponentModel.Win32Exception)
            {
            }
            run.Outcome = ct.IsCancellationRequested ? RunOutcome.Cancelled : RunOutcome.TimedOut;
            run.Problems.Add(ct.IsCancellationRequested ? "Stopped by you." : $"Stopped after the {timeout.TotalSeconds:0}-second limit.");
        }
        run.DurationMs = sw.ElapsedMilliseconds;
        string text;
        lock (output)
        {
            text = SecretRedactor.Redact(output.ToString());
        }
        Directory.CreateDirectory(Path.GetDirectoryName(logPath)!);
        await File.WriteAllTextAsync(logPath, $"> {run.CommandLine}\n(in {run.WorkingDirectory})\n\n{text}\nExit code: {run.ExitCode?.ToString() ?? "none"}\n", CancellationToken.None);
        run.OutputTail = Tail(text, 60);
        if (run.Outcome is RunOutcome.Cancelled or RunOutcome.TimedOut)
        {
            return run;
        }
        Read(run, text, ResultFiles(command, started), command.WorkingDirectory);
        return run;
    }

    /// <summary>Result files written by this run (not older ones a folder may still hold).</summary>
    private static List<string> ResultFiles(TestCommand command, DateTime since)
    {
        if (!Directory.Exists(command.ResultsDirectory))
        {
            return [];
        }
        return command.ResultPatterns
            .SelectMany(p => Directory.EnumerateFiles(command.ResultsDirectory, p, SearchOption.AllDirectories))
            .Where(f => File.GetLastWriteTime(f) >= since).Distinct().ToList();
    }

    /// <summary>Counts, failures and the outcome, from the result files and the output.</summary>
    internal static void Read(CommandRun run, string output, IReadOnlyList<string> resultFiles, string? root = null)
    {
        var counts = TestResults.FromTrx(resultFiles.Where(f => f.EndsWith(".trx", StringComparison.OrdinalIgnoreCase)))
                     ?? TestResults.FromJUnit(resultFiles.Where(f => f.EndsWith(".xml", StringComparison.OrdinalIgnoreCase)))
                     ?? TestResults.FromConsole(output);
        if (counts is not null)
        {
            (run.Discovered, run.Executed, run.Passed, run.Failed, run.Skipped, run.CountsFrom) = (counts.Discovered, counts.Executed, counts.Passed, counts.Failed, counts.Skipped, counts.From);
            run.Failures = counts.Failures.Select(f => f with
            {
                Message = SecretRedactor.Redact(Relative(f.Message, root)),
                StackTrace = f.StackTrace is null ? null : SecretRedactor.Redact(CompactStack(f.StackTrace, root)),
            }).ToList();
            if (run.Failures.Count == 0 && counts.Failed > 0)
            {
                run.Failures = TestResults.ConsoleFailures(output);
            }
        }
        run.Problems.AddRange(ProblemRegex().Matches(output).Select(m => Relative(m.Value.Trim(), root)).Distinct().Take(15));
        // A runner echoes each failing test's own exception in its output too: those are not separate logged errors.
        var known = run.Failures.Select(f => f.Message.Split('\n')[0].Trim()).Where(m => m.Length >= 20).Select(m => m[..Math.Min(80, m.Length)]).ToList();
        run.Logged = TestResults.LoggedErrors(resultFiles, output)
            .Where(b => !known.Any(k => b.Contains(k, StringComparison.Ordinal)) && !b.Contains("Error Message:", StringComparison.Ordinal))
            .Select(b => SecretRedactor.Redact(CompactLogged(b, root))).ToList();
        run.Outcome = Classify(run, output);
        if (root is not null)
        {
            run.Excerpts = Excerpts(run, root);
        }
    }

    /// <summary>
    /// A stack trace without the test framework's and the runtime's own frames (assertion helpers, reflection, task
    /// plumbing), with the repository's paths made relative: the frames that say where in the code it happened.
    /// </summary>
    public static string CompactStack(string stack, string? root)
    {
        var frames = stack.Replace("\r\n", "\n").Split('\n').Select(l => l.TrimEnd()).Where(l => l.Trim().Length > 0).ToList();
        var kept = frames.Where(f => !FrameworkFrameRegex().IsMatch(f)).Take(14).Select(f => "   " + Relative(f.Trim(), root)).ToList();
        var dropped = frames.Count - kept.Count;
        return string.Join("\n", kept) + (dropped > 0 ? $"\n   (… {dropped} test-framework or runtime frame(s) left out)" : "");
    }

    /// <summary>A logged error with its stack compacted like a failure's.</summary>
    private static string CompactLogged(string block, string? root)
    {
        var lines = block.Split('\n');
        var head = lines.TakeWhile(l => !l.TrimStart().StartsWith("at ", StringComparison.Ordinal)).Select(l => Relative(l, root)).ToList();
        var stack = string.Join("\n", lines.Skip(head.Count));
        return string.Join("\n", head) + (stack.Length > 0 ? "\n" + CompactStack(stack, root) : "");
    }

    /// <summary>The text with the repository's absolute paths made relative to it.</summary>
    public static string Relative(string text, string? root)
    {
        if (root is null || text.Length == 0)
        {
            return text;
        }
        var full = Path.GetFullPath(root).TrimEnd('\\', '/');
        return text.Replace(full + "\\", "", StringComparison.OrdinalIgnoreCase).Replace(full.Replace('\\', '/') + "/", "", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>The code around each repository frame of the failures and each compile error (±6 lines), as it is now.</summary>
    internal static List<CodeExcerpt> Excerpts(CommandRun run, string root)
    {
        var places = new List<(string Path, int Line)>();
        foreach (var failure in run.Failures.Take(20))
        {
            places.AddRange(TestResults.StackLocations(failure.StackTrace ?? "").Take(3));
        }
        foreach (var logged in run.Logged)
        {
            places.AddRange(TestResults.StackLocations(logged).Take(3));
        }
        foreach (var problem in run.Problems)
        {
            if (CompileLocationRegex().Match(problem) is { Success: true } m)
            {
                places.Add((m.Groups[1].Value, int.Parse(m.Groups[2].Value)));
            }
        }
        var excerpts = new List<CodeExcerpt>();
        foreach (var (path, line) in places.Distinct())
        {
            if (excerpts.Count >= 16)
            {
                break;
            }
            var full = Path.IsPathRooted(path) ? path : Path.Combine(root, path);
            try
            {
                if (!File.Exists(full) || !Path.GetFullPath(full).StartsWith(Path.GetFullPath(root), StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }
                var lines = File.ReadAllLines(full);
                var first = Math.Max(1, line - 6);
                var last = Math.Min(lines.Length, line + 6);
                var text = string.Join("\n", Enumerable.Range(first, Math.Max(0, last - first + 1)).Select(n => $"{n,5}{(n == line ? " >" : "  ")} {lines[n - 1]}"));
                excerpts.Add(new CodeExcerpt(Path.GetRelativePath(root, full).Replace('\\', '/'), line, first, SecretRedactor.Redact(text)));
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException)
            {
            }
        }
        return excerpts;
    }

    /// <summary>What a run amounted to. Zero executed tests is never a pass.</summary>
    internal static RunOutcome Classify(CommandRun run, string output)
    {
        if (AbortedRegex().IsMatch(output))
        {
            var hung = output.Contains("inactivity time", StringComparison.OrdinalIgnoreCase) || output.Contains("hang", StringComparison.OrdinalIgnoreCase);
            foreach (var name in RunningTestRegex().Matches(output).Select(m => m.Groups[1].Value.Trim()).Where(n => n.Length > 0).Distinct())
            {
                if (run.Failures.All(f => f.Name != name))
                {
                    run.Failures.Add(new TestFailure(name, hung
                        ? "This test hung: it made no progress for the hang limit, so the test host was stopped and the run aborted; the tests after it did not run."
                        : "The test host crashed while this test ran (a stack overflow, an unhandled exception on another thread, Environment.Exit…); the run was aborted.", null));
                }
            }
            run.Failed = Math.Max(run.Failed, run.Failures.Count);
            return RunOutcome.Aborted;
        }
        if (run.Executed > 0 && run.Failed > 0)
        {
            // Every failure is a connection that could not be made: a service is down, not the code.
            return run.Failures.Count > 0 && run.Failures.All(f => ServiceRegex().IsMatch(f.Message + "\n" + f.StackTrace)) ? RunOutcome.ServiceUnavailable : RunOutcome.TestsFailed;
        }
        if (run.Executed > 0 && run.ExitCode == 0)
        {
            return RunOutcome.Passed;
        }
        if (run.ExitCode == 9009 || NotFoundRegex().IsMatch(output))
        {
            return RunOutcome.RunnerUnavailable;
        }
        if (MissingDependencyRegex().IsMatch(output))
        {
            return RunOutcome.MissingDependency;
        }
        if (ConfigurationRegex().IsMatch(output))
        {
            return RunOutcome.ConfigurationError;
        }
        if (BuildErrorRegex().IsMatch(output))
        {
            return RunOutcome.BuildFailed;
        }
        if (ServiceRegex().IsMatch(output))
        {
            return RunOutcome.ServiceUnavailable;
        }
        if (DiscoveryErrorRegex().IsMatch(output))
        {
            return RunOutcome.DiscoveryError;
        }
        if (run.Executed == 0 && (run.ExitCode == 0 || NoTestsRegex().IsMatch(output) || run.CountsFrom is not null))
        {
            return RunOutcome.NoTestsRun;
        }
        if (run.Executed > 0 && run.Failed == 0 && run.Failures.Count == 0 && NoTestMatchesRegex().IsMatch(output))
        {
            // Tests ran and none failed; the exit code is the other test projects of a solution matching none of the filter.
            return RunOutcome.Passed;
        }
        return run.Executed > 0 ? RunOutcome.TestsFailed : RunOutcome.Failed;
    }

    [GeneratedRegex(@"No test matches the given testcase filter", RegexOptions.IgnoreCase)]
    private static partial Regex NoTestMatchesRegex();

    private static string Tail(string text, int lines)
    {
        var all = text.Replace("\r\n", "\n").TrimEnd().Split('\n');
        return string.Join("\n", all.Skip(Math.Max(0, all.Length - lines)));
    }

    private static string JavaTestName(string name)
    {
        var parts = name.Split('.');
        return parts.Length >= 2 && char.IsLower(parts[^1][0]) ? $"{parts[^2]}#{parts[^1]}" : parts[^1];
    }

    internal static string Quote(string value) => value.Length > 0 && !value.Any(c => char.IsWhiteSpace(c) || c is '"' or '&' or '|' or '<' or '>' or '^' or '(' or ')' or '%' or '!')
        ? value : "\"" + value.Replace("\"", "\\\"") + "\"";

    [GeneratedRegex(@"\bgit\s+(commit|push|tag|merge|rebase|reset|clean|checkout|switch|stash)\b|\b(dotnet\s+nuget\s+push|nuget(\.exe)?\s+push|npm\s+publish|yarn\s+publish|pnpm\s+publish|dotnet\s+publish|docker\s+push|twine\s+upload|mvn\S*\s+deploy|gradle\S*\s+publish|kubectl\s+(apply|delete|rollout)|helm\s+(install|upgrade|uninstall)|terraform\s+(apply|destroy)|az\s+\w+\s+(create|delete|deploy)|az\s+deployment|aws\s+\S+\s+(deploy|delete)|gh\s+(release|pr|repo)|func\s+azure|Remove-Item\b[^|&]*-Recurse|rmdir\s+/s|rd\s+/s|del\s+/[sq]|rm\s+-r|format\s+[a-z]:|shutdown\b)", RegexOptions.IgnoreCase)]
    private static partial Regex ForbiddenRegex();

    [GeneratedRegex(@"^\s*--- End of stack trace|\b(at\s+)?(Microsoft\.VisualStudio\.TestTools\.|Microsoft\.VisualStudio\.TestPlatform\.|Microsoft\.Testing\.|System\.Reflection\.|System\.RuntimeMethodHandle|System\.Runtime\.(CompilerServices|ExceptionServices)\.|System\.Threading\.(ExecutionContext|Tasks\.(Task\b|Task`|AwaitTaskContinuation|ThreadPool))|InvokeStub_|Xunit\.(Sdk|Assert)\b|Xunit\.Assert\.|NUnit\.Framework\.(Assert|Internal)|--- End of stack trace from previous location ---)")]
    private static partial Regex FrameworkFrameRegex();

    [GeneratedRegex(@"([^\s:""(]+\.(?:cs|fs|vb|ts|tsx|js|py|java))\((\d+),\d+\):\s*error")]
    private static partial Regex CompileLocationRegex();

    [GeneratedRegex(@"Test Run Aborted|The active test run was aborted|Test host process crashed|testhost\.exe.*exited|Test host process exited", RegexOptions.IgnoreCase)]
    private static partial Regex AbortedRegex();

    [GeneratedRegex(@"The test running when the crash occurred:\s*\r?\n\s*([^\r\n]+)", RegexOptions.IgnoreCase)]
    private static partial Regex RunningTestRegex();

    [GeneratedRegex(@"^\s*dotnet\s+test\b", RegexOptions.IgnoreCase)]
    private static partial Regex DotnetTestRegex();

    [GeneratedRegex(@"(\s-c\s|\s--configuration[\s=])", RegexOptions.IgnoreCase)]
    private static partial Regex ConfigurationArgRegex();

    [GeneratedRegex(@"(FullyQualifiedName|Name|ClassName|TestCategory|Category|Priority|Trait|DisplayName)\s*(=|!=|~|!~)")]
    private static partial Regex FilterExpressionRegex();

    [GeneratedRegex(@"[\\()&|=!~]")]
    private static partial Regex FilterEscapeRegex();

    [GeneratedRegex(@"^.*(error\s+(CS|MSB|NU|NETSDK|FS|BC|TS)\d+|Build FAILED|COMPILATION ERROR|ERROR collecting|ModuleNotFoundError|Cannot find module|Missing script|command not found|is not recognized as an internal or external command|No test is available|No test matches|No connection could be made|ECONNREFUSED|Connection refused).*$", RegexOptions.Multiline | RegexOptions.IgnoreCase)]
    private static partial Regex ProblemRegex();

    [GeneratedRegex(@"is not recognized as an internal or external command|: command not found|No such file or directory.*(dotnet|npm|python|mvn|gradle)|Could not execute because the specified command or file was not found", RegexOptions.IgnoreCase)]
    private static partial Regex NotFoundRegex();

    [GeneratedRegex(@"error\s+NU1\d{3}|Unable to find package|error\s+MSB4236|A compatible \.NET SDK was not found|You must install or update \.NET|The framework '[^']+', version '[^']+' .*was not found|Cannot find module|ModuleNotFoundError|No module named|Could not resolve dependencies|Could not find artifact|npm ERR! code (E404|ENOENT|ERESOLVE)|Could not resolve all (files|dependencies)", RegexOptions.IgnoreCase)]
    private static partial Regex MissingDependencyRegex();

    [GeneratedRegex(@"error\s+MSB(4126|1009|1008|1003|1011)|solution configuration .* is invalid|The specified (solution )?configuration|Missing script: ""?test|unrecognized arguments|Unknown option|The test source file .* was not found|error: no such option|error\s+NETSDK1004|error\s+NETSDK1005", RegexOptions.IgnoreCase)]
    private static partial Regex ConfigurationRegex();

    [GeneratedRegex(@"error\s+(CS|FS|BC|TS)\d+|error\s+MSB\d+|Build FAILED|COMPILATION ERROR|SyntaxError|ERROR collecting|compilation failed", RegexOptions.IgnoreCase)]
    private static partial Regex BuildErrorRegex();

    [GeneratedRegex(@"No connection could be made|ECONNREFUSED|Connection refused|network-related or instance-specific error|Name or service not known|No such host is known|actively refused|Could not connect to|Connection timed out|ServiceUnavailable|503 Service Unavailable", RegexOptions.IgnoreCase)]
    private static partial Regex ServiceRegex();

    [GeneratedRegex(@"Testhost process .* exited with error|Could not find testhost|An exception occurred while invoking executor|Test discovery failed|Unable to find .*\.deps\.json|No test discoverer|error collecting|failed to load the test", RegexOptions.IgnoreCase)]
    private static partial Regex DiscoveryErrorRegex();

    [GeneratedRegex(@"No test is available|No test matches the given testcase filter|no tests ran|No tests found|Test Run Aborted|0 tests? (found|collected)", RegexOptions.IgnoreCase)]
    private static partial Regex NoTestsRegex();
}
