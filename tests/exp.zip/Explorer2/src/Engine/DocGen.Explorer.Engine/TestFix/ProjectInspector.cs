using System.Text.Json;
using System.Text.RegularExpressions;

namespace DocGen.Explorer.Engine.TestFix;

/// <summary>
/// Works out how a repository runs its tests, from its own configuration: .NET solutions and test projects (MSTest,
/// NUnit, xUnit through <c>dotnet test</c>), package.json test scripts (Jest, Vitest, Mocha through npm, yarn or pnpm),
/// pytest, Maven and Gradle (their wrappers first). Pinned versions (global.json, packageManager, wrappers) are noted
/// and the repository's own commands are preferred.
/// </summary>
public static partial class ProjectInspector
{
    private static readonly string[] SkipFolders = ["bin", "obj", "node_modules", ".git", ".vs", "packages", "TestResults", ".venv", "venv", "dist", "build", "target", "out"];

    public static ProjectProfile Inspect(string root)
    {
        var profile = new ProjectProfile();
        var files = Files(root, 6).ToList();
        string Rel(string path) => Path.GetRelativePath(root, path).Replace('\\', '/');

        // .NET: a solution at the shallowest level, its configurations, and the test projects.
        var solutions = files.Where(f => f.EndsWith(".sln", StringComparison.OrdinalIgnoreCase) || f.EndsWith(".slnx", StringComparison.OrdinalIgnoreCase))
            .OrderBy(f => Depth(root, f)).ThenBy(f => f, StringComparer.OrdinalIgnoreCase).ToList();
        var projects = files.Where(f => f.EndsWith(".csproj", StringComparison.OrdinalIgnoreCase) || f.EndsWith(".fsproj", StringComparison.OrdinalIgnoreCase)
                                        || f.EndsWith(".vbproj", StringComparison.OrdinalIgnoreCase)).ToList();
        if (solutions.Count > 0 || projects.Count > 0)
        {
            // The language most of the projects are in (a C# solution with one F# sample is a C# repository).
            profile.Language = projects.GroupBy(p => Path.GetExtension(p).ToLowerInvariant()).OrderByDescending(g => g.Count()).Select(g => g.Key).FirstOrDefault() switch
            {
                ".fsproj" => "F#",
                ".vbproj" => "Visual Basic",
                _ => "C#",
            };
            profile.Runner = "dotnet test";
            var central = files.Where(f => Path.GetFileName(f).Equals("Directory.Packages.props", StringComparison.OrdinalIgnoreCase)).Select(Read).FirstOrDefault() ?? "";
            var frameworksOf = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
            foreach (var project in projects)
            {
                var text = Read(project);
                var frameworks = TestFrameworks(text + "\n" + (TestPackageRegex().IsMatch(text) ? central : "")).ToList();
                frameworksOf[Path.GetFullPath(project)] = frameworks;
                if (frameworks.Count > 0 || IsTestProjectRegex().IsMatch(text))
                {
                    profile.TestProjects.Add(Rel(project));
                    profile.Frameworks.AddRange(frameworks);
                }
            }
            // A project named as tests whose test packages come from elsewhere: a Directory.Build.props that adds them
            // (often under an MSBuild condition this reading does not evaluate), or a shared test library it references.
            var props = files.Where(f => Path.GetFileName(f).Equals("Directory.Build.props", StringComparison.OrdinalIgnoreCase)).ToList();
            foreach (var project in projects.Where(p => TestNameRegex().IsMatch(Path.GetFileNameWithoutExtension(p)) && !profile.TestProjects.Contains(Rel(p))))
            {
                var dir = Path.GetDirectoryName(Path.GetFullPath(project))!;
                var inherited = props.Where(p => dir.StartsWith(Path.GetDirectoryName(Path.GetFullPath(p))!, StringComparison.OrdinalIgnoreCase))
                    .SelectMany(p => TestFrameworks(Read(p))).ToList();
                var referenced = ProjectReferenceRegex().Matches(Read(project))
                    .Select(m => Path.GetFullPath(Path.Combine(dir, m.Groups[1].Value.Replace('\\', Path.DirectorySeparatorChar))))
                    .SelectMany(r => frameworksOf.TryGetValue(r, out var f) ? f : []).ToList();
                var frameworks = inherited.Concat(referenced).Distinct().ToList();
                if (frameworks.Count > 0 || props.Any(p => dir.StartsWith(Path.GetDirectoryName(Path.GetFullPath(p))!, StringComparison.OrdinalIgnoreCase) && TestPackageRegex().IsMatch(Read(p))))
                {
                    profile.TestProjects.Add(Rel(project));
                    profile.Frameworks.AddRange(frameworks);
                }
            }
            if (solutions.Count > 0)
            {
                profile.Target = Rel(solutions[0]);
                profile.Configurations.AddRange(SolutionConfigurations(Read(solutions[0])));
                profile.Notes.Add($"Solution {profile.Target}" + (solutions.Count > 1 ? $" (of {solutions.Count})" : "") + ".");
            }
            else if (profile.TestProjects.Count == 1)
            {
                profile.Target = profile.TestProjects[0];
            }
            if (files.FirstOrDefault(f => Path.GetFileName(f).Equals("global.json", StringComparison.OrdinalIgnoreCase)) is { } global
                && SdkVersionRegex().Match(Read(global)) is { Success: true } sdk)
            {
                profile.Pinned.Add($".NET SDK {sdk.Groups[1].Value} ({Rel(global)})");
            }
            if (central.Length > 0)
            {
                profile.Pinned.Add("package versions in Directory.Packages.props");
            }
            if (profile.Configurations.Count == 0)
            {
                profile.Configurations.AddRange(["Debug", "Release"]);
            }
        }
        // JavaScript / TypeScript: the test script of the root package.json.
        else if (File.Exists(Path.Combine(root, "package.json")))
        {
            var package = Read(Path.Combine(root, "package.json"));
            profile.Language = File.Exists(Path.Combine(root, "tsconfig.json")) ? "TypeScript" : "JavaScript";
            var manager = File.Exists(Path.Combine(root, "pnpm-lock.yaml")) ? "pnpm" : File.Exists(Path.Combine(root, "yarn.lock")) ? "yarn" : "npm";
            profile.Runner = $"{manager} test";
            profile.Target = "package.json";
            foreach (var (name, framework) in new[] { ("jest", "Jest"), ("vitest", "Vitest"), ("mocha", "Mocha"), ("jasmine", "Jasmine"), ("ava", "AVA"), ("playwright", "Playwright") })
            {
                if (package.Contains($"\"{name}", StringComparison.OrdinalIgnoreCase) || package.Contains($"\"@{name}", StringComparison.OrdinalIgnoreCase))
                {
                    profile.Frameworks.Add(framework);
                }
            }
            if (!TestScriptRegex().IsMatch(package))
            {
                profile.Notes.Add("package.json has no test script.");
            }
            if (PackageManagerRegex().Match(package) is { Success: true } pinned)
            {
                profile.Pinned.Add($"{pinned.Groups[1].Value} (packageManager)");
            }
        }
        // Python: pytest.
        else if (new[] { "pytest.ini", "pyproject.toml", "setup.cfg", "tox.ini", "conftest.py", "requirements.txt", "setup.py" }.Any(f => File.Exists(Path.Combine(root, f))))
        {
            profile.Language = "Python";
            profile.Runner = "python -m pytest";
            profile.Frameworks.Add(files.Any(f => Path.GetFileName(f).Equals("conftest.py", StringComparison.OrdinalIgnoreCase))
                                   || new[] { "pytest.ini", "pyproject.toml", "requirements.txt", "setup.cfg", "tox.ini" }.Any(f => File.Exists(Path.Combine(root, f)) && Read(Path.Combine(root, f)).Contains("pytest", StringComparison.OrdinalIgnoreCase))
                ? "pytest" : "unittest (through pytest)");
        }
        // Java: Maven or Gradle, their wrappers first (they pin the build tool's version).
        else if (File.Exists(Path.Combine(root, "pom.xml")))
        {
            profile.Language = "Java";
            var wrapper = File.Exists(Path.Combine(root, "mvnw.cmd")) || File.Exists(Path.Combine(root, "mvnw"));
            profile.Runner = wrapper ? "mvnw test" : "mvn test";
            profile.Target = "pom.xml";
            profile.Frameworks.Add(Read(Path.Combine(root, "pom.xml")).Contains("junit-jupiter", StringComparison.OrdinalIgnoreCase) ? "JUnit 5" : "JUnit");
            if (wrapper)
            {
                profile.Pinned.Add("Maven wrapper");
            }
        }
        else if (File.Exists(Path.Combine(root, "build.gradle")) || File.Exists(Path.Combine(root, "build.gradle.kts")))
        {
            profile.Language = File.Exists(Path.Combine(root, "build.gradle.kts")) ? "Kotlin/Java" : "Java";
            var wrapper = File.Exists(Path.Combine(root, "gradlew.bat")) || File.Exists(Path.Combine(root, "gradlew"));
            profile.Runner = wrapper ? "gradlew test" : "gradle test";
            profile.Frameworks.Add("JUnit");
            if (wrapper)
            {
                profile.Pinned.Add("Gradle wrapper");
            }
        }
        profile.Frameworks = profile.Frameworks.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        if (profile.Runner.Length == 0)
        {
            profile.Notes.Add("No test runner was recognised from the repository's files; give the test command.");
        }
        return profile;
    }

    /// <summary>The machine and the tools the runner uses (OS, SDK or runtime versions), asked briefly; nothing is installed.</summary>
    public static async Task<List<string>> EnvironmentAsync(ProjectProfile profile, string root, CancellationToken ct)
    {
        var lines = new List<string> { $"OS: {System.Runtime.InteropServices.RuntimeInformation.OSDescription} ({System.Runtime.InteropServices.RuntimeInformation.OSArchitecture})" };
        var tool = profile.Runner switch
        {
            "dotnet test" => ("dotnet", "--version", ".NET SDK"),
            "npm test" or "yarn test" or "pnpm test" => ("node", "--version", "Node.js"),
            "python -m pytest" => ("python", "--version", "Python"),
            "mvnw test" or "mvn test" or "gradlew test" or "gradle test" => ("java", "-version", "Java"),
            _ => default,
        };
        if (tool != default && await VersionAsync(tool.Item1, tool.Item2, root, ct) is { Length: > 0 } version)
        {
            lines.Add($"{tool.Item3}: {version}");
        }
        return lines;
    }

    private static async Task<string?> VersionAsync(string exe, string arguments, string root, CancellationToken ct)
    {
        try
        {
            var info = OperatingSystem.IsWindows()
                ? new System.Diagnostics.ProcessStartInfo("cmd.exe") { ArgumentList = { "/d", "/s", "/c", $"{exe} {arguments}" } }
                : new System.Diagnostics.ProcessStartInfo(exe, arguments);
            info.WorkingDirectory = root;
            info.RedirectStandardOutput = true;
            info.RedirectStandardError = true;
            info.UseShellExecute = false;
            info.CreateNoWindow = true;
            using var process = System.Diagnostics.Process.Start(info);
            if (process is null)
            {
                return null;
            }
            using var limit = CancellationTokenSource.CreateLinkedTokenSource(ct);
            limit.CancelAfter(TimeSpan.FromSeconds(20));
            var output = await process.StandardOutput.ReadToEndAsync(limit.Token) + await process.StandardError.ReadToEndAsync(limit.Token);
            await process.WaitForExitAsync(limit.Token);
            return process.ExitCode == 0 ? output.Split('\n', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault()?.Trim() : null;
        }
        catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or InvalidOperationException or OperationCanceledException or IOException)
        {
            return null;
        }
    }

    /// <summary>Test frameworks a .NET project references.</summary>
    public static IEnumerable<string> TestFrameworks(string projectText)
    {
        if (projectText.Contains("MSTest", StringComparison.OrdinalIgnoreCase))
        {
            yield return "MSTest";
        }
        if (NUnitRegex().IsMatch(projectText))
        {
            yield return "NUnit";
        }
        if (projectText.Contains("xunit", StringComparison.OrdinalIgnoreCase))
        {
            yield return "xUnit";
        }
        if (projectText.Contains("TUnit", StringComparison.Ordinal))
        {
            yield return "TUnit";
        }
    }

    /// <summary>The configurations a solution defines ("Debug|Any CPU = …" lines, or a .slnx's Configurations).</summary>
    public static IEnumerable<string> SolutionConfigurations(string solution)
        => SolutionConfigurationRegex().Matches(solution).Select(m => m.Groups[1].Value.Trim())
            .Concat(SlnxConfigurationRegex().Matches(solution).Select(m => m.Groups[1].Value.Trim()))
            .Where(c => c.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase);

    private static int Depth(string root, string file) => Path.GetRelativePath(root, file).Count(c => c is '\\' or '/');

    private static string Read(string path)
    {
        try
        {
            return new FileInfo(path).Length > 2_000_000 ? "" : File.ReadAllText(path);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return "";
        }
    }

    /// <summary>The repository's files to a depth, without build output, packages and tool folders.</summary>
    internal static IEnumerable<string> Files(string root, int maxDepth)
    {
        var pending = new Stack<(string Dir, int Depth)>([(root, 0)]);
        while (pending.Count > 0)
        {
            var (dir, depth) = pending.Pop();
            IEnumerable<string> entries;
            try
            {
                entries = Directory.EnumerateFiles(dir).ToList();
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                continue;
            }
            foreach (var file in entries)
            {
                yield return file;
            }
            if (depth >= maxDepth)
            {
                continue;
            }
            try
            {
                foreach (var sub in Directory.EnumerateDirectories(dir))
                {
                    if (!SkipFolders.Contains(Path.GetFileName(sub), StringComparer.OrdinalIgnoreCase) && !new DirectoryInfo(sub).Attributes.HasFlag(FileAttributes.ReparsePoint))
                    {
                        pending.Push((sub, depth + 1));
                    }
                }
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
            }
        }
    }

    /// <summary>Reads a JSON property from package.json-like text, or null.</summary>
    internal static string? JsonString(string json, params string[] path)
    {
        try
        {
            using var doc = JsonDocument.Parse(json);
            var element = doc.RootElement;
            foreach (var part in path)
            {
                if (element.ValueKind != JsonValueKind.Object || !element.TryGetProperty(part, out element))
                {
                    return null;
                }
            }
            return element.ValueKind == JsonValueKind.String ? element.GetString() : null;
        }
        catch (JsonException)
        {
            return null;
        }
    }

    [GeneratedRegex(@"<IsTestProject>\s*true\s*</IsTestProject>", RegexOptions.IgnoreCase)]
    private static partial Regex IsTestProjectRegex();

    [GeneratedRegex(@"Include=""(MSTest|NUnit|xunit|Microsoft\.NET\.Test\.Sdk|TUnit)", RegexOptions.IgnoreCase)]
    private static partial Regex TestPackageRegex();

    [GeneratedRegex(@"\bNUnit(?:\b|3TestAdapter)", RegexOptions.IgnoreCase)]
    private static partial Regex NUnitRegex();

    [GeneratedRegex(@"""sdk""\s*:\s*\{[^}]*""version""\s*:\s*""([^""]+)""", RegexOptions.Singleline)]
    private static partial Regex SdkVersionRegex();

    [GeneratedRegex(@"^\s*([^|=\r\n]+)\|[^=\r\n]+=\s*\1\|", RegexOptions.Multiline)]
    private static partial Regex SolutionConfigurationRegex();

    [GeneratedRegex(@"<BuildType\s+Name=""([^""]+)""", RegexOptions.IgnoreCase)]
    private static partial Regex SlnxConfigurationRegex();

    [GeneratedRegex(@"""scripts""\s*:\s*\{[^}]*""test""\s*:", RegexOptions.Singleline)]
    private static partial Regex TestScriptRegex();

    [GeneratedRegex(@"""packageManager""\s*:\s*""([^""]+)""")]
    private static partial Regex PackageManagerRegex();

    // "Core.Test", "Api.Tests", "OrdersIntegrationTests" — a capital T, so "Latest" is not one.
    [GeneratedRegex(@"(?:[.\-_]|(?<=[a-z0-9]))(Unit|Integration|Functional|Automation|Acceptance)?Tests?$")]
    private static partial Regex TestNameRegex();

    [GeneratedRegex(@"<ProjectReference\s+Include=""([^""]+)""", RegexOptions.IgnoreCase)]
    private static partial Regex ProjectReferenceRegex();
}
