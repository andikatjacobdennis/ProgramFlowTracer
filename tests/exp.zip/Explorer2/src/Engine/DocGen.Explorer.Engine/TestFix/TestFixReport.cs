using System.Text;

namespace DocGen.Explorer.Engine.TestFix;

/// <summary>The Test Fix report (Markdown): status, root cause and evidence, the changes and their diff, every command with its exit code and counts, what was verified and what was not, and what is left.</summary>
public static class TestFixReport
{
    public static string Title(TestFixStatus status) => status switch
    {
        TestFixStatus.FixedAndVerified => "Fixed and verified",
        TestFixStatus.PartiallyResolved => "Partially resolved",
        TestFixStatus.Blocked => "Blocked",
        _ => "Running",
    };

    public static string Build(TestFixRun run)
    {
        var sb = new StringBuilder();
        var icon = run.Status switch { TestFixStatus.FixedAndVerified => "✅", TestFixStatus.PartiallyResolved => "🟡", _ => "⛔" };
        // Nothing fixed, but diagnosed: an environment problem, a failure that does not reproduce here, or one not to patch blindly.
        var diagnosed = run.Status == TestFixStatus.Blocked && !run.Patches.Any(p => p.Applied) && run.Attempts.Any(a => a.Classification is not null);
        sb.AppendLine(diagnosed ? "## 🔎 Test Fix: Diagnosed, not fixed" : $"## {icon} Test Fix: {Title(run.Status)}").AppendLine();
        sb.AppendLine(Headline(run)).AppendLine();
        if (run.Interrupted)
        {
            var applied = run.Patches.Where(p => p.Applied).Select(p => $"`{p.Path}`").ToList();
            sb.AppendLine($"> **Interrupted:** {run.StopReason ?? "the run did not finish."} "
                          + (applied.Count > 0 ? $"Changes applied before it stopped: {string.Join(", ", applied)}. " : "No file was changed. ")
                          + $"Steps completed: {(run.Completed.Count == 0 ? "none" : run.Completed.Count.ToString())} (listed under Progress).").AppendLine();
        }
        if (run.Project is { } project)
        {
            sb.AppendLine($"**Project:** {TestFixService.Describe(project)}" + (run.Request.Configuration is { Length: > 0 } c ? $" · configuration **{c}**" : "")
                          + (project.Pinned.Count > 0 ? $" · pinned: {string.Join(", ", project.Pinned)}" : "")).AppendLine();
        }
        Environment(sb, run);
        Reproduced(sb, run);

        var attempt = run.Attempts.LastOrDefault(a => a.RootCause.Length > 0);
        if (attempt?.Classification is { } kind)
        {
            sb.AppendLine("### Diagnosis").AppendLine();
            sb.AppendLine($"- **Classification:** {FailureTriage.Name(kind)}" + (attempt.Confidence is { } confidence ? $" · confidence **{confidence}**" : ""));
            if (attempt.FixLocation is { } where)
            {
                sb.AppendLine($"- **Fix location:** {where.ReplaceLineEndings(" ")}");
            }
            foreach (var alternative in attempt.Alternatives)
            {
                sb.AppendLine($"- Considered: {alternative}");
            }
            sb.AppendLine();
        }
        if (run.Triage is { } triage && (triage.Hypotheses.Count > 0 || triage.SetupIssues.Count > 0 || triage.Repeats.Count > 0))
        {
            sb.AppendLine("### Triage").AppendLine().AppendLine(FailureTriage.Describe(triage).TrimEnd()).AppendLine();
        }
        if (attempt is not null)
        {
            sb.AppendLine("### Root cause").AppendLine().AppendLine(attempt.RootCause).AppendLine();
            if (attempt.Evidence.Count > 0)
            {
                sb.AppendLine("**Evidence**").AppendLine();
                foreach (var e in attempt.Evidence)
                {
                    sb.AppendLine($"- {e}");
                }
                sb.AppendLine();
            }
            var ambiguities = run.Attempts.SelectMany(a => a.Ambiguities).Distinct().ToList();
            if (ambiguities.Count > 0)
            {
                sb.AppendLine("**Unresolved ambiguity**").AppendLine();
                foreach (var a in ambiguities)
                {
                    sb.AppendLine($"- {a}");
                }
                sb.AppendLine();
            }
        }

        if (run.Patches.Count > 0)
        {
            sb.AppendLine("### Changes").AppendLine();
            sb.AppendLine("| File | State | Attempt | Why |").AppendLine("|---|---|---:|---|");
            foreach (var p in run.Patches)
            {
                var state = p.Applied ? (p.Created ? "Created (applied)" : "Applied") : "Not applied — " + (p.NotAppliedReason ?? "proposed only");
                sb.AppendLine($"| `{p.Path}`{(p.IsTest ? " (test)" : "")} | {Cell(state)} | {p.Iteration} | {Cell(p.Reason)} |");
            }
            sb.AppendLine();
            var testChanges = run.Attempts.Select(a => a.TestChanges).Where(t => t.Length > 0).Distinct().ToList();
            if (testChanges.Count > 0 || run.Patches.Any(p => p.IsTest))
            {
                sb.AppendLine("**Test changes and their evidence:** " + (testChanges.Count > 0 ? string.Join(" ", testChanges) : "none given.")).AppendLine();
            }
            sb.AppendLine(run.Patches.Any(p => p.Applied) ? "Diff of the changes (review it before you commit):" : "Proposed patch — **not applied** and **not verified**:").AppendLine();
            sb.AppendLine("```diff");
            foreach (var p in run.Patches)
            {
                sb.Append(p.Diff);
            }
            sb.AppendLine("```").AppendLine();
        }
        var refused = run.Attempts.SelectMany(a => a.Refused).Distinct().ToList();
        if (refused.Count > 0)
        {
            sb.AppendLine("**Refused edits**").AppendLine();
            foreach (var r in refused)
            {
                sb.AppendLine($"- {r}");
            }
            sb.AppendLine();
        }

        if (run.Attempts.Count > 1 || (run.Attempts.Count == 1 && run.Status != TestFixStatus.FixedAndVerified))
        {
            sb.AppendLine("### Attempts").AppendLine();
            sb.AppendLine("| Attempt | Diagnosis | Files changed | Verification |").AppendLine("|---:|---|---|---|");
            foreach (var a in run.Attempts)
            {
                var files = run.Patches.Where(p => p.Iteration == a.Number && p.Applied).Select(p => $"`{p.Path}`").ToList();
                var checks = run.Commands.Where(c => c.Iteration == a.Number).ToList();
                var verdict = checks.Count == 0 ? "not run" : checks.All(c => c.Verified || (c.Purpose.StartsWith("Build", StringComparison.Ordinal) && c.ExitCode == 0))
                    ? "passed" : string.Join("; ", checks.Where(c => !c.Verified).Select(c => $"{c.Purpose}: {TestFixService.Summary(c)}"));
                sb.AppendLine($"| {a.Number} | {Cell(Short(a.RootCause.Length > 0 ? a.RootCause : "(no diagnosis)", 220))} | {(files.Count == 0 ? "none" : string.Join(", ", files))} | {Cell(verdict)} |");
            }
            sb.AppendLine();
        }

        if (run.Commands.Count > 0)
        {
            sb.AppendLine("### Commands run").AppendLine();
            sb.AppendLine("| # | Purpose | Command | Exit code | Tests: executed / passed / failed / skipped | Result | Time |").AppendLine("|---:|---|---|---:|---|---|---:|");
            for (var i = 0; i < run.Commands.Count; i++)
            {
                var c = run.Commands[i];
                var tests = c.CountsFrom is null && c.Executed == 0 ? "—" : $"{c.Executed} / {c.Passed} / {c.Failed} / {c.Skipped}" + (c.Discovered is { } d && d != c.Executed + c.Skipped ? $" (of {d} found)" : "")
                                                                         + (c.CountsFrom is { } from ? $" ({from})" : "");
                sb.AppendLine($"| {i + 1} | {Cell(c.Purpose)} | `{Cell(c.CommandLine)}` | {c.ExitCode?.ToString() ?? "—"} | {tests} | {Outcome(c)} | {c.DurationMs / 1000.0:0.0} s |");
            }
            sb.AppendLine();
            var failing = run.Commands.Where(c => c.Failures.Count > 0).LastOrDefault();
            if (failing is not null && run.Status != TestFixStatus.FixedAndVerified && failing != FirstFailing(run))
            {
                sb.AppendLine($"#### Still failing (command {run.Commands.IndexOf(failing) + 1})").AppendLine();
                Failures(sb, failing);
            }

            sb.AppendLine($"Full output of every command (redacted): `{run.Commands[0].LogPath?[..run.Commands[0].LogPath!.LastIndexOf('/')]}` in the explorer's data folder"
                          + (run.LogFolder is { } folder ? $" (`{folder}`)." : ".")).AppendLine();
        }

        sb.AppendLine("### Verification").AppendLine();
        var verification = run.Commands.Where(c => c.Iteration > 0 && !c.Superseded).ToList();
        if (verification.Count == 0)
        {
            sb.AppendLine("- Nothing was verified" + (run.Patches.Any(p => p.Applied) ? " — the applied changes are **unverified**." : "."));
        }
        foreach (var c in verification.Where(c => c.Iteration == verification.Max(v => v.Iteration)))
        {
            var ok = c.Verified || (c.Purpose.StartsWith("Build", StringComparison.Ordinal) && c.ExitCode == 0);
            sb.AppendLine($"- {(ok ? "✅" : "❌")} {c.Purpose}: {TestFixService.Summary(c)}.");
        }
        foreach (var n in run.NotRun.Distinct())
        {
            sb.AppendLine($"- ⏭ Not run — {n}");
        }
        sb.AppendLine();

        if (run.Completed.Count > 0)
        {
            sb.AppendLine("### Progress").AppendLine();
            foreach (var step in run.Completed)
            {
                sb.AppendLine($"- {step}");
            }
            sb.AppendLine();
        }

        if (run.Remaining.Count > 0)
        {
            sb.AppendLine("### Remaining issues").AppendLine();
            foreach (var r in run.Remaining.Distinct())
            {
                sb.AppendLine($"- {r}");
            }
            sb.AppendLine();
        }
        if (run.NextActions.Count > 0)
        {
            sb.AppendLine("### Next actions").AppendLine();
            foreach (var a in run.NextActions.Distinct())
            {
                sb.AppendLine($"- {a}");
            }
            sb.AppendLine();
        }
        sb.AppendLine("_Test Fix changes files on this PC only. It never commits, pushes, publishes or deploys._");
        return sb.ToString();
    }

    /// <summary>The machine, tools and projects the runs used.</summary>
    private static void Environment(StringBuilder sb, TestFixRun run)
    {
        if (run.Project is not { } project)
        {
            return;
        }
        var lines = new List<string>(project.Environment);
        if (project.TestProjects.Count > 0)
        {
            lines.Add("Test projects: " + string.Join(", ", project.TestProjects.Select(t => $"`{t}`")));
        }
        if (project.Configurations.Count > 0)
        {
            lines.Add("Configurations defined: " + string.Join(", ", project.Configurations));
        }
        lines.AddRange(project.Notes);
        if (lines.Count == 0)
        {
            return;
        }
        sb.AppendLine("**Environment**").AppendLine();
        foreach (var line in lines)
        {
            sb.AppendLine($"- {line}");
        }
        sb.AppendLine();
    }

    private static CommandRun? FirstFailing(TestFixRun run) => run.Commands.FirstOrDefault(c => c.Failures.Count > 0 || c.Outcome is not (RunOutcome.Passed or RunOutcome.NoTestsRun));

    /// <summary>The failure as first seen: every failing test's message, its stack trace and the code it points at — enough to work on without running anything again.</summary>
    private static void Reproduced(StringBuilder sb, TestFixRun run)
    {
        var first = FirstFailing(run);
        if (first is null || first.Outcome is RunOutcome.Cancelled or RunOutcome.TimedOut && first.Failures.Count == 0 && first.Problems.Count == 0)
        {
            return;
        }
        sb.AppendLine($"### The failure, as reproduced (command {run.Commands.IndexOf(first) + 1})").AppendLine();
        sb.AppendLine($"`{first.CommandLine}` → exit code {first.ExitCode?.ToString() ?? "none"}, {first.Executed} executed, {first.Passed} passed, {first.Failed} failed, {first.Skipped} skipped"
                      + (first.CountsFrom is { } from ? $" (from the {from} results)" : "") + ".").AppendLine();
        Failures(sb, first);
    }

    /// <summary>Each failure in full (message, stack, the code at its frames), then build or configuration problems with the output's end.</summary>
    private static void Failures(StringBuilder sb, CommandRun command)
    {
        var shown = 0;
        var groups = command.Failures.GroupBy(f => (f.Message, f.StackTrace)).ToList();
        foreach (var group in groups)
        {
            if (++shown > 15)
            {
                sb.AppendLine($"… and {groups.Count - 15} more distinct failure(s): {string.Join(", ", groups.Skip(15).SelectMany(g => g).Select(x => $"`{x.Name}`").Distinct().Take(30))}.").AppendLine();
                break;
            }
            var names = group.Select(f => f.Name).Distinct().ToList();
            sb.AppendLine(names.Count == 1 ? $"**`{names[0]}`**" : $"**{names.Count} tests fail the same way:** {string.Join(", ", names.Select(n => $"`{n}`"))}").AppendLine();
            sb.AppendLine("```text").AppendLine(Short(group.Key.Message, 1500, keepLines: true));
            if (group.Key.StackTrace is { Length: > 0 } stack)
            {
                sb.AppendLine(stack);
            }
            sb.AppendLine("```").AppendLine();
        }
        if (command.Logged.Count > 0)
        {
            sb.AppendLine("Errors the code logged while the tests ran:").AppendLine();
            foreach (var logged in command.Logged)
            {
                sb.AppendLine("```text").AppendLine(logged).AppendLine("```").AppendLine();
            }
        }
        if (command.Excerpts.Count > 0)
        {
            sb.AppendLine("Code at those places, when it failed (`>` marks the line):").AppendLine();
            foreach (var e in command.Excerpts)
            {
                sb.AppendLine($"`{e.Path}` line {e.Line}:").AppendLine();
                sb.AppendLine("```text").AppendLine(e.Text).AppendLine("```").AppendLine();
            }
        }
        if (command.Failures.Count == 0 && (command.Problems.Count > 0 || command.OutputTail.Length > 0))
        {
            sb.AppendLine("```text");
            if (command.Problems.Count > 0)
            {
                sb.AppendLine(string.Join("\n", command.Problems.Take(15))).AppendLine("…");
            }
            sb.AppendLine(string.Join("\n", command.OutputTail.Split('\n').TakeLast(25))).AppendLine("```").AppendLine();
        }
    }

    private static string Headline(TestFixRun run)
    {
        var targets = run.TargetTests.Count == 0 ? "the failure" : run.TargetTests.Count == 1 ? $"`{run.TargetTests[0]}`" : $"{run.TargetTests.Count} failing tests";
        var applied = run.Patches.Count(p => p.Applied);
        return run.Status switch
        {
            TestFixStatus.FixedAndVerified => $"Fixed {targets}: {applied} file(s) changed locally, and every check that ran passed.",
            TestFixStatus.PartiallyResolved when applied == 0 => $"A patch for {targets} is proposed but **not applied** and **not verified**.",
            TestFixStatus.PartiallyResolved => $"Changes for {targets} are applied ({applied} file(s)), but not every check passes or could run.",
            _ => $"Test Fix could not fix {targets}: {run.Remaining.FirstOrDefault() ?? run.StopReason ?? "see below."}",
        };
    }

    private static string Outcome(CommandRun c) => c.Outcome switch
    {
        RunOutcome.Passed when c.Executed == 0 => "Passed (build)",
        RunOutcome.Passed => "✅ Passed",
        RunOutcome.TestsFailed => "❌ Tests failed",
        RunOutcome.BuildFailed => "❌ Build failed",
        RunOutcome.Aborted => "❌ Aborted (hang or crash)",
        RunOutcome.NoTestsRun => "⚠ No tests ran",
        RunOutcome.DiscoveryError => "⚠ Discovery error",
        RunOutcome.ConfigurationError => "⚠ Configuration problem",
        RunOutcome.MissingDependency => "⚠ Missing dependency",
        RunOutcome.ServiceUnavailable => "⚠ Service unavailable",
        RunOutcome.RunnerUnavailable => "⚠ Runner unavailable",
        RunOutcome.TimedOut => "⏱ Timed out",
        RunOutcome.Cancelled => "⏹ Stopped",
        _ => "❌ Failed",
    };

    private static string Cell(string text) => text.Replace("|", "\\|").ReplaceLineEndings(" ");

    private static string Short(string text, int max, bool keepLines = false)
    {
        text = keepLines ? text.Trim() : text.ReplaceLineEndings(" ").Trim();
        return text.Length <= max ? text : text[..max] + "…";
    }
}
