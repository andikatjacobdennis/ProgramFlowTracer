using System.Diagnostics;
using System.Text;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using DocGen.Analysis.Indexing;

namespace DocGen.Explorer.Engine.TestFix;

/// <summary>What kind of failure it is — and so which layer owns the fix.</summary>
[JsonConverter(typeof(JsonStringEnumConverter))]
public enum FailureClass
{
    /// <summary>The code under test is wrong: fix the production code.</summary>
    ProductionDefect,
    /// <summary>The test expects something the intended behaviour no longer is (or never was): fix the test.</summary>
    OutdatedTestExpectation,
    /// <summary>The test's setup, teardown or shared state is wrong (leaks between tests, order dependence): fix the fixture.</summary>
    FixtureOrIsolation,
    /// <summary>The machine, a tool, a package feed or a service differs from what the tests need: fix the environment, not the code.</summary>
    Environment,
    /// <summary>Passes and fails without a change (timing, concurrency, randomness, an external service): fix what makes it nondeterministic.</summary>
    Flaky,
    /// <summary>The runner or the investigation itself went wrong (wrong tests run, results misread).</summary>
    ToolDefect,
    /// <summary>The evidence does not settle it: say what is missing.</summary>
    Unresolved,
}

/// <summary>A problem that stops the tests from running at all (restore, SDK, runtime, feed), found in a command's output.</summary>
public sealed class SetupIssue
{
    /// <summary>package-audit | runtime-missing | sdk-missing | package-not-found | feed-unreachable | file-locked | target-framework | out-of-memory</summary>
    public string Kind { get; set; } = "";
    public string Summary { get; set; } = "";

    /// <summary>The project the problem is in (repository-relative), when the output names one.</summary>
    public string? Project { get; set; }

    /// <summary>Extra arguments that let the tests run here without changing any file (an environment adjustment), or null.</summary>
    public string? Workaround { get; set; }
    public string Evidence { get; set; } = "";
}

/// <summary>What one failure shows about itself: where it was thrown, what kind, and what in its path depends on the environment.</summary>
public sealed class FailureSignal
{
    public string Test { get; set; } = "";

    /// <summary>setup | teardown | test-body | production-code | framework | unknown</summary>
    public string Where { get; set; } = "unknown";
    public string? ThrowingFrame { get; set; }
    public string? ExceptionType { get; set; }

    /// <summary>The assertion compares generated values (hashes, IDs, GUIDs) of the same shape: an expectation recorded from an earlier output.</summary>
    public string? GeneratedValues { get; set; }

    /// <summary>Things on the failure's path that differ between machines or runs (hardware, clock, culture, network, OS, randomness, concurrency).</summary>
    public List<string> EnvironmentApis { get; set; } = [];

    /// <summary>A file or program the test needs that is not there (an application to start, a build output, a data file).</summary>
    public string? MissingPrerequisite { get; set; }
}

/// <summary>A recent commit that touched the failing test or the code it runs.</summary>
public sealed class ChangeRecord
{
    public string Sha { get; set; } = "";
    public string Date { get; set; } = "";
    public string Subject { get; set; } = "";
    public List<string> Files { get; set; } = [];
    public bool TouchesTests { get; set; }
    public bool TouchesProduction { get; set; }

    /// <summary>The commit checked out: listed whatever files it touches, since a failure that is new appears with it.</summary>
    public bool IsCheckedOut { get; set; }

    /// <summary>Whether it touches the failing tests' files or the code they were traced to (the checked-out commit may not).</summary>
    public bool OnPath { get; set; } = true;
}

/// <summary>A candidate explanation, with the evidence for and against it.</summary>
public sealed class Hypothesis
{
    public FailureClass Class { get; set; }

    /// <summary>high | medium | low</summary>
    public string Confidence { get; set; } = "low";
    public List<string> For { get; set; } = [];
    public List<string> Against { get; set; } = [];
}

/// <summary>Everything Test Fix measured about the failure before any diagnosis: kept in the run and given to the model.</summary>
public sealed class TriageResult
{
    public List<SetupIssue> SetupIssues { get; set; } = [];

    /// <summary>Environment adjustments made so the tests could run (never a file change), in plain words.</summary>
    public List<string> Adjustments { get; set; } = [];

    /// <summary>The failing tests as the logs named them, and as resolved in the code ("Namespace.Class.Method").</summary>
    public List<string> NamedInLogs { get; set; } = [];
    public List<string> Resolved { get; set; } = [];

    /// <summary>The test projects that own them (repository-relative).</summary>
    public List<string> OwningProjects { get; set; } = [];

    /// <summary>The one project the tests run in when they all belong to it (rather than the whole solution); null otherwise.</summary>
    public string? Target { get; set; }

    /// <summary>MSBuild arguments every test command adds (the adjustments above, and the solution's folder when one project runs alone).</summary>
    public List<string> ExtraArguments { get; set; } = [];

    /// <summary>When the local failure is not the one the logs show (another exception, another place): what differs.</summary>
    public string? DiffersFromLogs { get; set; }

    /// <summary>How often each failing test failed over the reproduction and the reruns ("Ns.C.M" → "3/3").</summary>
    public Dictionary<string, string> Repeats { get; set; } = [];

    /// <summary>deterministic | intermittent | passed-on-rerun | not-reproduced | not-run</summary>
    public string Reproducibility { get; set; } = "not-run";

    /// <summary>The failing tests passed when run on their own after failing in a larger run (order or shared-state dependence).</summary>
    public bool? PassesAlone { get; set; }

    public List<FailureSignal> Signals { get; set; } = [];
    public List<ChangeRecord> RecentChanges { get; set; } = [];

    /// <summary>The newest change to the code the failing tests run, as a short diff.</summary>
    public string? RecentDiff { get; set; }

    public List<Hypothesis> Hypotheses { get; set; } = [];
}

/// <summary>
/// Measuring a failure before diagnosing it: which tests the logs name and which project owns them, what keeps the tests
/// from running (with a safe adjustment when there is one), how reproducible the failure is, where it was thrown, what on
/// its path depends on the machine, what changed recently — and the explanations this evidence supports, ranked.
/// </summary>
public static partial class FailureTriage
{
    // ---------------------------------------------------------------- Failing tests named in logs

    /// <summary>
    /// Test names in pasted CI output, a stack trace or a runner's console: xUnit's "[FAIL]" lines (with or without the
    /// "[xUnit.net 00:00:01.23]" prefix, theory arguments dropped), "Failed Name [12 ms]" lines, NUnit/MSTest lines, and the
    /// test-code frames of stack traces. Names may be "Ns.Class.Method", "Class.Method" or only "Method".
    /// </summary>
    public static List<string> NamesInLogs(string text)
    {
        var names = new List<string>();
        foreach (var line in text.Replace("\r\n", "\n").Split('\n'))
        {
            var l = LogPrefixRegex().Replace(line, "").Trim();
            if (XunitFailLineRegex().Match(l) is { Success: true } x)
            {
                names.Add(StripArguments(x.Groups[1].Value));
            }
            else if (FailedLineRegex().Match(l) is { Success: true } f)
            {
                names.Add(StripArguments(f.Groups[1].Value));
            }
        }
        names.AddRange(TestResults.FailingTestNames(text));
        // Stack frames in test code: "at Ns.FooTests.Bar(…)" / "at Ns.FooFixture.Setup() in …/FooFixture.cs:line 18".
        foreach (Match m in TestFrameRegex().Matches(text))
        {
            names.Add(m.Groups[1].Value);
        }
        return names.Select(n => n.Trim().Trim('.')).Where(n => n.Length > 1 && !n.StartsWith("System.", StringComparison.Ordinal))
            .Distinct(StringComparer.Ordinal).Take(60).ToList();
    }

    private static string StripArguments(string name)
    {
        var paren = name.IndexOf('(');
        return (paren > 0 ? name[..paren] : name).Trim();
    }

    /// <summary>
    /// The test methods the names stand for, found in the code index ("Ns.Class.Method"), and the test projects that own them.
    /// A short name ("Method") counts only when it names one test method or a few in one class.
    /// </summary>
    public static (List<string> Tests, List<string> Projects) Resolve(CodeIndex? code, IReadOnlyList<string> names)
    {
        if (code is null || names.Count == 0)
        {
            return ([], []);
        }
        var tests = code.TestMethods.ToList();
        var found = new List<SymbolRecord>();
        var byClass = new List<SymbolRecord>();
        foreach (var name in names)
        {
            var parts = name.Split('.');
            var method = parts[^1];
            var candidates = tests.Where(t => t.Name == method).ToList();
            if (candidates.Count == 0)
            {
                // A test marked by the repository's own attribute ([WindowsOnlyFact] deriving from [Fact]…) is not known as
                // a test to the index: a method of that name in a test project stands for it.
                // Not a fixture hook or a helper the tests call (Setup, GivenOrderWithLines): those stand for their class below.
                candidates = FixtureHookRegex().IsMatch(method) || code.CallersByName(method).Count > 0 ? []
                    : code.ByName(method).Where(s => !SymbolKinds.IsType(s.Kind) && code.IsTestProject(s.Project)).ToList();
            }
            var whole = candidates.Count == 0;
            if (whole)
            {
                // A fixture method in a stack frame (Setup, TearDown) or a class name: the class's tests.
                var type = parts.Length >= 2 ? parts[^2] : method;
                candidates = tests.Where(t => t.Container?.Split('.')[^1] == (parts.Length >= 2 ? type : method) && parts.Length >= 2).ToList();
                if (candidates.Count > 20)
                {
                    candidates = [];
                }
            }
            if (parts.Length >= 2)
            {
                var qualified = string.Join('.', parts[..^1]);
                var narrowed = candidates.Where(t => t.Container is { } c && (c == qualified || c.EndsWith("." + qualified, StringComparison.Ordinal))).ToList();
                if (narrowed.Count > 0)
                {
                    candidates = narrowed;
                }
            }
            if (candidates.Count > 0 && candidates.Select(c => c.Container).Distinct().Count() <= 3)
            {
                (whole ? byClass : found).AddRange(candidates);
            }
        }
        // A class's tests stand in for a failing Setup or TearDown only when the logs name none of that class's tests.
        found.AddRange(byClass.Where(t => found.All(f => f.Container != t.Container)));
        var distinct = found.Distinct().ToList();
        var projects = distinct.Select(t => code.Projects.TryGetValue(t.Project, out var p) ? p.Path : null).OfType<string>()
            .Select(p => p.Replace('\\', '/')).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        return (distinct.Select(t => t.Container + "." + t.Name).Distinct(StringComparer.Ordinal).ToList(), projects);
    }

    /// <summary>A dotnet test filter that selects exactly these tests (methods by their full name; theory cases included).</summary>
    public static string FilterFor(IEnumerable<string> fullNames)
        => string.Join("|", fullNames.Distinct(StringComparer.Ordinal).Select(n => $"FullyQualifiedName~{n}"));

    // ---------------------------------------------------------------- What keeps the tests from running

    /// <summary>Setup problems in a command's output, with a safe environment adjustment where one exists.</summary>
    public static List<SetupIssue> SetupIssues(string output)
    {
        var issues = new List<SetupIssue>();
        void Add(string kind, string summary, Match m, string? workaround, Group? project = null)
        {
            if (issues.Any(i => i.Kind == kind && i.Project == (project?.Value is { Length: > 0 } pr ? Shorten(pr) : null)))
            {
                return;
            }
            issues.Add(new SetupIssue
            {
                Kind = kind, Summary = summary, Workaround = workaround, Evidence = m.Value.Trim().Length > 300 ? m.Value.Trim()[..300] + "…" : m.Value.Trim(),
                Project = project?.Value is { Length: > 0 } p ? Shorten(p) : null,
            });
        }
        foreach (Match m in AuditRegex().Matches(output))
        {
            Add("package-audit",
                "NuGet's vulnerability audit reports a package with a known advisory and the repository treats warnings as errors. The advisory data is today's, newer than the code: "
                + "this is the environment, not a defect in the failing tests.", m, "-p:NuGetAudit=false", m.Groups["project"]);
        }
        // A project that targets several frameworks, one of whose runtimes is missing here: run the newest one that is installed.
        var installed = InstalledRuntimeRegex().Matches(output).Select(m => int.Parse(m.Groups[1].Value)).ToHashSet();
        var targeted = TargetFolderRegex().Matches(output).Select(m => (Tfm: m.Groups[1].Value, Major: int.Parse(m.Groups[2].Value))).Distinct().ToList();
        var runnable = targeted.Where(t => installed.Contains(t.Major)).OrderByDescending(t => t.Major).Select(t => t.Tfm).FirstOrDefault();
        foreach (Match m in RuntimeMissingRegex().Matches(output))
        {
            Add("runtime-missing", $"The tests need a .NET runtime{(m.Groups["version"].Value is { Length: > 0 } v ? " " + v : "")} that is not installed here"
                + (runnable is null ? "." : $"; the project also targets {runnable}, which is, so it runs on that framework only."), m, runnable is null ? null : $"-f {runnable}");
        }
        foreach (Match m in SdkMissingRegex().Matches(output))
        {
            Add("sdk-missing", "The .NET SDK the repository asks for (global.json or a target framework) is not installed here.", m, null);
        }
        foreach (Match m in PackageNotFoundRegex().Matches(output))
        {
            Add("package-not-found", "A package or version could not be found in the configured feeds (a private feed, a removed version, or no access).", m, null, m.Groups["project"]);
        }
        foreach (Match m in FeedRegex().Matches(output))
        {
            Add("feed-unreachable", "A package feed could not be reached (network, proxy or credentials).", m, null);
        }
        foreach (Match m in FileLockedRegex().Matches(output))
        {
            Add("file-locked", "A build output file was locked by another process (parallel builds or a running test host): retry once the lock is gone.", m, null);
        }
        foreach (Match m in TargetFrameworkRegex().Matches(output))
        {
            Add("target-framework", "A project targets a framework this SDK cannot build.", m, null);
        }
        foreach (Match m in OomRegex().Matches(output))
        {
            Add("out-of-memory", "The process ran out of memory or was killed by the system (exit code 137).", m, null);
        }
        return issues;
    }

    private static string Shorten(string path)
    {
        var p = path.Replace('\\', '/').Trim();
        foreach (var marker in new[] { "/src/", "/tests/", "/test/" })
        {
            var i = p.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
            if (i >= 0)
            {
                return p[(i + 1)..];
            }
        }
        return Path.GetFileName(p);
    }

    // ---------------------------------------------------------------- Where it failed, and what on its path varies

    /// <summary>Where each failure was thrown, its exception, generated-value comparisons and environment-dependent code on its path.</summary>
    public static List<FailureSignal> Signals(IEnumerable<TestFailure> failures, string root, CodeIndex? code, IReadOnlyList<string> testProjects, IReadOnlyList<string> pathFiles)
    {
        var signals = new List<FailureSignal>();
        foreach (var failure in failures.GroupBy(f => f.Name).Select(g => g.First()).Take(12))
        {
            var text = failure.Message + "\n" + failure.StackTrace;
            var signal = new FailureSignal { Test = failure.Name };
            signal.ExceptionType = ExceptionTypeRegex().Match(text) is { Success: true } e ? e.Groups[1].Value : AssertionRegex().IsMatch(text) ? "assertion" : null;
            if (MissingPrerequisiteRegex().Match(text) is { Success: true } missing)
            {
                signal.MissingPrerequisite = missing.Value.Trim();
            }
            if (SetupMarkerRegex().IsMatch(text))
            {
                signal.Where = "setup";
            }
            else if (TeardownMarkerRegex().IsMatch(text))
            {
                signal.Where = "teardown";
            }
            var frames = TestResults.StackLocations(text);
            var first = frames.FirstOrDefault(f => !f.File.Contains("/_/", StringComparison.Ordinal));
            if (first != default)
            {
                var relative = Relative(first.File, root);
                signal.ThrowingFrame = $"{relative}:{first.Line}";
                if (signal.Where == "unknown")
                {
                    signal.Where = Patches.IsTestPath(relative, testProjects) ? "test-body" : "production-code";
                }
            }
            else if (signal.Where == "unknown" && FrameworkFrameRegex().IsMatch(text))
            {
                signal.Where = "framework";
            }
            if (ExpectedActualRegex().Match(failure.Message) is { Success: true } ea && SameShape(ea.Groups["expected"].Value, ea.Groups["actual"].Value))
            {
                signal.GeneratedValues = $"expected \"{ea.Groups["expected"].Value}\", actual \"{ea.Groups["actual"].Value}\": both look generated (an ID, hash or GUID of the same shape) — "
                                         + "the expectation was recorded from an earlier output, so a change to how they are made, or to their inputs, changes them";
            }
            else if (GuidRegex().Matches(failure.Message).Count >= 2)
            {
                signal.GeneratedValues = "the expected and actual values are GUID-like: an expectation recorded from an earlier output";
            }
            signals.Add(signal);
        }
        // What the failing tests and the code they run touch that differs between machines or runs.
        var apis = new SortedSet<string>(StringComparer.Ordinal);
        foreach (var file in pathFiles.Take(30))
        {
            var full = Path.Combine(root, file.Replace('/', Path.DirectorySeparatorChar));
            string text;
            try
            {
                text = File.Exists(full) && new FileInfo(full).Length < 1_000_000 ? File.ReadAllText(full) : "";
            }
            catch (IOException)
            {
                continue;
            }
            // Code only: a link in a comment ("see https://example.com/…") is not a network call.
            text = CommentRegex().Replace(text, "$1");
            foreach (var (category, pattern) in EnvironmentPatterns)
            {
                if (pattern.Match(text) is { Success: true } m)
                {
                    apis.Add($"{category}: `{m.Value.Trim()}` in {file}");
                }
            }
        }
        foreach (var signal in signals)
        {
            signal.EnvironmentApis = apis.Take(12).ToList();
        }
        return signals;
    }

    private static readonly (string Category, Regex Pattern)[] EnvironmentPatterns =
    [
        ("hardware", new Regex(@"\b(ManagementObjectSearcher|Win32_Processor|ProcessorCount|ProcessorFrequency|NominalFrequency|MaxClockSpeed|CurrentClockSpeed|/proc/cpuinfo|sysctl|wmic)\b", RegexOptions.Compiled)),
        ("clock and timing", new Regex(@"\b(DateTime\.Now|DateTime\.Today|DateTimeOffset\.Now|Stopwatch\.(?:StartNew|GetTimestamp|Frequency)|Thread\.Sleep|Task\.Delay|TimeZoneInfo\.Local)\b", RegexOptions.Compiled)),
        ("culture", new Regex(@"\b(CultureInfo\.CurrentCulture|CultureInfo\.CurrentUICulture|Thread\.CurrentThread\.CurrentCulture)\b", RegexOptions.Compiled)),
        ("network", new Regex(@"\b(HttpClient|WebRequest|TcpClient|Socket|Dns\.GetHost\w*)\b|https?://(?!localhost|127\.0\.0\.1)[\w.-]+\.\w+", RegexOptions.Compiled)),
        ("operating system", new Regex(@"\b(RuntimeInformation\.IsOSPlatform|OperatingSystem\.Is\w+|Environment\.OSVersion|Registry\.\w+)\b", RegexOptions.Compiled)),
        ("randomness", new Regex(@"\b(new Random\(\)|Random\.Shared|Guid\.NewGuid)\b", RegexOptions.Compiled)),
        ("concurrency", new Regex(@"\b(Task\.Run|Parallel\.\w+|new Thread\(|ThreadPool\.\w+|Interlocked\.\w+)\b", RegexOptions.Compiled)),
    ];

    /// <summary>Two values of the same generated shape: same length, same non-alphanumeric skeleton, mostly letters/digits that differ.</summary>
    public static bool SameShape(string expected, string actual)
    {
        if (expected.Length < 6 || expected.Length != actual.Length || expected == actual)
        {
            return false;
        }
        static string Skeleton(string s) => new(s.Select(c => char.IsLetterOrDigit(c) ? 'x' : c).ToArray());
        if (Skeleton(expected) != Skeleton(actual))
        {
            return false;
        }
        var differing = expected.Zip(actual).Count(p => p.First != p.Second);
        var alnum = expected.Count(char.IsLetterOrDigit);
        // Not a word with a typo: most of the characters differ, and it does not read as prose.
        return differing * 2 >= alnum && !expected.Contains(' ', StringComparison.Ordinal);
    }

    // ---------------------------------------------------------------- What changed recently

    /// <summary>The latest commits touching the failing tests' files and the code they run (git; empty outside a repository).</summary>
    public static async Task<(List<ChangeRecord> Changes, string? Diff)> RecentChangesAsync(string root, IReadOnlyList<string> testFiles, IReadOnlyList<string> codeFiles,
        IReadOnlyList<string> testProjects, CancellationToken ct, int max = 8)
    {
        var files = testFiles.Concat(codeFiles).Where(f => f.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).Take(40).ToList();
        if (files.Count == 0 || !Directory.Exists(Path.Combine(root, ".git")) && !File.Exists(Path.Combine(root, ".git")))
        {
            return ([], null);
        }
        var log = await GitAsync(root, ["log", $"-n{max}", "--date=short", "--name-only", "--format=@@%h|%ad|%s", "--", .. files], ct);
        // The checked-out commit first, whichever files it changed: the traced path can miss the file that matters
        // (a ToString used in a hash, a package version), and a failure that started with it is the usual case.
        var head = await GitAsync(root, ["log", "-n1", "--date=short", "--name-only", "--format=@@%h|%ad|%s", "HEAD"], ct);
        var changes = new List<ChangeRecord>();
        ChangeRecord? current = null;
        foreach (var line in (head + "\n" + log).Split('\n').Select(l => l.TrimEnd('\r')))
        {
            if (line.StartsWith("@@", StringComparison.Ordinal))
            {
                var parts = line[2..].Split('|', 3);
                if (changes.Any(c => c.Sha == parts[0]))
                {
                    current = null;
                    continue;
                }
                current = new ChangeRecord { Sha = parts[0], Date = parts.ElementAtOrDefault(1) ?? "", Subject = parts.ElementAtOrDefault(2) ?? "", IsCheckedOut = changes.Count == 0 };
                changes.Add(current);
            }
            else if (current is not null && line.Length > 0)
            {
                current.Files.Add(line);
                if (Patches.IsTestPath(line, testProjects))
                {
                    current.TouchesTests = true;
                }
                else
                {
                    current.TouchesProduction = true;
                }
            }
        }
        if (changes.FirstOrDefault(c => c.IsCheckedOut) is { } checkedOut)
        {
            checkedOut.OnPath = checkedOut.Files.Any(f => files.Contains(f, StringComparer.OrdinalIgnoreCase));
        }
        async Task<string> ShowAsync(ChangeRecord change, int max)
        {
            // Its source files first (not its documentation or project files).
            var codeOnly = change.Files.Where(f => !Patches.IsTestPath(f, testProjects)).OrderBy(f => SourceFileRegex().IsMatch(f) ? 0 : 1).Take(6).ToList();
            var text = await GitAsync(root, ["show", "--format=commit %h %ad%n%s%n%n%b", "--date=short", "--unified=2", change.Sha, "--", .. codeOnly], ct);
            var lines = text.Replace("\r\n", "\n").Split('\n');
            return string.Join("\n", lines.Take(max)) + (lines.Length > max ? $"\n… ({lines.Length - max} more lines)" : "");
        }
        string? diff = null;
        // The newest change to the code under test (not only to tests): its diff, short.
        if (changes.FirstOrDefault(c => c.TouchesProduction && c.OnPath) is { } newest)
        {
            diff = await ShowAsync(newest, 80);
        }
        // The checked-out commit's source changes too, when the traced path does not reach them: they may still be the cause.
        if (changes.FirstOrDefault(c => c.IsCheckedOut && !c.OnPath && c.Files.Any(f => SourceFileRegex().IsMatch(f) && !Patches.IsTestPath(f, testProjects))) is { } checkedOutCode)
        {
            diff = (diff is null ? "" : diff + "\n\n") + "(the commit checked out, outside the traced path)\n" + await ShowAsync(checkedOutCode, 50);
        }
        return (changes, diff);
    }

    private static async Task<string> GitAsync(string root, IEnumerable<string> arguments, CancellationToken ct)
    {
        try
        {
            var info = new ProcessStartInfo("git") { WorkingDirectory = root, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true };
            foreach (var a in arguments)
            {
                info.ArgumentList.Add(a);
            }
            info.StandardOutputEncoding = Encoding.UTF8;
            using var process = Process.Start(info);
            if (process is null)
            {
                return "";
            }
            using var limit = CancellationTokenSource.CreateLinkedTokenSource(ct);
            limit.CancelAfter(TimeSpan.FromSeconds(30));
            var output = await process.StandardOutput.ReadToEndAsync(limit.Token);
            await process.WaitForExitAsync(limit.Token);
            return process.ExitCode == 0 ? output : "";
        }
        catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or InvalidOperationException or OperationCanceledException or IOException)
        {
            return "";
        }
    }

    // ---------------------------------------------------------------- The explanations the evidence supports

    /// <summary>Candidate explanations, best first, each with the evidence for and against (none is a conclusion).</summary>
    public static List<Hypothesis> Rank(TriageResult t, bool testsRan)
    {
        var all = new List<Hypothesis>();
        Hypothesis H(FailureClass c)
        {
            var h = all.FirstOrDefault(x => x.Class == c);
            if (h is null)
            {
                h = new Hypothesis { Class = c };
                all.Add(h);
            }
            return h;
        }
        var score = new Dictionary<FailureClass, int>();
        void Up(FailureClass c, int by, string why)
        {
            H(c).For.Add(why);
            score[c] = score.GetValueOrDefault(c) + by;
        }
        void Down(FailureClass c, int by, string why)
        {
            H(c).Against.Add(why);
            score[c] = score.GetValueOrDefault(c) - by;
        }

        if (!testsRan && t.SetupIssues.Count > 0)
        {
            Up(FailureClass.Environment, 6, "the tests could not run here: " + string.Join("; ", t.SetupIssues.Select(i => i.Kind).Distinct()));
        }
        if (t.SetupIssues.Count > 0 && testsRan)
        {
            H(FailureClass.Environment).For.Add("setup problems were met and worked around (" + string.Join("; ", t.SetupIssues.Select(i => i.Kind).Distinct()) + "); they are separate from the test failure");
        }
        switch (t.Reproducibility)
        {
            case "deterministic":
                Down(FailureClass.Flaky, 3, $"it failed every time ({string.Join(", ", t.Repeats.Values.Distinct())})");
                break;
            case "intermittent":
                Up(FailureClass.Flaky, 5, $"it failed only some of the times it ran ({string.Join(", ", t.Repeats.Values.Distinct())})");
                break;
            case "passed-on-rerun":
                Up(FailureClass.Flaky, 5, "it failed once and passed when run again");
                break;
            case "not-reproduced":
                Up(FailureClass.Flaky, 2, "it did not fail here, although the logs show it failing elsewhere");
                Up(FailureClass.Environment, 2, "it did not fail here: the machine, OS or services differ from where it failed");
                Up(FailureClass.Unresolved, 3, "without a local failure the cause cannot be confirmed by running it");
                break;
        }
        if (t.PassesAlone == true)
        {
            Up(FailureClass.FixtureOrIsolation, 5, "it passes when run alone but fails with the other tests: shared state or order dependence");
        }
        foreach (var s in t.Signals)
        {
            if (s.MissingPrerequisite is { } missing)
            {
                Up(FailureClass.Environment, 5, $"{s.Test}: something the test needs is not there — {missing} (a build output, an application to start, a tool or a data file)");
            }
            switch (s.Where)
            {
                case "setup" or "teardown" when s.MissingPrerequisite is null:
                    Up(FailureClass.FixtureOrIsolation, 3, $"{s.Test} failed in its {s.Where}, before or after the test's own check");
                    break;
                case "production-code":
                    Up(FailureClass.ProductionDefect, 2, $"{s.Test}: the exception was thrown in production code ({s.ThrowingFrame})");
                    break;
                case "test-body" when s.ExceptionType == "assertion":
                    Up(FailureClass.ProductionDefect, 1, $"{s.Test}: an assertion failed in the test — the code returned something else than expected");
                    Up(FailureClass.OutdatedTestExpectation, 1, $"{s.Test}: an assertion failed — either the code or the expectation is wrong");
                    break;
            }
            if (s.ExceptionType is { } type && ServiceRegex().IsMatch(type))
            {
                Up(FailureClass.Environment, 3, $"{s.Test}: {type} — a connection or service problem");
            }
            if (s.GeneratedValues is not null)
            {
                Up(FailureClass.OutdatedTestExpectation, 3, $"{s.Test}: {s.GeneratedValues}");
            }
        }
        if (t.DiffersFromLogs is { } differs)
        {
            Up(FailureClass.Environment, 3, "the failure here is not the one in the logs (" + differs + "): this machine meets another problem first, so the logged failure is not reproduced");
            Up(FailureClass.Unresolved, 2, "the logged failure itself was not reproduced here");
        }
        var environmentApis = t.Signals.SelectMany(s => s.EnvironmentApis).Distinct().ToList();
        if (environmentApis.Any(a => a.StartsWith("hardware", StringComparison.Ordinal)))
        {
            Up(FailureClass.Environment, 3, "the failing path reads the hardware (" + environmentApis.First(a => a.StartsWith("hardware", StringComparison.Ordinal)) + "): results differ between machines");
        }
        if (environmentApis.Any(a => a.StartsWith("network", StringComparison.Ordinal)) && t.Reproducibility is "not-reproduced" or "intermittent")
        {
            Up(FailureClass.Flaky, 2, "the failing path reaches the network and the failure is not steady: an external service may be slow or unavailable");
        }
        if (environmentApis.Any(a => a.StartsWith("clock", StringComparison.Ordinal) || a.StartsWith("concurrency", StringComparison.Ordinal)) && t.Reproducibility is "intermittent" or "passed-on-rerun")
        {
            Up(FailureClass.Flaky, 2, "the failing path depends on timing or concurrency");
        }
        // Only changes to the tests or the code they run count here; the checked-out commit may touch neither.
        var onPath = t.RecentChanges.Where(c => c.OnPath).ToList();
        if (onPath.FirstOrDefault() is { } newest)
        {
            var lastTest = onPath.FirstOrDefault(c => c.TouchesTests);
            var lastCode = onPath.FirstOrDefault(c => c.TouchesProduction);
            if (lastCode is not null && (lastTest is null || onPath.IndexOf(lastCode) < onPath.IndexOf(lastTest)) && !lastCode.TouchesTests)
            {
                var why = $"the code under test changed after the test last did ({lastCode.Sha} {lastCode.Date} \"{lastCode.Subject}\") without updating it";
                Up(FailureClass.OutdatedTestExpectation, 2, why + " — if that change was intended, the expectation is outdated");
                Up(FailureClass.ProductionDefect, 2, why + " — if it was not intended, it is a regression");
            }
            if (newest.TouchesTests && !newest.TouchesProduction)
            {
                Up(FailureClass.OutdatedTestExpectation, 1, $"the newest change is to the tests only ({newest.Sha} \"{newest.Subject}\")");
            }
        }
        if (all.Count == 0 || score.Values.DefaultIfEmpty(0).Max() <= 0)
        {
            Up(FailureClass.Unresolved, 1, "the measurements alone do not point at one layer");
        }
        foreach (var h in all)
        {
            var s = score.GetValueOrDefault(h.Class);
            h.Confidence = s >= 6 ? "high" : s >= 3 ? "medium" : "low";
            // A cause in the code cannot be more than a lead while the failure does not happen here.
            if (t.Reproducibility is "not-reproduced" or "not-run" && h.Class is FailureClass.ProductionDefect or FailureClass.OutdatedTestExpectation)
            {
                h.Confidence = "low";
            }
        }
        return all.Where(h => score.GetValueOrDefault(h.Class) > 0 || h.Class == FailureClass.Unresolved)
            .OrderByDescending(h => score.GetValueOrDefault(h.Class)).ThenBy(h => h.Class).Take(4).ToList();
    }

    /// <summary>The triage as the model and the report read it.</summary>
    /// <summary>A classification as a reader would say it.</summary>
    public static string Name(FailureClass kind) => kind switch
    {
        FailureClass.ProductionDefect => "production defect",
        FailureClass.OutdatedTestExpectation => "outdated test expectation",
        FailureClass.FixtureOrIsolation => "fixture or isolation defect",
        FailureClass.Environment => "environment or dependency problem",
        FailureClass.Flaky => "flaky (nondeterministic) test",
        FailureClass.ToolDefect => "defect in the test tooling",
        _ => "unresolved",
    };

    public static string Describe(TriageResult t)
    {
        var sb = new StringBuilder();
        if (t.NamedInLogs.Count > 0)
        {
            sb.AppendLine($"- Failing tests named in the logs: {string.Join(", ", t.NamedInLogs.Take(12).Select(n => $"`{n}`"))}");
        }
        if (t.Resolved.Count > 0)
        {
            sb.AppendLine($"- Found in the code as: {string.Join(", ", t.Resolved.Take(12).Select(n => $"`{n}`"))}" + (t.OwningProjects.Count > 0 ? $" (in {string.Join(", ", t.OwningProjects.Select(p => $"`{p}`"))})" : ""));
        }
        foreach (var kind in t.SetupIssues.GroupBy(i => i.Kind))
        {
            var projects = kind.Select(i => i.Project).OfType<string>().Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            sb.AppendLine($"- Setup problem ({kind.Key}){(projects.Count == 0 ? "" : " in " + string.Join(", ", projects.Take(4).Select(p => $"`{p}`")) + (projects.Count > 4 ? $" and {projects.Count - 4} more" : ""))}: {kind.First().Summary}");
        }
        foreach (var a in t.Adjustments.Distinct())
        {
            sb.AppendLine($"- Environment adjustment made to run the tests (no file changed): {a}");
        }
        if (t.DiffersFromLogs is { } differs)
        {
            sb.AppendLine($"- The failure here is not the one in the logs: {differs}");
        }
        sb.AppendLine($"- Reproducibility: {t.Reproducibility}" + (t.Repeats.Count > 0 ? " — " + string.Join(", ", t.Repeats.Take(8).Select(r => $"`{r.Key}` failed {r.Value}")) : "")
                      + (t.PassesAlone == true ? "; passes when run alone" : t.PassesAlone == false ? "; fails when run alone too" : ""));
        foreach (var s in t.Signals.Take(8))
        {
            var parts = new List<string> { $"thrown in {s.Where}" + (s.ThrowingFrame is null ? "" : $" ({s.ThrowingFrame})") };
            if (s.ExceptionType is not null)
            {
                parts.Add(s.ExceptionType);
            }
            if (s.GeneratedValues is not null)
            {
                parts.Add(s.GeneratedValues);
            }
            if (s.MissingPrerequisite is not null)
            {
                parts.Add("missing: " + s.MissingPrerequisite);
            }
            sb.AppendLine($"- `{s.Test}`: {string.Join("; ", parts)}");
        }
        var apis = t.Signals.SelectMany(s => s.EnvironmentApis).Distinct().ToList();
        if (apis.Count > 0)
        {
            sb.AppendLine("- On the failing path, things that differ between machines or runs: " + string.Join("; ", apis.Take(8)));
        }
        if (t.RecentChanges.Count > 0)
        {
            sb.AppendLine("- Recent commits touching these tests or the code they run (newest first):");
            foreach (var c in t.RecentChanges.Take(6))
            {
                sb.AppendLine($"  - {c.Sha} {c.Date} \"{c.Subject}\"{(c.IsCheckedOut ? c.OnPath ? " (the commit checked out)" : " (the commit checked out; none of its files is on the traced path)" : "")} — {(c.TouchesProduction ? "code" : "")}{(c.TouchesProduction && c.TouchesTests ? " and " : "")}{(c.TouchesTests ? "tests" : "")}: {string.Join(", ", c.Files.Take(4))}");
            }
        }
        if (t.Hypotheses.Count > 0)
        {
            sb.AppendLine("- Explanations the measurements support (to confirm or reject, not conclusions):");
            foreach (var h in t.Hypotheses)
            {
                sb.AppendLine($"  - {Name(h.Class)} ({h.Confidence}): for — {string.Join("; ", h.For.Take(4))}" + (h.Against.Count > 0 ? $"; against — {string.Join("; ", h.Against.Take(3))}" : ""));
            }
        }
        return sb.ToString();
    }

    private static string Relative(string path, string root)
    {
        var p = path.Replace('\\', '/');
        var r = root.Replace('\\', '/').TrimEnd('/') + "/";
        if (p.StartsWith(r, StringComparison.OrdinalIgnoreCase))
        {
            return p[r.Length..];
        }
        // A CI path ("D:/a/Shop/Shop/Shop.Core/…", "./Shop.Core/…"): the shortest tail of it that is a file here.
        var parts = p.TrimStart('.', '/').Split('/', StringSplitOptions.RemoveEmptyEntries);
        for (var i = 0; i < parts.Length - 1; i++)
        {
            var tail = string.Join('/', parts[i..]);
            if (File.Exists(Path.Combine(root, tail.Replace('/', Path.DirectorySeparatorChar))))
            {
                return tail;
            }
        }
        return p.TrimStart('.', '/');
    }

    [GeneratedRegex(@"(An error occurred trying to start process '[^']+'|Could not find (?:a part of the path|file) '[^']+'|(?:FileNotFoundException|DirectoryNotFoundException)[^\n]{0,160}|The system cannot find the (?:file|path) specified|No such file or directory)")]
    private static partial Regex MissingPrerequisiteRegex();

    [GeneratedRegex(@"^(Set[Uu]p|Tear[Dd]own|OneTimeSet[Uu]p|OneTimeTear[Dd]own|Initialize|Cleanup|Dispose|DisposeAsync|InitializeAsync|TestInitialize|TestCleanup|ClassInitialize|ClassCleanup)$")]
    private static partial Regex FixtureHookRegex();

    // "  10.0.12 at [C:\Program Files\dotnet\shared\Microsoft.NETCore.App]"
    [GeneratedRegex(@"^\s*(\d+)\.\d+\.\d+ at \[[^\]]*Microsoft\.NETCore\.App\]", RegexOptions.Multiline)]
    private static partial Regex InstalledRuntimeRegex();

    // "…\bin\Debug\net10.0\Tests.dll" — the frameworks the test project was built for (not net4x, which has no such runtime).
    [GeneratedRegex(@"[\\/]bin[\\/][^\\/]+[\\/](net(\d+)\.\d+)(?:-[\w.]+)?[\\/]")]
    private static partial Regex TargetFolderRegex();

    // A /* block */ or a // line comment (not the "//" of "https://" inside a string).
    [GeneratedRegex(@"/\*.*?\*/|(^|[^:""])//[^\n]*", RegexOptions.Singleline | RegexOptions.Multiline)]
    private static partial Regex CommentRegex();

    /// <summary>The exception types named in a text ("System.InvalidOperationException", "Assert.Equal() Failure"…), short names.</summary>
    public static HashSet<string> ExceptionTypes(string text)
        => ExceptionTypeRegex().Matches(text).Select(m => m.Groups[1].Value.Split('.').Last()).ToHashSet(StringComparer.Ordinal);

    [GeneratedRegex(@"\.(cs|fs|vb|cpp|c|h|ts|js|py|java|kt|go|rs)$", RegexOptions.IgnoreCase)]
    private static partial Regex SourceFileRegex();

    [GeneratedRegex(@"^\s*\[(?:xUnit\.net|NUnit|MSTest)[^\]]*\]\s*")]
    private static partial Regex LogPrefixRegex();

    [GeneratedRegex(@"^([A-Za-z_][\w.`]*(?:\([^)]*\))?)\s+\[FAIL\]\s*$")]
    private static partial Regex XunitFailLineRegex();

    [GeneratedRegex(@"^(?:X\s+|✗\s+)?Failed\s+([A-Za-z_][\w.`]*(?:\(.*\))?)\s*\[[^\]]*\]\s*$")]
    private static partial Regex FailedLineRegex();

    [GeneratedRegex(@"\bat\s+((?:[A-Za-z_]\w*\.)+[A-Za-z_]\w*(?:Tests?|Fixture|Specs?)\.[A-Za-z_]\w*)\s*\(")]
    private static partial Regex TestFrameRegex();

    [GeneratedRegex(@"(?<project>[^\s:]+\.(?:cs|fs|vb)proj)\s*:\s*(?:error|warning)\s+NU190[1-4]:[^\n]*", RegexOptions.IgnoreCase)]
    private static partial Regex AuditRegex();

    [GeneratedRegex(@"(?:framework\s+'Microsoft\.(?:NETCore|AspNetCore|WindowsDesktop)\.App',\s*version\s+'(?<version>[\d.]+)'[^\n]*was not found|You must install or update \.NET to run this application[^\n]*)", RegexOptions.IgnoreCase)]
    private static partial Regex RuntimeMissingRegex();

    [GeneratedRegex(@"(?:A compatible \.NET SDK was not found[^\n]*|Requested SDK version:[^\n]*|NETSDK1045:[^\n]*)", RegexOptions.IgnoreCase)]
    private static partial Regex SdkMissingRegex();

    [GeneratedRegex(@"(?<project>[^\s:]+\.(?:cs|fs|vb)proj)?\s*:?\s*error\s+NU110[1-3]:[^\n]*", RegexOptions.IgnoreCase)]
    private static partial Regex PackageNotFoundRegex();

    [GeneratedRegex(@"error\s+NU130[0-1]:[^\n]*|Unable to load the service index[^\n]*", RegexOptions.IgnoreCase)]
    private static partial Regex FeedRegex();

    [GeneratedRegex(@"error\s+(?:CS2012|MSB3021|MSB3026|MSB3027):[^\n]*(?:being used by another process|cannot access the file|Cannot open)[^\n]*", RegexOptions.IgnoreCase)]
    private static partial Regex FileLockedRegex();

    [GeneratedRegex(@"error\s+NETSDK1(?:005|013|083|135|139):[^\n]*", RegexOptions.IgnoreCase)]
    private static partial Regex TargetFrameworkRegex();

    [GeneratedRegex(@"exit code 137\b[^\n]*|OutOfMemoryException[^\n]*", RegexOptions.IgnoreCase)]
    private static partial Regex OomRegex();

    [GeneratedRegex(@"\b((?:[A-Z]\w*\.)+\w*Exception)\b")]
    private static partial Regex ExceptionTypeRegex();

    [GeneratedRegex(@"Assert\.|Expected[:\s]|expected\s+.*\bbut\b|Should\(\)|\bShould\w*\b|Assertion", RegexOptions.IgnoreCase)]
    private static partial Regex AssertionRegex();

    [GeneratedRegex(@"--SetUp\b|\bSetUp\s*:|\bat\s+[\w.]+\.(?:Set[Uu]p|Setup|OneTimeSetUp|InitializeAsync|TestInitialize|Given\w*)\(", RegexOptions.None)]
    private static partial Regex SetupMarkerRegex();

    [GeneratedRegex(@"--TearDown\b|\bTearDown\s*:|\bat\s+[\w.]+\.(?:Tear[Dd]own|OneTimeTearDown|DisposeAsync|TestCleanup|Cleanup)\(", RegexOptions.None)]
    private static partial Regex TeardownMarkerRegex();

    [GeneratedRegex(@"\bat\s+(?:NUnit|Xunit|Microsoft\.VisualStudio\.TestTools)\.", RegexOptions.None)]
    private static partial Regex FrameworkFrameRegex();

    [GeneratedRegex(@"Expected:\s*""(?<expected>[^""]{4,200})""\s*\n?\s*(?:\[[^\]]*\]\s*)?Actual:\s*""(?<actual>[^""]{4,200})""", RegexOptions.IgnoreCase)]
    private static partial Regex ExpectedActualRegex();

    [GeneratedRegex(@"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", RegexOptions.IgnoreCase)]
    private static partial Regex GuidRegex();

    [GeneratedRegex(@"Socket|HttpRequest|Connection|Timeout", RegexOptions.IgnoreCase)]
    private static partial Regex ServiceRegex();
}
