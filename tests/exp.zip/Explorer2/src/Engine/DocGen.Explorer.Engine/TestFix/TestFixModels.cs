using System.Text.Json.Serialization;
using DocGen.Explorer.Engine.Models;

namespace DocGen.Explorer.Engine.TestFix;

/// <summary>What the person gives Test Fix: the failure, and how to run the tests.</summary>
public sealed class TestFixRequest
{
    /// <summary>What fails, in the person's words (may be empty when the attachments say it).</summary>
    public string Description { get; set; } = "";

    /// <summary>Failing test files, failure logs and stack traces, read as attachments (task data, never instructions).</summary>
    public List<Attachment> Attachments { get; set; } = [];

    /// <summary>Which tests to run: a runner filter or test names. Empty: the failing tests named in the logs, else all.</summary>
    public string? TestSelection { get; set; }

    /// <summary>The command that runs the tests, when the repository's own runner should not be worked out.</summary>
    public string? TestCommand { get; set; }

    /// <summary>The build configuration or environment (Debug, Release, QADebug…).</summary>
    public string? Configuration { get; set; }

    /// <summary>Write the fix to the files (else it is proposed only, unapplied).</summary>
    public bool ApplyChanges { get; set; } = true;

    /// <summary>Run the tests (else nothing is executed and every result is marked unverified).</summary>
    public bool RunCommands { get; set; } = true;

    /// <summary>Fix attempts before stopping (each: diagnose, patch, verify).</summary>
    public int MaxIterations { get; set; } = 3;

    /// <summary>Longest a single command may run.</summary>
    public int TimeoutSeconds { get; set; } = 600;

    /// <summary>Times the failing tests are run again after they fail, to tell a steady failure from a flaky one (0: not rerun).</summary>
    public int Reruns { get; set; } = 2;
}

/// <summary>Stages a run reports, in order.</summary>
public enum TestFixStage { Inspecting, Reproducing, Analysing, Patching, Applying, Verifying, Reporting }

/// <summary>How a run ended.</summary>
[JsonConverter(typeof(JsonStringEnumConverter))]
public enum TestFixStatus
{
    /// <summary>Still running (or interrupted, when no live run owns it).</summary>
    Running,
    /// <summary>The originally failing tests and every verification that ran pass.</summary>
    FixedAndVerified,
    /// <summary>Some of it is fixed, or a fix is proposed or applied but not fully verified.</summary>
    PartiallyResolved,
    /// <summary>The failure could not be reproduced, diagnosed or fixed: the report says why.</summary>
    Blocked,
}

/// <summary>What a command's run amounted to, from its exit code and output.</summary>
[JsonConverter(typeof(JsonStringEnumConverter))]
public enum RunOutcome
{
    Passed,
    TestsFailed,
    BuildFailed,
    /// <summary>The run was aborted: a test hung (no activity for the hang limit) or crashed the test host; the tests after it did not run.</summary>
    Aborted,
    /// <summary>No tests were found or none ran (never counts as a pass).</summary>
    NoTestsRun,
    DiscoveryError,
    ConfigurationError,
    MissingDependency,
    ServiceUnavailable,
    /// <summary>The runner itself (dotnet, npm, python…) could not be started.</summary>
    RunnerUnavailable,
    TimedOut,
    Cancelled,
    /// <summary>A non-zero exit that none of the above explains.</summary>
    Failed,
}

/// <summary>One failing test, as the runner reported it.</summary>
public sealed record TestFailure(string Name, string Message, string? StackTrace);

/// <summary>The source lines around a place a failure points at (a stack frame or a compile error), as they were then.</summary>
public sealed record CodeExcerpt(string Path, int Line, int FirstLine, string Text);

/// <summary>A command Test Fix ran, and what the runner said.</summary>
public sealed class CommandRun
{
    /// <summary>Why it ran: reproduce, rerun failing, related tests, build check, affected suite.</summary>
    public string Purpose { get; set; } = "";
    public int Iteration { get; set; }

    /// <summary>Run again with an environment adjustment: the later run stands for it in verification.</summary>
    public bool Superseded { get; set; }
    public string CommandLine { get; set; } = "";
    public string WorkingDirectory { get; set; } = "";
    public string? Configuration { get; set; }
    public int? ExitCode { get; set; }
    public long DurationMs { get; set; }
    public RunOutcome Outcome { get; set; }

    /// <summary>Tests the runner found (null when it did not say).</summary>
    public int? Discovered { get; set; }
    public int Executed { get; set; }
    public int Passed { get; set; }
    public int Failed { get; set; }
    public int Skipped { get; set; }

    /// <summary>Where the counts came from: "trx", "junit-xml" or "console".</summary>
    public string? CountsFrom { get; set; }

    public List<TestFailure> Failures { get; set; } = [];

    /// <summary>
    /// Errors the code logged while the tests ran (a server's unhandled exception behind an integration test's 500, a
    /// host that would not start), from the runner's captured output: often the only place the real cause shows.
    /// </summary>
    public List<string> Logged { get; set; } = [];

    /// <summary>The code at the places the failures point at, as it was when they happened.</summary>
    public List<CodeExcerpt> Excerpts { get; set; } = [];

    /// <summary>The lines that explain a build, configuration or dependency problem (redacted).</summary>
    public List<string> Problems { get; set; } = [];

    /// <summary>The whole output, redacted (data-folder relative).</summary>
    public string? LogPath { get; set; }

    /// <summary>The end of the output, redacted, for the report.</summary>
    public string OutputTail { get; set; } = "";

    /// <summary>Executed tests, all passed: the only result that counts as verified.</summary>
    [JsonIgnore]
    public bool Verified => Outcome == RunOutcome.Passed && Executed > 0 && Failed == 0;
}

/// <summary>A change to one file, as applied (or proposed) by Test Fix.</summary>
public sealed class FilePatch
{
    /// <summary>Repository-relative path, forward slashes.</summary>
    public string Path { get; set; } = "";
    public int Iteration { get; set; }

    /// <summary>Written to the file; false when only proposed (or refused).</summary>
    public bool Applied { get; set; }

    /// <summary>Why it was not applied (write access off, the file changed, the text was not found, the rules refused it).</summary>
    public string? NotAppliedReason { get; set; }

    /// <summary>The model's reason for the change.</summary>
    public string Reason { get; set; } = "";

    /// <summary>A test file (its changes need evidence that the test was wrong).</summary>
    public bool IsTest { get; set; }

    /// <summary>A new file.</summary>
    public bool Created { get; set; }

    public string BeforeHash { get; set; } = "";
    public string AfterHash { get; set; } = "";

    /// <summary>A unified diff of the change.</summary>
    public string Diff { get; set; } = "";

    /// <summary>The file's text before the change (data-folder relative), so the change can be undone.</summary>
    public string? OriginalPath { get; set; }
}

/// <summary>One diagnose → patch → verify attempt.</summary>
public sealed class FixAttempt
{
    public int Number { get; set; }
    public string RootCause { get; set; } = "";
    public List<string> Evidence { get; set; } = [];
    public List<string> Ambiguities { get; set; } = [];

    /// <summary>Why a test had to change (empty when no test changed).</summary>
    public string TestChanges { get; set; } = "";

    /// <summary>Edits the rules refused, and why.</summary>
    public List<string> Refused { get; set; } = [];
    public string? Model { get; set; }

    /// <summary>What kind of failure the diagnosis says it is (and so which layer owns the fix); null when it did not say.</summary>
    public FailureClass? Classification { get; set; }

    /// <summary>high | medium | low, as the diagnosis put it.</summary>
    public string? Confidence { get; set; }

    /// <summary>Where the fix belongs, and why there.</summary>
    public string? FixLocation { get; set; }

    /// <summary>Other explanations considered, and why each was ruled out.</summary>
    public List<string> Alternatives { get; set; } = [];
}

/// <summary>What the repository runs its tests with.</summary>
public sealed class ProjectProfile
{
    /// <summary>C#, JavaScript/TypeScript, Python, Java…; "unknown" when nothing was recognised.</summary>
    public string Language { get; set; } = "unknown";

    /// <summary>MSTest, NUnit, xUnit, Jest, Vitest, Mocha, pytest, JUnit…</summary>
    public List<string> Frameworks { get; set; } = [];

    /// <summary>dotnet test, npm test, pytest, mvn test, gradle test…</summary>
    public string Runner { get; set; } = "";

    /// <summary>The solution or build file the runner is pointed at (repository-relative), if any.</summary>
    public string? Target { get; set; }

    /// <summary>Test projects (repository-relative).</summary>
    public List<string> TestProjects { get; set; } = [];

    /// <summary>Configurations the solution defines (Debug, Release, QADebug…).</summary>
    public List<string> Configurations { get; set; } = [];

    /// <summary>Pinned tool versions (global.json SDK, packageManager, wrapper) found.</summary>
    public List<string> Pinned { get; set; } = [];

    /// <summary>What was found and where (for the report).</summary>
    public List<string> Notes { get; set; } = [];

    /// <summary>The machine and tools: OS, SDK or runtime versions (for the report).</summary>
    public List<string> Environment { get; set; } = [];
}

/// <summary>A Test Fix run: its inputs, every command and its results, the patches and the report. Saved after every step.</summary>
public sealed class TestFixRun
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N")[..12];
    public string RepositoryId { get; set; } = "";
    public string? ConversationId { get; set; }

    /// <summary>The assistant message that shows this run.</summary>
    public string? MessageId { get; set; }

    public DateTime StartedAt { get; set; } = DateTime.UtcNow;
    public DateTime? FinishedAt { get; set; }
    public TestFixStatus Status { get; set; } = TestFixStatus.Running;

    /// <summary>The run did not finish: stopped by the person, or the app closed while it ran.</summary>
    public bool Interrupted { get; set; }
    public string? StopReason { get; set; }

    public TestFixRequest Request { get; set; } = new();
    public ProjectProfile? Project { get; set; }

    /// <summary>The failing tests the run set out to fix (from the reproduction, else the logs).</summary>
    public List<string> TargetTests { get; set; } = [];

    /// <summary>What was measured about the failure before diagnosing it (names, setup problems, reproducibility, signals, history).</summary>
    public TriageResult? Triage { get; set; }

    /// <summary>Stages completed, in order, with a line each ("Reproducing failures: 2 of 5 tests fail").</summary>
    public List<string> Completed { get; set; } = [];

    public List<CommandRun> Commands { get; set; } = [];
    public List<FixAttempt> Attempts { get; set; } = [];
    public List<FilePatch> Patches { get; set; } = [];

    /// <summary>Checks that did not run, and why.</summary>
    public List<string> NotRun { get; set; } = [];
    public List<string> Remaining { get; set; } = [];
    public List<string> NextActions { get; set; } = [];

    /// <summary>Where the run's logs, results and kept originals are (absolute).</summary>
    public string? LogFolder { get; set; }

    /// <summary>The report (Markdown), once written.</summary>
    public string Report { get; set; } = "";
}
