using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace DocGen.Explorer.Engine.TestFix;

/// <summary>Test counts and failures from a runner's own output: its result files first, its console summary otherwise.</summary>
public sealed record TestCounts(int? Discovered, int Executed, int Passed, int Failed, int Skipped, IReadOnlyList<TestFailure> Failures, string From);

/// <summary>
/// Reads test results as the runners write them: Visual Studio TRX (dotnet test with MSTest, NUnit or xUnit), JUnit XML
/// (pytest, Maven Surefire, Gradle, Jest and Vitest reporters), and the summaries runners print. Nothing is assumed:
/// a count that the output does not give is not reported.
/// </summary>
public static partial class TestResults
{
    /// <summary>Totals over TRX files (one per test project).</summary>
    public static TestCounts? FromTrx(IEnumerable<string> trxFiles)
    {
        int total = 0, executed = 0, passed = 0, failed = 0, skipped = 0;
        var failures = new List<TestFailure>();
        var any = false;
        foreach (var file in trxFiles)
        {
            XDocument doc;
            try
            {
                doc = XDocument.Load(file);
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or System.Xml.XmlException)
            {
                continue;
            }
            any = true;
            var counters = doc.Descendants().FirstOrDefault(e => e.Name.LocalName == "Counters");
            if (counters is not null)
            {
                total += Int(counters, "total");
                executed += Int(counters, "executed");
                passed += Int(counters, "passed");
                failed += Int(counters, "failed") + Int(counters, "error") + Int(counters, "timeout") + Int(counters, "aborted");
                skipped += Int(counters, "notExecuted") + Int(counters, "inconclusive");
            }
            foreach (var result in doc.Descendants().Where(e => e.Name.LocalName == "UnitTestResult" && (string?)e.Attribute("outcome") is "Failed" or "Error" or "Timeout" or "Aborted"))
            {
                var info = result.Descendants().FirstOrDefault(e => e.Name.LocalName == "ErrorInfo");
                failures.Add(new TestFailure(
                    FullName(doc, result) ?? (string?)result.Attribute("testName") ?? "(unnamed test)",
                    Trim(info?.Elements().FirstOrDefault(e => e.Name.LocalName == "Message")?.Value),
                    Trim(info?.Elements().FirstOrDefault(e => e.Name.LocalName == "StackTrace")?.Value, 4000)));
            }
        }
        return any ? new TestCounts(total, executed, passed, failed, skipped, failures, "trx") : null;
    }

    /// <summary>Totals over JUnit XML files (testsuite or testsuites roots).</summary>
    public static TestCounts? FromJUnit(IEnumerable<string> xmlFiles)
    {
        int tests = 0, failed = 0, skipped = 0;
        var failures = new List<TestFailure>();
        var any = false;
        foreach (var file in xmlFiles)
        {
            XDocument doc;
            try
            {
                doc = XDocument.Load(file);
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or System.Xml.XmlException)
            {
                continue;
            }
            var cases = doc.Descendants().Where(e => e.Name.LocalName == "testcase").ToList();
            if (cases.Count == 0 && doc.Root?.Name.LocalName is not ("testsuite" or "testsuites"))
            {
                continue;
            }
            any = true;
            foreach (var testCase in cases)
            {
                tests++;
                var problem = testCase.Elements().FirstOrDefault(e => e.Name.LocalName is "failure" or "error");
                if (problem is not null)
                {
                    failed++;
                    var name = ((string?)testCase.Attribute("classname") is { Length: > 0 } c ? c + "." : "") + ((string?)testCase.Attribute("name") ?? "(unnamed test)");
                    failures.Add(new TestFailure(name, Trim((string?)problem.Attribute("message") ?? problem.Value.Split('\n')[0]), Trim(problem.Value, 4000)));
                }
                else if (testCase.Elements().Any(e => e.Name.LocalName == "skipped"))
                {
                    skipped++;
                }
            }
        }
        return any ? new TestCounts(tests, tests - skipped, tests - skipped - failed, failed, skipped, failures, "junit-xml") : null;
    }

    /// <summary>The counts a runner's summary line gives (dotnet test, NUnit console, Jest/Vitest, pytest, Maven, Gradle).</summary>
    public static TestCounts? FromConsole(string output)
    {
        // dotnet test (VSTest and Microsoft.Testing.Platform): "Failed!  - Failed: 1, Passed: 2, Skipped: 0, Total: 3"
        // and "total: 3, failed: 1, succeeded: 2, skipped: 0".
        var dotnet = DotnetSummaryRegex().Matches(output);
        if (dotnet.Count > 0)
        {
            int f = 0, p = 0, s = 0, t = 0;
            foreach (Match m in dotnet)
            {
                f += int.Parse(m.Groups["failed"].Value);
                p += int.Parse(m.Groups["passed"].Value);
                s += int.Parse(m.Groups["skipped"].Value);
                t += int.Parse(m.Groups["total"].Value);
            }
            return new TestCounts(t, f + p, p, f, s, ConsoleFailures(output), "console");
        }
        if (MtpSummaryRegex().Match(output) is { Success: true } mtp)
        {
            var (t, f, p, s) = (int.Parse(mtp.Groups["total"].Value), int.Parse(mtp.Groups["failed"].Value), int.Parse(mtp.Groups["passed"].Value), int.Parse(mtp.Groups["skipped"].Value));
            return new TestCounts(t, f + p, p, f, s, ConsoleFailures(output), "console");
        }
        // Jest / Vitest: "Tests:       1 failed, 2 passed, 3 total" / "Tests  1 failed | 2 passed (3)".
        if (JestSummaryRegex().Match(output) is { Success: true } jest)
        {
            var f = Count(jest.Value, "failed");
            var p = Count(jest.Value, "passed");
            var s = Count(jest.Value, "skipped") + Count(jest.Value, "todo");
            return new TestCounts(f + p + s, f + p, p, f, s, ConsoleFailures(output), "console");
        }
        // pytest: "=== 1 failed, 2 passed in 0.12s ===" / "no tests ran".
        if (PytestSummaryRegex().Match(output) is { Success: true } pytest)
        {
            var f = Count(pytest.Value, "failed") + Count(pytest.Value, "error") + Count(pytest.Value, "errors");
            var p = Count(pytest.Value, "passed");
            var s = Count(pytest.Value, "skipped");
            return new TestCounts(f + p + s, f + p, p, f, s, ConsoleFailures(output), "console");
        }
        if (output.Contains("no tests ran", StringComparison.OrdinalIgnoreCase) || output.Contains("No tests found", StringComparison.OrdinalIgnoreCase))
        {
            return new TestCounts(0, 0, 0, 0, 0, [], "console");
        }
        // Maven Surefire: "Tests run: 3, Failures: 1, Errors: 0, Skipped: 0" (the last line is the total).
        if (SurefireSummaryRegex().Matches(output) is { Count: > 0 } surefire)
        {
            var m = surefire[^1];
            var (t, f, e, s) = (int.Parse(m.Groups[1].Value), int.Parse(m.Groups[2].Value), int.Parse(m.Groups[3].Value), int.Parse(m.Groups[4].Value));
            return new TestCounts(t, t - s, t - s - f - e, f + e, s, ConsoleFailures(output), "console");
        }
        return null;
    }

    /// <summary>
    /// The errors logged while the tests ran — "fail:"/"crit:" log entries, unhandled exceptions and their stacks — from
    /// the result files' captured output (TRX StdOut/StdErr, JUnit system-out/system-err) and the console. Distinct blocks, bounded.
    /// </summary>
    public static List<string> LoggedErrors(IEnumerable<string> resultFiles, string console)
    {
        var texts = new List<string>();
        foreach (var file in resultFiles)
        {
            try
            {
                var doc = XDocument.Load(file);
                texts.AddRange(doc.Descendants().Where(e => e.Name.LocalName is "StdOut" or "StdErr" or "system-out" or "system-err").Select(e => e.Value));
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or System.Xml.XmlException)
            {
            }
        }
        texts.Add(console);
        var blocks = new List<string>();
        foreach (var text in texts)
        {
            var lines = text.Replace("\r\n", "\n").Split('\n');
            for (var i = 0; i < lines.Length && blocks.Count < 6; i++)
            {
                if (!LogStartRegex().IsMatch(lines[i]))
                {
                    continue;
                }
                var block = new List<string> { lines[i].TrimEnd() };
                var j = i + 1;
                while (j < lines.Length && block.Count < 40 && (lines[j].StartsWith(' ') || lines[j].StartsWith('\t') || lines[j].TrimStart().StartsWith("at ", StringComparison.Ordinal)
                                                             || lines[j].TrimStart().StartsWith("---", StringComparison.Ordinal)) && lines[j].Trim().Length > 0)
                {
                    block.Add(lines[j].TrimEnd());
                    j++;
                }
                var joined = string.Join("\n", block);
                // Only blocks that carry an exception or an error: not every warning a host writes.
                if (block.Count > 1 && joined.Contains("Exception", StringComparison.Ordinal) && !blocks.Any(b => b.Contains(block[^1], StringComparison.Ordinal) && b.Contains(block[1], StringComparison.Ordinal)))
                {
                    blocks.Add(joined);
                }
                i = j - 1;
            }
        }
        return blocks;
    }

    /// <summary>Failing tests named in console output (dotnet's "Failed Name [12 ms]", pytest's "FAILED path::name", Jest's "●").</summary>
    public static List<TestFailure> ConsoleFailures(string output)
    {
        var failures = new List<TestFailure>();
        var lines = output.Replace("\r\n", "\n").Split('\n');
        for (var i = 0; i < lines.Length; i++)
        {
            string? name = null;
            if (DotnetFailedLineRegex().Match(lines[i]) is { Success: true } d)
            {
                name = d.Groups[1].Value;
            }
            else if (PytestFailedLineRegex().Match(lines[i]) is { Success: true } p)
            {
                name = p.Groups[1].Value;
            }
            else if (JestFailedLineRegex().Match(lines[i]) is { Success: true } j)
            {
                name = j.Groups[1].Value.Trim();
            }
            if (name is null || failures.Any(f => f.Name == name))
            {
                continue;
            }
            // The message and stack that follow it, up to the next test or summary.
            var detail = lines.Skip(i + 1).TakeWhile(l => !DotnetFailedLineRegex().IsMatch(l) && !l.TrimStart().StartsWith("Passed ", StringComparison.Ordinal)
                                                         && !JestFailedLineRegex().IsMatch(l) && !DotnetSummaryRegex().IsMatch(l)).Take(40).ToList();
            var message = detail.SkipWhile(l => l.Trim() is "" or "Error Message:").FirstOrDefault()?.Trim() ?? "";
            var stackAt = detail.FindIndex(l => l.Trim() == "Stack Trace:" || l.TrimStart().StartsWith("at ", StringComparison.Ordinal));
            failures.Add(new TestFailure(name, Trim(message), stackAt < 0 ? null : Trim(string.Join("\n", detail.Skip(stackAt)), 4000)));
        }
        return failures;
    }

    /// <summary>
    /// The failing tests a log, a stack trace or a test file names, as names a runner filter can select ("Namespace.Class.Method"
    /// or "Class.Method"); best effort.
    /// </summary>
    public static List<string> FailingTestNames(string text)
    {
        var names = new List<string>();
        names.AddRange(ConsoleFailures(text).Select(f => f.Name));
        names.AddRange(NUnitFailedRegex().Matches(text).Select(m => m.Groups[1].Value));
        names.AddRange(XunitFailedRegex().Matches(text).Select(m => m.Groups[1].Value));
        return names.Select(n => n.Trim()).Where(n => n.Length > 1).Distinct(StringComparer.Ordinal).Take(40).ToList();
    }

    /// <summary>Source locations a stack trace names ("in C:\src\Calc.cs:line 12", "at Calc (src/calc.js:12:5)", "File \"x.py\", line 12").</summary>
    public static List<(string File, int Line)> StackLocations(string text)
    {
        var found = new List<(string, int)>();
        foreach (Match m in DotnetLocationRegex().Matches(text))
        {
            found.Add((m.Groups[1].Value.Trim(), int.Parse(m.Groups[2].Value)));
        }
        foreach (Match m in ScriptLocationRegex().Matches(text))
        {
            found.Add((m.Groups[1].Value.Trim(), int.Parse(m.Groups[2].Value)));
        }
        foreach (Match m in PythonLocationRegex().Matches(text))
        {
            found.Add((m.Groups[1].Value.Trim(), int.Parse(m.Groups[2].Value)));
        }
        return found.Distinct().ToList();
    }

    private static int Count(string summary, string word)
        => Regex.Match(summary, $@"(\d+)\s+{word}\b", RegexOptions.IgnoreCase) is { Success: true } m ? int.Parse(m.Groups[1].Value) : 0;

    private static int Int(XElement element, string attribute) => int.TryParse((string?)element.Attribute(attribute), out var value) ? value : 0;

    /// <summary>"Namespace.Class.Method" from the TRX's test definition, when it has one.</summary>
    private static string? FullName(XDocument doc, XElement result)
    {
        var testId = (string?)result.Attribute("testId");
        var definition = doc.Descendants().FirstOrDefault(e => e.Name.LocalName == "UnitTest" && (string?)e.Attribute("id") == testId);
        var method = definition?.Descendants().FirstOrDefault(e => e.Name.LocalName == "TestMethod");
        return method is null ? null : $"{(string?)method.Attribute("className")}.{(string?)method.Attribute("name")}";
    }

    private static string Trim(string? text, int max = 1200)
    {
        text = (text ?? "").Trim();
        return text.Length <= max ? text : text[..max] + " …";
    }

    [GeneratedRegex(@"^\s*(fail|crit|error|Unhandled exception|An unhandled exception)\b[:.]?|^\s*(?:[A-Z]\w*\.)+\w*Exception(?::|\s*$)", RegexOptions.IgnoreCase)]
    private static partial Regex LogStartRegex();

    [GeneratedRegex(@"(?:Failed|Passed)!\s*-\s*Failed:\s*(?<failed>\d+),\s*Passed:\s*(?<passed>\d+),\s*Skipped:\s*(?<skipped>\d+),\s*Total:\s*(?<total>\d+)", RegexOptions.IgnoreCase)]
    private static partial Regex DotnetSummaryRegex();

    [GeneratedRegex(@"total:\s*(?<total>\d+)\s*\r?\n?\s*failed:\s*(?<failed>\d+)\s*\r?\n?\s*succeeded:\s*(?<passed>\d+)\s*\r?\n?\s*skipped:\s*(?<skipped>\d+)", RegexOptions.IgnoreCase)]
    private static partial Regex MtpSummaryRegex();

    [GeneratedRegex(@"^\s*Tests:?\s+(?:\d+\s+\w+[,|]?\s*)+(?:\(\d+\)|\d+\s+total)", RegexOptions.Multiline)]
    private static partial Regex JestSummaryRegex();

    [GeneratedRegex(@"^=+\s*(?:\d+\s+(?:failed|passed|skipped|errors?|xfailed|xpassed|warnings?|deselected)[,\s]*)+in\s+[\d.]+s", RegexOptions.Multiline)]
    private static partial Regex PytestSummaryRegex();

    [GeneratedRegex(@"Tests run:\s*(\d+),\s*Failures:\s*(\d+),\s*Errors:\s*(\d+),\s*Skipped:\s*(\d+)")]
    private static partial Regex SurefireSummaryRegex();

    [GeneratedRegex(@"^\s*(?:X\s+|\u2717\s+)?Failed\s+([\w.`<>,\[\]()+-]+)\s*\[[^\]]*\]\s*$")]
    private static partial Regex DotnetFailedLineRegex();

    [GeneratedRegex(@"^FAILED\s+(\S+::\S+)")]
    private static partial Regex PytestFailedLineRegex();

    [GeneratedRegex(@"^\s*●\s+(.+?)\s*$")]
    private static partial Regex JestFailedLineRegex();

    [GeneratedRegex(@"(?:Failed|Error)\s*:\s*([A-Za-z_][\w.]*\.[A-Za-z_]\w*)\b")]
    private static partial Regex NUnitFailedRegex();

    [GeneratedRegex(@"^\s*([A-Za-z_][\w.]*\.[A-Za-z_]\w*)\s+\[FAIL\]", RegexOptions.Multiline)]
    private static partial Regex XunitFailedRegex();

    [GeneratedRegex(@"\sin\s+(.+?\.\w+):line\s+(\d+)")]
    private static partial Regex DotnetLocationRegex();

    [GeneratedRegex(@"\(?((?:[A-Za-z]:)?[^\s():]+\.(?:js|ts|jsx|tsx|mjs|cjs)):(\d+):\d+\)?")]
    private static partial Regex ScriptLocationRegex();

    [GeneratedRegex(@"File ""([^""]+\.py)"", line (\d+)")]
    private static partial Regex PythonLocationRegex();
}
