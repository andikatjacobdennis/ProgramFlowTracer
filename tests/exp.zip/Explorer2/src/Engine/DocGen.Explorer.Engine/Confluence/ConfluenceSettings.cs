using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Engine.Storage;

namespace DocGen.Explorer.Engine.Confluence;

/// <summary>How a Confluence site is signed in to.</summary>
public static class ConfluenceAuth
{
    /// <summary>Confluence Cloud: the account's email and an API token (id.atlassian.com → Security → API tokens).</summary>
    public const string Cloud = "cloud";

    /// <summary>Confluence Server or Data Center: a personal access token (profile → Personal access tokens).</summary>
    public const string Token = "token";

    /// <summary>A site whose spaces can be read without signing in.</summary>
    public const string None = "none";

    public static readonly IReadOnlyList<string> All = [Cloud, Token, None];

    public static string Describe(string kind) => kind switch
    {
        Cloud => "Confluence Cloud — email and API token",
        Token => "Server / Data Center — personal access token",
        _ => "No sign-in (public spaces)",
    };
}

/// <summary>A Confluence site and how to sign in to it. The token is kept in settings/confluence.json, encrypted for the Windows user.</summary>
public sealed class ConfluenceSite
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N")[..8];
    public string Name { get; set; } = "";

    /// <summary>The site's address, e.g. https://example.atlassian.net/wiki (spaces under it use this sign-in).</summary>
    public string BaseUrl { get; set; } = "";

    public string Auth { get; set; } = ConfluenceAuth.Cloud;
    public string Email { get; set; } = "";
    public string ApiToken { get; set; } = "";
    public string PersonalAccessToken { get; set; } = "";

    public bool HasCredentials => Auth switch
    {
        ConfluenceAuth.Cloud => Email.Trim().Length > 0 && ApiToken.Trim().Length > 0,
        ConfluenceAuth.Token => PersonalAccessToken.Trim().Length > 0,
        _ => true,
    };
}

public sealed class ConfluenceSettingsDocument
{
    public List<ConfluenceSite> Sites { get; set; } = [];

    /// <summary>At most this many pages are read from each space at a sync.</summary>
    public int MaxPagesPerSpace { get; set; } = ConfluenceService.MaxPagesPerSpace;

    public int TimeoutSeconds { get; set; } = 60;
}

/// <summary>Settings → Confluence: the sites, their sign-in, and how much a sync reads.</summary>
public sealed class ConfluenceSettingsService(ExplorerStore store)
{
    public const string Path = "settings/confluence.json";

    public async Task<ConfluenceSettingsDocument> GetAsync(CancellationToken ct = default)
        => await store.ReadProtectedAsync<ConfluenceSettingsDocument>(Path, ct) ?? new ConfluenceSettingsDocument();

    public async Task SaveAsync(ConfluenceSettingsDocument document, CancellationToken ct = default)
    {
        Validate(document);
        foreach (var site in document.Sites)
        {
            site.BaseUrl = NormalizeBaseUrl(site.BaseUrl);
            site.Name = string.IsNullOrWhiteSpace(site.Name) ? new Uri(site.BaseUrl).Host : site.Name.Trim();
            site.Email = site.Email.Trim();
            site.ApiToken = site.ApiToken.Trim();
            site.PersonalAccessToken = site.PersonalAccessToken.Trim();
        }
        await store.WriteProtectedAsync(Path, document, ct);
    }

    public static void Validate(ConfluenceSettingsDocument document)
    {
        if (document.MaxPagesPerSpace is < 1 or > 10_000)
        {
            throw new ExplorerValidationException("Pages per space must be between 1 and 10,000.");
        }
        if (document.TimeoutSeconds is < 5 or > 600)
        {
            throw new ExplorerValidationException("The timeout must be between 5 and 600 seconds.");
        }
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var site in document.Sites)
        {
            var url = NormalizeBaseUrl(site.BaseUrl);
            if (!seen.Add(url))
            {
                throw new ExplorerValidationException($"{url} is listed twice.");
            }
            if (!ConfluenceAuth.All.Contains(site.Auth))
            {
                throw new ExplorerValidationException($"Unknown sign-in '{site.Auth}' for {url}.");
            }
        }
    }

    /// <summary>
    /// A site's address as typed or pasted — a space or page link is accepted — trimmed to the site itself
    /// (https://example.atlassian.net/wiki).
    /// </summary>
    public static string NormalizeBaseUrl(string? url)
    {
        var text = (url ?? "").Trim().TrimEnd('/');
        if (!Uri.TryCreate(text, UriKind.Absolute, out var uri) || uri.Scheme != "https" || string.IsNullOrEmpty(uri.Host))
        {
            throw new ExplorerValidationException("A Confluence site address starts with https://, for example https://example.atlassian.net/wiki.");
        }
        var path = uri.AbsolutePath;
        foreach (var marker in new[] { "/spaces/", "/display/", "/pages/", "/rest/" })
        {
            var at = path.IndexOf(marker, StringComparison.OrdinalIgnoreCase);
            if (at >= 0)
            {
                path = path[..at];
            }
        }
        return $"{uri.Scheme}://{uri.Authority}{path}".TrimEnd('/');
    }

    /// <summary>The site whose address is the longest prefix of <paramref name="baseUrl"/> (a space's site), if any.</summary>
    public static ConfluenceSite? SiteFor(ConfluenceSettingsDocument document, string baseUrl)
    {
        var target = baseUrl.TrimEnd('/') + "/";
        return document.Sites
            .Where(s => target.StartsWith(s.BaseUrl.TrimEnd('/') + "/", StringComparison.OrdinalIgnoreCase))
            .OrderByDescending(s => s.BaseUrl.Length)
            .FirstOrDefault();
    }
}
