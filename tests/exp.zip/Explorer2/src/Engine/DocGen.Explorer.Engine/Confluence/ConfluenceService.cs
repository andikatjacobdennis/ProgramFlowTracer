using System.Net;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Engine.Storage;
using DocGen.Explorer.Engine.Text;

namespace DocGen.Explorer.Engine.Confluence;

/// <summary>A Confluence space added to a repository.</summary>
public sealed record ConfluenceSpace(string BaseUrl, string SpaceKey, string Url);

public sealed class ConfluencePage
{
    public string Id { get; set; } = "";
    public string Title { get; set; } = "";
    public string Url { get; set; } = "";
    public string Text { get; set; } = "";

    /// <summary>The space it was read from: its site and key (empty in pages synced by an earlier version).</summary>
    public string Space { get; set; } = "";
}

public sealed class ConfluenceDocument
{
    public DateTime SyncedAt { get; set; }
    public List<ConfluencePage> Pages { get; set; } = [];
}

/// <summary>What testing a site's connection found.</summary>
public sealed record ConfluenceTestResult(bool Ok, string Message);

/// <summary>A space a site's sign-in can see: its key, its name, and the address that adds it to a repository.</summary>
public sealed record ConfluenceSpaceInfo(string Key, string Name, string Url, string SiteName, bool Personal);

/// <summary>
/// Confluence spaces whose pages are searched alongside the repository's own files. Each space is read with the sign-in
/// of its site from Settings → Confluence (settings/confluence.json, stored as typed); nothing is read from environment
/// variables. Pages are fetched by "Sync" and become chunks at the next index run.
/// </summary>
public sealed partial class ConfluenceService(ExplorerStore store, RepositoryService repositories, HttpMessageHandler? handler = null)
{
    public const int MaxPagesPerSpace = 500;

    /// <summary>Settings → Confluence.</summary>
    public ConfluenceSettingsService Settings { get; } = new(store);

    private static string DocumentPath(string repositoryId) => $"repos/{repositoryId}/confluence.json";

    public static ConfluenceSpace ParseSpaceUrl(string? url)
    {
        var text = (url ?? "").Trim();
        if (!Uri.TryCreate(text, UriKind.Absolute, out var uri) || uri.Scheme != "https")
        {
            throw new ExplorerValidationException("A Confluence space address starts with https://, for example https://example.atlassian.net/wiki/spaces/ABC/overview.");
        }
        var match = SpaceRegex().Match(uri.AbsolutePath);
        if (!match.Success)
        {
            throw new ExplorerValidationException("That address does not name a space (…/wiki/spaces/KEY/…).");
        }
        var prefix = uri.AbsolutePath[..match.Index];
        var baseUrl = $"{uri.Scheme}://{uri.Authority}{prefix}".TrimEnd('/');
        return new ConfluenceSpace(baseUrl, match.Groups["key"].Value, text);
    }

    public async Task AddSpaceAsync(string repositoryId, string url, CancellationToken ct = default)
    {
        var space = ParseSpaceUrl(url);
        await repositories.UpdateAsync(repositoryId, r =>
        {
            if (!r.ConfluenceSpaces.Any(s => ParseSpaceUrl(s).SpaceKey == space.SpaceKey && ParseSpaceUrl(s).BaseUrl == space.BaseUrl))
            {
                r.ConfluenceSpaces.Add(space.Url);
            }
        }, ct);
    }

    public async Task RemoveSpaceAsync(string repositoryId, string url, CancellationToken ct = default)
        => await repositories.UpdateAsync(repositoryId, r => r.ConfluenceSpaces.RemoveAll(s => s == url), ct);

    public async Task<ConfluenceDocument?> GetAsync(string repositoryId, CancellationToken ct = default)
        => await store.ReadLargeAsync<ConfluenceDocument>(DocumentPath(repositoryId), ct);

    /// <summary>Fetches every page of every space; returns how many pages were stored.</summary>
    /// <summary>A space's identity, whatever form its address takes: its site and key ("https://site|KEY").</summary>
    public static string SpaceId(ConfluenceSpace space) => space.BaseUrl.TrimEnd('/') + "|" + space.SpaceKey;

    public async Task<int> SyncAsync(string repositoryId, IProgress<string>? progress = null, CancellationToken ct = default)
    {
        var repository = await repositories.GetAsync(repositoryId, ct) ?? throw new ExplorerValidationException("The repository no longer exists.");
        var settings = await Settings.GetAsync(ct);
        var document = new ConfluenceDocument { SyncedAt = DateTime.UtcNow };
        using var http = NewClient(settings);
        foreach (var spaceUrl in repository.ConfluenceSpaces)
        {
            var space = ParseSpaceUrl(spaceUrl);
            var site = ConfluenceSettingsService.SiteFor(settings, space.BaseUrl);
            var start = 0;
            var fromSpace = 0;
            while (fromSpace < settings.MaxPagesPerSpace)
            {
                ct.ThrowIfCancellationRequested();
                var requestUrl = $"{space.BaseUrl}/rest/api/content?spaceKey={Uri.EscapeDataString(space.SpaceKey)}&type=page&expand=body.storage&limit=50&start={start}";
                progress?.Report($"Reading {space.SpaceKey}: {document.Pages.Count} pages so far");
                using var request = new HttpRequestMessage(HttpMethod.Get, requestUrl);
                Authorize(request, site);
                HttpResponseMessage sent;
                try
                {
                    sent = await http.SendAsync(request, ct);
                }
                catch (TaskCanceledException) when (!ct.IsCancellationRequested)
                {
                    // The timeout set in Settings ran out (a cancellation nobody asked for), said as Test says it.
                    throw new ExplorerValidationException($"No answer from {space.BaseUrl} within {TextUtil.Plural(settings.TimeoutSeconds, "second")} (Settings → Confluence → Timeout).");
                }
                using var response = sent;
                if (response.StatusCode is HttpStatusCode.Unauthorized or HttpStatusCode.Forbidden)
                {
                    throw new ExplorerValidationException(site is null
                        ? $"Confluence refused the request for {space.BaseUrl}. Add the site and its sign-in under Settings → Confluence."
                        : $"Confluence refused the sign-in for {site.Name}. Check it under Settings → Confluence (Test shows what is wrong).");
                }
                if (response.StatusCode == HttpStatusCode.NotFound)
                {
                    throw new ExplorerValidationException($"Confluence has no space {space.SpaceKey} at {space.BaseUrl} (or the sign-in cannot see it).");
                }
                response.EnsureSuccessStatusCode();
                using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));
                var results = json.RootElement.GetProperty("results");
                foreach (var page in results.EnumerateArray())
                {
                    if (fromSpace >= settings.MaxPagesPerSpace)
                    {
                        break;
                    }
                    fromSpace++;
                    var html = page.TryGetProperty("body", out var body) && body.TryGetProperty("storage", out var storage) && storage.TryGetProperty("value", out var value) ? value.GetString() ?? "" : "";
                    var id = page.GetProperty("id").GetString() ?? "";
                    var webui = page.TryGetProperty("_links", out var links) && links.TryGetProperty("webui", out var w) ? w.GetString() ?? "" : "";
                    document.Pages.Add(new ConfluencePage
                    {
                        Id = id,
                        Title = page.GetProperty("title").GetString() ?? id,
                        Url = webui.Length > 0 ? space.BaseUrl + webui : spaceUrl,
                        Text = HtmlToText(html),
                        Space = SpaceId(space),
                    });
                }
                if (results.GetArrayLength() < 50)
                {
                    break;
                }
                start += 50;
            }
        }
        await store.WriteLargeAsync(DocumentPath(repositoryId), document, ct);
        return document.Pages.Count;
    }

    /// <summary>
    /// Asks the site for its spaces with the given sign-in: says whether the address is a Confluence site, whether the
    /// sign-in is accepted, and how many spaces it can see.
    /// </summary>
    public async Task<ConfluenceTestResult> TestAsync(ConfluenceSite site, CancellationToken ct = default)
    {
        string baseUrl;
        try
        {
            baseUrl = ConfluenceSettingsService.NormalizeBaseUrl(site.BaseUrl);
        }
        catch (ExplorerValidationException ex)
        {
            return new ConfluenceTestResult(false, ex.Message);
        }
        if (!site.HasCredentials)
        {
            return new ConfluenceTestResult(false, site.Auth == ConfluenceAuth.Cloud ? "Type the account's email and an API token." : "Paste a personal access token.");
        }
        var settings = await Settings.GetAsync(ct);
        using var http = NewClient(settings);
        using var request = new HttpRequestMessage(HttpMethod.Get, $"{baseUrl}/rest/api/space?limit=250");
        Authorize(request, site);
        try
        {
            using var response = await http.SendAsync(request, ct);
            switch (response.StatusCode)
            {
                case HttpStatusCode.Unauthorized:
                    return new ConfluenceTestResult(false, site.Auth switch
                    {
                        ConfluenceAuth.Cloud => "The sign-in was refused: check the email and the API token (a password does not work on Confluence Cloud).",
                        ConfluenceAuth.Token => "The sign-in was refused: check the personal access token.",
                        _ => "This site needs a sign-in.",
                    });
                case HttpStatusCode.Forbidden:
                    return new ConfluenceTestResult(false, "Signed in, but this account may not use the Confluence API.");
                case HttpStatusCode.NotFound:
                    return new ConfluenceTestResult(false, $"No Confluence at {baseUrl}. On Confluence Cloud the address ends in /wiki.");
            }
            if (!response.IsSuccessStatusCode)
            {
                return new ConfluenceTestResult(false, $"The site answered {(int)response.StatusCode} {response.ReasonPhrase}.");
            }
            int spaces;
            try
            {
                using var json = JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));
                spaces = json.RootElement.TryGetProperty("results", out var results) ? results.GetArrayLength() : 0;
            }
            catch (JsonException)
            {
                return new ConfluenceTestResult(false, $"{baseUrl} answered, but not as Confluence does (it may be a login page).");
            }
            return new ConfluenceTestResult(true, spaces == 0
                ? "Connected, but this sign-in sees no spaces."
                : $"Connected: {(spaces >= 250 ? "250 or more" : spaces.ToString())} space{(spaces == 1 ? "" : "s")} visible.");
        }
        catch (HttpRequestException ex)
        {
            return new ConfluenceTestResult(false, "The site could not be reached: " + ex.Message);
        }
        catch (TaskCanceledException) when (!ct.IsCancellationRequested)
        {
            return new ConfluenceTestResult(false, $"No answer within {settings.TimeoutSeconds} seconds.");
        }
    }

    /// <summary>
    /// Every space the site's sign-in can see (up to <paramref name="max"/>), sorted by name, personal spaces last. Throws
    /// <see cref="ExplorerValidationException"/> with a plain message when the site cannot be read.
    /// </summary>
    public async Task<List<ConfluenceSpaceInfo>> ListSpacesAsync(ConfluenceSite site, int max = 2000, CancellationToken ct = default)
    {
        var baseUrl = ConfluenceSettingsService.NormalizeBaseUrl(site.BaseUrl).TrimEnd('/');
        if (!site.HasCredentials)
        {
            throw new ExplorerValidationException(site.Auth == ConfluenceAuth.Cloud ? "Type the account's email and an API token." : "Paste a personal access token.");
        }
        var settings = await Settings.GetAsync(ct);
        using var http = NewClient(settings);
        var spaces = new List<ConfluenceSpaceInfo>();
        var name = string.IsNullOrWhiteSpace(site.Name) ? new Uri(baseUrl).Host : site.Name.Trim();
        for (var start = 0; spaces.Count < max; start += 100)
        {
            using var request = new HttpRequestMessage(HttpMethod.Get, $"{baseUrl}/rest/api/space?limit=100&start={start}");
            Authorize(request, site);
            JsonDocument json;
            try
            {
                using var response = await http.SendAsync(request, ct);
                if (!response.IsSuccessStatusCode)
                {
                    throw new ExplorerValidationException(response.StatusCode switch
                    {
                        HttpStatusCode.Unauthorized => "The sign-in was refused; check it under Settings → Confluence.",
                        HttpStatusCode.Forbidden => "Signed in, but this account may not use the Confluence API.",
                        HttpStatusCode.NotFound => $"No Confluence at {baseUrl}. On Confluence Cloud the address ends in /wiki.",
                        _ => $"The site answered {(int)response.StatusCode} {response.ReasonPhrase}.",
                    });
                }
                json = JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));
            }
            catch (HttpRequestException ex)
            {
                throw new ExplorerValidationException("The site could not be reached: " + ex.Message);
            }
            catch (TaskCanceledException) when (!ct.IsCancellationRequested)
            {
                throw new ExplorerValidationException($"No answer within {settings.TimeoutSeconds} seconds.");
            }
            catch (JsonException)
            {
                throw new ExplorerValidationException($"{baseUrl} answered, but not as Confluence does (it may be a login page).");
            }
            using (json)
            {
                if (!json.RootElement.TryGetProperty("results", out var results) || results.GetArrayLength() == 0)
                {
                    break;
                }
                foreach (var space in results.EnumerateArray())
                {
                    var key = space.TryGetProperty("key", out var k) ? k.GetString() ?? "" : "";
                    if (key.Length == 0)
                    {
                        continue;
                    }
                    var title = space.TryGetProperty("name", out var n) ? n.GetString() ?? key : key;
                    var personal = space.TryGetProperty("type", out var t) && t.GetString() == "personal";
                    spaces.Add(new ConfluenceSpaceInfo(key, title, $"{baseUrl}/spaces/{key}/overview", name, personal));
                }
                if (results.GetArrayLength() < 100)
                {
                    break;
                }
            }
        }
        return spaces.OrderBy(s => s.Personal).ThenBy(s => s.Name, StringComparer.CurrentCultureIgnoreCase).ToList();
    }

    private HttpClient NewClient(ConfluenceSettingsDocument settings)
    {
        var http = handler is null ? new HttpClient() : new HttpClient(handler, disposeHandler: false);
        http.Timeout = TimeSpan.FromSeconds(settings.TimeoutSeconds);
        http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        return http;
    }

    /// <summary>The site's sign-in from Settings → Confluence. A space whose site is not listed there is read without one.</summary>
    internal static void Authorize(HttpRequestMessage request, ConfluenceSite? site)
    {
        if (site is null || !site.HasCredentials)
        {
            return;
        }
        if (site.Auth == ConfluenceAuth.Cloud)
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Basic", Convert.ToBase64String(Encoding.UTF8.GetBytes($"{site.Email.Trim()}:{site.ApiToken.Trim()}")));
        }
        else if (site.Auth == ConfluenceAuth.Token)
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", site.PersonalAccessToken.Trim());
        }
    }

    /// <summary>Confluence storage format (XHTML) to readable text with paragraph breaks.</summary>
    public static string HtmlToText(string html)
    {
        var text = BlockRegex().Replace(html, "\n");
        text = TagRegex().Replace(text, "");
        text = WebUtility.HtmlDecode(text);
        text = SpacesRegex().Replace(text, " ");
        text = BlankLinesRegex().Replace(text, "\n\n");
        return text.Trim();
    }

    /// <summary>Confluence pages as chunks (paragraph windows), identified by a "confluence:" path.</summary>
    public static List<Chunk> ToChunks(ConfluenceDocument document)
    {
        var chunks = new List<Chunk>();
        foreach (var page in document.Pages)
        {
            var paragraphs = page.Text.Split("\n\n", StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            var current = new StringBuilder();
            var part = 1;
            void Flush()
            {
                if (current.Length == 0)
                {
                    return;
                }
                chunks.Add(new Chunk
                {
                    Id = TextUtil.ShortHash($"confluence:{page.Id}:{part}"),
                    Path = $"confluence:{page.Id}",
                    StartLine = part,
                    EndLine = part,
                    Kind = "doc",
                    Title = page.Title,
                    Text = current.ToString(),
                    Url = page.Url,
                });
                part++;
                current.Clear();
            }
            foreach (var paragraph in paragraphs)
            {
                if (current.Length + paragraph.Length > 3000)
                {
                    Flush();
                }
                current.AppendLine(paragraph).AppendLine();
            }
            Flush();
        }
        return chunks;
    }

    [GeneratedRegex(@"/spaces/(?<key>[A-Za-z0-9~_-]+)", RegexOptions.IgnoreCase)]
    private static partial Regex SpaceRegex();

    [GeneratedRegex(@"<\s*(?:br|/p|/h[1-6]|/li|/tr|/div|/pre)\s*/?>", RegexOptions.IgnoreCase)]
    private static partial Regex BlockRegex();

    [GeneratedRegex(@"<[^>]+>")]
    private static partial Regex TagRegex();

    [GeneratedRegex(@"[ \t ]+")]
    private static partial Regex SpacesRegex();

    [GeneratedRegex(@"\n\s*\n+")]
    private static partial Regex BlankLinesRegex();
}
