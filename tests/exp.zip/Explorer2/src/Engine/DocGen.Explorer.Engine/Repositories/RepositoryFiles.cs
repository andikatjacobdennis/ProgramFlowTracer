using System.Globalization;
using System.Text;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Text;

namespace DocGen.Explorer.Engine.Repositories;

/// <summary>What a file or folder is, for its tooltip in the tree: size, dates, lines, encoding and more.</summary>
public sealed record FileDetails
{
    public string Name { get; init; } = "";
    public string RelativePath { get; init; } = "";
    public string FullPath { get; init; } = "";
    public bool IsFolder { get; init; }
    public bool Exists { get; init; }
    public long Size { get; init; }
    public DateTime Created { get; init; }
    public DateTime Modified { get; init; }
    public DateTime Accessed { get; init; }
    public bool ReadOnly { get; init; }
    public bool Hidden { get; init; }
    public string? Language { get; init; }

    /// <summary>A text file: its lines (null when not counted: binary, or too large to read here).</summary>
    public int? Lines { get; init; }
    public int? BlankLines { get; init; }
    public long? Characters { get; init; }
    public string? Encoding { get; init; }
    public string? LineEndings { get; init; }
    public bool Binary { get; init; }

    /// <summary>A folder: what is in it (counted up to a limit), and its total size.</summary>
    public int? Files { get; init; }
    public int? Folders { get; init; }
    public bool Partial { get; init; }

    /// <summary>The details as lines: "Size: 4.2 KB (4,301 bytes)", "Modified: …".</summary>
    public IReadOnlyList<(string Label, string Value)> Rows()
    {
        var rows = new List<(string, string)>();
        if (!Exists)
        {
            rows.Add(("", "Not found on disk."));
            return rows;
        }
        rows.Add(("Path", RelativePath.Length == 0 ? "(repository root)" : RelativePath));
        if (IsFolder)
        {
            rows.Add(("Contains", $"{TextUtil.Plural(Files ?? 0, "file")}, {TextUtil.Plural(Folders ?? 0, "folder")}{(Partial ? " (counted up to the limit)" : "")}"));
            rows.Add(("Size", TextUtil.SizeWithBytes(Size) + (Partial ? "+" : "")));
        }
        else
        {
            rows.Add(("Size", TextUtil.SizeWithBytes(Size)));
            if (Language is { Length: > 0 })
            {
                rows.Add(("Type", Language));
            }
            if (Lines is { } lines)
            {
                rows.Add(("Lines", $"{lines.ToString("N0", CultureInfo.InvariantCulture)}{(BlankLines is { } blank && blank > 0 ? $" ({blank.ToString("N0", CultureInfo.InvariantCulture)} blank)" : "")}"));
            }
            if (Characters is { } chars)
            {
                rows.Add(("Characters", chars.ToString("N0", CultureInfo.InvariantCulture)));
            }
            if (Encoding is { Length: > 0 })
            {
                rows.Add(("Encoding", Encoding + (LineEndings is { Length: > 0 } eol ? " · " + eol : "")));
            }
            if (Binary)
            {
                rows.Add(("Content", "binary"));
            }
        }
        rows.Add(("Modified", When(Modified)));
        rows.Add(("Created", When(Created)));
        rows.Add(("Accessed", When(Accessed)));
        var flags = new List<string>();
        if (ReadOnly)
        {
            flags.Add("read-only");
        }
        if (Hidden)
        {
            flags.Add("hidden");
        }
        if (flags.Count > 0)
        {
            rows.Add(("Attributes", string.Join(", ", flags)));
        }
        return rows;
    }

    /// <summary>"17 Oct 2026 14:05 (3 hours ago)" in local time.</summary>
    public static string When(DateTime utc)
    {
        if (utc == default || utc.Year < 1990)
        {
            return "—";
        }
        var local = utc.Kind == DateTimeKind.Local ? utc : DateTime.SpecifyKind(utc, DateTimeKind.Utc).ToLocalTime();
        var ago = DateTime.Now - local;
        var relative = ago.TotalSeconds < 0 ? "" : ago.TotalMinutes < 1 ? "just now" : ago.TotalHours < 1 ? $"{(int)ago.TotalMinutes} min ago"
            : ago.TotalDays < 1 ? TextUtil.Plural((int)ago.TotalHours, "hour") + " ago" : ago.TotalDays < 60 ? TextUtil.Plural((int)ago.TotalDays, "day") + " ago" : "";
        return local.ToString("d MMM yyyy HH:mm:ss", CultureInfo.InvariantCulture) + (relative.Length > 0 ? $" ({relative})" : "");
    }
}

/// <summary>
/// Adding, renaming, editing and deleting files and folders of a repository on disk (Docs, as on GitHub). Every path is
/// relative to the repository and must stay inside it; nothing is overwritten unless asked; a save notices when the
/// file was changed elsewhere since it was opened. Deleting is done by the app (to the Recycle Bin).
/// </summary>
public static class RepositoryFiles
{
    /// <summary>The largest file whose lines are counted for a tooltip.</summary>
    public const long MaxCountedBytes = 32L * 1024 * 1024;

    /// <summary>The most entries a folder's tooltip counts.</summary>
    public const int MaxFolderEntries = 20_000;

    private static readonly char[] Invalid = Path.GetInvalidFileNameChars();

    /// <summary>Why a file or folder name cannot be used, or null.</summary>
    public static string? NameProblem(string? name)
    {
        var n = (name ?? "").Trim();
        if (n.Length == 0)
        {
            return "Enter a name.";
        }
        if (n is "." or "..")
        {
            return "That name is reserved.";
        }
        if (n.IndexOfAny(Invalid) >= 0)
        {
            return "A name cannot contain \\ / : * ? \" < > |.";
        }
        if (n.EndsWith('.') || n.EndsWith(' '))
        {
            return "A name cannot end with a dot or a space.";
        }
        var stem = Path.GetFileNameWithoutExtension(n).ToUpperInvariant();
        if (stem is "CON" or "PRN" or "AUX" or "NUL" || (stem.Length == 4 && (stem.StartsWith("COM", StringComparison.Ordinal) || stem.StartsWith("LPT", StringComparison.Ordinal)) && char.IsDigit(stem[3])))
        {
            return "Windows reserves that name.";
        }
        return n.Length > 200 ? "The name is too long." : null;
    }

    /// <summary>A path inside <paramref name="folder"/> (relative, "/" separated; "" is the root) for a new name, which may contain sub-folders ("docs/new.md").</summary>
    public static string Combine(string folder, string name)
    {
        var parts = name.Replace('\\', '/').Split('/', StringSplitOptions.RemoveEmptyEntries);
        foreach (var part in parts)
        {
            if (NameProblem(part) is { } problem)
            {
                throw new ExplorerValidationException(problem);
            }
        }
        var relative = string.Join('/', parts);
        return folder.Trim('/').Length == 0 ? relative : folder.Trim('/') + "/" + relative;
    }

    public static string CreateFile(string root, string relative, string content = "")
    {
        var full = FileScanner.SafeResolve(root, relative);
        if (File.Exists(full) || Directory.Exists(full))
        {
            throw new ExplorerValidationException($"'{relative}' already exists.");
        }
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        File.WriteAllText(full, content, new UTF8Encoding(false));
        return full;
    }

    public static string CreateFolder(string root, string relative)
    {
        var full = FileScanner.SafeResolve(root, relative);
        if (File.Exists(full) || Directory.Exists(full))
        {
            throw new ExplorerValidationException($"'{relative}' already exists.");
        }
        Directory.CreateDirectory(full);
        return full;
    }

    /// <summary>Renames a file or folder in its folder; returns its new relative path.</summary>
    public static string Rename(string root, string relative, string newName)
    {
        if (NameProblem(newName) is { } problem)
        {
            throw new ExplorerValidationException(problem);
        }
        var full = FileScanner.SafeResolve(root, relative);
        var parent = Path.GetDirectoryName(relative.Replace('\\', '/').TrimEnd('/'))?.Replace('\\', '/') ?? "";
        var target = parent.Length == 0 ? newName.Trim() : parent + "/" + newName.Trim();
        var targetFull = FileScanner.SafeResolve(root, target);
        var caseOnly = string.Equals(full, targetFull, StringComparison.OrdinalIgnoreCase);
        if (!caseOnly && (File.Exists(targetFull) || Directory.Exists(targetFull)))
        {
            throw new ExplorerValidationException($"'{newName}' already exists there.");
        }
        if (Directory.Exists(full))
        {
            if (caseOnly)
            {
                // A change of case only: through a temporary name (Windows sees them as the same).
                var temp = full + ".rename-" + Guid.NewGuid().ToString("N")[..6];
                Directory.Move(full, temp);
                Directory.Move(temp, targetFull);
            }
            else
            {
                Directory.Move(full, targetFull);
            }
        }
        else if (File.Exists(full))
        {
            File.Move(full, targetFull, overwrite: false);
        }
        else
        {
            throw new ExplorerValidationException($"'{relative}' was not found.");
        }
        return target;
    }

    /// <summary>
    /// Saves text to a file. When <paramref name="expectedModifiedUtc"/> is given and the file changed after it (edited
    /// elsewhere), nothing is written and false is returned, unless <paramref name="overwrite"/>.
    /// </summary>
    public static bool Save(string root, string relative, string text, DateTime? expectedModifiedUtc = null, bool overwrite = false)
    {
        var full = FileScanner.SafeResolve(root, relative);
        if (!overwrite && expectedModifiedUtc is { } expected && File.Exists(full) && Math.Abs((File.GetLastWriteTimeUtc(full) - expected).TotalSeconds) > 1)
        {
            return false;
        }
        // Keep the file's own encoding mark and line endings.
        var (bom, crlf) = File.Exists(full) ? Style(full) : (false, text.Contains("\r\n", StringComparison.Ordinal));
        var normalised = text.Replace("\r\n", "\n", StringComparison.Ordinal);
        if (crlf)
        {
            normalised = normalised.Replace("\n", "\r\n", StringComparison.Ordinal);
        }
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        File.WriteAllText(full, normalised, new UTF8Encoding(bom));
        return true;
    }

    /// <summary>Whether a file starts with a UTF-8 byte order mark and uses CRLF line endings.</summary>
    private static (bool Bom, bool Crlf) Style(string full)
    {
        using var stream = File.OpenRead(full);
        var head = new byte[Math.Min(64 * 1024, (int)Math.Min(stream.Length, 64 * 1024))];
        var read = stream.Read(head, 0, head.Length);
        var bom = read >= 3 && head[0] == 0xEF && head[1] == 0xBB && head[2] == 0xBF;
        var crlf = false;
        for (var i = 1; i < read; i++)
        {
            if (head[i] == '\n')
            {
                crlf = head[i - 1] == '\r';
                break;
            }
        }
        return (bom, crlf);
    }

    /// <summary>The details of a file or folder (never throws for what is on disk).</summary>
    public static FileDetails Details(string root, string relative, string? language = null)
    {
        string full;
        try
        {
            full = FileScanner.SafeResolve(root, relative);
        }
        catch (Exception ex) when (ex is UnauthorizedAccessException or ArgumentException or NotSupportedException)
        {
            return new FileDetails { Name = Path.GetFileName(relative), RelativePath = relative };
        }
        try
        {
            if (Directory.Exists(full))
            {
                var info = new DirectoryInfo(full);
                long size = 0;
                int files = 0, folders = 0;
                var partial = false;
                foreach (var entry in info.EnumerateFileSystemInfos("*", new EnumerationOptions { RecurseSubdirectories = true, IgnoreInaccessible = true, AttributesToSkip = FileAttributes.ReparsePoint }))
                {
                    if (files + folders >= MaxFolderEntries)
                    {
                        partial = true;
                        break;
                    }
                    if (entry is FileInfo f)
                    {
                        files++;
                        size += f.Length;
                    }
                    else
                    {
                        folders++;
                    }
                }
                return new FileDetails
                {
                    Name = info.Name, RelativePath = relative, FullPath = full, IsFolder = true, Exists = true, Size = size, Files = files, Folders = folders, Partial = partial,
                    Created = info.CreationTimeUtc, Modified = info.LastWriteTimeUtc, Accessed = info.LastAccessTimeUtc,
                    ReadOnly = info.Attributes.HasFlag(FileAttributes.ReadOnly), Hidden = info.Attributes.HasFlag(FileAttributes.Hidden),
                };
            }
            var file = new FileInfo(full);
            if (!file.Exists)
            {
                return new FileDetails { Name = Path.GetFileName(relative), RelativePath = relative, FullPath = full };
            }
            var details = new FileDetails
            {
                Name = file.Name, RelativePath = relative, FullPath = full, Exists = true, Size = file.Length, Language = language,
                Created = file.CreationTimeUtc, Modified = file.LastWriteTimeUtc, Accessed = file.LastAccessTimeUtc,
                ReadOnly = file.IsReadOnly, Hidden = file.Attributes.HasFlag(FileAttributes.Hidden),
            };
            return file.Length <= MaxCountedBytes ? Count(details, full) : details;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return new FileDetails { Name = Path.GetFileName(relative), RelativePath = relative, FullPath = full };
        }
    }

    /// <summary>Lines, blank lines, characters, encoding and line endings of a text file; binary is said, not counted.</summary>
    private static FileDetails Count(FileDetails details, string full)
    {
        var bytes = File.ReadAllBytes(full);
        var probe = Math.Min(bytes.Length, 8192);
        for (var i = 0; i < probe; i++)
        {
            if (bytes[i] == 0)
            {
                return details with { Binary = true };
            }
        }
        string encoding;
        string text;
        if (bytes.Length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF)
        {
            encoding = "UTF-8 with BOM";
            text = Encoding.UTF8.GetString(bytes, 3, bytes.Length - 3);
        }
        else if (bytes.Length >= 2 && bytes[0] == 0xFF && bytes[1] == 0xFE)
        {
            encoding = "UTF-16 LE";
            text = Encoding.Unicode.GetString(bytes, 2, bytes.Length - 2);
        }
        else
        {
            try
            {
                text = new UTF8Encoding(false, true).GetString(bytes);
                encoding = bytes.Any(b => b >= 0x80) ? "UTF-8" : "ASCII";
            }
            catch (DecoderFallbackException)
            {
                text = Encoding.Latin1.GetString(bytes);
                encoding = "ANSI (not UTF-8)";
            }
        }
        int lines = 0, blank = 0, crlf = 0, lf = 0;
        var lineHasText = false;
        for (var i = 0; i < text.Length; i++)
        {
            var c = text[i];
            if (c == '\n')
            {
                lines++;
                if (!lineHasText)
                {
                    blank++;
                }
                lineHasText = false;
                if (i > 0 && text[i - 1] == '\r')
                {
                    crlf++;
                }
                else
                {
                    lf++;
                }
            }
            else if (!char.IsWhiteSpace(c))
            {
                lineHasText = true;
            }
        }
        if (text.Length > 0 && text[^1] != '\n')
        {
            lines++;
            if (!lineHasText)
            {
                blank++;
            }
        }
        var endings = crlf > 0 && lf > 0 ? "mixed line endings" : crlf > 0 ? "CRLF" : lf > 0 ? "LF" : null;
        return details with { Lines = lines, BlankLines = blank, Characters = text.Length, Encoding = encoding, LineEndings = endings };
    }
}
