using System.Diagnostics;
using System.Text;

namespace DocGen.Explorer.Engine.Repositories;

/// <summary>How a file differs from the last commit (or, staged, from the index).</summary>
public enum GitChangeKind { Modified, Added, Deleted, Renamed, Untracked, Conflicted }

/// <summary>
/// One changed file: staged changes and working-tree changes of the same file are listed apart, as Visual Studio does.
/// A change between two branches carries the range it was found in (<see cref="Range"/>, "main...feature").
/// </summary>
public sealed record GitChange(string Path, string? OldPath, GitChangeKind Kind, bool Staged)
{
    /// <summary>The two refs compared ("base...target"), or null for a change in the working tree.</summary>
    public string? Range { get; init; }

    public bool IsBranchComparison => Range is not null;

    /// <summary>The letter Visual Studio shows beside the file: M, A, D, R, U (untracked) or ! (conflict).</summary>
    public string Letter => Kind switch
    {
        GitChangeKind.Modified => "M",
        GitChangeKind.Added => "A",
        GitChangeKind.Deleted => "D",
        GitChangeKind.Renamed => "R",
        GitChangeKind.Untracked => "U",
        _ => "!",
    };

    public string KindText => Kind switch
    {
        GitChangeKind.Modified => "Modified",
        GitChangeKind.Added => "Added",
        GitChangeKind.Deleted => "Deleted",
        GitChangeKind.Renamed => "Renamed",
        GitChangeKind.Untracked => "New (untracked)",
        _ => "Conflict",
    };

    public string FileName => System.IO.Path.GetFileName(Path);

    public string Folder => System.IO.Path.GetDirectoryName(Path)?.Replace('\\', '/') ?? "";
}

/// <summary>The working tree's state: the branch and the changed files.</summary>
public sealed record GitChangesReport(string Branch, int Ahead, int Behind, IReadOnlyList<GitChange> Changes)
{
    public IEnumerable<GitChange> Staged => Changes.Where(c => c.Staged);

    public IEnumerable<GitChange> Unstaged => Changes.Where(c => !c.Staged);
}

/// <summary>A line of a diff: context, added or removed, with its numbers in the old and the new file; or a hunk header.</summary>
public sealed record DiffLine(DiffLineKind Kind, int? OldNumber, int? NewNumber, string Text);

public enum DiffLineKind { Context, Added, Removed, Hunk, Note }

/// <summary>A file's diff, ready to show.</summary>
public sealed record FileDiff(GitChange Change, IReadOnlyList<DiffLine> Lines, int Added, int Removed, bool IsBinary, bool Truncated);

/// <summary>
/// Reads a repository's uncommitted changes, the diff of each file and the differences between two branches with git;
/// the one command that changes anything is <see cref="UndoAsync"/> (asked for, and confirmed, by the user).
/// </summary>
public static class GitChanges
{
    private const int MaxDiffLines = 20_000;

    /// <summary>The changes of the repository at <paramref name="root"/>, or null when it is not a git working tree (or git is missing).</summary>
    public static async Task<GitChangesReport?> ReadAsync(string root, CancellationToken ct)
    {
        var (ok, output) = await RunAsync(root, ["status", "--porcelain=v1", "--branch", "-z", "--untracked-files=all"], ct);
        return ok ? ParseStatus(output) : null;
    }

    /// <summary>Parses <c>git status --porcelain=v1 --branch -z</c>.</summary>
    public static GitChangesReport ParseStatus(string output)
    {
        var entries = output.Split('\0');
        var branch = "";
        int ahead = 0, behind = 0;
        var changes = new List<GitChange>();
        for (var i = 0; i < entries.Length; i++)
        {
            var e = entries[i];
            if (e.Length < 3)
            {
                continue;
            }
            if (e.StartsWith("## ", StringComparison.Ordinal))
            {
                (branch, ahead, behind) = ParseBranch(e[3..]);
                continue;
            }
            char x = e[0], y = e[1];
            var path = e[3..];
            string? old = null;
            if (x is 'R' or 'C')
            {
                // A rename's old path follows as its own entry.
                old = i + 1 < entries.Length ? entries[++i] : null;
            }
            if (x == '?' && y == '?')
            {
                changes.Add(new GitChange(path, null, GitChangeKind.Untracked, false));
                continue;
            }
            if (x == 'U' || y == 'U' || (x == 'A' && y == 'A') || (x == 'D' && y == 'D'))
            {
                changes.Add(new GitChange(path, null, GitChangeKind.Conflicted, false));
                continue;
            }
            if (x is not (' ' or '?' or '!'))
            {
                changes.Add(new GitChange(path, old, Kind(x), true));
            }
            if (y is not (' ' or '?' or '!'))
            {
                changes.Add(new GitChange(path, null, Kind(y), false));
            }
        }
        return new GitChangesReport(branch, ahead, behind,
            changes.OrderBy(c => c.Staged ? 0 : 1).ThenBy(c => c.Path, StringComparer.OrdinalIgnoreCase).ToList());
    }

    private static GitChangeKind Kind(char c) => c switch
    {
        'A' => GitChangeKind.Added,
        'D' => GitChangeKind.Deleted,
        'R' or 'C' => GitChangeKind.Renamed,
        _ => GitChangeKind.Modified,
    };

    // "main...origin/main [ahead 2, behind 1]", "main", "No commits yet on main", "HEAD (no branch)"
    private static (string Branch, int Ahead, int Behind) ParseBranch(string text)
    {
        int ahead = 0, behind = 0;
        var bracket = text.IndexOf(" [", StringComparison.Ordinal);
        if (bracket >= 0)
        {
            foreach (var part in text[(bracket + 2)..].TrimEnd(']').Split(", "))
            {
                if (part.StartsWith("ahead ", StringComparison.Ordinal) && int.TryParse(part[6..], out var a))
                {
                    ahead = a;
                }
                else if (part.StartsWith("behind ", StringComparison.Ordinal) && int.TryParse(part[7..], out var b))
                {
                    behind = b;
                }
            }
            text = text[..bracket];
        }
        var dots = text.IndexOf("...", StringComparison.Ordinal);
        var name = dots >= 0 ? text[..dots] : text;
        if (name.StartsWith("No commits yet on ", StringComparison.Ordinal))
        {
            name = name["No commits yet on ".Length..];
        }
        return (name, ahead, behind);
    }

    /// <summary>The diff of one change: staged against the last commit, a working-tree change against the index, a new file as all added.</summary>
    public static async Task<FileDiff> DiffAsync(string root, GitChange change, CancellationToken ct)
    {
        if (change.Kind == GitChangeKind.Untracked)
        {
            return NewFile(root, change);
        }
        List<string> args = ["diff", "--no-color", "--no-ext-diff", "-U3", "-M"];
        if (change.Range is { } range)
        {
            args.Add(range);
        }
        else if (change.Staged)
        {
            args.Add("--cached");
        }
        args.Add("--");
        if (change.OldPath is { } old)
        {
            args.Add(old);
        }
        args.Add(change.Path);
        var (ok, output) = await RunAsync(root, args, ct);
        return ok ? ParseDiff(change, output) : new FileDiff(change, [new DiffLine(DiffLineKind.Note, null, null, "git could not show this change.")], 0, 0, false, false);
    }

    /// <summary>
    /// The text a working-tree change is compared with (the index's version, else the last commit's), for comparing as you
    /// edit; empty for a new file. Null when git cannot show it.
    /// </summary>
    public static async Task<string?> BaseTextAsync(string root, GitChange change, CancellationToken ct)
    {
        if (change.Kind == GitChangeKind.Untracked)
        {
            return "";
        }
        var path = change.OldPath ?? change.Path;
        foreach (var spec in new[] { ":" + path, "HEAD:" + path })
        {
            var (ok, output) = await RunAsync(root, ["show", spec], ct);
            if (ok)
            {
                return output.Replace("\r\n", "\n", StringComparison.Ordinal);
            }
        }
        return change.Kind == GitChangeKind.Added ? "" : null;
    }

    /// <summary>Parses a unified diff of one file into numbered lines.</summary>
    public static FileDiff ParseDiff(GitChange change, string diff)
    {
        var lines = new List<DiffLine>();
        int oldNo = 0, newNo = 0, added = 0, removed = 0;
        var inHunk = false;
        var binary = false;
        foreach (var raw in diff.Replace("\r\n", "\n").Split('\n'))
        {
            if (lines.Count >= MaxDiffLines)
            {
                lines.Add(new DiffLine(DiffLineKind.Note, null, null, $"The diff is longer than {MaxDiffLines:N0} lines; the rest is not shown."));
                return new FileDiff(change, lines, added, removed, false, true);
            }
            if (raw.StartsWith("@@", StringComparison.Ordinal))
            {
                // "@@ -12,7 +12,9 @@ optional context"
                var parts = raw.Split(' ');
                oldNo = Start(parts.ElementAtOrDefault(1));
                newNo = Start(parts.ElementAtOrDefault(2));
                lines.Add(new DiffLine(DiffLineKind.Hunk, null, null, raw));
                inHunk = true;
                continue;
            }
            if (!inHunk)
            {
                binary |= raw.StartsWith("Binary files", StringComparison.Ordinal);
                continue;
            }
            if (raw.StartsWith('+'))
            {
                lines.Add(new DiffLine(DiffLineKind.Added, null, newNo++, raw[1..]));
                added++;
            }
            else if (raw.StartsWith('-'))
            {
                lines.Add(new DiffLine(DiffLineKind.Removed, oldNo++, null, raw[1..]));
                removed++;
            }
            else if (raw.StartsWith(' '))
            {
                lines.Add(new DiffLine(DiffLineKind.Context, oldNo++, newNo++, raw[1..]));
            }
            else if (raw.StartsWith('\\'))
            {
                lines.Add(new DiffLine(DiffLineKind.Note, null, null, raw.TrimStart('\\', ' ')));
            }
        }
        if (binary)
        {
            lines.Add(new DiffLine(DiffLineKind.Note, null, null, "A binary file: its contents are not compared."));
        }
        else if (lines.Count == 0)
        {
            lines.Add(new DiffLine(DiffLineKind.Note, null, null, change.Kind == GitChangeKind.Renamed ? "Renamed without changes." : "No differences in the text (a change of mode or line endings)."));
        }
        return new FileDiff(change, lines, added, removed, binary, false);
    }

    private static int Start(string? range)
    {
        // "-12,7" or "+12"
        var text = range?.TrimStart('-', '+') ?? "";
        var comma = text.IndexOf(',');
        return int.TryParse(comma >= 0 ? text[..comma] : text, out var n) ? Math.Max(n, 1) : 1;
    }

    private static FileDiff NewFile(string root, GitChange change)
    {
        var full = Path.Combine(root, change.Path.Replace('/', Path.DirectorySeparatorChar));
        try
        {
            var info = new FileInfo(full);
            if (!info.Exists)
            {
                return new FileDiff(change, [new DiffLine(DiffLineKind.Note, null, null, "The file is no longer there.")], 0, 0, false, false);
            }
            var bytes = File.ReadAllBytes(full);
            if (bytes.AsSpan(0, Math.Min(bytes.Length, 8000)).Contains((byte)0))
            {
                return new FileDiff(change, [new DiffLine(DiffLineKind.Note, null, null, "A binary file: its contents are not compared.")], 0, 0, true, false);
            }
            var text = Encoding.UTF8.GetString(bytes).Replace("\r\n", "\n");
            var all = text.Split('\n');
            if (all.Length > 1 && all[^1].Length == 0)
            {
                all = all[..^1];
            }
            var shown = all.Take(MaxDiffLines).Select((l, i) => new DiffLine(DiffLineKind.Added, null, i + 1, l)).ToList();
            var truncated = all.Length > MaxDiffLines;
            if (truncated)
            {
                shown.Add(new DiffLine(DiffLineKind.Note, null, null, $"The file is longer than {MaxDiffLines:N0} lines; the rest is not shown."));
            }
            return new FileDiff(change, shown, all.Length, 0, false, truncated);
        }
        catch (IOException ex)
        {
            return new FileDiff(change, [new DiffLine(DiffLineKind.Note, null, null, "The file could not be read: " + ex.Message)], 0, 0, false, false);
        }
    }

    // ---------- branches

    /// <summary>The local and remote-tracking branches, local first, the current one marked.</summary>
    public static async Task<(IReadOnlyList<string> Branches, string? Current)> BranchesAsync(string root, CancellationToken ct)
    {
        var (ok, output) = await RunAsync(root, ["for-each-ref", "--format=%(HEAD)%(refname:short)", "refs/heads", "refs/remotes"], ct);
        if (!ok)
        {
            return ([], null);
        }
        string? current = null;
        var names = new List<string>();
        foreach (var line in output.Replace("\r", "").Split('\n', StringSplitOptions.RemoveEmptyEntries))
        {
            var name = line[1..].Trim();
            if (name.EndsWith("/HEAD", StringComparison.Ordinal) || name.Length == 0)
            {
                continue;
            }
            if (line[0] == '*')
            {
                current = name;
            }
            names.Add(name);
        }
        return (names, current);
    }

    /// <summary>
    /// The files that differ between two branches, as a pull request shows them: what <paramref name="target"/> changed
    /// since it left <paramref name="baseRef"/> ("base...target").
    /// </summary>
    public static async Task<IReadOnlyList<GitChange>?> CompareAsync(string root, string baseRef, string target, CancellationToken ct)
    {
        var range = $"{baseRef}...{target}";
        var (ok, output) = await RunAsync(root, ["diff", "--name-status", "-M", "-z", range, "--"], ct);
        if (!ok)
        {
            return null;
        }
        var parts = output.Split('\0');
        var changes = new List<GitChange>();
        for (var i = 0; i < parts.Length; i++)
        {
            var status = parts[i];
            if (status.Length == 0)
            {
                continue;
            }
            var x = status[0];
            if (x is 'R' or 'C')
            {
                var old = parts.ElementAtOrDefault(i + 1) ?? "";
                var path = parts.ElementAtOrDefault(i + 2) ?? old;
                i += 2;
                changes.Add(new GitChange(path, old, GitChangeKind.Renamed, false) { Range = range });
            }
            else
            {
                var path = parts.ElementAtOrDefault(i + 1) ?? "";
                i += 1;
                changes.Add(new GitChange(path, null, Kind(x), false) { Range = range });
            }
        }
        return changes.OrderBy(c => c.Path, StringComparer.OrdinalIgnoreCase).ToList();
    }

    // ---------- undoing changes (the only commands here that change the working tree; the explorer asks first)

    /// <summary>
    /// Undoes a change, as Visual Studio's Undo Changes does: a working-tree change goes back to the staged (or last
    /// committed) version; a staged change is unstaged (its edits stay in the file); a new, untracked file is deleted.
    /// Returns null when it worked, else git's message.
    /// </summary>
    public static async Task<string?> UndoAsync(string root, GitChange change, CancellationToken ct)
    {
        if (change.IsBranchComparison)
        {
            return "A change between two branches cannot be undone here.";
        }
        if (change.Kind == GitChangeKind.Untracked)
        {
            try
            {
                var full = Path.Combine(root, change.Path.Replace('/', Path.DirectorySeparatorChar));
                if (File.Exists(full))
                {
                    File.SetAttributes(full, FileAttributes.Normal);
                    File.Delete(full);
                }
                return null;
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                return ex.Message;
            }
        }
        List<string> args = change.Staged
            ? ["restore", "--staged", "--", change.Path]
            : ["restore", "--worktree", "--", change.Path];
        if (change.Staged && change.OldPath is { } old)
        {
            args.Add(old);
        }
        var (ok, output, error) = await RunWithErrorAsync(root, args, ct);
        return ok ? null : (error.Trim() is { Length: > 0 } e ? e : output.Trim());
    }

    private static async Task<(bool Ok, string Output)> RunAsync(string root, IReadOnlyList<string> arguments, CancellationToken ct)
    {
        var (ok, output, _) = await RunWithErrorAsync(root, arguments, ct);
        return (ok, output);
    }

    private static async Task<(bool Ok, string Output, string Error)> RunWithErrorAsync(string root, IReadOnlyList<string> arguments, CancellationToken ct)
    {
        if (!Directory.Exists(root))
        {
            return (false, "", "The folder does not exist.");
        }
        try
        {
            var info = new ProcessStartInfo("git")
            {
                WorkingDirectory = root, RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false, CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
            };
            // Read-only: no optional locks (status would otherwise refresh the index), paths as they are (not octal-quoted).
            info.ArgumentList.Add("--no-optional-locks");
            info.ArgumentList.Add("-c");
            info.ArgumentList.Add("core.quotepath=false");
            foreach (var a in arguments)
            {
                info.ArgumentList.Add(a);
            }
            using var process = Process.Start(info)!;
            var output = process.StandardOutput.ReadToEndAsync(ct);
            var error = process.StandardError.ReadToEndAsync(ct);
            await process.WaitForExitAsync(ct);
            var text = await output;
            var problem = await error;
            return (process.ExitCode == 0, text, problem);
        }
        catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or InvalidOperationException or IOException)
        {
            return (false, "", ex.Message);
        }
    }
}
