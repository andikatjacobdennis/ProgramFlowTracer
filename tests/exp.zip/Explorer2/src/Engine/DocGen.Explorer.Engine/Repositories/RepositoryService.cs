using System.Diagnostics;
using System.Text.RegularExpressions;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Storage;

namespace DocGen.Explorer.Engine.Repositories;

/// <summary>Raised for input the user can fix (a missing folder, a duplicate, a malformed URL).</summary>
public sealed class ExplorerValidationException(string message) : Exception(message);

/// <summary>
/// The repository registry (repositories.json). Adding never writes into the repository; removing deletes only what the
/// explorer derived from it (index, graph, conversations, learning material) and, for clones, the clone it made.
/// </summary>
public sealed partial class RepositoryService(ExplorerStore store)
{
    public const string RegistryPath = "repositories.json";

    private static readonly string[] EntryFileExtensions = [".sln", ".slnx", ".csproj", ".vbproj", ".fsproj", ".vbp"];

    public event EventHandler? Changed;

    public async Task<List<RepositoryRecord>> ListAsync(CancellationToken ct = default)
        => (await store.ReadAsync<RepositoryRegistryDocument>(RegistryPath, ct))?.Repositories ?? [];

    public async Task<RepositoryRecord?> GetAsync(string id, CancellationToken ct = default)
        => (await ListAsync(ct)).FirstOrDefault(r => r.Id == id);

    /// <summary>
    /// Normalises what the user typed: surrounding quotes and spaces (from "Copy as path") are removed, and a .sln, .csproj
    /// or .vbp inside a folder stands for that folder. Returns the folder and the entry file, if one was given.
    /// </summary>
    public static (string Folder, string? EntryFile) NormalizeLocalPath(string? input)
    {
        var text = (input ?? "").Trim().Trim('"', '\'').Trim();
        if (text.Length == 0)
        {
            throw new ExplorerValidationException("Type the folder of the repository.");
        }
        text = Environment.ExpandEnvironmentVariables(text);
        if (text.StartsWith("file:///", StringComparison.OrdinalIgnoreCase))
        {
            text = Uri.UnescapeDataString(text[8..]);
        }
        string full;
        try
        {
            full = Path.GetFullPath(text);
        }
        catch (Exception ex) when (ex is ArgumentException or NotSupportedException or PathTooLongException)
        {
            throw new ExplorerValidationException($"'{text}' is not a valid path.");
        }
        if (File.Exists(full))
        {
            var extension = Path.GetExtension(full);
            if (!EntryFileExtensions.Contains(extension, StringComparer.OrdinalIgnoreCase))
            {
                throw new ExplorerValidationException("Choose a folder, or a .sln, .csproj or .vbp inside it.");
            }
            return (Path.GetDirectoryName(full)!, full);
        }
        if (!Directory.Exists(full))
        {
            throw new ExplorerValidationException($"The folder '{full}' does not exist.");
        }
        return (full.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar) is { Length: > 0 } trimmed && !trimmed.EndsWith(':') ? trimmed : full, null);
    }

    public async Task<RepositoryRecord> AddLocalAsync(string path, string? displayName, CancellationToken ct = default)
    {
        var (folder, entry) = NormalizeLocalPath(path);
        var record = new RepositoryRecord
        {
            Id = NewId(),
            Name = Path.GetFileName(folder) is { Length: > 0 } name ? name : folder,
            DisplayName = string.IsNullOrWhiteSpace(displayName) ? null : displayName.Trim(),
            Path = folder,
            EntryFile = entry,
            Source = "local",
        };
        await MutateAsync(list =>
        {
            if (list.Any(r => string.Equals(Path.GetFullPath(r.Path), folder, StringComparison.OrdinalIgnoreCase)))
            {
                throw new ExplorerValidationException($"'{folder}' is already registered.");
            }
            list.Add(record);
        }, ct);
        return record;
    }

    private static readonly string[] ReservedNames = ["CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"];

    /// <summary>
    /// Creates a new, empty repository folder named <paramref name="name"/> in <paramref name="parent"/> — with an empty
    /// Git repository in it when <paramref name="initGit"/> and Git is installed — and registers it. Says plainly why
    /// when the name or the place will not do. Returns whether Git was started in it.
    /// </summary>
    public async Task<(RepositoryRecord Record, bool Git)> CreateLocalAsync(string parent, string name, bool initGit, CancellationToken ct = default)
    {
        name = (name ?? "").Trim();
        if (name.Length == 0)
        {
            throw new ExplorerValidationException("Type a name for the new folder.");
        }
        if (name.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 || name.EndsWith('.') || name is "." or "..")
        {
            throw new ExplorerValidationException("A folder name cannot contain \\ / : * ? \" < > | or end with a dot.");
        }
        if (ReservedNames.Contains(Path.GetFileNameWithoutExtension(name), StringComparer.OrdinalIgnoreCase))
        {
            throw new ExplorerValidationException($"'{name}' is a name Windows keeps for itself; choose another.");
        }
        if ((parent ?? "").Trim().Length == 0)
        {
            throw new ExplorerValidationException("Choose where to create the folder.");
        }
        var (location, _) = NormalizeLocalPath(parent);
        var folder = Path.GetFullPath(Path.Combine(location, name));
        if (File.Exists(folder))
        {
            throw new ExplorerValidationException($"There is already a file called '{name}' in {location}.");
        }
        if (Directory.Exists(folder) && Directory.EnumerateFileSystemEntries(folder).Any())
        {
            throw new ExplorerValidationException($"'{folder}' already exists and is not empty. Choose another name, or add it under Local path.");
        }
        if ((await ListAsync(ct)).Any(r => string.Equals(Path.GetFullPath(r.Path), folder, StringComparison.OrdinalIgnoreCase)))
        {
            throw new ExplorerValidationException($"'{folder}' is already registered.");
        }
        try
        {
            Directory.CreateDirectory(folder);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            throw new ExplorerValidationException($"The folder could not be created in {location}: {ex.Message}");
        }
        var git = false;
        if (initGit)
        {
            try
            {
                git = (await RunGitAsync(["init", "--quiet"], folder, null, ct)).Exit == 0;
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                git = false; // Git is not installed: the folder is created without it
            }
        }
        return (await AddLocalAsync(folder, null, ct), git);
    }

    /// <summary>A Git address checked and tidied: the URL to clone, and the branch a browser link named (Azure DevOps <c>?version=GB…</c>).</summary>
    public sealed record GitAddress(string Url, string? Branch, bool IsAzureDevOps);

    public static string ValidateGitUrl(string? url) => ParseGitUrl(url).Url;

    /// <summary>
    /// Checks what the user typed or pasted. Besides plain HTTPS and SSH addresses it takes Azure DevOps ones as Azure shows them:
    /// the Clone button's <c>https://org@dev.azure.com/org/project/_git/repo</c> (a user name, no password), the old
    /// <c>https://org.visualstudio.com/project/_git/repo</c>, <c>git@ssh.dev.azure.com:v3/org/project/repo</c>, and a link copied from
    /// the browser while looking at the repository (<c>…/_git/repo?path=/src&amp;version=GBmain</c>), whose branch is kept.
    /// </summary>
    public static GitAddress ParseGitUrl(string? url)
    {
        var text = (url ?? "").Trim().Trim('"', '\'').Trim();
        if (text.Length == 0)
        {
            throw new ExplorerValidationException("Type the URL of the Git repository.");
        }
        if (GitSshRegex().IsMatch(text))
        {
            var azureSsh = text.Contains("@ssh.dev.azure.com:", StringComparison.OrdinalIgnoreCase) || text.Contains("@vs-ssh.visualstudio.com:", StringComparison.OrdinalIgnoreCase);
            return new GitAddress(text, null, azureSsh);
        }
        if (!Uri.TryCreate(text, UriKind.Absolute, out var uri) || uri.Scheme is not ("https" or "http") || string.IsNullOrEmpty(uri.Host))
        {
            throw new ExplorerValidationException("A Git URL starts with https:// (or is an SSH address such as git@host:owner/repo.git).");
        }
        if (uri.UserInfo.Contains(':'))
        {
            throw new ExplorerValidationException("Leave the password or token out of the URL; Git's own credential manager supplies it.");
        }
        if (!IsAzureDevOpsHost(uri.Host))
        {
            return new GitAddress(text, null, false);
        }
        // Azure DevOps: the repository is everything up to /_git/<name>; what follows (a file, a branch, a pull request) is not.
        var segments = uri.AbsolutePath.Split('/', StringSplitOptions.RemoveEmptyEntries);
        var gitAt = Array.FindIndex(segments, s => s.Equals("_git", StringComparison.OrdinalIgnoreCase));
        if (gitAt < 1 || gitAt + 1 >= segments.Length)
        {
            throw new ExplorerValidationException("An Azure DevOps repository URL looks like https://dev.azure.com/organization/project/_git/repository — copy it from the repository's Clone button.");
        }
        var path = "/" + string.Join('/', segments.Take(gitAt + 2));
        var user = string.IsNullOrEmpty(uri.UserInfo) ? "" : uri.UserInfo + "@";
        var port = uri.IsDefaultPort ? "" : ":" + uri.Port;
        string? branch = null;
        foreach (var pair in uri.Query.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries))
        {
            var parts = pair.Split('=', 2);
            if (parts.Length == 2 && parts[0].Equals("version", StringComparison.OrdinalIgnoreCase))
            {
                var version = Uri.UnescapeDataString(parts[1]);
                if (version.StartsWith("GB", StringComparison.Ordinal) && version.Length > 2)
                {
                    branch = version[2..];
                }
            }
        }
        return new GitAddress($"{uri.Scheme}://{user}{uri.Host}{port}{path}", branch, true);
    }

    private static bool IsAzureDevOpsHost(string host)
        => host.Equals("dev.azure.com", StringComparison.OrdinalIgnoreCase) || host.EndsWith(".visualstudio.com", StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// One key for every way of writing the same repository (a user name, the case of the host, a trailing .git or slash, Azure
    /// DevOps's old visualstudio.com host and its SSH form), so it is not cloned twice.
    /// </summary>
    public static string GitKey(string url)
    {
        var text = url.Trim().TrimEnd('/');
        if (text.EndsWith(".git", StringComparison.OrdinalIgnoreCase))
        {
            text = text[..^4];
        }
        if (GitSshRegex().IsMatch(text))
        {
            var colon = text.IndexOf(':');
            var host = text[(text.IndexOf('@') + 1)..colon].ToLowerInvariant();
            var path = text[(colon + 1)..].Trim('/');
            var parts = path.Split('/');
            if (host is "ssh.dev.azure.com" && parts.Length == 4 && parts[0].Equals("v3", StringComparison.OrdinalIgnoreCase))
            {
                return $"dev.azure.com/{parts[1]}/{parts[2]}/_git/{parts[3]}".ToLowerInvariant();
            }
            return (host + "/" + path).ToLowerInvariant();
        }
        if (Uri.TryCreate(text, UriKind.Absolute, out var uri))
        {
            var host = uri.Host.ToLowerInvariant();
            var path = Uri.UnescapeDataString(uri.AbsolutePath).Trim('/');
            if (host.EndsWith(".visualstudio.com") && host != "vs-ssh.visualstudio.com")
            {
                path = host[..^".visualstudio.com".Length] + "/" + path;
                host = "dev.azure.com";
            }
            return (host + "/" + path).ToLowerInvariant();
        }
        return text.ToLowerInvariant();
    }

    public static string NameFromGitUrl(string url)
    {
        var trimmed = url.TrimEnd('/');
        var last = trimmed[(Math.Max(trimmed.LastIndexOf('/'), trimmed.LastIndexOf(':')) + 1)..];
        if (last.EndsWith(".git", StringComparison.OrdinalIgnoreCase))
        {
            last = last[..^4];
        }
        return last.Length == 0 ? "repository" : Uri.UnescapeDataString(last);
    }

    /// <summary>Git's own error, with a hint for the usual causes (sign-in, a wrong URL or branch).</summary>
    public static string CloneFailure(string output, bool azure)
    {
        var lines = output.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
        var last = lines.LastOrDefault(l => l.StartsWith("fatal", StringComparison.OrdinalIgnoreCase)) ?? lines.LastOrDefault() ?? "unknown error";
        var all = string.Join('\n', lines);
        string? hint = null;
        if (all.Contains("Authentication failed", StringComparison.OrdinalIgnoreCase) || all.Contains("could not read Username", StringComparison.OrdinalIgnoreCase)
            || all.Contains("terminal prompts disabled", StringComparison.OrdinalIgnoreCase) || all.Contains(" 401", StringComparison.Ordinal) || all.Contains(" 403", StringComparison.Ordinal))
        {
            hint = azure
                ? "Git could not sign in to Azure DevOps. Run  git clone <url>  once in a terminal and sign in when Git Credential Manager asks (it remembers you), or check that your account can read the project."
                : "Git could not sign in. Run  git clone <url>  once in a terminal so Git's credential manager remembers you, or check your access to the repository.";
        }
        else if (all.Contains("Remote branch", StringComparison.OrdinalIgnoreCase) && all.Contains("not found", StringComparison.OrdinalIgnoreCase))
        {
            hint = "That branch does not exist; leave Branch empty for the default one.";
        }
        else if (all.Contains("not found", StringComparison.OrdinalIgnoreCase) || all.Contains("does not exist", StringComparison.OrdinalIgnoreCase))
        {
            hint = azure
                ? "Check the organization, project and repository names — copy the URL from the repository's Clone button in Azure DevOps."
                : "Check the URL.";
        }
        return "git clone failed: " + DocGen.Security.SecretRedactor.Redact(last) + (hint is null ? "" : "\n" + hint);
    }

    /// <summary>
    /// For tests: where Git clones from instead of the (validated, https or ssh) address, such as a local bare repository.
    /// The record keeps the address it was given.
    /// </summary>
    internal Func<string, string>? CloneSourceForTests { get; set; }

    /// <summary>Clones (shallow) into the explorer's data folder, then registers the clone.</summary>
    public async Task<RepositoryRecord> AddGitAsync(string url, string? displayName, string? branch, IProgress<string>? progress, CancellationToken ct = default)
    {
        var address = ParseGitUrl(url);
        url = address.Url;
        if (string.IsNullOrWhiteSpace(branch) && address.Branch is not null)
        {
            branch = address.Branch;
        }
        var key = GitKey(url);
        var existing = await ListAsync(ct);
        if (existing.FirstOrDefault(r => r.GitUrl is not null && GitKey(r.GitUrl) == key) is { } same)
        {
            throw new ExplorerValidationException($"That Git repository is already registered as {same.Title}.");
        }
        var id = NewId();
        var target = Path.Combine(store.ClonesDirectory, id);
        Directory.CreateDirectory(store.ClonesDirectory);
        var args = new List<string> { "clone", "--depth", "1", "--no-tags", "--progress" };
        if (!string.IsNullOrWhiteSpace(branch))
        {
            args.AddRange(["--branch", branch.Trim()]);
        }
        args.AddRange(["--", CloneSourceForTests?.Invoke(url) ?? url, target]);
        progress?.Report(address.IsAzureDevOps
            ? $"Cloning {url} from Azure DevOps — if you have not signed in before, a Microsoft sign-in window opens."
            : "Cloning " + url);
        var (exit, output) = await RunGitAsync(args, store.ClonesDirectory, progress, ct);
        if (exit != 0)
        {
            if (Directory.Exists(target))
            {
                ExplorerStore.DeleteTree(target);
            }
            throw new ExplorerValidationException(CloneFailure(output, address.IsAzureDevOps));
        }
        var record = new RepositoryRecord
        {
            Id = id,
            Name = NameFromGitUrl(url),
            DisplayName = string.IsNullOrWhiteSpace(displayName) ? null : displayName.Trim(),
            Path = target,
            Source = "git",
            GitUrl = url,
            Branch = await ReadBranchAsync(target, ct) ?? (string.IsNullOrWhiteSpace(branch) ? null : branch.Trim()),
        };
        await MutateAsync(list => list.Add(record), ct);
        return record;
    }

    /// <summary>The remote's branches, the default one first.</summary>
    public sealed record RemoteBranches(IReadOnlyList<string> Names, string? Default);

    /// <summary>The branch checked out in a clone, read from Git (and remembered when the record did not have it yet).</summary>
    public async Task<string?> CurrentBranchAsync(RepositoryRecord repository, CancellationToken ct = default)
    {
        if (repository.Source != "git" || !Directory.Exists(repository.Path))
        {
            return repository.Branch;
        }
        var branch = await ReadBranchAsync(repository.Path, ct);
        if (branch is not null && branch != repository.Branch)
        {
            repository.Branch = branch;
            await UpdateAsync(repository.Id, r => r.Branch = branch, ct);
        }
        return branch ?? repository.Branch;
    }

    private static async Task<string?> ReadBranchAsync(string folder, CancellationToken ct)
    {
        if (!Directory.Exists(folder))
        {
            return null;
        }
        var (exit, output) = await RunGitAsync(["rev-parse", "--abbrev-ref", "HEAD"], folder, null, ct);
        var name = output.Trim().Split('\n').LastOrDefault()?.Trim();
        return exit == 0 && !string.IsNullOrEmpty(name) && name != "HEAD" ? name : null;
    }

    /// <summary>Lists the branches on the clone's remote (asks the remote, so it may sign in like a clone does).</summary>
    public async Task<RemoteBranches> ListBranchesAsync(RepositoryRecord repository, CancellationToken ct = default)
    {
        RequireClone(repository);
        var (exit, output) = await RunGitAsync(["ls-remote", "--symref", "origin"], repository.Path, null, ct);
        if (exit != 0)
        {
            throw new ExplorerValidationException(CloneFailure(output, ParseAzure(repository.GitUrl)).Replace("git clone failed", "Listing the branches failed", StringComparison.Ordinal));
        }
        return ParseRemoteBranches(output);
    }

    /// <summary>Reads <c>git ls-remote --symref</c> output: branch names (default first, then alphabetical) and the default.</summary>
    public static RemoteBranches ParseRemoteBranches(string output)
    {
        string? fallback = null;
        var names = new SortedSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var raw in output.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            if (raw.StartsWith("ref: refs/heads/", StringComparison.Ordinal) && raw.EndsWith("HEAD", StringComparison.Ordinal))
            {
                fallback = raw["ref: refs/heads/".Length..].Split('\t', ' ')[0];
                continue;
            }
            var tab = raw.IndexOf('\t');
            if (tab > 0 && raw[(tab + 1)..].StartsWith("refs/heads/", StringComparison.Ordinal))
            {
                names.Add(raw[(tab + 1 + "refs/heads/".Length)..]);
            }
        }
        var list = names.ToList();
        if (fallback is not null && list.Remove(fallback))
        {
            list.Insert(0, fallback);
        }
        return new RemoteBranches(list, fallback);
    }

    /// <summary>
    /// Checks out another branch of a clone (shallow, like the clone itself) and remembers it. The caller reindexes:
    /// everything the explorer derived came from the old branch.
    /// </summary>
    public async Task<RepositoryRecord> SwitchBranchAsync(string id, string branch, IProgress<string>? progress = null, CancellationToken ct = default)
    {
        var repository = await GetAsync(id, ct) ?? throw new ExplorerValidationException("That repository is no longer registered.");
        RequireClone(repository);
        branch = (branch ?? "").Trim();
        if (branch.Length == 0)
        {
            throw new ExplorerValidationException("Choose a branch.");
        }
        if (branch.StartsWith('-') || (await RunGitAsync(["check-ref-format", "--branch", branch], repository.Path, null, ct)).Exit != 0)
        {
            throw new ExplorerValidationException($"'{branch}' is not a valid branch name.");
        }
        progress?.Report($"Fetching {branch}…");
        var (exit, output) = await RunGitAsync(["fetch", "--depth", "1", "--no-tags", "--progress", "origin", $"+refs/heads/{branch}:refs/remotes/origin/{branch}"], repository.Path, progress, ct);
        if (exit != 0)
        {
            var failure = output.Contains("couldn't find remote ref", StringComparison.OrdinalIgnoreCase)
                ? $"The remote has no branch '{branch}'."
                : CloneFailure(output, ParseAzure(repository.GitUrl)).Replace("git clone failed", "git fetch failed", StringComparison.Ordinal);
            throw new ExplorerValidationException(failure);
        }
        progress?.Report($"Checking out {branch}…");
        // A shallow single-branch clone only follows the branch it was made with; follow this one too, so Pull works on it.
        await RunGitAsync(["remote", "set-branches", "--add", "origin", branch], repository.Path, null, ct);
        (exit, output) = await RunGitAsync(["checkout", "--force", "--track", "-B", branch, $"origin/{branch}"], repository.Path, progress, ct);
        if (exit != 0)
        {
            throw new ExplorerValidationException("git checkout failed: " + DocGen.Security.SecretRedactor.Redact(output.Trim().Split('\n').LastOrDefault() ?? "unknown error"));
        }
        await UpdateAsync(id, r => r.Branch = branch, ct);
        repository.Branch = branch;
        return repository;
    }

    private static void RequireClone(RepositoryRecord repository)
    {
        if (repository.Source != "git")
        {
            throw new ExplorerValidationException("Only repositories cloned from Git have branches to switch; a folder is indexed as it is on disk.");
        }
        if (!Directory.Exists(Path.Combine(repository.Path, ".git")))
        {
            throw new ExplorerValidationException($"The clone in '{repository.Path}' is missing; remove the repository and add it again.");
        }
    }

    private static bool ParseAzure(string? url)
    {
        try
        {
            return url is not null && ParseGitUrl(url).IsAzureDevOps;
        }
        catch (ExplorerValidationException)
        {
            return false;
        }
    }

    /// <summary>Fetches and fast-forwards a clone (Git repositories only).</summary>
    public async Task<string> PullAsync(RepositoryRecord repository, CancellationToken ct = default)
    {
        if (repository.Source != "git")
        {
            throw new ExplorerValidationException("Only cloned repositories can be updated from their remote.");
        }
        // Not "--depth 1": that cuts the new commits from the one checked out, so they could never be fast-forwarded to.
        // The clone stays shallow at its old boundary and receives only the commits since.
        var (exit, output) = await RunGitAsync(["pull", "--ff-only"], repository.Path, null, ct);
        await CurrentBranchAsync(repository, ct);
        if (exit != 0)
        {
            throw new ExplorerValidationException("git pull failed: " + output.Trim());
        }
        return output.Trim();
    }

    private static async Task<(int Exit, string Output)> RunGitAsync(IEnumerable<string> args, string workingDirectory, IProgress<string>? progress, CancellationToken ct)
    {
        var info = new ProcessStartInfo("git")
        {
            WorkingDirectory = workingDirectory,
            RedirectStandardError = true,
            RedirectStandardOutput = true,
            UseShellExecute = false,
            CreateNoWindow = true,
        };
        foreach (var arg in args)
        {
            info.ArgumentList.Add(arg);
        }
        info.Environment["GIT_TERMINAL_PROMPT"] = "0";
        using var process = new Process { StartInfo = info };
        var output = new System.Text.StringBuilder();
        process.OutputDataReceived += (_, e) => { if (e.Data is not null) { lock (output) { output.AppendLine(e.Data); } } };
        process.ErrorDataReceived += (_, e) =>
        {
            if (e.Data is not null)
            {
                lock (output)
                {
                    output.AppendLine(e.Data);
                }
                progress?.Report(e.Data);
            }
        };
        try
        {
            process.Start();
        }
        catch (System.ComponentModel.Win32Exception)
        {
            throw new ExplorerValidationException("Git is not installed (git was not found on PATH).");
        }
        process.BeginOutputReadLine();
        process.BeginErrorReadLine();
        try
        {
            await process.WaitForExitAsync(ct);
        }
        catch (OperationCanceledException)
        {
            try
            {
                process.Kill(entireProcessTree: true);
            }
            catch (InvalidOperationException)
            {
            }
            throw;
        }
        return (process.ExitCode, output.ToString());
    }

    public async Task UpdateAsync(string id, Action<RepositoryRecord> mutate, CancellationToken ct = default)
    {
        await MutateAsync(list =>
        {
            var record = list.FirstOrDefault(r => r.Id == id);
            if (record is not null)
            {
                mutate(record);
            }
        }, ct);
    }

    public async Task RenameAsync(string id, string? displayName, CancellationToken ct = default)
        => await UpdateAsync(id, r => r.DisplayName = string.IsNullOrWhiteSpace(displayName) ? null : displayName.Trim(), ct);

    /// <summary>Removes a repository and everything derived from it. The registered folder itself is left alone.</summary>
    public async Task RemoveAsync(string id, CancellationToken ct = default)
    {
        ExplorerStore.RequireId(id);
        RepositoryRecord? removed = null;
        await MutateAsync(list =>
        {
            removed = list.FirstOrDefault(r => r.Id == id);
            list.RemoveAll(r => r.Id == id);
        }, ct);
        store.DeleteDirectory($"repos/{id}");
        store.DeleteDirectory($"analysis/indexes/{id}");
        if (removed is { Source: "git" } && removed.Path.StartsWith(store.ClonesDirectory, StringComparison.OrdinalIgnoreCase) && Directory.Exists(removed.Path))
        {
            ExplorerStore.DeleteTree(removed.Path);
        }
    }

    public async Task RemoveAllAsync(CancellationToken ct = default)
    {
        foreach (var repository in await ListAsync(ct))
        {
            await RemoveAsync(repository.Id, ct);
        }
    }

    internal async Task MutateAsync(Action<List<RepositoryRecord>> mutate, CancellationToken ct)
    {
        await using (await store.Json.AcquireLockAsync(RegistryPath, ct))
        {
            var document = await store.ReadAsync<RepositoryRegistryDocument>(RegistryPath, ct) ?? new RepositoryRegistryDocument();
            mutate(document.Repositories);
            await store.WriteAsync(RegistryPath, document, ct);
        }
        Changed?.Invoke(this, EventArgs.Empty);
    }

    public static IEnumerable<RepositoryRecord> Filter(IEnumerable<RepositoryRecord> repositories, string? search, RepositoryFilter filter, RepositorySort sort)
    {
        var query = repositories.Where(r => filter switch
        {
            RepositoryFilter.Indexed => r.Status == RepositoryStatus.Indexed,
            RepositoryFilter.Indexing => r.Status == RepositoryStatus.Indexing,
            RepositoryFilter.Failed => r.Status == RepositoryStatus.Failed,
            _ => true,
        });
        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            query = query.Where(r => r.Title.Contains(term, StringComparison.OrdinalIgnoreCase) || r.Name.Contains(term, StringComparison.OrdinalIgnoreCase)
                                     || r.Path.Contains(term, StringComparison.OrdinalIgnoreCase) || (r.GitUrl?.Contains(term, StringComparison.OrdinalIgnoreCase) ?? false));
        }
        return sort switch
        {
            RepositorySort.Name => query.OrderBy(r => r.Title, StringComparer.OrdinalIgnoreCase),
            RepositorySort.Files => query.OrderByDescending(r => r.Counters.Files).ThenBy(r => r.Title, StringComparer.OrdinalIgnoreCase),
            RepositorySort.Added => query.OrderByDescending(r => r.AddedAt),
            _ => query.OrderByDescending(r => r.LastIndexedAt ?? DateTime.MinValue).ThenByDescending(r => r.AddedAt),
        };
    }

    private static string NewId() => Guid.NewGuid().ToString("N")[..12];

    [GeneratedRegex(@"^[A-Za-z0-9._-]+@[A-Za-z0-9.-]+:[A-Za-z0-9._/~-]+$")]
    private static partial Regex GitSshRegex();
}
