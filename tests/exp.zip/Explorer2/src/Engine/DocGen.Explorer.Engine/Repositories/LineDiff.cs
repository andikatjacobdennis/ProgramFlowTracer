namespace DocGen.Explorer.Engine.Repositories;

/// <summary>
/// A line diff of two texts in memory (Myers' algorithm), for comparing as you type: every line of both texts, in order,
/// as unchanged, removed or added — numbered on its side — with removed lines before the added lines that replace them.
/// </summary>
public static class LineDiff
{
    /// <summary>Past this many differences the middle is shown as all removed, then all added (it would be no clearer).</summary>
    private const int MaxEdits = 2000;

    public static IReadOnlyList<DiffLine> Compare(string oldText, string newText) => Compare(Lines(oldText), Lines(newText));

    public static IReadOnlyList<DiffLine> Compare(IReadOnlyList<string> a, IReadOnlyList<string> b)
    {
        var result = new List<DiffLine>(Math.Max(a.Count, b.Count) + 8);
        var start = 0;
        while (start < a.Count && start < b.Count && a[start] == b[start])
        {
            start++;
        }
        int endA = a.Count, endB = b.Count;
        while (endA > start && endB > start && a[endA - 1] == b[endB - 1])
        {
            endA--;
            endB--;
        }
        for (var i = 0; i < start; i++)
        {
            result.Add(new DiffLine(DiffLineKind.Context, i + 1, i + 1, a[i]));
        }
        Middle(a, b, start, endA, start, endB, result);
        for (int i = endA, j = endB; i < a.Count; i++, j++)
        {
            result.Add(new DiffLine(DiffLineKind.Context, i + 1, j + 1, a[i]));
        }
        return result;
    }

    /// <summary>The text's lines (\r\n or \n); an empty text has none, and a final line break does not start a line.</summary>
    public static IReadOnlyList<string> Lines(string text)
    {
        if (text.Length == 0)
        {
            return [];
        }
        var lines = text.Replace("\r\n", "\n", StringComparison.Ordinal).Split('\n').ToList();
        if (lines[^1].Length == 0)
        {
            lines.RemoveAt(lines.Count - 1);
        }
        return lines;
    }

    private static void Middle(IReadOnlyList<string> a, IReadOnlyList<string> b, int a0, int a1, int b0, int b1, List<DiffLine> result)
    {
        int n = a1 - a0, m = b1 - b0;
        if (n == 0 && m == 0)
        {
            return;
        }
        var script = n == 0 || m == 0 ? null : Script(a, b, a0, n, b0, m);
        if (script is null)
        {
            for (var i = a0; i < a1; i++)
            {
                result.Add(new DiffLine(DiffLineKind.Removed, i + 1, null, a[i]));
            }
            for (var j = b0; j < b1; j++)
            {
                result.Add(new DiffLine(DiffLineKind.Added, null, j + 1, b[j]));
            }
            return;
        }
        // Walk the edit script, holding back added lines so a run of removals comes before the additions beside it.
        var pendingAdded = new List<DiffLine>();
        foreach (var (kind, i, j) in script)
        {
            switch (kind)
            {
                case DiffLineKind.Context:
                    result.AddRange(pendingAdded);
                    pendingAdded.Clear();
                    result.Add(new DiffLine(DiffLineKind.Context, a0 + i + 1, b0 + j + 1, a[a0 + i]));
                    break;
                case DiffLineKind.Removed:
                    result.Add(new DiffLine(DiffLineKind.Removed, a0 + i + 1, null, a[a0 + i]));
                    break;
                default:
                    pendingAdded.Add(new DiffLine(DiffLineKind.Added, null, b0 + j + 1, b[b0 + j]));
                    break;
            }
        }
        result.AddRange(pendingAdded);
    }

    /// <summary>The shortest edit script from a[a0..a0+n] to b[b0..b0+m] (indices relative to each start), or null when too long.</summary>
    private static List<(DiffLineKind Kind, int I, int J)>? Script(IReadOnlyList<string> a, IReadOnlyList<string> b, int a0, int n, int b0, int m)
    {
        var max = Math.Min(n + m, MaxEdits);
        var offset = max + 1;
        var v = new int[2 * max + 3];
        var trace = new List<int[]>();
        var found = -1;
        for (var d = 0; d <= max && found < 0; d++)
        {
            // Only the diagonals -d..d are in use at step d: keep just those.
            var snapshot = new int[2 * d + 1];
            for (var k = -d; k <= d; k += 2)
            {
                var x = k == -d || (k != d && v[offset + k - 1] < v[offset + k + 1]) ? v[offset + k + 1] : v[offset + k - 1] + 1;
                var y = x - k;
                while (x < n && y < m && a[a0 + x] == b[b0 + y])
                {
                    x++;
                    y++;
                }
                v[offset + k] = x;
                if (x >= n && y >= m)
                {
                    found = d;
                }
            }
            for (var k = -d; k <= d; k++)
            {
                snapshot[k + d] = v[offset + k];
            }
            trace.Add(snapshot);
        }
        if (found < 0)
        {
            return null;
        }
        // Back from (n, m) to (0, 0) through the saved steps.
        var script = new List<(DiffLineKind, int, int)>(n + m);
        int cx = n, cy = m;
        for (var d = found; d > 0; d--)
        {
            var previous = trace[d - 1];
            int At(int k) => k < -(d - 1) || k > d - 1 ? -1 : previous[k + d - 1];
            var k0 = cx - cy;
            var down = k0 == -d || (k0 != d && At(k0 - 1) < At(k0 + 1));
            var prevK = down ? k0 + 1 : k0 - 1;
            var prevX = At(prevK);
            var prevY = prevX - prevK;
            while (cx > prevX && cy > prevY && cx > (down ? prevX : prevX + 1))
            {
                cx--;
                cy--;
                script.Add((DiffLineKind.Context, cx, cy));
            }
            if (down)
            {
                cy--;
                script.Add((DiffLineKind.Added, cx, cy));
            }
            else
            {
                cx--;
                script.Add((DiffLineKind.Removed, cx, cy));
            }
        }
        while (cx > 0 && cy > 0)
        {
            cx--;
            cy--;
            script.Add((DiffLineKind.Context, cx, cy));
        }
        script.Reverse();
        return script;
    }
}
