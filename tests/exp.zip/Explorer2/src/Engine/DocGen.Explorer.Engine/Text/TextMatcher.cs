using System.Text.RegularExpressions;

namespace DocGen.Explorer.Engine.Text;

/// <summary>How a Find matches: case, whole words, or a regular expression.</summary>
public sealed record FindOptions(bool MatchCase = false, bool WholeWord = false, bool Regex = false);

/// <summary>A match: where it starts in the text searched and how long it is.</summary>
public readonly record struct TextMatch(int Start, int Length);

/// <summary>
/// Finds every occurrence of what was typed in a text — the shared matcher behind Find in a page or a file, the search
/// in Ask and the log filter. An invalid regular expression matches nothing (and says why in <see cref="Problem"/>).
/// </summary>
public static class TextMatcher
{
    /// <summary>The most matches reported for one text (a find of "e" in a large file stops there).</summary>
    public const int MaxMatches = 5000;

    /// <summary>Every match of <paramref name="query"/> in <paramref name="text"/>, in order, not overlapping.</summary>
    public static IReadOnlyList<TextMatch> Matches(string? text, string? query, FindOptions? options = null)
    {
        options ??= new FindOptions();
        if (string.IsNullOrEmpty(text) || string.IsNullOrEmpty(query) || Build(query, options) is not { } regex)
        {
            return [];
        }
        var found = new List<TextMatch>();
        try
        {
            for (var m = regex.Match(text); m.Success && found.Count < MaxMatches; m = m.NextMatch())
            {
                if (m.Length > 0)
                {
                    found.Add(new TextMatch(m.Index, m.Length));
                }
            }
        }
        catch (RegexMatchTimeoutException)
        {
            // A pathological pattern: what was found so far.
        }
        return found;
    }

    /// <summary>Whether the text contains the query at all.</summary>
    public static bool Contains(string? text, string? query, FindOptions? options = null)
    {
        options ??= new FindOptions();
        if (string.IsNullOrEmpty(query))
        {
            return true;
        }
        if (string.IsNullOrEmpty(text) || Build(query, options) is not { } regex)
        {
            return false;
        }
        try
        {
            return regex.IsMatch(text);
        }
        catch (RegexMatchTimeoutException)
        {
            return false;
        }
    }

    /// <summary>Why the query cannot be used (an invalid regular expression), or null.</summary>
    public static string? Problem(string? query, FindOptions? options = null)
    {
        if (string.IsNullOrEmpty(query) || options?.Regex != true)
        {
            return null;
        }
        try
        {
            _ = new Regex(query);
            return null;
        }
        catch (ArgumentException ex)
        {
            return "Not a valid regular expression: " + ex.Message;
        }
    }

    private static Regex? Build(string query, FindOptions options)
    {
        var pattern = options.Regex ? query : Regex.Escape(query);
        if (options.WholeWord)
        {
            pattern = $@"(?<![\p{{L}}\p{{N}}_])(?:{pattern})(?![\p{{L}}\p{{N}}_])";
        }
        var flags = RegexOptions.CultureInvariant | (options.MatchCase ? RegexOptions.None : RegexOptions.IgnoreCase);
        try
        {
            return new Regex(pattern, flags, TimeSpan.FromMilliseconds(250));
        }
        catch (ArgumentException)
        {
            return null;
        }
    }
}
