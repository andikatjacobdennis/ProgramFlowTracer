using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace DocGen.Explorer.Engine.Text;

/// <summary>Tokenisation shared by the keyword index, the embedder and question analysis.</summary>
public static class TextUtil
{
    private static readonly HashSet<string> StopWords = new(StringComparer.Ordinal)
    {
        "a", "an", "and", "are", "as", "at", "be", "by", "can", "do", "does", "for", "from", "has", "have", "how", "i", "if", "in",
        "into", "is", "it", "its", "me", "of", "on", "or", "so", "than", "that", "the", "their", "them", "then", "there", "these",
        "this", "those", "to", "up", "was", "we", "what", "when", "where", "which", "while", "who", "why", "will", "with", "you",
        "your", "about", "any", "all", "use", "uses", "used", "using", "var", "new", "return", "public", "private", "protected",
        "internal", "static", "void", "class", "string", "int", "bool", "null", "true", "false", "get", "set", "tell", "explain",
        "show", "please", "repository", "repo", "code", "file", "files", "does", "did", "would", "should", "could", "be", "been",
        "here", "my", "our", "out", "not", "no", "yes", "also", "just", "only", "very", "much", "more", "most", "some", "such",
    };

    /// <summary>
    /// Lower-cased terms: words split on non-alphanumerics, identifiers additionally split on camel humps
    /// (the whole identifier is kept too, so "AverageCalculator" yields averagecalculator, average, calculator).
    /// </summary>
    /// <summary>Words left out of search (English function words and language keywords such as "class").</summary>
    public static bool IsStopWord(string lowerWord) => StopWords.Contains(lowerWord);

    public static List<string> Terms(string? text, bool keepStopWords = false)
    {
        var terms = new List<string>();
        if (string.IsNullOrEmpty(text))
        {
            return terms;
        }
        var span = text.AsSpan();
        var i = 0;
        while (i < span.Length)
        {
            if (!char.IsLetterOrDigit(span[i]))
            {
                i++;
                continue;
            }
            var start = i;
            while (i < span.Length && (char.IsLetterOrDigit(span[i]) || span[i] == '_'))
            {
                i++;
            }
            var word = span[start..i].ToString();
            AddWord(terms, word, keepStopWords);
        }
        return terms;
    }

    private static void AddWord(List<string> terms, string word, bool keepStopWords)
    {
        var parts = SplitIdentifier(word);
        var whole = word.Replace("_", "", StringComparison.Ordinal).ToLowerInvariant();
        if (whole.Length > 1 && (keepStopWords || !StopWords.Contains(whole)))
        {
            terms.Add(whole);
        }
        if (parts.Count > 1)
        {
            foreach (var part in parts)
            {
                var lower = part.ToLowerInvariant();
                if (lower.Length > 1 && lower != whole && (keepStopWords || !StopWords.Contains(lower)))
                {
                    terms.Add(lower);
                }
            }
        }
    }

    /// <summary>"HTTPServerError_code2" → HTTP, Server, Error, code, 2.</summary>
    public static List<string> SplitIdentifier(string identifier)
    {
        var parts = new List<string>();
        var current = new StringBuilder();
        for (var i = 0; i < identifier.Length; i++)
        {
            var c = identifier[i];
            if (c == '_' || !char.IsLetterOrDigit(c))
            {
                Flush();
                continue;
            }
            if (current.Length > 0)
            {
                var prev = identifier[i - 1];
                var next = i + 1 < identifier.Length ? identifier[i + 1] : '\0';
                var boundary = char.IsUpper(c) && (char.IsLower(prev) || char.IsDigit(prev) || char.IsUpper(prev) && char.IsLower(next))
                               || char.IsDigit(c) != char.IsDigit(prev);
                if (boundary)
                {
                    Flush();
                }
            }
            current.Append(c);
        }
        Flush();
        return parts;

        void Flush()
        {
            if (current.Length > 0)
            {
                parts.Add(current.ToString());
                current.Clear();
            }
        }
    }

    /// <summary>Capitalised identifiers in free text ("How does AverageCalculator use Reading?" → AverageCalculator, Reading).</summary>
    public static List<string> CandidateIdentifiers(string text)
    {
        var result = new List<string>();
        foreach (var raw in text.Split([' ', '\t', '\r', '\n', ',', ';', '?', '!', '(', ')', '[', ']', '{', '}', '"', '\'', '`', ':', '<', '>'], StringSplitOptions.RemoveEmptyEntries))
        {
            var word = raw.Trim('.', '*', '_');
            if (word.Length < 2)
            {
                continue;
            }
            var last = word.Contains('.') ? word[(word.LastIndexOf('.') + 1)..] : word;
            if (last.Length > 1 && (char.IsUpper(last[0]) || last.Any(char.IsUpper) && last.Any(char.IsLower) || last.Contains('_')))
            {
                result.Add(word);
            }
        }
        return result.Distinct(StringComparer.Ordinal).ToList();
    }

    /// <summary>A URL- and file-safe slug.</summary>
    public static string Slug(string text, int max = 60)
    {
        var sb = new StringBuilder();
        foreach (var c in text.Normalize(NormalizationForm.FormD))
        {
            if (CharUnicodeInfo.GetUnicodeCategory(c) == UnicodeCategory.NonSpacingMark)
            {
                continue;
            }
            if (char.IsAsciiLetterOrDigit(c))
            {
                sb.Append(char.ToLowerInvariant(c));
            }
            else if (sb.Length > 0 && sb[^1] != '-')
            {
                sb.Append('-');
            }
        }
        var slug = sb.ToString().Trim('-');
        if (slug.Length > max)
        {
            slug = slug[..max].Trim('-');
        }
        return slug.Length == 0 ? "section" : slug;
    }

    /// <summary>"sample-sensor_dashboard" → "Sample sensor dashboard"; "notes" → "Notes".</summary>
    public static string Humanize(string name)
    {
        var words = name.Replace('-', ' ').Replace('_', ' ').Trim();
        if (words.Length == 0)
        {
            return name;
        }
        return char.ToUpperInvariant(words[0]) + words[1..];
    }

    public static string ShortHash(string text)
        => Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(text)))[..16].ToLowerInvariant();

    public static string HashBytes(ReadOnlySpan<byte> bytes) => Convert.ToHexString(SHA256.HashData(bytes))[..32].ToLowerInvariant();

    /// <summary>A rough token count (~4 characters per token) used only to bound prompts, never to report usage.</summary>
    public static int ApproximateTokens(string text) => (text.Length + 3) / 4;

    public static string Truncate(string text, int max) => text.Length <= max ? text : text[..Math.Max(0, max - 1)] + "…";

    public static int CountLines(string text)
    {
        if (text.Length == 0)
        {
            return 0;
        }
        var count = 1;
        foreach (var c in text.AsSpan())
        {
            if (c == '\n')
            {
                count++;
            }
        }
        if (text.EndsWith('\n'))
        {
            count--;
        }
        return count;
    }

    public static string[] SplitLines(string text) => text.Replace("\r\n", "\n", StringComparison.Ordinal).Split('\n');

    /// <summary>A stable 32-bit FNV-1a hash (string.GetHashCode is randomised per process).</summary>
    public static uint Fnv1a(string text)
    {
        var hash = 2166136261u;
        foreach (var c in text)
        {
            hash ^= c;
            hash *= 16777619u;
        }
        return hash;
    }

    /// <summary>Joins items as "a, b and c".</summary>
    public static string JoinNatural(IEnumerable<string> items)
    {
        var list = items.ToList();
        return list.Count switch
        {
            0 => "",
            1 => list[0],
            _ => string.Join(", ", list.Take(list.Count - 1)) + " and " + list[^1],
        };
    }

    public static string Plural(int count, string singular, string? plural = null)
        => count.ToString("N0", CultureInfo.InvariantCulture) + " " + (count == 1 ? singular : plural ?? singular + "s");

    private static readonly string[] SizeUnits = ["B", "KB", "MB", "GB", "TB", "PB", "EB"];

    /// <summary>A size in the unit that reads best: "812 B", "4.2 KB", "1.5 MB", "3.1 GB" … up to EB (1 KB = 1024 bytes).</summary>
    public static string Size(long bytes)
    {
        if (bytes < 0)
        {
            return "—";
        }
        double value = bytes;
        var unit = 0;
        while (value >= 1024 && unit < SizeUnits.Length - 1)
        {
            value /= 1024;
            unit++;
        }
        return unit == 0 ? $"{bytes} B" : value.ToString(value < 10 ? "0.#" : "0", CultureInfo.InvariantCulture) + " " + SizeUnits[unit];
    }

    /// <summary>A size with its exact byte count: "4.2 KB (4,301 bytes)".</summary>
    public static string SizeWithBytes(long bytes)
        => bytes < 1024 ? Plural((int)Math.Max(0, bytes), "byte") : $"{Size(bytes)} ({bytes.ToString("N0", CultureInfo.InvariantCulture)} bytes)";

    /// <summary>Levenshtein distance, giving up (returning <paramref name="limit"/> + 1) once it must exceed <paramref name="limit"/>.</summary>
    public static int EditDistance(string a, string b, int limit = int.MaxValue)
    {
        if (Math.Abs(a.Length - b.Length) > limit)
        {
            return limit + 1;
        }
        var previous = new int[b.Length + 1];
        var current = new int[b.Length + 1];
        for (var j = 0; j <= b.Length; j++)
        {
            previous[j] = j;
        }
        for (var i = 1; i <= a.Length; i++)
        {
            current[0] = i;
            var rowMin = current[0];
            for (var j = 1; j <= b.Length; j++)
            {
                var cost = a[i - 1] == b[j - 1] ? 0 : 1;
                current[j] = Math.Min(Math.Min(previous[j] + 1, current[j - 1] + 1), previous[j - 1] + cost);
                rowMin = Math.Min(rowMin, current[j]);
            }
            if (rowMin > limit)
            {
                return limit + 1;
            }
            (previous, current) = (current, previous);
        }
        return previous[b.Length];
    }
}

