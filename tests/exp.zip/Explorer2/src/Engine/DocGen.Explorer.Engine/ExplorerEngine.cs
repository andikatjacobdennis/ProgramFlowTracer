using DocGen.Explorer.Engine.Ai;
using DocGen.Explorer.Engine.Assistant;
using DocGen.Explorer.Engine.Confluence;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Learning;
using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Engine.Skills;
using DocGen.Explorer.Engine.Storage;
using DocGen.Explorer.Engine.Studio;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace DocGen.Explorer.Engine;

/// <summary>Everything DocGen Explorer does, wired together over one data folder.</summary>
public sealed class ExplorerEngine
{
    public ExplorerEngine(string? dataRoot = null, ILoggerFactory? loggers = null)
    {
        loggers ??= NullLoggerFactory.Instance;
        Store = new ExplorerStore(dataRoot ?? ExplorerStore.DefaultRoot(), loggers);
        Usage = new UsageService(Store);
        Models = new ModelGateway(Store, Usage, loggers);
        Repositories = new RepositoryService(Store);
        Indexing = new IndexingPipeline(Store, Repositories, Models, loggers);
        Skills = new SkillService(Store);
        GraphGroups = new Graph.GraphGroupingService(Store, Models);
        GraphScopes = new Graph.GraphScopeService(Models);
        TestFix = new TestFix.TestFixService(Store, Repositories, Indexing, Models);
        Assistant = new AssistantService(Store, Indexing, Models, Skills, testFix: TestFix);
        // Talk: the same grounded assistant with personas, its conversations kept apart from Ask's.
        Talk = new AssistantService(Store, Indexing, Models, Skills, channel: "talk");
        Learning = new LearningService(Store, Indexing, Assistant, Models);
        Studio = new StudioService(Store, Indexing, Models);
        Confluence = new ConfluenceService(Store, Repositories);
        Data = new Storage.DataMaintenance(Store, Repositories, Indexing);
    }

    public ExplorerStore Store { get; }
    public UsageService Usage { get; }
    public ModelGateway Models { get; }
    public RepositoryService Repositories { get; }
    public IndexingPipeline Indexing { get; }
    public AssistantService Assistant { get; }

    /// <summary>Talk: persona conversations about a repository (kept apart from Ask's).</summary>
    public AssistantService Talk { get; }

    public SkillService Skills { get; }

    /// <summary>The Test Fix skill's workflow (reproduce, diagnose, patch, verify), and its saved runs.</summary>
    public TestFix.TestFixService TestFix { get; }
    public Graph.GraphGroupingService GraphGroups { get; }
    public Graph.GraphScopeService GraphScopes { get; }
    public LearningService Learning { get; }
    public StudioService Studio { get; }
    public ConfluenceService Confluence { get; }
    public Storage.DataMaintenance Data { get; }

    /// <summary>Removes a repository: cancels its index run, then deletes everything derived from it.</summary>
    public async Task RemoveRepositoryAsync(string repositoryId, CancellationToken ct = default)
    {
        if (Indexing.Cancel(repositoryId))
        {
            for (var i = 0; i < 100 && Indexing.IsRunning(repositoryId); i++)
            {
                await Task.Delay(50, ct);
            }
        }
        Indexing.Forget(repositoryId);
        await Repositories.RemoveAsync(repositoryId, ct);
    }

    public async Task RemoveAllRepositoriesAsync(CancellationToken ct = default)
    {
        foreach (var repository in await Repositories.ListAsync(ct))
        {
            await RemoveRepositoryAsync(repository.Id, ct);
        }
    }
}
