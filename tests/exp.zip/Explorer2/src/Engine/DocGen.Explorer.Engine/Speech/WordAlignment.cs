using System.Text.RegularExpressions;

namespace DocGen.Explorer.Engine.Speech;

/// <summary>
/// Lines up the words read aloud with the words shown, so the word being said can be highlighted where it is shown —
/// moving word by word, never jumping to the same word somewhere else.
/// </summary>
public static partial class WordAlignment
{
    /// <summary>The words of a text, in order (letters and digits, with an inner apostrophe kept: "don't").</summary>
    public static IEnumerable<string> Tokens(string text) => WordRegex().Matches(text).Select(m => m.Value);

    /// <summary>Where each word is in a text: (index, length), in order.</summary>
    public static IEnumerable<(int Index, int Length)> Spans(string text) => WordRegex().Matches(text).Select(m => (m.Index, m.Length));

    /// <summary>
    /// Lines up two word sequences in order: for each spoken word, the index of the same shown word, or -1 when it is
    /// not shown. Where they differ, the nearer way to meet again is taken (a few words spoken but not shown, or shown but
    /// not spoken), and two words in a row must agree to meet again, so a common word ("the") is no anchor and one
    /// difference never throws the rest out of line.
    /// </summary>
    public static int[] Align(IReadOnlyList<string> spoken, IReadOnlyList<string> shown, int window = 40)
    {
        var map = Enumerable.Repeat(-1, spoken.Count).ToArray();
        var i = 0;
        var j = 0;
        while (i < spoken.Count && j < shown.Count)
        {
            if (Same(spoken[i], shown[j]))
            {
                map[i++] = j++;
                continue;
            }
            var skipShown = Ahead(shown, j, spoken, i, window);   // shown words that are not spoken
            var skipSpoken = Ahead(spoken, i, shown, j, window);  // spoken words that are not shown
            if (skipShown == int.MaxValue && skipSpoken == int.MaxValue)
            {
                i++;
                j++;
            }
            else if (skipShown <= skipSpoken)
            {
                j += skipShown;
            }
            else
            {
                i += skipSpoken;
            }
        }
        return map;
    }

    /// <summary>
    /// The next spoken word that matches a word the voice reports, at most <paramref name="lookahead"/> words after
    /// <paramref name="next"/>; -1 when none does (the word is then not shown as said).
    /// </summary>
    public static int Match(IReadOnlyList<string> spoken, int next, string said, int lookahead = 8)
    {
        var word = Tokens(said).FirstOrDefault();
        if (word is null)
        {
            return -1;
        }
        for (var i = next; i < Math.Min(spoken.Count, next + lookahead); i++)
        {
            if (Same(spoken[i], word))
            {
                return i;
            }
        }
        return -1;
    }

    private static bool Same(string a, string b) => string.Equals(a, b, StringComparison.OrdinalIgnoreCase);

    // How many words after `from` in `a` the words at `at` in `b` come again (two in a row), or int.MaxValue.
    private static int Ahead(IReadOnlyList<string> a, int from, IReadOnlyList<string> b, int at, int window)
    {
        for (var k = from + 1; k < Math.Min(a.Count, from + window); k++)
        {
            if (Same(a[k], b[at]) && (at + 1 >= b.Count || k + 1 >= a.Count || Same(a[k + 1], b[at + 1])))
            {
                return k - from;
            }
        }
        return int.MaxValue;
    }

    [GeneratedRegex(@"[\p{L}\p{N}]+(?:['’][\p{L}]+)*")]
    private static partial Regex WordRegex();
}
