using System.Globalization;
using System.Net.WebSockets;
using System.Security.Cryptography;
using System.Security;
using System.Text;
using System.Text.RegularExpressions;

namespace DocGen.Explorer.Engine.Speech;

/// <summary>A natural (neural) voice of Microsoft Edge's Read Aloud.</summary>
public sealed record NaturalVoice(string ShortName, string DisplayName, string Gender, string Locale);

/// <summary>A word of spoken audio: when it starts (from the start of the audio), how long it lasts, and the word.</summary>
public sealed record SpokenWord(TimeSpan Offset, TimeSpan Duration, string Text);

/// <summary>Spoken audio (MP3) and when each of its words is said.</summary>
public sealed record SpeechAudio(byte[] Audio, IReadOnlyList<SpokenWord> Words);

/// <summary>
/// Speech from Microsoft Edge's Read Aloud service: the natural (neural) voices Edge reads pages with, returned as
/// MP3. The text is sent to Microsoft over a WebSocket, so this needs a connection; callers fall back to the Windows
/// voices when it fails.
/// </summary>
public static partial class EdgeTts
{
    public const string TrustedClientToken = "6A5AA1D4EAFF4E9FB37E23D68491D6F4";
    private const string ChromiumVersion = "143.0.3650.75";
    private const string Endpoint = "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1";
    private const string OutputFormat = "audio-24khz-48kbitrate-mono-mp3";

    /// <summary>Longest piece of text sent in one request (the service rejects very long requests).</summary>
    public const int MaxChunkChars = 2_500;

    /// <summary>Edge's English natural voices (the service has many more languages; any "xx-YY-NameNeural" name works).</summary>
    public static readonly IReadOnlyList<NaturalVoice> Voices =
    [
        new("en-US-AvaNeural", "Ava (US)", "Female", "en-US"),
        new("en-US-AndrewNeural", "Andrew (US)", "Male", "en-US"),
        new("en-US-EmmaNeural", "Emma (US)", "Female", "en-US"),
        new("en-US-BrianNeural", "Brian (US)", "Male", "en-US"),
        new("en-US-AriaNeural", "Aria (US)", "Female", "en-US"),
        new("en-US-JennyNeural", "Jenny (US)", "Female", "en-US"),
        new("en-US-GuyNeural", "Guy (US)", "Male", "en-US"),
        new("en-US-ChristopherNeural", "Christopher (US)", "Male", "en-US"),
        new("en-US-MichelleNeural", "Michelle (US)", "Female", "en-US"),
        new("en-US-EricNeural", "Eric (US)", "Male", "en-US"),
        new("en-GB-SoniaNeural", "Sonia (UK)", "Female", "en-GB"),
        new("en-GB-RyanNeural", "Ryan (UK)", "Male", "en-GB"),
        new("en-GB-LibbyNeural", "Libby (UK)", "Female", "en-GB"),
        new("en-GB-ThomasNeural", "Thomas (UK)", "Male", "en-GB"),
        new("en-AU-NatashaNeural", "Natasha (Australia)", "Female", "en-AU"),
        new("en-AU-WilliamNeural", "William (Australia)", "Male", "en-AU"),
        new("en-IN-NeerjaNeural", "Neerja (India)", "Female", "en-IN"),
        new("en-IN-PrabhatNeural", "Prabhat (India)", "Male", "en-IN"),
        new("en-CA-ClaraNeural", "Clara (Canada)", "Female", "en-CA"),
        new("en-CA-LiamNeural", "Liam (Canada)", "Male", "en-CA"),
        new("en-IE-EmilyNeural", "Emily (Ireland)", "Female", "en-IE"),
        new("en-IE-ConnorNeural", "Connor (Ireland)", "Male", "en-IE"),
    ];

    public const string DefaultVoice = "en-US-AvaNeural";

    /// <summary>Distinct voices for speakers without one of their own, in speaking order.</summary>
    public static readonly IReadOnlyList<string> SpeakerRotation = ["en-US-AvaNeural", "en-US-AndrewNeural", "en-GB-SoniaNeural", "en-US-BrianNeural"];

    /// <summary>Whether a voice name is one of Edge's natural voices ("en-US-AvaNeural") rather than an installed Windows voice.</summary>
    public static bool IsNatural(string? voice) => voice is not null && NaturalNameRegex().IsMatch(voice);

    /// <summary>
    /// The Sec-MS-GEC token Edge sends: SHA-256 of the Windows file time (rounded down to five minutes) followed by the
    /// client token.
    /// </summary>
    public static string SecMsGec(DateTimeOffset now)
    {
        var seconds = now.ToUnixTimeSeconds() + 11_644_473_600L; // to the Windows epoch (1601)
        seconds -= seconds % 300;
        var ticks = seconds * 10_000_000L; // 100-nanosecond intervals
        var hash = SHA256.HashData(Encoding.ASCII.GetBytes(ticks.ToString(CultureInfo.InvariantCulture) + TrustedClientToken));
        return Convert.ToHexString(hash);
    }

    /// <summary>Rate (1 = normal) and pitch (1 = normal) as SSML prosody values.</summary>
    public static (string Rate, string Pitch) Prosody(double rate, double pitch)
    {
        var r = (int)Math.Round((Math.Clamp(rate, 0.5, 2) - 1) * 100);
        var p = (int)Math.Round((Math.Clamp(pitch, 0.5, 1.5) - 1) * 100);
        return ($"{r:+0;-0;+0}%", $"{p:+0;-0;+0}Hz");
    }

    public static string Ssml(string text, string voice, double rate = 1, double pitch = 1)
    {
        var (r, p) = Prosody(rate, pitch);
        var locale = voice.Length > 5 ? voice[..5] : "en-US";
        var name = NaturalNameRegex().Match(voice) is { Success: true } m
            ? $"Microsoft Server Speech Text to Speech Voice ({m.Groups[1].Value}, {m.Groups[2].Value})"
            : voice;
        return $"<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='{locale}'><voice name='{name}'>" +
               $"<prosody pitch='{p}' rate='{r}' volume='+0%'>{SecurityElement.Escape(Clean(text))}</prosody></voice></speak>";
    }

    /// <summary>Control characters make the service close the connection; they are spoken as spaces.</summary>
    private static string Clean(string text) => new(text.Select(c => char.IsControl(c) && c is not '\n' ? ' ' : c).ToArray());

    /// <summary>Splits text into requests of at most <paramref name="max"/> characters, at sentence ends where possible.</summary>
    public static List<string> Split(string text, int max = MaxChunkChars)
    {
        var chunks = new List<string>();
        var rest = text.Trim();
        while (rest.Length > max)
        {
            var cut = Cut(rest, max);
            chunks.Add(rest[..(cut + 1)].Trim());
            rest = rest[(cut + 1)..].TrimStart();
        }
        if (rest.Length > 0)
        {
            chunks.Add(rest);
        }
        return chunks;
    }

    /// <summary>
    /// Pieces that grow: a short first one (about a sentence) so the voice starts within a second or so, then longer ones,
    /// each fetched while the one before plays — a long answer starts at once instead of after its whole first 2,500 characters.
    /// </summary>
    public static List<string> SplitProgressive(string text)
    {
        int[] sizes = [160, 400, 900, 1600];
        var chunks = new List<string>();
        var rest = text.Trim();
        while (rest.Length > 0)
        {
            var max = chunks.Count < sizes.Length ? sizes[chunks.Count] : MaxChunkChars;
            if (rest.Length <= max)
            {
                chunks.Add(rest);
                break;
            }
            var cut = Cut(rest, max);
            chunks.Add(rest[..(cut + 1)].Trim());
            rest = rest[(cut + 1)..].TrimStart();
        }
        return chunks;
    }

    // Where to end a piece of at most max characters: after a sentence, else after a word, else at max.
    private static int Cut(string rest, int max)
    {
        var cut = rest.LastIndexOfAny(['.', '!', '?', '\n'], max - 1);
        if (cut < max / 3)
        {
            cut = rest.LastIndexOf(' ', max - 1);
        }
        return cut < max / 3 ? max - 1 : cut;
    }

    /// <summary>The audio part of a binary frame: a two-byte big-endian header length, the header, then the audio.</summary>
    public static ReadOnlySpan<byte> AudioOf(ReadOnlySpan<byte> frame)
    {
        if (frame.Length < 2)
        {
            return [];
        }
        var headerLength = (frame[0] << 8) | frame[1];
        if (2 + headerLength > frame.Length)
        {
            return [];
        }
        var header = Encoding.ASCII.GetString(frame.Slice(2, headerLength));
        var isAudio = header.Split("\r\n").Any(line => line == "Path:audio"); // not Path:audio.metadata
        return isAudio ? frame[(2 + headerLength)..] : [];
    }

    /// <summary>
    /// The words of an "audio.metadata" message: {"Metadata":[{"Type":"WordBoundary","Data":{"Offset":…,"Duration":…,
    /// "text":{"Text":"word",…}}}]}, offsets in 100-nanosecond units. Punctuation and sentence boundaries are left out.
    /// </summary>
    public static IEnumerable<SpokenWord> WordsOf(string message)
    {
        var body = message.IndexOf("\r\n\r\n", StringComparison.Ordinal);
        if (body < 0 || !message.Contains("Path:audio.metadata", StringComparison.Ordinal))
        {
            yield break;
        }
        System.Text.Json.JsonDocument document;
        try
        {
            document = System.Text.Json.JsonDocument.Parse(message[(body + 4)..]);
        }
        catch (System.Text.Json.JsonException)
        {
            yield break;
        }
        using (document)
        {
            if (!document.RootElement.TryGetProperty("Metadata", out var items) || items.ValueKind != System.Text.Json.JsonValueKind.Array)
            {
                yield break;
            }
            foreach (var item in items.EnumerateArray())
            {
                if (item.TryGetProperty("Type", out var type) && type.GetString() == "WordBoundary"
                    && item.TryGetProperty("Data", out var data)
                    && data.TryGetProperty("Offset", out var offset) && data.TryGetProperty("text", out var word)
                    && word.TryGetProperty("Text", out var spoken) && spoken.GetString() is { Length: > 0 } said
                    && !(word.TryGetProperty("BoxType", out var box) && box.GetString() is "Punctuation"))
                {
                    var duration = data.TryGetProperty("Duration", out var d) ? d.GetInt64() : 0;
                    yield return new SpokenWord(TimeSpan.FromTicks(offset.GetInt64()), TimeSpan.FromTicks(duration), said);
                }
            }
        }
    }

    /// <summary>Speaks <paramref name="text"/> (one request) and returns the MP3.</summary>
    public static async Task<byte[]> SynthesizeAsync(string text, string voice, double rate = 1, double pitch = 1, CancellationToken ct = default)
        => (await SpeakAsync(text, voice, rate, pitch, ct)).Audio;

    /// <summary>Speaks <paramref name="text"/> (one request) and returns the MP3 with when each word is said.</summary>
    public static async Task<SpeechAudio> SpeakAsync(string text, string voice, double rate = 1, double pitch = 1, CancellationToken ct = default)
    {
        using var socket = new ClientWebSocket();
        socket.Options.SetRequestHeader("Origin", "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold");
        socket.Options.SetRequestHeader("User-Agent", $"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{ChromiumVersion.Split('.')[0]}.0.0.0 Safari/537.36 Edg/{ChromiumVersion.Split('.')[0]}.0.0.0");
        socket.Options.SetRequestHeader("Pragma", "no-cache");
        socket.Options.SetRequestHeader("Cache-Control", "no-cache");
        socket.Options.SetRequestHeader("Cookie", $"muid={Guid.NewGuid().ToString("N").ToUpperInvariant()};");
        var url = $"{Endpoint}?TrustedClientToken={TrustedClientToken}&Sec-MS-GEC={SecMsGec(DateTimeOffset.UtcNow)}&Sec-MS-GEC-Version=1-{ChromiumVersion}&ConnectionId={Guid.NewGuid():N}";

        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(TimeSpan.FromSeconds(30));
        var token = timeout.Token;
        await socket.ConnectAsync(new Uri(url), token);

        var stamp = DateTime.UtcNow.ToString("ddd MMM dd yyyy HH:mm:ss 'GMT+0000 (Coordinated Universal Time)'", CultureInfo.InvariantCulture);
        await SendTextAsync(socket,
            $"X-Timestamp:{stamp}\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n" +
            "{\"context\":{\"synthesis\":{\"audio\":{\"metadataoptions\":{\"sentenceBoundaryEnabled\":\"false\",\"wordBoundaryEnabled\":\"true\"}," +
            $"\"outputFormat\":\"{OutputFormat}\"}}}}}}}}\r\n", token);
        await SendTextAsync(socket,
            $"X-RequestId:{Guid.NewGuid():N}\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:{stamp}Z\r\nPath:ssml\r\n\r\n{Ssml(text, voice, rate, pitch)}", token);

        using var audio = new MemoryStream();
        var words = new List<SpokenWord>();
        var buffer = new byte[64 * 1024];
        using var message = new MemoryStream();
        while (true)
        {
            message.SetLength(0);
            WebSocketReceiveResult result;
            do
            {
                result = await socket.ReceiveAsync(buffer, token);
                if (result.MessageType == WebSocketMessageType.Close)
                {
                    throw new IOException($"The speech service closed the connection ({socket.CloseStatusDescription ?? socket.CloseStatus?.ToString() ?? "no reason given"}).");
                }
                message.Write(buffer, 0, result.Count);
            }
            while (!result.EndOfMessage);

            if (result.MessageType == WebSocketMessageType.Binary)
            {
                audio.Write(AudioOf(message.GetBuffer().AsSpan(0, (int)message.Length)));
            }
            else
            {
                var said = Encoding.UTF8.GetString(message.GetBuffer(), 0, (int)message.Length);
                if (said.Contains("Path:turn.end", StringComparison.Ordinal))
                {
                    break;
                }
                words.AddRange(WordsOf(said));
            }
        }
        try
        {
            await socket.CloseOutputAsync(WebSocketCloseStatus.NormalClosure, "", CancellationToken.None);
        }
        catch (WebSocketException)
        {
        }
        if (audio.Length == 0)
        {
            throw new IOException("The speech service returned no audio.");
        }
        return new SpeechAudio(audio.ToArray(), words);
    }

    private static Task SendTextAsync(ClientWebSocket socket, string text, CancellationToken ct)
        => socket.SendAsync(Encoding.UTF8.GetBytes(text), WebSocketMessageType.Text, true, ct);

    [GeneratedRegex(@"^([a-z]{2,3}-[A-Z]{2,4}(?:-[A-Za-z]+)?)-(\w+Neural)$")]
    private static partial Regex NaturalNameRegex();
}
