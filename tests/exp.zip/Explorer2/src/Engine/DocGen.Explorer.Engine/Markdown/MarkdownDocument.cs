using System.Text;
using System.Text.RegularExpressions;
using DocGen.Explorer.Engine.Text;

namespace DocGen.Explorer.Engine.Markdown;

public abstract record MdBlock(int Line);

public sealed record MdHeading(int Line, int Level, IReadOnlyList<MdInline> Inlines, string Text, string Anchor) : MdBlock(Line);

public sealed record MdParagraph(int Line, IReadOnlyList<MdInline> Inlines) : MdBlock(Line);

public sealed record MdCode(int Line, string Language, string Code) : MdBlock(Line);

public sealed record MdQuote(int Line, IReadOnlyList<MdBlock> Blocks) : MdBlock(Line);

public sealed record MdList(int Line, bool Ordered, int Start, IReadOnlyList<MdListItem> Items) : MdBlock(Line);

public sealed record MdListItem(IReadOnlyList<MdBlock> Blocks, bool? Checked);

public sealed record MdTable(int Line, IReadOnlyList<IReadOnlyList<MdInline>> Header, IReadOnlyList<IReadOnlyList<IReadOnlyList<MdInline>>> Rows, IReadOnlyList<string> Alignments) : MdBlock(Line);

public sealed record MdRule(int Line) : MdBlock(Line);

public abstract record MdInline;

public sealed record MdText(string Text) : MdInline;

public sealed record MdStrong(IReadOnlyList<MdInline> Inlines) : MdInline;

public sealed record MdEmphasis(IReadOnlyList<MdInline> Inlines) : MdInline;

public sealed record MdStrike(IReadOnlyList<MdInline> Inlines) : MdInline;

public sealed record MdInlineCode(string Code) : MdInline;

public sealed record MdLink(IReadOnlyList<MdInline> Inlines, string Url) : MdInline;

public sealed record MdImage(string Alt, string Url) : MdInline;

public sealed record MdLineBreak : MdInline;

/// <summary>
/// A CommonMark-flavoured Markdown parser covering what repository documentation uses: ATX and setext headings, paragraphs,
/// fenced and indented code, block quotes, nested ordered/unordered/task lists, GFM tables, rules, emphasis, strong,
/// strike-through, inline code, links, autolinks and images. Front matter is skipped. Line numbers are 1-based.
/// </summary>
public sealed partial class MarkdownDocument
{
    private MarkdownDocument(IReadOnlyList<MdBlock> blocks) => Blocks = blocks;

    public IReadOnlyList<MdBlock> Blocks { get; }

    public IEnumerable<MdHeading> Headings => Walk(Blocks).OfType<MdHeading>();

    public static MarkdownDocument Parse(string? markdown)
    {
        var lines = TextUtil.SplitLines(markdown ?? "");
        var start = 0;
        if (lines.Length > 0 && lines[0].Trim() == "---")
        {
            var end = Array.FindIndex(lines, 1, l => l.Trim() is "---" or "...");
            if (end > 0)
            {
                start = end + 1;
            }
        }
        var anchors = new Dictionary<string, int>(StringComparer.Ordinal);
        var blocks = new Parser(lines, start, lines.Length, 0, anchors).ParseBlocks();
        return new MarkdownDocument(blocks);
    }

    private static IEnumerable<MdBlock> Walk(IEnumerable<MdBlock> blocks)
    {
        foreach (var block in blocks)
        {
            yield return block;
            switch (block)
            {
                case MdQuote q:
                    foreach (var inner in Walk(q.Blocks))
                    {
                        yield return inner;
                    }
                    break;
                case MdList l:
                    foreach (var inner in Walk(l.Items.SelectMany(i => i.Blocks)))
                    {
                        yield return inner;
                    }
                    break;
            }
        }
    }

    /// <summary>Plain text of inlines (for anchors, search and exports).</summary>
    public static string PlainText(IEnumerable<MdInline> inlines)
    {
        var sb = new StringBuilder();
        foreach (var inline in inlines)
        {
            switch (inline)
            {
                case MdText t: sb.Append(t.Text); break;
                case MdStrong s: sb.Append(PlainText(s.Inlines)); break;
                case MdEmphasis e: sb.Append(PlainText(e.Inlines)); break;
                case MdStrike s: sb.Append(PlainText(s.Inlines)); break;
                case MdInlineCode c: sb.Append(c.Code); break;
                case MdLink l: sb.Append(PlainText(l.Inlines)); break;
                case MdImage i: sb.Append(i.Alt); break;
                case MdLineBreak: sb.Append(' '); break;
            }
        }
        return sb.ToString();
    }

    /// <summary>The whole document as plain text, one block per paragraph.</summary>
    public string ToPlainText()
    {
        var sb = new StringBuilder();
        Append(Blocks, "");
        return sb.ToString().TrimEnd();

        void Append(IEnumerable<MdBlock> blocks, string prefix)
        {
            foreach (var block in blocks)
            {
                switch (block)
                {
                    case MdHeading h: sb.Append(prefix).AppendLine(h.Text).AppendLine(); break;
                    case MdParagraph p: sb.Append(prefix).AppendLine(PlainText(p.Inlines)).AppendLine(); break;
                    case MdCode c: sb.AppendLine(c.Code).AppendLine(); break;
                    case MdQuote q: Append(q.Blocks, prefix + "> "); break;
                    case MdList l:
                        var n = l.Start;
                        foreach (var item in l.Items)
                        {
                            sb.Append(prefix).Append(l.Ordered ? $"{n++}. " : "• ");
                            Append(item.Blocks, "");
                        }
                        break;
                    case MdTable t:
                        sb.AppendLine(string.Join(" | ", t.Header.Select(PlainText)));
                        foreach (var row in t.Rows)
                        {
                            sb.AppendLine(string.Join(" | ", row.Select(PlainText)));
                        }
                        sb.AppendLine();
                        break;
                }
            }
        }
    }

    private sealed partial class Parser(string[] lines, int from, int to, int lineOffset, Dictionary<string, int> anchors)
    {
        private int _i = from;

        public List<MdBlock> ParseBlocks()
        {
            var blocks = new List<MdBlock>();
            var paragraph = new List<string>();
            var paragraphLine = 0;

            void FlushParagraph()
            {
                if (paragraph.Count > 0)
                {
                    blocks.Add(new MdParagraph(paragraphLine, ParseInlines(string.Join("\n", paragraph))));
                    paragraph.Clear();
                }
            }

            while (_i < to)
            {
                var line = lines[_i];
                var lineNumber = _i + 1 + lineOffset;
                var trimmed = line.TrimStart();
                var indent = line.Length - trimmed.Length;

                if (trimmed.Length == 0)
                {
                    FlushParagraph();
                    _i++;
                    continue;
                }

                // Fenced code.
                var fence = FenceRegex().Match(line);
                if (fence.Success && indent < 4)
                {
                    FlushParagraph();
                    var marker = fence.Groups[2].Value;
                    var language = fence.Groups[3].Value.Trim().Split(' ', 2)[0];
                    var code = new List<string>();
                    _i++;
                    while (_i < to && !IsClosingFence(lines[_i], marker))
                    {
                        code.Add(StripIndent(lines[_i], indent));
                        _i++;
                    }
                    _i++; // closing fence (or end)
                    blocks.Add(new MdCode(lineNumber, language, string.Join("\n", code)));
                    continue;
                }

                // Indented code (not inside a paragraph).
                if (indent >= 4 && paragraph.Count == 0)
                {
                    var code = new List<string>();
                    while (_i < to && (lines[_i].Trim().Length == 0 || lines[_i].Length - lines[_i].TrimStart().Length >= 4))
                    {
                        code.Add(lines[_i].Length >= 4 ? lines[_i][4..] : "");
                        _i++;
                    }
                    while (code.Count > 0 && code[^1].Trim().Length == 0)
                    {
                        code.RemoveAt(code.Count - 1);
                    }
                    blocks.Add(new MdCode(lineNumber, "", string.Join("\n", code)));
                    continue;
                }

                // ATX heading.
                var atx = AtxRegex().Match(trimmed);
                if (atx.Success && indent < 4)
                {
                    FlushParagraph();
                    // Models sometimes repeat the marker ("## ## Title"): the extra markers are not part of the title.
                    var headingText = RepeatedMarker().Replace(atx.Groups[2].Value.Trim(), "").TrimEnd('#').Trim();
                    blocks.Add(Heading(lineNumber, atx.Groups[1].Value.Length, headingText));
                    _i++;
                    continue;
                }

                // Setext heading.
                if (paragraph.Count > 0 && indent < 4 && SetextRegex().IsMatch(trimmed))
                {
                    var text = string.Join(" ", paragraph).Trim();
                    paragraph.Clear();
                    blocks.Add(Heading(paragraphLine, trimmed[0] == '=' ? 1 : 2, text));
                    _i++;
                    continue;
                }

                // Rule.
                if (RuleRegex().IsMatch(trimmed) && indent < 4)
                {
                    FlushParagraph();
                    blocks.Add(new MdRule(lineNumber));
                    _i++;
                    continue;
                }

                // Block quote.
                if (trimmed.StartsWith('>'))
                {
                    FlushParagraph();
                    var inner = new List<string>();
                    var startLine = _i;
                    while (_i < to && lines[_i].TrimStart().StartsWith('>'))
                    {
                        var content = lines[_i].TrimStart()[1..];
                        inner.Add(content.StartsWith(' ') ? content[1..] : content);
                        _i++;
                    }
                    var nested = new Parser(inner.ToArray(), 0, inner.Count, startLine + lineOffset, anchors).ParseBlocks();
                    blocks.Add(new MdQuote(lineNumber, nested));
                    continue;
                }

                // Table.
                if (trimmed.Contains('|') && _i + 1 < to && TableDividerRegex().IsMatch(lines[_i + 1].Trim()))
                {
                    FlushParagraph();
                    blocks.Add(ParseTable(lineNumber));
                    continue;
                }

                // List.
                var bullet = ListRegex().Match(line);
                if (bullet.Success && (paragraph.Count == 0 || bullet.Groups[3].Value.Length == 0 || bullet.Groups[3].Value == "1"))
                {
                    FlushParagraph();
                    blocks.Add(ParseList(lineNumber));
                    continue;
                }

                if (paragraph.Count == 0)
                {
                    paragraphLine = lineNumber;
                }
                paragraph.Add(line.EndsWith("  ", StringComparison.Ordinal) ? trimmed.TrimEnd() + "\u2028" : trimmed);
                _i++;
            }
            FlushParagraph();
            return blocks;
        }

        private static bool IsClosingFence(string line, string marker)
        {
            var trimmed = line.Trim();
            return trimmed.Length >= marker.Length && trimmed.All(ch => ch == marker[0]);
        }

        private MdHeading Heading(int line, int level, string text)
        {
            var inlines = ParseInlines(text);
            var plain = PlainText(inlines);
            var anchor = TextUtil.Slug(plain);
            if (anchors.TryGetValue(anchor, out var count))
            {
                anchors[anchor] = count + 1;
                anchor = $"{anchor}-{count}";
            }
            else
            {
                anchors[anchor] = 1;
            }
            return new MdHeading(line, level, inlines, plain, anchor);
        }

        private static string StripIndent(string line, int indent)
        {
            var remove = 0;
            while (remove < indent && remove < line.Length && line[remove] == ' ')
            {
                remove++;
            }
            return line[remove..];
        }

        private MdTable ParseTable(int lineNumber)
        {
            var header = SplitRow(lines[_i]);
            var alignments = SplitRow(lines[_i + 1]).Select(cell =>
            {
                var c = cell.Trim();
                return c.StartsWith(':') && c.EndsWith(':') ? "center" : c.EndsWith(':') ? "right" : "left";
            }).ToList();
            _i += 2;
            var rows = new List<IReadOnlyList<IReadOnlyList<MdInline>>>();
            while (_i < to && lines[_i].Trim().Length > 0 && lines[_i].Contains('|'))
            {
                var cells = SplitRow(lines[_i]);
                while (cells.Count < header.Count)
                {
                    cells.Add("");
                }
                rows.Add(cells.Take(header.Count).Select(c => (IReadOnlyList<MdInline>)ParseInlines(c.Trim())).ToList());
                _i++;
            }
            return new MdTable(lineNumber, header.Select(c => (IReadOnlyList<MdInline>)ParseInlines(c.Trim())).ToList(), rows, alignments);
        }

        private static List<string> SplitRow(string row)
        {
            var text = row.Trim();
            if (text.StartsWith('|'))
            {
                text = text[1..];
            }
            if (text.EndsWith('|') && !text.EndsWith("\\|", StringComparison.Ordinal))
            {
                text = text[..^1];
            }
            var cells = new List<string>();
            var sb = new StringBuilder();
            var inCode = false;
            for (var k = 0; k < text.Length; k++)
            {
                var c = text[k];
                if (c == '\\' && k + 1 < text.Length && text[k + 1] == '|')
                {
                    sb.Append('|');
                    k++;
                    continue;
                }
                if (c == '`')
                {
                    inCode = !inCode;
                }
                if (c == '|' && !inCode)
                {
                    cells.Add(sb.ToString());
                    sb.Clear();
                    continue;
                }
                sb.Append(c);
            }
            cells.Add(sb.ToString());
            return cells;
        }

        private MdList ParseList(int lineNumber)
        {
            var first = ListRegex().Match(lines[_i]);
            var baseIndent = first.Groups[1].Value.Length;
            var ordered = first.Groups[3].Value.Length > 0;
            var start = ordered && int.TryParse(first.Groups[3].Value, out var s) ? s : 1;
            var items = new List<MdListItem>();

            while (_i < to)
            {
                var match = ListRegex().Match(lines[_i]);
                if (!match.Success || match.Groups[1].Value.Length != baseIndent || match.Groups[3].Value.Length > 0 != ordered)
                {
                    break;
                }
                var contentIndent = match.Length;
                var itemLines = new List<string> { lines[_i][contentIndent..] };
                var itemStart = _i;
                _i++;
                while (_i < to)
                {
                    var next = lines[_i];
                    var nextIndent = next.Length - next.TrimStart().Length;
                    if (next.Trim().Length == 0)
                    {
                        // A blank line continues the item only when indented content follows.
                        var peek = _i + 1;
                        if (peek < to && lines[peek].Trim().Length > 0 && lines[peek].Length - lines[peek].TrimStart().Length > baseIndent)
                        {
                            itemLines.Add("");
                            _i++;
                            continue;
                        }
                        break;
                    }
                    if (nextIndent <= baseIndent && (ListRegex().IsMatch(next) || AtxRegex().IsMatch(next.TrimStart()) || FenceRegex().IsMatch(next)))
                    {
                        break;
                    }
                    if (nextIndent <= baseIndent && next.TrimStart().StartsWith('>'))
                    {
                        break;
                    }
                    itemLines.Add(next.Length >= contentIndent && next[..contentIndent].Trim().Length == 0 ? next[contentIndent..] : next.TrimStart());
                    _i++;
                }
                bool? isChecked = null;
                var task = TaskRegex().Match(itemLines[0]);
                if (task.Success)
                {
                    isChecked = task.Groups[1].Value.Trim().Length > 0;
                    itemLines[0] = itemLines[0][task.Length..];
                }
                var inner = new Parser(itemLines.ToArray(), 0, itemLines.Count, itemStart + lineOffset, anchors).ParseBlocks();
                items.Add(new MdListItem(inner, isChecked));
                // Allow one blank line between items of a loose list.
                if (_i < to && lines[_i].Trim().Length == 0 && _i + 1 < to)
                {
                    var after = ListRegex().Match(lines[_i + 1]);
                    if (after.Success && after.Groups[1].Value.Length == baseIndent && after.Groups[3].Value.Length > 0 == ordered)
                    {
                        _i++;
                    }
                }
            }
            return new MdList(lineNumber, ordered, start, items);
        }

        [GeneratedRegex(@"^(\s*)(```+|~~~+)(.*)$")]
        private static partial Regex FenceRegex();

        [GeneratedRegex(@"^(#{1,6})(?:\s+(.*)|$)")]
        private static partial Regex AtxRegex();

        [GeneratedRegex(@"^(?:#{1,6}\s+)+")]
        private static partial Regex RepeatedMarker();

        [GeneratedRegex(@"^(=+|-+)\s*$")]
        private static partial Regex SetextRegex();

        [GeneratedRegex(@"^(?:(?:\*\s*){3,}|(?:-\s*){3,}|(?:_\s*){3,})$")]
        private static partial Regex RuleRegex();

        [GeneratedRegex(@"^\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?$")]
        private static partial Regex TableDividerRegex();

        private static Regex ListRegex() => ListRegexWrapper.Instance;

        [GeneratedRegex(@"^\[([ xX])\]\s+")]
        private static partial Regex TaskRegex();

        private static class ListRegexWrapper
        {
            // Group 1: indent, group 3: ordinal (group 2 kept for compatibility with checks above).
            public static readonly Regex Instance = new(@"^( {0,12})((?:[-*+])|(\d{1,9})[.)])(?:\s+|$)", RegexOptions.Compiled);
        }
    }

    /// <summary>Parses inline Markdown.</summary>
    public static List<MdInline> ParseInlines(string text)
    {
        var result = new List<MdInline>();
        var sb = new StringBuilder();
        var i = 0;

        void Flush()
        {
            if (sb.Length > 0)
            {
                result.Add(new MdText(sb.ToString()));
                sb.Clear();
            }
        }

        while (i < text.Length)
        {
            var c = text[i];
            if (c == '\\' && i + 1 < text.Length && IsEscapable(text[i + 1]))
            {
                sb.Append(text[i + 1]);
                i += 2;
                continue;
            }
            if (c is '\n')
            {
                sb.Append(' ');
                i++;
                continue;
            }
            if (c is '\u2028')
            {
                Flush();
                result.Add(new MdLineBreak());
                i++;
                continue;
            }
            if (c == '`')
            {
                var ticks = 0;
                while (i + ticks < text.Length && text[i + ticks] == '`')
                {
                    ticks++;
                }
                var marker = new string('`', ticks);
                var close = text.IndexOf(marker, i + ticks, StringComparison.Ordinal);
                if (close > 0)
                {
                    Flush();
                    var code = text[(i + ticks)..close];
                    if (code.Length > 1 && code.StartsWith(' ') && code.EndsWith(' '))
                    {
                        code = code[1..^1];
                    }
                    result.Add(new MdInlineCode(code));
                    i = close + ticks;
                    continue;
                }
                sb.Append(marker);
                i += ticks;
                continue;
            }
            if (c == '!' && i + 1 < text.Length && text[i + 1] == '[' && TryLink(text, i + 1, out var alt, out var imageUrl, out var imageEnd))
            {
                Flush();
                result.Add(new MdImage(alt, imageUrl));
                i = imageEnd;
                continue;
            }
            if (c == '[' && TryLink(text, i, out var label, out var url, out var end))
            {
                Flush();
                result.Add(new MdLink(ParseInlines(label), url));
                i = end;
                continue;
            }
            if (c == '<')
            {
                var close = text.IndexOf('>', i + 1);
                if (close > i)
                {
                    var inner = text[(i + 1)..close];
                    if (inner.StartsWith("http://", StringComparison.OrdinalIgnoreCase) || inner.StartsWith("https://", StringComparison.OrdinalIgnoreCase) || inner.StartsWith("mailto:", StringComparison.OrdinalIgnoreCase))
                    {
                        Flush();
                        result.Add(new MdLink([new MdText(inner)], inner));
                        i = close + 1;
                        continue;
                    }
                    if (inner is "br" or "br/" or "br /")
                    {
                        Flush();
                        result.Add(new MdLineBreak());
                        i = close + 1;
                        continue;
                    }
                }
            }
            if ((c == 'h' || c == 'H') && (Starts(text, i, "http://") || Starts(text, i, "https://")) && (i == 0 || !char.IsLetterOrDigit(text[i - 1])))
            {
                var endUrl = i;
                while (endUrl < text.Length && !char.IsWhiteSpace(text[endUrl]) && text[endUrl] is not ('<' or '>' or '"' or ')'))
                {
                    endUrl++;
                }
                while (endUrl > i && text[endUrl - 1] is '.' or ',' or ';' or ':' or '!' or '?')
                {
                    endUrl--;
                }
                Flush();
                var link = text[i..endUrl];
                result.Add(new MdLink([new MdText(link)], link));
                i = endUrl;
                continue;
            }
            if (c is '*' or '_' or '~')
            {
                var run = 0;
                while (i + run < text.Length && text[i + run] == c)
                {
                    run++;
                }
                if (c == '~' && run >= 2)
                {
                    var close = text.IndexOf("~~", i + 2, StringComparison.Ordinal);
                    if (close > i + 2)
                    {
                        Flush();
                        result.Add(new MdStrike(ParseInlines(text[(i + 2)..close])));
                        i = close + 2;
                        continue;
                    }
                }
                else if (c != '~')
                {
                    var leftFlanking = i + run < text.Length && !char.IsWhiteSpace(text[i + run]);
                    var intraword = c == '_' && i > 0 && char.IsLetterOrDigit(text[i - 1]);
                    if (leftFlanking && !intraword)
                    {
                        var size = run >= 2 ? 2 : 1;
                        var marker = new string(c, size);
                        var close = FindClosing(text, i + size, marker, c);
                        if (close > i + size)
                        {
                            Flush();
                            var inner = ParseInlines(text[(i + size)..close]);
                            result.Add(size == 2 ? new MdStrong(inner) : new MdEmphasis(inner));
                            i = close + size;
                            continue;
                        }
                    }
                }
                sb.Append(text, i, run);
                i += run;
                continue;
            }
            sb.Append(c);
            i++;
        }
        Flush();
        return result;
    }

    private static bool Starts(string text, int i, string prefix) => string.Compare(text, i, prefix, 0, prefix.Length, StringComparison.OrdinalIgnoreCase) == 0;

    private static bool IsEscapable(char c) => "\\`*_{}[]()#+-.!|<>~\"'".Contains(c);

    private static int FindClosing(string text, int from, string marker, char c)
    {
        var i = from;
        while (i < text.Length)
        {
            if (text[i] == '`')
            {
                var close = text.IndexOf('`', i + 1);
                i = close < 0 ? i + 1 : close + 1;
                continue;
            }
            if (string.CompareOrdinal(text, i, marker, 0, marker.Length) == 0 && i > from && !char.IsWhiteSpace(text[i - 1]))
            {
                var after = i + marker.Length;
                // For single markers do not stop inside a double marker.
                if (marker.Length == 1 && after < text.Length && text[after] == c)
                {
                    var j = after;
                    while (j < text.Length && text[j] == c)
                    {
                        j++;
                    }
                    if ((j - i) % 2 == 0)
                    {
                        i = j;
                        continue;
                    }
                }
                if (c == '_' && after < text.Length && char.IsLetterOrDigit(text[after]))
                {
                    i++;
                    continue;
                }
                return i;
            }
            i++;
        }
        return -1;
    }

    private static bool TryLink(string text, int open, out string label, out string url, out int end)
    {
        label = url = "";
        end = open;
        var depth = 0;
        var close = -1;
        for (var k = open; k < text.Length; k++)
        {
            if (text[k] == '\\')
            {
                k++;
                continue;
            }
            if (text[k] == '[')
            {
                depth++;
            }
            else if (text[k] == ']' && --depth == 0)
            {
                close = k;
                break;
            }
        }
        if (close < 0 || close + 1 >= text.Length || text[close + 1] != '(')
        {
            return false;
        }
        var parens = 0;
        var urlEnd = -1;
        for (var k = close + 1; k < text.Length; k++)
        {
            if (text[k] == '(')
            {
                parens++;
            }
            else if (text[k] == ')' && --parens == 0)
            {
                urlEnd = k;
                break;
            }
        }
        if (urlEnd < 0)
        {
            return false;
        }
        label = text[(open + 1)..close];
        var target = text[(close + 2)..urlEnd].Trim();
        var space = target.IndexOf(' ');
        if (space > 0 && (target[(space + 1)..].TrimStart().StartsWith('"') || target[(space + 1)..].TrimStart().StartsWith('\'')))
        {
            target = target[..space];
        }
        url = target.Trim('<', '>');
        end = urlEnd + 1;
        return true;
    }
}
