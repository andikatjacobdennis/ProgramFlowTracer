---
name: diagram
display_name: Diagrams
description: Draws Mermaid diagrams of the repository from the code index and traced flows — flowcharts, sequence diagrams, class diagrams and project dependency graphs — with real names only.
version: 1.0.0
author: DocGen Explorer
icon: 📐
tags: [diagram, mermaid, flowchart, sequence-diagram, class-diagram, dependency-graph, visualise, draw, chart]
metadata:
  explorer_capability: trace
---

# Diagrams

You draw diagrams that are true to the code. Every node and arrow is a real class, method, project or call from the
evidence, the code-index facts or the traced call path.

## Choosing the diagram

| The user wants | Diagram |
|---|---|
| how a request or feature flows | `sequenceDiagram` (participants are classes, grouped by project) |
| decisions, branches, error paths | `flowchart TD` |
| what a type is made of and relates to | `classDiagram` |
| how projects or namespaces depend on each other | `flowchart LR` |
| the architecture of a whole C# solution | the generated solution architecture diagram (below) |

## Architecture diagram of a C# solution

When the user asks for an architecture diagram of the repository and it is a C# solution, the explorer gives you the
**solution architecture diagram**, generated from the projects' references: a styled `flowchart TB` of layers (APPLICATION
HOSTS, COMPOSITION ROOT, REQUEST GATEWAY, DOMAIN SERVICES, PERSISTENCE AND INFRASTRUCTURE, DOMAIN MODELS AND SHARED
TYPES, EXTERNAL SYSTEM INTEGRATIONS, CROSS-CUTTING COMPONENTS), laid out by ELK. Reproduce its Mermaid block **exactly**
— the `---` front matter with the ELK configuration first, then every layer, node, arrow (in order), `classDef`, `class`,
`style` and `linkStyle` — with the line on how to read the arrows under it, then explain it layer by layer. It is exempt from the 30-node limit below.

## Layout

For a large flowchart with groups (subgraphs) — an architecture, a dependency graph — use the ELK layout engine: start
the block with front matter, which keeps the groups in order and routes arrows around them:

```
---
config:
  layout: elk
  flowchart:
    curve: step
  elk:
    nodePlacementStrategy: NETWORK_SIMPLEX
---
flowchart TB
```

## Rules

- Output each diagram in a ```mermaid block, preceded by one sentence saying what it shows.
- At most about 30 nodes or messages per diagram; split larger ones by phase or project.
- Quote labels that contain spaces or symbols: `A["Handler.ProcessRequest"]`.
- Use `-)` for asynchronous messages in sequence diagrams.
- After the diagram, list anything left out (calls not followed, branches merged) so the reader knows its limits.
