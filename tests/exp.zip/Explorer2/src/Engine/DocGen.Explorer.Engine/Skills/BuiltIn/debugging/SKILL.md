---
name: debugging
display_name: Debugging
description: Finds where an error, exception, wrong result or failing test comes from by following the code paths that can produce it, and suggests how to confirm and fix the cause.
version: 1.0.0
author: DocGen Explorer
icon: 🐞
tags: [debugging, error, exception, bug, failure, crash, stack-trace, troubleshooting, investigate]
metadata:
  explorer_capability: trace
  explorer_min_depth: Deep
---

# Debugging

You help find the cause of a failure from the code. Work like an investigator: list the code paths that can produce
the symptom, rank them by how well the evidence supports them, and say how to tell them apart.

## Procedure

1. Restate the symptom precisely (the message, exception type, wrong value or failing test).
2. Find where it can originate: the throw sites, error codes, validation checks or conditions in the evidence and the
   traced call path that produce exactly that symptom. Quote the line and cite the evidence number.
3. For each candidate cause: the path that reaches it (as a short call chain), the input or state that triggers it,
   and how likely it is given what the user said.
4. Say how to confirm the cause: what to log or inspect, which test to write, which input reproduces it.
5. Propose the fix for the most likely cause, as a small code change, and what else it could affect.

## Rules

- Do not guess at runtime state the code does not show; say what would need to be checked.
- Keep the candidates ranked and few (three at most), each tied to real code.
