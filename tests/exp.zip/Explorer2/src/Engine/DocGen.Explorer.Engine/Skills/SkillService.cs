using System.IO.Compression;
using System.Text;
using System.Text.RegularExpressions;
using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Engine.Storage;
using DocGen.Core.Skills;

namespace DocGen.Explorer.Engine.Skills;

/// <summary>What Settings → Skills stores (settings/skills.json).</summary>
public sealed class SkillSettings
{
    /// <summary>Pick a skill for each question from its words (when the question does not choose one).</summary>
    public bool AutoSelect { get; set; } = true;

    /// <summary>
    /// Ask: the chat model reads each question before the search (its intent, the part of the code it means, what the
    /// answer must contain) and asks back when the request is unclear.
    /// </summary>
    public bool ReadQuestionFirst { get; set; } = true;

    /// <summary>Skills turned off (by id); everything else installed is on, except skills that are off until turned on.</summary>
    public List<string> Disabled { get; set; } = [];

    /// <summary>Skills that are off until turned on (<c>metadata: explorer_default: off</c>, such as Test Fix) and were turned on.</summary>
    public List<string> Enabled { get; set; } = [];

    /// <summary>Test Fix: fix attempts (diagnose, patch, verify) before it stops and reports.</summary>
    public int TestFixMaxIterations { get; set; } = 3;

    /// <summary>Test Fix: the longest one command (a test run or build) may take, in seconds.</summary>
    public int TestFixTimeoutSeconds { get; set; } = 600;

    /// <summary>Test Fix: write the fix to the files (else it is only proposed).</summary>
    public bool TestFixApplyChanges { get; set; } = true;

    /// <summary>Test Fix: run the tests and builds (else nothing runs and every result is marked unverified).</summary>
    public bool TestFixRunCommands { get; set; } = true;

    /// <summary>Most steps an architecture trace follows (the Architect skill's program-flow table).</summary>
    public int TraceMaxSteps { get; set; } = 200;

    /// <summary>How deep a trace follows calls.</summary>
    public int TraceMaxDepth { get; set; } = 8;

    /// <summary>Most characters of a skill's instructions given to the model.</summary>
    public int MaxInstructionChars { get; set; } = 12_000;

    public const int MinTraceSteps = 20;
    public const int MaxTraceSteps = 600;
}

/// <summary>A skill as Settings shows it.</summary>
/// <param name="Replaces">The built-in skill an imported one replaces (same id): its explorer capability carries over.</param>
public sealed record SkillInfo(SkillManifest Manifest, bool Enabled, bool BuiltIn, SkillManifest? Replaces = null)
{
    public string Id => Manifest.Id;
    public string Name => Manifest.DisplayName;
    public string Icon => string.IsNullOrWhiteSpace(Manifest.Icon) ? "✦" : Manifest.Icon!;

    /// <summary>What the explorer does for the skill besides its instructions ("trace": the architecture trace).</summary>
    public string? Capability => Manifest.Metadata.GetValueOrDefault("explorer_capability") ?? Replaces?.Metadata.GetValueOrDefault("explorer_capability");

    /// <summary>The file the skill's answers are written for ("word": a .docx, "powerpoint": a .pptx), saved with one click.</summary>
    public string? Output => Manifest.Metadata.GetValueOrDefault("explorer_output") ?? Replaces?.Metadata.GetValueOrDefault("explorer_output");

    public string? MinDepth => Manifest.Metadata.GetValueOrDefault("explorer_min_depth") ?? Replaces?.Metadata.GetValueOrDefault("explorer_min_depth");

    /// <summary>Written for an agent with tools (it names tools the explorer does not have).</summary>
    public bool WrittenForAgent => Manifest.AllowedTools.Count > 0;

    /// <summary>Off until the person turns it on (<c>metadata: explorer_default: off</c>).</summary>
    public bool OffByDefault => SkillService.OffByDefault(Manifest) || (Replaces is { } r && SkillService.OffByDefault(r));
}

/// <summary>
/// Skills: packaged instructions (the SKILL.md format — front matter plus Markdown, optional references/) that
/// shape how the assistant answers a kind of question, and optionally an explorer capability (the Architect skill's
/// architecture trace). Built-in skills ship inside the engine and are written to the data folder; more can be
/// imported from a folder, a .zip or a skills collection. Settings → Skills turns them on and off.
/// </summary>
public sealed partial class SkillService(ExplorerStore store)
{
    public const string SettingsPath = "settings/skills.json";
    private const string BuiltInFolder = "skills/built-in";
    private const string ImportedFolder = "skills/imported";
    private readonly SemaphoreSlim _gate = new(1, 1);
    private List<SkillInfo>? _cache;

    public event EventHandler? Changed;

    public string BuiltInDirectory => Path.Combine(store.Root, BuiltInFolder);
    public string ImportedDirectory => Path.Combine(store.Root, ImportedFolder);

    public async Task<SkillSettings> GetSettingsAsync(CancellationToken ct = default)
        => await store.ReadAsync<SkillSettings>(SettingsPath, ct) ?? new SkillSettings();

    public async Task UpdateSettingsAsync(Action<SkillSettings> change, CancellationToken ct = default)
    {
        var settings = await GetSettingsAsync(ct);
        change(settings);
        settings.TraceMaxSteps = Math.Clamp(settings.TraceMaxSteps, SkillSettings.MinTraceSteps, SkillSettings.MaxTraceSteps);
        settings.TraceMaxDepth = Math.Clamp(settings.TraceMaxDepth, 2, 16);
        settings.MaxInstructionChars = Math.Clamp(settings.MaxInstructionChars, 1_000, SkillLimits.MaxInstructionChars);
        settings.Disabled = settings.Disabled.Distinct(StringComparer.Ordinal).ToList();
        settings.Enabled = settings.Enabled.Distinct(StringComparer.Ordinal).ToList();
        settings.TestFixMaxIterations = Math.Clamp(settings.TestFixMaxIterations, 1, 10);
        settings.TestFixTimeoutSeconds = Math.Clamp(settings.TestFixTimeoutSeconds, 30, 7200);
        await store.WriteAsync(SettingsPath, settings, ct);
        _cache = null;
        Changed?.Invoke(this, EventArgs.Empty);
    }

    public Task SetEnabledAsync(string id, bool enabled, CancellationToken ct = default) => UpdateSettingsAsync(s =>
    {
        s.Disabled.Remove(id);
        s.Enabled.Remove(id);
        (enabled ? s.Enabled : s.Disabled).Add(id);
    }, ct);

    /// <summary>A skill that is off until turned on: <c>metadata: explorer_default: off</c>.</summary>
    public static bool OffByDefault(SkillManifest manifest)
        => manifest.Metadata.TryGetValue("explorer_default", out var value) && value.Trim().Trim('"', '\'').Equals("off", StringComparison.OrdinalIgnoreCase);

    /// <summary>On: valid, not turned off, and — for a skill that is off by default — turned on.</summary>
    private static bool IsOn(SkillManifest manifest, SkillManifest? replaces, SkillSettings settings)
        => manifest.IsValid && !settings.Disabled.Contains(manifest.Id)
           && (!(OffByDefault(manifest) || (replaces is not null && OffByDefault(replaces))) || settings.Enabled.Contains(manifest.Id));

    /// <summary>Every installed skill (imported ones replace built-ins with the same id), valid or not.</summary>
    public async Task<IReadOnlyList<SkillInfo>> ListAsync(CancellationToken ct = default)
    {
        if (_cache is { } cached)
        {
            return cached;
        }
        await _gate.WaitAsync(ct);
        try
        {
            EnsureBuiltIns();
            var settings = await GetSettingsAsync(ct);
            var builtIn = Load(BuiltInDirectory, SkillScope.System);
            var imported = Load(ImportedDirectory, SkillScope.User);
            var all = imported.Concat(builtIn.Where(b => imported.All(i => i.Id != b.Id)))
                .Select(m => (Manifest: m, Replaces: m.Scope == SkillScope.System ? null : builtIn.FirstOrDefault(b => b.Id == m.Id)))
                .Select(x => new SkillInfo(x.Manifest, IsOn(x.Manifest, x.Replaces, settings), x.Manifest.Scope == SkillScope.System, x.Replaces))
                .OrderBy(s => s.BuiltIn ? 0 : 1).ThenBy(s => s.Name, StringComparer.OrdinalIgnoreCase).ToList();
            _cache = all;
            return all;
        }
        finally
        {
            _gate.Release();
        }
    }

    public async Task<IReadOnlyList<SkillInfo>> EnabledAsync(CancellationToken ct = default)
        => (await ListAsync(ct)).Where(s => s.Enabled).ToList();

    private static List<SkillManifest> Load(string root, SkillScope scope)
    {
        if (!Directory.Exists(root))
        {
            return [];
        }
        return Directory.EnumerateDirectories(root).Select(d =>
        {
            try
            {
                return SkillPackage.Load(d, scope);
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                return null;
            }
        }).OfType<SkillManifest>().ToList();
    }

    /// <summary>Writes the built-in skills shipped in the engine to the data folder (kept up to date with the engine).</summary>
    private void EnsureBuiltIns()
    {
        var assembly = typeof(SkillService).Assembly;
        const string prefix = "BuiltInSkill/";
        foreach (var name in assembly.GetManifestResourceNames().Where(n => n.StartsWith(prefix, StringComparison.Ordinal)))
        {
            var relative = name[prefix.Length..].Replace('\\', '/'); // architect/SKILL.md
            var target = Path.Combine(BuiltInDirectory, relative.Replace('/', Path.DirectorySeparatorChar));
            using var stream = assembly.GetManifestResourceStream(name)!;
            using var reader = new StreamReader(stream, Encoding.UTF8);
            var text = reader.ReadToEnd();
            if (!File.Exists(target) || File.ReadAllText(target) != text)
            {
                Directory.CreateDirectory(Path.GetDirectoryName(target)!);
                File.WriteAllText(target, text);
            }
        }
    }

    /// <summary>
    /// The skill for a question: the one asked for (by id, or "none"), else — with auto-select on — the best match
    /// of the question's words against each skill's name, tags and description (the skill router); a flow
    /// question prefers a skill with the trace capability, unless it asks for a document or a deck (a skill with an output).
    /// </summary>
    public async Task<SkillInfo?> SelectAsync(string question, string? requested, string intent, CancellationToken ct = default)
    {
        var enabled = await EnabledAsync(ct);
        if (requested is "none" || enabled.Count == 0)
        {
            return null;
        }
        // Test Fix runs commands and changes files: it is started on purpose (its own button), never as an answer skill.
        enabled = enabled.Where(s => s.Capability != "test-fix").ToList();
        if (!string.IsNullOrEmpty(requested) && requested != "auto")
        {
            return enabled.FirstOrDefault(s => s.Id == requested);
        }
        var settings = await GetSettingsAsync(ct);
        if (!settings.AutoSelect)
        {
            return null;
        }
        // A question that names the file it wants (a deck, a Word document) gets the skill that writes that file,
        // whatever it is about.
        if (AskedOutput(question) is { } output && enabled.FirstOrDefault(s => s.Output == output) is { } writer)
        {
            return writer;
        }
        var ranked = SkillRouter.Rank(question, enabled.Select(s => s.Manifest).ToList(), 3);
        if (intent == "flow" && enabled.FirstOrDefault(s => s.Capability == "trace" && s.Id == "architect") is { } architect
            && (ranked.Count == 0 || (ranked[0].Skill.Id is not ("debugging" or "diagram") && !ranked[0].Skill.Metadata.ContainsKey("explorer_output"))))
        {
            return architect;
        }
        return ranked.Count > 0 ? enabled.First(s => s.Id == ranked[0].Skill.Id) : null;
    }

    /// <summary>The file a question asks for: "powerpoint" (a ppt, slides, a deck), "word" (a Word document, a docx), else null.</summary>
    public static string? AskedOutput(string question)
        => PowerPointWords().IsMatch(question) ? "powerpoint" : WordWords().IsMatch(question) ? "word" : null;

    // "presentation layer" (and tier, model…) is code, not a deck.
    [GeneratedRegex(@"\b(pptx?|power\s?point|slides?|slide\s?deck|deck|presentation(?!\s+(layer|tier|model|logic|service|component)))\b", RegexOptions.IgnoreCase)]
    private static partial Regex PowerPointWords();

    [GeneratedRegex(@"\b(docx|ms[\s-]?word|word\s+(document|doc|file|format|report)|(in|as|into|to)\s+word)\b", RegexOptions.IgnoreCase)]
    private static partial Regex WordWords();

    /// <summary>The skill's instructions for the model (bounded).</summary>
    public async Task<string> InstructionsAsync(SkillInfo skill, CancellationToken ct = default)
    {
        var settings = await GetSettingsAsync(ct);
        var text = SkillPackage.ReadInstructions(skill.Manifest);
        return text.Length > settings.MaxInstructionChars ? text[..settings.MaxInstructionChars] + "\n…(instructions shortened)" : text;
    }

    /// <summary>Imports a skill package from a folder or a .zip (a package folder, or a folder of packages). Returns what was imported.</summary>
    /// <param name="onlyReplacementsOn">
    /// Import a whole collection (a skills/ folder) with only the skills that replace a built-in turned on; the
    /// rest (slides, spreadsheets… written for other tools) are there to turn on when wanted.
    /// </param>
    public async Task<IReadOnlyList<string>> ImportAsync(string path, CancellationToken ct = default, bool onlyReplacementsOn = false)
    {
        string source;
        string? temp = null;
        if (File.Exists(path) && path.EndsWith(".zip", StringComparison.OrdinalIgnoreCase))
        {
            temp = Path.Combine(Path.GetTempPath(), "docgen-skill-" + Guid.NewGuid().ToString("N")[..8]);
            ZipFile.ExtractToDirectory(path, temp);
            source = temp;
        }
        else if (File.Exists(path) && Path.GetFileName(path).Equals(SkillParser.FileName, StringComparison.OrdinalIgnoreCase))
        {
            source = Path.GetDirectoryName(path)!;
        }
        else if (Directory.Exists(path))
        {
            source = path;
        }
        else
        {
            throw new ExplorerValidationException("Choose a skill folder (with a SKILL.md), a SKILL.md file or a .zip of one.");
        }
        try
        {
            // A package folder, or a folder holding packages (a zip often wraps the package in one more folder).
            var packages = File.Exists(Path.Combine(source, SkillParser.FileName))
                ? [source]
                : Directory.EnumerateDirectories(source).Where(d => File.Exists(Path.Combine(d, SkillParser.FileName))).ToList();
            if (packages.Count == 0 && Directory.EnumerateDirectories(source).ToList() is [var only])
            {
                packages = Directory.EnumerateDirectories(only).Where(d => File.Exists(Path.Combine(d, SkillParser.FileName))).ToList();
            }
            if (packages.Count == 0)
            {
                throw new ExplorerValidationException("No SKILL.md was found there.");
            }
            var imported = new List<string>();
            var problems = new List<string>();
            foreach (var package in packages)
            {
                var parsed = SkillParser.Parse(await File.ReadAllTextAsync(Path.Combine(package, SkillParser.FileName), ct));
                if (!parsed.IsValid || parsed.Id is not { Length: > 0 } id)
                {
                    problems.Add($"{Path.GetFileName(package)}: {string.Join("; ", parsed.Diagnostics.Where(d => d.Severity == SkillDiagnosticSeverity.Error).Select(d => d.Message))}");
                    continue;
                }
                var target = Path.Combine(ImportedDirectory, id);
                if (Directory.Exists(target))
                {
                    Directory.Delete(target, recursive: true);
                }
                CopyPackage(package, target);
                imported.Add(id);
            }
            EnsureBuiltIns();
            var builtInIds = Load(BuiltInDirectory, SkillScope.System).Select(m => m.Id).ToHashSet(StringComparer.Ordinal);
            await UpdateSettingsAsync(s =>
            {
                foreach (var id in imported)
                {
                    s.Disabled.Remove(id);
                    if (onlyReplacementsOn && !builtInIds.Contains(id))
                    {
                        s.Disabled.Add(id);
                    }
                }
            }, ct);
            if (imported.Count == 0)
            {
                throw new ExplorerValidationException("Nothing was imported. " + string.Join(" ", problems));
            }
            return imported;
        }
        finally
        {
            if (temp is not null && Directory.Exists(temp))
            {
                Directory.Delete(temp, recursive: true);
            }
        }
    }

    /// <summary>Copies the package's SKILL.md and its references/templates/examples/assets (never scripts, never links).</summary>
    private static void CopyPackage(string from, string to)
    {
        Directory.CreateDirectory(to);
        File.Copy(Path.Combine(from, SkillParser.FileName), Path.Combine(to, SkillParser.FileName), overwrite: true);
        foreach (var folder in SkillPackage.Folders.Where(f => f != "scripts"))
        {
            var dir = Path.Combine(from, folder);
            if (!Directory.Exists(dir) || SkillPackage.IsLink(new DirectoryInfo(dir)))
            {
                continue;
            }
            foreach (var file in Directory.EnumerateFiles(dir, "*", SearchOption.AllDirectories).Take(SkillLimits.MaxFiles))
            {
                var info = new FileInfo(file);
                if (SkillPackage.IsLink(info) || info.Length > SkillLimits.MaxFileBytes)
                {
                    continue;
                }
                var target = Path.Combine(to, Path.GetRelativePath(from, file));
                Directory.CreateDirectory(Path.GetDirectoryName(target)!);
                File.Copy(file, target, overwrite: true);
            }
        }
    }

    /// <summary>Removes an imported skill (built-ins can only be turned off).</summary>
    public Task RemoveAsync(string id)
    {
        var target = Path.Combine(ImportedDirectory, id);
        if (!SkillParser.IsValidId(id) || !Directory.Exists(target))
        {
            throw new ExplorerValidationException("Only imported skills can be removed; built-in skills can be turned off.");
        }
        Directory.Delete(target, recursive: true);
        _cache = null;
        Changed?.Invoke(this, EventArgs.Empty);
        return Task.CompletedTask;
    }

    /// <summary>Where a collection keeps its skills: a skills/ folder next to its solution, or in its published app.</summary>
    public static string? FindSkillCollection(string collectionFolder)
    {
        foreach (var candidate in new[] { Path.Combine(collectionFolder, "skills"), Path.Combine(collectionFolder, "publish", "skills"), collectionFolder })
        {
            if (Directory.Exists(candidate) && Directory.EnumerateDirectories(candidate).Any(d => File.Exists(Path.Combine(d, SkillParser.FileName))))
            {
                return candidate;
            }
        }
        return null;
    }

    public void Invalidate() => _cache = null;
}
