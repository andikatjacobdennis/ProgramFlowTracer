namespace DocGen.Explorer.Engine.Models;

public static class ConceptTypes
{
    public const string Repository = "Repository";
    public const string Project = "Project";
    public const string Namespace = "Namespace";
    public const string File = "File";
    public const string Class = "Class";
    public const string Interface = "Interface";
    public const string Record = "Record";
    public const string Struct = "Struct";
    public const string Enum = "Enum";
    public const string Test = "Test";
    public const string DocumentationPage = "Documentation Page";
    public const string MarkdownFile = "Markdown File";
    public const string Endpoint = "Endpoint";

    /// <summary>A group of concepts in the grouped view of the graph (not part of the indexed graph).</summary>
    public const string Group = "Group";

    public static readonly IReadOnlyList<string> All =
        [Class, Interface, Record, Struct, Enum, Test, File, DocumentationPage, MarkdownFile, Namespace, Project, Repository, Endpoint];

    public static bool IsType(string type) => type is Class or Interface or Record or Struct or Enum or Test;
}

public static class EdgeKinds
{
    public const string Contains = "contains";
    public const string Declares = "declares";
    public const string Inherits = "inherits";
    public const string Uses = "uses";
    public const string Calls = "calls";
    public const string Tests = "tests";
    public const string References = "references";
    public const string Documents = "documents";
    public const string Mentions = "mentions";
}

public sealed class GraphNode
{
    public string Id { get; set; } = "";
    public string Label { get; set; } = "";
    public string Type { get; set; } = "";
    public string? Path { get; set; }
    public int? Line { get; set; }

    /// <summary>Fully qualified name for symbols, page id for documentation pages.</summary>
    public string? Key { get; set; }

    /// <summary>A one-line description (written by the model when one is configured, otherwise from the index).</summary>
    public string? Description { get; set; }
}

public sealed class GraphEdge
{
    public string From { get; set; } = "";
    public string To { get; set; } = "";
    public string Kind { get; set; } = "";
}

public sealed class KnowledgeGraph
{
    public List<GraphNode> Nodes { get; set; } = [];
    public List<GraphEdge> Edges { get; set; } = [];

    private Dictionary<string, GraphNode>? _byId;

    public GraphNode? Find(string id)
    {
        _byId ??= Nodes.GroupBy(n => n.Id).ToDictionary(g => g.Key, g => g.First());
        return _byId.GetValueOrDefault(id);
    }

    public void InvalidateLookup() => _byId = null;

    public IEnumerable<GraphEdge> EdgesOf(string id) => Edges.Where(e => e.From == id || e.To == id);

    public IEnumerable<string> Neighbours(string id) => EdgesOf(id).Select(e => e.From == id ? e.To : e.From).Distinct();

    public int Degree(string id) => Edges.Count(e => e.From == id || e.To == id);

    public Dictionary<string, int> TypeCounts() =>
        Nodes.GroupBy(n => n.Type).OrderBy(g => g.Key, StringComparer.Ordinal).ToDictionary(g => g.Key, g => g.Count());
}

/// <summary>A node position produced by <see cref="Graph.GraphLayout"/>.</summary>
public readonly record struct NodePosition(string Id, double X, double Y);
