namespace DocGen.Explorer.Engine.Models;

/// <summary>One call to the configured model, recorded as it is made. Nothing is estimated.</summary>
public sealed class UsageEntry
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N")[..12];
    public DateTime At { get; set; } = DateTime.UtcNow;

    /// <summary>assistant | describe-graph | learning | studio | refine | test</summary>
    public string Feature { get; set; } = "";

    public string ModelId { get; set; } = "";
    public string ProviderId { get; set; } = "";
    public string? RepositoryId { get; set; }
    public int InputTokens { get; set; }
    public int OutputTokens { get; set; }
    public int CachedInputTokens { get; set; }
    public long DurationMs { get; set; }
    public decimal Cost { get; set; }
    public bool Failed { get; set; }

    // ---- What the call was (recorded from this version on; older entries leave these empty) ----

    /// <summary>The name the provider knows the model by (example-chat-model), when it differs from the model's id.</summary>
    public string? ProviderModelId { get; set; }

    /// <summary>What the call was for, in one line: the question asked, the request, the topic…</summary>
    public string? Purpose { get; set; }

    /// <summary>The messages sent: role, size and the start of each.</summary>
    public List<UsageMessage>? Messages { get; set; }

    /// <summary>The start of what came back.</summary>
    public string? Response { get; set; }

    public int ResponseChars { get; set; }

    /// <summary>Characters of reasoning a reasoning model streamed before answering.</summary>
    public int ReasoningChars { get; set; }

    /// <summary>Why the model stopped (stop, length…), when the provider said.</summary>
    public string? FinishReason { get; set; }

    /// <summary>The error, when the call failed.</summary>
    public string? Error { get; set; }

    public int? MaxOutputTokens { get; set; }
    public double? Temperature { get; set; }
    public bool Streamed { get; set; }

    /// <summary>Prices per million tokens the cost was computed with (null: no price set).</summary>
    public decimal? InputPricePerMillion { get; set; }
    public decimal? OutputPricePerMillion { get; set; }

    public int TotalTokens => InputTokens + OutputTokens;

    public bool HasDetails => Messages is { Count: > 0 } || Purpose is not null;
}

/// <summary>One message of a recorded call.</summary>
public sealed class UsageMessage
{
    public string Role { get; set; } = "";
    public int Chars { get; set; }

    /// <summary>About four characters a token.</summary>
    public int ApproxTokens => (Chars + 3) / 4;

    public string Preview { get; set; } = "";
}

public sealed class UsageSummary
{
    public int Days { get; set; }
    public int Calls { get; set; }
    public long InputTokens { get; set; }
    public long OutputTokens { get; set; }
    public long TotalTokens => InputTokens + OutputTokens;
    public decimal Cost { get; set; }
    public int Failures { get; set; }
    public List<UsageEntry> Entries { get; set; } = [];
    public Dictionary<string, long> TokensByFeature { get; set; } = [];

    /// <summary>Input and output tokens per day (every day of the range, zero when nothing was called).</summary>
    public SortedDictionary<DateOnly, (long Input, long Output)> TokensByDayDetail { get; set; } = [];

    public Dictionary<string, int> CallsByFeature { get; set; } = [];
    public Dictionary<string, long> TokensByModel { get; set; } = [];
    public SortedDictionary<DateOnly, long> TokensByDay { get; set; } = [];
}

/// <summary>Per-million-token prices for a model (optional; costs show only when a price is set).</summary>
public sealed class ModelPrice
{
    public string ModelId { get; set; } = "";
    public decimal InputPerMillion { get; set; }
    public decimal OutputPerMillion { get; set; }
}

/// <summary>
/// The order of the explorer's three panes from left to right: the files (documentation list), the page, and Ask (the
/// assistant).
/// </summary>
public static class PaneLayout
{
    public const string Files = "files";
    public const string Page = "page";
    public const string Ask = "ask";
    public const string Default = "files,page,ask";

    /// <summary>Every arrangement, with a name to choose it by.</summary>
    public static readonly IReadOnlyList<(string Order, string Label)> Choices =
    [
        ("files,page,ask", "Files · Page · Ask"),
        ("ask,page,files", "Ask · Page · Files"),
        ("files,ask,page", "Files · Ask · Page"),
        ("ask,files,page", "Ask · Files · Page"),
        ("page,files,ask", "Page · Files · Ask"),
        ("page,ask,files", "Page · Ask · Files"),
    ];

    /// <summary>The order as three names; anything that is not the three panes once each gives the default.</summary>
    public static string[] Parse(string? order)
    {
        var parts = (order ?? "").Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries).Select(p => p.ToLowerInvariant()).ToArray();
        return parts.Length == 3 && parts.Distinct().Count() == 3 && parts.All(p => p is Files or Page or Ask) ? parts : Default.Split(',');
    }

    public static string Normalize(string? order) => string.Join(',', Parse(order));

}

/// <summary>The explorer's own preferences (data/settings/explorer.json).</summary>
public sealed class ExplorerSettings
{
    /// <summary>The chat model the explorer uses; null or empty means evidence mode (no model).</summary>
    public string? ChatModelId { get; set; }

    /// <summary>auto | light | dark</summary>
    public string Theme { get; set; } = "auto";

    public bool ReduceMotion { get; set; }
    public List<ModelPrice> Prices { get; set; } = [];
    public int MaxGraphNodes { get; set; } = 400;
    public bool DescribeGraphWithModel { get; set; } = true;
    public string? LastRepositoryId { get; set; }
    public double AssistantWidth { get; set; } = 400;
    public double TreeWidth { get; set; } = 280;
    public bool AssistantVisible { get; set; } = true;
    public bool TreeVisible { get; set; } = true;

    /// <summary>The order of the panes from left to right: "files", "page" and "ask", comma-separated.</summary>
    public string PaneOrder { get; set; } = PaneLayout.Default;

    /// <summary>The interface's size (1 = 100%), changed with Ctrl+= / Ctrl+- / Ctrl+0.</summary>
    public double Zoom { get; set; } = 1.0;

    /// <summary>Shortcuts changed in Settings → Shortcuts (action → keys such as "Ctrl+K"; "" = none). Others keep their default.</summary>
    public Dictionary<string, string> Shortcuts { get; set; } = [];

    /// <summary>The persona Talk uses (its id); the Friendly Guide at first.</summary>
    public string TalkPersona { get; set; } = "guide";

    /// <summary>Read aloud with Microsoft Edge's natural (neural) voices, online; the Windows voices otherwise.</summary>
    public bool NaturalVoices { get; set; } = true;

    /// <summary>The voice answers are read in (an Edge natural voice name or an installed Windows voice).</summary>
    public string ReadAloudVoice { get; set; } = Speech.EdgeTts.DefaultVoice;

    /// <summary>How attached files are read, by kind (Settings → Attachments); the defaults for a kind not listed.</summary>
    public List<AttachmentRule> AttachmentRules { get; set; } = Assistant.Attachments.DefaultRules();

    /// <summary>The most files attached to one question.</summary>
    public int MaxAttachments { get; set; } = 10;

    /// <summary>Questions can be dictated: the microphone button shows in Ask (when a microphone can be used).</summary>
    public bool DictationEnabled { get; set; } = true;

    /// <summary>
    /// How dictation is recognised: "online" (Windows' online speech recognition, Microsoft's cloud engine; it listens to
    /// the Windows default microphone), "whisper" (a Whisper model on this PC, with the microphone chosen here) or
    /// "offline" (Windows' recogniser on this PC, with the microphone chosen here).
    /// </summary>
    public string DictationEngine { get; set; } = "whisper";

    /// <summary>The Whisper model dictation uses when <see cref="DictationEngine"/> is "whisper" (e.g. "base.en").</summary>
    public string WhisperModel { get; set; } = "base.en";

    /// <summary>The microphone questions are dictated with (a name Windows lists); empty: the Windows default.</summary>
    public string MicrophoneDevice { get; set; } = "";

    /// <summary>The microphone button: "toggle" (click to start, click again to stop) or "hold" (hold to talk).</summary>
    public string MicrophoneMode { get; set; } = "toggle";

    /// <summary>Dictation stops by itself after this many seconds without sound (0: it listens until stopped).</summary>
    public int SilenceStopSeconds { get; set; } = 5;

    /// <summary>When dictation stops, send the question at once (instead of leaving it in the box to edit).</summary>
    public bool DictationSends { get; set; }

    /// <summary>The language questions are dictated in (an installed speech recogniser, e.g. "en-GB"); empty: Windows'.</summary>
    public string DictationLanguage { get; set; } = "";

    /// <summary>
    /// How many times the chat model is asked to fix a Mermaid diagram that could not be drawn (0: never). Each attempt
    /// sends the diagram and the error, and draws what comes back.
    /// </summary>
    public int DiagramRepairAttempts { get; set; } = 2;

    /// <summary>The persona who hosts quizzes and flashcards in Learning (empty: the first persona).</summary>
    public string? LearningHostId { get; set; }

    // ----- Reading and writing (Settings → Reading and writing) -----

    /// <summary>Lines one notch of the mouse wheel scrolls a page, a file or a conversation (Windows scrolls 3 lines of 16 px).</summary>
    public double WheelLines { get; set; } = 2;

    /// <summary>Smooth scrolling: a notch glides to its place instead of jumping.</summary>
    public bool SmoothScrolling { get; set; } = true;

    /// <summary>Spelling mistakes in the question box are underlined in red.</summary>
    public bool SpellCheck { get; set; } = true;

    /// <summary>Clicking an underlined word shows its suggestions (else they are on the right-click menu only).</summary>
    public bool SpellCheckOnClick { get; set; } = true;

    /// <summary>Pasted pictures, files and long or structured text (JSON, XML…) become attachments instead of text in the box.</summary>
    public bool PasteAsAttachment { get; set; } = true;

    /// <summary>Pasted text of at least this many characters becomes an attachment (structured text always does).</summary>
    public int PasteAttachmentChars { get; set; } = 400;

    /// <summary>Pasted text of at least this many lines becomes an attachment.</summary>
    public int PasteAttachmentLines { get; set; } = 6;

    /// <summary>Find: matches are highlighted in yellow as you type (else only when Find is pressed).</summary>
    public bool FindAsYouType { get; set; } = true;

    /// <summary>Logs: how often the log viewer refreshes itself while auto refresh is on, in seconds.</summary>
    public int LogRefreshSeconds { get; set; } = 5;

    /// <summary>Docs: files and folders of a local repository can be added, renamed, edited and deleted.</summary>
    public bool AllowFileEditing { get; set; } = true;

    /// <summary>Docs: a file's tooltip in the tree shows its details (size, dates, lines…), not only its name.</summary>
    public bool DetailedFileTips { get; set; } = true;
}
