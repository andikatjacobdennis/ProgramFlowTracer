namespace DocGen.Explorer.Engine.Models;

public static class ConversationStyles
{
    public static readonly IReadOnlyList<string> All =
    [
        "Technical discussion", "Explainer", "Interview", "Walkthrough", "Debate", "Code review", "Onboarding chat",
    ];
}

public sealed class StudioRequest
{
    public string Topic { get; set; } = "";
    public List<string> PersonaIds { get; set; } = [];
    public string Style { get; set; } = "Technical discussion";
    public int LengthMinutes { get; set; } = 10;
    public string? Title { get; set; }
    public List<string> Scope { get; set; } = [];

    public const int MinSpeakers = 2;
    public const int MaxSpeakers = 4;
}

public sealed class TranscriptLine
{
    public string Speaker { get; set; } = "";
    public string PersonaId { get; set; } = "";
    public string Text { get; set; } = "";
    public string? Path { get; set; }
    public int Line { get; set; }

    /// <summary>How the speaker feels saying it (one of Studio.Emotions.All): tagged by the model or read from the words.</summary>
    public string? Emotion { get; set; }
}

public sealed class StudioConversation
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string RepositoryId { get; set; } = "";
    public string Title { get; set; } = "";
    public string Topic { get; set; } = "";
    public string Style { get; set; } = "";
    public int LengthMinutes { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public List<TranscriptLine> Lines { get; set; } = [];
    public string Provenance { get; set; } = "";

    public int WordCount => Lines.Sum(l => l.Text.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries).Length);
}

public sealed class PersonaDocument
{
    public List<DocGen.Core.Models.Persona> Personas { get; set; } = [];
}
