using System.Text.Json.Serialization;

namespace DocGen.Explorer.Engine.Models;

[JsonConverter(typeof(JsonStringEnumConverter<AnalysisDepth>))]
public enum AnalysisDepth
{
    Auto,
    Quick,
    Balanced,
    Detailed,
    Deep,
    Expert,
}

/// <summary>A file the answer was drawn from.</summary>
public sealed class Citation
{
    public int Number { get; set; }
    public string Path { get; set; } = "";
    public int StartLine { get; set; }
    public int EndLine { get; set; }
    public string Title { get; set; } = "";
    public double Score { get; set; }

    [JsonIgnore]
    public string Location => StartLine > 0 ? $"{Path}:{StartLine}" : Path;
}

/// <summary>What became of an attached file.</summary>
public enum AttachmentStatus
{
    Read,
    Truncated,
    NotSupported,
    TurnedOff,
    TooLarge,
    Unreadable,
}

/// <summary>A file attached to a question: what it is, and what was read from it (kept with the question, for Retry).</summary>
public sealed record Attachment
{
    public string Name { get; init; } = "";
    public long Size { get; init; }

    /// <summary>text | pdf | word | image; null when there is no reader for it.</summary>
    public string? Kind { get; init; }

    public AttachmentStatus Status { get; init; } = AttachmentStatus.NotSupported;

    /// <summary>Why it was not (fully) read, for the person and the model.</summary>
    public string? Note { get; init; }

    /// <summary>The text read (within the length set for its kind).</summary>
    public string? Text { get; init; }

    /// <summary>An image: its media type and content (sent to a model that can view images).</summary>
    public string? MediaType { get; init; }

    public string? ImageBase64 { get; init; }

    [JsonIgnore]
    public bool IsRead => Status is AttachmentStatus.Read or AttachmentStatus.Truncated;
}

/// <summary>How attachments of one kind are read (Settings → Attachments).</summary>
public sealed class AttachmentRule
{
    /// <summary>text | pdf | word | image</summary>
    public string Kind { get; set; } = "";

    /// <summary>Whether files of this kind are read (off: attached by name only).</summary>
    public bool Enabled { get; set; } = true;

    /// <summary>The largest file read, in megabytes.</summary>
    public double MaxSizeMb { get; set; } = 10;

    /// <summary>The most characters of its text sent to the model (0: no limit; not used for images).</summary>
    public int MaxChars { get; set; } = 60_000;

    /// <summary>Images: the longest side, in pixels, a larger image is scaled down to (0: not scaled).</summary>
    public int MaxPixels { get; set; }
}

public sealed class ChatMessage
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");

    /// <summary>Files attached to a question (user messages).</summary>
    public List<Attachment>? Attachments { get; set; }

    /// <summary>user | assistant</summary>
    public string Role { get; set; } = "user";

    public string Text { get; set; } = "";
    public DateTime At { get; set; } = DateTime.UtcNow;
    public List<Citation> Citations { get; set; } = [];
    public List<string> Diagnostics { get; set; } = [];
    public int InputTokens { get; set; }
    public int OutputTokens { get; set; }
    public long DurationMs { get; set; }
    public AnalysisDepth Depth { get; set; }

    /// <summary>The model that wrote the answer, or "evidence" when it was composed offline from the index.</summary>
    public string? Model { get; set; }

    public bool Failed { get; set; }

    /// <summary>What the assistant did to answer (shown under "Working through this").</summary>
    public List<string> Steps { get; set; } = [];

    /// <summary>The model's own reasoning, when it shares it (reasoning models).</summary>
    public string? Thinking { get; set; }

    /// <summary>The skill that shaped the answer (its id), when one did.</summary>
    public string? Skill { get; set; }

    /// <summary>The skill's icon and name, as shown on the answer.</summary>
    public string? SkillName { get; set; }

    /// <summary>The file the answer was written as ("word" or "powerpoint", from its skill): the answer offers to save it so.</summary>
    public string? Output { get; set; }

    /// <summary>Talk: the persona that answered (its name), so a switch mid-conversation stays visible.</summary>
    public string? Persona { get; set; }

    /// <summary>The Test Fix run this message reports (its record holds the commands, logs and patches).</summary>
    public string? TestFixRunId { get; set; }

    /// <summary>A Test Fix request (on the person's message): what to run, so the run can be repeated.</summary>
    public DocGen.Explorer.Engine.TestFix.TestFixRequest? TestFix { get; set; }

    /// <summary>A question back, when the request was unclear: the reply to it completes the question before it.</summary>
    public DocGen.Explorer.Engine.Assistant.Clarification? Clarify { get; set; }

    /// <summary>A request to summarise a selection (on the user's message): what was selected, so Retry summarises the same thing.</summary>
    public SummaryRequest? Summary { get; set; }

    /// <summary>Summaries of this answer's diagrams, written under each diagram (key: <see cref="SummaryRequest.Key"/> of its source).</summary>
    public Dictionary<string, string>? DiagramSummaries { get; set; }

    [JsonIgnore]
    public int TotalTokens => InputTokens + OutputTokens;
}

/// <summary>What a summary was made from: the selected text or a diagram's Mermaid source, and where it came from.</summary>
public sealed class SummaryRequest
{
    public string Selection { get; set; } = "";
    public bool Diagram { get; set; }
    public string? Source { get; set; }

    /// <summary>A short, stable key for a diagram's source (its summaries are kept under it).</summary>
    public static string Key(string source)
        => Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(System.Text.Encoding.UTF8.GetBytes(source.Trim().ReplaceLineEndings("\n"))))[..16];
}

public sealed class Conversation
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Title { get; set; } = "New conversation";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public List<ChatMessage> Messages { get; set; } = [];
}

public sealed class ConversationSummary
{
    public string Id { get; set; } = "";
    public string Title { get; set; } = "";
    public DateTime UpdatedAt { get; set; }
    public int Messages { get; set; }

    /// <summary>A search: how many times the words occur in the conversation, and the first place, in context.</summary>
    public int Matches { get; set; }

    public string? Snippet { get; set; }
}

/// <summary>A retrieved piece of evidence with its fused score and the methods that found it.</summary>
public sealed class Evidence
{
    public Chunk Chunk { get; set; } = new();
    public double Score { get; set; }
    public List<string> Methods { get; set; } = [];
}

/// <summary>A streamed piece of an answer.</summary>
public sealed record AnswerDelta(string Text);

public sealed class SearchHit
{
    /// <summary>Class, Interface, Method, File, Documentation, Line …</summary>
    public string Kind { get; set; } = "";

    public string Title { get; set; } = "";
    public string Path { get; set; } = "";
    public int Line { get; set; }

    /// <summary>exact | file | keyword | semantic | symbol | heading</summary>
    public string Method { get; set; } = "";

    public string? Snippet { get; set; }
    public double Score { get; set; }

    /// <summary>A documentation page to open instead of a file.</summary>
    public string? PageId { get; set; }

    [JsonIgnore]
    public string Location => Line > 0 ? $"{Path}:{Line}" : Path;
}
