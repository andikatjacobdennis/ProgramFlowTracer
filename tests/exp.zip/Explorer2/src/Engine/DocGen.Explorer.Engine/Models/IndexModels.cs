using System.Text.Json.Serialization;

namespace DocGen.Explorer.Engine.Models;

[JsonConverter(typeof(JsonStringEnumConverter<FileKind>))]
public enum FileKind
{
    Documentation,
    Source,
    Config,
    Other,
}

/// <summary>A file the ingestion filters kept.</summary>
public sealed class ScannedFile
{
    /// <summary>Path relative to the repository root, with forward slashes.</summary>
    public string Path { get; set; } = "";

    public long Size { get; set; }
    public int Lines { get; set; }
    public string Language { get; set; } = "";
    public FileKind Kind { get; set; }
    public string Hash { get; set; } = "";
    public long LastWriteTicks { get; set; }

    [JsonIgnore]
    public string Name => System.IO.Path.GetFileName(Path);
}

[JsonConverter(typeof(JsonStringEnumConverter<StageStatus>))]
public enum StageStatus
{
    Pending,
    Running,
    Done,
    Skipped,
    Failed,
}

public static class IndexStages
{
    public const string Scanning = "Scanning";
    public const string Classifying = "Classifying";
    public const string ParsingDocumentation = "ParsingDocumentation";
    public const string Chunking = "Chunking";
    public const string Embedding = "Embedding";
    public const string BuildingGraph = "BuildingGraph";
    public const string AnalyzingOkf = "AnalyzingOkf";
    public const string DescribingGraph = "DescribingGraph";
    public const string Finalizing = "Finalizing";

    public static readonly IReadOnlyList<string> All =
        [Scanning, Classifying, ParsingDocumentation, Chunking, Embedding, BuildingGraph, AnalyzingOkf, DescribingGraph, Finalizing];
}

public sealed class StageResult
{
    public string Name { get; set; } = "";
    public StageStatus Status { get; set; } = StageStatus.Pending;
    public string Detail { get; set; } = "";
    public long DurationMs { get; set; }
}

[JsonConverter(typeof(JsonStringEnumConverter<IndexMode>))]
public enum IndexMode
{
    /// <summary>Reads only what changed since the last run.</summary>
    Incremental,

    /// <summary>Throws the index away and reads everything again.</summary>
    Full,
}

[JsonConverter(typeof(JsonStringEnumConverter<RunState>))]
public enum RunState
{
    Running,
    Completed,
    Cancelled,
    Failed,
}

/// <summary>One indexing run: its mode, stages and outcome.</summary>
public sealed class IndexRun
{
    public IndexMode Mode { get; set; }
    public RunState State { get; set; } = RunState.Running;
    public DateTime StartedAt { get; set; } = DateTime.UtcNow;
    public DateTime? FinishedAt { get; set; }
    public string? Error { get; set; }
    public List<StageResult> Stages { get; set; } = IndexStages.All.Select(s => new StageResult { Name = s }).ToList();

    /// <summary>The chunking rules this run used (<see cref="Indexing.Chunker.Version"/>); 0 for runs before it was recorded.</summary>
    public int ChunkerVersion { get; set; }

    public StageResult Stage(string name) => Stages.First(s => s.Name == name);

    /// <summary>0..1 by completed stages.</summary>
    [JsonIgnore]
    public double Progress => Stages.Count == 0 ? 0 : Stages.Count(s => s.Status is StageStatus.Done or StageStatus.Skipped) / (double)Stages.Count;
}

/// <summary>Progress notification from the pipeline.</summary>
public sealed record IndexProgress(string RepositoryId, IndexRun Run, string? Message);

/// <summary>A searchable, embeddable piece of a file.</summary>
public sealed class Chunk
{
    public string Id { get; set; } = "";
    public string Path { get; set; } = "";
    public int StartLine { get; set; }
    public int EndLine { get; set; }

    /// <summary>doc | code | config | text</summary>
    public string Kind { get; set; } = "text";

    /// <summary>Heading or symbol this chunk covers.</summary>
    public string Title { get; set; } = "";

    public string? Symbol { get; set; }
    public string Text { get; set; } = "";

    /// <summary>For external material (Confluence pages): where to open it.</summary>
    public string? Url { get; set; }
}

public sealed class Heading
{
    public int Level { get; set; }
    public string Text { get; set; } = "";
    public string Anchor { get; set; } = "";
    public int Line { get; set; }
}

/// <summary>A documentation page: a Markdown file of the repository or a page the explorer generated.</summary>
public sealed class DocPage
{
    public string Id { get; set; } = "";
    public string Title { get; set; } = "";

    /// <summary>Where the page sits in the documentation tree ("docs/notes", "Reference/Overview").</summary>
    public string TreePath { get; set; } = "";

    /// <summary>The repository file it comes from (null for generated pages).</summary>
    public string? SourcePath { get; set; }

    public bool Generated { get; set; }
    public List<Heading> Headings { get; set; } = [];
}

/// <summary>Operational knowledge facts: configuration keys, endpoints, service registrations, middleware, packages.</summary>
public sealed class OkfEntity
{
    /// <summary>config | endpoint | service | middleware | package | entrypoint</summary>
    public string Kind { get; set; } = "";

    public string Name { get; set; } = "";
    public string Detail { get; set; } = "";
    public string Path { get; set; } = "";
    public int Line { get; set; }
}
