using System.Text.Json.Serialization;

namespace DocGen.Explorer.Engine.Models;

[JsonConverter(typeof(JsonStringEnumConverter<Difficulty>))]
public enum Difficulty
{
    Easy,
    Medium,
    Hard,
}

[JsonConverter(typeof(JsonStringEnumConverter<FeedbackTiming>))]
public enum FeedbackTiming
{
    AfterEachQuestion,
    AtTheEnd,
}

public static class Audiences
{
    public static readonly IReadOnlyList<string> All =
    [
        "New developer", "Developer", "Senior developer", "Architect", "QA engineer", "DevOps engineer", "Product manager", "Security engineer",
    ];
}

public static class LearningTopics
{
    public const string Architecture = "Architecture";
    public const string Services = "Services";
    public const string Apis = "APIs";
    public const string DomainLogic = "Domain logic";
    public const string Database = "Database";
    public const string Classes = "Classes";
    public const string Dependencies = "Dependencies";
    public const string Configuration = "Configuration";
    public const string Security = "Security";
    public const string Testing = "Testing";
    public const string Infrastructure = "Infrastructure";
    public const string Setup = "Setup";

    public static readonly IReadOnlyList<string> All =
        [Architecture, Services, Apis, DomainLogic, Database, Classes, Dependencies, Configuration, Security, Testing, Infrastructure, Setup];
}

/// <summary>Settings shared by every generator; each generator uses the ones that apply to it.</summary>
public sealed class GenerationOptions
{
    public string? Title { get; set; }
    public int Count { get; set; } = 10;
    public Difficulty Difficulty { get; set; } = Difficulty.Medium;
    public string Audience { get; set; } = "Developer";
    public List<string> Topics { get; set; } = [];
    public int PassMarkPercent { get; set; } = 70;
    public int TimeLimitMinutes { get; set; }
    public FeedbackTiming Feedback { get; set; } = FeedbackTiming.AtTheEnd;
    public bool ShuffleQuestions { get; set; } = true;
    public bool ShuffleAnswers { get; set; } = true;

    /// <summary>Folders and files to draw on (relative paths); empty means the whole repository.</summary>
    public List<string> Scope { get; set; } = [];

    /// <summary>Makes otherwise identical generations differ ("Generate again").</summary>
    public int Seed { get; set; }
}

public sealed class QuizQuestion
{
    public string Id { get; set; } = "";
    public string Prompt { get; set; } = "";
    public List<string> Options { get; set; } = [];
    public int CorrectIndex { get; set; }
    public string Explanation { get; set; } = "";
    public string Topic { get; set; } = "";
    public string? Path { get; set; }
    public int Line { get; set; }

    /// <summary>The concept this question checks (symbol, file or page), for the knowledge record.</summary>
    public string Concept { get; set; } = "";
}

public sealed class QuizAttempt
{
    public DateTime At { get; set; } = DateTime.UtcNow;
    public List<int> Answers { get; set; } = [];
    public int Correct { get; set; }
    public int Total { get; set; }
    public double Percent { get; set; }
    public bool Passed { get; set; }
    public long DurationSeconds { get; set; }
}

public abstract class LearningItem
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Title { get; set; } = "";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public bool Archived { get; set; }
    public GenerationOptions Options { get; set; } = new();

    /// <summary>How it was written ("Written offline from retrieved evidence, without a model." or the model's name).</summary>
    public string Provenance { get; set; } = "";
}

public sealed class Quiz : LearningItem
{
    public List<QuizQuestion> Questions { get; set; } = [];
    public List<QuizAttempt> Attempts { get; set; } = [];
}

public sealed class LearningSession
{
    public int Number { get; set; }
    public string Title { get; set; } = "";
    public string Goal { get; set; } = "";
    public List<string> ReadFirst { get; set; } = [];
    public List<string> ReadNext { get; set; } = [];
    public string TryThis { get; set; } = "";
    public int Minutes { get; set; }
    public bool Completed { get; set; }
}

public sealed class LearningPath : LearningItem
{
    public string Introduction { get; set; } = "";
    public List<LearningSession> Sessions { get; set; } = [];
}

public sealed class Flashcard
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Front { get; set; } = "";
    public string Back { get; set; } = "";
    public string Topic { get; set; } = "";
    public string Concept { get; set; } = "";
    public string? Path { get; set; }
    public int Line { get; set; }

    // SM-2 scheduling state.
    public double Ease { get; set; } = 2.5;
    public int IntervalDays { get; set; }
    public int Repetitions { get; set; }
    public DateTime DueAt { get; set; } = DateTime.UtcNow;
    public int Reviews { get; set; }
    public int Lapses { get; set; }
}

[JsonConverter(typeof(JsonStringEnumConverter<RecallGrade>))]
public enum RecallGrade
{
    Again = 0,
    Hard = 3,
    Good = 4,
    Easy = 5,
}

public sealed class FlashcardDeck : LearningItem
{
    public List<Flashcard> Cards { get; set; } = [];
}

public sealed class FaqEntry
{
    public string Question { get; set; } = "";
    public string Answer { get; set; } = "";
    public List<Citation> Citations { get; set; } = [];
}

public sealed class Faq : LearningItem
{
    public List<FaqEntry> Entries { get; set; } = [];
}

/// <summary>One observation for the knowledge record (a quiz answer or a card review).</summary>
public sealed class KnowledgeEvent
{
    public DateTime At { get; set; } = DateTime.UtcNow;
    public string Topic { get; set; } = "";
    public string Concept { get; set; } = "";
    public bool Success { get; set; }

    /// <summary>quiz | card</summary>
    public string Source { get; set; } = "quiz";
}

public sealed class KnowledgeRecord
{
    public List<KnowledgeEvent> Events { get; set; } = [];
}

[JsonConverter(typeof(JsonStringEnumConverter<MasteryLevel>))]
public enum MasteryLevel
{
    NotEnoughEvidence,
    Learning,
    Familiar,
    Understood,
}

public sealed class MasteryEntry
{
    public string Name { get; set; } = "";
    public int Observations { get; set; }
    public int Successes { get; set; }
    public double Rate { get; set; }
    public MasteryLevel Level { get; set; }
}

public sealed class LearningLibrary
{
    public List<Quiz> Quizzes { get; set; } = [];
    public List<LearningPath> Paths { get; set; } = [];
    public List<FlashcardDeck> Decks { get; set; } = [];
    public List<Faq> Faqs { get; set; } = [];
}
