using System.Text.Json.Serialization;

namespace DocGen.Explorer.Engine.Models;

[JsonConverter(typeof(JsonStringEnumConverter<RepositoryStatus>))]
public enum RepositoryStatus
{
    NotIndexed,
    Indexing,
    Indexed,
    Failed,
}

/// <summary>A repository registered with the explorer. Nothing is ever written back into <see cref="Path"/>.</summary>
public sealed class RepositoryRecord
{
    public string Id { get; set; } = "";
    public string Name { get; set; } = "";

    /// <summary>Optional name chosen by the user; <see cref="Name"/> is the folder name.</summary>
    public string? DisplayName { get; set; }

    /// <summary>Absolute repository root.</summary>
    public string Path { get; set; } = "";

    /// <summary>local | git</summary>
    public string Source { get; set; } = "local";

    public string? GitUrl { get; set; }

    /// <summary>The branch checked out in the clone (Git repositories only).</summary>
    public string? Branch { get; set; }

    /// <summary>The .sln/.csproj/.vbp the user pointed at, when they did not give a folder.</summary>
    public string? EntryFile { get; set; }

    public RepositoryStatus Status { get; set; } = RepositoryStatus.NotIndexed;
    public string? Error { get; set; }
    public DateTime AddedAt { get; set; } = DateTime.UtcNow;
    public DateTime? LastIndexedAt { get; set; }
    public IndexCounters Counters { get; set; } = new();
    public List<string> ConfluenceSpaces { get; set; } = [];

    [JsonIgnore]
    public string Title => string.IsNullOrWhiteSpace(DisplayName) ? Name : DisplayName!;
}

/// <summary>The totals the rest of the explorer answers from.</summary>
public sealed class IndexCounters
{
    public int Files { get; set; }
    public int DocumentationFiles { get; set; }
    public int SourceFiles { get; set; }
    public int Chunks { get; set; }
    public int Embeddings { get; set; }
    public int GraphNodes { get; set; }
    public int GraphEdges { get; set; }
    public int OkfEntities { get; set; }
    public int Symbols { get; set; }
}

public sealed class RepositoryRegistryDocument
{
    public List<RepositoryRecord> Repositories { get; set; } = [];
}

/// <summary>Repository list filter chips.</summary>
public enum RepositoryFilter
{
    All,
    Indexed,
    Indexing,
    Failed,
}

public enum RepositorySort
{
    LastIndexed,
    Name,
    Files,
    Added,
}
