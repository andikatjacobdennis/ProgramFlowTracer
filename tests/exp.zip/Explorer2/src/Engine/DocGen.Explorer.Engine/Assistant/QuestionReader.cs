using System.Text;
using System.Text.Json;
using DocGen.Explorer.Engine.Graph;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Search;

namespace DocGen.Explorer.Engine.Assistant;

/// <summary>A question back to the person, when the request itself is unclear, with the choices that would settle it.</summary>
public sealed record Clarification(string Question, IReadOnlyList<string> Options);

/// <summary>
/// What a question asks for, read before anything is searched: the kind of question, the parts of the code it is about
/// (as the code names them), what the answer must contain — or, when the request is unclear, a question back.
/// </summary>
/// <param name="Intent">One of <see cref="QuestionReader.Intents"/>.</param>
/// <param name="Targets">Names in the code the question is about (features, folders, namespaces, types, members).</param>
/// <param name="Requirements">What the answer must contain or look like, in the person's terms; empty when nothing is asked for.</param>
/// <param name="Summary">The request in one plain sentence.</param>
/// <param name="By">Who read it: the model's name.</param>
public sealed record QuestionUnderstanding(string Intent, IReadOnlyList<string> Targets, string Requirements, string Summary, Clarification? Clarify, string By);

/// <summary>
/// Reads a question with the chat model before the search, for any repository: the candidates it is given are the
/// features, folders, namespaces and types whose names the question's words match, so the model picks what the
/// question means from what exists, and asks when the words fit several things and the choice changes the answer.
/// </summary>
public static class QuestionReader
{
    /// <summary>The kinds of question the search knows (see <see cref="QuestionAnalysis.Intent"/>).</summary>
    public static readonly IReadOnlyList<string> Intents = ["flow", "relationship", "location", "overview", "diagram", "configuration", "howto", "testing", "general"];

    public const string SystemPrompt = """
        You read a developer's question about a code repository before anything is searched, to work out what they want.
        Reply with JSON only:
        {"intent": "flow", "targets": ["OrderService_2_0"], "requirements": "a table with Project, Class, Method and Description",
         "summary": "the program flow of OrderService 2.0 from its handler to the response, across projects",
         "clarify": null}
        - intent: flow (how something runs, a call chain, request to response), relationship (what uses or depends on what),
          location (where something is), overview (architecture, structure), diagram, configuration, howto (build, run, use),
          testing, or general.
        - targets: the parts of the code the question is about, written exactly as one of the candidates (a feature, folder,
          namespace, project or type). Empty when it names no part. Words that only describe the answer (table columns
          such as Project, Class, Method, Description; "steps", "diagram") are requirements, never targets.
        - requirements: what the answer must contain or look like (columns, format, diagram kind, level of detail), in the
          developer's terms; "" when nothing is asked for.
        - summary: the request in one plain sentence, with the targets named as in the code.
        - clarify: null when you can tell what is wanted. Otherwise {"question": "one short question", "options": ["…", "…"]}
          with 2 to 5 short options, each a complete answer to it (often candidate names, plus "All of them" or "Compare
          them" when that makes sense). Ask only when the answer would really differ and the question does not say which:
          the words fit several different things (two versions of a feature and no version named, two unrelated features
          with similar names), or they fit nothing in the candidates and name no code, or the request contradicts itself.
          Do not ask about details you can reasonably assume (format, depth); assume them and put the assumption in the
          summary. A version the developer names ("version 1.0", "v2", "1.0") settles which version.
        """;

    /// <summary>The prompt: the question, the earlier question when this one follows it, and what its words match in the repository.</summary>
    public static string Prompt(string question, string? earlier, IReadOnlyList<GraphScopeSuggestion> candidates, IReadOnlyList<string> projects)
    {
        var sb = new StringBuilder();
        if (earlier is { Length: > 0 })
        {
            sb.AppendLine($"Earlier question in this conversation (use it only when this question continues it): {earlier.Trim()}");
        }
        sb.AppendLine($"Question: {question.Trim()}");
        sb.AppendLine().AppendLine(candidates.Count > 0
            ? "Candidates in this repository that the words match (name · kind · concepts):"
            : "Nothing in this repository matches the question's words by name.");
        foreach (var c in candidates)
        {
            sb.AppendLine($"- {c.Text} · {c.Kind} · {c.Count}");
        }
        if (projects.Count > 0)
        {
            sb.AppendLine().AppendLine("Projects: " + string.Join(", ", projects.Take(80)));
        }
        return sb.ToString();
    }

    /// <summary>
    /// The model's reading. Targets that name nothing in the code are dropped (the model must not invent names); null when
    /// the reply is not the JSON asked for.
    /// </summary>
    public static QuestionUnderstanding? Parse(string text, Func<string, bool> exists, string by)
    {
        var start = text.IndexOf('{');
        var end = text.LastIndexOf('}');
        if (start < 0 || end <= start)
        {
            return null;
        }
        Answer? answer;
        try
        {
            answer = JsonSerializer.Deserialize<Answer>(text[start..(end + 1)], new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }
        catch (JsonException)
        {
            return null;
        }
        if (answer is null)
        {
            return null;
        }
        var intent = Intents.FirstOrDefault(i => i.Equals(answer.Intent?.Trim(), StringComparison.OrdinalIgnoreCase)) ?? "general";
        var targets = (answer.Targets ?? []).Select(t => t.Trim().Trim('`')).Where(t => t.Length >= 2 && exists(t))
            .Distinct(StringComparer.OrdinalIgnoreCase).Take(6).ToList();
        Clarification? clarify = null;
        if (answer.Clarify is { Question: { Length: > 0 } q })
        {
            var options = (answer.Clarify.Options ?? []).Select(o => o.Trim()).Where(o => o.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).Take(5).ToList();
            clarify = new Clarification(q.Trim(), options);
        }
        return new QuestionUnderstanding(intent, targets, answer.Requirements?.Trim() ?? "", answer.Summary?.Trim() ?? "", clarify, by);
    }

    /// <summary>The question back, as the assistant's message.</summary>
    public static string ClarificationText(Clarification clarify)
        => clarify.Options.Count == 0
            ? clarify.Question
            : clarify.Question + "\n\n" + string.Join("\n", clarify.Options.Select(o => $"- {o}")) + "\n\nChoose one, or say it in your own words.";

    /// <summary>The request to answer after a question back: the original question with the person's reply to it.</summary>
    public static string Combine(string original, Clarification? asked, string reply)
        => asked is null ? $"{original.Trim()}\n\n{reply.Trim()}" : $"{original.Trim()}\n\n({asked.Question.Trim()} {reply.Trim()})";

    /// <summary>The step that says how the question was read.</summary>
    public static string Describe(QuestionUnderstanding understood)
    {
        var sb = new StringBuilder($"Understood (read by {understood.By}): ");
        sb.Append(understood.Summary.Length > 0 ? understood.Summary.TrimEnd('.') : $"a {understood.Intent} question");
        if (understood.Targets.Count > 0 && understood.Summary.Length == 0)
        {
            sb.Append(" about ").Append(string.Join(", ", understood.Targets));
        }
        sb.Append('.');
        if (understood.Requirements.Length > 0)
        {
            sb.Append(" The answer must have: ").Append(understood.Requirements.TrimEnd('.')).Append('.');
        }
        return sb.ToString();
    }

    /// <summary>The asked-for answer, as a rule in the answering prompt.</summary>
    public static string PromptRule(QuestionUnderstanding understood)
    {
        var sb = new StringBuilder("- The question was read before searching as: ");
        sb.Append(understood.Summary.Length > 0 ? understood.Summary.TrimEnd('.') : understood.Intent + " question").Append('.');
        if (understood.Targets.Count > 0)
        {
            sb.Append(" It is about ").Append(string.Join(", ", understood.Targets)).Append('.');
        }
        if (understood.Requirements.Length > 0)
        {
            sb.Append(" The answer must have: ").Append(understood.Requirements.TrimEnd('.')).Append(" — give exactly that.");
        }
        return sb.ToString();
    }

    private sealed class Answer
    {
        public string? Intent { get; set; }
        public List<string>? Targets { get; set; }
        public string? Requirements { get; set; }
        public string? Summary { get; set; }
        public AnswerClarify? Clarify { get; set; }
    }

    private sealed class AnswerClarify
    {
        public string? Question { get; set; }
        public List<string>? Options { get; set; }
    }
}
