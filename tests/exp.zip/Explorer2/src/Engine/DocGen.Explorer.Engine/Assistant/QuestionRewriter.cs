using System.Text;
using System.Text.RegularExpressions;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Search;
using DocGen.Explorer.Engine.Text;

namespace DocGen.Explorer.Engine.Assistant;

/// <summary>A question rewritten for the assistant, and what was changed.</summary>
public sealed record RewriteResult(string Text, string By, IReadOnlyList<string> Changes);

/// <summary>
/// Tidies a question before it is asked, without a model: misspelt words are corrected against the repository's own
/// vocabulary ("respoonse" → "response"), names written as words are given as the code spells them ("order
/// service" → `OrderService`), and the text is made one clean request. The model rewrite (see
/// <see cref="AssistantService.RewriteAsync"/>) starts from this.
/// </summary>
public static partial class QuestionRewriter
{
    public static RewriteResult Offline(RepositoryIndex index, string question)
    {
        var changes = new List<string>();
        var text = WhitespaceRegex().Replace(question.Trim(), " ");

        // 1. Spelling, against words that occur in the repository.
        text = WordRegex().Replace(text, m =>
        {
            var word = m.Value;
            var lower = word.ToLowerInvariant();
            // Words search leaves out ("class", "return") are not in the vocabulary, but they are not misspelt either.
            if (word.Length < 5 || word.Any(char.IsDigit) || index.Keywords.DocumentFrequency(lower) > 0 || CommonWords.Contains(lower) || TextUtil.IsStopWord(lower))
            {
                return word;
            }
            var fix = Correct(index, lower);
            if (fix is null)
            {
                return word;
            }
            changes.Add($"{word} → {fix}");
            return char.IsUpper(word[0]) ? char.ToUpperInvariant(fix[0]) + fix[1..] : fix;
        });

        // 2. Names written as words, given as the code spells them.
        if (index.Code is { } code)
        {
            var words = WordRegex().Matches(text).Select(m => m.Value).ToList();
            for (var n = 4; n >= 2; n--)
            {
                for (var i = 0; i + n <= words.Count; i++)
                {
                    var phrase = words.Skip(i).Take(n).ToList();
                    if (phrase.Any(w => w.Length < 3 || CommonWords.Contains(w.ToLowerInvariant())))
                    {
                        continue;
                    }
                    var pascal = string.Concat(phrase.Select(w => char.ToUpperInvariant(w[0]) + w[1..].ToLowerInvariant()));
                    var named = code.Types.Select(t => t.FullName.Split('.').FirstOrDefault(s => s.StartsWith(pascal, StringComparison.OrdinalIgnoreCase)))
                        .FirstOrDefault(s => s is not null);
                    if (named is null)
                    {
                        continue;
                    }
                    var identifier = named.Length > pascal.Length && named[pascal.Length] == '_' ? named[..pascal.Length] : named.Length == pascal.Length ? named : null;
                    if (identifier is null)
                    {
                        continue;
                    }
                    var pattern = string.Join(@"[\s_-]+", phrase.Select(Regex.Escape));
                    var replaced = Regex.Replace(text, $@"(?<![`\w]){pattern}(?![`\w])", $"`{identifier}`", RegexOptions.IgnoreCase);
                    if (replaced != text)
                    {
                        changes.Add($"{string.Join(' ', phrase)} → {identifier}");
                        text = replaced;
                        words = WordRegex().Matches(text).Select(m => m.Value).ToList();
                    }
                }
            }
        }

        // 3. One clean request: capitalised, ending in punctuation.
        if (text.Length > 0 && char.IsLower(text[0]))
        {
            text = char.ToUpperInvariant(text[0]) + text[1..];
        }
        if (text.Length > 0 && !".?!:)`".Contains(text[^1]))
        {
            text += IsQuestion(text) ? "?" : ".";
        }
        return new RewriteResult(text, "offline", changes);
    }

    private static bool IsQuestion(string text)
    {
        var first = text.Split(' ', 2)[0].ToLowerInvariant();
        return first is "what" or "how" or "why" or "where" or "which" or "who" or "when" or "does" or "do" or "is" or "are" or "can" or "should" or "could";
    }

    /// <summary>The repository word closest to a misspelt one (one edit for short words, two for long), most used first.</summary>
    private static string? Correct(RepositoryIndex index, string word)
    {
        var limit = word.Length >= 8 ? 2 : 1;
        string? best = null;
        var bestDistance = int.MaxValue;
        var bestFrequency = 0;
        foreach (var term in index.Keywords.Terms)
        {
            if (Math.Abs(term.Length - word.Length) > limit || term.Length < 4 || term[0] != word[0])
            {
                continue;
            }
            var distance = TextUtil.EditDistance(word, term, limit);
            if (distance > limit)
            {
                continue;
            }
            var frequency = index.Keywords.DocumentFrequency(term);
            if (frequency < 3)
            {
                continue; // a word the repository barely uses is more likely a typo of its own
            }
            if (distance < bestDistance || (distance == bestDistance && frequency > bestFrequency))
            {
                (best, bestDistance, bestFrequency) = (term, distance, frequency);
            }
        }
        return best;
    }

    /// <summary>The instructions for a model rewrite.</summary>
    public static string ModelPrompt(RepositoryIndex index, RewriteResult offline)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"You improve questions that a developer asks a code assistant about the repository \"{index.Repository.Title}\".");
        sb.AppendLine("Rewrite the question so it is clear, specific and complete: keep the developer's intent and every requirement (columns, format, scope),");
        sb.AppendLine("fix spelling and grammar, use the code's exact names (given below where known), and say what output is wanted when the question implies it");
        sb.AppendLine("(a table, a list of steps, a diagram, code). Do not answer it, do not add requirements the developer did not ask for, do not invent names.");
        sb.AppendLine("Reply with the rewritten question only — no preamble, no quotes.");
        if (offline.Changes.Count > 0)
        {
            sb.AppendLine().AppendLine("Corrections already found in the repository's vocabulary: " + string.Join("; ", offline.Changes) + ".");
        }
        if (index.Code is { } code)
        {
            var seeds = FlowTracer.SeedsFromPhrase(code, offline.Text, 5);
            if (seeds.Count > 0)
            {
                sb.AppendLine("Types the question appears to be about: " + string.Join(", ", seeds.Select(s => s.FullName)) + ".");
            }
        }
        return sb.ToString();
    }

    /// <summary>Words a repository may lack but that are spelt correctly.</summary>
    private static readonly HashSet<string> CommonWords = new(StringComparer.Ordinal)
    {
        "about", "above", "after", "again", "against", "below", "between", "column", "columns", "comprehensive", "describe", "description",
        "detail", "details", "diagram", "different", "does", "explain", "following", "format", "please", "program", "should", "summary",
        "table", "their", "there", "these", "those", "through", "under", "until", "where", "which", "while", "would", "write", "flows",
    };

    [GeneratedRegex(@"[A-Za-z][A-Za-z0-9]*")]
    private static partial Regex WordRegex();

    [GeneratedRegex(@"\s+")]
    private static partial Regex WhitespaceRegex();
}
