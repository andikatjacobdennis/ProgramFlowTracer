using System.Text;

namespace DocGen.Explorer.Engine.Assistant;

/// <summary>Something the assistant is doing (a step) or a reasoning model's thinking (streamed text).</summary>
/// <param name="Stage">For a step that begins a stage the app can show (the progress animation): which one. Null for other steps.</param>
/// <param name="Files">For the Finding stage: the files the evidence came from (names only), so the animation lights real files.</param>
public sealed record ThinkingUpdate(ThinkingKind Kind, string Text, ProgressStage? Stage = null, IReadOnlyList<string>? Files = null);

/// <summary>
/// The stages of an answer that the assistant actually goes through and reports — nothing is estimated or simulated.
/// Connecting only happens when the architecture trace runs.
/// </summary>
public enum ProgressStage
{
    /// <summary>Reading the question (and choosing a skill).</summary>
    Understanding,

    /// <summary>Evidence gathered from the index (with the files it came from).</summary>
    Finding,

    /// <summary>Following how the pieces connect (the architecture trace).</summary>
    Connecting,

    /// <summary>Writing the answer: the model is asked, or the answer is composed from the evidence.</summary>
    Writing,

    /// <summary>The answer is complete.</summary>
    Ready,

    // Test Fix's stages, in order.

    /// <summary>Test Fix: working out the language, test framework, runner and configurations.</summary>
    Inspecting,

    /// <summary>Test Fix: running the failing tests to see them fail.</summary>
    Reproducing,

    /// <summary>Test Fix: tracing the failure to its root cause.</summary>
    Analysing,

    /// <summary>Test Fix: preparing a patch and checking it against the rules.</summary>
    Patching,

    /// <summary>Test Fix: writing the patch to the files.</summary>
    Applying,

    /// <summary>Test Fix: rerunning the failing tests, related tests and build checks.</summary>
    Verifying,
}

public enum ThinkingKind
{
    /// <summary>A step of the answer: understanding the question, finding evidence, calling the model…</summary>
    Step,

    /// <summary>A piece of the model's own reasoning, as it streams.</summary>
    Reasoning,
}

/// <summary>
/// Separates <c>&lt;think&gt;…&lt;/think&gt;</c> blocks (how local reasoning models stream their
/// thinking) from the answer, across arbitrary chunk boundaries.
/// </summary>
public sealed class ThinkTagSplitter
{
    private const string Open = "<think>";
    private const string Close = "</think>";
    private readonly StringBuilder _pending = new();
    private bool _inThink;

    public (string Answer, string Thinking) Feed(string chunk)
    {
        _pending.Append(chunk);
        var answer = new StringBuilder();
        var thinking = new StringBuilder();
        while (_pending.Length > 0)
        {
            var text = _pending.ToString();
            var tag = _inThink ? Close : Open;
            var at = text.IndexOf(tag, StringComparison.OrdinalIgnoreCase);
            if (at >= 0)
            {
                (_inThink ? thinking : answer).Append(text, 0, at);
                _pending.Remove(0, at + tag.Length);
                _inThink = !_inThink;
                continue;
            }
            // Hold back a possible partial tag at the end ("<thi").
            var keep = PartialTagLength(text, tag);
            (_inThink ? thinking : answer).Append(text, 0, text.Length - keep);
            _pending.Remove(0, text.Length - keep);
            break;
        }
        return (answer.ToString(), thinking.ToString());
    }

    /// <summary>Whatever is still held back, at the end of the stream.</summary>
    public (string Answer, string Thinking) Flush()
    {
        var rest = _pending.ToString();
        _pending.Clear();
        return _inThink ? ("", rest) : (rest, "");
    }

    private static int PartialTagLength(string text, string tag)
    {
        for (var length = Math.Min(tag.Length - 1, text.Length); length > 0; length--)
        {
            if (text.EndsWith(tag[..length], StringComparison.OrdinalIgnoreCase))
            {
                return length;
            }
        }
        return 0;
    }
}
