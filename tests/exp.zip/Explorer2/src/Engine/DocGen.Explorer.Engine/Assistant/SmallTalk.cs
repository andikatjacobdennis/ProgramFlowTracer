using System.Globalization;
using System.Text.RegularExpressions;

namespace DocGen.Explorer.Engine.Assistant;

/// <summary>
/// Where the assistant is when it is spoken to: the repository (and branch), whether it is indexed, the model in use, and
/// the local time on this PC (the app runs on the person's own machine, so its clock and time zone are theirs).
/// </summary>
public sealed record ChatContext(
    string RepositoryTitle,
    string? Branch,
    bool Indexed,
    int Files,
    string? ModelName,
    DateTime LocalNow,
    string TimeZone,
    IReadOnlyList<string> Suggestions);

/// <summary>
/// Messages that are conversation rather than questions about the repository — greetings, thanks, "ok", "who are you",
/// "what can you do", "what time is it", "test" — get a short, direct reply, aware of the time and of where the assistant
/// is. Searching the repository (and asking a model) for "hi" only produces an answer to a question nobody asked. Anything
/// with a real question in it is left alone (null).
/// </summary>
public static partial class SmallTalk
{
    public static string? Reply(string message, ChatContext c)
    {
        var text = Spaces().Replace(Strip().Replace(message.ToLowerInvariant(), " "), " ").Trim();
        if (text.Length == 0)
        {
            return null;
        }
        var words = text.Split(' ').Length;
        var repo = c.RepositoryTitle;
        var part = PartOfDay(c.LocalNow);
        var time = c.LocalNow.ToString("h:mm tt", CultureInfo.InvariantCulture).ToLowerInvariant();

        // Questions about the assistant itself, or about the time: answered from what it knows, not from the repository.
        if (words <= 8 && WhoAreYou().IsMatch(text))
        {
            return About(c);
        }
        if (words <= 8 && WhatTime().IsMatch(text))
        {
            return $"It is {time} on {c.LocalNow.ToString("dddd, d MMMM yyyy", CultureInfo.InvariantCulture)} here ({c.TimeZone}).";
        }
        if (words > 6)
        {
            return null;
        }
        if (GoodNight().IsMatch(text))
        {
            return $"Good night! Rest well. We can carry on with {repo} whenever you are ready.";
        }
        if (GoodPartOfDay().Match(text) is { Success: true } said)
        {
            var greeting = said.Groups["part"].Value;
            // Mirror their greeting; if the clock here disagrees, say so lightly rather than pretend.
            return greeting == part
                ? $"Good {part}! {(part == "morning" ? "☀️ " : "")}What would you like to explore in {repo}{(part == "morning" ? " today" : "")}?"
                : $"Good {greeting}! It is {time} here, so a good {part} to you too 🙂 What would you like to look at in {repo}?";
        }
        if (Thanks().IsMatch(text))
        {
            return $"You are welcome! Ask me anything else about {repo} whenever you like.";
        }
        if (HowAreYou().IsMatch(text))
        {
            return $"Doing well, thank you for asking! Ready to dig into {repo}. What shall we look at?";
        }
        if (Bye().IsMatch(text))
        {
            return part == "night" ? "Bye for now, and good night! Come back any time." : $"Bye for now! Enjoy your {part}. Come back any time to keep exploring {repo}.";
        }
        if (Hello().IsMatch(text))
        {
            var hello = part == "night" ? "Hi! 🌙 Working late?" : $"Hi, good {part}! 👋";
            return $"{hello} What would you like to know about {repo}?{NotIndexed(c)}{Example(c)}";
        }
        if (Acknowledge().IsMatch(text))
        {
            return $"Great! Ask whenever you are ready.{Example(c)}";
        }
        if (Testing().IsMatch(text))
        {
            return $"I am here and working. Ask me anything about {repo}.{Example(c)}";
        }
        return null;
    }

    /// <summary>
    /// Whether a message the patterns above did not recognise could still be conversation, worth a few tokens of the model's
    /// judgement before the repository is searched: short, and naming nothing that looks like code (no identifiers, paths,
    /// calls or code marks). Anything longer or code-like is taken as a question straight away.
    /// </summary>
    public static bool MayBeChat(string message)
    {
        var text = message.Trim();
        if (text.Length == 0 || text.Length > 120 || CodeMarks().IsMatch(text) || CodeWord().IsMatch(text) || CodeVocabulary().IsMatch(text))
        {
            return false;
        }
        return Spaces().Split(text).Length <= 12;
    }

    /// <summary>The intent check: a tiny prompt whose answer is one word, so it costs a few dozen tokens.</summary>
    public const string IntentPrompt = """
        Classify the user's message to a code-repository assistant. Reply with exactly one word:
        CHAT - greetings, thanks, small talk, feelings, jokes, chit-chat, or remarks that need no information from the repository.
        CODE - anything asking about the repository, its code, files, design, behaviour, documentation, or how to do something with it.
        If unsure, reply CODE.
        """;

    /// <summary>Whether the intent check's answer says the message is conversation.</summary>
    public static bool IsChatVerdict(string answer)
    {
        var word = Strip().Replace(answer, " ").Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault() ?? "";
        return word.Equals("chat", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>The prompt for a short conversational reply: who and where the assistant is, and nothing from the repository.</summary>
    public static string ReplyPrompt(ChatContext c, string? persona)
    {
        var where = c.RepositoryTitle + (c.Branch is { Length: > 0 } b ? $" (branch {b})" : "");
        var time = c.LocalNow.ToString("dddd d MMMM yyyy, h:mm tt", CultureInfo.InvariantCulture);
        var indexed = c.Indexed ? $" ({c.Files:N0} files indexed)" : " (not indexed yet)";
        var example = c.Suggestions.Count > 0 ? $", for example: “{c.Suggestions[0]}”" : "";
        return $"You are the repository assistant of DocGen Explorer for {where}{indexed}.\n" +
               $"It is {time} ({c.TimeZone}) on the user's PC.{(persona is { Length: > 0 } ? " " + persona : "")}\n" +
               "The user is making conversation, not asking about the code. Reply warmly and naturally in one to three short sentences.\n" +
               $"Make no claims about the repository's content. If it fits, invite a question{example}.";
    }

    /// <summary>What is said when the model cannot reply to conversation.</summary>
    public static string Fallback(ChatContext c) => $"I am here. What would you like to know about {c.RepositoryTitle}?{Example(c)}";

    /// <summary>Who the assistant is and what it can do, here and now.</summary>
    private static string About(ChatContext c)
    {
        var where = c.RepositoryTitle + (c.Branch is { Length: > 0 } b ? $" (branch {b})" : "");
        var index = c.Indexed ? $"{c.Files:N0} files are indexed" : "it is not indexed yet";
        var model = c.ModelName is { Length: > 0 } m ? $"I write answers with {m}" : "no chat model is set up, so I answer in evidence mode (straight from the index)";
        return $"I am the repository assistant for {where}: {index}, and {model}. I answer questions about this repository from its own files and cite them, " +
               $"so you can check every claim. I can explain how things work, where something is, how parts connect, and draw diagrams.{NotIndexed(c)}{Example(c)}";
    }

    private static string NotIndexed(ChatContext c)
        => c.Indexed ? "" : $" ({c.RepositoryTitle} is not indexed yet: open Indexing and choose Full reindex so I can read it.)";

    private static string Example(ChatContext c)
        => c.Indexed && c.Suggestions.Count > 0 ? $" For example: “{c.Suggestions[0]}”" : "";

    /// <summary>morning 5–12, afternoon 12–17, evening 17–22, night otherwise.</summary>
    public static string PartOfDay(DateTime local) => local.Hour switch
    {
        >= 5 and < 12 => "morning",
        >= 12 and < 17 => "afternoon",
        >= 17 and < 22 => "evening",
        _ => "night",
    };

    // Code in a message: a path, a call, a member access, generics, code marks, a file extension.
    [GeneratedRegex(@"[`{}()<>\\/=;#\[\]]|\w\.\w|\.(cs|js|ts|py|json|xml|md|csproj|sln|yml|yaml|sql|config)\b|::|->|=>", RegexOptions.IgnoreCase)]
    private static partial Regex CodeMarks();

    // An identifier-shaped word: camelCase or PascalCase with an inner capital, or snake_case.
    [GeneratedRegex(@"\b\w*[a-z][A-Z]\w*\b|\b\w+_\w+\b")]
    private static partial Regex CodeWord();

    // Words of a request about code: what it is made of, and what one asks to be done with it.
    [GeneratedRegex(@"\b(class(es)?|methods?|functions?|files?|folders?|projects?|solution|code|codebase|repo(sitory)?|modules?|namespaces?|interfaces?|types?|members?|propert(y|ies)|fields?|enums?|api|endpoints?|database|tables?|queries|query|bugs?|errors?|exceptions?|crash(es)?|logs?|tests?|build|deploy|packages?|dependenc(y|ies)|commits?|branch(es)?|docs?|documentation|readme|explain|describe|summari[sz]e|list|show|find|tabulate|draw|compare|trace|refactor|implement|fix|debug|generate)\b", RegexOptions.IgnoreCase)]
    private static partial Regex CodeVocabulary();

    // Punctuation and emoji out; letters, digits, apostrophes and spaces kept.
    [GeneratedRegex(@"[^\p{L}\p{N}' ]+")]
    private static partial Regex Strip();

    [GeneratedRegex(@"\s+")]
    private static partial Regex Spaces();

    [GeneratedRegex(@"^(?:(?:hi|hello|hey|ok|okay)\s+)?(?:good\s*night|gn|nighty night|sleep well)(?:\s+\w+)?$")]
    private static partial Regex GoodNight();

    [GeneratedRegex(@"^(?:(?:hi|hello|hey)\s+)?(?:a\s+)?good\s*(?<part>morning|afternoon|evening)(?:\s+(?:to\s+you|everyone|all|\w+))?$|^(?<part>morning|evening)$")]
    private static partial Regex GoodPartOfDay();

    [GeneratedRegex(@"^(?:ok(?:ay)?\s+)?(?:thanks?|thank\s+you|thank\s+you\s+so\s+much|thanks\s+a\s+lot|many\s+thanks|thx|ty|cheers)(?:\s+\w+)?$")]
    private static partial Regex Thanks();

    [GeneratedRegex(@"^(?:(?:hi|hello|hey)\s+)?(?:how\s+are\s+(?:you|u)|how's\s+it\s+going|how\s+is\s+it\s+going|how\s+are\s+you\s+doing|how\s+do\s+you\s+do)(?:\s+today)?$")]
    private static partial Regex HowAreYou();

    [GeneratedRegex(@"^(?:bye|goodbye|good\s+bye|see\s+you|see\s+ya|see\s+you\s+later|cya|ttyl)(?:\s+\w+)?$")]
    private static partial Regex Bye();

    [GeneratedRegex(@"^(?:hi|hii+|hello|helo|hey|heya|hiya|namaste|yo|hi\s+there|hello\s+there|hey\s+there)(?:\s+\w+)?$")]
    private static partial Regex Hello();

    [GeneratedRegex(@"^(?:ok|okay|k|cool|great|nice|got\s+it|alright|all\s+right|sure|fine|hmm+|ah|i\s+see|awesome|perfect|good|noted)$")]
    private static partial Regex Acknowledge();

    [GeneratedRegex(@"^(?:test|testing|test\s+test|are\s+you\s+there|anyone\s+there|you\s+there)$")]
    private static partial Regex Testing();

    [GeneratedRegex(@"^(?:who\s+are\s+you|what\s+are\s+you|what\s+can\s+you\s+do|what\s+do\s+you\s+do|help|help\s+me|how\s+do\s+i\s+use\s+(?:you|this)|introduce\s+yourself|what\s+can\s+i\s+ask(?:\s+you)?)$")]
    private static partial Regex WhoAreYou();

    [GeneratedRegex(@"^(?:what(?:'s|\s+is)\s+the\s+(?:time|date)(?:\s+now)?|what\s+time\s+is\s+it(?:\s+now)?|what\s+day\s+is\s+(?:it|today)|what(?:'s|\s+is)\s+today's\s+date|today's\s+date)$")]
    private static partial Regex WhatTime();
}
