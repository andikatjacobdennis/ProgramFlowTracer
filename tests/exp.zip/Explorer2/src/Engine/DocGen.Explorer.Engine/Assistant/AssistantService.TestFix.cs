using System.Diagnostics;
using System.Text;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Engine.Text;
using DocGen.Explorer.Engine.TestFix;

namespace DocGen.Explorer.Engine.Assistant;

public sealed partial class AssistantService
{
    /// <summary>The Test Fix skill, when it is installed and turned on (it is off until turned on in Settings → Skills).</summary>
    public async Task<Skills.SkillInfo?> TestFixSkillAsync(CancellationToken ct = default)
        => skills is null || testFix is null ? null : (await skills.EnabledAsync(ct)).FirstOrDefault(s => s.Capability == "test-fix");

    /// <summary>
    /// Runs Test Fix in a conversation: the request becomes the person's message and the report the answer. Both are
    /// saved before anything runs, so a run the app does not live to finish still shows, and is reported, in its conversation.
    /// </summary>
    public async Task<(Conversation Conversation, ChatMessage Answer)> TestFixAsync(string repositoryId, string? conversationId, TestFixRequest request,
        Action<ThinkingUpdate>? onThinking, CancellationToken ct = default)
    {
        if (testFix is null || await TestFixSkillAsync(ct) is not { } skill)
        {
            throw new ExplorerValidationException("Turn on the Test Fix skill first: Settings → Skills.");
        }
        var sw = Stopwatch.StartNew();
        var conversation = await GetOrCreateAsync(repositoryId, conversationId, ct);
        var asked = UserText(request);
        if (conversation.Messages.Count == 0)
        {
            conversation.Title = TextUtil.Truncate(asked.ReplaceLineEndings(" "), 80);
        }
        var user = new ChatMessage
        {
            Role = "user", Text = asked, Attachments = request.Attachments.Count > 0 ? request.Attachments.ToList() : null,
            TestFix = new TestFixRequest
            {
                Description = request.Description, TestSelection = request.TestSelection, TestCommand = request.TestCommand, Configuration = request.Configuration,
                ApplyChanges = request.ApplyChanges, RunCommands = request.RunCommands, MaxIterations = request.MaxIterations, TimeoutSeconds = request.TimeoutSeconds,
            },
        };
        var answer = new ChatMessage
        {
            Role = "assistant", Text = "Test Fix is running…", Skill = skill.Id, SkillName = $"{skill.Icon} {skill.Name}", Model = "test-fix",
        };
        conversation.Messages.Add(user);
        conversation.Messages.Add(answer);
        var steps = new List<string> { $"Using the {skill.Icon} {skill.Name} skill (started from the Test Fix button)." };
        onThinking?.Invoke(new ThinkingUpdate(ThinkingKind.Step, steps[0], ProgressStage.Inspecting));
        var instructions = skills is null ? null : await skills.InstructionsAsync(skill, ct);
        var run = await testFix.RunAsync(repositoryId, request, instructions, (stage, text) =>
        {
            steps.Add(text);
            onThinking?.Invoke(new ThinkingUpdate(ThinkingKind.Step, text, Stage(stage)));
        }, ct, async started =>
        {
            started.ConversationId = conversation.Id;
            started.MessageId = answer.Id;
            answer.TestFixRunId = started.Id;
            await SaveAsync(repositoryId, conversation, CancellationToken.None);
        });
        steps.AddRange(run.Completed.Select(c => "✓ " + c));
        answer.Text = run.Report;
        answer.Steps = steps;
        answer.Model = run.Attempts.LastOrDefault()?.Model ?? "test-fix";
        answer.DurationMs = sw.ElapsedMilliseconds;
        answer.Diagnostics = run.Commands.Select(c => $"{c.Purpose}: `{c.CommandLine}` → exit {c.ExitCode?.ToString() ?? "none"}, {c.Outcome}, {c.Executed} executed / {c.Failed} failed.").ToList();
        answer.Failed = run.Status == TestFixStatus.Blocked && run.Commands.Count == 0 && run.Attempts.Count == 0 && run.Project is null;
        onThinking?.Invoke(new ThinkingUpdate(ThinkingKind.Step, $"{TestFixReport.Title(run.Status)} in {sw.ElapsedMilliseconds / 1000.0:0} s.", ProgressStage.Ready));
        await SaveAsync(repositoryId, conversation, CancellationToken.None);
        return (conversation, answer);
    }

    /// <summary>
    /// Runs the app did not live to finish: marked interrupted, and their messages show what was applied and verified
    /// before they stopped. Returns how many were recovered.
    /// </summary>
    public async Task<int> RecoverTestFixAsync(string repositoryId, CancellationToken ct = default)
    {
        if (testFix is null)
        {
            return 0;
        }
        var recovered = await testFix.RecoverAsync(repositoryId, ct);
        foreach (var run in recovered.Where(r => r.ConversationId is not null))
        {
            var conversation = await GetOrCreateAsync(repositoryId, run.ConversationId, ct);
            if (conversation.Messages.FirstOrDefault(m => m.Id == run.MessageId || m.TestFixRunId == run.Id) is { } message)
            {
                message.Text = run.Report;
                await SaveAsync(repositoryId, conversation, ct);
            }
        }
        return recovered.Count;
    }

    /// <summary>
    /// Undoes the changes a Test Fix run made (files changed since are left alone) and updates its message's report.
    /// Returns the files restored, those kept, and the new report.
    /// </summary>
    public async Task<(IReadOnlyList<string> Restored, IReadOnlyList<string> Kept, string Report)> UndoTestFixAsync(string repositoryId, string conversationId, string runId,
        CancellationToken ct = default)
    {
        if (testFix is null)
        {
            throw new ExplorerValidationException("Test Fix is not available.");
        }
        var (restored, kept) = await testFix.UndoAsync(repositoryId, runId, ct);
        var run = await testFix.GetAsync(repositoryId, runId, ct);
        var report = run?.Report ?? "";
        if (restored.Count > 0)
        {
            report += $"\n\n> **Undone:** {string.Join(", ", restored.Select(r => $"`{r}`"))} restored to how they were before this run."
                      + (kept.Count > 0 ? $" Left as they are (changed since): {string.Join(", ", kept.Select(k => $"`{k}`"))}." : "");
        }
        var conversation = await GetOrCreateAsync(repositoryId, conversationId, ct);
        if (conversation.Messages.FirstOrDefault(m => m.TestFixRunId == runId) is { } message)
        {
            message.Text = report;
            await SaveAsync(repositoryId, conversation, ct);
        }
        return (restored, kept, report);
    }

    /// <summary>The person's message for a Test Fix request: what fails and how it is to be run.</summary>
    public static string UserText(TestFixRequest request)
    {
        var sb = new StringBuilder("🧪 Test Fix: ").Append(request.Description.Trim().Length > 0 ? request.Description.Trim() : "fix the failing tests");
        var details = new List<string>();
        if (request.TestSelection is { Length: > 0 } selection)
        {
            details.Add($"tests: `{selection}`");
        }
        if (request.TestCommand is { Length: > 0 } command)
        {
            details.Add($"command: `{command}`");
        }
        if (request.Configuration is { Length: > 0 } configuration)
        {
            details.Add($"configuration: {configuration}");
        }
        if (!request.ApplyChanges)
        {
            details.Add("propose only (no file is changed)");
        }
        if (!request.RunCommands)
        {
            details.Add("nothing is run");
        }
        if (details.Count > 0)
        {
            sb.Append("\n\n").Append(string.Join(" · ", details));
        }
        return sb.ToString();
    }

    private static ProgressStage Stage(TestFixStage stage) => stage switch
    {
        TestFixStage.Inspecting => ProgressStage.Inspecting,
        TestFixStage.Reproducing => ProgressStage.Reproducing,
        TestFixStage.Analysing => ProgressStage.Analysing,
        TestFixStage.Patching => ProgressStage.Patching,
        TestFixStage.Applying => ProgressStage.Applying,
        TestFixStage.Verifying => ProgressStage.Verifying,
        _ => ProgressStage.Writing,
    };
}
