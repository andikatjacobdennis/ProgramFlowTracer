using System.Text;
using DocGen.Explorer.Engine.Documentation;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Markdown;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Search;
using DocGen.Explorer.Engine.Text;
using DocGen.Analysis.Indexing;

namespace DocGen.Explorer.Engine.Assistant;

/// <summary>
/// Evidence mode: writes a grounded answer without a model, from the code index, the knowledge graph and the retrieved
/// chunks. Every statement comes from the index and cites the evidence it rests on ([n]). The same facts are handed to
/// the model as a briefing when one is configured.
/// </summary>
public static class EvidenceComposer
{
    public const string OfflineNote = "_Written offline from the index and the retrieved evidence (evidence mode). Choose a chat model under **Settings → Chat model** for generated prose._";

    public static string NothingFound(QuestionAnalysis analysis, bool indexed)
    {
        var sb = new StringBuilder();
        sb.AppendLine("I could not find anything in the indexed repository that answers this question.").AppendLine();
        sb.AppendLine("Possible reasons:").AppendLine();
        if (!indexed)
        {
            sb.AppendLine("- the repository has not finished indexing yet");
        }
        if (analysis.UnknownIdentifiers.Count > 0)
        {
            sb.AppendLine($"- {TextUtil.JoinNatural(analysis.UnknownIdentifiers.Select(u => $"`{u}`"))} does not appear in the code index");
        }
        sb.AppendLine("- the question uses vocabulary that does not appear in the repository");
        sb.AppendLine("- the relevant files are excluded by the ingestion filters, or by the current selection");
        return sb.ToString();
    }

    /// <summary>The structured facts about the question's symbols (used offline and as a model briefing).</summary>
    public static string Facts(RepositoryIndex index, QuestionAnalysis analysis, IReadOnlyList<Evidence> evidence)
    {
        var sb = new StringBuilder();
        foreach (var symbol in analysis.Symbols.Take(4))
        {
            AppendSymbol(sb, index, symbol, evidence, brief: true);
        }
        return sb.ToString().Trim();
    }

    /// <summary>
    /// The layered architecture diagram of the repository's C# solution when the question asks for an architecture diagram
    /// of the whole repository (and the repository has C# projects); otherwise null.
    /// </summary>
    public static string? SolutionDiagram(RepositoryIndex index, string question)
        => index.Code is { } code && SolutionArchitectureDiagram.Asks(question, index.Repository.Title)
           && code.Manifest.Projects.Any(p => p.Path.EndsWith(".csproj", StringComparison.OrdinalIgnoreCase))
            ? SolutionArchitectureDiagram.Build(code)
            : null;

    public static string Compose(RepositoryIndex index, RetrievalResult retrieval)
    {
        var analysis = retrieval.Analysis;
        var evidence = retrieval.Evidence;
        // An architecture diagram of a C# solution: its projects in layers, from their project references.
        if (SolutionDiagram(index, analysis.Question) is { } solution)
        {
            return $"The architecture of **{index.Repository.Title}**, project by project, from the solution's project references.\n\n{solution}\n\n{OfflineNote}";
        }
        if (evidence.Count == 0 && analysis.Symbols.Count == 0)
        {
            return NothingFound(analysis, indexed: true) + Environment.NewLine + OfflineNote;
        }
        var sb = new StringBuilder();
        switch (analysis.Intent)
        {
            case "overview" when analysis.Symbols.Count < 2:
                Overview(sb, index, evidence);
                break;
            case "diagram":
                Diagram(sb, index, analysis);
                break;
            case "configuration":
                Configuration(sb, index, evidence);
                break;
            case "testing" when analysis.Symbols.Count == 0:
                Testing(sb, index, evidence);
                break;
        }

        if (analysis.Intent is "relationship" or "overview" && analysis.Symbols.Count >= 2)
        {
            Relationship(sb, index, analysis.Symbols, evidence);
        }
        foreach (var symbol in analysis.Symbols.Where(s => analysis.Intent != "diagram").Take(3))
        {
            AppendSymbol(sb, index, symbol, evidence, brief: false);
        }

        if (sb.Length == 0 || analysis.Symbols.Count == 0 && analysis.Intent is "general" or "howto" or "location" or "relationship")
        {
            Excerpts(sb, index, evidence, analysis.Intent == "howto" ? 6 : 5);
        }
        sb.AppendLine().AppendLine(OfflineNote);
        return sb.ToString().Trim();
    }

    private static int Cite(IReadOnlyList<Evidence> evidence, string path, int line)
    {
        for (var i = 0; i < evidence.Count; i++)
        {
            var c = evidence[i].Chunk;
            if (string.Equals(c.Path, path, StringComparison.OrdinalIgnoreCase) && (line <= 0 || c.StartLine <= line && c.EndLine >= line))
            {
                return i + 1;
            }
        }
        for (var i = 0; i < evidence.Count; i++)
        {
            if (string.Equals(evidence[i].Chunk.Path, path, StringComparison.OrdinalIgnoreCase))
            {
                return i + 1;
            }
        }
        return 0;
    }

    private static string Ref(IReadOnlyList<Evidence> evidence, string path, int line)
    {
        var n = Cite(evidence, path, line);
        return n > 0 ? $" [{n}]" : "";
    }

    private static string Link(string path, int line) => line > 0 ? $"[`{path}:{line}`](repo:{path}#L{line})" : $"[`{path}`](repo:{path})";

    private static void AppendSymbol(StringBuilder sb, RepositoryIndex index, SymbolRecord symbol, IReadOnlyList<Evidence> evidence, bool brief)
    {
        var code = index.Code!;
        var kind = CodeIndexHelpers.KindLabel(symbol.Kind).ToLowerInvariant();
        var modifiers = symbol.Modifiers.Where(m => m is "static" or "abstract" or "sealed" or "partial").ToList();
        var article = modifiers.Count > 0 ? (modifiers[0] is "abstract" ? "an" : "a") : "aeiou".Contains(kind[0]) ? "an" : "a";
        if (!brief)
        {
            sb.AppendLine($"### {symbol.Name}").AppendLine();
        }
        sb.Append($"**{symbol.Name}** is {article} {string.Join(" ", modifiers.Append(kind))}");
        if (symbol.Namespace.Length > 0)
        {
            sb.Append($" in `{symbol.Namespace}`");
        }
        sb.Append($", declared in {Link(symbol.File, symbol.StartLine)}{Ref(evidence, symbol.File, symbol.StartLine)}.");
        var lines = index.ReadLines(symbol.File);
        var summary = lines is null ? null : DocumentationBuilder.XmlDocSummary(lines, symbol.StartLine);
        if (!string.IsNullOrWhiteSpace(summary))
        {
            sb.Append($" Its documentation says: \"{summary}\"");
        }
        sb.AppendLine().AppendLine();

        if (SymbolKinds.IsType(symbol.Kind))
        {
            var members = code.MembersOf(symbol.FullName).Where(m => !SymbolKinds.IsType(m.Kind)).OrderBy(m => m.StartLine).ToList();
            if (members.Count > 0)
            {
                sb.AppendLine($"It has {TextUtil.Plural(members.Count, "member")}:").AppendLine();
                foreach (var member in members.Take(brief ? 8 : 12))
                {
                    var signature = string.IsNullOrWhiteSpace(member.Signature) ? member.Name : member.Signature;
                    var memberSummary = lines is null ? null : DocumentationBuilder.XmlDocSummary(lines, member.StartLine);
                    sb.AppendLine($"- `{TextUtil.Truncate(signature, 100)}` ({member.Kind}, line {member.StartLine}){(memberSummary is { Length: > 0 } ? " — " + memberSummary : "")}{Ref(evidence, member.File, member.StartLine)}");
                }
                if (members.Count > (brief ? 8 : 12))
                {
                    sb.AppendLine($"- … and {members.Count - (brief ? 8 : 12)} more");
                }
                sb.AppendLine();
            }
            if (symbol.Bases.Count > 0)
            {
                sb.AppendLine($"It derives from or implements {TextUtil.JoinNatural(symbol.Bases.Select(b => $"`{b}`"))}.").AppendLine();
            }
            var derived = code.DirectlyDerived(symbol.Name).Where(d => d.FullName != symbol.FullName).Select(d => d.Name).Distinct().ToList();
            if (derived.Count > 0)
            {
                sb.AppendLine($"It is derived from or implemented by {TextUtil.JoinNatural(derived.Take(10).Select(d => $"`{d}`"))}.").AppendLine();
            }
            var nodeId = "type:" + symbol.FullName;
            var uses = index.Graph.Edges.Where(e => e.From == nodeId && e.Kind is EdgeKinds.Uses).Select(e => index.Graph.Find(e.To)?.Label).OfType<string>().Distinct().ToList();
            var usedBy = index.Graph.Edges.Where(e => e.To == nodeId && e.Kind is EdgeKinds.Uses).Select(e => index.Graph.Find(e.From)?.Label).OfType<string>().Distinct().ToList();
            var testedBy = index.Graph.Edges.Where(e => e.To == nodeId && e.Kind is EdgeKinds.Tests).Select(e => index.Graph.Find(e.From)?.Label).OfType<string>().Distinct().ToList();
            var documentedIn = index.Graph.Edges.Where(e => e.To == nodeId && e.Kind is EdgeKinds.Mentions).Select(e => index.Graph.Find(e.From)?.Label).OfType<string>().Distinct().ToList();
            if (uses.Count > 0)
            {
                sb.AppendLine($"It depends on {TextUtil.JoinNatural(uses.Take(12).Select(u => $"`{u}`"))}.").AppendLine();
            }
            if (usedBy.Count > 0)
            {
                sb.AppendLine($"It is used by {TextUtil.JoinNatural(usedBy.Take(12).Select(u => $"`{u}`"))}.").AppendLine();
            }
            if (testedBy.Count > 0)
            {
                sb.AppendLine($"It is tested by {TextUtil.JoinNatural(testedBy.Select(u => $"`{u}`"))}.").AppendLine();
            }
            if (documentedIn.Count > 0)
            {
                sb.AppendLine($"It is mentioned in the documentation page{(documentedIn.Count > 1 ? "s" : "")} {TextUtil.JoinNatural(documentedIn.Select(u => $"*{u}*"))}.").AppendLine();
            }
            if (uses.Count == 0 && usedBy.Count == 0 && testedBy.Count == 0 && !brief)
            {
                sb.AppendLine("Nothing else in the index refers to it, and it refers to no other indexed type.").AppendLine();
            }
        }
        else
        {
            var callers = code.CallersByName(symbol.Name).Where(c => c.FullName != symbol.FullName).Select(c => CodeIndexHelpers.ShortName(c.FullName)).Distinct().Take(12).ToList();
            if (symbol.ReturnType is { Length: > 0 } returns)
            {
                sb.AppendLine($"It returns `{returns}`" + (symbol.ParameterTypes.Count > 0 ? $" and takes {TextUtil.JoinNatural(symbol.ParameterTypes.Select(p => $"`{p}`"))}." : "."));
                sb.AppendLine();
            }
            if (callers.Count > 0)
            {
                sb.AppendLine($"It is called from {TextUtil.JoinNatural(callers.Select(c => $"`{c}`"))}.").AppendLine();
            }
            if (symbol.Calls.Count > 0)
            {
                sb.AppendLine($"It calls {TextUtil.JoinNatural(symbol.Calls.Distinct().Take(12).Select(c => $"`{c}`"))}.").AppendLine();
            }
        }
    }

    private static void Relationship(StringBuilder sb, RepositoryIndex index, List<SymbolRecord> symbols, IReadOnlyList<Evidence> evidence)
    {
        var a = symbols[0];
        foreach (var b in symbols.Skip(1).Take(2))
        {
            var found = false;
            foreach (var (from, to) in new[] { (a, b), (b, a) })
            {
                var lines = index.ReadLines(from.File);
                if (lines is null)
                {
                    continue;
                }
                var start = Math.Max(1, from.StartLine);
                var end = Math.Min(lines.Length, Math.Max(from.EndLine, from.StartLine));
                var hits = new List<(int Line, string Text)>();
                for (var line = start; line <= end; line++)
                {
                    if (ContainsWord(lines[line - 1], to.Name))
                    {
                        hits.Add((line, lines[line - 1].Trim()));
                    }
                }
                if (hits.Count == 0)
                {
                    continue;
                }
                found = true;
                sb.AppendLine($"**{from.Name}** refers to **{to.Name}** {(hits.Count == 1 ? "once" : $"{hits.Count} times")} in {Link(from.File, hits[0].Line)}{Ref(evidence, from.File, hits[0].Line)}:").AppendLine();
                sb.AppendLine("```" + LanguageOf(from.File));
                foreach (var (line, text) in hits.Take(10))
                {
                    sb.AppendLine($"{line,4}: {TextUtil.Truncate(text, 140)}");
                }
                sb.AppendLine("```").AppendLine();
            }
            if (!found)
            {
                var path = PathBetween(index.Graph, "type:" + a.FullName, "type:" + b.FullName);
                sb.AppendLine(path is { Count: > 2 }
                    ? $"**{a.Name}** and **{b.Name}** do not refer to each other directly; the graph connects them through {TextUtil.JoinNatural(path.Skip(1).SkipLast(1).Select(id => $"`{index.Graph.Find(id)?.Label ?? id}`"))}."
                    : $"**{a.Name}** and **{b.Name}** do not refer to each other in the indexed code.").AppendLine();
            }
        }
    }

    private static bool ContainsWord(string line, string word)
    {
        var i = 0;
        while ((i = line.IndexOf(word, i, StringComparison.Ordinal)) >= 0)
        {
            var before = i == 0 || !char.IsLetterOrDigit(line[i - 1]) && line[i - 1] != '_';
            var afterIndex = i + word.Length;
            var after = afterIndex >= line.Length || !char.IsLetterOrDigit(line[afterIndex]) && line[afterIndex] != '_';
            if (before && after)
            {
                return true;
            }
            i += word.Length;
        }
        return false;
    }

    /// <summary>Shortest undirected path between two nodes (breadth-first, bounded).</summary>
    public static List<string>? PathBetween(KnowledgeGraph graph, string from, string to, int maxDepth = 4)
    {
        if (graph.Find(from) is null || graph.Find(to) is null)
        {
            return null;
        }
        var adjacency = new Dictionary<string, List<string>>(StringComparer.Ordinal);
        foreach (var e in graph.Edges.Where(e => e.Kind is not EdgeKinds.Contains))
        {
            (adjacency.TryGetValue(e.From, out var x) ? x : adjacency[e.From] = []).Add(e.To);
            (adjacency.TryGetValue(e.To, out var y) ? y : adjacency[e.To] = []).Add(e.From);
        }
        var previous = new Dictionary<string, string>(StringComparer.Ordinal) { [from] = "" };
        var queue = new Queue<(string Id, int Depth)>();
        queue.Enqueue((from, 0));
        while (queue.Count > 0)
        {
            var (id, depth) = queue.Dequeue();
            if (id == to)
            {
                var path = new List<string>();
                for (var cur = to; cur.Length > 0; cur = previous[cur])
                {
                    path.Add(cur);
                }
                path.Reverse();
                return path;
            }
            if (depth >= maxDepth)
            {
                continue;
            }
            foreach (var next in adjacency.GetValueOrDefault(id) ?? [])
            {
                if (previous.TryAdd(next, id))
                {
                    queue.Enqueue((next, depth + 1));
                }
            }
        }
        return null;
    }

    private static void Overview(StringBuilder sb, RepositoryIndex index, IReadOnlyList<Evidence> evidence)
    {
        var repo = index.Repository;
        var c = repo.Counters;
        sb.AppendLine($"## {repo.Title} at a glance").AppendLine();
        sb.AppendLine($"The repository holds {TextUtil.Plural(c.Files, "indexed file")} — {TextUtil.Plural(c.SourceFiles, "source file")} and {TextUtil.Plural(c.DocumentationFiles, "documentation file")}" +
                      (index.Code is { } code0 ? $", with {TextUtil.Plural(code0.Types.Count(), "type")} in {TextUtil.Plural(code0.Manifest.Projects.Count, "project")}." : "."))
          .AppendLine();

        var readme = evidence.FirstOrDefault(e => e.Chunk.Kind == "doc" && e.Chunk.Path.Contains("README", StringComparison.OrdinalIgnoreCase))
                     ?? evidence.FirstOrDefault(e => e.Chunk.Kind == "doc");
        if (readme is not null)
        {
            var paragraph = FirstParagraph(readme.Chunk.Text);
            if (paragraph.Length > 0)
            {
                sb.AppendLine($"> {TextUtil.Truncate(paragraph, 500)}{Ref(evidence, readme.Chunk.Path, readme.Chunk.StartLine)}").AppendLine();
            }
        }

        if (index.Code is { } code && code.Manifest.Projects.Count > 0)
        {
            sb.AppendLine("### Projects").AppendLine();
            foreach (var project in code.Manifest.Projects)
            {
                var kind = project.IsTestProject ? "test project" : project.OutputType?.ToLowerInvariant() switch
                {
                    "exe" or "winexe" => "application",
                    _ when project.Sdk?.Contains("Web", StringComparison.OrdinalIgnoreCase) == true => "web application",
                    _ => "library",
                };
                var types = code.Types.Count(t => t.Project == project.Name);
                sb.Append($"- **{project.Name}** ({kind}, {TextUtil.Plural(types, "type")})");
                if (project.ProjectReferences.Count > 0)
                {
                    sb.Append($" → depends on {TextUtil.JoinNatural(project.ProjectReferences.Select(r => Path.GetFileNameWithoutExtension(r)!))}");
                }
                sb.AppendLine(Ref(evidence, project.Path, 0));
            }
            sb.AppendLine();

            var degree = index.Graph.Nodes.Where(n => ConceptTypes.IsType(n.Type) && n.Type != ConceptTypes.Test)
                .Select(n => (Node: n, In: index.Graph.Edges.Count(e => e.To == n.Id && e.Kind is EdgeKinds.Uses or EdgeKinds.Inherits or EdgeKinds.Tests)))
                .OrderByDescending(x => x.In).ThenBy(x => x.Node.Label, StringComparer.Ordinal).Take(8).ToList();
            if (degree.Count > 0)
            {
                sb.AppendLine("### Key types").AppendLine();
                sb.AppendLine("The types the rest of the code leans on most:").AppendLine();
                foreach (var (node, incoming) in degree)
                {
                    sb.AppendLine($"- **{node.Label}** ({node.Type.ToLowerInvariant()}) — {(incoming == 0 ? "standalone" : $"referenced by {TextUtil.Plural(incoming, "other type")}")}; {Link(node.Path ?? "", node.Line ?? 0)}{Ref(evidence, node.Path ?? "", node.Line ?? 0)}" +
                                  (node.Description is { Length: > 0 } d && !d.StartsWith("Class in", StringComparison.Ordinal) ? $" — {TextUtil.Truncate(d, 140)}" : ""));
                }
                sb.AppendLine();
            }
        }

        var entry = index.Okf.Where(o => o.Kind == "entrypoint").Take(5).ToList();
        if (entry.Count > 0)
        {
            sb.AppendLine("### Where execution starts").AppendLine();
            foreach (var e in entry)
            {
                sb.AppendLine($"- {e.Name} — {e.Detail}, {Link(e.Path, e.Line)}");
            }
            sb.AppendLine();
        }

        var docs = index.Pages.Where(p => !p.Generated).Take(8).ToList();
        if (docs.Count > 0)
        {
            sb.AppendLine("### Documentation to read").AppendLine();
            foreach (var page in docs)
            {
                sb.AppendLine($"- [{page.Title}](page:{page.Id}) — `{page.SourcePath}`");
            }
            sb.AppendLine();
        }
    }

    private static void Diagram(StringBuilder sb, RepositoryIndex index, QuestionAnalysis analysis)
    {
        var graph = index.Graph;
        var subject = analysis.Symbols.FirstOrDefault(s => SymbolKinds.IsType(s.Kind));
        var lines = new List<string> { "graph LR" };
        string Id(string nodeId) => "n" + TextUtil.ShortHash(nodeId)[..8];
        string Label(GraphNode node) => node.Label.Replace("\"", "'", StringComparison.Ordinal);
        if (subject is not null)
        {
            var root = "type:" + subject.FullName;
            var node = graph.Find(root);
            if (node is null)
            {
                sb.AppendLine($"`{subject.Name}` is not a node in the knowledge graph, so there is nothing to draw.");
                return;
            }
            lines.Add($"  {Id(root)}[\"{Label(node)}\"]");
            var outgoing = graph.Edges.Where(e => e.From == root && e.Kind is not EdgeKinds.Contains).ToList();
            var incoming = graph.Edges.Where(e => e.To == root && e.Kind is EdgeKinds.Uses or EdgeKinds.Inherits or EdgeKinds.Tests).ToList();
            foreach (var e in outgoing)
            {
                if (graph.Find(e.To) is { } target)
                {
                    lines.Add($"  {Id(root)} -->|{e.Kind}| {Id(e.To)}[\"{Label(target)}\"]");
                }
            }
            foreach (var e in incoming)
            {
                if (graph.Find(e.From) is { } source)
                {
                    lines.Add($"  {Id(e.From)}[\"{Label(source)}\"] -->|{e.Kind}| {Id(root)}");
                }
            }
            sb.AppendLine($"What **{subject.Name}** depends on ({outgoing.Count}) and what depends on it ({incoming.Count}), from the knowledge graph:").AppendLine();
        }
        else
        {
            var projects = graph.Nodes.Where(n => n.Type == ConceptTypes.Project).ToList();
            if (projects.Count > 0)
            {
                foreach (var p in projects)
                {
                    lines.Add($"  {Id(p.Id)}[\"{Label(p)}\"]");
                }
                foreach (var e in graph.Edges.Where(e => e.Kind == EdgeKinds.References))
                {
                    lines.Add($"  {Id(e.From)} --> {Id(e.To)}");
                }
                sb.AppendLine("How the projects reference one another:").AppendLine();
            }
            else
            {
                var top = graph.Nodes.Where(n => ConceptTypes.IsType(n.Type)).OrderByDescending(n => graph.Degree(n.Id)).Take(15).Select(n => n.Id).ToHashSet();
                foreach (var e in graph.Edges.Where(e => top.Contains(e.From) && top.Contains(e.To)))
                {
                    lines.Add($"  {Id(e.From)}[\"{Label(graph.Find(e.From)!)}\"] -->|{e.Kind}| {Id(e.To)}[\"{Label(graph.Find(e.To)!)}\"]");
                }
                sb.AppendLine("The most connected types and how they relate:").AppendLine();
            }
        }
        sb.AppendLine("```mermaid");
        foreach (var line in lines.Distinct())
        {
            sb.AppendLine(line);
        }
        sb.AppendLine("```").AppendLine();
    }

    private static void Configuration(StringBuilder sb, RepositoryIndex index, IReadOnlyList<Evidence> evidence)
    {
        var config = index.Okf.Where(o => o.Kind == "config").ToList();
        var files = index.Files.Where(f => f.Kind == FileKind.Config && (f.Name.StartsWith("appsettings", StringComparison.OrdinalIgnoreCase) || f.Name.EndsWith(".config", StringComparison.OrdinalIgnoreCase)
                                                                        || f.Name.EndsWith(".yml", StringComparison.OrdinalIgnoreCase) || f.Name.EndsWith(".yaml", StringComparison.OrdinalIgnoreCase)
                                                                        || f.Name.Equals(".env", StringComparison.OrdinalIgnoreCase) || f.Name.EndsWith(".toml", StringComparison.OrdinalIgnoreCase)
                                                                        || f.Name.EndsWith(".ini", StringComparison.OrdinalIgnoreCase))).ToList();
        if (config.Count == 0 && files.Count == 0)
        {
            sb.AppendLine("The index records no configuration files (appsettings, .config, YAML, TOML, INI or .env) and no code that reads configuration.").AppendLine();
            var projects = index.Files.Where(f => f.Language == "msbuild").ToList();
            if (projects.Count > 0)
            {
                sb.AppendLine($"Build configuration lives in the project file{(projects.Count > 1 ? "s" : "")} {TextUtil.JoinNatural(projects.Select(p => Link(p.Path, 0)))}.").AppendLine();
            }
            return;
        }
        if (files.Count > 0)
        {
            sb.AppendLine("Configuration files:").AppendLine();
            foreach (var file in files.Take(15))
            {
                sb.AppendLine($"- {Link(file.Path, 0)}{Ref(evidence, file.Path, 0)}");
            }
            sb.AppendLine();
        }
        if (config.Count > 0)
        {
            sb.AppendLine("Configuration keys and where they are read:").AppendLine();
            foreach (var entity in config.Take(25))
            {
                sb.AppendLine($"- `{entity.Name}` — {entity.Detail}, {Link(entity.Path, entity.Line)}{Ref(evidence, entity.Path, entity.Line)}");
            }
            if (config.Count > 25)
            {
                sb.AppendLine($"- … and {config.Count - 25} more (see the Operations reference page)");
            }
            sb.AppendLine();
        }
    }

    private static void Testing(StringBuilder sb, RepositoryIndex index, IReadOnlyList<Evidence> evidence)
    {
        var tests = index.Graph.Nodes.Where(n => n.Type == ConceptTypes.Test).ToList();
        if (tests.Count == 0)
        {
            sb.AppendLine("The index records no test classes.").AppendLine();
            return;
        }
        var methods = index.Code?.TestMethods.Count() ?? 0;
        sb.AppendLine($"The repository has {TextUtil.Plural(tests.Count, "test class", "test classes")}{(methods > 0 ? $" with {TextUtil.Plural(methods, "test")}" : "")}:").AppendLine();
        foreach (var test in tests.Take(15))
        {
            var targets = index.Graph.Edges.Where(e => e.From == test.Id && e.Kind == EdgeKinds.Tests).Select(e => index.Graph.Find(e.To)?.Label).OfType<string>().ToList();
            sb.AppendLine($"- **{test.Label}** {Link(test.Path ?? "", test.Line ?? 0)}{Ref(evidence, test.Path ?? "", test.Line ?? 0)}" + (targets.Count > 0 ? $" — exercises {TextUtil.JoinNatural(targets.Select(t => $"`{t}`"))}" : ""));
        }
        sb.AppendLine();
        var testProjects = index.Code?.Manifest.Projects.Where(p => p.IsTestProject).ToList() ?? [];
        if (testProjects.Count > 0)
        {
            sb.AppendLine($"Run them with `dotnet test {testProjects[0].Path}`" + (testProjects.Count > 1 ? $" (and {testProjects.Count - 1} more test project{(testProjects.Count > 2 ? "s" : "")})." : ".")).AppendLine();
        }
    }

    private static void Excerpts(StringBuilder sb, RepositoryIndex index, IReadOnlyList<Evidence> evidence, int max)
    {
        if (evidence.Count == 0)
        {
            return;
        }
        sb.AppendLine("The most relevant passages in the repository:").AppendLine();
        for (var i = 0; i < Math.Min(max, evidence.Count); i++)
        {
            var chunk = evidence[i].Chunk;
            sb.AppendLine($"**{i + 1}. {chunk.Title}** — {Link(chunk.Path, chunk.StartLine)} (lines {chunk.StartLine}–{chunk.EndLine}) [{i + 1}]").AppendLine();
            if (chunk.Kind == "doc")
            {
                var paragraph = FirstParagraph(chunk.Text);
                if (paragraph.Length > 0)
                {
                    sb.AppendLine("> " + TextUtil.Truncate(paragraph, 400)).AppendLine();
                }
            }
            else
            {
                var excerpt = TextUtil.SplitLines(chunk.Text).Where(l => l.Trim().Length > 0).Take(8).ToList();
                sb.AppendLine("```" + LanguageOf(chunk.Path));
                foreach (var line in excerpt)
                {
                    sb.AppendLine(TextUtil.Truncate(line, 140));
                }
                sb.AppendLine("```").AppendLine();
            }
        }
    }

    private static string FirstParagraph(string markdown)
    {
        var document = MarkdownDocument.Parse(markdown);
        var paragraph = document.Blocks.OfType<MdParagraph>().FirstOrDefault();
        return paragraph is null ? "" : MarkdownDocument.PlainText(paragraph.Inlines).Trim();
    }

    public static string LanguageOf(string path) => Indexing.IngestionFilters.LanguageOf(path) switch
    {
        "csharp" => "csharp",
        "markdown" => "markdown",
        "json" => "json",
        "msbuild" or "xml" => "xml",
        "yaml" => "yaml",
        { } other => other,
        null => "",
    };
}
