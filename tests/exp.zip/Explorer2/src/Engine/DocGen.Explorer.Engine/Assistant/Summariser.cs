using System.Text;
using System.Text.RegularExpressions;

namespace DocGen.Explorer.Engine.Assistant;

/// <summary>
/// Summaries without a model: a passage's most informative sentences (by the words it repeats), and a Mermaid diagram
/// described from its own source — who or what takes part, and the steps in order. With a chat model the assistant
/// writes the summary instead (<see cref="AssistantService.SummariseAsync"/>); these are the evidence-mode answers.
/// </summary>
public static partial class Summariser
{
    /// <summary>Instructions for the model.</summary>
    public const string Prompt = """
        Summarise what the person selected, for someone who may not be technical.
        - Start with one plain sentence saying what it is about.
        - Then 3 to 6 short bullet points with the main points, in the order they come.
        - For a Mermaid diagram: say what kind of diagram it is, who or what takes part, and walk through the steps or links in order, in plain words.
        - Use only what the selection says; do not add facts. Explain a technical word briefly the first time.
        - No preamble ("Here is a summary…"); start with the summary itself.
        """;

    private static readonly HashSet<string> Stop = new(StringComparer.OrdinalIgnoreCase)
    {
        "the", "a", "an", "and", "or", "of", "to", "in", "on", "for", "is", "are", "was", "were", "be", "it", "its", "this", "that",
        "with", "as", "by", "at", "from", "can", "will", "when", "then", "than", "which", "who", "what", "has", "have", "had", "not",
        "but", "so", "if", "into", "also", "these", "those", "there", "their", "they", "you", "your", "we", "our", "all", "any", "each",
    };

    /// <summary>The passage's most informative sentences, in their order, as a short Markdown summary.</summary>
    public static string Passage(string text)
    {
        var plain = Markup().Replace(text, " ");
        var sentences = SentenceEnd().Split(Spaces().Replace(plain, " ").Trim())
            .Select(s => s.Trim()).Where(s => s.Count(char.IsLetter) >= 12).ToList();
        if (sentences.Count == 0)
        {
            return "The selection is too short to summarise; it says: " + Spaces().Replace(plain, " ").Trim();
        }
        if (sentences.Count <= 3)
        {
            return "In short:\n\n" + string.Join("\n", sentences.Select(s => "- " + s));
        }
        // Words that recur carry the passage; a sentence scores by how many of them it holds (per word, so long sentences do
        // not win by length), and the first sentence gets a little extra as it often says what the passage is about.
        var frequency = Words(plain).GroupBy(w => w).ToDictionary(g => g.Key, g => g.Count());
        var keep = Math.Clamp(sentences.Count / 4, 3, 6);
        var chosen = sentences.Select((s, i) =>
            {
                var words = Words(s).ToList();
                var score = words.Count == 0 ? 0 : words.Sum(w => frequency.GetValueOrDefault(w)) / (double)Math.Sqrt(words.Count);
                return (Sentence: s, Index: i, Score: score * (i == 0 ? 1.3 : 1));
            })
            .OrderByDescending(x => x.Score).Take(keep).OrderBy(x => x.Index).Select(x => x.Sentence).ToList();
        return $"The main points ({chosen.Count} of its {sentences.Count} sentences):\n\n" + string.Join("\n", chosen.Select(s => "- " + s));
    }

    private static IEnumerable<string> Words(string text)
        => Word().Matches(text).Select(m => m.Value.ToLowerInvariant()).Where(w => w.Length > 2 && !Stop.Contains(w));

    /// <summary>A Mermaid diagram described in plain words from its source.</summary>
    public static string Diagram(string code)
    {
        var lines = Code.MermaidFlowchart.WithoutFrontMatter(code).Split('\n').Select(l => l.Trim()).Where(l => l.Length > 0 && !l.StartsWith("%%", StringComparison.Ordinal)).ToList();
        if (lines.Count == 0)
        {
            return "The diagram is empty.";
        }
        var kind = lines[0].Split(' ')[0];
        return kind switch
        {
            "sequenceDiagram" => Sequence(lines.Skip(1).ToList()),
            "flowchart" or "graph" => Flowchart(lines.Skip(1).ToList()),
            "classDiagram" => Classes(lines.Skip(1).ToList()),
            _ => $"A Mermaid **{kind}** diagram of {lines.Count - 1} lines. Its first lines:\n\n" + string.Join("\n", lines.Skip(1).Take(6).Select(l => "- `" + l + "`")),
        };
    }

    private static string Sequence(List<string> lines)
    {
        var declared = lines.Select(l => Participant().Match(l)).Where(m => m.Success)
            .ToDictionary(m => m.Groups["id"].Value, m => m.Groups["label"].Success ? m.Groups["label"].Value.Trim() : m.Groups["id"].Value);
        string Name(string id) => declared.GetValueOrDefault(id, id);
        var steps = lines.Select(l => Message().Match(l)).Where(m => m.Success)
            .Select(m => (From: Name(m.Groups["from"].Value), To: Name(m.Groups["to"].Value), Reply: m.Groups["arrow"].Value.StartsWith("--", StringComparison.Ordinal), Text: m.Groups["text"].Value.Trim()))
            .ToList();
        var who = declared.Values.Concat(steps.SelectMany(s => new[] { s.From, s.To })).Distinct().ToList();
        var sb = new StringBuilder($"A **sequence diagram**: {who.Count} part{(who.Count == 1 ? "" : "s")} ({string.Join(", ", who.Take(8))}{(who.Count > 8 ? ", …" : "")}) " +
                                   $"exchange {steps.Count} message{(steps.Count == 1 ? "" : "s")}, read from top to bottom.");
        if (steps.Count > 0)
        {
            sb.Append("\n\nIn order:\n\n");
            foreach (var (s, i) in steps.Take(10).Select((s, i) => (s, i)))
            {
                sb.Append($"{i + 1}. **{s.From}** {(s.Reply ? "replies to" : "asks")} **{s.To}**{(s.Text.Length > 0 ? $": {s.Text}" : "")}\n");
            }
            if (steps.Count > 10)
            {
                sb.Append($"\n…and {steps.Count - 10} more, ending with **{steps[^1].From}** → **{steps[^1].To}**{(steps[^1].Text.Length > 0 ? $" ({steps[^1].Text})" : "")}.");
            }
        }
        return sb.ToString().TrimEnd();
    }

    private static string Flowchart(List<string> lines)
    {
        var labels = new Dictionary<string, string>();
        var edges = new List<(string From, string To, string Label)>();
        foreach (var line in lines)
        {
            foreach (Match node in Node().Matches(line))
            {
                labels.TryAdd(node.Groups["id"].Value, node.Groups["label"].Value.Trim('"', ' '));
            }
            var ids = Edge().Matches(line).Select(m => m.Groups["id"].Value).ToList();
            var label = EdgeLabel().Match(line) is { Success: true } l ? l.Groups["label"].Value.Trim() : "";
            for (var i = 0; i + 1 < ids.Count; i++)
            {
                edges.Add((ids[i], ids[i + 1], label));
            }
        }
        string Name(string id) => labels.GetValueOrDefault(id, id);
        var nodes = labels.Keys.Concat(edges.SelectMany(e => new[] { e.From, e.To })).Distinct().ToList();
        var starts = nodes.Where(n => edges.All(e => e.To != n) && edges.Any(e => e.From == n)).Select(Name).ToList();
        var ends = nodes.Where(n => edges.All(e => e.From != n) && edges.Any(e => e.To == n)).Select(Name).ToList();
        var sb = new StringBuilder($"A **flowchart** of {nodes.Count} step{(nodes.Count == 1 ? "" : "s")} joined by {edges.Count} link{(edges.Count == 1 ? "" : "s")}.");
        if (starts.Count > 0)
        {
            sb.Append($" It starts at {string.Join(", ", starts.Take(4).Select(s => $"**{s}**"))}");
            sb.Append(ends.Count > 0 ? $" and ends at {string.Join(", ", ends.Take(4).Select(s => $"**{s}**"))}." : ".");
        }
        if (edges.Count > 0)
        {
            sb.Append("\n\nThe links:\n\n");
            foreach (var (from, to, label) in edges.Take(12))
            {
                sb.Append($"- **{Name(from)}** leads to **{Name(to)}**{(label.Length > 0 ? $" ({label})" : "")}\n");
            }
            if (edges.Count > 12)
            {
                sb.Append($"- …and {edges.Count - 12} more.\n");
            }
        }
        return sb.ToString().TrimEnd();
    }

    private static string Classes(List<string> lines)
    {
        var classes = lines.Select(l => ClassName().Match(l)).Where(m => m.Success).Select(m => m.Groups["name"].Value).Distinct().ToList();
        var links = lines.Count(l => Relation().IsMatch(l));
        return $"A **class diagram** of {classes.Count} class{(classes.Count == 1 ? "" : "es")} ({string.Join(", ", classes.Take(10))}{(classes.Count > 10 ? ", …" : "")}) " +
               $"with {links} relationship{(links == 1 ? "" : "s")} between them (inheritance, use or containment).";
    }

    [GeneratedRegex(@"```[a-zA-Z]*|`|\*\*|__|#+\s|\[(?<t>[^\]]*)\]\([^)]*\)|^\s*[-*+]\s|\|", RegexOptions.Multiline)]
    private static partial Regex Markup();

    [GeneratedRegex(@"(?<=[.!?])\s+(?=[A-Z0-9""'(])")]
    private static partial Regex SentenceEnd();

    [GeneratedRegex(@"\s+")]
    private static partial Regex Spaces();

    [GeneratedRegex(@"[\p{L}][\p{L}\p{N}_]*")]
    private static partial Regex Word();

    [GeneratedRegex(@"^(?:participant|actor)\s+(?<id>[^\s]+)(?:\s+as\s+(?<label>.+))?$")]
    private static partial Regex Participant();

    [GeneratedRegex(@"^(?<from>[^\s\-<>+]+)\s*(?<arrow>--?>>|--?>|--?x|--?\))[+-]?\s*(?<to>[^\s:]+)\s*:?\s*(?<text>.*)$")]
    private static partial Regex Message();

    [GeneratedRegex(@"(?<id>[A-Za-z0-9_]+)\s*(?:\[\(|\(\[|\[\[|\(\(|\[|\(|\{\{|\{|>)(?<label>[^\]\)\}]*)")]
    private static partial Regex Node();

    [GeneratedRegex(@"(?:^|-->|---|-\.->|==>|--[^>]*-->)\s*(?:\|[^|]*\|\s*)?(?<id>[A-Za-z0-9_]+)")]
    private static partial Regex Edge();

    [GeneratedRegex(@"\|(?<label>[^|]+)\||--\s*(?<label>[^->]+?)\s*-->")]
    private static partial Regex EdgeLabel();

    [GeneratedRegex(@"^class\s+(?<name>[A-Za-z0-9_]+)")]
    private static partial Regex ClassName();

    [GeneratedRegex(@"<\|--|\*--|o--|-->|\.\.>|\.\.\|>|--")]
    private static partial Regex Relation();
}
