using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;

namespace DocGen.Explorer.Engine.Indexing;

/// <summary>The ingestion filters: which files are read, and what kind of file each one is.</summary>
public sealed class IngestionFilters
{
    public static readonly IReadOnlyDictionary<string, string> Languages = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
    {
        // Source.
        [".cs"] = "csharp", [".vb"] = "vbnet", [".fs"] = "fsharp", [".fsx"] = "fsharp", [".py"] = "python", [".js"] = "javascript",
        [".mjs"] = "javascript", [".cjs"] = "javascript", [".jsx"] = "javascript", [".ts"] = "typescript", [".tsx"] = "typescript",
        [".java"] = "java", [".kt"] = "kotlin", [".go"] = "go", [".rs"] = "rust", [".c"] = "c", [".h"] = "c", [".cpp"] = "cpp",
        [".cc"] = "cpp", [".hpp"] = "cpp", [".swift"] = "swift", [".rb"] = "ruby", [".php"] = "php", [".sql"] = "sql",
        [".ps1"] = "powershell", [".psm1"] = "powershell", [".sh"] = "shell", [".bash"] = "shell", [".bat"] = "batch", [".cmd"] = "batch",
        [".bas"] = "vb6", [".cls"] = "vb6", [".frm"] = "vb6", [".ctl"] = "vb6", [".razor"] = "razor", [".cshtml"] = "razor",
        [".xaml"] = "xaml", [".html"] = "html", [".htm"] = "html", [".css"] = "css", [".scss"] = "scss", [".less"] = "less",
        [".vue"] = "vue", [".svelte"] = "svelte", [".dart"] = "dart", [".scala"] = "scala", [".lua"] = "lua", [".r"] = "r",
        [".proto"] = "protobuf", [".graphql"] = "graphql", [".http"] = "http",
        // Documentation.
        [".md"] = "markdown", [".markdown"] = "markdown", [".mdx"] = "markdown", [".rst"] = "rst", [".adoc"] = "asciidoc", [".txt"] = "text",
        // Configuration and build.
        [".json"] = "json", [".jsonc"] = "json", [".yml"] = "yaml", [".yaml"] = "yaml", [".xml"] = "xml", [".config"] = "xml",
        [".csproj"] = "msbuild", [".vbproj"] = "msbuild", [".fsproj"] = "msbuild", [".props"] = "msbuild", [".targets"] = "msbuild",
        [".sln"] = "solution", [".slnx"] = "solution", [".vbp"] = "vb6project", [".toml"] = "toml", [".ini"] = "ini",
        [".editorconfig"] = "ini", [".resx"] = "xml", [".gradle"] = "groovy", [".tf"] = "terraform", [".env"] = "ini",
    };

    private static readonly HashSet<string> DocumentationLanguages = new(StringComparer.Ordinal) { "markdown", "rst", "asciidoc" };

    private static readonly HashSet<string> ConfigLanguages = new(StringComparer.Ordinal)
    {
        "json", "yaml", "xml", "msbuild", "solution", "vb6project", "toml", "ini", "groovy", "terraform",
    };

    private static readonly Dictionary<string, string> SpecialNames = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Dockerfile"] = "dockerfile", ["Makefile"] = "makefile", ["Jenkinsfile"] = "groovy", ["LICENSE"] = "text",
        [".gitignore"] = "ini", [".gitattributes"] = "ini", [".dockerignore"] = "ini",
    };

    public HashSet<string> ExcludedDirectories { get; } = new(StringComparer.OrdinalIgnoreCase)
    {
        "bin", "obj", ".git", ".vs", ".vscode", ".idea", "node_modules", "packages", "TestResults", ".nuget", "dist", "build",
        "out", "target", "__pycache__", ".venv", "venv", ".gradle", ".next", "coverage", ".svn", ".hg", "wwwroot/lib", "artifacts",
    };

    public long MaxFileBytes { get; set; } = 2 * 1024 * 1024;
    public int MaxFiles { get; set; } = 100_000;

    public static string? LanguageOf(string path)
    {
        var name = System.IO.Path.GetFileName(path);
        if (SpecialNames.TryGetValue(name, out var special))
        {
            return special;
        }
        return Languages.TryGetValue(System.IO.Path.GetExtension(path), out var language) ? language : null;
    }

    public static FileKind KindOf(string path, string language)
    {
        if (DocumentationLanguages.Contains(language))
        {
            return FileKind.Documentation;
        }
        if (language == "text")
        {
            var name = System.IO.Path.GetFileNameWithoutExtension(path);
            var inDocs = path.Split('/').SkipLast(1).Any(s => s.Equals("docs", StringComparison.OrdinalIgnoreCase) || s.Equals("doc", StringComparison.OrdinalIgnoreCase) || s.Equals("documentation", StringComparison.OrdinalIgnoreCase));
            return inDocs || name.Equals("README", StringComparison.OrdinalIgnoreCase) ? FileKind.Documentation : FileKind.Other;
        }
        if (ConfigLanguages.Contains(language) || language is "dockerfile" or "makefile")
        {
            return FileKind.Config;
        }
        return FileKind.Source;
    }
}

/// <summary>Walks a repository with the ingestion filters, never following links and skipping hidden and excluded folders.</summary>
public static class FileScanner
{
    public static List<ScannedFile> Scan(string root, IngestionFilters filters, IReadOnlyDictionary<string, ScannedFile>? previous, CancellationToken ct)
    {
        root = Path.GetFullPath(root);
        var result = new List<ScannedFile>();
        var stack = new Stack<DirectoryInfo>();
        stack.Push(new DirectoryInfo(root));
        var options = new EnumerationOptions
        {
            RecurseSubdirectories = false,
            AttributesToSkip = FileAttributes.ReparsePoint | FileAttributes.System,
            IgnoreInaccessible = true,
        };
        while (stack.Count > 0 && result.Count < filters.MaxFiles)
        {
            ct.ThrowIfCancellationRequested();
            var dir = stack.Pop();
            List<FileSystemInfo> entries;
            try
            {
                entries = dir.EnumerateFileSystemInfos("*", options).OrderBy(e => e.Name, StringComparer.OrdinalIgnoreCase).ToList();
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                continue;
            }
            foreach (var entry in entries.OfType<DirectoryInfo>().Reverse())
            {
                var relativeDir = Relative(root, entry.FullName);
                if (entry.Name.StartsWith('.') || filters.ExcludedDirectories.Contains(entry.Name) || filters.ExcludedDirectories.Contains(relativeDir))
                {
                    continue;
                }
                stack.Push(entry);
            }
            foreach (var file in entries.OfType<FileInfo>())
            {
                if (result.Count >= filters.MaxFiles)
                {
                    break;
                }
                var language = IngestionFilters.LanguageOf(file.Name);
                if (language is null || file.Length > filters.MaxFileBytes)
                {
                    continue;
                }
                var relative = Relative(root, file.FullName);
                var ticks = file.LastWriteTimeUtc.Ticks;
                if (previous is not null && previous.TryGetValue(relative, out var known) && known.Size == file.Length && known.LastWriteTicks == ticks)
                {
                    result.Add(known);
                    continue;
                }
                byte[] bytes;
                try
                {
                    bytes = File.ReadAllBytes(file.FullName);
                }
                catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
                {
                    continue;
                }
                if (IsBinary(bytes))
                {
                    continue;
                }
                result.Add(new ScannedFile
                {
                    Path = relative,
                    Size = file.Length,
                    Lines = TextUtil.CountLines(DecodeText(bytes)),
                    Language = language,
                    Kind = IngestionFilters.KindOf(relative, language),
                    Hash = TextUtil.HashBytes(bytes),
                    LastWriteTicks = ticks,
                });
            }
        }
        result.Sort((a, b) => string.Compare(a.Path, b.Path, StringComparison.OrdinalIgnoreCase));
        return result;
    }

    public static string Relative(string root, string full) => Path.GetRelativePath(root, full).Replace('\\', '/');

    public static bool IsBinary(ReadOnlySpan<byte> bytes) => bytes[..Math.Min(bytes.Length, 8000)].IndexOf((byte)0) >= 0;

    /// <summary>Decodes UTF-8 (with or without BOM); other encodings fall back to Latin-1 rather than failing.</summary>
    public static string DecodeText(byte[] bytes)
    {
        if (bytes.Length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF)
        {
            return System.Text.Encoding.UTF8.GetString(bytes, 3, bytes.Length - 3);
        }
        try
        {
            return new System.Text.UTF8Encoding(false, throwOnInvalidBytes: true).GetString(bytes);
        }
        catch (System.Text.DecoderFallbackException)
        {
            return System.Text.Encoding.Latin1.GetString(bytes);
        }
    }

    public static string ReadText(string root, string relative)
    {
        var full = SafeResolve(root, relative);
        return DecodeText(File.ReadAllBytes(full));
    }

    /// <summary>Resolves a repository-relative path, rejecting traversal outside the root.</summary>
    public static string SafeResolve(string root, string relative)
    {
        var rootFull = Path.GetFullPath(root);
        var full = Path.GetFullPath(Path.Combine(rootFull, relative.Replace('/', Path.DirectorySeparatorChar)));
        var rootWithSep = rootFull.EndsWith(Path.DirectorySeparatorChar) ? rootFull : rootFull + Path.DirectorySeparatorChar;
        if (!full.StartsWith(rootWithSep, StringComparison.OrdinalIgnoreCase) && !string.Equals(full, rootFull, StringComparison.OrdinalIgnoreCase))
        {
            throw new UnauthorizedAccessException($"'{relative}' is outside the repository.");
        }
        return full;
    }
}
