using System.Text.RegularExpressions;
using DocGen.Explorer.Engine.Markdown;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;
using DocGen.Analysis.Indexing;

namespace DocGen.Explorer.Engine.Indexing;

/// <summary>
/// Splits files into retrieval chunks: Markdown by section, C# by type and member (from the C# parser's symbol
/// ranges), other code and configuration by overlapping line windows. Chunks never exceed <see cref="MaxLines"/> lines.
/// </summary>
public static partial class Chunker
{
    public const int MaxLines = 80;
    public const int WindowLines = 60;
    public const int WindowStride = 50;
    public const int MaxChars = 6000;

    /// <summary>Bumped when the chunking rules change, so a refresh re-chunks files chunked under older rules.</summary>
    public const int Version = 2;

    /// <summary>Data formats: a large file in one of these is test data, a fixture or an export, not something to read line by line.</summary>
    public static readonly IReadOnlySet<string> DataLanguages = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "xml", "json", "csv", "tsv", "resx" };

    /// <summary>Data files longer than this get one chunk (where it is and how it begins) instead of a window every 50 lines.</summary>
    public const int DataFileMaxLines = 160;

    public const int DataHeadLines = 40;

    /// <summary>
    /// Whether a file is bulk data: a data format and either long or kept with test fixtures. Thousands of request and
    /// response samples otherwise become hundreds of thousands of chunks that slow loading and crowd the code out of
    /// search results.
    /// </summary>
    public static bool IsBulkData(ScannedFile file, int lineCount)
        => DataLanguages.Contains(file.Language) && !IsSettingsFile(file.Path)
           && (lineCount > DataFileMaxLines || file.Size > 64 * 1024);

    /// <summary>Configuration people read and edit (web.config, appsettings.json, package.json…): always chunked in full.</summary>
    public static bool IsSettingsFile(string path)
    {
        var name = System.IO.Path.GetFileName(path).ToLowerInvariant();
        return name.EndsWith(".config", StringComparison.Ordinal) || name.StartsWith("appsettings", StringComparison.Ordinal)
               || name is "package.json" or "launchsettings.json" or "tsconfig.json" or "global.json" or "docker-compose.yml" or "docker-compose.yaml"
               || name.EndsWith(".settings.json", StringComparison.Ordinal);
    }

    public static List<Chunk> ChunkFile(ScannedFile file, string text, FileIndex? csharp)
    {
        var lines = TextUtil.SplitLines(text);
        if (lines.Length > 0 && lines[^1].Length == 0)
        {
            lines = lines[..^1];
        }
        if (lines.Length == 0 || lines.All(l => l.Trim().Length == 0))
        {
            return [];
        }
        List<Chunk> chunks;
        if (IsBulkData(file, lines.Length))
        {
            // One chunk: the path says what it is for, the head shows its shape.
            var head = Make(file, lines, 1, Math.Min(lines.Length, DataHeadLines), "data", $"{System.IO.Path.GetFileName(file.Path)} (data, {lines.Length:N0} lines)", null);
            head.EndLine = lines.Length;
            chunks = [head];
        }
        else if (file.Kind == FileKind.Documentation && file.Language == "markdown")
        {
            chunks = ChunkMarkdown(file, lines);
        }
        else if (csharp is { Parsed: true, Symbols.Count: > 0 })
        {
            chunks = ChunkCSharp(file, lines, csharp);
        }
        else
        {
            var kind = file.Kind switch
            {
                FileKind.Documentation => "doc",
                FileKind.Config => "config",
                FileKind.Source => "code",
                _ => "text",
            };
            chunks = Windows(file, lines, 1, lines.Length, kind, null, null);
        }
        return chunks;
    }

    private static List<Chunk> ChunkMarkdown(ScannedFile file, string[] lines)
    {
        var document = MarkdownDocument.Parse(string.Join("\n", lines));
        var cuts = document.Headings.Where(h => h.Level <= 3).Select(h => (h.Line, h.Text)).OrderBy(h => h.Line).ToList();
        var chunks = new List<Chunk>();
        var title = TitleOf(file);
        if (cuts.Count == 0 || cuts[0].Line > 1)
        {
            var end = cuts.Count == 0 ? lines.Length : cuts[0].Line - 1;
            chunks.AddRange(Windows(file, lines, 1, end, "doc", title, null));
        }
        for (var i = 0; i < cuts.Count; i++)
        {
            var start = cuts[i].Line;
            var end = i + 1 < cuts.Count ? cuts[i + 1].Line - 1 : lines.Length;
            chunks.AddRange(Windows(file, lines, start, end, "doc", cuts[i].Text, null));
        }
        return chunks;
    }

    private static List<Chunk> ChunkCSharp(ScannedFile file, string[] lines, FileIndex index)
    {
        var chunks = new List<Chunk>();
        var covered = new bool[lines.Length + 2];
        var types = index.Symbols.Where(s => SymbolKinds.IsType(s.Kind) && s.StartLine > 0 && s.EndLine >= s.StartLine).OrderBy(s => s.StartLine).ToList();
        var topLevel = types.Where(t => !types.Any(o => !ReferenceEquals(o, t) && o.StartLine <= t.StartLine && o.EndLine >= t.EndLine && (o.StartLine < t.StartLine || o.EndLine > t.EndLine))).ToList();

        foreach (var type in topLevel)
        {
            var start = Math.Max(1, ExtendToDocComment(lines, type.StartLine));
            var end = Math.Min(lines.Length, type.EndLine);
            if (end - start + 1 <= MaxLines)
            {
                chunks.Add(Make(file, lines, start, end, "code", $"{type.Kind} {type.Name}", type.FullName));
                Mark(covered, start, end);
                continue;
            }
            // Large type: one chunk per member (and nested type), plus the declaration header.
            var members = index.Symbols
                .Where(s => !ReferenceEquals(s, type) && s.StartLine > type.StartLine && s.EndLine <= type.EndLine && s.StartLine > 0 && IsDirectChild(s, type, types))
                .OrderBy(s => s.StartLine).ToList();
            var headerEnd = members.Count > 0 ? Math.Min(end, ExtendToDocComment(lines, members[0].StartLine) - 1) : end;
            if (headerEnd >= start)
            {
                chunks.AddRange(Windows(file, lines, start, Math.Min(headerEnd, start + MaxLines - 1), "code", $"{type.Kind} {type.Name}", type.FullName));
                Mark(covered, start, headerEnd);
            }
            foreach (var member in members)
            {
                var memberStart = Math.Max(start, ExtendToDocComment(lines, member.StartLine));
                var memberEnd = Math.Min(end, Math.Max(member.EndLine, member.StartLine));
                if (memberStart > memberEnd || covered[member.StartLine])
                {
                    continue;
                }
                chunks.AddRange(Windows(file, lines, memberStart, memberEnd, "code", $"{type.Name}.{member.Name}", member.FullName));
                Mark(covered, memberStart, memberEnd);
            }
            Mark(covered, start, end);
        }

        // Whatever no type covered (top-level statements, delegates outside types…), when it holds real code.
        var runStart = -1;
        for (var line = 1; line <= lines.Length + 1; line++)
        {
            var free = line <= lines.Length && !covered[line];
            if (free && runStart < 0)
            {
                runStart = line;
            }
            else if (!free && runStart > 0)
            {
                var meaningful = Enumerable.Range(runStart, line - runStart)
                    .Select(l => lines[l - 1].Trim())
                    .Count(t => t.Length > 0 && !t.StartsWith("using ", StringComparison.Ordinal) && !t.StartsWith("namespace ", StringComparison.Ordinal) && t is not ("{" or "}") && !t.StartsWith("//", StringComparison.Ordinal));
                if (meaningful >= 2)
                {
                    chunks.AddRange(Windows(file, lines, runStart, line - 1, "code", TitleOf(file), null));
                }
                runStart = -1;
            }
        }
        return chunks.OrderBy(c => c.StartLine).ToList();
    }

    private static bool IsDirectChild(SymbolRecord candidate, SymbolRecord type, List<SymbolRecord> types)
        => !types.Any(t => !ReferenceEquals(t, type) && !ReferenceEquals(t, candidate) && t.StartLine > type.StartLine && t.EndLine <= type.EndLine && t.StartLine <= candidate.StartLine && t.EndLine >= candidate.EndLine);

    /// <summary>Includes the XML documentation comment and attributes directly above a declaration.</summary>
    private static int ExtendToDocComment(string[] lines, int line)
    {
        var start = line;
        while (start > 1)
        {
            var previous = lines[start - 2].Trim();
            if (previous.StartsWith("///", StringComparison.Ordinal) || previous.StartsWith('[') && previous.EndsWith(']'))
            {
                start--;
                continue;
            }
            break;
        }
        return start;
    }

    private static void Mark(bool[] covered, int start, int end)
    {
        for (var i = Math.Max(1, start); i <= end && i < covered.Length; i++)
        {
            covered[i] = true;
        }
    }

    private static List<Chunk> Windows(ScannedFile file, string[] lines, int start, int end, string kind, string? title, string? symbol)
    {
        var result = new List<Chunk>();
        // Trim blank lines at both ends.
        while (start <= end && lines[start - 1].Trim().Length == 0)
        {
            start++;
        }
        while (end >= start && lines[end - 1].Trim().Length == 0)
        {
            end--;
        }
        if (start > end)
        {
            return result;
        }
        if (end - start + 1 <= MaxLines)
        {
            result.Add(Make(file, lines, start, end, kind, title ?? GuessTitle(file, lines, start, end), symbol));
            return result;
        }
        for (var s = start; s <= end; s += WindowStride)
        {
            var e = Math.Min(end, s + WindowLines - 1);
            result.Add(Make(file, lines, s, e, kind, title is null ? GuessTitle(file, lines, s, e) : $"{title} ({s}–{e})", symbol));
            if (e == end)
            {
                break;
            }
        }
        return result;
    }

    private static Chunk Make(ScannedFile file, string[] lines, int start, int end, string kind, string title, string? symbol)
    {
        var text = string.Join("\n", lines[(start - 1)..end]);
        if (text.Length > MaxChars)
        {
            text = text[..MaxChars];
        }
        return new Chunk
        {
            Id = TextUtil.ShortHash($"{file.Path}:{start}-{end}:{symbol}"),
            Path = file.Path,
            StartLine = start,
            EndLine = end,
            Kind = kind,
            Title = title,
            Symbol = symbol,
            Text = text,
        };
    }

    private static string TitleOf(ScannedFile file) => System.IO.Path.GetFileName(file.Path);

    /// <summary>A title from the first declaration-looking line ("def load", "function render", "class Foo").</summary>
    private static string GuessTitle(ScannedFile file, string[] lines, int start, int end)
    {
        for (var i = start; i <= Math.Min(end, start + 30); i++)
        {
            var match = DeclarationRegex().Match(lines[i - 1]);
            if (match.Success)
            {
                return $"{TitleOf(file)} · {match.Groups[2].Value}";
            }
        }
        return TitleOf(file);
    }

    [GeneratedRegex(@"^\s*(?:export\s+)?(?:public\s+|private\s+|protected\s+|static\s+|async\s+|abstract\s+)*(def|function|class|interface|struct|enum|func|fn|sub|module|type|trait|impl)\s+([A-Za-z_][A-Za-z0-9_]*)", RegexOptions.IgnoreCase)]
    private static partial Regex DeclarationRegex();
}
