using System.Text.Json;
using DocGen.Explorer.Engine.Models;
using DocGen.Analysis.Indexing;

namespace DocGen.Explorer.Engine.Indexing;

/// <summary>
/// Operational knowledge facts, from the code index: configuration keys and reads, HTTP endpoints, dependency-injection
/// registrations, middleware order, packages and entry points. package.json dependencies are read too.
/// </summary>
public static class OkfAnalyzer
{
    public const int MaxEntities = 20_000;

    public static List<OkfEntity> Analyze(CodeIndex? code, IReadOnlyList<ScannedFile> files, Func<string, string?> readText)
    {
        var result = new List<OkfEntity>();
        if (code is not null)
        {
            foreach (var (key, locations) in code.ConfigValues.OrderBy(k => k.Key, StringComparer.OrdinalIgnoreCase))
            {
                var first = locations.FirstOrDefault();
                result.Add(new OkfEntity { Kind = "config", Name = key, Detail = "configuration value", Path = first.File ?? "", Line = first.Line });
            }
            foreach (var reference in code.ConfigReferences)
            {
                result.Add(new OkfEntity
                {
                    Kind = "config",
                    Name = reference.Key,
                    Detail = reference.Kind switch
                    {
                        "optionsBinding" => $"bound to {reference.Type}",
                        "connectionString" => "connection string read",
                        "section" => "section read",
                        _ => $"{reference.Kind} read" + (reference.Owner is null ? "" : $" in {reference.Owner}"),
                    },
                    Path = reference.File,
                    Line = reference.Line,
                });
            }
            foreach (var endpoint in code.Endpoints)
            {
                result.Add(new OkfEntity { Kind = "endpoint", Name = $"{endpoint.Verb} {endpoint.Route}".Trim(), Detail = $"{endpoint.Handler} ({endpoint.Style})", Path = endpoint.File, Line = endpoint.Line });
            }
            foreach (var registration in code.Registrations)
            {
                var implementation = registration.Factory ? "factory" : registration.ImplementationType.Length > 0 ? registration.ImplementationType : registration.ServiceType;
                result.Add(new OkfEntity
                {
                    Kind = "service",
                    Name = registration.ServiceType,
                    Detail = $"{registration.Lifetime} → {implementation}" + (registration.Hosted ? " (hosted)" : ""),
                    Path = registration.File,
                    Line = registration.Line,
                });
            }
            foreach (var middleware in code.Middleware.OrderBy(m => m.File, StringComparer.Ordinal).ThenBy(m => m.Order))
            {
                result.Add(new OkfEntity { Kind = "middleware", Name = middleware.Name, Detail = $"position {middleware.Order}", Path = middleware.File, Line = middleware.Line });
            }
            foreach (var project in code.Manifest.Projects)
            {
                foreach (var package in project.Packages.Where(p => !p.Transitive))
                {
                    result.Add(new OkfEntity { Kind = "package", Name = package.Id, Detail = $"{package.Version ?? package.ResolvedVersion ?? "unversioned"} in {project.Name}", Path = project.Path });
                }
            }
            foreach (var symbol in code.Symbols)
            {
                if (symbol.Kind == SymbolKinds.Method && symbol.Name == "Main" && symbol.Modifiers.Contains("static"))
                {
                    result.Add(new OkfEntity { Kind = "entrypoint", Name = symbol.Container ?? symbol.FullName, Detail = "static Main", Path = symbol.File, Line = symbol.StartLine });
                }
                else if (symbol.Kind == SymbolKinds.TopLevel)
                {
                    result.Add(new OkfEntity { Kind = "entrypoint", Name = Path.GetFileName(symbol.File), Detail = "top-level statements", Path = symbol.File, Line = symbol.StartLine });
                }
            }
        }

        foreach (var file in files.Where(f => Path.GetFileName(f.Path).Equals("package.json", StringComparison.OrdinalIgnoreCase)))
        {
            var text = readText(file.Path);
            if (text is null)
            {
                continue;
            }
            try
            {
                using var document = JsonDocument.Parse(text, new JsonDocumentOptions { AllowTrailingCommas = true, CommentHandling = JsonCommentHandling.Skip });
                foreach (var section in new[] { "dependencies", "devDependencies" })
                {
                    if (document.RootElement.ValueKind == JsonValueKind.Object && document.RootElement.TryGetProperty(section, out var deps) && deps.ValueKind == JsonValueKind.Object)
                    {
                        foreach (var dep in deps.EnumerateObject())
                        {
                            result.Add(new OkfEntity { Kind = "package", Name = dep.Name, Detail = $"{dep.Value} ({section})", Path = file.Path });
                        }
                    }
                }
                if (document.RootElement.ValueKind == JsonValueKind.Object && document.RootElement.TryGetProperty("main", out var main) && main.ValueKind == JsonValueKind.String)
                {
                    result.Add(new OkfEntity { Kind = "entrypoint", Name = main.GetString()!, Detail = "package.json main", Path = file.Path });
                }
            }
            catch (JsonException)
            {
                // Not valid JSON: nothing to learn from it.
            }
        }

        foreach (var file in files.Where(f => Path.GetFileName(f.Path).Equals("Dockerfile", StringComparison.OrdinalIgnoreCase)))
        {
            result.Add(new OkfEntity { Kind = "entrypoint", Name = file.Path, Detail = "container image", Path = file.Path, Line = 1 });
        }

        return result
            .GroupBy(e => (e.Kind, e.Name, e.Path, e.Line))
            .Select(g => g.First())
            .Take(MaxEntities)
            .ToList();
    }
}
