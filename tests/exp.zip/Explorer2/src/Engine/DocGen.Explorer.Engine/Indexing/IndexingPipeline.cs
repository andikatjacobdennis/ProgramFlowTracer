using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text;
using DocGen.Explorer.Engine.Ai;
using DocGen.Explorer.Engine.Documentation;
using DocGen.Explorer.Engine.Graph;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Repositories;
using DocGen.Explorer.Engine.Search;
using DocGen.Explorer.Engine.Storage;
using DocGen.Explorer.Engine.Text;
using DocGen.Analysis.Indexing;
using DocGen.Analysis.Repositories;
using DocGen.Core.Abstractions;
using DocGen.Core.Models;
using DocGen.Core.Options;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;

namespace DocGen.Explorer.Engine.Indexing;

/// <summary>
/// Indexes a repository in nine stages — Scanning, Classifying, ParsingDocumentation, Chunking, Embedding, BuildingGraph,
/// AnalyzingOkf, DescribingGraph, Finalizing — and keeps the result in memory and on disk. A refresh re-reads only the
/// files whose content changed; a full reindex starts from nothing. One run per repository at a time; runs can be cancelled,
/// and a cancelled or failed run leaves the previous index in place.
/// </summary>
public sealed class IndexingPipeline
{
    private readonly ExplorerStore _store;
    private readonly RepositoryService _repositories;
    private readonly IModelGateway _models;
    private readonly CodeIndexService _codeIndex;
    private readonly HashingEmbedder _embedder = new();
    private readonly ConcurrentDictionary<string, RepositoryIndex> _loaded = new(StringComparer.Ordinal);
    private readonly ConcurrentDictionary<string, (CancellationTokenSource Cts, Task Task, IndexRun Run)> _running = new(StringComparer.Ordinal);
    private readonly SemaphoreSlim _loadGate = new(1, 1);
    private readonly ILogger _logger;

    /// <summary>The repositories' records (the assistant names a repository that is not indexed yet).</summary>
    public RepositoryService Repositories => _repositories;

    public IndexingPipeline(ExplorerStore store, RepositoryService repositories, IModelGateway models, ILoggerFactory? loggers = null)
    {
        _store = store;
        _repositories = repositories;
        _models = models;
        loggers ??= NullLoggerFactory.Instance;
        _logger = loggers.CreateLogger<IndexingPipeline>();
        _codeIndex = new CodeIndexService(new IndexStore(store.Root), new StaticOptionsMonitor<AnalysisOptions>(new AnalysisOptions()), loggers.CreateLogger<CodeIndexService>());
    }

    public IngestionFilters Filters { get; } = new();

    /// <summary>Raised on every stage change (from a background thread).</summary>
    public event EventHandler<IndexProgress>? Progress;

    /// <summary>Raised when a run ends, whatever its outcome.</summary>
    public event EventHandler<IndexProgress>? Completed;

    public bool IsRunning(string repositoryId) => _running.ContainsKey(repositoryId);

    public IndexRun? CurrentRun(string repositoryId) => _running.TryGetValue(repositoryId, out var r) ? r.Run : null;

    private static string Rel(string id, string file) => $"repos/{id}/{file}";

    /// <summary>Starts a run in the background (returns at once). A second request while one runs returns the running task.</summary>
    public Task StartAsync(string repositoryId, IndexMode mode)
    {
        ExplorerStore.RequireId(repositoryId);
        var cts = new CancellationTokenSource();
        var run = new IndexRun { Mode = mode };
        var task = new Task<Task>(() => RunCoreAsync(repositoryId, run, cts.Token));
        var entry = (cts, task.Unwrap(), run);
        if (!_running.TryAdd(repositoryId, entry))
        {
            cts.Dispose();
            return _running[repositoryId].Task;
        }
        task.Start(TaskScheduler.Default);
        return entry.Item2;
    }

    /// <summary>Runs to completion (used by tests and by callers that want to wait).</summary>
    public async Task<IndexRun> RunAsync(string repositoryId, IndexMode mode, CancellationToken ct = default)
    {
        var task = StartAsync(repositoryId, mode);
        var run = CurrentRun(repositoryId);
        using (ct.Register(() => Cancel(repositoryId)))
        {
            await task;
        }
        return run ?? (await LoadRunAsync(repositoryId)) ?? new IndexRun { Mode = mode, State = RunState.Failed };
    }

    public bool Cancel(string repositoryId)
    {
        if (_running.TryGetValue(repositoryId, out var entry))
        {
            entry.Cts.Cancel();
            return true;
        }
        return false;
    }

    public async Task<IndexRun?> LoadRunAsync(string repositoryId, CancellationToken ct = default)
        => CurrentRun(repositoryId) ?? await _store.ReadLargeAsync<IndexRun>(Rel(repositoryId, "run.json"), ct);

    private async Task RunCoreAsync(string repositoryId, IndexRun run, CancellationToken ct)
    {
        var repository = await _repositories.GetAsync(repositoryId, CancellationToken.None);
        if (repository is null)
        {
            _running.TryRemove(repositoryId, out _);
            return;
        }
        var previousStatus = repository.Status;
        await _repositories.UpdateAsync(repositoryId, r => { r.Status = RepositoryStatus.Indexing; r.Error = null; }, CancellationToken.None);
        Report(repositoryId, run, "Indexing started");
        try
        {
            if (!Directory.Exists(repository.Path))
            {
                throw new DirectoryNotFoundException($"The folder '{repository.Path}' no longer exists.");
            }
            var index = await ExecuteAsync(repository, run, ct);
            run.State = RunState.Completed;
            run.FinishedAt = DateTime.UtcNow;
            await _store.WriteLargeAsync(Rel(repositoryId, "run.json"), run, CancellationToken.None);
            _loaded[repositoryId] = index;
            await _repositories.UpdateAsync(repositoryId, r =>
            {
                r.Status = RepositoryStatus.Indexed;
                r.LastIndexedAt = run.FinishedAt;
                r.Counters = index.Repository.Counters;
                r.Error = null;
            }, CancellationToken.None);
            Report(repositoryId, run, "Indexing complete");
        }
        catch (OperationCanceledException)
        {
            run.State = RunState.Cancelled;
            run.FinishedAt = DateTime.UtcNow;
            foreach (var stage in run.Stages.Where(s => s.Status is StageStatus.Running or StageStatus.Pending))
            {
                stage.Status = StageStatus.Skipped;
                stage.Detail = stage.Detail.Length == 0 ? "cancelled" : stage.Detail;
            }
            await _store.WriteLargeAsync(Rel(repositoryId, "run.json"), run, CancellationToken.None);
            var restored = previousStatus == RepositoryStatus.Indexing ? RepositoryStatus.NotIndexed : previousStatus;
            await _repositories.UpdateAsync(repositoryId, r => r.Status = restored, CancellationToken.None);
            Report(repositoryId, run, "Indexing cancelled");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Indexing {Repository} failed", repository.Title);
            run.State = RunState.Failed;
            run.Error = ex.Message;
            run.FinishedAt = DateTime.UtcNow;
            var failed = run.Stages.FirstOrDefault(s => s.Status == StageStatus.Running);
            if (failed is not null)
            {
                failed.Status = StageStatus.Failed;
                failed.Detail = ex.Message;
            }
            await _store.WriteLargeAsync(Rel(repositoryId, "run.json"), run, CancellationToken.None);
            await _repositories.UpdateAsync(repositoryId, r => { r.Status = RepositoryStatus.Failed; r.Error = ex.Message; }, CancellationToken.None);
            Report(repositoryId, run, "Indexing failed: " + ex.Message);
        }
        finally
        {
            if (_running.TryRemove(repositoryId, out var entry))
            {
                entry.Cts.Dispose();
            }
            Completed?.Invoke(this, new IndexProgress(repositoryId, run, run.State.ToString()));
        }
    }

    private void Report(string repositoryId, IndexRun run, string? message) => Progress?.Invoke(this, new IndexProgress(repositoryId, run, message));

    private async Task<T> StageAsync<T>(string repositoryId, IndexRun run, string name, CancellationToken ct, Func<StageResult, Task<T>> body)
    {
        ct.ThrowIfCancellationRequested();
        var stage = run.Stage(name);
        stage.Status = StageStatus.Running;
        Report(repositoryId, run, name);
        var sw = Stopwatch.StartNew();
        var result = await body(stage);
        stage.DurationMs = sw.ElapsedMilliseconds;
        if (stage.Status == StageStatus.Running)
        {
            stage.Status = StageStatus.Done;
        }
        Report(repositoryId, run, name);
        return result;
    }

    private async Task<RepositoryIndex> ExecuteAsync(RepositoryRecord repository, IndexRun run, CancellationToken ct)
    {
        var id = repository.Id;
        var full = run.Mode == IndexMode.Full;
        RepositoryIndex? previous = full ? null : await GetAsync(id, ct);
        // Chunks made under older chunking rules are made again (their embeddings are reused where a chunk is unchanged).
        var reuseChunks = previous?.LastRun?.ChunkerVersion == Chunker.Version;
        run.ChunkerVersion = Chunker.Version;

        // 1. Scanning.
        var files = await StageAsync(id, run, IndexStages.Scanning, ct, stage =>
        {
            var known = previous?.Files.ToDictionary(f => f.Path, StringComparer.OrdinalIgnoreCase);
            var scanned = FileScanner.Scan(repository.Path, Filters, known, ct);
            stage.Detail = $"{TextUtil.Plural(scanned.Count, "file")} discovered";
            return Task.FromResult(scanned);
        });

        // 2. Classifying (and the code index, which is incremental by content hash too).
        var (changed, code) = await StageAsync(id, run, IndexStages.Classifying, ct, async stage =>
        {
            var before = previous?.Files.ToDictionary(f => f.Path, f => f.Hash, StringComparer.OrdinalIgnoreCase) ?? new(StringComparer.OrdinalIgnoreCase);
            var changedPaths = files.Where(f => !before.TryGetValue(f.Path, out var hash) || hash != f.Hash).Select(f => f.Path).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var present = files.Select(f => f.Path).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var removed = before.Keys.Count(p => !present.Contains(p));
            var unchanged = files.Count - changedPaths.Count;
            CodeIndex? codeIndex = null;
            if (files.Any(f => f.Language is "csharp" or "msbuild" or "solution"))
            {
                var handle = new RepositoryHandle { Name = repository.Title, Root = repository.Path, Source = "registered", IndexKey = id };
                if (full)
                {
                    _codeIndex.Invalidate(handle);
                }
                await _codeIndex.UpdateAsync(handle, full, ct);
                codeIndex = await _codeIndex.GetAsync(handle, ct, TimeSpan.FromMinutes(5));
            }
            stage.Detail = $"{changedPaths.Count} changed, {unchanged} unchanged, {removed} removed" +
                           (codeIndex is { Symbols.Count: > 0 } ? $" · {TextUtil.Plural(codeIndex.Symbols.Count, "symbol")} parsed" : "");
            return (changedPaths, codeIndex);
        });

        // 3. ParsingDocumentation.
        var pages = await StageAsync(id, run, IndexStages.ParsingDocumentation, ct, stage =>
        {
            var list = new List<DocPage>();
            foreach (var file in files.Where(f => f.Kind == FileKind.Documentation && f.Language == "markdown"))
            {
                ct.ThrowIfCancellationRequested();
                var reuse = !changed.Contains(file.Path) ? previous?.PageForSource(file.Path) : null;
                if (reuse is not null)
                {
                    list.Add(reuse);
                    continue;
                }
                var text = SafeRead(repository.Path, file.Path);
                if (text is not null)
                {
                    list.Add(DocumentationBuilder.PageForMarkdown(file, text));
                }
            }
            // Two files can slug to the same id ("a-b.md" and "a/b.md"): make ids unique.
            foreach (var group in list.GroupBy(p => p.Id).Where(g => g.Count() > 1))
            {
                var n = 2;
                foreach (var page in group.Skip(1))
                {
                    page.Id = $"{page.Id}-{n++}";
                }
            }
            stage.Detail = $"{TextUtil.Plural(list.Count, "documentation page")} parsed";
            return Task.FromResult(list);
        });

        // 4. Chunking.
        var chunks = await StageAsync(id, run, IndexStages.Chunking, ct, async stage =>
        {
            var result = new List<Chunk>();
            var reused = 0;
            foreach (var file in files)
            {
                ct.ThrowIfCancellationRequested();
                if (reuseChunks && !changed.Contains(file.Path) && previous is not null && previous.ChunksByPath.TryGetValue(file.Path, out var old))
                {
                    result.AddRange(old);
                    reused += old.Count;
                    continue;
                }
                var text = SafeRead(repository.Path, file.Path);
                if (text is null)
                {
                    continue;
                }
                FileIndex? parsed = null;
                code?.Files.TryGetValue(file.Path, out parsed);
                result.AddRange(Chunker.ChunkFile(file, text, parsed));
            }
            var confluence = await _store.ReadLargeAsync<Confluence.ConfluenceDocument>(Rel(id, "confluence.json"), ct);
            var external = confluence is null || repository.ConfluenceSpaces.Count == 0 ? [] : Confluence.ConfluenceService.ToChunks(confluence);
            result.AddRange(external);
            stage.Detail = $"{TextUtil.Plural(result.Count - reused - external.Count, "chunk")} generated" + (reused > 0 ? $", {reused} reused" : "")
                           + (external.Count > 0 ? $", {external.Count} from Confluence" : "");
            return result;
        });

        // 5. Embedding.
        var vectors = await StageAsync(id, run, IndexStages.Embedding, ct, stage =>
        {
            var store = new VectorStore();
            var generated = 0;
            foreach (var chunk in chunks)
            {
                ct.ThrowIfCancellationRequested();
                if (previous is not null && previous.Vectors.TryGet(chunk.Id, out var existing))
                {
                    store.Set(chunk.Id, existing);
                    continue;
                }
                store.Set(chunk.Id, _embedder.EmbedChunk(chunk));
                generated++;
            }
            var reused = store.Count - generated;
            stage.Detail = $"{TextUtil.Plural(generated, "embedding")} generated" + (reused > 0 ? $", {reused} reused" : "");
            return Task.FromResult(store);
        });

        // 6. BuildingGraph.
        var graph = await StageAsync(id, run, IndexStages.BuildingGraph, ct, stage =>
        {
            var g = GraphBuilder.Build(repository, files, code is { Symbols.Count: > 0 } ? code : null, pages, p => SafeRead(repository.Path, p));
            stage.Detail = $"{g.Nodes.Count} nodes, {g.Edges.Count} edges";
            return Task.FromResult(g);
        });

        // 7. AnalyzingOkf.
        var okf = await StageAsync(id, run, IndexStages.AnalyzingOkf, ct, stage =>
        {
            var entities = OkfAnalyzer.Analyze(code, files, p => SafeRead(repository.Path, p));
            stage.Detail = $"{entities.Count} OKF entities";
            return Task.FromResult(entities);
        });

        // 8. DescribingGraph.
        await StageAsync(id, run, IndexStages.DescribingGraph, ct, async stage =>
        {
            DescribeFromIndex(graph, code, p => SafeReadLines(repository.Path, p));
            var status = await _models.GetStatusAsync(ct);
            var settings = _models is ModelGateway gateway ? await gateway.GetExplorerSettingsAsync(ct) : new ExplorerSettings();
            if (!status.Configured || !settings.DescribeGraphWithModel)
            {
                stage.Detail = status.Configured ? "described from the index (model descriptions turned off)" : "no model configured";
                return 0;
            }
            try
            {
                var described = await DescribeWithModelAsync(repository, graph, chunks, ct);
                stage.Detail = $"{TextUtil.Plural(described, "concept")} described by {status.DisplayName}";
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                stage.Detail = "model unavailable (" + TextUtil.Truncate(ex.Message, 80) + "); described from the index";
            }
            return 0;
        });

        // 9. Finalizing.
        var finalIndex = await StageAsync(id, run, IndexStages.Finalizing, ct, async stage =>
        {
            var generated = DocumentationBuilder.Generate(repository.Title, files, code is { Symbols.Count: > 0 } ? code : null, okf, pages, p => SafeReadLines(repository.Path, p));
            _store.DeleteDirectory(Rel(id, "pages"));
            foreach (var page in generated)
            {
                await _store.WriteTextAsync(Rel(id, $"pages/{page.Page.Id}.md"), page.Markdown, CancellationToken.None);
            }
            var allPages = pages.Concat(generated.Select(g => g.Page)).ToList();

            ct.ThrowIfCancellationRequested();
            await _store.WriteLargeAsync(Rel(id, "files.json"), files, CancellationToken.None);
            await _store.WriteLargeAsync(Rel(id, "pages.json"), allPages, CancellationToken.None);
            await _store.WriteLargeAsync(Rel(id, "chunks.json"), chunks, CancellationToken.None);
            await _store.WriteBytesAsync(Rel(id, "vectors.bin"), vectors.Serialize(), CancellationToken.None);
            await _store.WriteLargeAsync(Rel(id, "graph.json"), graph, CancellationToken.None);
            await _store.WriteLargeAsync(Rel(id, "okf.json"), okf, CancellationToken.None);

            var counters = new IndexCounters
            {
                Files = files.Count,
                DocumentationFiles = files.Count(f => f.Kind == FileKind.Documentation),
                SourceFiles = files.Count(f => f.Kind == FileKind.Source),
                Chunks = chunks.Count,
                Embeddings = vectors.Count,
                GraphNodes = graph.Nodes.Count,
                GraphEdges = graph.Edges.Count,
                OkfEntities = okf.Count,
                Symbols = code?.Symbols.Count ?? 0,
            };
            repository.Counters = counters;
            stage.Detail = $"index updated · {TextUtil.Plural(generated.Count, "reference page")} written";
            return new RepositoryIndex
            {
                Repository = repository,
                Files = files,
                Pages = allPages,
                Chunks = chunks,
                Vectors = vectors,
                Graph = graph,
                Okf = okf,
                Code = code,
                LastRun = run,
            };
        });
        return finalIndex;
    }

    private static string? SafeRead(string root, string relative)
    {
        try
        {
            return FileScanner.ReadText(root, relative);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return null;
        }
    }

    private static string[]? SafeReadLines(string root, string relative) => SafeRead(root, relative) is { } text ? TextUtil.SplitLines(text) : null;

    /// <summary>One-line descriptions written from the index: kind, namespace, XML summary, members and relations.</summary>
    internal static void DescribeFromIndex(KnowledgeGraph graph, CodeIndex? code, Func<string, string[]?> readLines)
    {
        var cache = new Dictionary<string, string[]?>(StringComparer.OrdinalIgnoreCase);
        foreach (var node in graph.Nodes)
        {
            switch (node.Type)
            {
                case ConceptTypes.Repository:
                    node.Description = $"The repository: {graph.Nodes.Count(n => n.Type == ConceptTypes.File)} source files, {graph.Nodes.Count(n => ConceptTypes.IsType(n.Type))} types.";
                    break;
                case ConceptTypes.Project when code is not null && node.Key is not null && code.Projects.TryGetValue(node.Key, out var project):
                    node.Description = (project.IsTestProject ? "Test project" : project.OutputType is { } output ? $"{output} project" : "Project") +
                                       (project.TargetFrameworks.Count > 0 ? $" targeting {string.Join(", ", project.TargetFrameworks)}" : "") +
                                       (project.ProjectReferences.Count > 0 ? $"; references {string.Join(", ", project.ProjectReferences.Select(r => Path.GetFileNameWithoutExtension(r)))}" : "") + ".";
                    break;
                case ConceptTypes.Namespace:
                    node.Description = $"Namespace with {TextUtil.Plural(graph.Edges.Count(e => e.From == node.Id && e.Kind == EdgeKinds.Contains), "type")}.";
                    break;
                case var t when ConceptTypes.IsType(t) && code is not null && node.Key is not null:
                    var symbol = code.Resolve(node.Key, "type").FirstOrDefault();
                    if (symbol is null)
                    {
                        break;
                    }
                    var lines = cache.TryGetValue(symbol.File, out var l) ? l : cache[symbol.File] = readLines(symbol.File);
                    var summary = lines is null ? null : DocumentationBuilder.XmlDocSummary(lines, symbol.StartLine);
                    var members = code.MembersOf(symbol.FullName).Count(m => !SymbolKinds.IsType(m.Kind));
                    node.Description = summary is { Length: > 0 }
                        ? summary
                        : $"{CodeIndexHelpers.KindLabel(symbol.Kind)} in {(symbol.Namespace.Length > 0 ? symbol.Namespace : "the global namespace")} with {TextUtil.Plural(members, "member")}" +
                          (symbol.Bases.Count > 0 ? $"; derives from {string.Join(", ", symbol.Bases)}" : "") + ".";
                    break;
                case ConceptTypes.File:
                    node.Description = $"Source file {node.Path}.";
                    break;
                case ConceptTypes.MarkdownFile:
                    node.Description = $"Markdown file {node.Path}.";
                    break;
                case ConceptTypes.DocumentationPage:
                    node.Description = $"Documentation page from {node.Path}.";
                    break;
            }
        }
    }

    private async Task<int> DescribeWithModelAsync(RepositoryRecord repository, KnowledgeGraph graph, List<Chunk> chunks, CancellationToken ct)
    {
        var degree = graph.Nodes.ToDictionary(n => n.Id, n => 0, StringComparer.Ordinal);
        foreach (var edge in graph.Edges)
        {
            degree[edge.From]++;
            degree[edge.To]++;
        }
        var targets = graph.Nodes.Where(n => ConceptTypes.IsType(n.Type)).OrderByDescending(n => degree[n.Id]).ThenBy(n => n.Id, StringComparer.Ordinal).Take(24).ToList();
        if (targets.Count == 0)
        {
            return 0;
        }
        var prompt = new StringBuilder();
        prompt.AppendLine($"Repository: {repository.Title}. For each concept below write ONE sentence (max 25 words) saying what it is responsible for, based only on the code shown.");
        prompt.AppendLine("Answer with one line per concept, exactly in the form `Name: sentence`. No other text.").AppendLine();
        foreach (var node in targets)
        {
            var chunk = chunks.FirstOrDefault(c => c.Symbol == node.Key) ?? chunks.FirstOrDefault(c => c.Path == node.Path);
            prompt.AppendLine($"## {node.Label} ({node.Type}, {node.Path})");
            if (chunk is not null)
            {
                prompt.AppendLine("```").AppendLine(TextUtil.Truncate(chunk.Text, 1200)).AppendLine("```");
            }
        }
        using var purpose = UsagePurpose.Set($"Describe {targets.Count} graph concepts of {repository.Title} while indexing");
        var result = await _models.CompleteAsync("describe-graph", repository.Id,
            [ModelMessage.System("You describe source code concisely and only from the evidence given. " + Ai.PlainLanguage.Short), ModelMessage.User(prompt.ToString())], 1500, ct);
        var count = 0;
        foreach (var line in result.Text.Split('\n'))
        {
            var colon = line.IndexOf(':');
            if (colon <= 0)
            {
                continue;
            }
            var name = line[..colon].Trim().Trim('*', '`', '-', ' ');
            var sentence = line[(colon + 1)..].Trim();
            var node = targets.FirstOrDefault(n => string.Equals(n.Label, name, StringComparison.Ordinal));
            if (node is not null && sentence.Length > 0)
            {
                node.Description = TextUtil.Truncate(sentence, 300);
                count++;
            }
        }
        return count;
    }

    /// <summary>The loaded index of a repository (from memory or disk); null when it was never indexed.</summary>
    public async Task<RepositoryIndex?> GetAsync(string repositoryId, CancellationToken ct = default)
    {
        if (_loaded.TryGetValue(repositoryId, out var loaded))
        {
            return loaded;
        }
        await _loadGate.WaitAsync(ct);
        try
        {
            if (_loaded.TryGetValue(repositoryId, out loaded))
            {
                return loaded;
            }
            var repository = await _repositories.GetAsync(repositoryId, ct);
            if (repository is null)
            {
                return null;
            }
            var files = await _store.ReadLargeAsync<List<ScannedFile>>(Rel(repositoryId, "files.json"), ct);
            if (files is null)
            {
                return null;
            }
            CodeIndex? code = null;
            if (files.Any(f => f.Language is "csharp" or "msbuild" or "solution") && Directory.Exists(repository.Path))
            {
                var handle = new RepositoryHandle { Name = repository.Title, Root = repository.Path, Source = "registered", IndexKey = repositoryId };
                try
                {
                    // Load what is on disk; refreshing waits for an explicit index run.
                    code = await _codeIndex.GetAsync(handle, ct, TimeSpan.FromDays(3650));
                }
                catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
                {
                    code = null;
                }
            }
            var index = new RepositoryIndex
            {
                Repository = repository,
                Files = files,
                Pages = await _store.ReadLargeAsync<List<DocPage>>(Rel(repositoryId, "pages.json"), ct) ?? [],
                Chunks = await _store.ReadLargeAsync<List<Chunk>>(Rel(repositoryId, "chunks.json"), ct) ?? [],
                Vectors = VectorStore.Deserialize(await _store.ReadBytesAsync(Rel(repositoryId, "vectors.bin"), ct)),
                Graph = await _store.ReadLargeAsync<KnowledgeGraph>(Rel(repositoryId, "graph.json"), ct) ?? new KnowledgeGraph(),
                Okf = await _store.ReadLargeAsync<List<OkfEntity>>(Rel(repositoryId, "okf.json"), ct) ?? [],
                LastRun = await _store.ReadLargeAsync<IndexRun>(Rel(repositoryId, "run.json"), ct),
                Code = code,
            };
            _loaded[repositoryId] = index;
            return index;
        }
        finally
        {
            _loadGate.Release();
        }
    }

    /// <summary>Markdown of a page: the repository file for Markdown pages, the stored text for generated ones.</summary>
    public async Task<string?> ReadPageMarkdownAsync(RepositoryIndex index, DocPage page, CancellationToken ct = default)
    {
        if (page.SourcePath is not null)
        {
            return index.ReadText(page.SourcePath);
        }
        return await _store.ReadTextAsync(Rel(index.Repository.Id, $"pages/{page.Id}.md"), ct);
    }

    /// <summary>Removes the index, leaving the repository (and its conversations and learning material) registered.</summary>
    public async Task ClearAsync(string repositoryId, CancellationToken ct = default)
    {
        if (IsRunning(repositoryId))
        {
            throw new ExplorerValidationException("Cancel the running index first.");
        }
        _loaded.TryRemove(repositoryId, out _);
        var repository = await _repositories.GetAsync(repositoryId, ct);
        if (repository is not null)
        {
            _codeIndex.Invalidate(new RepositoryHandle { Name = repository.Title, Root = repository.Path, Source = "registered", IndexKey = repositoryId });
        }
        foreach (var file in new[] { "files.json", "pages.json", "chunks.json", "vectors.bin", "graph.json", "okf.json", "run.json" })
        {
            _store.Delete(Rel(repositoryId, file));
        }
        _store.DeleteDirectory(Rel(repositoryId, "pages"));
        _store.DeleteDirectory($"analysis/indexes/{repositoryId}");
        await _repositories.UpdateAsync(repositoryId, r =>
        {
            r.Status = RepositoryStatus.NotIndexed;
            r.Counters = new IndexCounters();
            r.LastIndexedAt = null;
            r.Error = null;
        }, ct);
    }

    /// <summary>Forgets the in-memory copy (after removal).</summary>
    public void Forget(string repositoryId) => _loaded.TryRemove(repositoryId, out _);

    /// <summary>Marks repositories left "Indexing" by a crash as not indexed (or indexed, when an index exists).</summary>
    public async Task RecoverInterruptedAsync(CancellationToken ct = default)
    {
        foreach (var repository in (await _repositories.ListAsync(ct)).Where(r => r.Status == RepositoryStatus.Indexing && !IsRunning(r.Id)))
        {
            var hasIndex = _store.Exists(Rel(repository.Id, "files.json"));
            await _repositories.UpdateAsync(repository.Id, r => r.Status = hasIndex ? RepositoryStatus.Indexed : RepositoryStatus.NotIndexed, ct);
        }
    }
}

/// <summary>A fixed options value for the platform services that expect an <see cref="IOptionsMonitor{T}"/>.</summary>
public sealed class StaticOptionsMonitor<T>(T value) : IOptionsMonitor<T>
{
    public T CurrentValue => value;

    public T Get(string? name) => value;

    public IDisposable? OnChange(Action<T, string?> listener) => null;
}
