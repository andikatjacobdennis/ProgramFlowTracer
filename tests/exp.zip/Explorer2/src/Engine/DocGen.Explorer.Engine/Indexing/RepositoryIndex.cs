using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Search;
using DocGen.Analysis.Indexing;

namespace DocGen.Explorer.Engine.Indexing;

/// <summary>Everything the explorer knows about one indexed repository, loaded in memory.</summary>
public sealed class RepositoryIndex
{
    private KeywordIndex? _keywords;
    private Dictionary<string, Chunk>? _chunksById;
    private Dictionary<string, List<Chunk>>? _chunksByPath;
    private Dictionary<string, ScannedFile>? _filesByPath;

    public required RepositoryRecord Repository { get; init; }
    public List<ScannedFile> Files { get; init; } = [];
    public List<DocPage> Pages { get; init; } = [];
    public List<Chunk> Chunks { get; init; } = [];
    public VectorStore Vectors { get; init; } = new();
    public KnowledgeGraph Graph { get; init; } = new();
    public List<OkfEntity> Okf { get; init; } = [];
    public IndexRun? LastRun { get; init; }

    /// <summary>The code index (C# symbols, projects, DI, configuration, endpoints); null when not built.</summary>
    public CodeIndex? Code { get; init; }

    public string Root => Repository.Path;

    // Built on first use, once, even when the assistant and a page ask at the same moment.
    private readonly object _gate = new();

    private T Once<T>(ref T? field, Func<T> build) where T : class
    {
        if (Volatile.Read(ref field) is { } built)
        {
            return built;
        }
        lock (_gate)
        {
            return field ??= build();
        }
    }

    public KeywordIndex Keywords => Once(ref _keywords, () => KeywordIndex.Build(Chunks));

    public Dictionary<string, Chunk> ChunksById => Once(ref _chunksById,
        () => Chunks.GroupBy(c => c.Id).ToDictionary(g => g.Key, g => g.First(), StringComparer.Ordinal));

    public Dictionary<string, List<Chunk>> ChunksByPath => Once(ref _chunksByPath,
        () => Chunks.GroupBy(c => c.Path, StringComparer.OrdinalIgnoreCase).ToDictionary(g => g.Key, g => g.OrderBy(c => c.StartLine).ToList(), StringComparer.OrdinalIgnoreCase));

    public Dictionary<string, ScannedFile> FilesByPath => Once(ref _filesByPath,
        () => Files.ToDictionary(f => f.Path, StringComparer.OrdinalIgnoreCase));

    /// <summary>Whether the keyword index is built (the first search after loading builds it otherwise).</summary>
    public bool IsSearchReady => Volatile.Read(ref _keywords) is not null;

    /// <summary>Builds the lookups pages need (quick); the keyword index is built by <see cref="WarmSearch"/>.</summary>
    public void Warm()
    {
        _ = ChunksById;
        _ = ChunksByPath;
        _ = FilesByPath;
    }

    /// <summary>Builds the keyword index ahead of the first question (seconds on a large repository: call off the UI thread).</summary>
    public void WarmSearch() => _ = Keywords;

    public ScannedFile? FindFile(string path) => FilesByPath.GetValueOrDefault(path.Replace('\\', '/'));

    public DocPage? FindPage(string id) => Pages.FirstOrDefault(p => p.Id == id);

    /// <summary>
    /// The pages the Docs list shows (and "All documentation" exports): the repository's own pages; the generated
    /// reference pages (Overview, Architecture, API, Operations) only when the repository has no Markdown of its own.
    /// </summary>
    public IEnumerable<DocPage> ShownPages()
    {
        var own = Pages.Any(p => !p.Generated);
        return Pages.Where(p => !own || !p.Generated);
    }

    public DocPage? PageForSource(string path) => Pages.FirstOrDefault(p => string.Equals(p.SourcePath, path, StringComparison.OrdinalIgnoreCase));

    /// <summary>Reads a repository file (UTF-8, falling back to Latin-1); null when it is missing or outside the root.</summary>
    public string? ReadText(string relativePath)
    {
        try
        {
            var full = FileScanner.SafeResolve(Root, relativePath);
            return File.Exists(full) ? FileScanner.DecodeText(File.ReadAllBytes(full)) : null;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException)
        {
            return null;
        }
    }

    public string[]? ReadLines(string relativePath) => ReadText(relativePath) is { } text ? Text.TextUtil.SplitLines(text) : null;

    /// <summary>True when the path lies in one of the scope entries (folders end without a slash; files match exactly).</summary>
    public static bool InScope(string path, IReadOnlyCollection<string>? scope)
    {
        if (scope is null || scope.Count == 0)
        {
            return true;
        }
        foreach (var entry in scope)
        {
            var e = entry.Replace('\\', '/').TrimEnd('/');
            if (e.Length == 0 || string.Equals(path, e, StringComparison.OrdinalIgnoreCase) || path.StartsWith(e + "/", StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
        }
        return false;
    }
}
