using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Markdown;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;
using DocGen.Analysis.Indexing;

namespace DocGen.Explorer.Engine.Documentation;

/// <summary>A generated page and its Markdown.</summary>
public sealed record GeneratedPage(DocPage Page, string Markdown);

/// <summary>
/// Builds the documentation: one page per Markdown file of the repository, plus reference pages generated from the code
/// index (Overview, Architecture and an API page per project). Links use two schemes the viewer understands:
/// <c>repo:path#L12</c> opens a file at a line and <c>page:id#anchor</c> opens a page.
/// </summary>
public static partial class DocumentationBuilder
{
    public const string ReferenceFolder = "Reference";

    public static DocPage PageForMarkdown(ScannedFile file, string text)
    {
        var document = MarkdownDocument.Parse(text);
        var headings = document.Headings.ToList();
        var firstH1 = headings.FirstOrDefault(h => h.Level == 1);
        var fileTitle = TextUtil.Humanize(Path.GetFileNameWithoutExtension(file.Path));
        var title = firstH1?.Text is { Length: > 0 } h1 ? h1 : fileTitle;
        var folder = Path.GetDirectoryName(file.Path)?.Replace('\\', '/') ?? "";
        var leaf = Path.GetFileNameWithoutExtension(file.Path).Equals("README", StringComparison.OrdinalIgnoreCase) && folder.Length == 0
            ? title
            : fileTitle;
        return new DocPage
        {
            Id = PageId(file.Path),
            Title = title,
            TreePath = folder.Length == 0 ? leaf : $"{folder}/{leaf}",
            SourcePath = file.Path,
            Generated = false,
            Headings = headings.Where(h => h.Level >= 2 || h != firstH1).Select(h => new Heading { Level = h.Level, Text = h.Text, Anchor = h.Anchor, Line = h.Line }).ToList(),
        };
    }

    public static string PageId(string path)
    {
        var withoutExtension = Path.ChangeExtension(path, null)!.Replace('\\', '/');
        return TextUtil.Slug(withoutExtension, 120);
    }

    public static DocPage PageFromMarkdown(string id, string title, string treePath, string markdown)
    {
        var headings = MarkdownDocument.Parse(markdown).Headings.Where(h => h.Level >= 2)
            .Select(h => new Heading { Level = h.Level, Text = h.Text, Anchor = h.Anchor, Line = h.Line }).ToList();
        return new DocPage { Id = id, Title = title, TreePath = treePath, Generated = true, Headings = headings };
    }

    /// <summary>Reference pages generated from the index. Always returns at least the Overview.</summary>
    public static List<GeneratedPage> Generate(string repositoryName, IReadOnlyList<ScannedFile> files, CodeIndex? code, IReadOnlyList<OkfEntity> okf,
        IReadOnlyList<DocPage> markdownPages, Func<string, string[]?> readLines)
    {
        var pages = new List<GeneratedPage>();
        var overview = Overview(repositoryName, files, code, markdownPages, okf);
        pages.Add(new GeneratedPage(PageFromMarkdown("reference-overview", "Overview", $"{ReferenceFolder}/Overview", overview), overview));
        if (code is not null && code.Symbols.Count > 0)
        {
            var architecture = Architecture(repositoryName, code, okf);
            pages.Add(new GeneratedPage(PageFromMarkdown("reference-architecture", "Architecture", $"{ReferenceFolder}/Architecture", architecture), architecture));
            foreach (var group in code.Types.GroupBy(t => string.IsNullOrEmpty(t.Project) ? "(no project)" : t.Project).OrderBy(g => g.Key, StringComparer.OrdinalIgnoreCase))
            {
                var types = group.ToList();
                var id = "reference-api-" + TextUtil.Slug(group.Key, 80);
                if (types.Count <= MaxTypesPerPage)
                {
                    var markdown = ApiPage($"API: {group.Key}", group.Key, types, code, readLines);
                    pages.Add(new GeneratedPage(PageFromMarkdown(id, $"API: {group.Key}", $"{ReferenceFolder}/API/{group.Key}", markdown), markdown));
                    continue;
                }
                // A large project gets an index page and one page per namespace (in parts of MaxTypesPerPage types), so
                // no single page is too big to read — or to lay out.
                var parts = new List<(string Id, string Title, int Count)>();
                foreach (var ns in types.GroupBy(t => string.IsNullOrEmpty(t.Namespace) ? "(global)" : t.Namespace).OrderBy(g => g.Key, StringComparer.Ordinal))
                {
                    var chunks = ns.OrderBy(t => t.FullName, StringComparer.Ordinal).Chunk(MaxTypesPerPage).ToList();
                    for (var c = 0; c < chunks.Count; c++)
                    {
                        var suffix = chunks.Count > 1 ? $" ({c + 1} of {chunks.Count})" : "";
                        var title = $"{ns.Key}{suffix}";
                        var partId = id + "-" + TextUtil.Slug(ns.Key + (chunks.Count > 1 ? "-" + (c + 1) : ""), 100);
                        var markdown = ApiPage($"API: {title}", group.Key, chunks[c].ToList(), code, readLines);
                        pages.Add(new GeneratedPage(PageFromMarkdown(partId, $"API: {title}", $"{ReferenceFolder}/API/{group.Key}/{title}", markdown), markdown));
                        parts.Add((partId, title, chunks[c].Length));
                    }
                }
                var index = new StringBuilder();
                index.AppendLine($"# API: {group.Key}").AppendLine();
                index.AppendLine($"{TextUtil.Plural(types.Count, "type")} in {TextUtil.Plural(parts.Count, "page")}, one per namespace:").AppendLine();
                foreach (var (partId, title, count) in parts)
                {
                    index.AppendLine($"- [{title}](page:{partId}) — {TextUtil.Plural(count, "type")}");
                }
                var indexMarkdown = index.ToString();
                pages.Add(new GeneratedPage(PageFromMarkdown(id, $"API: {group.Key}", $"{ReferenceFolder}/API/{group.Key}/Index", indexMarkdown), indexMarkdown));
            }
        }
        if (okf.Count > 0)
        {
            var configuration = ConfigurationPage(okf);
            pages.Add(new GeneratedPage(PageFromMarkdown("reference-operations", "Operations", $"{ReferenceFolder}/Operations", configuration), configuration));
        }
        return pages;
    }

    private static string Overview(string repositoryName, IReadOnlyList<ScannedFile> files, CodeIndex? code, IReadOnlyList<DocPage> pages, IReadOnlyList<OkfEntity> okf)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"# {repositoryName}").AppendLine();
        var source = files.Count(f => f.Kind == FileKind.Source);
        var docs = files.Count(f => f.Kind == FileKind.Documentation);
        var lines = files.Sum(f => (long)f.Lines);
        sb.AppendLine($"This page was generated from the repository's index: {TextUtil.Plural(files.Count, "file")} " +
                      $"({TextUtil.Plural(source, "source file")}, {TextUtil.Plural(docs, "documentation file")}), " +
                      $"{lines.ToString("N0", CultureInfo.InvariantCulture)} lines in all.").AppendLine();

        sb.AppendLine("## At a glance").AppendLine();
        sb.AppendLine("| Measure | Value |").AppendLine("|---|---:|");
        sb.AppendLine($"| Files | {files.Count:N0} |");
        sb.AppendLine($"| Source files | {source:N0} |");
        sb.AppendLine($"| Documentation files | {docs:N0} |");
        if (code is not null)
        {
            sb.AppendLine($"| Projects | {code.Manifest.Projects.Count:N0} |");
            sb.AppendLine($"| Types | {code.Types.Count():N0} |");
            sb.AppendLine($"| Members | {code.Symbols.Count(s => !SymbolKinds.IsType(s.Kind)):N0} |");
            sb.AppendLine($"| Tests | {code.TestMethods.Count():N0} |");
        }
        sb.AppendLine($"| Operational facts | {okf.Count:N0} |").AppendLine();

        sb.AppendLine("## Languages").AppendLine();
        sb.AppendLine("| Language | Files | Lines |").AppendLine("|---|---:|---:|");
        foreach (var group in files.GroupBy(f => f.Language).OrderByDescending(g => g.Sum(f => (long)f.Lines)).Take(15))
        {
            sb.AppendLine($"| {group.Key} | {group.Count():N0} | {group.Sum(f => (long)f.Lines):N0} |");
        }
        sb.AppendLine();

        var folders = files.Select(f => f.Path.Contains('/') ? f.Path[..f.Path.IndexOf('/')] : "(root)").GroupBy(f => f).OrderByDescending(g => g.Count()).Take(20).ToList();
        if (folders.Count > 1)
        {
            sb.AppendLine("## Top-level folders").AppendLine();
            foreach (var folder in folders)
            {
                sb.AppendLine($"- `{folder.Key}` — {TextUtil.Plural(folder.Count(), "file")}");
            }
            sb.AppendLine();
        }

        if (code is not null && code.Manifest.Projects.Count > 0)
        {
            sb.AppendLine("## Projects").AppendLine();
            sb.AppendLine("| Project | Kind | Framework | References |").AppendLine("|---|---|---|---|");
            foreach (var project in code.Manifest.Projects)
            {
                var kind = project.IsTestProject ? "Tests" : project.OutputType ?? (project.Sdk?.Contains("Web", StringComparison.OrdinalIgnoreCase) == true ? "Web" : "Library");
                var references = project.ProjectReferences.Count == 0 ? "—" : string.Join(", ", project.ProjectReferences.Select(Path.GetFileNameWithoutExtension));
                sb.AppendLine($"| [{project.Name}](repo:{project.Path}) | {kind} | {string.Join(", ", project.TargetFrameworks)} | {references} |");
            }
            sb.AppendLine();
        }

        var entryPoints = okf.Where(o => o.Kind == "entrypoint").ToList();
        if (entryPoints.Count > 0)
        {
            sb.AppendLine("## Entry points").AppendLine();
            foreach (var entry in entryPoints.Take(20))
            {
                sb.AppendLine($"- [{entry.Name}](repo:{entry.Path}#L{entry.Line}) — {entry.Detail}");
            }
            sb.AppendLine();
        }

        if (pages.Count > 0)
        {
            sb.AppendLine("## Documentation in the repository").AppendLine();
            foreach (var page in pages.OrderBy(p => p.TreePath, StringComparer.OrdinalIgnoreCase))
            {
                sb.AppendLine($"- [{page.Title}](page:{page.Id}) — `{page.SourcePath}`");
            }
            sb.AppendLine();
        }

        if (code is not null)
        {
            var central = code.Types
                .Select(t => (Type: t, Users: code.UsersByName(t.Name).Select(u => u.File).Concat(code.CallersByName(t.Name).Select(c => c.File)).Where(f => f != t.File).Distinct().Count()))
                .Where(x => x.Users > 0)
                .OrderByDescending(x => x.Users).ThenBy(x => x.Type.Name, StringComparer.Ordinal).Take(12).ToList();
            if (central.Count > 0)
            {
                sb.AppendLine("## Most referenced types").AppendLine();
                sb.AppendLine("The types other files lean on most — a good place to start reading.").AppendLine();
                foreach (var (type, users) in central)
                {
                    sb.AppendLine($"- [{type.Name}](repo:{type.File}#L{type.StartLine}) ({type.Kind}) — referenced from {TextUtil.Plural(users, "other file")}");
                }
                sb.AppendLine();
            }
        }
        return sb.ToString();
    }

    private static string Architecture(string repositoryName, CodeIndex code, IReadOnlyList<OkfEntity> okf)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"# Architecture of {repositoryName}").AppendLine();
        sb.AppendLine("How the projects and namespaces fit together, from the code index. Every name links to its declaration.").AppendLine();

        if (code.Manifest.Projects.Count > 0)
        {
            sb.AppendLine("## Project dependencies").AppendLine();
            sb.AppendLine("```mermaid").AppendLine("graph LR");
            foreach (var project in code.Manifest.Projects)
            {
                sb.AppendLine($"  {MermaidId(project.Name)}[\"{project.Name}\"]");
                foreach (var reference in project.ProjectReferences)
                {
                    sb.AppendLine($"  {MermaidId(project.Name)} --> {MermaidId(Path.GetFileNameWithoutExtension(reference))}");
                }
            }
            sb.AppendLine("```").AppendLine();
            foreach (var project in code.Manifest.Projects)
            {
                var dependents = code.Manifest.Projects.Where(p => p.ProjectReferences.Any(r => Path.GetFileNameWithoutExtension(r).Equals(project.Name, StringComparison.OrdinalIgnoreCase))).Select(p => p.Name).ToList();
                sb.Append($"- **{project.Name}**");
                sb.Append(project.ProjectReferences.Count > 0 ? $" depends on {TextUtil.JoinNatural(project.ProjectReferences.Select(r => Path.GetFileNameWithoutExtension(r)!))}" : " depends on no other project");
                sb.Append(dependents.Count > 0 ? $"; used by {TextUtil.JoinNatural(dependents)}." : ".");
                if (project.Packages.Count > 0)
                {
                    sb.Append($" Packages: {string.Join(", ", project.Packages.Take(12).Select(p => p.Version is null ? p.Id : $"{p.Id} {p.Version}"))}.");
                }
                sb.AppendLine();
            }
            sb.AppendLine();
        }

        sb.AppendLine("## Namespaces").AppendLine();
        foreach (var ns in code.Types.GroupBy(t => string.IsNullOrEmpty(t.Namespace) ? "(global)" : t.Namespace).OrderBy(g => g.Key, StringComparer.Ordinal).Take(200))
        {
            var types = ns.OrderBy(t => t.Name, StringComparer.Ordinal).ToList();
            sb.AppendLine($"### {ns.Key}").AppendLine();
            sb.AppendLine(string.Join(", ", types.Take(60).Select(t => $"[{t.Name}](repo:{t.File}#L{t.StartLine})")) + (types.Count > 60 ? $" and {types.Count - 60} more" : "") + ".").AppendLine();
        }

        var hierarchies = code.Types.Where(t => t.Bases.Count > 0).OrderBy(t => t.FullName, StringComparer.Ordinal).Take(150).ToList();
        if (hierarchies.Count > 0)
        {
            sb.AppendLine("## Inheritance and implementation").AppendLine();
            sb.AppendLine("| Type | Derives from / implements |").AppendLine("|---|---|");
            foreach (var type in hierarchies)
            {
                sb.AppendLine($"| [{type.Name}](repo:{type.File}#L{type.StartLine}) | {string.Join(", ", type.Bases.Select(b => $"`{b}`"))} |");
            }
            sb.AppendLine();
        }

        var services = okf.Where(o => o.Kind == "service").ToList();
        if (services.Count > 0)
        {
            sb.AppendLine("## Service registrations").AppendLine();
            sb.AppendLine("| Service | Implementation | Where |").AppendLine("|---|---|---|");
            foreach (var service in services.Take(200))
            {
                sb.AppendLine($"| `{service.Name}` | {service.Detail} | [{Path.GetFileName(service.Path)}:{service.Line}](repo:{service.Path}#L{service.Line}) |");
            }
            sb.AppendLine();
        }

        var endpoints = okf.Where(o => o.Kind == "endpoint").ToList();
        if (endpoints.Count > 0)
        {
            sb.AppendLine("## HTTP endpoints").AppendLine();
            sb.AppendLine("| Route | Handler | Where |").AppendLine("|---|---|---|");
            foreach (var endpoint in endpoints.Take(300))
            {
                sb.AppendLine($"| `{endpoint.Name}` | {endpoint.Detail} | [{Path.GetFileName(endpoint.Path)}:{endpoint.Line}](repo:{endpoint.Path}#L{endpoint.Line}) |");
            }
            sb.AppendLine();
        }

        var tests = code.TestMethods.ToList();
        if (tests.Count > 0)
        {
            sb.AppendLine("## Tests").AppendLine();
            foreach (var group in tests.GroupBy(t => t.Container ?? "").OrderBy(g => g.Key, StringComparer.Ordinal).Take(80))
            {
                var first = group.First();
                sb.AppendLine($"- [{CodeIndexHelpers.ShortName(group.Key)}](repo:{first.File}#L{first.StartLine}) — {TextUtil.Plural(group.Count(), "test")}");
            }
            sb.AppendLine();
        }
        return sb.ToString();
    }

    /// <summary>Types per generated API page; larger projects are split by namespace.</summary>
    public const int MaxTypesPerPage = 40;

    /// <summary>Rows per table on the Operations page.</summary>
    public const int MaxRowsPerTable = 150;

    private static string ApiPage(string heading, string project, List<SymbolRecord> types, CodeIndex code, Func<string, string[]?> readLines)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"# {heading}").AppendLine();
        var info = code.Projects.GetValueOrDefault(project);
        if (info is not null)
        {
            sb.AppendLine($"Project file: [{info.Path}](repo:{info.Path}). " +
                          (info.TargetFrameworks.Count > 0 ? $"Targets {string.Join(", ", info.TargetFrameworks)}. " : "") +
                          $"{TextUtil.Plural(types.Count, "type")}.").AppendLine();
        }
        var cache = new Dictionary<string, string[]?>(StringComparer.OrdinalIgnoreCase);
        string[]? Lines(string file) => cache.TryGetValue(file, out var l) ? l : cache[file] = readLines(file);

        foreach (var ns in types.GroupBy(t => string.IsNullOrEmpty(t.Namespace) ? "(global)" : t.Namespace).OrderBy(g => g.Key, StringComparer.Ordinal))
        {
            sb.AppendLine($"## {ns.Key}").AppendLine();
            foreach (var type in ns.OrderBy(t => t.FullName, StringComparer.Ordinal).Take(400))
            {
                sb.AppendLine($"### {type.Name}").AppendLine();
                var modifiers = type.Modifiers.Count > 0 ? string.Join(" ", type.Modifiers) + " " : "";
                sb.AppendLine($"`{modifiers}{type.Kind} {type.Name}`" + (type.Bases.Count > 0 ? $" : {string.Join(", ", type.Bases.Select(b => $"`{b}`"))}" : "") +
                              $" — [{type.File}:{type.StartLine}](repo:{type.File}#L{type.StartLine})").AppendLine();
                var summary = Lines(type.File) is { } fileLines ? XmlDocSummary(fileLines, type.StartLine) : null;
                if (!string.IsNullOrWhiteSpace(summary))
                {
                    sb.AppendLine(summary).AppendLine();
                }
                var members = code.MembersOf(type.FullName).Where(m => !SymbolKinds.IsType(m.Kind)).OrderBy(m => m.StartLine).Take(150).ToList();
                if (members.Count > 0)
                {
                    sb.AppendLine("| Member | Kind | Description |").AppendLine("|---|---|---|");
                    foreach (var member in members)
                    {
                        var memberSummary = Lines(member.File) is { } ml ? XmlDocSummary(ml, member.StartLine) : null;
                        var signature = string.IsNullOrWhiteSpace(member.Signature) ? member.Name : member.Signature;
                        sb.AppendLine($"| [`{EscapeCell(TextUtil.Truncate(signature, 110))}`](repo:{member.File}#L{member.StartLine}) | {member.Kind} | {EscapeCell(memberSummary ?? "")} |");
                    }
                    sb.AppendLine();
                }
                var users = code.UsersByName(type.Name).Concat(code.CallersByName(type.Name)).Select(u => u.Container ?? u.FullName)
                    .Where(c => c is not null && !c.StartsWith(type.FullName, StringComparison.Ordinal)).Select(CodeIndexHelpers.ShortName).Distinct().Take(12).ToList();
                if (users.Count > 0)
                {
                    sb.AppendLine($"Used by {TextUtil.JoinNatural(users.Select(u => $"`{u}`"))}.").AppendLine();
                }
            }
        }
        return sb.ToString();
    }

    private static string ConfigurationPage(IReadOnlyList<OkfEntity> okf)
    {
        var sb = new StringBuilder();
        sb.AppendLine("# Operations").AppendLine();
        sb.AppendLine("Configuration keys, endpoints, service registrations, middleware, packages and entry points found in the code.").AppendLine();
        foreach (var group in okf.GroupBy(o => o.Kind).OrderBy(g => g.Key, StringComparer.Ordinal))
        {
            sb.AppendLine($"## {KindTitle(group.Key)}").AppendLine();
            sb.AppendLine("| Name | Detail | Where |").AppendLine("|---|---|---|");
            foreach (var entity in group.OrderBy(e => e.Name, StringComparer.OrdinalIgnoreCase).Take(MaxRowsPerTable))
            {
                var where = entity.Path.Length == 0 ? "" : $"[{Path.GetFileName(entity.Path)}{(entity.Line > 0 ? ":" + entity.Line : "")}](repo:{entity.Path}{(entity.Line > 0 ? "#L" + entity.Line : "")})";
                sb.AppendLine($"| `{EscapeCell(entity.Name)}` | {EscapeCell(entity.Detail)} | {where} |");
            }
            if (group.Count() > MaxRowsPerTable)
            {
                sb.AppendLine().AppendLine($"… and {group.Count() - MaxRowsPerTable:N0} more; ask the assistant or search for a specific one.");
            }
            sb.AppendLine();
        }
        return sb.ToString();
    }

    private static string KindTitle(string kind) => kind switch
    {
        "config" => "Configuration",
        "endpoint" => "Endpoints",
        "service" => "Services",
        "middleware" => "Middleware",
        "package" => "Packages",
        "entrypoint" => "Entry points",
        _ => TextUtil.Humanize(kind),
    };

    private static string EscapeCell(string text) => text.Replace("|", "\\|", StringComparison.Ordinal).Replace("\n", " ", StringComparison.Ordinal).Replace("\r", "", StringComparison.Ordinal);

    private static string MermaidId(string name) => "p_" + TextUtil.Slug(name, 60).Replace('-', '_');

    /// <summary>The &lt;summary&gt; of the XML documentation comment directly above a 1-based line (attributes skipped).</summary>
    public static string? XmlDocSummary(string[] lines, int declarationLine)
    {
        var i = declarationLine - 2;
        while (i >= 0 && lines[i].Trim().StartsWith('[') && lines[i].Trim().EndsWith(']'))
        {
            i--;
        }
        var comment = new List<string>();
        while (i >= 0 && lines[i].TrimStart().StartsWith("///", StringComparison.Ordinal))
        {
            comment.Insert(0, lines[i].TrimStart()[3..].Trim());
            i--;
        }
        if (comment.Count == 0)
        {
            return null;
        }
        var xml = string.Join(" ", comment);
        var match = SummaryRegex().Match(xml);
        var text = match.Success ? match.Groups[1].Value : xml;
        text = SeeRegex().Replace(text, m => "`" + (m.Groups[2].Success && m.Groups[2].Value.Length > 0 ? m.Groups[2].Value : m.Groups[1].Value) + "`");
        text = TagRegex().Replace(text, "");
        text = System.Net.WebUtility.HtmlDecode(text);
        return SpaceRegex().Replace(text, " ").Trim();
    }

    [GeneratedRegex(@"<summary>(.*?)</summary>", RegexOptions.Singleline)]
    private static partial Regex SummaryRegex();

    [GeneratedRegex(@"<(?:see|seealso|paramref|typeparamref)\s+(?:cref|name|langword|href)=""(?:[A-Z]:)?([^""]+)""\s*(?:/>|>(.*?)</(?:see|seealso|paramref|typeparamref)>)")]
    private static partial Regex SeeRegex();

    [GeneratedRegex(@"<[^>]+>")]
    private static partial Regex TagRegex();

    [GeneratedRegex(@"\s+")]
    private static partial Regex SpaceRegex();
}

public static class CodeIndexHelpers
{
    /// <summary>"Ns.Outer.Inner" → "Outer.Inner" when the first segments are a namespace; otherwise the last two segments.</summary>
    public static string ShortName(string? fullName)
    {
        if (string.IsNullOrEmpty(fullName))
        {
            return "";
        }
        var parts = fullName.Split('.');
        return parts.Length <= 2 ? fullName : string.Join(".", parts[^2..]);
    }

    /// <summary>Maps a code-index symbol kind to a concept type for the graph and the search results.</summary>
    public static string ConceptType(SymbolRecord symbol) => symbol.Kind switch
    {
        _ when symbol.IsTest && SymbolKinds.IsType(symbol.Kind) => ConceptTypes.Test,
        SymbolKinds.Interface => ConceptTypes.Interface,
        SymbolKinds.Record => ConceptTypes.Record,
        SymbolKinds.Struct => ConceptTypes.Struct,
        SymbolKinds.Enum => ConceptTypes.Enum,
        _ => ConceptTypes.Class,
    };

    public static string KindLabel(string kind) => kind switch
    {
        SymbolKinds.EnumMember => "Enum member",
        SymbolKinds.TopLevel => "Top-level code",
        _ => kind.Length == 0 ? "" : char.ToUpperInvariant(kind[0]) + kind[1..],
    };
}
