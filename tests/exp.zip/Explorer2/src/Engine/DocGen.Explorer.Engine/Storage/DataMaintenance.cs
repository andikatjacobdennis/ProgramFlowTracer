using System.Text.Json;
using DocGen.Explorer.Engine.Indexing;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Repositories;

namespace DocGen.Explorer.Engine.Storage;

/// <summary>What Settings → Data and storage can remove.</summary>
public enum DataCategory
{
    /// <summary>Indexes, graphs, search data and generated documentation; the repositories stay, to be indexed again.</summary>
    Indexes,
    Conversations,
    StudioConversations,
    /// <summary>Test Fix runs: their commands, logs, patch records and the originals kept for undoing.</summary>
    TestFixRuns,
    Learning,
    Usage,
    Logs,
    /// <summary>Folders an earlier version of the explorer left in the data folder and nothing reads now.</summary>
    Leftovers,
}

/// <summary>A category with what it holds now.</summary>
public sealed record DataCategoryInfo(DataCategory Category, string Title, string Description, long Bytes, int Files);

/// <summary>What a removal did: what was freed, and what could not be deleted (in use).</summary>
public sealed record DataRemoval(long BytesFreed, int FilesDeleted, int FilesInUse);

/// <summary>
/// Removing data and the factory reset. Only names the explorer itself creates are ever touched — never other files in
/// the data folder, and never a registered repository's own folder.
/// </summary>
public sealed class DataMaintenance(ExplorerStore store, RepositoryService repositories, IndexingPipeline indexing)
{
    /// <summary>Written by <see cref="ScheduleFactoryReset"/>; the next start resets the folder before anything opens files in it.</summary>
    public const string ResetMarker = "factory-reset.pending";

    /// <summary>Everything the explorer creates at the top of its data folder (the factory reset deletes exactly these).</summary>
    public static readonly string[] ExplorerEntries =
    [
        "repositories.json", "repositories.json.bak", "repos", "analysis", "clones", "settings", "skills", "studio", "usage", "logs", "webview2",
        // Earlier versions:
        "state", "attachments", "repositories",
    ];

    private static readonly string[] LeftoverEntries = ["state", "attachments", "repositories"];

    /// <summary>The per-repository files that are not the index (kept when indexes are removed, removed by their own category).</summary>
    private static readonly string[] NotIndex = ["conversations", "talk", "studio", "testfix", "learning.json", "knowledge.json", "confluence.json"];

    public string Root => store.Root;

    public async Task<IReadOnlyList<DataCategoryInfo>> MeasureAsync(CancellationToken ct = default)
    {
        return await Task.Run(() => Enum.GetValues<DataCategory>().Select(c =>
        {
            var (bytes, files) = Measure(Paths(c));
            return new DataCategoryInfo(c, Title(c), Description(c), bytes, files);
        }).ToList(), ct);
    }

    public static string Title(DataCategory category) => category switch
    {
        DataCategory.Indexes => "Indexes and generated documentation",
        DataCategory.Conversations => "Ask and Talk conversations",
        DataCategory.StudioConversations => "Studio conversations",
        DataCategory.TestFixRuns => "Test Fix runs",
        DataCategory.Learning => "Learning material",
        DataCategory.Usage => "Token usage history",
        DataCategory.Logs => "Logs",
        DataCategory.Leftovers => "Leftovers from earlier versions",
        _ => category.ToString(),
    };

    public static string Description(DataCategory category) => category switch
    {
        DataCategory.Indexes => "Files, chunks, vectors, graphs, code indexes and generated pages. The repositories stay registered; index them again to use them.",
        DataCategory.Conversations => "Every question and answer in the Ask panel and every Talk conversation, in every repository.",
        DataCategory.StudioConversations => "Composed Studio conversations and their transcripts. Personas are kept.",
        DataCategory.TestFixRuns => "Test Fix's record of each run: commands, logs, patches and the original files kept for undoing. Changes already made to your files stay.",
        DataCategory.Learning => "Learning paths, quizzes, flashcards, FAQ and knowledge checks.",
        DataCategory.Usage => "The record of model calls on the Usage page.",
        DataCategory.Logs => "Diagnostic logs. A log being written at that moment is left.",
        DataCategory.Leftovers => "Folders an earlier version left behind (state, attachments, repositories); nothing reads them now.",
        _ => "",
    };

    /// <summary>The files and folders of a category, as full paths.</summary>
    public IEnumerable<string> Paths(DataCategory category)
    {
        var repos = Path.Combine(store.Root, "repos");
        IEnumerable<string> RepoDirs() => Directory.Exists(repos) ? Directory.EnumerateDirectories(repos) : [];
        switch (category)
        {
            case DataCategory.Indexes:
                foreach (var dir in RepoDirs())
                {
                    foreach (var entry in Directory.EnumerateFileSystemEntries(dir))
                    {
                        if (!NotIndex.Contains(Path.GetFileName(entry), StringComparer.OrdinalIgnoreCase))
                        {
                            yield return entry;
                        }
                    }
                }
                yield return Path.Combine(store.Root, "analysis");
                break;
            case DataCategory.Conversations:
                foreach (var dir in RepoDirs())
                {
                    yield return Path.Combine(dir, "conversations");
                    yield return Path.Combine(dir, "talk");
                }
                break;
            case DataCategory.StudioConversations:
                foreach (var dir in RepoDirs())
                {
                    yield return Path.Combine(dir, "studio");
                }
                break;
            case DataCategory.TestFixRuns:
                foreach (var dir in RepoDirs())
                {
                    yield return Path.Combine(dir, "testfix");
                }
                break;
            case DataCategory.Learning:
                foreach (var dir in RepoDirs())
                {
                    yield return Path.Combine(dir, "learning.json");
                    yield return Path.Combine(dir, "knowledge.json");
                }
                break;
            case DataCategory.Usage:
                yield return Path.Combine(store.Root, "usage");
                break;
            case DataCategory.Logs:
                yield return Path.Combine(store.Root, "logs");
                break;
            case DataCategory.Leftovers:
                foreach (var name in LeftoverEntries)
                {
                    yield return Path.Combine(store.Root, name);
                }
                break;
        }
    }

    /// <summary>Removes the chosen categories. Indexes cannot be removed while a repository is being indexed.</summary>
    public async Task<DataRemoval> RemoveAsync(IReadOnlyCollection<DataCategory> categories, CancellationToken ct = default)
    {
        var records = await repositories.ListAsync(ct);
        if (categories.Contains(DataCategory.Indexes) && records.FirstOrDefault(r => indexing.IsRunning(r.Id)) is { } busy)
        {
            throw new ExplorerValidationException($"{busy.Title} is being indexed. Wait for it to finish (or cancel it), then remove the indexes.");
        }
        var paths = categories.Distinct().SelectMany(Paths).ToList();
        var result = await Task.Run(() => Delete(paths), ct);
        if (categories.Contains(DataCategory.Indexes))
        {
            foreach (var record in records)
            {
                indexing.Forget(record.Id);
                await repositories.UpdateAsync(record.Id, r =>
                {
                    r.Status = RepositoryStatus.NotIndexed;
                    r.Counters = new IndexCounters();
                    r.LastIndexedAt = null;
                    r.Error = null;
                }, ct);
            }
        }
        return result;
    }

    /// <summary>
    /// Asks for a factory reset on the next start (files in use now — the log, the diagram renderer — are free then).
    /// With <paramref name="keepAiSettings"/>, settings/ai.json (providers, models and API keys) survives the reset.
    /// </summary>
    public void ScheduleFactoryReset(bool keepAiSettings)
        => File.WriteAllText(Path.Combine(store.Root, ResetMarker), JsonSerializer.Serialize(new ResetRequest { KeepAiSettings = keepAiSettings, RequestedAt = DateTime.UtcNow }));

    /// <summary>
    /// Runs a factory reset that was asked for, before the explorer opens anything in <paramref name="root"/>.
    /// Returns what was deleted, or null when no reset was pending.
    /// </summary>
    public static DataRemoval? RunPendingFactoryReset(string root)
    {
        var marker = Path.Combine(root, ResetMarker);
        if (!File.Exists(marker))
        {
            return null;
        }
        ResetRequest request;
        try
        {
            request = JsonSerializer.Deserialize<ResetRequest>(File.ReadAllText(marker)) ?? new ResetRequest();
        }
        catch (JsonException)
        {
            request = new ResetRequest();
        }
        string? aiSettings = null;
        var aiPath = Path.Combine(root, "settings", "ai.json");
        if (request.KeepAiSettings && File.Exists(aiPath))
        {
            aiSettings = File.ReadAllText(aiPath);
        }
        var result = Delete(ExplorerEntries.Select(e => Path.Combine(root, e)));
        if (aiSettings is not null)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(aiPath)!);
            File.WriteAllText(aiPath, aiSettings);
        }
        File.Delete(marker);
        return result;
    }

    public static bool IsFactoryResetPending(string root) => File.Exists(Path.Combine(root, ResetMarker));

    /// <summary>Cancels a reset asked for earlier in this session.</summary>
    public void CancelFactoryReset() => File.Delete(Path.Combine(store.Root, ResetMarker));

    private static (long Bytes, int Files) Measure(IEnumerable<string> paths)
    {
        long bytes = 0;
        var files = 0;
        foreach (var path in paths)
        {
            if (File.Exists(path))
            {
                bytes += new FileInfo(path).Length;
                files++;
            }
            else if (Directory.Exists(path))
            {
                foreach (var file in SafeFiles(path))
                {
                    try
                    {
                        bytes += new FileInfo(file).Length;
                        files++;
                    }
                    catch (IOException)
                    {
                    }
                }
            }
        }
        return (bytes, files);
    }

    /// <summary>Deletes files and folders; a file in use is left (and counted) rather than failing the whole removal.</summary>
    private static DataRemoval Delete(IEnumerable<string> paths)
    {
        long freed = 0;
        int deleted = 0, inUse = 0;
        void DeleteFile(string file)
        {
            try
            {
                var info = new FileInfo(file);
                var length = info.Length;
                if (info.IsReadOnly)
                {
                    info.IsReadOnly = false;
                }
                info.Delete();
                freed += length;
                deleted++;
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                inUse++;
            }
        }
        foreach (var path in paths)
        {
            if (File.Exists(path))
            {
                DeleteFile(path);
            }
            else if (Directory.Exists(path))
            {
                foreach (var file in SafeFiles(path).ToList())
                {
                    DeleteFile(file);
                }
                // Folders bottom-up; one still holding a file in use stays.
                foreach (var dir in Directory.EnumerateDirectories(path, "*", SearchOption.AllDirectories).OrderByDescending(d => d.Count(c => c == Path.DirectorySeparatorChar)).Append(path))
                {
                    try
                    {
                        Directory.Delete(dir);
                    }
                    catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
                    {
                    }
                }
            }
        }
        return new DataRemoval(freed, deleted, inUse);
    }

    private static IEnumerable<string> SafeFiles(string folder)
    {
        try
        {
            return Directory.EnumerateFiles(folder, "*", new EnumerationOptions { RecurseSubdirectories = true, IgnoreInaccessible = true, AttributesToSkip = 0 });
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return [];
        }
    }

    private sealed class ResetRequest
    {
        public bool KeepAiSettings { get; set; }
        public DateTime RequestedAt { get; set; }
    }
}
