using System.Text.Json;
using DocGen.Core.Json;
using DocGen.Data.Storage;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;

namespace DocGen.Explorer.Engine.Storage;

/// <summary>
/// The explorer's data folder. Small documents go through the platform's <see cref="JsonFileStore"/> (atomic writes, backups,
/// cross-process locks); large derived artefacts (chunks, vectors) are written directly, atomically, without its 16 MB cap.
/// </summary>
public sealed class ExplorerStore
{
    public const string DataEnvironmentVariable = "DOCGEN_EXPLORER_DATA";

    private static readonly JsonSerializerOptions Compact = DocGenJson.Wire;

    public ExplorerStore(string rootDirectory, ILoggerFactory? loggers = null)
    {
        Root = Path.GetFullPath(rootDirectory);
        Directory.CreateDirectory(Root);
        Json = new JsonFileStore(Root, (loggers ?? NullLoggerFactory.Instance).CreateLogger<JsonFileStore>());
    }

    public string Root { get; }

    public IJsonStore Json { get; }

    /// <summary>DOCGEN_EXPLORER_DATA when set, otherwise %LOCALAPPDATA%\DocGen.Explorer\desktop.</summary>
    public static string DefaultRoot()
    {
        var configured = Environment.GetEnvironmentVariable(DataEnvironmentVariable);
        if (!string.IsNullOrWhiteSpace(configured))
        {
            return Path.GetFullPath(configured.Trim().Trim('"'));
        }
        return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DocGen.Explorer", "desktop");
    }

    public string RepositoryDirectory(string repositoryId)
    {
        RequireId(repositoryId);
        return Path.Combine(Root, "repos", repositoryId);
    }

    public string RepositoryRelative(string repositoryId, string file)
    {
        RequireId(repositoryId);
        return $"repos/{repositoryId}/{file}";
    }

    public string ClonesDirectory => Path.Combine(Root, "clones");

    public static void RequireId(string id)
    {
        if (string.IsNullOrWhiteSpace(id) || id.Length > 64 || id.Any(c => !(char.IsAsciiLetterOrDigit(c) || c is '-' or '_')))
        {
            throw new ArgumentException($"Invalid identifier '{id}'.", nameof(id));
        }
    }

    public Task<T?> ReadAsync<T>(string relativePath, CancellationToken ct = default) where T : class => Json.ReadAsync<T>(relativePath, ct);

    public Task WriteAsync<T>(string relativePath, T value, CancellationToken ct = default) where T : class => Json.WriteAsync(relativePath, value, ct);

    /// <summary>
    /// Reads settings kept encrypted for the current Windows user (<see cref="ProtectedJson"/>). A plain file from an
    /// earlier version is read, written back encrypted at once, and its plain backup removed.
    /// </summary>
    public async Task<T?> ReadProtectedAsync<T>(string relativePath, CancellationToken ct = default) where T : class
    {
        if (!OperatingSystem.IsWindows())
        {
            throw NotWindows();
        }
        var gate = GateFor(relativePath);
        await gate.WaitAsync(ct);
        try
        {
            var path = Full(relativePath);
            if (!File.Exists(path))
            {
                return null;
            }
            var text = await ReadSharedAsync(path, ct);
            if (ProtectedJson.IsProtected(text))
            {
                return JsonSerializer.Deserialize<T>(ProtectedJson.Unprotect(text), DocGenJson.Storage);
            }
            // Plain (an earlier version, or a damaged write): read it, then keep it encrypted from now on.
            var plain = await Json.ReadAsync<T>(relativePath, ct);
            if (plain is not null)
            {
                await WriteProtectedCoreAsync(relativePath, plain, ct);
            }
            return plain;
        }
        finally
        {
            gate.Release();
        }
    }

    /// <summary>Writes settings encrypted for the current Windows user; the backup kept beside it is encrypted too.</summary>
    public async Task WriteProtectedAsync<T>(string relativePath, T value, CancellationToken ct = default) where T : class
    {
        if (!OperatingSystem.IsWindows())
        {
            throw NotWindows();
        }
        var gate = GateFor(relativePath);
        await gate.WaitAsync(ct);
        try
        {
            await WriteProtectedCoreAsync(relativePath, value, ct);
        }
        finally
        {
            gate.Release();
        }
    }

    // One reader or writer at a time per settings file: a read while a write replaces the file fails ("the process cannot
    // access the file"). Shared by every store on the same folder.
    private static readonly System.Collections.Concurrent.ConcurrentDictionary<string, SemaphoreSlim> Gates = new(StringComparer.OrdinalIgnoreCase);

    private SemaphoreSlim GateFor(string relativePath) => Gates.GetOrAdd(Full(relativePath), _ => new SemaphoreSlim(1, 1));

    private static PlatformNotSupportedException NotWindows()
        => new("Settings are kept encrypted with Windows data protection: DocGen Explorer runs on Windows.");

    /// <summary>Reads a file, waiting briefly when another program (a virus scanner, a second copy) has it open.</summary>
    private static async Task<string> ReadSharedAsync(string path, CancellationToken ct)
    {
        for (var attempt = 1; ; attempt++)
        {
            try
            {
                return await File.ReadAllTextAsync(path, ct);
            }
            catch (IOException) when (attempt < 10 && File.Exists(path))
            {
                await Task.Delay(50 * attempt, ct);
            }
        }
    }

    [System.Runtime.Versioning.SupportedOSPlatform("windows")]
    private async Task WriteProtectedCoreAsync<T>(string relativePath, T value, CancellationToken ct) where T : class
    {
        var json = JsonSerializer.Serialize(value, DocGenJson.Storage);
        var envelope = JsonSerializer.Deserialize<System.Text.Json.Nodes.JsonObject>(ProtectedJson.Protect(json))!;
        await Json.WriteAsync(relativePath, envelope, ct);
        // The previous version is kept as .bak: if it was the plain file, it must not stay on disk.
        var backup = Full(relativePath) + DocGen.Data.Storage.JsonFileStore.BackupSuffix;
        if (File.Exists(backup) && !ProtectedJson.IsProtected(await File.ReadAllTextAsync(backup, ct)))
        {
            File.Delete(backup);
        }
    }

    /// <summary>Writes a (possibly large) document compactly and atomically.</summary>
    public async Task WriteLargeAsync<T>(string relativePath, T value, CancellationToken ct = default)
    {
        var path = Full(relativePath);
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var temp = path + "." + Guid.NewGuid().ToString("N")[..8] + ".tmp";
        await using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None, 1 << 16, useAsync: true))
        {
            await JsonSerializer.SerializeAsync(stream, value, Compact, ct);
        }
        File.Move(temp, path, overwrite: true);
    }

    public async Task<T?> ReadLargeAsync<T>(string relativePath, CancellationToken ct = default) where T : class
    {
        var path = Full(relativePath);
        if (!File.Exists(path))
        {
            return null;
        }
        try
        {
            await using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16, useAsync: true);
            return await JsonSerializer.DeserializeAsync<T>(stream, Compact, ct);
        }
        catch (JsonException)
        {
            return null; // Derived data: a damaged file is rebuilt by the next index run.
        }
    }

    public async Task WriteBytesAsync(string relativePath, byte[] bytes, CancellationToken ct = default)
    {
        var path = Full(relativePath);
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var temp = path + "." + Guid.NewGuid().ToString("N")[..8] + ".tmp";
        await File.WriteAllBytesAsync(temp, bytes, ct);
        File.Move(temp, path, overwrite: true);
    }

    public async Task<byte[]?> ReadBytesAsync(string relativePath, CancellationToken ct = default)
    {
        var path = Full(relativePath);
        return File.Exists(path) ? await File.ReadAllBytesAsync(path, ct) : null;
    }

    public async Task WriteTextAsync(string relativePath, string text, CancellationToken ct = default)
    {
        var path = Full(relativePath);
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var temp = path + "." + Guid.NewGuid().ToString("N")[..8] + ".tmp";
        await File.WriteAllTextAsync(temp, text, ct);
        File.Move(temp, path, overwrite: true);
    }

    public async Task<string?> ReadTextAsync(string relativePath, CancellationToken ct = default)
    {
        var path = Full(relativePath);
        return File.Exists(path) ? await File.ReadAllTextAsync(path, ct) : null;
    }

    public async Task AppendLineAsync(string relativePath, string line, CancellationToken ct = default)
    {
        var path = Full(relativePath);
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        await File.AppendAllTextAsync(path, line + Environment.NewLine, ct);
    }

    public bool Exists(string relativePath) => File.Exists(Full(relativePath));

    public void Delete(string relativePath)
    {
        var path = Full(relativePath);
        if (File.Exists(path))
        {
            File.Delete(path);
        }
    }

    public void DeleteDirectory(string relativePath)
    {
        var path = Full(relativePath);
        if (Directory.Exists(path))
        {
            DeleteTree(path);
        }
    }

    /// <summary>Deletes a folder, clearing read-only attributes (git object files are read-only).</summary>
    public static void DeleteTree(string path)
    {
        foreach (var file in Directory.EnumerateFiles(path, "*", SearchOption.AllDirectories))
        {
            var attributes = File.GetAttributes(file);
            if ((attributes & FileAttributes.ReadOnly) != 0)
            {
                File.SetAttributes(file, attributes & ~FileAttributes.ReadOnly);
            }
        }
        Directory.Delete(path, recursive: true);
    }

    public IEnumerable<string> EnumerateFiles(string relativeDirectory, string pattern)
    {
        var path = Full(relativeDirectory);
        return Directory.Exists(path) ? Directory.EnumerateFiles(path, pattern).Select(Path.GetFileName).OfType<string>() : [];
    }

    public string Full(string relativePath)
    {
        var full = Path.GetFullPath(Path.Combine(Root, relativePath.Replace('/', Path.DirectorySeparatorChar)));
        if (!full.StartsWith(Root, StringComparison.OrdinalIgnoreCase))
        {
            throw new ArgumentException("Path escapes the data folder.", nameof(relativePath));
        }
        return full;
    }
}
