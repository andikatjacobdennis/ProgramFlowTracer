using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using DocGen.Explorer.Engine.Repositories;

namespace DocGen.Explorer.Engine.Storage;

/// <summary>
/// JSON encrypted with the team's key — the providers files a team hands to its users. The same format is written and
/// read by scripts\providers\Protect-ProvidersFile.ps1 and Unprotect-ProvidersFile.ps1 (Windows PowerShell 5.1 has no
/// AES-GCM, so the format is AES-256-CBC with an HMAC-SHA256 over everything, encrypt-then-MAC).
/// <code>
/// { "format": "docgen-encrypted-json", "version": 1, "cipher": "AES-256-CBC+HMAC-SHA256",
///   "keyId": "…", "iv": "base64", "data": "base64", "mac": "base64" }
/// </code>
/// The 32-byte key is kept in secrets\providers.key (not in git) and built into the app.
/// </summary>
public static class EncryptedJson
{
    public const string Format = "docgen-encrypted-json";
    public const int Version = 1;
    public const string Cipher = "AES-256-CBC+HMAC-SHA256";

    /// <summary>The two keys used, derived from the team key (a separate key for encrypting and for the MAC).</summary>
    private static (byte[] Encrypt, byte[] Mac) Derive(byte[] key)
    {
        if (key.Length != 32)
        {
            throw new ExplorerValidationException("The providers key must be 32 bytes.");
        }
        return (HMACSHA256.HashData(key, Encoding.UTF8.GetBytes("docgen/providers/encrypt")),
                HMACSHA256.HashData(key, Encoding.UTF8.GetBytes("docgen/providers/mac")));
    }

    /// <summary>A short fingerprint of a key, so a file says which key it needs without giving the key away.</summary>
    public static string KeyId(byte[] key) => Convert.ToHexString(SHA256.HashData(key))[..16].ToLowerInvariant();

    private static byte[] MacInput(byte[] iv, byte[] data)
    {
        var header = Encoding.UTF8.GetBytes($"{Format}/{Version}");
        return [.. header, .. iv, .. data];
    }

    public static string Encrypt(string json, byte[] key)
    {
        var (encryptKey, macKey) = Derive(key);
        using var aes = Aes.Create();
        aes.Key = encryptKey;
        aes.GenerateIV();
        var data = aes.EncryptCbc(Encoding.UTF8.GetBytes(json), aes.IV, PaddingMode.PKCS7);
        var mac = HMACSHA256.HashData(macKey, MacInput(aes.IV, data));
        var envelope = new JsonObject
        {
            ["format"] = Format,
            ["version"] = Version,
            ["cipher"] = Cipher,
            ["keyId"] = KeyId(key),
            ["iv"] = Convert.ToBase64String(aes.IV),
            ["data"] = Convert.ToBase64String(data),
            ["mac"] = Convert.ToBase64String(mac),
        };
        return envelope.ToJsonString(new JsonSerializerOptions { WriteIndented = true });
    }

    /// <summary>Whether <paramref name="text"/> is an encrypted file (rather than plain JSON or something else).</summary>
    public static bool IsEncrypted(string text)
    {
        try
        {
            return JsonNode.Parse(text) is JsonObject o && (string?)o["format"] == Format;
        }
        catch (JsonException)
        {
            return false;
        }
    }

    /// <summary>The JSON inside an encrypted file; says plainly why when it cannot be read.</summary>
    public static string Decrypt(string text, byte[] key)
    {
        if (!IsEncrypted(text))
        {
            throw new ExplorerValidationException("This is not an encrypted file.");
        }
        var o = (JsonObject)JsonNode.Parse(text)!;
        if ((int?)o["version"] != Version || (string?)o["cipher"] != Cipher)
        {
            throw new ExplorerValidationException("This encrypted file was written by a newer version, or in another format.");
        }
        if ((string?)o["keyId"] is { } id && id != KeyId(key))
        {
            throw new ExplorerValidationException("This file was encrypted with another key than the one this build of DocGen Explorer has.");
        }
        byte[] iv, data, mac;
        try
        {
            iv = Convert.FromBase64String((string?)o["iv"] ?? "");
            data = Convert.FromBase64String((string?)o["data"] ?? "");
            mac = Convert.FromBase64String((string?)o["mac"] ?? "");
        }
        catch (FormatException)
        {
            throw new ExplorerValidationException("The encrypted file is damaged.");
        }
        var (encryptKey, macKey) = Derive(key);
        if (iv.Length != 16 || !CryptographicOperations.FixedTimeEquals(mac, HMACSHA256.HashData(macKey, MacInput(iv, data))))
        {
            throw new ExplorerValidationException("The encrypted file was changed after it was encrypted, or it was encrypted with another key.");
        }
        using var aes = Aes.Create();
        aes.Key = encryptKey;
        try
        {
            return Encoding.UTF8.GetString(aes.DecryptCbc(data, iv, PaddingMode.PKCS7));
        }
        catch (CryptographicException)
        {
            throw new ExplorerValidationException("The encrypted file is damaged.");
        }
    }

    /// <summary>Reads a key file: 32 bytes, written as base64 by scripts\providers\New-ProvidersKey.ps1.</summary>
    public static byte[] ReadKey(string base64)
    {
        try
        {
            var key = Convert.FromBase64String(base64.Trim());
            return key.Length == 32 ? key : throw new ExplorerValidationException("The providers key must be 32 bytes (base64).");
        }
        catch (FormatException)
        {
            throw new ExplorerValidationException("The providers key is not base64.");
        }
    }
}

/// <summary>
/// Settings kept encrypted on this PC (the AI keys, the Confluence tokens): Windows DPAPI for the current user, so only
/// this Windows account on this computer can read them. Plain files from earlier versions are encrypted when read.
/// <code>{ "format": "docgen-protected-json", "version": 1, "scope": "CurrentUser", "data": "base64" }</code>
/// </summary>
[System.Runtime.Versioning.SupportedOSPlatform("windows")]
public static class ProtectedJson
{
    public const string Format = "docgen-protected-json";
    private static readonly byte[] Entropy = Encoding.UTF8.GetBytes("DocGen.Explorer/settings/v1");

    public static string Protect(string json)
    {
        var data = ProtectedData.Protect(Encoding.UTF8.GetBytes(json), Entropy, DataProtectionScope.CurrentUser);
        return new JsonObject { ["format"] = Format, ["version"] = 1, ["scope"] = "CurrentUser", ["data"] = Convert.ToBase64String(data) }
            .ToJsonString(new JsonSerializerOptions { WriteIndented = true });
    }

    public static bool IsProtected(string text)
    {
        try
        {
            return JsonNode.Parse(text) is JsonObject o && (string?)o["format"] == Format;
        }
        catch (JsonException)
        {
            return false;
        }
    }

    public static string Unprotect(string text)
    {
        var o = (JsonObject)JsonNode.Parse(text)!;
        try
        {
            return Encoding.UTF8.GetString(ProtectedData.Unprotect(Convert.FromBase64String((string?)o["data"] ?? ""), Entropy, DataProtectionScope.CurrentUser));
        }
        catch (Exception ex) when (ex is CryptographicException or FormatException)
        {
            throw new ExplorerValidationException("These settings were encrypted for another Windows user or computer and cannot be read here.");
        }
    }
}
