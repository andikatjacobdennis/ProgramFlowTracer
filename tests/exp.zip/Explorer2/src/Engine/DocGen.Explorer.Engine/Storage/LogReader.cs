using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using DocGen.Explorer.Engine.Text;

namespace DocGen.Explorer.Engine.Storage;

/// <summary>One entry of the explorer's log: when, how serious, from where, what — and the exception, when there was one.</summary>
public sealed record LogEntry
{
    public long Id { get; init; }
    public DateTime TimeUtc { get; init; }
    public string Level { get; init; } = "INFO";
    public string Source { get; init; } = "";
    public string Message { get; init; } = "";

    /// <summary>The lines after the first (a stack trace), if any.</summary>
    public string Details { get; init; } = "";

    /// <summary>The exception's type ("System.IO.IOException"), when the entry has one.</summary>
    public string Exception { get; init; } = "";
    public string File { get; init; } = "";
    public int Line { get; init; }

    public DateTime Time => TimeUtc.ToLocalTime();
    public string Summary => Message.Length > 300 ? Message[..299] + "…" : Message;
    public string Full => Details.Length == 0 ? Message : Message + "\n" + Details;
}

/// <summary>What the log viewer shows: levels, a search, a text per column, and a time range.</summary>
public sealed record LogFilter
{
    public IReadOnlySet<string>? Levels { get; init; }
    public string? Search { get; init; }
    public FindOptions? SearchOptions { get; init; }
    public DateTime? FromUtc { get; init; }
    public DateTime? ToUtc { get; init; }
    public string? Source { get; init; }
    public string? Message { get; init; }
    public string? Exception { get; init; }
    public string? File { get; init; }

    public bool Matches(LogEntry e)
    {
        if (Levels is { Count: > 0 } levels && !levels.Contains(e.Level))
        {
            return false;
        }
        if (FromUtc is { } from && e.TimeUtc < from)
        {
            return false;
        }
        if (ToUtc is { } to && e.TimeUtc > to)
        {
            return false;
        }
        return Has(e.Source, Source) && Has(e.Full, Message) && Has(e.Exception, Exception) && Has(e.File, File)
               && (string.IsNullOrWhiteSpace(Search) || TextMatcher.Contains(e.Full + " " + e.Source + " " + e.Exception, Search, SearchOptions));
    }

    private static bool Has(string value, string? wanted) => string.IsNullOrWhiteSpace(wanted) || value.Contains(wanted.Trim(), StringComparison.OrdinalIgnoreCase);
}

/// <summary>A page of entries, and how many there are in all.</summary>
public sealed record LogPage(IReadOnlyList<LogEntry> Entries, int Total, int Matching, int Page, int PageCount);

/// <summary>
/// Reads the explorer's log files (logs/explorer-yyyyMMdd.log: "time LEVEL [source] message", with stack traces on the
/// lines after). Lines that do not start with a time belong to the entry before. It reads only what was added since the
/// last read, so auto refresh stays cheap on a large log.
/// </summary>
public sealed partial class LogReader(string folder)
{
    private readonly List<LogEntry> _entries = [];
    private readonly Dictionary<string, long> _read = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, int> _linesRead = new(StringComparer.OrdinalIgnoreCase);
    private long _nextId;

    public string Folder { get; } = folder;

    /// <summary>The levels the log uses, in order of seriousness.</summary>
    public static readonly IReadOnlyList<string> Levels = ["ERROR", "WARN", "INFO", "DEBUG"];

    public IReadOnlyList<LogEntry> Entries => _entries;

    /// <summary>Reads what is new in the log files (all of them the first time); returns how many entries were added.</summary>
    public int Refresh()
    {
        if (!Directory.Exists(Folder))
        {
            return 0;
        }
        var added = 0;
        foreach (var path in Directory.EnumerateFiles(Folder, "*.log").OrderBy(p => p, StringComparer.OrdinalIgnoreCase))
        {
            try
            {
                var length = new FileInfo(path).Length;
                var from = _read.GetValueOrDefault(path);
                if (length < from)
                {
                    // The file was replaced or cut: read it again.
                    _entries.RemoveAll(e => e.File == Path.GetFileName(path));
                    from = 0;
                    _linesRead[path] = 0;
                }
                if (length == from)
                {
                    continue;
                }
                using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
                stream.Seek(from, SeekOrigin.Begin);
                using var reader = new StreamReader(stream, Encoding.UTF8, detectEncodingFromByteOrderMarks: true);
                var text = reader.ReadToEnd();
                // An entry still being written (no line end yet) is read next time.
                var end = text.LastIndexOf('\n');
                if (end < 0)
                {
                    continue;
                }
                var complete = text[..(end + 1)];
                added += Parse(complete, Path.GetFileName(path), _linesRead.GetValueOrDefault(path));
                _linesRead[path] = _linesRead.GetValueOrDefault(path) + complete.Count(c => c == '\n');
                _read[path] = from + Encoding.UTF8.GetByteCount(complete) + (from == 0 && HasBom(path) ? 3 : 0);
            }
            catch (IOException)
            {
                // A file locked or removed meanwhile: read on the next refresh.
            }
            catch (UnauthorizedAccessException)
            {
            }
        }
        return added;
    }

    private static bool HasBom(string path)
    {
        using var s = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
        Span<byte> head = stackalloc byte[3];
        return s.Read(head) == 3 && head[0] == 0xEF && head[1] == 0xBB && head[2] == 0xBF;
    }

    /// <summary>Parses log text into entries (continuation lines join the entry before).</summary>
    public int Parse(string text, string file, int firstLine = 0)
    {
        var added = 0;
        var lineNumber = firstLine;
        LogEntry? current = null;
        var details = new StringBuilder();

        void Close()
        {
            if (current is null)
            {
                return;
            }
            var extra = details.ToString().TrimEnd();
            var exception = ExceptionType().Match(current.Message + "\n" + extra) is { Success: true } m ? m.Groups["type"].Value : "";
            _entries.Add(current with { Details = extra, Exception = exception });
            added++;
            details.Clear();
            current = null;
        }

        foreach (var raw in text.Split('\n'))
        {
            var line = raw.TrimEnd('\r');
            lineNumber++;
            var head = Head().Match(line);
            if (head.Success && DateTime.TryParse(head.Groups["time"].Value, CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal, out var time))
            {
                Close();
                var level = head.Groups["level"].Value.ToUpperInvariant() switch { "WARNING" => "WARN", "FATAL" or "CRITICAL" => "ERROR", "TRACE" => "DEBUG", var l => l };
                var rest = head.Groups["rest"].Value;
                var source = "";
                if (rest.StartsWith('[') && rest.IndexOf(']') is var close and > 1)
                {
                    source = rest[1..close];
                    rest = rest[(close + 1)..].TrimStart();
                }
                else if (rest.IndexOf(": ", StringComparison.Ordinal) is var colon and > 0 and <= 40 && !rest[..colon].Contains(' ', StringComparison.Ordinal))
                {
                    // "Assistant: …": the part before the colon names where it came from.
                    source = rest[..colon];
                }
                current = new LogEntry { Id = ++_nextId, TimeUtc = time, Level = level, Source = source, Message = rest, File = file, Line = lineNumber };
            }
            else if (current is not null && line.Length > 0)
            {
                details.Append(line).Append('\n');
            }
        }
        Close();
        return added;
    }

    /// <summary>The entries that match, newest (or oldest) first, one page of them.</summary>
    public LogPage Query(LogFilter filter, int page, int pageSize, bool newestFirst = true, string sortBy = "time")
    {
        var matching = _entries.Where(filter.Matches);
        IOrderedEnumerable<LogEntry> ordered = sortBy switch
        {
            "level" => newestFirst ? matching.OrderBy(e => Severity(e.Level)) : matching.OrderByDescending(e => Severity(e.Level)),
            "source" => newestFirst ? matching.OrderByDescending(e => e.Source, StringComparer.OrdinalIgnoreCase) : matching.OrderBy(e => e.Source, StringComparer.OrdinalIgnoreCase),
            "message" => newestFirst ? matching.OrderByDescending(e => e.Message, StringComparer.OrdinalIgnoreCase) : matching.OrderBy(e => e.Message, StringComparer.OrdinalIgnoreCase),
            "exception" => newestFirst ? matching.OrderByDescending(e => e.Exception, StringComparer.OrdinalIgnoreCase) : matching.OrderBy(e => e.Exception, StringComparer.OrdinalIgnoreCase),
            "file" => newestFirst ? matching.OrderByDescending(e => e.File, StringComparer.OrdinalIgnoreCase) : matching.OrderBy(e => e.File, StringComparer.OrdinalIgnoreCase),
            _ => newestFirst ? matching.OrderByDescending(e => e.TimeUtc) : matching.OrderBy(e => e.TimeUtc),
        };
        var list = ordered.ThenByDescending(e => e.Id).ToList();
        pageSize = Math.Max(1, pageSize);
        var pages = Math.Max(1, (list.Count + pageSize - 1) / pageSize);
        page = Math.Clamp(page, 0, pages - 1);
        return new LogPage(list.Skip(page * pageSize).Take(pageSize).ToList(), _entries.Count, list.Count, page, pages);
    }

    private static int Severity(string level) => level switch { "ERROR" => 0, "WARN" => 1, "INFO" => 2, _ => 3 };

    [GeneratedRegex(@"^(?<time>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?)\s+(?<level>[A-Za-z]+)\s?(?<rest>.*)$")]
    private static partial Regex Head();

    [GeneratedRegex(@"(?<type>(?:[A-Z][A-Za-z0-9_]*\.)+[A-Z][A-Za-z0-9_]*Exception)\b")]
    private static partial Regex ExceptionType();
}
