using System.Text.RegularExpressions;
using DocGen.Explorer.Engine.Models;

namespace DocGen.Explorer.Engine.Code;

/// <summary>
/// Parses Mermaid flowcharts ("graph LR" / "flowchart TD") into a <see cref="KnowledgeGraph"/> so they can be drawn
/// natively: nodes (A, A[label], A("label"), A{label}…), edges (-->, ---, -.->, ==>, with |label| or -- label -->) and
/// chains (A --> B --> C). Anything else (styles, classes, subgraph headers) is ignored. Returns null for other diagrams.
/// </summary>
public static partial class MermaidFlowchart
{
    /// <summary>
    /// The diagram without its front matter (the "---" block of YAML configuration, e.g. the ELK layout), so its first
    /// line is the diagram's kind.
    /// </summary>
    public static string WithoutFrontMatter(string source)
    {
        var text = source.Replace("\r", "", StringComparison.Ordinal).TrimStart();
        if (!text.StartsWith("---", StringComparison.Ordinal))
        {
            return text;
        }
        var end = text.IndexOf("\n---", 3, StringComparison.Ordinal);
        if (end < 0)
        {
            return text;
        }
        var after = text.IndexOf('\n', end + 4);
        return after < 0 ? "" : text[(after + 1)..];
    }

    public static KnowledgeGraph? Parse(string source, out string direction)
    {
        direction = "LR";
        source = WithoutFrontMatter(source);
        var lines = source.Replace("\r", "", StringComparison.Ordinal).Split('\n').Select(l => l.Trim()).Where(l => l.Length > 0 && !l.StartsWith("%%", StringComparison.Ordinal)).ToList();
        if (lines.Count == 0)
        {
            return null;
        }
        var header = HeaderRegex().Match(lines[0]);
        if (!header.Success)
        {
            return null;
        }
        direction = header.Groups[2].Success && header.Groups[2].Value.Length > 0 ? header.Groups[2].Value.ToUpperInvariant() : "TD";
        var graph = new KnowledgeGraph();
        var nodes = new Dictionary<string, GraphNode>(StringComparer.Ordinal);

        GraphNode Node(string token)
        {
            var match = NodeRegex().Match(token.Trim());
            var id = match.Success ? match.Groups["id"].Value : token.Trim();
            var label = match.Success && match.Groups["label"].Success ? match.Groups["label"].Value.Trim().Trim('"') : null;
            if (!nodes.TryGetValue(id, out var node))
            {
                node = new GraphNode { Id = id, Label = label ?? id, Type = ConceptTypes.Class };
                nodes[id] = node;
            }
            else if (label is not null)
            {
                node.Label = label;
            }
            return node;
        }

        foreach (var raw in lines.Skip(1))
        {
            var line = raw.TrimEnd(';');
            if (line.StartsWith("style ", StringComparison.Ordinal) || line.StartsWith("classDef ", StringComparison.Ordinal) || line.StartsWith("class ", StringComparison.Ordinal)
                || line.StartsWith("linkStyle", StringComparison.Ordinal) || line.StartsWith("click ", StringComparison.Ordinal) || line == "end" || line.StartsWith("subgraph", StringComparison.Ordinal)
                || line.StartsWith("direction", StringComparison.Ordinal))
            {
                continue;
            }
            var arrows = EdgeRegex().Matches(line);
            if (arrows.Count == 0)
            {
                foreach (var single in line.Split('&'))
                {
                    if (single.Trim().Length > 0)
                    {
                        Node(single);
                    }
                }
                continue;
            }
            var segments = new List<string>();
            var last = 0;
            foreach (Match arrow in arrows)
            {
                segments.Add(line[last..arrow.Index]);
                last = arrow.Index + arrow.Length;
            }
            segments.Add(line[last..]);
            for (var k = 0; k < arrows.Count; k++)
            {
                var label = arrows[k].Groups["pipe"].Success ? arrows[k].Groups["pipe"].Value : arrows[k].Groups["text"].Success ? arrows[k].Groups["text"].Value : "";
                foreach (var from in segments[k].Split('&').Where(s => s.Trim().Length > 0))
                {
                    foreach (var to in segments[k + 1].Split('&').Where(s => s.Trim().Length > 0))
                    {
                        var a = Node(from);
                        var b = Node(to);
                        graph.Edges.Add(new GraphEdge { From = a.Id, To = b.Id, Kind = label.Trim().Length > 0 ? label.Trim() : "uses" });
                    }
                }
            }
        }
        graph.Nodes = nodes.Values.ToList();
        return graph.Nodes.Count == 0 ? null : graph;
    }

    [GeneratedRegex(@"^(graph|flowchart)(?:\s+(LR|RL|TD|TB|BT))?\s*$", RegexOptions.IgnoreCase)]
    private static partial Regex HeaderRegex();

    [GeneratedRegex(@"^(?<id>[A-Za-z0-9_.:-]+)\s*(?:\[\[?\(?(?<label>[^\]\)]*)\)?\]?\]|\(\(?(?<label>[^\)]*)\)?\)|\{\{?(?<label>[^\}]*)\}?\}|>(?<label>[^\]]*)\])?\s*$")]
    private static partial Regex NodeRegex();

    [GeneratedRegex(@"\s*(?:--\s*(?<text>[^-|>][^->]*?)\s*-->|-\.->|-\.-|==>|-->|---|--o|--x|<-->)\s*(?:\|(?<pipe>[^|]*)\|)?\s*")]
    private static partial Regex EdgeRegex();
}
