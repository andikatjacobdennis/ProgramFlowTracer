using System.Text;

namespace DocGen.Explorer.Engine.Code;

/// <summary>
/// Shell-like and style languages, which a C-like scanner colours wrongly: bash/sh/zsh (commands, options, variables,
/// substitutions), console sessions (prompt lines), PowerShell (cmdlets, parameters, variables, block comments), Windows
/// batch, CSS/SCSS/Less, Dockerfiles and Makefiles.
/// </summary>
public static partial class SyntaxHighlighter
{
    private static readonly HashSet<string> ShellKeywords = Set(
        "if then else elif fi for while until do done case esac in function return local export readonly declare typeset unset shift break continue select time coproc trap set source alias eval exec exit");

    private static readonly HashSet<string> ShellBuiltins = Set(
        "echo printf cd pwd ls cat grep egrep sed awk find xargs sort uniq head tail wc cut tr tee touch mkdir rm rmdir cp mv ln chmod chown chgrp sudo su kill ps " +
        "curl wget tar gzip gunzip zip unzip ssh scp rsync git docker kubectl helm dotnet npm npx yarn pnpm node python python3 pip pip3 java mvn gradle make cmake " +
        "go cargo rustc apt apt-get yum dnf brew az aws gcloud terraform ansible systemctl journalctl test read sleep date env which whereis basename dirname " +
        "realpath mktemp true false wait nohup ulimit umask history jobs fg bg type command builtin getopts let trap");

    private static readonly HashSet<string> BatchKeywords = Set(
        "echo set if else goto call exit for in do not exist defined errorlevel equ neq lss leq gtr geq setlocal endlocal pushd popd cd cls copy xcopy robocopy del erase md mkdir rd rmdir " +
        "move ren rename type start pause shift title choice timeout where findstr find dir");

    private static readonly HashSet<string> DockerInstructions = Set(
        "FROM RUN CMD LABEL MAINTAINER EXPOSE ENV ADD COPY ENTRYPOINT VOLUME USER WORKDIR ARG ONBUILD STOPSIGNAL HEALTHCHECK SHELL AS");

    private static List<Span> ShellLine(string line, ref State state)
    {
        var spans = new List<Span>();
        var plain = new StringBuilder();
        void Flush()
        {
            if (plain.Length > 0)
            {
                spans.Add(new Span(TokenClass.Plain, plain.ToString()));
                plain.Clear();
            }
        }
        void Emit(TokenClass c, string text)
        {
            Flush();
            spans.Add(new Span(c, text));
        }

        var i = 0;
        // A command is expected at the start and after | ; && || ( $( and `.
        var commandNext = true;
        while (i < line.Length)
        {
            var c = line[i];
            if (c == '#' && (i == 0 || char.IsWhiteSpace(line[i - 1])))
            {
                Emit(TokenClass.Comment, line[i..]);
                return spans;
            }
            if (c is '"' or '\'')
            {
                var end = i + 1;
                while (end < line.Length && line[end] != c)
                {
                    end += line[end] == '\\' && c == '"' ? 2 : 1;
                }
                end = Math.Min(end, line.Length - 1);
                Emit(TokenClass.String, line[i..(end + 1)]);
                i = end + 1;
                commandNext = false;
                continue;
            }
            if (c == '$' && i + 1 < line.Length)
            {
                var next = line[i + 1];
                if (next == '{')
                {
                    var close = line.IndexOf('}', i + 2);
                    close = close < 0 ? line.Length - 1 : close;
                    Emit(TokenClass.Attribute, line[i..(close + 1)]);
                    i = close + 1;
                    continue;
                }
                if (next == '(')
                {
                    Emit(TokenClass.Punctuation, "$(");
                    i += 2;
                    commandNext = true;
                    continue;
                }
                if (char.IsLetter(next) || next == '_')
                {
                    var end = i + 1;
                    while (end < line.Length && (char.IsLetterOrDigit(line[end]) || line[end] == '_'))
                    {
                        end++;
                    }
                    Emit(TokenClass.Attribute, line[i..end]);
                    i = end;
                    continue;
                }
                if (char.IsDigit(next) || next is '@' or '*' or '#' or '?' or '$' or '!' or '-')
                {
                    Emit(TokenClass.Attribute, line[i..(i + 2)]);
                    i += 2;
                    continue;
                }
            }
            if (c is '|' or ';' or '&' or '(' or '`')
            {
                var end = i + 1;
                while (end < line.Length && line[end] is '|' or '&' or ';')
                {
                    end++;
                }
                Emit(TokenClass.Punctuation, line[i..end]);
                i = end;
                commandNext = true;
                continue;
            }
            if (c == '-' && (i == 0 || char.IsWhiteSpace(line[i - 1])) && i + 1 < line.Length && (char.IsLetter(line[i + 1]) || line[i + 1] == '-'))
            {
                var end = i + 1;
                while (end < line.Length && !char.IsWhiteSpace(line[end]) && line[end] is not ('=' or ';' or '|' or ')' or '"' or '\''))
                {
                    end++;
                }
                Emit(TokenClass.Preprocessor, line[i..end]);
                i = end;
                continue;
            }
            if (char.IsDigit(c) && (i == 0 || !char.IsLetterOrDigit(line[i - 1])))
            {
                var end = i;
                while (end < line.Length && (char.IsDigit(line[end]) || line[end] == '.'))
                {
                    end++;
                }
                if (end == line.Length || !char.IsLetter(line[end]))
                {
                    Emit(TokenClass.Number, line[i..end]);
                    i = end;
                    continue;
                }
            }
            if (char.IsLetter(c) || c == '_' || c == '.' && commandNext && i + 1 < line.Length && line[i + 1] == '/')
            {
                var end = i + 1;
                while (end < line.Length && (char.IsLetterOrDigit(line[end]) || line[end] is '_' or '-' or '.' or '/'))
                {
                    end++;
                }
                var word = line[i..end];
                if (end < line.Length && line[end] == '=' && word.All(ch => char.IsLetterOrDigit(ch) || ch == '_'))
                {
                    // NAME=value: an assignment (also after export, local, readonly…).
                    Emit(TokenClass.Attribute, word);
                }
                else if (ShellKeywords.Contains(word))
                {
                    Emit(TokenClass.Keyword, word);
                    commandNext = word is "then" or "else" or "do" or "if" or "elif" or "while" or "until" or "exec" or "eval" or "time" or "sudo";
                    i = end;
                    continue;
                }
                else if (commandNext || ShellBuiltins.Contains(word))
                {
                    Emit(TokenClass.Type, word);
                }
                else
                {
                    plain.Append(word);
                }
                commandNext = word == "sudo";
                i = end;
                continue;
            }
            if (!char.IsWhiteSpace(c))
            {
                commandNext = commandNext && c is '{' or '!';
            }
            plain.Append(c);
            i++;
        }
        Flush();
        return spans;
    }

    /// <summary>A console session: "$ " / "&gt; " / "PS C:\…&gt; " prompt lines are commands; other lines are output.</summary>
    private static List<Span> ConsoleLine(string line, ref State state)
    {
        var prompt = line.StartsWith("$ ", StringComparison.Ordinal) || line.StartsWith("# ", StringComparison.Ordinal) || line.StartsWith("> ", StringComparison.Ordinal) ? 2
            : line.StartsWith("PS ", StringComparison.Ordinal) && line.IndexOf("> ", StringComparison.Ordinal) is var ps and > 2 ? ps + 2
            : 0;
        if (prompt == 0)
        {
            return [new Span(TokenClass.Comment, line)];
        }
        var spans = new List<Span> { new(TokenClass.Punctuation, line[..prompt]) };
        spans.AddRange(line.StartsWith("PS ", StringComparison.Ordinal) ? CodeLine(line[prompt..], "powershell", ref state) : ShellLine(line[prompt..], ref state));
        return spans;
    }

    /// <summary>PowerShell: the C-like scan, plus $variables, -Parameters, Verb-Noun cmdlets and &lt;# … #&gt; comments.</summary>
    private static List<Span> PowerShellLine(string line, ref State state)
    {
        if (state == State.BlockComment)
        {
            var end = line.IndexOf("#>", StringComparison.Ordinal);
            if (end < 0)
            {
                return [new Span(TokenClass.Comment, line)];
            }
            state = State.None;
            var rest = PowerShellLine(line[(end + 2)..], ref state);
            rest.Insert(0, new Span(TokenClass.Comment, line[..(end + 2)]));
            return rest;
        }
        var open = line.IndexOf("<#", StringComparison.Ordinal);
        if (open >= 0 && !InString(line, open))
        {
            var close = line.IndexOf("#>", open + 2, StringComparison.Ordinal);
            var before = PowerShellLine(line[..open], ref state);
            if (close < 0)
            {
                before.Add(new Span(TokenClass.Comment, line[open..]));
                state = State.BlockComment;
                return before;
            }
            before.Add(new Span(TokenClass.Comment, line[open..(close + 2)]));
            before.AddRange(PowerShellLine(line[(close + 2)..], ref state));
            return before;
        }
        // The keyword scan, then the plain stretches refined.
        var spans = new List<Span>();
        foreach (var span in CodeLine(line, "powershell", ref state))
        {
            if (span.Class != TokenClass.Plain)
            {
                spans.Add(span);
                continue;
            }
            spans.AddRange(Refine(span.Text));
        }
        return spans;

        static IEnumerable<Span> Refine(string text)
        {
            var plain = new StringBuilder();
            var i = 0;
            while (i < text.Length)
            {
                var c = text[i];
                var start = i;
                TokenClass? kind = null;
                if (c == '$' && i + 1 < text.Length && (char.IsLetter(text[i + 1]) || text[i + 1] is '_' or '{'))
                {
                    i++;
                    if (text[i] == '{')
                    {
                        var close = text.IndexOf('}', i);
                        i = close < 0 ? text.Length : close + 1;
                    }
                    else
                    {
                        while (i < text.Length && (char.IsLetterOrDigit(text[i]) || text[i] is '_' or ':'))
                        {
                            i++;
                        }
                    }
                    kind = TokenClass.Attribute;
                }
                else if (c == '-' && i + 1 < text.Length && char.IsLetter(text[i + 1]) && (i == 0 || !char.IsLetterOrDigit(text[i - 1])))
                {
                    i++;
                    while (i < text.Length && char.IsLetterOrDigit(text[i]))
                    {
                        i++;
                    }
                    kind = TokenClass.Preprocessor;
                }
                else if (char.IsLetter(c) && (i == 0 || !char.IsLetterOrDigit(text[i - 1])))
                {
                    while (i < text.Length && (char.IsLetterOrDigit(text[i]) || text[i] == '-'))
                    {
                        i++;
                    }
                    var word = text[start..i];
                    // Verb-Noun: a cmdlet (Get-ChildItem, Set-Location).
                    kind = word.IndexOf('-') is > 0 and var dash && dash < word.Length - 1 && char.IsUpper(word[0]) ? TokenClass.Type : null;
                }
                else
                {
                    i++;
                }
                if (kind is { } k)
                {
                    if (plain.Length > 0)
                    {
                        yield return new Span(TokenClass.Plain, plain.ToString());
                        plain.Clear();
                    }
                    yield return new Span(k, text[start..i]);
                }
                else
                {
                    plain.Append(text, start, i - start);
                }
            }
            if (plain.Length > 0)
            {
                yield return new Span(TokenClass.Plain, plain.ToString());
            }
        }
    }

    private static bool InString(string line, int index)
    {
        var quotes = 0;
        for (var k = 0; k < index; k++)
        {
            if (line[k] is '"' or '\'')
            {
                quotes++;
            }
        }
        return quotes % 2 == 1;
    }

    /// <summary>Windows batch: REM and :: comments, :labels, %variables% and !delayed!, keywords, strings.</summary>
    private static List<Span> BatchLine(string line)
    {
        var trimmed = line.TrimStart();
        if (trimmed.StartsWith("::", StringComparison.Ordinal) || trimmed.StartsWith("rem ", StringComparison.OrdinalIgnoreCase) || trimmed.Equals("rem", StringComparison.OrdinalIgnoreCase)
            || trimmed.StartsWith("@rem ", StringComparison.OrdinalIgnoreCase))
        {
            return [new Span(TokenClass.Comment, line)];
        }
        if (trimmed.StartsWith(':'))
        {
            return [new Span(TokenClass.Heading, line)];
        }
        var spans = new List<Span>();
        var plain = new StringBuilder();
        void Flush()
        {
            if (plain.Length > 0)
            {
                spans.Add(new Span(TokenClass.Plain, plain.ToString()));
                plain.Clear();
            }
        }
        var i = 0;
        while (i < line.Length)
        {
            var c = line[i];
            if (c is '%' or '!')
            {
                var close = line.IndexOf(c, i + 1);
                if (c == '%' && i + 1 < line.Length && (char.IsDigit(line[i + 1]) || line[i + 1] == '~'))
                {
                    var end = i + 2;
                    while (end < line.Length && char.IsLetterOrDigit(line[end]))
                    {
                        end++;
                    }
                    Flush();
                    spans.Add(new Span(TokenClass.Attribute, line[i..end]));
                    i = end;
                    continue;
                }
                if (close > i + 1 && line[(i + 1)..close].All(ch => char.IsLetterOrDigit(ch) || ch is '_' or ':' or '~' or '-' or '='))
                {
                    Flush();
                    spans.Add(new Span(TokenClass.Attribute, line[i..(close + 1)]));
                    i = close + 1;
                    continue;
                }
            }
            if (c == '"')
            {
                var close = line.IndexOf('"', i + 1);
                close = close < 0 ? line.Length - 1 : close;
                Flush();
                spans.Add(new Span(TokenClass.String, line[i..(close + 1)]));
                i = close + 1;
                continue;
            }
            if (char.IsLetter(c) && (i == 0 || !char.IsLetterOrDigit(line[i - 1])))
            {
                var end = i;
                while (end < line.Length && (char.IsLetterOrDigit(line[end]) || line[end] == '_'))
                {
                    end++;
                }
                var word = line[i..end];
                if (BatchKeywords.Contains(word.ToLowerInvariant()))
                {
                    Flush();
                    spans.Add(new Span(TokenClass.Keyword, word));
                }
                else
                {
                    plain.Append(word);
                }
                i = end;
                continue;
            }
            if (c == '@' && i == line.Length - trimmed.Length)
            {
                Flush();
                spans.Add(new Span(TokenClass.Punctuation, "@"));
                i++;
                continue;
            }
            plain.Append(c);
            i++;
        }
        Flush();
        return spans;
    }

    /// <summary>CSS, SCSS and Less: selectors, properties, values (numbers with units, colours), strings, @rules and comments.</summary>
    private static List<Span> CssLine(string line, ref State state)
    {
        var spans = new List<Span>();
        var i = 0;
        if (state == State.BlockComment)
        {
            var end = line.IndexOf("*/", StringComparison.Ordinal);
            if (end < 0)
            {
                return [new Span(TokenClass.Comment, line)];
            }
            spans.Add(new Span(TokenClass.Comment, line[..(end + 2)]));
            i = end + 2;
            state = State.None;
        }
        var plain = new StringBuilder();
        void Flush()
        {
            if (plain.Length > 0)
            {
                spans.Add(new Span(TokenClass.Plain, plain.ToString()));
                plain.Clear();
            }
        }
        // Inside a declaration (after "prop:") until ";" or "}".
        var inValue = false;
        var declaration = line.Contains(':') && !line.TrimEnd().EndsWith('{') && !line.TrimStart().StartsWith('@');
        while (i < line.Length)
        {
            var c = line[i];
            if (c == '/' && i + 1 < line.Length && line[i + 1] == '*')
            {
                Flush();
                var end = line.IndexOf("*/", i + 2, StringComparison.Ordinal);
                if (end < 0)
                {
                    spans.Add(new Span(TokenClass.Comment, line[i..]));
                    state = State.BlockComment;
                    return spans;
                }
                spans.Add(new Span(TokenClass.Comment, line[i..(end + 2)]));
                i = end + 2;
                continue;
            }
            if (c == '/' && i + 1 < line.Length && line[i + 1] == '/')
            {
                Flush();
                spans.Add(new Span(TokenClass.Comment, line[i..]));
                return spans;
            }
            if (c is '"' or '\'')
            {
                Flush();
                var close = line.IndexOf(c, i + 1);
                close = close < 0 ? line.Length - 1 : close;
                spans.Add(new Span(TokenClass.String, line[i..(close + 1)]));
                i = close + 1;
                continue;
            }
            if (c == '@' || (c is '$' && !inValue))
            {
                Flush();
                var end = i + 1;
                while (end < line.Length && (char.IsLetterOrDigit(line[end]) || line[end] is '-' or '_'))
                {
                    end++;
                }
                spans.Add(new Span(c == '@' ? TokenClass.Keyword : TokenClass.Attribute, line[i..end]));
                i = end;
                continue;
            }
            if (c == '#' && inValue)
            {
                Flush();
                var end = i + 1;
                while (end < line.Length && Uri.IsHexDigit(line[end]))
                {
                    end++;
                }
                spans.Add(new Span(TokenClass.Number, line[i..end]));
                i = end;
                continue;
            }
            if (inValue && (char.IsDigit(c) || c == '.' && i + 1 < line.Length && char.IsDigit(line[i + 1])))
            {
                Flush();
                var end = i;
                while (end < line.Length && (char.IsLetterOrDigit(line[end]) || line[end] is '.' or '%'))
                {
                    end++;
                }
                spans.Add(new Span(TokenClass.Number, line[i..end]));
                i = end;
                continue;
            }
            if (c == ':' && declaration && !inValue)
            {
                // What came before was the property.
                var property = plain.ToString();
                plain.Clear();
                var lead = property.Length - property.TrimStart().Length;
                if (lead > 0)
                {
                    spans.Add(new Span(TokenClass.Plain, property[..lead]));
                }
                spans.Add(new Span(TokenClass.Attribute, property[lead..]));
                spans.Add(new Span(TokenClass.Punctuation, ":"));
                inValue = true;
                i++;
                continue;
            }
            if (c is ';' or '}' or '{')
            {
                Flush();
                spans.Add(new Span(TokenClass.Punctuation, c.ToString()));
                inValue = false;
                i++;
                continue;
            }
            plain.Append(c);
            i++;
        }
        if (plain.Length > 0)
        {
            // A selector line (no declaration): the selector as a tag.
            Flush();
            if (!declaration && spans.Count > 0 && spans[^1].Class == TokenClass.Plain && spans[^1].Text.Trim().Length > 0 && !inValue)
            {
                spans[^1] = spans[^1] with { Class = TokenClass.Tag };
            }
        }
        if (!declaration)
        {
            for (var k = 0; k < spans.Count; k++)
            {
                if (spans[k].Class == TokenClass.Plain && spans[k].Text.Trim().Length > 0)
                {
                    spans[k] = spans[k] with { Class = TokenClass.Tag };
                }
            }
        }
        return spans;
    }

    /// <summary>A Dockerfile: the instruction at the start of a line, the rest as shell; comments.</summary>
    private static List<Span> DockerLine(string line, ref State state)
    {
        var trimmed = line.TrimStart();
        if (trimmed.StartsWith('#'))
        {
            return [new Span(TokenClass.Comment, line)];
        }
        var lead = line.Length - trimmed.Length;
        var word = new string(trimmed.TakeWhile(char.IsLetter).ToArray());
        if (word.Length > 0 && DockerInstructions.Contains(word.ToUpperInvariant()))
        {
            var spans = new List<Span>();
            if (lead > 0)
            {
                spans.Add(new Span(TokenClass.Plain, line[..lead]));
            }
            spans.Add(new Span(TokenClass.Keyword, line.Substring(lead, word.Length)));
            spans.AddRange(ShellArguments(line[(lead + word.Length)..], ref state));
            return spans;
        }
        return ShellArguments(line, ref state);
    }

    /// <summary>Shell text that does not start with a command (arguments, a continuation line).</summary>
    private static List<Span> ShellArguments(string text, ref State state)
    {
        var spans = ShellLine("x" + text, ref state);
        // Drop the stand-in command the scan coloured.
        if (spans.Count > 0 && spans[0].Text.StartsWith('x'))
        {
            var first = spans[0].Text[1..];
            spans[0] = new Span(TokenClass.Plain, first);
            if (first.Length == 0)
            {
                spans.RemoveAt(0);
            }
        }
        return spans;
    }

    /// <summary>A Makefile: targets, variables $(NAME), assignments, recipe lines as shell, comments.</summary>
    private static List<Span> MakeLine(string line, ref State state)
    {
        var trimmed = line.TrimStart();
        if (trimmed.StartsWith('#'))
        {
            return [new Span(TokenClass.Comment, line)];
        }
        if (line.StartsWith('\t'))
        {
            var recipe = new List<Span> { new(TokenClass.Plain, "\t") };
            recipe.AddRange(ShellLine(line[1..], ref state));
            return recipe;
        }
        var colon = line.IndexOf(':');
        var equals = line.IndexOf('=');
        if (equals > 0 && (colon < 0 || colon > equals || line.ElementAtOrDefault(equals - 1) == ':'))
        {
            var name = line[..equals].TrimEnd(':', '?', '+', ' ');
            return [new Span(TokenClass.Attribute, name), new Span(TokenClass.Punctuation, line[name.Length..(equals + 1)]), .. Variables(line[(equals + 1)..])];
        }
        if (colon > 0 && !line[..colon].Contains(' ') || colon > 0 && line[..colon].Trim().StartsWith('.'))
        {
            return [new Span(TokenClass.Type, line[..colon]), new Span(TokenClass.Punctuation, ":"), .. Variables(line[(colon + 1)..])];
        }
        return Variables(line);

        static List<Span> Variables(string text)
        {
            var spans = new List<Span>();
            var i = 0;
            var last = 0;
            while (i < text.Length)
            {
                if (text[i] == '$' && i + 1 < text.Length && text[i + 1] is '(' or '{')
                {
                    var close = text.IndexOf(text[i + 1] == '(' ? ')' : '}', i + 2);
                    close = close < 0 ? text.Length - 1 : close;
                    if (i > last)
                    {
                        spans.Add(new Span(TokenClass.Plain, text[last..i]));
                    }
                    spans.Add(new Span(TokenClass.Attribute, text[i..(close + 1)]));
                    i = last = close + 1;
                    continue;
                }
                i++;
            }
            if (last < text.Length)
            {
                spans.Add(new Span(TokenClass.Plain, text[last..]));
            }
            return spans;
        }
    }
}
