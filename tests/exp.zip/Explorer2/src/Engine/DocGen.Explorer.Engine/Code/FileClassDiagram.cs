using System.Text;
using System.Text.RegularExpressions;
using DocGen.Analysis.Indexing;

namespace DocGen.Explorer.Engine.Code;

/// <summary>
/// A Mermaid class diagram of the types declared in one source file (Files → the class diagram button): each class,
/// interface, record, struct and enum with its members (visibility, type, parameters), what it inherits and implements,
/// the other indexed types its fields and properties hold, and the types nested in it.
/// </summary>
public static partial class FileClassDiagram
{
    /// <summary>The most members shown for one type (the rest are counted).</summary>
    public const int MaxMembers = 30;

    /// <summary>Whether the file declares a type a diagram can show.</summary>
    public static bool HasTypes(CodeIndex? code, string? file)
        => code is not null && file is not null && code.Files.TryGetValue(file, out var entry) && entry.Symbols.Any(IsShownType);

    private static bool IsShownType(SymbolRecord s) => SymbolKinds.IsType(s.Kind) && s.Kind != SymbolKinds.Delegate;

    /// <summary>The diagram's Mermaid source, or null when the file declares no type.</summary>
    public static string? Mermaid(CodeIndex code, string file)
    {
        if (!code.Files.TryGetValue(file, out var entry))
        {
            return null;
        }
        var types = entry.Symbols.Where(IsShownType).OrderBy(s => s.StartLine).ToList();
        if (types.Count == 0)
        {
            return null;
        }
        var ids = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var type in types)
        {
            ids[type.FullName] = Id(type.Name, ids.Values);
        }
        var sb = new StringBuilder("classDiagram\n");
        var related = new List<string>();
        var outside = new Dictionary<string, string>(StringComparer.Ordinal);

        string Other(string typeName)
        {
            // A type from outside this file: shown by name only (once).
            var bare = Bare(typeName);
            if (types.FirstOrDefault(t => t.Name == bare) is { } local)
            {
                return ids[local.FullName];
            }
            if (!outside.TryGetValue(bare, out var id))
            {
                outside[bare] = id = Id(bare, ids.Values.Concat(outside.Values));
            }
            return id;
        }

        foreach (var type in types)
        {
            var id = ids[type.FullName];
            sb.Append("    class ").Append(id).Append(Generic(type.Signature, type.Name)).Append(" {\n");
            var stereotype = type.Kind switch
            {
                SymbolKinds.Interface => "interface",
                SymbolKinds.Enum => "enumeration",
                SymbolKinds.Record => "record",
                SymbolKinds.Struct => "struct",
                _ when type.Modifiers.Contains("static") => "static",
                _ when type.Modifiers.Contains("abstract") => "abstract",
                _ => null,
            };
            if (stereotype is not null)
            {
                sb.Append("        <<").Append(stereotype).Append(">>\n");
            }
            var members = code.MembersOf(type.FullName).Where(m => !SymbolKinds.IsType(m.Kind)).OrderBy(m => m.File == file ? 0 : 1).ThenBy(m => m.StartLine).ToList();
            foreach (var member in members.Take(MaxMembers))
            {
                sb.Append("        ").Append(Member(member, type)).Append('\n');
            }
            if (members.Count > MaxMembers)
            {
                sb.Append("        … ").Append(members.Count - MaxMembers).Append(" more\n");
            }
            sb.Append("    }\n");

            // Inherits and implements: a name that is an interface (in the index, or I + capital) is implemented.
            for (var i = 0; i < type.Bases.Count; i++)
            {
                var b = type.Bases[i];
                var isInterface = code.ByName(Bare(b)).Any(s => s.Kind == SymbolKinds.Interface)
                                  || (Bare(b).Length > 1 && Bare(b)[0] == 'I' && char.IsUpper(Bare(b)[1]));
                related.Add(isInterface && type.Kind != SymbolKinds.Interface ? $"    {Other(b)} <|.. {id}" : $"    {Other(b)} <|-- {id}");
            }
            // Nested in another type of the file.
            if (type.Container is { } container && ids.TryGetValue(container, out var outer))
            {
                related.Add($"    {outer} *-- {id}");
            }
            // Holds: fields and properties whose type is another type of the index.
            foreach (var held in members.Where(m => m.Kind is SymbolKinds.Field or SymbolKinds.Property && m.ReturnType is { Length: > 0 })
                         .Select(m => (m.Name, Type: ElementType(m.ReturnType!)))
                         .Where(h => h.Type.Length > 0 && h.Type != type.Name && code.ByName(h.Type).Any(IsShownType))
                         .DistinctBy(h => h.Type).Take(8))
            {
                related.Add($"    {id} --> {Other(held.Type)} : {Safe(held.Name)}");
            }
        }
        foreach (var (name, id) in outside)
        {
            sb.Append("    class ").Append(id).Append(id == name ? "" : $"[\"{name}\"]").Append('\n');
        }
        foreach (var line in related.Distinct())
        {
            sb.Append(line).Append('\n');
        }
        return sb.ToString();
    }

    /// <summary>"+Name(string id, int count) Task~bool~", "-_cache : Dictionary~string, int~", "+Value" for an enum member.</summary>
    private static string Member(SymbolRecord m, SymbolRecord owner)
    {
        var visibility = m.Modifiers.Contains("public") || owner.Kind == SymbolKinds.Interface ? "+"
            : m.Modifiers.Contains("protected") ? "#"
            : m.Modifiers.Contains("internal") ? "~"
            : owner.Kind == SymbolKinds.Enum ? "" : "-";
        var suffix = (m.Modifiers.Contains("static") ? "$" : "") + (m.Modifiers.Contains("abstract") ? "*" : "");
        switch (m.Kind)
        {
            case SymbolKinds.Method or SymbolKinds.Constructor:
            {
                var parameters = Parameters(m.Signature) ?? string.Join(", ", m.ParameterTypes);
                var returns = m.Kind == SymbolKinds.Constructor || string.IsNullOrEmpty(m.ReturnType) || m.ReturnType == "void" ? "" : " " + Safe(m.ReturnType!);
                return $"{visibility}{Safe(m.Name)}({Safe(parameters)}){suffix}{returns}";
            }
            case SymbolKinds.EnumMember:
                return Safe(m.Name);
            case SymbolKinds.Event:
                return $"{visibility}event {Safe(m.ReturnType ?? "")} {Safe(m.Name)}{suffix}";
            default:
                return $"{visibility}{Safe(m.ReturnType ?? "")} {Safe(m.Name)}{suffix}".Replace("+ ", "+", StringComparison.Ordinal).Replace("- ", "-", StringComparison.Ordinal);
        }
    }

    /// <summary>The parameter list from a signature ("(string id, int count = 0)" → "string id, int count"), shortened.</summary>
    private static string? Parameters(string signature)
    {
        var open = signature.IndexOf('(');
        var close = signature.LastIndexOf(')');
        if (open < 0 || close <= open)
        {
            return null;
        }
        var inside = DefaultValue().Replace(signature[(open + 1)..close], "");
        inside = Spaces().Replace(inside, " ").Trim();
        return inside.Length > 70 ? inside[..69] + "…" : inside;
    }

    /// <summary>A type's generic parameters as Mermaid writes them: "Repository~T~".</summary>
    private static string Generic(string signature, string name)
    {
        var at = signature.IndexOf(name + "<", StringComparison.Ordinal);
        if (at < 0)
        {
            return "";
        }
        var close = signature.IndexOf('>', at);
        return close < 0 ? "" : "~" + signature[(at + name.Length + 1)..close].Replace(" ", "", StringComparison.Ordinal) + "~";
    }

    /// <summary>The type a member holds: "List&lt;Order&gt;" → "Order", "Order?" → "Order", "Dictionary&lt;string, Item&gt;" → "Item".</summary>
    private static string ElementType(string type)
    {
        var t = type.Trim().TrimEnd('?', '[', ']');
        var lt = t.IndexOf('<');
        if (lt >= 0 && t.EndsWith('>'))
        {
            var args = t[(lt + 1)..^1].Split(',');
            t = args[^1].Trim();
        }
        return Bare(t);
    }

    private static string Bare(string type)
    {
        var t = type.Trim();
        var lt = t.IndexOf('<');
        if (lt >= 0)
        {
            t = t[..lt];
        }
        var dot = t.LastIndexOf('.');
        return (dot >= 0 ? t[(dot + 1)..] : t).TrimEnd('?', '[', ']');
    }

    private static string Id(string name, IEnumerable<string> taken)
    {
        var id = NotIdentifier().Replace(name, "_");
        if (id.Length == 0 || char.IsDigit(id[0]))
        {
            id = "T_" + id;
        }
        var used = taken.ToHashSet(StringComparer.Ordinal);
        var unique = id;
        for (var n = 2; used.Contains(unique); n++)
        {
            unique = id + n;
        }
        return unique;
    }

    /// <summary>Text Mermaid draws as written: generics in ~ ~, no braces or quotes that would end the class block.</summary>
    private static string Safe(string text) => text.Replace('<', '~').Replace('>', '~').Replace('{', '(').Replace('}', ')').Replace("\"", "'", StringComparison.Ordinal)
        .Replace(":", "", StringComparison.Ordinal).Replace("#", "", StringComparison.Ordinal).Trim();

    [GeneratedRegex(@"\s*=\s*[^,)]+")]
    private static partial Regex DefaultValue();

    [GeneratedRegex(@"\s+")]
    private static partial Regex Spaces();

    [GeneratedRegex(@"[^A-Za-z0-9_]")]
    private static partial Regex NotIdentifier();
}
