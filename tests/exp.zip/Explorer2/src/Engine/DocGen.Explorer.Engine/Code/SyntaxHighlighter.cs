using System.Text;

namespace DocGen.Explorer.Engine.Code;

public enum TokenClass : byte
{
    Plain,
    Keyword,
    Type,
    String,
    Comment,
    Number,
    Preprocessor,
    Tag,
    Attribute,
    Heading,
    Punctuation,

    /// <summary>A line a diff adds.</summary>
    Inserted,

    /// <summary>A line a diff removes.</summary>
    Deleted,
}

public readonly record struct Span(TokenClass Class, string Text);

/// <summary>
/// A fast, line-oriented highlighter for the languages the explorer indexes: keywords, types (capitalised identifiers in
/// C-like languages), strings, comments (including multi-line ones carried across lines), numbers, preprocessor lines,
/// markup tags and attributes, JSON/YAML keys and Markdown headings. It never fails: unknown input is plain text.
/// </summary>
public static partial class SyntaxHighlighter
{
    private static readonly Dictionary<string, HashSet<string>> Keywords = new(StringComparer.Ordinal)
    {
        ["csharp"] = Set("abstract as async await base bool break byte case catch char checked class const continue decimal default delegate do double else enum event explicit extern false finally fixed float for foreach get goto if implicit in init int interface internal is lock long namespace new null object operator out override params partial private protected public readonly record ref required return sbyte sealed set short sizeof stackalloc static string struct switch this throw true try typeof uint ulong unchecked unsafe ushort using value var virtual void volatile when where while with yield file scoped global nameof not and or"),
        ["javascript"] = Set("async await break case catch class const continue debugger default delete do else export extends false finally for from function get if import in instanceof let new null of return set static super switch this throw true try typeof undefined var void while with yield"),
        ["typescript"] = Set("abstract any as async await boolean break case catch class const constructor continue declare default delete do else enum export extends false finally for from function get if implements import in infer instanceof interface is keyof let module namespace never new null number object of private protected public readonly return set static string super switch symbol this throw true try type typeof undefined unknown var void while yield"),
        ["python"] = Set("and as assert async await break class continue def del elif else except False finally for from global if import in is lambda None nonlocal not or pass raise return True try while with yield self match case"),
        ["java"] = Set("abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for goto if implements import instanceof int interface long native new null package private protected public return short static strictfp super switch synchronized this throw throws transient true false try var void volatile while record"),
        ["kotlin"] = Set("as break class continue do else false for fun if in interface is null object package return super this throw true try typealias val var when while by data sealed override open private public internal protected suspend"),
        ["go"] = Set("break case chan const continue default defer else fallthrough for func go goto if import interface map package range return select struct switch type var true false nil"),
        ["rust"] = Set("as async await break const continue crate dyn else enum extern false fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait true type unsafe use where while"),
        ["sql"] = Set("select from where and or not insert into values update set delete create table alter drop index view join inner left right outer on as group by order having limit offset distinct union all null is like in between exists case when then else end primary key foreign references default begin commit rollback transaction procedure function returns declare"),
        ["powershell"] = Set("begin break catch class continue data define do dynamicparam else elseif end exit filter finally for foreach from function if in param process return switch throw trap try until using var while"),
        ["vbnet"] = Set("addhandler and andalso as boolean byref byval case catch class const dim do each else elseif end enum event exit false finally for friend function get handles if implements imports in inherits integer interface is let me module mustinherit mustoverride mybase namespace new next not nothing object of on option optional or orelse overrides partial private property protected public raiseevent readonly redim return select set shadows shared static step string structure sub then throw to true try typeof using while with withevents"),
        ["vb6"] = Set("as boolean byref byval call case const dim do each else elseif end enum exit false for function get if integer let long loop me new next not nothing object on option private property public redim resume select set single static string sub then to true type until variant wend while with"),
        ["shell"] = Set("if then else elif fi for while do done case esac in function return local export echo exit"),
        ["fsharp"] = Set("let mutable rec fun function match with type module open if then else elif for in do while yield return true false null and or not member override abstract interface new inherit"),
        ["dart"] = Set("abstract as async await break case catch class const continue default do else enum extends false final finally for if implements import in is library new null return static super switch this throw true try var void while with"),
        ["php"] = Set("abstract and array as break case catch class clone const continue declare default do echo else elseif empty extends final finally for foreach function global if implements include interface isset namespace new null private protected public require return static switch throw trait try use var while"),
        ["ruby"] = Set("alias and begin break case class def defined do else elsif end ensure false for if in module next nil not or redo rescue retry return self super then true undef unless until when while yield"),
        ["c"] = Set("auto break case char const continue default do double else enum extern float for goto if inline int long register restrict return short signed sizeof static struct switch typedef union unsigned void volatile while bool true false NULL nullptr " +
            "class namespace template typename public private protected virtual override final friend operator new delete this throw try catch using constexpr noexcept auto decltype static_cast dynamic_cast reinterpret_cast const_cast explicit mutable"),
        ["swift"] = Set("associatedtype class deinit enum extension fileprivate func import init inout internal let open operator private protocol public rethrows static struct subscript typealias var break case continue default defer do else fallthrough for guard if in repeat return switch where while as catch false is nil self Self super throw throws true try async await"),
        ["scala"] = Set("abstract case catch class def do else extends false final finally for forSome if implicit import lazy match new null object override package private protected return sealed super this throw trait try true type val var while with yield given using enum then"),
        ["lua"] = Set("and break do else elseif end false for function goto if in local nil not or repeat return then true until while"),
        ["r"] = Set("if else repeat while function for in next break TRUE FALSE NULL Inf NaN NA library require return"),
        ["groovy"] = Set("abstract as assert boolean break byte case catch char class const continue def default do double else enum extends false final finally float for goto if implements import in instanceof int interface long native new null package private protected public return short static super switch synchronized this throw throws trait true try var void volatile while pipeline stage stages steps agent sh node"),
        ["perl"] = Set("my our local sub if elsif else unless while until for foreach do last next redo return use require package and or not eq ne lt gt le ge"),
        ["hcl"] = Set("resource data variable output locals module provider terraform for_each count depends_on lifecycle dynamic content true false null for in if"),
        ["graphql"] = Set("query mutation subscription fragment on type interface union enum input scalar schema extend directive implements true false null"),
        ["proto"] = Set("syntax package import option message enum service rpc returns repeated optional required oneof map reserved extend stream true false"),
    };

    private static readonly Dictionary<string, string> Aliases = new(StringComparer.Ordinal)
    {
        ["cs"] = "csharp", ["c#"] = "csharp", ["razor"] = "csharp", ["js"] = "javascript", ["jsx"] = "javascript", ["ts"] = "typescript", ["tsx"] = "typescript",
        ["py"] = "python", ["ps1"] = "powershell", ["sh"] = "shell", ["bash"] = "shell",
        ["vb"] = "vbnet", ["html"] = "xml", ["htm"] = "xml", ["xaml"] = "xml", ["msbuild"] = "xml", ["svg"] = "xml", ["vue"] = "xml", ["yml"] = "yaml",
        ["jsonc"] = "json", ["md"] = "markdown", ["kt"] = "kotlin", ["rs"] = "rust", ["fs"] = "fsharp", ["rb"] = "ruby", ["golang"] = "go",
        // Shells and consoles.
        ["zsh"] = "shell", ["ksh"] = "shell", ["fish"] = "shell", ["shellscript"] = "shell", ["sh-session"] = "console", ["shell-session"] = "console",
        ["terminal"] = "console", ["pwsh"] = "powershell", ["ps"] = "powershell", ["psm1"] = "powershell", ["psd1"] = "powershell", ["posh"] = "powershell",
        ["bat"] = "batch", ["cmd"] = "batch", ["dos"] = "batch", ["batchfile"] = "batch",
        // More languages and file types.
        ["cpp"] = "c", ["c++"] = "c", ["cc"] = "c", ["h"] = "c", ["hpp"] = "c", ["cxx"] = "c", ["objc"] = "c", ["objective-c"] = "c", ["cuda"] = "c",
        ["scss"] = "css", ["less"] = "css", ["sass"] = "css", ["docker"] = "dockerfile", ["make"] = "makefile", ["mk"] = "makefile",
        ["tf"] = "hcl", ["terraform"] = "hcl", ["gql"] = "graphql", ["protobuf"] = "proto", ["pl"] = "perl", ["gradle"] = "groovy", ["jenkinsfile"] = "groovy",
        ["env"] = "ini", ["dotenv"] = "ini", ["properties"] = "ini", ["editorconfig"] = "ini", ["gitignore"] = "shell", ["csproj"] = "xml", ["xsd"] = "xml",
        ["xslt"] = "xml", ["plist"] = "xml", ["resx"] = "xml", ["config"] = "xml", ["xhtml"] = "xml", ["cshtml"] = "csharp", ["vbs"] = "vbnet", ["vba"] = "vb6",
    };

    private static HashSet<string> Set(string words) => new(words.Split(' ', StringSplitOptions.RemoveEmptyEntries), StringComparer.Ordinal);

    public static string Normalize(string? language)
    {
        var lang = (language ?? "").Trim().ToLowerInvariant();
        return Aliases.TryGetValue(lang, out var alias) ? alias : lang;
    }

    /// <summary>Highlights a whole file, line by line (block comments and strings may span lines).</summary>
    public static List<List<Span>> Highlight(IReadOnlyList<string> lines, string? language)
    {
        var lang = Normalize(language);
        var result = new List<List<Span>>(lines.Count);
        var state = State.None;
        foreach (var line in lines)
        {
            result.Add(lang switch
            {
                "xml" => Markup(line, ref state),
                "json" => Json(line),
                "yaml" or "ini" or "toml" => KeyValue(line, lang),
                "markdown" => MarkdownLine(line, ref state),
                "diff" or "patch" => [DiffLine(line)],
                "shell" => ShellLine(line, ref state),
                "console" => ConsoleLine(line, ref state),
                "powershell" => PowerShellLine(line, ref state),
                "batch" => BatchLine(line),
                "css" => CssLine(line, ref state),
                "dockerfile" => DockerLine(line, ref state),
                "makefile" => MakeLine(line, ref state),
                _ when Keywords.ContainsKey(lang) => CodeLine(line, lang, ref state),
                "text" or "plaintext" or "txt" or "output" or "log" or "" => [new Span(TokenClass.Plain, line)],
                _ => CodeLine(line, "", ref state),
            });
        }
        return result;
    }

    /// <summary>A unified-diff line: added, removed, a hunk header or a file header.</summary>
    private static Span DiffLine(string line)
        => line.StartsWith("+++", StringComparison.Ordinal) || line.StartsWith("---", StringComparison.Ordinal) ? new Span(TokenClass.Comment, line)
            : line.StartsWith('+') ? new Span(TokenClass.Inserted, line)
            : line.StartsWith('-') ? new Span(TokenClass.Deleted, line)
            : line.StartsWith("@@", StringComparison.Ordinal) ? new Span(TokenClass.Heading, line)
            : new Span(TokenClass.Plain, line);

    private enum State
    {
        None,
        BlockComment,
        VerbatimString,
        RawString,
        XmlComment,
        Fence,
        PythonDoc,
    }

    private static List<Span> CodeLine(string line, string lang, ref State state)
    {
        var spans = new List<Span>();
        var keywords = Keywords.GetValueOrDefault(lang) ?? [];
        var caseInsensitive = lang is "sql" or "vbnet" or "vb6" or "powershell";
        var hashComments = lang is "python" or "shell" or "ruby" or "powershell" or "yaml" or "r" or "perl" or "hcl" or "graphql";
        var quoteComments = lang is "vbnet" or "vb6";
        var cLike = !(lang is "python" or "shell" or "ruby" or "sql" or "vbnet" or "vb6" or "powershell" or "r" or "perl" or "lua" or "graphql");
        var i = 0;
        var plain = new StringBuilder();

        void Flush()
        {
            if (plain.Length > 0)
            {
                spans.Add(new Span(TokenClass.Plain, plain.ToString()));
                plain.Clear();
            }
        }

        void Emit(TokenClass c, string text)
        {
            Flush();
            spans.Add(new Span(c, text));
        }

        // Continue a multi-line construct.
        if (state == State.BlockComment)
        {
            var end = line.IndexOf("*/", StringComparison.Ordinal);
            if (end < 0)
            {
                return [new Span(TokenClass.Comment, line)];
            }
            Emit(TokenClass.Comment, line[..(end + 2)]);
            i = end + 2;
            state = State.None;
        }
        else if (state == State.VerbatimString)
        {
            var end = FindVerbatimEnd(line, 0);
            if (end < 0)
            {
                return [new Span(TokenClass.String, line)];
            }
            Emit(TokenClass.String, line[..(end + 1)]);
            i = end + 1;
            state = State.None;
        }
        else if (state is State.RawString or State.PythonDoc)
        {
            var marker = state == State.RawString ? "\"\"\"" : "\"\"\"";
            var end = line.IndexOf(marker, StringComparison.Ordinal);
            if (end < 0)
            {
                return [new Span(TokenClass.String, line)];
            }
            Emit(TokenClass.String, line[..(end + 3)]);
            i = end + 3;
            state = State.None;
        }

        if (i == 0 && line.TrimStart().StartsWith('#') && lang is "csharp" or "java" or "c")
        {
            return [new Span(TokenClass.Preprocessor, line)];
        }

        while (i < line.Length)
        {
            var c = line[i];
            if (cLike && c == '/' && i + 1 < line.Length && line[i + 1] == '/')
            {
                Emit(TokenClass.Comment, line[i..]);
                return spans;
            }
            if ((hashComments && c == '#') || (lang is "sql" or "lua" && c == '-' && i + 1 < line.Length && line[i + 1] == '-') || (quoteComments && c == '\''))
            {
                Emit(TokenClass.Comment, line[i..]);
                return spans;
            }
            if (cLike && c == '/' && i + 1 < line.Length && line[i + 1] == '*')
            {
                var end = line.IndexOf("*/", i + 2, StringComparison.Ordinal);
                if (end < 0)
                {
                    Emit(TokenClass.Comment, line[i..]);
                    state = State.BlockComment;
                    return spans;
                }
                Emit(TokenClass.Comment, line[i..(end + 2)]);
                i = end + 2;
                continue;
            }
            if (c == '"' && i + 2 < line.Length && line[i + 1] == '"' && line[i + 2] == '"' && lang is "csharp" or "python" or "kotlin" or "java" or "dart")
            {
                var end = line.IndexOf("\"\"\"", i + 3, StringComparison.Ordinal);
                if (end < 0)
                {
                    Emit(TokenClass.String, line[i..]);
                    state = lang == "python" ? State.PythonDoc : State.RawString;
                    return spans;
                }
                Emit(TokenClass.String, line[i..(end + 3)]);
                i = end + 3;
                continue;
            }
            if (c == '@' && i + 1 < line.Length && line[i + 1] == '"' && lang == "csharp")
            {
                var end = FindVerbatimEnd(line, i + 2);
                if (end < 0)
                {
                    Emit(TokenClass.String, line[i..]);
                    state = State.VerbatimString;
                    return spans;
                }
                Emit(TokenClass.String, line[i..(end + 1)]);
                i = end + 1;
                continue;
            }
            if (c is '"' or '\'' or '`' && !(c == '\'' && quoteComments) && !(c == '`' && lang is not ("javascript" or "typescript" or "go" or "shell")))
            {
                var start = i;
                if (start > 0 && line[start - 1] == '$' && plain.Length > 0 && plain[^1] == '$')
                {
                    plain.Length--;
                    start--;
                }
                var end = i + 1;
                while (end < line.Length && line[end] != c)
                {
                    end += line[end] == '\\' && lang is not ("sql" or "vbnet" or "vb6") ? 2 : 1;
                }
                end = Math.Min(end, line.Length - 1);
                Emit(TokenClass.String, line[start..(end + 1)]);
                i = end + 1;
                continue;
            }
            if (char.IsDigit(c) && (i == 0 || !char.IsLetterOrDigit(line[i - 1]) && line[i - 1] != '_'))
            {
                var end = i;
                while (end < line.Length && (char.IsLetterOrDigit(line[end]) || line[end] is '.' or '_') && !(line[end] == '.' && end + 1 < line.Length && !char.IsDigit(line[end + 1])))
                {
                    end++;
                }
                Emit(TokenClass.Number, line[i..end]);
                i = end;
                continue;
            }
            if (char.IsLetter(c) || c == '_' || c == '@' && i + 1 < line.Length && char.IsLetter(line[i + 1]))
            {
                var end = i + 1;
                while (end < line.Length && (char.IsLetterOrDigit(line[end]) || line[end] == '_'))
                {
                    end++;
                }
                var word = line[i..end];
                var lookup = caseInsensitive ? word.ToLowerInvariant() : word;
                if (keywords.Contains(lookup))
                {
                    Emit(TokenClass.Keyword, word);
                }
                else if (cLike && char.IsUpper(word[0]) && word.Length > 1)
                {
                    Emit(TokenClass.Type, word);
                }
                else
                {
                    plain.Append(word);
                }
                i = end;
                continue;
            }
            plain.Append(c);
            i++;
        }
        Flush();
        return spans;
    }

    private static int FindVerbatimEnd(string line, int from)
    {
        for (var k = from; k < line.Length; k++)
        {
            if (line[k] == '"')
            {
                if (k + 1 < line.Length && line[k + 1] == '"')
                {
                    k++;
                    continue;
                }
                return k;
            }
        }
        return -1;
    }

    private static List<Span> Markup(string line, ref State state)
    {
        var spans = new List<Span>();
        var i = 0;
        if (state == State.XmlComment)
        {
            var end = line.IndexOf("-->", StringComparison.Ordinal);
            if (end < 0)
            {
                return [new Span(TokenClass.Comment, line)];
            }
            spans.Add(new Span(TokenClass.Comment, line[..(end + 3)]));
            i = end + 3;
            state = State.None;
        }
        var plain = new StringBuilder();
        while (i < line.Length)
        {
            if (string.CompareOrdinal(line, i, "<!--", 0, 4) == 0)
            {
                if (plain.Length > 0) { spans.Add(new Span(TokenClass.Plain, plain.ToString())); plain.Clear(); }
                var end = line.IndexOf("-->", i + 4, StringComparison.Ordinal);
                if (end < 0)
                {
                    spans.Add(new Span(TokenClass.Comment, line[i..]));
                    state = State.XmlComment;
                    return spans;
                }
                spans.Add(new Span(TokenClass.Comment, line[i..(end + 3)]));
                i = end + 3;
                continue;
            }
            if (line[i] == '<')
            {
                if (plain.Length > 0) { spans.Add(new Span(TokenClass.Plain, plain.ToString())); plain.Clear(); }
                var end = i + 1;
                while (end < line.Length && (char.IsLetterOrDigit(line[end]) || line[end] is '/' or ':' or '.' or '-' or '_' or '?' or '!'))
                {
                    end++;
                }
                spans.Add(new Span(TokenClass.Tag, line[i..end]));
                i = end;
                // Attributes up to '>'.
                while (i < line.Length && line[i] != '>')
                {
                    if (char.IsLetter(line[i]))
                    {
                        var a = i;
                        while (i < line.Length && (char.IsLetterOrDigit(line[i]) || line[i] is ':' or '-' or '_' or '.'))
                        {
                            i++;
                        }
                        spans.Add(new Span(TokenClass.Attribute, line[a..i]));
                    }
                    else if (line[i] is '"' or '\'')
                    {
                        var q = line[i];
                        var close = line.IndexOf(q, i + 1);
                        close = close < 0 ? line.Length - 1 : close;
                        spans.Add(new Span(TokenClass.String, line[i..(close + 1)]));
                        i = close + 1;
                    }
                    else
                    {
                        spans.Add(new Span(TokenClass.Plain, line[i].ToString()));
                        i++;
                    }
                }
                if (i < line.Length)
                {
                    var tagEnd = line[i - 1] == '/' ? ">" : ">";
                    spans.Add(new Span(TokenClass.Tag, tagEnd));
                    i++;
                }
                continue;
            }
            plain.Append(line[i]);
            i++;
        }
        if (plain.Length > 0)
        {
            spans.Add(new Span(TokenClass.Plain, plain.ToString()));
        }
        return spans;
    }

    private static List<Span> Json(string line)
    {
        var spans = new List<Span>();
        var i = 0;
        var plain = new StringBuilder();
        void Flush() { if (plain.Length > 0) { spans.Add(new Span(TokenClass.Plain, plain.ToString())); plain.Clear(); } }
        while (i < line.Length)
        {
            var c = line[i];
            if (c == '/' && i + 1 < line.Length && line[i + 1] == '/')
            {
                Flush();
                spans.Add(new Span(TokenClass.Comment, line[i..]));
                return spans;
            }
            if (c == '"')
            {
                Flush();
                var end = i + 1;
                while (end < line.Length && line[end] != '"')
                {
                    end += line[end] == '\\' ? 2 : 1;
                }
                end = Math.Min(end, line.Length - 1);
                var rest = line[(end + 1)..].TrimStart();
                spans.Add(new Span(rest.StartsWith(':') ? TokenClass.Attribute : TokenClass.String, line[i..(end + 1)]));
                i = end + 1;
                continue;
            }
            if (char.IsDigit(c) || c == '-' && i + 1 < line.Length && char.IsDigit(line[i + 1]))
            {
                Flush();
                var end = i + 1;
                while (end < line.Length && (char.IsDigit(line[end]) || line[end] is '.' or 'e' or 'E' or '+' or '-'))
                {
                    end++;
                }
                spans.Add(new Span(TokenClass.Number, line[i..end]));
                i = end;
                continue;
            }
            if (char.IsLetter(c))
            {
                var end = i;
                while (end < line.Length && char.IsLetter(line[end]))
                {
                    end++;
                }
                var word = line[i..end];
                if (word is "true" or "false" or "null")
                {
                    Flush();
                    spans.Add(new Span(TokenClass.Keyword, word));
                }
                else
                {
                    plain.Append(word);
                }
                i = end;
                continue;
            }
            plain.Append(c);
            i++;
        }
        Flush();
        return spans;
    }

    private static List<Span> KeyValue(string line, string lang)
    {
        var trimmed = line.TrimStart();
        if (trimmed.StartsWith('#') || trimmed.StartsWith(';'))
        {
            return [new Span(TokenClass.Comment, line)];
        }
        if (trimmed.StartsWith('[') && lang is "ini" or "toml")
        {
            return [new Span(TokenClass.Tag, line)];
        }
        var separator = lang == "yaml" ? line.IndexOf(':') : line.IndexOf('=');
        var key = separator > 0 ? line[..separator].Trim().TrimStart('-', ' ') : "";
        if (key.Length > 0 && key.All(ch => char.IsLetterOrDigit(ch) || ch is '_' or '-' or '.' or ' ' or '"' or '\''))
        {
            var spans = new List<Span> { new(TokenClass.Attribute, line[..separator]), new(TokenClass.Punctuation, line[separator].ToString()) };
            var value = line[(separator + 1)..];
            var hash = value.IndexOf(" #", StringComparison.Ordinal);
            if (hash >= 0)
            {
                spans.Add(ValueSpan(value[..hash]));
                spans.Add(new Span(TokenClass.Comment, value[hash..]));
            }
            else
            {
                spans.Add(ValueSpan(value));
            }
            return spans;
        }
        return [new Span(TokenClass.Plain, line)];
    }

    private static Span ValueSpan(string value)
    {
        var t = value.Trim();
        if (t.Length > 0 && (t[0] is '"' or '\''))
        {
            return new Span(TokenClass.String, value);
        }
        if (double.TryParse(t, System.Globalization.NumberStyles.Float, System.Globalization.CultureInfo.InvariantCulture, out _))
        {
            return new Span(TokenClass.Number, value);
        }
        if (t is "true" or "false" or "null" or "yes" or "no" or "~")
        {
            return new Span(TokenClass.Keyword, value);
        }
        return new Span(TokenClass.Plain, value);
    }

    private static List<Span> MarkdownLine(string line, ref State state)
    {
        var trimmed = line.TrimStart();
        if (trimmed.StartsWith("```", StringComparison.Ordinal) || trimmed.StartsWith("~~~", StringComparison.Ordinal))
        {
            state = state == State.Fence ? State.None : State.Fence;
            return [new Span(TokenClass.Preprocessor, line)];
        }
        if (state == State.Fence)
        {
            return [new Span(TokenClass.String, line)];
        }
        if (trimmed.StartsWith('#'))
        {
            return [new Span(TokenClass.Heading, line)];
        }
        if (trimmed.StartsWith('>'))
        {
            return [new Span(TokenClass.Comment, line)];
        }
        var spans = new List<Span>();
        var parts = line.Split('`');
        for (var k = 0; k < parts.Length; k++)
        {
            if (parts[k].Length == 0 && k % 2 == 0)
            {
                continue;
            }
            spans.Add(new Span(k % 2 == 1 ? TokenClass.String : TokenClass.Plain, k % 2 == 1 ? "`" + parts[k] + "`" : parts[k]));
        }
        return spans.Count == 0 ? [new Span(TokenClass.Plain, line)] : spans;
    }
}

/// <summary>A foldable block: lines <see cref="Start"/> (shown) to <see cref="End"/> (inclusive), 1-based.</summary>
public readonly record struct FoldRegion(int Start, int End);

/// <summary>Fold regions from braces (C-like languages and JSON), indentation (Python, YAML) or headings (Markdown).</summary>
public static class Folding
{
    public static List<FoldRegion> Regions(IReadOnlyList<string> lines, string? language)
    {
        var lang = SyntaxHighlighter.Normalize(language);
        var regions = lang switch
        {
            "python" or "yaml" => ByIndentation(lines),
            "markdown" => ByHeadings(lines),
            "xml" => ByTags(lines),
            _ => ByBraces(lines),
        };
        return regions.Where(r => r.End > r.Start).Distinct().OrderBy(r => r.Start).ThenByDescending(r => r.End).ToList();
    }

    private static List<FoldRegion> ByBraces(IReadOnlyList<string> lines)
    {
        var regions = new List<FoldRegion>();
        var stack = new Stack<int>();
        var inBlockComment = false;
        for (var i = 0; i < lines.Count; i++)
        {
            var line = lines[i];
            var inString = '\0';
            for (var k = 0; k < line.Length; k++)
            {
                var c = line[k];
                if (inBlockComment)
                {
                    if (c == '*' && k + 1 < line.Length && line[k + 1] == '/')
                    {
                        inBlockComment = false;
                        k++;
                    }
                    continue;
                }
                if (inString != '\0')
                {
                    if (c == '\\')
                    {
                        k++;
                    }
                    else if (c == inString)
                    {
                        inString = '\0';
                    }
                    continue;
                }
                if (c == '/' && k + 1 < line.Length && line[k + 1] == '/')
                {
                    break;
                }
                if (c == '/' && k + 1 < line.Length && line[k + 1] == '*')
                {
                    inBlockComment = true;
                    k++;
                    continue;
                }
                if (c is '"' or '\'')
                {
                    inString = c;
                    continue;
                }
                if (c is '{' or '[')
                {
                    // A brace alone on its line belongs to the declaration above it.
                    var owner = line.Trim() is "{" or "[" && i > 0 ? i : i + 1;
                    stack.Push(owner);
                }
                else if (c is '}' or ']' && stack.Count > 0)
                {
                    var start = stack.Pop();
                    if (i + 1 > start)
                    {
                        regions.Add(new FoldRegion(start, i + 1));
                    }
                }
            }
        }
        return regions;
    }

    private static List<FoldRegion> ByIndentation(IReadOnlyList<string> lines)
    {
        var regions = new List<FoldRegion>();
        static int Indent(string s) => s.Length - s.TrimStart().Length;
        for (var i = 0; i < lines.Count; i++)
        {
            if (lines[i].Trim().Length == 0)
            {
                continue;
            }
            var indent = Indent(lines[i]);
            var end = i;
            for (var j = i + 1; j < lines.Count; j++)
            {
                if (lines[j].Trim().Length == 0)
                {
                    continue;
                }
                if (Indent(lines[j]) <= indent)
                {
                    break;
                }
                end = j;
            }
            if (end > i)
            {
                regions.Add(new FoldRegion(i + 1, end + 1));
            }
        }
        return regions;
    }

    private static List<FoldRegion> ByHeadings(IReadOnlyList<string> lines)
    {
        var headings = new List<(int Line, int Level)>();
        var fence = false;
        for (var i = 0; i < lines.Count; i++)
        {
            var t = lines[i].TrimStart();
            if (t.StartsWith("```", StringComparison.Ordinal))
            {
                fence = !fence;
            }
            if (!fence && t.StartsWith('#'))
            {
                headings.Add((i + 1, t.TakeWhile(c => c == '#').Count()));
            }
        }
        var regions = new List<FoldRegion>();
        for (var k = 0; k < headings.Count; k++)
        {
            var end = lines.Count;
            for (var m = k + 1; m < headings.Count; m++)
            {
                if (headings[m].Level <= headings[k].Level)
                {
                    end = headings[m].Line - 1;
                    break;
                }
            }
            while (end > headings[k].Line && lines[end - 1].Trim().Length == 0)
            {
                end--;
            }
            regions.Add(new FoldRegion(headings[k].Line, end));
        }
        return regions;
    }

    private static List<FoldRegion> ByTags(IReadOnlyList<string> lines)
    {
        var regions = new List<FoldRegion>();
        var stack = new Stack<(string Name, int Line)>();
        var tag = new System.Text.RegularExpressions.Regex(@"<(/?)([A-Za-z_][\w:.-]*)[^>]*?(/?)>");
        for (var i = 0; i < lines.Count; i++)
        {
            foreach (System.Text.RegularExpressions.Match m in tag.Matches(lines[i]))
            {
                if (m.Groups[3].Value == "/")
                {
                    continue;
                }
                if (m.Groups[1].Value == "/")
                {
                    while (stack.Count > 0)
                    {
                        var open = stack.Pop();
                        if (open.Name == m.Groups[2].Value)
                        {
                            regions.Add(new FoldRegion(open.Line, i + 1));
                            break;
                        }
                    }
                }
                else
                {
                    stack.Push((m.Groups[2].Value, i + 1));
                }
            }
        }
        return regions;
    }
}
