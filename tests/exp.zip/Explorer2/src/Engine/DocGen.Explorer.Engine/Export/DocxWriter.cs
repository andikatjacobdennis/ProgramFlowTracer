using System.IO.Compression;
using System.Security;
using System.Text;
using DocGen.Explorer.Engine.Markdown;

namespace DocGen.Explorer.Engine.Export;

/// <summary>A titled Markdown document to export.</summary>
public sealed record ExportDocument(string Title, string Markdown);

/// <summary>
/// Writes Markdown documents to a Word (.docx) file: headings, paragraphs, lists, code, quotes, tables, links and — when
/// drawn — Mermaid diagrams as pictures.
/// </summary>
public static class DocxWriter
{
    // The printable width of the page (A4 less its margins) and the tallest a picture may be, in EMU.
    private const long PageWidthEmu = 6120130, MaxPictureHeightEmu = 8280000;

    /// <param name="diagrams">Drawn Mermaid diagrams by their source (trimmed); a diagram not here shows as its source.</param>
    public static byte[] Write(IReadOnlyList<ExportDocument> documents, string? title = null, IReadOnlyDictionary<string, DiagramImage>? diagrams = null)
    {
        using var stream = new MemoryStream();
        using (var zip = new ZipArchive(stream, ZipArchiveMode.Create, leaveOpen: true))
        {
            var links = new List<string>();
            var pictures = new Pictures(diagrams);
            var body = new StringBuilder();
            for (var d = 0; d < documents.Count; d++)
            {
                if (d > 0)
                {
                    body.Append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>");
                }
                var doc = MarkdownDocument.Parse(documents[d].Markdown);
                if (!doc.Blocks.OfType<MdHeading>().Any(h => h.Level == 1))
                {
                    body.Append(Paragraph("Heading1", [new MdText(documents[d].Title)], links));
                }
                foreach (var block in doc.Blocks)
                {
                    AppendBlock(body, block, links, 0, pictures);
                }
            }
            for (var i = 0; i < pictures.Png.Count; i++)
            {
                var entry = zip.CreateEntry($"word/media/image{i + 1}.png", CompressionLevel.NoCompression);
                using var output = entry.Open();
                output.Write(pictures.Png[i]);
            }
            Add(zip, "[Content_Types].xml", ContentTypes);
            Add(zip, "_rels/.rels", RootRels);
            Add(zip, "docProps/core.xml", Core(title ?? documents.FirstOrDefault()?.Title ?? "Documentation"));
            Add(zip, "word/styles.xml", Styles);
            Add(zip, "word/_rels/document.xml.rels", DocumentRels(links, pictures.Png.Count));
            Add(zip, "word/document.xml",
                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
                "xmlns:wp=\"http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing\" xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" " +
                "xmlns:pic=\"http://schemas.openxmlformats.org/drawingml/2006/picture\">" +
                "<w:body>" + body + "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1134\" w:right=\"1134\" w:bottom=\"1134\" w:left=\"1134\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/></w:sectPr>" +
                "</w:body></w:document>");
        }
        return stream.ToArray();
    }

    /// <summary>The drawn diagrams on hand and the pictures placed so far (image1.png, image2.png…).</summary>
    private sealed class Pictures(IReadOnlyDictionary<string, DiagramImage>? diagrams)
    {
        public List<byte[]> Png { get; } = [];

        public DiagramImage? For(MdCode code)
            => code.Language.Trim().Split(' ', 2)[0].Equals("mermaid", StringComparison.OrdinalIgnoreCase)
               && diagrams?.GetValueOrDefault(code.Code.Trim()) is { Png.Length: > 0, Width: > 0, Height: > 0 } image ? image : null;
    }

    /// <summary>A centred picture fitted to the page width (never enlarged).</summary>
    private static string Picture(DiagramImage image, Pictures pictures)
    {
        pictures.Png.Add(image.Png);
        var n = pictures.Png.Count;
        // Device-independent pixels (1/96 inch) to EMU.
        var cx = image.Width * 9525;
        var cy = image.Height * 9525;
        var scale = Math.Min(1, Math.Min(PageWidthEmu / cx, MaxPictureHeightEmu / cy));
        var w = (long)(cx * scale);
        var h = (long)(cy * scale);
        return "<w:p><w:pPr><w:jc w:val=\"center\"/></w:pPr><w:r><w:drawing>" +
               $"<wp:inline distT=\"0\" distB=\"0\" distL=\"0\" distR=\"0\"><wp:extent cx=\"{w}\" cy=\"{h}\"/><wp:docPr id=\"{n}\" name=\"Diagram {n}\" descr=\"Diagram\"/>" +
               "<wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect=\"1\"/></wp:cNvGraphicFramePr>" +
               "<a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/picture\"><pic:pic>" +
               $"<pic:nvPicPr><pic:cNvPr id=\"{n}\" name=\"image{n}.png\"/><pic:cNvPicPr/></pic:nvPicPr>" +
               $"<pic:blipFill><a:blip r:embed=\"rIdImage{n}\"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>" +
               $"<pic:spPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"{w}\" cy=\"{h}\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></pic:spPr>" +
               "</pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>";
    }

    private static void AppendBlock(StringBuilder body, MdBlock block, List<string> links, int depth, Pictures pictures)
    {
        switch (block)
        {
            case MdHeading h:
                body.Append(Paragraph($"Heading{Math.Clamp(h.Level, 1, 4)}", h.Inlines, links));
                break;
            case MdParagraph p:
                body.Append(Paragraph(depth > 0 ? "Quote" : "Normal", p.Inlines, links));
                break;
            case MdCode c when pictures.For(c) is { } image:
                body.Append(Picture(image, pictures));
                break;
            case MdCode c:
                foreach (var line in c.Code.Replace("\r", "", StringComparison.Ordinal).Split('\n'))
                {
                    body.Append($"<w:p><w:pPr><w:pStyle w:val=\"Code\"/></w:pPr><w:r><w:t xml:space=\"preserve\">{Escape(line)}</w:t></w:r></w:p>");
                }
                break;
            case MdQuote q:
                foreach (var inner in q.Blocks)
                {
                    AppendBlock(body, inner, links, depth + 1, pictures);
                }
                break;
            case MdList l:
                var number = l.Start;
                foreach (var item in l.Items)
                {
                    var marker = l.Ordered ? $"{number++}. " : item.Checked is null ? "• " : item.Checked == true ? "☑ " : "☐ ";
                    var first = true;
                    foreach (var inner in item.Blocks)
                    {
                        if (first && inner is MdParagraph para)
                        {
                            var inlines = new List<MdInline> { new MdText(marker) };
                            inlines.AddRange(para.Inlines);
                            body.Append(Paragraph("ListParagraph", inlines, links, indentTwips: 360 * (depth + 1)));
                        }
                        else
                        {
                            AppendBlock(body, inner, links, depth + 1, pictures);
                        }
                        first = false;
                    }
                }
                break;
            case MdTable t:
                body.Append("<w:tbl><w:tblPr><w:tblStyle w:val=\"TableGrid\"/><w:tblW w:w=\"0\" w:type=\"auto\"/><w:tblBorders>" +
                            "<w:top w:val=\"single\" w:sz=\"4\" w:color=\"BFBFBF\"/><w:left w:val=\"single\" w:sz=\"4\" w:color=\"BFBFBF\"/><w:bottom w:val=\"single\" w:sz=\"4\" w:color=\"BFBFBF\"/>" +
                            "<w:right w:val=\"single\" w:sz=\"4\" w:color=\"BFBFBF\"/><w:insideH w:val=\"single\" w:sz=\"4\" w:color=\"BFBFBF\"/><w:insideV w:val=\"single\" w:sz=\"4\" w:color=\"BFBFBF\"/>" +
                            "</w:tblBorders></w:tblPr>");
                body.Append("<w:tr>");
                foreach (var cell in t.Header)
                {
                    body.Append("<w:tc><w:tcPr><w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"F2F2F2\"/></w:tcPr>").Append(Paragraph("TableHeader", cell, links)).Append("</w:tc>");
                }
                body.Append("</w:tr>");
                foreach (var row in t.Rows)
                {
                    body.Append("<w:tr>");
                    foreach (var cell in row)
                    {
                        body.Append("<w:tc>").Append(Paragraph("Normal", cell, links)).Append("</w:tc>");
                    }
                    body.Append("</w:tr>");
                }
                body.Append("</w:tbl><w:p/>");
                break;
            case MdRule:
                body.Append("<w:p><w:pPr><w:pBdr><w:bottom w:val=\"single\" w:sz=\"6\" w:space=\"1\" w:color=\"BFBFBF\"/></w:pBdr></w:pPr></w:p>");
                break;
        }
    }

    private static string Paragraph(string style, IEnumerable<MdInline> inlines, List<string> links, int indentTwips = 0)
    {
        var sb = new StringBuilder("<w:p><w:pPr>");
        sb.Append($"<w:pStyle w:val=\"{style}\"/>");
        if (indentTwips > 0)
        {
            sb.Append($"<w:ind w:left=\"{indentTwips}\"/>");
        }
        sb.Append("</w:pPr>");
        AppendRuns(sb, inlines, links, bold: false, italic: false, strike: false);
        sb.Append("</w:p>");
        return sb.ToString();
    }

    private static void AppendRuns(StringBuilder sb, IEnumerable<MdInline> inlines, List<string> links, bool bold, bool italic, bool strike, bool link = false)
    {
        foreach (var inline in inlines)
        {
            switch (inline)
            {
                case MdText t:
                    sb.Append(Run(t.Text, bold, italic, strike, code: false, link));
                    break;
                case MdStrong s:
                    AppendRuns(sb, s.Inlines, links, true, italic, strike, link);
                    break;
                case MdEmphasis e:
                    AppendRuns(sb, e.Inlines, links, bold, true, strike, link);
                    break;
                case MdStrike s:
                    AppendRuns(sb, s.Inlines, links, bold, italic, true, link);
                    break;
                case MdInlineCode c:
                    sb.Append(Run(c.Code, bold, italic, strike, code: true, link));
                    break;
                case MdLink l when l.Url.StartsWith("http", StringComparison.OrdinalIgnoreCase):
                    links.Add(l.Url);
                    sb.Append($"<w:hyperlink r:id=\"rIdLink{links.Count}\">");
                    AppendRuns(sb, l.Inlines, links, bold, italic, strike, link: true);
                    sb.Append("</w:hyperlink>");
                    break;
                case MdLink l:
                    AppendRuns(sb, l.Inlines, links, bold, italic, strike, link);
                    break;
                case MdImage i:
                    sb.Append(Run($"[{i.Alt}]", bold, true, strike, code: false, link));
                    break;
                case MdLineBreak:
                    sb.Append("<w:r><w:br/></w:r>");
                    break;
            }
        }
    }

    private static string Run(string text, bool bold, bool italic, bool strike, bool code, bool link)
    {
        var props = new StringBuilder();
        if (code)
        {
            props.Append("<w:rFonts w:ascii=\"Consolas\" w:hAnsi=\"Consolas\" w:cs=\"Consolas\"/><w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"F2F2F2\"/>");
        }
        if (bold)
        {
            props.Append("<w:b/>");
        }
        if (italic)
        {
            props.Append("<w:i/>");
        }
        if (strike)
        {
            props.Append("<w:strike/>");
        }
        if (link)
        {
            props.Append("<w:color w:val=\"0B57D0\"/><w:u w:val=\"single\"/>");
        }
        var rPr = props.Length > 0 ? $"<w:rPr>{props}</w:rPr>" : "";
        return $"<w:r>{rPr}<w:t xml:space=\"preserve\">{Escape(text)}</w:t></w:r>";
    }

    public static string Escape(string text)
    {
        var sb = new StringBuilder(text.Length);
        foreach (var c in text)
        {
            // XML 1.0 forbids most control characters.
            if (c < 0x20 && c is not ('\t' or '\n' or '\r'))
            {
                continue;
            }
            sb.Append(c);
        }
        return SecurityElement.Escape(sb.ToString()) ?? "";
    }

    private static void Add(ZipArchive zip, string name, string content)
    {
        var entry = zip.CreateEntry(name, CompressionLevel.Optimal);
        using var writer = new StreamWriter(entry.Open(), new UTF8Encoding(false));
        writer.Write(content);
    }

    private const string ContentTypes =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
        "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
        "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
        "<Default Extension=\"png\" ContentType=\"image/png\"/>" +
        "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
        "<Override PartName=\"/word/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml\"/>" +
        "<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>" +
        "</Types>";

    private const string RootRels =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
        "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
        "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties\" Target=\"docProps/core.xml\"/>" +
        "</Relationships>";

    private static string DocumentRels(List<string> links, int pictures)
    {
        var sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        sb.Append("<Relationship Id=\"rIdStyles\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>");
        for (var i = 0; i < links.Count; i++)
        {
            sb.Append($"<Relationship Id=\"rIdLink{i + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink\" Target=\"{Escape(links[i])}\" TargetMode=\"External\"/>");
        }
        for (var i = 1; i <= pictures; i++)
        {
            sb.Append($"<Relationship Id=\"rIdImage{i}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"media/image{i}.png\"/>");
        }
        return sb.Append("</Relationships>").ToString();
    }

    private static string Core(string title) =>
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
        "xmlns:dcterms=\"http://purl.org/dc/terms/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
        $"<dc:title>{Escape(title)}</dc:title><dc:creator>DocGen Explorer</dc:creator>" +
        $"<dcterms:created xsi:type=\"dcterms:W3CDTF\">{DateTime.UtcNow:yyyy-MM-ddTHH:mm:ssZ}</dcterms:created></cp:coreProperties>";

    private const string Styles =
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<w:styles xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\">" +
        "<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii=\"Segoe UI\" w:hAnsi=\"Segoe UI\" w:cs=\"Segoe UI\"/><w:sz w:val=\"21\"/></w:rPr></w:rPrDefault>" +
        "<w:pPrDefault><w:pPr><w:spacing w:after=\"120\" w:line=\"276\" w:lineRule=\"auto\"/></w:pPr></w:pPrDefault></w:docDefaults>" +
        "<w:style w:type=\"paragraph\" w:default=\"1\" w:styleId=\"Normal\"><w:name w:val=\"Normal\"/></w:style>" +
        "<w:style w:type=\"paragraph\" w:styleId=\"Heading1\"><w:name w:val=\"heading 1\"/><w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/><w:pPr><w:keepNext/><w:spacing w:before=\"240\" w:after=\"160\"/><w:outlineLvl w:val=\"0\"/></w:pPr><w:rPr><w:b/><w:sz w:val=\"40\"/></w:rPr></w:style>" +
        "<w:style w:type=\"paragraph\" w:styleId=\"Heading2\"><w:name w:val=\"heading 2\"/><w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/><w:pPr><w:keepNext/><w:spacing w:before=\"240\" w:after=\"120\"/><w:pBdr><w:bottom w:val=\"single\" w:sz=\"4\" w:space=\"4\" w:color=\"D9D9D9\"/></w:pBdr><w:outlineLvl w:val=\"1\"/></w:pPr><w:rPr><w:b/><w:sz w:val=\"30\"/></w:rPr></w:style>" +
        "<w:style w:type=\"paragraph\" w:styleId=\"Heading3\"><w:name w:val=\"heading 3\"/><w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/><w:pPr><w:keepNext/><w:spacing w:before=\"200\" w:after=\"80\"/><w:outlineLvl w:val=\"2\"/></w:pPr><w:rPr><w:b/><w:sz w:val=\"25\"/></w:rPr></w:style>" +
        "<w:style w:type=\"paragraph\" w:styleId=\"Heading4\"><w:name w:val=\"heading 4\"/><w:basedOn w:val=\"Normal\"/><w:next w:val=\"Normal\"/><w:pPr><w:keepNext/><w:outlineLvl w:val=\"3\"/></w:pPr><w:rPr><w:b/><w:i/><w:sz w:val=\"22\"/></w:rPr></w:style>" +
        "<w:style w:type=\"paragraph\" w:styleId=\"Code\"><w:name w:val=\"Code\"/><w:basedOn w:val=\"Normal\"/><w:pPr><w:spacing w:after=\"0\" w:line=\"240\" w:lineRule=\"auto\"/><w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"F5F5F5\"/></w:pPr><w:rPr><w:rFonts w:ascii=\"Consolas\" w:hAnsi=\"Consolas\" w:cs=\"Consolas\"/><w:sz w:val=\"18\"/></w:rPr></w:style>" +
        "<w:style w:type=\"paragraph\" w:styleId=\"Quote\"><w:name w:val=\"Quote\"/><w:basedOn w:val=\"Normal\"/><w:pPr><w:ind w:left=\"567\"/><w:pBdr><w:left w:val=\"single\" w:sz=\"18\" w:space=\"8\" w:color=\"0B57D0\"/></w:pBdr></w:pPr><w:rPr><w:color w:val=\"555555\"/></w:rPr></w:style>" +
        "<w:style w:type=\"paragraph\" w:styleId=\"ListParagraph\"><w:name w:val=\"List Paragraph\"/><w:basedOn w:val=\"Normal\"/><w:pPr><w:spacing w:after=\"60\"/></w:pPr></w:style>" +
        "<w:style w:type=\"paragraph\" w:styleId=\"TableHeader\"><w:name w:val=\"Table Header\"/><w:basedOn w:val=\"Normal\"/><w:rPr><w:b/></w:rPr></w:style>" +
        "<w:style w:type=\"table\" w:styleId=\"TableGrid\"><w:name w:val=\"Table Grid\"/><w:tblPr><w:tblCellMar><w:left w:w=\"108\" w:type=\"dxa\"/><w:right w:w=\"108\" w:type=\"dxa\"/></w:tblCellMar></w:tblPr></w:style>" +
        "</w:styles>";
}
