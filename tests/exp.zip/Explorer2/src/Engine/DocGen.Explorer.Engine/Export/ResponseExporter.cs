using System.Globalization;
using System.IO.Compression;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using DocGen.Explorer.Engine.Markdown;
using DocGen.Explorer.Engine.Models;

namespace DocGen.Explorer.Engine.Export;

/// <summary>The file formats one assistant answer can be saved as.</summary>
public enum ResponseFormat { Word, Html, Markdown, Pdf, Text, Mermaid, PowerPoint }

/// <summary>One answer to export, with what is needed to give it a title, a header line and a Sources list.</summary>
public sealed record ResponseExport(
    string Answer,
    string? Question,
    bool IncludeQuestion,
    string RepositoryTitle,
    string? Branch,
    DateTime AnsweredAt,
    IReadOnlyList<Citation> Citations,
    string? Model = null,
    string? Persona = null);

/// <summary>
/// Saves one assistant answer as Word, PowerPoint, HTML, Markdown, PDF, plain text or its Mermaid diagrams. Every format shares the
/// same shape — title, a header line, the question (optional), the answer and its Sources — so a reader gets the same
/// content whichever file they open. Repository links (repo:) only mean something inside the app, so they become
/// readable "path:line" references everywhere.
/// </summary>
public static partial class ResponseExporter
{
    private const string NoDiagram = "This response does not contain a Mermaid diagram.";
    private const string MermaidLabel = "Mermaid diagram (source)";
    private const int MaxFileName = 60;
    private const int MaxTitle = 120;

    /// <summary>The ```mermaid fenced blocks of the answer, in order (source only, trimmed, no fences).</summary>
    public static IReadOnlyList<string> MermaidDiagrams(string answerMarkdown)
    {
        // Only blocks the author marked as Mermaid count: a diagram is never inferred from prose or other code.
        return Walk(MarkdownDocument.Parse(answerMarkdown).Blocks)
            .OfType<MdCode>()
            .Where(IsMermaid)
            .Select(c => c.Code.Trim())
            .Where(c => c.Length > 0)
            .ToList();
    }

    /// <summary>A readable, Windows-safe file name without extension, from the question or else the answer's title.</summary>
    public static string FileName(ResponseExport export)
    {
        var source = !string.IsNullOrWhiteSpace(export.Question) ? export.Question! : AnswerTitle(export.Answer) ?? "";
        var sb = new StringBuilder();
        var invalid = Path.GetInvalidFileNameChars();
        foreach (var c in source)
        {
            // Characters Windows refuses (and Markdown punctuation that only adds noise) become spaces.
            sb.Append(char.IsControl(c) || invalid.Contains(c) || c is '<' or '>' or ':' or '"' or '/' or '\\' or '|' or '?' or '*' or '`' or '#' ? ' ' : c);
        }
        var name = WhitespaceRegex().Replace(sb.ToString(), " ").Trim();
        if (name.Length > MaxFileName)
        {
            // Cut at a word boundary so the name does not end mid-word.
            var cut = name[..MaxFileName];
            var space = cut.LastIndexOf(' ');
            name = space > MaxFileName / 2 ? cut[..space] : cut;
        }
        // Windows also refuses names ending in a dot or space.
        name = name.TrimEnd('.', ' ').Trim();
        if (name.Length == 0)
        {
            return "answer";
        }
        return IsReserved(name) ? name + " answer" : name;
    }

    public static string Extension(ResponseFormat format) => format switch
    {
        ResponseFormat.Word => ".docx",
        ResponseFormat.Html => ".html",
        ResponseFormat.Markdown => ".md",
        ResponseFormat.Pdf => ".pdf",
        ResponseFormat.Text => ".txt",
        ResponseFormat.Mermaid => ".mmd",
        ResponseFormat.PowerPoint => ".pptx",
        _ => throw new ArgumentOutOfRangeException(nameof(format)),
    };

    /// <summary>The file's bytes for every format except Mermaid (a response may hold several diagrams; use MermaidFile or MermaidZip).</summary>
    /// <param name="diagrams">Drawn Mermaid diagrams by their source (trimmed): Word and PowerPoint show them as pictures; any not drawn show as source.</param>
    public static byte[] Write(ResponseExport export, ResponseFormat format, IReadOnlyDictionary<string, DiagramImage>? diagrams = null)
    {
        var utf8 = new UTF8Encoding(false);
        return format switch
        {
            ResponseFormat.Word => DocxWriter.Write([new ExportDocument(Title(export), DocumentMarkdown(export, forPrint: true, diagrams))], Title(export), diagrams),
            ResponseFormat.PowerPoint => PptxWriter.Write(Rewrite(export.Answer ?? "", labelMermaid: false).Trim(), DeckOptions(export, diagrams)),
            ResponseFormat.Pdf => PdfWriter.Write([new ExportDocument(Title(export), DocumentMarkdown(export, forPrint: true))], Title(export)),
            ResponseFormat.Markdown => utf8.GetBytes(DocumentMarkdown(export, forPrint: false)),
            ResponseFormat.Html => utf8.GetBytes(Html(export)),
            ResponseFormat.Text => utf8.GetBytes(PlainText(export)),
            ResponseFormat.Mermaid => throw new InvalidOperationException("Mermaid diagrams are saved with MermaidFile or MermaidZip."),
            _ => throw new ArgumentOutOfRangeException(nameof(format)),
        };
    }

    /// <summary>One diagram as a .mmd file: the source exactly, ending with a newline.</summary>
    public static byte[] MermaidFile(ResponseExport export, int index)
    {
        var diagrams = MermaidDiagrams(export.Answer);
        if (index < 0 || index >= diagrams.Count)
        {
            throw new InvalidOperationException(NoDiagram);
        }
        return new UTF8Encoding(false).GetBytes(diagrams[index] + "\n");
    }

    /// <summary>Every diagram as its own .mmd file inside one ZIP.</summary>
    public static byte[] MermaidZip(ResponseExport export)
    {
        var diagrams = MermaidDiagrams(export.Answer);
        if (diagrams.Count == 0)
        {
            throw new InvalidOperationException(NoDiagram);
        }
        var name = FileName(export);
        using var stream = new MemoryStream();
        using (var zip = new ZipArchive(stream, ZipArchiveMode.Create, leaveOpen: true))
        {
            for (var i = 0; i < diagrams.Count; i++)
            {
                var entry = zip.CreateEntry($"{name}-diagram-{i + 1}.mmd", CompressionLevel.Optimal);
                using var output = entry.Open();
                output.Write(MermaidFile(export, i));
            }
        }
        return stream.ToArray();
    }

    /// <summary>
    /// A deck of the answer: its "# " heading (else the question or the answer's first line) is the title slide, with the
    /// header line, the question when included and the model as its small print, and the Sources close the deck.
    /// </summary>
    private static DeckOptions DeckOptions(ResponseExport e, IReadOnlyDictionary<string, DiagramImage>? diagrams)
    {
        var small = new List<string> { HeaderLine(e) };
        if (UsesQuestion(e))
        {
            var question = WhitespaceRegex().Replace(e.Question!, " ").Trim();
            small.Add("Question: " + (question.Length > 200 ? question[..199].TrimEnd() + "…" : question));
        }
        if (!string.IsNullOrWhiteSpace(e.Model))
        {
            small.Add("Answered by " + e.Model);
        }
        var sources = Sources(e).Select(c => $"[{c.Number.ToString(CultureInfo.InvariantCulture)}] {SourceLocation(c)}" + (string.IsNullOrWhiteSpace(c.Title) ? "" : " — " + c.Title.Trim())).ToList();
        return new DeckOptions(Title(e), small, sources, diagrams);
    }

    // ---------------------------------------------------------------- shared document model

    private static bool UsesQuestion(ResponseExport e) => e.IncludeQuestion && !string.IsNullOrWhiteSpace(e.Question);

    private static string Title(ResponseExport e)
    {
        var title = UsesQuestion(e) ? WhitespaceRegex().Replace(e.Question!, " ").Trim() : AnswerTitle(e.Answer) ?? "Answer";
        return title.Length > MaxTitle ? title[..(MaxTitle - 1)].TrimEnd() + "…" : title;
    }

    /// <summary>The answer's first heading, else its first sentence; null when the answer has no text.</summary>
    private static string? AnswerTitle(string answer)
    {
        var blocks = MarkdownDocument.Parse(answer).Blocks;
        var heading = blocks.OfType<MdHeading>().FirstOrDefault();
        if (heading is not null && heading.Text.Trim().Length > 0)
        {
            return heading.Text.Trim();
        }
        var paragraph = Walk(blocks).OfType<MdParagraph>().Select(p => MarkdownDocument.PlainText(p.Inlines).Trim()).FirstOrDefault(t => t.Length > 0);
        if (paragraph is null)
        {
            return null;
        }
        var sentence = SentenceEndRegex().Match(paragraph);
        var text = sentence.Success ? paragraph[..(sentence.Index + 1)] : paragraph;
        // A title reads better without the full stop; a question keeps its question mark.
        return text.TrimEnd('.').Trim();
    }

    private static string HeaderLine(ResponseExport e)
    {
        var parts = new List<string> { e.RepositoryTitle };
        if (!string.IsNullOrWhiteSpace(e.Branch))
        {
            parts.Add("branch " + e.Branch);
        }
        // AnsweredAt is stored in UTC; readers expect their own clock.
        var at = e.AnsweredAt.Kind == DateTimeKind.Local ? e.AnsweredAt : DateTime.SpecifyKind(e.AnsweredAt, DateTimeKind.Utc).ToLocalTime();
        parts.Add(at.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture));
        if (!string.IsNullOrWhiteSpace(e.Persona))
        {
            parts.Add(e.Persona!);
        }
        return string.Join(" · ", parts);
    }

    private static string SourceLocation(Citation c)
    {
        if (c.StartLine <= 0)
        {
            return c.Path;
        }
        return c.EndLine > c.StartLine ? $"{c.Path}:{c.StartLine}–{c.EndLine}" : $"{c.Path}:{c.StartLine}";
    }

    private static IEnumerable<Citation> Sources(ResponseExport e) => e.Citations.OrderBy(c => c.Number);

    /// <summary>
    /// The answer as it goes into a file: the leading heading is dropped when it already serves as the title, repo: links
    /// become code spans, and (for Word/PDF, which cannot draw diagrams) each Mermaid block is labelled as source.
    /// </summary>
    private static string AnswerBody(ResponseExport e, bool labelMermaid, IReadOnlyDictionary<string, DiagramImage>? diagrams = null)
    {
        var answer = e.Answer ?? "";
        if (!UsesQuestion(e))
        {
            answer = DropLeadingHeading(answer);
        }
        return Rewrite(answer, labelMermaid, diagrams).Trim();
    }

    private static string DropLeadingHeading(string answer)
    {
        var blocks = MarkdownDocument.Parse(answer).Blocks;
        if (blocks.Count == 0 || blocks[0] is not MdHeading heading)
        {
            return answer;
        }
        var lines = answer.Replace("\r\n", "\n", StringComparison.Ordinal).Split('\n').ToList();
        var index = heading.Line - 1;
        if (index < 0 || index >= lines.Count)
        {
            return answer;
        }
        // A setext heading is its text line plus an underline of = or -.
        var count = index + 1 < lines.Count && SetextUnderlineRegex().IsMatch(lines[index + 1].Trim()) && !lines[index].TrimStart().StartsWith('#') ? 2 : 1;
        lines.RemoveRange(index, count);
        return string.Join("\n", lines);
    }

    /// <summary>
    /// Rewrites repo: links outside code (fenced or inline) and optionally labels Mermaid fences — except a diagram that
    /// is drawn (in <paramref name="diagrams"/>), which shows as a picture.
    /// </summary>
    private static string Rewrite(string markdown, bool labelMermaid, IReadOnlyDictionary<string, DiagramImage>? diagrams = null)
    {
        var output = new List<string>();
        string? fence = null;
        var labelAt = -1;
        var indent = "";
        var code = new List<string>();
        foreach (var line in markdown.Replace("\r\n", "\n", StringComparison.Ordinal).Split('\n'))
        {
            var match = FenceRegex().Match(line);
            if (fence is null && match.Success)
            {
                fence = match.Groups[2].Value;
                labelAt = labelMermaid && match.Groups[3].Value.Trim().Split(' ', 2)[0].Equals("mermaid", StringComparison.OrdinalIgnoreCase) ? output.Count : -1;
                indent = match.Groups[1].Value;
                code.Clear();
                output.Add(line);
                continue;
            }
            if (fence is not null)
            {
                var trimmed = line.Trim();
                if (trimmed.Length >= fence.Length && trimmed.All(ch => ch == fence[0]))
                {
                    fence = null;
                    if (labelAt >= 0 && diagrams?.ContainsKey(string.Join("\n", code).Trim()) != true)
                    {
                        // Blank lines around the label keep it out of the paragraph before and from merging with the fence.
                        output.InsertRange(labelAt, ["", indent + "*" + MermaidLabel + "*", ""]);
                    }
                    labelAt = -1;
                }
                else
                {
                    code.Add(line);
                }
                output.Add(line);
                continue;
            }
            output.Add(RewriteLinksOutsideCode(line));
        }
        return string.Join("\n", output);
    }

    private static string RewriteLinksOutsideCode(string line)
    {
        var sb = new StringBuilder();
        var last = 0;
        foreach (Match code in InlineCodeRegex().Matches(line))
        {
            sb.Append(RepoLinkRegex().Replace(line[last..code.Index], RepoLinkReplacement));
            sb.Append(code.Value);
            last = code.Index + code.Length;
        }
        sb.Append(RepoLinkRegex().Replace(line[last..], RepoLinkReplacement));
        return sb.ToString();
    }

    private static string RepoLinkReplacement(Match m)
    {
        var label = m.Groups["label"].Value.Trim();
        var reference = RepoReference(m.Groups["path"].Value, m.Groups["fragment"].Value);
        var span = CodeSpan(reference);
        // Keep a descriptive label ("the indexer") but not one that merely repeats the path.
        var plainLabel = label.Trim('`');
        return plainLabel.Length == 0 || reference.StartsWith(plainLabel, StringComparison.OrdinalIgnoreCase) || plainLabel.StartsWith(m.Groups["path"].Value, StringComparison.OrdinalIgnoreCase)
            ? span
            : $"{label} ({span})";
    }

    /// <summary>"src/a.cs" + "L12-L20" → "src/a.cs:12–20", the same line the app would open.</summary>
    private static string RepoReference(string path, string fragment)
    {
        path = Uri.UnescapeDataString(path);
        var range = LineFragmentRegex().Match(fragment);
        if (!range.Success)
        {
            return path;
        }
        var start = range.Groups[1].Value;
        var end = range.Groups[2].Value;
        return end.Length > 0 && end != start ? $"{path}:{start}–{end}" : $"{path}:{start}";
    }

    private static string CodeSpan(string text) => text.Contains('`') ? $"`` {text} ``" : $"`{text}`";

    /// <summary>The whole export as Markdown. For print (Word/PDF) Mermaid blocks are labelled, since they show as source.</summary>
    private static string DocumentMarkdown(ResponseExport e, bool forPrint, IReadOnlyDictionary<string, DiagramImage>? diagrams = null)
    {
        var sb = new StringBuilder();
        sb.Append("# ").Append(EscapeMarkdown(Title(e))).Append("\n\n");
        sb.Append('*').Append(EscapeMarkdown(HeaderLine(e))).Append("*\n\n");
        if (UsesQuestion(e))
        {
            sb.Append("## Question\n\n");
            foreach (var line in e.Question!.Replace("\r\n", "\n", StringComparison.Ordinal).Trim().Split('\n'))
            {
                sb.Append("> ").Append(line).Append('\n');
            }
            sb.Append("\n## Answer\n\n");
        }
        sb.Append(AnswerBody(e, labelMermaid: forPrint, diagrams)).Append("\n\n");
        var sources = Sources(e).ToList();
        if (sources.Count > 0)
        {
            sb.Append("## Sources\n\n");
            foreach (var c in sources)
            {
                sb.Append("- \\[").Append(c.Number.ToString(CultureInfo.InvariantCulture)).Append("\\] ").Append(CodeSpan(SourceLocation(c)));
                if (!string.IsNullOrWhiteSpace(c.Title))
                {
                    sb.Append(" — ").Append(EscapeMarkdown(c.Title.Trim()));
                }
                sb.Append('\n');
            }
            sb.Append('\n');
        }
        if (!string.IsNullOrWhiteSpace(e.Model))
        {
            sb.Append("---\n\n*Answered by ").Append(EscapeMarkdown(e.Model!)).Append("*\n");
        }
        return sb.ToString().TrimEnd() + "\n";
    }

    private static string EscapeMarkdown(string text)
    {
        var sb = new StringBuilder(text.Length);
        foreach (var c in text)
        {
            if (c is '\\' or '`' or '*' or '_' or '[' or ']' or '<' or '>' or '#' or '|' or '~')
            {
                sb.Append('\\');
            }
            sb.Append(c is '\r' or '\n' ? ' ' : c);
        }
        return sb.ToString();
    }

    // ---------------------------------------------------------------- HTML

    private static string Html(ResponseExport e)
    {
        var citations = e.Citations.Select(c => c.Number).ToHashSet();
        var sb = new StringBuilder();
        sb.Append("<!doctype html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n");
        sb.Append("<title>").Append(H(Title(e))).Append("</title>\n<style>").Append(HtmlStyle).Append("</style>\n</head>\n<body>\n<main>\n");
        sb.Append("<header>\n<h1>").Append(H(Title(e))).Append("</h1>\n<p class=\"meta\">").Append(H(HeaderLine(e))).Append("</p>\n</header>\n");
        if (UsesQuestion(e))
        {
            // The question is the user's own words: shown as typed, never interpreted as Markdown.
            sb.Append("<section class=\"question\">\n<h2>Question</h2>\n<blockquote><p>")
              .Append(H(e.Question!.Replace("\r\n", "\n", StringComparison.Ordinal).Trim()).Replace("\n", "<br>\n", StringComparison.Ordinal))
              .Append("</p></blockquote>\n</section>\n");
        }
        sb.Append("<section class=\"answer\">\n");
        if (UsesQuestion(e))
        {
            sb.Append("<h2>Answer</h2>\n");
        }
        foreach (var block in MarkdownDocument.Parse(AnswerBody(e, labelMermaid: false)).Blocks)
        {
            HtmlBlock(sb, block, citations, UsesQuestion(e) ? 3 : 2);
        }
        sb.Append("</section>\n");
        var sources = Sources(e).ToList();
        if (sources.Count > 0)
        {
            sb.Append("<section class=\"sources\">\n<h2>Sources</h2>\n<ol>\n");
            foreach (var c in sources)
            {
                var n = c.Number.ToString(CultureInfo.InvariantCulture);
                sb.Append("<li id=\"source-").Append(n).Append("\"><span class=\"num\">[").Append(n).Append("]</span> <code>").Append(H(SourceLocation(c))).Append("</code>");
                if (!string.IsNullOrWhiteSpace(c.Title))
                {
                    sb.Append(" — ").Append(H(c.Title.Trim()));
                }
                sb.Append("</li>\n");
            }
            sb.Append("</ol>\n</section>\n");
        }
        if (!string.IsNullOrWhiteSpace(e.Model))
        {
            sb.Append("<footer>Answered by ").Append(H(e.Model!)).Append("</footer>\n");
        }
        sb.Append("</main>\n</body>\n</html>\n");
        return sb.ToString();
    }

    private static void HtmlBlock(StringBuilder sb, MdBlock block, HashSet<int> citations, int minHeading)
    {
        switch (block)
        {
            case MdHeading h:
                // h1 belongs to the document title (and h2 to "Answer" when the question is shown), so the answer's
                // headings sit below them.
                var level = Math.Clamp(h.Level + minHeading - 2, minHeading, 6);
                sb.Append("<h").Append(level).Append('>');
                HtmlInlines(sb, h.Inlines, citations, inLink: false);
                sb.Append("</h").Append(level).Append(">\n");
                break;
            case MdParagraph p:
                sb.Append("<p>");
                HtmlInlines(sb, p.Inlines, citations, inLink: false);
                sb.Append("</p>\n");
                break;
            case MdCode c when IsMermaid(c):
                sb.Append("<figure class=\"mermaid\"><figcaption>").Append(MermaidLabel).Append("</figcaption><pre class=\"mermaid-source\"><code>")
                  .Append(H(c.Code.Trim())).Append("</code></pre></figure>\n");
                break;
            case MdCode c:
                sb.Append("<pre><code");
                if (LanguageRegex().IsMatch(c.Language))
                {
                    sb.Append(" class=\"language-").Append(H(c.Language)).Append('"');
                }
                sb.Append('>').Append(H(c.Code)).Append("</code></pre>\n");
                break;
            case MdQuote q:
                sb.Append("<blockquote>\n");
                foreach (var inner in q.Blocks)
                {
                    HtmlBlock(sb, inner, citations, minHeading);
                }
                sb.Append("</blockquote>\n");
                break;
            case MdList l:
                if (l.Ordered)
                {
                    sb.Append(l.Start == 1 ? "<ol>\n" : $"<ol start=\"{l.Start.ToString(CultureInfo.InvariantCulture)}\">\n");
                }
                else
                {
                    sb.Append("<ul>\n");
                }
                foreach (var item in l.Items)
                {
                    sb.Append("<li>");
                    if (item.Checked is not null)
                    {
                        sb.Append(item.Checked == true ? "☑ " : "☐ ");
                    }
                    // A single paragraph item stays inline so tight lists do not gain paragraph spacing.
                    if (item.Blocks.Count == 1 && item.Blocks[0] is MdParagraph only)
                    {
                        HtmlInlines(sb, only.Inlines, citations, inLink: false);
                    }
                    else
                    {
                        foreach (var inner in item.Blocks)
                        {
                            HtmlBlock(sb, inner, citations, minHeading);
                        }
                    }
                    sb.Append("</li>\n");
                }
                sb.Append(l.Ordered ? "</ol>\n" : "</ul>\n");
                break;
            case MdTable t:
                sb.Append("<div class=\"table-wrap\"><table>\n<thead><tr>");
                for (var i = 0; i < t.Header.Count; i++)
                {
                    sb.Append("<th").Append(Align(t, i)).Append('>');
                    HtmlInlines(sb, t.Header[i], citations, inLink: false);
                    sb.Append("</th>");
                }
                sb.Append("</tr></thead>\n<tbody>\n");
                foreach (var row in t.Rows)
                {
                    sb.Append("<tr>");
                    for (var i = 0; i < row.Count; i++)
                    {
                        sb.Append("<td").Append(Align(t, i)).Append('>');
                        HtmlInlines(sb, row[i], citations, inLink: false);
                        sb.Append("</td>");
                    }
                    sb.Append("</tr>\n");
                }
                sb.Append("</tbody>\n</table></div>\n");
                break;
            case MdRule:
                sb.Append("<hr>\n");
                break;
        }
    }

    private static string Align(MdTable t, int column)
    {
        // Alignments come from the parser as a fixed set of words, so they are safe to place in an attribute.
        var align = column < t.Alignments.Count ? t.Alignments[column] : "left";
        return align is "center" or "right" ? $" style=\"text-align:{align}\"" : "";
    }

    private static void HtmlInlines(StringBuilder sb, IEnumerable<MdInline> inlines, HashSet<int> citations, bool inLink)
    {
        foreach (var inline in inlines)
        {
            switch (inline)
            {
                case MdText t when inLink:
                    sb.Append(H(t.Text));
                    break;
                case MdText t:
                    HtmlTextWithCitations(sb, t.Text, citations);
                    break;
                case MdStrong s:
                    sb.Append("<strong>");
                    HtmlInlines(sb, s.Inlines, citations, inLink);
                    sb.Append("</strong>");
                    break;
                case MdEmphasis em:
                    sb.Append("<em>");
                    HtmlInlines(sb, em.Inlines, citations, inLink);
                    sb.Append("</em>");
                    break;
                case MdStrike s:
                    sb.Append("<del>");
                    HtmlInlines(sb, s.Inlines, citations, inLink);
                    sb.Append("</del>");
                    break;
                case MdInlineCode c:
                    sb.Append("<code>").Append(H(c.Code)).Append("</code>");
                    break;
                case MdLink l when !inLink && IsWebUrl(l.Url):
                    sb.Append("<a href=\"").Append(H(l.Url)).Append("\" rel=\"noopener noreferrer\">");
                    HtmlInlines(sb, l.Inlines, citations, inLink: true);
                    sb.Append("</a>");
                    break;
                case MdLink l:
                    // Any other scheme (javascript:, data:, file:, page:, relative paths) means nothing — or something
                    // unsafe — outside the app, so only the link's text is kept.
                    HtmlInlines(sb, l.Inlines, citations, inLink);
                    break;
                case MdImage i:
                    // Images are not fetched: a saved answer must not call out to other hosts when opened.
                    sb.Append("<span class=\"image\">[image: ").Append(H(i.Alt)).Append("]</span>");
                    break;
                case MdLineBreak:
                    sb.Append("<br>");
                    break;
            }
        }
    }

    private static void HtmlTextWithCitations(StringBuilder sb, string text, HashSet<int> citations)
    {
        var last = 0;
        foreach (Match m in CitationRegex().Matches(text))
        {
            if (!int.TryParse(m.Groups[1].Value, NumberStyles.None, CultureInfo.InvariantCulture, out var n) || !citations.Contains(n))
            {
                continue;
            }
            sb.Append(H(text[last..m.Index]));
            sb.Append("<a class=\"cite\" href=\"#source-").Append(n.ToString(CultureInfo.InvariantCulture)).Append("\">[").Append(n.ToString(CultureInfo.InvariantCulture)).Append("]</a>");
            last = m.Index + m.Length;
        }
        sb.Append(H(text[last..]));
    }

    private static bool IsWebUrl(string url)
        => Uri.TryCreate(url.Trim(), UriKind.Absolute, out var uri) && (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps);

    private static string H(string text) => WebUtility.HtmlEncode(text);

    private const string HtmlStyle = """

        :root { color-scheme: light dark; --bg: #ffffff; --fg: #1f2328; --muted: #59636e; --border: #d1d9e0; --code-bg: #f3f4f6; --head-bg: #eef1f4; --link: #0b57d0; --quote: #0b57d0; }
        @media (prefers-color-scheme: dark) {
          :root { --bg: #16181c; --fg: #e6e8eb; --muted: #9aa4af; --border: #3a4049; --code-bg: #22262c; --head-bg: #2a2f36; --link: #7cacf8; --quote: #7cacf8; }
        }
        * { box-sizing: border-box; }
        html { -webkit-text-size-adjust: 100%; }
        body { margin: 0; background: var(--bg); color: var(--fg); font: 16px/1.6 "Segoe UI", system-ui, -apple-system, Roboto, "Helvetica Neue", Arial, sans-serif; }
        main { max-width: 820px; margin: 0 auto; padding: 32px 20px 48px; overflow-wrap: break-word; }
        h1 { font-size: 1.8em; line-height: 1.25; margin: 0 0 6px; }
        h2 { font-size: 1.35em; margin: 1.6em 0 0.6em; padding-bottom: 4px; border-bottom: 1px solid var(--border); }
        h3 { font-size: 1.15em; margin: 1.4em 0 0.5em; }
        h4, h5, h6 { font-size: 1em; margin: 1.2em 0 0.4em; }
        .meta { color: var(--muted); font-size: 0.9em; margin: 0 0 24px; }
        a { color: var(--link); }
        code { font-family: Consolas, "Cascadia Mono", Menlo, monospace; font-size: 0.9em; background: var(--code-bg); padding: 1px 4px; border-radius: 4px; }
        pre { background: var(--code-bg); padding: 12px 14px; border-radius: 6px; overflow-x: auto; white-space: pre-wrap; word-break: break-word; }
        pre code { background: none; padding: 0; font-size: 0.875em; }
        blockquote { margin: 0 0 1em; padding: 2px 16px; border-left: 4px solid var(--quote); color: var(--muted); }
        .table-wrap { overflow-x: auto; margin: 0 0 1em; }
        table { border-collapse: collapse; min-width: 100%; }
        th, td { border: 1px solid var(--border); padding: 6px 10px; text-align: left; vertical-align: top; }
        th { background: var(--head-bg); }
        figure.mermaid { margin: 0 0 1em; }
        figcaption { color: var(--muted); font-size: 0.85em; margin-bottom: 4px; }
        .sources ol { list-style: none; padding-left: 0; }
        .sources li { margin: 4px 0; }
        .sources .num, a.cite { font-weight: 600; }
        a.cite { text-decoration: none; }
        footer { margin-top: 32px; padding-top: 12px; border-top: 1px solid var(--border); color: var(--muted); font-size: 0.85em; }
        @media (max-width: 600px) { main { padding: 20px 16px 32px; } h1 { font-size: 1.5em; } }

        """;

    // ---------------------------------------------------------------- plain text

    private static string PlainText(ResponseExport e)
    {
        var sb = new StringBuilder();
        var title = Title(e);
        sb.Append(title).Append('\n').Append(new string('=', Math.Min(title.Length, 80))).Append("\n\n");
        sb.Append(HeaderLine(e)).Append("\n\n");
        if (UsesQuestion(e))
        {
            sb.Append("Question\n--------\n\n").Append(e.Question!.Replace("\r\n", "\n", StringComparison.Ordinal).Trim()).Append("\n\n");
            sb.Append("Answer\n------\n\n");
        }
        foreach (var block in MarkdownDocument.Parse(AnswerBody(e, labelMermaid: false)).Blocks)
        {
            TextBlock(sb, block, "");
        }
        var sources = Sources(e).ToList();
        if (sources.Count > 0)
        {
            sb.Append("Sources\n-------\n\n");
            foreach (var c in sources)
            {
                sb.Append('[').Append(c.Number.ToString(CultureInfo.InvariantCulture)).Append("] ").Append(SourceLocation(c));
                if (!string.IsNullOrWhiteSpace(c.Title))
                {
                    sb.Append(" — ").Append(c.Title.Trim());
                }
                sb.Append('\n');
            }
            sb.Append('\n');
        }
        if (!string.IsNullOrWhiteSpace(e.Model))
        {
            sb.Append("Answered by ").Append(e.Model).Append('\n');
        }
        // One line ending throughout: CRLF, as Notepad and other Windows tools expect.
        return sb.ToString().TrimEnd().Replace("\n", "\r\n", StringComparison.Ordinal) + "\r\n";
    }

    private static void TextBlock(StringBuilder sb, MdBlock block, string prefix)
    {
        switch (block)
        {
            case MdHeading h:
                var text = TextInlines(h.Inlines);
                sb.Append(prefix).Append(text).Append('\n');
                if (h.Level <= 2)
                {
                    sb.Append(prefix).Append(new string('-', Math.Min(Math.Max(text.Length, 3), 80))).Append('\n');
                }
                sb.Append(prefix.TrimEnd()).Append('\n');
                break;
            case MdParagraph p:
                sb.Append(prefix).Append(TextInlines(p.Inlines).Replace("\n", "\n" + prefix, StringComparison.Ordinal)).Append('\n').Append(prefix.TrimEnd()).Append('\n');
                break;
            case MdCode c:
                if (IsMermaid(c))
                {
                    sb.Append(prefix).Append(MermaidLabel).Append(":\n");
                }
                foreach (var line in (IsMermaid(c) ? c.Code.Trim() : c.Code).Split('\n'))
                {
                    sb.Append(prefix).Append("    ").Append(line).Append('\n');
                }
                sb.Append(prefix.TrimEnd()).Append('\n');
                break;
            case MdQuote q:
                foreach (var inner in q.Blocks)
                {
                    TextBlock(sb, inner, prefix + "> ");
                }
                break;
            case MdList l:
                var n = l.Start;
                foreach (var item in l.Items)
                {
                    var marker = l.Ordered ? $"{n++}. " : item.Checked is null ? "- " : item.Checked == true ? "- [x] " : "- [ ] ";
                    var continuation = prefix + new string(' ', marker.Length);
                    var first = true;
                    foreach (var inner in item.Blocks)
                    {
                        if (first && inner is MdParagraph para)
                        {
                            sb.Append(prefix).Append(marker).Append(TextInlines(para.Inlines).Replace("\n", "\n" + continuation, StringComparison.Ordinal)).Append('\n');
                        }
                        else
                        {
                            var nested = new StringBuilder();
                            TextBlock(nested, inner, continuation);
                            // Nested blocks inside a tight list do not need their own trailing blank line.
                            sb.Append(nested.ToString().TrimEnd(' ', '\n')).Append('\n');
                        }
                        first = false;
                    }
                }
                sb.Append(prefix.TrimEnd()).Append('\n');
                break;
            case MdTable t:
                var rows = new List<List<string>> { t.Header.Select(TextInlines).ToList() };
                rows.AddRange(t.Rows.Select(r => r.Select(TextInlines).ToList()));
                var columns = rows.Max(r => r.Count);
                var widths = Enumerable.Range(0, columns).Select(i => rows.Max(r => i < r.Count ? r[i].Length : 0)).ToArray();
                for (var r = 0; r < rows.Count; r++)
                {
                    var cells = Enumerable.Range(0, columns).Select(i => (i < rows[r].Count ? rows[r][i] : "").PadRight(widths[i]));
                    sb.Append(prefix).Append(string.Join(" | ", cells).TrimEnd()).Append('\n');
                    if (r == 0)
                    {
                        sb.Append(prefix).Append(string.Join("-+-", widths.Select(w => new string('-', Math.Max(w, 1))))).Append('\n');
                    }
                }
                sb.Append(prefix.TrimEnd()).Append('\n');
                break;
            case MdRule:
                sb.Append(prefix).Append(new string('-', 40)).Append('\n').Append(prefix.TrimEnd()).Append('\n');
                break;
        }
    }

    private static string TextInlines(IEnumerable<MdInline> inlines)
    {
        var sb = new StringBuilder();
        foreach (var inline in inlines)
        {
            switch (inline)
            {
                case MdText t: sb.Append(t.Text); break;
                case MdStrong s: sb.Append(TextInlines(s.Inlines)); break;
                case MdEmphasis em: sb.Append(TextInlines(em.Inlines)); break;
                case MdStrike s: sb.Append(TextInlines(s.Inlines)); break;
                case MdInlineCode c: sb.Append(c.Code); break;
                case MdLink l when IsWebUrl(l.Url):
                    var label = TextInlines(l.Inlines);
                    sb.Append(label == l.Url ? l.Url : $"{label} ({l.Url})");
                    break;
                case MdLink l: sb.Append(TextInlines(l.Inlines)); break;
                case MdImage i: sb.Append("[image: ").Append(i.Alt).Append(']'); break;
                case MdLineBreak: sb.Append('\n'); break;
            }
        }
        return sb.ToString();
    }

    // ---------------------------------------------------------------- helpers

    private static bool IsMermaid(MdCode code) => code.Language.Equals("mermaid", StringComparison.OrdinalIgnoreCase);

    private static IEnumerable<MdBlock> Walk(IEnumerable<MdBlock> blocks)
    {
        foreach (var block in blocks)
        {
            yield return block;
            IEnumerable<MdBlock> inner = block switch
            {
                MdQuote q => q.Blocks,
                MdList l => l.Items.SelectMany(i => i.Blocks),
                _ => [],
            };
            foreach (var nested in Walk(inner))
            {
                yield return nested;
            }
        }
    }

    private static bool IsReserved(string name)
    {
        // Windows treats these device names as reserved with or without an extension ("CON", "con.txt").
        var stem = name.Split('.')[0].Trim().ToUpperInvariant();
        return stem is "CON" or "PRN" or "AUX" or "NUL" or "CLOCK$"
            || (stem.Length == 4 && (stem.StartsWith("COM", StringComparison.Ordinal) || stem.StartsWith("LPT", StringComparison.Ordinal)) && stem[3] is >= '0' and <= '9');
    }

    [GeneratedRegex(@"\s+")]
    private static partial Regex WhitespaceRegex();

    [GeneratedRegex(@"[.!?](?=\s|$)")]
    private static partial Regex SentenceEndRegex();

    [GeneratedRegex(@"^(=+|-+)$")]
    private static partial Regex SetextUnderlineRegex();

    [GeneratedRegex(@"^(\s*)(```+|~~~+)(.*)$")]
    private static partial Regex FenceRegex();

    [GeneratedRegex(@"(`+)(?:(?!\1).)+?\1")]
    private static partial Regex InlineCodeRegex();

    // [label](repo:path#L12-L20 "optional title"), optionally as an image (!) or with <angle brackets>.
    [GeneratedRegex(@"!?\[(?<label>[^\]]*)\]\(\s*<?repo:(?<path>[^)\s#>]+)(?:#(?<fragment>[^)\s>]*))?>?(?:\s+""[^""]*"")?\s*\)")]
    private static partial Regex RepoLinkRegex();

    [GeneratedRegex(@"^[Ll]?(\d+)(?:-[Ll]?(\d+))?$")]
    private static partial Regex LineFragmentRegex();

    [GeneratedRegex(@"\[(\d{1,3})\]")]
    private static partial Regex CitationRegex();

    [GeneratedRegex(@"^[A-Za-z0-9_+#.-]{1,32}$")]
    private static partial Regex LanguageRegex();
}
