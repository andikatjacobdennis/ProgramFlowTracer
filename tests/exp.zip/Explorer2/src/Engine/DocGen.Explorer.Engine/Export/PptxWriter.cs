using System.Globalization;
using System.IO.Compression;
using System.Text;
using DocGen.Explorer.Engine.Markdown;

namespace DocGen.Explorer.Engine.Export;

/// <summary>A drawn diagram to put in a document in place of its source: PNG bytes and its size in device-independent pixels (1/96 inch).</summary>
public sealed record DiagramImage(byte[] Png, double Width, double Height);

/// <summary>What a deck has besides its Markdown: a fallback title, the title slide's small print and the closing Sources slide.</summary>
/// <param name="Diagrams">Drawn Mermaid diagrams by their source (trimmed): each becomes a picture; a diagram not here shows as its source.</param>
public sealed record DeckOptions(
    string? Title = null,
    IReadOnlyList<string>? Subtitle = null,
    IReadOnlyList<string>? Sources = null,
    IReadOnlyDictionary<string, DiagramImage>? Diagrams = null);

/// <summary>
/// Writes Markdown as a PowerPoint (.pptx) deck, 16:9. The first "# " heading is the title slide (a short paragraph
/// under it is its subtitle); every "## " heading starts a slide; a later "# " heading is a section divider and "---"
/// starts an untitled slide. A quote that begins "Notes:" holds the slide's speaker notes. Lists, paragraphs and "### "
/// sub-headings are the slide's text; tables, code and Mermaid diagrams (as pictures when drawn) are placed below.
/// A slide that holds more than fits is first set in smaller type, then continued on the next slide.
/// </summary>
public static class PptxWriter
{
    // Layout in points (the slide is 13.333 × 7.5 inches).
    private const double SlideW = 960, SlideH = 540, MarginX = 44, ContentW = SlideW - 2 * MarginX;
    private const double TitleY = 26, TitleH = 54, ContentTop = 100, ContentBottom = 498, Gap = 10;
    private const double Available = ContentBottom - ContentTop;
    private static readonly int[] BaseSizes = [20, 18, 16];

    private const string Ink = "1F2328", Muted = "6B7480", Accent = "0B57D0", Navy = "0B2545", CodeInk = "24292F", InlineCode = "9A3412";
    private const string MermaidLabel = "Mermaid diagram (source)";

    public static byte[] Write(string markdown, DeckOptions? options = null)
    {
        options ??= new DeckOptions();
        var deck = Plan(markdown, options);
        var pages = new List<Page>();
        foreach (var slide in deck.Slides)
        {
            pages.AddRange(slide.Kind == SlideKind.Content ? Layout(slide, options.Diagrams) : [new Page(slide, 0, 20, [])]);
        }

        using var stream = new MemoryStream();
        using (var zip = new ZipArchive(stream, ZipArchiveMode.Create, leaveOpen: true))
        {
            var media = 0;
            var notes = new List<int>();
            for (var i = 0; i < pages.Count; i++)
            {
                var number = i + 1;
                var rels = new SlideRels();
                var xml = SlideXml(pages[i], deck.Title, number, rels, png =>
                {
                    media++;
                    AddBytes(zip, $"ppt/media/image{media}.png", png);
                    return $"../media/image{media}.png";
                });
                var notesText = pages[i].Part == 0 ? string.Join("\n", pages[i].Slide.Notes) : "";
                if (notesText.Trim().Length > 0)
                {
                    notes.Add(number);
                    Add(zip, $"ppt/notesSlides/notesSlide{number}.xml", NotesSlide(notesText));
                    Add(zip, $"ppt/notesSlides/_rels/notesSlide{number}.xml.rels", Rels(
                        ("rId1", "notesMaster", "../notesMasters/notesMaster1.xml", false),
                        ("rId2", "slide", $"../slides/slide{number}.xml", false)));
                    rels.Items.Add(("rIdNotes", "notesSlide", $"../notesSlides/notesSlide{number}.xml", false));
                }
                Add(zip, $"ppt/slides/slide{number}.xml", xml);
                Add(zip, $"ppt/slides/_rels/slide{number}.xml.rels", Rels([("rId1", "slideLayout", "../slideLayouts/slideLayout1.xml", false), .. rels.Items]));
            }
            Add(zip, "[Content_Types].xml", ContentTypes(pages.Count, notes));
            Add(zip, "_rels/.rels", Rels(
                ("rId1", "officeDocument", "ppt/presentation.xml", false),
                ("rId2", "http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties", "docProps/core.xml", false)));
            Add(zip, "docProps/core.xml", Core(deck.Title));
            Add(zip, "ppt/presentation.xml", Presentation(pages.Count));
            Add(zip, "ppt/_rels/presentation.xml.rels", Rels([
                ("rId1", "slideMaster", "slideMasters/slideMaster1.xml", false),
                ("rId2", "notesMaster", "notesMasters/notesMaster1.xml", false),
                ("rId3", "theme", "theme/theme1.xml", false),
                ("rId4", "presProps", "presProps.xml", false),
                ("rId5", "viewProps", "viewProps.xml", false),
                ("rId6", "tableStyles", "tableStyles.xml", false),
                .. Enumerable.Range(1, pages.Count).Select(n => ($"rIdS{n}", "slide", $"slides/slide{n}.xml", false))]));
            Add(zip, "ppt/presProps.xml", $"{Decl}<p:presentationPr {Ns}/>");
            Add(zip, "ppt/viewProps.xml", $"{Decl}<p:viewPr {Ns}/>");
            Add(zip, "ppt/tableStyles.xml", $"{Decl}<a:tblStyleLst xmlns:a=\"{NsA}\" def=\"{{5C22544A-7EE6-4342-B048-85BDC9FD1C3A}}\"/>");
            Add(zip, "ppt/slideMasters/slideMaster1.xml", Master);
            Add(zip, "ppt/slideMasters/_rels/slideMaster1.xml.rels", Rels(
                ("rId1", "slideLayout", "../slideLayouts/slideLayout1.xml", false),
                ("rId2", "theme", "../theme/theme1.xml", false)));
            Add(zip, "ppt/slideLayouts/slideLayout1.xml", Layout1);
            Add(zip, "ppt/slideLayouts/_rels/slideLayout1.xml.rels", Rels(("rId1", "slideMaster", "../slideMasters/slideMaster1.xml", false)));
            Add(zip, "ppt/notesMasters/notesMaster1.xml", NotesMaster);
            Add(zip, "ppt/notesMasters/_rels/notesMaster1.xml.rels", Rels(("rId1", "theme", "../theme/theme2.xml", false)));
            Add(zip, "ppt/theme/theme1.xml", Theme("DocGen"));
            Add(zip, "ppt/theme/theme2.xml", Theme("DocGen Notes"));
        }
        return stream.ToArray();
    }

    /// <summary>How many slides the Markdown makes (for a summary before saving, and for tests).</summary>
    public static int SlideCount(string markdown, DeckOptions? options = null)
    {
        options ??= new DeckOptions();
        return Plan(markdown, options).Slides.Sum(s => s.Kind == SlideKind.Content ? Layout(s, options.Diagrams).Count : 1);
    }

    // ---------------------------------------------------------------- planning: Markdown → slides

    private enum SlideKind { Title, Section, Content }

    private sealed class Slide(SlideKind kind, string title)
    {
        public SlideKind Kind { get; set; } = kind;
        public string Title { get; } = title;
        public List<MdBlock> Blocks { get; } = [];
        public List<string> Notes { get; } = [];
        public IReadOnlyList<string> Small { get; init; } = [];
    }

    private sealed record Deck(string Title, List<Slide> Slides);

    private static Deck Plan(string markdown, DeckOptions options)
    {
        var blocks = MarkdownDocument.Parse(markdown).Blocks;
        var title = blocks.OfType<MdHeading>().FirstOrDefault(h => h.Level == 1)?.Text.Trim() is { Length: > 0 } h1 ? h1
            : options.Title is { Length: > 0 } t ? t.Trim() : "Presentation";
        var titleSlide = new Slide(SlideKind.Title, title) { Small = options.Subtitle ?? [] };
        var slides = new List<Slide> { titleSlide };
        Slide? current = null;
        var seenTitle = false;
        var titleClosed = false;
        foreach (var block in blocks)
        {
            switch (block)
            {
                case MdHeading { Level: 1 } when !seenTitle && current is null:
                    seenTitle = true;
                    break;
                case MdHeading { Level: 1 } h:
                    current = new Slide(SlideKind.Section, h.Text.Trim());
                    slides.Add(current);
                    titleClosed = true;
                    break;
                case MdHeading { Level: 2 } h:
                    current = new Slide(SlideKind.Content, h.Text.Trim());
                    slides.Add(current);
                    titleClosed = true;
                    break;
                case MdRule:
                    current = null;
                    titleClosed = true;
                    break;
                case MdQuote q when NotesOf(q) is { } notes:
                    (current ?? titleSlide).Notes.Add(notes);
                    break;
                default:
                    if (current is null)
                    {
                        // A short paragraph under the deck's title is its subtitle.
                        if (!titleClosed && block is MdParagraph p && titleSlide.Blocks.Count < 2 && MarkdownDocument.PlainText(p.Inlines).Length <= 280)
                        {
                            titleSlide.Blocks.Add(block);
                            break;
                        }
                        current = new Slide(SlideKind.Content, titleClosed ? "" : "Overview");
                        slides.Add(current);
                        titleClosed = true;
                    }
                    // A divider with content under it is an ordinary slide.
                    current.Kind = SlideKind.Content;
                    current.Blocks.Add(block);
                    break;
            }
        }
        if (options.Sources is { Count: > 0 } sources)
        {
            var sourcesSlide = new Slide(SlideKind.Content, "Sources");
            sourcesSlide.Blocks.Add(new MdList(0, false, 1, sources.Select(s => new MdListItem([new MdParagraph(0, [new MdText(s)])], null)).ToList()));
            slides.Add(sourcesSlide);
        }
        // A Content slide with nothing on it (a heading followed by another) still shows its title.
        return new Deck(title, slides);
    }

    /// <summary>A quote that begins "Notes:" or "Speaker notes:": the slide's speaker notes (plain text).</summary>
    private static string? NotesOf(MdQuote quote)
    {
        if (quote.Blocks.FirstOrDefault() is not MdParagraph first)
        {
            return null;
        }
        var text = MarkdownDocument.PlainText(first.Inlines).TrimStart();
        string? rest = null;
        foreach (var prefix in new[] { "Speaker notes:", "Notes:", "Note:" })
        {
            if (text.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            {
                rest = text[prefix.Length..].Trim();
                break;
            }
        }
        if (rest is null)
        {
            return null;
        }
        var lines = new List<string>();
        if (rest.Length > 0)
        {
            lines.Add(rest);
        }
        foreach (var block in quote.Blocks.Skip(1))
        {
            lines.AddRange(PlainLines(block));
        }
        return string.Join("\n", lines);
    }

    private static IEnumerable<string> PlainLines(MdBlock block) => block switch
    {
        MdParagraph p => [MarkdownDocument.PlainText(p.Inlines)],
        MdHeading h => [h.Text],
        MdList l => l.Items.SelectMany(i => i.Blocks.SelectMany(PlainLines)).Select(t => "• " + t),
        MdQuote q => q.Blocks.SelectMany(PlainLines),
        MdCode c => c.Code.Replace("\r", "", StringComparison.Ordinal).Split('\n'),
        _ => [],
    };

    // ---------------------------------------------------------------- layout: a slide's blocks → placed shapes on pages

    private enum Bullet { None, Dot, Number, Open, Done }

    private abstract record Item;
    private sealed record Para(IReadOnlyList<MdInline> Inlines, int Level, Bullet Bullet, int Number, bool Heading, bool Quote) : Item;
    private sealed record CodeItem(IReadOnlyList<string> Lines, string? Label) : Item;
    private sealed record TableItem(MdTable Table) : Item;
    private sealed record PictureItem(DiagramImage Image) : Item;

    private abstract record Placed(double Y, double Height);
    private sealed record TextBox(double Y, double Height, List<Para> Paras) : Placed(Y, Height);
    private sealed record CodeBox(double Y, double Height, IReadOnlyList<string> Lines, string? Label, double Size) : Placed(Y, Height);
    private sealed record TableBox(double Y, double Height, MdTable Table, IReadOnlyList<IReadOnlyList<IReadOnlyList<MdInline>>> Rows, double[] Widths, double[] RowHeights, double Size, int FirstRow)
        : Placed(Y, Height);
    private sealed record PictureBox(double Y, double Height, double Width, DiagramImage Image) : Placed(Y, Height);

    private sealed record Page(Slide Slide, int Part, int Size, List<Placed> Shapes);

    private static List<Item> Items(Slide slide, IReadOnlyDictionary<string, DiagramImage>? diagrams)
    {
        var items = new List<Item>();
        foreach (var block in slide.Blocks)
        {
            Flatten(block, 0, false, items, diagrams);
        }
        return items;
    }

    private static void Flatten(MdBlock block, int level, bool quote, List<Item> items, IReadOnlyDictionary<string, DiagramImage>? diagrams)
    {
        switch (block)
        {
            case MdHeading h:
                items.Add(new Para(h.Inlines, 0, Bullet.None, 0, Heading: true, quote));
                break;
            case MdParagraph p:
                items.Add(new Para(p.Inlines, level, Bullet.None, 0, Heading: false, quote));
                break;
            case MdList l:
                var number = l.Start;
                foreach (var item in l.Items)
                {
                    var bullet = l.Ordered ? Bullet.Number : item.Checked switch { true => Bullet.Done, false => Bullet.Open, _ => Bullet.Dot };
                    var rest = item.Blocks.AsEnumerable();
                    if (item.Blocks.FirstOrDefault() is MdParagraph first)
                    {
                        items.Add(new Para(first.Inlines, level, bullet, number, false, quote));
                        rest = item.Blocks.Skip(1);
                    }
                    number++;
                    foreach (var inner in rest)
                    {
                        Flatten(inner, level + 1, quote, items, diagrams);
                    }
                }
                break;
            case MdQuote q:
                foreach (var inner in q.Blocks)
                {
                    Flatten(inner, level, true, items, diagrams);
                }
                break;
            case MdCode c:
                var code = c.Code.Replace("\r", "", StringComparison.Ordinal).TrimEnd('\n');
                var mermaid = c.Language.Trim().Split(' ', 2)[0].Equals("mermaid", StringComparison.OrdinalIgnoreCase);
                if (mermaid && diagrams?.GetValueOrDefault(c.Code.Trim()) is { Png.Length: > 0 } image)
                {
                    items.Add(new PictureItem(image));
                }
                else
                {
                    items.Add(new CodeItem(code.Split('\n').Select(l => l.Replace("\t", "    ", StringComparison.Ordinal)).ToList(), mermaid ? MermaidLabel : null));
                }
                break;
            case MdTable t:
                items.Add(new TableItem(t));
                break;
        }
    }

    /// <summary>The slide's pages at the largest type that fits on one; else continued over several at the smallest.</summary>
    private static List<Page> Layout(Slide slide, IReadOnlyDictionary<string, DiagramImage>? diagrams)
    {
        var items = Items(slide, diagrams);
        List<Page>? pages = null;
        foreach (var size in BaseSizes)
        {
            pages = Paginate(slide, items, size);
            if (pages.Count == 1)
            {
                break;
            }
        }
        return pages!;
    }

    private static List<Page> Paginate(Slide slide, List<Item> items, int size)
    {
        var pages = new List<Page> { new(slide, 0, size, []) };
        var y = 0.0;
        Page Current() => pages[^1];
        void NewPage()
        {
            pages.Add(new Page(slide, pages.Count, size, []));
            y = 0;
        }
        double Room() => Available - y;
        void Place(Placed shape)
        {
            Current().Shapes.Add(shape);
            y = shape.Y + shape.Height + Gap;
        }

        foreach (var item in items)
        {
            switch (item)
            {
                case Para para:
                {
                    var h = ParaHeight(para, size);
                    if (h > Room() && Current().Shapes.Count > 0)
                    {
                        NewPage();
                    }
                    if (Current().Shapes.LastOrDefault() is TextBox box && Math.Abs(box.Y + box.Height + Gap - y) < 0.01)
                    {
                        // Consecutive text stays in one text box.
                        box.Paras.Add(para);
                        Current().Shapes[^1] = box with { Height = box.Height + h };
                        y += h;
                    }
                    else
                    {
                        Place(new TextBox(y, h, [para]));
                    }
                    break;
                }
                case CodeItem code:
                {
                    var codeSize = CodeSize(size);
                    var lineH = codeSize * 1.2;
                    var labelH = code.Label is null ? 0 : codeSize * 1.4;
                    var wrapped = code.Lines.Select(l => Math.Max(1, (int)Math.Ceiling(l.Length / ((ContentW - 16) / (codeSize * 0.55))))).ToList();
                    var index = 0;
                    while (index < code.Lines.Count)
                    {
                        if (Room() < labelH + 16 + 3 * lineH && Current().Shapes.Count > 0)
                        {
                            NewPage();
                        }
                        var fit = index;
                        var used = labelH + 16;
                        while (fit < code.Lines.Count && (used + wrapped[fit] * lineH <= Room() || fit == index))
                        {
                            used += wrapped[fit] * lineH;
                            fit++;
                        }
                        Place(new CodeBox(y, used, code.Lines.Skip(index).Take(fit - index).ToList(), index == 0 ? code.Label : null, codeSize));
                        index = fit;
                        if (index < code.Lines.Count)
                        {
                            NewPage();
                        }
                    }
                    break;
                }
                case TableItem table:
                {
                    var t = table.Table;
                    var tableSize = Math.Max(11, size - 6);
                    var widths = ColumnWidths(t);
                    var headerH = RowHeight(t.Header, widths, tableSize);
                    var rowHeights = t.Rows.Select(r => RowHeight(r, widths, tableSize)).ToList();
                    var index = 0;
                    do
                    {
                        if (Room() < headerH + (rowHeights.Count > 0 ? rowHeights[index] : 0) && Current().Shapes.Count > 0)
                        {
                            NewPage();
                        }
                        var used = headerH;
                        var fit = index;
                        while (fit < t.Rows.Count && (used + rowHeights[fit] <= Room() || fit == index))
                        {
                            used += rowHeights[fit];
                            fit++;
                        }
                        Place(new TableBox(y, used, t, t.Rows.Skip(index).Take(fit - index).ToList(), widths,
                            [headerH, .. rowHeights.Skip(index).Take(fit - index)], tableSize, index));
                        index = fit;
                        if (index < t.Rows.Count)
                        {
                            NewPage();
                        }
                    }
                    while (index < t.Rows.Count);
                    break;
                }
                case PictureItem picture:
                {
                    // Device-independent pixels to points; enlarged up to twice to fill the slide, never past it.
                    var w = picture.Image.Width * 0.75;
                    var h = picture.Image.Height * 0.75;
                    if (w <= 0 || h <= 0)
                    {
                        break;
                    }
                    if (Room() < Available * 0.45 && Current().Shapes.Count > 0)
                    {
                        NewPage();
                    }
                    var scale = Math.Min(2, Math.Min(ContentW / w, Room() / h));
                    Place(new PictureBox(y, h * scale, w * scale, picture.Image));
                    break;
                }
            }
        }
        return pages;
    }

    private static int CodeSize(int size) => size switch { >= 20 => 14, >= 18 => 13, _ => 12 };

    private static double ParaSize(Para p, int size) => p.Heading ? size + 2 : p.Level > 0 || p.Quote ? size - 2 : size;

    private static double Indent(Para p) => p.Level * 24 + (p.Bullet == Bullet.None ? 0 : 20);

    private static double ParaHeight(Para p, int size)
    {
        var s = ParaSize(p, size);
        var lines = TextLines(MarkdownDocument.PlainText(p.Inlines), ContentW - Indent(p), s);
        return lines * s * 1.2 + s * 0.4 + (p.Heading ? s * 0.4 : 0);
    }

    /// <summary>Lines a text takes in a width (an average character is about half the type size wide).</summary>
    private static int TextLines(string text, double width, double size)
    {
        var perLine = Math.Max(8, width / (size * 0.5));
        return text.Split('\n').Sum(line => Math.Max(1, (int)Math.Ceiling(line.Length / perLine)));
    }

    private static double[] ColumnWidths(MdTable t)
    {
        var columns = Math.Max(t.Header.Count, t.Rows.Count == 0 ? 0 : t.Rows.Max(r => r.Count));
        var weights = Enumerable.Range(0, columns).Select(c =>
        {
            var longest = t.Rows.Select(r => c < r.Count ? MarkdownDocument.PlainText(r[c]).Length : 0)
                .Append(c < t.Header.Count ? MarkdownDocument.PlainText(t.Header[c]).Length : 0).Max();
            return Math.Clamp(longest, 6, 60);
        }).Select(w => (double)w).ToArray();
        var total = weights.Sum();
        return weights.Select(w => ContentW * w / total).ToArray();
    }

    private static double RowHeight(IReadOnlyList<IReadOnlyList<MdInline>> row, double[] widths, double size)
    {
        var lines = 1;
        for (var c = 0; c < widths.Length && c < row.Count; c++)
        {
            lines = Math.Max(lines, TextLines(MarkdownDocument.PlainText(row[c]), widths[c] - 12, size));
        }
        return lines * size * 1.2 + 10;
    }

    // ---------------------------------------------------------------- slide XML

    private sealed class SlideRels
    {
        public List<(string Id, string Type, string Target, bool External)> Items { get; } = [];

        public string Link(string url)
        {
            var id = $"rIdL{Items.Count + 1}";
            Items.Add((id, "hyperlink", url, true));
            return id;
        }

        public string Image(string target)
        {
            var id = $"rIdI{Items.Count + 1}";
            Items.Add((id, "image", target, false));
            return id;
        }
    }

    private static string SlideXml(Page page, string deckTitle, int number, SlideRels rels, Func<byte[], string> addImage)
    {
        var slide = page.Slide;
        var sb = new StringBuilder();
        var id = 1;
        var dark = slide.Kind is SlideKind.Title or SlideKind.Section;
        sb.Append(Decl).Append("<p:sld ").Append(Ns).Append("><p:cSld>");
        if (dark)
        {
            sb.Append($"<p:bg><p:bgPr><a:solidFill><a:srgbClr val=\"{Navy}\"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>");
        }
        sb.Append("<p:spTree><p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>")
          .Append("<p:grpSpPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"0\" cy=\"0\"/><a:chOff x=\"0\" y=\"0\"/><a:chExt cx=\"0\" cy=\"0\"/></a:xfrm></p:grpSpPr>");
        switch (slide.Kind)
        {
            case SlideKind.Title:
            {
                sb.Append(TitleShape(++id, slide.Title, 64, 150, SlideW - 128, 130, 40, "FFFFFF", "b"));
                sb.Append(Rect(++id, 64, 292, 72, 4, "4C8DF6"));
                var paras = new StringBuilder();
                foreach (var block in slide.Blocks.OfType<MdParagraph>())
                {
                    paras.Append(Paragraph(block.Inlines, 20, "E6ECF5", rels, spaceAfter: 8));
                }
                if (paras.Length > 0)
                {
                    sb.Append(TextShape(++id, "Subtitle", 64, 310, SlideW - 128, 110, paras.ToString()));
                }
                if (slide.Small.Count > 0)
                {
                    var small = string.Concat(slide.Small.Select(line => Paragraph([new MdText(line)], 12, "9FB0C8", rels, spaceAfter: 2)));
                    sb.Append(TextShape(++id, "Details", 64, 440, SlideW - 128, 70, small, anchor: "b"));
                }
                break;
            }
            case SlideKind.Section:
                sb.Append(TitleShape(++id, slide.Title, 64, 200, SlideW - 128, 110, 36, "FFFFFF", "b"));
                sb.Append(Rect(++id, 64, 322, 72, 4, "4C8DF6"));
                break;
            default:
            {
                var title = slide.Title.Length == 0 ? "" : page.Part > 0 ? slide.Title + " (continued)" : slide.Title;
                if (title.Length > 0)
                {
                    sb.Append(TitleShape(++id, title, MarginX, TitleY, ContentW, TitleH, 28, Ink, "b"));
                    sb.Append(Rect(++id, MarginX, TitleY + TitleH + 6, 56, 3, Accent));
                }
                foreach (var shape in page.Shapes)
                {
                    sb.Append(Shape(++id, shape, page.Size, rels, addImage));
                }
                break;
            }
        }
        if (slide.Kind != SlideKind.Title)
        {
            var footer = dark ? "9FB0C8" : "8A94A3";
            sb.Append(TextShape(++id, "Footer", MarginX, SlideH - 30, ContentW - 60, 18, Paragraph([new MdText(deckTitle)], 10, footer, rels), anchor: "ctr"));
            sb.Append(TextShape(++id, "Slide number", SlideW - MarginX - 60, SlideH - 30, 60, 18,
                Paragraph([new MdText(number.ToString(CultureInfo.InvariantCulture))], 10, footer, rels, align: "r"), anchor: "ctr"));
        }
        sb.Append("</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>");
        return sb.ToString();
    }

    private static string Shape(int id, Placed shape, int size, SlideRels rels, Func<byte[], string> addImage)
    {
        var top = ContentTop + shape.Y;
        switch (shape)
        {
            case TextBox box:
            {
                var paras = new StringBuilder();
                foreach (var p in box.Paras)
                {
                    paras.Append(BodyParagraph(p, size, rels));
                }
                return TextShape(id, $"Text {id}", MarginX, top, ContentW, box.Height, paras.ToString());
            }
            case CodeBox code:
            {
                var paras = new StringBuilder();
                if (code.Label is not null)
                {
                    paras.Append(Paragraph([new MdEmphasis([new MdText(code.Label)])], code.Size, Muted, rels, spaceAfter: 4));
                }
                foreach (var line in code.Lines)
                {
                    paras.Append(line.Length == 0
                        ? $"<a:p><a:endParaRPr lang=\"en-US\" sz=\"{Hundredths(code.Size)}\" dirty=\"0\"/></a:p>"
                        : $"<a:p><a:r>{RunProps(code.Size, CodeInk, false, false, false, mono: true, null)}<a:t>{Escape(line)}</a:t></a:r></a:p>");
                }
                return TextShape(id, $"Code {id}", MarginX, top, ContentW, code.Height, paras.ToString(), fill: "F3F4F6", inset: 8);
            }
            case TableBox table:
                return TableShape(id, table, top, rels);
            case PictureBox picture:
            {
                var rid = rels.Image(addImage(picture.Image.Png));
                var x = MarginX + (ContentW - picture.Width) / 2;
                return $"<p:pic><p:nvPicPr><p:cNvPr id=\"{id}\" name=\"Diagram {id}\" descr=\"Diagram\"/><p:cNvPicPr><a:picLocks noChangeAspect=\"1\"/></p:cNvPicPr><p:nvPr/></p:nvPicPr>" +
                       $"<p:blipFill><a:blip r:embed=\"{rid}\"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>" +
                       $"<p:spPr>{Xfrm(x, top, picture.Width, picture.Height)}<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></p:spPr></p:pic>";
            }
            default:
                return "";
        }
    }

    private static string TableShape(int id, TableBox t, double top, SlideRels rels)
    {
        var sb = new StringBuilder();
        var height = t.RowHeights.Sum();
        sb.Append($"<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id=\"{id}\" name=\"Table {id}\"/><p:cNvGraphicFramePr><a:graphicFrameLocks noGrp=\"1\"/></p:cNvGraphicFramePr><p:nvPr/></p:nvGraphicFramePr>")
          .Append($"<p:xfrm><a:off x=\"{Emu(MarginX)}\" y=\"{Emu(top)}\"/><a:ext cx=\"{t.Widths.Sum(Emu)}\" cy=\"{Emu(height)}\"/></p:xfrm>")
          .Append("<a:graphic><a:graphicData uri=\"http://schemas.openxmlformats.org/drawingml/2006/table\"><a:tbl><a:tblPr firstRow=\"1\" bandRow=\"1\"/><a:tblGrid>");
        foreach (var w in t.Widths)
        {
            sb.Append($"<a:gridCol w=\"{Emu(w)}\"/>");
        }
        sb.Append("</a:tblGrid>");
        void Row(IReadOnlyList<IReadOnlyList<MdInline>> cells, double h, bool header, bool band)
        {
            sb.Append($"<a:tr h=\"{Emu(h)}\">");
            for (var c = 0; c < t.Widths.Length; c++)
            {
                IReadOnlyList<MdInline> inlines = c < cells.Count ? cells[c] : [];
                var align = c < t.Table.Alignments.Count ? t.Table.Alignments[c] switch { "right" => "r", "center" => "ctr", _ => null } : null;
                IReadOnlyList<MdInline> content = header ? [new MdStrong(inlines)] : inlines;
                sb.Append("<a:tc><a:txBody><a:bodyPr/><a:lstStyle/>").Append(Paragraph(content, t.Size, Ink, rels, align: align)).Append("</a:txBody>")
                  .Append("<a:tcPr marL=\"76200\" marR=\"76200\" marT=\"50800\" marB=\"50800\">");
                foreach (var edge in new[] { "lnL", "lnR", "lnT", "lnB" })
                {
                    sb.Append($"<a:{edge} w=\"6350\"><a:solidFill><a:srgbClr val=\"D0D7DE\"/></a:solidFill></a:{edge}>");
                }
                sb.Append(header ? "<a:solidFill><a:srgbClr val=\"E8EEF7\"/></a:solidFill>" : band ? "<a:solidFill><a:srgbClr val=\"F6F8FA\"/></a:solidFill>" : "<a:noFill/>")
                  .Append("</a:tcPr></a:tc>");
            }
            sb.Append("</a:tr>");
        }
        Row(t.Table.Header, t.RowHeights[0], true, false);
        for (var r = 0; r < t.Rows.Count; r++)
        {
            Row(t.Rows[r], t.RowHeights[r + 1], false, (t.FirstRow + r) % 2 == 1);
        }
        sb.Append("</a:tbl></a:graphicData></a:graphic></p:graphicFrame>");
        return sb.ToString();
    }

    private static string BodyParagraph(Para p, int size, SlideRels rels)
    {
        var s = ParaSize(p, size);
        var indent = Indent(p);
        var props = new StringBuilder("<a:pPr");
        if (indent > 0)
        {
            props.Append($" marL=\"{Emu(indent)}\"");
            if (p.Bullet != Bullet.None)
            {
                props.Append($" indent=\"{-Emu(20)}\"");
            }
        }
        props.Append('>');
        if (p.Heading)
        {
            props.Append($"<a:spcBef><a:spcPts val=\"{Hundredths(s * 0.4)}\"/></a:spcBef>");
        }
        props.Append($"<a:spcAft><a:spcPts val=\"{Hundredths(s * 0.4)}\"/></a:spcAft>");
        props.Append(p.Bullet switch
        {
            Bullet.Dot => $"<a:buClr><a:srgbClr val=\"{Accent}\"/></a:buClr><a:buFont typeface=\"Arial\"/><a:buChar char=\"{(p.Level == 0 ? "•" : "–")}\"/>",
            Bullet.Number => $"<a:buClr><a:srgbClr val=\"{Accent}\"/></a:buClr><a:buFont typeface=\"+mj-lt\"/><a:buAutoNum type=\"arabicPeriod\" startAt=\"{Math.Max(1, p.Number)}\"/>",
            Bullet.Open => "<a:buFont typeface=\"Segoe UI Symbol\"/><a:buChar char=\"☐\"/>",
            Bullet.Done => "<a:buFont typeface=\"Segoe UI Symbol\"/><a:buChar char=\"☑\"/>",
            _ => "<a:buNone/>",
        });
        props.Append("</a:pPr>");
        IReadOnlyList<MdInline> inlines = p.Heading ? [new MdStrong(p.Inlines)] : p.Quote ? [new MdEmphasis(p.Inlines)] : p.Inlines;
        return "<a:p>" + props + Runs(inlines, s, p.Quote ? Muted : Ink, rels) + $"<a:endParaRPr lang=\"en-US\" sz=\"{Hundredths(s)}\" dirty=\"0\"/></a:p>";
    }

    private static string Paragraph(IReadOnlyList<MdInline> inlines, double size, string color, SlideRels rels, double spaceAfter = 0, string? align = null)
    {
        var props = (align is null ? "<a:pPr" : $"<a:pPr algn=\"{align}\"") + ">" +
                    (spaceAfter > 0 ? $"<a:spcAft><a:spcPts val=\"{Hundredths(spaceAfter)}\"/></a:spcAft>" : "") + "<a:buNone/></a:pPr>";
        return "<a:p>" + props + Runs(inlines, size, color, rels) + $"<a:endParaRPr lang=\"en-US\" sz=\"{Hundredths(size)}\" dirty=\"0\"/></a:p>";
    }

    private static string Runs(IEnumerable<MdInline> inlines, double size, string color, SlideRels rels, bool bold = false, bool italic = false, bool strike = false, string? link = null)
    {
        var sb = new StringBuilder();
        foreach (var inline in inlines)
        {
            switch (inline)
            {
                case MdText t:
                    sb.Append(Run(t.Text, size, link is null ? color : Accent, bold, italic, strike, mono: false, link));
                    break;
                case MdStrong s:
                    sb.Append(Runs(s.Inlines, size, color, rels, true, italic, strike, link));
                    break;
                case MdEmphasis e:
                    sb.Append(Runs(e.Inlines, size, color, rels, bold, true, strike, link));
                    break;
                case MdStrike s:
                    sb.Append(Runs(s.Inlines, size, color, rels, bold, italic, true, link));
                    break;
                case MdInlineCode c:
                    sb.Append(Run(c.Code, size, InlineCode, bold, italic, strike, mono: true, link));
                    break;
                case MdLink l when l.Url.StartsWith("http", StringComparison.OrdinalIgnoreCase) && link is null:
                    sb.Append(Runs(l.Inlines, size, color, rels, bold, italic, strike, rels.Link(l.Url)));
                    break;
                case MdLink l:
                    sb.Append(Runs(l.Inlines, size, color, rels, bold, italic, strike, link));
                    break;
                case MdImage i:
                    sb.Append(Run($"[{i.Alt}]", size, color, bold, true, strike, mono: false, link));
                    break;
                case MdLineBreak:
                    sb.Append($"<a:br><a:rPr lang=\"en-US\" sz=\"{Hundredths(size)}\" dirty=\"0\"/></a:br>");
                    break;
            }
        }
        return sb.ToString();
    }

    private static string Run(string text, double size, string color, bool bold, bool italic, bool strike, bool mono, string? link)
        => text.Length == 0 ? "" : $"<a:r>{RunProps(size, color, bold, italic, strike, mono, link)}<a:t>{Escape(text)}</a:t></a:r>";

    private static string RunProps(double size, string color, bool bold, bool italic, bool strike, bool mono, string? link)
    {
        var sb = new StringBuilder($"<a:rPr lang=\"en-US\" sz=\"{Hundredths(size)}\"");
        if (bold)
        {
            sb.Append(" b=\"1\"");
        }
        if (italic)
        {
            sb.Append(" i=\"1\"");
        }
        if (link is not null)
        {
            sb.Append(" u=\"sng\"");
        }
        if (strike)
        {
            sb.Append(" strike=\"sngStrike\"");
        }
        sb.Append($" dirty=\"0\"><a:solidFill><a:srgbClr val=\"{color}\"/></a:solidFill>");
        if (mono)
        {
            sb.Append("<a:latin typeface=\"Consolas\"/><a:cs typeface=\"Consolas\"/>");
        }
        if (link is not null)
        {
            sb.Append($"<a:hlinkClick r:id=\"{link}\"/>");
        }
        return sb.Append("</a:rPr>").ToString();
    }

    private static string TitleShape(int id, string text, double x, double y, double w, double h, double size, string color, string anchor)
        => $"<p:sp><p:nvSpPr><p:cNvPr id=\"{id}\" name=\"Title {id}\"/><p:cNvSpPr><a:spLocks noGrp=\"1\"/></p:cNvSpPr><p:nvPr><p:ph type=\"title\"/></p:nvPr></p:nvSpPr>" +
           $"<p:spPr>{Xfrm(x, y, w, h)}</p:spPr><p:txBody><a:bodyPr vert=\"horz\" wrap=\"square\" lIns=\"0\" tIns=\"0\" rIns=\"0\" bIns=\"0\" anchor=\"{anchor}\"><a:normAutofit/></a:bodyPr><a:lstStyle/>" +
           $"<a:p><a:pPr algn=\"l\"/><a:r>{RunProps(size, color, true, false, false, false, null)}<a:t>{Escape(text)}</a:t></a:r></a:p></p:txBody></p:sp>";

    private static string TextShape(int id, string name, double x, double y, double w, double h, string paragraphs, string? fill = null, double inset = 0, string anchor = "t")
    {
        var ins = Emu(inset);
        return $"<p:sp><p:nvSpPr><p:cNvPr id=\"{id}\" name=\"{Escape(name)}\"/><p:cNvSpPr txBox=\"1\"/><p:nvPr/></p:nvSpPr>" +
               $"<p:spPr>{Xfrm(x, y, w, h)}<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom>{(fill is null ? "<a:noFill/>" : $"<a:solidFill><a:srgbClr val=\"{fill}\"/></a:solidFill>")}</p:spPr>" +
               $"<p:txBody><a:bodyPr wrap=\"square\" lIns=\"{ins}\" tIns=\"{ins}\" rIns=\"{ins}\" bIns=\"{ins}\" anchor=\"{anchor}\"><a:noAutofit/></a:bodyPr><a:lstStyle/>{paragraphs}</p:txBody></p:sp>";
    }

    private static string Rect(int id, double x, double y, double w, double h, string color)
        => $"<p:sp><p:nvSpPr><p:cNvPr id=\"{id}\" name=\"Accent {id}\"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr>{Xfrm(x, y, w, h)}<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom>" +
           $"<a:solidFill><a:srgbClr val=\"{color}\"/></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr></p:sp>";

    private static string Xfrm(double x, double y, double w, double h)
        => $"<a:xfrm><a:off x=\"{Emu(x)}\" y=\"{Emu(y)}\"/><a:ext cx=\"{Emu(Math.Max(w, 1))}\" cy=\"{Emu(Math.Max(h, 1))}\"/></a:xfrm>";

    private static long Emu(double points) => (long)Math.Round(points * 12700);

    private static string Hundredths(double points) => ((int)Math.Round(points * 100)).ToString(CultureInfo.InvariantCulture);

    private static string Escape(string text) => DocxWriter.Escape(text);

    private static string NotesSlide(string text)
    {
        var paras = string.Concat(text.Replace("\r", "", StringComparison.Ordinal).Split('\n')
            .Select(line => line.Length == 0 ? "<a:p><a:endParaRPr lang=\"en-US\" dirty=\"0\"/></a:p>" : $"<a:p><a:r><a:rPr lang=\"en-US\" dirty=\"0\"/><a:t>{Escape(line)}</a:t></a:r></a:p>"));
        return $"{Decl}<p:notes {Ns}><p:cSld><p:spTree>{GroupHeader}" +
               "<p:sp><p:nvSpPr><p:cNvPr id=\"2\" name=\"Slide Image Placeholder 1\"/><p:cNvSpPr><a:spLocks noGrp=\"1\" noRot=\"1\" noChangeAspect=\"1\"/></p:cNvSpPr><p:nvPr><p:ph type=\"sldImg\"/></p:nvPr></p:nvSpPr><p:spPr/></p:sp>" +
               "<p:sp><p:nvSpPr><p:cNvPr id=\"3\" name=\"Notes Placeholder 2\"/><p:cNvSpPr><a:spLocks noGrp=\"1\"/></p:cNvSpPr><p:nvPr><p:ph type=\"body\" idx=\"1\"/></p:nvPr></p:nvSpPr><p:spPr/>" +
               $"<p:txBody><a:bodyPr/><a:lstStyle/>{paras}</p:txBody></p:sp></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:notes>";
    }

    // ---------------------------------------------------------------- package parts

    private const string Decl = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>";
    private const string NsA = "http://schemas.openxmlformats.org/drawingml/2006/main";
    private const string Ns = "xmlns:a=\"http://schemas.openxmlformats.org/drawingml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" " +
                              "xmlns:p=\"http://schemas.openxmlformats.org/presentationml/2006/main\"";
    private const string GroupHeader = "<p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>" +
                                       "<p:grpSpPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"0\" cy=\"0\"/><a:chOff x=\"0\" y=\"0\"/><a:chExt cx=\"0\" cy=\"0\"/></a:xfrm></p:grpSpPr>";
    private const string ColorMap = "bg1=\"lt1\" tx1=\"dk1\" bg2=\"lt2\" tx2=\"dk2\" accent1=\"accent1\" accent2=\"accent2\" accent3=\"accent3\" accent4=\"accent4\" " +
                                    "accent5=\"accent5\" accent6=\"accent6\" hlink=\"hlink\" folHlink=\"folHlink\"";

    private static string Presentation(int slides)
    {
        var ids = string.Concat(Enumerable.Range(1, slides).Select(n => $"<p:sldId id=\"{255 + n}\" r:id=\"rIdS{n}\"/>"));
        return $"{Decl}<p:presentation {Ns} saveSubsetFonts=\"1\">" +
               "<p:sldMasterIdLst><p:sldMasterId id=\"2147483648\" r:id=\"rId1\"/></p:sldMasterIdLst>" +
               "<p:notesMasterIdLst><p:notesMasterId r:id=\"rId2\"/></p:notesMasterIdLst>" +
               $"<p:sldIdLst>{ids}</p:sldIdLst>" +
               $"<p:sldSz cx=\"{Emu(SlideW)}\" cy=\"{Emu(SlideH)}\"/><p:notesSz cx=\"6858000\" cy=\"9144000\"/></p:presentation>";
    }

    private static readonly string Master =
        $"{Decl}<p:sldMaster {Ns}><p:cSld><p:bg><p:bgRef idx=\"1001\"><a:schemeClr val=\"bg1\"/></p:bgRef></p:bg><p:spTree>{GroupHeader}" +
        "<p:sp><p:nvSpPr><p:cNvPr id=\"2\" name=\"Title Placeholder 1\"/><p:cNvSpPr><a:spLocks noGrp=\"1\"/></p:cNvSpPr><p:nvPr><p:ph type=\"title\"/></p:nvPr></p:nvSpPr>" +
        $"<p:spPr>{Xfrm(MarginX, TitleY, ContentW, TitleH)}<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></p:spPr>" +
        "<p:txBody><a:bodyPr vert=\"horz\" lIns=\"0\" tIns=\"0\" rIns=\"0\" bIns=\"0\" anchor=\"b\"><a:normAutofit/></a:bodyPr><a:lstStyle/><a:p><a:r><a:rPr lang=\"en-US\"/><a:t>Title</a:t></a:r></a:p></p:txBody></p:sp>" +
        "<p:sp><p:nvSpPr><p:cNvPr id=\"3\" name=\"Text Placeholder 2\"/><p:cNvSpPr><a:spLocks noGrp=\"1\"/></p:cNvSpPr><p:nvPr><p:ph type=\"body\" idx=\"1\"/></p:nvPr></p:nvSpPr>" +
        $"<p:spPr>{Xfrm(MarginX, ContentTop, ContentW, Available)}<a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></p:spPr>" +
        "<p:txBody><a:bodyPr vert=\"horz\" lIns=\"0\" tIns=\"0\" rIns=\"0\" bIns=\"0\"><a:normAutofit/></a:bodyPr><a:lstStyle/><a:p><a:pPr lvl=\"0\"/><a:r><a:rPr lang=\"en-US\"/><a:t>Text</a:t></a:r></a:p></p:txBody></p:sp>" +
        $"</p:spTree></p:cSld><p:clrMap {ColorMap}/>" +
        "<p:sldLayoutIdLst><p:sldLayoutId id=\"2147483649\" r:id=\"rId1\"/></p:sldLayoutIdLst>" +
        $"<p:txStyles><p:titleStyle><a:lvl1pPr algn=\"l\"><a:defRPr sz=\"2800\" b=\"1\"><a:solidFill><a:srgbClr val=\"{Ink}\"/></a:solidFill><a:latin typeface=\"+mj-lt\"/></a:defRPr></a:lvl1pPr></p:titleStyle>" +
        $"<p:bodyStyle><a:lvl1pPr marL=\"0\" indent=\"0\"><a:buNone/><a:defRPr sz=\"2000\"><a:solidFill><a:srgbClr val=\"{Ink}\"/></a:solidFill><a:latin typeface=\"+mn-lt\"/></a:defRPr></a:lvl1pPr></p:bodyStyle>" +
        $"<p:otherStyle><a:lvl1pPr><a:defRPr sz=\"1800\"><a:solidFill><a:srgbClr val=\"{Ink}\"/></a:solidFill><a:latin typeface=\"+mn-lt\"/></a:defRPr></a:lvl1pPr></p:otherStyle></p:txStyles></p:sldMaster>";

    private static readonly string Layout1 =
        $"{Decl}<p:sldLayout {Ns} type=\"titleOnly\" preserve=\"1\"><p:cSld name=\"Title Only\"><p:spTree>{GroupHeader}" +
        "<p:sp><p:nvSpPr><p:cNvPr id=\"2\" name=\"Title 1\"/><p:cNvSpPr><a:spLocks noGrp=\"1\"/></p:cNvSpPr><p:nvPr><p:ph type=\"title\"/></p:nvPr></p:nvSpPr><p:spPr/>" +
        "<p:txBody><a:bodyPr/><a:lstStyle/><a:p><a:endParaRPr lang=\"en-US\"/></a:p></p:txBody></p:sp>" +
        "</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>";

    private static readonly string NotesMaster =
        $"{Decl}<p:notesMaster {Ns}><p:cSld><p:bg><p:bgRef idx=\"1001\"><a:schemeClr val=\"bg1\"/></p:bgRef></p:bg><p:spTree>{GroupHeader}" +
        "<p:sp><p:nvSpPr><p:cNvPr id=\"2\" name=\"Slide Image Placeholder 1\"/><p:cNvSpPr><a:spLocks noGrp=\"1\" noRot=\"1\" noChangeAspect=\"1\"/></p:cNvSpPr><p:nvPr><p:ph type=\"sldImg\" idx=\"2\"/></p:nvPr></p:nvSpPr>" +
        "<p:spPr><a:xfrm><a:off x=\"685800\" y=\"1143000\"/><a:ext cx=\"5486400\" cy=\"3086100\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom><a:noFill/><a:ln w=\"12700\"><a:solidFill><a:prstClr val=\"black\"/></a:solidFill></a:ln></p:spPr></p:sp>" +
        "<p:sp><p:nvSpPr><p:cNvPr id=\"3\" name=\"Notes Placeholder 2\"/><p:cNvSpPr><a:spLocks noGrp=\"1\"/></p:cNvSpPr><p:nvPr><p:ph type=\"body\" sz=\"quarter\" idx=\"3\"/></p:nvPr></p:nvSpPr>" +
        "<p:spPr><a:xfrm><a:off x=\"685800\" y=\"4400550\"/><a:ext cx=\"5486400\" cy=\"3600450\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></p:spPr>" +
        "<p:txBody><a:bodyPr vert=\"horz\" lIns=\"91440\" tIns=\"45720\" rIns=\"91440\" bIns=\"45720\"/><a:lstStyle/><a:p><a:pPr lvl=\"0\"/><a:r><a:rPr lang=\"en-US\"/><a:t>Notes</a:t></a:r></a:p></p:txBody></p:sp>" +
        $"</p:spTree></p:cSld><p:clrMap {ColorMap}/>" +
        "<p:notesStyle><a:lvl1pPr marL=\"0\" algn=\"l\"><a:defRPr sz=\"1200\"><a:solidFill><a:schemeClr val=\"tx1\"/></a:solidFill><a:latin typeface=\"+mn-lt\"/></a:defRPr></a:lvl1pPr></p:notesStyle></p:notesMaster>";

    private static string Theme(string name) =>
        $"{Decl}<a:theme xmlns:a=\"{NsA}\" name=\"{name}\"><a:themeElements>" +
        "<a:clrScheme name=\"DocGen\"><a:dk1><a:srgbClr val=\"1F2328\"/></a:dk1><a:lt1><a:srgbClr val=\"FFFFFF\"/></a:lt1><a:dk2><a:srgbClr val=\"0B2545\"/></a:dk2><a:lt2><a:srgbClr val=\"EEF2F7\"/></a:lt2>" +
        "<a:accent1><a:srgbClr val=\"0B57D0\"/></a:accent1><a:accent2><a:srgbClr val=\"1A7F37\"/></a:accent2><a:accent3><a:srgbClr val=\"BF8700\"/></a:accent3>" +
        "<a:accent4><a:srgbClr val=\"CF222E\"/></a:accent4><a:accent5><a:srgbClr val=\"8250DF\"/></a:accent5><a:accent6><a:srgbClr val=\"1B7C83\"/></a:accent6>" +
        "<a:hlink><a:srgbClr val=\"0B57D0\"/></a:hlink><a:folHlink><a:srgbClr val=\"8250DF\"/></a:folHlink></a:clrScheme>" +
        "<a:fontScheme name=\"DocGen\"><a:majorFont><a:latin typeface=\"Segoe UI Semibold\"/><a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:majorFont>" +
        "<a:minorFont><a:latin typeface=\"Segoe UI\"/><a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:minorFont></a:fontScheme>" +
        "<a:fmtScheme name=\"DocGen\"><a:fillStyleLst><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:fillStyleLst>" +
        "<a:lnStyleLst><a:ln w=\"6350\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:ln><a:ln w=\"12700\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:ln>" +
        "<a:ln w=\"19050\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:ln></a:lnStyleLst>" +
        "<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>" +
        "<a:bgFillStyleLst><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:bgFillStyleLst>" +
        "</a:fmtScheme></a:themeElements><a:objectDefaults/><a:extraClrSchemeLst/></a:theme>";

    private static string ContentTypes(int slides, IReadOnlyList<int> notes)
    {
        const string Pml = "application/vnd.openxmlformats-officedocument.presentationml.";
        var sb = new StringBuilder($"{Decl}<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">");
        sb.Append("<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>")
          .Append("<Default Extension=\"xml\" ContentType=\"application/xml\"/><Default Extension=\"png\" ContentType=\"image/png\"/>")
          .Append($"<Override PartName=\"/ppt/presentation.xml\" ContentType=\"{Pml}presentation.main+xml\"/>")
          .Append($"<Override PartName=\"/ppt/slideMasters/slideMaster1.xml\" ContentType=\"{Pml}slideMaster+xml\"/>")
          .Append($"<Override PartName=\"/ppt/slideLayouts/slideLayout1.xml\" ContentType=\"{Pml}slideLayout+xml\"/>")
          .Append($"<Override PartName=\"/ppt/notesMasters/notesMaster1.xml\" ContentType=\"{Pml}notesMaster+xml\"/>")
          .Append("<Override PartName=\"/ppt/theme/theme1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.theme+xml\"/>")
          .Append("<Override PartName=\"/ppt/theme/theme2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.theme+xml\"/>")
          .Append($"<Override PartName=\"/ppt/presProps.xml\" ContentType=\"{Pml}presProps+xml\"/>")
          .Append($"<Override PartName=\"/ppt/viewProps.xml\" ContentType=\"{Pml}viewProps+xml\"/>")
          .Append($"<Override PartName=\"/ppt/tableStyles.xml\" ContentType=\"{Pml}tableStyles+xml\"/>")
          .Append("<Override PartName=\"/docProps/core.xml\" ContentType=\"application/vnd.openxmlformats-package.core-properties+xml\"/>");
        for (var n = 1; n <= slides; n++)
        {
            sb.Append($"<Override PartName=\"/ppt/slides/slide{n}.xml\" ContentType=\"{Pml}slide+xml\"/>");
        }
        foreach (var n in notes)
        {
            sb.Append($"<Override PartName=\"/ppt/notesSlides/notesSlide{n}.xml\" ContentType=\"{Pml}notesSlide+xml\"/>");
        }
        return sb.Append("</Types>").ToString();
    }

    private static string Rels(params (string Id, string Type, string Target, bool External)[] items)
    {
        var sb = new StringBuilder($"{Decl}<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        foreach (var (id, type, target, external) in items)
        {
            var fullType = type.StartsWith("http", StringComparison.Ordinal) ? type : "http://schemas.openxmlformats.org/officeDocument/2006/relationships/" + type;
            sb.Append($"<Relationship Id=\"{id}\" Type=\"{fullType}\" Target=\"{Escape(target)}\"{(external ? " TargetMode=\"External\"" : "")}/>");
        }
        return sb.Append("</Relationships>").ToString();
    }

    private static string Core(string title) =>
        $"{Decl}<cp:coreProperties xmlns:cp=\"http://schemas.openxmlformats.org/package/2006/metadata/core-properties\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
        "xmlns:dcterms=\"http://purl.org/dc/terms/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
        $"<dc:title>{Escape(title)}</dc:title><dc:creator>DocGen Explorer</dc:creator>" +
        $"<dcterms:created xsi:type=\"dcterms:W3CDTF\">{DateTime.UtcNow:yyyy-MM-ddTHH:mm:ssZ}</dcterms:created></cp:coreProperties>";

    private static void Add(ZipArchive zip, string name, string content)
    {
        var entry = zip.CreateEntry(name, CompressionLevel.Optimal);
        using var writer = new StreamWriter(entry.Open(), new UTF8Encoding(false));
        writer.Write(content);
    }

    private static void AddBytes(ZipArchive zip, string name, byte[] content)
    {
        var entry = zip.CreateEntry(name, CompressionLevel.NoCompression);
        using var output = entry.Open();
        output.Write(content);
    }
}
