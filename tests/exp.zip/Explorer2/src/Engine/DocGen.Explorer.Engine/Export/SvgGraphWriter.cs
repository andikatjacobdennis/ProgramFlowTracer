using System.Globalization;
using System.Security;
using System.Text;
using DocGen.Explorer.Engine.Graph;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.Engine.Text;

namespace DocGen.Explorer.Engine.Export;

/// <summary>Colours of the concept types, shared by the graph view and the SVG export.</summary>
public static class ConceptPalette
{
    public static (string Fill, string Stroke, string Accent) Of(string type) => type switch
    {
        ConceptTypes.Repository => ("#0B6B57", "#0B6B57", "#FFFFFF"),
        ConceptTypes.Project => ("#EAF5F1", "#7FB9A6", "#0B6B57"),
        ConceptTypes.Namespace => ("#EAF5F1", "#9CCBBB", "#2E7D66"),
        ConceptTypes.Class => ("#EEF3FD", "#8FB0EA", "#1E5BC6"),
        ConceptTypes.Interface => ("#F1EEFD", "#A99AE6", "#5B3FC4"),
        ConceptTypes.Record => ("#EEF8FD", "#8CC7E3", "#14739E"),
        ConceptTypes.Struct => ("#F3F6FB", "#A7B6CF", "#40597F"),
        ConceptTypes.Enum => ("#FDF6E9", "#E3C27E", "#9A6B00"),
        ConceptTypes.Test => ("#FDEEF3", "#E39AB4", "#B0215A"),
        ConceptTypes.DocumentationPage => ("#F2F3F5", "#B9BEC7", "#4A5260"),
        ConceptTypes.MarkdownFile => ("#F2F3F5", "#B9BEC7", "#4A5260"),
        ConceptTypes.Endpoint => ("#FDF0E8", "#E7A57D", "#B3541E"),
        ConceptTypes.Group => ("#FFF8E6", "#E0B04C", "#8A5A00"),
        _ => ("#F2F3F5", "#B9BEC7", "#4A5260"),
    };

    public static string EdgeColor(string kind) => kind switch
    {
        EdgeKinds.Inherits => "#5B3FC4",
        EdgeKinds.Uses or EdgeKinds.Calls => "#3D7BD9",
        EdgeKinds.Tests => "#B0215A",
        EdgeKinds.References => "#0B6B57",
        EdgeKinds.Mentions or EdgeKinds.Documents => "#8A8F98",
        _ => "#7FB9A6",
    };
}

/// <summary>Draws the knowledge graph as a standalone SVG, for a document or a slide.</summary>
public static class SvgGraphWriter
{
    public static string Write(KnowledgeGraph graph, IReadOnlyDictionary<string, NodePosition>? positions = null, string? title = null)
    {
        positions ??= GraphLayout.Compute(graph);
        var w = GraphLayout.NodeWidth;
        var h = GraphLayout.NodeHeight;
        var maxX = positions.Values.Select(p => p.X).DefaultIfEmpty(0).Max() + w + 40;
        var maxY = positions.Values.Select(p => p.Y).DefaultIfEmpty(0).Max() + h + 60;
        var inv = CultureInfo.InvariantCulture;
        var sb = new StringBuilder();
        sb.Append(inv, $"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{maxX:0}\" height=\"{maxY:0}\" viewBox=\"0 0 {maxX:0} {maxY:0}\" font-family=\"Segoe UI, Roboto, Helvetica, Arial, sans-serif\">\n");
        sb.Append("<title>").Append(SecurityElement.Escape(title ?? "Knowledge graph")).Append("</title>\n");
        sb.Append("<defs>");
        foreach (var kind in graph.Edges.Select(e => e.Kind).Distinct())
        {
            sb.Append($"<marker id=\"arrow-{kind}\" viewBox=\"0 0 10 10\" refX=\"9\" refY=\"5\" markerWidth=\"7\" markerHeight=\"7\" orient=\"auto-start-reverse\"><path d=\"M 0 0 L 10 5 L 0 10 z\" fill=\"{ConceptPalette.EdgeColor(kind)}\"/></marker>");
        }
        sb.Append("</defs>\n<rect width=\"100%\" height=\"100%\" fill=\"#FFFFFF\"/>\n<g fill=\"none\" stroke-width=\"1.3\" opacity=\"0.8\">\n");
        foreach (var edge in graph.Edges)
        {
            if (!positions.TryGetValue(edge.From, out var a) || !positions.TryGetValue(edge.To, out var b))
            {
                continue;
            }
            var (x1, y1, x2, y2) = Anchors(a, b, w, h);
            var mx = (x1 + x2) / 2;
            var my = (y1 + y2) / 2 - Math.Min(40, Math.Abs(x2 - x1) * 0.08);
            sb.Append(inv, $"<path d=\"M {x1:0.#} {y1:0.#} Q {mx:0.#} {my:0.#} {x2:0.#} {y2:0.#}\" stroke=\"{ConceptPalette.EdgeColor(edge.Kind)}\" marker-end=\"url(#arrow-{edge.Kind})\"><title>{SecurityElement.Escape(edge.Kind)}</title></path>\n");
        }
        sb.Append("</g>\n");
        foreach (var node in graph.Nodes)
        {
            if (!positions.TryGetValue(node.Id, out var p))
            {
                continue;
            }
            var (fill, stroke, accent) = ConceptPalette.Of(node.Type);
            var textColor = node.Type == ConceptTypes.Repository ? "#FFFFFF" : "#1F2328";
            var subColor = node.Type == ConceptTypes.Repository ? "#D7F0E8" : "#5F6670";
            sb.Append(inv, $"<g transform=\"translate({p.X:0.#},{p.Y:0.#})\"><title>{SecurityElement.Escape(node.Description ?? node.Label)}</title>");
            sb.Append(inv, $"<rect width=\"{w:0}\" height=\"{h:0}\" rx=\"8\" fill=\"{fill}\" stroke=\"{stroke}\" stroke-width=\"1.2\"/>");
            sb.Append(inv, $"<rect x=\"10\" y=\"14\" width=\"24\" height=\"24\" rx=\"6\" fill=\"{(node.Type == ConceptTypes.Repository ? "#13846C" : "#FFFFFF")}\" stroke=\"{stroke}\" stroke-width=\"0.8\"/>");
            sb.Append(inv, $"<circle cx=\"22\" cy=\"26\" r=\"4\" fill=\"{accent}\"/>");
            sb.Append(inv, $"<text x=\"44\" y=\"24\" font-size=\"12\" font-weight=\"600\" fill=\"{textColor}\">{SecurityElement.Escape(TextUtil.Truncate(node.Label, 22))}</text>");
            sb.Append(inv, $"<text x=\"44\" y=\"40\" font-size=\"10\" fill=\"{subColor}\">{SecurityElement.Escape(node.Type)}</text></g>\n");
        }
        sb.Append("</svg>\n");
        return sb.ToString();
    }

    /// <summary>Edge end points on the borders of the two node rectangles.</summary>
    public static (double X1, double Y1, double X2, double Y2) Anchors(NodePosition a, NodePosition b, double w, double h)
    {
        var ac = (X: a.X + w / 2, Y: a.Y + h / 2);
        var bc = (X: b.X + w / 2, Y: b.Y + h / 2);
        return (Border(ac, bc, w, h).X, Border(ac, bc, w, h).Y, Border(bc, ac, w, h).X, Border(bc, ac, w, h).Y);
    }

    private static (double X, double Y) Border((double X, double Y) from, (double X, double Y) to, double w, double h)
    {
        var dx = to.X - from.X;
        var dy = to.Y - from.Y;
        if (Math.Abs(dx) < 1e-6 && Math.Abs(dy) < 1e-6)
        {
            return from;
        }
        var sx = Math.Abs(dx) > 1e-6 ? (w / 2) / Math.Abs(dx) : double.MaxValue;
        var sy = Math.Abs(dy) > 1e-6 ? (h / 2) / Math.Abs(dy) : double.MaxValue;
        var s = Math.Min(sx, sy);
        return (from.X + dx * s, from.Y + dy * s);
    }
}
