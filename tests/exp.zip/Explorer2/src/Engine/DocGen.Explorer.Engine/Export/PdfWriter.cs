using System.Globalization;
using System.Text;
using DocGen.Explorer.Engine.Markdown;

namespace DocGen.Explorer.Engine.Export;

/// <summary>
/// Writes Markdown documents to PDF (A4) with the standard Helvetica and Courier fonts — no external dependency. Text is
/// wrapped with the fonts' real metrics, long code lines are wrapped too, and every page carries a footer with its number.
/// </summary>
public static class PdfWriter
{
    private const double PageWidth = 595.28;
    private const double PageHeight = 841.89;
    private const double Margin = 56;
    private const double ContentWidth = PageWidth - 2 * Margin;

    // Helvetica advance widths (1/1000 em) for 0x20..0x7E.
    private static readonly int[] Helvetica =
    [
        278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, 556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556,
        1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, 667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556,
        333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, 556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584,
    ];

    private enum Font { Regular, Bold, Italic, Mono }

    private sealed record Word(string Text, Font Font, double Size, bool Link);

    private sealed class PageBuilder
    {
        public readonly List<StringBuilder> Pages = [];
        public StringBuilder Current = new();
        public double Y;

        public PageBuilder() => NewPage();

        public void NewPage()
        {
            Current = new StringBuilder();
            Pages.Add(Current);
            Y = PageHeight - Margin;
        }

        public void Ensure(double height)
        {
            if (Y - height < Margin + 20)
            {
                NewPage();
            }
        }
    }

    public static byte[] Write(IReadOnlyList<ExportDocument> documents, string? title = null)
    {
        var builder = new PageBuilder();
        for (var d = 0; d < documents.Count; d++)
        {
            if (d > 0)
            {
                builder.NewPage();
            }
            var doc = MarkdownDocument.Parse(documents[d].Markdown);
            if (!doc.Blocks.OfType<MdHeading>().Any(h => h.Level == 1))
            {
                Heading(builder, 1, documents[d].Title);
            }
            foreach (var block in doc.Blocks)
            {
                Block(builder, block, 0);
            }
        }
        return Assemble(builder.Pages, title ?? documents.FirstOrDefault()?.Title ?? "Documentation");
    }

    private static void Block(PageBuilder b, MdBlock block, double indent)
    {
        switch (block)
        {
            case MdHeading h:
                Heading(b, h.Level, h.Text, indent);
                break;
            case MdParagraph p:
                Flow(b, Words(p.Inlines, Font.Regular, 10.5), indent, 10.5 * 1.45, 0);
                b.Y -= 6;
                break;
            case MdCode c:
                Code(b, c.Code, indent);
                break;
            case MdQuote q:
                foreach (var inner in q.Blocks)
                {
                    var startY = b.Y;
                    Block(b, inner, indent + 14);
                    if (b.Y < startY)
                    {
                        b.Current.Append(CultureInfo.InvariantCulture, $"0.04 0.34 0.82 RG 2 w {Margin + indent + 4:0.##} {startY + 2:0.##} m {Margin + indent + 4:0.##} {b.Y + 8:0.##} l S 0 0 0 RG\n");
                    }
                }
                break;
            case MdList l:
                var n = l.Start;
                foreach (var item in l.Items)
                {
                    var marker = l.Ordered ? $"{n++}." : item.Checked is null ? "•" : item.Checked == true ? "[x]" : "[ ]";
                    var first = true;
                    foreach (var inner in item.Blocks)
                    {
                        if (first && inner is MdParagraph para)
                        {
                            b.Ensure(16);
                            Text(b, Margin + indent + 4, b.Y - 10.5, marker, Font.Regular, 10.5);
                            Flow(b, Words(para.Inlines, Font.Regular, 10.5), indent + 20, 10.5 * 1.4, 0);
                            b.Y -= 2;
                        }
                        else
                        {
                            Block(b, inner, indent + 20);
                        }
                        first = false;
                    }
                }
                b.Y -= 4;
                break;
            case MdTable t:
                Table(b, t, indent);
                break;
            case MdRule:
                b.Ensure(12);
                b.Current.Append(CultureInfo.InvariantCulture, $"0.75 G 0.5 w {Margin + indent:0.##} {b.Y - 6:0.##} m {PageWidth - Margin:0.##} {b.Y - 6:0.##} l S 0 G\n");
                b.Y -= 14;
                break;
        }
    }

    private static void Heading(PageBuilder b, int level, string text, double indent = 0)
    {
        var size = level switch { 1 => 20.0, 2 => 15.0, 3 => 12.5, _ => 11.0 };
        b.Ensure(size * 3);
        b.Y -= level == 1 ? 4 : 10;
        Flow(b, Words([new MdText(text)], Font.Bold, size), indent, size * 1.3, 0);
        if (level <= 2)
        {
            b.Current.Append(CultureInfo.InvariantCulture, $"0.85 G 0.6 w {Margin + indent:0.##} {b.Y + 2:0.##} m {PageWidth - Margin:0.##} {b.Y + 2:0.##} l S 0 G\n");
            b.Y -= 6;
        }
        b.Y -= 4;
    }

    private static List<Word> Words(IEnumerable<MdInline> inlines, Font font, double size, bool link = false)
    {
        var words = new List<Word>();
        foreach (var inline in inlines)
        {
            switch (inline)
            {
                case MdText t:
                    words.AddRange(Split(t.Text, font, size, link));
                    break;
                case MdStrong s:
                    words.AddRange(Words(s.Inlines, font == Font.Mono ? Font.Mono : Font.Bold, size, link));
                    break;
                case MdEmphasis e:
                    words.AddRange(Words(e.Inlines, font == Font.Regular ? Font.Italic : font, size, link));
                    break;
                case MdStrike s:
                    words.AddRange(Words(s.Inlines, font, size, link));
                    break;
                case MdInlineCode c:
                    words.AddRange(Split(c.Code, Font.Mono, size * 0.92, link));
                    break;
                case MdLink l:
                    words.AddRange(Words(l.Inlines, font, size, true));
                    break;
                case MdImage i:
                    words.AddRange(Split($"[{i.Alt}]", Font.Italic, size, link));
                    break;
                case MdLineBreak:
                    words.Add(new Word("\n", font, size, false));
                    break;
            }
        }
        return words;
    }

    private static IEnumerable<Word> Split(string text, Font font, double size, bool link)
    {
        var parts = text.Split(' ');
        for (var i = 0; i < parts.Length; i++)
        {
            if (parts[i].Length > 0)
            {
                yield return new Word(parts[i], font, size, link);
            }
            if (i < parts.Length - 1)
            {
                yield return new Word(" ", font, size, link);
            }
        }
    }

    private static void Flow(PageBuilder b, List<Word> words, double indent, double lineHeight, double firstLineOffset)
    {
        var maxWidth = ContentWidth - indent;
        var line = new List<Word>();
        double width = 0;

        void FlushLine()
        {
            while (line.Count > 0 && line[^1].Text == " ")
            {
                line.RemoveAt(line.Count - 1);
            }
            b.Ensure(lineHeight);
            var x = Margin + indent;
            var baseline = b.Y - lineHeight * 0.78;
            foreach (var word in line)
            {
                if (word.Text != " " || x > Margin + indent)
                {
                    if (word.Link)
                    {
                        b.Current.Append("0.04 0.34 0.82 rg ");
                    }
                    Text(b, x, baseline, word.Text, word.Font, word.Size);
                    if (word.Link)
                    {
                        b.Current.Append("0 g ");
                    }
                    x += Measure(word.Text, word.Font, word.Size);
                }
            }
            b.Y -= lineHeight;
            line.Clear();
            width = 0;
        }

        foreach (var word in words)
        {
            if (word.Text == "\n")
            {
                FlushLine();
                continue;
            }
            var w = Measure(word.Text, word.Font, word.Size);
            if (word.Text != " " && width + w > maxWidth && line.Count > 0)
            {
                FlushLine();
            }
            if (word.Text == " " && line.Count == 0)
            {
                continue;
            }
            if (w > maxWidth)
            {
                // A single word longer than the line: hard-wrap it.
                var chunk = new StringBuilder();
                foreach (var c in word.Text)
                {
                    if (Measure(chunk.ToString() + c, word.Font, word.Size) > maxWidth)
                    {
                        line.Add(word with { Text = chunk.ToString() });
                        FlushLine();
                        chunk.Clear();
                    }
                    chunk.Append(c);
                }
                line.Add(word with { Text = chunk.ToString() });
                width = Measure(chunk.ToString(), word.Font, word.Size);
                continue;
            }
            line.Add(word);
            width += w;
        }
        if (line.Count > 0)
        {
            FlushLine();
        }
    }

    private static void Code(PageBuilder b, string code, double indent)
    {
        const double size = 8.6;
        const double lineHeight = size * 1.35;
        var charWidth = 0.6 * size;
        var maxChars = Math.Max(20, (int)((ContentWidth - indent - 16) / charWidth));
        var lines = new List<string>();
        foreach (var raw in code.Replace("\t", "    ", StringComparison.Ordinal).Replace("\r", "", StringComparison.Ordinal).Split('\n'))
        {
            var rest = raw;
            do
            {
                lines.Add(rest.Length > maxChars ? rest[..maxChars] : rest);
                rest = rest.Length > maxChars ? "  " + rest[maxChars..] : "";
            }
            while (rest.Length > 0);
        }
        b.Y -= 4;
        var i = 0;
        while (i < lines.Count)
        {
            b.Ensure(lineHeight * 2 + 8);
            var available = (int)((b.Y - Margin - 28) / lineHeight);
            var take = Math.Max(1, Math.Min(available, lines.Count - i));
            var height = take * lineHeight + 10;
            b.Current.Append(CultureInfo.InvariantCulture, $"0.96 0.96 0.96 rg {Margin + indent:0.##} {b.Y - height:0.##} {ContentWidth - indent:0.##} {height:0.##} re f 0 g\n");
            var y = b.Y - 5 - size;
            for (var k = 0; k < take; k++)
            {
                Text(b, Margin + indent + 8, y, lines[i + k], Font.Mono, size);
                y -= lineHeight;
            }
            b.Y -= height;
            i += take;
            if (i < lines.Count)
            {
                b.NewPage();
            }
        }
        b.Y -= 8;
    }

    private static void Table(PageBuilder b, MdTable table, double indent)
    {
        var columns = Math.Max(1, table.Header.Count);
        var colWidth = (ContentWidth - indent) / columns;
        const double size = 9;
        void Row(IReadOnlyList<IReadOnlyList<MdInline>> cells, Font font, bool shade)
        {
            // Wrap each cell, then draw the row at the tallest cell's height.
            var wrapped = cells.Select(c => WrapPlain(MarkdownDocument.PlainText(c), font, size, colWidth - 8)).ToList();
            var rowLines = Math.Max(1, wrapped.Max(w => w.Count));
            var height = rowLines * size * 1.3 + 6;
            b.Ensure(height);
            if (shade)
            {
                b.Current.Append(CultureInfo.InvariantCulture, $"0.95 0.95 0.95 rg {Margin + indent:0.##} {b.Y - height:0.##} {ContentWidth - indent:0.##} {height:0.##} re f 0 g\n");
            }
            for (var c = 0; c < wrapped.Count && c < columns; c++)
            {
                var y = b.Y - 3 - size;
                foreach (var line in wrapped[c])
                {
                    Text(b, Margin + indent + c * colWidth + 4, y, line, font, size);
                    y -= size * 1.3;
                }
            }
            b.Current.Append(CultureInfo.InvariantCulture, $"0.8 G 0.4 w {Margin + indent:0.##} {b.Y - height:0.##} m {PageWidth - Margin:0.##} {b.Y - height:0.##} l S 0 G\n");
            b.Y -= height;
        }
        Row(table.Header, Font.Bold, true);
        foreach (var row in table.Rows)
        {
            Row(row, Font.Regular, false);
        }
        b.Y -= 8;
    }

    private static List<string> WrapPlain(string text, Font font, double size, double width)
    {
        var lines = new List<string>();
        var current = new StringBuilder();
        foreach (var word in text.Split(' ', StringSplitOptions.RemoveEmptyEntries))
        {
            var candidate = current.Length == 0 ? word : current + " " + word;
            if (Measure(candidate, font, size) > width && current.Length > 0)
            {
                lines.Add(current.ToString());
                current.Clear().Append(word);
            }
            else
            {
                current.Clear().Append(candidate);
            }
        }
        if (current.Length > 0)
        {
            lines.Add(current.ToString());
        }
        return lines.Count == 0 ? [""] : lines;
    }

    private static double Measure(string text, Font font, double size)
    {
        if (font == Font.Mono)
        {
            return text.Length * 0.6 * size;
        }
        double total = 0;
        foreach (var c in text)
        {
            var code = c is >= ' ' and <= '~' ? c : '?';
            total += Helvetica[code - 32];
        }
        var factor = font == Font.Bold ? 1.06 : 1.0;
        return total * size / 1000 * factor;
    }

    private static void Text(PageBuilder b, double x, double y, string text, Font font, double size)
    {
        var name = font switch { Font.Bold => "F2", Font.Italic => "F3", Font.Mono => "F4", _ => "F1" };
        b.Current.Append(CultureInfo.InvariantCulture, $"BT /{name} {size:0.##} Tf {x:0.##} {y:0.##} Td (");
        b.Current.Append(EscapeText(text));
        b.Current.Append(") Tj ET\n");
    }

    /// <summary>Escapes PDF string syntax and maps Unicode punctuation to WinAnsi; other characters become '?'.</summary>
    public static string EscapeText(string text)
    {
        var sb = new StringBuilder(text.Length);
        foreach (var c in text)
        {
            var mapped = c switch
            {
                '—' => '\u0097',
                '–' => '\u0096',
                '‘' => '\u0091',
                '’' => '\u0092',
                '“' => '\u0093',
                '”' => '\u0094',
                '•' => '\u0095',
                '…' => '\u0085',
                '€' => '\u0080',
                '→' => '>',
                ' ' => ' ',
                _ => c,
            };
            if (mapped is '(' or ')' or '\\')
            {
                sb.Append('\\').Append(mapped);
            }
            else if (mapped < ' ')
            {
                sb.Append(' ');
            }
            else if (mapped > 'ÿ')
            {
                sb.Append('?');
            }
            else
            {
                sb.Append(mapped);
            }
        }
        return sb.ToString();
    }

    private static byte[] Assemble(List<StringBuilder> pages, string title)
    {
        var latin1 = Encoding.Latin1;
        var objects = new List<byte[]>();
        int Add(string content)
        {
            objects.Add(latin1.GetBytes(content));
            return objects.Count;
        }

        // 1 catalog, 2 pages, 3-6 fonts, 7 info; then per page: content + page.
        objects.Add([]); // placeholder for catalog
        objects.Add([]); // placeholder for pages
        Add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");
        Add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>");
        Add("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique /Encoding /WinAnsiEncoding >>");
        Add("<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>");
        var info = Add($"<< /Title ({EscapeText(title)}) /Producer (DocGen Explorer) /CreationDate (D:{DateTime.UtcNow:yyyyMMddHHmmss}Z) >>");
        var pageIds = new List<int>();
        for (var i = 0; i < pages.Count; i++)
        {
            var footer = $"BT /F1 8 Tf {PageWidth / 2 - 20:0.##} 30 Td ({EscapeText($"{title} — {i + 1} / {pages.Count}")}) Tj ET\n";
            var content = "0 g\n" + pages[i] + "0.45 g " + footer.Replace(",", ".", StringComparison.Ordinal);
            var bytes = latin1.GetBytes(content);
            objects.Add(latin1.GetBytes($"<< /Length {bytes.Length} >>\nstream\n").Concat(bytes).Concat(latin1.GetBytes("\nendstream")).ToArray());
            var contentId = objects.Count;
            pageIds.Add(Add($"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {PageWidth.ToString("0.##", CultureInfo.InvariantCulture)} {PageHeight.ToString("0.##", CultureInfo.InvariantCulture)}] " +
                            $"/Resources << /Font << /F1 3 0 R /F2 4 0 R /F3 5 0 R /F4 6 0 R >> >> /Contents {contentId} 0 R >>"));
        }
        objects[0] = latin1.GetBytes("<< /Type /Catalog /Pages 2 0 R >>");
        objects[1] = latin1.GetBytes($"<< /Type /Pages /Kids [{string.Join(" ", pageIds.Select(id => $"{id} 0 R"))}] /Count {pageIds.Count} >>");

        using var output = new MemoryStream();
        void Write(string s) => output.Write(latin1.GetBytes(s));
        Write("%PDF-1.4\n%âãÏÓ\n");
        var offsets = new List<long>();
        for (var i = 0; i < objects.Count; i++)
        {
            offsets.Add(output.Position);
            Write($"{i + 1} 0 obj\n");
            output.Write(objects[i]);
            Write("\nendobj\n");
        }
        var xref = output.Position;
        Write($"xref\n0 {objects.Count + 1}\n0000000000 65535 f \n");
        foreach (var offset in offsets)
        {
            Write($"{offset:D10} 00000 n \n");
        }
        Write($"trailer\n<< /Size {objects.Count + 1} /Root 1 0 R /Info {info} 0 R >>\nstartxref\n{xref}\n%%EOF\n");
        return output.ToArray();
    }
}
