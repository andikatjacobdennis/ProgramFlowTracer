using System.Text;

namespace DocGen.Analysis.CSharp;

public enum TokenKind : byte
{
    Identifier,
    Keyword,
    String,
    Char,
    Number,
    Punct,
}

/// <summary>A C# token. <see cref="Text"/> is the identifier/keyword/punctuation; for strings it is the literal's value.</summary>
public readonly record struct Token(TokenKind Kind, string Text, int Line)
{
    public bool Is(string text) => Text == text && Kind is TokenKind.Punct or TokenKind.Keyword or TokenKind.Identifier;
    public bool IsPunct(char c) => Kind == TokenKind.Punct && Text.Length == 1 && Text[0] == c;
    public override string ToString() => Kind == TokenKind.String ? "\"" + Text + "\"" : Text;
}

/// <summary>
/// A tolerant, allocation-light C# lexer: comments and preprocessor lines are skipped; regular, verbatim, interpolated
/// and raw string literals are recognised (so braces inside strings never confuse the structural parser). Malformed
/// input never throws — the lexer recovers at the next line. Only <c>=&gt;</c>, <c>::</c> and <c>?.</c> are combined
/// into multi-character punctuation; everything else is a single character (generic <c>&gt;&gt;</c> stays two tokens).
/// </summary>
public static class CSharpLexer
{
    public static readonly HashSet<string> Keywords = new(StringComparer.Ordinal)
    {
        "abstract", "as", "base", "bool", "break", "byte", "case", "catch", "char", "checked", "class", "const", "continue",
        "decimal", "default", "delegate", "do", "double", "else", "enum", "event", "explicit", "extern", "false", "finally",
        "fixed", "float", "for", "foreach", "goto", "if", "implicit", "in", "int", "interface", "internal", "is", "lock",
        "long", "namespace", "new", "null", "object", "operator", "out", "override", "params", "private", "protected",
        "public", "readonly", "ref", "return", "sbyte", "sealed", "short", "sizeof", "stackalloc", "static", "string",
        "struct", "switch", "this", "throw", "true", "try", "typeof", "uint", "ulong", "unchecked", "unsafe", "ushort",
        "using", "virtual", "void", "volatile", "while",
    };

    public static List<Token> Tokenize(string source)
    {
        var tokens = new List<Token>(source.Length / 5 + 16);
        var i = 0;
        var line = 1;
        var atLineStart = true;
        var n = source.Length;

        while (i < n)
        {
            var c = source[i];
            if (c == '\n')
            {
                line++;
                i++;
                atLineStart = true;
                continue;
            }
            // A byte-order mark (U+FEFF) is not whitespace to char.IsWhiteSpace, but it is not code either.
            if (char.IsWhiteSpace(c) || c == '\uFEFF')
            {
                i++;
                continue;
            }
            if (c == '#' && atLineStart)
            {
                while (i < n && source[i] != '\n')
                {
                    i++;
                }
                continue;
            }
            atLineStart = false;

            if (c == '/' && i + 1 < n && source[i + 1] == '/')
            {
                while (i < n && source[i] != '\n')
                {
                    i++;
                }
                continue;
            }
            if (c == '/' && i + 1 < n && source[i + 1] == '*')
            {
                i += 2;
                while (i < n && !(source[i] == '*' && i + 1 < n && source[i + 1] == '/'))
                {
                    if (source[i] == '\n')
                    {
                        line++;
                    }
                    i++;
                }
                i = Math.Min(n, i + 2);
                continue;
            }

            // String literals, possibly prefixed by $ (any count) and/or @, and raw strings.
            if (c is '"' or '$' or '@' && TryString(source, ref i, ref line, out var literal, out var startLine))
            {
                tokens.Add(new Token(TokenKind.String, literal, startLine));
                continue;
            }

            if (c == '\'')
            {
                var start = i++;
                while (i < n && source[i] != '\'' && source[i] != '\n')
                {
                    i += source[i] == '\\' ? 2 : 1;
                }
                i = Math.Min(n, i + 1);
                tokens.Add(new Token(TokenKind.Char, source[start..Math.Min(i, n)], line));
                continue;
            }

            if (char.IsLetter(c) || c == '_' || c == '@' && i + 1 < n && (char.IsLetter(source[i + 1]) || source[i + 1] == '_'))
            {
                var verbatim = c == '@';
                var start = verbatim ? ++i : i;
                while (i < n && (char.IsLetterOrDigit(source[i]) || source[i] == '_'))
                {
                    i++;
                }
                var word = source[start..i];
                tokens.Add(new Token(!verbatim && Keywords.Contains(word) ? TokenKind.Keyword : TokenKind.Identifier, word, line));
                continue;
            }

            if (char.IsDigit(c) || c == '.' && i + 1 < n && char.IsDigit(source[i + 1]))
            {
                var start = i;
                while (i < n && (char.IsLetterOrDigit(source[i]) || source[i] == '_' || source[i] == '.' && i + 1 < n && char.IsDigit(source[i + 1])))
                {
                    i++;
                }
                tokens.Add(new Token(TokenKind.Number, source[start..i], line));
                continue;
            }

            if (i + 1 < n)
            {
                var two = source.AsSpan(i, 2);
                if (two is "=>" or "::" or "?.")
                {
                    tokens.Add(new Token(TokenKind.Punct, two.ToString(), line));
                    i += 2;
                    continue;
                }
            }
            tokens.Add(new Token(TokenKind.Punct, PunctCache(c), line));
            i++;
        }
        return tokens;
    }

    private static readonly string[] SingleChars = Enumerable.Range(0, 128).Select(x => ((char)x).ToString()).ToArray();

    private static string PunctCache(char c) => c < 128 ? SingleChars[c] : c.ToString();

    private static bool TryString(string s, ref int i, ref int line, out string value, out int startLine)
    {
        value = "";
        startLine = line;
        var n = s.Length;
        var j = i;
        var dollars = 0;
        var verbatim = false;
        while (j < n && (s[j] == '$' || s[j] == '@'))
        {
            if (s[j] == '$')
            {
                dollars++;
            }
            else
            {
                verbatim = true;
            }
            j++;
        }
        if (j >= n || s[j] != '"')
        {
            return false;
        }

        // Raw string literal: three or more quotes.
        var quotes = 0;
        while (j + quotes < n && s[j + quotes] == '"')
        {
            quotes++;
        }
        if (quotes >= 3)
        {
            var contentStart = j + quotes;
            var k = contentStart;
            while (k < n)
            {
                if (s[k] == '"')
                {
                    var run = 0;
                    while (k + run < n && s[k + run] == '"')
                    {
                        run++;
                    }
                    if (run >= quotes)
                    {
                        value = s[contentStart..k];
                        line += CountLines(s, i, k + run);
                        i = k + run;
                        return true;
                    }
                    k += run;
                    continue;
                }
                k++;
            }
            value = s[contentStart..];
            line += CountLines(s, i, n);
            i = n;
            return true;
        }

        // Regular / verbatim / interpolated string.
        var sb = new StringBuilder();
        var p = j + 1;
        var depth = 0;
        while (p < n)
        {
            var ch = s[p];
            if (depth == 0)
            {
                if (ch == '"')
                {
                    if (verbatim && p + 1 < n && s[p + 1] == '"')
                    {
                        sb.Append('"');
                        p += 2;
                        continue;
                    }
                    p++;
                    break;
                }
                if (!verbatim && ch == '\\' && p + 1 < n)
                {
                    sb.Append(s[p + 1] switch { 'n' => '\n', 't' => '\t', '\\' => '\\', '"' => '"', '\'' => '\'', '0' => '\0', 'r' => '\r', var other => other });
                    p += 2;
                    continue;
                }
                if (!verbatim && ch == '\n')
                {
                    break; // Unterminated; recover at the line end.
                }
                if (dollars > 0 && ch == '{')
                {
                    if (p + 1 < n && s[p + 1] == '{')
                    {
                        sb.Append('{');
                        p += 2;
                        continue;
                    }
                    depth = 1;
                    sb.Append('{');
                    p++;
                    continue;
                }
                sb.Append(ch);
                p++;
                continue;
            }

            // Inside an interpolation hole: skip nested strings and balance braces.
            if (ch == '"' || (ch is '$' or '@') && p + 1 < n && (s[p + 1] == '"' || s[p + 1] is '$' or '@'))
            {
                var nestedLine = line;
                var q = p;
                if (TryString(s, ref q, ref nestedLine, out var nested, out _) && q > p)
                {
                    sb.Append('"').Append(nested).Append('"');
                    p = q;
                    continue;
                }
            }
            if (ch == '{')
            {
                depth++;
            }
            else if (ch == '}')
            {
                depth--;
            }
            sb.Append(ch);
            p++;
        }
        line += CountLines(s, i, p);
        i = p;
        value = sb.ToString();
        return true;
    }

    private static int CountLines(string s, int from, int to)
    {
        var count = 0;
        for (var k = from; k < to && k < s.Length; k++)
        {
            if (s[k] == '\n')
            {
                count++;
            }
        }
        return count;
    }
}
