using DocGen.Analysis.Indexing;

namespace DocGen.Analysis.CSharp;

/// <summary>
/// Structural (declaration-level) C# parser over <see cref="CSharpLexer"/> tokens. It extracts namespaces, usings,
/// types, members, base lists, attributes, parameters and per-member references (invocations and capitalised names),
/// plus framework patterns: DI registrations, configuration keys, controller/minimal-API endpoints, middleware and
/// tests. It does not bind names semantically (no compilation, no overload resolution): results are name-based and
/// the tools say so. It never throws on malformed input.
/// </summary>
public static class CSharpParser
{
    private const int MaxReferencesPerMember = 400;
    private const int MaxLinesPerIdentifier = 64;

    private static readonly HashSet<string> Modifiers = new(StringComparer.Ordinal)
    {
        "public", "private", "protected", "internal", "static", "readonly", "const", "virtual", "override", "abstract",
        "sealed", "async", "extern", "unsafe", "new", "partial", "volatile", "required", "file",
    };

    private static readonly HashSet<string> TestAttributes = new(StringComparer.Ordinal)
    {
        "TestMethod", "DataTestMethod", "Fact", "Theory", "Test", "TestCase", "TestCaseSource", "SkippableFact",
    };

    private static readonly HashSet<string> IgnoredReferenceNames = new(StringComparer.Ordinal)
    {
        "var", "get", "set", "init", "value", "async", "await", "nameof", "where", "when", "yield", "partial", "record",
        "dynamic", "global", "add", "remove", "and", "or", "not", "with", "required", "file", "scoped", "select", "from",
        "orderby", "let", "join", "on", "equals", "into", "by", "ascending", "descending", "group", "args", "notnull", "unmanaged",
    };

    private static readonly Dictionary<string, string> DiMethods = new(StringComparer.Ordinal)
    {
        ["AddSingleton"] = "Singleton", ["AddScoped"] = "Scoped", ["AddTransient"] = "Transient",
        ["TryAddSingleton"] = "Singleton", ["TryAddScoped"] = "Scoped", ["TryAddTransient"] = "Transient",
        ["AddKeyedSingleton"] = "Singleton", ["AddKeyedScoped"] = "Scoped", ["AddKeyedTransient"] = "Transient",
        ["AddHostedService"] = "Singleton",
        ["AddDbContext"] = "Scoped", ["AddDbContextPool"] = "Scoped", ["AddDbContextFactory"] = "Singleton",
        ["AddHttpClient"] = "Transient",
    };

    private static readonly Dictionary<string, string> MapMethods = new(StringComparer.Ordinal)
    {
        ["MapGet"] = "GET", ["MapPost"] = "POST", ["MapPut"] = "PUT", ["MapDelete"] = "DELETE", ["MapPatch"] = "PATCH",
        ["MapMethods"] = "*", ["MapFallback"] = "*",
    };

    private static readonly Dictionary<string, string> HttpAttributes = new(StringComparer.Ordinal)
    {
        ["HttpGet"] = "GET", ["HttpPost"] = "POST", ["HttpPut"] = "PUT", ["HttpDelete"] = "DELETE", ["HttpPatch"] = "PATCH",
    };

    private enum ScopeKind
    {
        File,
        Namespace,
        Type,
        Enum,
        Body,
        Accessors,
        Transparent,
    }

    private sealed class Scope
    {
        public ScopeKind Kind;
        public string Namespace = "";
        public SymbolRecord? Symbol;       // Type for Type/Enum scopes; owning member for Body/Accessors.
        public List<AttributeInfo> TypeAttributes = [];
    }

    private sealed record AttributeInfo(string Name, List<string> StringArgs, int Line);

    /// <summary>"System.Collections.Generic.List&lt;int&gt;?" → "List&lt;int&gt;".</summary>
    public static string SimpleTypeName(string text) => State.SimpleTypeName(text);

    public static FileIndex Parse(string source, string path)
    {
        var tokens = CSharpLexer.Tokenize(source);
        var result = new FileIndex { Path = path, Language = "cs", Parsed = true };
        try
        {
            new State(tokens, result).Run();
        }
        catch (Exception ex) when (ex is ArgumentOutOfRangeException or IndexOutOfRangeException or InvalidOperationException)
        {
            // Defensive: a parser bug must never break indexing of the rest of the repository.
            result.Parsed = false;
        }
        return result;
    }

    private sealed class State(List<Token> tokens, FileIndex result)
    {
        private readonly Stack<Scope> _scopes = new();
        private readonly List<Token> _header = [];
        private readonly List<int> _headerIdx = [];
        private readonly List<AttributeInfo> _pendingAttributes = [];
        private int _headerStartLine;
        private string _fileNamespace = "";
        private SymbolRecord? _topLevel;
        private readonly SymbolRecord?[] _owners = new SymbolRecord?[tokens.Count];
        private readonly Dictionary<SymbolRecord, (HashSet<string> Calls, HashSet<string> Uses)> _refs = new(ReferenceEqualityComparer.Instance);

        public void Run()
        {
            _scopes.Push(new Scope { Kind = ScopeKind.File });
            for (var i = 0; i < tokens.Count; i++)
            {
                var t = tokens[i];
                var scope = _scopes.Peek();
                _owners[i] = OwnerOf(scope);

                switch (scope.Kind)
                {
                    case ScopeKind.Body:
                        if (t.IsPunct('{'))
                        {
                            _scopes.Push(new Scope { Kind = ScopeKind.Body, Symbol = scope.Symbol, Namespace = scope.Namespace });
                        }
                        else if (t.IsPunct('}'))
                        {
                            Close(t);
                        }
                        continue;
                    case ScopeKind.Accessors:
                        if (t.IsPunct('{'))
                        {
                            _scopes.Push(new Scope { Kind = ScopeKind.Body, Symbol = scope.Symbol, Namespace = scope.Namespace });
                        }
                        else if (t.IsPunct('}'))
                        {
                            Close(t);
                            // Auto-property initializer: "{ get; } = value;" belongs to the property.
                            if (i + 1 < tokens.Count && tokens[i + 1].IsPunct('='))
                            {
                                i = SkipToStatementEnd(i + 1, scope.Symbol);
                            }
                        }
                        continue;
                    case ScopeKind.Transparent:
                        _header.Add(t);
                        _headerIdx.Add(i);
                        if (t.IsPunct('{'))
                        {
                            _scopes.Push(new Scope { Kind = ScopeKind.Transparent, Namespace = scope.Namespace, Symbol = scope.Symbol });
                        }
                        else if (t.IsPunct('}'))
                        {
                            _scopes.Pop();
                        }
                        continue;
                    case ScopeKind.Enum:
                        if (t.IsPunct('}'))
                        {
                            Close(t);
                        }
                        else if (t.IsPunct('['))
                        {
                            i = SkipBalanced(i, '[', ']');
                        }
                        else if (t.Kind == TokenKind.Identifier && (i == 0 || tokens[i - 1].IsPunct('{') || tokens[i - 1].IsPunct(',') || tokens[i - 1].IsPunct(']')))
                        {
                            AddSymbol(new SymbolRecord
                            {
                                Kind = SymbolKinds.EnumMember, Name = t.Text, FullName = scope.Symbol!.FullName + "." + t.Text,
                                Container = scope.Symbol.FullName, Namespace = scope.Namespace, Signature = t.Text, StartLine = t.Line, EndLine = t.Line,
                            });
                        }
                        continue;
                }

                // Declaration scopes (file, namespace, type).
                if (t.IsPunct('[') && _header.Count == 0)
                {
                    var end = SkipBalanced(i, '[', ']');
                    if (_pendingAttributes.Count == 0)
                    {
                        _headerStartLine = t.Line;
                    }
                    _pendingAttributes.AddRange(ParseAttributes(i + 1, end));
                    for (var k = i; k <= end && k < tokens.Count; k++)
                    {
                        _owners[k] = OwnerOf(scope);
                    }
                    i = end;
                    continue;
                }
                if (t.IsPunct(';'))
                {
                    EndStatement(scope, t);
                    continue;
                }
                if (t.IsPunct('{'))
                {
                    OpenBlock(scope, t, i);
                    continue;
                }
                if (t.IsPunct('}'))
                {
                    ResetHeader();
                    Close(t);
                    continue;
                }
                if (_header.Count == 0 && _pendingAttributes.Count == 0)
                {
                    _headerStartLine = t.Line;
                }
                _header.Add(t);
                _headerIdx.Add(i);
            }

            // Unclosed scopes (truncated file): close at the last line.
            var lastLine = tokens.Count > 0 ? tokens[^1].Line : 1;
            while (_scopes.Count > 1)
            {
                var s = _scopes.Pop();
                if (s.Symbol is not null && s.Kind is ScopeKind.Type or ScopeKind.Enum)
                {
                    s.Symbol.EndLine = Math.Max(s.Symbol.EndLine, lastLine);
                }
            }
            if (_header.Count > 0 && _scopes.Peek().Kind == ScopeKind.File && IsTopLevelStatement(_header))
            {
                AttachTopLevel(_header[^1].Line);
            }

            CollectReferences();
            DetectPatterns();
            BuildControllerEndpoints();
            result.Namespaces = result.Symbols.Where(s => s.Namespace.Length > 0).Select(s => s.Namespace).Distinct(StringComparer.Ordinal).ToList();
        }

        private static SymbolRecord? OwnerOf(Scope scope) => scope.Symbol;

        private string CurrentNamespace()
        {
            foreach (var s in _scopes)
            {
                if (s.Kind is ScopeKind.Namespace or ScopeKind.Type or ScopeKind.Enum)
                {
                    return s.Namespace;
                }
            }
            return _fileNamespace;
        }

        private SymbolRecord? CurrentType()
        {
            var top = _scopes.Peek();
            return top.Kind == ScopeKind.Type ? top.Symbol : null;
        }

        private void ResetHeader()
        {
            _header.Clear();
            _headerIdx.Clear();
            _pendingAttributes.Clear();
        }

        private void Close(Token t)
        {
            if (_scopes.Count <= 1)
            {
                return; // Unbalanced brace; ignore.
            }
            var scope = _scopes.Pop();
            if (scope.Symbol is not null && scope.Kind is ScopeKind.Type or ScopeKind.Enum or ScopeKind.Accessors
                || scope.Symbol is not null && scope.Kind == ScopeKind.Body && _scopes.Peek().Kind is not (ScopeKind.Body or ScopeKind.Accessors))
            {
                scope.Symbol!.EndLine = Math.Max(scope.Symbol.EndLine, t.Line);
            }
        }

        private int SkipBalanced(int start, char open, char close)
        {
            var depth = 0;
            for (var k = start; k < tokens.Count; k++)
            {
                if (tokens[k].IsPunct(open))
                {
                    depth++;
                }
                else if (tokens[k].IsPunct(close) && --depth == 0)
                {
                    return k;
                }
            }
            return tokens.Count - 1;
        }

        private int SkipToStatementEnd(int start, SymbolRecord? owner)
        {
            var depth = 0;
            for (var k = start; k < tokens.Count; k++)
            {
                _owners[k] = owner;
                var tk = tokens[k];
                if (tk.IsPunct('{') || tk.IsPunct('(') || tk.IsPunct('['))
                {
                    depth++;
                }
                else if (tk.IsPunct('}') || tk.IsPunct(')') || tk.IsPunct(']'))
                {
                    depth--;
                }
                else if (tk.IsPunct(';') && depth <= 0)
                {
                    if (owner is not null)
                    {
                        owner.EndLine = Math.Max(owner.EndLine, tk.Line);
                    }
                    return k;
                }
            }
            return tokens.Count - 1;
        }

        private List<AttributeInfo> ParseAttributes(int from, int toExclusive)
        {
            var list = new List<AttributeInfo>();
            var depth = 0;
            var segmentStart = from;
            for (var k = from; k <= toExclusive && k < tokens.Count; k++)
            {
                var tk = tokens[k];
                if (tk.IsPunct('(') || tk.IsPunct('['))
                {
                    depth++;
                }
                else if (tk.IsPunct(')') || tk.IsPunct(']') && k != toExclusive)
                {
                    depth--;
                }
                if (depth == 0 && (tk.IsPunct(',') || k == toExclusive))
                {
                    if (ParseAttribute(segmentStart, k) is { } attr)
                    {
                        list.Add(attr);
                    }
                    segmentStart = k + 1;
                }
            }
            return list;
        }

        private AttributeInfo? ParseAttribute(int from, int toExclusive)
        {
            string? name = null;
            var args = new List<string>();
            var line = from < tokens.Count ? tokens[from].Line : 0;
            var inArgs = false;
            for (var k = from; k < toExclusive; k++)
            {
                var tk = tokens[k];
                if (!inArgs)
                {
                    if (tk.IsPunct(':'))
                    {
                        name = null; // Attribute target ("assembly:", "return:").
                        continue;
                    }
                    if (tk.IsPunct('('))
                    {
                        inArgs = true;
                        continue;
                    }
                    if (tk.Kind == TokenKind.Identifier)
                    {
                        name = tk.Text;
                    }
                }
                else if (tk.Kind == TokenKind.String)
                {
                    args.Add(tk.Text);
                }
            }
            if (name is null)
            {
                return null;
            }
            if (name.EndsWith("Attribute", StringComparison.Ordinal) && name.Length > "Attribute".Length)
            {
                name = name[..^"Attribute".Length];
            }
            return new AttributeInfo(name, args, line);
        }

        private void EndStatement(Scope scope, Token semicolon)
        {
            var header = _header;
            if (header.Count == 0)
            {
                ResetHeader();
                return;
            }
            var first = header[0];

            if (scope.Kind is ScopeKind.File or ScopeKind.Namespace)
            {
                if (first.Is("using") || first.Is("global") && header.Count > 1 && header[1].Is("using"))
                {
                    var start = first.Is("global") ? 2 : 1;
                    var text = string.Concat(header.Skip(start).Select(x => x.Text));
                    if (text.Length > 0 && !text.StartsWith('('))
                    {
                        result.Usings.Add(text);
                    }
                }
                else if (first.Is("namespace"))
                {
                    _fileNamespace = QualifiedName(header, 1);
                    scope.Namespace = _fileNamespace;
                }
                else if (first.Is("extern"))
                {
                    // extern alias
                }
                else if (IsTypeOrDelegateDeclaration(header))
                {
                    DeclareTypeOrDelegate(header, semicolon.Line, hasBody: false);
                }
                else if (scope.Kind == ScopeKind.File && IsTopLevelStatement(header))
                {
                    AttachTopLevel(semicolon.Line);
                }
                ResetHeader();
                return;
            }

            if (scope.Kind == ScopeKind.Type)
            {
                if (IsTypeOrDelegateDeclaration(header))
                {
                    DeclareTypeOrDelegate(header, semicolon.Line, hasBody: false);
                }
                else
                {
                    DeclareMemberFromStatement(header, semicolon.Line);
                }
            }
            ResetHeader();
        }

        private void OpenBlock(Scope scope, Token brace, int index)
        {
            var header = _header;
            if (scope.Kind is ScopeKind.File or ScopeKind.Namespace)
            {
                if (header.Count > 0 && header[0].Is("namespace"))
                {
                    var name = QualifiedName(header, 1);
                    var ns = CurrentNamespace();
                    _scopes.Push(new Scope { Kind = ScopeKind.Namespace, Namespace = ns.Length == 0 ? name : ns + "." + name });
                    ResetHeader();
                    return;
                }
                if (FindTypeKeyword(header) >= 0)
                {
                    DeclareTypeOrDelegate(header, brace.Line, hasBody: true);
                    ResetHeader();
                    return;
                }
                // Top-level statement containing a block (lambda, initializer, if/for...).
                var owner = scope.Kind == ScopeKind.File ? AttachTopLevel(brace.Line) : null;
                _owners[index] = owner;
                _scopes.Push(new Scope { Kind = ScopeKind.Transparent, Namespace = scope.Namespace, Symbol = owner });
                _header.Add(brace);
                _headerIdx.Add(index);
                return;
            }

            if (scope.Kind == ScopeKind.Type)
            {
                var arrow = DepthZeroIndex(header, "=>");
                var assign = DepthZeroIndex(header, "=");
                var paren = ParameterListIndex(header);
                var typeKeyword = FindTypeKeyword(header);
                if (typeKeyword >= 0 && (paren < 0 || typeKeyword < paren) && assign < 0)
                {
                    DeclareTypeOrDelegate(header, brace.Line, hasBody: true);
                    ResetHeader();
                    return;
                }
                if (arrow >= 0 || assign >= 0 && (paren < 0 || assign < paren))
                {
                    // Expression body or initializer containing braces; the member is declared at the ';'.
                    _scopes.Push(new Scope { Kind = ScopeKind.Transparent, Namespace = scope.Namespace, Symbol = scope.Symbol });
                    _header.Add(brace);
                    _headerIdx.Add(index);
                    return;
                }
                if (paren >= 0)
                {
                    var method = DeclareMethod(header, brace.Line);
                    _owners[index] = method;
                    _scopes.Push(new Scope { Kind = ScopeKind.Body, Symbol = method, Namespace = scope.Namespace });
                    ResetHeader();
                    return;
                }
                var property = DeclarePropertyLike(header, brace.Line);
                _owners[index] = property;
                _scopes.Push(new Scope { Kind = ScopeKind.Accessors, Symbol = property, Namespace = scope.Namespace });
                ResetHeader();
                return;
            }

            ResetHeader();
        }

        private static bool IsTopLevelStatement(List<Token> header)
        {
            if (header.Count == 0)
            {
                return false;
            }
            var first = header[0];
            return !(first.Is("using") || first.Is("namespace") || first.Is("extern") || first.Is("global") || first.IsPunct('[')
                     || first.Text is "public" or "internal" or "private" or "protected" or "file" or "abstract" or "sealed" or "delegate"
                     || IsTypeOrDelegateDeclaration(header));
        }

        private static bool IsTypeOrDelegateDeclaration(List<Token> header)
        {
            if (FindTypeKeyword(header) >= 0)
            {
                return true;
            }
            var d = header.FindIndex(h => h.Is("delegate"));
            if (d < 0 || header.Take(d).Any(h => !Modifiers.Contains(h.Text)))
            {
                return false;
            }
            var paren = ParameterListIndex(header);
            var assign = DepthZeroIndex(header, "=");
            return paren > d + 1 && assign < 0;
        }

        private SymbolRecord AttachTopLevel(int line)
        {
            if (_topLevel is null)
            {
                _topLevel = new SymbolRecord
                {
                    Kind = SymbolKinds.TopLevel, Name = "<top-level statements>", FullName = "Program.<top-level statements>",
                    Container = "Program", Namespace = "", Signature = "top-level statements", StartLine = _header.Count > 0 ? _header[0].Line : line, EndLine = line,
                };
                AddSymbol(_topLevel);
            }
            _topLevel.EndLine = Math.Max(_topLevel.EndLine, line);
            // Header tokens were recorded with the file scope's owner (none); attribute them to the top-level symbol.
            foreach (var idx in _headerIdx)
            {
                _owners[idx] ??= _topLevel;
            }
            return _topLevel;
        }

        /// <summary>Index of the type-declaring keyword (class/struct/interface/enum/record) at depth 0, or -1.</summary>
        private static int FindTypeKeyword(List<Token> header)
        {
            var depth = 0;
            for (var k = 0; k < header.Count; k++)
            {
                var h = header[k];
                if (h.IsPunct('(') || h.IsPunct('<') || h.IsPunct('['))
                {
                    depth++;
                }
                else if (h.IsPunct(')') || h.IsPunct('>') || h.IsPunct(']'))
                {
                    depth--;
                }
                if (depth != 0)
                {
                    continue;
                }
                if (h.IsPunct('=') || h.IsPunct(':') || h.Is("where") || h.Is("=>") || h.IsPunct('.'))
                {
                    return -1;
                }
                if (h.Kind == TokenKind.Keyword && h.Text is "class" or "struct" or "interface" or "enum")
                {
                    return k + 1 < header.Count && header[k + 1].Kind == TokenKind.Identifier ? k : -1;
                }
                if (h.Kind == TokenKind.Identifier && h.Text == "record" && k + 1 < header.Count
                    && (header[k + 1].Kind == TokenKind.Identifier || header[k + 1].Is("class") || header[k + 1].Is("struct")))
                {
                    return k;
                }
            }
            return -1;
        }

        /// <summary>
        /// The '(' that opens a member's parameter list: the first depth-zero '(' right after the member name (an
        /// identifier, possibly with generic arguments) or after an operator. A tuple type's '(' follows a modifier,
        /// '&lt;' or nothing, so "public (int A, int B) Read(string id)" finds the one after Read. -1 when there is none.
        /// </summary>
        private static int ParameterListIndex(List<Token> header)
        {
            var depth = 0;
            var afterOperator = false;
            for (var k = 0; k < header.Count; k++)
            {
                var h = header[k];
                if (depth == 0 && h.IsPunct('('))
                {
                    var name = NameBefore(header, k);
                    if (afterOperator || name >= 0 && header[name].Kind == TokenKind.Identifier)
                    {
                        return k;
                    }
                }
                afterOperator |= depth == 0 && h.Is("operator");
                if (h.IsPunct('(') || h.IsPunct('[') || h.IsPunct('{'))
                {
                    depth++;
                }
                else if (h.IsPunct(')') || h.IsPunct(']') || h.IsPunct('}'))
                {
                    depth--;
                }
            }
            return -1;
        }

        private static int DepthZeroIndex(List<Token> header, string text)
        {
            var depth = 0;
            for (var k = 0; k < header.Count; k++)
            {
                var h = header[k];
                if (depth == 0 && h.Text == text && h.Kind == TokenKind.Punct)
                {
                    return k;
                }
                if (h.IsPunct('(') || h.IsPunct('[') || h.IsPunct('{'))
                {
                    depth++;
                }
                else if (h.IsPunct(')') || h.IsPunct(']') || h.IsPunct('}'))
                {
                    depth--;
                }
            }
            return -1;
        }

        private static string QualifiedName(List<Token> header, int start)
        {
            var parts = new List<string>();
            for (var k = start; k < header.Count; k++)
            {
                if (header[k].Kind == TokenKind.Identifier)
                {
                    parts.Add(header[k].Text);
                }
                else if (!header[k].IsPunct('.'))
                {
                    break;
                }
            }
            return string.Join('.', parts);
        }

        private List<string> ModifiersOf(List<Token> header, int until)
            => header.Take(Math.Max(0, until)).Where(h => Modifiers.Contains(h.Text) && h.Kind is TokenKind.Keyword or TokenKind.Identifier).Select(h => h.Text).Distinct().ToList();

        private void DeclareTypeOrDelegate(List<Token> header, int line, bool hasBody)
        {
            var ns = CurrentNamespace();
            var container = CurrentType();
            var keywordIndex = FindTypeKeyword(header);
            var attributes = _pendingAttributes.ToList();

            if (keywordIndex < 0)
            {
                // delegate R Name(params);
                var d = header.FindIndex(h => h.Is("delegate"));
                var paren = ParameterListIndex(header);
                if (d < 0 || paren <= d + 1)
                {
                    return;
                }
                var nameIndex = NameBefore(header, paren);
                var name = nameIndex >= 0 ? header[nameIndex].Text : "delegate";
                AddSymbol(new SymbolRecord
                {
                    Kind = SymbolKinds.Delegate, Name = name, FullName = Join(container?.FullName ?? ns, name), Container = container?.FullName,
                    Namespace = ns, Signature = Signature(header), Modifiers = ModifiersOf(header, d), Attributes = attributes.Select(a => a.Name).ToList(),
                    ReturnType = TypeText(header, d + 1, nameIndex), ParameterTypes = ParameterTypes(header, paren),
                    StartLine = StartLine(header), EndLine = line,
                });
                return;
            }

            var keyword = header[keywordIndex].Text;
            var nameAt = keywordIndex + 1;
            if (keyword == "record" && nameAt < header.Count && (header[nameAt].Is("class") || header[nameAt].Is("struct")))
            {
                nameAt++;
            }
            if (nameAt >= header.Count || header[nameAt].Kind != TokenKind.Identifier)
            {
                return;
            }
            var typeName = header[nameAt].Text;
            var kind = keyword switch
            {
                "class" => SymbolKinds.Class,
                "struct" => SymbolKinds.Struct,
                "interface" => SymbolKinds.Interface,
                "enum" => SymbolKinds.Enum,
                _ => SymbolKinds.Record,
            };

            var k2 = nameAt + 1;
            if (k2 < header.Count && header[k2].IsPunct('<'))
            {
                k2 = SkipAngle(header, k2) + 1;
            }
            var parameterTypes = new List<string>();
            if (k2 < header.Count && header[k2].IsPunct('('))
            {
                parameterTypes = ParameterTypes(header, k2);
                k2 = SkipParen(header, k2) + 1;
            }
            var bases = new List<string>();
            if (k2 < header.Count && header[k2].IsPunct(':'))
            {
                bases = BaseList(header, k2 + 1);
            }

            var symbol = new SymbolRecord
            {
                Kind = kind, Name = typeName, FullName = Join(container?.FullName ?? ns, typeName), Container = container?.FullName, Namespace = ns,
                Signature = Signature(header), Modifiers = ModifiersOf(header, keywordIndex), Attributes = attributes.Select(a => a.Name).ToList(),
                Bases = bases, ParameterTypes = parameterTypes, StartLine = StartLine(header), EndLine = line,
                IsTest = attributes.Any(a => a.Name is "TestClass" or "TestFixture"),
            };
            AddSymbol(symbol);
            if (hasBody)
            {
                var scope = new Scope { Kind = kind == SymbolKinds.Enum ? ScopeKind.Enum : ScopeKind.Type, Symbol = symbol, Namespace = ns, TypeAttributes = attributes };
                _scopes.Push(scope);
                _typeAttributes[symbol] = attributes;
            }
            else
            {
                _typeAttributes[symbol] = attributes;
            }
        }

        private readonly Dictionary<SymbolRecord, List<AttributeInfo>> _typeAttributes = new(ReferenceEqualityComparer.Instance);
        private readonly Dictionary<SymbolRecord, List<AttributeInfo>> _memberAttributes = new(ReferenceEqualityComparer.Instance);

        private int StartLine(List<Token> header) => _pendingAttributes.Count > 0 ? Math.Min(_headerStartLine, header.Count > 0 ? header[0].Line : _headerStartLine) : header.Count > 0 ? header[0].Line : _headerStartLine;

        private static string Join(string prefix, string name) => prefix.Length == 0 ? name : prefix + "." + name;

        /// <summary>"System.Collections.Generic.List&lt;int&gt;?" → "List&lt;int&gt;": drops namespace qualification and nullability.</summary>
        internal static string SimpleTypeName(string text)
        {
            text = text.TrimEnd('?');
            var lt = text.IndexOf('<');
            var head = lt >= 0 ? text[..lt] : text;
            var dot = head.LastIndexOf('.');
            return dot >= 0 ? text[(dot + 1)..] : text;
        }

        private static int SkipAngle(List<Token> header, int start)
        {
            var depth = 0;
            for (var k = start; k < header.Count; k++)
            {
                if (header[k].IsPunct('<'))
                {
                    depth++;
                }
                else if (header[k].IsPunct('>') && --depth == 0)
                {
                    return k;
                }
                else if (header[k].IsPunct('{') || header[k].IsPunct(';'))
                {
                    return k - 1;
                }
            }
            return header.Count - 1;
        }

        private static int SkipParen(List<Token> header, int start)
        {
            var depth = 0;
            for (var k = start; k < header.Count; k++)
            {
                if (header[k].IsPunct('('))
                {
                    depth++;
                }
                else if (header[k].IsPunct(')') && --depth == 0)
                {
                    return k;
                }
            }
            return header.Count - 1;
        }

        private static List<string> BaseList(List<Token> header, int start)
        {
            var bases = new List<string>();
            var depth = 0;
            string? current = null;
            for (var k = start; k < header.Count; k++)
            {
                var h = header[k];
                if (depth == 0 && h.Is("where"))
                {
                    break;
                }
                if (h.IsPunct('<') || h.IsPunct('('))
                {
                    depth++;
                    continue;
                }
                if (h.IsPunct('>') || h.IsPunct(')'))
                {
                    depth--;
                    continue;
                }
                if (depth != 0)
                {
                    continue;
                }
                if (h.IsPunct(','))
                {
                    if (current is not null)
                    {
                        bases.Add(current);
                    }
                    current = null;
                    continue;
                }
                if (h.Kind is TokenKind.Identifier or TokenKind.Keyword && h.Text != "global")
                {
                    current = h.Text; // Last segment of a qualified name.
                }
            }
            if (current is not null)
            {
                bases.Add(current);
            }
            return bases;
        }

        /// <summary>Index of the member name before the token at <paramref name="before"/> (skipping generic parameters).</summary>
        private static int NameBefore(List<Token> header, int before)
        {
            var k = before - 1;
            if (k >= 0 && header[k].IsPunct('>'))
            {
                var depth = 0;
                for (; k >= 0; k--)
                {
                    if (header[k].IsPunct('>'))
                    {
                        depth++;
                    }
                    else if (header[k].IsPunct('<') && --depth == 0)
                    {
                        k--;
                        break;
                    }
                }
            }
            return k >= 0 && header[k].Kind is TokenKind.Identifier or TokenKind.Keyword ? k : -1;
        }

        private static string? TypeText(List<Token> header, int from, int toExclusive)
        {
            if (toExclusive <= from)
            {
                return null;
            }
            // Two words in a row only occur in a tuple ("(string Text, double Units)"), where they keep their space.
            var text = new System.Text.StringBuilder();
            Token? previous = null;
            foreach (var h in header.Skip(from).Take(toExclusive - from).Where(h => !Modifiers.Contains(h.Text)))
            {
                if (previous is { } p && p.Kind is TokenKind.Identifier or TokenKind.Keyword && h.Kind is TokenKind.Identifier or TokenKind.Keyword)
                {
                    text.Append(' ');
                }
                text.Append(h.Text);
                previous = h;
            }
            return text.Length == 0 ? null : text.Length > 120 ? text.ToString(0, 120) : text.ToString();
        }

        private static List<string> ParameterTypes(List<Token> header, int openParen)
        {
            var types = new List<string>();
            var close = SkipParen(header, openParen);
            var depth = 0;
            var segment = new List<Token>();
            for (var k = openParen + 1; k <= close && k < header.Count; k++)
            {
                var h = header[k];
                if (k == close || depth == 0 && h.IsPunct(','))
                {
                    if (ParameterType(segment) is { } type)
                    {
                        types.Add(type);
                    }
                    segment.Clear();
                    continue;
                }
                if (h.IsPunct('<') || h.IsPunct('(') || h.IsPunct('['))
                {
                    depth++;
                }
                else if (h.IsPunct('>') || h.IsPunct(')') || h.IsPunct(']'))
                {
                    depth--;
                }
                segment.Add(h);
            }
            return types;
        }

        /// <summary>Simple name of a parameter's type: "ILogger&lt;Foo&gt; logger" → "ILogger"; "IOptions&lt;X&gt; o" → "IOptions&lt;X&gt;".</summary>
        private static string? ParameterType(List<Token> segment)
        {
            var tokensOnly = segment.ToList();
            // Drop attributes and default values.
            var eq = tokensOnly.FindIndex(t => t.IsPunct('='));
            if (eq >= 0)
            {
                tokensOnly = tokensOnly.Take(eq).ToList();
            }
            while (tokensOnly.Count > 0 && tokensOnly[0].IsPunct('['))
            {
                var depth = 0;
                var k = 0;
                for (; k < tokensOnly.Count; k++)
                {
                    if (tokensOnly[k].IsPunct('['))
                    {
                        depth++;
                    }
                    else if (tokensOnly[k].IsPunct(']') && --depth == 0)
                    {
                        break;
                    }
                }
                tokensOnly = tokensOnly.Skip(k + 1).ToList();
            }
            tokensOnly = tokensOnly.Where(t => t.Text is not ("this" or "ref" or "out" or "in" or "params" or "scoped" or "readonly")).ToList();
            if (tokensOnly.Count < 2)
            {
                return null;
            }
            var text = string.Concat(tokensOnly.Take(tokensOnly.Count - 1).Select(t => t.Text));
            return SimpleTypeName(text);
        }

        private static string Signature(List<Token> header)
        {
            var sb = new System.Text.StringBuilder();
            Token? previous = null;
            foreach (var h in header)
            {
                if (previous is { } p && NeedsSpace(p, h))
                {
                    sb.Append(' ');
                }
                sb.Append(h.Kind == TokenKind.String ? "\"" + h.Text + "\"" : h.Text);
                previous = h;
                if (sb.Length > 300)
                {
                    sb.Append('…');
                    break;
                }
            }
            return sb.ToString();
        }

        private static bool NeedsSpace(Token a, Token b)
        {
            if (b.Kind == TokenKind.Punct && b.Text is "," or ")" or "." or ">" or "?" or "[" or "]" or ";" or "(" or "<" or "?.")
            {
                return b.Text is "(" && a.Kind == TokenKind.Keyword && a.Text is not ("this" or "base" or "typeof" or "nameof" or "default" or "sizeof");
            }
            if (a.Kind == TokenKind.Punct && a.Text is "(" or "." or "<" or "[" or "?.")
            {
                return false;
            }
            return true;
        }

        private SymbolRecord DeclareMethod(List<Token> header, int line)
        {
            var type = CurrentType();
            var ns = CurrentNamespace();
            var paren = ParameterListIndex(header);
            var nameIndex = NameBefore(header, paren);
            var name = nameIndex >= 0 ? header[nameIndex].Text : "method";
            var kind = SymbolKinds.Method;
            var operatorIndex = header.FindIndex(h => h.Is("operator"));
            if (operatorIndex >= 0 && operatorIndex < paren)
            {
                name = "operator " + string.Concat(header.Skip(operatorIndex + 1).Take(paren - operatorIndex - 1).Select(h => h.Text));
            }
            else if (nameIndex > 0 && header[nameIndex - 1].IsPunct('~'))
            {
                name = "~" + name;
            }
            else if (type is not null && name == type.Name && (nameIndex == 0 || Modifiers.Contains(header[nameIndex - 1].Text) || header[nameIndex - 1].IsPunct(']')))
            {
                kind = SymbolKinds.Constructor;
            }
            var firstNonModifier = header.FindIndex(h => !Modifiers.Contains(h.Text));
            var symbol = new SymbolRecord
            {
                Kind = kind, Name = name, FullName = Join(type?.FullName ?? ns, name), Container = type?.FullName, Namespace = ns,
                Signature = Signature(header), Modifiers = ModifiersOf(header, Math.Max(0, nameIndex)),
                Attributes = _pendingAttributes.Select(a => a.Name).ToList(),
                ReturnType = kind == SymbolKinds.Method && firstNonModifier >= 0 && nameIndex > firstNonModifier ? TypeText(header, firstNonModifier, nameIndex) : null,
                ParameterTypes = paren >= 0 ? ParameterTypes(header, paren) : [], StartLine = StartLine(header), EndLine = line,
                IsTest = _pendingAttributes.Any(a => TestAttributes.Contains(a.Name)),
            };
            AddSymbol(symbol);
            _memberAttributes[symbol] = _pendingAttributes.ToList();
            MarkHeaderOwnerStrict(symbol);
            return symbol;
        }

        private SymbolRecord DeclarePropertyLike(List<Token> header, int line)
        {
            var type = CurrentType();
            var ns = CurrentNamespace();
            var isEvent = header.Any(h => h.Is("event"));
            var thisIndex = header.FindIndex(h => h.Is("this"));
            var kind = isEvent ? SymbolKinds.Event : thisIndex >= 0 && thisIndex + 1 < header.Count && header[thisIndex + 1].IsPunct('[') ? SymbolKinds.Indexer : SymbolKinds.Property;
            var nameIndex = kind == SymbolKinds.Indexer ? thisIndex : LastIdentifier(header);
            var name = kind == SymbolKinds.Indexer ? "this[]" : nameIndex >= 0 ? header[nameIndex].Text : "property";
            var firstNonModifier = header.FindIndex(h => !Modifiers.Contains(h.Text) && !h.Is("event"));
            var symbol = new SymbolRecord
            {
                Kind = kind, Name = name, FullName = Join(type?.FullName ?? ns, name), Container = type?.FullName, Namespace = ns,
                Signature = Signature(header), Modifiers = ModifiersOf(header, Math.Max(0, nameIndex)), Attributes = _pendingAttributes.Select(a => a.Name).ToList(),
                ReturnType = nameIndex > firstNonModifier && firstNonModifier >= 0 ? TypeText(header, firstNonModifier, nameIndex) : null,
                StartLine = StartLine(header), EndLine = line,
            };
            AddSymbol(symbol);
            _memberAttributes[symbol] = _pendingAttributes.ToList();
            MarkHeaderOwnerStrict(symbol);
            return symbol;
        }

        private static int LastIdentifier(List<Token> header)
        {
            for (var k = header.Count - 1; k >= 0; k--)
            {
                if (header[k].Kind == TokenKind.Identifier)
                {
                    return k;
                }
            }
            return -1;
        }

        /// <summary>Handles a ';'-terminated member: field(s), abstract/interface/expression-bodied method, expression-bodied property.</summary>
        private void DeclareMemberFromStatement(List<Token> header, int line)
        {
            var paren = ParameterListIndex(header);
            var arrow = DepthZeroIndex(header, "=>");
            var assign = DepthZeroIndex(header, "=");
            var type = CurrentType();

            if (paren >= 0 && (arrow < 0 || paren < arrow) && (assign < 0 || paren < assign))
            {
                var method = DeclareMethod(header, line);
                method.Signature = Signature(arrow >= 0 ? header.Take(arrow).ToList() : header);
                return;
            }
            if (arrow >= 0 && (assign < 0 || arrow < assign))
            {
                var property = DeclarePropertyLike(header.Take(arrow).ToList(), line);
                property.Signature = Signature(header.Take(arrow).ToList());
                return;
            }

            // Field or event field: "T a = x, b;" → one symbol per declarator.
            var isEvent = header.Any(h => h.Is("event"));
            var isConst = header.Any(h => h.Is("const"));
            var declaration = assign >= 0 ? header.Take(assign).ToList() : header;
            var nameIndex = LastIdentifier(declaration);
            if (nameIndex < 0)
            {
                return;
            }
            var firstNonModifier = declaration.FindIndex(h => !Modifiers.Contains(h.Text) && !h.Is("event"));
            var typeText = firstNonModifier >= 0 && nameIndex > firstNonModifier ? TypeText(declaration, firstNonModifier, nameIndex) : null;
            var ns = CurrentNamespace();
            var names = new List<(string Name, int Index)> { (declaration[nameIndex].Text, nameIndex) };
            // Additional declarators after commas at depth 0 (outside the initializer).
            var depth = 0;
            for (var k = assign >= 0 ? assign : header.Count; k < header.Count; k++)
            {
                var h = header[k];
                if (h.IsPunct('(') || h.IsPunct('{') || h.IsPunct('[') || h.IsPunct('<'))
                {
                    depth++;
                }
                else if (h.IsPunct(')') || h.IsPunct('}') || h.IsPunct(']') || h.IsPunct('>'))
                {
                    depth--;
                }
                else if (depth == 0 && h.IsPunct(',') && k + 1 < header.Count && header[k + 1].Kind == TokenKind.Identifier
                         && (k + 2 >= header.Count || header[k + 2].IsPunct('=') || header[k + 2].IsPunct(',')))
                {
                    names.Add((header[k + 1].Text, k + 1));
                }
            }
            foreach (var (name, _) in names)
            {
                var symbol = new SymbolRecord
                {
                    Kind = isEvent ? SymbolKinds.Event : SymbolKinds.Field, Name = name, FullName = Join(type?.FullName ?? ns, name), Container = type?.FullName,
                    Namespace = ns, Signature = Signature(declaration), Modifiers = ModifiersOf(header, nameIndex), Attributes = _pendingAttributes.Select(a => a.Name).ToList(),
                    ReturnType = typeText, StartLine = StartLine(header), EndLine = line,
                };
                AddSymbol(symbol);
                MarkHeaderOwnerStrict(symbol);

                // const string Section = "X:Y" → a configuration section constant.
                if (isConst && assign >= 0 && assign + 1 < header.Count && header[assign + 1].Kind == TokenKind.String && typeText == "string"
                    && name.Contains("Section", StringComparison.Ordinal) && type is not null)
                {
                    result.Config.Add(new ConfigReference { Kind = "sectionConstant", Key = header[assign + 1].Text, Type = type.Name, Line = line, Owner = symbol.FullName });
                }
            }
        }

        /// <summary>Owns the current header's tokens (by line range) to <paramref name="symbol"/> where no nested owner exists.</summary>
        private void MarkHeaderOwnerStrict(SymbolRecord symbol)
        {
            var type = CurrentType();
            foreach (var idx in _headerIdx)
            {
                if (_owners[idx] is null || ReferenceEquals(_owners[idx], type))
                {
                    _owners[idx] = symbol;
                }
            }
        }

        private void AddSymbol(SymbolRecord symbol)
        {
            if (symbol.StartLine <= 0)
            {
                symbol.StartLine = symbol.EndLine;
            }
            result.Symbols.Add(symbol);
        }

        /// <summary>Per-file identifier occurrences and per-member call/use sets.</summary>
        private void CollectReferences()
        {
            for (var i = 0; i < tokens.Count; i++)
            {
                var t = tokens[i];
                if (t.Kind != TokenKind.Identifier || IgnoredReferenceNames.Contains(t.Text))
                {
                    continue;
                }
                if (!result.Identifiers.TryGetValue(t.Text, out var lines))
                {
                    lines = [];
                    result.Identifiers[t.Text] = lines;
                }
                if (lines.Count < MaxLinesPerIdentifier && (lines.Count == 0 || lines[^1] != t.Line))
                {
                    lines.Add(t.Line);
                }

                var owner = _owners[i];
                if (owner is null)
                {
                    continue;
                }
                if (!_refs.TryGetValue(owner, out var sets))
                {
                    sets = (new HashSet<string>(StringComparer.Ordinal), new HashSet<string>(StringComparer.Ordinal));
                    _refs[owner] = sets;
                }
                if (IsInvocation(i))
                {
                    if (sets.Calls.Count < MaxReferencesPerMember && t.Text != owner.Name)
                    {
                        sets.Calls.Add(t.Text);
                    }
                    else if (t.Text == owner.Name && i > 0 && tokens[i - 1].IsPunct('.'))
                    {
                        sets.Calls.Add(t.Text); // Recursion through a receiver (x.M()).
                    }
                }
                else if (char.IsUpper(t.Text[0]) && sets.Uses.Count < MaxReferencesPerMember)
                {
                    sets.Uses.Add(t.Text);
                }
            }
            foreach (var (symbol, sets) in _refs)
            {
                // Declaration names are not references to themselves.
                sets.Uses.Remove(symbol.Name);
                symbol.Calls = sets.Calls.ToList();
                symbol.Uses = sets.Uses.ToList();
            }
        }

        private bool IsInvocation(int i)
        {
            var k = i + 1;
            if (k < tokens.Count && tokens[k].IsPunct('<'))
            {
                // Generic invocation M<T>(...): find the matching '>' on the same line.
                var depth = 0;
                for (; k < tokens.Count && k < i + 40; k++)
                {
                    if (tokens[k].IsPunct('<'))
                    {
                        depth++;
                    }
                    else if (tokens[k].IsPunct('>') && --depth == 0)
                    {
                        break;
                    }
                    else if (tokens[k].IsPunct(';') || tokens[k].IsPunct('{') || tokens[k].IsPunct(')'))
                    {
                        return false;
                    }
                }
                k++;
            }
            return k < tokens.Count && tokens[k].IsPunct('(');
        }

        private void DetectPatterns()
        {
            var middlewareOrder = 0;
            for (var i = 0; i < tokens.Count; i++)
            {
                var t = tokens[i];
                if (t.Kind != TokenKind.Identifier)
                {
                    if (t.IsPunct('[') && i > 0 && i + 2 < tokens.Count && tokens[i + 1].Kind == TokenKind.String && tokens[i + 2].IsPunct(']')
                        && tokens[i - 1].Kind == TokenKind.Identifier
                        && (tokens[i - 1].Text.Contains("onfig", StringComparison.Ordinal) || tokens[i - 1].Text.Contains("Settings", StringComparison.Ordinal))
                        && tokens[i + 1].Text.Length is > 0 and < 200)
                    {
                        result.Config.Add(new ConfigReference { Kind = "indexer", Key = tokens[i + 1].Text, Line = t.Line, Owner = _owners[i]?.FullName });
                    }
                    continue;
                }
                var owner = _owners[i]?.FullName;
                var afterDot = i > 0 && (tokens[i - 1].IsPunct('.') || tokens[i - 1].Is("?."));

                if (afterDot && DiMethods.TryGetValue(t.Text, out var lifetime))
                {
                    DetectRegistration(i, lifetime, owner);
                    continue;
                }
                if (afterDot && t.Text is "GetSection" or "GetRequiredSection" or "GetValue" or "GetConnectionString" or "Bind")
                {
                    var open = NextOpenParen(i);
                    if (open > 0 && open + 1 < tokens.Count && tokens[open + 1].Kind == TokenKind.String)
                    {
                        var key = tokens[open + 1].Text;
                        var kind = t.Text switch
                        {
                            "GetValue" => "value",
                            "GetConnectionString" => "connectionString",
                            "Bind" => "bind",
                            _ => "section",
                        };
                        result.Config.Add(new ConfigReference
                        {
                            Kind = kind, Key = kind == "connectionString" ? "ConnectionStrings:" + key : key, Line = t.Line, Owner = owner,
                        });
                    }
                    continue;
                }
                if (afterDot && t.Text == "Configure" && i + 1 < tokens.Count && tokens[i + 1].IsPunct('<') && i + 3 < tokens.Count)
                {
                    // services.Configure<TOptions>(config.GetSection("X")) or (...GetSection(TOptions.Section))
                    var optionsType = tokens[i + 2].Text;
                    var open = NextOpenParen(i);
                    var close = open > 0 ? MatchParen(open) : -1;
                    string? key = null;
                    for (var k = open; k > 0 && k < close; k++)
                    {
                        if (tokens[k].Text is "GetSection" or "GetRequiredSection" && k + 2 < close)
                        {
                            key = tokens[k + 2].Kind == TokenKind.String
                                ? tokens[k + 2].Text
                                : string.Concat(tokens.Skip(k + 2).TakeWhile((x, idx) => k + 2 + idx < close && !x.IsPunct(')')).Select(x => x.Text));
                            break;
                        }
                    }
                    result.Config.Add(new ConfigReference { Kind = "optionsBinding", Key = key ?? "", Type = optionsType, Line = t.Line, Owner = owner });
                    continue;
                }
                if (afterDot && MapMethods.TryGetValue(t.Text, out var verb))
                {
                    var open = NextOpenParen(i);
                    if (open > 0)
                    {
                        var close = MatchParen(open);
                        var route = open + 1 < tokens.Count && tokens[open + 1].Kind == TokenKind.String ? tokens[open + 1].Text : t.Text == "MapFallback" ? "(fallback)" : "";
                        if (t.Text == "MapMethods" && open + 1 < close)
                        {
                            verb = string.Join(",", tokens.Skip(open + 2).Take(Math.Max(0, close - open - 2)).Where(x => x.Kind == TokenKind.String).Select(x => x.Text));
                        }
                        var handler = HandlerExpression(open, close);
                        result.Endpoints.Add(new EndpointRecord { Verb = verb, Route = route, Handler = handler ?? owner ?? "", Style = "minimal", Line = t.Line });
                    }
                    continue;
                }
                if (afterDot && t.Text is "MapHub" or "MapGrpcService" && i + 2 < tokens.Count && tokens[i + 1].IsPunct('<'))
                {
                    var open = NextOpenParen(i);
                    var route = open > 0 && open + 1 < tokens.Count && tokens[open + 1].Kind == TokenKind.String ? tokens[open + 1].Text : "";
                    result.Endpoints.Add(new EndpointRecord { Verb = "*", Route = route, Handler = tokens[i + 2].Text, Style = t.Text == "MapHub" ? "hub" : "grpc", Line = t.Line });
                    continue;
                }
                if (afterDot && t.Text == "UseMiddleware" && i + 2 < tokens.Count && tokens[i + 1].IsPunct('<'))
                {
                    result.Middleware.Add(new MiddlewareRecord { Name = tokens[i + 2].Text, Order = ++middlewareOrder, Line = t.Line, Owner = owner });
                    continue;
                }
                if (afterDot && t.Text.StartsWith("Use", StringComparison.Ordinal) && t.Text.Length > 3 && char.IsUpper(t.Text[3])
                    && i + 1 < tokens.Count && tokens[i + 1].IsPunct('(') && i >= 2 && tokens[i - 2].Kind == TokenKind.Identifier
                    && tokens[i - 2].Text is "app" or "application" or "builder" or "App" && t.Text is not ("UseSerilog" or "UseUrls" or "UseContentRoot" or "UseEnvironment" or "UseKestrel" or "UseDefaultServiceProvider"))
                {
                    result.Middleware.Add(new MiddlewareRecord { Name = t.Text, Order = ++middlewareOrder, Line = t.Line, Owner = owner });
                    continue;
                }
                if (afterDot && t.Text == "Use" && i + 1 < tokens.Count && tokens[i + 1].IsPunct('(') && i >= 2 && tokens[i - 2].Text is "app" or "application")
                {
                    result.Middleware.Add(new MiddlewareRecord { Name = "(inline middleware)", Order = ++middlewareOrder, Line = t.Line, Owner = owner });
                }
            }
        }

        private string? HandlerExpression(int open, int close)
        {
            // Second argument: a method group ("Handlers.GetOrder") or a lambda.
            var depth = 0;
            for (var k = open + 1; k < close; k++)
            {
                var tk = tokens[k];
                if (tk.IsPunct('(') || tk.IsPunct('{') || tk.IsPunct('['))
                {
                    depth++;
                }
                else if (tk.IsPunct(')') || tk.IsPunct('}') || tk.IsPunct(']'))
                {
                    depth--;
                }
                else if (depth == 0 && tk.IsPunct(','))
                {
                    var parts = new List<string>();
                    for (var m = k + 1; m < close && parts.Count < 8; m++)
                    {
                        if (tokens[m].Is("=>") || tokens[m].IsPunct('(') && parts.Count == 0)
                        {
                            return "(lambda)";
                        }
                        if (tokens[m].IsPunct(',') || tokens[m].IsPunct(')'))
                        {
                            break;
                        }
                        parts.Add(tokens[m].Text);
                    }
                    var text = string.Concat(parts);
                    return text.Length == 0 ? null : text.Contains("=>", StringComparison.Ordinal) ? "(lambda)" : text;
                }
            }
            return null;
        }

        private int NextOpenParen(int i)
        {
            var k = i + 1;
            if (k < tokens.Count && tokens[k].IsPunct('<'))
            {
                var depth = 0;
                for (; k < tokens.Count && k < i + 60; k++)
                {
                    if (tokens[k].IsPunct('<'))
                    {
                        depth++;
                    }
                    else if (tokens[k].IsPunct('>') && --depth == 0)
                    {
                        k++;
                        break;
                    }
                }
            }
            return k < tokens.Count && tokens[k].IsPunct('(') ? k : -1;
        }

        private int MatchParen(int open)
        {
            var depth = 0;
            for (var k = open; k < tokens.Count; k++)
            {
                if (tokens[k].IsPunct('('))
                {
                    depth++;
                }
                else if (tokens[k].IsPunct(')') && --depth == 0)
                {
                    return k;
                }
            }
            return tokens.Count - 1;
        }

        private void DetectRegistration(int i, string lifetime, string? owner)
        {
            var method = tokens[i].Text;
            var generics = new List<string>();
            var k = i + 1;
            if (k < tokens.Count && tokens[k].IsPunct('<'))
            {
                var depth = 0;
                var segment = new System.Text.StringBuilder();
                for (; k < tokens.Count && k < i + 80; k++)
                {
                    var tk = tokens[k];
                    if (tk.IsPunct('<') && ++depth == 1)
                    {
                        continue;
                    }
                    if (tk.IsPunct('>') && --depth == 0)
                    {
                        if (segment.Length > 0)
                        {
                            generics.Add(SimpleTypeName(segment.ToString()));
                        }
                        k++;
                        break;
                    }
                    if (depth == 1 && tk.IsPunct(','))
                    {
                        generics.Add(SimpleTypeName(segment.ToString()));
                        segment.Clear();
                        continue;
                    }
                    if (tk.IsPunct(';') || tk.IsPunct('{'))
                    {
                        return;
                    }
                    segment.Append(tk.Text);
                }
            }
            if (k >= tokens.Count || !tokens[k].IsPunct('('))
            {
                return;
            }
            var close = MatchParen(k);
            var argTokens = tokens.Skip(k + 1).Take(Math.Max(0, close - k - 1)).ToList();
            var hasLambda = argTokens.Any(a => a.Is("=>"));
            var typeofs = new List<string>();
            for (var a = 0; a + 2 < argTokens.Count; a++)
            {
                if (argTokens[a].Is("typeof") && argTokens[a + 1].IsPunct('('))
                {
                    var name = argTokens.Skip(a + 2).TakeWhile(x => !x.IsPunct(')') && !x.IsPunct('<')).LastOrDefault(x => x.Kind == TokenKind.Identifier).Text;
                    if (name is not null)
                    {
                        typeofs.Add(name);
                    }
                }
            }
            string? newed = null;
            if (!hasLambda)
            {
                var n = argTokens.FindIndex(a => a.Is("new"));
                if (n >= 0 && n + 1 < argTokens.Count && argTokens[n + 1].Kind == TokenKind.Identifier)
                {
                    newed = argTokens[n + 1].Text;
                }
            }
            else
            {
                // Factory lambdas: "sp => new Foo(...)" or "sp => sp.GetRequiredService<Foo>()" still tell us the implementation.
                var n = argTokens.FindIndex(a => a.Is("new"));
                if (n >= 0 && n + 1 < argTokens.Count && argTokens[n + 1].Kind == TokenKind.Identifier)
                {
                    newed = argTokens[n + 1].Text;
                }
                var resolve = argTokens.FindIndex(a => a.Text is "GetRequiredService" or "GetService");
                if (newed is null && resolve >= 0 && resolve + 2 < argTokens.Count && argTokens[resolve + 1].IsPunct('<') && argTokens[resolve + 2].Kind == TokenKind.Identifier)
                {
                    newed = argTokens[resolve + 2].Text;
                }
            }

            string service;
            string implementation;
            if (method == "AddHostedService")
            {
                service = "IHostedService";
                implementation = generics.FirstOrDefault() ?? newed ?? "(factory)";
            }
            else if (generics.Count >= 2)
            {
                service = generics[0];
                implementation = generics[1];
            }
            else if (generics.Count == 1 && (method.StartsWith("AddDbContext", StringComparison.Ordinal) || method == "AddHttpClient"))
            {
                service = generics[0];
                implementation = generics[0];
            }
            else if (generics.Count == 1)
            {
                service = generics[0];
                implementation = hasLambda ? newed ?? "(factory)" : newed ?? (argTokens.Count > 0 ? "(instance)" : generics[0]);
            }
            else if (typeofs.Count >= 2)
            {
                service = typeofs[0];
                implementation = typeofs[1];
            }
            else if (typeofs.Count == 1)
            {
                service = typeofs[0];
                implementation = typeofs[0];
            }
            else if (newed is not null)
            {
                service = newed;
                implementation = newed;
            }
            else
            {
                return;
            }

            result.Registrations.Add(new DiRegistration
            {
                Lifetime = lifetime, ServiceType = service, ImplementationType = implementation, Factory = hasLambda,
                Hosted = method == "AddHostedService", Method = method, Line = tokens[i].Line, Owner = owner,
            });
        }

        private void BuildControllerEndpoints()
        {
            foreach (var (type, attributes) in _typeAttributes)
            {
                var isController = type.Name.EndsWith("Controller", StringComparison.Ordinal) && type.Kind == SymbolKinds.Class
                                   || attributes.Any(a => a.Name == "ApiController")
                                   || type.Bases.Any(b => b is "Controller" or "ControllerBase");
                if (!isController)
                {
                    continue;
                }
                var controllerName = type.Name.EndsWith("Controller", StringComparison.Ordinal) ? type.Name[..^"Controller".Length] : type.Name;
                var classRoute = attributes.FirstOrDefault(a => a.Name == "Route")?.StringArgs.FirstOrDefault() ?? "";
                foreach (var (member, memberAttributes) in _memberAttributes)
                {
                    if (member.Container != type.FullName || member.Kind != SymbolKinds.Method)
                    {
                        continue;
                    }
                    var methodRoute = memberAttributes.FirstOrDefault(a => a.Name == "Route")?.StringArgs.FirstOrDefault();
                    foreach (var attribute in memberAttributes)
                    {
                        if (!HttpAttributes.TryGetValue(attribute.Name, out var httpVerb))
                        {
                            continue;
                        }
                        var template = attribute.StringArgs.FirstOrDefault() ?? methodRoute ?? "";
                        var route = template.StartsWith('/') || template.StartsWith('~')
                            ? template.TrimStart('~')
                            : string.Join('/', new[] { classRoute, template }.Where(x => x.Length > 0));
                        route = route.Replace("[controller]", controllerName, StringComparison.OrdinalIgnoreCase)
                                     .Replace("[action]", member.Name, StringComparison.OrdinalIgnoreCase);
                        result.Endpoints.Add(new EndpointRecord
                        {
                            Verb = httpVerb, Route = "/" + route.TrimStart('/'), Handler = member.FullName, Style = "controller", Line = member.StartLine,
                        });
                    }
                }
            }
        }
    }
}
