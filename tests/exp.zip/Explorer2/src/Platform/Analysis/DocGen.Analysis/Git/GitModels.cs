using System.Globalization;
using System.Text;

namespace DocGen.Analysis.Git;

/// <summary>One changed path in the working tree (index and work tree combined), with line counts where known.</summary>
public sealed class GitFileChange
{
    public string Path { get; set; } = "";
    public string? OriginalPath { get; set; }

    /// <summary>modified | added | deleted | renamed | copied | untracked | conflicted | typechange</summary>
    public string Kind { get; set; } = "modified";

    /// <summary>Porcelain XY code ("M.", ".M", "??", "UU"…).</summary>
    public string Code { get; set; } = "";

    public bool Staged { get; set; }
    public int? Insertions { get; set; }
    public int? Deletions { get; set; }
    public bool Binary { get; set; }
}

/// <summary>Deterministic Git working-tree status (parsed from porcelain v2 and numstat output, never from prose).</summary>
public sealed class GitStatusReport
{
    public string Repository { get; set; } = "";

    /// <summary>Git root relative to the repository root ("." when they coincide, or ".." segments when the repository is a sub-folder).</summary>
    public string GitRoot { get; set; } = ".";

    public string? Branch { get; set; }
    public bool Detached { get; set; }
    public string? Head { get; set; }
    public string? HeadShort => Head is { Length: >= 7 } h ? h[..7] : Head;
    public bool InitialCommit { get; set; }
    public string? Upstream { get; set; }
    public int Ahead { get; set; }
    public int Behind { get; set; }
    public List<GitFileChange> Files { get; set; } = [];
    public int Modified => Files.Count(f => f.Kind is "modified" or "typechange");
    public int Added => Files.Count(f => f.Kind is "added" or "copied");
    public int Deleted => Files.Count(f => f.Kind == "deleted");
    public int Renamed => Files.Count(f => f.Kind == "renamed");
    public int Untracked => Files.Count(f => f.Kind == "untracked");
    public int Conflicted => Files.Count(f => f.Kind == "conflicted");
    public int Insertions => Files.Sum(f => f.Insertions ?? 0);
    public int Deletions => Files.Sum(f => f.Deletions ?? 0);
    public int Changed => Files.Count;
    public bool Clean => Files.Count == 0;

    /// <summary>SHA-256 over HEAD and every changed path's content: the identity of the exact tree that was (or will be) verified.</summary>
    public string Fingerprint { get; set; } = "";

    /// <summary>Content hash per changed path ("deleted" for removed files) — what the fingerprint was computed from.</summary>
    public Dictionary<string, string> FileHashes { get; set; } = new(StringComparer.Ordinal);

    public string Summary()
    {
        var sb = new StringBuilder();
        sb.Append(CultureInfo.InvariantCulture, $"{Branch ?? "(detached)"}");
        if (Head is not null)
        {
            sb.Append(CultureInfo.InvariantCulture, $" @ {HeadShort}");
        }
        if (Upstream is not null)
        {
            sb.Append(CultureInfo.InvariantCulture, $" → {Upstream} (ahead {Ahead}, behind {Behind})");
        }
        sb.Append(Clean ? " · clean" : $" · {Changed} changed (+{Insertions} −{Deletions})");
        return sb.ToString();
    }
}

public sealed record GitCommitInfo(string Hash, string ShortHash, string Author, string Date, string Subject);

/// <summary>A changed path between two refs.</summary>
public sealed class GitRefChange
{
    public string Path { get; set; } = "";
    public string? OriginalPath { get; set; }

    /// <summary>added | modified | deleted | renamed | copied | typechange</summary>
    public string Kind { get; set; } = "modified";

    public int? Insertions { get; set; }
    public int? Deletions { get; set; }
    public bool Binary { get; set; }
}

/// <summary>Pure parsers for Git's machine-readable output formats.</summary>
public static class GitParsers
{
    /// <summary>Parses <c>git status --porcelain=v2 --branch -z --untracked-files=all</c>.</summary>
    public static GitStatusReport ParseStatusV2(string output)
    {
        var report = new GitStatusReport();
        var tokens = output.Split('\0');
        for (var i = 0; i < tokens.Length; i++)
        {
            var t = tokens[i];
            if (t.Length == 0)
            {
                continue;
            }
            if (t.StartsWith("# ", StringComparison.Ordinal))
            {
                var header = t[2..];
                if (header.StartsWith("branch.oid ", StringComparison.Ordinal))
                {
                    var oid = header[11..];
                    report.InitialCommit = oid == "(initial)";
                    report.Head = report.InitialCommit ? null : oid;
                }
                else if (header.StartsWith("branch.head ", StringComparison.Ordinal))
                {
                    var head = header[12..];
                    report.Detached = head == "(detached)";
                    report.Branch = report.Detached ? null : head;
                }
                else if (header.StartsWith("branch.upstream ", StringComparison.Ordinal))
                {
                    report.Upstream = header[16..];
                }
                else if (header.StartsWith("branch.ab ", StringComparison.Ordinal))
                {
                    var parts = header[10..].Split(' ');
                    report.Ahead = parts.Length > 0 ? Math.Abs(int.Parse(parts[0], CultureInfo.InvariantCulture)) : 0;
                    report.Behind = parts.Length > 1 ? Math.Abs(int.Parse(parts[1], CultureInfo.InvariantCulture)) : 0;
                }
                continue;
            }
            switch (t[0])
            {
                case '1':
                {
                    // 1 XY sub mH mI mW hH hI path
                    var f = t.Split(' ', 9);
                    report.Files.Add(Change(f[1], f[8], null));
                    break;
                }
                case '2':
                {
                    // 2 XY sub mH mI mW hH hI Xscore path \0 origPath
                    var f = t.Split(' ', 10);
                    var original = i + 1 < tokens.Length ? tokens[++i] : null;
                    report.Files.Add(Change(f[1], f[9], original));
                    break;
                }
                case 'u':
                {
                    // u XY sub m1 m2 m3 mW h1 h2 h3 path
                    var f = t.Split(' ', 11);
                    report.Files.Add(new GitFileChange { Path = f[10], Code = f[1], Kind = "conflicted" });
                    break;
                }
                case '?':
                    report.Files.Add(new GitFileChange { Path = t[2..], Code = "??", Kind = "untracked" });
                    break;
            }
        }
        return report;
    }

    private static GitFileChange Change(string xy, string path, string? original)
    {
        var x = xy[0];
        var y = xy.Length > 1 ? xy[1] : '.';
        var kind = x == 'R' || y == 'R' ? "renamed"
            : x == 'C' || y == 'C' ? "copied"
            : x == 'D' || y == 'D' ? "deleted"
            : x == 'A' ? "added"
            : x == 'T' || y == 'T' ? "typechange"
            : "modified";
        return new GitFileChange { Path = path, OriginalPath = original, Code = xy, Kind = kind, Staged = x != '.' };
    }

    /// <summary>Parses <c>git diff --numstat -z</c> (with or without rename detection) into path → (insertions, deletions, binary).</summary>
    public static Dictionary<string, (int? Insertions, int? Deletions, bool Binary)> ParseNumstatZ(string output)
    {
        var result = new Dictionary<string, (int?, int?, bool)>(StringComparer.Ordinal);
        var tokens = output.Split('\0');
        for (var i = 0; i < tokens.Length; i++)
        {
            var t = tokens[i].TrimStart('\n', '\r');
            if (t.Length == 0)
            {
                continue;
            }
            var f = t.Split('\t', 3);
            if (f.Length < 3)
            {
                continue;
            }
            var binary = f[0] == "-" && f[1] == "-";
            int? ins = binary ? null : int.Parse(f[0], CultureInfo.InvariantCulture);
            int? del = binary ? null : int.Parse(f[1], CultureInfo.InvariantCulture);
            var path = f[2];
            if (path.Length == 0 && i + 2 < tokens.Length)
            {
                i++; // original path
                path = tokens[++i];
            }
            result[path] = (ins, del, binary);
        }
        return result;
    }

    /// <summary>Parses <c>git diff --name-status -z -M</c>.</summary>
    public static List<GitRefChange> ParseNameStatusZ(string output)
    {
        var list = new List<GitRefChange>();
        var tokens = output.Split('\0');
        for (var i = 0; i < tokens.Length; i++)
        {
            var status = tokens[i].Trim('\n', '\r');
            if (status.Length == 0 || i + 1 >= tokens.Length)
            {
                continue;
            }
            var code = status[0];
            if (code is 'R' or 'C')
            {
                var from = tokens[++i];
                var to = i + 1 < tokens.Length ? tokens[++i] : from;
                list.Add(new GitRefChange { Path = to, OriginalPath = from, Kind = code == 'R' ? "renamed" : "copied" });
            }
            else
            {
                list.Add(new GitRefChange
                {
                    Path = tokens[++i],
                    Kind = code switch { 'A' => "added", 'D' => "deleted", 'T' => "typechange", _ => "modified" },
                });
            }
        }
        return list;
    }

    /// <summary>Parses <c>git log --format=%H%x1f%h%x1f%an%x1f%ad%x1f%s%x1e --date=short</c>.</summary>
    public static List<GitCommitInfo> ParseLog(string output)
        => output.Split('\x1e', StringSplitOptions.RemoveEmptyEntries)
            .Select(r => r.Trim('\n', '\r').Split('\x1f'))
            .Where(f => f.Length >= 5)
            .Select(f => new GitCommitInfo(f[0], f[1], f[2], f[3], f[4]))
            .ToList();

    /// <summary>
    /// A ref argument is accepted only if it cannot be read as an option and uses ref characters
    /// (branch, tag, remote branch, commit, HEAD~n, HEAD^, @{u}).
    /// </summary>
    public static bool IsSafeRef(string? value)
        => value is { Length: > 0 and <= 200 } v && v[0] != '-' && !v.Contains("..", StringComparison.Ordinal)
           && v.All(c => char.IsLetterOrDigit(c) || c is '.' or '_' or '/' or '-' or '~' or '^' or '@' or '{' or '}');

    /// <summary>Removes credentials from a remote URL (https://user:token@host/… → https://host/…).</summary>
    public static string SanitizeRemoteUrl(string url)
    {
        if (Uri.TryCreate(url, UriKind.Absolute, out var uri) && !string.IsNullOrEmpty(uri.UserInfo))
        {
            return new UriBuilder(uri) { UserName = "", Password = "" }.Uri.ToString();
        }
        return url;
    }
}
