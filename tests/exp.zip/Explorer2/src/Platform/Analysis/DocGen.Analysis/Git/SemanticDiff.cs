using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using DocGen.Analysis.CSharp;
using DocGen.Analysis.Indexing;

namespace DocGen.Analysis.Git;

/// <summary>A declaration-level change between two versions of a C# file.</summary>
public sealed record SymbolChange(
    string Change,
    string SymbolKind,
    string FullName,
    string File,
    bool Public,
    bool IsTest,
    string? Before = null,
    string? After = null);

public sealed record ConfigChange(string File, string Key, string Change, string? Before, string? After);

public sealed record DependencyChange(string File, string Kind, string Name, string Change, string? Before, string? After)
{
    public bool MajorBump => Change == "version" && Major(Before) is { } b && Major(After) is { } a && a != b;

    private static int? Major(string? version)
        => version is not null && int.TryParse(version.TrimStart('[', '(').Split('.', ',')[0], out var m) ? m : null;
}

public sealed record EndpointChange(string Change, string Verb, string Route, string Handler, string File);

/// <summary>
/// Deterministic, declaration-level comparison of two file versions using the same C# parser as the code index
/// (types, members, signatures, body hashes, endpoints), plus configuration-key and package-reference comparison.
/// </summary>
public static partial class SemanticDiff
{
    private static readonly string[] TestAttributes = ["TestMethod", "DataTestMethod", "Fact", "Theory", "Test", "TestCase"];

    public static List<SymbolChange> CompareCSharp(string path, string? before, string? after)
    {
        var old = Declarations(path, before);
        var @new = Declarations(path, after);
        var changes = new List<SymbolChange>();
        foreach (var (key, n) in @new)
        {
            if (old.TryGetValue(key, out var o))
            {
                if (o.BodyHash != n.BodyHash)
                {
                    changes.Add(new SymbolChange("body", n.Symbol.Kind, n.Symbol.FullName, path, n.Public, n.IsTest, o.Symbol.Signature, n.Symbol.Signature));
                }
            }
        }
        var removed = old.Where(p => !@new.ContainsKey(p.Key)).Select(p => p.Value).ToList();
        var added = @new.Where(p => !old.ContainsKey(p.Key)).Select(p => p.Value).ToList();

        // Same name and kind on both sides, different parameters/return: a signature change, not add + remove.
        foreach (var r in removed.ToList())
        {
            var match = added.Where(a => a.Symbol.FullName == r.Symbol.FullName && a.Symbol.Kind == r.Symbol.Kind).ToList();
            if (match.Count == 1 && removed.Count(x => x.Symbol.FullName == r.Symbol.FullName && x.Symbol.Kind == r.Symbol.Kind) == 1)
            {
                changes.Add(new SymbolChange("signature", r.Symbol.Kind, r.Symbol.FullName, path, r.Public || match[0].Public, r.IsTest || match[0].IsTest, r.Symbol.Signature, match[0].Symbol.Signature));
                removed.Remove(r);
                added.Remove(match[0]);
            }
        }
        changes.AddRange(added.Select(a => new SymbolChange("added", a.Symbol.Kind, a.Symbol.FullName, path, a.Public, a.IsTest, null, a.Symbol.Signature)));
        changes.AddRange(removed.Select(r => new SymbolChange("removed", r.Symbol.Kind, r.Symbol.FullName, path, r.Public, r.IsTest, r.Symbol.Signature, null)));
        return changes;
    }

    public static List<EndpointChange> CompareEndpoints(string path, string? before, string? after)
    {
        static List<EndpointRecord> Of(string path, string? text) => text is null ? [] : Parse(path, text)?.Endpoints ?? [];
        static string Key(EndpointRecord e) => e.Verb.ToUpperInvariant() + " " + e.Route;
        var old = Of(path, before).GroupBy(Key).ToDictionary(g => g.Key, g => g.First());
        var @new = Of(path, after).GroupBy(Key).ToDictionary(g => g.Key, g => g.First());
        var list = new List<EndpointChange>();
        list.AddRange(@new.Where(p => !old.ContainsKey(p.Key)).Select(p => new EndpointChange("added", p.Value.Verb, p.Value.Route, p.Value.Handler, path)));
        list.AddRange(old.Where(p => !@new.ContainsKey(p.Key)).Select(p => new EndpointChange("removed", p.Value.Verb, p.Value.Route, p.Value.Handler, path)));
        return list;
    }

    private sealed record Declaration(SymbolRecord Symbol, string BodyHash, bool Public, bool IsTest);

    private static FileIndex? Parse(string path, string text)
    {
        try
        {
            return CSharpParser.Parse(text, path);
        }
        catch (Exception ex) when (ex is not OperationCanceledException and not OutOfMemoryException)
        {
            return null;
        }
    }

    private static Dictionary<string, Declaration> Declarations(string path, string? text)
    {
        var result = new Dictionary<string, Declaration>(StringComparer.Ordinal);
        if (string.IsNullOrEmpty(text) || Parse(path, text) is not { } file)
        {
            return result;
        }
        var lines = text.Split('\n');
        foreach (var s in file.Symbols)
        {
            var key = s.Kind + " " + s.FullName + "(" + string.Join(",", s.ParameterTypes) + ")";
            var from = Math.Clamp(s.StartLine - 1, 0, lines.Length);
            var to = Math.Clamp(s.EndLine, from, lines.Length);
            var body = Whitespace().Replace(string.Join("\n", lines[from..to]), " ");
            var hash = Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(body)))[..16];
            var isPublic = s.Modifiers.Contains("public") || s.Modifiers.Contains("protected");
            var isTest = s.Attributes.Any(a => TestAttributes.Contains(a.Split('(')[0].Replace("Attribute", "", StringComparison.Ordinal)));
            result.TryAdd(key, new Declaration(s, hash, isPublic, isTest));
        }
        return result;
    }

    /// <summary>Flattened JSON configuration keys (A:B:C, arrays as A:0). Values of secret-looking keys are masked.</summary>
    public static List<ConfigChange> CompareJsonConfig(string path, string? before, string? after)
    {
        var old = Flatten(before);
        var @new = Flatten(after);
        var list = new List<ConfigChange>();
        foreach (var (key, value) in @new)
        {
            if (!old.TryGetValue(key, out var previous))
            {
                list.Add(new ConfigChange(path, key, "added", null, Mask(key, value)));
            }
            else if (previous != value)
            {
                list.Add(new ConfigChange(path, key, "changed", Mask(key, previous), Mask(key, value)));
            }
        }
        list.AddRange(old.Where(p => !@new.ContainsKey(p.Key)).Select(p => new ConfigChange(path, p.Key, "removed", Mask(p.Key, p.Value), null)));
        return list;
    }

    public static string Mask(string key, string? value)
        => value is null ? "" : IsSecretKey(key) || SecretScanner.ContainsSecret(value) ? "••••" : value.Length > 80 ? value[..80] + "…" : value;

    private static readonly string[] SecretKeyMarkers = ["SECRET", "TOKEN", "PASSWORD", "PASSWD", "PWD", "CONNECTIONSTRING", "CREDENTIAL", "PRIVATE", "APIKEY", "API_KEY", "ACCESSKEY", "SIGNINGKEY", "CERTIFICATEPASSWORD"];

    /// <summary>Configuration keys whose values are credentials (ConnectionStrings:*, *:ApiKey, *:ClientSecret, *Password, *Token, *:Key…).</summary>
    public static bool IsSecretKey(string key)
    {
        var segments = key.Split(':');
        return segments[0].Equals("ConnectionStrings", StringComparison.OrdinalIgnoreCase)
               || segments.Any(s => SecretKeyMarkers.Any(m => s.ToUpperInvariant().Contains(m, StringComparison.Ordinal))
                                    || s.Equals("Key", StringComparison.OrdinalIgnoreCase) || s.EndsWith("Key", StringComparison.Ordinal) && s.Length > 3 && !s.EndsWith("PublicKey", StringComparison.Ordinal));
    }

    public static Dictionary<string, string> Flatten(string? json)
    {
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (string.IsNullOrWhiteSpace(json))
        {
            return result;
        }
        try
        {
            using var doc = JsonDocument.Parse(json, new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
            Walk(doc.RootElement, "", result);
        }
        catch (JsonException)
        {
        }
        return result;
    }

    private static void Walk(JsonElement e, string prefix, Dictionary<string, string> into)
    {
        switch (e.ValueKind)
        {
            case JsonValueKind.Object:
                foreach (var p in e.EnumerateObject())
                {
                    Walk(p.Value, prefix.Length == 0 ? p.Name : prefix + ":" + p.Name, into);
                }
                break;
            case JsonValueKind.Array:
                var i = 0;
                foreach (var item in e.EnumerateArray())
                {
                    Walk(item, prefix + ":" + i++, into);
                }
                if (i == 0)
                {
                    into[prefix] = "[]";
                }
                break;
            default:
                into[prefix] = e.ToString();
                break;
        }
    }

    /// <summary>PackageReference / PackageVersion / ProjectReference / FrameworkReference changes in MSBuild files.</summary>
    public static List<DependencyChange> CompareMsBuild(string path, string? before, string? after)
    {
        var old = References(before);
        var @new = References(after);
        var list = new List<DependencyChange>();
        foreach (var (key, (kind, name, version)) in @new)
        {
            if (!old.TryGetValue(key, out var o))
            {
                list.Add(new DependencyChange(path, kind, name, "added", null, version));
            }
            else if (o.Version != version)
            {
                list.Add(new DependencyChange(path, kind, name, "version", o.Version, version));
            }
        }
        list.AddRange(old.Where(p => !@new.ContainsKey(p.Key)).Select(p => new DependencyChange(path, p.Value.Kind, p.Value.Name, "removed", p.Value.Version, null)));
        return list;
    }

    private static Dictionary<string, (string Kind, string Name, string? Version)> References(string? xml)
    {
        var result = new Dictionary<string, (string, string, string?)>(StringComparer.OrdinalIgnoreCase);
        if (string.IsNullOrWhiteSpace(xml))
        {
            return result;
        }
        try
        {
            var doc = XDocument.Parse(xml);
            foreach (var e in doc.Descendants().Where(e => e.Name.LocalName is "PackageReference" or "PackageVersion" or "ProjectReference" or "FrameworkReference"))
            {
                var name = (string?)e.Attribute("Include") ?? (string?)e.Attribute("Update");
                if (name is null)
                {
                    continue;
                }
                var version = (string?)e.Attribute("Version") ?? e.Elements().FirstOrDefault(x => x.Name.LocalName == "Version")?.Value;
                result[e.Name.LocalName + "|" + name] = (e.Name.LocalName, name, version);
            }
        }
        catch (System.Xml.XmlException)
        {
        }
        return result;
    }

    [GeneratedRegex(@"\s+")]
    private static partial Regex Whitespace();
}

/// <summary>Detects credential material in file names and text (used by packaging, commit safety and memory).</summary>
public static partial class SecretScanner
{
    private static readonly string[] SecretFileNames =
    [
        ".env", "secrets.json", "credentials", "credentials.json", "id_rsa", "id_dsa", "id_ecdsa", "id_ed25519", ".npmrc", ".pypirc", ".netrc", "_netrc",
        ".git-credentials", "appsettings.secrets.json", "usersecrets.json",
    ];

    private static readonly string[] SecretExtensions = [".pfx", ".p12", ".pem", ".key", ".jks", ".keystore", ".kdbx", ".ppk", ".asc", ".gpg"];

    /// <summary>File names that hold credentials by convention (never packaged, never committed without review).</summary>
    public static bool IsSecretFileName(string path)
    {
        var name = Path.GetFileName(path.Replace('\\', '/'));
        var lower = name.ToLowerInvariant();
        return SecretFileNames.Contains(lower)
               || lower.StartsWith(".env.", StringComparison.Ordinal) && !lower.EndsWith(".example", StringComparison.Ordinal) && !lower.EndsWith(".sample", StringComparison.Ordinal)
               || SecretExtensions.Contains(Path.GetExtension(lower))
               || lower.StartsWith("id_", StringComparison.Ordinal) && !lower.Contains('.', StringComparison.Ordinal)
               || lower.EndsWith(".publishsettings", StringComparison.Ordinal)
               || lower.EndsWith(".pubxml.user", StringComparison.Ordinal);
    }

    /// <summary>High-confidence credential patterns (private keys, provider key formats, credentialed URLs, password assignments).</summary>
    public static bool ContainsSecret(string text) => Find(text).Count > 0;

    public static List<string> Find(string text, int max = 5)
    {
        var found = new List<string>();
        foreach (Match m in Patterns().Matches(text))
        {
            var kind = m.Groups["pk"].Success ? "private key" : m.Groups["aws"].Success ? "AWS access key" : m.Groups["gh"].Success ? "GitHub token"
                : m.Groups["sk"].Success ? "API key (sk-…)" : m.Groups["google"].Success ? "Google API key" : m.Groups["slack"].Success ? "Slack token"
                : m.Groups["jwt"].Success ? "JWT" : m.Groups["url"].Success ? "credentials in URL" : m.Groups["gsk"].Success ? "API key (gsk_…)"
                : m.Groups["atl"].Success ? "Atlassian token" : "password assignment";
            if (!found.Contains(kind))
            {
                found.Add(kind);
            }
            if (found.Count >= max)
            {
                break;
            }
        }
        return found;
    }

    [GeneratedRegex(
        @"(?<pk>-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY-----)" +
        @"|(?<aws>\bAKIA[0-9A-Z]{16}\b)" +
        @"|(?<gh>\bgh[pousr]_[A-Za-z0-9]{36,}\b)" +
        @"|(?<sk>\bsk-(?:proj-|ant-)?[A-Za-z0-9_\-]{20,}\b)" +
        @"|(?<gsk>\bgsk_[A-Za-z0-9]{20,}\b)" +
        @"|(?<google>\bAIza[0-9A-Za-z_\-]{35}\b)" +
        @"|(?<atl>\bATATT[0-9A-Za-z_\-=]{20,}\b)" +
        @"|(?<slack>\bxox[baprs]-[0-9A-Za-z\-]{10,}\b)" +
        @"|(?<jwt>\beyJ[A-Za-z0-9_\-]{10,}\.eyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,})" +
        @"|(?<url>\b[a-z][a-z0-9+.\-]*://[^\s:/@""'{}<>]+:(?!(?:token|password|passwd|pass|secret|pwd|x+|\*+|\.\.\.|…)@)[^\s@/""'{}<>]{3,}@[^\s""']+)" +
        @"|(?<pwd>(?i:\b(?:password|passwd|pwd|secret|api[_\-]?key|access[_\-]?token|client[_\-]?secret)\b)[""']?\s*[:=]\s*[""'](?![\s""']*$)(?!\$\{|\{\{|<|%|your|changeme|example|xxx|\*\*\*)[^""'\s]{6,}[""'])",
        RegexOptions.CultureInvariant)]
    private static partial Regex Patterns();
}
