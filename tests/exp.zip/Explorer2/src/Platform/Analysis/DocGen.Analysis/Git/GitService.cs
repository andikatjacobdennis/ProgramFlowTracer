using System.Security.Cryptography;
using System.Text;
using DocGen.Analysis.Commands;
using DocGen.Analysis.Repositories;
using DocGen.Analysis.Tools;
using DocGen.Core.Exceptions;

namespace DocGen.Analysis.Git;

/// <summary>Who runs Git where: the user, an accessible repository and the Git working tree that contains it.</summary>
public sealed record GitContext(string UserId, RepositoryHandle Repo, string GitRoot, string? RunId = null, string? ConversationId = null)
{
    /// <summary>Repository-relative path of a Git path (Git paths are relative to the Git root).</summary>
    public string DisplayPath(string gitPath) => Path.GetRelativePath(Repo.Root, Path.Combine(GitRoot, gitPath)).Replace('\\', '/');
}

public sealed record GitOutput(CommandRecord Record, string Stdout)
{
    public bool Ok => Record.Status == CommandStatus.Succeeded;

    public string Error => string.Join(" ", Record.Tail.TakeLast(4)).Trim() is { Length: > 0 } t ? t : $"{Record.Status} (exit {Record.ExitCode})";
}

/// <summary>
/// Runs Git through <see cref="CommandRunner"/> (allow-listed executable, owned, logged, timed out, redacted) and
/// turns its machine-readable output into structured reports. Never prompts for credentials (GIT_TERMINAL_PROMPT=0),
/// never pages, never checks out anything merely to inspect it.
/// </summary>
public sealed class GitService(AnalysisServices services)
{
    public const int MaxHashedFileBytes = 64 * 1024 * 1024;

    public async Task<GitContext> ContextAsync(string userId, string? repository, string? runId, string? conversationId, CancellationToken ct)
    {
        var repo = await services.Repositories.ResolveAsync(userId, repository, ct);
        if (!services.Executables.IsAllowed("git"))
        {
            throw new ValidationException("git is not allow-listed (DocGen:Execution:Executables).");
        }
        var root = FindGitRoot(repo) ?? throw new ValidationException($"Repository '{repo.Name}' is not inside a Git working tree.");
        return new GitContext(userId, repo, root, runId, conversationId);
    }

    /// <summary>
    /// The Git working tree of a repository. For a user's workspace only a tree rooted inside the workspace counts:
    /// walking up would reach whatever repository happens to contain the data directory (e.g. DocGen's own source).
    /// Administrator-registered folders may be a subfolder of a larger working tree.
    /// </summary>
    public static string? FindGitRoot(RepositoryHandle repo)
    {
        var root = FindGitRoot(repo.Root);
        if (root is null || repo.Source != "workspace")
        {
            return root;
        }
        var full = Path.GetFullPath(repo.Root).TrimEnd(Path.DirectorySeparatorChar);
        return string.Equals(Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar), full, StringComparison.OrdinalIgnoreCase)
               || Path.GetFullPath(root).StartsWith(full + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)
            ? root
            : null;
    }

    public static string? FindGitRoot(string start)
    {
        for (var dir = new DirectoryInfo(start); dir is not null; dir = dir.Parent)
        {
            if (Directory.Exists(Path.Combine(dir.FullName, ".git")) || File.Exists(Path.Combine(dir.FullName, ".git")))
            {
                return dir.FullName;
            }
        }
        return null;
    }

    public async Task<GitOutput> RunAsync(GitContext ctx, IReadOnlyList<string> arguments, string description, CancellationToken ct,
        string risk = "ReadOnly", int timeoutSeconds = 60, int maxBytes = 32 * 1024 * 1024)
    {
        var git = services.Executables.Resolve("git");
        var args = SafeArguments(arguments, disableHooks: ctx.Repo.Source == "workspace");
        var (record, bytes) = await services.Commands.RunCaptureAsync(ctx.UserId, new ProcessLaunch
        {
            Kind = CommandKinds.Process, ExecutableName = git.Name, ExecutablePath = git.Path, Arguments = args, WorkingDirectory = ctx.GitRoot,
            DisplayWorkingDirectory = Path.GetRelativePath(ctx.Repo.Root, ctx.GitRoot).Replace('\\', '/'), Repository = ctx.Repo.Name,
            DisplayCommand = "git " + string.Join(' ', arguments.Select(a => a.Contains(' ', StringComparison.Ordinal) ? $"\"{a}\"" : a)),
            Description = description, TimeoutSeconds = timeoutSeconds, RunId = ctx.RunId, ConversationId = ctx.ConversationId, Risk = risk,
            Environment = new Dictionary<string, string> { ["GIT_TERMINAL_PROMPT"] = "0", ["GIT_OPTIONAL_LOCKS"] = risk == "ReadOnly" ? "0" : "1" },
        }, maxBytes, ct);
        return new GitOutput(record, Encoding.UTF8.GetString(bytes));
    }

    /// <summary>
    /// Arguments for every Git invocation made by DocGen. Repository configuration can name programs for Git to run
    /// (filesystem monitor, external diff, text conversion, pager, custom transports); DocGen turns those off so
    /// that reading status or diffs never executes anything the repository asks for. Hooks are also disabled for a
    /// user's workspace repository, whose contents the user controls; administrator-registered repositories keep
    /// their hooks for explicitly authorized commits and pushes.
    /// </summary>
    public static List<string> SafeArguments(IReadOnlyList<string> arguments, bool disableHooks)
    {
        var args = new List<string>
        {
            "--no-pager",
            "-c", "core.quotepath=false", "-c", "color.ui=false", "-c", "core.autocrlf=false",
            "-c", "core.fsmonitor=false", "-c", "core.pager=cat", "-c", "diff.external=", "-c", "protocol.ext.allow=never",
        };
        if (disableHooks)
        {
            args.AddRange(["-c", "core.hooksPath=" + EmptyHooksDirectory.Value]);
        }
        if (arguments.Count > 0)
        {
            args.Add(arguments[0]);
            if (arguments[0] is "diff" or "show" or "log")
            {
                args.AddRange(["--no-ext-diff", "--no-textconv"]);
            }
            args.AddRange(arguments.Skip(1));
        }
        return args;
    }

    private static readonly Lazy<string> EmptyHooksDirectory = new(() =>
    {
        var dir = Path.Combine(Path.GetTempPath(), "docgen-git-no-hooks");
        Directory.CreateDirectory(dir);
        return dir.Replace('\\', '/');
    });

    private async Task<string> RequireAsync(GitContext ctx, IReadOnlyList<string> arguments, string description, CancellationToken ct)
    {
        var output = await RunAsync(ctx, arguments, description, ct);
        return output.Ok ? output.Stdout : throw new ValidationException($"git {arguments[0]} failed: {output.Error}");
    }

    /// <summary>Branch, HEAD, upstream, ahead/behind, changed files with +/− counts, and the tree fingerprint.</summary>
    public async Task<GitStatusReport> StatusAsync(GitContext ctx, CancellationToken ct)
    {
        var raw = await RequireAsync(ctx, ["status", "--porcelain=v2", "--branch", "-z", "--untracked-files=all"], "Git status", ct);
        var report = GitParsers.ParseStatusV2(raw);
        report.Repository = ctx.Repo.Name;
        report.GitRoot = Path.GetRelativePath(ctx.Repo.Root, ctx.GitRoot).Replace('\\', '/');

        if (report.Files.Any(f => f.Kind != "untracked"))
        {
            var against = report.InitialCommit ? EmptyTree : "HEAD";
            var numstat = await RunAsync(ctx, ["diff", against, "--numstat", "-z", "-M"], "Git line counts", ct);
            if (numstat.Ok)
            {
                var counts = GitParsers.ParseNumstatZ(numstat.Stdout);
                foreach (var f in report.Files)
                {
                    if (counts.TryGetValue(f.Path, out var c))
                    {
                        (f.Insertions, f.Deletions, f.Binary) = c;
                    }
                }
            }
        }
        foreach (var f in report.Files.Where(f => f.Kind == "untracked"))
        {
            var full = Path.Combine(ctx.GitRoot, f.Path);
            if (File.Exists(full) && new FileInfo(full).Length <= 8 * 1024 * 1024)
            {
                var bytes = await File.ReadAllBytesAsync(full, ct);
                f.Binary = bytes.AsSpan(0, Math.Min(bytes.Length, 8000)).IndexOf((byte)0) >= 0;
                f.Insertions = f.Binary ? null : CountLines(bytes);
                f.Deletions = f.Binary ? null : 0;
            }
        }
        (report.Fingerprint, report.FileHashes) = await FingerprintAsync(ctx, report, ct);
        return report;
    }

    /// <summary>SHA-256 of the empty tree: the base for a repository without commits.</summary>
    public const string EmptyTree = "4b825dc642cb6eb9a060e54bf8d69288fbee4904";

    public static int CountLines(ReadOnlySpan<byte> bytes)
    {
        var n = 0;
        foreach (var b in bytes)
        {
            if (b == (byte)'\n')
            {
                n++;
            }
        }
        return bytes.Length > 0 && bytes[^1] != (byte)'\n' ? n + 1 : n;
    }

    /// <summary>Tree identity: HEAD plus each changed path with a hash of its current content.</summary>
    public static async Task<(string Fingerprint, Dictionary<string, string> Hashes)> FingerprintAsync(GitContext ctx, GitStatusReport status, CancellationToken ct)
    {
        var hashes = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var f in status.Files.OrderBy(f => f.Path, StringComparer.Ordinal))
        {
            var full = Path.Combine(ctx.GitRoot, f.Path);
            string hash;
            if (!File.Exists(full))
            {
                hash = Directory.Exists(full) ? "directory" : "deleted";
            }
            else if (new FileInfo(full).Length > MaxHashedFileBytes)
            {
                var info = new FileInfo(full);
                hash = $"large:{info.Length}:{info.LastWriteTimeUtc.Ticks}";
            }
            else
            {
                await using var stream = File.OpenRead(full);
                hash = Convert.ToHexStringLower(await SHA256.HashDataAsync(stream, ct));
            }
            hashes[f.Path] = hash;
        }
        var sb = new StringBuilder("head:" + (status.Head ?? "(initial)") + "\n");
        foreach (var (path, hash) in hashes)
        {
            sb.Append(path).Append('\t').Append(hash).Append('\n');
        }
        return (Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(sb.ToString()))), hashes);
    }

    /// <summary>Unified diff of the working tree against HEAD (bounded), optionally for one path.</summary>
    public async Task<string> DiffAsync(GitContext ctx, string? path, int maxChars, CancellationToken ct)
    {
        var args = new List<string> { "diff", "HEAD", "-M", "--stat=160", "--patch" };
        if (path is { Length: > 0 })
        {
            args.Add("--");
            args.Add(path);
        }
        var output = await RunAsync(ctx, args, "Git diff", ct, maxBytes: maxChars * 4);
        if (!output.Ok)
        {
            // No commits yet: nothing to diff against.
            return "(no committed HEAD to diff against)";
        }
        return output.Stdout.Length > maxChars ? output.Stdout[..maxChars] + $"\n… (diff truncated at {maxChars:N0} characters)" : output.Stdout;
    }

    /// <summary>Verifies a ref names a commit (no checkout); returns the full commit id.</summary>
    public async Task<string> ResolveCommitAsync(GitContext ctx, string reference, CancellationToken ct)
    {
        if (!GitParsers.IsSafeRef(reference))
        {
            throw new ValidationException($"'{reference}' is not a valid ref (branch, tag, commit or HEAD~n).");
        }
        var output = await RunAsync(ctx, ["rev-parse", "--verify", "--quiet", "--end-of-options", reference + "^{commit}"], "Resolve ref", ct);
        return output.Ok && output.Stdout.Trim() is { Length: 40 or 64 } id ? id : throw new ValidationException($"'{reference}' does not name a commit in this repository.");
    }

    /// <summary>File content at a commit (null when absent or larger than the limit).</summary>
    public async Task<string?> ShowAsync(GitContext ctx, string commit, string gitPath, int maxBytes, CancellationToken ct)
    {
        var output = await RunAsync(ctx, ["show", $"{commit}:{gitPath}"], "Read file at ref", ct, maxBytes: maxBytes);
        return output.Ok && !output.Record.OutputTruncated ? output.Stdout : null;
    }

    public async Task<List<(string Name, string Url)>> RemotesAsync(GitContext ctx, CancellationToken ct)
    {
        var output = await RunAsync(ctx, ["remote", "-v"], "List remotes", ct);
        return output.Stdout.Split('\n', StringSplitOptions.RemoveEmptyEntries)
            .Select(l => l.Split('\t', ' '))
            .Where(p => p.Length >= 2)
            .Select(p => (p[0], GitParsers.SanitizeRemoteUrl(p[1])))
            .Distinct()
            .ToList();
    }

    /// <summary>Commits reachable from HEAD that no remote has (or that the upstream lacks).</summary>
    public async Task<List<GitCommitInfo>> UnpushedAsync(GitContext ctx, GitStatusReport status, CancellationToken ct)
    {
        if (status.Head is null)
        {
            return [];
        }
        IReadOnlyList<string> args = status.Upstream is not null
            ? ["log", "--format=%H%x1f%h%x1f%an%x1f%ad%x1f%s%x1e", "--date=short", "-n", "200", "@{u}..HEAD"]
            : ["log", "--format=%H%x1f%h%x1f%an%x1f%ad%x1f%s%x1e", "--date=short", "-n", "200", "HEAD", "--not", "--remotes"];
        var output = await RunAsync(ctx, args, "Commits to push", ct);
        return output.Ok ? GitParsers.ParseLog(output.Stdout) : [];
    }

    /// <summary>
    /// Dirty-tree protection: the local changes that a checkout/switch/rebase/merge/reset/pull could overwrite or discard.
    /// Empty when the tree is clean.
    /// </summary>
    public async Task<List<GitFileChange>> AtRiskChangesAsync(GitContext ctx, CancellationToken ct)
        => (await StatusAsync(ctx, ct)).Files;
}
