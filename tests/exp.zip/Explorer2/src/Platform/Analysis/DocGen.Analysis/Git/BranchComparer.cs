using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using DocGen.Analysis.Indexing;

namespace DocGen.Analysis.Git;

/// <summary>Everything compare_branches found between two refs (merge-base diff, no checkout).</summary>
public sealed class BranchComparison
{
    public string Base { get; set; } = "";
    public string Head { get; set; } = "";
    public string BaseCommit { get; set; } = "";
    public string HeadCommit { get; set; } = "";
    public string MergeBase { get; set; } = "";
    public List<GitCommitInfo> Commits { get; set; } = [];
    public bool CommitsTruncated { get; set; }
    public List<GitRefChange> Files { get; set; } = [];
    public Dictionary<string, List<string>> Projects { get; set; } = new(StringComparer.Ordinal);
    public List<SymbolChange> Symbols { get; set; } = [];
    public List<EndpointChange> Endpoints { get; set; } = [];
    public List<ConfigChange> Config { get; set; } = [];
    public List<DependencyChange> Dependencies { get; set; } = [];
    public List<string> SkippedSemantic { get; set; } = [];
    public string Verification { get; set; } = "Not verified by DocGen.";

    public int Insertions => Files.Sum(f => f.Insertions ?? 0);
    public int Deletions => Files.Sum(f => f.Deletions ?? 0);
}

/// <summary>Builds and renders the branch comparison report (merge-base three-dot semantics, like a pull request).</summary>
public static partial class BranchComparer
{
    public const int MaxSemanticFiles = 200;
    public const int MaxSemanticBytes = 1024 * 1024;

    public static async Task<BranchComparison> CompareAsync(GitService git, GitContext ctx, string baseRef, string headRef, CancellationToken ct)
    {
        var result = new BranchComparison { Base = baseRef, Head = headRef };
        result.BaseCommit = await git.ResolveCommitAsync(ctx, baseRef, ct);
        result.HeadCommit = await git.ResolveCommitAsync(ctx, headRef, ct);
        var mb = await git.RunAsync(ctx, ["merge-base", result.BaseCommit, result.HeadCommit], "Merge base", ct);
        result.MergeBase = mb.Ok && mb.Stdout.Trim().Length >= 40 ? mb.Stdout.Trim() : result.BaseCommit;

        var log = await git.RunAsync(ctx, ["log", "--format=%H%x1f%h%x1f%an%x1f%ad%x1f%s%x1e", "--date=short", "-n", "501", $"{result.BaseCommit}..{result.HeadCommit}"], "Commits between refs", ct);
        result.Commits = GitParsers.ParseLog(log.Stdout);
        if (result.Commits.Count > 500)
        {
            result.Commits = result.Commits.Take(500).ToList();
            result.CommitsTruncated = true;
        }

        var names = await git.RunAsync(ctx, ["diff", "--name-status", "-z", "-M", result.MergeBase, result.HeadCommit], "Changed files", ct);
        result.Files = GitParsers.ParseNameStatusZ(names.Stdout);
        var numstat = await git.RunAsync(ctx, ["diff", "--numstat", "-z", "-M", result.MergeBase, result.HeadCommit], "Line counts", ct);
        var counts = GitParsers.ParseNumstatZ(numstat.Stdout);
        foreach (var f in result.Files)
        {
            if (counts.TryGetValue(f.Path, out var c))
            {
                (f.Insertions, f.Deletions, f.Binary) = c;
            }
        }

        // Projects: nearest *.csproj directory at head (or base, for deleted files).
        var projectDirs = new List<(string Dir, string Name)>();
        foreach (var commit in new[] { result.HeadCommit, result.MergeBase }.Distinct())
        {
            var tree = await git.RunAsync(ctx, ["ls-tree", "-r", "--name-only", "-z", commit], "List project files", ct, maxBytes: 64 * 1024 * 1024);
            foreach (var p in tree.Stdout.Split('\0').Where(p => p.EndsWith(".csproj", StringComparison.OrdinalIgnoreCase)))
            {
                var dir = p.Contains('/', StringComparison.Ordinal) ? p[..p.LastIndexOf('/')] : "";
                if (!projectDirs.Any(d => d.Dir == dir))
                {
                    projectDirs.Add((dir, Path.GetFileNameWithoutExtension(p)));
                }
            }
        }
        foreach (var f in result.Files)
        {
            var owner = projectDirs.Where(d => d.Dir.Length == 0 || f.Path.StartsWith(d.Dir + "/", StringComparison.Ordinal)).OrderByDescending(d => d.Dir.Length).FirstOrDefault();
            var name = owner.Name ?? "(no project)";
            if (!result.Projects.TryGetValue(name, out var list))
            {
                result.Projects[name] = list = [];
            }
            list.Add(f.Path);
        }

        // Semantic comparison of source, configuration and dependency files.
        var semantic = 0;
        foreach (var f in result.Files)
        {
            var ext = Path.GetExtension(f.Path).ToLowerInvariant();
            var name = Path.GetFileName(f.Path);
            var isConfig = ext == ".json" && name.StartsWith("appsettings", StringComparison.OrdinalIgnoreCase);
            var isMsBuild = ext is ".csproj" or ".props" or ".targets";
            if (ext != ".cs" && !isConfig && !isMsBuild || f.Binary)
            {
                continue;
            }
            if (++semantic > MaxSemanticFiles)
            {
                result.SkippedSemantic.Add(f.Path);
                continue;
            }
            var before = f.Kind == "added" ? null : await git.ShowAsync(ctx, result.MergeBase, f.OriginalPath ?? f.Path, MaxSemanticBytes, ct);
            var after = f.Kind == "deleted" ? null : await git.ShowAsync(ctx, result.HeadCommit, f.Path, MaxSemanticBytes, ct);
            if (ext == ".cs")
            {
                result.Symbols.AddRange(SemanticDiff.CompareCSharp(f.Path, before, after));
                result.Endpoints.AddRange(SemanticDiff.CompareEndpoints(f.Path, before, after));
            }
            else if (isConfig)
            {
                result.Config.AddRange(SemanticDiff.CompareJsonConfig(f.Path, before, after));
            }
            else
            {
                result.Dependencies.AddRange(SemanticDiff.CompareMsBuild(f.Path, before, after));
            }
        }
        return result;
    }

    public static bool IsTestPath(string path)
        => TestPath().IsMatch(path.Replace('\\', '/'));

    public static bool IsDataModel(SymbolChange s)
        => DataModelPath().IsMatch(s.File) || DataModelName().IsMatch(s.FullName.Split('.').Reverse().Skip(SymbolKinds.IsType(s.SymbolKind) ? 0 : 1).FirstOrDefault() ?? "");

    public static bool IsRiskPath(string path) => RiskPath().IsMatch(path);

    /// <summary>The report sections requested for branch comparison. Every statement is derived from the collected facts.</summary>
    public static string Render(BranchComparison c, int maxItems = 25)
    {
        var sb = new StringBuilder();
        string Short(string id) => id.Length >= 7 ? id[..7] : id;
        void Section(string title) => sb.Append("\n## ").AppendLine(title);
        void Items<T>(IEnumerable<T> items, Func<T, string> line, string empty = "None detected.")
        {
            var list = items.ToList();
            if (list.Count == 0)
            {
                sb.AppendLine(empty);
                return;
            }
            foreach (var item in list.Take(maxItems))
            {
                sb.Append("- ").AppendLine(line(item));
            }
            if (list.Count > maxItems)
            {
                sb.AppendLine(CultureInfo.InvariantCulture, $"- … and {list.Count - maxItems} more");
            }
        }

        var code = c.Symbols.Where(s => !s.IsTest && !IsTestPath(s.File)).ToList();
        var tests = c.Symbols.Where(s => s.IsTest || IsTestPath(s.File)).ToList();
        var newTypes = code.Where(s => s.Change == "added" && SymbolKinds.IsType(s.SymbolKind)).ToList();
        var newTypeNames = newTypes.Select(t => t.FullName).ToHashSet(StringComparer.Ordinal);
        var newMembers = code.Where(s => s.Change == "added" && !SymbolKinds.IsType(s.SymbolKind) && s.Public && !newTypeNames.Any(t => s.FullName.StartsWith(t + ".", StringComparison.Ordinal))).ToList();
        var behavior = code.Where(s => s.Change == "body" && SymbolKinds.IsCallable(s.SymbolKind)).ToList();
        var removedPublic = code.Where(s => s.Change == "removed" && s.Public).ToList();
        var signature = code.Where(s => s.Change == "signature").ToList();
        var fixes = c.Commits.Where(m => FixWords().IsMatch(m.Subject)).ToList();
        var testFiles = c.Files.Where(f => IsTestPath(f.Path)).ToList();
        var models = code.Where(IsDataModel).Where(s => s.Change != "body" || s.SymbolKind == "property").ToList();
        var breaking = new List<string>();
        breaking.AddRange(removedPublic.Select(s => $"Removed public {s.SymbolKind} `{s.FullName}` ({s.File})"));
        breaking.AddRange(signature.Where(s => s.Public).Select(s => $"Changed public signature `{s.FullName}`: `{s.Before}` → `{s.After}`"));
        breaking.AddRange(c.Endpoints.Where(e => e.Change == "removed").Select(e => $"Removed endpoint {e.Verb} {e.Route} ({e.Handler})"));
        breaking.AddRange(c.Config.Where(k => k.Change == "removed").Select(k => $"Removed configuration key `{k.Key}` ({k.File})"));
        breaking.AddRange(c.Dependencies.Where(d => d.MajorBump).Select(d => $"Major version change {d.Name} {d.Before} → {d.After} ({d.File})"));
        breaking.AddRange(c.Dependencies.Where(d => d.Change == "removed").Select(d => $"Removed {d.Kind} {d.Name} ({d.File})"));

        sb.AppendLine(CultureInfo.InvariantCulture, $"# Branch comparison: {c.Base} ({Short(c.BaseCommit)}) → {c.Head} ({Short(c.HeadCommit)})");
        sb.AppendLine(CultureInfo.InvariantCulture, $"Merge base {Short(c.MergeBase)}. Compared without checkout (git diff merge-base..head, like a pull request).");

        Section("Executive Summary");
        sb.AppendLine(CultureInfo.InvariantCulture, $"{c.Commits.Count}{(c.CommitsTruncated ? "+" : "")} commits, {c.Files.Count} files changed (+{c.Insertions} −{c.Deletions}) across {c.Projects.Count} project(s): " +
            $"{c.Files.Count(f => f.Kind == "added")} added, {c.Files.Count(f => f.Kind == "modified")} modified, {c.Files.Count(f => f.Kind == "deleted")} deleted, {c.Files.Count(f => f.Kind == "renamed")} renamed.");
        sb.AppendLine(CultureInfo.InvariantCulture, $"Declarations: {newTypes.Count} new types, {newMembers.Count} new public members, {behavior.Count} changed method/property bodies, {removedPublic.Count} removed public members, " +
            $"{signature.Count} signature changes; {c.Endpoints.Count} endpoint changes; {c.Config.Count} configuration key changes; {c.Dependencies.Count} dependency changes; {tests.Count(t => t.Change == "added")} tests added.");
        sb.AppendLine(breaking.Count == 0 ? "No potential breaking changes detected by the declaration-level comparison." : $"{breaking.Count} potential breaking change(s) — see below.");
        if (c.SkippedSemantic.Count > 0)
        {
            sb.AppendLine(CultureInfo.InvariantCulture, $"Semantic analysis covered the first {MaxSemanticFiles} source/config files; {c.SkippedSemantic.Count} more were compared by path and line counts only.");
        }

        Section("Commits");
        Items(c.Commits, m => $"{m.ShortHash} {m.Date} {m.Author}: {m.Subject}", "No commits in head that are not in base.");

        Section("Files Changed");
        foreach (var (project, files) in c.Projects.OrderBy(p => p.Key, StringComparer.Ordinal))
        {
            sb.AppendLine().AppendLine(CultureInfo.InvariantCulture, $"**{project}** ({files.Count})");
            Items(c.Files.Where(f => files.Contains(f.Path)), f => $"{f.Kind,-8} {f.Path}{(f.OriginalPath is null ? "" : $" (from {f.OriginalPath})")} {(f.Binary ? "binary" : $"+{f.Insertions} −{f.Deletions}")}");
        }
        if (c.Projects.Count == 0)
        {
            sb.AppendLine("No files changed.");
        }

        Section("Features Added");
        Items(newTypes.Select(t => $"New {t.SymbolKind} `{t.FullName}` ({t.File})")
            .Concat(c.Endpoints.Where(e => e.Change == "added").Select(e => $"New endpoint {e.Verb} {e.Route} → {e.Handler}"))
            .Concat(newMembers.Select(m => $"New public {m.SymbolKind} `{m.FullName}`")), s => s);

        Section("Behavior Changes");
        Items(behavior, s => $"`{s.FullName}` body changed ({s.File})");

        Section("Bug Fixes");
        Items(fixes, m => $"{m.ShortHash}: {m.Subject}", "No commits describe a fix (from commit subjects only; code changes are listed under Behavior Changes).");

        Section("API Changes");
        Items(signature.Select(s => $"`{s.FullName}`: `{s.Before}` → `{s.After}`")
            .Concat(removedPublic.Select(s => $"Removed `{s.FullName}`"))
            .Concat(newMembers.Select(s => $"Added `{s.FullName}`"))
            .Concat(c.Endpoints.Select(e => $"Endpoint {e.Change}: {e.Verb} {e.Route}")), s => s);

        Section("Data Model Changes");
        Items(models, s => $"{s.Change} {s.SymbolKind} `{s.FullName}`{(s.Change == "signature" ? $": `{s.Before}` → `{s.After}`" : "")}");

        Section("Configuration Changes");
        Items(c.Config, k => $"{k.Change} `{k.Key}` in {k.File}{(k.Change == "changed" ? $": {k.Before} → {k.After}" : k.After is { Length: > 0 } a ? $" = {a}" : "")}");

        Section("Dependency Changes");
        Items(c.Dependencies, d => $"{d.Change} {d.Kind} {d.Name}{(d.Change == "version" ? $" {d.Before} → {d.After}" : d.After is not null ? $" {d.After}" : "")} ({d.File})");

        Section("Tests Added/Changed");
        var testLines = tests.Where(t => SymbolKinds.IsCallable(t.SymbolKind)).Select(t => $"{t.Change} `{t.FullName}`").ToList();
        if (testLines.Count == 0)
        {
            testLines = testFiles.Select(f => $"{f.Kind} {f.Path}").ToList();
        }
        Items(testLines, s => s, "No test changes.");

        Section("Potential Breaking Changes");
        Items(breaking, s => s);

        Section("Risk Areas");
        var risks = new List<string>();
        var testedProjects = c.Projects.Where(p => p.Value.Any(IsTestPath)).Select(p => p.Key).ToHashSet(StringComparer.Ordinal);
        foreach (var (project, files) in c.Projects.Where(p => !p.Value.All(IsTestPath)))
        {
            var changedCode = behavior.Count(b => files.Contains(b.File)) + signature.Count(s => files.Contains(s.File));
            if (changedCode > 0 && testedProjects.Count == 0)
            {
                risks.Add($"{project}: {changedCode} changed declarations and no test changes in this comparison");
            }
        }
        risks.AddRange(c.Files.Where(f => IsRiskPath(f.Path)).Select(f => $"{f.Path}: security/startup/composition code changed"));
        risks.AddRange(c.Files.Where(f => (f.Insertions ?? 0) + (f.Deletions ?? 0) >= 300).Select(f => $"{f.Path}: large change (+{f.Insertions} −{f.Deletions})"));
        Items(risks, s => s);

        Section("Verification Status");
        sb.AppendLine(c.Verification);
        return sb.ToString();
    }

    [GeneratedRegex(@"(^|/)(tests?|[^/]*\.Tests?|[^/]*Tests?)(/|$)|Tests?\.cs$", RegexOptions.IgnoreCase)]
    private static partial Regex TestPath();

    [GeneratedRegex(@"(^|/)(Models?|Entities|Entity|Dtos?|Contracts|Domain)(/|$)", RegexOptions.IgnoreCase)]
    private static partial Regex DataModelPath();

    [GeneratedRegex(@"(Entity|Dto|Model|Record|Request|Response)$")]
    private static partial Regex DataModelName();

    [GeneratedRegex(@"(^|/)(Program\.cs|Startup\.cs|[^/]*ServiceCollectionExtensions\.cs)$|(^|/)(Security|Auth[^/]*|Permissions?)(/|$)|appsettings[^/]*\.json$", RegexOptions.IgnoreCase)]
    private static partial Regex RiskPath();

    [GeneratedRegex(@"\b(fix(e[sd])?|bug|hotfix|patch(ed)?|resolve[sd]?|regression)\b", RegexOptions.IgnoreCase)]
    private static partial Regex FixWords();
}
