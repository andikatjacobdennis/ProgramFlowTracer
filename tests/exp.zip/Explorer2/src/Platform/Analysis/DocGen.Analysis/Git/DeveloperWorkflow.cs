using System.Collections.Concurrent;
using System.Diagnostics;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using DocGen.Analysis.Commands;
using DocGen.Analysis.Indexing;
using DocGen.Analysis.Tools;
using DocGen.Core.Exceptions;
using DocGen.Core.Options;
using DocGen.Data.Storage;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Git;

public static class CommitStates
{
    public const string NotReady = "NOT READY";
    public const string Verifying = "VERIFYING";
    public const string Ready = "READY";
    public const string Committed = "COMMITTED";
    public const string Pushed = "PUSHED";
    public const string DirtyAfterCommit = "DIRTY AFTER COMMIT";
    public const string Clean = "CLEAN";
}

public sealed class PreCommitStepResult
{
    public string Name { get; set; } = "";

    /// <summary>restore | build | unit | integration | smoke | extra</summary>
    public string Category { get; set; } = "";

    public string? Target { get; set; }

    /// <summary>passed | failed | no-tests (the test command ran zero tests) | not-run</summary>
    public string Status { get; set; } = "not-run";

    public int? Passed { get; set; }
    public int? Failed { get; set; }
    public int? Skipped { get; set; }
    public int? Errors { get; set; }
    public int? Warnings { get; set; }
    public string? CommandId { get; set; }
    public double Seconds { get; set; }
    public string? Summary { get; set; }
}

/// <summary>The verification cache: which exact tree was verified, when, and with what result.</summary>
public sealed class VerificationRecord
{
    public string Fingerprint { get; set; } = "";
    public string? Head { get; set; }
    public string? Branch { get; set; }
    public Dictionary<string, string> FileHashes { get; set; } = new(StringComparer.Ordinal);
    public DateTime StartedAt { get; set; } = DateTime.UtcNow;
    public DateTime? CompletedAt { get; set; }

    /// <summary>running | passed | failed | changed-during-run | error</summary>
    public string Status { get; set; } = "running";

    public string? Error { get; set; }
    public List<PreCommitStepResult> Steps { get; set; } = [];
    public bool Passed => Status == "passed";
}

public sealed class CommitRecordInfo
{
    public string Commit { get; set; } = "";
    public string Message { get; set; } = "";
    public string Fingerprint { get; set; } = "";
    public bool Verified { get; set; }
    public DateTime At { get; set; } = DateTime.UtcNow;
}

public sealed class PushRecordInfo
{
    public string Remote { get; set; } = "";
    public string Branch { get; set; } = "";
    public string Commit { get; set; } = "";
    public DateTime At { get; set; } = DateTime.UtcNow;
}

public sealed class WorkflowDocument
{
    public VerificationRecord? Verification { get; set; }
    public CommitRecordInfo? LastCommit { get; set; }
    public PushRecordInfo? LastPush { get; set; }
}

public sealed record SafetyCheck(string Name, bool Passed, string Detail, bool Blocking = true);

/// <summary>State shown near the composer and in the Git panel.</summary>
public sealed class WorkflowState
{
    public required GitStatusReport Status { get; init; }
    public string State { get; set; } = CommitStates.NotReady;
    public string Detail { get; set; } = "";
    public VerificationRecord? Verification { get; set; }
    public bool VerificationStale { get; set; }
    public bool VerificationRunning { get; set; }
    public List<string> ChangedSinceVerification { get; set; } = [];
    public CommitRecordInfo? LastCommit { get; set; }
    public PushRecordInfo? LastPush { get; set; }

    /// <summary>not verified | passed | failed | stale | running — for the compact indicator.</summary>
    public string BuildStatus { get; set; } = "not verified";

    public string TestStatus { get; set; } = "not verified";
}

public sealed class PreCommitReport
{
    public required WorkflowState State { get; init; }
    public List<SafetyCheck> Checks { get; set; } = [];
    public string SuggestedMessage { get; set; } = "";
    public List<SymbolChange> Symbols { get; set; } = [];
    public bool CanCommit => State.State == CommitStates.Ready && Checks.All(c => c.Passed || !c.Blocking);
}

public sealed class PushView
{
    public required GitStatusReport Status { get; init; }
    public string? Remote { get; set; }
    public string? RemoteUrl { get; set; }
    public string? Branch { get; set; }
    public string? Upstream { get; set; }
    public bool SetsUpstream { get; set; }
    public List<GitCommitInfo> Commits { get; set; } = [];
    public string Verification { get; set; } = "";
    public List<string> Problems { get; set; } = [];
    public bool CanPush => Problems.Count == 0 && Commits.Count > 0;
}

/// <summary>
/// Pre-commit verification, the verification cache, commit/push states, commit safety and gated commit/push.
/// DocGen never commits or pushes on its own: the web endpoints are invoked by the user's explicit click and the
/// agent tools always require the user's approval (<see cref="Core.Abstractions.IUserIntentTool"/>). A commit is refused
/// unless the exact current tree passed verification and the tree still matches the diff the user reviewed.
/// </summary>
public sealed partial class DeveloperWorkflowService(
    GitService git,
    AnalysisServices services,
    IJsonStore store,
    IOptionsMonitor<WorkflowOptions> options,
    ILogger<DeveloperWorkflowService> logger)
{
    private readonly ConcurrentDictionary<string, Task<VerificationRecord>> _running = new(StringComparer.Ordinal);

    private static string Key(GitContext ctx) => ctx.UserId + ":" + ctx.Repo.IndexKey;

    private static string DocPath(GitContext ctx)
        => $"workflow/{ctx.UserId}/{Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(ctx.Repo.IndexKey)))[..24]}.json";

    public async Task<WorkflowDocument> LoadAsync(GitContext ctx, CancellationToken ct) => await store.ReadAsync<WorkflowDocument>(DocPath(ctx), ct) ?? new WorkflowDocument();

    private async Task UpdateAsync(GitContext ctx, Action<WorkflowDocument> change, CancellationToken ct)
    {
        await using var _ = await store.AcquireLockAsync(DocPath(ctx), ct);
        var doc = await LoadAsync(ctx, ct);
        change(doc);
        await store.WriteAsync(DocPath(ctx), doc, ct);
    }

    public bool IsVerifying(GitContext ctx) => _running.TryGetValue(Key(ctx), out var t) && !t.IsCompleted;

    /// <summary>Current commit state, deterministically derived from Git status, the verification cache and the last commit/push.</summary>
    public async Task<WorkflowState> StateAsync(GitContext ctx, CancellationToken ct)
    {
        var status = await git.StatusAsync(ctx, ct);
        var doc = await LoadAsync(ctx, ct);
        var state = new WorkflowState { Status = status, Verification = doc.Verification, LastCommit = doc.LastCommit, LastPush = doc.LastPush, VerificationRunning = IsVerifying(ctx) };
        var v = doc.Verification;
        var matches = v is { Status: not "running" } && v.Fingerprint == status.Fingerprint;
        state.VerificationStale = v is { Status: not "running" } && !matches;
        if (state.VerificationStale && v is not null)
        {
            state.ChangedSinceVerification = status.FileHashes.Where(p => !v.FileHashes.TryGetValue(p.Key, out var h) || h != p.Value).Select(p => p.Key)
                .Concat(v.FileHashes.Keys.Where(k => !status.FileHashes.ContainsKey(k))).Distinct().Take(50).ToList();
        }
        string Of(params string[] categories)
        {
            if (state.VerificationRunning)
            {
                return "running";
            }
            if (v is null || v.Status == "running")
            {
                return "not verified";
            }
            if (!matches)
            {
                return "stale";
            }
            var steps = v.Steps.Where(s => categories.Contains(s.Category)).ToList();
            return steps.Count == 0 ? "not run" : steps.Any(s => s.Status == "failed") ? "failed"
                : steps.All(s => s.Status == "no-tests") ? "no tests" : steps.All(s => s.Status is "passed" or "no-tests") ? "passed" : "incomplete";
        }
        state.BuildStatus = Of("restore", "build");
        state.TestStatus = Of("unit", "integration", "smoke", "extra");

        if (state.VerificationRunning)
        {
            state.State = CommitStates.Verifying;
            state.Detail = "Pre-commit verification is running.";
        }
        else if (status.Clean)
        {
            if (status.Ahead > 0 || status.Upstream is null && doc.LastCommit?.Commit == status.Head && status.Head is not null)
            {
                state.State = CommitStates.Committed;
                state.Detail = status.Upstream is null ? "Committed locally; no upstream branch." : $"Committed; {status.Ahead} commit(s) not pushed to {status.Upstream}.";
            }
            else if (status.Upstream is not null && status.Ahead == 0 && doc.LastPush?.Commit == status.Head)
            {
                state.State = CommitStates.Pushed;
                state.Detail = $"Pushed to {status.Upstream}.";
            }
            else
            {
                state.State = CommitStates.Clean;
                state.Detail = "No local changes.";
            }
        }
        else if (status.Conflicted > 0)
        {
            state.State = CommitStates.NotReady;
            state.Detail = $"{status.Conflicted} file(s) have merge conflicts.";
        }
        else if (matches && v!.Passed)
        {
            state.State = CommitStates.Ready;
            state.Detail = $"Verified {v.CompletedAt:yyyy-MM-dd HH:mm} UTC for this exact tree.";
        }
        else if (doc.LastCommit is { } last && last.Commit == status.Head && !matches)
        {
            state.State = CommitStates.DirtyAfterCommit;
            state.Detail = $"Files changed after commit {last.Commit[..Math.Min(7, last.Commit.Length)]}; verify again before the next commit.";
        }
        else
        {
            state.State = CommitStates.NotReady;
            state.Detail = v is null ? "Not verified." : state.VerificationStale ? $"Verification stale: {state.ChangedSinceVerification.Count} file(s) changed since the last verification."
                : v.Status == "failed" ? "The last verification failed." : $"Last verification: {v.Status}.";
        }
        return state;
    }

    /// <summary>Starts (or joins) a background pre-commit verification of the current tree.</summary>
    public Task<VerificationRecord> StartVerificationAsync(GitContext ctx)
    {
        if (!ctx.Repo.AllowCommands)
        {
            throw new ForbiddenException($"Commands are not enabled for repository '{ctx.Repo.Name}'.");
        }
        return _running.AddOrUpdate(Key(ctx),
            _ => Task.Run(() => VerifyAsync(ctx)),
            (_, existing) => existing.IsCompleted ? Task.Run(() => VerifyAsync(ctx)) : existing);
    }

    private async Task<VerificationRecord> VerifyAsync(GitContext ctx)
    {
        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(Math.Max(60, options.CurrentValue.VerificationTimeoutSeconds)));
        var ct = cts.Token;
        var before = await git.StatusAsync(ctx, ct);
        var record = new VerificationRecord { Fingerprint = before.Fingerprint, Head = before.Head, Branch = before.Branch, FileHashes = before.FileHashes };
        await UpdateAsync(ctx, d => d.Verification = record, ct);
        try
        {
            var solution = FindSolution(ctx.Repo.Root);
            async Task AddStepAsync(PreCommitStepResult step)
            {
                // Progress is visible while the verification runs (the record stays "running" until the end).
                record.Steps.Add(step);
                await UpdateAsync(ctx, d => d.Verification = record, ct);
            }
            var restore = await RunStepAsync(ctx, "restore", "Restore", new CommandRequest { Kind = CommandKinds.Restore, Target = solution }, ct);
            await AddStepAsync(restore);
            var build = restore.Status == "passed"
                ? await RunStepAsync(ctx, "build", "Build", new CommandRequest { Kind = CommandKinds.Build, Target = solution, NoRestore = true }, ct)
                : new PreCommitStepResult { Name = "Build", Category = "build", Target = solution, Status = "not-run", Summary = "skipped: restore failed" };
            await AddStepAsync(build);
            foreach (var (project, category) in FindTestProjects(ctx.Repo.Root, solution))
            {
                await AddStepAsync(build.Status == "passed"
                    ? await RunStepAsync(ctx, category, "Tests: " + Path.GetFileNameWithoutExtension(project), new CommandRequest { Kind = CommandKinds.Test, Target = project, NoBuild = true, NoRestore = true }, ct)
                    : new PreCommitStepResult { Name = "Tests: " + Path.GetFileNameWithoutExtension(project), Category = category, Target = project, Status = "not-run", Summary = "skipped: build failed" });
            }
            foreach (var extra in options.CurrentValue.ExtraVerificationSteps)
            {
                var kind = extra.Kind is CommandKinds.Build or CommandKinds.Test ? extra.Kind : CommandKinds.Test;
                await AddStepAsync(build.Status == "passed"
                    ? await RunStepAsync(ctx, "extra", extra.Name is { Length: > 0 } n ? n : kind, new CommandRequest { Kind = kind, Target = extra.Target, Filter = extra.Filter, NoRestore = true }, ct)
                    : new PreCommitStepResult { Name = extra.Name, Category = "extra", Status = "not-run", Summary = "skipped: build failed" });
            }
            var after = await git.StatusAsync(ctx, ct);
            record.Status = after.Fingerprint != before.Fingerprint ? "changed-during-run"
                : record.Steps.All(s => s.Status is "passed" or "no-tests") ? "passed" : "failed";
            if (record.Status == "changed-during-run")
            {
                record.Error = "Files changed while verification was running; the result does not describe the current tree.";
            }
        }
        catch (Exception ex) when (ex is not OutOfMemoryException)
        {
            record.Status = "error";
            record.Error = ex is OperationCanceledException ? "Verification timed out." : ex.Message;
            logger.LogWarning(ex, "Pre-commit verification failed for {Repository}", ctx.Repo.Name);
        }
        record.CompletedAt = DateTime.UtcNow;
        await UpdateAsync(ctx, d => d.Verification = record, CancellationToken.None);
        logger.LogInformation("Pre-commit verification of {Repository}: {Status} ({Steps} steps)", ctx.Repo.Name, record.Status, record.Steps.Count);
        return record;
    }

    private async Task<PreCommitStepResult> RunStepAsync(GitContext ctx, string category, string name, CommandRequest request, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        var step = new PreCommitStepResult { Name = name, Category = category, Target = request.Target };
        var record = await services.Commands.StartAsync(ctx.UserId, ctx.Repo, new CommandRequest
        {
            Kind = request.Kind, Target = request.Target, Filter = request.Filter, NoBuild = request.NoBuild, NoRestore = request.NoRestore,
            RunId = ctx.RunId, ConversationId = ctx.ConversationId, TimeoutSeconds = Math.Max(60, options.CurrentValue.VerificationTimeoutSeconds),
        }, ct);
        record = await services.Commands.WaitAsync(ctx.UserId, record.Id, TimeSpan.FromSeconds(Math.Max(60, options.CurrentValue.VerificationTimeoutSeconds)), ct);
        step.CommandId = record.Id;
        step.Seconds = sw.Elapsed.TotalSeconds;
        step.Errors = record.Build?.ErrorCount ?? record.Tests?.Build?.ErrorCount;
        step.Warnings = record.Build?.WarningCount ?? record.Tests?.Build?.WarningCount;
        if (record.Tests is { } t)
        {
            step.Passed = t.Passed;
            step.Failed = t.Failed ?? t.Failures.Count;
            step.Skipped = t.Skipped;
        }
        step.Status = record.Status == CommandStatus.Succeeded && (record.Tests?.Failed ?? 0) == 0
            ? request.Kind == CommandKinds.Test && (record.Tests?.Passed ?? 0) + (record.Tests?.Failed ?? 0) + (record.Tests?.Skipped ?? 0) == 0 ? "no-tests" : "passed"
            : "failed";
        step.Summary = Tools.CommandSummary(record);
        return step;
    }

    public static string? FindSolution(string root)
        => Directory.EnumerateFiles(root, "*.sln").Concat(Directory.EnumerateFiles(root, "*.slnx")).OrderBy(f => f, StringComparer.OrdinalIgnoreCase)
            .Select(f => Path.GetFileName(f)).FirstOrDefault();

    /// <summary>
    /// Test projects (relative paths) classified by name: *Integration* → integration, *Smoke*/*E2E* → smoke, otherwise unit.
    /// With a solution, only its projects count (the build step built exactly those); test fixtures elsewhere are not run.
    /// </summary>
    public static List<(string Project, string Category)> FindTestProjects(string root, string? solution = null)
    {
        HashSet<string>? inSolution = null;
        if (solution is not null && File.Exists(Path.Combine(root, solution)))
        {
            inSolution = ProjectParser.ParseSolution(Path.Combine(root, solution), root).Projects
                .Select(p => p.Replace('\\', '/')).ToHashSet(StringComparer.OrdinalIgnoreCase);
        }
        var excluded = new HashSet<string>(["bin", "obj", "node_modules", ".git", ".vs", "packages"], StringComparer.OrdinalIgnoreCase);
        var list = new List<(string, string)>();
        foreach (var file in Directory.EnumerateFiles(root, "*.csproj", new EnumerationOptions { RecurseSubdirectories = true, MaxRecursionDepth = 6, IgnoreInaccessible = true }))
        {
            var relative = Path.GetRelativePath(root, file);
            if (relative.Split(Path.DirectorySeparatorChar).Any(excluded.Contains))
            {
                continue;
            }
            var text = File.ReadAllText(file);
            var name = Path.GetFileNameWithoutExtension(file);
            var isTest = text.Contains("<IsTestProject>true", StringComparison.OrdinalIgnoreCase) || TestPackages().IsMatch(text)
                         || name.EndsWith(".Tests", StringComparison.OrdinalIgnoreCase) || name.EndsWith(".Test", StringComparison.OrdinalIgnoreCase);
            if (isTest && (inSolution is null || inSolution.Contains(relative.Replace('\\', '/'))))
            {
                list.Add((relative.Replace('\\', '/'), Category(name)));
            }
        }
        return list.OrderBy(p => p.Item1, StringComparer.Ordinal).ToList();
    }

    public static string Category(string projectName)
        => projectName.Contains("Integration", StringComparison.OrdinalIgnoreCase) ? "integration"
            : projectName.Contains("Smoke", StringComparison.OrdinalIgnoreCase) || projectName.Contains("E2E", StringComparison.OrdinalIgnoreCase)
              || projectName.Contains("EndToEnd", StringComparison.OrdinalIgnoreCase) ? "smoke"
            : "unit";

    /// <summary>Pre-commit report: state, verification results, safety checks, changes and a message generated from the diff.</summary>
    public async Task<PreCommitReport> PreCommitAsync(GitContext ctx, CancellationToken ct)
    {
        var state = await StateAsync(ctx, ct);
        var report = new PreCommitReport { State = state };
        report.Checks = await SafetyChecksAsync(ctx, state, ct);
        report.Symbols = await WorkingTreeSymbolsAsync(ctx, state.Status, ct);
        report.SuggestedMessage = CommitMessageGenerator.Generate(state.Status, report.Symbols);
        return report;
    }

    private async Task<List<SymbolChange>> WorkingTreeSymbolsAsync(GitContext ctx, GitStatusReport status, CancellationToken ct)
    {
        var list = new List<SymbolChange>();
        foreach (var f in status.Files.Where(f => f.Path.EndsWith(".cs", StringComparison.OrdinalIgnoreCase)).Take(60))
        {
            var before = f.Kind is "added" or "untracked" || status.Head is null ? null : await git.ShowAsync(ctx, "HEAD", f.OriginalPath ?? f.Path, BranchComparer.MaxSemanticBytes, ct);
            var full = Path.Combine(ctx.GitRoot, f.Path);
            var after = f.Kind == "deleted" || !File.Exists(full) || new FileInfo(full).Length > BranchComparer.MaxSemanticBytes ? null : await File.ReadAllTextAsync(full, ct);
            list.AddRange(SemanticDiff.CompareCSharp(f.Path, before, after));
        }
        return list;
    }

    /// <summary>Commit safety: conflicts, secrets, build output, huge files, verification and tree identity.</summary>
    public async Task<List<SafetyCheck>> SafetyChecksAsync(GitContext ctx, WorkflowState state, CancellationToken ct)
    {
        var status = state.Status;
        var checks = new List<SafetyCheck>
        {
            new("No merge conflicts", status.Conflicted == 0, status.Conflicted == 0 ? "none" : string.Join(", ", status.Files.Where(f => f.Kind == "conflicted").Select(f => f.Path).Take(10))),
        };
        var buildOutput = status.Files.Where(f => f.Kind != "deleted" && BuildOutput().IsMatch(f.Path)).Select(f => f.Path).ToList();
        checks.Add(new SafetyCheck("No bin/obj or build output", buildOutput.Count == 0, buildOutput.Count == 0 ? "none" : string.Join(", ", buildOutput.Take(10))));

        var max = options.CurrentValue.MaxCommitFileBytes;
        var huge = status.Files.Where(f => f.Kind != "deleted" && File.Exists(Path.Combine(ctx.GitRoot, f.Path)) && new FileInfo(Path.Combine(ctx.GitRoot, f.Path)).Length > max)
            .Select(f => $"{f.Path} ({new FileInfo(Path.Combine(ctx.GitRoot, f.Path)).Length / 1024 / 1024.0:0.#} MB)").ToList();
        checks.Add(new SafetyCheck($"No files over {max / 1024 / 1024} MB", huge.Count == 0, huge.Count == 0 ? "none" : string.Join(", ", huge.Take(10))));

        var secretFiles = status.Files.Where(f => f.Kind != "deleted" && SecretScanner.IsSecretFileName(f.Path)).Select(f => f.Path).ToList();
        var strong = new List<string>();
        var weak = new List<string>();
        foreach (var f in status.Files.Where(f => f.Kind != "deleted" && !f.Binary))
        {
            var full = Path.Combine(ctx.GitRoot, f.Path);
            if (!File.Exists(full) || new FileInfo(full).Length > 2 * 1024 * 1024)
            {
                continue;
            }
            var kinds = SecretScanner.Find(await File.ReadAllTextAsync(full, ct));
            if (kinds.Any(k => k != "password assignment"))
            {
                strong.Add($"{f.Path} ({string.Join(", ", kinds.Where(k => k != "password assignment"))})");
            }
            else if (kinds.Count > 0)
            {
                weak.Add(f.Path);
            }
        }
        checks.Add(new SafetyCheck("No secret files", secretFiles.Count == 0, secretFiles.Count == 0 ? "none" : string.Join(", ", secretFiles.Take(10))));
        checks.Add(new SafetyCheck("No credentials in changed files", strong.Count == 0, strong.Count == 0 ? "none detected" : string.Join("; ", strong.Take(10))));
        if (weak.Count > 0)
        {
            checks.Add(new SafetyCheck("Password-like assignments (review)", false, string.Join(", ", weak.Take(10)), Blocking: false));
        }
        checks.Add(new SafetyCheck("Verification passed for this exact tree", state.State == CommitStates.Ready,
            state.State == CommitStates.Ready ? state.Detail : state.Detail is { Length: > 0 } d ? d : "not verified"));
        return checks;
    }

    /// <summary>
    /// Commits every change in the working tree (git add -A; git commit) after re-checking safety. <paramref name="reviewedFingerprint"/>
    /// is the tree identity the user reviewed; any difference refuses the commit. Hooks are never skipped.
    /// </summary>
    public async Task<CommitRecordInfo> CommitAsync(GitContext ctx, string message, string reviewedFingerprint, CancellationToken ct)
    {
        if (!ctx.Repo.AllowCommands || !ctx.Repo.AllowWrite)
        {
            throw new ForbiddenException($"Committing requires commands and write access for repository '{ctx.Repo.Name}'.");
        }
        message = (message ?? "").Trim();
        if (message.Length is 0 or > 5000)
        {
            throw new ValidationException("A commit message (1–5000 characters) is required.");
        }
        if (SecretScanner.ContainsSecret(message))
        {
            throw new ValidationException("The commit message looks like it contains a credential.");
        }
        var state = await StateAsync(ctx, ct);
        if (!string.Equals(state.Status.Fingerprint, reviewedFingerprint, StringComparison.Ordinal))
        {
            throw new DocGenException("TREE_CHANGED", "The working tree changed after it was reviewed. Review the changes again before committing.", 409);
        }
        var checks = await SafetyChecksAsync(ctx, state, ct);
        if (checks.FirstOrDefault(c => c.Blocking && !c.Passed) is { } failed)
        {
            throw new DocGenException("COMMIT_BLOCKED", $"Commit refused — {failed.Name}: {failed.Detail}", 409);
        }
        var add = await git.RunAsync(ctx, ["add", "-A", "--", "."], "Stage all changes for commit", ct, risk: "Write");
        if (!add.Ok)
        {
            throw new ValidationException("git add failed: " + add.Error);
        }
        await CommitWithMessageAsync(ctx, message, ct);
        var head = await git.RunAsync(ctx, ["rev-parse", "HEAD"], "Read new HEAD", ct);
        var info = new CommitRecordInfo { Commit = head.Stdout.Trim(), Message = message, Fingerprint = reviewedFingerprint, Verified = true };
        await UpdateAsync(ctx, d => d.LastCommit = info, ct);
        logger.LogInformation("User {UserId} committed {Commit} in {Repository}", ctx.UserId, info.Commit, ctx.Repo.Name);
        return info;
    }

    private async Task<GitOutput> CommitWithMessageAsync(GitContext ctx, string message, CancellationToken ct)
    {
        // The message goes through a temporary file (no shell quoting); it is deleted afterwards.
        var file = Path.Combine(Path.GetTempPath(), "docgen-commit-" + Guid.NewGuid().ToString("N") + ".txt");
        await File.WriteAllTextAsync(file, message + "\n", new UTF8Encoding(false), ct);
        try
        {
            var result = await git.RunAsync(ctx, ["commit", "-F", file], "Commit", ct, risk: "Write", timeoutSeconds: 300);
            if (!result.Ok)
            {
                throw new ValidationException("git commit failed: " + result.Error);
            }
            return result;
        }
        finally
        {
            File.Delete(file);
        }
    }

    /// <summary>What a push would do: remote, branch, upstream, commits and whether they were verified.</summary>
    public async Task<PushView> PushViewAsync(GitContext ctx, CancellationToken ct)
    {
        var status = await git.StatusAsync(ctx, ct);
        var doc = await LoadAsync(ctx, ct);
        var view = new PushView { Status = status, Branch = status.Branch, Upstream = status.Upstream };
        var remotes = await git.RemotesAsync(ctx, ct);
        if (status.Upstream is { } upstream && upstream.Contains('/', StringComparison.Ordinal))
        {
            view.Remote = upstream[..upstream.IndexOf('/', StringComparison.Ordinal)];
        }
        else
        {
            view.Remote = remotes.Select(r => r.Name).Distinct().Count() == 1 ? remotes[0].Name : remotes.Any(r => r.Name == "origin") ? "origin" : null;
            view.SetsUpstream = view.Remote is not null;
        }
        view.RemoteUrl = remotes.FirstOrDefault(r => r.Name == view.Remote).Url;
        view.Commits = await git.UnpushedAsync(ctx, status, ct);
        if (status.Detached || status.Branch is null)
        {
            view.Problems.Add("HEAD is detached; check out a branch first.");
        }
        if (view.Remote is null)
        {
            view.Problems.Add(remotes.Count == 0 ? "No remote is configured." : "Several remotes and no upstream: set an upstream branch first.");
        }
        if (status.Behind > 0)
        {
            view.Problems.Add($"The branch is {status.Behind} commit(s) behind {status.Upstream}; integrate those first (DocGen never force-pushes).");
        }
        if (status.Conflicted > 0)
        {
            view.Problems.Add("Merge conflicts are present.");
        }
        view.Verification = doc.LastCommit is { } last && last.Commit == status.Head
            ? last.Verified ? $"HEAD {last.Commit[..7]} was committed from a verified tree." : $"HEAD {last.Commit[..7]} was committed without verification."
            : "HEAD was not committed through DocGen; its verification status is unknown.";
        return view;
    }

    public async Task<PushRecordInfo> PushAsync(GitContext ctx, CancellationToken ct)
    {
        if (!ctx.Repo.AllowCommands)
        {
            throw new ForbiddenException($"Commands are not enabled for repository '{ctx.Repo.Name}'.");
        }
        var view = await PushViewAsync(ctx, ct);
        if (!view.CanPush)
        {
            throw new DocGenException("PUSH_BLOCKED", view.Commits.Count == 0 && view.Problems.Count == 0 ? "Nothing to push." : "Push refused: " + string.Join(" ", view.Problems), 409);
        }
        IReadOnlyList<string> args = view.SetsUpstream ? ["push", "--set-upstream", "--end-of-options", view.Remote!, view.Branch!] : ["push", "--end-of-options", view.Remote!, view.Branch!];
        var result = await git.RunAsync(ctx, args, "Push", ct, risk: "External", timeoutSeconds: 300);
        if (!result.Ok)
        {
            throw new ValidationException("git push failed: " + result.Error);
        }
        var info = new PushRecordInfo { Remote = view.Remote!, Branch = view.Branch!, Commit = view.Status.Head ?? "" };
        await UpdateAsync(ctx, d => d.LastPush = info, ct);
        logger.LogInformation("User {UserId} pushed {Branch} to {Remote} in {Repository}", ctx.UserId, info.Branch, info.Remote, ctx.Repo.Name);
        return info;
    }

    /// <summary>Verification line for a branch comparison: only a verified, clean current HEAD counts.</summary>
    public async Task<string> VerificationForCommitAsync(GitContext ctx, string commit, CancellationToken ct)
    {
        var doc = await LoadAsync(ctx, ct);
        if (doc.Verification is { Passed: true } v && v.Head == commit && v.FileHashes.Count == 0)
        {
            return $"Verified by DocGen at {v.CompletedAt:yyyy-MM-dd HH:mm} UTC (restore, build and tests passed for this commit with a clean tree).";
        }
        if (doc.LastCommit is { Verified: true } c && c.Commit == commit)
        {
            return $"Committed through DocGen from a verified tree ({c.At:yyyy-MM-dd HH:mm} UTC).";
        }
        return "Not verified: DocGen has no build/test result for the head commit. Run precommit_verify on a checkout of it to verify.";
    }

    [GeneratedRegex(@"(^|/)(bin|obj)/|\.(dll|exe|pdb|nupkg|snupkg)$", RegexOptions.IgnoreCase)]
    private static partial Regex BuildOutput();

    [GeneratedRegex(@"MSTest|xunit|NUnit|Microsoft\.NET\.Test\.Sdk", RegexOptions.IgnoreCase)]
    private static partial Regex TestPackages();

    /// <summary>Short text for a finished command.</summary>
    private static class Tools
    {
        public static string CommandSummary(CommandRecord r)
            => r.Tests is { } t ? $"{r.Status}: {t.Passed ?? 0} passed, {t.Failed ?? t.Failures.Count} failed, {t.Skipped ?? 0} skipped"
                : r.Build is { } b ? $"{r.Status}: {b.ErrorCount} errors, {b.WarningCount} warnings"
                : $"{r.Status} (exit {r.ExitCode})";
    }
}

/// <summary>Commit messages generated from the actual changes (paths, kinds, declarations) — never invented.</summary>
public static class CommitMessageGenerator
{
    public static string Generate(GitStatusReport status, IReadOnlyList<SymbolChange> symbols)
    {
        if (status.Clean)
        {
            return "";
        }
        var files = status.Files;
        bool All(Func<GitFileChange, bool> p) => files.All(p);
        var type = All(f => BranchComparer.IsTestPath(f.Path)) ? "test"
            : All(f => f.Path.EndsWith(".md", StringComparison.OrdinalIgnoreCase) || f.Path.StartsWith("docs/", StringComparison.OrdinalIgnoreCase)) ? "docs"
            : All(f => IsBuildFile(f.Path)) ? "build"
            : symbols.Any(s => s.Change == "added" && !s.IsTest && (SymbolKinds.IsType(s.SymbolKind) || s.Public)) ? "feat"
            : null;

        var areas = files.Select(f => Area(f.Path)).GroupBy(a => a).OrderByDescending(g => g.Count()).Select(g => g.Key).Take(3).ToList();
        var newTypes = symbols.Where(s => s.Change == "added" && SymbolKinds.IsType(s.SymbolKind) && !s.IsTest).Select(s => s.FullName.Split('.')[^1]).Distinct().Take(3).ToList();
        string subject;
        if (newTypes.Count > 0)
        {
            subject = $"Add {string.Join(", ", newTypes)}";
        }
        else if (files.Count == 1)
        {
            var f = files[0];
            subject = $"{Verb(f.Kind)} {f.Path}";
        }
        else
        {
            subject = $"Update {string.Join(", ", areas)}";
        }
        if (files.Count > 1 && newTypes.Count > 0 && areas.Count > 0)
        {
            subject += $" in {areas[0]}";
        }
        subject = (type is null ? "" : type + ": ") + subject;
        if (subject.Length > 72)
        {
            subject = subject[..69] + "...";
        }

        var sb = new StringBuilder(subject).Append("\n\n");
        var groups = new[] { ("Added", new[] { "added", "untracked", "copied" }), ("Modified", new[] { "modified", "typechange" }), ("Renamed", new[] { "renamed" }), ("Deleted", new[] { "deleted" }) };
        foreach (var (label, kinds) in groups)
        {
            var list = files.Where(f => kinds.Contains(f.Kind)).ToList();
            if (list.Count == 0)
            {
                continue;
            }
            sb.Append(label).Append(": ").Append(string.Join(", ", list.Take(8).Select(f => f.Kind == "renamed" ? $"{f.OriginalPath} → {f.Path}" : f.Path)));
            sb.Append(list.Count > 8 ? $" (+{list.Count - 8} more)" : "").Append('\n');
        }
        var decl = symbols.Where(s => !s.IsTest && SymbolKinds.IsCallable(s.SymbolKind) && s.Change is "added" or "signature" or "removed").Take(6).ToList();
        if (decl.Count > 0)
        {
            sb.Append("Declarations: ").Append(string.Join("; ", decl.Select(s => $"{s.Change} {s.FullName.Split('.').TakeLast(2).Aggregate((a, b) => a + "." + b)}"))).Append('\n');
        }
        var tests = symbols.Count(s => s.IsTest && s.Change == "added");
        if (tests > 0)
        {
            sb.Append(CultureInfo.InvariantCulture, $"Tests: {tests} added\n");
        }
        sb.Append(CultureInfo.InvariantCulture, $"\n{files.Count} files, +{status.Insertions} −{status.Deletions}");
        return sb.ToString().TrimEnd();
    }

    private static bool IsBuildFile(string path)
        => path.EndsWith(".csproj", StringComparison.OrdinalIgnoreCase) || path.EndsWith(".props", StringComparison.OrdinalIgnoreCase)
           || path.EndsWith(".targets", StringComparison.OrdinalIgnoreCase) || path.EndsWith(".sln", StringComparison.OrdinalIgnoreCase)
           || path.EndsWith(".slnx", StringComparison.OrdinalIgnoreCase) || path.StartsWith(".github/", StringComparison.OrdinalIgnoreCase);

    private static string Area(string path)
    {
        var parts = path.Split('/');
        return parts.Length >= 2 && parts[0] is "src" or "tests" or "test" or "tools" ? parts[1] : parts.Length >= 2 ? parts[0] : Path.GetFileNameWithoutExtension(path);
    }

    private static string Verb(string kind) => kind switch { "added" or "untracked" => "Add", "deleted" => "Remove", "renamed" => "Rename", _ => "Update" };
}
