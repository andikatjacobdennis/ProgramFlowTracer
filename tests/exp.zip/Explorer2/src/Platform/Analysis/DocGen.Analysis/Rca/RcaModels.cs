namespace DocGen.Analysis.Rca;

public static class NodeKinds
{
    public const string Failure = "failure";
    public const string Local = "local";
    public const string Parameter = "parameter";
    public const string Argument = "argument";
    public const string ConstructorParameter = "constructorParameter";
    public const string Field = "field";
    public const string Write = "write";
    public const string Initializer = "initializer";
    public const string Construction = "construction";
    public const string Omission = "omission";
    public const string Return = "return";
    public const string Transformation = "transformation";
    public const string Filter = "filter";
    public const string Element = "element";
    public const string Literal = "literal";
    public const string Deserialization = "deserialization";
    public const string Configuration = "configuration";
    public const string DependencyInjection = "di";
    public const string Input = "input";
    public const string External = "external";
    public const string Unknown = "unknown";
}

/// <summary>One step of a backward provenance trace. Confidence is qualitative: definite, likely or ambiguous.</summary>
public sealed class ProvenanceNode
{
    public int Id { get; set; }
    public int ParentId { get; set; } = -1;
    public string Kind { get; set; } = NodeKinds.Unknown;
    public string Title { get; set; } = "";
    public string? Expression { get; set; }

    /// <summary>Member (full name) where this step happens.</summary>
    public string? Symbol { get; set; }

    public string? File { get; set; }
    public int? Line { get; set; }
    public int Depth { get; set; }

    /// <summary>definite | likely | ambiguous</summary>
    public string Confidence { get; set; } = "likely";

    /// <summary>For origin nodes: where a value was introduced (null-literal, default, omission, configuration, deserialization, input…).</summary>
    public string? Origin { get; set; }

    /// <summary>Member path still being traced when this node was reached (e.g. "Author.Name").</summary>
    public string? Path { get; set; }

    public List<string> Notes { get; set; } = [];
}

public static class EvidenceCategories
{
    public const string Stack = "stack";
    public const string Provenance = "provenance";
    public const string NullOrigin = "null-origin";
    public const string Test = "test";
    public const string Configuration = "configuration";
    public const string Serialization = "serialization";
    public const string DependencyInjection = "di";
    public const string Concurrency = "concurrency";
    public const string StaleState = "stale-state";
    public const string Data = "data";
    public const string Arithmetic = "arithmetic";
    public const string Wrapper = "wrapper";
}

public sealed class CandidateEvidence
{
    public string Category { get; set; } = "";
    public double Weight { get; set; }
    public string Text { get; set; } = "";

    /// <summary>True for evidence of a state origin (where invalid state is introduced), not just a propagation step.</summary>
    public bool Origin { get; set; }

    /// <summary>True when the item argues against this candidate being the root cause.</summary>
    public bool Contradicts { get; set; }

    public int? NodeId { get; set; }
}

/// <summary>A ranked root-cause candidate: a member, a configuration value, a data record or a contract.</summary>
public sealed class CauseCandidate
{
    /// <summary>Stable key: member full name, or "config:file#key", "data:file#path", "contract:A→B".</summary>
    public string Key { get; set; } = "";

    public string Title { get; set; } = "";

    /// <summary>code | configuration | data | contract | di</summary>
    public string Kind { get; set; } = "code";

    public string? Symbol { get; set; }
    public string? File { get; set; }
    public int? Line { get; set; }

    /// <summary>Human-readable location (symbol, "file#key" or "file#$.path").</summary>
    public string Location { get; set; } = "";

    /// <summary>throw site | wrapper | propagation | transformation | state origin</summary>
    public string Role { get; set; } = "propagation";

    public double Score { get; set; }

    /// <summary>Strong | Moderate | Weak (qualitative; not a probability).</summary>
    public string Strength { get; set; } = "Weak";

    /// <summary>True when connected to the failing value by a provenance chain or a direct analyzer link.</summary>
    public bool Connected { get; set; }

    public int MaxDepth { get; set; }
    public List<CandidateEvidence> Evidence { get; set; } = [];

    public string Why => string.Join("; ", Evidence.Where(e => !e.Contradicts).OrderByDescending(e => e.Weight).Take(4).Select(e => e.Text));
}

public sealed class ProposedExperiment
{
    public string Id { get; set; } = "";
    public string Description { get; set; } = "";

    /// <summary>What outcome supports / weakens which candidate.</summary>
    public string Discriminates { get; set; } = "";

    /// <summary>cheap | moderate | expensive</summary>
    public string Cost { get; set; } = "cheap";

    /// <summary>DocGen tool that can run it (e.g. counterfactual_run, compare_json_contracts), when one applies.</summary>
    public string? Tool { get; set; }

    public List<string> CandidateKeys { get; set; } = [];
}

/// <summary>Adaptive search budget and its accounting (reported with every analysis).</summary>
public sealed class RcaBudget
{
    public int MaxDepth { get; set; } = 10;
    public int MaxNodes { get; set; } = 400;
    public int MaxFiles { get; set; } = 60;
    public int MaxCallersPerParameter { get; set; } = 8;

    public int FilesOpened { get; set; }
    public HashSet<string> SymbolsConsidered { get; } = new(StringComparer.Ordinal);
    public long SourceLinesRetrieved { get; set; }
    public int NodesTraversed { get; set; }
    public int Expansions { get; set; }
    public bool Exhausted { get; set; }

    public static RcaBudget Narrow() => new() { MaxDepth = 10, MaxNodes = 400, MaxFiles = 60 };

    public static RcaBudget Wide() => new() { MaxDepth = 16, MaxNodes = 1500, MaxFiles = 200, MaxCallersPerParameter = 16 };

    public RcaStats Snapshot() => new()
    {
        FilesOpened = FilesOpened, SymbolsConsidered = SymbolsConsidered.Count, SourceLinesRetrieved = SourceLinesRetrieved,
        NodesTraversed = NodesTraversed, Expansions = Expansions, Exhausted = Exhausted,
    };
}

public sealed class RcaStats
{
    public int FilesOpened { get; set; }
    public int SymbolsConsidered { get; set; }
    public long SourceLinesRetrieved { get; set; }
    public int NodesTraversed { get; set; }
    public int Expansions { get; set; }
    public bool Exhausted { get; set; }
    public long ElapsedMs { get; set; }
}

public sealed class RcaReport
{
    public string Summary { get; set; } = "";
    public string? FailureKind { get; set; }
    public List<ProvenanceNode> Trace { get; set; } = [];
    public List<ProvenanceNode> Nodes { get; set; } = [];
    public List<CauseCandidate> Candidates { get; set; } = [];
    public List<ProposedExperiment> Experiments { get; set; } = [];
    public List<string> Ambiguities { get; set; } = [];
    public List<string> Findings { get; set; } = [];
    public RcaStats Stats { get; set; } = new();
}
