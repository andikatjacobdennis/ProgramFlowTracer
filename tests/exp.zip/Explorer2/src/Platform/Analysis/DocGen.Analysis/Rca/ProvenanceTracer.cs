using DocGen.Analysis.CSharp;
using DocGen.Analysis.Flow;
using DocGen.Analysis.Indexing;

namespace DocGen.Analysis.Rca;

/// <summary>Facts found while tracing that the specialised analyzers (contracts, configuration, DI, state) examine.</summary>
public sealed class TraceHooks
{
    public List<DeserializationSite> Deserializations { get; } = [];
    public List<ConfigurationSite> Configurations { get; } = [];
    public List<KeyedStateSite> KeyedState { get; } = [];
    public List<CapturedDependency> Captured { get; } = [];
    public List<(ProvenanceNode Node, string Type, string Property)> Omissions { get; } = [];
    public HashSet<SymbolRecord> Visited { get; } = new(ReferenceEqualityComparer.Instance);
    public List<(ProvenanceNode Node, MemberFlow Member, string Expression)> NullForgiving { get; } = [];
}

public sealed record DeserializationSite(ProvenanceNode Node, MemberFlow Member, string? Type, string? OptionsExpression, IReadOnlyList<string> Path);

public sealed record ConfigurationSite(ProvenanceNode Node, MemberFlow Member, string? Key, string? OptionsType, IReadOnlyList<string> Path);

public sealed record KeyedStateSite(ProvenanceNode Node, SymbolRecord Type, string Field);

public sealed record CapturedDependency(ProvenanceNode Node, SymbolRecord Holder, string Parameter, string ParameterType);

/// <summary>
/// Backward value-provenance tracing over <see cref="FlowContext"/>. Starting from an expression at a failure site it
/// follows locals, parameters (to their callers' arguments), fields and properties (to their writers), object
/// initializers and constructor arguments, return values (binding parameters to the call's arguments), LINQ element
/// flow, collection writes and framework boundaries (deserialization, configuration, DI, file input). Resolution is
/// conservative and name-based where types are unknown; every step records its confidence.
/// </summary>
public sealed class ProvenanceTracer(FlowContext ctx)
{
    private static readonly HashSet<string> DeserializeMethods = new(StringComparer.Ordinal)
    {
        "Deserialize", "DeserializeAsync", "DeserializeObject", "ReadFromJsonAsync", "GetFromJsonAsync", "ReadAsAsync", "DeserializeAsyncEnumerable",
    };

    private static readonly HashSet<string> ElementPreserving = new(StringComparer.Ordinal)
    {
        "Where", "OrderBy", "OrderByDescending", "ThenBy", "ThenByDescending", "Skip", "Take", "SkipWhile", "TakeWhile", "Distinct", "DistinctBy",
        "ToList", "ToArray", "ToHashSet", "AsEnumerable", "AsReadOnly", "Reverse", "Concat", "Union", "Intersect", "Except", "Cast", "OfType", "ToImmutableList",
    };

    private static readonly HashSet<string> ElementSelecting = new(StringComparer.Ordinal)
    {
        "First", "FirstOrDefault", "Single", "SingleOrDefault", "Last", "LastOrDefault", "ElementAt", "ElementAtOrDefault", "Find", "GetValueOrDefault",
    };

    private static readonly HashSet<string> Projecting = new(StringComparer.Ordinal) { "Select", "SelectMany", "ConvertAll", "ToDictionary", "ToLookup", "GroupBy" };

    private static readonly HashSet<string> Aggregating = new(StringComparer.Ordinal)
    {
        "Count", "LongCount", "Sum", "Average", "Min", "Max", "Aggregate", "Any", "All", "Contains",
    };

    private static readonly HashSet<string> ValueTransforms = new(StringComparer.Ordinal)
    {
        "ToLower", "ToLowerInvariant", "ToUpper", "ToUpperInvariant", "Trim", "TrimStart", "TrimEnd", "Substring", "Replace", "PadLeft", "PadRight",
        "Round", "Floor", "Ceiling", "Truncate", "Abs", "Parse", "TryParse", "ToString", "AddDays", "AddHours", "AddMinutes", "AddSeconds", "Normalize", "Split", "Join", "Format",
    };

    private static readonly HashSet<string> CollectionAdders = new(StringComparer.Ordinal) { "Add", "TryAdd", "Enqueue", "Push", "Insert", "AddOrUpdate", "GetOrAdd", "Set", "AddRange" };

    private readonly Queue<Item> _queue = new();
    private readonly HashSet<string> _visited = new(StringComparer.Ordinal);

    public List<ProvenanceNode> Nodes { get; } = [];
    public TraceHooks Hooks { get; } = new();

    private sealed record Binding(Dictionary<string, (Item Caller, Expr Arg, bool ElementOf)> Parameters, (Item Caller, List<Token> Receiver)? Receiver);

    private sealed record Item(MemberFlow Member, List<Token> Expr, int Line, IReadOnlyList<string> Path, Binding? Bind, int Depth, int Parent, string? ExpectedType, string Purpose);

    /// <summary>Adds a root node for the failure and queues the expression to trace. Returns the root node id.</summary>
    public int Start(MemberFlow member, List<Token> expression, int line, IReadOnlyList<string> path, string title, string purpose = "value", int parent = -1)
    {
        var root = NewNode(member, NodeKinds.Failure, title, line, depth: 0, parent, Expr.Render(expression), path);
        _queue.Enqueue(new Item(member, expression, line, path, null, 1, root.Id, null, purpose));
        return root.Id;
    }

    public void Run()
    {
        while (_queue.Count > 0)
        {
            if (Nodes.Count >= ctx.Budget.MaxNodes)
            {
                ctx.Budget.Exhausted = true;
                break;
            }
            var item = _queue.Dequeue();
            if (item.Depth > ctx.Budget.MaxDepth)
            {
                ctx.Budget.Exhausted = true;
                continue;
            }
            try
            {
                Process(item);
            }
            catch (Exception ex) when (ex is ArgumentOutOfRangeException or IndexOutOfRangeException or InvalidOperationException)
            {
                // Unusual syntax: skip this branch.
            }
        }
    }

    // ------------------------------------------------------------------ core

    private void Enqueue(Item parent, MemberFlow member, List<Token> expr, int line, IReadOnlyList<string> path, Binding? bind, int parentNode, string? expectedType = null)
    {
        if (expr.Count == 0)
        {
            return;
        }
        var key = $"{member.Symbol.FullName}|{member.Symbol.StartLine}|{Expr.Render(expr, 400)}|{string.Join('.', path)}|{parent.Purpose}";
        if (!_visited.Add(key))
        {
            return;
        }
        _queue.Enqueue(new Item(member, expr, line, path, bind, parent.Depth + 1, parentNode, expectedType, parent.Purpose));
    }

    private ProvenanceNode NewNode(MemberFlow member, string kind, string title, int line, int depth, int parent, string? expression, IReadOnlyList<string> path,
        string confidence = "likely", string? origin = null)
    {
        var node = new ProvenanceNode
        {
            Id = Nodes.Count, ParentId = parent, Kind = kind, Title = title, Symbol = member.Symbol.FullName, File = member.Symbol.File, Line = line > 0 ? line : member.Symbol.StartLine,
            Depth = depth, Expression = expression, Path = path.Count == 0 ? null : string.Join('.', path), Confidence = confidence, Origin = origin,
        };
        Nodes.Add(node);
        ctx.Budget.NodesTraversed++;
        Hooks.Visited.Add(member.Symbol);
        return node;
    }

    private ProvenanceNode Add(Item item, string kind, string title, string confidence = "likely", string? origin = null, IReadOnlyList<string>? path = null)
        => NewNode(item.Member, kind, title, item.Line, item.Depth, item.Parent, Expr.Render(item.Expr), path ?? item.Path, confidence, origin);

    private void Process(Item item)
    {
        var t = FlowContext.Normalize(item.Expr);
        if (t.Count == 0)
        {
            return;
        }
        if (item.Expr.Count > 0 && item.Expr[^1].IsPunct('!') && item.Path.Count == 0)
        {
            var node = Add(item, NodeKinds.Transformation, $"null-forgiving '!' asserts `{Expr.Render(t)}` is not null", "definite");
            Hooks.NullForgiving.Add((node, item.Member, Expr.Render(t)));
            item = item with { Parent = node.Id };
        }

        // Alternatives: a ?? b, c ? a : b
        var coalesce = TopLevelIndexes(t, "?", pairWithNext: true);
        if (coalesce.Count > 0)
        {
            var node = Add(item, NodeKinds.Transformation, $"`{Expr.Render(t)}` falls back with ??", "definite");
            var start = 0;
            foreach (var index in coalesce)
            {
                Enqueue(item, item.Member, t.GetRange(start, index - start), item.Line, item.Path, item.Bind, node.Id, item.ExpectedType);
                start = index + 2;
            }
            if (start < t.Count && !t[start].Is("throw"))
            {
                Enqueue(item, item.Member, t.GetRange(start, t.Count - start), item.Line, item.Path, item.Bind, node.Id, item.ExpectedType);
            }
            return;
        }
        var question = TopLevelIndexes(t, "?", pairWithNext: false);
        var colon = TopLevelIndexes(t, ":", pairWithNext: false);
        if (question.Count > 0 && colon.Count > 0 && colon[0] > question[0])
        {
            var node = Add(item, NodeKinds.Transformation, $"conditional `{Expr.Render(t.GetRange(0, question[0]))}` selects a value", "definite");
            Enqueue(item, item.Member, t.GetRange(question[0] + 1, colon[0] - question[0] - 1), item.Line, item.Path, item.Bind, node.Id, item.ExpectedType);
            Enqueue(item, item.Member, t.GetRange(colon[0] + 1, t.Count - colon[0] - 1), item.Line, item.Path, item.Bind, node.Id, item.ExpectedType);
            return;
        }
        var arrow = TopLevelIndexes(t, "=>", pairWithNext: false);
        if (arrow.Count > 0)
        {
            Enqueue(item, item.Member, t.GetRange(arrow[0] + 1, t.Count - arrow[0] - 1), item.Line, item.Path, item.Bind, item.Parent, item.ExpectedType);
            return;
        }
        if (t.Count == 1 && t[0].Kind is TokenKind.Number or TokenKind.String or TokenKind.Char || t.Count == 1 && t[0].Text is "null" or "true" or "false" || t[0].Is("default"))
        {
            if (t[0].Kind == TokenKind.String && t[0].Text.Contains('{'))
            {
                Interpolation(item, t[0]);
                return;
            }
            var origin = t[0].Text == "null" ? "null-literal" : t[0].Is("default") ? "default" : "literal";
            Add(item, NodeKinds.Literal, $"literal `{Expr.Render(t)}` introduced here", "definite", origin);
            return;
        }
        if (t[0].Is("new"))
        {
            Construction(item, t);
            return;
        }
        var with = TopLevelIndexes(t, "with", pairWithNext: false);
        if (with.Count > 0 && with[0] + 1 < t.Count && t[with[0] + 1].IsPunct('{'))
        {
            WithExpression(item, t, with[0]);
            return;
        }
        var ops = BinaryOperators(t);
        if (ops.Count > 0)
        {
            var arithmetic = ops.Where(i => t[i].Text is "+" or "-" or "*" or "/" or "%").ToList();
            var kindText = arithmetic.Count > 0 ? "arithmetic" : "comparison";
            var node = Add(item, NodeKinds.Transformation, $"{kindText} `{Expr.Render(t)}`", "definite");
            if (arithmetic.Count > 0)
            {
                node.Notes.Add("arithmetic:" + string.Join("", arithmetic.Select(i => t[i].Text)));
            }
            var start = 0;
            foreach (var index in ops.Concat([t.Count]))
            {
                var operand = t.GetRange(start, index - start);
                if (operand.Count > 0 && !(operand.Count == 1 && operand[0].Kind == TokenKind.Number))
                {
                    Enqueue(item, item.Member, operand, item.Line, [], item.Bind, node.Id);
                }
                start = index + (index < t.Count && t[index].Text is "&" or "|" or "=" or "!" or "<" or ">" && index + 1 < t.Count && t[index + 1].Kind == TokenKind.Punct && t[index + 1].Text is "&" or "|" or "=" ? 2 : 1);
            }
            return;
        }
        if (t.Count == 1 && t[0].Kind == TokenKind.String)
        {
            Interpolation(item, t[0]);
            return;
        }

        var segments = Chain.Parse(t);
        if (segments.Count == 0 || segments[0].Kind == SegmentKind.Other)
        {
            Add(item, NodeKinds.Unknown, $"expression `{Expr.Render(t)}` is not traced further", "ambiguous");
            return;
        }
        var lastCall = segments.FindLastIndex(s => s.Kind == SegmentKind.Call);
        if (lastCall >= 0)
        {
            var rest = segments.Skip(lastCall + 1).Select(SegmentName).Concat(item.Path).ToList();
            var receiver = lastCall == 0 ? [] : TrimDots(t.GetRange(0, segments[lastCall].TokenStart));
            Call(item, receiver, segments[lastCall], rest, segments, lastCall);
            return;
        }
        var path = segments.Skip(1).Select(SegmentName).Concat(item.Path).ToList();
        // configuration["A:B"]
        if (segments.Count >= 2 && segments[1].Kind == SegmentKind.Index && IsConfigurationName(segments[0].Name)
            && segments[1].Args.FirstOrDefault()?.Tokens is [{ Kind: TokenKind.String } keyToken])
        {
            ConfigurationNode(item, keyToken.Text, null, path.Skip(1).ToList());
            return;
        }
        Identifier(item, segments[0].Name, path);
    }

    private static string SegmentName(Segment s) => s.Kind == SegmentKind.Index ? "[]" : s.Name;

    private void Interpolation(Item item, Token literal)
    {
        var holes = InterpolationHoles(literal.Text);
        if (holes.Count == 0)
        {
            Add(item, NodeKinds.Literal, "string literal", "definite", "literal");
            return;
        }
        var node = Add(item, NodeKinds.Transformation, "string built from interpolated values", "definite");
        foreach (var hole in holes.Take(6))
        {
            Enqueue(item, item.Member, hole, item.Line, [], item.Bind, node.Id);
        }
    }

    /// <summary>Tokens of each "{…}" expression in an interpolated string literal (format specifiers removed).</summary>
    public static List<List<Token>> InterpolationHoles(string text)
    {
        var holes = new List<List<Token>>();
        for (var i = 0; i < text.Length; i++)
        {
            if (text[i] != '{')
            {
                continue;
            }
            if (i + 1 < text.Length && text[i + 1] == '{')
            {
                i++;
                continue;
            }
            var depth = 0;
            var j = i;
            for (; j < text.Length; j++)
            {
                if (text[j] == '{')
                {
                    depth++;
                }
                else if (text[j] == '}' && --depth == 0)
                {
                    break;
                }
            }
            if (j >= text.Length)
            {
                break;
            }
            var inner = text[(i + 1)..j];
            var tokens = CSharpLexer.Tokenize(inner);
            // Drop ",alignment" and ":format" at depth 0.
            var cut = tokens.Count;
            var d = 0;
            for (var k = 0; k < tokens.Count; k++)
            {
                if (tokens[k].IsPunct('(') || tokens[k].IsPunct('['))
                {
                    d++;
                }
                else if (tokens[k].IsPunct(')') || tokens[k].IsPunct(']'))
                {
                    d--;
                }
                else if (d == 0 && (tokens[k].IsPunct(':') || tokens[k].IsPunct(',')) && !TokensHaveTernary(tokens, k))
                {
                    cut = k;
                    break;
                }
            }
            if (cut > 0)
            {
                holes.Add(tokens.GetRange(0, cut));
            }
            i = j;
        }
        return holes;
    }

    private static bool TokensHaveTernary(List<Token> tokens, int colon) => tokens.Take(colon).Any(t => t.IsPunct('?'));

    // ------------------------------------------------------------------ identifiers

    private void Identifier(Item item, string name, List<string> path)
    {
        var m = item.Member;
        if (name is "this" or "base")
        {
            if (path.Count > 0 && ctx.ContainingType(m.Symbol) is { } self)
            {
                MemberOfType(item, self, path[0], path.Skip(1).ToList());
            }
            else
            {
                Add(item, NodeKinds.Unknown, "the current instance", "ambiguous");
            }
            return;
        }
        if (item.Bind?.Parameters.TryGetValue(name, out var bound) == true)
        {
            var node = Add(item, NodeKinds.Argument, $"`{name}` is supplied by {ShortName(bound.Caller.Member.Symbol)} as `{bound.Arg.Text}`", "definite");
            var nextPath = bound.ElementOf ? new List<string> { "[]" }.Concat(path).ToList() : path;
            Enqueue(item, bound.Caller.Member, bound.Arg.Tokens, bound.Caller.Line, nextPath, bound.Caller.Bind, node.Id);
            return;
        }
        var locals = m.LocalsNamed(name).ToList();
        if (locals.Count > 0)
        {
            var node = Add(item, NodeKinds.Local, $"local `{name}`", locals.Count == 1 ? "definite" : "likely");
            foreach (var local in locals)
            {
                if (local.Init is null)
                {
                    continue;
                }
                if (local.OutArgument)
                {
                    Add(item with { Parent = node.Id, Depth = item.Depth + 1 }, NodeKinds.External, $"`{name}` is produced through an out argument of `{Expr.Render(local.Init.Tokens, 80)}`", "ambiguous");
                    continue;
                }
                var p = local.ElementOf ? new List<string> { "[]" }.Concat(path).ToList() : path;
                Enqueue(item, m, local.Init.Tokens, local.Line, p, item.Bind, node.Id, local.Type);
            }
            foreach (var reassign in m.Assignments.Where(a => a.TargetTokens.Count == 1 && a.TargetRoot == name))
            {
                if (reassign.Kind is AssignmentKinds.Compound or AssignmentKinds.Increment)
                {
                    Add(item with { Parent = node.Id, Depth = item.Depth + 1, Line = reassign.Line }, NodeKinds.Transformation, $"`{reassign.Target}` updated in place (line {reassign.Line})", "definite");
                }
                else
                {
                    Enqueue(item, m, reassign.Source.Tokens, reassign.Line, path, item.Bind, node.Id);
                }
            }
            return;
        }
        if (m.Parameter(name) is { } parameter)
        {
            var node = Add(item, NodeKinds.Parameter, $"parameter `{parameter.Type} {name}` of {ShortName(m.Symbol)}", "definite");
            if (IsOptionsType(parameter.Type) && path.Count > 0 && path[0] is "Value" or "CurrentValue")
            {
                ConfigurationNode(item with { Parent = node.Id }, null, FlowContext.GenericArgument(parameter.Type), path.Skip(1).ToList());
                return;
            }
            Callers(item, node, m.Parameters.IndexOf(parameter), name, path);
            return;
        }
        var lambda = LambdaSource(m, name, item.Line);
        if (lambda is { } source)
        {
            var node = Add(item, NodeKinds.Element, $"lambda parameter `{name}` iterates `{Expr.Render(source, 80)}`", "likely");
            Enqueue(item, m, source, item.Line, new List<string> { "[]" }.Concat(path).ToList(), item.Bind, node.Id);
            return;
        }
        if (ctx.ContainingType(m.Symbol) is { } type)
        {
            var primary = ctx.TypeFlowOf(type)?.PrimaryParameters.FirstOrDefault(p => p.Name == name);
            if (primary is not null)
            {
                if (IsOptionsType(primary.Type) && path.Count > 0 && path[0] is "Value" or "CurrentValue")
                {
                    var node = Add(item, NodeKinds.ConstructorParameter, $"{type.Name} receives `{primary.Type} {name}`", "definite");
                    ConfigurationNode(item with { Parent = node.Id }, null, FlowContext.GenericArgument(primary.Type), path.Skip(1).ToList());
                    return;
                }
                ConstructorParameter(item, type, name, primary.Type, path);
                return;
            }
            if (ctx.MembersNamed(type, name).Any(s => s.Kind is SymbolKinds.Field or SymbolKinds.Property or SymbolKinds.Event))
            {
                MemberOfType(item, type, name, path);
                return;
            }
        }
        var staticType = ctx.ResolveType(name, m.Symbol).FirstOrDefault();
        if (staticType is not null && path.Count > 0)
        {
            MemberOfType(item, staticType, path[0], path.Skip(1).ToList());
            return;
        }
        Add(item, NodeKinds.Unknown, $"could not resolve `{name}`", "ambiguous");
    }

    /// <summary>For "x" in "coll.Select(x => …)" returns the tokens of "coll".</summary>
    private static List<Token>? LambdaSource(MemberFlow m, string name, int line)
    {
        var body = m.Body;
        for (var i = 0; i + 1 < body.Count; i++)
        {
            if (body[i].Kind != TokenKind.Identifier || body[i].Text != name || !body[i + 1].Is("=>"))
            {
                continue;
            }
            // Find the call whose argument list contains this lambda.
            var depth = 0;
            for (var k = i - 1; k >= 0; k--)
            {
                if (body[k].IsPunct(')'))
                {
                    depth++;
                }
                else if (body[k].IsPunct('('))
                {
                    if (depth == 0)
                    {
                        if (k >= 2 && body[k - 1].Kind == TokenKind.Identifier && (body[k - 2].IsPunct('.') || body[k - 2].Is("?.")))
                        {
                            var receiver = ReceiverTokens(body, k - 2);
                            return receiver.Count > 0 ? receiver : null;
                        }
                        return null;
                    }
                    depth--;
                }
            }
        }
        return null;
    }

    private static List<Token> ReceiverTokens(List<Token> body, int dot)
    {
        var list = new List<Token>();
        var k = dot - 1;
        while (k >= 0)
        {
            var tok = body[k];
            if (tok.IsPunct(')'))
            {
                var open = FlowParser.MatchBack(body, k, '(', ')');
                list.InsertRange(0, body.GetRange(open, k - open + 1));
                k = open - 1;
                continue;
            }
            if (tok.IsPunct(']'))
            {
                var open = FlowParser.MatchBack(body, k, '[', ']');
                list.InsertRange(0, body.GetRange(open, k - open + 1));
                k = open - 1;
                continue;
            }
            if (tok.Kind == TokenKind.Identifier || tok.Is("this"))
            {
                list.Insert(0, tok);
                k--;
                if (k >= 0 && (body[k].IsPunct('.') || body[k].Is("?.")))
                {
                    list.Insert(0, body[k]);
                    k--;
                    continue;
                }
                break;
            }
            break;
        }
        return list;
    }

    private void Callers(Item item, ProvenanceNode paramNode, int index, string name, List<string> path)
    {
        var m = item.Member;
        var calleeName = m.Symbol.Kind == SymbolKinds.Constructor ? ctx.ContainingType(m.Symbol)?.Name ?? m.Symbol.Name : m.Symbol.Name;
        var callerSymbols = ctx.Index.CallersByName(calleeName).Concat(ctx.Index.UsersByName(calleeName)).Distinct().Take(ctx.Budget.MaxCallersPerParameter * 3).ToList();
        var sites = 0;
        foreach (var callerSymbol in callerSymbols)
        {
            var caller = ctx.Member(callerSymbol);
            if (caller is null)
            {
                continue;
            }
            foreach (var call in caller.Calls)
            {
                if (sites >= ctx.Budget.MaxCallersPerParameter)
                {
                    break;
                }
                var matchesCallee = m.Symbol.Kind == SymbolKinds.Constructor ? call.IsConstructor && call.ConstructedType == calleeName : !call.IsConstructor && call.Callee == calleeName;
                if (matchesCallee)
                {
                    if (!ReceiverCompatible(caller, call, m.Symbol))
                    {
                        continue;
                    }
                    var arg = ArgumentFor(call, index, name);
                    if (arg is null)
                    {
                        continue;
                    }
                    sites++;
                    var node = NewNode(caller, NodeKinds.Argument, $"{ShortName(caller.Symbol)} passes `{arg.Text}` as `{name}`", call.Line, item.Depth + 1, paramNode.Id, arg.Text, path);
                    Enqueue(item with { Depth = item.Depth + 1 }, caller, arg.Tokens, call.Line, path, null, node.Id);
                    continue;
                }
                // Method group: "records.Select(Mapper.Map)" passes each element as the parameter.
                if (call.Callee is "Select" or "SelectMany" or "ConvertAll" or "ForEach" or "ToDictionary" or "Where" or "All" or "Any"
                    && call.Args.Any(a => a.Tokens.Count > 0 && a.Tokens[^1].Text == calleeName && !a.Tokens.Any(x => x.IsPunct('('))))
                {
                    sites++;
                    var node = NewNode(caller, NodeKinds.Element, $"{ShortName(caller.Symbol)} passes each element of `{call.ReceiverText}` to {calleeName} via {call.Callee}", call.Line, item.Depth + 1, paramNode.Id, call.Whole.Text, path);
                    Enqueue(item with { Depth = item.Depth + 1 }, caller, call.Receiver, call.Line, new List<string> { "[]" }.Concat(path).ToList(), null, node.Id);
                }
            }
        }
        if (sites == 0)
        {
            Add(item with { Parent = paramNode.Id, Depth = item.Depth + 1 }, NodeKinds.Unknown, $"no callers of {calleeName} found (entry point, test input or dynamic invocation)", "ambiguous", "input");
        }
        else if (sites > 1)
        {
            paramNode.Confidence = "ambiguous";
            paramNode.Notes.Add($"{sites} call sites");
        }
    }

    private bool ReceiverCompatible(MemberFlow caller, FlowCall call, SymbolRecord target)
    {
        if (call.Receiver.Count == 0 || target.Container is null)
        {
            return true;
        }
        var type = ctx.ExpressionType(caller, call.Receiver, call.Line);
        if (type is null)
        {
            // Static call "Type.Member(...)".
            if (call.Receiver.Count == 1 && ctx.ResolveType(call.Receiver[0].Text, caller.Symbol).Count > 0)
            {
                return target.Container.EndsWith("." + call.Receiver[0].Text, StringComparison.Ordinal) || target.Container == call.Receiver[0].Text;
            }
            return true; // Unknown: keep (ambiguous).
        }
        var bare = FlowContext.BareName(type);
        var containerName = target.Container.Split('.')[^1];
        if (bare == containerName)
        {
            return true;
        }
        // Interface or base type of the target's container.
        var container = ctx.Index.Resolve(target.Container, "type").FirstOrDefault(t => t.FullName == target.Container);
        return container is null || container.Bases.Any(b => CodeIndex.StripGeneric(b) == bare) || ctx.Index.AllDerived(bare, 3).Any(d => d.Type.FullName == target.Container)
               || ctx.ResolveType(bare, caller.Symbol).Count == 0;
    }

    private static Expr? ArgumentFor(FlowCall call, int index, string name)
    {
        var named = call.ArgNames.IndexOf(name);
        if (named >= 0)
        {
            return call.Args[named];
        }
        return index >= 0 && index < call.Args.Count && call.ArgNames[index] is null ? call.Args[index] : null;
    }

    private void ConstructorParameter(Item item, SymbolRecord type, string name, string parameterType, List<string> path)
    {
        var node = Add(item, NodeKinds.ConstructorParameter, $"{type.Name} captures `{parameterType} {name}` from its constructor", "definite");
        Hooks.Captured.Add(new CapturedDependency(node, type, name, parameterType));
        var index = ctx.TypeFlowOf(type)?.PrimaryParameters.FindIndex(p => p.Name == name) ?? -1;

        // Explicit construction sites.
        var sites = 0;
        foreach (var user in ctx.Index.CallersByName(type.Name).Concat(ctx.Index.UsersByName(type.Name)).Distinct().Take(20))
        {
            var flow = ctx.Member(user);
            foreach (var call in flow?.Calls.Where(c => c.IsConstructor && c.ConstructedType == type.Name) ?? [])
            {
                var arg = ArgumentFor(call, index, name);
                if (arg is null || sites >= ctx.Budget.MaxCallersPerParameter)
                {
                    continue;
                }
                sites++;
                var argNode = NewNode(flow!, NodeKinds.Argument, $"{ShortName(user)} constructs {type.Name} with `{arg.Text}`", call.Line, item.Depth + 1, node.Id, arg.Text, path);
                Enqueue(item with { Depth = item.Depth + 1 }, flow!, arg.Tokens, call.Line, path, null, argNode.Id);
            }
        }

        // Dependency injection.
        foreach (var registration in ctx.Index.Registrations.Where(r => r.ImplementationType == type.Name || r.ServiceType == type.Name).Take(4))
        {
            var dependency = ctx.Index.Registrations.Where(r => r.ServiceType == FlowContext.BareName(parameterType)).ToList();
            var lifetimes = dependency.Count == 0 ? "not registered here" : string.Join("/", dependency.Select(d => d.Lifetime).Distinct());
            var di = NewNode(item.Member, NodeKinds.DependencyInjection,
                $"DI: {registration.Lifetime} {registration.ServiceType} → {registration.ImplementationType} ({registration.File}:{registration.Line}); `{parameterType}` is {lifetimes}",
                item.Line, item.Depth + 1, node.Id, null, path, "definite", "di");
            di.File = registration.File;
            di.Line = registration.Line;
            di.Notes.Add($"registration-owner:{registration.Owner}");
        }
        if (sites == 0 && !ctx.Index.Registrations.Any(r => r.ImplementationType == type.Name || r.ServiceType == type.Name))
        {
            node.Notes.Add("no construction site or registration found");
        }
    }

    private void MemberOfType(Item item, SymbolRecord type, string memberName, List<string> rest)
    {
        var members = ctx.MembersNamed(type, memberName).Where(s => s.Kind is SymbolKinds.Field or SymbolKinds.Property or SymbolKinds.Event).ToList();
        if (members.Count == 0)
        {
            Add(item, NodeKinds.Unknown, $"`{type.Name}.{memberName}` not found in the index", "ambiguous");
            return;
        }
        var symbol = members[0];
        var node = Add(item, NodeKinds.Field, $"{symbol.Kind} `{type.Name}.{memberName}` ({symbol.ReturnType ?? "?"})", "definite");
        if (IsKeyedCollection(symbol.ReturnType) || memberName.Contains("cache", StringComparison.OrdinalIgnoreCase))
        {
            Hooks.KeyedState.Add(new KeyedStateSite(node, type, memberName));
        }
        var writers = 0;
        foreach (var declaring in ctx.Index.MembersOf(ctx.ContainingType(symbol)?.FullName ?? type.FullName).Take(80))
        {
            var flow = ctx.Member(declaring);
            if (flow is null)
            {
                continue;
            }
            foreach (var a in flow.Assignments)
            {
                if (a.TargetMember != memberName && !(a.Kind == AssignmentKinds.FieldInit && declaring == symbol))
                {
                    continue;
                }
                var direct = a.TargetTokens.Count == 1 || a.TargetRoot == "this" && a.TargetTokens.Count == 3;
                var elementWrite = a.TargetTokens.Count > 1 && a.TargetTokens[0].Text == memberName && a.TargetTokens[^1].IsPunct(']');
                if (a.Kind == AssignmentKinds.FieldInit && declaring == symbol || direct)
                {
                    writers++;
                    if (a.Kind is AssignmentKinds.Compound or AssignmentKinds.Increment)
                    {
                        NewNode(flow, NodeKinds.Transformation, $"{ShortName(declaring)} updates `{a.Target}` in place", a.Line, item.Depth + 1, node.Id, a.Target, rest, "definite");
                        continue;
                    }
                    var w = NewNode(flow, NodeKinds.Write, $"{ShortName(declaring)} assigns `{a.Target} = {a.Source.Text}`", a.Line, item.Depth + 1, node.Id, a.Source.Text, rest, "likely");
                    Enqueue(item with { Depth = item.Depth + 1 }, flow, a.Source.Tokens, a.Line, rest, null, w.Id, symbol.ReturnType);
                }
                else if (elementWrite && rest.Count > 0 && rest[0] == "[]")
                {
                    writers++;
                    var w = NewNode(flow, NodeKinds.Write, $"{ShortName(declaring)} stores `{a.Source.Text}` into `{a.Target}`", a.Line, item.Depth + 1, node.Id, a.Source.Text, rest, "likely");
                    Enqueue(item with { Depth = item.Depth + 1 }, flow, a.Source.Tokens, a.Line, rest.Skip(1).ToList(), null, w.Id);
                }
            }
            foreach (var call in flow.Calls.Where(c => CollectionAdders.Contains(c.Callee) && c.Receiver.Count > 0 && (c.ReceiverText == memberName || c.ReceiverText == "this." + memberName)))
            {
                if (call.Args.Count == 0)
                {
                    continue;
                }
                writers++;
                var value = call.Args[^1];
                var arrowIndex = value.Tokens.FindIndex(x => x.Is("=>"));
                var valueTokens = arrowIndex >= 0 ? value.Tokens.Skip(arrowIndex + 1).ToList() : value.Tokens;
                var w = NewNode(flow, NodeKinds.Write, $"{ShortName(declaring)} adds `{Expr.Render(valueTokens, 80)}` to `{memberName}` ({call.Callee})", call.Line, item.Depth + 1, node.Id, call.Whole.Text, rest, "likely");
                var elementRest = rest.Count > 0 && rest[0] == "[]" ? rest.Skip(1).ToList() : rest;
                Enqueue(item with { Depth = item.Depth + 1 }, flow, valueTokens, call.Line, elementRest, null, w.Id);
            }
        }
        if (writers == 0 && symbol.Kind == SymbolKinds.Property && ctx.Member(symbol) is { Returns.Count: > 0 } getter)
        {
            foreach (var r in getter.Returns)
            {
                Enqueue(item, getter, r.Tokens, r.Line, rest, item.Bind, node.Id, symbol.ReturnType);
            }
            return;
        }
        if (writers == 0)
        {
            // Set from outside the type (object initializers / constructors elsewhere).
            PropertyProducers(item with { Parent = node.Id }, type, memberName, rest);
        }
    }

    /// <summary>Finds constructions of <paramref name="type"/> elsewhere and how they set (or omit) <paramref name="property"/>.</summary>
    private void PropertyProducers(Item item, SymbolRecord type, string property, List<string> rest)
    {
        var found = 0;
        foreach (var user in ctx.Index.UsersByName(type.Name).Concat(ctx.Index.CallersByName(type.Name)).Distinct().Where(u => !u.IsTest).Take(20))
        {
            var flow = ctx.Member(user);
            foreach (var call in flow?.Calls.Where(c => c.IsConstructor && (c.ConstructedType == type.Name || c.Callee == "new()" && FlowContext.BareName(user.ReturnType ?? "") == type.Name)) ?? [])
            {
                found++;
                Enqueue(item, flow!, call.Whole.Tokens, call.Line, new List<string> { property }.Concat(rest).ToList(), null, item.Parent, type.Name);
            }
        }
        if (found == 0)
        {
            Add(item, NodeKinds.Unknown, $"no writer of {type.Name}.{property} found", "ambiguous");
        }
    }

    // ------------------------------------------------------------------ calls

    private void Call(Item item, List<Token> receiver, Segment call, List<string> rest, List<Segment> segments, int callIndex)
    {
        var m = item.Member;
        var name = call.Name;
        var receiverText = Expr.Render(receiver);
        // An application method that happens to be named Deserialize (a serializer wrapper) is followed into its body;
        // only framework/package deserializers are input boundaries.
        if (DeserializeMethods.Contains(name)
            && ctx.ResolveCall(m, new FlowCall { Callee = name, Receiver = receiver, Args = call.Args, TypeArgs = call.TypeArgs, Line = item.Line }) is { Targets.Count: > 0, Ambiguous: false } wrapper)
        {
            SourceCall(item, receiver, call, rest, wrapper.Targets, false);
            return;
        }
        if (DeserializeMethods.Contains(name))
        {
            var type = call.TypeArgs.FirstOrDefault() ?? item.ExpectedType;
            var options = call.Args.Count > 1 ? call.Args[1].Text : null;
            var node = Add(item, NodeKinds.Deserialization, $"deserialized from JSON as `{type ?? "?"}`{(options is null ? " with default options" : $" with options `{options}`")}", "definite", "deserialization", rest);
            Hooks.Deserializations.Add(new DeserializationSite(node, m, type, options, rest));
            return;
        }
        if (name is "GetValue" or "GetSection" or "GetRequiredSection" or "GetConnectionString" && (IsConfigurationName(receiverText) || receiverText.Contains("Section", StringComparison.Ordinal)))
        {
            var key = call.Args.FirstOrDefault()?.Tokens is [{ Kind: TokenKind.String } k] ? k.Text : call.Args.FirstOrDefault()?.Text;
            ConfigurationNode(item, name == "GetConnectionString" ? "ConnectionStrings:" + key : key, null, rest);
            return;
        }
        if (name is "Get" or "Bind" && receiver.Count > 0 && Expr.Render(receiver).Contains("GetSection", StringComparison.Ordinal))
        {
            var inner = Chain.Parse(receiver).LastOrDefault(s => s.Kind == SegmentKind.Call && s.Name is "GetSection" or "GetRequiredSection");
            var key = inner?.Args.FirstOrDefault()?.Tokens is [{ Kind: TokenKind.String } k] ? k.Text : inner?.Args.FirstOrDefault()?.Text;
            ConfigurationNode(item, key, call.TypeArgs.FirstOrDefault(), rest);
            return;
        }
        if (name == "GetEnvironmentVariable")
        {
            ConfigurationNode(item, "env:" + call.Args.FirstOrDefault()?.Text, null, rest);
            return;
        }
        if (name is "GetRequiredService" or "GetService" or "GetRequiredKeyedService" && call.TypeArgs.Count > 0)
        {
            var service = FlowContext.BareName(call.TypeArgs[0]);
            var registrations = ctx.Index.Registrations.Where(r => r.ServiceType == service).ToList();
            var node = Add(item, NodeKinds.DependencyInjection,
                $"resolved from DI: {service}{(registrations.Count == 0 ? " (no registration found)" : " → " + string.Join(", ", registrations.Select(r => $"{r.Lifetime} {r.ImplementationType}")))}", "definite", rest.Count == 0 ? "di" : null, rest);
            if (rest.Count > 0)
            {
                var implName = registrations.LastOrDefault()?.ImplementationType is { } impl && !impl.StartsWith('(') ? impl : service;
                if (ctx.ResolveType(implName, m.Symbol).FirstOrDefault() is { } implType)
                {
                    MemberOfType(item with { Parent = node.Id, Depth = item.Depth + 1 }, implType, rest[0], rest.Skip(1).ToList());
                }
            }
            return;
        }
        if (name is "ReadAllText" or "ReadAllLines" or "ReadAllBytes" or "OpenRead" or "ReadToEnd" or "ReadToEndAsync" or "ReadLine" or "ReadLineAsync" or "ReadAsStringAsync" or "ReadAsStreamAsync")
        {
            Add(item, NodeKinds.Input, $"external input read by `{receiverText}.{name}({string.Join(", ", call.Args.Select(a => a.Text))})`", "definite", "input", rest);
            return;
        }
        if ((receiver.Count > 0 || name == "WhenAll") && (ElementPreserving.Contains(name) || ElementSelecting.Contains(name) || Projecting.Contains(name) || Aggregating.Contains(name) || name == "WhenAll"))
        {
            if (ctx.ResolveCall(m, new FlowCall { Callee = name, Receiver = receiver, Args = call.Args, Line = item.Line }).Targets is { Count: > 0 } sourceTargets
                && ctx.ExpressionType(m, receiver, item.Line) is { } rt && ctx.ResolveType(rt, m.Symbol).Count > 0)
            {
                SourceCall(item, receiver, call, rest, sourceTargets, false);
                return;
            }
            Sequence(item, receiver, call, rest);
            return;
        }

        var flowCall = new FlowCall { Callee = name, Receiver = receiver, Args = call.Args, TypeArgs = call.TypeArgs, Line = item.Line };
        var (targets, ambiguous) = ctx.ResolveCall(m, flowCall);
        if (targets.Count > 0)
        {
            SourceCall(item, receiver, call, rest, targets, ambiguous);
            return;
        }
        // Outside the repository (framework or package).
        if (receiver.Count > 0 && ValueTransforms.Contains(name))
        {
            var node = Add(item, NodeKinds.Transformation, $"`{receiverText}` is transformed by {name}()", "definite", path: rest);
            Enqueue(item, m, receiver, item.Line, [], item.Bind, node.Id);
            return;
        }
        if (receiver.Count > 0 && name is "TryGetValue" or "GetValueOrDefault" or "GetOrAdd" or "ElementAt" or "Peek" or "Dequeue" or "Pop" or "TryDequeue" or "TryPeek" or "TryRemove")
        {
            var node = Add(item, NodeKinds.Element, $"element read from `{receiverText}` via {name}", "likely", path: rest);
            Enqueue(item, m, receiver, item.Line, new List<string> { "[]" }.Concat(rest).ToList(), item.Bind, node.Id);
            return;
        }
        var external = Add(item, NodeKinds.External, $"`{(receiver.Count > 0 ? receiverText + "." : "")}{name}(…)` is outside the repository", "ambiguous", path: rest);
        if (rest.Count == 0)
        {
            foreach (var arg in call.Args.Take(3))
            {
                Enqueue(item, m, arg.Tokens, item.Line, [], item.Bind, external.Id);
            }
        }
        else if (ctx.ExpressionType(m, receiver.Count == 0 ? [] : receiver, item.Line) is { } receiverType && ctx.ResolveType(receiverType, m.Symbol).FirstOrDefault() is { } rtSym)
        {
            PropertyProducers(item with { Parent = external.Id }, rtSym, rest[0], rest.Skip(1).ToList());
        }
    }

    private void SourceCall(Item item, List<Token> receiver, Segment call, List<string> rest, List<SymbolRecord> targets, bool ambiguous)
    {
        var m = item.Member;
        var node = Add(item, NodeKinds.Return, $"value returned by {string.Join(" / ", targets.Take(3).Select(ShortName))}{(ambiguous ? " (ambiguous target)" : "")}", ambiguous ? "ambiguous" : "definite", path: rest);
        if (ambiguous)
        {
            node.Notes.Add("candidates: " + string.Join(", ", targets.Take(6).Select(t => t.FullName)));
        }
        foreach (var target in targets.Take(4))
        {
            var flow = ctx.Member(target);
            if (flow is null)
            {
                continue;
            }
            if (target.Kind is SymbolKinds.Property or SymbolKinds.Field)
            {
                continue;
            }
            var parameters = new Dictionary<string, (Item, Expr, bool)>(StringComparer.Ordinal);
            for (var i = 0; i < flow.Parameters.Count; i++)
            {
                var arg = ArgumentFor(new FlowCall { Args = call.Args, ArgNames = call.Args.Select(_ => (string?)null).ToList() }, i, flow.Parameters[i].Name);
                if (arg is not null)
                {
                    parameters[flow.Parameters[i].Name] = (item, arg, false);
                }
            }
            var binding = new Binding(parameters, receiver.Count > 0 ? (item, receiver) : null);
            if (flow.Returns.Count == 0)
            {
                NewNode(flow, NodeKinds.Unknown, $"{ShortName(target)} has no return expression (void, abstract or interface member)", target.StartLine, item.Depth + 1, node.Id, null, rest, "ambiguous");
                continue;
            }
            foreach (var r in flow.Returns)
            {
                Enqueue(item, flow, r.Tokens, r.Line, rest, binding, node.Id, FlowContext.UnwrapTask(target.ReturnType));
            }
        }
    }

    private void Sequence(Item item, List<Token> receiver, Segment call, List<string> rest)
    {
        var m = item.Member;
        var name = call.Name;
        var node = Add(item, NodeKinds.Transformation, $"`{Expr.Render(receiver, 60)}` → {name}({string.Join(", ", call.Args.Select(a => a.Text)).Truncate(80)})", "definite", path: rest);

        // Methods invoked inside the arguments transform or filter the sequence.
        foreach (var arg in call.Args)
        {
            foreach (var inner in InnerCalls(arg.Tokens))
            {
                var (targets, ambiguous) = ctx.ResolveCall(m, inner);
                foreach (var target in targets.Where(t => !t.IsTest).Take(2))
                {
                    var kind = name is "Where" or "First" or "FirstOrDefault" or "Single" or "SingleOrDefault" or "Any" or "All" or "Count" or "SkipWhile" or "TakeWhile" or "Find"
                        ? NodeKinds.Filter : NodeKinds.Transformation;
                    var flow = ctx.Member(target);
                    var t = NewNode(flow ?? m, kind, $"{ShortName(target)} is applied by {name}(…) in {ShortName(m.Symbol)}", flow is null ? item.Line : target.StartLine, item.Depth + 1, node.Id,
                        inner.Whole.Text, rest, ambiguous ? "ambiguous" : "likely");
                    t.Notes.Add("operator:" + name);
                    if (name is "Skip" or "Take" or "ElementAt" && flow is not null)
                    {
                        // Count arguments are values: trace them.
                        Enqueue(item, m, inner.Whole.Tokens, item.Line, [], item.Bind, t.Id);
                    }
                }
            }
            // Method group projection: Select(Mapper.Map)
            if (Projecting.Contains(name) && arg.Tokens.Count > 0 && !arg.Tokens.Any(x => x.IsPunct('(') || x.Is("=>")))
            {
                var group = arg.Tokens;
                var groupName = group[^1].Text;
                var ownerTypeName = group.Count >= 3 ? group[^3].Text : null;
                var targets = ownerTypeName is not null && ctx.ResolveType(ownerTypeName, m.Symbol).FirstOrDefault() is { } ownerType
                    ? ctx.MembersNamed(ownerType, groupName).Where(s => s.Kind == SymbolKinds.Method).ToList()
                    : ctx.ContainingType(m.Symbol) is { } ct ? ctx.MembersNamed(ct, groupName).Where(s => s.Kind == SymbolKinds.Method).ToList() : [];
                foreach (var target in targets.Take(2))
                {
                    var flow = ctx.Member(target);
                    if (flow is null)
                    {
                        continue;
                    }
                    var projection = NewNode(flow, NodeKinds.Transformation, $"each element is mapped by {ShortName(target)}", target.StartLine, item.Depth + 1, node.Id, Expr.Render(group), rest, "definite");
                    var binding = flow.Parameters.Count > 0
                        ? new Binding(new Dictionary<string, (Item, Expr, bool)> { [flow.Parameters[0].Name] = (item, new Expr(receiver, item.Line), true) }, null)
                        : null;
                    var elementRest = rest.Count > 0 && rest[0] == "[]" ? rest.Skip(1).ToList() : rest;
                    foreach (var r in flow.Returns)
                    {
                        Enqueue(item, flow, r.Tokens, r.Line, elementRest, binding, projection.Id, FlowContext.UnwrapTask(target.ReturnType));
                    }
                }
                if (targets.Count > 0)
                {
                    return;
                }
            }
        }

        if (name == "WhenAll" && call.Args.Count > 0)
        {
            Enqueue(item, m, call.Args[0].Tokens, item.Line, rest, item.Bind, node.Id);
            return;
        }
        if (ElementSelecting.Contains(name))
        {
            Enqueue(item, m, receiver, item.Line, new List<string> { "[]" }.Concat(rest).ToList(), item.Bind, node.Id);
            return;
        }
        if (Projecting.Contains(name))
        {
            var lambda = call.Args.LastOrDefault(a => a.Tokens.Any(x => x.Is("=>")));
            if (lambda is not null && name != "ToDictionary" || name == "ToDictionary" && call.Args.Count >= 2 && lambda is not null)
            {
                var arrowIndex = lambda!.Tokens.FindIndex(x => x.Is("=>"));
                var body = lambda.Tokens.Skip(arrowIndex + 1).ToList();
                var elementRest = rest.Count > 0 && rest[0] == "[]" ? rest.Skip(1).ToList() : rest;
                Enqueue(item, m, body, item.Line, elementRest, item.Bind, node.Id);
                return;
            }
            Enqueue(item, m, receiver, item.Line, rest, item.Bind, node.Id);
            return;
        }
        if (Aggregating.Contains(name))
        {
            node.Notes.Add("aggregate");
            Enqueue(item, m, receiver, item.Line, ["[]"], item.Bind, node.Id);
            foreach (var lambda in call.Args.Where(a => a.Tokens.Any(x => x.Is("=>"))))
            {
                var arrowIndex = lambda.Tokens.FindIndex(x => x.Is("=>"));
                Enqueue(item, m, lambda.Tokens.Skip(arrowIndex + 1).ToList(), item.Line, [], item.Bind, node.Id);
            }
            return;
        }
        Enqueue(item, m, receiver, item.Line, rest, item.Bind, node.Id);
    }

    /// <summary>Calls inside an argument expression (including lambda bodies).</summary>
    private static List<FlowCall> InnerCalls(List<Token> tokens)
    {
        var calls = new List<FlowCall>();
        for (var i = 0; i + 1 < tokens.Count; i++)
        {
            if (tokens[i].Kind != TokenKind.Identifier || !tokens[i + 1].IsPunct('(') || i > 0 && tokens[i - 1].Is("new"))
            {
                continue;
            }
            var close = FlowParser.Match(tokens, i + 1, '(', ')');
            var (args, names, outs) = FlowParser.SplitArguments(tokens, i + 1, close);
            var receiver = i >= 2 && (tokens[i - 1].IsPunct('.') || tokens[i - 1].Is("?.")) ? ReceiverTokens(tokens, i - 1) : [];
            var start = i - (receiver.Count > 0 ? receiver.Count + 1 : 0);
            calls.Add(new FlowCall
            {
                Callee = tokens[i].Text, Receiver = receiver, Args = args, ArgNames = names, ArgIsOut = outs, Line = tokens[i].Line,
                Whole = FlowParser.Sub(tokens, Math.Max(0, start), close + 1),
            });
        }
        return calls;
    }

    // ------------------------------------------------------------------ construction

    private void Construction(Item item, List<Token> t)
    {
        var m = item.Member;
        string? typeName = null;
        var k = 1;
        while (k < t.Count && (t[k].Kind == TokenKind.Identifier || t[k].IsPunct('.')))
        {
            if (t[k].Kind == TokenKind.Identifier)
            {
                typeName = t[k].Text;
            }
            k++;
        }
        if (k < t.Count && t[k].IsPunct('<'))
        {
            k = FlowParser.Match(t, k, '<', '>') + 1;
        }
        typeName ??= item.ExpectedType is { } expected ? FlowContext.BareName(expected) : null;
        var args = new List<Expr>();
        var argNames = new List<string?>();
        if (k < t.Count && t[k].IsPunct('('))
        {
            var close = FlowParser.Match(t, k, '(', ')');
            (args, argNames, _) = FlowParser.SplitArguments(t, k, close);
            k = close + 1;
        }
        var initializer = new Dictionary<string, List<Token>>(StringComparer.Ordinal);
        if (k < t.Count && t[k].IsPunct('{'))
        {
            var close = FlowParser.Match(t, k, '{', '}');
            var (entries, _, _) = FlowParser.SplitArguments(ReplaceBraces(t, k, close), k, close);
            foreach (var entry in entries)
            {
                var eq = entry.Tokens.FindIndex(x => x.IsPunct('='));
                if (eq == 1 && entry.Tokens[0].Kind == TokenKind.Identifier)
                {
                    initializer[entry.Tokens[0].Text] = entry.Tokens.Skip(2).ToList();
                }
            }
        }
        var display = typeName ?? "?";
        if (item.Path.Count == 0 || item.Path[0] == "[]")
        {
            Add(item, NodeKinds.Construction, $"new {display}(…) created in {ShortName(m.Symbol)}", "definite", item.Purpose == "instance" ? "constructed" : null);
            return;
        }
        var property = item.Path[0];
        var rest = item.Path.Skip(1).ToList();
        if (initializer.TryGetValue(property, out var value))
        {
            var node = Add(item, NodeKinds.Initializer, $"{display}.{property} is set to `{Expr.Render(value)}` in {ShortName(m.Symbol)}", "definite");
            Enqueue(item, m, value, item.Line, rest, item.Bind, node.Id, PropertyType(typeName, property, m));
            return;
        }
        var type = typeName is null ? null : ctx.ResolveType(typeName, m.Symbol).FirstOrDefault();
        if (type is not null)
        {
            var primary = ctx.TypeFlowOf(type)?.PrimaryParameters;
            var index = primary?.FindIndex(p => string.Equals(p.Name, property, StringComparison.OrdinalIgnoreCase)) ?? -1;
            if (index >= 0)
            {
                var arg = argNames.IndexOf(primary![index].Name) is var named && named >= 0 ? args[named] : index < args.Count ? args[index] : null;
                if (arg is not null)
                {
                    var node = Add(item, NodeKinds.Initializer, $"{display}({primary[index].Name}: `{arg.Text}`) in {ShortName(m.Symbol)}", "definite");
                    Enqueue(item, m, arg.Tokens, item.Line, rest, item.Bind, node.Id, primary[index].Type);
                    return;
                }
            }
            // Explicit constructors: "Property = parameter".
            foreach (var ctor in ctx.Index.MembersOf(type.FullName).Where(s => s.Kind == SymbolKinds.Constructor && s.ParameterTypes.Count == args.Count))
            {
                var flow = ctx.Member(ctor);
                var assignment = flow?.Assignments.FirstOrDefault(a => a.TargetMember == property && a.Source.Tokens.Count == 1);
                var paramIndex = assignment is null ? -1 : flow!.Parameters.FindIndex(p => p.Name == assignment.Source.Tokens[0].Text);
                if (paramIndex >= 0 && paramIndex < args.Count)
                {
                    var node = Add(item, NodeKinds.Initializer, $"{display} constructor assigns {property} from argument `{args[paramIndex].Text}`", "likely");
                    Enqueue(item, m, args[paramIndex].Tokens, item.Line, rest, item.Bind, node.Id);
                    return;
                }
            }
            var propertySymbol = ctx.MembersNamed(type, property).FirstOrDefault(s => s.Kind is SymbolKinds.Property or SymbolKinds.Field);
            if (propertySymbol is not null)
            {
                var defaultValue = ctx.Member(propertySymbol)?.Assignments.FirstOrDefault(a => a.Kind == AssignmentKinds.FieldInit)?.Source.Text;
                var nullable = FlowContext.IsNullableDeclared(propertySymbol.ReturnType);
                var omitted = Add(item, NodeKinds.Omission,
                    $"{display} is constructed in {ShortName(m.Symbol)} without setting {property} — it keeps {(defaultValue is null ? nullable ? "null" : "its default value" : $"its initializer `{defaultValue}`")}",
                    "definite", defaultValue is null ? nullable ? "null-omission" : "default-omission" : "initializer-default");
                Hooks.Omissions.Add((omitted, display, property));
                return;
            }
        }
        Add(item, NodeKinds.Unknown, $"cannot see how new {display}(…) sets {property}", "ambiguous");
    }

    private void WithExpression(Item item, List<Token> t, int withIndex)
    {
        var close = FlowParser.Match(t, withIndex + 1, '{', '}');
        var (entries, _, _) = FlowParser.SplitArguments(ReplaceBraces(t, withIndex + 1, close), withIndex + 1, close);
        if (item.Path.Count > 0)
        {
            foreach (var entry in entries)
            {
                if (entry.Tokens.Count > 2 && entry.Tokens[0].Text == item.Path[0] && entry.Tokens[1].IsPunct('='))
                {
                    var node = Add(item, NodeKinds.Initializer, $"`with` sets {item.Path[0]} to `{Expr.Render(entry.Tokens.Skip(2).ToList())}`", "definite");
                    Enqueue(item, item.Member, entry.Tokens.Skip(2).ToList(), item.Line, item.Path.Skip(1).ToList(), item.Bind, node.Id);
                    return;
                }
            }
        }
        Enqueue(item, item.Member, t.GetRange(0, withIndex), item.Line, item.Path, item.Bind, item.Parent);
    }

    private string? PropertyType(string? typeName, string property, MemberFlow context)
    {
        var type = typeName is null ? null : ctx.ResolveType(typeName, context.Symbol).FirstOrDefault();
        return type is null ? null : ctx.MembersNamed(type, property).FirstOrDefault()?.ReturnType;
    }

    private void ConfigurationNode(Item item, string? key, string? optionsType, List<string> rest)
    {
        var title = key is not null
            ? $"configuration value `{key}`{(rest.Count > 0 ? "." + string.Join('.', rest) : "")}"
            : $"options `{optionsType}`{(rest.Count > 0 ? "." + string.Join('.', rest) : "")} bound from configuration";
        var node = Add(item, NodeKinds.Configuration, title, "definite", "configuration", rest);
        Hooks.Configurations.Add(new ConfigurationSite(node, item.Member, key, optionsType, rest));
    }

    // ------------------------------------------------------------------ helpers

    public static bool IsOptionsType(string? type) => type is not null && FlowContext.BareName(type) is "IOptions" or "IOptionsMonitor" or "IOptionsSnapshot";

    public static bool IsConfigurationName(string text)
        => text.Contains("onfig", StringComparison.Ordinal) || text.Contains("Settings", StringComparison.Ordinal) || text.EndsWith("section", StringComparison.OrdinalIgnoreCase);

    public static bool IsKeyedCollection(string? type)
        => type is not null && FlowContext.BareName(type) is "Dictionary" or "ConcurrentDictionary" or "IDictionary" or "IReadOnlyDictionary" or "MemoryCache" or "IMemoryCache" or "Hashtable" or "SortedDictionary";

    public static string ShortName(SymbolRecord s)
    {
        var parts = s.FullName.Split('.');
        return parts.Length >= 2 ? parts[^2] + "." + parts[^1] : s.FullName;
    }

    private static List<Token> TrimDots(List<Token> tokens)
    {
        var list = tokens.ToList();
        while (list.Count > 0 && (list[^1].IsPunct('.') || list[^1].Is("?.")))
        {
            list.RemoveAt(list.Count - 1);
        }
        return list;
    }

    /// <summary>Copy of tokens where the braces at [open, close] become parentheses (so argument splitting works).</summary>
    private static List<Token> ReplaceBraces(List<Token> t, int open, int close)
    {
        var copy = t.ToList();
        copy[open] = new Token(TokenKind.Punct, "(", t[open].Line);
        copy[close] = new Token(TokenKind.Punct, ")", t[close].Line);
        return copy;
    }

    /// <summary>Indexes of a punctuation token at depth 0 ("?" with pairWithNext finds "??").</summary>
    private static List<int> TopLevelIndexes(List<Token> t, string text, bool pairWithNext)
    {
        var list = new List<int>();
        var depth = 0;
        for (var i = 0; i < t.Count; i++)
        {
            var tok = t[i];
            if (tok.IsPunct('(') || tok.IsPunct('[') || tok.IsPunct('{'))
            {
                depth++;
                continue;
            }
            if (tok.IsPunct(')') || tok.IsPunct(']') || tok.IsPunct('}'))
            {
                depth--;
                continue;
            }
            if (depth != 0 || tok.Text != text || tok.Kind == TokenKind.String)
            {
                continue;
            }
            if (text == "?")
            {
                var isPair = i + 1 < t.Count && t[i + 1].IsPunct('?');
                var prevIsPair = i > 0 && t[i - 1].IsPunct('?');
                if (pairWithNext)
                {
                    if (isPair)
                    {
                        list.Add(i);
                        i++;
                    }
                    continue;
                }
                if (isPair || prevIsPair || i + 1 < t.Count && (t[i + 1].IsPunct('.') || t[i + 1].IsPunct('[')))
                {
                    if (isPair)
                    {
                        i++;
                    }
                    continue;
                }
                list.Add(i);
                continue;
            }
            list.Add(i);
        }
        return list;
    }

    /// <summary>Depth-0 binary operator indexes (arithmetic, comparison, logical).</summary>
    private static List<int> BinaryOperators(List<Token> t)
    {
        var list = new List<int>();
        var depth = 0;
        for (var i = 1; i < t.Count - 1; i++)
        {
            var tok = t[i];
            if (tok.IsPunct('(') || tok.IsPunct('[') || tok.IsPunct('{'))
            {
                depth++;
                continue;
            }
            if (tok.IsPunct(')') || tok.IsPunct(']') || tok.IsPunct('}'))
            {
                depth--;
                continue;
            }
            if (depth != 0 || tok.Kind != TokenKind.Punct)
            {
                continue;
            }
            var prev = t[i - 1];
            var operandBefore = prev.Kind is TokenKind.Identifier or TokenKind.Number or TokenKind.String or TokenKind.Char || prev.Text is ")" or "]" || prev.Is("this") || prev.Text is "true" or "false" or "null";
            if (!operandBefore)
            {
                continue;
            }
            if (tok.Text is "+" or "-" or "*" or "/" or "%")
            {
                if (t[i + 1].Text == tok.Text && tok.Text is "+" or "-")
                {
                    i++;
                    continue; // ++ / --
                }
                list.Add(i);
            }
            else if (tok.IsPunct('<') && GenericClose(t, i) is var genericEnd and >= 0)
            {
                i = genericEnd; // Deserialize<Order>(…) is a generic call, not a comparison
            }
            else if (tok.Text is "&" or "|" && t[i + 1].Text == tok.Text || tok.Text is "=" or "!" && t[i + 1].IsPunct('=') || tok.Text is "<" or ">")
            {
                list.Add(i);
                if (t[i + 1].Kind == TokenKind.Punct && t[i + 1].Text is "&" or "|" or "=")
                {
                    i++;
                }
            }
        }
        return list;
    }

    /// <summary>Index of the matching '>' when t[i] opens a generic argument list (Foo&lt;Bar, Baz?&gt;), otherwise -1.</summary>
    internal static int GenericClose(List<Token> t, int i)
    {
        if (!t[i].IsPunct('<') || i == 0 || t[i - 1].Kind != TokenKind.Identifier)
        {
            return -1;
        }
        var depth = 0;
        for (var k = i; k < t.Count && k - i < 40; k++)
        {
            var tok = t[k];
            if (tok.IsPunct('<'))
            {
                depth++;
            }
            else if (tok.IsPunct('>'))
            {
                depth--;
                if (depth == 0)
                {
                    var next = k + 1 < t.Count ? t[k + 1].Text : null;
                    return next is null or "(" or ")" or "." or "," or ";" or ">" or "{" or "]" ? k : -1;
                }
            }
            else if (!(tok.Kind is TokenKind.Identifier || tok.Kind == TokenKind.Keyword && tok.Text is "int" or "long" or "string" or "bool" or "decimal" or "double" or "float" or "object" or "byte" or "short" or "char" or "uint" or "ulong"
                       || tok.Text is "." or "," or "?" or "[" or "]" or "(" or ")"))
            {
                return -1;
            }
        }
        return -1;
    }

    private static bool IsGenericAngle(List<Token> t, int i) => GenericClose(t, i) >= 0;
}

internal static class StringExtensions
{
    public static string Truncate(this string value, int max) => value.Length <= max ? value : value[..max] + "…";
}
