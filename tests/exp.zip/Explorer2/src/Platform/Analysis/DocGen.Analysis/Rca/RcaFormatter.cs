using System.Text;

namespace DocGen.Analysis.Rca;

/// <summary>Plain-text rendering of RCA results for tool output (bounded).</summary>
public static class RcaFormatter
{
    public static string Format(RcaReport report, int maxCandidates = 8)
    {
        var sb = new StringBuilder();
        sb.AppendLine(report.Summary);
        if (report.FailureKind is not null)
        {
            sb.AppendLine("Failure kind: " + report.FailureKind);
        }
        sb.AppendLine();
        sb.AppendLine("Likely causes (evidence-weighted; strength is qualitative, not a probability):");
        var rank = 0;
        foreach (var c in report.Candidates.Take(maxCandidates))
        {
            rank++;
            sb.AppendLine($"{rank}. [{c.Strength}] {c.Title} — {c.Role} · {c.Location}");
            foreach (var e in c.Evidence.Where(e => !e.Contradicts).OrderByDescending(e => e.Weight).Take(3))
            {
                sb.AppendLine($"     + {Clip(e.Text, 260)}");
            }
            foreach (var e in c.Evidence.Where(e => e.Contradicts).Take(2))
            {
                sb.AppendLine($"     − {Clip(e.Text, 260)}");
            }
        }
        if (report.Candidates.Count == 0)
        {
            sb.AppendLine("  (none)");
        }
        if (report.Trace.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("Root cause trace for #1 (origin → failure):");
            AppendChain(sb, report.Trace);
        }
        if (report.Experiments.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("Discriminating experiments:");
            foreach (var e in report.Experiments)
            {
                sb.AppendLine($"  {e.Id} ({e.Cost}{(e.Tool is null ? "" : ", tool " + e.Tool)}): {e.Description} ({e.Discriminates})");
            }
        }
        if (report.Findings.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("Analyzer findings:");
            foreach (var f in report.Findings.Distinct().Take(8))
            {
                sb.AppendLine("  - " + Clip(f, 300));
            }
        }
        if (report.Ambiguities.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("Ambiguities (name-based resolution, not certain):");
            foreach (var a in report.Ambiguities.Take(6))
            {
                sb.AppendLine("  - " + Clip(a, 200));
            }
        }
        sb.AppendLine();
        sb.AppendLine(Stats(report.Stats));
        return sb.ToString();
    }

    public static void AppendChain(StringBuilder sb, IReadOnlyList<ProvenanceNode> chain)
    {
        for (var i = 0; i < chain.Count; i++)
        {
            var n = chain[i];
            var where = n.File is null ? "" : $" [{n.File}{(n.Line is { } l ? ":" + l : "")}]";
            sb.AppendLine($"  {(i == 0 ? "●" : "↓")} {Clip(n.Title, 220)}{where}{(n.Confidence == "definite" ? "" : $" ({n.Confidence})")}");
            foreach (var note in n.Notes.Take(2))
            {
                sb.AppendLine($"      note: {Clip(note, 200)}");
            }
        }
    }

    public static string Stats(RcaStats s)
        => $"Budget: {s.FilesOpened} files opened, {s.SymbolsConsidered} symbols considered, {s.SourceLinesRetrieved:N0} source lines retrieved, {s.NodesTraversed} graph nodes, " +
           $"{s.ElapsedMs} ms{(s.Expansions > 0 ? ", widened once" : "")}{(s.Exhausted ? ", budget exhausted (results may be incomplete)" : "")}.";

    private static string Clip(string value, int max) => value.Length <= max ? value : value[..max] + "…";
}
