using System.Text.RegularExpressions;
using DocGen.Analysis.CSharp;
using DocGen.Analysis.Flow;
using DocGen.Analysis.Indexing;

namespace DocGen.Analysis.Rca;

public sealed record RaceFinding(SymbolRecord Member, string Pattern, string Description, int ReadLine, int WriteLine);

/// <summary>
/// Deterministic concurrency heuristics on one member. These are candidates, not confirmed bugs:
/// <list type="bullet">
/// <item>lost update: a field is read, the method awaits, then the field is written from the stale read;</item>
/// <item>check-then-act: a value obtained from a dependency is checked, then a dependent write happens after an await;</item>
/// <item>non-atomic update of a field (++, +=) in an async or shared member without synchronisation.</item>
/// </list>
/// Members that use lock, SemaphoreSlim.Wait*, Interlocked or Monitor are not reported.
/// </summary>
public static class RaceAnalyzer
{
    private static readonly Regex WriteVerb = new("^(Set|Update|Save|Write|Put|Store|Decrement|Increment|Remove|Add|Delete|Insert|Upsert|Commit|Apply|Deduct|Withdraw|Allocate)", RegexOptions.Compiled);

    public static List<RaceFinding> Analyze(FlowContext ctx, MemberFlow m)
    {
        var findings = new List<RaceFinding>();
        if (m.Synchronization.Count > 0 || m.AwaitLines.Count == 0 && !m.Symbol.Modifiers.Contains("static"))
        {
            return findings;
        }
        var type = ctx.ContainingType(m.Symbol);
        var fields = type is null ? [] : ctx.Index.MembersOf(type.FullName)
            .Where(s => s.Kind == SymbolKinds.Field && !s.Modifiers.Contains("readonly") && !s.Modifiers.Contains("const")).Select(s => s.Name).ToHashSet(StringComparer.Ordinal);

        // Lost update on a field across an await.
        foreach (var write in m.Assignments.Where(a => fields.Contains(a.TargetRoot) && a.TargetTokens.Count == 1))
        {
            var readLine = m.Body.Where(t => t.Kind == TokenKind.Identifier && t.Text == write.TargetRoot && t.Line < write.Line).Select(t => t.Line).DefaultIfEmpty(-1).Min();
            if (readLine > 0 && m.AwaitLines.Any(l => l >= readLine && l <= write.Line))
            {
                findings.Add(new RaceFinding(m.Symbol, "lost-update",
                    $"`{write.TargetRoot}` is read (line {readLine}), the method awaits, then `{write.Target}` is written from that earlier read (line {write.Line}) without synchronisation — concurrent callers can overwrite each other.",
                    readLine, write.Line));
            }
            else if (write.Kind is AssignmentKinds.Compound or AssignmentKinds.Increment && m.AwaitLines.Count > 0)
            {
                findings.Add(new RaceFinding(m.Symbol, "non-atomic", $"`{write.Target}` is updated non-atomically in an async method without synchronisation.", write.Line, write.Line));
            }
        }

        // Check-then-act on state held by a dependency.
        foreach (var local in m.Locals.Where(l => l.Init is { } init && init.Tokens.Any(t => t.Is("await"))))
        {
            var readCall = m.Calls.FirstOrDefault(c => c.Line == local.Line && c.Receiver.Count > 0);
            if (readCall is null)
            {
                continue;
            }
            var checkedIn = m.Conditions.FirstOrDefault(c => c.Line >= local.Line && c.Condition.Tokens.Any(t => t.Text == local.Name));
            if (checkedIn is null)
            {
                continue;
            }
            var write = m.Calls.FirstOrDefault(c => c.Line > checkedIn.Line && WriteVerb.IsMatch(c.Callee) && c.Args.Any(a => a.Tokens.Any(t => t.Text == local.Name))
                                                  && (c.ReceiverText == readCall.ReceiverText || c.Receiver.Count > 0));
            if (write is not null && m.AwaitLines.Any(l => l >= local.Line && l <= write.Line))
            {
                findings.Add(new RaceFinding(m.Symbol, "check-then-act",
                    $"`{local.Name}` is read via `{readCall.ReceiverText}.{readCall.Callee}` (line {local.Line}), checked (line {checkedIn.Line}), then written back through `{write.ReceiverText}.{write.Callee}` (line {write.Line}) across an await with no lock — another caller can act on the same stale value.",
                    local.Line, write.Line));
            }
        }
        return findings;
    }

    // Standard concurrency vocabulary only (no domain words).
    private static readonly string[] ConcurrencyWords = ["concurren", "parallel", "under load", "race condition", "intermittent", "simultaneous", "at the same time", "thread", "second operation", "deadlock"];

    /// <summary>Does the symptom or the failing test suggest concurrent execution?</summary>
    public static bool ConcurrencyContext(string? symptom, string failureText, MemberFlow? test)
        => ConcurrencyWords.Any(w => (symptom ?? "").Contains(w, StringComparison.OrdinalIgnoreCase) || failureText.Contains(w, StringComparison.OrdinalIgnoreCase))
           || test is not null && test.Calls.Any(c => c.Callee is "WhenAll" or "WaitAll" or "Run" or "StartNew" or "For" or "ForEach" or "ForEachAsync" or "SignalAndWait" && (c.ReceiverText is "Task" or "Parallel" or "" || c.Callee == "SignalAndWait"));
}

public sealed record DiChain(DiRegistration Singleton, List<string> Path, DiRegistration Captured);

/// <summary>DI lifetime chains: singleton → (transient)* → scoped, including factories that resolve scoped services.</summary>
public static class DiChainAnalyzer
{
    private static readonly HashSet<string> Wrappers = new(StringComparer.Ordinal) { "ILogger", "IOptions", "IOptionsMonitor", "IOptionsSnapshot", "IServiceProvider", "IServiceScopeFactory", "IConfiguration", "IEnumerable" };

    public static List<DiChain> Chains(CodeIndex index)
    {
        var chains = new List<DiChain>();
        var byService = index.Registrations.GroupBy(r => r.ServiceType).ToDictionary(g => g.Key, g => g.Last(), StringComparer.Ordinal);
        foreach (var singleton in index.Registrations.Where(r => r.Lifetime == "Singleton" && !r.ImplementationType.StartsWith('(')))
        {
            Walk(singleton, singleton.ImplementationType, [singleton.ImplementationType], 0);
        }
        return chains;

        void Walk(DiRegistration root, string implementation, List<string> path, int depth)
        {
            if (depth > 4)
            {
                return;
            }
            foreach (var dependency in Dependencies(index, implementation))
            {
                var name = CodeIndex.StripGeneric(FlowContext.BareName(dependency));
                if (Wrappers.Contains(name) || path.Contains(name) || !byService.TryGetValue(name, out var registration))
                {
                    continue;
                }
                var next = path.Append(name).ToList();
                if (registration.Lifetime == "Scoped")
                {
                    chains.Add(new DiChain(root, next, registration));
                }
                else if (registration.Lifetime == "Transient" && !registration.ImplementationType.StartsWith('('))
                {
                    Walk(root, registration.ImplementationType, next, depth + 1);
                }
            }
        }
    }

    public static IEnumerable<string> Dependencies(CodeIndex index, string typeName)
    {
        foreach (var type in index.ByName(CodeIndex.StripGeneric(typeName)).Where(t => t.Kind is SymbolKinds.Class or SymbolKinds.Record))
        {
            foreach (var p in type.ParameterTypes)
            {
                yield return p;
            }
            foreach (var ctor in index.MembersOf(type.FullName).Where(m => m.Kind == SymbolKinds.Constructor))
            {
                foreach (var p in ctor.ParameterTypes)
                {
                    yield return p;
                }
            }
        }
    }
}

public sealed class JsonOptionsInfo
{
    public string Expression { get; set; } = "";
    public bool Web { get; set; }
    public string? NamingPolicy { get; set; }
    public bool CaseInsensitive { get; set; }
    public List<string> Converters { get; set; } = [];
    public bool Resolved { get; set; }

    public string Describe() => $"{(Web ? "Web defaults (camelCase, case-insensitive)" : NamingPolicy is null ? "default (exact PascalCase, case-sensitive)" : "")}"
                                + (NamingPolicy is null ? "" : $"naming {NamingPolicy}") + (CaseInsensitive && !Web ? ", case-insensitive" : "")
                                + (Converters.Count > 0 ? $", converters: {string.Join(", ", Converters)}" : "");
}

public sealed record ContractMismatch(string Property, string ReceiverExpects, string SenderWrites, string Reason);

public sealed class ContractComparison
{
    public string ReceiverType { get; set; } = "";
    public string SenderType { get; set; } = "";
    public string? SenderSite { get; set; }
    public string? ReceiverSite { get; set; }
    public JsonOptionsInfo SenderOptions { get; set; } = new();
    public JsonOptionsInfo ReceiverOptions { get; set; } = new();
    public List<ContractMismatch> Mismatches { get; } = [];
    public SymbolRecord? SenderMember { get; set; }
    public SymbolRecord? ReceiverMember { get; set; }
}

/// <summary>
/// Compares the JSON contract written by serializers with the one read by deserializers: property names after naming
/// policies and [JsonPropertyName], case sensitivity, properties the sender never writes, and converters that apply.
/// Sender types are the exact receiver type or same-shaped types (≥ 60% shared property names).
/// </summary>
public static class ContractAnalyzer
{
    private static readonly HashSet<string> SerializeMethods = new(StringComparer.Ordinal) { "Serialize", "SerializeAsync", "SerializeToUtf8Bytes", "SerializeObject", "PostAsJsonAsync", "PutAsJsonAsync", "WriteAsJsonAsync", "Create" };

    public static JsonOptionsInfo ResolveOptions(FlowContext ctx, MemberFlow site, string? expression, bool webDefault = false)
    {
        var info = new JsonOptionsInfo { Expression = expression ?? "(none)", Web = webDefault };
        if (string.IsNullOrWhiteSpace(expression))
        {
            info.Resolved = true;
            return info;
        }
        List<Token>? init = null;
        var name = expression.Trim();
        if (name.StartsWith("new", StringComparison.Ordinal))
        {
            init = CSharpLexer.Tokenize(name);
        }
        else if (site.LocalsNamed(name).FirstOrDefault()?.Init is { } localInit)
        {
            init = localInit.Tokens;
        }
        else if (ctx.ContainingType(site.Symbol) is { } type && ctx.MembersNamed(type, name.Split('.')[^1]).FirstOrDefault() is { } field
                 && ctx.Member(field)?.Assignments.FirstOrDefault(a => a.Kind == AssignmentKinds.FieldInit) is { } fieldInit)
        {
            init = fieldInit.Source.Tokens;
        }
        if (init is null)
        {
            return info;
        }
        info.Resolved = true;
        var text = Expr.Render(init, 2000);
        info.Web |= text.Contains("JsonSerializerDefaults.Web", StringComparison.Ordinal);
        var policy = Regex.Match(text, @"PropertyNamingPolicy\s*=\s*JsonNamingPolicy\.(\w+)");
        if (policy.Success)
        {
            info.NamingPolicy = policy.Groups[1].Value;
        }
        info.CaseInsensitive = Regex.IsMatch(text, @"PropertyNameCaseInsensitive\s*=\s*true");
        foreach (Match converter in Regex.Matches(text, @"new\s+(\w+Converter\w*)"))
        {
            info.Converters.Add(converter.Groups[1].Value);
        }
        return info;
    }

    /// <summary>Wire name of a property under options (attribute first).</summary>
    public static string WireName(string property, string? attribute, JsonOptionsInfo options)
    {
        if (attribute is not null)
        {
            return attribute;
        }
        var policy = options.NamingPolicy ?? (options.Web ? "CamelCase" : null);
        return policy switch
        {
            "CamelCase" => char.ToLowerInvariant(property[0]) + property[1..],
            "SnakeCaseLower" => Separate(property, '_').ToLowerInvariant(),
            "SnakeCaseUpper" => Separate(property, '_').ToUpperInvariant(),
            "KebabCaseLower" => Separate(property, '-').ToLowerInvariant(),
            "KebabCaseUpper" => Separate(property, '-').ToUpperInvariant(),
            _ => property,
        };
    }

    private static string Separate(string name, char separator)
        => Regex.Replace(name, "(?<=[a-z0-9])([A-Z])|(?<=[A-Z])([A-Z][a-z])", separator + "$1$2");

    public static List<(SymbolRecord Property, string? Attribute)> Properties(FlowContext ctx, SymbolRecord type)
        => ctx.Index.MembersOf(type.FullName).Where(m => m.Kind == SymbolKinds.Property && !m.Modifiers.Contains("static"))
            .Select(p => (p, ctx.Member(p)?.AttributeArguments.GetValueOrDefault("JsonPropertyName"))).ToList();

    /// <summary>Serialization sites of types compatible with <paramref name="receiverType"/> (bounded search).</summary>
    public static List<(SymbolRecord SenderType, MemberFlow Site, string? Options, bool WebDefault)> SenderSites(FlowContext ctx, SymbolRecord receiverType)
    {
        var results = new List<(SymbolRecord, MemberFlow, string?, bool)>();
        var receiverProps = ctx.Index.MembersOf(receiverType.FullName).Where(m => m.Kind == SymbolKinds.Property).Select(p => p.Name).ToHashSet(StringComparer.Ordinal);
        foreach (var user in ctx.Index.CallersByName("Serialize").Concat(ctx.Index.CallersByName("SerializeAsync")).Concat(ctx.Index.CallersByName("PostAsJsonAsync"))
                     .Concat(ctx.Index.CallersByName("SerializeToUtf8Bytes")).Distinct().Take(40))
        {
            var site = ctx.Member(user);
            if (site is null)
            {
                continue;
            }
            foreach (var call in site.Calls.Where(c => SerializeMethods.Contains(c.Callee) && c.Callee != "Create" && c.Args.Count > 0))
            {
                var valueIndex = call.Callee is "PostAsJsonAsync" or "PutAsJsonAsync" or "WriteAsJsonAsync" ? 1 : 0;
                if (valueIndex >= call.Args.Count)
                {
                    continue;
                }
                var options = call.Args.Count > valueIndex + 1 ? call.Args[valueIndex + 1].Text : null;
                var web = call.Callee.EndsWith("AsJsonAsync", StringComparison.Ordinal);
                var valueType = call.TypeArgs.FirstOrDefault() ?? ctx.ExpressionType(site, call.Args[valueIndex].Tokens, call.Line);
                var senderTypes = new List<SymbolRecord>();
                var concrete = valueType is null ? [] : ctx.ResolveType(valueType, site.Symbol);
                if (concrete.Count > 0)
                {
                    senderTypes.AddRange(concrete);
                }
                else if (site.Parameters.Any(p => call.Args[valueIndex].Tokens.Count == 1 && p.Name == call.Args[valueIndex].Tokens[0].Text))
                {
                    // Generic publisher "Publish<T>(T message)": concrete types come from its callers.
                    var index = site.Parameters.FindIndex(p => p.Name == call.Args[valueIndex].Tokens[0].Text);
                    foreach (var caller in ctx.Index.CallersByName(site.Symbol.Name).Take(20))
                    {
                        var callerFlow = ctx.Member(caller);
                        foreach (var c in callerFlow?.Calls.Where(c => c.Callee == site.Symbol.Name && c.Args.Count > index) ?? [])
                        {
                            if (ctx.ExpressionType(callerFlow!, c.Args[index].Tokens, c.Line) is { } argType)
                            {
                                senderTypes.AddRange(ctx.ResolveType(argType, callerFlow!.Symbol));
                            }
                        }
                    }
                }
                foreach (var sender in senderTypes.Distinct())
                {
                    if (sender.FullName == receiverType.FullName)
                    {
                        results.Add((sender, site, options, web));
                        continue;
                    }
                    var senderProps = ctx.Index.MembersOf(sender.FullName).Where(m => m.Kind == SymbolKinds.Property).Select(p => p.Name).ToHashSet(StringComparer.Ordinal);
                    var shared = senderProps.Intersect(receiverProps).Count();
                    if (shared >= 2 && shared >= 0.6 * Math.Max(senderProps.Count, receiverProps.Count))
                    {
                        results.Add((sender, site, options, web));
                    }
                }
            }
        }
        return results;
    }

    public static List<ContractComparison> Compare(FlowContext ctx, DeserializationSite receiver)
    {
        var comparisons = new List<ContractComparison>();
        var receiverTypeName = receiver.Type is null ? null : FlowContext.GenericArgument(receiver.Type) is { } element && FlowContext.BareName(receiver.Type) is "List" or "IEnumerable" or "IReadOnlyList" or "Array" ? element : receiver.Type;
        var receiverType = receiverTypeName is null ? null : ctx.ResolveType(receiverTypeName, receiver.Member.Symbol).FirstOrDefault();
        if (receiverType is null)
        {
            return comparisons;
        }
        var web = receiver.Member.Calls.Any(c => c.Callee is "ReadFromJsonAsync" or "GetFromJsonAsync");
        var receiverOptions = ResolveOptions(ctx, receiver.Member, receiver.OptionsExpression, web);
        foreach (var (senderType, site, optionsText, senderWeb) in SenderSites(ctx, receiverType).Take(6))
        {
            var comparison = CompareTypes(ctx, senderType, receiverType, ResolveOptions(ctx, site, optionsText, senderWeb), receiverOptions);
            comparison.SenderSite = site.Symbol.FullName;
            comparison.ReceiverSite = receiver.Member.Symbol.FullName;
            comparison.SenderMember = site.Symbol;
            comparison.ReceiverMember = receiver.Member.Symbol;
            comparisons.Add(comparison);
        }
        return comparisons;
    }

    /// <summary>Compares what <paramref name="senderType"/> writes under the sender options with what <paramref name="receiverType"/> reads.</summary>
    public static ContractComparison CompareTypes(FlowContext ctx, SymbolRecord senderType, SymbolRecord receiverType, JsonOptionsInfo senderOptions, JsonOptionsInfo receiverOptions)
    {
        var receiverProps = Properties(ctx, receiverType);
        var senderProps = Properties(ctx, senderType).ToDictionary(p => p.Property.Name, p => p.Attribute, StringComparer.Ordinal);
        var comparison = new ContractComparison
        {
            ReceiverType = receiverType.FullName, SenderType = senderType.FullName, SenderOptions = senderOptions, ReceiverOptions = receiverOptions,
        };
        var ci = receiverOptions.Web || receiverOptions.CaseInsensitive;
        foreach (var (property, attribute) in receiverProps)
        {
            if (ctx.Member(property) is { Returns.Count: > 0 } getter && !getter.Body.Any(t => t.Is("set") || t.Is("init")) && attribute is null && !property.Signature.Contains("set", StringComparison.Ordinal))
            {
                continue; // computed, not read from JSON
            }
            var expects = WireName(property.Name, attribute, receiverOptions);
            if (!senderProps.TryGetValue(property.Name, out var senderAttribute))
            {
                if (senderType.FullName != receiverType.FullName)
                {
                    comparison.Mismatches.Add(new ContractMismatch(property.Name, expects, "(not written)", $"{senderType.Name} has no {property.Name}; the receiver keeps its default"));
                }
                continue;
            }
            var writes = WireName(property.Name, senderAttribute, senderOptions);
            var match = ci ? string.Equals(expects, writes, StringComparison.OrdinalIgnoreCase) : expects == writes;
            if (!match)
            {
                comparison.Mismatches.Add(new ContractMismatch(property.Name, expects, writes,
                    $"sender writes \"{writes}\" but receiver reads \"{expects}\"{(ci ? " (case-insensitive)" : " (case-sensitive)")} — {property.Name} is left at its default"));
            }
        }
        return comparison;
    }

    /// <summary>Converter types (in the options) that handle a type found in <paramref name="rootType"/>'s property graph.</summary>
    public static List<(SymbolRecord Converter, string HandledType)> ApplicableConverters(FlowContext ctx, JsonOptionsInfo options, SymbolRecord rootType, SymbolRecord context)
    {
        var types = new HashSet<string>(StringComparer.Ordinal);
        var queue = new Queue<(SymbolRecord, int)>([(rootType, 0)]);
        var seen = new HashSet<string>(StringComparer.Ordinal);
        while (queue.Count > 0)
        {
            var (type, depth) = queue.Dequeue();
            if (!seen.Add(type.FullName) || depth > 3)
            {
                continue;
            }
            foreach (var p in ctx.Index.MembersOf(type.FullName).Where(m => m.Kind == SymbolKinds.Property && m.ReturnType is not null))
            {
                var t = p.ReturnType!.TrimEnd('?');
                var element = FlowContext.GenericArgument(t) ?? t;
                types.Add(FlowContext.BareName(t));
                types.Add(FlowContext.BareName(element));
                foreach (var nested in ctx.ResolveType(element, type))
                {
                    queue.Enqueue((nested, depth + 1));
                }
            }
        }
        var result = new List<(SymbolRecord, string)>();
        foreach (var converterName in options.Converters)
        {
            foreach (var converter in ctx.ResolveType(converterName, context))
            {
                var handled = ctx.TypeFlowOf(converter)?.BaseTypeArguments.GetValueOrDefault("JsonConverter");
                if (handled is not null && types.Contains(FlowContext.BareName(handled)))
                {
                    result.Add((converter, handled));
                }
            }
        }
        return result;
    }
}

public sealed class ConfigLayer
{
    public string File { get; set; } = "";
    public int Line { get; set; }
    public string? Value { get; set; }
}

public sealed class ConfigProvenance
{
    public string Key { get; set; } = "";
    public List<ConfigLayer> Layers { get; } = [];
    public string EnvironmentVariable => Key.Replace(":", "__");
    public bool Missing => Layers.Count == 0;
    public List<string> NearMisses { get; } = [];
    public List<string> Findings { get; } = [];

    /// <summary>The environment-specific layer that overrides the base value with a different one.</summary>
    public ConfigLayer? Override { get; set; }

    public bool SuspiciousOverride { get; set; }
}

/// <summary>
/// Configuration provenance: key → appsettings layers (base and environment files) → options binding → consumer.
/// Reports missing keys (the consumer gets a default), environment overrides that change a value (flagging
/// suspicious values such as 0, empty or negative), and near-miss keys that look like misspellings.
/// </summary>
public static class ConfigAnalyzer
{
    public static string? ResolveOptionsKey(CodeIndex index, string optionsType, IReadOnlyList<string> path)
    {
        var bare = FlowContext.BareName(optionsType);
        var binding = index.ConfigReferences.FirstOrDefault(c => c.Kind == "optionsBinding" && c.Type == bare);
        if (binding is null)
        {
            return null;
        }
        var section = binding.Key;
        if (section.Contains('.') && !section.Contains(':'))
        {
            var parts = section.Split('.');
            section = index.ConfigReferences.FirstOrDefault(s => s.Kind == "sectionConstant" && s.Type == parts[^2] && s.Owner?.EndsWith("." + parts[^1], StringComparison.Ordinal) == true)?.Key ?? section;
        }
        return path.Count == 0 ? section : section + ":" + string.Join(':', path);
    }

    public static ConfigProvenance Trace(CodeIndex index, string key)
    {
        var result = new ConfigProvenance { Key = key };
        foreach (var (k, locations) in index.ConfigValues.Where(kv => kv.Key.Equals(key, StringComparison.OrdinalIgnoreCase)))
        {
            foreach (var (file, line) in locations)
            {
                result.Layers.Add(new ConfigLayer { File = file, Line = line, Value = ReadJsonValue(index, file, k) ?? ReadValue(index, file, line) });
            }
        }
        result.Layers.Sort((a, b) => Rank(a.File).CompareTo(Rank(b.File)));
        var baseLayer = result.Layers.FirstOrDefault(l => Rank(l.File) == 0);
        foreach (var layer in result.Layers.Where(l => Rank(l.File) > 0))
        {
            if (baseLayer is null || layer.Value != baseLayer.Value)
            {
                result.Override = layer;
                result.SuspiciousOverride = IsSuspicious(layer.Value);
                result.Findings.Add($"{Path.GetFileName(layer.File)} sets {key} = {layer.Value}{(baseLayer is null ? "" : $" (base {Path.GetFileName(baseLayer.File)}: {baseLayer.Value})")}{(result.SuspiciousOverride ? " — suspicious value" : "")}");
            }
        }
        if (result.Missing)
        {
            result.Findings.Add($"{key} is not defined in any appsettings*.json; the consumer receives the default unless environment variable {result.EnvironmentVariable} or another provider sets it");
            var section = key.Contains(':') ? key[..key.LastIndexOf(':')] : "";
            var leaf = key.Contains(':') ? key[(key.LastIndexOf(':') + 1)..] : key;
            foreach (var candidate in index.ConfigValues.Keys.Where(k => section.Length == 0 || k.StartsWith(section + ":", StringComparison.OrdinalIgnoreCase)))
            {
                var candidateLeaf = candidate.Contains(':') ? candidate[(candidate.LastIndexOf(':') + 1)..] : candidate;
                if (Similar(leaf, candidateLeaf) && candidate.Count(c => c == ':') == key.Count(c => c == ':'))
                {
                    result.NearMisses.Add(candidate);
                }
            }
            if (result.NearMisses.Count > 0)
            {
                result.Findings.Add($"near-miss keys present: {string.Join(", ", result.NearMisses.Distinct(StringComparer.OrdinalIgnoreCase))} — possible naming mismatch between code and configuration");
            }
        }
        return result;
    }

    private static int Rank(string file)
    {
        var name = Path.GetFileName(file);
        return name.Equals("appsettings.json", StringComparison.OrdinalIgnoreCase) ? 0 : 1;
    }

    public static bool IsSuspicious(string? value)
    {
        var v = value?.Trim().Trim('"', ',') ?? "";
        return v is "0" or "" or "null" or "false" || v.StartsWith('-') && double.TryParse(v, out _);
    }

    private static bool Similar(string a, string b)
    {
        if (a.Equals(b, StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }
        var x = a.ToLowerInvariant();
        var y = b.ToLowerInvariant();
        return x.Contains(y, StringComparison.Ordinal) || y.Contains(x, StringComparison.Ordinal) || Levenshtein(x, y) <= 2;
    }

    private static int Levenshtein(string a, string b)
    {
        var d = new int[a.Length + 1, b.Length + 1];
        for (var i = 0; i <= a.Length; i++)
        {
            d[i, 0] = i;
        }
        for (var j = 0; j <= b.Length; j++)
        {
            d[0, j] = j;
        }
        for (var i = 1; i <= a.Length; i++)
        {
            for (var j = 1; j <= b.Length; j++)
            {
                d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1), d[i - 1, j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1));
            }
        }
        return d[a.Length, b.Length];
    }

    /// <summary>Value of a "Section:Key" path in a JSON configuration file (works for compact and multi-line files).</summary>
    private static string? ReadJsonValue(CodeIndex index, string file, string key)
    {
        try
        {
            var full = Path.Combine(index.Root, file);
            if (new FileInfo(full).Length > 4 * 1024 * 1024)
            {
                return null;
            }
            using var doc = System.Text.Json.JsonDocument.Parse(File.ReadAllText(full), new System.Text.Json.JsonDocumentOptions { CommentHandling = System.Text.Json.JsonCommentHandling.Skip, AllowTrailingCommas = true });
            var element = doc.RootElement;
            foreach (var segment in key.Split(':'))
            {
                if (element.ValueKind == System.Text.Json.JsonValueKind.Array && int.TryParse(segment, out var i) && i < element.GetArrayLength())
                {
                    element = element[i];
                    continue;
                }
                if (element.ValueKind != System.Text.Json.JsonValueKind.Object)
                {
                    return null;
                }
                var next = element.EnumerateObject().FirstOrDefault(p => p.Name.Equals(segment, StringComparison.OrdinalIgnoreCase));
                if (next.Value.ValueKind == System.Text.Json.JsonValueKind.Undefined)
                {
                    return null;
                }
                element = next.Value;
            }
            return element.ValueKind is System.Text.Json.JsonValueKind.Object or System.Text.Json.JsonValueKind.Array ? null : element.GetRawText();
        }
        catch (Exception ex) when (ex is System.Text.Json.JsonException or IOException)
        {
            return null;
        }
    }

    private static string? ReadValue(CodeIndex index, string file, int line)
    {
        try
        {
            var text = File.ReadLines(Path.Combine(index.Root, file)).Skip(line - 1).FirstOrDefault();
            if (text is null)
            {
                return null;
            }
            var colon = text.IndexOf(':');
            return colon < 0 ? text.Trim() : text[(colon + 1)..].Trim().TrimEnd(',').Trim();
        }
        catch (IOException)
        {
            return null;
        }
    }
}

public sealed record StaleFinding(SymbolRecord Invalidator, string ReadKeys, string InvalidateKeys, string Description);

/// <summary>
/// Stale state around a keyed collection (cache/dictionary field): compares how callers build the key when reading
/// with how they build it when invalidating/removing. Disjoint key sources suggest invalidations that never hit.
/// </summary>
public static class StaleStateAnalyzer
{
    private static readonly HashSet<string> Reads = new(StringComparer.Ordinal) { "GetOrAdd", "TryGetValue", "Get", "GetValueOrDefault", "ContainsKey", "TryGet" };
    private static readonly HashSet<string> Invalidations = new(StringComparer.Ordinal) { "Remove", "TryRemove", "Clear", "Invalidate", "Evict", "Set", "AddOrUpdate" };

    public static List<StaleFinding> Analyze(FlowContext ctx, KeyedStateSite site)
    {
        var findings = new List<StaleFinding>();
        var members = ctx.Index.MembersOf(site.Type.FullName).Where(s => s.Kind == SymbolKinds.Method).ToList();
        var readers = new List<MemberFlow>();
        var invalidators = new List<MemberFlow>();
        foreach (var member in members)
        {
            var flow = ctx.Member(member);
            if (flow is null)
            {
                continue;
            }
            var onField = flow.Calls.Where(c => c.ReceiverText == site.Field || c.ReceiverText == "this." + site.Field).ToList();
            if (onField.Any(c => Reads.Contains(c.Callee)))
            {
                readers.Add(flow);
            }
            if (onField.Any(c => Invalidations.Contains(c.Callee) && c.Callee != "AddOrUpdate") || flow.Assignments.Any(a => a.TargetTokens.Count > 1 && a.TargetTokens[0].Text == site.Field))
            {
                invalidators.Add(flow);
            }
        }
        foreach (var reader in readers.Where(r => r.Parameters.Count > 0))
        {
            var readKeys = KeySources(ctx, reader.Symbol, 0);
            foreach (var invalidator in invalidators.Where(i => i.Parameters.Count > 0 && i.Symbol != reader.Symbol))
            {
                var invalidateKeys = KeySources(ctx, invalidator.Symbol, 0);
                if (readKeys.Count == 0 || invalidateKeys.Count == 0)
                {
                    continue;
                }
                foreach (var (callerSymbol, keys) in invalidateKeys)
                {
                    var allRead = readKeys.SelectMany(r => r.Keys).ToHashSet(StringComparer.OrdinalIgnoreCase);
                    if (!keys.Overlaps(allRead))
                    {
                        findings.Add(new StaleFinding(callerSymbol, string.Join(", ", allRead), string.Join(", ", keys),
                            $"{ProvenanceTracer.ShortName(callerSymbol)} invalidates `{site.Field}` via {ProvenanceTracer.ShortName(invalidator.Symbol)} with a key built from {{{string.Join(", ", keys)}}}, "
                            + $"but readers build it from {{{string.Join(", ", allRead)}}} — the invalidation can miss the cached entry, leaving stale state."));
                    }
                }
            }
        }
        return findings;
    }

    /// <summary>For each external caller of <paramref name="method"/>: the names the key argument is built from.</summary>
    private static List<(SymbolRecord Caller, HashSet<string> Keys)> KeySources(FlowContext ctx, SymbolRecord method, int argIndex)
    {
        var result = new List<(SymbolRecord, HashSet<string>)>();
        foreach (var callerSymbol in ctx.Index.CallersByName(method.Name).Where(c => c.Container != method.Container).Take(12))
        {
            var caller = ctx.Member(callerSymbol);
            foreach (var call in caller?.Calls.Where(c => c.Callee == method.Name && c.Args.Count > argIndex) ?? [])
            {
                var names = call.Args[argIndex].Tokens.Where(t => t.Kind == TokenKind.Identifier && t.Text is not ("ToString" or "ToLowerInvariant" or "ToUpperInvariant" or "Trim" or "Format"))
                    .Select(t => t.Text).ToList();
                // "book.Isbn" → Isbn; "bookId" → bookId; "b.Id" → Id
                var key = names.Count == 0 ? null : names.Count >= 2 ? names[^1] : names[0];
                if (key is not null)
                {
                    result.Add((callerSymbol, new HashSet<string>([key], StringComparer.OrdinalIgnoreCase)));
                }
            }
        }
        return result;
    }
}

/// <summary>Integer division whose result feeds a decimal/double/float value (truncation before conversion).</summary>
public static class ArithmeticSmells
{
    public static string? IntegerDivision(FlowContext ctx, MemberFlow m)
    {
        var returnType = FlowContext.UnwrapTask(m.Symbol.ReturnType);
        if (returnType is not ("decimal" or "double" or "float" or "decimal?" or "double?"))
        {
            return null;
        }
        foreach (var r in m.Returns)
        {
            var t = r.Tokens;
            for (var i = 1; i + 1 < t.Count; i++)
            {
                if (!t[i].IsPunct('/'))
                {
                    continue;
                }
                var right = t[i + 1];
                var rightIntegral = right.Kind == TokenKind.Number && !right.Text.Any(c => c is '.' or 'm' or 'M' or 'd' or 'D' or 'f' or 'F');
                var leftText = Expr.Render(t.Take(i).ToList());
                var leftIntegral = Regex.IsMatch(leftText, @"GetInt(16|32|64)\(\)|\bCount\b|\bLength\b|\(int\)|\(long\)$");
                if (rightIntegral && leftIntegral)
                {
                    return $"`{Expr.Render(t)}` divides integers ({leftText} / {right.Text}) and only then converts to {returnType}: the fractional part is truncated.";
                }
            }
        }
        return null;
    }
}
