using System.Text.RegularExpressions;
using DocGen.Analysis.CSharp;
using DocGen.Analysis.Diagnostics;
using DocGen.Analysis.Flow;
using DocGen.Analysis.Indexing;
using DocGen.Analysis.Json;
using DocGen.Analysis.Tools;

namespace DocGen.Analysis.Rca;

public sealed class RcaFailure
{
    public string? TestName { get; set; }

    /// <summary>Exception message and stack trace text (test output, log excerpt or Exception.ToString()).</summary>
    public string Text { get; set; } = "";
}

public sealed class RcaRequest
{
    public List<RcaFailure> Failures { get; set; } = [];
    public string? Symptom { get; set; }
}

/// <summary>
/// Backward root-cause analysis. From each failure it identifies the throw site, wrappers and the underlying
/// exception, chooses the values involved (dereferenced expression, divisor, bad argument, assertion "actual"),
/// traces their provenance backwards, runs specialised analyzers on what the trace reaches, and ranks candidates by
/// evidence. Crash proximity alone cannot dominate: a throw site is worth less than any demonstrated state origin.
/// Scores are relative rankings, not probabilities; strength is reported as Strong / Moderate / Weak with reasons.
/// </summary>
public static partial class RcaEngine
{
    // Evidence weights (fixed; documented in README "Root cause localization").
    private const double ThrowSite = 2;
    private const double OtherFrame = 1;
    private const double Propagation = 1;
    private const double TransformationWeight = 3;
    private const double OmissionWeight = 5;
    private const double NullLiteralWeight = 4;
    private const double NullableFlowWeight = 4;
    private const double RaceWeight = 4;
    private const double ConcurrencyContextBonus = 2;
    private const double DiLinkedWeight = 6;
    private const double DiUnlinkedWeight = 2;
    private const double ContractOnPathWeight = 6;
    private const double ContractSiteWeight = 4;
    private const double ContractOffPathWeight = 2;
    private const double ConverterWeight = 3;
    private const double ConfigOverrideWeight = 7;
    private const double ConfigMissingWeight = 6;
    private const double ConfigReaderWeight = 2;
    private const double StaleWeight = 6;
    private const double DataCorrelatedWeight = 7;
    private const double IntegerDivisionWeight = 2;
    private const double EmptySequenceFilterWeight = 3;
    private const double WrapperPenalty = -3;

    public static RcaReport Analyze(CodeIndex index, RcaRequest request, CancellationToken ct)
    {
        var report = Run(index, request, RcaBudget.Narrow(), ct);
        if (!report.Candidates.Any(c => c.Strength == "Strong"))
        {
            var wide = RcaBudget.Wide();
            wide.Expansions = 1;
            report = Run(index, request, wide, ct);
        }
        return report;
    }

    private sealed class FrameInfo
    {
        public required StackFrame Frame { get; init; }
        public SymbolRecord? Symbol { get; init; }
        public string? File { get; init; }
        public int Line { get; init; }
        public bool IsTest { get; init; }
    }

    private static RcaReport Run(CodeIndex index, RcaRequest request, RcaBudget budget, CancellationToken ct)
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        var ctx = new FlowContext(index, budget);
        var tracer = new ProvenanceTracer(ctx);
        var report = new RcaReport();
        var candidates = new Dictionary<string, CauseCandidate>(StringComparer.Ordinal);
        var failureText = string.Join("\n", request.Failures.Select(f => f.Text));
        var frameMembers = new List<SymbolRecord>();
        var testMembers = new List<MemberFlow>();
        string? failureKind = null;

        foreach (var failure in request.Failures.Take(3))
        {
            ct.ThrowIfCancellationRequested();
            var trace = StackTraceAnalyzer.Parse(failure.Text);
            var exceptions = trace.Exceptions.OrderByDescending(e => e.Depth).ToList();
            var test = FindTest(ctx, failure.TestName);
            if (test is not null)
            {
                testMembers.Add(test);
            }
            var assertion = IsAssertion(failure.Text, exceptions);
            var innermost = exceptions.FirstOrDefault();
            failureKind ??= assertion ? "assertion" : innermost?.Type;

            // Frames of the innermost exception that has application frames ("call into framework" otherwise).
            var withFrames = exceptions.FirstOrDefault(e => Map(ctx, e.Frames).Any(f => f.Symbol is not null && (!f.IsTest || assertion)));
            var frames = withFrames is null ? [] : Map(ctx, withFrames.Frames).Where(f => f.Symbol is not null).ToList();
            var production = frames.Where(f => !f.IsTest).ToList();
            for (var i = 0; i < Math.Min(4, production.Count); i++)
            {
                var f = production[i];
                frameMembers.Add(f.Symbol!);
                AddEvidence(candidates, index, f.Symbol!, new CandidateEvidence
                {
                    Category = EvidenceCategories.Stack,
                    Weight = i == 0 ? ThrowSite : OtherFrame,
                    Text = i == 0 ? $"{(withFrames == innermost ? "throws" : "calls into the framework code that throws")} {innermost?.Type} (line {f.Line})" : $"on the stack of {innermost?.Type} (frame {i + 1})",
                }, i == 0 ? "throw site" : "propagation");
            }

            // Wrapper sites: outer exceptions whose first application frame catches and rethrows a new exception.
            foreach (var outer in exceptions.Skip(1))
            {
                var outerFrame = Map(ctx, outer.Frames).FirstOrDefault(f => f.Symbol is not null && !f.IsTest);
                if (outerFrame?.Symbol is null || ctx.Member(outerFrame.Symbol) is not { } wrapper || !wrapper.Catches.Any(c => c.WrapType is not null))
                {
                    continue;
                }
                var catchInfo = wrapper.Catches.First(c => c.WrapType is not null);
                AddEvidence(candidates, index, outerFrame.Symbol, new CandidateEvidence
                {
                    Category = EvidenceCategories.Wrapper, Weight = WrapperPenalty, Contradicts = true,
                    Text = $"catches {catchInfo.ExceptionType ?? "Exception"} and rethrows it as {catchInfo.WrapType}{(catchInfo.PassesInner ? " (inner exception preserved)" : "")}: this is a wrapper site; the cause is in the inner {innermost?.Type}",
                }, "wrapper");
                report.Findings.Add($"Wrapper: {ProvenanceTracer.ShortName(outerFrame.Symbol)} wraps {innermost?.Type} in {outer.Type}; ranking follows the inner exception.");
            }

            // Values to trace.
            var starts = StartPoints(ctx, frames, assertion, innermost, failure.Text);
            foreach (var (member, tokens, line, title) in starts.Take(4))
            {
                tracer.Start(member, tokens, line, [], title);
            }
            // Ownership of the object that failed: receivers of the calls between the first frames.
            for (var i = 0; i + 1 < Math.Min(frames.Count, 4); i++)
            {
                var callee = frames[i].Symbol!;
                var caller = frames[i + 1];
                if (ctx.Member(caller.Symbol!) is not { } callerFlow)
                {
                    continue;
                }
                var call = callerFlow.Calls.FirstOrDefault(c => c.Line == caller.Line && c.Callee == callee.Name && c.Receiver.Count > 0);
                if (call is not null)
                {
                    tracer.Start(callerFlow, call.Receiver, caller.Line, [], $"instance `{call.ReceiverText}` on which {callee.Name} failed", "instance");
                }
            }
        }
        tracer.Run();
        report.FailureKind = failureKind;
        report.Nodes = tracer.Nodes;

        // ---- Provenance evidence.
        var nullFailure = failureKind is "System.NullReferenceException" or "System.ArgumentNullException";
        var emptySequence = failureKind is "System.DivideByZeroException" || failureText.Contains("Sequence contains no elements", StringComparison.Ordinal);
        foreach (var node in tracer.Nodes.Where(n => n.Symbol is not null && n.Kind != NodeKinds.Failure))
        {
            var symbol = index.Resolve(node.Symbol!).FirstOrDefault(s => s.FullName == node.Symbol);
            if (symbol is null || symbol.IsTest || index.IsTestProject(symbol.Project))
            {
                continue;
            }
            var evidence = node.Kind switch
            {
                NodeKinds.Omission => new CandidateEvidence { Category = nullFailure ? EvidenceCategories.NullOrigin : EvidenceCategories.Provenance, Weight = OmissionWeight, Origin = true, Text = node.Title },
                NodeKinds.Literal when node.Origin is "null-literal" or "default" => new CandidateEvidence
                {
                    Category = EvidenceCategories.NullOrigin, Weight = nullFailure ? NullLiteralWeight : Propagation, Origin = nullFailure, Text = node.Title,
                },
                NodeKinds.Filter => new CandidateEvidence
                {
                    Category = EvidenceCategories.Provenance, Weight = TransformationWeight + (emptySequence ? EmptySequenceFilterWeight : 0), Origin = emptySequence,
                    Text = node.Title + (emptySequence ? " — the failure needs a non-empty sequence, and this predicate decides which elements remain" : ""),
                },
                NodeKinds.Transformation when node.Symbol == symbol.FullName && !node.Title.StartsWith("null-forgiving", StringComparison.Ordinal)
                                              && !node.Title.StartsWith("string built", StringComparison.Ordinal) && !node.Title.StartsWith("conditional", StringComparison.Ordinal)
                                              && !node.Title.StartsWith("comparison", StringComparison.Ordinal) && !node.Title.Contains(" falls back ", StringComparison.Ordinal)
                    => new CandidateEvidence { Category = EvidenceCategories.Arithmetic, Weight = TransformationWeight, Text = "transforms the traced value: " + node.Title },
                _ => new CandidateEvidence { Category = EvidenceCategories.Provenance, Weight = Propagation, Text = "on the value's provenance path: " + node.Title },
            };
            evidence.NodeId = node.Id;
            AddEvidence(candidates, index, symbol, evidence, evidence.Origin ? "state origin" : node.Kind is NodeKinds.Transformation or NodeKinds.Filter ? "transformation" : "propagation", node.Depth);
        }

        // ---- Null origin: nullable values flowing into a non-null use.
        if (nullFailure)
        {
            foreach (var node in tracer.Nodes.Where(n => n.Kind is NodeKinds.Initializer or NodeKinds.Write && n.Symbol is not null))
            {
                var symbol = index.Resolve(node.Symbol!).FirstOrDefault(s => s.FullName == node.Symbol);
                var member = symbol is null ? null : ctx.Member(symbol);
                var source = member?.Assignments.FirstOrDefault(a => a.Line == node.Line)?.Source ?? (node.Expression is null ? null : new Expr(CSharpLexer.Tokenize(node.Expression.Split('`').ElementAtOrDefault(1) ?? ""), node.Line ?? 0));
                var sourceText = Regex.Match(node.Title, "`([^`]+)`").Groups[1].Value;
                if (member is null || symbol!.IsTest || index.IsTestProject(symbol.Project) || sourceText.Length == 0)
                {
                    continue;
                }
                var type = ctx.ExpressionType(member, CSharpLexer.Tokenize(sourceText), node.Line ?? 0);
                if (FlowContext.IsNullableDeclared(type))
                {
                    AddEvidence(candidates, index, symbol, new CandidateEvidence
                    {
                        Category = EvidenceCategories.NullOrigin, Weight = NullableFlowWeight, Origin = true, NodeId = node.Id,
                        Text = $"assigns `{sourceText}` (declared {type}, may be null) into a value later dereferenced as non-null",
                    }, "state origin", node.Depth);
                }
            }
        }

        // ---- Concurrency.
        var concurrency = RaceAnalyzer.ConcurrencyContext(request.Symptom, failureText, testMembers.FirstOrDefault());
        var raceMembers = tracer.Hooks.Visited.Concat(frameMembers).Where(s => !s.IsTest && !index.IsTestProject(s.Project)).Distinct().Take(40).ToList();
        foreach (var symbol in raceMembers)
        {
            if (ctx.Member(symbol) is not { } flow)
            {
                continue;
            }
            foreach (var finding in RaceAnalyzer.Analyze(ctx, flow))
            {
                AddEvidence(candidates, index, symbol, new CandidateEvidence
                {
                    Category = EvidenceCategories.Concurrency, Weight = RaceWeight + (concurrency ? ConcurrencyContextBonus : 0), Origin = true,
                    Text = $"{finding.Pattern}: {finding.Description}{(concurrency ? " The symptom/test involves concurrent execution." : "")}",
                }, "state origin");
                report.Findings.Add($"Race risk in {ProvenanceTracer.ShortName(symbol)} ({finding.Pattern}).");
            }
        }

        // ---- DI lifetimes.
        var lifetimeWords = LifetimeWords().IsMatch(failureText + " " + request.Symptom);
        foreach (var chain in DiChainAnalyzer.Chains(index))
        {
            var captured = tracer.Hooks.Captured.FirstOrDefault(c => chain.Path.Zip(chain.Path.Skip(1)).Any(pair => pair.First == c.Holder.Name && pair.Second == FlowContext.BareName(c.ParameterType)));
            var capturedTypeOnStack = frameMembers.Any(m => m.Container?.Split('.')[^1] == chain.Captured.ImplementationType)
                                      && frameMembers.Any(m => chain.Path.Take(chain.Path.Count - 1).Contains(m.Container?.Split('.')[^1] ?? ""));
            var linked = captured is not null || capturedTypeOnStack;
            if (!linked && !lifetimeWords)
            {
                continue;
            }
            var weight = linked ? DiLinkedWeight + (lifetimeWords || concurrency ? ConcurrencyContextBonus : 0) : DiUnlinkedWeight;
            var text = $"captive dependency: singleton {string.Join(" → ", chain.Path)} where {chain.Captured.ServiceType} is Scoped ({chain.Captured.File}:{chain.Captured.Line}); "
                       + (linked ? captured is not null ? $"the failing value/instance flows through {captured.Holder.Name}.{captured.Parameter}" : "the failing frames run on the captured instance" : "the symptom mentions lifetime/concurrency effects");
            if (chain.Singleton.Owner is { } owner && index.Resolve(owner).FirstOrDefault(s => s.FullName == owner) is { } ownerSymbol)
            {
                AddEvidence(candidates, index, ownerSymbol, new CandidateEvidence { Category = EvidenceCategories.DependencyInjection, Weight = weight, Origin = linked, Text = text + $" — registered at {chain.Singleton.File}:{chain.Singleton.Line}", NodeId = captured?.Node.Id }, "state origin");
            }
            foreach (var impl in index.ByName(chain.Singleton.ImplementationType).Where(t => SymbolKinds.IsType(t.Kind)))
            {
                AddEvidence(candidates, index, impl, new CandidateEvidence { Category = EvidenceCategories.DependencyInjection, Weight = weight, Origin = linked, Text = text, NodeId = captured?.Node.Id }, "state origin");
            }
        }

        // ---- Serialization contracts.
        foreach (var site in tracer.Hooks.Deserializations.DistinctBy(d => d.Member.Symbol.FullName + d.Type))
        {
            var path = site.Path.Where(p => p != "[]").ToList();
            AddEvidence(candidates, index, site.Member.Symbol, new CandidateEvidence
            {
                Category = EvidenceCategories.Serialization, Weight = Propagation + 1, NodeId = site.Node.Id, Text = $"reads external JSON as {site.Type} — an input boundary on the value's path",
            }, "propagation", site.Node.Depth);
            foreach (var comparison in ContractAnalyzer.Compare(ctx, site))
            {
                var onPath = comparison.Mismatches.Where(m => path.Count == 0 || path.Contains(m.Property)).ToList();
                var mismatches = onPath.Count > 0 ? onPath : comparison.Mismatches;
                if (mismatches.Count == 0)
                {
                    continue;
                }
                var weight = onPath.Count > 0 ? ContractOnPathWeight : ContractOffPathWeight;
                var text = $"JSON contract mismatch {Short(comparison.SenderType)} → {Short(comparison.ReceiverType)}: {string.Join("; ", mismatches.Take(3).Select(m => m.Reason))}. Sender options: {comparison.SenderOptions.Describe()}; receiver options: {comparison.ReceiverOptions.Describe()}";
                report.Findings.Add(text);
                foreach (var typeName in new[] { comparison.SenderType, comparison.ReceiverType }.Distinct())
                {
                    if (index.Resolve(typeName, "type").FirstOrDefault(t => t.FullName == typeName) is { } typeSymbol)
                    {
                        AddEvidence(candidates, index, typeSymbol, new CandidateEvidence { Category = EvidenceCategories.Serialization, Weight = weight, Origin = onPath.Count > 0, Text = text, NodeId = site.Node.Id }, "state origin");
                    }
                }
                foreach (var siteSymbol in new[] { comparison.SenderMember, comparison.ReceiverMember }.OfType<SymbolRecord>().Distinct())
                {
                    AddEvidence(candidates, index, siteSymbol, new CandidateEvidence { Category = EvidenceCategories.Serialization, Weight = onPath.Count > 0 ? ContractSiteWeight : ContractOffPathWeight, Origin = onPath.Count > 0, Text = text, NodeId = site.Node.Id }, "state origin");
                }
            }
            // Converters that handle types in the payload.
            var receiverTypeName = site.Type is null ? null : FlowContext.GenericArgument(site.Type) ?? site.Type;
            if (receiverTypeName is not null && ctx.ResolveType(receiverTypeName, site.Member.Symbol).FirstOrDefault() is { } receiverType)
            {
                var options = ContractAnalyzer.ResolveOptions(ctx, site.Member, site.OptionsExpression);
                foreach (var (converter, handled) in ContractAnalyzer.ApplicableConverters(ctx, options, receiverType, site.Member.Symbol))
                {
                    foreach (var method in index.MembersOf(converter.FullName).Where(m => m.Name is "Read" or "Write"))
                    {
                        var smell = ctx.Member(method) is { } flow ? ArithmeticSmells.IntegerDivision(ctx, flow) : null;
                        AddEvidence(candidates, index, method, new CandidateEvidence
                        {
                            Category = EvidenceCategories.Serialization, Weight = ConverterWeight + (smell is null ? 0 : IntegerDivisionWeight), Origin = smell is not null, NodeId = site.Node.Id,
                            Text = $"custom converter {converter.Name} ({handled}) runs for {receiverType.Name} values read at {ProvenanceTracer.ShortName(site.Member.Symbol)}{(smell is null ? "" : "; " + smell)}",
                        }, smell is null ? "transformation" : "state origin");
                    }
                }
            }
        }

        // ---- Configuration provenance.
        var appsettings = index.Files.Keys.Where(k => Path.GetFileName(k).Equals("appsettings.json", StringComparison.OrdinalIgnoreCase)).OrderBy(k => k.Length).FirstOrDefault();
        foreach (var site in tracer.Hooks.Configurations.DistinctBy(c => (c.Key ?? c.OptionsType) + string.Join('.', c.Path)))
        {
            var key = site.Key ?? (site.OptionsType is null ? null : ConfigAnalyzer.ResolveOptionsKey(index, site.OptionsType, site.Path));
            if (key is null || key.StartsWith("env:", StringComparison.Ordinal))
            {
                continue;
            }
            var provenance = ConfigAnalyzer.Trace(index, key);
            report.Findings.AddRange(provenance.Findings);
            AddEvidence(candidates, index, site.Member.Symbol, new CandidateEvidence
            {
                Category = EvidenceCategories.Configuration, Weight = ConfigReaderWeight, NodeId = site.Node.Id,
                Text = $"reads configuration `{key}`" + (provenance.Findings.Count > 0 ? ": " + provenance.Findings[0] : ""),
            }, "propagation", site.Node.Depth);
            if (provenance.Override is { } layer)
            {
                AddCandidate(candidates, $"config:{layer.File}#{key}", $"{Path.GetFileName(layer.File)} overrides {key} = {layer.Value}", "configuration", layer.File, layer.Line, $"{layer.File}#{key}",
                    new CandidateEvidence { Category = EvidenceCategories.Configuration, Weight = provenance.SuspiciousOverride ? ConfigOverrideWeight : ConfigOverrideWeight - 3, Origin = true, NodeId = site.Node.Id, Text = string.Join("; ", provenance.Findings) });
            }
            else if (provenance.Missing)
            {
                AddCandidate(candidates, $"config:missing#{key}", $"configuration key {key} is missing", "configuration", appsettings, null, $"{appsettings ?? "appsettings.json"}#{key} (missing)",
                    new CandidateEvidence { Category = EvidenceCategories.Configuration, Weight = ConfigMissingWeight, Origin = true, NodeId = site.Node.Id, Text = string.Join("; ", provenance.Findings) });
            }
        }

        // ---- Stale state.
        foreach (var site in tracer.Hooks.KeyedState.DistinctBy(k => k.Type.FullName + k.Field))
        {
            foreach (var finding in StaleStateAnalyzer.Analyze(ctx, site))
            {
                AddEvidence(candidates, index, finding.Invalidator, new CandidateEvidence { Category = EvidenceCategories.StaleState, Weight = StaleWeight, Origin = true, NodeId = site.Node.Id, Text = finding.Description }, "state origin");
                report.Findings.Add(finding.Description);
            }
        }

        // ---- Arithmetic smells on the path.
        foreach (var symbol in tracer.Hooks.Visited.Where(s => !s.IsTest && !index.IsTestProject(s.Project)))
        {
            if (ctx.Member(symbol) is { } flow && ArithmeticSmells.IntegerDivision(ctx, flow) is { } smell)
            {
                AddEvidence(candidates, index, symbol, new CandidateEvidence { Category = EvidenceCategories.Arithmetic, Weight = IntegerDivisionWeight, Origin = true, Text = smell }, "state origin");
            }
        }

        // ---- Data anomalies in inputs used by the failing tests.
        DataEvidence(ctx, candidates, report, testMembers, failureText, tracer, ct);

        // ---- Finalise.
        foreach (var candidate in candidates.Values)
        {
            var positive = candidate.Evidence.Where(e => !e.Contradicts).GroupBy(e => e.Category).Sum(g => g.Max(e => e.Weight));
            var negative = candidate.Evidence.Where(e => e.Contradicts).GroupBy(e => e.Category).Sum(g => g.Min(e => e.Weight));
            candidate.Score = Math.Max(0, positive + negative);
            candidate.Connected = candidate.Evidence.Any(e => e.Category != EvidenceCategories.Stack && e.Category != EvidenceCategories.Wrapper && !e.Contradicts);
            var hasOrigin = candidate.Evidence.Any(e => e.Origin && !e.Contradicts);
            candidate.Strength = hasOrigin && candidate.Connected && candidate.Score >= 5 ? "Strong" : candidate.Score >= 4 || candidate.Connected && candidate.Score >= 3 ? "Moderate" : "Weak";
            if (hasOrigin)
            {
                candidate.Role = "state origin";
            }
            else if (candidate.Evidence.Any(e => e.Category == EvidenceCategories.Wrapper))
            {
                candidate.Role = "wrapper";
            }
        }
        report.Candidates = candidates.Values
            .OrderByDescending(c => c.Score)
            .ThenByDescending(c => c.Strength switch { "Strong" => 2, "Moderate" => 1, _ => 0 })
            .ThenByDescending(c => c.MaxDepth)
            .ThenBy(c => c.Key, StringComparer.Ordinal)
            .Take(12)
            .ToList();
        report.Trace = PrimaryTrace(report.Candidates.FirstOrDefault(), tracer.Nodes);
        report.Experiments = Experiments(report.Candidates.Take(4).ToList(), request.Failures.FirstOrDefault()?.TestName);
        report.Ambiguities = tracer.Nodes.Where(n => n.Confidence == "ambiguous").Select(n => n.Title).Distinct().Take(10).ToList();
        budget.SymbolsConsidered.UnionWith(tracer.Hooks.Visited.Select(v => v.FullName));
        report.Stats = budget.Snapshot();
        report.Stats.ElapsedMs = sw.ElapsedMilliseconds;
        var top = report.Candidates.FirstOrDefault();
        report.Summary = top is null
            ? "No root-cause candidate could be derived from the failure."
            : $"{top.Strength} evidence: {top.Title} ({top.Role}). {(top.Strength == "Strong" ? "" : "Root cause not yet confirmed — evidence is incomplete. ")}Not confirmed until an experiment or counterfactual verifies it.";
        return report;
    }

    // ------------------------------------------------------------------ start points

    private static List<(MemberFlow Member, List<Token> Tokens, int Line, string Title)> StartPoints(FlowContext ctx, List<FrameInfo> frames, bool assertion, ExceptionInfo? innermost, string text)
    {
        var starts = new List<(MemberFlow, List<Token>, int, string)>();
        var frame = assertion ? frames.FirstOrDefault(f => f.IsTest) ?? frames.FirstOrDefault() : frames.FirstOrDefault(f => !f.IsTest) ?? frames.FirstOrDefault();
        if (frame?.Symbol is null || ctx.Member(frame.Symbol) is not { } member)
        {
            return starts;
        }
        var lineText = ctx.SourceLine(frame.File!, frame.Line) ?? "";
        var lineTokens = ExpandInterpolations(CSharpLexer.Tokenize(lineText), frame.Line);
        var type = innermost?.Type ?? "";

        if (assertion)
        {
            var call = member.Calls.FirstOrDefault(c => c.Line == frame.Line && c.ReceiverText is "Assert" or "StringAssert" or "CollectionAssert" or "ClassicAssert");
            if (call is not null && call.Args.Count > 0)
            {
                var actualIndex = call.Callee is "AreEqual" or "AreNotEqual" or "Equal" or "NotEqual" or "AreSame" or "AreNotSame" or "Same" or "NotSame" or "AreEquivalent" or "Equivalent" && call.Args.Count >= 2 ? 1 : 0;
                starts.Add((member, call.Args[actualIndex].Tokens, frame.Line, $"assertion {call.ReceiverText}.{call.Callee} failed on `{call.Args[actualIndex].Text}`"));
                return starts;
            }
        }
        if (type.EndsWith("NullReferenceException", StringComparison.Ordinal))
        {
            foreach (var component in DereferencedComponents(ctx, member, lineTokens, frame.Line).Take(2))
            {
                starts.Add((member, component, frame.Line, $"`{Expr.Render(component)}` is dereferenced here and may be null (NullReferenceException)"));
            }
            if (starts.Count > 0)
            {
                return starts;
            }
        }
        if (type.EndsWith("DivideByZeroException", StringComparison.Ordinal))
        {
            var slash = lineTokens.FindIndex(t => t.IsPunct('/') || t.IsPunct('%'));
            if (slash >= 0)
            {
                var end = slash + 1;
                while (end < lineTokens.Count && (lineTokens[end].Kind == TokenKind.Identifier || lineTokens[end].IsPunct('.') || lineTokens[end].Is("?.")))
                {
                    end++;
                }
                var divisor = lineTokens.GetRange(slash + 1, end - slash - 1);
                if (divisor.Count > 0)
                {
                    starts.Add((member, divisor, frame.Line, $"divisor `{Expr.Render(divisor)}` is zero (DivideByZeroException)"));
                    return starts;
                }
            }
        }
        var parameter = ParameterName().Match(text);
        if (parameter.Success && member.Parameter(parameter.Groups[1].Value) is { } p && frame == frames.FirstOrDefault(f => !f.IsTest))
        {
            starts.Add((member, [new Token(TokenKind.Identifier, p.Name, frame.Line)], frame.Line, $"argument `{p.Name}` is invalid ({ShortType(type)})"));
            return starts;
        }
        // Thrown by application code: the values in the throw and the guarding condition.
        var thrown = member.Throws.Where(t => Math.Abs(t.Line - frame.Line) <= 1).ToList();
        foreach (var t in thrown)
        {
            foreach (var value in ValueExpressions(ExpandInterpolations(t.Arguments.Tokens, t.Line)).Take(3))
            {
                starts.Add((member, value, t.Line, $"`{Expr.Render(value)}` is involved in the thrown {t.Type}"));
            }
            var guard = member.Conditions.Where(c => c.Line <= t.Line && c.Line >= t.Line - 6).OrderByDescending(c => c.Line).FirstOrDefault();
            if (guard is not null)
            {
                foreach (var value in ValueExpressions(guard.Condition.Tokens).Take(3))
                {
                    starts.Add((member, value, guard.Line, $"`{Expr.Render(value)}` decides the failing condition `{guard.Condition.Text}`"));
                }
            }
        }
        if (starts.Count > 0)
        {
            return starts;
        }
        foreach (var value in ValueExpressions(StatementTokens(lineTokens)).Take(4))
        {
            starts.Add((member, value, frame.Line, $"`{Expr.Render(value)}` is used where {ShortType(type)} is raised"));
        }
        return starts;
    }

    /// <summary>Removes a leading declaration ("public static string Render(Book book) =>") from a line.</summary>
    private static List<Token> StatementTokens(List<Token> tokens)
    {
        var arrow = tokens.FindIndex(t => t.Is("=>"));
        return arrow >= 0 && tokens.Take(arrow).Any(t => t.Kind == TokenKind.Keyword && t.Text is "public" or "private" or "internal" or "protected" or "static") ? tokens.Skip(arrow + 1).ToList() : tokens;
    }

    /// <summary>Candidate values: call arguments, assignment sources, member-access chains (deduplicated, longest first).</summary>
    private static List<List<Token>> ValueExpressions(List<Token> tokens)
    {
        var values = new List<List<Token>>();
        var t = tokens.Where(x => !x.IsPunct(';')).ToList();
        var eq = t.FindIndex(x => x.IsPunct('=') );
        if (eq > 0 && eq + 1 < t.Count && !t[eq + 1].IsPunct('=') && !t[eq - 1].IsPunct('!') && !t[eq - 1].IsPunct('<') && !t[eq - 1].IsPunct('>'))
        {
            var end = FlowParser.ExpressionEnd(t, eq + 1, stopAtComma: true, t.Count);
            values.Add(t.GetRange(eq + 1, end - eq - 1));
        }
        for (var i = 0; i < t.Count; i++)
        {
            if (t[i].Kind != TokenKind.Identifier)
            {
                continue;
            }
            var start = i;
            var k = i;
            while (k + 2 < t.Count && (t[k + 1].IsPunct('.') || t[k + 1].Is("?.") || t[k + 1].IsPunct('!') && t[k + 2].IsPunct('.')) )
            {
                k += t[k + 1].IsPunct('!') ? 3 : 2;
                if (k >= t.Count || t[k].Kind != TokenKind.Identifier)
                {
                    k -= 2;
                    break;
                }
            }
            if (k + 1 < t.Count && t[k + 1].IsPunct('('))
            {
                var close = FlowParser.Match(t, k + 1, '(', ')');
                var (args, _, _) = FlowParser.SplitArguments(t, k + 1, close);
                values.AddRange(args.Where(a => a.Tokens.Count > 0 && !(a.Tokens.Count == 1 && a.Tokens[0].Kind is TokenKind.String or TokenKind.Number)).Select(a => a.Tokens));
                i = k;
                continue;
            }
            var chain = t.GetRange(start, k - start + 1);
            if (!(chain.Count == 1 && char.IsUpper(chain[0].Text[0])))
            {
                values.Add(chain);
            }
            i = k;
        }
        return values.DistinctBy(v => Expr.Render(v)).OrderByDescending(v => v.Count).ToList();
    }

    /// <summary>Prefixes of member-access chains that are dereferenced on the crash line, most suspicious first.</summary>
    private static List<List<Token>> DereferencedComponents(FlowContext ctx, MemberFlow member, List<Token> tokens, int line)
    {
        var results = new List<(List<Token> Tokens, int Priority)>();
        var t = StatementTokens(tokens);
        for (var i = 0; i < t.Count; i++)
        {
            if (t[i].Kind != TokenKind.Identifier || i > 0 && (t[i - 1].IsPunct('.') || t[i - 1].Is("?.")))
            {
                continue;
            }
            var chain = new List<Token> { t[i] };
            var k = i;
            while (k + 1 < t.Count)
            {
                var forgiving = t[k + 1].IsPunct('!');
                var dotIndex = forgiving ? k + 2 : k + 1;
                if (dotIndex >= t.Count || !(t[dotIndex].IsPunct('.')))
                {
                    break;
                }
                if (dotIndex + 1 >= t.Count || t[dotIndex + 1].Kind != TokenKind.Identifier)
                {
                    break;
                }
                // "chain" is dereferenced by the following '.'.
                var type = ctx.ExpressionType(member, chain, line);
                var priority = forgiving ? 3 : FlowContext.IsNullableDeclared(type) ? 2 : 1;
                if (!(chain.Count == 1 && ctx.ResolveType(chain[0].Text, member.Symbol).Count > 0 && member.Parameter(chain[0].Text) is null && !member.LocalsNamed(chain[0].Text).Any()))
                {
                    results.Add((chain.ToList(), priority));
                }
                chain.Add(t[dotIndex]);
                chain.Add(t[dotIndex + 1]);
                k = dotIndex + 1;
            }
            i = k;
        }
        return results.OrderByDescending(r => r.Priority).ThenBy(r => r.Tokens.Count).Select(r => r.Tokens).DistinctBy(r => Expr.Render(r)).ToList();
    }

    private static List<Token> ExpandInterpolations(List<Token> tokens, int line)
    {
        var expanded = new List<Token>();
        foreach (var t in tokens)
        {
            if (t.Kind == TokenKind.String && t.Text.Contains('{'))
            {
                foreach (var hole in ProvenanceTracer.InterpolationHoles(t.Text))
                {
                    expanded.Add(new Token(TokenKind.Punct, "(", line));
                    expanded.AddRange(hole.Select(h => h with { Line = line }));
                    expanded.Add(new Token(TokenKind.Punct, ")", line));
                    expanded.Add(new Token(TokenKind.Punct, ";", line));
                }
                continue;
            }
            expanded.Add(t);
        }
        return expanded;
    }

    // ------------------------------------------------------------------ data

    private static void DataEvidence(FlowContext ctx, Dictionary<string, CauseCandidate> candidates, RcaReport report, List<MemberFlow> tests, string failureText, ProvenanceTracer tracer, CancellationToken ct)
    {
        var fileNames = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var test in tests)
        {
            foreach (var t in test.Body.Where(t => t.Kind == TokenKind.String && t.Text.EndsWith(".json", StringComparison.OrdinalIgnoreCase)))
            {
                fileNames.Add(Path.GetFileName(t.Text));
            }
        }
        if (fileNames.Count == 0)
        {
            return;
        }
        var jsonPath = JsonPathInText().Match(failureText);
        foreach (var name in fileNames.Take(2))
        {
            var file = ctx.Index.Files.Keys.FirstOrDefault(k => Path.GetFileName(k).Equals(name, StringComparison.OrdinalIgnoreCase));
            if (file is null)
            {
                continue;
            }
            var full = Path.Combine(ctx.Index.Root, file);
            if (new FileInfo(full).Length > 512L * 1024 * 1024)
            {
                continue;
            }
            ctx.Budget.FilesOpened++;
            if (jsonPath.Success)
            {
                var recordPath = RecordOf().Match(jsonPath.Value) is { Success: true } r ? r.Value : jsonPath.Value;
                AddCandidate(candidates, $"data:{file}#{recordPath}", $"record {recordPath} in {Path.GetFileName(file)}", "data", file, null, $"{file}#{recordPath}",
                    new CandidateEvidence { Category = EvidenceCategories.Data, Weight = DataCorrelatedWeight, Origin = true, Text = $"the failure names JSON path {jsonPath.Value} in {Path.GetFileName(file)} (input used by the failing test)" });
            }
            AnomalyReport anomalies;
            try
            {
                var arrayPath = jsonPath.Success ? ArrayOf().Match(jsonPath.Value).Groups[1].Value : null;
                anomalies = JsonAnomalyDetector.Scan(full, string.IsNullOrEmpty(arrayPath) ? null : arrayPath, 25, ct);
            }
            catch (Exception ex) when (ex is System.Text.Json.JsonException or IOException or FormatException)
            {
                continue;
            }
            JsonAnomalyDetector.Correlate(anomalies, failureText);
            var tracedProperties = tracer.Nodes.Where(n => n.Path is not null).SelectMany(n => n.Path!.Split('.')).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var correlated = anomalies.Anomalies.Where(a => a.CorrelatedWithFailure).Take(3).ToList();
            foreach (var anomaly in correlated)
            {
                var onPath = tracedProperties.Contains(anomaly.Field.Split('.')[^1]);
                AddCandidate(candidates, $"data:{file}#{anomaly.Path}", $"record {anomaly.Path} in {Path.GetFileName(file)}: {anomaly.Kind} {anomaly.Field}", "data", file, null, $"{file}#{anomaly.Path}",
                    new CandidateEvidence
                    {
                        Category = EvidenceCategories.Data, Weight = DataCorrelatedWeight, Origin = true,
                        Text = $"{anomaly.Reason} — the value appears in the failure message{(onPath ? $" and {anomaly.Field} is on the traced path" : "")}",
                    });
                report.Findings.Add($"Data anomaly correlated with the failure: {anomaly.Path} {anomaly.Reason}");
            }
            if (correlated.Count == 0 && anomalies.Anomalies.FirstOrDefault() is { } first)
            {
                AddCandidate(candidates, $"data:{file}#{first.Path}", $"record {first.Path} in {Path.GetFileName(file)}: {first.Kind} {first.Field}", "data", file, null, $"{file}#{first.Path}",
                    new CandidateEvidence { Category = EvidenceCategories.Data, Weight = 1, Text = first.Reason + " (not linked to the failure)" });
            }
        }
    }

    // ------------------------------------------------------------------ helpers

    private static List<FrameInfo> Map(FlowContext ctx, List<StackFrame> frames)
        => frames.Where(f => !f.IsFramework).Select(f =>
        {
            var (file, symbol) = FailureMapper.Map(ctx.Index, f.File, f.Line, f.Type, f.MemberName);
            var line = f.Line ?? symbol?.StartLine ?? 0;
            return new FrameInfo { Frame = f, Symbol = symbol, File = file ?? symbol?.File, Line = line, IsTest = symbol is not null && (symbol.IsTest || ctx.Index.IsTestProject(symbol.Project)) };
        }).ToList();

    private static MemberFlow? FindTest(FlowContext ctx, string? name)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            return null;
        }
        var symbol = ctx.Index.Resolve(name).FirstOrDefault(s => s.IsTest) ?? ctx.Index.Resolve(name.Split('.')[^1]).FirstOrDefault(s => s.IsTest);
        return symbol is null ? null : ctx.Member(symbol);
    }

    private static bool IsAssertion(string text, List<ExceptionInfo> exceptions)
        => exceptions.Any(e => e.Type.Contains("Assert", StringComparison.Ordinal) || e.Type.EndsWith("UnitTestAssertException", StringComparison.Ordinal))
           || AssertionText().IsMatch(text) && !exceptions.Any(e => e.Type.StartsWith("System.", StringComparison.Ordinal) && !e.Type.Contains("Assert", StringComparison.Ordinal) && e.Frames.Count > 0);

    private static void AddEvidence(Dictionary<string, CauseCandidate> candidates, CodeIndex index, SymbolRecord symbol, CandidateEvidence evidence, string role, int depth = 0)
    {
        if (symbol.IsTest || index.IsTestProject(symbol.Project))
        {
            return;
        }
        if (!candidates.TryGetValue(symbol.FullName, out var candidate))
        {
            candidate = new CauseCandidate
            {
                Key = symbol.FullName, Title = $"{symbol.Kind} {ProvenanceTracer.ShortName(symbol)}", Kind = SymbolKinds.IsType(symbol.Kind) ? "code" : "code",
                Symbol = symbol.FullName, File = symbol.File, Line = symbol.StartLine, Location = $"{symbol.FullName} ({symbol.File}:{symbol.StartLine})", Role = role,
            };
            candidates[symbol.FullName] = candidate;
        }
        candidate.MaxDepth = Math.Max(candidate.MaxDepth, depth);
        if (candidate.Role is "propagation" or "throw site" && role is "transformation" or "state origin")
        {
            candidate.Role = role;
        }
        if (!candidate.Evidence.Any(e => e.Category == evidence.Category && e.Text == evidence.Text))
        {
            candidate.Evidence.Add(evidence);
        }
    }

    private static void AddCandidate(Dictionary<string, CauseCandidate> candidates, string key, string title, string kind, string? file, int? line, string location, CandidateEvidence evidence)
    {
        if (!candidates.TryGetValue(key, out var candidate))
        {
            candidate = new CauseCandidate { Key = key, Title = title, Kind = kind, File = file, Line = line, Location = location, Role = "state origin" };
            candidates[key] = candidate;
        }
        if (!candidate.Evidence.Any(e => e.Text == evidence.Text))
        {
            candidate.Evidence.Add(evidence);
        }
    }

    private static List<ProvenanceNode> PrimaryTrace(CauseCandidate? top, List<ProvenanceNode> nodes)
    {
        if (top is null)
        {
            return [];
        }
        var byId = nodes.ToDictionary(n => n.Id);
        var nodeId = top.Evidence.Where(e => e.NodeId is not null && !e.Contradicts).OrderByDescending(e => e.Origin).ThenByDescending(e => e.Weight).Select(e => e.NodeId).FirstOrDefault()
                     ?? nodes.Where(n => n.Symbol == top.Symbol).OrderByDescending(n => n.Depth).Select(n => (int?)n.Id).FirstOrDefault();
        if (nodeId is null || !byId.TryGetValue(nodeId.Value, out var node))
        {
            return [];
        }
        var chain = new List<ProvenanceNode>();
        for (var current = node; current is not null && chain.Count < 30; current = current.ParentId >= 0 && byId.TryGetValue(current.ParentId, out var parent) ? parent : null)
        {
            chain.Add(current);
        }
        return chain; // origin first, failure last
    }

    private static List<ProposedExperiment> Experiments(List<CauseCandidate> top, string? testName)
    {
        var experiments = new List<ProposedExperiment>();
        var test = testName ?? "the failing test";
        foreach (var c in top)
        {
            var others = string.Join(", ", top.Where(o => o.Key != c.Key).Take(2).Select(o => o.Title));
            var categories = c.Evidence.Where(e => !e.Contradicts).Select(e => e.Category).ToHashSet();
            ProposedExperiment e;
            if (categories.Contains(EvidenceCategories.Configuration) && c.Kind == "configuration")
            {
                e = new ProposedExperiment { Description = $"In a scratch copy, change only {c.Location} (set the base/expected value or add the key) and rerun {test}.", Tool = "counterfactual_run", Cost = "cheap" };
            }
            else if (categories.Contains(EvidenceCategories.Data))
            {
                e = new ProposedExperiment { Description = $"In a scratch copy, correct {c.Location} to match the typical records and rerun {test}. If the failure disappears, decide whether to fix the producer or harden the reader.", Tool = "counterfactual_run", Cost = "cheap" };
            }
            else if (categories.Contains(EvidenceCategories.Serialization))
            {
                e = new ProposedExperiment { Description = $"Round-trip the payload: serialize with the sender's options and deserialize with the receiver's (compare_json_contracts), then in a scratch copy align the names/converter at {c.Title} and rerun {test}.", Tool = "compare_json_contracts", Cost = "cheap" };
            }
            else if (categories.Contains(EvidenceCategories.Concurrency))
            {
                e = new ProposedExperiment { Description = $"Run {test} repeatedly (e.g. 20×); then in a scratch copy make {c.Title} atomic (lock/SemaphoreSlim/Interlocked) and rerun. Disappearance under the guard supports the race.", Tool = "counterfactual_run", Cost = "moderate" };
            }
            else if (categories.Contains(EvidenceCategories.DependencyInjection))
            {
                e = new ProposedExperiment { Description = $"In a scratch copy change the singleton registration in the chain for {c.Title} to Scoped (or resolve the dependency per call via IServiceScopeFactory) and rerun {test}.", Tool = "counterfactual_run", Cost = "cheap" };
            }
            else if (categories.Contains(EvidenceCategories.StaleState))
            {
                e = new ProposedExperiment { Description = $"Focused test: update the entity through {c.Title}, then read it back through the cached path; in a scratch copy use the reader's key in the invalidation and rerun {test}.", Tool = "counterfactual_run", Cost = "cheap" };
            }
            else if (categories.Contains(EvidenceCategories.NullOrigin))
            {
                e = new ProposedExperiment { Description = $"Focused test: build the object through {c.Title} from input that contains the value and assert the property is non-null; then set it in a scratch copy and rerun {test}.", Tool = "counterfactual_run", Cost = "cheap" };
            }
            else if (categories.Contains(EvidenceCategories.Arithmetic) || c.Role == "transformation")
            {
                e = new ProposedExperiment { Description = $"Boundary test for {c.Title}: call it with edge inputs (first/last element, 0, 1, empty) and compare with the expected values from the specification.", Cost = "cheap" };
            }
            else
            {
                e = new ProposedExperiment { Description = $"Trace the values reaching {c.Title} (trace_value_origin); a throw site is usually not the origin.", Tool = "trace_value_origin", Cost = "cheap" };
            }
            e.Id = "X" + (experiments.Count + 1);
            e.CandidateKeys = [c.Key];
            e.Discriminates = others.Length == 0 ? $"confirms or rejects {c.Title}" : $"supports {c.Title} over {others} if the failure disappears";
            experiments.Add(e);
        }
        return experiments;
    }

    private static string Short(string fullName) => fullName.Split('.')[^1];

    private static string ShortType(string type) => type.Split('.')[^1];

    [GeneratedRegex(@"\(Parameter '(\w+)'\)")]
    private static partial Regex ParameterName();

    [GeneratedRegex(@"Assert\.\w+ failed|Assert\.That|Expected:.*Actual:|Expected .* but ", RegexOptions.IgnoreCase)]
    private static partial Regex AssertionText();

    [GeneratedRegex(@"disposed|second operation|concurren|thread|scope|lifetime", RegexOptions.IgnoreCase)]
    private static partial Regex LifetimeWords();

    [GeneratedRegex(@"\$(?:\.[A-Za-z_][\w]*|\[\d+\])+")]
    private static partial Regex JsonPathInText();

    [GeneratedRegex(@"^\$(?:\.[A-Za-z_][\w]*)*\[\d+\]")]
    private static partial Regex RecordOf();

    [GeneratedRegex(@"^(\$(?:\.[A-Za-z_][\w]*)*)\[\d+\]")]
    private static partial Regex ArrayOf();
}
