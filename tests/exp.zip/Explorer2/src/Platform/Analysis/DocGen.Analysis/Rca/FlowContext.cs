using DocGen.Analysis.CSharp;
using DocGen.Analysis.Flow;
using DocGen.Analysis.Indexing;

namespace DocGen.Analysis.Rca;

/// <summary>
/// Retrieval layer for one analysis: parses files on demand (never the whole repository), resolves types and call
/// targets conservatively, and accounts every file, symbol and source line in the <see cref="RcaBudget"/>.
/// </summary>
public sealed class FlowContext(CodeIndex index, RcaBudget budget)
{
    private readonly Dictionary<string, FileFlow?> _files = new(StringComparer.OrdinalIgnoreCase);
    private readonly HashSet<SymbolRecord> _linesCounted = new(ReferenceEqualityComparer.Instance);

    public CodeIndex Index => index;
    public RcaBudget Budget => budget;

    public FileFlow? File(string path)
    {
        if (_files.TryGetValue(path, out var cached))
        {
            return cached;
        }
        if (_files.Count >= budget.MaxFiles || !index.Files.TryGetValue(path, out var entry) || !entry.Parsed)
        {
            if (_files.Count >= budget.MaxFiles)
            {
                budget.Exhausted = true;
            }
            _files[path] = null;
            return null;
        }
        FileFlow? flow = null;
        try
        {
            var text = System.IO.File.ReadAllText(Path.Combine(index.Root, path));
            flow = FlowParser.Parse(path, text, entry.Symbols);
            budget.FilesOpened++;
        }
        catch (IOException)
        {
        }
        _files[path] = flow;
        return flow;
    }

    public MemberFlow? Member(SymbolRecord symbol)
    {
        var file = File(symbol.File);
        if (file is null || !file.Members.TryGetValue(symbol, out var member))
        {
            return null;
        }
        budget.SymbolsConsidered.Add(symbol.FullName);
        if (_linesCounted.Add(symbol))
        {
            budget.SourceLinesRetrieved += member.SourceLines;
        }
        return member;
    }

    public TypeFlow? TypeFlowOf(SymbolRecord type) => File(type.File) is { } f && f.Types.TryGetValue(type, out var t) ? t : null;

    public string? SourceLine(string file, int line)
    {
        var flow = File(file);
        if (flow is null || line < 1 || line > flow.Lines.Length)
        {
            return null;
        }
        budget.SourceLinesRetrieved++;
        return flow.Lines[line - 1];
    }

    /// <summary>The member whose range contains the line (innermost), with its flow.</summary>
    public MemberFlow? MemberAt(string file, int line)
    {
        var symbol = index.Files.TryGetValue(file, out var entry)
            ? entry.Symbols.Where(s => !SymbolKinds.IsType(s.Kind) && s.StartLine <= line && line <= s.EndLine).OrderBy(s => s.EndLine - s.StartLine).FirstOrDefault()
            : null;
        return symbol is null ? null : Member(symbol);
    }

    // ------------------------------------------------------------------ types

    public SymbolRecord? ContainingType(SymbolRecord member)
        => member.Container is null ? null : index.Resolve(member.Container, "type").FirstOrDefault(t => t.FullName == member.Container);

    /// <summary>Types named <paramref name="typeText"/> (generic arguments, nullability and arrays stripped), preferring the context's namespace.</summary>
    public List<SymbolRecord> ResolveType(string? typeText, SymbolRecord? context)
    {
        if (string.IsNullOrWhiteSpace(typeText))
        {
            return [];
        }
        var name = BareName(typeText);
        var types = index.ByName(name).Where(s => SymbolKinds.IsType(s.Kind)).ToList();
        if (types.Count > 1 && context is not null)
        {
            var sameNamespace = types.Where(t => t.Namespace == context.Namespace).ToList();
            if (sameNamespace.Count > 0)
            {
                return sameNamespace;
            }
        }
        return types;
    }

    public static string BareName(string typeText)
    {
        var text = typeText.Trim().TrimEnd('?');
        if (text.EndsWith("[]", StringComparison.Ordinal))
        {
            text = text[..^2];
        }
        var lt = text.IndexOf('<');
        var head = lt >= 0 ? text[..lt] : text;
        var dot = head.LastIndexOf('.');
        return dot >= 0 ? head[(dot + 1)..] : head;
    }

    /// <summary>"Task&lt;List&lt;Order&gt;&gt;" → "List&lt;Order&gt;"; "List&lt;Order&gt;" (element) → "Order"; "Dictionary&lt;K,V&gt;" (element) → "V".</summary>
    public static string? GenericArgument(string? typeText, bool last = true)
    {
        if (typeText is null)
        {
            return null;
        }
        var t = typeText.Trim().TrimEnd('?');
        if (t.EndsWith("[]", StringComparison.Ordinal))
        {
            return t[..^2];
        }
        var lt = t.IndexOf('<');
        var gt = t.LastIndexOf('>');
        if (lt < 0 || gt < lt)
        {
            return null;
        }
        var inner = t[(lt + 1)..gt];
        var parts = new List<string>();
        var depth = 0;
        var startPart = 0;
        for (var i = 0; i < inner.Length; i++)
        {
            if (inner[i] == '<')
            {
                depth++;
            }
            else if (inner[i] == '>')
            {
                depth--;
            }
            else if (inner[i] == ',' && depth == 0)
            {
                parts.Add(inner[startPart..i].Trim());
                startPart = i + 1;
            }
        }
        parts.Add(inner[startPart..].Trim());
        return last ? parts[^1] : parts[0];
    }

    public static string UnwrapTask(string? typeText)
    {
        if (typeText is null)
        {
            return "";
        }
        var bare = BareName(typeText);
        return bare is "Task" or "ValueTask" ? GenericArgument(typeText) ?? "void" : typeText;
    }

    public static bool IsNullableDeclared(string? typeText) => typeText is not null && typeText.Trim().EndsWith('?');

    /// <summary>Members named <paramref name="name"/> on a type or its bases (bounded).</summary>
    public List<SymbolRecord> MembersNamed(SymbolRecord type, string name)
    {
        var result = new List<SymbolRecord>();
        var queue = new Queue<SymbolRecord>([type]);
        var seen = new HashSet<string>(StringComparer.Ordinal);
        while (queue.Count > 0 && seen.Count < 8)
        {
            var t = queue.Dequeue();
            if (!seen.Add(t.FullName))
            {
                continue;
            }
            result.AddRange(index.MembersOf(t.FullName).Where(m => m.Name == name));
            foreach (var b in t.Bases)
            {
                foreach (var baseType in ResolveType(b, t))
                {
                    queue.Enqueue(baseType);
                }
            }
        }
        return result;
    }

    /// <summary>Declared type of an identifier inside a member (local, parameter, primary-constructor parameter, field/property).</summary>
    public string? DeclaredType(MemberFlow member, string identifier, int line, int depth = 0)
    {
        var local = member.LocalsNamed(identifier).Where(l => l.Line <= line || line <= 0).LastOrDefault() ?? member.LocalsNamed(identifier).FirstOrDefault();
        if (local is not null)
        {
            if (local.Type is not null)
            {
                return local.Type;
            }
            if (local.Init is not null && depth < 4)
            {
                var init = ExpressionType(member, local.Init.Tokens, line, depth + 1);
                return local.ElementOf ? GenericArgument(init) : init;
            }
            return null;
        }
        if (member.Parameter(identifier) is { } p)
        {
            return p.Type;
        }
        if (ContainingType(member.Symbol) is { } type)
        {
            if (TypeFlowOf(type)?.PrimaryParameters.FirstOrDefault(pp => pp.Name == identifier) is { } primary)
            {
                return primary.Type;
            }
            var field = MembersNamed(type, identifier).FirstOrDefault(m => m.Kind is SymbolKinds.Field or SymbolKinds.Property);
            if (field?.ReturnType is { } ft)
            {
                return ft;
            }
            if (identifier == "this")
            {
                return type.Name;
            }
        }
        return null;
    }

    /// <summary>Best-effort static type of an expression; null when unknown (callers must treat that as ambiguous).</summary>
    public string? ExpressionType(MemberFlow member, List<Token> tokens, int line, int depth = 0)
    {
        if (depth > 6 || tokens.Count == 0)
        {
            return null;
        }
        var t = Normalize(tokens);
        if (t.Count == 0)
        {
            return null;
        }
        if (t.Count == 1)
        {
            return t[0].Kind switch
            {
                TokenKind.String => "string",
                TokenKind.Number => t[0].Text.EndsWith('m') || t[0].Text.EndsWith('M') ? "decimal" : t[0].Text.Contains('.') ? "double" : "int",
                TokenKind.Keyword when t[0].Text is "true" or "false" => "bool",
                _ => t[0].Kind == TokenKind.Identifier ? DeclaredType(member, t[0].Text, line, depth + 1) : null,
            };
        }
        if (t[0].Is("new") && t.Count > 1 && t[1].Kind == TokenKind.Identifier)
        {
            return t[1].Text;
        }
        var segments = Chain.Parse(t);
        if (segments.Count == 0)
        {
            return null;
        }
        string? current;
        var first = segments[0];
        var startIndex = 1;
        if (first.Kind == SegmentKind.Identifier)
        {
            current = DeclaredType(member, first.Name, line, depth + 1);
            if (current is null && ResolveType(first.Name, member.Symbol).Count > 0)
            {
                current = "static:" + first.Name;
            }
        }
        else if (first.Kind == SegmentKind.Call)
        {
            // Unqualified call on this type.
            var target = ContainingType(member.Symbol) is { } ct ? MembersNamed(ct, first.Name).FirstOrDefault() : null;
            current = UnwrapTask(target?.ReturnType);
        }
        else
        {
            return null;
        }
        for (var i = startIndex; i < segments.Count && current is not null; i++)
        {
            var seg = segments[i];
            if (seg.Kind == SegmentKind.Index)
            {
                current = GenericArgument(current);
                continue;
            }
            var isStatic = current.StartsWith("static:", StringComparison.Ordinal);
            var typeName = isStatic ? current[7..] : current;
            var type = ResolveType(typeName, member.Symbol).FirstOrDefault();
            if (type is null)
            {
                return null;
            }
            var m = MembersNamed(type, seg.Name).FirstOrDefault();
            current = m?.ReturnType is { } rt ? (seg.Kind == SegmentKind.Call ? UnwrapTask(rt) : rt) : null;
        }
        return current?.StartsWith("static:", StringComparison.Ordinal) == true ? null : current;
    }

    /// <summary>
    /// Source members a call can reach. Uses the receiver's static type when known (semantic-like), else falls back to
    /// same-named members with a compatible parameter count and reports the result as ambiguous.
    /// </summary>
    public (List<SymbolRecord> Targets, bool Ambiguous) ResolveCall(MemberFlow caller, FlowCall call)
    {
        var argCount = call.Args.Count;
        bool ArityOk(SymbolRecord s) => s.Kind != SymbolKinds.Method && s.Kind != SymbolKinds.Constructor || s.ParameterTypes.Count >= argCount - 0 && s.ParameterTypes.Count <= argCount + 3;

        if (call.IsConstructor)
        {
            var types = ResolveType(call.ConstructedType, caller.Symbol);
            var ctors = types.SelectMany(t => index.MembersOf(t.FullName).Where(m => m.Kind == SymbolKinds.Constructor)).ToList();
            return (ctors, types.Count > 1);
        }
        List<SymbolRecord> targets;
        var ambiguous = false;
        if (call.Receiver.Count == 0)
        {
            targets = ContainingType(caller.Symbol) is { } ct ? MembersNamed(ct, call.Callee).Where(ArityOk).ToList() : [];
            if (targets.Count == 0)
            {
                targets = index.ByName(call.Callee).Where(s => SymbolKinds.IsCallable(s.Kind) && ArityOk(s)).ToList();
                ambiguous = targets.Count != 1;
            }
            return (targets, ambiguous);
        }
        var receiverType = ExpressionType(caller, call.Receiver, call.Line);
        string? typeName = receiverType;
        if (receiverType is null && call.Receiver.Count == 1 && ResolveType(call.Receiver[0].Text, caller.Symbol).Count > 0)
        {
            typeName = call.Receiver[0].Text; // static call on a type
        }
        if (typeName is not null)
        {
            var types = ResolveType(typeName, caller.Symbol);
            targets = types.SelectMany(t => MembersNamed(t, call.Callee)).Where(ArityOk).ToList();
            // Interfaces: add implementations of the member (dynamic dispatch).
            foreach (var iface in types.Where(t => t.Kind == SymbolKinds.Interface).ToList())
            {
                foreach (var (impl, _) in index.AllDerived(iface.Name, 3))
                {
                    targets.AddRange(index.MembersOf(impl.FullName).Where(m => m.Name == call.Callee && ArityOk(m)));
                }
            }
            targets = targets.Distinct().ToList();
            if (targets.Count > 0 || types.Count > 0)
            {
                return (targets, types.Count > 1 || targets.Count > 1);
            }
            return ([], false); // Known external type (framework): not a source target.
        }
        targets = index.ByName(call.Callee).Where(s => SymbolKinds.IsCallable(s.Kind) && ArityOk(s) && !s.IsTest).ToList();
        return (targets, true);
    }

    internal static List<Token> Normalize(List<Token> tokens)
    {
        var t = tokens.ToList();
        var changed = true;
        while (changed && t.Count > 0)
        {
            changed = false;
            if (t[0].Is("await") || t[0].Is("checked") || t[0].Is("unchecked"))
            {
                t.RemoveAt(0);
                changed = true;
            }
            if (t.Count > 0 && t[^1].IsPunct('!'))
            {
                t.RemoveAt(t.Count - 1);
                changed = true;
            }
            if (t.Count >= 2 && t[0].IsPunct('(') && FlowParser.Match(t, 0, '(', ')') == t.Count - 1)
            {
                t = t.GetRange(1, t.Count - 2);
                changed = true;
            }
            // Cast: "(Type)expr"
            if (t.Count >= 4 && t[0].IsPunct('(') && t[1].Kind is TokenKind.Identifier or TokenKind.Keyword)
            {
                var close = FlowParser.Match(t, 0, '(', ')');
                if (close < t.Count - 1 && close <= 5 && t.Skip(1).Take(close - 1).All(x => x.Kind is TokenKind.Identifier or TokenKind.Keyword || x.Text is "." or "?" or "<" or ">" or ","))
                {
                    t = t.Skip(close + 1).ToList();
                    changed = true;
                }
            }
        }
        return t;
    }
}

public enum SegmentKind
{
    Identifier,
    Member,
    Call,
    Index,
    Other,
}

public sealed class Segment
{
    public SegmentKind Kind { get; init; }
    public string Name { get; init; } = "";
    public List<Expr> Args { get; init; } = [];
    public List<string> TypeArgs { get; init; } = [];
    public int TokenStart { get; init; }
    public int TokenEnd { get; init; }
}

/// <summary>Parses a primary expression "a.b(c)[d].e" into segments.</summary>
public static class Chain
{
    public static List<Segment> Parse(List<Token> t)
    {
        var segments = new List<Segment>();
        var i = 0;
        while (i < t.Count)
        {
            var tok = t[i];
            if (tok.IsPunct('.') || tok.Is("?.") || tok.IsPunct('!'))
            {
                i++;
                continue;
            }
            if (tok.IsPunct('['))
            {
                var close = FlowParser.Match(t, i, '[', ']');
                segments.Add(new Segment { Kind = SegmentKind.Index, Name = "[]", Args = [FlowParser.Sub(t, i + 1, close)], TokenStart = i, TokenEnd = close + 1 });
                i = close + 1;
                continue;
            }
            if (tok.Kind is TokenKind.Identifier || tok.Is("this") || tok.Is("base"))
            {
                var k = i + 1;
                var typeArgs = new List<string>();
                if (k < t.Count && t[k].IsPunct('<'))
                {
                    var gt = FlowParser.Match(t, k, '<', '>');
                    if (gt + 1 < t.Count && t[gt + 1].IsPunct('('))
                    {
                        typeArgs.Add(Expr.Render(t.GetRange(k + 1, gt - k - 1)));
                        k = gt + 1;
                    }
                }
                if (k < t.Count && t[k].IsPunct('('))
                {
                    var close = FlowParser.Match(t, k, '(', ')');
                    var (args, _, _) = FlowParser.SplitArguments(t, k, close);
                    segments.Add(new Segment { Kind = SegmentKind.Call, Name = tok.Text, Args = args, TypeArgs = typeArgs, TokenStart = i, TokenEnd = close + 1 });
                    i = close + 1;
                    continue;
                }
                segments.Add(new Segment { Kind = segments.Count == 0 ? SegmentKind.Identifier : SegmentKind.Member, Name = tok.Text, TokenStart = i, TokenEnd = i + 1 });
                i++;
                continue;
            }
            // Anything else (operators, literals in the middle) means this is not a simple chain.
            return segments.Count == 0 ? [] : [new Segment { Kind = SegmentKind.Other, Name = Expr.Render(t) }];
        }
        return segments;
    }
}
