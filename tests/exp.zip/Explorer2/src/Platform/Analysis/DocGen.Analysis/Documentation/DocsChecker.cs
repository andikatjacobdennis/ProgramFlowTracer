using System.Text.Json;
using System.Text.RegularExpressions;

namespace DocGen.Analysis.Documentation;

/// <summary>One finding of <see cref="DocsChecker"/>.</summary>
public sealed record DocsFinding(string File, int Line, string Kind, string Message, bool Problem);

/// <summary>
/// Checks a folder of Markdown user documentation against itself and against the screenshots it was written from:
/// <list type="bullet">
/// <item>links, anchors and images resolve; every image has alt text and a caption line after it;</item>
/// <item>an annotated image keeps its original, and every numbered marker on it has a matching step in the text;</item>
/// <item>numbered steps are consecutive;</item>
/// <item>every UI label written in bold (**Add and index**) appears in the text that was visible on a screenshot used by
/// that page (recorded by browser_screenshot in .capture.json), unless the sentence says it comes from the code or was
/// not verified. This catches invented or misspelt labels without needing to look at the pixels.</item>
/// </list>
/// </summary>
public static partial class DocsChecker
{
    public static IReadOnlyList<DocsFinding> Check(string folder)
    {
        var findings = new List<DocsFinding>();
        var pages = Directory.EnumerateFiles(folder, "*.md", SearchOption.AllDirectories).OrderBy(p => p, StringComparer.OrdinalIgnoreCase).ToList();
        var allCaptures = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase); // capture path → normalised visible text
        var allControls = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase); // capture path → control names (icon buttons, tooltips)
        foreach (var capture in Directory.EnumerateFiles(folder, "*.capture.json", SearchOption.AllDirectories))
        {
            var (text, controls) = ReadCapture(capture);
            allCaptures[capture] = Normalise(text);
            allControls[capture] = Normalise(controls);
        }
        var referencedImages = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var anchors = pages.ToDictionary(p => p, p => Headings(File.ReadAllLines(p)).Select(h => Slug(h.Text)).ToHashSet(), StringComparer.OrdinalIgnoreCase);

        foreach (var page in pages)
        {
            var rel = Path.GetRelativePath(folder, page).Replace('\\', '/');
            var lines = File.ReadAllLines(page);
            var dir = Path.GetDirectoryName(page)!;
            var pageCaptures = new List<string>();
            var inCode = false;
            for (var i = 0; i < lines.Length; i++)
            {
                var line = lines[i];
                if (line.TrimStart().StartsWith("```", StringComparison.Ordinal))
                {
                    inCode = !inCode;
                    continue;
                }
                if (inCode)
                {
                    continue;
                }
                foreach (Match m in LinkOrImage().Matches(line))
                {
                    var image = m.Groups["bang"].Value == "!";
                    var alt = m.Groups["text"].Value.Trim();
                    var target = m.Groups["target"].Value.Trim().Split(' ')[0].Trim('<', '>');
                    if (target.StartsWith("http:", StringComparison.OrdinalIgnoreCase) || target.StartsWith("https:", StringComparison.OrdinalIgnoreCase) || target.StartsWith("mailto:", StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }
                    var hash = target.IndexOf('#');
                    var path = hash >= 0 ? target[..hash] : target;
                    var anchor = hash >= 0 ? target[(hash + 1)..] : null;
                    var full = path.Length == 0 ? page : Path.GetFullPath(Path.Combine(dir, Uri.UnescapeDataString(path).Replace('/', Path.DirectorySeparatorChar)));
                    if (!File.Exists(full) && !Directory.Exists(full))
                    {
                        findings.Add(new(rel, i + 1, image ? "image" : "link", $"{(image ? "image" : "link")} target does not exist: {target}", true));
                        continue;
                    }
                    if (anchor is { Length: > 0 } && anchors.TryGetValue(full, out var slugs) && !slugs.Contains(anchor))
                    {
                        findings.Add(new(rel, i + 1, "link", $"no heading for anchor #{anchor} in {(path.Length == 0 ? "this page" : path)}", true));
                    }
                    if (!image)
                    {
                        continue;
                    }
                    referencedImages.Add(full);
                    if (alt.Length == 0)
                    {
                        findings.Add(new(rel, i + 1, "image", $"image has no alt text: {target}", true));
                    }
                    if (!HasCaption(lines, i))
                    {
                        findings.Add(new(rel, i + 1, "caption", $"no caption after {target} (a sentence on the next line saying what the screenshot shows)", true));
                    }
                    CheckAnnotated(full, rel, i + 1, lines, i, findings, pageCaptures);
                }
            }
            CheckNumbering(lines, rel, findings);
            CheckLabels(lines, rel, pageCaptures, allCaptures, allControls, findings);
        }

        foreach (var png in Directory.EnumerateFiles(folder, "*.png", SearchOption.AllDirectories))
        {
            var isRaw = png.Contains(Path.DirectorySeparatorChar + "raw" + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
            if (!referencedImages.Contains(png) && !(isRaw && File.Exists(AnnotatedFor(png))))
            {
                findings.Add(new(Path.GetRelativePath(folder, png).Replace('\\', '/'), 0, "unused", "screenshot is not used by any page", false));
            }
        }
        return findings;
    }

    private static string AnnotatedFor(string raw)
        => raw.Replace(Path.DirectorySeparatorChar + "raw" + Path.DirectorySeparatorChar, Path.DirectorySeparatorChar + "annotated" + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);

    private static void CheckAnnotated(string image, string rel, int lineNo, string[] lines, int imageLine, List<DocsFinding> findings, List<string> pageCaptures)
    {
        var record = Path.ChangeExtension(image, null) + ".annotations.json";
        string? original = null;
        var markers = new List<(int Number, string? Element)>();
        if (File.Exists(record))
        {
            using var doc = JsonDocument.Parse(File.ReadAllText(record));
            if (doc.RootElement.TryGetProperty("source", out var s) && s.GetString() is { } source)
            {
                original = Path.GetFullPath(Path.Combine(Path.GetDirectoryName(image)!, source));
            }
            if (doc.RootElement.TryGetProperty("markers", out var ms))
            {
                markers.AddRange(ms.EnumerateArray().Select(m => (m.GetProperty("number").GetInt32(), m.TryGetProperty("element", out var e) ? e.GetString() : null)));
            }
        }
        else if (image.Contains(Path.DirectorySeparatorChar + "annotated" + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
        {
            original = image.Replace(Path.DirectorySeparatorChar + "annotated" + Path.DirectorySeparatorChar, Path.DirectorySeparatorChar + "raw" + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
        }
        if (original is not null && !File.Exists(original))
        {
            findings.Add(new(rel, lineNo, "original", $"annotated image without its original screenshot ({Path.GetFileName(original)} missing)", true));
        }
        var capture = Path.ChangeExtension(original ?? image, null) + ".capture.json";
        if (File.Exists(capture))
        {
            pageCaptures.Add(capture);
        }
        else
        {
            findings.Add(new(rel, lineNo, "capture", $"no capture record for {Path.GetFileName(original ?? image)}: its labels cannot be checked (capture with browser_screenshot savePath)", false));
        }
        if (markers.Count == 0)
        {
            return;
        }
        CheckMarkerLabels(lines, imageLine, markers, rel, findings);
        // The text around the figure (to the next heading) must explain every number.
        var section = string.Join("\n", SectionAround(lines, imageLine));
        foreach (var (number, element) in markers)
        {
            var mentioned = Regex.IsMatch(section, $@"(?m)^\s*{number}\.\s") || Regex.IsMatch(section, $@"\({number}\)|\[{number}\]|marker {number}\b|\b{number}\s*[=–—:-]\s|\*\*{number}\*\*", RegexOptions.IgnoreCase);
            if (!mentioned)
            {
                findings.Add(new(rel, lineNo, "legend", $"marker {number}{(element is null ? "" : " (" + element + ")")} on this image has no matching numbered step or legend entry in the section", true));
            }
        }
    }

    /// <summary>
    /// "Select **Add and index** (3)": marker 3 on the figure that step belongs to (the nearest figure in the section)
    /// must be on an element with that label. Catches steps numbered across several screenshots while each screenshot
    /// numbers its own markers.
    /// </summary>
    private static void CheckMarkerLabels(string[] lines, int imageLine, List<(int Number, string? Element)> markers, string rel, List<DocsFinding> findings)
    {
        var start = imageLine;
        while (start > 0 && !lines[start - 1].StartsWith('#'))
        {
            start--;
        }
        var end = imageLine + 1;
        while (end < lines.Length && !lines[end].StartsWith('#'))
        {
            end++;
        }
        var figures = Enumerable.Range(start, end - start).Where(j => lines[j].TrimStart().StartsWith("![", StringComparison.Ordinal)).ToList();
        for (var j = start; j < end; j++)
        {
            if (figures.OrderBy(f => Math.Abs(f - j)).ThenBy(f => f).First() != imageLine)
            {
                continue; // this line belongs to another figure
            }
            foreach (Match m in BoldThenMarker().Matches(lines[j]))
            {
                var label = Normalise(m.Groups[1].Value);
                var number = int.Parse(m.Groups[2].Value);
                var marker = markers.FirstOrDefault(x => x.Number == number);
                if (marker == default)
                {
                    findings.Add(new(rel, j + 1, "marker", $"step refers to marker ({number}) for **{m.Groups[1].Value}**, but its screenshot has no marker {number}", true));
                }
                else if (marker.Element is { } element && Normalise(element) is var e && !e.Contains(label, StringComparison.Ordinal) && !label.Contains(QuotedLabel(e), StringComparison.Ordinal))
                {
                    findings.Add(new(rel, j + 1, "marker", $"step says **{m.Groups[1].Value}** ({number}), but marker {number} on its screenshot is on {element}", true));
                }
            }
        }
    }

    private static string QuotedLabel(string element) => Regex.Match(element, "\"([^\"]+)\"") is { Success: true } q ? q.Groups[1].Value : element;

    [GeneratedRegex(@"\*\*([^*]+)\*\*[^()*\n]{0,40}\((\d{1,2})\)")]
    private static partial Regex BoldThenMarker();

    private static IEnumerable<string> SectionAround(string[] lines, int index)
    {
        var start = index;
        while (start > 0 && !lines[start - 1].StartsWith('#'))
        {
            start--;
        }
        var end = index + 1;
        while (end < lines.Length && !lines[end].StartsWith('#'))
        {
            end++;
        }
        return lines[start..end];
    }

    private static bool HasCaption(string[] lines, int imageLine)
    {
        for (var j = imageLine + 1; j < lines.Length && j <= imageLine + 3; j++)
        {
            var t = lines[j].Trim();
            if (t.Length == 0)
            {
                continue;
            }
            return !(t.StartsWith('#') || t.StartsWith("![", StringComparison.Ordinal) || t.StartsWith('|') || t.StartsWith("<!--", StringComparison.Ordinal)
                     || Regex.IsMatch(t, @"^([-+]|\* |\d+\.\s)"));
        }
        return false;
    }

    private static void CheckNumbering(string[] lines, string rel, List<DocsFinding> findings)
    {
        int? expected = null;
        var inCode = false;
        for (var i = 0; i < lines.Length; i++)
        {
            var line = lines[i];
            if (line.TrimStart().StartsWith("```", StringComparison.Ordinal))
            {
                inCode = !inCode;
            }
            if (inCode)
            {
                continue;
            }
            var m = Regex.Match(line, @"^(\d+)\.\s");
            if (m.Success)
            {
                var n = int.Parse(m.Groups[1].Value);
                if (expected is { } e && n != e && n != 1)
                {
                    findings.Add(new(rel, i + 1, "steps", $"numbered step {n} follows {e - 1}: steps must be consecutive", true));
                }
                expected = n + 1;
            }
            else if (line.Length > 0 && !char.IsWhiteSpace(line[0]) && !line.StartsWith("![", StringComparison.Ordinal) && !line.StartsWith('*') && !line.StartsWith("<!--", StringComparison.Ordinal))
            {
                expected = null; // a paragraph or heading ends the list
            }
        }
    }

    private static readonly string[] SourceMarkers = ["from code", "from the code", "not verified", "not observed", "unverified", "not exercised", "not captured"];

    private static void CheckLabels(string[] lines, string rel, List<string> pageCaptures, Dictionary<string, string> allCaptures,
        Dictionary<string, string> allControls, List<DocsFinding> findings)
    {
        var controlText = string.Join("\n", allControls.Values);
        // Labels are checked where a page shows screenshots: an index or a plan without figures uses bold for emphasis,
        // and there is no screen on that page to check it against.
        if (allCaptures.Count == 0 || pageCaptures.Count == 0)
        {
            return;
        }
        var pageText = string.Join("\n", pageCaptures.Where(allCaptures.ContainsKey).Select(c => allCaptures[c]));
        var inCode = false;
        for (var i = 0; i < lines.Length; i++)
        {
            var line = lines[i];
            if (line.TrimStart().StartsWith("```", StringComparison.Ordinal))
            {
                inCode = !inCode;
            }
            if (inCode || SourceMarkers.Any(m => line.Contains(m, StringComparison.OrdinalIgnoreCase)) || line.TrimStart().StartsWith('#'))
            {
                continue;
            }
            foreach (Match m in Bold().Matches(line))
            {
                foreach (var part in Regex.Split(m.Groups[1].Value, @"\s*(?:→|›|->|>)\s*"))
                {
                    var label = part.Trim().TrimEnd('.', ',', ':', ';', '…').Trim('"', '“', '”', '\'');
                    if (label.Length < 2 || label.Length > 80 || KeyLike().IsMatch(label) || !label.Any(char.IsLetter))
                    {
                        continue;
                    }
                    var want = Normalise(label);
                    if (pageText.Contains(want, StringComparison.Ordinal))
                    {
                        continue;
                    }
                    var elsewhere = allCaptures.Where(c => c.Value.Contains(want, StringComparison.Ordinal)).Select(c => Path.GetFileName(c.Key)).FirstOrDefault();
                    if (elsewhere is null && controlText.Contains(want, StringComparison.Ordinal))
                    {
                        findings.Add(new(rel, i + 1, "label", $"**{label}** is a control's accessible name (an icon or tooltip), not text the reader sees — describe the icon too", false));
                        continue;
                    }
                    findings.Add(elsewhere is null
                        ? new(rel, i + 1, "label", $"**{label}** is not visible on any screenshot — check the wording against the app, or say the step comes from the code", true)
                        : new(rel, i + 1, "label", $"**{label}** is not on this page's screenshots (seen on {elsewhere})", false));
                }
            }
        }
    }

    private static (string Text, string Controls) ReadCapture(string capture)
    {
        try
        {
            using var doc = JsonDocument.Parse(File.ReadAllText(capture));
            var text = doc.RootElement.TryGetProperty("visibleText", out var t) ? t.GetString() ?? "" : "";
            var controls = doc.RootElement.TryGetProperty("controlNames", out var c) && c.ValueKind == JsonValueKind.Array
                ? string.Join("\n", c.EnumerateArray().Select(x => x.GetString() ?? ""))
                : "";
            return (text, controls);
        }
        catch (JsonException)
        {
            return ("", "");
        }
    }

    private static string Normalise(string text) => Regex.Replace(text.ToLowerInvariant().Replace('’', '\'').Replace('…', '.'), @"\s+", " ").Trim();

    private static IEnumerable<(int Line, string Text)> Headings(string[] lines)
    {
        var inCode = false;
        for (var i = 0; i < lines.Length; i++)
        {
            if (lines[i].TrimStart().StartsWith("```", StringComparison.Ordinal))
            {
                inCode = !inCode;
            }
            if (!inCode && Regex.Match(lines[i], @"^#{1,6}\s+(.+?)\s*#*\s*$") is { Success: true } m)
            {
                yield return (i + 1, m.Groups[1].Value);
            }
        }
    }

    /// <summary>GitHub-style heading anchor.</summary>
    internal static string Slug(string heading)
        => Regex.Replace(Regex.Replace(heading.Trim().ToLowerInvariant(), @"[^\p{L}\p{N}\s_-]", ""), @"\s", "-");

    [GeneratedRegex(@"(?<bang>!?)\[(?<text>[^\]]*)\]\((?<target>[^)\s]+(?:\s+""[^""]*"")?)\)")]
    private static partial Regex LinkOrImage();

    [GeneratedRegex(@"\*\*([^*]+)\*\*")]
    private static partial Regex Bold();

    // Keys and shortcuts are typed, not shown: Ctrl+K, Shift+Enter, Esc, F5.
    [GeneratedRegex(@"^((ctrl|shift|alt|cmd|win)\s*\+.*|enter|esc|escape|tab|space|backspace|delete|f\d{1,2}|↑|↓|←|→)$", RegexOptions.IgnoreCase)]
    private static partial Regex KeyLike();
}
