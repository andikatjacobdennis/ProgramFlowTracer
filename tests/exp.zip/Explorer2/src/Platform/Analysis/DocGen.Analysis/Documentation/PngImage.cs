using System.Buffers.Binary;
using System.IO.Compression;

namespace DocGen.Analysis.Documentation;

/// <summary>
/// A decoded PNG (8-bit greyscale, grey+alpha, RGB or RGBA, not interlaced — what browsers write for screenshots),
/// enough to measure how busy a region is so annotations can be placed on calm areas. No image library is needed:
/// PNG is zlib-compressed scanlines with a per-row filter.
/// </summary>
public sealed class PngImage
{
    private readonly byte[] _luma; // one byte per pixel

    private PngImage(int width, int height, byte[] luma)
    {
        Width = width;
        Height = height;
        _luma = luma;
    }

    public int Width { get; }
    public int Height { get; }

    /// <summary>Width and height from the IHDR chunk without decoding the pixels.</summary>
    public static (int Width, int Height) ReadSize(ReadOnlySpan<byte> png)
    {
        CheckSignature(png);
        return (BinaryPrimitives.ReadInt32BigEndian(png[16..]), BinaryPrimitives.ReadInt32BigEndian(png[20..]));
    }

    public static PngImage Decode(byte[] png)
    {
        CheckSignature(png);
        int width = 0, height = 0, bitDepth = 0, colorType = 0, interlace = 0;
        using var idat = new MemoryStream();
        var pos = 8;
        while (pos + 8 <= png.Length)
        {
            var length = BinaryPrimitives.ReadInt32BigEndian(png.AsSpan(pos));
            var type = System.Text.Encoding.ASCII.GetString(png, pos + 4, 4);
            var data = png.AsSpan(pos + 8, length);
            switch (type)
            {
                case "IHDR":
                    width = BinaryPrimitives.ReadInt32BigEndian(data);
                    height = BinaryPrimitives.ReadInt32BigEndian(data[4..]);
                    bitDepth = data[8];
                    colorType = data[9];
                    interlace = data[12];
                    break;
                case "IDAT":
                    idat.Write(data);
                    break;
                case "IEND":
                    pos = png.Length;
                    continue;
            }
            pos += 12 + length;
        }
        var channels = colorType switch { 0 => 1, 2 => 3, 4 => 2, 6 => 4, _ => 0 };
        if (width <= 0 || height <= 0 || bitDepth != 8 || channels == 0 || interlace != 0)
        {
            throw new InvalidDataException($"Unsupported PNG (colour type {colorType}, {bitDepth}-bit{(interlace != 0 ? ", interlaced" : "")}); screenshots from DocGen's browser are supported.");
        }
        idat.Position = 0;
        using var z = new ZLibStream(idat, CompressionMode.Decompress);
        var stride = width * channels;
        var previous = new byte[stride];
        var row = new byte[stride];
        var luma = new byte[width * height];
        for (var y = 0; y < height; y++)
        {
            var filter = z.ReadByte();
            z.ReadExactly(row);
            Unfilter(filter, row, previous, channels);
            for (var x = 0; x < width; x++)
            {
                var i = x * channels;
                luma[y * width + x] = channels < 3 ? row[i] : (byte)((row[i] * 299 + row[i + 1] * 587 + row[i + 2] * 114) / 1000);
            }
            (previous, row) = (row, previous);
        }
        return new PngImage(width, height, luma);
    }

    /// <summary>
    /// How busy a rectangle is (0 = flat background): the standard deviation of brightness, sampled. Text, icons and
    /// edges score high; empty panels score low. Rectangles are clipped to the image; fully outside scores 255.
    /// </summary>
    public double Busyness(double x, double y, double w, double h)
    {
        int x0 = Math.Max(0, (int)x), y0 = Math.Max(0, (int)y), x1 = Math.Min(Width, (int)(x + w)), y1 = Math.Min(Height, (int)(y + h));
        if (x1 <= x0 || y1 <= y0)
        {
            return 255;
        }
        // Every pixel for the small regions annotations need (a regular sampling grid aliases with text strokes and
        // stripes and can call a busy area calm); large regions are subsampled with an odd stride.
        var step = (x1 - x0) * (y1 - y0) <= 250_000 ? 1 : 3;
        double sum = 0, sumSq = 0;
        var n = 0;
        for (var yy = y0; yy < y1; yy += step)
        {
            for (var xx = x0 + (step > 1 ? yy % step : 0); xx < x1; xx += step)
            {
                double v = _luma[yy * Width + xx];
                sum += v;
                sumSq += v * v;
                n++;
            }
        }
        var mean = sum / n;
        return Math.Sqrt(Math.Max(0, sumSq / n - mean * mean));
    }

    /// <summary>Average brightness of a rectangle (0 black – 255 white), to pick readable colours.</summary>
    public double Brightness(double x, double y, double w, double h)
    {
        int x0 = Math.Max(0, (int)x), y0 = Math.Max(0, (int)y), x1 = Math.Min(Width, (int)(x + w)), y1 = Math.Min(Height, (int)(y + h));
        if (x1 <= x0 || y1 <= y0)
        {
            return 255;
        }
        double sum = 0;
        var n = 0;
        for (var yy = y0; yy < y1; yy += 2)
        {
            for (var xx = x0; xx < x1; xx += 2)
            {
                sum += _luma[yy * Width + xx];
                n++;
            }
        }
        return n == 0 ? 255 : sum / n;
    }

    private static void CheckSignature(ReadOnlySpan<byte> png)
    {
        ReadOnlySpan<byte> signature = [137, 80, 78, 71, 13, 10, 26, 10];
        if (png.Length < 33 || !png[..8].SequenceEqual(signature))
        {
            throw new InvalidDataException("Not a PNG file.");
        }
    }

    private static void Unfilter(int filter, byte[] row, byte[] previous, int bpp)
    {
        switch (filter)
        {
            case 0:
                return;
            case 1:
                for (var i = bpp; i < row.Length; i++) row[i] += row[i - bpp];
                return;
            case 2:
                for (var i = 0; i < row.Length; i++) row[i] += previous[i];
                return;
            case 3:
                for (var i = 0; i < row.Length; i++) row[i] += (byte)(((i >= bpp ? row[i - bpp] : 0) + previous[i]) / 2);
                return;
            case 4:
                for (var i = 0; i < row.Length; i++)
                {
                    int a = i >= bpp ? row[i - bpp] : 0, b = previous[i], c = i >= bpp ? previous[i - bpp] : 0;
                    int p = a + b - c, pa = Math.Abs(p - a), pb = Math.Abs(p - b), pc = Math.Abs(p - c);
                    row[i] += (byte)(pa <= pb && pa <= pc ? a : pb <= pc ? b : c);
                }
                return;
            default:
                throw new InvalidDataException($"Bad PNG filter {filter}.");
        }
    }
}
