using System.Globalization;
using System.Net;
using System.Text;

namespace DocGen.Analysis.Documentation;

/// <summary>A rectangle in image pixels.</summary>
public readonly record struct Rect(double X, double Y, double W, double H)
{
    public double Right => X + W;
    public double Bottom => Y + H;
    public double CenterX => X + W / 2;
    public double CenterY => Y + H / 2;

    public Rect Inflate(double d) => new(X - d, Y - d, W + 2 * d, H + 2 * d);

    public double Overlap(Rect o)
    {
        var w = Math.Min(Right, o.Right) - Math.Max(X, o.X);
        var h = Math.Min(Bottom, o.Bottom) - Math.Max(Y, o.Y);
        return w > 0 && h > 0 ? w * h : 0;
    }

    /// <summary>The point on this rectangle's edge closest to (x, y).</summary>
    public (double X, double Y) Nearest(double x, double y) => (Math.Clamp(x, X, Right), Math.Clamp(y, Y, Bottom));
}

/// <summary>One requested annotation (from image_annotate's arguments).</summary>
/// <param name="Type">box | marker | arrow | callout | cloud</param>
/// <param name="Target">Name of a target recorded with the screenshot (browser_screenshot targets).</param>
/// <param name="Rect">Explicit [x, y, width, height] in image pixels, instead of a target.</param>
/// <param name="Number">Step number shown in a marker (or in a callout/cloud badge, or a box's corner badge).</param>
/// <param name="Text">Callout or cloud text.</param>
/// <param name="From">Arrow start: a target name.</param>
/// <param name="To">Arrow end: a target name (the arrowhead points at it).</param>
/// <param name="Side">Preferred side for callouts/clouds/markers: right, left, above, below.</param>
public sealed record AnnotationSpec(string Type, string? Target = null, double[]? Rect = null, int? Number = null, string? Text = null,
    string? From = null, string? To = null, string? Side = null);

/// <summary>A target as recorded beside the screenshot: its box and what the element was.</summary>
public sealed record AnnotationTarget(Rect Box, string? Description);

/// <summary>The result of laying annotations out on an image.</summary>
public sealed class AnnotationLayoutResult
{
    public required string Svg { get; init; }
    public List<string> Placed { get; } = [];
    public List<string> Warnings { get; } = [];
    public List<(int Number, string Target, string? Description)> Markers { get; } = [];
    public List<(string Kind, string Text, string Target)> Notes { get; } = [];
}

/// <summary>
/// Lays out documentation annotations on a screenshot and draws them as SVG over the original pixels. Boxes and arrows
/// follow the recorded element boxes exactly; numbered markers, callouts and clouds are placed where the image is calm
/// (low brightness variation), outside the elements the guide talks about, and away from each other. Everything is
/// scaled with the screenshot's device pixel ratio so a phone shot gets the same visual weight as a desktop one.
/// </summary>
public static class AnnotationRenderer
{
    private const string Accent = "#E03131";
    private const string Ink = "#1F2328";
    private const string CloudFill = "#FFF8DB";
    private const string CloudStroke = "#D99A00";

    public static AnnotationLayoutResult Layout(PngImage image, byte[] png, IReadOnlyList<AnnotationSpec> specs,
        IReadOnlyDictionary<string, AnnotationTarget> targets, double scale)
    {
        var s = Math.Clamp(scale, 1, 4);
        var svg = new StringBuilder();
        var placed = new List<Rect>();                       // markers, callouts, clouds already drawn
        var protectedBoxes = targets.Values.Select(t => t.Box).ToList(); // the guide's subjects: keep them visible
        var result = new AnnotationLayoutResult { Svg = "" };
        var bounds = new Rect(0, 0, image.Width, image.Height);

        Rect? Resolve(string? name, double[]? rect, string role)
        {
            if (rect is { Length: 4 })
            {
                return new Rect(rect[0], rect[1], rect[2], rect[3]);
            }
            if (name is null)
            {
                result.Warnings.Add($"{role}: give a target (recorded with the screenshot) or rect [x, y, width, height]");
                return null;
            }
            if (!targets.TryGetValue(name, out var t))
            {
                result.Warnings.Add($"{role}: target '{name}' was not recorded or not found in this screenshot — annotation skipped (capture it again with that target)");
                return null;
            }
            return t.Box;
        }

        string Describe(string? name) => name is not null && targets.TryGetValue(name, out var t) && t.Description is { Length: > 0 } d ? $"{name} ({d})" : name ?? "rect";

        // 1. Boxes (and their optional corner badges) first: they sit exactly on their elements.
        foreach (var spec in specs.Where(a => Is(a, "box")))
        {
            if (Resolve(spec.Target, spec.Rect, "box") is not { } box)
            {
                continue;
            }
            var r = box.Inflate(4 * s);
            svg.Append(CultureInfo.InvariantCulture, $"<rect x=\"{F(r.X)}\" y=\"{F(r.Y)}\" width=\"{F(r.W)}\" height=\"{F(r.H)}\" rx=\"{F(6 * s)}\" fill=\"{Accent}\" fill-opacity=\"0.06\" stroke=\"{Accent}\" stroke-width=\"{F(3 * s)}\" filter=\"url(#shadow)\"/>");
            result.Placed.Add($"box around {Describe(spec.Target)} at {F(box.X)},{F(box.Y)} {F(box.W)}×{F(box.H)}");
            if (spec.Number is { } n)
            {
                var c = PlaceMarker(image, bounds, r, s, placed, protectedBoxes, box, spec.Side);
                svg.Append(MarkerSvg(c.X, c.Y, n, s));
                result.Markers.Add((n, spec.Target ?? "rect", Description(targets, spec.Target)));
            }
        }

        // 2. Numbered markers.
        foreach (var spec in specs.Where(a => Is(a, "marker")))
        {
            if (Resolve(spec.Target, spec.Rect, "marker") is not { } box)
            {
                continue;
            }
            var c = PlaceMarker(image, bounds, box.Inflate(4 * s), s, placed, protectedBoxes, box, spec.Side);
            var n = spec.Number ?? result.Markers.Count + 1;
            if (!string.IsNullOrWhiteSpace(spec.Text))
            {
                result.Warnings.Add($"marker {n}: its text is not drawn (a marker is only a number) — put the words in the numbered step, or use a callout");
            }
            svg.Append(MarkerSvg(c.X, c.Y, n, s));
            result.Markers.Add((n, spec.Target ?? "rect", Description(targets, spec.Target)));
            result.Placed.Add($"marker {n} on {Describe(spec.Target)} at {F(c.X)},{F(c.Y)}");
        }

        // 3. Callouts and clouds: a short text panel beside the element, connected to it.
        foreach (var spec in specs.Where(a => Is(a, "callout") || Is(a, "cloud")))
        {
            var kind = Is(spec, "cloud") ? "cloud" : "callout";
            if (Resolve(spec.Target, spec.Rect, kind) is not { } box)
            {
                continue;
            }
            if (string.IsNullOrWhiteSpace(spec.Text))
            {
                result.Warnings.Add($"{kind} on {spec.Target}: no text — skipped");
                continue;
            }
            var lines = Wrap(spec.Text.Trim(), spec.Text.Length > 60 ? 34 : 28);
            if (spec.Text.Length > 140)
            {
                result.Warnings.Add($"{kind} on {spec.Target}: {spec.Text.Length} characters — keep callouts to one short sentence; explain in the caption instead");
            }
            var badge = spec.Number is null ? 0 : 26 * s;
            var pad = (kind == "cloud" ? 18 : 10) * s;
            var w = lines.Max(l => l.Length) * 7.4 * s + 2 * pad + badge;
            var h = lines.Count * 19 * s + 2 * pad;
            var panel = PlacePanel(image, bounds, box, w, h, s, placed, protectedBoxes, spec.Side);
            placed.Add(panel);
            var (tx, ty) = box.Inflate(4 * s).Nearest(panel.CenterX, panel.CenterY);
            var (px, py) = panel.Nearest(tx, ty);
            if (kind == "cloud")
            {
                // Thought-bubble trail towards the element.
                for (var i = 1; i <= 3; i++)
                {
                    var f = i / 4.0;
                    svg.Append(CultureInfo.InvariantCulture, $"<circle cx=\"{F(px + (tx - px) * f)}\" cy=\"{F(py + (ty - py) * f)}\" r=\"{F((5 - i) * 1.6 * s)}\" fill=\"{CloudFill}\" stroke=\"{CloudStroke}\" stroke-width=\"{F(1.5 * s)}\"/>");
                }
                svg.Append(CloudPath(panel, s));
            }
            else
            {
                svg.Append(CultureInfo.InvariantCulture, $"<line x1=\"{F(px)}\" y1=\"{F(py)}\" x2=\"{F(tx)}\" y2=\"{F(ty)}\" stroke=\"{Accent}\" stroke-width=\"{F(2 * s)}\"/>");
                svg.Append(CultureInfo.InvariantCulture, $"<circle cx=\"{F(tx)}\" cy=\"{F(ty)}\" r=\"{F(4 * s)}\" fill=\"{Accent}\"/>");
                svg.Append(CultureInfo.InvariantCulture, $"<rect x=\"{F(panel.X)}\" y=\"{F(panel.Y)}\" width=\"{F(panel.W)}\" height=\"{F(panel.H)}\" rx=\"{F(8 * s)}\" fill=\"#FFFFFF\" stroke=\"{Accent}\" stroke-width=\"{F(2 * s)}\" filter=\"url(#shadow)\"/>");
            }
            if (spec.Number is { } n)
            {
                svg.Append(MarkerSvg(panel.X + pad + 11 * s, panel.Y + pad + 9.5 * s, n, s * 0.85));
                result.Markers.Add((n, spec.Target ?? "rect", Description(targets, spec.Target)));
            }
            for (var i = 0; i < lines.Count; i++)
            {
                svg.Append(CultureInfo.InvariantCulture,
                    $"<text x=\"{F(panel.X + pad + badge)}\" y=\"{F(panel.Y + pad + 14 * s + i * 19 * s)}\" font-family=\"Segoe UI, Arial, sans-serif\" font-size=\"{F(14 * s)}\" fill=\"{Ink}\">{WebUtility.HtmlEncode(lines[i])}</text>");
            }
            result.Notes.Add((kind, spec.Text.Trim(), spec.Target ?? "rect"));
            result.Placed.Add($"{kind} \"{Clip(spec.Text, 40)}\" for {Describe(spec.Target)} at {F(panel.X)},{F(panel.Y)} {F(panel.W)}×{F(panel.H)}");
            if (protectedBoxes.Any(b => b != box && b.Overlap(panel) > 0.15 * Math.Min(b.W * b.H, panel.W * panel.H)))
            {
                result.Warnings.Add($"{kind} on {spec.Target} covers part of another recorded element; consider fewer annotations or a different side");
            }
        }

        // 4. Arrows last, on top: from one element to another (e.g. "type here, then press this").
        foreach (var spec in specs.Where(a => Is(a, "arrow")))
        {
            if (Resolve(spec.From, null, "arrow start") is not { } from || Resolve(spec.To ?? spec.Target, spec.Rect, "arrow end") is not { } to)
            {
                continue;
            }
            var (sx, sy) = from.Inflate(6 * s).Nearest(to.CenterX, to.CenterY);
            var (ex, ey) = to.Inflate(8 * s).Nearest(sx, sy);
            // A gentle bend reads as an annotation rather than part of the UI.
            var (mx, my) = ((sx + ex) / 2, (sy + ey) / 2);
            var (dx, dy) = (ex - sx, ey - sy);
            var len = Math.Max(1, Math.Sqrt(dx * dx + dy * dy));
            var (cx, cy) = (mx - dy / len * Math.Min(40 * s, len * 0.15), my + dx / len * Math.Min(40 * s, len * 0.15));
            svg.Append(CultureInfo.InvariantCulture,
                $"<path d=\"M{F(sx)},{F(sy)} Q{F(cx)},{F(cy)} {F(ex)},{F(ey)}\" fill=\"none\" stroke=\"{Accent}\" stroke-width=\"{F(3 * s)}\" stroke-linecap=\"round\" marker-end=\"url(#head)\" filter=\"url(#shadow)\"/>");
            result.Placed.Add($"arrow from {Describe(spec.From)} to {Describe(spec.To ?? spec.Target)}");
        }

        foreach (var spec in specs.Where(a => !new[] { "box", "marker", "arrow", "callout", "cloud" }.Any(k => Is(a, k))))
        {
            result.Warnings.Add($"unknown annotation type '{spec.Type}' (use box, marker, arrow, callout or cloud)");
        }
        var numbers = result.Markers.Select(m => m.Number).ToList();
        if (numbers.Count != numbers.Distinct().Count())
        {
            result.Warnings.Add("the same marker number is used twice");
        }
        else if (numbers.Count > 0 && !numbers.Order().SequenceEqual(Enumerable.Range(1, numbers.Count)))
        {
            result.Warnings.Add($"marker numbers are {string.Join(", ", numbers.Order())}: number them 1…{numbers.Count} in the order of the steps they illustrate");
        }
        if (numbers.Count > 7)
        {
            result.Warnings.Add($"{numbers.Count} numbered markers on one image: more than 6–7 is hard to follow; split the workflow over two screenshots");
        }

        var document = new StringBuilder();
        document.Append(CultureInfo.InvariantCulture, $"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{image.Width}\" height=\"{image.Height}\" viewBox=\"0 0 {image.Width} {image.Height}\">");
        document.Append(CultureInfo.InvariantCulture,
            $"<defs><filter id=\"shadow\" x=\"-20%\" y=\"-20%\" width=\"140%\" height=\"140%\"><feDropShadow dx=\"0\" dy=\"{F(1.5 * s)}\" stdDeviation=\"{F(2 * s)}\" flood-color=\"#000\" flood-opacity=\"0.28\"/></filter>" +
            $"<marker id=\"head\" viewBox=\"0 0 10 10\" refX=\"8\" refY=\"5\" markerWidth=\"4.5\" markerHeight=\"4.5\" orient=\"auto-start-reverse\"><path d=\"M0,0 L10,5 L0,10 z\" fill=\"{Accent}\"/></marker></defs>");
        document.Append(CultureInfo.InvariantCulture, $"<image href=\"data:image/png;base64,{Convert.ToBase64String(png)}\" x=\"0\" y=\"0\" width=\"{image.Width}\" height=\"{image.Height}\"/>");
        document.Append(svg);
        document.Append("</svg>");
        return new AnnotationLayoutResult { Svg = document.ToString() }.With(result);
    }

    private static AnnotationLayoutResult With(this AnnotationLayoutResult target, AnnotationLayoutResult from)
    {
        target.Placed.AddRange(from.Placed);
        target.Warnings.AddRange(from.Warnings);
        target.Markers.AddRange(from.Markers);
        target.Notes.AddRange(from.Notes);
        return target;
    }

    private static string? Description(IReadOnlyDictionary<string, AnnotationTarget> targets, string? name)
        => name is not null && targets.TryGetValue(name, out var t) ? t.Description : null;

    private static bool Is(AnnotationSpec a, string type) => string.Equals(a.Type, type, StringComparison.OrdinalIgnoreCase);

    /// <summary>Marker centre: a corner or side of the element where the image is calm and nothing else is drawn.</summary>
    private static (double X, double Y) PlaceMarker(PngImage image, Rect bounds, Rect around, double s, List<Rect> placed, List<Rect> protectedBoxes, Rect own, string? side)
    {
        var r = 14 * s;
        var g = 3 * s;
        var candidates = new List<(double X, double Y, string Side)>
        {
            (around.X, around.Y, "corner"), (around.Right, around.Y, "corner"),
            (around.X - r - g, around.CenterY, "left"), (around.Right + r + g, around.CenterY, "right"),
            (around.CenterX, around.Y - r - g, "above"), (around.CenterX, around.Bottom + r + g, "below"),
            (around.X, around.Bottom, "corner"), (around.Right, around.Bottom, "corner"),
        };
        var best = candidates.Select((c, i) =>
        {
            var disc = new Rect(c.X - r, c.Y - r, 2 * r, 2 * r);
            var score = image.Busyness(disc.X, disc.Y, disc.W, disc.H) + i * 1.5;
            if (disc.X < 0 || disc.Y < 0 || disc.Right > bounds.Right || disc.Bottom > bounds.Bottom) score += 1000;
            score += placed.Sum(p => p.Overlap(disc.Inflate(2 * s))) / (disc.W * disc.H) * 400;
            score += protectedBoxes.Where(b => b != own).Sum(b => b.Overlap(disc)) / (disc.W * disc.H) * 150;
            if (side is not null && string.Equals(c.Side, side, StringComparison.OrdinalIgnoreCase)) score -= 40;
            return (c, score);
        }).OrderBy(x => x.score).First().c;
        placed.Add(new Rect(best.X - r, best.Y - r, 2 * r, 2 * r));
        return (best.X, best.Y);
    }

    /// <summary>Callout/cloud panel position: beside the element on the calmest free side, kept inside the image.</summary>
    private static Rect PlacePanel(PngImage image, Rect bounds, Rect box, double w, double h, double s, List<Rect> placed, List<Rect> protectedBoxes, string? side)
    {
        var gap = 30 * s;
        var candidates = new List<(Rect R, string Side)>
        {
            (new Rect(box.Right + gap, box.CenterY - h / 2, w, h), "right"),
            (new Rect(box.X - gap - w, box.CenterY - h / 2, w, h), "left"),
            (new Rect(box.CenterX - w / 2, box.Bottom + gap, w, h), "below"),
            (new Rect(box.CenterX - w / 2, box.Y - gap - h, w, h), "above"),
            (new Rect(box.Right + gap, box.Bottom + gap / 2, w, h), "right"),
            (new Rect(box.X - gap - w, box.Bottom + gap / 2, w, h), "left"),
            (new Rect(box.Right + gap, box.Y - gap / 2 - h, w, h), "right"),
            (new Rect(box.X - gap - w, box.Y - gap / 2 - h, w, h), "left"),
        };
        return candidates.Select((c, i) =>
        {
            // Pull a panel that sticks out back inside, at a cost.
            var x = Math.Clamp(c.R.X, 4 * s, Math.Max(4 * s, bounds.Right - w - 4 * s));
            var y = Math.Clamp(c.R.Y, 4 * s, Math.Max(4 * s, bounds.Bottom - h - 4 * s));
            var r = new Rect(x, y, w, h);
            // The busiest part counts, not the average: a mostly blank strip with a nav link in one corner would still
            // hide that link.
            var score = WorstCell(image, r) + i * 2 + (Math.Abs(x - c.R.X) + Math.Abs(y - c.R.Y)) / s * 0.6;
            score += placed.Sum(p => p.Overlap(r.Inflate(4 * s))) / (w * h) * 500;
            score += protectedBoxes.Sum(b => b.Overlap(r)) / (w * h) * 300;
            score += box.Overlap(r) / (w * h) * 800;
            if (side is not null && string.Equals(c.Side, side, StringComparison.OrdinalIgnoreCase)) score -= 30;
            return (r, score);
        }).OrderBy(x => x.score).First().r;
    }

    /// <summary>Busyness of the busiest cell of a 4×2 grid over the rectangle.</summary>
    private static double WorstCell(PngImage image, Rect r)
    {
        double worst = 0;
        for (var gx = 0; gx < 4; gx++)
        {
            for (var gy = 0; gy < 2; gy++)
            {
                worst = Math.Max(worst, image.Busyness(r.X + gx * r.W / 4, r.Y + gy * r.H / 2, r.W / 4, r.H / 2));
            }
        }
        return worst;
    }

    private static string MarkerSvg(double x, double y, int n, double s)
    {
        var r = 14 * s;
        return string.Create(CultureInfo.InvariantCulture,
            $"<g filter=\"url(#shadow)\"><circle cx=\"{F(x)}\" cy=\"{F(y)}\" r=\"{F(r)}\" fill=\"{Accent}\" stroke=\"#FFFFFF\" stroke-width=\"{F(2.5 * s)}\"/>" +
            $"<text x=\"{F(x)}\" y=\"{F(y + 5.2 * s)}\" text-anchor=\"middle\" font-family=\"Segoe UI, Arial, sans-serif\" font-weight=\"700\" font-size=\"{F((n > 9 ? 13 : 15) * s)}\" fill=\"#FFFFFF\">{n}</text></g>");
    }

    /// <summary>A cloud outline: scalloped bumps around the panel.</summary>
    private static string CloudPath(Rect p, double s)
    {
        var bump = 14 * s;
        var sb = new StringBuilder();
        void Edge(double x0, double y0, double x1, double y1)
        {
            var len = Math.Sqrt((x1 - x0) * (x1 - x0) + (y1 - y0) * (y1 - y0));
            var n = Math.Max(2, (int)Math.Round(len / (bump * 1.6)));
            for (var i = 1; i <= n; i++)
            {
                var x = x0 + (x1 - x0) * i / n;
                var y = y0 + (y1 - y0) * i / n;
                sb.Append(CultureInfo.InvariantCulture, $" A{F(len / n * 0.62)},{F(len / n * 0.62)} 0 0 1 {F(x)},{F(y)}");
            }
        }
        sb.Append(CultureInfo.InvariantCulture, $"<path d=\"M{F(p.X)},{F(p.Y)}");
        Edge(p.X, p.Y, p.Right, p.Y);
        Edge(p.Right, p.Y, p.Right, p.Bottom);
        Edge(p.Right, p.Bottom, p.X, p.Bottom);
        Edge(p.X, p.Bottom, p.X, p.Y);
        sb.Append(CultureInfo.InvariantCulture, $" Z\" fill=\"{CloudFill}\" stroke=\"{CloudStroke}\" stroke-width=\"{F(2 * s)}\" filter=\"url(#shadow)\"/>");
        return sb.ToString();
    }

    internal static List<string> Wrap(string text, int width)
    {
        var lines = new List<string>();
        var line = new StringBuilder();
        foreach (var word in text.Split(' ', StringSplitOptions.RemoveEmptyEntries))
        {
            if (line.Length > 0 && line.Length + 1 + word.Length > width)
            {
                lines.Add(line.ToString());
                line.Clear();
            }
            line.Append(line.Length > 0 ? " " : "").Append(word);
        }
        if (line.Length > 0)
        {
            lines.Add(line.ToString());
        }
        return lines.Count == 0 ? [""] : lines;
    }

    private static string Clip(string text, int max) => text.Length > max ? text[..max] + "…" : text;

    private static string F(double v) => v.ToString("0.#", CultureInfo.InvariantCulture);
}
