using System.Text;
using DocGen.Core.Abstractions;
using DocGen.Security;
using Microsoft.Extensions.Logging;

namespace DocGen.Analysis.Execution;

/// <summary>
/// AI suggestions in the terminal (Settings → Terminal): given the start of a command line, the shell, the folder, its
/// file names and recent commands, a model proposes the rest of the line. The suggestion is only shown as grey text;
/// nothing runs until the user accepts it and presses Enter. Secrets in the recent commands are masked first.
/// </summary>
public sealed class TerminalSuggestions(
    TerminalService terminals,
    IModelRegistry models,
    IProviderRegistry providers,
    ILogger<TerminalSuggestions> logger)
{
    public const int MaxTypedChars = 400;
    private static readonly TimeSpan Timeout = TimeSpan.FromSeconds(8);

    /// <summary>The text to append to <paramref name="typed"/>, or "" when there is no confident suggestion.</summary>
    public async Task<string> SuggestAsync(string userId, string sessionId, string typed, IReadOnlyList<string> history, string? modelId, CancellationToken ct)
    {
        typed ??= "";
        if (typed.Trim().Length < 2 || typed.Length > MaxTypedChars || typed.Contains('\n'))
        {
            return "";
        }
        var state = terminals.Get(userId, sessionId);
        var model = await models.ResolveAsync(modelId, ct);
        var provider = await providers.GetAsync(model.ProviderId, ct);

        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(Timeout);
        try
        {
            var response = await provider.GenerateAsync(new ModelRequest
            {
                ModelId = model.ProviderModelId ?? model.Id,
                Messages = [ModelMessage.System(SystemPrompt(state.ShellLabel)), ModelMessage.User(Context(state, typed, history))],
                MaxOutputTokens = 60,
                Temperature = 0,
            }, timeout.Token);
            return Clean(typed, response.Text);
        }
        catch (Exception ex) when (ex is OperationCanceledException && !ct.IsCancellationRequested)
        {
            return "";
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            logger.LogDebug(ex, "Terminal suggestion failed");
            return "";
        }
    }

    private static string SystemPrompt(string shell) =>
        $"You complete command lines typed in {shell} on Windows. Reply with only the characters that should come right after the " +
        "typed text, continuing it exactly (include a leading space when a new word starts). One line, no explanation, no quotes " +
        "around the answer, no code fences. Prefer commands and file names that fit the folder and the recent commands. " +
        "Never suggest destructive commands (deleting, formatting, force-pushing). If you are not confident, reply with nothing.";

    private static string Context(TerminalState state, string typed, IReadOnlyList<string> history)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"Folder: {state.Cwd}");
        try
        {
            var names = new DirectoryInfo(state.Cwd).EnumerateFileSystemInfos()
                .Where(i => !i.Name.StartsWith('.') || i.Name is ".git" or ".env.example")
                .Take(60)
                .Select(i => i is DirectoryInfo ? i.Name + "\\" : i.Name);
            sb.AppendLine("Entries: " + string.Join(", ", names));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            // The listing only helps; suggest without it.
        }
        var recent = history.Where(h => !string.IsNullOrWhiteSpace(h)).TakeLast(12).Select(h => SecretRedactor.Redact(h.Length > 200 ? h[..200] : h)).ToList();
        if (recent.Count > 0)
        {
            sb.AppendLine("Recent commands (oldest first):");
            foreach (var command in recent)
            {
                sb.AppendLine("  " + command);
            }
        }
        sb.Append("Typed so far: ").Append(typed);
        return sb.ToString();
    }

    /// <summary>The model's answer as a continuation: first line only, fences and quotes removed, a repeated prefix cut.</summary>
    public static string Clean(string typed, string? answer)
    {
        var text = (answer ?? "").Replace("\r", "");
        text = text.Trim('\n');
        if (text.StartsWith("```", StringComparison.Ordinal))
        {
            text = string.Join('\n', text.Split('\n').Skip(1).TakeWhile(l => !l.StartsWith("```", StringComparison.Ordinal)));
        }
        text = text.Split('\n')[0].TrimEnd();
        if (text.Length >= 2 && text[0] == '`' && text[^1] == '`')
        {
            text = text[1..^1];
        }
        // Models sometimes repeat the whole line: keep only what follows the typed text.
        if (text.StartsWith(typed, StringComparison.OrdinalIgnoreCase))
        {
            text = text[typed.Length..];
        }
        else if (typed.TrimEnd().Length > 0 && text.TrimStart().StartsWith(typed.Trim(), StringComparison.OrdinalIgnoreCase))
        {
            text = text.TrimStart()[typed.Trim().Length..];
        }
        return text.Length > 200 || text.Trim().Length == 0 ? "" : text;
    }
}
