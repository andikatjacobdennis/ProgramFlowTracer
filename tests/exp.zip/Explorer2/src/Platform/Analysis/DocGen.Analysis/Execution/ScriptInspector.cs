using System.Text.RegularExpressions;
using DocGen.Core.Models;

namespace DocGen.Analysis.Execution;

/// <summary>readonly → mutating → elevated (process / network / system) → blocked.</summary>
public enum ExecutionTier
{
    ReadOnly = 0,
    Mutating = 1,
    Elevated = 2,
    Blocked = 3,
}

public sealed record ExecutionFinding(string Command, string Category, ExecutionTier Tier, int Line);

public sealed class ExecutionAssessment
{
    public ExecutionTier Tier { get; set; } = ExecutionTier.ReadOnly;
    public List<ExecutionFinding> Findings { get; } = [];

    public void Add(string command, string category, ExecutionTier tier, int line)
    {
        if (Findings.Count < 50 && !Findings.Any(f => f.Command.Equals(command, StringComparison.OrdinalIgnoreCase) && f.Category == category))
        {
            Findings.Add(new ExecutionFinding(command, category, tier, line));
        }
        if (tier > Tier)
        {
            Tier = tier;
        }
    }

    /// <summary>Tier → tool risk used by the permission policy.</summary>
    public ToolRiskLevel Risk => Tier switch
    {
        ExecutionTier.ReadOnly => ToolRiskLevel.ReadOnly,
        ExecutionTier.Mutating => ToolRiskLevel.Sensitive,
        ExecutionTier.Elevated => ToolRiskLevel.External,
        _ => ToolRiskLevel.Destructive,
    };

    private static readonly string[] SystemOrNetworkMarkers =
    [
        "network", "install", "service", "scheduled task", "registry", "permissions", "credential", "remot", "obfuscation", "ownership",
        "configuration", "download", "certificate", "dynamic code evaluation", "process kill", "shutdown", "disk",
    ];

    /// <summary>
    /// Whether anything found installs software, uses the network or changes the system, as opposed to running local
    /// programs and changing files (dotnet ef, a built app, sqlite3, New-Item). Blocked findings always count.
    /// </summary>
    public bool ChangesSystemOrNetwork => Findings.Any(f => f.Tier == ExecutionTier.Blocked
        || f.Tier == ExecutionTier.Elevated && SystemOrNetworkMarkers.Any(m => f.Category.Contains(m, StringComparison.OrdinalIgnoreCase)));

    public IReadOnlyList<string> Describe()
        => Findings.OrderByDescending(f => f.Tier).Select(f => $"{f.Tier.ToString().ToLowerInvariant()}: {f.Command} ({f.Category}{(f.Line > 0 ? $", line {f.Line}" : "")})").ToList();

    public string Summary => Tier switch
    {
        ExecutionTier.ReadOnly => "read-only",
        ExecutionTier.Mutating => "modifies files or state",
        ExecutionTier.Elevated => "starts processes, uses the network or changes the system",
        _ => "blocked by policy",
    };
}

/// <summary>
/// Deterministic inspection of a PowerShell script before it runs. It tokenizes lightly (comments and string
/// literals are skipped, aliases resolved) and classifies every command it finds. Detection is conservative: an
/// unknown command or a native executable is treated as "elevated" (it may start processes), a known mutating cmdlet
/// as "mutating", a known dangerous one as "blocked". It does not prove a script is malicious; it decides how strong
/// the approval must be, or whether policy blocks it.
/// </summary>
public static partial class PowerShellInspector
{
    private static readonly Dictionary<string, string> Aliases = new(StringComparer.OrdinalIgnoreCase)
    {
        ["gci"] = "Get-ChildItem", ["ls"] = "Get-ChildItem", ["dir"] = "Get-ChildItem", ["gc"] = "Get-Content", ["cat"] = "Get-Content", ["type"] = "Get-Content",
        ["sls"] = "Select-String", ["select"] = "Select-Object", ["where"] = "Where-Object", ["?"] = "Where-Object", ["%"] = "ForEach-Object", ["foreach"] = "ForEach-Object",
        ["sort"] = "Sort-Object", ["measure"] = "Measure-Object", ["gi"] = "Get-Item", ["gp"] = "Get-ItemProperty", ["gl"] = "Get-Location", ["pwd"] = "Get-Location",
        ["cd"] = "Set-Location", ["sl"] = "Set-Location", ["chdir"] = "Set-Location", ["pushd"] = "Push-Location", ["popd"] = "Pop-Location", ["echo"] = "Write-Output",
        ["write"] = "Write-Output", ["ft"] = "Format-Table", ["fl"] = "Format-List", ["group"] = "Group-Object", ["compare"] = "Compare-Object", ["diff"] = "Compare-Object",
        ["tee"] = "Tee-Object", ["gps"] = "Get-Process", ["ps"] = "Get-Process", ["gsv"] = "Get-Service", ["gm"] = "Get-Member", ["rvpa"] = "Resolve-Path",
        ["rm"] = "Remove-Item", ["del"] = "Remove-Item", ["erase"] = "Remove-Item", ["rd"] = "Remove-Item", ["ri"] = "Remove-Item", ["rmdir"] = "Remove-Item",
        ["cp"] = "Copy-Item", ["copy"] = "Copy-Item", ["cpi"] = "Copy-Item", ["mv"] = "Move-Item", ["move"] = "Move-Item", ["mi"] = "Move-Item",
        ["ren"] = "Rename-Item", ["rni"] = "Rename-Item", ["ni"] = "New-Item", ["md"] = "New-Item", ["mkdir"] = "New-Item", ["sc"] = "Set-Content", ["ac"] = "Add-Content",
        ["clc"] = "Clear-Content", ["si"] = "Set-Item", ["sp"] = "Set-ItemProperty", ["iwr"] = "Invoke-WebRequest", ["curl"] = "Invoke-WebRequest", ["wget"] = "Invoke-WebRequest",
        ["irm"] = "Invoke-RestMethod", ["iex"] = "Invoke-Expression", ["icm"] = "Invoke-Command", ["saps"] = "Start-Process", ["start"] = "Start-Process",
        ["kill"] = "Stop-Process", ["spps"] = "Stop-Process", ["sajb"] = "Start-Job", ["ii"] = "Invoke-Item", ["sv"] = "Set-Variable", ["set"] = "Set-Variable",
        ["gv"] = "Get-Variable", ["nal"] = "New-Alias", ["sasv"] = "Start-Service", ["spsv"] = "Stop-Service",
    };

    private static readonly HashSet<string> ReadOnlyCommands = new(StringComparer.OrdinalIgnoreCase)
    {
        "Get-ChildItem", "Get-Content", "Get-Item", "Get-ItemProperty", "Get-Location", "Select-String", "Select-Object", "Where-Object", "ForEach-Object",
        "Sort-Object", "Measure-Object", "Group-Object", "Compare-Object", "Format-Table", "Format-List", "Format-Wide", "Out-String", "Write-Output", "Write-Host",
        "Write-Verbose", "Write-Warning", "Write-Error", "Write-Information", "Get-FileHash", "Test-Path", "Resolve-Path", "Split-Path", "Join-Path", "Get-Date",
        "Get-Process", "Get-Service", "Get-Member", "Get-Command", "Get-Help", "Get-Variable", "Get-Host", "ConvertTo-Json", "ConvertFrom-Json", "ConvertTo-Csv",
        "ConvertFrom-Csv", "ConvertTo-Html", "Import-Csv", "Select-Xml", "Get-Unique", "Tee-Object", "Set-Location", "Push-Location", "Pop-Location",
        "Out-Null", "Out-Host", "New-Object", "Get-Random", "Start-Sleep", "Get-Culture", "Get-UICulture", "Get-TimeZone", "Get-PSDrive", "Get-Acl",
        "Get-ComputerInfo", "Get-CimInstance", "Get-WmiObject", "Get-NetTCPConnection", "Get-Module", "Get-ExecutionPolicy", "Get-History", "Get-Job",
        "Receive-Job", "Wait-Job", "Test-Connection", "Write-Progress", "Measure-Command", "Where", "Sort", "Get-Alias", "Out-Default", "Get-Error",
        "Set-StrictMode", "Import-PowerShellDataFile", "Test-Json", "Get-TypeData", "Get-Clipboard", "ConvertTo-SecureString", "Export-Csv", "Out-File",
    };

    private static readonly Dictionary<string, (string Category, ExecutionTier Tier)> Classified = new(StringComparer.OrdinalIgnoreCase)
    {
        // Mutating: files and state inside the working tree.
        ["Set-Content"] = ("file write", ExecutionTier.Mutating), ["Add-Content"] = ("file write", ExecutionTier.Mutating),
        ["Clear-Content"] = ("file write", ExecutionTier.Mutating), ["Out-File"] = ("file write", ExecutionTier.Mutating),
        ["Export-Csv"] = ("file write", ExecutionTier.Mutating), ["New-Item"] = ("file create", ExecutionTier.Mutating),
        ["Copy-Item"] = ("file copy", ExecutionTier.Mutating), ["Move-Item"] = ("file move", ExecutionTier.Mutating),
        ["Rename-Item"] = ("file rename", ExecutionTier.Mutating), ["Remove-Item"] = ("file delete", ExecutionTier.Mutating),
        ["Set-Item"] = ("item write", ExecutionTier.Mutating), ["Set-ItemProperty"] = ("item write", ExecutionTier.Mutating),
        ["New-ItemProperty"] = ("item write", ExecutionTier.Mutating), ["Remove-ItemProperty"] = ("item write", ExecutionTier.Mutating),
        ["Expand-Archive"] = ("archive", ExecutionTier.Mutating), ["Compress-Archive"] = ("archive", ExecutionTier.Mutating),
        ["Set-Variable"] = ("session state", ExecutionTier.ReadOnly), ["New-Alias"] = ("session state", ExecutionTier.ReadOnly),
        ["Set-Acl"] = ("permissions change", ExecutionTier.Elevated),
        // Elevated: processes, network, jobs, code evaluation.
        ["Start-Process"] = ("process start", ExecutionTier.Elevated), ["Stop-Process"] = ("process kill", ExecutionTier.Elevated),
        ["Invoke-Item"] = ("process start", ExecutionTier.Elevated), ["Start-Job"] = ("background job", ExecutionTier.Elevated),
        ["Start-ThreadJob"] = ("background job", ExecutionTier.Elevated), ["Invoke-Command"] = ("remote/scriptblock execution", ExecutionTier.Elevated),
        ["Invoke-Expression"] = ("dynamic code evaluation", ExecutionTier.Elevated), ["Add-Type"] = ("compiles and loads code", ExecutionTier.Elevated),
        ["Invoke-WebRequest"] = ("network", ExecutionTier.Elevated), ["Invoke-RestMethod"] = ("network", ExecutionTier.Elevated),
        ["Start-BitsTransfer"] = ("network", ExecutionTier.Elevated), ["Send-MailMessage"] = ("network", ExecutionTier.Elevated),
        ["New-PSSession"] = ("remoting", ExecutionTier.Elevated), ["Enter-PSSession"] = ("remoting", ExecutionTier.Elevated),
        ["Install-Module"] = ("installation", ExecutionTier.Elevated), ["Install-Package"] = ("installation", ExecutionTier.Elevated),
        ["Install-Script"] = ("installation", ExecutionTier.Elevated), ["Update-Module"] = ("installation", ExecutionTier.Elevated),
        ["Import-Module"] = ("loads code", ExecutionTier.Elevated), ["Get-Credential"] = ("credential operation", ExecutionTier.Elevated),
        ["Start-Service"] = ("service modification", ExecutionTier.Elevated), ["Stop-Service"] = ("service modification", ExecutionTier.Elevated),
        ["Restart-Service"] = ("service modification", ExecutionTier.Elevated), ["Set-Service"] = ("service modification", ExecutionTier.Elevated),
        ["New-Service"] = ("service modification", ExecutionTier.Elevated), ["Remove-Service"] = ("service modification", ExecutionTier.Elevated),
        ["Register-ScheduledTask"] = ("scheduled task", ExecutionTier.Elevated), ["Unregister-ScheduledTask"] = ("scheduled task", ExecutionTier.Elevated),
        ["New-ScheduledTask"] = ("scheduled task", ExecutionTier.Elevated), ["Set-ScheduledTask"] = ("scheduled task", ExecutionTier.Elevated),
        ["Set-Location"] = ("navigation", ExecutionTier.ReadOnly),
        // Blocked: destructive to the machine or its security configuration.
        ["Format-Volume"] = ("disk format", ExecutionTier.Blocked), ["Clear-Disk"] = ("disk wipe", ExecutionTier.Blocked),
        ["Initialize-Disk"] = ("disk initialization", ExecutionTier.Blocked), ["Remove-Partition"] = ("partition removal", ExecutionTier.Blocked),
        ["Stop-Computer"] = ("shutdown", ExecutionTier.Blocked), ["Restart-Computer"] = ("restart", ExecutionTier.Blocked),
        ["Set-ExecutionPolicy"] = ("execution policy change", ExecutionTier.Blocked), ["Disable-ComputerRestore"] = ("system configuration", ExecutionTier.Blocked),
        ["Set-MpPreference"] = ("security product configuration", ExecutionTier.Blocked), ["Add-MpPreference"] = ("security product configuration", ExecutionTier.Blocked),
        ["New-LocalUser"] = ("account management", ExecutionTier.Blocked), ["Add-LocalGroupMember"] = ("account management", ExecutionTier.Blocked),
        ["Set-LocalUser"] = ("account management", ExecutionTier.Blocked), ["Remove-LocalUser"] = ("account management", ExecutionTier.Blocked),
        ["Enable-PSRemoting"] = ("remoting configuration", ExecutionTier.Blocked), ["Set-Item WSMan"] = ("remoting configuration", ExecutionTier.Blocked),
        ["cmdkey"] = ("credential store", ExecutionTier.Blocked), ["vssadmin"] = ("shadow copies", ExecutionTier.Blocked),
        ["bcdedit"] = ("boot configuration", ExecutionTier.Blocked), ["diskpart"] = ("disk partitioning", ExecutionTier.Blocked),
        ["format"] = ("disk format", ExecutionTier.Blocked), ["reg"] = ("registry", ExecutionTier.Elevated), ["regedit"] = ("registry", ExecutionTier.Blocked),
        ["schtasks"] = ("scheduled task", ExecutionTier.Elevated), ["sc.exe"] = ("service modification", ExecutionTier.Elevated),
        ["shutdown"] = ("shutdown", ExecutionTier.Blocked), ["takeown"] = ("ownership change", ExecutionTier.Blocked), ["icacls"] = ("permissions change", ExecutionTier.Elevated),
        ["net"] = ("system/network configuration", ExecutionTier.Elevated), ["netsh"] = ("network configuration", ExecutionTier.Blocked),
        ["certutil"] = ("certificate/download utility", ExecutionTier.Elevated), ["bitsadmin"] = ("download utility", ExecutionTier.Elevated),
        ["curl.exe"] = ("network", ExecutionTier.Elevated), ["wget.exe"] = ("network", ExecutionTier.Elevated),
    };

    /// <summary>Well-known native tools that only read (when used without writing flags they are still "elevated" unless listed here).</summary>
    private static readonly HashSet<string> ReadOnlyNative = new(StringComparer.OrdinalIgnoreCase) { "where.exe", "whoami", "hostname", "findstr", "find.exe", "sort.exe", "more" };

    public static ExecutionAssessment Inspect(string script, IEnumerable<string>? extraBlocked = null)
    {
        var assessment = new ExecutionAssessment();
        var blocked = new HashSet<string>(extraBlocked ?? [], StringComparer.OrdinalIgnoreCase);
        var cleaned = StripCommentsAndStrings(script, out var strings);
        var lines = cleaned.Split('\n');

        // Script-wide patterns (on the cleaned text or on literals).
        for (var i = 0; i < lines.Length; i++)
        {
            var line = lines[i];
            var n = i + 1;
            if (EncodedCommand().IsMatch(line))
            {
                assessment.Add("-EncodedCommand", "obfuscated command", ExecutionTier.Blocked, n);
            }
            if (RegistryPath().IsMatch(line) && WriteVerb().IsMatch(line))
            {
                assessment.Add("registry write", "registry modification", ExecutionTier.Blocked, n);
            }
            else if (RegistryPath().IsMatch(line))
            {
                assessment.Add("registry read", "registry", ExecutionTier.ReadOnly, n);
            }
            if (DotNetDangerous().Match(line) is { Success: true } dotnet)
            {
                assessment.Add(dotnet.Value.Trim(), dotnet.Value.Contains("Net.", StringComparison.OrdinalIgnoreCase) || dotnet.Value.Contains("WebClient", StringComparison.OrdinalIgnoreCase) ? "network (.NET)" : "file or process operation (.NET)", ExecutionTier.Elevated, n);
            }
            if (RedirectWrite().IsMatch(line))
            {
                assessment.Add(">", "output redirection to a file", ExecutionTier.Mutating, n);
            }
            if (ScriptBlockInvoke().IsMatch(line))
            {
                assessment.Add("&", "call operator", ExecutionTier.Elevated, n);
            }
            if (QuotedInvoke().IsMatch(line))
            {
                // & "C:\tools\x.exe" or . 'script.ps1': the literal was stripped, so its target cannot be classified.
                assessment.Add("& \"…\"", "runs a program or script named by a string", ExecutionTier.Elevated, n);
            }
            if (PathInvoke().Match(line) is { Success: true } byPath)
            {
                assessment.Add(byPath.Groups["path"].Value, "runs a program or script by path", ExecutionTier.Elevated, n);
            }
        }
        foreach (var literal in strings)
        {
            if (literal.Contains("DownloadString", StringComparison.OrdinalIgnoreCase) || literal.Contains("FromBase64String", StringComparison.OrdinalIgnoreCase))
            {
                assessment.Add("encoded or downloaded code", "obfuscation", ExecutionTier.Elevated, 0);
            }
        }

        // Commands: the first word of every statement / pipeline element.
        foreach (var (command, line) in Commands(lines))
        {
            var name = Aliases.TryGetValue(command, out var full) ? full : command;
            if (blocked.Contains(name) || blocked.Contains(command))
            {
                assessment.Add(name, "blocked by configuration", ExecutionTier.Blocked, line);
                continue;
            }
            // Killing by name also ends the user's own programs of that name (their Notepad, their browser).
            if (name == "Stop-Process" && ByNameKill().IsMatch(lines[line - 1])
                || name.Equals("taskkill", StringComparison.OrdinalIgnoreCase) || name.Equals("taskkill.exe", StringComparison.OrdinalIgnoreCase))
            {
                assessment.Add(name, "process kill by name — also stops the user's own programs with that name; stop what DocGen started with process_stop", ExecutionTier.Elevated, line);
                continue;
            }
            if (name is "Invoke-RestMethod" or "Invoke-WebRequest" && IsPlainWebRead(lines[line - 1], command, strings))
            {
                // A GET of a public page or API that sends nothing and saves nothing: the same as http_request's web read.
                assessment.Add(name, WebReadCategory, ExecutionTier.Elevated, line);
                continue;
            }
            if (Classified.TryGetValue(name, out var c))
            {
                assessment.Add(name, c.Category, c.Tier, line);
                continue;
            }
            if (ReadOnlyCommands.Contains(name) || ReadOnlyNative.Contains(name))
            {
                continue;
            }
            if (name.Equals("git", StringComparison.OrdinalIgnoreCase) || name.Equals("git.exe", StringComparison.OrdinalIgnoreCase)
                || name.Equals("dotnet", StringComparison.OrdinalIgnoreCase) || name.Equals("dotnet.exe", StringComparison.OrdinalIgnoreCase))
            {
                var tail = lines[line - 1];
                var args = tail[(tail.IndexOf(command, StringComparison.OrdinalIgnoreCase) + command.Length)..].Split(' ', StringSplitOptions.RemoveEmptyEntries).ToList();
                var tier = name.StartsWith("git", StringComparison.OrdinalIgnoreCase) ? ProcessClassifier.Git(args) : ProcessClassifier.Dotnet(args);
                assessment.Add($"{name} {string.Join(' ', args.Take(2))}".Trim(), tier.Category, tier.Tier, line);
                continue;
            }
            // Unknown cmdlet or native program: may do anything. Package installs and network tools are named as such.
            var rest = lines[line - 1];
            var at = rest.IndexOf(command, StringComparison.OrdinalIgnoreCase);
            var nativeArgs = (at < 0 ? "" : rest[(at + command.Length)..]).Split(' ', StringSplitOptions.RemoveEmptyEntries);
            assessment.Add(name, name.Contains('-') ? "unrecognized cmdlet" : NativeCategory(name, nativeArgs), ExecutionTier.Elevated, line);
        }
        return assessment;
    }

    /// <summary>The finding category of a plain web read in a script (see <see cref="IsPlainWebRead"/>).</summary>
    public const string WebReadCategory = "web read";

    /// <summary>Whether the script only reads and reads the web: every finding is read-only or a plain web read.</summary>
    public static bool IsWebReadOnly(ExecutionAssessment assessment)
        => assessment.Findings.Any(f => f.Category == WebReadCategory)
           && assessment.Findings.All(f => f.Tier == ExecutionTier.ReadOnly || f.Category == WebReadCategory);

    /// <summary>Parameters that send data, use credentials or a session, or save to disk: such a request is not a plain read.</summary>
    private static readonly HashSet<string> WebWriteParameters = new(StringComparer.OrdinalIgnoreCase)
    {
        "Body", "InFile", "OutFile", "Form", "Headers", "Credential", "UseDefaultCredentials", "WebSession", "SessionVariable", "Authentication",
        "Token", "Certificate", "CertificateThumbprint", "Proxy", "ProxyCredential", "ProxyUseDefaultCredentials", "AllowUnencryptedAuthentication",
        "CustomMethod", "Resume", "ContentType", "TransferEncoding",
    };

    /// <summary>
    /// Invoke-RestMethod / Invoke-WebRequest as a plain read: GET or HEAD, nothing sent (no body, headers, credentials or
    /// session), nothing saved (-OutFile), no splatted parameters, and every URL written in the script is a public
    /// http(s) address (no localhost, private or link-local IP, or single-label host). Anything else stays "network".
    /// </summary>
    internal static bool IsPlainWebRead(string cleanedLine, string command, IReadOnlyList<string> literals)
    {
        var at = cleanedLine.IndexOf(command, StringComparison.OrdinalIgnoreCase);
        if (at < 0)
        {
            return false;
        }
        var segment = cleanedLine[(at + command.Length)..];
        var stop = segment.IndexOfAny(['|', ';', ')', '}']);
        if (stop >= 0)
        {
            segment = segment[..stop];
        }
        if (segment.Contains('@'))
        {
            return false;
        }
        var tokens = segment.Split([' ', '\t'], StringSplitOptions.RemoveEmptyEntries);
        for (var i = 0; i < tokens.Length; i++)
        {
            if (!tokens[i].StartsWith('-') || tokens[i].Length < 2 || !char.IsLetter(tokens[i][1]))
            {
                continue;
            }
            var parameter = tokens[i][1..].TrimEnd(':');
            if (WebWriteParameters.Any(p => p.StartsWith(parameter, StringComparison.OrdinalIgnoreCase) && parameter.Length >= 3 || p.Equals(parameter, StringComparison.OrdinalIgnoreCase)))
            {
                return false;
            }
            if ("Method".StartsWith(parameter, StringComparison.OrdinalIgnoreCase) && parameter.Length >= 2
                && !(i + 1 < tokens.Length && tokens[i + 1].Trim('\'', '"') is var method && (method.Equals("Get", StringComparison.OrdinalIgnoreCase) || method.Equals("Head", StringComparison.OrdinalIgnoreCase))))
            {
                return false;
            }
        }
        var urls = literals.Append(segment).SelectMany(l => UrlInLiteral().Matches(l).Select(m => m.Value)).ToList();
        return urls.Count > 0 && urls.All(IsPublicWebUrl);
    }

    private static bool IsPublicWebUrl(string url)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) || uri.Scheme is not ("http" or "https") || !string.IsNullOrEmpty(uri.UserInfo))
        {
            return false;
        }
        var host = uri.IdnHost.TrimEnd('.').ToLowerInvariant();
        if (System.Net.IPAddress.TryParse(host.Trim('[', ']'), out var ip))
        {
            var b = ip.MapToIPv4().GetAddressBytes();
            return !(System.Net.IPAddress.IsLoopback(ip) || ip.IsIPv6LinkLocal || ip.IsIPv6SiteLocal || ip.IsIPv6UniqueLocal
                     || b[0] is 10 or 127 or 0 || b[0] == 169 && b[1] == 254 || b[0] == 172 && b[1] is >= 16 and <= 31 || b[0] == 192 && b[1] == 168
                     || b[0] == 100 && b[1] is >= 64 and <= 127);
        }
        return host.Contains('.') && host != "localhost"
               && !new[] { ".localhost", ".local", ".internal", ".lan", ".home", ".corp", ".intranet", ".test" }.Any(host.EndsWith)
               && !host.StartsWith("metadata", StringComparison.Ordinal);
    }

    [GeneratedRegex(@"https?://[^\s'""`<>)]+", RegexOptions.IgnoreCase)]
    private static partial Regex UrlInLiteral();

    [GeneratedRegex(@"-(Process)?Name\b|\b(Get-Process|gps|ps)\s+(-Name\s+)?[A-Za-z*'""][^|]*\|\s*(Stop-Process|kill|spps)\b", RegexOptions.IgnoreCase)]
    private static partial Regex ByNameKill();

    private static readonly HashSet<string> PackageManagers = new(StringComparer.OrdinalIgnoreCase)
    {
        "npm", "pnpm", "yarn", "bun", "pip", "pip3", "pipx", "uv", "poetry", "conda", "winget", "choco", "scoop", "gem", "cargo", "go", "nuget", "composer", "apt", "apt-get", "brew",
    };

    private static readonly HashSet<string> InstallVerbs = new(StringComparer.OrdinalIgnoreCase)
    {
        "install", "i", "add", "update", "upgrade", "uninstall", "remove", "get", "publish", "push", "ci", "sync", "restore",
    };

    private static readonly HashSet<string> NetworkPrograms = new(StringComparer.OrdinalIgnoreCase)
    {
        "curl", "wget", "ssh", "scp", "sftp", "ftp", "rsync", "az", "aws", "gcloud", "kubectl", "helm", "gh", "telnet", "nc", "ncat",
    };

    /// <summary>What a native program does, as far as its name and first arguments tell (installs and network tools are named).</summary>
    internal static string NativeCategory(string name, IReadOnlyList<string> args)
    {
        var program = System.IO.Path.GetFileNameWithoutExtension(name);
        if (NetworkPrograms.Contains(program))
        {
            return "native program (network)";
        }
        if (PackageManagers.Contains(program) && args.FirstOrDefault(a => !a.StartsWith('-')) is { } verb && InstallVerbs.Contains(verb))
        {
            return $"{program} {verb} (package installation, uses the network)";
        }
        if (program.Equals("docker", StringComparison.OrdinalIgnoreCase) && args.FirstOrDefault() is "push" or "pull" or "login")
        {
            return "docker " + args[0] + " (network)";
        }
        return "native program";
    }

    /// <summary>Replaces comments with spaces and string literal contents with empty literals (keeps line structure).</summary>
    internal static string StripCommentsAndStrings(string script, out List<string> literals)
    {
        literals = [];
        var sb = new System.Text.StringBuilder(script.Length);
        var i = 0;
        while (i < script.Length)
        {
            var ch = script[i];
            if (ch == '<' && i + 1 < script.Length && script[i + 1] == '#')
            {
                var end = script.IndexOf("#>", i + 2, StringComparison.Ordinal);
                end = end < 0 ? script.Length : end + 2;
                sb.Append(new string(script[i..end].Select(c => c == '\n' ? '\n' : ' ').ToArray()));
                i = end;
                continue;
            }
            if (ch == '#')
            {
                while (i < script.Length && script[i] != '\n')
                {
                    sb.Append(' ');
                    i++;
                }
                continue;
            }
            if (ch == '@' && i + 1 < script.Length && script[i + 1] is '"' or '\'' && (i + 2 >= script.Length || script[i + 2] is '\n' or '\r'))
            {
                var quote = script[i + 1];
                var end = script.IndexOf("\n" + quote + "@", i + 2, StringComparison.Ordinal);
                end = end < 0 ? script.Length : end + 3;
                literals.Add(script[i..end]);
                sb.Append("''").Append(new string(script[i..end].Where(c => c == '\n').ToArray()));
                i = end;
                continue;
            }
            if (ch is '"' or '\'')
            {
                var j = i + 1;
                while (j < script.Length && script[j] != ch)
                {
                    if (ch == '"' && script[j] == '`')
                    {
                        j++;
                    }
                    j++;
                }
                var end = Math.Min(script.Length, j + 1);
                var literal = script[i..end];
                literals.Add(literal);
                // Subexpressions inside double quotes still execute: keep them for inspection.
                var sub = ch == '"' ? string.Join(" ; ", Subexpression().Matches(literal).Select(m => m.Groups[1].Value)) : "";
                sb.Append("''");
                if (sub.Length > 0)
                {
                    sb.Append(" ; ").Append(sub.Replace('\n', ' ')).Append(" ;");
                }
                sb.Append(new string(literal.Where(c => c == '\n').ToArray()));
                i = end;
                continue;
            }
            sb.Append(ch);
            i++;
        }
        return sb.ToString();
    }

    private static IEnumerable<(string Command, int Line)> Commands(string[] lines)
    {
        for (var i = 0; i < lines.Length; i++)
        {
            var line = lines[i];
            foreach (Match m in CommandPosition().Matches(line))
            {
                var word = m.Groups["cmd"].Value;
                if (word.Length == 0 || Keywords.Contains(word) || word.StartsWith('$') || word.StartsWith('[') || word.StartsWith('-') || char.IsDigit(word[0]))
                {
                    continue;
                }
                yield return (word, i + 1);
            }
        }
    }

    private static readonly HashSet<string> Keywords = new(StringComparer.OrdinalIgnoreCase)
    {
        "if", "else", "elseif", "foreach", "for", "while", "do", "until", "switch", "function", "filter", "param", "begin", "process", "end", "return",
        "break", "continue", "try", "catch", "finally", "throw", "trap", "in", "exit", "class", "enum", "using", "data", "dynamicparam", "hidden", "static",
        "true", "false", "null",
    };

    // A command appears at the start of a statement: line start, after ; | { ( && || or "=", ignoring leading spaces and "&" / ".".
    [GeneratedRegex(@"(?:^|[;|{(]|&&|\|\||=)\s*(?:[&.]\s+)?(?<cmd>[A-Za-z_?%][\w\-.:\\?%]*)", RegexOptions.CultureInvariant)]
    private static partial Regex CommandPosition();

    [GeneratedRegex(@"\s-(?:e|ec|en|enc|enco|encod|encode|encoded|encodedc\w*)\s+[A-Za-z0-9+/=]{16,}", RegexOptions.IgnoreCase)]
    private static partial Regex EncodedCommand();

    [GeneratedRegex(@"\b(?:HKLM|HKCU|HKCR|HKU|HKCC):|Registry::|\bHKEY_", RegexOptions.IgnoreCase)]
    private static partial Regex RegistryPath();

    [GeneratedRegex(@"\b(?:Set-|New-|Remove-|Rename-|Move-|Copy-|Clear-)\w*|\breg\s+(?:add|delete|import)", RegexOptions.IgnoreCase)]
    private static partial Regex WriteVerb();

    [GeneratedRegex(@"\[(?:System\.)?(?:IO\.File|IO\.Directory|Diagnostics\.Process|Net\.WebClient|Net\.Http\.HttpClient|Net\.WebRequest|Reflection\.Assembly|Runtime\.InteropServices\.Marshal|Environment)\]::\w+|New-Object\s+(?:System\.)?Net\.WebClient", RegexOptions.IgnoreCase)]
    private static partial Regex DotNetDangerous();

    [GeneratedRegex(@"(?<![-\w>])\d?>>?\s*(?!\s*\$null\b|&1|\s*&2)[^\s|;&]+", RegexOptions.CultureInvariant)]
    private static partial Regex RedirectWrite();

    [GeneratedRegex(@"(?:^|[;|{(])\s*&\s*[\$({]", RegexOptions.CultureInvariant)]
    private static partial Regex ScriptBlockInvoke();

    // Call or dot-source operator applied to a string literal (literals are reduced to '' before inspection).
    [GeneratedRegex(@"(?:^|[;|{(]|&&|\|\|)\s*[&.]\s*''", RegexOptions.CultureInvariant)]
    private static partial Regex QuotedInvoke();

    // A statement that starts with a path: .\x.exe, ..\bin\x, \x, /x, ~/x or C:\x (optionally after & or .).
    [GeneratedRegex(@"(?:^|[;|{(]|&&|\|\|)\s*(?:[&.]\s+)?(?<path>(?:\.{1,2}[\\/]|[\\/~]|[A-Za-z]:[\\/])[^\s;|&)]*)", RegexOptions.CultureInvariant)]
    private static partial Regex PathInvoke();

    [GeneratedRegex(@"\$\(([^()]*(?:\([^()]*\)[^()]*)*)\)")]
    private static partial Regex Subexpression();
}

/// <summary>Classification of direct process invocations (run_process and native calls inside scripts).</summary>
public static class ProcessClassifier
{
    private static readonly HashSet<string> GitReadOnly = new(StringComparer.OrdinalIgnoreCase)
    {
        "status", "diff", "log", "show", "rev-parse", "ls-files", "ls-tree", "blame", "describe", "shortlog", "cat-file", "grep", "reflog", "config",
        "branch", "tag", "remote", "rev-list", "merge-base", "name-rev", "for-each-ref", "whatchanged", "count-objects", "check-ignore", "version", "help", "--version",
        "stash",
    };

    private static readonly HashSet<string> GitNetwork = new(StringComparer.OrdinalIgnoreCase) { "push", "pull", "fetch", "clone", "submodule", "ls-remote" };

    /// <summary>Options that change which configuration, repository or programs Git uses, or where it writes.</summary>
    private static readonly string[] GitRiskyOptionPrefixes =
    [
        "--config-env", "--git-dir", "--work-tree", "--exec-path", "--namespace", "--super-prefix", "--output", "--open-files-in-pager",
        "--no-index", "--ext-diff", "--textconv", "--upload-pack", "--receive-pack", "--exec=", "--template",
    ];

    public static (string Category, ExecutionTier Tier) Git(IReadOnlyList<string> args)
    {
        var subIndex = args.ToList().FindIndex(a => !a.StartsWith('-'));
        // Any option before the subcommand is a global option (-c key=value, -C dir, --git-dir…): it changes what Git
        // reads or runs, so the call is never treated as read-only. The same holds for redirecting options anywhere.
        var leading = subIndex < 0 ? args : args.Take(subIndex);
        if (leading.Any(a => a is not ("--no-pager" or "--version" or "--help")))
        {
            return ("git with global options", ExecutionTier.Elevated);
        }
        if (args.Any(a => GitRiskyOptionPrefixes.Any(p => a.StartsWith(p, StringComparison.OrdinalIgnoreCase)) || a.StartsWith("-O", StringComparison.Ordinal)))
        {
            return ("git with configuration or redirection options", ExecutionTier.Elevated);
        }
        var sub = args.FirstOrDefault(a => !a.StartsWith('-')) ?? (args.Count > 0 ? args[0] : "");
        if (GitNetwork.Contains(sub))
        {
            return ("git network operation", ExecutionTier.Elevated);
        }
        if (GitReadOnly.Contains(sub))
        {
            // Listing is read-only; creating/deleting branches, tags, remotes, config values or stash entries is not.
            var writes = sub switch
            {
                "branch" or "tag" => args.Skip(1).Any(a => !a.StartsWith('-') || a is "-d" or "-D" or "--delete" or "-m" or "-M" or "-f"),
                "remote" => args.Skip(1).Any(a => a is "add" or "remove" or "rm" or "rename" or "set-url"),
                "config" => !args.Any(a => a is "--get" or "--list" or "-l" or "--get-all" or "--get-regexp"),
                "stash" => !args.Skip(1).Any(a => a is "list" or "show"),
                _ => false,
            };
            return writes ? ("git " + sub + " (writes)", ExecutionTier.Mutating) : ("git " + sub, ExecutionTier.ReadOnly);
        }
        return ("git " + sub + " (modifies the repository)", ExecutionTier.Mutating);
    }

    public static (string Category, ExecutionTier Tier) Dotnet(IReadOnlyList<string> args)
    {
        var sub = args.FirstOrDefault() ?? "";
        return sub switch
        {
            "--info" or "--version" or "--list-sdks" or "--list-runtimes" or "-h" or "--help" => ("dotnet " + sub, ExecutionTier.ReadOnly),
            "list" => ("dotnet list", ExecutionTier.ReadOnly),
            "build" or "test" or "restore" or "format" or "clean" or "pack" or "publish" or "new" or "add" or "remove" or "sln" => ("dotnet " + sub + " (builds or changes the project; runs repository code)", ExecutionTier.Mutating),
            "tool" when args.Skip(1).FirstOrDefault() is "install" or "update" or "uninstall" => ("dotnet tool " + args[1] + " (installation, uses the network)", ExecutionTier.Elevated),
            "workload" when args.Skip(1).FirstOrDefault() is not ("list" or "search" or null) => ("dotnet workload (installation, uses the network)", ExecutionTier.Elevated),
            "nuget" when args.Skip(1).FirstOrDefault() is "push" or "delete" => ("dotnet nuget " + args[1] + " (uses the network)", ExecutionTier.Elevated),
            "run" or "watch" or "exec" or "tool" or "workload" or "nuget" or "ef" => ("dotnet " + sub + " (starts code)", ExecutionTier.Elevated),
            _ => ("dotnet " + sub, ExecutionTier.Elevated),
        };
    }

    public static (string Category, ExecutionTier Tier) Classify(string executableKind, string executableName, IReadOnlyList<string> args)
        => executableKind switch
        {
            "git" => Git(args),
            "dotnet" => Dotnet(args),
            _ => (PowerShellInspector.NativeCategory(executableName, args).Replace("native program", executableName + " (allow-listed program)"), ExecutionTier.Elevated),
        };
}
