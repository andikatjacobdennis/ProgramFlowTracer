using System.Text;
using DocGen.Analysis.Browser;
using DocGen.Analysis.Commands;
using DocGen.Analysis.Investigations;
using DocGen.Core.Abstractions;
using DocGen.Core.Models;

namespace DocGen.Analysis.Execution;

/// <summary>Investigation and RCA state for compaction snapshots: never discarded because the context is full.</summary>
public sealed class InvestigationCompactionProvider(InvestigationService investigations) : ICompactionStateProvider
{
    public async Task<CompactionSection?> GetSectionAsync(CompactionContext context, CancellationToken ct)
    {
        if (context.ConversationId is null || await investigations.GetActiveForConversationAsync(context.UserId, context.ConversationId, ct) is not { } i)
        {
            return null;
        }
        var sb = new StringBuilder();
        sb.AppendLine($"Investigation {i.Id}: {i.Title} [{i.Status}] · repository {i.Repository} · reproduction {i.Reproduction.Status}");
        sb.AppendLine("Symptom: " + Clip(i.Symptom, 800));
        sb.AppendLine("Root cause: " + (i.RootCause is { } rc ? $"CONFIRMED — {rc.Statement} ({rc.HypothesisId}{(rc.Location is null ? "" : ", " + rc.Location)}; evidence {string.Join(", ", rc.EvidenceIds)})" : "not yet confirmed"));
        if (i.Hypotheses.Count > 0)
        {
            sb.AppendLine("Hypotheses:");
            foreach (var h in i.Hypotheses)
            {
                sb.AppendLine($"- {h.Id} [{h.Status}] {Clip(h.Statement, 240)} (for: {string.Join(", ", h.SupportingEvidence)}; against: {string.Join(", ", h.ContradictingEvidence)}){(h.Limitation is null ? "" : " limitation: " + Clip(h.Limitation, 160))}");
            }
        }
        if (i.Rca is { } rca)
        {
            sb.AppendLine($"Root-cause ranking ({rca.At:yyyy-MM-dd HH:mm} UTC): {Clip(rca.Summary, 300)}");
            if (rca.Trace.Count > 0)
            {
                sb.AppendLine("Trace (origin → failure): " + string.Join(" → ", rca.Trace.Select(n => $"{Clip(n.Title, 90)}{(n.File is null ? "" : $" [{n.File}:{n.Line}]")}")));
            }
            foreach (var c in rca.Candidates.Take(6))
            {
                sb.AppendLine($"- [{c.Strength}] {Clip(c.Title, 120)} ({c.Role}) {c.Location}: {Clip(c.Why, 220)}");
            }
            foreach (var e in rca.Experiments.Take(4))
            {
                sb.AppendLine($"- Experiment {e.Id}: {Clip(e.Description, 200)}");
            }
        }
        var counterfactuals = i.Evidence.Where(e => e.Counterfactual).ToList();
        foreach (var e in counterfactuals)
        {
            sb.AppendLine($"- Counterfactual {e.Id} ({e.Outcome}){(e.HypothesisId is null ? "" : " for " + e.HypothesisId)}: {Clip(e.Summary, 240)}");
        }
        var other = i.Evidence.Where(e => !e.Counterfactual).ToList();
        sb.AppendLine($"Evidence ledger: {i.Evidence.Count} items (investigation_status shows all). Latest:");
        foreach (var e in other.TakeLast(12))
        {
            sb.AppendLine($"- {e.Id} {e.Kind.ToUpperInvariant()}: {Clip(e.Summary, 200)}{(e.Source is null ? "" : " [" + Clip(e.Source, 80) + "]")}");
        }
        if (i.Fix is { } fix)
        {
            sb.AppendLine($"Fix: {Clip(fix.Summary, 200)} · files: {string.Join(", ", fix.FilesChanged.Take(10))}");
        }
        foreach (var v in i.Verification.TakeLast(3))
        {
            sb.AppendLine($"Verification: {(v.Passed ? "PASSED" : "FAILED")} — {Clip(v.Summary, 160)}");
        }
        var mustMention = new List<string> { i.Id };
        mustMention.AddRange(i.Hypotheses.Select(h => h.Id + " ["));
        mustMention.AddRange(counterfactuals.Select(e => e.Id));
        if (i.RootCause is { } root)
        {
            mustMention.Add("CONFIRMED");
        }
        return new CompactionSection { Name = "investigation", Title = "Investigation and root-cause analysis", Content = sb.ToString(), Required = true, MustMention = mustMention };
    }

    private static string Clip(string text, int max) => text.Length > max ? text[..max] + "…" : text;
}

/// <summary>Commands started by the run: running ones must survive compaction; finished ones keep their outcome and output reference.</summary>
public sealed class CommandCompactionProvider(CommandRunner runner) : ICompactionStateProvider
{
    public async Task<CompactionSection?> GetSectionAsync(CompactionContext context, CancellationToken ct)
    {
        var commands = (await runner.ListAsync(context.UserId, 500, ct)).Where(c => c.RunId == context.RunId && c.Kind != CommandKinds.Browser).OrderBy(c => c.CreatedAt).ToList();
        if (commands.Count == 0)
        {
            return null;
        }
        var sb = new StringBuilder();
        var running = commands.Where(c => !c.IsFinal).ToList();
        if (running.Count > 0)
        {
            sb.AppendLine("Still running (check with command_status, stop with process_stop):");
            foreach (var c in running)
            {
                sb.AppendLine($"- command {c.Id} [{c.Kind}] {Clip(c.Description ?? c.CommandLine, 160)} · started {c.StartedAt:HH:mm:ss} UTC{(c.ServerId is null ? "" : " · server " + c.ServerId)}");
            }
        }
        if (commands.LastOrDefault(c => c.Build is not null && c.IsFinal) is { Build: { } build } lastBuild)
        {
            sb.AppendLine($"Latest build: {build.Result}, {build.ErrorCount} errors, {build.WarningCount} warnings (command {lastBuild.Id}).");
        }
        if (commands.LastOrDefault(c => c.Tests is not null && c.IsFinal) is { Tests: { } tests } lastTest)
        {
            sb.AppendLine($"Latest tests: {tests.Result}, {tests.Passed ?? 0} passed, {tests.Failed ?? tests.Failures.Count} failed, {tests.Skipped ?? 0} skipped (command {lastTest.Id})" +
                          (tests.Failures.Count > 0 ? ": " + string.Join("; ", tests.Failures.Take(5).Select(f => f.Name)) : "."));
        }
        sb.AppendLine($"Commands run ({commands.Count}, most recent last; full output: command_status commandId=…):");
        foreach (var c in commands.Where(c => c.IsFinal).TakeLast(25))
        {
            sb.AppendLine($"- {c.Id} {c.Status}{(c.ExitCode is { } e ? $" exit {e}" : "")} {c.DurationMs / 1000.0:0.0}s · {Clip(c.Description ?? c.CommandLine, 140)}");
        }
        return new CompactionSection
        {
            Name = "commands", Title = "Commands, builds and tests", Content = sb.ToString(), Required = running.Count > 0,
            MustMention = running.Select(c => c.Id).ToList(),
        };
    }

    private static string Clip(string text, int max) => text.Length > max ? text[..max] + "…" : text;
}

public sealed class DevServerCompactionProvider(DevServerService servers) : ICompactionStateProvider
{
    public async Task<CompactionSection?> GetSectionAsync(CompactionContext context, CancellationToken ct)
    {
        var active = (await servers.ListAsync(context.UserId, ct)).Where(s => s.Status is DevServerStatus.Starting or DevServerStatus.Running).ToList();
        if (active.Count == 0)
        {
            return null;
        }
        var sb = new StringBuilder("Running development servers (dev_server_status / dev_server_stop):\n");
        foreach (var s in active)
        {
            sb.AppendLine($"- serverId {s.ServerId} {s.Name}: {s.Status} · URL {(s.Url ?? "not determined")} · command {s.CommandId} · {s.Repository}:{s.WorkingDirectory}");
        }
        return new CompactionSection { Name = "servers", Title = "Development servers", Content = sb.ToString(), Required = true, MustMention = active.Select(s => s.ServerId).ToList() };
    }
}

public sealed class BrowserCompactionProvider(BrowserService browser) : ICompactionStateProvider
{
    public Task<CompactionSection?> GetSectionAsync(CompactionContext context, CancellationToken ct)
    {
        var sessions = browser.OpenSessions(context.UserId);
        if (sessions.Count == 0)
        {
            return Task.FromResult<CompactionSection?>(null);
        }
        var sb = new StringBuilder();
        var tabs = new List<string>();
        foreach (var s in sessions)
        {
            sb.AppendLine($"Browser session {s.SessionId} ({s.Browser}, headless, fresh profile); active tab {s.ActiveTabId}:");
            foreach (var t in s.Tabs.Where(t => !t.Closed))
            {
                tabs.Add(t.TabId);
                sb.AppendLine($"- {t.TabId} — {(t.Title.Length == 0 ? "(untitled)" : t.Title)} — {t.Url}{(t.Viewport is null ? " — default viewport" : $" — {t.Viewport}")}");
            }
            if (s.BlockedNavigations.Count > 0)
            {
                sb.AppendLine("Blocked navigations: " + string.Join("; ", s.BlockedNavigations.TakeLast(3)));
            }
        }
        return Task.FromResult<CompactionSection?>(new CompactionSection { Name = "browser", Title = "Browser state", Content = sb.ToString(), Required = true, MustMention = tabs });
    }
}
