using System.Globalization;
using System.IO.Compression;
using System.Runtime.InteropServices;
using System.Text;

namespace DocGen.Analysis.Execution;

/// <summary>One visible top-level window of a process tree.</summary>
public sealed record AppWindow(IntPtr Handle, int ProcessId, string ProcessName, string Title);

/// <summary>A captured window: a PNG plus a compact description of its pixels for models without vision.</summary>
public sealed class WindowShot
{
    public required AppWindow Window { get; init; }
    public int Width { get; init; }
    public int Height { get; init; }
    public bool Minimized { get; init; }
    public string Method { get; init; } = "";
    public byte[]? Png { get; init; }

    /// <summary>Most common colours (quantised) with their share of the window, largest first.</summary>
    public List<(string Hex, double Share)> Colors { get; init; } = [];

    /// <summary>Average colour of each cell of a coarse grid (rows top to bottom), for a sense of layout.</summary>
    public List<string[]> Grid { get; init; } = [];

    /// <summary>Share of pixels that are (near) black — a blank GPU surface usually captures as black.</summary>
    public double BlackShare { get; init; }
}

/// <summary>
/// Captures the windows of processes DocGen started (a dev server's or command's process tree) with plain Win32 calls:
/// PrintWindow with full-content rendering (works for WPF/DirectX surfaces), falling back to a screen copy when that
/// comes back blank. Only windows owned by the given process tree are ever captured — never arbitrary desktop windows.
/// </summary>
public static class WindowCapture
{
    public const int GridColumns = 8;
    public const int GridRows = 6;
    private const int MaxDimension = 4096;

    /// <summary>The process and all its descendants (by parent process id).</summary>
    public static HashSet<int> ProcessTree(int rootProcessId)
    {
        var tree = new HashSet<int> { rootProcessId };
        if (!OperatingSystem.IsWindows())
        {
            return tree;
        }
        var parents = new List<(int Pid, int Parent)>();
        var snapshot = CreateToolhelp32Snapshot(0x2 /* TH32CS_SNAPPROCESS */, 0);
        if (snapshot == IntPtr.Zero || snapshot == new IntPtr(-1))
        {
            return tree;
        }
        try
        {
            var entry = new PROCESSENTRY32W { dwSize = (uint)Marshal.SizeOf<PROCESSENTRY32W>() };
            for (var ok = Process32FirstW(snapshot, ref entry); ok; ok = Process32NextW(snapshot, ref entry))
            {
                parents.Add(((int)entry.th32ProcessID, (int)entry.th32ParentProcessID));
            }
        }
        finally
        {
            CloseHandle(snapshot);
        }
        // Breadth-first over parent links; a process id reused by an unrelated process older than its "parent" is rare and harmless here.
        for (var changed = true; changed;)
        {
            changed = false;
            foreach (var (pid, parent) in parents)
            {
                if (pid != parent && tree.Contains(parent) && tree.Add(pid))
                {
                    changed = true;
                }
            }
        }
        return tree;
    }

    /// <summary>Visible top-level windows (with a non-empty size) owned by any of the processes.</summary>
    public static List<AppWindow> Windows(ISet<int> processIds)
    {
        var found = new List<AppWindow>();
        if (!OperatingSystem.IsWindows())
        {
            return found;
        }
        EnumWindows((hwnd, _) =>
        {
            if (!IsWindowVisible(hwnd))
            {
                return true;
            }
            GetWindowThreadProcessId(hwnd, out var pid);
            if (!processIds.Contains((int)pid) || !GetWindowRect(hwnd, out var r) || r.Right - r.Left < 2 || r.Bottom - r.Top < 2)
            {
                return true;
            }
            var length = GetWindowTextLengthW(hwnd);
            var title = new StringBuilder(Math.Min(length, 512) + 1);
            GetWindowTextW(hwnd, title, title.Capacity);
            string name;
            try
            {
                using var process = System.Diagnostics.Process.GetProcessById((int)pid);
                name = process.ProcessName;
            }
            catch (ArgumentException)
            {
                name = "?";
            }
            found.Add(new AppWindow(hwnd, (int)pid, name, title.ToString()));
            return true;
        }, IntPtr.Zero);
        return found;
    }

    public static WindowShot Capture(AppWindow window)
    {
        if (!OperatingSystem.IsWindows())
        {
            throw new PlatformNotSupportedException("Window capture needs Windows.");
        }
        // Physical pixels: without per-monitor awareness a scaled display reports virtualised (smaller) sizes.
        var previous = SetThreadDpiAwarenessContext(new IntPtr(-4) /* PER_MONITOR_AWARE_V2 */);
        try
        {
            if (IsIconic(window.Handle))
            {
                return new WindowShot { Window = window, Minimized = true, Method = "none (minimized)" };
            }
            var rect = Bounds(window.Handle);
            var width = Math.Clamp(rect.Right - rect.Left, 1, MaxDimension);
            var height = Math.Clamp(rect.Bottom - rect.Top, 1, MaxDimension);

            var printed = Grab(width, height, dc => PrintWindow(window.Handle, dc, 0x2 /* PW_RENDERFULLCONTENT */));
            var method = "PrintWindow";
            var pixels = printed;
            if (printed is null || BlackShare(printed) > 0.9)
            {
                // Some GPU surfaces print as black: copy what is on screen instead (the window must not be covered).
                var screen = Grab(width, height, dc =>
                {
                    var desktop = GetDC(IntPtr.Zero);
                    try
                    {
                        return BitBlt(dc, 0, 0, width, height, desktop, rect.Left, rect.Top, 0x00CC0020 /* SRCCOPY */);
                    }
                    finally
                    {
                        ReleaseDC(IntPtr.Zero, desktop);
                    }
                });
                if (screen is not null && (pixels is null || BlackShare(screen) < BlackShare(pixels)))
                {
                    pixels = screen;
                    method = "screen copy";
                }
            }
            if (pixels is null)
            {
                return new WindowShot { Window = window, Width = width, Height = height, Method = "failed" };
            }
            return new WindowShot
            {
                Window = window, Width = width, Height = height, Method = method, Png = EncodePng(pixels, width, height),
                Colors = TopColors(pixels, 6), Grid = AverageGrid(pixels, width, height), BlackShare = BlackShare(pixels),
            };
        }
        finally
        {
            SetThreadDpiAwarenessContext(previous);
        }
    }

    private static RECT Bounds(IntPtr hwnd)
    {
        // The visible frame (without the invisible resize borders of Windows 10/11).
        if (DwmGetWindowAttribute(hwnd, 9 /* DWMWA_EXTENDED_FRAME_BOUNDS */, out RECT frame, Marshal.SizeOf<RECT>()) == 0 && frame.Right > frame.Left)
        {
            return frame;
        }
        GetWindowRect(hwnd, out var rect);
        return rect;
    }

    /// <summary>Renders into a 32-bit top-down DIB and returns its BGRA bytes (null when drawing failed).</summary>
    private static byte[]? Grab(int width, int height, Func<IntPtr, bool> draw)
    {
        var screenDc = GetDC(IntPtr.Zero);
        var memoryDc = CreateCompatibleDC(screenDc);
        var info = new BITMAPINFO { biSize = (uint)Marshal.SizeOf<BITMAPINFO>(), biWidth = width, biHeight = -height, biPlanes = 1, biBitCount = 32 };
        var bitmap = CreateDIBSection(screenDc, ref info, 0, out var bits, IntPtr.Zero, 0);
        try
        {
            if (bitmap == IntPtr.Zero || bits == IntPtr.Zero)
            {
                return null;
            }
            var old = SelectObject(memoryDc, bitmap);
            var ok = draw(memoryDc);
            SelectObject(memoryDc, old);
            if (!ok)
            {
                return null;
            }
            var data = new byte[width * height * 4];
            Marshal.Copy(bits, data, 0, data.Length);
            return data;
        }
        finally
        {
            if (bitmap != IntPtr.Zero)
            {
                DeleteObject(bitmap);
            }
            DeleteDC(memoryDc);
            ReleaseDC(IntPtr.Zero, screenDc);
        }
    }

    public static double BlackShare(byte[] bgra)
    {
        long black = 0, total = bgra.Length / 4;
        for (var i = 0; i < bgra.Length; i += 4)
        {
            if (bgra[i] < 12 && bgra[i + 1] < 12 && bgra[i + 2] < 12)
            {
                black++;
            }
        }
        return total == 0 ? 1 : (double)black / total;
    }

    /// <summary>Most common colours after quantising to 4 bits per channel (reported as the bucket's average colour).</summary>
    public static List<(string Hex, double Share)> TopColors(byte[] bgra, int count)
    {
        var buckets = new Dictionary<int, (long N, long B, long G, long R)>();
        for (var i = 0; i < bgra.Length; i += 4)
        {
            var key = (bgra[i + 2] >> 4 << 8) | (bgra[i + 1] >> 4 << 4) | (bgra[i] >> 4);
            buckets.TryGetValue(key, out var v);
            buckets[key] = (v.N + 1, v.B + bgra[i], v.G + bgra[i + 1], v.R + bgra[i + 2]);
        }
        double total = bgra.Length / 4;
        return buckets.Values.OrderByDescending(v => v.N).Take(count)
            .Select(v => (Hex((int)(v.R / v.N), (int)(v.G / v.N), (int)(v.B / v.N)), v.N / total)).ToList();
    }

    public static List<string[]> AverageGrid(byte[] bgra, int width, int height)
    {
        var grid = new List<string[]>();
        for (var row = 0; row < GridRows; row++)
        {
            var cells = new string[GridColumns];
            var y0 = row * height / GridRows;
            var y1 = Math.Max(y0 + 1, (row + 1) * height / GridRows);
            for (var col = 0; col < GridColumns; col++)
            {
                var x0 = col * width / GridColumns;
                var x1 = Math.Max(x0 + 1, (col + 1) * width / GridColumns);
                long r = 0, g = 0, b = 0, n = 0;
                // Every other pixel is enough for an average.
                for (var y = y0; y < y1 && y < height; y += 2)
                {
                    for (var x = x0; x < x1 && x < width; x += 2)
                    {
                        var i = (y * width + x) * 4;
                        b += bgra[i];
                        g += bgra[i + 1];
                        r += bgra[i + 2];
                        n++;
                    }
                }
                cells[col] = n == 0 ? "-" : Hex((int)(r / n), (int)(g / n), (int)(b / n));
            }
            grid.Add(cells);
        }
        return grid;
    }

    private static string Hex(int r, int g, int b) => "#" + r.ToString("X2", CultureInfo.InvariantCulture) + g.ToString("X2", CultureInfo.InvariantCulture) + b.ToString("X2", CultureInfo.InvariantCulture);

    /// <summary>Minimal PNG encoder (8-bit RGB, filter "Sub", zlib) — no imaging packages needed.</summary>
    public static byte[] EncodePng(byte[] bgra, int width, int height)
    {
        using var raw = new MemoryStream();
        using (var z = new ZLibStream(raw, CompressionLevel.Fastest, leaveOpen: true))
        {
            var line = new byte[1 + width * 3];
            line[0] = 1; // Sub: each byte minus the byte one pixel to the left.
            for (var y = 0; y < height; y++)
            {
                var row = y * width * 4;
                for (var x = 0; x < width; x++)
                {
                    var i = row + x * 4;
                    var o = 1 + x * 3;
                    byte r = bgra[i + 2], g = bgra[i + 1], b = bgra[i];
                    if (x == 0)
                    {
                        line[o] = r;
                        line[o + 1] = g;
                        line[o + 2] = b;
                    }
                    else
                    {
                        line[o] = (byte)(r - bgra[i - 2]);
                        line[o + 1] = (byte)(g - bgra[i - 3]);
                        line[o + 2] = (byte)(b - bgra[i - 4]);
                    }
                }
                z.Write(line);
            }
        }
        using var png = new MemoryStream();
        png.Write([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]);
        var header = new byte[13];
        WriteBigEndian(header, 0, (uint)width);
        WriteBigEndian(header, 4, (uint)height);
        header[8] = 8;  // bit depth
        header[9] = 2;  // colour type: RGB
        Chunk(png, "IHDR", header);
        Chunk(png, "IDAT", raw.ToArray());
        Chunk(png, "IEND", []);
        return png.ToArray();
    }

    private static void Chunk(Stream s, string type, byte[] data)
    {
        var buffer = new byte[4];
        WriteBigEndian(buffer, 0, (uint)data.Length);
        s.Write(buffer);
        var typeBytes = Encoding.ASCII.GetBytes(type);
        s.Write(typeBytes);
        s.Write(data);
        var crc = Crc32(Crc32(0xFFFFFFFF, typeBytes), data) ^ 0xFFFFFFFF;
        WriteBigEndian(buffer, 0, crc);
        s.Write(buffer);
    }

    private static readonly uint[] CrcTable = Enumerable.Range(0, 256).Select(n =>
    {
        var c = (uint)n;
        for (var k = 0; k < 8; k++)
        {
            c = (c & 1) != 0 ? 0xEDB88320 ^ (c >> 1) : c >> 1;
        }
        return c;
    }).ToArray();

    private static uint Crc32(uint crc, byte[] data)
    {
        foreach (var b in data)
        {
            crc = CrcTable[(crc ^ b) & 0xFF] ^ (crc >> 8);
        }
        return crc;
    }

    private static void WriteBigEndian(byte[] buffer, int offset, uint value)
    {
        buffer[offset] = (byte)(value >> 24);
        buffer[offset + 1] = (byte)(value >> 16);
        buffer[offset + 2] = (byte)(value >> 8);
        buffer[offset + 3] = (byte)value;
    }

    // ---- Win32 ----
    private delegate bool EnumWindowsProc(IntPtr hwnd, IntPtr lParam);

    [StructLayout(LayoutKind.Sequential)]
    private struct RECT
    {
        public int Left, Top, Right, Bottom;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct BITMAPINFO
    {
        public uint biSize;
        public int biWidth, biHeight;
        public ushort biPlanes, biBitCount;
        public uint biCompression, biSizeImage;
        public int biXPelsPerMeter, biYPelsPerMeter;
        public uint biClrUsed, biClrImportant;
        public uint bmiColors;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct PROCESSENTRY32W
    {
        public uint dwSize, cntUsage, th32ProcessID;
        public IntPtr th32DefaultHeapID;
        public uint th32ModuleID, cntThreads, th32ParentProcessID;
        public int pcPriClassBase;
        public uint dwFlags;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
        public string szExeFile;
    }

    [DllImport("user32.dll")] private static extern bool EnumWindows(EnumWindowsProc callback, IntPtr lParam);
    [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll")] private static extern bool IsIconic(IntPtr hwnd);
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint processId);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetWindowTextLengthW(IntPtr hwnd);
    [DllImport("user32.dll", CharSet = CharSet.Unicode)] private static extern int GetWindowTextW(IntPtr hwnd, StringBuilder text, int maxCount);
    [DllImport("user32.dll")] private static extern bool GetWindowRect(IntPtr hwnd, out RECT rect);
    [DllImport("user32.dll")] private static extern bool PrintWindow(IntPtr hwnd, IntPtr hdc, uint flags);
    [DllImport("user32.dll")] private static extern IntPtr GetDC(IntPtr hwnd);
    [DllImport("user32.dll")] private static extern int ReleaseDC(IntPtr hwnd, IntPtr hdc);
    [DllImport("user32.dll")] private static extern IntPtr SetThreadDpiAwarenessContext(IntPtr context);
    [DllImport("gdi32.dll")] private static extern IntPtr CreateCompatibleDC(IntPtr hdc);
    [DllImport("gdi32.dll")] private static extern IntPtr CreateDIBSection(IntPtr hdc, ref BITMAPINFO info, uint usage, out IntPtr bits, IntPtr section, uint offset);
    [DllImport("gdi32.dll")] private static extern IntPtr SelectObject(IntPtr hdc, IntPtr obj);
    [DllImport("gdi32.dll")] private static extern bool DeleteObject(IntPtr obj);
    [DllImport("gdi32.dll")] private static extern bool DeleteDC(IntPtr hdc);
    [DllImport("gdi32.dll")] private static extern bool BitBlt(IntPtr dest, int x, int y, int width, int height, IntPtr source, int sx, int sy, uint rop);
    [DllImport("dwmapi.dll")] private static extern int DwmGetWindowAttribute(IntPtr hwnd, int attribute, out RECT value, int size);
    [DllImport("kernel32.dll", SetLastError = true)] private static extern IntPtr CreateToolhelp32Snapshot(uint flags, uint processId);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] private static extern bool Process32FirstW(IntPtr snapshot, ref PROCESSENTRY32W entry);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] private static extern bool Process32NextW(IntPtr snapshot, ref PROCESSENTRY32W entry);
    [DllImport("kernel32.dll")] private static extern bool CloseHandle(IntPtr handle);
}
