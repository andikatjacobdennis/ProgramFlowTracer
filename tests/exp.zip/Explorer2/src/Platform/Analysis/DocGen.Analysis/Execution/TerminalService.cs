using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;
using DocGen.Core.Exceptions;
using DocGen.Core.Options;
using DocGen.Core.Models;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Execution;

/// <summary>A shell a terminal can use.</summary>
public sealed record TerminalShell(string Id, string Label, string Path);

/// <summary>Public state of one terminal session.</summary>
public sealed record TerminalState(
    string Id, string Shell, string ShellLabel, string Cwd, string Status, int? ExitCode, string? Command, long OutputEnd, DateTimeOffset CreatedAt,
    string? RootLabel = null, string? DisplayCwd = null);

/// <summary>
/// Text: the line after completing the common part (bash style). Candidates: matching names to show. Options: the whole
/// line completed with each candidate in turn, for Tab / Shift+Tab cycling (PowerShell and cmd style).
/// </summary>
public sealed record TerminalCompletion(string Text, IReadOnlyList<string> Candidates, IReadOnlyList<string>? Options = null);

/// <summary>
/// The built-in terminal: an administrator's own shell sessions (PowerShell, Command Prompt, Git Bash), run on their
/// explicit action only — the model has no tool for it. Each command is a child process whose raw output (including
/// progress bars drawn with carriage returns and ANSI escapes) is appended to the session's output log, which clients
/// stream by character offset and render with a small VT renderer. PowerShell sessions keep the working directory
/// across commands (the wrapper reports it back); for the other shells a plain "cd" is handled by DocGen.
/// Secret-looking environment variables are removed from the child environment and their values redacted from output.
/// </summary>
public sealed partial class TerminalService(IOptionsMonitor<TerminalOptions> options, ILogger<TerminalService> logger) : IHostedService
{
    private const char Marker = '\u001e';
    private const string CwdTag = "DOCGEN-CWD:";
    private static readonly TimeSpan FlushDelay = TimeSpan.FromMilliseconds(120);

    private readonly ConcurrentDictionary<string, Session> _sessions = new(StringComparer.Ordinal);
    private IReadOnlyList<TerminalShell>? _shells;

    private sealed class Session
    {
        public required string Id { get; init; }
        public required string UserId { get; init; }
        public required TerminalShell Shell { get; init; }
        public required string Cwd { get; set; }

        /// <summary>The repository the terminal was opened for ("workspace", "sample-repo"…) and its root, shown instead of the full path.</summary>
        public string? RootLabel { get; init; }
        public string? Root { get; init; }
        public DateTimeOffset CreatedAt { get; } = DateTimeOffset.UtcNow;
        public readonly object Sync = new();
        public readonly StringBuilder Buffer = new();
        public long BaseOffset;
        public char LastChar = '\n';
        public Process? Process;
        public string? Command;
        public int? ExitCode;
        public bool Interrupted;
        public event Action? Changed;
        public void Notify() => Changed?.Invoke();
        public long End => BaseOffset + Buffer.Length;
    }

    public TerminalOptions Settings => options.CurrentValue;

    /// <summary>Shells installed on this machine (Windows PowerShell and Command Prompt always; PowerShell 7 and Git Bash when found).</summary>
    public IReadOnlyList<TerminalShell> Shells => _shells ??= DetectShells();

    private static List<TerminalShell> DetectShells()
    {
        var list = new List<TerminalShell>();
        var windows = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        var winPs = Path.Combine(windows, "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
        if (File.Exists(winPs))
        {
            list.Add(new TerminalShell("powershell", "Windows PowerShell", winPs));
        }
        if ((FindOnPath("pwsh.exe") ?? Existing(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "PowerShell", "7", "pwsh.exe"))) is { } pwsh)
        {
            list.Add(new TerminalShell("pwsh", "PowerShell 7", pwsh));
        }
        var cmd = Environment.GetEnvironmentVariable("ComSpec") is { Length: > 0 } spec && File.Exists(spec) ? spec : Existing(Path.Combine(windows, "System32", "cmd.exe"));
        if (cmd is not null)
        {
            list.Add(new TerminalShell("cmd", "Command Prompt", cmd));
        }
        var gitBash = Existing(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Git", "bin", "bash.exe"))
                      ?? Existing(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Programs", "Git", "bin", "bash.exe"));
        if (gitBash is not null)
        {
            list.Add(new TerminalShell("bash", "Git Bash", gitBash));
        }
        if (!OperatingSystem.IsWindows())
        {
            list.Clear();
            if (Existing("/bin/bash") is { } bash)
            {
                list.Add(new TerminalShell("bash", "Bash", bash));
            }
            if (FindOnPath("pwsh") is { } pwshUnix)
            {
                list.Add(new TerminalShell("pwsh", "PowerShell 7", pwshUnix));
            }
        }
        return list;
    }

    private static string? Existing(string path) => File.Exists(path) ? path : null;

    private static string? FindOnPath(string exe)
        => (Environment.GetEnvironmentVariable("PATH") ?? "").Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries)
            .Select(d => { try { return Path.Combine(d.Trim(), exe); } catch (ArgumentException) { return ""; } })
            .FirstOrDefault(File.Exists);

    /// <summary>Closes every terminal of every user (stopping their commands). Returns how many were closed.</summary>
    public int CloseAll(string reason)
    {
        var count = 0;
        foreach (var session in _sessions.Values.ToList())
        {
            Interrupt(session, reason);
            if (_sessions.TryRemove(session.Id, out _))
            {
                count++;
                session.Notify();
            }
        }
        return count;
    }

    public IReadOnlyList<TerminalState> List(string userId)
        => _sessions.Values.Where(s => s.UserId == userId).OrderBy(s => s.CreatedAt).Select(State).ToList();

    public TerminalState Get(string userId, string id) => State(Find(userId, id));

    public TerminalState Create(string userId, string? shellId, string cwd, string? rootLabel = null)
    {
        EnsureEnabled();
        if (_sessions.Values.Count(s => s.UserId == userId) >= Settings.MaxSessionsPerUser)
        {
            throw new ValidationException($"At most {Settings.MaxSessionsPerUser} terminals can be open; close one first.");
        }
        var shell = string.IsNullOrWhiteSpace(shellId)
            ? Shells.FirstOrDefault() ?? throw new ValidationException("No shell is available on this machine.")
            : Shells.FirstOrDefault(s => string.Equals(s.Id, shellId, StringComparison.OrdinalIgnoreCase)) ?? throw new ValidationException($"Unknown or unavailable shell '{shellId}'.");
        if (!Directory.Exists(cwd))
        {
            throw new ValidationException("The starting folder does not exist.");
        }
        var full = Path.GetFullPath(cwd);
        var session = new Session { Id = Ids.New(), UserId = userId, Shell = shell, Cwd = full, RootLabel = rootLabel, Root = rootLabel is null ? null : full };
        _sessions[session.Id] = session;
        logger.LogInformation("Terminal {TerminalId} opened ({Shell}) by {UserId}", session.Id, shell.Id, userId);
        return State(session);
    }

    public async Task CloseAsync(string userId, string id)
    {
        var session = Find(userId, id);
        Interrupt(session, "closed");
        _sessions.TryRemove(id, out _);
        session.Notify();
        await Task.CompletedTask;
    }

    /// <summary>Runs a command typed (or explicitly run) by the user. One command at a time per terminal.</summary>
    public TerminalState Run(string userId, string id, string command)
    {
        EnsureEnabled();
        var session = Find(userId, id);
        command = (command ?? "").Replace("\r\n", "\n").TrimEnd();
        if (command.Length > Settings.MaxCommandChars)
        {
            throw new ValidationException($"Commands are limited to {Settings.MaxCommandChars:N0} characters.");
        }
        lock (session.Sync)
        {
            if (session.Process is not null)
            {
                throw new DocGenException("CONFLICT", "A command is still running in this terminal. Stop it or open another terminal.", 409);
            }
            AppendLocked(session, Prompt(session) + "\u001b[1m" + command.Replace("\n", "\r\n>> ") + "\u001b[0m\r\n");
            if (command.Length == 0)
            {
                session.Notify();
                return State(session);
            }
            if (session.Shell.Id is not ("powershell" or "pwsh") && TryChangeDirectory(session, command) is { } cdResult)
            {
                if (cdResult.Length > 0)
                {
                    AppendLocked(session, "\u001b[31m" + cdResult + "\u001b[0m\r\n");
                }
                session.Command = null;
                session.ExitCode = cdResult.Length > 0 ? 1 : 0;
                session.Notify();
                return State(session);
            }

            var psi = BuildStartInfo(session, command, out var secrets);
            var redactor = new OutputRedactor(secrets);
            Process process;
            try
            {
                process = Process.Start(psi) ?? throw new InvalidOperationException("The shell did not start.");
            }
            catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or InvalidOperationException)
            {
                AppendLocked(session, $"\u001b[31mCould not start {session.Shell.Label}: {ex.Message}\u001b[0m\r\n");
                session.Notify();
                return State(session);
            }
            session.Process = process;
            session.Command = command;
            session.ExitCode = null;
            session.Interrupted = false;
            logger.LogInformation("Terminal {TerminalId} runs a command ({Length} chars, first word {Program})", session.Id, command.Length,
                Regex.Match(command, @"^[\w.\-]{1,40}").Value);
            _ = PumpAsync(session, process, redactor);
            session.Notify();
            return State(session);
        }
    }

    /// <summary>Sends a line of input to the running command's standard input (echoed unless it is secret).</summary>
    public async Task SendInputAsync(string userId, string id, string text, bool secret)
    {
        var session = Find(userId, id);
        Process? process;
        lock (session.Sync)
        {
            process = session.Process ?? throw new DocGenException("CONFLICT", "No command is running in this terminal.", 409);
            AppendLocked(session, (secret ? new string('•', Math.Min(text.Length, 12)) : text) + "\r\n");
        }
        session.Notify();
        try
        {
            await process.StandardInput.WriteAsync(text + "\n");
            await process.StandardInput.FlushAsync();
        }
        catch (Exception ex) when (ex is IOException or InvalidOperationException or ObjectDisposedException)
        {
            throw new DocGenException("CONFLICT", "The command no longer accepts input.", 409);
        }
    }

    /// <summary>Stops the running command (and everything it started).</summary>
    public bool Interrupt(string userId, string id) => Interrupt(Find(userId, id), "stopped");

    public void Clear(string userId, string id)
    {
        var session = Find(userId, id);
        lock (session.Sync)
        {
            session.BaseOffset += session.Buffer.Length;
            session.Buffer.Clear();
            AppendLocked(session, "\u001b[2J\u001b[H");
        }
        session.Notify();
    }

    /// <summary>Output from <paramref name="from"/> (character offset); returns the actual start (later when older output was dropped).</summary>
    public (long Start, string Text, long End) Read(string userId, string id, long from, int maxChars = 256 * 1024)
    {
        var session = Find(userId, id);
        lock (session.Sync)
        {
            var start = Math.Clamp(from, session.BaseOffset, session.End);
            var index = (int)(start - session.BaseOffset);
            var count = Math.Min(maxChars, session.Buffer.Length - index);
            return (start, session.Buffer.ToString(index, count), session.End);
        }
    }

    public IDisposable Subscribe(string userId, string id, Action onChange)
    {
        var session = Find(userId, id);
        session.Changed += onChange;
        return new Unsubscriber(() => session.Changed -= onChange);
    }

    public bool Exists(string userId, string id) => _sessions.TryGetValue(id, out var s) && s.UserId == userId;

    private sealed class Unsubscriber(Action dispose) : IDisposable
    {
        public void Dispose() => dispose();
    }

    private void EnsureEnabled()
    {
        if (!Settings.Enabled)
        {
            throw new ForbiddenException("The terminal is disabled (DocGen:Terminal:Enabled).");
        }
    }

    private Session Find(string userId, string id)
        => _sessions.TryGetValue(id ?? "", out var s) && s.UserId == userId ? s : throw new NotFoundException("Terminal");

    /// <summary>
    /// Tab completion of a file or folder name: the last word of <paramref name="text"/> is completed against the
    /// terminal's folder (relative, absolute, "~", ".\" or "../" paths). One match completes it (folders get a trailing
    /// separator, names with spaces are quoted); several extend it to their common prefix and are returned as candidates.
    /// </summary>
    public TerminalCompletion Complete(string userId, string id, string text)
    {
        var session = Find(userId, id);
        text ??= "";
        var (start, word) = LastWord(text);
        var bash = session.Shell.Id == "bash";
        var sep = bash || word.Contains('/') ? '/' : '\\';
        var typedDir = word.LastIndexOfAny(['\\', '/']) is var cut and >= 0 ? word[..(cut + 1)] : "";
        var prefix = word[typedDir.Length..];

        string folder;
        try
        {
            var dirPart = typedDir;
            if (dirPart.StartsWith('~'))
            {
                dirPart = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + dirPart[1..];
            }
            else if (bash && System.Text.RegularExpressions.Regex.Match(dirPart, "^/([A-Za-z])(/.*)?$") is { Success: true } drive)
            {
                dirPart = drive.Groups[1].Value + ":\\" + drive.Groups[2].Value.TrimStart('/');
            }
            folder = Path.GetFullPath(Path.Combine(session.Cwd, dirPart.Length == 0 ? "." : dirPart));
            if (!Directory.Exists(folder))
            {
                return new TerminalCompletion(text, []);
            }
        }
        catch (Exception ex) when (ex is ArgumentException or NotSupportedException or PathTooLongException or IOException)
        {
            return new TerminalCompletion(text, []);
        }

        List<(string Name, bool Dir)> matches;
        try
        {
            // Wildcards (* and ?) match like the shells do; otherwise names starting with what was typed.
            var wildcard = prefix.IndexOfAny(['*', '?']) >= 0
                ? new System.Text.RegularExpressions.Regex("^" + System.Text.RegularExpressions.Regex.Escape(prefix).Replace("\\*", ".*").Replace("\\?", ".") + (prefix.EndsWith('*') ? "" : ".*") + "$",
                    System.Text.RegularExpressions.RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.CultureInvariant)
                : null;
            matches = new DirectoryInfo(folder).EnumerateFileSystemInfos()
                .Where(i => wildcard?.IsMatch(i.Name) ?? i.Name.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                .Select(i => (i.Name, i is DirectoryInfo))
                .OrderBy(m => m.Item1, StringComparer.OrdinalIgnoreCase)
                .Take(500)
                .ToList();
        }
        catch (Exception ex) when (ex is UnauthorizedAccessException or IOException)
        {
            return new TerminalCompletion(text, []);
        }
        if (matches.Count == 0)
        {
            return new TerminalCompletion(text, []);
        }

        string Quote(string value) => value.Contains(' ') ? "\"" + value + "\"" : value;
        var options = matches.Take(100).Select(m => text[..start] + Quote(typedDir + m.Name + (m.Dir ? sep.ToString() : ""))).ToList();
        if (prefix.IndexOfAny(['*', '?']) >= 0)
        {
            // A wildcard never has a useful common prefix: offer the matches to cycle through.
            return new TerminalCompletion(matches.Count == 1 ? options[0] : text, matches.Count == 1 ? [] : matches.Take(100).Select(m => m.Name + (m.Dir ? sep.ToString() : "")).ToList(), options);
        }
        if (matches.Count == 1)
        {
            var (name, dir) = matches[0];
            var completed = typedDir + name + (dir ? sep.ToString() : "");
            return new TerminalCompletion(text[..start] + Quote(completed) + (dir ? "" : " "), [], options);
        }
        var common = matches.Select(m => m.Name).Aggregate((a, b) =>
        {
            var n = 0;
            while (n < a.Length && n < b.Length && char.ToLowerInvariant(a[n]) == char.ToLowerInvariant(b[n]))
            {
                n++;
            }
            return a[..n];
        });
        var extended = common.Length > prefix.Length ? typedDir + common : word;
        return new TerminalCompletion(text[..start] + (extended == word ? word : Quote(extended)),
            matches.Take(100).Select(m => m.Name + (m.Dir ? sep.ToString() : "")).ToList(), options);
    }

    /// <summary>The last word of a command line (a quoted word counts as one) and where it starts.</summary>
    private static (int Start, string Word) LastWord(string text)
    {
        var quotes = text.Count(c => c == '"');
        if (quotes % 2 == 1)
        {
            var open = text.LastIndexOf('"');
            return (open, text[(open + 1)..]);
        }
        var space = text.LastIndexOfAny([' ', '\t']);
        return (space + 1, text[(space + 1)..].Trim('"'));
    }

    private static TerminalState State(Session s)
    {
        lock (s.Sync)
        {
            return new TerminalState(s.Id, s.Shell.Id, s.Shell.Label, s.Cwd, s.Process is null ? "idle" : "running", s.ExitCode, s.Command, s.End, s.CreatedAt,
                s.RootLabel, DisplayCwd(s));
        }
    }

    private static string Prompt(Session s) => s.Shell.Id switch
    {
        "cmd" => $"\u001b[32m{DisplayCwd(s)}>\u001b[0m",
        "bash" => $"\u001b[32m{(InsideRoot(s) ? DisplayCwd(s).Replace('\\', '/') : BashPath(s.Cwd))}\u001b[0m $ ",
        _ => $"\u001b[32mPS {DisplayCwd(s)}>\u001b[0m ",
    };

    private static bool InsideRoot(Session s)
        => s.Root is { } root && (s.Cwd.Equals(root, StringComparison.OrdinalIgnoreCase)
                                  || s.Cwd.StartsWith(root.TrimEnd('\\') + "\\", StringComparison.OrdinalIgnoreCase));

    /// <summary>
    /// Inside the repository the terminal was opened for, the folder is shown as "workspace\generated\app" instead of the
    /// long physical path (a workspace lives in a folder named by a user id). Outside it, the real path.
    /// </summary>
    private static string DisplayCwd(Session s)
        => InsideRoot(s) ? s.RootLabel + s.Cwd[s.Root!.TrimEnd('\\').Length..] : s.Cwd;

    private static string BashPath(string path)
        => path.Length >= 2 && path[1] == ':' ? "/" + char.ToLowerInvariant(path[0]) + path[2..].Replace('\\', '/') : path;

    /// <summary>"cd" for shells whose directory changes do not survive the process: null when the command is not a plain cd.</summary>
    private static string? TryChangeDirectory(Session session, string command)
    {
        var match = CdPattern().Match(command.Trim());
        if (!match.Success)
        {
            return null;
        }
        var target = match.Groups["path"].Value.Trim().Trim('"', '\'');
        if (target.Length == 0)
        {
            return session.Shell.Id == "cmd" ? "" : ChangeTo(session, Environment.GetFolderPath(Environment.SpecialFolder.UserProfile));
        }
        if (target == "~" || target.StartsWith("~/", StringComparison.Ordinal))
        {
            target = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), target.Length > 2 ? target[2..] : "");
        }
        else if (Regex.Match(target, "^/([A-Za-z])(/.*)?$") is { Success: true } drive)
        {
            target = drive.Groups[1].Value.ToUpperInvariant() + ":\\" + drive.Groups[2].Value.TrimStart('/').Replace('/', '\\');
        }
        return ChangeTo(session, target);
    }

    private static string ChangeTo(Session session, string target)
    {
        try
        {
            var full = Path.GetFullPath(Path.Combine(session.Cwd, target));
            if (!Directory.Exists(full))
            {
                return $"The folder '{target}' does not exist.";
            }
            session.Cwd = full;
            return "";
        }
        catch (Exception ex) when (ex is ArgumentException or NotSupportedException or PathTooLongException)
        {
            return $"Invalid folder: {ex.Message}";
        }
    }

    // "cd.." and "cd\" (no space) are valid in Command Prompt and commonly typed.
    [GeneratedRegex(@"^(?:cd|chdir|Set-Location|sl)(?:\s+/d)?(?:\s+(?<path>[^&|;<>\n]*)|(?<path>(?:\.\.?|[\\/])[^&|;<>\n]*))?$", RegexOptions.IgnoreCase)]
    private static partial Regex CdPattern();

    private ProcessStartInfo BuildStartInfo(Session session, string command, out List<string> secrets)
    {
        var psi = new ProcessStartInfo(session.Shell.Path)
        {
            WorkingDirectory = session.Cwd,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardInput = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            StandardOutputEncoding = new UTF8Encoding(false),
            StandardErrorEncoding = new UTF8Encoding(false),
            StandardInputEncoding = new UTF8Encoding(false),
        };
        secrets = ApplyEnvironment(psi.Environment);
        switch (session.Shell.Id)
        {
            case "powershell" or "pwsh":
                psi.Environment["TERMINAL_COMMAND"] = command;
                psi.Environment["TERMINAL_CWD"] = session.Cwd;
                // -Command, not -EncodedCommand: with -EncodedCommand PowerShell serializes its error stream as CLIXML and
                // writes it only when it exits, so an error from a long-running command (a server, a watch script) stayed
                // hidden until it stopped. With -Command errors are plain text, written the moment they happen. The
                // wrapper is a constant without double quotes; the user's command still arrives in an environment variable.
                foreach (var a in new[] { "-NoLogo", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", PowerShellWrapper })
                {
                    psi.ArgumentList.Add(a);
                }
                break;
            case "cmd":
                psi.Arguments = "/d /s /c \"" + command.Replace("\n", " & ") + "\"";
                break;
            default:
                psi.ArgumentList.Add("-c");
                psi.ArgumentList.Add(command);
                psi.Environment["CHERE_INVOKING"] = "1";
                break;
        }
        return psi;
    }

    /// <summary>The user's environment minus secret-looking variables (whose values are then redacted) and DocGen's own settings.</summary>
    private static List<string> ApplyEnvironment(IDictionary<string, string?> environment)
    {
        var secrets = new List<string>();
        foreach (var name in environment.Keys.ToList())
        {
            if (EnvironmentPolicy.LooksSecret(name) || name.StartsWith("DOCGEN_", StringComparison.OrdinalIgnoreCase) || name.StartsWith("ASPNETCORE_", StringComparison.OrdinalIgnoreCase))
            {
                if (EnvironmentPolicy.LooksSecret(name) && environment[name] is { Length: >= 4 } value)
                {
                    secrets.Add(value);
                }
                environment.Remove(name);
            }
        }
        environment["POWERSHELL_TELEMETRY_OPTOUT"] = "1";
        environment["POWERSHELL_UPDATECHECK"] = "Off";
        environment["GIT_TERMINAL_PROMPT"] = "0";
        environment["GIT_PAGER"] = "cat";
        environment["PAGER"] = "cat";
        environment["PYTHONIOENCODING"] = "utf-8";
        return secrets;
    }

    /// <summary>
    /// PowerShell: the command arrives in an environment variable (never spliced into script text), is parsed as a
    /// script block and dot-sourced, then the working directory is reported back behind a marker.
    /// </summary>
    private const string PowerShellWrapper = """
        $ErrorActionPreference = 'Continue'
        $ProgressPreference = 'SilentlyContinue'
        [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false
        $OutputEncoding = [Console]::OutputEncoding
        $__h = @{ Command = $env:TERMINAL_COMMAND; Code = 0 }
        Set-Location -LiteralPath $env:TERMINAL_CWD
        Remove-Item Env:TERMINAL_COMMAND, Env:TERMINAL_CWD -ErrorAction SilentlyContinue
        try {
          $__h.Block = [ScriptBlock]::Create($__h.Command)
          $global:LASTEXITCODE = 0
          . $__h.Block
          if (-not $?) { $__h.Code = 1 }
          if ($global:LASTEXITCODE) { $__h.Code = $global:LASTEXITCODE }
        } catch {
          [Console]::Error.WriteLine($_.Exception.Message)
          $__h.Code = 1
        } finally {
          [Console]::Out.Flush()
          [Console]::Out.Write([string][char]30 + 'DOCGEN-CWD:' + (Get-Location).ProviderPath + [char]30)
          [Console]::Out.Flush()
        }
        exit $__h.Code
        """;

    private async Task PumpAsync(Session session, Process process, OutputRedactor redactor)
    {
        var stdout = new StreamPump(isStdout: true);
        var stderr = new StreamPump(isStdout: false);
        using var runTimeout = Settings.MaxRunSeconds > 0 ? new CancellationTokenSource(TimeSpan.FromSeconds(Settings.MaxRunSeconds)) : new CancellationTokenSource();
        using var reg = runTimeout.Token.Register(() => Interrupt(session, $"stopped after {Settings.MaxRunSeconds} s (DocGen:Terminal:MaxRunSeconds)"));
        using var flusher = new PeriodicTimer(FlushDelay);
        var reading = Task.WhenAll(ReadAsync(process.StandardOutput, stdout), ReadAsync(process.StandardError, stderr));
        var flushing = Task.Run(async () =>
        {
            try
            {
                while (await flusher.WaitForNextTickAsync())
                {
                    Emit(session, stdout.Take(force: true), redactor, stdout);
                    Emit(session, stderr.Take(force: true), redactor, null);
                }
            }
            catch (OperationCanceledException)
            {
            }
        });

        try
        {
            await reading;
            await process.WaitForExitAsync();
        }
        catch (Exception ex) when (ex is IOException or InvalidOperationException or ObjectDisposedException)
        {
            logger.LogDebug(ex, "Terminal {TerminalId} output ended", session.Id);
        }
        flusher.Dispose();
        await flushing;
        Emit(session, stdout.Take(force: true, final: true), redactor, stdout);
        Emit(session, stderr.Take(force: true, final: true), redactor, null);

        int? code = null;
        try
        {
            code = process.ExitCode;
        }
        catch (InvalidOperationException)
        {
        }
        lock (session.Sync)
        {
            if (session.LastChar != '\n')
            {
                AppendLocked(session, "\r\n");
            }
            if (session.Interrupted)
            {
                AppendLocked(session, "\u001b[33m^C\u001b[0m\r\n");
            }
            else if (code is not null and not 0)
            {
                AppendLocked(session, $"\u001b[31m[exit code {code}]\u001b[0m\r\n");
                if (ExitHint(session.Command, code.Value, session.Shell.Id) is { } hint)
                {
                    AppendLocked(session, $"\u001b[33m{hint}\u001b[0m\r\n");
                }
            }
            session.ExitCode = code;
            session.Process = null;
        }
        process.Dispose();
        session.Notify();
    }

    /// <summary>
    /// A one-line explanation for failures whose cause is not obvious from the output: curl run with -s prints nothing
    /// but an exit code, and Git Bash silently drops the backslashes of a Windows path.
    /// </summary>
    public static string? ExitHint(string? command, int code, string? shell = null)
    {
        // Only unquoted backslashes are lost: inside '…' and "…" Bash keeps them.
        if (shell == "bash" && command is not null && BackslashPath().IsMatch(Regex.Replace(command, "'[^']*'|\"[^\"]*\"", " ")))
        {
            return "Git Bash treats \\ as an escape character, so a Windows path like folder\\file loses its backslashes. " +
                   "Use / in paths (folder/file.py), or run the command in a PowerShell or Command Prompt tab.";
        }
        var first = command?.TrimStart().Split(' ', 2)[0].ToLowerInvariant();
        if (first is not ("curl" or "curl.exe"))
        {
            return null;
        }
        return code switch
        {
            6 => "curl: could not resolve the host name. Check the URL (including http:// or https://).",
            7 => "curl: could not connect. Nothing is listening at that address and port. Is the server running? Start it in another terminal tab first.",
            22 => "curl: the server returned an HTTP error (4xx/5xx). Run it with -i to see the status and response body.",
            26 => "curl: a file named with @ (in --data, --data-binary or -F) does not exist in the current folder. Create it first or give its full path.",
            28 => "curl: the request timed out.",
            35 or 60 => "curl: TLS/certificate problem. For a local https dev server, try the http:// address instead.",
            _ => null,
        };
    }

    /// <summary>A backslash between two path characters (folderile), outside of what looks like an escape sequence.</summary>
    [GeneratedRegex(@"[A-Za-z0-9_.\-]\\[A-Za-z0-9_.\-]")]
    private static partial Regex BackslashPath();

    private static async Task ReadAsync(StreamReader reader, StreamPump pump)
    {
        var buffer = new char[8192];
        int read;
        while ((read = await reader.ReadAsync(buffer.AsMemory())) > 0)
        {
            pump.Add(buffer.AsSpan(0, read));
        }
    }

    /// <summary>Appends redacted output; for stdout, strips the working-directory marker and applies it.</summary>
    private void Emit(Session session, string text, OutputRedactor redactor, StreamPump? stdout)
    {
        if (text.Length == 0)
        {
            return;
        }
        if (stdout is not null)
        {
            var start = text.IndexOf(Marker, StringComparison.Ordinal);
            while (start >= 0)
            {
                var end = text.IndexOf(Marker, start + 1);
                if (end < 0)
                {
                    break;
                }
                var payload = text[(start + 1)..end];
                if (payload.StartsWith(CwdTag, StringComparison.Ordinal) && Directory.Exists(payload[CwdTag.Length..]))
                {
                    lock (session.Sync)
                    {
                        session.Cwd = payload[CwdTag.Length..];
                    }
                }
                text = text[..start] + text[(end + 1)..];
                start = text.IndexOf(Marker, start);
            }
        }
        if (text.Length == 0)
        {
            return;
        }
        lock (session.Sync)
        {
            AppendLocked(session, redactor.Redact(text).Replace("\r\r\n", "\r\n"));
        }
        session.Notify();
    }

    private void AppendLocked(Session session, string text)
    {
        if (text.Length == 0)
        {
            return;
        }
        session.Buffer.Append(text);
        session.LastChar = text[^1];
        var max = Math.Max(10_000, Settings.MaxOutputChars);
        if (session.Buffer.Length > max)
        {
            var drop = session.Buffer.Length - max * 4 / 5;
            session.Buffer.Remove(0, drop);
            session.BaseOffset += drop;
        }
    }

    private bool Interrupt(Session session, string reason)
    {
        Process? process;
        lock (session.Sync)
        {
            process = session.Process;
            if (process is null)
            {
                return false;
            }
            session.Interrupted = true;
        }
        try
        {
            if (!process.HasExited)
            {
                process.Kill(entireProcessTree: true);
            }
        }
        catch (Exception ex) when (ex is InvalidOperationException or System.ComponentModel.Win32Exception or NotSupportedException)
        {
            logger.LogDebug(ex, "Terminal {TerminalId}: stop failed", session.Id);
        }
        logger.LogInformation("Terminal {TerminalId} command {Reason}", session.Id, reason);
        return true;
    }

    public Task StartAsync(CancellationToken cancellationToken) => Task.CompletedTask;

    public Task StopAsync(CancellationToken cancellationToken)
    {
        foreach (var session in _sessions.Values)
        {
            Interrupt(session, "stopped because DocGen is shutting down");
        }
        return Task.CompletedTask;
    }

    /// <summary>
    /// Pending output of one stream. Text up to the last line break (or carriage return) is released at once; the rest
    /// on the next flush tick, so progress bars redraw live. A marker that has started but not finished is held back.
    /// Stderr goes through <see cref="PowerShellErrorStream.Reader"/>, which decodes PowerShell's serialized errors as
    /// each one completes and holds back only a fragment that is still arriving.
    /// </summary>
    private sealed class StreamPump(bool isStdout)
    {
        private readonly StringBuilder _pending = new();
        private readonly object _sync = new();
        private readonly PowerShellErrorStream.Reader _errors = new();

        public void Add(ReadOnlySpan<char> chunk)
        {
            lock (_sync)
            {
                _pending.Append(chunk);
            }
        }

        public string Take(bool force, bool final = false)
        {
            lock (_sync)
            {
                if (_pending.Length == 0)
                {
                    return "";
                }
                var text = _pending.ToString();
                if (!isStdout)
                {
                    // PowerShell's error document is decoded element by element as it arrives (it stays open for the
                    // whole command); plain text follows the same line-break rule as stdout.
                    var lastLineBreak = text.LastIndexOfAny(['\n', '\r']);
                    var plainLimit = force || final ? text.Length : lastLineBreak + 1;
                    var output = _errors.Take(text, plainLimit, final, out var consumed);
                    _pending.Remove(0, consumed);
                    return output;
                }
                var cut = text.Length;
                if (isStdout && !final)
                {
                    // Hold an unfinished marker (odd count of marker characters) until its end arrives.
                    var markers = text.Count(c => c == Marker);
                    if (markers % 2 == 1)
                    {
                        cut = text.LastIndexOf(Marker);
                    }
                }
                if (!force)
                {
                    var lastBreak = text.LastIndexOfAny(['\n', '\r'], Math.Max(0, cut - 1));
                    cut = lastBreak < 0 ? 0 : Math.Min(cut, lastBreak + 1);
                }
                _pending.Remove(0, cut);
                return text[..cut];
            }
        }
    }
}
