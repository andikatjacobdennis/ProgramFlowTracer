using System.Net;
using System.Text.Json;
using System.Text.RegularExpressions;
using DocGen.Analysis.Commands;
using DocGen.Analysis.Repositories;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Core.Options;
using DocGen.Data.Storage;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Execution;

public static class DevServerStatus
{
    public const string Starting = "starting";
    public const string Running = "running";
    public const string Stopped = "stopped";
    public const string Exited = "exited";
    public const string Failed = "failed";
}

/// <summary>What was asked for, kept so a restart repeats exactly the same launch.</summary>
public sealed class DevServerStartRequest
{
    public string Repository { get; set; } = "workspace";

    /// <summary>Project file (relative) for dotnet run.</summary>
    public string? Project { get; set; }

    /// <summary>Allow-listed executable for non-dotnet servers (with Arguments).</summary>
    public string? Executable { get; set; }

    public List<string> Arguments { get; set; } = [];
    public string? WorkingDirectory { get; set; }
    public string? LaunchProfile { get; set; }
    public bool NoBuild { get; set; }

    /// <summary>Arguments passed to the application after "--" (e.g. --urls, --DocGen:DataDirectory=…).</summary>
    public List<string> ApplicationArguments { get; set; } = [];

    public Dictionary<string, string>? Environment { get; set; }
    public string? Name { get; set; }
}

/// <summary>Persistent record of a development server DocGen started (data/servers/{userId}/{serverId}.json).</summary>
public sealed class DevServerRecord
{
    public string ServerId { get; set; } = Guid.NewGuid().ToString();
    public string UserId { get; set; } = "";
    public string? RunId { get; set; }
    public string? ConversationId { get; set; }
    public string? ProjectId { get; set; }
    public string Name { get; set; } = "";
    public string Repository { get; set; } = "";
    public string CommandId { get; set; } = "";
    public string CommandLine { get; set; } = "";
    public string WorkingDirectory { get; set; } = ".";

    /// <summary>The URL the application actually listens on — null when it could not be determined (never invented).</summary>
    public string? Url { get; set; }

    /// <summary>output | health-check | none</summary>
    public string UrlSource { get; set; } = "none";

    /// <summary>URLs from configuration (launchSettings, --urls): hints only, never reported as the listening URL unless confirmed.</summary>
    public List<string> ConfiguredUrls { get; set; } = [];

    public int? ProcessId { get; set; }
    public string Status { get; set; } = DevServerStatus.Starting;
    public DateTime StartedAt { get; set; } = DateTime.UtcNow;
    public DateTime? StoppedAt { get; set; }
    public int? ExitCode { get; set; }
    public string? LastHealth { get; set; }
    public DateTime? LastHealthAt { get; set; }
    public List<string> Notes { get; set; } = [];
    public DevServerStartRequest Request { get; set; } = new();
}

/// <summary>
/// Development servers as first-class resources: stable ServerIds (never just PIDs), a persisted registry, listening-URL
/// discovery from the process output (confirmed by a loopback health check), status/stop/restart, and reconciliation
/// after a DocGen restart (a server is never reported running unless its process is owned and alive). Servers run as
/// long-running commands through <see cref="CommandRunner"/>, so they are owned, logged, cancellable and reconciled.
/// </summary>
public sealed partial class DevServerService(
    CommandRunner runner,
    RepositoryCatalog repositories,
    ExecutableResolver executables,
    IJsonStore store,
    IOptionsMonitor<ExecutionOptions> options,
    ILogger<DevServerService> logger) : IHostedService
{
    private static readonly HttpClient Health = new(new SocketsHttpHandler { UseProxy = false, AllowAutoRedirect = false, ConnectTimeout = TimeSpan.FromSeconds(3) })
    {
        Timeout = TimeSpan.FromSeconds(5),
    };

    private static string Dir(string userId) => $"servers/{Ids.Require(userId, "user id")}";

    private static string PathOf(string userId, string serverId) => $"{Dir(userId)}/{Ids.Require(serverId.Replace("-", ""), "server id")}.json";

    public async Task<DevServerRecord> StartAsync(string userId, DevServerStartRequest request, string? runId, string? conversationId, string? projectId,
        TimeSpan wait, CancellationToken ct)
    {
        var running = (await ListAsync(userId, ct)).Count(s => s.Status is DevServerStatus.Starting or DevServerStatus.Running);
        if (running >= options.CurrentValue.MaxServersPerUser)
        {
            throw new DocGenException("SERVER_LIMIT", $"You already have {running} development servers running (limit {options.CurrentValue.MaxServersPerUser}). Stop one first.", 409);
        }
        var repo = await repositories.ResolveAsync(userId, request.Repository, ct);
        if (!repo.AllowCommands)
        {
            throw new ForbiddenException($"Commands are not enabled for repository '{repo.Name}'.");
        }
        var record = new DevServerRecord { UserId = userId, RunId = runId, ConversationId = conversationId, ProjectId = projectId, Repository = repo.Name, Request = request };
        var (exe, args, cwd, configured) = BuildLaunch(repo, request, record.Notes);
        record.ConfiguredUrls = configured;
        record.WorkingDirectory = repo.Relative(cwd).Replace('\\', '/') is { Length: > 0 } d ? d : ".";
        record.Name = request.Name ?? (request.Project is { } p ? Path.GetFileNameWithoutExtension(p) : exe.Name);

        var discovered = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
        var command = await runner.StartProcessAsync(userId, new ProcessLaunch
        {
            Kind = CommandKinds.Server, ExecutableName = exe.Name, ExecutablePath = exe.Path, Arguments = args, WorkingDirectory = cwd,
            DisplayWorkingDirectory = record.WorkingDirectory, Repository = repo.Name, Description = $"Development server {record.Name}",
            Environment = request.Environment, LongRunning = true, RunId = runId, ConversationId = conversationId, ServerId = record.ServerId,
            Risk = "External", RiskFindings = ["starts the application"],
            OnOutput = line =>
            {
                if (ListeningUrl(line) is { } url)
                {
                    discovered.TrySetResult(url);
                }
            },
        }, ct);
        record.CommandId = command.Id;
        record.CommandLine = command.CommandLine;
        await SaveAsync(record);

        // Wait for the listening URL, the process to end, or the startup timeout.
        var timeout = TimeSpan.FromSeconds(Math.Min(wait.TotalSeconds, options.CurrentValue.ServerStartupTimeoutSeconds));
        var exited = runner.WaitAsync(userId, command.Id, timeout, ct, cancelOnAbort: false);
        var first = await Task.WhenAny(discovered.Task, exited, Task.Delay(timeout, ct));
        if (first == discovered.Task)
        {
            record.Url = await discovered.Task;
            record.UrlSource = "output";
        }
        return await RefreshAsync(record, probeConfigured: record.Url is null, ct);
    }

    public async Task<DevServerRecord> GetAsync(string userId, string serverId, CancellationToken ct)
    {
        var record = await store.ReadAsync<DevServerRecord>(PathOf(userId, serverId), ct) ?? throw new NotFoundException("Development server");
        return record.UserId == userId ? record : throw new NotFoundException("Development server");
    }

    /// <summary>Current status: the owned process must be alive; a running server gets a fresh loopback health check.</summary>
    public async Task<DevServerRecord> StatusAsync(string userId, string serverId, CancellationToken ct)
        => await RefreshAsync(await GetAsync(userId, serverId, ct), probeConfigured: false, ct);

    public async Task<IReadOnlyList<DevServerRecord>> ListAsync(string userId, CancellationToken ct)
    {
        var list = new List<DevServerRecord>();
        foreach (var path in store.EnumerateDocuments(Dir(userId)))
        {
            try
            {
                if (await store.ReadAsync<DevServerRecord>(path, ct) is { } r && r.UserId == userId)
                {
                    list.Add(r);
                }
            }
            catch (StorageException)
            {
            }
        }
        return list.OrderByDescending(r => r.StartedAt).ToList();
    }

    public async Task<DevServerRecord> StopAsync(string userId, string serverId, CancellationToken ct)
    {
        var record = await GetAsync(userId, serverId, ct);
        if (runner.IsActive(record.CommandId))
        {
            await runner.CancelAsync(userId, record.CommandId, "development server stopped");
            await runner.WaitAsync(userId, record.CommandId, TimeSpan.FromSeconds(20), ct, cancelOnAbort: false);
        }
        var command = await TryCommandAsync(record, ct);
        record.Status = DevServerStatus.Stopped;
        record.StoppedAt ??= DateTime.UtcNow;
        record.ExitCode = command?.ExitCode;
        record.LastHealth = null;
        await SaveAsync(record);
        return record;
    }

    public async Task<DevServerRecord> RestartAsync(string userId, string serverId, string? runId, TimeSpan wait, CancellationToken ct)
    {
        var old = await StopAsync(userId, serverId, ct);
        var restarted = await StartAsync(userId, old.Request, runId ?? old.RunId, old.ConversationId, old.ProjectId, wait, ct);
        restarted.Notes.Add($"restart of server {old.ServerId}");
        await SaveAsync(restarted);
        return restarted;
    }

    private async Task<DevServerRecord> RefreshAsync(DevServerRecord record, bool probeConfigured, CancellationToken ct)
    {
        var command = await TryCommandAsync(record, ct);
        record.ProcessId = command?.ProcessId ?? record.ProcessId;
        var alive = runner.IsActive(record.CommandId) && command is { IsFinal: false };
        if (!alive)
        {
            if (record.Status is DevServerStatus.Starting or DevServerStatus.Running)
            {
                record.Status = command is { Status: CommandStatus.Cancelled } ? DevServerStatus.Stopped
                    : command is { Status: CommandStatus.Succeeded } ? DevServerStatus.Exited : DevServerStatus.Failed;
                record.StoppedAt ??= command?.CompletedAt ?? DateTime.UtcNow;
                record.ExitCode = command?.ExitCode;
                if (command?.Tail.Count > 0)
                {
                    record.Notes.Add("last output: " + string.Join(" | ", command.Tail.TakeLast(3)));
                }
            }
            record.LastHealth = null;
            await SaveAsync(record);
            return record;
        }

        if (record.Url is null && probeConfigured)
        {
            foreach (var candidate in record.ConfiguredUrls)
            {
                if (await ProbeAsync(candidate, ct) is { } status)
                {
                    record.Url = candidate;
                    record.UrlSource = "health-check";
                    record.LastHealth = status;
                    break;
                }
            }
            if (record.Url is null)
            {
                record.Notes.Add("The listening URL could not be determined: the process did not print one and no configured URL answered a health check.");
            }
        }
        if (record.Url is not null)
        {
            record.LastHealth = await ProbeAsync(record.Url, ct) ?? "no response";
            record.LastHealthAt = DateTime.UtcNow;
        }
        record.Status = record.Url is not null && record.LastHealth != "no response" ? DevServerStatus.Running : record.Status == DevServerStatus.Running ? DevServerStatus.Running : DevServerStatus.Starting;
        await SaveAsync(record);
        return record;
    }

    private async Task<CommandRecord?> TryCommandAsync(DevServerRecord record, CancellationToken ct)
    {
        try
        {
            return await runner.GetAsync(record.UserId, record.CommandId, ct);
        }
        catch (NotFoundException)
        {
            return null;
        }
    }

    /// <summary>GET on a loopback URL only; returns "HTTP 200" etc., or null when nothing answers.</summary>
    public static async Task<string?> ProbeAsync(string url, CancellationToken ct)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) || !IsLoopback(uri))
        {
            return null;
        }
        try
        {
            using var response = await Health.GetAsync(uri, HttpCompletionOption.ResponseHeadersRead, ct);
            return $"HTTP {(int)response.StatusCode}";
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or OperationCanceledException)
        {
            return null;
        }
    }

    public static bool IsLoopback(Uri uri)
        => uri.Scheme is "http" or "https" && (uri.IsLoopback || uri.Host.Equals("localhost", StringComparison.OrdinalIgnoreCase) || uri.Host.EndsWith(".localhost", StringComparison.OrdinalIgnoreCase));

    /// <summary>Recognises "Now listening on: http://…" (ASP.NET Core) and common dev-server banners; normalises wildcard hosts.</summary>
    public static string? ListeningUrl(string line)
    {
        var m = AspNetListening().Match(line);
        if (!m.Success)
        {
            if (!BannerHint().IsMatch(line))
            {
                return null;
            }
            m = AnyLocalUrl().Match(line);
            if (!m.Success)
            {
                return null;
            }
        }
        var url = m.Groups["url"].Value.TrimEnd('/', '.', ',', ')');
        url = WildcardHost().Replace(url, "${scheme}://localhost");
        return Uri.TryCreate(url, UriKind.Absolute, out var uri) && uri.Port > 0 ? uri.GetLeftPart(UriPartial.Authority) + "/" : null;
    }

    private (ResolvedExecutable Exe, List<string> Args, string Cwd, List<string> Configured) BuildLaunch(RepositoryHandle repo, DevServerStartRequest request, List<string>? notes = null)
    {
        var configured = new List<string>();
        if (request.Project is { Length: > 0 } project)
        {
            var full = repo.Resolve(project);
            if (!File.Exists(full) || Path.GetExtension(full) is not (".csproj" or ".fsproj"))
            {
                throw new ValidationException("project must be an existing .csproj/.fsproj file in the repository.");
            }
            var exe = executables.Resolve("dotnet");
            var args = new List<string> { "run", "--project", full };
            if (request.NoBuild)
            {
                args.Add("--no-build");
            }
            var projectDirectory = Path.GetDirectoryName(full)!;
            if (string.Equals(request.LaunchProfile, "none", StringComparison.OrdinalIgnoreCase))
            {
                args.Add("--no-launch-profile");
            }
            else if (request.LaunchProfile is { Length: > 0 } profile)
            {
                if (!Regex.IsMatch(profile, @"^[\w .\-]{1,64}$"))
                {
                    throw new ValidationException("Invalid launch profile name.");
                }
                args.AddRange(["--launch-profile", profile]);
            }
            else if (request.Environment is { Count: > 0 } environment && DefaultProfileEnvironment(projectDirectory) is { } profileEnvironment
                     && environment.Keys.Where(k => profileEnvironment.Variables.ContainsKey(k)).ToList() is { Count: > 0 } clash)
            {
                // dotnet run applies the launch profile's variables over the process environment, so the caller's
                // ASPNETCORE_ENVIRONMENT=Production silently became Development. Honour what was asked for instead.
                args.Add("--no-launch-profile");
                notes?.Add($"Started with --no-launch-profile: the default launch profile '{profileEnvironment.Name}' sets {string.Join(", ", clash)}, " +
                           "which would have overridden the environment given. Pass launchProfile to use a profile anyway.");
            }
            if (!args.Contains("--no-launch-profile"))
            {
                configured.AddRange(LaunchSettingsUrls(projectDirectory, request.LaunchProfile));
            }
            if (request.ApplicationArguments.Count > 0)
            {
                args.Add("--");
                args.AddRange(request.ApplicationArguments);
                var urls = request.ApplicationArguments.SkipWhile(a => a != "--urls").Skip(1).FirstOrDefault()
                           ?? request.ApplicationArguments.FirstOrDefault(a => a.StartsWith("--urls=", StringComparison.Ordinal))?[7..];
                if (urls is not null)
                {
                    configured.InsertRange(0, urls.Split(';', StringSplitOptions.RemoveEmptyEntries));
                }
            }
            var cwd = request.WorkingDirectory is { Length: > 0 } w ? repo.Resolve(w) : Path.GetDirectoryName(full)!;
            return (exe, args, cwd, configured.Distinct().ToList());
        }
        if (request.Executable is { Length: > 0 } name)
        {
            var exe = executables.Resolve(Path.GetFileNameWithoutExtension(name));
            if (exe.Kind == "powershell")
            {
                throw new ValidationException("PowerShell cannot be a development server command.");
            }
            var cwd = request.WorkingDirectory is { Length: > 0 } w ? repo.Resolve(w) : repo.Root;
            return (exe, request.Arguments.ToList(), cwd, configured);
        }
        throw new ValidationException("Give 'project' (a .csproj for dotnet run) or 'executable' with 'arguments'.");
    }

    /// <summary>The environment variables of the launch profile dotnet run uses by default (the first "Project" profile), or null.</summary>
    public static (string Name, Dictionary<string, string> Variables)? DefaultProfileEnvironment(string projectDirectory)
    {
        var path = Path.Combine(projectDirectory, "Properties", "launchSettings.json");
        if (!File.Exists(path))
        {
            return null;
        }
        try
        {
            using var doc = JsonDocument.Parse(File.ReadAllText(path), new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
            if (!doc.RootElement.TryGetProperty("profiles", out var profiles))
            {
                return null;
            }
            foreach (var p in profiles.EnumerateObject())
            {
                if (p.Value.TryGetProperty("commandName", out var cn) && cn.GetString() != "Project")
                {
                    continue;
                }
                var variables = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                if (p.Value.TryGetProperty("environmentVariables", out var ev) && ev.ValueKind == JsonValueKind.Object)
                {
                    foreach (var v in ev.EnumerateObject())
                    {
                        variables[v.Name] = v.Value.ValueKind == JsonValueKind.String ? v.Value.GetString() ?? "" : v.Value.GetRawText();
                    }
                }
                return (p.Name, variables);
            }
            return null;
        }
        catch (JsonException)
        {
            return null;
        }
    }

    /// <summary>applicationUrl values from Properties/launchSettings.json (hints; confirmed by output or health check before use).</summary>
    public static IEnumerable<string> LaunchSettingsUrls(string projectDirectory, string? profile)
    {
        var path = Path.Combine(projectDirectory, "Properties", "launchSettings.json");
        if (!File.Exists(path))
        {
            return [];
        }
        try
        {
            using var doc = JsonDocument.Parse(File.ReadAllText(path), new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
            if (!doc.RootElement.TryGetProperty("profiles", out var profiles))
            {
                return [];
            }
            var urls = new List<string>();
            foreach (var p in profiles.EnumerateObject())
            {
                if (profile is not null && p.Name != profile)
                {
                    continue;
                }
                if (p.Value.TryGetProperty("commandName", out var cn) && cn.GetString() != "Project")
                {
                    continue;
                }
                if (p.Value.TryGetProperty("applicationUrl", out var u) && u.GetString() is { } value)
                {
                    urls.AddRange(value.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries));
                }
                if (profile is null)
                {
                    break; // dotnet run uses the first Project profile.
                }
            }
            return urls;
        }
        catch (Exception ex) when (ex is JsonException or IOException)
        {
            return [];
        }
    }

    private async Task SaveAsync(DevServerRecord record)
    {
        if (record.Notes.Count > 20)
        {
            record.Notes.RemoveRange(0, record.Notes.Count - 20);
        }
        await store.WriteAsync(PathOf(record.UserId, record.ServerId), record, CancellationToken.None);
    }

    /// <summary>
    /// After a restart no server process is owned any more (command reconciliation killed the orphans): records that
    /// still say starting/running are marked stopped. Servers are never restarted automatically.
    /// </summary>
    public async Task<int> ReconcileAsync(CancellationToken ct = default)
    {
        var count = 0;
        foreach (var userDir in store.EnumerateDirectories("servers"))
        {
            foreach (var path in store.EnumerateDocuments($"servers/{userDir}"))
            {
                DevServerRecord? record;
                try
                {
                    record = await store.ReadAsync<DevServerRecord>(path, ct);
                }
                catch (StorageException)
                {
                    continue;
                }
                if (record is null || record.Status is not (DevServerStatus.Starting or DevServerStatus.Running) || runner.IsActive(record.CommandId))
                {
                    continue;
                }
                record.Status = DevServerStatus.Stopped;
                record.StoppedAt ??= DateTime.UtcNow;
                record.LastHealth = null;
                record.Notes.Add("DocGen restarted while this server was running; its process was stopped. It is not restarted automatically.");
                await store.WriteAsync(path, record, ct);
                count++;
            }
        }
        if (count > 0)
        {
            logger.LogWarning("Marked {Count} development servers left running by a previous process as stopped", count);
        }
        return count;
    }

    public async Task StartAsync(CancellationToken cancellationToken) => await ReconcileAsync(cancellationToken);

    public Task StopAsync(CancellationToken cancellationToken) => Task.CompletedTask;

    [GeneratedRegex(@"Now listening on:\s*(?<url>https?://\S+)", RegexOptions.IgnoreCase)]
    private static partial Regex AspNetListening();

    [GeneratedRegex(@"listening|running at|server running|local:|started server|available on|ready on", RegexOptions.IgnoreCase)]
    private static partial Regex BannerHint();

    [GeneratedRegex(@"(?<url>https?://(?:localhost|127\.0\.0\.1|\[::1\]|0\.0\.0\.0|\[::\]|\+|\*)(?::\d{1,5})?[^\s'""]*)", RegexOptions.IgnoreCase)]
    private static partial Regex AnyLocalUrl();

    [GeneratedRegex(@"^(?<scheme>https?)://(?:0\.0\.0\.0|\[::\]|\+|\*)", RegexOptions.IgnoreCase)]
    private static partial Regex WildcardHost();
}
