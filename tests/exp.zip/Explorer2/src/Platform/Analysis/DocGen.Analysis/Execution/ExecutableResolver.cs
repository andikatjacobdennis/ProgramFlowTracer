using System.Diagnostics;
using DocGen.Core.Exceptions;
using DocGen.Core.Options;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Execution;

public sealed record ResolvedExecutable(string Name, string Path, string Kind);

/// <summary>The PowerShell DocGen uses: PowerShell 7 (pwsh) when installed, otherwise Windows PowerShell when allowed.</summary>
public sealed record PowerShellInfo(string Name, string Path, string Edition, string Version)
{
    /// <summary>"PowerShell 7.4.1" or "Windows PowerShell 5.1.26100".</summary>
    public string DisplayName => Edition == "Core" ? $"PowerShell {Version}" : $"Windows PowerShell {Version}";

    /// <summary>PowerShell 7 supports && / || pipeline chains; Windows PowerShell does not.</summary>
    public bool SupportsPipelineChains => Edition == "Core";
}

public sealed record ExecutableStatus(string Name, string Kind, bool Enabled, string? Path, string? Problem);

/// <summary>
/// Resolves logical executable names against the configured allowlist (DocGen:Execution:Executables). An executable
/// that merely exists on PATH is never permitted by that fact alone; it must be listed and enabled.
/// </summary>
public sealed class ExecutableResolver(IOptionsMonitor<ExecutionOptions> options, ILogger<ExecutableResolver>? logger = null)
{
    private readonly ILogger _logger = (ILogger?)logger ?? NullLogger.Instance;
    private readonly Lock _sync = new();
    private (string Key, PowerShellInfo? Info)? _powerShell;

    public ExecutionOptions Options => options.CurrentValue;

    /// <summary>Resolves an allow-listed, enabled executable to a full path, or throws.</summary>
    public ResolvedExecutable Resolve(string name)
    {
        var entry = Options.Executables.FirstOrDefault(e => string.Equals(e.Name, name, StringComparison.OrdinalIgnoreCase));
        if (entry is null || !entry.Enabled)
        {
            throw new ForbiddenException($"The executable '{Clip(name)}' is not allowed by DocGen:Execution:Executables.");
        }
        var path = Locate(entry) ?? throw new DocGenException("EXECUTABLE_NOT_FOUND", $"The executable '{entry.Name}' is allowed but was not found on this machine.", 404);
        return new ResolvedExecutable(entry.Name, path, entry.Kind);
    }

    public bool IsAllowed(string name) => Options.Executables.Any(e => string.Equals(e.Name, name, StringComparison.OrdinalIgnoreCase) && e.Enabled);

    public IReadOnlyList<ExecutableStatus> Describe()
        => Options.Executables.Select(e =>
        {
            var path = e.Enabled ? Locate(e) : null;
            return new ExecutableStatus(e.Name, e.Kind, e.Enabled, path, !e.Enabled ? "disabled" : path is null ? "not found" : null);
        }).ToList();

    /// <summary>Detects the PowerShell to use (cached per configuration). Null when none is allowed and installed.</summary>
    public PowerShellInfo? DetectPowerShell()
    {
        var o = Options;
        var key = string.Join('|', o.Executables.Where(e => e.Kind == "powershell").Select(e => $"{e.Name}:{e.Enabled}:{e.Path}")) + "|" + o.AllowWindowsPowerShellFallback;
        lock (_sync)
        {
            if (_powerShell is { } cached && cached.Key == key)
            {
                return cached.Info;
            }
        }
        PowerShellInfo? info = null;
        foreach (var candidate in new[] { "pwsh", "powershell" })
        {
            if (candidate == "powershell" && !o.AllowWindowsPowerShellFallback)
            {
                continue;
            }
            var entry = o.Executables.FirstOrDefault(e => string.Equals(e.Name, candidate, StringComparison.OrdinalIgnoreCase) && e.Enabled);
            if (entry is null || Locate(entry) is not { } path)
            {
                continue;
            }
            var version = ProbeVersion(path);
            if (version is null)
            {
                continue;
            }
            info = new PowerShellInfo(entry.Name, path, version.StartsWith("5.", StringComparison.Ordinal) ? "Desktop" : "Core", version);
            break;
        }
        lock (_sync)
        {
            _powerShell = (key, info);
        }
        return info;
    }

    private string? ProbeVersion(string path)
    {
        try
        {
            var psi = new ProcessStartInfo(path)
            {
                RedirectStandardOutput = true, RedirectStandardError = true, RedirectStandardInput = true, UseShellExecute = false, CreateNoWindow = true,
            };
            foreach (var a in new[] { "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", "$PSVersionTable.PSVersion.ToString()" })
            {
                psi.ArgumentList.Add(a);
            }
            using var process = Process.Start(psi);
            if (process is null)
            {
                return null;
            }
            process.StandardInput.Close();
            var output = process.StandardOutput.ReadToEndAsync();
            if (!process.WaitForExit(20_000))
            {
                process.Kill(entireProcessTree: true);
                return null;
            }
            var text = output.Result.Trim();
            return text.Length is > 0 and < 40 && char.IsDigit(text[0]) ? text : null;
        }
        catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or InvalidOperationException or IOException)
        {
            _logger.LogDebug(ex, "PowerShell probe failed for {Path}", path);
            return null;
        }
    }

    private static string? Locate(ExecutableOptions entry)
    {
        if (!string.IsNullOrWhiteSpace(entry.Path))
        {
            return File.Exists(entry.Path) ? Path.GetFullPath(entry.Path) : null;
        }
        if (entry.Kind == "dotnet" && Environment.GetEnvironmentVariable("DOTNET_HOST_PATH") is { Length: > 0 } host && File.Exists(host)
            && Path.GetFileNameWithoutExtension(host).Equals("dotnet", StringComparison.OrdinalIgnoreCase))
        {
            return host;
        }
        if (FindOnPath(entry.Name) is { } found)
        {
            return found;
        }
        foreach (var known in KnownLocations(entry.Name))
        {
            if (File.Exists(known))
            {
                return known;
            }
        }
        return null;
    }

    private static IEnumerable<string> KnownLocations(string name)
    {
        if (!OperatingSystem.IsWindows())
        {
            yield return "/usr/bin/" + name;
            yield return "/usr/local/bin/" + name;
            yield break;
        }
        var programFiles = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
        switch (name.ToLowerInvariant())
        {
            case "pwsh":
                yield return Path.Combine(programFiles, "PowerShell", "7", "pwsh.exe");
                yield return Path.Combine(programFiles, "PowerShell", "7-preview", "pwsh.exe");
                break;
            case "powershell":
                yield return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell", "v1.0", "powershell.exe");
                break;
            case "git":
                yield return Path.Combine(programFiles, "Git", "cmd", "git.exe");
                break;
            case "dotnet":
                yield return Path.Combine(programFiles, "dotnet", "dotnet.exe");
                break;
        }
    }

    public static string? FindOnPath(string name)
    {
        var path = Environment.GetEnvironmentVariable("PATH") ?? "";
        var extensions = OperatingSystem.IsWindows()
            ? (Environment.GetEnvironmentVariable("PATHEXT") ?? ".EXE;.CMD;.BAT").Split(';', StringSplitOptions.RemoveEmptyEntries).Prepend("").ToArray()
            : [""];
        foreach (var dir in path.Split(Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries))
        {
            foreach (var ext in extensions)
            {
                try
                {
                    var candidate = Path.Combine(dir.Trim('"'), name + ext);
                    // Only real executables (.exe on Windows): scripts on PATH (.cmd/.bat shims) are not resolved.
                    if (File.Exists(candidate) && (!OperatingSystem.IsWindows() || candidate.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)))
                    {
                        return Path.GetFullPath(candidate);
                    }
                }
                catch (ArgumentException)
                {
                }
            }
        }
        return null;
    }

    private static string Clip(string value) => value.Length > 60 ? value[..60] + "…" : value;
}
