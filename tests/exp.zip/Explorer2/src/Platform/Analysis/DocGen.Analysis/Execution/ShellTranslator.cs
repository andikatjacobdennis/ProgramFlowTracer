using System.Text;
using System.Text.RegularExpressions;

namespace DocGen.Analysis.Execution;

public sealed record ShellTranslation(bool Success, string PowerShell, IReadOnlyList<string> Notes, string? Reason = null);

/// <summary>
/// Translates simple POSIX-shell snippets (the kind people paste: <c>cd dir &amp;&amp; dotnet build 2&gt;&amp;1 | grep -E "a|b" | head -5</c>)
/// into equivalent PowerShell, preserving the intent. It is intentionally small: pipelines of well-known commands
/// (cd, ls, cat, grep, head, tail, wc -l, sort, uniq, find -name, echo, pwd, dotnet, git) joined by &amp;&amp;, || and ;.
/// Anything else (loops, functions, command substitution, sed/awk, redirections to files…) is refused with a reason
/// rather than guessed; the caller can run it with an allow-listed POSIX shell instead.
/// </summary>
public static partial class ShellTranslator
{
    /// <summary>Heuristic: does this look like POSIX shell rather than PowerShell?</summary>
    public static bool LooksLikePosixShell(string script)
    {
        var s = script.Trim();
        if (s.Length == 0)
        {
            return false;
        }
        var posixSignals = 0;
        if (PosixDrivePath().IsMatch(s)) posixSignals += 2;
        if (Regex.IsMatch(s, @"\|\s*(grep|head|tail|wc|sed|awk|sort|uniq|xargs|cut|tr)\b")) posixSignals += 2;
        if (Regex.IsMatch(s, @"(^|[;&|]\s*)(export|source)\s")) posixSignals += 2;
        if (s.Contains("$(", StringComparison.Ordinal) && !Regex.IsMatch(s, @"\$\(\s*Get-|\$\(\s*\$")) posixSignals += 1;
        if (Regex.IsMatch(s, @"\b(ls|cat|find)\s+-[a-zA-Z]")) posixSignals += 1;
        if (Regex.IsMatch(s, @"\b[A-Z]\w*-[A-Z]\w+\b")) posixSignals -= 3; // Verb-Noun cmdlets
        if (Regex.IsMatch(s, @"\$_\b|\$env:|\$PSVersionTable")) posixSignals -= 3;
        return posixSignals >= 2;
    }

    public static ShellTranslation Translate(string script, bool supportsPipelineChains)
    {
        var notes = new List<string>();
        var text = script.Replace("\r\n", "\n").Replace("\\\n", " ").Trim();
        if (text.Contains('\n'))
        {
            var lines = text.Split('\n', StringSplitOptions.RemoveEmptyEntries).Select(l => l.Trim()).Where(l => l.Length > 0 && !l.StartsWith('#')).ToList();
            text = string.Join(" ; ", lines);
        }
        if (Unsupported().Match(text) is { Success: true } unsupported)
        {
            return Fail($"'{unsupported.Value.Trim()}' has no safe automatic translation");
        }

        var output = new StringBuilder();
        var segments = SplitTopLevel(text);
        if (segments is null)
        {
            return Fail("unbalanced quotes");
        }
        var chainsUsed = false;
        foreach (var (op, segment) in segments)
        {
            var translated = TranslatePipeline(segment, notes, out var error);
            if (translated is null)
            {
                return Fail(error ?? "unsupported command");
            }
            if (output.Length == 0)
            {
                output.Append(translated);
                continue;
            }
            switch (op)
            {
                case "&&":
                    chainsUsed = true;
                    output.Append(supportsPipelineChains ? " && " : "\nif ($?) { ").Append(translated);
                    if (!supportsPipelineChains)
                    {
                        output.Append(" }");
                    }
                    break;
                case "||":
                    chainsUsed = true;
                    output.Append(supportsPipelineChains ? " || " : "\nif (-not $?) { ").Append(translated);
                    if (!supportsPipelineChains)
                    {
                        output.Append(" }");
                    }
                    break;
                default:
                    output.Append('\n').Append(translated);
                    break;
            }
        }
        if (chainsUsed && !supportsPipelineChains)
        {
            notes.Add("&& / || became if ($?) checks (Windows PowerShell has no pipeline chain operators)");
        }
        return new ShellTranslation(true, output.ToString(), notes);

        ShellTranslation Fail(string reason) => new(false, "", notes, reason);
    }

    private static string? TranslatePipeline(string pipeline, List<string> notes, out string? error)
    {
        error = null;
        var stages = SplitPipes(pipeline);
        var result = new List<string>();
        foreach (var raw in stages)
        {
            var stage = raw.Trim();
            var mergeStderr = false;
            if (stage.EndsWith("2>&1", StringComparison.Ordinal))
            {
                stage = stage[..^4].TrimEnd();
                mergeStderr = true;
            }
            var words = Words(stage);
            if (words.Count == 0)
            {
                error = "empty pipeline stage";
                return null;
            }
            var cmd = words[0];
            var args = words.Skip(1).ToList();
            string? ps = cmd switch
            {
                "cd" => $"Set-Location -LiteralPath {Quote(ConvertPath(args.FirstOrDefault() ?? "~"))}",
                "pwd" => "Get-Location",
                "ls" => "Get-ChildItem" + (args.Any(a => a.StartsWith('-') && a.Contains('a')) ? " -Force" : "") + PathArgs(args),
                "cat" => $"Get-Content {string.Join(", ", args.Where(a => !a.StartsWith('-')).Select(a => Quote(ConvertPath(a))))}",
                "echo" => $"Write-Output {Quote(string.Join(' ', args))}",
                "head" => $"Select-Object -First {Count(args, 10)}",
                "tail" => $"Select-Object -Last {Count(args, 10)}",
                "wc" when args.Contains("-l") => "Measure-Object -Line | Select-Object -ExpandProperty Lines",
                "sort" => "Sort-Object" + (args.Contains("-r") ? " -Descending" : "") + (args.Contains("-u") ? " -Unique" : ""),
                "uniq" => args.Contains("-c") ? "Group-Object | ForEach-Object { '{0,7} {1}' -f $_.Count, $_.Name }" : "Get-Unique",
                "grep" => Grep(args, result.Count == 0, notes),
                "find" => Find(args),
                "dotnet" or "git" => cmd + " " + string.Join(' ', args.Select(QuoteIfNeeded)),
                "true" => "$null",
                _ => null,
            };
            if (ps is null)
            {
                error = $"'{cmd}' is not in the translatable command set";
                return null;
            }
            if (mergeStderr)
            {
                ps += " 2>&1";
                if (cmd is "dotnet" or "git")
                {
                    // Native stderr lines become ErrorRecords in Windows PowerShell; convert them back to text.
                    ps += " | ForEach-Object { \"$_\" }";
                }
            }
            result.Add(ps);
        }
        return string.Join(" | ", result);
    }

    private static string Grep(List<string> args, bool firstStage, List<string> notes)
    {
        var flags = args.Where(a => a.StartsWith('-')).SelectMany(a => a.TrimStart('-')).ToHashSet();
        var positional = args.Where(a => !a.StartsWith('-')).ToList();
        var pattern = positional.FirstOrDefault() ?? "";
        var paths = positional.Skip(1).ToList();
        var fixedString = flags.Contains('F');
        var sb = new StringBuilder();
        if (firstStage && paths.Count > 0)
        {
            var recurse = flags.Contains('r') || flags.Contains('R');
            sb.Append(recurse ? $"Get-ChildItem -Recurse -File {Quote(ConvertPath(paths[0]))} | " : "");
            sb.Append("Select-String");
            if (!recurse)
            {
                sb.Append(" -Path ").Append(string.Join(", ", paths.Select(p => Quote(ConvertPath(p)))));
            }
        }
        else
        {
            sb.Append("Select-String");
        }
        sb.Append(" -Pattern ").Append(Quote(pattern));
        if (!flags.Contains('i'))
        {
            sb.Append(" -CaseSensitive");
        }
        if (fixedString)
        {
            sb.Append(" -SimpleMatch");
        }
        if (flags.Contains('v'))
        {
            sb.Append(" -NotMatch");
        }
        if (flags.Contains('E'))
        {
            notes.Add("grep -E pattern used as a .NET regular expression");
        }
        if (!firstStage || paths.Count == 0)
        {
            // Plain text lines, like grep, instead of MatchInfo objects.
            sb.Append(" | ForEach-Object { $_.Line }");
        }
        if (flags.Contains('c'))
        {
            sb.Append(" | Measure-Object | Select-Object -ExpandProperty Count");
        }
        return sb.ToString();
    }

    private static string? Find(List<string> args)
    {
        var root = args.FirstOrDefault(a => !a.StartsWith('-')) ?? ".";
        var sb = new StringBuilder($"Get-ChildItem -Recurse {Quote(ConvertPath(root))}");
        for (var i = 0; i < args.Count - 1; i++)
        {
            switch (args[i])
            {
                case "-name":
                case "-iname":
                    sb.Append(" -Filter ").Append(Quote(args[i + 1]));
                    break;
                case "-type" when args[i + 1] == "f":
                    sb.Append(" -File");
                    break;
                case "-type" when args[i + 1] == "d":
                    sb.Append(" -Directory");
                    break;
            }
        }
        return sb.Append(" | ForEach-Object { $_.FullName }").ToString();
    }

    private static string PathArgs(List<string> args)
    {
        var paths = args.Where(a => !a.StartsWith('-')).ToList();
        return paths.Count == 0 ? "" : " " + string.Join(", ", paths.Select(p => Quote(ConvertPath(p))));
    }

    private static int Count(List<string> args, int fallback)
    {
        for (var i = 0; i < args.Count; i++)
        {
            if (args[i] == "-n" && i + 1 < args.Count && int.TryParse(args[i + 1], out var n))
            {
                return n;
            }
            if (args[i].StartsWith('-') && int.TryParse(args[i][1..], out var m))
            {
                return m;
            }
        }
        return fallback;
    }

    /// <summary>/c/Users/x → C:\Users\x (Git Bash / MSYS drive paths).</summary>
    public static string ConvertPath(string path)
    {
        var m = PosixDrivePath().Match(path);
        if (m.Success && m.Index == 0)
        {
            var rest = path[m.Length..].Replace('/', '\\');
            return char.ToUpperInvariant(m.Groups[1].Value[0]) + ":" + (rest.Length == 0 ? "\\" : rest);
        }
        return path;
    }

    private static string Quote(string value) => "'" + value.Replace("'", "''") + "'";

    private static string QuoteIfNeeded(string value) => value.Length == 0 || value.Any(c => char.IsWhiteSpace(c) || c is '|' or ';' or '&' or '(' or ')' or '$' or '`' or '"' or '\'' or '{' or '}' or ',') ? Quote(value) : value;

    /// <summary>Splits on top-level &&, || and ; (outside quotes). Null on unbalanced quotes.</summary>
    private static List<(string Op, string Segment)>? SplitTopLevel(string text)
    {
        var list = new List<(string, string)>();
        var sb = new StringBuilder();
        var op = "";
        char quote = '\0';
        for (var i = 0; i < text.Length; i++)
        {
            var c = text[i];
            if (quote != '\0')
            {
                sb.Append(c);
                if (c == quote)
                {
                    quote = '\0';
                }
                continue;
            }
            if (c is '"' or '\'')
            {
                quote = c;
                sb.Append(c);
                continue;
            }
            string? found = c == '&' && i + 1 < text.Length && text[i + 1] == '&' ? "&&" : c == '|' && i + 1 < text.Length && text[i + 1] == '|' ? "||" : c == ';' ? ";" : null;
            if (found is not null)
            {
                list.Add((op, sb.ToString().Trim()));
                sb.Clear();
                op = found;
                i += found.Length - 1;
                continue;
            }
            sb.Append(c);
        }
        if (quote != '\0')
        {
            return null;
        }
        list.Add((op, sb.ToString().Trim()));
        return list.Where(s => s.Item2.Length > 0).ToList();
    }

    private static List<string> SplitPipes(string text)
    {
        var list = new List<string>();
        var sb = new StringBuilder();
        char quote = '\0';
        foreach (var c in text)
        {
            if (quote != '\0')
            {
                sb.Append(c);
                if (c == quote)
                {
                    quote = '\0';
                }
                continue;
            }
            if (c is '"' or '\'')
            {
                quote = c;
            }
            if (c == '|')
            {
                list.Add(sb.ToString());
                sb.Clear();
                continue;
            }
            sb.Append(c);
        }
        list.Add(sb.ToString());
        return list;
    }

    private static List<string> Words(string text)
    {
        var words = new List<string>();
        var sb = new StringBuilder();
        char quote = '\0';
        var inWord = false;
        foreach (var c in text)
        {
            if (quote != '\0')
            {
                if (c == quote)
                {
                    quote = '\0';
                }
                else
                {
                    sb.Append(c);
                }
                continue;
            }
            if (c is '"' or '\'')
            {
                quote = c;
                inWord = true;
                continue;
            }
            if (char.IsWhiteSpace(c))
            {
                if (inWord)
                {
                    words.Add(sb.ToString());
                    sb.Clear();
                    inWord = false;
                }
                continue;
            }
            sb.Append(c);
            inWord = true;
        }
        if (inWord)
        {
            words.Add(sb.ToString());
        }
        return words;
    }

    [GeneratedRegex(@"^/([a-zA-Z])(?=/|$)")]
    private static partial Regex PosixDrivePath();

    [GeneratedRegex(@"\b(?:for|while|until|case|function|sed|awk|xargs|eval|exec|sudo|rm|mv|cp|chmod|chown|curl|wget|export|source)\b|`|\$\(|(?<![0-9&])>{1,2}(?!&)|<<|\bdo\b|\bdone\b|\bfi\b")]
    private static partial Regex Unsupported();
}
