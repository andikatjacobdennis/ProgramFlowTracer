using DocGen.Analysis.Commands;

namespace DocGen.Analysis.Execution;

/// <summary>
/// The single process-execution abstraction (implemented by <see cref="CommandRunner"/>). Every process DocGen
/// starts — builds, tests, PowerShell, git, development servers, browsers — goes through it, so each one is
/// persisted, observable, owned by a user, cancellable (process-tree kill) and reconciled after a restart.
/// </summary>
public interface IProcessRunner
{
    Task<CommandRecord> StartProcessAsync(string userId, ProcessLaunch launch, CancellationToken ct);

    Task<CommandRecord> WaitAsync(string userId, string id, TimeSpan maxWait, CancellationToken ct, bool cancelOnAbort = true);

    Task<CommandRecord> GetAsync(string userId, string id, CancellationToken ct);

    Task<bool> CancelAsync(string userId, string id, string reason = "cancelled by user");

    (List<(long Line, string Text)> Lines, long TotalStored) ReadOutput(string userId, string id, long fromLine, int count, string? search = null);

    IReadOnlyList<CommandRecord> ListActive(string userId);

    bool IsActive(string id);
}
