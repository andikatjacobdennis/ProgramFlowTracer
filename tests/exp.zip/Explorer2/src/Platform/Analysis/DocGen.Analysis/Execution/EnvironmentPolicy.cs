using System.Text.RegularExpressions;
using DocGen.Core.Exceptions;
using DocGen.Core.Options;
using DocGen.Security;

namespace DocGen.Analysis.Execution;

/// <summary>
/// The environment a child process receives. Nothing is inherited implicitly: only allow-listed variables pass from
/// the DocGen process, secret-looking variables are always removed, explicitly authorized secrets are added for the
/// repositories they are authorized for (and their values are redacted from all output), and model-supplied overrides
/// are validated and may never carry secrets.
/// </summary>
public static partial class EnvironmentPolicy
{
    private static readonly string[] SecretMarkers = ["KEY", "SECRET", "TOKEN", "PASSWORD", "PASSWD", "CONNECTIONSTRING", "CREDENTIAL", "PRIVATE", "AUTH"];

    public static bool LooksSecret(string name)
    {
        var upper = name.ToUpperInvariant();
        // AUTHOR / AUTHORITY are not secrets.
        // PASS and PAT only as whole name parts (DB_PASS, GH_PAT) — never inside PATH or PASSTHROUGH.
        var parts = upper.Split(['_', '-', '.'], StringSplitOptions.RemoveEmptyEntries);
        return SecretMarkers.Any(m => upper.Contains(m, StringComparison.Ordinal) && !(m == "AUTH" && upper.Contains("AUTHOR", StringComparison.Ordinal)))
               || parts.Any(p => p is "PASS" or "PAT")
               || upper.StartsWith("DOCGEN_", StringComparison.Ordinal) || upper.StartsWith("DOCGEN__", StringComparison.Ordinal);
    }

    public static bool IsInherited(string name, IEnumerable<string> patterns)
        => patterns.Any(p => p.EndsWith('*')
            ? name.StartsWith(p[..^1], StringComparison.OrdinalIgnoreCase)
            : string.Equals(name, p, StringComparison.OrdinalIgnoreCase));

    private static readonly string[] LoaderPrefixes = ["GIT_", "DOTNET_", "COMPLUS_", "CORECLR_", "MSBUILD", "NUGET_", "LD_", "DYLD_"];

    private static readonly HashSet<string> LoaderNames = new(StringComparer.OrdinalIgnoreCase)
    {
        "PATH", "PATHEXT", "PSModulePath", "ComSpec", "SystemRoot", "windir", "NODE_OPTIONS", "NODE_PATH", "PYTHONPATH", "PYTHONSTARTUP",
        "PYTHONHOME", "PERL5OPT", "PERL5LIB", "RUBYOPT", "BASH_ENV", "ENV", "PROMPT_COMMAND", "EDITOR", "VISUAL", "PAGER", "HOME", "USERPROFILE",
        "APPDATA", "LOCALAPPDATA", "XDG_CONFIG_HOME",
    };

    /// <summary>Variables that select programs, libraries or configuration files; tool arguments may not set them.</summary>
    public static bool IsLoaderVariable(string name)
        => LoaderNames.Contains(name) || LoaderPrefixes.Any(p => name.StartsWith(p, StringComparison.OrdinalIgnoreCase));

    /// <summary>Rejects tool-argument overrides of variables that select programs, libraries or configuration.</summary>
    public static void RejectLoaderVariables(IReadOnlyDictionary<string, string>? overrides)
    {
        foreach (var name in (overrides ?? new Dictionary<string, string>()).Keys)
        {
            if (IsLoaderVariable(name))
            {
                throw new ValidationException($"'{Clip(name)}' changes which programs or configuration a tool loads and cannot be set from tool arguments.");
            }
        }
    }

    /// <summary>Validates model-supplied overrides (names and values).</summary>
    public static Dictionary<string, string> ValidateOverrides(IReadOnlyDictionary<string, string>? overrides)
    {
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var (name, value) in overrides ?? new Dictionary<string, string>())
        {
            if (!NamePattern().IsMatch(name) || name.Length > 128)
            {
                throw new ValidationException($"Invalid environment variable name '{Clip(name)}'.");
            }
            if (LooksSecret(name))
            {
                throw new ValidationException($"'{Clip(name)}' looks like a secret. Secrets are never passed from tool arguments; an administrator can authorize one in DocGen:Execution:AuthorizedSecrets.");
            }
            if (value.Length > 8192 || value.Contains('\0'))
            {
                throw new ValidationException($"The value of '{name}' is too long or contains NUL.");
            }
            result[name] = value;
        }
        if (result.Count > 50)
        {
            throw new ValidationException("At most 50 environment overrides are allowed.");
        }
        return result;
    }

    /// <summary>
    /// Rewrites <paramref name="environment"/> (initialised from the DocGen process) in place and returns the secret
    /// values that must be redacted from output.
    /// </summary>
    public static List<string> Apply(IDictionary<string, string?> environment, ExecutionOptions options, IReadOnlyDictionary<string, string>? overrides, string? repository)
    {
        var host = environment.ToDictionary(e => e.Key, e => e.Value, StringComparer.OrdinalIgnoreCase);
        environment.Clear();
        foreach (var (name, value) in host)
        {
            if (IsInherited(name, options.InheritedEnvironment) && !LooksSecret(name))
            {
                environment[name] = value;
            }
        }

        var secrets = new List<string>();
        foreach (var secret in options.AuthorizedSecrets)
        {
            if (repository is not null && secret.Repositories.Contains(repository, StringComparer.OrdinalIgnoreCase)
                && host.TryGetValue(secret.Name, out var value) && !string.IsNullOrEmpty(value))
            {
                environment[secret.Name] = value;
                secrets.Add(value);
            }
        }

        foreach (var (name, value) in ValidateOverrides(overrides))
        {
            environment[name] = value;
        }

        environment["DOTNET_CLI_TELEMETRY_OPTOUT"] = "1";
        environment["DOTNET_NOLOGO"] = "1";
        environment["DOTNET_SKIP_FIRST_TIME_EXPERIENCE"] = "1";
        environment["MSBUILDDISABLENODEREUSE"] = "1";
        environment["DOTNET_CLI_UI_LANGUAGE"] = "en";
        environment["VSLANG"] = "1033";
        environment["POWERSHELL_TELEMETRY_OPTOUT"] = "1";
        environment["POWERSHELL_UPDATECHECK"] = "Off";
        environment["GIT_TERMINAL_PROMPT"] = "0";
        environment["GIT_PAGER"] = "cat";
        environment["PAGER"] = "cat";
        environment["NO_COLOR"] = "1";
        return secrets;
    }

    [GeneratedRegex("^[A-Za-z_][A-Za-z0-9_.]*$")]
    private static partial Regex NamePattern();

    private static string Clip(string value) => value.Length > 40 ? value[..40] + "…" : value;
}

/// <summary>Redacts known secret values and well-known secret shapes from command output and transcripts.</summary>
public sealed class OutputRedactor(IEnumerable<string>? secretValues = null)
{
    private readonly string[] _values = (secretValues ?? []).Where(v => v.Length >= 4).Distinct().OrderByDescending(v => v.Length).ToArray();

    public string Redact(string line)
    {
        foreach (var value in _values)
        {
            if (line.Contains(value, StringComparison.Ordinal))
            {
                line = line.Replace(value, SecretRedactor.Mask, StringComparison.Ordinal);
            }
        }
        return SecretRedactor.Redact(line);
    }
}
