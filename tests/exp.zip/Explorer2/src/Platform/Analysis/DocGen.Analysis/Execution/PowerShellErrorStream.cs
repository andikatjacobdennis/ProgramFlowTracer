using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace DocGen.Analysis.Execution;

/// <summary>
/// Turns PowerShell's serialized error stream back into the text a console would have shown.
///
/// <para>
/// Windows PowerShell writes its own error records to a redirected stderr as CLIXML - a header line and an
/// &lt;Objs&gt; document of per-line fragments - rather than as text. It does this whenever stderr is a pipe, which is
/// always here, and there is no switch that turns it off: -OutputFormat Text governs stdout and leaves this alone.
/// Undecoded, a mistyped folder name reaches the terminal as a screenful of angle brackets with the sentence that
/// says what went wrong buried inside it.
/// </para>
/// <para>
/// The document stays open for the whole command: PowerShell writes the opening tag once, appends one element per
/// fragment as errors happen, and closes it only when it exits. So decoding works element by element - an error is
/// shown as soon as its own element is complete, not when the command ends, which for a server or a watch script
/// would be never.
/// </para>
/// <para>
/// Only PowerShell's own records are encoded. A child process inherits the same stderr handle and writes to it
/// directly, so a Python traceback or a compiler's diagnostics arrive as plain text on the same stream - even while
/// the document is open - and must pass through untouched.
/// </para>
/// </summary>
public static partial class PowerShellErrorStream
{
    /// <summary>PowerShell's own sentinel, and the only thing that puts this decoder in play.</summary>
    private const string Header = "#< CLIXML";

    private const string Open = "<Objs";
    private const string Close = "</Objs>";

    /// <summary>An opening tag longer than this is not PowerShell's (its own is about 90 characters).</summary>
    private const int MaxOpenTag = 512;

    /// <summary>Decodes a complete piece of stderr in one go (every document in it, whole or not).</summary>
    public static string Decode(string text)
    {
        var reader = new Reader();
        return reader.Take(text, text.Length, final: true, out _);
    }

    /// <summary>
    /// Stateful decoder for one stream. <see cref="Take"/> consumes as much of the pending text as can be released now
    /// and returns what to show; the caller keeps the rest and offers it again with more text appended.
    /// </summary>
    public sealed class Reader
    {
        private bool _inside;

        /// <summary>
        /// Consumes from the start of <paramref name="text"/>. Plain text (outside a document, or a child's output inside
        /// one) is released only up to <paramref name="plainLimit"/> - the caller's line-break rule - while a completed
        /// element is always released. <paramref name="final"/> releases everything, decoding what can be decoded.
        /// </summary>
        public string Take(string text, int plainLimit, bool final, out int consumed)
        {
            var sb = new StringBuilder();
            var at = 0;
            plainLimit = final ? text.Length : Math.Clamp(plainLimit, 0, text.Length);

            while (at < text.Length)
            {
                var next = _inside ? Inside(text, at, final, sb) : Outside(text, at, plainLimit, final, sb);
                if (next == at)
                {
                    break;
                }
                at = next;
            }

            consumed = at;
            return sb.ToString();
        }

        /// <summary>Plain text until a header that introduces a document; the header and the opening tag are dropped.</summary>
        private int Outside(string text, int at, int plainLimit, bool final, StringBuilder sb)
        {
            var header = text.IndexOf(Header, at, StringComparison.Ordinal);
            if (header < 0)
            {
                // The header may be split across chunks ("#< CL"): hold it - but only at the start of a line, so a "#"
                // at the end of some program's output is not delayed.
                var end = final ? text.Length : Math.Min(plainLimit, HeaderPrefixStart(text, at));
                return Plain(text, at, Math.Max(at, end), sb);
            }
            if (header > at)
            {
                return Plain(text, at, Math.Min(header, final ? header : Math.Max(at, plainLimit)), sb);
            }

            // At the header: it must be followed by the opening tag of a document.
            var afterHeader = header + Header.Length;
            while (afterHeader < text.Length && text[afterHeader] is '\r' or '\n')
            {
                afterHeader++;
            }
            var tagEnd = afterHeader + Open.Length > text.Length ? -1 : text.IndexOf('>', afterHeader);
            if (tagEnd < 0)
            {
                if (!final && text.Length - header < Header.Length + 2 + MaxOpenTag)
                {
                    return at; // Wait for the rest of the header and the opening tag.
                }
                return Plain(text, at, final ? text.Length : afterHeader, sb);
            }
            if (string.CompareOrdinal(text, afterHeader, Open, 0, Open.Length) != 0 || tagEnd - afterHeader > MaxOpenTag)
            {
                // A "#< CLIXML" that is not followed by a document: show it as it came.
                return Plain(text, at, afterHeader, sb);
            }
            _inside = true;
            return tagEnd + 1;
        }

        /// <summary>
        /// Inside a document: decoded &lt;S&gt; fragments, dropped &lt;Obj&gt; progress records, the closing tag, and
        /// plain text a child process wrote in between.
        /// </summary>
        private int Inside(string text, int at, bool final, StringBuilder sb)
        {
            if (string.CompareOrdinal(text, at, Close, 0, Close.Length) == 0)
            {
                _inside = false;
                return at + Close.Length;
            }
            if (IsElementStart(text, at, "S"))
            {
                var end = text.IndexOf("</S>", at, StringComparison.Ordinal);
                if (end < 0)
                {
                    return final ? Plain(text, at, text.Length, sb) : at;
                }
                end += "</S>".Length;
                sb.Append(Render(text[at..end]) ?? text[at..end]);
                return end;
            }
            if (IsElementStart(text, at, "Obj"))
            {
                var end = ObjEnd(text, at);
                if (end < 0)
                {
                    return final ? Plain(text, at, text.Length, sb) : at;
                }
                return end; // A progress record: a console draws and erases it; nothing to show once it is over.
            }
            if (text[at] is '\r' or '\n')
            {
                return at + 1;
            }

            // A child's output while the document is open: plain text up to the next element.
            var marker = NextMarker(text, at + 1);
            if (marker < 0)
            {
                // The text may end in the first characters of an element ("<S S"): hold those.
                return Plain(text, at, final ? text.Length : TrailingMarkerPrefix(text, at), sb);
            }
            return Plain(text, at, marker, sb);
        }

        private static int Plain(string text, int from, int to, StringBuilder sb)
        {
            if (to > from)
            {
                sb.Append(text, from, to - from);
            }
            return Math.Max(from, to);
        }
    }

    /// <summary>"&lt;S " / "&lt;S&gt;" (or Obj) at <paramref name="at"/>, but not "&lt;Objs".</summary>
    private static bool IsElementStart(string text, int at, string name)
    {
        var after = at + 1 + name.Length;
        return after < text.Length && text[at] == '<' && string.CompareOrdinal(text, at + 1, name, 0, name.Length) == 0 && text[after] is ' ' or '>';
    }

    /// <summary>End of the &lt;Obj&gt; starting at <paramref name="at"/> (nested ones counted), or -1 when not complete yet.</summary>
    private static int ObjEnd(string text, int at)
    {
        var depth = 0;
        var i = at;
        while (i < text.Length)
        {
            var open = text.IndexOf("<Obj", i, StringComparison.Ordinal);
            var close = text.IndexOf("</Obj>", i, StringComparison.Ordinal);
            if (close < 0)
            {
                return -1;
            }
            if (open >= 0 && open < close && IsElementStart(text, open, "Obj"))
            {
                depth++;
                i = open + 4;
                continue;
            }
            if (open >= 0 && open < close)
            {
                i = open + 4; // "<Objs" or similar: not an element start.
                continue;
            }
            depth--;
            i = close + "</Obj>".Length;
            if (depth <= 0)
            {
                return i;
            }
        }
        return -1;
    }

    private static readonly string[] Markers = ["<S ", "<S>", "<Obj ", "<Obj>", Close];

    private static int NextMarker(string text, int from)
    {
        var best = -1;
        foreach (var m in Markers)
        {
            var i = text.IndexOf(m, from, StringComparison.Ordinal);
            if (i >= 0 && (best < 0 || i < best))
            {
                best = i;
            }
        }
        return best;
    }

    /// <summary>Start of a trailing partial marker ("&lt;", "&lt;S", "&lt;/Obj"…), or text.Length when there is none.</summary>
    private static int TrailingMarkerPrefix(string text, int from)
    {
        var lt = text.LastIndexOf('<');
        if (lt < from)
        {
            return text.Length;
        }
        var tail = text[lt..];
        return Markers.Any(m => m.Length > tail.Length && m.StartsWith(tail, StringComparison.Ordinal)) ? lt : text.Length;
    }

    /// <summary>Start of a partial header at the end of the text, when it begins a line.</summary>
    private static int HeaderPrefixStart(string text, int from)
    {
        for (var held = Math.Min(Header.Length - 1, text.Length - from); held >= 1; held--)
        {
            var start = text.Length - held;
            if (string.CompareOrdinal(text, start, Header, 0, held) == 0 && (start == 0 || text[start - 1] is '\n' or '\r'))
            {
                return start;
            }
        }
        return text.Length;
    }

    /// <summary>The text of one &lt;S&gt; element, or null where it does not parse.</summary>
    private static string? Render(string element)
    {
        try
        {
            return Unescape(XElement.Parse(element).Value);
        }
        catch (System.Xml.XmlException)
        {
            return null;
        }
    }

    /// <summary>
    /// CLIXML escapes anything that cannot sit in an XML text node - the line breaks that end every fragment, and any
    /// literal underscore - as _xHHHH_. XElement has already undone the entities by the time this runs.
    /// </summary>
    private static string Unescape(string value) =>
        EscapedChar().Replace(value, m => ((char)Convert.ToInt32(m.Groups[1].Value, 16)).ToString());

    [GeneratedRegex("_x([0-9A-Fa-f]{4})_")]
    private static partial Regex EscapedChar();
}
