using System.Text.RegularExpressions;

namespace DocGen.Analysis.Execution;

/// <summary>A file-system location a script deletes, moves or writes, as written in the script.</summary>
/// <param name="Command">The cmdlet or program (aliases resolved), e.g. Remove-Item.</param>
/// <param name="Path">The path as resolved without running anything, or null when it is computed at run time ($var, $(…)).</param>
/// <param name="Raw">The argument as written.</param>
/// <param name="Delete">True for deletes and moves (the original disappears).</param>
/// <param name="Recursive">True when a whole folder tree is affected (-Recurse, /s).</param>
public sealed record MutationTarget(string Command, string? Path, string Raw, bool Delete, bool Recursive, int Line);

/// <summary>
/// Where a PowerShell script changes the file system. <see cref="PowerShellInspector"/> classifies commands by name
/// ("Remove-Item is a file delete"); this says <em>where</em> they act, so the approval policy can tell a clean-up in
/// the chat's folder from a recursive delete in the user's profile. Paths are resolved statically: environment
/// variables the script reads ($env:APPDATA, %APPDATA%, $HOME, ~) are expanded with the values the command would
/// see, relative paths against the working directory. Anything computed at run time is reported with a null path.
/// </summary>
public static partial class MutationTargets
{
    // Which parameters and which positional arguments (0-based) name a location the command changes. Copy-Item's
    // source is only read, so only its destination (second positional or -Destination) counts.
    private static readonly Dictionary<string, (bool Delete, string[] PathParameters, int[] Positionals)> FileCommands = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Remove-Item"] = (true, ["Path", "LiteralPath"], [0]),
        ["Move-Item"] = (true, ["Path", "LiteralPath", "Destination"], [0, 1]),
        ["Copy-Item"] = (false, ["Destination"], [1]),
        ["Rename-Item"] = (true, ["Path", "LiteralPath"], [0]),
        ["New-Item"] = (false, ["Path"], [0]),
        ["Set-Content"] = (false, ["Path", "LiteralPath"], [0]),
        ["Add-Content"] = (false, ["Path", "LiteralPath"], [0]),
        ["Clear-Content"] = (true, ["Path", "LiteralPath"], [0]),
        ["Out-File"] = (false, ["FilePath", "LiteralPath", "Path"], [0]),
        ["Export-Csv"] = (false, ["Path", "LiteralPath"], [0]),
        ["Expand-Archive"] = (false, ["DestinationPath"], [1]),
        ["Compress-Archive"] = (false, ["DestinationPath"], [1]),
        ["Set-Item"] = (false, ["Path", "LiteralPath"], [0]),
    };

    private static readonly Dictionary<string, string> Aliases = new(StringComparer.OrdinalIgnoreCase)
    {
        ["rm"] = "Remove-Item", ["del"] = "Remove-Item", ["erase"] = "Remove-Item", ["rd"] = "Remove-Item", ["ri"] = "Remove-Item", ["rmdir"] = "Remove-Item",
        ["mv"] = "Move-Item", ["move"] = "Move-Item", ["mi"] = "Move-Item", ["cp"] = "Copy-Item", ["copy"] = "Copy-Item", ["cpi"] = "Copy-Item",
        ["ren"] = "Rename-Item", ["rni"] = "Rename-Item", ["ni"] = "New-Item", ["md"] = "New-Item", ["mkdir"] = "New-Item", ["sc"] = "Set-Content",
        ["ac"] = "Add-Content", ["clc"] = "Clear-Content", ["si"] = "Set-Item",
    };

    /// <summary>The locations <paramref name="script"/> deletes, moves or writes.</summary>
    /// <param name="workingDirectory">Directory the script runs in (relative paths resolve against it).</param>
    /// <param name="environment">Environment variable lookup for the values the command will see.</param>
    public static IReadOnlyList<MutationTarget> Find(string script, string workingDirectory, Func<string, string?> environment)
    {
        var targets = new List<MutationTarget>();
        var lines = script.Replace("\r", "").Split('\n');
        for (var n = 0; n < lines.Length; n++)
        {
            foreach (var statement in Statements(lines[n]))
            {
                var words = Words(statement);
                if (words.Count == 0)
                {
                    continue;
                }
                var first = words[0];
                if (first is "&" or "." && words.Count > 1)
                {
                    words.RemoveAt(0);
                    first = words[0];
                }
                var name = Aliases.TryGetValue(first, out var full) ? full : first;
                if (FileCommands.TryGetValue(name, out var spec))
                {
                    var recursive = words.Any(w => w.Length >= 2 && "-recurse".StartsWith(w, StringComparison.OrdinalIgnoreCase));
                    foreach (var raw in PathArguments(words, spec.PathParameters, spec.Positionals))
                    {
                        targets.Add(new MutationTarget(name, Resolve(raw, workingDirectory, environment), raw, spec.Delete, recursive && spec.Delete, n + 1));
                    }
                }
                else if (Path.GetFileNameWithoutExtension(name).Equals("cmd", StringComparison.OrdinalIgnoreCase)
                         && words.FindIndex(w => w.Equals("/c", StringComparison.OrdinalIgnoreCase) || w.Equals("/k", StringComparison.OrdinalIgnoreCase)) is var c and >= 0
                         && c + 1 < words.Count && words[c + 1].ToLowerInvariant() is "rd" or "rmdir" or "del" or "erase")
                {
                    // cmd /c rmdir /s /q <path>
                    var rest = words.Skip(c + 2).ToList();
                    var recursive = rest.Any(w => w.Equals("/s", StringComparison.OrdinalIgnoreCase));
                    foreach (var raw in rest.Where(w => !w.StartsWith('/')))
                    {
                        targets.Add(new MutationTarget("cmd " + words[c + 1].ToLowerInvariant(), Resolve(raw, workingDirectory, environment), raw, true, recursive, n + 1));
                    }
                }
            }
            foreach (Match m in DotNetDelete().Matches(lines[n]))
            {
                var raw = m.Groups["arg"].Value.Trim();
                targets.Add(new MutationTarget($"[IO.{m.Groups["type"].Value}]::{m.Groups["op"].Value}", Resolve(raw, workingDirectory, environment), raw,
                    true, m.Groups["type"].Value.Equals("Directory", StringComparison.OrdinalIgnoreCase) && m.Groups["rest"].Value.Contains("true", StringComparison.OrdinalIgnoreCase), n + 1));
            }
            foreach (Match m in Redirect().Matches(StripQuoted(lines[n])))
            {
                // Redirection target as written in the original line (same offset: StripQuoted keeps lengths).
                var raw = FirstWord(lines[n][(m.Index + m.Length - m.Groups["target"].Length)..]);
                if (raw.Length > 0 && !raw.StartsWith("$null", StringComparison.OrdinalIgnoreCase))
                {
                    targets.Add(new MutationTarget(">", Resolve(raw, workingDirectory, environment), raw, false, false, n + 1));
                }
            }
        }
        return targets;
    }

    /// <summary>
    /// Resolves a path argument without running anything: quotes removed, $env:X / ${env:X} / %X% / $HOME / ~ expanded,
    /// relative paths made absolute; wildcards keep their folder. Null when the path depends on run-time values.
    /// </summary>
    public static string? Resolve(string raw, string workingDirectory, Func<string, string?> environment)
    {
        var value = raw.Trim().Trim('(', ')').Trim();
        var single = value.Length >= 2 && value[0] == '\'' && value[^1] == '\'';
        value = value.Trim('"', '\'').Trim();
        if (value.Length == 0)
        {
            return null;
        }
        if (!single)
        {
            var unknown = false;
            value = EnvVariable().Replace(value, m =>
            {
                var v = environment(m.Groups["a"].Success ? m.Groups["a"].Value : m.Groups["b"].Value);
                unknown |= v is null;
                return v ?? "";
            });
            if (Regex.IsMatch(value, @"\$HOME\b", RegexOptions.IgnoreCase))
            {
                var home = environment("USERPROFILE");
                unknown |= home is null;
                value = Regex.Replace(value, @"\$HOME\b", (home ?? "").Replace("$", "$$"), RegexOptions.IgnoreCase);
            }
            if (unknown || value.Contains('$') || value.Contains('`'))
            {
                return null;
            }
        }
        value = PercentVariable().Replace(value, m => environment(m.Groups[1].Value) ?? m.Value);
        if (value.Contains('%'))
        {
            return null;
        }
        if (value == "~" || value.StartsWith("~\\") || value.StartsWith("~/"))
        {
            value = (environment("USERPROFILE") ?? "") + value[1..];
        }
        var wildcard = value.IndexOfAny(['*', '?', '[']);
        if (wildcard >= 0)
        {
            var cut = value.LastIndexOfAny(['\\', '/'], wildcard);
            value = cut < 0 ? "." : value[..cut];
        }
        try
        {
            return System.IO.Path.GetFullPath(System.IO.Path.IsPathFullyQualified(value) ? value : System.IO.Path.Combine(workingDirectory, value));
        }
        catch (Exception ex) when (ex is ArgumentException or NotSupportedException or PathTooLongException)
        {
            return null;
        }
    }

    /// <summary>Whether <paramref name="path"/> is <paramref name="root"/> or lies inside it.</summary>
    public static bool IsInside(string path, string root)
    {
        var p = System.IO.Path.GetFullPath(path).TrimEnd('\\', '/');
        var r = System.IO.Path.GetFullPath(root).TrimEnd('\\', '/');
        return p.Equals(r, StringComparison.OrdinalIgnoreCase) || p.StartsWith(r + System.IO.Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
    }

    private static IEnumerable<string> PathArguments(List<string> words, string[] parameters, int[] positionals)
    {
        var positional = 0;
        for (var i = 1; i < words.Count; i++)
        {
            var w = words[i];
            if (w.StartsWith('-') && w.Length > 1 && char.IsLetter(w[1]))
            {
                var p = w[1..].TrimEnd(':');
                var colon = w.IndexOf(':');
                if (parameters.Any(x => x.StartsWith(colon > 0 ? w[1..colon] : p, StringComparison.OrdinalIgnoreCase) && (colon > 0 ? colon - 1 : p.Length) >= 2))
                {
                    if (colon > 0 && colon + 1 < w.Length)
                    {
                        yield return w[(colon + 1)..];
                    }
                    else if (i + 1 < words.Count)
                    {
                        foreach (var item in words[++i].Split(','))
                        {
                            yield return item;
                        }
                    }
                }
                else if (TakesValue(p) && i + 1 < words.Count && !words[i + 1].StartsWith('-'))
                {
                    i++;
                }
                continue;
            }
            if (positionals.Contains(positional++))
            {
                foreach (var item in w.Split(','))
                {
                    yield return item;
                }
            }
        }
    }

    // Switch parameters (no value): anything else consumes the next word.
    private static bool TakesValue(string parameter)
        => !new[] { "Recurse", "Force", "WhatIf", "Confirm", "PassThru", "NoNewline", "Append", "NoClobber", "Container", "ErrorAction", "Verbose" }
            .Any(s => s.StartsWith(parameter, StringComparison.OrdinalIgnoreCase)) || parameter.StartsWith("ErrorA", StringComparison.OrdinalIgnoreCase)
            || parameter.Equals("ea", StringComparison.OrdinalIgnoreCase);

    /// <summary>Splits a line into statements at ; | && || outside quotes and braces' first level.</summary>
    private static IEnumerable<string> Statements(string line)
    {
        var start = 0;
        char quote = '\0';
        for (var i = 0; i < line.Length; i++)
        {
            var ch = line[i];
            if (quote != '\0')
            {
                if (ch == quote)
                {
                    quote = '\0';
                }
                continue;
            }
            if (ch is '"' or '\'')
            {
                quote = ch;
                continue;
            }
            if (ch == '#')
            {
                yield return line[start..i];
                yield break;
            }
            if (ch is ';' or '|' or '{' or '}')
            {
                yield return line[start..i];
                start = i + 1;
            }
        }
        yield return line[start..];
    }

    /// <summary>Words of a statement; quoted strings stay one word (with their quotes).</summary>
    private static List<string> Words(string statement)
    {
        var words = new List<string>();
        var i = 0;
        while (i < statement.Length)
        {
            while (i < statement.Length && char.IsWhiteSpace(statement[i]))
            {
                i++;
            }
            if (i >= statement.Length)
            {
                break;
            }
            var start = i;
            var depth = 0;
            char quote = '\0';
            while (i < statement.Length && (quote != '\0' || depth > 0 || !char.IsWhiteSpace(statement[i])))
            {
                var ch = statement[i];
                if (quote != '\0')
                {
                    if (ch == quote)
                    {
                        quote = '\0';
                    }
                }
                else if (ch is '"' or '\'')
                {
                    quote = ch;
                }
                else if (ch == '(')
                {
                    depth++;
                }
                else if (ch == ')' && depth > 0)
                {
                    depth--;
                }
                i++;
            }
            words.Add(statement[start..i]);
        }
        return words;
    }

    private static string FirstWord(string text) => Words(text.TrimStart()).FirstOrDefault() ?? "";

    private static string StripQuoted(string line)
    {
        var chars = line.ToCharArray();
        char quote = '\0';
        for (var i = 0; i < chars.Length; i++)
        {
            if (quote != '\0')
            {
                if (chars[i] == quote)
                {
                    quote = '\0';
                }
                else
                {
                    chars[i] = ' ';
                }
            }
            else if (chars[i] is '"' or '\'')
            {
                quote = chars[i];
            }
        }
        return new string(chars);
    }

    [GeneratedRegex(@"\$\{env:(?<a>[A-Za-z_][\w()]*)\}|\$env:(?<b>[A-Za-z_]\w*)", RegexOptions.IgnoreCase)]
    private static partial Regex EnvVariable();

    [GeneratedRegex(@"%([A-Za-z_]\w*)%")]
    private static partial Regex PercentVariable();

    [GeneratedRegex(@"\[(?:System\.)?IO\.(?<type>File|Directory)\]::(?<op>Delete|Move)\(\s*(?<arg>(?:""[^""]*""|'[^']*'|[^,)]+))(?<rest>[^)]*)\)", RegexOptions.IgnoreCase)]
    private static partial Regex DotNetDelete();

    [GeneratedRegex(@"(?<![-\w>])\d?>>?\s*(?<target>(?!&\d)\S+)")]
    private static partial Regex Redirect();
}
