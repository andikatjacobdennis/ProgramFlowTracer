namespace DocGen.Analysis.Browser;

/// <summary>
/// JavaScript evaluated in the page (as a self-contained expression) to read DOM-backed accessibility information and
/// resolve elements. Elements that are reported get a stable data-docgen-ref attribute, so "ref_12" can be clicked later.
/// The scripts only read the page and dispatch the same events a user would; they never access storage or cookies.
/// </summary>
internal static class PageScripts
{
    /// <summary>Defines window.__docgen (idempotent per document).</summary>
    public const string Helpers = """
        (() => {
          if (window.__docgen) return window.__docgen;
          const H = {};
          H.next = 1;
          H.visible = (el) => {
            if (!el || !el.isConnected) return false;
            const s = getComputedStyle(el);
            if (s.visibility === 'hidden' || s.display === 'none' || Number(s.opacity) === 0) return false;
            const r = el.getBoundingClientRect();
            return r.width > 0 && r.height > 0;
          };
          H.text = (el) => (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
          H.name = (el) => {
            const aria = el.getAttribute('aria-label');
            if (aria) return aria.trim();
            const by = el.getAttribute('aria-labelledby');
            if (by) { const t = by.split(/\s+/).map(id => document.getElementById(id)).filter(Boolean).map(H.text).join(' '); if (t) return t; }
            if (el.id) { const l = document.querySelector('label[for="' + CSS.escape(el.id) + '"]'); if (l) return H.text(l); }
            const wrap = el.closest && el.closest('label'); if (wrap && wrap !== el) { const t = H.text(wrap); if (t) return t; }
            if (['INPUT', 'TEXTAREA', 'SELECT'].includes(el.tagName)) {
              // Unlinked label right before the control (common in hand-written forms).
              let prev = el.previousElementSibling;
              while (prev && prev.tagName !== 'LABEL' && !['INPUT', 'TEXTAREA', 'SELECT', 'BUTTON'].includes(prev.tagName)) prev = prev.previousElementSibling;
              if (prev && prev.tagName === 'LABEL' && !prev.control) { const t = H.text(prev); if (t) return t; }
            }
            for (const a of ['placeholder', 'alt', 'title']) { const v = el.getAttribute(a); if (v) return v.trim(); }
            if (el.tagName === 'INPUT' && ['submit', 'button', 'reset'].includes(el.type)) return el.value || el.type;
            const t = H.text(el); return t.length > 120 ? t.slice(0, 120) + '…' : t;
          };
          H.role = (el) => {
            const r = el.getAttribute('role'); if (r) return r;
            const tag = el.tagName.toLowerCase();
            if (/^h[1-6]$/.test(tag)) return 'heading';
            if (tag === 'a') return el.hasAttribute('href') ? 'link' : 'generic';
            if (tag === 'button' || tag === 'summary') return 'button';
            if (tag === 'select') return 'combobox';
            if (tag === 'textarea') return 'textbox';
            if (tag === 'input') {
              const t = (el.type || 'text').toLowerCase();
              return ({ checkbox: 'checkbox', radio: 'radio', submit: 'button', button: 'button', reset: 'button', range: 'slider', search: 'searchbox', password: 'textbox', email: 'textbox', number: 'spinbutton' })[t] || 'textbox';
            }
            return ({ nav: 'navigation', main: 'main', header: 'banner', footer: 'contentinfo', form: 'form', dialog: 'dialog', table: 'table', ul: 'list', ol: 'list', li: 'listitem', img: 'img', aside: 'complementary' })[tag] || 'generic';
          };
          H.interactive = (el) => {
            const tag = el.tagName.toLowerCase();
            if (['a', 'button', 'input', 'select', 'textarea', 'summary'].includes(tag)) return true;
            const r = el.getAttribute('role');
            if (r && ['button', 'link', 'tab', 'menuitem', 'checkbox', 'radio', 'switch', 'option', 'textbox', 'combobox', 'searchbox', 'slider'].includes(r)) return true;
            return el.hasAttribute('onclick') || (el.hasAttribute('tabindex') && el.getAttribute('tabindex') !== '-1') || el.isContentEditable;
          };
          H.ref = (el) => {
            let r = el.getAttribute('data-docgen-ref');
            if (!r) { r = String(H.next++); el.setAttribute('data-docgen-ref', r); }
            return 'ref_' + r;
          };
          H.sensitive = (el) => {
            const reasons = [];
            const type = (el.getAttribute('type') || '').toLowerCase();
            const ac = (el.getAttribute('autocomplete') || '').toLowerCase();
            if (type === 'password' || ac.includes('password')) reasons.push('password field');
            if (ac.startsWith('cc-')) reasons.push('payment card field');
            const form = el.closest && el.closest('form');
            if (form && form.querySelector('input[type=password]') && (el.type === 'submit' || el.tagName === 'BUTTON')) reasons.push('submits a form with a password');
            const label = (H.name(el) + ' ' + (el.getAttribute('value') || '')).toLowerCase();
            if (/\b(buy|purchase|pay|payment|checkout|place order|order now|transfer|withdraw|donate|subscribe)\b/.test(label)) reasons.push('purchase or payment action');
            if (/\b(delete|remove|destroy|drop|erase|purge|wipe|revoke|deactivate)\b/.test(label)) reasons.push('destructive action');
            return reasons;
          };
          H.editable = (el) => !!el && (['INPUT', 'TEXTAREA', 'SELECT'].includes(el.tagName) || el.isContentEditable);
          H.controlFor = (label) => {
            if (label.control) return label.control;
            const inside = label.querySelector('input,textarea,select,[contenteditable=true]');
            if (inside) return inside;
            let next = label.nextElementSibling;
            while (next) {
              if (H.editable(next)) return next;
              const nested = next.querySelector && next.querySelector('input,textarea,select,[contenteditable=true]');
              if (nested) return nested;
              if (next.tagName === 'LABEL') break;
              next = next.nextElementSibling;
            }
            return null;
          };
          H.find = (t) => {
            if (t.ref) return document.querySelector('[data-docgen-ref="' + String(t.ref).replace(/^ref_/, '') + '"]');
            if (t.selector) return document.querySelector(t.selector);
            if (t.text) {
              const want = t.text.trim().toLowerCase();
              const candidates = [...document.querySelectorAll('a,button,summary,label,[role=button],[role=link],[role=tab],[role=menuitem],[role=checkbox],[role=switch],input:not([type=hidden]),textarea,select,[contenteditable=true],h1,h2,h3,h4,[onclick]')].filter(H.visible);
              const hit = candidates.find(e => H.name(e).toLowerCase() === want) || candidates.find(e => H.name(e).toLowerCase().includes(want)) || null;
              // A label stands for its form control: linked (for=/nesting) or the nearest control in the same field.
              return hit && hit.tagName === 'LABEL' ? (H.controlFor(hit) || hit) : hit;
            }
            return null;
          };
          H.describe = (el) => el ? ({
            ref: H.ref(el), role: H.role(el), name: H.name(el), tag: el.tagName.toLowerCase(), type: el.getAttribute('type'),
            href: el.getAttribute('href'), visible: H.visible(el), sensitive: H.sensitive(el), disabled: !!el.disabled,
          }) : null;
          H.snapshot = (filter, maxLines) => {
            const lines = []; const depthOf = new Map(); let truncated = false;
            const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_ELEMENT);
            const landmarks = ['heading', 'navigation', 'main', 'banner', 'contentinfo', 'form', 'dialog', 'table', 'img', 'complementary'];
            let el = walker.currentNode;
            while (el) {
              if (el.nodeType === 1 && H.visible(el)) {
                const role = H.role(el);
                const interactive = H.interactive(el);
                let include = interactive || landmarks.includes(role);
                let textOnly = false;
                if (!include && filter === 'all') {
                  const direct = [...el.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent.trim()).join(' ').trim();
                  if (direct.length > 1 && ['p', 'li', 'td', 'th', 'span', 'div', 'label', 'dd', 'dt', 'pre', 'code', 'small', 'strong', 'em'].includes(el.tagName.toLowerCase())) { include = true; textOnly = true; }
                }
                let parent = el.parentElement, depth = 0;
                while (parent) { if (depthOf.has(parent)) { depth = depthOf.get(parent) + 1; break; } parent = parent.parentElement; }
                if (include) {
                  depthOf.set(el, depth);
                  if (lines.length >= maxLines) { truncated = true; break; }
                  let line = '  '.repeat(Math.min(depth, 12)) + '- ';
                  if (textOnly) {
                    const t = [...el.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent).join(' ').replace(/\s+/g, ' ').trim();
                    line += 'text "' + (t.length > 160 ? t.slice(0, 160) + '…' : t) + '"';
                  } else {
                    line += role + ' "' + H.name(el).replace(/"/g, "'") + '"';
                    if (role === 'heading') line += ' level=' + el.tagName.slice(1);
                    if (el.getAttribute('href')) line += ' href=' + el.getAttribute('href').slice(0, 120);
                    if ('value' in el && ['INPUT', 'TEXTAREA', 'SELECT'].includes(el.tagName) && el.type !== 'password') line += ' value="' + String(el.value).slice(0, 80) + '"';
                    if (el.type === 'password') line += ' [password]';
                    if (el.disabled) line += ' [disabled]';
                    if (el.getAttribute('aria-expanded')) line += ' expanded=' + el.getAttribute('aria-expanded');
                    if (el.checked) line += ' [checked]';
                    if (interactive) line += ' [' + H.ref(el) + ']';
                  }
                  lines.push(line);
                }
              }
              el = walker.nextNode();
            }
            return { title: document.title, url: location.href, lines, truncated, scrollY: Math.round(scrollY), height: document.documentElement.scrollHeight, width: innerWidth, viewportHeight: innerHeight };
          };
          window.__docgen = H;
          return H;
        })()
        """;

    public static string Call(string expression) => "(() => { const H = " + Helpers + "; return (" + expression + "); })()";
}
