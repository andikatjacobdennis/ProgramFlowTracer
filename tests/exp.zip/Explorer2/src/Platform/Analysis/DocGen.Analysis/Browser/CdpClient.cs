using System.Collections.Concurrent;
using System.Net.WebSockets;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using DocGen.Core.Exceptions;

namespace DocGen.Analysis.Browser;

/// <summary>
/// Minimal Chrome DevTools Protocol client over <see cref="ClientWebSocket"/> (no third-party packages). Commands are
/// JSON-RPC style messages with ids; responses complete the matching task; events are dispatched to subscribers.
/// Flattened target sessions are addressed with a sessionId on each message.
/// </summary>
public sealed class CdpClient : IAsyncDisposable
{
    private readonly ClientWebSocket _socket = new();
    private readonly ConcurrentDictionary<int, TaskCompletionSource<JsonElement>> _pending = new();
    private readonly SemaphoreSlim _send = new(1, 1);
    private readonly CancellationTokenSource _closing = new();
    private int _nextId;
    private Task? _receive;

    /// <summary>(method, sessionId, params) for every event.</summary>
    public event Action<string, string?, JsonElement>? Event;

    public bool IsOpen => _socket.State == WebSocketState.Open;

    public async Task ConnectAsync(Uri endpoint, CancellationToken ct)
    {
        _socket.Options.KeepAliveInterval = TimeSpan.FromSeconds(20);
        await _socket.ConnectAsync(endpoint, ct);
        _receive = Task.Run(ReceiveLoopAsync);
    }

    public async Task<JsonElement> SendAsync(string method, object? parameters = null, string? sessionId = null, CancellationToken ct = default, int timeoutSeconds = 30)
    {
        var id = Interlocked.Increment(ref _nextId);
        var message = new JsonObject { ["id"] = id, ["method"] = method };
        if (parameters is not null)
        {
            message["params"] = JsonSerializer.SerializeToNode(parameters);
        }
        if (sessionId is not null)
        {
            message["sessionId"] = sessionId;
        }
        var tcs = new TaskCompletionSource<JsonElement>(TaskCreationOptions.RunContinuationsAsynchronously);
        _pending[id] = tcs;
        var bytes = Encoding.UTF8.GetBytes(message.ToJsonString());
        await _send.WaitAsync(ct);
        try
        {
            if (!IsOpen)
            {
                throw new DocGenException("BROWSER_CLOSED", "The browser connection is closed.", 409);
            }
            await _socket.SendAsync(bytes, WebSocketMessageType.Text, endOfMessage: true, ct);
        }
        finally
        {
            _send.Release();
        }
        try
        {
            return await tcs.Task.WaitAsync(TimeSpan.FromSeconds(timeoutSeconds), ct);
        }
        catch (TimeoutException)
        {
            throw new DocGenException("BROWSER_TIMEOUT", $"The browser did not answer {method} within {timeoutSeconds} s.", 504);
        }
        finally
        {
            _pending.TryRemove(id, out _);
        }
    }

    private async Task ReceiveLoopAsync()
    {
        var buffer = new byte[64 * 1024];
        using var message = new MemoryStream();
        try
        {
            while (!_closing.IsCancellationRequested && _socket.State == WebSocketState.Open)
            {
                message.SetLength(0);
                WebSocketReceiveResult result;
                do
                {
                    result = await _socket.ReceiveAsync(buffer, _closing.Token);
                    if (result.MessageType == WebSocketMessageType.Close)
                    {
                        return;
                    }
                    message.Write(buffer, 0, result.Count);
                    if (message.Length > 64L * 1024 * 1024)
                    {
                        throw new InvalidOperationException("CDP message too large.");
                    }
                }
                while (!result.EndOfMessage);
                Dispatch(message.GetBuffer().AsMemory(0, (int)message.Length));
            }
        }
        catch (Exception ex) when (ex is WebSocketException or OperationCanceledException or InvalidOperationException or ObjectDisposedException)
        {
        }
        finally
        {
            foreach (var pending in _pending.Values)
            {
                pending.TrySetException(new DocGenException("BROWSER_CLOSED", "The browser connection closed.", 409));
            }
        }
    }

    private void Dispatch(ReadOnlyMemory<byte> json)
    {
        using var doc = JsonDocument.Parse(json);
        var root = doc.RootElement;
        if (root.TryGetProperty("id", out var idElement) && idElement.TryGetInt32(out var id))
        {
            if (_pending.TryGetValue(id, out var tcs))
            {
                if (root.TryGetProperty("error", out var error))
                {
                    var text = error.TryGetProperty("message", out var m) ? m.GetString() : "CDP error";
                    tcs.TrySetException(new DocGenException("BROWSER_ERROR", "Browser: " + text, 502));
                }
                else
                {
                    tcs.TrySetResult(root.TryGetProperty("result", out var r) ? r.Clone() : default);
                }
            }
            return;
        }
        if (root.TryGetProperty("method", out var method))
        {
            var sessionId = root.TryGetProperty("sessionId", out var s) ? s.GetString() : null;
            var parameters = root.TryGetProperty("params", out var p) ? p.Clone() : default;
            try
            {
                Event?.Invoke(method.GetString() ?? "", sessionId, parameters);
            }
            catch (Exception)
            {
                // A faulty subscriber must never stop the receive loop.
            }
        }
    }

    public async ValueTask DisposeAsync()
    {
        _closing.Cancel();
        try
        {
            if (_socket.State == WebSocketState.Open)
            {
                using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(2));
                await _socket.CloseAsync(WebSocketCloseStatus.NormalClosure, "closing", timeout.Token);
            }
        }
        catch (Exception ex) when (ex is WebSocketException or OperationCanceledException or ObjectDisposedException)
        {
        }
        if (_receive is not null)
        {
            await _receive.WaitAsync(TimeSpan.FromSeconds(2)).ContinueWith(_ => { }, TaskScheduler.Default);
        }
        _socket.Dispose();
        _closing.Dispose();
    }
}
