using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;

namespace DocGen.Analysis.Browser;

/// <summary>Masks values typed into credential-like fields (password, secret, token, PIN, card number…).</summary>
public static partial class CredentialMask
{
    public const string Masked = "••••";

    /// <summary>Readable JSON for previews (no escape sequences for non-ASCII characters such as the mask bullets).</summary>
    public static readonly JsonSerializerOptions Display = new() { Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping };

    public static bool IsCredentialTarget(string? target) => target is not null && CredentialWords().IsMatch(target);

    /// <summary>browser_type-style arguments: {text|selector|ref, value}.</summary>
    public static string MaskTypeArguments(string json)
    {
        try
        {
            if (JsonNode.Parse(json) is not JsonObject o)
            {
                return json;
            }
            MaskObject(o);
            return o.ToJsonString(Display);
        }
        catch (JsonException)
        {
            return json;
        }
    }

    public static void MaskObject(JsonObject o)
    {
        var target = string.Join(' ', new[] { "text", "selector", "ref", "target" }.Select(k => o[k]?.GetValueKind() == JsonValueKind.String ? o[k]!.GetValue<string>() : null).Where(v => v is not null));
        if (IsCredentialTarget(target) && o["value"] is not null)
        {
            o["value"] = Masked;
        }
    }

    /// <summary>"type X into Password" → "type •••• into Password".</summary>
    public static string MaskSentence(string sentence)
    {
        var m = TypeInto().Match(sentence);
        return m.Success && IsCredentialTarget(m.Groups[2].Value) ? $"{m.Groups["verb"].Value} {Masked} into {m.Groups[2].Value}" : sentence;
    }

    [GeneratedRegex(@"pass(word|wd|code|phrase)?|pwd|secret|token|api.?key|\bpin\b|cvv|cvc|card.?number|credit.?card|otp|2fa", RegexOptions.IgnoreCase)]
    private static partial Regex CredentialWords();

    [GeneratedRegex(@"^(?<verb>type)\s+(.+?)\s+into\s+(.+)$", RegexOptions.IgnoreCase)]
    private static partial Regex TypeIntoRaw();

    private static Regex TypeInto() => TypeIntoRaw();
}
