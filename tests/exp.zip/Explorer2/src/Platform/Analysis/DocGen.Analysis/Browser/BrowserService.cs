using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text.Json;
using System.Text.RegularExpressions;
using DocGen.Analysis.Commands;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Core.Options;
using DocGen.Data.Storage;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Browser;

/// <summary>Identifies an element: a ref from browser_read_page, a CSS selector, or visible text/accessible name.</summary>
public sealed record BrowserTarget(string? Ref = null, string? Selector = null, string? Text = null)
{
    public bool IsEmpty => Ref is null && Selector is null && Text is null;

    public override string ToString() => Ref ?? (Selector is not null ? $"selector {Selector}" : $"\"{Text}\"");
}

public sealed record ElementInfo(string Ref, string Role, string Name, string Tag, string? Href, bool Visible, IReadOnlyList<string> Sensitive, bool Disabled);

public sealed record PageSnapshot(string Title, string Url, IReadOnlyList<string> Lines, bool Truncated, int ScrollY, int Height, int Width, int ViewportHeight);

/// <summary>
/// Where a named element was in a screenshot, in the screenshot's own pixels (CSS pixels × device pixel ratio; for a
/// full-page shot measured from the top of the document). <see cref="Found"/> is false when it was missing or hidden.
/// </summary>
public sealed record LocatedElement(string Name, string Locator, bool Found, int X, int Y, int Width, int Height, string? Role, string? Label, bool PartlyVisible,
    IReadOnlyList<string>? Suggestions = null);

/// <summary>What a screenshot shows besides pixels: the page, the named elements' boxes and the text that was visible.</summary>
public sealed record PageCapture(string Url, string Title, double DevicePixelRatio, int CssWidth, int CssHeight, IReadOnlyList<LocatedElement> Elements, string VisibleText,
    IReadOnlyList<string>? ControlNames = null);

/// <summary>
/// Browser automation for verifying applications under development, over the Chrome DevTools Protocol with a locally
/// installed Edge or Chrome. Each session runs a separate headless browser with a fresh, throwaway profile (so no
/// cookies, history or passwords of the user's own browser are ever visible), launched as an owned long-running
/// process through <see cref="CommandRunner"/>. Top-level navigations are intercepted: local development targets are
/// allowed, external sites only when that host was explicitly navigated to by an approved call, everything else is
/// blocked. JavaScript dialogs are dismissed and recorded.
/// </summary>
public sealed partial class BrowserService(
    CommandRunner runner,
    IJsonStore store,
    IOptionsMonitor<BrowserOptions> options,
    IOptions<DocGenOptions> docgen,
    ILogger<BrowserService> logger) : IHostedService, IAsyncDisposable
{
    private readonly ConcurrentDictionary<string, Session> _sessions = new(StringComparer.Ordinal);
    private Timer? _idle;

    private sealed class Tab
    {
        public required BrowserTabInfo Info { get; init; }
        public required string TargetId { get; init; }
        public required string CdpSessionId { get; init; }
        public readonly List<ConsoleEntry> Console = [];
        public readonly List<NetworkFailure> Network = [];
        public readonly ConcurrentDictionary<string, (string Url, string? Type)> Requests = new();
        public readonly Lock Sync = new();
    }

    private sealed class Session
    {
        public required BrowserSessionInfo Info { get; init; }
        public required CdpClient Cdp { get; init; }
        public required string ProfileDirectory { get; init; }
        public readonly List<Tab> Tabs = [];
        public readonly SemaphoreSlim Gate = new(1, 1);
        public int NextTab = 1;
    }

    public BrowserOptions Options => options.CurrentValue;

    private string SessionPath(string userId, string sessionId) => $"browser/{Ids.Require(userId, "user id")}/{Ids.Require(sessionId, "session id")}.json";

    // ------------------------------------------------------------------ sessions

    /// <summary>The user's open session, or a new one (headless browser + first tab).</summary>
    public async Task<BrowserSessionInfo> EnsureSessionAsync(string userId, string? runId, CancellationToken ct)
        => (await GetOrCreateAsync(userId, runId, ct)).Info;

    private async Task<Session> GetOrCreateAsync(string userId, string? runId, CancellationToken ct)
    {
        var existing = _sessions.Values.FirstOrDefault(s => s.Info.UserId == userId && s.Info.Status == "open" && s.Cdp.IsOpen);
        if (existing is not null)
        {
            existing.Info.LastUsedAt = DateTime.UtcNow;
            if (runId is not null)
            {
                existing.Info.RunId = runId;
            }
            return existing;
        }
        if (!Options.Enabled)
        {
            throw new DocGenException("BROWSER_DISABLED", "Browser automation is disabled (DocGen:Browser:Enabled).", 403);
        }
        if (_sessions.Values.Count(s => s.Info.UserId == userId) >= Math.Max(1, Options.MaxSessionsPerUser))
        {
            throw new DocGenException("BROWSER_LIMIT", "Too many browser sessions; close one first (browser_close).", 409);
        }
        return await LaunchAsync(userId, runId, ct);
    }

    public static string? LocateBrowser(BrowserOptions options)
    {
        if (options.ExecutablePath is { Length: > 0 } configured)
        {
            return File.Exists(configured) ? Path.GetFullPath(configured) : null;
        }
        var candidates = OperatingSystem.IsWindows()
            ? new[]
            {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Microsoft", "Edge", "Application", "msedge.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Microsoft", "Edge", "Application", "msedge.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Google", "Chrome", "Application", "chrome.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Google", "Chrome", "Application", "chrome.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Google", "Chrome", "Application", "chrome.exe"),
            }
            : ["/usr/bin/microsoft-edge", "/usr/bin/google-chrome", "/usr/bin/chromium", "/usr/bin/chromium-browser", "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"];
        return candidates.FirstOrDefault(File.Exists);
    }

    private async Task<Session> LaunchAsync(string userId, string? runId, CancellationToken ct)
    {
        var o = Options;
        var executable = LocateBrowser(o) ?? throw new DocGenException("BROWSER_NOT_FOUND", "No Chromium-based browser (Edge or Chrome) was found; set DocGen:Browser:ExecutablePath.", 404);
        var sessionId = "bs" + Ids.New()[..10];
        var profile = Path.Combine(Path.GetFullPath(docgen.Value.DataDirectory), "scratch", "browser", Ids.Require(userId, "user id"), sessionId);
        Directory.CreateDirectory(profile);
        var endpoint = new TaskCompletionSource<string>(TaskCreationOptions.RunContinuationsAsynchronously);
        var args = new List<string>
        {
            "--remote-debugging-port=0", "--remote-debugging-address=127.0.0.1", "--user-data-dir=" + profile, "--no-first-run", "--no-default-browser-check",
            "--disable-extensions", "--disable-sync", "--disable-background-networking", "--disable-component-update", "--disable-default-apps",
            "--disable-features=Translate,OptimizationHints,MediaRouter,AutofillServerCommunication", "--password-store=basic", "--mute-audio",
            "--disable-popup-blocking", $"--window-size={o.DefaultWidth},{o.DefaultHeight}", "about:blank",
        };
        if (o.Headless)
        {
            args.Insert(0, "--headless=new");
        }
        var command = await runner.StartProcessAsync(userId, new ProcessLaunch
        {
            Kind = CommandKinds.Browser, ExecutableName = Path.GetFileNameWithoutExtension(executable), ExecutablePath = executable, Arguments = args,
            WorkingDirectory = profile, DisplayWorkingDirectory = "(browser profile)", Repository = "(browser)", Description = "Browser for development verification",
            LongRunning = true, RunId = runId, Risk = "ReadOnly",
            OnOutput = line =>
            {
                if (DevToolsListening().Match(line) is { Success: true } m)
                {
                    endpoint.TrySetResult(m.Groups[1].Value);
                }
            },
        }, ct);

        var sw = Stopwatch.StartNew();
        string? ws = null;
        while (sw.Elapsed < TimeSpan.FromSeconds(30) && ws is null)
        {
            if (endpoint.Task.IsCompleted)
            {
                ws = endpoint.Task.Result;
                break;
            }
            var portFile = Path.Combine(profile, "DevToolsActivePort");
            if (File.Exists(portFile))
            {
                try
                {
                    var lines = await File.ReadAllLinesAsync(portFile, ct);
                    if (lines.Length >= 2 && int.TryParse(lines[0], out var port))
                    {
                        ws = $"ws://127.0.0.1:{port}{lines[1]}";
                        break;
                    }
                }
                catch (IOException)
                {
                }
            }
            if (!runner.IsActive(command.Id))
            {
                break;
            }
            await Task.Delay(100, ct);
        }
        if (ws is null)
        {
            await runner.CancelAsync(userId, command.Id, "browser did not expose a DevTools endpoint");
            throw new DocGenException("BROWSER_START_FAILED", "The browser started but did not expose a DevTools endpoint within 30 s.", 502);
        }
        var cdp = new CdpClient();
        await cdp.ConnectAsync(new Uri(ws), ct);
        var version = await cdp.SendAsync("Browser.getVersion", ct: ct);
        var info = new BrowserSessionInfo
        {
            SessionId = sessionId, UserId = userId, RunId = runId, CommandId = command.Id, WindowWidth = o.DefaultWidth, WindowHeight = o.DefaultHeight,
            Browser = version.TryGetProperty("product", out var product) ? product.GetString() ?? "Chromium" : "Chromium",
        };
        var session = new Session { Info = info, Cdp = cdp, ProfileDirectory = profile };
        cdp.Event += (method, cdpSession, parameters) => OnEvent(session, method, cdpSession, parameters);
        _sessions[sessionId] = session;

        // Adopt the initial about:blank page as tab-1.
        var targets = await cdp.SendAsync("Target.getTargets", ct: ct);
        var page = targets.GetProperty("targetInfos").EnumerateArray().FirstOrDefault(t => t.GetProperty("type").GetString() == "page");
        if (page.ValueKind == JsonValueKind.Object)
        {
            await AttachAsync(session, page.GetProperty("targetId").GetString()!, ct);
        }
        else
        {
            await NewTabAsync(session, ct);
        }
        await SaveAsync(session);
        logger.LogInformation("Browser session {SessionId} started for {UserId}: {Browser} (command {CommandId})", sessionId, userId, info.Browser, command.Id);
        return session;
    }

    private async Task<Tab> NewTabAsync(Session session, CancellationToken ct)
    {
        if (session.Tabs.Count(t => !t.Info.Closed) >= Math.Max(1, Options.MaxTabsPerSession))
        {
            throw new DocGenException("BROWSER_TAB_LIMIT", $"At most {Options.MaxTabsPerSession} tabs per session; close one first.", 409);
        }
        var created = await session.Cdp.SendAsync("Target.createTarget", new { url = "about:blank" }, ct: ct);
        return await AttachAsync(session, created.GetProperty("targetId").GetString()!, ct);
    }

    private async Task<Tab> AttachAsync(Session session, string targetId, CancellationToken ct)
    {
        var attached = await session.Cdp.SendAsync("Target.attachToTarget", new { targetId, flatten = true }, ct: ct);
        var cdpSession = attached.GetProperty("sessionId").GetString()!;
        var tab = new Tab { Info = new BrowserTabInfo { TabId = "tab-" + session.NextTab++ }, TargetId = targetId, CdpSessionId = cdpSession };
        session.Tabs.Add(tab);
        foreach (var domain in new[] { "Page.enable", "Runtime.enable", "Network.enable", "Log.enable" })
        {
            await session.Cdp.SendAsync(domain, sessionId: cdpSession, ct: ct);
        }
        await session.Cdp.SendAsync("Fetch.enable", new { patterns = new[] { new { urlPattern = "*", resourceType = "Document", requestStage = "Request" } } }, cdpSession, ct);
        session.Info.ActiveTabId = tab.Info.TabId;
        session.Info.Tabs.Add(tab.Info);
        return tab;
    }

    // ------------------------------------------------------------------ events

    private void OnEvent(Session session, string method, string? cdpSession, JsonElement p)
    {
        var tab = session.Tabs.FirstOrDefault(t => t.CdpSessionId == cdpSession);
        switch (method)
        {
            case "Runtime.consoleAPICalled" when tab is not null:
                var level = p.GetProperty("type").GetString() switch { "error" or "assert" => "error", "warning" => "warning", "info" => "info", "debug" => "debug", _ => "log" };
                var text = string.Join(" ", p.GetProperty("args").EnumerateArray().Select(a =>
                    a.TryGetProperty("value", out var v) ? v.ValueKind == JsonValueKind.String ? v.GetString() : v.GetRawText() : a.TryGetProperty("description", out var d) ? d.GetString() : a.GetProperty("type").GetString()));
                AddConsole(tab, new ConsoleEntry { Level = level, Source = "console", Text = text, Url = FirstFrameUrl(p) });
                break;
            case "Runtime.exceptionThrown" when tab is not null:
                var details = p.GetProperty("exceptionDetails");
                var message = details.TryGetProperty("exception", out var ex) && ex.TryGetProperty("description", out var desc) ? desc.GetString() : details.GetProperty("text").GetString();
                AddConsole(tab, new ConsoleEntry { Level = "error", Source = "exception", Text = message ?? "exception", Url = details.TryGetProperty("url", out var u) ? u.GetString() : null });
                break;
            case "Log.entryAdded" when tab is not null:
                var entry = p.GetProperty("entry");
                var l = entry.GetProperty("level").GetString();
                if (l is "error" or "warning")
                {
                    AddConsole(tab, new ConsoleEntry { Level = l, Source = entry.TryGetProperty("source", out var src) ? src.GetString() ?? "log" : "log", Text = entry.GetProperty("text").GetString() ?? "", Url = entry.TryGetProperty("url", out var eu) ? eu.GetString() : null });
                }
                break;
            case "Network.requestWillBeSent" when tab is not null:
                if (tab.Requests.Count < 2000)
                {
                    tab.Requests[p.GetProperty("requestId").GetString()!] = (p.GetProperty("request").GetProperty("url").GetString() ?? "", p.TryGetProperty("type", out var rt) ? rt.GetString() : null);
                }
                break;
            case "Network.responseReceived" when tab is not null:
                var response = p.GetProperty("response");
                var status = response.GetProperty("status").GetInt32();
                if (status >= 400)
                {
                    AddNetwork(tab, new NetworkFailure { Url = response.GetProperty("url").GetString() ?? "", Status = status, ResourceType = p.TryGetProperty("type", out var t2) ? t2.GetString() : null });
                }
                break;
            case "Network.loadingFailed" when tab is not null:
                if (p.TryGetProperty("canceled", out var canceled) && canceled.GetBoolean())
                {
                    break;
                }
                tab.Requests.TryGetValue(p.GetProperty("requestId").GetString()!, out var req);
                AddNetwork(tab, new NetworkFailure { Url = req.Url ?? "", Error = p.GetProperty("errorText").GetString(), ResourceType = p.TryGetProperty("type", out var t3) ? t3.GetString() : req.Type });
                break;
            case "Fetch.requestPaused" when tab is not null:
                _ = Task.Run(() => DecideNavigationAsync(session, tab, p));
                break;
            case "Page.frameNavigated" when tab is not null:
                var frame = p.GetProperty("frame");
                if (!frame.TryGetProperty("parentId", out _))
                {
                    tab.Info.Url = frame.GetProperty("url").GetString() + (frame.TryGetProperty("urlFragment", out var frag) ? frag.GetString() : "");
                }
                break;
            case "Page.navigatedWithinDocument" when tab is not null:
                tab.Info.Url = p.GetProperty("url").GetString() ?? tab.Info.Url;
                break;
            case "Page.javascriptDialogOpening" when tab is not null:
                AddConsole(tab, new ConsoleEntry { Level = "warning", Source = "dialog", Text = $"{p.GetProperty("type").GetString()} dialog dismissed by DocGen: {p.GetProperty("message").GetString()}" });
                _ = Task.Run(() => session.Cdp.SendAsync("Page.handleJavaScriptDialog", new { accept = false }, tab.CdpSessionId));
                break;
            case "Target.detachedFromTarget":
                var detached = session.Tabs.FirstOrDefault(t => p.TryGetProperty("sessionId", out var ds) && ds.GetString() == t.CdpSessionId);
                if (detached is not null)
                {
                    detached.Info.Closed = true;
                }
                break;
        }
    }

    private async Task DecideNavigationAsync(Session session, Tab tab, JsonElement p)
    {
        var requestId = p.GetProperty("requestId").GetString()!;
        var url = p.GetProperty("request").GetProperty("url").GetString() ?? "";
        try
        {
            var (cls, uri, reason) = BrowserUrlPolicy.Classify(url, Options);
            var allowed = cls == UrlClass.Local || cls == UrlClass.External && uri is not null && session.Info.AllowedExternalHosts.Contains(uri.Host, StringComparer.OrdinalIgnoreCase);
            if (allowed)
            {
                await session.Cdp.SendAsync("Fetch.continueRequest", new { requestId }, tab.CdpSessionId);
                return;
            }
            lock (tab.Sync)
            {
                if (session.Info.BlockedNavigations.Count < 50)
                {
                    session.Info.BlockedNavigations.Add($"{DateTime.UtcNow:HH:mm:ss} {Clip(url, 200)} ({reason ?? "external host not approved for this session"})");
                }
            }
            AddConsole(tab, new ConsoleEntry { Level = "warning", Source = "docgen", Text = $"DocGen blocked navigation to {Clip(url, 200)}: {reason ?? "external host not approved (use browser_navigate to request it)"}" });
            // Aborted keeps the tab on the current page (BlockedByClient would show an error page).
            await session.Cdp.SendAsync("Fetch.failRequest", new { requestId, errorReason = "Aborted" }, tab.CdpSessionId);
        }
        catch (Exception ex) when (ex is DocGenException or InvalidOperationException)
        {
            logger.LogDebug(ex, "Navigation decision failed");
        }
    }

    private static string? FirstFrameUrl(JsonElement p)
        => p.TryGetProperty("stackTrace", out var st) && st.TryGetProperty("callFrames", out var frames) && frames.GetArrayLength() > 0
            ? frames[0].GetProperty("url").GetString() : null;

    private static void AddConsole(Tab tab, ConsoleEntry entry)
    {
        entry.Text = DocGen.Security.SecretRedactor.Redact(Clip(entry.Text, 2000));
        lock (tab.Sync)
        {
            tab.Console.Add(entry);
            if (tab.Console.Count > 500)
            {
                tab.Console.RemoveRange(0, tab.Console.Count - 500);
            }
        }
    }

    private static void AddNetwork(Tab tab, NetworkFailure failure)
    {
        lock (tab.Sync)
        {
            tab.Network.Add(failure);
            if (tab.Network.Count > 300)
            {
                tab.Network.RemoveRange(0, tab.Network.Count - 300);
            }
        }
    }

    // ------------------------------------------------------------------ operations

    private async Task<T> WithTabAsync<T>(string userId, string? tabId, Func<Session, Tab, Task<T>> action, CancellationToken ct, bool create = false, string? runId = null)
    {
        var session = create ? await GetOrCreateAsync(userId, runId, ct) : _sessions.Values.FirstOrDefault(s => s.Info.UserId == userId && s.Info.Status == "open" && s.Cdp.IsOpen)
                      ?? throw new DocGenException("BROWSER_NO_SESSION", "No browser session is open. Start one with browser_open.", 409);
        await session.Gate.WaitAsync(ct);
        try
        {
            var id = tabId ?? session.Info.ActiveTabId;
            var tab = session.Tabs.FirstOrDefault(t => t.Info.TabId == id && !t.Info.Closed)
                      ?? throw new NotFoundException($"Tab '{id}'");
            session.Info.LastUsedAt = DateTime.UtcNow;
            var result = await action(session, tab);
            await RefreshTitleAsync(session, tab, ct);
            await SaveAsync(session);
            return result;
        }
        finally
        {
            session.Gate.Release();
        }
    }

    public async Task<BrowserTabInfo> OpenAsync(string userId, string? runId, string? url, bool newTab, CancellationToken ct)
    {
        var session = await GetOrCreateAsync(userId, runId, ct);
        await session.Gate.WaitAsync(ct);
        Tab tab;
        BrowserViewport? inherited = null;
        try
        {
            var active = session.Tabs.FirstOrDefault(t => t.Info.TabId == session.Info.ActiveTabId && !t.Info.Closed);
            var created = newTab || active is null || active.Info.Url != "about:blank" && newTab;
            // A new tab keeps the size the session was set to: screenshots of one guide must match in size.
            inherited = created ? (active?.Info.Viewport ?? session.Tabs.LastOrDefault(t => !t.Info.Closed && t.Info.Viewport is not null)?.Info.Viewport) : null;
            tab = created ? await NewTabAsync(session, ct) : active!;
            session.Info.ActiveTabId = tab.Info.TabId;
        }
        finally
        {
            session.Gate.Release();
        }
        if (inherited is not null)
        {
            await SetViewportAsync(userId, tab.Info.TabId, inherited, ct);
        }
        if (url is not null)
        {
            await NavigateAsync(userId, tab.Info.TabId, url, ct);
        }
        return tab.Info;
    }

    public Task<BrowserTabInfo> NavigateAsync(string userId, string? tabId, string url, CancellationToken ct)
        => WithTabAsync(userId, tabId, async (session, tab) =>
        {
            var (cls, uri, reason) = BrowserUrlPolicy.Classify(url, Options);
            if (cls == UrlClass.Forbidden)
            {
                throw new ForbiddenException($"Navigation to {Clip(url, 120)} is not allowed: {reason}.");
            }
            if (cls == UrlClass.External && uri is not null && !session.Info.AllowedExternalHosts.Contains(uri.Host, StringComparer.OrdinalIgnoreCase))
            {
                // Reaching here means the call was approved under BrowserExternal (the permission check happens before execution).
                session.Info.AllowedExternalHosts.Add(uri.Host);
            }
            var result = await session.Cdp.SendAsync("Page.navigate", new { url }, tab.CdpSessionId, ct, Options.NavigationTimeoutSeconds);
            if (result.TryGetProperty("errorText", out var error) && error.GetString() is { Length: > 0 } errorText)
            {
                throw new DocGenException("NAVIGATION_FAILED", $"Navigation to {Clip(url, 120)} failed: {errorText}", 502);
            }
            await WaitForLoadAsync(session, tab, ct);
            session.Info.ActiveTabId = tab.Info.TabId;
            return tab.Info;
        }, ct);

    public Task<BrowserTabInfo> HistoryAsync(string userId, string? tabId, string action, CancellationToken ct)
        => WithTabAsync(userId, tabId, async (session, tab) =>
        {
            if (action == "reload")
            {
                await session.Cdp.SendAsync("Page.reload", new { ignoreCache = true }, tab.CdpSessionId, ct);
            }
            else
            {
                var history = await session.Cdp.SendAsync("Page.getNavigationHistory", sessionId: tab.CdpSessionId, ct: ct);
                var index = history.GetProperty("currentIndex").GetInt32() + (action == "back" ? -1 : 1);
                var entries = history.GetProperty("entries");
                if (index < 0 || index >= entries.GetArrayLength())
                {
                    throw new ValidationException($"There is no page to go {action} to.");
                }
                var entry = entries[index];
                var (cls, _, reason) = BrowserUrlPolicy.Classify(entry.GetProperty("url").GetString() ?? "", Options);
                if (cls == UrlClass.Forbidden)
                {
                    throw new ForbiddenException("That history entry is not allowed: " + reason);
                }
                await session.Cdp.SendAsync("Page.navigateToHistoryEntry", new { entryId = entry.GetProperty("id").GetInt32() }, tab.CdpSessionId, ct);
            }
            await WaitForLoadAsync(session, tab, ct);
            return tab.Info;
        }, ct);

    private async Task WaitForLoadAsync(Session session, Tab tab, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        await Task.Delay(150, ct);
        while (sw.Elapsed < TimeSpan.FromSeconds(Options.NavigationTimeoutSeconds))
        {
            try
            {
                var state = await EvaluateAsync(session, tab, "document.readyState", ct);
                if (state.GetString() == "complete")
                {
                    await Task.Delay(250, ct); // let client-side rendering settle
                    return;
                }
            }
            catch (DocGenException)
            {
                // Context destroyed during navigation; try again.
            }
            await Task.Delay(150, ct);
        }
    }

    public Task<BrowserTabInfo> SetViewportAsync(string userId, string? tabId, BrowserViewport? viewport, CancellationToken ct)
        => WithTabAsync(userId, tabId, async (session, tab) =>
        {
            if (viewport is null)
            {
                await session.Cdp.SendAsync("Emulation.clearDeviceMetricsOverride", sessionId: tab.CdpSessionId, ct: ct);
                await session.Cdp.SendAsync("Emulation.setTouchEmulationEnabled", new { enabled = false }, tab.CdpSessionId, ct);
                tab.Info.Viewport = null;
            }
            else
            {
                await session.Cdp.SendAsync("Emulation.setDeviceMetricsOverride",
                    new { width = viewport.Width, height = viewport.Height, deviceScaleFactor = viewport.DeviceScaleFactor, mobile = viewport.Mobile }, tab.CdpSessionId, ct);
                await session.Cdp.SendAsync("Emulation.setTouchEmulationEnabled", new { enabled = viewport.Mobile, maxTouchPoints = viewport.Mobile ? 5 : 1 }, tab.CdpSessionId, ct);
                tab.Info.Viewport = viewport;
            }
            await Task.Delay(300, ct); // responsive layout recalculation
            return tab.Info;
        }, ct);

    public Task<PageSnapshot> ReadPageAsync(string userId, string? tabId, bool all, int maxLines, CancellationToken ct)
        => WithTabAsync(userId, tabId, async (session, tab) =>
        {
            var r = await EvaluateAsync(session, tab, PageScripts.Call($"H.snapshot('{(all ? "all" : "interactive")}', {maxLines})"), ct);
            return new PageSnapshot(r.GetProperty("title").GetString() ?? "", r.GetProperty("url").GetString() ?? "",
                r.GetProperty("lines").EnumerateArray().Select(l => l.GetString() ?? "").ToList(), r.GetProperty("truncated").GetBoolean(),
                r.GetProperty("scrollY").GetInt32(), r.GetProperty("height").GetInt32(), r.GetProperty("width").GetInt32(), r.GetProperty("viewportHeight").GetInt32());
        }, ct);

    public Task<string> ReadTextAsync(string userId, string? tabId, int maxChars, CancellationToken ct)
        => WithTabAsync(userId, tabId, async (session, tab) =>
        {
            var r = await EvaluateAsync(session, tab, "(document.body ? document.body.innerText : '')", ct);
            var text = r.GetString() ?? "";
            return text.Length > maxChars ? text[..maxChars] + $"\n…[{text.Length - maxChars:N0} more characters]" : text;
        }, ct);

    /// <summary>Describes a target element without acting on it (used for risk assessment before approval).</summary>
    public async Task<ElementInfo?> DescribeAsync(string userId, string? tabId, BrowserTarget target, CancellationToken ct)
    {
        var session = _sessions.Values.FirstOrDefault(s => s.Info.UserId == userId && s.Info.Status == "open" && s.Cdp.IsOpen);
        var tab = session?.Tabs.FirstOrDefault(t => t.Info.TabId == (tabId ?? session.Info.ActiveTabId) && !t.Info.Closed);
        if (session is null || tab is null)
        {
            return null;
        }
        var r = await EvaluateAsync(session, tab, PageScripts.Call($"H.describe(H.find({TargetJson(target)}))"), ct);
        return r.ValueKind == JsonValueKind.Object ? ToInfo(r) : null;
    }

    public string? CurrentUrl(string userId, string? tabId)
    {
        var session = _sessions.Values.FirstOrDefault(s => s.Info.UserId == userId && s.Info.Status == "open");
        return session?.Tabs.FirstOrDefault(t => t.Info.TabId == (tabId ?? session.Info.ActiveTabId))?.Info.Url;
    }

    public Task<ElementInfo> ClickAsync(string userId, string? tabId, BrowserTarget target, CancellationToken ct)
        => WithTabAsync(userId, tabId, async (session, tab) =>
        {
            var info = await PrepareElementAsync(session, tab, target, ct);
            var point = await EvaluateAsync(session, tab, PageScripts.Call($$"""
                (() => { const el = H.find({{TargetJson(target)}}); el.scrollIntoView({ block: 'center', inline: 'center' });
                  const r = el.getBoundingClientRect(); const x = r.left + r.width / 2, y = r.top + r.height / 2;
                  const top = document.elementFromPoint(x, y);
                  return { x, y, covered: !!top && top !== el && !el.contains(top) && !top.contains(el), by: top ? H.describe(top) : null }; })()
                """), ct);
            if (point.GetProperty("covered").GetBoolean())
            {
                var by = point.GetProperty("by");
                throw new DocGenException("ELEMENT_COVERED", $"{target} is covered by {(by.ValueKind == JsonValueKind.Object ? by.GetProperty("role").GetString() + " \"" + by.GetProperty("name").GetString() + "\"" : "another element")}; it was not clicked.", 409);
            }
            var x = point.GetProperty("x").GetDouble();
            var y = point.GetProperty("y").GetDouble();
            await session.Cdp.SendAsync("Input.dispatchMouseEvent", new { type = "mouseMoved", x, y }, tab.CdpSessionId, ct);
            await session.Cdp.SendAsync("Input.dispatchMouseEvent", new { type = "mousePressed", x, y, button = "left", clickCount = 1 }, tab.CdpSessionId, ct);
            await session.Cdp.SendAsync("Input.dispatchMouseEvent", new { type = "mouseReleased", x, y, button = "left", clickCount = 1 }, tab.CdpSessionId, ct);
            await Task.Delay(200, ct);
            await WaitForLoadAsync(session, tab, ct);
            return info;
        }, ct);

    public Task<ElementInfo> TypeAsync(string userId, string? tabId, BrowserTarget target, string text, bool clear, bool submit, CancellationToken ct)
        => WithTabAsync(userId, tabId, async (session, tab) =>
        {
            var info = await PrepareElementAsync(session, tab, target, ct);
            var focused = await EvaluateAsync(session, tab, PageScripts.Call($$"""
                (() => { const el = H.find({{TargetJson(target)}}); if (!H.editable(el)) return 'not editable';
                  el.scrollIntoView({ block: 'center' }); el.focus();
                  if ({{(clear ? "true" : "false")}}) { if ('value' in el) { el.value = ''; el.dispatchEvent(new Event('input', { bubbles: true })); } else if (el.isContentEditable) el.textContent = ''; }
                  return document.activeElement === el ? 'ok' : 'not focused'; })()
                """), ct);
            if (focused.GetString() != "ok")
            {
                throw new DocGenException("ELEMENT_NOT_EDITABLE", $"{target} resolved to {info.Role} \"{info.Name}\", which is {focused.GetString()}; nothing was typed.", 409);
            }
            await session.Cdp.SendAsync("Input.insertText", new { text }, tab.CdpSessionId, ct);
            if (submit)
            {
                await Key(session, tab, "Enter", ct);
                await Task.Delay(200, ct);
                await WaitForLoadAsync(session, tab, ct);
            }
            return info;
        }, ct);

    public Task<string> PressKeyAsync(string userId, string? tabId, string key, CancellationToken ct)
        => WithTabAsync(userId, tabId, async (session, tab) =>
        {
            await Key(session, tab, key, ct);
            await Task.Delay(150, ct);
            return key;
        }, ct);

    private static async Task Key(Session session, Tab tab, string key, CancellationToken ct)
    {
        var (code, vk, text) = key switch
        {
            "Enter" => ("Enter", 13, "\r"), "Tab" => ("Tab", 9, ""), "Escape" => ("Escape", 27, ""), "Backspace" => ("Backspace", 8, ""),
            "ArrowDown" => ("ArrowDown", 40, ""), "ArrowUp" => ("ArrowUp", 38, ""), "ArrowLeft" => ("ArrowLeft", 37, ""), "ArrowRight" => ("ArrowRight", 39, ""),
            "Space" => ("Space", 32, " "), "PageDown" => ("PageDown", 34, ""), "PageUp" => ("PageUp", 33, ""), "Home" => ("Home", 36, ""), "End" => ("End", 35, ""),
            _ => throw new ValidationException("Supported keys: Enter, Tab, Escape, Backspace, Space, Arrow keys, PageUp/PageDown, Home, End."),
        };
        var name = key == "Space" ? " " : key;
        await session.Cdp.SendAsync("Input.dispatchKeyEvent", new { type = text.Length > 0 ? "keyDown" : "rawKeyDown", key = name, code, windowsVirtualKeyCode = vk, text }, tab.CdpSessionId, ct);
        await session.Cdp.SendAsync("Input.dispatchKeyEvent", new { type = "keyUp", key = name, code, windowsVirtualKeyCode = vk }, tab.CdpSessionId, ct);
    }

    public Task<ElementInfo> SelectAsync(string userId, string? tabId, BrowserTarget target, string value, CancellationToken ct)
        => WithTabAsync(userId, tabId, async (session, tab) =>
        {
            var info = await PrepareElementAsync(session, tab, target, ct);
            var ok = await EvaluateAsync(session, tab, PageScripts.Call($$"""
                (() => { const el = H.find({{TargetJson(target)}}); if (el.tagName !== 'SELECT') return 'not a select element';
                  const want = {{JsonSerializer.Serialize(value)}};
                  const opt = [...el.options].find(o => o.value === want) || [...el.options].find(o => o.text.trim().toLowerCase() === want.toLowerCase());
                  if (!opt) return 'no option ' + want;
                  el.value = opt.value; el.dispatchEvent(new Event('input', { bubbles: true })); el.dispatchEvent(new Event('change', { bubbles: true })); return 'ok'; })()
                """), ct);
            if (ok.GetString() != "ok")
            {
                throw new ValidationException(ok.GetString() ?? "select failed");
            }
            return info;
        }, ct);

    public Task<string> ScrollAsync(string userId, string? tabId, BrowserTarget? target, string direction, int amount, CancellationToken ct)
        => WithTabAsync(userId, tabId, async (session, tab) =>
        {
            if (target is { IsEmpty: false })
            {
                await PrepareElementAsync(session, tab, target, ct);
                await EvaluateAsync(session, tab, PageScripts.Call($"(H.find({TargetJson(target)}).scrollIntoView({{ block: 'center' }}), true)"), ct);
            }
            else
            {
                var (dx, dy) = direction switch { "up" => (0, -amount), "left" => (-amount, 0), "right" => (amount, 0), "top" => (0, int.MinValue / 2), "bottom" => (0, int.MaxValue / 2), _ => (0, amount) };
                await EvaluateAsync(session, tab, $"(window.scrollBy({dx}, {dy}), true)", ct);
            }
            var pos = await EvaluateAsync(session, tab, "JSON.stringify({ y: Math.round(scrollY), h: document.documentElement.scrollHeight, vh: innerHeight })", ct);
            return pos.GetString() ?? "";
        }, ct);

    /// <summary>Waits for a condition: text present/absent, selector visible, URL containing a value, or the page load.</summary>
    public Task<(bool Met, string Detail)> WaitAsync(string userId, string? tabId, string kind, string? value, int timeoutSeconds, CancellationToken ct)
        => WithTabAsync(userId, tabId, async (session, tab) =>
        {
            var predicate = kind switch
            {
                "text" => $"(document.body && document.body.innerText.includes({JsonSerializer.Serialize(value ?? "")}))",
                "textGone" => $"!(document.body && document.body.innerText.includes({JsonSerializer.Serialize(value ?? "")}))",
                "selector" => PageScripts.Call($"H.visible(document.querySelector({JsonSerializer.Serialize(value ?? "")}))"),
                "url" => $"location.href.includes({JsonSerializer.Serialize(value ?? "")})",
                "load" => "document.readyState === 'complete'",
                _ => throw new ValidationException("wait kind must be text, textGone, selector, url or load."),
            };
            var sw = Stopwatch.StartNew();
            while (sw.Elapsed < TimeSpan.FromSeconds(timeoutSeconds))
            {
                try
                {
                    if ((await EvaluateAsync(session, tab, predicate, ct)).ValueKind == JsonValueKind.True)
                    {
                        return (true, $"condition met after {sw.ElapsedMilliseconds} ms");
                    }
                }
                catch (DocGenException)
                {
                }
                await Task.Delay(200, ct);
            }
            return (false, $"not met within {timeoutSeconds} s");
        }, ct);

    public Task<(byte[] Png, string Format)> ScreenshotAsync(string userId, string? tabId, bool fullPage, CancellationToken ct, bool allowJpeg = true)
        => WithTabAsync(userId, tabId, async (session, tab) =>
        {
            // A background tab gets no animation frames, so a page that is drawing (a graph, a chart) never produces the
            // frame captureScreenshot waits for: bring the tab to the front first.
            await session.Cdp.SendAsync("Page.bringToFront", sessionId: tab.CdpSessionId, ct: ct);
            object parameters = new { format = "png", captureBeyondViewport = fullPage };
            if (fullPage)
            {
                var metrics = await session.Cdp.SendAsync("Page.getLayoutMetrics", sessionId: tab.CdpSessionId, ct: ct);
                var size = metrics.GetProperty("cssContentSize");
                var height = Math.Min(size.GetProperty("height").GetDouble(), 12000);
                parameters = new { format = "png", captureBeyondViewport = true, clip = new { x = 0, y = 0, width = size.GetProperty("width").GetDouble(), height, scale = 1 } };
            }
            var shot = await session.Cdp.SendAsync("Page.captureScreenshot", parameters, tab.CdpSessionId, ct, 60);
            var bytes = Convert.FromBase64String(shot.GetProperty("data").GetString()!);
            if (bytes.Length > 1_400_000 && allowJpeg)
            {
                // Keep artifacts bounded: fall back to JPEG.
                shot = await session.Cdp.SendAsync("Page.captureScreenshot", new { format = "jpeg", quality = 70, captureBeyondViewport = fullPage }, tab.CdpSessionId, ct, 60);
                return (Convert.FromBase64String(shot.GetProperty("data").GetString()!), "jpeg");
            }
            return (bytes, "png");
        }, ct);

    /// <summary>
    /// Measures what a screenshot taken right now shows: each named target's box (ref_N, CSS selector or text=Label;
    /// the first visible match, preferring one inside the viewport) in screenshot pixels, and the visible text. Used to
    /// place annotations on real element positions and to check documentation against what the screen said.
    /// </summary>
    public Task<PageCapture> CaptureContextAsync(string userId, string? tabId, IReadOnlyDictionary<string, BrowserTarget> targets, bool fullPage, CancellationToken ct)
        => WithTabAsync(userId, tabId, async (session, tab) =>
        {
            var list = JsonSerializer.Serialize(targets.Select(t => new { name = t.Key, @ref = t.Value.Ref, selector = t.Value.Selector, text = t.Value.Text }));
            var r = await EvaluateAsync(session, tab, PageScripts.Call($$"""
                (() => {
                  const full = {{(fullPage ? "true" : "false")}}, dpr = window.devicePixelRatio || 1, vw = innerWidth, vh = innerHeight;
                  const docW = Math.max(document.documentElement.scrollWidth, vw), docH = Math.min(Math.max(document.documentElement.scrollHeight, vh), 12000);
                  const W = full ? docW : vw, Hh = full ? docH : vh;
                  const inView = (r) => r.bottom > 0 && r.top < vh && r.right > 0 && r.left < vw;
                  const named = () => [...document.querySelectorAll('a,button,summary,label,input:not([type=hidden]),textarea,select,[role],h1,h2,h3,h4,nav,main,header,footer,aside,form,dialog,section[aria-label],table,img')].filter(H.visible);
                  const pick = (t) => {
                    if (t.selector && !t.ref) {
                      // role "Name" — the notation browser_read_page prints — is matched by role and accessible name.
                      const rn = /^([a-z]+)\s+["'“](.+)["'”]$/i.exec(t.selector.trim());
                      if (rn) {
                        const want = rn[2].trim().toLowerCase(), all = named().filter(e => H.role(e) === rn[1].toLowerCase());
                        return all.find(e => H.name(e).toLowerCase() === want) || all.find(e => H.name(e).toLowerCase().startsWith(want)) || null;
                      }
                      const all = [...document.querySelectorAll(t.selector)].filter(H.visible); return all.find(e => full || inView(e.getBoundingClientRect())) || all[0] || null;
                    }
                    return H.find(t);
                  };
                  // For a target that was not found: the visible elements whose names share the most words with it.
                  const suggest = (t) => {
                    const words = String(t.text || t.selector || '').toLowerCase().split(/[^a-z0-9]+/).filter(w => w.length > 2);
                    if (!words.length) return [];
                    return named().map(e => ({ e, n: H.name(e) })).filter(x => x.n && x.n.length < 80)
                      .map(x => ({ ...x, s: words.filter(w => x.n.toLowerCase().includes(w)).length })).filter(x => x.s > 0)
                      .sort((a, b) => b.s - a.s).slice(0, 3).map(x => H.role(x.e) + ' "' + x.n + '"' + (x.e.id ? ' #' + x.e.id : ''));
                  };
                  const elements = [];
                  for (const t of {{list}}) {
                    let el = null; try { el = pick(t); } catch (e) { el = null; }
                    const locator = t.ref || (t.selector ? t.selector : 'text=' + t.text);
                    if (!el || !H.visible(el)) { elements.push({ name: t.name, locator, found: false, suggestions: suggest(t) }); continue; }
                    const r = el.getBoundingClientRect();
                    let x0 = r.left + (full ? scrollX : 0), y0 = r.top + (full ? scrollY : 0), x1 = x0 + r.width, y1 = y0 + r.height;
                    const cx0 = Math.max(0, x0), cy0 = Math.max(0, y0), cx1 = Math.min(W, x1), cy1 = Math.min(Hh, y1);
                    if (cx1 <= cx0 || cy1 <= cy0) { elements.push({ name: t.name, locator, found: false, role: H.role(el), label: H.name(el) }); continue; }
                    elements.push({ name: t.name, locator, found: true, x: Math.round(cx0 * dpr), y: Math.round(cy0 * dpr), width: Math.round((cx1 - cx0) * dpr), height: Math.round((cy1 - cy0) * dpr),
                                    role: H.role(el), label: H.name(el), partly: cx0 !== x0 || cy0 !== y0 || cx1 !== x1 || cy1 !== y1 });
                  }
                  // Text a reader can see in the shot: text nodes of visible elements inside the captured area.
                  const parts = []; let size = 0;
                  const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT);
                  for (let n = walker.nextNode(); n && size < 30000; n = walker.nextNode()) {
                    const s = n.textContent.replace(/\s+/g, ' ').trim(); if (!s || !n.parentElement || !H.visible(n.parentElement)) continue;
                    const range = document.createRange(); range.selectNodeContents(n); const rr = range.getBoundingClientRect();
                    if (!full && !inView(rr)) continue;
                    if (!full && rr.width > 0 && rr.height > 0) {
                      // Really on screen: not inside a closed menu, a clipped panel or under an overlay.
                      const cx = Math.min(vw - 1, Math.max(0, rr.left + Math.min(rr.width, 40) / 2)), cy = Math.min(vh - 1, Math.max(0, rr.top + rr.height / 2));
                      const top = document.elementFromPoint(cx, cy), host = n.parentElement;
                      let near = false; for (let a = host, i = 0; a && i < 4; a = a.parentElement, i++) if (a === top) near = true;
                      if (!top || !(near || host.contains(top))) continue;
                    }
                    parts.push(s); size += s.length + 1;
                  }
                  // Form values and placeholders are on screen too.
                  for (const f of document.querySelectorAll('input,textarea,select')) {
                    if (!H.visible(f) || f.type === 'password' || (!full && !inView(f.getBoundingClientRect()))) continue;
                    const v = f.tagName === 'SELECT' ? (f.selectedOptions[0] || {}).text : (f.value || f.getAttribute('placeholder'));
                    if (v) parts.push(String(v).slice(0, 200));
                  }
                  // Accessible names of the controls on screen: an icon button shows no text but has a name (its tooltip).
                  const controls = [];
                  for (const el of document.querySelectorAll('a,button,summary,select,input:not([type=hidden]),textarea,[role=button],[role=tab],[role=link],[role=menuitem],[role=switch],[title]')) {
                    if (!H.visible(el)) continue; const r = el.getBoundingClientRect(); if (!full && !inView(r)) continue;
                    const nm = H.name(el); if (nm && nm.length < 100 && !controls.includes(nm)) controls.push(nm);
                    const tt = el.getAttribute('title'); if (tt && tt.length < 100 && !controls.includes(tt)) controls.push(tt);
                  }
                  return { url: location.href, title: document.title, dpr, cssWidth: W, cssHeight: Hh, elements, text: parts.join('\n'), controls };
                })()
                """), ct);
            var elements = r.GetProperty("elements").EnumerateArray().Select(e => new LocatedElement(
                e.GetProperty("name").GetString() ?? "", e.GetProperty("locator").GetString() ?? "", e.GetProperty("found").GetBoolean(),
                Int(e, "x"), Int(e, "y"), Int(e, "width"), Int(e, "height"), Str(e, "role"), Str(e, "label"), e.TryGetProperty("partly", out var p) && p.GetBoolean(),
                e.TryGetProperty("suggestions", out var sg) && sg.ValueKind == JsonValueKind.Array ? sg.EnumerateArray().Select(x => x.GetString() ?? "").ToList() : null)).ToList();
            return new PageCapture(r.GetProperty("url").GetString() ?? "", r.GetProperty("title").GetString() ?? "", r.GetProperty("dpr").GetDouble(),
                (int)r.GetProperty("cssWidth").GetDouble(), (int)r.GetProperty("cssHeight").GetDouble(), elements, r.GetProperty("text").GetString() ?? "",
                r.TryGetProperty("controls", out var cs) && cs.ValueKind == JsonValueKind.Array ? cs.EnumerateArray().Select(x => x.GetString() ?? "").ToList() : []);

            static int Int(JsonElement e, string name) => e.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.Number ? (int)Math.Round(v.GetDouble()) : 0;
            static string? Str(JsonElement e, string name) => e.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;
        }, ct);

    public Task<(List<ConsoleEntry> Console, List<NetworkFailure> Network)> DiagnosticsAsync(string userId, string? tabId, bool clear, CancellationToken ct)
        => WithTabAsync(userId, tabId, (session, tab) =>
        {
            lock (tab.Sync)
            {
                var result = (tab.Console.ToList(), tab.Network.ToList());
                if (clear)
                {
                    tab.Console.Clear();
                    tab.Network.Clear();
                }
                return Task.FromResult(result);
            }
        }, ct);

    public sealed record LayoutMetrics(int ScrollWidth, int ViewportWidth, int ClientWidth, string Widest);

    /// <summary>Document width vs viewport width and the widest element that sticks out (for overflow checks).</summary>
    public Task<LayoutMetrics> EvaluateMetricsAsync(string userId, string? tabId, CancellationToken ct)
        => WithTabAsync(userId, tabId, async (session, tab) =>
        {
            var r = await EvaluateAsync(session, tab, PageScripts.Call("""
                (() => { const vw = document.documentElement.clientWidth; let widest = '', max = vw;
                  for (const el of document.querySelectorAll('body *')) { const r = el.getBoundingClientRect(); if (r.right > max + 1 && H.visible(el)) { max = r.right; widest = el.tagName.toLowerCase() + (el.id ? '#' + el.id : '') + (el.className && typeof el.className === 'string' ? '.' + el.className.trim().split(/\s+/).slice(0, 2).join('.') : ''); } }
                  return { scrollWidth: document.documentElement.scrollWidth, viewportWidth: innerWidth, clientWidth: vw, widest }; })()
                """), ct);
            return new LayoutMetrics(r.GetProperty("scrollWidth").GetInt32(), r.GetProperty("viewportWidth").GetInt32(), r.GetProperty("clientWidth").GetInt32(), r.GetProperty("widest").GetString() ?? "");
        }, ct);

    /// <summary>Heuristic sidebar state: a visible element named/classed "sidebar" (or the first aside/nav) inside the viewport.</summary>
    public Task<string> SidebarStateAsync(string userId, string? tabId, CancellationToken ct)
        => WithTabAsync(userId, tabId, async (session, tab) =>
        {
            var r = await EvaluateAsync(session, tab, PageScripts.Call("""
                (() => { const el = document.querySelector('[class*=sidebar],[id*=sidebar],aside,nav'); if (!el) return 'hidden (no sidebar element found)';
                  const rect = el.getBoundingClientRect(); const on = H.visible(el) && rect.right > 4 && rect.left < innerWidth - 4;
                  return (on ? 'visible' : 'hidden') + ' (' + el.tagName.toLowerCase() + (el.className ? '.' + String(el.className).split(' ')[0] : '') + ', ' + Math.round(rect.left) + '..' + Math.round(rect.right) + 'px)'; })()
                """), ct);
            return r.GetString() ?? "unknown";
        }, ct);

    /// <summary>The browser's own automatic favicon request is not an application error.</summary>
    public static bool IsNoise(string? url, string? text)
        => url is not null && url.EndsWith("/favicon.ico", StringComparison.OrdinalIgnoreCase);

    public IReadOnlyList<BrowserTabInfo> ListTabs(string userId, out BrowserSessionInfo? session)
    {
        var s = _sessions.Values.FirstOrDefault(x => x.Info.UserId == userId && x.Info.Status == "open");
        session = s?.Info;
        return s?.Tabs.Where(t => !t.Info.Closed).Select(t => t.Info).ToList() ?? [];
    }

    public BrowserTabInfo SelectTab(string userId, string tabId)
    {
        var s = _sessions.Values.FirstOrDefault(x => x.Info.UserId == userId && x.Info.Status == "open") ?? throw new DocGenException("BROWSER_NO_SESSION", "No browser session is open.", 409);
        var tab = s.Tabs.FirstOrDefault(t => t.Info.TabId == tabId && !t.Info.Closed) ?? throw new NotFoundException($"Tab '{tabId}'");
        s.Info.ActiveTabId = tab.Info.TabId;
        _ = s.Cdp.SendAsync("Target.activateTarget", new { targetId = tab.TargetId });
        return tab.Info;
    }

    /// <summary>Closes a tab, or the whole session (browser process tree killed) when tabId is null.</summary>
    public async Task<string> CloseAsync(string userId, string? tabId, CancellationToken ct)
    {
        var s = _sessions.Values.FirstOrDefault(x => x.Info.UserId == userId && x.Info.Status == "open") ?? throw new DocGenException("BROWSER_NO_SESSION", "No browser session is open.", 409);
        if (tabId is not null)
        {
            var tab = s.Tabs.FirstOrDefault(t => t.Info.TabId == tabId && !t.Info.Closed) ?? throw new NotFoundException($"Tab '{tabId}'");
            await s.Cdp.SendAsync("Target.closeTarget", new { targetId = tab.TargetId }, ct: ct);
            tab.Info.Closed = true;
            s.Info.ActiveTabId = s.Tabs.LastOrDefault(t => !t.Info.Closed)?.Info.TabId;
            await SaveAsync(s);
            return $"Closed {tabId}.";
        }
        await CloseSessionAsync(s, "closed by browser_close");
        return $"Closed browser session {s.Info.SessionId} ({s.Tabs.Count} tabs); the browser process tree was stopped.";
    }

    private async Task CloseSessionAsync(Session s, string reason)
    {
        s.Info.Status = "closed";
        s.Info.ClosedReason = reason;
        foreach (var t in s.Tabs)
        {
            t.Info.Closed = true;
        }
        try
        {
            await s.Cdp.SendAsync("Browser.close", timeoutSeconds: 5);
        }
        catch (DocGenException)
        {
        }
        await s.Cdp.DisposeAsync();
        await runner.CancelAsync(s.Info.UserId, s.Info.CommandId, "browser session closed");
        await runner.WaitAsync(s.Info.UserId, s.Info.CommandId, TimeSpan.FromSeconds(10), CancellationToken.None, cancelOnAbort: false);
        _sessions.TryRemove(s.Info.SessionId, out _);
        await SaveAsync(s);
        TryDeleteDirectory(s.ProfileDirectory);
    }

    /// <summary>Open sessions of a user (for compaction snapshots and Run Details).</summary>
    public IReadOnlyList<BrowserSessionInfo> OpenSessions(string userId)
        => _sessions.Values.Where(s => s.Info.UserId == userId && s.Info.Status == "open").Select(s => s.Info).ToList();

    // ------------------------------------------------------------------ helpers

    private async Task<ElementInfo> PrepareElementAsync(Session session, Tab tab, BrowserTarget target, CancellationToken ct)
    {
        if (target.IsEmpty)
        {
            throw new ValidationException("Give ref (from browser_read_page), selector or text.");
        }
        var r = await EvaluateAsync(session, tab, PageScripts.Call($"H.describe(H.find({TargetJson(target)}))"), ct);
        if (r.ValueKind != JsonValueKind.Object)
        {
            throw new NotFoundException($"Element {target} (it may have changed; read the page again)");
        }
        var info = ToInfo(r);
        if (!info.Visible)
        {
            throw new DocGenException("ELEMENT_HIDDEN", $"Element {target} ({info.Role} \"{info.Name}\") is not visible.", 409);
        }
        if (info.Disabled)
        {
            throw new DocGenException("ELEMENT_DISABLED", $"Element {target} ({info.Role} \"{info.Name}\") is disabled.", 409);
        }
        return info;
    }

    private static ElementInfo ToInfo(JsonElement r) => new(
        r.GetProperty("ref").GetString() ?? "", r.GetProperty("role").GetString() ?? "", r.GetProperty("name").GetString() ?? "", r.GetProperty("tag").GetString() ?? "",
        r.TryGetProperty("href", out var h) && h.ValueKind == JsonValueKind.String ? h.GetString() : null, r.GetProperty("visible").GetBoolean(),
        r.GetProperty("sensitive").EnumerateArray().Select(x => x.GetString() ?? "").ToList(), r.GetProperty("disabled").GetBoolean());

    private static string TargetJson(BrowserTarget t) => JsonSerializer.Serialize(new { @ref = t.Ref, selector = t.Selector, text = t.Text });

    private static async Task<JsonElement> EvaluateAsync(Session session, Tab tab, string expression, CancellationToken ct)
    {
        var result = await session.Cdp.SendAsync("Runtime.evaluate", new { expression, returnByValue = true, awaitPromise = true, userGesture = true }, tab.CdpSessionId, ct);
        if (result.TryGetProperty("exceptionDetails", out var ex))
        {
            var text = ex.TryGetProperty("exception", out var e) && e.TryGetProperty("description", out var d) ? d.GetString() : ex.GetProperty("text").GetString();
            throw new DocGenException("PAGE_SCRIPT_ERROR", "Page evaluation failed: " + Clip(text ?? "error", 300), 409);
        }
        return result.GetProperty("result").TryGetProperty("value", out var value) ? value : default;
    }

    private static async Task RefreshTitleAsync(Session session, Tab tab, CancellationToken ct)
    {
        try
        {
            var info = await session.Cdp.SendAsync("Target.getTargetInfo", new { targetId = tab.TargetId }, ct: ct, timeoutSeconds: 5);
            var target = info.GetProperty("targetInfo");
            tab.Info.Title = target.GetProperty("title").GetString() ?? "";
            tab.Info.Url = target.GetProperty("url").GetString() ?? tab.Info.Url;
        }
        catch (DocGenException)
        {
        }
    }

    private async Task SaveAsync(Session session)
    {
        try
        {
            await store.WriteAsync(SessionPath(session.Info.UserId, session.Info.SessionId), session.Info, CancellationToken.None);
        }
        catch (StorageException ex)
        {
            logger.LogWarning(ex, "Could not persist browser session {SessionId}", session.Info.SessionId);
        }
    }

    private static void TryDeleteDirectory(string path)
    {
        try
        {
            if (Directory.Exists(path))
            {
                Directory.Delete(path, recursive: true);
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            // Browser still releasing files; retention removes old scratch profiles.
        }
    }

    private static string Clip(string text, int max) => text.Length > max ? text[..max] + "…" : text;

    // ------------------------------------------------------------------ hosting

    /// <summary>Startup: sessions persisted by a previous process are closed (their browsers were killed by command reconciliation).</summary>
    public async Task<int> ReconcileAsync(CancellationToken ct = default)
    {
        var count = 0;
        foreach (var userDir in store.EnumerateDirectories("browser"))
        {
            foreach (var path in store.EnumerateDocuments($"browser/{userDir}"))
            {
                try
                {
                    if (await store.ReadAsync<BrowserSessionInfo>(path, ct) is { Status: "open" } info && !_sessions.ContainsKey(info.SessionId))
                    {
                        info.Status = "closed";
                        info.ClosedReason = "DocGen restarted; the browser was stopped.";
                        foreach (var t in info.Tabs)
                        {
                            t.Closed = true;
                        }
                        await store.WriteAsync(path, info, ct);
                        count++;
                    }
                }
                catch (StorageException)
                {
                }
            }
        }
        return count;
    }

    public async Task StartAsync(CancellationToken cancellationToken)
    {
        await ReconcileAsync(cancellationToken);
        _idle = new Timer(_ => _ = CloseIdleAsync(), null, TimeSpan.FromMinutes(1), TimeSpan.FromMinutes(1));
    }

    private async Task CloseIdleAsync()
    {
        foreach (var s in _sessions.Values.Where(s => DateTime.UtcNow - s.Info.LastUsedAt > TimeSpan.FromMinutes(30) || !s.Cdp.IsOpen).ToList())
        {
            try
            {
                await CloseSessionAsync(s, s.Cdp.IsOpen ? "idle for 30 minutes" : "browser connection lost");
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Could not close idle browser session {SessionId}", s.Info.SessionId);
            }
        }
    }

    /// <summary>Closes every browser session (e.g. before a reset); new sessions can still be opened afterwards.</summary>
    public async Task CloseAllSessionsAsync(string reason)
    {
        foreach (var s in _sessions.Values.ToList())
        {
            try
            {
                await CloseSessionAsync(s, reason);
            }
            catch (Exception ex)
            {
                logger.LogDebug(ex, "Closing browser session {SessionId}", s.Info.SessionId);
            }
        }
    }

    public async Task StopAsync(CancellationToken cancellationToken)
    {
        _idle?.Dispose();
        foreach (var s in _sessions.Values.ToList())
        {
            try
            {
                await CloseSessionAsync(s, "DocGen is shutting down");
            }
            catch (Exception ex)
            {
                logger.LogDebug(ex, "Browser shutdown");
            }
        }
    }

    public async ValueTask DisposeAsync() => await StopAsync(CancellationToken.None);

    [GeneratedRegex(@"DevTools listening on (ws://\S+)")]
    private static partial Regex DevToolsListening();
}
