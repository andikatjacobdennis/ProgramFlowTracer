using System.Net;
using DocGen.Core.Options;

namespace DocGen.Analysis.Browser;

public sealed class BrowserViewport
{
    /// <summary>mobile | tablet | desktop | custom</summary>
    public string Preset { get; set; } = "custom";

    public int Width { get; set; }
    public int Height { get; set; }
    public bool Mobile { get; set; }
    public double DeviceScaleFactor { get; set; } = 1;

    public override string ToString() => $"{Preset} {Width}×{Height}{(Mobile ? " (mobile, touch)" : "")}";

    public static readonly IReadOnlyDictionary<string, BrowserViewport> Presets = new Dictionary<string, BrowserViewport>(StringComparer.OrdinalIgnoreCase)
    {
        ["mobile"] = new() { Preset = "mobile", Width = 390, Height = 844, Mobile = true, DeviceScaleFactor = 2 },
        ["tablet"] = new() { Preset = "tablet", Width = 768, Height = 1024, Mobile = true, DeviceScaleFactor = 1 },
        ["desktop"] = new() { Preset = "desktop", Width = 1440, Height = 900, Mobile = false, DeviceScaleFactor = 1 },
    };
}

public sealed class ConsoleEntry
{
    /// <summary>error | warning | info | log | debug</summary>
    public string Level { get; set; } = "log";

    /// <summary>console | exception | network | log</summary>
    public string Source { get; set; } = "console";

    public string Text { get; set; } = "";
    public string? Url { get; set; }
    public DateTime At { get; set; } = DateTime.UtcNow;
}

public sealed class NetworkFailure
{
    public string Url { get; set; } = "";
    public int? Status { get; set; }
    public string? Error { get; set; }
    public string? ResourceType { get; set; }
    public DateTime At { get; set; } = DateTime.UtcNow;
}

/// <summary>Persisted, externally meaningful tab state (no page content).</summary>
public sealed class BrowserTabInfo
{
    public string TabId { get; set; } = "";
    public string Url { get; set; } = "about:blank";
    public string Title { get; set; } = "";

    /// <summary>Null when no viewport emulation is active (the browser window's own size applies).</summary>
    public BrowserViewport? Viewport { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public bool Closed { get; set; }
}

/// <summary>Persisted browser session (data/browser/{userId}/{sessionId}.json).</summary>
public sealed class BrowserSessionInfo
{
    public string SessionId { get; set; } = "";
    public string UserId { get; set; } = "";
    public string? RunId { get; set; }
    public string CommandId { get; set; } = "";
    public string Browser { get; set; } = "";
    public string? ActiveTabId { get; set; }
    public List<BrowserTabInfo> Tabs { get; set; } = [];

    /// <summary>open | closed</summary>
    public string Status { get; set; } = "open";

    public int WindowWidth { get; set; }
    public int WindowHeight { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime LastUsedAt { get; set; } = DateTime.UtcNow;
    public List<string> AllowedExternalHosts { get; set; } = [];
    public List<string> BlockedNavigations { get; set; } = [];
    public string? ClosedReason { get; set; }
}

public enum UrlClass
{
    Local,
    External,
    Forbidden,
}

/// <summary>
/// Where the browser may go. Local development targets (loopback, localhost, *.localhost, *.test, configured hosts)
/// need BrowserLocal; public http(s) sites need BrowserExternal and pass the same SSRF rules as the HTTP tool;
/// file:, data:, javascript:, chrome: and private network addresses are refused.
/// </summary>
public static class BrowserUrlPolicy
{
    public static (UrlClass Class, Uri? Uri, string? Reason) Classify(string url, BrowserOptions options)
    {
        if (url == "about:blank")
        {
            return (UrlClass.Local, new Uri("about:blank"), null);
        }
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri))
        {
            return (UrlClass.Forbidden, null, "not an absolute URL");
        }
        if (uri.Scheme is not ("http" or "https"))
        {
            return (UrlClass.Forbidden, uri, $"the {uri.Scheme}: scheme is not allowed");
        }
        if (IsLocal(uri, options))
        {
            return (UrlClass.Local, uri, null);
        }
        if (IPAddress.TryParse(uri.Host.Trim('[', ']'), out var ip) && DocGen.Security.NetworkDestinationValidator.IsBlocked(ip))
        {
            return (UrlClass.Forbidden, uri, "private or reserved network address");
        }
        return (UrlClass.External, uri, null);
    }

    public static bool IsLocal(Uri uri, BrowserOptions options)
        => uri.IsLoopback
           || uri.Host.Equals("localhost", StringComparison.OrdinalIgnoreCase)
           || uri.Host.EndsWith(".localhost", StringComparison.OrdinalIgnoreCase)
           || uri.Host.EndsWith(".test", StringComparison.OrdinalIgnoreCase)
           || options.LocalHosts.Contains(uri.Host, StringComparer.OrdinalIgnoreCase);
}
