using System.Collections.Concurrent;
using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;
using DocGen.Analysis.Diagnostics;
using DocGen.Analysis.Repositories;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Core.Options;
using DocGen.Data.Storage;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Commands;

/// <summary>
/// Runs long build/test commands asynchronously with bounded concurrency. Output streams to a log file on disk (the
/// full output is kept up to a size cap; the model only ever sees summaries and tails), a heartbeat is persisted every
/// few seconds, and timeouts, user cancellation, run cancellation and shutdown kill the whole process tree.
/// <para>
/// Security: only allow-listed executables run (dotnet), arguments are built by DocGen from validated structured
/// input (never a shell string), the working directory is a repository root, and secret-looking environment
/// variables are removed from the child environment. Starting a command is approval-gated at the tool level.
/// </para>
/// </summary>
public sealed partial class CommandRunner(
    IJsonStore store,
    IOptionsMonitor<AnalysisOptions> options,
    ILogger<CommandRunner> logger,
    IOptionsMonitor<ExecutionOptions>? execution = null) : IHostedService, DocGen.Analysis.Execution.IProcessRunner
{
    private ExecutionOptions ExecutionSettings => execution?.CurrentValue ?? DefaultExecution;
    private static readonly ExecutionOptions DefaultExecution = new();

    private const int TailLines = 60;
    private static readonly TimeSpan HeartbeatInterval = TimeSpan.FromSeconds(5);

    private readonly ConcurrentDictionary<string, Active> _active = new(StringComparer.Ordinal);
    private SemaphoreSlim? _slots;
    private volatile bool _stopping;

    private sealed class Active
    {
        public required CommandRecord Record { get; init; }
        public required CancellationTokenSource Cancellation { get; init; }
        public TaskCompletionSource Completed { get; } = new(TaskCreationOptions.RunContinuationsAsynchronously);
        public Process? Process { get; set; }
        public string? Reason { get; set; }
        public readonly object Sync = new();
        public long LinesWritten;
        public bool LogClosed;
        public required ProcessLaunch Launch { get; init; }
        public required DocGen.Analysis.Execution.OutputRedactor Redactor { get; set; }
        public event Action? Changed;
        public void Notify() => Changed?.Invoke();
    }

    private SemaphoreSlim Slots => _slots ??= new SemaphoreSlim(Math.Max(1, options.CurrentValue.MaxConcurrentCommands));

    public static string DirectoryFor(string userId) => $"commands/{Ids.Require(userId, "user id")}";

    private static string RecordPath(string userId, string id) => $"{DirectoryFor(userId)}/{Ids.Require(id)}.json";

    public string LogPath(string userId, string id) => Path.Combine(store.RootDirectory, "commands", Ids.Require(userId, "user id"), Ids.Require(id) + ".log");

    /// <summary>Validates and queues a command. Returns immediately; use <see cref="WaitAsync"/> to wait (bounded).</summary>
    public async Task<CommandRecord> StartAsync(string userId, RepositoryHandle repo, CommandRequest request, CancellationToken ct)
    {
        if (_stopping)
        {
            throw new DocGenException("SHUTTING_DOWN", "DocGen is shutting down and is not starting new commands.", 503);
        }
        if (!repo.AllowCommands)
        {
            throw new ForbiddenException($"Commands are not enabled for repository '{repo.Name}'.");
        }
        if (!CommandKinds.IsValid(request.Kind))
        {
            throw new ValidationException("Unknown command kind.");
        }
        var opts = options.CurrentValue;
        var executable = ResolveExecutable(opts);
        var arguments = BuildArguments(repo, request);
        var timeout = Math.Clamp(request.TimeoutSeconds ?? opts.CommandTimeoutSeconds, 10, Math.Max(10, opts.CommandTimeoutSeconds));
        return await StartLaunchAsync(userId, new ProcessLaunch
        {
            Kind = request.Kind, ExecutableName = "dotnet", ExecutablePath = executable, Arguments = arguments, WorkingDirectory = repo.Root,
            Repository = repo.Name, TimeoutSeconds = timeout, RunId = request.RunId, ConversationId = request.ConversationId,
            ParseAs = request.Kind is CommandKinds.Test ? CommandKinds.Test : request.Kind is CommandKinds.Packages ? null : CommandKinds.Build,
        }, record =>
        {
            record.Target = request.Target;
            record.Filter = request.Filter;
        }, ct);
    }

    /// <summary>
    /// Starts a validated process (PowerShell, git, an allow-listed executable, a development server or a browser)
    /// through the same infrastructure as build/test commands: persisted record, live output log, heartbeat,
    /// cancellation, process-tree kill, crash reconciliation and output redaction.
    /// </summary>
    public Task<CommandRecord> StartProcessAsync(string userId, ProcessLaunch launch, CancellationToken ct)
    {
        if (!CommandKinds.IsKnown(launch.Kind))
        {
            throw new ValidationException("Unknown command kind.");
        }
        if (!Path.IsPathFullyQualified(launch.WorkingDirectory) || !Directory.Exists(launch.WorkingDirectory))
        {
            throw new ValidationException("The working directory must be an existing absolute directory.");
        }
        if (!Path.IsPathFullyQualified(launch.ExecutablePath) || !File.Exists(launch.ExecutablePath))
        {
            throw new ValidationException("The executable must be resolved to an existing file.");
        }
        return StartLaunchAsync(userId, launch, null, ct);
    }

    private async Task<CommandRecord> StartLaunchAsync(string userId, ProcessLaunch launch, Action<CommandRecord>? configure, CancellationToken ct)
    {
        if (_stopping)
        {
            throw new DocGenException("SHUTTING_DOWN", "DocGen is shutting down and is not starting new commands.", 503);
        }
        var exec = ExecutionSettings;
        var timeout = launch.LongRunning && launch.TimeoutSeconds is null
            ? 0
            : Math.Clamp(launch.TimeoutSeconds ?? exec.DefaultTimeoutSeconds, 5, Math.Max(10, Math.Max(exec.MaxTimeoutSeconds, options.CurrentValue.CommandTimeoutSeconds)));

        // Validate the environment before anything is persisted (invalid overrides fail fast).
        var overrides = DocGen.Analysis.Execution.EnvironmentPolicy.ValidateOverrides(launch.Environment);
        var redactor = new DocGen.Analysis.Execution.OutputRedactor();
        var display = launch.DisplayCommand ?? launch.ExecutableName + " " + string.Join(' ', launch.Arguments.Select(a => a.Contains(' ') ? "\"" + a + "\"" : a));
        var record = new CommandRecord
        {
            UserId = userId,
            RunId = launch.RunId,
            ConversationId = launch.ConversationId,
            Repository = launch.Repository,
            Kind = launch.Kind,
            CommandLine = redactor.Redact(display.Length > 4000 ? display[..4000] + "…" : display),
            TimeoutSeconds = timeout,
            CreatedAt = DateTime.UtcNow,
            Executable = launch.ExecutableName,
            WorkingDirectory = launch.DisplayWorkingDirectory,
            Script = launch.Script is null ? null : redactor.Redact(launch.Script.Length > 20_000 ? launch.Script[..20_000] + "\n…" : launch.Script),
            ScriptPath = launch.ScriptPath,
            Description = launch.Description is null ? null : redactor.Redact(launch.Description.Length > 200 ? launch.Description[..200] : launch.Description),
            Shell = launch.Shell,
            Risk = launch.Risk,
            RiskFindings = launch.RiskFindings.Take(20).ToList(),
            EnvironmentOverrides = overrides.Keys.ToList(),
            ServerId = launch.ServerId,
            LongRunning = launch.LongRunning,
        };
        configure?.Invoke(record);
        await store.WriteAsync(RecordPath(userId, record.Id), record, ct);
        var active = new Active { Record = record, Cancellation = new CancellationTokenSource(), Launch = launch, Redactor = redactor };
        _active[record.Id] = active;
        _ = Task.Run(() => ExecuteAsync(active, timeout), CancellationToken.None);
        logger.LogInformation("Command {CommandId} ({Kind}) queued for {UserId}: {CommandLine} in {Repository}", record.Id, record.Kind, userId, record.CommandLine, launch.Repository);
        return record;
    }

    /// <summary>
    /// Runs a short process and returns its raw stdout bytes (bounded) — for helpers that need exact bytes, such as
    /// <c>git show HEAD:path</c> for line-ending comparison. Same validation, environment policy, record, ownership and
    /// timeout/kill semantics as every other command; the stored log holds the decoded, redacted text.
    /// </summary>
    public async Task<(CommandRecord Record, byte[] Stdout)> RunCaptureAsync(string userId, ProcessLaunch launch, int maxBytes, CancellationToken ct)
    {
        if (!Path.IsPathFullyQualified(launch.WorkingDirectory) || !Directory.Exists(launch.WorkingDirectory) || !File.Exists(launch.ExecutablePath))
        {
            throw new ValidationException("The working directory and executable must be resolved.");
        }
        var timeoutSeconds = Math.Clamp(launch.TimeoutSeconds ?? 60, 5, 600);
        var record = new CommandRecord
        {
            UserId = userId, RunId = launch.RunId, ConversationId = launch.ConversationId, Repository = launch.Repository, Kind = launch.Kind,
            CommandLine = launch.DisplayCommand ?? launch.ExecutableName + " " + string.Join(' ', launch.Arguments), TimeoutSeconds = timeoutSeconds,
            CreatedAt = DateTime.UtcNow, Executable = launch.ExecutableName, WorkingDirectory = launch.DisplayWorkingDirectory, Description = launch.Description,
            Risk = launch.Risk, Status = CommandStatus.Running, StartedAt = DateTime.UtcNow,
        };
        var psi = new ProcessStartInfo(launch.ExecutablePath)
        {
            WorkingDirectory = launch.WorkingDirectory, RedirectStandardOutput = true, RedirectStandardError = true, RedirectStandardInput = true,
            UseShellExecute = false, CreateNoWindow = true,
        };
        foreach (var a in launch.Arguments)
        {
            psi.ArgumentList.Add(a);
        }
        var secrets = DocGen.Analysis.Execution.EnvironmentPolicy.Apply(psi.Environment, ExecutionSettings, launch.Environment, launch.Repository);
        var redactor = new DocGen.Analysis.Execution.OutputRedactor(secrets);
        var sw = Stopwatch.StartNew();
        using var buffer = new MemoryStream();
        string stderr = "";
        using var process = new Process { StartInfo = psi };
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(TimeSpan.FromSeconds(timeoutSeconds));
        try
        {
            process.Start();
            record.ProcessId = process.Id;
            record.ProcessStartTime = TryStartTime(process);
            process.StandardInput.Close();
            var errTask = process.StandardError.ReadToEndAsync(timeout.Token);
            var chunk = new byte[81920];
            int read;
            while ((read = await process.StandardOutput.BaseStream.ReadAsync(chunk, timeout.Token)) > 0)
            {
                if (buffer.Length + read > maxBytes)
                {
                    record.OutputTruncated = true;
                    buffer.Write(chunk, 0, (int)Math.Max(0, maxBytes - buffer.Length));
                    KillTree(process);
                    break;
                }
                buffer.Write(chunk, 0, read);
            }
            await process.WaitForExitAsync(timeout.Token);
            stderr = await errTask;
            record.ExitCode = process.ExitCode;
            record.Status = process.ExitCode == 0 ? CommandStatus.Succeeded : CommandStatus.Failed;
        }
        catch (OperationCanceledException)
        {
            KillTree(process);
            record.Status = ct.IsCancellationRequested ? CommandStatus.Cancelled : CommandStatus.TimedOut;
            record.CancelReason = record.Status == CommandStatus.TimedOut ? $"timed out after {timeoutSeconds} s" : "cancelled";
        }
        catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or InvalidOperationException or IOException)
        {
            record.Status = CommandStatus.Failed;
            record.CancelReason = "The command could not be started: " + ex.Message;
        }
        record.CompletedAt = DateTime.UtcNow;
        record.DurationMs = sw.ElapsedMilliseconds;
        var bytes = buffer.ToArray();
        var text = Encoding.UTF8.GetString(bytes);
        var lines = text.Split('\n').Select(l => redactor.Redact(l.TrimEnd('\r'))).Concat(stderr.Split('\n', StringSplitOptions.RemoveEmptyEntries).Select(l => redactor.Redact(l.TrimEnd('\r')))).ToList();
        record.OutputLines = lines.Count;
        record.OutputBytes = bytes.Length + stderr.Length;
        record.Tail = lines.TakeLast(TailLines).Select(l => l.Length > 1000 ? l[..1000] + "…" : l).ToList();
        try
        {
            var logPath = LogPath(userId, record.Id);
            Directory.CreateDirectory(Path.GetDirectoryName(logPath)!);
            await File.WriteAllLinesAsync(logPath, lines, CancellationToken.None);
            await store.WriteAsync(RecordPath(userId, record.Id), record, CancellationToken.None);
        }
        catch (Exception ex) when (ex is IOException or StorageException)
        {
            logger.LogWarning(ex, "Could not persist capture command {CommandId}", record.Id);
        }
        return (record, bytes);
    }

    /// <summary>Processes this DocGen instance started for the user that are still queued or running.</summary>
    public IReadOnlyList<CommandRecord> ListActive(string userId)
        => _active.Values.Where(a => a.Record.UserId == userId).Select(a =>
        {
            lock (a.Sync)
            {
                return Clone(a.Record);
            }
        }).ToList();

    /// <summary>Waits until the command finishes or <paramref name="maxWait"/> elapses. Cancelling <paramref name="ct"/> cancels the command.</summary>
    public async Task<CommandRecord> WaitAsync(string userId, string id, TimeSpan maxWait, CancellationToken ct, bool cancelOnAbort = true)
    {
        if (_active.TryGetValue(id, out var active) && active.Record.UserId == userId)
        {
            try
            {
                await active.Completed.Task.WaitAsync(maxWait, ct);
            }
            catch (TimeoutException)
            {
            }
            catch (OperationCanceledException) when (cancelOnAbort)
            {
                // The run that started the command was stopped: cancellation propagates to the process.
                await CancelAsync(userId, id, "run cancelled");
                throw;
            }
        }
        return await GetAsync(userId, id, CancellationToken.None);
    }

    public async Task<CommandRecord> GetAsync(string userId, string id, CancellationToken ct)
    {
        if (_active.TryGetValue(id, out var active) && active.Record.UserId == userId)
        {
            lock (active.Sync)
            {
                return Clone(active.Record);
            }
        }
        return await store.ReadAsync<CommandRecord>(RecordPath(userId, id), ct) ?? throw new NotFoundException("Command");
    }

    public async Task<List<CommandRecord>> ListAsync(string userId, int limit, CancellationToken ct)
    {
        var list = new List<CommandRecord>();
        foreach (var path in store.EnumerateDocuments(DirectoryFor(userId)))
        {
            try
            {
                if (await store.ReadAsync<CommandRecord>(path, ct) is { } record)
                {
                    list.Add(_active.TryGetValue(record.Id, out var a) ? Clone(a.Record) : record);
                }
            }
            catch (StorageException)
            {
            }
        }
        return list.OrderByDescending(c => c.CreatedAt).Take(Math.Clamp(limit, 1, 500)).ToList();
    }

    public async Task<bool> CancelAsync(string userId, string id, string reason = "cancelled by user")
    {
        if (!_active.TryGetValue(id, out var active) || active.Record.UserId != userId)
        {
            _ = await store.ReadAsync<CommandRecord>(RecordPath(userId, id)) ?? throw new NotFoundException("Command");
            return false; // Already finished (or interrupted): nothing to cancel.
        }
        active.Reason ??= reason;
        await active.Cancellation.CancelAsync();
        return true;
    }

    /// <summary>Output lines [fromLine, fromLine+count) (1-based) from the stored log.</summary>
    public (List<(long Line, string Text)> Lines, long TotalStored) ReadOutput(string userId, string id, long fromLine, int count, string? search = null)
    {
        var path = LogPath(userId, id);
        if (!File.Exists(path))
        {
            return ([], 0);
        }
        var lines = new List<(long, string)>();
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete);
        using var reader = new StreamReader(stream, Encoding.UTF8);
        long n = 0;
        while (reader.ReadLine() is { } line)
        {
            n++;
            if (n < fromLine || lines.Count >= count)
            {
                continue;
            }
            if (search is { Length: > 0 } && !line.Contains(search, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }
            lines.Add((n, line.Length > 4000 ? line[..4000] + "…" : line));
        }
        return (lines, n);
    }

    /// <summary>Subscribes to progress notifications of an active command (for live streaming). Null when not active.</summary>
    public IDisposable? Subscribe(string userId, string id, Action onChange)
    {
        if (!_active.TryGetValue(id, out var active) || active.Record.UserId != userId)
        {
            return null;
        }
        active.Changed += onChange;
        return new Unsubscriber(() => active.Changed -= onChange);
    }

    private sealed class Unsubscriber(Action dispose) : IDisposable
    {
        public void Dispose() => dispose();
    }

    private async Task ExecuteAsync(Active active, int timeoutSeconds)
    {
        var record = active.Record;
        var launch = active.Launch;
        var workingDirectory = launch.WorkingDirectory;
        var logPath = LogPath(record.UserId, record.Id);
        Directory.CreateDirectory(Path.GetDirectoryName(logPath)!);
        var maxBytes = options.CurrentValue.MaxCommandOutputBytes;
        var tail = new Queue<string>();
        var sw = new Stopwatch();
        var slotTaken = false;
        StreamWriter? log = null;

        try
        {
            if (!launch.LongRunning)
            {
                await Slots.WaitAsync(active.Cancellation.Token);
                slotTaken = true;
            }
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(active.Cancellation.Token);
            if (timeoutSeconds > 0)
            {
                timeout.CancelAfter(TimeSpan.FromSeconds(timeoutSeconds));
            }

            log = new StreamWriter(new FileStream(logPath, FileMode.Create, FileAccess.Write, FileShare.Read | FileShare.Delete), new UTF8Encoding(false)) { AutoFlush = false };
            var psi = new ProcessStartInfo(launch.ExecutablePath)
            {
                WorkingDirectory = workingDirectory,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                RedirectStandardInput = true,
                UseShellExecute = false,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8,
            };
            foreach (var argument in launch.Arguments)
            {
                psi.ArgumentList.Add(argument);
            }
            var secretValues = DocGen.Analysis.Execution.EnvironmentPolicy.Apply(psi.Environment, ExecutionSettings, launch.Environment, launch.Repository);
            active.Redactor = new DocGen.Analysis.Execution.OutputRedactor(secretValues);

            using var process = new Process { StartInfo = psi, EnableRaisingEvents = true };
            void OnLine(string? line, bool stderr)
            {
                if (line is null)
                {
                    return;
                }
                line = active.Redactor.Redact(line);
                lock (active.Sync)
                {
                    record.OutputLines++;
                    if (stderr)
                    {
                        record.StderrLines++;
                    }
                    var bytes = Encoding.UTF8.GetByteCount(line) + 1;
                    record.OutputBytes += bytes;
                    if (record.OutputBytes <= maxBytes && !active.LogClosed)
                    {
                        log.WriteLine(line);
                        active.LinesWritten++;
                    }
                    else
                    {
                        record.OutputTruncated = true;
                    }
                    tail.Enqueue(line.Length > 1000 ? line[..1000] + "…" : line);
                    if (tail.Count > TailLines)
                    {
                        tail.Dequeue();
                    }
                }
                try
                {
                    launch.OnOutput?.Invoke(line);
                }
                catch (Exception ex)
                {
                    logger.LogDebug(ex, "Output observer of command {CommandId} failed", record.Id);
                }
            }
            process.OutputDataReceived += (_, e) => OnLine(e.Data, stderr: false);
            process.ErrorDataReceived += (_, e) => OnLine(e.Data, stderr: true);

            sw.Start();
            process.Start();
            process.StandardInput.Close(); // Never wait for interactive input.
            process.BeginOutputReadLine();
            process.BeginErrorReadLine();
            active.Process = process;
            lock (active.Sync)
            {
                record.Status = CommandStatus.Running;
                record.StartedAt = DateTime.UtcNow;
                record.LastHeartbeatAt = record.StartedAt;
                record.ProcessId = process.Id;
                record.ProcessStartTime = TryStartTime(process);
            }
            await PersistAsync(active, tail);
            active.Notify();

            var exit = process.WaitForExitAsync(CancellationToken.None);
            while (!exit.IsCompleted)
            {
                var delay = Task.Delay(HeartbeatInterval, CancellationToken.None);
                var cancelled = Task.Delay(Timeout.Infinite, timeout.Token);
                var finished = await Task.WhenAny(exit, delay, cancelled);
                if (finished == cancelled || timeout.IsCancellationRequested)
                {
                    KillTree(process);
                    await exit.WaitAsync(TimeSpan.FromSeconds(15)).ContinueWith(_ => { }, TaskScheduler.Default);
                    lock (active.Sync)
                    {
                        record.Status = active.Cancellation.IsCancellationRequested || timeoutSeconds <= 0 ? CommandStatus.Cancelled : CommandStatus.TimedOut;
                        record.CancelReason = record.Status == CommandStatus.TimedOut ? $"timed out after {timeoutSeconds} s" : active.Reason ?? "cancelled";
                    }
                    break;
                }
                lock (active.Sync)
                {
                    record.LastHeartbeatAt = DateTime.UtcNow;
                    record.DurationMs = sw.ElapsedMilliseconds;
                    log.Flush();
                }
                active.Notify();
                await PersistAsync(active, tail);
                active.Notify();
            }

            if (exit.IsCompleted)
            {
                process.WaitForExit(); // Drains the asynchronous output handlers.
            }
            lock (active.Sync)
            {
                log.Flush();
                if (record.Status == CommandStatus.Running)
                {
                    record.ExitCode = process.HasExited ? process.ExitCode : null;
                    record.Status = record.ExitCode == 0 ? CommandStatus.Succeeded : CommandStatus.Failed;
                }
            }
        }
        catch (OperationCanceledException)
        {
            lock (active.Sync)
            {
                record.Status = CommandStatus.Cancelled;
                record.CancelReason = active.Reason ?? "cancelled";
            }
        }
        catch (Exception ex) when (ex is System.ComponentModel.Win32Exception or InvalidOperationException or IOException)
        {
            logger.LogWarning(ex, "Command {CommandId} could not run", record.Id);
            lock (active.Sync)
            {
                record.Status = CommandStatus.Failed;
                record.CancelReason = "The command could not be started: " + ex.Message;
            }
        }
        finally
        {
            if (slotTaken)
            {
                Slots.Release();
            }
            lock (active.Sync)
            {
                record.CompletedAt = DateTime.UtcNow;
                record.DurationMs = sw.ElapsedMilliseconds;
                // Late output events (after a kill) must never touch a disposed writer.
                active.LogClosed = true;
                log?.Flush();
                log?.Dispose();
            }
            AnalyzeOutput(active);
            await PersistAsync(active, tail);
            _active.TryRemove(record.Id, out _);
            active.Completed.TrySetResult();
            active.Notify();
            active.Cancellation.Dispose();
            logger.LogInformation("Command {CommandId} finished {Status} (exit {ExitCode}) in {DurationMs} ms, {Lines} output lines",
                record.Id, record.Status, record.ExitCode, record.DurationMs, record.OutputLines);
        }
    }

    /// <summary>Parses the stored output into a build/test report (full output, never just the tail).</summary>
    private void AnalyzeOutput(Active active)
    {
        var record = active.Record;
        try
        {
            var path = LogPath(record.UserId, record.Id);
            if (!File.Exists(path) || active.Launch.ParseAs is null)
            {
                return;
            }
            var lines = File.ReadLines(path).Take(500_000).ToList();
            if (active.Launch.ParseAs == CommandKinds.Test)
            {
                record.Tests = TestOutputAnalyzer.Parse(lines);
            }
            else
            {
                record.Build = BuildOutputAnalyzer.Parse(lines);
            }
        }
        catch (IOException ex)
        {
            logger.LogWarning(ex, "Could not analyse the output of command {CommandId}", record.Id);
        }
    }

    private async Task PersistAsync(Active active, Queue<string> tail)
    {
        CommandRecord snapshot;
        lock (active.Sync)
        {
            active.Record.Tail = tail.ToList();
            snapshot = Clone(active.Record);
        }
        try
        {
            await store.WriteAsync(RecordPath(snapshot.UserId, snapshot.Id), snapshot, CancellationToken.None);
        }
        catch (StorageException ex)
        {
            logger.LogWarning(ex, "Could not persist command {CommandId}", snapshot.Id);
        }
    }

    private static CommandRecord Clone(CommandRecord r)
    {
        var json = System.Text.Json.JsonSerializer.Serialize(r, DocGen.Core.Json.DocGenJson.Wire);
        return System.Text.Json.JsonSerializer.Deserialize<CommandRecord>(json, DocGen.Core.Json.DocGenJson.Wire)!;
    }

    private static string ResolveExecutable(AnalysisOptions opts)
    {
        if (!opts.AllowedExecutables.Contains("dotnet", StringComparer.OrdinalIgnoreCase))
        {
            throw new ForbiddenException("The dotnet executable is not allowed by configuration.");
        }
        // The SDK sets DOTNET_HOST_PATH for processes it starts; otherwise resolve from PATH.
        var host = Environment.GetEnvironmentVariable("DOTNET_HOST_PATH");
        return host is { Length: > 0 } && File.Exists(host) && Path.GetFileNameWithoutExtension(host).Equals("dotnet", StringComparison.OrdinalIgnoreCase) ? host : "dotnet";
    }

    /// <summary>Builds the argument list from validated, structured input. Nothing is passed through a shell.</summary>
    internal static List<string> BuildArguments(RepositoryHandle repo, CommandRequest request)
    {
        var args = new List<string>();
        string? target = null;
        if (!string.IsNullOrWhiteSpace(request.Target))
        {
            var full = repo.Resolve(request.Target);
            var ext = Path.GetExtension(full);
            if (!File.Exists(full) || ext is not (".sln" or ".slnx" or ".csproj" or ".fsproj" or ".vbproj"))
            {
                throw new ValidationException("The target must be an existing .sln, .slnx or project file in the repository.");
            }
            target = repo.Relative(full);
        }
        switch (request.Kind)
        {
            case CommandKinds.Build:
                args.Add("build");
                break;
            case CommandKinds.Test:
                args.Add("test");
                break;
            case CommandKinds.Restore:
                args.Add("restore");
                break;
            case CommandKinds.Packages:
                args.Add("list");
                break;
        }
        if (target is not null)
        {
            args.Add(target);
        }
        if (request.Kind == CommandKinds.Packages)
        {
            args.AddRange(["package", "--include-transitive"]);
            return args;
        }
        args.Add("-nologo");
        args.Add("-nodeReuse:false");
        if (request.Configuration is { Length: > 0 } configuration)
        {
            if (configuration is not ("Debug" or "Release"))
            {
                throw new ValidationException("Configuration must be Debug or Release.");
            }
            args.AddRange(["-c", configuration]);
        }
        if (request.NoRestore && request.Kind != CommandKinds.Restore)
        {
            args.Add("--no-restore");
        }
        if (request.Kind == CommandKinds.Test)
        {
            if (request.NoBuild)
            {
                args.Add("--no-build");
            }
            args.AddRange(["--logger", "console;verbosity=normal"]);
            if (request.Filter is { Length: > 0 } filter)
            {
                if (filter.Length > 500 || !FilterPattern().IsMatch(filter))
                {
                    throw new ValidationException("The test filter contains unsupported characters.");
                }
                args.AddRange(["--filter", filter]);
            }
        }
        return args;
    }

    private static readonly string[] SecretMarkers = ["KEY", "SECRET", "TOKEN", "PASSWORD", "PASSWD", "CONNECTIONSTRING", "CREDENTIAL", "PRIVATE"];

    /// <summary>Removes secret-looking variables (e.g. provider API keys) so code under build/test cannot read them.</summary>
    internal static void SanitizeEnvironment(IDictionary<string, string?> environment)
    {
        foreach (var name in environment.Keys.ToList())
        {
            var upper = name.ToUpperInvariant();
            if (SecretMarkers.Any(m => upper.Contains(m, StringComparison.Ordinal)) || upper.StartsWith("DOCGEN_", StringComparison.Ordinal))
            {
                environment.Remove(name);
            }
        }
        environment["DOTNET_CLI_TELEMETRY_OPTOUT"] = "1";
        environment["DOTNET_NOLOGO"] = "1";
        environment["DOTNET_SKIP_FIRST_TIME_EXPERIENCE"] = "1";
        environment["MSBUILDDISABLENODEREUSE"] = "1";
        environment["DOTNET_CLI_UI_LANGUAGE"] = "en";
        environment["VSLANG"] = "1033";
    }

    private static void KillTree(Process process)
    {
        try
        {
            if (!process.HasExited)
            {
                process.Kill(entireProcessTree: true);
            }
        }
        catch (Exception ex) when (ex is InvalidOperationException or System.ComponentModel.Win32Exception or NotSupportedException)
        {
        }
    }

    private static DateTime? TryStartTime(Process process)
    {
        try
        {
            return process.StartTime.ToUniversalTime();
        }
        catch (Exception ex) when (ex is InvalidOperationException or System.ComponentModel.Win32Exception or NotSupportedException)
        {
            return null;
        }
    }

    /// <summary>
    /// Startup: commands left Queued/Running by a previous process are marked Interrupted. A still-running orphan is
    /// killed only if its process id AND start time match the record (never an unrelated process that reused the id).
    /// </summary>
    public async Task<int> ReconcileAsync(CancellationToken ct = default)
    {
        var count = 0;
        foreach (var userDir in store.EnumerateDirectories("commands"))
        {
            foreach (var path in store.EnumerateDocuments($"commands/{userDir}"))
            {
                CommandRecord? record;
                try
                {
                    record = await store.ReadAsync<CommandRecord>(path, ct);
                }
                catch (StorageException)
                {
                    continue;
                }
                if (record is null || record.IsFinal || _active.ContainsKey(record.Id))
                {
                    continue;
                }
                if (record.ProcessId is { } pid && record.ProcessStartTime is { } started)
                {
                    try
                    {
                        using var orphan = Process.GetProcessById(pid);
                        if (TryStartTime(orphan) is { } actual && Math.Abs((actual - started).TotalSeconds) < 2)
                        {
                            KillTree(orphan);
                            logger.LogWarning("Killed orphaned command process {ProcessId} of command {CommandId}", pid, record.Id);
                        }
                    }
                    catch (ArgumentException)
                    {
                        // Not running any more.
                    }
                }
                record.Status = CommandStatus.Interrupted;
                record.CancelReason = "DocGen stopped while this command was running; its outcome is unknown.";
                record.CompletedAt ??= DateTime.UtcNow;
                await store.WriteAsync(path, record, ct);
                count++;
            }
        }
        if (count > 0)
        {
            logger.LogWarning("Marked {Count} commands left running by a previous process as Interrupted", count);
        }
        return count;
    }

    public Task StartAsync(CancellationToken cancellationToken) => Task.CompletedTask;

    /// <summary>Graceful shutdown: cancel (kill) running commands and wait briefly for their records to be saved.</summary>
    public async Task StopAsync(CancellationToken cancellationToken)
    {
        _stopping = true;
        var running = _active.Values.ToList();
        foreach (var active in running)
        {
            active.Reason ??= "DocGen is shutting down";
            await active.Cancellation.CancelAsync();
        }
        if (running.Count > 0)
        {
            await Task.WhenAll(running.Select(a => a.Completed.Task)).WaitAsync(TimeSpan.FromSeconds(20), CancellationToken.None).ContinueWith(_ => { }, TaskScheduler.Default);
        }
    }

    public int ActiveCount => _active.Count;

    /// <summary>True while a command is queued or running in this process.</summary>
    public bool IsActive(string id) => _active.ContainsKey(id);

    [GeneratedRegex(@"^[A-Za-z0-9_.,=~!&|()<>\-\s:*/""]+$")]
    private static partial Regex FilterPattern();
}
