using DocGen.Analysis.Diagnostics;
using DocGen.Core.Models;

namespace DocGen.Analysis.Commands;

public enum CommandStatus
{
    Queued,
    Running,
    Succeeded,
    Failed,
    TimedOut,
    Cancelled,

    /// <summary>DocGen stopped while the command was running; its outcome is unknown.</summary>
    Interrupted,
}

/// <summary>build | test | restore | packages (dotnet) and the general kinds powershell | process | server | browser.</summary>
public static class CommandKinds
{
    public const string Build = "build";
    public const string Test = "test";
    public const string Restore = "restore";
    public const string Packages = "packages";
    public const string PowerShell = "powershell";
    public const string Process = "process";
    public const string Server = "server";
    public const string Browser = "browser";

    public static bool IsValid(string kind) => kind is Build or Test or Restore or Packages;

    public static bool IsKnown(string kind) => IsValid(kind) || kind is PowerShell or Process or Server or Browser;
}

/// <summary>Persistent record of one command execution (data/commands/{userId}/{id}.json + {id}.log).</summary>
public sealed class CommandRecord : Entity, IOwnedEntity
{
    public string UserId { get; set; } = "";
    public string? RunId { get; set; }
    public string? ConversationId { get; set; }
    public string Repository { get; set; } = "";
    public string Kind { get; set; } = CommandKinds.Build;

    /// <summary>Solution/project path relative to the repository root, or null for the repository root.</summary>
    public string? Target { get; set; }

    public string? Filter { get; set; }

    /// <summary>The exact command line that ran (for display and reproduction).</summary>
    public string CommandLine { get; set; } = "";

    public CommandStatus Status { get; set; } = CommandStatus.Queued;
    public int? ExitCode { get; set; }
    public DateTime QueuedAt { get; set; } = DateTime.UtcNow;
    public DateTime? StartedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
    public DateTime? LastHeartbeatAt { get; set; }
    public long DurationMs { get; set; }
    public int TimeoutSeconds { get; set; }
    public string? CancelReason { get; set; }
    public int? ProcessId { get; set; }
    public DateTime? ProcessStartTime { get; set; }

    public long OutputLines { get; set; }
    public long StderrLines { get; set; }
    public long OutputBytes { get; set; }

    /// <summary>True when output beyond the storage cap was counted but not kept.</summary>
    public bool OutputTruncated { get; set; }

    /// <summary>The most recent output lines (bounded), for quick status views.</summary>
    public List<string> Tail { get; set; } = [];

    public BuildReport? Build { get; set; }
    public TestReport? Tests { get; set; }

    // ---- 0.6.0: general process execution metadata (all redacted and bounded).

    /// <summary>Logical executable name (dotnet, pwsh, powershell, git…).</summary>
    public string? Executable { get; set; }

    /// <summary>Working directory relative to the repository root ("." for the root).</summary>
    public string? WorkingDirectory { get; set; }

    /// <summary>PowerShell script text (redacted, bounded) for powershell commands.</summary>
    public string? Script { get; set; }

    /// <summary>Repository-relative path of an executed script file.</summary>
    public string? ScriptPath { get; set; }

    /// <summary>Short human description supplied with the request ("Checked project files and version").</summary>
    public string? Description { get; set; }

    /// <summary>Shell that ran it, e.g. "Windows PowerShell 5.1.26100".</summary>
    public string? Shell { get; set; }

    /// <summary>Server-assessed risk (ReadOnly, Write, External, Sensitive, Destructive) and the findings behind it.</summary>
    public string? Risk { get; set; }

    public List<string> RiskFindings { get; set; } = [];

    /// <summary>Names (never values) of environment overrides applied.</summary>
    public List<string> EnvironmentOverrides { get; set; } = [];

    /// <summary>Development server this process belongs to.</summary>
    public string? ServerId { get; set; }

    /// <summary>Long-running processes (servers, browsers) have no timeout and do not take a command slot.</summary>
    public bool LongRunning { get; set; }

    public bool IsFinal => Status is not (CommandStatus.Queued or CommandStatus.Running);
}

/// <summary>
/// A validated request to start a process through <see cref="CommandRunner"/>. Built only by DocGen code from
/// structured tool input: the executable is already resolved against the allowlist and the working directory is an
/// absolute path inside an allowed repository root.
/// </summary>
public sealed class ProcessLaunch
{
    public required string Kind { get; init; }
    public required string ExecutableName { get; init; }
    public required string ExecutablePath { get; init; }
    public List<string> Arguments { get; init; } = [];
    public required string WorkingDirectory { get; init; }

    /// <summary>Working directory relative to the repository root, for display.</summary>
    public string DisplayWorkingDirectory { get; init; } = ".";

    public required string Repository { get; init; }

    /// <summary>What is shown as the command line (e.g. "pwsh -File …" or "git status --short"). Redacted before storage.</summary>
    public string? DisplayCommand { get; init; }

    public string? Script { get; init; }
    public string? ScriptPath { get; init; }
    public string? Description { get; init; }
    public string? Shell { get; init; }
    public IReadOnlyDictionary<string, string>? Environment { get; init; }
    public int? TimeoutSeconds { get; init; }
    public bool LongRunning { get; init; }
    public string? RunId { get; init; }
    public string? ConversationId { get; init; }
    public string? ServerId { get; init; }
    public string? Risk { get; init; }
    public List<string> RiskFindings { get; init; } = [];

    /// <summary>build | test: parse the output into a build/test report when finished.</summary>
    public string? ParseAs { get; init; }

    /// <summary>Called for every (redacted) output line; used for port discovery. Must be fast and never throw.</summary>
    public Action<string>? OnOutput { get; init; }
}

public sealed class CommandRequest
{
    public required string Kind { get; init; }
    public string? Target { get; init; }
    public string? Filter { get; init; }
    public bool NoBuild { get; init; }
    public bool NoRestore { get; init; }
    public string? Configuration { get; init; }
    public int? TimeoutSeconds { get; init; }
    public string? RunId { get; init; }
    public string? ConversationId { get; init; }
}
