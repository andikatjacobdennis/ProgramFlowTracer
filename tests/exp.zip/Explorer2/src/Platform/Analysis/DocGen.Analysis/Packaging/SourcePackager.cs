using System.Globalization;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.RegularExpressions;
using DocGen.Analysis.Git;
using DocGen.Core.Exceptions;

namespace DocGen.Analysis.Packaging;

public sealed class PackageSettings
{
    public List<string> ExcludedDirectories { get; init; } = [];
    public List<string> NeverIncludedDirectories { get; init; } = [];

    /// <summary>Default-excluded directory names the user explicitly asked to include (never secrets, never the "never" set).</summary>
    public List<string> Include { get; init; } = [];

    /// <summary>Additional exclusions: directory names or file globs (*.log, docs/private/*).</summary>
    public List<string> Exclude { get; init; } = [];

    public bool WriteManifest { get; init; } = true;

    /// <summary>
    /// Also exclude source-code files whose content looks like a credential. By default they are packaged (a source
    /// package must stay complete) and listed as warnings to review before sharing.
    /// </summary>
    public bool StrictSecrets { get; init; }

    /// <summary>Optional top-level folder for every entry (e.g. "OrderService_1_0/"), so the ZIP extracts into one folder.</summary>
    public string EntryPrefix { get; init; } = "";
    public long MaxTotalBytes { get; init; } = 512L * 1024 * 1024;
    public int MaxFiles { get; init; } = 50_000;

    /// <summary>Directories (absolute) that are never packaged, e.g. the output folder itself.</summary>
    public List<string> ExcludedAbsolute { get; init; } = [];
}

public sealed class PackageManifest
{
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public string Repository { get; set; } = "";
    public string? Branch { get; set; }
    public string? Commit { get; set; }
    public bool? WorkingTreeClean { get; set; }
    public string RelativeRoot { get; set; } = ".";
    public string RootKind { get; set; } = "repository";
    public int IncludedFileCount { get; set; }
    public long TotalBytes { get; set; }
    public List<string> Exclusions { get; set; } = [];
    public Dictionary<string, int> ExcludedCounts { get; set; } = new(StringComparer.Ordinal);
    public string CreatedBy { get; set; } = "DocGen package_source";
}

public sealed class PackageResult
{
    public string ArchivePath { get; set; } = "";
    public long ArchiveBytes { get; set; }
    public string Sha256 { get; set; } = "";
    public int FileCount { get; set; }
    public long TotalBytes { get; set; }
    public PackageManifest Manifest { get; set; } = new();
    public List<string> SecretFilesExcluded { get; set; } = [];

    /// <summary>Source files packaged although they contain credential-like strings (test fixtures, examples…): review before sharing.</summary>
    public List<string> SourceWarnings { get; set; } = [];
    public List<string> ExcludedSamples { get; set; } = [];
    public List<(string Path, long Bytes)> Largest { get; set; } = [];
    public PackageVerification Verification { get; set; } = new();
}

public sealed class PackageVerification
{
    public bool Passed => Problems.Count == 0;
    public int Entries { get; set; }
    public long UncompressedBytes { get; set; }
    public string Sha256 { get; set; } = "";
    public List<string> Checks { get; set; } = [];
    public List<string> Problems { get; set; } = [];
}

/// <summary>
/// Builds a source ZIP with System.IO.Compression: repository-relative entry names only (never "../", absolute paths,
/// drive letters or UNC paths), default exclusions for build output, tooling state, data/logs/workspaces, browser
/// profiles, scratch folders, user-specific files and secrets, an optional credential-free docgen-package.json, and an
/// independent verification pass that re-opens the archive.
/// </summary>
public static partial class SourcePackager
{
    public const string ManifestName = "docgen-package.json";

    private static readonly string[] UserSpecificSuffixes = [".user", ".suo", ".userprefs", ".dotsettings.user", ".userosscache", ".sln.docstates", ".pubxml.user"];
    private static readonly string[] AlwaysExcludedExtensions = [".log", ".tmp", ".cache"];

    private static readonly HashSet<string> CodeExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".cs", ".csx", ".vb", ".fs", ".js", ".mjs", ".ts", ".tsx", ".jsx", ".py", ".java", ".kt", ".go", ".rb", ".php", ".razor", ".cshtml",
        ".ps1", ".psm1", ".sh", ".sql", ".md",
    };

    public static PackageResult Create(string root, string outputPath, PackageSettings settings, PackageManifest manifest, CancellationToken ct)
    {
        root = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar);
        outputPath = Path.GetFullPath(outputPath);
        var never = new HashSet<string>(settings.NeverIncludedDirectories, StringComparer.OrdinalIgnoreCase);
        var refused = settings.Include.Where(never.Contains).ToList();
        if (refused.Count > 0)
        {
            throw new ValidationException($"These directories are never packaged: {string.Join(", ", refused)}.");
        }
        var excludedDirs = new HashSet<string>(settings.ExcludedDirectories.Concat(settings.NeverIncludedDirectories), StringComparer.OrdinalIgnoreCase);
        excludedDirs.ExceptWith(settings.Include);
        var excludeGlobs = settings.Exclude.Select(Glob).ToList();
        foreach (var dir in settings.Exclude.Where(e => !e.Contains('*', StringComparison.Ordinal) && !e.Contains('/', StringComparison.Ordinal) && !e.Contains('.', StringComparison.Ordinal)))
        {
            excludedDirs.Add(dir);
        }

        var result = new PackageResult();
        var excludedCounts = new Dictionary<string, int>(StringComparer.Ordinal);
        void Excluded(string reason, string relative)
        {
            excludedCounts[reason] = excludedCounts.GetValueOrDefault(reason) + 1;
            if (result.ExcludedSamples.Count < 40)
            {
                result.ExcludedSamples.Add($"{relative} ({reason})");
            }
        }

        var files = new List<(string Full, string Entry, long Length)>();
        var stack = new Stack<string>();
        stack.Push(root);
        long total = 0;
        while (stack.Count > 0)
        {
            ct.ThrowIfCancellationRequested();
            var dir = stack.Pop();
            foreach (var sub in Directory.EnumerateDirectories(dir).OrderBy(d => d, StringComparer.Ordinal))
            {
                var info = new DirectoryInfo(sub);
                var relative = Rel(root, sub);
                if (info.LinkTarget is not null || info.Attributes.HasFlag(FileAttributes.ReparsePoint))
                {
                    Excluded("symbolic link or junction", relative + "/");
                }
                else if (excludedDirs.Contains(info.Name) || ProfileDir().IsMatch(info.Name))
                {
                    Excluded("excluded directory " + info.Name, relative + "/");
                }
                else if (settings.ExcludedAbsolute.Any(a => string.Equals(Path.GetFullPath(a).TrimEnd(Path.DirectorySeparatorChar), sub, StringComparison.OrdinalIgnoreCase)))
                {
                    Excluded("package output folder", relative + "/");
                }
                else if (excludeGlobs.Any(g => g.IsMatch(relative) || g.IsMatch(relative + "/")))
                {
                    Excluded("requested exclusion", relative + "/");
                }
                else
                {
                    stack.Push(sub);
                }
            }
            foreach (var file in Directory.EnumerateFiles(dir).OrderBy(f => f, StringComparer.Ordinal))
            {
                var info = new FileInfo(file);
                var relative = Rel(root, file);
                var lower = info.Name.ToLowerInvariant();
                if (string.Equals(info.FullName, outputPath, StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }
                if (info.LinkTarget is not null)
                {
                    Excluded("symbolic link", relative);
                    continue;
                }
                if (SecretScanner.IsSecretFileName(relative))
                {
                    Excluded("secret file", relative);
                    result.SecretFilesExcluded.Add(relative);
                    continue;
                }
                if (UserSpecificSuffixes.Any(s => lower.EndsWith(s, StringComparison.Ordinal)))
                {
                    Excluded("user-specific file", relative);
                    continue;
                }
                if (AlwaysExcludedExtensions.Contains(info.Extension.ToLowerInvariant()) && !settings.Include.Any(i => i.Equals(info.Extension, StringComparison.OrdinalIgnoreCase)))
                {
                    Excluded("log/temporary file", relative);
                    continue;
                }
                if (excludeGlobs.Any(g => g.IsMatch(relative)))
                {
                    Excluded("requested exclusion", relative);
                    continue;
                }
                if (info.Length <= 2 * 1024 * 1024 && LooksText(file) && SecretScanner.Find(File.ReadAllText(file)).Where(k => k != "password assignment").ToList() is { Count: > 0 } kinds)
                {
                    if (settings.StrictSecrets || !CodeExtensions.Contains(info.Extension))
                    {
                        Excluded("credential content: " + string.Join(", ", kinds), relative);
                        result.SecretFilesExcluded.Add($"{relative} ({string.Join(", ", kinds)})");
                        continue;
                    }
                    result.SourceWarnings.Add($"{relative} ({string.Join(", ", kinds)})");
                }
                var entryName = settings.EntryPrefix + relative;
                if (!IsSafeEntryName(entryName))
                {
                    Excluded("unsafe entry name", relative);
                    continue;
                }
                files.Add((file, entryName, info.Length));
                total += info.Length;
                if (files.Count > settings.MaxFiles)
                {
                    throw new ValidationException($"More than {settings.MaxFiles:N0} files would be packaged; narrow the root or add exclusions.");
                }
                if (total > settings.MaxTotalBytes)
                {
                    throw new ValidationException($"The package would exceed {settings.MaxTotalBytes / 1024 / 1024:N0} MB; narrow the root or add exclusions.");
                }
            }
        }

        manifest.IncludedFileCount = files.Count;
        manifest.TotalBytes = total;
        manifest.ExcludedCounts = excludedCounts;
        manifest.Exclusions = excludedDirs.OrderBy(d => d, StringComparer.OrdinalIgnoreCase).Select(d => d + "/")
            .Concat(["secret files (.env, *.pfx, *.pem, *.key, id_rsa, secrets.json, credentials…)", "files with credential content", "user-specific files (*.user, *.suo)", "*.log, *.tmp"])
            .Concat(settings.Exclude).ToList();

        Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
        var temp = outputPath + ".partial";
        using (var stream = new FileStream(temp, FileMode.Create, FileAccess.Write, FileShare.None))
        using (var zip = new ZipArchive(stream, ZipArchiveMode.Create))
        {
            foreach (var (full, entryName, _) in files)
            {
                ct.ThrowIfCancellationRequested();
                var entry = zip.CreateEntry(entryName, CompressionLevel.Optimal);
                entry.LastWriteTime = File.GetLastWriteTime(full) is var t && t.Year >= 1980 ? t : new DateTime(1980, 1, 1);
                using var input = File.OpenRead(full);
                using var output = entry.Open();
                input.CopyTo(output);
            }
            if (settings.WriteManifest)
            {
                var entry = zip.CreateEntry(ManifestName, CompressionLevel.Optimal);
                using var output = entry.Open();
                JsonSerializer.Serialize(output, manifest, new JsonSerializerOptions { WriteIndented = true, PropertyNamingPolicy = JsonNamingPolicy.CamelCase });
            }
        }
        File.Move(temp, outputPath, overwrite: true);

        result.ArchivePath = outputPath;
        result.ArchiveBytes = new FileInfo(outputPath).Length;
        result.FileCount = files.Count;
        result.TotalBytes = total;
        result.Manifest = manifest;
        result.Largest = files.OrderByDescending(f => f.Length).Take(5).Select(f => (f.Entry, f.Length)).ToList();
        result.Verification = Verify(outputPath, excludedDirs, files.Count, settings.WriteManifest);
        result.Sha256 = result.Verification.Sha256;
        return result;
    }

    /// <summary>Re-opens the archive and checks every entry independently of how it was written.</summary>
    public static PackageVerification Verify(string archivePath, IReadOnlySet<string> excludedDirectories, int? expectedFiles, bool expectManifest)
    {
        var v = new PackageVerification();
        using (var stream = File.OpenRead(archivePath))
        {
            v.Sha256 = Convert.ToHexStringLower(SHA256.HashData(stream));
        }
        using var zip = ZipFile.OpenRead(archivePath);
        var unsafeNames = new List<string>();
        var excluded = new List<string>();
        var secrets = new List<string>();
        var buildOutput = new List<string>();
        var manifestFound = false;
        foreach (var entry in zip.Entries)
        {
            v.Entries++;
            v.UncompressedBytes += entry.Length;
            var name = entry.FullName;
            if (name == ManifestName)
            {
                manifestFound = true;
                continue;
            }
            if (!IsSafeEntryName(name))
            {
                unsafeNames.Add(name);
            }
            var segments = name.Split('/');
            if (segments.Take(segments.Length - 1).Any(excludedDirectories.Contains))
            {
                excluded.Add(name);
            }
            if (segments.Take(segments.Length - 1).Any(s => s.Equals("bin", StringComparison.OrdinalIgnoreCase) || s.Equals("obj", StringComparison.OrdinalIgnoreCase))
                && excludedDirectories.Contains("bin"))
            {
                buildOutput.Add(name);
            }
            if (SecretScanner.IsSecretFileName(name))
            {
                secrets.Add(name);
            }
        }
        void Check(bool ok, string pass, string fail, List<string>? offenders = null)
        {
            if (ok)
            {
                v.Checks.Add("✓ " + pass);
            }
            else
            {
                v.Checks.Add("✗ " + fail);
                v.Problems.Add(fail + (offenders is { Count: > 0 } ? ": " + string.Join(", ", offenders.Take(5)) : ""));
            }
        }
        Check(unsafeNames.Count == 0, "Relative paths verified (no ../, absolute paths, drive letters or UNC paths)", "Unsafe entry names", unsafeNames);
        Check(buildOutput.Count == 0, "No build output (bin/obj)", "Build output present", buildOutput);
        Check(excluded.Count == 0, "No excluded directories", "Excluded directories present", excluded);
        Check(secrets.Count == 0, "No secret files detected", "Secret files present", secrets);
        if (expectedFiles is { } n)
        {
            Check(v.Entries - (manifestFound ? 1 : 0) == n, $"{n:N0} files as planned", $"Entry count {v.Entries - (manifestFound ? 1 : 0)} differs from the {n} planned files");
        }
        if (expectManifest)
        {
            Check(manifestFound, $"{ManifestName} present", $"{ManifestName} missing");
        }
        v.Checks.Add($"✓ SHA-256 {v.Sha256}");
        return v;
    }

    /// <summary>Relative, forward-slash, no traversal, no rooted/drive/UNC form, no control characters.</summary>
    public static bool IsSafeEntryName(string name)
    {
        if (string.IsNullOrEmpty(name) || name.Length > 400)
        {
            return false;
        }
        var n = name.Replace('\\', '/');
        if (n != name && name.Contains('\\', StringComparison.Ordinal))
        {
            return false; // Entry names must use '/'.
        }
        if (n.StartsWith('/') || n.StartsWith("//", StringComparison.Ordinal) || n.Contains(':', StringComparison.Ordinal) || Path.IsPathRooted(n))
        {
            return false;
        }
        return n.Split('/').All(s => s.Length > 0 && s != ".." && s != "." && !s.Any(char.IsControl));
    }

    private static string Rel(string root, string full) => Path.GetRelativePath(root, full).Replace('\\', '/');

    private static bool LooksText(string file)
    {
        Span<byte> head = stackalloc byte[4096];
        using var s = File.OpenRead(file);
        var n = s.Read(head);
        return head[..n].IndexOf((byte)0) < 0;
    }

    private static Regex Glob(string pattern)
    {
        var p = pattern.Replace('\\', '/').Trim('/');
        var regex = "^" + Regex.Escape(p).Replace(@"\*\*/", "(.*/)?", StringComparison.Ordinal).Replace(@"\*\*", ".*", StringComparison.Ordinal)
            .Replace(@"\*", "[^/]*", StringComparison.Ordinal).Replace(@"\?", "[^/]", StringComparison.Ordinal) + "(/.*)?$";
        // A bare pattern without a slash also matches at any depth (like .gitignore).
        return new Regex(p.Contains('/', StringComparison.Ordinal) ? regex : "(^|.*/)" + regex[1..], RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
    }

    public static string SizeText(long bytes)
        => bytes >= 1024 * 1024 ? (bytes / 1024.0 / 1024).ToString("0.0", CultureInfo.InvariantCulture) + " MB"
            : bytes >= 1024 ? (bytes / 1024.0).ToString("0.0", CultureInfo.InvariantCulture) + " KB" : bytes + " B";

    [GeneratedRegex(@"^(browser-?profiles?|docgen-browser-.*|chrome-profile.*|edge-profile.*|\.playwright.*)$", RegexOptions.IgnoreCase)]
    private static partial Regex ProfileDir();
}
