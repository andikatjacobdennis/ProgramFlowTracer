using System.Diagnostics;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using DocGen.Analysis.Browser;
using DocGen.Analysis.Diagrams;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Core.Options;
using DocGen.Tools.Infrastructure;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Tools;

/// <summary>
/// Renders a layered architecture diagram from a JSON description: deterministic layout and routing (the model never
/// places boxes), a self-contained SVG, a PNG made by headless Edge/Chrome when one is installed, and the spec for
/// later edits - all under generated/diagrams/ in the user's workspace.
/// </summary>
public sealed partial class DiagramRenderTool(AnalysisServices services) : AnalysisTool(services), IDynamicRiskTool
{
    public override string Name => "diagram_render";

    public override string Description =>
        "Renders a beautiful architecture/system/component diagram from a description (layers, nodes with icon/title/subtitle, " +
        "edges with kind request|realtime|data|async|event). DocGen does the layout and arrow routing and checks it; you get SVG + PNG " +
        "in generated/diagrams/. Load the diagram skill (skill_load name=diagram) first for the spec format and design rules.";

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    public override string InputSchema => """
        {
          "type": "object",
          "properties": {
            "spec": { "type": "object", "description": "{ title, subtitle?, layers: [{id, title, color?}], nodes: [{id, layer, title, subtitle?, icon?, column?}], edges: [{from, to, label?, kind?, both?}] }" },
            "name": { "type": "string", "maxLength": 80, "description": "File name without extension (default: from the title)." },
            "png": { "type": "boolean", "description": "Also write a PNG (default true)." }
          },
          "required": ["spec"],
          "additionalProperties": false
        }
        """;

    /// <summary>Writes only inside the user's own workspace: routine.</summary>
    public Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken)
        => Task.FromResult(new ToolRiskAssessment(RiskLevel, Routine: true));

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var element = args.GetElement("spec") ?? throw new ValidationException("Provide 'spec'.");
        DiagramSpec spec;
        try
        {
            spec = element.Deserialize<DiagramSpec>(ArchitectureDiagram.Json) ?? throw new ValidationException("'spec' is empty.");
        }
        catch (JsonException ex)
        {
            throw new ValidationException("'spec' does not match the diagram format: " + ex.Message);
        }
        var result = await Task.Run(() => ArchitectureDiagram.Render(spec), ct);

        var name = Slug(args.GetString("name") is { Length: > 0 } n ? n : spec.Title);
        var workspace = await Services.Repositories.ResolveAsync(context.UserId, "workspace", ct);
        var folder = Path.Combine(workspace.Root, "generated", "diagrams");
        Directory.CreateDirectory(folder);
        var svgPath = Path.Combine(folder, name + ".svg");
        var existed = File.Exists(svgPath);
        await File.WriteAllTextAsync(svgPath, result.Svg, new UTF8Encoding(false), ct);
        await File.WriteAllTextAsync(Path.Combine(folder, name + ".json"), JsonSerializer.Serialize(spec, ArchitectureDiagram.Json), new UTF8Encoding(false), ct);

        string? pngNote = null;
        var pngWritten = false;
        if (args.GetBool("png") ?? true)
        {
            (pngWritten, pngNote) = await RasterizeAsync(svgPath, Path.Combine(folder, name + ".png"), result.Width, result.Height, ct);
        }

        var rel = $"generated/diagrams/{name}";
        var sb = new StringBuilder();
        sb.AppendLine($"Rendered \"{spec.Title}\": {result.Boxes} boxes in {spec.Layers.Count} layers, {result.Arrows} arrows ({result.Width}x{result.Height} px).");
        sb.AppendLine($"Files: {rel}.svg (vector){(pngWritten ? $", {rel}.png (2x, {result.Width * 2}x{result.Height * 2} px)" : "")}, {rel}.json (spec: edit and render again with the same name).");
        if (pngNote is not null)
        {
            sb.AppendLine("PNG: " + pngNote);
        }
        sb.AppendLine("Layout checks:");
        sb.AppendLine("- boxes never overlap: yes");
        sb.AppendLine(result.BlockedArrows.Count == 0
            ? "- every arrow stays clear of the boxes it does not connect: yes"
            : "- arrows passing through boxes: " + string.Join("; ", result.BlockedArrows) + " (reorder nodes or add a layer so a corridor is free)");
        sb.AppendLine($"- line crossings: {result.Crossings}{(result.Crossings > result.Arrows / 3 ? " (high: reorder nodes within layers or reduce layer-skipping edges)" : "")}");
        if (result.Rerouted > 0)
        {
            sb.AppendLine($"- {result.Rerouted} arrow(s) skip layers and were routed through a free corridor");
        }
        foreach (var w in result.Warnings)
        {
            sb.AppendLine("Warning: " + w);
        }
        sb.AppendLine("You have not seen the image: tell the user where it is and what the checks confirmed; do not claim it looks good.");

        var changes = new List<FileChange> { new() { Path = rel + ".svg", Kind = existed ? "modified" : "created" } };
        if (pngWritten)
        {
            changes.Add(new FileChange { Path = rel + ".png", Kind = "image" });
        }
        return new ToolResult { ToolCallId = call.Id, ToolName = call.Name, Success = true, Content = sb.ToString().TrimEnd(), FileChanges = changes };
    }

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct) => throw new NotSupportedException();

    private static string Slug(string? text)
    {
        var slug = NonWord().Replace((text ?? "").Trim().ToLowerInvariant(), "-").Trim('-');
        return slug.Length == 0 ? "diagram" : slug[..Math.Min(slug.Length, 60)];
    }

    [GeneratedRegex("[^a-z0-9]+")]
    private static partial Regex NonWord();

    /// <summary>
    /// PNG through a headless Chromium browser: the SVG is DocGen's own output (no scripts, text escaped), opened as a
    /// local file with a throwaway profile. Without a browser the SVG is still there.
    /// </summary>
    private async Task<(bool Written, string? Note)> RasterizeAsync(string svg, string png, int width, int height, CancellationToken ct)
    {
        var options = Services.Service<IOptionsMonitor<BrowserOptions>>()?.CurrentValue ?? new BrowserOptions();
        var browser = BrowserService.LocateBrowser(options);
        if (browser is null)
        {
            return (false, "not written (no Edge or Chrome found); the SVG opens in any browser.");
        }
        var profile = Path.Combine(Services.DataDirectory, "scratch", "diagram-render", Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(profile);
        try
        {
            File.Delete(png);
            var psi = new ProcessStartInfo(browser) { UseShellExecute = false, CreateNoWindow = true, RedirectStandardError = true, RedirectStandardOutput = true };
            foreach (var a in new[]
                     {
                         "--headless=new", "--disable-gpu", "--hide-scrollbars", "--no-first-run", "--disable-extensions", "--force-device-scale-factor=2",
                         "--default-background-color=ffffffff", $"--window-size={width},{height}", $"--user-data-dir={profile}", $"--screenshot={png}",
                         new Uri(svg).AbsoluteUri,
                     })
            {
                psi.ArgumentList.Add(a);
            }
            using var process = Process.Start(psi);
            if (process is null)
            {
                return (false, "not written (the browser did not start).");
            }
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
            timeout.CancelAfter(TimeSpan.FromSeconds(60));
            try
            {
                await Task.WhenAll(process.StandardOutput.ReadToEndAsync(timeout.Token), process.StandardError.ReadToEndAsync(timeout.Token));
                await process.WaitForExitAsync(timeout.Token);
            }
            catch (OperationCanceledException) when (!ct.IsCancellationRequested)
            {
                try { process.Kill(entireProcessTree: true); } catch (InvalidOperationException) { }
                return (false, "not written (the browser took too long); the SVG is complete.");
            }
            return File.Exists(png) && new FileInfo(png).Length > 0 ? (true, null) : (false, "not written (the browser produced no image); the SVG is complete.");
        }
        finally
        {
            try { Directory.Delete(profile, recursive: true); } catch (IOException) { } catch (UnauthorizedAccessException) { }
        }
    }
}
