using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using DocGen.Analysis.Commands;
using DocGen.Analysis.Execution;
using DocGen.Analysis.Git;
using DocGen.Analysis.Repositories;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Security;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

/// <summary>
/// Shared plumbing for controlled execution: working-directory resolution inside allowed roots, bounded waiting,
/// compact result presentation and activity records. Every process goes through <see cref="CommandRunner"/>.
/// </summary>
public abstract class ExecutionToolBase(AnalysisServices services) : AnalysisTool(services), IDynamicRiskTool
{
    protected const string CommonProperties = """
        "repository": { "type": "string", "maxLength": 64, "description": "Repository whose tree bounds the working directory. Default: workspace." },
        "workingDirectory": { "type": "string", "maxLength": 500, "description": "Directory relative to the repository root (or an absolute path inside it). Default: the root." },
        "timeoutSeconds": { "type": "integer", "minimum": 5, "maximum": 3600 },
        "waitSeconds": { "type": "integer", "minimum": 0, "maximum": 600, "description": "How long to wait before returning; the command keeps running afterwards." },
        "environment": { "type": "object", "additionalProperties": { "type": "string", "maxLength": 8192 }, "maxProperties": 50, "description": "Extra environment variables (non-secret)." },
        "maxOutputLines": { "type": "integer", "minimum": 1, "maximum": 400 },
        "description": { "type": "string", "maxLength": 200, "description": "Short past-tense summary shown in the activity list, e.g. 'Checked project files and version'." }
        """;

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Sensitive;

    public abstract Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken);

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct) => throw new NotSupportedException();

    /// <summary>Resolves the working directory: a canonical, existing directory inside the repository's root.</summary>
    protected async Task<(RepositoryHandle Repo, string Full, string Display)> WorkingDirectoryAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var repo = await Services.RepositoryAsync(args, context, ct);
        if (!repo.AllowCommands)
        {
            throw new ForbiddenException($"Commands are not enabled for repository '{repo.Name}'.");
        }
        var requested = args.GetString("workingDirectory");
        string full;
        if (string.IsNullOrWhiteSpace(requested) || requested.Trim() is "." or "./")
        {
            full = repo.Root;
        }
        else if (Path.IsPathFullyQualified(requested.Trim()) || ShellTranslator.ConvertPath(requested.Trim()) is var converted && Path.IsPathFullyQualified(converted))
        {
            // An absolute path is accepted only when it lies inside the repository root.
            var candidate = Path.GetFullPath(ShellTranslator.ConvertPath(requested.Trim()));
            var root = Path.GetFullPath(repo.Root).TrimEnd(Path.DirectorySeparatorChar);
            if (!candidate.Equals(root, StringComparison.OrdinalIgnoreCase) && !candidate.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            {
                throw new ForbiddenException($"The working directory must be inside repository '{repo.Name}'. Use 'repository' to select another allowed repository.");
            }
            full = repo.Resolve(Path.GetRelativePath(root, candidate));
        }
        else
        {
            full = repo.Resolve(requested.Trim());
        }
        if (!Directory.Exists(full))
        {
            throw new ValidationException("The working directory does not exist.");
        }
        var display = repo.Relative(full).Replace('\\', '/');
        return (repo, full, display.Length == 0 ? "." : display);
    }

    protected static Dictionary<string, string>? Environment(ToolArguments args)
    {
        if (args.GetElement("environment") is not { ValueKind: JsonValueKind.Object } env)
        {
            return null;
        }
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var p in env.EnumerateObject())
        {
            result[p.Name] = p.Value.ValueKind == JsonValueKind.String ? p.Value.GetString()! : p.Value.GetRawText();
        }
        DocGen.Analysis.Execution.EnvironmentPolicy.RejectLoaderVariables(result);
        return result;
    }

    protected int Timeout(ToolArguments args)
        => Math.Clamp(args.GetInt("timeoutSeconds") ?? Services.Executables.Options.DefaultTimeoutSeconds, 5, Math.Max(5, Services.Executables.Options.MaxTimeoutSeconds));

    private static readonly Regex TreeOverwritingGitInScript = new(
        @"\bgit(?:\.exe)?(?:\s+-c\s+\S+|\s+--?[\w.-]+(?:=\S+)?)*\s+(checkout|switch|rebase|merge|reset|pull|restore|clean|cherry-pick|am)\b",
        RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

    private static readonly HashSet<string> TreeOverwritingGitCommands = new(StringComparer.OrdinalIgnoreCase)
    {
        "checkout", "switch", "rebase", "merge", "reset", "pull", "restore", "clean", "cherry-pick", "am",
    };

    /// <summary>The git sub-command (checkout, rebase, merge, reset…) in a git argument list that can overwrite local work, or null.</summary>
    public static string? TreeOverwritingGitOperation(IReadOnlyList<string> gitArguments)
    {
        for (var i = 0; i < gitArguments.Count; i++)
        {
            var a = gitArguments[i];
            if (a is "-c" or "-C" or "--git-dir" or "--work-tree")
            {
                i++;
                continue;
            }
            if (a.StartsWith('-'))
            {
                continue;
            }
            return TreeOverwritingGitCommands.Contains(a) ? a.ToLowerInvariant() : null;
        }
        return null;
    }

    /// <summary>The first tree-overwriting git invocation in a PowerShell script, or null.</summary>
    public static string? TreeOverwritingGitOperation(string script)
        => TreeOverwritingGitInScript.Match(script) is { Success: true } m ? m.Groups[1].Value.ToLowerInvariant() : null;

    /// <summary>
    /// Dirty-tree protection: before a checkout/switch/rebase/merge/reset/pull/restore/clean, inspect the working tree; when
    /// local changes could be overwritten or discarded the call is refused with the files at risk (the user decides).
    /// </summary>
    protected async Task<ToolRiskAssessment> GuardDirtyTreeAsync(ToolRiskAssessment assessment, string? operation, RepositoryHandle repo, string workingDirectory,
        ToolExecutionContext context, CancellationToken ct)
    {
        if (operation is null || assessment.DenyReason is not null || GitService.FindGitRoot(workingDirectory) is not { } gitRoot || !Services.Executables.IsAllowed("git"))
        {
            return assessment;
        }
        var status = await new GitService(Services).StatusAsync(new GitContext(context.UserId, repo, gitRoot, context.RunId, context.ConversationId), ct);
        var findings = (assessment.Findings ?? []).ToList();
        if (status.Clean)
        {
            findings.Add($"dirty-tree check before git {operation}: working tree clean");
            return assessment with { Findings = findings };
        }
        var files = string.Join(", ", status.Files.Take(8).Select(f => $"{f.Path} ({f.Kind})")) + (status.Changed > 8 ? $" and {status.Changed - 8} more" : "");
        findings.Add($"dirty-tree check before git {operation}: {status.Changed} local change(s)");
        return assessment with
        {
            Findings = findings,
            DenyReason = $"git {operation} could overwrite or discard local work — {status.Changed} changed file(s): {files}. DocGen does not run it on a dirty tree. " +
                         "Explain the risk to the user and ask whether to commit or stash these changes first (or let them run it themselves).",
        };
    }

    /// <summary>
    /// Path-aware approval for scripts. The working directory says where a command <em>starts</em>, not where it acts:
    /// <c>Remove-Item "$env:APPDATA\…" -Recurse</c> run from the chat's folder is not work in the chat's folder.
    /// Every location the script deletes, moves or writes (see <see cref="MutationTargets"/>) is checked against the
    /// folders DocGen works in (the user's workspace and the accessible repositories):
    /// <list type="bullet">
    /// <item>inside the chat's folder: unchanged;</item>
    /// <item>inside another of DocGen's folders, or the temp folder: not routine ("work in other folders");</item>
    /// <item>a write outside all of them: a system change (asks in every default mode);</item>
    /// <item>a delete or move outside all of them, or a recursive delete whose location is only known at run time:
    /// destructive — always asks, whatever the mode or rules.</item>
    /// </list>
    /// The findings name the paths, so the approval card shows the user exactly what would be removed.
    /// </summary>
    protected async Task<ToolRiskAssessment> GuardTargetsAsync(ToolRiskAssessment assessment, string script, RepositoryHandle repo, string workingDirectory,
        ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        if (assessment.DenyReason is not null)
        {
            return assessment;
        }
        var overrides = Environment(args);
        string? Env(string name) => overrides is not null && overrides.TryGetValue(name, out var v) ? v : System.Environment.GetEnvironmentVariable(name);
        var targets = MutationTargets.Find(script, workingDirectory, Env);
        if (targets.Count == 0)
        {
            return assessment;
        }
        var roots = await Services.Repositories.ListAsync(context.UserId, ct);
        var temp = Path.GetFullPath(Path.GetTempPath());
        var findings = (assessment.Findings ?? []).ToList();
        bool outsideDelete = false, outsideWrite = false, elsewhere = false;
        foreach (var t in targets)
        {
            if (t.Path is null)
            {
                if (t.Delete && t.Recursive)
                {
                    findings.Insert(0, $"{t.Command} deletes a folder tree whose location is only known at run time ({AnalysisServices.Clip(t.Raw, 80)}): treated as outside DocGen's folders");
                    outsideDelete = true;
                }
                continue;
            }
            if (MutationTargets.IsInside(t.Path, repo.Root))
            {
                continue;
            }
            if (roots.Where(r => MutationTargets.IsInside(t.Path, r.Root)).OrderByDescending(r => r.Root.Length).FirstOrDefault() is { } other)
            {
                findings.Insert(0, $"{t.Command} changes {t.Path} in the folder '{other.Name}', not this chat's folder");
                elsewhere = true;
                continue;
            }
            if (MutationTargets.IsInside(t.Path, temp) && !t.Path.TrimEnd('\\', '/').Equals(temp.TrimEnd('\\', '/'), StringComparison.OrdinalIgnoreCase))
            {
                findings.Insert(0, $"{t.Command} changes {t.Path} in the temporary folder");
                elsewhere = true;
                continue;
            }
            findings.Insert(0, $"{t.Command} {(t.Delete ? "deletes" : "writes")} {t.Path}{(t.Recursive ? " and everything under it" : "")} — outside every folder DocGen works in");
            if (t.Delete)
            {
                outsideDelete = true;
            }
            else
            {
                outsideWrite = true;
            }
        }
        if (outsideDelete)
        {
            return assessment with { Findings = findings, Risk = ToolRiskLevel.Destructive, Routine = false, Summary = "deletes files outside the folders DocGen works in" };
        }
        if (outsideWrite)
        {
            return assessment with { Findings = findings, Routine = false, SystemOrNetwork = true, Category = ApprovalCategories.SystemChanges, Summary = "changes files outside the folders DocGen works in" };
        }
        return elsewhere ? assessment with { Findings = findings, Routine = false } : assessment;
    }

    /// <summary>
    /// Balanced mode runs a command without a prompt when it only reads, or when it runs in the chat's own folder and
    /// neither installs software, uses the network nor changes the system (as a coding assistant would: builds, migrations, local tools
    /// and file changes in the project just run). Git commands that modify a repository keep asking.
    /// </summary>
    protected static bool IsRoutine(ExecutionAssessment inspected, RepositoryHandle repo, ToolExecutionContext context, bool git = false)
        => inspected.Tier == ExecutionTier.ReadOnly
           || inspected.Tier <= ExecutionTier.Elevated && !git && !inspected.ChangesSystemOrNetwork && AnalysisServices.IsChatFolder(repo, context);

    /// <summary>install, network or system for a command that does any of those (the approval category it falls in).</summary>
    protected static string? SystemCategory(ExecutionAssessment inspected)
    {
        if (!inspected.ChangesSystemOrNetwork)
        {
            // Only reading, plus plain GETs of public pages: "Reading the web", like http_request.
            return PowerShellInspector.IsWebReadOnly(inspected) ? ApprovalCategories.WebReads : null;
        }
        bool Any(params string[] words) => inspected.Findings.Any(f => f.Tier >= ExecutionTier.Elevated && words.Any(w => f.Category.Contains(w, StringComparison.OrdinalIgnoreCase)));
        return Any("install") ? ApprovalCategories.Install
            : Any("network", "download", "remot") ? ApprovalCategories.Network
            : ApprovalCategories.SystemChanges;
    }

    protected static ToolRiskAssessment Assessment(ExecutionAssessment inspected, string capability, bool enforceBlocked, string? prefix = null)
    {
        var findings = inspected.Describe().ToList();
        if (prefix is not null)
        {
            findings.Insert(0, prefix);
        }
        var deny = inspected.Tier == ExecutionTier.Blocked && enforceBlocked
            ? "the command contains operations DocGen never runs (" + string.Join(", ", inspected.Findings.Where(f => f.Tier == ExecutionTier.Blocked).Select(f => f.Command).Take(4)) + ")"
            : null;
        return new ToolRiskAssessment(inspected.Tier == ExecutionTier.Blocked && !enforceBlocked ? ToolRiskLevel.Destructive : inspected.Risk, capability, findings, deny, inspected.Summary,
            SystemOrNetwork: inspected.ChangesSystemOrNetwork, Category: SystemCategory(inspected));
    }

    /// <summary>Starts the process, waits a bounded time, and turns the command record into a compact tool result.</summary>
    protected async Task<ToolResult> StartAndReportAsync(ToolCall call, ProcessLaunch launch, ToolArguments args, ToolExecutionContext context, string? preamble, CancellationToken ct)
    {
        var runner = Services.Commands;
        var record = await runner.StartProcessAsync(context.UserId, launch, ct);
        var maxWait = Math.Max(5, Services.AgentOptions.ToolTimeoutSeconds - 5);
        var wait = TimeSpan.FromSeconds(Math.Clamp(args.GetInt("waitSeconds") ?? maxWait, 0, maxWait));
        if (wait > TimeSpan.Zero)
        {
            record = await runner.WaitAsync(context.UserId, record.Id, wait, ct);
        }
        else
        {
            record = await runner.GetAsync(context.UserId, record.Id, ct);
        }
        var lines = Math.Clamp(args.GetInt("maxOutputLines") ?? Services.Executables.Options.ResultOutputLines, 1, 400);
        var content = Describe(record, runner, context.UserId, lines, preamble);
        var result = new ToolResult { ToolCallId = call.Id, ToolName = call.Name, Success = !record.IsFinal || record.Status == CommandStatus.Succeeded, Content = content };
        if (record.IsFinal && record.Status != CommandStatus.Succeeded)
        {
            result.Error = $"Command {record.Status.ToString().ToLowerInvariant()}{(record.ExitCode is { } code ? $" (exit {code})" : "")}";
        }
        result.Activities = [Activity(record)];
        return result;
    }

    public static ActivityRecord Activity(CommandRecord record)
    {
        var type = record.IsFinal ? "command_completed" : "command_running";
        var title = record.Description ?? (record.Kind == CommandKinds.PowerShell ? "Ran PowerShell" : "Ran " + (record.Executable ?? "command"));
        var activity = new ActivityRecord
        {
            Type = type,
            Title = title,
            Detail = record.Kind == CommandKinds.PowerShell ? "PS> " + FirstLines(record.Script ?? record.CommandLine, 3) : "> " + record.CommandLine,
        };
        activity.Data["commandId"] = record.Id;
        activity.Data["kind"] = record.Kind;
        activity.Data["executable"] = record.Executable ?? "";
        activity.Data["workingDirectory"] = $"{record.Repository}:{record.WorkingDirectory ?? "."}";
        activity.Data["status"] = record.Status.ToString();
        if (record.Shell is { } shell)
        {
            activity.Data["shell"] = shell;
        }
        if (record.ExitCode is { } exit)
        {
            activity.Data["exitCode"] = exit.ToString(System.Globalization.CultureInfo.InvariantCulture);
        }
        activity.Data["durationMs"] = record.DurationMs.ToString(System.Globalization.CultureInfo.InvariantCulture);
        if (record.Risk is { } risk)
        {
            activity.Data["risk"] = risk;
        }
        return activity;
    }

    /// <summary>Compact presentation: summary line, what ran, where, the result, the last output lines and how to see more.</summary>
    public static string Describe(CommandRecord record, CommandRunner runner, string userId, int maxLines, string? preamble = null)
    {
        var sb = new StringBuilder();
        var mark = !record.IsFinal ? "…" : record.Status == CommandStatus.Succeeded ? "✓" : "✗";
        sb.AppendLine($"{mark} {record.Description ?? (record.Kind == CommandKinds.PowerShell ? "PowerShell command" : "Command")} — {Status(record)}");
        if (preamble is not null)
        {
            sb.AppendLine(preamble.TrimEnd());
        }
        sb.AppendLine($"{(record.Shell ?? record.Executable ?? "process")} · working directory: {record.Repository}:{record.WorkingDirectory ?? "."} · command {record.Id}");
        sb.AppendLine(record.Kind == CommandKinds.PowerShell ? "PS> " + FirstLines(record.Script ?? "", 12).Replace("\n", "\n    ") : "> " + record.CommandLine);
        if (record.RiskFindings.Count > 0)
        {
            sb.AppendLine($"Risk: {record.Risk} — {string.Join("; ", record.RiskFindings.Take(4))}");
        }
        var (lines, total) = runner.ReadOutput(userId, record.Id, Math.Max(1, record.OutputLines - maxLines + 1), maxLines);
        if (total == 0 && record.Tail.Count > 0)
        {
            lines = record.Tail.TakeLast(maxLines).Select((t, i) => ((long)i + 1, t)).ToList();
            total = record.OutputLines;
        }
        if (lines.Count == 0)
        {
            sb.AppendLine(record.IsFinal ? "(no output)" : "(no output yet — a quiet process is not necessarily hung)");
        }
        else
        {
            sb.AppendLine(lines.Count < record.OutputLines ? $"Output (last {lines.Count} of {record.OutputLines:N0} lines{(record.StderrLines > 0 ? $", {record.StderrLines} on stderr" : "")}):" : $"Output ({record.OutputLines} lines{(record.StderrLines > 0 ? $", {record.StderrLines} on stderr" : "")}):");
            foreach (var (_, text) in lines)
            {
                sb.Append("  ").AppendLine(text.Length > 400 ? text[..400] + "…" : text);
            }
        }
        if (record.Tests is { } tests)
        {
            sb.AppendLine($"Tests {tests.Result}: {tests.Passed ?? 0} passed, {tests.Failed ?? tests.Failures.Count} failed, {tests.Skipped ?? 0} skipped.");
        }
        else if (record.Build is { } build)
        {
            sb.AppendLine($"Build {build.Result}: {build.ErrorCount} errors, {build.WarningCount} warnings.");
        }
        sb.Append(record.IsFinal
            ? $"Full output: command_status commandId={record.Id} (lineStart / search)."
            : $"Still running. Check with command_status commandId={record.Id} waitSeconds=…; stop with process_stop commandId={record.Id}.");
        return sb.ToString();
    }

    private static string Status(CommandRecord r) => r.IsFinal
        ? $"{r.Status}{(r.ExitCode is { } c ? $", exit code {c}" : "")}, {r.DurationMs / 1000.0:0.0} s{(r.CancelReason is { } reason ? $" ({reason})" : "")}"
        : $"running for {(DateTime.UtcNow - (r.StartedAt ?? r.CreatedAt)).TotalSeconds:0} s{(r.LastHeartbeatAt is { } hb ? $", last heartbeat {hb:HH:mm:ss} UTC" : "")}";

    protected static string FirstLines(string text, int max)
    {
        var lines = text.Replace("\r\n", "\n").Split('\n').Where(l => l.Trim().Length > 0).ToList();
        var shown = string.Join("\n", lines.Take(max).Select(l => l.Length > 240 ? l[..240] + "…" : l));
        return lines.Count > max ? shown + $"\n… ({lines.Count - max} more lines)" : shown;
    }
}

/// <summary>Runs a PowerShell script (pwsh, or Windows PowerShell when allowed) as an owned, observable command.</summary>
public sealed class PowerShellTool(AnalysisServices services) : ExecutionToolBase(services)
{
    public override string Name => "powershell";

    public override string Description =>
        "Runs a PowerShell script (PowerShell 7 when installed, otherwise Windows PowerShell when allowed) in a working directory inside a repository, " +
        "with live output, timeout and cancellation. Pipelines work natively. DocGen inspects the script first: read-only scripts, scripts that modify " +
        "files, and scripts that start processes/use the network/change the system need increasingly strong approval; dangerous operations are blocked. " +
        "Prefer DocGen's native tools (directory_stats, line_endings, search_code, read_source_range…) when they give the answer directly. " +
        "If the snippet is POSIX shell (bash), set sourceShell=bash: simple pipelines are translated and the translation is shown.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            "script": { "type": "string", "minLength": 1, "maxLength": 100000 },
            "sourceShell": { "type": "string", "enum": ["powershell", "bash"], "description": "Language of 'script'. bash snippets are translated to PowerShell when possible." },
            {{CommonProperties}}
          },
          "required": ["script"],
          "additionalProperties": false
        }
        """;

    public override async Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken ct)
    {
        var args = ToolArguments.Parse(call);
        var (script, note) = Prepare(args);
        var (repo, full, _) = await WorkingDirectoryAsync(args, context, ct);
        var inspected = PowerShellInspector.Inspect(script, Services.Executables.Options.BlockedCommands);
        var assessment = Assessment(inspected, Capabilities.ExecutePowerShell, Services.Executables.Options.EnforceBlockedCommands, note)
            with { Routine = IsRoutine(inspected, repo, context, git: TreeOverwritingGitOperation(script) is not null) };
        assessment = await GuardTargetsAsync(assessment, script, repo, full, args, context, ct);
        return await GuardDirtyTreeAsync(assessment, TreeOverwritingGitOperation(script), repo, full, context, ct);
    }

    private (string Script, string? Note) Prepare(ToolArguments args)
    {
        var script = args.RequireString("script");
        var source = args.GetString("sourceShell") ?? (ShellTranslator.LooksLikePosixShell(script) ? "bash" : "powershell");
        if (source != "bash")
        {
            return (script, null);
        }
        var ps = Services.Executables.DetectPowerShell();
        var translation = ShellTranslator.Translate(script, ps?.SupportsPipelineChains ?? false);
        if (!translation.Success)
        {
            throw new ValidationException($"This looks like POSIX shell and could not be translated safely: {translation.Reason}. " +
                                          "Rewrite it in PowerShell (e.g. Set-Location, Select-String, Sort-Object, Select-Object -First) or use DocGen's native tools.");
        }
        return (translation.PowerShell, "translated from bash" + (translation.Notes.Count > 0 ? " (" + string.Join("; ", translation.Notes) + ")" : ""));
    }

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var ps = Services.Executables.DetectPowerShell()
                 ?? throw new DocGenException("POWERSHELL_UNAVAILABLE", "No allowed PowerShell is installed (pwsh, or powershell.exe with AllowWindowsPowerShellFallback).", 404);
        var (script, note) = Prepare(args);
        var (repo, full, display) = await WorkingDirectoryAsync(args, context, ct);
        var inspected = PowerShellInspector.Inspect(script, Services.Executables.Options.BlockedCommands);
        if (inspected.Tier == ExecutionTier.Blocked && Services.Executables.Options.EnforceBlockedCommands)
        {
            // Defence in depth: the permission policy already denies these.
            throw new ForbiddenException("The script contains operations DocGen never runs.");
        }
        var scriptPath = WriteScriptFile(context.UserId, script, full);
        var preamble = note is null ? null : $"Translated from bash:\n  {args.RequireString("script").Trim().Replace("\n", "\n  ")}\nExecuted as PowerShell.";
        return await StartAndReportAsync(call, new ProcessLaunch
        {
            Kind = CommandKinds.PowerShell, ExecutableName = ps.Name, ExecutablePath = ps.Path,
            Arguments = ["-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", scriptPath],
            WorkingDirectory = full, DisplayWorkingDirectory = display, Repository = repo.Name,
            DisplayCommand = $"{ps.Name} -NoProfile -NonInteractive -File <script>", Script = script, Description = args.GetString("description"),
            Shell = ps.DisplayName, Environment = Environment(args), TimeoutSeconds = Timeout(args), RunId = context.RunId, ConversationId = context.ConversationId,
            Risk = inspected.Risk.ToString(), RiskFindings = inspected.Describe().ToList(),
        }, args, context, preamble, ct);
    }

    /// <summary>
    /// Writes the script to data/scratch/powershell (UTF-8 with BOM so Windows PowerShell reads it correctly) with a
    /// small preamble: UTF-8 output, no progress bars, start in the working directory, and propagate the exit code of
    /// the last native command. The execution policy bypass is process-scoped only.
    /// </summary>
    private string WriteScriptFile(string userId, string script, string workingDirectory)
    {
        var dir = Path.Combine(Services.DataDirectory, "scratch", "powershell", Ids.Require(userId, "user id"));
        Directory.CreateDirectory(dir);
        var path = Path.Combine(dir, Guid.NewGuid().ToString("N") + ".ps1");
        var body = new StringBuilder();
        body.AppendLine("$ErrorActionPreference = 'Continue'");
        body.AppendLine("$ProgressPreference = 'SilentlyContinue'");
        body.AppendLine("try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }");
        body.AppendLine("$OutputEncoding = [System.Text.Encoding]::UTF8");
        body.AppendLine($"Set-Location -LiteralPath '{workingDirectory.Replace("'", "''")}'");
        body.AppendLine("$global:LASTEXITCODE = 0");
        body.AppendLine(script);
        body.AppendLine("if ($global:LASTEXITCODE -is [int] -and $global:LASTEXITCODE -ne 0) { exit $global:LASTEXITCODE }");
        File.WriteAllText(path, body.ToString(), new UTF8Encoding(encoderShouldEmitUTF8Identifier: true));
        return path;
    }
}

/// <summary>Creates or replaces a reusable .ps1 script. Writing never grants permission to execute it.</summary>
public sealed class ScriptWriteTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "script_write";

    public override string Description =>
        "Creates or replaces a PowerShell script file (.ps1) in a repository, e.g. scripts/reproduce-bug.ps1. This only writes the file (normal file-write " +
        "permissions); running it is a separate action (script_run) with its own approval.";

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "path": { "type": "string", "minLength": 5, "maxLength": 400 },
            "content": { "type": "string", "maxLength": 200000 }
          },
          "required": ["path", "content"],
          "additionalProperties": false
        }
        """;

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var repo = await Services.RepositoryAsync(args, context, ct);
        if (!repo.AllowWrite)
        {
            throw new ForbiddenException($"Writes are not enabled for repository '{repo.Name}'.");
        }
        var relative = args.RequireString("path");
        if (!relative.EndsWith(".ps1", StringComparison.OrdinalIgnoreCase))
        {
            throw new ValidationException("script_write only writes .ps1 files.");
        }
        var full = repo.Resolve(relative);
        var existed = File.Exists(full);
        var oldLines = existed ? File.ReadAllLines(full).Length : 0;
        var content = args.GetString("content") ?? "";
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        await File.WriteAllTextAsync(full, content, new UTF8Encoding(encoderShouldEmitUTF8Identifier: true), ct);
        var shown = repo.Relative(full).Replace('\\', '/');
        var inspected = PowerShellInspector.Inspect(content);
        var newLines = content.Split('\n').Length;
        return new ToolResult
        {
            ToolCallId = call.Id, ToolName = call.Name, Success = true,
            Content = $"{(existed ? "Replaced" : "Created")} {repo.Name}:{shown} ({newLines} lines). Not executed. Inspection: {inspected.Summary}" +
                      (inspected.Findings.Count > 0 ? " — " + string.Join("; ", inspected.Describe().Take(5)) : "") + $". Run it with script_run path={shown}.",
            FileChanges = [new FileChange { Path = $"{repo.Name}:{shown}", Kind = existed ? "modified" : "created", LinesAdded = newLines, LinesRemoved = oldLines }],
            Activities = [new ActivityRecord { Type = "script_written", Title = $"{(existed ? "Updated" : "Created")} script {shown}", Data = { ["path"] = $"{repo.Name}:{shown}", ["risk"] = inspected.Risk.ToString() } }],
        };
    }

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct) => throw new NotSupportedException();
}

/// <summary>Executes an existing .ps1 file from a repository (inspected at execution time).</summary>
public sealed class ScriptRunTool(AnalysisServices services) : ExecutionToolBase(services)
{
    public override string Name => "script_run";

    public override string Description =>
        "Runs an existing PowerShell script file (.ps1) from a repository with optional arguments. The file's current content is inspected and the " +
        "approval requirement follows from what it does. Output streams live; long scripts keep running in the background (command_status).";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            "path": { "type": "string", "minLength": 5, "maxLength": 400 },
            "arguments": { "type": "array", "items": { "type": "string", "maxLength": 2000 }, "maxItems": 50 },
            {{CommonProperties}}
          },
          "required": ["path"],
          "additionalProperties": false
        }
        """;

    private async Task<(RepositoryHandle Repo, string Full, string Relative, string Content)> ScriptAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var repo = await Services.RepositoryAsync(args, context, ct);
        var full = repo.Resolve(args.RequireString("path"));
        if (!full.EndsWith(".ps1", StringComparison.OrdinalIgnoreCase) || !File.Exists(full))
        {
            throw new ValidationException("path must be an existing .ps1 file in the repository.");
        }
        if (new FileInfo(full).Length > 1024 * 1024)
        {
            throw new ValidationException("The script is larger than 1 MB.");
        }
        return (repo, full, repo.Relative(full).Replace('\\', '/'), await File.ReadAllTextAsync(full, ct));
    }

    public override async Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken ct)
    {
        var args = ToolArguments.Parse(call);
        var (_, _, relative, content) = await ScriptAsync(args, context, ct);
        var (repo, cwd, _) = await WorkingDirectoryAsync(args, context, ct);
        var inspected = PowerShellInspector.Inspect(content, Services.Executables.Options.BlockedCommands);
        var assessment = Assessment(inspected, Capabilities.ExecutePowerShell, Services.Executables.Options.EnforceBlockedCommands, $"runs script {relative}")
            with { Routine = IsRoutine(inspected, repo, context, git: TreeOverwritingGitOperation(content) is not null) };
        return await GuardTargetsAsync(assessment, content, repo, cwd, args, context, ct);
    }

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var ps = Services.Executables.DetectPowerShell()
                 ?? throw new DocGenException("POWERSHELL_UNAVAILABLE", "No allowed PowerShell is installed.", 404);
        var (repo, full, relative, content) = await ScriptAsync(args, context, ct);
        var (_, cwd, display) = await WorkingDirectoryAsync(args, context, ct);
        var inspected = PowerShellInspector.Inspect(content, Services.Executables.Options.BlockedCommands);
        if (inspected.Tier == ExecutionTier.Blocked && Services.Executables.Options.EnforceBlockedCommands)
        {
            throw new ForbiddenException("The script contains operations DocGen never runs.");
        }
        var scriptArgs = args.GetElement("arguments") is { ValueKind: JsonValueKind.Array } a ? a.EnumerateArray().Select(e => e.GetString() ?? "").ToList() : [];
        return await StartAndReportAsync(call, new ProcessLaunch
        {
            Kind = CommandKinds.PowerShell, ExecutableName = ps.Name, ExecutablePath = ps.Path,
            Arguments = ["-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", full, .. scriptArgs],
            WorkingDirectory = cwd, DisplayWorkingDirectory = display, Repository = repo.Name,
            DisplayCommand = $"{ps.Name} -File {relative} {string.Join(' ', scriptArgs)}".TrimEnd(), Script = content, ScriptPath = relative,
            Description = args.GetString("description") ?? $"Ran script {relative}", Shell = ps.DisplayName, Environment = Environment(args), TimeoutSeconds = Timeout(args),
            RunId = context.RunId, ConversationId = context.ConversationId, Risk = inspected.Risk.ToString(), RiskFindings = inspected.Describe().ToList(),
        }, args, context, null, ct);
    }
}

/// <summary>Starts an allow-listed executable (git, dotnet, or one an administrator configured) with structured arguments.</summary>
public sealed class RunProcessTool(AnalysisServices services) : ExecutionToolBase(services)
{
    public override string Name => "run_process";

    public override string Description =>
        "Runs an allow-listed executable (e.g. git, dotnet, or programs an administrator enabled in DocGen:Execution:Executables) with an argument list — " +
        "no shell, no string parsing. Examples: git status --short; git diff --stat; git log -n 5 --oneline; dotnet --info. Read-only git commands are " +
        "low risk; commands that change the repository, run code or use the network need approval. PowerShell uses the powershell tool.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            "executable": { "type": "string", "minLength": 1, "maxLength": 64 },
            "arguments": { "type": "array", "items": { "type": "string", "maxLength": 4000 }, "maxItems": 100 },
            {{CommonProperties}}
          },
          "required": ["executable"],
          "additionalProperties": false
        }
        """;

    private (ResolvedExecutable Exe, List<string> Args, (string Category, ExecutionTier Tier) Class) Parse(ToolArguments args)
    {
        var name = args.RequireString("executable").Trim();
        name = Path.GetFileNameWithoutExtension(name);
        var exe = Services.Executables.Resolve(name);
        if (exe.Kind == "powershell")
        {
            throw new ValidationException("Use the powershell tool to run PowerShell.");
        }
        var list = args.GetElement("arguments") is { ValueKind: JsonValueKind.Array } a ? a.EnumerateArray().Select(e => e.GetString() ?? "").ToList() : [];
        if (list.Any(x => x.Contains('\0')))
        {
            throw new ValidationException("Arguments cannot contain NUL.");
        }
        return (exe, list, ProcessClassifier.Classify(exe.Kind, exe.Name, list));
    }

    public override async Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken ct)
    {
        var args = ToolArguments.Parse(call);
        var (exe, list, (category, tier)) = Parse(args);
        var (repo, full, _) = await WorkingDirectoryAsync(args, context, ct);
        var inspected = new ExecutionAssessment();
        inspected.Add(category, "process", tier, 0);
        var assessment = Assessment(inspected, Capabilities.ExecuteProcess, true) with { Routine = IsRoutine(inspected, repo, context, git: exe.Kind == "git" && tier != ExecutionTier.ReadOnly) };
        return await GuardDirtyTreeAsync(assessment, exe.Kind == "git" ? TreeOverwritingGitOperation(list) : null, repo, full, context, ct);
    }

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (exe, list, (category, tier)) = Parse(args);
        var (repo, full, display) = await WorkingDirectoryAsync(args, context, ct);
        var arguments = exe.Kind == "git" ? ["-c", "color.ui=never", "-c", "core.pager=cat", .. list] : list;
        return await StartAndReportAsync(call, new ProcessLaunch
        {
            Kind = CommandKinds.Process, ExecutableName = exe.Name, ExecutablePath = exe.Path, Arguments = arguments, WorkingDirectory = full,
            DisplayWorkingDirectory = display, Repository = repo.Name,
            DisplayCommand = exe.Name + " " + string.Join(' ', list.Select(x => x.Length == 0 || x.Contains(' ') ? "\"" + x + "\"" : x)),
            Description = args.GetString("description"), Environment = Environment(args), TimeoutSeconds = Timeout(args), RunId = context.RunId,
            ConversationId = context.ConversationId, Risk = new ExecutionAssessment { Tier = tier }.Risk.ToString(), RiskFindings = [category],
            ParseAs = exe.Kind == "dotnet" && list.FirstOrDefault() is "test" ? CommandKinds.Test : exe.Kind == "dotnet" && list.FirstOrDefault() is "build" ? CommandKinds.Build : null,
        }, args, context, null, ct);
    }
}

/// <summary>Lists processes DocGen started for this user (commands, servers, browsers).</summary>
public sealed class ProcessListTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "process_list";

    public override string Description => "Lists the processes DocGen started for you that are still running (commands, development servers, browsers) with command id, run, process id and working directory.";

    public override string InputSchema => """{ "type": "object", "properties": {}, "additionalProperties": false }""";

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var active = Services.Commands.ListActive(context.UserId);
        if (active.Count == 0)
        {
            return Task.FromResult("No processes started by DocGen are running for you.");
        }
        var sb = new StringBuilder($"{active.Count} running process(es) owned by you:\n");
        foreach (var r in active.OrderBy(r => r.CreatedAt))
        {
            sb.AppendLine($"- command {r.Id} [{r.Kind}] pid {r.ProcessId?.ToString() ?? "(starting)"} · {r.Executable ?? "dotnet"} · {r.Repository}:{r.WorkingDirectory ?? "."} · " +
                          $"started {r.StartedAt:HH:mm:ss} UTC · run {r.RunId ?? "-"}{(r.ServerId is null ? "" : " · server " + r.ServerId)} — {Clip(r.Description ?? r.CommandLine)}");
        }
        return Task.FromResult(sb.ToString());
    }

    private static string Clip(string text) => text.Length > 160 ? text[..160] + "…" : text;
}

/// <summary>Stops (kills the process tree of) a process DocGen started for this user. Never arbitrary PIDs.</summary>
public sealed class ProcessStopTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "process_stop";

    public override string Description => "Stops a command or process DocGen started for you (kills its whole process tree), by commandId. Processes DocGen did not start cannot be stopped.";

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    public override string InputSchema => """
        {
          "type": "object",
          "properties": { "commandId": { "type": "string", "minLength": 1, "maxLength": 64 }, "reason": { "type": "string", "maxLength": 200 } },
          "required": ["commandId"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var id = args.RequireString("commandId");
        var stopped = await Services.Commands.CancelAsync(context.UserId, id, args.GetString("reason") ?? "stopped by process_stop");
        if (!stopped)
        {
            var record = await Services.Commands.GetAsync(context.UserId, id, ct);
            return $"Command {id} is not running (status {record.Status}).";
        }
        var final = await Services.Commands.WaitAsync(context.UserId, id, TimeSpan.FromSeconds(20), ct, cancelOnAbort: false);
        return $"Stopped command {id}: {final.Status}{(final.IsFinal ? "" : " (still stopping)")} after {final.DurationMs / 1000.0:0.0} s; process tree killed.";
    }
}
