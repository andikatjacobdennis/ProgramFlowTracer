using System.Text;
using DocGen.Analysis.Commands;
using DocGen.Analysis.Indexing;
using DocGen.Analysis.Investigations;
using DocGen.Analysis.Repositories;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

/// <summary>Starts a build/test command, waits a bounded time and reports the (parsed) outcome.</summary>
public abstract class CommandToolBase(AnalysisServices services) : AnalysisTool(services), IDynamicRiskTool
{
    /// <summary>Runs code from the repository (MSBuild targets, tests): approval required by default.</summary>
    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Sensitive;

    /// <summary>Builds and tests execute project code, so role policy for running processes applies.</summary>
    public async Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken)
    {
        // Building/testing code in the chat's own folder is routine; in another registered repository it runs that repository's code.
        var repo = await Services.RepositoryAsync(ToolArguments.Parse(call), context, cancellationToken);
        return new ToolRiskAssessment(ToolRiskLevel.Sensitive, Capabilities.ExecuteProcess, ["runs repository code (dotnet restore/build/test)"], Summary: Name,
            Routine: AnalysisServices.IsChatFolder(repo, context));
    }

    protected async Task<string> StartAndWaitAsync(RepositoryHandle repo, CommandRequest request, int? waitSeconds, ToolExecutionContext context, string? note, CancellationToken ct)
    {
        var record = await Services.Commands.StartAsync(context.UserId, repo, request, ct);
        var maxWait = Math.Max(5, Services.AgentOptions.ToolTimeoutSeconds - 5);
        var wait = TimeSpan.FromSeconds(Math.Clamp(waitSeconds ?? maxWait, 1, maxWait));
        // A Stop of the run cancels ct, which cancels the command too.
        record = await Services.Commands.WaitAsync(context.UserId, record.Id, wait, ct);
        var text = Describe(record, note);
        if (record.IsFinal && context.ConversationId is not null
            && await Services.Investigations.GetActiveForConversationAsync(context.UserId, context.ConversationId, CancellationToken.None) is { } active)
        {
            await Services.Investigations.AddEvidenceAsync(context.UserId, active.Id, EvidenceKinds.Result, InvestigationService.DescribeCommand(record),
                "command:" + record.Id, null, context.RunId, automatic: true, CancellationToken.None);
        }
        return text;
    }

    internal static string Describe(CommandRecord record, string? note = null)
    {
        var sb = new StringBuilder();
        if (note is not null)
        {
            sb.AppendLine(note);
        }
        sb.AppendLine($"Command {record.Id}: `{record.CommandLine}` — {record.Status}{(record.ExitCode is { } c ? $" (exit {c})" : "")}, {record.DurationMs / 1000.0:0.0} s, {record.OutputLines:N0} output lines.");
        if (!record.IsFinal)
        {
            sb.AppendLine($"Still running (last heartbeat {record.LastHeartbeatAt:HH:mm:ss} UTC). Check again with command_status commandId={record.Id} (wait up to a minute per call).");
        }
        if (record.CancelReason is { } reason)
        {
            sb.AppendLine("Reason: " + reason);
        }
        if (record.Build is { } b)
        {
            sb.AppendLine($"Build {b.Result}: {b.ErrorCount} errors, {b.WarningCount} warnings.");
            foreach (var e in b.Errors.Take(10))
            {
                sb.AppendLine($"  {e.Code} {e.File}:{e.Line} {AnalysisServices.Clip(e.Message, 200)}");
            }
        }
        if (record.Tests is { } t)
        {
            sb.AppendLine($"Tests {t.Result}: {t.Passed ?? 0} passed, {t.Failed ?? t.Failures.Count} failed, {t.Skipped ?? 0} skipped{(t.Total is { } total ? $" of {total}" : "")}.");
            foreach (var f in t.Failures.Take(10))
            {
                sb.AppendLine($"  FAILED {f.Name}: {f.ExceptionType} {AnalysisServices.Clip(f.Message?.Split('\n')[0], 200)}{(f.TopApplicationFrame is null ? "" : $" at {f.TopApplicationFrame}{(f.Line is { } l ? $" line {l}" : "")}")}");
            }
            if (Diagnostics.TestFailure.WrongReasonNote(t.Failures) is { } wrongReason)
            {
                sb.AppendLine("  " + wrongReason);
            }
            if (t.Build is { ErrorCount: > 0 } tb)
            {
                foreach (var e in tb.Errors.Take(5))
                {
                    sb.AppendLine($"  build {e.Code} {e.File}:{e.Line} {AnalysisServices.Clip(e.Message, 200)}");
                }
            }
        }
        if (record.IsFinal && record.Build is null && record.Tests is null || record.Status == CommandStatus.Failed && record.Tests is { Failures.Count: 0 } && record.Build is null)
        {
            sb.AppendLine("Last output lines:");
            foreach (var line in record.Tail.TakeLast(15))
            {
                sb.AppendLine("  " + AnalysisServices.Clip(line, 300));
            }
        }
        if (record.IsFinal)
        {
            sb.AppendLine($"Full output: command_status commandId={record.Id} lineStart=1 (or search=…); analyze_build/analyze_test_failure commandId={record.Id}.");
        }
        return sb.ToString();
    }
}

public sealed class RunBuildTool(AnalysisServices services) : CommandToolBase(services)
{
    public override string Name => "run_build";

    public override string Description =>
        "Builds a repository with dotnet build (requires approval: builds run repository code). scope=project builds one project, affected builds what the changed files affect, " +
        "solution builds everything. Waits up to waitSeconds, then keeps running in the background (command_status).";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "scope": { "type": "string", "enum": ["solution", "project", "affected"] },
            "target": { "type": "string", "maxLength": 400, "description": "Solution or project path (relative) for scope=solution/project." },
            "changedFiles": { "type": "array", "items": { "type": "string", "maxLength": 400 }, "maxItems": 50 },
            "configuration": { "type": "string", "enum": ["Debug", "Release"] },
            "noRestore": { "type": "boolean" },
            "waitSeconds": { "type": "integer", "minimum": 1, "maximum": 600 }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        var (target, note) = ChooseTarget(index, args.GetString("scope") ?? (args.GetString("target") is null ? "solution" : "project"), args.GetString("target"), ChangedFiles(args));
        return await StartAndWaitAsync(repo, new CommandRequest
        {
            Kind = CommandKinds.Build, Target = target, Configuration = args.GetString("configuration"), NoRestore = args.GetBool("noRestore") ?? false,
            RunId = context.RunId, ConversationId = context.ConversationId,
        }, args.GetInt("waitSeconds"), context, note, ct);
    }

    internal static List<string> ChangedFiles(ToolArguments args)
        => args.GetElement("changedFiles") is { ValueKind: System.Text.Json.JsonValueKind.Array } array
            ? array.EnumerateArray().Where(e => e.ValueKind == System.Text.Json.JsonValueKind.String).Select(e => e.GetString()!.Replace('\\', '/')).ToList()
            : [];

    /// <summary>Picks the smallest build target for a scope. Returns the target path (null = repository root) and an explanation.</summary>
    internal static (string? Target, string Note) ChooseTarget(CodeIndex index, string scope, string? target, List<string> changedFiles)
    {
        if (scope == "affected")
        {
            var owners = changedFiles.Select(f => index.Files.TryGetValue(f, out var fi) ? fi.Project : null).Where(p => !string.IsNullOrEmpty(p)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            if (owners.Count == 0)
            {
                throw new ValidationException("scope=affected needs changedFiles that belong to indexed projects.");
            }
            var affected = owners.SelectMany(o => index.ReverseProjectClosure(o!).Append(o!)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            if (affected.Count == 1)
            {
                return (index.Projects[affected[0]].Path, $"Affected: {affected[0]} only — building that project.");
            }
            // Building the top-most dependents builds their dependencies too; a solution build is the simplest complete choice.
            var leaves = affected.Where(p => !affected.Any(other => index.ProjectReferencesOf(other).Contains(p, StringComparer.OrdinalIgnoreCase))).ToList();
            if (leaves.Count == 1)
            {
                return (index.Projects[leaves[0]].Path, $"Affected projects: {string.Join(", ", affected)}; building {leaves[0]} (it depends on the others).");
            }
            return (index.Manifest.Solutions.FirstOrDefault()?.Path, $"Affected projects: {string.Join(", ", affected)}; building the solution.");
        }
        if (scope == "project")
        {
            if (target is null)
            {
                throw new ValidationException("scope=project needs 'target' (a .csproj path or project name).");
            }
            if (index.Projects.TryGetValue(target, out var byName))
            {
                return (byName.Path, $"Building project {byName.Name}.");
            }
            return (target, $"Building {target}.");
        }
        return (target ?? (index.Manifest.Solutions.Count == 1 ? index.Manifest.Solutions[0].Path : null), "Building the solution.");
    }
}

public sealed class RunTestsTool(AnalysisServices services) : CommandToolBase(services)
{
    public override string Name => "run_tests";

    public override string Description =>
        "Runs tests with dotnet test (requires approval). Narrow first: pass 'symbol' to run only the tests find_tests selects (widening automatically), or a 'filter' " +
        "(e.g. FullyQualifiedName~OrderServiceTests) and 'target' test project. Waits up to waitSeconds, then continues in the background.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "target": { "type": "string", "maxLength": 400 },
            "filter": { "type": "string", "maxLength": 500 },
            "symbol": { "type": "string", "maxLength": 300 },
            "noBuild": { "type": "boolean" },
            "configuration": { "type": "string", "enum": ["Debug", "Release"] },
            "waitSeconds": { "type": "integer", "minimum": 1, "maximum": 600 }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        var target = args.GetString("target");
        var filter = args.GetString("filter");
        string? note = null;
        if (args.GetString("symbol") is { Length: > 0 } symbol && filter is null)
        {
            var targets = index.Resolve(symbol);
            var name = CodeIndex.StripGeneric(symbol.Contains('.') ? symbol[(symbol.LastIndexOf('.') + 1)..] : symbol);
            var typeName = targets.FirstOrDefault() is { } t ? SymbolKinds.IsType(t.Kind) ? t.Name : t.Container?.Split('.')[^1] : null;
            var tests = index.TestMethods.Where(s => (s.Calls.Contains(name) || s.Uses.Contains(name))).ToList();
            var level = 1;
            if (tests.Count == 0 && typeName is not null)
            {
                tests = index.TestMethods.Where(s => (s.Uses.Contains(typeName) || s.Calls.Contains(typeName))).ToList();
                level = 2;
            }
            if (tests.Count > 0)
            {
                filter = tests.Count <= 15
                    ? string.Join("|", tests.Select(t => "FullyQualifiedName=" + t.FullName))
                    : string.Join("|", tests.Select(t => t.Container).Distinct().Take(15).Select(c => "FullyQualifiedName~" + c));
                target ??= tests.Select(t => index.Projects.GetValueOrDefault(t.Project)?.Path).FirstOrDefault(p => p is not null);
                note = $"Selected {tests.Count} tests for {symbol} (level {level}).";
            }
            else
            {
                note = $"No tests reference {symbol}; running the whole test target instead.";
            }
        }
        if (target is not null && index.Projects.TryGetValue(target, out var project))
        {
            target = project.Path;
        }
        target ??= index.Manifest.Solutions.Count == 1 ? index.Manifest.Solutions[0].Path : null;
        return await StartAndWaitAsync(repo, new CommandRequest
        {
            Kind = CommandKinds.Test, Target = target, Filter = filter, NoBuild = args.GetBool("noBuild") ?? false, Configuration = args.GetString("configuration"),
            RunId = context.RunId, ConversationId = context.ConversationId,
        }, args.GetInt("waitSeconds"), context, note, ct);
    }
}

public sealed class CommandStatusTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "command_status";

    public override string Description => "Status of a build/test command (optionally waiting for it), its parsed results, and its full stored output by line range or search.";

    public override string InputSchema => """
        {
          "type": "object",
          "properties": {
            "commandId": { "type": "string", "minLength": 1, "maxLength": 64 },
            "waitSeconds": { "type": "integer", "minimum": 0, "maximum": 600 },
            "lineStart": { "type": "integer", "minimum": 1 },
            "lineCount": { "type": "integer", "minimum": 1, "maximum": 500 },
            "search": { "type": "string", "maxLength": 200 }
          },
          "required": ["commandId"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var id = args.RequireString("commandId");
        var maxWait = Math.Max(0, Services.AgentOptions.ToolTimeoutSeconds - 5);
        var record = await Services.Commands.WaitAsync(context.UserId, id, TimeSpan.FromSeconds(Math.Clamp(args.GetInt("waitSeconds") ?? 0, 0, maxWait)), ct, cancelOnAbort: false);
        var sb = new StringBuilder(CommandToolBase.Describe(record));
        if (args.GetInt("lineStart") is not null || args.GetString("search") is not null)
        {
            var (lines, total) = Services.Commands.ReadOutput(context.UserId, id, args.GetInt("lineStart") ?? 1, Clamp(args.GetInt("lineCount"), 100, 1, 500), args.GetString("search"));
            sb.AppendLine($"Output ({total:N0} stored lines{(record.OutputTruncated ? "; output beyond the storage cap was not kept" : "")}):");
            foreach (var (n, text) in lines)
            {
                sb.AppendLine($"{n,7}: {text}");
            }
        }
        return sb.ToString();
    }
}
