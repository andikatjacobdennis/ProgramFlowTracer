using System.Globalization;
using System.Text;
using DocGen.Analysis.Git;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

/// <summary>Shared rendering for Git/workflow tools and the web API.</summary>
public static class GitReports
{
    public static string Mark(string status) => status switch
    {
        "passed" => "✓",
        "failed" => "✗",
        "running" => "…",
        "stale" or "no-tests" or "no tests" => "⚠",
        _ => "–",
    };

    public static string StatusText(WorkflowState state, int maxFiles = 40)
    {
        var s = state.Status;
        var sb = new StringBuilder();
        sb.AppendLine(CultureInfo.InvariantCulture, $"Git status — {s.Repository}{(s.GitRoot == "." ? "" : $" (git root {s.GitRoot})")}");
        sb.AppendLine(CultureInfo.InvariantCulture, $"Branch: {s.Branch ?? "(detached HEAD)"} · HEAD {s.HeadShort ?? "(no commits)"} · upstream {s.Upstream ?? "none"} · ahead {s.Ahead} · behind {s.Behind}");
        sb.AppendLine(CultureInfo.InvariantCulture, $"Changes: {s.Changed} (modified {s.Modified}, added {s.Added}, deleted {s.Deleted}, renamed {s.Renamed}, untracked {s.Untracked}, conflicted {s.Conflicted}) · +{s.Insertions} −{s.Deletions}");
        foreach (var f in s.Files.Take(maxFiles))
        {
            sb.AppendLine(CultureInfo.InvariantCulture, $"  {f.Code,-2} {f.Kind,-10} {f.Path}{(f.OriginalPath is null ? "" : $" ← {f.OriginalPath}")} {(f.Binary ? "binary" : f.Insertions is null ? "" : $"+{f.Insertions} −{f.Deletions}")}");
        }
        if (s.Files.Count > maxFiles)
        {
            sb.AppendLine(CultureInfo.InvariantCulture, $"  … {s.Files.Count - maxFiles} more");
        }
        sb.AppendLine(CultureInfo.InvariantCulture, $"Build: {Mark(state.BuildStatus)} {state.BuildStatus} · Tests: {Mark(state.TestStatus)} {state.TestStatus} · Last verification: {(state.Verification?.CompletedAt is { } at ? at.ToString("yyyy-MM-dd HH:mm 'UTC'", CultureInfo.InvariantCulture) : "never")}");
        sb.AppendLine(CultureInfo.InvariantCulture, $"Commit state: {state.State} — {state.Detail}");
        if (state.VerificationStale && state.ChangedSinceVerification.Count > 0)
        {
            sb.AppendLine("Verification stale — changed since verification: " + string.Join(", ", state.ChangedSinceVerification.Take(10)));
        }
        if (state.LastCommit is { } c)
        {
            sb.AppendLine(CultureInfo.InvariantCulture, $"Last DocGen commit: {c.Commit[..Math.Min(7, c.Commit.Length)]} at {c.At:yyyy-MM-dd HH:mm} UTC");
        }
        if (state.LastPush is { } p)
        {
            sb.AppendLine(CultureInfo.InvariantCulture, $"Last DocGen push: {p.Branch} → {p.Remote} at {p.At:yyyy-MM-dd HH:mm} UTC");
        }
        sb.AppendLine("Tree fingerprint: " + s.Fingerprint);
        return sb.ToString();
    }

    public static string VerificationText(VerificationRecord? v)
    {
        if (v is null)
        {
            return "Verification: not run.";
        }
        var sb = new StringBuilder();
        sb.AppendLine(CultureInfo.InvariantCulture, $"Verification: {v.Status}{(v.CompletedAt is { } at ? $" at {at:yyyy-MM-dd HH:mm} UTC" : " (in progress)")}{(v.Error is null ? "" : " — " + v.Error)}");
        foreach (var step in v.Steps)
        {
            sb.AppendLine(CultureInfo.InvariantCulture, $"  {Mark(step.Status)} {step.Category,-11} {step.Name}: {step.Summary ?? step.Status} ({step.Seconds:0.#} s{(step.CommandId is null ? "" : ", command " + step.CommandId)})");
        }
        foreach (var category in new[] { "unit", "integration", "smoke" }.Where(c => v.Steps.All(s => s.Category != c)))
        {
            sb.AppendLine(CultureInfo.InvariantCulture, $"  – {category,-11} no {category} test project found (classified by project name)");
        }
        return sb.ToString();
    }

    public static string PreCommitText(PreCommitReport r)
    {
        var s = r.State.Status;
        var sb = new StringBuilder();
        sb.AppendLine(CultureInfo.InvariantCulture, $"Pre-Commit Report — {s.Repository} · branch {s.Branch ?? "(detached)"} @ {s.HeadShort ?? "(no commits)"}");
        sb.AppendLine(CultureInfo.InvariantCulture, $"State: {r.State.State} — {r.State.Detail}");
        sb.AppendLine(CultureInfo.InvariantCulture, $"Build: {Mark(r.State.BuildStatus)} {r.State.BuildStatus} · Tests: {Mark(r.State.TestStatus)} {r.State.TestStatus}");
        sb.Append(VerificationText(r.State.Verification));
        sb.AppendLine(CultureInfo.InvariantCulture, $"Changes: {s.Changed} files (+{s.Insertions} −{s.Deletions}): modified {s.Modified}, added {s.Added}, deleted {s.Deleted}, renamed {s.Renamed}, untracked {s.Untracked}");
        foreach (var f in s.Files.Take(30))
        {
            sb.AppendLine(CultureInfo.InvariantCulture, $"  {f.Kind,-10} {f.Path} {(f.Binary ? "binary" : f.Insertions is null ? "" : $"+{f.Insertions} −{f.Deletions}")}");
        }
        sb.AppendLine("Safety checks:");
        foreach (var c in r.Checks)
        {
            sb.AppendLine(CultureInfo.InvariantCulture, $"  {(c.Passed ? "✓" : c.Blocking ? "✗" : "⚠")} {c.Name}: {c.Detail}");
        }
        sb.AppendLine("Suggested commit message (generated from the diff):");
        foreach (var line in r.SuggestedMessage.Split('\n'))
        {
            sb.Append("  ").AppendLine(line);
        }
        sb.AppendLine("Tree fingerprint: " + s.Fingerprint);
        sb.AppendLine(r.CanCommit
            ? "READY TO COMMIT. Committing needs the user's explicit choice: [Commit] [Review changes] [Not now]."
            : "Not ready to commit: " + (r.State.State != CommitStates.Ready ? r.State.Detail : string.Join("; ", r.Checks.Where(c => c.Blocking && !c.Passed).Select(c => c.Name))));
        return sb.ToString();
    }

    public static string PushText(PushView v)
    {
        var sb = new StringBuilder();
        sb.AppendLine(CultureInfo.InvariantCulture, $"Push — {v.Status.Repository}: {v.Branch ?? "(detached)"} → {v.Remote ?? "(no remote)"}{(v.RemoteUrl is null ? "" : $" ({v.RemoteUrl})")}");
        sb.AppendLine(CultureInfo.InvariantCulture, $"Upstream: {v.Upstream ?? (v.SetsUpstream ? $"none — will be set to {v.Remote}/{v.Branch}" : "none")} · ahead {v.Status.Ahead} · behind {v.Status.Behind}");
        sb.AppendLine(CultureInfo.InvariantCulture, $"Commits to push ({v.Commits.Count}):");
        foreach (var c in v.Commits.Take(30))
        {
            sb.AppendLine(CultureInfo.InvariantCulture, $"  {c.ShortHash} {c.Subject}");
        }
        sb.AppendLine("Verification: " + v.Verification);
        foreach (var p in v.Problems)
        {
            sb.AppendLine("✗ " + p);
        }
        sb.AppendLine(v.CanPush ? "Pushing needs the user's separate, explicit choice: [Push] [Not now]." : "Nothing can be pushed right now.");
        return sb.ToString();
    }
}

public abstract class GitToolBase(AnalysisServices services) : AnalysisTool(services)
{
    protected GitService Git => Services.Service<GitService>() ?? new GitService(Services);

    protected DeveloperWorkflowService Workflow => Services.Service<DeveloperWorkflowService>()
        ?? throw new DocGenException("WORKFLOW_UNAVAILABLE", "The developer workflow service is not registered.", 500);

    protected async Task<GitContext> ContextAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
        => await Git.ContextAsync(context.UserId, await Services.RepositoryNameAsync(args, context, ct), context.RunId, context.ConversationId, ct);
}

public sealed class GitStatusTool(AnalysisServices services) : GitToolBase(services)
{
    public override string Name => "git_status";

    public override string Description =>
        "Deterministic Git status of a repository: branch, HEAD, upstream, ahead/behind, modified/added/deleted/renamed/untracked/conflicted files with " +
        "+/− line counts, build and test status from the verification cache, and the commit state (NOT READY, VERIFYING, READY, COMMITTED, PUSHED, " +
        "DIRTY AFTER COMMIT, CLEAN). Parsed from git porcelain output; read-only.";

    public override string InputSchema => $$"""
        { "type": "object", "properties": { {{RepositoryProperty}}, "maxFiles": { "type": "integer", "minimum": 1, "maximum": 500 } }, "additionalProperties": false }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var ctx = await ContextAsync(args, context, ct);
        return GitReports.StatusText(await Workflow.StateAsync(ctx, ct), Clamp(args.GetInt("maxFiles"), 40, 1, 500));
    }
}

public sealed class GitDiffTool(AnalysisServices services) : GitToolBase(services)
{
    public override string Name => "git_diff";

    public override string Description => "Unified diff of the working tree against HEAD (staged and unstaged), with a diffstat; optionally for one path. Read-only and bounded.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "path": { "type": "string", "maxLength": 500, "description": "Limit to this path (relative to the Git root)." },
            "maxChars": { "type": "integer", "minimum": 1000, "maximum": 200000 }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var ctx = await ContextAsync(args, context, ct);
        var path = args.GetString("path");
        if (path is { Length: > 0 } && (path.StartsWith('-') || path.Contains("..", StringComparison.Ordinal) || Path.IsPathRooted(path)))
        {
            throw new ValidationException("path must be a relative path inside the repository.");
        }
        return await Git.DiffAsync(ctx, path, Clamp(args.GetInt("maxChars"), 40_000, 1000, 200_000), ct);
    }
}

public sealed class CompareBranchesTool(AnalysisServices services) : GitToolBase(services)
{
    public override string Name => "compare_branches";

    public override string Description =>
        "Compares two refs (branch vs branch, branch vs HEAD, commit vs commit, tag vs branch) without checking anything out, like a pull request " +
        "(merge-base..head). Reports commits, files, insertions/deletions, projects, and a declaration-level semantic analysis from the C# parser: " +
        "features added, behavior changes, bug fixes (from commit subjects), API changes, data model changes, configuration and dependency changes, " +
        "tests added/changed, potential breaking changes, risk areas and verification status.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "base": { "type": "string", "minLength": 1, "maxLength": 200, "description": "Base ref, e.g. main, v1.2.0, origin/main or a commit." },
            "head": { "type": "string", "maxLength": 200, "description": "Head ref (default HEAD)." },
            "maxItems": { "type": "integer", "minimum": 5, "maximum": 200 }
          },
          "required": ["base"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var ctx = await ContextAsync(args, context, ct);
        var comparison = await BranchComparer.CompareAsync(Git, ctx, args.RequireString("base"), args.GetString("head") is { Length: > 0 } h ? h : "HEAD", ct);
        comparison.Verification = await Workflow.VerificationForCommitAsync(ctx, comparison.HeadCommit, ct);
        return BranchComparer.Render(comparison, Clamp(args.GetInt("maxItems"), 25, 5, 200));
    }
}

public sealed class PreCommitVerifyTool(AnalysisServices services) : GitToolBase(services), IDynamicRiskTool
{
    public override string Name => "precommit_verify";

    public override string Description =>
        "Pre-commit verification of the current working tree: dotnet restore, build, then every test project (classified unit/integration/smoke by name) " +
        "and configured extra steps. Results are cached against the exact tree (file hashes); any later file change marks the verification stale. " +
        "Returns the Pre-Commit Report: build, tests, changes, branch, safety checks and a commit message generated from the diff. Long runs continue " +
        "in the background — call again (start=false) to get the report. Never commits.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "start": { "type": "boolean", "description": "Start a verification (default true). false = only report." },
            "waitSeconds": { "type": "integer", "minimum": 0, "maximum": 600 }
          },
          "additionalProperties": false
        }
        """;

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Sensitive;

    /// <summary>Starting a verification restores, builds and tests (project code runs); reading the cached report does not.</summary>
    public Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken)
        => Task.FromResult(ToolArguments.Parse(call).GetBool("start") == false
            ? new ToolRiskAssessment(ToolRiskLevel.ReadOnly, Summary: "Read the pre-commit report")
            : new ToolRiskAssessment(ToolRiskLevel.Sensitive, Capabilities.ExecuteProcess, ["restores, builds and tests the working tree"], Summary: "Pre-commit verification"));

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var ctx = await ContextAsync(args, context, ct);
        if (args.GetBool("start") != false)
        {
            var task = Workflow.StartVerificationAsync(ctx);
            var maxWait = Math.Max(5, Services.AgentOptions.ToolTimeoutSeconds - 8);
            var wait = TimeSpan.FromSeconds(Math.Clamp(args.GetInt("waitSeconds") ?? maxWait, 0, maxWait));
            await Task.WhenAny(task, Task.Delay(wait, ct));
            if (!task.IsCompleted)
            {
                return "Pre-commit verification is still running in the background (restore → build → tests). Call precommit_verify with start=false to get the report.";
            }
        }
        return GitReports.PreCommitText(await Workflow.PreCommitAsync(ctx, ct));
    }
}

/// <summary>Commit: only with the user's approval, only a verified tree, only the tree that was reviewed.</summary>
public sealed class GitCommitTool(AnalysisServices services) : GitToolBase(services), IDynamicRiskTool, IUserIntentTool
{
    public override string Name => "git_commit";

    public override string Description =>
        "Commits all changes in the working tree. Requires the user's explicit approval every time, a READY state (the exact tree passed precommit_verify) " +
        "and the tree fingerprint from the Pre-Commit Report (proves the tree did not change after review). Refused on conflicts, secrets, bin/obj or huge files. " +
        "Hooks always run. Use only when the user asked to commit.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "fingerprint": { "type": "string", "minLength": 12, "maxLength": 64, "description": "Tree fingerprint from the Pre-Commit Report (at least the first 12 characters)." },
            "message": { "type": "string", "maxLength": 5000, "description": "Commit message. Default: the message generated from the diff." }
          },
          "required": ["fingerprint"],
          "additionalProperties": false
        }
        """;

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Sensitive;

    public async Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken ct)
    {
        var args = ToolArguments.Parse(call);
        var ctx = await ContextAsync(args, context, ct);
        var state = await Workflow.StateAsync(ctx, ct);
        var findings = new List<string> { $"commit state {state.State}", $"{state.Status.Changed} files (+{state.Status.Insertions} −{state.Status.Deletions}) on {state.Status.Branch ?? "detached HEAD"}" };
        string? deny = state.State != CommitStates.Ready ? $"the repository is not READY to commit ({state.State}: {state.Detail})"
            : !state.Status.Fingerprint.StartsWith(args.RequireString("fingerprint"), StringComparison.Ordinal) ? "the working tree changed after the reviewed Pre-Commit Report (fingerprint mismatch)"
            : null;
        return new ToolRiskAssessment(ToolRiskLevel.Sensitive, Capabilities.GitCommit, findings, deny, $"Commit {state.Status.Changed} files to {state.Status.Branch}");
    }

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var ctx = await ContextAsync(args, context, ct);
        var report = await Workflow.PreCommitAsync(ctx, ct);
        var fingerprint = args.RequireString("fingerprint");
        if (!report.State.Status.Fingerprint.StartsWith(fingerprint, StringComparison.Ordinal))
        {
            throw new DocGenException("TREE_CHANGED", "The working tree changed after it was reviewed. Run precommit_verify again.", 409);
        }
        var message = args.GetString("message") is { Length: > 0 } m ? m : report.SuggestedMessage;
        var info = await Workflow.CommitAsync(ctx, message, report.State.Status.Fingerprint, ct);
        return $"Committed {info.Commit[..7]} on {report.State.Status.Branch}: {message.Split('\n')[0]}\nState: COMMITTED (not pushed). Pushing needs a separate, explicit user choice.";
    }
}

/// <summary>Push: a separate explicit user intent; never forced.</summary>
public sealed class GitPushTool(AnalysisServices services) : GitToolBase(services), IDynamicRiskTool, IUserIntentTool
{
    public override string Name => "git_push";

    public override string Description =>
        "Pushes the current branch to its upstream (or sets the upstream on the only/origin remote). Requires the user's explicit approval every time, " +
        "separately from committing. Never force-pushes; refused when the branch is behind, detached or has conflicts. Use only when the user asked to push.";

    public override string InputSchema => $$"""
        { "type": "object", "properties": { {{RepositoryProperty}} }, "additionalProperties": false }
        """;

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.External;

    public async Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken ct)
    {
        var ctx = await ContextAsync(ToolArguments.Parse(call), context, ct);
        var view = await Workflow.PushViewAsync(ctx, ct);
        var findings = new List<string> { $"{view.Commits.Count} commit(s) {view.Branch} → {view.Remote}", view.Verification };
        return new ToolRiskAssessment(ToolRiskLevel.External, Capabilities.GitPush, findings,
            view.CanPush ? null : view.Commits.Count == 0 && view.Problems.Count == 0 ? "nothing to push" : string.Join(" ", view.Problems),
            $"Push {view.Commits.Count} commit(s) to {view.Remote}/{view.Branch}");
    }

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var ctx = await ContextAsync(args, context, ct);
        var info = await Workflow.PushAsync(ctx, ct);
        return $"Pushed {info.Branch} → {info.Remote} ({info.Commit[..Math.Min(7, info.Commit.Length)]}). State: PUSHED.";
    }
}
