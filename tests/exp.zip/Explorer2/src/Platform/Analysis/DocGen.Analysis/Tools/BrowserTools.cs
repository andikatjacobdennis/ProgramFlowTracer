using System.Text;
using System.Text.Json;
using DocGen.Analysis.Browser;
using DocGen.Analysis.Investigations;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Core.Options;
using DocGen.Tools.Infrastructure;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Tools;

/// <summary>
/// Base for browser tools: capability by destination (BrowserLocal for development targets, BrowserExternal for
/// public sites), sensitive-action detection (purchases, payments, credentials, destructive admin actions always
/// require explicit approval), tab context in every result, and activity records.
/// </summary>
public abstract class BrowserToolBase(AnalysisServices services) : AnalysisTool(services), IDynamicRiskTool
{
    protected const string TabProperty = """
        "tabId": { "type": "string", "maxLength": 20, "description": "Tab to act on (default: the active tab)." }
        """;

    protected const string TargetProperties = """
        "ref": { "type": "string", "maxLength": 20, "description": "Element ref from browser_read_page, e.g. ref_12." },
        "selector": { "type": "string", "maxLength": 500, "description": "CSS selector." },
        "text": { "type": "string", "maxLength": 200, "description": "Visible text / accessible name of the element." }
        """;

    protected BrowserService Browser => Services.Service<BrowserService>() ?? throw new DocGenException("BROWSER_UNAVAILABLE", "Browser automation is not available in this host.", 503);

    protected BrowserOptions BrowserSettings => Services.Service<IOptionsMonitor<BrowserOptions>>()?.CurrentValue ?? new BrowserOptions();

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.ReadOnly;

    /// <summary>Default: the capability follows the current tab's URL.</summary>
    public virtual Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken ct)
    {
        var args = ToolArguments.Parse(call);
        var url = Services.Service<BrowserService>()?.CurrentUrl(context.UserId, args.GetString("tabId"));
        return Task.FromResult(new ToolRiskAssessment(RiskLevel, CapabilityFor(url)));
    }

    protected string CapabilityFor(string? url)
        => url is null || BrowserUrlPolicy.Classify(url, BrowserSettings).Class == UrlClass.Local ? Capabilities.BrowserLocal : Capabilities.BrowserExternal;

    protected static BrowserTarget Target(ToolArguments args) => new(args.GetString("ref"), args.GetString("selector"), args.GetString("text"));

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct) => throw new NotSupportedException();

    protected string TabContext(string userId, string? executedOn)
    {
        var tabs = Browser.ListTabs(userId, out var session);
        var sb = new StringBuilder("\n\nTab Context:\n");
        sb.AppendLine($"Executed on: {executedOn ?? session?.ActiveTabId ?? "-"}");
        sb.AppendLine("Available tabs:");
        foreach (var t in tabs)
        {
            sb.AppendLine($"  {t.TabId} — {(t.Title.Length == 0 ? "(untitled)" : Clip(t.Title, 80))} — {t.Url}{(t.Viewport is null ? "" : $" [{t.Viewport}]")}{(t.TabId == session?.ActiveTabId ? " (active)" : "")}");
        }
        return sb.ToString().TrimEnd();
    }

    protected ToolResult Result(ToolCall call, string content, string userId, string? tabId, params ActivityRecord[] activities)
        => new() { ToolCallId = call.Id, ToolName = call.Name, Success = true, Content = content + TabContext(userId, tabId), Activities = activities.ToList() };

    protected static ActivityRecord Activity(string type, string title, string? detail = null, params (string Key, string? Value)[] data)
    {
        var a = new ActivityRecord { Type = type, Title = title, Detail = detail };
        foreach (var (key, value) in data)
        {
            if (value is not null)
            {
                a.Data[key] = value;
            }
        }
        return a;
    }

    protected static string Clip(string text, int max) => text.Length > max ? text[..max] + "…" : text;
}

public sealed class BrowserOpenTool(AnalysisServices services) : BrowserToolBase(services)
{
    public override string Name => "browser_open";

    public override string Description =>
        "Opens the browser used for verifying applications (a separate headless Edge/Chrome with a fresh profile — none of your own browser data) and " +
        "optionally navigates to a URL. Local development URLs (localhost, 127.0.0.1, *.localhost, *.test) are allowed; public sites need extra approval. " +
        "To read a public web page or API, use http_request instead.";

    public override string InputSchema => """
        {
          "type": "object",
          "properties": {
            "url": { "type": "string", "maxLength": 2000 },
            "newTab": { "type": "boolean" }
          },
          "additionalProperties": false
        }
        """;

    public override Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken ct)
        => Task.FromResult(NavigationAssessment(ToolArguments.Parse(call).GetString("url")));

    internal ToolRiskAssessment NavigationAssessment(string? url)
    {
        if (url is null)
        {
            return new ToolRiskAssessment(ToolRiskLevel.ReadOnly, Capabilities.BrowserLocal);
        }
        var (cls, _, reason) = BrowserUrlPolicy.Classify(url, BrowserSettings);
        return cls switch
        {
            UrlClass.Forbidden => new ToolRiskAssessment(ToolRiskLevel.External, Capabilities.BrowserExternal, [reason ?? "forbidden"], $"navigation to {Clip(url, 100)} is not allowed ({reason})"),
            UrlClass.External => new ToolRiskAssessment(ToolRiskLevel.External, Capabilities.BrowserExternal, ["navigates to an external site: " + Clip(url, 120)]),
            _ => new ToolRiskAssessment(ToolRiskLevel.ReadOnly, Capabilities.BrowserLocal),
        };
    }

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var url = args.GetString("url");
        var tab = await Browser.OpenAsync(context.UserId, context.RunId, url, args.GetBool("newTab") ?? false, ct);
        var session = Browser.OpenSessions(context.UserId).FirstOrDefault();
        return Result(call, $"Opened {tab.TabId}{(url is null ? "" : $" at {tab.Url}")} — {(tab.Title.Length == 0 ? "(untitled)" : tab.Title)}\nBrowser: {session?.Browser} (headless, fresh profile), session {session?.SessionId}",
            context.UserId, tab.TabId,
            Activity("browser_opened", $"Opened {tab.TabId}{(url is null ? "" : " " + tab.Url)}", tab.Title, ("tabId", tab.TabId), ("url", tab.Url), ("sessionId", session?.SessionId)));
    }
}

public sealed class BrowserNavigateTool(AnalysisServices services) : BrowserToolBase(services)
{
    public override string Name => "browser_navigate";

    public override string Description => "Navigates a tab: action=goto (with url), back, forward or reload. Waits for the page to load.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            "action": { "type": "string", "enum": ["goto", "back", "forward", "reload"] },
            "url": { "type": "string", "maxLength": 2000 },
            {{TabProperty}}
          },
          "additionalProperties": false
        }
        """;

    public override async Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken ct)
    {
        var args = ToolArguments.Parse(call);
        return args.GetString("url") is { } url && (args.GetString("action") ?? "goto") == "goto"
            ? new BrowserOpenTool(Services).NavigationAssessment(url)
            : await base.AssessAsync(call, context, ct);
    }

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var action = args.GetString("action") ?? "goto";
        var tabId = args.GetString("tabId");
        var tab = action == "goto"
            ? await Browser.NavigateAsync(context.UserId, tabId, args.GetString("url") ?? throw new ValidationException("goto needs 'url'."), ct)
            : await Browser.HistoryAsync(context.UserId, tabId, action, ct);
        return Result(call, $"{(action == "goto" ? "Navigated" : action == "reload" ? "Reloaded" : $"Went {action}")} {tab.TabId} to {tab.Url} — {(tab.Title.Length == 0 ? "(untitled)" : tab.Title)}",
            context.UserId, tab.TabId, Activity("browser_navigated", $"{action} → {tab.Url}", tab.Title, ("tabId", tab.TabId), ("url", tab.Url)));
    }
}

public sealed class BrowserTabsTool(AnalysisServices services) : BrowserToolBase(services)
{
    public override string Name => "browser_tabs";

    public override string Description => "Lists tabs, selects one (makes it active), or closes a tab. browser_close closes the whole browser.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            "action": { "type": "string", "enum": ["list", "select", "close"] },
            {{TabProperty}}
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var action = args.GetString("action") ?? "list";
        var tabId = args.GetString("tabId");
        switch (action)
        {
            case "select":
                var tab = Browser.SelectTab(context.UserId, tabId ?? throw new ValidationException("select needs tabId."));
                return Result(call, $"Selected {tab.TabId}.", context.UserId, tab.TabId);
            case "close":
                var message = await Browser.CloseAsync(context.UserId, tabId ?? throw new ValidationException("close needs tabId (use browser_close to close the browser)."), ct);
                return Result(call, message, context.UserId, null, Activity("browser_closed", $"Closed {tabId}", data: ("tabId", tabId)));
            default:
                var tabs = Browser.ListTabs(context.UserId, out var session);
                return Result(call, session is null ? "No browser session is open." : $"Session {session.SessionId} ({session.Browser}), {tabs.Count} tab(s).", context.UserId, null);
        }
    }
}

public sealed class BrowserViewportTool(AnalysisServices services) : BrowserToolBase(services)
{
    public override string Name => "browser_viewport";

    public override string Description =>
        "Sets the viewport: preset mobile (390×844, touch), tablet (768×1024), desktop (1440×900), custom width/height, or responsive to clear the emulation " +
        "(the tab returns to the browser window's own size).";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            "preset": { "type": "string", "enum": ["mobile", "tablet", "desktop", "responsive", "custom"] },
            "width": { "type": "integer", "minimum": 200, "maximum": 3840 },
            "height": { "type": "integer", "minimum": 200, "maximum": 4000 },
            "mobile": { "type": "boolean" },
            {{TabProperty}}
          },
          "required": ["preset"],
          "additionalProperties": false
        }
        """;

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var preset = args.RequireString("preset");
        BrowserViewport? viewport = preset switch
        {
            "responsive" => null,
            "custom" => new BrowserViewport
            {
                Preset = "custom", Width = args.GetInt("width") ?? throw new ValidationException("custom needs width."),
                Height = args.GetInt("height") ?? throw new ValidationException("custom needs height."), Mobile = args.GetBool("mobile") ?? false,
            },
            _ => BrowserViewport.Presets[preset],
        };
        var tab = await Browser.SetViewportAsync(context.UserId, args.GetString("tabId"), viewport, ct);
        var session = Browser.OpenSessions(context.UserId).FirstOrDefault();
        var measured = viewport is null ? await Browser.EvaluateMetricsAsync(context.UserId, tab.TabId, ct) : null;
        var text = viewport is null
            ? $"Resized browser\npreset: responsive\nViewport emulation cleared; the tab is back to the browser window's own size (window {session?.WindowWidth}×{session?.WindowHeight}, measured viewport width {measured?.ViewportWidth}px)."
            : $"Resized browser\npreset: {viewport.Preset}\nViewport: {viewport.Width}×{viewport.Height}{(viewport.Mobile ? ", mobile emulation with touch" : "")}.";
        return Result(call, text, context.UserId, tab.TabId,
            Activity("browser_viewport_changed", viewport is null ? "Cleared viewport emulation" : $"Viewport {viewport}", data: [("tabId", tab.TabId), ("preset", preset), ("width", viewport?.Width.ToString()), ("height", viewport?.Height.ToString())]));
    }
}

public sealed class BrowserReadPageTool(AnalysisServices services) : BrowserToolBase(services)
{
    public override string Name => "browser_read_page";

    public override string Description =>
        "Reads the current page: mode=accessibility (default) returns a DOM-backed accessibility outline — headings, landmarks and interactive elements with " +
        "refs (ref_N) usable by browser_click/browser_type; filter=all adds visible text. mode=text returns the visible text.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            "mode": { "type": "string", "enum": ["accessibility", "text"] },
            "filter": { "type": "string", "enum": ["interactive", "all"] },
            "maxLines": { "type": "integer", "minimum": 10, "maximum": 1500 },
            "maxChars": { "type": "integer", "minimum": 500, "maximum": 100000 },
            {{TabProperty}}
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var tabId = args.GetString("tabId");
        if (args.GetString("mode") == "text")
        {
            var text = await Browser.ReadTextAsync(context.UserId, tabId, Clamp(args.GetInt("maxChars"), 20_000, 500, 100_000), ct);
            return Result(call, "<untrusted_content source=\"page text\">\n" + text + "\n</untrusted_content>", context.UserId, tabId);
        }
        var snapshot = await Browser.ReadPageAsync(context.UserId, tabId, args.GetString("filter") == "all", Clamp(args.GetInt("maxLines"), 400, 10, 1500), ct);
        var content = $"Page: {snapshot.Title} — {snapshot.Url}\nViewport {snapshot.Width}×{snapshot.ViewportHeight}, scrolled {snapshot.ScrollY} of {snapshot.Height}px\n" +
                      "<untrusted_content source=\"page\">\n" + string.Join("\n", snapshot.Lines) + (snapshot.Truncated ? "\n… (truncated; raise maxLines)" : "") + "\n</untrusted_content>";
        return Result(call, content, context.UserId, tabId);
    }
}

/// <summary>Shared assessment for element interactions: sensitive targets always require explicit approval.</summary>
public abstract class BrowserInteractionTool(AnalysisServices services) : BrowserToolBase(services)
{
    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    public override async Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken ct)
    {
        var args = ToolArguments.Parse(call);
        var browser = Services.Service<BrowserService>();
        var capability = CapabilityFor(browser?.CurrentUrl(context.UserId, args.GetString("tabId")));
        ElementInfo? info = null;
        try
        {
            info = browser is null ? null : await browser.DescribeAsync(context.UserId, args.GetString("tabId"), Target(args), ct);
        }
        catch (DocGenException)
        {
        }
        var findings = new List<string>();
        if (info is not null)
        {
            findings.Add($"{info.Role} \"{Clip(info.Name, 80)}\"");
            findings.AddRange(info.Sensitive);
        }
        if (IsSensitiveInput(args))
        {
            findings.Add("types into a password field");
        }
        var sensitive = info is { Sensitive.Count: > 0 } || IsSensitiveInput(args);
        return new ToolRiskAssessment(sensitive ? ToolRiskLevel.Sensitive : RiskLevel, capability, findings);
    }

    protected virtual bool IsSensitiveInput(ToolArguments args) => false;
}

public sealed class BrowserClickTool(AnalysisServices services) : BrowserInteractionTool(services)
{
    public override string Name => "browser_click";

    public override string Description =>
        "Clicks an element (ref from browser_read_page, CSS selector, or visible text). The element is scrolled into view and must be visible, enabled and not " +
        "covered. Purchases, payments, credential submission and destructive actions (delete, remove…) always ask for approval first.";

    public override string InputSchema => $$"""
        { "type": "object", "properties": { {{TargetProperties}}, {{TabProperty}} }, "additionalProperties": false }
        """;

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var target = Target(args);
        var info = await Browser.ClickAsync(context.UserId, args.GetString("tabId"), target, ct);
        var url = Browser.CurrentUrl(context.UserId, args.GetString("tabId"));
        return Result(call, $"Clicked {info.Role} \"{Clip(info.Name, 100)}\" ({info.Ref}). Now at {url}", context.UserId, args.GetString("tabId"),
            Activity("browser_clicked", $"Clicked {info.Role} \"{Clip(info.Name, 80)}\"", url, ("ref", info.Ref), ("url", url)));
    }
}

public sealed class BrowserTypeTool(AnalysisServices services) : BrowserInteractionTool(services), IArgumentRedactor
{
    public string RedactArguments(string argumentsJson) => CredentialMask.MaskTypeArguments(argumentsJson);

    protected override bool IsSensitiveInput(ToolArguments args)
        => CredentialMask.IsCredentialTarget($"{args.GetString("text")} {args.GetString("selector")} {args.GetString("ref")}");

    public override string Name => "browser_type";

    public override string Description =>
        "Types text into an element (focus + insert text), optionally clearing it first and pressing Enter; or presses a single key (key=Enter, Tab, Escape, " +
        "arrows…). Typing into password fields always asks for approval; never type real credentials — only scratch/test values.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{TargetProperties}},
            "value": { "type": "string", "maxLength": 10000 },
            "clear": { "type": "boolean" },
            "submit": { "type": "boolean", "description": "Press Enter after typing." },
            "key": { "type": "string", "enum": ["Enter", "Tab", "Escape", "Backspace", "Space", "ArrowDown", "ArrowUp", "ArrowLeft", "ArrowRight", "PageDown", "PageUp", "Home", "End"] },
            {{TabProperty}}
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var tabId = args.GetString("tabId");
        var target = Target(args);
        if (args.GetString("value") is null && args.GetString("key") is { } key)
        {
            await Browser.PressKeyAsync(context.UserId, tabId, key, ct);
            return Result(call, $"Pressed {key}.", context.UserId, tabId, Activity("browser_typed", $"Pressed {key}"));
        }
        var value = args.GetString("value") ?? throw new ValidationException("Give 'value' to type, or 'key' to press.");
        var info = await Browser.TypeAsync(context.UserId, tabId, target, value, args.GetBool("clear") ?? true, args.GetBool("submit") ?? false, ct);
        var shown = info.Sensitive.Contains("password field") || IsSensitiveInput(args) ? CredentialMask.Masked : Clip(value, 60);
        return Result(call, $"Typed \"{shown}\" into {info.Role} \"{Clip(info.Name, 80)}\" ({info.Ref}){(args.GetBool("submit") == true ? " and pressed Enter" : "")}.",
            context.UserId, tabId, Activity("browser_typed", $"Typed into {info.Role} \"{Clip(info.Name, 60)}\"", null, ("ref", info.Ref)));
    }
}

public sealed class BrowserSelectTool(AnalysisServices services) : BrowserInteractionTool(services)
{
    public override string Name => "browser_select";

    public override string Description => "Chooses an option (by value or visible label) in a <select> element.";

    public override string InputSchema => $$"""
        { "type": "object", "properties": { {{TargetProperties}}, "value": { "type": "string", "maxLength": 500 }, {{TabProperty}} }, "required": ["value"], "additionalProperties": false }
        """;

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var info = await Browser.SelectAsync(context.UserId, args.GetString("tabId"), Target(args), args.RequireString("value"), ct);
        return Result(call, $"Selected \"{args.RequireString("value")}\" in {info.Role} \"{Clip(info.Name, 80)}\" ({info.Ref}).", context.UserId, args.GetString("tabId"),
            Activity("browser_selected", $"Selected {args.RequireString("value")}", null, ("ref", info.Ref)));
    }
}

public sealed class BrowserScrollTool(AnalysisServices services) : BrowserToolBase(services)
{
    public override string Name => "browser_scroll";

    public override string Description => "Scrolls the page (direction up/down/left/right/top/bottom by amount pixels) or scrolls an element into view.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            "direction": { "type": "string", "enum": ["up", "down", "left", "right", "top", "bottom"] },
            "amount": { "type": "integer", "minimum": 1, "maximum": 20000 },
            {{TargetProperties}},
            {{TabProperty}}
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var target = Target(args);
        var position = await Browser.ScrollAsync(context.UserId, args.GetString("tabId"), target.IsEmpty ? null : target, args.GetString("direction") ?? "down", args.GetInt("amount") ?? 600, ct);
        return Result(call, $"Scrolled{(target.IsEmpty ? "" : " to " + target)}. Position: {position}", context.UserId, args.GetString("tabId"));
    }
}

public sealed class BrowserWaitTool(AnalysisServices services) : BrowserToolBase(services)
{
    public override string Name => "browser_wait";

    public override string Description => "Waits until text appears (kind=text) or disappears (textGone), a selector is visible (selector), the URL contains a value (url), or the page finished loading (load).";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            "kind": { "type": "string", "enum": ["text", "textGone", "selector", "url", "load"] },
            "value": { "type": "string", "maxLength": 500 },
            "timeoutSeconds": { "type": "integer", "minimum": 1, "maximum": 60 },
            {{TabProperty}}
          },
          "required": ["kind"],
          "additionalProperties": false
        }
        """;

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (met, detail) = await Browser.WaitAsync(context.UserId, args.GetString("tabId"), args.RequireString("kind"), args.GetString("value"), args.GetInt("timeoutSeconds") ?? 10, ct);
        var result = Result(call, $"Wait for {args.RequireString("kind")} {(args.GetString("value") is { } v ? $"\"{Clip(v, 80)}\"" : "")}: {(met ? "✓" : "✗")} {detail}", context.UserId, args.GetString("tabId"));
        result.Success = met;
        result.Error = met ? null : "condition not met";
        return result;
    }
}

public sealed class BrowserScreenshotTool(AnalysisServices services) : BrowserToolBase(services)
{
    public override string Name => "browser_screenshot";

    public override string Description =>
        "Captures a screenshot of the tab (viewport or full page) and saves it as an image artifact with URL, viewport and time. Reusing the same title adds " +
        "a new version, so before/after screenshots of a fix can be compared side by side on the Artifacts page. The image is not returned to the model. " +
        "For documentation: savePath also writes the original PNG into the workspace (e.g. generated/app-docs/screenshots/raw/home.png), and targets " +
        "(name → ref_N, CSS selector or text=Label) records where those elements are in the image, plus the text visible in it, in a <name>.capture.json " +
        "file beside the PNG — image_annotate draws on those boxes and docs_check verifies the guide against that text.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            "fullPage": { "type": "boolean" },
            "title": { "type": "string", "maxLength": 120, "description": "Artifact title; an existing screenshot artifact with this title gets a new version." },
            "description": { "type": "string", "maxLength": 300 },
            "savePath": { "type": "string", "maxLength": 300, "description": "Workspace path of a .png to write the original screenshot to (replaced if it exists)." },
            "targets": { "type": "object", "maxProperties": 30, "additionalProperties": { "type": "string", "maxLength": 300 },
                         "description": "Elements to locate, by a short name you choose: {\"add\": \"text=Add and index\", \"files\": \"tab \\\"Files 4\\\"\", \"path\": \"ref_11\", \"nav\": \"nav.sections\"} — text=Label, role \"Name\" as browser_read_page prints it, ref_N or a CSS selector. Needs savePath." },
            "scrollTo": { "type": "string", "maxLength": 300, "description": "Before a viewport shot, scroll this element (a target name, ref_N, CSS selector or text=Label) to the middle of the screen." },
            {{TabProperty}}
          },
          "additionalProperties": false
        }
        """;

    public override Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken ct)
    {
        var args = ToolArguments.Parse(call);
        var url = Services.Service<BrowserService>()?.CurrentUrl(context.UserId, args.GetString("tabId"));
        // Writing the PNG into the user's own workspace is routine file work, like file_write to generated/.
        return Task.FromResult(args.GetString("savePath") is { Length: > 0 }
            ? new ToolRiskAssessment(ToolRiskLevel.Write, CapabilityFor(url), Routine: true)
            : new ToolRiskAssessment(RiskLevel, CapabilityFor(url)));
    }

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var tabId = args.GetString("tabId");
        var fullPage = args.GetBool("fullPage") ?? false;
        var savePath = args.GetString("savePath");
        var targets = args.GetElement("targets") is { ValueKind: JsonValueKind.Object } t
            ? t.EnumerateObject().ToDictionary(p => p.Name, p => ParseTarget(p.Value.GetString() ?? ""), StringComparer.Ordinal)
            : [];
        if (targets.Count > 0 && savePath is null)
        {
            throw new ValidationException("targets needs savePath: the boxes are saved beside the PNG for image_annotate.");
        }
        string? fullSave = null;
        if (savePath is not null)
        {
            var workspace = await Services.Repositories.ResolveAsync(context.UserId, Repositories.RepositoryCatalog.WorkspaceName, ct);
            fullSave = workspace.Resolve(savePath);
            if (!fullSave.EndsWith(".png", StringComparison.OrdinalIgnoreCase))
            {
                throw new ValidationException("savePath must name a .png file in the workspace.");
            }
        }
        string? scrollNote = null;
        if (args.GetString("scrollTo") is { Length: > 0 } scrollTo && !fullPage)
        {
            try
            {
                await Browser.ScrollAsync(context.UserId, tabId, targets.TryGetValue(scrollTo, out var named) ? named : ParseTarget(scrollTo), "down", 0, ct);
                await Task.Delay(250, ct); // sticky headers and lazy content settle
            }
            catch (Exception ex) when (ex is DocGenException or NotFoundException)
            {
                scrollNote = $"\nCould not scroll to {scrollTo}: {ex.Message}";
            }
        }
        // Measured immediately before the pixels are taken, from the same layout.
        var capture = fullSave is null ? null : await Browser.CaptureContextAsync(context.UserId, tabId, targets, fullPage, ct);
        var saved = await CaptureAsync(Services, Browser, context, tabId, fullPage, args.GetString("title"), args.GetString("description"), ct, fullSave);
        var content = new StringBuilder(saved.Summary).Append(scrollNote);
        if (fullSave is not null && capture is not null)
        {
            var sidecar = Path.ChangeExtension(fullSave, null) + ".capture.json";
            await File.WriteAllTextAsync(sidecar, JsonSerializer.Serialize(new
            {
                image = Path.GetFileName(fullSave), capture.Url, capture.Title, capture.DevicePixelRatio, cssWidth = capture.CssWidth, cssHeight = capture.CssHeight,
                fullPage, capturedAt = DateTimeOffset.UtcNow, runId = context.RunId, targets = capture.Elements, visibleText = capture.VisibleText,
                controlNames = capture.ControlNames ?? [],
            }, CaptureJson), ct);
            content.Append($"\nOriginal saved to {savePath!.Replace('\\', '/')} (+ {Path.GetFileName(sidecar)}).");
            foreach (var e in capture.Elements)
            {
                content.Append(e.Found
                    ? $"\n  {e.Name}: {e.Role} \"{Clip(e.Label ?? "", 60)}\" at x={e.X} y={e.Y} {e.Width}×{e.Height}{(e.PartlyVisible ? " (partly outside the image)" : "")}"
                    : $"\n  {e.Name}: NOT FOUND ({e.Locator}) — not visible in this shot; fix the locator or the page state before annotating it" +
                      (e.Suggestions is { Count: > 0 } s ? $". Closest visible: {string.Join("; ", s)} (use text=Name, role \"Name\" or #id)" : ""));
            }
        }
        var result = Result(call, content.ToString(), context.UserId, tabId, saved.Activity);
        if (saved.ArtifactId is not null)
        {
            // Shown in the reply, so the user sees what DocGen is looking at.
            result.FileChanges = [new FileChange { Path = saved.Activity.Title ?? "Screenshot", Kind = "image", ArtifactId = saved.ArtifactId }];
        }
        return result;
    }

    private static readonly JsonSerializerOptions CaptureJson = new(JsonSerializerDefaults.Web) { WriteIndented = true };

    /// <summary>ref_N, text=Label, or a CSS selector.</summary>
    internal static BrowserTarget ParseTarget(string locator)
    {
        var l = locator.Trim();
        if (System.Text.RegularExpressions.Regex.IsMatch(l, @"^ref_\d+$"))
        {
            return new BrowserTarget(Ref: l);
        }
        return l.StartsWith("text=", StringComparison.OrdinalIgnoreCase) ? new BrowserTarget(Text: l[5..]) : new BrowserTarget(Selector: l);
    }

    internal static async Task<(string Summary, ActivityRecord Activity, string? ArtifactId)> CaptureAsync(AnalysisServices services, BrowserService browser, ToolExecutionContext context,
        string? tabId, bool fullPage, string? title, string? description, CancellationToken ct, string? savePath = null)
    {
        var (bytes, format) = await browser.ScreenshotAsync(context.UserId, tabId, fullPage, ct, allowJpeg: savePath is null);
        if (savePath is not null)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(savePath)!);
            await File.WriteAllBytesAsync(savePath, bytes, ct);
        }
        var tabs = browser.ListTabs(context.UserId, out var session);
        var tab = tabs.FirstOrDefault(t => t.TabId == (tabId ?? session?.ActiveTabId));
        var viewport = tab?.Viewport?.ToString() ?? $"window {session?.WindowWidth}×{session?.WindowHeight}";
        var note = $"{tab?.Url} · {viewport} · {DateTime.UtcNow:yyyy-MM-dd HH:mm:ss} UTC · run {context.RunId ?? "-"}{(description is null ? "" : " · " + description)}";
        var artifacts = services.Service<IArtifactService>();
        string? artifactId = null;
        var version = 1;
        if (artifacts is not null)
        {
            var content = $"data:image/{format};base64,{Convert.ToBase64String(bytes)}";
            var name = title ?? $"Screenshot — {(tab?.Title is { Length: > 0 } t ? Clip(t, 60) : "page")} ({(tab?.Viewport?.Preset ?? "default")})";
            var existing = (await artifacts.ListAsync(context.UserId, null, ct)).FirstOrDefault(a => a.Type == ArtifactType.Image && a.Title == name && a.ConversationId == context.ConversationId);
            var artifact = existing is null
                ? await artifacts.CreateAsync(context.UserId, name, ArtifactType.Image, content, "agent", context.ConversationId, context.ProjectId, ct)
                : await artifacts.UpdateAsync(context.UserId, existing.Id, content, "agent", note, null, ct);
            if (existing is null && artifact.Versions.Count > 0)
            {
                artifact = await artifacts.GetAsync(context.UserId, artifact.Id, ct);
            }
            artifactId = artifact.Id;
            version = artifact.CurrentVersion;
        }
        var summary = $"Screenshot captured ({format}, {bytes.Length / 1024.0:0.0} KB, {(fullPage ? "full page" : "viewport")}) of {tab?.Url} at {viewport}." +
                      (artifactId is null ? " (artifacts unavailable: not stored)" : $" Saved as artifact {artifactId} version {version}{(version > 1 ? $" — compare with version {version - 1} on the Artifacts page" : "")}.");
        var activity = Activity("browser_screenshot", $"Screenshot of {tab?.Title}", note, ("artifactId", artifactId), ("version", version.ToString()), ("url", tab?.Url), ("viewport", viewport));
        return (summary, activity, artifactId);
    }
}

public sealed class BrowserConsoleTool(AnalysisServices services) : BrowserToolBase(services)
{
    public override string Name => "browser_console";

    public override string Description => "Reads console messages (errors and warnings by default), uncaught exceptions and failed network requests (HTTP ≥ 400, load failures) collected for the tab.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            "levels": { "type": "array", "items": { "type": "string", "enum": ["error", "warning", "info", "log", "debug"] }, "maxItems": 5 },
            "clear": { "type": "boolean", "description": "Clear the collected messages after reading (to check a later step in isolation)." },
            {{TabProperty}}
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var levels = args.GetElement("levels") is { ValueKind: JsonValueKind.Array } l ? l.EnumerateArray().Select(e => e.GetString()!).ToHashSet() : ["error", "warning"];
        var (console, network) = await Browser.DiagnosticsAsync(context.UserId, args.GetString("tabId"), args.GetBool("clear") ?? false, ct);
        var entries = console.Where(c => levels.Contains(c.Level)).TakeLast(100).ToList();
        var sb = new StringBuilder($"Console: {console.Count(c => c.Level == "error")} errors, {console.Count(c => c.Level == "warning")} warnings; network failures: {network.Count}\n");
        foreach (var c in entries)
        {
            sb.AppendLine($"  [{c.Level}/{c.Source}] {Clip(c.Text, 400)}{(c.Url is { Length: > 0 } u ? $" ({Clip(u, 120)})" : "")}");
        }
        foreach (var n in network.TakeLast(50))
        {
            sb.AppendLine($"  [network] {(n.Status is { } s ? "HTTP " + s : n.Error)} {n.ResourceType} {Clip(n.Url, 200)}");
        }
        var errors = console.Count(c => c.Level == "error");
        return Result(call, sb.ToString().TrimEnd(), context.UserId, args.GetString("tabId"),
            Activity("browser_console_checked", errors == 0 ? "No console errors" : $"{errors} console errors", null, ("errors", errors.ToString()), ("networkFailures", network.Count.ToString())));
    }
}

public sealed class BrowserCloseTool(AnalysisServices services) : BrowserToolBase(services)
{
    public override string Name => "browser_close";

    public override string Description => "Closes a tab (tabId) or, without tabId, the whole browser session (its process tree is stopped and the scratch profile deleted).";

    public override string InputSchema => $$"""
        { "type": "object", "properties": { {{TabProperty}} }, "additionalProperties": false }
        """;

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var tabId = args.GetString("tabId");
        var message = await Browser.CloseAsync(context.UserId, tabId, ct);
        return new ToolResult
        {
            ToolCallId = call.Id, ToolName = call.Name, Success = true, Content = message,
            Activities = [Activity("browser_closed", tabId is null ? "Closed browser" : $"Closed {tabId}", data: ("tabId", tabId))],
        };
    }
}
