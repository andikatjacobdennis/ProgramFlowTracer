using System.Text;
using System.Text.Json;
using DocGen.Analysis.Documentation;
using DocGen.Analysis.Repositories;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

/// <summary>
/// image_annotate: draws documentation annotations (boxes, numbered markers, arrows, callouts, clouds) on a COPY of a
/// screenshot. Positions come from the element boxes browser_screenshot recorded (targets → .capture.json), so a box
/// frames the real control, not a guess; markers and text panels are placed on calm parts of the image and away from
/// each other. The original is never modified. A .annotations.json beside the output lists the markers (number → element)
/// for the guide's legend and for docs_check.
/// </summary>
public sealed class ImageAnnotateTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "image_annotate";

    public override string Description =>
        "Annotates a copy of a screenshot for documentation: box (frame a control, optional number), marker (numbered circle), arrow (from one " +
        "element to another), callout (short text panel with a pointer) and cloud (a tip or note). Refer to elements by the target names recorded " +
        "with browser_screenshot (savePath + targets), or give rect [x, y, width, height]. Placement avoids busy areas and overlaps; the original " +
        "file is never changed. Keep it to what the text explains: 1–6 numbered markers that match the numbered steps.";

    public override string InputSchema => """
        {
          "type": "object",
          "properties": {
            "source": { "type": "string", "maxLength": 300, "description": "Workspace path of the original PNG (e.g. generated/app-docs/screenshots/raw/home.png)." },
            "output": { "type": "string", "maxLength": 300, "description": "Workspace path for the annotated copy (e.g. generated/app-docs/screenshots/annotated/home.png). Must differ from source." },
            "annotations": {
              "type": "array", "minItems": 1, "maxItems": 20,
              "items": {
                "type": "object",
                "properties": {
                  "type": { "type": "string", "enum": ["box", "marker", "arrow", "callout", "cloud"] },
                  "target": { "type": "string", "maxLength": 60, "description": "Target name recorded with the screenshot." },
                  "rect": { "type": "array", "items": { "type": "number" }, "minItems": 4, "maxItems": 4 },
                  "number": { "type": "integer", "minimum": 1, "maximum": 30 },
                  "text": { "type": "string", "maxLength": 200 },
                  "from": { "type": "string", "maxLength": 60, "description": "Arrow start (target name)." },
                  "to": { "type": "string", "maxLength": 60, "description": "Arrow end (target name)." },
                  "side": { "type": "string", "enum": ["right", "left", "above", "below", "corner"] }
                },
                "required": ["type"],
                "additionalProperties": false
              }
            }
          },
          "required": ["source", "output", "annotations"],
          "additionalProperties": false
        }
        """;

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct) => throw new NotSupportedException();

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var workspace = await Services.Repositories.ResolveAsync(context.UserId, RepositoryCatalog.WorkspaceName, ct);
        var source = workspace.Resolve(args.RequireString("source"));
        var output = workspace.Resolve(args.RequireString("output"));
        if (!source.EndsWith(".png", StringComparison.OrdinalIgnoreCase) || !output.EndsWith(".png", StringComparison.OrdinalIgnoreCase))
        {
            throw new ValidationException("source and output must be .png files in the workspace.");
        }
        if (string.Equals(Path.GetFullPath(source), Path.GetFullPath(output), StringComparison.OrdinalIgnoreCase))
        {
            throw new ValidationException("output must be a different file: the original screenshot is kept unchanged (e.g. screenshots/raw/x.png → screenshots/annotated/x.png).");
        }
        if (!File.Exists(source))
        {
            throw new NotFoundException("Source screenshot");
        }
        var specs = (args.GetElement("annotations") is { ValueKind: JsonValueKind.Array } list ? list.EnumerateArray() : Enumerable.Empty<JsonElement>())
            .Select(a => new AnnotationSpec(
                Str(a, "type") ?? "", Str(a, "target"), a.TryGetProperty("rect", out var r) && r.ValueKind == JsonValueKind.Array ? r.EnumerateArray().Select(v => v.GetDouble()).ToArray() : null,
                a.TryGetProperty("number", out var n) && n.ValueKind == JsonValueKind.Number ? n.GetInt32() : null, Str(a, "text"), Str(a, "from"), Str(a, "to"), Str(a, "side")))
            .ToList();

        var png = await File.ReadAllBytesAsync(source, ct);
        PngImage image;
        try
        {
            image = PngImage.Decode(png);
        }
        catch (InvalidDataException ex)
        {
            throw new ValidationException(ex.Message);
        }
        var (targets, scale, captureNote) = await ReadCaptureAsync(source, ct);
        var layout = AnnotationRenderer.Layout(image, png, specs, targets, scale);

        var browser = HeadlessRender.LocateBrowser(Services, "the annotations cannot be drawn");
        var work = Path.Combine(Path.GetTempPath(), "docgen-annotate-" + Guid.NewGuid().ToString("N")[..12]);
        Directory.CreateDirectory(work);
        try
        {
            var svgPath = Path.Combine(work, "annotated.svg");
            await File.WriteAllTextAsync(svgPath, layout.Svg, ct);
            Directory.CreateDirectory(Path.GetDirectoryName(output)!);
            var failure = await ImageExportTool.SvgToPngAsync(browser, svgPath, output, image.Width, image.Height, ct);
            if (failure is not null)
            {
                return ToolResult.Fail(call, failure);
            }
        }
        finally
        {
            try { Directory.Delete(work, recursive: true); } catch (IOException) { }
        }

        var relativeOut = workspace.Relative(output).Replace('\\', '/');
        var relativeSource = workspace.Relative(source).Replace('\\', '/');
        await File.WriteAllTextAsync(Path.ChangeExtension(output, null) + ".annotations.json", JsonSerializer.Serialize(new
        {
            source = Path.GetRelativePath(Path.GetDirectoryName(output)!, source).Replace('\\', '/'),
            markers = layout.Markers.OrderBy(m => m.Number).Select(m => new { number = m.Number, target = m.Target, element = m.Description }),
            notes = layout.Notes.Select(m => new { kind = m.Kind, text = m.Text, target = m.Target }),
            warnings = layout.Warnings,
            annotatedAt = DateTimeOffset.UtcNow,
        }, new JsonSerializerOptions { WriteIndented = true }), ct);

        var sb = new StringBuilder($"Annotated {relativeSource} → {relativeOut} ({image.Width}×{image.Height}); the original is unchanged.");
        if (captureNote is not null)
        {
            sb.Append(' ').Append(captureNote);
        }
        foreach (var p in layout.Placed)
        {
            sb.Append("\n  ").Append(p);
        }
        if (layout.Markers.Count > 0)
        {
            sb.Append("\nLegend for the guide (marker → element): ").Append(string.Join("; ", layout.Markers.OrderBy(m => m.Number).Select(m => $"{m.Number} = {m.Description ?? m.Target}")));
        }
        foreach (var w in layout.Warnings)
        {
            sb.Append("\n  ⚠ ").Append(w);
        }
        var result = ToolResult.Ok(call, sb.ToString());
        result.FileChanges = [new FileChange { Path = relativeOut, Kind = "image" }];
        return result;
    }

    /// <summary>Targets recorded by browser_screenshot beside the source (x.png → x.capture.json).</summary>
    private static async Task<(Dictionary<string, AnnotationTarget> Targets, double Scale, string? Note)> ReadCaptureAsync(string source, CancellationToken ct)
    {
        var path = Path.ChangeExtension(source, null) + ".capture.json";
        var targets = new Dictionary<string, AnnotationTarget>(StringComparer.OrdinalIgnoreCase);
        if (!File.Exists(path))
        {
            return (targets, 1, "No .capture.json beside the source: only rect annotations can be placed (capture with browser_screenshot savePath + targets).");
        }
        using var doc = JsonDocument.Parse(await File.ReadAllTextAsync(path, ct));
        var root = doc.RootElement;
        var partial = new List<string>();
        var scale = root.TryGetProperty("devicePixelRatio", out var d) && d.ValueKind == JsonValueKind.Number ? d.GetDouble() : 1;
        if (root.TryGetProperty("targets", out var list) && list.ValueKind == JsonValueKind.Array)
        {
            foreach (var t in list.EnumerateArray())
            {
                if (t.TryGetProperty("found", out var found) && found.GetBoolean())
                {
                    var role = Str(t, "role");
                    var label = Str(t, "label");
                    if (t.TryGetProperty("partlyVisible", out var partly) && partly.ValueKind == JsonValueKind.True)
                    {
                        partial.Add(Str(t, "name") ?? "");
                    }
                    targets[Str(t, "name") ?? ""] = new AnnotationTarget(
                        new Rect(t.GetProperty("x").GetDouble(), t.GetProperty("y").GetDouble(), t.GetProperty("width").GetDouble(), t.GetProperty("height").GetDouble()),
                        label is { Length: > 0 } ? $"{role} \"{(label.Length > 50 ? label[..50] + "…" : label)}\"" : role);
                }
            }
        }
        return (targets, scale, partial.Count == 0 ? null
            : $"⚠ Only partly inside the screenshot: {string.Join(", ", partial)} — capture again with scrollTo (or fullPage) so the reader can see what is marked.");
    }

    private static string? Str(JsonElement e, string name) => e.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;
}
