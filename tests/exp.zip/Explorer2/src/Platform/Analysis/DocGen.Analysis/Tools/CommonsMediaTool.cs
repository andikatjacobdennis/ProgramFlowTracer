using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

/// <summary>
/// commons_media: finds and fetches existing images from Wikimedia Commons (the media library behind Wikipedia) —
/// for example a state's district map — with the author, licence and source the user must be given. Only Wikimedia's
/// own hosts are contacted; SVGs arrive as PNGs rendered by Wikimedia, so no downloaded markup is ever opened here.
/// </summary>
public sealed partial class CommonsMediaTool(AnalysisServices services) : AnalysisTool(services), IDynamicRiskTool
{
    private const string Api = "https://commons.wikimedia.org/w/api.php";
    private const long MaxBytes = 20 * 1024 * 1024;
    private static readonly HttpClient Http = CreateClient();

    public override string Name => "commons_media";

    public override string Description =>
        "Searches Wikimedia Commons (Wikipedia's image library) and fetches an existing image with its author and licence — e.g. district " +
        "maps of a state, historical maps, diagrams. action=search {query} lists files with licence, date and description; action=fetch " +
        "{title} saves the image to generated/wiki/ and shows it. Always give the user the attribution line from the result. For India's " +
        "national borders use map_render (India's official view): Commons maps may draw disputed borders differently — check the " +
        "description, and say so if a file's borders differ from India's official map.";

    public override string InputSchema => """
        {
          "type": "object",
          "properties": {
            "action": { "type": "string", "enum": ["search", "fetch"] },
            "query": { "type": "string", "maxLength": 200, "description": "search: what to look for, e.g. \"Rajasthan districts map\"." },
            "title": { "type": "string", "maxLength": 250, "description": "fetch: the file title from search, e.g. \"File:Rajasthan districts map.svg\"." },
            "width": { "type": "integer", "minimum": 200, "maximum": 3000, "description": "fetch: image width in pixels (default 1600; smaller originals keep their size)." }
          },
          "required": ["action"],
          "additionalProperties": false
        }
        """;

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    public Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken)
        => Task.FromResult(new ToolRiskAssessment(ToolRiskLevel.Write, Routine: true, Category: ApprovalCategories.WebReads,
            Summary: "Read Wikimedia Commons (and save the fetched image in generated/wiki/)"));

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct) => throw new NotSupportedException();

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
        => args.RequireString("action") switch
        {
            "search" => ToolResult.Ok(call, await SearchAsync(args.GetString("query") ?? throw new ValidationException("Give a query to search for."), ct)),
            "fetch" => await FetchAsync(call, args.GetString("title") ?? throw new ValidationException("Give the file title to fetch (from search)."), args.GetInt("width") ?? 1600, context, ct),
            _ => throw new ValidationException("action must be search or fetch."),
        };

    private static async Task<string> SearchAsync(string query, CancellationToken ct)
    {
        var search = await GetJsonAsync($"{Api}?action=query&format=json&list=search&srnamespace=6&srlimit=12&srsearch={Uri.EscapeDataString(query)}", ct);
        var titles = search.RootElement.GetProperty("query").GetProperty("search").EnumerateArray()
            .Select(r => r.GetProperty("title").GetString()!)
            .Where(t => ImageExtension().IsMatch(t))
            .Take(8).ToList();
        if (titles.Count == 0)
        {
            return $"No images on Wikimedia Commons match \"{query}\". Try other words (English names, \"map\", \"districts\"), or tell the user none was found.";
        }
        var infos = await InfoAsync(titles, 0, ct);
        var sb = new StringBuilder($"Wikimedia Commons results for \"{query}\" (fetch one with action=fetch and its title):\n");
        foreach (var i in infos)
        {
            sb.AppendLine($"- {i.Title} — {i.Mime}, {i.Width}×{i.Height}, uploaded {i.Date}, licence {i.License}; {Short(i.Description, 160)}");
        }
        sb.Append("Prefer the most recent file whose description matches what the user asked for (e.g. the current number of districts).");
        return sb.ToString();
    }

    private async Task<ToolResult> FetchAsync(ToolCall call, string title, int width, ToolExecutionContext context, CancellationToken ct)
    {
        title = title.Trim();
        if (!title.StartsWith("File:", StringComparison.OrdinalIgnoreCase))
        {
            title = "File:" + title;
        }
        var info = (await InfoAsync([title], Math.Clamp(width, 200, 3000), ct)).FirstOrDefault()
                   ?? throw new NotFoundException($"Wikimedia Commons file \"{title}\"");
        var url = info.ImageUrl ?? throw new ValidationException($"{title} has no downloadable image.");
        if (!IsWikimediaHost(url))
        {
            throw new ValidationException("The image is not hosted by Wikimedia, so it was not downloaded.");
        }
        using var response = await Http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, ct);
        if (response.StatusCode != HttpStatusCode.OK || response.Content.Headers.ContentType?.MediaType is not { } type || !type.StartsWith("image/", StringComparison.Ordinal) || type.Contains("svg", StringComparison.Ordinal))
        {
            throw new ToolException($"Wikimedia did not return an image for {title} ({(int)response.StatusCode}).");
        }
        var extension = type switch { "image/png" => ".png", "image/jpeg" => ".jpg", "image/gif" => ".gif", "image/webp" => ".webp", _ => throw new ToolException($"Unsupported image type {type}.") };
        await using var input = await response.Content.ReadAsStreamAsync(ct);
        using var memory = new MemoryStream();
        var buffer = new byte[81920];
        int read;
        while ((read = await input.ReadAsync(buffer, ct)) > 0)
        {
            if (memory.Length + read > MaxBytes)
            {
                throw new ToolException("The image is larger than 20 MB; ask for a smaller width.");
            }
            memory.Write(buffer, 0, read);
        }

        var baseName = SafeName().Replace(Path.GetFileNameWithoutExtension(title["File:".Length..]), "-").Trim('-').ToLowerInvariant();
        baseName = baseName.Length == 0 ? "commons-image" : baseName[..Math.Min(80, baseName.Length)];
        var folder = Path.Combine(context.WorkspaceRoot, "generated", "wiki");
        Directory.CreateDirectory(folder);
        var file = baseName + extension;
        await File.WriteAllBytesAsync(Path.Combine(folder, file), memory.ToArray(), ct);
        var attribution = $"\"{info.Title["File:".Length..]}\" by {info.Artist}, {info.License}{(info.LicenseUrl is { Length: > 0 } lu ? $" ({lu})" : "")}, via Wikimedia Commons: {info.PageUrl}";
        await File.WriteAllTextAsync(Path.Combine(folder, baseName + ".attribution.txt"),
            attribution + Environment.NewLine + "Description: " + info.Description + Environment.NewLine + "Uploaded: " + info.Date + Environment.NewLine, ct);

        var result = ToolResult.Ok(call,
            $"Saved {info.Title} as generated/wiki/{file} ({memory.Length:N0} bytes; shown to the user) with generated/wiki/{baseName}.attribution.txt.\n" +
            $"Description: {Short(info.Description, 300)}\nUploaded: {info.Date}\n" +
            $"Attribution to give the user with the image: {attribution}\n" +
            "State facts about this image only from its title, date and description above — never names or numbers read from the image by " +
            "OCR, which can be wrong. If several files matched, show the one most recent that fits and say why; mention an older one only " +
            "as older.");
        result.FileChanges = [new FileChange { Path = $"generated/wiki/{file}", Kind = "image" }, new FileChange { Path = $"generated/wiki/{baseName}.attribution.txt", Kind = "created" }];
        return result;
    }

    private sealed record Info(string Title, string Mime, int Width, int Height, string Date, string License, string? LicenseUrl, string Artist, string Description, string PageUrl, string? ImageUrl);

    private static async Task<List<Info>> InfoAsync(IReadOnlyList<string> titles, int width, CancellationToken ct)
    {
        var url = $"{Api}?action=query&format=json&prop=imageinfo&iiprop=url|size|mime|extmetadata|timestamp&titles={Uri.EscapeDataString(string.Join("|", titles))}" +
                  (width > 0 ? $"&iiurlwidth={width}" : "");
        using var doc = await GetJsonAsync(url, ct);
        var list = new List<Info>();
        if (!doc.RootElement.TryGetProperty("query", out var q) || !q.TryGetProperty("pages", out var pages))
        {
            return list;
        }
        foreach (var page in pages.EnumerateObject().Select(p => p.Value))
        {
            if (page.TryGetProperty("missing", out _) || !page.TryGetProperty("imageinfo", out var infos) || infos.GetArrayLength() == 0)
            {
                continue;
            }
            var i = infos[0];
            var meta = i.TryGetProperty("extmetadata", out var m) ? m : default;
            string Meta(string key) => meta.ValueKind == JsonValueKind.Object && meta.TryGetProperty(key, out var v) && v.TryGetProperty("value", out var value)
                ? Plain(value.ToString()) : "";
            // A rendered copy (thumbnail) when one was asked for; an SVG is only ever taken as Wikimedia's PNG rendering.
            var mime = i.GetProperty("mime").GetString() ?? "";
            var thumbUrl = i.TryGetProperty("thumburl", out var thumb) ? thumb.GetString() : null;
            var imageUrl = thumbUrl ?? (mime.Contains("svg", StringComparison.Ordinal) ? null : i.GetProperty("url").GetString());
            var rawDate = Meta("DateTimeOriginal") is { Length: > 0 } original ? original : i.GetProperty("timestamp").GetString() ?? "";
            list.Add(new Info(
                page.GetProperty("title").GetString() ?? "",
                mime,
                i.GetProperty("width").GetInt32(),
                i.GetProperty("height").GetInt32(),
                rawDate.Length > 10 ? rawDate[..10] : rawDate,
                Meta("LicenseShortName") is { Length: > 0 } l ? l : "licence not stated",
                Meta("LicenseUrl"),
                Meta("Artist") is { Length: > 0 } a ? Short(a, 120) : "unknown author",
                Meta("ImageDescription"),
                i.TryGetProperty("descriptionurl", out var du) ? du.GetString() ?? "" : "",
                imageUrl));
        }
        return list;
    }

    private static async Task<JsonDocument> GetJsonAsync(string url, CancellationToken ct)
    {
        try
        {
            using var response = await Http.GetAsync(url, ct);
            response.EnsureSuccessStatusCode();
            return await JsonDocument.ParseAsync(await response.Content.ReadAsStreamAsync(ct), cancellationToken: ct);
        }
        catch (HttpRequestException ex)
        {
            throw new ToolException($"Wikimedia Commons could not be reached: {ex.Message}");
        }
    }

    internal static bool IsWikimediaHost(string url)
        => Uri.TryCreate(url, UriKind.Absolute, out var u) && u.Scheme == Uri.UriSchemeHttps
           && (u.Host == "upload.wikimedia.org" || u.Host == "commons.wikimedia.org" || u.Host.EndsWith(".wikimedia.org", StringComparison.OrdinalIgnoreCase));

    private static HttpClient CreateClient()
    {
        var client = new HttpClient(new SocketsHttpHandler { AllowAutoRedirect = false, AutomaticDecompression = DecompressionMethods.All }) { Timeout = TimeSpan.FromSeconds(60) };
        // Wikimedia asks every client for a descriptive User-Agent.
        client.DefaultRequestHeaders.UserAgent.ParseAdd("DocGen/1.0 (local AI assistant; Wikimedia Commons lookup)");
        return client;
    }

    private static string Plain(string html) => WebUtility.HtmlDecode(Tags().Replace(html, "")).Replace('\n', ' ').Trim();

    private static string Short(string text, int max) => text.Length <= max ? text : text[..(max - 1)] + "…";

    [GeneratedRegex(@"\.(svg|png|jpe?g|gif|webp|tiff?)$", RegexOptions.IgnoreCase)]
    private static partial Regex ImageExtension();

    [GeneratedRegex("<[^>]+>")]
    private static partial Regex Tags();

    [GeneratedRegex(@"[^A-Za-z0-9._-]+")]
    private static partial Regex SafeName();
}
