using System.Text;
using System.Text.Json;
using DocGen.Analysis.Architecture;
using DocGen.Analysis.Indexing;
using DocGen.Analysis.Repositories;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

/// <summary>
/// architecture_docs: the deterministic half of the architect skill. Without a scope it documents the whole repository
/// (Repository Mode). With a scope — a folder or file path, project, class, Class.Method or feature words — it traces the
/// execution of just that part (Partial Architecture Mode): entry points, calls across projects, DI, databases, APIs and
/// messages, written as a focused bundle. trace answers "how does X flow" in chat without files. validate rebuilds the
/// navigation and checks a bundle; package validates and zips it. Output goes to the workspace, never into the repository.
/// </summary>
public sealed class ArchitectureDocsTool(AnalysisServices services) : AnalysisTool(services), IDynamicRiskTool
{
    public override string Name => "architecture_docs";

    public override string Description =>
        "Architecture documentation (the architect skill). scope = what to document: a folder/file path (absolute or repository-relative), a project, " +
        "a class, Class.Method, or feature words ('order service'); omit it only when the whole repository was asked for. " +
        "action=trace: trace the scope's execution (entry points, program-flow table, call chain, sequence diagram, project transitions, " +
        "database/API/message boundaries, uncertain calls) and return it as text — for questions about how something works; no files. " +
        "action=model: write the bundle to generated/architecture/<repo>/[<scope>/]architecture/ in the workspace, with " +
        "'<!-- architect:write … -->' markers where narrative is needed (rerunning keeps pages you finished; add 'also' targets to expand a scope). " +
        "action=validate: check JSON, links, markers, secrets, Mermaid syntax and (for a scope) that tables and diagrams match the trace. " +
        "action=package: validate, then ZIP (refused while errors remain).";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "action": { "type": "string", "enum": ["trace", "model", "validate", "package"] },
            "scope": { "type": "string", "description": "What to document: path, project, class, Class.Method or feature words. Omit for the whole repository." },
            "also": { "type": "array", "items": { "type": "string" }, "description": "Extra targets merged into the scope (expanding an existing bundle: 'also include OrderRepository')." },
            "depth": { "type": "integer", "minimum": 1, "maximum": 20, "description": "How deep to follow calls from each entry point (default 8)." },
            "max_steps": { "type": "integer", "minimum": 10, "maximum": 600, "description": "Most steps to trace (default 160)." },
            "include_tests": { "type": "boolean", "description": "Repository mode: include test projects (default true)." },
            "max_method_pages": { "type": "integer", "minimum": 0, "maximum": 1000, "description": "Most method pages (default 150 for a repository, 40 for a scope)." },
            "max_narrative_types": { "type": "integer", "minimum": 0, "maximum": 400, "description": "Key types whose pages get narrative (default 24; 10 for a scope)." },
            "max_narrative_methods": { "type": "integer", "minimum": 0, "maximum": 400, "description": "Key methods (repository) or program-flow steps (scope) with narrative (default 16)." }
          },
          "required": ["action"],
          "additionalProperties": false
        }
        """;

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    public Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken)
        => Task.FromResult(new ToolRiskAssessment(ToolRiskLevel.Write, Routine: true, Summary: "Write architecture documentation into generated/architecture/ in the workspace"));

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct) => throw new NotSupportedException();

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var action = args.RequireString("action");
        var scopeText = args.GetString("scope")?.Trim();
        var (repo, index) = await IndexForAsync(args, scopeText, context, ct);
        var name = ArchitectureWriter.Safe(repo.Name);
        var repoBundles = Path.Combine(context.WorkspaceRoot, "generated", "architecture", name);

        if (action is "model" or "trace")
        {
            if (index.Manifest.Stats.Files == 0)
            {
                throw new ValidationException($"The {repo.Name} repository has no indexed files; run index_repository first.");
            }
            var partialRequested = !string.IsNullOrEmpty(scopeText) || action == "trace";
            var model = await Task.Run(() => ArchitectureModelBuilder.Build(repo.Name, index, args.GetBool("include_tests") ?? !partialRequested, ct), ct);
            var scope = string.IsNullOrEmpty(scopeText) ? null : ScopeResolver.Resolve(scopeText, index, model, repo.Root);
            if (scope is null && action == "trace")
            {
                throw new ValidationException("trace needs a scope: the folder, project, class, method or feature to follow.");
            }
            if (scope is not null)
            {
                foreach (var extra in args.GetStringArray("also"))
                {
                    if (ScopeResolver.Resolve(extra, index, model, repo.Root) is { } more)
                    {
                        scope.Files.UnionWith(more.Files);
                        scope.Types.AddRange(more.Types.Where(t => !scope.Types.Contains(t)));
                        scope.Methods.AddRange(more.Methods.Where(m => !scope.Methods.Contains(m)));
                        scope.Notes.Add($"Expanded with {more.Kind} '{extra}'.");
                    }
                }
                var trace = await Task.Run(() => FlowTracer.Trace(scope, index, model, new FlowTracer.Options(MaxDepth: args.GetInt("depth") ?? 8, MaxSteps: args.GetInt("max_steps") ?? 160), ct), ct);
                if (action == "trace")
                {
                    return ToolResult.Ok(call, PartialWriter.ChatSummary(trace) + "\nAnswer from this trace (tables and diagrams above use real names). Read the source of the key steps before explaining what they do; for files, use action=model with the same scope.");
                }
                return ModelPartial(call, args, repo, model, trace, repoBundles);
            }
            return ModelRepository(call, args, repo, model, repoBundles);
        }

        var (outDir, zipName, label) = FindBundle(repoBundles, name, scopeText);
        ArchitectureBundle.BuildIndexes(outDir);
        string? browser = null;
        try
        {
            browser = HeadlessRender.LocateBrowser(Services, "Mermaid diagrams cannot be checked");
        }
        catch (ValidationException)
        {
        }
        var check = await ArchitectureBundle.ValidateAsync(outDir, browser, ArchitectureBundle.FindMermaidScript(), ct);
        var report = new StringBuilder();
        report.AppendLine($"{label}: checked {check.Markdown} Markdown and {check.Json} JSON files, {check.Diagrams} Mermaid diagrams ({check.DiagramsValidated} parsed by Mermaid; " +
                          $"{string.Join(", ", check.DiagramTypes.Select(t => $"{t.Value} {t.Key}"))}).");
        foreach (var w in check.Warnings)
        {
            report.AppendLine("Warning: " + w);
        }
        if (check.Errors.Count > 0)
        {
            report.AppendLine($"{check.Errors.Count} problems:");
            foreach (var e in check.Errors.Take(50))
            {
                report.AppendLine("- " + e);
            }
            if (check.Errors.Count > 50)
            {
                report.AppendLine($"- … and {check.Errors.Count - 50} more");
            }
        }
        if (action == "validate")
        {
            report.Append(check.Errors.Count == 0 ? "The bundle is valid; package it with action=package." : "Fix these, then validate again.");
            return ToolResult.Ok(call, report.ToString());
        }
        if (action != "package")
        {
            throw new ValidationException("action must be trace, model, validate or package.");
        }
        if (check.Errors.Count > 0)
        {
            return ToolResult.Fail(call, report + "Not packaged: fix the problems above first.");
        }
        var bundleRoot = Path.GetDirectoryName(outDir)!;
        var zip = Path.Combine(bundleRoot, zipName);
        var entries = ArchitectureBundle.Package(outDir, zip);
        var relativeZip = Path.GetRelativePath(context.WorkspaceRoot, zip).Replace('\\', '/');
        var packaged = ToolResult.Ok(call, report + $"Packaged {entries} files into {relativeZip} ({new FileInfo(zip).Length:N0} bytes; entry point architecture/00-index.md). The user has a download button.");
        packaged.FileChanges = [new FileChange { Path = relativeZip, Kind = "download", LinesAdded = (int)Math.Min(int.MaxValue, new FileInfo(zip).Length) }];
        return packaged;
    }

    /// <summary>The repository to analyse: the one named, else the one containing an absolute scope path, else the chat's.</summary>
    private async Task<(RepositoryHandle Repo, CodeIndex Index)> IndexForAsync(ToolArguments args, string? scope, ToolExecutionContext context, CancellationToken ct)
    {
        if (string.IsNullOrEmpty(args.GetString("repository")) && scope is { Length: > 0 } && Path.IsPathFullyQualified(scope.Trim('"')))
        {
            var repo = await Services.RepositoryContainingAsync(scope.Trim('"'), context, ct)
                       ?? throw new ValidationException($"No repository you can access contains {scope}. Register the repository first (or pass repository).");
            return (repo, await Services.Indexes.GetAsync(repo, ct));
        }
        return await Services.IndexAsync(args, context, ct);
    }

    private static ToolResult ModelRepository(ToolCall call, ToolArguments args, RepositoryHandle repo, ArchitectureModel model, string repoBundles)
    {
        var relativeRoot = $"generated/architecture/{ArchitectureWriter.Safe(repo.Name)}";
        var outDir = Path.Combine(repoBundles, "architecture");
        var written = ArchitectureWriter.WriteAll(model, outDir, args.GetInt("max_method_pages") ?? 150, args.GetInt("max_narrative_types") ?? 24, args.GetInt("max_narrative_methods") ?? 16);
        ArchitectureBundle.BuildIndexes(outDir);
        var sb = new StringBuilder();
        sb.AppendLine($"Repository Mode — architecture model of {repo.Name}: {model.Projects.Count} projects, {model.Types.Count} types ({model.Types.Count(t => t.Tier == 1)} tier 1), {model.Methods.Count} methods, " +
                      $"{model.Endpoints.Count} API endpoints, {model.Entities.Count} database entities, {model.Relationships.Count} relationships, {model.ProjectCycles.Count} project cycles.");
        sb.AppendLine($"Wrote {written.Files} files ({written.Diagrams} diagrams, {written.TypePages} type pages, {written.MethodPages} method pages" +
                      $"{(written.MethodPagesSkipped > 0 ? $"; {written.MethodPagesSkipped} more important methods over the page limit" : "")}{(written.KeptPages > 0 ? $"; kept {written.KeptPages} pages already finished" : "")}; narrative for {written.NarrativeTypes} key types and {written.NarrativeMethods} key methods).");
        sb.AppendLine($"Bundle: {relativeRoot}/architecture/ in the workspace (absolute {outDir}).");
        AppendMarkers(sb, outDir, $"{relativeRoot}/architecture/");
        sb.Append("Also add scenario pages (scenarios/<name>.md) with activity and sequence diagrams. Then action=validate, fix what it reports, and action=package.");
        var result = ToolResult.Ok(call, sb.ToString());
        result.FileChanges = [new FileChange { Path = $"{relativeRoot}/architecture/00-index.md", Kind = "created" }];
        return result;
    }

    private static ToolResult ModelPartial(ToolCall call, ToolArguments args, RepositoryHandle repo, ArchitectureModel model, FlowTrace trace, string repoBundles)
    {
        var scope = trace.Scope;
        var relativeRoot = $"generated/architecture/{ArchitectureWriter.Safe(repo.Name)}/{scope.Slug}";
        var outDir = Path.Combine(repoBundles, scope.Slug, "architecture");
        var written = PartialWriter.Write(trace, model, outDir, args.GetInt("max_narrative_methods") ?? 16, args.GetInt("max_narrative_types") ?? 10, args.GetInt("max_method_pages") ?? 40);
        ArchitectureBundle.BuildIndexes(outDir);
        var sb = new StringBuilder();
        sb.AppendLine($"Partial Architecture Mode — {scope.Kind} '{scope.Target}' in {repo.Name} (the rest of the repository is context only).");
        foreach (var note in scope.Notes) sb.AppendLine("Note: " + note);
        sb.AppendLine($"Traced {trace.Entries.Count} entry points → {trace.Steps.Count} steps, {trace.Projects.Count()} projects ({string.Join(", ", trace.Projects)}), " +
                      $"{trace.Transitions.Count()} project transitions, {trace.BoundaryEdges.Count()} database/API/message/file calls, {trace.Ambiguities.Count} uncertain calls not followed.");
        foreach (var e in trace.Entries) sb.AppendLine($"- Entry: {e.Description} — {e.Root.Display} ({e.Root.Symbol.File}:{e.Root.Symbol.StartLine})");
        foreach (var limit in trace.Limits) sb.AppendLine("Limit: " + limit);
        sb.AppendLine($"Wrote {written.Files} files ({written.Diagrams} diagrams, {written.ClassPages} class pages, {written.MethodPages} method pages; narrative for {written.NarrativeSteps} steps{(written.KeptPages > 0 ? $"; kept {written.KeptPages} pages already finished" : "")}).");
        sb.AppendLine($"Bundle: {relativeRoot}/architecture/ in the workspace (absolute {outDir}). The program-flow table, call chain, call graph and sequence diagrams are generated from the trace — do not rewrite them; write the narrative and the activity diagrams.");
        AppendMarkers(sb, outDir, $"{relativeRoot}/architecture/");
        sb.Append($"Then action=validate with the same scope, fix what it reports, and action=package (ZIP: {ArchitectureWriter.Safe(repo.Name)}-{scope.Slug}-architecture.zip).");
        var result = ToolResult.Ok(call, sb.ToString());
        result.FileChanges = [new FileChange { Path = $"{relativeRoot}/architecture/00-index.md", Kind = "created" }];
        return result;
    }

    private static void AppendMarkers(StringBuilder sb, string outDir, string prefix)
    {
        var markers = Directory.EnumerateFiles(outDir, "*.md", SearchOption.AllDirectories)
            .Select(f => (File: Path.GetRelativePath(outDir, f).Replace('\\', '/'), Count: System.Text.RegularExpressions.Regex.Matches(File.ReadAllText(f), ArchitectureWriter.Marker).Count))
            .Where(x => x.Count > 0).OrderBy(x => x.File, StringComparer.Ordinal).ToList();
        sb.AppendLine($"Write the narrative with file_write using repository \"workspace\" and paths under {prefix} — read the source with read_symbol / read_source_range first; never guess.");
        sb.AppendLine($"Pages with sections to write ({markers.Sum(m => m.Count)} markers in {markers.Count} pages):");
        foreach (var (file, count) in markers.Take(60))
        {
            sb.AppendLine($"- {file} ({count})");
        }
        if (markers.Count > 60)
        {
            sb.AppendLine($"- … and {markers.Count - 60} more (architecture_docs action=validate lists what is left).");
        }
        if (markers.Count > 0)
        {
            sb.AppendLine("Running short of tool calls? Rerun action=model with smaller max_narrative_types / max_narrative_methods: written pages are kept and unwritten key pages become computed-facts pages.");
        }
    }

    /// <summary>
    /// The bundle to validate or package: the scope's (matched by its request, label or folder name), else the repository
    /// bundle, else the only scoped bundle. Returns the bundle folder, ZIP name and a label.
    /// </summary>
    private static (string OutDir, string Zip, string Label) FindBundle(string repoBundles, string repoName, string? scopeText)
    {
        var partials = Directory.Exists(repoBundles)
            ? Directory.EnumerateDirectories(repoBundles).Select(d => Path.Combine(d, "architecture")).Where(ArchitectureBundle.IsPartial).ToList()
            : [];
        (string, string, string) Partial(string dir)
        {
            var slug = Path.GetFileName(Path.GetDirectoryName(dir))!;
            return (dir, $"{repoName}-{slug}-architecture.zip", $"Scope '{slug}'");
        }
        if (!string.IsNullOrEmpty(scopeText))
        {
            var wanted = scopeText.Trim().Trim('"');
            foreach (var dir in partials)
            {
                using var doc = JsonDocument.Parse(File.ReadAllText(Path.Combine(dir, "inventory", "scope.json")));
                var s = doc.RootElement.GetProperty("scope");
                var candidates = new[] { s.GetProperty("target").GetString(), s.GetProperty("label").GetString(), Path.GetFileName(Path.GetDirectoryName(dir)) };
                if (candidates.Any(c => c is not null && (string.Equals(c, wanted, StringComparison.OrdinalIgnoreCase) || string.Equals(ArchitectureWriter.Safe(c), ArchitectureWriter.Safe(wanted), StringComparison.OrdinalIgnoreCase))))
                {
                    return Partial(dir);
                }
            }
            throw new ValidationException($"No architecture bundle for scope '{scopeText}' yet; run architecture_docs action=model with that scope first." +
                                          (partials.Count > 0 ? $" Existing scoped bundles: {string.Join(", ", partials.Select(p => Path.GetFileName(Path.GetDirectoryName(p))))}." : ""));
        }
        var repositoryBundle = Path.Combine(repoBundles, "architecture");
        if (Directory.Exists(repositoryBundle))
        {
            return (repositoryBundle, $"{repoName}-architecture.zip", "Repository bundle");
        }
        if (partials.Count == 1)
        {
            return Partial(partials[0]);
        }
        throw new ValidationException(partials.Count == 0
            ? $"No architecture bundle for {repoName} yet; run architecture_docs action=model first."
            : $"Several scoped bundles exist ({string.Join(", ", partials.Select(p => Path.GetFileName(Path.GetDirectoryName(p))))}); pass scope to choose one.");
    }
}
