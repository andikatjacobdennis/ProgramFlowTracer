using System.Text;
using System.Text.RegularExpressions;
using DocGen.Analysis.Maps;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

/// <summary>
/// local_map: a map of a village, town or neighbourhood from OpenStreetMap — the place is looked up by name (so where
/// it is comes from data, not memory) and the real roads, rivers, water, settlements and landmarks around it are drawn.
/// </summary>
public sealed partial class LocalMapTool(AnalysisServices services) : AnalysisTool(services), IDynamicRiskTool
{
    public override string Name => "local_map";

    public override string Description =>
        "Draws a map of a village, town, locality or neighbourhood from OpenStreetMap data: finds the place by name, then draws the real " +
        "roads, rivers and streams, water, railways, nearby villages and landmarks around it (SVG + PNG in generated/maps/, shown in the " +
        "reply). Use it for places too small for map_render. The result gives the place's address as OpenStreetMap records it (district, " +
        "state, PIN) — state where a place is only from that, never from memory. If the place is not found, say so plainly.";

    public override string InputSchema => """
        {
          "type": "object",
          "properties": {
            "place": { "type": "string", "minLength": 2, "maxLength": 120, "description": "The place, as specific as you know it, e.g. \"Thammanimattam, Ernakulam, Kerala\"." },
            "country": { "type": "string", "maxLength": 2, "description": "ISO alpha-2 country code to search in (default: the user's country, then worldwide)." },
            "radius_km": { "type": "number", "minimum": 0.3, "maximum": 8, "description": "How far around the place to show (default 2)." },
            "title": { "type": "string", "maxLength": 100 },
            "name": { "type": "string", "maxLength": 60, "description": "File name (default from the place)." },
            "width": { "type": "integer", "minimum": 600, "maximum": 2400 }
          },
          "required": ["place"],
          "additionalProperties": false
        }
        """;

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    public Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken)
        => Task.FromResult(new ToolRiskAssessment(ToolRiskLevel.Write, Routine: true, Category: ApprovalCategories.WebReads,
            Summary: "Look up a place on OpenStreetMap and draw the area into generated/maps/"));

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct) => throw new NotSupportedException();

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var query = args.RequireString("place").Trim();
        var country = args.GetString("country") is { Length: 2 } c ? c : await UserCountryAsync(context, ct);
        var found = await OpenStreetMap.FindAsync(query, country, ct);
        if (found.Count == 0 && country is not null)
        {
            found = await OpenStreetMap.FindAsync(query, null, ct);
        }
        if (found.Count == 0)
        {
            return ToolResult.Ok(call, $"No place called \"{query}\" was found on OpenStreetMap{(country is null ? "" : " (searched " + country + ", then worldwide)")}. " +
                                       "Tell the user plainly it was not found; ask for another spelling or the nearest town. Do not draw anything.");
        }
        // A spelling that only matches things named after the place (a pond, a school "…, Thammanimattom") finds the
        // settlement through their address: look up the address part that is spelled like the request.
        string? spelling = null;
        if (found[0].Category is not ("place" or "boundary"))
        {
            var wanted = query.Split(',')[0].Trim();
            var near = found.SelectMany(f => new[] { "suburb", "village", "hamlet", "town", "neighbourhood", "quarter", "locality", "city" }
                    .Select(k => f.Address.GetValueOrDefault(k)))
                .OfType<string>()
                .FirstOrDefault(v => !string.Equals(v, wanted, StringComparison.OrdinalIgnoreCase) && CloseSpelling(v, wanted));
            if (near is not null)
            {
                var again = await OpenStreetMap.FindAsync(near + query[wanted.Length..], country ?? found[0].Address.GetValueOrDefault("country_code"), ct);
                if (again.FirstOrDefault(f => f.Category is "place" or "boundary") is { } settlement)
                {
                    found = [settlement, .. found];
                    spelling = near;
                }
            }
        }
        var place = found[0];
        var radiusKm = Math.Clamp(args.GetElement("radius_km") is { ValueKind: System.Text.Json.JsonValueKind.Number } r ? r.GetDouble() : 2, 0.3, 8);
        var features = await OpenStreetMap.AroundAsync(place.Lat, place.Lon, (int)(radiusKm * 1000 * 1.45), ct); // corners of the square view
        var title = args.GetString("title");
        var caption = OpenStreetMap.Attribution + " Not an official map" +
                      (string.Equals(country, "IN", StringComparison.OrdinalIgnoreCase) || place.Address.GetValueOrDefault("country_code") == "in"
                          ? ": the Survey of India publishes official maps." : ".");
        var map = LocalMapRenderer.Render(place, features, radiusKm, title, caption, args.GetInt("width") ?? 1000);

        var baseName = SafeName().Replace(args.GetString("name") is { Length: > 0 } n ? n : title ?? place.DisplayName.Split(',')[0] + "-map", "-").Trim('-').ToLowerInvariant();
        baseName = baseName.Length == 0 ? "local-map" : baseName[..Math.Min(60, baseName.Length)];
        var folder = Path.Combine(context.WorkspaceRoot, "generated", "maps");
        Directory.CreateDirectory(folder);
        var svgPath = Path.Combine(folder, baseName + ".svg");
        await File.WriteAllTextAsync(svgPath, map.Svg, new UTF8Encoding(false), ct);
        var changes = new List<FileChange> { new() { Path = $"generated/maps/{baseName}.svg", Kind = "created" } };
        string? pngNote = null;
        try
        {
            var browser = HeadlessRender.LocateBrowser(Services, "the map could not be rendered to PNG");
            var failure = await ImageExportTool.SvgToPngAsync(browser, svgPath, Path.Combine(folder, baseName + ".png"), map.Width * 2, map.Height * 2, ct);
            if (failure is null)
            {
                changes.Add(new FileChange { Path = $"generated/maps/{baseName}.png", Kind = "image" });
            }
            else
            {
                pngNote = "The PNG could not be made: " + failure;
            }
        }
        catch (ValidationException ex)
        {
            pngNote = ex.Message;
        }

        var address = string.Join(", ", new[] { "suburb", "village", "hamlet", "town", "city", "municipality", "county", "state_district", "state", "postcode", "country" }
            .Select(k => place.Address.TryGetValue(k, out var v) ? $"{k.Replace('_', ' ')}: {v}" : null).OfType<string>());
        var text = new StringBuilder();
        if (spelling is not null)
        {
            text.AppendLine($"OpenStreetMap spells the place \"{spelling}\" (the request said \"{query.Split(',')[0].Trim()}\"); tell the user.");
        }
        text.AppendLine($"Found on OpenStreetMap: {place.DisplayName} ({place.Lat:0.00000}, {place.Lon:0.00000}; mapped as a {place.Type}).");
        text.AppendLine($"Address parts: {address}.");
        if (found.Count > 1)
        {
            text.AppendLine($"Other matches (not drawn): {string.Join(" | ", found.Skip(1).Take(3).Select(f => f.DisplayName))}.");
        }
        text.AppendLine($"Drew {radiusKm:0.#} km around it to generated/maps/{baseName}.svg{(changes.Count > 1 ? " and .png (shown to the user)" : "")}: " +
                        $"{map.Roads} roads, {map.Waterways} waterways, places {string.Join(", ", map.Places)}; landmarks {(map.Landmarks.Count > 0 ? string.Join(", ", map.Landmarks) : "none mapped")}.");
        if (pngNote is not null)
        {
            text.AppendLine(pngNote);
        }
        text.Append("Give the user the attribution (© OpenStreetMap contributors, ODbL) and say where the place is only from the address above. " +
                    "OpenStreetMap is community-mapped: it is real data but not an official survey.");
        var result = ToolResult.Ok(call, text.ToString());
        result.FileChanges = changes;
        return result;
    }

    /// <summary>Same first letter and at most two letters different (Thammanimattom / Thammanimattam).</summary>
    internal static bool CloseSpelling(string a, string b)
    {
        a = a.Trim().ToLowerInvariant();
        b = b.Trim().ToLowerInvariant();
        if (a.Length == 0 || b.Length == 0 || a[0] != b[0] || Math.Abs(a.Length - b.Length) > 2)
        {
            return false;
        }
        var d = new int[a.Length + 1, b.Length + 1];
        for (var i = 0; i <= a.Length; i++) d[i, 0] = i;
        for (var j = 0; j <= b.Length; j++) d[0, j] = j;
        for (var i = 1; i <= a.Length; i++)
        {
            for (var j = 1; j <= b.Length; j++)
            {
                d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1), d[i - 1, j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1));
            }
        }
        return d[a.Length, b.Length] <= 2;
    }

    private async Task<string?> UserCountryAsync(ToolExecutionContext context, CancellationToken ct)
        => Services.Service<IUserRepository>() is { } users && await users.GetAsync(context.UserId, ct) is { } user
            ? user.Preferences?.Country is { Length: 2 } code ? code : null
            : UserCountries.Default;

    [GeneratedRegex(@"[^A-Za-z0-9._-]+")]
    private static partial Regex SafeName();
}
