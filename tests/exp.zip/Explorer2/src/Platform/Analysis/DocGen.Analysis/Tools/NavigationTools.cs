using System.Text;
using DocGen.Analysis.Indexing;
using DocGen.Analysis.Repositories;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

public sealed class RepoListTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "repo_list";

    public override string Description => "Lists the source repositories you can analyse (your workspace plus any configured by the administrator) and their index status.";

    public override string InputSchema => """{ "type": "object", "properties": {}, "additionalProperties": false }""";

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var sb = new StringBuilder();
        foreach (var repo in await Services.Repositories.ListAsync(context.UserId, ct))
        {
            var manifest = await Services.Indexes.GetManifestAsync(repo, ct);
            var status = manifest?.LastIndexedAt is { } at
                ? $"indexed {at:yyyy-MM-dd HH:mm} UTC: {manifest.Stats.Files:N0} files, {manifest.Stats.Symbols:N0} symbols, {manifest.Stats.Projects} projects"
                : "not indexed yet (indexed automatically on first use)";
            sb.AppendLine($"- {repo.Name} ({repo.Source}; commands {(repo.AllowCommands ? "allowed" : "disabled")}; edits {(repo.AllowWrite ? "allowed" : "disabled")}) — {status}");
        }
        return sb.ToString();
    }
}

public sealed class IndexRepositoryTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "index_repository";

    public override string Description => "Builds or incrementally updates the code index of a repository (only changed files are re-parsed). Other tools do this automatically; use full=true to rebuild from scratch.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "full": { "type": "boolean", "description": "Rebuild the whole index." }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var repo = await Services.RepositoryAsync(args, context, ct);
        var r = await Services.Indexes.UpdateAsync(repo, args.GetBool("full") == true, ct);
        return $"Index of '{repo.Name}' {(r.Full ? "rebuilt" : "updated")} in {r.DurationMs:N0} ms: {r.Scanned:N0} files scanned, {r.Added:N0} added, {r.Changed:N0} changed, " +
               $"{r.Removed:N0} removed, {r.Unchanged:N0} unchanged. Totals: {r.Stats.Files:N0} files ({r.Stats.ParsedFiles:N0} parsed), {r.Stats.Symbols:N0} symbols " +
               $"({r.Stats.Types:N0} types), {r.Stats.Projects} projects, {r.Stats.Relationships:N0} relationships.";
    }
}

public sealed class SolutionOverviewTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "solution_overview";

    public override string Description =>
        "Start here. High-level map of a repository: solutions, projects (frameworks, type, size, references, packages), entry points, hosted services, " +
        "endpoint/DI/config counts. Drill down with project_overview, find_symbol and read_symbol instead of reading files.";

    public override string InputSchema => $$"""{ "type": "object", "properties": { {{RepositoryProperty}} }, "additionalProperties": false }""";

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        var m = index.Manifest;
        var sb = new StringBuilder();
        var csFiles = index.Files.Values.Count(f => f.Language == "cs");
        sb.AppendLine($"Repository '{repo.Name}': {m.Stats.Files:N0} files ({csFiles:N0} C#), {m.Stats.Symbols:N0} symbols ({m.Stats.Types:N0} types), {m.Stats.Projects} projects, {m.Stats.Relationships:N0} relationships; index updated {m.LastIndexedAt:HH:mm:ss} UTC.");
        foreach (var solution in m.Solutions.Take(10))
        {
            sb.AppendLine($"Solution {solution.Path}: {solution.Projects.Count} projects");
        }
        var filesPerProject = index.Files.Values.GroupBy(f => f.Project).ToDictionary(g => g.Key, g => (Files: g.Count(), Symbols: g.Sum(f => f.Symbols.Count)), StringComparer.OrdinalIgnoreCase);
        sb.AppendLine("Projects:");
        foreach (var p in m.Projects.Take(200))
        {
            var counts = filesPerProject.GetValueOrDefault(p.Name);
            var kind = p.IsTestProject ? "test" : string.Equals(p.OutputType, "Exe", StringComparison.OrdinalIgnoreCase) || p.Sdk?.Contains("Web", StringComparison.OrdinalIgnoreCase) == true ? "app" : "library";
            var refs = index.ProjectReferencesOf(p.Name);
            var direct = p.Packages.Where(x => !x.Transitive).ToList();
            sb.Append($"- {p.Name} ({string.Join(";", p.TargetFrameworks)}, {kind}) — {counts.Files} files, {counts.Symbols:N0} symbols");
            if (refs.Count > 0)
            {
                sb.Append($"; refs: {string.Join(", ", refs.Take(8))}{(refs.Count > 8 ? $" +{refs.Count - 8}" : "")}");
            }
            if (direct.Count > 0)
            {
                sb.Append($"; packages: {string.Join(", ", direct.Take(6).Select(x => $"{x.Id} {x.ResolvedVersion ?? x.Version}"))}{(direct.Count > 6 ? $" +{direct.Count - 6}" : "")}");
            }
            sb.AppendLine();
        }
        if (m.Projects.Count > 200)
        {
            sb.AppendLine($"… {m.Projects.Count - 200} more projects.");
        }
        var entryPoints = index.Symbols.Where(s => s.Kind == SymbolKinds.TopLevel || s.Name == "Main" && s.Modifiers.Contains("static")).Take(10).ToList();
        if (entryPoints.Count > 0)
        {
            sb.AppendLine("Entry points: " + string.Join(", ", entryPoints.Select(s => $"{s.File}{(s.Kind == SymbolKinds.TopLevel ? " (top-level statements)" : "")}")));
        }
        var hosted = index.Registrations.Where(r => r.Hosted).Select(r => r.ImplementationType)
            .Concat(index.Types.Where(t => t.Bases.Any(b => b is "BackgroundService" or "IHostedService")).Select(t => t.Name))
            .Distinct().Take(20).ToList();
        if (hosted.Count > 0)
        {
            sb.AppendLine("Hosted/background services: " + string.Join(", ", hosted));
        }
        var endpointStyles = index.Endpoints.GroupBy(e => e.Style).Select(g => $"{g.Key} {g.Count()}");
        sb.AppendLine($"Endpoints: {index.Endpoints.Count} ({string.Join(", ", endpointStyles)}) · DI registrations: {index.Registrations.Count} · middleware: {index.Middleware.Count} · " +
                      $"config references: {index.ConfigReferences.Count} · config keys in appsettings: {index.ConfigValues.Count}");
        var tests = index.TestMethods.Count();
        sb.AppendLine($"Tests: {tests:N0} test methods in {m.Projects.Count(p => p.IsTestProject)} test projects.");
        sb.AppendLine("Next: project_overview project=<name> · find_symbol query=<name> · analyze_stacktrace / analyze_test_failure for a failure.");
        return sb.ToString();
    }
}

public sealed class ProjectOverviewTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "project_overview";

    public override string Description => "Summarises one project: namespaces, most-referenced types, DI registrations, endpoints, configuration, middleware, packages and project references.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "project": { "type": "string", "minLength": 1, "maxLength": 200 }
          },
          "required": ["project"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (_, index) = await Services.IndexAsync(args, context, ct);
        var name = args.RequireString("project");
        if (!index.Projects.TryGetValue(name, out var project))
        {
            var suggestions = index.Projects.Keys.Where(k => k.Contains(name, StringComparison.OrdinalIgnoreCase)).Take(5).ToList();
            throw new ValidationException($"Unknown project '{name}'." + (suggestions.Count > 0 ? " Did you mean: " + string.Join(", ", suggestions) : ""));
        }
        var files = index.Files.Values.Where(f => f.Project.Equals(project.Name, StringComparison.OrdinalIgnoreCase)).ToList();
        var symbols = files.SelectMany(f => f.Symbols).ToList();
        var sb = new StringBuilder();
        sb.AppendLine($"Project {project.Name} ({project.Path}) — {string.Join(";", project.TargetFrameworks)}, {(project.IsTestProject ? "test project" : project.OutputType ?? "library")}, " +
                      $"{files.Count} files, {symbols.Count:N0} symbols, nullable {project.Nullable ?? "default"}");
        sb.AppendLine("References: " + (project.ProjectReferences.Count == 0 ? "none" : string.Join(", ", index.ProjectReferencesOf(project.Name))));
        var dependents = index.ReverseProjectClosure(project.Name);
        sb.AppendLine("Referenced by (transitively): " + (dependents.Count == 0 ? "none" : string.Join(", ", dependents.Take(20))));
        var direct = project.Packages.Where(p => !p.Transitive).ToList();
        sb.AppendLine($"Packages: {(direct.Count == 0 ? "none" : string.Join(", ", direct.Select(p => $"{p.Id} {p.Version}{(p.ResolvedVersion is { } rv && rv != p.Version ? $" (resolved {rv})" : "")}")))}; transitive: {project.Packages.Count(p => p.Transitive)}");
        if (project.FrameworkReferences.Count > 0)
        {
            sb.AppendLine("Framework references: " + string.Join(", ", project.FrameworkReferences));
        }
        sb.AppendLine("Namespaces:");
        foreach (var ns in symbols.Where(s => SymbolKinds.IsType(s.Kind)).GroupBy(s => s.Namespace).OrderByDescending(g => g.Count()).Take(25))
        {
            sb.AppendLine($"- {(ns.Key.Length == 0 ? "(global)" : ns.Key)}: {ns.Count()} types");
        }
        var types = symbols.Where(s => SymbolKinds.IsType(s.Kind) && s.Container is null)
            .Select(t => (Type: t, Refs: index.UsersByName(t.Name).Count + index.CallersByName(t.Name).Count))
            .OrderByDescending(x => x.Refs).Take(15).ToList();
        sb.AppendLine("Most referenced types:");
        foreach (var (type, refs) in types)
        {
            sb.AppendLine($"- {type.Kind} {type.FullName} ({refs} referencing members) — {type.File}:{type.StartLine}{(type.Bases.Count > 0 ? " : " + string.Join(", ", type.Bases) : "")}");
        }
        var paths = files.Select(f => f.Path).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var registrations = index.Registrations.Where(r => paths.Contains(r.File)).ToList();
        if (registrations.Count > 0)
        {
            sb.AppendLine($"DI registrations ({registrations.Count}):");
            foreach (var r in registrations.Take(25))
            {
                sb.AppendLine($"- {r.Lifetime} {r.ServiceType} → {r.ImplementationType}{(r.Factory ? " (factory)" : "")} — {r.File}:{r.Line}");
            }
        }
        var endpoints = index.Endpoints.Where(e => paths.Contains(e.File)).ToList();
        if (endpoints.Count > 0)
        {
            sb.AppendLine($"Endpoints ({endpoints.Count}):");
            foreach (var e in endpoints.Take(30))
            {
                sb.AppendLine($"- {e.Verb} {e.Route} → {e.Handler} — {e.File}:{e.Line}");
            }
        }
        var middleware = index.Middleware.Where(m => paths.Contains(m.File)).OrderBy(m => m.File).ThenBy(m => m.Order).ToList();
        if (middleware.Count > 0)
        {
            sb.AppendLine("Middleware order: " + string.Join(" → ", middleware.Select(m => m.Name)));
        }
        var config = index.ConfigReferences.Where(c => paths.Contains(c.File)).Select(c => c.Key).Where(k => k.Length > 0).Distinct().Take(30).ToList();
        if (config.Count > 0)
        {
            sb.AppendLine("Configuration keys used: " + string.Join(", ", config));
        }
        return sb.ToString();
    }
}

public sealed class FindSymbolTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "find_symbol";

    public override string Description => "Finds types and members by name (exact, prefix, CamelHumps like 'OrdSvc', substring or qualified 'Type.Member'). Returns locations and signatures, not source.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "query": { "type": "string", "minLength": 1, "maxLength": 300 },
            "kind": { "type": "string", "enum": ["type", "member", "test", "class", "interface", "record", "struct", "enum", "method", "constructor", "property", "field", "event"] },
            "project": { "type": "string", "maxLength": 200 },
            "includeTests": { "type": "boolean" },
            "limit": { "type": "integer", "minimum": 1, "maximum": 100 }
          },
          "required": ["query"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (_, index) = await Services.IndexAsync(args, context, ct);
        var results = index.Search(args.RequireString("query"), args.GetString("kind"), args.GetString("project"), args.GetBool("includeTests") ?? false, Clamp(args.GetInt("limit"), 20, 1, 100));
        if (results.Count == 0)
        {
            return "No matching symbols. Try a shorter name, CamelHumps (e.g. 'OrdSvc'), or search_code for text.";
        }
        var sb = new StringBuilder($"{results.Count} symbols:\n");
        foreach (var (s, _) in results)
        {
            sb.AppendLine($"- {AnalysisServices.Describe(s)}");
            sb.AppendLine($"    {AnalysisServices.Clip(s.Signature, 200)}");
        }
        return sb.ToString();
    }
}

public sealed class FindReferencesTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "find_references";

    public override string Description =>
        "Finds where a symbol name is used, grouped by file with the enclosing member and the source line. Name-based: for 'Type.Member', files that also mention the type are listed first.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "symbol": { "type": "string", "minLength": 1, "maxLength": 300 },
            "project": { "type": "string", "maxLength": 200 },
            "limit": { "type": "integer", "minimum": 1, "maximum": 300 }
          },
          "required": ["symbol"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        var query = CodeIndex.StripGeneric(args.RequireString("symbol").Trim());
        var name = query.Contains('.') ? query[(query.LastIndexOf('.') + 1)..] : query;
        var typeName = query.Contains('.') ? query[..query.LastIndexOf('.')].Split('.')[^1] : null;
        var project = args.GetString("project");
        var limit = Clamp(args.GetInt("limit"), 60, 1, 300);

        var hits = new List<(string File, int Line, bool Likely)>();
        foreach (var (path, file) in index.Files)
        {
            if (!file.Identifiers.TryGetValue(name, out var lines) || project is not null && !file.Project.Equals(project, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }
            var likely = typeName is null || file.Identifiers.ContainsKey(typeName) || file.Symbols.Any(s => s.Name == typeName);
            hits.AddRange(lines.Select(l => (path, l, likely)));
        }
        // Declarations are not references.
        var declarations = index.Resolve(query).Select(s => (s.File, s.StartLine)).ToHashSet();
        hits.RemoveAll(h => declarations.Contains((h.File, h.Line)));
        if (hits.Count == 0)
        {
            return $"No references to '{query}' found.";
        }
        var ordered = hits.OrderByDescending(h => h.Likely).ThenBy(h => h.File, StringComparer.OrdinalIgnoreCase).ThenBy(h => h.Line).ToList();
        var fileCount = ordered.Select(h => h.File).Distinct().Count();
        var sb = new StringBuilder($"{hits.Count} references to '{name}' in {fileCount} files (name-based{(typeName is null ? "" : $"; files mentioning {typeName} first")}):\n");
        var shown = 0;
        var inspected = new List<string>();
        foreach (var group in ordered.GroupBy(h => h.File))
        {
            if (shown >= limit)
            {
                break;
            }
            var full = Path.Combine(index.Root, group.Key);
            var lines = group.Take(Math.Max(1, limit - shown)).ToList();
            var wanted = lines.Select(l => l.Line).ToHashSet();
            var text = ReadLines(full, wanted);
            sb.AppendLine($"{group.Key}{(group.First().Likely ? "" : " (same name, possibly unrelated)")}:");
            foreach (var (_, line, _) in lines)
            {
                var owner = index.EnclosingSymbol(group.Key, line);
                sb.AppendLine($"  {line,5}: {AnalysisServices.Clip(text.GetValueOrDefault(line)?.Trim(), 160)}{(owner is null ? "" : $"   ← {owner.FullName}")}");
                shown++;
            }
            inspected.Add(group.Key);
        }
        if (shown < hits.Count)
        {
            sb.AppendLine($"… {hits.Count - shown} more (raise limit or filter by project).");
        }
        await Services.TrackInspectedAsync(context, repo.Name, inspected, ct);
        return sb.ToString();
    }

    internal static Dictionary<int, string> ReadLines(string fullPath, HashSet<int> wanted)
    {
        var result = new Dictionary<int, string>();
        if (!File.Exists(fullPath) || wanted.Count == 0)
        {
            return result;
        }
        var max = wanted.Max();
        var n = 0;
        foreach (var line in File.ReadLines(fullPath))
        {
            n++;
            if (wanted.Contains(n))
            {
                result[n] = line;
            }
            if (n >= max)
            {
                break;
            }
        }
        return result;
    }
}

public sealed class FindImplementationsTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "find_implementations";

    public override string Description => "Finds types implementing/deriving from a type (transitively), members overriding/implementing a member, and DI registrations that map a service to implementations.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "symbol": { "type": "string", "minLength": 1, "maxLength": 300, "description": "Type (IOrderService) or member (IOrderService.PlaceAsync)." }
          },
          "required": ["symbol"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (_, index) = await Services.IndexAsync(args, context, ct);
        var query = args.RequireString("symbol").Trim();
        var types = index.Resolve(query, "type");
        string? memberName = null;
        if (types.Count == 0 && query.Contains('.'))
        {
            memberName = query[(query.LastIndexOf('.') + 1)..];
            types = index.Resolve(query[..query.LastIndexOf('.')], "type");
        }
        var typeName = types.FirstOrDefault()?.Name ?? CodeIndex.StripGeneric(memberName is null ? query : query[..query.LastIndexOf('.')]).Split('.')[^1];
        var derived = index.AllDerived(typeName);
        var sb = new StringBuilder();
        sb.AppendLine($"{derived.Count} types derive from / implement {typeName}:");
        foreach (var (type, depth) in derived.Take(100))
        {
            sb.AppendLine($"- {new string(' ', (depth - 1) * 2)}{type.Kind} {type.FullName} — {type.File}:{type.StartLine}{(type.IsTest ? " (test)" : "")}");
            if (memberName is not null)
            {
                foreach (var member in index.MembersOf(type.FullName).Where(m => m.Name == memberName))
                {
                    sb.AppendLine($"    {member.Kind} {member.FullName} — {member.File}:{member.StartLine}-{member.EndLine}");
                }
            }
        }
        var registrations = index.Registrations.Where(r => r.ServiceType == typeName || r.ImplementationType == typeName).ToList();
        if (registrations.Count > 0)
        {
            sb.AppendLine("DI registrations:");
            foreach (var r in registrations.Take(30))
            {
                sb.AppendLine($"- {r.Lifetime} {r.ServiceType} → {r.ImplementationType}{(r.Factory ? " (factory)" : "")} — {r.File}:{r.Line}");
            }
            var services = registrations.GroupBy(r => r.ServiceType).Where(g => g.Count() > 1).ToList();
            foreach (var group in services)
            {
                sb.AppendLine($"  Note: {group.Key} is registered {group.Count()} times; a single-service resolve gets the LAST registration.");
            }
        }
        return sb.ToString();
    }
}

public sealed class FindCallersTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "find_callers";

    public override string Description =>
        "Finds members that call a method/constructor/property (name-based call graph), optionally as a tree up to depth 3. Callers in files that mention the declaring type are marked 'likely'.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "symbol": { "type": "string", "minLength": 1, "maxLength": 300, "description": "Member name or Type.Member." },
            "depth": { "type": "integer", "minimum": 1, "maximum": 3 },
            "limit": { "type": "integer", "minimum": 1, "maximum": 200 }
          },
          "required": ["symbol"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (_, index) = await Services.IndexAsync(args, context, ct);
        var query = CodeIndex.StripGeneric(args.RequireString("symbol").Trim());
        var depth = Clamp(args.GetInt("depth"), 1, 1, 3);
        var limit = Clamp(args.GetInt("limit"), 50, 1, 200);
        var targets = index.Resolve(query);
        var name = query.Contains('.') ? query[(query.LastIndexOf('.') + 1)..] : query;
        var typeName = targets.FirstOrDefault(t => !SymbolKinds.IsType(t.Kind))?.Container?.Split('.')[^1]
                       ?? (query.Contains('.') ? query[..query.LastIndexOf('.')].Split('.')[^1] : null);
        if (targets.Any(t => SymbolKinds.IsType(t.Kind)))
        {
            typeName = name; // Constructor calls: new Type(...).
        }

        var sb = new StringBuilder();
        var seen = new HashSet<SymbolRecord>(ReferenceEqualityComparer.Instance);
        var count = 0;
        void Walk(string callee, string? calleeType, int level)
        {
            var callers = index.CallersByName(callee)
                .Select(c => (Caller: c, Likely: calleeType is null || c.Container?.EndsWith(calleeType, StringComparison.Ordinal) == true
                                                  || index.Files.TryGetValue(c.File, out var f) && f.Identifiers.ContainsKey(calleeType)))
                .OrderByDescending(c => c.Likely).ThenBy(c => c.Caller.IsTest).ThenBy(c => c.Caller.FullName, StringComparer.Ordinal).ToList();
            foreach (var (caller, likely) in callers)
            {
                if (count >= limit || !seen.Add(caller))
                {
                    continue;
                }
                count++;
                sb.AppendLine($"{new string(' ', level * 2)}- {caller.FullName} — {caller.File}:{caller.StartLine}{(likely ? "" : " (possible: same name)")}{(caller.IsTest ? " (test)" : "")}");
                if (level + 1 < depth && caller.Kind != SymbolKinds.TopLevel)
                {
                    Walk(caller.Name, caller.Container?.Split('.')[^1], level + 1);
                }
            }
        }
        Walk(name, typeName, 0);
        if (typeName is not null && targets.Any(t => SymbolKinds.IsType(t.Kind)))
        {
            foreach (var r in index.Registrations.Where(r => r.ImplementationType == name).Take(10))
            {
                sb.AppendLine($"- constructed by DI: {r.Lifetime} {r.ServiceType} → {r.ImplementationType} — {r.File}:{r.Line}");
            }
        }
        return count == 0 && sb.Length == 0 ? $"No callers of '{query}' found in the index." : $"Callers of '{query}' ({count}{(count >= limit ? "+, limited" : "")}):\n" + sb;
    }
}

public sealed class FindTestsTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "find_tests";

    public override string Description =>
        "Finds tests for a symbol with progressive widening: 1 = tests that call/use the symbol, 2 = tests of its type, 3 = tests in projects referencing its project, 4 = all tests. " +
        "Returns a dotnet test --filter expression for the chosen level.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "symbol": { "type": "string", "minLength": 1, "maxLength": 300 },
            "level": { "type": "integer", "minimum": 1, "maximum": 4, "description": "Omit to start narrow and widen until tests are found." },
            "limit": { "type": "integer", "minimum": 1, "maximum": 200 }
          },
          "required": ["symbol"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (_, index) = await Services.IndexAsync(args, context, ct);
        var query = args.RequireString("symbol").Trim();
        var limit = Clamp(args.GetInt("limit"), 40, 1, 200);
        var requested = args.GetInt("level");
        var targets = index.Resolve(query);
        var target = targets.FirstOrDefault(t => !t.IsTest) ?? targets.FirstOrDefault();
        var name = CodeIndex.StripGeneric(query.Contains('.') ? query[(query.LastIndexOf('.') + 1)..] : query);
        var typeName = target is null ? null : SymbolKinds.IsType(target.Kind) ? target.Name : target.Container?.Split('.')[^1];
        var allTests = index.TestMethods.ToList();

        List<SymbolRecord> Level(int level) => level switch
        {
            1 => allTests.Where(t => t.Calls.Contains(name) || t.Uses.Contains(name)).ToList(),
            2 when typeName is not null => allTests.Where(t => t.Uses.Contains(typeName) || t.Calls.Contains(typeName)
                                                            || t.Container?.Split('.')[^1] is { } c && (c == typeName + "Tests" || c == typeName + "Test")).ToList(),
            3 when target is not null => allTests.Where(t => index.Projects.TryGetValue(t.Project, out var p)
                                                             && index.ProjectReferencesOf(p.Name).Contains(target.Project, StringComparer.OrdinalIgnoreCase)).ToList(),
            4 => allTests,
            _ => [],
        };

        var level = requested ?? 1;
        var tests = Level(level);
        while (requested is null && tests.Count == 0 && level < 4)
        {
            tests = Level(++level);
        }
        if (tests.Count == 0)
        {
            return $"No tests found for '{query}' up to level {level}.";
        }
        var sb = new StringBuilder($"Level {level} ({LevelName(level)}): {tests.Count} tests for '{query}':\n");
        foreach (var t in tests.Take(limit))
        {
            sb.AppendLine($"- {t.FullName} — {t.File}:{t.StartLine} [{t.Project}]");
        }
        if (tests.Count > limit)
        {
            sb.AppendLine($"… {tests.Count - limit} more.");
        }
        var filter = level switch
        {
            4 => null,
            3 => null,
            _ => tests.Count <= 20
                ? string.Join("|", tests.Select(t => "FullyQualifiedName=" + t.FullName))
                : string.Join("|", tests.Select(t => t.Container).Distinct().Take(20).Select(c => "FullyQualifiedName~" + c)),
        };
        var projects = tests.Select(t => index.Projects.GetValueOrDefault(t.Project)?.Path).Where(p => p is not null).Distinct().ToList();
        sb.AppendLine(filter is null
            ? $"Run: run_tests with target={projects.FirstOrDefault() ?? "(solution)"}{(projects.Count > 1 ? $" (and {projects.Count - 1} other test projects)" : "")}"
            : $"Run: run_tests target={projects.FirstOrDefault()} filter=\"{AnalysisServices.Clip(filter, 480)}\"");
        if (level < 4)
        {
            sb.AppendLine($"Widen with level={level + 1} if these pass but the problem persists.");
        }
        return sb.ToString();
    }

    private static string LevelName(int level) => level switch
    {
        1 => "tests that reference the symbol",
        2 => "tests of the declaring type",
        3 => "tests in projects that reference the symbol's project",
        _ => "all tests",
    };
}

public sealed class ReadSymbolTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "read_symbol";

    public override string Description =>
        "Reads one symbol. Types default to an outline (members with signatures and line ranges); members default to their source with line numbers. Use 'index' to pick among same-named symbols.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "symbol": { "type": "string", "minLength": 1, "maxLength": 300 },
            "mode": { "type": "string", "enum": ["outline", "source"] },
            "index": { "type": "integer", "minimum": 1, "maximum": 50 },
            "maxLines": { "type": "integer", "minimum": 10, "maximum": 600 }
          },
          "required": ["symbol"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        var query = args.RequireString("symbol");
        var matches = index.Resolve(query);
        if (matches.Count == 0)
        {
            var suggestions = index.Search(query, null, null, true, 5);
            return $"Symbol '{query}' not found." + (suggestions.Count > 0 ? " Similar: " + string.Join(", ", suggestions.Select(s => s.Symbol.FullName)) : "");
        }
        var pick = Clamp(args.GetInt("index"), 1, 1, matches.Count) - 1;
        var symbol = matches[pick];
        var sb = new StringBuilder();
        if (matches.Count > 1)
        {
            sb.AppendLine($"{matches.Count} symbols match; showing #{pick + 1}. Others: " + string.Join("; ", matches.Select((m, i) => $"#{i + 1} {m.Kind} {m.FullName} ({m.File}:{m.StartLine})").Where((_, i) => i != pick).Take(8)));
        }
        sb.AppendLine(AnalysisServices.Describe(symbol));
        if (symbol.Attributes.Count > 0)
        {
            sb.AppendLine("Attributes: " + string.Join(", ", symbol.Attributes));
        }
        if (symbol.Bases.Count > 0)
        {
            sb.AppendLine("Bases: " + string.Join(", ", symbol.Bases));
        }
        var mode = args.GetString("mode") ?? (SymbolKinds.IsType(symbol.Kind) && symbol.EndLine - symbol.StartLine > 60 ? "outline" : "source");
        var full = repo.Resolve(symbol.File);
        if (mode == "outline" && SymbolKinds.IsType(symbol.Kind))
        {
            var members = index.MembersOf(symbol.FullName);
            sb.AppendLine($"Outline ({members.Count} members):");
            foreach (var m in members.Take(150))
            {
                sb.AppendLine($"  {m.StartLine,5}-{m.EndLine,-5} {m.Kind,-11} {AnalysisServices.Clip(m.Signature, 180)}");
            }
            sb.AppendLine("Read a member with read_symbol symbol=Type.Member, or a range with read_source_range.");
        }
        else
        {
            var maxLines = Clamp(args.GetInt("maxLines"), 200, 10, 600);
            var text = AnalysisServices.ReadNumberedLines(full, symbol.StartLine, symbol.EndLine, maxLines, out _);
            sb.Append(text);
            var length = symbol.EndLine - symbol.StartLine + 1;
            if (length > maxLines)
            {
                sb.AppendLine($"… {length - maxLines} more lines; continue with read_source_range path={symbol.File} startLine={symbol.StartLine + maxLines}.");
            }
        }
        await Services.TrackInspectedAsync(context, repo.Name, [symbol.File], ct);
        return sb.ToString();
    }
}

public sealed class ReadSourceRangeTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "read_source_range";

    public override string Description => "Reads a line range (max 400 lines) of a repository file with line numbers. Prefer read_symbol when you know the symbol.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "path": { "type": "string", "minLength": 1, "maxLength": 400 },
            "startLine": { "type": "integer", "minimum": 1 },
            "endLine": { "type": "integer", "minimum": 1 }
          },
          "required": ["path", "startLine"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var repo = await Services.RepositoryAsync(args, context, ct);
        var full = repo.Resolve(args.RequireString("path"));
        if (!File.Exists(full))
        {
            throw new NotFoundException("File");
        }
        if (new FileInfo(full).Length > 64L * 1024 * 1024)
        {
            throw new ValidationException("The file is too large to read by line range; use log_search or json tools.");
        }
        var start = args.GetInt("startLine") ?? 1;
        var end = Math.Max(start, args.GetInt("endLine") ?? start + 99);
        end = Math.Min(end, start + 399);
        var text = AnalysisServices.ReadNumberedLines(full, start, end, 400, out var total);
        await Services.TrackInspectedAsync(context, repo.Name, [repo.Relative(full)], ct);
        if (start > total)
        {
            // Say it plainly: an empty "lines 300-58" reads like a tool fault and invites a hunt for one.
            return $"{repo.Relative(full)} has {total} lines; line {start} is past the end of the file.";
        }
        return $"{repo.Relative(full)} lines {start}-{Math.Min(end, total)} of {total}:\n{text}" + (end < total ? $"… {total - end} more lines." : "");
    }
}

public sealed class SearchCodeTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "search_code";

    public override string Description =>
        "Searches repository files for text or a regular expression (default: *.cs files). Returns file:line matches with the line; counts all matches. Use a glob like '*.json' or 'src/Orders/**' to narrow.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "query": { "type": "string", "minLength": 1, "maxLength": 300 },
            "regex": { "type": "boolean" },
            "caseSensitive": { "type": "boolean" },
            "glob": { "type": "string", "maxLength": 200 },
            "project": { "type": "string", "maxLength": 200 },
            "limit": { "type": "integer", "minimum": 1, "maximum": 300 }
          },
          "required": ["query"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        var query = args.RequireString("query");
        var caseSensitive = args.GetBool("caseSensitive") ?? false;
        System.Text.RegularExpressions.Regex? regex = null;
        if (args.GetBool("regex") == true)
        {
            try
            {
                regex = new System.Text.RegularExpressions.Regex(query,
                    (caseSensitive ? System.Text.RegularExpressions.RegexOptions.None : System.Text.RegularExpressions.RegexOptions.IgnoreCase) | System.Text.RegularExpressions.RegexOptions.CultureInvariant,
                    TimeSpan.FromMilliseconds(100));
            }
            catch (ArgumentException ex)
            {
                throw new ValidationException("Invalid regular expression: " + ex.Message);
            }
        }
        var glob = args.GetString("glob") ?? "*.cs";
        var project = args.GetString("project");
        var limit = Clamp(args.GetInt("limit"), 50, 1, Services.Options.MaxSearchResults);
        var files = index.Files.Values
            .Where(f => Glob.IsMatch(f.Path, glob) && (project is null || f.Project.Equals(project, StringComparison.OrdinalIgnoreCase)) && f.Size < 8 * 1024 * 1024)
            .Select(f => f.Path).OrderBy(p => p, StringComparer.OrdinalIgnoreCase).ToList();

        var perFile = new (string Path, List<(int Line, string Text)> Hits)[files.Count];
        long total = 0;
        await Parallel.ForEachAsync(Enumerable.Range(0, files.Count), new ParallelOptions { MaxDegreeOfParallelism = Math.Max(1, Services.Options.MaxParallelism), CancellationToken = ct }, (i, token) =>
        {
            var hits = new List<(int, string)>();
            var n = 0;
            try
            {
                foreach (var line in File.ReadLines(Path.Combine(index.Root, files[i])))
                {
                    n++;
                    bool match;
                    try
                    {
                        match = regex?.IsMatch(line) ?? line.Contains(query, caseSensitive ? StringComparison.Ordinal : StringComparison.OrdinalIgnoreCase);
                    }
                    catch (System.Text.RegularExpressions.RegexMatchTimeoutException)
                    {
                        match = false;
                    }
                    if (match)
                    {
                        Interlocked.Increment(ref total);
                        if (hits.Count < limit)
                        {
                            hits.Add((n, line.Length > 300 ? line[..300] + "…" : line));
                        }
                    }
                }
            }
            catch (IOException)
            {
            }
            perFile[i] = (files[i], hits);
            return ValueTask.CompletedTask;
        });

        var sb = new StringBuilder($"{total} matches in {perFile.Count(p => p.Hits?.Count > 0)} of {files.Count} files ({glob}):\n");
        var shown = 0;
        foreach (var (path, hits) in perFile.Where(p => p.Hits?.Count > 0))
        {
            foreach (var (line, text) in hits)
            {
                if (shown++ >= limit)
                {
                    break;
                }
                sb.AppendLine($"{path}:{line}: {text.Trim()}");
            }
            if (shown >= limit)
            {
                break;
            }
        }
        if (total > limit)
        {
            sb.AppendLine($"… {total - limit} more matches; refine the query, glob or project.");
        }
        await Services.TrackInspectedAsync(context, repo.Name, perFile.Where(p => p.Hits?.Count > 0).Take(20).Select(p => p.Path), ct);
        return sb.ToString();
    }
}

/// <summary>Minimal glob matching for repository-relative paths: '*' (within a segment), '**' (any depth), '?'.</summary>
public static class Glob
{
    public static bool IsMatch(string path, string pattern)
    {
        if (string.IsNullOrWhiteSpace(pattern) || pattern == "*" || pattern == "**")
        {
            return true;
        }
        pattern = pattern.Replace('\\', '/');
        // A pattern without a slash matches the file name anywhere ("*.cs").
        var target = pattern.Contains('/') ? path : Path.GetFileName(path);
        var regex = "^" + System.Text.RegularExpressions.Regex.Escape(pattern)
            .Replace(@"\*\*/", "(.*/)?").Replace(@"\*\*", ".*").Replace(@"\*", "[^/]*").Replace(@"\?", "[^/]") + "$";
        return System.Text.RegularExpressions.Regex.IsMatch(target, regex, System.Text.RegularExpressions.RegexOptions.IgnoreCase, TimeSpan.FromMilliseconds(50));
    }
}
