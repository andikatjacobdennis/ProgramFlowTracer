using System.Text;
using System.Text.Json;
using DocGen.Analysis.Execution;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

internal static class DevServerFormat
{
    public static DevServerService Service(AnalysisServices services)
        => services.Service<DevServerService>() ?? throw new DocGenException("SERVERS_UNAVAILABLE", "Development servers are not available in this host.", 503);

    public static string Describe(DevServerRecord s)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"Server {s.Name} — {s.Status}");
        sb.AppendLine($"serverId: {s.ServerId}");
        sb.AppendLine("URL: " + (s.Url is null ? "not determined (the process did not print a listening URL and no configured URL answered)" : $"{s.Url} (from {s.UrlSource})"));
        if (s.Url is null && s.ConfiguredUrls.Count > 0)
        {
            sb.AppendLine("Configured (unconfirmed): " + string.Join(", ", s.ConfiguredUrls));
        }
        if (s.LastHealth is { } health)
        {
            sb.AppendLine($"Health: {health} at {s.LastHealthAt:HH:mm:ss} UTC");
        }
        sb.AppendLine($"Command {s.CommandId} · pid {s.ProcessId?.ToString() ?? "-"} · {s.Repository}:{s.WorkingDirectory} · started {s.StartedAt:yyyy-MM-dd HH:mm:ss} UTC" +
                      (s.StoppedAt is { } stopped ? $" · stopped {stopped:HH:mm:ss} UTC" : "") + (s.ExitCode is { } exit ? $" · exit code {exit}" : ""));
        sb.AppendLine("> " + s.CommandLine);
        foreach (var note in s.Notes.TakeLast(3))
        {
            sb.AppendLine("Note: " + note);
        }
        if (s.Url is null && s.Status is DevServerStatus.Running or DevServerStatus.Starting)
        {
            sb.AppendLine($"Desktop app (WPF/WinForms…)? It has no URL: check what its window shows with window_capture serverId={s.ServerId}.");
        }
        sb.Append($"Output: command_status commandId={s.CommandId}");
        return sb.ToString();
    }

    public static ActivityRecord Activity(string type, string title, DevServerRecord s)
    {
        var a = new ActivityRecord { Type = type, Title = title, Detail = s.Url ?? "URL not determined" };
        a.Data["serverId"] = s.ServerId;
        a.Data["status"] = s.Status;
        a.Data["commandId"] = s.CommandId;
        if (s.Url is { } url)
        {
            a.Data["url"] = url;
        }
        return a;
    }
}

public sealed class DevServerStartTool(AnalysisServices services) : AnalysisTool(services), IDynamicRiskTool
{
    public override string Name => "dev_server_start";

    public override string Description =>
        "Starts a development server (dotnet run for a project, or an allow-listed executable) as a tracked process and waits until it prints its listening " +
        "URL (confirmed with a loopback health check). Returns a stable serverId. DocGen never guesses a port: if the URL cannot be determined it says so. " +
        "Pass application arguments (e.g. --urls http://127.0.0.1:5099) via applicationArguments.";

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.External;

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "project": { "type": "string", "maxLength": 400, "description": "Project file for dotnet run, e.g. src/Web/Web.csproj." },
            "executable": { "type": "string", "maxLength": 64 },
            "arguments": { "type": "array", "items": { "type": "string", "maxLength": 2000 }, "maxItems": 50 },
            "workingDirectory": { "type": "string", "maxLength": 400 },
            "launchProfile": { "type": "string", "maxLength": 64, "description": "launchSettings.json profile to use, or \"none\" for --no-launch-profile. When 'environment' sets a variable the default profile also sets (e.g. ASPNETCORE_ENVIRONMENT), DocGen starts without the profile so your value wins, and says so." },
            "noBuild": { "type": "boolean" },
            "applicationArguments": { "type": "array", "items": { "type": "string", "maxLength": 2000 }, "maxItems": 50 },
            "environment": { "type": "object", "additionalProperties": { "type": "string", "maxLength": 4000 }, "maxProperties": 30 },
            "name": { "type": "string", "maxLength": 80 },
            "waitSeconds": { "type": "integer", "minimum": 1, "maximum": 300 }
          },
          "additionalProperties": false
        }
        """;

    public async Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken ct)
        => new(ToolRiskLevel.External, Capabilities.ManageDevelopmentServer, ["starts an application process that keeps running"],
            Routine: AnalysisServices.IsChatFolder(await Services.RepositoryAsync(ToolArguments.Parse(call), context, ct), context));

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        static List<string> List(ToolArguments a, string name) => a.GetElement(name) is { ValueKind: JsonValueKind.Array } arr ? arr.EnumerateArray().Select(e => e.GetString() ?? "").ToList() : [];
        var env = args.GetElement("environment") is { ValueKind: JsonValueKind.Object } e ? e.EnumerateObject().ToDictionary(p => p.Name, p => p.Value.GetString() ?? "") : null;
        DocGen.Analysis.Execution.EnvironmentPolicy.RejectLoaderVariables(env);
        var request = new DevServerStartRequest
        {
            Repository = await Services.RepositoryNameAsync(args, context, ct) ?? "workspace", Project = args.GetString("project"), Executable = args.GetString("executable"),
            Arguments = List(args, "arguments"), WorkingDirectory = args.GetString("workingDirectory"), LaunchProfile = args.GetString("launchProfile"),
            NoBuild = args.GetBool("noBuild") ?? false, ApplicationArguments = List(args, "applicationArguments"), Environment = env, Name = args.GetString("name"),
        };
        var maxWait = Math.Max(5, Services.AgentOptions.ToolTimeoutSeconds - 5);
        var server = await DevServerFormat.Service(Services).StartAsync(context.UserId, request, context.RunId, context.ConversationId, context.ProjectId,
            TimeSpan.FromSeconds(Math.Clamp(args.GetInt("waitSeconds") ?? maxWait, 1, maxWait)), ct);
        var ok = server.Status is DevServerStatus.Running or DevServerStatus.Starting;
        return new ToolResult
        {
            ToolCallId = call.Id, ToolName = call.Name, Success = ok,
            Content = (ok ? "Started preview\n" : "The server did not start\n") + DevServerFormat.Describe(server),
            Error = ok ? null : "server " + server.Status,
            Activities = [DevServerFormat.Activity("server_started", ok ? $"Started preview {server.Name}" : $"Preview {server.Name} failed to start", server)],
        };
    }

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct) => throw new NotSupportedException();
}

public sealed class DevServerStatusTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "dev_server_status";

    public override string Description => "Status of a development server DocGen started (process alive, listening URL, loopback health check), or all of your servers when serverId is omitted.";

    public override string InputSchema => """
        { "type": "object", "properties": { "serverId": { "type": "string", "maxLength": 64 } }, "additionalProperties": false }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var service = DevServerFormat.Service(Services);
        if (args.GetString("serverId") is { Length: > 0 } id)
        {
            return DevServerFormat.Describe(await service.StatusAsync(context.UserId, id, ct));
        }
        var all = await service.ListAsync(context.UserId, ct);
        if (all.Count == 0)
        {
            return "No development servers.";
        }
        var sb = new StringBuilder();
        foreach (var s in all.Take(20))
        {
            var current = s.Status is DevServerStatus.Starting or DevServerStatus.Running ? await service.StatusAsync(context.UserId, s.ServerId, ct) : s;
            sb.AppendLine($"- {current.ServerId} {current.Name}: {current.Status}{(current.Url is null ? "" : " · " + current.Url)} · started {current.StartedAt:yyyy-MM-dd HH:mm} UTC");
        }
        return sb.ToString();
    }
}

public sealed class DevServerStopTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "dev_server_stop";

    public override string Description => "Stops a development server DocGen started (by serverId): its process tree is killed and the registry updated.";

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    public override string InputSchema => """
        { "type": "object", "properties": { "serverId": { "type": "string", "minLength": 1, "maxLength": 64 } }, "required": ["serverId"], "additionalProperties": false }
        """;

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var server = await DevServerFormat.Service(Services).StopAsync(context.UserId, args.RequireString("serverId"), ct);
        return new ToolResult
        {
            ToolCallId = call.Id, ToolName = call.Name, Success = true,
            Content = $"Stopped preview\nserverId: {server.ServerId}\nServer stopped successfully.",
            Activities = [DevServerFormat.Activity("server_stopped", $"Stopped preview {server.Name}", server)],
        };
    }

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct) => throw new NotSupportedException();
}

public sealed class DevServerRestartTool(AnalysisServices services) : AnalysisTool(services), IDynamicRiskTool
{
    public override string Name => "dev_server_restart";

    public override string Description => "Restarts a development server with exactly the same launch (stop, then start). Returns the new serverId and URL.";

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.External;

    public override string InputSchema => """
        {
          "type": "object",
          "properties": { "serverId": { "type": "string", "minLength": 1, "maxLength": 64 }, "waitSeconds": { "type": "integer", "minimum": 1, "maximum": 300 } },
          "required": ["serverId"],
          "additionalProperties": false
        }
        """;

    public Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken ct)
        => Task.FromResult(new ToolRiskAssessment(ToolRiskLevel.External, Capabilities.ManageDevelopmentServer, ["restarts an application process"]));

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var maxWait = Math.Max(5, Services.AgentOptions.ToolTimeoutSeconds - 5);
        var server = await DevServerFormat.Service(Services).RestartAsync(context.UserId, args.RequireString("serverId"), context.RunId,
            TimeSpan.FromSeconds(Math.Clamp(args.GetInt("waitSeconds") ?? maxWait, 1, maxWait)), ct);
        return new ToolResult
        {
            ToolCallId = call.Id, ToolName = call.Name, Success = server.Status is DevServerStatus.Running or DevServerStatus.Starting,
            Content = "Restarted preview\n" + DevServerFormat.Describe(server),
            Activities = [DevServerFormat.Activity("server_restarted", $"Restarted preview {server.Name}", server)],
        };
    }

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct) => throw new NotSupportedException();
}
