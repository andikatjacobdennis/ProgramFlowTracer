using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using DocGen.Analysis.Indexing;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

public sealed class DependencyPathTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "dependency_path";

    public override string Description =>
        "Finds the shortest dependency chain between two symbols (calls, type uses, inheritance, declarations, DI service→implementation) or two projects (project references). " +
        "Answers 'how does A reach B?' without reading intermediate files. Name-based resolution.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "from": { "type": "string", "minLength": 1, "maxLength": 300 },
            "to": { "type": "string", "minLength": 1, "maxLength": 300 },
            "maxDepth": { "type": "integer", "minimum": 1, "maximum": 12 }
          },
          "required": ["from", "to"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (_, index) = await Services.IndexAsync(args, context, ct);
        var from = args.RequireString("from");
        var to = args.RequireString("to");
        var maxDepth = Clamp(args.GetInt("maxDepth"), 8, 1, 12);

        if (index.Projects.ContainsKey(from) && index.Projects.ContainsKey(to))
        {
            var path = ProjectPath(index, from, to);
            return path is null ? $"Project {from} does not (transitively) reference {to}." : "Project path: " + string.Join(" → ", path);
        }

        var sources = index.Resolve(from).Take(20).ToList();
        var targets = index.Resolve(to).ToHashSet(ReferenceEqualityComparer.Instance);
        if (sources.Count == 0 || targets.Count == 0)
        {
            return $"Could not resolve {(sources.Count == 0 ? $"'{from}'" : $"'{to}'")} to a symbol. Use find_symbol first.";
        }
        var result = ShortestPath(index, sources, s => targets.Contains(s), maxDepth, ct);
        if (result is null)
        {
            return $"No dependency path from '{from}' to '{to}' within {maxDepth} steps (name-based graph; dynamic dispatch through reflection or configuration is not visible).";
        }
        var sb = new StringBuilder($"Shortest path ({result.Count - 1} steps, name-based):\n");
        for (var i = 0; i < result.Count; i++)
        {
            var (symbol, edge) = result[i];
            sb.AppendLine($"{(i == 0 ? "  " : $"  --{edge}--> ")}{symbol.Kind} {symbol.FullName} ({symbol.File}:{symbol.StartLine})");
        }
        return sb.ToString();
    }

    internal static List<(SymbolRecord Symbol, string Edge)>? ShortestPath(CodeIndex index, List<SymbolRecord> sources, Func<SymbolRecord, bool> isTarget, int maxDepth, CancellationToken ct)
    {
        var previous = new Dictionary<SymbolRecord, (SymbolRecord? From, string Edge)>(ReferenceEqualityComparer.Instance);
        var queue = new Queue<(SymbolRecord Node, int Depth)>();
        foreach (var s in sources)
        {
            previous[s] = (null, "");
            queue.Enqueue((s, 0));
        }
        var visited = 0;
        while (queue.Count > 0)
        {
            var (node, depth) = queue.Dequeue();
            if (isTarget(node))
            {
                var path = new List<(SymbolRecord, string)>();
                for (SymbolRecord? cursor = node; cursor is not null; cursor = previous[cursor].From)
                {
                    path.Add((cursor, previous[cursor].Edge));
                }
                path.Reverse();
                return path;
            }
            if (depth >= maxDepth || ++visited > 200_000)
            {
                continue;
            }
            if ((visited & 1023) == 0)
            {
                ct.ThrowIfCancellationRequested();
            }
            foreach (var (next, edge) in Neighbors(index, node))
            {
                if (!previous.ContainsKey(next))
                {
                    previous[next] = (node, edge);
                    queue.Enqueue((next, depth + 1));
                }
            }
        }
        return null;
    }

    private static IEnumerable<(SymbolRecord, string)> Neighbors(CodeIndex index, SymbolRecord node)
    {
        if (SymbolKinds.IsType(node.Kind))
        {
            foreach (var member in index.MembersOf(node.FullName))
            {
                yield return (member, "declares");
            }
            foreach (var b in node.Bases)
            {
                foreach (var baseType in index.ByName(CodeIndex.StripGeneric(b)).Where(t => SymbolKinds.IsType(t.Kind)).Take(5))
                {
                    yield return (baseType, "inherits");
                }
            }
            foreach (var r in index.Registrations.Where(r => r.ServiceType == node.Name && r.ImplementationType != node.Name).Take(10))
            {
                foreach (var impl in index.ByName(r.ImplementationType).Where(t => SymbolKinds.IsType(t.Kind)).Take(3))
                {
                    yield return (impl, "DI resolves to");
                }
            }
            yield break;
        }
        foreach (var call in node.Calls)
        {
            foreach (var callee in index.ByName(call).Where(c => !c.IsTest).Take(15))
            {
                yield return (callee, SymbolKinds.IsType(callee.Kind) ? "constructs" : "calls");
            }
        }
        foreach (var use in node.Uses)
        {
            foreach (var used in index.ByName(use).Where(u => SymbolKinds.IsType(u.Kind) || u.Kind is SymbolKinds.Property or SymbolKinds.Field).Take(10))
            {
                yield return (used, "uses");
            }
        }
        if (node.ReturnType is { } returnType)
        {
            foreach (var t in index.ByName(CodeIndex.StripGeneric(CSharp.CSharpParser.SimpleTypeName(returnType))).Where(t => SymbolKinds.IsType(t.Kind)).Take(3))
            {
                yield return (t, "has type");
            }
        }
    }

    private static List<string>? ProjectPath(CodeIndex index, string from, string to)
    {
        var previous = new Dictionary<string, string?>(StringComparer.OrdinalIgnoreCase) { [from] = null };
        var queue = new Queue<string>([from]);
        while (queue.Count > 0)
        {
            var node = queue.Dequeue();
            if (node.Equals(to, StringComparison.OrdinalIgnoreCase))
            {
                var path = new List<string>();
                for (var cursor = node; cursor is not null; cursor = previous[cursor])
                {
                    path.Add(cursor);
                }
                path.Reverse();
                return path;
            }
            foreach (var next in index.ProjectReferencesOf(node))
            {
                if (previous.TryAdd(next, node))
                {
                    queue.Enqueue(next);
                }
            }
        }
        return null;
    }
}

public sealed class BlastRadiusTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "blast_radius";

    public override string Description =>
        "Regression analysis before/after changing a symbol: transitive callers (depth 3), derived types, DI consumers, affected endpoints, projects and tests, with a risk rating.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "symbol": { "type": "string", "minLength": 1, "maxLength": 300 }
          },
          "required": ["symbol"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (_, index) = await Services.IndexAsync(args, context, ct);
        var query = args.RequireString("symbol");
        var targets = index.Resolve(query);
        if (targets.Count == 0)
        {
            return $"Symbol '{query}' not found.";
        }
        var target = targets.FirstOrDefault(t => !t.IsTest) ?? targets[0];
        var isType = SymbolKinds.IsType(target.Kind);
        var typeName = isType ? target.Name : target.Container?.Split('.')[^1];

        // Transitive "likely" callers (the caller's file mentions the callee's type).
        var callers = new Dictionary<SymbolRecord, int>(ReferenceEqualityComparer.Instance);
        var frontier = new List<(string Name, string? Type)> { (target.Name, typeName) };
        for (var depth = 1; depth <= 3 && frontier.Count > 0; depth++)
        {
            var next = new List<(string, string?)>();
            foreach (var (name, type) in frontier)
            {
                foreach (var caller in index.CallersByName(name).Concat(isType && depth == 1 ? index.UsersByName(name) : []))
                {
                    var likely = type is null || caller.Container?.EndsWith(type, StringComparison.Ordinal) == true
                                 || index.Files.TryGetValue(caller.File, out var f) && f.Identifiers.ContainsKey(type);
                    if (!likely || callers.ContainsKey(caller) || ReferenceEquals(caller, target))
                    {
                        continue;
                    }
                    callers[caller] = depth;
                    if (caller.Kind != SymbolKinds.TopLevel && callers.Count < 2000)
                    {
                        next.Add((caller.Name, caller.Container?.Split('.')[^1]));
                    }
                }
            }
            frontier = next;
        }

        var derived = isType ? index.AllDerived(target.Name) : [];
        var registrations = typeName is null ? [] : index.Registrations.Where(r => r.ServiceType == typeName || r.ImplementationType == typeName).ToList();
        var callerNames = callers.Keys.Select(c => c.FullName).Append(target.FullName).ToHashSet(StringComparer.Ordinal);
        var endpoints = index.Endpoints.Where(e => callerNames.Contains(e.Handler)
                                                   || e.Style == "minimal" && callers.Keys.Any(c => c.Kind == SymbolKinds.TopLevel && c.File == e.File)).ToList();
        var tests = callers.Keys.Where(c => c.IsTest).ToList();
        var projects = callers.Keys.Select(c => c.Project).Append(target.Project).Where(p => p.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var dependents = index.ReverseProjectClosure(target.Project);
        var production = callers.Keys.Count(c => !c.IsTest);
        var isPublic = target.Modifiers.Contains("public");

        var score = production + endpoints.Count * 5 + derived.Count * 2 + (isPublic ? 3 : 0) + registrations.Count;
        var risk = score switch { < 5 => "low", < 25 => "medium", _ => "high" };
        var sb = new StringBuilder();
        sb.AppendLine($"Blast radius of {target.Kind} {target.FullName} ({target.File}:{target.StartLine}) — risk: {risk.ToUpperInvariant()} (name-based estimate)");
        sb.AppendLine($"Production callers: {production} (direct {callers.Count(c => c.Value == 1 && !c.Key.IsTest)}), test callers: {tests.Count}, derived types: {derived.Count}, DI registrations: {registrations.Count}, endpoints: {endpoints.Count}");
        sb.AppendLine($"Projects containing callers: {string.Join(", ", projects)}; projects depending on {target.Project}: {(dependents.Count == 0 ? "none" : string.Join(", ", dependents.Take(15)))}");
        foreach (var (caller, depth) in callers.Where(c => !c.Key.IsTest).OrderBy(c => c.Value).ThenBy(c => c.Key.FullName).Take(25))
        {
            sb.AppendLine($"  d{depth} {caller.FullName} — {caller.File}:{caller.StartLine}");
        }
        foreach (var e in endpoints.Take(15))
        {
            sb.AppendLine($"  endpoint {e.Verb} {e.Route} → {e.Handler}");
        }
        foreach (var (type, _) in derived.Take(10))
        {
            sb.AppendLine($"  derived {type.FullName}");
        }
        if (tests.Count > 0)
        {
            sb.AppendLine("Tests exercising it: " + string.Join(", ", tests.Take(15).Select(t => t.FullName)));
        }
        else
        {
            sb.AppendLine("No tests reference it directly — consider find_tests (wider levels) or adding a regression test.");
        }
        return sb.ToString();
    }
}

public sealed class ConfigLookupTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "config_lookup";

    public override string Description =>
        "Traces configuration: where code reads a key/section (GetSection, GetValue, indexers, Configure<T>, Section constants) and where appsettings*.json defines it, " +
        "flagging keys read by code but defined nowhere. Without 'key', lists every key the code reads.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "key": { "type": "string", "maxLength": 300, "description": "Key or section, e.g. 'Payments:Timeout' or 'ConnectionStrings'." }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        var sections = index.ConfigReferences.Where(c => c.Kind == "sectionConstant").ToList();
        string ResolveKey(ConfigReference c)
        {
            if (c.Kind == "optionsBinding" && c.Key.Contains('.') && !c.Key.Contains(':'))
            {
                // GetSection(TOptions.Section) → the constant's value.
                var parts = c.Key.Split('.');
                var constant = sections.FirstOrDefault(s => s.Type == parts[^2] && s.Owner?.EndsWith("." + parts[^1], StringComparison.Ordinal) == true);
                return constant?.Key ?? c.Key;
            }
            return c.Key;
        }
        bool Defined(string key) => key.Length == 0 || index.ConfigValues.Keys.Any(k => k.Equals(key, StringComparison.OrdinalIgnoreCase) || k.StartsWith(key + ":", StringComparison.OrdinalIgnoreCase));

        var key = args.GetString("key")?.Trim();
        var sb = new StringBuilder();
        if (string.IsNullOrEmpty(key))
        {
            var keys = index.ConfigReferences.Where(c => c.Kind != "sectionConstant").Select(ResolveKey).Where(k => k.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(k => k).ToList();
            sb.AppendLine($"{keys.Count} configuration keys/sections read by code:");
            foreach (var k in keys.Take(200))
            {
                sb.AppendLine($"- {k}{(Defined(k) ? "" : "   ⚠ not defined in any appsettings*.json (must come from environment/other providers)")}");
            }
            return sb.ToString();
        }

        var refs = index.ConfigReferences.Where(c =>
        {
            var k = ResolveKey(c);
            return k.Equals(key, StringComparison.OrdinalIgnoreCase) || k.StartsWith(key + ":", StringComparison.OrdinalIgnoreCase) || key.StartsWith(k + ":", StringComparison.OrdinalIgnoreCase) && k.Length > 0;
        }).ToList();
        sb.AppendLine($"Code references for '{key}' ({refs.Count}):");
        foreach (var c in refs.Take(50))
        {
            sb.AppendLine($"- {c.Kind} '{ResolveKey(c)}'{(c.Type is null ? "" : $" ({c.Type})")} — {c.File}:{c.Line}{(c.Owner is null ? "" : $" in {c.Owner}")}");
        }
        var values = index.ConfigValues.Where(kv => kv.Key.Equals(key, StringComparison.OrdinalIgnoreCase) || kv.Key.StartsWith(key + ":", StringComparison.OrdinalIgnoreCase)).Take(60).ToList();
        sb.AppendLine($"Defined in appsettings ({values.Count} keys):");
        var inspected = new List<string>();
        foreach (var (k, locations) in values)
        {
            foreach (var (file, line) in locations)
            {
                var text = FindReferencesTool.ReadLines(Path.Combine(index.Root, file), [line]).GetValueOrDefault(line)?.Trim();
                sb.AppendLine($"- {k} = {AnalysisServices.Clip(text, 160)} — {file}:{line}");
                inspected.Add(file);
            }
        }
        if (values.Count == 0)
        {
            sb.AppendLine($"⚠ '{key}' is not defined in any appsettings*.json. At runtime it must come from environment variables ({key.Replace(":", "__")}), user secrets or another provider — otherwise it is null/default.");
        }
        var envFiles = index.Files.Keys.Where(f => f.EndsWith("appsettings.Development.json", StringComparison.OrdinalIgnoreCase) || f.EndsWith("appsettings.Production.json", StringComparison.OrdinalIgnoreCase)).ToList();
        if (envFiles.Count > 0)
        {
            sb.AppendLine("Environment-specific files (later files override appsettings.json): " + string.Join(", ", envFiles.Take(10)));
        }
        await Services.TrackInspectedAsync(context, repo.Name, inspected, ct);
        return sb.ToString();
    }
}

public sealed class DiRegistrationsTool(AnalysisServices services) : AnalysisTool(services)
{
    private static readonly HashSet<string> FrameworkWrappers = new(StringComparer.Ordinal)
    {
        "ILogger", "IOptions", "IOptionsMonitor", "IOptionsSnapshot", "IEnumerable", "IServiceProvider", "IServiceScopeFactory",
        "IConfiguration", "IHostEnvironment", "IWebHostEnvironment", "IHttpClientFactory", "IHostApplicationLifetime", "TimeProvider", "CancellationToken",
    };

    public override string Name => "di_registrations";

    public override string Description =>
        "Lists dependency-injection registrations (lifetime, service → implementation, location) and checks them: captive dependencies (singletons that take scoped " +
        "services, e.g. a DbContext), duplicate registrations (last one wins) and constructor dependencies with no registration.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "service": { "type": "string", "maxLength": 200 },
            "project": { "type": "string", "maxLength": 200 }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (_, index) = await Services.IndexAsync(args, context, ct);
        var service = args.GetString("service");
        var project = args.GetString("project");
        var all = index.Registrations;
        var listed = all.Where(r => (service is null || r.ServiceType.Contains(service, StringComparison.OrdinalIgnoreCase) || r.ImplementationType.Contains(service, StringComparison.OrdinalIgnoreCase))
                                    && (project is null || r.Project.Equals(project, StringComparison.OrdinalIgnoreCase))).ToList();
        var sb = new StringBuilder($"{listed.Count} registrations{(service is null ? "" : $" matching '{service}'")}:\n");
        foreach (var r in listed.Take(80))
        {
            sb.AppendLine($"- {r.Lifetime,-9} {r.ServiceType} → {r.ImplementationType}{(r.Factory ? " (factory)" : "")}{(r.Hosted ? " (hosted service)" : "")} — {r.File}:{r.Line}");
        }

        var issues = Analyze(index, all).Where(i => service is null || i.Contains(service, StringComparison.OrdinalIgnoreCase)).ToList();
        sb.AppendLine(issues.Count == 0 ? "Checks: no captive dependencies, duplicates or missing registrations detected (static, name-based analysis)." : $"Findings ({issues.Count}):");
        foreach (var issue in issues.Take(40))
        {
            sb.AppendLine("- " + issue);
        }
        return sb.ToString();
    }

    /// <summary>A static DI finding. <see cref="Registration"/> is the registration at fault (for captive dependencies: the singleton).</summary>
    public sealed record DiFinding(string Kind, string Message, DiRegistration Registration, string? Dependency = null, DiRegistration? DependencyRegistration = null);

    internal static List<string> Analyze(CodeIndex index, List<DiRegistration> registrations)
        => Findings(index, registrations).Select(f => f.Message).Distinct().ToList();

    public static List<DiFinding> Findings(CodeIndex index, List<DiRegistration> registrations)
    {
        var findings = new List<DiFinding>();
        var byService = registrations.GroupBy(r => r.ServiceType).ToDictionary(g => g.Key, g => g.ToList(), StringComparer.Ordinal);
        foreach (var (serviceType, regs) in byService)
        {
            if (regs.Count > 1 && regs.Select(r => r.ImplementationType).Distinct().Count() > 1 && serviceType != "IHostedService")
            {
                findings.Add(new DiFinding("duplicate", $"DUPLICATE: {serviceType} is registered {regs.Count} times ({string.Join(", ", regs.Select(r => $"{r.Lifetime} {r.ImplementationType} @ {r.File}:{r.Line}"))}); GetService/constructor injection receives the last one.", regs[^1]));
            }
            var lifetimes = regs.Select(r => r.Lifetime).Distinct().ToList();
            if (lifetimes.Count > 1)
            {
                findings.Add(new DiFinding("mixedLifetimes", $"MIXED LIFETIMES: {serviceType} is registered as {string.Join(" and ", lifetimes)}.", regs[^1]));
            }
        }

        foreach (var r in registrations.Where(r => r.Lifetime == "Singleton" && !r.ImplementationType.StartsWith('(')))
        {
            foreach (var dependency in ConstructorDependencies(index, r.ImplementationType))
            {
                var name = CodeIndex.StripGeneric(dependency);
                if (FrameworkWrappers.Contains(name))
                {
                    continue;
                }
                if (byService.TryGetValue(name, out var depRegs) && depRegs.Any(d => d.Lifetime == "Scoped"))
                {
                    var scoped = depRegs.First(d => d.Lifetime == "Scoped");
                    findings.Add(new DiFinding("captive",
                        $"CAPTIVE DEPENDENCY: {(r.Hosted ? "hosted service" : "singleton")} {r.ImplementationType} ({r.File}:{r.Line}) takes {name}, which is Scoped ({scoped.File}:{scoped.Line}). " +
                        "The scoped instance is captured for the app's lifetime (shared across requests/threads; disposed objects, stale state). " +
                        "ValidateScopes/ValidateOnBuild would reject this in Development.", r, name, scoped));
                }
                else if (byService.TryGetValue(name, out var transientRegs) && transientRegs.All(d => d.Lifetime == "Transient") && index.ByName(name).Any(t => t.Kind == SymbolKinds.Class && t.Name.Contains("Context", StringComparison.Ordinal)))
                {
                    findings.Add(new DiFinding("lifetime", $"LIFETIME: singleton {r.ImplementationType} takes transient {name}; the transient instance lives as long as the singleton.", r, name, transientRegs[0]));
                }
            }
        }

        var registered = byService.Keys.ToHashSet(StringComparer.Ordinal);
        foreach (var r in registrations.Where(r => !r.ImplementationType.StartsWith('(')).DistinctBy(r => r.ImplementationType).Take(500))
        {
            foreach (var dependency in ConstructorDependencies(index, r.ImplementationType))
            {
                var name = CodeIndex.StripGeneric(dependency);
                if (FrameworkWrappers.Contains(name) || registered.Contains(name) || name.Length < 2 || name[0] != 'I' || !char.IsUpper(name[1]))
                {
                    continue;
                }
                if (index.ByName(name).Any(t => t.Kind == SymbolKinds.Interface))
                {
                    findings.Add(new DiFinding("unregistered", $"UNREGISTERED: {r.ImplementationType} requires {name}, which has no registration in this repository (resolution will fail unless a framework/extension method registers it).", r, name));
                }
            }
        }
        return findings;
    }

    private static IEnumerable<string> ConstructorDependencies(CodeIndex index, string typeName)
    {
        foreach (var type in index.ByName(CodeIndex.StripGeneric(typeName)).Where(t => t.Kind is SymbolKinds.Class or SymbolKinds.Record))
        {
            foreach (var p in type.ParameterTypes)
            {
                yield return p;
            }
            foreach (var ctor in index.MembersOf(type.FullName).Where(m => m.Kind == SymbolKinds.Constructor))
            {
                foreach (var p in ctor.ParameterTypes)
                {
                    yield return p;
                }
            }
        }
    }
}

public sealed partial class PackageInfoTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "package_info";

    public override string Description =>
        "NuGet dependency facts: which projects reference a package (direct/transitive, requested vs resolved version), version conflicts across projects, and metadata " +
        "from the local package cache (description, dependencies per framework, available lib frameworks, cached versions). Offline — no network access.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "package": { "type": "string", "maxLength": 200 }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (_, index) = await Services.IndexAsync(args, context, ct);
        var id = args.GetString("package");
        var sb = new StringBuilder();
        var references = index.Manifest.Projects.SelectMany(p => p.Packages.Select(x => (Project: p, Package: x))).ToList();
        if (string.IsNullOrWhiteSpace(id))
        {
            var direct = references.Where(r => !r.Package.Transitive).GroupBy(r => r.Package.Id, StringComparer.OrdinalIgnoreCase).OrderBy(g => g.Key).ToList();
            sb.AppendLine($"{direct.Count} direct packages ({references.Count(r => r.Package.Transitive)} transitive references):");
            foreach (var g in direct)
            {
                var versions = g.Select(r => r.Package.ResolvedVersion ?? r.Package.Version ?? "?").Distinct().ToList();
                sb.AppendLine($"- {g.Key} {string.Join(" / ", versions)} ({g.Count()} projects){(versions.Count > 1 ? "   ⚠ VERSION CONFLICT across projects" : "")}");
            }
            var transitiveConflicts = references.GroupBy(r => r.Package.Id, StringComparer.OrdinalIgnoreCase)
                .Where(g => g.Select(r => r.Package.ResolvedVersion).Where(v => v is not null).Distinct().Count() > 1 && g.Any(r => r.Package.Transitive)).Take(20).ToList();
            foreach (var g in transitiveConflicts)
            {
                sb.AppendLine($"⚠ {g.Key} resolves to different versions: {string.Join(", ", g.Select(r => $"{r.Project.Name}={r.Package.ResolvedVersion}").Distinct())}");
            }
            if (references.All(r => r.Package.ResolvedVersion is null))
            {
                sb.AppendLine("Resolved/transitive versions are unavailable: no obj/project.assets.json found (run a restore: run_build or a restore command).");
            }
            return sb.ToString();
        }

        if (!PackageId().IsMatch(id))
        {
            throw new ValidationException("Invalid package id.");
        }
        var users = references.Where(r => r.Package.Id.Equals(id, StringComparison.OrdinalIgnoreCase)).ToList();
        sb.AppendLine($"Package {id}: referenced by {users.Count} projects");
        foreach (var (project, package) in users)
        {
            sb.AppendLine($"- {project.Name}: {(package.Transitive ? "transitive" : "direct")}, requested {package.Version ?? "(none)"}, resolved {package.ResolvedVersion ?? "(unknown — not restored)"}");
        }
        var cache = Environment.GetEnvironmentVariable("NUGET_PACKAGES") is { Length: > 0 } custom ? custom : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), ".nuget", "packages");
        var packageDir = Path.Combine(cache, id.ToLowerInvariant());
        if (!Directory.Exists(packageDir))
        {
            sb.AppendLine("Not present in the local NuGet cache.");
            return sb.ToString();
        }
        var cached = Directory.GetDirectories(packageDir).Select(Path.GetFileName).Where(v => v is not null && PackageVersion().IsMatch(v)).OrderBy(v => v).ToList();
        sb.AppendLine("Versions in local cache: " + string.Join(", ", cached));
        var version = users.Select(u => u.Package.ResolvedVersion ?? u.Package.Version).FirstOrDefault(v => v is not null && cached.Contains(v.ToLowerInvariant())) ?? cached.LastOrDefault();
        if (version is null)
        {
            return sb.ToString();
        }
        var versionDir = Path.Combine(packageDir, version.ToLowerInvariant());
        var nuspec = Directory.GetFiles(versionDir, "*.nuspec").FirstOrDefault();
        if (nuspec is not null)
        {
            try
            {
                using var reader = XmlReader.Create(nuspec, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null });
                var doc = XDocument.Load(reader);
                string? Meta(string name) => doc.Descendants().FirstOrDefault(e => e.Name.LocalName == name)?.Value;
                sb.AppendLine($"Metadata ({version}): {AnalysisServices.Clip(Meta("description"), 300)}");
                foreach (var group in doc.Descendants().Where(e => e.Name.LocalName == "group").Take(10))
                {
                    var deps = group.Elements().Where(e => e.Name.LocalName == "dependency").Select(e => $"{e.Attribute("id")?.Value} {e.Attribute("version")?.Value}").ToList();
                    sb.AppendLine($"  dependencies [{group.Attribute("targetFramework")?.Value ?? "any"}]: {(deps.Count == 0 ? "none" : string.Join(", ", deps.Take(15)))}");
                }
            }
            catch (Exception ex) when (ex is XmlException or IOException)
            {
                sb.AppendLine("The .nuspec could not be read.");
            }
        }
        foreach (var folder in new[] { "lib", "ref" })
        {
            var dir = Path.Combine(versionDir, folder);
            if (Directory.Exists(dir))
            {
                var tfms = Directory.GetDirectories(dir).Select(d => $"{Path.GetFileName(d)} ({string.Join(", ", Directory.GetFiles(d, "*.dll").Select(Path.GetFileName).Take(5))})");
                sb.AppendLine($"{folder}/: {string.Join("; ", tfms.Take(10))}");
            }
        }
        return sb.ToString();
    }

    [GeneratedRegex(@"^[A-Za-z0-9_.\-]{1,200}$")]
    private static partial Regex PackageId();

    [GeneratedRegex(@"^[0-9A-Za-z.\-+]{1,100}$")]
    private static partial Regex PackageVersion();
}
