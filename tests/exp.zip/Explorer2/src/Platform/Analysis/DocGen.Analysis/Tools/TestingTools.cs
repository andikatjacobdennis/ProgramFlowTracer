using System.Globalization;
using System.Text;
using DocGen.Analysis.Commands;
using DocGen.Analysis.Git;
using DocGen.Analysis.Indexing;
using DocGen.Analysis.Testing;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

/// <summary>Test selection from changes (files, symbols, callers, implementations, dependents) with progressive runs.</summary>
public sealed class SelectTestsTool(AnalysisServices services) : AnalysisTool(services), IDynamicRiskTool
{
    public override string Name => "select_tests";

    public override string Description =>
        "Selects the tests to run for a change. Uses changed files (default: Git working-tree changes), changed symbols, their callers and implementations, " +
        "existing tests and dependent projects (blast radius) to build five progressive stages: 1 new/changed tests, 2 affected tests, 3 tests of the changed " +
        "projects, 4 tests of dependent projects, 5 full solution. With run=N it runs stage N (dotnet test with the stage's filter) and reports the result; " +
        "run stages in order and stop at the first failure. expect=fail|pass checks a regression test RED before a fix and GREEN after it.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "changedFiles": { "type": "array", "items": { "type": "string", "maxLength": 500 }, "maxItems": 500, "description": "Repository-relative paths. Default: Git changes." },
            "symbols": { "type": "array", "items": { "type": "string", "maxLength": 300 }, "maxItems": 50 },
            "run": { "type": "integer", "minimum": 1, "maximum": 5, "description": "Run this stage now." },
            "expect": { "type": "string", "enum": ["pass", "fail"], "description": "Expected outcome (RED → GREEN checks)." },
            "waitSeconds": { "type": "integer", "minimum": 1, "maximum": 600 }
          },
          "additionalProperties": false
        }
        """;

    public Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken)
    {
        var args = ToolArguments.Parse(call);
        return Task.FromResult(args.GetInt("run") is { } stage
            ? new ToolRiskAssessment(ToolRiskLevel.Sensitive, Capabilities.ExecuteProcess, [$"runs test stage {stage} (dotnet test)"], Summary: $"Run test stage {stage}")
            : new ToolRiskAssessment(ToolRiskLevel.ReadOnly, Summary: "Select tests"));
    }

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        // Changes are what this tool is about: refresh the index incrementally (unchanged files are skipped by size/time).
        var repo = await Services.RepositoryAsync(args, context, ct);
        var index = await Services.Indexes.GetAsync(repo, ct, TimeSpan.Zero);
        var changed = args.GetStringArray("changedFiles").ToList();
        var note = "";
        if (changed.Count == 0 && GitService.FindGitRoot(repo) is { } gitRoot && Services.Executables.IsAllowed("git"))
        {
            var ctx = new GitContext(context.UserId, repo, gitRoot, context.RunId, context.ConversationId);
            var status = await new GitService(Services).StatusAsync(ctx, ct);
            changed = status.Files.Where(f => f.Kind != "deleted").Select(f => ctx.DisplayPath(f.Path)).Where(p => !p.StartsWith("..", StringComparison.Ordinal)).ToList();
            note = $"Changed files from Git ({changed.Count}).\n";
        }
        var plan = TestSelector.Plan(index, changed, args.GetStringArray("symbols"), DeveloperWorkflowService.FindSolution(repo.Root));
        if (args.GetInt("run") is not { } run)
        {
            return note + TestSelector.Render(plan);
        }

        var stage = plan.Stages[run - 1];
        if (stage.Tests.Count == 0 && run < 5)
        {
            return note + $"Stage {run} ({stage.Name}) selects no tests — continue with stage {run + 1}.\n" + TestSelector.Render(plan);
        }
        if (!repo.AllowCommands)
        {
            throw new ForbiddenException($"Commands are not enabled for repository '{repo.Name}'.");
        }
        var record = await Services.Commands.StartAsync(context.UserId, repo, new CommandRequest
        {
            Kind = CommandKinds.Test, Target = stage.Target, Filter = stage.Filter, RunId = context.RunId, ConversationId = context.ConversationId,
        }, ct);
        var maxWait = Math.Max(5, Services.AgentOptions.ToolTimeoutSeconds - 5);
        record = await Services.Commands.WaitAsync(context.UserId, record.Id, TimeSpan.FromSeconds(Math.Clamp(args.GetInt("waitSeconds") ?? maxWait, 1, maxWait)), ct);
        var sb = new StringBuilder(note);
        sb.AppendLine(CultureInfo.InvariantCulture, $"Stage {run} — {stage.Name}: {record.CommandLine}");
        if (!record.IsFinal)
        {
            sb.AppendLine($"Still running. Check with command_status commandId={record.Id}.");
            return sb.ToString();
        }
        var t = record.Tests;
        var failed = record.Status != CommandStatus.Succeeded || (t?.Failed ?? 0) > 0;
        sb.AppendLine(CultureInfo.InvariantCulture, $"Result: {(failed ? "FAILED" : "passed")} — {t?.Passed ?? 0} passed, {t?.Failed ?? t?.Failures.Count ?? 0} failed, {t?.Skipped ?? 0} skipped (command {record.Id}, {record.DurationMs / 1000.0:0.0} s)");
        if (t?.Total is 0 or null && t?.Passed is 0 or null && !failed)
        {
            sb.AppendLine("Warning: no tests were executed by this stage's filter.");
        }
        foreach (var f in t?.Failures.Take(10) ?? [])
        {
            sb.AppendLine(CultureInfo.InvariantCulture, $"  ✗ {f.Name}: {AnalysisServices.Clip(f.Message, 200)}");
        }
        if (args.GetString("expect") is { } expect)
        {
            var met = expect == "fail" ? failed : !failed;
            sb.AppendLine(expect == "fail"
                ? met ? "RED confirmed: the test fails before the fix, so it reproduces the bug." : "Expected a failure (RED) but the stage passed — the test does not reproduce the bug yet."
                : met ? "GREEN confirmed: the stage passes." : "Expected a pass (GREEN) but the stage failed.");
        }
        sb.AppendLine(failed ? "Stop here: fix the failure before widening." : run < 5 ? $"Next: select_tests run={run + 1}." : "All stages passed.");
        return sb.ToString();
    }
}

/// <summary>Generates MSTest unit, integration or smoke tests that follow the repository's conventions.</summary>
public sealed class GenerateTestsTool(AnalysisServices services) : AnalysisTool(services), IDynamicRiskTool
{
    public override string Name => "generate_tests";

    public override string Description =>
        "Generates MSTest tests following the repository's conventions (framework and version, naming style, test project, folder layout; Moq only " +
        "when it is already referenced and an interface dependency needs isolation — a new NuGet dependency is reported, never added). kind=unit " +
        "inspects a class (constructor dependencies, public methods, async, nullability, null guards, thrown exceptions) and emits complete guard " +
        "tests plus clearly marked scaffolds (Assert.Inconclusive) for behaviour whose expected values must come from the requirement. kind=smoke " +
        "or integration target a web project: app starts, health, auth page, key API, GET routes, no fatal startup errors. write=true writes the file " +
        "(approval required); always run the generated tests afterwards (select_tests or run_tests).";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "kind": { "type": "string", "enum": ["unit", "integration", "smoke"] },
            "symbol": { "type": "string", "maxLength": 300, "description": "kind=unit: the class to test." },
            "project": { "type": "string", "maxLength": 200, "description": "kind=smoke/integration: the web project name." },
            "write": { "type": "boolean", "description": "Write the generated file to the suggested path (requires write access and approval)." },
            "path": { "type": "string", "maxLength": 500, "description": "Override the target path when writing." }
          },
          "additionalProperties": false
        }
        """;

    public Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken)
        => Task.FromResult(ToolArguments.Parse(call).GetBool("write") == true
            ? new ToolRiskAssessment(ToolRiskLevel.Sensitive, Findings: ["writes a new test file into the repository"], Summary: "Write generated tests")
            : new ToolRiskAssessment(ToolRiskLevel.ReadOnly, Summary: "Generate tests"));

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        var kind = args.GetString("kind") ?? "unit";
        GeneratedTests generated;
        if (kind == "unit")
        {
            var query = args.RequireString("symbol");
            var type = index.Resolve(query).FirstOrDefault(s => SymbolKinds.IsType(s.Kind) && !s.IsTest)
                       ?? index.Resolve(query).Where(s => !s.IsTest).Select(s => s.Container is null ? null : index.Resolve(s.Container).FirstOrDefault(t => SymbolKinds.IsType(t.Kind))).FirstOrDefault(t => t is not null)
                       ?? throw new NotFoundException($"Class '{query}'");
            generated = TestGenerator.Unit(index, type, m => AnalysisServices.ReadNumberedLines(repo.Resolve(m.File), m.StartLine, m.EndLine, 400, out _));
        }
        else
        {
            var name = args.GetString("project");
            var project = (name is { Length: > 0 } ? index.Projects.Values.FirstOrDefault(p => p.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) : null)
                          ?? index.Projects.Values.FirstOrDefault(p => !p.IsTestProject && p.Sdk?.Contains("Web", StringComparison.OrdinalIgnoreCase) == true)
                          ?? throw new NotFoundException("Web project (pass 'project')");
            generated = TestGenerator.Smoke(index, project, kind == "integration");
        }

        var sb = new StringBuilder();
        var c = generated.Conventions;
        sb.AppendLine(CultureInfo.InvariantCulture, $"Generated {generated.Kind} tests: {generated.ClassName} → {args.GetString("path") ?? generated.SuggestedPath}");
        sb.AppendLine(CultureInfo.InvariantCulture, $"Conventions: {c.Framework}{(c.FrameworkVersion is null ? "" : " " + c.FrameworkVersion)} in {c.TestProject ?? "(no test project found)"}; naming {c.NamingStyle}; " +
            $"doubles: {(c.Moq ? "Moq" : "none")}{(c.OtherDoubles.Count > 0 ? ", " + string.Join(", ", c.OtherDoubles) : "")}; assertions: {(c.AssertionLibraries.Count > 0 ? string.Join(", ", c.AssertionLibraries) : "MSTest Assert")}");
        foreach (var line in generated.Analysis)
        {
            sb.AppendLine("  · " + line);
        }
        foreach (var warning in generated.Warnings)
        {
            sb.AppendLine("  ⚠ " + warning);
        }
        foreach (var dependency in generated.NewDependencies)
        {
            sb.AppendLine("  New dependency (not added): " + dependency);
        }
        sb.AppendLine(CultureInfo.InvariantCulture, $"{generated.CompleteTests} complete test(s); {generated.ScaffoldTests} scaffold(s) marked Assert.Inconclusive that must be completed before they count.");

        if (args.GetBool("write") == true)
        {
            if (!repo.AllowWrite)
            {
                throw new ForbiddenException($"Repository '{repo.Name}' is read-only.");
            }
            var target = repo.Resolve(args.GetString("path") ?? generated.SuggestedPath);
            if (File.Exists(target))
            {
                throw new ValidationException($"{repo.Relative(target)} already exists; choose another path or edit it with source_edit.");
            }
            Directory.CreateDirectory(Path.GetDirectoryName(target)!);
            await File.WriteAllTextAsync(target, generated.Code, ct);
            Services.Indexes.Invalidate(repo);
            sb.AppendLine(CultureInfo.InvariantCulture, $"Written: {repo.Relative(target).Replace('\\', '/')}. Next: build and run it (select_tests changedFiles=[\"{repo.Relative(target).Replace('\\', '/')}\"] run=1) — generated tests count only after they ran.");
        }
        sb.AppendLine("```csharp");
        sb.Append(generated.Code);
        sb.AppendLine("```");
        return sb.ToString();
    }
}
