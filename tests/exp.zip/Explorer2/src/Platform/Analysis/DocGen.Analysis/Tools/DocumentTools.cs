using System.Globalization;
using System.Text;
using DocGen.Analysis.Documents;
using DocGen.Core.Documents;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

/// <summary>Office document tools: retrieval over ingestion, every excerpt cited by file and sheet/slide/section and cell/range/paragraph.</summary>
public abstract class DocumentToolBase(AnalysisServices services) : AnalysisTool(services)
{
    protected const string PathProperty = """
        "path": { "type": "string", "minLength": 1, "maxLength": 500, "description": "Document path in the repository (default repository: your workspace, including uploads)." }
        """;

    protected async Task<(string Full, string Label)> DocumentAsync(ToolArguments args, ToolExecutionContext context, string[] extensions, CancellationToken ct)
    {
        var repo = await Services.RepositoryAsync(args, context, ct);
        var full = repo.Resolve(args.RequireString("path"));
        var ext = Path.GetExtension(full).ToLowerInvariant();
        if (OfficePackage.IsLegacy(full))
        {
            throw new ValidationException("Legacy binary Office formats (.doc, .xls, .ppt) are not supported; save the file as .docx, .xlsx or .pptx.");
        }
        if (!extensions.Contains(ext))
        {
            throw new ValidationException($"This tool reads {string.Join(", ", extensions)} files.");
        }
        var label = Path.GetFileName(full);
        if (!File.Exists(full) && Services.Service<IFileService>() is { } files)
        {
            // Uploads are stored by id (files/<id>.pdf); models naturally ask for them by the name the user sees.
            var uploads = await files.ListAsync(context.UserId, ct: ct);
            var wanted = Path.GetFileName(args.RequireString("path").Replace('\\', '/'));
            if (uploads.Where(f => f.FileName.Equals(wanted, StringComparison.OrdinalIgnoreCase)).OrderByDescending(f => f.CreatedAt).FirstOrDefault() is { } upload)
            {
                full = Path.Combine(files.GetWorkspaceRoot(context.UserId), upload.RelativePath.Replace('/', Path.DirectorySeparatorChar));
                label = upload.FileName;
            }
            else
            {
                var same = uploads.Where(f => extensions.Contains(Path.GetExtension(f.FileName).ToLowerInvariant())).Take(10)
                    .Select(f => $"{f.FileName} → path \"{f.RelativePath}\"").ToList();
                if (same.Count > 0)
                {
                    throw new ValidationException($"No document at \"{args.RequireString("path")}\". Uploaded files of this type (stored by id): {string.Join("; ", same)}.");
                }
                throw new NotFoundException("Document");
            }
        }
        if (!File.Exists(full))
        {
            throw new NotFoundException("Document");
        }
        await Services.TrackInspectedAsync(context, repo.Name, [repo.Relative(full).Replace('\\', '/')], ct);
        return (full, label);
    }

    protected static string Clip(string text, int max) => text.Length <= max ? text : text[..max] + "…";

    protected static void Properties(StringBuilder sb, Dictionary<string, string> properties)
    {
        if (properties.Count > 0)
        {
            sb.AppendLine("Properties: " + string.Join(" · ", properties.Select(p => $"{p.Key} {p.Value}")));
        }
    }
}

public sealed class ReadDocumentTool(AnalysisServices services) : DocumentToolBase(services)
{
    public override string Name => "read_document";

    public override string Description =>
        "Reads a Word document (.docx) without Office: mode=summary (properties, counts, outline), outline (headings), section (the blocks under a heading), " +
        "paragraphs (a ¶ range), tables (all or one table), search (matching paragraphs/table rows). Blocks keep document order: headings, paragraphs, " +
        "lists, tables, hyperlinks, headers/footers. Every excerpt is cited as file §section ¶n. Retrieve the part you need instead of the whole document. " +
        "Also reads the text layer of a PDF: mode=summary (properties, page count, first page), pages (from/to page range), search (matching lines, cited as file p.n). " +
        "Scanned PDFs without a text layer cannot be read.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            {{PathProperty}},
            "mode": { "type": "string", "enum": ["summary", "outline", "section", "paragraphs", "tables", "search", "pages"] },
            "heading": { "type": "string", "maxLength": 200, "description": "mode=section: heading text (case-insensitive, partial match)." },
            "from": { "type": "integer", "minimum": 1, "description": "mode=paragraphs: first ¶; mode=pages (PDF): first page." },
            "to": { "type": "integer", "minimum": 1 },
            "table": { "type": "integer", "minimum": 1, "description": "mode=tables: one table number." },
            "query": { "type": "string", "maxLength": 200 },
            "maxChars": { "type": "integer", "minimum": 500, "maximum": 60000 }
          },
          "required": ["path"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (full, file) = await DocumentAsync(args, context, [".docx", ".docm", ".dotx", ".pdf"], ct);
        var root = Path.GetFullPath(context.WorkspaceRoot);
        var origin = Path.GetFullPath(full).StartsWith(root, StringComparison.OrdinalIgnoreCase)
            ? SourceOrigin.ForWorkspacePath(Path.GetRelativePath(root, full))
            : null;
        var text = await ReadAsync(args, full, file, ct);
        return origin is null ? text : origin + "\n" + text;
    }

    private async Task<string> ReadAsync(ToolArguments args, string full, string file, CancellationToken ct)
    {
        var max = Clamp(args.GetInt("maxChars"), 12_000, 500, 60_000);
        if (full.EndsWith(".pdf", StringComparison.OrdinalIgnoreCase))
        {
            return await ReadPdfAsync(args, full, file, max, ct);
        }
        var doc = await Task.Run(() => DocxReader.Read(full), ct);
        var sb = new StringBuilder();
        string Cite(DocBlock b) => $"[{file} §\"{Clip(b.Section, 60)}\" ¶{b.Index}]";
        void Block(DocBlock b)
        {
            switch (b.Kind)
            {
                case "heading":
                    sb.AppendLine(CultureInfo.InvariantCulture, $"{new string('#', Math.Min(b.Level, 6))} {b.Text}  [¶{b.Index}]");
                    break;
                case "list":
                    sb.AppendLine(CultureInfo.InvariantCulture, $"{new string(' ', b.Level * 2)}- {b.Text}  [¶{b.Index}]");
                    break;
                case "table":
                    sb.AppendLine(CultureInfo.InvariantCulture, $"Table {b.TableNumber} ({b.Rows!.Count} rows)  [¶{b.Index}]");
                    for (var r = 0; r < b.Rows.Count; r++)
                    {
                        sb.AppendLine(CultureInfo.InvariantCulture, $"  r{r + 1}: {string.Join(" | ", b.Rows[r])}");
                    }
                    break;
                default:
                    sb.AppendLine(CultureInfo.InvariantCulture, $"{b.Text}  [¶{b.Index}]");
                    break;
            }
            foreach (var (text, url) in b.Links)
            {
                sb.AppendLine(CultureInfo.InvariantCulture, $"    link: {text} → {url}");
            }
        }

        switch (args.GetString("mode") ?? "summary")
        {
            case "summary":
                sb.AppendLine(CultureInfo.InvariantCulture, $"{file}: {doc.Blocks.Count(b => b.Kind != "table")} paragraphs, {doc.Headings.Count()} headings, {doc.Tables.Count()} tables, ~{doc.Words:N0} words, {doc.Blocks.Sum(b => b.Links.Count)} hyperlinks");
                Properties(sb, doc.Properties);
                if (doc.Headers.Count > 0)
                {
                    sb.AppendLine("Headers: " + string.Join(" / ", doc.Headers.Select(h => Clip(h, 120))));
                }
                if (doc.Footers.Count > 0)
                {
                    sb.AppendLine("Footers: " + string.Join(" / ", doc.Footers.Select(h => Clip(h, 120))));
                }
                sb.AppendLine("Outline:");
                foreach (var h in doc.Headings.Take(80))
                {
                    sb.AppendLine(CultureInfo.InvariantCulture, $"{new string(' ', (h.Level - 1) * 2)}{h.Text}  [¶{h.Index}]");
                }
                if (!doc.Headings.Any())
                {
                    foreach (var b in doc.Blocks.Take(5))
                    {
                        Block(b);
                    }
                }
                break;
            case "outline":
                foreach (var h in doc.Headings)
                {
                    sb.AppendLine(CultureInfo.InvariantCulture, $"{new string(' ', (h.Level - 1) * 2)}{h.Text}  [¶{h.Index}]");
                }
                break;
            case "section":
                var query = args.RequireString("heading");
                var heading = doc.Headings.FirstOrDefault(h => h.Text.Equals(query, StringComparison.OrdinalIgnoreCase))
                              ?? doc.Headings.FirstOrDefault(h => h.Text.Contains(query, StringComparison.OrdinalIgnoreCase))
                              ?? throw new NotFoundException($"Heading '{query}'");
                sb.AppendLine(CultureInfo.InvariantCulture, $"Section of {file} starting at ¶{heading.Index}:");
                foreach (var b in doc.Blocks.SkipWhile(b => b != heading).TakeWhile(b => b == heading || !(b.Kind == "heading" && b.Level <= heading.Level)))
                {
                    Block(b);
                }
                break;
            case "paragraphs":
                var from = args.GetInt("from") ?? 1;
                var to = args.GetInt("to") ?? from + 40;
                foreach (var b in doc.Blocks.Where(b => b.Index >= from && b.Index <= to))
                {
                    Block(b);
                }
                break;
            case "tables":
                var tables = doc.Tables.Where(t => args.GetInt("table") is not { } n || t.TableNumber == n).ToList();
                if (tables.Count == 0)
                {
                    throw new NotFoundException("Table");
                }
                foreach (var t in tables)
                {
                    sb.AppendLine(Cite(t));
                    Block(t);
                }
                break;
            case "search":
                var q = args.RequireString("query");
                var hits = 0;
                foreach (var b in doc.Blocks)
                {
                    if (b.Kind == "table")
                    {
                        for (var r = 0; r < b.Rows!.Count; r++)
                        {
                            if (string.Join(" | ", b.Rows[r]) is var row && row.Contains(q, StringComparison.OrdinalIgnoreCase))
                            {
                                sb.AppendLine(CultureInfo.InvariantCulture, $"{Cite(b)} Table {b.TableNumber} r{r + 1}: {Clip(row, 300)}");
                                hits++;
                            }
                        }
                    }
                    else if (b.Text.Contains(q, StringComparison.OrdinalIgnoreCase))
                    {
                        sb.AppendLine(CultureInfo.InvariantCulture, $"{Cite(b)} {Clip(b.Text, 400)}");
                        hits++;
                    }
                    if (hits >= 100)
                    {
                        break;
                    }
                }
                sb.Insert(0, $"{hits} match(es) for \"{q}\" in {file}{(hits >= 100 ? " (first 100)" : "")}\n");
                break;
            default:
                throw new ValidationException("Unknown mode.");
        }
        var text = sb.ToString();
        return text.Length > max ? text[..max] + $"\n… (truncated at {max:N0} characters; narrow with section/paragraphs/search)" : text;
    }

    private static async Task<string> ReadPdfAsync(ToolArguments args, string full, string file, int max, CancellationToken ct)
    {
        var pdf = await Task.Run(() => PdfTextReader.Read(full, ct), ct);
        if (!pdf.HasText)
        {
            throw new ValidationException(pdf.Error ?? "The PDF has no readable text.");
        }
        var sb = new StringBuilder();
        void Page(PdfPageText page)
        {
            sb.AppendLine(CultureInfo.InvariantCulture, $"--- [{file} p.{page.Number}] ---");
            sb.AppendLine(page.Text);
        }
        switch (args.GetString("mode") ?? "summary")
        {
            case "summary":
                sb.AppendLine(CultureInfo.InvariantCulture, $"{file}: PDF, {pdf.PageCount} page(s), ~{pdf.WordCount:N0} words{(pdf.Truncated ? " (text truncated)" : "")}");
                Properties(sb, pdf.Properties);
                foreach (var page in pdf.Pages.Where(p => p.Text.Length > 0).Take(1))
                {
                    Page(page);
                }
                if (pdf.PageCount > 1)
                {
                    sb.AppendLine("(Use mode=pages with from/to, or mode=search, for the rest.)");
                }
                break;
            case "pages":
                var from = args.GetInt("from") ?? 1;
                var to = args.GetInt("to") ?? from + 4;
                var pages = pdf.Pages.Where(p => p.Number >= from && p.Number <= to).ToList();
                if (pages.Count == 0)
                {
                    throw new NotFoundException($"Pages {from}–{to} (the PDF has {pdf.PageCount} page(s))");
                }
                pages.ForEach(Page);
                break;
            case "search":
                var q = args.RequireString("query");
                var hits = 0;
                foreach (var page in pdf.Pages)
                {
                    foreach (var line in page.Text.Split('\n'))
                    {
                        if (hits < 100 && line.Contains(q, StringComparison.OrdinalIgnoreCase))
                        {
                            sb.AppendLine(CultureInfo.InvariantCulture, $"[{file} p.{page.Number}] {Clip(line.Trim(), 400)}");
                            hits++;
                        }
                    }
                }
                sb.Insert(0, $"{hits} match(es) for \"{q}\" in {file}{(hits >= 100 ? " (first 100)" : "")}\n");
                break;
            default:
                throw new ValidationException("For a PDF, mode must be summary, pages or search.");
        }
        var text = sb.ToString();
        return text.Length > max ? text[..max] + $"\n… (truncated at {max:N0} characters; narrow with pages/search)" : text;
    }
}

/// <summary>OCR and classification of an image file (screenshot, scan, photo, diagram…) with the Windows OCR engine.</summary>
public sealed class ReadImageTool(AnalysisServices services) : DocumentToolBase(services)
{
    public override string Name => "read_image";

    public override string Description =>
        "Reads the text in an image (OCR) and classifies the image: text document/screenshot/scan, photo of text, diagram or graphic with some text, " +
        "photo with some text, graphic without text, or photo without text. Returns the recognised lines (may contain OCR errors), word count, how much " +
        "of the image is text, and the image size. Works for .png .jpg .jpeg .gif .bmp .tif .tiff .webp in a repository or your workspace (including uploads).";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": { {{RepositoryProperty}}, {{PathProperty}}, "maxChars": { "type": "integer", "minimum": 200, "maximum": 60000 } },
          "required": ["path"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (full, file) = await DocumentAsync(args, context, [".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".webp"], ct);
        var maxChars = Clamp(args.GetInt("maxChars"), 12_000, 200, 60_000);
        // A vision model describes the image (Settings → Agent → Images); Windows OCR is the fallback.
        var seen = Services.Service<IImageDescriber>() is { } describer ? await describer.DescribeAsync(full, file, ct) : null;
        if (seen is { Error: null })
        {
            var text = seen.Text.Length > maxChars ? seen.Text[..maxChars] + "\n…[truncated]" : seen.Text;
            return $"{file}: described by the vision model {seen.Engine} (what it shows, then its text):\n{text}";
        }
        var analyzer = Services.Service<IImageAnalyzer>() ?? throw new DocGenException("OCR_UNAVAILABLE", "Image analysis is not available in this host.", 500);
        var analysis = await analyzer.AnalyzeAsync(context.UserId, full, ct);
        var note = seen?.Error is { } error ? $"(The vision model could not read it: {error}. Windows OCR was used instead.)\n" : "";
        return note + ImageAnalyzer.Describe(analysis, file, maxChars);
    }
}

public abstract class WorkbookToolBase(AnalysisServices services) : DocumentToolBase(services)
{
    protected static readonly string[] Extensions = [".xlsx", ".xlsm"];

    protected const string SheetProperty = """
        "sheet": { "type": "string", "maxLength": 100, "description": "Sheet name (default: the first sheet)." }
        """;

    protected static string Cite(string file, string sheet, string reference) => $"{file}!{(sheet.Contains(' ', StringComparison.Ordinal) ? $"'{sheet}'" : sheet)}!{reference}";

    protected static string Show(CellValue c) => c.Type switch
    {
        "string" => c.Value.Contains('\n', StringComparison.Ordinal) ? c.Value.Replace("\n", "⏎", StringComparison.Ordinal) : c.Value,
        _ => c.Value,
    };
}

public sealed class ListSheetsTool(AnalysisServices services) : WorkbookToolBase(services)
{
    public override string Name => "list_sheets";

    public override string Description => "Lists an Excel workbook's (.xlsx) sheets with visibility, used range, cell and formula counts, tables, merged ranges, named ranges and properties.";

    public override string InputSchema => $$"""
        { "type": "object", "properties": { {{RepositoryProperty}}, {{PathProperty}} }, "required": ["path"], "additionalProperties": false }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (full, file) = await DocumentAsync(args, context, Extensions, ct);
        return await Task.Run(() =>
        {
            using var book = XlsxReader.Open(full);
            var sb = new StringBuilder($"{file}: ");
            var sheets = book.Sheets();
            sb.AppendLine(CultureInfo.InvariantCulture, $"{sheets.Count} sheet(s)");
            Properties(sb, book.Properties());
            foreach (var s in sheets)
            {
                ct.ThrowIfCancellationRequested();
                var data = book.Read(s);
                sb.AppendLine($"{s.Index}. {s.Name}{(s.State == "visible" ? "" : $" ({s.State})")}: used range {data.UsedRange}, {data.Cells.Count:N0} cells, {data.Cells.Count(c => c.Formula is not null):N0} formulas" +
                    (data.Tables.Count > 0 ? ", tables " + string.Join(", ", data.Tables.Select(t => $"{t.Name} ({t.Range})")) : "") + (data.MergedRanges > 0 ? $", {data.MergedRanges} merged ranges" : ""));
            }
            var names = book.DefinedNames();
            if (names.Count > 0)
            {
                sb.AppendLine("Named ranges: " + string.Join("; ", names.Take(50).Select(n => $"{n.Name} = {n.Reference}{(n.Scope is null ? "" : $" (sheet {n.Scope})")}")));
            }
            return sb.ToString();
        }, ct);
    }
}

public sealed class SheetSummaryTool(AnalysisServices services) : WorkbookToolBase(services)
{
    public override string Name => "sheet_summary";

    public override string Description =>
        "Summarizes one sheet: used range, header row, per-column inferred type and fill, sample rows, formula examples, tables and merged ranges — without reading every cell into the conversation.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": { {{RepositoryProperty}}, {{PathProperty}}, {{SheetProperty}}, "sampleRows": { "type": "integer", "minimum": 0, "maximum": 50 } },
          "required": ["path"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (full, file) = await DocumentAsync(args, context, Extensions, ct);
        var samples = Clamp(args.GetInt("sampleRows"), 5, 0, 50);
        return await Task.Run(() =>
        {
            using var book = XlsxReader.Open(full);
            var sheet = book.Sheet(args.GetString("sheet"));
            var data = book.Read(sheet);
            var sb = new StringBuilder();
            sb.AppendLine(CultureInfo.InvariantCulture, $"{Cite(file, sheet.Name, data.UsedRange)} — {data.Cells.Count:N0} cells, {data.Cells.Count(c => c.Formula is not null):N0} formulas{(data.Dimension is null ? "" : $", declared dimension {data.Dimension}")}");
            if (data.Used is not { } used)
            {
                sb.AppendLine("The sheet is empty.");
                return sb.ToString();
            }
            var byRow = data.Cells.GroupBy(c => c.Row).OrderBy(g => g.Key).ToList();
            var header = byRow.First();
            sb.AppendLine($"Header (row {header.Key}): " + string.Join(" | ", header.OrderBy(c => c.Column).Select(c => $"{XlsxReader.ColumnName(c.Column)}={Clip(Show(c), 40)}")));
            sb.AppendLine("Columns:");
            foreach (var column in data.Cells.Where(c => c.Row > header.Key).GroupBy(c => c.Column).OrderBy(g => g.Key).Take(60))
            {
                var types = column.GroupBy(c => c.Type).OrderByDescending(g => g.Count()).Select(g => $"{g.Key} {g.Count()}");
                var name = header.FirstOrDefault(h => h.Column == column.Key) is { } h ? Clip(Show(h), 40) : "";
                sb.AppendLine(CultureInfo.InvariantCulture, $"  {XlsxReader.ColumnName(column.Key)} {name}: {column.Count()} values ({string.Join(", ", types)}){(column.Any(c => c.Formula is not null) ? $", {column.Count(c => c.Formula is not null)} formulas" : "")}");
            }
            if (samples > 0)
            {
                sb.AppendLine("Sample rows:");
                foreach (var row in byRow.Skip(1).Take(samples))
                {
                    sb.AppendLine($"  row {row.Key}: " + string.Join(" | ", row.OrderBy(c => c.Column).Select(c => $"{c.Reference}={Clip(Show(c), 40)}")));
                }
            }
            foreach (var f in data.Cells.Where(c => c.Formula is not null && !c.Formula.StartsWith('(')).Take(8))
            {
                sb.AppendLine(CultureInfo.InvariantCulture, $"  formula {f.Reference}: ={Clip(f.Formula!, 120)} → cached {Clip(Show(f), 40)}");
            }
            foreach (var t in data.Tables)
            {
                sb.AppendLine(CultureInfo.InvariantCulture, $"Table {t.Name} {t.Range}: {string.Join(", ", t.Columns)}");
            }
            if (data.MergedRanges > 0)
            {
                sb.AppendLine(CultureInfo.InvariantCulture, $"{data.MergedRanges} merged range(s).");
            }
            sb.AppendLine("Values are the cached results saved in the file (DocGen does not recalculate formulas).");
            return sb.ToString();
        }, ct);
    }
}

public sealed class ReadRangeTool(AnalysisServices services) : WorkbookToolBase(services)
{
    public override string Name => "read_range";

    public override string Description => "Reads a cell range (A1:D20, B:B, 3:5) from a sheet: values (cached), types and formulas, cited as file!Sheet!Cell. At most 2,000 non-empty cells.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}}, {{PathProperty}}, {{SheetProperty}},
            "range": { "type": "string", "minLength": 1, "maxLength": 40 },
            "formulas": { "type": "boolean", "description": "Include formulas (default true)." }
          },
          "required": ["path", "range"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (full, file) = await DocumentAsync(args, context, Extensions, ct);
        var bounds = XlsxReader.ParseRange(args.RequireString("range"));
        var formulas = args.GetBool("formulas") != false;
        return await Task.Run(() =>
        {
            using var book = XlsxReader.Open(full);
            var sheet = book.Sheet(args.GetString("sheet"));
            var data = book.Read(sheet, bounds, 2001);
            var sb = new StringBuilder();
            sb.AppendLine(CultureInfo.InvariantCulture, $"{Cite(file, sheet.Name, args.RequireString("range").ToUpperInvariant())}: {Math.Min(data.Cells.Count, 2000)} non-empty cells{(data.Cells.Count > 2000 ? " (first 2,000 — narrow the range)" : "")}");
            foreach (var row in data.Cells.Take(2000).GroupBy(c => c.Row).OrderBy(g => g.Key))
            {
                sb.Append(CultureInfo.InvariantCulture, $"row {row.Key}: ");
                sb.AppendLine(string.Join(" | ", row.OrderBy(c => c.Column).Select(c =>
                    $"{c.Reference}={Clip(Show(c), 80)}{(c.Type is "date" or "error" or "boolean" ? $" ({c.Type})" : "")}{(formulas && c.Formula is not null ? $" [={Clip(c.Formula, 80)}]" : "")}")));
            }
            return sb.ToString();
        }, ct);
    }
}

public sealed class FindInWorkbookTool(AnalysisServices services) : WorkbookToolBase(services)
{
    public override string Name => "find_in_workbook";

    public override string Description => "Finds cells whose value (or formula) contains text across all sheets or one sheet. Returns file!Sheet!Cell citations.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}}, {{PathProperty}}, {{SheetProperty}},
            "query": { "type": "string", "minLength": 1, "maxLength": 200 },
            "includeFormulas": { "type": "boolean" },
            "maxResults": { "type": "integer", "minimum": 1, "maximum": 500 }
          },
          "required": ["path", "query"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (full, file) = await DocumentAsync(args, context, Extensions, ct);
        var query = args.RequireString("query");
        var max = Clamp(args.GetInt("maxResults"), 50, 1, 500);
        return await Task.Run(() =>
        {
            using var book = XlsxReader.Open(full);
            var sheets = args.GetString("sheet") is { Length: > 0 } one ? [book.Sheet(one)] : book.Sheets();
            var sb = new StringBuilder();
            var hits = 0;
            foreach (var s in sheets)
            {
                foreach (var c in book.Read(s).Cells)
                {
                    if (c.Value.Contains(query, StringComparison.OrdinalIgnoreCase) || args.GetBool("includeFormulas") == true && c.Formula?.Contains(query, StringComparison.OrdinalIgnoreCase) == true)
                    {
                        sb.AppendLine(CultureInfo.InvariantCulture, $"{Cite(file, s.Name, c.Reference)}: {Clip(Show(c), 160)}{(c.Formula is null ? "" : $" [={Clip(c.Formula, 100)}]")}");
                        if (++hits >= max)
                        {
                            break;
                        }
                    }
                }
                if (hits >= max)
                {
                    break;
                }
            }
            return $"{hits} match(es) for \"{query}\" in {file}{(hits >= max ? $" (first {max})" : "")}\n" + sb;
        }, ct);
    }
}

public sealed class FormulaSearchTool(AnalysisServices services) : WorkbookToolBase(services)
{
    public override string Name => "formula_search";

    public override string Description => "Lists formulas that contain a function name or text (e.g. VLOOKUP, SUM(, Sheet2!, #REF!) with their cached results; without 'query', summarizes the functions used per sheet.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}}, {{PathProperty}}, {{SheetProperty}},
            "query": { "type": "string", "maxLength": 200 },
            "maxResults": { "type": "integer", "minimum": 1, "maximum": 500 }
          },
          "required": ["path"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (full, file) = await DocumentAsync(args, context, Extensions, ct);
        var query = args.GetString("query");
        var max = Clamp(args.GetInt("maxResults"), 50, 1, 500);
        return await Task.Run(() =>
        {
            using var book = XlsxReader.Open(full);
            var sheets = args.GetString("sheet") is { Length: > 0 } one ? [book.Sheet(one)] : book.Sheets();
            var sb = new StringBuilder();
            var hits = 0;
            foreach (var s in sheets)
            {
                var formulas = book.Read(s).Cells.Where(c => c.Formula is not null).ToList();
                if (query is null or "")
                {
                    var functions = formulas.SelectMany(f => System.Text.RegularExpressions.Regex.Matches(f.Formula!, @"\b([A-Z][A-Z0-9.]{1,30})\(").Select(m => m.Groups[1].Value))
                        .GroupBy(x => x).OrderByDescending(g => g.Count()).Take(20);
                    sb.AppendLine($"{s.Name}: {formulas.Count} formulas; functions: {string.Join(", ", functions.Select(g => $"{g.Key}×{g.Count()}"))}" +
                        (formulas.Count(f => f.Type == "error") is > 0 and var errors ? $"; {errors} formulas with error results" : ""));
                    continue;
                }
                foreach (var f in formulas.Where(f => f.Formula!.Contains(query, StringComparison.OrdinalIgnoreCase)))
                {
                    sb.AppendLine(CultureInfo.InvariantCulture, $"{Cite(file, s.Name, f.Reference)}: ={Clip(f.Formula!, 200)} → {Clip(Show(f), 60)}{(f.Type == "error" ? " (error)" : "")}");
                    if (++hits >= max)
                    {
                        break;
                    }
                }
            }
            return (query is null or "" ? $"Formula overview of {file}\n" : $"{hits} formula(s) containing \"{query}\" in {file}\n") + sb;
        }, ct);
    }
}

public abstract class PresentationToolBase(AnalysisServices services) : DocumentToolBase(services)
{
    protected static readonly string[] Extensions = [".pptx", ".pptm", ".ppsx"];

    protected static void Slide(StringBuilder sb, string file, SlideContent s, bool notes, int maxParagraphs = 200)
    {
        sb.AppendLine(CultureInfo.InvariantCulture, $"[{file} slide {s.Number}]{(s.Hidden ? " (hidden)" : "")} {s.Title ?? "(no title)"}{(s.Layout is null ? "" : $" · layout {s.Layout}")}");
        foreach (var (level, text) in s.Paragraphs.Take(maxParagraphs))
        {
            sb.AppendLine(CultureInfo.InvariantCulture, $"{new string(' ', 2 + level * 2)}- {text}");
        }
        for (var t = 0; t < s.Tables.Count; t++)
        {
            sb.AppendLine(CultureInfo.InvariantCulture, $"  table {t + 1}:");
            for (var r = 0; r < s.Tables[t].Count; r++)
            {
                sb.AppendLine(CultureInfo.InvariantCulture, $"    r{r + 1}: {string.Join(" | ", s.Tables[t][r])}");
            }
        }
        if (s.Objects.Count(o => o.Kind != "table") is > 0)
        {
            sb.AppendLine("  objects: " + string.Join(", ", s.Objects.Where(o => o.Kind != "table").Select(o => $"{o.Kind} \"{o.Name}\"{(o.Description is { Length: > 0 } d ? $" ({Clip(d, 80)})" : "")}")));
        }
        if (notes && s.Notes is { } n)
        {
            sb.AppendLine("  notes: " + n.Replace("\n", " / ", StringComparison.Ordinal));
        }
    }
}

public sealed class PresentationSummaryTool(AnalysisServices services) : PresentationToolBase(services)
{
    public override string Name => "presentation_summary";

    public override string Description => "Summarizes a PowerPoint deck (.pptx): properties, slide count, each slide's number, title, text size, tables, objects (pictures, charts) and whether it has speaker notes.";

    public override string InputSchema => $$"""
        { "type": "object", "properties": { {{RepositoryProperty}}, {{PathProperty}} }, "required": ["path"], "additionalProperties": false }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (full, file) = await DocumentAsync(args, context, Extensions, ct);
        var (properties, slides) = await Task.Run(() => PptxReader.Read(full), ct);
        var sb = new StringBuilder($"{file}: {slides.Count} slides, {slides.Count(s => s.Notes is not null)} with notes, {slides.Sum(s => s.Tables.Count)} tables, {slides.Sum(s => s.Objects.Count(o => o.Kind == "picture"))} pictures, {slides.Sum(s => s.Objects.Count(o => o.Kind == "chart"))} charts\n");
        Properties(sb, properties);
        foreach (var s in slides)
        {
            sb.AppendLine($"{s.Number,3}. {s.Title ?? "(no title)"}{(s.Hidden ? " (hidden)" : "")} — {s.Paragraphs.Count} text paragraphs" +
                (s.Tables.Count > 0 ? $", {s.Tables.Count} table(s)" : "") + (s.Objects.Count(o => o.Kind is "picture" or "chart") is > 0 and var objects ? $", {objects} picture/chart(s)" : "") + (s.Notes is null ? "" : ", notes"));
        }
        return sb.ToString();
    }
}

public sealed class ReadSlideTool(AnalysisServices services) : PresentationToolBase(services)
{
    public override string Name => "read_slide";

    public override string Description => "Reads one slide (or a range) of a .pptx: title, text with bullet levels, tables, speaker notes and object metadata, cited by slide number.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}}, {{PathProperty}},
            "slide": { "type": "integer", "minimum": 1 },
            "to": { "type": "integer", "minimum": 1, "description": "Last slide of a range (at most 20 slides)." },
            "notes": { "type": "boolean", "description": "Include speaker notes (default true)." }
          },
          "required": ["path", "slide"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (full, file) = await DocumentAsync(args, context, Extensions, ct);
        var from = args.GetInt("slide") ?? 1;
        var to = Math.Min(args.GetInt("to") ?? from, from + 19);
        var (_, slides) = await Task.Run(() => PptxReader.Read(full), ct);
        var selected = slides.Where(s => s.Number >= from && s.Number <= to).ToList();
        if (selected.Count == 0)
        {
            throw new NotFoundException($"Slide {from} (the deck has {slides.Count} slides)");
        }
        var sb = new StringBuilder();
        foreach (var s in selected)
        {
            Slide(sb, file, s, args.GetBool("notes") != false);
        }
        return sb.ToString();
    }
}

public sealed class SearchPresentationTool(AnalysisServices services) : PresentationToolBase(services)
{
    public override string Name => "search_presentation";

    public override string Description => "Finds text in a .pptx across titles, body text, tables and speaker notes; each hit is cited by slide number and location.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": { {{RepositoryProperty}}, {{PathProperty}}, "query": { "type": "string", "minLength": 1, "maxLength": 200 } },
          "required": ["path", "query"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (full, file) = await DocumentAsync(args, context, Extensions, ct);
        var q = args.RequireString("query");
        var (_, slides) = await Task.Run(() => PptxReader.Read(full), ct);
        var sb = new StringBuilder();
        var hits = 0;
        foreach (var s in slides)
        {
            void Hit(string where, string text)
            {
                if (text.Contains(q, StringComparison.OrdinalIgnoreCase) && hits < 200)
                {
                    sb.AppendLine(CultureInfo.InvariantCulture, $"[{file} slide {s.Number} {where}] {Clip(text, 300)}");
                    hits++;
                }
            }
            Hit("title", s.Title ?? "");
            foreach (var (_, text) in s.Paragraphs)
            {
                Hit("body", text);
            }
            for (var t = 0; t < s.Tables.Count; t++)
            {
                for (var r = 0; r < s.Tables[t].Count; r++)
                {
                    Hit($"table {t + 1} r{r + 1}", string.Join(" | ", s.Tables[t][r]));
                }
            }
            Hit("notes", s.Notes ?? "");
        }
        return $"{hits} match(es) for \"{q}\" in {file}\n" + sb;
    }
}
