using DocGen.Core.Abstractions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

/// <summary>Base for analysis tools: parses arguments and turns the returned text into a tool result.</summary>
public abstract class AnalysisTool(AnalysisServices services) : IAgentTool
{
    protected const string RepositoryProperty = """
        "repository": { "type": "string", "maxLength": 64, "description": "Repository name from repo_list. Default: the repository selected in the DocGen UI, otherwise workspace (your own files)." }
        """;

    protected AnalysisServices Services => services;

    public abstract string Name { get; }

    public abstract string Description { get; }

    public abstract string InputSchema { get; }

    public virtual ToolRiskLevel RiskLevel => ToolRiskLevel.ReadOnly;

    public async Task<ToolResult> ExecuteAsync(ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken)
    {
        var args = ToolArguments.Parse(call);
        return await RunResultAsync(call, args, context, cancellationToken);
    }

    /// <summary>Override to return a richer result (e.g. file changes); the default wraps <see cref="RunAsync"/>.</summary>
    protected virtual async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
        => ToolResult.Ok(call, (await RunAsync(args, context, ct)).TrimEnd());

    protected abstract Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct);

    protected static int Clamp(int? value, int fallback, int min, int max) => Math.Clamp(value ?? fallback, min, max);
}
