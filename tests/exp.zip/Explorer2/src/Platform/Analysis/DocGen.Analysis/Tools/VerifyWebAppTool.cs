using System.Diagnostics;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using DocGen.Analysis.Browser;
using DocGen.Analysis.Execution;
using DocGen.Analysis.Investigations;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

public sealed record VerificationStep(string Action, BrowserTarget Target, string? Value, string Source);

public sealed class VerificationStepResult
{
    public int Index { get; set; }
    public string Step { get; set; } = "";
    public bool Passed { get; set; }
    public string Detail { get; set; } = "";
    public string? Viewport { get; set; }
    public string? ArtifactId { get; set; }
    public long DurationMs { get; set; }
}

/// <summary>
/// Executes a verification script against a running application (a development server by serverId, or a local URL)
/// using observable browser actions, and returns structured evidence: per-step pass/fail with details, layout checks at
/// each requested viewport (horizontal overflow + screenshot), and console/network errors. The evidence is recorded
/// on the run (activities) and, when an investigation is active, in its ledger.
/// </summary>
public sealed partial class VerifyWebAppTool(AnalysisServices services) : BrowserToolBase(services), IArgumentRedactor
{
    /// <summary>Values typed into credential-like fields are masked in previews, approvals, results and evidence.</summary>
    public string RedactArguments(string argumentsJson)
    {
        try
        {
            if (System.Text.Json.Nodes.JsonNode.Parse(argumentsJson) is not System.Text.Json.Nodes.JsonObject o || o["steps"] is not System.Text.Json.Nodes.JsonArray steps)
            {
                return argumentsJson;
            }
            for (var i = 0; i < steps.Count; i++)
            {
                if (steps[i] is System.Text.Json.Nodes.JsonObject step)
                {
                    CredentialMask.MaskObject(step);
                }
                else if (steps[i]?.GetValueKind() == JsonValueKind.String)
                {
                    steps[i] = CredentialMask.MaskSentence(steps[i]!.GetValue<string>());
                }
            }
            return o.ToJsonString(CredentialMask.Display);
        }
        catch (JsonException)
        {
            return argumentsJson;
        }
    }

    public override string Name => "verify_web_app";

    public override string Description =>
        "Verifies a web application in the browser. Give serverId (from dev_server_start) or a local url, and steps — each either a sentence such as " +
        "\"open /\", \"expect heading DocGen\", \"click Runs\", \"expect text Runs\", \"type hello into Message\", \"resize mobile\", \"expect no overflow\", " +
        "\"check console\", \"screenshot home\", \"wait text Saved\", \"expect url #/runs\" — or an object {action, text|ref|selector, value}. Optional " +
        "viewports (mobile, tablet, desktop) are checked at the end (overflow + screenshot). Returns pass/fail evidence per step.";

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    public override string InputSchema => """
        {
          "type": "object",
          "properties": {
            "serverId": { "type": "string", "maxLength": 64 },
            "url": { "type": "string", "maxLength": 2000 },
            "steps": { "type": "array", "items": { "type": ["string", "object"] }, "minItems": 1, "maxItems": 60 },
            "viewports": { "type": "array", "items": { "type": "string", "enum": ["mobile", "tablet", "desktop"] }, "maxItems": 3 },
            "screenshots": { "type": "boolean", "description": "Capture a screenshot per viewport check (default true)." },
            "stopOnFailure": { "type": "boolean" }
          },
          "required": ["steps"],
          "additionalProperties": false
        }
        """;

    public override async Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken ct)
    {
        var args = ToolArguments.Parse(call);
        var baseUrl = await BaseUrlAsync(args, context, ct);
        var (cls, _, reason) = BrowserUrlPolicy.Classify(baseUrl, BrowserSettings);
        if (cls == UrlClass.Forbidden)
        {
            return new ToolRiskAssessment(ToolRiskLevel.External, Capabilities.BrowserExternal, [reason ?? ""], $"the target URL is not allowed ({reason})");
        }
        var steps = ParseSteps(args);
        var sensitive = steps.Where(s => s.Action is "type" or "click" && SensitiveWords().IsMatch($"{s.Target.Text} {s.Target.Selector} {s.Value}")).Select(s => "sensitive step: " + s.Source).ToList();
        return new ToolRiskAssessment(sensitive.Count > 0 ? ToolRiskLevel.Sensitive : ToolRiskLevel.Write,
            cls == UrlClass.Local ? Capabilities.BrowserLocal : Capabilities.BrowserExternal, sensitive.Count > 0 ? sensitive : [$"{steps.Count} browser steps on {baseUrl}"]);
    }

    private async Task<string> BaseUrlAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        if (args.GetString("serverId") is { Length: > 0 } serverId)
        {
            var servers = Services.Service<DevServerService>() ?? throw new DocGenException("SERVERS_UNAVAILABLE", "Development servers are not available.", 503);
            var server = await servers.StatusAsync(context.UserId, serverId, ct);
            if (server.Status != DevServerStatus.Running || server.Url is null)
            {
                throw new DocGenException("SERVER_NOT_RUNNING", $"Server {serverId} is {server.Status}{(server.Url is null ? " and its URL is unknown" : "")}; start it first.", 409);
            }
            return server.Url;
        }
        return args.GetString("url") ?? throw new ValidationException("Give serverId or url.");
    }

    public static List<VerificationStep> ParseSteps(ToolArguments args)
    {
        var list = new List<VerificationStep>();
        if (args.GetElement("steps") is not { ValueKind: JsonValueKind.Array } steps)
        {
            return list;
        }
        foreach (var s in steps.EnumerateArray())
        {
            if (s.ValueKind == JsonValueKind.String)
            {
                var parsed = Parse(s.GetString() ?? "");
                list.Add(parsed with { Source = CredentialMask.MaskSentence(parsed.Source) });
                continue;
            }
            string? Get(string n) => s.TryGetProperty(n, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;
            var action = (Get("action") ?? "").ToLowerInvariant();
            var source = System.Text.Json.Nodes.JsonNode.Parse(s.GetRawText()) is System.Text.Json.Nodes.JsonObject node ? MaskedJson(node) : s.GetRawText();
            list.Add(new VerificationStep(action, new BrowserTarget(Get("ref"), Get("selector"), Get("text") ?? Get("target")), Get("value") ?? Get("url"), source));
        }
        return list;
    }

    private static string MaskedJson(System.Text.Json.Nodes.JsonObject node)
    {
        CredentialMask.MaskObject(node);
        return node.ToJsonString(CredentialMask.Display);
    }

    /// <summary>Parses the sentence forms. Unknown sentences become an "unknown" step that fails with a clear message.</summary>
    public static VerificationStep Parse(string sentence)
    {
        var s = sentence.Trim().TrimEnd('.');
        Match m;
        if ((m = Regex.Match(s, @"^(?:open|go to|goto|navigate to)\s+(.+)$", RegexOptions.IgnoreCase)).Success) return new("open", new(), Unquote(m.Groups[1].Value), sentence);
        if ((m = Regex.Match(s, @"^(?:click|press|tap)\s+(?:on\s+)?(.+)$", RegexOptions.IgnoreCase)).Success) return new("click", new(Text: Unquote(m.Groups[1].Value)), null, sentence);
        if ((m = Regex.Match(s, @"^type\s+(.+?)\s+into\s+(.+)$", RegexOptions.IgnoreCase)).Success) return new("type", new(Text: Unquote(m.Groups[2].Value)), Unquote(m.Groups[1].Value), sentence);
        if ((m = Regex.Match(s, @"^(?:expect|confirm|check)\s+heading\s+(.+?)(?:\s+(?:is shown|loads|exists))?$", RegexOptions.IgnoreCase)).Success) return new("expect_heading", new(Text: Unquote(m.Groups[1].Value)), null, sentence);
        if ((m = Regex.Match(s, @"^(?:expect|confirm|check)\s+no\s+text\s+(.+)$", RegexOptions.IgnoreCase)).Success) return new("expect_no_text", new(), Unquote(m.Groups[1].Value), sentence);
        if ((m = Regex.Match(s, @"^(?:expect|confirm|check)\s+(?:text\s+)?(.+?)\s+(?:page\s+)?(?:loads|is shown|appears|is visible)$", RegexOptions.IgnoreCase)).Success) return new("expect_text", new(), Unquote(m.Groups[1].Value), sentence);
        if ((m = Regex.Match(s, @"^(?:expect|confirm|check)\s+text\s+(.+)$", RegexOptions.IgnoreCase)).Success) return new("expect_text", new(), Unquote(m.Groups[1].Value), sentence);
        if ((m = Regex.Match(s, @"^(?:expect|confirm|check)\s+url\s+(.+)$", RegexOptions.IgnoreCase)).Success) return new("expect_url", new(), Unquote(m.Groups[1].Value), sentence);
        if ((m = Regex.Match(s, @"^(?:expect|confirm|check)\s+(?:element|selector)\s+(.+)$", RegexOptions.IgnoreCase)).Success) return new("expect_element", new(Selector: Unquote(m.Groups[1].Value)), null, sentence);
        if (Regex.IsMatch(s, @"^(?:expect|confirm|check)\s+no\s+(?:horizontal\s+)?overflow$", RegexOptions.IgnoreCase)) return new("expect_no_overflow", new(), null, sentence);
        if ((m = Regex.Match(s, @"^(?:expect|confirm|check)\s+(?:the\s+)?sidebar\s+(collapses|is collapsed|is hidden|is visible|is shown)$", RegexOptions.IgnoreCase)).Success) return new("expect_sidebar", new(), m.Groups[1].Value.Contains("visible") || m.Groups[1].Value.Contains("shown") ? "visible" : "hidden", sentence);
        if ((m = Regex.Match(s, @"^(?:resize|viewport|set viewport)\s+(?:to\s+)?(mobile|tablet|desktop|responsive|default)$", RegexOptions.IgnoreCase)).Success) return new("resize", new(), m.Groups[1].Value.ToLowerInvariant(), sentence);
        if (Regex.IsMatch(s, @"^(?:check|read)\s+(?:the\s+)?console(?:\s+errors)?$", RegexOptions.IgnoreCase)) return new("check_console", new(), null, sentence);
        if ((m = Regex.Match(s, @"^(?:take\s+)?screenshot(?:\s+(.+))?$", RegexOptions.IgnoreCase)).Success) return new("screenshot", new(), m.Groups[1].Success ? Unquote(m.Groups[1].Value) : null, sentence);
        if ((m = Regex.Match(s, @"^wait\s+(?:for\s+)?text\s+(.+)$", RegexOptions.IgnoreCase)).Success) return new("wait_text", new(), Unquote(m.Groups[1].Value), sentence);
        if (Regex.IsMatch(s, @"^(?:reload|refresh)$", RegexOptions.IgnoreCase)) return new("reload", new(), null, sentence);
        if (Regex.IsMatch(s, @"^(?:go\s+)?back$", RegexOptions.IgnoreCase)) return new("back", new(), null, sentence);
        return new("unknown", new(), null, sentence);
    }

    private static string Unquote(string v) => v.Trim().Trim('"', '\'', '“', '”');

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var baseUrl = await BaseUrlAsync(args, context, ct);
        var steps = ParseSteps(args);
        var stopOnFailure = args.GetBool("stopOnFailure") ?? false;
        var screenshots = args.GetBool("screenshots") ?? true;
        var browser = Browser;
        var user = context.UserId;
        var results = new List<VerificationStepResult>();
        var activities = new List<ActivityRecord>();
        var tab = await browser.OpenAsync(user, context.RunId, null, newTab: true, ct);
        activities.Add(Activity("browser_opened", $"Opened {tab.TabId} for verification of {baseUrl}", null, ("tabId", tab.TabId)));
        string? viewportLabel = null;
        var consoleErrors = 0;

        async Task Run(int index, string label, Func<Task<(bool, string, string?)>> action)
        {
            var sw = Stopwatch.StartNew();
            var r = new VerificationStepResult { Index = index, Step = label, Viewport = viewportLabel };
            try
            {
                var (passed, detail, artifact) = await action();
                r.Passed = passed;
                r.Detail = detail;
                r.ArtifactId = artifact;
            }
            catch (DocGenException ex)
            {
                r.Passed = false;
                r.Detail = ex.Message;
            }
            r.DurationMs = sw.ElapsedMilliseconds;
            results.Add(r);
        }

        string Resolve(string target) => Uri.TryCreate(target, UriKind.Absolute, out var abs) && abs.Scheme is "http" or "https" ? target
            : new Uri(new Uri(baseUrl), target).ToString();

        var i = 0;
        foreach (var step in steps)
        {
            i++;
            if (stopOnFailure && results.Any(r => !r.Passed))
            {
                results.Add(new VerificationStepResult { Index = i, Step = step.Source, Passed = false, Detail = "skipped (an earlier step failed)" });
                continue;
            }
            await Run(i, step.Source, async () =>
            {
                switch (step.Action)
                {
                    case "open":
                    {
                        var url = Resolve(step.Value ?? "/");
                        var (cls, _, reason) = BrowserUrlPolicy.Classify(url, BrowserSettings);
                        if (cls != UrlClass.Local && !Uri.Compare(new Uri(url), new Uri(baseUrl), UriComponents.SchemeAndServer, UriFormat.Unescaped, StringComparison.OrdinalIgnoreCase).Equals(0))
                        {
                            return (false, $"only the application under test can be opened here ({reason ?? "external host"})", null);
                        }
                        var t = await browser.NavigateAsync(user, tab.TabId, url, ct);
                        activities.Add(Activity("browser_navigated", $"Opened {t.Url}", t.Title, ("tabId", t.TabId), ("url", t.Url)));
                        return (true, $"loaded {t.Url} — \"{t.Title}\"", null);
                    }
                    case "click":
                    {
                        var info = await browser.ClickAsync(user, tab.TabId, step.Target, ct);
                        if (info.Sensitive.Count > 0)
                        {
                            // Should not be reachable: the assessment asked for approval. Recorded for the audit trail.
                            activities.Add(Activity("browser_sensitive_action", $"Sensitive click approved: {info.Name}", string.Join(", ", info.Sensitive)));
                        }
                        var url = browser.CurrentUrl(user, tab.TabId);
                        activities.Add(Activity("browser_clicked", $"Clicked {info.Role} \"{Clip(info.Name, 60)}\"", url, ("ref", info.Ref)));
                        return (true, $"clicked {info.Role} \"{Clip(info.Name, 80)}\"; now at {url}", null);
                    }
                    case "type":
                    {
                        var info = await browser.TypeAsync(user, tab.TabId, step.Target, step.Value ?? "", true, false, ct);
                        activities.Add(Activity("browser_typed", $"Typed into {info.Role} \"{Clip(info.Name, 60)}\""));
                        return (true, $"typed into {info.Role} \"{Clip(info.Name, 80)}\"", null);
                    }
                    case "expect_text":
                    case "wait_text":
                    {
                        var (met, detail) = await browser.WaitAsync(user, tab.TabId, "text", step.Value, step.Action == "wait_text" ? 15 : 8, ct);
                        return (met, met ? $"text \"{Clip(step.Value ?? "", 80)}\" is present ({detail})" : $"text \"{Clip(step.Value ?? "", 80)}\" not found ({detail})", null);
                    }
                    case "expect_no_text":
                    {
                        var (met, detail) = await browser.WaitAsync(user, tab.TabId, "textGone", step.Value, 3, ct);
                        return (met, met ? $"text \"{Clip(step.Value ?? "", 80)}\" is absent" : $"text \"{Clip(step.Value ?? "", 80)}\" is still present ({detail})", null);
                    }
                    case "expect_heading":
                    {
                        var want = step.Target.Text ?? "";
                        var sw = Stopwatch.StartNew();
                        while (true)
                        {
                            var snapshot = await browser.ReadPageAsync(user, tab.TabId, false, 400, ct);
                            var heading = snapshot.Lines.FirstOrDefault(l => l.TrimStart().StartsWith("- heading \"", StringComparison.Ordinal) && l.Contains(want, StringComparison.OrdinalIgnoreCase));
                            if (heading is not null)
                            {
                                return (true, "found " + heading.Trim().TrimStart('-', ' '), null);
                            }
                            if (sw.Elapsed > TimeSpan.FromSeconds(8))
                            {
                                var headings = snapshot.Lines.Where(l => l.Contains("heading \"", StringComparison.Ordinal)).Select(l => l.Trim().TrimStart('-', ' ')).Take(6);
                                return (false, $"no heading containing \"{want}\"; headings: {string.Join("; ", headings)}", null);
                            }
                            await Task.Delay(300, ct);
                        }
                    }
                    case "expect_url":
                    {
                        var (met, detail) = await browser.WaitAsync(user, tab.TabId, "url", step.Value, 8, ct);
                        var url = browser.CurrentUrl(user, tab.TabId);
                        return (met, met ? $"URL {url} contains \"{step.Value}\"" : $"URL {url} does not contain \"{step.Value}\" ({detail})", null);
                    }
                    case "expect_element":
                    {
                        var (met, detail) = await browser.WaitAsync(user, tab.TabId, "selector", step.Target.Selector, 8, ct);
                        return (met, met ? $"{step.Target.Selector} is visible" : $"{step.Target.Selector} is not visible ({detail})", null);
                    }
                    case "expect_no_overflow":
                        return await OverflowAsync(browser, user, tab.TabId, ct);
                    case "expect_sidebar":
                    {
                        var state = await SidebarAsync(browser, user, tab.TabId, ct);
                        var ok = state.StartsWith(step.Value ?? "hidden", StringComparison.Ordinal);
                        return (ok, $"sidebar is {state}", null);
                    }
                    case "resize":
                    {
                        var preset = step.Value is "responsive" or "default" ? null : BrowserViewport.Presets[step.Value!];
                        await browser.SetViewportAsync(user, tab.TabId, preset, ct);
                        viewportLabel = preset?.ToString();
                        activities.Add(Activity("browser_viewport_changed", preset is null ? "Cleared viewport emulation" : $"Viewport {preset}", null, ("preset", step.Value)));
                        return (true, preset is null ? "viewport emulation cleared" : $"viewport {preset}", null);
                    }
                    case "check_console":
                    {
                        var (console, allNetwork) = await browser.DiagnosticsAsync(user, tab.TabId, clear: true, ct);
                        var errors = console.Where(c => c.Level == "error" && !BrowserService.IsNoise(c.Url, c.Text)).ToList();
                        var network = allNetwork.Where(n => !BrowserService.IsNoise(n.Url, null)).ToList();
                        consoleErrors += errors.Count;
                        activities.Add(Activity("browser_console_checked", errors.Count == 0 ? "No console errors" : $"{errors.Count} console errors", null, ("errors", errors.Count.ToString())));
                        var detail = errors.Count == 0 && network.Count == 0 ? "no console errors, no failed requests"
                            : $"{errors.Count} console errors, {network.Count} failed requests: " + string.Join("; ", errors.Select(e => Clip(e.Text, 160)).Concat(network.Select(n => $"{(n.Status is { } st ? "HTTP " + st : n.Error)} {Clip(n.Url, 100)}")).Take(5));
                        return (errors.Count == 0 && network.Count == 0, detail, null);
                    }
                    case "screenshot":
                    {
                        var shot = await BrowserScreenshotTool.CaptureAsync(Services, browser, context, tab.TabId, false, step.Value is null ? null : $"Verification — {step.Value}", step.Source, ct);
                        activities.Add(shot.Activity);
                        return (true, shot.Summary, shot.ArtifactId);
                    }
                    case "reload":
                    case "back":
                    {
                        var t = await browser.HistoryAsync(user, tab.TabId, step.Action, ct);
                        return (true, $"{step.Action}: {t.Url}", null);
                    }
                    default:
                        return (false, "unrecognised step; use sentences like \"open /\", \"click Runs\", \"expect text X\", \"resize mobile\", \"check console\" or an object {action, text, value}", null);
                }
            });
        }

        // Viewport layout checks.
        foreach (var name in args.GetElement("viewports") is { ValueKind: JsonValueKind.Array } vps ? vps.EnumerateArray().Select(v => v.GetString() ?? "") : [])
        {
            i++;
            var preset = BrowserViewport.Presets[name];
            viewportLabel = preset.ToString();
            await Run(i, $"layout at {name}", async () =>
            {
                await browser.SetViewportAsync(user, tab.TabId, preset, ct);
                activities.Add(Activity("browser_viewport_changed", $"Viewport {preset}", null, ("preset", name)));
                var (ok, detail, _) = await OverflowAsync(browser, user, tab.TabId, ct);
                string? artifact = null;
                if (screenshots)
                {
                    var shot = await BrowserScreenshotTool.CaptureAsync(Services, browser, context, tab.TabId, false, $"Verification — {name}", "layout check", ct);
                    activities.Add(shot.Activity);
                    artifact = shot.ArtifactId;
                    detail += "; screenshot artifact " + artifact;
                }
                return (ok, detail, artifact);
            });
        }
        if (args.GetElement("viewports") is { ValueKind: JsonValueKind.Array })
        {
            await browser.SetViewportAsync(user, tab.TabId, null, ct);
            activities.Add(Activity("browser_viewport_changed", "Cleared viewport emulation (back to the browser window's size)"));
        }
        var (finalConsole, finalNetworkAll) = await browser.DiagnosticsAsync(user, tab.TabId, clear: false, ct);
        finalConsole = finalConsole.Where(c => !BrowserService.IsNoise(c.Url, c.Text)).ToList();
        var finalNetwork = finalNetworkAll.Where(n => !BrowserService.IsNoise(n.Url, null)).ToList();
        consoleErrors += finalConsole.Count(c => c.Level == "error");

        var passed = results.Count(r => r.Passed);
        var sb = new StringBuilder($"Browser verification of {baseUrl}: {passed}/{results.Count} steps passed{(consoleErrors > 0 ? $", {consoleErrors} console errors" : ", no console errors")}\n");
        foreach (var r in results)
        {
            sb.AppendLine($"{(r.Passed ? "✓" : "✗")} {r.Index}. {Clip(r.Step, 120)}{(r.Viewport is null ? "" : $" [{r.Viewport}]")} — {Clip(r.Detail, 300)} ({r.DurationMs} ms)");
        }
        foreach (var c in finalConsole.Where(c => c.Level == "error").Take(5))
        {
            sb.AppendLine($"  console error: {Clip(c.Text, 200)}");
        }
        foreach (var n in finalNetwork.Take(5))
        {
            sb.AppendLine($"  failed request: {(n.Status is { } s ? "HTTP " + s : n.Error)} {Clip(n.Url, 120)}");
        }
        var summary = sb.ToString().TrimEnd();
        activities.Add(Activity("browser_verification", $"Browser verification: {passed}/{results.Count} passed", Clip(summary, 1500), ("baseUrl", baseUrl), ("passed", passed.ToString()), ("total", results.Count.ToString())));

        // Evidence for the investigation (recorded by DocGen, not claimed by the model).
        if (context.ConversationId is not null && await Services.Investigations.GetActiveForConversationAsync(context.UserId, context.ConversationId, CancellationToken.None) is { } investigation)
        {
            await Services.Investigations.AddEvidenceAsync(context.UserId, investigation.Id, EvidenceKinds.Result, Clip(summary, 3900), "browser:" + baseUrl, null, context.RunId, automatic: true, CancellationToken.None);
        }
        return new ToolResult
        {
            ToolCallId = call.Id, ToolName = call.Name, Success = passed == results.Count, Content = summary + TabContext(user, tab.TabId),
            Error = passed == results.Count ? null : $"{results.Count - passed} verification steps failed", Activities = activities,
        };
    }

    private static async Task<(bool, string, string?)> OverflowAsync(BrowserService browser, string user, string tabId, CancellationToken ct)
    {
        // Horizontal overflow: the document is wider than the viewport.
        var metrics = await browser.EvaluateMetricsAsync(user, tabId, ct);
        var ok = metrics.ScrollWidth <= metrics.ClientWidth + 1;
        return (ok, ok ? $"no horizontal overflow (content {metrics.ScrollWidth}px ≤ viewport {metrics.ClientWidth}px)" : $"horizontal overflow: content {metrics.ScrollWidth}px > viewport {metrics.ClientWidth}px (widest: {metrics.Widest})", null);
    }

    private static async Task<string> SidebarAsync(BrowserService browser, string user, string tabId, CancellationToken ct)
        => await browser.SidebarStateAsync(user, tabId, ct);

    [GeneratedRegex(@"password|passwd|credit|card|pay|buy|purchase|checkout|delete|remove|destroy|transfer|withdraw", RegexOptions.IgnoreCase)]
    private static partial Regex SensitiveWords();
}
