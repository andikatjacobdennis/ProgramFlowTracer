using System.Text;
using DocGen.Analysis.Commands;
using DocGen.Analysis.Indexing;
using DocGen.Analysis.Investigations;
using DocGen.Analysis.Repositories;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Options;
using DocGen.Tools.Infrastructure;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Tools;

/// <summary>Services shared by the analysis tools.</summary>
public sealed class AnalysisServices(
    RepositoryCatalog repositories,
    CodeIndexService indexes,
    InvestigationService investigations,
    CommandRunner commands,
    IBlobStore blobs,
    IOptionsMonitor<AnalysisOptions> options,
    IOptionsMonitor<AgentOptions> agentOptions,
    IOptions<DocGenOptions> docgenOptions,
    DocGen.Analysis.Execution.ExecutableResolver? executables = null,
    IServiceProvider? serviceProvider = null)
{
    private DocGen.Analysis.Execution.ExecutableResolver? _executables = executables;

    /// <summary>Allow-listed executables and PowerShell detection.</summary>
    public DocGen.Analysis.Execution.ExecutableResolver Executables
        => _executables ??= new DocGen.Analysis.Execution.ExecutableResolver(new StaticOptionsMonitor<ExecutionOptions>(new ExecutionOptions()));

    /// <summary>Optional services registered by the host (dev servers, browser automation).</summary>
    public T? Service<T>() where T : class => serviceProvider?.GetService(typeof(T)) as T;

    /// <summary>DocGen data directory (scratch copies live under data/scratch).</summary>
    public string DataDirectory => Path.GetFullPath(docgenOptions.Value.DataDirectory);

    public RepositoryCatalog Repositories => repositories;
    public CodeIndexService Indexes => indexes;
    public InvestigationService Investigations => investigations;
    public CommandRunner Commands => commands;
    public IBlobStore Blobs => blobs;
    public AnalysisOptions Options => options.CurrentValue;
    public AgentOptions AgentOptions => agentOptions.CurrentValue;

    /// <summary>
    /// The chat's own folder: the user's workspace, or the repository the user selected as this chat's working folder
    /// (resolved on the server). Routine work there runs without a prompt in the balanced approval mode.
    /// </summary>
    public static bool IsChatFolder(RepositoryHandle repo, ToolExecutionContext context)
        => repo.Source == "workspace"
           || context.WorkingFolder is { IsWorkspace: false } folder && string.Equals(folder.Name, repo.Name, StringComparison.OrdinalIgnoreCase);

    public async Task<RepositoryHandle> RepositoryAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
        => await repositories.ResolveAsync(context.UserId, await RepositoryNameAsync(args, context, ct), ct);

    /// <summary>
    /// The repository a tool call targets: the explicit "repository" argument; otherwise the repository selected in
    /// the UI (when this user may access it); otherwise null, meaning the workspace. Models often omit the argument,
    /// and silently searching the empty workspace instead of the repository being discussed wastes the whole run.
    /// </summary>
    public async Task<string?> RepositoryNameAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        if (args.GetString("repository") is { Length: > 0 } requested)
        {
            return requested;
        }
        if (context.Repository is { Length: > 0 } selected)
        {
            var accessible = await repositories.ListAsync(context.UserId, ct);
            var name = accessible.FirstOrDefault(r => string.Equals(r.Name, selected, StringComparison.OrdinalIgnoreCase))?.Name;
            // The model often creates a project in the workspace (file_write always writes there) and then omits
            // "repository" on the next edit/build: a path that exists only in the workspace means the workspace.
            if (name is not null && await OnlyInWorkspaceAsync(args, context, name, ct))
            {
                return null;
            }
            return name;
        }
        return null;
    }

    private static readonly string[] PathArguments = ["path", "target", "project"];

    private async Task<bool> OnlyInWorkspaceAsync(ToolArguments args, ToolExecutionContext context, string selected, CancellationToken ct)
    {
        var relative = PathArguments.Select(args.GetString).FirstOrDefault(p => !string.IsNullOrWhiteSpace(p));
        if (relative is null || Path.IsPathFullyQualified(relative) || selected.Equals(RepositoryCatalog.WorkspaceName, StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }
        static bool Exists(RepositoryHandle repo, string path)
        {
            try
            {
                var full = repo.Resolve(path);
                return File.Exists(full) || Directory.Exists(full);
            }
            catch (Exception ex) when (ex is ValidationException or ForbiddenException or ArgumentException or IOException)
            {
                return false;
            }
        }
        try
        {
            var selectedRepo = await repositories.ResolveAsync(context.UserId, selected, ct);
            if (Exists(selectedRepo, relative))
            {
                return false;
            }
            return Exists(await repositories.ResolveAsync(context.UserId, RepositoryCatalog.WorkspaceName, ct), relative);
        }
        catch (Exception ex) when (ex is NotFoundException or ForbiddenException or ValidationException)
        {
            return false;
        }
    }

    /// <summary>The accessible repository whose root contains <paramref name="fullPath"/> (the deepest one), or null.</summary>
    public async Task<RepositoryHandle?> RepositoryContainingAsync(string fullPath, ToolExecutionContext context, CancellationToken ct)
    {
        var path = Path.GetFullPath(fullPath).TrimEnd('\\', '/');
        return (await repositories.ListAsync(context.UserId, ct))
            .Where(r => Path.GetFullPath(r.Root).TrimEnd('\\', '/') is var root && (path.Equals(root, StringComparison.OrdinalIgnoreCase) || path.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)))
            .OrderByDescending(r => r.Root.Length).FirstOrDefault();
    }

    public async Task<(RepositoryHandle Repo, CodeIndex Index)> IndexAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var repo = await RepositoryAsync(args, context, ct);
        return (repo, await indexes.GetAsync(repo, ct));
    }

    /// <summary>Adds files to the active investigation's inspected set (no-op without one).</summary>
    public async Task TrackInspectedAsync(ToolExecutionContext context, string repository, IEnumerable<string> files, CancellationToken ct)
    {
        if (context.ConversationId is null)
        {
            return;
        }
        var list = files.Distinct(StringComparer.OrdinalIgnoreCase).Select(f => repository == RepositoryCatalog.WorkspaceName ? f : $"{repository}:{f}").ToList();
        if (list.Count == 0)
        {
            return;
        }
        if (await investigations.GetActiveForConversationAsync(context.UserId, context.ConversationId, ct) is { } active)
        {
            await investigations.TrackAsync(context.UserId, active.Id, list, countToolCall: false, context.RunId, CancellationToken.None);
        }
    }

    /// <summary>
    /// Resolves a data source for log/JSON tools: a blob or runtime-object reference ("ref"), or a file ("path") in a
    /// repository (default: the user's workspace). Returns an absolute path that is guaranteed to be inside an allowed root.
    /// </summary>
    public async Task<(string FullPath, string Label)> SourceAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct, string refArg = "ref", string pathArg = "path")
    {
        if (args.GetString(refArg) is { Length: > 0 } reference)
        {
            var path = blobs.GetContentPath(context.UserId, reference) ?? throw new NotFoundException("Blob");
            return (path, reference);
        }
        var repo = await RepositoryAsync(args, context, ct);
        var relative = args.GetString(pathArg) ?? throw new ValidationException($"Provide '{pathArg}' (a file in the repository) or '{refArg}' (a blob:// reference).");
        var full = repo.Resolve(relative);
        if (!File.Exists(full))
        {
            throw new NotFoundException("File");
        }
        await TrackInspectedAsync(context, repo.Name, [repo.Relative(full)], ct);
        return (full, $"{repo.Name}:{repo.Relative(full)}");
    }

    /// <summary>Reads 1-based lines [start, end] of a repository file with line numbers (bounded).</summary>
    public static string ReadNumberedLines(string fullPath, int start, int end, int maxLines, out int totalLines)
    {
        var sb = new StringBuilder();
        var n = 0;
        var emitted = 0;
        start = Math.Max(1, start);
        foreach (var line in File.ReadLines(fullPath))
        {
            n++;
            if (n < start || n > end)
            {
                continue;
            }
            if (emitted >= maxLines)
            {
                continue;
            }
            sb.Append(n.ToString().PadLeft(5)).Append("  ").AppendLine(line.Length > 400 ? line[..400] + "…" : line);
            emitted++;
        }
        totalLines = n;
        return sb.ToString();
    }

    public static string Location(SymbolRecord s) => $"{s.File}:{s.StartLine}";

    public static string Describe(SymbolRecord s)
        => $"{s.Kind} {s.FullName} — {s.File}:{s.StartLine}-{s.EndLine}{(string.IsNullOrEmpty(s.Project) ? "" : $" [{s.Project}]")}";

    public static string Clip(string? value, int max) => string.IsNullOrEmpty(value) ? "" : value.Length <= max ? value : value[..max] + "…";
}

/// <summary>Fixed options (used when no host configuration is available, e.g. in tools constructed by tests).</summary>
public sealed class StaticOptionsMonitor<T>(T value) : IOptionsMonitor<T>
{
    public T CurrentValue => value;
    public T Get(string? name) => value;
    public IDisposable? OnChange(Action<T, string?> listener) => null;
}
