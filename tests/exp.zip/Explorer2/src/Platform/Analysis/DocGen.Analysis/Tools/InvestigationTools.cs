using System.Text;
using System.Text.Json;
using DocGen.Analysis.Investigations;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

internal static class InvestigationToolHelpers
{
    public static async Task<Investigation> ActiveAsync(AnalysisServices services, ToolExecutionContext context, CancellationToken ct)
    {
        if (context.ConversationId is null)
        {
            throw new ValidationException("Investigations belong to a conversation.");
        }
        return await services.Investigations.GetActiveForConversationAsync(context.UserId, context.ConversationId, ct)
               ?? throw new ValidationException("No active investigation in this conversation. Start one with investigation_start.");
    }

    public static List<string> StringArray(ToolArguments args, string name)
        => args.GetElement(name) is { ValueKind: JsonValueKind.Array } array
            ? array.EnumerateArray().Where(e => e.ValueKind == JsonValueKind.String).Select(e => e.GetString()!).Take(100).ToList()
            : [];
}

public sealed class InvestigationStartTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "investigation_start";

    public override string Description =>
        "Starts Bug Investigation mode for this conversation: records the symptom and creates a durable evidence ledger. From then on DocGen pins the investigation memory " +
        "into every model call and blocks source edits until a root cause is confirmed with evidence. Use it for hard bugs: the symptom is far from the likely cause, " +
        "several causes are plausible, the bug is intermittent, or earlier fixes failed. Do not use it for a clear, local bug whose cause the code shows directly: " +
        "reproduce that with a failing test, fix it, and run the tests.";

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "symptom": { "type": "string", "minLength": 3, "maxLength": 20000 },
            "title": { "type": "string", "maxLength": 120 }
          },
          "required": ["symptom"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        if (context.ConversationId is null)
        {
            throw new ValidationException("Investigations belong to a conversation.");
        }
        var repo = await Services.RepositoryAsync(args, context, ct);
        var investigation = await Services.Investigations.CreateAsync(context.UserId, args.RequireString("symptom"), args.GetString("title"), repo.Name, context.ConversationId, context.ProjectId, ct);
        if (context.RunId is not null)
        {
            await Services.Investigations.TrackAsync(context.UserId, investigation.Id, [], false, context.RunId, ct);
        }
        return $"Investigation {investigation.Id} started.\n" + InvestigationService.BuildMemory(investigation);
    }
}

public sealed class InvestigationRecordTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "investigation_record";

    public override string Description =>
        "Records an item in the active investigation. kind: fact | experiment | result (evidence ledger), hypothesis (new hypothesis; summary = statement, source = location), " +
        "reproduction (status reproduced|notReproduced|notReproducible, optional commandId), fix (summary, rationale, files), verification (commandId of a finished build/test — " +
        "pass/fail is taken from the command, not from you), regression (risk assessment), uncertainty (what remains unknown).";

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    public override string InputSchema => """
        {
          "type": "object",
          "properties": {
            "kind": { "type": "string", "enum": ["fact", "experiment", "result", "hypothesis", "reproduction", "fix", "verification", "regression", "uncertainty"] },
            "summary": { "type": "string", "maxLength": 4000 },
            "source": { "type": "string", "maxLength": 300, "description": "file:line, symbol, command:{id} or blob reference supporting the item." },
            "hypothesisId": { "type": "string", "maxLength": 10, "description": "For experiment/result evidence: the hypothesis it tests (adds it as supporting evidence)." },
            "status": { "type": "string", "enum": ["reproduced", "notReproduced", "notReproducible"] },
            "commandId": { "type": "string", "maxLength": 64 },
            "rationale": { "type": "string", "maxLength": 2000 },
            "files": { "type": "array", "items": { "type": "string", "maxLength": 400 }, "maxItems": 50 }
          },
          "required": ["kind"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var active = await InvestigationToolHelpers.ActiveAsync(Services, context, ct);
        var kind = args.RequireString("kind");
        var summary = args.GetString("summary") ?? "";
        var service = Services.Investigations;
        Investigation updated;
        switch (kind)
        {
            case EvidenceKinds.Fact or EvidenceKinds.Experiment or EvidenceKinds.Result:
                updated = await service.AddEvidenceAsync(context.UserId, active.Id, kind, Require(summary), args.GetString("source"), args.GetString("hypothesisId"), context.RunId, false, ct);
                return $"Recorded {updated.Evidence[^1].Id} ({kind.ToUpperInvariant()}).";
            case "hypothesis":
                updated = await service.AddHypothesisAsync(context.UserId, active.Id, Require(summary), args.GetString("source"), ct);
                return $"Recorded hypothesis {updated.Hypotheses[^1].Id} [Open]. Test it with an experiment and link results via hypothesisId.";
            case "reproduction":
                var status = args.GetString("status") ?? throw new ValidationException("reproduction needs 'status'.");
                updated = await service.SetReproductionAsync(context.UserId, active.Id, status, summary, args.GetString("commandId"), context.RunId, ct);
                return $"Reproduction recorded: {status}.";
            case "fix":
                updated = await service.RecordFixAsync(context.UserId, active.Id, Require(summary), args.GetString("rationale"), InvestigationToolHelpers.StringArray(args, "files"), 0, 0, ct);
                return "Fix recorded. Verify it: run_tests (narrow first), then investigation_record kind=verification commandId=…";
            case "verification":
                var commandId = args.GetString("commandId") ?? throw new ValidationException("verification needs 'commandId' of a finished build/test command.");
                updated = await service.RecordVerificationAsync(context.UserId, active.Id, commandId, ct);
                var last = updated.Verification[^1];
                return $"Verification {(last.Passed ? "PASSED" : "FAILED")} (from the command record): {last.Summary}";
            case "regression":
                await service.UpdateAsync(context.UserId, active.Id, i =>
                {
                    i.RegressionRisk = InvestigationService.Clip(Require(summary), 4000);
                    i.Timeline.Add(new TimelineEntry { Kind = "regression", Text = InvestigationService.Clip(summary, 160) });
                }, ct);
                return "Regression risk recorded.";
            case "uncertainty":
                await service.UpdateAsync(context.UserId, active.Id, i => i.RemainingUncertainty = InvestigationService.Clip(Require(summary), 4000), ct);
                return "Remaining uncertainty recorded.";
            default:
                throw new ValidationException("Unknown kind.");
        }
    }

    private static string Require(string summary) => summary.Trim().Length > 0 ? summary : throw new ValidationException("'summary' is required for this kind.");
}

public sealed class HypothesisUpdateTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "hypothesis_update";

    public override string Description =>
        "Changes a hypothesis status with linked evidence: Supported (needs supporting evidence), Weakened/Rejected (need contradicting evidence), Confirmed (needs a reproduction, " +
        "at least one supporting experiment/result, and a counterfactual_run that removed the failure — or, only when that is impossible, a 'limitation' explaining why). " +
        "Confirming sets the root cause and unlocks production source edits. DocGen rejects changes that break these rules.";

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    public override string InputSchema => """
        {
          "type": "object",
          "properties": {
            "hypothesisId": { "type": "string", "minLength": 2, "maxLength": 10 },
            "status": { "type": "string", "enum": ["Open", "Supported", "Weakened", "Rejected", "Confirmed"] },
            "supporting": { "type": "array", "items": { "type": "string", "maxLength": 10 }, "maxItems": 50 },
            "contradicting": { "type": "array", "items": { "type": "string", "maxLength": 10 }, "maxItems": 50 },
            "reason": { "type": "string", "minLength": 3, "maxLength": 1000 },
            "limitation": { "type": "string", "maxLength": 2000, "description": "Only when a counterfactual experiment is impossible: why (documented in the report)." }
          },
          "required": ["hypothesisId", "status", "reason"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var active = await InvestigationToolHelpers.ActiveAsync(Services, context, ct);
        var status = Enum.Parse<HypothesisStatus>(args.RequireString("status"));
        var id = args.RequireString("hypothesisId");
        var updated = await Services.Investigations.UpdateHypothesisAsync(context.UserId, active.Id, id, status,
            InvestigationToolHelpers.StringArray(args, "supporting"), InvestigationToolHelpers.StringArray(args, "contradicting"), args.RequireString("reason"), ct, args.GetString("limitation"));
        return status == HypothesisStatus.Confirmed
            ? $"{id} Confirmed. Root cause recorded: {updated.RootCause?.Statement}. Source edits are now allowed (still approval-gated). Make the smallest fix, then verify."
            : $"{id} is now {status}.";
    }
}

public sealed class InvestigationStatusTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "investigation_status";

    public override string Description => "Shows the active investigation's memory, or with report=true generates the Root Cause Report (Symptom, Reproduction, Root Cause, Evidence, Fix, Files Changed, Verification, Regression Risk, Remaining Uncertainty).";

    public override string InputSchema => """
        {
          "type": "object",
          "properties": { "report": { "type": "boolean" } },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var active = await InvestigationToolHelpers.ActiveAsync(Services, context, ct);
        if (args.GetBool("report") != true)
        {
            return InvestigationService.BuildMemory(active);
        }
        var report = InvestigationService.BuildReport(active);
        await Services.Investigations.UpdateAsync(context.UserId, active.Id, i => i.Report = report, ct);
        return report;
    }
}

public sealed class SourceEditTool(AnalysisServices services) : AnalysisTool(services), IDynamicRiskTool
{
    /// <summary>Edits in the chat's own folder (workspace or selected working folder) are routine; other repositories ask.</summary>
    public async Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken ct)
        => new(ToolRiskLevel.Write, Routine: AnalysisServices.IsChatFolder(await Services.RepositoryAsync(ToolArguments.Parse(call), context, ct), context));

    public override string Name => "source_edit";

    public override string Description =>
        "Replaces an exact snippet in a repository source file (minimal edit; the snippet must occur exactly once unless 'occurrence' is given). Requires approval and a " +
        "repository that allows edits; blocked in an investigation until the root cause is confirmed. Line endings and encoding are preserved.";

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "path": { "type": "string", "minLength": 1, "maxLength": 400 },
            "oldText": { "type": "string", "minLength": 1, "maxLength": 20000 },
            "newText": { "type": "string", "maxLength": 20000 },
            "occurrence": { "type": "integer", "minimum": 1, "maximum": 1000 }
          },
          "required": ["path", "oldText", "newText"],
          "additionalProperties": false
        }
        """;

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
        => throw new NotSupportedException();

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var repo = await Services.RepositoryAsync(args, context, ct);
        if (!repo.AllowWrite)
        {
            throw new ForbiddenException($"Edits are not enabled for repository '{repo.Name}'.");
        }
        var full = repo.Resolve(args.RequireString("path"));
        if (!File.Exists(full))
        {
            throw new NotFoundException("File");
        }
        if (new FileInfo(full).Length > 4 * 1024 * 1024)
        {
            throw new ValidationException("The file is too large to edit with source_edit.");
        }
        var bytes = await File.ReadAllBytesAsync(full, ct);
        var hasBom = bytes.Length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF;
        var original = new UTF8Encoding(false).GetString(bytes, hasBom ? 3 : 0, bytes.Length - (hasBom ? 3 : 0));
        var newline = original.Contains("\r\n", StringComparison.Ordinal) ? "\r\n" : "\n";
        string Normalize(string s) => s.Replace("\r\n", "\n").Replace("\n", newline);
        var oldText = Normalize(args.RequireString("oldText"));
        var newText = Normalize(args.GetString("newText") ?? "");

        var positions = new List<int>();
        for (var at = original.IndexOf(oldText, StringComparison.Ordinal); at >= 0; at = original.IndexOf(oldText, at + 1, StringComparison.Ordinal))
        {
            positions.Add(at);
        }
        if (positions.Count == 0)
        {
            throw new ValidationException("oldText was not found in the file (it must match exactly, including whitespace). Read the current source first.");
        }
        var occurrence = args.GetInt("occurrence");
        if (positions.Count > 1 && occurrence is null)
        {
            throw new ValidationException($"oldText occurs {positions.Count} times; include more surrounding text or pass 'occurrence'.");
        }
        var index = (occurrence ?? 1) - 1;
        if (index >= positions.Count)
        {
            throw new ValidationException($"Only {positions.Count} occurrences exist.");
        }
        var updated = original[..positions[index]] + newText + original[(positions[index] + oldText.Length)..];
        var (added, removed) = LineDiff.Count(oldText, newText);

        var temp = full + ".docgen-edit";
        var encoded = new UTF8Encoding(hasBom).GetPreamble().Concat(new UTF8Encoding(false).GetBytes(updated)).ToArray();
        await File.WriteAllBytesAsync(temp, encoded, ct);
        File.Move(temp, full, overwrite: true);

        var relative = repo.Relative(full);
        Services.Indexes.Invalidate(repo);
        var line = original[..positions[index]].Count(c => c == '\n') + 1;
        if (context.ConversationId is not null
            && await Services.Investigations.GetActiveForConversationAsync(context.UserId, context.ConversationId, CancellationToken.None) is { RootCause: not null } active)
        {
            var summary = active.Fix?.Summary ?? $"Edited {relative}";
            await Services.Investigations.RecordFixAsync(context.UserId, active.Id, summary, null, [relative], added, removed, CancellationToken.None);
        }
        var result = ToolResult.Ok(call, $"Edited {repo.Name}:{relative} at line {line} (+{added} / -{removed} lines). Rebuild/test to verify; the index refreshes automatically.");
        result.FileChanges = [new FileChange { Path = $"{repo.Name}:{relative}", Kind = "modified", LinesAdded = added, LinesRemoved = removed }];
        return result;
    }
}
