using System.Diagnostics;
using System.Globalization;
using System.Text.RegularExpressions;
using DocGen.Analysis.Browser;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Core.Options;
using DocGen.Tools.Infrastructure;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Tools;

/// <summary>
/// Renders a local file with the machine's Edge/Chrome, headless and offline (throwaway profile, name resolution blocked
/// so the document cannot fetch anything), into an output file (PDF or PNG). Shared by pdf_export and image_export.
/// </summary>
internal static class HeadlessRender
{
    private static readonly TimeSpan Timeout = TimeSpan.FromSeconds(90);

    /// <summary>Returns null when <paramref name="output"/> was written, otherwise why not.</summary>
    public static async Task<string?> RunAsync(string browser, string source, string output, Func<string, IEnumerable<string>> modeArguments, string what, CancellationToken ct)
    {
        var profile = Path.Combine(Path.GetTempPath(), "docgen-render-" + Guid.NewGuid().ToString("N")[..12]);
        var temp = Path.Combine(Path.GetDirectoryName(output)!, Path.GetFileNameWithoutExtension(output) + ".tmp-" + Guid.NewGuid().ToString("N")[..8] + Path.GetExtension(output));
        try
        {
            var start = new ProcessStartInfo(browser) { UseShellExecute = false, CreateNoWindow = true, RedirectStandardError = true, RedirectStandardOutput = true };
            foreach (var a in new[]
            {
                "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check", "--disable-extensions", "--disable-sync",
                "--user-data-dir=" + profile, "--host-resolver-rules=MAP * ~NOTFOUND", "--hide-scrollbars", "--virtual-time-budget=3000",
            }.Concat(modeArguments(temp)).Append(new Uri(source).AbsoluteUri))
            {
                start.ArgumentList.Add(a);
            }
            using var process = Process.Start(start) ?? throw new ToolException("The browser could not be started.");
            _ = process.StandardOutput.ReadToEndAsync(ct);
            var errors = process.StandardError.ReadToEndAsync(ct);
            using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
            timeout.CancelAfter(Timeout);
            try
            {
                await process.WaitForExitAsync(timeout.Token);
            }
            catch (OperationCanceledException)
            {
                process.Kill(entireProcessTree: true);
                throw new ToolTimeoutException($"Rendering the {what} took longer than {Timeout.TotalSeconds:0} seconds.");
            }
            // The launcher can exit before the rendering child process has written the file: wait for it to appear and settle.
            var waited = Stopwatch.StartNew();
            long lastSize = -1;
            while (waited.Elapsed < TimeSpan.FromSeconds(30))
            {
                var size = File.Exists(temp) ? new FileInfo(temp).Length : 0;
                if (size > 0 && size == lastSize)
                {
                    break;
                }
                lastSize = size;
                await Task.Delay(400, ct);
            }
            if (!File.Exists(temp) || new FileInfo(temp).Length == 0)
            {
                var detail = (await errors).Trim();
                return $"The browser did not produce a {what}" + (detail.Length > 0 ? ": " + detail[..Math.Min(400, detail.Length)] : ".");
            }
            File.Move(temp, output, overwrite: true);
            return null;
        }
        finally
        {
            try { if (File.Exists(temp)) File.Delete(temp); } catch (IOException) { }
            try { if (Directory.Exists(profile)) Directory.Delete(profile, recursive: true); } catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { }
        }
    }

    public static string LocateBrowser(AnalysisServices services, string purpose)
    {
        var options = services.Service<IOptionsMonitor<BrowserOptions>>()?.CurrentValue ?? new BrowserOptions();
        return BrowserService.LocateBrowser(options)
               ?? throw new ValidationException($"No Edge or Chrome was found on this machine, so {purpose} (set DocGen:Browser:ExecutablePath).");
    }
}

/// <summary>
/// image_export: an SVG drawing or an HTML page rendered to a PNG in the workspace's generated/ folder, shown in the reply.
/// The size comes from the SVG's own width/height or viewBox (or the width/height given), at 2× for crisp text and lines.
/// </summary>
public sealed partial class ImageExportTool(AnalysisServices services) : AnalysisTool(services)
{
    private const int MaxSide = 4000;

    public override string Name => "image_export";

    public override string Description =>
        "Renders an .svg drawing or an .html page to a PNG image (headless Edge/Chrome, offline) in the workspace under generated/, " +
        "shown to the user in the reply. Use it when the user wants a PNG (or any raster image) of a drawing you wrote: write the SVG/HTML " +
        "first (file_write), then export it. Size: the SVG's own width/height or viewBox unless you pass width/height (CSS pixels; rendered at 2×).";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "path": { "type": "string", "minLength": 1, "maxLength": 500, "description": "The .svg or .html file to render." },
            "name": { "type": "string", "maxLength": 80, "description": "PNG file name (default: the source file's name)." },
            "width": { "type": "integer", "minimum": 16, "maximum": 4000 },
            "height": { "type": "integer", "minimum": 16, "maximum": 4000 }
          },
          "required": ["path"],
          "additionalProperties": false
        }
        """;

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct) => throw new NotSupportedException();

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var repo = await Services.RepositoryAsync(args, context, ct);
        var source = repo.Resolve(args.RequireString("path"));
        var extension = Path.GetExtension(source).ToLowerInvariant();
        if (extension is not (".svg" or ".html" or ".htm"))
        {
            throw new ValidationException("image_export renders .svg and .html files; write the drawing as SVG (or HTML) first.");
        }
        if (!File.Exists(source))
        {
            throw new NotFoundException(extension == ".svg" ? "SVG file" : "HTML file");
        }
        var (width, height) = (args.GetInt("width"), args.GetInt("height"));
        if (extension == ".svg" && (width is null || height is null) && SvgSize(await File.ReadAllTextAsync(source, ct)) is { } size)
        {
            width ??= size.Width;
            height ??= size.Height;
        }
        var (w, h) = (Math.Clamp(width ?? 1200, 16, MaxSide), Math.Clamp(height ?? 800, 16, MaxSide));
        // 2× for SVG (crisp lines and text); an HTML page renders at its CSS size.
        var scale = extension == ".svg" && Math.Max(w, h) * 2 <= MaxSide ? 2 : 1;
        var browser = HeadlessRender.LocateBrowser(Services, "an image cannot be rendered");

        var baseName = SafeName().Replace(Path.GetFileNameWithoutExtension(args.GetString("name") is { Length: > 0 } n ? n : source), "-").Trim('-');
        var relative = $"generated/{(baseName.Length == 0 ? "image" : baseName)}.png";
        var output = Path.Combine(context.WorkspaceRoot, relative.Replace('/', Path.DirectorySeparatorChar));
        Directory.CreateDirectory(Path.GetDirectoryName(output)!);
        var failure = extension == ".svg"
            ? await SvgToPngAsync(browser, source, output, w * scale, h * scale, ct)
            : await HeadlessRender.RunAsync(browser, source, output,
                temp => ["--screenshot=" + temp, $"--window-size={w},{h}", "--force-device-scale-factor=1", "--default-background-color=00000000"], "PNG", ct);
        if (failure is not null)
        {
            return ToolResult.Fail(call, failure);
        }
        var bytes = new FileInfo(output).Length;
        var result = ToolResult.Ok(call, $"Rendered {repo.Relative(source).Replace('\\', '/')} to {relative} ({w * scale}×{h * scale} px, {bytes:N0} bytes; " +
                                         $"absolute path {output}). The user sees it in the reply.");
        result.FileChanges = [new FileChange { Path = relative, Kind = "image" }];
        return result;
    }

    /// <summary>
    /// Renders an SVG file to a PNG of exactly <paramref name="pixelWidth"/>×<paramref name="pixelHeight"/>. Headless Edge
    /// enlarges the canvas for a device scale factor but not an SVG opened directly (the drawing filled a quarter of the
    /// PNG), so the SVG is shown by a one-line page at the output size and screenshotted at 1×. Null on success.
    /// </summary>
    internal static async Task<string?> SvgToPngAsync(string browser, string svgPath, string output, int pixelWidth, int pixelHeight, CancellationToken ct)
    {
        var wrapper = Path.Combine(Path.GetDirectoryName(svgPath)!, $".docgen-render-{Guid.NewGuid():N}.html");
        await File.WriteAllTextAsync(wrapper,
            "<!doctype html><html><head><meta charset=\"utf-8\"><style>html,body{margin:0;padding:0;background:transparent;overflow:hidden}" +
            $"img{{display:block;width:{pixelWidth}px;height:{pixelHeight}px}}</style></head><body><img src=\"{Uri.EscapeDataString(Path.GetFileName(svgPath))}\" alt=\"\"></body></html>", ct);
        try
        {
            return await HeadlessRender.RunAsync(browser, wrapper, output,
                temp => ["--screenshot=" + temp, $"--window-size={pixelWidth},{pixelHeight}", "--force-device-scale-factor=1", "--default-background-color=00000000"], "PNG", ct);
        }
        finally
        {
            try { File.Delete(wrapper); } catch (IOException) { }
        }
    }

    /// <summary>An SVG's size from width/height (px or unitless) or, failing that, its viewBox.</summary>
    internal static (int Width, int Height)? SvgSize(string svg)
    {
        var root = SvgRoot().Match(svg);
        if (!root.Success)
        {
            return null;
        }
        var tag = root.Value;
        double? Length(string name) => Regex.Match(tag, $@"\b{name}\s*=\s*[""']\s*([\d.]+)\s*(px)?\s*[""']") is { Success: true } m
            && double.TryParse(m.Groups[1].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out var v) ? v : null;
        var (width, height) = (Length("width"), Length("height"));
        if ((width is null || height is null) && ViewBox().Match(tag) is { Success: true } vb
            && double.TryParse(vb.Groups[3].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out var vw)
            && double.TryParse(vb.Groups[4].Value, NumberStyles.Float, CultureInfo.InvariantCulture, out var vh))
        {
            width ??= vw;
            height ??= vh;
        }
        return width is > 0 && height is > 0 ? ((int)Math.Round(width.Value), (int)Math.Round(height.Value)) : null;
    }

    [GeneratedRegex(@"<svg\b[^>]*>", RegexOptions.IgnoreCase)]
    private static partial Regex SvgRoot();

    [GeneratedRegex(@"\bviewBox\s*=\s*[""']\s*([-\d.]+)[\s,]+([-\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)\s*[""']", RegexOptions.IgnoreCase)]
    private static partial Regex ViewBox();

    [GeneratedRegex(@"[^A-Za-z0-9._-]+")]
    private static partial Regex SafeName();
}
