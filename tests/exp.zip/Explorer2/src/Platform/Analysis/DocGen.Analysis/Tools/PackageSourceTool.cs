using System.Globalization;
using System.Text;
using DocGen.Analysis.Git;
using DocGen.Analysis.Packaging;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Core.Options;
using DocGen.Tools.Infrastructure;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Tools;

/// <summary>package_source: a verified, relative-path source ZIP in the user's workspace (packages/). Separate from commit/push.</summary>
public sealed class PackageSourceTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "package_source";

    public override string Description =>
        "Creates a ZIP (System.IO.Compression) in your workspace under packages/ and gives the user a download button. Use it whenever the user asks " +
        "to download, zip, export or package a folder or the source. 'path' zips one folder (relative to the repository, or an absolute path inside " +
        "a registered repository — the repository is found automatically); its entries sit under the folder's name. Otherwise entries are relative " +
        "to the chosen root (root=repository (default), solution, project or workspace) — never ../, absolute paths, drive letters or UNC paths. Excluded by default: " +
        ".git .vs bin obj node_modules data logs workspaces TestResults, browser profiles, scratch folders, *.log, user-specific files and every " +
        "secret file or file with credential content (secrets are never included, even on request). 'include' re-adds safe default-excluded " +
        "directories; 'exclude' adds directory names or globs. Writes docgen-package.json (no credentials) and verifies the archive after creation.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "root": { "type": "string", "enum": ["repository", "solution", "project", "workspace", "folder"] },
            "path": { "type": "string", "maxLength": 500, "description": "Folder to zip (root=folder): relative to the repository, or an absolute path inside a registered repository." },
            "project": { "type": "string", "maxLength": 500, "description": "Project file or folder (root=project)." },
            "solution": { "type": "string", "maxLength": 500, "description": "Solution file (root=solution; default: the solution at the repository root)." },
            "include": { "type": "array", "items": { "type": "string", "maxLength": 100 }, "maxItems": 20, "description": "Default-excluded directory names to include (e.g. TestResults)." },
            "exclude": { "type": "array", "items": { "type": "string", "maxLength": 200 }, "maxItems": 50, "description": "Extra exclusions: directory names or globs (docs/private/**, *.bak)." },
            "manifest": { "type": "boolean", "description": "Write docgen-package.json (default true)." },
            "strictSecrets": { "type": "boolean", "description": "Also exclude source-code files with credential-like strings (default: package them and list them for review)." },
            "name": { "type": "string", "maxLength": 60, "description": "Archive base name (default: repository name)." }
          },
          "additionalProperties": false
        }
        """;

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct) => throw new NotSupportedException();

    /// <summary>The text result plus a "download" file change, which the chat renders as a download button.</summary>
    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (text, archive, bytes) = await PackageAsync(args, context, ct);
        var result = ToolResult.Ok(call, text.TrimEnd());
        result.FileChanges = [new FileChange { Path = archive, Kind = "download", LinesAdded = (int)Math.Min(int.MaxValue, bytes) }];
        return result;
    }

    /// <summary>Finds the registered repository that contains an absolute folder (the explicit repository first).</summary>
    private async Task<(Repositories.RepositoryHandle Repo, string Folder)> FolderAsync(ToolArguments args, ToolExecutionContext context, string path, CancellationToken ct)
    {
        var candidate = path.Trim().Trim('"');
        if (!Path.IsPathFullyQualified(candidate))
        {
            var repo = await Services.RepositoryAsync(args, context, ct);
            return (repo, repo.Resolve(candidate));
        }
        var full = Path.GetFullPath(candidate).TrimEnd(Path.DirectorySeparatorChar);
        var repos = await Services.Repositories.ListAsync(context.UserId, ct);
        var ordered = repos.OrderByDescending(r => string.Equals(r.Name, args.GetString("repository"), StringComparison.OrdinalIgnoreCase)).ThenByDescending(r => r.Root.Length);
        foreach (var r in ordered)
        {
            var root = Path.GetFullPath(r.Root).TrimEnd(Path.DirectorySeparatorChar);
            if (full.Equals(root, StringComparison.OrdinalIgnoreCase) || full.StartsWith(root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            {
                return (r, r.Resolve(Path.GetRelativePath(root, full)));
            }
        }
        throw new ForbiddenException($"'{candidate}' is not inside a folder DocGen can use. Add it first with + → Add folder (or ask an administrator to register it).");
    }

    private async Task<(string Text, string Archive, long Bytes)> PackageAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var workflow = Services.Service<IOptionsMonitor<WorkflowOptions>>()?.CurrentValue ?? new WorkflowOptions();
        var rootKind = args.GetString("root") ?? (args.GetString("path") is { Length: > 0 } ? "folder" : "repository");
        Repositories.RepositoryHandle repo;
        string? folderRoot = null;
        if (rootKind == "folder")
        {
            (repo, folderRoot) = await FolderAsync(args, context, args.GetString("path") is { Length: > 0 } fp ? fp : throw new ValidationException("root=folder requires 'path'."), ct);
            if (!Directory.Exists(folderRoot))
            {
                throw new NotFoundException("Folder");
            }
        }
        else
        {
            repo = rootKind == "workspace" ? await Services.Repositories.ResolveAsync(context.UserId, "workspace", ct) : await Services.RepositoryAsync(args, context, ct);
        }
        string root;
        switch (rootKind)
        {
            case "folder":
                root = folderRoot!;
                break;
            case "repository":
            case "workspace":
                root = repo.Root;
                break;
            case "solution":
                var solution = args.GetString("solution") is { Length: > 0 } s ? repo.Resolve(s) : DeveloperWorkflowService.FindSolution(repo.Root) is { } found ? repo.Resolve(found)
                    : throw new ValidationException("No solution file at the repository root; pass 'solution'.");
                if (!File.Exists(solution) || Path.GetExtension(solution) is not (".sln" or ".slnx"))
                {
                    throw new NotFoundException("Solution");
                }
                root = Path.GetDirectoryName(solution)!;
                break;
            case "project":
                var project = repo.Resolve(args.GetString("project") is { Length: > 0 } p ? p : throw new ValidationException("root=project requires 'project'."));
                root = File.Exists(project) ? Path.GetDirectoryName(project)! : Directory.Exists(project) ? project : throw new NotFoundException("Project");
                break;
            default:
                throw new ValidationException("root must be repository, solution, project, workspace or folder.");
        }

        var folderName = Path.GetFileName(root.TrimEnd(Path.DirectorySeparatorChar));
        var baseName = SafeName(args.GetString("name") is { Length: > 0 } n ? n
            : rootKind == "folder" ? folderName : repo.Name + (rootKind is "project" ? "-" + Path.GetFileName(root) : ""));
        var outputDir = Path.Combine(context.WorkspaceRoot, "packages");
        var output = Path.Combine(outputDir, $"{baseName}-{DateTime.UtcNow:yyyyMMdd-HHmmss}.zip");
        var manifest = new PackageManifest
        {
            Repository = repo.Name, RootKind = rootKind,
            RelativeRoot = Path.GetRelativePath(repo.Root, root).Replace('\\', '/') is { Length: > 0 } rr ? rr : ".",
        };
        if (rootKind != "workspace" && GitService.FindGitRoot(root) is { } gitRoot && Services.Executables.IsAllowed("git"))
        {
            try
            {
                var status = await new GitService(Services).StatusAsync(new GitContext(context.UserId, repo, gitRoot, context.RunId, context.ConversationId), ct);
                manifest.Branch = status.Branch;
                manifest.Commit = status.Head;
                manifest.WorkingTreeClean = status.Clean;
            }
            catch (ValidationException)
            {
                // Git metadata is optional.
            }
        }

        var settings = new PackageSettings
        {
            ExcludedDirectories = workflow.PackageExcludedDirectories.Concat(Services.Options.ExcludedDirectories).Distinct(StringComparer.OrdinalIgnoreCase).ToList(),
            NeverIncludedDirectories = workflow.PackageNeverIncludedDirectories,
            Include = args.GetStringArray("include").ToList(),
            Exclude = args.GetStringArray("exclude").ToList(),
            WriteManifest = args.GetBool("manifest") != false,
            StrictSecrets = args.GetBool("strictSecrets") == true,
            MaxTotalBytes = workflow.MaxPackageBytes,
            MaxFiles = workflow.MaxPackageFiles,
            ExcludedAbsolute = [outputDir],
            EntryPrefix = rootKind == "folder" && SafeName(folderName) == folderName ? folderName + "/" : rootKind == "folder" ? SafeName(folderName) + "/" : "",
        };
        var result = await Task.Run(() => SourcePackager.Create(root, output, settings, manifest, ct), ct);

        var sb = new StringBuilder();
        var shown = Path.GetRelativePath(context.WorkspaceRoot, output).Replace('\\', '/');
        sb.AppendLine(CultureInfo.InvariantCulture, $"Source package: workspace:{shown} ({SourcePackager.SizeText(result.ArchiveBytes)}; {result.FileCount:N0} files, {SourcePackager.SizeText(result.TotalBytes)} uncompressed)");
        sb.AppendLine($"Root: {rootKind} {repo.Name}:{manifest.RelativeRoot}" +
            (manifest.Commit is { } c ? $" · branch {manifest.Branch ?? "(detached)"} @ {c[..7]}{(manifest.WorkingTreeClean == false ? " (includes uncommitted changes)" : "")}" : ""));
        sb.AppendLine(result.Verification.Passed ? "Verification passed:" : "VERIFICATION FAILED:");
        foreach (var check in result.Verification.Checks)
        {
            sb.Append("  ").AppendLine(check);
        }
        foreach (var problem in result.Verification.Problems)
        {
            sb.Append("  ✗ ").AppendLine(problem);
        }
        sb.AppendLine("Excluded: " + (result.Manifest.ExcludedCounts.Count == 0 ? "nothing" : string.Join("; ", result.Manifest.ExcludedCounts.OrderByDescending(p => p.Value).Take(12).Select(p => $"{p.Key} ×{p.Value}"))));
        if (result.SecretFilesExcluded.Count > 0)
        {
            sb.AppendLine("Secret files excluded (never packaged): " + string.Join(", ", result.SecretFilesExcluded.Take(10)));
        }
        if (result.SourceWarnings.Count > 0)
        {
            sb.AppendLine($"⚠ Credential-like strings in {result.SourceWarnings.Count} packaged source file(s) — review before sharing (strictSecrets=true excludes them): " +
                          string.Join(", ", result.SourceWarnings.Take(10)));
        }
        sb.AppendLine("Largest files: " + string.Join(", ", result.Largest.Select(l => $"{l.Path} ({SourcePackager.SizeText(l.Bytes)})")));
        if (settings.WriteManifest)
        {
            sb.AppendLine($"Manifest: {SourcePackager.ManifestName} (createdAt, repository, branch, commit, file count, total bytes, exclusions, relative root — no credentials).");
        }
        sb.AppendLine($"Download: the user can save it with the download button on this step (workspace file {shown}).");
        return (sb.ToString(), shown, result.ArchiveBytes);
    }

    private static string SafeName(string value)
    {
        var chars = value.Select(ch => char.IsLetterOrDigit(ch) || ch is '-' or '_' or '.' ? ch : '-').ToArray();
        var name = new string(chars).Trim('-', '.');
        return name.Length == 0 ? "source" : name.Length > 60 ? name[..60] : name;
    }
}
