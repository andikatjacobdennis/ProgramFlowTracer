using System.Text;
using System.Text.Json;
using DocGen.Analysis.Memory;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

public abstract class MemoryToolBase(AnalysisServices services) : AnalysisTool(services)
{
    protected ProjectMemoryService Memory => Services.Service<ProjectMemoryService>()
        ?? throw new DocGenException("MEMORY_UNAVAILABLE", "Project memory is not available in this host.", 500);
}

public sealed class MemorySearchTool(AnalysisServices services) : MemoryToolBase(services)
{
    public override string Name => "memory_search";

    public override string Description =>
        "Searches project memory (durable facts about a repository: architecture, conventions, verification practice, build/test commands, layout, " +
        "limitations, decisions, debugging lessons, benchmark baselines, release history, roadmap, environment facts). Returns only the most relevant " +
        "entries with provenance. mode=index shows the compact index. Memory can be outdated: repository evidence wins.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "query": { "type": "string", "maxLength": 300 },
            "category": { "type": "string", "enum": ["architecture", "conventions", "verification", "commands", "layout", "limitations", "decisions", "debugging", "benchmarks", "releases", "roadmap", "environment"] },
            "mode": { "type": "string", "enum": ["search", "index"] },
            "limit": { "type": "integer", "minimum": 1, "maximum": 10 }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, doc) = await Memory.LoadAsync(context.UserId, await Services.RepositoryNameAsync(args, context, ct), ct);
        if (args.GetString("mode") == "index")
        {
            return ProjectMemoryService.IndexMarkdown(doc);
        }
        var query = args.GetString("query") ?? "";
        if (query.Trim().Length == 0 && args.GetString("category") is null)
        {
            throw new ValidationException("Pass a query or a category (or mode=index).");
        }
        var limit = Clamp(args.GetInt("limit"), 5, 1, 10);
        var hits = query.Trim().Length == 0
            ? doc.Entries.Where(e => e.Status == MemoryStatus.Active && e.Category == args.GetString("category")).OrderByDescending(e => e.UpdatedAt).Take(limit).Select(e => (e, 0.0)).ToList()
            : ProjectMemoryService.Rank(doc.Entries, query, args.GetString("category"), includeStale: true, limit);
        if (hits.Count == 0)
        {
            return $"No project memory in {repo.Name} matches that ({doc.Entries.Count(e => e.Status == MemoryStatus.Active)} active entries).";
        }
        var sb = new StringBuilder($"{hits.Count} memory entr{(hits.Count == 1 ? "y" : "ies")} from {repo.Name}:\n\n");
        foreach (var (entry, _) in hits)
        {
            sb.AppendLine(ProjectMemoryService.Describe(entry)).AppendLine();
        }
        return sb.ToString();
    }
}

public sealed class MemoryProposeTool(AnalysisServices services) : MemoryToolBase(services)
{
    public override string Name => "memory_propose";

    public override string Description =>
        "Proposes a project-memory entry at the end of meaningful work: one durable, non-secret fact that future work on this repository needs, " +
        "with evidence files (and optionally text they contain) so it can be re-checked. The user reviews proposals (accept, edit or archive); " +
        "proposals are not used until accepted. Never propose passwords, keys, tokens, logs, temporary output, speculation or UI state; do not " +
        "record every conversation. 'replaces' revises an existing entry.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "category": { "type": "string", "enum": ["architecture", "conventions", "verification", "commands", "layout", "limitations", "decisions", "debugging", "benchmarks", "releases", "roadmap", "environment"] },
            "title": { "type": "string", "minLength": 3, "maxLength": 120 },
            "content": { "type": "string", "minLength": 10, "maxLength": 1500 },
            "tags": { "type": "array", "items": { "type": "string", "maxLength": 40 }, "maxItems": 10 },
            "confidence": { "type": "string", "enum": ["high", "medium", "low"] },
            "evidence": {
              "type": "array", "minItems": 1, "maxItems": 10,
              "items": { "type": "object", "properties": { "file": { "type": "string", "maxLength": 300 }, "contains": { "type": "string", "maxLength": 200 } }, "required": ["file"], "additionalProperties": false }
            },
            "replaces": { "type": "string", "maxLength": 40 }
          },
          "required": ["category", "title", "content", "evidence"],
          "additionalProperties": false
        }
        """;

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var evidence = args.GetElement("evidence") is { ValueKind: JsonValueKind.Array } a
            ? a.EnumerateArray().Select(e => new MemoryEvidence
            {
                File = e.TryGetProperty("file", out var f) ? f.GetString() ?? "" : "",
                Contains = e.TryGetProperty("contains", out var c) ? c.GetString() : null,
            }).ToList()
            : [];
        var entry = await Memory.ProposeAsync(context.UserId, await Services.RepositoryNameAsync(args, context, ct), new MemoryEntry
        {
            Category = args.RequireString("category"), Title = args.RequireString("title"), Content = args.RequireString("content"),
            Tags = args.GetStringArray("tags").ToList(), Confidence = args.GetString("confidence") ?? "medium", Evidence = evidence,
            SourceConversationId = context.ConversationId, SourceRunId = context.RunId, Replaces = args.GetString("replaces"),
        }, byUser: false, ct);
        return $"Proposed memory entry {entry.Id} ({entry.Category}: {entry.Title}). It is used only after the user accepts it on the Memory page.";
    }
}
