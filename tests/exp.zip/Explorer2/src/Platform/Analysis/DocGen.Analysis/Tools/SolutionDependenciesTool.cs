using System.Text;
using System.Text.Json;
using DocGen.Analysis.Architecture;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

/// <summary>
/// solution_dependencies: the project dependency diagram of a solution, computed from its ProjectReference items —
/// a detailed Mermaid view (every project in folder subgraphs, every reference) and a simplified one (areas, one arrow
/// per pair of areas) — plus the facts about each project that its description and role are written from.
/// The diagrams are saved to generated/diagrams/ in the workspace; the repository is never changed.
/// </summary>
public sealed class SolutionDependenciesTool(AnalysisServices services) : AnalysisTool(services), IDynamicRiskTool
{
    public override string Name => "solution_dependencies";

    public override string Description =>
        "Project dependency diagrams of a .NET solution from its real ProjectReferences (the solution-dependency skill). Returns Mermaid: " +
        "a detailed view (projects grouped by folder; 'A --> B' = A references B; production / tests / test support coloured) and a " +
        "simplified view (areas; references inside an area hidden; one arrow per pair of areas), plus per-project facts (kind, " +
        "references, used by, entry points, endpoints, hosted services, packages, role hint) for writing each project's description. " +
        "Saves generated/diagrams/<repo>-dependencies.md in the workspace.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "solution": { "type": "string", "description": "A .sln/.slnx path or name; default: the only solution (or all projects when there are several)." },
            "include_tests": { "type": "boolean", "description": "Include test and test-support projects (default true)." },
            "transitive_reduction": { "type": "boolean", "description": "Detailed view: drop references already implied through other references (default false)." },
            "areas": { "type": "object", "additionalProperties": { "type": "array", "items": { "type": "string" } },
                       "description": "Simplified view: area label → project names or wildcards, e.g. {\"HostCommon / Service hosts\": [\"HostCommon\", \"*Host\"]}. Unlisted projects get a default area." },
            "descriptions": { "type": "object", "additionalProperties": { "type": "string" },
                       "description": "Project name → one sentence on what it does (written from its code); fills the 'What it does' column of the saved file's project table." }
          },
          "additionalProperties": false
        }
        """;

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    public Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken)
        => Task.FromResult(new ToolRiskAssessment(ToolRiskLevel.Write, Routine: true, Summary: "Write a dependency diagram into generated/diagrams/ in the workspace"));

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct) => throw new NotSupportedException();

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        if (index.Manifest.Projects.Count == 0)
        {
            throw new ValidationException($"The {repo.Name} repository has no indexed projects; run index_repository first (or this is not a .NET solution).");
        }
        var solution = args.GetString("solution");
        var includeTests = args.GetBool("include_tests") ?? true;
        Dictionary<string, IReadOnlyList<string>>? areas = null;
        if (args.GetElement("areas") is { ValueKind: JsonValueKind.Object } a)
        {
            areas = a.EnumerateObject().ToDictionary(p => p.Name, p => (IReadOnlyList<string>)(p.Value.ValueKind == JsonValueKind.Array ? p.Value.EnumerateArray().Select(x => x.GetString() ?? "").Where(x => x.Length > 0).ToList() : []));
        }

        var descriptions = args.GetElement("descriptions") is { ValueKind: JsonValueKind.Object } d
            ? d.EnumerateObject().ToDictionary(p => p.Name, p => p.Value.GetString() ?? "", StringComparer.OrdinalIgnoreCase)
            : new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var detailed = SolutionDependencyDiagram.Build(index, solution, includeTests, args.GetBool("transitive_reduction") ?? false);
        var simplified = SolutionDependencyDiagram.BuildAreas(index, solution, includeTests, areas);
        var facts = SolutionDependencyDiagram.Facts(index, solution, includeTests);

        var file = new StringBuilder($"# Project dependencies — {repo.Name}\n\nSolution: `{detailed.Solution}` · {detailed.Projects} projects ({detailed.Production} production, {detailed.Tests} tests, {detailed.Support} test support) · {detailed.References} project references.\n\n");
        file.Append("Arrows read **A --> B = A references B** (from the .csproj ProjectReference items).\n\n## Simplified view\n\n")
            .Append($"Projects grouped by area; references inside an area are hidden. Each arrow stands for at least one project reference.\n\n```mermaid\n{simplified.Mermaid}```\n\n");
        foreach (var (area, members) in simplified.Members.OrderBy(kv => kv.Key, StringComparer.OrdinalIgnoreCase))
        {
            file.Append($"- **{area}**: {string.Join(", ", members)}\n");
        }
        file.Append($"\n## Detailed view\n\n```mermaid\n{detailed.Mermaid}```\n\n## Projects\n\n| Project | Kind | What it does | Role in the solution | References | Used by |\n|---|---|---|---|---:|---:|\n");
        foreach (var f in facts)
        {
            var what = descriptions.TryGetValue(f.Name, out var text) && text.Length > 0 ? text.Replace("|", "\\|").Replace("\n", " ") : "—";
            file.Append($"| `{f.Name}` | {f.Kind} | {what} | {f.RoleHint} | {f.References.Count} | {f.ReferencedBy.Count} |\n");
        }
        var factLines = facts.Select(FactLine).ToList();
        file.Append("\n## Project facts\n\nWhat the code index shows about each project (kind, role hint, types, entry points, endpoints, hosted services, DbContexts, packages, references).\n\n")
            .Append(string.Concat(factLines));
        var safe = ArchitectureWriter.Safe(repo.Name) + (string.IsNullOrEmpty(solution) ? "" : "-" + ArchitectureWriter.Safe(Path.GetFileNameWithoutExtension(detailed.Solution)));
        var relative = $"generated/diagrams/{safe}-dependencies.md";
        var full = Path.Combine(context.WorkspaceRoot, relative.Replace('/', Path.DirectorySeparatorChar));
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);

        // Both views as PNG too: chat shows them inline (a large detailed view is too long to repeat as Mermaid text).
        var images = await RenderAsync(full, [("simplified", simplified.Mermaid), ("detailed", detailed.Mermaid)], ct);
        var markdown = file.ToString();
        foreach (var (view, png, _) in images.Where(i => i.Png is not null))
        {
            var heading = view == "detailed" ? "## Detailed view\n\n" : "## Simplified view\n\n";
            markdown = markdown.Replace(heading, heading + $"![{view} view]({Path.GetFileName(png)})\n\n");
        }
        await File.WriteAllTextAsync(full, markdown, new UTF8Encoding(true), ct);

        var sb = new StringBuilder();
        sb.AppendLine($"Solution {detailed.Solution}: {detailed.Projects} projects ({detailed.Production} production, {detailed.Tests} tests, {detailed.Support} test support), {detailed.References} references, {detailed.Groups} folder groups; simplified: {simplified.Areas} areas, {simplified.Links} area links.");
        if (detailed.Cycles.Count > 0)
        {
            sb.AppendLine($"Reference cycles: {string.Join("; ", detailed.Cycles.Take(5))}");
        }
        sb.AppendLine($"Saved to {relative} in the workspace (both diagrams and the project table).");
        foreach (var (view, png, error) in images)
        {
            sb.AppendLine(png is not null
                ? $"The {view} view is rendered as {Path.GetDirectoryName(relative)!.Replace('\\', '/')}/{Path.GetFileName(png)}{(view == "detailed" ? " and shown to the user in the chat" : "")}."
                : $"The {view} view could not be rendered as an image ({error}); the Mermaid is in the file.");
        }
        sb.AppendLine("\n### Simplified view (areas)\n```mermaid\n" + simplified.Mermaid + "```");
        sb.AppendLine("Areas: " + string.Join("; ", simplified.Members.Select(kv => $"{kv.Key} = {string.Join(", ", kv.Value)}")));
        // The detailed view of a large solution is long; the model gets it only when it fits, the user always has the file.
        const int maxInline = 9000;
        if (detailed.Mermaid.Length <= maxInline)
        {
            sb.AppendLine("\n### Detailed view\n```mermaid\n" + detailed.Mermaid + "```");
        }
        else
        {
            sb.AppendLine($"\n### Detailed view\nToo large to repeat as Mermaid here ({detailed.Mermaid.Length:N0} characters, {detailed.References} arrows in {detailed.Groups} groups). " +
                          (images.Any(i => i.View == "detailed" && i.Png is not null) ? "The user sees it as the rendered image above; " : "") + $"the Mermaid is in {relative} (section 'Detailed view').");
        }
        if (descriptions.Count > 0)
        {
            sb.AppendLine($"Wrote {descriptions.Count} project descriptions into the project table of {relative}.");
        }
        sb.AppendLine("\n### Project facts (write each project's description and role from these and its code)");
        // Within the tool-output budget: production first (the list is ordered so); the rest are in the saved file.
        const int budget = 17_500;
        var shown = 0;
        foreach (var line in factLines)
        {
            if (sb.Length + line.Length > budget)
            {
                break;
            }
            sb.Append(line);
            shown++;
        }
        if (shown < factLines.Count)
        {
            sb.AppendLine($"… {factLines.Count - shown} more projects: read the 'Project facts' section of {relative} (file_read, repository \"workspace\").");
        }
        var result = ToolResult.Ok(call, sb.ToString());
        var folder = Path.GetDirectoryName(relative)!.Replace('\\', '/');
        result.FileChanges = [new FileChange { Path = relative, Kind = "created" },
            .. images.Where(i => i.Png is not null).OrderBy(i => i.View == "detailed" ? 1 : 0).Select(i => new FileChange { Path = $"{folder}/{Path.GetFileName(i.Png)}", Kind = i.View == "detailed" ? "image" : "created" })];
        return result;
    }

    /// <summary>Renders each view to PNG beside the Markdown file; per view the image path, or why it was not rendered.</summary>
    private async Task<List<(string View, string? Png, string? Error)>> RenderAsync(string markdownPath, (string View, string Mermaid)[] views, CancellationToken ct)
    {
        var results = new List<(string, string?, string?)>();
        string? browser = null;
        try
        {
            browser = HeadlessRender.LocateBrowser(Services, "Diagrams cannot be rendered as images");
        }
        catch (ValidationException ex)
        {
            return views.Select(v => (v.View, (string?)null, (string?)ex.Message)).ToList();
        }
        var script = ArchitectureBundle.FindMermaidScript();
        await using var mermaid = script is null ? null : await MermaidBrowser.StartAsync(browser, script, ct);
        foreach (var (view, text) in views)
        {
            if (mermaid is null)
            {
                results.Add((view, null, script is null ? "the Mermaid library was not found" : "the headless browser could not start"));
                continue;
            }
            try
            {
                var (png, _, _) = await mermaid.RenderPngAsync(text, 2, ct);
                var path = Path.Combine(Path.GetDirectoryName(markdownPath)!, Path.GetFileNameWithoutExtension(markdownPath) + $"-{view}.png");
                await File.WriteAllBytesAsync(path, png, ct);
                results.Add((view, path, null));
            }
            catch (Exception ex) when (ex is InvalidOperationException or IOException or System.Net.WebSockets.WebSocketException or System.Text.Json.JsonException or DocGenException)
            {
                results.Add((view, null, ex.Message));
            }
        }
        return results;
    }

    private static string FactLine(SolutionDependencyDiagram.ProjectFacts f)
    {
        static string List(IReadOnlyList<string> items) => items.Count == 0 ? "none" : items.Count <= 4 ? string.Join(", ", items) : $"{string.Join(", ", items.Take(3))} +{items.Count - 3}";
        if (f.Category == "tests")
        {
            return $"- {f.Name} [test project] {f.RoleHint}; {f.Types} types\n"; // what it tests is in its references
        }
        var sb = new StringBuilder($"- {f.Name} [{f.Kind}] {f.RoleHint}; {f.Types} types");
        if (f.Namespaces.Count > 0) sb.Append($"; namespace: {f.Namespaces[0]}");
        if (f.EntryPoints.Count > 0) sb.Append($"; entry: {string.Join(", ", f.EntryPoints)}");
        if (f.Endpoints > 0) sb.Append($"; {f.Endpoints} HTTP endpoints");
        if (f.HostedServices.Count > 0) sb.Append($"; hosted services: {string.Join(", ", f.HostedServices)}");
        if (f.DbContexts.Count > 0) sb.Append($"; DbContexts: {string.Join(", ", f.DbContexts)}");
        if (f.Packages.Count > 0) sb.Append($"; packages: {string.Join(", ", f.Packages.Take(4))}");
        return sb.Append($"; references: {List(f.References)}; used by: {List(f.ReferencedBy)}\n").ToString();
    }
}
