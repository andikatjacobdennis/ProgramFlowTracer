using System.Globalization;
using System.Text;
using DocGen.Analysis.Commands;
using DocGen.Analysis.Diagnostics;
using DocGen.Analysis.Indexing;
using DocGen.Analysis.Investigations;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

/// <summary>Maps failure locations (file paths from another machine, type/method names) onto the repository index.</summary>
public static class FailureMapper
{
    public static (string? File, SymbolRecord? Symbol) Map(CodeIndex index, string? file, int? line, string type, string member)
    {
        string? relative = null;
        if (file is not null)
        {
            var normalized = file.Replace('\\', '/');
            // Longest matching suffix of path segments (paths in traces come from build machines).
            relative = index.Files.Keys
                .Select(k => (Key: k, Score: SuffixScore(k, normalized)))
                .Where(x => x.Score > 0).OrderByDescending(x => x.Score).FirstOrDefault().Key;
        }
        SymbolRecord? symbol = null;
        if (relative is not null && line is { } l)
        {
            symbol = index.EnclosingSymbol(relative, l);
        }
        if (symbol is null && member.Length > 0)
        {
            var typeName = type.Split('.')[^1].Split('+')[^1];
            symbol = index.Resolve(member).FirstOrDefault(s => s.Container?.EndsWith(typeName, StringComparison.Ordinal) == true)
                     ?? index.Resolve($"{typeName}.{member}").FirstOrDefault();
        }
        return (relative ?? symbol?.File, symbol);
    }

    private static int SuffixScore(string candidate, string path)
    {
        var a = candidate.Split('/');
        var b = path.Split('/');
        var score = 0;
        for (int i = a.Length - 1, j = b.Length - 1; i >= 0 && j >= 0; i--, j--)
        {
            if (!a[i].Equals(b[j], StringComparison.OrdinalIgnoreCase))
            {
                break;
            }
            score++;
        }
        return score;
    }
}

public sealed class AnalyzeStackTraceTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "analyze_stacktrace";

    public override string Description =>
        "Parses a .NET exception/stack trace (text, a blob:// reference or a file) into the exception chain (outer → innermost), maps application frames to indexed " +
        "symbols and suggests where to look. Distinguishes wrapper exceptions from the innermost (usually originating) exception.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "text": { "type": "string", "maxLength": 200000 },
            "ref": { "type": "string", "maxLength": 200 },
            "path": { "type": "string", "maxLength": 400 }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var text = await ReadInputAsync(Services, args, context, ct);
        var report = StackTraceAnalyzer.Parse(text);
        if (report.Exceptions.Count == 0)
        {
            return "No .NET exception or stack frames recognised in the input.";
        }
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        var sb = new StringBuilder("Exception chain (outer → innermost):\n");
        foreach (var e in report.Exceptions.OrderBy(e => e.Depth))
        {
            sb.AppendLine($"{new string(' ', e.Depth * 2)}{e.Depth}. {e.Type}: {AnalysisServices.Clip(e.Message.Split('\n')[0], 300)}{(e == report.Root && report.Exceptions.Count > 1 ? "   ← innermost" : "")}");
        }
        var inspected = new List<string>();
        var shown = 0;
        foreach (var e in report.Exceptions.OrderByDescending(e => e.Depth))
        {
            var appFrames = e.Frames.Where(f => !f.IsFramework).ToList();
            sb.AppendLine($"Frames of {e.Type} ({e.Frames.Count} total, {appFrames.Count} application, {e.Frames.Count - appFrames.Count} framework hidden):");
            foreach (var f in appFrames.Take(12))
            {
                var (file, symbol) = FailureMapper.Map(index, f.File, f.Line, f.Type, f.MemberName);
                sb.Append($"  at {f.Type}.{f.MemberName}{(f.IsAsyncMachinery ? " (async)" : "")}");
                sb.Append(f.Line is { } l ? $" line {l}" : "");
                sb.AppendLine(symbol is not null ? $" → {symbol.Kind} {symbol.FullName} [{symbol.File}:{symbol.StartLine}-{symbol.EndLine}]" : file is not null ? $" → {file}" : " (not in index)");
                if (symbol is not null)
                {
                    inspected.Add(symbol.File);
                }
                shown++;
            }
            if (appFrames.Count == 0 && e.Frames.Count > 0)
            {
                sb.AppendLine($"  (only framework frames; top: {e.Frames[0].Method})");
            }
        }
        sb.AppendLine("Signature: " + report.Signature);
        if (report.Exceptions.Count > 1)
        {
            sb.AppendLine("Note: outer exceptions often wrap the real fault. Start at the innermost exception's first application frame, then check where the wrapper was thrown.");
        }
        var top = report.Exceptions.OrderByDescending(e => e.Depth).SelectMany(e => e.Frames).FirstOrDefault(f => !f.IsFramework);
        if (top is not null)
        {
            sb.AppendLine($"Next: read_symbol symbol={top.Type.Split('.')[^1]}.{top.MemberName} · find_callers symbol={top.MemberName}");
        }
        await Services.TrackInspectedAsync(context, repo.Name, inspected, ct);
        await RecordFactAsync(Services, context, $"Stack trace: innermost {report.Root?.Type}: {AnalysisServices.Clip(report.Root?.Message.Split('\n')[0], 160)}" +
                                                  (top is null ? "" : $" at {top.Type}.{top.MemberName}{(top.Line is { } tl ? $" line {tl}" : "")}"), "analyze_stacktrace", ct);
        return sb.ToString();
    }

    internal static async Task<string> ReadInputAsync(AnalysisServices services, ToolArguments args, ToolExecutionContext context, CancellationToken ct, int maxChars = 2_000_000)
    {
        if (args.GetString("text") is { Length: > 0 } text)
        {
            return text;
        }
        if (args.GetString("ref") is null && args.GetString("path") is null)
        {
            throw new ValidationException("Provide 'text', 'ref' (blob://…) or 'path'.");
        }
        var (full, _) = await services.SourceAsync(args, context, ct);
        using var reader = new StreamReader(full, Encoding.UTF8);
        var buffer = new char[Math.Min(maxChars, (int)Math.Min(int.MaxValue, new FileInfo(full).Length + 1))];
        var read = await reader.ReadBlockAsync(buffer, ct);
        return new string(buffer, 0, read);
    }

    internal static async Task RecordFactAsync(AnalysisServices services, ToolExecutionContext context, string summary, string source, CancellationToken ct)
    {
        if (context.ConversationId is null)
        {
            return;
        }
        if (await services.Investigations.GetActiveForConversationAsync(context.UserId, context.ConversationId, ct) is { } active
            && active.Evidence.All(e => e.Summary != summary))
        {
            await services.Investigations.AddEvidenceAsync(context.UserId, active.Id, EvidenceKinds.Fact, summary, source, null, context.RunId, automatic: true, CancellationToken.None);
        }
    }
}

public sealed class AnalyzeBuildTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "analyze_build";

    public override string Description => "Parses build output (text, blob:// reference, file, or a finished command id) into de-duplicated errors/warnings with codes and locations mapped to indexed symbols.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "text": { "type": "string", "maxLength": 500000 },
            "ref": { "type": "string", "maxLength": 200 },
            "path": { "type": "string", "maxLength": 400 },
            "commandId": { "type": "string", "maxLength": 64 },
            "includeWarnings": { "type": "boolean" }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        BuildReport report;
        if (args.GetString("commandId") is { Length: > 0 } commandId)
        {
            var command = await Services.Commands.GetAsync(context.UserId, commandId, ct);
            report = command.Build ?? command.Tests?.Build ?? BuildOutputAnalyzer.Parse(File.Exists(Services.Commands.LogPath(context.UserId, commandId)) ? File.ReadLines(Services.Commands.LogPath(context.UserId, commandId)) : []);
        }
        else
        {
            var text = await AnalyzeStackTraceTool.ReadInputAsync(Services, args, context, ct, 20_000_000);
            report = BuildOutputAnalyzer.Parse(text.Split('\n'));
        }
        var (_, index) = await Services.IndexAsync(args, context, ct);
        var sb = new StringBuilder($"Build {report.Result}: {report.ErrorCount} errors, {report.WarningCount} warnings{(report.DurationSeconds is { } d ? $", {d:0.0} s" : "")}.\n");
        foreach (var group in report.Errors.GroupBy(e => e.Code).OrderByDescending(g => g.Count()).Take(15))
        {
            sb.AppendLine($"{group.Key} ×{group.Count()}:");
            foreach (var e in group.Take(8))
            {
                var (file, symbol) = FailureMapper.Map(index, e.File, e.Line, "", "");
                sb.AppendLine($"  {file ?? e.File ?? "(no file)"}:{e.Line}{(e.Column is { } c ? $":{c}" : "")} {AnalysisServices.Clip(e.Message, 220)}{(symbol is null ? "" : $"  ← in {symbol.FullName}")}{(e.Project is null ? "" : $" [{e.Project}]")}");
            }
        }
        if (report.RestoreProblems.Count > 0)
        {
            sb.AppendLine("Restore problems: " + string.Join("; ", report.RestoreProblems.Take(5)));
        }
        if (args.GetBool("includeWarnings") == true)
        {
            foreach (var group in report.Warnings.GroupBy(w => w.Code).OrderByDescending(g => g.Count()).Take(10))
            {
                sb.AppendLine($"warning {group.Key} ×{group.Count()}: {AnalysisServices.Clip(group.First().Message, 160)} ({group.First().File}:{group.First().Line})");
            }
        }
        if (report.ErrorCount > 0)
        {
            sb.AppendLine("Fix the first error of each code first; later errors are often consequences.");
        }
        return sb.ToString();
    }
}

public sealed class AnalyzeTestFailureTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "analyze_test_failure";

    public override string Description => "Parses dotnet test output (text, blob:// reference, file or a finished command id): failed tests with exception type, message and the first application frame, mapped to indexed symbols.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "text": { "type": "string", "maxLength": 500000 },
            "ref": { "type": "string", "maxLength": 200 },
            "path": { "type": "string", "maxLength": 400 },
            "commandId": { "type": "string", "maxLength": 64 }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        TestReport report;
        if (args.GetString("commandId") is { Length: > 0 } commandId)
        {
            var command = await Services.Commands.GetAsync(context.UserId, commandId, ct);
            report = command.Tests ?? TestOutputAnalyzer.Parse(File.Exists(Services.Commands.LogPath(context.UserId, commandId)) ? File.ReadLines(Services.Commands.LogPath(context.UserId, commandId)).ToList() : []);
        }
        else
        {
            var text = await AnalyzeStackTraceTool.ReadInputAsync(Services, args, context, ct, 20_000_000);
            report = TestOutputAnalyzer.Parse(text.Split('\n'));
        }
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        var sb = new StringBuilder($"Tests {report.Result}: {report.Passed ?? 0} passed, {report.Failed ?? report.Failures.Count} failed, {report.Skipped ?? 0} skipped{(report.Total is { } t ? $" of {t}" : "")}.\n");
        if (report.Build is { ErrorCount: > 0 } build)
        {
            sb.AppendLine($"Build errors ({build.ErrorCount}): " + string.Join("; ", build.Errors.Take(5).Select(e => $"{e.Code} {Path.GetFileName(e.File)}:{e.Line} {AnalysisServices.Clip(e.Message, 120)}")));
        }
        var inspected = new List<string>();
        foreach (var f in report.Failures.Take(20))
        {
            var test = index.Resolve(f.Name).FirstOrDefault() ?? index.Resolve(f.Name.Split('(')[0]).FirstOrDefault();
            sb.AppendLine($"FAILED {f.Name}{(test is null ? "" : $" [{test.File}:{test.StartLine}]")}");
            sb.AppendLine($"  {f.ExceptionType ?? "(no exception type)"}: {AnalysisServices.Clip(f.Message?.Replace('\n', ' '), 400)}");
            if (f.TopApplicationFrame is not null)
            {
                var parts = f.TopApplicationFrame.Split('.');
                var (file, symbol) = FailureMapper.Map(index, f.File, f.Line, string.Join('.', parts[..^1]), parts[^1]);
                sb.AppendLine($"  first application frame: {f.TopApplicationFrame}{(f.Line is { } l ? $" line {l}" : "")}{(symbol is null ? file is null ? "" : $" → {file}" : $" → {symbol.FullName} [{symbol.File}:{symbol.StartLine}]")}");
                if (symbol is not null)
                {
                    inspected.Add(symbol.File);
                }
            }
        }
        if (TestFailure.WrongReasonNote(report.Failures) is { } wrongReason)
        {
            sb.AppendLine(wrongReason);
        }
        if (report.Failures.Count > 20)
        {
            sb.AppendLine($"… {report.Failures.Count - 20} more failures.");
        }
        await Services.TrackInspectedAsync(context, repo.Name, inspected, ct);
        if (report.Failures.FirstOrDefault() is { } first)
        {
            await AnalyzeStackTraceTool.RecordFactAsync(Services, context, $"Test failure: {first.Name} — {first.ExceptionType}: {AnalysisServices.Clip(first.Message?.Split('\n')[0], 160)}" +
                                                                         (first.TopApplicationFrame is null ? "" : $" at {first.TopApplicationFrame}{(first.Line is { } fl ? $" line {fl}" : "")}"), "analyze_test_failure", ct);
        }
        return sb.ToString();
    }
}

public sealed class LogSummaryTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "log_summary";

    public override string Description =>
        "Streams a log file of any size (path or blob:// reference) and summarises it: levels, time range, message signatures grouped with counts and first/last " +
        "occurrence, exception types, correlation/thread ids and an error timeline. Use log_search to expand a group (signature id) progressively.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "path": { "type": "string", "maxLength": 400 },
            "ref": { "type": "string", "maxLength": 200 },
            "top": { "type": "integer", "minimum": 1, "maximum": 60 }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (full, label) = await Services.SourceAsync(args, context, ct);
        var summary = await Task.Run(() => LogAnalyzer.Summarize(full, Clamp(args.GetInt("top"), 20, 1, 60), ct), ct);
        var sb = new StringBuilder();
        sb.AppendLine($"{label}: {summary.Bytes:N0} bytes, {summary.Lines:N0} lines, {summary.Entries:N0} entries, analysed in {summary.ElapsedMs:N0} ms.");
        sb.AppendLine("Levels: " + string.Join(", ", summary.Levels.OrderByDescending(l => LogAnalyzer.Rank(l.Key)).Select(l => $"{l.Key} {l.Value:N0}")));
        if (summary.From is { } from)
        {
            sb.AppendLine($"Time range: {from:yyyy-MM-dd HH:mm:ss.fff} → {summary.To:yyyy-MM-dd HH:mm:ss.fff} ({(summary.To - from)?.TotalMinutes:0.#} min)");
        }
        sb.AppendLine($"{summary.DistinctSignatures:N0} distinct message signatures{(summary.SignaturesCapped ? " (capped; rarer ones merged)" : "")}. Top groups (severity, then count):");
        foreach (var g in summary.Groups)
        {
            sb.AppendLine($"- [{g.Id}] {g.Level.ToUpperInvariant()} ×{g.Count:N0} lines {g.FirstLine:N0}…{g.LastLine:N0}{(g.FirstSeen is { } fs ? $" ({fs:HH:mm:ss} → {g.LastSeen:HH:mm:ss})" : "")}{(g.ExceptionType is null ? "" : $" {g.ExceptionType}")}");
            sb.AppendLine($"    {AnalysisServices.Clip(g.Signature, 220)}");
            if (g.CorrelationIds.Count > 0)
            {
                sb.AppendLine($"    correlation ids: {string.Join(", ", g.CorrelationIds)}");
            }
        }
        if (summary.TopCorrelationIds.Count > 0)
        {
            sb.AppendLine("Correlation ids with most warnings/errors: " + string.Join(", ", summary.TopCorrelationIds.Take(5).Select(c => $"{c.Id} ({c.Errors})")));
        }
        if (summary.ErrorTimeline.Count > 0)
        {
            sb.AppendLine("Error timeline: " + string.Join(" ", summary.ErrorTimeline.Take(24).Select(b => $"{b.Start:HH:mm}={b.Errors}")));
        }
        sb.AppendLine("Expand with log_search signature=<id> (context lines, skip/limit) or a correlationId.");
        return sb.ToString();
    }
}

public sealed class LogSearchTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "log_search";

    public override string Description =>
        "Searches a large log (path or blob:// reference) by text, regex, minimum level, correlation id, signature id (from log_summary) or time window, with context lines " +
        "and paging (skip/limit). With lineStart it reads a raw line range instead.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "path": { "type": "string", "maxLength": 400 },
            "ref": { "type": "string", "maxLength": 200 },
            "text": { "type": "string", "maxLength": 300 },
            "regex": { "type": "string", "maxLength": 300 },
            "level": { "type": "string", "enum": ["trace", "debug", "info", "warning", "error", "fatal"] },
            "correlationId": { "type": "string", "maxLength": 100 },
            "signature": { "type": "string", "maxLength": 16 },
            "from": { "type": "string", "maxLength": 40 },
            "to": { "type": "string", "maxLength": 40 },
            "context": { "type": "integer", "minimum": 0, "maximum": 20 },
            "limit": { "type": "integer", "minimum": 1, "maximum": 200 },
            "skip": { "type": "integer", "minimum": 0 },
            "lineStart": { "type": "integer", "minimum": 1 },
            "lineCount": { "type": "integer", "minimum": 1, "maximum": 500 }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (full, label) = await Services.SourceAsync(args, context, ct);
        if (args.GetInt("lineStart") is { } start)
        {
            var (lines, total) = await Task.Run(() => LogAnalyzer.ReadLines(full, start, Clamp(args.GetInt("lineCount"), 100, 1, 500), ct), ct);
            var sb = new StringBuilder($"{label} lines {start}–{start + lines.Count - 1} of {total:N0}:\n");
            foreach (var (n, text) in lines)
            {
                sb.AppendLine($"{n,8}: {text}");
            }
            return sb.ToString();
        }
        var options = new LogSearchOptions
        {
            Text = args.GetString("text"),
            Regex = args.GetString("regex"),
            MinimumLevel = args.GetString("level"),
            CorrelationId = args.GetString("correlationId"),
            SignatureId = args.GetString("signature"),
            From = ParseTime(args.GetString("from")),
            To = ParseTime(args.GetString("to")),
            ContextLines = args.GetInt("context") ?? 0,
            Limit = Clamp(args.GetInt("limit"), 30, 1, 200),
            Skip = Math.Max(0, args.GetInt("skip") ?? 0),
        };
        if (options.Text is null && options.Regex is null && options.MinimumLevel is null && options.CorrelationId is null && options.SignatureId is null && options.From is null && options.To is null)
        {
            throw new ValidationException("Give at least one filter (text, regex, level, correlationId, signature, from/to) or a lineStart.");
        }
        LogSearchResult result;
        try
        {
            result = await Task.Run(() => LogAnalyzer.Search(full, options, ct), ct);
        }
        catch (ArgumentException ex)
        {
            throw new ValidationException("Invalid regular expression: " + ex.Message);
        }
        var output = new StringBuilder($"{result.TotalMatches:N0} matching entries in {result.ScannedLines:N0} lines; showing {result.Matches.Count} from #{options.Skip + 1}:\n");
        foreach (var match in result.Matches)
        {
            foreach (var (n, text) in match.Lines)
            {
                output.AppendLine($"{(n == match.Line ? ">" : " ")}{n,8}: {AnalysisServices.Clip(text, 600)}");
            }
            if (options.ContextLines > 0)
            {
                output.AppendLine("  ---");
            }
        }
        if (result.TotalMatches > options.Skip + result.Matches.Count)
        {
            output.AppendLine($"Next page: skip={options.Skip + result.Matches.Count}");
        }
        return output.ToString();
    }

    private static DateTimeOffset? ParseTime(string? value)
        => value is { Length: > 0 } && DateTimeOffset.TryParse(value, CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var t) ? t
            : value is { Length: > 0 } ? throw new ValidationException($"Could not parse time '{value}'.") : null;
}

public sealed class BlobReadTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "blob_read";

    public override string Description =>
        "Reads a stored large output (blob:// or runtime-object:// reference) progressively: metadata, a line range, or lines matching a search with context.";

    public override string InputSchema => """
        {
          "type": "object",
          "properties": {
            "ref": { "type": "string", "minLength": 10, "maxLength": 200 },
            "lineStart": { "type": "integer", "minimum": 1 },
            "lineCount": { "type": "integer", "minimum": 1, "maximum": 500 },
            "search": { "type": "string", "maxLength": 300 },
            "context": { "type": "integer", "minimum": 0, "maximum": 20 },
            "limit": { "type": "integer", "minimum": 1, "maximum": 200 }
          },
          "required": ["ref"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var reference = args.RequireString("ref");
        var info = await Services.Blobs.GetInfoAsync(context.UserId, reference, ct) ?? throw new NotFoundException("Blob");
        var path = Services.Blobs.GetContentPath(context.UserId, reference)!;
        var header = $"{info.Reference}: {info.Kind}, {info.SizeBytes:N0} bytes, {info.LineCount:N0} lines, ~{info.EstimatedTokens:N0} tokens{(info.Source is null ? "" : $", from {info.Source}")}.\n";
        if (args.GetString("search") is { Length: > 0 } search)
        {
            var result = LogAnalyzer.Search(path, new LogSearchOptions { Text = search, ContextLines = args.GetInt("context") ?? 1, Limit = Clamp(args.GetInt("limit"), 30, 1, 200) }, ct);
            var sb = new StringBuilder(header + $"{result.TotalMatches:N0} lines match '{search}':\n");
            foreach (var match in result.Matches)
            {
                foreach (var (n, text) in match.Lines)
                {
                    sb.AppendLine($"{(n == match.Line ? ">" : " ")}{n,8}: {AnalysisServices.Clip(text, 600)}");
                }
            }
            return sb.ToString();
        }
        var start = args.GetInt("lineStart") ?? 1;
        var (lines, total) = LogAnalyzer.ReadLines(path, start, Clamp(args.GetInt("lineCount"), 120, 1, 500), ct);
        var output = new StringBuilder(header + $"Lines {start}–{start + lines.Count - 1} of {total:N0}:\n");
        foreach (var (n, text) in lines)
        {
            output.AppendLine($"{n,8}: {AnalysisServices.Clip(text, 1000)}");
        }
        return output.ToString();
    }
}
