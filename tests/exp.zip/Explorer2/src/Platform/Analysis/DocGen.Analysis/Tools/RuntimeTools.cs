using System.Globalization;
using System.Text;
using DocGen.Analysis.Browser;
using DocGen.Analysis.Commands;
using DocGen.Analysis.Execution;
using DocGen.Analysis.Indexing;
using DocGen.Analysis.Repositories;
using DocGen.Analysis.Runtime;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

public abstract class RuntimeToolBase(AnalysisServices services) : AnalysisTool(services)
{
    protected static ProjectInfo Project(CodeIndex index, string? name)
        => (name is { Length: > 0 }
               ? index.Projects.Values.FirstOrDefault(p => p.Name.Equals(name, StringComparison.OrdinalIgnoreCase) || p.Path.Replace('\\', '/').Equals(name.Replace('\\', '/'), StringComparison.OrdinalIgnoreCase))
               : index.Projects.Values.Where(p => !p.IsTestProject).OrderByDescending(p => p.Sdk?.Contains("Web", StringComparison.OrdinalIgnoreCase) == true).ThenBy(p => p.OutputType == "Exe" ? 0 : 1).FirstOrDefault())
           ?? throw new NotFoundException(name is null ? "Runnable project (pass 'project')" : $"Project '{name}'");

    /// <summary>Installed runtimes and the dev-certificate state, from fixed read-only dotnet commands.</summary>
    protected async Task<RuntimeFacts> FactsAsync(RepositoryHandle repo, ToolExecutionContext context, bool https, CancellationToken ct)
    {
        List<string>? runtimes = null;
        bool? cert = null;
        if (Services.Executables.IsAllowed("dotnet"))
        {
            var dotnet = Services.Executables.Resolve("dotnet");
            ProcessLaunch Launch(List<string> args, string description) => new()
            {
                Kind = CommandKinds.Process, ExecutableName = dotnet.Name, ExecutablePath = dotnet.Path, Arguments = args, WorkingDirectory = repo.Root,
                Repository = repo.Name, DisplayCommand = "dotnet " + string.Join(' ', args), Description = description, TimeoutSeconds = 60,
                RunId = context.RunId, ConversationId = context.ConversationId, Risk = "ReadOnly",
            };
            var (record, bytes) = await Services.Commands.RunCaptureAsync(context.UserId, Launch(["--list-runtimes"], "List installed .NET runtimes"), 256 * 1024, ct);
            if (record.Status == CommandStatus.Succeeded)
            {
                runtimes = Encoding.UTF8.GetString(bytes).Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Select(l => string.Join(' ', l.Split(' ').Take(2))).ToList();
            }
            if (https)
            {
                var (check, _) = await Services.Commands.RunCaptureAsync(context.UserId, Launch(["dev-certs", "https", "--check", "--trust"], "Check the HTTPS development certificate"), 64 * 1024, ct);
                cert = check.Status is CommandStatus.Succeeded ? true : check.Status is CommandStatus.Failed ? false : null;
            }
        }
        return new RuntimeFacts { Runtimes = runtimes, DevCertificateTrusted = cert };
    }

    protected static string Render(ReadinessReport report)
    {
        var sb = new StringBuilder();
        sb.AppendLine(CultureInfo.InvariantCulture, $"Dependency readiness — {report.Project}: {report.Items.Count(i => i.Mark == "✓")} ✓ · {report.Items.Count(i => i.Mark == "⚠")} ⚠ · {report.Items.Count(i => i.Mark == "✗")} ✗ · {report.Items.Count(i => i.Mark == "?")} ?");
        foreach (var group in report.Items.GroupBy(i => i.Category))
        {
            foreach (var item in group)
            {
                sb.AppendLine(CultureInfo.InvariantCulture, $"  {item.Mark} {item.Category,-12} {item.Name}: {item.Detail}");
            }
        }
        sb.AppendLine(report.Blocked ? "Blocked: resolve the ✗ items before running the application." : "No blocking problems found (⚠ items may still fail at runtime; ? items were not checked).");
        return sb.ToString();
    }
}

public sealed class CheckReadinessTool(AnalysisServices services) : RuntimeToolBase(services)
{
    public override string Name => "check_readiness";

    public override string Description =>
        "Checks whether a project can run: .NET runtime for its target framework, launchSettings ports (in use?), HTTPS development certificate, " +
        "appsettings files and configuration keys the code reads but nothing defines, environment variables the code reads, databases from connection " +
        "strings, external service URLs and configured file paths. Marks each ✓ ready, ⚠ warning, ✗ blocking or ? unknown. Only loopback endpoints are " +
        "probed; remote hosts are never contacted and connection strings are never shown.";

    public override string InputSchema => $$"""
        { "type": "object", "properties": { {{RepositoryProperty}}, "project": { "type": "string", "maxLength": 300 } }, "additionalProperties": false }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        var project = Project(index, args.GetString("project"));
        var https = File.Exists(Path.Combine(repo.Root, project.Directory, "Properties", "launchSettings.json"))
                    && File.ReadAllText(Path.Combine(repo.Root, project.Directory, "Properties", "launchSettings.json")).Contains("https://", StringComparison.OrdinalIgnoreCase);
        var facts = await FactsAsync(repo, context, https, ct);
        return Render(ReadinessChecker.Check(index, repo.Root, project, facts));
    }
}

/// <summary>Build → run → verify, with distinct states; never claims "works" from a build alone.</summary>
public sealed class PostBuildReportTool(AnalysisServices services) : RuntimeToolBase(services), IDynamicRiskTool
{
    public static readonly string[] States = ["COMPILES", "TESTS PASS", "STARTS", "HEALTHY", "SMOKE VERIFIED", "BROWSER VERIFIED"];

    public override string Name => "post_build_report";

    public override string Description =>
        "Build → run → verify for a runnable project, reported as distinct states: COMPILES (build), TESTS PASS (its test projects), STARTS (dev server " +
        "process alive with a confirmed URL), HEALTHY (health endpoint or root answers), SMOKE VERIFIED (key routes answer without 5xx and no fatal " +
        "startup errors), BROWSER VERIFIED (optional: page loads in the headless browser without console errors). Checks dependency readiness first and " +
        "starts the app only if the build succeeded and nothing blocks it. Stops the server afterwards unless keepRunning=true.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "project": { "type": "string", "maxLength": 300 },
            "tests": { "type": "boolean", "description": "Run the project's test projects (default true)." },
            "start": { "type": "boolean", "description": "Start and verify the running app (default true)." },
            "browser": { "type": "boolean", "description": "Also verify in the headless browser (default false)." },
            "paths": { "type": "array", "items": { "type": "string", "maxLength": 200 }, "maxItems": 20, "description": "Smoke paths (default: health, auth page, key API, /)." },
            "keepRunning": { "type": "boolean" }
          },
          "additionalProperties": false
        }
        """;

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.External;

    public Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken)
    {
        var args = ToolArguments.Parse(call);
        return Task.FromResult(args.GetBool("start") == false
            ? new ToolRiskAssessment(ToolRiskLevel.Sensitive, Capabilities.ExecuteProcess, ["builds and tests (dotnet build/test)"], Summary: "Build and test")
            : new ToolRiskAssessment(ToolRiskLevel.External, Capabilities.ManageDevelopmentServer,
                [(args.GetBool("tests") == false ? "builds" : "builds, tests") + " and starts the application as a development server on a loopback port"
                 + (args.GetBool("browser") == true ? ", then opens it in the headless browser" : "")],
                Summary: "Build, run and verify"));
    }

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        if (!repo.AllowCommands)
        {
            throw new ForbiddenException($"Commands are not enabled for repository '{repo.Name}'.");
        }
        var project = Project(index, args.GetString("project"));
        var reached = new Dictionary<string, (string Mark, string Detail)>(StringComparer.Ordinal);
        foreach (var s in States)
        {
            reached[s] = ("–", "not run");
        }
        var sb = new StringBuilder();
        var budget = TimeSpan.FromSeconds(Math.Max(20, Services.AgentOptions.ToolTimeoutSeconds - 10));
        var started = DateTime.UtcNow;
        TimeSpan Left() => budget - (DateTime.UtcNow - started);

        // COMPILES
        var build = await Services.Commands.StartAsync(context.UserId, repo, new CommandRequest { Kind = CommandKinds.Build, Target = project.Path, RunId = context.RunId, ConversationId = context.ConversationId }, ct);
        build = await Services.Commands.WaitAsync(context.UserId, build.Id, Left(), ct);
        var compiles = build.Status == CommandStatus.Succeeded;
        reached["COMPILES"] = !build.IsFinal ? ("…", $"build still running (command {build.Id})")
            : compiles ? ("✓", $"build succeeded: {build.Build?.ErrorCount ?? 0} errors, {build.Build?.WarningCount ?? 0} warnings ({build.DurationMs / 1000.0:0.0} s)")
            : ("✗", $"build failed: {build.Build?.ErrorCount ?? 0} errors — {string.Join("; ", build.Build?.Errors.Take(3).Select(e => $"{e.Code} {e.File}:{e.Line} {e.Message}") ?? [])}");

        // TESTS PASS
        if (compiles && args.GetBool("tests") != false)
        {
            var testProjects = index.Projects.Values.Where(p => p.IsTestProject && index.ProjectReferencesOf(p.Name).Contains(project.Name, StringComparer.OrdinalIgnoreCase)).ToList();
            if (testProjects.Count == 0)
            {
                reached["TESTS PASS"] = ("–", "no test project references this project");
            }
            else
            {
                int passed = 0, failed = 0;
                var ok = true;
                foreach (var tp in testProjects)
                {
                    var test = await Services.Commands.StartAsync(context.UserId, repo, new CommandRequest { Kind = CommandKinds.Test, Target = tp.Path, RunId = context.RunId, ConversationId = context.ConversationId }, ct);
                    test = await Services.Commands.WaitAsync(context.UserId, test.Id, Left() > TimeSpan.FromSeconds(5) ? Left() : TimeSpan.FromSeconds(5), ct);
                    if (!test.IsFinal)
                    {
                        reached["TESTS PASS"] = ("…", $"tests still running (command {test.Id}); check with command_status");
                        ok = false;
                        break;
                    }
                    passed += test.Tests?.Passed ?? 0;
                    failed += test.Tests?.Failed ?? test.Tests?.Failures.Count ?? 0;
                    ok &= test.Status == CommandStatus.Succeeded && (test.Tests?.Failed ?? 0) == 0;
                }
                if (reached["TESTS PASS"].Mark != "…")
                {
                    reached["TESTS PASS"] = ok ? ("✓", $"{passed} passed in {testProjects.Count} test project(s)") : ("✗", $"{failed} failed, {passed} passed");
                }
            }
        }

        // Readiness, then STARTS / HEALTHY / SMOKE / BROWSER.
        ReadinessReport? readiness = null;
        if (compiles && args.GetBool("start") != false)
        {
            var launch = Path.Combine(repo.Root, project.Directory, "Properties", "launchSettings.json");
            var https = File.Exists(launch) && File.ReadAllText(launch).Contains("https://", StringComparison.OrdinalIgnoreCase);
            readiness = ReadinessChecker.Check(index, repo.Root, project, await FactsAsync(repo, context, https, ct));
            var servers = Services.Service<DevServerService>();
            if (readiness.Blocked)
            {
                reached["STARTS"] = ("–", "not started: dependency readiness has blocking problems");
            }
            else if (servers is null)
            {
                reached["STARTS"] = ("–", "development servers are not available in this host");
            }
            else
            {
                DevServerRecord? server = null;
                try
                {
                    server = await servers.StartAsync(context.UserId, new DevServerStartRequest
                    {
                        Repository = repo.Name, Project = project.Path, NoBuild = true, Name = "post-build " + project.Name,
                        ApplicationArguments = ["--urls", "http://127.0.0.1:0"],
                    }, context.RunId, context.ConversationId, context.ProjectId, TimeSpan.FromSeconds(Math.Clamp(Left().TotalSeconds, 5, 60)), ct);
                    server = await servers.StatusAsync(context.UserId, server.ServerId, ct);
                    var alive = server.Status is DevServerStatus.Running or DevServerStatus.Starting && server.Url is not null;
                    reached["STARTS"] = alive ? ("✓", $"process alive, listening on {server.Url} ({server.UrlSource})")
                        : ("✗", $"status {server.Status}{(server.ExitCode is { } code ? $", exit code {code}" : "")}; {string.Join("; ", server.Notes.TakeLast(2))}");
                    if (alive)
                    {
                        var root = server.Url!.TrimEnd('/');
                        var endpoints = index.Endpoints.Where(e => e.Verb.Equals("GET", StringComparison.OrdinalIgnoreCase) && !e.Route.Contains('{', StringComparison.Ordinal))
                            .Select(e => "/" + e.Route.TrimStart('/')).Distinct().ToList();
                        var health = endpoints.FirstOrDefault(r => r.Contains("health", StringComparison.OrdinalIgnoreCase));
                        var healthResult = await DevServerService.ProbeAsync(root + (health ?? "/"), ct);
                        reached["HEALTHY"] = healthResult is "HTTP 200" or "HTTP 204" ? ("✓", $"{health ?? "/"} → {healthResult}")
                            : healthResult is null ? ("✗", $"{health ?? "/"} did not answer") : healthResult.StartsWith("HTTP 5", StringComparison.Ordinal) ? ("✗", $"{health ?? "/"} → {healthResult}") : ("⚠", $"{health ?? "/"} → {healthResult}");

                        var paths = args.GetStringArray("paths").Where(p => p.StartsWith('/')).ToList();
                        if (paths.Count == 0)
                        {
                            paths = new[] { health, endpoints.FirstOrDefault(r => r.Contains("login", StringComparison.OrdinalIgnoreCase)), endpoints.FirstOrDefault(r => r.StartsWith("/api", StringComparison.OrdinalIgnoreCase) && r != health), "/" }
                                .OfType<string>().Distinct().ToList();
                        }
                        var smoke = new List<string>();
                        var smokeOk = true;
                        foreach (var path in paths)
                        {
                            var result = await DevServerService.ProbeAsync(root + path, ct);
                            smoke.Add($"{path} → {result ?? "no answer"}");
                            smokeOk &= result is not null && !result.StartsWith("HTTP 5", StringComparison.Ordinal);
                        }
                        var log = Services.Commands.ReadOutput(context.UserId, server.CommandId, 0, 2000).Lines.Select(l => l.Text).ToList();
                        var fatal = log.Where(l => l.Contains("crit:", StringComparison.OrdinalIgnoreCase) || l.Contains("Unhandled exception", StringComparison.OrdinalIgnoreCase)
                                                   || l.Contains("[FTL]", StringComparison.Ordinal) || l.Contains("[ERR]", StringComparison.Ordinal) || l.Contains("fail:", StringComparison.Ordinal)).Take(3).ToList();
                        smokeOk &= fatal.Count == 0;
                        reached["SMOKE VERIFIED"] = smokeOk ? ("✓", string.Join(", ", smoke) + "; no fatal startup errors")
                            : ("✗", string.Join(", ", smoke) + (fatal.Count > 0 ? "; startup errors: " + string.Join(" | ", fatal.Select(f => AnalysisServices.Clip(f, 160))) : ""));

                        if (args.GetBool("browser") == true && smokeOk)
                        {
                            var browser = Services.Service<BrowserService>();
                            if (browser is null)
                            {
                                reached["BROWSER VERIFIED"] = ("–", "browser automation is not available");
                            }
                            else
                            {
                                var tab = await browser.OpenAsync(context.UserId, context.RunId, root + "/", newTab: true, ct);
                                await browser.WaitAsync(context.UserId, tab.TabId, "load", null, 15, ct);
                                var (console, network) = await browser.DiagnosticsAsync(context.UserId, tab.TabId, clear: false, ct);
                                var errors = console.Where(c => c.Level == "error").ToList();
                                var failedRequests = network.Where(n => n.Status is >= 500 || n.Error is not null).ToList();
                                reached["BROWSER VERIFIED"] = errors.Count == 0 && failedRequests.Count == 0
                                    ? ("✓", $"\"{tab.Title}\" loaded at {tab.Url} with no console errors")
                                    : ("✗", $"{errors.Count} console error(s){(errors.Count > 0 ? ": " + AnalysisServices.Clip(errors[0].Text, 160) : "")}; {failedRequests.Count} failed request(s)");
                                await browser.CloseAsync(context.UserId, tab.TabId, ct);
                            }
                        }
                    }
                }
                finally
                {
                    if (server is not null && args.GetBool("keepRunning") != true)
                    {
                        await servers.StopAsync(context.UserId, server.ServerId, CancellationToken.None);
                    }
                }
                if (server is not null && args.GetBool("keepRunning") == true)
                {
                    sb.AppendLine(CultureInfo.InvariantCulture, $"Server {server.ServerId} kept running at {server.Url}.");
                }
            }
        }

        var report = new StringBuilder();
        report.AppendLine(CultureInfo.InvariantCulture, $"Post-Build Report — {project.Name} ({project.Path})");
        foreach (var s in States)
        {
            report.AppendLine(CultureInfo.InvariantCulture, $"  {reached[s].Mark} {s,-16} {reached[s].Detail}");
        }
        if (readiness is not null)
        {
            report.AppendLine($"Readiness: {readiness.Items.Count(i => i.Mark == "✓")} ✓ · {readiness.Items.Count(i => i.Mark == "⚠")} ⚠ · {readiness.Items.Count(i => i.Mark == "✗")} ✗ · {readiness.Items.Count(i => i.Mark == "?")} ?" +
                (readiness.Items.Any(i => i.Mark is "✗" or "⚠") ? " — " + string.Join("; ", readiness.Items.Where(i => i.Mark is "✗" or "⚠").Take(5).Select(i => $"{i.Mark} {i.Name}: {i.Detail}")) : ""));
        }
        var verified = States.Where(s => reached[s].Mark == "✓").ToList();
        var notVerified = States.Where(s => reached[s].Mark != "✓").ToList();
        report.AppendLine(verified.Count switch
        {
            0 => "Verified: nothing — the project does not compile (or the build did not finish).",
            1 when verified[0] == "COMPILES" => "Verified: COMPILES only. That does not show the application works.",
            _ => $"Verified: {string.Join(" · ", verified)}." + (notVerified.Count > 0 ? $" Not verified: {string.Join(", ", notVerified)}." : "") +
                 " Only the states marked ✓ were verified; nothing beyond them is claimed.",
        });
        report.Append(sb);
        return report.ToString();
    }
}
