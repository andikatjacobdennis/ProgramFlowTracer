using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using DocGen.Analysis.Commands;
using DocGen.Analysis.Repositories;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

public sealed record LineEndingStats(long Lines, long Crlf, long Lf, long Cr, bool FinalNewline, bool Bom, bool Binary)
{
    public string Style => Binary ? "binary" : Crlf > 0 && Lf == 0 && Cr == 0 ? "CRLF" : Lf > 0 && Crlf == 0 && Cr == 0 ? "LF" : Crlf == 0 && Lf == 0 && Cr == 0 ? "none" : "mixed";

    public static LineEndingStats Of(ReadOnlySpan<byte> bytes)
    {
        long crlf = 0, lf = 0, cr = 0;
        var binary = false;
        for (var i = 0; i < bytes.Length; i++)
        {
            var b = bytes[i];
            if (b == 0)
            {
                binary = true;
            }
            if (b == (byte)'\r')
            {
                if (i + 1 < bytes.Length && bytes[i + 1] == (byte)'\n')
                {
                    crlf++;
                    i++;
                }
                else
                {
                    cr++;
                }
            }
            else if (b == (byte)'\n')
            {
                lf++;
            }
        }
        var final = bytes.Length > 0 && bytes[^1] is (byte)'\n' or (byte)'\r';
        var lines = crlf + lf + cr + (bytes.Length > 0 && !final ? 1 : 0);
        var bom = bytes.Length >= 3 && bytes[0] == 0xEF && bytes[1] == 0xBB && bytes[2] == 0xBF;
        return new LineEndingStats(lines, crlf, lf, cr, final, bom, binary);
    }
}

/// <summary>Deterministic line-ending report for a file, optionally compared with Git HEAD.</summary>
public sealed class LineEndingsTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "line_endings";

    public override string Description =>
        "Counts line endings in a file (total lines, CRLF, LF-only, CR-only, final newline, BOM) and, where Git is available, compares with the committed " +
        "version at HEAD to tell whether an edit converted the line-ending style. Native and deterministic — no shell pipeline needed.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "path": { "type": "string", "minLength": 1, "maxLength": 500 },
            "compareHead": { "type": "boolean", "description": "Default true when the file is in a Git repository and git is allow-listed." }
          },
          "required": ["path"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var repo = await Services.RepositoryAsync(args, context, ct);
        var full = repo.Resolve(args.RequireString("path"));
        if (!File.Exists(full))
        {
            throw new NotFoundException("File");
        }
        if (new FileInfo(full).Length > 256L * 1024 * 1024)
        {
            throw new ValidationException("The file is larger than 256 MB.");
        }
        var current = LineEndingStats.Of(await File.ReadAllBytesAsync(full, ct));
        var shown = repo.Relative(full).Replace('\\', '/');
        var sb = new StringBuilder($"Line endings — {repo.Name}:{shown}\n");
        sb.AppendLine("Current:");
        Append(sb, current);

        if (args.GetBool("compareHead") != false)
        {
            var head = await HeadAsync(repo, full, context, ct);
            if (head.Bytes is { } bytes)
            {
                var committed = LineEndingStats.Of(bytes);
                sb.AppendLine("HEAD:");
                Append(sb, committed);
                sb.AppendLine("Result:");
                sb.AppendLine(current.Binary || committed.Binary ? "  Binary content; line endings are not meaningful."
                    : current.Style == committed.Style ? $"  No line-ending conversion detected ({current.Style} in both)."
                    : $"  Line-ending style changed: HEAD {committed.Style} → current {current.Style}." +
                      (current.Style == "mixed" ? " The file now mixes styles (likely a partial conversion by an edit)." : ""));
                if (current.Bom != committed.Bom)
                {
                    sb.AppendLine($"  BOM changed: HEAD {(committed.Bom ? "with" : "without")} → current {(current.Bom ? "with" : "without")}.");
                }
            }
            else
            {
                sb.AppendLine("HEAD: " + head.Note);
            }
        }
        await Services.TrackInspectedAsync(context, repo.Name, [shown], ct);
        return sb.ToString();
    }

    private static void Append(StringBuilder sb, LineEndingStats s)
        => sb.AppendLine($"  lines {s.Lines:N0} · CRLF {s.Crlf:N0} · LF {s.Lf:N0} · CR {s.Cr:N0} · style {s.Style} · final newline {(s.FinalNewline ? "yes" : "no")} · BOM {(s.Bom ? "yes" : "no")}");

    private async Task<(byte[]? Bytes, string Note)> HeadAsync(RepositoryHandle repo, string full, ToolExecutionContext context, CancellationToken ct)
    {
        var gitRoot = FindGitRoot(Path.GetDirectoryName(full)!, repo.Root);
        if (gitRoot is null)
        {
            return (null, "not a Git working tree; no comparison.");
        }
        if (!Services.Executables.IsAllowed("git"))
        {
            return (null, "git is not allow-listed (DocGen:Execution:Executables); no comparison.");
        }
        var git = Services.Executables.Resolve("git");
        var relativeToGit = Path.GetRelativePath(gitRoot, full).Replace('\\', '/');
        var (record, bytes) = await Services.Commands.RunCaptureAsync(context.UserId, new ProcessLaunch
        {
            Kind = CommandKinds.Process, ExecutableName = git.Name, ExecutablePath = git.Path,
            Arguments = ["-c", "core.autocrlf=false", "cat-file", "blob", "HEAD:" + relativeToGit], WorkingDirectory = gitRoot,
            DisplayWorkingDirectory = repo.Relative(gitRoot).Replace('\\', '/') is { Length: > 0 } d ? d : ".", Repository = repo.Name,
            DisplayCommand = $"git cat-file blob HEAD:{relativeToGit}", Description = "Read committed file for line-ending comparison",
            TimeoutSeconds = 60, RunId = context.RunId, ConversationId = context.ConversationId, Risk = "ReadOnly",
        }, 256 * 1024 * 1024, ct);
        return record.Status == CommandStatus.Succeeded ? (bytes, "") : (null, $"not in HEAD or git failed ({record.Status}, command {record.Id}).");
    }

    private static string? FindGitRoot(string start, string repoRoot)
    {
        for (var dir = new DirectoryInfo(start); dir is not null; dir = dir.Parent)
        {
            if (Directory.Exists(Path.Combine(dir.FullName, ".git")) || File.Exists(Path.Combine(dir.FullName, ".git")))
            {
                return dir.FullName;
            }
            if (string.Equals(dir.FullName.TrimEnd(Path.DirectorySeparatorChar), Path.GetFullPath(repoRoot).TrimEnd(Path.DirectorySeparatorChar), StringComparison.OrdinalIgnoreCase))
            {
                // Only look above the repository root if the repository itself is inside a Git working tree.
                continue;
            }
        }
        return null;
    }
}

/// <summary>Native, bounded file-system diagnostics (no shell): counts, sizes, largest/recent files, duplicates, tree, timestamps.</summary>
public sealed class DirectoryStatsTool(AnalysisServices services) : AnalysisTool(services)
{
    private const int MaxFiles = 300_000;

    public override string Name => "directory_stats";

    public override string Description =>
        "File-system diagnostics computed natively: mode=summary (file/dir counts, total size, per-extension counts and sizes), largest, recent (recently " +
        "modified), duplicates (identical content by SHA-256), tree (per-directory counts and sizes to a depth), timestamps (created/modified/size for matching " +
        "files). Filter with a glob 'pattern' such as *.cs. bin/obj/.git and other excluded folders are skipped unless includeExcluded=true.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "path": { "type": "string", "maxLength": 500, "description": "Directory (default: repository root)." },
            "mode": { "type": "string", "enum": ["summary", "largest", "recent", "duplicates", "tree", "timestamps"] },
            "pattern": { "type": "string", "maxLength": 100, "description": "File name glob, e.g. *.cs or *.json." },
            "limit": { "type": "integer", "minimum": 1, "maximum": 500 },
            "depth": { "type": "integer", "minimum": 1, "maximum": 6 },
            "sinceHours": { "type": "number", "minimum": 0 },
            "includeExcluded": { "type": "boolean" }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var repo = await Services.RepositoryAsync(args, context, ct);
        var root = string.IsNullOrWhiteSpace(args.GetString("path")) ? repo.Root : repo.Resolve(args.GetString("path"));
        if (!Directory.Exists(root))
        {
            throw new NotFoundException("Directory");
        }
        var mode = args.GetString("mode") ?? "summary";
        var limit = Clamp(args.GetInt("limit"), 20, 1, 500);
        var pattern = args.GetString("pattern");
        var regex = pattern is { Length: > 0 } ? new Regex("^" + Regex.Escape(pattern).Replace("\\*", ".*").Replace("\\?", ".") + "$", RegexOptions.IgnoreCase) : null;
        var excluded = args.GetBool("includeExcluded") == true ? [] : Services.Options.ExcludedDirectories.ToHashSet(StringComparer.OrdinalIgnoreCase);
        var (files, dirs, truncated) = await Task.Run(() => Enumerate(root, excluded, regex, ct), ct);
        var shownRoot = repo.Relative(root).Replace('\\', '/') is { Length: > 0 } r ? r : ".";
        string Rel(string f) => Path.GetRelativePath(root, f).Replace('\\', '/');
        var sb = new StringBuilder($"{mode} of {repo.Name}:{shownRoot}{(pattern is null ? "" : $" ({pattern})")}: {files.Count:N0} files, {dirs:N0} directories, {Size(files.Sum(f => f.Length))}{(truncated ? $" (stopped at {MaxFiles:N0} files)" : "")}\n");

        switch (mode)
        {
            case "summary":
                foreach (var g in files.GroupBy(f => f.Extension.Length == 0 ? "(none)" : f.Extension.ToLowerInvariant()).OrderByDescending(g => g.Count()).Take(limit))
                {
                    sb.AppendLine($"  {g.Key,-12} {g.Count(),8:N0} files  {Size(g.Sum(f => f.Length)),10}");
                }
                if (files.Count > 0)
                {
                    var newest = files.MaxBy(f => f.LastWriteTimeUtc)!;
                    var oldest = files.MinBy(f => f.LastWriteTimeUtc)!;
                    sb.AppendLine($"  newest: {Rel(newest.FullName)} ({newest.LastWriteTimeUtc:yyyy-MM-dd HH:mm:ss} UTC)");
                    sb.AppendLine($"  oldest: {Rel(oldest.FullName)} ({oldest.LastWriteTimeUtc:yyyy-MM-dd HH:mm:ss} UTC)");
                }
                break;
            case "largest":
                foreach (var f in files.OrderByDescending(f => f.Length).Take(limit))
                {
                    sb.AppendLine($"  {Size(f.Length),10}  {Rel(f.FullName)}");
                }
                break;
            case "recent":
                var since = args.GetElement("sinceHours") is { } h && h.TryGetDouble(out var hours) ? DateTime.UtcNow.AddHours(-hours) : DateTime.MinValue;
                foreach (var f in files.Where(f => f.LastWriteTimeUtc >= since).OrderByDescending(f => f.LastWriteTimeUtc).Take(limit))
                {
                    sb.AppendLine($"  {f.LastWriteTimeUtc:yyyy-MM-dd HH:mm:ss} UTC  {Size(f.Length),10}  {Rel(f.FullName)}");
                }
                break;
            case "timestamps":
                foreach (var f in files.OrderBy(f => f.FullName, StringComparer.OrdinalIgnoreCase).Take(limit))
                {
                    sb.AppendLine($"  {Rel(f.FullName)}: created {f.CreationTimeUtc:yyyy-MM-dd HH:mm:ss}, modified {f.LastWriteTimeUtc:yyyy-MM-dd HH:mm:ss}, accessed {f.LastAccessTimeUtc:yyyy-MM-dd HH:mm:ss} UTC, {Size(f.Length)}");
                }
                break;
            case "duplicates":
                var groups = 0;
                long hashedBytes = 0;
                foreach (var bySize in files.Where(f => f.Length > 0).GroupBy(f => f.Length).Where(g => g.Count() > 1).OrderByDescending(g => g.Key))
                {
                    if (hashedBytes > 4L * 1024 * 1024 * 1024 || groups >= limit)
                    {
                        sb.AppendLine("  (stopped: hashing budget or limit reached)");
                        break;
                    }
                    var byHash = new Dictionary<string, List<FileInfo>>();
                    foreach (var f in bySize)
                    {
                        ct.ThrowIfCancellationRequested();
                        await using var stream = f.OpenRead();
                        var hash = Convert.ToHexString(await SHA256.HashDataAsync(stream, ct));
                        hashedBytes += f.Length;
                        (byHash.TryGetValue(hash, out var list) ? list : byHash[hash] = []).Add(f);
                    }
                    foreach (var (hash, list) in byHash.Where(kv => kv.Value.Count > 1))
                    {
                        groups++;
                        sb.AppendLine($"  {list.Count} × {Size(bySize.Key)} (sha256 {hash[..12]}…): {string.Join(", ", list.Take(8).Select(f => Rel(f.FullName)))}{(list.Count > 8 ? ", …" : "")}");
                    }
                }
                if (groups == 0)
                {
                    sb.AppendLine("  No duplicate files found.");
                }
                break;
            case "tree":
                var depth = Clamp(args.GetInt("depth"), 2, 1, 6);
                var byDir = files.GroupBy(f =>
                {
                    var rel = Path.GetRelativePath(root, f.DirectoryName!).Replace('\\', '/');
                    var parts = rel == "." ? [] : rel.Split('/');
                    return parts.Length == 0 ? "." : string.Join('/', parts.Take(depth));
                }).OrderByDescending(g => g.Sum(f => f.Length)).Take(limit);
                foreach (var g in byDir)
                {
                    sb.AppendLine($"  {g.Key + "/",-60} {g.Count(),8:N0} files  {Size(g.Sum(f => f.Length)),10}");
                }
                break;
        }
        return sb.ToString();
    }

    private static (List<FileInfo> Files, int Dirs, bool Truncated) Enumerate(string root, HashSet<string> excluded, Regex? pattern, CancellationToken ct)
    {
        var files = new List<FileInfo>();
        var dirs = 0;
        var stack = new Stack<DirectoryInfo>([new DirectoryInfo(root)]);
        while (stack.Count > 0)
        {
            ct.ThrowIfCancellationRequested();
            var dir = stack.Pop();
            try
            {
                foreach (var entry in dir.EnumerateFileSystemInfos())
                {
                    if (entry.Attributes.HasFlag(FileAttributes.ReparsePoint))
                    {
                        continue; // Never follow links out of the tree.
                    }
                    if (entry is DirectoryInfo d)
                    {
                        if (!excluded.Contains(d.Name))
                        {
                            dirs++;
                            stack.Push(d);
                        }
                    }
                    else if (entry is FileInfo f && (pattern is null || pattern.IsMatch(f.Name)))
                    {
                        files.Add(f);
                        if (files.Count >= MaxFiles)
                        {
                            return (files, dirs, true);
                        }
                    }
                }
            }
            catch (Exception ex) when (ex is UnauthorizedAccessException or IOException)
            {
            }
        }
        return (files, dirs, false);
    }

    private static string Size(long bytes) => bytes switch
    {
        < 1024 => $"{bytes} B",
        < 1024 * 1024 => $"{bytes / 1024.0:0.0} KB",
        < 1024L * 1024 * 1024 => $"{bytes / 1024.0 / 1024:0.0} MB",
        _ => $"{bytes / 1024.0 / 1024 / 1024:0.00} GB",
    };
}
