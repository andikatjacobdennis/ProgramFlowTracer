using System.Text;
using DocGen.Analysis.Documentation;
using DocGen.Analysis.Repositories;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

/// <summary>docs_check: verifies a Markdown user guide in the workspace (see <see cref="DocsChecker"/>).</summary>
public sealed class DocsCheckTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "docs_check";

    public override string Description =>
        "Checks a folder of Markdown user documentation in the workspace: broken links, anchors and images; images without alt text or caption; " +
        "annotated screenshots without their original; numbered markers without a matching step; non-consecutive steps; and UI labels written in " +
        "**bold** that do not appear in the text visible on the page's screenshots (from browser_screenshot capture records). Run it after writing " +
        "and fix every problem it lists before reporting the guide as done.";

    public override string InputSchema => """
        {
          "type": "object",
          "properties": {
            "folder": { "type": "string", "maxLength": 300, "description": "Workspace folder of the guide, e.g. generated/app-docs." }
          },
          "required": ["folder"],
          "additionalProperties": false
        }
        """;

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.ReadOnly;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var workspace = await Services.Repositories.ResolveAsync(context.UserId, RepositoryCatalog.WorkspaceName, ct);
        var folder = workspace.Resolve(args.RequireString("folder"));
        if (!Directory.Exists(folder))
        {
            throw new NotFoundException("Documentation folder");
        }
        var findings = DocsChecker.Check(folder);
        var problems = findings.Where(f => f.Problem).ToList();
        var notes = findings.Where(f => !f.Problem).ToList();
        var pages = Directory.EnumerateFiles(folder, "*.md", SearchOption.AllDirectories).Count();
        var images = Directory.EnumerateFiles(folder, "*.png", SearchOption.AllDirectories).Count();
        var sb = new StringBuilder($"{pages} page(s), {images} image(s): {problems.Count} problem(s), {notes.Count} note(s).");
        foreach (var group in problems.GroupBy(f => f.Kind).OrderByDescending(g => g.Count()))
        {
            sb.Append($"\n{group.Key}: {group.Count()}");
        }
        foreach (var f in problems.Take(80))
        {
            sb.Append($"\n✗ {f.File}{(f.Line > 0 ? ":" + f.Line : "")} — {f.Message}");
        }
        if (problems.Count > 80)
        {
            sb.Append($"\n… {problems.Count - 80} more problems");
        }
        foreach (var f in notes.Take(30))
        {
            sb.Append($"\n· {f.File}{(f.Line > 0 ? ":" + f.Line : "")} — {f.Message}");
        }
        if (problems.Count == 0)
        {
            sb.Append("\nNo problems: links, images, captions, originals, legends, step numbering and on-screen labels check out.");
        }
        return sb.ToString();
    }
}
