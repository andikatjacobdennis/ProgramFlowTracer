using System.Text;
using System.Text.Json;
using DocGen.Analysis.Commands;
using DocGen.Analysis.CSharp;
using DocGen.Analysis.Flow;
using DocGen.Analysis.Indexing;
using DocGen.Analysis.Investigations;
using DocGen.Analysis.Json;
using DocGen.Analysis.Rca;
using DocGen.Analysis.Repositories;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

/// <summary>
/// Backward root-cause analysis: failure → throw/wrapper/underlying exception → provenance trace → evidence-weighted
/// candidates (Strong/Moderate/Weak) → discriminating experiments. Stores the result in the active investigation.
/// </summary>
public sealed class RankRootCausesTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "rank_root_causes";

    public override string Description =>
        "Traces a failure backward to where the bad state originated and ranks root-cause candidates by evidence (not by crash proximity). Input: a finished test " +
        "command (commandId) or failure text (exception + stack trace / assertion output) and optionally the failing test name. Output: candidates grouped by strength " +
        "with reasons, the provenance trace of the top candidate (origin → failure), contradicting evidence (e.g. wrapper sites) and discriminating experiments. " +
        "Results are hypotheses to test, never a confirmed root cause.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "commandId": { "type": "string", "maxLength": 64, "description": "A finished run_tests command; its failures are analyzed." },
            "failure": { "type": "string", "maxLength": 200000, "description": "Exception text with stack trace, or assertion output." },
            "testName": { "type": "string", "maxLength": 400 },
            "symptom": { "type": "string", "maxLength": 4000 }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        var request = new RcaRequest { Symptom = args.GetString("symptom") };
        if (args.GetString("commandId") is { Length: > 0 } commandId)
        {
            var command = await Services.Commands.GetAsync(context.UserId, commandId, ct);
            foreach (var f in command.Tests?.Failures.Take(3) ?? [])
            {
                request.Failures.Add(new RcaFailure { TestName = f.Name, Text = $"{f.ExceptionType}: {f.Message}\n{f.StackTrace}" });
            }
            if (request.Failures.Count == 0)
            {
                throw new ValidationException("That command has no parsed test failures. Pass 'failure' text instead.");
            }
        }
        if (args.GetString("failure") is { Length: > 0 } text)
        {
            request.Failures.Insert(0, new RcaFailure { TestName = args.GetString("testName"), Text = text });
        }
        if (request.Failures.Count == 0)
        {
            throw new ValidationException("Provide 'commandId' (finished test command) or 'failure' (exception/assertion text).");
        }
        var investigation = context.ConversationId is null ? null : await Services.Investigations.GetActiveForConversationAsync(context.UserId, context.ConversationId, ct);
        request.Symptom ??= investigation?.Symptom;
        var report = RcaEngine.Analyze(index, request, ct);
        var files = report.Candidates.Select(c => c.File).OfType<string>().Concat(report.Trace.Select(t => t.File).OfType<string>()).Distinct().Take(30).ToList();
        await Services.TrackInspectedAsync(context, repo.Name, files, ct);
        var note = "";
        if (investigation is not null)
        {
            await Services.Investigations.SetRcaAsync(context.UserId, investigation.Id, RcaSnapshot.From(report), CancellationToken.None);
            note = $"\nStored on investigation {investigation.Id} (Root Cause Trace). Next: record the leading candidates as hypotheses and run the experiments.";
        }
        return RcaFormatter.Format(report) + note;
    }
}

/// <summary>Backward provenance of one expression: where its value comes from, step by step.</summary>
public sealed class TraceValueOriginTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "trace_value_origin";

    public override string Description =>
        "Traces where the value of an expression comes from, backwards: locals, parameters → call-site arguments, assignments, returns, constructors and object " +
        "initializers (including properties that are never set), fields and their writers, collections, LINQ filters/projections, deserialization, configuration and DI. " +
        "Returns ordered chains (origin first) with confidence (definite/likely/ambiguous), evidence locations and explicit ambiguities where resolution is name-based.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "symbol": { "type": "string", "maxLength": 400, "description": "Member containing the expression (e.g. SpineLabel.Render). Optional when path+line are given." },
            "path": { "type": "string", "maxLength": 400 },
            "line": { "type": "integer", "minimum": 1 },
            "expression": { "type": "string", "minLength": 1, "maxLength": 400, "description": "Expression whose value to trace, e.g. book.Author or loan.DueDate." },
            "maxChains": { "type": "integer", "minimum": 1, "maximum": 12 }
          },
          "required": ["expression"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        var budget = RcaBudget.Wide();
        var ctx = new FlowContext(index, budget);
        var expression = args.RequireString("expression").Trim();
        var line = args.GetInt("line");
        MemberFlow? member = null;
        var notes = new List<string>();
        if (args.GetString("path") is { Length: > 0 } path && line is { } l)
        {
            var relative = repo.Relative(repo.Resolve(path)).Replace('\\', '/');
            member = ctx.MemberAt(relative, l);
        }
        if (member is null && args.GetString("symbol") is { Length: > 0 } symbol)
        {
            var targets = index.Resolve(symbol).Where(s => !SymbolKinds.IsType(s.Kind)).ToList();
            if (targets.Count == 0)
            {
                throw new NotFoundException("Symbol");
            }
            if (targets.Count > 1)
            {
                notes.Add($"'{symbol}' matches {targets.Count} members (name-based); traced {targets[0].FullName}. Others: {string.Join(", ", targets.Skip(1).Take(4).Select(t => t.FullName))}.");
            }
            member = ctx.Member(targets[0]);
        }
        if (member is null)
        {
            throw new ValidationException("Give 'symbol' (the member containing the expression) or 'path' and 'line'.");
        }
        var tokens = CSharpLexer.Tokenize(expression);
        var startLine = line ?? FindLine(ctx, member, expression);
        var tracer = new ProvenanceTracer(ctx);
        tracer.Start(member, tokens, startLine, [], $"`{expression}` in {ProvenanceTracer.ShortName(member.Symbol)}");
        tracer.Run();

        var byId = tracer.Nodes.ToDictionary(n => n.Id);
        var parents = tracer.Nodes.Select(n => n.ParentId).ToHashSet();
        var leaves = tracer.Nodes.Where(n => !parents.Contains(n.Id) && n.Kind != NodeKinds.Failure)
            .OrderByDescending(n => n.Origin is not null || n.Kind is NodeKinds.Omission or NodeKinds.Literal or NodeKinds.Configuration or NodeKinds.Deserialization or NodeKinds.Input)
            .ThenByDescending(n => n.Depth)
            .Take(Clamp(args.GetInt("maxChains"), 6, 1, 12))
            .ToList();
        var sb = new StringBuilder();
        sb.AppendLine($"Provenance of `{expression}` in {member.Symbol.FullName} (line {startLine}): {leaves.Count} chain(s), origin first.");
        foreach (var note in notes)
        {
            sb.AppendLine("Ambiguity: " + note);
        }
        var chainNo = 0;
        foreach (var leaf in leaves)
        {
            var chain = new List<ProvenanceNode>();
            for (var n = leaf; n is not null && chain.Count < 30; n = n.ParentId >= 0 && byId.TryGetValue(n.ParentId, out var p) ? p : null)
            {
                chain.Add(n);
            }
            var confidence = chain.Any(n => n.Confidence == "ambiguous") ? "ambiguous" : chain.All(n => n.Confidence == "definite") ? "definite" : "likely";
            sb.AppendLine();
            sb.AppendLine($"Chain {++chainNo} — confidence {confidence}{(leaf.Origin is null ? "" : $", origin: {leaf.Origin}")}; evidence: {string.Join(", ", chain.Where(n => n.File is not null).Select(n => $"{n.File}:{n.Line}").Distinct().Take(6))}");
            RcaFormatter.AppendChain(sb, chain);
        }
        var ambiguous = tracer.Nodes.Where(n => n.Confidence == "ambiguous").Select(n => n.Title).Distinct().Take(6).ToList();
        if (ambiguous.Count > 0)
        {
            sb.AppendLine();
            sb.AppendLine("Ambiguities (resolved by name, not by type — verify before relying on them):");
            foreach (var a in ambiguous)
            {
                sb.AppendLine("  - " + a);
            }
        }
        sb.AppendLine();
        var stats = budget.Snapshot();
        stats.SymbolsConsidered = tracer.Hooks.Visited.Count;
        sb.AppendLine(RcaFormatter.Stats(stats));
        await Services.TrackInspectedAsync(context, repo.Name, tracer.Nodes.Select(n => n.File).OfType<string>().Distinct().Take(30), ct);
        return sb.ToString();
    }

    private static int FindLine(FlowContext ctx, MemberFlow member, string expression)
    {
        var compact = expression.Replace(" ", "");
        for (var line = member.Symbol.EndLine; line >= member.Symbol.StartLine; line--)
        {
            if (ctx.SourceLine(member.Symbol.File, line)?.Replace(" ", "").Contains(compact, StringComparison.Ordinal) == true)
            {
                return line;
            }
        }
        return member.Symbol.EndLine;
    }
}

/// <summary>Compares JSON contracts between serializers and deserializers of related types.</summary>
public sealed class CompareJsonContractsTool(AnalysisServices services) : AnalysisTool(services)
{
    private static readonly string[] DeserializeMethods = ["Deserialize", "DeserializeAsync", "ReadFromJsonAsync", "GetFromJsonAsync", "DeserializeObject"];

    public override string Name => "compare_json_contracts";

    public override string Description =>
        "Compares the JSON contract a sender writes with the one a receiver reads: property names after naming policies and [JsonPropertyName], case sensitivity, " +
        "properties the sender never writes, and custom converters that apply. Give receiverType (and optionally senderType); options are taken from the code's " +
        "Serialize/Deserialize call sites, or overridden with senderOptions/receiverOptions (default | web | camelCase | snakeCaseLower | kebabCaseLower).";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "receiverType": { "type": "string", "minLength": 1, "maxLength": 300 },
            "senderType": { "type": "string", "maxLength": 300 },
            "senderOptions": { "type": "string", "enum": ["default", "web", "camelCase", "snakeCaseLower", "snakeCaseUpper", "kebabCaseLower"] },
            "receiverOptions": { "type": "string", "enum": ["default", "web", "camelCase", "snakeCaseLower", "snakeCaseUpper", "kebabCaseLower"] }
          },
          "required": ["receiverType"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        var ctx = new FlowContext(index, RcaBudget.Wide());
        var receiver = ResolveType(index, args.RequireString("receiverType"));
        var comparisons = new List<ContractComparison>();
        if (args.GetString("senderType") is { Length: > 0 } senderName)
        {
            var sender = ResolveType(index, senderName);
            comparisons.Add(ContractAnalyzer.CompareTypes(ctx, sender, receiver, Options(args.GetString("senderOptions")) ?? new JsonOptionsInfo(), Options(args.GetString("receiverOptions")) ?? new JsonOptionsInfo()));
        }
        else
        {
            var sites = ReceiverSites(ctx, receiver).Take(4).ToList();
            if (sites.Count == 0)
            {
                sites.Add(new DeserializationSite(new ProvenanceNode(), ctx.Member(index.MembersOf(receiver.FullName).FirstOrDefault() ?? receiver) ?? throw new ValidationException("The type has no readable members."), receiver.Name, null, []));
            }
            foreach (var site in sites)
            {
                foreach (var comparison in ContractAnalyzer.Compare(ctx, site))
                {
                    if (Options(args.GetString("receiverOptions")) is { } ro || Options(args.GetString("senderOptions")) is not null)
                    {
                        var senderType = ResolveType(index, comparison.SenderType);
                        var redone = ContractAnalyzer.CompareTypes(ctx, senderType, receiver, Options(args.GetString("senderOptions")) ?? comparison.SenderOptions, Options(args.GetString("receiverOptions")) ?? comparison.ReceiverOptions);
                        redone.SenderSite = comparison.SenderSite;
                        redone.ReceiverSite = comparison.ReceiverSite;
                        comparisons.Add(redone);
                    }
                    else
                    {
                        comparisons.Add(comparison);
                    }
                }
            }
        }
        var sb = new StringBuilder();
        if (comparisons.Count == 0)
        {
            sb.AppendLine($"No serialization site writing {receiver.Name} or a same-shaped type was found. Give senderType explicitly to compare two types.");
        }
        foreach (var c in comparisons.DistinctBy(c => c.SenderType + c.ReceiverType + c.SenderSite + c.ReceiverSite).Take(6))
        {
            sb.AppendLine($"{c.SenderType} → {c.ReceiverType}{(c.SenderSite is null ? "" : $" (written in {c.SenderSite}, read in {c.ReceiverSite})")}");
            sb.AppendLine($"  sender options: {c.SenderOptions.Describe()} [{c.SenderOptions.Expression}{(c.SenderOptions.Resolved ? "" : ", not resolved — assumed default")}]");
            sb.AppendLine($"  receiver options: {c.ReceiverOptions.Describe()} [{c.ReceiverOptions.Expression}{(c.ReceiverOptions.Resolved ? "" : ", not resolved — assumed default")}]");
            if (c.Mismatches.Count == 0)
            {
                sb.AppendLine("  Contract matches: every receiver property is written under a name the receiver reads.");
            }
            foreach (var m in c.Mismatches)
            {
                sb.AppendLine($"  MISMATCH {m.Property}: {m.Reason}");
            }
            var options = c.ReceiverOptions;
            foreach (var (converter, handled) in ContractAnalyzer.ApplicableConverters(ctx, options, receiver, receiver))
            {
                sb.AppendLine($"  Converter {converter.Name} handles {handled} ({converter.File}:{converter.StartLine}) — check its Read/Write for lossy transformations.");
            }
        }
        await Services.TrackInspectedAsync(context, repo.Name, [receiver.File], ct);
        return sb.ToString();
    }

    private static IEnumerable<DeserializationSite> ReceiverSites(FlowContext ctx, SymbolRecord receiver)
    {
        foreach (var user in DeserializeMethods.SelectMany(m => ctx.Index.CallersByName(m)).Distinct().Take(60))
        {
            if (ctx.Member(user) is not { } flow)
            {
                continue;
            }
            foreach (var call in flow.Calls.Where(c => DeserializeMethods.Contains(c.Callee) && c.TypeArgs.Any(t => FlowContext.BareName(FlowContext.GenericArgument(t) ?? t) == receiver.Name)))
            {
                var options = call.Args.Count > 1 ? call.Args[^1].Text : null;
                yield return new DeserializationSite(new ProvenanceNode { Title = "deserialization" }, flow, call.TypeArgs[0], options, []);
            }
        }
    }

    private static SymbolRecord ResolveType(CodeIndex index, string name)
        => index.Resolve(name, "type").FirstOrDefault() ?? index.ByName(name.Split('.')[^1]).FirstOrDefault(s => SymbolKinds.IsType(s.Kind)) ?? throw new NotFoundException($"Type '{name}'");

    private static JsonOptionsInfo? Options(string? preset) => preset switch
    {
        null => null,
        "web" => new JsonOptionsInfo { Expression = "web", Web = true, Resolved = true },
        "camelCase" => new JsonOptionsInfo { Expression = "camelCase", NamingPolicy = "CamelCase", Resolved = true },
        "snakeCaseLower" => new JsonOptionsInfo { Expression = preset, NamingPolicy = "SnakeCaseLower", Resolved = true },
        "snakeCaseUpper" => new JsonOptionsInfo { Expression = preset, NamingPolicy = "SnakeCaseUpper", Resolved = true },
        "kebabCaseLower" => new JsonOptionsInfo { Expression = preset, NamingPolicy = "KebabCaseLower", Resolved = true },
        _ => new JsonOptionsInfo { Expression = "default", Resolved = true },
    };
}

/// <summary>Configuration provenance for one key.</summary>
public sealed class ConfigProvenanceTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "config_provenance";

    public override string Description =>
        "Explains where a configuration value comes from: base appsettings.json, environment files (appsettings.{Environment}.json) that override it, the " +
        "environment-variable name that would override it, the options class/section bound to it and its consumers. Flags missing keys, suspicious overrides " +
        "(0, empty, negative) and near-miss key names. Give 'key' (Section:Name) or optionsType + property.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "key": { "type": "string", "maxLength": 300 },
            "optionsType": { "type": "string", "maxLength": 200 },
            "property": { "type": "string", "maxLength": 200 }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        var key = args.GetString("key");
        if (string.IsNullOrWhiteSpace(key) && args.GetString("optionsType") is { Length: > 0 } optionsType)
        {
            key = ConfigAnalyzer.ResolveOptionsKey(index, optionsType, args.GetString("property") is { Length: > 0 } p ? [p] : []);
            if (key is null)
            {
                return $"No options binding (Configure<{optionsType}>/Bind/GetSection) was found for {optionsType}; its values are defaults unless bound elsewhere (ambiguous).";
            }
        }
        if (string.IsNullOrWhiteSpace(key))
        {
            throw new ValidationException("Give 'key' or 'optionsType'.");
        }
        var provenance = ConfigAnalyzer.Trace(index, key);
        var sb = new StringBuilder();
        sb.AppendLine($"Configuration key {provenance.Key} (environment variable: {provenance.EnvironmentVariable}; later layers win: appsettings.json → appsettings.{{Environment}}.json → user secrets → environment variables → command line):");
        if (provenance.Missing)
        {
            sb.AppendLine("  Not set in any configuration file in the repository — the consumer gets its default unless an environment variable or other runtime source provides it.");
        }
        foreach (var layer in provenance.Layers)
        {
            sb.AppendLine($"  {layer.File}:{layer.Line} = {layer.Value ?? "(object)"}{(layer == provenance.Override ? "  ← overrides the base value" : "")}");
        }
        foreach (var finding in provenance.Findings)
        {
            sb.AppendLine("  Finding: " + finding);
        }
        foreach (var miss in provenance.NearMisses)
        {
            sb.AppendLine("  Near miss: " + miss);
        }
        var section = key.Split(':')[0];
        foreach (var reference in index.ConfigReferences.Where(c => c.Key is not null && (c.Key.Equals(key, StringComparison.OrdinalIgnoreCase) || c.Key.Equals(section, StringComparison.OrdinalIgnoreCase))).Take(10))
        {
            sb.AppendLine($"  Used by: {reference.Kind} {reference.Type ?? ""} at {reference.File}:{reference.Line}");
        }
        await Services.TrackInspectedAsync(context, repo.Name, provenance.Layers.Select(l => l.File), ct);
        return sb.ToString();
    }
}

/// <summary>Concurrency and lifetime risk scan.</summary>
public sealed class FindRaceRisksTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "find_race_risks";

    public override string Description =>
        "Finds concurrency risks: read→await→write of shared fields without synchronisation (lost update), check-then-act across awaits, non-atomic counters " +
        "(++/+=) in async/shared members, and captive dependencies (singleton → … → scoped, e.g. a shared DbContext or request context). Scope with 'symbol' " +
        "(member or type) or 'project'. Heuristic: results are risks to test (repeat the test / add a lock in a counterfactual), not confirmed races.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "symbol": { "type": "string", "maxLength": 300 },
            "project": { "type": "string", "maxLength": 200 },
            "maxResults": { "type": "integer", "minimum": 1, "maximum": 100 }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        var ctx = new FlowContext(index, new RcaBudget { MaxFiles = 400 });
        var members = new List<SymbolRecord>();
        if (args.GetString("symbol") is { Length: > 0 } symbol)
        {
            foreach (var s in index.Resolve(symbol))
            {
                members.AddRange(SymbolKinds.IsType(s.Kind) ? index.MembersOf(s.FullName) : [s]);
            }
        }
        else
        {
            var project = args.GetString("project");
            var singletons = index.Registrations.Where(r => r.Lifetime == "Singleton").Select(r => r.ImplementationType).ToHashSet(StringComparer.Ordinal);
            members.AddRange(index.Symbols.Where(s => !SymbolKinds.IsType(s.Kind) && !s.IsTest && !index.IsTestProject(s.Project)
                                                      && (project is null || s.Project.Equals(project, StringComparison.OrdinalIgnoreCase))
                                                      && (s.Modifiers.Contains("async") || s.Modifiers.Contains("static") || singletons.Contains(s.Container?.Split('.')[^1] ?? "")))
                .Take(400));
        }
        var sb = new StringBuilder();
        var max = Clamp(args.GetInt("maxResults"), 25, 1, 100);
        var count = 0;
        foreach (var member in members.Where(m => m.Kind is SymbolKinds.Method or SymbolKinds.Constructor or SymbolKinds.Property).Distinct())
        {
            ct.ThrowIfCancellationRequested();
            if (ctx.Member(member) is not { } flow)
            {
                continue;
            }
            foreach (var finding in RaceAnalyzer.Analyze(ctx, flow))
            {
                if (count++ >= max)
                {
                    break;
                }
                sb.AppendLine($"[{finding.Pattern}] {member.FullName} ({member.File}:{finding.ReadLine}-{finding.WriteLine}): {finding.Description}");
            }
        }
        var chains = DiChainAnalyzer.Chains(index);
        foreach (var chain in chains.Take(10))
        {
            sb.AppendLine($"[captive-dependency] singleton {string.Join(" → ", chain.Path)}: {chain.Captured.ServiceType} is Scoped ({chain.Captured.File}:{chain.Captured.Line}) but is held by a singleton registered at {chain.Singleton.File}:{chain.Singleton.Line} — one instance is shared across requests/threads.");
        }
        if (sb.Length == 0)
        {
            sb.AppendLine($"No race or lifetime risks found in {members.Count} members (heuristics cover field read/await/write, check-then-act, non-atomic updates and singleton→scoped chains).");
        }
        sb.AppendLine(RcaFormatter.Stats(ctx.Budget.Snapshot()));
        return sb.ToString();
    }
}

/// <summary>Anomaly localization in large JSON arrays (streaming, bounded memory).</summary>
public sealed class JsonAnomaliesTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "json_anomalies";

    public override string Description =>
        "Streams a large JSON document (any size) and localizes anomalous records in its main array: missing or unexpected fields, unexpected nulls, type changes, " +
        "rare values/formats, numeric outliers and duplicate ids — each with its JSON path. With 'failure' text, anomalies whose values appear in the failure are " +
        "ranked first (correlation, not proof).";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "path": { "type": "string", "maxLength": 400 },
            "ref": { "type": "string", "maxLength": 200 },
            "arrayPath": { "type": "string", "maxLength": 300, "description": "JSON path of the record array, e.g. $.readings (default: the largest array)." },
            "failure": { "type": "string", "maxLength": 20000 },
            "maxAnomalies": { "type": "integer", "minimum": 1, "maximum": 200 }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (full, label) = await Services.SourceAsync(args, context, ct);
        var report = await Task.Run(() => JsonAnomalyDetector.Scan(full, args.GetString("arrayPath"), Clamp(args.GetInt("maxAnomalies"), 30, 1, 200), ct), ct);
        if (args.GetString("failure") is { Length: > 0 } failure)
        {
            JsonAnomalyDetector.Correlate(report, failure);
        }
        var sb = new StringBuilder();
        sb.AppendLine($"{label}: array {report.ArrayPath} with {report.Elements:N0} records, {report.FieldsProfiled} fields profiled, {report.Anomalies.Count} anomalies ({report.ElapsedMs} ms).");
        foreach (var a in report.Anomalies.OrderByDescending(a => a.CorrelatedWithFailure).Take(Clamp(args.GetInt("maxAnomalies"), 30, 1, 200)))
        {
            sb.AppendLine($"  {(a.CorrelatedWithFailure ? "★ " : "")}{a.Path} [{a.Kind}] {a.Field}: {a.Reason}");
        }
        return sb.ToString();
    }
}

/// <summary>
/// Counterfactual verification: applies candidate edits to a scratch copy of the repository (never the original) and
/// reruns the failing test there. The outcome is derived from the command record and recorded as counterfactual
/// evidence on the active investigation.
/// </summary>
public sealed class CounterfactualRunTool(AnalysisServices services) : CommandToolBase(services)
{
    public override string Name => "counterfactual_run";

    public override string Description =>
        "Tests a root-cause hypothesis without touching the repository: copies it to a scratch directory, applies 'edits' (exact oldText → newText replacements; also " +
        "data/config files), and runs the failing test(s) there (requires approval). With baseline=true (default) the unmodified copy is run first to show the failure " +
        "reproduces. Outcome failureGone / failurePersists / inconclusive is derived from the test results and recorded as counterfactual evidence (link it with hypothesisId).";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "edits": {
              "type": "array", "minItems": 1, "maxItems": 20,
              "items": {
                "type": "object",
                "properties": {
                  "path": { "type": "string", "minLength": 1, "maxLength": 400 },
                  "oldText": { "type": "string", "minLength": 1, "maxLength": 20000 },
                  "newText": { "type": "string", "maxLength": 20000 }
                },
                "required": ["path", "oldText", "newText"],
                "additionalProperties": false
              }
            },
            "filter": { "type": "string", "maxLength": 500, "description": "dotnet test filter selecting the failing test(s), e.g. FullyQualifiedName~LabelTests.Prints_labels" },
            "target": { "type": "string", "maxLength": 400 },
            "hypothesisId": { "type": "string", "maxLength": 10 },
            "baseline": { "type": "boolean" },
            "repeat": { "type": "integer", "minimum": 1, "maximum": 20, "description": "Run the tests this many times (for flaky/concurrency failures)." }
          },
          "required": ["edits", "filter"],
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (repo, index) = await Services.IndexAsync(args, context, ct);
        if (!repo.AllowCommands)
        {
            throw new ForbiddenException($"Commands are not enabled for repository '{repo.Name}'.");
        }
        var edits = ParseEdits(args);
        var filter = args.RequireString("filter");
        var target = args.GetString("target");
        if (target is not null && index.Projects.TryGetValue(target, out var project))
        {
            target = project.Path;
        }
        target ??= index.Manifest.Solutions.Count == 1 ? index.Manifest.Solutions[0].Path : null;
        var hypothesisId = args.GetString("hypothesisId");
        var repeat = Clamp(args.GetInt("repeat"), 1, 1, 20);

        var id = Guid.NewGuid().ToString("N")[..12];
        var scratchRoot = Path.Combine(Services.DataDirectory, "scratch", "counterfactual", Ids.Require(context.UserId, "user id"), id);
        var sb = new StringBuilder();
        try
        {
            var copied = CopyRepository(repo.Root, scratchRoot, Services.Options.ExcludedDirectories, Services.DataDirectory, Services.Options.MaxCounterfactualCopyBytes);
            sb.AppendLine($"Scratch copy: {copied.Files:N0} files ({copied.Bytes / 1024.0 / 1024.0:0.0} MB); the original repository is not modified.");
            var scratch = new RepositoryHandle { Name = repo.Name, Root = scratchRoot, AllowCommands = true, AllowWrite = false, Source = "scratch", IndexKey = "scratch-" + id };

            string? baselineOutcome = null;
            if (args.GetBool("baseline") ?? true)
            {
                var (outcome, text) = await RunTestsAsync(scratch, target, filter, repeat, context, ct);
                baselineOutcome = outcome;
                sb.AppendLine($"Baseline (unmodified copy): {Describe(outcome)}");
                sb.Append(text);
            }
            foreach (var edit in edits)
            {
                ApplyEdit(scratch, edit);
            }
            sb.AppendLine($"Applied {edits.Count} edit(s): {string.Join(", ", edits.Select(e => e.Path).Distinct())}");
            var (after, afterText) = await RunTestsAsync(scratch, target, filter, repeat, context, ct);
            sb.AppendLine($"With the edits: {Describe(after)}");
            sb.Append(afterText);

            // The failure must reproduce in the copy for "gone" to mean anything.
            var verdict = baselineOutcome is not null && baselineOutcome != "failurePersists"
                ? "inconclusive"
                : after;
            if (baselineOutcome is not null && baselineOutcome != "failurePersists")
            {
                sb.AppendLine("Verdict: inconclusive — the failure did not reproduce in the unmodified copy, so its disappearance proves nothing.");
            }
            else
            {
                sb.AppendLine($"Verdict: {verdict}{(baselineOutcome is null ? " (no baseline run: the failure was not re-observed in the copy)" : "")}.");
            }
            if (context.ConversationId is not null && await Services.Investigations.GetActiveForConversationAsync(context.UserId, context.ConversationId, CancellationToken.None) is { } active)
            {
                var summary = $"Counterfactual: applied {string.Join("; ", edits.Select(e => $"{e.Path}: `{Clip(e.OldText, 60)}` → `{Clip(e.NewText, 60)}`"))} in a scratch copy and ran `{filter}`"
                              + $"{(repeat > 1 ? $" ×{repeat}" : "")}: baseline {baselineOutcome ?? "not run"}, after {after} → {verdict}.";
                var updated = await Services.Investigations.AddCounterfactualEvidenceAsync(context.UserId, active.Id, summary, "counterfactual:" + id,
                    hypothesisId is not null && active.Hypotheses.Any(h => h.Id == hypothesisId) ? hypothesisId : null,
                    baselineOutcome is null && verdict == "failureGone" ? "inconclusive" : verdict, context.RunId, CancellationToken.None);
                sb.AppendLine($"Recorded {updated.Evidence[^1].Id} (counterfactual, {updated.Evidence[^1].Outcome}){(hypothesisId is null ? "" : $" for {hypothesisId}")}.");
                if (baselineOutcome is null && verdict == "failureGone")
                {
                    sb.AppendLine("Recorded as inconclusive because no baseline run showed the failure in the copy.");
                }
            }
        }
        finally
        {
            TryDelete(scratchRoot);
        }
        return sb.ToString();
    }

    private async Task<(string Outcome, string Text)> RunTestsAsync(RepositoryHandle scratch, string? target, string filter, int repeat, ToolExecutionContext context, CancellationToken ct)
    {
        var sb = new StringBuilder();
        var failed = false;
        var passedAll = true;
        for (var i = 0; i < repeat; i++)
        {
            var record = await Services.Commands.StartAsync(context.UserId, scratch, new CommandRequest
            {
                Kind = CommandKinds.Test, Target = target, Filter = filter, RunId = context.RunId, ConversationId = context.ConversationId,
            }, ct);
            var maxWait = Math.Max(5, Services.AgentOptions.ToolTimeoutSeconds - 5);
            record = await Services.Commands.WaitAsync(context.UserId, record.Id, TimeSpan.FromSeconds(maxWait), ct);
            if (!record.IsFinal)
            {
                await Services.Commands.CancelAsync(context.UserId, record.Id, "counterfactual run exceeded the tool time limit");
                record = await Services.Commands.WaitAsync(context.UserId, record.Id, TimeSpan.FromSeconds(30), CancellationToken.None);
            }
            var tests = record.Tests;
            var ran = (tests?.Passed ?? 0) + (tests?.Failed ?? 0) > 0;
            if (tests is { Failed: > 0 } || tests is { Failures.Count: > 0 })
            {
                failed = true;
            }
            if (!(ran && tests is { Failed: 0 or null, Failures.Count: 0 } && record.Status == CommandStatus.Succeeded))
            {
                passedAll = false;
            }
            if (i == 0 || failed)
            {
                sb.Append(Indent(Describe(record)));
            }
            if (failed)
            {
                break;
            }
        }
        return (failed ? "failurePersists" : passedAll ? "failureGone" : "inconclusive", sb.ToString());
    }

    private static string Describe(string outcome) => outcome switch
    {
        "failurePersists" => "tests FAIL",
        "failureGone" => "tests PASS",
        _ => "inconclusive (build failure, timeout or no tests selected)",
    };

    private static string Indent(string text) => string.Join("\n", text.TrimEnd().Split('\n').Select(l => "    " + l.TrimEnd('\r'))) + "\n";

    internal sealed record Edit(string Path, string OldText, string NewText);

    private static List<Edit> ParseEdits(ToolArguments args)
    {
        if (args.GetElement("edits") is not { ValueKind: JsonValueKind.Array } array)
        {
            throw new ValidationException("'edits' is required.");
        }
        var edits = new List<Edit>();
        foreach (var e in array.EnumerateArray().Take(20))
        {
            var path = e.TryGetProperty("path", out var p) ? p.GetString() : null;
            var oldText = e.TryGetProperty("oldText", out var o) ? o.GetString() : null;
            var newText = e.TryGetProperty("newText", out var n) ? n.GetString() : "";
            if (string.IsNullOrWhiteSpace(path) || string.IsNullOrEmpty(oldText))
            {
                throw new ValidationException("Every edit needs 'path' and 'oldText'.");
            }
            edits.Add(new Edit(path, oldText, newText ?? ""));
        }
        return edits;
    }

    internal static void ApplyEdit(RepositoryHandle scratch, Edit edit)
    {
        var full = scratch.Resolve(edit.Path);
        if (!File.Exists(full))
        {
            throw new ValidationException($"File '{edit.Path}' does not exist in the repository.");
        }
        var text = File.ReadAllText(full);
        var oldText = edit.OldText.Replace("\r\n", "\n");
        var crlf = text.Contains("\r\n", StringComparison.Ordinal);
        var normalized = text.Replace("\r\n", "\n");
        var first = normalized.IndexOf(oldText, StringComparison.Ordinal);
        if (first < 0)
        {
            throw new ValidationException($"oldText was not found in '{edit.Path}'.");
        }
        if (normalized.IndexOf(oldText, first + 1, StringComparison.Ordinal) >= 0)
        {
            throw new ValidationException($"oldText occurs more than once in '{edit.Path}'; include more context.");
        }
        var updated = normalized[..first] + edit.NewText.Replace("\r\n", "\n") + normalized[(first + oldText.Length)..];
        File.WriteAllText(full, crlf ? updated.Replace("\n", "\r\n") : updated);
    }

    /// <summary>Copies source, project and data files (skipping build output, VCS folders and the DocGen data directory).</summary>
    internal static (int Files, long Bytes) CopyRepository(string source, string destination, IEnumerable<string> excluded, string dataDirectory, long maxBytes)
    {
        var skip = new HashSet<string>(excluded, StringComparer.OrdinalIgnoreCase);
        var dataFull = Path.GetFullPath(dataDirectory).TrimEnd(Path.DirectorySeparatorChar);
        var files = 0;
        long bytes = 0;
        var stack = new Stack<string>([Path.GetFullPath(source)]);
        while (stack.Count > 0)
        {
            var dir = stack.Pop();
            if (string.Equals(dir.TrimEnd(Path.DirectorySeparatorChar), dataFull, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }
            foreach (var sub in Directory.EnumerateDirectories(dir))
            {
                var info = new DirectoryInfo(sub);
                if (!skip.Contains(info.Name) && !info.Attributes.HasFlag(FileAttributes.ReparsePoint))
                {
                    stack.Push(sub);
                }
            }
            foreach (var file in Directory.EnumerateFiles(dir))
            {
                var info = new FileInfo(file);
                if (info.Attributes.HasFlag(FileAttributes.ReparsePoint))
                {
                    continue;
                }
                bytes += info.Length;
                if (bytes > maxBytes)
                {
                    throw new ValidationException($"The repository is larger than the counterfactual copy limit ({maxBytes / 1024 / 1024} MB, DocGen:Analysis:MaxCounterfactualCopyBytes).");
                }
                var target = Path.Combine(destination, Path.GetRelativePath(source, file));
                Directory.CreateDirectory(Path.GetDirectoryName(target)!);
                File.Copy(file, target, overwrite: false);
                files++;
            }
        }
        return (files, bytes);
    }

    private static void TryDelete(string path)
    {
        try
        {
            if (Directory.Exists(path))
            {
                Directory.Delete(path, recursive: true);
            }
        }
        catch (IOException)
        {
            // Left for the retention service (scratch copies older than DocGen:Retention:ScratchMaxAgeHours).
        }
        catch (UnauthorizedAccessException)
        {
        }
    }

    private static string Clip(string value, int max) => value.Length <= max ? value.Replace('\n', ' ') : value[..max].Replace('\n', ' ') + "…";
}
