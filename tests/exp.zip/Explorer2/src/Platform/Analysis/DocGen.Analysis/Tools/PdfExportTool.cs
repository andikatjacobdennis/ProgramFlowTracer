using System.Diagnostics;
using System.Text.RegularExpressions;
using DocGen.Analysis.Browser;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Core.Options;
using DocGen.Tools.Infrastructure;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Tools;

/// <summary>
/// pdf_export: prints an HTML file to PDF with the machine's Edge/Chrome (headless, throwaway profile, network blocked so
/// the document cannot fetch anything) into the workspace's generated/ folder, with a download button in the chat.
/// </summary>
public sealed partial class PdfExportTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "pdf_export";

    public override string Description =>
        "Exports an HTML file to PDF (A4/Letter, print CSS honoured) and gives the user a download button. Use it when the user asks for a PDF " +
        "(resume, report, letter…): write the document as a complete, styled HTML file first (file_write, e.g. generated/resume.html; use " +
        "@page and print CSS, no external fonts or scripts — the export runs offline), then export it. The PDF is saved in the workspace under generated/.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "path": { "type": "string", "minLength": 1, "maxLength": 500, "description": "The .html file to export." },
            "name": { "type": "string", "maxLength": 80, "description": "PDF file name (default: the HTML file's name)." }
          },
          "required": ["path"],
          "additionalProperties": false
        }
        """;

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct) => throw new NotSupportedException();

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var repo = await Services.RepositoryAsync(args, context, ct);
        var source = repo.Resolve(args.RequireString("path"));
        if (Path.GetExtension(source).ToLowerInvariant() is not (".html" or ".htm"))
        {
            throw new ValidationException("pdf_export prints .html files; write the document as HTML first (file_write).");
        }
        if (!File.Exists(source))
        {
            throw new NotFoundException("HTML file");
        }
        var browser = HeadlessRender.LocateBrowser(Services, "a PDF cannot be printed");
        var baseName = SafeName().Replace(Path.GetFileNameWithoutExtension(args.GetString("name") is { Length: > 0 } n ? n : source), "-").Trim('-');
        var relative = $"generated/{(baseName.Length == 0 ? "document" : baseName)}.pdf";
        var output = Path.Combine(context.WorkspaceRoot, relative.Replace('/', Path.DirectorySeparatorChar));
        Directory.CreateDirectory(Path.GetDirectoryName(output)!);
        var failure = await HeadlessRender.RunAsync(browser, source, output, temp => ["--no-pdf-header-footer", "--print-to-pdf=" + temp], "PDF", ct);
        if (failure is not null)
        {
            return ToolResult.Fail(call, failure);
        }

        var bytes = new FileInfo(output).Length;
        var pages = PdfPageCount(output);
        var result = ToolResult.Ok(call, $"Exported {repo.Relative(source).Replace('\\', '/')} to {relative} ({bytes:N0} bytes{(pages > 0 ? $", {pages} page(s)" : "")}). " +
                                         "The user has a download button; check the layout with read_document (mode=pages) if the page count looks wrong.");
        result.FileChanges = [new FileChange { Path = relative, Kind = "download", LinesAdded = (int)Math.Min(int.MaxValue, bytes) }];
        return result;
    }

    /// <summary>Page count from the PDF's page objects (good enough to report; 0 when unknown).</summary>
    private static int PdfPageCount(string path)
    {
        try
        {
            var text = System.Text.Encoding.Latin1.GetString(File.ReadAllBytes(path));
            return PageObject().Matches(text).Count;
        }
        catch (IOException)
        {
            return 0;
        }
    }

    [GeneratedRegex(@"[^A-Za-z0-9._-]+")]
    private static partial Regex SafeName();

    [GeneratedRegex(@"/Type\s*/Page(?!s)")]
    private static partial Regex PageObject();
}
