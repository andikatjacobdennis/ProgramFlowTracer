using DocGen.Core.Models;
using System.Text;
using DocGen.Analysis.Execution;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

/// <summary>
/// Captures the windows of a desktop application DocGen started (dev server or command): saves a PNG in the workspace and
/// reports the text on screen (OCR), the dominant colours and a coarse colour grid, so the agent can verify what a
/// WPF/WinForms/game window actually shows instead of assuming. Only windows of DocGen-started process trees are captured.
/// </summary>
public sealed class WindowCaptureTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "window_capture";

    public override string Description =>
        "Takes a screenshot of the window(s) of a desktop app you started with dev_server_start (serverId) or run_process (commandId): WPF, WinForms, " +
        "OpenGL/DirectX, console UIs. Returns the text visible in the window (OCR), the main colours and an 8x6 grid of average colours, and saves a PNG " +
        "under generated/screenshots/ that the user can open. Use it to verify a GUI really shows what it should (e.g. that a 3D scene rendered and is not " +
        "blank) before telling the user it works. waitSeconds lets the app finish starting or animating first.";

    public override string InputSchema => """
        {
          "type": "object",
          "properties": {
            "serverId": { "type": "string", "maxLength": 64, "description": "From dev_server_start. Default: the most recently started running app." },
            "commandId": { "type": "string", "maxLength": 64, "description": "From run_process/powershell when the app was started that way." },
            "waitSeconds": { "type": "integer", "minimum": 0, "maximum": 30, "description": "Wait before capturing (default 2)." }
          },
          "additionalProperties": false
        }
        """;

    /// <summary>The captures are returned as images too, so the reply shows what DocGen saw.</summary>
    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var text = (await RunAsync(args, context, ct)).TrimEnd();
        var result = ToolResult.Ok(call, text);
        var shots = System.Text.RegularExpressions.Regex.Matches(text, @"Saved: (generated/screenshots/\S+\.png)").Select(m => m.Groups[1].Value).ToList();
        if (shots.Count > 0)
        {
            result.FileChanges = shots.Select(p => new FileChange { Path = p, Kind = "image" }).ToList();
        }
        return result;
    }

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        if (!OperatingSystem.IsWindows())
        {
            throw new ValidationException("Window capture needs Windows.");
        }
        var (label, rootPid) = await TargetAsync(args, context, ct);
        var wait = Clamp(args.GetInt("waitSeconds"), 2, 0, 30);
        if (wait > 0)
        {
            await Task.Delay(TimeSpan.FromSeconds(wait), ct);
        }
        var windows = WindowCapture.Windows(WindowCapture.ProcessTree(rootPid));
        if (windows.Count == 0)
        {
            return $"{label} (pid {rootPid}) has no visible window right now. If it is a GUI app it may still be starting (try waitSeconds), may have exited " +
                   "(check dev_server_status / command_status for its output and exit code), or may be a console/web app without a window.";
        }
        var workspace = await Services.Repositories.ResolveAsync(context.UserId, "workspace", ct);
        var folder = Path.Combine(workspace.Root, "generated", "screenshots");
        Directory.CreateDirectory(folder);
        var images = Services.Service<IImageAnalyzer>();
        var sb = new StringBuilder();
        foreach (var window in windows.Take(4))
        {
            var shot = await Task.Run(() => WindowCapture.Capture(window), ct);
            sb.AppendLine($"Window \"{window.Title}\" ({window.ProcessName}, pid {window.ProcessId}) — {shot.Width}x{shot.Height}, captured with {shot.Method}");
            if (shot.Minimized)
            {
                sb.AppendLine("The window is minimized, so nothing is visible. Ask the user to restore it, then capture again.");
                continue;
            }
            if (shot.Png is null)
            {
                sb.AppendLine("The window could not be captured.");
                continue;
            }
            var safe = new string(window.ProcessName.Where(char.IsLetterOrDigit).ToArray());
            var file = $"{(safe.Length > 0 ? safe : "window")}-{DateTime.UtcNow:yyyyMMdd-HHmmss-fff}.png";
            var full = Path.Combine(folder, file);
            await File.WriteAllBytesAsync(full, shot.Png, ct);
            sb.AppendLine($"Saved: generated/screenshots/{file} (the user can open it on the Files page)");
            if (images is not null)
            {
                var ocr = await images.AnalyzeAsync(context.UserId, full, ct);
                sb.AppendLine(ocr.Error is not null ? "Text on screen: (OCR unavailable: " + ocr.Error + ")"
                    : ocr.HasText ? "Text on screen (OCR; each line with x,y from the window's top-left and width x height, so you can see where things are laid out):\n"
                                    + string.Join("\n", ocr.Lines.Take(40).Select(l => $"  [{l.X:0},{l.Y:0} {l.Width:0}x{l.Height:0}] {l.Text}"))
                    : "Text on screen: none recognised");
                sb.AppendLine($"Window size for reference: {shot.Width}x{shot.Height} (grid cells are {shot.Width / WindowCapture.GridColumns}x{shot.Height / WindowCapture.GridRows} px).");
            }
            sb.AppendLine("Main colours: " + string.Join(", ", shot.Colors.Select(c => $"{c.Hex} {c.Share:P0}")));
            if (shot.BlackShare > 0.85)
            {
                sb.AppendLine($"Warning: {shot.BlackShare:P0} of the window is black. A GPU surface that rendered nothing (or is not presented) typically looks like this.");
            }
            sb.AppendLine($"Average colour grid ({WindowCapture.GridColumns}x{WindowCapture.GridRows}, top row first; cells that all match the background mean nothing is drawn there):");
            foreach (var row in shot.Grid)
            {
                sb.AppendLine("  " + string.Join(" ", row));
            }
            sb.AppendLine();
        }
        if (windows.Count > 4)
        {
            sb.AppendLine($"({windows.Count - 4} more window(s) not captured.)");
        }
        return sb.ToString().TrimEnd();
    }

    /// <summary>The process tree to look at: always one this user started through DocGen (ownership enforced by the services).</summary>
    private async Task<(string Label, int ProcessId)> TargetAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        if (args.GetString("commandId") is { Length: > 0 } commandId)
        {
            var command = await Services.Commands.GetAsync(context.UserId, commandId, ct);
            return command.ProcessId is { } pid && !command.IsFinal
                ? ($"Command {command.Id}", pid)
                : throw new ValidationException($"Command {commandId} is not running ({command.Status}); start the app again first.");
        }
        var servers = DevServerFormat.Service(Services);
        DevServerRecord server;
        if (args.GetString("serverId") is { Length: > 0 } serverId)
        {
            server = await servers.StatusAsync(context.UserId, serverId, ct);
        }
        else
        {
            var running = (await servers.ListAsync(context.UserId, ct)).Where(s => s.Status is DevServerStatus.Running or DevServerStatus.Starting)
                .OrderByDescending(s => s.StartedAt).ToList();
            // Only an app from this conversation: an older app still running from another chat must never be mistaken for it.
            server = running.FirstOrDefault(s => s.ConversationId == context.ConversationId)
                     ?? throw new ValidationException("No app started in this conversation is running" +
                                                      (running.Count > 0 ? $" ({running.Count} from other conversations; pass serverId to capture one of those)" : "") +
                                                      ". Start it with dev_server_start (or pass commandId), then capture.");
        }
        if (server.Status is not (DevServerStatus.Running or DevServerStatus.Starting) || server.ProcessId is not { } processId)
        {
            throw new ValidationException($"App {server.Name} is not running ({server.Status}{(server.ExitCode is { } code ? $", exit code {code}" : "")}). " +
                                          $"Read its output with command_status commandId={server.CommandId}, fix the problem and start it again.");
        }
        return ($"App {server.Name}", processId);
    }
}
