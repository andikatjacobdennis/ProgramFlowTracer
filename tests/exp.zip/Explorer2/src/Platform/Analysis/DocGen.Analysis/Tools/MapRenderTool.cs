using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using DocGen.Analysis.Maps;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

/// <summary>
/// map_render: maps of real places drawn from Natural Earth boundary data (never by hand). Country boundaries follow
/// the point of view of the user's country (Settings → Language &amp; region) when Natural Earth publishes one, and
/// every map says on it where its boundaries come from and that it is not an official map.
/// </summary>
public sealed partial class MapRenderTool(AnalysisServices services) : AnalysisTool(services), IDynamicRiskTool
{
    public override string Name => "map_render";

    public override string Description =>
        "Draws a map of real countries, states/provinces and cities from Natural Earth boundary data as SVG + PNG in generated/maps/ " +
        "(shown in the reply). Use it for ANY map of a real place — never draw coastlines or borders yourself. Boundaries follow the " +
        "user's country's official point of view; the map states its source. You choose what to show: countries, state borders, " +
        "highlights, which cities; positions and shapes come from the data. It has countries, regions (Europe…), states/provinces " +
        "(focus_states) and cities — not districts: for district maps fetch an existing one with commons_media.";

    public override string InputSchema => """
        {
          "type": "object",
          "properties": {
            "countries": { "type": "array", "items": { "type": "string", "maxLength": 60 }, "maxItems": 60, "description": "Countries the map is about (English name or ISO code), e.g. [\"India\"]." },
            "region": { "type": "string", "maxLength": 40, "description": "A continent or region instead of listing countries: Europe, Africa, Asia, South America, North America, Oceania, South Asia, Southeast Asia, East Asia, Middle East, Central Asia." },
            "focus_states": { "type": "array", "items": { "type": "string", "maxLength": 60 }, "maxItems": 12, "description": "States/provinces the map is about, e.g. [\"Rajasthan\"]: the map frames them, marks their own cities, and shows the rest of the country as context." },
            "title": { "type": "string", "maxLength": 100 },
            "states": { "type": "boolean", "description": "Draw state/province borders and names (default true)." },
            "highlight": { "type": "array", "maxItems": 40, "items": { "type": "object", "properties": { "name": { "type": "string", "maxLength": 80 }, "color": { "type": "string", "maxLength": 20 } }, "required": ["name"], "additionalProperties": false }, "description": "States or countries to fill, e.g. [{\"name\":\"Karnataka\",\"color\":\"#f4c56a\"}]." },
            "cities": { "type": "string", "enum": ["none", "capitals", "major"], "description": "none, capitals (national and state capitals) or major (largest cities; default)." },
            "city_names": { "type": "array", "maxItems": 40, "items": { "type": "string", "maxLength": 60 }, "description": "Particular cities to mark." },
            "bounds": { "type": "array", "items": { "type": "number" }, "minItems": 4, "maxItems": 4, "description": "Optional view: [west, south, east, north] in degrees (e.g. to zoom on a region)." },
            "point_of_view": { "type": "string", "maxLength": 7, "description": "Only when the user asks for another country's view of borders: its ISO alpha-2 code, or \"default\" for Natural Earth's de facto edition. Omit to use the user's country." },
            "name": { "type": "string", "maxLength": 60, "description": "File name (default from the title)." },
            "width": { "type": "integer", "minimum": 500, "maximum": 2400 }
          },
          "required": [],
          "additionalProperties": false
        }
        """;

    public override ToolRiskLevel RiskLevel => ToolRiskLevel.Write;

    public Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken)
        => Task.FromResult(new ToolRiskAssessment(ToolRiskLevel.Write, Routine: true, Summary: "Draw a map into generated/maps/"));

    protected override Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct) => throw new NotSupportedException();

    protected override async Task<ToolResult> RunResultAsync(ToolCall call, ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (pov, povName, povSource) = await PointOfViewAsync(args.GetString("point_of_view"), context, ct);
        var data = new NaturalEarth(Path.Combine(Services.DataDirectory, "geo", "natural-earth-" + NaturalEarth.Version));
        var countries = await data.LayerAsync(NaturalEarth.CountriesFile(pov), ct);
        var states = await data.LayerAsync(NaturalEarth.StatesFile, ct);
        var places = await data.LayerAsync(NaturalEarth.PlacesFile, ct);

        var root = JsonDocument.Parse(call.Arguments).RootElement;
        var highlights = root.TryGetProperty("highlight", out var hl) && hl.ValueKind == JsonValueKind.Array
            ? hl.EnumerateArray().Select(h => (h.GetProperty("name").GetString() ?? "", h.TryGetProperty("color", out var c) ? c.GetString() ?? "#f4c56a" : "#f4c56a")).ToList()
            : [];
        (double, double, double, double)? bounds = null;
        if (root.TryGetProperty("bounds", out var b) && b.ValueKind == JsonValueKind.Array && b.GetArrayLength() == 4)
        {
            var v = b.EnumerateArray().Select(x => x.GetDouble()).ToArray();
            if (v[0] >= v[2] || v[1] >= v[3] || v.Any(x => Math.Abs(x) > 180))
            {
                throw new ValidationException("bounds must be [west, south, east, north] with west < east and south < north.");
            }
            bounds = (v[0], v[1], v[2], v[3]);
        }
        var spec = new MapSpec
        {
            Title = args.GetString("title"),
            Countries = args.GetStringArray("countries"),
            Region = args.GetString("region"),
            FocusStates = args.GetStringArray("focus_states"),
            Bounds = bounds,
            // State borders suit one or a few countries; on a continent they bury the country names.
            States = args.GetBool("states") ?? (args.GetString("region") is null && args.GetStringArray("countries").Count <= 3),
            Highlights = highlights,
            Cities = args.GetString("cities") ?? "major",
            CityNames = args.GetStringArray("city_names"),
            Width = args.GetInt("width") ?? 1000,
            PointOfView = pov,
            PointOfViewName = povName,
        };
        var map = MapRenderer.Render(spec, countries, states, places);

        var baseName = SafeName().Replace(args.GetString("name") is { Length: > 0 } n ? n : spec.Title ?? string.Join("-", map.Subjects) + "-map", "-").Trim('-').ToLowerInvariant();
        baseName = baseName.Length == 0 ? "map" : baseName[..Math.Min(60, baseName.Length)];
        var folder = Path.Combine(context.WorkspaceRoot, "generated", "maps");
        Directory.CreateDirectory(folder);
        var svgPath = Path.Combine(folder, baseName + ".svg");
        await File.WriteAllTextAsync(svgPath, map.Svg, new UTF8Encoding(false), ct);

        var changes = new List<FileChange> { new() { Path = $"generated/maps/{baseName}.svg", Kind = "created" } };
        string? pngNote = null;
        try
        {
            var browser = HeadlessRender.LocateBrowser(Services, "the map could not be rendered to PNG");
            var scale = map.Width * 2 <= 4000 && map.Height * 2 <= 4000 ? 2 : 1;
            var failure = await ImageExportTool.SvgToPngAsync(browser, svgPath, Path.Combine(folder, baseName + ".png"), map.Width * scale, map.Height * scale, ct);
            if (failure is null)
            {
                changes.Add(new FileChange { Path = $"generated/maps/{baseName}.png", Kind = "image" });
            }
            else
            {
                pngNote = "The PNG could not be made: " + failure;
            }
        }
        catch (ValidationException ex)
        {
            pngNote = ex.Message;
        }

        var text = new StringBuilder();
        var about = spec.FocusStates.Count > 0 ? $"{string.Join(", ", spec.FocusStates)} ({string.Join(", ", map.Subjects)})" : spec.Region ?? string.Join(", ", map.Subjects);
        text.AppendLine($"Drew a map of {about} ({map.Width}×{map.Height}) to generated/maps/{baseName}.svg" +
                        (changes.Count > 1 ? $" and .png (shown to the user)." : "."));
        text.AppendLine($"Boundaries: {map.Caption} ({povSource})");
        text.AppendLine(map.Cities.Count > 0 ? $"Cities marked (from the data): {string.Join(", ", map.Cities)}." : "No cities marked.");
        text.AppendLine($"{map.LabelsPlaced} labels placed; {map.LabelsSkipped} left out because they would overlap others (use a larger width or fewer cities to fit more).");
        foreach (var note in map.Notes.Append(pngNote).OfType<string>())
        {
            text.AppendLine(note);
        }
        text.Append("Tell the user the boundaries follow the point of view above and that it is not an official survey map; do not describe shapes or positions you have not checked.");
        var result = ToolResult.Ok(call, text.ToString());
        result.FileChanges = changes;
        return result;
    }

    /// <summary>
    /// Whose boundaries to draw: an explicit request, else the user's country (Settings → Language &amp; region) when
    /// Natural Earth has its edition, else the default (de facto) edition.
    /// </summary>
    private async Task<(string? Code, string? Name, string Source)> PointOfViewAsync(string? requested, ToolExecutionContext context, CancellationToken ct)
    {
        static string? NameOf(string code) => UserCountries.All.FirstOrDefault(c => string.Equals(c.Code, code, StringComparison.OrdinalIgnoreCase)).Name;
        if (requested is { Length: > 0 })
        {
            if (string.Equals(requested, "default", StringComparison.OrdinalIgnoreCase))
            {
                return (null, null, "requested: Natural Earth default edition");
            }
            if (!NaturalEarth.PointsOfView.ContainsKey(requested))
            {
                throw new ValidationException($"No boundary edition for \"{requested}\". Available: {string.Join(", ", NaturalEarth.PointsOfView.Keys)} or default.");
            }
            return (requested.ToUpperInvariant(), NameOf(requested), "requested explicitly");
        }
        var country = Services.Service<IUserRepository>() is { } users && await users.GetAsync(context.UserId, ct) is { } user
            ? user.Preferences?.Country
            : UserCountries.Default;
        if (country is { Length: > 0 } && NaturalEarth.PointsOfView.ContainsKey(country))
        {
            return (country.ToUpperInvariant(), NameOf(country), "the user's country in Settings");
        }
        return (null, null, country is { Length: > 0 } ? $"no boundary edition for the user's country ({NameOf(country) ?? country})" : "no country set");
    }

    [GeneratedRegex(@"[^A-Za-z0-9._-]+")]
    private static partial Regex SafeName();
}
