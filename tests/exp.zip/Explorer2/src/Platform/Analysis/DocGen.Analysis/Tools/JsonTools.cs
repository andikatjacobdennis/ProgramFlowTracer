using System.Globalization;
using System.Text;
using System.Text.Json;
using DocGen.Analysis.Json;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Tools.Infrastructure;

namespace DocGen.Analysis.Tools;

/// <summary>Shared argument schema and error handling for the JSON tools.</summary>
public abstract class JsonToolBase(AnalysisServices services) : AnalysisTool(services)
{
    protected const string SourceProperties = """
        "path": { "type": "string", "maxLength": 400, "description": "JSON file in the repository (or workspace)." },
        "ref": { "type": "string", "maxLength": 200, "description": "blob:// or runtime-object:// reference instead of a path." }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (full, label) = await Services.SourceAsync(args, context, ct);
        try
        {
            return await Task.Run(() => Run(args, full, label, ct), ct);
        }
        catch (JsonException ex)
        {
            throw new ValidationException($"{label} is not valid JSON: {ex.Message}");
        }
        catch (FormatException ex)
        {
            throw new ValidationException(ex.Message);
        }
    }

    protected abstract string Run(ToolArguments args, string fullPath, string label, CancellationToken ct);
}

public sealed class JsonSummaryTool(AnalysisServices services) : JsonToolBase(services)
{
    public override string Name => "json_summary";

    public override string Description =>
        "Summarises a JSON document of any size by streaming it: byte size, token estimate, root type, value counts, depth, top-level keys with sizes, largest arrays, " +
        "strings and subtrees, and null-heavy paths. Use before reading any large JSON.";

    public override string InputSchema => $$"""{ "type": "object", "properties": { {{RepositoryProperty}}, {{SourceProperties}} }, "additionalProperties": false }""";

    protected override string Run(ToolArguments args, string fullPath, string label, CancellationToken ct)
    {
        var s = JsonAnalyzer.Summarize(fullPath, ct);
        var sb = new StringBuilder();
        sb.AppendLine($"{label}: {s.Bytes:N0} bytes (~{s.EstimatedTokens:N0} tokens if read whole), root {s.RootType}, {s.Values:N0} values, max depth {s.MaxDepth}, scanned in {s.ElapsedMs:N0} ms.");
        sb.AppendLine("Value types: " + string.Join(", ", s.TypeCounts.OrderByDescending(t => t.Value).Select(t => $"{t.Key} {t.Value:N0}")));
        if (s.TopLevel.Count > 0)
        {
            sb.AppendLine("Top-level members:");
            foreach (var (path, bytes, type) in s.TopLevel.Take(40))
            {
                sb.AppendLine($"  {path} ({type}, {bytes:N0} bytes)");
            }
        }
        sb.AppendLine("Largest arrays: " + string.Join("; ", s.LargestArrays.Take(6).Select(a => $"{a.Path} [{a.Length:N0}]")));
        sb.AppendLine("Largest subtrees: " + string.Join("; ", s.LargestSubtrees.Take(6).Select(a => $"{a.Path} {a.Bytes:N0} B")));
        if (s.LargestStrings.Count > 0 && s.LargestStrings[0].Bytes > 200)
        {
            sb.AppendLine("Largest strings: " + string.Join("; ", s.LargestStrings.Where(x => x.Bytes > 200).Take(5).Select(a => $"{a.Path} {a.Bytes:N0} B")));
        }
        if (s.NullHeavyPaths.Count > 0)
        {
            sb.AppendLine("Paths with nulls: " + string.Join("; ", s.NullHeavyPaths.Take(10).Select(n => $"{n.Path} {n.Nulls:N0}/{n.Count:N0}")));
        }
        sb.AppendLine($"{s.Shapes.Count:N0} distinct paths{(s.ShapesCapped ? " (capped)" : "")}. Next: json_type_shape, json_path, json_search or json_sample.");
        return sb.ToString();
    }
}

public sealed class JsonTypeShapeTool(AnalysisServices services) : JsonToolBase(services)
{
    public override string Name => "json_type_shape";

    public override string Description =>
        "Infers the schema-like shape of a JSON document by streaming it: every path (array indexes collapsed to [*]) with observed types, counts, nulls, string lengths, " +
        "number ranges and array lengths. Reveals mixed types and optional fields that break deserialisation.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}}, {{SourceProperties}},
            "maxDepth": { "type": "integer", "minimum": 1, "maximum": 64 },
            "under": { "type": "string", "maxLength": 300, "description": "Only paths below this prefix, e.g. $.orders[*]" },
            "limit": { "type": "integer", "minimum": 1, "maximum": 500 }
          },
          "additionalProperties": false
        }
        """;

    protected override string Run(ToolArguments args, string fullPath, string label, CancellationToken ct)
    {
        var s = JsonAnalyzer.Summarize(fullPath, ct);
        var maxDepth = Clamp(args.GetInt("maxDepth"), 6, 1, 64);
        var under = args.GetString("under");
        var limit = Clamp(args.GetInt("limit"), 150, 1, 500);
        var shapes = s.Shapes.Where(x => x.Depth <= maxDepth && (under is null || x.Path.StartsWith(under, StringComparison.Ordinal))).ToList();
        var sb = new StringBuilder($"{label}: {shapes.Count} paths (depth ≤ {maxDepth}{(under is null ? "" : $", under {under}")}):\n");
        foreach (var shape in shapes.Take(limit))
        {
            var types = string.Join("|", shape.Types);
            var extra = new List<string>();
            if (shape.Types.Count > 1 && !(shape.Types.Count == 2 && shape.Types.Contains("null")))
            {
                extra.Add("⚠ MIXED TYPES");
            }
            if (shape.Nulls > 0)
            {
                extra.Add($"nulls {shape.Nulls:N0}");
            }
            if (shape.MaxStringBytes > 0)
            {
                extra.Add($"max len {shape.MaxStringBytes:N0}");
            }
            if (shape.MinNumber is { } min)
            {
                extra.Add($"range {min.ToString(CultureInfo.InvariantCulture)}…{shape.MaxNumber?.ToString(CultureInfo.InvariantCulture)}");
            }
            if (shape.MaxArrayLength > 0 || shape.Types.Contains("array"))
            {
                extra.Add($"length {(shape.MinArrayLength == long.MaxValue ? 0 : shape.MinArrayLength):N0}…{shape.MaxArrayLength:N0}");
            }
            sb.AppendLine($"{new string(' ', Math.Min(shape.Depth, 12) * 2)}{shape.Path}: {types} ×{shape.Count:N0}{(extra.Count > 0 ? " (" + string.Join(", ", extra) + ")" : "")}");
        }
        if (shapes.Count > limit)
        {
            sb.AppendLine($"… {shapes.Count - limit} more paths; narrow with 'under' or 'maxDepth'.");
        }
        return sb.ToString();
    }
}

public sealed class JsonPathTool(AnalysisServices services) : JsonToolBase(services)
{
    public override string Name => "json_path";

    public override string Description => "Extracts values by path from a JSON document of any size (streamed): $.a.b, ['key'], [3], [*], ..name. Each match is returned as a bounded raw JSON slice.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}}, {{SourceProperties}},
            "query": { "type": "string", "minLength": 1, "maxLength": 300 },
            "limit": { "type": "integer", "minimum": 1, "maximum": 50 },
            "maxBytes": { "type": "integer", "minimum": 100, "maximum": 20000 }
          },
          "required": ["query"],
          "additionalProperties": false
        }
        """;

    protected override string Run(ToolArguments args, string fullPath, string label, CancellationToken ct)
    {
        var (matches, total) = JsonAnalyzer.Query(fullPath, args.RequireString("query"), Clamp(args.GetInt("limit"), 10, 1, 50), Clamp(args.GetInt("maxBytes"), 4000, 100, 20000), ct);
        var sb = new StringBuilder($"{total:N0} matches for {args.RequireString("query")} in {label}{(total > matches.Count ? $" (showing {matches.Count})" : "")}:\n");
        foreach (var m in matches)
        {
            sb.AppendLine($"{m.Path} ({m.Kind}, {m.Bytes:N0} bytes){(m.Truncated ? " [truncated]" : "")}:");
            sb.AppendLine(m.Preview);
        }
        return sb.ToString();
    }
}

public sealed class JsonSearchTool(AnalysisServices services) : JsonToolBase(services)
{
    public override string Name => "json_search";

    public override string Description => "Searches keys and/or primitive values of a JSON document of any size (streamed) by text or regex; returns the paths of matches with value previews.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}}, {{SourceProperties}},
            "text": { "type": "string", "maxLength": 300 },
            "regex": { "type": "string", "maxLength": 300 },
            "in": { "type": "string", "enum": ["keys", "values", "both"] },
            "limit": { "type": "integer", "minimum": 1, "maximum": 200 },
            "skip": { "type": "integer", "minimum": 0 }
          },
          "additionalProperties": false
        }
        """;

    protected override string Run(ToolArguments args, string fullPath, string label, CancellationToken ct)
    {
        var text = args.GetString("text");
        var regex = args.GetString("regex");
        if (text is null && regex is null)
        {
            throw new ValidationException("Provide 'text' or 'regex'.");
        }
        var where = args.GetString("in") ?? "both";
        var skip = Math.Max(0, args.GetInt("skip") ?? 0);
        List<JsonMatch> matches;
        long total;
        try
        {
            (matches, total) = JsonAnalyzer.Search(fullPath, text, regex, where is "keys" or "both", where is "values" or "both", Clamp(args.GetInt("limit"), 40, 1, 200), skip, ct);
        }
        catch (ArgumentException ex) when (ex is not ArgumentNullException)
        {
            throw new ValidationException("Invalid regular expression: " + ex.Message);
        }
        var sb = new StringBuilder($"{total:N0} matches in {label}; showing {matches.Count} from #{skip + 1}:\n");
        foreach (var m in matches)
        {
            sb.AppendLine($"{m.Path} [{m.Kind}] = {m.Preview}");
        }
        if (total > skip + matches.Count)
        {
            sb.AppendLine($"Next page: skip={skip + matches.Count}");
        }
        return sb.ToString();
    }
}

public sealed class JsonSampleTool(AnalysisServices services) : JsonToolBase(services)
{
    public override string Name => "json_sample";

    public override string Description => "Returns a few elements of a (possibly huge) JSON array: the first, the last, or evenly spread samples — to see representative and edge-case records.";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}}, {{SourceProperties}},
            "array": { "type": "string", "minLength": 1, "maxLength": 300, "description": "Path of the array, e.g. $ or $.orders" },
            "count": { "type": "integer", "minimum": 1, "maximum": 50 },
            "strategy": { "type": "string", "enum": ["first", "last", "spread"] },
            "maxBytes": { "type": "integer", "minimum": 100, "maximum": 20000 }
          },
          "required": ["array"],
          "additionalProperties": false
        }
        """;

    protected override string Run(ToolArguments args, string fullPath, string label, CancellationToken ct)
    {
        var array = args.RequireString("array");
        var (samples, length) = JsonAnalyzer.Sample(fullPath, array, Clamp(args.GetInt("count"), 3, 1, 50), args.GetString("strategy") ?? "spread", Clamp(args.GetInt("maxBytes"), 2000, 100, 20000), ct);
        if (length < 0)
        {
            return $"No array found at {array} in {label}.";
        }
        var sb = new StringBuilder($"{array} has {length:N0} elements; {samples.Count} samples:\n");
        foreach (var s in samples)
        {
            sb.AppendLine($"{s.Path} ({s.Bytes:N0} bytes){(s.Truncated ? " [truncated]" : "")}:");
            sb.AppendLine(s.Preview);
        }
        return sb.ToString();
    }
}

public sealed class JsonDiffTool(AnalysisServices services) : AnalysisTool(services)
{
    public override string Name => "json_diff";

    public override string Description =>
        "Structural diff of two JSON documents (paths or blob references): added/removed/changed values and type changes. Arrays of objects can be matched by a key property (arrayKey).";

    public override string InputSchema => $$"""
        {
          "type": "object",
          "properties": {
            {{RepositoryProperty}},
            "path": { "type": "string", "maxLength": 400 },
            "ref": { "type": "string", "maxLength": 200 },
            "otherPath": { "type": "string", "maxLength": 400 },
            "otherRef": { "type": "string", "maxLength": 200 },
            "arrayKey": { "type": "string", "maxLength": 100 },
            "limit": { "type": "integer", "minimum": 1, "maximum": 500 }
          },
          "additionalProperties": false
        }
        """;

    protected override async Task<string> RunAsync(ToolArguments args, ToolExecutionContext context, CancellationToken ct)
    {
        var (a, labelA) = await Services.SourceAsync(args, context, ct);
        var (b, labelB) = await Services.SourceAsync(args, context, ct, refArg: "otherRef", pathArg: "otherPath");
        var max = Services.Options.MaxJsonDocumentBytes;
        if (new FileInfo(a).Length > max || new FileInfo(b).Length > max)
        {
            throw new ValidationException($"json_diff loads both documents; each must be under {max:N0} bytes. Compare sub-trees with json_path instead.");
        }
        try
        {
            return await Task.Run(() =>
            {
                using var docA = JsonDocument.Parse(File.ReadAllBytes(a), new JsonDocumentOptions { MaxDepth = JsonScanner.MaxDepth, CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
                using var docB = JsonDocument.Parse(File.ReadAllBytes(b), new JsonDocumentOptions { MaxDepth = JsonScanner.MaxDepth, CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
                var (diffs, total) = JsonAnalyzer.Diff(docA.RootElement, docB.RootElement, args.GetString("arrayKey"), Clamp(args.GetInt("limit"), 100, 1, 500));
                var sb = new StringBuilder($"{total:N0} differences between {labelA} and {labelB}{(total > diffs.Count ? $" (showing {diffs.Count})" : "")}:\n");
                foreach (var group in diffs.GroupBy(d => d.Kind))
                {
                    sb.AppendLine($"{group.Key} ({group.Count()}):");
                    foreach (var d in group)
                    {
                        sb.AppendLine($"  {d.Path}: {d.Before ?? "∅"} → {d.After ?? "∅"}");
                    }
                }
                return sb.ToString();
            }, ct);
        }
        catch (JsonException ex)
        {
            throw new ValidationException("Invalid JSON: " + ex.Message);
        }
    }
}
