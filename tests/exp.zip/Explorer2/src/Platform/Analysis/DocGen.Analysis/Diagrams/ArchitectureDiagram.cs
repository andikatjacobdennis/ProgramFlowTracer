using System.Globalization;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using DocGen.Core.Exceptions;

namespace DocGen.Analysis.Diagrams;

// ---------------------------------------------------------------- spec (what the model writes)

public sealed class DiagramSpec
{
    public string Title { get; set; } = "";
    public string? Subtitle { get; set; }
    public List<DiagramLayer> Layers { get; set; } = [];
    public List<DiagramNode> Nodes { get; set; } = [];
    public List<DiagramEdge> Edges { get; set; } = [];
}

public sealed class DiagramLayer
{
    public string Id { get; set; } = "";
    public string Title { get; set; } = "";
    public string? Color { get; set; }
}

public sealed class DiagramNode
{
    public string Id { get; set; } = "";
    public string Layer { get; set; } = "";
    public string Title { get; set; } = "";
    public string? Subtitle { get; set; }
    public string? Icon { get; set; }

    /// <summary>Optional manual column (0, 1, 2 … may be fractional). When every node of a layer has one, the layer is pinned.</summary>
    public double? Column { get; set; }
}

public sealed class DiagramEdge
{
    public string From { get; set; } = "";
    public string To { get; set; } = "";
    public string? Label { get; set; }

    /// <summary>request | realtime | data | async | event</summary>
    public string? Kind { get; set; }

    /// <summary>Arrow heads at both ends.</summary>
    public bool Both { get; set; }
}

/// <summary>The rendered diagram and what the layout checks found.</summary>
public sealed record DiagramResult(
    string Svg, int Width, int Height, int Boxes, int Arrows, int Crossings, int Rerouted, IReadOnlyList<string> BlockedArrows, IReadOnlyList<string> Warnings);

/// <summary>
/// Layered architecture diagrams, laid out and routed deterministically (the model only describes the diagram):
/// boxes are ordered per layer to reduce crossings (barycenter sweeps) and positioned so connected boxes line up;
/// arrows are routed orthogonally from box border to box border, through free corridors when they skip layers, with
/// parallel runs spread over separate lanes. The result is checked: boxes never overlap, and every arrow is tested
/// against every box it does not connect. Output is a self-contained SVG (no scripts; all text XML-escaped).
/// </summary>
public static class ArchitectureDiagram
{
    public const int MaxLayers = 12, MaxNodes = 60, MaxEdges = 150;

    private const double BoxW = 240, BoxH = 84, Col = 284, Pitch = 204, BandPad = 20, LeftTitle = 250, Margin = 36, Top = 128;
    private const double LaneStep = 14, Clearance = 12;

    /// <summary>Height of a layer band.</summary>
    private const double BandH = BoxH + 2 * BandPad;

    /// <summary>
    /// Vertical positions: the top of each layer band and the height of the gap above it. Gaps grow with the number of
    /// lanes that run through them, so busy gaps get room instead of squeezing lines and labels together.
    /// </summary>
    private sealed class Frame
    {
        public required double[] RowTop { get; init; }
        public required double[] GapH { get; init; }

        public static Frame Create(int rows, double[] gapH)
        {
            var top = new double[rows];
            for (var r = 0; r < rows; r++)
            {
                top[r] = r == 0 ? Top : top[r - 1] + BandH + gapH[r];
            }
            return new Frame { RowTop = top, GapH = gapH };
        }

        /// <summary>The middle of the gap above row <paramref name="gap"/> (gap = rows is below the last row).</summary>
        public double GapY(int gap) => gap <= 0 ? Top - Gap / 2
            : gap >= RowTop.Length ? RowTop[^1] + BandH + Gap / 2
            : RowTop[gap] - GapH[gap] / 2;

        public double Bottom => RowTop[^1] + BandH;
    }

    private static readonly (string Name, string Band, string Border)[] Palette =
    [
        ("blue", "#eef5ff", "#3b82f6"), ("slate", "#f1f5f9", "#475569"), ("green", "#ecfdf5", "#10b981"),
        ("orange", "#fff7ed", "#f97316"), ("purple", "#f7f3ff", "#8b5cf6"), ("teal", "#effcfa", "#14b8a6"),
        ("pink", "#fdf2f8", "#ec4899"), ("amber", "#fffbeb", "#f59e0b"), ("red", "#fef2f2", "#ef4444"),
    ];

    private static readonly Dictionary<string, (string Color, bool Dashed, string Legend)> Kinds = new(StringComparer.OrdinalIgnoreCase)
    {
        ["request"] = ("#374151", false, "request"),
        ["realtime"] = ("#10b981", false, "real-time"),
        ["data"] = ("#f97316", false, "reads / writes"),
        ["async"] = ("#8b5cf6", true, "asynchronous"),
        ["event"] = ("#0ea5e9", true, "events"),
    };

    public static readonly JsonSerializerOptions Json = new()
    {
        PropertyNameCaseInsensitive = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        WriteIndented = true,
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    };

    // ---------------------------------------------------------------- validation

    public static void Validate(DiagramSpec spec)
    {
        if (spec.Layers.Count == 0 || spec.Nodes.Count == 0)
        {
            throw new ValidationException("The diagram needs at least one layer and one node.");
        }
        if (spec.Layers.Count > MaxLayers || spec.Nodes.Count > MaxNodes || spec.Edges.Count > MaxEdges)
        {
            throw new ValidationException($"Too big: at most {MaxLayers} layers, {MaxNodes} nodes and {MaxEdges} edges. Split it into several diagrams.");
        }
        var layers = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var l in spec.Layers)
        {
            if (string.IsNullOrWhiteSpace(l.Id) || !layers.Add(l.Id))
            {
                throw new ValidationException($"Layer ids must be present and unique ('{l.Id}').");
            }
        }
        var nodes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var n in spec.Nodes)
        {
            if (string.IsNullOrWhiteSpace(n.Id) || !nodes.Add(n.Id))
            {
                throw new ValidationException($"Node ids must be present and unique ('{n.Id}').");
            }
            if (!layers.Contains(n.Layer))
            {
                throw new ValidationException($"Node '{n.Id}' is in layer '{n.Layer}', which is not in 'layers'.");
            }
            if (string.IsNullOrWhiteSpace(n.Title))
            {
                throw new ValidationException($"Node '{n.Id}' needs a title.");
            }
        }
        foreach (var e in spec.Edges)
        {
            if (!nodes.Contains(e.From) || !nodes.Contains(e.To))
            {
                throw new ValidationException($"Edge {e.From} → {e.To} refers to a node that does not exist.");
            }
            if (string.Equals(e.From, e.To, StringComparison.OrdinalIgnoreCase))
            {
                throw new ValidationException($"Edge {e.From} → {e.To} connects a node to itself.");
            }
            if (e.Kind is { } kind && !Kinds.ContainsKey(kind))
            {
                throw new ValidationException($"Edge kind '{kind}' is not one of: {string.Join(", ", Kinds.Keys)}.");
            }
        }
    }

    // ---------------------------------------------------------------- layout model

    private sealed class Box
    {
        public required DiagramNode Spec { get; init; }
        public int Row { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public double Left => X - BoxW / 2;
        public double Right => X + BoxW / 2;
        public double TopY => Y - BoxH / 2;
        public double Bottom => Y + BoxH / 2;
    }

    private sealed class Route
    {
        public required DiagramEdge Edge { get; init; }
        public required Box From { get; init; }
        public required Box To { get; init; }
        public List<(double X, double Y)> Points { get; set; } = [];
        public double SourceOffset { get; set; }
        public double TargetOffset { get; set; }

        /// <summary>Horizontal segments that sit in a gap between rows: (gap index, index of the segment's first point).</summary>
        public List<(int Gap, int Index)> GapSegments { get; } = [];
        public bool Rerouted { get; set; }
    }

    // ---------------------------------------------------------------- render

    public static DiagramResult Render(DiagramSpec spec)
    {
        Validate(spec);
        var warnings = new List<string>();
        var layerIndex = spec.Layers.Select((l, i) => (l.Id, i)).ToDictionary(p => p.Id, p => p.i, StringComparer.OrdinalIgnoreCase);
        var boxes = spec.Nodes.Select(n => new Box { Spec = n, Row = layerIndex[n.Layer] }).ToList();
        var byId = boxes.ToDictionary(b => b.Spec.Id, StringComparer.OrdinalIgnoreCase);
        var rows = Enumerable.Range(0, spec.Layers.Count).Select(r => boxes.Where(b => b.Row == r).ToList()).ToList();
        var neighbours = boxes.ToDictionary(b => b, _ => new List<Box>());
        foreach (var e in spec.Edges)
        {
            neighbours[byId[e.From]].Add(byId[e.To]);
            neighbours[byId[e.To]].Add(byId[e.From]);
        }
        foreach (var (row, i) in rows.Select((r, i) => (r, i)))
        {
            if (row.Count > 7)
            {
                warnings.Add($"Layer '{spec.Layers[i].Title}' has {row.Count} boxes; more than 7 makes the diagram very wide. Consider merging or splitting it.");
            }
        }

        Order(rows, neighbours);
        Place(rows, neighbours);

        // Boxes must never overlap (a pinned layer with columns too close together would).
        for (var i = 0; i < boxes.Count; i++)
        {
            for (var j = i + 1; j < boxes.Count; j++)
            {
                // Rows are stacked apart, so only boxes of the same row can overlap.
                var (a, b) = (boxes[i], boxes[j]);
                if (a.Row == b.Row && a.Left < b.Right && b.Left < a.Right)
                {
                    throw new ValidationException($"'{a.Spec.Id}' and '{b.Spec.Id}' overlap: their columns are too close (keep pinned columns at least 1 apart).");
                }
            }
        }

        // Route, see how many lanes each gap needs, resize the gaps and route again (positions depend on the gaps).
        var gapH = Enumerable.Repeat(Gap, rows.Count + 1).ToArray();
        Frame frame;
        List<Route> routes;
        for (var pass = 0; ; pass++)
        {
            frame = Frame.Create(rows.Count, gapH);
            for (var r = 0; r < rows.Count; r++)
            {
                foreach (var b in rows[r])
                {
                    b.Y = frame.RowTop[r] + BandPad + BoxH / 2;
                }
            }
            routes = spec.Edges.Select(e => new Route { Edge = e, From = byId[e.From], To = byId[e.To] }).ToList();
            AssignPorts(routes);
            foreach (var route in routes)
            {
                RouteEdge(route, rows, frame);
            }
            var lanes = AssignLanes(routes, frame);
            var labelled = routes.SelectMany(rt => rt.GapSegments.Where(_ => !string.IsNullOrWhiteSpace(rt.Edge.Label)).Select(g => g.Gap)).GroupBy(g => g).ToDictionary(g => g.Key, g => g.Count());
            var next = gapH.Select((h, g) => Math.Max(Gap, lanes.GetValueOrDefault(g) * LaneStep + 40 + (labelled.GetValueOrDefault(g) > 2 ? 16 : 0))).ToArray();
            if (pass >= 2 || next.SequenceEqual(gapH))
            {
                break;
            }
            gapH = next;
        }

        var blocked = new List<string>();
        foreach (var route in routes)
        {
            if (Blocks(route, boxes) is { } hit)
            {
                blocked.Add($"{route.Edge.From} → {route.Edge.To} crosses '{hit}'");
            }
        }
        var crossings = CountCrossings(routes);
        var svg = Draw(spec, rows, boxes, routes, frame, out var width, out var height);
        return new DiagramResult(svg, (int)Math.Ceiling(width), (int)Math.Ceiling(height), boxes.Count, routes.Count, crossings,
            routes.Count(r => r.Rerouted), blocked, warnings);
    }

    // ---------------------------------------------------------------- ordering and placement

    private static bool Pinned(List<Box> row) => row.Count > 0 && row.All(b => b.Spec.Column is not null);

    /// <summary>Barycenter sweeps: each row is ordered by the average position of its neighbours in the other rows.</summary>
    private static void Order(List<List<Box>> rows, Dictionary<Box, List<Box>> neighbours)
    {
        foreach (var row in rows.Where(Pinned))
        {
            row.Sort((a, b) => a.Spec.Column!.Value.CompareTo(b.Spec.Column!.Value));
        }
        double Pos(Box b, List<List<Box>> all) => all[b.Row].IndexOf(b) - (all[b.Row].Count - 1) / 2.0;
        for (var sweep = 0; sweep < 6; sweep++)
        {
            var down = sweep % 2 == 0;
            var order = down ? Enumerable.Range(1, rows.Count - 1) : Enumerable.Range(0, rows.Count - 1).Reverse();
            foreach (var r in order)
            {
                if (Pinned(rows[r]))
                {
                    continue;
                }
                var keys = rows[r].ToDictionary(b => b, b =>
                {
                    var ns = neighbours[b].Where(n => down ? n.Row < r : n.Row > r).ToList();
                    return ns.Count == 0 ? Pos(b, rows) : ns.Average(n => Pos(n, rows));
                });
                var current = rows[r].ToList();
                rows[r] = current.OrderBy(b => keys[b]).ThenBy(b => current.IndexOf(b)).ToList();
            }
        }
        Improve(rows, neighbours);
    }

    /// <summary>
    /// Local search after the sweeps: swap neighbouring boxes while that lowers the cost - estimated crossings plus a
    /// penalty for boxes linked within their own layer that are not next to each other (their link must go around).
    /// </summary>
    private static void Improve(List<List<Box>> rows, Dictionary<Box, List<Box>> neighbours)
    {
        var edges = neighbours.SelectMany(p => p.Value.Select(n => (A: p.Key, B: n))).Where(e => e.A.GetHashCode() < e.B.GetHashCode()
            || (e.A.GetHashCode() == e.B.GetHashCode() && !ReferenceEquals(e.A, e.B))).Distinct().ToList();
        for (var pass = 0; pass < 8; pass++)
        {
            var improved = false;
            foreach (var row in rows.Where(r => !Pinned(r)))
            {
                // Move each box to the position in its row where the cost is lowest (escapes the local minima of plain swaps).
                foreach (var box in row.ToList())
                {
                    var from = row.IndexOf(box);
                    var best = (Position: from, Cost: Cost(rows, edges));
                    row.RemoveAt(from);
                    for (var to = 0; to <= row.Count; to++)
                    {
                        row.Insert(to, box);
                        var cost = Cost(rows, edges);
                        if (cost < best.Cost - 1e-9)
                        {
                            best = (to, cost);
                        }
                        row.RemoveAt(to);
                    }
                    row.Insert(best.Position, box);
                    improved |= best.Position != from;
                }
            }
            if (!improved)
            {
                break;
            }
        }
    }

    private static double Cost(List<List<Box>> rows, List<(Box A, Box B)> edges)
    {
        double Pos(Box b) => rows[b.Row].IndexOf(b) - (rows[b.Row].Count - 1) / 2.0;
        var cost = 0.0;
        var spans = new List<(int Top, int Bottom, double PTop, double PBottom, Box A, Box B)>();
        foreach (var (a, b) in edges)
        {
            if (a.Row == b.Row)
            {
                cost += 3 * (Math.Abs(rows[a.Row].IndexOf(a) - rows[b.Row].IndexOf(b)) - 1);
                continue;
            }
            var (top, bottom) = a.Row < b.Row ? (a, b) : (b, a);
            spans.Add((top.Row, bottom.Row, Pos(top), Pos(bottom), a, b));
        }
        for (var i = 0; i < spans.Count; i++)
        {
            for (var j = i + 1; j < spans.Count; j++)
            {
                var (s, t) = (spans[i], spans[j]);
                if (s.A == t.A || s.A == t.B || s.B == t.A || s.B == t.B)
                {
                    continue; // Edges that share a box meet there; that is not a crossing.
                }
                var from = Math.Max(s.Top, t.Top);
                var to = Math.Min(s.Bottom, t.Bottom);
                if (from >= to)
                {
                    continue;
                }
                double At((int Top, int Bottom, double PTop, double PBottom, Box, Box) e, int row)
                    => e.PTop + (e.PBottom - e.PTop) * (row - e.Top) / (double)(e.Bottom - e.Top);
                var d1 = At(s, from) - At(t, from);
                var d2 = At(s, to) - At(t, to);
                if (d1 * d2 < 0)
                {
                    cost += 1;
                }
            }
        }
        return cost;
    }

    /// <summary>Positions boxes near the average x of their neighbours, keeping row order and a minimum spacing.</summary>
    private static void Place(List<List<Box>> rows, Dictionary<Box, List<Box>> neighbours)
    {
        foreach (var row in rows)
        {
            for (var i = 0; i < row.Count; i++)
            {
                row[i].X = row[i].Spec.Column is { } c && Pinned(row) ? c * Col : (i - (row.Count - 1) / 2.0) * Col;
            }
        }
        for (var iteration = 0; iteration < 10; iteration++)
        {
            foreach (var row in iteration % 2 == 0 ? rows : Enumerable.Reverse(rows))
            {
                if (Pinned(row) || row.Count == 0)
                {
                    continue;
                }
                var desired = row.Select(b => neighbours[b].Where(n => n.Row != b.Row).Select(n => n.X).DefaultIfEmpty(b.X).Average()).ToArray();
                var forward = new double[row.Count];
                var backward = new double[row.Count];
                for (var i = 0; i < row.Count; i++)
                {
                    forward[i] = i == 0 ? desired[i] : Math.Max(desired[i], forward[i - 1] + Col);
                }
                for (var i = row.Count - 1; i >= 0; i--)
                {
                    backward[i] = i == row.Count - 1 ? desired[i] : Math.Min(desired[i], backward[i + 1] - Col);
                }
                for (var i = 0; i < row.Count; i++)
                {
                    var x = Math.Round((forward[i] + backward[i]) / 2 / (Col / 4)) * (Col / 4);
                    row[i].X = i == 0 ? x : Math.Max(x, row[i - 1].X + Col);
                }
            }
        }
        var minX = rows.SelectMany(r => r).Min(b => b.Left);
        foreach (var b in rows.SelectMany(r => r))
        {
            b.X += LeftTitle + Margin - minX;
        }
    }

    // ---------------------------------------------------------------- routing

    /// <summary>Space between the bands of two neighbouring rows.</summary>
    private const double Gap = Pitch - BoxH - 2 * BandPad;


    /// <summary>Spreads the ends of several arrows on the same side of a box, ordered by where they go, so they do not share a line.</summary>
    private static void AssignPorts(List<Route> routes)
    {
        var sides = new Dictionary<(Box, bool Bottom), List<(Route Route, bool IsFrom, double Other)>>();
        foreach (var r in routes)
        {
            if (r.From.Row == r.To.Row)
            {
                continue;
            }
            var down = r.From.Row < r.To.Row;
            Add((r.From, down), (r, true, r.To.X));
            Add((r.To, !down), (r, false, r.From.X));
        }
        foreach (var (key, list) in sides)
        {
            list.Sort((a, b) => a.Other.CompareTo(b.Other));
            var step = list.Count <= 1 ? 0 : Math.Min(34, (BoxW - 70) / (list.Count - 1));
            for (var i = 0; i < list.Count; i++)
            {
                var offset = (i - (list.Count - 1) / 2.0) * step;
                var (route, isFrom, _) = list[i];
                if (isFrom)
                {
                    route.SourceOffset = offset;
                }
                else
                {
                    route.TargetOffset = offset;
                }
            }
        }
        return;

        void Add((Box, bool) key, (Route, bool, double) item)
        {
            if (!sides.TryGetValue(key, out var list))
            {
                sides[key] = list = [];
            }
            list.Add(item);
        }
    }

    private static void RouteEdge(Route r, List<List<Box>> rows, Frame frame)
    {
        double GapY(int gap) => frame.GapY(gap);
        var (a, b) = (r.From, r.To);
        if (a.Row == b.Row)
        {
            var row = rows[a.Row];
            var (ia, ib) = (row.IndexOf(a), row.IndexOf(b));
            if (Math.Abs(ia - ib) == 1)
            {
                var right = ib > ia;
                r.Points = [(right ? a.Right : a.Left, a.Y), (right ? b.Left : b.Right, b.Y)];
                return;
            }
            // Not neighbours: around the row through the gap below it (above it for the last row, where the legend is),
            // with off-centre ends so it does not run on top of the straight lines leaving the same boxes.
            var sx = a.X + (b.X > a.X ? 40 : -40);
            var tx = b.X + (b.X > a.X ? -40 : 40);
            var below = a.Row < rows.Count - 1;
            var gap = below ? a.Row + 1 : a.Row;
            var (ya, yb) = below ? (a.Bottom, b.Bottom) : (a.TopY, b.TopY);
            r.Points = [(sx, ya), (sx, GapY(gap)), (tx, GapY(gap)), (tx, yb)];
            r.GapSegments.Add((gap, 1));
            return;
        }
        var down = a.Row < b.Row;
        var startX = a.X + r.SourceOffset;
        var endX = b.X + r.TargetOffset;
        var start = (X: startX, Y: down ? a.Bottom : a.TopY);
        var end = (X: endX, Y: down ? b.TopY : b.Bottom);
        var gapAfter = down ? a.Row + 1 : a.Row;          // gap index next to the source, towards the target
        var gapBefore = down ? b.Row : b.Row + 1;         // gap index next to the target, towards the source
        var between = Enumerable.Range(Math.Min(a.Row, b.Row) + 1, Math.Abs(a.Row - b.Row) - 1).ToList();

        if (between.Count == 0)
        {
            if (Math.Abs(start.X - end.X) < 0.5)
            {
                r.Points = [start, end];
                return;
            }
            r.Points = [start, (start.X, GapY(gapAfter)), (end.X, GapY(gapAfter)), end];
            r.GapSegments.Add((gapAfter, 1));
            return;
        }

        // Skipping layers: find a vertical corridor that is clear of every box in the rows in between.
        bool Free(double x) => between.All(row => rows[row].All(box => x <= box.Left - Clearance || x >= box.Right + Clearance));
        var candidates = new List<double> { end.X, start.X };
        foreach (var row in between.Select(i => rows[i].OrderBy(bx => bx.X).ToList()))
        {
            for (var i = 0; i + 1 < row.Count; i++)
            {
                candidates.Add((row[i].Right + row[i + 1].Left) / 2);
            }
            if (row.Count > 0)
            {
                candidates.Add(row[0].Left - Col / 4);
                candidates.Add(row[^1].Right + Col / 4);
            }
        }
        var corridor = candidates.Where(Free).OrderBy(x => Math.Abs(x - start.X) + Math.Abs(x - end.X)).First();
        if (Math.Abs(corridor - end.X) < 0.5)
        {
            r.Points = Math.Abs(start.X - end.X) < 0.5 ? [start, end] : [start, (start.X, GapY(gapAfter)), (end.X, GapY(gapAfter)), end];
            if (r.Points.Count == 4)
            {
                r.GapSegments.Add((gapAfter, 1));
            }
            return;
        }
        if (Math.Abs(corridor - start.X) < 0.5)
        {
            r.Points = [start, (start.X, GapY(gapBefore)), (end.X, GapY(gapBefore)), end];
            r.GapSegments.Add((gapBefore, 1));
            return;
        }
        r.Rerouted = true;
        r.Points = [start, (start.X, GapY(gapAfter)), (corridor, GapY(gapAfter)), (corridor, GapY(gapBefore)), (end.X, GapY(gapBefore)), end];
        r.GapSegments.Add((gapAfter, 1));
        r.GapSegments.Add((gapBefore, 3));
    }

    /// <summary>Horizontal runs in the same gap get separate lanes when they overlap, so lines never lie on top of each other.</summary>
    private static Dictionary<int, int> AssignLanes(List<Route> routes, Frame frame)
    {
        var counts = new Dictionary<int, int>();
        foreach (var group in routes.SelectMany(r => r.GapSegments.Select(s => (Route: r, s.Gap, s.Index))).GroupBy(s => s.Gap))
        {
            var segments = group.Select(s =>
            {
                var (x1, x2) = (s.Route.Points[s.Index].X, s.Route.Points[s.Index + 1].X);
                return (s.Route, s.Index, Min: Math.Min(x1, x2), Max: Math.Max(x1, x2));
            }).OrderBy(s => s.Min).ThenBy(s => s.Max).ToList();
            var laneEnds = new List<double>();
            var assigned = new List<(Route Route, int Index, int Lane)>();
            foreach (var s in segments)
            {
                var lane = laneEnds.FindIndex(end => end < s.Min - 14);
                if (lane < 0)
                {
                    laneEnds.Add(s.Max);
                    lane = laneEnds.Count - 1;
                }
                else
                {
                    laneEnds[lane] = s.Max;
                }
                assigned.Add((s.Route, s.Index, lane));
            }
            var lanes = laneEnds.Count;
            counts[group.Key] = lanes;
            var step = Math.Min(LaneStep, (frame.GapH[Math.Clamp(group.Key, 0, frame.GapH.Length - 1)] - 24) / Math.Max(1, lanes));
            foreach (var (route, index, lane) in assigned)
            {
                var y = frame.GapY(group.Key) + (lane - (lanes - 1) / 2.0) * step;
                route.Points[index] = (route.Points[index].X, y);
                route.Points[index + 1] = (route.Points[index + 1].X, y);
            }
        }
        return counts;
    }

    /// <summary>The first box (other than its own ends) that an arrow passes through, or null.</summary>
    private static string? Blocks(Route r, List<Box> boxes)
    {
        for (var i = 0; i + 1 < r.Points.Count; i++)
        {
            var (p, q) = (r.Points[i], r.Points[i + 1]);
            foreach (var box in boxes)
            {
                if (box == r.From || box == r.To)
                {
                    continue;
                }
                var (minX, maxX) = (Math.Min(p.X, q.X), Math.Max(p.X, q.X));
                var (minY, maxY) = (Math.Min(p.Y, q.Y), Math.Max(p.Y, q.Y));
                if (maxX > box.Left + 1 && minX < box.Right - 1 && maxY > box.TopY + 1 && minY < box.Bottom - 1)
                {
                    return box.Spec.Id;
                }
            }
        }
        return null;
    }

    private static int CountCrossings(List<Route> routes)
    {
        var crossings = 0;
        for (var i = 0; i < routes.Count; i++)
        {
            for (var j = i + 1; j < routes.Count; j++)
            {
                foreach (var (p1, q1) in Segments(routes[i]))
                {
                    foreach (var (p2, q2) in Segments(routes[j]))
                    {
                        var h1 = Math.Abs(p1.Y - q1.Y) < 0.01;
                        var h2 = Math.Abs(p2.Y - q2.Y) < 0.01;
                        if (h1 == h2)
                        {
                            continue;
                        }
                        var (h, v) = h1 ? ((p1, q1), (p2, q2)) : ((p2, q2), (p1, q1));
                        var (hx1, hx2) = (Math.Min(h.Item1.X, h.Item2.X), Math.Max(h.Item1.X, h.Item2.X));
                        var (vy1, vy2) = (Math.Min(v.Item1.Y, v.Item2.Y), Math.Max(v.Item1.Y, v.Item2.Y));
                        if (v.Item1.X > hx1 + 0.5 && v.Item1.X < hx2 - 0.5 && h.Item1.Y > vy1 + 0.5 && h.Item1.Y < vy2 - 0.5)
                        {
                            crossings++;
                        }
                    }
                }
            }
        }
        return crossings;

        static IEnumerable<((double X, double Y), (double X, double Y))> Segments(Route r)
        {
            for (var i = 0; i + 1 < r.Points.Count; i++)
            {
                yield return (r.Points[i], r.Points[i + 1]);
            }
        }
    }

    // ---------------------------------------------------------------- SVG

    private static string F(double v) => v.ToString("0.#", CultureInfo.InvariantCulture);
    private static string E(string? text) => WebUtility.HtmlEncode(text ?? "");

    private static string Clip(string? text, double width, double charWidth)
    {
        text = (text ?? "").Trim();
        var max = Math.Max(4, (int)(width / charWidth));
        return text.Length <= max ? text : text[..(max - 1)].TrimEnd() + "…";
    }

    /// <summary>The first user-perceived character: emoji built from several code points (🧑‍💼, 🛡️, flags) stay whole.</summary>
    private static string FirstCharacter(string? text)
        => string.IsNullOrWhiteSpace(text) ? "" : StringInfo.GetNextTextElement(text.Trim());

    private static (string Band, string Border) LayerColors(DiagramLayer layer, int index)
    {
        var named = Palette.FirstOrDefault(p => string.Equals(p.Name, layer.Color, StringComparison.OrdinalIgnoreCase));
        var (_, band, border) = named.Name is null ? Palette[index % Palette.Length] : named;
        return (band, border);
    }

    private static string Draw(DiagramSpec spec, List<List<Box>> rows, List<Box> boxes, List<Route> routes, Frame frame, out double width, out double height)
    {
        const string Font = "'Segoe UI', 'Inter', system-ui, -apple-system, sans-serif";
        const string EmojiFont = "'Segoe UI Emoji', 'Apple Color Emoji', 'Noto Color Emoji', sans-serif";
        var titleWidth = Margin + Math.Max((spec.Title?.Length ?? 0) * 14.5, (spec.Subtitle?.Length ?? 0) * 7.2) + Margin;
        width = Math.Max(boxes.Max(b => b.Right) + Margin + BandPad, titleWidth);
        var bandsBottom = frame.Bottom;
        var usedKinds = routes.Select(r => (r.Edge.Kind ?? "request").ToLowerInvariant()).Distinct().ToList();
        height = bandsBottom + (usedKinds.Count > 0 ? 64 : 24);

        var sb = new StringBuilder();
        sb.Append(CultureInfo.InvariantCulture, $"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{F(width)}\" height=\"{F(height)}\" viewBox=\"0 0 {F(width)} {F(height)}\" font-family=\"{Font}\">\n");
        sb.Append("<defs>\n<filter id=\"shadow\" x=\"-10%\" y=\"-10%\" width=\"120%\" height=\"140%\"><feDropShadow dx=\"0\" dy=\"2\" stdDeviation=\"3\" flood-color=\"#0f172a\" flood-opacity=\"0.10\"/></filter>\n");
        foreach (var (kind, (color, _, _)) in Kinds)
        {
            sb.Append(CultureInfo.InvariantCulture, $"<marker id=\"arrow-{kind}\" viewBox=\"0 0 10 10\" refX=\"10\" refY=\"5\" markerWidth=\"9\" markerHeight=\"9\" markerUnits=\"userSpaceOnUse\" orient=\"auto-start-reverse\"><path d=\"M0,0 L10,5 L0,10 z\" fill=\"{color}\"/></marker>\n");
        }
        sb.Append("</defs>\n");
        sb.Append(CultureInfo.InvariantCulture, $"<rect width=\"{F(width)}\" height=\"{F(height)}\" fill=\"#ffffff\"/>\n");
        sb.Append(CultureInfo.InvariantCulture, $"<text x=\"{F(Margin)}\" y=\"58\" font-size=\"26\" font-weight=\"700\" fill=\"#111827\">{E(spec.Title)}</text>\n");
        if (!string.IsNullOrWhiteSpace(spec.Subtitle))
        {
            sb.Append(CultureInfo.InvariantCulture, $"<text x=\"{F(Margin)}\" y=\"90\" font-size=\"14\" fill=\"#6b7280\">{E(spec.Subtitle)}</text>\n");
        }

        // Layer bands.
        for (var r = 0; r < rows.Count; r++)
        {
            var layer = spec.Layers[r];
            var (band, border) = LayerColors(layer, r);
            var y = frame.RowTop[r];
            var h = BandH;
            sb.Append(CultureInfo.InvariantCulture, $"<rect x=\"{F(Margin / 2)}\" y=\"{F(y)}\" width=\"{F(width - Margin)}\" height=\"{F(h)}\" rx=\"16\" fill=\"{band}\"/>\n");
            sb.Append(CultureInfo.InvariantCulture, $"<text x=\"{F(Margin)}\" y=\"{F(y + h / 2 + 2)}\" font-size=\"22\" font-weight=\"700\" fill=\"{border}\">{r + 1}</text>\n");
            sb.Append(CultureInfo.InvariantCulture, $"<text x=\"{F(Margin + 30)}\" y=\"{F(y + h / 2 - 4)}\" font-size=\"15\" font-weight=\"700\" fill=\"#111827\">{E(Clip(layer.Title, LeftTitle - 60, 8.4))}</text>\n");
            sb.Append(CultureInfo.InvariantCulture, $"<text x=\"{F(Margin + 30)}\" y=\"{F(y + h / 2 + 16)}\" font-size=\"12\" fill=\"#6b7280\">{rows[r].Count} component{(rows[r].Count == 1 ? "" : "s")}</text>\n");
        }

        // Arrows under the boxes, labels above them.
        var labels = new StringBuilder();
        var placedLabels = new List<(double X, double Y, double W)>();
        foreach (var route in routes)
        {
            var kind = (route.Edge.Kind ?? "request").ToLowerInvariant();
            var (color, dashed, _) = Kinds[kind];
            var d = new StringBuilder();
            for (var i = 0; i < route.Points.Count; i++)
            {
                d.Append(i == 0 ? 'M' : 'L').Append(F(route.Points[i].X)).Append(',').Append(F(route.Points[i].Y)).Append(' ');
            }
            sb.Append(CultureInfo.InvariantCulture, $"<path d=\"{d.ToString().TrimEnd()}\" fill=\"none\" stroke=\"{color}\" stroke-width=\"2\" stroke-linejoin=\"round\"{(dashed ? " stroke-dasharray=\"7 5\"" : "")} marker-end=\"url(#arrow-{kind})\"{(route.Edge.Both ? $" marker-start=\"url(#arrow-{kind})\"" : "")}/>\n");
            if (!string.IsNullOrWhiteSpace(route.Edge.Label))
            {
                // On the longest horizontal run, or the middle of the line when it is straight.
                var best = Enumerable.Range(0, route.Points.Count - 1)
                    .OrderByDescending(i => Math.Abs(route.Points[i].Y - route.Points[i + 1].Y) < 0.01 ? 1 : 0)
                    .ThenByDescending(i => Math.Abs(route.Points[i].X - route.Points[i + 1].X) + Math.Abs(route.Points[i].Y - route.Points[i + 1].Y))
                    .First();
                var (p, q) = (route.Points[best], route.Points[best + 1]);
                var text = Clip(route.Edge.Label, 150, 6.4);
                var w = text.Length * 6.4 + 12;
                var (cx, cy) = ((p.X + q.X) / 2, (p.Y + q.Y) / 2);
                if (route.Points.Count == 2 && Math.Abs(p.Y - q.Y) < 0.01 && Math.Abs(p.X - q.X) < w + 10)
                {
                    cy -= 14; // A short side link: the label sits above the line instead of covering it.
                }
                else
                {
                    // Slide along the segment until the label does not cover an earlier one.
                    var horizontal = Math.Abs(p.Y - q.Y) < 0.01;
                    var length = horizontal ? Math.Abs(q.X - p.X) : Math.Abs(q.Y - p.Y);
                    // Along the segment first; for short segments also above/below (or beside) it.
                    var along = new[] { 0.0, 0.25, -0.25, 0.4, -0.4 }.Select(t => horizontal ? ((p.X + q.X) / 2 + t * length, cy) : (cx, (p.Y + q.Y) / 2 + t * length));
                    var across = new[] { -22.0, 22.0, -44.0, 44.0 }.Select(o => horizontal ? (cx, cy + o) : (cx + o + Math.Sign(o) * w / 2, cy));
                    foreach (var (tx, ty) in along.Concat(across))
                    {
                        if (!placedLabels.Any(l => Math.Abs(l.X - tx) < (l.W + w) / 2 + 4 && Math.Abs(l.Y - ty) < 20))
                        {
                            (cx, cy) = (tx, ty);
                            break;
                        }
                    }
                }
                placedLabels.Add((cx, cy, w));
                labels.Append(CultureInfo.InvariantCulture, $"<rect x=\"{F(cx - w / 2)}\" y=\"{F(cy - 9)}\" width=\"{F(w)}\" height=\"18\" rx=\"9\" fill=\"#ffffff\" stroke=\"{color}\" stroke-width=\"1\"/>\n");
                labels.Append(CultureInfo.InvariantCulture, $"<text x=\"{F(cx)}\" y=\"{F(cy + 4)}\" font-size=\"11\" font-weight=\"600\" text-anchor=\"middle\" fill=\"{color}\">{E(text)}</text>\n");
            }
        }

        foreach (var b in boxes)
        {
            var (_, border) = LayerColors(spec.Layers[b.Row], b.Row);
            sb.Append(CultureInfo.InvariantCulture, $"<g filter=\"url(#shadow)\"><rect x=\"{F(b.Left)}\" y=\"{F(b.TopY)}\" width=\"{F(BoxW)}\" height=\"{F(BoxH)}\" rx=\"12\" fill=\"#ffffff\" stroke=\"{border}\" stroke-width=\"1.6\"/></g>\n");
            sb.Append(CultureInfo.InvariantCulture, $"<path d=\"M{F(b.Left + 12)},{F(b.TopY + 0.8)} L{F(b.Left + 6)},{F(b.TopY + 0.8)} Q{F(b.Left + 0.8)},{F(b.TopY + 0.8)} {F(b.Left + 0.8)},{F(b.TopY + 6)} L{F(b.Left + 0.8)},{F(b.Bottom - 6)} Q{F(b.Left + 0.8)},{F(b.Bottom - 0.8)} {F(b.Left + 6)},{F(b.Bottom - 0.8)} L{F(b.Left + 12)},{F(b.Bottom - 0.8)} Z\" fill=\"{border}\"/>\n");
            var textX = b.Left + 26;
            if (!string.IsNullOrWhiteSpace(b.Spec.Icon))
            {
                sb.Append(CultureInfo.InvariantCulture, $"<text x=\"{F(b.Left + 42)}\" y=\"{F(b.Y + 10)}\" font-size=\"28\" text-anchor=\"middle\" font-family=\"{EmojiFont}\">{E(FirstCharacter(b.Spec.Icon))}</text>\n");
                textX = b.Left + 70;
            }
            var textWidth = b.Right - 12 - textX;
            var hasSub = !string.IsNullOrWhiteSpace(b.Spec.Subtitle);
            sb.Append(CultureInfo.InvariantCulture, $"<text x=\"{F(textX)}\" y=\"{F(b.Y + (hasSub ? -4 : 5))}\" font-size=\"15\" font-weight=\"700\" fill=\"#111827\">{E(Clip(b.Spec.Title, textWidth, 8.3))}</text>\n");
            if (hasSub)
            {
                sb.Append(CultureInfo.InvariantCulture, $"<text x=\"{F(textX)}\" y=\"{F(b.Y + 17)}\" font-size=\"12\" fill=\"#6b7280\">{E(Clip(b.Spec.Subtitle, textWidth, 6.3))}</text>\n");
            }
        }
        sb.Append(labels);

        // Legend of the kinds in use.
        var lx = Margin;
        var ly = bandsBottom + 36;
        foreach (var kind in Kinds.Keys.Where(k => usedKinds.Contains(k, StringComparer.OrdinalIgnoreCase)))
        {
            var (color, dashed, legend) = Kinds[kind];
            sb.Append(CultureInfo.InvariantCulture, $"<line x1=\"{F(lx)}\" y1=\"{F(ly)}\" x2=\"{F(lx + 34)}\" y2=\"{F(ly)}\" stroke=\"{color}\" stroke-width=\"2.4\"{(dashed ? " stroke-dasharray=\"7 5\"" : "")}/>\n");
            sb.Append(CultureInfo.InvariantCulture, $"<text x=\"{F(lx + 44)}\" y=\"{F(ly + 4)}\" font-size=\"12.5\" fill=\"#374151\">{E(legend)}</text>\n");
            lx += 64 + legend.Length * 7.2;
        }
        sb.Append("</svg>\n");
        return sb.ToString();
    }
}
