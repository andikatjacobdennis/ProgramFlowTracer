using System.Collections.Concurrent;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using DocGen.Analysis.Git;
using DocGen.Analysis.Repositories;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Options;
using DocGen.Data.Storage;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Memory;

public static class MemoryCategories
{
    public static readonly IReadOnlyDictionary<string, string> All = new Dictionary<string, string>(StringComparer.Ordinal)
    {
        ["architecture"] = "Architecture",
        ["conventions"] = "Conventions",
        ["verification"] = "Verification practice",
        ["commands"] = "Build and test commands",
        ["layout"] = "Repository layout",
        ["limitations"] = "Known limitations",
        ["decisions"] = "Decisions",
        ["debugging"] = "Debugging lessons",
        ["benchmarks"] = "Benchmark baselines",
        ["releases"] = "Release history",
        ["roadmap"] = "Roadmap",
        ["environment"] = "Environment facts",
    };
}

public static class MemoryStatus
{
    public const string Proposed = "proposed";
    public const string Active = "active";
    public const string Stale = "stale";
    public const string Archived = "archived";
}

/// <summary>A repository fact the entry rests on: a file that must exist and, optionally, text it must contain.</summary>
public sealed class MemoryEvidence
{
    public string File { get; set; } = "";
    public string? Contains { get; set; }
}

/// <summary>One durable, non-secret project fact with provenance.</summary>
public sealed class MemoryEntry
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N")[..12];
    public string Category { get; set; } = "conventions";
    public string Title { get; set; } = "";
    public string Content { get; set; } = "";
    public List<string> Tags { get; set; } = [];
    public List<MemoryEvidence> Evidence { get; set; } = [];
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>agent | user</summary>
    public string CreatedBy { get; set; } = "agent";

    public string? CreatedByUserId { get; set; }
    public string? SourceConversationId { get; set; }
    public string? SourceRunId { get; set; }

    /// <summary>high | medium | low</summary>
    public string Confidence { get; set; } = "medium";

    public string Status { get; set; } = MemoryStatus.Proposed;
    public string? StaleReason { get; set; }
    public DateTime? VerifiedAt { get; set; }

    /// <summary>For a proposal that revises an existing entry.</summary>
    public string? Replaces { get; set; }
}

public sealed class MemoryDocument
{
    public string Repository { get; set; } = "";
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    public DateTime? RefreshedAt { get; set; }
    public List<MemoryEntry> Entries { get; set; } = [];
}

public sealed record MemoryHit(MemoryEntry Entry, double Score, string Repository);

/// <summary>
/// Quality gate for project memory: concise, durable, non-secret, supported by facts. Rejects credentials, log dumps,
/// speculative hypotheses and transient UI or session state.
/// </summary>
public static partial class MemoryPolicy
{
    public const int MaxTitle = 120;
    public const int MaxContent = 1500;
    public const int MaxLines = 25;

    public static List<string> Problems(MemoryEntry e, bool requireEvidence)
    {
        var problems = new List<string>();
        if (!MemoryCategories.All.ContainsKey(e.Category))
        {
            problems.Add($"unknown category '{e.Category}' (use {string.Join(", ", MemoryCategories.All.Keys)})");
        }
        if (e.Title.Trim().Length is < 3 or > MaxTitle)
        {
            problems.Add($"the title must be 3–{MaxTitle} characters");
        }
        if (e.Content.Trim().Length is < 10 or > MaxContent)
        {
            problems.Add($"the content must be 10–{MaxContent} characters (memory is for concise, durable facts)");
        }
        if (e.Content.Split('\n').Length > MaxLines)
        {
            problems.Add($"more than {MaxLines} lines — summarize instead of pasting");
        }
        var text = e.Title + "\n" + e.Content + "\n" + string.Join(" ", e.Tags);
        var secrets = SecretScanner.Find(text);
        if (secrets.Count > 0 || CredentialStatement().IsMatch(text))
        {
            problems.Add("it looks like it contains a credential" + (secrets.Count > 0 ? $" ({string.Join(", ", secrets)})" : "") + " — never store passwords, API keys or tokens");
        }
        if (LogLine().Matches(e.Content).Count >= 3 || StackFrame().Matches(e.Content).Count >= 2)
        {
            problems.Add("it looks like log or stack-trace output — store the lesson, not the output");
        }
        if (Speculative().Match(text) is { Success: true } s)
        {
            problems.Add($"it is speculative (\"{s.Value}\") — store only facts supported by evidence");
        }
        if (Transient().Match(text) is { Success: true } t)
        {
            problems.Add($"it describes transient session or UI state (\"{t.Value}\")");
        }
        if (e.Confidence is not ("high" or "medium" or "low"))
        {
            problems.Add("confidence must be high, medium or low");
        }
        foreach (var ev in e.Evidence)
        {
            if (!Packaging.SourcePackager.IsSafeEntryName(ev.File.Replace('\\', '/')))
            {
                problems.Add($"evidence path '{ev.File}' must be relative to the repository");
            }
        }
        if (requireEvidence && e.Evidence.Count == 0)
        {
            problems.Add("agent proposals need at least one evidence file (and optionally text it contains) so the fact can be re-checked");
        }
        return problems;
    }

    [GeneratedRegex(@"(?i)\b(password|passwd|passphrase|api[ _-]?key|access[ _-]?token|secret|bearer)\b\s*(is|=|:)\s*[""']?[^\s""']{6,}")]
    private static partial Regex CredentialStatement();

    [GeneratedRegex(@"(?m)^\s*(\[?\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}|\[\d{2}:\d{2}:\d{2}|(info|warn|fail|crit|dbug): )")]
    private static partial Regex LogLine();

    [GeneratedRegex(@"(?m)^\s+at \S+\(.*\)")]
    private static partial Regex StackFrame();

    [GeneratedRegex(@"(?i)\b(maybe|probably|perhaps|possibly|might be|could be|i think|i guess|not sure|hypothes[ie]s|suspect(ed)?|likely cause)\b")]
    private static partial Regex Speculative();

    [GeneratedRegex(@"(?i)\b(currently open|right now|this session|the (panel|dialog|tab) is (open|closed)|just clicked|scrolled to|at the moment)\b")]
    private static partial Regex Transient();
}

/// <summary>
/// Project memory: per-repository, durable facts with provenance (data/memory/{repository}/memory.json), separate from run
/// compaction. Agents only propose; a user accepts, edits or archives. Retrieval returns only the entries relevant to a
/// query; the store is never injected wholesale. When repository evidence disagrees with an entry, the repository wins
/// and the entry is marked stale.
/// </summary>
public sealed partial class ProjectMemoryService(
    IJsonStore store,
    RepositoryCatalog repositories,
    IOptionsMonitor<WorkflowOptions> options,
    ILogger<ProjectMemoryService> logger)
{
    private static string Key(RepositoryHandle repo) => Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(repo.IndexKey)))[..24];

    private static string PathOf(RepositoryHandle repo) => $"memory/{Key(repo)}/memory.json";

    public async Task<(RepositoryHandle Repo, MemoryDocument Document)> LoadAsync(string userId, string? repository, CancellationToken ct)
    {
        var repo = await repositories.ResolveAsync(userId, repository, ct);
        return (repo, await store.ReadAsync<MemoryDocument>(PathOf(repo), ct) ?? new MemoryDocument { Repository = repo.Name });
    }

    private async Task<T> MutateAsync<T>(string userId, string? repository, Func<RepositoryHandle, MemoryDocument, T> change, CancellationToken ct)
    {
        var repo = await repositories.ResolveAsync(userId, repository, ct);
        await using var _ = await store.AcquireLockAsync(PathOf(repo), ct);
        var doc = await store.ReadAsync<MemoryDocument>(PathOf(repo), ct) ?? new MemoryDocument { Repository = repo.Name };
        var result = change(repo, doc);
        doc.Repository = repo.Name;
        doc.UpdatedAt = DateTime.UtcNow;
        await store.WriteAsync(PathOf(repo), doc, ct);
        return result;
    }

    /// <summary>Adds a proposal (agent) or an active entry (user). A proposal with the same title and category replaces the older proposal.</summary>
    public async Task<MemoryEntry> ProposeAsync(string userId, string? repository, MemoryEntry draft, bool byUser, CancellationToken ct)
    {
        draft.Title = draft.Title.Trim();
        draft.Content = draft.Content.Trim();
        draft.Tags = draft.Tags.Select(t => t.Trim().ToLowerInvariant()).Where(t => t.Length is > 0 and <= 40).Distinct().Take(10).ToList();
        var problems = MemoryPolicy.Problems(draft, requireEvidence: !byUser);
        if (problems.Count > 0)
        {
            throw new ValidationException("Memory not saved: " + string.Join("; ", problems) + ".");
        }
        var (repo, _) = await LoadAsync(userId, repository, ct);
        var missing = draft.Evidence.Where(ev => !EvidenceHolds(repo, ev, out _)).Select(ev => ev.File).ToList();
        if (missing.Count > 0)
        {
            throw new ValidationException("Memory not saved: the repository does not support it (" + string.Join(", ", missing) + " missing or without the stated text).");
        }
        return await MutateAsync(userId, repository, (r, doc) =>
        {
            if (doc.Entries.Count(e => e.Status != MemoryStatus.Archived) >= options.CurrentValue.MaxMemoryEntries)
            {
                throw new ValidationException($"The project memory already holds {options.CurrentValue.MaxMemoryEntries} entries; archive some first.");
            }
            if (draft.Replaces is { } replaces && doc.Entries.All(e => e.Id != replaces))
            {
                throw new NotFoundException("Memory entry to revise");
            }
            draft.Status = byUser ? MemoryStatus.Active : MemoryStatus.Proposed;
            draft.CreatedBy = byUser ? "user" : "agent";
            draft.CreatedByUserId = userId;
            draft.CreatedAt = draft.UpdatedAt = DateTime.UtcNow;
            draft.VerifiedAt = draft.Evidence.Count > 0 ? DateTime.UtcNow : null;
            var duplicate = doc.Entries.FirstOrDefault(e => e.Status == MemoryStatus.Proposed && e.Category == draft.Category && e.Title.Equals(draft.Title, StringComparison.OrdinalIgnoreCase));
            if (duplicate is not null)
            {
                doc.Entries.Remove(duplicate);
                draft.Id = duplicate.Id;
                draft.CreatedAt = duplicate.CreatedAt;
            }
            if (byUser && draft.Replaces is { } old)
            {
                doc.Entries.First(e => e.Id == old).Status = MemoryStatus.Archived;
            }
            doc.Entries.Add(draft);
            logger.LogInformation("Project memory {Action} in {Repository}: {EntryId} ({Category})", byUser ? "entry added" : "proposal", r.Name, draft.Id, draft.Category);
            return draft;
        }, ct);
    }

    public async Task<MemoryEntry> EditAsync(string userId, string? repository, string id, string? title, string? content, string? category, List<string>? tags,
        string? confidence, List<MemoryEvidence>? evidence, CancellationToken ct)
        => await MutateAsync(userId, repository, (_, doc) =>
        {
            var entry = doc.Entries.FirstOrDefault(e => e.Id == id) ?? throw new NotFoundException("Memory entry");
            var copy = new MemoryEntry
            {
                Id = entry.Id, Title = title ?? entry.Title, Content = content ?? entry.Content, Category = category ?? entry.Category, Tags = tags ?? entry.Tags,
                Confidence = confidence ?? entry.Confidence, Evidence = evidence ?? entry.Evidence,
            };
            var problems = MemoryPolicy.Problems(copy, requireEvidence: false);
            if (problems.Count > 0)
            {
                throw new ValidationException("Memory not saved: " + string.Join("; ", problems) + ".");
            }
            (entry.Title, entry.Content, entry.Category, entry.Tags, entry.Confidence, entry.Evidence) = (copy.Title.Trim(), copy.Content.Trim(), copy.Category, copy.Tags, copy.Confidence, copy.Evidence);
            entry.UpdatedAt = DateTime.UtcNow;
            return entry;
        }, ct);

    /// <summary>accept (proposal → active; a revision archives the entry it replaces), archive, restore.</summary>
    public async Task<MemoryEntry> SetStatusAsync(string userId, string? repository, string id, string action, CancellationToken ct)
        => await MutateAsync(userId, repository, (_, doc) =>
        {
            var entry = doc.Entries.FirstOrDefault(e => e.Id == id) ?? throw new NotFoundException("Memory entry");
            switch (action)
            {
                case "accept":
                    if (entry.Status != MemoryStatus.Proposed)
                    {
                        throw new ValidationException("Only proposals can be accepted.");
                    }
                    entry.Status = MemoryStatus.Active;
                    if (entry.Replaces is { } old && doc.Entries.FirstOrDefault(e => e.Id == old) is { } previous)
                    {
                        previous.Status = MemoryStatus.Archived;
                    }
                    break;
                case "archive":
                    entry.Status = MemoryStatus.Archived;
                    break;
                case "restore":
                    entry.Status = MemoryStatus.Active;
                    entry.StaleReason = null;
                    break;
                default:
                    throw new ValidationException("action must be accept, archive or restore.");
            }
            entry.UpdatedAt = DateTime.UtcNow;
            return entry;
        }, ct);

    /// <summary>Re-checks every entry's evidence against the repository; failing entries become stale (the repository wins).</summary>
    public async Task<(int Checked, int Stale, int Restored)> RefreshAsync(string userId, string? repository, CancellationToken ct)
        => await MutateAsync(userId, repository, (repo, doc) =>
        {
            int checkedCount = 0, stale = 0, restored = 0;
            foreach (var e in doc.Entries.Where(e => e.Status is MemoryStatus.Active or MemoryStatus.Stale or MemoryStatus.Proposed && e.Evidence.Count > 0))
            {
                checkedCount++;
                var failures = new List<string>();
                foreach (var ev in e.Evidence)
                {
                    if (!EvidenceHolds(repo, ev, out var why))
                    {
                        failures.Add(why);
                    }
                }
                if (failures.Count > 0)
                {
                    if (e.Status != MemoryStatus.Stale)
                    {
                        stale++;
                    }
                    e.Status = e.Status == MemoryStatus.Proposed ? MemoryStatus.Proposed : MemoryStatus.Stale;
                    e.StaleReason = "Repository evidence no longer supports this: " + string.Join("; ", failures);
                }
                else
                {
                    if (e.Status == MemoryStatus.Stale)
                    {
                        e.Status = MemoryStatus.Active;
                        restored++;
                    }
                    e.StaleReason = null;
                    e.VerifiedAt = DateTime.UtcNow;
                }
            }
            doc.RefreshedAt = DateTime.UtcNow;
            return (checkedCount, stale, restored);
        }, ct);

    private static bool EvidenceHolds(RepositoryHandle repo, MemoryEvidence ev, out string why)
    {
        why = "";
        string full;
        try
        {
            full = repo.Resolve(ev.File);
        }
        catch (Exception ex) when (ex is ValidationException or ForbiddenException or ArgumentException)
        {
            why = $"{ev.File} is outside the repository";
            return false;
        }
        if (!File.Exists(full) && !Directory.Exists(full))
        {
            why = $"{ev.File} no longer exists";
            return false;
        }
        if (ev.Contains is { Length: > 0 } text && File.Exists(full))
        {
            if (new FileInfo(full).Length > 8 * 1024 * 1024 || !File.ReadAllText(full).Contains(text, StringComparison.Ordinal))
            {
                why = $"{ev.File} no longer contains \"{text}\"";
                return false;
            }
        }
        return true;
    }

    /// <summary>Relevance retrieval (never the whole store): active entries scored by query terms in title, tags and content.</summary>
    public static List<(MemoryEntry Entry, double Score)> Rank(IEnumerable<MemoryEntry> entries, string query, string? category, bool includeStale, int limit, double minimum = 1.0)
    {
        var terms = Terms(query);
        if (terms.Count == 0)
        {
            return [];
        }
        var list = new List<(MemoryEntry, double)>();
        foreach (var e in entries.Where(e => e.Status == MemoryStatus.Active || includeStale && e.Status == MemoryStatus.Stale))
        {
            if (category is not null && e.Category != category)
            {
                continue;
            }
            var title = Terms(e.Title);
            var tags = e.Tags.SelectMany(Terms).ToHashSet(StringComparer.Ordinal);
            var content = Terms(e.Content);
            double score = 0;
            foreach (var t in terms)
            {
                score += (title.Contains(t) ? 3 : 0) + (tags.Contains(t) ? 2 : 0) + (content.Contains(t) ? 1 : 0) + (e.Category == t ? 1 : 0);
            }
            score *= e.Confidence switch { "high" => 1.2, "low" => 0.7, _ => 1.0 } * (e.Status == MemoryStatus.Stale ? 0.5 : 1.0);
            if (score >= minimum)
            {
                list.Add((e, score));
            }
        }
        return list.OrderByDescending(p => p.Item2).ThenByDescending(p => p.Item1.UpdatedAt).Take(limit).ToList();
    }

    private static HashSet<string> Terms(string text)
        => Word().Matches(text.ToLowerInvariant()).Select(m => m.Value).Where(w => w.Length >= 3 && !StopWords.Contains(w)).ToHashSet(StringComparer.Ordinal);

    private static readonly HashSet<string> StopWords = new(StringComparer.Ordinal)
    {
        "the", "and", "for", "with", "that", "this", "from", "into", "are", "was", "were", "has", "have", "not", "use", "used", "using", "all", "any", "can",
        "how", "what", "when", "where", "which", "why", "does", "should", "would", "will", "you", "your", "our", "its", "their", "about", "please",
    };

    public async Task<List<MemoryHit>> SearchAsync(string userId, IEnumerable<string?> repositoryNames, string query, string? category, int limit, CancellationToken ct, double minimum = 1.0)
    {
        var hits = new List<MemoryHit>();
        foreach (var name in repositoryNames.Distinct())
        {
            try
            {
                var (repo, doc) = await LoadAsync(userId, name, ct);
                hits.AddRange(Rank(doc.Entries, query, category, includeStale: false, limit, minimum).Select(p => new MemoryHit(p.Entry, p.Score, repo.Name)));
            }
            catch (Exception ex) when (ex is NotFoundException or ForbiddenException)
            {
                // Repository no longer accessible.
            }
        }
        return hits.OrderByDescending(h => h.Score).Take(limit).ToList();
    }

    /// <summary>The compact index (like INDEX.md): one line per active or stale entry, grouped by category.</summary>
    public static string IndexMarkdown(MemoryDocument doc)
    {
        var sb = new StringBuilder($"# Project memory — {doc.Repository}\n\n");
        sb.AppendLine($"Updated {doc.UpdatedAt:yyyy-MM-dd HH:mm} UTC · {doc.Entries.Count(e => e.Status == MemoryStatus.Active)} active · {doc.Entries.Count(e => e.Status == MemoryStatus.Stale)} stale · {doc.Entries.Count(e => e.Status == MemoryStatus.Proposed)} proposed" +
            (doc.RefreshedAt is { } r ? $" · evidence checked {r:yyyy-MM-dd HH:mm} UTC" : ""));
        foreach (var group in doc.Entries.Where(e => e.Status is MemoryStatus.Active or MemoryStatus.Stale).GroupBy(e => e.Category).OrderBy(g => g.Key, StringComparer.Ordinal))
        {
            sb.Append("\n## ").AppendLine(MemoryCategories.All.GetValueOrDefault(group.Key, group.Key));
            foreach (var e in group.OrderBy(e => e.Title, StringComparer.OrdinalIgnoreCase))
            {
                var first = e.Content.Split('\n')[0];
                sb.AppendLine(CultureInfo.InvariantCulture, $"- {e.Title} [{e.Id}]{(e.Status == MemoryStatus.Stale ? " (STALE)" : "")} — {(first.Length > 140 ? first[..140] + "…" : first)}");
            }
        }
        return sb.ToString();
    }

    public static string Describe(MemoryEntry e, string? repository = null)
        => $"[{(repository is null ? "" : repository + " · ")}{e.Category}] {e.Title} ({e.Id}; {e.Status}; confidence {e.Confidence}; updated {e.UpdatedAt:yyyy-MM-dd}" +
           (e.SourceRunId is null ? "" : $"; source run {e.SourceRunId}") + ")\n" + e.Content +
           (e.Evidence.Count > 0 ? "\nEvidence: " + string.Join(", ", e.Evidence.Select(ev => ev.File + (ev.Contains is null ? "" : $" contains \"{ev.Contains}\""))) : "") +
           (e.StaleReason is null ? "" : "\nSTALE: " + e.StaleReason);

    [GeneratedRegex(@"[a-z0-9][a-z0-9_.\-]*[a-z0-9]|[a-z0-9]")]
    private static partial Regex Word();
}

/// <summary>
/// Adds at most a few project-memory entries relevant to the current request to the model context (never the whole store),
/// marked as possibly outdated: repository evidence always wins.
/// </summary>
public sealed class MemoryContextContributor(ProjectMemoryService memory, RepositoryCatalog repositories, IMessageRepository messages) : IContextContributor
{
    private readonly ConcurrentDictionary<string, string?> _cache = new(StringComparer.Ordinal);

    public async Task<string?> GetPinnedContextAsync(ToolExecutionContext context, CancellationToken cancellationToken)
    {
        if (context.ConversationId is null)
        {
            return null;
        }
        var key = context.RunId ?? context.ConversationId;
        if (_cache.TryGetValue(key, out var cached))
        {
            return cached;
        }
        var list = await messages.ListAsync(context.ConversationId, cancellationToken);
        var request = list.Where(m => m.Role == Core.Models.MessageRole.User && m.UserId == context.UserId).OrderBy(m => m.CreatedAt).LastOrDefault()?.Text;
        string? result = null;
        if (request is { Length: > 0 })
        {
            var repos = (await repositories.ListAsync(context.UserId, cancellationToken)).Select(r => (string?)r.Name).ToList();
            var hits = await memory.SearchAsync(context.UserId, repos, request, null, 3, cancellationToken, minimum: 3.0);
            if (hits.Count > 0)
            {
                var sb = new StringBuilder("Project memory relevant to this request (may be outdated — when the repository says otherwise, the repository wins; use memory_search for more):\n");
                foreach (var h in hits)
                {
                    var content = h.Entry.Content.Length > 400 ? h.Entry.Content[..400] + "…" : h.Entry.Content;
                    sb.AppendLine(CultureInfo.InvariantCulture, $"- [{h.Repository} · {h.Entry.Category}] {h.Entry.Title}: {content} ({h.Entry.Id}, updated {h.Entry.UpdatedAt:yyyy-MM-dd})");
                }
                result = sb.ToString();
            }
        }
        if (_cache.Count > 500)
        {
            _cache.Clear();
        }
        _cache[key] = result;
        return result;
    }
}
