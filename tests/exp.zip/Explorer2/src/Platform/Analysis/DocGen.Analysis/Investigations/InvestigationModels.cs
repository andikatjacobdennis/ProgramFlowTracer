using DocGen.Analysis.Rca;
using DocGen.Core.Models;

namespace DocGen.Analysis.Investigations;

public enum InvestigationStatus
{
    Open,
    Reproduced,
    RootCauseConfirmed,
    Fixed,
    Verified,
    Closed,
}

public enum HypothesisStatus
{
    Open,
    Supported,
    Weakened,
    Rejected,
    Confirmed,
}

public static class EvidenceKinds
{
    /// <summary>Something directly observed in code, configuration, logs or data.</summary>
    public const string Fact = "fact";

    /// <summary>A deliberate test of a hypothesis (what was done and what was expected).</summary>
    public const string Experiment = "experiment";

    /// <summary>The observed outcome of an experiment, command or reproduction.</summary>
    public const string Result = "result";

    public static bool IsValid(string kind) => kind is Fact or Experiment or Result;
}

public sealed class EvidenceItem
{
    public string Id { get; set; } = "";
    public string Kind { get; set; } = EvidenceKinds.Fact;
    public string Summary { get; set; } = "";

    /// <summary>Where it came from: "path:line", a symbol, "command:{id}", a blob reference or a tool call.</summary>
    public string? Source { get; set; }

    public string? HypothesisId { get; set; }
    public string? RunId { get; set; }

    /// <summary>True when DocGen recorded it automatically from a tool result (e.g. a command outcome).</summary>
    public bool Automatic { get; set; }

    /// <summary>
    /// True for a counterfactual experiment DocGen ran itself (counterfactual_run): the candidate fix was applied to a
    /// scratch copy and the failing test rerun. Only DocGen sets it; the model cannot record it.
    /// </summary>
    public bool Counterfactual { get; set; }

    /// <summary>For counterfactual evidence: failureGone | failurePersists | inconclusive (derived from the command record).</summary>
    public string? Outcome { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public sealed class HypothesisChange
{
    public DateTime At { get; set; } = DateTime.UtcNow;
    public HypothesisStatus From { get; set; }
    public HypothesisStatus To { get; set; }
    public string Reason { get; set; } = "";
}

public sealed class Hypothesis
{
    public string Id { get; set; } = "";
    public string Statement { get; set; } = "";
    public HypothesisStatus Status { get; set; } = HypothesisStatus.Open;
    public string? Location { get; set; }
    public List<string> SupportingEvidence { get; set; } = [];
    public List<string> ContradictingEvidence { get; set; } = [];
    public List<HypothesisChange> History { get; set; } = [];

    /// <summary>Why a counterfactual experiment was impossible, when the hypothesis was confirmed without one.</summary>
    public string? Limitation { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}

public sealed class ReproductionRecord
{
    /// <summary>notAttempted | reproduced | notReproduced | notReproducible</summary>
    public string Status { get; set; } = "notAttempted";

    public string? Details { get; set; }
    public string? CommandId { get; set; }
    public DateTime? At { get; set; }
}

public sealed class RootCauseRecord
{
    public string Statement { get; set; } = "";
    public string HypothesisId { get; set; } = "";
    public string? Location { get; set; }
    public List<string> EvidenceIds { get; set; } = [];
    public DateTime ConfirmedAt { get; set; } = DateTime.UtcNow;
}

public sealed class FixRecord
{
    public string Summary { get; set; } = "";
    public string? Rationale { get; set; }
    public List<string> FilesChanged { get; set; } = [];
    public int LinesAdded { get; set; }
    public int LinesRemoved { get; set; }
    public DateTime At { get; set; } = DateTime.UtcNow;
}

public sealed class VerificationRecord
{
    public string CommandId { get; set; } = "";
    public string Kind { get; set; } = "";
    public string CommandLine { get; set; } = "";

    /// <summary>Derived by DocGen from the command record — never taken from the model.</summary>
    public bool Passed { get; set; }

    public string Summary { get; set; } = "";
    public DateTime At { get; set; } = DateTime.UtcNow;
}

public sealed class TimelineEntry
{
    public DateTime At { get; set; } = DateTime.UtcNow;
    public string Kind { get; set; } = "";
    public string Text { get; set; } = "";
}

/// <summary>
/// Durable investigation memory: symptom, reproduction, evidence ledger, hypotheses and their status history, root
/// cause, fix and verification. It is stored outside the conversation, so it survives context compaction and run
/// resumption; its summary is pinned into the model context on every call. It contains only externally meaningful
/// facts and decisions — never hidden model reasoning.
/// </summary>
public sealed class Investigation : Entity, IOwnedEntity
{
    public string UserId { get; set; } = "";
    public string? ConversationId { get; set; }
    public string? ProjectId { get; set; }
    public string Title { get; set; } = "";
    public string Symptom { get; set; } = "";
    public string Repository { get; set; } = "workspace";
    public InvestigationStatus Status { get; set; } = InvestigationStatus.Open;
    public ReproductionRecord Reproduction { get; set; } = new();
    public List<EvidenceItem> Evidence { get; set; } = [];
    public List<Hypothesis> Hypotheses { get; set; } = [];
    public RootCauseRecord? RootCause { get; set; }
    public FixRecord? Fix { get; set; }
    public List<VerificationRecord> Verification { get; set; } = [];
    public string? RegressionRisk { get; set; }
    public string? RemainingUncertainty { get; set; }
    public List<string> InspectedFiles { get; set; } = [];
    public List<string> RunIds { get; set; } = [];
    public int ToolCalls { get; set; }
    public List<TimelineEntry> Timeline { get; set; } = [];
    public string? Report { get; set; }

    /// <summary>Latest root-cause analysis (rank_root_causes): primary trace (origin first), ranked candidates, experiments.</summary>
    public RcaSnapshot? Rca { get; set; }

    /// <summary>Investigative modifications made before confirmation (tests, scratch files) — never production code.</summary>
    public List<string> InvestigativeChanges { get; set; } = [];
    public DateTime? ReproducedAt { get; set; }
    public DateTime? RootCauseAt { get; set; }
    public DateTime? FixedAt { get; set; }
    public DateTime? VerifiedAt { get; set; }
    public DateTime? ClosedAt { get; set; }
}

/// <summary>The persisted part of an <see cref="RcaReport"/> (bounded; all provenance nodes are not stored).</summary>
public sealed class RcaSnapshot
{
    public string Summary { get; set; } = "";
    public string? FailureKind { get; set; }
    public List<ProvenanceNode> Trace { get; set; } = [];
    public List<CauseCandidate> Candidates { get; set; } = [];
    public List<ProposedExperiment> Experiments { get; set; } = [];
    public List<string> Ambiguities { get; set; } = [];
    public List<string> Findings { get; set; } = [];
    public RcaStats Stats { get; set; } = new();
    public DateTime At { get; set; } = DateTime.UtcNow;

    public static RcaSnapshot From(RcaReport report) => new()
    {
        Summary = report.Summary, FailureKind = report.FailureKind, Trace = report.Trace.Take(30).ToList(), Candidates = report.Candidates.Take(10).ToList(),
        Experiments = report.Experiments.Take(8).ToList(), Ambiguities = report.Ambiguities.Take(10).ToList(), Findings = report.Findings.Distinct().Take(15).ToList(), Stats = report.Stats,
    };
}
