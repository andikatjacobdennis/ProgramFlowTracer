using System.Collections.Concurrent;
using System.Text;
using DocGen.Analysis.Commands;
using DocGen.Analysis.Rca;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Data.Storage;
using DocGen.Core.Options;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Investigations;

/// <summary>
/// Owns investigation records and enforces the debugging discipline in C#:
/// <list type="bullet">
/// <item>A hypothesis can be Confirmed only after the failure was reproduced (or recorded as not reproducible with a
/// justification) and at least one experiment/result evidence item supports it.</item>
/// <item>Supported/Weakened/Rejected require linked evidence.</item>
/// <item>A fix can only be recorded once a root cause is confirmed.</item>
/// <item>Verification status is derived from the command record, never from the model's claim.</item>
/// </list>
/// </summary>
public sealed class InvestigationService(IJsonStore store, CommandRunner commands, IOptionsMonitor<AnalysisOptions> options, ILogger<InvestigationService> logger)
{
    private bool RequireCounterfactual => options.CurrentValue.RequireCounterfactualForConfirmation;

    public const int MaxEvidence = 500;
    public const int MaxHypotheses = 50;
    public const int MaxInspectedFiles = 5000;
    public const int MaxTimeline = 1000;

    private readonly ConcurrentDictionary<string, string> _byConversation = new(StringComparer.Ordinal);

    private JsonRepository<Investigation> Repo(string userId) => new(store, $"investigations/{Ids.Require(userId, "user id")}");

    public async Task<Investigation> CreateAsync(string userId, string symptom, string? title, string repository, string? conversationId, string? projectId, CancellationToken ct)
    {
        symptom = symptom.Trim();
        if (symptom.Length is < 3 or > 20_000)
        {
            throw new ValidationException("Describe the symptom in 3–20,000 characters.");
        }
        if (conversationId is not null && await GetActiveForConversationAsync(userId, conversationId, ct) is { } existing)
        {
            throw new ValidationException($"This conversation already has an active investigation ({existing.Id}). Close it before starting another.");
        }
        var investigation = new Investigation
        {
            UserId = userId,
            ConversationId = conversationId,
            ProjectId = projectId,
            Symptom = symptom,
            Title = string.IsNullOrWhiteSpace(title) ? MakeTitle(symptom) : title.Trim()[..Math.Min(title.Trim().Length, 120)],
            Repository = repository,
        };
        investigation.Timeline.Add(new TimelineEntry { Kind = "created", Text = "Investigation started: " + Clip(symptom, 200) });
        await Repo(userId).CreateAsync(investigation, ct);
        if (conversationId is not null)
        {
            _byConversation[conversationId] = investigation.Id;
        }
        logger.LogInformation("Investigation {InvestigationId} started for {UserId} in repository {Repository}", investigation.Id, userId, repository);
        return investigation;
    }

    public async Task<Investigation> GetAsync(string userId, string id, CancellationToken ct)
        => await Repo(userId).GetAsync(id, ct) is { } i && i.UserId == userId ? i : throw new NotFoundException("Investigation");

    public Task<List<Investigation>> ListAsync(string userId, CancellationToken ct) => Repo(userId).ListAsync(i => i.UserId == userId, ct);

    public async Task<Investigation?> GetActiveForConversationAsync(string userId, string conversationId, CancellationToken ct)
    {
        if (_byConversation.TryGetValue(conversationId, out var cachedId))
        {
            var cached = await Repo(userId).GetAsync(cachedId, ct);
            if (cached is { Status: not InvestigationStatus.Closed } && cached.UserId == userId && cached.ConversationId == conversationId)
            {
                return cached;
            }
            _byConversation.TryRemove(conversationId, out _);
        }
        var found = (await Repo(userId).ListAsync(i => i.ConversationId == conversationId && i.Status != InvestigationStatus.Closed && i.UserId == userId, ct))
            .OrderByDescending(i => i.CreatedAt).FirstOrDefault();
        if (found is not null)
        {
            _byConversation[conversationId] = found.Id;
        }
        return found;
    }

    public Task<Investigation> UpdateAsync(string userId, string id, Action<Investigation> mutate, CancellationToken ct)
        => Repo(userId).UpdateAsync(id, i =>
        {
            if (i.UserId != userId)
            {
                throw new NotFoundException("Investigation");
            }
            mutate(i);
            if (i.Timeline.Count > MaxTimeline)
            {
                i.Timeline.RemoveRange(0, i.Timeline.Count - MaxTimeline);
            }
        }, ct: ct);

    public Task<Investigation> AddEvidenceAsync(string userId, string id, string kind, string summary, string? source, string? hypothesisId, string? runId, bool automatic, CancellationToken ct)
    {
        if (!EvidenceKinds.IsValid(kind))
        {
            throw new ValidationException("Evidence kind must be fact, experiment or result.");
        }
        summary = summary.Trim();
        if (summary.Length is 0 or > 4000)
        {
            throw new ValidationException("Evidence summaries must be 1–4,000 characters.");
        }
        return UpdateAsync(userId, id, i =>
        {
            if (i.Evidence.Count >= MaxEvidence)
            {
                throw new ValidationException($"The evidence ledger is full ({MaxEvidence} items).");
            }
            if (hypothesisId is not null && i.Hypotheses.All(h => h.Id != hypothesisId))
            {
                throw new ValidationException($"Unknown hypothesis '{hypothesisId}'.");
            }
            var item = new EvidenceItem
            {
                Id = "E" + (i.Evidence.Count + 1), Kind = kind, Summary = summary, Source = source is { Length: > 300 } ? source[..300] : source,
                HypothesisId = hypothesisId, RunId = runId, Automatic = automatic,
            };
            i.Evidence.Add(item);
            if (hypothesisId is not null)
            {
                i.Hypotheses.First(h => h.Id == hypothesisId).SupportingEvidence.Add(item.Id);
            }
            i.Timeline.Add(new TimelineEntry { Kind = kind, Text = $"{item.Id}: {Clip(summary, 160)}" });
        }, ct);
    }

    /// <summary>
    /// Records the outcome of a counterfactual experiment DocGen ran (the outcome is derived from the command record).
    /// failureGone supports the hypothesis, failurePersists contradicts it, inconclusive is only linked.
    /// </summary>
    public Task<Investigation> AddCounterfactualEvidenceAsync(string userId, string id, string summary, string source, string? hypothesisId, string outcome, string? runId, CancellationToken ct)
    {
        if (outcome is not ("failureGone" or "failurePersists" or "inconclusive"))
        {
            throw new ValidationException("Unknown counterfactual outcome.");
        }
        return UpdateAsync(userId, id, i =>
        {
            if (i.Evidence.Count >= MaxEvidence)
            {
                throw new ValidationException($"The evidence ledger is full ({MaxEvidence} items).");
            }
            var hypothesis = hypothesisId is null ? null : i.Hypotheses.FirstOrDefault(h => h.Id == hypothesisId) ?? throw new ValidationException($"Unknown hypothesis '{hypothesisId}'.");
            var item = new EvidenceItem
            {
                Id = "E" + (i.Evidence.Count + 1), Kind = EvidenceKinds.Experiment, Summary = Clip(summary.Trim(), 4000), Source = Clip(source, 300),
                HypothesisId = hypothesisId, RunId = runId, Automatic = true, Counterfactual = true, Outcome = outcome,
            };
            i.Evidence.Add(item);
            if (hypothesis is not null && outcome == "failureGone")
            {
                hypothesis.SupportingEvidence.Add(item.Id);
            }
            else if (hypothesis is not null && outcome == "failurePersists")
            {
                hypothesis.ContradictingEvidence.Add(item.Id);
            }
            i.Timeline.Add(new TimelineEntry { Kind = "counterfactual", Text = $"{item.Id}: {outcome} — {Clip(summary, 140)}" });
        }, ct);
    }

    /// <summary>Stores the latest root-cause analysis (bounded snapshot) on the investigation.</summary>
    public Task<Investigation> SetRcaAsync(string userId, string id, RcaSnapshot snapshot, CancellationToken ct)
        => UpdateAsync(userId, id, i =>
        {
            i.Rca = snapshot;
            var top = snapshot.Candidates.FirstOrDefault();
            i.Timeline.Add(new TimelineEntry { Kind = "rca", Text = top is null ? "Root-cause ranking: no candidates" : $"Root-cause ranking: #1 {Clip(top.Title, 100)} ({top.Strength})" });
        }, ct);

    /// <summary>Records an investigative (non-production) modification made before the root cause was confirmed.</summary>
    public Task<Investigation> RecordInvestigativeChangeAsync(string userId, string id, string path, CancellationToken ct)
        => UpdateAsync(userId, id, i =>
        {
            if (!i.InvestigativeChanges.Contains(path, StringComparer.OrdinalIgnoreCase) && i.InvestigativeChanges.Count < 200)
            {
                i.InvestigativeChanges.Add(path);
                i.Timeline.Add(new TimelineEntry { Kind = "investigative-change", Text = $"Investigative modification (not a fix): {Clip(path, 140)}" });
            }
        }, ct);

    public Task<Investigation> AddHypothesisAsync(string userId, string id, string statement, string? location, CancellationToken ct)
    {
        statement = statement.Trim();
        if (statement.Length is < 5 or > 2000)
        {
            throw new ValidationException("A hypothesis must be 5–2,000 characters.");
        }
        return UpdateAsync(userId, id, i =>
        {
            if (i.Hypotheses.Count >= MaxHypotheses)
            {
                throw new ValidationException($"Too many hypotheses ({MaxHypotheses}); reject or merge some first.");
            }
            var hypothesis = new Hypothesis { Id = "H" + (i.Hypotheses.Count + 1), Statement = statement, Location = location };
            i.Hypotheses.Add(hypothesis);
            i.Timeline.Add(new TimelineEntry { Kind = "hypothesis", Text = $"{hypothesis.Id}: {Clip(statement, 160)}" });
        }, ct);
    }

    /// <summary>Changes a hypothesis status, enforcing the evidence rules (see class remarks).</summary>
    public Task<Investigation> UpdateHypothesisAsync(string userId, string id, string hypothesisId, HypothesisStatus status,
        IReadOnlyList<string> supporting, IReadOnlyList<string> contradicting, string reason, CancellationToken ct, string? limitation = null)
        => UpdateAsync(userId, id, i =>
        {
            var hypothesis = i.Hypotheses.FirstOrDefault(h => h.Id == hypothesisId) ?? throw new ValidationException($"Unknown hypothesis '{hypothesisId}'.");
            foreach (var evidenceId in supporting.Concat(contradicting))
            {
                if (i.Evidence.All(e => e.Id != evidenceId))
                {
                    throw new ValidationException($"Unknown evidence '{evidenceId}'. Record evidence first (investigation_record).");
                }
            }
            foreach (var e in supporting.Where(e => !hypothesis.SupportingEvidence.Contains(e)))
            {
                hypothesis.SupportingEvidence.Add(e);
            }
            foreach (var e in contradicting.Where(e => !hypothesis.ContradictingEvidence.Contains(e)))
            {
                hypothesis.ContradictingEvidence.Add(e);
            }

            if (!string.IsNullOrWhiteSpace(limitation))
            {
                hypothesis.Limitation = Clip(limitation.Trim(), 2000);
            }
            var problem = CheckTransition(i, hypothesis, status, reason, RequireCounterfactual);
            if (problem is not null)
            {
                throw new DocGenException("INVESTIGATION_RULE", problem, 409);
            }

            hypothesis.History.Add(new HypothesisChange { From = hypothesis.Status, To = status, Reason = Clip(reason.Trim(), 1000) });
            hypothesis.Status = status;
            i.Timeline.Add(new TimelineEntry { Kind = "hypothesis", Text = $"{hypothesis.Id} → {status}: {Clip(reason, 160)}" });

            if (status == HypothesisStatus.Confirmed)
            {
                i.RootCause = new RootCauseRecord
                {
                    Statement = hypothesis.Statement, HypothesisId = hypothesis.Id, Location = hypothesis.Location,
                    EvidenceIds = hypothesis.SupportingEvidence.ToList(),
                };
                i.RootCauseAt = DateTime.UtcNow;
                if (i.Status < InvestigationStatus.RootCauseConfirmed)
                {
                    i.Status = InvestigationStatus.RootCauseConfirmed;
                }
                // Only one confirmed root cause: others that were confirmed become supported.
                foreach (var other in i.Hypotheses.Where(h => h != hypothesis && h.Status == HypothesisStatus.Confirmed))
                {
                    other.History.Add(new HypothesisChange { From = other.Status, To = HypothesisStatus.Supported, Reason = $"Superseded by {hypothesis.Id}" });
                    other.Status = HypothesisStatus.Supported;
                }
            }
            else if (i.RootCause?.HypothesisId == hypothesis.Id)
            {
                // The confirmed root cause was withdrawn.
                i.RootCause = null;
                i.RootCauseAt = null;
                if (i.Status == InvestigationStatus.RootCauseConfirmed)
                {
                    i.Status = i.Reproduction.Status == "reproduced" ? InvestigationStatus.Reproduced : InvestigationStatus.Open;
                }
            }
        }, ct);

    internal static string? CheckTransition(Investigation i, Hypothesis hypothesis, HypothesisStatus status, string reason, bool requireCounterfactual = true)
    {
        if (string.IsNullOrWhiteSpace(reason))
        {
            return "A reason is required for every hypothesis status change.";
        }
        switch (status)
        {
            case HypothesisStatus.Supported when hypothesis.SupportingEvidence.Count == 0:
                return "Supported requires at least one supporting evidence id.";
            case HypothesisStatus.Weakened or HypothesisStatus.Rejected when hypothesis.ContradictingEvidence.Count == 0:
                return $"{status} requires at least one contradicting evidence id.";
            case HypothesisStatus.Confirmed:
                if (hypothesis.Status == HypothesisStatus.Rejected)
                {
                    return "A rejected hypothesis cannot be confirmed; add a new hypothesis instead.";
                }
                if (i.Reproduction.Status is not ("reproduced" or "notReproducible"))
                {
                    return "Root cause not yet confirmed: reproduce the failure first (record a reproduction), or record it as not reproducible with a justification.";
                }
                var observed = hypothesis.SupportingEvidence
                    .Select(id => i.Evidence.FirstOrDefault(e => e.Id == id))
                    .Count(e => e is { Kind: EvidenceKinds.Result or EvidenceKinds.Experiment });
                if (observed == 0)
                {
                    return "Root cause not yet confirmed: confirmation requires at least one supporting experiment or result evidence item (an observed outcome), not only facts or reasoning.";
                }
                if (hypothesis.ContradictingEvidence.Count > 0 && hypothesis.ContradictingEvidence.Count >= hypothesis.SupportingEvidence.Count)
                {
                    return "Root cause not yet confirmed: contradicting evidence outweighs the supporting evidence.";
                }
                if (!requireCounterfactual)
                {
                    break;
                }
                var linked = i.Evidence.Where(e => e.HypothesisId == hypothesis.Id || hypothesis.SupportingEvidence.Contains(e.Id)).ToList();
                if (linked.Any(e => e is { Counterfactual: true, Outcome: "failurePersists" }) && !linked.Any(e => e is { Counterfactual: true, Outcome: "failureGone" }))
                {
                    return "Root cause not yet confirmed: the counterfactual experiment did not remove the failure.";
                }
                var counterfactual = linked.Any(e => e is { Counterfactual: true, Outcome: "failureGone" });
                if (!counterfactual && (hypothesis.Limitation?.Trim().Length ?? 0) < 20)
                {
                    return "Root cause not yet confirmed: confirmation requires a counterfactual experiment that removes the failure (counterfactual_run with hypothesisId), " +
                           "or — only when that is impossible — a documented limitation (hypothesis_update limitation=…, at least 20 characters) explaining why.";
                }
                break;
        }
        return null;
    }

    /// <summary>Records reproduction. When a command id is given, its real outcome is attached as result evidence.</summary>
    public async Task<Investigation> SetReproductionAsync(string userId, string id, string status, string details, string? commandId, string? runId, CancellationToken ct)
    {
        if (status is not ("reproduced" or "notReproduced" or "notReproducible"))
        {
            throw new ValidationException("Reproduction status must be reproduced, notReproduced or notReproducible.");
        }
        if (status == "notReproducible" && details.Trim().Length < 20)
        {
            throw new ValidationException("Explain (at least 20 characters) why the failure cannot be reproduced.");
        }
        CommandRecord? command = null;
        if (commandId is not null)
        {
            command = await commands.GetAsync(userId, commandId, ct);
            if (!command.IsFinal)
            {
                throw new ValidationException("The command is still running; wait for it to finish before recording the reproduction.");
            }
        }
        var investigation = await UpdateAsync(userId, id, i =>
        {
            i.Reproduction = new ReproductionRecord { Status = status, Details = Clip(details.Trim(), 4000), CommandId = commandId, At = DateTime.UtcNow };
            if (status == "reproduced")
            {
                i.ReproducedAt ??= DateTime.UtcNow;
                if (i.Status == InvestigationStatus.Open)
                {
                    i.Status = InvestigationStatus.Reproduced;
                }
            }
            i.Timeline.Add(new TimelineEntry { Kind = "reproduction", Text = $"Reproduction: {status} — {Clip(details, 160)}" });
        }, ct);
        if (command is not null)
        {
            investigation = await AddEvidenceAsync(userId, id, EvidenceKinds.Result, "Reproduction command: " + DescribeCommand(command), "command:" + command.Id, null, runId, automatic: true, ct);
        }
        return investigation;
    }

    public Task<Investigation> RecordFixAsync(string userId, string id, string summary, string? rationale, IReadOnlyList<string> files, int added, int removed, CancellationToken ct)
        => UpdateAsync(userId, id, i =>
        {
            if (i.RootCause is null)
            {
                throw new DocGenException("INVESTIGATION_RULE", "Root cause not yet confirmed: a fix can only be recorded after a hypothesis is confirmed.", 409);
            }
            var fix = i.Fix ?? new FixRecord();
            fix.Summary = Clip(summary.Trim(), 2000);
            fix.Rationale = rationale is null ? fix.Rationale : Clip(rationale.Trim(), 2000);
            foreach (var f in files.Where(f => !fix.FilesChanged.Contains(f)))
            {
                fix.FilesChanged.Add(f);
            }
            fix.LinesAdded += added;
            fix.LinesRemoved += removed;
            fix.At = DateTime.UtcNow;
            i.Fix = fix;
            i.FixedAt = DateTime.UtcNow;
            if (i.Status < InvestigationStatus.Fixed)
            {
                i.Status = InvestigationStatus.Fixed;
            }
            i.Timeline.Add(new TimelineEntry { Kind = "fix", Text = Clip(summary, 160) });
        }, ct);

    /// <summary>Attaches a finished build/test command as verification; pass/fail comes from the command record.</summary>
    public async Task<Investigation> RecordVerificationAsync(string userId, string id, string commandId, CancellationToken ct)
    {
        var command = await commands.GetAsync(userId, commandId, ct);
        if (!command.IsFinal)
        {
            throw new ValidationException("The command is still running; wait for it to finish.");
        }
        var passed = command.Status == CommandStatus.Succeeded
                     && (command.Tests is null || command.Tests.Result == "passed" && (command.Tests.Failed ?? 0) == 0)
                     && (command.Build is null || command.Build.ErrorCount == 0);
        var investigation = await UpdateAsync(userId, id, i =>
        {
            i.Verification.Add(new VerificationRecord { CommandId = command.Id, Kind = command.Kind, CommandLine = command.CommandLine, Passed = passed, Summary = DescribeCommand(command) });
            if (passed && i.Fix is not null && i.Status < InvestigationStatus.Verified)
            {
                i.Status = InvestigationStatus.Verified;
                i.VerifiedAt = DateTime.UtcNow;
            }
            i.Timeline.Add(new TimelineEntry { Kind = "verification", Text = $"{(passed ? "PASSED" : "FAILED")}: {command.CommandLine}" });
        }, ct);
        return await AddEvidenceAsync(userId, id, EvidenceKinds.Result, "Verification command: " + DescribeCommand(command), "command:" + command.Id, null, command.RunId, automatic: true, ct);
    }

    public Task TrackAsync(string userId, string id, IEnumerable<string> inspectedFiles, bool countToolCall, string? runId, CancellationToken ct)
        => UpdateAsync(userId, id, i =>
        {
            foreach (var file in inspectedFiles)
            {
                if (i.InspectedFiles.Count < MaxInspectedFiles && !i.InspectedFiles.Contains(file))
                {
                    i.InspectedFiles.Add(file);
                }
            }
            if (countToolCall)
            {
                i.ToolCalls++;
            }
            if (runId is not null && !i.RunIds.Contains(runId))
            {
                i.RunIds.Add(runId);
            }
        }, ct);

    public static string DescribeCommand(CommandRecord c)
    {
        var sb = new StringBuilder($"`{c.CommandLine}` → {c.Status}");
        if (c.ExitCode is { } code)
        {
            sb.Append($" (exit {code})");
        }
        if (c.Tests is { } t)
        {
            sb.Append($"; tests: {t.Passed ?? 0} passed, {t.Failed ?? 0} failed, {t.Skipped ?? 0} skipped");
            foreach (var f in t.Failures.Take(3))
            {
                sb.Append($"; FAILED {f.Name}: {Clip(f.ExceptionType ?? f.Message ?? "", 120)}");
            }
        }
        if (c.Build is { } b)
        {
            sb.Append($"; build {b.Result}: {b.ErrorCount} errors, {b.WarningCount} warnings");
            foreach (var e in b.Errors.Take(3))
            {
                sb.Append($"; {e.Code} {Path.GetFileName(e.File)}:{e.Line} {Clip(e.Message, 100)}");
            }
        }
        return sb.ToString();
    }

    /// <summary>The Root Cause Report, generated deterministically from the ledger (no model involvement).</summary>
    public static string BuildReport(Investigation i)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"# Root Cause Report — {i.Title}");
        sb.AppendLine();
        sb.AppendLine($"Investigation {i.Id} · repository `{i.Repository}` · status **{i.Status}** · generated {DateTime.UtcNow:yyyy-MM-dd HH:mm} UTC");
        sb.AppendLine();
        sb.AppendLine("## Symptom");
        sb.AppendLine(i.Symptom);
        sb.AppendLine();
        sb.AppendLine("## Reproduction");
        sb.AppendLine(i.Reproduction.Status switch
        {
            "reproduced" => $"Reproduced. {i.Reproduction.Details}",
            "notReproduced" => $"Not reproduced yet. {i.Reproduction.Details}",
            "notReproducible" => $"Not reproducible: {i.Reproduction.Details}",
            _ => "Not attempted.",
        });
        if (i.Reproduction.CommandId is { } rc)
        {
            sb.AppendLine($"Command: `{rc}`");
        }
        sb.AppendLine();
        sb.AppendLine("## Root Cause");
        if (i.RootCause is { } root)
        {
            sb.AppendLine($"**{root.Statement}** ({root.HypothesisId}{(root.Location is null ? "" : ", " + root.Location)})");
        }
        else
        {
            sb.AppendLine("**Root cause not yet confirmed.**");
        }
        sb.AppendLine();
        if (i.Rca is { } rca)
        {
            sb.AppendLine("## Root Cause Trace");
            sb.AppendLine(rca.Summary);
            sb.AppendLine();
            for (var n = 0; n < rca.Trace.Count; n++)
            {
                var node = rca.Trace[n];
                sb.AppendLine($"{(n == 0 ? "- **origin** " : "- ↓ ")}{node.Title}{(node.File is null ? "" : $" — `{node.File}{(node.Line is { } nl ? ":" + nl : "")}`")}{(node.Confidence == "definite" ? "" : $" ({node.Confidence})")}");
            }
            sb.AppendLine();
            sb.AppendLine("## Candidate Causes");
            foreach (var group in rca.Candidates.GroupBy(c => c.Strength))
            {
                sb.AppendLine($"**{group.Key}**");
                foreach (var c in group)
                {
                    sb.AppendLine($"- {c.Title} ({c.Role}) — {c.Why}");
                    foreach (var against in c.Evidence.Where(e => e.Contradicts))
                    {
                        sb.AppendLine($"  - against: {against.Text}");
                    }
                }
            }
            if (rca.Experiments.Count > 0)
            {
                sb.AppendLine();
                sb.AppendLine("## Proposed Experiments");
                foreach (var e in rca.Experiments)
                {
                    sb.AppendLine($"- {e.Id} ({e.Cost}{(e.Tool is null ? "" : ", " + e.Tool)}): {e.Description} — {e.Discriminates}");
                }
            }
            if (rca.Ambiguities.Count > 0)
            {
                sb.AppendLine();
                sb.AppendLine("Ambiguities (name-based resolution): " + string.Join("; ", rca.Ambiguities.Take(5)));
            }
            sb.AppendLine();
        }
        if (i.InvestigativeChanges.Count > 0)
        {
            sb.AppendLine("## Investigative Modifications");
            sb.AppendLine("Made before confirmation to gather evidence (tests, scratch files); not part of the fix:");
            foreach (var change in i.InvestigativeChanges.Take(30))
            {
                sb.AppendLine($"- `{change}`");
            }
            sb.AppendLine();
        }
        sb.AppendLine("## Evidence");
        if (i.Evidence.Count == 0)
        {
            sb.AppendLine("No evidence recorded.");
        }
        var relevant = i.RootCause is { } rcause ? i.Evidence.Where(e => rcause.EvidenceIds.Contains(e.Id)).Concat(i.Evidence.Where(e => !rcause.EvidenceIds.Contains(e.Id))) : i.Evidence;
        foreach (var e in relevant.Take(60))
        {
            sb.AppendLine($"- **{e.Id} {e.Kind.ToUpperInvariant()}**{(e.Counterfactual ? $" counterfactual: {e.Outcome}" : "")}{(e.Automatic ? " (recorded by DocGen)" : "")}: {e.Summary}{(e.Source is null ? "" : $" — `{e.Source}`")}");
        }
        if (i.Evidence.Count > 60)
        {
            sb.AppendLine($"- … {i.Evidence.Count - 60} more items in the ledger.");
        }
        sb.AppendLine();
        sb.AppendLine("## Hypotheses");
        foreach (var h in i.Hypotheses)
        {
            sb.AppendLine($"- **{h.Id} [{h.Status}]** {h.Statement} (for: {Join(h.SupportingEvidence)}; against: {Join(h.ContradictingEvidence)}){(h.Limitation is null ? "" : $" — confirmed without a counterfactual: {h.Limitation}")}");
        }
        if (i.Hypotheses.Count == 0)
        {
            sb.AppendLine("None recorded.");
        }
        sb.AppendLine();
        sb.AppendLine("## Fix");
        sb.AppendLine(i.Fix is { } fix ? fix.Summary + (fix.Rationale is null ? "" : $"\n\nWhy this is minimal: {fix.Rationale}") : "No fix applied.");
        sb.AppendLine();
        sb.AppendLine("## Files Changed");
        if (i.Fix is { FilesChanged.Count: > 0 } f)
        {
            foreach (var file in f.FilesChanged)
            {
                sb.AppendLine($"- `{file}`");
            }
            sb.AppendLine($"(+{f.LinesAdded} / −{f.LinesRemoved} lines)");
        }
        else
        {
            sb.AppendLine("None.");
        }
        sb.AppendLine();
        sb.AppendLine("## Verification");
        if (i.Verification.Count == 0)
        {
            sb.AppendLine("Not verified.");
        }
        foreach (var v in i.Verification)
        {
            sb.AppendLine($"- {(v.Passed ? "PASSED" : "FAILED")} — {v.Summary}");
        }
        sb.AppendLine();
        sb.AppendLine("## Regression Risk");
        sb.AppendLine(i.RegressionRisk ?? "Not assessed.");
        sb.AppendLine();
        sb.AppendLine("## Remaining Uncertainty");
        sb.AppendLine(i.RemainingUncertainty ?? (i.RootCause is null ? "The root cause has not been confirmed." : "None recorded."));
        sb.AppendLine();
        sb.AppendLine($"Inspected files: {i.InspectedFiles.Count} · tool calls: {i.ToolCalls} · runs: {i.RunIds.Count}");
        return sb.ToString();
    }

    /// <summary>Compact memory block pinned into the model context (bounded).</summary>
    public static string BuildMemory(Investigation i)
    {
        var sb = new StringBuilder();
        sb.AppendLine("BUG INVESTIGATION MODE — rules enforced by DocGen:");
        sb.AppendLine("- Work in this order: reproduce → gather FACTS → state HYPOTHESES → run EXPERIMENTS → record RESULTS → confirm ROOT CAUSE → minimal FIX → VERIFICATION → regression check.");
        sb.AppendLine("- Production source edits are blocked until a hypothesis is Confirmed: reproduced, connected by evidence, tested by a discriminating experiment and a counterfactual (counterfactual_run) that removes the failure. Tests and scratch files may be edited as investigative changes. Anything not backed by evidence is a hypothesis; say \"Root cause not yet confirmed\" until it is.");
        sb.AppendLine("- Trace backwards, not from the crash site: rank_root_causes (failure → provenance trace → ranked causes), trace_value_origin, compare_json_contracts, config_provenance, find_race_risks, json_anomalies. The throw site is rarely the origin.");
        sb.AppendLine("- Retrieve narrowly: solution_overview → project_overview → find_symbol/find_references/find_callers → read_symbol/read_source_range. Do not read whole files or dump large outputs; expand references (blob://) only as needed.");
        sb.AppendLine("- Record evidence with investigation_record and hypothesis changes with hypothesis_update. Prefer the smallest fix that addresses the confirmed root cause; then run the narrowest tests, widening as needed.");
        sb.AppendLine();
        sb.AppendLine($"Investigation {i.Id}: {i.Title} [{i.Status}] · repository: {i.Repository}");
        sb.AppendLine("Symptom: " + Clip(i.Symptom, 600));
        sb.AppendLine($"Reproduction: {i.Reproduction.Status}{(i.Reproduction.Details is null ? "" : " — " + Clip(i.Reproduction.Details, 200))}");
        if (i.Hypotheses.Count > 0)
        {
            sb.AppendLine("Hypotheses:");
            foreach (var h in i.Hypotheses.OrderBy(h => h.Status is HypothesisStatus.Rejected ? 1 : 0).Take(12))
            {
                sb.AppendLine($"- {h.Id} [{h.Status}] {Clip(h.Statement, 200)} (for: {Join(h.SupportingEvidence)}; against: {Join(h.ContradictingEvidence)})");
            }
        }
        if (i.Evidence.Count > 0)
        {
            sb.AppendLine($"Evidence (latest {Math.Min(10, i.Evidence.Count)} of {i.Evidence.Count}):");
            foreach (var e in i.Evidence.TakeLast(10))
            {
                sb.AppendLine($"- {e.Id} {e.Kind.ToUpperInvariant()}: {Clip(e.Summary, 220)}{(e.Source is null ? "" : " [" + Clip(e.Source, 80) + "]")}");
            }
        }
        if (i.Rca is { } rca)
        {
            sb.AppendLine($"Root-cause ranking ({rca.At:HH:mm} UTC, not proof):");
            foreach (var c in rca.Candidates.Take(5))
            {
                sb.AppendLine($"- [{c.Strength}] {Clip(c.Title, 120)} ({c.Role}): {Clip(c.Why, 200)}");
            }
            if (rca.Trace.Count > 0)
            {
                sb.AppendLine("Trace (origin → failure): " + Clip(string.Join(" → ", rca.Trace.Select(n => Clip(n.Title, 70))), 600));
            }
            foreach (var e in rca.Experiments.Take(3))
            {
                sb.AppendLine($"- Experiment {e.Id}: {Clip(e.Description, 180)}");
            }
        }
        sb.AppendLine("Root cause: " + (i.RootCause is { } r ? $"{r.Statement} ({r.HypothesisId})" : "not yet confirmed"));
        if (i.Fix is { } fix)
        {
            sb.AppendLine($"Fix: {Clip(fix.Summary, 200)} · files: {string.Join(", ", fix.FilesChanged.Take(5))}");
        }
        if (i.Verification.Count > 0)
        {
            var last = i.Verification[^1];
            sb.AppendLine($"Last verification: {(last.Passed ? "PASSED" : "FAILED")} — {Clip(last.Summary, 200)}");
        }
        sb.AppendLine($"Inspected files: {i.InspectedFiles.Count}{(i.InspectedFiles.Count > 0 ? " (latest: " + string.Join(", ", i.InspectedFiles.TakeLast(5)) + ")" : "")}");
        return sb.ToString();
    }

    private static string Join(List<string> ids) => ids.Count == 0 ? "—" : string.Join(", ", ids);

    private static string MakeTitle(string symptom)
    {
        var line = symptom.Split('\n')[0].Trim();
        return line.Length > 80 ? line[..80] + "…" : line;
    }

    internal static string Clip(string? value, int max) => string.IsNullOrEmpty(value) ? "" : value.Length <= max ? value : value[..max] + "…";
}
