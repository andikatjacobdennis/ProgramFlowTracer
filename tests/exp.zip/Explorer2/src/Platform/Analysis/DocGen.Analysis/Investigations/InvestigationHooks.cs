using DocGen.Analysis.Indexing;
using DocGen.Analysis.Repositories;
using DocGen.Core.Abstractions;
using DocGen.Core.Models;
using DocGen.Core.Options;
using DocGen.Tools.Infrastructure;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Investigations;

/// <summary>
/// Blocks production source modifications while the conversation's active investigation has no confirmed root cause
/// ("never modify code on a hypothesis alone"). Investigative modifications stay possible: files in test projects and
/// under a "scratch/" directory (reproduction tests, temporary repro projects, instrumentation) are allowed and recorded
/// on the investigation as investigative changes, separate from the fix. Enforced in C# for every run.
/// </summary>
public sealed class RootCauseEditGuard(InvestigationService investigations, IOptionsMonitor<AnalysisOptions> options,
    RepositoryCatalog? repositories = null, CodeIndexService? indexes = null) : IToolExecutionGuard
{
    public static readonly HashSet<string> GuardedTools = new(StringComparer.Ordinal) { "source_edit", "file_write" };

    public const string BlockedMessage =
        "Root cause not yet confirmed. DocGen does not modify production code on a hypothesis alone: reproduce the failure, trace it (rank_root_causes), " +
        "run a discriminating experiment and a counterfactual (counterfactual_run) and confirm a hypothesis (hypothesis_update status=Confirmed) before editing. " +
        "Tests and files under scratch/ may be edited as investigative changes.";

    public async Task<string?> CheckAsync(IAgentTool tool, ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken)
    {
        if (!GuardedTools.Contains(tool.Name) || !options.CurrentValue.RequireConfirmedRootCauseForEdits || context.ConversationId is null)
        {
            return null;
        }
        var active = await investigations.GetActiveForConversationAsync(context.UserId, context.ConversationId, cancellationToken);
        if (active is not { RootCause: null })
        {
            return null;
        }
        var path = await InvestigativePathAsync(tool.Name, call, context, cancellationToken);
        if (path is null)
        {
            return BlockedMessage;
        }
        await investigations.RecordInvestigativeChangeAsync(context.UserId, active.Id, path, CancellationToken.None);
        return null;
    }

    /// <summary>The target path when the edit is investigative (test project or scratch), otherwise null.</summary>
    private async Task<string?> InvestigativePathAsync(string toolName, ToolCall call, ToolExecutionContext context, CancellationToken ct)
    {
        string? path;
        string? repository;
        try
        {
            var args = ToolArguments.Parse(call);
            path = args.GetString("path")?.Replace('\\', '/').TrimStart('/');
            repository = args.GetString("repository");
        }
        catch (Exception)
        {
            return null;
        }
        if (string.IsNullOrWhiteSpace(path) || path.Split('/').Contains(".."))
        {
            return null;
        }
        if (IsScratch(path))
        {
            return path;
        }
        if (toolName != "source_edit" || repositories is null || indexes is null)
        {
            return null;
        }
        try
        {
            var repo = await repositories.ResolveAsync(context.UserId, repository, ct);
            var index = await indexes.GetAsync(repo, ct);
            var relative = repo.Relative(repo.Resolve(path)).Replace('\\', '/');
            return index.Files.TryGetValue(relative, out var file) && !string.IsNullOrEmpty(file.Project) && index.IsTestProject(file.Project)
                ? (repo.Name == RepositoryCatalog.WorkspaceName ? relative : $"{repo.Name}:{relative}")
                : null;
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            return null;
        }
    }

    public static bool IsScratch(string path)
        => path.StartsWith("scratch/", StringComparison.OrdinalIgnoreCase) || path.Contains("/scratch/", StringComparison.OrdinalIgnoreCase);
}

/// <summary>Pins the active investigation's memory into every model call of the conversation.</summary>
public sealed class InvestigationContextContributor(InvestigationService investigations) : IContextContributor
{
    public async Task<string?> GetPinnedContextAsync(ToolExecutionContext context, CancellationToken cancellationToken)
    {
        if (context.ConversationId is null)
        {
            return null;
        }
        var active = await investigations.GetActiveForConversationAsync(context.UserId, context.ConversationId, cancellationToken);
        return active is null ? null : InvestigationService.BuildMemory(active);
    }
}

/// <summary>Counts tool calls and links runs to the active investigation (for the benchmark and the UI).</summary>
public sealed class InvestigationToolObserver(InvestigationService investigations) : IToolExecutionObserver
{
    public async Task OnToolCompletedAsync(ToolCall call, ToolResult result, ToolExecutionContext context, long durationMs, CancellationToken cancellationToken)
    {
        if (context.ConversationId is null)
        {
            return;
        }
        var active = await investigations.GetActiveForConversationAsync(context.UserId, context.ConversationId, cancellationToken);
        if (active is not null)
        {
            await investigations.TrackAsync(context.UserId, active.Id, [], countToolCall: true, context.RunId, cancellationToken);
        }
    }
}
