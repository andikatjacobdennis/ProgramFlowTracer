using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Options;
using DocGen.Data.Storage;
using DocGen.Security;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Repositories;

/// <summary>A source tree the debugging tools may read, resolved for one user.</summary>
public sealed class RepositoryHandle
{
    public required string Name { get; init; }
    public required string Root { get; init; }
    public bool AllowWrite { get; init; }
    public bool AllowCommands { get; init; }

    /// <summary>workspace | configured | registered</summary>
    public required string Source { get; init; }

    /// <summary>Stable storage key for this repository's index (per user for workspaces).</summary>
    public required string IndexKey { get; init; }

    /// <summary>Resolves a model-supplied relative path inside the repository (traversal, links and absolute paths rejected).</summary>
    public string Resolve(string? relativePath) => WorkspacePathResolver.Resolve(Root, relativePath);

    public string Relative(string fullPath) => WorkspacePathResolver.ToRelative(Root, fullPath);
}

/// <summary>Repositories registered at runtime by an administrator (data/analysis/repositories.json).</summary>
public sealed class RegisteredRepositories
{
    public List<RepositoryOptions> Repositories { get; set; } = [];
}

/// <summary>
/// Resolves repository names to roots and enforces who may use them. The model only ever names a repository;
/// roots come from server configuration (appsettings or the admin API). Every user always has "workspace" — their
/// own isolated workspace folder. Configured repositories are restricted to administrators unless users are listed.
/// </summary>
public sealed partial class RepositoryCatalog(
    IOptionsMonitor<AnalysisOptions> options,
    IUserRepository users,
    IFileService files,
    IJsonStore store)
{
    public const string WorkspaceName = "workspace";
    private const string RegisteredPath = "analysis/repositories.json";

    public async Task<IReadOnlyList<RepositoryHandle>> ListAsync(string userId, CancellationToken ct = default)
    {
        var user = await users.GetAsync(userId, ct) ?? throw new NotFoundException("User");
        var list = new List<RepositoryHandle> { Workspace(userId) };
        foreach (var (repo, source) in await AllConfiguredAsync(ct))
        {
            if (!CanUse(repo, user.UserName, user.IsAdmin) || !Directory.Exists(repo.Path))
            {
                continue;
            }
            list.Add(ToHandle(repo, source));
        }
        return list;
    }

    public async Task<RepositoryHandle> ResolveAsync(string userId, string? name, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(name) || string.Equals(name, WorkspaceName, StringComparison.OrdinalIgnoreCase))
        {
            return Workspace(userId);
        }
        var all = await ListAsync(userId, ct);
        return all.FirstOrDefault(r => string.Equals(r.Name, name, StringComparison.OrdinalIgnoreCase))
               ?? throw new NotFoundException($"Repository '{Truncate(name)}'");
    }

    public async Task<IReadOnlyList<RepositoryOptions>> ListRegisteredAsync(CancellationToken ct = default)
        => (await store.ReadAsync<RegisteredRepositories>(RegisteredPath, ct))?.Repositories ?? [];

    /// <summary>Administrator only (enforced by the API). The path must be an existing absolute directory.</summary>
    public async Task<RepositoryOptions> RegisterAsync(RepositoryOptions repository, CancellationToken ct = default)
    {
        ValidateName(repository.Name);
        if (string.IsNullOrWhiteSpace(repository.Path) || !Path.IsPathFullyQualified(repository.Path))
        {
            throw new ValidationException("The repository path must be an absolute path.");
        }
        var full = Path.GetFullPath(repository.Path);
        if (!Directory.Exists(full))
        {
            throw new ValidationException("The repository folder does not exist on the server.");
        }
        if (Path.GetPathRoot(full) is { } driveRoot && string.Equals(full.TrimEnd(Path.DirectorySeparatorChar), driveRoot.TrimEnd(Path.DirectorySeparatorChar), StringComparison.OrdinalIgnoreCase))
        {
            throw new ValidationException("A drive root cannot be registered as a repository.");
        }
        if (string.Equals(repository.Name, WorkspaceName, StringComparison.OrdinalIgnoreCase)
            || options.CurrentValue.Repositories.Any(r => string.Equals(r.Name, repository.Name, StringComparison.OrdinalIgnoreCase)))
        {
            throw new ValidationException("A repository with this name already exists.");
        }
        repository.Path = full;
        repository.Users = repository.Users.Where(u => !string.IsNullOrWhiteSpace(u)).Select(u => u.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).Take(100).ToList();

        await using (await store.AcquireLockAsync(RegisteredPath, ct))
        {
            var current = await store.ReadAsync<RegisteredRepositories>(RegisteredPath, ct) ?? new RegisteredRepositories();
            current.Repositories.RemoveAll(r => string.Equals(r.Name, repository.Name, StringComparison.OrdinalIgnoreCase));
            current.Repositories.Add(repository);
            await store.WriteAsync(RegisteredPath, current, ct);
        }
        return repository;
    }

    public async Task<bool> UnregisterAsync(string name, CancellationToken ct = default)
    {
        await using (await store.AcquireLockAsync(RegisteredPath, ct))
        {
            var current = await store.ReadAsync<RegisteredRepositories>(RegisteredPath, ct) ?? new RegisteredRepositories();
            var removed = current.Repositories.RemoveAll(r => string.Equals(r.Name, name, StringComparison.OrdinalIgnoreCase)) > 0;
            if (removed)
            {
                await store.WriteAsync(RegisteredPath, current, ct);
            }
            return removed;
        }
    }

    private RepositoryHandle Workspace(string userId) => new()
    {
        Name = WorkspaceName,
        Root = files.GetWorkspaceRoot(userId),
        AllowWrite = true,
        AllowCommands = true,
        Source = "workspace",
        IndexKey = "workspace-" + userId,
    };

    private async Task<List<(RepositoryOptions Repo, string Source)>> AllConfiguredAsync(CancellationToken ct)
    {
        var list = options.CurrentValue.Repositories.Where(r => IsValidName(r.Name) && Path.IsPathFullyQualified(r.Path)).Select(r => (r, "configured")).ToList();
        foreach (var registered in await ListRegisteredAsync(ct))
        {
            if (IsValidName(registered.Name) && list.All(l => !string.Equals(l.r.Name, registered.Name, StringComparison.OrdinalIgnoreCase)))
            {
                list.Add((registered, "registered"));
            }
        }
        return list;
    }

    private static bool CanUse(RepositoryOptions repo, string userName, bool isAdmin)
        => isAdmin || repo.Users.Any(u => string.Equals(u, userName, StringComparison.OrdinalIgnoreCase) || u == "*");

    private static RepositoryHandle ToHandle(RepositoryOptions repo, string source) => new()
    {
        Name = repo.Name,
        Root = Path.GetFullPath(repo.Path),
        AllowWrite = repo.AllowWrite,
        AllowCommands = repo.AllowCommands,
        Source = source,
        IndexKey = "repo-" + Sanitize(repo.Name) + "-" + Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(Path.GetFullPath(repo.Path).ToLowerInvariant())))[..12].ToLowerInvariant(),
    };

    public static void ValidateName(string name)
    {
        if (!IsValidName(name))
        {
            throw new ValidationException("Repository names use 1–64 letters, digits, '.', '-' or '_'.");
        }
    }

    private static bool IsValidName(string? name) => name is not null && NamePattern().IsMatch(name);

    private static string Sanitize(string name) => new(name.Select(c => char.IsAsciiLetterOrDigit(c) ? char.ToLowerInvariant(c) : '-').ToArray());

    private static string Truncate(string value) => value.Length > 64 ? value[..64] : value;

    [GeneratedRegex("^[A-Za-z0-9._-]{1,64}$")]
    private static partial Regex NamePattern();
}
