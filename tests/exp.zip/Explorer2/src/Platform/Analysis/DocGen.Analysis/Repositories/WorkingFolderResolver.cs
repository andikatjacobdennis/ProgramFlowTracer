using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;

namespace DocGen.Analysis.Repositories;

/// <summary>Resolves a chat's selected repository through <see cref="RepositoryCatalog"/>, so access rules apply.</summary>
public sealed class WorkingFolderResolver(RepositoryCatalog repositories) : IWorkingFolderResolver
{
    public async Task<WorkingFolder?> ResolveAsync(string userId, string? name, CancellationToken cancellationToken)
    {
        try
        {
            var repo = await repositories.ResolveAsync(userId, name, cancellationToken);
            return new WorkingFolder(repo.Name, repo.Root, repo.AllowWrite, repo.AllowCommands, repo.Source == "workspace");
        }
        catch (NotFoundException)
        {
            return null;
        }
    }
}
