using System.Globalization;
using System.Text;
using DocGen.Core.Abstractions;

namespace DocGen.Analysis.Repositories;

/// <summary>
/// Tells the model which repositories the user can work with and which one is selected in the UI (the Git pill above
/// the composer), so a request like "what is laptop tracker" is matched to the registered LaptopTracker repository
/// instead of being answered from general knowledge. Only repositories this user may access are listed; a selection
/// sent by the client is used only when it names one of them.
/// </summary>
public sealed class RepositoryContextContributor(RepositoryCatalog repositories) : IContextContributor
{
    private const int MaxListed = 40;

    public async Task<string?> GetPinnedContextAsync(ToolExecutionContext context, CancellationToken cancellationToken)
    {
        var list = await repositories.ListAsync(context.UserId, cancellationToken);
        var named = list.Where(r => !string.Equals(r.Name, RepositoryCatalog.WorkspaceName, StringComparison.OrdinalIgnoreCase)).ToList();
        var sb = new StringBuilder();
        AppendWorkingFolder(sb, context, list);
        if (named.Count == 0)
        {
            return sb.ToString().TrimEnd();
        }

        sb.AppendLine("Repositories available to the code, Git and analysis tools (use these exact names; the user may write them loosely, e.g. with spaces or different case):");
        foreach (var repo in named.Take(MaxListed))
        {
            var access = (repo.AllowCommands ? "builds/tests allowed" : "read-only analysis") + (repo.AllowWrite ? ", editable" : "");
            sb.AppendLine(CultureInfo.InvariantCulture, $"- {repo.Name} ({access})");
        }
        if (named.Count > MaxListed)
        {
            sb.AppendLine(CultureInfo.InvariantCulture, $"- … and {named.Count - MaxListed} more (use repo_list).");
        }
        sb.AppendLine("- workspace (the user's own DocGen files: uploads and generated files)");
        sb.Append("Work in the working folder above. Another repository is used only when the user names it — loosely written is fine (\"kite trading bot\" " +
                  "names KiteTradingBot), but a word that matches only part of a name (\"kite\") does not: if the request might be about another repository, " +
                  "ask. When the user does name one, inspect it with the tools before answering; do not claim it does not exist.");
        return sb.ToString();
    }

    /// <summary>
    /// States the one folder this request works in (name and absolute path), what it allows, and, when the user just
    /// switched folders, that earlier messages refer to the previous one. Without this the model guesses from history.
    /// </summary>
    private static void AppendWorkingFolder(StringBuilder sb, ToolExecutionContext context, IReadOnlyList<RepositoryHandle> list)
    {
        // Normally resolved by the orchestrator; otherwise the UI's selection counts only when this user may access it.
        var folder = context.WorkingFolder ?? list
            .Where(r => context.Repository is { Length: > 0 } requested && string.Equals(r.Name, requested, StringComparison.OrdinalIgnoreCase))
            .Select(r => new WorkingFolder(r.Name, r.Root, r.AllowWrite, r.AllowCommands, r.Source == "workspace"))
            .FirstOrDefault();
        var name = folder?.Name ?? RepositoryCatalog.WorkspaceName;
        var root = folder?.Root ?? list.FirstOrDefault(r => r.Source == "workspace")?.Root ?? context.WorkspaceRoot;
        var isWorkspace = folder?.IsWorkspace ?? true;
        sb.AppendLine(CultureInfo.InvariantCulture, $"Working folder for this request: {name} ({root}).");
        sb.AppendLine("- Tool paths are relative to it: file_list, file_read, file_search and file_write, the code tools (search_code, read_source_range, source_edit…), run_build/run_tests, powershell and Git all start here. Do not pass absolute paths.");
        // Seen in a real run: a stale user secret broke the app under test and the model deleted the machine's whole
        // user-secrets store to "fix" it. The policy now refuses such deletes; this keeps the model from trying.
        sb.AppendLine("- Stay inside the folders DocGen works in. A problem in the machine's own setup — credentials, user secrets, environment variables, global caches, another program's settings — is a blocker to report to the user (what is wrong, what would fix it, and why), never something to fix by changing or deleting files outside these folders.");
        if (isWorkspace)
        {
            sb.AppendLine("- This is the user's private DocGen workspace: uploads are in files/ (read-only), files you create go in generated/ unless you give another folder.");
        }
        else
        {
            var access = (folder!.AllowWrite ? "editable" : "read-only (file_write saves to the workspace's generated/ folder instead; source_edit is refused)")
                         + (folder.AllowCommands ? ", builds/tests/commands allowed" : ", commands not allowed");
            sb.AppendLine(CultureInfo.InvariantCulture, $"- Access: {access}. Uploaded attachments stay in the workspace under files/ and are still readable by that path.");
            // File tools send generated/ and files/ to the workspace while commands run in the working folder: without both
            // absolute paths the model searched the disk for a file it had just written.
            sb.AppendLine(CultureInfo.InvariantCulture,
                $"- Two places: the user's workspace is {context.WorkspaceRoot} — file tools read and write generated/… and files/… there — while commands (powershell, run_process, scripts) run in {root}. " +
                $"From a command, reach a workspace file by its absolute path ({Path.Combine(context.WorkspaceRoot, "generated", "…")}); never search the disk for it.");
            sb.AppendLine(CultureInfo.InvariantCulture,
                $"- This is the repository currently selected in the DocGen UI. When the user says \"the repo\", \"the project\", \"this folder\" or \"this code\" without naming one, they mean {name}.");
        }
        if (context.PreviousRepository is { Length: > 0 } previous && !string.Equals(previous, name, StringComparison.OrdinalIgnoreCase))
        {
            sb.AppendLine(CultureInfo.InvariantCulture,
                $"- The user switched the working folder from {previous} to {name} with this message. Earlier messages, paths and tool results refer to {previous}; do not assume its files exist here — look at {name} again before relying on anything from before.");
        }
        else if (context.Repository is { Length: > 0 } && folder is null)
        {
            sb.AppendLine("- The folder selected in the UI is not available to this user, so the workspace is used. Tell the user if the request depends on it.");
        }
    }
}
