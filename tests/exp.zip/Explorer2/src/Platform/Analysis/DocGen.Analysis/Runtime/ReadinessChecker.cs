using System.Net;
using System.Net.Sockets;
using System.Text.Json;
using System.Text.RegularExpressions;
using DocGen.Analysis.Git;
using DocGen.Analysis.Indexing;

namespace DocGen.Analysis.Runtime;

/// <summary>✓ ready · ⚠ warning · ✗ blocking · ? unknown (not checked, e.g. a remote service DocGen never contacts).</summary>
public sealed record ReadinessItem(string Category, string Name, string Mark, string Detail)
{
    public bool Blocking => Mark == "✗";
}

public sealed class ReadinessReport
{
    public string Project { get; set; } = "";
    public List<ReadinessItem> Items { get; } = [];
    public List<string> Urls { get; } = [];
    public bool Blocked => Items.Any(i => i.Blocking);

    public void Add(string category, string name, string mark, string detail) => Items.Add(new ReadinessItem(category, name, mark, detail));
}

/// <summary>Runtime facts gathered by the caller (installed runtimes, dev certificate) so the checker stays pure and testable.</summary>
public sealed class RuntimeFacts
{
    /// <summary>"Microsoft.NETCore.App 10.0.1", "Microsoft.AspNetCore.App 10.0.1"… (null = unknown).</summary>
    public List<string>? Runtimes { get; init; }

    /// <summary>true/false = dotnet dev-certs https --check result; null = not checked.</summary>
    public bool? DevCertificateTrusted { get; init; }

    public Func<string, bool> EnvironmentVariableSet { get; init; } = name => !string.IsNullOrEmpty(Environment.GetEnvironmentVariable(name));

    /// <summary>Loopback TCP probe: true when something accepts connections on the port.</summary>
    public Func<int, bool> PortInUse { get; init; } = ReadinessChecker.LoopbackPortInUse;
}

/// <summary>
/// Dependency readiness before running an application: runtime, ports, configuration files and keys, environment
/// variables, external services, files, certificates and databases. Only loopback endpoints are probed; remote hosts are
/// reported as "?" (never contacted); connection strings and values are never printed.
/// </summary>
public static partial class ReadinessChecker
{
    public static ReadinessReport Check(CodeIndex index, string repoRoot, ProjectInfo project, RuntimeFacts facts)
    {
        var report = new ReadinessReport { Project = project.Name };
        var projectDir = Path.Combine(repoRoot, project.Directory);

        // Runtime.
        foreach (var tfm in project.TargetFrameworks.DefaultIfEmpty(""))
        {
            var m = TfmVersion().Match(tfm);
            if (!m.Success)
            {
                report.Add("runtime", tfm.Length == 0 ? "target framework" : tfm, "?", "target framework not determined");
                continue;
            }
            var version = m.Groups[1].Value;
            var web = project.Sdk?.Contains("Web", StringComparison.OrdinalIgnoreCase) == true || project.FrameworkReferences.Contains("Microsoft.AspNetCore.App");
            var needed = web ? "Microsoft.AspNetCore.App" : "Microsoft.NETCore.App";
            if (facts.Runtimes is null)
            {
                report.Add("runtime", $"{needed} {version}", "?", "installed runtimes unknown (dotnet --list-runtimes not run)");
            }
            else
            {
                var found = facts.Runtimes.Where(r => r.StartsWith(needed + " " + version + ".", StringComparison.Ordinal)).ToList();
                report.Add("runtime", $"{needed} {version}", found.Count > 0 ? "✓" : "✗", found.Count > 0 ? string.Join(", ", found.Select(f => f.Split(' ')[1]).Take(3)) : $"no {needed} {version}.x runtime installed");
            }
        }

        // Ports and certificates from launchSettings.json.
        var launch = Path.Combine(projectDir, "Properties", "launchSettings.json");
        var https = false;
        if (File.Exists(launch))
        {
            try
            {
                using var doc = JsonDocument.Parse(File.ReadAllText(launch), new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
                if (doc.RootElement.TryGetProperty("profiles", out var profiles))
                {
                    foreach (var profile in profiles.EnumerateObject())
                    {
                        if (profile.Value.TryGetProperty("applicationUrl", out var urls) && urls.ValueKind == JsonValueKind.String)
                        {
                            foreach (var url in urls.GetString()!.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
                            {
                                if (!Uri.TryCreate(url.Replace("*", "localhost", StringComparison.Ordinal).Replace("+", "localhost", StringComparison.Ordinal), UriKind.Absolute, out var uri) || report.Urls.Contains(url))
                                {
                                    continue;
                                }
                                report.Urls.Add(url);
                                https |= uri.Scheme == "https";
                                var inUse = facts.PortInUse(uri.Port);
                                report.Add("port", $"{uri.Port} ({profile.Name})", inUse ? "⚠" : "✓", inUse ? "already in use by another process — the app would fail to bind; DocGen starts dev servers on a free port instead" : "free");
                            }
                        }
                    }
                }
            }
            catch (JsonException ex)
            {
                report.Add("config", "Properties/launchSettings.json", "✗", "invalid JSON: " + ex.Message);
            }
        }
        if (https)
        {
            report.Add("certificate", "ASP.NET Core HTTPS development certificate", facts.DevCertificateTrusted switch { true => "✓", false => "⚠", null => "?" },
                facts.DevCertificateTrusted switch { true => "present and trusted", false => "missing or untrusted (run: dotnet dev-certs https --trust)", null => "not checked" });
        }

        // Configuration files.
        var settingsFiles = Directory.Exists(projectDir) ? Directory.EnumerateFiles(projectDir, "appsettings*.json").OrderBy(f => f, StringComparer.OrdinalIgnoreCase).ToList() : [];
        var config = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var file in settingsFiles)
        {
            var name = Path.GetFileName(file);
            try
            {
                foreach (var (k, v) in SemanticDiff.Flatten(File.ReadAllText(file)))
                {
                    config[k] = v;
                }
                using var _ = JsonDocument.Parse(File.ReadAllText(file), new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true });
                report.Add("config", name, "✓", "valid JSON");
            }
            catch (JsonException ex)
            {
                report.Add("config", name, "✗", "invalid JSON: " + ex.Message);
            }
        }
        if (settingsFiles.Count == 0 && (project.Sdk?.Contains("Web", StringComparison.OrdinalIgnoreCase) ?? false))
        {
            report.Add("config", "appsettings.json", "⚠", "no appsettings*.json in the project folder");
        }
        bool Defined(string key) => config.Keys.Any(k => k.Equals(key, StringComparison.OrdinalIgnoreCase) || k.StartsWith(key + ":", StringComparison.OrdinalIgnoreCase));
        var projectFiles = index.Files.Where(f => f.Value.Project == project.Name).Select(f => f.Key).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var missing = index.ConfigReferences.Where(c => projectFiles.Contains(c.File) && c.Kind is "value" or "connectionString" or "indexer" && c.Key.Length > 0 && !Defined(c.Key)
                                                        && !(c.Kind == "connectionString" && Defined("ConnectionStrings:" + c.Key)))
            .Select(c => c.Kind == "connectionString" ? "ConnectionStrings:" + c.Key : c.Key).Distinct(StringComparer.OrdinalIgnoreCase).Take(20).ToList();
        foreach (var key in missing)
        {
            var envName = key.Replace(":", "__", StringComparison.Ordinal);
            report.Add("config", key, facts.EnvironmentVariableSet(envName) ? "✓" : "⚠", facts.EnvironmentVariableSet(envName) ? $"provided by environment variable {envName}" : "read by code but not defined in appsettings (or as an environment variable)");
        }

        // Environment variables read directly by the code (names only).
        foreach (var name in EnvironmentVariablesUsed(repoRoot, projectFiles).Take(20))
        {
            report.Add("environment", name, facts.EnvironmentVariableSet(name) ? "✓" : "⚠", facts.EnvironmentVariableSet(name) ? "set" : "not set in DocGen's environment");
        }

        // Databases and external services (values are never printed).
        foreach (var (key, value) in config.Where(p => p.Key.StartsWith("ConnectionStrings:", StringComparison.OrdinalIgnoreCase)))
        {
            report.Items.Add(Database(key, value, repoRoot, projectDir, facts));
        }
        foreach (var (key, value) in config.Where(p => !p.Key.StartsWith("ConnectionStrings:", StringComparison.OrdinalIgnoreCase)))
        {
            if (Uri.TryCreate(value, UriKind.Absolute, out var uri) && uri.Scheme is "http" or "https" or "amqp" or "redis" or "mongodb" or "rediss")
            {
                var loopback = uri.IsLoopback || uri.Host is "localhost" or "127.0.0.1" or "::1";
                report.Add("service", key, loopback ? facts.PortInUse(uri.Port) ? "✓" : "✗" : "?",
                    loopback ? facts.PortInUse(uri.Port) ? $"loopback {uri.Scheme} service answering on port {uri.Port}" : $"nothing listening on loopback port {uri.Port}"
                             : $"remote {uri.Scheme} host (not contacted by DocGen)");
            }
            else if (FileKey().IsMatch(key) && value.Length is > 0 and < 260 && !value.Contains("://", StringComparison.Ordinal) && value.IndexOfAny(Path.GetInvalidPathChars()) < 0)
            {
                var full = Path.IsPathRooted(value) ? value : Path.Combine(projectDir, value);
                var exists = File.Exists(full) || Directory.Exists(full);
                report.Add("file", key, exists ? "✓" : "⚠", exists ? "exists" : "configured path does not exist (it may be created at runtime)");
            }
            if (key.Contains("Certificate", StringComparison.OrdinalIgnoreCase) && key.EndsWith(":Path", StringComparison.OrdinalIgnoreCase))
            {
                var full = Path.IsPathRooted(value) ? value : Path.Combine(projectDir, value);
                report.Add("certificate", key, File.Exists(full) ? "✓" : "✗", File.Exists(full) ? "certificate file exists" : "certificate file missing");
            }
        }
        return report;
    }

    private static ReadinessItem Database(string key, string value, string repoRoot, string projectDir, RuntimeFacts facts)
    {
        var parts = value.Split(';', StringSplitOptions.RemoveEmptyEntries)
            .Select(p => p.Split('=', 2)).Where(p => p.Length == 2)
            .ToDictionary(p => p[0].Trim(), p => p[1].Trim(), StringComparer.OrdinalIgnoreCase);
        var source = parts.GetValueOrDefault("Server") ?? parts.GetValueOrDefault("Host") ?? parts.GetValueOrDefault("Data Source") ?? parts.GetValueOrDefault("Address") ?? "";
        if (source.Length == 0)
        {
            return new ReadinessItem("database", key, "?", "connection target not recognised");
        }
        if (source.Contains("(localdb)", StringComparison.OrdinalIgnoreCase))
        {
            return new ReadinessItem("database", key, "?", "SQL Server LocalDB (instance state not checked)");
        }
        if (source.EndsWith(".db", StringComparison.OrdinalIgnoreCase) || source.EndsWith(".sqlite", StringComparison.OrdinalIgnoreCase) || source.EndsWith(".sqlite3", StringComparison.OrdinalIgnoreCase))
        {
            var full = Path.IsPathRooted(source) ? source : Path.Combine(projectDir, source);
            return new ReadinessItem("database", key, File.Exists(full) ? "✓" : "⚠", File.Exists(full) ? "SQLite file exists" : "SQLite file does not exist yet (created on first use or by migrations)");
        }
        var host = source.Replace("tcp:", "", StringComparison.OrdinalIgnoreCase);
        var port = parts.TryGetValue("Port", out var p) && int.TryParse(p, out var pp) ? pp : 0;
        if (host.Contains(',', StringComparison.Ordinal))
        {
            port = int.TryParse(host[(host.IndexOf(',') + 1)..], out var sp) ? sp : port;
            host = host[..host.IndexOf(',')];
        }
        else if (host.Count(c => c == ':') == 1)
        {
            port = int.TryParse(host[(host.IndexOf(':') + 1)..], out var hp) ? hp : port;
            host = host[..host.IndexOf(':')];
        }
        host = host.Split('\\')[0];
        if (port == 0)
        {
            port = parts.ContainsKey("Host") ? 5432 : 1433;
        }
        var loopback = host is "." or "localhost" or "127.0.0.1" or "::1" or "(local)";
        if (!loopback)
        {
            return new ReadinessItem("database", key, "?", "remote database host (not contacted by DocGen)");
        }
        return facts.PortInUse(port)
            ? new ReadinessItem("database", key, "✓", $"local database port {port} accepts connections")
            : new ReadinessItem("database", key, "✗", $"nothing listening on local database port {port}");
    }

    private static IEnumerable<string> EnvironmentVariablesUsed(string repoRoot, IEnumerable<string> files)
    {
        var names = new SortedSet<string>(StringComparer.Ordinal);
        foreach (var file in files.Where(f => f.EndsWith(".cs", StringComparison.OrdinalIgnoreCase)).Take(2000))
        {
            var full = Path.Combine(repoRoot, file);
            if (!File.Exists(full) || new FileInfo(full).Length > 1024 * 1024)
            {
                continue;
            }
            foreach (Match m in EnvironmentRead().Matches(File.ReadAllText(full)))
            {
                names.Add(m.Groups[1].Value);
            }
        }
        return names.Where(n => n is not ("ASPNETCORE_ENVIRONMENT" or "DOTNET_ENVIRONMENT"));
    }

    public static bool LoopbackPortInUse(int port)
    {
        if (port is <= 0 or > 65535)
        {
            return false;
        }
        try
        {
            using var client = new TcpClient();
            var task = client.ConnectAsync(IPAddress.Loopback, port);
            return task.Wait(TimeSpan.FromMilliseconds(400)) && client.Connected;
        }
        catch (Exception ex) when (ex is SocketException or AggregateException)
        {
            return false;
        }
    }

    [GeneratedRegex(@"net(?:coreapp)?(\d+\.\d+)")]
    private static partial Regex TfmVersion();

    [GeneratedRegex(@"GetEnvironmentVariable\(\s*""([A-Za-z_][A-Za-z0-9_]*)""")]
    private static partial Regex EnvironmentRead();

    [GeneratedRegex(@"(Path|File|Directory|Folder)$", RegexOptions.IgnoreCase)]
    private static partial Regex FileKey();
}
