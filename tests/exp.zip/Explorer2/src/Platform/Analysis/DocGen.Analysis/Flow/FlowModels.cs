using System.Text;
using DocGen.Analysis.CSharp;
using DocGen.Analysis.Indexing;

namespace DocGen.Analysis.Flow;

/// <summary>A source expression as a token span (never compiled; used for conservative, name-based data flow).</summary>
public sealed class Expr
{
    public Expr(List<Token> tokens, int line)
    {
        Tokens = tokens;
        Line = line;
    }

    public List<Token> Tokens { get; }
    public int Line { get; }

    public string Text => Render(Tokens);

    public bool IsEmpty => Tokens.Count == 0;

    public static string Render(IReadOnlyList<Token> tokens, int max = 240)
    {
        var sb = new StringBuilder();
        Token? previous = null;
        foreach (var t in tokens)
        {
            if (previous is { } p && Space(p, t))
            {
                sb.Append(' ');
            }
            sb.Append(t.Kind == TokenKind.String ? "\"" + (t.Text.Length > 40 ? t.Text[..40] + "…" : t.Text) + "\"" : t.Text);
            previous = t;
            if (sb.Length > max)
            {
                sb.Append('…');
                break;
            }
        }
        return sb.ToString();
    }

    private static bool Space(Token a, Token b)
    {
        if (b.Kind == TokenKind.Punct && b.Text is "." or "?." or "(" or ")" or "[" or "]" or "," or ";" or "!" && !(b.Text == "(" && a.Kind == TokenKind.Keyword && a.Text is "if" or "while" or "switch" or "catch" or "lock" or "foreach" or "for"))
        {
            return b.Text == "!" && a.Kind != TokenKind.Identifier && a.Text is not (")" or "]");
        }
        if (a.Kind == TokenKind.Punct && a.Text is "." or "?." or "(" or "[" or "!")
        {
            return a.Text == "!" && b.Kind != TokenKind.Punct;
        }
        if (b.Text is "<" or ">" && b.Kind == TokenKind.Punct && a.Kind == TokenKind.Identifier)
        {
            return false;
        }
        if (a.Text is "<" && a.Kind == TokenKind.Punct)
        {
            return false;
        }
        return true;
    }
}

public sealed class FlowParameter(string type, string name)
{
    public string Type { get; } = type;
    public string Name { get; } = name;
    public bool IsOut { get; init; }
}

public sealed class FlowLocal
{
    public string Name { get; init; } = "";
    public string? Type { get; init; }
    public Expr? Init { get; init; }

    /// <summary>foreach variable: the value is an element of <see cref="Init"/>.</summary>
    public bool ElementOf { get; init; }

    /// <summary>Declared as an out argument of a call (the value comes from inside that call).</summary>
    public bool OutArgument { get; init; }

    public int Line { get; init; }
}

public static class AssignmentKinds
{
    public const string Assign = "assign";
    public const string Compound = "compound";
    public const string Initializer = "initializer";
    public const string Increment = "increment";
    public const string FieldInit = "fieldInit";
}

public sealed class FlowAssignment
{
    /// <summary>Rendered target ("member.Address", "_count", "Title").</summary>
    public string Target { get; init; } = "";

    public List<Token> TargetTokens { get; init; } = [];
    public Expr Source { get; init; } = new([], 0);
    public string Kind { get; init; } = AssignmentKinds.Assign;

    /// <summary>For object initializers: the type being constructed (null when target-typed or unknown).</summary>
    public string? InitializerType { get; init; }

    public int Line { get; init; }

    /// <summary>Root identifier of the target (e.g. "member" for member.Address, "_count").</summary>
    public string TargetRoot => TargetTokens.FirstOrDefault(t => t.Kind == TokenKind.Identifier || t.Is("this")).Text ?? Target;

    /// <summary>Last member name of the target ("Address" for member.Address).</summary>
    public string TargetMember => TargetTokens.LastOrDefault(t => t.Kind == TokenKind.Identifier).Text ?? Target;
}

public sealed class FlowCall
{
    public string Callee { get; init; } = "";

    /// <summary>Receiver expression tokens before ".Callee" (empty for unqualified calls).</summary>
    public List<Token> Receiver { get; init; } = [];

    public List<Expr> Args { get; init; } = [];
    public List<string?> ArgNames { get; init; } = [];
    public List<bool> ArgIsOut { get; init; } = [];
    public List<string> TypeArgs { get; init; } = [];
    public bool IsConstructor { get; init; }
    public string? ConstructedType { get; init; }
    public int Line { get; init; }

    /// <summary>The whole invocation expression (receiver + call).</summary>
    public Expr Whole { get; init; } = new([], 0);

    public string ReceiverText => Expr.Render(Receiver);
}

public sealed class FlowCatch
{
    public string? ExceptionType { get; init; }
    public string? Variable { get; init; }
    public string? WrapType { get; set; }
    public bool PassesInner { get; set; }
    public bool Rethrows { get; set; }
    public int Line { get; init; }
}

public sealed class FlowThrow
{
    public string Type { get; init; } = "";
    public Expr Arguments { get; init; } = new([], 0);
    public int Line { get; init; }
}

public sealed class FlowCondition
{
    public Expr Condition { get; init; } = new([], 0);
    public int Line { get; init; }
}

/// <summary>Flow facts of one member, extracted on demand from its source.</summary>
public sealed class MemberFlow
{
    public required SymbolRecord Symbol { get; init; }
    public List<FlowParameter> Parameters { get; } = [];
    public List<FlowLocal> Locals { get; } = [];
    public List<FlowAssignment> Assignments { get; } = [];
    public List<Expr> Returns { get; } = [];
    public List<FlowCall> Calls { get; } = [];
    public List<int> AwaitLines { get; } = [];
    public List<int> LockLines { get; } = [];

    /// <summary>Synchronisation primitives used (lock, SemaphoreSlim.Wait*, Interlocked.*, Monitor.*).</summary>
    public HashSet<string> Synchronization { get; } = new(StringComparer.Ordinal);

    public List<FlowCatch> Catches { get; } = [];
    public List<FlowThrow> Throws { get; } = [];
    public List<FlowCondition> Conditions { get; } = [];
    public List<Token> Body { get; } = [];

    /// <summary>For properties: [JsonPropertyName("x")] and similar attribute string arguments.</summary>
    public Dictionary<string, string> AttributeArguments { get; } = new(StringComparer.Ordinal);

    public int SourceLines => Math.Max(1, Symbol.EndLine - Symbol.StartLine + 1);

    public FlowParameter? Parameter(string name) => Parameters.FirstOrDefault(p => p.Name == name);

    public IEnumerable<FlowLocal> LocalsNamed(string name) => Locals.Where(l => l.Name == name);
}

public sealed class TypeFlow
{
    public required SymbolRecord Symbol { get; init; }

    /// <summary>Primary constructor parameters (records and C# 12 classes).</summary>
    public List<FlowParameter> PrimaryParameters { get; } = [];

    /// <summary>Base types with their generic arguments as written ("JsonConverter" → "decimal").</summary>
    public Dictionary<string, string> BaseTypeArguments { get; } = new(StringComparer.Ordinal);
}

public sealed class FileFlow
{
    public required string Path { get; init; }
    public required string[] Lines { get; init; }
    public Dictionary<SymbolRecord, MemberFlow> Members { get; } = new(ReferenceEqualityComparer.Instance);
    public Dictionary<SymbolRecord, TypeFlow> Types { get; } = new(ReferenceEqualityComparer.Instance);
}
