using DocGen.Analysis.CSharp;
using DocGen.Analysis.Indexing;

namespace DocGen.Analysis.Flow;

/// <summary>
/// Extracts conservative data-flow facts from C# source for the members of one file: parameters, locals (with
/// initializers), assignments (including object initializers and compound/increment updates), return expressions,
/// call sites with their arguments, awaits, locks and other synchronisation, catch/wrap and throw sites, and
/// conditions. It works on tokens and the index's member ranges; it does not compile or bind. Malformed code never
/// throws: unrecognised constructs are skipped.
/// </summary>
public static class FlowParser
{
    private static readonly HashSet<string> NotCallees = new(StringComparer.Ordinal)
    {
        "nameof", "typeof", "sizeof", "default", "if", "while", "for", "foreach", "switch", "catch", "lock", "using", "return", "when", "checked", "unchecked",
    };

    private static readonly HashSet<string> Modifiers = new(StringComparer.Ordinal) { "this", "ref", "out", "in", "params", "scoped", "readonly" };

    public static FileFlow Parse(string path, string text, IReadOnlyList<SymbolRecord> symbols)
    {
        var tokens = CSharpLexer.Tokenize(text);
        var flow = new FileFlow { Path = path, Lines = text.Split('\n') };
        foreach (var symbol in symbols)
        {
            try
            {
                var span = tokens.Where(t => t.Line >= symbol.StartLine && t.Line <= symbol.EndLine).ToList();
                if (SymbolKinds.IsType(symbol.Kind))
                {
                    flow.Types[symbol] = ParseType(symbol, span);
                }
                else if (symbol.Kind != SymbolKinds.EnumMember)
                {
                    flow.Members[symbol] = ParseMember(symbol, span, symbols);
                }
            }
            catch (Exception ex) when (ex is ArgumentOutOfRangeException or IndexOutOfRangeException or InvalidOperationException)
            {
                // Defensive: never let one odd member break analysis of the rest.
            }
        }
        return flow;
    }

    private static TypeFlow ParseType(SymbolRecord type, List<Token> span)
    {
        var flow = new TypeFlow { Symbol = type };
        var keyword = span.FindIndex(t => t.Text is "class" or "record" or "struct" or "interface");
        if (keyword < 0)
        {
            return flow;
        }
        var nameIndex = span.FindIndex(keyword, t => t.Kind == TokenKind.Identifier && t.Text == type.Name);
        if (nameIndex < 0)
        {
            return flow;
        }
        var k = nameIndex + 1;
        if (k < span.Count && span[k].IsPunct('<'))
        {
            k = Match(span, k, '<', '>') + 1;
        }
        if (k < span.Count && span[k].IsPunct('('))
        {
            var close = Match(span, k, '(', ')');
            flow.PrimaryParameters.AddRange(ParseParameters(span, k, close));
            k = close + 1;
        }
        if (k < span.Count && span[k].IsPunct(':'))
        {
            // Base list with generic arguments: ": JsonConverter<decimal>, IFoo"
            for (var i = k + 1; i < span.Count && !span[i].IsPunct('{') && !span[i].Is("where") && !span[i].IsPunct(';'); i++)
            {
                if (span[i].Kind == TokenKind.Identifier && i + 1 < span.Count && span[i + 1].IsPunct('<'))
                {
                    var close = Match(span, i + 1, '<', '>');
                    flow.BaseTypeArguments[span[i].Text] = Expr.Render(span.GetRange(i + 2, Math.Max(0, close - i - 2)));
                    i = close;
                }
            }
        }
        return flow;
    }

    private static MemberFlow ParseMember(SymbolRecord member, List<Token> span, IReadOnlyList<SymbolRecord> symbols)
    {
        var flow = new MemberFlow { Symbol = member };
        CollectAttributes(span, flow);
        if (member.Kind == SymbolKinds.TopLevel)
        {
            Scan(span, 0, span.Count, flow, initialInitType: null);
            return flow;
        }

        var name = member.Kind == SymbolKinds.Constructor ? member.Name : member.Name;
        var nameIndex = FindName(span, member);
        if (nameIndex < 0)
        {
            return flow;
        }

        int bodyStart;
        if (member.Kind is SymbolKinds.Method or SymbolKinds.Constructor)
        {
            var k = nameIndex + 1;
            if (k < span.Count && span[k].IsPunct('<'))
            {
                k = Match(span, k, '<', '>') + 1;
            }
            if (k >= span.Count || !span[k].IsPunct('('))
            {
                return flow;
            }
            var close = Match(span, k, '(', ')');
            flow.Parameters.AddRange(ParseParameters(span, k, close));
            bodyStart = close + 1;
            // Constructor initializer ": base(...)" / ": this(...)" and generic constraints are part of the header.
            while (bodyStart < span.Count && !span[bodyStart].IsPunct('{') && !span[bodyStart].Is("=>") && !span[bodyStart].IsPunct(';'))
            {
                bodyStart++;
            }
        }
        else if (member.Kind == SymbolKinds.Indexer)
        {
            var open = span.FindIndex(nameIndex, t => t.IsPunct('['));
            if (open >= 0)
            {
                var close = Match(span, open, '[', ']');
                flow.Parameters.AddRange(ParseParameters(span, open, close));
                bodyStart = close + 1;
            }
            else
            {
                bodyStart = nameIndex + 1;
            }
        }
        else
        {
            bodyStart = nameIndex + 1;
        }

        if (bodyStart >= span.Count)
        {
            return flow;
        }

        if (member.Kind == SymbolKinds.Field)
        {
            // "T a = expr, b = expr;" — only the initializer of this field.
            var eq = bodyStart < span.Count && span[bodyStart].IsPunct('=') ? bodyStart : -1;
            if (eq > 0)
            {
                var end = ExpressionEnd(span, eq + 1, stopAtComma: true, span.Count);
                flow.Assignments.Add(new FlowAssignment
                {
                    Target = member.Name, TargetTokens = [span[nameIndex]], Source = Sub(span, eq + 1, end), Kind = AssignmentKinds.FieldInit, Line = span[eq].Line,
                });
                Scan(span, eq + 1, end, flow, null);
            }
            return flow;
        }

        if (span[bodyStart].Is("=>"))
        {
            var end = ExpressionEnd(span, bodyStart + 1, stopAtComma: false, span.Count);
            flow.Returns.Add(Sub(span, bodyStart + 1, end));
            flow.Body.AddRange(span.GetRange(bodyStart + 1, Math.Max(0, end - bodyStart - 1)));
            Scan(span, bodyStart + 1, end, flow, null);
            return flow;
        }

        if (span[bodyStart].IsPunct('{'))
        {
            var close = Match(span, bodyStart, '{', '}');
            flow.Body.AddRange(span.GetRange(bodyStart + 1, Math.Max(0, close - bodyStart - 1)));
            if (member.Kind is SymbolKinds.Property or SymbolKinds.Indexer or SymbolKinds.Event)
            {
                ScanAccessors(span, bodyStart, close, flow);
                // Auto-property initializer: "{ get; } = expr;"
                if (close + 1 < span.Count && span[close + 1].IsPunct('='))
                {
                    var end = ExpressionEnd(span, close + 2, stopAtComma: false, span.Count);
                    flow.Assignments.Add(new FlowAssignment
                    {
                        Target = member.Name, TargetTokens = [span[nameIndex]], Source = Sub(span, close + 2, end), Kind = AssignmentKinds.FieldInit, Line = span[close + 1].Line,
                    });
                    Scan(span, close + 2, end, flow, null);
                }
            }
            else
            {
                Scan(span, bodyStart + 1, close, flow, null);
            }
        }
        return flow;
    }

    private static int FindName(List<Token> span, SymbolRecord member)
    {
        var target = member.Kind == SymbolKinds.Indexer ? "this" : member.Name.StartsWith('~') ? member.Name[1..] : member.Name.StartsWith("operator", StringComparison.Ordinal) ? "operator" : member.Name;
        for (var i = 0; i < span.Count; i++)
        {
            if (span[i].Text != target)
            {
                continue;
            }
            // Skip attribute contents.
            if (i + 1 < span.Count && (member.Kind is SymbolKinds.Method or SymbolKinds.Constructor ? span[i + 1].IsPunct('(') || span[i + 1].IsPunct('<')
                                        : member.Kind == SymbolKinds.Indexer ? span[i + 1].IsPunct('[') : true))
            {
                return i;
            }
        }
        return -1;
    }

    private static void CollectAttributes(List<Token> span, MemberFlow flow)
    {
        for (var i = 0; i + 3 < span.Count && span[i].Line <= flow.Symbol.StartLine + 3; i++)
        {
            if (span[i].IsPunct('[') && span[i + 1].Kind == TokenKind.Identifier && span[i + 2].IsPunct('(') && span[i + 3].Kind == TokenKind.String)
            {
                flow.AttributeArguments[span[i + 1].Text] = span[i + 3].Text;
            }
        }
    }

    private static void ScanAccessors(List<Token> span, int open, int close, MemberFlow flow)
    {
        // get => expr;  get { return expr; }  set { _x = value; }
        for (var i = open + 1; i < close; i++)
        {
            if (span[i].Is("get") && i + 1 < close && span[i + 1].Is("=>"))
            {
                var end = ExpressionEnd(span, i + 2, stopAtComma: false, close);
                flow.Returns.Add(Sub(span, i + 2, end));
                Scan(span, i + 2, end, flow, null);
                i = end;
            }
            else if (span[i].IsPunct('{'))
            {
                var c = Match(span, i, '{', '}');
                Scan(span, i + 1, c, flow, null);
                i = c;
            }
            else if (span[i].Is("set") || span[i].Is("init"))
            {
                if (i + 1 < close && span[i + 1].Is("=>"))
                {
                    var end = ExpressionEnd(span, i + 2, stopAtComma: false, close);
                    Scan(span, i + 2, end, flow, null);
                    i = end;
                }
            }
        }
    }

    internal static List<FlowParameter> ParseParameters(List<Token> span, int open, int close)
    {
        var list = new List<FlowParameter>();
        var segment = new List<Token>();
        var depth = 0;
        for (var i = open + 1; i <= close && i < span.Count; i++)
        {
            var t = span[i];
            if (i == close || depth == 0 && t.IsPunct(','))
            {
                if (ParameterFrom(segment) is { } p)
                {
                    list.Add(p);
                }
                segment.Clear();
                continue;
            }
            if (t.IsPunct('<') || t.IsPunct('(') || t.IsPunct('[') || t.IsPunct('{'))
            {
                depth++;
            }
            else if (t.IsPunct('>') || t.IsPunct(')') || t.IsPunct(']') || t.IsPunct('}'))
            {
                depth--;
            }
            segment.Add(t);
        }
        return list;
    }

    private static FlowParameter? ParameterFrom(List<Token> segment)
    {
        var s = segment.ToList();
        while (s.Count > 0 && s[0].IsPunct('['))
        {
            var c = Match(s, 0, '[', ']');
            s = s.Skip(c + 1).ToList();
        }
        var eq = s.FindIndex(t => t.IsPunct('='));
        if (eq >= 0)
        {
            s = s.Take(eq).ToList();
        }
        var isOut = s.Any(t => t.Text == "out");
        s = s.Where(t => !Modifiers.Contains(t.Text)).ToList();
        if (s.Count < 2 || s[^1].Kind != TokenKind.Identifier)
        {
            return null;
        }
        return new FlowParameter(Expr.Render(s.Take(s.Count - 1).ToList()), s[^1].Text) { IsOut = isOut };
    }

    /// <summary>Walks tokens [start, end) recording flow facts. Braces are tracked to recognise object initializers.</summary>
    private static void Scan(List<Token> t, int start, int end, MemberFlow flow, string? initialInitType)
    {
        var contexts = new Stack<(bool Init, string? Type, int Open)>();
        for (var i = start; i < end && i < t.Count; i++)
        {
            var tok = t[i];
            if (tok.IsPunct('{'))
            {
                var (isInit, type) = InitializerContext(t, i, start);
                contexts.Push((isInit, type, i));
                continue;
            }
            if (tok.IsPunct('}'))
            {
                if (contexts.Count > 0)
                {
                    contexts.Pop();
                }
                continue;
            }
            if (tok.Is("await"))
            {
                flow.AwaitLines.Add(tok.Line);
                continue;
            }
            if (tok.Is("lock") && i + 1 < end && t[i + 1].IsPunct('('))
            {
                flow.LockLines.Add(tok.Line);
                flow.Synchronization.Add("lock");
                continue;
            }
            if (tok.Is("return"))
            {
                var e = ExpressionEnd(t, i + 1, stopAtComma: false, end);
                if (e > i + 1)
                {
                    flow.Returns.Add(Sub(t, i + 1, e));
                }
                continue;
            }
            if (tok.Is("throw"))
            {
                if (i + 2 < end && t[i + 1].Is("new") && t[i + 2].Kind == TokenKind.Identifier)
                {
                    var open = i + 3 < end && t[i + 3].IsPunct('(') ? i + 3 : -1;
                    var close = open > 0 ? Match(t, open, '(', ')') : i + 2;
                    flow.Throws.Add(new FlowThrow { Type = t[i + 2].Text, Arguments = open > 0 ? Sub(t, open + 1, close) : new Expr([], tok.Line), Line = tok.Line });
                }
                continue;
            }
            if (tok.Is("catch"))
            {
                ParseCatch(t, i, end, flow);
                continue;
            }
            if ((tok.Is("if") || tok.Is("while")) && i + 1 < end && t[i + 1].IsPunct('('))
            {
                var close = Match(t, i + 1, '(', ')');
                flow.Conditions.Add(new FlowCondition { Condition = Sub(t, i + 2, close), Line = tok.Line });
                continue;
            }
            if (tok.Is("foreach") && i + 1 < end && t[i + 1].IsPunct('('))
            {
                var close = Match(t, i + 1, '(', ')');
                var inIndex = FindDepthZero(t, i + 2, close, "in");
                if (inIndex > 0 && t[inIndex - 1].Kind == TokenKind.Identifier)
                {
                    var typeTokens = t.GetRange(i + 2, Math.Max(0, inIndex - i - 3));
                    flow.Locals.Add(new FlowLocal
                    {
                        Name = t[inIndex - 1].Text,
                        Type = typeTokens.Count == 1 && typeTokens[0].Text == "var" ? null : Expr.Render(typeTokens),
                        Init = Sub(t, inIndex + 1, close),
                        ElementOf = true,
                        Line = tok.Line,
                    });
                }
                continue;
            }
            if (tok.Kind == TokenKind.Identifier && tok.Text is "WaitAsync" or "Wait" or "Enter" or "TryEnter" && i > 0 && t[i - 1].IsPunct('.'))
            {
                flow.Synchronization.Add(tok.Text);
            }
            if (tok.Kind == TokenKind.Identifier && tok.Text is "Interlocked" or "Monitor" or "Volatile" && i + 1 < end && t[i + 1].IsPunct('.'))
            {
                flow.Synchronization.Add(tok.Text);
            }

            // ++ / -- on a target: x++, ++x
            if (tok.IsPunct('+') || tok.IsPunct('-'))
            {
                if (i + 1 < end && t[i + 1].Text == tok.Text)
                {
                    var targetIndex = i > start && t[i - 1].Kind == TokenKind.Identifier ? i - 1 : i + 2 < end && t[i + 2].Kind == TokenKind.Identifier ? i + 2 : -1;
                    if (targetIndex >= 0)
                    {
                        var target = TargetBackward(t, targetIndex + 1, start);
                        flow.Assignments.Add(new FlowAssignment { Target = Expr.Render(target), TargetTokens = target, Source = new Expr(target, tok.Line), Kind = AssignmentKinds.Increment, Line = tok.Line });
                    }
                    i++;
                    continue;
                }
            }

            if (tok.IsPunct('=') && IsAssignment(t, i, end))
            {
                RecordAssignment(t, i, start, end, flow, contexts.Count > 0 && contexts.Peek().Init ? contexts.Peek().Type ?? "?" : null);
                continue;
            }

            if (tok.Kind == TokenKind.Identifier && !NotCallees.Contains(tok.Text))
            {
                var callOpen = CallOpen(t, i, end);
                if (callOpen > 0)
                {
                    RecordCall(t, i, callOpen, start, end, flow);
                }
                else if (i > start && t[i - 1].Is("new") && i + 1 < end && (t[i + 1].IsPunct('{') || t[i + 1].IsPunct('<')))
                {
                    // "new T { ... }" without an argument list.
                    var whole = ExpressionEnd(t, i - 1, stopAtComma: true, end);
                    flow.Calls.Add(new FlowCall
                    {
                        Callee = tok.Text, IsConstructor = true, ConstructedType = tok.Text, Line = tok.Line, Whole = Sub(t, i - 1, whole),
                    });
                }
            }
            else if (tok.Is("new") && i + 1 < end && t[i + 1].IsPunct('('))
            {
                // Target-typed "new(...)".
                var close = Match(t, i + 1, '(', ')');
                var (args, names, outs) = SplitArguments(t, i + 1, close);
                var wholeEnd = close + 1 < end && t[close + 1].IsPunct('{') ? Match(t, close + 1, '{', '}') + 1 : close + 1;
                flow.Calls.Add(new FlowCall { Callee = "new()", IsConstructor = true, Args = args, ArgNames = names, ArgIsOut = outs, Line = tok.Line, Whole = Sub(t, i, wholeEnd) });
            }
        }
    }

    private static (bool Init, string? Type) InitializerContext(List<Token> t, int brace, int start)
    {
        var j = brace - 1;
        if (j < start)
        {
            return (false, null);
        }
        if (t[j].Is("with"))
        {
            return (true, "with");
        }
        if (t[j].IsPunct(')'))
        {
            var open = MatchBack(t, j, '(', ')');
            j = open - 1;
            if (j >= start && t[j].Is("new"))
            {
                return (true, null); // new() { ... }
            }
        }
        if (j >= start && t[j].IsPunct('>'))
        {
            j = MatchBack(t, j, '<', '>') - 1;
        }
        if (j >= start && t[j].IsPunct(']'))
        {
            j = MatchBack(t, j, '[', ']') - 1;
        }
        if (j - 1 >= start && t[j].Kind == TokenKind.Identifier)
        {
            var k = j;
            while (k - 2 >= start && t[k - 1].IsPunct('.') && t[k - 2].Kind == TokenKind.Identifier)
            {
                k -= 2;
            }
            if (k - 1 >= start && t[k - 1].Is("new"))
            {
                return (true, t[j].Text);
            }
        }
        if (j >= start && t[j].Is("new"))
        {
            return (true, null);
        }
        if (j >= start && t[j].IsPunct('='))
        {
            return (true, "collection");
        }
        return (false, null);
    }

    private static bool IsAssignment(List<Token> t, int i, int end)
    {
        if (i + 1 < end && (t[i + 1].IsPunct('=') || t[i + 1].IsPunct('>')))
        {
            return false; // == or => (=> is lexed as one token, but be safe)
        }
        if (i > 0 && t[i - 1].Kind == TokenKind.Punct && t[i - 1].Text is "=" or "!" or "<" or ">")
        {
            // <= >= != == — but "a >>= b"/"a <<= b" are rare; treat as comparison.
            return false;
        }
        return true;
    }

    private static void RecordAssignment(List<Token> t, int eq, int start, int end, MemberFlow flow, string? initType)
    {
        var compound = eq > start && t[eq - 1].Kind == TokenKind.Punct && t[eq - 1].Text is "+" or "-" or "*" or "/" or "%" or "&" or "|" or "^" or "?";
        var targetEnd = compound ? eq - 1 : eq;
        if (compound && t[eq - 1].IsPunct('?') && eq - 2 >= start && t[eq - 2].IsPunct('?'))
        {
            targetEnd = eq - 2; // ??=
        }
        var target = TargetBackward(t, targetEnd, start);
        if (target.Count == 0)
        {
            return;
        }
        var sourceEnd = ExpressionEnd(t, eq + 1, stopAtComma: initType is not null || InsideArguments(t, eq, start), end);
        var source = Sub(t, eq + 1, sourceEnd);

        // Local declaration: "var x = ...", "Book book = ...", "List<int> xs = ..."
        if (target.Count >= 2 && target[^1].Kind == TokenKind.Identifier && !target[^2].IsPunct('.') && !target[^2].Is("?.")
            && (target[^2].Kind is TokenKind.Identifier or TokenKind.Keyword || target[^2].Text is ">" or "]" or "?"))
        {
            var typeTokens = target.Take(target.Count - 1).Where(x => !x.Is("using") && !x.Is("await") && !x.Is("const")).ToList();
            flow.Locals.Add(new FlowLocal
            {
                Name = target[^1].Text,
                Type = typeTokens.Count == 1 && typeTokens[0].Text == "var" ? null : Expr.Render(typeTokens),
                Init = source,
                Line = t[eq].Line,
            });
            return;
        }
        flow.Assignments.Add(new FlowAssignment
        {
            Target = Expr.Render(target),
            TargetTokens = target,
            Source = source,
            Kind = initType is not null && target.Count == 1 ? AssignmentKinds.Initializer : compound ? AssignmentKinds.Compound : AssignmentKinds.Assign,
            InitializerType = initType is not null && target.Count == 1 ? (initType is "?" ? null : initType) : null,
            Line = t[eq].Line,
        });
    }

    private static bool InsideArguments(List<Token> t, int index, int start)
    {
        var depth = 0;
        for (var k = index - 1; k >= start; k--)
        {
            if (t[k].IsPunct(')') || t[k].IsPunct(']'))
            {
                depth++;
            }
            else if (t[k].IsPunct('(') || t[k].IsPunct('['))
            {
                if (depth == 0)
                {
                    return true;
                }
                depth--;
            }
            else if (t[k].IsPunct(';') || t[k].IsPunct('{') || t[k].IsPunct('}'))
            {
                return false;
            }
        }
        return false;
    }

    /// <summary>Tokens of an assignment target, scanning backwards from <paramref name="endExclusive"/> to a boundary.</summary>
    private static List<Token> TargetBackward(List<Token> t, int endExclusive, int start)
    {
        var list = new List<Token>();
        var k = endExclusive - 1;
        while (k >= start)
        {
            var tok = t[k];
            if (tok.IsPunct(']'))
            {
                var open = MatchBack(t, k, '[', ']');
                list.InsertRange(0, t.GetRange(open, k - open + 1));
                k = open - 1;
                continue;
            }
            if (tok.IsPunct(')'))
            {
                var open = MatchBack(t, k, '(', ')');
                list.InsertRange(0, t.GetRange(open, k - open + 1));
                k = open - 1;
                continue;
            }
            if (tok.IsPunct('>'))
            {
                var open = MatchBack(t, k, '<', '>');
                if (open >= start && open > 0 && t[open - 1].Kind == TokenKind.Identifier)
                {
                    list.InsertRange(0, t.GetRange(open, k - open + 1));
                    k = open - 1;
                    continue;
                }
                break;
            }
            if (tok.Kind == TokenKind.Punct && tok.Text is ";" or "{" or "}" or "," or "(" or "=>" or ":" or "=" or "&&" or "||" or "?" || tok.Is("return"))
            {
                break;
            }
            if (tok.Kind == TokenKind.Punct && tok.Text is not ("." or "?." or "!" ))
            {
                break;
            }
            list.Insert(0, tok);
            k--;
        }
        // Drop leading modifiers of declarations ("readonly", "await using"…) but keep the type.
        while (list.Count > 0 && list[0].Text is "await" or "using" or "const" or "static" or "readonly" or "ref")
        {
            list.RemoveAt(0);
        }
        return list;
    }

    /// <summary>End (exclusive) of an expression starting at <paramref name="from"/>.</summary>
    internal static int ExpressionEnd(List<Token> t, int from, bool stopAtComma, int end)
    {
        var depth = 0;
        for (var k = from; k < end && k < t.Count; k++)
        {
            var tok = t[k];
            if (tok.IsPunct('(') || tok.IsPunct('[') || tok.IsPunct('{'))
            {
                depth++;
            }
            else if (tok.IsPunct(')') || tok.IsPunct(']') || tok.IsPunct('}'))
            {
                if (depth == 0)
                {
                    return k;
                }
                depth--;
            }
            else if (depth == 0 && (tok.IsPunct(';') || stopAtComma && tok.IsPunct(',')))
            {
                return k;
            }
        }
        return Math.Min(end, t.Count);
    }

    private static int CallOpen(List<Token> t, int i, int end)
    {
        var k = i + 1;
        if (k < end && t[k].IsPunct('<'))
        {
            var close = Match(t, k, '<', '>');
            if (close <= k || close >= end || close - k > 40)
            {
                return -1;
            }
            // Only accept "<...>(" where the angle content looks like types.
            for (var m = k + 1; m < close; m++)
            {
                if (!(t[m].Kind is TokenKind.Identifier or TokenKind.Keyword || t[m].Text is "," or "." or "<" or ">" or "?" or "[" or "]"))
                {
                    return -1;
                }
            }
            k = close + 1;
        }
        return k < end && t[k].IsPunct('(') ? k : -1;
    }

    private static void RecordCall(List<Token> t, int nameIndex, int open, int start, int end, MemberFlow flow)
    {
        var close = Match(t, open, '(', ')');
        var (args, names, outs) = SplitArguments(t, open, close);
        var typeArgs = new List<string>();
        if (open > nameIndex + 1)
        {
            typeArgs = SplitTypeArguments(t, nameIndex + 1, open - 1);
        }
        var isCtor = nameIndex > start && t[nameIndex - 1].Is("new");
        var receiver = new List<Token>();
        var wholeStart = isCtor ? nameIndex - 1 : nameIndex;
        if (!isCtor && nameIndex - 1 >= start && (t[nameIndex - 1].IsPunct('.') || t[nameIndex - 1].Is("?.")))
        {
            receiver = ReceiverBackward(t, nameIndex - 1, start);
            wholeStart = nameIndex - 1 - receiver.Count;
        }
        var wholeEnd = close + 1;
        if (isCtor && close + 1 < end && t[close + 1].IsPunct('{'))
        {
            wholeEnd = Match(t, close + 1, '{', '}') + 1;
        }
        flow.Calls.Add(new FlowCall
        {
            Callee = t[nameIndex].Text,
            Receiver = receiver,
            Args = args,
            ArgNames = names,
            ArgIsOut = outs,
            TypeArgs = typeArgs,
            IsConstructor = isCtor,
            ConstructedType = isCtor ? t[nameIndex].Text : null,
            Line = t[nameIndex].Line,
            Whole = Sub(t, Math.Max(start, wholeStart), Math.Min(end, wholeEnd)),
        });

        // Out-argument declarations: "out var x" / "out Type x" become locals whose value comes from the call.
        for (var a = 0; a < args.Count; a++)
        {
            if (outs[a] && args[a].Tokens.Count >= 1 && args[a].Tokens[^1].Kind == TokenKind.Identifier)
            {
                flow.Locals.Add(new FlowLocal { Name = args[a].Tokens[^1].Text, Init = Sub(t, Math.Max(start, wholeStart), close + 1), OutArgument = true, Line = t[nameIndex].Line });
            }
        }
    }

    /// <summary>Receiver chain before a '.' at <paramref name="dot"/> (e.g. "_repo", "a.b", "Get(x).Items[0]").</summary>
    private static List<Token> ReceiverBackward(List<Token> t, int dot, int start)
    {
        var list = new List<Token>();
        var k = dot - 1;
        while (k >= start)
        {
            var tok = t[k];
            if (tok.IsPunct(')'))
            {
                var open = MatchBack(t, k, '(', ')');
                list.InsertRange(0, t.GetRange(open, k - open + 1));
                k = open - 1;
                if (k >= start && (t[k].Kind == TokenKind.Identifier || t[k].IsPunct('>')))
                {
                    continue; // method name or generic args precede
                }
                break;
            }
            if (tok.IsPunct(']'))
            {
                var open = MatchBack(t, k, '[', ']');
                list.InsertRange(0, t.GetRange(open, k - open + 1));
                k = open - 1;
                continue;
            }
            if (tok.IsPunct('>'))
            {
                var open = MatchBack(t, k, '<', '>');
                if (open > start && t[open - 1].Kind == TokenKind.Identifier)
                {
                    list.InsertRange(0, t.GetRange(open, k - open + 1));
                    k = open - 1;
                    continue;
                }
                break;
            }
            if (tok.Kind is TokenKind.Identifier or TokenKind.String || tok.Is("this") || tok.Is("base") || tok.Kind == TokenKind.Keyword && tok.Text is "string" or "int" or "decimal" or "long" or "double" or "bool" or "object")
            {
                list.Insert(0, tok);
                k--;
                if (k >= start && (t[k].IsPunct('.') || t[k].Is("?.") || t[k].IsPunct('!')))
                {
                    list.Insert(0, t[k]);
                    k--;
                    continue;
                }
                break;
            }
            if (tok.IsPunct('!'))
            {
                list.Insert(0, tok);
                k--;
                continue;
            }
            break;
        }
        return list;
    }

    internal static (List<Expr> Args, List<string?> Names, List<bool> Outs) SplitArguments(List<Token> t, int open, int close)
    {
        var args = new List<Expr>();
        var names = new List<string?>();
        var outs = new List<bool>();
        if (close <= open + 1)
        {
            return (args, names, outs);
        }
        var depth = 0;
        var segStart = open + 1;
        for (var k = open + 1; k <= close && k < t.Count; k++)
        {
            var tok = t[k];
            if (k == close || depth == 0 && tok.IsPunct(','))
            {
                var seg = t.GetRange(segStart, Math.Max(0, k - segStart));
                string? name = null;
                if (seg.Count > 2 && seg[0].Kind == TokenKind.Identifier && seg[1].IsPunct(':'))
                {
                    name = seg[0].Text;
                    seg = seg.Skip(2).ToList();
                }
                var isOut = seg.Count > 0 && seg[0].Text is "out" or "ref";
                seg = seg.Where((x, idx) => !(idx == 0 && x.Text is "out" or "ref" or "in")).ToList();
                if (isOut && seg.Count >= 2 && (seg[0].Text == "var" || seg[0].Kind is TokenKind.Identifier or TokenKind.Keyword) && seg[^1].Kind == TokenKind.Identifier)
                {
                    seg = [seg[^1]];
                }
                args.Add(new Expr(seg, seg.Count > 0 ? seg[0].Line : tok.Line));
                names.Add(name);
                outs.Add(isOut);
                segStart = k + 1;
                continue;
            }
            if (tok.IsPunct('(') || tok.IsPunct('[') || tok.IsPunct('{') || tok.IsPunct('<') && IsGenericOpen(t, k))
            {
                depth++;
            }
            else if (tok.IsPunct(')') || tok.IsPunct(']') || tok.IsPunct('}') || tok.IsPunct('>') && depth > 0 && IsGenericCloseCandidate(t, k))
            {
                depth--;
            }
        }
        return (args, names, outs);
    }

    private static bool IsGenericOpen(List<Token> t, int k) => k > 0 && t[k - 1].Kind == TokenKind.Identifier && char.IsUpper(t[k - 1].Text[0]) && Match(t, k, '<', '>') - k < 20;

    private static bool IsGenericCloseCandidate(List<Token> t, int k)
    {
        // Only close a '<' we opened as generic: look back for a matching generic open on the same line.
        var depth = 0;
        for (var m = k; m >= 0 && m > k - 20; m--)
        {
            if (t[m].IsPunct('>'))
            {
                depth++;
            }
            else if (t[m].IsPunct('<'))
            {
                depth--;
                if (depth == 0)
                {
                    return IsGenericOpen(t, m);
                }
            }
        }
        return false;
    }

    private static List<string> SplitTypeArguments(List<Token> t, int lt, int gt)
    {
        var list = new List<string>();
        var depth = 0;
        var seg = new List<Token>();
        for (var k = lt + 1; k <= gt && k < t.Count; k++)
        {
            if (k == gt || depth == 0 && t[k].IsPunct(','))
            {
                if (seg.Count > 0)
                {
                    list.Add(Expr.Render(seg));
                }
                seg.Clear();
                continue;
            }
            if (t[k].IsPunct('<'))
            {
                depth++;
            }
            else if (t[k].IsPunct('>'))
            {
                depth--;
            }
            seg.Add(t[k]);
        }
        return list;
    }

    private static void ParseCatch(List<Token> t, int i, int end, MemberFlow flow)
    {
        string? type = null;
        string? variable = null;
        var k = i + 1;
        if (k < end && t[k].IsPunct('('))
        {
            var close = Match(t, k, '(', ')');
            var inner = t.GetRange(k + 1, Math.Max(0, close - k - 1));
            if (inner.Count >= 1)
            {
                type = inner.Count >= 2 && inner[^1].Kind == TokenKind.Identifier && inner[^2].Kind == TokenKind.Identifier ? inner[^2].Text : inner[^1].Text;
                variable = inner.Count >= 2 && inner[^1].Kind == TokenKind.Identifier ? inner[^1].Text : null;
            }
            k = close + 1;
        }
        if (k < end && t[k].Is("when") && k + 1 < end && t[k + 1].IsPunct('('))
        {
            k = Match(t, k + 1, '(', ')') + 1;
        }
        if (k >= end || !t[k].IsPunct('{'))
        {
            return;
        }
        var blockEnd = Match(t, k, '{', '}');
        var info = new FlowCatch { ExceptionType = type, Variable = variable, Line = t[i].Line };
        for (var m = k + 1; m < blockEnd; m++)
        {
            if (!t[m].Is("throw"))
            {
                continue;
            }
            if (m + 1 < blockEnd && t[m + 1].IsPunct(';'))
            {
                info.Rethrows = true;
            }
            else if (m + 2 < blockEnd && t[m + 1].Is("new") && t[m + 2].Kind == TokenKind.Identifier)
            {
                info.WrapType = t[m + 2].Text;
                var open = m + 3 < blockEnd && t[m + 3].IsPunct('(') ? m + 3 : -1;
                if (open > 0)
                {
                    var close = Match(t, open, '(', ')');
                    info.PassesInner = variable is not null && t.Skip(open).Take(close - open).Any(x => x.Kind == TokenKind.Identifier && x.Text == variable);
                }
            }
        }
        flow.Catches.Add(info);
    }

    private static int FindDepthZero(List<Token> t, int from, int to, string text)
    {
        var depth = 0;
        for (var k = from; k < to; k++)
        {
            if (t[k].IsPunct('(') || t[k].IsPunct('[') || t[k].IsPunct('{'))
            {
                depth++;
            }
            else if (t[k].IsPunct(')') || t[k].IsPunct(']') || t[k].IsPunct('}'))
            {
                depth--;
            }
            else if (depth == 0 && t[k].Text == text)
            {
                return k;
            }
        }
        return -1;
    }

    internal static Expr Sub(List<Token> t, int from, int toExclusive)
    {
        from = Math.Clamp(from, 0, t.Count);
        toExclusive = Math.Clamp(toExclusive, from, t.Count);
        var list = t.GetRange(from, toExclusive - from);
        return new Expr(list, list.Count > 0 ? list[0].Line : from < t.Count ? t[from].Line : 0);
    }

    internal static int Match(List<Token> t, int open, char openChar, char closeChar)
    {
        var depth = 0;
        for (var k = open; k < t.Count; k++)
        {
            if (t[k].IsPunct(openChar))
            {
                depth++;
            }
            else if (t[k].IsPunct(closeChar) && --depth == 0)
            {
                return k;
            }
        }
        return t.Count - 1;
    }

    internal static int MatchBack(List<Token> t, int close, char openChar, char closeChar)
    {
        var depth = 0;
        for (var k = close; k >= 0; k--)
        {
            if (t[k].IsPunct(closeChar))
            {
                depth++;
            }
            else if (t[k].IsPunct(openChar) && --depth == 0)
            {
                return k;
            }
        }
        return 0;
    }
}
