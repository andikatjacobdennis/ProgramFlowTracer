using DocGen.Analysis.Commands;
using DocGen.Analysis.Indexing;
using DocGen.Analysis.Investigations;
using DocGen.Analysis.Repositories;
using DocGen.Analysis.Retention;
using DocGen.Analysis.Tools;
using DocGen.Core.Abstractions;
using DocGen.Core.Options;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis;

public static class AnalysisServiceCollectionExtensions
{
    /// <summary>Code intelligence, debugging tools, command runner and investigations (DocGen 0.7.0).</summary>
    public static IServiceCollection AddDocGenAnalysis(this IServiceCollection services)
    {
        services.AddSingleton(sp => new IndexStore(sp.GetRequiredService<IOptions<DocGenOptions>>().Value.DataDirectory));
        services.AddSingleton<CodeIndexService>();
        services.AddSingleton<RepositoryCatalog>();
        services.AddSingleton<IWorkingFolderResolver, DocGen.Analysis.Repositories.WorkingFolderResolver>();
        services.AddSingleton<CommandRunner>();
        services.AddSingleton<DocGen.Analysis.Execution.IProcessRunner>(sp => sp.GetRequiredService<CommandRunner>());
        services.AddHostedService(sp => sp.GetRequiredService<CommandRunner>());
        services.AddSingleton<DocGen.Analysis.Execution.ExecutableResolver>();
        services.AddSingleton<DocGen.Analysis.Execution.TerminalService>();
        services.AddHostedService(sp => sp.GetRequiredService<DocGen.Analysis.Execution.TerminalService>());
        services.AddSingleton<DocGen.Analysis.Execution.TerminalSuggestions>();
        services.AddSingleton<DocGen.Analysis.Execution.DevServerService>();
        services.AddHostedService(sp => sp.GetRequiredService<DocGen.Analysis.Execution.DevServerService>());
        services.AddSingleton<DocGen.Analysis.Browser.BrowserService>();
        services.AddHostedService(sp => sp.GetRequiredService<DocGen.Analysis.Browser.BrowserService>());
        services.AddSingleton<ICompactionStateProvider, DocGen.Analysis.Execution.InvestigationCompactionProvider>();
        services.AddSingleton<ICompactionStateProvider, DocGen.Analysis.Execution.CommandCompactionProvider>();
        services.AddSingleton<ICompactionStateProvider, DocGen.Analysis.Execution.DevServerCompactionProvider>();
        services.AddSingleton<ICompactionStateProvider, DocGen.Analysis.Execution.BrowserCompactionProvider>();
        services.AddSingleton<InvestigationService>();
        services.AddSingleton<RetentionService>();
        services.AddHostedService(sp => sp.GetRequiredService<RetentionService>());
        services.AddSingleton<AnalysisServices>();

        services.AddSingleton<IToolExecutionGuard, RootCauseEditGuard>();
        services.AddSingleton<IContextContributor, InvestigationContextContributor>();
        services.AddSingleton<IContextContributor, DocGen.Analysis.Repositories.RepositoryContextContributor>();
        services.AddSingleton<IToolExecutionObserver, InvestigationToolObserver>();

        // Navigation (read-only, retrieval over ingestion).
        services.AddSingleton<IAgentTool, RepoListTool>();
        services.AddSingleton<IAgentTool, IndexRepositoryTool>();
        services.AddSingleton<IAgentTool, SolutionOverviewTool>();
        services.AddSingleton<IAgentTool, ProjectOverviewTool>();
        services.AddSingleton<IAgentTool, FindSymbolTool>();
        services.AddSingleton<IAgentTool, FindReferencesTool>();
        services.AddSingleton<IAgentTool, FindImplementationsTool>();
        services.AddSingleton<IAgentTool, FindCallersTool>();
        services.AddSingleton<IAgentTool, FindTestsTool>();
        services.AddSingleton<IAgentTool, ReadSymbolTool>();
        services.AddSingleton<IAgentTool, ReadSourceRangeTool>();
        services.AddSingleton<IAgentTool, SearchCodeTool>();
        services.AddSingleton<IAgentTool, DependencyPathTool>();
        services.AddSingleton<IAgentTool, BlastRadiusTool>();
        services.AddSingleton<IAgentTool, ConfigLookupTool>();
        services.AddSingleton<IAgentTool, DiRegistrationsTool>();
        services.AddSingleton<IAgentTool, PackageInfoTool>();

        // Failure analysis and large data.
        services.AddSingleton<IAgentTool, AnalyzeStackTraceTool>();
        services.AddSingleton<IAgentTool, AnalyzeBuildTool>();
        services.AddSingleton<IAgentTool, AnalyzeTestFailureTool>();
        services.AddSingleton<IAgentTool, LogSummaryTool>();
        services.AddSingleton<IAgentTool, LogSearchTool>();
        services.AddSingleton<IAgentTool, BlobReadTool>();
        services.AddSingleton<IAgentTool, JsonSummaryTool>();
        services.AddSingleton<IAgentTool, JsonTypeShapeTool>();
        services.AddSingleton<IAgentTool, JsonPathTool>();
        services.AddSingleton<IAgentTool, JsonSearchTool>();
        services.AddSingleton<IAgentTool, JsonSampleTool>();
        services.AddSingleton<IAgentTool, JsonDiffTool>();

        // Commands (approval-gated) and investigations.
        services.AddSingleton<IAgentTool, RunBuildTool>();
        services.AddSingleton<IAgentTool, RunTestsTool>();
        services.AddSingleton<IAgentTool, CommandStatusTool>();
        services.AddSingleton<IAgentTool, InvestigationStartTool>();
        services.AddSingleton<IAgentTool, InvestigationRecordTool>();
        services.AddSingleton<IAgentTool, HypothesisUpdateTool>();
        services.AddSingleton<IAgentTool, InvestigationStatusTool>();
        services.AddSingleton<IAgentTool, SourceEditTool>();

        // Root-cause analysis (0.5.0): backward tracing, evidence-weighted ranking, counterfactual verification.
        services.AddSingleton<IAgentTool, RankRootCausesTool>();
        services.AddSingleton<IAgentTool, TraceValueOriginTool>();
        services.AddSingleton<IAgentTool, CompareJsonContractsTool>();
        services.AddSingleton<IAgentTool, ConfigProvenanceTool>();
        services.AddSingleton<IAgentTool, FindRaceRisksTool>();
        services.AddSingleton<IAgentTool, JsonAnomaliesTool>();
        services.AddSingleton<IAgentTool, CounterfactualRunTool>();

        // Execution & computer interaction (0.6.0): controlled processes, dev servers, browser verification.
        services.AddSingleton<IAgentTool, PowerShellTool>();
        services.AddSingleton<IAgentTool, ScriptWriteTool>();
        services.AddSingleton<IAgentTool, ScriptRunTool>();
        services.AddSingleton<IAgentTool, RunProcessTool>();
        services.AddSingleton<IAgentTool, ProcessListTool>();
        services.AddSingleton<IAgentTool, ProcessStopTool>();
        services.AddSingleton<IAgentTool, LineEndingsTool>();
        services.AddSingleton<IAgentTool, DirectoryStatsTool>();
        services.AddSingleton<IAgentTool, DevServerStartTool>();
        services.AddSingleton<IAgentTool, DevServerStatusTool>();
        services.AddSingleton<IAgentTool, DevServerStopTool>();
        services.AddSingleton<IAgentTool, WindowCaptureTool>();
        services.AddSingleton<IAgentTool, SkillLoadTool>();
        services.AddSingleton<IAgentTool, SkillResourceTool>();
        services.AddSingleton<IAgentTool, SkillSearchTool>();
        services.AddSingleton<IAgentTool, DiagramRenderTool>();
        services.AddSingleton<IAgentTool, MapRenderTool>();
        services.AddSingleton<IAgentTool, CommonsMediaTool>();
        services.AddSingleton<IAgentTool, LocalMapTool>();
        services.AddSingleton<IAgentTool, ArchitectureDocsTool>();
        services.AddSingleton<IAgentTool, SolutionDependenciesTool>();
        services.AddSingleton<IAgentTool, DevServerRestartTool>();
        services.AddSingleton<IAgentTool, BrowserOpenTool>();
        services.AddSingleton<IAgentTool, BrowserNavigateTool>();
        services.AddSingleton<IAgentTool, BrowserTabsTool>();
        services.AddSingleton<IAgentTool, BrowserViewportTool>();
        services.AddSingleton<IAgentTool, BrowserReadPageTool>();
        services.AddSingleton<IAgentTool, BrowserClickTool>();
        services.AddSingleton<IAgentTool, BrowserTypeTool>();
        services.AddSingleton<IAgentTool, BrowserSelectTool>();
        services.AddSingleton<IAgentTool, BrowserScrollTool>();
        services.AddSingleton<IAgentTool, BrowserWaitTool>();
        services.AddSingleton<IAgentTool, BrowserScreenshotTool>();
        services.AddSingleton<IAgentTool, BrowserConsoleTool>();
        services.AddSingleton<IAgentTool, BrowserCloseTool>();
        services.AddSingleton<IAgentTool, VerifyWebAppTool>();

        // Developer workflow intelligence (0.7.0): Git status/metrics, branch comparison, gated commit/push.
        services.AddSingleton<DocGen.Analysis.Git.GitService>();
        services.AddSingleton<DocGen.Analysis.Git.DeveloperWorkflowService>();
        services.AddSingleton<IAgentTool, GitStatusTool>();
        services.AddSingleton<IAgentTool, GitDiffTool>();
        services.AddSingleton<IAgentTool, CompareBranchesTool>();
        services.AddSingleton<IAgentTool, PreCommitVerifyTool>();
        services.AddSingleton<IAgentTool, GitCommitTool>();
        services.AddSingleton<IAgentTool, GitPushTool>();
        services.AddSingleton<IAgentTool, PackageSourceTool>();
        services.AddSingleton<IAgentTool, SelectTestsTool>();
        services.AddSingleton<IAgentTool, GenerateTestsTool>();
        services.AddSingleton<IAgentTool, CheckReadinessTool>();
        services.AddSingleton<IAgentTool, PostBuildReportTool>();

        // Project memory (0.7.0): durable repository facts with provenance; agents propose, users accept.
        services.AddSingleton<DocGen.Analysis.Memory.ProjectMemoryService>();
        services.AddSingleton<IContextContributor, DocGen.Analysis.Memory.MemoryContextContributor>();
        services.AddSingleton<IAgentTool, MemorySearchTool>();
        services.AddSingleton<IAgentTool, MemoryProposeTool>();

        // Office documents (0.7.0): DOCX/XLSX/PPTX via ZIP + XML, retrieval over ingestion.
        services.AddSingleton<IAgentTool, ReadDocumentTool>();
        services.AddSingleton<IAgentTool, PdfExportTool>();
        services.AddSingleton<IAgentTool, ImageExportTool>();
        // UI documentation: annotated copies of screenshots and a checker for the written guide.
        services.AddSingleton<IAgentTool, ImageAnnotateTool>();
        services.AddSingleton<IAgentTool, DocsCheckTool>();
        services.AddSingleton<IAgentTool, ListSheetsTool>();
        services.AddSingleton<IAgentTool, SheetSummaryTool>();
        services.AddSingleton<IAgentTool, ReadRangeTool>();
        services.AddSingleton<IAgentTool, FindInWorkbookTool>();
        services.AddSingleton<IAgentTool, FormulaSearchTool>();
        services.AddSingleton<IAgentTool, PresentationSummaryTool>();
        services.AddSingleton<IAgentTool, ReadSlideTool>();
        services.AddSingleton<IAgentTool, SearchPresentationTool>();
        services.AddSingleton<DocGen.Analysis.Documents.ImageAnalyzer>();
        services.AddSingleton<IImageAnalyzer>(sp => sp.GetRequiredService<DocGen.Analysis.Documents.ImageAnalyzer>());
        services.AddSingleton<IAgentTool, ReadImageTool>();
        return services;
    }
}
