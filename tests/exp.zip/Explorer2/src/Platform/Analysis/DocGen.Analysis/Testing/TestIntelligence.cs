using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using DocGen.Analysis.Indexing;

namespace DocGen.Analysis.Testing;

public sealed class TestStage
{
    public int Number { get; init; }
    public string Name { get; init; } = "";
    public string Why { get; set; } = "";
    public List<SymbolRecord> Tests { get; init; } = [];
    public List<string> Projects { get; init; } = [];

    /// <summary>dotnet test target (test project path or solution/null for the repository).</summary>
    public string? Target { get; set; }

    /// <summary>dotnet test --filter expression, or null for "everything in Target".</summary>
    public string? Filter { get; set; }
}

public sealed class TestPlan
{
    public List<string> ChangedFiles { get; init; } = [];
    public List<SymbolRecord> ChangedSymbols { get; init; } = [];
    public List<string> ChangedProjects { get; init; } = [];
    public List<string> Callers { get; init; } = [];
    public List<TestStage> Stages { get; init; } = [];
    public List<string> Notes { get; init; } = [];
}

/// <summary>
/// Test selection from what changed: changed files → declared symbols → callers and implementations → tests that call or
/// use them, tests of the changed projects, tests of dependent projects (blast radius), then the full solution. Run
/// progressively, stopping at the first failing stage.
/// </summary>
public static class TestSelector
{
    public const int MaxFilterClasses = 40;

    public static TestPlan Plan(CodeIndex index, IReadOnlyList<string> changedFiles, IReadOnlyList<string> symbols, string? solution)
    {
        static string Norm(string p) => p.Replace('\\', '/').TrimStart('.', '/');
        var changed = changedFiles.Select(Norm).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var changedSet = changed.ToHashSet(StringComparer.OrdinalIgnoreCase);
        var plan = new TestPlan { ChangedFiles = changed };
        var inFiles = index.Symbols.Where(s => changedSet.Contains(Norm(s.File))).ToList();
        var requested = symbols.SelectMany(q => index.Resolve(q)).ToList();
        var changedSymbols = inFiles.Where(s => !s.IsTest).Concat(requested).Distinct().ToList();
        plan.ChangedSymbols.AddRange(changedSymbols.Take(500));
        var projects = changed.Select(f => index.Files.TryGetValue(f, out var fi) ? fi.Project : index.Files.FirstOrDefault(p => Norm(p.Key).Equals(f, StringComparison.OrdinalIgnoreCase)).Value?.Project)
            .Concat(requested.Select(r => r.Project))
            .Where(p => !string.IsNullOrEmpty(p)).Select(p => p!).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        plan.ChangedProjects.AddRange(projects.Where(p => !index.IsTestProject(p)));
        var allTests = index.TestMethods.ToList();

        // 1. New or changed tests.
        var stage1 = allTests.Where(t => changedSet.Contains(Norm(t.File))).ToList();
        plan.Stages.Add(Stage(index, 1, "new/changed tests", stage1, solution, "tests declared in changed files"));

        // 2. Affected tests: tests that call/use a changed symbol, one of its callers, an implementation, or are named after a changed type.
        var names = new HashSet<string>(StringComparer.Ordinal);
        var typeNames = new HashSet<string>(StringComparer.Ordinal);
        foreach (var s in changedSymbols)
        {
            names.Add(s.Name);
            if (SymbolKinds.IsType(s.Kind))
            {
                typeNames.Add(s.Name);
                foreach (var (derived, _) in index.AllDerived(s.Name, 3))
                {
                    typeNames.Add(derived.Name);
                    names.Add(derived.Name);
                }
            }
            else if (s.Container?.Split('.')[^1] is { } container)
            {
                typeNames.Add(container);
            }
        }
        var callers = new HashSet<string>(StringComparer.Ordinal);
        foreach (var name in names.ToList())
        {
            foreach (var caller in index.CallersByName(name).Where(c => !c.IsTest).Take(50))
            {
                if (callers.Count < 300 && callers.Add(caller.Name))
                {
                    plan.Callers.Add(caller.FullName);
                }
            }
        }
        var affected = allTests.Where(t => !stage1.Contains(t) && (t.Calls.Any(names.Contains) || t.Uses.Any(names.Contains) || t.Calls.Any(callers.Contains)
                                                                   || t.Uses.Any(typeNames.Contains)
                                                                   || t.Container?.Split('.')[^1] is { } c && typeNames.Any(n => c == n + "Tests" || c == n + "Test"))).ToList();
        plan.Stages.Add(Stage(index, 2, "affected tests", affected, solution, $"call or use {names.Count} changed symbols or their {callers.Count} callers"));

        // 3. Tests of the changed projects (test projects that reference them directly).
        var direct = index.Projects.Values.Where(p => p.IsTestProject && (projects.Contains(p.Name, StringComparer.OrdinalIgnoreCase)
                                                                         || index.ProjectReferencesOf(p.Name).Intersect(projects, StringComparer.OrdinalIgnoreCase).Any()))
            .Select(p => p.Name).ToList();
        plan.Stages.Add(ProjectStage(index, 3, "project tests", direct, solution, "test projects that reference a changed project"));

        // 4. Dependents: test projects anywhere in the reverse dependency closure (the blast radius).
        var dependents = projects.SelectMany(index.ReverseProjectClosure).Where(p => index.IsTestProject(p) && !direct.Contains(p, StringComparer.OrdinalIgnoreCase))
            .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        plan.Stages.Add(ProjectStage(index, 4, "dependent project tests", dependents, solution, "test projects of projects that depend on a changed project"));

        // 5. Full solution.
        plan.Stages.Add(new TestStage { Number = 5, Name = "full solution", Why = "everything", Target = solution, Tests = allTests, Projects = index.Projects.Values.Where(p => p.IsTestProject).Select(p => p.Name).ToList() });
        if (changed.Count == 0 && symbols.Count == 0)
        {
            plan.Notes.Add("No changed files or symbols were given; only the full-solution stage is meaningful.");
        }
        return plan;
    }

    private static TestStage Stage(CodeIndex index, int number, string name, List<SymbolRecord> tests, string? solution, string why)
    {
        var projects = tests.Select(t => t.Project).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var classes = tests.Select(t => t.Container ?? t.FullName).Distinct(StringComparer.Ordinal).ToList();
        var stage = new TestStage { Number = number, Name = name, Tests = tests, Projects = projects, Why = why };
        if (tests.Count == 0)
        {
            return stage;
        }
        stage.Target = projects.Count == 1 && index.Projects.TryGetValue(projects[0], out var p) ? p.Path : solution;
        stage.Filter = classes.Count <= MaxFilterClasses
            ? string.Join("|", tests.Count <= 25 ? tests.Select(t => "FullyQualifiedName~" + t.FullName) : classes.Select(c => "FullyQualifiedName~" + c))
            : null;
        if (stage.Filter is null)
        {
            stage.Why += $" ({classes.Count} classes: running the whole project set instead of a filter)";
        }
        return stage;
    }

    private static TestStage ProjectStage(CodeIndex index, int number, string name, List<string> projects, string? solution, string why)
    {
        var stage = new TestStage
        {
            Number = number, Name = name, Projects = projects, Why = why,
            Tests = index.TestMethods.Where(t => projects.Contains(t.Project, StringComparer.OrdinalIgnoreCase)).ToList(),
        };
        stage.Target = projects.Count == 1 && index.Projects.TryGetValue(projects[0], out var p) ? p.Path : projects.Count == 0 ? null : solution;
        if (projects.Count > 1)
        {
            stage.Filter = null;
            stage.Why += $" — run each: {string.Join(", ", projects.Select(x => index.Projects.TryGetValue(x, out var pp) ? pp.Path : x))}";
        }
        return stage;
    }

    public static string Render(TestPlan plan, int maxTests = 15)
    {
        var sb = new StringBuilder();
        sb.AppendLine(CultureInfo.InvariantCulture, $"Test selection for {plan.ChangedFiles.Count} changed file(s), {plan.ChangedSymbols.Count} changed symbol(s) in {string.Join(", ", plan.ChangedProjects.DefaultIfEmpty("(no project)"))}; {plan.Callers.Count} caller(s).");
        foreach (var note in plan.Notes)
        {
            sb.AppendLine("Note: " + note);
        }
        foreach (var s in plan.Stages)
        {
            sb.AppendLine(CultureInfo.InvariantCulture, $"Stage {s.Number} — {s.Name}: {s.Tests.Count} test(s) in {s.Projects.Count} project(s) ({s.Why})");
            if (s.Tests.Count > 0 && s.Number <= 2)
            {
                foreach (var t in s.Tests.Take(maxTests))
                {
                    sb.AppendLine(CultureInfo.InvariantCulture, $"    {t.FullName} — {t.File}:{t.StartLine}");
                }
                if (s.Tests.Count > maxTests)
                {
                    sb.AppendLine(CultureInfo.InvariantCulture, $"    … {s.Tests.Count - maxTests} more");
                }
            }
            if (s.Tests.Count > 0 || s.Number == 5)
            {
                sb.AppendLine(CultureInfo.InvariantCulture, $"    run: dotnet test {s.Target ?? "(repository)"}{(s.Filter is null ? "" : $" --filter \"{Clip(s.Filter, 300)}\"")}");
            }
        }
        sb.AppendLine("Run progressively (select_tests run=1, then 2, …) and stop at the first failing stage; a regression test should fail before the fix (RED) and pass after it (GREEN).");
        return sb.ToString();
    }

    private static string Clip(string s, int max) => s.Length <= max ? s : s[..max] + "…";
}

public sealed class TestConventions
{
    public string Framework { get; set; } = "MSTest";
    public string? FrameworkVersion { get; set; }
    public string? TestProject { get; set; }
    public string? TestProjectPath { get; set; }
    public bool Moq { get; set; }
    public List<string> OtherDoubles { get; set; } = [];
    public List<string> AssertionLibraries { get; set; } = [];
    public string NamingStyle { get; set; } = "Method_condition_expectation";
    public List<string> ExampleNames { get; set; } = [];
    public bool MvcTesting { get; set; }

    /// <summary>MSTest ≥ 3.8 has Assert.ThrowsExactly; older versions use Assert.ThrowsException.</summary>
    public bool HasThrowsExactly => FrameworkVersion is null || Version.TryParse(FrameworkVersion.Split('-')[0], out var v) && v >= new Version(3, 8);
}

public sealed class GeneratedTests
{
    public TestConventions Conventions { get; init; } = new();
    public string Kind { get; init; } = "unit";
    public string ClassName { get; set; } = "";
    public string SuggestedPath { get; set; } = "";
    public string Code { get; set; } = "";
    public int CompleteTests { get; set; }
    public int ScaffoldTests { get; set; }
    public List<string> Analysis { get; } = [];
    public List<string> NewDependencies { get; } = [];
    public List<string> Warnings { get; } = [];
}

/// <summary>
/// Generates MSTest tests from the code index and the repository's own conventions. Guard-clause and smoke checks are
/// complete tests; behaviour tests whose expected values cannot be known from the code are emitted as clearly marked
/// scaffolds (Assert.Inconclusive) — they never count as passing. New dependencies (Moq, Mvc.Testing) are surfaced, never added.
/// </summary>
public static partial class TestGenerator
{
    public static TestConventions Conventions(CodeIndex index, string? forProject)
    {
        var conventions = new TestConventions();
        var tests = index.Projects.Values.Where(p => p.IsTestProject).ToList();
        var chosen = tests.FirstOrDefault(p => forProject is not null && p.Name.Equals(forProject + ".Tests", StringComparison.OrdinalIgnoreCase))
                     ?? tests.FirstOrDefault(p => forProject is not null && index.ProjectReferencesOf(p.Name).Contains(forProject, StringComparer.OrdinalIgnoreCase))
                     ?? tests.FirstOrDefault();
        conventions.TestProject = chosen?.Name;
        conventions.TestProjectPath = chosen?.Path;
        var packages = (chosen?.Packages ?? []).ToList();
        string? Version(string id) => packages.FirstOrDefault(p => p.Id.Equals(id, StringComparison.OrdinalIgnoreCase)) is { } p ? p.ResolvedVersion ?? p.Version ?? "" : null;
        if ((Version("MSTest") ?? Version("MSTest.TestFramework") ?? Version("MSTest.Sdk")) is { } mstest)
        {
            conventions.Framework = "MSTest";
            conventions.FrameworkVersion = mstest.Length == 0 ? null : mstest;
        }
        else if ((Version("xunit") ?? Version("xunit.v3")) is not null)
        {
            conventions.Framework = "xUnit";
        }
        else if (Version("NUnit") is not null)
        {
            conventions.Framework = "NUnit";
        }
        conventions.Moq = Version("Moq") is not null;
        conventions.OtherDoubles.AddRange(new[] { "NSubstitute", "FakeItEasy" }.Where(p => Version(p) is not null));
        conventions.AssertionLibraries.AddRange(new[] { "FluentAssertions", "Shouldly", "AwesomeAssertions" }.Where(p => Version(p) is not null));
        conventions.MvcTesting = Version("Microsoft.AspNetCore.Mvc.Testing") is not null;
        var names = index.TestMethods.Where(t => chosen is null || t.Project == chosen.Name).Select(t => t.Name).Take(200).ToList();
        conventions.ExampleNames = names.Take(4).ToList();
        var underscores = names.Count(n => n.Count(c => c == '_') >= 2);
        conventions.NamingStyle = names.Count == 0 ? "Method_condition_expectation (no existing tests to copy)"
            : underscores * 2 >= names.Count ? "underscore-separated sentences (e.g. " + names.First(n => n.Count(c => c == '_') >= 2) + ")"
            : "PascalCase sentences (e.g. " + names[0] + ")";
        return conventions;
    }

    public static GeneratedTests Unit(CodeIndex index, SymbolRecord type, Func<SymbolRecord, string> source)
    {
        var conventions = Conventions(index, type.Project);
        var result = new GeneratedTests { Conventions = conventions, Kind = "unit", ClassName = type.Name + "Tests" };
        if (conventions.Framework != "MSTest")
        {
            result.Warnings.Add($"The repository's tests use {conventions.Framework}; DocGen generates MSTest. Convert the attributes or ask before adding MSTest.");
        }
        var members = index.MembersOf(type.FullName).ToList();
        var isStatic = type.Modifiers.Contains("static");
        var ctor = members.Where(m => m.Kind == SymbolKinds.Constructor && m.Modifiers.Contains("public")).OrderByDescending(m => m.ParameterTypes.Count).FirstOrDefault();
        var methods = members.Where(m => m.Kind == SymbolKinds.Method && m.Modifiers.Contains("public")).ToList();
        result.Analysis.Add($"{type.Kind} {type.FullName} ({type.File}:{type.StartLine}), {methods.Count} public method(s){(isStatic ? ", static" : "")}");

        var needsMoq = false;
        var ctorArgs = new List<string>();
        // Explicit constructor, or the primary constructor's parameters recorded on the type.
        foreach (var p in ctor?.ParameterTypes ?? type.ParameterTypes)
        {
            var t = p.TrimEnd('?');
            if (IsInterface(index, t))
            {
                if (conventions.Moq)
                {
                    ctorArgs.Add($"new Mock<{t}>().Object");
                    needsMoq = true;
                }
                else
                {
                    ctorArgs.Add($"default! /* TODO: a test double for {t} */");
                    result.Warnings.Add($"{type.Name} depends on {t}. Moq is not referenced by {conventions.TestProject ?? "the test project"}: adding it would be a new NuGet dependency (ask the user first), or write a small hand-written fake.");
                }
                result.Analysis.Add($"dependency {t}: interface → isolated with {(conventions.Moq ? "Moq" : "a test double")}");
            }
            else
            {
                ctorArgs.Add(Sample(t));
                result.Analysis.Add($"dependency {t}: {(IsSimple(t) ? "value" : "real instance")}");
            }
        }

        var sb = new StringBuilder();
        sb.AppendLine("using Microsoft.VisualStudio.TestTools.UnitTesting;");
        if (needsMoq)
        {
            sb.AppendLine("using Moq;");
        }
        if (type.Namespace.Length > 0)
        {
            sb.AppendLine($"using {type.Namespace};");
        }
        sb.AppendLine();
        sb.AppendLine($"namespace {(conventions.TestProject ?? type.Project + ".Tests")}.{(type.Namespace.Split('.').Skip(1).LastOrDefault() is { Length: > 0 } last ? last : "Generated")};");
        sb.AppendLine();
        sb.AppendLine("[TestClass]");
        sb.AppendLine($"public sealed class {result.ClassName}");
        sb.AppendLine("{");
        if (!isStatic)
        {
            sb.AppendLine($"    private static {type.Name} CreateSut() => new({string.Join(", ", ctorArgs)});");
            sb.AppendLine();
        }
        var throwsName = conventions.HasThrowsExactly ? "ThrowsExactly" : "ThrowsException";
        foreach (var m in methods.Take(30))
        {
            var body = source(m);
            var isAsync = m.ReturnType is { } r && (r.StartsWith("Task", StringComparison.Ordinal) || r.StartsWith("ValueTask", StringComparison.Ordinal));
            var parameterNames = ParameterNames(m.Signature);
            var parameterTypes = m.ParameterTypes;
            var target = m.Modifiers.Contains("static") || isStatic ? type.Name : "sut";
            var nullGuards = NullGuards(body).Where(parameterNames.Contains).ToList();
            var throwsList = ThrowStatements(body);
            result.Analysis.Add($"{m.Name}({string.Join(", ", parameterTypes)}) → {m.ReturnType ?? "void"}{(isAsync ? " (async)" : "")}" +
                (nullGuards.Count > 0 ? $"; null guards: {string.Join(", ", nullGuards)}" : "") + (throwsList.Count > 0 ? $"; throws {string.Join(", ", throwsList)}" : "") +
                (parameterTypes.Any(t => t.EndsWith('?')) ? "; nullable parameters: " + string.Join(", ", parameterTypes.Where(t => t.EndsWith('?'))) : ""));

            foreach (var guard in nullGuards)
            {
                var args = parameterNames.Select((n, i) => n == guard ? "null!" : Sample(i < parameterTypes.Count ? parameterTypes[i] : "object")).ToList();
                var call = $"{target}.{m.Name}({string.Join(", ", args)})";
                sb.AppendLine("    [TestMethod]");
                if (isAsync)
                {
                    sb.AppendLine($"    public async Task {m.Name}_throws_ArgumentNullException_when_{guard}_is_null()");
                    sb.AppendLine("    {");
                    AppendSut(sb, target);
                    sb.AppendLine($"        await Assert.{throwsName}Async<ArgumentNullException>(async () => await {call});");
                }
                else
                {
                    sb.AppendLine($"    public void {m.Name}_throws_ArgumentNullException_when_{guard}_is_null()");
                    sb.AppendLine("    {");
                    AppendSut(sb, target);
                    sb.AppendLine($"        Assert.{throwsName}<ArgumentNullException>(() => {call});");
                }
                sb.AppendLine("    }");
                sb.AppendLine();
                result.CompleteTests++;
            }

            var sampleArgs = string.Join(", ", parameterNames.Select((_, i) => Sample(i < parameterTypes.Count ? parameterTypes[i] : "object")));
            sb.AppendLine("    [TestMethod]");
            sb.AppendLine($"    public {(isAsync ? "async Task" : "void")} {m.Name}_returns_expected_result()");
            sb.AppendLine("    {");
            AppendSut(sb, target);
            var returns = m.ReturnType is not null and not "void" and not "Task" and not "ValueTask";
            sb.AppendLine($"        {(returns ? "var result = " : "")}{(isAsync ? "await " : "")}{target}.{m.Name}({sampleArgs});");
            sb.AppendLine("        // TODO: replace with the expected outcome for these inputs (derive it from the requirement, not from the implementation).");
            sb.AppendLine("        Assert.Inconclusive(\"Generated scaffold — complete the assertion before relying on this test.\");");
            sb.AppendLine("    }");
            sb.AppendLine();
            result.ScaffoldTests++;
        }
        sb.AppendLine("}");
        result.Code = sb.ToString().Replace("\n    }\n\n}", "\n    }\n}", StringComparison.Ordinal);
        result.SuggestedPath = SuggestPath(index, conventions, type, result.ClassName);
        if (needsMoq)
        {
            result.Analysis.Add("Moq is already referenced by the test project; it is used only for interface dependencies.");
        }
        return result;
    }

    private static void AppendSut(StringBuilder sb, string target)
    {
        if (target == "sut")
        {
            sb.AppendLine("        var sut = CreateSut();");
        }
    }

    /// <summary>Smoke tests for a web project: app starts, health, auth page, a key API, no fatal startup errors (process-based, no new packages).</summary>
    public static GeneratedTests Smoke(CodeIndex index, ProjectInfo project, bool integration)
    {
        var conventions = Conventions(index, project.Name);
        var result = new GeneratedTests { Conventions = conventions, Kind = integration ? "integration" : "smoke", ClassName = SafeIdentifier(project.Name) + (integration ? "IntegrationTests" : "SmokeTests") };
        var endpoints = index.Endpoints.Where(e => e.File.StartsWith(project.Directory.Replace('\\', '/').TrimEnd('/') + "/", StringComparison.OrdinalIgnoreCase) || project.Directory is "" or ".").ToList();
        var gets = endpoints.Where(e => e.Verb.Equals("GET", StringComparison.OrdinalIgnoreCase) && !e.Route.Contains('{', StringComparison.Ordinal)).Select(e => "/" + e.Route.TrimStart('/')).Distinct().ToList();
        var health = gets.FirstOrDefault(r => r.Contains("health", StringComparison.OrdinalIgnoreCase));
        var auth = gets.FirstOrDefault(r => AuthRoute().IsMatch(r));
        var api = gets.FirstOrDefault(r => r.StartsWith("/api", StringComparison.OrdinalIgnoreCase) && r != health) ?? gets.FirstOrDefault(r => r != health && r != auth);
        result.Analysis.Add($"{project.Name}: {endpoints.Count} endpoints, {gets.Count} parameterless GET routes; health {health ?? "none"}; auth page {auth ?? "none"}; key API {api ?? "none"}");
        if (integration && conventions.MvcTesting)
        {
            result.Analysis.Add("Microsoft.AspNetCore.Mvc.Testing is referenced: in-process WebApplicationFactory tests would also be possible.");
        }
        else if (integration)
        {
            result.NewDependencies.Add("Microsoft.AspNetCore.Mvc.Testing (not referenced) would allow in-process WebApplicationFactory tests; the generated tests start the real app as a process instead, so no new package is needed.");
        }
        var projectPath = project.Path.Replace('\\', '/');
        var sb = new StringBuilder();
        sb.AppendLine("using System.Diagnostics;");
        sb.AppendLine("using System.Net;");
        sb.AppendLine("using System.Net.Sockets;");
        sb.AppendLine("using System.Text;");
        sb.AppendLine("using Microsoft.VisualStudio.TestTools.UnitTesting;");
        sb.AppendLine();
        sb.AppendLine($"namespace {(conventions.TestProject ?? project.Name + ".Tests")}.{(integration ? "Integration" : "Smoke")};");
        sb.AppendLine();
        sb.AppendLine("/// <summary>Starts the real application (dotnet run --no-build) on a free loopback port and checks it over HTTP.</summary>");
        sb.AppendLine("[TestClass]");
        sb.AppendLine($"public sealed class {result.ClassName}");
        sb.AppendLine("{");
        sb.AppendLine("    private static readonly StringBuilder Output = new();");
        sb.AppendLine("    private static Process? _app;");
        sb.AppendLine("    private static HttpClient _http = null!;");
        sb.AppendLine();
        sb.AppendLine("    [ClassInitialize]");
        sb.AppendLine("    public static async Task StartAsync(TestContext _)");
        sb.AppendLine("    {");
        sb.AppendLine("        var listener = new TcpListener(IPAddress.Loopback, 0);");
        sb.AppendLine("        listener.Start();");
        sb.AppendLine("        var port = ((IPEndPoint)listener.LocalEndpoint).Port;");
        sb.AppendLine("        listener.Stop();");
        sb.AppendLine("        var root = AppContext.BaseDirectory;");
        sb.AppendLine("        while (root is not null && !Directory.EnumerateFiles(root, \"*.sln*\").Any())");
        sb.AppendLine("        {");
        sb.AppendLine("            root = Path.GetDirectoryName(root);");
        sb.AppendLine("        }");
        sb.AppendLine("        Assert.IsNotNull(root, \"Solution folder not found.\");");
        sb.AppendLine($"        var psi = new ProcessStartInfo(\"dotnet\", [\"run\", \"--no-build\", \"--project\", Path.Combine(root, \"{projectPath}\"), \"--urls\", $\"http://127.0.0.1:{{port}}\"])");
        sb.AppendLine("        {");
        sb.AppendLine("            RedirectStandardOutput = true, RedirectStandardError = true, UseShellExecute = false,");
        sb.AppendLine("        };");
        sb.AppendLine("        psi.Environment[\"ASPNETCORE_ENVIRONMENT\"] = \"Development\";");
        sb.AppendLine("        _app = Process.Start(psi)!;");
        sb.AppendLine("        _app.OutputDataReceived += (_, e) => { lock (Output) { Output.AppendLine(e.Data); } };");
        sb.AppendLine("        _app.ErrorDataReceived += (_, e) => { lock (Output) { Output.AppendLine(e.Data); } };");
        sb.AppendLine("        _app.BeginOutputReadLine();");
        sb.AppendLine("        _app.BeginErrorReadLine();");
        sb.AppendLine("        _http = new HttpClient { BaseAddress = new Uri($\"http://127.0.0.1:{port}\"), Timeout = TimeSpan.FromSeconds(10) };");
        sb.AppendLine("        var deadline = DateTime.UtcNow.AddSeconds(90);");
        sb.AppendLine("        while (DateTime.UtcNow < deadline && !_app.HasExited)");
        sb.AppendLine("        {");
        sb.AppendLine("            try");
        sb.AppendLine("            {");
        sb.AppendLine("                await _http.GetAsync(\"/\");");
        sb.AppendLine("                return;");
        sb.AppendLine("            }");
        sb.AppendLine("            catch (HttpRequestException)");
        sb.AppendLine("            {");
        sb.AppendLine("                await Task.Delay(500);");
        sb.AppendLine("            }");
        sb.AppendLine("        }");
        sb.AppendLine("    }");
        sb.AppendLine();
        sb.AppendLine("    [ClassCleanup]");
        sb.AppendLine("    public static void Stop()");
        sb.AppendLine("    {");
        sb.AppendLine("        if (_app is { HasExited: false })");
        sb.AppendLine("        {");
        sb.AppendLine("            _app.Kill(entireProcessTree: true);");
        sb.AppendLine("        }");
        sb.AppendLine("        _app?.Dispose();");
        sb.AppendLine("    }");
        sb.AppendLine();
        void Test(string name, string body)
        {
            sb.AppendLine("    [TestMethod]");
            sb.AppendLine($"    public async Task {name}()");
            sb.AppendLine("    {");
            sb.Append(body);
            sb.AppendLine("    }");
            sb.AppendLine();
            result.CompleteTests++;
        }
        Test("App_starts", "        await Task.CompletedTask;\n        Assert.IsNotNull(_app);\n        Assert.IsFalse(_app.HasExited, \"The application exited during startup:\\n\" + Output);\n");
        if (health is not null)
        {
            Test("Health_endpoint_is_healthy", $"        var response = await _http.GetAsync(\"{health}\");\n        Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);\n");
        }
        if (auth is not null)
        {
            Test("Auth_page_loads", $"        var response = await _http.GetAsync(\"{auth}\");\n        Assert.IsTrue((int)response.StatusCode < 500, $\"{auth} returned {{(int)response.StatusCode}}\");\n");
        }
        if (api is not null)
        {
            Test("Key_api_has_no_server_error", $"        var response = await _http.GetAsync(\"{api}\");\n        Assert.IsTrue((int)response.StatusCode < 500, $\"{api} returned {{(int)response.StatusCode}}\");\n");
        }
        if (integration)
        {
            foreach (var route in gets.Where(r => r != health && r != auth && r != api).Take(8))
            {
                Test("Get_" + SafeIdentifier(route.Trim('/').Replace('/', '_')) + "_has_no_server_error",
                    $"        var response = await _http.GetAsync(\"{route}\");\n        Assert.IsTrue((int)response.StatusCode < 500, $\"{route} returned {{(int)response.StatusCode}}\");\n");
            }
        }
        Test("No_fatal_errors_during_startup", "        await Task.Delay(500);\n        string log;\n        lock (Output)\n        {\n            log = Output.ToString();\n        }\n" +
                                             "        StringAssert.DoesNotMatch(log, new System.Text.RegularExpressions.Regex(\"crit:|fail: Microsoft.AspNetCore|Unhandled exception\", System.Text.RegularExpressions.RegexOptions.IgnoreCase));\n");
        sb.AppendLine("}");
        result.Code = sb.ToString().Replace("\n    }\n\n}", "\n    }\n}", StringComparison.Ordinal);
        result.SuggestedPath = (conventions.TestProjectPath is { } tp ? Path.GetDirectoryName(tp)!.Replace('\\', '/') : "tests/" + project.Name + ".Tests") + $"/{(integration ? "Integration" : "Smoke")}/{result.ClassName}.cs";
        return result;
    }

    private static string SuggestPath(CodeIndex index, TestConventions conventions, SymbolRecord type, string className)
    {
        var testDir = conventions.TestProjectPath is { } tp ? Path.GetDirectoryName(tp)!.Replace('\\', '/') : "tests/" + type.Project + ".Tests";
        var projectDir = index.Projects.TryGetValue(type.Project, out var p) ? p.Directory.Replace('\\', '/').TrimEnd('/') : "";
        var relative = type.File.Replace('\\', '/');
        if (projectDir.Length > 0 && relative.StartsWith(projectDir + "/", StringComparison.OrdinalIgnoreCase))
        {
            relative = relative[(projectDir.Length + 1)..];
        }
        var folder = Path.GetDirectoryName(relative)?.Replace('\\', '/');
        return $"{testDir}/{(string.IsNullOrEmpty(folder) ? "" : folder + "/")}{className}.cs";
    }

    private static bool IsInterface(CodeIndex index, string type)
    {
        var name = CodeIndex.StripGeneric(type.Split('.')[^1]);
        var resolved = index.ByName(name).Where(s => SymbolKinds.IsType(s.Kind)).ToList();
        return resolved.Count > 0 ? resolved.Any(s => s.Kind == SymbolKinds.Interface) : name.Length > 1 && name[0] == 'I' && char.IsUpper(name[1]);
    }

    private static bool IsSimple(string t) => Sample(t) is not "default!";

    public static string Sample(string type)
    {
        var t = type.Trim();
        var nullable = t.EndsWith('?');
        t = t.TrimEnd('?');
        return t switch
        {
            "string" or "String" => "\"value\"",
            "int" or "long" or "short" or "Int32" or "Int64" => "1",
            "decimal" => "1m",
            "double" => "1.0",
            "float" => "1f",
            "bool" or "Boolean" => "false",
            "Guid" => "Guid.NewGuid()",
            "DateTime" => "new DateTime(2024, 1, 1)",
            "DateTimeOffset" => "new DateTimeOffset(2024, 1, 1, 0, 0, 0, TimeSpan.Zero)",
            "TimeSpan" => "TimeSpan.FromSeconds(1)",
            "CancellationToken" => "CancellationToken.None",
            _ when t.EndsWith("[]", StringComparison.Ordinal) => $"Array.Empty<{t[..^2]}>()",
            _ when t.StartsWith("List<", StringComparison.Ordinal) || t.StartsWith("IEnumerable<", StringComparison.Ordinal) || t.StartsWith("IReadOnlyList<", StringComparison.Ordinal)
                => $"new List<{t[(t.IndexOf('<') + 1)..^1]}>()",
            _ => nullable ? "null" : "default!",
        };
    }

    /// <summary>Parameter names from a signature such as "Task&lt;int&gt; M(string name, int count = 1)".</summary>
    public static List<string> ParameterNames(string signature)
    {
        var open = signature.IndexOf('(');
        var close = signature.LastIndexOf(')');
        if (open < 0 || close <= open + 1)
        {
            return [];
        }
        var inner = signature[(open + 1)..close];
        var parts = new List<string>();
        var depth = 0;
        var start = 0;
        for (var i = 0; i < inner.Length; i++)
        {
            depth += inner[i] is '<' or '(' or '[' ? 1 : inner[i] is '>' or ')' or ']' ? -1 : 0;
            if (inner[i] == ',' && depth == 0)
            {
                parts.Add(inner[start..i]);
                start = i + 1;
            }
        }
        parts.Add(inner[start..]);
        return parts.Select(p => p.Split('=')[0].Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries).LastOrDefault() ?? "").Where(n => n.Length > 0).ToList();
    }

    public static List<string> NullGuards(string body)
        => NullGuard().Matches(body).Select(m => m.Groups["a"].Success ? m.Groups["a"].Value : m.Groups["b"].Success ? m.Groups["b"].Value : m.Groups["c"].Value).Distinct().ToList();

    public static List<string> ThrowStatements(string body)
        => ThrowNew().Matches(body).Select(m => m.Groups[1].Value).Distinct().ToList();

    private static string SafeIdentifier(string value)
    {
        var s = new string(value.Select(ch => char.IsLetterOrDigit(ch) ? ch : '_').ToArray()).Trim('_');
        return s.Length == 0 ? "Root" : char.IsDigit(s[0]) ? "_" + s : s;
    }

    [GeneratedRegex(@"ArgumentNullException\.ThrowIfNull(?:OrEmpty|OrWhiteSpace)?\(\s*(?<a>\w+)\s*\)|if\s*\(\s*(?<b>\w+)\s*(?:is\s+null|==\s*null)\s*\)\s*\{?\s*throw\s+new\s+ArgumentNullException|(?<c>\w+)\s*\?\?\s*throw\s+new\s+ArgumentNullException")]
    private static partial Regex NullGuard();

    [GeneratedRegex(@"throw\s+new\s+(\w+Exception)\b")]
    private static partial Regex ThrowNew();

    [GeneratedRegex(@"(^|/)(login|signin|sign-in|account/login|auth)(/|$|\.html)", RegexOptions.IgnoreCase)]
    private static partial Regex AuthRoute();
}
