using System.Globalization;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace DocGen.Analysis.Json;

/// <summary>Aggregated information about one normalised path ("$.items[*].price") in a document.</summary>
public sealed class JsonPathShape
{
    public string Path { get; set; } = "";
    public long Count { get; set; }
    public long Nulls { get; set; }
    public SortedSet<string> Types { get; set; } = new(StringComparer.Ordinal);
    public long MaxStringBytes { get; set; }
    public double? MinNumber { get; set; }
    public double? MaxNumber { get; set; }
    public long MinArrayLength { get; set; } = long.MaxValue;
    public long MaxArrayLength { get; set; }
    public int Depth { get; set; }
}

public sealed class JsonSummary
{
    public long Bytes { get; set; }
    public long EstimatedTokens { get; set; }
    public string RootType { get; set; } = "";
    public long Values { get; set; }
    public int MaxDepth { get; set; }
    public Dictionary<string, long> TypeCounts { get; set; } = new(StringComparer.Ordinal);
    public List<(string Path, long Bytes, string Type)> TopLevel { get; set; } = [];
    public List<(string Path, long Length)> LargestArrays { get; set; } = [];
    public List<(string Path, long Bytes)> LargestStrings { get; set; } = [];
    public List<(string Path, long Bytes)> LargestSubtrees { get; set; } = [];
    public List<(string Path, long Nulls, long Count)> NullHeavyPaths { get; set; } = [];
    public List<JsonPathShape> Shapes { get; set; } = [];
    public bool ShapesCapped { get; set; }
    public long ElapsedMs { get; set; }
}

public sealed class JsonMatch
{
    public string Path { get; set; } = "";
    public string Kind { get; set; } = "";
    public string Preview { get; set; } = "";
    public bool Truncated { get; set; }
    public long Bytes { get; set; }
}

public sealed class JsonDifference
{
    public string Path { get; set; } = "";

    /// <summary>added | removed | changed | type</summary>
    public string Kind { get; set; } = "";

    public string? Before { get; set; }
    public string? After { get; set; }
}

/// <summary>
/// Analysis of large JSON documents without loading them into the model's context. Summary, shape, search, path
/// queries and sampling stream the file (no size limit); diff loads both documents (bounded by configuration).
/// </summary>
public static class JsonAnalyzer
{
    public const int MaxShapes = 5000;

    public static JsonSummary Summarize(string path, CancellationToken ct)
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        var summary = new JsonSummary { Bytes = new FileInfo(path).Length };
        summary.EstimatedTokens = summary.Bytes / 4;
        var shapes = new Dictionary<string, JsonPathShape>(StringComparer.Ordinal);
        var arrays = new TopN<string>(10);
        var strings = new TopN<string>(10);
        var subtrees = new TopN<string>(10);

        JsonScanner.Scan(path, evt =>
        {
            if (evt.IsEnd)
            {
                var bytes = evt.End - evt.Start;
                var p = evt.PathString();
                if (evt.TokenType == JsonTokenType.EndArray)
                {
                    arrays.Add(p, evt.Length);
                }
                if (evt.Depth >= 1)
                {
                    subtrees.Add(p, bytes);
                }
                if (evt.Depth == 1)
                {
                    summary.TopLevel.Add((p, bytes, evt.TokenType == JsonTokenType.EndArray ? "array" : "object"));
                }
                Shape(shapes, evt, summary)?.Also(s =>
                {
                    s.MinArrayLength = evt.TokenType == JsonTokenType.EndArray ? Math.Min(s.MinArrayLength, evt.Length) : s.MinArrayLength;
                    s.MaxArrayLength = evt.TokenType == JsonTokenType.EndArray ? Math.Max(s.MaxArrayLength, evt.Length) : s.MaxArrayLength;
                });
                return true;
            }

            summary.Values++;
            summary.MaxDepth = Math.Max(summary.MaxDepth, evt.Depth);
            var type = TypeName(evt.TokenType);
            summary.TypeCounts[type] = summary.TypeCounts.GetValueOrDefault(type) + 1;
            if (evt.Depth == 0)
            {
                summary.RootType = type;
            }
            if (evt.Depth == 1 && evt.TokenType is not (JsonTokenType.StartArray or JsonTokenType.StartObject))
            {
                summary.TopLevel.Add((evt.PathString(), evt.End - evt.Start, type));
            }
            var shape = Shape(shapes, evt, summary);
            if (shape is not null)
            {
                shape.Count++;
                shape.Types.Add(type);
                if (evt.TokenType == JsonTokenType.Null)
                {
                    shape.Nulls++;
                }
                else if (evt.TokenType == JsonTokenType.String)
                {
                    shape.MaxStringBytes = Math.Max(shape.MaxStringBytes, evt.Length);
                    strings.Add(evt.PathString(), evt.Length);
                }
                else if (evt.TokenType == JsonTokenType.Number && double.TryParse(evt.Value, NumberStyles.Float, CultureInfo.InvariantCulture, out var number))
                {
                    shape.MinNumber = shape.MinNumber is null ? number : Math.Min(shape.MinNumber.Value, number);
                    shape.MaxNumber = shape.MaxNumber is null ? number : Math.Max(shape.MaxNumber.Value, number);
                }
            }
            return true;
        }, ct);

        summary.LargestArrays = arrays.Items();
        summary.LargestStrings = strings.Items();
        summary.LargestSubtrees = subtrees.Items();
        summary.Shapes = shapes.Values.OrderBy(s => s.Path, StringComparer.Ordinal).ToList();
        summary.NullHeavyPaths = shapes.Values.Where(s => s.Nulls > 0).OrderByDescending(s => s.Nulls).Take(15).Select(s => (s.Path, s.Nulls, s.Count)).ToList();
        summary.ElapsedMs = sw.ElapsedMilliseconds;
        return summary;
    }

    private static JsonPathShape? Shape(Dictionary<string, JsonPathShape> shapes, JsonScanEvent evt, JsonSummary summary)
    {
        var key = evt.PathString(wildcardIndexes: true);
        if (shapes.TryGetValue(key, out var shape))
        {
            return shape;
        }
        if (shapes.Count >= MaxShapes)
        {
            summary.ShapesCapped = true;
            return null;
        }
        shape = new JsonPathShape { Path = key, Depth = evt.Depth };
        shapes[key] = shape;
        return shape;
    }

    public static string TypeName(JsonTokenType token) => token switch
    {
        JsonTokenType.StartObject or JsonTokenType.EndObject => "object",
        JsonTokenType.StartArray or JsonTokenType.EndArray => "array",
        JsonTokenType.String => "string",
        JsonTokenType.Number => "number",
        JsonTokenType.True or JsonTokenType.False => "boolean",
        _ => "null",
    };

    /// <summary>Finds property names and/or primitive values containing the text (or matching the regex).</summary>
    public static (List<JsonMatch> Matches, long Total) Search(string path, string? text, string? regex, bool keys, bool values, int limit, int skip, CancellationToken ct)
    {
        var matches = new List<JsonMatch>();
        long total = 0;
        var re = regex is null ? null : new Regex(regex, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(100));
        bool IsMatch(string? candidate)
        {
            if (candidate is null)
            {
                return false;
            }
            if (re is not null)
            {
                try
                {
                    return re.IsMatch(candidate);
                }
                catch (RegexMatchTimeoutException)
                {
                    return false;
                }
            }
            return text is not null && candidate.Contains(text, StringComparison.OrdinalIgnoreCase);
        }

        JsonScanner.Scan(path, evt =>
        {
            if (evt.IsEnd)
            {
                return true;
            }
            var slot = evt.Path[^1];
            var keyHit = keys && slot.Name is not null && IsMatch(slot.Name);
            var valueHit = values && evt.Value is not null && IsMatch(evt.Value);
            if (keyHit || valueHit)
            {
                total++;
                if (total > skip && matches.Count < limit)
                {
                    matches.Add(new JsonMatch
                    {
                        Path = evt.PathString(),
                        Kind = keyHit ? "key" : "value",
                        Preview = evt.Value is null ? $"({TypeName(evt.TokenType)})" : Clip(evt.Value, 300),
                        Bytes = evt.End > 0 ? evt.End - evt.Start : 0,
                    });
                }
            }
            return true;
        }, ct);
        return (matches, total);
    }

    /// <summary>
    /// Evaluates a path expression: $, .name, ['name'], [n], [*] and ..name (recursive descent). Returns matched
    /// values as raw JSON slices (bounded per match).
    /// </summary>
    public static (List<JsonMatch> Matches, long Total) Query(string path, string expression, int limit, int maxBytesPerMatch, CancellationToken ct)
    {
        var pattern = JsonPathPattern.Parse(expression);
        var hits = new List<(string Path, long Start, long End, string Type)>();
        long total = 0;
        var open = new Dictionary<int, int>(); // depth → index in hits (containers awaiting their end offset)

        JsonScanner.Scan(path, evt =>
        {
            if (evt.IsEnd)
            {
                if (open.Remove(evt.Depth, out var hitIndex))
                {
                    var h = hits[hitIndex];
                    hits[hitIndex] = (h.Path, h.Start, evt.End, h.Type);
                }
                return true;
            }
            if (!pattern.Matches(evt.Path))
            {
                return true;
            }
            total++;
            if (hits.Count < limit)
            {
                hits.Add((evt.PathString(), evt.Start, evt.End, TypeName(evt.TokenType)));
                if (evt.TokenType is JsonTokenType.StartObject or JsonTokenType.StartArray)
                {
                    open[evt.Depth] = hits.Count - 1;
                }
            }
            return true;
        }, ct);

        var matches = hits.Select(h =>
        {
            var (slice, truncated) = JsonScanner.ReadSlice(path, h.Start, h.End, maxBytesPerMatch);
            return new JsonMatch { Path = h.Path, Kind = h.Type, Preview = slice, Truncated = truncated, Bytes = h.End - h.Start };
        }).ToList();
        return (matches, total);
    }

    /// <summary>Samples elements of the array at <paramref name="arrayPath"/>: first | last | spread (evenly spaced).</summary>
    public static (List<JsonMatch> Samples, long ArrayLength) Sample(string path, string arrayPath, int count, string strategy, int maxBytesPerElement, CancellationToken ct)
    {
        var pattern = JsonPathPattern.Parse(arrayPath);
        count = Math.Clamp(count, 1, 50);

        // Pass 1: find the array and its length (and the first/last element offsets when that is all we need).
        long length = -1;
        var arrayDepth = -1;
        var first = new List<(long Index, long Start, long End)>();
        var last = new Queue<(long Index, long Start, long End)>();
        var starts = new Dictionary<int, (long Index, long Start)>();
        JsonScanner.Scan(path, evt =>
        {
            if (arrayDepth < 0)
            {
                if (!evt.IsEnd && evt.TokenType == JsonTokenType.StartArray && pattern.Matches(evt.Path))
                {
                    arrayDepth = evt.Depth;
                }
                return true;
            }
            if (evt.IsEnd && evt.Depth == arrayDepth)
            {
                length = evt.Length;
                return false;
            }
            if (evt.Depth == arrayDepth + 1)
            {
                var index = evt.Path[^1].Index;
                if (!evt.IsEnd && evt.TokenType is JsonTokenType.StartObject or JsonTokenType.StartArray)
                {
                    starts[evt.Depth] = (index, evt.Start);
                    return true;
                }
                var element = evt.IsEnd ? (starts[evt.Depth].Index, starts[evt.Depth].Start, evt.End) : (index, evt.Start, evt.End);
                if (first.Count < count)
                {
                    first.Add(element);
                }
                last.Enqueue(element);
                if (last.Count > count)
                {
                    last.Dequeue();
                }
            }
            return true;
        }, ct);
        if (length < 0)
        {
            return ([], -1);
        }

        List<(long Index, long Start, long End)> chosen;
        if (strategy == "last")
        {
            chosen = last.ToList();
        }
        else if (strategy == "spread" && length > count)
        {
            var wanted = Enumerable.Range(0, count).Select(i => (long)Math.Round(i * (length - 1) / (double)(count - 1 == 0 ? 1 : count - 1))).ToHashSet();
            chosen = [];
            var depthStarts = new Dictionary<int, (long, long)>();
            var inside = -1;
            JsonScanner.Scan(path, evt =>
            {
                if (inside < 0)
                {
                    if (!evt.IsEnd && evt.TokenType == JsonTokenType.StartArray && pattern.Matches(evt.Path))
                    {
                        inside = evt.Depth;
                    }
                    return true;
                }
                if (evt.IsEnd && evt.Depth == inside)
                {
                    return false;
                }
                if (evt.Depth == inside + 1)
                {
                    var index = evt.Path[^1].Index;
                    if (!evt.IsEnd && evt.TokenType is JsonTokenType.StartObject or JsonTokenType.StartArray)
                    {
                        depthStarts[evt.Depth] = (index, evt.Start);
                        return true;
                    }
                    var element = evt.IsEnd ? (depthStarts[evt.Depth].Item1, depthStarts[evt.Depth].Item2, evt.End) : (index, evt.Start, evt.End);
                    if (wanted.Contains(element.Item1))
                    {
                        chosen.Add(element);
                    }
                }
                return true;
            }, ct);
        }
        else
        {
            chosen = first;
        }

        var samples = chosen.Select(e =>
        {
            var (slice, truncated) = JsonScanner.ReadSlice(path, e.Start, e.End, maxBytesPerElement);
            return new JsonMatch { Path = $"{arrayPath.TrimEnd()}[{e.Index}]", Kind = "element", Preview = slice, Truncated = truncated, Bytes = e.End - e.Start };
        }).ToList();
        return (samples, length);
    }

    /// <summary>Structural diff. Arrays of objects can be matched by a key property instead of by position.</summary>
    public static (List<JsonDifference> Differences, long Total) Diff(JsonElement before, JsonElement after, string? arrayKey, int limit)
    {
        var diffs = new List<JsonDifference>();
        long total = 0;
        void Add(string path, string kind, JsonElement? a, JsonElement? b)
        {
            total++;
            if (diffs.Count < limit)
            {
                diffs.Add(new JsonDifference { Path = path, Kind = kind, Before = a is { } x ? Clip(x.GetRawText(), 200) : null, After = b is { } y ? Clip(y.GetRawText(), 200) : null });
            }
        }
        void Compare(string path, JsonElement a, JsonElement b, int depth)
        {
            if (depth > JsonScanner.MaxDepth)
            {
                return;
            }
            var ka = Kind(a);
            var kb = Kind(b);
            if (ka != kb)
            {
                Add(path, "type", a, b);
                return;
            }
            switch (a.ValueKind)
            {
                case JsonValueKind.Object:
                    var propsB = new Dictionary<string, JsonElement>(StringComparer.Ordinal);
                    foreach (var p in b.EnumerateObject())
                    {
                        propsB[p.Name] = p.Value;
                    }
                    foreach (var p in a.EnumerateObject())
                    {
                        var child = Child(path, p.Name);
                        if (propsB.Remove(p.Name, out var other))
                        {
                            Compare(child, p.Value, other, depth + 1);
                        }
                        else
                        {
                            Add(child, "removed", p.Value, null);
                        }
                    }
                    foreach (var (name, value) in propsB)
                    {
                        Add(Child(path, name), "added", null, value);
                    }
                    break;
                case JsonValueKind.Array:
                    if (arrayKey is not null && IsKeyed(a, arrayKey) && IsKeyed(b, arrayKey))
                    {
                        var mapB = b.EnumerateArray().GroupBy(e => e.GetProperty(arrayKey).GetRawText()).ToDictionary(g => g.Key, g => g.First());
                        foreach (var element in a.EnumerateArray())
                        {
                            var key = element.GetProperty(arrayKey).GetRawText();
                            var child = $"{path}[?(@.{arrayKey}=={key})]";
                            if (mapB.Remove(key, out var other))
                            {
                                Compare(child, element, other, depth + 1);
                            }
                            else
                            {
                                Add(child, "removed", element, null);
                            }
                        }
                        foreach (var (key, value) in mapB)
                        {
                            Add($"{path}[?(@.{arrayKey}=={key})]", "added", null, value);
                        }
                        break;
                    }
                    var la = a.GetArrayLength();
                    var lb = b.GetArrayLength();
                    for (var i = 0; i < Math.Max(la, lb); i++)
                    {
                        if (i >= la)
                        {
                            Add($"{path}[{i}]", "added", null, b[i]);
                        }
                        else if (i >= lb)
                        {
                            Add($"{path}[{i}]", "removed", a[i], null);
                        }
                        else
                        {
                            Compare($"{path}[{i}]", a[i], b[i], depth + 1);
                        }
                    }
                    break;
                default:
                    if (a.GetRawText() != b.GetRawText())
                    {
                        Add(path, "changed", a, b);
                    }
                    break;
            }
        }
        Compare("$", before, after, 0);
        return (diffs, total);
    }

    private static string Kind(JsonElement e) => e.ValueKind is JsonValueKind.True or JsonValueKind.False ? "boolean" : e.ValueKind.ToString();

    private static bool IsKeyed(JsonElement array, string key)
        => array.GetArrayLength() > 0 && array.EnumerateArray().All(e => e.ValueKind == JsonValueKind.Object && e.TryGetProperty(key, out _));

    private static string Child(string path, string name)
        => name.Length > 0 && name.All(c => char.IsLetterOrDigit(c) || c is '_' or '$' or '-') && !char.IsDigit(name[0]) ? path + "." + name : $"{path}['{name}']";

    public static string Clip(string value, int max) => value.Length <= max ? value : value[..max] + "…";

    /// <summary>Keeps the N items with the largest values.</summary>
    private sealed class TopN<TKey>(int n)
    {
        private readonly List<(TKey Key, long Value)> _items = [];

        public void Add(TKey key, long value)
        {
            if (_items.Count < n)
            {
                _items.Add((key, value));
                return;
            }
            var minIndex = 0;
            for (var i = 1; i < _items.Count; i++)
            {
                if (_items[i].Value < _items[minIndex].Value)
                {
                    minIndex = i;
                }
            }
            if (value > _items[minIndex].Value)
            {
                _items[minIndex] = (key, value);
            }
        }

        public List<(TKey, long)> Items() => _items.OrderByDescending(i => i.Value).Select(i => (i.Key, i.Value)).ToList();
    }
}

internal static class FluentExtensions
{
    public static void Also<T>(this T value, Action<T> action) => action(value);
}

/// <summary>A compiled path pattern: $, .name, ['name'], [n], [*], ..name.</summary>
public sealed class JsonPathPattern
{
    private sealed record Segment(string? Name, int? Index, bool Wildcard, bool Recursive);

    private readonly List<Segment> _segments;

    private JsonPathPattern(List<Segment> segments) => _segments = segments;

    public static JsonPathPattern Parse(string expression)
    {
        var text = expression.Trim();
        if (text.Length == 0 || text[0] != '$')
        {
            text = "$" + (text.StartsWith('.') || text.StartsWith('[') ? "" : ".") + text;
        }
        var segments = new List<Segment>();
        var i = 1;
        while (i < text.Length)
        {
            var recursive = false;
            if (text[i] == '.')
            {
                i++;
                if (i < text.Length && text[i] == '.')
                {
                    recursive = true;
                    i++;
                }
                if (i < text.Length && text[i] == '*')
                {
                    segments.Add(new Segment(null, null, true, recursive));
                    i++;
                    continue;
                }
                var start = i;
                while (i < text.Length && text[i] != '.' && text[i] != '[')
                {
                    i++;
                }
                if (i == start)
                {
                    throw new FormatException("Empty property name in path.");
                }
                segments.Add(new Segment(text[start..i], null, false, recursive));
                continue;
            }
            if (text[i] == '[')
            {
                var close = text.IndexOf(']', i);
                if (close < 0)
                {
                    throw new FormatException("Unclosed '[' in path.");
                }
                var inner = text[(i + 1)..close].Trim();
                i = close + 1;
                if (inner == "*")
                {
                    segments.Add(new Segment(null, null, true, false));
                }
                else if (inner.Length >= 2 && inner[0] is '\'' or '"' && inner[^1] == inner[0])
                {
                    segments.Add(new Segment(inner[1..^1], null, false, false));
                }
                else if (int.TryParse(inner, NumberStyles.None, CultureInfo.InvariantCulture, out var index))
                {
                    segments.Add(new Segment(null, index, false, false));
                }
                else
                {
                    throw new FormatException($"Unsupported path segment '[{inner}]'. Use [n], [*] or ['name'].");
                }
                continue;
            }
            throw new FormatException($"Unexpected character '{text[i]}' in path.");
        }
        if (segments.Count > 64)
        {
            throw new FormatException("Path is too deep.");
        }
        return new JsonPathPattern(segments);
    }

    /// <summary>Does the concrete path (root frame first) match this pattern?</summary>
    public bool Matches(List<JsonPathFrame> frames) => Match(frames, 1, 0);

    private bool Match(List<JsonPathFrame> frames, int f, int s)
    {
        if (s == _segments.Count)
        {
            return f == frames.Count;
        }
        if (f >= frames.Count)
        {
            return false;
        }
        var segment = _segments[s];
        if (segment.Recursive)
        {
            for (var k = f; k < frames.Count; k++)
            {
                if (SegmentMatches(segment, frames[k]) && Match(frames, k + 1, s + 1))
                {
                    return true;
                }
            }
            return false;
        }
        return SegmentMatches(segment, frames[f]) && Match(frames, f + 1, s + 1);
    }

    private static bool SegmentMatches(Segment segment, JsonPathFrame frame)
    {
        if (segment.Wildcard)
        {
            return true;
        }
        if (segment.Index is { } index)
        {
            return frame.Index == index;
        }
        return frame.Index < 0 && string.Equals(frame.Name, segment.Name, StringComparison.Ordinal);
    }
}
