using System.Globalization;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace DocGen.Analysis.Json;

public sealed class JsonAnomaly
{
    public string Path { get; set; } = "";
    public long Index { get; set; }
    public string Field { get; set; } = "";
    public string? Value { get; set; }

    /// <summary>missing-field | unexpected-null | type-change | rare-value | rare-format | outlier | duplicate-id | unexpected-field</summary>
    public string Kind { get; set; } = "";

    public string Reason { get; set; } = "";
    public string Typical { get; set; } = "";

    /// <summary>Higher = rarer / more severe (used for ordering only).</summary>
    public double Severity { get; set; }

    public bool CorrelatedWithFailure { get; set; }
}

public sealed class AnomalyReport
{
    public string ArrayPath { get; set; } = "";
    public long Elements { get; set; }
    public int FieldsProfiled { get; set; }
    public List<JsonAnomaly> Anomalies { get; set; } = [];
    public long ElapsedMs { get; set; }
}

/// <summary>
/// Finds records that differ from the rest of a large JSON array, streaming the file twice (profile, then compare).
/// Memory is bounded by the number of fields and capped value dictionaries, not by the file size.
/// </summary>
public static partial class JsonAnomalyDetector
{
    private const int MaxDistinct = 64;
    private const int MaxSignatures = 256;
    private const int MaxIds = 2_000_000;

    private sealed class FieldStats
    {
        public long Present;
        public long Nulls;
        public Dictionary<string, long> Types = new(StringComparer.Ordinal);
        public Dictionary<string, long> Values = new(StringComparer.Ordinal);
        public bool ValuesOverflow;
        public Dictionary<string, long> Signatures = new(StringComparer.Ordinal);
        public long Numbers;
        public double Mean;
        public double M2;
        public HashSet<string>? Ids;
        public List<string> Duplicates = [];
    }

    public static AnomalyReport Scan(string path, string? arrayPath, int maxAnomalies, CancellationToken ct)
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        arrayPath ??= LargestObjectArray(path, ct);
        var report = new AnomalyReport { ArrayPath = arrayPath ?? "$" };
        if (arrayPath is null)
        {
            return report;
        }
        var pattern = JsonPathPattern.Parse(arrayPath);
        var stats = new Dictionary<string, FieldStats>(StringComparer.Ordinal);
        long elements = 0;

        // Pass 1: profile.
        Walk(path, pattern, ct, (index, fields) =>
        {
            elements++;
            foreach (var (field, (type, value)) in fields)
            {
                if (!stats.TryGetValue(field, out var s))
                {
                    if (stats.Count >= 400)
                    {
                        continue;
                    }
                    s = new FieldStats();
                    if (IsIdLike(field))
                    {
                        s.Ids = new HashSet<string>(StringComparer.Ordinal);
                    }
                    stats[field] = s;
                }
                s.Present++;
                s.Types[type] = s.Types.GetValueOrDefault(type) + 1;
                if (type == "null")
                {
                    s.Nulls++;
                    continue;
                }
                if (type is "string" or "boolean" or "number")
                {
                    if (!s.ValuesOverflow)
                    {
                        if (s.Values.ContainsKey(value!) || s.Values.Count < MaxDistinct)
                        {
                            s.Values[value!] = s.Values.GetValueOrDefault(value!) + 1;
                        }
                        else
                        {
                            s.ValuesOverflow = true;
                            s.Values.Clear();
                        }
                    }
                }
                if (type == "string")
                {
                    var sig = Signature(value!);
                    if (s.Signatures.ContainsKey(sig) || s.Signatures.Count < MaxSignatures)
                    {
                        s.Signatures[sig] = s.Signatures.GetValueOrDefault(sig) + 1;
                    }
                }
                if (type == "number" && double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var number))
                {
                    s.Numbers++;
                    var delta = number - s.Mean;
                    s.Mean += delta / s.Numbers;
                    s.M2 += delta * (number - s.Mean);
                }
                if (s.Ids is not null && value is not null && s.Ids.Count < MaxIds && !s.Ids.Add(value) && s.Duplicates.Count < 20)
                {
                    s.Duplicates.Add(value);
                }
            }
        });
        report.Elements = elements;
        report.FieldsProfiled = stats.Count;
        if (elements < 20)
        {
            report.ElapsedMs = sw.ElapsedMilliseconds;
            return report; // Too few records for a baseline.
        }

        // Pass 2: compare each record with the profile.
        var anomalies = new List<JsonAnomaly>();
        var rare = Math.Max(0.001, 2.0 / elements);
        Walk(path, pattern, ct, (index, fields) =>
        {
            var elementPath = $"{arrayPath}[{index}]";
            foreach (var (field, s) in stats)
            {
                if (!fields.ContainsKey(field) && s.Present >= 0.99 * elements && s.Present < elements)
                {
                    anomalies.Add(new JsonAnomaly { Path = elementPath, Index = index, Field = field, Kind = "missing-field", Reason = $"`{field}` is missing (present in {Percent(s.Present, elements)} of records)", Typical = TypicalValues(s, elements), Severity = 8 });
                }
            }
            foreach (var (field, (type, value)) in fields)
            {
                if (!stats.TryGetValue(field, out var s))
                {
                    continue;
                }
                if (s.Present <= rare * elements)
                {
                    anomalies.Add(new JsonAnomaly { Path = elementPath, Index = index, Field = field, Value = value, Kind = "unexpected-field", Reason = $"field `{field}` appears in only {s.Present} record(s)", Severity = 5 });
                    continue;
                }
                if (type == "null")
                {
                    if (s.Nulls <= 0.01 * s.Present)
                    {
                        anomalies.Add(new JsonAnomaly { Path = elementPath, Index = index, Field = field, Value = "null", Kind = "unexpected-null", Reason = $"`{field}` is null ({s.Nulls} null of {s.Present})", Typical = TypicalValues(s, elements), Severity = 8 });
                    }
                    continue;
                }
                var dominant = s.Types.MaxBy(kv => kv.Value);
                if (type != dominant.Key && dominant.Value >= 0.99 * s.Present)
                {
                    anomalies.Add(new JsonAnomaly { Path = elementPath, Index = index, Field = field, Value = value, Kind = "type-change", Reason = $"`{field}` is a {type} ({Preview(value)}) where {Percent(dominant.Value, s.Present)} of records have a {dominant.Key}", Typical = TypicalValues(s, elements), Severity = 9 });
                    continue;
                }
                if (!s.ValuesOverflow && value is not null && s.Values.Count <= 20 && s.Values.TryGetValue(value, out var count) && count <= rare * elements && s.Values.Count > 1)
                {
                    anomalies.Add(new JsonAnomaly { Path = elementPath, Index = index, Field = field, Value = value, Kind = "rare-value", Reason = $"`{field}` = {Preview(value)} occurs {count} time(s); usual values: {TypicalValues(s, elements)}", Typical = TypicalValues(s, elements), Severity = 7 + Math.Min(2, 1.0 / count) });
                    continue;
                }
                if (type == "string" && s.ValuesOverflow && value is not null)
                {
                    var sig = Signature(value);
                    var dominantSig = s.Signatures.MaxBy(kv => kv.Value);
                    if (s.Signatures.TryGetValue(sig, out var sigCount) && sigCount <= rare * elements && dominantSig.Value >= 0.9 * s.Present && sig != dominantSig.Key)
                    {
                        anomalies.Add(new JsonAnomaly { Path = elementPath, Index = index, Field = field, Value = value, Kind = "rare-format", Reason = $"`{field}` = {Preview(value)} has format {sig}; {Percent(dominantSig.Value, s.Present)} use {dominantSig.Key}", Typical = dominantSig.Key, Severity = 6 });
                    }
                }
                if (type == "number" && s.Numbers >= 50 && double.TryParse(value, NumberStyles.Float, CultureInfo.InvariantCulture, out var x))
                {
                    var std = Math.Sqrt(s.M2 / (s.Numbers - 1));
                    if (std > 0 && Math.Abs(x - s.Mean) / std > 6)
                    {
                        anomalies.Add(new JsonAnomaly { Path = elementPath, Index = index, Field = field, Value = value, Kind = "outlier", Reason = $"`{field}` = {value} is {Math.Abs(x - s.Mean) / std:0.#} standard deviations from the mean {s.Mean:0.##}", Typical = $"mean {s.Mean:0.##} ± {std:0.##}", Severity = 4 });
                    }
                }
                if (s.Duplicates.Contains(value ?? ""))
                {
                    anomalies.Add(new JsonAnomaly { Path = elementPath, Index = index, Field = field, Value = value, Kind = "duplicate-id", Reason = $"`{field}` = {Preview(value)} is not unique", Severity = 5 });
                }
            }
        });
        report.Anomalies = anomalies.OrderByDescending(a => a.Severity).ThenBy(a => a.Index).Take(Math.Max(1, maxAnomalies)).ToList();
        report.ElapsedMs = sw.ElapsedMilliseconds;
        return report;
    }

    /// <summary>Marks anomalies whose value or path appears in the failure text (quoted or as a whole token).</summary>
    public static void Correlate(AnomalyReport report, string failureText)
    {
        foreach (var a in report.Anomalies)
        {
            var quoted = a.Value is { Length: > 0 } v && (failureText.Contains($"'{v}'", StringComparison.Ordinal) || failureText.Contains($"\"{v}\"", StringComparison.Ordinal)
                                                          || v.Length >= 3 && Regex.IsMatch(failureText, $@"(?<![\w.]){Regex.Escape(v)}(?![\w])"));
            var byPath = failureText.Contains($"[{a.Index}]", StringComparison.Ordinal) && failureText.Contains(a.Field.Split('.')[^1], StringComparison.OrdinalIgnoreCase);
            a.CorrelatedWithFailure = quoted || byPath;
        }
    }

    private static string? LargestObjectArray(string path, CancellationToken ct)
    {
        var summary = JsonAnalyzer.Summarize(path, ct);
        foreach (var (arrayPath, _) in summary.LargestArrays)
        {
            if (summary.Shapes.Any(s => s.Path == Wildcard(arrayPath) + "[*]" && s.Types.Contains("object")))
            {
                return arrayPath;
            }
        }
        return summary.LargestArrays.FirstOrDefault().Path;
    }

    private static string Wildcard(string concrete) => IndexPattern().Replace(concrete, "[*]");

    /// <summary>Streams the elements of the array matching <paramref name="pattern"/>, flattening fields one level deep.</summary>
    private static void Walk(string path, JsonPathPattern pattern, CancellationToken ct, Action<long, Dictionary<string, (string Type, string? Value)>> onElement)
    {
        var arrayDepth = -1;
        Dictionary<string, (string, string?)>? current = null;
        long index = -1;
        JsonScanner.Scan(path, evt =>
        {
            if (arrayDepth < 0)
            {
                if (!evt.IsEnd && evt.TokenType == JsonTokenType.StartArray && pattern.Matches(evt.Path))
                {
                    arrayDepth = evt.Depth;
                }
                return true;
            }
            if (evt.Depth == arrayDepth && evt.IsEnd)
            {
                return false; // Done with the array.
            }
            if (evt.Depth == arrayDepth + 1)
            {
                if (!evt.IsEnd && evt.TokenType == JsonTokenType.StartObject)
                {
                    current = new Dictionary<string, (string, string?)>(StringComparer.Ordinal);
                    index = evt.Path[^1].Index;
                }
                else if (evt.IsEnd && current is not null)
                {
                    onElement(index, current);
                    current = null;
                }
                return true;
            }
            if (current is null || evt.IsEnd)
            {
                return true;
            }
            var relative = evt.Depth - arrayDepth - 1;
            if (relative is 1 or 2)
            {
                var name = relative == 1 ? evt.Path[^1].Name : $"{evt.Path[^2].Name}.{evt.Path[^1].Name}";
                if (name is null || evt.Path[^1].Index >= 0)
                {
                    return true;
                }
                current[name] = (JsonAnalyzer.TypeName(evt.TokenType), evt.Value);
            }
            return true;
        }, ct);
    }

    private static bool IsIdLike(string field)
    {
        var leaf = field.Split('.')[^1];
        return leaf is "id" or "Id" or "ID" or "sku" or "Sku" or "key" or "Key" || leaf.EndsWith("Id", StringComparison.Ordinal) && !field.Contains('.');
    }

    /// <summary>Shape of a string: letters → a/A, digits → 9, other characters kept (runs compressed).</summary>
    public static string Signature(string value)
    {
        var sb = new StringBuilder();
        foreach (var c in value.Length > 64 ? value[..64] : value)
        {
            var mapped = char.IsDigit(c) ? '9' : char.IsLower(c) ? 'a' : char.IsUpper(c) ? 'A' : c;
            if (sb.Length == 0 || sb[^1] != mapped || !(mapped is '9' or 'a' or 'A'))
            {
                sb.Append(mapped);
            }
        }
        return sb.ToString();
    }

    private static string TypicalValues(FieldStats s, long elements)
    {
        if (!s.ValuesOverflow && s.Values.Count > 0)
        {
            return string.Join(", ", s.Values.OrderByDescending(kv => kv.Value).Take(4).Select(kv => $"{Preview(kv.Key)} ({Percent(kv.Value, elements)})"));
        }
        if (s.Numbers > 0)
        {
            return $"numbers around {s.Mean:0.##}";
        }
        var sig = s.Signatures.OrderByDescending(kv => kv.Value).FirstOrDefault();
        return sig.Key is null ? "" : $"format {sig.Key}";
    }

    private static string Percent(long part, long total) => total == 0 ? "0%" : $"{100.0 * part / total:0.##}%";

    private static string Preview(string? value) => value is null ? "null" : value.Length > 40 ? $"\"{value[..40]}…\"" : $"\"{value}\"";

    [GeneratedRegex(@"\[\d+\]")]
    private static partial Regex IndexPattern();
}
