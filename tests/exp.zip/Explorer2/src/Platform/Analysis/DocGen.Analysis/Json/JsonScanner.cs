using System.Buffers;
using System.Text;
using System.Text.Json;

namespace DocGen.Analysis.Json;

/// <summary>One step on the path to a JSON value: a property name or an array index.</summary>
public sealed class JsonPathFrame
{
    public bool IsArray;
    public string? Name;
    public int Index = -1;

    /// <summary>For containers: absolute byte offset of the opening bracket.</summary>
    public long Start;

    /// <summary>For containers: number of direct children seen so far.</summary>
    public int Children;
}

/// <summary>A value (primitive or container start/end) encountered by <see cref="JsonScanner"/>.</summary>
public sealed class JsonScanEvent
{
    public JsonTokenType TokenType;

    /// <summary>Path frames from the root to this value (the last frame is this value's slot).</summary>
    public required List<JsonPathFrame> Path;

    /// <summary>Absolute byte offsets in the file: [Start, End). End is known for primitives and container ends.</summary>
    public long Start;
    public long End;

    /// <summary>For strings: length in bytes (escaped). For containers at end: number of children.</summary>
    public long Length;

    /// <summary>Primitive value text (strings unescaped, bounded to 4 KB); null for containers.</summary>
    public string? Value;

    public bool IsEnd;
    public int Depth => Path.Count - 1;

    public string PathString(bool wildcardIndexes = false) => JsonScanner.FormatPath(Path, wildcardIndexes);
}

/// <summary>
/// Streams a JSON file of any size through <see cref="Utf8JsonReader"/> with a growing buffer, tracking the path and
/// absolute byte offsets of every value. Memory is proportional to nesting depth and the largest single token, not
/// the document size. The callback returns false to stop early.
/// </summary>
public static class JsonScanner
{
    public const int MaxDepth = 256;
    private const int ValuePreviewBytes = 4096;

    public static void Scan(string path, Func<JsonScanEvent, bool> onEvent, CancellationToken ct)
    {
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16, FileOptions.SequentialScan);
        var buffer = ArrayPool<byte>.Shared.Rent(1 << 20);
        try
        {
            var filled = 0;
            long consumedBefore = 0;
            var final = false;
            var state = new JsonReaderState(new JsonReaderOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true, MaxDepth = MaxDepth });
            var frames = new List<JsonPathFrame>();
            string? pendingName = null;
            var evt = new JsonScanEvent { Path = frames };

            // Skip a UTF-8 BOM.
            filled = stream.Read(buffer, 0, buffer.Length);
            var offset = filled >= 3 && buffer[0] == 0xEF && buffer[1] == 0xBB && buffer[2] == 0xBF ? 3 : 0;
            if (offset > 0)
            {
                Buffer.BlockCopy(buffer, 3, buffer, 0, filled - 3);
                filled -= 3;
                consumedBefore = 3;
            }
            final = filled == 0;

            while (true)
            {
                ct.ThrowIfCancellationRequested();
                var reader = new Utf8JsonReader(buffer.AsSpan(0, filled), final, state);
                while (reader.Read())
                {
                    var token = reader.TokenType;
                    if (token == JsonTokenType.PropertyName)
                    {
                        pendingName = reader.GetString();
                        continue;
                    }
                    var absoluteStart = consumedBefore + reader.TokenStartIndex;
                    if (token is JsonTokenType.EndObject or JsonTokenType.EndArray)
                    {
                        var frame = frames[^1];
                        evt.TokenType = token;
                        evt.Start = frame.Start;
                        evt.End = absoluteStart + 1;
                        evt.Length = frame.Children;
                        evt.Value = null;
                        evt.IsEnd = true;
                        if (!onEvent(evt))
                        {
                            return;
                        }
                        frames.RemoveAt(frames.Count - 1);
                        continue;
                    }

                    // A value: occupy the next slot in the parent.
                    var slot = new JsonPathFrame { Start = absoluteStart };
                    if (frames.Count > 0)
                    {
                        var parent = frames[^1];
                        if (parent.IsArray)
                        {
                            slot.Index = parent.Children;
                        }
                        else
                        {
                            slot.Name = pendingName;
                        }
                        parent.Children++;
                    }
                    pendingName = null;
                    frames.Add(slot);
                    evt.TokenType = token;
                    evt.Start = absoluteStart;
                    evt.IsEnd = false;

                    if (token is JsonTokenType.StartObject or JsonTokenType.StartArray)
                    {
                        slot.IsArray = token == JsonTokenType.StartArray;
                        evt.End = -1;
                        evt.Length = 0;
                        evt.Value = null;
                        if (!onEvent(evt))
                        {
                            return;
                        }
                        continue;
                    }

                    evt.End = consumedBefore + reader.BytesConsumed;
                    evt.Length = reader.HasValueSequence ? reader.ValueSequence.Length : reader.ValueSpan.Length;
                    evt.Value = token switch
                    {
                        JsonTokenType.String when evt.Length <= ValuePreviewBytes => reader.GetString(),
                        JsonTokenType.String => Encoding.UTF8.GetString(reader.ValueSpan[..Math.Min(reader.ValueSpan.Length, ValuePreviewBytes)]) + "…",
                        JsonTokenType.Number => Encoding.UTF8.GetString(reader.ValueSpan),
                        JsonTokenType.True => "true",
                        JsonTokenType.False => "false",
                        _ => "null",
                    };
                    var keepGoing = onEvent(evt);
                    frames.RemoveAt(frames.Count - 1);
                    if (!keepGoing)
                    {
                        return;
                    }
                }

                if (final)
                {
                    return;
                }
                state = reader.CurrentState;
                var consumed = (int)reader.BytesConsumed;
                consumedBefore += consumed;
                var leftover = filled - consumed;
                if (leftover > 0)
                {
                    Buffer.BlockCopy(buffer, consumed, buffer, 0, leftover);
                }
                if (leftover == buffer.Length)
                {
                    // A single token larger than the buffer: grow.
                    var bigger = ArrayPool<byte>.Shared.Rent(buffer.Length * 2);
                    Buffer.BlockCopy(buffer, 0, bigger, 0, leftover);
                    ArrayPool<byte>.Shared.Return(buffer);
                    buffer = bigger;
                }
                var read = stream.Read(buffer, leftover, buffer.Length - leftover);
                filled = leftover + read;
                final = read == 0;
            }
        }
        finally
        {
            ArrayPool<byte>.Shared.Return(buffer);
        }
    }

    public static string FormatPath(IReadOnlyList<JsonPathFrame> frames, bool wildcardIndexes)
    {
        var sb = new StringBuilder("$");
        for (var i = 1; i < frames.Count; i++)
        {
            var f = frames[i];
            if (f.Index >= 0)
            {
                sb.Append(wildcardIndexes ? "[*]" : $"[{f.Index}]");
            }
            else if (f.Name is { } name)
            {
                if (name.Length > 0 && name.All(c => char.IsLetterOrDigit(c) || c is '_' or '$' or '-') && !char.IsDigit(name[0]))
                {
                    sb.Append('.').Append(name);
                }
                else
                {
                    sb.Append("['").Append(name.Replace("'", "\\'")).Append("']");
                }
            }
        }
        return sb.ToString();
    }

    /// <summary>Reads [start, end) of the file (bounded), for showing matched values.</summary>
    public static (string Text, bool Truncated) ReadSlice(string path, long start, long end, int maxBytes)
    {
        if (start < 0 || end <= start)
        {
            return ("", false);
        }
        var length = (int)Math.Min(end - start, maxBytes);
        var bytes = new byte[length];
        using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        stream.Seek(start, SeekOrigin.Begin);
        var read = 0;
        while (read < length)
        {
            var n = stream.Read(bytes, read, length - read);
            if (n == 0)
            {
                break;
            }
            read += n;
        }
        // Avoid splitting a multi-byte UTF-8 sequence at the cut.
        var text = Encoding.UTF8.GetString(bytes, 0, read);
        return (text, end - start > maxBytes);
    }
}
