using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using DocGen.Core.Exceptions;

namespace DocGen.Analysis.Maps;

/// <summary>A GeoJSON feature reduced to what maps need: string properties, polygons (rings of lon/lat pairs) or lines.</summary>
public sealed class GeoFeature
{
    public required IReadOnlyDictionary<string, string> Properties { get; init; }

    /// <summary>Polygons, each a list of rings (outer first); a ring is [lon0, lat0, lon1, lat1, …].</summary>
    public IReadOnlyList<IReadOnlyList<double[]>> Polygons { get; init; } = [];

    /// <summary>Line strings, each [lon0, lat0, lon1, lat1, …].</summary>
    public IReadOnlyList<double[]> Lines { get; init; } = [];

    /// <summary>Point features (populated places).</summary>
    public (double Lon, double Lat)? Point { get; init; }

    public (double West, double South, double East, double North) Bounds { get; init; }

    public string Get(string key) => Properties.TryGetValue(key, out var v) ? v : "";
}

/// <summary>
/// Natural Earth (public domain, naturalearthdata.com) data for maps, v5.1.2. Files are downloaded on first use from
/// the project's release tag and checked against their published git blob hashes before use, then cached under
/// {data}/geo/. Country boundaries come in "point of view" editions: the same world drawn the way a given country's
/// government draws it (for India: all of Jammu &amp; Kashmir and Ladakh, including the areas administered by Pakistan
/// and China, inside India). DocGen uses the user's country's edition when one exists.
/// </summary>
public sealed class NaturalEarth(string cacheDirectory, HttpClient? http = null, bool verify = true)
{
    public const string Version = "v5.1.2";
    private const string BaseUrl = "https://raw.githubusercontent.com/nvkelso/natural-earth-vector/" + Version + "/geojson/";

    public const string DefaultCountriesFile = "ne_10m_admin_0_countries.geojson";
    public const string StatesFile = "ne_50m_admin_1_states_provinces.geojson";
    public const string PlacesFile = "ne_10m_populated_places_simple.geojson";

    /// <summary>Git blob SHA-1 and size of each file at the pinned tag (from the GitHub contents API).</summary>
    private static readonly Dictionary<string, (string Sha, long Size)> Pins = new(StringComparer.Ordinal)
    {
        ["ne_10m_admin_0_countries.geojson"] = ("5ebc66e25fc1af01edaebe9375c546655e04cf1e", 13287234),
        ["ne_10m_admin_0_countries_arg.geojson"] = ("8994af4ec8de1ce66358273aa2bd00574710cb08", 13212970),
        ["ne_10m_admin_0_countries_bdg.geojson"] = ("193a2ad5007eff8365a9fca5a08f39e353b9f079", 13219102),
        ["ne_10m_admin_0_countries_bra.geojson"] = ("72f54dd0233788b5cfcc7f724fec921843764967", 13229096),
        ["ne_10m_admin_0_countries_chn.geojson"] = ("464406c710df1add2c6025b1c90b67c207b4002b", 13205107),
        ["ne_10m_admin_0_countries_deu.geojson"] = ("0a1f1fdf02536e47e244d3b02f62a873f17b0f43", 13232694),
        ["ne_10m_admin_0_countries_egy.geojson"] = ("63e1bbeeeb16956fed1ab67faaecbf703916426d", 13229953),
        ["ne_10m_admin_0_countries_esp.geojson"] = ("1ede5fa6bf6ce3dacb5265a14ad92fa6aafd7876", 13222717),
        ["ne_10m_admin_0_countries_fra.geojson"] = ("e80bb7d020f94ed2f4ae47dd9a23739bcf827b83", 13225891),
        ["ne_10m_admin_0_countries_gbr.geojson"] = ("c16bf09354a7f924e502342615224d115cd3c3f1", 13236144),
        ["ne_10m_admin_0_countries_grc.geojson"] = ("17c221e4fc8900bdb3b9e3ed772d51d67c25139c", 13222986),
        ["ne_10m_admin_0_countries_idn.geojson"] = ("3882f2928d536f2004ca4b7ecd7ab763c8fefbcb", 13202902),
        ["ne_10m_admin_0_countries_ind.geojson"] = ("852f3fdf92c01811d433e258b1475179184bd9b0", 13242091),
        ["ne_10m_admin_0_countries_isr.geojson"] = ("a36bea67da2b8838822ee19101f514de200e3294", 13232084),
        ["ne_10m_admin_0_countries_ita.geojson"] = ("405b08f5a88c6dc671d48b53fec65975ab6d22c8", 13232383),
        ["ne_10m_admin_0_countries_jpn.geojson"] = ("a42f521e1f0f1465c6dddf6bf1730b562f7038ed", 13232502),
        ["ne_10m_admin_0_countries_kor.geojson"] = ("c905d1d70f3a6090e61d3f089618a3002490103a", 13233357),
        ["ne_10m_admin_0_countries_mar.geojson"] = ("7b378febec4e1f9bb5f02b630d4b0b9e1afe6226", 13213047),
        ["ne_10m_admin_0_countries_nep.geojson"] = ("a5c66538bbb3a489b2793fcc1e49897a1a8dab55", 13242878),
        ["ne_10m_admin_0_countries_nld.geojson"] = ("41aac13c65f0144e0e57624bf94cabf43d9a3c7b", 13225580),
        ["ne_10m_admin_0_countries_pak.geojson"] = ("da5b3874974bc5ec879e9ff22351ca0307e089c0", 13222725),
        ["ne_10m_admin_0_countries_pol.geojson"] = ("2a573c4989227d1e3031453c2072c70e187c7cb3", 13225580),
        ["ne_10m_admin_0_countries_prt.geojson"] = ("aee051df1094bf1b19e96b5c9b5a13c9de299b35", 13232291),
        ["ne_10m_admin_0_countries_pse.geojson"] = ("2939a90ad15949bd2c2c44a9cfce05583d5dc562", 13247652),
        ["ne_10m_admin_0_countries_rus.geojson"] = ("e991ce04ebf0ffa0488aa6ca53d9ad48e0cf5981", 13296060),
        ["ne_10m_admin_0_countries_sau.geojson"] = ("f29026ec93bb8d7f5145183715e4d2b6cc97c774", 13220358),
        ["ne_10m_admin_0_countries_swe.geojson"] = ("1b18b490c689b9074f0d3e20ed90161e0fd6a89c", 13232383),
        ["ne_10m_admin_0_countries_tur.geojson"] = ("5cc25138564916cf93806e392bfa3fffc3877056", 13238246),
        ["ne_10m_admin_0_countries_twn.geojson"] = ("0c2b48fe8901af2cbb8afae3481d2cdeff4479eb", 13224274),
        ["ne_10m_admin_0_countries_ukr.geojson"] = ("e0ae295012dd7bfb75e0fea1fce5aff554c1a065", 13223297),
        ["ne_10m_admin_0_countries_usa.geojson"] = ("3ff54a8e3c27f4163631b6bc9b479eee5263f01b", 13245274),
        ["ne_10m_admin_0_countries_vnm.geojson"] = ("cb9139cab88557f520669903efc77c16c9aced5b", 13221654),
        ["ne_10m_populated_places_simple.geojson"] = ("4da9c6b27b5cd41d7c930ea9cd0c1f84548b65fb", 4932147),
        ["ne_50m_admin_1_states_provinces.geojson"] = ("1a362ae0bfbe1f2768071e58a2905a5561039703", 2325694),
    };

    /// <summary>Countries (ISO 3166 alpha-2) with a point-of-view edition, and its file suffix.</summary>
    public static readonly IReadOnlyDictionary<string, string> PointsOfView = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
    {
        ["AR"] = "arg", ["BD"] = "bdg", ["BR"] = "bra", ["CN"] = "chn", ["DE"] = "deu", ["EG"] = "egy", ["ES"] = "esp", ["FR"] = "fra",
        ["GB"] = "gbr", ["GR"] = "grc", ["ID"] = "idn", ["IN"] = "ind", ["IL"] = "isr", ["IT"] = "ita", ["JP"] = "jpn", ["KR"] = "kor",
        ["MA"] = "mar", ["NP"] = "nep", ["NL"] = "nld", ["PK"] = "pak", ["PL"] = "pol", ["PT"] = "prt", ["PS"] = "pse", ["RU"] = "rus",
        ["SA"] = "sau", ["SE"] = "swe", ["TR"] = "tur", ["TW"] = "twn", ["UA"] = "ukr", ["US"] = "usa", ["VN"] = "vnm",
    };

    /// <summary>The countries file for a point of view (ISO alpha-2; null or unknown: the default edition).</summary>
    public static string CountriesFile(string? pointOfView)
        => pointOfView is not null && PointsOfView.TryGetValue(pointOfView, out var suffix) ? $"ne_10m_admin_0_countries_{suffix}.geojson" : DefaultCountriesFile;

    private static readonly ConcurrentDictionary<string, Lazy<Task<IReadOnlyList<GeoFeature>>>> Layers = new(StringComparer.OrdinalIgnoreCase);
    private static readonly SemaphoreSlim DownloadLock = new(1, 1);

    public string CacheDirectory { get; } = cacheDirectory;

    /// <summary>A parsed layer (downloaded and verified on first use; parsed once per process).</summary>
    public Task<IReadOnlyList<GeoFeature>> LayerAsync(string file, CancellationToken ct)
    {
        var key = Path.Combine(CacheDirectory, file);
        var lazy = Layers.GetOrAdd(key, _ => new Lazy<Task<IReadOnlyList<GeoFeature>>>(() => LoadAsync(file)));
        var task = lazy.Value;
        if (task.IsFaulted)
        {
            Layers.TryRemove(key, out _); // A failed download can be retried.
        }
        return task.WaitAsync(ct);
    }

    private async Task<IReadOnlyList<GeoFeature>> LoadAsync(string file)
    {
        var path = await EnsureFileAsync(file, CancellationToken.None);
        await using var stream = File.OpenRead(path);
        using var document = await JsonDocument.ParseAsync(stream, new JsonDocumentOptions { MaxDepth = 64 });
        var features = new List<GeoFeature>();
        foreach (var f in document.RootElement.GetProperty("features").EnumerateArray())
        {
            if (Parse(f) is { } feature)
            {
                features.Add(feature);
            }
        }
        return features;
    }

    /// <summary>The local path of a data file: downloaded from the pinned release and hash-checked when missing.</summary>
    public async Task<string> EnsureFileAsync(string file, CancellationToken ct)
    {
        if (!Pins.TryGetValue(file, out var pin))
        {
            throw new ValidationException($"Unknown map data file {file}.");
        }
        var path = Path.Combine(CacheDirectory, file);
        if (File.Exists(path))
        {
            return path;
        }
        await DownloadLock.WaitAsync(ct);
        try
        {
            if (File.Exists(path))
            {
                return path;
            }
            Directory.CreateDirectory(CacheDirectory);
            var client = http ?? SharedClient;
            byte[] bytes;
            try
            {
                bytes = await client.GetByteArrayAsync(BaseUrl + file, ct);
            }
            catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException && !ct.IsCancellationRequested)
            {
                throw new ToolException($"The map data ({file}) could not be downloaded from Natural Earth: {ex.Message}. Check the internet connection and try again.");
            }
            if (verify && (bytes.LongLength != pin.Size || GitBlobSha(bytes) != pin.Sha))
            {
                throw new ToolException($"The downloaded map data ({file}) does not match the published Natural Earth {Version} file, so it was not used.");
            }
            var temp = path + ".download";
            await File.WriteAllBytesAsync(temp, bytes, ct);
            File.Move(temp, path, overwrite: true);
            return path;
        }
        finally
        {
            DownloadLock.Release();
        }
    }

    private static readonly HttpClient SharedClient = new() { Timeout = TimeSpan.FromMinutes(4) };

    /// <summary>Git's blob hash: SHA-1 of "blob {size}\0" followed by the content.</summary>
    public static string GitBlobSha(byte[] content)
    {
        var header = Encoding.ASCII.GetBytes($"blob {content.LongLength}\0");
        using var sha = IncrementalHash.CreateHash(HashAlgorithmName.SHA1);
        sha.AppendData(header);
        sha.AppendData(content);
        return Convert.ToHexString(sha.GetHashAndReset()).ToLowerInvariant();
    }

    private static GeoFeature? Parse(JsonElement feature)
    {
        var props = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (feature.TryGetProperty("properties", out var p) && p.ValueKind == JsonValueKind.Object)
        {
            foreach (var prop in p.EnumerateObject())
            {
                props[prop.Name] = prop.Value.ValueKind switch
                {
                    JsonValueKind.String => prop.Value.GetString() ?? "",
                    JsonValueKind.Number => prop.Value.GetRawText(),
                    JsonValueKind.True => "true",
                    JsonValueKind.False => "false",
                    _ => "",
                };
            }
        }
        if (!feature.TryGetProperty("geometry", out var g) || g.ValueKind != JsonValueKind.Object)
        {
            return null;
        }
        var type = g.GetProperty("type").GetString();
        var coords = g.GetProperty("coordinates");
        double w = double.MaxValue, s = double.MaxValue, e = double.MinValue, n = double.MinValue;
        double[] Ring(JsonElement ring)
        {
            var list = new double[ring.GetArrayLength() * 2];
            var i = 0;
            foreach (var pt in ring.EnumerateArray())
            {
                var x = pt[0].GetDouble();
                var y = pt[1].GetDouble();
                list[i++] = x;
                list[i++] = y;
                w = Math.Min(w, x); e = Math.Max(e, x); s = Math.Min(s, y); n = Math.Max(n, y);
            }
            return list;
        }
        switch (type)
        {
            case "Polygon":
                return new GeoFeature { Properties = props, Polygons = [coords.EnumerateArray().Select(Ring).ToList()], Bounds = Bounds() };
            case "MultiPolygon":
                return new GeoFeature { Properties = props, Polygons = coords.EnumerateArray().Select(poly => (IReadOnlyList<double[]>)poly.EnumerateArray().Select(Ring).ToList()).ToList(), Bounds = Bounds() };
            case "LineString":
                return new GeoFeature { Properties = props, Lines = [Ring(coords)], Bounds = Bounds() };
            case "MultiLineString":
                return new GeoFeature { Properties = props, Lines = coords.EnumerateArray().Select(Ring).ToList(), Bounds = Bounds() };
            case "Point":
                var (lon, lat) = (coords[0].GetDouble(), coords[1].GetDouble());
                return new GeoFeature { Properties = props, Point = (lon, lat), Bounds = (lon, lat, lon, lat) };
            default:
                return null;
        }
        (double, double, double, double) Bounds() => (w, s, e, n);
    }
}
