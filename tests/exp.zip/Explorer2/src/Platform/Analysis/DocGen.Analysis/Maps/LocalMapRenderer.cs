using System.Globalization;
using System.Net;
using System.Text;

namespace DocGen.Analysis.Maps;

public sealed record LocalMapResult(string Svg, int Width, int Height, IReadOnlyList<string> Places, IReadOnlyList<string> Landmarks,
    int Roads, int Waterways, IReadOnlyList<(double X, double Y, double W, double H)> Boxes);

/// <summary>
/// Draws the area around a place from OpenStreetMap features: water, rivers and streams, roads by importance,
/// railways, settlements and named landmarks, with the place itself marked. Labels never overlap (a label that does
/// not fit is left out). Nothing is drawn that is not in the data.
/// </summary>
public static class LocalMapRenderer
{
    private const double TitleBand = 58;
    private const double CaptionBand = 44;

    private static readonly Dictionary<string, (string Color, double Width, int Rank)> RoadStyles = new(StringComparer.OrdinalIgnoreCase)
    {
        ["motorway"] = ("#e8925b", 6, 7), ["trunk"] = ("#f0a35e", 5.5, 6), ["primary"] = ("#f5bf6b", 5, 5), ["secondary"] = ("#f8dc8f", 4.2, 4),
        ["tertiary"] = ("#ffffff", 3.6, 3), ["unclassified"] = ("#ffffff", 2.6, 2), ["residential"] = ("#ffffff", 2.4, 2),
        ["living_street"] = ("#ffffff", 2.2, 2), ["service"] = ("#ffffff", 1.4, 1), ["track"] = ("#c9b38a", 1.2, 0),
    };

    public static LocalMapResult Render(OsmPlace place, IReadOnlyList<OsmFeature> features, double radiusKm, string? title, string caption, int width = 1000)
    {
        width = Math.Clamp(width, 600, 2400);
        var mapSize = (double)width;
        var top = string.IsNullOrWhiteSpace(title) ? 12 : TitleBand;
        var height = (int)Math.Ceiling(top + mapSize + CaptionBand);
        var k = Math.Cos(place.Lat * Math.PI / 180);
        var scale = mapSize / 2 / (radiusKm / 111.32); // pixels per degree of latitude
        (double X, double Y) P(double lon, double lat) => (width / 2.0 + (lon - place.Lon) * k * scale, top + mapSize / 2 + (place.Lat - lat) * scale);

        var svg = new StringBuilder();
        svg.Append(CultureInfo.InvariantCulture, $"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 {width} {height}\" width=\"{width}\" height=\"{height}\" font-family=\"Segoe UI, Arial, sans-serif\">");
        svg.Append($"<title>{Esc(title ?? place.DisplayName)}</title>");
        svg.Append(CultureInfo.InvariantCulture, $"<rect width=\"{width}\" height=\"{height}\" fill=\"#ffffff\"/>");
        svg.Append(CultureInfo.InvariantCulture, $"<clipPath id=\"local\"><rect x=\"0\" y=\"{F(top)}\" width=\"{width}\" height=\"{F(mapSize)}\"/></clipPath>");
        svg.Append("<g clip-path=\"url(#local)\">");
        svg.Append(CultureInfo.InvariantCulture, $"<rect x=\"0\" y=\"{F(top)}\" width=\"{width}\" height=\"{F(mapSize)}\" fill=\"#f3efe6\"/>");

        string Path(IReadOnlyList<(double Lon, double Lat)> points, bool close)
        {
            var projected = points.Select(p => P(p.Lon, p.Lat)).ToList();
            var simplified = MapRenderer.Simplify(projected, 0.4);
            if (simplified.Count < 2)
            {
                return "";
            }
            var sb = new StringBuilder("M").Append(F(simplified[0].X)).Append(' ').Append(F(simplified[0].Y));
            foreach (var (x, y) in simplified.Skip(1))
            {
                sb.Append('L').Append(F(x)).Append(' ').Append(F(y));
            }
            return close ? sb.Append('Z').ToString() : sb.ToString();
        }

        // Water areas, then waterways, railways and roads (least important first, so main roads sit on top).
        foreach (var w in features.Where(f => f.IsWay && (f.Tag("natural") == "water" || f.Tag("landuse") == "reservoir")))
        {
            svg.Append($"<path d=\"{Path(w.Points, true)}\" fill=\"#aad3df\" stroke=\"#8cbcd0\" stroke-width=\"0.6\"/>");
        }
        var waterways = features.Where(f => f.IsWay && f.Tag("waterway").Length > 0).ToList();
        foreach (var w in waterways)
        {
            var width2 = w.Tag("waterway") switch { "river" => 4.0, "canal" => 2.6, "stream" => 1.4, _ => 1.0 };
            svg.Append($"<path d=\"{Path(w.Points, false)}\" fill=\"none\" stroke=\"#7fb6d4\" stroke-width=\"{F(width2)}\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>");
        }
        foreach (var r in features.Where(f => f.IsWay && f.Tag("railway") == "rail"))
        {
            var d = Path(r.Points, false);
            svg.Append($"<path d=\"{d}\" fill=\"none\" stroke=\"#8a8a8a\" stroke-width=\"3\"/><path d=\"{d}\" fill=\"none\" stroke=\"#ffffff\" stroke-width=\"1.6\" stroke-dasharray=\"6 6\"/>");
        }
        var roads = features.Where(f => f.IsWay && RoadStyles.ContainsKey(f.Tag("highway"))).OrderBy(f => RoadStyles[f.Tag("highway")].Rank).ToList();
        foreach (var r in roads)
        {
            var (_, w, _) = RoadStyles[r.Tag("highway")];
            svg.Append($"<path d=\"{Path(r.Points, false)}\" fill=\"none\" stroke=\"#b9b1a0\" stroke-width=\"{F(w + 1.6)}\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>");
        }
        foreach (var r in roads)
        {
            var (color, w, _) = RoadStyles[r.Tag("highway")];
            svg.Append($"<path d=\"{Path(r.Points, false)}\" fill=\"none\" stroke=\"{color}\" stroke-width=\"{F(w)}\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/>");
        }
        svg.Append("</g>");

        // Labels: the place itself, then settlements, then landmarks; none overlap.
        var placed = new List<(double X, double Y, double W, double H)> { (0, 0, width, top - 4), (0, height - CaptionBand, width, CaptionBand), (0, top + mapSize - 50, 260, 50) };
        bool TryPlace(double x, double y, double w, double h)
        {
            if (x < 2 || y < top + 2 || x + w > width - 2 || y + h > top + mapSize - 2 || placed.Any(r => x < r.X + r.W && x + w > r.X && y < r.Y + r.H && y + h > r.Y))
            {
                return false;
            }
            placed.Add((x, y, w, h));
            return true;
        }
        var labels = new StringBuilder();
        var (cx, cy) = P(place.Lon, place.Lat);
        var name = place.Address.TryGetValue(place.Type, out var own) && own.Length > 0 ? own : place.DisplayName.Split(',')[0];
        placed.Add((cx - 9, cy - 26, 18, 28));
        labels.Append($"<path d=\"M{F(cx)} {F(cy)} C{F(cx - 4)} {F(cy - 10)} {F(cx - 10)} {F(cy - 14)} {F(cx - 10)} {F(cy - 20)} A10 10 0 1 1 {F(cx + 10)} {F(cy - 20)} C{F(cx + 10)} {F(cy - 14)} {F(cx + 4)} {F(cy - 10)} {F(cx)} {F(cy)}Z\" fill=\"#c62828\" stroke=\"#ffffff\" stroke-width=\"1.5\"/><circle cx=\"{F(cx)}\" cy=\"{F(cy - 20)}\" r=\"3.5\" fill=\"#ffffff\"/>");
        var nameWidth = name.Length * 16 * 0.56;
        if (TryPlace(cx + 14, cy - 34, nameWidth, 18) || TryPlace(cx - 14 - nameWidth, cy - 34, nameWidth, 18))
        {
            var x = placed[^1].X;
            labels.Append($"<text x=\"{F(x)}\" y=\"{F(cy - 20)}\" font-size=\"16\" font-weight=\"700\" fill=\"#7f1d1d\" paint-order=\"stroke\" stroke=\"#ffffff\" stroke-width=\"4\" stroke-linejoin=\"round\">{Esc(name)}</text>");
        }

        var places = new List<string>();
        var rank = new Dictionary<string, int> { ["city"] = 6, ["town"] = 5, ["suburb"] = 4, ["village"] = 4, ["hamlet"] = 2, ["neighbourhood"] = 2, ["locality"] = 1 };
        foreach (var n in features.Where(f => !f.IsWay && f.Tag("place").Length > 0 && f.Tag("name").Length > 0).OrderByDescending(f => rank.GetValueOrDefault(f.Tag("place"))))
        {
            var label = n.Tag("name:en") is { Length: > 0 } en ? en : n.Tag("name");
            if (string.Equals(label, name, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }
            var (x, y) = P(n.Points[0].Lon, n.Points[0].Lat);
            var size = rank.GetValueOrDefault(n.Tag("place")) >= 4 ? 14.0 : 12.0;
            var w = label.Length * size * 0.56;
            if (TryPlace(x - w / 2, y - size / 2, w, size + 2))
            {
                labels.Append($"<text x=\"{F(x)}\" y=\"{F(y + size * 0.38)}\" font-size=\"{F(size)}\" font-weight=\"600\" text-anchor=\"middle\" fill=\"#3d3a33\" paint-order=\"stroke\" stroke=\"#f3efe6\" stroke-width=\"3.5\" stroke-linejoin=\"round\">{Esc(label)}</text>");
                places.Add(label);
            }
        }

        var landmarks = new List<string>();
        foreach (var n in features.Where(f => !f.IsWay && f.Tag("name").Length > 0 && (f.Tag("amenity").Length > 0 || f.Tag("railway") == "station")))
        {
            var label = n.Tag("name:en") is { Length: > 0 } en ? en : n.Tag("name");
            var (x, y) = P(n.Points[0].Lon, n.Points[0].Lat);
            var w = label.Length * 10.5 * 0.56;
            if (TryPlace(x - 4, y - 4, 8, 8) && (TryPlace(x + 7, y - 7, w, 13) || TryPlace(x - 7 - w, y - 7, w, 13)))
            {
                var anchorRight = placed[^1].X > x;
                labels.Append($"<circle cx=\"{F(x)}\" cy=\"{F(y)}\" r=\"3.5\" fill=\"#6a4c93\" stroke=\"#ffffff\" stroke-width=\"1\"/>");
                labels.Append($"<text x=\"{F(anchorRight ? x + 7 : x - 7)}\" y=\"{F(y + 4)}\" font-size=\"10.5\" text-anchor=\"{(anchorRight ? "start" : "end")}\" fill=\"#4a3470\" paint-order=\"stroke\" stroke=\"#f3efe6\" stroke-width=\"3\" stroke-linejoin=\"round\">{Esc(label)}</text>");
                landmarks.Add(label);
            }
        }
        svg.Append(labels);

        // Scale, north arrow, title, source.
        var pxPerKm = scale / 111.32;
        var barKm = new[] { 0.1, 0.2, 0.25, 0.5, 1, 2, 5 }.FirstOrDefault(v => v * pxPerKm >= width * 0.12, 5);
        var barPx = barKm * pxPerKm;
        var by = top + mapSize - 22;
        svg.Append(CultureInfo.InvariantCulture, $"<g fill=\"#34495e\" font-size=\"11\"><rect x=\"18\" y=\"{F(by - 16)}\" width=\"{F(barPx + 50)}\" height=\"28\" rx=\"4\" fill=\"#ffffff\" fill-opacity=\"0.85\"/>" +
            $"<rect x=\"26\" y=\"{F(by)}\" width=\"{F(barPx)}\" height=\"4\"/><text x=\"26\" y=\"{F(by - 4)}\">0</text><text x=\"{F(26 + barPx)}\" y=\"{F(by - 4)}\" text-anchor=\"middle\">{(barKm < 1 ? $"{barKm * 1000:0} m" : $"{barKm:0} km")}</text></g>");
        svg.Append($"<g transform=\"translate({F(width - 34)} {F(top + 16)})\"><path d=\"M0 0 L9 26 L0 20 L-9 26 Z\" fill=\"#34495e\"/><text x=\"0\" y=\"42\" font-size=\"12\" text-anchor=\"middle\" fill=\"#34495e\">N</text></g>");
        if (!string.IsNullOrWhiteSpace(title))
        {
            svg.Append($"<text x=\"20\" y=\"38\" font-size=\"24\" font-weight=\"600\" fill=\"#1f2430\">{Esc(title)}</text>");
        }
        var lines = WrapCaption(caption, width);
        for (var i = 0; i < lines.Count; i++)
        {
            svg.Append($"<text x=\"20\" y=\"{F(height - CaptionBand + 16 + i * 15)}\" font-size=\"11\" fill=\"#5b6272\">{Esc(lines[i])}</text>");
        }
        svg.Append("</svg>");
        return new LocalMapResult(svg.ToString(), width, height, places, landmarks, roads.Count, waterways.Count, placed.Skip(3).ToList());
    }

    private static List<string> WrapCaption(string caption, int width)
    {
        var max = (int)((width - 40) / (11 * 0.52));
        var lines = new List<string>();
        var line = new StringBuilder();
        foreach (var word in caption.Split(' '))
        {
            if (line.Length + word.Length + 1 > max && line.Length > 0)
            {
                lines.Add(line.ToString());
                line.Clear();
            }
            line.Append(line.Length > 0 ? " " : "").Append(word);
        }
        if (line.Length > 0)
        {
            lines.Add(line.ToString());
        }
        return lines.Take(2).ToList();
    }

    private static string F(double v) => v.ToString("0.#", CultureInfo.InvariantCulture);

    private static string Esc(string text) => WebUtility.HtmlEncode(text);
}
