using System.Globalization;
using System.Net;
using System.Text;
using DocGen.Core.Exceptions;

namespace DocGen.Analysis.Maps;

/// <summary>What to draw. Everything geographic comes from the data; the caller only chooses.</summary>
public sealed class MapSpec
{
    public string? Title { get; init; }

    /// <summary>Countries the map is about (names or ISO codes); the view fits them.</summary>
    public IReadOnlyList<string> Countries { get; init; } = [];

    /// <summary>A continent or region (Europe, Africa, South Asia…): all its countries, with a view that fits the region.</summary>
    public string? Region { get; init; }

    /// <summary>States/provinces the map is about (e.g. Rajasthan): the view fits them and the rest is shown as context.</summary>
    public IReadOnlyList<string> FocusStates { get; init; } = [];

    /// <summary>Optional view override: west, south, east, north (degrees).</summary>
    public (double West, double South, double East, double North)? Bounds { get; init; }

    /// <summary>Draw state/province borders and names for the subject countries.</summary>
    public bool States { get; init; } = true;

    /// <summary>States or countries to fill, by name, with a CSS colour.</summary>
    public IReadOnlyList<(string Name, string Color)> Highlights { get; init; } = [];

    /// <summary>none | capitals | major</summary>
    public string Cities { get; init; } = "major";

    /// <summary>Particular cities to mark (searched in the subject countries).</summary>
    public IReadOnlyList<string> CityNames { get; init; } = [];

    public int Width { get; init; } = 1000;

    /// <summary>ISO alpha-2 of the point of view used (null: the default Natural Earth edition).</summary>
    public string? PointOfView { get; init; }

    public string? PointOfViewName { get; init; }
}

/// <param name="Boxes">Every label and city marker on the map (x, y, width, height), for checks.</param>
public sealed record MapResult(string Svg, int Width, int Height, IReadOnlyList<string> Subjects, IReadOnlyList<string> Cities,
    int LabelsPlaced, int LabelsSkipped, IReadOnlyList<string> Notes, IReadOnlyList<(double X, double Y, double W, double H)> Boxes, string Caption);

/// <summary>
/// Draws a map as SVG from Natural Earth layers: an equirectangular projection scaled by the cosine of the middle
/// latitude (good for country and regional maps), outlines simplified to the output resolution, labels at the data's
/// own label points and city coordinates, placed greedily so that none overlap (a label that does not fit is left out
/// rather than drawn on top of another).
/// </summary>
public static class MapRenderer
{
    private const double TitleBand = 58;
    private const double CaptionBand = 40;

    public static MapResult Render(MapSpec spec, IReadOnlyList<GeoFeature> countries, IReadOnlyList<GeoFeature> states, IReadOnlyList<GeoFeature> places)
    {
        var notes = new List<string>();
        var subjects = spec.Countries.Select(name => FindCountry(countries, name)).ToList();
        (double, double, double, double)? regionView = null;
        if (spec.Region is { Length: > 0 } region)
        {
            var (members, view) = FindRegion(countries, region);
            subjects.AddRange(members);
            regionView = view;
        }
        var focus = spec.FocusStates.Select(name => FindState(states, subjects, name)).DistinctBy(s => s.Get("name") + s.Get("adm0_a3")).ToList();
        subjects.AddRange(focus.Select(s => FindCountry(countries, s.Get("adm0_a3"))));
        subjects = subjects.DistinctBy(c => c.Get("ADM0_A3")).ToList();
        if (subjects.Count == 0 && spec.Bounds is null)
        {
            throw new ValidationException("Name at least one country, region or state (or give bounds).");
        }
        var subjectCodes = subjects.Select(c => c.Get("ADM0_A3")).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var focusKeys = focus.Select(StateKey).ToHashSet(StringComparer.OrdinalIgnoreCase);

        var (west, south, east, north) = spec.Bounds ?? (focus.Count > 0 ? Union(focus.Select(f => f.Bounds)) : regionView ?? ViewOf(subjects));
        var padX = (east - west) * 0.04;
        var padY = (north - south) * 0.04;
        (west, east, south, north) = (west - padX, east + padX, Math.Max(-85, south - padY), Math.Min(85, north + padY));

        var k = Math.Cos((south + north) / 2 * Math.PI / 180);
        var width = Math.Clamp(spec.Width, 500, 2400);
        var scale = width / ((east - west) * k);
        var mapHeight = (north - south) * scale;
        var top = string.IsNullOrWhiteSpace(spec.Title) ? 12 : TitleBand;
        var height = (int)Math.Ceiling(top + mapHeight + CaptionBand);
        (double X, double Y) P(double lon, double lat) => ((lon - west) * k * scale, top + (north - lat) * scale);
        bool InView((double West, double South, double East, double North) b) => b.East >= west && b.West <= east && b.North >= south && b.South <= north;

        var svg = new StringBuilder();
        svg.Append(CultureInfo.InvariantCulture, $"<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 {width} {height}\" width=\"{width}\" height=\"{height}\" font-family=\"Segoe UI, Arial, sans-serif\">");
        svg.Append($"<title>{Esc(spec.Title ?? "Map")}</title>");
        svg.Append(CultureInfo.InvariantCulture, $"<rect width=\"{width}\" height=\"{height}\" fill=\"#ffffff\"/>");
        svg.Append(CultureInfo.InvariantCulture, $"<clipPath id=\"view\"><rect x=\"0\" y=\"{F(top)}\" width=\"{width}\" height=\"{F(mapHeight)}\"/></clipPath>");
        svg.Append(CultureInfo.InvariantCulture, $"<rect x=\"0\" y=\"{F(top)}\" width=\"{width}\" height=\"{F(mapHeight)}\" fill=\"#d5e8f5\"/>");
        svg.Append("<g clip-path=\"url(#view)\">");

        var highlight = spec.Highlights.ToDictionary(h => h.Name.Trim(), h => SafeColor(h.Color), StringComparer.OrdinalIgnoreCase);
        var matched = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        // Countries: neighbours first, subjects on top.
        foreach (var c in countries.Where(c => InView(c.Bounds)).OrderBy(c => subjectCodes.Contains(c.Get("ADM0_A3")) ? 1 : 0))
        {
            var isSubject = subjectCodes.Contains(c.Get("ADM0_A3"));
            var fill = Highlighted(c, highlight, matched, "NAME", "NAME_EN", "ADMIN", "ADM0_A3") ?? (isSubject && focus.Count == 0 ? "#f6ecd2" : isSubject ? "#efeadf" : "#ebe8e1");
            var d = PathOf(c.Polygons, P);
            if (d.Length > 0)
            {
                svg.Append($"<path d=\"{d}\" fill=\"{fill}\" stroke=\"{(isSubject ? "#6f5f4a" : "#a19b91")}\" stroke-width=\"{(isSubject ? "1.2" : "0.7")}\" stroke-linejoin=\"round\"/>");
            }
        }

        // States of the subject countries: highlighted fills, then the internal borders.
        var subjectStates = spec.States || highlight.Count > 0 || focus.Count > 0
            ? states.Where(s => subjectCodes.Contains(s.Get("adm0_a3")) && InView(s.Bounds)).ToList()
            : [];
        foreach (var s in subjectStates)
        {
            var color = Highlighted(s, highlight, matched, "name", "name_en") ?? (focusKeys.Contains(StateKey(s)) ? "#f6ecd2" : null);
            if (color is not null)
            {
                svg.Append($"<path d=\"{PathOf(s.Polygons, P)}\" fill=\"{color}\" stroke=\"none\"/>");
            }
        }
        if (spec.States)
        {
            // Only borders two states of the same country share: never a coastline, and never a line along a
            // disputed or de facto boundary (such as a line of control), which no two states share.
            foreach (var border in SharedBorders(subjectStates))
            {
                var d = LineOf(border, P);
                if (d.Length > 0)
                {
                    svg.Append($"<path d=\"{d}\" fill=\"none\" stroke=\"#b59f7c\" stroke-width=\"0.7\" stroke-linejoin=\"round\"/>");
                }
            }
        }
        // The focus states' own outline, drawn strongly on top.
        foreach (var f in focus)
        {
            svg.Append($"<path d=\"{PathOf(f.Polygons, P)}\" fill=\"none\" stroke=\"#6f5f4a\" stroke-width=\"1.6\" stroke-linejoin=\"round\"/>");
        }
        svg.Append("</g>");
        foreach (var name in highlight.Keys.Where(n => !matched.Contains(n)))
        {
            notes.Add($"\"{name}\" was not found among the countries and states on this map, so it is not highlighted.");
        }

        // Labels, most important first; a label that would overlap one already placed is left out.
        var placed = new List<(double X, double Y, double W, double H)> { (0, 0, width, top - 4), (0, height - CaptionBand, width, CaptionBand) };
        var labels = new StringBuilder();
        var skipped = 0;
        var citiesShown = new List<string>();
        bool TryPlace(double x, double y, double w, double h)
        {
            if (x < 2 || y < top + 2 || x + w > width - 2 || y + h > top + mapHeight - 2)
            {
                return false;
            }
            if (placed.Any(r => x < r.X + r.W && x + w > r.X && y < r.Y + r.H && y + h > r.Y))
            {
                return false;
            }
            placed.Add((x, y, w, h));
            return true;
        }

        // City markers are reserved first, so no label ever covers another city's dot.
        var cities = PickCities(spec, places, subjectCodes, focus).Where(c => c.Point!.Value.Lon >= west && c.Point.Value.Lon <= east && c.Point.Value.Lat >= south && c.Point.Value.Lat <= north).ToList();
        var dots = new List<(double X, double Y, double W, double H)>();
        foreach (var city in cities)
        {
            var (dx, dy) = P(city.Point!.Value.Lon, city.Point.Value.Lat);
            var box = (dx - 4, dy - 4, 8.0, 8.0);
            if (!dots.Any(d => box.Item1 < d.X + d.W && box.Item1 + 8 > d.X && box.Item2 < d.Y + d.H && box.Item2 + 8 > d.Y))
            {
                dots.Add(box);
            }
        }
        placed.AddRange(dots);
        foreach (var city in cities)
        {
            var (lon, lat) = city.Point!.Value;
            if (lon < west || lon > east || lat < south || lat > north)
            {
                continue;
            }
            var (x, y) = P(lon, lat);
            if (!dots.Any(d => Math.Abs(d.X + 4 - x) < 0.01 && Math.Abs(d.Y + 4 - y) < 0.01))
            {
                skipped++; // Its dot would sit on another city's dot.
                continue;
            }
            var capital = city.Get("adm0cap") == "1";
            var name = city.Get("name");
            var size = capital ? 13.0 : 11.5;
            var w = TextWidth(name, size) + (capital ? 4 : 0);
            var h = size + 2;
            var spots = new[] { (x + 6, y - h / 2, "start", x + 6), (x - 6 - w, y - h / 2, "end", x - 6), (x - w / 2, y - h - 5, "middle", x), (x - w / 2, y + 5, "middle", x) };
            var done = false;
            foreach (var (lx, ly, anchor, tx) in spots)
            {
                if (TryPlace(lx, ly, w, h))
                {
                    labels.Append(capital
                        ? $"<path d=\"{Star(x, y, 6.5)}\" fill=\"#b3261e\" stroke=\"#ffffff\" stroke-width=\"1\"/>"
                        : $"<circle cx=\"{F(x)}\" cy=\"{F(y)}\" r=\"3\" fill=\"#b3261e\" stroke=\"#ffffff\" stroke-width=\"1\"/>");
                    labels.Append($"<text x=\"{F(tx)}\" y=\"{F(ly + size * 0.88)}\" font-size=\"{F(size)}\" text-anchor=\"{anchor}\" fill=\"#5a1a14\"{(capital ? " font-weight=\"600\"" : "")} paint-order=\"stroke\" stroke=\"#ffffff\" stroke-width=\"3\" stroke-linejoin=\"round\">{Esc(name)}</text>");
                    citiesShown.Add(name);
                    done = true;
                    break;
                }
            }
            if (!done)
            {
                skipped++;
            }
        }

        if (spec.States)
        {
            foreach (var s in subjectStates.OrderByDescending(s => (s.Bounds.East - s.Bounds.West) * (s.Bounds.North - s.Bounds.South)))
            {
                if (!double.TryParse(s.Get("longitude"), NumberStyles.Float, CultureInfo.InvariantCulture, out var lon)
                    || !double.TryParse(s.Get("latitude"), NumberStyles.Float, CultureInfo.InvariantCulture, out var lat))
                {
                    continue;
                }
                var name = s.Get("name");
                var (x, y) = P(lon, lat);
                var fitted = false;
                // At the data's label point, then a little above, below or to either side, then smaller.
                foreach (var (size, ox, oy) in new[] { (11.0, 0.0, 0.0), (11.0, 0, -13), (11.0, 0, 13), (11.0, -24, 0), (11.0, 24, 0), (9.5, 0, 0), (9.5, 0, -11), (9.5, 0, 11) })
                {
                    var w = TextWidth(name, size);
                    var (cx, cy) = (x + ox, y + oy);
                    if (TryPlace(cx - w / 2, cy - size / 2, w, size + 1))
                    {
                        labels.Append($"<text x=\"{F(cx)}\" y=\"{F(cy + size * 0.38)}\" font-size=\"{F(size)}\" text-anchor=\"middle\" fill=\"#6b5638\" paint-order=\"stroke\" stroke=\"#f6ecd2\" stroke-width=\"2.5\" stroke-linejoin=\"round\">{Esc(name)}</text>");
                        fitted = true;
                        break;
                    }
                }
                if (!fitted)
                {
                    skipped++;
                }
            }
        }

        foreach (var c in countries.Where(c => InView(c.Bounds)))
        {
            if (!double.TryParse(c.Get("LABEL_X"), NumberStyles.Float, CultureInfo.InvariantCulture, out var lon)
                || !double.TryParse(c.Get("LABEL_Y"), NumberStyles.Float, CultureInfo.InvariantCulture, out var lat)
                || lon < west || lon > east || lat < south || lat > north)
            {
                continue;
            }
            var isSubject = subjectCodes.Contains(c.Get("ADM0_A3"));
            if (isSubject && spec.States && subjects.Count == 1)
            {
                continue; // The title names the one subject country; state names fill its area.
            }
            var name = c.Get("NAME");
            var size = isSubject ? 16.0 : 12.0;
            var w = TextWidth(name.ToUpperInvariant(), size) + name.Length * 1.2;
            var (x, y) = P(lon, lat);
            if (TryPlace(x - w / 2, y - size / 2, w, size + 2))
            {
                labels.Append($"<text x=\"{F(x)}\" y=\"{F(y + size * 0.38)}\" font-size=\"{F(size)}\" text-anchor=\"middle\" letter-spacing=\"1.2\" fill=\"{(isSubject ? "#4a3c28" : "#7c776e")}\" font-weight=\"{(isSubject ? "600" : "500")}\">{Esc(name.ToUpperInvariant())}</text>");
            }
        }
        svg.Append(labels);

        // Title, scale bar, north arrow, source and point of view.
        if (!string.IsNullOrWhiteSpace(spec.Title))
        {
            svg.Append($"<text x=\"20\" y=\"38\" font-size=\"24\" font-weight=\"600\" fill=\"#1f2430\">{Esc(spec.Title)}</text>");
        }
        var kmPerPx = 111.32 / scale;
        var barKm = NiceKm(kmPerPx * width * 0.18);
        var barPx = barKm / kmPerPx;
        var by = top + mapHeight - 22;
        svg.Append(CultureInfo.InvariantCulture, $"<g fill=\"#34495e\" font-size=\"11\"><rect x=\"18\" y=\"{F(by - 16)}\" width=\"{F(barPx + 44)}\" height=\"28\" rx=\"4\" fill=\"#ffffff\" fill-opacity=\"0.75\"/>" +
            $"<rect x=\"26\" y=\"{F(by)}\" width=\"{F(barPx)}\" height=\"4\"/><text x=\"26\" y=\"{F(by - 4)}\">0</text><text x=\"{F(26 + barPx)}\" y=\"{F(by - 4)}\" text-anchor=\"middle\">{barKm:N0} km</text></g>");
        var ax = width - 34;
        svg.Append($"<g transform=\"translate({F(ax)} {F(top + 16)})\"><path d=\"M0 0 L9 26 L0 20 L-9 26 Z\" fill=\"#34495e\"/><text x=\"0\" y=\"42\" font-size=\"12\" text-anchor=\"middle\" fill=\"#34495e\">N</text></g>");
        var showsIndia = countries.Any(c => c.Get("ADM0_A3") == "IND" && InView(c.Bounds));
        var caption = Caption(spec, showsIndia);
        svg.Append($"<text x=\"20\" y=\"{F(height - 16)}\" font-size=\"11\" fill=\"#5b6272\">{Esc(caption)}</text>");
        svg.Append("</svg>");

        return new MapResult(svg.ToString(), width, height, subjects.Select(s => s.Get("NAME")).ToList(), citiesShown, placed.Count - 2 - dots.Count, skipped, notes, placed.Skip(2).ToList(), caption);
    }

    /// <summary>Where the boundaries come from and whose view they follow (always on the map).</summary>
    /// <param name="showsIndia">India is on the map: an India view then names the Survey of India as the official source.</param>
    public static string Caption(MapSpec spec, bool showsIndia = true)
    {
        var source = $"Map data: Natural Earth {NaturalEarth.Version} (public domain).";
        if (spec.PointOfView is null)
        {
            return source + " Boundaries as Natural Earth draws them (de facto control); some are disputed. Not an official map.";
        }
        var view = $" Boundaries from the point of view of {spec.PointOfViewName ?? spec.PointOfView}.";
        return showsIndia && spec.PointOfView.Equals("IN", StringComparison.OrdinalIgnoreCase)
            ? source + view + " Not an official map: the Survey of India publishes India's authoritative boundaries."
            : source + view + " Not an official map.";
    }

    private static string StateKey(GeoFeature s) => s.Get("adm0_a3") + "/" + s.Get("name");

    private static (double, double, double, double) Union(IEnumerable<(double West, double South, double East, double North)> boxes)
    {
        var list = boxes.ToList();
        return (list.Min(b => b.West), list.Min(b => b.South), list.Max(b => b.East), list.Max(b => b.North));
    }

    /// <summary>Views for continents: whole transcontinental countries (Russia, France with its overseas parts) would stretch them.</summary>
    private static readonly Dictionary<string, (double, double, double, double)> RegionViews = new(StringComparer.OrdinalIgnoreCase)
    {
        ["Europe"] = (-25, 34, 45, 71.5), ["Africa"] = (-26, -36, 56, 38.5), ["Asia"] = (25, -12, 150, 56), ["South America"] = (-93, -57, -30, 14),
        ["North America"] = (-170, 5, -50, 84), ["Oceania"] = (110, -50, 180, 5), ["Southern Asia"] = (60, 4, 98, 40), ["South Asia"] = (60, 4, 98, 40),
        ["Middle East"] = (24, 11, 64, 43), ["Western Asia"] = (24, 11, 64, 43), ["South-Eastern Asia"] = (92, -12, 142, 29), ["Southeast Asia"] = (92, -12, 142, 29),
        ["Eastern Asia"] = (73, 18, 150, 54), ["East Asia"] = (73, 18, 150, 54), ["Central Asia"] = (46, 35, 88, 56),
    };

    private static readonly Dictionary<string, string> RegionAliases = new(StringComparer.OrdinalIgnoreCase)
    {
        ["South Asia"] = "Southern Asia", ["Southeast Asia"] = "South-Eastern Asia", ["East Asia"] = "Eastern Asia", ["Middle East"] = "Western Asia",
    };

    /// <summary>The countries of a continent or UN subregion (Natural Earth's CONTINENT, REGION_UN and SUBREGION fields).</summary>
    public static (List<GeoFeature> Members, (double, double, double, double)? View) FindRegion(IReadOnlyList<GeoFeature> countries, string region)
    {
        var name = RegionAliases.GetValueOrDefault(region.Trim(), region.Trim());
        var members = countries.Where(c => new[] { "CONTINENT", "REGION_UN", "SUBREGION" }.Any(k => string.Equals(c.Get(k), name, StringComparison.OrdinalIgnoreCase))).ToList();
        if (members.Count == 0)
        {
            var known = countries.SelectMany(c => new[] { c.Get("CONTINENT"), c.Get("SUBREGION") }).Where(n => n.Length > 0).Distinct().Order();
            throw new ValidationException($"No region called \"{region}\" in the map data. Regions: {string.Join(", ", known)}.");
        }
        return (members, RegionViews.TryGetValue(region.Trim(), out var view) || RegionViews.TryGetValue(name, out view) ? view : null);
    }

    /// <summary>A state/province by name (English or local), in the given countries if any are named.</summary>
    public static GeoFeature FindState(IReadOnlyList<GeoFeature> states, IReadOnlyList<GeoFeature> countries, string name)
    {
        var codes = countries.Select(c => c.Get("ADM0_A3")).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var n = name.Trim();
        var candidates = states.Where(s => codes.Count == 0 || codes.Contains(s.Get("adm0_a3"))).ToList();
        var match = candidates.FirstOrDefault(s => new[] { "name", "name_en", "name_alt", "postal", "iso_3166_2" }
            .Any(k => s.Get(k).Split('|').Any(v => string.Equals(v.Trim(), n, StringComparison.OrdinalIgnoreCase))));
        if (match is not null)
        {
            return match;
        }
        var similar = candidates.Where(s => Similar(s.Get("name"), n)).Select(s => s.Get("name")).Take(5).ToList();
        throw new ValidationException($"No state or province called \"{n}\" in the map data." + (similar.Count > 0 ? $" Did you mean: {string.Join(", ", similar)}?" : ""));
    }

    /// <summary>Close spellings ("Rajastan" → Rajasthan): same first letter and at most two letters different.</summary>
    private static bool Similar(string a, string b)
    {
        if (a.Length == 0 || b.Length == 0 || char.ToLowerInvariant(a[0]) != char.ToLowerInvariant(b[0]))
        {
            return false;
        }
        a = a.ToLowerInvariant();
        b = b.ToLowerInvariant();
        var d = new int[a.Length + 1, b.Length + 1];
        for (var i = 0; i <= a.Length; i++) d[i, 0] = i;
        for (var j = 0; j <= b.Length; j++) d[0, j] = j;
        for (var i = 1; i <= a.Length; i++)
        {
            for (var j = 1; j <= b.Length; j++)
            {
                d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1), d[i - 1, j - 1] + (a[i - 1] == b[j - 1] ? 0 : 1));
            }
        }
        return d[a.Length, b.Length] <= 2;
    }

    public static GeoFeature FindCountry(IReadOnlyList<GeoFeature> countries, string name)
    {
        var n = name.Trim();
        var match = countries.FirstOrDefault(c => new[] { "ADM0_A3", "ISO_A3", "ISO_A2", "NAME", "NAME_EN", "NAME_LONG", "ADMIN", "FORMAL_EN" }
            .Any(k => string.Equals(c.Get(k), n, StringComparison.OrdinalIgnoreCase)));
        if (match is not null)
        {
            return match;
        }
        var similar = countries.Where(c => c.Get("NAME").Contains(n, StringComparison.OrdinalIgnoreCase) || n.Contains(c.Get("NAME"), StringComparison.OrdinalIgnoreCase))
            .Select(c => c.Get("NAME")).Where(s => s.Length > 0).Take(5).ToList();
        throw new ValidationException($"No country called \"{n}\" in the map data." + (similar.Count > 0 ? $" Did you mean: {string.Join(", ", similar)}?" : " Use the English name or ISO code."));
    }

    /// <summary>The view for the subjects: their main land plus parts near it (far territories do not stretch the map).</summary>
    private static (double, double, double, double) ViewOf(IReadOnlyList<GeoFeature> subjects)
    {
        double w = double.MaxValue, s = double.MaxValue, e = double.MinValue, n = double.MinValue;
        foreach (var c in subjects)
        {
            var polys = c.Polygons.Select(p => (Poly: p, Box: RingBounds(p[0]))).ToList();
            var main = polys.MaxBy(p => (p.Box.E - p.Box.W) * (p.Box.N - p.Box.S));
            var reach = Math.Max(main.Box.E - main.Box.W, main.Box.N - main.Box.S) * 0.45;
            foreach (var (_, b) in polys.Where(p => p.Box.W <= main.Box.E + reach && p.Box.E >= main.Box.W - reach && p.Box.S <= main.Box.N + reach && p.Box.N >= main.Box.S - reach))
            {
                (w, s, e, n) = (Math.Min(w, b.W), Math.Min(s, b.S), Math.Max(e, b.E), Math.Max(n, b.N));
            }
        }
        return (w, s, e, n);
    }

    private static (double W, double S, double E, double N) RingBounds(double[] ring)
    {
        double w = double.MaxValue, s = double.MaxValue, e = double.MinValue, n = double.MinValue;
        for (var i = 0; i < ring.Length; i += 2)
        {
            (w, e) = (Math.Min(w, ring[i]), Math.Max(e, ring[i]));
            (s, n) = (Math.Min(s, ring[i + 1]), Math.Max(n, ring[i + 1]));
        }
        return (w, s, e, n);
    }

    private static IEnumerable<GeoFeature> PickCities(MapSpec spec, IReadOnlyList<GeoFeature> places, HashSet<string> subjects, IReadOnlyList<GeoFeature> focus)
    {
        // With focus states, their own cities (the data records each city's state).
        var focusNames = focus.SelectMany(f => new[] { f.Get("name"), f.Get("name_en") }).Where(n => n.Length > 0).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var inSubjects = places.Where(p => subjects.Contains(p.Get("adm0_a3")) && (focusNames.Count == 0 || focusNames.Contains(p.Get("adm1name"))));
        double Pop(GeoFeature p) => double.TryParse(p.Get("pop_max"), NumberStyles.Float, CultureInfo.InvariantCulture, out var v) ? v : 0;
        var chosen = new List<GeoFeature>();
        foreach (var name in spec.CityNames)
        {
            var hit = inSubjects.Where(p => string.Equals(p.Get("name"), name.Trim(), StringComparison.OrdinalIgnoreCase)
                                            || string.Equals(p.Get("nameascii"), name.Trim(), StringComparison.OrdinalIgnoreCase)
                                            || p.Get("namealt").Split('|').Any(a => string.Equals(a.Trim(), name.Trim(), StringComparison.OrdinalIgnoreCase)))
                .MaxBy(Pop);
            if (hit is not null)
            {
                chosen.Add(hit);
            }
        }
        var mode = spec.Cities.ToLowerInvariant();
        if (mode != "none")
        {
            chosen.AddRange(inSubjects.Where(p => p.Get("adm0cap") == "1" || (focusNames.Count > 0 && p.Get("featurecla").Contains("Admin-1 capital", StringComparison.OrdinalIgnoreCase))));
            // State capitals only on maps of one or a few countries (a continent would get hundreds).
            if (mode == "capitals" && (subjects.Count <= 3 || focusNames.Count > 0))
            {
                chosen.AddRange(inSubjects.Where(p => p.Get("featurecla").Contains("Admin-1 capital", StringComparison.OrdinalIgnoreCase)).OrderByDescending(Pop));
            }
            else if (mode == "major")
            {
                chosen.AddRange(inSubjects.OrderByDescending(Pop).Take(Math.Min(30, 12 * Math.Max(1, subjects.Count))));
            }
        }
        // Capitals first, then by population; placement order is priority order.
        return chosen.DistinctBy(p => p.Get("name") + p.Get("adm0_a3")).OrderByDescending(p => p.Get("adm0cap") == "1").ThenByDescending(Pop);
    }

    /// <summary>
    /// The edges shared by two of the given state polygons, chained into lines (each edge once). Natural Earth builds
    /// neighbouring states from the same vertices, so a shared border is a run of identical edges.
    /// </summary>
    public static List<double[]> SharedBorders(IReadOnlyList<GeoFeature> states)
    {
        static (long, long, long, long) Key(double ax, double ay, double bx, double by)
        {
            var (a1, a2, b1, b2) = ((long)Math.Round(ax * 1e6), (long)Math.Round(ay * 1e6), (long)Math.Round(bx * 1e6), (long)Math.Round(by * 1e6));
            return a1 < b1 || (a1 == b1 && a2 <= b2) ? (a1, a2, b1, b2) : (b1, b2, a1, a2);
        }
        var count = new Dictionary<(long, long, long, long), int>();
        var rings = states.SelectMany(s => s.Polygons).SelectMany(p => p).ToList();
        foreach (var ring in rings)
        {
            for (var i = 0; i + 3 < ring.Length; i += 2)
            {
                var key = Key(ring[i], ring[i + 1], ring[i + 2], ring[i + 3]);
                count[key] = count.GetValueOrDefault(key) + 1;
            }
        }
        var drawn = new HashSet<(long, long, long, long)>();
        var lines = new List<double[]>();
        foreach (var ring in rings)
        {
            var current = new List<double>();
            for (var i = 0; i + 3 < ring.Length; i += 2)
            {
                var key = Key(ring[i], ring[i + 1], ring[i + 2], ring[i + 3]);
                if (count[key] >= 2 && drawn.Add(key))
                {
                    if (current.Count == 0)
                    {
                        current.Add(ring[i]);
                        current.Add(ring[i + 1]);
                    }
                    current.Add(ring[i + 2]);
                    current.Add(ring[i + 3]);
                }
                else if (current.Count > 0)
                {
                    lines.Add([.. current]);
                    current.Clear();
                }
            }
            if (current.Count > 0)
            {
                lines.Add([.. current]);
            }
        }
        return lines;
    }

    private static string? Highlighted(GeoFeature f, Dictionary<string, string> highlight, HashSet<string> matched, params string[] keys)
    {
        foreach (var key in keys)
        {
            var value = f.Get(key);
            if (value.Length > 0 && highlight.TryGetValue(value, out var color))
            {
                matched.Add(value);
                return color;
            }
        }
        return null;
    }

    /// <summary>Only plain colours reach the SVG (no url(), quotes or markup from the request).</summary>
    private static string SafeColor(string color)
    {
        var c = color.Trim();
        return System.Text.RegularExpressions.Regex.IsMatch(c, "^(#[0-9a-fA-F]{3,8}|[a-zA-Z]{3,20})$") ? c : "#f4c56a";
    }

    private static string PathOf(IReadOnlyList<IReadOnlyList<double[]>> polygons, Func<double, double, (double X, double Y)> project)
    {
        var sb = new StringBuilder();
        foreach (var polygon in polygons)
        {
            foreach (var ring in polygon)
            {
                var points = Simplify(Project(ring, project), 0.35);
                if (points.Count < 3 || Extent(points) < 0.8)
                {
                    continue;
                }
                sb.Append('M').Append(F(points[0].X)).Append(' ').Append(F(points[0].Y));
                for (var i = 1; i < points.Count; i++)
                {
                    sb.Append('L').Append(F(points[i].X)).Append(' ').Append(F(points[i].Y));
                }
                sb.Append('Z');
            }
        }
        return sb.ToString();
    }

    private static string LineOf(double[] line, Func<double, double, (double X, double Y)> project)
    {
        var points = Simplify(Project(line, project), 0.35);
        if (points.Count < 2)
        {
            return "";
        }
        var sb = new StringBuilder();
        sb.Append('M').Append(F(points[0].X)).Append(' ').Append(F(points[0].Y));
        for (var i = 1; i < points.Count; i++)
        {
            sb.Append('L').Append(F(points[i].X)).Append(' ').Append(F(points[i].Y));
        }
        return sb.ToString();
    }

    private static List<(double X, double Y)> Project(double[] ring, Func<double, double, (double X, double Y)> project)
    {
        var list = new List<(double X, double Y)>(ring.Length / 2);
        for (var i = 0; i < ring.Length; i += 2)
        {
            list.Add(project(ring[i], ring[i + 1]));
        }
        return list;
    }

    private static double Extent(List<(double X, double Y)> points)
        => Math.Max(points.Max(p => p.X) - points.Min(p => p.X), points.Max(p => p.Y) - points.Min(p => p.Y));

    /// <summary>Douglas–Peucker in pixels: drops detail the output cannot show.</summary>
    public static List<(double X, double Y)> Simplify(List<(double X, double Y)> points, double tolerance)
    {
        if (points.Count < 3)
        {
            return points;
        }
        var keep = new bool[points.Count];
        keep[0] = keep[^1] = true;
        var stack = new Stack<(int, int)>();
        stack.Push((0, points.Count - 1));
        while (stack.Count > 0)
        {
            var (a, b) = stack.Pop();
            double max = 0;
            var index = -1;
            for (var i = a + 1; i < b; i++)
            {
                var d = Distance(points[i], points[a], points[b]);
                if (d > max)
                {
                    (max, index) = (d, i);
                }
            }
            if (index >= 0 && max > tolerance)
            {
                keep[index] = true;
                stack.Push((a, index));
                stack.Push((index, b));
            }
        }
        return points.Where((_, i) => keep[i]).ToList();
    }

    private static double Distance((double X, double Y) p, (double X, double Y) a, (double X, double Y) b)
    {
        var (dx, dy) = (b.X - a.X, b.Y - a.Y);
        var length = dx * dx + dy * dy;
        if (length == 0)
        {
            return Math.Sqrt((p.X - a.X) * (p.X - a.X) + (p.Y - a.Y) * (p.Y - a.Y));
        }
        return Math.Abs(dy * p.X - dx * p.Y + b.X * a.Y - b.Y * a.X) / Math.Sqrt(length);
    }

    private static double TextWidth(string text, double size) => text.Length * size * 0.56;

    private static int NiceKm(double km)
    {
        foreach (var step in new[] { 10, 20, 25, 50, 100, 200, 250, 300, 500, 1000, 2000, 2500, 5000 })
        {
            if (step >= km * 0.7)
            {
                return step;
            }
        }
        return 5000;
    }

    private static string Star(double x, double y, double r)
    {
        var sb = new StringBuilder("M");
        for (var i = 0; i < 10; i++)
        {
            var angle = -Math.PI / 2 + i * Math.PI / 5;
            var radius = i % 2 == 0 ? r : r * 0.45;
            sb.Append(i == 0 ? "" : "L").Append(F(x + radius * Math.Cos(angle))).Append(' ').Append(F(y + radius * Math.Sin(angle)));
        }
        return sb.Append('Z').ToString();
    }

    private static string F(double v) => v.ToString("0.#", CultureInfo.InvariantCulture);

    private static string Esc(string text) => WebUtility.HtmlEncode(text);
}
