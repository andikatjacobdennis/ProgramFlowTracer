using System.Globalization;
using System.Net;
using System.Text.Json;
using DocGen.Core.Exceptions;

namespace DocGen.Analysis.Maps;

/// <summary>A place found by name: where it is and its address as OpenStreetMap records it.</summary>
public sealed record OsmPlace(string DisplayName, double Lat, double Lon, string Type, IReadOnlyDictionary<string, string> Address, string Category = "");

/// <summary>An OpenStreetMap feature near a place: a line/area (way) or a point (node), with its tags.</summary>
public sealed record OsmFeature(bool IsWay, IReadOnlyDictionary<string, string> Tags, IReadOnlyList<(double Lon, double Lat)> Points)
{
    public string Tag(string key) => Tags.TryGetValue(key, out var v) ? v : "";
}

/// <summary>
/// OpenStreetMap (© OpenStreetMap contributors, ODbL 1.0): finds a place by name (Nominatim) and fetches the mapped
/// roads, rivers, water, railways, settlements and landmarks around it (Overpass API). Real surveyed data, used for
/// village and town maps that country/state datasets are too coarse for. Only these two public services are contacted,
/// once per map, as their usage policies ask.
/// </summary>
public static class OpenStreetMap
{
    public const string Attribution = "Map data © OpenStreetMap contributors, ODbL 1.0 (openstreetmap.org/copyright).";
    private static readonly HttpClient Http = CreateClient();

    /// <summary>Places matching a name, best first; <paramref name="countryCode"/> (ISO alpha-2) narrows the search.</summary>
    public static async Task<IReadOnlyList<OsmPlace>> FindAsync(string query, string? countryCode, CancellationToken ct)
    {
        var url = "https://nominatim.openstreetmap.org/search?format=jsonv2&addressdetails=1&limit=5&accept-language=en&q=" + Uri.EscapeDataString(query) +
                  (countryCode is { Length: 2 } ? "&countrycodes=" + countryCode.ToLowerInvariant() : "");
        using var doc = await GetJsonAsync(url, ct);
        var list = new List<OsmPlace>();
        foreach (var r in doc.RootElement.EnumerateArray())
        {
            var address = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            if (r.TryGetProperty("address", out var a) && a.ValueKind == JsonValueKind.Object)
            {
                foreach (var p in a.EnumerateObject())
                {
                    address[p.Name] = p.Value.ToString();
                }
            }
            list.Add(new OsmPlace(r.GetProperty("display_name").GetString() ?? "", Num(r.GetProperty("lat")), Num(r.GetProperty("lon")),
                r.TryGetProperty("type", out var t) ? t.GetString() ?? "" : "", address, r.TryGetProperty("category", out var cat) ? cat.GetString() ?? "" : ""));
        }
        // A settlement (village, locality…) or an administrative area before a pond, colony or shop that has the name in it.
        return list.OrderBy(p => p.Category is "place" or "boundary" ? 0 : 1).ToList();
    }

    /// <summary>Roads, waterways, water areas, railways, settlements and named landmarks within <paramref name="radiusMeters"/>.</summary>
    public static async Task<IReadOnlyList<OsmFeature>> AroundAsync(double lat, double lon, int radiusMeters, CancellationToken ct)
    {
        var around = FormattableString.Invariant($"around:{radiusMeters},{lat},{lon}");
        var query = $"""
            [out:json][timeout:60];
            (
              way["highway"~"^(motorway|trunk|primary|secondary|tertiary|unclassified|residential|living_street|service|track)$"]({around});
              way["waterway"~"^(river|stream|canal|drain|ditch)$"]({around});
              way["natural"="water"]({around});
              way["landuse"="reservoir"]({around});
              way["railway"="rail"]({around});
              node["place"~"^(city|town|village|hamlet|suburb|neighbourhood|locality)$"]({around});
              node["amenity"~"^(place_of_worship|school|college|university|hospital|clinic|police|post_office|townhall|bank)$"]["name"]({around});
              node["railway"="station"]["name"]({around});
            );
            out geom;
            """;
        using var response = await OverpassAsync(query, ct);
        await using var stream = await response.Content.ReadAsStreamAsync(ct);
        using var doc = await JsonDocument.ParseAsync(stream, cancellationToken: ct);
        var features = new List<OsmFeature>();
        foreach (var e in doc.RootElement.GetProperty("elements").EnumerateArray())
        {
            var tags = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            if (e.TryGetProperty("tags", out var t))
            {
                foreach (var p in t.EnumerateObject())
                {
                    tags[p.Name] = p.Value.GetString() ?? "";
                }
            }
            var type = e.GetProperty("type").GetString();
            if (type == "node")
            {
                features.Add(new OsmFeature(false, tags, [(Num(e.GetProperty("lon")), Num(e.GetProperty("lat")))]));
            }
            else if (type == "way" && e.TryGetProperty("geometry", out var g))
            {
                features.Add(new OsmFeature(true, tags, g.EnumerateArray().Select(p => (Num(p.GetProperty("lon")), Num(p.GetProperty("lat")))).ToList()));
            }
        }
        return features;
    }

    /// <summary>The public Overpass servers (same OpenStreetMap data): the main one, retried once when busy, then a mirror.</summary>
    private static readonly string[] OverpassServers = ["https://overpass-api.de/api/interpreter", "https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter"];

    private static async Task<HttpResponseMessage> OverpassAsync(string query, CancellationToken ct)
    {
        ToolException? last = null;
        foreach (var server in OverpassServers)
        {
            try
            {
                using var content = new FormUrlEncodedContent([new KeyValuePair<string, string>("data", query)]);
                return await SendAsync(() => Http.PostAsync(server, content, ct));
            }
            catch (ToolException ex)
            {
                last = ex;
                await Task.Delay(TimeSpan.FromSeconds(3), ct);
            }
        }
        throw last!;
    }

    private static async Task<JsonDocument> GetJsonAsync(string url, CancellationToken ct)
    {
        using var response = await SendAsync(() => Http.GetAsync(url, ct));
        return await JsonDocument.ParseAsync(await response.Content.ReadAsStreamAsync(ct), cancellationToken: ct);
    }

    private static async Task<HttpResponseMessage> SendAsync(Func<Task<HttpResponseMessage>> send)
    {
        HttpResponseMessage response;
        try
        {
            response = await send();
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            throw new ToolException($"OpenStreetMap could not be reached ({ex.Message}). Check the internet connection and try again.");
        }
        if (response.StatusCode is HttpStatusCode.TooManyRequests or HttpStatusCode.GatewayTimeout or HttpStatusCode.ServiceUnavailable)
        {
            response.Dispose();
            throw new ToolException("OpenStreetMap's servers are busy right now; try again in a minute.");
        }
        if (!response.IsSuccessStatusCode)
        {
            var code = (int)response.StatusCode;
            response.Dispose();
            throw new ToolException($"OpenStreetMap returned HTTP {code}.");
        }
        return response;
    }

    private static double Num(JsonElement e) => e.ValueKind == JsonValueKind.Number ? e.GetDouble() : double.Parse(e.GetString()!, CultureInfo.InvariantCulture);

    private static HttpClient CreateClient()
    {
        var client = new HttpClient(new SocketsHttpHandler { AllowAutoRedirect = false, AutomaticDecompression = DecompressionMethods.All }) { Timeout = TimeSpan.FromSeconds(90) };
        // Both services require an identifying User-Agent.
        client.DefaultRequestHeaders.UserAgent.ParseAdd("DocGen/1.0 (local AI assistant; map lookup)");
        return client;
    }
}
