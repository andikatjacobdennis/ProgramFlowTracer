using System.Collections.Concurrent;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using DocGen.Analysis.CSharp;
using DocGen.Analysis.Repositories;
using DocGen.Core.Options;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Indexing;

/// <summary>
/// Builds, updates and caches repository indexes. Updates are incremental: a file is re-read only when its size or
/// timestamp changed, and re-parsed only when its content hash changed; deleted files are removed. One update per
/// repository runs at a time. Queries use the cached <see cref="CodeIndex"/>, refreshed when older than
/// <see cref="FreshnessWindow"/> (a cheap metadata walk when nothing changed).
/// </summary>
public sealed class CodeIndexService(IndexStore store, IOptionsMonitor<AnalysisOptions> options, ILogger<CodeIndexService> logger)
{
    public static readonly TimeSpan FreshnessWindow = TimeSpan.FromSeconds(20);

    private static readonly HashSet<string> IndexedExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".cs", ".csproj", ".props", ".targets", ".sln", ".slnx", ".json", ".config", ".xml", ".razor", ".cshtml",
        ".md", ".yml", ".yaml", ".txt", ".sql", ".http", ".resx", ".editorconfig",
    };

    private readonly ConcurrentDictionary<string, (CodeIndex Index, DateTime CheckedAt)> _cache = new(StringComparer.Ordinal);
    private readonly ConcurrentDictionary<string, SemaphoreSlim> _locks = new(StringComparer.Ordinal);

    public async Task<CodeIndex> GetAsync(RepositoryHandle repo, CancellationToken ct, TimeSpan? maxAge = null)
    {
        if (_cache.TryGetValue(repo.IndexKey, out var cached) && DateTime.UtcNow - cached.CheckedAt < (maxAge ?? FreshnessWindow))
        {
            return cached.Index;
        }
        await UpdateAsync(repo, full: false, ct);
        return _cache[repo.IndexKey].Index;
    }

    /// <summary>The cached index without refreshing (null when never loaded or built).</summary>
    public async Task<IndexManifest?> GetManifestAsync(RepositoryHandle repo, CancellationToken ct)
        => _cache.TryGetValue(repo.IndexKey, out var cached) ? cached.Index.Manifest : await store.ReadManifestAsync(repo.IndexKey, ct);

    /// <summary>True when an index is loaded in memory (in use); retention never deletes those.</summary>
    public bool IsCached(string indexKey) => _cache.ContainsKey(indexKey);

    public void Invalidate(RepositoryHandle repo) => _cache.TryRemove(repo.IndexKey, out _);

    public async Task<IndexUpdateResult> UpdateAsync(RepositoryHandle repo, bool full, CancellationToken ct)
    {
        var gate = _locks.GetOrAdd(repo.IndexKey, _ => new SemaphoreSlim(1, 1));
        await gate.WaitAsync(ct);
        try
        {
            return await UpdateCoreAsync(repo, full, ct);
        }
        finally
        {
            gate.Release();
        }
    }

    private async Task<IndexUpdateResult> UpdateCoreAsync(RepositoryHandle repo, bool full, CancellationToken ct)
    {
        var sw = Stopwatch.StartNew();
        var opts = options.CurrentValue;
        var parallelism = Math.Clamp(opts.MaxParallelism, 1, 64);
        var root = Path.GetFullPath(repo.Root);
        var result = new IndexUpdateResult { Repository = repo.Name, Full = full };

        IndexManifest manifest;
        Dictionary<string, FileIndex> files;
        if (!full && _cache.TryGetValue(repo.IndexKey, out var cached))
        {
            manifest = cached.Index.Manifest;
            files = cached.Index.Files;
        }
        else
        {
            manifest = full ? null! : await store.ReadManifestAsync(repo.IndexKey, ct) ?? null!;
            if (manifest is not null && manifest.ParserVersion != IndexManifest.CurrentParserVersion)
            {
                logger.LogInformation("Index of {Repository} was built by parser version {Old}; rebuilding with version {New}", repo.Name, manifest.ParserVersion, IndexManifest.CurrentParserVersion);
                manifest = null!;
                full = true;
                result.Full = true;
            }
            files = manifest is null ? new(StringComparer.OrdinalIgnoreCase) : await store.ReadFilesAsync(repo.IndexKey, parallelism, ct);
            manifest ??= new IndexManifest();
            if (full)
            {
                files.Clear();
            }
        }
        // Work on copies so readers of the cached index never observe a half-updated state.
        files = new Dictionary<string, FileIndex>(files, StringComparer.OrdinalIgnoreCase);

        var excluded = new HashSet<string>(opts.ExcludedDirectories, StringComparer.OrdinalIgnoreCase);
        var discovered = Enumerate(root, excluded, ct).ToList();
        result.Scanned = discovered.Count;

        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var candidates = new List<(string Relative, FileInfo Info)>();
        foreach (var info in discovered)
        {
            var relative = ProjectParser.Relative(root, info.FullName);
            seen.Add(relative);
            if (files.TryGetValue(relative, out var existing) && existing.Size == info.Length && existing.LastWriteTicks == info.LastWriteTimeUtc.Ticks)
            {
                result.Unchanged++;
                continue;
            }
            candidates.Add((relative, info));
        }

        var changedBuckets = new ConcurrentBag<int>();
        var updates = new ConcurrentDictionary<string, FileIndex>(StringComparer.OrdinalIgnoreCase);
        var added = 0;
        var changed = 0;
        var touched = 0;
        await Parallel.ForEachAsync(candidates, new ParallelOptions { MaxDegreeOfParallelism = parallelism, CancellationToken = ct }, async (candidate, token) =>
        {
            byte[] bytes;
            try
            {
                bytes = await File.ReadAllBytesAsync(candidate.Info.FullName, token);
            }
            catch (IOException)
            {
                return; // Locked or vanished; picked up next time.
            }
            catch (UnauthorizedAccessException)
            {
                return;
            }
            var hash = Convert.ToHexString(SHA256.HashData(bytes))[..32].ToLowerInvariant();
            files.TryGetValue(candidate.Relative, out var existing);
            if (existing is not null && existing.Hash == hash)
            {
                // Touched but identical: keep the parse, refresh metadata.
                existing.LastWriteTicks = candidate.Info.LastWriteTimeUtc.Ticks;
                existing.Size = candidate.Info.Length;
                updates[candidate.Relative] = existing;
                changedBuckets.Add(IndexStore.BucketOf(candidate.Relative));
                Interlocked.Increment(ref touched);
                return;
            }
            var entry = IndexFile(candidate.Relative, bytes, opts.MaxIndexedFileBytes);
            entry.Hash = hash;
            entry.Size = candidate.Info.Length;
            entry.LastWriteTicks = candidate.Info.LastWriteTimeUtc.Ticks;
            updates[candidate.Relative] = entry;
            changedBuckets.Add(IndexStore.BucketOf(candidate.Relative));
            if (existing is null)
            {
                Interlocked.Increment(ref added);
            }
            else
            {
                Interlocked.Increment(ref changed);
            }
        });

        foreach (var (path, entry) in updates)
        {
            files[path] = entry;
        }
        foreach (var removed in files.Keys.Where(k => !seen.Contains(k)).ToList())
        {
            files.Remove(removed);
            changedBuckets.Add(IndexStore.BucketOf(removed));
            result.Removed++;
        }
        result.Added = added;
        result.Changed = changed;
        result.Unchanged += touched;

        // Projects and solutions are re-read every pass (cheap) so references and packages stay current.
        var central = ProjectParser.CentralVersions(root);
        manifest.Projects = files.Keys.Where(k => k.EndsWith(".csproj", StringComparison.OrdinalIgnoreCase))
            .Select(k => ProjectParser.ParseProject(Path.Combine(root, k), root, central))
            .OrderBy(p => p.Path, StringComparer.OrdinalIgnoreCase).ToList();
        manifest.Solutions = files.Keys.Where(k => k.EndsWith(".sln", StringComparison.OrdinalIgnoreCase) || k.EndsWith(".slnx", StringComparison.OrdinalIgnoreCase))
            .Select(k => ProjectParser.ParseSolution(Path.Combine(root, k), root)).ToList();
        manifest.Repository = repo.Name;
        manifest.ParserVersion = IndexManifest.CurrentParserVersion;
        manifest.Root = root;
        manifest.Files = files.ToDictionary(f => f.Key, f => f.Value.Hash, StringComparer.OrdinalIgnoreCase);
        manifest.LastIndexedAt = DateTime.UtcNow;

        var index = new CodeIndex(manifest, files, root);
        manifest.Stats = new IndexStats
        {
            Files = files.Count,
            ParsedFiles = files.Values.Count(f => f.Parsed),
            Symbols = index.Symbols.Count,
            Types = index.Symbols.Count(s => SymbolKinds.IsType(s.Kind)),
            Projects = manifest.Projects.Count,
            Relationships = index.Relationships,
            SourceBytes = files.Values.Sum(f => f.Size),
        };
        manifest.LastDurationMs = sw.ElapsedMilliseconds;
        result.Stats = manifest.Stats;

        var bucketList = full ? Enumerable.Range(0, 256).ToList() : changedBuckets.Distinct().ToList();
        if (bucketList.Count > 0 || full || !File.Exists(Path.Combine(store.DirectoryFor(repo.IndexKey), "manifest.json")))
        {
            await store.WriteBucketsAsync(repo.IndexKey, bucketList, files, ct);
            await store.WriteManifestAsync(repo.IndexKey, manifest, ct);
        }
        _cache[repo.IndexKey] = (index, DateTime.UtcNow);
        result.DurationMs = sw.ElapsedMilliseconds;
        if (result.Added + result.Changed + result.Removed > 0 || full)
        {
            logger.LogInformation("Indexed repository {Repository}: {Added} added, {Changed} changed, {Removed} removed, {Unchanged} unchanged, {Symbols} symbols in {DurationMs} ms",
                repo.Name, result.Added, result.Changed, result.Removed, result.Unchanged, manifest.Stats.Symbols, result.DurationMs);
        }
        return result;
    }

    internal static FileIndex IndexFile(string relative, byte[] bytes, long maxParseBytes)
    {
        var extension = Path.GetExtension(relative);
        var fileName = Path.GetFileName(relative);
        if (bytes.Length > maxParseBytes || bytes.AsSpan(0, Math.Min(bytes.Length, 8000)).IndexOf((byte)0) >= 0)
        {
            return new FileIndex { Path = relative, Language = "other", Parsed = false };
        }
        var text = Encoding.UTF8.GetString(bytes);
        var lines = CountLines(text);
        if (extension.Equals(".cs", StringComparison.OrdinalIgnoreCase))
        {
            var parsed = CSharpParser.Parse(text, relative);
            parsed.Lines = lines;
            return parsed;
        }
        if (extension.Equals(".json", StringComparison.OrdinalIgnoreCase) && fileName.StartsWith("appsettings", StringComparison.OrdinalIgnoreCase))
        {
            return new FileIndex { Path = relative, Language = "json", Parsed = true, Lines = lines, ConfigKeys = ProjectParser.FlattenConfiguration(text) };
        }
        return new FileIndex
        {
            Path = relative,
            Language = extension.Equals(".csproj", StringComparison.OrdinalIgnoreCase) ? "csproj" : extension.TrimStart('.').ToLowerInvariant(),
            Parsed = false,
            Lines = lines,
        };
    }

    private static int CountLines(string text)
    {
        var count = 1;
        foreach (var c in text.AsSpan())
        {
            if (c == '\n')
            {
                count++;
            }
        }
        return count;
    }

    /// <summary>Walks the tree, skipping excluded and hidden directories and never following links.</summary>
    internal static IEnumerable<FileInfo> Enumerate(string root, HashSet<string> excluded, CancellationToken ct)
    {
        var stack = new Stack<DirectoryInfo>();
        stack.Push(new DirectoryInfo(root));
        var enumeration = new EnumerationOptions { RecurseSubdirectories = false, AttributesToSkip = FileAttributes.ReparsePoint | FileAttributes.System, IgnoreInaccessible = true };
        while (stack.Count > 0)
        {
            ct.ThrowIfCancellationRequested();
            var dir = stack.Pop();
            IEnumerable<FileSystemInfo> entries;
            try
            {
                entries = dir.EnumerateFileSystemInfos("*", enumeration).ToList();
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                continue;
            }
            foreach (var entry in entries)
            {
                if (entry is DirectoryInfo sub)
                {
                    if (!excluded.Contains(sub.Name) && !sub.Name.StartsWith('.'))
                    {
                        stack.Push(sub);
                    }
                }
                else if (entry is FileInfo file && (IndexedExtensions.Contains(file.Extension) || file.Name.Equals("Dockerfile", StringComparison.OrdinalIgnoreCase)))
                {
                    yield return file;
                }
            }
        }
    }
}
