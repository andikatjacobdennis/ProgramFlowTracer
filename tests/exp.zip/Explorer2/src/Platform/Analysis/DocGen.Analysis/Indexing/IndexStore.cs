using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using DocGen.Core.Exceptions;

namespace DocGen.Analysis.Indexing;

/// <summary>
/// Persists repository indexes as JSON under {data}/analysis/indexes/{key}/: manifest.json plus 256 bucket files that
/// hold the per-file entries (bucket = first byte of SHA-1(path)). An incremental update rewrites only the buckets whose
/// files changed. The index is a rebuildable cache: writes are atomic (temp + rename) but not fsync'd, and a damaged
/// bucket is simply re-indexed.
/// </summary>
public sealed class IndexStore(string dataDirectory)
{
    private const string PartialSuffix = ".partial";

    internal static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web)
    {
        WriteIndented = false,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingDefault,
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
        MaxDepth = 64,
    };

    public string DirectoryFor(string indexKey)
    {
        if (string.IsNullOrWhiteSpace(indexKey) || indexKey.Any(c => !(char.IsAsciiLetterOrDigit(c) || c is '-' or '_')) || indexKey.Length > 120)
        {
            throw new ValidationException("Invalid index key.");
        }
        return Path.Combine(Path.GetFullPath(dataDirectory), "analysis", "indexes", indexKey);
    }

    public static int BucketOf(string relativePath)
        => SHA1.HashData(Encoding.UTF8.GetBytes(relativePath.ToLowerInvariant()))[0];

    public async Task<IndexManifest?> ReadManifestAsync(string indexKey, CancellationToken ct)
    {
        var path = Path.Combine(DirectoryFor(indexKey), "manifest.json");
        if (!File.Exists(path))
        {
            return null;
        }
        try
        {
            await using var stream = File.OpenRead(path);
            var manifest = await JsonSerializer.DeserializeAsync<IndexManifest>(stream, Json, ct);
            return manifest?.SchemaVersion == IndexManifest.CurrentSchemaVersion ? manifest : null;
        }
        catch (Exception ex) when (ex is JsonException or IOException)
        {
            return null; // Rebuilt by the next index pass.
        }
    }

    /// <summary>Loads all bucket entries. Buckets that cannot be read are skipped (their files will re-index).</summary>
    public async Task<Dictionary<string, FileIndex>> ReadFilesAsync(string indexKey, int parallelism, CancellationToken ct)
    {
        var dir = Path.Combine(DirectoryFor(indexKey), "buckets");
        var result = new Dictionary<string, FileIndex>(StringComparer.OrdinalIgnoreCase);
        if (!Directory.Exists(dir))
        {
            return result;
        }
        var buckets = Directory.EnumerateFiles(dir, "*.json").ToList();
        var loaded = new Dictionary<string, FileIndex>[buckets.Count];
        await Parallel.ForEachAsync(Enumerable.Range(0, buckets.Count), new ParallelOptions { MaxDegreeOfParallelism = Math.Max(1, parallelism), CancellationToken = ct }, async (i, token) =>
        {
            try
            {
                await using var stream = File.OpenRead(buckets[i]);
                loaded[i] = await JsonSerializer.DeserializeAsync<Dictionary<string, FileIndex>>(stream, Json, token) ?? [];
            }
            catch (Exception ex) when (ex is JsonException or IOException)
            {
                loaded[i] = [];
            }
        });
        foreach (var bucket in loaded)
        {
            foreach (var (path, entry) in bucket)
            {
                result[path] = entry;
            }
        }
        return result;
    }

    public async Task WriteBucketsAsync(string indexKey, IEnumerable<int> buckets, IReadOnlyDictionary<string, FileIndex> files, CancellationToken ct)
    {
        var dir = Path.Combine(DirectoryFor(indexKey), "buckets");
        Directory.CreateDirectory(dir);
        var byBucket = files.GroupBy(f => BucketOf(f.Key)).ToDictionary(g => g.Key, g => g.ToDictionary(x => x.Key, x => x.Value, StringComparer.OrdinalIgnoreCase));
        foreach (var bucket in buckets.Distinct())
        {
            ct.ThrowIfCancellationRequested();
            var path = Path.Combine(dir, bucket.ToString("x2") + ".json");
            if (!byBucket.TryGetValue(bucket, out var content) || content.Count == 0)
            {
                if (File.Exists(path))
                {
                    File.Delete(path);
                }
                continue;
            }
            await WriteAtomicAsync(path, content, ct);
        }
    }

    public Task WriteManifestAsync(string indexKey, IndexManifest manifest, CancellationToken ct)
    {
        var dir = DirectoryFor(indexKey);
        Directory.CreateDirectory(dir);
        return WriteAtomicAsync(Path.Combine(dir, "manifest.json"), manifest, ct);
    }

    public void Delete(string indexKey)
    {
        var dir = DirectoryFor(indexKey);
        if (Directory.Exists(dir))
        {
            Directory.Delete(dir, recursive: true);
        }
    }

    private static async Task WriteAtomicAsync<T>(string path, T value, CancellationToken ct)
    {
        var temp = path + PartialSuffix;
        await using (var stream = new FileStream(temp, FileMode.Create, FileAccess.Write, FileShare.None, 64 * 1024, FileOptions.Asynchronous))
        {
            await JsonSerializer.SerializeAsync(stream, value, Json, ct);
        }
        File.Move(temp, path, overwrite: true);
    }
}
