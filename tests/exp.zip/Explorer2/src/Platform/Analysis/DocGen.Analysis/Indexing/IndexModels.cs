namespace DocGen.Analysis.Indexing;

public static class SymbolKinds
{
    public const string Class = "class";
    public const string Struct = "struct";
    public const string Interface = "interface";
    public const string Record = "record";
    public const string Enum = "enum";
    public const string Delegate = "delegate";
    public const string Method = "method";
    public const string Constructor = "constructor";
    public const string Property = "property";
    public const string Field = "field";
    public const string Event = "event";
    public const string Indexer = "indexer";
    public const string EnumMember = "enumMember";
    public const string TopLevel = "topLevel";

    public static bool IsType(string kind) => kind is Class or Struct or Interface or Record or Enum or Delegate;

    public static bool IsCallable(string kind) => kind is Method or Constructor or Property or Indexer or TopLevel;
}

/// <summary>A declared symbol. Positions are 1-based lines. Resolution is name-based (see README: "Code intelligence").</summary>
public sealed class SymbolRecord
{
    public string Kind { get; set; } = "";
    public string Name { get; set; } = "";

    /// <summary>Namespace.Type[.Nested][.Member]; generic arity is not part of the name.</summary>
    public string FullName { get; set; } = "";

    public string? Container { get; set; }
    public string Namespace { get; set; } = "";
    public string Signature { get; set; } = "";
    public List<string> Modifiers { get; set; } = [];
    public List<string> Attributes { get; set; } = [];

    /// <summary>Base types / implemented interfaces by simple name (types only).</summary>
    public List<string> Bases { get; set; } = [];

    public string? ReturnType { get; set; }

    /// <summary>Parameter simple type names (methods, constructors, primary constructors).</summary>
    public List<string> ParameterTypes { get; set; } = [];

    public int StartLine { get; set; }
    public int EndLine { get; set; }

    /// <summary>Names this member invokes (identifier followed by an argument list).</summary>
    public List<string> Calls { get; set; } = [];

    /// <summary>Capitalised names this member references that are not invocations (types, properties, constants).</summary>
    public List<string> Uses { get; set; } = [];

    public bool IsTest { get; set; }

    /// <summary>File path relative to the repository root (set when loaded from the index).</summary>
    public string File { get; set; } = "";

    public string Project { get; set; } = "";
}

public sealed class DiRegistration
{
    public string Lifetime { get; set; } = "";
    public string ServiceType { get; set; } = "";
    public string ImplementationType { get; set; } = "";
    public bool Factory { get; set; }
    public bool Hosted { get; set; }
    public string Method { get; set; } = "";
    public int Line { get; set; }
    public string? Owner { get; set; }
    public string File { get; set; } = "";
    public string Project { get; set; } = "";
}

public sealed class ConfigReference
{
    /// <summary>section | value | connectionString | indexer | bind | sectionConstant | optionsBinding</summary>
    public string Kind { get; set; } = "";

    public string Key { get; set; } = "";

    /// <summary>For optionsBinding: the options type; for sectionConstant: the declaring type.</summary>
    public string? Type { get; set; }

    public int Line { get; set; }
    public string? Owner { get; set; }
    public string File { get; set; } = "";
}

public sealed class EndpointRecord
{
    public string Verb { get; set; } = "";
    public string Route { get; set; } = "";
    public string Handler { get; set; } = "";

    /// <summary>controller | minimal | hub | grpc</summary>
    public string Style { get; set; } = "";

    public int Line { get; set; }
    public string File { get; set; } = "";
}

public sealed class MiddlewareRecord
{
    public string Name { get; set; } = "";
    public int Order { get; set; }
    public int Line { get; set; }
    public string? Owner { get; set; }
    public string File { get; set; } = "";
}

/// <summary>Everything extracted from one source file. Stored in the index; re-created only when the file hash changes.</summary>
public sealed class FileIndex
{
    public string Path { get; set; } = "";
    public string Hash { get; set; } = "";
    public long Size { get; set; }
    public int Lines { get; set; }

    /// <summary>Last write time (UTC ticks) at indexing; with <see cref="Size"/> it lets unchanged files skip hashing.</summary>
    public long LastWriteTicks { get; set; }
    public DateTime IndexedAt { get; set; } = DateTime.UtcNow;
    public string Project { get; set; } = "";

    /// <summary>cs | json | csproj | other</summary>
    public string Language { get; set; } = "cs";

    public bool Parsed { get; set; }
    public List<string> Namespaces { get; set; } = [];
    public List<string> Usings { get; set; } = [];
    public List<SymbolRecord> Symbols { get; set; } = [];

    /// <summary>Identifier → lines where it occurs (bounded per identifier). Drives find_references.</summary>
    public Dictionary<string, List<int>> Identifiers { get; set; } = new(StringComparer.Ordinal);

    public List<DiRegistration> Registrations { get; set; } = [];
    public List<ConfigReference> Config { get; set; } = [];
    public List<EndpointRecord> Endpoints { get; set; } = [];
    public List<MiddlewareRecord> Middleware { get; set; } = [];

    /// <summary>For configuration JSON files (appsettings*.json): flattened keys ("A:B:C") → line.</summary>
    public Dictionary<string, int>? ConfigKeys { get; set; }
}

public sealed class PackageReference
{
    public string Id { get; set; } = "";
    public string? Version { get; set; }

    /// <summary>Resolved version from obj/project.assets.json when a restore has run.</summary>
    public string? ResolvedVersion { get; set; }

    public bool Transitive { get; set; }
}

public sealed class ProjectInfo
{
    public string Name { get; set; } = "";
    public string Path { get; set; } = "";
    public string Directory { get; set; } = "";
    public string? Sdk { get; set; }
    public List<string> TargetFrameworks { get; set; } = [];
    public string? OutputType { get; set; }
    public bool IsTestProject { get; set; }
    public string? RootNamespace { get; set; }
    public string? AssemblyName { get; set; }
    public List<string> ProjectReferences { get; set; } = [];
    public List<PackageReference> Packages { get; set; } = [];
    public List<string> FrameworkReferences { get; set; } = [];
    public string? Nullable { get; set; }
    public string Hash { get; set; } = "";
}

public sealed class SolutionInfo
{
    public string Path { get; set; } = "";
    public List<string> Projects { get; set; } = [];
}

/// <summary>Repository-level index metadata (manifest.json). File entries are stored in hash buckets.</summary>
public sealed class IndexManifest
{
    public const int CurrentSchemaVersion = 1;

    /// <summary>Bumped whenever extraction changes; an index built by an older parser is rebuilt automatically.</summary>
    public const int CurrentParserVersion = 3;

    public int SchemaVersion { get; set; } = CurrentSchemaVersion;
    public int ParserVersion { get; set; } = CurrentParserVersion;
    public string Repository { get; set; } = "";
    public string Root { get; set; } = "";
    public DateTime? LastIndexedAt { get; set; }
    public long LastDurationMs { get; set; }
    public List<SolutionInfo> Solutions { get; set; } = [];
    public List<ProjectInfo> Projects { get; set; } = [];

    /// <summary>Relative path → content hash of every indexed file.</summary>
    public Dictionary<string, string> Files { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    public IndexStats Stats { get; set; } = new();
}

public sealed class IndexStats
{
    public int Files { get; set; }
    public int ParsedFiles { get; set; }
    public int Symbols { get; set; }
    public int Types { get; set; }
    public int Projects { get; set; }
    public int Relationships { get; set; }
    public long SourceBytes { get; set; }
}

/// <summary>Outcome of one (incremental) indexing pass.</summary>
public sealed class IndexUpdateResult
{
    public string Repository { get; set; } = "";
    public int Scanned { get; set; }
    public int Added { get; set; }
    public int Changed { get; set; }
    public int Removed { get; set; }
    public int Unchanged { get; set; }
    public int Skipped { get; set; }
    public long DurationMs { get; set; }
    public bool Full { get; set; }
    public IndexStats Stats { get; set; } = new();
}
