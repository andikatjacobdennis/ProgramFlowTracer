using System.Text.Json;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;

namespace DocGen.Analysis.Indexing;

/// <summary>Reads .sln/.slnx solutions, SDK-style .csproj files, Directory.Packages.props and obj/project.assets.json.</summary>
public static partial class ProjectParser
{
    private static readonly XmlReaderSettings SafeXml = new()
    {
        DtdProcessing = DtdProcessing.Prohibit, // No external entities / DTDs from repository content.
        XmlResolver = null,
        MaxCharactersInDocument = 20_000_000,
    };

    public static SolutionInfo ParseSolution(string fullPath, string root)
    {
        var info = new SolutionInfo { Path = Relative(root, fullPath) };
        var dir = Path.GetDirectoryName(fullPath)!;
        if (fullPath.EndsWith(".slnx", StringComparison.OrdinalIgnoreCase))
        {
            try
            {
                using var reader = XmlReader.Create(fullPath, SafeXml);
                var doc = XDocument.Load(reader);
                foreach (var p in doc.Descendants().Where(e => e.Name.LocalName == "Project"))
                {
                    if (p.Attribute("Path")?.Value is { } path)
                    {
                        info.Projects.Add(Relative(root, Path.GetFullPath(Path.Combine(dir, path.Replace('\\', Path.DirectorySeparatorChar)))));
                    }
                }
            }
            catch (Exception ex) when (ex is XmlException or IOException)
            {
            }
            return info;
        }
        foreach (var line in File.ReadLines(fullPath))
        {
            var match = SlnProject().Match(line);
            if (match.Success && match.Groups["path"].Value.EndsWith("proj", StringComparison.OrdinalIgnoreCase))
            {
                var path = match.Groups["path"].Value.Replace('\\', Path.DirectorySeparatorChar);
                info.Projects.Add(Relative(root, Path.GetFullPath(Path.Combine(dir, path))));
            }
        }
        return info;
    }

    public static ProjectInfo ParseProject(string fullPath, string root, IReadOnlyDictionary<string, string> centralVersions)
    {
        var project = new ProjectInfo
        {
            Name = Path.GetFileNameWithoutExtension(fullPath),
            Path = Relative(root, fullPath),
            Directory = Relative(root, Path.GetDirectoryName(fullPath)!),
        };
        XDocument doc;
        try
        {
            using var reader = XmlReader.Create(fullPath, SafeXml);
            doc = XDocument.Load(reader);
        }
        catch (Exception ex) when (ex is XmlException or IOException)
        {
            return project;
        }

        var rootElement = doc.Root;
        project.Sdk = rootElement?.Attribute("Sdk")?.Value;
        var inherited = InheritedProperties(Path.GetDirectoryName(fullPath)!, root);
        string? Prop(string name) => doc.Descendants().Where(e => e.Name.LocalName == name).Select(e => e.Value.Trim()).LastOrDefault(v => v.Length > 0)
                                     ?? inherited.GetValueOrDefault(name);

        var tfm = Prop("TargetFramework");
        var tfms = Prop("TargetFrameworks");
        project.TargetFrameworks = (tfms ?? tfm ?? "").Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
        project.OutputType = Prop("OutputType");
        project.RootNamespace = Prop("RootNamespace");
        project.AssemblyName = Prop("AssemblyName");
        project.Nullable = Prop("Nullable");

        var projectDir = Path.GetDirectoryName(fullPath)!;
        foreach (var element in doc.Descendants())
        {
            switch (element.Name.LocalName)
            {
                case "ProjectReference" when element.Attribute("Include")?.Value is { } include:
                    project.ProjectReferences.Add(Relative(root, Path.GetFullPath(Path.Combine(projectDir, include.Replace('\\', Path.DirectorySeparatorChar)))));
                    break;
                case "PackageReference" when (element.Attribute("Include") ?? element.Attribute("Update"))?.Value is { } id:
                    var version = element.Attribute("Version")?.Value ?? element.Attribute("VersionOverride")?.Value
                                  ?? element.Elements().FirstOrDefault(e => e.Name.LocalName == "Version")?.Value;
                    if (version is null && centralVersions.TryGetValue(id, out var central))
                    {
                        version = central;
                    }
                    project.Packages.Add(new PackageReference { Id = id, Version = version });
                    break;
                case "FrameworkReference" when element.Attribute("Include")?.Value is { } framework:
                    project.FrameworkReferences.Add(framework);
                    break;
            }
        }

        project.IsTestProject = string.Equals(Prop("IsTestProject"), "true", StringComparison.OrdinalIgnoreCase)
                                || project.Packages.Any(p => p.Id is "Microsoft.NET.Test.Sdk" or "MSTest" or "MSTest.TestFramework" or "xunit" or "xunit.v3" or "NUnit" or "TUnit")
                                || project.Sdk?.Contains("MSTest", StringComparison.OrdinalIgnoreCase) == true;
        // A project named as tests whose test packages a Directory.Build.props adds — often under a condition such as
        // '$(TestProject)'=='true', which this reading does not evaluate.
        if (!project.IsTestProject && TestProjectName().IsMatch(project.Name) && InheritsTestPackages(projectDir, root))
        {
            project.IsTestProject = true;
        }

        ApplyAssets(project, Path.Combine(projectDir, "obj", "project.assets.json"));
        return project;
    }

    /// <summary>
    /// Properties from Directory.Build.props files between the repository root and the project folder (MSBuild imports
    /// the nearest one; nested files commonly import their parent, so inner values override outer ones here).
    /// Only literal values are used — MSBuild expressions are not evaluated.
    /// </summary>
    internal static Dictionary<string, string> InheritedProperties(string projectDir, string root)
    {
        var chain = new List<string>();
        var rootFull = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar);
        for (var dir = Path.GetFullPath(projectDir); dir is not null && dir.Length >= rootFull.Length; dir = Path.GetDirectoryName(dir))
        {
            var candidate = Path.Combine(dir, "Directory.Build.props");
            if (File.Exists(candidate))
            {
                chain.Add(candidate);
            }
            if (string.Equals(dir.TrimEnd(Path.DirectorySeparatorChar), rootFull, StringComparison.OrdinalIgnoreCase))
            {
                break;
            }
        }
        var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var file in Enumerable.Reverse(chain))
        {
            try
            {
                using var reader = XmlReader.Create(file, SafeXml);
                var doc = XDocument.Load(reader);
                foreach (var group in doc.Descendants().Where(e => e.Name.LocalName == "PropertyGroup" && e.Attribute("Condition") is null))
                {
                    foreach (var property in group.Elements())
                    {
                        var value = property.Value.Trim();
                        if (value.Length > 0 && !value.Contains("$(", StringComparison.Ordinal))
                        {
                            values[property.Name.LocalName] = value;
                        }
                    }
                }
            }
            catch (Exception ex) when (ex is XmlException or IOException)
            {
            }
        }
        return values;
    }

    /// <summary>Whether a Directory.Build.props between the project and the repository root references a test framework or the test SDK.</summary>
    private static bool InheritsTestPackages(string projectDir, string root)
    {
        var rootFull = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar);
        for (var dir = Path.GetFullPath(projectDir); dir is not null && dir.Length >= rootFull.Length; dir = Path.GetDirectoryName(dir))
        {
            var candidate = Path.Combine(dir, "Directory.Build.props");
            try
            {
                if (File.Exists(candidate) && TestPackageInclude().IsMatch(File.ReadAllText(candidate)))
                {
                    return true;
                }
            }
            catch (IOException)
            {
            }
            if (string.Equals(dir.TrimEnd(Path.DirectorySeparatorChar), rootFull, StringComparison.OrdinalIgnoreCase))
            {
                break;
            }
        }
        return false;
    }

    // "Core.Test", "Api.Tests", "OrdersIntegrationTests" — a capital T, so "Latest" is not one.
    [GeneratedRegex(@"(?:[.\-_]|(?<=[a-z0-9]))(Unit|Integration|Functional|Automation|Acceptance)?Tests?$")]
    private static partial Regex TestProjectName();

    [GeneratedRegex(@"Include=""(Microsoft\.NET\.Test\.Sdk|NUnit|xunit|MSTest|TUnit)", RegexOptions.IgnoreCase)]
    private static partial Regex TestPackageInclude();

    /// <summary>Directory.Packages.props (central package management) in the repository root or any ancestor within it.</summary>
    public static Dictionary<string, string> CentralVersions(string root)
    {
        var versions = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var path = Path.Combine(root, "Directory.Packages.props");
        if (!File.Exists(path))
        {
            return versions;
        }
        try
        {
            using var reader = XmlReader.Create(path, SafeXml);
            var doc = XDocument.Load(reader);
            foreach (var e in doc.Descendants().Where(e => e.Name.LocalName == "PackageVersion"))
            {
                if (e.Attribute("Include")?.Value is { } id && e.Attribute("Version")?.Value is { } v)
                {
                    versions[id] = v;
                }
            }
        }
        catch (Exception ex) when (ex is XmlException or IOException)
        {
        }
        return versions;
    }

    /// <summary>Adds resolved versions and transitive packages from a restore's project.assets.json (if present).</summary>
    private static void ApplyAssets(ProjectInfo project, string assetsPath)
    {
        if (!File.Exists(assetsPath) || new FileInfo(assetsPath).Length > 64L * 1024 * 1024)
        {
            return;
        }
        try
        {
            using var stream = File.OpenRead(assetsPath);
            using var doc = JsonDocument.Parse(stream, new JsonDocumentOptions { MaxDepth = 64 });
            if (!doc.RootElement.TryGetProperty("libraries", out var libraries) || libraries.ValueKind != JsonValueKind.Object)
            {
                return;
            }
            // A package may be listed twice (one per conditional ItemGroup): the first entry stands for it.
            var direct = project.Packages.GroupBy(p => p.Id, StringComparer.OrdinalIgnoreCase).ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
            foreach (var library in libraries.EnumerateObject())
            {
                var slash = library.Name.IndexOf('/');
                if (slash <= 0 || !library.Value.TryGetProperty("type", out var type) || type.GetString() != "package")
                {
                    continue;
                }
                var id = library.Name[..slash];
                var version = library.Name[(slash + 1)..];
                if (direct.TryGetValue(id, out var reference))
                {
                    reference.ResolvedVersion = version;
                }
                else
                {
                    project.Packages.Add(new PackageReference { Id = id, ResolvedVersion = version, Transitive = true });
                }
            }
        }
        catch (Exception ex) when (ex is JsonException or IOException)
        {
        }
    }

    /// <summary>Flattens a JSON configuration file into "A:B:C" keys (array items as indexes) with their line numbers.</summary>
    public static Dictionary<string, int> FlattenConfiguration(string text)
    {
        var keys = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        var bytes = System.Text.Encoding.UTF8.GetBytes(text);
        var lineStarts = new List<int> { 0 };
        for (var i = 0; i < bytes.Length; i++)
        {
            if (bytes[i] == '\n')
            {
                lineStarts.Add(i + 1);
            }
        }
        int LineOf(long offset)
        {
            var index = lineStarts.BinarySearch((int)offset);
            return (index >= 0 ? index : ~index - 1) + 1;
        }

        var reader = new Utf8JsonReader(bytes, new JsonReaderOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true, MaxDepth = 64 });
        var path = new List<string>();
        var arrayIndex = new Stack<int>();
        var containers = new Stack<bool>(); // true = array
        string? pendingProperty = null;
        try
        {
            while (reader.Read())
            {
                switch (reader.TokenType)
                {
                    case JsonTokenType.PropertyName:
                        pendingProperty = reader.GetString();
                        break;
                    case JsonTokenType.StartObject or JsonTokenType.StartArray:
                        PushSegment(reader.TokenStartIndex);
                        containers.Push(reader.TokenType == JsonTokenType.StartArray);
                        arrayIndex.Push(0);
                        break;
                    case JsonTokenType.EndObject or JsonTokenType.EndArray:
                        if (containers.Count > 0)
                        {
                            containers.Pop();
                            arrayIndex.Pop();
                        }
                        if (path.Count > 0)
                        {
                            path.RemoveAt(path.Count - 1);
                        }
                        break;
                    default:
                        PushSegment(reader.TokenStartIndex);
                        if (path.Count > 0)
                        {
                            path.RemoveAt(path.Count - 1);
                        }
                        break;
                }
            }
        }
        catch (JsonException)
        {
            // Partial results are still useful for malformed configuration files.
        }
        return keys;

        void PushSegment(long offset)
        {
            if (containers.Count == 0)
            {
                path.Add(""); // Root container.
                return;
            }
            string segment;
            if (containers.Peek())
            {
                var idx = arrayIndex.Pop();
                segment = idx.ToString(System.Globalization.CultureInfo.InvariantCulture);
                arrayIndex.Push(idx + 1);
            }
            else
            {
                segment = pendingProperty ?? "";
            }
            path.Add(segment);
            var key = string.Join(':', path.Where(p => p.Length > 0));
            if (key.Length > 0)
            {
                keys.TryAdd(key, LineOf(offset));
            }
        }
    }

    public static string Relative(string root, string full) => Path.GetRelativePath(root, full).Replace('\\', '/');

    [GeneratedRegex(@"^Project\(""\{[^}]+\}""\)\s*=\s*""(?<name>[^""]+)""\s*,\s*""(?<path>[^""]+)""")]
    private static partial Regex SlnProject();
}
