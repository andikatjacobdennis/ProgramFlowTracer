namespace DocGen.Analysis.Indexing;

/// <summary>
/// Immutable, in-memory query model over one repository index: symbol tables, inheritance, name-based call and use
/// graphs, DI registrations, configuration, endpoints and projects. Built from the persisted index in milliseconds for
/// tens of thousands of symbols; queries never touch the disk except to read source lines.
/// </summary>
public sealed class CodeIndex
{
    public const int MaxEnumerated = 5000;

    private readonly Dictionary<string, List<SymbolRecord>> _byName = new(StringComparer.Ordinal);
    private readonly Dictionary<string, List<SymbolRecord>> _byNameIgnoreCase = new(StringComparer.OrdinalIgnoreCase);
    private readonly Dictionary<string, List<SymbolRecord>> _byFullName = new(StringComparer.Ordinal);
    private readonly Dictionary<string, List<SymbolRecord>> _derived = new(StringComparer.Ordinal);
    private readonly Dictionary<string, List<SymbolRecord>> _callers = new(StringComparer.Ordinal);
    private readonly Dictionary<string, List<SymbolRecord>> _users = new(StringComparer.Ordinal);
    private readonly Dictionary<string, List<SymbolRecord>> _membersByContainer = new(StringComparer.Ordinal);
    private readonly Dictionary<SymbolRecord, int> _ids = new(ReferenceEqualityComparer.Instance);

    public CodeIndex(IndexManifest manifest, Dictionary<string, FileIndex> files, string root)
    {
        Manifest = manifest;
        Files = files;
        Root = root;
        // Two projects may share a name (a scratch copy, a sample next to the real one): the first is looked up by name,
        // and every file still belongs to the project whose folder contains it. A duplicate must never break the index.
        Projects = manifest.Projects.GroupBy(p => p.Name, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);

        // Deepest project directory owns a file (SDK-style globbing).
        var projectDirs = manifest.Projects.Where(p => p.Directory.Length > 0 && p.Directory != ".")
            .OrderByDescending(p => p.Directory.Length).ToList();
        var rootProject = manifest.Projects.FirstOrDefault(p => p.Directory is "" or ".");
        foreach (var (path, file) in files)
        {
            file.Project = projectDirs.FirstOrDefault(p => path.StartsWith(p.Directory + "/", StringComparison.OrdinalIgnoreCase))?.Name ?? rootProject?.Name ?? "";
            foreach (var symbol in file.Symbols)
            {
                symbol.File = path;
                symbol.Project = file.Project;
                _ids[symbol] = Symbols.Count;
                Symbols.Add(symbol);
                Add(_byName, symbol.Name, symbol);
                Add(_byNameIgnoreCase, symbol.Name, symbol);
                Add(_byFullName, symbol.FullName, symbol);
                if (symbol.Container is not null)
                {
                    Add(_membersByContainer, symbol.Container, symbol);
                }
                foreach (var b in symbol.Bases)
                {
                    Add(_derived, StripGeneric(b), symbol);
                }
                foreach (var call in symbol.Calls)
                {
                    Add(_callers, call, symbol);
                }
                foreach (var use in symbol.Uses)
                {
                    Add(_users, use, symbol);
                }
            }
            foreach (var r in file.Registrations)
            {
                r.File = path;
                r.Project = file.Project;
                Registrations.Add(r);
            }
            foreach (var c in file.Config)
            {
                c.File = path;
                ConfigReferences.Add(c);
            }
            foreach (var e in file.Endpoints)
            {
                e.File = path;
                Endpoints.Add(e);
            }
            foreach (var m in file.Middleware)
            {
                m.File = path;
                Middleware.Add(m);
            }
            if (file.ConfigKeys is { } keys)
            {
                foreach (var (key, line) in keys)
                {
                    Add(ConfigValues, key, (path, line));
                }
            }
        }
        Relationships = _derived.Values.Sum(v => v.Count) + _callers.Values.Sum(v => v.Count) + _users.Values.Sum(v => v.Count)
                        + Registrations.Count + manifest.Projects.Sum(p => p.ProjectReferences.Count);
    }

    public IndexManifest Manifest { get; }
    public Dictionary<string, FileIndex> Files { get; }
    public string Root { get; }
    public Dictionary<string, ProjectInfo> Projects { get; }
    public List<SymbolRecord> Symbols { get; } = [];
    public List<DiRegistration> Registrations { get; } = [];
    public List<ConfigReference> ConfigReferences { get; } = [];
    public List<EndpointRecord> Endpoints { get; } = [];
    public List<MiddlewareRecord> Middleware { get; } = [];
    public Dictionary<string, List<(string File, int Line)>> ConfigValues { get; } = new(StringComparer.OrdinalIgnoreCase);
    public int Relationships { get; }

    public int IdOf(SymbolRecord symbol) => _ids.TryGetValue(symbol, out var id) ? id : -1;

    public IEnumerable<SymbolRecord> Types => Symbols.Where(s => SymbolKinds.IsType(s.Kind));

    /// <summary>Test methods ([TestMethod], [Fact], [Test]…); test classes are excluded.</summary>
    public IEnumerable<SymbolRecord> TestMethods => Symbols.Where(s => s.IsTest && !SymbolKinds.IsType(s.Kind));

    public IReadOnlyList<SymbolRecord> ByName(string name) => _byName.TryGetValue(name, out var list) ? list : [];

    public IReadOnlyList<SymbolRecord> MembersOf(string containerFullName) => _membersByContainer.TryGetValue(containerFullName, out var list) ? list : [];

    public IReadOnlyList<SymbolRecord> DirectlyDerived(string typeName) => _derived.TryGetValue(StripGeneric(typeName), out var list) ? list : [];

    public IReadOnlyList<SymbolRecord> CallersByName(string name) => _callers.TryGetValue(name, out var list) ? list : [];

    public IReadOnlyList<SymbolRecord> UsersByName(string name) => _users.TryGetValue(name, out var list) ? list : [];

    /// <summary>
    /// Resolves a user/model supplied symbol reference: "Name", "Type.Member", "Namespace.Type" or a full name
    /// (case-insensitive fallback). Optional kind filter: type | member | any.
    /// </summary>
    public List<SymbolRecord> Resolve(string query, string? kind = null)
    {
        query = query.Trim();
        var paren = query.IndexOf('(');
        if (paren > 0)
        {
            query = query[..paren];
        }
        query = StripGeneric(query);
        List<SymbolRecord> found;
        if (_byFullName.TryGetValue(query, out var exact))
        {
            found = exact.ToList();
        }
        else if (query.Contains('.'))
        {
            var last = query[(query.LastIndexOf('.') + 1)..];
            found = (_byName.TryGetValue(last, out var candidates) ? candidates : _byNameIgnoreCase.TryGetValue(last, out var ci) ? ci : [])
                .Where(s => s.FullName.EndsWith("." + query, StringComparison.OrdinalIgnoreCase) || s.FullName.Equals(query, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }
        else
        {
            found = _byName.TryGetValue(query, out var byName) ? byName.ToList()
                : _byNameIgnoreCase.TryGetValue(query, out var byNameCi) ? byNameCi.ToList() : [];
        }
        return kind switch
        {
            "type" => found.Where(s => SymbolKinds.IsType(s.Kind)).ToList(),
            "member" => found.Where(s => !SymbolKinds.IsType(s.Kind)).ToList(),
            _ => found,
        };
    }

    /// <summary>Ranked fuzzy symbol search (exact, prefix, camel-hump, substring).</summary>
    public List<(SymbolRecord Symbol, int Score)> Search(string query, string? kind, string? project, bool includeTests, int limit)
    {
        query = StripGeneric(query.Trim());
        var results = new List<(SymbolRecord, int)>();
        if (query.Length == 0)
        {
            return results;
        }
        var lastSegment = query.Contains('.') ? query[(query.LastIndexOf('.') + 1)..] : query;
        foreach (var s in Symbols)
        {
            if (kind is not null && !KindMatches(s, kind) || project is not null && !string.Equals(s.Project, project, StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }
            var score = Score(s, query, lastSegment);
            if (score <= 0)
            {
                continue;
            }
            if (SymbolKinds.IsType(s.Kind))
            {
                score += 5;
            }
            if (!includeTests && (s.IsTest || IsTestProject(s.Project)))
            {
                score -= 15;
            }
            results.Add((s, score));
        }
        return results.OrderByDescending(r => r.Item2).ThenBy(r => r.Item1.FullName.Length).ThenBy(r => r.Item1.FullName, StringComparer.Ordinal).Take(limit).ToList();
    }

    private static bool KindMatches(SymbolRecord s, string kind) => kind switch
    {
        "type" => SymbolKinds.IsType(s.Kind),
        "member" => !SymbolKinds.IsType(s.Kind),
        "test" => s.IsTest,
        _ => string.Equals(s.Kind, kind, StringComparison.OrdinalIgnoreCase),
    };

    private static int Score(SymbolRecord s, string query, string last)
    {
        if (s.FullName.Equals(query, StringComparison.Ordinal))
        {
            return 120;
        }
        if (s.Name.Equals(last, StringComparison.Ordinal) && (query == last || s.FullName.EndsWith("." + query, StringComparison.OrdinalIgnoreCase)))
        {
            return 100;
        }
        if (s.Name.Equals(last, StringComparison.OrdinalIgnoreCase))
        {
            return 90;
        }
        if (s.Name.StartsWith(last, StringComparison.OrdinalIgnoreCase))
        {
            return 70;
        }
        if (CamelHumps(s.Name, last))
        {
            return 60;
        }
        if (s.Name.Contains(last, StringComparison.OrdinalIgnoreCase))
        {
            return 50;
        }
        if (s.FullName.Contains(query, StringComparison.OrdinalIgnoreCase))
        {
            return 30;
        }
        return 0;
    }

    /// <summary>"OrdSvc" matches "OrderService"; "OS" matches "OrderService".</summary>
    private static bool CamelHumps(string name, string query)
    {
        if (query.Length < 2 || !char.IsUpper(query[0]))
        {
            return false;
        }
        var humps = new List<string>();
        var start = 0;
        for (var i = 1; i <= name.Length; i++)
        {
            if (i == name.Length || char.IsUpper(name[i]) && !char.IsUpper(name[i - 1]))
            {
                humps.Add(name[start..i]);
                start = i;
            }
        }
        var qHumps = new List<string>();
        start = 0;
        for (var i = 1; i <= query.Length; i++)
        {
            if (i == query.Length || char.IsUpper(query[i]))
            {
                qHumps.Add(query[start..i]);
                start = i;
            }
        }
        var h = 0;
        foreach (var q in qHumps)
        {
            while (h < humps.Count && !HumpMatches(humps[h], q))
            {
                h++;
            }
            if (h == humps.Count)
            {
                return false;
            }
            h++;
        }
        return true;
    }

    /// <summary>The query hump's first letter starts the name hump and its other letters appear in order ("Svc" ~ "Service").</summary>
    private static bool HumpMatches(string hump, string query)
    {
        if (char.ToUpperInvariant(hump[0]) != char.ToUpperInvariant(query[0]))
        {
            return false;
        }
        var i = 1;
        foreach (var c in query.AsSpan(1))
        {
            while (i < hump.Length && char.ToUpperInvariant(hump[i]) != char.ToUpperInvariant(c))
            {
                i++;
            }
            if (i++ >= hump.Length)
            {
                return false;
            }
        }
        return true;
    }

    public bool IsTestProject(string project) => Projects.TryGetValue(project, out var p) && p.IsTestProject;

    /// <summary>The innermost member (or type) whose line range contains the line.</summary>
    public SymbolRecord? EnclosingSymbol(string file, int line)
    {
        if (!Files.TryGetValue(file, out var entry))
        {
            return null;
        }
        SymbolRecord? best = null;
        foreach (var s in entry.Symbols)
        {
            if (s.StartLine <= line && line <= s.EndLine && (best is null || s.EndLine - s.StartLine < best.EndLine - best.StartLine))
            {
                best = s;
            }
        }
        return best;
    }

    /// <summary>All types deriving from / implementing the type name, transitively (breadth-first, bounded).</summary>
    public List<(SymbolRecord Type, int Depth)> AllDerived(string typeName, int maxDepth = 6)
    {
        var result = new List<(SymbolRecord, int)>();
        var seen = new HashSet<string>(StringComparer.Ordinal) { StripGeneric(typeName) };
        var frontier = new Queue<(string Name, int Depth)>();
        frontier.Enqueue((StripGeneric(typeName), 0));
        while (frontier.Count > 0 && result.Count < MaxEnumerated)
        {
            var (name, depth) = frontier.Dequeue();
            if (depth >= maxDepth)
            {
                continue;
            }
            foreach (var derived in DirectlyDerived(name))
            {
                if (seen.Add(derived.FullName))
                {
                    result.Add((derived, depth + 1));
                    frontier.Enqueue((derived.Name, depth + 1));
                }
            }
        }
        return result;
    }

    /// <summary>Projects that (transitively) reference the project.</summary>
    public List<string> ReverseProjectClosure(string project)
    {
        var byPath = Manifest.Projects.ToDictionary(p => p.Path, p => p.Name, StringComparer.OrdinalIgnoreCase);
        var reverse = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
        foreach (var p in Manifest.Projects)
        {
            foreach (var reference in p.ProjectReferences)
            {
                if (byPath.TryGetValue(reference, out var target))
                {
                    Add(reverse, target, p.Name);
                }
            }
        }
        var result = new List<string>();
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { project };
        var queue = new Queue<string>([project]);
        while (queue.Count > 0)
        {
            foreach (var dependent in reverse.GetValueOrDefault(queue.Dequeue()) ?? [])
            {
                if (seen.Add(dependent))
                {
                    result.Add(dependent);
                    queue.Enqueue(dependent);
                }
            }
        }
        return result;
    }

    public List<string> ProjectReferencesOf(string project)
    {
        var byPath = Manifest.Projects.ToDictionary(p => p.Path, p => p.Name, StringComparer.OrdinalIgnoreCase);
        return Projects.TryGetValue(project, out var p)
            ? p.ProjectReferences.Select(r => byPath.GetValueOrDefault(r) ?? Path.GetFileNameWithoutExtension(r)).ToList()
            : [];
    }

    public static string StripGeneric(string name)
    {
        var lt = name.IndexOf('<');
        return lt > 0 ? name[..lt] : name;
    }

    private static void Add<TValue>(Dictionary<string, List<TValue>> map, string key, TValue value)
    {
        if (!map.TryGetValue(key, out var list))
        {
            list = [];
            map[key] = list;
        }
        list.Add(value);
    }
}
