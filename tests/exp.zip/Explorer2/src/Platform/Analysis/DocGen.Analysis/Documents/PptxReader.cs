using System.Text;
using System.Xml.Linq;

namespace DocGen.Analysis.Documents;

public sealed class SlideObject
{
    /// <summary>picture | chart | table | shape | group | media | diagram</summary>
    public string Kind { get; init; } = "shape";

    public string Name { get; init; } = "";
    public string? Description { get; init; }
}

public sealed class SlideContent
{
    public int Number { get; init; }
    public bool Hidden { get; init; }
    public string? Title { get; set; }

    /// <summary>Body paragraphs with their outline level (0 = top).</summary>
    public List<(int Level, string Text)> Paragraphs { get; } = [];

    public List<List<List<string>>> Tables { get; } = [];
    public string? Notes { get; set; }
    public List<SlideObject> Objects { get; } = [];
    public string? Layout { get; set; }

    public string AllText => string.Join("\n", new[] { Title ?? "" }.Concat(Paragraphs.Select(p => p.Text)).Concat(Tables.SelectMany(t => t.Select(r => string.Join(" | ", r)))));
}

/// <summary>Reads .pptx presentations: slide order, titles, text with levels, tables, speaker notes and object metadata.</summary>
public static class PptxReader
{
    public static readonly XNamespace P = "http://schemas.openxmlformats.org/presentationml/2006/main";
    public static readonly XNamespace A = "http://schemas.openxmlformats.org/drawingml/2006/main";

    public static (Dictionary<string, string> Properties, List<SlideContent> Slides) Read(string path, int? onlySlide = null)
    {
        using var package = OfficePackage.Open(path);
        var root = package.Relationships("");
        var main = root.Values.FirstOrDefault(r => r.Type.EndsWith("/officeDocument", StringComparison.Ordinal)).Target is { Length: > 0 } t ? t : "ppt/presentation.xml";
        var presentation = package.Xml(main) ?? throw new Core.Exceptions.ValidationException("The file is not a PowerPoint presentation.");
        var rels = package.Relationships(main);
        var slides = new List<SlideContent>();
        var number = 0;
        foreach (var id in presentation.Root?.Element(P + "sldIdLst")?.Elements(P + "sldId") ?? [])
        {
            number++;
            if (onlySlide is { } only && only != number)
            {
                continue;
            }
            var rid = (string?)id.Attribute(OfficePackage.R + "id");
            if (rid is null || !rels.TryGetValue(rid, out var rel) || package.Xml(rel.Target)?.Root is not { } slideRoot)
            {
                continue;
            }
            var slide = new SlideContent { Number = number, Hidden = (string?)slideRoot.Attribute("show") == "0" };
            ReadShapes(slideRoot.Element(P + "cSld")?.Element(P + "spTree"), slide);
            var slideRels = package.Relationships(rel.Target);
            foreach (var (_, r) in slideRels)
            {
                if (r.Type.EndsWith("/notesSlide", StringComparison.Ordinal) && package.Xml(r.Target)?.Root is { } notes)
                {
                    var text = notes.Descendants(P + "sp")
                        .Where(sp => PlaceholderType(sp) is "body" or null && PlaceholderType(sp) != "sldNum")
                        .SelectMany(sp => sp.Descendants(A + "p").Select(Paragraph))
                        .Where(x => x.Length > 0);
                    slide.Notes = string.Join("\n", text) is { Length: > 0 } n ? n : null;
                }
                else if (r.Type.EndsWith("/slideLayout", StringComparison.Ordinal) && package.Xml(r.Target)?.Root is { } layout)
                {
                    slide.Layout = (string?)layout.Element(P + "cSld")?.Attribute("name");
                }
            }
            slides.Add(slide);
        }
        return (package.Properties(), slides);
    }

    public static int SlideCount(string path)
    {
        using var package = OfficePackage.Open(path);
        var main = package.Relationships("").Values.FirstOrDefault(r => r.Type.EndsWith("/officeDocument", StringComparison.Ordinal)).Target ?? "ppt/presentation.xml";
        return package.Xml(main)?.Root?.Element(P + "sldIdLst")?.Elements(P + "sldId").Count() ?? 0;
    }

    private static void ReadShapes(XElement? tree, SlideContent slide)
    {
        foreach (var e in tree?.Elements() ?? [])
        {
            var nv = e.Descendants(P + "cNvPr").FirstOrDefault();
            var name = (string?)nv?.Attribute("name") ?? "";
            var descr = (string?)nv?.Attribute("descr");
            if (e.Name == P + "sp")
            {
                var type = PlaceholderType(e);
                var paragraphs = e.Element(P + "txBody")?.Elements(A + "p").Select(p => (Level: (int?)p.Element(A + "pPr")?.Attribute("lvl") ?? 0, Text: Paragraph(p))).Where(p => p.Text.Length > 0).ToList() ?? [];
                if (type is "title" or "ctrTitle" && slide.Title is null)
                {
                    slide.Title = string.Join(" ", paragraphs.Select(p => p.Text));
                }
                else if (type is not ("sldNum" or "dt" or "ftr"))
                {
                    slide.Paragraphs.AddRange(paragraphs);
                }
            }
            else if (e.Name == P + "graphicFrame")
            {
                var data = e.Descendants(A + "graphicData").FirstOrDefault();
                var uri = (string?)data?.Attribute("uri") ?? "";
                if (data?.Descendants(A + "tbl").FirstOrDefault() is { } table)
                {
                    slide.Tables.Add(table.Elements(A + "tr").Select(tr => tr.Elements(A + "tc").Select(tc => string.Join(" ", tc.Descendants(A + "p").Select(Paragraph).Where(x => x.Length > 0))).ToList()).ToList());
                    slide.Objects.Add(new SlideObject { Kind = "table", Name = name, Description = descr });
                }
                else
                {
                    slide.Objects.Add(new SlideObject { Kind = uri.Contains("chart", StringComparison.Ordinal) ? "chart" : uri.Contains("diagram", StringComparison.Ordinal) ? "diagram" : "object", Name = name, Description = descr });
                }
            }
            else if (e.Name == P + "pic")
            {
                var media = e.Descendants(A + "videoFile").Any() || e.Descendants(A + "audioFile").Any();
                slide.Objects.Add(new SlideObject { Kind = media ? "media" : "picture", Name = name, Description = descr });
            }
            else if (e.Name == P + "grpSp")
            {
                slide.Objects.Add(new SlideObject { Kind = "group", Name = name, Description = descr });
                ReadShapes(e, slide);
            }
        }
    }

    private static string? PlaceholderType(XElement shape)
    {
        var ph = shape.Element(P + "nvSpPr")?.Element(P + "nvPr")?.Element(P + "ph");
        return ph is null ? null : (string?)ph.Attribute("type") ?? "body";
    }

    private static string Paragraph(XElement p)
    {
        var sb = new StringBuilder();
        foreach (var node in p.Elements())
        {
            if (node.Name == A + "r" || node.Name == A + "fld")
            {
                sb.Append(node.Element(A + "t")?.Value);
            }
            else if (node.Name == A + "br")
            {
                sb.Append('\n');
            }
        }
        return sb.ToString().Trim();
    }
}
