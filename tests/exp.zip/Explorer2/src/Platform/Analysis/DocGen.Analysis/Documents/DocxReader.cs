using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;

namespace DocGen.Analysis.Documents;

/// <summary>One block of a Word document in document order.</summary>
public sealed class DocBlock
{
    /// <summary>1-based paragraph/table number in document order (the ¶ citation).</summary>
    public int Index { get; init; }

    /// <summary>heading | paragraph | list | table</summary>
    public string Kind { get; init; } = "paragraph";

    /// <summary>Heading level (1–9), list level (0-based) or 0.</summary>
    public int Level { get; init; }

    public string Text { get; init; } = "";
    public string? Style { get; init; }

    /// <summary>Nearest preceding heading (the § citation).</summary>
    public string Section { get; init; } = "";

    /// <summary>For tables: rows of cell text; TableNumber is 1-based.</summary>
    public List<List<string>>? Rows { get; init; }

    public int TableNumber { get; init; }
    public List<(string Text, string Url)> Links { get; init; } = [];
}

public sealed class DocxDocument
{
    public Dictionary<string, string> Properties { get; set; } = [];
    public List<DocBlock> Blocks { get; set; } = [];
    public List<string> Headers { get; set; } = [];
    public List<string> Footers { get; set; } = [];
    public IEnumerable<DocBlock> Headings => Blocks.Where(b => b.Kind == "heading");
    public IEnumerable<DocBlock> Tables => Blocks.Where(b => b.Kind == "table");
    public int Words => Blocks.Sum(b => b.Kind == "table" ? b.Rows!.Sum(r => r.Sum(Count)) : Count(b.Text));

    private static int Count(string text) => text.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries).Length;
}

/// <summary>Reads .docx content in document order: headings, paragraphs, lists, tables, hyperlinks, headers/footers and properties.</summary>
public static partial class DocxReader
{
    public static readonly XNamespace W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";

    public static DocxDocument Read(string path)
    {
        using var package = OfficePackage.Open(path);
        var main = MainPart(package);
        var body = package.Xml(main)?.Root?.Element(W + "body") ?? throw new Core.Exceptions.ValidationException("The file has no Word document body.");
        var rels = package.Relationships(main);
        var styles = StyleNames(package);
        var doc = new DocxDocument { Properties = package.Properties() };
        var section = "";
        var index = 0;
        var tables = 0;
        foreach (var element in body.Elements())
        {
            if (element.Name == W + "p")
            {
                var (text, links) = ParagraphText(element, rels);
                if (text.Trim().Length == 0)
                {
                    continue;
                }
                var styleId = (string?)element.Element(W + "pPr")?.Element(W + "pStyle")?.Attribute(W + "val");
                var styleName = styleId is not null && styles.TryGetValue(styleId, out var n) ? n : styleId;
                var headingLevel = HeadingLevel(styleName, styleId, element);
                var numPr = element.Element(W + "pPr")?.Element(W + "numPr");
                index++;
                if (headingLevel > 0)
                {
                    section = text.Trim();
                    doc.Blocks.Add(new DocBlock { Index = index, Kind = "heading", Level = headingLevel, Text = text.Trim(), Style = styleName, Section = section, Links = links });
                }
                else if (numPr is not null || styleName?.StartsWith("List", StringComparison.OrdinalIgnoreCase) == true)
                {
                    var level = (int?)numPr?.Element(W + "ilvl")?.Attribute(W + "val") ?? 0;
                    doc.Blocks.Add(new DocBlock { Index = index, Kind = "list", Level = level, Text = text.Trim(), Style = styleName, Section = section, Links = links });
                }
                else
                {
                    doc.Blocks.Add(new DocBlock { Index = index, Kind = "paragraph", Text = text.Trim(), Style = styleName, Section = section, Links = links });
                }
            }
            else if (element.Name == W + "tbl")
            {
                index++;
                tables++;
                var rows = element.Elements(W + "tr")
                    .Select(tr => tr.Elements(W + "tc").Select(tc => string.Join(" ", tc.Descendants(W + "p").Select(p => ParagraphText(p, rels).Text.Trim()).Where(t => t.Length > 0))).ToList())
                    .ToList();
                doc.Blocks.Add(new DocBlock { Index = index, Kind = "table", TableNumber = tables, Rows = rows, Section = section, Text = string.Join(" | ", rows.FirstOrDefault() ?? []) });
            }
            else if (element.Name == W + "sdt")
            {
                // Content controls (e.g. a table of contents): read their paragraphs as plain text.
                foreach (var p in element.Descendants(W + "p"))
                {
                    var (text, links) = ParagraphText(p, rels);
                    if (text.Trim().Length > 0)
                    {
                        index++;
                        doc.Blocks.Add(new DocBlock { Index = index, Kind = "paragraph", Text = text.Trim(), Style = "content control", Section = section, Links = links });
                    }
                }
            }
        }
        foreach (var (_, (type, target, external)) in rels)
        {
            if (external)
            {
                continue;
            }
            var list = type.EndsWith("/header", StringComparison.Ordinal) ? doc.Headers : type.EndsWith("/footer", StringComparison.Ordinal) ? doc.Footers : null;
            if (list is not null && package.Xml(target)?.Root is { } root)
            {
                var text = string.Join(" ", root.Descendants(W + "p").Select(p => ParagraphText(p, []).Text.Trim()).Where(t => t.Length > 0));
                if (text.Length > 0 && !list.Contains(text))
                {
                    list.Add(text);
                }
            }
        }
        return doc;
    }

    private static string MainPart(OfficePackage package)
    {
        var root = package.Relationships("");
        return root.Values.FirstOrDefault(r => r.Type.EndsWith("/officeDocument", StringComparison.Ordinal)).Target is { Length: > 0 } t ? t : "word/document.xml";
    }

    private static Dictionary<string, string> StyleNames(OfficePackage package)
    {
        var result = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var s in package.Xml("word/styles.xml")?.Root?.Elements(W + "style") ?? [])
        {
            if ((string?)s.Attribute(W + "styleId") is { } id && (string?)s.Element(W + "name")?.Attribute(W + "val") is { } name)
            {
                result[id] = name;
            }
        }
        return result;
    }

    private static int HeadingLevel(string? styleName, string? styleId, XElement paragraph)
    {
        foreach (var candidate in new[] { styleName, styleId })
        {
            if (candidate is null)
            {
                continue;
            }
            if (candidate.Equals("Title", StringComparison.OrdinalIgnoreCase))
            {
                return 1;
            }
            var m = HeadingStyle().Match(candidate);
            if (m.Success)
            {
                return int.Parse(m.Groups[1].Value, System.Globalization.CultureInfo.InvariantCulture);
            }
        }
        var outline = (int?)paragraph.Element(W + "pPr")?.Element(W + "outlineLvl")?.Attribute(W + "val");
        return outline is { } o and < 9 ? o + 1 : 0;
    }

    public static (string Text, List<(string Text, string Url)> Links) ParagraphText(XElement paragraph, Dictionary<string, (string Type, string Target, bool External)> rels)
    {
        var sb = new StringBuilder();
        var links = new List<(string, string)>();
        foreach (var node in paragraph.Descendants())
        {
            if (node.Name == W + "t")
            {
                // Tracked deletions are w:delText and are intentionally not read.
                sb.Append(node.Value);
            }
            else if (node.Name == W + "tab")
            {
                sb.Append('\t');
            }
            else if (node.Name == W + "br" || node.Name == W + "cr")
            {
                sb.Append('\n');
            }
            else if (node.Name == W + "hyperlink")
            {
                var id = (string?)node.Attribute(OfficePackage.R + "id");
                var text = string.Concat(node.Descendants(W + "t").Select(t => t.Value));
                if (id is not null && rels.TryGetValue(id, out var rel) && rel.External)
                {
                    links.Add((text, rel.Target));
                }
                else if ((string?)node.Attribute(W + "anchor") is { } anchor)
                {
                    links.Add((text, "#" + anchor));
                }
            }
        }
        return (sb.ToString(), links);
    }

    [GeneratedRegex(@"^heading\s*([1-9])$", RegexOptions.IgnoreCase)]
    private static partial Regex HeadingStyle();
}
