using System.IO.Compression;
using System.Xml;
using System.Xml.Linq;
using DocGen.Core.Exceptions;

namespace DocGen.Analysis.Documents;

/// <summary>
/// Read-only access to an Office Open XML package (ZIP of XML parts) with the safety limits a document reader needs:
/// bounded file and part sizes (zip-bomb guard), no DTDs, no external entity resolution, and relationship targets
/// resolved strictly inside the package.
/// </summary>
public sealed class OfficePackage : IDisposable
{
    public const long MaxFileBytes = 200L * 1024 * 1024;
    public const long MaxPartBytes = 128L * 1024 * 1024;
    public const long MaxTotalReadBytes = 512L * 1024 * 1024;

    public static readonly XNamespace PackageRels = "http://schemas.openxmlformats.org/package/2006/relationships";
    public static readonly XNamespace R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";

    private readonly ZipArchive _zip;
    private long _read;

    private OfficePackage(ZipArchive zip, string path)
    {
        _zip = zip;
        FilePath = path;
    }

    public string FilePath { get; }

    public static OfficePackage Open(string path)
    {
        var info = new FileInfo(path);
        if (!info.Exists)
        {
            throw new NotFoundException("Document");
        }
        if (info.Length > MaxFileBytes)
        {
            throw new ValidationException($"The document is larger than {MaxFileBytes / 1024 / 1024} MB.");
        }
        try
        {
            return new OfficePackage(ZipFile.OpenRead(path), path);
        }
        catch (InvalidDataException)
        {
            throw new ValidationException(IsLegacy(path)
                ? "Legacy binary Office formats (.doc, .xls, .ppt) are not supported; save the file as .docx, .xlsx or .pptx."
                : "The file is not a valid Office Open XML package.");
        }
    }

    public static bool IsLegacy(string path) => Path.GetExtension(path).ToLowerInvariant() is ".doc" or ".xls" or ".ppt";

    public bool Exists(string part) => _zip.GetEntry(part.TrimStart('/')) is not null;

    public IEnumerable<string> Parts => _zip.Entries.Select(e => e.FullName);

    /// <summary>Loads an XML part, or null when it does not exist.</summary>
    public XDocument? Xml(string part)
    {
        var entry = _zip.GetEntry(part.TrimStart('/'));
        if (entry is null)
        {
            return null;
        }
        if (entry.Length > MaxPartBytes)
        {
            throw new ValidationException($"Part {part} is larger than {MaxPartBytes / 1024 / 1024} MB uncompressed.");
        }
        _read += entry.Length;
        if (_read > MaxTotalReadBytes)
        {
            throw new ValidationException("The document expands to more data than DocGen reads from one file.");
        }
        using var stream = entry.Open();
        using var bounded = new BoundedStream(stream, MaxPartBytes);
        using var reader = XmlReader.Create(bounded, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null, IgnoreComments = true });
        return XDocument.Load(reader);
    }

    /// <summary>Relationships of a part: id → (type, resolved part path or external URL, external).</summary>
    public Dictionary<string, (string Type, string Target, bool External)> Relationships(string part)
    {
        var dir = part.Contains('/', StringComparison.Ordinal) ? part[..part.LastIndexOf('/')] : "";
        var name = part.Contains('/', StringComparison.Ordinal) ? part[(part.LastIndexOf('/') + 1)..] : part;
        var rels = Xml((dir.Length == 0 ? "" : dir + "/") + "_rels/" + name + ".rels");
        var result = new Dictionary<string, (string, string, bool)>(StringComparer.Ordinal);
        foreach (var r in rels?.Root?.Elements(PackageRels + "Relationship") ?? [])
        {
            var id = (string?)r.Attribute("Id");
            var target = (string?)r.Attribute("Target");
            if (id is null || target is null)
            {
                continue;
            }
            var external = string.Equals((string?)r.Attribute("TargetMode"), "External", StringComparison.OrdinalIgnoreCase);
            result[id] = ((string?)r.Attribute("Type") ?? "", external ? target : Resolve(dir, target), external);
        }
        return result;
    }

    /// <summary>Resolves a relative relationship target against a part folder, never leaving the package root.</summary>
    public static string Resolve(string baseDir, string target)
    {
        var parts = new List<string>();
        var combined = target.StartsWith('/') ? target.TrimStart('/') : (baseDir.Length == 0 ? "" : baseDir + "/") + target;
        foreach (var segment in combined.Split('/'))
        {
            if (segment is "" or ".")
            {
                continue;
            }
            if (segment == "..")
            {
                if (parts.Count > 0)
                {
                    parts.RemoveAt(parts.Count - 1);
                }
                continue;
            }
            parts.Add(Uri.UnescapeDataString(segment));
        }
        return string.Join('/', parts);
    }

    /// <summary>Core and app properties (title, subject, creator, last modified by, created, modified, application…).</summary>
    public Dictionary<string, string> Properties()
    {
        var result = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var part in new[] { "docProps/core.xml", "docProps/app.xml" })
        {
            foreach (var e in Xml(part)?.Root?.Elements() ?? [])
            {
                if (!e.HasElements && e.Value.Trim() is { Length: > 0 } v && e.Name.LocalName is "title" or "subject" or "creator" or "lastModifiedBy" or "created" or "modified"
                        or "description" or "keywords" or "category" or "Application" or "Company" or "Pages" or "Words" or "Slides" or "Notes" or "revision")
                {
                    result[e.Name.LocalName] = v.Length > 200 ? v[..200] + "…" : v;
                }
            }
        }
        return result;
    }

    public void Dispose() => _zip.Dispose();

    /// <summary>Stops reading after a byte budget (defends against misreported entry sizes).</summary>
    private sealed class BoundedStream(Stream inner, long max) : Stream
    {
        private long _total;

        public override bool CanRead => true;
        public override bool CanSeek => false;
        public override bool CanWrite => false;
        public override long Length => throw new NotSupportedException();
        public override long Position { get => _total; set => throw new NotSupportedException(); }

        public override int Read(byte[] buffer, int offset, int count)
        {
            var n = inner.Read(buffer, offset, count);
            _total += n;
            return _total > max ? throw new ValidationException("A document part expands beyond the size limit.") : n;
        }

        public override void Flush()
        {
        }

        public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
        public override void SetLength(long value) => throw new NotSupportedException();
        public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();
    }
}
