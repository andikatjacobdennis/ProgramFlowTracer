using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using DocGen.Core.Exceptions;

namespace DocGen.Analysis.Documents;

public sealed class SheetInfo
{
    public string Name { get; init; } = "";
    public string State { get; init; } = "visible";
    public string Part { get; init; } = "";
    public int Index { get; init; }
}

public sealed class CellValue
{
    public string Reference { get; init; } = "";
    public int Row { get; init; }
    public int Column { get; init; }

    /// <summary>Displayable value: shared/inline strings resolved, booleans, errors, dates as ISO text, numbers invariant.</summary>
    public string Value { get; init; } = "";

    /// <summary>string | number | boolean | date | error | empty</summary>
    public string Type { get; init; } = "string";

    /// <summary>Formula text without '=' (shared formulas are expanded only for the anchor cell; others say "shared").</summary>
    public string? Formula { get; init; }
}

public sealed class TableInfo
{
    public string Name { get; init; } = "";
    public string Sheet { get; init; } = "";
    public string Range { get; init; } = "";
    public List<string> Columns { get; init; } = [];
}

public sealed class SheetData
{
    public required SheetInfo Info { get; init; }
    public string? Dimension { get; set; }
    public List<CellValue> Cells { get; set; } = [];
    public List<TableInfo> Tables { get; set; } = [];
    public int MergedRanges { get; set; }
    public (int MinRow, int MinCol, int MaxRow, int MaxCol)? Used => Cells.Count == 0 ? null
        : (Cells.Min(c => c.Row), Cells.Min(c => c.Column), Cells.Max(c => c.Row), Cells.Max(c => c.Column));
    public string UsedRange => Used is { } u ? $"{XlsxReader.Address(u.MinRow, u.MinCol)}:{XlsxReader.Address(u.MaxRow, u.MaxCol)}" : "(empty)";
}

/// <summary>
/// Reads .xlsx workbooks (SpreadsheetML): sheets, used ranges, cells with formulas and cached values, tables, named
/// ranges. Values are the cached results Excel saved — DocGen does not recalculate formulas.
/// </summary>
public sealed partial class XlsxReader : IDisposable
{
    public static readonly XNamespace S = "http://schemas.openxmlformats.org/spreadsheetml/2006/main";

    private readonly OfficePackage _package;
    private readonly string _workbookPart;
    private List<string>? _shared;
    private HashSet<int>? _dateStyles;

    private XlsxReader(OfficePackage package, string workbookPart)
    {
        _package = package;
        _workbookPart = workbookPart;
    }

    public static XlsxReader Open(string path)
    {
        var package = OfficePackage.Open(path);
        var root = package.Relationships("");
        var part = root.Values.FirstOrDefault(r => r.Type.EndsWith("/officeDocument", StringComparison.Ordinal)).Target is { Length: > 0 } t ? t : "xl/workbook.xml";
        if (!package.Exists(part))
        {
            package.Dispose();
            throw new ValidationException("The file is not an Excel workbook.");
        }
        return new XlsxReader(package, part);
    }

    public Dictionary<string, string> Properties() => _package.Properties();

    public List<SheetInfo> Sheets()
    {
        var workbook = _package.Xml(_workbookPart)!;
        var rels = _package.Relationships(_workbookPart);
        var list = new List<SheetInfo>();
        var i = 0;
        foreach (var s in workbook.Root?.Element(S + "sheets")?.Elements(S + "sheet") ?? [])
        {
            var id = (string?)s.Attribute(OfficePackage.R + "id");
            if (id is null || !rels.TryGetValue(id, out var rel) || !rel.Type.EndsWith("/worksheet", StringComparison.Ordinal))
            {
                continue; // chart sheets and dialog sheets have no cells
            }
            list.Add(new SheetInfo { Name = (string?)s.Attribute("name") ?? $"Sheet{i + 1}", State = (string?)s.Attribute("state") ?? "visible", Part = rel.Target, Index = ++i });
        }
        return list;
    }

    /// <summary>Workbook-level defined names (named ranges) → reference text.</summary>
    public List<(string Name, string Reference, string? Scope)> DefinedNames()
    {
        var workbook = _package.Xml(_workbookPart)!;
        var sheets = Sheets();
        return (workbook.Root?.Element(S + "definedNames")?.Elements(S + "definedName") ?? [])
            .Select(d => ((string?)d.Attribute("name") ?? "", d.Value,
                (int?)d.Attribute("localSheetId") is { } local && local < sheets.Count ? sheets[local].Name : null))
            .Where(d => d.Item1.Length > 0 && !d.Item1.StartsWith("_xlnm._FilterDatabase", StringComparison.Ordinal))
            .ToList();
    }

    public SheetInfo Sheet(string? name)
    {
        var sheets = Sheets();
        if (sheets.Count == 0)
        {
            throw new ValidationException("The workbook has no worksheets.");
        }
        return name is null or "" ? sheets[0]
            : sheets.FirstOrDefault(s => s.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
              ?? throw new NotFoundException($"Sheet '{name}' (sheets: {string.Join(", ", sheets.Select(s => s.Name))})");
    }

    /// <summary>Reads a sheet's cells (optionally only those inside a range) plus its tables and merged ranges.</summary>
    public SheetData Read(SheetInfo sheet, (int R1, int C1, int R2, int C2)? range = null, int maxCells = 1_000_000)
    {
        var xml = _package.Xml(sheet.Part) ?? throw new ValidationException($"Sheet part {sheet.Part} is missing.");
        var data = new SheetData { Info = sheet, Dimension = (string?)xml.Root?.Element(S + "dimension")?.Attribute("ref") };
        var shared = SharedStrings();
        var dates = DateStyles();
        foreach (var row in xml.Root?.Element(S + "sheetData")?.Elements(S + "row") ?? [])
        {
            foreach (var c in row.Elements(S + "c"))
            {
                var reference = (string?)c.Attribute("r");
                if (reference is null || !TryParseAddress(reference, out var r, out var col))
                {
                    continue;
                }
                if (range is { } g && (r < g.R1 || r > g.R2 || col < g.C1 || col > g.C2))
                {
                    continue;
                }
                var cell = ReadCell(c, reference, r, col, shared, dates);
                if (cell.Type == "empty" && cell.Formula is null)
                {
                    continue;
                }
                data.Cells.Add(cell);
                if (data.Cells.Count >= maxCells)
                {
                    break;
                }
            }
        }
        data.MergedRanges = xml.Root?.Element(S + "mergeCells")?.Elements(S + "mergeCell").Count() ?? 0;
        foreach (var (_, rel) in _package.Relationships(sheet.Part).Where(p => p.Value.Type.EndsWith("/table", StringComparison.Ordinal)))
        {
            if (_package.Xml(rel.Target)?.Root is { } t)
            {
                data.Tables.Add(new TableInfo
                {
                    Name = (string?)t.Attribute("displayName") ?? (string?)t.Attribute("name") ?? "",
                    Sheet = sheet.Name,
                    Range = (string?)t.Attribute("ref") ?? "",
                    Columns = t.Element(S + "tableColumns")?.Elements(S + "tableColumn").Select(tc => (string?)tc.Attribute("name") ?? "").ToList() ?? [],
                });
            }
        }
        return data;
    }

    private static CellValue ReadCell(XElement c, string reference, int row, int col, List<string> shared, HashSet<int> dates)
    {
        var t = (string?)c.Attribute("t") ?? "n";
        var raw = c.Element(S + "v")?.Value;
        var f = c.Element(S + "f");
        string? formula = f is null ? null : f.Value.Length > 0 ? f.Value : (string?)f.Attribute("t") == "shared" ? $"(shared formula #{(string?)f.Attribute("si")})" : null;
        string type;
        string value;
        switch (t)
        {
            case "s":
                type = "string";
                value = int.TryParse(raw, NumberStyles.Integer, CultureInfo.InvariantCulture, out var i) && i >= 0 && i < shared.Count ? shared[i] : "";
                break;
            case "inlineStr":
                type = "string";
                value = string.Concat(c.Element(S + "is")?.Descendants(S + "t").Select(x => x.Value) ?? []);
                break;
            case "str":
                type = "string";
                value = raw ?? "";
                break;
            case "b":
                type = "boolean";
                value = raw == "1" ? "TRUE" : "FALSE";
                break;
            case "e":
                type = "error";
                value = raw ?? "#ERROR";
                break;
            default:
                if (raw is null or "")
                {
                    type = "empty";
                    value = "";
                }
                else if ((int?)c.Attribute("s") is { } style && dates.Contains(style) && double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out var oa) && oa is > -657435 and < 2958466)
                {
                    type = "date";
                    var dt = DateTime.FromOADate(oa);
                    value = dt.TimeOfDay == TimeSpan.Zero ? dt.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) : dt.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
                }
                else
                {
                    type = "number";
                    value = double.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out var d) ? d.ToString("G15", CultureInfo.InvariantCulture) : raw;
                }
                break;
        }
        return new CellValue { Reference = reference, Row = row, Column = col, Value = value, Type = type, Formula = formula };
    }

    private List<string> SharedStrings()
    {
        if (_shared is not null)
        {
            return _shared;
        }
        var rel = _package.Relationships(_workbookPart).Values.FirstOrDefault(r => r.Type.EndsWith("/sharedStrings", StringComparison.Ordinal));
        var xml = _package.Xml(rel.Target is { Length: > 0 } t ? t : "xl/sharedStrings.xml");
        _shared = xml?.Root?.Elements(S + "si").Select(si => si.Element(S + "t") is { } plain ? plain.Value : string.Concat(si.Elements(S + "r").Select(r => r.Element(S + "t")?.Value))).ToList() ?? [];
        return _shared;
    }

    /// <summary>Style indexes (cellXfs) whose number format is a date/time format.</summary>
    private HashSet<int> DateStyles()
    {
        if (_dateStyles is not null)
        {
            return _dateStyles;
        }
        _dateStyles = [];
        var rel = _package.Relationships(_workbookPart).Values.FirstOrDefault(r => r.Type.EndsWith("/styles", StringComparison.Ordinal));
        var styles = _package.Xml(rel.Target is { Length: > 0 } t ? t : "xl/styles.xml")?.Root;
        if (styles is null)
        {
            return _dateStyles;
        }
        var custom = styles.Element(S + "numFmts")?.Elements(S + "numFmt")
            .Where(n => IsDateFormat((string?)n.Attribute("formatCode") ?? ""))
            .Select(n => (int?)n.Attribute("numFmtId") ?? -1).ToHashSet() ?? [];
        var i = 0;
        foreach (var xf in styles.Element(S + "cellXfs")?.Elements(S + "xf") ?? [])
        {
            var id = (int?)xf.Attribute("numFmtId") ?? 0;
            if (id is >= 14 and <= 22 or >= 45 and <= 47 || custom.Contains(id))
            {
                _dateStyles.Add(i);
            }
            i++;
        }
        return _dateStyles;
    }

    public static bool IsDateFormat(string code)
    {
        var stripped = QuotedOrEscaped().Replace(code, "");
        return DateTokens().IsMatch(stripped) && !stripped.Contains("General", StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>"B12" → (12, 2).</summary>
    public static bool TryParseAddress(string reference, out int row, out int column)
    {
        row = 0;
        column = 0;
        var m = AddressPattern().Match(reference.Replace("$", "", StringComparison.Ordinal));
        if (!m.Success)
        {
            return false;
        }
        foreach (var ch in m.Groups[1].Value.ToUpperInvariant())
        {
            column = column * 26 + (ch - 'A' + 1);
        }
        row = int.Parse(m.Groups[2].Value, CultureInfo.InvariantCulture);
        return column is > 0 and <= 16384 && row is > 0 and <= 1_048_576;
    }

    /// <summary>"A1:D20" (also "B:B" or "3:5") → bounds.</summary>
    public static (int R1, int C1, int R2, int C2) ParseRange(string range)
    {
        var parts = range.Replace("$", "", StringComparison.Ordinal).Split(':');
        if (parts.Length is < 1 or > 2)
        {
            throw new ValidationException($"'{range}' is not a cell range (use A1:D20).");
        }
        (int, int) Corner(string p, bool end)
        {
            if (TryParseAddress(p, out var r, out var c))
            {
                return (r, c);
            }
            if (ColumnOnly().IsMatch(p))
            {
                TryParseAddress(p + "1", out _, out c);
                return (end ? 1_048_576 : 1, c);
            }
            if (int.TryParse(p, NumberStyles.Integer, CultureInfo.InvariantCulture, out r))
            {
                return (r, end ? 16384 : 1);
            }
            throw new ValidationException($"'{range}' is not a cell range (use A1:D20).");
        }
        var (r1, c1) = Corner(parts[0], false);
        var (r2, c2) = Corner(parts.Length == 2 ? parts[1] : parts[0], true);
        return (Math.Min(r1, r2), Math.Min(c1, c2), Math.Max(r1, r2), Math.Max(c1, c2));
    }

    public static string ColumnName(int column)
    {
        var sb = new StringBuilder();
        while (column > 0)
        {
            var m = (column - 1) % 26;
            sb.Insert(0, (char)('A' + m));
            column = (column - 1) / 26;
        }
        return sb.ToString();
    }

    public static string Address(int row, int column) => ColumnName(column) + row.ToString(CultureInfo.InvariantCulture);

    public void Dispose() => _package.Dispose();

    [GeneratedRegex(@"^([A-Za-z]{1,3})(\d{1,7})$")]
    private static partial Regex AddressPattern();

    [GeneratedRegex(@"^[A-Za-z]{1,3}$")]
    private static partial Regex ColumnOnly();

    [GeneratedRegex(@"""[^""]*""|\\.|\[[^\]]*\]")]
    private static partial Regex QuotedOrEscaped();

    [GeneratedRegex(@"[dDyY]|[hH]|(?<![a-zA-Z])m{1,5}(?![a-zA-Z])|[sS]")]
    private static partial Regex DateTokens();
}
