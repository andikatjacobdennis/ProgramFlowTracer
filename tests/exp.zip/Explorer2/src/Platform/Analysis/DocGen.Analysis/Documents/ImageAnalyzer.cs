using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using DocGen.Analysis.Commands;
using DocGen.Analysis.Tools;
using DocGen.Core.Abstractions;
using DocGen.Data.Storage;
using Microsoft.Extensions.Logging;

namespace DocGen.Analysis.Documents;

/// <summary>
/// OCR and image classification with the Windows OCR engine (Windows.Media.Ocr), driven through Windows PowerShell 5.1 —
/// no packages. A fixed, DocGen-owned script runs through <see cref="CommandRunner"/> (owned, logged, timed out); the
/// image path is passed in an environment variable, never interpolated into the script. Results are cached per file
/// content hash. Classification is a heuristic over word count, text coverage and colour flatness.
/// </summary>
public sealed class ImageAnalyzer(AnalysisServices services, IJsonStore store, ILogger<ImageAnalyzer> logger) : IImageAnalyzer
{
    public const long MaxImageBytes = 25L * 1024 * 1024;

    private static readonly HashSet<string> Extensions = new(StringComparer.OrdinalIgnoreCase) { ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".webp" };

    public bool IsImage(string fileName) => Extensions.Contains(Path.GetExtension(fileName));

    public async Task<ImageAnalysis> AnalyzeAsync(string userId, string fullPath, CancellationToken cancellationToken)
    {
        var info = new FileInfo(fullPath);
        if (!info.Exists)
        {
            return new ImageAnalysis { Error = "The image file does not exist." };
        }
        if (info.Length > MaxImageBytes)
        {
            return new ImageAnalysis { Error = $"The image is larger than {MaxImageBytes / 1024 / 1024} MB." };
        }
        string hash;
        await using (var stream = info.OpenRead())
        {
            hash = Convert.ToHexStringLower(await SHA256.HashDataAsync(stream, cancellationToken));
        }
        var cachePath = $"ocr/{hash[..2]}/{hash}.json";
        if (await store.ReadAsync<ImageAnalysis>(cachePath, cancellationToken) is { Error: null } cached)
        {
            return cached;
        }

        var result = await RunOcrAsync(userId, fullPath, cancellationToken);
        if (result.Error is null)
        {
            await store.WriteAsync(cachePath, result, cancellationToken);
        }
        return result;
    }

    private async Task<ImageAnalysis> RunOcrAsync(string userId, string fullPath, CancellationToken ct)
    {
        var windowsPowerShell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows), "System32", "WindowsPowerShell", "v1.0", "powershell.exe");
        if (!OperatingSystem.IsWindows() || !File.Exists(windowsPowerShell))
        {
            return new ImageAnalysis { Error = "Image OCR needs the Windows OCR engine (Windows PowerShell 5.1), which is not available on this machine." };
        }
        var encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(Script));
        var (record, stdout) = await services.Commands.RunCaptureAsync(userId, new ProcessLaunch
        {
            Kind = CommandKinds.Process, ExecutableName = "powershell", ExecutablePath = windowsPowerShell,
            Arguments = ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-EncodedCommand", encoded],
            WorkingDirectory = Path.GetDirectoryName(fullPath)!, Repository = "workspace",
            DisplayCommand = $"Windows OCR: {Path.GetFileName(fullPath)}", Description = "Read text from an image (Windows OCR)",
            Environment = new Dictionary<string, string> { ["OCR_IMAGE_PATH"] = fullPath }, TimeoutSeconds = 90, Risk = "ReadOnly",
        }, 16 * 1024 * 1024, ct);
        var text = Encoding.UTF8.GetString(stdout).Trim();
        var start = text.IndexOf('{');
        if (record.Status != CommandStatus.Succeeded || start < 0)
        {
            var reason = string.Join(" ", record.Tail.TakeLast(3)).Trim();
            logger.LogWarning("Image OCR failed for {File}: {Status} {Reason}", Path.GetFileName(fullPath), record.Status, reason);
            return new ImageAnalysis { Error = "The image could not be read" + (reason.Length > 0 ? ": " + reason : $" ({record.Status}).") };
        }
        try
        {
            return Classify(JsonDocument.Parse(text[start..]).RootElement);
        }
        catch (JsonException ex)
        {
            return new ImageAnalysis { Error = "Unexpected OCR output: " + ex.Message };
        }
    }

    /// <summary>Builds the analysis from the OCR script's JSON (public for tests).</summary>
    public static ImageAnalysis Classify(JsonElement json)
    {
        var a = new ImageAnalysis
        {
            Width = json.GetProperty("width").GetInt32(),
            Height = json.GetProperty("height").GetInt32(),
            Language = json.TryGetProperty("language", out var lang) ? lang.GetString() : null,
            ColorFlatness = json.TryGetProperty("flatness", out var f) && f.ValueKind == JsonValueKind.Number ? f.GetDouble() : -1,
            Engine = "Windows OCR",
        };
        double covered = 0;
        foreach (var line in json.GetProperty("lines").EnumerateArray())
        {
            var words = line.GetProperty("words").EnumerateArray().ToList();
            if (words.Count == 0)
            {
                continue;
            }
            double x1 = double.MaxValue, y1 = double.MaxValue, x2 = 0, y2 = 0;
            foreach (var w in words)
            {
                var (x, y, ww, hh) = (w.GetProperty("x").GetDouble(), w.GetProperty("y").GetDouble(), w.GetProperty("w").GetDouble(), w.GetProperty("h").GetDouble());
                covered += ww * hh;
                x1 = Math.Min(x1, x); y1 = Math.Min(y1, y); x2 = Math.Max(x2, x + ww); y2 = Math.Max(y2, y + hh);
                a.WordCount++;
            }
            a.Lines.Add(new ImageTextLine(line.GetProperty("text").GetString() ?? "", Math.Round(x1), Math.Round(y1), Math.Round(x2 - x1), Math.Round(y2 - y1)));
        }
        a.Text = string.Join("\n", a.Lines.Select(l => l.Text));
        a.TextCoverage = a.Width * a.Height > 0 ? Math.Round(Math.Min(1, covered / (a.Width * (double)a.Height)), 4) : 0;
        (a.Kind, a.KindLabel) = Kind(a.WordCount, a.TextCoverage, a.ColorFlatness);
        a.HasText = a.WordCount >= 3;
        return a;
    }

    /// <summary>Heuristic classification: lots of text vs some vs none, crossed with flat colours (graphic/screenshot) vs photo.</summary>
    public static (string Kind, string Label) Kind(int words, double coverage, double flatness)
    {
        var flat = flatness < 0 || flatness >= 0.45;
        if (words >= 25 || coverage >= 0.06)
        {
            return flat ? ("text-document", "Text: a document, screenshot or scan") : ("photo-of-text", "Photo of text (e.g. a page, sign or screen)");
        }
        if (words >= 3)
        {
            return flat ? ("graphic-with-text", "Diagram, chart or graphic with some text") : ("photo-with-text", "Photo with some text in it");
        }
        return flat ? ("graphic", "Graphic without text (icon, logo, illustration)") : ("photo", "Photo without text");
    }

    public static string Describe(ImageAnalysis a, string name, int maxChars = 12_000) => ImageText.Describe(a, name, maxChars);

    /// <summary>Windows PowerShell 5.1: decode (scaled to the OCR limit), OCR, and colour statistics from a 64×64 thumbnail; prints JSON.</summary>
    private const string Script = """
        $ErrorActionPreference = 'Stop'
        [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
        $path = $env:OCR_IMAGE_PATH
        Add-Type -AssemblyName System.Runtime.WindowsRuntime
        $null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
        $null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
        $null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
        $asTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1
        function Await($op, [Type]$type) { $t = $asTask.MakeGenericMethod($type).Invoke($null, @($op)); $t.Wait(); $t.Result }
        $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
        $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
        $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
        $w = [int]$decoder.PixelWidth; $h = [int]$decoder.PixelHeight
        $max = [Windows.Media.Ocr.OcrEngine]::MaxImageDimension
        $scale = [Math]::Min(1.0, $max / [double][Math]::Max($w, $h))
        $transform = New-Object Windows.Graphics.Imaging.BitmapTransform
        if ($scale -lt 1.0) { $transform.ScaledWidth = [uint32]($w * $scale); $transform.ScaledHeight = [uint32]($h * $scale) }
        $bitmap = Await ($decoder.GetSoftwareBitmapAsync([Windows.Graphics.Imaging.BitmapPixelFormat]::Bgra8, [Windows.Graphics.Imaging.BitmapAlphaMode]::Premultiplied, $transform, [Windows.Graphics.Imaging.ExifOrientationMode]::RespectExifOrientation, [Windows.Graphics.Imaging.ColorManagementMode]::DoNotColorManage)) ([Windows.Graphics.Imaging.SoftwareBitmap])
        $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
        if ($null -eq $engine) { throw 'No OCR language is installed in Windows.' }
        $result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
        $lines = @($result.Lines | ForEach-Object {
          $words = @($_.Words | ForEach-Object { [ordered]@{ t = $_.Text; x = $_.BoundingRect.X / $scale; y = $_.BoundingRect.Y / $scale; w = $_.BoundingRect.Width / $scale; h = $_.BoundingRect.Height / $scale } })
          [ordered]@{ text = $_.Text; words = $words } })
        $flatness = $null
        try {
          Add-Type -AssemblyName System.Drawing
          $img = [System.Drawing.Image]::FromFile($path)
          $thumb = New-Object System.Drawing.Bitmap 64, 64
          $g = [System.Drawing.Graphics]::FromImage($thumb); $g.DrawImage($img, 0, 0, 64, 64); $g.Dispose(); $img.Dispose()
          $counts = @{}
          for ($y = 0; $y -lt 64; $y++) { for ($x = 0; $x -lt 64; $x++) { $c = $thumb.GetPixel($x, $y); $k = (($c.R -shr 4) -shl 8) -bor (($c.G -shr 4) -shl 4) -bor ($c.B -shr 4); $counts[$k] = 1 + [int]$counts[$k] } }
          $thumb.Dispose()
          $top = ($counts.Values | Sort-Object -Descending | Select-Object -First 8 | Measure-Object -Sum).Sum
          $flatness = [Math]::Round($top / 4096.0, 4)
        } catch { $flatness = $null }
        [ordered]@{ width = $w; height = $h; language = $engine.RecognizerLanguage.LanguageTag; flatness = $flatness; lines = $lines } | ConvertTo-Json -Depth 6 -Compress
        """;
}
