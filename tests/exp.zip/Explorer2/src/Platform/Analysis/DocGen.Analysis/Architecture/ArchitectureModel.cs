using System.Text.RegularExpressions;
using DocGen.Analysis.CSharp;
using DocGen.Analysis.Indexing;

namespace DocGen.Analysis.Architecture;

/// <summary>Complexity and size of one method (or other callable member), measured from its tokens.</summary>
public sealed record MethodMetrics(int LinesOfCode, int CyclomaticComplexity, int ParameterCount, int DependencyCalls, int BranchCount);

public sealed class TypeMetrics
{
    public int LinesOfCode { get; set; }
    public int SourceLines { get; set; }
    public int CommentLines { get; set; }
    public int BlankLines { get; set; }
    public int MethodCount { get; set; }
    public int ConstructorCount { get; set; }
    public int PropertyCount { get; set; }
    public int FieldCount { get; set; }
    public int EventCount { get; set; }
    public int PublicMethodCount { get; set; }
    public int PrivateMethodCount { get; set; }
    public int StaticMethodCount { get; set; }
    public int AsyncMethodCount { get; set; }
    public int DependencyCount { get; set; }
    public int FanIn { get; set; }
    public int FanOut { get; set; }
    public int? InheritanceDepth { get; set; }
    public int InterfaceCount { get; set; }
    public int CyclomaticComplexity { get; set; }
    public double AverageMethodComplexity { get; set; }
    public int MaximumMethodComplexity { get; set; }
}

public sealed class TypeNode
{
    public required SymbolRecord Symbol { get; init; }
    public string Id => "type:" + Symbol.FullName;
    public List<SymbolRecord> Members { get; } = [];
    public TypeMetrics Metrics { get; } = new();

    /// <summary>1 = detailed page, 2 = moderate, 3 = inventory only (see the architect skill's tiers).</summary>
    public int Tier { get; set; } = 3;

    public List<string> TierReasons { get; } = [];
    public bool Generated { get; set; }
}

public sealed class MethodNode
{
    public required SymbolRecord Symbol { get; init; }
    public required TypeNode? Declaring { get; init; }
    public required MethodMetrics Metrics { get; init; }
    public string Id => $"method:{Symbol.FullName}({string.Join(",", Symbol.ParameterTypes)})";

    /// <summary>Methods this one calls that resolve to exactly one method in the repository (name-based).</summary>
    public List<string> ResolvedCalls { get; } = [];

    /// <summary>Call names that match several methods (dynamic dispatch or overloads): edges marked uncertain.</summary>
    public List<string> AmbiguousCalls { get; } = [];

    public bool Important { get; set; }
}

/// <param name="Evidence">How the relationship was found (constructor_injection, base_list, ProjectReference…).</param>
/// <param name="Confidence">high (declared), medium (name-based, unique match), low (name-based, several matches).</param>
public sealed record Relationship(string Source, string Target, string Kind, string Evidence, string Confidence);

public sealed class ProjectNode
{
    public required ProjectInfo Info { get; init; }
    public string Id => "project:" + Info.Name;
    public List<string> Files { get; } = [];
    public List<TypeNode> Types { get; } = [];
    /// <summary>Names of the projects it references (the index stores paths; these are resolved to names).</summary>
    public List<string> References { get; } = [];

    public List<string> Dependents { get; } = [];
    public List<string> EntryPoints { get; } = [];
    public int SourceLines { get; set; }
    public int CommentLines { get; set; }
    public int BlankLines { get; set; }
    public int TestMethods { get; set; }
}

public sealed record EntityNode(string Name, string Type, string? DbContext, string File, IReadOnlyList<(string Property, string Type)> Properties,
    IReadOnlyList<(string Property, string Target, string Evidence)> References);

/// <summary>The canonical model of a repository: every document, diagram and metric is rendered from this.</summary>
public sealed class ArchitectureModel
{
    public required string Repository { get; init; }
    public required string Root { get; init; }
    public DateTime GeneratedAt { get; } = DateTime.UtcNow;
    public Dictionary<string, ProjectNode> Projects { get; } = new(StringComparer.OrdinalIgnoreCase);
    public List<TypeNode> Types { get; } = [];
    public List<MethodNode> Methods { get; } = [];
    public List<Relationship> Relationships { get; } = [];
    public List<EndpointRecord> Endpoints { get; } = [];
    public List<DiRegistration> Registrations { get; } = [];
    public List<ConfigReference> ConfigReads { get; } = [];
    public List<string> ConfigKeysDefined { get; } = [];
    public List<EntityNode> Entities { get; } = [];
    public List<string> DbContexts { get; } = [];
    public Dictionary<string, (int Files, int Lines)> Languages { get; } = new(StringComparer.OrdinalIgnoreCase);
    public List<string> Exclusions { get; } = [];
    public List<string> GeneratedFiles { get; } = [];
    public List<string> UnparsedLanguages { get; } = [];
    public List<List<string>> ProjectCycles { get; } = [];
    public int FilesDiscovered { get; set; }
    public int FilesAnalyzed { get; set; }
    public int TestMethods { get; set; }
}

/// <summary>
/// Builds the <see cref="ArchitectureModel"/> from the code index (types, members, calls, DI, endpoints, config) and
/// the source text (line counts, complexity). Resolution is by name, like the index: every relationship carries its
/// evidence and a confidence so nothing inferred is presented as certain.
/// </summary>
public static partial class ArchitectureModelBuilder
{
    private static readonly HashSet<string> Keywords = new(StringComparer.Ordinal)
    {
        "static", "async", "unsafe", "extern", "new", "return", "await", "var", "void", "if", "for", "foreach", "while", "switch", "using", "lock",
    };

    private static readonly HashSet<string> ExcludedDirectories = new(StringComparer.OrdinalIgnoreCase)
    {
        ".git", ".vs", ".vscode", ".idea", "node_modules", "bin", "obj", "dist", "build", "out", "coverage", "TestResults", "packages",
        "__pycache__", ".venv", "venv", "target", ".next", ".nuget",
    };

    private static readonly Dictionary<string, string> LanguageByExtension = new(StringComparer.OrdinalIgnoreCase)
    {
        [".cs"] = "C#", [".razor"] = "Razor", [".cshtml"] = "Razor", [".js"] = "JavaScript", [".mjs"] = "JavaScript", [".ts"] = "TypeScript", [".tsx"] = "TypeScript",
        [".jsx"] = "JavaScript", [".py"] = "Python", [".java"] = "Java", [".kt"] = "Kotlin", [".go"] = "Go", [".rs"] = "Rust", [".rb"] = "Ruby", [".php"] = "PHP",
        [".cpp"] = "C++", [".cc"] = "C++", [".c"] = "C", [".h"] = "C/C++ header", [".swift"] = "Swift", [".sql"] = "SQL", [".css"] = "CSS", [".scss"] = "SCSS",
        [".html"] = "HTML", [".ps1"] = "PowerShell", [".sh"] = "Shell", [".fs"] = "F#", [".vb"] = "Visual Basic",
    };

    private static readonly string[] Tier1Suffixes =
    [
        "Service", "Controller", "Repository", "Handler", "Worker", "Middleware", "Manager", "Orchestrator", "Provider", "Client", "Store",
        "Gateway", "Adapter", "Processor", "Engine", "Registry", "Loop", "Hub", "Consumer", "Producer", "Job", "Scheduler", "Context", "Tool",
    ];

    public static ArchitectureModel Build(string repositoryName, CodeIndex index, bool includeTests, CancellationToken ct)
    {
        var model = new ArchitectureModel { Repository = repositoryName, Root = index.Root };
        ScanFiles(model, index.Root, ct);

        foreach (var (name, info) in index.Projects)
        {
            if (!includeTests && info.IsTestProject)
            {
                continue;
            }
            model.Projects[name] = new ProjectNode { Info = info };
        }
        foreach (var project in model.Projects.Values)
        {
            project.References.AddRange(index.ProjectReferencesOf(project.Info.Name).Where(model.Projects.ContainsKey).Distinct(StringComparer.OrdinalIgnoreCase));
        }
        foreach (var project in model.Projects.Values)
        {
            project.Dependents.AddRange(model.Projects.Values.Where(p => p.References.Contains(project.Info.Name, StringComparer.OrdinalIgnoreCase)).Select(p => p.Info.Name));
            foreach (var reference in project.References)
            {
                model.Relationships.Add(new Relationship(project.Id, "project:" + reference, "depends_on", "ProjectReference", "high"));
            }
        }
        FindCycles(model);

        // Files, line counts and generated code per project.
        foreach (var file in index.Files.Values.Where(f => f.Language == "cs"))
        {
            ct.ThrowIfCancellationRequested();
            if (!model.Projects.TryGetValue(file.Project, out var project))
            {
                continue;
            }
            if (IsGenerated(file.Path))
            {
                model.GeneratedFiles.Add(file.Path);
                continue;
            }
            project.Files.Add(file.Path);
            var (source, comment, blank) = CountLines(ReadLines(index.Root, file.Path), 1, int.MaxValue);
            (project.SourceLines, project.CommentLines, project.BlankLines) = (project.SourceLines + source, project.CommentLines + comment, project.BlankLines + blank);
        }

        // Types and their members.
        var typeByFull = new Dictionary<string, TypeNode>(StringComparer.Ordinal);
        foreach (var symbol in index.Types.Where(t => model.Projects.ContainsKey(t.Project) && (includeTests || !t.IsTest)))
        {
            // Partial types appear once per declaration; the first stands for all (MembersOf spans every part).
            if (IsGenerated(symbol.File) || typeByFull.ContainsKey(symbol.FullName))
            {
                continue;
            }
            var node = new TypeNode { Symbol = symbol };
            node.Members.AddRange(index.MembersOf(symbol.FullName).Where(m => !SymbolKinds.IsType(m.Kind)));
            typeByFull[symbol.FullName] = node;
            model.Types.Add(node);
            model.Projects[symbol.Project].Types.Add(node);
        }
        var typesByName = model.Types.GroupBy(t => t.Symbol.Name, StringComparer.Ordinal).ToDictionary(g => g.Key, g => g.ToList(), StringComparer.Ordinal);

        // Methods: size and complexity from the source tokens.
        var fileCache = new Dictionary<string, string[]>(StringComparer.OrdinalIgnoreCase);
        string[] Lines(string file) => fileCache.TryGetValue(file, out var cached) ? cached : fileCache[file] = ReadLines(index.Root, file);
        var methodIds = new HashSet<string>(StringComparer.Ordinal);
        foreach (var type in model.Types)
        {
            ct.ThrowIfCancellationRequested();
            var lines = Lines(type.Symbol.File);
            var (src, com, bl) = CountLines(lines, type.Symbol.StartLine, type.Symbol.EndLine);
            var m = type.Metrics;
            (m.LinesOfCode, m.SourceLines, m.CommentLines, m.BlankLines) = (Math.Max(0, type.Symbol.EndLine - type.Symbol.StartLine + 1), src, com, bl);
            foreach (var member in type.Members)
            {
                // A local function such as `static (int, int) Key(...)` can reach the index as a member named after a
                // keyword, and a partial method's declaration repeats its implementation; neither is a separate method.
                if (member.Kind is SymbolKinds.Method or SymbolKinds.Constructor &&
                    (Keywords.Contains(member.Name) || !methodIds.Add($"{member.FullName}({string.Join(",", member.ParameterTypes)})")))
                {
                    continue;
                }
                switch (member.Kind)
                {
                    case SymbolKinds.Method:
                        m.MethodCount++;
                        if (member.Modifiers.Contains("public")) m.PublicMethodCount++;
                        if (member.Modifiers.Contains("private") || !member.Modifiers.Any(x => x is "public" or "internal" or "protected")) m.PrivateMethodCount++;
                        if (member.Modifiers.Contains("static")) m.StaticMethodCount++;
                        if (member.Modifiers.Contains("async")) m.AsyncMethodCount++;
                        break;
                    case SymbolKinds.Constructor: m.ConstructorCount++; break;
                    case SymbolKinds.Property or SymbolKinds.Indexer: m.PropertyCount++; break;
                    case SymbolKinds.Field: m.FieldCount++; break;
                    case SymbolKinds.Event: m.EventCount++; break;
                }
                if (member.Kind is SymbolKinds.Method or SymbolKinds.Constructor)
                {
                    var metrics = MeasureMethod(lines, member);
                    model.Methods.Add(new MethodNode { Symbol = member, Declaring = type, Metrics = metrics });
                }
            }
            var own = model.Methods.Where(x => x.Declaring == type).Select(x => x.Metrics.CyclomaticComplexity).ToList();
            m.CyclomaticComplexity = own.Sum();
            m.MaximumMethodComplexity = own.Count == 0 ? 0 : own.Max();
            m.AverageMethodComplexity = own.Count == 0 ? 0 : Math.Round(own.Average(), 2);
        }
        model.TestMethods = index.TestMethods.Count();
        foreach (var project in model.Projects.Values)
        {
            project.TestMethods = index.TestMethods.Count(t => t.Project == project.Info.Name);
            project.EntryPoints.AddRange(EntryPoints(index, project.Info));
        }

        // Type relationships, with the evidence that produced each one.
        var referencedBy = new Dictionary<TypeNode, HashSet<TypeNode>>();
        foreach (var type in model.Types)
        {
            var targets = new Dictionary<TypeNode, (string Kind, string Evidence, string Confidence)>();
            void Add(string rawName, string kind, string evidence)
            {
                foreach (var name in TypeNames(rawName))
                {
                    if (!typesByName.TryGetValue(name, out var candidates))
                    {
                        continue;
                    }
                    foreach (var target in candidates.Where(t => t != type))
                    {
                        // The strongest evidence wins: declared bases, then injection, then members, signatures and usage.
                        if (!targets.TryGetValue(target, out var existing) || Rank(kind, evidence) > Rank(existing.Kind, existing.Evidence))
                        {
                            targets[target] = (kind, evidence, candidates.Count == 1 ? (kind is "inherits" or "implements" ? "high" : "medium") : "low");
                        }
                    }
                }
            }
            foreach (var b in type.Symbol.Bases)
            {
                var baseNode = typesByName.TryGetValue(CodeIndex.StripGeneric(b), out var bs) ? bs[0] : null;
                Add(b, baseNode?.Symbol.Kind == SymbolKinds.Interface ? "implements" : "inherits", "base_list");
                if (baseNode?.Symbol.Kind == SymbolKinds.Interface || (baseNode is null && InterfaceName().IsMatch(CodeIndex.StripGeneric(b))))
                {
                    type.Metrics.InterfaceCount++;
                }
            }
            foreach (var p in type.Symbol.ParameterTypes)
            {
                Add(p, "depends_on", "constructor_injection");
            }
            foreach (var member in type.Members)
            {
                var evidence = member.Kind switch
                {
                    SymbolKinds.Constructor => "constructor_injection",
                    SymbolKinds.Field or SymbolKinds.Property => "field_or_property",
                    _ => "method_signature",
                };
                foreach (var p in member.ParameterTypes) Add(p, "depends_on", evidence);
                if (member.ReturnType is { } r) Add(r, "depends_on", evidence);
                foreach (var u in member.Uses) Add(u, "depends_on", "usage");
                foreach (var c in member.Calls.Where(typesByName.ContainsKey)) Add(c, "depends_on", "instantiation_or_static_call");
            }
            foreach (var (target, (kind, evidence, confidence)) in targets)
            {
                model.Relationships.Add(new Relationship(type.Id, target.Id, kind, evidence, confidence));
                (referencedBy.TryGetValue(target, out var set) ? set : referencedBy[target] = []).Add(type);
            }
            type.Metrics.FanOut = targets.Count;
            type.Metrics.DependencyCount = targets.Count;
        }
        foreach (var type in model.Types)
        {
            type.Metrics.FanIn = referencedBy.TryGetValue(type, out var set) ? set.Count : 0;
            type.Metrics.InheritanceDepth = InheritanceDepth(type, typesByName);
        }

        // Calls between methods (name-based; ambiguous names are kept apart as uncertain).
        var methodsByName = model.Methods.GroupBy(x => x.Symbol.Name, StringComparer.Ordinal).ToDictionary(g => g.Key, g => g.ToList(), StringComparer.Ordinal);
        foreach (var method in model.Methods)
        {
            foreach (var call in method.Symbol.Calls.Distinct(StringComparer.Ordinal))
            {
                if (!methodsByName.TryGetValue(call, out var candidates))
                {
                    continue;
                }
                if (candidates.Count == 1 && candidates[0] != method)
                {
                    method.ResolvedCalls.Add(candidates[0].Id);
                    model.Relationships.Add(new Relationship(method.Id, candidates[0].Id, "calls", "invocation_by_name", "medium"));
                }
                else if (candidates.Count > 1)
                {
                    method.AmbiguousCalls.Add(call);
                }
            }
        }

        // Endpoints, DI, configuration (keys only — values are never read into the model).
        model.Endpoints.AddRange(index.Endpoints.Where(e => !IsGenerated(e.File)));
        model.Registrations.AddRange(index.Registrations);
        model.ConfigReads.AddRange(index.ConfigReferences);
        model.ConfigKeysDefined.AddRange(index.Files.Values.Where(f => f.ConfigKeys is not null).SelectMany(f => f.ConfigKeys!.Keys.Select(k => $"{k} ({f.Path})")).Distinct().Order());
        foreach (var r in index.Registrations.Where(r => r.ImplementationType.Length > 0 && r.ServiceType.Length > 0 && r.ImplementationType != r.ServiceType))
        {
            if (typesByName.TryGetValue(CodeIndex.StripGeneric(r.ServiceType), out var services) && typesByName.TryGetValue(CodeIndex.StripGeneric(r.ImplementationType), out var impls))
            {
                model.Relationships.Add(new Relationship(services[0].Id, impls[0].Id, "registered_as", $"DI {r.Lifetime} in {r.File}:{r.Line}", "high"));
            }
        }
        FindEntities(model, index, typesByName, Lines);

        // Tiers: what gets a detailed page (entry points, services, controllers, data, integration, complexity).
        var endpointHandlers = model.Endpoints.Select(e => e.Handler.Split('.')[0]).ToHashSet(StringComparer.Ordinal);
        var registered = model.Registrations.SelectMany(r => new[] { CodeIndex.StripGeneric(r.ImplementationType), CodeIndex.StripGeneric(r.ServiceType) }).ToHashSet(StringComparer.Ordinal);
        var complexityCut = Percentile(model.Types.Select(t => t.Metrics.CyclomaticComplexity), 0.85);
        var fanInCut = Percentile(model.Types.Select(t => t.Metrics.FanIn), 0.85);
        foreach (var type in model.Types)
        {
            var s = type.Symbol;
            if (s.IsTest) { type.Tier = 3; type.TierReasons.Add("test"); continue; }
            if (endpointHandlers.Contains(s.Name)) type.TierReasons.Add("handles API endpoints");
            if (registered.Contains(s.Name)) type.TierReasons.Add("registered in dependency injection");
            if (Tier1Suffixes.Any(x => s.Name.EndsWith(x, StringComparison.Ordinal) && s.Kind is SymbolKinds.Class or SymbolKinds.Record)) type.TierReasons.Add("service-like role");
            if (model.Entities.Any(e => e.Type == s.Name)) type.TierReasons.Add("persisted entity");
            if (type.Metrics.CyclomaticComplexity >= Math.Max(10, complexityCut)) type.TierReasons.Add("high complexity");
            if (type.Metrics.FanIn >= Math.Max(5, fanInCut)) type.TierReasons.Add("widely used");
            type.Tier = type.TierReasons.Count > 0 ? 1 : type.Metrics.MethodCount > 0 ? 2 : 3;
        }
        foreach (var method in model.Methods)
        {
            method.Important = method.Declaring?.Tier == 1 && method.Symbol.Kind == SymbolKinds.Method
                               && (method.Metrics.CyclomaticComplexity >= 4 || method.ResolvedCalls.Count + method.AmbiguousCalls.Count >= 3
                                   || model.Endpoints.Any(e => e.Handler.EndsWith("." + method.Symbol.Name, StringComparison.Ordinal)));
        }
        return model;
    }

    private static int Rank(string kind, string evidence) => kind is "inherits" or "implements" ? 6 : evidence switch
    {
        "constructor_injection" => 5, "field_or_property" => 4, "method_signature" => 3, "instantiation_or_static_call" => 2, _ => 1,
    };

    /// <summary>
    /// Cyclomatic complexity estimated from tokens: 1 + if + case + for + foreach + while + catch + when + &amp;&amp; + || + ??.
    /// (Ternary ?: is not counted: the lexer cannot tell it from nullable annotations.)
    /// </summary>
    public static MethodMetrics MeasureMethod(string[] lines, SymbolRecord method)
    {
        var start = Math.Max(1, method.StartLine);
        var end = Math.Min(lines.Length, Math.Max(start, method.EndLine));
        var body = string.Join('\n', lines.Skip(start - 1).Take(end - start + 1));
        var tokens = CSharpLexer.Tokenize(body);
        var complexity = 1;
        var branches = 0;
        for (var i = 0; i < tokens.Count; i++)
        {
            var t = tokens[i];
            if (t.Kind == TokenKind.Keyword && t.Text is "if" or "case" or "catch")
            {
                complexity++;
                branches++;
            }
            else if (t.Kind == TokenKind.Keyword && t.Text is "for" or "foreach" or "while")
            {
                complexity++;
            }
            else if (t.Kind == TokenKind.Identifier && t.Text == "when")
            {
                complexity++;
            }
            else if (t.Kind == TokenKind.Punct && i + 1 < tokens.Count && tokens[i + 1].Kind == TokenKind.Punct && tokens[i + 1].Line == t.Line
                     && ((t.Text == "&" && tokens[i + 1].Text == "&") || (t.Text == "|" && tokens[i + 1].Text == "|") || (t.Text == "?" && tokens[i + 1].Text == "?")))
            {
                complexity++;
                i++;
            }
        }
        var (source, _, _) = CountLines(lines, start, end);
        return new MethodMetrics(source, complexity, method.ParameterTypes.Count, method.Calls.Distinct().Count(), branches);
    }

    /// <summary>Source, comment and blank lines in [start, end] (1-based, inclusive).</summary>
    public static (int Source, int Comment, int Blank) CountLines(string[] lines, int start, int end)
    {
        int source = 0, comment = 0, blank = 0;
        var inBlock = false;
        for (var i = Math.Max(0, start - 1); i < Math.Min(lines.Length, end); i++)
        {
            var line = lines[i].Trim();
            if (inBlock)
            {
                comment++;
                inBlock = !line.Contains("*/", StringComparison.Ordinal);
            }
            else if (line.Length == 0)
            {
                blank++;
            }
            else if (line.StartsWith("//", StringComparison.Ordinal))
            {
                comment++;
            }
            else if (line.StartsWith("/*", StringComparison.Ordinal))
            {
                comment++;
                inBlock = !line.Contains("*/", StringComparison.Ordinal);
            }
            else
            {
                source++;
            }
        }
        return (source, comment, blank);
    }

    public static bool IsGenerated(string path)
    {
        var p = path.Replace('\\', '/');
        return p.EndsWith(".g.cs", StringComparison.OrdinalIgnoreCase) || p.EndsWith(".g.i.cs", StringComparison.OrdinalIgnoreCase)
               || p.EndsWith(".Designer.cs", StringComparison.OrdinalIgnoreCase) || p.EndsWith(".generated.cs", StringComparison.OrdinalIgnoreCase)
               || p.EndsWith("AssemblyInfo.cs", StringComparison.OrdinalIgnoreCase) || p.Contains("/obj/", StringComparison.OrdinalIgnoreCase)
               || p.Contains("/Migrations/", StringComparison.OrdinalIgnoreCase) && p.EndsWith(".Designer.cs", StringComparison.OrdinalIgnoreCase);
    }

    private static string[] ReadLines(string root, string relative)
    {
        try
        {
            return File.ReadAllLines(Path.Combine(root, relative.Replace('/', Path.DirectorySeparatorChar)));
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return [];
        }
    }

    /// <summary>Every file of the repository (outside build output, dependencies and vendored code): languages and sizes.</summary>
    private static void ScanFiles(ArchitectureModel model, string root, CancellationToken ct)
    {
        var pending = new Stack<string>();
        pending.Push(root);
        while (pending.Count > 0)
        {
            ct.ThrowIfCancellationRequested();
            var dir = pending.Pop();
            IEnumerable<string> entries;
            try
            {
                entries = Directory.EnumerateFileSystemEntries(dir);
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
            {
                model.Exclusions.Add($"{Path.GetRelativePath(root, dir)} (unreadable)");
                continue;
            }
            // Published or build output (a *.deps.json beside assemblies) and vendored libraries are not source.
            if (dir != root && Directory.EnumerateFiles(dir, "*.deps.json").Any())
            {
                model.Exclusions.Add($"{Path.GetRelativePath(root, dir).Replace('\\', '/')}/ (build output)");
                continue;
            }
            foreach (var entry in entries)
            {
                var name = Path.GetFileName(entry);
                if (Directory.Exists(entry))
                {
                    var relative = Path.GetRelativePath(root, entry).Replace('\\', '/');
                    if (ExcludedDirectories.Contains(name) || relative.EndsWith("wwwroot/lib", StringComparison.OrdinalIgnoreCase) || name is "vendor" or "third_party")
                    {
                        model.Exclusions.Add(relative + "/");
                        continue;
                    }
                    if (new DirectoryInfo(entry).LinkTarget is null)
                    {
                        pending.Push(entry);
                    }
                    continue;
                }
                model.FilesDiscovered++;
                if (LanguageByExtension.TryGetValue(Path.GetExtension(name), out var language))
                {
                    var lines = 0;
                    try
                    {
                        if (new FileInfo(entry).Length < 4 * 1024 * 1024)
                        {
                            lines = File.ReadLines(entry).Count();
                        }
                    }
                    catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
                    {
                    }
                    var (files, total) = model.Languages.GetValueOrDefault(language);
                    model.Languages[language] = (files + 1, total + lines);
                    model.FilesAnalyzed++;
                }
            }
        }
        model.UnparsedLanguages.AddRange(model.Languages.Keys.Where(l => l is not ("C#" or "Razor" or "SQL" or "CSS" or "HTML")).Order());
    }

    private static IEnumerable<string> EntryPoints(CodeIndex index, ProjectInfo project)
    {
        var programs = index.Files.Values.Where(f => f.Project == project.Name && (Path.GetFileName(f.Path).Equals("Program.cs", StringComparison.OrdinalIgnoreCase)
                                                                                   || f.Symbols.Any(s => s.Kind == SymbolKinds.TopLevel || (s.Name == "Main" && s.Kind == SymbolKinds.Method))))
            .Select(f => f.Path);
        var hosted = index.Registrations.Where(r => r.Hosted && r.Project == project.Name).Select(r => $"hosted service {r.ImplementationType} ({r.File}:{r.Line})");
        return programs.Concat(hosted).Distinct();
    }

    private static int? InheritanceDepth(TypeNode type, Dictionary<string, List<TypeNode>> typesByName)
    {
        if (type.Symbol.Kind is not (SymbolKinds.Class or SymbolKinds.Record))
        {
            return null;
        }
        var depth = 0;
        var current = type;
        var seen = new HashSet<TypeNode>();
        while (current is not null && seen.Add(current))
        {
            var baseName = current.Symbol.Bases.Select(CodeIndex.StripGeneric).FirstOrDefault(b => typesByName.TryGetValue(b, out var c) && c[0].Symbol.Kind is SymbolKinds.Class or SymbolKinds.Record);
            if (baseName is null)
            {
                // An external base class (Controller, Exception…) counts as one more level when it is not an interface.
                return current.Symbol.Bases.Any(b => !InterfaceName().IsMatch(CodeIndex.StripGeneric(b)) && !typesByName.ContainsKey(CodeIndex.StripGeneric(b))) ? depth + 1 : depth;
            }
            depth++;
            current = typesByName[baseName][0];
        }
        return depth;
    }

    private static void FindCycles(ArchitectureModel model)
    {
        var state = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        var stack = new List<string>();
        void Visit(string name)
        {
            state[name] = 1;
            stack.Add(name);
            foreach (var next in model.Projects[name].References)
            {
                if (state.GetValueOrDefault(next) == 1)
                {
                    model.ProjectCycles.Add([.. stack.Skip(stack.IndexOf(next)), next]);
                }
                else if (state.GetValueOrDefault(next) == 0)
                {
                    Visit(next);
                }
            }
            stack.RemoveAt(stack.Count - 1);
            state[name] = 2;
        }
        foreach (var name in model.Projects.Keys.Order())
        {
            if (state.GetValueOrDefault(name) == 0)
            {
                Visit(name);
            }
        }
    }

    /// <summary>EF Core: DbContext types and their DbSet&lt;T&gt; entities, with references between entities (inferred from property types).</summary>
    private static void FindEntities(ArchitectureModel model, CodeIndex index, Dictionary<string, List<TypeNode>> typesByName, Func<string, string[]> lines)
    {
        foreach (var context in model.Types.Where(t => t.Symbol.Bases.Any(b => CodeIndex.StripGeneric(b) is "DbContext" or "IdentityDbContext" or "IdentityDbContext`1")))
        {
            model.DbContexts.Add(context.Symbol.FullName);
            var text = lines(context.Symbol.File).Skip(context.Symbol.StartLine - 1).Take(context.Symbol.EndLine - context.Symbol.StartLine + 1);
            foreach (Match m in DbSet().Matches(string.Join('\n', text)))
            {
                var entityType = m.Groups[1].Value;
                if (!typesByName.TryGetValue(entityType, out var entityNodes))
                {
                    model.Entities.Add(new EntityNode(m.Groups[2].Value, entityType, context.Symbol.Name, context.Symbol.File, [], []));
                    continue;
                }
                var entity = entityNodes[0];
                var props = entity.Members.Where(x => x.Kind == SymbolKinds.Property).Select(x => (x.Name, x.ReturnType ?? "")).ToList();
                model.Entities.Add(new EntityNode(m.Groups[2].Value, entityType, context.Symbol.Name, entity.Symbol.File, props, []));
            }
        }
        var entityTypes = model.Entities.Select(e => e.Type).ToHashSet(StringComparer.Ordinal);
        for (var i = 0; i < model.Entities.Count; i++)
        {
            var e = model.Entities[i];
            var refs = new List<(string, string, string)>();
            foreach (var (prop, type) in e.Properties)
            {
                foreach (var name in TypeNames(type).Where(entityTypes.Contains))
                {
                    refs.Add((prop, name, type.Contains('<') ? "collection navigation property" : "navigation property"));
                }
                if (prop.EndsWith("Id", StringComparison.Ordinal) && prop.Length > 2 && entityTypes.Contains(prop[..^2]))
                {
                    refs.Add((prop, prop[..^2], "foreign key by naming convention (inferred)"));
                }
            }
            model.Entities[i] = e with { References = refs.Distinct().ToList() };
        }
    }

    /// <summary>The capitalised type names in a type expression ("Task&lt;List&lt;Order&gt;&gt;" → Task, List, Order).</summary>
    public static IEnumerable<string> TypeNames(string expression) => TypeName().Matches(expression).Select(m => m.Value);

    private static int Percentile(IEnumerable<int> values, double p)
    {
        var sorted = values.Order().ToList();
        return sorted.Count == 0 ? 0 : sorted[(int)Math.Min(sorted.Count - 1, Math.Floor(sorted.Count * p))];
    }

    [GeneratedRegex(@"\b[A-Z][A-Za-z0-9_]*")]
    private static partial Regex TypeName();

    [GeneratedRegex("^I[A-Z]")]
    private static partial Regex InterfaceName();

    [GeneratedRegex(@"DbSet<\s*([A-Za-z_][A-Za-z0-9_]*)\s*>\??\s+([A-Za-z_][A-Za-z0-9_]*)")]
    private static partial Regex DbSet();
}
