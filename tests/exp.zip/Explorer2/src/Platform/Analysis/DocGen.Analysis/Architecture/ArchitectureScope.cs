using System.Text.RegularExpressions;
using DocGen.Analysis.Indexing;
using DocGen.Core.Exceptions;

namespace DocGen.Analysis.Architecture;

/// <summary>
/// What the user asked to document. The repository is context; the scope is what gets documented. Primary code is what
/// the request names; everything else the trace reaches is supporting code, documented only as far as the flow needs.
/// </summary>
public sealed class AnalysisScope
{
    /// <summary>repository | project | directory | file | class | method | feature</summary>
    public required string Kind { get; init; }

    /// <summary>The request as given (a path, project, class, Class.Method or feature words).</summary>
    public required string Target { get; init; }

    /// <summary>Short display name ("OrderService_1_0", "OrderService.Place", "order service").</summary>
    public required string Label { get; init; }

    /// <summary>Repository-relative path for path scopes (forward slashes), else null.</summary>
    public string? RelativePath { get; init; }

    public HashSet<string> Files { get; } = new(StringComparer.OrdinalIgnoreCase);
    public List<SymbolRecord> Types { get; } = [];
    public List<SymbolRecord> Methods { get; } = [];

    /// <summary>How the scope was resolved, alternatives and truncation — shown in the bundle and the tool result.</summary>
    public List<string> Notes { get; } = [];

    /// <summary>Folder and ZIP name part: safe, short and stable for the same request.</summary>
    public string Slug => ArchitectureWriter.Safe(Label.Length > 60 ? Label[..60] : Label);

    public bool IsPrimary(SymbolRecord symbol)
        => Files.Contains(symbol.File) || Types.Any(t => t.FullName == symbol.FullName || symbol.Container == t.FullName || symbol.Container?.StartsWith(t.FullName + ".", StringComparison.Ordinal) == true)
           || Methods.Any(m => ReferenceEquals(m, symbol) || m.FullName == symbol.FullName && m.ParameterTypes.SequenceEqual(symbol.ParameterTypes));
}

/// <summary>Turns a request into an <see cref="AnalysisScope"/> — the smallest scope that answers it.</summary>
public static partial class ScopeResolver
{
    private static readonly HashSet<string> StopWords = new(StringComparer.OrdinalIgnoreCase)
    {
        "a", "an", "and", "architect", "does", "document", "documentation", "explain", "feature", "flow", "flows", "for", "from", "get", "gets", "how",
        "in", "is", "it", "me", "of", "only", "process", "show", "the", "this", "to", "trace", "what", "when", "where", "which", "work", "works", "happens",
        "deeply", "everything", "reachable", "including", "every", "relevant", "method", "methods", "class", "project", "folder", "directory", "code",
    };

    /// <summary>
    /// Resolves <paramref name="target"/> against the repository at <paramref name="root"/>. Returns null when the target
    /// is the repository itself (repository mode). Throws with suggestions when nothing matches.
    /// </summary>
    public static AnalysisScope? Resolve(string target, CodeIndex index, ArchitectureModel model, string root)
    {
        var t = target.Trim().Trim('"', '\'', '`').Trim();
        if (t.Length == 0 || t is "." or "/")
        {
            return null;
        }

        // Paths: absolute inside the repository, or repository-relative.
        string? relative = null;
        if (Path.IsPathFullyQualified(t))
        {
            var full = Path.GetFullPath(t).TrimEnd('\\', '/');
            var rootFull = Path.GetFullPath(root).TrimEnd('\\', '/');
            if (string.Equals(full, rootFull, StringComparison.OrdinalIgnoreCase))
            {
                return null;
            }
            if (!full.StartsWith(rootFull + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            {
                throw new ValidationException($"{t} is not inside the repository being analysed ({rootFull}). Pick the repository that contains it.");
            }
            relative = Path.GetRelativePath(rootFull, full).Replace('\\', '/');
        }
        else if (t.Contains('/') || t.Contains('\\') || t.EndsWith(".cs", StringComparison.OrdinalIgnoreCase) || t.EndsWith(".csproj", StringComparison.OrdinalIgnoreCase))
        {
            var candidate = t.Replace('\\', '/').Trim('/');
            if (File.Exists(Path.Combine(root, candidate)) || Directory.Exists(Path.Combine(root, candidate)))
            {
                relative = candidate;
            }
        }
        if (relative is not null)
        {
            return PathScope(t, relative, index, model, root);
        }

        // A project by name.
        if (model.Projects.TryGetValue(t, out var project))
        {
            var scope = new AnalysisScope { Kind = "project", Target = t, Label = project.Info.Name };
            scope.Files.UnionWith(project.Files);
            AddSymbolsOfFiles(scope, index);
            return scope;
        }

        // Class.Method, a class, or a method.
        var dotted = t.TrimEnd(')', '(').Trim();
        var lastDot = dotted.LastIndexOf('.');
        if (lastDot > 0 && IdentifierPath().IsMatch(dotted))
        {
            var typeName = dotted[..lastDot];
            typeName = typeName[(typeName.LastIndexOf('.') + 1)..];
            var memberName = dotted[(lastDot + 1)..];
            var types = TypesNamed(index, typeName);
            var members = types.SelectMany(ty => index.MembersOf(ty.FullName)).Where(m => m.Name == memberName && SymbolKinds.IsCallable(m.Kind)).ToList();
            if (members.Count > 0)
            {
                var scope = new AnalysisScope { Kind = "method", Target = t, Label = $"{types[0].Name}.{memberName}" };
                scope.Methods.AddRange(members);
                if (members.Count > 1) scope.Notes.Add($"{members.Count} overloads or same-named methods match {t}; all are included.");
                return scope;
            }
            if (TypesNamed(index, memberName) is { Count: > 0 } nested)
            {
                return ClassScope(t, nested);
            }
        }
        if (IdentifierPath().IsMatch(dotted) && !dotted.Contains(' '))
        {
            var simple = dotted[(dotted.LastIndexOf('.') + 1)..];
            if (TypesNamed(index, simple) is { Count: > 0 } types)
            {
                return ClassScope(t, types);
            }
            var methods = index.ByName(simple).Where(s => SymbolKinds.IsCallable(s.Kind) && !s.IsTest && !ArchitectureModelBuilder.IsGenerated(s.File)).ToList();
            if (methods.Count > 0)
            {
                var scope = new AnalysisScope { Kind = "method", Target = t, Label = methods.Count == 1 && methods[0].Container is { } c ? $"{c[(c.LastIndexOf('.') + 1)..]}.{simple}" : simple };
                scope.Methods.AddRange(methods.Take(12));
                if (methods.Count > 1) scope.Notes.Add($"{methods.Count} methods are named {simple} ({string.Join(", ", methods.Take(6).Select(m => m.Container ?? m.File))}); all are treated as the requested scope.");
                return scope;
            }
        }
        return FeatureScope(t, index, model);
    }

    private static AnalysisScope ClassScope(string target, List<SymbolRecord> types)
    {
        var scope = new AnalysisScope { Kind = "class", Target = target, Label = types[0].Name };
        scope.Types.AddRange(types);
        if (types.Count > 1) scope.Notes.Add($"{types.Count} types are named {types[0].Name} ({string.Join(", ", types.Select(x => x.FullName))}); all are included.");
        return scope;
    }

    private static List<SymbolRecord> TypesNamed(CodeIndex index, string name)
    {
        var all = index.ByName(name).Where(s => SymbolKinds.IsType(s.Kind) && !ArchitectureModelBuilder.IsGenerated(s.File)).ToList();
        var nonTest = all.Where(s => !s.IsTest).ToList();
        // Partial types appear once per declaration: keep one per full name.
        return (nonTest.Count > 0 ? nonTest : all).DistinctBy(s => s.FullName).ToList();
    }

    private static AnalysisScope PathScope(string target, string relative, CodeIndex index, ArchitectureModel model, string root)
    {
        var full = Path.Combine(root, relative);
        var label = Path.GetFileNameWithoutExtension(relative.TrimEnd('/'));
        if (File.Exists(full) && relative.EndsWith(".csproj", StringComparison.OrdinalIgnoreCase))
        {
            var project = model.Projects.Values.FirstOrDefault(p => string.Equals(p.Info.Path.Replace('\\', '/'), relative, StringComparison.OrdinalIgnoreCase));
            var scope = new AnalysisScope { Kind = "project", Target = target, Label = project?.Info.Name ?? label, RelativePath = relative };
            if (project is not null) scope.Files.UnionWith(project.Files);
            AddSymbolsOfFiles(scope, index);
            return scope;
        }
        if (File.Exists(full))
        {
            var scope = new AnalysisScope { Kind = "file", Target = target, Label = label, RelativePath = relative };
            scope.Files.Add(relative);
            AddSymbolsOfFiles(scope, index);
            if (scope.Types.Count == 0 && scope.Methods.Count == 0)
            {
                throw new ValidationException($"{relative} has no C# types or methods in the index (is it a source file, and is the index up to date?).");
            }
            return scope;
        }
        var prefix = relative.TrimEnd('/') + "/";
        var isProject = model.Projects.Values.FirstOrDefault(p => string.Equals(p.Info.Directory.Replace('\\', '/').TrimEnd('/'), relative.TrimEnd('/'), StringComparison.OrdinalIgnoreCase));
        var dirScope = new AnalysisScope { Kind = isProject is null ? "directory" : "project", Target = target, Label = isProject?.Info.Name ?? label, RelativePath = relative };
        dirScope.Files.UnionWith(index.Files.Keys.Where(f => f.Replace('\\', '/').StartsWith(prefix, StringComparison.OrdinalIgnoreCase)));
        AddSymbolsOfFiles(dirScope, index);
        if (dirScope.Types.Count == 0 && dirScope.Methods.Count == 0)
        {
            throw new ValidationException($"No indexed C# code under {relative}. Check the path, or re-index the repository (index_repository).");
        }
        return dirScope;
    }

    private static void AddSymbolsOfFiles(AnalysisScope scope, CodeIndex index)
    {
        foreach (var file in scope.Files.ToList())
        {
            if (!index.Files.TryGetValue(file, out var entry) || ArchitectureModelBuilder.IsGenerated(file))
            {
                continue;
            }
            scope.Types.AddRange(entry.Symbols.Where(s => SymbolKinds.IsType(s.Kind)));
            scope.Methods.AddRange(entry.Symbols.Where(s => SymbolKinds.IsCallable(s.Kind) || s.Kind == SymbolKinds.TopLevel));
        }
    }

    /// <summary>Feature words ("order service") → the types, methods and routes whose names carry them.</summary>
    private static AnalysisScope FeatureScope(string target, CodeIndex index, ArchitectureModel model)
    {
        var words = Regex.Split(target, "[^A-Za-z0-9]+").Where(w => w.Length > 1 && !StopWords.Contains(w)).Select(w => w.ToLowerInvariant()).Distinct().ToList();
        if (words.Count == 0)
        {
            throw new ValidationException($"'{target}' does not name a path, project, class, method or feature words to search for.");
        }
        var joined = string.Concat(words);
        int Score(string name)
        {
            var lower = name.ToLowerInvariant();
            return lower.Contains(joined, StringComparison.Ordinal) ? 100 + (lower == joined ? 50 : 0) : words.All(w => lower.Contains(w, StringComparison.Ordinal)) ? 60 : 0;
        }
        var scope = new AnalysisScope { Kind = "feature", Target = target, Label = string.Join(' ', words) };
        var types = index.Types.Where(s => !s.IsTest && !ArchitectureModelBuilder.IsGenerated(s.File)).Select(s => (Symbol: s, Score: Score(s.Name))).Where(x => x.Score > 0)
            .OrderByDescending(x => x.Score).ThenBy(x => x.Symbol.FullName, StringComparer.Ordinal).DistinctBy(x => x.Symbol.FullName).ToList();
        var methods = index.Symbols.Where(s => SymbolKinds.IsCallable(s.Kind) && !s.IsTest && !ArchitectureModelBuilder.IsGenerated(s.File)).Select(s => (Symbol: s, Score: Score(s.Name))).Where(x => x.Score > 0)
            .OrderByDescending(x => x.Score).ThenBy(x => x.Symbol.FullName, StringComparer.Ordinal).ToList();
        var routes = model.Endpoints.Where(e => words.All(w => e.Route.Contains(w, StringComparison.OrdinalIgnoreCase))).ToList();
        foreach (var e in routes)
        {
            if (index.Files.TryGetValue(e.File, out var entry) && entry.Symbols.Where(s => !SymbolKinds.IsType(s.Kind) && s.StartLine <= e.Line && e.Line <= s.EndLine).OrderBy(s => s.EndLine - s.StartLine).FirstOrDefault() is { } handler)
            {
                methods.Insert(0, (handler, 200));
            }
        }
        const int maxTypes = 25, maxMethods = 40;
        scope.Types.AddRange(types.Take(maxTypes).Select(x => x.Symbol));
        scope.Methods.AddRange(methods.Where(m => !scope.Types.Any(t => m.Symbol.Container == t.FullName)).Select(x => x.Symbol).Distinct().Take(maxMethods));
        if (types.Count > maxTypes) scope.Notes.Add($"{types.Count} types match '{scope.Label}'; the {maxTypes} strongest name matches are the primary scope.");
        if (routes.Count > 0) scope.Notes.Add($"Routes matching: {string.Join(", ", routes.Take(8).Select(r => $"{r.Verb} {r.Route}"))}.");
        if (scope.Types.Count == 0 && scope.Methods.Count == 0)
        {
            var near = index.Search(string.Join(' ', words), null, null, includeTests: false, limit: 8).Select(x => x.Symbol.Name).Distinct();
            throw new ValidationException($"No type, method or route name contains '{string.Join(' ', words)}'. Closest names: {string.Join(", ", near)}. Name the class, method or folder instead.");
        }
        scope.Notes.Add($"Feature scope found by name: types and methods whose names contain '{joined}' (or all of: {string.Join(", ", words)}). A matching name is not proof of participation; the trace decides.");
        return scope;
    }

    [GeneratedRegex(@"^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*$")]
    private static partial Regex IdentifierPath();
}
