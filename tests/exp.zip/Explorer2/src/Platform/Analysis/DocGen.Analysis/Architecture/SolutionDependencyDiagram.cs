using System.Text;
using System.Text.RegularExpressions;
using DocGen.Analysis.Indexing;

namespace DocGen.Analysis.Architecture;

/// <summary>
/// The project dependency diagram of a solution as Mermaid, computed from the real ProjectReference items: projects
/// grouped into subgraphs by folder, one arrow per reference ("A --> B" = A references B), straight connectors, and
/// production / test / test-support projects coloured apart.
/// </summary>
public static partial class SolutionDependencyDiagram
{
    public sealed record Result(string Mermaid, string Solution, int Projects, int References, int Groups, int Production, int Tests, int Support, IReadOnlyList<string> Cycles);

    private sealed record Node(ProjectInfo Project, string Id, string Category, string Folder);

    private static readonly string[] CategoryOrder = ["production", "support", "tests"];

    /// <param name="solution">A .sln/.slnx path or name; null = the only solution, or every project when there are several.</param>
    /// <param name="transitiveReduction">Drop references already implied through other references (a sparser picture).</param>
    public static Result Build(CodeIndex index, string? solution, bool includeTests, bool transitiveReduction)
    {
        var (label, projects) = SelectProjects(index, solution);
        var withTests = ProjectsWithTests(index);
        string Category(ProjectInfo p) => CategoryOf(p, withTests);
        var nodes = new List<Node>();
        var ids = new HashSet<string>(StringComparer.Ordinal);
        foreach (var p in projects.OrderBy(p => p.Directory, StringComparer.OrdinalIgnoreCase).ThenBy(p => p.Name, StringComparer.OrdinalIgnoreCase))
        {
            var category = Category(p);
            if (!includeTests && category != "production")
            {
                continue;
            }
            var folder = ParentFolder(p);
            nodes.Add(new Node(p, UniqueId(p.Name, ids), category, folder));
        }
        var byName = nodes.ToDictionary(n => n.Project.Name, StringComparer.OrdinalIgnoreCase);

        // Direct references between the selected projects.
        var edges = new List<(Node From, Node To)>();
        foreach (var n in nodes)
        {
            foreach (var target in index.ProjectReferencesOf(n.Project.Name).Distinct(StringComparer.OrdinalIgnoreCase))
            {
                if (byName.TryGetValue(target, out var to) && to != n)
                {
                    edges.Add((n, to));
                }
            }
        }
        if (transitiveReduction)
        {
            edges = Reduce(edges);
        }
        var cycles = Cycles(edges);

        var sb = new StringBuilder("flowchart TB\n");
        var groups = Groups(nodes);
        foreach (var (groupId, groupLabel, members) in groups)
        {
            sb.Append($"    subgraph {groupId}[\"{Escape(groupLabel)}\"]\n");
            if (members.Count > 1)
            {
                sb.Append("        direction TB\n");
            }
            foreach (var m in members)
            {
                sb.Append($"        {m.Id}[\"{Escape(m.Project.Name)}\"]\n");
            }
            sb.Append("    end\n\n");
        }

        // Edges, grouped like the picture reads: production first, then test support, then tests.
        var sections = new[]
        {
            ("production", "Production dependencies", "p"),
            ("support", "Test support dependencies", "s"),
            ("tests", "Test dependencies", "t"),
        };
        var edgeIds = new List<List<string>>();
        foreach (var (category, title, prefix) in sections)
        {
            var section = edges.Where(e => e.From.Category == category)
                .OrderBy(e => Order(groups, e.From)).ThenBy(e => e.From.Project.Name, StringComparer.OrdinalIgnoreCase)
                .ThenBy(e => Order(groups, e.To)).ThenBy(e => e.To.Project.Name, StringComparer.OrdinalIgnoreCase).ToList();
            if (section.Count == 0)
            {
                continue;
            }
            var width = Math.Max(2, section.Count.ToString().Length);
            var list = new List<string>();
            sb.Append($"    %% {title}\n");
            string? previous = null;
            for (var i = 0; i < section.Count; i++)
            {
                var (from, to) = section[i];
                if (previous is not null && previous != from.Id)
                {
                    sb.Append('\n'); // a blank line between sources keeps long lists readable
                }
                previous = from.Id;
                var id = prefix + (i + 1).ToString().PadLeft(width, '0');
                list.Add(id);
                sb.Append($"    {from.Id} {id}@--> {to.Id}\n");
            }
            sb.Append('\n');
            edgeIds.Add(list);
        }
        if (edgeIds.Count > 0)
        {
            sb.Append("    %% Straight connector segments\n");
            foreach (var list in edgeIds)
            {
                foreach (var id in list)
                {
                    sb.Append($"    {id}@{{ curve: linear }}\n");
                }
                sb.Append('\n');
            }
        }

        sb.Append("    %% Visual grouping\n");
        sb.Append("    classDef production fill:#eff6ff,stroke:#2563eb,color:#172554\n");
        sb.Append("    classDef tests fill:#f0fdf4,stroke:#16a34a,color:#14532d\n");
        sb.Append("    classDef support fill:#faf5ff,stroke:#9333ea,color:#581c87\n");
        foreach (var category in CategoryOrder)
        {
            var members = nodes.Where(n => n.Category == category).Select(n => n.Id).ToList();
            if (members.Count == 0)
            {
                continue;
            }
            sb.Append('\n');
            foreach (var chunk in members.Chunk(8))
            {
                sb.Append($"    class {string.Join(',', chunk)} {category}\n");
            }
        }
        return new Result(sb.ToString(), label, nodes.Count, edges.Count, groups.Count,
            nodes.Count(n => n.Category == "production"), nodes.Count(n => n.Category == "tests"), nodes.Count(n => n.Category == "support"), cycles);
    }

    /// <summary>What the index knows about one project — the evidence for its description and role.</summary>
    public sealed record ProjectFacts(
        string Name, string Path, string Category, string Kind, string Frameworks, IReadOnlyList<string> References, IReadOnlyList<string> ReferencedBy,
        int Types, IReadOnlyList<string> Namespaces, IReadOnlyList<string> EntryPoints, int Endpoints, IReadOnlyList<string> HostedServices,
        IReadOnlyList<string> DbContexts, IReadOnlyList<string> Packages, string RoleHint);

    /// <summary>Facts per project, in the detailed diagram's order, with a role hint derived from the reference graph.</summary>
    public static List<ProjectFacts> Facts(CodeIndex index, string? solution, bool includeTests)
    {
        var (_, projects) = SelectProjects(index, solution);
        var withTests = ProjectsWithTests(index);
        string Category(ProjectInfo p) => CategoryOf(p, withTests);
        projects = projects.Where(p => includeTests || Category(p) == "production").ToList();
        var names = projects.Select(p => p.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var refs = projects.ToDictionary(p => p.Name, p => index.ProjectReferencesOf(p.Name).Where(names.Contains).Distinct(StringComparer.OrdinalIgnoreCase).Order(StringComparer.OrdinalIgnoreCase).ToList(), StringComparer.OrdinalIgnoreCase);
        var production = projects.Where(p => Category(p) == "production").Select(p => p.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var projectOfFile = index.Files.Values.ToDictionary(f => f.Path, f => f.Project, StringComparer.OrdinalIgnoreCase);
        var result = new List<ProjectFacts>();
        foreach (var p in projects.OrderBy(p => Array.IndexOf(CategoryOrder, Category(p))).ThenBy(p => p.Directory, StringComparer.OrdinalIgnoreCase))
        {
            var category = Category(p);
            var types = index.Types.Where(t => t.Project == p.Name && !ArchitectureModelBuilder.IsGenerated(t.File)).DistinctBy(t => t.FullName).ToList();
            var referencedBy = refs.Where(kv => kv.Value.Contains(p.Name, StringComparer.OrdinalIgnoreCase)).Select(kv => kv.Key).Order(StringComparer.OrdinalIgnoreCase).ToList();
            var isExe = p.OutputType is "Exe" or "WinExe" || (p.Sdk ?? "").Contains("Web", StringComparison.OrdinalIgnoreCase) || (p.Sdk ?? "").Contains("Worker", StringComparison.OrdinalIgnoreCase);
            var kind = category == "tests" ? "test project" : category == "support" ? "test support library"
                : (p.Sdk ?? "").Contains("Web", StringComparison.OrdinalIgnoreCase) ? "web application" : isExe ? "application" : "class library";
            var entry = index.Files.Values.Where(f => f.Project == p.Name && f.Symbols.Any(s => s.Kind == SymbolKinds.TopLevel || s.Name == "Main" && s.Kind == SymbolKinds.Method)).Select(f => f.Path).Take(3).ToList();
            var endpoints = index.Endpoints.Count(e => projectOfFile.GetValueOrDefault(e.File) == p.Name);
            var hosted = index.Registrations.Where(r => r.Hosted && r.Project == p.Name).Select(r => r.ImplementationType).Distinct().Take(8).ToList();
            var contexts = types.Where(t => t.Bases.Any(b => CodeIndex.StripGeneric(b).EndsWith("DbContext", StringComparison.Ordinal))).Select(t => t.Name).Take(5).ToList();
            var namespaces = types.Select(t => t.Namespace).Where(n => n.Length > 0).GroupBy(n => n).OrderByDescending(g => g.Count()).Select(g => g.Key).Take(4).ToList();
            var packages = p.Packages.Select(x => x.Id).Where(id => !Regex.IsMatch(id, "^(Microsoft\\.NET\\.Test\\.Sdk|coverlet|xunit\\.runner|MSTest\\.TestAdapter|NUnit3TestAdapter)", RegexOptions.IgnoreCase)).Take(8).ToList();
            var prodRefs = refs[p.Name].Count(production.Contains);
            var prodUsers = referencedBy.Count(production.Contains);
            var role = category switch
            {
                "tests" => refs[p.Name].Count == 0 ? "tests (no project references)" : $"tests {string.Join(", ", refs[p.Name].Where(production.Contains).Take(3))}",
                "support" => $"shared test support, used by {referencedBy.Count} projects",
                _ when isExe => prodRefs == 0 ? "application entry point" : $"application entry point / host; composes {prodRefs} projects",
                _ when production.Count > 3 && prodRefs >= production.Count / 2 => $"composition root: references {prodRefs} of {production.Count - 1} production projects",
                _ when prodUsers >= Math.Max(2, production.Count / 2) && prodRefs <= 1 => $"foundation library used by {prodUsers} production projects",
                _ when prodUsers == 0 => "top-level library (no production project references it)",
                _ when prodRefs == 0 => $"leaf library used by {prodUsers} projects",
                _ => $"library: uses {prodRefs}, used by {prodUsers} production projects",
            };
            result.Add(new ProjectFacts(p.Name, p.Path, category, kind, string.Join(", ", p.TargetFrameworks), refs[p.Name], referencedBy, types.Count, namespaces, entry, endpoints, hosted, contexts, packages, role));
        }
        return result;
    }

    public sealed record AreaResult(string Mermaid, int Areas, int Links, IReadOnlyDictionary<string, IReadOnlyList<string>> Members);

    /// <summary>
    /// The simplified view: projects grouped into areas, references inside an area hidden, one arrow per pair of areas
    /// with at least one reference between them ("A --> B" = something in A references something in B). Areas default
    /// to the detailed diagram's folder groups (tests collapse into support / unit / integration); <paramref name="areas"/>
    /// overrides them: area label → project names or wildcards ("OrderDomain.*", "*Host*").
    /// </summary>
    public static AreaResult BuildAreas(CodeIndex index, string? solution, bool includeTests, IReadOnlyDictionary<string, IReadOnlyList<string>>? areas)
    {
        var (_, projects) = SelectProjects(index, solution);
        var withTests = ProjectsWithTests(index);
        var nodes = projects.Select(p => (Project: p, Category: CategoryOf(p, withTests))).Where(x => includeTests || x.Category == "production").ToList();
        var areaOf = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        if (areas is { Count: > 0 })
        {
            foreach (var (area, patterns) in areas)
            {
                foreach (var (p, _) in nodes.Where(n => !areaOf.ContainsKey(n.Project.Name) && patterns.Any(pattern => Matches(pattern, n.Project))))
                {
                    areaOf[p.Name] = area;
                }
            }
        }
        foreach (var (p, category) in nodes.Where(n => !areaOf.ContainsKey(n.Project.Name)))
        {
            areaOf[p.Name] = category switch
            {
                "support" => "Shared test support",
                "tests" => IntegrationFolder().IsMatch(p.Path.Replace('\\', '/')) || IntegrationFolder().IsMatch(p.Name) ? "Integration tests" : "Unit tests",
                _ => DefaultArea(p, nodes.Where(n => n.Category == "production").Select(n => n.Project).ToList()),
            };
        }
        var categoryOfArea = areaOf.GroupBy(kv => kv.Value).ToDictionary(g => g.Key, g => nodes.Where(n => g.Any(kv => kv.Key == n.Project.Name)).Select(n => n.Category).Any(c => c == "production") ? "production" : "tests");

        // One link per pair of areas that has at least one project reference.
        var links = new SortedSet<(string From, string To)>();
        foreach (var (p, _) in nodes)
        {
            foreach (var target in index.ProjectReferencesOf(p.Name))
            {
                if (areaOf.TryGetValue(target, out var to) && areaOf[p.Name] is var from && from != to)
                {
                    links.Add((from, to));
                }
            }
        }

        var ids = new HashSet<string>(StringComparer.Ordinal);
        var areaIds = areaOf.Values.Distinct().OrderBy(a => a, StringComparer.OrdinalIgnoreCase).ToDictionary(a => a, a => UniqueId(a, ids));
        var sb = new StringBuilder("flowchart TB\n");
        var testAreas = areaIds.Keys.Where(a => categoryOfArea[a] != "production").OrderBy(a => TestRank(a)).ThenBy(a => a, StringComparer.OrdinalIgnoreCase).ToList();
        var productionAreas = areaIds.Keys.Where(a => categoryOfArea[a] == "production")
            .OrderBy(a => KindRank(Kind(a))).ThenBy(a => a, StringComparer.OrdinalIgnoreCase).ToList();
        void Subgraph(string id, string label, List<string> members)
        {
            if (members.Count == 0) return;
            sb.Append($"    subgraph {id}[\"{Escape(label)}\"]\n        direction TB\n");
            foreach (var a in members) sb.Append($"        {areaIds[a]}[\"{Escape(a)}\"]\n");
            sb.Append("    end\n\n");
        }
        Subgraph("TESTS", "Tests and support", testAreas);
        Subgraph("PRODUCTION", CommonFolder(nodes.Where(n => n.Category == "production").Select(n => n.Project).ToList()) ?? "Production", productionAreas);

        var sections = new[] { ("Test dependencies", "t", testAreas), ("Production dependencies", "p", productionAreas) };
        var allIds = new List<List<string>>();
        foreach (var (title, prefix, sources) in sections)
        {
            var section = links.Where(l => sources.Contains(l.From)).OrderBy(l => sources.IndexOf(l.From))
                .ThenBy(l => productionAreas.Contains(l.To) ? productionAreas.IndexOf(l.To) + 100 : testAreas.IndexOf(l.To)).ToList();
            if (section.Count == 0) continue;
            sb.Append($"    %% {title}\n");
            var list = new List<string>();
            string? previous = null;
            foreach (var (from, to) in section)
            {
                if (previous is not null && previous != from) sb.Append('\n');
                previous = from;
                var id = prefix + (list.Count + 1).ToString().PadLeft(2, '0');
                list.Add(id);
                sb.Append($"    {areaIds[from]} {id}@--> {areaIds[to]}\n");
            }
            sb.Append('\n');
            allIds.Add(list);
        }
        if (allIds.Count > 0)
        {
            sb.Append("    %% Straight connector segments\n");
            foreach (var list in allIds)
            {
                foreach (var id in list) sb.Append($"    {id}@{{ curve: linear }}\n");
                sb.Append('\n');
            }
        }
        sb.Append("    classDef host fill:#dbeafe,stroke:#2563eb,color:#172554\n");
        sb.Append("    classDef domain fill:#dcfce7,stroke:#16a34a,color:#14532d\n");
        sb.Append("    classDef proxy fill:#ffedd5,stroke:#ea580c,color:#7c2d12\n");
        sb.Append("    classDef shared fill:#f1f5f9,stroke:#64748b,color:#0f172a\n");
        sb.Append("    classDef test fill:#f3e8ff,stroke:#9333ea,color:#581c87\n\n");
        foreach (var kind in new[] { "host", "domain", "proxy", "shared" })
        {
            var members = productionAreas.Where(a => Kind(a) == kind).Select(a => areaIds[a]).ToList();
            if (members.Count > 0) sb.Append($"    class {string.Join(',', members)} {kind}\n");
        }
        if (testAreas.Count > 0) sb.Append($"    class {string.Join(',', testAreas.Select(a => areaIds[a]))} test\n");

        var membership = areaOf.GroupBy(kv => kv.Value).ToDictionary(g => g.Key, g => (IReadOnlyList<string>)g.Select(kv => kv.Key).Order(StringComparer.OrdinalIgnoreCase).ToList());
        return new AreaResult(sb.ToString(), areaIds.Count, links.Count, membership);
    }

    /// <summary>A production project's default area: its folder group's last segment, or its family when it sits alone in a shared folder.</summary>
    private static string DefaultArea(ProjectInfo p, List<ProjectInfo> production)
    {
        var folder = ParentFolder(p);
        var siblings = production.Where(o => ParentFolder(o) == folder).ToList();
        var last = folder.Contains('/') ? folder[(folder.LastIndexOf('/') + 1)..] : folder;
        var holdsAreas = production.Any(o => ParentFolder(o).StartsWith(folder + "/", StringComparison.OrdinalIgnoreCase));
        var families = siblings.Select(o => Family(o.Name)).Distinct().Count();
        // Projects sitting directly in a folder of areas (src/Components/HostCommon, …/UtilityComponent): a host
        // gets its own area, the rest are shared libraries.
        if (holdsAreas && (siblings.Count == 1 || families > 1))
        {
            return Kind(p.Name) == "host" ? Humanize(Family(p.Name)) : "Shared libraries";
        }
        // Alone in its own folder (GatewayComponents/Request.Listener): the folder names the area.
        return Humanize(families > 1 && siblings.Count > 1 || siblings.Count == 1 ? last : last);
    }

    /// <summary>"OrderDomain" → "Order domain", "ProxyComponents" → "Proxy components", "NonUIServiceComponents" → "Non UI service components".</summary>
    private static string Humanize(string text)
    {
        var words = Regex.Matches(text, "[A-Z]+(?![a-z])|[A-Z]?[a-z]+|[0-9]+").Select(m => m.Value).ToList();
        if (words.Count <= 1) return text;
        return words[0] + " " + string.Join(' ', words.Skip(1).Select(w => w.All(char.IsUpper) ? w : w.ToLowerInvariant()));
    }

    /// <summary>host / domain / proxy / shared, from the area name — only for colouring.</summary>
    private static string Kind(string name) =>
        Regex.IsMatch(name, "host|gateway|listener|api|web|service ?components|server|worker|app", RegexOptions.IgnoreCase) ? "host"
        : Regex.IsMatch(name, "prox|client|adapter|connector|integration", RegexOptions.IgnoreCase) ? "proxy"
        : Regex.IsMatch(name, "shared|common|util|messag|core|infrastructure|abstraction|contract", RegexOptions.IgnoreCase) ? "shared"
        : "domain";

    private static int KindRank(string kind) => kind switch { "host" => 0, "domain" => 1, "proxy" => 2, _ => 3 };

    private static int TestRank(string area) => area.Contains("support", StringComparison.OrdinalIgnoreCase) ? 0 : area.StartsWith("Unit", StringComparison.OrdinalIgnoreCase) ? 1 : 2;

    private static bool Matches(string pattern, ProjectInfo p)
    {
        var regex = "^" + Regex.Escape(pattern.Trim()).Replace("\\*", ".*") + "$";
        return Regex.IsMatch(p.Name, regex, RegexOptions.IgnoreCase) || Regex.IsMatch(p.Path.Replace('\\', '/'), regex.TrimEnd('$') + "(/|$)", RegexOptions.IgnoreCase);
    }

    private static string? CommonFolder(List<ProjectInfo> projects)
    {
        var folders = projects.Select(ParentFolder).Where(f => f != "(root)").ToList();
        if (folders.Count == 0) return null;
        var prefix = folders[0];
        foreach (var f in folders)
        {
            while (prefix.Length > 0 && !(f.Equals(prefix, StringComparison.OrdinalIgnoreCase) || f.StartsWith(prefix + "/", StringComparison.OrdinalIgnoreCase)))
            {
                prefix = prefix.Contains('/') ? prefix[..prefix.LastIndexOf('/')] : "";
            }
        }
        return prefix.Length == 0 ? null : prefix;
    }

    private static (string Label, List<ProjectInfo> Projects) SelectProjects(CodeIndex index, string? solution)
    {
        var all = index.Manifest.Projects;
        var solutions = index.Manifest.Solutions;
        SolutionInfo? chosen = null;
        if (!string.IsNullOrWhiteSpace(solution))
        {
            var wanted = solution.Trim().Replace('\\', '/');
            chosen = solutions.FirstOrDefault(s => string.Equals(s.Path.Replace('\\', '/'), wanted, StringComparison.OrdinalIgnoreCase))
                     ?? solutions.FirstOrDefault(s => string.Equals(Path.GetFileName(s.Path), Path.GetFileName(wanted), StringComparison.OrdinalIgnoreCase))
                     ?? solutions.FirstOrDefault(s => string.Equals(Path.GetFileNameWithoutExtension(s.Path), Path.GetFileNameWithoutExtension(wanted), StringComparison.OrdinalIgnoreCase))
                     ?? throw new DocGen.Core.Exceptions.ValidationException($"No solution named '{solution}'. Solutions: {(solutions.Count == 0 ? "none" : string.Join(", ", solutions.Select(s => s.Path)))}.");
        }
        else if (solutions.Count == 1)
        {
            chosen = solutions[0];
        }
        if (chosen is null)
        {
            return (solutions.Count == 0 ? "all projects (no solution file)" : $"all projects ({solutions.Count} solutions)", all.ToList());
        }
        var inSolution = chosen.Projects.Select(p => p.Replace('\\', '/')).ToHashSet(StringComparer.OrdinalIgnoreCase);
        return (chosen.Path, all.Where(p => inSolution.Contains(p.Path.Replace('\\', '/'))).ToList());
    }

    /// <summary>tests: test projects; support: non-test code that lives with the tests (fixtures, object mothers, test utilities); production: the rest.</summary>
    private static HashSet<string> ProjectsWithTests(CodeIndex index) => index.TestMethods.Select(t => t.Project).ToHashSet(StringComparer.OrdinalIgnoreCase);

    private static string CategoryOf(ProjectInfo p, HashSet<string> withTests)
    {
        // A test-SDK project without a single test that is named like shared support (TestUtilityComponent,
        // IntegrationTestCommon) is test support, not a test project.
        if (p.IsTestProject && !(SupportName().IsMatch(p.Name) && !withTests.Contains(p.Name) && !p.Name.EndsWith("Tests", StringComparison.OrdinalIgnoreCase) && !p.Name.EndsWith("Test", StringComparison.OrdinalIgnoreCase)))
        {
            return "tests";
        }
        var path = p.Path.Replace('\\', '/');
        return TestFolder().IsMatch(path) || SupportName().IsMatch(p.Name) ? "support" : "production";
    }

    private static string ParentFolder(ProjectInfo p)
    {
        var dir = (string.IsNullOrEmpty(p.Directory) ? Path.GetDirectoryName(p.Path) ?? "" : p.Directory).Replace('\\', '/').TrimEnd('/');
        var parent = dir.Contains('/') ? dir[..dir.LastIndexOf('/')] : "";
        return parent.Length == 0 ? "(root)" : parent;
    }

    /// <summary>
    /// Subgraphs, one per parent folder:
    /// - a folder that also holds other groups' folders (src/Components): each production project directly in it gets
    ///   its own subgraph named by its own folder (src/Components/HostCommon); tests there share one subgraph;
    /// - a folder mixing families of several projects (UnitTests: AuditDomain.* and Proxy.*): one subgraph per family,
    ///   the one-project families together;
    /// - otherwise the folder is one subgraph (NonUIServiceComponents with both hosts).
    /// Ordered production, test support, tests, then by folder.
    /// </summary>
    private static List<(string Id, string Label, List<Node> Members)> Groups(List<Node> nodes)
    {
        var raw = new List<(string Label, int Rank, List<Node> Members)>();
        var categoriesByFolder = nodes.GroupBy(n => n.Folder).ToDictionary(g => g.Key, g => g.Select(n => n.Category).Distinct().Count());
        foreach (var folder in nodes.GroupBy(n => (n.Folder, n.Category)))
        {
            var members = folder.ToList();
            var rank = Array.IndexOf(CategoryOrder, folder.Key.Category);
            var label = folder.Key.Folder + (folder.Key.Category == "support" && categoriesByFolder[folder.Key.Folder] > 1 ? " (shared support)" : "");
            var holdsGroups = nodes.Any(n => n.Folder.StartsWith(folder.Key.Folder + "/", StringComparison.OrdinalIgnoreCase));
            var families = members.GroupBy(m => Family(m.Project.Name)).ToList();
            if (holdsGroups && (folder.Key.Category == "production" || members.Count == 1))
            {
                raw.AddRange(members.Select(m => (OwnFolder(m.Project), rank, new List<Node> { m })));
            }
            else if (holdsGroups && members.Count > 1)
            {
                var names = families.Select(f => f.Key).ToList();
                raw.Add(($"{label} ({string.Join(" / ", names.Take(5))}{(names.Count > 5 ? " / …" : "")})", rank, members));
            }
            else if (families.Count > 1 && families.Any(f => f.Count() > 1))
            {
                var singles = new List<Node>();
                foreach (var family in families)
                {
                    if (family.Count() > 1) raw.Add(($"{label} ({family.Key})", rank, family.ToList()));
                    else singles.AddRange(family);
                }
                if (singles.Count > 0)
                {
                    var names = singles.Select(x => Family(x.Project.Name)).Distinct().ToList();
                    raw.Add(($"{label} ({string.Join(" / ", names.Take(5))}{(names.Count > 5 ? " / …" : "")})", rank, singles));
                }
            }
            else
            {
                raw.Add((members.Count == 1 && holdsGroups ? $"{label} ({Family(members[0].Project.Name)})" : label, rank, members));
            }
        }
        var ids = new HashSet<string>(StringComparer.Ordinal);
        return raw.OrderBy(g => g.Rank).ThenBy(g => g.Label, StringComparer.OrdinalIgnoreCase)
            .Select(g => (UniqueId("G_" + g.Label, ids), g.Label, g.Members)).ToList();
    }

    /// <summary>The project's own folder (src/Components/HostCommon), or its parent when the .csproj sits there directly.</summary>
    private static string OwnFolder(ProjectInfo p)
    {
        var dir = (string.IsNullOrEmpty(p.Directory) ? Path.GetDirectoryName(p.Path) ?? "" : p.Directory).Replace('\\', '/').TrimEnd('/');
        return dir.Length == 0 ? "(root)" : dir;
    }

    private static int Order(List<(string Id, string Label, List<Node> Members)> groups, Node n) => groups.FindIndex(g => g.Members.Contains(n));

    private static string Family(string name) => name.Split('.')[0];

    /// <summary>Drops A→C when A reaches C through another reference (keeps the picture readable on large solutions).</summary>
    private static List<(Node From, Node To)> Reduce(List<(Node From, Node To)> edges)
    {
        var next = edges.GroupBy(e => e.From).ToDictionary(g => g.Key, g => g.Select(e => e.To).ToList());
        bool ReachesWithout(Node from, Node target, Node skipDirect)
        {
            var seen = new HashSet<Node>();
            var stack = new Stack<Node>(next.GetValueOrDefault(from, []).Where(n => n != skipDirect));
            while (stack.Count > 0)
            {
                var n = stack.Pop();
                if (n == target) return true;
                if (!seen.Add(n)) continue;
                foreach (var m in next.GetValueOrDefault(n, [])) stack.Push(m);
            }
            return false;
        }
        return edges.Where(e => !ReachesWithout(e.From, e.To, e.To)).ToList();
    }

    private static List<string> Cycles(List<(Node From, Node To)> edges)
    {
        var next = edges.GroupBy(e => e.From).ToDictionary(g => g.Key, g => g.Select(e => e.To).ToList());
        var state = new Dictionary<Node, int>();
        var stack = new List<Node>();
        var cycles = new List<string>();
        void Visit(Node n)
        {
            state[n] = 1;
            stack.Add(n);
            foreach (var m in next.GetValueOrDefault(n, []))
            {
                if (state.GetValueOrDefault(m) == 1)
                {
                    cycles.Add(string.Join(" → ", stack.Skip(stack.IndexOf(m)).Append(m).Select(x => x.Project.Name)));
                }
                else if (state.GetValueOrDefault(m) == 0)
                {
                    Visit(m);
                }
            }
            stack.RemoveAt(stack.Count - 1);
            state[n] = 2;
        }
        foreach (var n in next.Keys.ToList())
        {
            if (state.GetValueOrDefault(n) == 0) Visit(n);
        }
        return cycles;
    }

    /// <summary>A short readable Mermaid id: the name's words run together ("OrderDomain.Model" → "OrderDomainModel").</summary>
    private static string UniqueId(string text, HashSet<string> taken)
    {
        var id = string.Concat(Regex.Split(text, "[^A-Za-z0-9]+").Where(w => w.Length > 0).Select(w => char.ToUpperInvariant(w[0]) + w[1..]));
        if (id.Length == 0 || char.IsDigit(id[0])) id = "N" + id;
        // Mermaid keywords cannot be ids.
        if (id is "end" or "End" or "subgraph" or "graph" or "flowchart" or "class" or "classDef" or "style" or "click") id += "Node";
        var unique = id;
        for (var i = 2; !taken.Add(unique); i++) unique = id + i;
        return unique;
    }

    private static string Escape(string text) => text.Replace("\"", "#quot;");

    [GeneratedRegex(@"integration|e2e|end[-_]?to[-_]?end|smoke|production(17)?test|acceptance|system[-_]?test", RegexOptions.IgnoreCase)]
    private static partial Regex IntegrationFolder();

    [GeneratedRegex(@"(^|/)(tests?|testing|testutilities|test[-_.]?support|integrationtests?|unittests?)(/|$)", RegexOptions.IgnoreCase)]
    private static partial Regex TestFolder();

    [GeneratedRegex(@"(Test|Tests|Testing|ObjectMother|ObjectMothers|Fake|Fakes|Mock|Mocks|Stub|Stubs|Fixture|Fixtures)\b|Test(Utility|Utilities|Common|Support|Helpers?)", RegexOptions.IgnoreCase)]
    private static partial Regex SupportName();
}
