using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.RegularExpressions;
using DocGen.Analysis.Indexing;

namespace DocGen.Analysis.Architecture;

/// <summary>
/// Renders the deterministic part of the architecture bundle from the model: JSON inventories and metrics, the
/// dependency, type and class diagrams, the API and data model, and a page per project, important type and important
/// method with every fact the index provides. Sections that need understanding (What / Why / How, scenarios, runtime
/// sequences) are left as <see cref="Marker"/> blocks for the skill to write from the source; validation refuses to
/// package a bundle that still contains one.
/// </summary>
public static partial class ArchitectureWriter
{
    public const string Marker = "<!-- architect:write";

    public static readonly JsonSerializerOptions Json = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
    };

    /// <summary>A narrative gap for the skill to fill, with what to write there.</summary>
    internal const string FactsOnly = "_Computed facts only: narrative is written for the key ";

    public static string Write(string what) => $"{Marker} {what} -->\n_To be written from source evidence._\n";

    public sealed record WriteResult(int Files, int TypePages, int MethodPages, int MethodPagesSkipped, int Diagrams, int KeptPages, int NarrativeTypes, int NarrativeMethods);

    public static WriteResult WriteAll(ArchitectureModel model, string outDir, int maxMethodPages, int maxNarrativeTypes = 24, int maxNarrativeMethods = 16)
    {
        Directory.CreateDirectory(outDir);
        var files = 0;
        var diagrams = 0;
        var kept = 0;
        void Put(string relative, string content)
        {
            var path = Path.Combine(outDir, relative.Replace('/', Path.DirectorySeparatorChar));
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            // A page the skill has already written (no markers left, not a facts-only page) is kept when the model is
            // rebuilt, including when a smaller narrative budget would now make it a facts-only page.
            if ((content.Contains(Marker, StringComparison.Ordinal) || content.Contains(FactsOnly, StringComparison.Ordinal)) && File.Exists(path) &&
                File.ReadAllText(path) is var existing && !existing.Contains(Marker, StringComparison.Ordinal) && !existing.Contains(FactsOnly, StringComparison.Ordinal))
            {
                kept++;
                return;
            }
            File.WriteAllText(path, content.Replace("\r\n", "\n"), PartialWriter.EncodingFor(relative));
            files++;
            diagrams += Regex.Matches(content, "^```mermaid", RegexOptions.Multiline).Count;
        }
        void PutJson(string relative, object value) => Put(relative, JsonSerializer.Serialize(value, Json) + "\n");

        var typePage = model.Types.Where(t => t.Tier <= 2 && !t.Symbol.IsTest).ToDictionary(t => t, t => $"classes/{SourceFolder(t.Symbol.File)}{TypeFileName(t)}.md");
        var important = model.Methods.Where(m => m.Important).OrderByDescending(m => m.Metrics.CyclomaticComplexity).ThenBy(m => m.Symbol.FullName, StringComparer.Ordinal).ToList();
        var methodPage = important.Take(maxMethodPages).ToDictionary(m => m, m => $"methods/{SourceFolder(m.Symbol.File)}{TypeFileName(m.Declaring!)}/{MethodFileName(m, model)}.md");

        // Narrative (the write markers) is bounded so one run can finish it: the key tier-1 types by how many reasons
        // made them tier 1, then fan-in and complexity, and the most complex of their important methods. Every other
        // page is complete as a fact page.
        var keyTypes = typePage.Keys.Where(t => t.Tier == 1)
            .OrderByDescending(t => t.TierReasons.Count).ThenByDescending(t => t.Metrics.FanIn).ThenByDescending(t => t.Metrics.CyclomaticComplexity).ThenBy(t => t.Symbol.FullName, StringComparer.Ordinal)
            .Take(maxNarrativeTypes).ToHashSet();
        var keyMethods = methodPage.Keys.Where(m => keyTypes.Contains(m.Declaring!))
            .OrderByDescending(m => m.Metrics.CyclomaticComplexity).ThenByDescending(m => m.ResolvedCalls.Count).ThenBy(m => m.Symbol.FullName, StringComparer.Ordinal)
            .Take(maxNarrativeMethods).ToHashSet();

        WriteInventories(model, PutJson);
        WriteMetrics(model, PutJson);
        WriteProjects(model, Put, typePage);
        WriteTypes(model, Put, typePage, methodPage, keyTypes);
        WriteMethods(model, Put, typePage, methodPage, keyMethods);
        WriteApi(model, Put, PutJson, typePage);
        WriteDatabase(model, Put);
        WriteDiagrams(model, Put, typePage);
        WriteNarrativeStubs(model, Put);
        var result = new WriteResult(files, typePage.Count, methodPage.Count, Math.Max(0, important.Count - maxMethodPages), diagrams, kept, keyTypes.Count, keyMethods.Count);
        PutJson("inventory/analysis.json", new
        {
            schemaVersion = "1.0",
            repository = model.Repository,
            generatedAt = model.GeneratedAt,
            projectsDiscovered = model.Projects.Count,
            sourceFilesDiscovered = model.FilesDiscovered,
            sourceFilesAnalyzed = model.FilesAnalyzed,
            typesDiscovered = model.Types.Count,
            typesTier1 = model.Types.Count(t => t.Tier == 1),
            typesTier2 = model.Types.Count(t => t.Tier == 2),
            typePages = typePage.Count,
            methodsDiscovered = model.Methods.Count,
            importantMethods = important.Count,
            methodPages = methodPage.Count,
            methodPagesNotWritten = result.MethodPagesSkipped,
            narrativeTypes = result.NarrativeTypes,
            narrativeMethods = result.NarrativeMethods,
            apisDiscovered = model.Endpoints.Count,
            databaseEntities = model.Entities.Count,
            generatedFiles = model.GeneratedFiles.Count,
            languagesWithoutTypeAnalysis = model.UnparsedLanguages,
            uncertainCalls = model.Methods.Sum(m => m.AmbiguousCalls.Count),
            lowConfidenceRelationships = model.Relationships.Count(r => r.Confidence == "low"),
            exclusions = model.Exclusions.Distinct().Order(),
        });
        return result;
    }

    // ---------- JSON ----------

    private static void WriteInventories(ArchitectureModel model, Action<string, object> put)
    {
        put("inventory/repository.json", new
        {
            schemaVersion = "1.0",
            repository = model.Repository,
            generatedAt = model.GeneratedAt,
            filesDiscovered = model.FilesDiscovered,
            sourceFilesAnalyzed = model.FilesAnalyzed,
            languages = model.Languages.OrderByDescending(l => l.Value.Lines).Select(l => new { language = l.Key, files = l.Value.Files, lines = l.Value.Lines }),
            projects = model.Projects.Count,
            parsedLanguages = new[] { "C#" },
            languagesWithoutTypeAnalysis = model.UnparsedLanguages,
            exclusions = model.Exclusions.Distinct().Order(),
            generatedFiles = model.GeneratedFiles.Order(),
        });
        put("inventory/projects.json", new
        {
            schemaVersion = "1.0",
            projects = model.Projects.Values.OrderBy(p => p.Info.Name).Select(p => new
            {
                id = p.Id,
                name = p.Info.Name,
                path = p.Info.Path,
                sdk = p.Info.Sdk,
                targetFrameworks = p.Info.TargetFrameworks,
                outputType = p.Info.OutputType,
                isTestProject = p.Info.IsTestProject,
                projectReferences = p.References,
                dependents = p.Dependents,
                packages = p.Info.Packages.Where(x => !x.Transitive).Select(x => new { x.Id, version = x.ResolvedVersion ?? x.Version }),
                frameworkReferences = p.Info.FrameworkReferences,
                entryPoints = p.EntryPoints,
                files = p.Files.Count,
                types = p.Types.Count,
            }),
        });
        put("inventory/types.json", new
        {
            schemaVersion = "1.0",
            types = model.Types.OrderBy(t => t.Symbol.FullName, StringComparer.Ordinal).Select(t => new
            {
                id = t.Id,
                kind = t.Symbol.Kind,
                name = t.Symbol.Name,
                fullyQualifiedName = t.Symbol.FullName,
                @namespace = t.Symbol.Namespace,
                project = t.Symbol.Project,
                source = t.Symbol.File,
                startLine = t.Symbol.StartLine,
                endLine = t.Symbol.EndLine,
                visibility = Visibility(t.Symbol),
                modifiers = t.Symbol.Modifiers,
                attributes = t.Symbol.Attributes,
                bases = t.Symbol.Bases,
                isTest = t.Symbol.IsTest,
                tier = t.Tier,
                tierReasons = t.TierReasons,
            }),
        });
        put("inventory/methods.json", new
        {
            schemaVersion = "1.0",
            methods = model.Methods.OrderBy(m => m.Symbol.FullName, StringComparer.Ordinal).Select(m => new
            {
                id = m.Id,
                kind = m.Symbol.Kind,
                name = m.Symbol.Name,
                declaringType = m.Declaring?.Id,
                signature = m.Symbol.Signature,
                returnType = m.Symbol.ReturnType,
                parameterTypes = m.Symbol.ParameterTypes,
                visibility = Visibility(m.Symbol),
                isAsync = m.Symbol.Modifiers.Contains("async"),
                isStatic = m.Symbol.Modifiers.Contains("static"),
                source = m.Symbol.File,
                startLine = m.Symbol.StartLine,
                endLine = m.Symbol.EndLine,
                calls = m.ResolvedCalls,
                uncertainCalls = m.AmbiguousCalls,
                important = m.Important,
            }),
        });
        put("inventory/dependencies.json", new
        {
            schemaVersion = "1.0",
            note = "Name-based static analysis. confidence: high = declared (project reference, base list, DI); medium = unique name match; low = several types or methods share the name.",
            projectCycles = model.ProjectCycles,
            relationships = model.Relationships.Select(r => new { r.Source, r.Target, relationship = r.Kind, r.Evidence, r.Confidence }),
        });
        put("inventory/di-registrations.json", new
        {
            schemaVersion = "1.0",
            registrations = model.Registrations.Select(r => new { r.Lifetime, r.ServiceType, r.ImplementationType, r.Factory, r.Hosted, r.Method, source = r.File, line = r.Line, r.Project }),
        });
        put("inventory/configuration.json", new
        {
            schemaVersion = "1.0",
            note = "Configuration keys only; values are never copied into the documentation.",
            reads = model.ConfigReads.Select(c => new { c.Kind, c.Key, c.Type, c.Owner, source = c.File, line = c.Line }),
            definedKeys = model.ConfigKeysDefined,
        });
        put("inventory/integrations.json", new
        {
            schemaVersion = "1.0",
            note = "Candidates from package references, typed HTTP clients and configuration keys; the skill confirms each from the source.",
            packages = model.Projects.Values.SelectMany(p => p.Info.Packages.Where(x => !x.Transitive).Select(x => new { project = p.Info.Name, package = x.Id, version = x.ResolvedVersion ?? x.Version })),
            httpClients = model.Registrations.Where(r => r.Method.Contains("HttpClient", StringComparison.OrdinalIgnoreCase))
                .Select(r => new { r.ServiceType, r.ImplementationType, source = r.File, line = r.Line }),
            endpointLikeConfigKeys = model.ConfigReads.Select(c => c.Key).Concat(model.ConfigKeysDefined.Select(k => k.Split(' ')[0]))
                .Where(k => Regex.IsMatch(k, "(Url|Uri|Endpoint|BaseAddress|Host|ConnectionString|Server|Queue|Topic|Bucket)", RegexOptions.IgnoreCase)).Distinct().Order(),
        });
        put("inventory/entities.json", new
        {
            schemaVersion = "1.0",
            dbContexts = model.DbContexts,
            entities = model.Entities.Select(e => new
            {
                e.Name, e.Type, e.DbContext, source = e.File,
                properties = e.Properties.Select(p => new { name = p.Property, type = p.Type }),
                references = e.References.Select(r => new { property = r.Property, target = r.Target, evidence = r.Evidence }),
            }),
        });
    }

    private static void WriteMetrics(ArchitectureModel model, Action<string, object> put)
    {
        const string method = "Static analysis. cyclomaticComplexity is estimated from tokens: 1 + if + case + for + foreach + while + catch + when + && + || + ?? (ternaries not counted). fanIn/fanOut count distinct repository types by name. Coverage is not measured (no coverage data).";
        put("metrics/classes.json", new
        {
            schemaVersion = "1.0",
            method,
            classes = model.Types.OrderBy(t => t.Symbol.FullName, StringComparer.Ordinal).Select(t => new
            {
                name = t.Symbol.Name,
                fullyQualifiedName = t.Symbol.FullName,
                kind = t.Symbol.Kind,
                project = t.Symbol.Project,
                file = t.Symbol.File,
                startLine = t.Symbol.StartLine,
                endLine = t.Symbol.EndLine,
                metrics = t.Metrics,
            }),
        });
        put("metrics/methods.json", new
        {
            schemaVersion = "1.0",
            method,
            methods = model.Methods.OrderBy(m => m.Symbol.FullName, StringComparer.Ordinal).Select(m => new
            {
                @class = m.Declaring?.Symbol.Name,
                method = m.Symbol.Name,
                kind = m.Symbol.Kind,
                file = m.Symbol.File,
                startLine = m.Symbol.StartLine,
                endLine = m.Symbol.EndLine,
                metrics = m.Metrics,
            }),
        });
        put("metrics/projects.json", new
        {
            schemaVersion = "1.0",
            method,
            projects = model.Projects.Values.OrderBy(p => p.Info.Name).Select(p =>
            {
                var methods = model.Methods.Where(m => m.Symbol.Project == p.Info.Name).ToList();
                return new
                {
                    name = p.Info.Name,
                    files = p.Files.Count,
                    types = p.Types.Count,
                    classes = p.Types.Count(t => t.Symbol.Kind is SymbolKinds.Class or SymbolKinds.Record),
                    interfaces = p.Types.Count(t => t.Symbol.Kind == SymbolKinds.Interface),
                    methods = methods.Count,
                    sourceLines = p.SourceLines,
                    commentLines = p.CommentLines,
                    blankLines = p.BlankLines,
                    projectDependencies = p.References.Count,
                    externalDependencies = p.Info.Packages.Count(x => !x.Transitive),
                    tests = p.TestMethods,
                    totalComplexity = methods.Sum(m => m.Metrics.CyclomaticComplexity),
                    averageMethodComplexity = methods.Count == 0 ? 0 : Math.Round(methods.Average(m => m.Metrics.CyclomaticComplexity), 2),
                    maximumMethodComplexity = methods.Count == 0 ? 0 : methods.Max(m => m.Metrics.CyclomaticComplexity),
                };
            }),
        });
        put("metrics/repository.json", new
        {
            schemaVersion = "1.0",
            method,
            filesDiscovered = model.FilesDiscovered,
            sourceFiles = model.FilesAnalyzed,
            projects = model.Projects.Count,
            types = model.Types.Count,
            methods = model.Methods.Count,
            apis = model.Endpoints.Count,
            databaseEntities = model.Entities.Count,
            tests = model.TestMethods,
            sourceLines = model.Projects.Values.Sum(p => p.SourceLines),
            commentLines = model.Projects.Values.Sum(p => p.CommentLines),
            languages = model.Languages.ToDictionary(l => l.Key, l => new { files = l.Value.Files, lines = l.Value.Lines }),
            relationships = model.Relationships.Count,
            projectCycles = model.ProjectCycles.Count,
            totalComplexity = model.Methods.Sum(m => m.Metrics.CyclomaticComplexity),
            averageMethodComplexity = model.Methods.Count == 0 ? 0 : Math.Round(model.Methods.Average(m => m.Metrics.CyclomaticComplexity), 2),
            testCoverage = (object?)null,
        });
        put("metrics/hotspots.json", new
        {
            schemaVersion = "1.0",
            largestTypes = Top(model, t => t.Metrics.SourceLines),
            mostComplexTypes = Top(model, t => t.Metrics.CyclomaticComplexity),
            highestFanOut = Top(model, t => t.Metrics.FanOut),
            highestFanIn = Top(model, t => t.Metrics.FanIn),
            mostComplexMethods = model.Methods.OrderByDescending(m => m.Metrics.CyclomaticComplexity).Take(15)
                .Select(m => new { method = m.Symbol.FullName, file = m.Symbol.File, line = m.Symbol.StartLine, m.Metrics.CyclomaticComplexity, m.Metrics.LinesOfCode }),
            projectCycles = model.ProjectCycles,
        });
    }

    private static IEnumerable<object> Top(ArchitectureModel model, Func<TypeNode, int> by)
        => model.Types.Where(t => !t.Symbol.IsTest).OrderByDescending(by).Take(15).Select(t => new { type = t.Symbol.FullName, file = t.Symbol.File, value = by(t) });

    // ---------- Pages ----------

    private static void WriteProjects(ArchitectureModel model, Action<string, string> put, Dictionary<TypeNode, string> typePage)
    {
        var index = new StringBuilder("# Projects\n\n[Architecture Index](../00-index.md)\n\n| Project | Kind | Types | Source lines | Documentation |\n|---|---|---|---|---|\n");
        foreach (var p in model.Projects.Values.OrderBy(p => p.Info.Name))
        {
            index.Append($"| {Cell(p.Info.Name)} | {ProjectKind(p)} | {p.Types.Count} | {p.SourceLines:N0} | [{Cell(p.Info.Name)}]({Safe(p.Info.Name)}.md) |\n");
            var sb = new StringBuilder($"# {p.Info.Name}\n\n[Architecture Index](../00-index.md) · [Projects](index.md)\n\n");
            sb.Append("## Purpose\n\n").Append(Write($"one paragraph on what {p.Info.Name} is for, from its code")).Append('\n');
            sb.Append("## What\n\n").Append(Write("what this project contains")).Append("\n## Why\n\n").Append(Write("why it exists as a separate project")).Append("\n## How\n\n").Append(Write("how it does its job: main flow, key types")).Append('\n');
            sb.Append($"## Technology\n\n- Project file: `{p.Info.Path}`\n- SDK: {p.Info.Sdk ?? "not stated"}\n- Target frameworks: {Join(p.Info.TargetFrameworks)}\n- Output type: {p.Info.OutputType ?? "Library"}{(p.Info.IsTestProject ? " (test project)" : "")}\n");
            if (p.Info.FrameworkReferences.Count > 0) sb.Append($"- Framework references: {Join(p.Info.FrameworkReferences)}\n");
            sb.Append("\n## Entry Points\n\n").Append(p.EntryPoints.Count == 0 ? "None found (library).\n" : string.Concat(p.EntryPoints.Select(e => $"- `{e}`\n")));
            sb.Append("\n## Internal Structure\n\n| Namespace | Types |\n|---|---|\n");
            foreach (var ns in p.Types.GroupBy(t => t.Symbol.Namespace).OrderBy(g => g.Key)) sb.Append($"| `{(ns.Key.Length == 0 ? "(global)" : ns.Key)}` | {ns.Count()} |\n");
            sb.Append("\n## Important Components\n\n| Type | Kind | Why it matters | Source |\n|---|---|---|---|\n");
            foreach (var t in p.Types.Where(t => t.Tier == 1).OrderByDescending(t => t.Metrics.FanIn + t.Metrics.CyclomaticComplexity).Take(40))
            {
                sb.Append($"| {Link(t, typePage, "../")} | {t.Symbol.Kind} | {string.Join(", ", t.TierReasons)} | `{t.Symbol.File}` |\n");
            }
            sb.Append($"\n## Dependencies\n\n{(p.References.Count == 0 ? "No project references." : string.Join(", ", p.References.Select(r => $"[{r}]({Safe(r)}.md)")))}\n\n## Dependents\n\n{(p.Dependents.Count == 0 ? "No project references it." : string.Join(", ", p.Dependents.Select(r => $"[{r}]({Safe(r)}.md)")))}\n");
            sb.Append("\n## External Dependencies\n\n").Append(p.Info.Packages.Count(x => !x.Transitive) == 0 ? "No package references.\n" : "| Package | Version |\n|---|---|\n" + string.Concat(p.Info.Packages.Where(x => !x.Transitive).Select(x => $"| {Cell(x.Id)} | {x.ResolvedVersion ?? x.Version ?? "—"} |\n")));
            var endpoints = model.Endpoints.Where(e => ProjectOfFile(model, e.File) == p.Info.Name).ToList();
            sb.Append($"\n## APIs\n\n{(endpoints.Count == 0 ? "No HTTP endpoints declared in this project." : $"{endpoints.Count} endpoints — see [API inventory](../api/api-inventory.md).")}\n");
            var regs = model.Registrations.Where(r => r.Project == p.Info.Name).ToList();
            sb.Append($"\n## Configuration\n\n- DI registrations: {regs.Count}\n- Configuration keys read: {model.ConfigReads.Count(c => ProjectOfFile(model, c.File) == p.Info.Name)} (see `inventory/configuration.json`)\n");
            sb.Append($"\n## Diagrams\n\n- [Type dependencies](../diagrams/type-dependencies/{Safe(p.Info.Name)}.md)\n- [Class diagram](../diagrams/classes/{Safe(p.Info.Name)}.md)\n");
            sb.Append($"\n## Metrics\n\n| Metric | Value |\n|---|---|\n| Files | {p.Files.Count} |\n| Types | {p.Types.Count} |\n| Source lines | {p.SourceLines:N0} |\n| Comment lines | {p.CommentLines:N0} |\n| Tests | {p.TestMethods} |\n");
            sb.Append("\n## Architectural Notes\n\n").Append(Write("observed facts about this project's structure, then interpretation; no speculation"));
            put($"projects/{Safe(p.Info.Name)}.md", sb.ToString());
        }
        put("projects/index.md", index.ToString());
    }

    private static void WriteTypes(ArchitectureModel model, Action<string, string> put, Dictionary<TypeNode, string> typePage, Dictionary<MethodNode, string> methodPage, HashSet<TypeNode> keyTypes)
    {
        var index = new StringBuilder("# Classes and Types\n\n[Architecture Index](../00-index.md)\n\nTier 1 and 2 types have pages of computed facts; the key types (marked ★) also have a written narrative; tier 3 (DTOs, enums, tests) are in `inventory/types.json`.\n\n| Type | Kind | Project | Tier | Source lines | Complexity | Documentation |\n|---|---|---|---|---|---|---|\n");
        foreach (var t in model.Types.Where(t => !t.Symbol.IsTest).OrderBy(t => t.Symbol.Project).ThenBy(t => t.Symbol.Name, StringComparer.Ordinal))
        {
            index.Append($"| `{Cell(t.Symbol.Name)}`{(keyTypes.Contains(t) ? " ★" : "")} | {t.Symbol.Kind} | {Cell(t.Symbol.Project)} | {t.Tier} | {t.Metrics.SourceLines} | {t.Metrics.CyclomaticComplexity} | {(typePage.TryGetValue(t, out var page) ? $"[page]({page[8..]})" : "inventory")} |\n");
        }
        put("classes/index.md", index.ToString());

        var byId = model.Types.ToDictionary(t => t.Id);
        foreach (var (t, page) in typePage)
        {
            var s = t.Symbol;
            var outgoing = model.Relationships.Where(r => r.Source == t.Id && byId.ContainsKey(r.Target)).ToList();
            var incoming = model.Relationships.Where(r => r.Target == t.Id && byId.ContainsKey(r.Source)).ToList();
            var up = Up(page);
            var sb = new StringBuilder($"# {s.Name}\n\n[Architecture Index]({up}00-index.md) · [Classes]({up}classes/index.md) · [Project {s.Project}]({up}projects/{Safe(s.Project)}.md)\n\n");
            sb.Append($"## Overview\n\n`{s.FullName}` — {Visibility(s)} {string.Join(' ', s.Modifiers.Where(m => m is "static" or "abstract" or "sealed" or "partial"))} {s.Kind} in project **{s.Project}**. Tier {t.Tier}{(t.TierReasons.Count > 0 ? $" ({string.Join(", ", t.TierReasons)})" : "")}.\n\n");
            if (keyTypes.Contains(t))
            {
                sb.Append("## What\n\n").Append(Write("what this type represents")).Append("\n## Why\n\n").Append(Write("why it exists")).Append("\n## How\n\n").Append(Write("how it fulfils its responsibility, from its code")).Append("\n## Responsibilities\n\n").Append(Write("bullet list of responsibilities")).Append('\n');
            }
            sb.Append($"## Source\n\n`{s.File}` lines {s.StartLine}–{s.EndLine}\n\n");
            if (s.Attributes.Count > 0) sb.Append($"Attributes: {string.Join(", ", s.Attributes.Select(a => $"`[{a}]`"))}\n\n");
            sb.Append("## Relationships\n\n");
            if (s.Bases.Count > 0) sb.Append($"- Bases/interfaces: {string.Join(", ", s.Bases.Select(b => $"`{b}`"))}\n");
            sb.Append($"- Depends on: {(outgoing.Count == 0 ? "no repository types" : string.Join(", ", outgoing.OrderBy(r => byId[r.Target].Symbol.Name).Select(r => $"{Link(byId[r.Target], typePage, up)} ({r.Evidence.Replace('_', ' ')}{(r.Confidence == "low" ? ", uncertain" : "")})")))}\n");
            sb.Append($"- Used by: {(incoming.Count == 0 ? "no repository types" : string.Join(", ", incoming.Select(r => byId[r.Source]).Distinct().OrderBy(x => x.Symbol.Name).Take(40).Select(x => Link(x, typePage, up))))}{(incoming.Count > 40 ? $" and {incoming.Count - 40} more" : "")}\n\n");
            var state = t.Members.Where(m => m.Kind is SymbolKinds.Field or SymbolKinds.Property).ToList();
            if (state.Count > 0)
            {
                sb.Append("## State\n\n| Member | Kind | Type | Visibility |\n|---|---|---|---|\n");
                foreach (var m in state) sb.Append($"| `{Cell(m.Name)}` | {m.Kind} | `{Cell(m.ReturnType ?? "")}` | {Visibility(m)} |\n");
                sb.Append('\n');
            }
            var methods = model.Methods.Where(m => m.Declaring == t).ToList();
            if (methods.Count > 0)
            {
                sb.Append("## Methods\n\n| Method | Visibility | Lines | Complexity | Calls | Documentation |\n|---|---|---|---|---|---|\n");
                foreach (var m in methods)
                {
                    sb.Append($"| `{Cell(m.Symbol.Signature.Length > 0 ? m.Symbol.Signature : m.Symbol.Name)}` | {Visibility(m.Symbol)} | {m.Symbol.StartLine}–{m.Symbol.EndLine} | {m.Metrics.CyclomaticComplexity} | {m.ResolvedCalls.Count + m.AmbiguousCalls.Count} | {(methodPage.TryGetValue(m, out var mp) ? $"[details]({up}{mp})" : "—")} |\n");
                }
                sb.Append('\n');
            }
            sb.Append("## Class Diagram\n\n```mermaid\n").Append(ClassDiagram(t, outgoing.Select(r => (byId[r.Target], r.Kind)).Take(12).ToList(), methods)).Append("```\n\n");
            if (keyTypes.Contains(t))
            {
                sb.Append("## Important Execution Flows\n\n").Append(Write("the main flows through this type; link method pages; add a sequenceDiagram when collaborators are involved")).Append('\n');
            }
            var mt = t.Metrics;
            sb.Append($"## Metrics\n\n| Metric | Value |\n|---|---|\n| Lines (declaration) | {mt.LinesOfCode} |\n| Source / comment / blank lines | {mt.SourceLines} / {mt.CommentLines} / {mt.BlankLines} |\n| Methods / constructors / properties / fields | {mt.MethodCount} / {mt.ConstructorCount} / {mt.PropertyCount} / {mt.FieldCount} |\n| Fan-in / fan-out | {mt.FanIn} / {mt.FanOut} |\n| Inheritance depth | {(mt.InheritanceDepth?.ToString() ?? "n/a")} |\n| Cyclomatic complexity (total / avg / max) | {mt.CyclomaticComplexity} / {mt.AverageMethodComplexity} / {mt.MaximumMethodComplexity} |\n\n");
            if (keyTypes.Contains(t))
            {
                sb.Append("## Architectural Notes\n\n").Append(Write("observed facts (metrics above), interpretation, considerations"));
            }
            else
            {
                sb.Append(FactsOnly + $"types listed in [Classes]({up}classes/index.md)._\n");
            }
            put(page, sb.ToString());
        }
    }

    private static void WriteMethods(ArchitectureModel model, Action<string, string> put, Dictionary<TypeNode, string> typePage, Dictionary<MethodNode, string> methodPage, HashSet<MethodNode> keyMethods)
    {
        var byId = model.Methods.ToDictionary(m => m.Id);
        var index = new StringBuilder("# Methods\n\n[Architecture Index](../00-index.md)\n\nImportant methods (in tier-1 types, with complexity ≥ 4, three or more calls, or an API route) have pages of computed facts; the key methods (marked ★) also have a written narrative and diagrams. Every method is in `inventory/methods.json` and `metrics/methods.json`.\n\n| Method | Type | Complexity | Lines | Documentation |\n|---|---|---|---|---|\n");
        foreach (var (m, page) in methodPage.OrderBy(x => x.Key.Symbol.FullName, StringComparer.Ordinal))
        {
            var key = keyMethods.Contains(m);
            index.Append($"| `{Cell(m.Symbol.Name)}`{(key ? " ★" : "")} | `{Cell(m.Declaring!.Symbol.Name)}` | {m.Metrics.CyclomaticComplexity} | {m.Metrics.LinesOfCode} | [page]({page[8..]}) |\n");
            var s = m.Symbol;
            var up = Up(page);
            var sb = new StringBuilder($"# {m.Declaring!.Symbol.Name}.{s.Name}\n\n[Architecture Index]({up}00-index.md) · [Methods]({up}methods/index.md) · [{m.Declaring.Symbol.Name}]({up}{typePage.GetValueOrDefault(m.Declaring) ?? "classes/index.md"})\n\n");
            if (key) sb.Append("## Purpose\n\n").Append(Write("one sentence")).Append("\n## What\n\n").Append(Write("what it does")).Append("\n## Why\n\n").Append(Write("why it is needed")).Append("\n## How\n\n").Append(Write("how execution proceeds, step by step, from the code")).Append('\n');
            sb.Append($"## Signature\n\n```csharp\n{s.Signature}\n```\n\n");
            sb.Append($"## Parameters\n\n{(s.ParameterTypes.Count == 0 ? "None." : string.Join(", ", s.ParameterTypes.Select(p => $"`{p}`")))}\n\n## Return Value\n\n`{s.ReturnType ?? "void"}`\n\n");
            sb.Append("## Calls\n\n");
            sb.Append(m.ResolvedCalls.Count == 0 ? "No calls to other repository methods resolved by name.\n" : string.Concat(m.ResolvedCalls.Select(c => byId.TryGetValue(c, out var target) ? $"- `{target.Declaring?.Symbol.Name}.{target.Symbol.Name}` ({target.Symbol.File}:{target.Symbol.StartLine})\n" : $"- `{c}`\n")));
            if (m.AmbiguousCalls.Count > 0) sb.Append($"\nUncertain (several methods share the name): {string.Join(", ", m.AmbiguousCalls.Select(c => $"`{c}`"))}\n");
            sb.Append('\n');
            if (key)
            {
                sb.Append("## Side Effects\n\n").Append(Write("state changes, persistence, external calls, messages; write 'None found' if none")).Append('\n');
                sb.Append("## Error Paths\n\n").Append(Write("exceptions thrown or caught, validation failures, early returns")).Append('\n');
                sb.Append("## Sequence Diagram\n\n").Append(Write("a sequenceDiagram of the real collaboration (or 'Diagram omitted: no collaborators' for self-contained logic)")).Append('\n');
                sb.Append("## Flowchart\n\n").Append(Write($"a flowchart of its control flow (complexity {m.Metrics.CyclomaticComplexity}); omit with a note when it is linear")).Append('\n');
            }
            sb.Append($"## Metrics\n\n| Metric | Value |\n|---|---|\n| Source lines | {m.Metrics.LinesOfCode} |\n| Cyclomatic complexity (estimated) | {m.Metrics.CyclomaticComplexity} |\n| Branches | {m.Metrics.BranchCount} |\n| Parameters | {m.Metrics.ParameterCount} |\n| Distinct calls | {m.Metrics.DependencyCalls} |\n\n");
            sb.Append($"## Source\n\n`{s.File}` lines {s.StartLine}–{s.EndLine}\n");
            if (!key) sb.Append("\n" + FactsOnly + $"methods listed in [Methods]({up}methods/index.md)._\n");
            put(page, sb.ToString());
        }
        put("methods/index.md", index.ToString());
    }

    private static void WriteApi(ArchitectureModel model, Action<string, string> put, Action<string, object> putJson, Dictionary<TypeNode, string> typePage)
    {
        var types = model.Types.GroupBy(t => t.Symbol.Name).ToDictionary(g => g.Key, g => g.First());
        var sb = new StringBuilder("# API Inventory\n\n[Architecture Index](../00-index.md) · [API](index.md)\n\n");
        if (model.Endpoints.Count == 0)
        {
            sb.Append("No HTTP endpoints were found (controllers, minimal APIs, SignalR hubs, gRPC services).\n");
        }
        else
        {
            sb.Append("| Method | Route | Handler | Style | Source |\n|---|---|---|---|---|\n");
            foreach (var e in model.Endpoints.OrderBy(e => e.Route, StringComparer.Ordinal).ThenBy(e => e.Verb))
            {
                var handlerType = e.Handler.Split('.')[0];
                var handler = types.TryGetValue(handlerType, out var t) && typePage.TryGetValue(t, out var page) ? $"[`{Cell(e.Handler)}`](../{page})" : $"`{Cell(e.Handler)}`";
                sb.Append($"| {e.Verb} | `{Cell(e.Route)}` | {handler} | {e.Style} | `{e.File}:{e.Line}` |\n");
            }
            sb.Append("\n## Authentication, validation and errors\n\n").Append(Write("per group of endpoints: auth/authorization (attributes, policies, middleware), validation, the services they call and the errors they return — from the handler code"));
        }
        put("api/api-inventory.md", sb.ToString());
        putJson("api/api-inventory.json", new
        {
            schemaVersion = "1.0",
            endpoints = model.Endpoints.Select(e => new { id = $"api:{e.Verb} {e.Route}", method = e.Verb, route = e.Route, handler = e.Handler, style = e.Style, source = e.File, line = e.Line }),
        });
        put("api/index.md", $"# APIs\n\n[Architecture Index](../00-index.md)\n\n- [API inventory](api-inventory.md) ({model.Endpoints.Count} endpoints)\n- Machine-readable: `api-inventory.json`\n\n## What\n\n{Write("what the API offers and to whom")}\n## How\n\n{Write("how requests are handled end to end (middleware, auth, controllers/handlers)")}");
    }

    private static void WriteDatabase(ArchitectureModel model, Action<string, string> put)
    {
        if (model.Entities.Count == 0)
        {
            put("database/index.md", "# Data and Persistence\n\n[Architecture Index](../00-index.md)\n\nNo Entity Framework `DbContext` or `DbSet<T>` was found by static analysis.\n\n## What\n\n" +
                Write("how the system actually stores data (files, JSON stores, other databases, caches) — from the code; or 'No persistence' if there is none") +
                "\n## Diagram\n\n" + Write("an erDiagram or flowchart of the persisted records if the storage model is clear from the code, else 'Diagram omitted: insufficient repository evidence.'"));
            return;
        }
        var er = new StringBuilder("erDiagram\n");
        foreach (var e in model.Entities)
        {
            er.Append($"    {Id(e.Type)} {{\n");
            foreach (var (prop, type) in e.Properties.Where(p => !p.Type.Contains('<')).Take(25))
            {
                er.Append($"        {Id(CodeIndexName(type))} {Id(prop)}{(prop == "Id" || prop == e.Type + "Id" ? " PK" : "")}\n");
            }
            er.Append("    }\n");
        }
        foreach (var e in model.Entities)
        {
            foreach (var (prop, target, evidence) in e.References.DistinctBy(r => r.Target))
            {
                er.Append($"    {Id(e.Type)} {(evidence.StartsWith("collection") ? "||--o{" : "}o--||")} {Id(target)} : \"{Label(prop)}\"\n");
            }
        }
        put("database/er-diagram.md", $"# Entity Relationship Diagram\n\n[Architecture Index](../00-index.md) · [Database](index.md)\n\nFrom `DbSet<T>` properties of {string.Join(", ", model.DbContexts.Select(d => $"`{d}`"))}; relationships from navigation properties and `…Id` naming (inferred).\n\n```mermaid\n{er}```\n");
        var schema = new StringBuilder("# Schema\n\n[Architecture Index](../00-index.md) · [Database](index.md)\n\n");
        foreach (var e in model.Entities)
        {
            schema.Append($"## {e.Type} (`{e.Name}` in {e.DbContext})\n\nSource: `{e.File}`\n\n| Property | Type |\n|---|---|\n{string.Concat(e.Properties.Select(p => $"| {Cell(p.Property)} | `{Cell(p.Type)}` |\n"))}\n");
        }
        put("database/schema.md", schema.ToString());
        put("database/index.md", $"# Data and Persistence\n\n[Architecture Index](../00-index.md)\n\n- [Schema](schema.md) ({model.Entities.Count} entities)\n- [ER diagram](er-diagram.md)\n\n## What\n\n{Write("the persistence technology and what is stored, from the code and configuration")}\n## How\n\n{Write("how the code reads and writes data (repositories, contexts, transactions, migrations)")}");
    }

    private static void WriteDiagrams(ArchitectureModel model, Action<string, string> put, Dictionary<TypeNode, string> typePage)
    {
        var graph = new StringBuilder("flowchart LR\n");
        foreach (var p in model.Projects.Values.OrderBy(p => p.Info.Name))
        {
            graph.Append($"    {Id(p.Info.Name)}[\"{Label(p.Info.Name)}\"]\n");
        }
        foreach (var p in model.Projects.Values.OrderBy(p => p.Info.Name))
        {
            foreach (var r in p.References.Order())
            {
                graph.Append($"    {Id(p.Info.Name)} --> {Id(r)}\n");
            }
        }
        var tests = model.Projects.Values.Where(p => p.Info.IsTestProject).Select(p => Id(p.Info.Name)).ToList();
        if (tests.Count > 0)
        {
            graph.Append("    classDef test fill:#eef6ee,stroke:#6a9f6a\n").Append($"    class {string.Join(",", tests)} test\n");
        }
        put("diagrams/project-dependencies.md", $"# Project Dependencies\n\n[Architecture Index](../00-index.md) · [Diagrams](index.md)\n\nFrom project references in the project files. An arrow points from a project to one it references.{(tests.Count > 0 ? " Test projects are shaded green." : "")}\n\n```mermaid\n{graph}```\n\n" +
            (model.ProjectCycles.Count == 0 ? "No dependency cycles between projects.\n" : "Dependency cycles found: " + string.Join("; ", model.ProjectCycles.Select(c => string.Join(" → ", c))) + "\n"));

        var byId = model.Types.ToDictionary(t => t.Id);
        foreach (var p in model.Projects.Values.Where(p => p.Types.Count > 0).OrderBy(p => p.Info.Name))
        {
            // The most connected types of the project (a diagram stays readable at about 30 nodes).
            var nodes = p.Types.Where(t => !t.Symbol.IsTest).OrderByDescending(t => t.Metrics.FanIn + t.Metrics.FanOut).Take(30).ToHashSet();
            var edges = model.Relationships.Where(r => r.Kind is "depends_on" or "inherits" or "implements" && byId.TryGetValue(r.Source, out var a) && nodes.Contains(a)
                                                       && byId.TryGetValue(r.Target, out var b) && nodes.Contains(b) && r.Confidence != "low").ToList();
            var d = new StringBuilder("flowchart LR\n");
            foreach (var t in nodes.OrderBy(t => t.Symbol.Name)) d.Append($"    {Id(t.Symbol.FullName)}[\"{Label(t.Symbol.Name)}\"]\n");
            foreach (var e in edges) d.Append($"    {Id(byId[e.Source].Symbol.FullName)} {(e.Kind == "depends_on" ? "-->" : "-.->|" + e.Kind + "|")} {Id(byId[e.Target].Symbol.FullName)}\n");
            var omitted = p.Types.Count(t => !t.Symbol.IsTest) - nodes.Count;
            put($"diagrams/type-dependencies/{Safe(p.Info.Name)}.md", $"# Type Dependencies — {p.Info.Name}\n\n[Architecture Index](../../00-index.md) · [Diagrams](../index.md) · [Project](../../projects/{Safe(p.Info.Name)}.md)\n\n" +
                $"The {nodes.Count} most connected types{(omitted > 0 ? $" ({omitted} others in `inventory/types.json`)" : "")}. Solid arrows: uses/depends on; dotted: inherits/implements. Name-based edges with several possible targets are left out.\n\n```mermaid\n{d}```\n");

            var tier1 = p.Types.Where(t => t.Tier == 1).OrderByDescending(t => t.Metrics.FanIn).Take(12).ToList();
            if (tier1.Count > 0)
            {
                var c = new StringBuilder("classDiagram\n");
                foreach (var t in tier1) AppendClass(c, t, model.Methods.Where(m => m.Declaring == t && m.Symbol.Modifiers.Contains("public")).Take(6).ToList());
                var set = tier1.ToHashSet();
                foreach (var r in model.Relationships.Where(r => byId.TryGetValue(r.Source, out var a) && set.Contains(a) && byId.TryGetValue(r.Target, out var b) && set.Contains(b) && r.Confidence != "low"))
                {
                    c.Append($"    {Id(byId[r.Source].Symbol.Name)} {(r.Kind == "inherits" ? "--|>" : r.Kind == "implements" ? "..|>" : "-->")} {Id(byId[r.Target].Symbol.Name)}\n");
                }
                put($"diagrams/classes/{Safe(p.Info.Name)}.md", $"# Class Diagram — {p.Info.Name}\n\n[Architecture Index](../../00-index.md) · [Diagrams](../index.md)\n\nThe project's most used tier-1 types and their public methods.\n\n```mermaid\n{c}```\n");
            }
            else
            {
                put($"diagrams/classes/{Safe(p.Info.Name)}.md", $"# Class Diagram — {p.Info.Name}\n\n[Architecture Index](../../00-index.md) · [Diagrams](../index.md)\n\nDiagram omitted: the project has no tier-1 types.\n");
            }
        }
    }

    private static void WriteNarrativeStubs(ArchitectureModel model, Action<string, string> put)
    {
        var langs = string.Join(", ", model.Languages.OrderByDescending(l => l.Value.Lines).Select(l => $"{l.Key} ({l.Value.Files} files, {l.Value.Lines:N0} lines)"));
        put("01-overview.md", "# Overview\n\n[Architecture Index](00-index.md)\n\n## What\n\n" + Write("what the system is, in one paragraph (this paragraph becomes the index summary)") +
            "\n## Why\n\n" + Write("the problem it solves, from README and code") + "\n## How\n\n" + Write("how it is structured and how it operates: main components and execution paths") +
            "\n## Capabilities\n\n" + Write("major capabilities") + "\n## Architecture Style\n\n" + Write("the style, with evidence (see 03-architecture.md)") + "\n");
        put("02-repository-structure.md", "# Repository Structure\n\n[Architecture Index](00-index.md)\n\n## Projects\n\n" +
            string.Concat(model.Projects.Values.OrderBy(p => p.Info.Path).Select(p => $"- `{p.Info.Path}` — [{p.Info.Name}](projects/{Safe(p.Info.Name)}.md)\n")) +
            $"\n## Excluded from analysis\n\n{string.Concat(model.Exclusions.Distinct().Order().Take(60).Select(e => $"- `{e}`\n"))}\n## Layout\n\n" + Write("how the folders are organised and why"));
        put("03-architecture.md", "# Architecture\n\n[Architecture Index](00-index.md)\n\n## Style and layers\n\n" + Write("the architecture style and layers, each claim with evidence (project references, namespaces, types)") +
            "\n## Patterns\n\n" + Write("patterns with evidence, participants, purpose and consequences; only those with structural evidence") +
            "\n## Component Diagram\n\nSee [block diagram](diagrams/block-diagram.md) and [project dependencies](diagrams/project-dependencies.md).\n");
        put("04-technology-stack.md", $"# Technology Stack\n\n[Architecture Index](00-index.md)\n\n## Languages\n\n{langs}\n\n## Frameworks\n\n" +
            string.Concat(model.Projects.Values.SelectMany(p => p.Info.TargetFrameworks.Select(f => (f, p.Info.Sdk ?? "")))
                .Distinct().Select(x => $"- {x.f} ({(x.Item2.Length == 0 ? "SDK not stated" : x.Item2)})\n")) +
            "\n## Packages\n\nSee `inventory/integrations.json` and each project page.\n\n## Summary\n\n" + Write("the stack in a few sentences: runtime, web framework, persistence, messaging, testing") +
            (model.UnparsedLanguages.Count > 0 ? $"\nLanguages without type-level analysis: {string.Join(", ", model.UnparsedLanguages)}.\n" : ""));
        put("05-data-flow.md", "# Data Flow\n\n[Architecture Index](00-index.md)\n\n" + Write("how data enters, moves through and leaves the system, with at least one flowchart of real components"));
        put("06-security.md", "# Security Architecture\n\n[Architecture Index](00-index.md)\n\n" + Write("authentication, authorization, secrets handling, input validation and boundaries — evidence only, no verdicts"));
        put("07-deployment.md", "# Deployment\n\n[Architecture Index](00-index.md)\n\n" + Write("deployable units, ports, hosting, CI/CD from the repository files; 'Not determined from static repository analysis.' where there is no evidence"));
        var hot = new StringBuilder("# Hotspots\n\n[Architecture Index](00-index.md)\n\nMeasured by static analysis (see `metrics/hotspots.json`). Numbers first; interpretation below.\n\n| Type | Source lines | Complexity | Fan-in | Fan-out |\n|---|---|---|---|---|\n");
        foreach (var t in model.Types.Where(t => !t.Symbol.IsTest).OrderByDescending(t => t.Metrics.CyclomaticComplexity + t.Metrics.FanOut * 2).Take(15))
        {
            hot.Append($"| `{Cell(t.Symbol.FullName)}` | {t.Metrics.SourceLines} | {t.Metrics.CyclomaticComplexity} | {t.Metrics.FanIn} | {t.Metrics.FanOut} |\n");
        }
        hot.Append("\n| Method | Complexity | Source lines | Source |\n|---|---|---|---|\n");
        foreach (var m in model.Methods.OrderByDescending(m => m.Metrics.CyclomaticComplexity).Take(15))
        {
            hot.Append($"| `{Cell((m.Declaring?.Symbol.Name ?? "") + "." + m.Symbol.Name)}` | {m.Metrics.CyclomaticComplexity} | {m.Metrics.LinesOfCode} | `{m.Symbol.File}:{m.Symbol.StartLine}` |\n");
        }
        hot.Append($"\nProject dependency cycles: {(model.ProjectCycles.Count == 0 ? "none" : string.Join("; ", model.ProjectCycles.Select(c => string.Join(" → ", c))))}.\n\n## Observations\n\n")
           .Append(Write("for each hotspot: observed fact, architectural interpretation, possible consideration — never 'bad architecture' without evidence"));
        put("08-hotspots.md", hot.ToString());
        put("glossary.md", "# Glossary\n\n[Architecture Index](00-index.md)\n\n" + Write("domain and technical terms used in the code, each with where it appears"));
        put("scenarios/index.md", "# Scenarios\n\n[Architecture Index](../00-index.md)\n\nOne page per important scenario (`scenarios/<name>.md`), each with an activity flowchart and a sequence diagram of real components. The architecture index lists them.\n\n" +
            Write("a short list of the scenarios found in the code (entry points, API groups, background jobs), then write one page per scenario and delete this marker"));
        put("diagrams/block-diagram.md", "# Block Diagram\n\n[Architecture Index](../00-index.md) · [Diagrams](index.md)\n\n" + Write("a flowchart LR of applications, services, stores and external systems with real names"));
        put("diagrams/system-context.md", "# System Context\n\n[Architecture Index](../00-index.md) · [Diagrams](index.md)\n\n" + Write("a flowchart of the system, its users and the external systems it talks to"));
        put("diagrams/deployment.md", "# Deployment Diagram\n\n[Architecture Index](../00-index.md) · [Diagrams](index.md)\n\n" + Write("a deployment flowchart if the repository shows how it is deployed, else 'Diagram omitted: insufficient repository evidence.'"));
    }

    // ---------- Helpers ----------

    private static string ClassDiagram(TypeNode t, List<(TypeNode Target, string Kind)> related, List<MethodNode> methods)
    {
        var sb = new StringBuilder("classDiagram\n");
        AppendClass(sb, t, methods.Where(m => !m.Symbol.Modifiers.Contains("private")).Take(10).ToList());
        foreach (var (target, kind) in related.DistinctBy(r => r.Target))
        {
            sb.Append($"    class {Id(target.Symbol.Name)}\n");
            if (target.Symbol.Kind == SymbolKinds.Interface) sb.Append($"    <<interface>> {Id(target.Symbol.Name)}\n");
            sb.Append($"    {Id(t.Symbol.Name)} {(kind == "inherits" ? "--|>" : kind == "implements" ? "..|>" : "-->")} {Id(target.Symbol.Name)}\n");
        }
        return sb.ToString();
    }

    private static void AppendClass(StringBuilder sb, TypeNode t, List<MethodNode> methods)
    {
        sb.Append($"    class {Id(t.Symbol.Name)} {{\n");
        if (t.Symbol.Kind == SymbolKinds.Interface) sb.Append("        <<interface>>\n");
        foreach (var p in t.Members.Where(m => m.Kind == SymbolKinds.Property && m.Modifiers.Contains("public")).Take(6))
        {
            sb.Append($"        +{Member(p.ReturnType ?? "")} {Member(p.Name)}\n");
        }
        foreach (var m in methods)
        {
            sb.Append($"        {(m.Symbol.Modifiers.Contains("public") ? "+" : m.Symbol.Modifiers.Contains("private") ? "-" : "#")}{Member(m.Symbol.Name)}({Member(string.Join(", ", m.Symbol.ParameterTypes))})\n");
        }
        sb.Append("    }\n");
    }

    /// <summary>Text inside a class diagram member: generics as ~T~, nothing Mermaid treats as syntax.</summary>
    internal static string Member(string text) => Regex.Replace(text.Replace('<', '~').Replace('>', '~').Replace("[]", "Array"), @"[^A-Za-z0-9_~,. ?]", "");

    public static string Id(string text)
    {
        var id = Regex.Replace(text, "[^A-Za-z0-9_]", "_");
        return id.Length > 0 && char.IsDigit(id[0]) ? "n" + id : id.Length == 0 ? "node" : id;
    }

    public static string Label(string text) => text.Replace("\"", "#quot;").Replace("<", "#lt;").Replace(">", "#gt;");

    internal static string Cell(string text) => text.Replace("|", "\\|").Replace("\n", " ");

    public static string Safe(string text)
    {
        var safe = Regex.Replace(text, @"[^A-Za-z0-9._-]+", "-").Trim('-', '.');
        return safe.Length == 0 ? "item" : safe;
    }

    /// <summary>The repository-relative folder of a source file as a page path prefix ("src/Shop/Orders/"), each segment made safe.</summary>
    internal static string SourceFolder(string file)
    {
        var folder = Path.GetDirectoryName(file.Replace('\\', '/'))?.Replace('\\', '/') ?? "";
        return folder.Length == 0 ? "" : string.Join('/', folder.Split('/', StringSplitOptions.RemoveEmptyEntries).Select(Safe)) + "/";
    }

    /// <summary>"../" once per folder level of a bundle page, to reach the bundle root.</summary>
    internal static string Up(string page) => string.Concat(Enumerable.Repeat("../", page.Count(c => c == '/')));

    private static string TypeFileName(TypeNode t)
    {
        // Nested types and same-named types in different namespaces stay distinct.
        var container = t.Symbol.FullName.StartsWith(t.Symbol.Namespace + ".", StringComparison.Ordinal) ? t.Symbol.FullName[(t.Symbol.Namespace.Length + 1)..] : t.Symbol.FullName;
        return Safe(container);
    }

    private static string MethodFileName(MethodNode m, ArchitectureModel model)
    {
        var overloaded = model.Methods.Count(x => x.Declaring == m.Declaring && x.Symbol.Name == m.Symbol.Name) > 1;
        if (!overloaded)
        {
            return Safe(m.Symbol.Name);
        }
        var hash = Convert.ToHexString(SHA1.HashData(Encoding.UTF8.GetBytes(string.Join(",", m.Symbol.ParameterTypes))))[..6].ToLowerInvariant();
        return Safe(m.Symbol.Name) + "-" + hash;
    }

    private static string Link(TypeNode t, Dictionary<TypeNode, string> pages, string up) => pages.TryGetValue(t, out var page) ? $"[`{Cell(t.Symbol.Name)}`]({up}{page})" : $"`{Cell(t.Symbol.Name)}`";

    internal static string Visibility(SymbolRecord s) => s.Modifiers.FirstOrDefault(m => m is "public" or "internal" or "protected" or "private") ?? "private";

    private static string ProjectKind(ProjectNode p) => p.Info.IsTestProject ? "tests" : p.Info.OutputType is "Exe" or "WinExe" || (p.Info.Sdk ?? "").Contains("Web", StringComparison.Ordinal) ? "application" : "library";

    private static string Join(IEnumerable<string> items) => items.Any() ? string.Join(", ", items) : "not stated";

    private static string CodeIndexName(string type) => CodeIndex.StripGeneric(type).TrimEnd('?');

    private static string? ProjectOfFile(ArchitectureModel model, string file)
        => model.Projects.Values.FirstOrDefault(p => p.Files.Contains(file, StringComparer.OrdinalIgnoreCase))?.Info.Name;
}
