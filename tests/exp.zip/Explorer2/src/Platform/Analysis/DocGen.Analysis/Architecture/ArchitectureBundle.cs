using System.Diagnostics;
using System.IO.Compression;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace DocGen.Analysis.Architecture;

public sealed record BundleCheck(List<string> Errors, List<string> Warnings, int Markdown, int Json, int Diagrams, int DiagramsValidated, IReadOnlyDictionary<string, int> DiagramTypes);

/// <summary>
/// Finishes an architecture bundle: builds the navigation (00-index.md, diagram index, scenario inventory, coverage
/// report, manifest) from the files that exist, validates everything (JSON, relative links, unfinished sections,
/// secrets, Mermaid syntax with the real Mermaid parser) and packages the folder as a ZIP whose root is architecture/.
/// </summary>
public static partial class ArchitectureBundle
{
    private static readonly string[] Required =
    [
        "00-index.md", "01-overview.md", "03-architecture.md", "projects/index.md", "classes/index.md", "diagrams/project-dependencies.md",
        "diagrams/block-diagram.md", "api/api-inventory.json", "metrics/repository.json", "metrics/projects.json", "metrics/classes.json", "metrics/methods.json",
        "inventory/types.json", "inventory/dependencies.json", "manifest.json",
    ];

    private static readonly string[] PartialRequired =
    [
        "00-index.md", "01-feature-overview.md", "02-program-flow.md", "03-project-boundaries.md", "05-classes.md", "flows/program-flow.md", "flows/program-flow.json",
        "flows/call-chain.md", "diagrams/activity.md", "diagrams/sequence.md", "diagrams/call-graph.md", "inventory/scope.json", "manifest.json",
    ];

    /// <summary>A bundle for a requested scope (Partial Architecture Mode) rather than a whole repository.</summary>
    public static bool IsPartial(string outDir) => File.Exists(Path.Combine(outDir, "inventory", "scope.json"));

    // ---------- Navigation ----------

    public static void BuildIndexes(string outDir)
    {
        if (IsPartial(outDir))
        {
            BuildPartialManifest(outDir);
            return;
        }
        var analysis = ReadJson(outDir, "inventory/analysis.json");
        var repository = analysis?.GetProperty("repository").GetString() ?? Path.GetFileName(Path.GetDirectoryName(outDir)) ?? "repository";
        var pages = MarkdownFiles(outDir);
        var diagrams = new List<(string Type, string Scope, string File)>();
        foreach (var page in pages.Where(p => p != "00-index.md" && p != "diagrams/index.md"))
        {
            var text = File.ReadAllText(Path.Combine(outDir, page));
            var title = Title(text) ?? page;
            foreach (Match m in MermaidBlock().Matches(text))
            {
                diagrams.Add((m.Groups[1].Value.Trim().Split(' ', '\n')[0], title, page));
            }
        }

        var scenarios = pages.Where(p => p.StartsWith("scenarios/", StringComparison.Ordinal) && p != "scenarios/index.md")
            .Select(p => (File: p, Text: File.ReadAllText(Path.Combine(outDir, p)))).Select(x => (x.File, Name: (Title(x.Text) ?? x.File).Replace("Scenario:", "").Trim(), Goal: Section(x.Text, "Goal"))).ToList();
        File.WriteAllText(Path.Combine(outDir, "inventory", "scenarios.json"), JsonSerializer.Serialize(new
        {
            schemaVersion = "1.0",
            scenarios = scenarios.Select(s => new { id = "scenario:" + ArchitectureWriter.Safe(s.Name).ToLowerInvariant(), name = s.Name, description = s.Goal, source = s.File }),
        }, ArchitectureWriter.Json) + "\n");

        var sb = new StringBuilder("# Architecture Documentation\n\n");
        var summary = pages.Contains("01-overview.md") ? Section(File.ReadAllText(Path.Combine(outDir, "01-overview.md")), "What") : null;
        sb.Append("## System Summary\n\n").Append(string.IsNullOrWhiteSpace(summary) ? "See the [overview](01-overview.md)." : summary).Append("\n\n");
        sb.Append("## Documentation Map\n\n");
        foreach (var (label, file) in new[]
        {
            ("Overview", "01-overview.md"), ("Repository Structure", "02-repository-structure.md"), ("Architecture", "03-architecture.md"), ("Technology Stack", "04-technology-stack.md"),
            ("Project Dependencies", "diagrams/project-dependencies.md"), ("Component / Block Diagram", "diagrams/block-diagram.md"), ("System Context", "diagrams/system-context.md"),
            ("Diagrams", "diagrams/index.md"), ("Projects", "projects/index.md"), ("Classes", "classes/index.md"), ("Methods", "methods/index.md"), ("APIs", "api/index.md"),
            ("Database", "database/index.md"), ("Scenarios", "scenarios/index.md"), ("Data Flows", "05-data-flow.md"), ("Security", "06-security.md"), ("Deployment", "07-deployment.md"),
            ("Metrics", "metrics/repository.json"), ("Hotspots", "08-hotspots.md"), ("Coverage", "coverage.md"), ("Glossary", "glossary.md"),
        })
        {
            if (file is "diagrams/index.md" or "coverage.md" || File.Exists(Path.Combine(outDir, file)))
            {
                sb.Append($"- [{label}]({file})\n");
            }
        }

        sb.Append("\n## Diagram Index\n\n| Diagram | Type | Scope | File |\n|---|---|---|---|\n");
        var n = 0;
        foreach (var d in diagrams.OrderBy(d => d.File, StringComparer.Ordinal))
        {
            sb.Append($"| {++n} | {d.Type} | {Cell(d.Scope)} | [{d.File}]({d.File}) |\n");
        }
        var projects = ReadJson(outDir, "inventory/projects.json");
        sb.Append("\n## Project Index\n\n| Project | Purpose | Documentation |\n|---|---|---|\n");
        foreach (var p in projects?.GetProperty("projects").EnumerateArray() ?? Enumerable.Empty<JsonElement>())
        {
            var name = p.GetProperty("name").GetString()!;
            var file = $"projects/{ArchitectureWriter.Safe(name)}.md";
            var purpose = File.Exists(Path.Combine(outDir, file)) ? FirstSentence(Section(File.ReadAllText(Path.Combine(outDir, file)), "Purpose")) : "";
            sb.Append($"| {Cell(name)} | {Cell(purpose)} | [{name}]({file}) |\n");
        }
        sb.Append("\n## Class Index\n\nImportant types (all types: [classes/index.md](classes/index.md)).\n\n| Class | Project | Responsibility | Documentation |\n|---|---|---|---|\n");
        foreach (var page in pages.Where(p => p.StartsWith("classes/", StringComparison.Ordinal) && p != "classes/index.md").Order(StringComparer.Ordinal))
        {
            var text = File.ReadAllText(Path.Combine(outDir, page));
            if (!text.Contains("## What", StringComparison.Ordinal))
            {
                continue; // tier-2 fact pages are reached from the class index
            }
            sb.Append($"| `{Cell(Title(text) ?? page)}` | {Cell(Regex.Match(text, @"in project \*\*([^*]+)\*\*").Groups[1].Value)} | {Cell(FirstSentence(Section(text, "What")))} | [page]({page}) |\n");
        }
        sb.Append("\n## Scenario Index\n\n| Scenario | Description | Documentation |\n|---|---|---|\n");
        foreach (var s in scenarios)
        {
            sb.Append($"| {Cell(s.Name)} | {Cell(FirstSentence(s.Goal))} | [{s.File}]({s.File}) |\n");
        }
        var api = ReadJson(outDir, "api/api-inventory.json");
        sb.Append("\n## API Index\n\n| API | Method/Protocol | Handler | Documentation |\n|---|---|---|---|\n");
        foreach (var e in api?.GetProperty("endpoints").EnumerateArray() ?? Enumerable.Empty<JsonElement>())
        {
            sb.Append($"| `{Cell(e.GetProperty("route").GetString() ?? "")}` | {e.GetProperty("method").GetString()} | `{Cell(e.GetProperty("handler").GetString() ?? "")}` | [inventory](api/api-inventory.md) |\n");
        }
        File.WriteAllText(Path.Combine(outDir, "00-index.md"), sb.ToString(), new UTF8Encoding(true));

        var dsb = new StringBuilder("# Diagrams\n\n[Architecture Index](../00-index.md)\n\n| Diagram | Type | Scope | File |\n|---|---|---|---|\n");
        n = 0;
        foreach (var d in diagrams.OrderBy(d => d.File, StringComparer.Ordinal))
        {
            var relative = d.File.StartsWith("diagrams/", StringComparison.Ordinal) ? d.File["diagrams/".Length..] : "../" + d.File;
            dsb.Append($"| {++n} | {d.Type} | {Cell(d.Scope)} | [{d.File}]({relative}) |\n");
        }
        File.WriteAllText(Path.Combine(outDir, "diagrams", "index.md"), dsb.ToString(), new UTF8Encoding(true));

        // Coverage: what was analysed, what was not.
        var cov = new StringBuilder("# Analysis Coverage\n\n[Architecture Index](00-index.md)\n\n");
        int Num(string key) => analysis is { } a && a.TryGetProperty(key, out var v) && v.ValueKind == JsonValueKind.Number ? v.GetInt32() : 0;
        var methodPages = pages.Count(p => p.StartsWith("methods/", StringComparison.Ordinal) && p != "methods/index.md");
        cov.Append($"- Projects discovered: {Num("projectsDiscovered")}\n- Projects documented: {pages.Count(p => p.StartsWith("projects/") && p != "projects/index.md")}\n- Source files discovered: {Num("sourceFilesDiscovered")}\n- Source files analyzed: {Num("sourceFilesAnalyzed")}\n");
        cov.Append($"- Types discovered: {Num("typesDiscovered")} (tier 1: {Num("typesTier1")}, tier 2: {Num("typesTier2")})\n- Types documented (pages): {pages.Count(p => p.StartsWith("classes/", StringComparison.Ordinal) && p != "classes/index.md")}\n");
        cov.Append($"- Methods discovered: {Num("methodsDiscovered")}\n- Important methods: {Num("importantMethods")}; with pages: {methodPages}; without a page (over the limit): {Num("methodPagesNotWritten")}\n");
        cov.Append($"- APIs discovered: {Num("apisDiscovered")}\n- Database entities discovered: {Num("databaseEntities")}\n- Scenarios documented: {scenarios.Count}\n- Diagrams generated: {diagrams.Count}\n\n");
        cov.Append("## Limitations\n\n- Types, members, calls and dependencies come from a C# declaration parser with name-based resolution (no compiler semantic model): ");
        cov.Append($"{Num("uncertainCalls")} calls matched several methods and {Num("lowConfidenceRelationships")} type relationships matched several types; those are marked uncertain.\n");
        cov.Append("- Cyclomatic complexity is estimated from tokens; test coverage is not measured.\n");
        if (analysis is { } an)
        {
            if (an.TryGetProperty("languagesWithoutTypeAnalysis", out var langs) && langs.GetArrayLength() > 0)
            {
                cov.Append($"- Languages without type-level analysis (file inventory and line counts only): {string.Join(", ", langs.EnumerateArray().Select(l => l.GetString()))}\n");
            }
            cov.Append($"- Generated files excluded: {Num("generatedFiles")}\n");
            if (an.TryGetProperty("exclusions", out var ex))
            {
                cov.Append("\n## Excluded paths\n\n").Append(string.Concat(ex.EnumerateArray().Take(80).Select(e => $"- `{e.GetString()}`\n")));
            }
        }
        File.WriteAllText(Path.Combine(outDir, "coverage.md"), cov.ToString(), new UTF8Encoding(true));

        File.WriteAllText(Path.Combine(outDir, "manifest.json"), JsonSerializer.Serialize(new
        {
            schemaVersion = "1.0",
            generator = "DocGen Architect",
            repository,
            generatedAt = DateTime.UtcNow,
            analysis = new
            {
                projects = Num("projectsDiscovered"),
                files = Num("sourceFilesAnalyzed"),
                types = Num("typesDiscovered"),
                methods = Num("methodsDiscovered"),
                apis = Num("apisDiscovered"),
                entities = Num("databaseEntities"),
                scenarios = scenarios.Count,
                diagrams = diagrams.Count,
            },
            exclusions = analysis is { } a2 && a2.TryGetProperty("exclusions", out var e2) ? e2.EnumerateArray().Select(x => x.GetString()).ToArray() : [],
            entryPoint = "00-index.md",
        }, ArchitectureWriter.Json) + "\n", new UTF8Encoding(false));
    }

    /// <summary>Partial bundles keep their own 00-index.md (written with the trace); only the manifest is rebuilt.</summary>
    private static void BuildPartialManifest(string outDir)
    {
        SyncStepDescriptions(outDir);
        var scope = ReadJson(outDir, "inventory/scope.json");
        var flow = ReadJson(outDir, "flows/program-flow.json");
        var diagrams = MarkdownFiles(outDir).Sum(p => MermaidBlock().Matches(File.ReadAllText(Path.Combine(outDir, p))).Count);
        int Count(JsonElement? e, string property) => e is { } x && x.TryGetProperty(property, out var v) && v.ValueKind == JsonValueKind.Array ? v.GetArrayLength() : 0;
        var steps = flow is { } f && f.TryGetProperty("steps", out var st) ? st.EnumerateArray().ToList() : [];
        File.WriteAllText(Path.Combine(outDir, "manifest.json"), JsonSerializer.Serialize(new
        {
            schemaVersion = "1.0",
            generator = "DocGen Architect",
            mode = "partial",
            repository = scope?.GetProperty("repository").GetString(),
            scope = scope is { } sc ? JsonSerializer.Deserialize<object>(sc.GetProperty("scope").GetRawText()) : null,
            generatedAt = DateTime.UtcNow,
            analysis = new
            {
                entryPoints = Count(flow, "entryPoints"),
                steps = steps.Count,
                projects = steps.Select(x => x.GetProperty("project").GetString()).Distinct().Count(),
                classes = steps.Select(x => x.GetProperty("class").GetString()).Distinct().Count(),
                methods = steps.Select(x => $"{x.GetProperty("class").GetString()}.{x.GetProperty("method").GetString()}").Distinct().Count(),
                projectTransitions = Count(flow, "projectTransitions"),
                ambiguities = Count(flow, "ambiguities"),
                diagrams,
            },
            entryPoint = "00-index.md",
        }, ArchitectureWriter.Json) + "\n", new UTF8Encoding(false));
    }

    /// <summary>
    /// Program-flow tables list a description per step. Steps without a /// summary show "—" until the skill writes the
    /// step's What in 02-program-flow.md; this copies the first sentence of that What into every table row of the step.
    /// </summary>
    private static void SyncStepDescriptions(string outDir)
    {
        var detailPath = Path.Combine(outDir, "02-program-flow.md");
        if (!File.Exists(detailPath))
        {
            return;
        }
        var whats = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (Match m in Regex.Matches(File.ReadAllText(detailPath), @"<a id=""step-(\d+)""></a>(?:(?!<a id=""step-).)*?\*\*What:\*\*(?>[ \t]*)([^\n<][^\n]*)", RegexOptions.Singleline))
        {
            var sentence = Regex.Match(m.Groups[2].Value.Trim(), @"^.*?[.!?](?=\s|$)").Value;
            var text = (sentence.Length > 0 ? sentence : m.Groups[2].Value.Trim()).Replace("|", "\\|");
            if (text.Length > 0 && !text.StartsWith("_To be written", StringComparison.Ordinal) && !text.Contains(ArchitectureWriter.Marker, StringComparison.Ordinal))
            {
                whats[m.Groups[1].Value] = text.Length > 220 ? text[..219] + "…" : text;
            }
        }
        if (whats.Count == 0)
        {
            return;
        }
        foreach (var file in new[] { "02-program-flow.md", "flows/program-flow.md" }.Select(f => Path.Combine(outDir, f)).Where(File.Exists))
        {
            var lines = File.ReadAllLines(file);
            var changed = false;
            for (var i = 0; i < lines.Length; i++)
            {
                var row = Regex.Match(lines[i], @"^\| \[(\d+)\]\([^)]*02-program-flow\.md#step-\1\) \|");
                if (!row.Success || !whats.TryGetValue(row.Groups[1].Value, out var what))
                {
                    continue;
                }
                var cells = Regex.Split(lines[i], @"(?<!\\)\|");
                var current = cells.Length > 6 ? cells[5].Trim() : "";
                // Replace a placeholder or a derived (italic) description; never a /// summary.
                if (cells.Length > 6 && (current == PartialWriter.NoDescription || current.Length > 2 && current.StartsWith('_') && current.EndsWith('_')))
                {
                    cells[5] = " " + what + " ";
                    lines[i] = string.Join("|", cells);
                    changed = true;
                }
            }
            if (changed)
            {
                File.WriteAllText(file, string.Join("\n", lines) + "\n", new UTF8Encoding(true));
            }
        }
    }

    /// <summary>
    /// The program-flow table, call graph and activity diagram must describe the same execution model: every traced
    /// method appears in the table and the call graph, and each activity diagram starts from its entry point.
    /// </summary>
    private static void CheckPartialConsistency(string outDir, List<string> errors, List<string> warnings)
    {
        var flow = ReadJson(outDir, "flows/program-flow.json");
        if (flow is not { } f || !f.TryGetProperty("steps", out var steps))
        {
            return;
        }
        var table = File.Exists(Path.Combine(outDir, "02-program-flow.md")) ? File.ReadAllText(Path.Combine(outDir, "02-program-flow.md")) : "";
        var graph = File.Exists(Path.Combine(outDir, "diagrams/call-graph.md")) ? File.ReadAllText(Path.Combine(outDir, "diagrams/call-graph.md")) : "";
        var activity = File.Exists(Path.Combine(outDir, "diagrams/activity.md")) ? File.ReadAllText(Path.Combine(outDir, "diagrams/activity.md")) : "";
        var missingInTable = new List<string>();
        var missingInGraph = new List<string>();
        foreach (var step in steps.EnumerateArray())
        {
            var cls = step.GetProperty("class").GetString() ?? "";
            var method = step.GetProperty("method").GetString() ?? "";
            if (!table.Contains(method, StringComparison.Ordinal) || !table.Contains(cls, StringComparison.Ordinal))
            {
                missingInTable.Add($"{cls}.{method}");
            }
            if (!graph.Contains(method, StringComparison.Ordinal) && !graph.Contains("… more steps", StringComparison.Ordinal))
            {
                missingInGraph.Add($"{cls}.{method}");
            }
        }
        if (missingInTable.Count > 0)
        {
            errors.Add($"02-program-flow.md no longer lists traced steps: {string.Join(", ", missingInTable.Distinct().Take(10))}. The table must match flows/program-flow.json.");
        }
        if (missingInGraph.Count > 0)
        {
            errors.Add($"diagrams/call-graph.md is missing traced methods: {string.Join(", ", missingInGraph.Distinct().Take(10))}.");
        }
        if (!activity.Contains(ArchitectureWriter.Marker, StringComparison.Ordinal))
        {
            foreach (var entry in f.GetProperty("entryPoints").EnumerateArray())
            {
                var method = entry.GetProperty("method").GetString() ?? "";
                var cls = entry.GetProperty("class").GetString() ?? "";
                if (method.Length > 0 && !activity.Contains(method, StringComparison.Ordinal) && !activity.Contains(cls, StringComparison.Ordinal))
                {
                    errors.Add($"diagrams/activity.md does not mention the entry point {cls}.{method}: the activity diagram must describe the traced flow.");
                }
            }
        }
        if (!activity.Contains("```mermaid", StringComparison.Ordinal) && !activity.Contains(ArchitectureWriter.Marker, StringComparison.Ordinal) && !activity.Contains("Diagram omitted", StringComparison.Ordinal))
        {
            errors.Add("diagrams/activity.md has no activity diagram.");
        }
        if (f.TryGetProperty("ambiguities", out var amb) && amb.GetArrayLength() > 0)
        {
            warnings.Add($"{amb.GetArrayLength()} calls have several possible targets and were not followed; mention them in the report.");
        }
    }

    // ---------- Validation ----------

    public static async Task<BundleCheck> ValidateAsync(string outDir, string? browser, string? mermaidScript, CancellationToken ct)
    {
        var errors = new List<string>();
        var warnings = new List<string>();
        var partial = IsPartial(outDir);
        foreach (var file in (partial ? PartialRequired : Required).Where(f => !File.Exists(Path.Combine(outDir, f))))
        {
            errors.Add($"Missing required file {file}.");
        }
        if (partial)
        {
            CheckPartialConsistency(outDir, errors, warnings);
        }
        var all = Directory.EnumerateFiles(outDir, "*", SearchOption.AllDirectories).Select(f => Path.GetRelativePath(outDir, f).Replace('\\', '/')).ToList();
        var json = 0;
        foreach (var file in all.Where(f => f.EndsWith(".json", StringComparison.OrdinalIgnoreCase)))
        {
            json++;
            try
            {
                using var _ = JsonDocument.Parse(File.ReadAllText(Path.Combine(outDir, file)));
            }
            catch (JsonException ex)
            {
                errors.Add($"{file}: invalid JSON ({ex.Message}).");
            }
        }

        var markdown = all.Where(f => f.EndsWith(".md", StringComparison.OrdinalIgnoreCase)).ToList();
        var diagrams = new List<(string File, int Number, string Text)>();
        var unfinished = new List<string>();
        foreach (var file in markdown)
        {
            var text = File.ReadAllText(Path.Combine(outDir, file));
            var markers = Regex.Matches(text, Regex.Escape(ArchitectureWriter.Marker)).Count;
            if (markers > 0)
            {
                unfinished.Add($"{file} ({markers})");
            }
            if (text.Contains("_To be written from source evidence._", StringComparison.Ordinal) && markers == 0)
            {
                errors.Add($"{file}: a placeholder line is left without its marker.");
            }
            var dir = Path.GetDirectoryName(file)?.Replace('\\', '/') ?? "";
            foreach (Match m in LinkPattern().Matches(text))
            {
                var target = m.Groups[1].Value.Split('#')[0];
                if (target.Length == 0 || target.Contains("://", StringComparison.Ordinal) || target.StartsWith("mailto:", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }
                var resolved = Path.GetFullPath(Path.Combine(outDir, dir, WebUtility.UrlDecode(target)));
                if (!resolved.StartsWith(Path.GetFullPath(outDir), StringComparison.OrdinalIgnoreCase))
                {
                    errors.Add($"{file}: link \"{target}\" leaves the bundle.");
                }
                else if (!File.Exists(resolved) && !Directory.Exists(resolved))
                {
                    errors.Add($"{file}: broken link \"{target}\".");
                }
            }
            var number = 0;
            foreach (Match m in MermaidBlock().Matches(text))
            {
                diagrams.Add((file, ++number, m.Groups[1].Value));
            }
            if (Regex.Matches(text, "^```", RegexOptions.Multiline).Count % 2 != 0)
            {
                errors.Add($"{file}: a code fence is not closed.");
            }
            foreach (var secret in Secrets(text))
            {
                errors.Add($"{file}: looks like a secret ({secret}); replace it with [REDACTED].");
            }
        }
        foreach (var file in all.Where(f => f.EndsWith(".json", StringComparison.OrdinalIgnoreCase)))
        {
            foreach (var secret in Secrets(File.ReadAllText(Path.Combine(outDir, file))))
            {
                errors.Add($"{file}: looks like a secret ({secret}); replace it with [REDACTED].");
            }
        }
        if (unfinished.Count > 0)
        {
            errors.Add($"{unfinished.Count} pages still have unwritten sections ({ArchitectureWriter.Marker} … -->): {string.Join(", ", unfinished.Take(25))}{(unfinished.Count > 25 ? " …" : "")}. " +
                       "Write each from source evidence, or replace it with 'Not determined from static repository analysis.' / 'Diagram omitted: insufficient repository evidence.' when there is none. " +
                       "Out of time for the key class/method pages? Rerun action=model with smaller max_narrative_types / max_narrative_methods: written pages are kept, the rest become computed-facts pages.");
        }

        var validated = 0;
        foreach (var (file, number, text) in diagrams.Where(d => d.Text.Trim().Length == 0))
        {
            errors.Add($"{file}: diagram {number} is empty.");
        }
        if (browser is null || mermaidScript is null)
        {
            warnings.Add($"Mermaid syntax was not checked ({(browser is null ? "no Edge or Chrome found" : "the Mermaid library was not found")}).");
        }
        else if (diagrams.Count > 0)
        {
            var results = await ParseMermaidAsync(browser, mermaidScript, diagrams.Select(d => d.Text).ToList(), ct);
            if (results is null)
            {
                warnings.Add("Mermaid syntax could not be checked (the browser did not finish in time).");
            }
            else
            {
                for (var i = 0; i < diagrams.Count; i++)
                {
                    if (results[i] is { } error)
                    {
                        errors.Add($"{diagrams[i].File}: diagram {diagrams[i].Number} is not valid Mermaid — {error}");
                    }
                    else
                    {
                        validated++;
                    }
                }
            }
        }
        var types = diagrams.GroupBy(d => d.Text.Trim().Split(' ', '\n')[0]).ToDictionary(g => g.Key, g => g.Count());
        return new BundleCheck(errors, warnings, markdown.Count, json, diagrams.Count, validated, types);
    }

    /// <summary>Runs mermaid.parse on each diagram in a private headless browser; null overall when the browser could not be used.</summary>
    private static async Task<List<string?>?> ParseMermaidAsync(string browser, string mermaidScript, List<string> diagrams, CancellationToken ct)
    {
        await using var mermaid = await MermaidBrowser.StartAsync(browser, mermaidScript, ct);
        if (mermaid is null)
        {
            return null;
        }
        try
        {
            return await mermaid.ParseAsync(diagrams, ct);
        }
        catch (Exception ex) when (ex is IOException or System.Net.WebSockets.WebSocketException or InvalidOperationException or JsonException or DocGen.Core.Exceptions.DocGenException)
        {
            return null;
        }
    }

    /// <summary>The Mermaid library DocGen serves (published wwwroot, the content root, or the source tree when developing).</summary>
    public static string? FindMermaidScript()
    {
        foreach (var start in new[] { AppContext.BaseDirectory, Directory.GetCurrentDirectory() })
        {
            for (var dir = new DirectoryInfo(start); dir is not null; dir = dir.Parent)
            {
                foreach (var candidate in new[] { Path.Combine(dir.FullName, "wwwroot", "lib", "mermaid", "mermaid.min.js"), Path.Combine(dir.FullName, "src", "DocGen.Web", "wwwroot", "lib", "mermaid", "mermaid.min.js") })
                {
                    if (File.Exists(candidate))
                    {
                        return candidate;
                    }
                }
            }
        }
        return null;
    }

    // ---------- Packaging ----------

    /// <summary>Zips the bundle with architecture/ at the root; returns the entry count after reopening the archive.</summary>
    public static int Package(string outDir, string zipPath)
    {
        var temp = zipPath + ".tmp";
        using (var zip = ZipFile.Open(temp, ZipArchiveMode.Create))
        {
            foreach (var file in Directory.EnumerateFiles(outDir, "*", SearchOption.AllDirectories).Order(StringComparer.Ordinal))
            {
                zip.CreateEntryFromFile(file, "architecture/" + Path.GetRelativePath(outDir, file).Replace('\\', '/'), CompressionLevel.Optimal);
            }
        }
        using (var check = ZipFile.OpenRead(temp))
        {
            if (check.GetEntry("architecture/00-index.md") is null)
            {
                throw new InvalidOperationException("The archive has no architecture/00-index.md.");
            }
        }
        File.Move(temp, zipPath, overwrite: true);
        using var verify = ZipFile.OpenRead(zipPath);
        return verify.Entries.Count;
    }

    // ---------- Helpers ----------

    private static List<string> MarkdownFiles(string outDir)
        => Directory.EnumerateFiles(outDir, "*.md", SearchOption.AllDirectories).Select(f => Path.GetRelativePath(outDir, f).Replace('\\', '/')).Order(StringComparer.Ordinal).ToList();

    private static JsonElement? ReadJson(string outDir, string relative)
    {
        var path = Path.Combine(outDir, relative);
        if (!File.Exists(path))
        {
            return null;
        }
        try
        {
            using var doc = JsonDocument.Parse(File.ReadAllText(path));
            return doc.RootElement.Clone();
        }
        catch (JsonException)
        {
            return null;
        }
    }

    private static string? Title(string text) => Regex.Match(text, @"^#\s+(.+)$", RegexOptions.Multiline) is { Success: true } m ? m.Groups[1].Value.Trim() : null;

    /// <summary>The text of a "## Name" section, without markers.</summary>
    private static string Section(string text, string heading)
    {
        var m = Regex.Match(text, $@"^##\s+{Regex.Escape(heading)}\s*$\n(.*?)(?=^##\s|\z)", RegexOptions.Multiline | RegexOptions.Singleline);
        if (!m.Success)
        {
            return "";
        }
        var body = Regex.Replace(m.Groups[1].Value, @"<!--.*?-->", "", RegexOptions.Singleline).Replace("_To be written from source evidence._", "").Trim();
        return body;
    }

    private static string FirstSentence(string text)
    {
        var flat = Regex.Replace(text, @"\s+", " ").Trim();
        var end = flat.IndexOf(". ", StringComparison.Ordinal);
        var sentence = end > 0 ? flat[..(end + 1)] : flat;
        return sentence.Length > 180 ? sentence[..177] + "…" : sentence;
    }

    private static string Cell(string text) => text.Replace("|", "\\|").Replace("\n", " ");

    private static IEnumerable<string> Secrets(string text)
    {
        foreach (Match m in SecretPattern().Matches(text))
        {
            var value = m.Value;
            if (value.Contains("[REDACTED]", StringComparison.Ordinal) || value.Contains("{", StringComparison.Ordinal) || value.Contains("<", StringComparison.Ordinal))
            {
                continue;
            }
            yield return value.Length > 24 ? value[..24] + "…" : value;
        }
    }

    [GeneratedRegex(@"^```mermaid[ \t]*\r?\n(.*?)^```", RegexOptions.Multiline | RegexOptions.Singleline)]
    private static partial Regex MermaidBlock();

    [GeneratedRegex(@"\]\(([^)\s]+)\)")]
    private static partial Regex LinkPattern();

    [GeneratedRegex(@"(-----BEGIN [A-Z ]*PRIVATE KEY-----|\bAKIA[0-9A-Z]{16}\b|\bsk-[A-Za-z0-9_-]{20,}|\bgh[pousr]_[A-Za-z0-9]{30,}|AccountKey=[A-Za-z0-9+/=]{20,}|(?i:\b(?:password|pwd)\s*=\s*[^;\s""'`]{4,}))")]
    private static partial Regex SecretPattern();
}
