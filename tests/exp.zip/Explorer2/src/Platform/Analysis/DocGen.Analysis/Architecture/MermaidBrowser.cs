using System.Diagnostics;
using System.Text.Json;
using DocGen.Analysis.Browser;

namespace DocGen.Analysis.Architecture;

/// <summary>
/// A private headless Edge/Chrome with the Mermaid library loaded, driven over the DevTools protocol (the Windows
/// launcher exits at once, so its console output cannot be read). Parses diagrams (validation) and renders them to
/// PNG for chat. Disposing kills the browser and deletes its profile.
/// </summary>
public sealed class MermaidBrowser : IAsyncDisposable
{
    private readonly string _dir;
    private readonly Process _process;
    private readonly CdpClient _cdp;
    private readonly string _session;

    private MermaidBrowser(string dir, Process process, CdpClient cdp, string session)
    {
        _dir = dir;
        _process = process;
        _cdp = cdp;
        _session = session;
    }

    /// <summary>Starts the browser with Mermaid loaded; null when it cannot be used (no DevTools endpoint, library not loading).</summary>
    public static async Task<MermaidBrowser?> StartAsync(string browser, string mermaidScript, CancellationToken ct)
    {
        var dir = Path.Combine(Path.GetTempPath(), "docgen-mermaid-" + Guid.NewGuid().ToString("N")[..10]);
        var profile = Path.Combine(dir, "profile");
        Directory.CreateDirectory(profile);
        Process? process = null;
        CdpClient? cdp = null;
        try
        {
            var page = Path.Combine(dir, "render.html");
            await File.WriteAllTextAsync(page, "<!doctype html><html><head><meta charset=\"utf-8\"><style>html,body{margin:0;background:#fff}#host{display:inline-block;padding:16px;background:#fff}</style>" +
                                               $"<script src=\"{new Uri(mermaidScript).AbsoluteUri}\"></script></head><body><div id=\"host\"></div></body></html>", ct);
            var start = new ProcessStartInfo(browser) { UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true };
            foreach (var a in new[] { "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check", "--disable-extensions", "--remote-debugging-port=0",
                         "--remote-debugging-address=127.0.0.1", "--user-data-dir=" + profile, "--allow-file-access-from-files", "--host-resolver-rules=MAP * ~NOTFOUND", "about:blank" })
            {
                start.ArgumentList.Add(a);
            }
            process = Process.Start(start)!;
            _ = process.StandardOutput.ReadToEndAsync(ct);
            _ = process.StandardError.ReadToEndAsync(ct);

            // The DevTools endpoint is written to the profile once the browser listens.
            string? ws = null;
            var portFile = Path.Combine(profile, "DevToolsActivePort");
            for (var waited = Stopwatch.StartNew(); ws is null && waited.Elapsed < TimeSpan.FromSeconds(30);)
            {
                if (File.Exists(portFile))
                {
                    try
                    {
                        var lines = await File.ReadAllLinesAsync(portFile, ct);
                        if (lines.Length >= 2 && int.TryParse(lines[0], out var port))
                        {
                            ws = $"ws://127.0.0.1:{port}{lines[1]}";
                            break;
                        }
                    }
                    catch (IOException)
                    {
                    }
                }
                await Task.Delay(100, ct);
            }
            if (ws is null)
            {
                throw new IOException("The browser did not open a DevTools endpoint.");
            }
            cdp = new CdpClient();
            await cdp.ConnectAsync(new Uri(ws), ct);
            var target = await cdp.SendAsync("Target.createTarget", new { url = new Uri(page).AbsoluteUri }, ct: ct);
            var attached = await cdp.SendAsync("Target.attachToTarget", new { targetId = target.GetProperty("targetId").GetString(), flatten = true }, ct: ct);
            var session = attached.GetProperty("sessionId").GetString()!;
            for (var waited = Stopwatch.StartNew(); ; await Task.Delay(150, ct))
            {
                var ready = await cdp.SendAsync("Runtime.evaluate", new { expression = "typeof mermaid !== 'undefined'", returnByValue = true }, session, ct);
                if (ready.GetProperty("result").TryGetProperty("value", out var v) && v.ValueKind == JsonValueKind.True)
                {
                    break;
                }
                if (waited.Elapsed > TimeSpan.FromSeconds(30))
                {
                    throw new IOException("Mermaid did not load.");
                }
            }
            await cdp.SendAsync("Runtime.evaluate", new { expression = "mermaid.initialize({startOnLoad:false,securityLevel:'strict',theme:'default',flowchart:{useMaxWidth:false},maxEdges:2000,maxTextSize:500000});" }, session, ct);
            return new MermaidBrowser(dir, process, cdp, session);
        }
        catch (Exception ex) when (ex is IOException or System.Net.WebSockets.WebSocketException or InvalidOperationException or JsonException or DocGen.Core.Exceptions.DocGenException or System.ComponentModel.Win32Exception)
        {
            if (cdp is not null) await cdp.DisposeAsync();
            await Stop(process, dir);
            return null;
        }
    }

    /// <summary>mermaid.parse per diagram: null when valid, else the parser's error.</summary>
    public async Task<List<string?>?> ParseAsync(IReadOnlyList<string> diagrams, CancellationToken ct)
    {
        var expression = "(async()=>{const ds=" + JsonSerializer.Serialize(diagrams) + ";const r=[];" +
                         "for(const d of ds){try{await mermaid.parse(d);r.push(null);}catch(e){r.push(String((e&&(e.message||e.str))||e).replace(/\\s+/g,' ').slice(0,240));}}" +
                         "return JSON.stringify(r);})()";
        var evaluated = await _cdp.SendAsync("Runtime.evaluate", new { expression, awaitPromise = true, returnByValue = true }, _session, ct, timeoutSeconds: 120);
        return evaluated.GetProperty("result").TryGetProperty("value", out var value) && value.ValueKind == JsonValueKind.String
            ? JsonSerializer.Deserialize<List<string?>>(value.GetString()!)
            : null;
    }

    /// <summary>
    /// Renders a diagram to PNG (white background, 16 px margin) at up to <paramref name="scale"/>× for sharp text; the
    /// scale drops for very large diagrams so the image stays within about 16,000 px. Throws with Mermaid's message
    /// when the diagram does not render.
    /// </summary>
    public async Task<(byte[] Png, int Width, int Height)> RenderPngAsync(string diagram, double scale, CancellationToken ct)
    {
        var expression = "(async()=>{const host=document.getElementById('host');host.innerHTML='';try{const {svg}=await mermaid.render('m'+Date.now(), " + JsonSerializer.Serialize(diagram) + ");" +
                         "host.innerHTML=svg;const r=host.getBoundingClientRect();return JSON.stringify({w:Math.ceil(r.width),h:Math.ceil(r.height)});}" +
                         "catch(e){return JSON.stringify({error:String((e&&(e.message||e.str))||e).slice(0,300)});}})()";
        var evaluated = await _cdp.SendAsync("Runtime.evaluate", new { expression, awaitPromise = true, returnByValue = true }, _session, ct, timeoutSeconds: 120);
        using var size = JsonDocument.Parse(evaluated.GetProperty("result").GetProperty("value").GetString()!);
        if (size.RootElement.TryGetProperty("error", out var error))
        {
            throw new InvalidOperationException("Mermaid could not render the diagram: " + error.GetString());
        }
        var width = Math.Max(1, size.RootElement.GetProperty("w").GetInt32());
        var height = Math.Max(1, size.RootElement.GetProperty("h").GetInt32());
        var factor = Math.Min(scale, 16000.0 / Math.Max(width, height));
        await _cdp.SendAsync("Emulation.setDeviceMetricsOverride", new { width, height, deviceScaleFactor = factor, mobile = false }, _session, ct);
        var shot = await _cdp.SendAsync("Page.captureScreenshot", new { format = "png", captureBeyondViewport = true, clip = new { x = 0, y = 0, width, height, scale = 1 } }, _session, ct, timeoutSeconds: 120);
        return (Convert.FromBase64String(shot.GetProperty("data").GetString()!), (int)Math.Round(width * factor), (int)Math.Round(height * factor));
    }

    public async ValueTask DisposeAsync()
    {
        await _cdp.DisposeAsync();
        await Stop(_process, _dir);
    }

    private static async Task Stop(Process? process, string dir)
    {
        try
        {
            if (process is { HasExited: false })
            {
                process.Kill(entireProcessTree: true);
                await process.WaitForExitAsync(CancellationToken.None).WaitAsync(TimeSpan.FromSeconds(10), CancellationToken.None);
            }
        }
        catch (Exception ex) when (ex is InvalidOperationException or TimeoutException or System.ComponentModel.Win32Exception)
        {
        }
        process?.Dispose();
        try { Directory.Delete(dir, recursive: true); } catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { }
    }
}
