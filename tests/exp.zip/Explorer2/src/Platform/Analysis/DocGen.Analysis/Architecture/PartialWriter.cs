using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using DocGen.Analysis.Indexing;
using static DocGen.Analysis.Architecture.ArchitectureWriter;

namespace DocGen.Analysis.Architecture;

/// <summary>
/// Partial Architecture Mode: documents one requested scope (a folder, project, class, method or feature) from its traced
/// execution model. The program-flow table, call chain, call graph, cross-project flow and sequence diagrams are all
/// rendered from the same <see cref="FlowTrace"/>, so they cannot disagree; the skill writes the narrative (What / Why /
/// How, activity diagrams, transformations) where markers ask for it.
/// </summary>
public static class PartialWriter
{
    public sealed record Result(int Files, int Diagrams, int ClassPages, int MethodPages, int NarrativeSteps, int KeptPages);

    private const int MaxGraphNodes = 60;

    public static Result Write(FlowTrace trace, ArchitectureModel model, string outDir, int maxNarrativeSteps = 16, int maxNarrativeClasses = 10, int maxMethodPages = 40)
    {
        Directory.CreateDirectory(outDir);
        int files = 0, diagrams = 0, kept = 0;
        void Put(string relative, string content)
        {
            var path = Path.Combine(outDir, relative.Replace('/', Path.DirectorySeparatorChar));
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            // Pages the skill finished (no markers left, not a facts-only page) survive a re-trace.
            if ((content.Contains(Marker, StringComparison.Ordinal) || content.Contains(FactsOnly, StringComparison.Ordinal)) && File.Exists(path) &&
                File.ReadAllText(path) is var existing && !existing.Contains(Marker, StringComparison.Ordinal) && !existing.Contains(FactsOnly, StringComparison.Ordinal))
            {
                kept++;
                return;
            }
            File.WriteAllText(path, content.Replace("\r\n", "\n"), EncodingFor(relative));
            files++;
            diagrams += Regex.Matches(content, "^```mermaid", RegexOptions.Multiline).Count;
        }
        void PutJson(string relative, object value) => Put(relative, JsonSerializer.Serialize(value, ArchitectureWriter.Json) + "\n");

        var scope = trace.Scope;
        var typesByFull = model.Types.GroupBy(t => t.Symbol.FullName, StringComparer.Ordinal).ToDictionary(g => g.Key, g => g.First(), StringComparer.Ordinal);
        var methodsByKey = model.Methods.GroupBy(m => Key(m.Symbol)).ToDictionary(g => g.Key, g => g.First());
        TypeNode? TypeOf(FlowStep s) => s.Symbol.Container is { } c && typesByFull.TryGetValue(c, out var t) ? t : null;
        MethodNode? MethodOf(FlowStep s) => methodsByKey.GetValueOrDefault(Key(s.Symbol));

        // Involved types: those with steps, in trace order; primary first when budgets apply.
        var involved = trace.Steps.Select(TypeOf).Where(t => t is not null).Select(t => t!).Distinct().ToList();
        var stepsByType = trace.Steps.Where(s => TypeOf(s) is not null).GroupBy(s => TypeOf(s)!).ToDictionary(g => g.Key, g => g.ToList());
        var keyClasses = involved.OrderByDescending(t => stepsByType[t].Any(s => s.Primary)).ThenByDescending(t => stepsByType[t].Count).ThenBy(t => stepsByType[t][0].Number)
            .Take(maxNarrativeClasses).ToHashSet();
        // Class and method pages mirror the source tree: classes/<folder of the .cs file>/<Type>.md.
        var classPage = involved.ToDictionary(t => t, t => $"classes/{SourceFolder(t.Symbol.File)}{Safe(TypeFile(t))}.md");

        // Narrative steps: entry roots first, then primary, then business steps, in trace order.
        var keySteps = trace.Steps.OrderByDescending(s => s.Parent is null).ThenByDescending(s => s.Primary).ThenByDescending(s => s.Role is not "Internal helper")
            .ThenBy(s => s.Number).Take(maxNarrativeSteps).ToHashSet();
        var methodSteps = trace.Steps.Where(s => s.Symbol.Kind is SymbolKinds.Method or SymbolKinds.TopLevel && s.Symbol.Kind != SymbolKinds.TopLevel
                                                 && (MethodOf(s)?.Metrics.CyclomaticComplexity >= 3 || s.Edges.Count >= 2 || s.Parent is null))
            .GroupBy(s => s.Symbol, ReferenceEqualityComparer.Instance).Select(g => g.First()).Take(maxMethodPages).ToList();
        var methodPage = methodSteps.ToDictionary(s => s.Symbol, s => $"methods/{SourceFolder(s.Symbol.File)}{Safe(s.TypeName)}/{Safe(s.MethodName)}{(Overloaded(s.Symbol, model) ? "-" + Hash(s.Symbol) : "")}.md", (IEqualityComparer<SymbolRecord>)ReferenceEqualityComparer.Instance);
        string StepLink(FlowStep s, string up) => $"[{s.Number}]({up}02-program-flow.md#step-{s.Number})";
        string ClassLink(FlowStep s, string up) => TypeOf(s) is { } t ? $"[`{Cell(s.TypeName)}`]({up}{classPage[t]})" : $"`{Cell(s.TypeName)}`";
        string MethodLink(FlowStep s, string up) => methodPage.TryGetValue(s.Symbol, out var p) ? $"[`{Cell(s.MethodName)}`]({up}{p})" : $"`{Cell(s.MethodName)}`";

        var boundaries = trace.BoundaryEdges.ToList();
        var dataObjects = DataObjects(trace, model);
        var entities = EntitiesTouched(trace, model, dataObjects);
        var endpoints = trace.Entries.Where(e => e.Kind == "endpoint").ToList();
        var hasDatabase = boundaries.Any(b => b.Edge.Boundary!.Kind == "database") || entities.Count > 0;
        var hasIntegrations = endpoints.Count > 0 || boundaries.Any(b => b.Edge.Boundary!.Kind is "http" or "message" or "file" or "process" or "external");
        var title = ScopeTitle(scope);

        // ---------- flows/ ----------
        var flowTable = new StringBuilder($"# Program Flow — {title}\n\n[Architecture Index](../00-index.md) · [Detailed program flow](../02-program-flow.md) · [Call chain](call-chain.md)\n\n");
        flowTable.Append("Every step the trace reached, in call order (depth-first from each entry point). Role is inferred from names. `→ n` is the step it calls; `↺ n` a step traced earlier.\n\n");
        foreach (var entry in trace.Entries)
        {
            flowTable.Append($"## {Cell(entry.Description)} — `{Cell(entry.Root.Display)}`\n\n").Append(FlowTable(trace, entry, "../", includeSource: true, ClassLink, MethodLink)).Append('\n');
        }
        Put("flows/program-flow.md", flowTable.ToString());
        PutJson("flows/program-flow.json", FlowJson(trace));
        Put("flows/call-chain.md", $"# Call Chain — {title}\n\n[Architecture Index](../00-index.md) · [Program flow](program-flow.md)\n\n" + string.Concat(trace.Entries.Select(e =>
            $"## {Cell(e.Description)}\n\n### Primary path\n\n```text\n{LinearChain(PrimaryPath(e.Root))}```\n\n### Full call tree\n\n```text\n{Tree(e.Root)}```\n\n")));

        // ---------- diagrams/ ----------
        var d = "# {0}\n\n[Architecture Index](../00-index.md)\n\n";
        Put("diagrams/call-graph.md", string.Format(d, "Call Graph — " + title) + "Calls between the traced methods (solid), asynchronous hand-offs (dashed) and boundaries (databases, APIs, messages). Uncertain calls end in a `?` node.\n\n" +
            string.Concat(trace.Entries.Select(e => $"## {Cell(e.Description)}\n\n```mermaid\n{CallGraph(Subtree(e.Root))}```\n\n")));
        Put("diagrams/cross-project-flow.md", string.Format(d, "Cross-Project Flow — " + title) + $"Execution grouped by project: {trace.Projects.Count()} projects take part. Transitions are listed in [project boundaries](../03-project-boundaries.md).\n\n```mermaid\n{CrossProject(trace)}```\n");
        Put("diagrams/sequence.md", string.Format(d, "Sequence — " + title) +
            "End-to-end sequence per entry point, from the traced calls in source order. Branches are not distinguished here (see the [activity diagram](activity.md)); `-)` marks an asynchronous message.\n\n" +
            string.Concat(trace.Entries.Select(e => $"## {Cell(e.Description)}\n\n```mermaid\n{Sequence(e.Root)}```\n\n")));
        Put("diagrams/activity.md", string.Format(d, "Activity — " + title) + string.Concat(trace.Entries.Select(e =>
            $"## {Cell(e.Description)} — `{Cell(e.Root.Display)}`\n\n" + ArchitectureWriter.Write(ActivityBrief(e.Root)) + "\n")));
        Put("diagrams/class-diagram.md", string.Format(d, "Class Diagram — " + title) + $"The {Math.Min(involved.Count, 25)} classes that take part in the flow and the relationships between them.\n\n```mermaid\n{ClassDiagram(involved.Take(25).ToList(), model, stepsByType)}```\n");
        Put("diagrams/type-dependencies.md", string.Format(d, "Type Dependencies — " + title) + $"How the participating types depend on each other (with the evidence kind on each edge).\n\n```mermaid\n{TypeDependencies(involved.Take(40).ToList(), model)}```\n");
        Put("diagrams/data-flow.md", string.Format(d, "Data Flow — " + title) + (dataObjects.Count == 0
            ? "No repository-defined data types are passed between the traced steps.\n"
            : $"Repository data types created, passed and returned along the flow.\n\n```mermaid\n{DataFlowDiagram(dataObjects)}```\n"));
        if (entities.Count > 0)
        {
            Put("diagrams/er-diagram.md", string.Format(d, "Entities — " + title) + $"The persisted entities this flow touches and the entities directly related to them.\n\n```mermaid\n{ErDiagram(entities, model)}```\n");
        }

        // ---------- classes/ and methods/ ----------
        foreach (var t in involved)
        {
            var steps = stepsByType[t];
            var s = t.Symbol;
            var up = Up(classPage[t]);
            var sb = new StringBuilder($"# {s.Name}\n\n[Architecture Index]({up}00-index.md) · [Classes]({up}05-classes.md)\n\n");
            sb.Append($"## Overview\n\n`{s.FullName}` — {s.Kind} in project **{s.Project}**, {(steps.Any(x => x.Primary) ? "in the requested scope" : "supporting code (reached by the trace)")}.\n\n");
            if (keyClasses.Contains(t))
            {
                sb.Append("## What\n\n").Append(ArchitectureWriter.Write($"what {s.Name} is")).Append("\n## Why\n\n").Append(ArchitectureWriter.Write($"why {s.Name} is part of this flow"))
                  .Append("\n## How\n\n").Append(ArchitectureWriter.Write($"how {s.Name} takes part in the execution, from its code")).Append('\n');
            }
            sb.Append($"## Source\n\n`{s.File}` lines {s.StartLine}–{s.EndLine}\n\n## In this flow\n\n| Step | Method | Role | Called from |\n|---:|---|---|---|\n");
            foreach (var st in steps)
            {
                sb.Append($"| {StepLink(st, up)} | {MethodLink(st, up)} | {Cell(st.Role)} | {(st.Parent is { } p ? $"`{Cell(p.Display)}` (line {st.CalledFromLine})" : "entry point")} |\n");
            }
            var rel = model.Relationships.Where(r => r.Source == t.Id && involved.Any(o => o.Id == r.Target)).ToList();
            var usedBy = model.Relationships.Where(r => r.Target == t.Id && involved.Any(o => o.Id == r.Source)).Select(r => r.Source).Distinct().ToList();
            sb.Append($"\n## Relationships (within this flow)\n\n- Bases/interfaces: {(s.Bases.Count == 0 ? "none" : string.Join(", ", s.Bases.Select(b => $"`{Cell(b)}`")))}\n");
            sb.Append($"- Depends on: {(rel.Count == 0 ? "no other participating type" : string.Join(", ", rel.Select(r => $"`{Cell(r.Target[5..][(r.Target[5..].LastIndexOf('.') + 1)..])}` ({r.Kind}, {r.Evidence.Replace('_', ' ')})")))}\n");
            sb.Append($"- Used by: {(usedBy.Count == 0 ? "no other participating type" : string.Join(", ", usedBy.Select(u => $"`{Cell(u[(u.LastIndexOf('.') + 1)..])}`")))}\n\n");
            var mt = t.Metrics;
            sb.Append($"## Metrics\n\n| Metric | Value |\n|---|---|\n| Lines (declaration) | {mt.LinesOfCode} |\n| Methods / properties / fields | {mt.MethodCount} / {mt.PropertyCount} / {mt.FieldCount} |\n| Dependencies | {mt.DependencyCount} |\n| Fan-in / fan-out | {mt.FanIn} / {mt.FanOut} |\n| Cyclomatic complexity (total / avg / max) | {mt.CyclomaticComplexity} / {mt.AverageMethodComplexity} / {mt.MaximumMethodComplexity} |\n");
            if (!keyClasses.Contains(t))
            {
                sb.Append('\n').Append(FactsOnly).Append($"classes of this flow (see [Classes]({up}05-classes.md))._\n");
            }
            Put(classPage[t], sb.ToString());
        }
        foreach (var st in methodSteps)
        {
            var s = st.Symbol;
            var m = MethodOf(st);
            var page = methodPage[s];
            var up = Up(page);
            var sb = new StringBuilder($"# {st.Display}\n\n[Architecture Index]({up}00-index.md) · [Program flow step {st.Number}]({up}02-program-flow.md#step-{st.Number}) · {ClassLink(st, up)}\n\n");
            sb.Append($"## Signature\n\n```csharp\n{s.Signature}\n```\n\n");
            sb.Append($"- Parameters: {(s.ParameterTypes.Count == 0 ? "none" : string.Join(", ", s.ParameterTypes.Select(p => $"`{Cell(p)}`")))}\n- Returns: `{Cell(s.ReturnType ?? "void")}`\n- Role in the flow: {st.Role}\n- Source: `{s.File}` lines {s.StartLine}–{s.EndLine}\n\n");
            sb.Append("## Calls (in source order)\n\n").Append(EdgeList(st, up, MethodLink)).Append('\n');
            if (st.Flow is { } f)
            {
                if (f.Conditions.Count > 0)
                {
                    sb.Append("## Conditions\n\n| Line | Condition |\n|---:|---|\n").Append(string.Concat(f.Conditions.Take(25).Select(c => $"| {c.Line} | `{Cell(Short(c.Condition.Text, 110))}` |\n"))).Append('\n');
                }
                if (f.Throws.Count > 0 || f.Catches.Count > 0)
                {
                    sb.Append("## Errors\n\n");
                    foreach (var th in f.Throws.Take(12)) sb.Append($"- line {th.Line}: throws `{Cell(th.Type)}`\n");
                    foreach (var ca in f.Catches.Take(12)) sb.Append($"- line {ca.Line}: catches `{Cell(ca.ExceptionType ?? "any exception")}`{(ca.Rethrows ? " and rethrows" : "")}{(ca.WrapType is { } w ? $", wraps in `{Cell(w)}`" : "")}\n");
                    sb.Append('\n');
                }
            }
            var collaborators = st.Edges.Select(e => e.Target?.TypeName ?? e.Boundary?.Kind).Where(x => x is not null && x != st.TypeName).Distinct().Count();
            if (collaborators >= 2)
            {
                sb.Append($"## Sequence Diagram\n\n```mermaid\n{Sequence(st, maxDepth: 1)}```\n\n");
            }
            if (m is { } mn)
            {
                sb.Append($"## Metrics\n\n| Metric | Value |\n|---|---|\n| Source lines | {mn.Metrics.LinesOfCode} |\n| Parameters | {mn.Metrics.ParameterCount} |\n| Branches | {mn.Metrics.BranchCount} |\n| Cyclomatic complexity (estimated) | {mn.Metrics.CyclomaticComplexity} |\n| Distinct calls | {mn.Metrics.DependencyCalls} |\n\n");
                if (mn.Metrics.CyclomaticComplexity >= 4 && keySteps.Contains(st))
                {
                    sb.Append("## Flowchart\n\n").Append(ArchitectureWriter.Write($"a flowchart of {st.Display}'s control flow from its code (conditions above, complexity {mn.Metrics.CyclomaticComplexity})"));
                }
            }
            Put(page, sb.ToString());
        }

        // ---------- numbered pages ----------
        var overview = new StringBuilder($"# Feature / Component Overview — {title}\n\n[Architecture Index](00-index.md)\n\n");
        overview.Append("## What\n\n").Append(ArchitectureWriter.Write($"what {scope.Label} does, in one paragraph (it becomes the index summary)"))
            .Append("\n## Why\n\n").Append(ArchitectureWriter.Write("why it exists: the business or technical need it serves, from the code"))
            .Append("\n## How\n\n").Append(ArchitectureWriter.Write("how it works at a high level: the main path through the steps in 02-program-flow.md")).Append('\n');
        overview.Append("## Entry Point\n\n").Append(EntryList(trace, "", ClassLink, MethodLink)).Append('\n');
        overview.Append("## End Point\n\n").Append(EndPoints(trace)).Append('\n');
        overview.Append($"## Projects Involved\n\n{string.Concat(trace.Projects.Select(p => $"- **{p}** — {trace.Steps.Count(s => s.Project == p)} steps\n"))}\n");
        overview.Append($"## Important Classes\n\nSee [Classes](05-classes.md) for all {involved.Count}.\n\n{string.Concat(keyClasses.Select(t => $"- [`{Cell(t.Symbol.Name)}`]({classPage[t]}) — {stepsByType[t][0].Role}\n"))}\n");
        overview.Append("## External Dependencies\n\n").Append(boundaries.Count == 0 ? "None reached by the trace (no database, HTTP, message, file or process calls).\n" :
            string.Concat(boundaries.GroupBy(b => (b.Edge.Boundary!.Kind, b.Edge.Boundary.Name)).Select(g => $"- {g.Key.Kind}: `{Cell(g.Key.Name)}` — {g.First().Edge.Boundary!.Detail} (step {string.Join(", ", g.Select(x => x.Step.Number).Distinct())})\n")));
        if (trace.Upstream.Count > 0)
        {
            overview.Append("\n## Called From (outside the scope)\n\nBy name — an orientation, not proof of the runtime caller:\n\n")
                .Append(string.Concat(trace.Upstream.Select(u => $"- `{Cell(u.Caller.Container is { } c ? c[(c.LastIndexOf('.') + 1)..] + "." + u.Caller.Name : u.Caller.Name)}` calls `{u.Via}` — `{u.Caller.File}` lines {u.Caller.StartLine}–{u.Caller.EndLine}\n")));
        }
        Put("01-feature-overview.md", overview.ToString());

        var program = new StringBuilder($"# Program Flow — {title}\n\n[Architecture Index](00-index.md) · [Flat table and JSON](flows/program-flow.md) · [Call chain](flows/call-chain.md) · [Sequence](diagrams/sequence.md) · [Activity](diagrams/activity.md)\n\n");
        foreach (var entry in trace.Entries)
        {
            program.Append($"## Program Flow Table — {Cell(entry.Description)}\n\n").Append(FlowTable(trace, entry, "", includeSource: false, ClassLink, MethodLink)).Append('\n');
        }
        program.Append("## Execution Flows\n\n").Append(ArchitectureWriter.Write("the distinct flows (success, validation failure, not found, external or database failure…) with the step numbers each takes, from the conditions and error handling in the code; 'Only one path found' if the code has no meaningful branches")).Append('\n');
        program.Append("## Detailed Program Flow\n\n");
        foreach (var st in trace.Steps)
        {
            program.Append($"<a id=\"step-{st.Number}\"></a>\n\n### Step {st.Number} — {Cell(st.Project)} / {Cell(st.TypeName)} / {Cell(st.MethodName)}\n\n");
            if (keySteps.Contains(st))
            {
                program.Append("**What:** ").Append(ArchitectureWriter.Write("what this step does")).Append("\n**Why:** ").Append(ArchitectureWriter.Write("why the flow needs it"))
                    .Append("\n**How:** ").Append(ArchitectureWriter.Write("how it does it, from the code (validation, branches, data changes)")).Append('\n');
            }
            if (st.Description.Length > 0) program.Append($"- Documented as: {st.Description}\n");
            program.Append($"- Role: {st.Role}{(st.Primary ? " — requested scope" : " — supporting code")}\n");
            program.Append($"- Input: {(st.Symbol.ParameterTypes.Count == 0 ? "none" : string.Join(", ", st.Symbol.ParameterTypes.Select(p => $"`{Cell(p)}`")))}\n");
            program.Append($"- Output: `{Cell(st.Symbol.ReturnType ?? (st.Symbol.Kind == SymbolKinds.TopLevel ? "—" : "void"))}`\n");
            if (st.Creates.Count > 0) program.Append($"- Creates: {string.Join(", ", st.Creates.Select(c => $"`{Cell(c)}`"))}\n");
            var sideEffects = st.Edges.Where(e => e.Boundary is not null).Select(e => $"{e.Boundary!.Kind} `{Cell(e.Boundary.Name)}` (line {e.Line})").Distinct().ToList();
            program.Append($"- Side effects: {(sideEffects.Count == 0 ? "none found directly in this method" : string.Join("; ", sideEffects))}\n");
            program.Append("- Calls:\n").Append(Indent(EdgeList(st, "", MethodLink)));
            program.Append($"- Next: {(st.Edges.FirstOrDefault(e => e.Target is not null)?.Target is { } nx ? $"step {nx.Number} ({Cell(nx.Display)})" : st.Parent is { } p ? $"returns to step {p.Number} ({Cell(p.Display)})" : "end of this entry's flow")}\n");
            program.Append($"- Source: `{st.Symbol.File}` lines {st.Symbol.StartLine}–{st.Symbol.EndLine}{(st.CalledFromLine is { } l && st.Parent is { } cp ? $"; called from `{cp.Symbol.File}` line {l}" : "")}\n");
            if (st.Truncated is { } why) program.Append($"- Not traced further: {why}\n");
            if (!keySteps.Contains(st)) program.Append($"\n{FactsOnly}steps; this step's facts are above._\n");
            program.Append('\n');
        }
        Put("02-program-flow.md", program.ToString());

        var boundariesPage = new StringBuilder($"# Project Boundaries — {title}\n\n[Architecture Index](00-index.md) · [Cross-project diagram](diagrams/cross-project-flow.md)\n\n");
        var transitions = trace.Transitions.ToList();
        boundariesPage.Append(transitions.Count == 0 ? $"The traced flow stays inside **{trace.Projects.FirstOrDefault() ?? "one project"}**.\n\n" :
            "## Project Transition Table\n\n| From Project | From Class/Method | To Project | To Class/Method | Reason |\n|---|---|---|---|---|\n" +
            string.Concat(transitions.Select(x => $"| {Cell(x.From.Project)} | `{Cell(x.From.Display)}` | {Cell(x.To.Project)} | `{Cell(x.To.Display)}` | {Cell(x.To.Role)}{(x.From.Edges.First(e => e.Target == x.To).Resolution is { } r ? $"; {Cell(r)}" : "")} (step {x.From.Number} → {x.To.Number}) |\n")) + "\n");
        boundariesPage.Append("## Call Chain by Project\n\n").Append(string.Concat(trace.Entries.Select(e => $"### {Cell(e.Description)}\n\n```text\n{LinearChain(PrimaryPath(e.Root), byProject: true)}```\n\n")));
        Put("03-project-boundaries.md", boundariesPage.ToString());

        var dataPage = new StringBuilder($"# Data Flow — {title}\n\n[Architecture Index](00-index.md) · [Diagram](diagrams/data-flow.md)\n\n");
        if (dataObjects.Count == 0)
        {
            dataPage.Append("No repository-defined data types are passed between the traced steps (only framework types such as strings and numbers).\n");
        }
        else
        {
            dataPage.Append("## Data Flow Table\n\n| Step | Data | Created By | Consumed By | Returned By |\n|---:|---|---|---|---|\n");
            var n = 0;
            foreach (var o in dataObjects)
            {
                string Steps(List<FlowStep> list) => list.Count == 0 ? "—" : string.Join(", ", list.Take(6).Select(s => $"{StepLink(s, "")} `{Cell(s.Display)}`"));
                dataPage.Append($"| {++n} | `{Cell(o.Type)}` | {Steps(o.CreatedBy)} | {Steps(o.ConsumedBy)} | {Steps(o.ReturnedBy)} |\n");
            }
            dataPage.Append("\n## Transformations\n\n").Append(ArchitectureWriter.Write("how the data changes between these types along the flow (mapping, validation, enrichment), with the method that does each change, from the code"));
        }
        Put("04-data-flow.md", dataPage.ToString());

        var classes = new StringBuilder($"# Classes — {title}\n\n[Architecture Index](00-index.md) · [Class diagram](diagrams/class-diagram.md) · [Type dependencies](diagrams/type-dependencies.md)\n\n");
        classes.Append("## Requested-Scope Inventory\n\n| Project | Class | Role in the flow | In Primary Scope? | Steps | Complexity | Page |\n|---|---|---|---|---|---:|---|\n");
        foreach (var t in involved)
        {
            var steps = stepsByType[t];
            classes.Append($"| {Cell(t.Symbol.Project)} | `{Cell(t.Symbol.Name)}` | {Cell(steps[0].Role)} | {(steps.Any(s => s.Primary) ? "Yes" : "Supporting")} | {string.Join(", ", steps.Take(8).Select(s => StepLink(s, "")))} | {t.Metrics.CyclomaticComplexity} | [page]({classPage[t]}) |\n");
        }
        var primaryOnly = scope.Types.Where(pt => !involved.Any(t => t.Symbol.FullName == pt.FullName)).ToList();
        if (primaryOnly.Count > 0)
        {
            classes.Append($"\n## In the Scope but Not Reached\n\nTypes in the requested scope that no traced entry point calls (data types, unused code, or entry points beyond the limit):\n\n{string.Concat(primaryOnly.Take(40).Select(t => $"- `{Cell(t.Name)}` ({t.Kind}, `{t.File}`)\n"))}");
        }
        classes.Append("\n## Responsibilities\n\n").Append(ArchitectureWriter.Write("one bullet per participating class: its responsibility in this flow"));
        Put("05-classes.md", classes.ToString());

        if (hasDatabase)
        {
            var db = new StringBuilder($"# Database — {title}\n\n[Architecture Index](00-index.md){(entities.Count > 0 ? " · [ER diagram](diagrams/er-diagram.md)" : "")}\n\n");
            var dbCalls = boundaries.Where(b => b.Edge.Boundary!.Kind == "database").ToList();
            db.Append(dbCalls.Count == 0 ? "No direct database calls were traced.\n\n" : "## Database Operations\n\n| Step | Method | Call | Detail | Line |\n|---:|---|---|---|---:|\n" +
                string.Concat(dbCalls.Select(b => $"| {StepLink(b.Step, "")} | `{Cell(b.Step.Display)}` | `{Cell(b.Edge.Call)}` | {Cell(b.Edge.Boundary!.Detail)} | {b.Edge.Line} |\n")) + "\n");
            if (entities.Count > 0)
            {
                db.Append("## Entities Touched\n\n| Entity | Set | DbContext | Properties |\n|---|---|---|---:|\n")
                  .Append(string.Concat(entities.Select(e => $"| `{Cell(e.Type)}` | `{Cell(e.Name)}` | {Cell(e.DbContext ?? "")} | {e.Properties.Count} |\n"))).Append('\n');
            }
            db.Append("## Read/Write Behaviour\n\n").Append(ArchitectureWriter.Write("what this flow reads and writes, in which step, and in what transaction (from the code); 'Not determined from static repository analysis.' where it cannot be seen"));
            Put("06-database.md", db.ToString());
        }
        if (hasIntegrations)
        {
            var api = new StringBuilder($"# APIs and Integrations — {title}\n\n[Architecture Index](00-index.md)\n\n");
            if (endpoints.Count > 0)
            {
                api.Append("## Endpoints\n\n| Method / Route | Handler | Step | Source |\n|---|---|---:|---|\n")
                   .Append(string.Concat(endpoints.Select(e => $"| `{Cell(e.Description)}` | `{Cell(e.Root.Display)}` | {StepLink(e.Root, "")} | `{e.Root.Symbol.File}` |\n"))).Append('\n');
            }
            var outbound = boundaries.Where(b => b.Edge.Boundary!.Kind is "http" or "message" or "file" or "process" or "external").ToList();
            if (outbound.Count > 0)
            {
                api.Append("## Outbound Calls and Messages\n\n| Kind | Target | Detail | Step | Line |\n|---|---|---|---:|---:|\n")
                   .Append(string.Concat(outbound.Select(b => $"| {b.Edge.Boundary!.Kind}{(b.Edge.Boundary.Asynchronous ? " (async)" : "")} | `{Cell(b.Edge.Boundary.Name)}` | {Cell(b.Edge.Boundary.Detail)} | {StepLink(b.Step, "")} | {b.Edge.Line} |\n"))).Append('\n');
            }
            api.Append("## Authentication, Validation and Errors\n\n").Append(ArchitectureWriter.Write("for each endpoint or integration: authentication/authorization, validation, errors returned or raised — from the code; 'Not determined from static repository analysis.' where not visible"));
            Put("07-api-and-integrations.md", api.ToString());
        }

        // ---------- metrics/ and inventory/ ----------
        PutJson("metrics/classes.json", new
        {
            schemaVersion = "1.0",
            scope = scope.Label,
            classes = involved.Select(t => new { name = t.Symbol.Name, fullyQualifiedName = t.Symbol.FullName, project = t.Symbol.Project, primary = stepsByType[t].Any(s => s.Primary), metrics = t.Metrics }),
        });
        PutJson("metrics/methods.json", new
        {
            schemaVersion = "1.0",
            scope = scope.Label,
            methods = trace.Steps.Select(s => (Step: s, Node: MethodOf(s))).Where(x => x.Node is not null).DistinctBy(x => x.Node).Select(x => new
            {
                step = x.Step.Number, type = x.Step.TypeName, method = x.Step.MethodName, source = x.Step.Symbol.File, startLine = x.Step.Symbol.StartLine, endLine = x.Step.Symbol.EndLine,
                metrics = new
                {
                    linesOfCode = x.Node!.Metrics.LinesOfCode, parameterCount = x.Node.Metrics.ParameterCount, branchCount = x.Node.Metrics.BranchCount,
                    cyclomaticComplexity = x.Node.Metrics.CyclomaticComplexity, dependencyCalls = x.Node.Metrics.DependencyCalls,
                },
            }),
        });
        PutJson("inventory/scope.json", new
        {
            schemaVersion = "1.0",
            mode = "partial",
            repository = model.Repository,
            scope = new { kind = scope.Kind, target = scope.Target, label = scope.Label, path = scope.RelativePath },
            notes = scope.Notes,
            primary = new { files = scope.Files.Order(StringComparer.Ordinal), types = scope.Types.Select(t => t.FullName).Distinct(), methods = scope.Methods.Take(200).Select(m => $"{m.Container}.{m.Name}") },
            supporting = involved.Where(t => !stepsByType[t].Any(s => s.Primary)).Select(t => t.Symbol.FullName),
            limits = trace.Limits,
            ambiguities = trace.Ambiguities,
        });
        PutJson("inventory/types.json", new
        {
            schemaVersion = "1.0",
            types = involved.Select(t => new { id = t.Id, name = t.Symbol.Name, fullyQualifiedName = t.Symbol.FullName, kind = t.Symbol.Kind, project = t.Symbol.Project, source = t.Symbol.File, startLine = t.Symbol.StartLine, endLine = t.Symbol.EndLine, primary = stepsByType[t].Any(s => s.Primary), bases = t.Symbol.Bases }),
        });
        PutJson("inventory/methods.json", new
        {
            schemaVersion = "1.0",
            methods = trace.Steps.Select(s => new { step = s.Number, type = s.Symbol.Container, method = s.MethodName, signature = s.Symbol.Signature, project = s.Project, source = s.Symbol.File, startLine = s.Symbol.StartLine, endLine = s.Symbol.EndLine, primary = s.Primary, role = s.Role }),
        });
        var ids = involved.Select(t => t.Id).ToHashSet(StringComparer.Ordinal);
        PutJson("inventory/relationships.json", new
        {
            schemaVersion = "1.0",
            relationships = model.Relationships.Where(r => ids.Contains(r.Source) && ids.Contains(r.Target))
                .Select(r => new { source = r.Source, target = r.Target, relationship = r.Kind, evidence = r.Evidence, confidence = r.Confidence })
                .Concat(trace.Steps.SelectMany(s => s.Edges.Where(e => e.Target is not null).Select(e => new
                {
                    source = $"method:{s.Symbol.Container}.{s.Symbol.Name}", target = $"method:{e.Target!.Symbol.Container}.{e.Target.Symbol.Name}", relationship = "calls",
                    evidence = e.Resolution is null ? $"call at {s.Symbol.File}:{e.Line}" : $"call at {s.Symbol.File}:{e.Line}; {e.Resolution}", confidence = e.Resolution?.Contains("DI", StringComparison.Ordinal) == true ? "high" : "medium",
                }))),
        });

        // ---------- 00-index.md ----------
        var index = new StringBuilder($"# Architecture — {title}\n\n");
        index.Append($"## Scope\n\nRequested: **{Cell(scope.Target)}** — analysed as a {scope.Kind}{(scope.RelativePath is { } rp ? $" (`{rp}`)" : "")}.\n");
        foreach (var note in scope.Notes) index.Append($"\n- {note}");
        index.Append($"\n\n## Repository Context\n\nPart of the **{model.Repository}** repository. The rest of the repository was used only to resolve calls, dependencies and data; it is not documented here.\n\n");
        index.Append("## What / Why / How\n\n").Append(ArchitectureWriter.Write("three short paragraphs — what it is, why it exists, how it works — consistent with 01-feature-overview.md")).Append('\n');
        index.Append("## Entry Point\n\n").Append(EntryList(trace, "", ClassLink, MethodLink)).Append('\n');
        index.Append("## Primary Flow\n\n").Append(trace.Entries.Count == 0 ? "No entry point was found in the scope.\n\n" : $"```text\n{LinearChain(PrimaryPath(trace.Entries[0].Root), byProject: true)}```\n\n");
        index.Append("## Program Flow\n\n- [Program flow table and step-by-step walkthrough](02-program-flow.md)\n- [Flat table](flows/program-flow.md), [JSON](flows/program-flow.json) and [call chain](flows/call-chain.md)\n\n");
        index.Append("## Documents\n\n- [Feature overview](01-feature-overview.md)\n- [Project boundaries](03-project-boundaries.md)\n- [Data flow](04-data-flow.md)\n- [Classes](05-classes.md)\n");
        if (hasDatabase) index.Append("- [Database](06-database.md)\n");
        if (hasIntegrations) index.Append("- [APIs and integrations](07-api-and-integrations.md)\n");
        index.Append("\n## Diagrams\n\n- [Activity](diagrams/activity.md)\n- [Sequence](diagrams/sequence.md)\n- [Call graph](diagrams/call-graph.md)\n- [Cross-project flow](diagrams/cross-project-flow.md)\n- [Class diagram](diagrams/class-diagram.md)\n- [Type dependencies](diagrams/type-dependencies.md)\n- [Data flow](diagrams/data-flow.md)\n");
        if (entities.Count > 0) index.Append("- [ER diagram](diagrams/er-diagram.md)\n");
        index.Append($"\n## Projects Involved\n\n{string.Concat(trace.Projects.Select(p => $"- {p}\n"))}\n## Classes Involved\n\n{string.Concat(involved.Take(60).Select(t => $"- [`{Cell(t.Symbol.Name)}`]({classPage[t]}){(stepsByType[t].Any(s => s.Primary) ? "" : " (supporting)")}\n"))}");
        if (involved.Count > 60) index.Append($"- … {involved.Count - 60} more in [Classes](05-classes.md)\n");
        index.Append("\n## Analysis Boundary\n\n");
        index.Append($"- Documented: the requested {scope.Kind} and the {involved.Count(t => !stepsByType[t].Any(s => s.Primary))} supporting classes its execution reaches ({trace.Steps.Count} steps from {trace.Entries.Count} entry points).\n");
        index.Append("- Not followed: framework and library internals, logging, tests, generated code; databases, HTTP APIs, messages and the file system are shown as boundaries.\n");
        index.Append($"- Uncertain calls not followed: {trace.Ambiguities.Count}{(trace.Ambiguities.Count > 0 ? " (listed in `inventory/scope.json`)" : "")}.\n");
        foreach (var limit in trace.Limits) index.Append($"- Limit: {limit}\n");
        index.Append("- Static analysis only: nothing was run. Calls are resolved from declared types and DI registrations; reflection, dynamic dispatch and runtime configuration may add paths not shown.\n");
        Put("00-index.md", index.ToString());

        return new Result(files, diagrams, involved.Count, methodSteps.Count, keySteps.Count, kept);
    }

    /// <summary>
    /// The flow as chat-ready Markdown (no files): overview, program-flow table, call chain, sequence diagram, project
    /// transitions, boundaries and uncertainties — for "show me how X gets to Y" questions.
    /// </summary>
    public static string ChatSummary(FlowTrace trace, int maxRows = 40)
    {
        var sb = new StringBuilder();
        var scope = trace.Scope;
        sb.Append($"Scope: {scope.Kind} '{scope.Target}' → {trace.Entries.Count} entry points, {trace.Steps.Count} steps across {trace.Projects.Count()} projects ({string.Join(", ", trace.Projects)}).\n");
        foreach (var note in scope.Notes) sb.Append($"Note: {note}\n");
        foreach (var limit in trace.Limits) sb.Append($"Limit: {limit}\n");
        if (trace.Entries.Count == 0)
        {
            sb.Append("No entry point found in the scope (no endpoint, handler or public operation).\n");
        }
        foreach (var entry in trace.Entries)
        {
            var steps = Subtree(entry.Root).ToList();
            sb.Append($"\n## {entry.Description} — {entry.Root.Display} ({entry.Root.Symbol.File}:{entry.Root.Symbol.StartLine})\n\n");
            sb.Append("Descriptions: the method's /// summary, else (in italics) what its code visibly calls, creates and throws.\n\n");
            sb.Append("| Step | Project | Class | Method | Description | Role | Calls / Next Step | Source |\n|---:|---|---|---|---|---|---|---|\n");
            foreach (var s in steps.Take(maxRows))
            {
                var next = s.Edges.Count == 0 ? (s.Parent is { } p ? $"returns to {p.Number}" : "end") : string.Join("<br>", s.Edges.Take(8).Select(EdgeShort));
                sb.Append($"| {s.Number} | {Cell(s.Project)} | {Cell(s.TypeName)} | {Cell(s.MethodName)} | {DescriptionCell(s)} | {Cell(s.Role)} | {next} | {s.Symbol.File}:{s.Symbol.StartLine}–{s.Symbol.EndLine} |\n");
            }
            if (steps.Count > maxRows) sb.Append($"\n… {steps.Count - maxRows} more steps (use a narrower scope or action=model for the full bundle).\n");
            sb.Append($"\nCall chain (primary path):\n```text\n{LinearChain(PrimaryPath(entry.Root), byProject: true)}```\n");
            sb.Append($"\nSequence (calls in source order; branches not distinguished):\n```mermaid\n{Sequence(entry.Root)}```\n");
            var edgesWithResolution = steps.SelectMany(s => s.Edges.Where(e => e.Resolution is not null).Select(e => $"step {s.Number} line {e.Line}: {e.Resolution}")).Take(10).ToList();
            if (edgesWithResolution.Count > 0) sb.Append("\nInterface/handler resolution:\n").Append(string.Concat(edgesWithResolution.Select(r => $"- {r}\n")));
        }
        var transitions = trace.Transitions.ToList();
        if (transitions.Count > 0)
        {
            sb.Append("\nProject transitions:\n\n| From Project | From | To Project | To |\n|---|---|---|---|\n")
              .Append(string.Concat(transitions.Take(30).Select(t => $"| {t.From.Project} | {t.From.Display} (step {t.From.Number}) | {t.To.Project} | {t.To.Display} (step {t.To.Number}) |\n")));
        }
        var boundaries = trace.BoundaryEdges.ToList();
        if (boundaries.Count > 0)
        {
            sb.Append("\nBoundaries (database / HTTP / messages / files):\n").Append(string.Concat(boundaries.Take(25).Select(b => $"- step {b.Step.Number} {b.Step.Display} line {b.Edge.Line}: {b.Edge.Boundary!.Kind} {b.Edge.Boundary.Name} — {b.Edge.Boundary.Detail}\n")));
        }
        if (trace.Ambiguities.Count > 0)
        {
            sb.Append("\nNot followed (several possible targets):\n").Append(string.Concat(trace.Ambiguities.Take(15).Select(a => $"- {a}\n")));
        }
        if (trace.Upstream.Count > 0)
        {
            sb.Append("\nCalled from outside the scope (by name):\n").Append(string.Concat(trace.Upstream.Take(10).Select(u => $"- {u.Caller.Container}.{u.Caller.Name} ({u.Caller.File}:{u.Caller.StartLine}) calls {u.Via}\n")));
        }
        return sb.ToString();
    }

    // ---------- Tables and chains ----------

    private static string FlowTable(FlowTrace trace, FlowEntry entry, string up, bool includeSource, Func<FlowStep, string, string> classLink, Func<FlowStep, string, string> methodLink)
    {
        var sb = new StringBuilder($"Description: the method's /// summary or its written What; in italics, what its code visibly calls, creates and throws.\n\n| Step | Project | Class | Method | Description | Role | Calls / Next Step |{(includeSource ? " Source |" : "")}\n|---:|---|---|---|---|---|---|{(includeSource ? "---|" : "")}\n");
        foreach (var s in Subtree(entry.Root))
        {
            var next = s.Edges.Count == 0 ? (s.Parent is { } p ? $"returns to {p.Number}" : "end") : string.Join("<br>", s.Edges.Take(10).Select(EdgeShort)) + (s.Edges.Count > 10 ? $"<br>… {s.Edges.Count - 10} more" : "");
            sb.Append($"| [{s.Number}]({up}02-program-flow.md#step-{s.Number}) | {Cell(s.Project)} | {classLink(s, up)} | {methodLink(s, up)} | {DescriptionCell(s)} | {Cell(s.Role)} | {next} |{(includeSource ? $" `{s.Symbol.File}:{s.Symbol.StartLine}` |" : "")}\n");
        }
        return sb.ToString();
    }

    /// <summary>
    /// The step's description: its /// summary, else "—" until the skill writes the step's What (validation copies the
    /// first sentence of that into the table — see <see cref="ArchitectureBundle"/>).
    /// </summary>
    internal static string DescriptionCell(FlowStep s) => s.Description.Length > 0 ? Cell(s.Description) : StructuralDescription(s);

    /// <summary>
    /// For a step without a /// summary: what its code visibly does — the methods it calls, what it creates, database /
    /// API / message calls and exceptions it throws — in italics, so it reads as derived. Validation replaces it with
    /// the first sentence of the step's written What.
    /// </summary>
    internal static string StructuralDescription(FlowStep s)
    {
        var parts = new List<string>();
        var calls = s.Edges.Select(e => e.Target ?? e.RepeatOf).Where(t => t is not null).Select(t => $"{t!.TypeName}.{t.MethodName}").Distinct().ToList();
        if (calls.Count > 0) parts.Add($"calls {string.Join(", ", calls.Take(3))}{(calls.Count > 3 ? $" and {calls.Count - 3} more" : "")}");
        var effects = s.Edges.Where(e => e.Boundary is not null).Select(e => $"{e.Boundary!.Kind} {e.Boundary.Name}").Distinct().ToList();
        if (effects.Count > 0) parts.Add(string.Join(", ", effects.Take(2)));
        if (s.Creates.Count > 0) parts.Add($"creates {string.Join(", ", s.Creates.Distinct().Take(3))}");
        if (s.Flow is { } f && f.Throws.Count > 0) parts.Add($"throws {string.Join(", ", f.Throws.Select(t => t.Type).Distinct().Take(2))}");
        if (s.Flow is { } g && g.Conditions.Count > 0) parts.Add($"{g.Conditions.Count} condition{(g.Conditions.Count == 1 ? "" : "s")}");
        if (parts.Count == 0)
        {
            var returns = s.Symbol.ReturnType is { Length: > 0 } rt && rt != "void" ? $"returns {rt}" : "no calls into repository code";
            parts.Add(returns);
        }
        var text = string.Join("; ", parts);
        return "_" + Cell(char.ToUpperInvariant(text[0]) + text[1..]) + "_";
    }

    internal const string NoDescription = "—";

    /// <summary>Markdown gets a UTF-8 byte-order mark so Windows tools and viewers do not read it as ANSI (â€” for —); JSON does not.</summary>
    internal static Encoding EncodingFor(string relative) => relative.EndsWith(".md", StringComparison.OrdinalIgnoreCase) ? new UTF8Encoding(true) : new UTF8Encoding(false);

    internal static string EdgeShort(FlowEdge e)
    {
        var call = Cell(Short(e.Call, 50));
        if (e.Target is { } t) return $"→ {t.Number} `{Cell(t.Display)}`{(e.Boundary is { Asynchronous: true } ? " (async)" : "")}";
        if (e.RepeatOf is { } r) return $"↺ {r.Number} `{Cell(r.Display)}`";
        if (e.Boundary is { } b) return $"{b.Kind}: `{Cell(Short(b.Name, 50))}`";
        if (e.Candidates.Count > 0) return $"? `{call}` ({e.Candidates.Count} candidates)";
        return $"`{call}` (not traced)";
    }

    private static string EdgeList(FlowStep s, string up, Func<FlowStep, string, string> methodLink)
    {
        if (s.Edges.Count == 0)
        {
            return "- No calls into repository code or external systems.\n";
        }
        var sb = new StringBuilder();
        foreach (var e in s.Edges)
        {
            sb.Append($"- line {e.Line}: `{Cell(e.Call)}` ");
            if (e.Target is { } t) sb.Append($"→ [step {t.Number}]({up}02-program-flow.md#step-{t.Number}) `{Cell(t.Display)}` ({Cell(t.Project)})");
            else if (e.RepeatOf is { } r) sb.Append($"→ step {r.Number} `{Cell(r.Display)}` (traced earlier)");
            else if (e.Boundary is { } b) sb.Append($"→ {b.Kind} boundary: {Cell(b.Detail)}");
            else if (e.Candidates.Count > 0) sb.Append($"→ uncertain: {string.Join(", ", e.Candidates.Select(c => $"`{Cell(c)}`"))}");
            else sb.Append("→ not traced (limit)");
            if (e.Resolution is { } res) sb.Append($" — {Cell(res)}");
            sb.Append('\n');
        }
        return sb.ToString();
    }

    private static string EntryList(FlowTrace trace, string up, Func<FlowStep, string, string> classLink, Func<FlowStep, string, string> methodLink)
    {
        if (trace.Entries.Count == 0)
        {
            return "No entry point was found: nothing in the scope is an endpoint, handler or public operation.\n";
        }
        return string.Concat(trace.Entries.Select(e => $"- **{Cell(e.Description)}** — {classLink(e.Root, up)}.{methodLink(e.Root, up)} in {Cell(e.Root.Project)} (`{e.Root.Symbol.File}` line {e.Root.Symbol.StartLine}); {Subtree(e.Root).Count()} steps\n"));
    }

    private static string EndPoints(FlowTrace trace)
    {
        var sb = new StringBuilder();
        foreach (var e in trace.Entries)
        {
            var path = PrimaryPath(e.Root);
            var last = path[^1];
            var ends = Subtree(e.Root).SelectMany(s => s.Edges.Where(x => x.Boundary is not null)).Select(x => $"{x.Boundary!.Kind} `{Cell(x.Boundary.Name)}`").Distinct().ToList();
            sb.Append($"- {Cell(e.Description)}: the deepest path ends in `{Cell(last.Display)}` (step {last.Number}){(ends.Count > 0 ? $"; external effects: {string.Join(", ", ends.Take(6))}" : "")}; control then returns to `{Cell(e.Root.Display)}`.\n");
        }
        return sb.Length == 0 ? "Not determined: no entry point was traced.\n" : sb.ToString();
    }

    public static IEnumerable<FlowStep> Subtree(FlowStep root)
    {
        yield return root;
        foreach (var e in root.Edges.Where(e => e.Target is not null))
        {
            foreach (var s in Subtree(e.Target!))
            {
                yield return s;
            }
        }
    }

    /// <summary>The path from the root that reaches the most steps (the main line of execution).</summary>
    public static List<FlowStep> PrimaryPath(FlowStep root)
    {
        var path = new List<FlowStep> { root };
        var current = root;
        while (current.Edges.Where(e => e.Target is not null).Select(e => e.Target!).OrderByDescending(t => Subtree(t).Count()).ThenBy(t => t.Number).FirstOrDefault() is { } next)
        {
            path.Add(next);
            current = next;
        }
        return path;
    }

    internal static string LinearChain(List<FlowStep> path, bool byProject = false)
    {
        var sb = new StringBuilder();
        string? project = null;
        for (var i = 0; i < path.Count; i++)
        {
            var s = path[i];
            if (byProject && s.Project != project)
            {
                if (i > 0) sb.Append('\n');
                sb.Append($"[{s.Project}]\n");
                project = s.Project;
            }
            sb.Append(s.Symbol.Kind == SymbolKinds.TopLevel ? s.Display : $"{s.TypeName}.{s.MethodName}()").Append('\n');
            var boundaryEnds = i == path.Count - 1 ? s.Edges.Where(e => e.Boundary is not null).Select(e => e.Boundary!).DistinctBy(b => b.Name).ToList() : [];
            if (i < path.Count - 1 || boundaryEnds.Count > 0)
            {
                sb.Append("        ↓\n");
            }
            foreach (var b in boundaryEnds.Take(3))
            {
                sb.Append($"{(byProject ? $"\n[{Cap(b.Kind)}]\n" : "")}{b.Name}\n");
            }
        }
        return sb.ToString();
    }

    private static string Tree(FlowStep root)
    {
        var sb = new StringBuilder();
        void Walk(FlowStep s, string prefix, bool last, bool isRoot)
        {
            sb.Append(isRoot ? "" : prefix + (last ? "└─ " : "├─ ")).Append($"[{s.Project}] {s.Display}  (step {s.Number})\n");
            var childPrefix = isRoot ? "" : prefix + (last ? "   " : "│  ");
            var edges = s.Edges.ToList();
            for (var i = 0; i < edges.Count; i++)
            {
                var e = edges[i];
                var isLast = i == edges.Count - 1;
                if (e.Target is { } t)
                {
                    Walk(t, childPrefix, isLast, false);
                }
                else
                {
                    var text = e.RepeatOf is { } r ? $"↺ {r.Display} (step {r.Number})" : e.Boundary is { } b ? $"[{Cap(b.Kind)}] {b.Name}" : e.Candidates.Count > 0 ? $"? {e.Call} — uncertain ({e.Candidates.Count} candidates)" : $"{e.Call} (not traced)";
                    sb.Append(childPrefix + (isLast ? "└─ " : "├─ ") + text + "\n");
                }
            }
        }
        Walk(root, "", true, true);
        return sb.ToString();
    }

    private static string ActivityBrief(FlowStep root)
    {
        var sb = new StringBuilder($"a flowchart TD activity diagram of this flow as the code runs it: start at {root.Display}, show validations and decisions, loops, retries, error paths, persistence, external calls and messages, and the result; use the real names. Evidence to start from:");
        foreach (var s in Subtree(root).Take(12))
        {
            if (s.Flow is not { } f) continue;
            var conditions = f.Conditions.Take(4).Select(c => $"line {c.Line}: if {Short(c.Condition.Text, 60)}").ToList();
            var errors = f.Throws.Take(2).Select(t => $"line {t.Line}: throws {t.Type}").Concat(f.Catches.Take(2).Select(c => $"line {c.Line}: catches {c.ExceptionType ?? "exception"}")).ToList();
            if (conditions.Count + errors.Count > 0)
            {
                sb.Append($" {s.Display} [{string.Join("; ", conditions.Concat(errors))}]");
            }
        }
        return Regex.Replace(sb.ToString(), "-->|--", "-").Replace("\n", " ");
    }

    // ---------- Mermaid ----------

    private static string CallGraph(IEnumerable<FlowStep> steps)
    {
        var sb = new StringBuilder("flowchart TD\n");
        var nodes = new Dictionary<string, string>(StringComparer.Ordinal);
        var edges = new HashSet<string>(StringComparer.Ordinal);
        string Node(FlowStep s)
        {
            var key = $"{s.Symbol.Container}.{s.Symbol.Name}({string.Join(",", s.Symbol.ParameterTypes)})";
            if (!nodes.TryGetValue(key, out var id))
            {
                id = "s" + (nodes.Count + 1);
                nodes[key] = id;
                sb.Append($"    {id}[\"{Label(s.Symbol.Kind == SymbolKinds.TopLevel ? s.Display : $"{s.TypeName}.{s.MethodName}()")}\"]\n");
            }
            return id;
        }
        var extra = 0;
        foreach (var s in steps)
        {
            if (nodes.Count >= MaxGraphNodes)
            {
                sb.Append($"    more[\"… more steps: see the program flow table\"]\n");
                break;
            }
            var from = Node(s);
            foreach (var e in s.Edges)
            {
                string? to = null;
                var style = "-->";
                if (e.Target is { } t) to = Node(t);
                else if (e.RepeatOf is { } r) to = Node(r);
                else if (e.Boundary is { } b)
                {
                    to = "b" + Id(b.Kind + "_" + b.Name);
                    if (edges.Add("node:" + to))
                    {
                        sb.Append(b.Kind switch
                        {
                            "database" => $"    {to}[(\"{Label(Short(b.Name, 48))}\")]\n",
                            "message" => $"    {to}>\"{Label(Short(b.Name, 48))}\"]\n",
                            _ => $"    {to}[[\"{Label($"{b.Kind}: {Short(b.Name, 44)}")}\"]]\n",
                        });
                    }
                }
                else if (e.Candidates.Count > 0)
                {
                    to = "u" + (++extra);
                    sb.Append($"    {to}{{\"{Label("? " + Short(e.Call, 40))}\"}}\n");
                    style = "-.->";
                }
                if (to is not null && edges.Add($"{from}>{to}"))
                {
                    sb.Append(e.Boundary is { Asynchronous: true } ? $"    {from} -. async .-> {to}\n" : $"    {from} {style} {to}\n");
                }
            }
        }
        return sb.ToString();
    }

    private static string CrossProject(FlowTrace trace)
    {
        var sb = new StringBuilder("flowchart LR\n");
        var nodes = new Dictionary<string, (string Id, FlowStep Step)>(StringComparer.Ordinal);
        foreach (var s in trace.Steps)
        {
            var key = $"{s.Symbol.Container}.{s.Symbol.Name}";
            if (!nodes.ContainsKey(key) && nodes.Count < MaxGraphNodes)
            {
                nodes[key] = ("n" + (nodes.Count + 1), s);
            }
        }
        foreach (var group in nodes.Values.GroupBy(n => n.Step.Project))
        {
            sb.Append($"    subgraph {Id("p_" + group.Key)}[\"{Label(group.Key)}\"]\n");
            foreach (var (id, s) in group)
            {
                sb.Append($"        {id}[\"{Label(s.Symbol.Kind == SymbolKinds.TopLevel ? s.Display : $"{s.TypeName}.{s.MethodName}")}\"]\n");
            }
            sb.Append("    end\n");
        }
        var edges = new HashSet<string>(StringComparer.Ordinal);
        foreach (var s in trace.Steps)
        {
            if (!nodes.TryGetValue($"{s.Symbol.Container}.{s.Symbol.Name}", out var from)) continue;
            foreach (var e in s.Edges)
            {
                var target = e.Target ?? e.RepeatOf;
                if (target is not null && nodes.TryGetValue($"{target.Symbol.Container}.{target.Symbol.Name}", out var to) && edges.Add($"{from.Id}>{to.Id}"))
                {
                    sb.Append(e.Boundary is { Asynchronous: true } ? $"    {from.Id} -. async .-> {to.Id}\n" : $"    {from.Id} --> {to.Id}\n");
                }
                else if (e.Boundary is { } b && e.Target is null)
                {
                    var bid = "x" + Id(b.Kind + "_" + b.Name);
                    if (edges.Add("node:" + bid)) sb.Append(b.Kind == "database" ? $"    {bid}[(\"{Label(Short(b.Name, 40))}\")]\n" : $"    {bid}[[\"{Label($"{b.Kind}: {Short(b.Name, 36)}")}\"]]\n");
                    if (edges.Add($"{from.Id}>{bid}")) sb.Append($"    {from.Id} --> {bid}\n");
                }
            }
        }
        return sb.ToString();
    }

    /// <summary>A sequence diagram of the calls under <paramref name="root"/> in source order (returns shown for cross-participant calls).</summary>
    internal static string Sequence(FlowStep root, int maxDepth = 12)
    {
        var sb = new StringBuilder("sequenceDiagram\n");
        var participants = new Dictionary<string, string>(StringComparer.Ordinal);
        var body = new StringBuilder();
        var messages = 0;
        string P(string name)
        {
            if (!participants.TryGetValue(name, out var id))
            {
                id = "p" + (participants.Count + 1);
                participants[name] = id;
            }
            return id;
        }
        string Of(FlowStep s) => P(s.Symbol.Kind == SymbolKinds.TopLevel ? Path.GetFileNameWithoutExtension(s.Symbol.File) : s.TypeName);
        string Text(string t) => Regex.Replace(t, "[;#:<>{}]", " ").Trim();
        void Walk(FlowStep s, int depth)
        {
            var me = Of(s);
            foreach (var e in s.Edges)
            {
                if (messages >= 90)
                {
                    return;
                }
                if (e.Target is { } t)
                {
                    var them = Of(t);
                    messages++;
                    if (e.Boundary is { Asynchronous: true })
                    {
                        var bus = P("Message bus");
                        body.Append($"    {me}-){bus}: {Text(e.Boundary.Name)}\n    {bus}-){them}: {Text(t.MethodName)}\n");
                    }
                    else
                    {
                        body.Append($"    {me}->>{them}: {Text(t.MethodName)}()\n");
                    }
                    if (depth < maxDepth)
                    {
                        Walk(t, depth + 1);
                    }
                    if (them != me && e.Boundary is not { Asynchronous: true })
                    {
                        body.Append($"    {them}-->>{me}: {Text(Short(t.Symbol.ReturnType ?? "done", 30))}\n");
                    }
                }
                else if (e.RepeatOf is { } r)
                {
                    messages++;
                    body.Append($"    {me}->>{Of(r)}: {Text(r.MethodName)}() see step {r.Number}\n");
                }
                else if (e.Boundary is { } b)
                {
                    var them = P(b.Kind switch { "database" => "Database", "http" => "HTTP API", "message" => "Message bus", "file" => "File system", "process" => "External process", _ => "External" });
                    messages++;
                    var callee = e.Call[(e.Call.LastIndexOf('.') + 1)..];
                    body.Append(b.Asynchronous ? $"    {me}-){them}: {Text(callee)}\n" : $"    {me}->>{them}: {Text(callee)}\n    {them}-->>{me}: result\n");
                }
                else if (e.Candidates.Count > 0)
                {
                    body.Append($"    Note over {me}: {Text(Short(e.Call, 40))} is uncertain ({e.Candidates.Count} candidates)\n");
                }
            }
        }
        Of(root);
        Walk(root, 0);
        if (messages >= 90)
        {
            body.Append($"    Note over {Of(root)}: more calls follow; see the program flow table\n");
        }
        foreach (var (name, id) in participants)
        {
            sb.Append($"    participant {id} as {Text(name)}\n");
        }
        if (messages == 0)
        {
            body.Append($"    Note over {Of(root)}: no calls into repository code or external systems\n");
        }
        return sb.Append(body).ToString();
    }

    private static string ClassDiagram(List<TypeNode> types, ArchitectureModel model, Dictionary<TypeNode, List<FlowStep>> steps)
    {
        var sb = new StringBuilder("classDiagram\n");
        var ids = types.Select(t => t.Id).ToHashSet(StringComparer.Ordinal);
        foreach (var t in types)
        {
            sb.Append($"    class {Id(t.Symbol.Name)} {{\n");
            if (t.Symbol.Kind == SymbolKinds.Interface) sb.Append("        <<interface>>\n");
            foreach (var s in steps[t].DistinctBy(s => s.Symbol.Name).Take(8))
            {
                sb.Append($"        {(s.Symbol.Modifiers.Contains("public") ? "+" : s.Symbol.Modifiers.Contains("private") ? "-" : "#")}{Member(s.MethodName == "constructor" ? t.Symbol.Name : s.MethodName)}({Member(string.Join(", ", s.Symbol.ParameterTypes))})\n");
            }
            sb.Append("    }\n");
        }
        foreach (var r in model.Relationships.Where(r => ids.Contains(r.Source) && ids.Contains(r.Target) && r.Kind is "inherits" or "implements" or "depends_on").DistinctBy(r => (r.Source, r.Target)).Take(80))
        {
            var from = Id(r.Source[(r.Source.LastIndexOf('.') + 1)..]);
            var to = Id(r.Target[(r.Target.LastIndexOf('.') + 1)..]);
            sb.Append($"    {from} {(r.Kind == "inherits" ? "--|>" : r.Kind == "implements" ? "..|>" : "-->")} {to}\n");
        }
        return sb.ToString();
    }

    private static string TypeDependencies(List<TypeNode> types, ArchitectureModel model)
    {
        var ids = types.Select(t => t.Id).ToHashSet(StringComparer.Ordinal);
        // Interfaces the participants implement or depend on are part of the picture even without steps of their own.
        var interfaces = model.Relationships.Where(r => ids.Contains(r.Source) && r.Kind is "implements" or "depends_on" && r.Target.Length > 5)
            .Select(r => r.Target).Where(t => !ids.Contains(t) && Regex.IsMatch(t[(t.LastIndexOf('.') + 1)..], "^I[A-Z]")).Distinct().Take(20).ToList();
        var all = ids.Concat(interfaces).ToHashSet(StringComparer.Ordinal);
        var sb = new StringBuilder("flowchart LR\n");
        foreach (var id in all)
        {
            var name = id[(id.LastIndexOf('.') + 1)..];
            sb.Append($"    {Id("t_" + id)}[\"{Label(name)}\"]\n");
        }
        foreach (var r in model.Relationships.Where(r => all.Contains(r.Source) && all.Contains(r.Target) && r.Kind is "inherits" or "implements" or "depends_on" or "registered_as").DistinctBy(r => (r.Source, r.Target)).Take(100))
        {
            var label = r.Kind == "depends_on" ? r.Evidence.Replace('_', ' ') : r.Kind.Replace('_', ' ');
            sb.Append($"    {Id("t_" + r.Source)} -->|{Label(Short(label, 24))}| {Id("t_" + r.Target)}\n");
        }
        return sb.ToString();
    }

    private sealed record DataObject(string Type, List<FlowStep> CreatedBy, List<FlowStep> ConsumedBy, List<FlowStep> ReturnedBy);

    private static List<DataObject> DataObjects(FlowTrace trace, ArchitectureModel model)
    {
        var repoTypes = model.Types.Where(t => t.Symbol.Kind is SymbolKinds.Class or SymbolKinds.Record or SymbolKinds.Struct).Select(t => t.Symbol.Name).ToHashSet(StringComparer.Ordinal);
        var serviceLike = trace.Steps.Select(s => s.TypeName).ToHashSet(StringComparer.Ordinal); // types with behaviour in the flow are not data
        var objects = new Dictionary<string, DataObject>(StringComparer.Ordinal);
        DataObject Get(string name) => objects.TryGetValue(name, out var o) ? o : objects[name] = new DataObject(name, [], [], []);
        foreach (var s in trace.Steps)
        {
            foreach (var p in s.Symbol.ParameterTypes.SelectMany(ArchitectureModelBuilder.TypeNames).Where(n => repoTypes.Contains(n) && !serviceLike.Contains(n)).Distinct())
            {
                Get(p).ConsumedBy.Add(s);
            }
            foreach (var r in (s.Symbol.ReturnType is { } rt ? ArchitectureModelBuilder.TypeNames(rt) : []).Where(n => repoTypes.Contains(n) && !serviceLike.Contains(n)).Distinct())
            {
                Get(r).ReturnedBy.Add(s);
            }
            foreach (var c in s.Creates.Select(c => DocGen.Analysis.Rca.FlowContext.BareName(c)).Where(n => repoTypes.Contains(n) && !serviceLike.Contains(n)).Distinct())
            {
                Get(c).CreatedBy.Add(s);
            }
        }
        return objects.Values.OrderBy(o => o.CreatedBy.Concat(o.ConsumedBy).Concat(o.ReturnedBy).Min(s => s.Number)).Take(40).ToList();
    }

    private static string DataFlowDiagram(List<DataObject> objects)
    {
        var sb = new StringBuilder("flowchart LR\n");
        var steps = new HashSet<string>(StringComparer.Ordinal);
        string Step(FlowStep s)
        {
            var id = "s" + s.Number;
            if (steps.Add(id)) sb.Append($"    {id}[\"{Label($"{s.Number}. {s.Display}")}\"]\n");
            return id;
        }
        foreach (var o in objects.Take(20))
        {
            var id = Id("d_" + o.Type);
            sb.Append($"    {id}([\"{Label(o.Type)}\"])\n");
            foreach (var s in o.CreatedBy.Concat(o.ReturnedBy).DistinctBy(s => s.Number).Take(4)) sb.Append($"    {Step(s)} --> {id}\n");
            foreach (var s in o.ConsumedBy.Take(4)) sb.Append($"    {id} --> {Step(s)}\n");
        }
        return sb.ToString();
    }

    private static List<EntityNode> EntitiesTouched(FlowTrace trace, ArchitectureModel model, List<DataObject> data)
    {
        var names = data.Select(d => d.Type).ToHashSet(StringComparer.Ordinal);
        foreach (var (_, e) in trace.BoundaryEdges.Where(b => b.Edge.Boundary!.Kind == "database"))
        {
            foreach (var n in ArchitectureModelBuilder.TypeNames(e.Boundary!.Detail + " " + e.Call)) names.Add(n);
            foreach (var part in e.Call.Split('.')) names.Add(part);
        }
        var touched = model.Entities.Where(e => names.Contains(e.Type) || names.Contains(e.Name)).ToList();
        var related = model.Entities.Where(e => touched.Any(t => t.References.Any(r => r.Target == e.Type)) && !touched.Contains(e));
        return touched.Concat(related).DistinctBy(e => e.Type).Take(20).ToList();
    }

    private static string ErDiagram(List<EntityNode> entities, ArchitectureModel model)
    {
        var sb = new StringBuilder("erDiagram\n");
        var names = entities.Select(e => e.Type).ToHashSet(StringComparer.Ordinal);
        foreach (var e in entities)
        {
            sb.Append($"    {Id(e.Type)} {{\n");
            foreach (var (prop, type) in e.Properties.Where(p => !p.Type.Contains('<') && !names.Contains(p.Type.TrimEnd('?'))).Take(12))
            {
                sb.Append($"        {Id(Regex.Replace(type.TrimEnd('?'), "[^A-Za-z0-9_]", ""))} {Id(prop)}\n");
            }
            sb.Append("    }\n");
        }
        foreach (var e in entities)
        {
            foreach (var (prop, target, evidence) in e.References.Where(r => names.Contains(r.Target)).DistinctBy(r => r.Target))
            {
                sb.Append(evidence.StartsWith("collection", StringComparison.Ordinal) ? $"    {Id(e.Type)} ||--o{{ {Id(target)} : \"{Label(prop)}\"\n" : $"    {Id(e.Type)} }}o--|| {Id(target)} : \"{Label(prop)}\"\n");
            }
        }
        return sb.ToString();
    }

    // ---------- JSON ----------

    private static object FlowJson(FlowTrace trace) => new
    {
        schemaVersion = "1.0",
        feature = trace.Scope.Label,
        scope = new { kind = trace.Scope.Kind, target = trace.Scope.Target, path = trace.Scope.RelativePath },
        entryPoints = trace.Entries.Select(e => new { kind = e.Kind, description = e.Description, step = e.Root.Number, project = e.Root.Project, @class = e.Root.TypeName, method = e.Root.MethodName }),
        steps = trace.Steps.Select(s => new
        {
            step = s.Number,
            depth = s.Depth,
            parent = s.Parent?.Number,
            project = s.Project,
            @class = s.TypeName,
            method = s.MethodName,
            role = s.Role,
            primaryScope = s.Primary,
            source = new { file = s.Symbol.File, startLine = s.Symbol.StartLine, endLine = s.Symbol.EndLine },
            calledFromLine = s.CalledFromLine,
            next = s.Edges.Select(e => new
            {
                line = e.Line,
                call = e.Call,
                step = e.Target?.Number,
                repeatOf = e.RepeatOf?.Number,
                boundary = e.Boundary is { } b ? new { kind = b.Kind, name = b.Name, detail = b.Detail, asynchronous = b.Asynchronous } : null,
                candidates = e.Candidates.Count > 0 ? e.Candidates : null,
                resolution = e.Resolution,
                confidence = e.Target is not null ? "confirmed-static" : e.Candidates.Count > 0 ? "ambiguous" : e.Boundary is not null ? "boundary" : "unavailable",
            }),
            truncated = s.Truncated,
        }),
        projectTransitions = trace.Transitions.Select(t => new { fromProject = t.From.Project, from = t.From.Display, toProject = t.To.Project, to = t.To.Display, fromStep = t.From.Number, toStep = t.To.Number }),
        ambiguities = trace.Ambiguities,
        limits = trace.Limits,
    };

    // ---------- Helpers ----------

    private static string ScopeTitle(AnalysisScope scope) => scope.Kind == "feature" ? $"{char.ToUpperInvariant(scope.Label[0])}{scope.Label[1..]} (feature)" : scope.Label;

    private static string Key(SymbolRecord s) => $"{s.Container}|{s.Name}|{string.Join(",", s.ParameterTypes)}|{s.StartLine}";

    private static string TypeFile(TypeNode t)
        => t.Symbol.FullName.StartsWith(t.Symbol.Namespace + ".", StringComparison.Ordinal) ? t.Symbol.FullName[(t.Symbol.Namespace.Length + 1)..] : t.Symbol.FullName;

    private static bool Overloaded(SymbolRecord s, ArchitectureModel model) => model.Methods.Count(m => m.Symbol.Container == s.Container && m.Symbol.Name == s.Name) > 1;

    private static string Hash(SymbolRecord s) => Convert.ToHexString(SHA1.HashData(Encoding.UTF8.GetBytes(string.Join(",", s.ParameterTypes))))[..6].ToLowerInvariant();

    private static string Short(string text, int max) => text.Length <= max ? text : text[..(max - 1)] + "…";

    private static string Cap(string s) => s.Length == 0 ? s : char.ToUpperInvariant(s[0]) + s[1..];

    private static string Indent(string lines) => string.Concat(lines.Split('\n', StringSplitOptions.RemoveEmptyEntries).Select(l => "  " + l + "\n"));
}
