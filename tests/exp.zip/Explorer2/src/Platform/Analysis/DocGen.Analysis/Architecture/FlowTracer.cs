using System.Text.RegularExpressions;
using DocGen.Analysis.Flow;
using DocGen.Analysis.Indexing;
using DocGen.Analysis.Rca;

namespace DocGen.Analysis.Architecture;

/// <summary>Something the flow reaches outside the repository's code: a database, an HTTP API, a message, the file system.</summary>
public sealed record FlowBoundary(string Kind, string Name, string Detail, bool Asynchronous);

/// <summary>One call made by a step, in source order.</summary>
public sealed class FlowEdge
{
    public required int Line { get; init; }

    /// <summary>The call as written ("_orders.SaveAsync", "Place").</summary>
    public required string Call { get; init; }

    public FlowStep? Target { get; set; }

    /// <summary>The call reaches a step traced earlier (recursion or a shared helper).</summary>
    public FlowStep? RepeatOf { get; set; }

    public FlowBoundary? Boundary { get; set; }

    /// <summary>Several possible targets: static analysis cannot pick one, so the flow is not followed.</summary>
    public List<string> Candidates { get; } = [];

    /// <summary>How an interface call was resolved ("IOrderRepository → SqlOrderRepository (DI Scoped, Program.cs:12)").</summary>
    public string? Resolution { get; set; }
}

public sealed class FlowStep
{
    public required int Number { get; init; }
    public required int Depth { get; init; }
    public required SymbolRecord Symbol { get; init; }
    public FlowStep? Parent { get; init; }
    public int? CalledFromLine { get; init; }
    public required bool Primary { get; init; }
    public required string Role { get; init; }
    public List<FlowEdge> Edges { get; } = [];
    public List<string> Creates { get; } = [];

    /// <summary>Why tracing stopped here (depth or size limit), when it did.</summary>
    public string? Truncated { get; set; }

    public MemberFlow? Flow { get; set; }

    /// <summary>What the step does, from the method's own /// &lt;summary&gt; (empty when it has none).</summary>
    public string Description { get; set; } = "";

    public string Project => Symbol.Project;
    public string TypeName => Symbol.Container is { } c ? c[(c.LastIndexOf('.') + 1)..] : Path.GetFileNameWithoutExtension(Symbol.File);
    public string MethodName => Symbol.Kind == SymbolKinds.TopLevel ? "top-level statements" : Symbol.Kind == SymbolKinds.Constructor ? "constructor" : Symbol.Name;
    public string Display => Symbol.Kind == SymbolKinds.TopLevel ? $"{Path.GetFileName(Symbol.File)} (top-level)" : $"{TypeName}.{MethodName}";
}

public sealed class FlowEntry
{
    /// <summary>endpoint | handler | requested | public</summary>
    public required string Kind { get; init; }

    /// <summary>"POST /orders", "message handler", "requested method"…</summary>
    public required string Description { get; init; }

    public required FlowStep Root { get; init; }
}

/// <summary>A traced execution model of the scope: entry points, steps in call order, boundaries and uncertainties.</summary>
public sealed class FlowTrace
{
    public required AnalysisScope Scope { get; init; }
    public List<FlowEntry> Entries { get; } = [];
    public List<FlowStep> Steps { get; } = [];
    public List<string> Ambiguities { get; } = [];
    public List<string> Limits { get; } = [];

    /// <summary>Callers outside the scope (name-based), for "where does this flow begin" when the scope is a class or method.</summary>
    public List<(SymbolRecord Caller, string Via)> Upstream { get; } = [];

    public IEnumerable<(FlowStep Step, FlowEdge Edge)> BoundaryEdges => Steps.SelectMany(s => s.Edges.Where(e => e.Boundary is not null).Select(e => (s, e)));

    public IEnumerable<string> Projects => Steps.Select(s => s.Project).Where(p => p.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase);

    /// <summary>Calls from one project into another, in trace order.</summary>
    public IEnumerable<(FlowStep From, FlowStep To)> Transitions
        => Steps.SelectMany(s => s.Edges.Where(e => e.Target is not null && !string.Equals(e.Target.Project, s.Project, StringComparison.OrdinalIgnoreCase)).Select(e => (s, e.Target!)));
}

/// <summary>
/// Traces execution from the scope's entry points through the repository: calls in source order, the receiver's static
/// type to pick the target, DI registrations to go from an interface to its implementation. It stops at framework
/// code, logging, tests and generated code, records databases/HTTP/messages as boundaries, and never guesses between
/// several possible targets (they are reported as ambiguous instead).
/// </summary>
public static partial class FlowTracer
{
    public sealed record Options(int MaxDepth = 8, int MaxSteps = 160, int MaxEntries = 8, int MaxCallsPerStep = 24);

    private static readonly string[] HandlerMethodNames =
        ["Handle", "HandleAsync", "Consume", "ConsumeAsync", "Execute", "ExecuteAsync", "Invoke", "InvokeAsync", "Run", "RunAsync", "Process", "ProcessAsync", "Main", "Receive", "ReceiveAsync", "OnMessage", "OnMessageAsync"];

    private static readonly string[] HandlerTypeSuffixes = ["Handler", "Listener", "Consumer", "Controller", "Job", "Worker", "Subscriber", "Function", "Endpoint", "Processor"];

    public static FlowTrace Trace(AnalysisScope scope, CodeIndex index, ArchitectureModel model, Options? options = null, CancellationToken ct = default)
    {
        options ??= new Options();
        var trace = new FlowTrace { Scope = scope };
        var ctx = new FlowContext(index, new RcaBudget { MaxFiles = 800, MaxDepth = options.MaxDepth, MaxNodes = options.MaxSteps * 4 });
        var visited = new Dictionary<SymbolRecord, FlowStep>(ReferenceEqualityComparer.Instance);
        var registrations = model.Registrations.Where(r => r.ServiceType.Length > 0 && r.ImplementationType.Length > 0)
            .GroupBy(r => CodeIndex.StripGeneric(r.ServiceType), StringComparer.Ordinal).ToDictionary(g => g.Key, g => g.ToList(), StringComparer.Ordinal);
        var dbContexts = model.DbContexts.Select(c => c[(c.LastIndexOf('.') + 1)..]).ToHashSet(StringComparer.Ordinal);

        var unresolved = 0;

        FlowStep Visit(SymbolRecord symbol, int depth, FlowStep? parent, int? callLine, (int From, int To)? window, string? roleOverride)
        {
            ct.ThrowIfCancellationRequested();
            var step = new FlowStep
            {
                Number = trace.Steps.Count + 1, Depth = depth, Symbol = symbol, Parent = parent, CalledFromLine = callLine, Primary = scope.IsPrimary(symbol),
                Role = roleOverride ?? Role(symbol),
            };
            trace.Steps.Add(step);
            if (window is null)
            {
                visited[symbol] = step;
            }
            var flow = ctx.Member(symbol);
            step.Flow = flow;
            step.Description = DocSummary(ctx.File(symbol.File)?.Lines, symbol.StartLine);
            if (flow is null)
            {
                return step;
            }
            var calls = flow.Calls.Where(c => window is null || c.Line >= window.Value.From && c.Line <= window.Value.To).OrderBy(c => c.Line).ToList();
            foreach (var call in calls)
            {
                if (IgnoredCall(call))
                {
                    continue;
                }
                if (step.Edges.Count >= options.MaxCallsPerStep)
                {
                    step.Truncated ??= $"more than {options.MaxCallsPerStep} calls; the rest are not traced";
                    break;
                }
                var (targets, ambiguous) = ctx.ResolveCall(flow, call);
                targets = targets.Where(t => !t.IsTest && !ArchitectureModelBuilder.IsGenerated(t.File) && SymbolKinds.IsCallable(t.Kind)).Distinct().ToList();
                if (!call.IsConstructor && targets.Count > 0 && !ResolvedByType(ctx, flow, call, symbol, targets))
                {
                    // The receiver's type is unknown or outside the repository (a library type, a string, a JSON element):
                    // a repository method that merely shares the name is not a call target.
                    unresolved++;
                    targets = [];
                    ambiguous = false;
                }
                if (call.IsConstructor)
                {
                    if (call.ConstructedType is { } made && ctx.ResolveType(made, symbol).Count > 0 && !step.Creates.Contains(made))
                    {
                        step.Creates.Add(made);
                    }
                    continue;
                }
                var edge = new FlowEdge { Line = call.Line, Call = CallText(call) };
                // Mediator requests and published messages: an unresolved call, or one into an interface the repository
                // does not implement (a bus abstraction), continues in the handlers of the message type.
                var onlyUnimplementedInterface = targets.Count > 0 && targets.All(t => IsInterfaceMember(ctx, t));
                if ((targets.Count == 0 || onlyUnimplementedInterface) && MessageHandlers(ctx, index, flow, call) is { Handlers.Count: > 0 } dispatch)
                {
                    // Mediator requests run in-process; published messages continue in their consumers after an async boundary.
                    foreach (var handler in dispatch.Handlers)
                    {
                        var hop = new FlowEdge { Line = call.Line, Call = edge.Call, Resolution = $"{dispatch.Message} → {handler.Container?[(handler.Container!.LastIndexOf('.') + 1)..]}.{handler.Name} ({dispatch.How})" };
                        if (dispatch.Asynchronous)
                        {
                            hop.Boundary = new FlowBoundary("message", $"{dispatch.Message}", "published message; the consumer runs asynchronously", true);
                        }
                        step.Edges.Add(hop);
                        if (visited.TryGetValue(handler, out var known))
                        {
                            hop.RepeatOf = known;
                        }
                        else if (depth + 1 <= options.MaxDepth && trace.Steps.Count < options.MaxSteps)
                        {
                            hop.Target = Visit(handler, depth + 1, step, call.Line, null, null);
                        }
                    }
                    continue;
                }
                if (targets.Count == 0)
                {
                    if (Classify(ctx, flow, call, dbContexts) is { } boundary)
                    {
                        edge.Boundary = boundary;
                        step.Edges.Add(edge);
                    }
                    continue;
                }

                // Same-named types in several namespaces (one per service version): keep the one the caller's file can
                // see — its namespace chain and using directives, which is how the C# compiler resolves the name.
                var declared = targets.Where(t => IsInterfaceMember(ctx, t)).ToList();
                var visibleDeclared = declared.Where(t => ctx.ContainingType(t) is { } dt && Visible(index, symbol, dt.Namespace)).ToList();
                var interfaceMembers = visibleDeclared.Count > 0 ? visibleDeclared : declared;
                var implementations = targets.Except(declared).ToList();
                if (interfaceMembers.Count == 0)
                {
                    implementations = PreferVisible(ctx, index, symbol, implementations);
                }
                if (interfaceMembers.Count > 0)
                {
                    // An implementation implements the interface it can see (its own namespace chain and usings).
                    var ifaceNamespaces = interfaceMembers.Select(m => ctx.ContainingType(m)?.Namespace).Where(n => n is not null).Distinct().ToList();
                    if (ifaceNamespaces.Count == 1)
                    {
                        var implementing = implementations.Where(m => ctx.ContainingType(m) is { } it && Visible(index, it, ifaceNamespaces[0]!)).ToList();
                        if (implementing.Count > 0)
                        {
                            implementations = implementing;
                        }
                    }
                    var iface = interfaceMembers[0].Container is { } ic ? ic[(ic.LastIndexOf('.') + 1)..] : "";
                    if (registrations.TryGetValue(iface, out var regs))
                    {
                        var registeredNames = regs.Select(r => CodeIndex.StripGeneric(r.ImplementationType)).ToHashSet(StringComparer.Ordinal);
                        var registered = implementations.Where(m => m.Container is { } c && registeredNames.Contains(c[(c.LastIndexOf('.') + 1)..])).ToList();
                        if (registered.Count == 1)
                        {
                            var r = regs.First(x => registered[0].Container!.EndsWith("." + CodeIndex.StripGeneric(x.ImplementationType), StringComparison.Ordinal) || registered[0].Container == CodeIndex.StripGeneric(x.ImplementationType));
                            edge.Resolution = $"{iface} → {CodeIndex.StripGeneric(r.ImplementationType)} (DI {r.Lifetime}, {r.File}:{r.Line})";
                            implementations = registered;
                        }
                    }
                    if (implementations.Count == 0)
                    {
                        edge.Boundary = new FlowBoundary("external", $"{iface}.{call.Callee}", "interface with no implementation in the repository", false);
                        step.Edges.Add(edge);
                        continue;
                    }
                    if (implementations.Count > 1 && edge.Resolution is null && ctx.ContainingType(interfaceMembers[0]) is { } ifaceType)
                    {
                        var closest = implementations.GroupBy(m => SharedNamespaceDepth(ctx.ContainingType(m)?.Namespace ?? "", ifaceType.Namespace)).OrderByDescending(g => g.Key).First();
                        if (closest.Key > 0 && closest.Count() == 1)
                        {
                            var chosen = closest.First();
                            edge.Resolution = $"{iface} → {chosen.Container?[(chosen.Container!.LastIndexOf('.') + 1)..]} (inferred: the only implementation in {ifaceType.Namespace}'s namespace; {implementations.Count} classes implement an interface named {iface})";
                            implementations = [chosen];
                        }
                    }
                    if (implementations.Count == 1 && edge.Resolution is null)
                    {
                        edge.Resolution = $"{iface} → {implementations[0].Container?[(implementations[0].Container!.LastIndexOf('.') + 1)..]} (the only implementation of {ifaceNamespaces.FirstOrDefault()}.{iface} in the repository)";
                    }
                    targets = implementations;
                    ambiguous = implementations.Count > 1;
                }
                else
                {
                    targets = implementations;
                    ambiguous = targets.Count > 1;
                }
                if (targets.Count > 1)
                {
                    // Prefer a target the caller can see: its own type, then the types it holds (fields, constructor).
                    var own = targets.Where(t => t.Container == symbol.Container).ToList();
                    if (own.Count == 1)
                    {
                        targets = own;
                        ambiguous = false;
                    }
                }
                if (targets.Count > 1 || ambiguous && targets.Count != 1)
                {
                    edge.Candidates.AddRange(targets.Select(t => $"{t.Container ?? t.File}.{t.Name}").Distinct().Take(8));
                    step.Edges.Add(edge);
                    trace.Ambiguities.Add($"{step.Display} (line {call.Line}) calls {edge.Call}: {targets.Count} possible targets ({string.Join(", ", edge.Candidates)}); static analysis cannot choose, so this branch is not followed.");
                    continue;
                }
                var target = targets[0];
                if (ReferenceEquals(target, symbol))
                {
                    edge.RepeatOf = step;
                    step.Edges.Add(edge);
                    continue;
                }
                if (visited.TryGetValue(target, out var seen))
                {
                    edge.RepeatOf = seen;
                    step.Edges.Add(edge);
                    continue;
                }
                if (depth + 1 > options.MaxDepth)
                {
                    step.Truncated = $"depth limit {options.MaxDepth} reached; {edge.Call} and deeper calls are not traced";
                    step.Edges.Add(edge);
                    continue;
                }
                if (trace.Steps.Count >= options.MaxSteps)
                {
                    step.Truncated = $"trace size limit ({options.MaxSteps} steps) reached";
                    step.Edges.Add(edge);
                    if (!trace.Limits.Contains(step.Truncated)) trace.Limits.Add(step.Truncated);
                    continue;
                }
                step.Edges.Add(edge);
                edge.Target = Visit(target, depth + 1, step, call.Line, null, null);
            }
            return step;
        }

        // With a real entry (endpoint, handler, requested method), public methods nobody in the scope calls are not
        // separate entry points — they are usually reached through interfaces from that entry's flow.
        var entries = EntryPoints(scope, index, model, ctx).ToList();
        if (scope.Kind != "class" && entries.Any(e => e.Kind is "endpoint" or "handler" or "requested"))
        {
            entries = entries.Where(e => e.Kind != "public").ToList();
        }
        foreach (var (symbol, kind, description, window) in entries.Take(options.MaxEntries))
        {
            if (window is null && visited.TryGetValue(symbol, out _))
            {
                continue; // Already traced as part of an earlier entry's flow.
            }
            var root = Visit(symbol, 0, null, null, window, kind == "endpoint" ? $"Entry: {description}" : kind == "handler" ? $"Entry: {Role(symbol)}" : null);
            trace.Entries.Add(new FlowEntry { Kind = kind, Description = description, Root = root });
        }
        if (unresolved > 0)
        {
            trace.Limits.Add($"{unresolved} calls on receivers whose type is outside the repository or could not be determined were not followed (a repository method with the same name is not evidence of a call).");
        }
        var allEntries = entries.Count;
        if (allEntries > options.MaxEntries)
        {
            trace.Limits.Add($"{allEntries} entry points found; the first {options.MaxEntries} are traced.");
        }

        // Upstream: who calls the requested class/method from outside the scope (by name — an orientation, not proof).
        if (scope.Kind is "class" or "method")
        {
            var names = trace.Entries.Select(e => e.Root.Symbol.Name).Distinct();
            foreach (var name in names)
            {
                foreach (var caller in index.CallersByName(name).Where(c => !c.IsTest && !scope.IsPrimary(c) && !ArchitectureModelBuilder.IsGenerated(c.File)).Take(10))
                {
                    trace.Upstream.Add((caller, name));
                }
            }
        }
        return trace;
    }

    /// <summary>Where execution can enter the scope, strongest first.</summary>
    private static IEnumerable<(SymbolRecord Symbol, string Kind, string Description, (int, int)? Window)> EntryPoints(AnalysisScope scope, CodeIndex index, ArchitectureModel model, FlowContext ctx)
    {
        var seen = new HashSet<SymbolRecord>(ReferenceEqualityComparer.Instance);
        var primaryMethods = scope.Methods.Concat(scope.Types.SelectMany(t => index.MembersOf(t.FullName).Where(m => SymbolKinds.IsCallable(m.Kind))))
            .Where(m => m.Kind is not (SymbolKinds.Property or SymbolKinds.Indexer)).Distinct().ToList();

        // 1. HTTP endpoints handled in the scope.
        foreach (var e in model.Endpoints.OrderBy(e => e.File, StringComparer.Ordinal).ThenBy(e => e.Line))
        {
            if (e.Style == "controller")
            {
                var handler = primaryMethods.FirstOrDefault(m => m.FullName == e.Handler);
                if (handler is not null && seen.Add(handler))
                {
                    yield return (handler, "endpoint", $"{e.Verb} {e.Route}", null);
                }
                continue;
            }
            if (!scope.Files.Contains(e.File) && !primaryMethods.Any(m => m.File == e.File && m.StartLine <= e.Line && e.Line <= m.EndLine))
            {
                continue;
            }
            // Minimal API: the calls on the mapping's lines (up to the next mapping).
            var member = ctx.MemberAt(e.File, e.Line)?.Symbol;
            if (member is null)
            {
                continue;
            }
            var next = model.Endpoints.Where(o => o.File == e.File && o.Line > e.Line).Select(o => o.Line).DefaultIfEmpty(e.Line + 25).Min();
            yield return (member, "endpoint", $"{e.Verb} {e.Route}", (e.Line, Math.Min(next - 1, e.Line + 25)));
        }

        // 2. Handlers, listeners, consumers, jobs and requested methods.
        var calledInside = new HashSet<string>(primaryMethods.SelectMany(m => m.Calls), StringComparer.Ordinal);
        var ranked = primaryMethods.Where(m => m.Kind is SymbolKinds.Method or SymbolKinds.TopLevel && !m.IsTest)
            .Select(m => (Symbol: m, Rank: Rank(m, scope, calledInside)))
            .Where(x => x.Rank > 0)
            .OrderByDescending(x => x.Rank).ThenBy(x => x.Symbol.File, StringComparer.Ordinal).ThenBy(x => x.Symbol.StartLine);
        foreach (var (m, rank) in ranked)
        {
            if (seen.Add(m))
            {
                yield return (m, rank >= 80 ? "handler" : scope.Kind == "method" ? "requested" : "public", rank >= 80 ? Role(m) : scope.Kind == "method" ? "requested method" : "public operation not called from inside the scope", null);
            }
        }
    }

    private static int Rank(SymbolRecord m, AnalysisScope scope, HashSet<string> calledInside)
    {
        if (scope.Kind == "method")
        {
            return scope.Methods.Contains(m) ? 90 : 0;
        }
        var type = m.Container is { } c ? c[(c.LastIndexOf('.') + 1)..] : "";
        var isPublic = m.Modifiers.Contains("public") || m.Modifiers.Contains("internal") || m.Kind == SymbolKinds.TopLevel;
        if (m.Kind == SymbolKinds.TopLevel || m.Name == "Main") return 85;
        if (isPublic && HandlerMethodNames.Contains(m.Name) || m.Modifiers.Contains("override") && m.Name is "ExecuteAsync" or "Handle" or "HandleAsync") return 90;
        if (isPublic && HandlerTypeSuffixes.Any(s => type.EndsWith(s, StringComparison.Ordinal))) return 80;
        if (isPublic && !calledInside.Contains(m.Name)) return scope.Kind == "class" ? 60 : 40;
        return 0;
    }

    private sealed record Dispatch(string Message, string How, bool Asynchronous, List<SymbolRecord> Handlers);

    private static readonly Regex HandlerBase = new(@"^I?(RequestHandler|NotificationHandler|CommandHandler|QueryHandler|EventHandler|MessageHandler|Consumer|Handler|Handles|Subscriber)$", RegexOptions.Compiled);

    /// <summary>
    /// Send/Publish of a message type handled in the repository: MediatR-style requests (IRequestHandler&lt;X&gt;) run
    /// in-process; bus publishes (IConsumer&lt;X&gt;, IHandleMessages&lt;X&gt;…) run asynchronously in the consumer.
    /// </summary>
    private static Dispatch? MessageHandlers(FlowContext ctx, CodeIndex index, MemberFlow flow, FlowCall call)
    {
        if (call.Args.Count == 0 || !(call.Callee.StartsWith("Send", StringComparison.Ordinal) || call.Callee.StartsWith("Publish", StringComparison.Ordinal)
                                       || call.Callee.StartsWith("Dispatch", StringComparison.Ordinal) || call.Callee.StartsWith("Produce", StringComparison.Ordinal)))
        {
            return null;
        }
        var arg = call.Args[0].Tokens;
        string? message = null;
        var newIndex = arg.FindIndex(t => t.Is("new"));
        if (newIndex >= 0 && newIndex + 1 < arg.Count && arg[newIndex + 1].Kind == DocGen.Analysis.CSharp.TokenKind.Identifier)
        {
            message = arg[newIndex + 1].Text;
        }
        else
        {
            try
            {
                message = ctx.ExpressionType(flow, arg, call.Line) is { } t ? FlowContext.BareName(t) : null;
            }
            catch (Exception ex) when (ex is ArgumentException or InvalidOperationException or IndexOutOfRangeException)
            {
            }
        }
        message ??= call.TypeArgs.FirstOrDefault();
        if (message is null || ctx.ResolveType(message, flow.Symbol).Count == 0)
        {
            return null;
        }
        var handlers = new List<SymbolRecord>();
        var viaBus = false;
        // The index keeps base names without generic arguments; the type's flow has them ("IConsumer" → "OrderPlacedEvent").
        foreach (var type in index.Types.Where(t => !t.IsTest && t.Bases.Any(b => HandlerBase.IsMatch(CodeIndex.StripGeneric(b)))))
        {
            var arguments = ctx.TypeFlowOf(type)?.BaseTypeArguments;
            foreach (var b in type.Bases.Select(CodeIndex.StripGeneric).Where(b => HandlerBase.IsMatch(b)))
            {
                var handled = arguments is not null && arguments.TryGetValue(b, out var args) ? args.Split(',')[0].Trim() : null;
                if (handled is null || FlowContext.BareName(handled) != message)
                {
                    continue;
                }
                viaBus |= b.Contains("Consumer", StringComparison.Ordinal) || b.Contains("HandleMessages", StringComparison.Ordinal) || b.Contains("Subscriber", StringComparison.Ordinal);
                handlers.AddRange(index.MembersOf(type.FullName).Where(m => m.Kind == SymbolKinds.Method && m.Name is "Handle" or "HandleAsync" or "Consume" or "ConsumeAsync" or "Execute" or "ExecuteAsync" or "Process" or "ProcessAsync"));
            }
        }
        if (handlers.Count == 0)
        {
            return null;
        }
        var mediator = !viaBus && !MessageType().IsMatch(call.ReceiverText);
        return new Dispatch(message, mediator ? "in-process handler" : "message consumer", !mediator, handlers.Distinct().Take(6).ToList());
    }

    /// <summary>The text of the /// &lt;summary&gt; just above a declaration (attributes skipped), tags reduced to their names.</summary>
    public static string DocSummary(string[]? lines, int startLine)
    {
        if (lines is null || startLine < 2)
        {
            return "";
        }
        var doc = new List<string>();
        for (var i = Math.Min(startLine - 2, lines.Length - 1); i >= 0; i--)
        {
            var t = lines[i].Trim();
            if (t.StartsWith("///", StringComparison.Ordinal))
            {
                doc.Insert(0, t[3..].Trim());
            }
            else if (t.StartsWith('[') || t.Length == 0 && doc.Count == 0)
            {
                continue;
            }
            else
            {
                break;
            }
        }
        var text = string.Join(' ', doc);
        var m = Regex.Match(text, "<summary>(.*?)</summary>", RegexOptions.Singleline);
        if (!m.Success)
        {
            return "";
        }
        var summary = Regex.Replace(m.Groups[1].Value, @"<(?:see|seealso)\s+(?:cref|langword|href)=""(?:[A-Z]:)?([^""]+)""\s*/>", "$1");
        summary = Regex.Replace(summary, @"<(?:paramref|typeparamref)\s+name=""([^""]+)""\s*/>", "$1");
        summary = Regex.Replace(Regex.Replace(summary, "<[^>]+>", ""), @"\s+", " ").Trim();
        return summary.Length > 220 ? summary[..219] + "…" : summary;
    }

    private static readonly Dictionary<string, HashSet<string>> VisibleCache = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>
    /// Whether code in <paramref name="from"/> sees types of namespace <paramref name="ns"/> by simple name: the
    /// declaring namespace and its parents, and the file's using directives.
    /// </summary>
    private static bool Visible(CodeIndex index, SymbolRecord from, string ns)
    {
        if (ns.Length == 0)
        {
            return true;
        }
        var key = from.File + "|" + from.Namespace;
        HashSet<string> visible;
        lock (VisibleCache)
        {
            if (!VisibleCache.TryGetValue(key, out visible!))
            {
                visible = new HashSet<string>(StringComparer.Ordinal);
                var parts = from.Namespace.Split('.', StringSplitOptions.RemoveEmptyEntries);
                for (var i = parts.Length; i > 0; i--)
                {
                    visible.Add(string.Join('.', parts.Take(i)));
                }
                if (index.Files.TryGetValue(from.File, out var file))
                {
                    foreach (var u in file.Usings.Where(u => !u.Contains('=') && !u.StartsWith("static", StringComparison.Ordinal)))
                    {
                        visible.Add(u.TrimEnd(';'));
                    }
                }
                if (VisibleCache.Count > 20000) VisibleCache.Clear();
                VisibleCache[key] = visible;
            }
        }
        return visible.Contains(ns);
    }

    /// <summary>Among members of same-named classes in different namespaces, those whose class the caller can see (all when none is).</summary>
    private static List<SymbolRecord> PreferVisible(FlowContext ctx, CodeIndex index, SymbolRecord caller, List<SymbolRecord> targets)
    {
        var result = new List<SymbolRecord>();
        foreach (var group in targets.GroupBy(t => t.Container is { } c ? c[(c.LastIndexOf('.') + 1)..] : t.File))
        {
            var members = group.ToList();
            if (members.Select(m => m.Container).Distinct().Count() > 1)
            {
                var visible = members.Where(m => ctx.ContainingType(m) is { } t && Visible(index, caller, t.Namespace)).ToList();
                result.AddRange(visible.Count > 0 ? visible : members);
            }
            else
            {
                result.AddRange(members);
            }
        }
        return result;
    }

    /// <summary>How close an implementation's namespace <paramref name="a"/> is to the interface's <paramref name="b"/> (0 = unrelated).</summary>
    private static int SharedNamespaceDepth(string a, string b)
    {
        // Shared leading segments, minus the implementation's extra ones: the same namespace scores highest,
        // "…Ordering" beats "…Ordering.V2" for an interface in "…Ordering".
        var x = a.Split('.');
        var y = b.Split('.');
        var n = 0;
        while (n < x.Length && n < y.Length && x[n] == y[n]) n++;
        return n == 0 ? 0 : 2 * n - (x.Length - n);
    }

    /// <summary>
    /// Whether the targets were found through the caller's own type (and its bases) or the receiver's known type — not
    /// by name alone. A static call on a repository type counts; a call on a library type, an unknown local or a
    /// string does not.
    /// </summary>
    private static bool ResolvedByType(FlowContext ctx, MemberFlow flow, FlowCall call, SymbolRecord caller, List<SymbolRecord> targets)
    {
        if (call.Receiver.Count == 0 || call.Receiver.Count == 1 && call.Receiver[0].Is("this") || call.Receiver.Count == 1 && call.Receiver[0].Is("base"))
        {
            return ctx.ContainingType(caller) is { } own && ctx.MembersNamed(own, call.Callee).Intersect(targets).Any();
        }
        try
        {
            if (ctx.ExpressionType(flow, call.Receiver, call.Line) is { } type)
            {
                return ctx.ResolveType(type, caller).Count > 0;
            }
        }
        catch (Exception ex) when (ex is ArgumentException or InvalidOperationException or IndexOutOfRangeException)
        {
        }
        return call.Receiver.Count == 1 && ctx.ResolveType(call.Receiver[0].Text, caller).Count > 0; // static call on a repository type
    }

    private static bool IsInterfaceMember(FlowContext ctx, SymbolRecord member) => ctx.ContainingType(member)?.Kind == SymbolKinds.Interface;

    /// <summary>Calls that are never architecture: logging, string/format helpers, guards, nameof, LINQ over in-memory data.</summary>
    private static bool IgnoredCall(FlowCall call)
    {
        var receiver = call.ReceiverText;
        if (call.Callee is "nameof" or "typeof" or "ToString" or "Equals" or "GetHashCode" or "GetType" or "ConfigureAwait" or "ThrowIfCancellationRequested" or "Dispose" or "DisposeAsync")
        {
            return true;
        }
        if (call.Callee.StartsWith("Log", StringComparison.Ordinal) && (receiver.Contains("log", StringComparison.OrdinalIgnoreCase) || receiver.Length == 0))
        {
            return true;
        }
        return receiver is "string" or "String" or "Math" or "Convert" or "Guid" or "DateTime" or "DateTimeOffset" or "TimeSpan" or "ArgumentNullException" or "ArgumentException"
            or "ObjectDisposedException" or "Enumerable" or "Task" or "Regex" or "StringComparer" or "Console" or "Debug" or "Trace" or "Interlocked" or "Volatile";
    }

    /// <summary>A call into something outside the repository that matters for architecture, or null.</summary>
    private static FlowBoundary? Classify(FlowContext ctx, MemberFlow flow, FlowCall call, HashSet<string> dbContexts)
    {
        var receiver = call.ReceiverText;
        string? type = null;
        try
        {
            type = call.Receiver.Count > 0 ? ctx.ExpressionType(flow, call.Receiver, call.Line) : null;
        }
        catch (Exception ex) when (ex is ArgumentException or InvalidOperationException or IndexOutOfRangeException)
        {
        }
        var bare = type is null ? "" : FlowContext.BareName(type);
        var name = $"{(bare.Length > 0 ? bare : receiver)}.{call.Callee}";
        if (DatabaseType().IsMatch(bare) || dbContexts.Contains(bare) || call.Callee is "SaveChanges" or "SaveChangesAsync" or "ExecuteSqlRaw" or "ExecuteSqlRawAsync" or "ExecuteSqlInterpolated" or "ExecuteSqlInterpolatedAsync" or "FromSqlRaw" or "FromSqlInterpolated"
            || call.Callee is "QueryAsync" or "QueryFirstOrDefaultAsync" or "QuerySingleAsync" or "ExecuteAsync" or "ExecuteScalarAsync" or "ExecuteReaderAsync" or "ExecuteNonQueryAsync" && DatabaseType().IsMatch(receiver))
        {
            var entity = type is not null ? FlowContext.GenericArgument(type) : null;
            return new FlowBoundary("database", name, entity is not null && bare.StartsWith("DbSet", StringComparison.Ordinal) ? $"entity set of {entity}" : bare.Length > 0 ? bare : "database access", false);
        }
        if (HttpType().IsMatch(bare) || HttpType().IsMatch(receiver) && call.Callee.EndsWith("Async", StringComparison.Ordinal))
        {
            return new FlowBoundary("http", name, "outbound HTTP call", false);
        }
        if (MessageType().IsMatch(bare) || MessageType().IsMatch(receiver) && call.Callee.StartsWith("Publish", StringComparison.Ordinal) || call.Callee.StartsWith("Send", StringComparison.Ordinal) && MessageType().IsMatch(receiver))
        {
            var publish = call.Callee.StartsWith("Publish", StringComparison.Ordinal) || call.Callee.StartsWith("Produce", StringComparison.Ordinal) || call.Callee.StartsWith("Enqueue", StringComparison.Ordinal) || call.Callee.StartsWith("Send", StringComparison.Ordinal);
            return new FlowBoundary("message", name, publish ? "publishes a message (asynchronous boundary)" : "messaging call", publish);
        }
        if (receiver is "File" or "Directory" or "Path" && call.Callee is not ("Combine" or "GetFileName" or "GetExtension" or "GetFileNameWithoutExtension" or "GetDirectoryName" or "GetFullPath" or "GetRelativePath" or "IsPathRooted" or "IsPathFullyQualified" or "GetTempPath")
            || bare is "FileStream" or "StreamWriter" or "StreamReader")
        {
            return new FlowBoundary("file", name, "file system", false);
        }
        if (receiver == "Process" && call.Callee == "Start" || bare == "Process" && call.Callee is "Start" or "WaitForExitAsync")
        {
            return new FlowBoundary("process", name, "starts an external process", false);
        }
        return null;
    }

    private static string CallText(FlowCall call)
    {
        var receiver = Expr.Render(call.Receiver.SkipWhile(t => t.IsPunct('!') || t.Is("await")).ToList());
        if (receiver.Length > 40)
        {
            receiver = "…" + receiver[^38..];
        }
        return receiver.Length > 0 ? $"{receiver}.{call.Callee}" : call.Callee;
    }

    /// <summary>The part a step plays, from its declaring type's and its own name (inferred, and labelled so).</summary>
    public static string Role(SymbolRecord m)
    {
        var type = m.Container is { } c ? c[(c.LastIndexOf('.') + 1)..] : "";
        if (m.Kind == SymbolKinds.TopLevel) return "Application startup / top-level statements";
        if (m.Name.StartsWith("Validat", StringComparison.Ordinal) || type.EndsWith("Validator", StringComparison.Ordinal)) return "Validation";
        if (type.EndsWith("Controller", StringComparison.Ordinal)) return "HTTP controller action";
        if (type.EndsWith("Middleware", StringComparison.Ordinal)) return "HTTP middleware";
        if (HandlerTypeSuffixes.Take(3).Any(s => type.EndsWith(s, StringComparison.Ordinal)) || type.EndsWith("Subscriber", StringComparison.Ordinal)) return "Request/message handler";
        if (type.EndsWith("Job", StringComparison.Ordinal) || type.EndsWith("Worker", StringComparison.Ordinal) || m.Name == "ExecuteAsync" && m.Modifiers.Contains("override")) return "Background job";
        if (Regex.IsMatch(type, "(Repository|Store|Dao|DbContext|Context)$")) return "Data access";
        if (Regex.IsMatch(type, "(Client|Gateway|Proxy|Adapter|Connector|Api)$")) return "Integration client";
        if (Regex.IsMatch(type, "(Mapper|Converter|Factory|Builder|Serializer|Parser)$")) return "Mapping / construction";
        if (Regex.IsMatch(type, "(Service|Manager|Orchestrator|Coordinator|Engine|Processor|Workflow|UseCase|Command|Query)$")) return "Application / business logic";
        return m.Modifiers.Contains("private") || !m.Modifiers.Any(x => x is "public" or "internal" or "protected") ? "Internal helper" : "Operation";
    }

    [GeneratedRegex("^(I?DbContext|DbSet|I?DbConnection|SqlConnection|SqlCommand|NpgsqlConnection|NpgsqlCommand|MySqlConnection|SqliteConnection|SqliteCommand|IMongoCollection|IMongoDatabase|IDatabase|CosmosClient|Container|IDocumentSession|ISession|IQueryable)$|DbContext$")]
    private static partial Regex DatabaseType();

    [GeneratedRegex("^(HttpClient|IHttpClientFactory|RestClient|IRestClient|GrpcChannel|HttpMessageInvoker)$|(^_?[hH]ttp[A-Za-z]*[cC]lient$)")]
    private static partial Regex HttpType();

    [GeneratedRegex("(Bus|Publisher|Producer|ServiceBus|Kafka|Rabbit|MessageQueue|QueueClient|TopicClient|EventHub|MessageBroker|MessageSender|IPublishEndpoint|ISendEndpoint)", RegexOptions.IgnoreCase)]
    private static partial Regex MessageType();
}
