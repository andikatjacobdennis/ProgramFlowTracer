using System.Globalization;
using System.Text.RegularExpressions;

namespace DocGen.Analysis.Diagnostics;

public sealed class BuildDiagnostic
{
    /// <summary>error | warning</summary>
    public string Severity { get; set; } = "";

    public string Code { get; set; } = "";
    public string Message { get; set; } = "";
    public string? File { get; set; }
    public int? Line { get; set; }
    public int? Column { get; set; }
    public string? Project { get; set; }

    /// <summary>How many times the identical diagnostic appeared (MSBuild repeats them per target framework / summary).</summary>
    public int Occurrences { get; set; } = 1;
}

public sealed class BuildReport
{
    /// <summary>succeeded | failed | unknown</summary>
    public string Result { get; set; } = "unknown";

    public int ErrorCount { get; set; }
    public int WarningCount { get; set; }
    public List<BuildDiagnostic> Errors { get; set; } = [];
    public List<BuildDiagnostic> Warnings { get; set; } = [];
    public double? DurationSeconds { get; set; }
    public List<string> ProjectsBuilt { get; set; } = [];
    public List<string> RestoreProblems { get; set; } = [];
}

/// <summary>Parses MSBuild / dotnet build console output (errors, warnings, codes, locations, projects, duration).</summary>
public static partial class BuildOutputAnalyzer
{
    public static BuildReport Parse(IEnumerable<string> lines, int maxDiagnostics = 200)
    {
        var report = new BuildReport();
        var seen = new Dictionary<string, BuildDiagnostic>(StringComparer.Ordinal);
        foreach (var raw in lines)
        {
            var line = raw.TrimEnd('\r');
            var match = DiagnosticPattern().Match(line);
            if (match.Success)
            {
                var diagnostic = new BuildDiagnostic
                {
                    Severity = match.Groups["severity"].Value.ToLowerInvariant(),
                    Code = match.Groups["code"].Value,
                    Message = match.Groups["message"].Value.Trim(),
                    File = match.Groups["file"].Success ? match.Groups["file"].Value.Trim() : null,
                    Line = int.TryParse(match.Groups["line"].Value, out var l) ? l : null,
                    Column = int.TryParse(match.Groups["col"].Value, out var c) ? c : null,
                    Project = match.Groups["project"].Success ? Path.GetFileNameWithoutExtension(match.Groups["project"].Value.Trim()) : null,
                };
                var key = $"{diagnostic.Severity}|{diagnostic.Code}|{diagnostic.File}|{diagnostic.Line}|{diagnostic.Column}|{diagnostic.Message}";
                if (seen.TryGetValue(key, out var existing))
                {
                    existing.Occurrences++;
                    continue;
                }
                seen[key] = diagnostic;
                var target = diagnostic.Severity == "error" ? report.Errors : report.Warnings;
                if (target.Count < maxDiagnostics)
                {
                    target.Add(diagnostic);
                }
                if (diagnostic.Code.StartsWith("NU1", StringComparison.Ordinal))
                {
                    report.RestoreProblems.Add($"{diagnostic.Code}: {diagnostic.Message}");
                }
                continue;
            }
            var built = BuiltProject().Match(line);
            if (built.Success)
            {
                report.ProjectsBuilt.Add(built.Groups["name"].Value);
                continue;
            }
            if (line.Contains("Build succeeded", StringComparison.OrdinalIgnoreCase))
            {
                report.Result = "succeeded";
            }
            else if (line.Contains("Build FAILED", StringComparison.Ordinal) || line.Contains("build failed", StringComparison.OrdinalIgnoreCase))
            {
                report.Result = "failed";
            }
            var elapsed = Elapsed().Match(line);
            if (elapsed.Success && TimeSpan.TryParse(elapsed.Groups["t"].Value, CultureInfo.InvariantCulture, out var span))
            {
                report.DurationSeconds = span.TotalSeconds;
            }
        }
        report.ErrorCount = seen.Values.Count(d => d.Severity == "error");
        report.WarningCount = seen.Values.Count(d => d.Severity == "warning");
        if (report.Result == "unknown" && report.ErrorCount > 0)
        {
            report.Result = "failed";
        }
        return report;
    }

    // "C:\src\Foo.cs(12,5): error CS0103: The name 'x' does not exist [C:\src\Foo.csproj]" or "error NU1101: ..." (no file).
    [GeneratedRegex(@"^\s*(?:(?<file>[^(:]*?(?::[\\/][^(]*?)?)\((?<line>\d+)(?:,(?<col>\d+))?(?:,\d+,\d+)?\)\s*:\s*|(?<file2>.+?)\s+:\s+)?(?<severity>error|warning)\s+(?<code>[A-Z]{1,6}\d{3,6})\s*:\s*(?<message>.*?)(?:\s+\[(?<project>[^\]]+)\])?\s*$", RegexOptions.IgnoreCase)]
    private static partial Regex DiagnosticPattern();

    [GeneratedRegex(@"^\s*(?<name>[\w.\-]+)\s+->\s+.+\.(dll|exe)\s*$")]
    private static partial Regex BuiltProject();

    [GeneratedRegex(@"Time Elapsed\s+(?<t>\d{1,2}:\d{2}:\d{2}(?:\.\d+)?)")]
    private static partial Regex Elapsed();
}

public sealed class TestFailure
{
    public string Name { get; set; } = "";
    public string? Message { get; set; }
    public string? StackTrace { get; set; }
    public string? ExceptionType { get; set; }
    public string? TopApplicationFrame { get; set; }
    public string? File { get; set; }
    public int? Line { get; set; }

    /// <summary>
    /// The test threw an ordinary exception from its own code (its setup: inputs, data, moves) instead of failing an
    /// assertion. Such a failure says the test is wrong or incomplete; it does not show the behaviour the test was
    /// written to demonstrate.
    /// </summary>
    public bool FailedInOwnCode
    {
        get
        {
            if (IsAssertion(ExceptionType) || TopApplicationFrame is null)
            {
                return false;
            }
            var method = Name[(Name.LastIndexOf('.') + 1)..];
            return method.Length > 0 && TopApplicationFrame.Contains(method, StringComparison.Ordinal);
        }
    }

    private static bool IsAssertion(string? type)
        => string.IsNullOrWhiteSpace(type) || type.StartsWith('(')
           || type.Contains("Assert", StringComparison.OrdinalIgnoreCase)
           || type.StartsWith("Xunit.Sdk.", StringComparison.Ordinal) || type.Contains("XunitException", StringComparison.Ordinal)
           || type.Contains("Shouldly", StringComparison.Ordinal) || type.Contains("FluentAssertions", StringComparison.Ordinal);

    /// <summary>
    /// A note for failures that happened in the tests' own code, or null. Writing a failing test first proves a bug only
    /// when the test fails for the reason it was written for; an exception in its setup sends debugging the wrong way.
    /// </summary>
    public static string? WrongReasonNote(IEnumerable<TestFailure> failures)
    {
        var own = failures.Where(f => f.FailedInOwnCode).ToList();
        if (own.Count == 0)
        {
            return null;
        }
        var first = own[0];
        return $"Note: {own.Count} test(s) failed with {first.ExceptionType} thrown in the test's own code ({first.Name[(first.Name.LastIndexOf('.') + 1)..]}" +
               $"{(first.Line is { } line ? $" line {line}" : "")}), not at an assertion. Such a failure does not show the behaviour under test: " +
               "check the test's own setup (inputs, data, moves, expected values) against the domain rules before changing product code. If the setup " +
               "is hard to get right, test closer to the fix: call the function you are changing with a constructed input.";
    }
}

public sealed class TestReport
{
    public int? Passed { get; set; }
    public int? Failed { get; set; }
    public int? Skipped { get; set; }
    public int? Total { get; set; }
    public List<TestFailure> Failures { get; set; } = [];

    /// <summary>passed | failed | build-failed | unknown</summary>
    public string Result { get; set; } = "unknown";

    public BuildReport? Build { get; set; }
}

/// <summary>
/// Parses `dotnet test` console output (VSTest and Microsoft.Testing.Platform styles): failed test names, messages,
/// stack traces and the pass/fail summary. Stack traces are analysed with <see cref="StackTraceAnalyzer"/>.
/// </summary>
public static partial class TestOutputAnalyzer
{
    public static TestReport Parse(IReadOnlyList<string> lines, int maxFailures = 100)
    {
        var report = new TestReport();
        TestFailure? current = null;
        string? section = null;
        var message = new List<string>();
        var stack = new List<string>();

        void Flush()
        {
            if (current is null)
            {
                return;
            }
            current.Message = message.Count > 0 ? string.Join("\n", message).Trim() : current.Message;
            current.StackTrace = stack.Count > 0 ? string.Join("\n", stack) : null;
            var trace = StackTraceAnalyzer.Parse((current.Message ?? "") + "\n" + (current.StackTrace ?? ""));
            current.ExceptionType ??= trace.Root?.Type is { } t && t != "(unknown)" ? t : null;
            var frame = trace.Exceptions.OrderByDescending(e => e.Depth).SelectMany(e => e.Frames)
                .FirstOrDefault(f => !f.IsFramework && f.File is not null);
            if (frame is not null)
            {
                current.TopApplicationFrame = frame.Type + "." + frame.MemberName;
                current.File = frame.File;
                current.Line = frame.Line;
            }
            if (report.Failures.Count < maxFailures)
            {
                report.Failures.Add(current);
            }
            current = null;
            message.Clear();
            stack.Clear();
            section = null;
        }

        foreach (var raw in lines)
        {
            var line = raw.TrimEnd('\r');
            var failed = FailedTest().Match(line);
            if (failed.Success)
            {
                Flush();
                current = new TestFailure { Name = failed.Groups["name"].Value.Trim() };
                section = "message";
                continue;
            }
            var summary = Summary().Match(line);
            if (summary.Success)
            {
                Flush();
                report.Failed = Int(summary.Groups["failed"].Value);
                report.Passed = Int(summary.Groups["passed"].Value);
                report.Skipped = Int(summary.Groups["skipped"].Value);
                report.Total = Int(summary.Groups["total"].Value);
                continue;
            }
            var mtp = MtpSummary().Match(line);
            if (mtp.Success)
            {
                Flush();
                report.Total = Int(mtp.Groups["total"].Value);
                report.Failed = Int(mtp.Groups["failed"].Value);
                report.Passed = Int(mtp.Groups["passed"].Value);
                report.Skipped = Int(mtp.Groups["skipped"].Value);
                continue;
            }
            var multi = MultiLineSummary().Match(line);
            if (multi.Success)
            {
                // "Total tests: 2" / "Passed: 1" / "Failed: 1" / "Skipped: 0" (console logger, normal verbosity).
                Flush();
                var value = Int(multi.Groups["n"].Value);
                switch (multi.Groups["k"].Value)
                {
                    case "Total tests":
                        report.Total = value;
                        break;
                    case "Passed":
                        report.Passed = value;
                        break;
                    case "Failed":
                        report.Failed = value;
                        break;
                    case "Skipped":
                        report.Skipped = value;
                        break;
                }
                continue;
            }
            if (current is null)
            {
                continue;
            }
            var trimmed = line.Trim();
            if (FullName().Match(trimmed) is { Success: true } fullName && !current.Name.Contains('.'))
            {
                // Display names are often just the method name; the message carries the fully qualified one.
                current.Name = fullName.Groups["name"].Value;
            }
            if (trimmed.StartsWith("Error Message:", StringComparison.Ordinal))
            {
                section = "message";
                var rest = trimmed["Error Message:".Length..].Trim();
                if (rest.Length > 0)
                {
                    message.Add(rest);
                }
                continue;
            }
            if (trimmed.StartsWith("Stack Trace:", StringComparison.Ordinal))
            {
                section = "stack";
                continue;
            }
            if (trimmed.StartsWith("Standard Output Messages:", StringComparison.Ordinal) || trimmed.StartsWith("Standard Error Messages:", StringComparison.Ordinal))
            {
                section = "output";
                continue;
            }
            if (trimmed.StartsWith("Passed ", StringComparison.Ordinal) || trimmed.StartsWith("Skipped ", StringComparison.Ordinal) || PassedMtp().IsMatch(trimmed))
            {
                Flush();
                continue;
            }
            if (trimmed.StartsWith("at ", StringComparison.Ordinal))
            {
                section = "stack";
            }
            if (section == "message" && message.Count < 60 && trimmed.Length > 0)
            {
                message.Add(trimmed);
            }
            else if (section == "stack" && stack.Count < 200 && trimmed.Length > 0)
            {
                stack.Add(trimmed);
            }
        }
        Flush();

        var build = BuildOutputAnalyzer.Parse(lines);
        if (build.ErrorCount > 0)
        {
            report.Build = build;
        }
        report.Result = report.Failures.Count > 0 || report.Failed > 0 ? "failed"
            : build.ErrorCount > 0 && report.Total is null ? "build-failed"
            : report.Total is not null || report.Passed is not null ? "passed" : "unknown";
        return report;
    }

    private static int? Int(string value) => int.TryParse(value, out var v) ? v : null;

    [GeneratedRegex(@"^\s*(?<k>Total tests|Passed|Failed|Skipped):\s*(?<n>\d+)\s*$")]
    private static partial Regex MultiLineSummary();

    [GeneratedRegex(@"^Test method (?<name>[\w.`+]+) threw exception")]
    private static partial Regex FullName();

    // VSTest: "  Failed Namespace.Class.Method [12 ms]"   MTP: "failed Namespace.Class.Method (12ms)"
    [GeneratedRegex(@"^\s*(?:Failed|failed|X)\s+(?<name>[\w.`<>\[\]\(\),"" =-]+?)\s*(?:\[[^\]]*\]|\([\d.,]+\s*m?s\))?\s*$")]
    private static partial Regex FailedTest();

    [GeneratedRegex(@"^\s*(?:Passed|passed)\s+[\w.]+")]
    private static partial Regex PassedMtp();

    // "Failed!  - Failed:     1, Passed:    10, Skipped:     0, Total:    11, Duration: ..." / "Passed!  - ..."
    [GeneratedRegex(@"(?:Failed|Passed)!\s*-\s*Failed:\s*(?<failed>\d+),\s*Passed:\s*(?<passed>\d+),\s*Skipped:\s*(?<skipped>\d+),\s*Total:\s*(?<total>\d+)")]
    private static partial Regex Summary();

    // MTP: "Test run summary: Failed! ... total: 11 failed: 1 succeeded: 10 skipped: 0"
    [GeneratedRegex(@"total:\s*(?<total>\d+)\s+failed:\s*(?<failed>\d+)\s+succeeded:\s*(?<passed>\d+)\s+skipped:\s*(?<skipped>\d+)", RegexOptions.IgnoreCase)]
    private static partial Regex MtpSummary();
}
