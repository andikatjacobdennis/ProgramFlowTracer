using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace DocGen.Analysis.Diagnostics;

public sealed class LogEntry
{
    public long Line { get; set; }
    public DateTimeOffset? Timestamp { get; set; }

    /// <summary>trace | debug | info | warning | error | fatal | unknown</summary>
    public string Level { get; set; } = "unknown";

    public string Message { get; set; } = "";
    public string? ExceptionType { get; set; }
    public string? CorrelationId { get; set; }
    public string? ThreadId { get; set; }
    public int ContinuationLines { get; set; }
}

public sealed class LogGroup
{
    public string Id { get; set; } = "";
    public string Level { get; set; } = "";
    public string Signature { get; set; } = "";
    public string? ExceptionType { get; set; }
    public long Count { get; set; }
    public long FirstLine { get; set; }
    public long LastLine { get; set; }
    public DateTimeOffset? FirstSeen { get; set; }
    public DateTimeOffset? LastSeen { get; set; }
    public string Sample { get; set; } = "";
    public List<string> CorrelationIds { get; set; } = [];
    public List<string> ThreadIds { get; set; } = [];
}

public sealed class LogSummary
{
    public long Lines { get; set; }
    public long Entries { get; set; }
    public long Bytes { get; set; }
    public Dictionary<string, long> Levels { get; set; } = new(StringComparer.Ordinal);
    public DateTimeOffset? From { get; set; }
    public DateTimeOffset? To { get; set; }
    public int DistinctSignatures { get; set; }
    public bool SignaturesCapped { get; set; }
    public List<LogGroup> Groups { get; set; } = [];

    /// <summary>Correlation ids attached to the most warning/error entries.</summary>
    public List<(string Id, long Errors)> TopCorrelationIds { get; set; } = [];

    /// <summary>Error/fatal entries per time bucket (up to 24 buckets over the log's time range).</summary>
    public List<(DateTimeOffset Start, long Errors)> ErrorTimeline { get; set; } = [];
    public long ElapsedMs { get; set; }
}

public sealed class LogSearchOptions
{
    public string? Text { get; set; }
    public string? Regex { get; set; }
    public string? MinimumLevel { get; set; }
    public string? CorrelationId { get; set; }
    public string? SignatureId { get; set; }
    public DateTimeOffset? From { get; set; }
    public DateTimeOffset? To { get; set; }
    public int ContextLines { get; set; }
    public int Limit { get; set; } = 50;
    public int Skip { get; set; }
}

public sealed class LogMatch
{
    public long Line { get; set; }
    public string Level { get; set; } = "";
    public List<(long Line, string Text)> Lines { get; set; } = [];
}

public sealed class LogSearchResult
{
    public List<LogMatch> Matches { get; set; } = [];
    public long TotalMatches { get; set; }
    public long ScannedLines { get; set; }
    public bool LimitReached { get; set; }
}

/// <summary>
/// Streaming analysis of arbitrarily large log files (plain text, Serilog/ASP.NET console formats and JSON lines).
/// Memory is bounded by the number of distinct message signatures (capped), never by the file size. Messages are
/// normalised into signatures (ids, numbers, GUIDs, quoted values and URLs replaced by placeholders) so a million
/// repetitions of one failure become a single group with a count and first/last occurrence.
/// </summary>
public static partial class LogAnalyzer
{
    public const int MaxGroups = 20_000;
    private static readonly string[] LevelOrder = ["trace", "debug", "info", "warning", "error", "fatal"];

    public static int Rank(string level) => Array.IndexOf(LevelOrder, level) is var i && i >= 0 ? i : -1;

    public static LogSummary Summarize(string path, int topGroups, CancellationToken ct)
    {
        var started = System.Diagnostics.Stopwatch.StartNew();
        var summary = new LogSummary { Bytes = new FileInfo(path).Length };
        var groups = new Dictionary<string, LogGroup>(StringComparer.Ordinal);
        var correlationErrors = new Dictionary<string, long>(StringComparer.Ordinal);
        var errorTimes = new List<DateTimeOffset>();

        var entries = ReadEntries(path, ct, out var lineCounter);
        foreach (var entry in entries)
        {
            summary.Entries++;
            summary.Levels[entry.Level] = summary.Levels.GetValueOrDefault(entry.Level) + 1;
            if (entry.Timestamp is { } ts)
            {
                summary.From = summary.From is null || ts < summary.From ? ts : summary.From;
                summary.To = summary.To is null || ts > summary.To ? ts : summary.To;
            }
            var severe = Rank(entry.Level) >= Rank("warning");
            if (severe && entry.CorrelationId is { } cid && correlationErrors.Count < 100_000)
            {
                correlationErrors[cid] = correlationErrors.GetValueOrDefault(cid) + 1;
            }
            if (Rank(entry.Level) >= Rank("error") && entry.Timestamp is { } errorTime && errorTimes.Count < 1_000_000)
            {
                errorTimes.Add(errorTime);
            }

            var signature = Normalize(entry.Message);
            // The key (and group id) is level + normalised message only, so log_search can recompute it from a single line.
            var key = entry.Level + "|" + signature;
            if (!groups.TryGetValue(key, out var group))
            {
                if (groups.Count >= MaxGroups)
                {
                    summary.SignaturesCapped = true;
                    key = entry.Level + "|(other signatures)";
                    if (!groups.TryGetValue(key, out group))
                    {
                        group = NewGroup(key, entry, "(other signatures)");
                        groups[key] = group;
                    }
                }
                else
                {
                    group = NewGroup(key, entry, signature);
                    groups[key] = group;
                }
            }
            group.Count++;
            group.ExceptionType ??= entry.ExceptionType;
            group.LastLine = entry.Line;
            group.LastSeen = entry.Timestamp ?? group.LastSeen;
            if (entry.CorrelationId is { } c && group.CorrelationIds.Count < 5 && !group.CorrelationIds.Contains(c))
            {
                group.CorrelationIds.Add(c);
            }
            if (entry.ThreadId is { } t && group.ThreadIds.Count < 5 && !group.ThreadIds.Contains(t))
            {
                group.ThreadIds.Add(t);
            }
        }
        summary.Lines = lineCounter.Value;
        summary.DistinctSignatures = groups.Count;
        summary.Groups = groups.Values
            .OrderByDescending(g => Rank(g.Level))
            .ThenByDescending(g => g.Count)
            .Take(Math.Max(1, topGroups))
            .ToList();
        summary.TopCorrelationIds = correlationErrors.OrderByDescending(kv => kv.Value).Take(10).Select(kv => (kv.Key, kv.Value)).ToList();
        if (errorTimes.Count > 0 && summary.From is { } from && summary.To is { } to && to > from)
        {
            var bucket = TimeSpan.FromTicks(Math.Max(TimeSpan.TicksPerSecond, (to - from).Ticks / 24));
            summary.ErrorTimeline = errorTimes.GroupBy(t => (t - from).Ticks / bucket.Ticks)
                .OrderBy(g => g.Key).Select(g => (from + TimeSpan.FromTicks(g.Key * bucket.Ticks), (long)g.Count())).ToList();
        }
        summary.ElapsedMs = started.ElapsedMilliseconds;
        return summary;
    }

    private static LogGroup NewGroup(string key, LogEntry entry, string signature) => new()
    {
        Id = Convert.ToHexString(SHA1.HashData(Encoding.UTF8.GetBytes(key)))[..8].ToLowerInvariant(),
        Level = entry.Level,
        Signature = signature.Length > 240 ? signature[..240] + "…" : signature,
        ExceptionType = entry.ExceptionType,
        FirstLine = entry.Line,
        FirstSeen = entry.Timestamp,
        Sample = entry.Message.Length > 400 ? entry.Message[..400] + "…" : entry.Message,
    };

    public static string SignatureId(LogEntry entry)
    {
        var key = entry.Level + "|" + Normalize(entry.Message);
        return Convert.ToHexString(SHA1.HashData(Encoding.UTF8.GetBytes(key)))[..8].ToLowerInvariant();
    }

    public static LogSearchResult Search(string path, LogSearchOptions options, CancellationToken ct)
    {
        var result = new LogSearchResult();
        Regex? regex = null;
        if (!string.IsNullOrEmpty(options.Regex))
        {
            regex = new Regex(options.Regex, RegexOptions.IgnoreCase | RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(200));
        }
        var minRank = options.MinimumLevel is null ? -1 : Rank(options.MinimumLevel.ToLowerInvariant());
        var context = Math.Clamp(options.ContextLines, 0, 20);
        var limit = Math.Clamp(options.Limit, 1, 500);
        var ring = new Queue<(long Line, string Text)>();
        LogMatch? open = null;
        var openRemaining = 0;

        using var reader = new StreamReader(path, Encoding.UTF8, detectEncodingFromByteOrderMarks: true, new FileStreamOptions { BufferSize = 1 << 16, Options = FileOptions.SequentialScan });
        long lineNo = 0;
        var state = new EntryState();
        while (reader.ReadLine() is { } line)
        {
            lineNo++;
            if ((lineNo & 0xFFF) == 0)
            {
                ct.ThrowIfCancellationRequested();
            }
            var capped = line.Length > 8000 ? line[..8000] + "…" : line;
            if (open is not null && openRemaining > 0)
            {
                open.Lines.Add((lineNo, capped));
                openRemaining--;
            }

            var entry = state.Classify(line, lineNo);
            var matches = entry is not null && Matches(entry, line, options, regex, minRank);
            if (matches)
            {
                result.TotalMatches++;
                if (result.TotalMatches > options.Skip && result.Matches.Count < limit)
                {
                    open = new LogMatch { Line = lineNo, Level = entry!.Level };
                    open.Lines.AddRange(ring);
                    open.Lines.Add((lineNo, capped));
                    openRemaining = context;
                    result.Matches.Add(open);
                }
                else if (result.Matches.Count >= limit)
                {
                    result.LimitReached = true;
                }
            }
            if (context > 0)
            {
                ring.Enqueue((lineNo, capped));
                if (ring.Count > context)
                {
                    ring.Dequeue();
                }
            }
        }
        result.ScannedLines = lineNo;
        return result;
    }

    private static bool Matches(LogEntry entry, string line, LogSearchOptions options, Regex? regex, int minRank)
    {
        if (minRank >= 0 && Rank(entry.Level) < minRank)
        {
            return false;
        }
        if (options.CorrelationId is { Length: > 0 } cid && !line.Contains(cid, StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }
        if (options.From is { } from && entry.Timestamp is { } t1 && t1 < from || options.To is { } to && entry.Timestamp is { } t2 && t2 > to)
        {
            return false;
        }
        if (options.Text is { Length: > 0 } text && !line.Contains(text, StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }
        if (regex is not null)
        {
            try
            {
                if (!regex.IsMatch(line))
                {
                    return false;
                }
            }
            catch (RegexMatchTimeoutException)
            {
                return false;
            }
        }
        if (options.SignatureId is { Length: > 0 } sig && SignatureId(entry) != sig)
        {
            return false;
        }
        return true;
    }

    /// <summary>Lines [start, start+count) (1-based), bounded; used for progressive expansion.</summary>
    public static (List<(long Line, string Text)> Lines, long TotalLines) ReadLines(string path, long start, int count, CancellationToken ct)
    {
        var lines = new List<(long, string)>();
        using var reader = new StreamReader(path, Encoding.UTF8, true, new FileStreamOptions { BufferSize = 1 << 16, Options = FileOptions.SequentialScan });
        long n = 0;
        while (reader.ReadLine() is { } line)
        {
            n++;
            if ((n & 0xFFFF) == 0)
            {
                ct.ThrowIfCancellationRequested();
            }
            if (n >= start && lines.Count < count)
            {
                lines.Add((n, line.Length > 8000 ? line[..8000] + "…" : line));
            }
        }
        return (lines, n);
    }

    /// <summary>Streams complete entries (continuation lines — stack traces, wrapped messages — fold into their entry).</summary>
    public static IEnumerable<LogEntry> ReadEntries(string path, CancellationToken ct, out StrongBox<long> lineCount)
    {
        var box = new StrongBox<long>();
        lineCount = box;
        return Iterate(path, box, ct);

        static IEnumerable<LogEntry> Iterate(string path, StrongBox<long> box, CancellationToken ct)
        {
            using var reader = new StreamReader(path, Encoding.UTF8, true, new FileStreamOptions { BufferSize = 1 << 16, Options = FileOptions.SequentialScan });
            var state = new EntryState();
            LogEntry? pending = null;
            while (reader.ReadLine() is { } line)
            {
                box.Value++;
                if ((box.Value & 0xFFF) == 0)
                {
                    ct.ThrowIfCancellationRequested();
                }
                var entry = state.Classify(line, box.Value);
                if (entry is null)
                {
                    if (pending is not null)
                    {
                        pending.ContinuationLines++;
                        if (pending.ExceptionType is null && ExceptionHeader().Match(line.Trim()) is { Success: true } ex)
                        {
                            pending.ExceptionType = ex.Groups["type"].Value;
                        }
                        if (pending.CorrelationId is null && Correlation().Match(line) is { Success: true } cm)
                        {
                            pending.CorrelationId = cm.Groups["id"].Value;
                        }
                    }
                    continue;
                }
                if (pending is not null)
                {
                    yield return pending;
                }
                pending = entry;
            }
            if (pending is not null)
            {
                yield return pending;
            }
        }
    }

    /// <summary>Per-stream classification state: decides whether a line starts a new entry.</summary>
    private sealed class EntryState
    {
        private bool _sawStructuredEntry;

        public LogEntry? Classify(string line, long lineNo)
        {
            if (line.Length == 0)
            {
                return null;
            }
            var trimmed = line.TrimStart();
            if (trimmed.StartsWith('{') && trimmed.EndsWith('}') && TryJson(trimmed, lineNo) is { } json)
            {
                _sawStructuredEntry = true;
                return json;
            }
            if (line[0] is ' ' or '\t' || trimmed.StartsWith("at ", StringComparison.Ordinal) || trimmed.StartsWith("---", StringComparison.Ordinal))
            {
                // Indented lines continue the previous entry once entries have been recognised.
                if (_sawStructuredEntry)
                {
                    return null;
                }
            }

            DateTimeOffset? timestamp = null;
            var ts = TimestampPattern().Match(line);
            if (ts.Success && ts.Index < 40 && DateTimeOffset.TryParse(ts.Value.Replace(',', '.'), CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var parsed))
            {
                timestamp = parsed;
            }
            var levelMatch = LevelPattern().Match(line.Length > 120 ? line[..120] : line);
            var level = levelMatch.Success ? MapLevel(levelMatch.Groups["level"].Value) : null;

            if (timestamp is null && level is null)
            {
                return _sawStructuredEntry ? null : new LogEntry { Line = lineNo, Level = "unknown", Message = Truncate(line) };
            }
            _sawStructuredEntry = true;
            var messageStart = Math.Max(ts.Success ? ts.Index + ts.Length : 0, levelMatch.Success ? levelMatch.Index + levelMatch.Length : 0);
            var message = line[Math.Min(messageStart, line.Length)..].Trim(' ', ']', ':', '-', '|');
            var entry = new LogEntry { Line = lineNo, Timestamp = timestamp, Level = level ?? "unknown", Message = Truncate(message) };
            if (Correlation().Match(line) is { Success: true } c)
            {
                entry.CorrelationId = c.Groups["id"].Value;
            }
            if (Thread().Match(line) is { Success: true } t)
            {
                entry.ThreadId = t.Groups["id"].Value;
            }
            if (ExceptionHeader().Match(message) is { Success: true } ex)
            {
                entry.ExceptionType = ex.Groups["type"].Value;
            }
            return entry;
        }

        private static LogEntry? TryJson(string line, long lineNo)
        {
            try
            {
                using var doc = JsonDocument.Parse(line, new JsonDocumentOptions { MaxDepth = 32 });
                if (doc.RootElement.ValueKind != JsonValueKind.Object)
                {
                    return null;
                }
                string? Get(params string[] names)
                {
                    foreach (var name in names)
                    {
                        if (doc.RootElement.TryGetProperty(name, out var v))
                        {
                            return v.ValueKind == JsonValueKind.String ? v.GetString() : v.GetRawText();
                        }
                    }
                    return null;
                }
                var entry = new LogEntry
                {
                    Line = lineNo,
                    Level = MapLevel(Get("@l", "level", "Level", "severity", "LogLevel") ?? "info") ?? "info",
                    Message = Truncate(Get("@m", "message", "Message", "RenderedMessage", "msg", "@mt", "MessageTemplate") ?? ""),
                    CorrelationId = Get("CorrelationId", "correlationId", "RequestId", "requestId", "TraceId", "traceId", "@tr"),
                    ThreadId = Get("ThreadId", "threadId", "thread"),
                };
                if (DateTimeOffset.TryParse(Get("@t", "timestamp", "Timestamp", "time", "@timestamp"), CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal, out var ts))
                {
                    entry.Timestamp = ts;
                }
                var exception = Get("@x", "exception", "Exception");
                if (exception is not null && ExceptionHeader().Match(exception.Split('\n')[0].Trim()) is { Success: true } ex)
                {
                    entry.ExceptionType = ex.Groups["type"].Value;
                }
                return entry;
            }
            catch (JsonException)
            {
                return null;
            }
        }
    }

    private static string? MapLevel(string raw) => raw.ToLowerInvariant() switch
    {
        "trc" or "trce" or "trace" or "verbose" or "vrb" => "trace",
        "dbg" or "dbug" or "debug" => "debug",
        "inf" or "info" or "information" => "info",
        "wrn" or "warn" or "warning" => "warning",
        "err" or "eror" or "error" or "fail" => "error",
        "ftl" or "fatal" or "crit" or "critical" => "fatal",
        _ => null,
    };

    private static string Truncate(string value) => value.Length > 2000 ? value[..2000] + "…" : value;

    /// <summary>Replaces variable parts of a message with placeholders so repeated events share a signature.</summary>
    public static string Normalize(string message)
    {
        var text = message.Length > 600 ? message[..600] : message;
        text = GuidPattern().Replace(text, "<guid>");
        text = UrlPattern().Replace(text, "<url>");
        text = IpPattern().Replace(text, "<ip>");
        text = TimestampPattern().Replace(text, "<time>");
        text = QuotedPattern().Replace(text, "<str>");
        text = HexPattern().Replace(text, "<hex>");
        text = NumberPattern().Replace(text, "<n>");
        text = Whitespace().Replace(text, " ");
        return text.Trim();
    }

    [GeneratedRegex(@"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}(?:[.,]\d{1,7})?(?:Z|[+-]\d{2}:?\d{2})?")]
    private static partial Regex TimestampPattern();

    [GeneratedRegex(@"(?:^|[\[\s|(])(?<level>TRC|TRCE|VRB|DBG|DBUG|INF|INFO|INFORMATION|WRN|WARN|WARNING|ERR|EROR|ERROR|FTL|FATAL|CRIT|CRITICAL|fail|warn|info|dbug|crit|trce|Trace|Debug|Information|Warning|Error|Critical|Fatal|Verbose)(?=[\]\s:|)])")]
    private static partial Regex LevelPattern();

    [GeneratedRegex(@"(?:CorrelationId|correlationId|correlation_id|RequestId|requestId|request_id|TraceId|traceId|trace_id|X-Correlation-ID|OperationId)[""']?\s*[:=]\s*[""']?(?<id>[A-Za-z0-9\-_.:]{4,80})")]
    private static partial Regex Correlation();

    [GeneratedRegex(@"(?:\[(?:Thread|thread|T)[:# ]?(?<id>\d{1,6})\]|ThreadId[""']?\s*[:=]\s*(?<id>\d{1,6}))")]
    private static partial Regex Thread();

    [GeneratedRegex(@"(?<type>(?:[A-Za-z_][A-Za-z0-9_]*\.)+[A-Za-z_][A-Za-z0-9_]*Exception)\b")]
    private static partial Regex ExceptionHeader();

    [GeneratedRegex(@"\b[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}\b")]
    private static partial Regex GuidPattern();

    [GeneratedRegex(@"\bhttps?://\S+")]
    private static partial Regex UrlPattern();

    [GeneratedRegex(@"\b\d{1,3}(?:\.\d{1,3}){3}(?::\d+)?\b")]
    private static partial Regex IpPattern();

    [GeneratedRegex(@"""[^""]{0,200}""|'[^']{0,200}'")]
    private static partial Regex QuotedPattern();

    [GeneratedRegex(@"\b0x[0-9a-fA-F]+\b|\b[0-9a-fA-F]{16,}\b")]
    private static partial Regex HexPattern();

    [GeneratedRegex(@"\b\d+(?:\.\d+)?\b")]
    private static partial Regex NumberPattern();

    [GeneratedRegex(@"\s+")]
    private static partial Regex Whitespace();
}

public sealed class StrongBox<T>
{
    public T Value = default!;
}
