using System.Text.RegularExpressions;

namespace DocGen.Analysis.Diagnostics;

public sealed class StackFrame
{
    public string Method { get; set; } = "";

    /// <summary>Declaring type as written (async state machines and lambdas are mapped back to their method).</summary>
    public string Type { get; set; } = "";

    public string MemberName { get; set; } = "";
    public string? File { get; set; }
    public int? Line { get; set; }
    public bool IsFramework { get; set; }
    public bool IsAsyncMachinery { get; set; }
    public string Raw { get; set; } = "";
}

public sealed class ExceptionInfo
{
    public string Type { get; set; } = "";
    public string Message { get; set; } = "";
    public List<StackFrame> Frames { get; set; } = [];

    /// <summary>0 = outermost; higher = more deeply nested inner exception.</summary>
    public int Depth { get; set; }
}

public sealed class StackTraceReport
{
    public List<ExceptionInfo> Exceptions { get; set; } = [];

    /// <summary>The innermost exception: usually closest to the original fault (outer ones are often wrappers).</summary>
    public ExceptionInfo? Root => Exceptions.Count == 0 ? null : Exceptions.MaxBy(e => e.Depth);

    public ExceptionInfo? Outer => Exceptions.Count == 0 ? null : Exceptions.MinBy(e => e.Depth);

    /// <summary>A stable signature: innermost exception type + top application frames (for grouping repeated failures).</summary>
    public string Signature { get; set; } = "";
}

/// <summary>
/// Parses .NET exception text (Exception.ToString(), logs, test output): exception type/message, inner exceptions
/// ("---&gt;" and "Inner exception" formats), frames with file/line, async state-machine and lambda frames mapped back
/// to their source method, and framework-vs-application classification. Deterministic; no symbol server needed.
/// </summary>
public static partial class StackTraceAnalyzer
{
    private static readonly string[] FrameworkPrefixes =
    [
        "System.", "Microsoft.", "Internal.", "Newtonsoft.", "Xunit.", "NUnit.", "MSTest.", "Castle.", "Moq.", "Serilog.",
        "Polly.", "Grpc.", "Npgsql.", "StackExchange.", "Swashbuckle.", "AutoMapper.", "MediatR.", "FluentValidation.", "Dapper.",
    ];

    public static StackTraceReport Parse(string text, int maxExceptions = 20)
    {
        var report = new StackTraceReport();
        ExceptionInfo? current = null;
        var chain = new List<ExceptionInfo>();
        var depth = 0;
        foreach (var rawLine in text.Split('\n'))
        {
            var line = rawLine.TrimEnd('\r');
            var trimmed = line.Trim();
            if (trimmed.Length == 0)
            {
                continue;
            }

            var frame = FramePattern().Match(trimmed);
            if (frame.Success)
            {
                if (current is null)
                {
                    current = new ExceptionInfo { Type = "(unknown)", Depth = depth };
                    report.Exceptions.Add(current);
                    chain.Add(current);
                }
                if (current.Frames.Count < 400)
                {
                    current.Frames.Add(ToFrame(frame, trimmed));
                }
                continue;
            }

            if (trimmed.StartsWith("--- End of inner exception stack trace ---", StringComparison.Ordinal))
            {
                // Frames that follow belong to the enclosing (outer) exception.
                if (chain.Count > 1)
                {
                    chain.RemoveAt(chain.Count - 1);
                    current = chain[^1];
                }
                continue;
            }
            if (trimmed.StartsWith("--- End of stack trace from previous location", StringComparison.Ordinal))
            {
                continue;
            }

            // "---> System.X: message" starts an inner exception; "Inner exception System.X ..." (Serilog/some loggers) too.
            var inner = trimmed.StartsWith("--->", StringComparison.Ordinal) || trimmed.StartsWith("Inner exception", StringComparison.OrdinalIgnoreCase);
            var candidate = inner ? InnerPrefix().Replace(trimmed, "") : trimmed;
            var header = HeaderPattern().Match(candidate);
            if (header.Success && report.Exceptions.Count < maxExceptions)
            {
                if (inner)
                {
                    depth++;
                }
                else
                {
                    depth = 0; // A new exception block.
                    chain.Clear();
                }
                current = new ExceptionInfo { Type = header.Groups["type"].Value, Message = header.Groups["message"].Value.Trim(), Depth = depth };
                report.Exceptions.Add(current);
                chain.Add(current);

                // "Outer: msg ---> Inner: msg" on one line.
                var arrow = candidate.IndexOf(" ---> ", StringComparison.Ordinal);
                if (arrow > 0)
                {
                    current.Message = HeaderPattern().Match(candidate[..arrow]).Groups["message"].Value.Trim();
                    var rest = HeaderPattern().Match(candidate[(arrow + 6)..]);
                    if (rest.Success)
                    {
                        depth++;
                        current = new ExceptionInfo { Type = rest.Groups["type"].Value, Message = rest.Groups["message"].Value.Trim(), Depth = depth };
                        report.Exceptions.Add(current);
                        chain.Add(current);
                    }
                }
                continue;
            }
            if (current is not null && current.Frames.Count == 0 && current.Message.Length < 4000)
            {
                current.Message += "\n" + trimmed; // Multi-line message.
            }
        }

        // With "--->" formatting, frames of the innermost exception are printed first; the header order already
        // gives depth. Signature: innermost type + top 3 application frames.
        var root = report.Root;
        if (root is not null)
        {
            var frames = report.Exceptions.OrderByDescending(e => e.Depth).SelectMany(e => e.Frames).Where(f => !f.IsFramework).Take(3).Select(f => f.Type + "." + f.MemberName);
            report.Signature = root.Type + " @ " + string.Join(" < ", frames);
        }
        return report;
    }

    private static StackFrame ToFrame(Match match, string raw)
    {
        var method = match.Groups["method"].Value;
        var (type, member, machinery) = Normalize(method);
        var frame = new StackFrame
        {
            Method = method,
            Type = type,
            MemberName = member,
            Raw = raw.Length > 400 ? raw[..400] : raw,
            IsAsyncMachinery = machinery,
            IsFramework = FrameworkPrefixes.Any(p => method.StartsWith(p, StringComparison.Ordinal)) || method.StartsWith("lambda_method", StringComparison.Ordinal),
        };
        if (match.Groups["file"].Success && match.Groups["file"].Value.Length > 0)
        {
            frame.File = match.Groups["file"].Value.Trim();
            frame.Line = int.TryParse(match.Groups["line"].Value, out var line) ? line : null;
        }
        return frame;
    }

    /// <summary>
    /// "Ns.Type.&lt;DoWorkAsync&gt;d__5.MoveNext()" → (Ns.Type, DoWorkAsync); "Ns.Type.&lt;&gt;c__DisplayClass3_0.&lt;Run&gt;b__0(Int32 x)" → (Ns.Type, Run);
    /// "Ns.Type.Method(String a)" → (Ns.Type, Method); generic arity markers are removed.
    /// </summary>
    internal static (string Type, string Member, bool Machinery) Normalize(string method)
    {
        var paren = method.IndexOf('(');
        var name = paren > 0 ? method[..paren] : method;
        name = GenericArity().Replace(name, "");
        name = GenericArgs().Replace(name, "");
        var machinery = false;

        var asyncMatch = AsyncStateMachine().Match(name);
        if (asyncMatch.Success)
        {
            machinery = true;
            return (asyncMatch.Groups["type"].Value, asyncMatch.Groups["member"].Value, machinery);
        }
        var lambda = LambdaFrame().Match(name);
        if (lambda.Success)
        {
            return (lambda.Groups["type"].Value, lambda.Groups["member"].Value, machinery);
        }
        var dot = name.LastIndexOf('.');
        return dot > 0 ? (name[..dot], name[(dot + 1)..], machinery) : ("", name, machinery);
    }

    // "   at Namespace.Type.Method(args) in C:\path\File.cs:line 42" (also "in /path/File.cs:line 42" and localized "à"/"bei" is not supported).
    [GeneratedRegex(@"^at\s+(?<method>.+?\))(?:\s+in\s+(?<file>.+?):line\s+(?<line>\d+))?\s*$")]
    private static partial Regex FramePattern();

    [GeneratedRegex(@"^(?<type>(?:[A-Za-z_][A-Za-z0-9_`]*\.)+[A-Za-z_][A-Za-z0-9_`]*(?:Exception|Error|Fault|Failure))(?::\s?(?<message>.*))?$")]
    private static partial Regex HeaderPattern();

    [GeneratedRegex(@"^(?:--->\s*|Inner exception\s*(?:\d+\s*)?:?\s*)")]
    private static partial Regex InnerPrefix();

    [GeneratedRegex(@"`\d+")]
    private static partial Regex GenericArity();

    [GeneratedRegex(@"\[[^\]]*\]")]
    private static partial Regex GenericArgs();

    [GeneratedRegex(@"^(?<type>.+?)\.<(?<member>[^>]+)>d__\d+(?:\.MoveNext)?$")]
    private static partial Regex AsyncStateMachine();

    [GeneratedRegex(@"^(?<type>.+?)\.(?:<>c(?:__DisplayClass[\d_]+)?\.)?<(?<member>[^>]+)>(?:b|g)__[\w|]+$")]
    private static partial Regex LambdaFrame();
}
