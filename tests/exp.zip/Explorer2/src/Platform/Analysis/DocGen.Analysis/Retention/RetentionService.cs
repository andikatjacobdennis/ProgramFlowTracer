using System.Text.Json;
using System.Text.RegularExpressions;
using DocGen.Analysis.Commands;
using DocGen.Analysis.Indexing;
using DocGen.Core.Options;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace DocGen.Analysis.Retention;

public sealed class RetentionReport
{
    public int CommandsDeleted { get; set; }
    public int CommandLogsDeleted { get; set; }
    public int BlobsDeleted { get; set; }
    public int CheckpointsDeleted { get; set; }
    public int IndexesDeleted { get; set; }
    public int ScratchDeleted { get; set; }
    public long BytesFreed { get; set; }
    public int ProtectedBlobs { get; set; }
    public List<string> Errors { get; } = [];
}

/// <summary>
/// Bounded retention of derived data (DocGen:Retention). Removes, by age and then by size quota (oldest first):
/// finished command records and output logs, blobs, finalized run checkpoints, code indexes that are not loaded, and
/// counterfactual scratch copies. It never deletes: output of a queued/running command, the checkpoint of an
/// unfinished run, blobs referenced by an unfinished run's checkpoint, or an index that is in memory. Run records,
/// conversations, investigations and user files are never touched.
/// <para>At-rest encryption (Data Protection) of these files is not implemented in 0.5.0; see README "Retention".</para>
/// </summary>
public sealed partial class RetentionService(
    CommandRunner commands,
    CodeIndexService indexes,
    IOptionsMonitor<RetentionOptions> options,
    IOptions<DocGenOptions> docgenOptions,
    ILogger<RetentionService> logger) : BackgroundService
{
    private readonly SemaphoreSlim _gate = new(1, 1);

    private string DataRoot => Path.GetFullPath(docgenOptions.Value.DataDirectory);

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // First pass shortly after start (not during startup), then on the configured interval.
        try
        {
            await Task.Delay(TimeSpan.FromMinutes(2), stoppingToken);
            while (!stoppingToken.IsCancellationRequested)
            {
                if (options.CurrentValue.Enabled)
                {
                    var report = await RunOnceAsync(DateTime.UtcNow, stoppingToken);
                    if (report.BytesFreed > 0 || report.Errors.Count > 0)
                    {
                        logger.LogInformation("Retention: {Commands} commands, {Logs} logs, {Blobs} blobs, {Checkpoints} checkpoints, {Indexes} indexes, {Scratch} scratch copies deleted ({Bytes} bytes); {Errors} errors",
                            report.CommandsDeleted, report.CommandLogsDeleted, report.BlobsDeleted, report.CheckpointsDeleted, report.IndexesDeleted, report.ScratchDeleted, report.BytesFreed, report.Errors.Count);
                    }
                }
                await Task.Delay(TimeSpan.FromMinutes(Math.Max(5, options.CurrentValue.IntervalMinutes)), stoppingToken);
            }
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
        }
    }

    /// <summary>One retention pass. <paramref name="now"/> is injectable for tests.</summary>
    public async Task<RetentionReport> RunOnceAsync(DateTime now, CancellationToken ct)
    {
        var report = new RetentionReport();
        await _gate.WaitAsync(ct);
        try
        {
            var o = options.CurrentValue;
            var activeRuns = new HashSet<string>(StringComparer.Ordinal);
            var protectedBlobs = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            Checkpoints(now, o, report, activeRuns, protectedBlobs, ct);
            report.ProtectedBlobs = protectedBlobs.Count;
            Commands(now, o, report, ct);
            Blobs(now, o, report, protectedBlobs, ct);
            Indexes(now, o, report, ct);
            Scratch(now, o, report, ct);
        }
        finally
        {
            _gate.Release();
        }
        return await Task.FromResult(report);
    }

    private void Checkpoints(DateTime now, RetentionOptions o, RetentionReport report, HashSet<string> activeRuns, HashSet<string> protectedBlobs, CancellationToken ct)
    {
        var runs = Path.Combine(DataRoot, "runs");
        if (!Directory.Exists(runs))
        {
            return;
        }
        foreach (var dir in Directory.EnumerateDirectories(runs))
        {
            ct.ThrowIfCancellationRequested();
            var path = Path.Combine(dir, "checkpoint.json");
            if (!File.Exists(path))
            {
                continue;
            }
            string text;
            try
            {
                text = File.ReadAllText(path);
            }
            catch (IOException ex)
            {
                report.Errors.Add($"checkpoint {Path.GetFileName(dir)}: {ex.Message}");
                continue;
            }
            bool finalized;
            DateTime savedAt;
            try
            {
                using var doc = JsonDocument.Parse(text);
                var rootElement = doc.RootElement;
                finalized = Get(rootElement, "finalized") is { ValueKind: JsonValueKind.True };
                savedAt = Get(rootElement, "savedAt") is { ValueKind: JsonValueKind.String } s && s.TryGetDateTime(out var d) ? d.ToUniversalTime() : File.GetLastWriteTimeUtc(path);
            }
            catch (JsonException)
            {
                continue; // Unreadable: leave it for the resume logic / operator.
            }
            if (!finalized)
            {
                // Unfinished run: keep it and everything it references.
                activeRuns.Add(Path.GetFileName(dir));
                foreach (Match m in BlobReference().Matches(text))
                {
                    protectedBlobs.Add(m.Groups[1].Value);
                }
                continue;
            }
            if (now - savedAt > TimeSpan.FromDays(o.FinalizedCheckpointMaxAgeDays))
            {
                report.BytesFreed += Delete(path, report) + Delete(path + ".bak", report);
                report.CheckpointsDeleted++;
            }
        }
    }

    private void Commands(DateTime now, RetentionOptions o, RetentionReport report, CancellationToken ct)
    {
        var root = Path.Combine(DataRoot, "commands");
        if (!Directory.Exists(root))
        {
            return;
        }
        var finishedLogs = new List<(string Log, DateTime At, long Size)>();
        foreach (var userDir in Directory.EnumerateDirectories(root))
        {
            foreach (var record in Directory.EnumerateFiles(userDir, "*.json"))
            {
                ct.ThrowIfCancellationRequested();
                var id = Path.GetFileNameWithoutExtension(record);
                if (commands.IsActive(id))
                {
                    continue;
                }
                var (final, completed) = ReadCommand(record);
                if (!final)
                {
                    continue; // Queued/running in another process or interrupted without reconciliation: keep.
                }
                var log = Path.ChangeExtension(record, ".log");
                var at = completed ?? File.GetLastWriteTimeUtc(record);
                if (now - at > TimeSpan.FromDays(o.CommandMaxAgeDays))
                {
                    report.BytesFreed += Delete(record, report) + Delete(log, report) + Delete(record + ".bak", report);
                    report.CommandsDeleted++;
                }
                else if (File.Exists(log))
                {
                    finishedLogs.Add((log, at, new FileInfo(log).Length));
                }
            }
        }
        var total = finishedLogs.Sum(l => l.Size);
        foreach (var log in finishedLogs.OrderBy(l => l.At))
        {
            if (total <= o.CommandOutputQuotaBytes)
            {
                break;
            }
            // The record stays (status, parsed results); only the full output is dropped.
            report.BytesFreed += Delete(log.Log, report);
            report.CommandLogsDeleted++;
            total -= log.Size;
        }
    }

    private static (bool Final, DateTime? Completed) ReadCommand(string path)
    {
        try
        {
            using var doc = JsonDocument.Parse(File.ReadAllText(path));
            var status = Get(doc.RootElement, "status");
            var final = status is { ValueKind: JsonValueKind.String } s
                ? s.GetString() is not ("queued" or "running" or "Queued" or "Running")
                : status is { ValueKind: JsonValueKind.Number } n && n.GetInt32() > 1;
            var completed = Get(doc.RootElement, "completedAt") is { ValueKind: JsonValueKind.String } c && c.TryGetDateTime(out var d) ? d.ToUniversalTime() : (DateTime?)null;
            return (final, completed);
        }
        catch (Exception ex) when (ex is JsonException or IOException)
        {
            return (false, null);
        }
    }

    private void Blobs(DateTime now, RetentionOptions o, RetentionReport report, HashSet<string> protectedBlobs, CancellationToken ct)
    {
        var root = Path.Combine(DataRoot, "blobs");
        if (!Directory.Exists(root))
        {
            return;
        }
        var kept = new List<(string Content, DateTime At, long Size)>();
        foreach (var content in Directory.EnumerateFiles(root, "*.txt", SearchOption.AllDirectories))
        {
            ct.ThrowIfCancellationRequested();
            var hash = Path.GetFileNameWithoutExtension(content);
            if (protectedBlobs.Contains(hash))
            {
                continue;
            }
            var info = new FileInfo(content);
            var at = info.LastWriteTimeUtc;
            if (now - at > TimeSpan.FromDays(o.BlobMaxAgeDays))
            {
                report.BytesFreed += Delete(content, report) + Delete(Path.ChangeExtension(content, ".json"), report);
                report.BlobsDeleted++;
            }
            else
            {
                kept.Add((content, at, info.Length));
            }
        }
        var total = kept.Sum(k => k.Size);
        foreach (var blob in kept.OrderBy(k => k.At))
        {
            if (total <= o.BlobQuotaBytes)
            {
                break;
            }
            report.BytesFreed += Delete(blob.Content, report) + Delete(Path.ChangeExtension(blob.Content, ".json"), report);
            report.BlobsDeleted++;
            total -= blob.Size;
        }
    }

    private void Indexes(DateTime now, RetentionOptions o, RetentionReport report, CancellationToken ct)
    {
        var root = Path.Combine(DataRoot, "analysis", "indexes");
        if (!Directory.Exists(root))
        {
            return;
        }
        foreach (var dir in Directory.EnumerateDirectories(root))
        {
            ct.ThrowIfCancellationRequested();
            if (indexes.IsCached(Path.GetFileName(dir)))
            {
                continue;
            }
            var last = LastWrite(dir);
            if (now - last > TimeSpan.FromDays(o.IndexMaxAgeDays))
            {
                report.BytesFreed += DeleteDirectory(dir, report);
                report.IndexesDeleted++;
            }
        }
    }

    private void Scratch(DateTime now, RetentionOptions o, RetentionReport report, CancellationToken ct)
    {
        // PowerShell script files written for executions (the command record keeps the script text).
        var scripts = Path.Combine(DataRoot, "scratch", "powershell");
        if (Directory.Exists(scripts))
        {
            foreach (var file in Directory.EnumerateFiles(scripts, "*.ps1", SearchOption.AllDirectories))
            {
                ct.ThrowIfCancellationRequested();
                if (now - File.GetLastWriteTimeUtc(file) > TimeSpan.FromHours(o.ScratchMaxAgeHours))
                {
                    report.BytesFreed += Delete(file, report);
                    report.ScratchDeleted++;
                }
            }
        }
        // Browser profiles of sessions that no longer exist (live sessions close after 30 idle minutes).
        var profiles = Path.Combine(DataRoot, "scratch", "browser");
        if (Directory.Exists(profiles))
        {
            foreach (var dir in Directory.EnumerateDirectories(profiles).SelectMany(Directory.EnumerateDirectories))
            {
                ct.ThrowIfCancellationRequested();
                if (now - LastWrite(dir) > TimeSpan.FromHours(o.ScratchMaxAgeHours))
                {
                    report.BytesFreed += DeleteDirectory(dir, report);
                    report.ScratchDeleted++;
                }
            }
        }
        var root = Path.Combine(DataRoot, "scratch", "counterfactual");
        if (!Directory.Exists(root))
        {
            return;
        }
        foreach (var userDir in Directory.EnumerateDirectories(root))
        {
            foreach (var dir in Directory.EnumerateDirectories(userDir))
            {
                ct.ThrowIfCancellationRequested();
                if (now - Directory.GetCreationTimeUtc(dir) > TimeSpan.FromHours(o.ScratchMaxAgeHours))
                {
                    report.BytesFreed += DeleteDirectory(dir, report);
                    report.ScratchDeleted++;
                }
            }
        }
    }

    private static JsonElement? Get(JsonElement element, string name)
    {
        foreach (var p in element.EnumerateObject())
        {
            if (p.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
            {
                return p.Value;
            }
        }
        return null;
    }

    private static DateTime LastWrite(string dir)
    {
        var last = Directory.GetLastWriteTimeUtc(dir);
        foreach (var file in Directory.EnumerateFiles(dir, "*", SearchOption.AllDirectories))
        {
            var t = File.GetLastWriteTimeUtc(file);
            if (t > last)
            {
                last = t;
            }
        }
        return last;
    }

    private static long Delete(string path, RetentionReport report)
    {
        try
        {
            if (!File.Exists(path))
            {
                return 0;
            }
            var size = new FileInfo(path).Length;
            File.Delete(path);
            return size;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            report.Errors.Add($"{Path.GetFileName(path)}: {ex.Message}");
            return 0;
        }
    }

    private static long DeleteDirectory(string dir, RetentionReport report)
    {
        try
        {
            var size = Directory.EnumerateFiles(dir, "*", SearchOption.AllDirectories).Sum(f => new FileInfo(f).Length);
            Directory.Delete(dir, recursive: true);
            return size;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            report.Errors.Add($"{Path.GetFileName(dir)}: {ex.Message}");
            return 0;
        }
    }

    [GeneratedRegex(@"(?:blob|runtime-object)://([0-9a-f]{64})", RegexOptions.IgnoreCase)]
    private static partial Regex BlobReference();
}
