namespace DocGen.Core.Options;

/// <summary>Root "DocGen" configuration section (non-secret settings only).</summary>
public sealed class DocGenOptions
{
    public const string Section = "DocGen";

    public string DataDirectory { get; set; } = "data";
    public string WorkspaceDirectory { get; set; } = "workspaces";
    public string LogDirectory { get; set; } = "logs";

    /// <summary>Built-in skill packages (folders with a SKILL.md); empty means the "skills" folder next to the app.</summary>
    public string SkillsDirectory { get; set; } = "";

    /// <summary>Rolling log files older than this many days are deleted.</summary>
    public int LogRetentionDays { get; set; } = 14;
    public long MaxUploadBytes { get; set; } = 25 * 1024 * 1024;

    public List<string> AllowedUploadExtensions { get; set; } =
        [".txt", ".md", ".json", ".csv", ".cs", ".js", ".html", ".css", ".xml", ".log", ".yml", ".yaml", ".docx", ".xlsx", ".pptx", ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".tif", ".tiff", ".webp", ".pdf"];

    /// <summary>Largest file (bytes) the file tools and context manager will read.</summary>
    public long MaxFileReadBytes { get; set; } = 512 * 1024;

    public int SessionDays { get; set; } = 14;
    public int PasswordHashIterations { get; set; } = 210_000;
    public int MinimumPasswordLength { get; set; } = 8;

    /// <summary>Login/registration attempts allowed per client IP per minute.</summary>
    public int AuthRateLimitPerMinute { get; set; } = 10;
}

public sealed class AgentOptions
{
    public const string Section = "DocGen:Agent";

    public int MaximumIterations { get; set; } = 80;
    public int MaximumToolCalls { get; set; } = 200;
    public int MaximumRuntimeSeconds { get; set; } = 1800;

    /// <summary>Cap on the steps a built-in skill may ask for (SKILL.md metadata max_steps) once it is active.</summary>
    public int MaximumSkillSteps { get; set; } = 200;

    /// <summary>Cap on the tool calls a built-in skill may ask for (SKILL.md metadata max_tool_calls).</summary>
    public int MaximumSkillToolCalls { get; set; } = 400;

    /// <summary>Upper bound on (estimated) prompt tokens, further limited by each model's context window.</summary>
    public int MaximumContextTokens { get; set; } = 256_000;

    public int MaximumToolOutputChars { get; set; } = 20_000;

    /// <summary>Identical call + identical result this many times terminates the run.</summary>
    public int RepeatedCallThreshold { get; set; } = 3;

    public int ToolTimeoutSeconds { get; set; } = 300;
    public int ApprovalTimeoutSeconds { get; set; } = 1800;
    public int RecentMessageCount { get; set; } = 40;
    public int MaximumAttachmentChars { get; set; } = 60_000;

    /// <summary>On graceful shutdown, how long active runs get to save their partial output and final state.</summary>
    public int ShutdownGracePeriodSeconds { get; set; } = 10;

    /// <summary>Independent read-only tool calls from one model response run concurrently, at most this many at a time.</summary>
    public int MaxParallelTools { get; set; } = 4;

    /// <summary>Tool-call arguments longer than this are stored as runtime objects; run records keep a reference.</summary>
    public int LargeArgumentChars { get; set; } = 16_000;

    /// <summary>
    /// Soft compaction threshold (fraction of the context budget): old raw tool outputs, duplicates, superseded file
    /// contents and old logs are externalized (kept as references) before the next model call.
    /// </summary>
    public double SoftCompactionThreshold { get; set; } = 0.85;

    /// <summary>Hard compaction threshold: a validated continuation snapshot replaces older context before the next model call.</summary>
    public double HardCompactionThreshold { get; set; } = 0.95;

    /// <summary>After hard compaction the verbatim recent tail may use at most this fraction of the budget.</summary>
    public double CompactionTailFraction { get; set; } = 0.30;

    /// <summary>Utilization at which a context_pressure activity is recorded.</summary>
    public double ContextPressureThreshold { get; set; } = 0.75;

    /// <summary>
    /// Engineering guidance derived from the run itself (see EngineeringLedger): a pinned "engineering state" block when
    /// files changed or half the budget is spent, a one-time completion check when the model tries to finish with changes
    /// no build/test has seen, and a factual changed-files notice at the end. Off restores the previous loop behaviour.
    /// </summary>
    public bool EngineeringGuidance { get; set; } = true;
}

public sealed class PermissionOptions
{
    public const string Section = "DocGen:Permissions";

    /// <summary>Default decision per risk level. Evaluated in C#; the model can never change it.</summary>
    public Dictionary<string, string> RiskLevels { get; set; } = new(StringComparer.OrdinalIgnoreCase)
    {
        ["ReadOnly"] = "Allow",
        ["Write"] = "Allow",
        ["External"] = "Ask",
        ["Sensitive"] = "Ask",
        ["Destructive"] = "Deny",
    };

    /// <summary>Per-tool overrides (tool name → Allow | Ask | Deny). Cannot relax Destructive tools to Allow.</summary>
    public Dictionary<string, string> Tools { get; set; } = new(StringComparer.OrdinalIgnoreCase)
    {
        ["file_write"] = "Ask",
        ["source_edit"] = "Ask",
        ["script_write"] = "Ask",
    };

    public List<string> DisabledTools { get; set; } = [];

    /// <summary>
    /// Capability policies per role (Administrators / Users → Allow | Ask | Deny). A capability decision can only make a
    /// call's risk-based decision stricter. Ordinary users cannot run PowerShell or processes by default.
    /// </summary>
    public Dictionary<string, CapabilityPolicy> Capabilities { get; set; } = new(StringComparer.OrdinalIgnoreCase)
    {
        ["ExecutePowerShell"] = new() { Administrators = "Ask", Users = "Deny" },
        ["ExecuteProcess"] = new() { Administrators = "Ask", Users = "Deny" },
        ["ManageDevelopmentServer"] = new() { Administrators = "Ask", Users = "Deny" },
        ["BrowserLocal"] = new() { Administrators = "Allow", Users = "Ask" },
        ["BrowserExternal"] = new() { Administrators = "Ask", Users = "Deny" },
        ["GitCommit"] = new() { Administrators = "Ask", Users = "Deny" },
        ["GitPush"] = new() { Administrators = "Ask", Users = "Deny" },
    };
}

public sealed class CapabilityPolicy
{
    public string Administrators { get; set; } = "Ask";
    public string Users { get; set; } = "Deny";
}

/// <summary>Controlled process execution (DocGen:Execution). Nothing runs unless its executable is listed and enabled.</summary>
public sealed class ExecutionOptions
{
    public const string Section = "DocGen:Execution";

    /// <summary>Executables DocGen may start, by logical name. Existence on PATH never grants permission by itself.</summary>
    public List<ExecutableOptions> Executables { get; set; } =
    [
        new() { Name = "dotnet", Kind = "dotnet" },
        new() { Name = "git", Kind = "git" },
        new() { Name = "pwsh", Kind = "powershell" },
        new() { Name = "powershell", Kind = "powershell" },
    ];

    /// <summary>Use Windows PowerShell 5.1 (powershell.exe) when PowerShell 7 (pwsh) is not installed.</summary>
    public bool AllowWindowsPowerShellFallback { get; set; } = true;

    public int DefaultTimeoutSeconds { get; set; } = 300;
    public int MaxTimeoutSeconds { get; set; } = 3600;

    /// <summary>Output lines included in a tool result (the full output stays in the command log).</summary>
    public int ResultOutputLines { get; set; } = 60;

    /// <summary>Environment variables child processes inherit from DocGen (names; a trailing * is a prefix). Everything else is dropped.</summary>
    public List<string> InheritedEnvironment { get; set; } =
    [
        "PATH", "PATHEXT", "SystemRoot", "SystemDrive", "windir", "ComSpec", "TEMP", "TMP", "USERPROFILE", "HOME", "HOMEDRIVE", "HOMEPATH",
        "APPDATA", "LOCALAPPDATA", "ProgramData", "ALLUSERSPROFILE", "PUBLIC", "ProgramFiles", "ProgramFiles(x86)", "ProgramW6432", "CommonProgramFiles",
        "CommonProgramFiles(x86)", "CommonProgramW6432", "COMPUTERNAME", "USERNAME", "USERDOMAIN", "OS", "PROCESSOR_*", "NUMBER_OF_PROCESSORS",
        "PSModulePath", "LANG", "LC_*", "TERM", "DOTNET_*", "NUGET_*", "MSBuild*", "MSBUILD*", "VSINSTALLDIR", "VisualStudioVersion", "GIT_*", "XDG_*",
        "SHELL", "USER", "LOGNAME", "TZ",
    ];

    /// <summary>Secrets a project needs, explicitly authorized by an administrator. Values are passed through and always redacted.</summary>
    public List<AuthorizedSecretOptions> AuthorizedSecrets { get; set; } = [];

    /// <summary>PowerShell commands that are always blocked (in addition to the built-in list).</summary>
    public List<string> BlockedCommands { get; set; } = [];

    /// <summary>When false, scripts that trigger the built-in "blocked" rules only require approval instead (not recommended).</summary>
    public bool EnforceBlockedCommands { get; set; } = true;

    /// <summary>Development servers: how long to wait for a listening URL after start.</summary>
    public int ServerStartupTimeoutSeconds { get; set; } = 90;

    public int MaxServersPerUser { get; set; } = 4;
}

public sealed class ExecutableOptions
{
    /// <summary>Logical name (dotnet, git, pwsh, powershell, node…).</summary>
    public string Name { get; set; } = "";

    /// <summary>Absolute path; when empty the name is looked up on PATH (and well-known install locations).</summary>
    public string? Path { get; set; }

    public bool Enabled { get; set; } = true;

    /// <summary>dotnet | git | powershell | process</summary>
    public string Kind { get; set; } = "process";
}

public sealed class AuthorizedSecretOptions
{
    /// <summary>Environment variable name passed to child processes (taken from the DocGen process environment).</summary>
    public string Name { get; set; } = "";

    /// <summary>Repositories allowed to receive it (empty = none).</summary>
    public List<string> Repositories { get; set; } = [];
}

/// <summary>Browser automation for development verification (DocGen:Browser), via the Chrome DevTools Protocol.</summary>
public sealed class BrowserOptions
{
    public const string Section = "DocGen:Browser";

    public bool Enabled { get; set; } = true;

    /// <summary>Chromium-based browser (Edge/Chrome). Empty = detect Edge, then Chrome.</summary>
    public string? ExecutablePath { get; set; }

    public bool Headless { get; set; } = true;
    public int DefaultWidth { get; set; } = 1280;
    public int DefaultHeight { get; set; } = 800;
    public int NavigationTimeoutSeconds { get; set; } = 30;
    public int MaxSessionsPerUser { get; set; } = 2;
    public int MaxTabsPerSession { get; set; } = 8;

    /// <summary>Hosts treated as local development targets (in addition to loopback, *.localhost and *.test).</summary>
    public List<string> LocalHosts { get; set; } = [];
}

public sealed class TcpOptions
{
    public const string Section = "DocGen:Tcp";

    public bool Enabled { get; set; } = true;
    public string BindAddress { get; set; } = "127.0.0.1";
    public int Port { get; set; } = 5055;

    /// <summary>Must be set to true to bind to a non-loopback address.</summary>
    public bool AllowRemoteConnections { get; set; }

    public int MaximumConnections { get; set; } = 32;
    public int MaximumMessageSize { get; set; } = 1024 * 1024;
    public int ConnectionTimeoutSeconds { get; set; } = 10;
    public int ReadTimeoutSeconds { get; set; } = 30;
    public int WriteTimeoutSeconds { get; set; } = 30;
    public int IdleTimeoutSeconds { get; set; } = 300;
}

public sealed class HttpToolOptions
{
    public const string Section = "DocGen:HttpTool";

    public int TimeoutSeconds { get; set; } = 30;
    public int MaximumResponseBytes { get; set; } = 1024 * 1024;
    public int MaximumRedirects { get; set; } = 5;
    public List<string> AllowedSchemes { get; set; } = ["http", "https"];

    /// <summary>Explicit escape hatch for trusted internal hosts (host names or IPs). Empty by default.</summary>
    public List<string> AllowedPrivateHosts { get; set; } = [];

    public List<string> BlockedHosts { get; set; } = ["metadata.google.internal", "metadata"];
}

public sealed class TcpToolOptions
{
    public const string Section = "DocGen:TcpTool";

    /// <summary>host:port pairs the TcpSendTool may contact. Empty means the tool refuses every destination.</summary>
    public List<string> AllowedEndpoints { get; set; } = ["127.0.0.1:5055"];

    public int TimeoutSeconds { get; set; } = 15;
}

/// <summary>"DocGen:Analysis" — code intelligence, debugging tools and command execution (server-side settings only).</summary>
public sealed class AnalysisOptions
{
    public const string Section = "DocGen:Analysis";

    /// <summary>
    /// Source repositories on this machine that the debugging tools may read. Configured by the operator only; the
    /// model refers to them by name and can never supply an absolute path. Every user also has "workspace".
    /// </summary>
    public List<RepositoryOptions> Repositories { get; set; } = [];

    /// <summary>Directories never indexed or searched.</summary>
    public List<string> ExcludedDirectories { get; set; } =
        ["bin", "obj", ".git", ".vs", ".idea", "node_modules", "packages", "TestResults", ".nuget"];

    /// <summary>Source files larger than this are listed but not parsed.</summary>
    public long MaxIndexedFileBytes { get; set; } = 2 * 1024 * 1024;

    /// <summary>Largest JSON document the DOM-based tools (json_path, json_diff, json_sample) load. Streaming tools have no limit.</summary>
    public long MaxJsonDocumentBytes { get; set; } = 256L * 1024 * 1024;

    public int MaxSearchResults { get; set; } = 200;

    /// <summary>Degree of parallelism for indexing and code search.</summary>
    public int MaxParallelism { get; set; } = 8;

    /// <summary>Executables the command runner may start (by file name, without extension).</summary>
    public List<string> AllowedExecutables { get; set; } = ["dotnet"];

    public int CommandTimeoutSeconds { get; set; } = 900;
    public int MaxConcurrentCommands { get; set; } = 2;

    /// <summary>Full command output is kept on disk up to this size; beyond it output is counted but not stored.</summary>
    public long MaxCommandOutputBytes { get; set; } = 64L * 1024 * 1024;

    /// <summary>In an active investigation, source edits are blocked until a hypothesis is confirmed with evidence.</summary>
    public bool RequireConfirmedRootCauseForEdits { get; set; } = true;

    /// <summary>
    /// Confirming a root cause also requires a counterfactual experiment that removed the failure (or a documented
    /// limitation explaining why one is impossible).
    /// </summary>
    public bool RequireCounterfactualForConfirmation { get; set; } = true;

    /// <summary>Largest repository (bytes of source/test/config files) counterfactual_run copies to a scratch directory.</summary>
    public long MaxCounterfactualCopyBytes { get; set; } = 256L * 1024 * 1024;
}

/// <summary>
/// Bounded retention of derived data (DocGen:Retention). Only finished, inactive data is removed: output of running
/// commands, checkpoints of unfinished runs and blobs referenced by them are never deleted.
/// </summary>
public sealed class RetentionOptions
{
    public const string Section = "DocGen:Retention";

    public bool Enabled { get; set; } = true;
    public int IntervalMinutes { get; set; } = 60;

    /// <summary>Finished command records and their output logs older than this are deleted.</summary>
    public int CommandMaxAgeDays { get; set; } = 30;

    /// <summary>Total size cap for stored command output; the oldest finished logs are deleted first.</summary>
    public long CommandOutputQuotaBytes { get; set; } = 2L * 1024 * 1024 * 1024;

    /// <summary>Blobs (large tool outputs) older than this are deleted unless referenced by an unfinished run.</summary>
    public int BlobMaxAgeDays { get; set; } = 30;

    public long BlobQuotaBytes { get; set; } = 2L * 1024 * 1024 * 1024;

    /// <summary>Checkpoints of finished (completed, failed, cancelled) runs older than this are deleted.</summary>
    public int FinalizedCheckpointMaxAgeDays { get; set; } = 14;

    /// <summary>Stored code indexes not used for this long are deleted (they are rebuilt on demand).</summary>
    public int IndexMaxAgeDays { get; set; } = 30;

    /// <summary>Counterfactual scratch copies older than this are deleted.</summary>
    public int ScratchMaxAgeHours { get; set; } = 24;
}

public sealed class RepositoryOptions
{
    /// <summary>Name used by tools and the UI (letters, digits, '-', '_', '.').</summary>
    public string Name { get; set; } = "";

    /// <summary>Absolute path of the repository root.</summary>
    public string Path { get; set; } = "";

    /// <summary>Allows source_edit to change files in this repository (still subject to approval and guards).</summary>
    public bool AllowWrite { get; set; }

    /// <summary>Allows build/test commands to run in this repository (still subject to approval).</summary>
    public bool AllowCommands { get; set; } = true;

    /// <summary>User names allowed to use this repository. Empty = administrators only.</summary>
    public List<string> Users { get; set; } = [];
}

/// <summary>Developer workflow: pre-commit verification, commit/push safety, source packaging and project memory (0.7.0).</summary>
public sealed class WorkflowOptions
{
    public const string Section = "DocGen:Workflow";

    /// <summary>Extra verification steps run after restore/build/test (kind build or test, optional target and filter).</summary>
    public List<VerificationStepOptions> ExtraVerificationSteps { get; set; } = [];

    /// <summary>Maximum time for one pre-commit verification.</summary>
    public int VerificationTimeoutSeconds { get; set; } = 1800;

    /// <summary>A file larger than this blocks a commit (huge generated or binary files).</summary>
    public long MaxCommitFileBytes { get; set; } = 5L * 1024 * 1024;

    /// <summary>Directory names excluded from source packages by default (in addition to secret and user-specific files).</summary>
    public List<string> PackageExcludedDirectories { get; set; } =
        [".git", ".vs", ".idea", "bin", "obj", "node_modules", "data", "logs", "workspaces", "TestResults", "packages", ".nuget", "scratch", "browser-profiles", "artifacts"];

    /// <summary>Excluded directories that may never be included, even on explicit request.</summary>
    public List<string> PackageNeverIncludedDirectories { get; set; } = [".git", "data", "logs", "workspaces", "scratch", "browser-profiles"];

    public long MaxPackageBytes { get; set; } = 512L * 1024 * 1024;
    public int MaxPackageFiles { get; set; } = 50_000;

    /// <summary>Maximum project memory entries per repository.</summary>
    public int MaxMemoryEntries { get; set; } = 500;
}

public sealed class VerificationStepOptions
{
    public string Name { get; set; } = "";
    public string Kind { get; set; } = "test";
    public string? Target { get; set; }
    public string? Filter { get; set; }
}

/// <summary>The built-in terminal (DocGen:Terminal): administrators run shell commands themselves; the model never does.</summary>
public sealed class TerminalOptions
{
    public const string Section = "DocGen:Terminal";

    public bool Enabled { get; set; } = true;

    public int MaxSessionsPerUser { get; set; } = 8;

    /// <summary>Characters of output kept per terminal (older output is dropped).</summary>
    public int MaxOutputChars { get; set; } = 1_000_000;

    /// <summary>Longest a single command may run; 0 means no limit (Stop ends it).</summary>
    public int MaxRunSeconds { get; set; }

    /// <summary>Longest command accepted (characters).</summary>
    public int MaxCommandChars { get; set; } = 16_000;
}
