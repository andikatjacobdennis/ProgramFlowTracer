namespace DocGen.Core.Exceptions;

/// <summary>
/// Base exception. <see cref="Code"/> and <see cref="Exception.Message"/> are safe to show to users;
/// internal details must go in inner exceptions (which are logged, never returned).
/// </summary>
public class DocGenException : Exception
{
    public DocGenException(string code, string message, int statusCode = 500, Exception? inner = null)
        : base(message, inner)
    {
        Code = code;
        StatusCode = statusCode;
    }

    public string Code { get; }

    /// <summary>Suggested HTTP status code.</summary>
    public int StatusCode { get; }
}

public class ValidationException(string message)
    : DocGenException("VALIDATION_FAILED", message, 400);

/// <summary>Resource missing or not owned by the caller (the two are deliberately indistinguishable).</summary>
public class NotFoundException(string resource = "Resource")
    : DocGenException("NOT_FOUND", $"{resource} was not found.", 404);

public class AuthenticationFailedException(string message = "Invalid user name or password.")
    : DocGenException("AUTHENTICATION_FAILED", message, 401);

public class ForbiddenException(string message = "You are not allowed to perform this action.")
    : DocGenException("FORBIDDEN", message, 403);

public class StorageException(string message, Exception? inner = null)
    : DocGenException("STORAGE_ERROR", message, 500, inner);

public class StorageConcurrencyException(string message = "The resource was modified by another request. Reload and try again.")
    : DocGenException("CONCURRENCY_CONFLICT", message, 409);

public class ProviderException(string message, Exception? inner = null, string code = "PROVIDER_ERROR")
    : DocGenException(code, message, 502, inner);

public class ProviderTimeoutException(string message = "The model provider timed out.", Exception? inner = null)
    : ProviderException(message, inner, "PROVIDER_TIMEOUT");

public class ToolException(string message, Exception? inner = null, string code = "TOOL_ERROR")
    : DocGenException(code, message, 500, inner);

public class ToolDeniedException(string message = "The tool call was denied.")
    : ToolException(message, null, "TOOL_DENIED");

public class ToolTimeoutException(string message = "The tool timed out.")
    : ToolException(message, null, "TOOL_TIMEOUT");

public class TcpProtocolException(string message, string code = "INVALID_REQUEST", Exception? inner = null)
    : DocGenException(code, message, 400, inner);

public class NetworkException(string message, Exception? inner = null, string code = "NETWORK_ERROR")
    : DocGenException(code, message, 502, inner);

public class AgentLimitException(string message)
    : DocGenException("AGENT_LIMIT", message, 422);

public class ContextLimitException(string message = "The message is too large for the model's context window.")
    : DocGenException("CONTEXT_LIMIT", message, 413);
