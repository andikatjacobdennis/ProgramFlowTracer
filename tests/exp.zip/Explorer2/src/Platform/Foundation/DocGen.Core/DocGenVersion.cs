using System.Reflection;

namespace DocGen.Core;

/// <summary>Application version, taken from the &lt;Version&gt; in Directory.Build.props (no extra dependencies).</summary>
public static class DocGenVersion
{
    public static string Current { get; } = Read();

    private static string Read()
    {
        var informational = typeof(DocGenVersion).Assembly.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion;
        if (!string.IsNullOrWhiteSpace(informational))
        {
            // Strip build metadata such as "+<commit sha>".
            var plus = informational.IndexOf('+');
            return plus > 0 ? informational[..plus] : informational;
        }
        return typeof(DocGenVersion).Assembly.GetName().Version?.ToString(3) ?? "0.0.0";
    }
}
