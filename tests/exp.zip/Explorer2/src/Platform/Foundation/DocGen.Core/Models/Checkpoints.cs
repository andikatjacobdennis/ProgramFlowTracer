using DocGen.Core.Abstractions;

namespace DocGen.Core.Models;

/// <summary>
/// The minimum state needed to continue an agent run after an interruption (data/runs/{runId}/checkpoint.json).
/// It contains only externally meaningful data — the model-visible messages, tool calls, tool results and
/// execution metadata — never hidden reasoning. Written atomically after each model response and tool result.
/// </summary>
public sealed class AgentCheckpoint
{
    public const int CurrentSchemaVersion = 1;

    public int SchemaVersion { get; set; } = CurrentSchemaVersion;
    public string RunId { get; set; } = "";
    public string UserId { get; set; } = "";
    public string ConversationId { get; set; } = "";
    public string? AssistantMessageId { get; set; }
    public string? ProjectId { get; set; }
    public string ModelId { get; set; } = "";
    public string ProviderId { get; set; } = "";

    /// <summary>Completed model iterations when the checkpoint was written.</summary>
    public int Iteration { get; set; }

    public int ToolCallCount { get; set; }

    /// <summary>model = the next step is a model call; tools = tool calls from the last response are being handled.</summary>
    public string Phase { get; set; } = CheckpointPhases.Model;

    /// <summary>Bounded model conversation (system, user, assistant, tool messages).</summary>
    public List<ModelMessage> Messages { get; set; } = [];

    /// <summary>Tool calls requested by the latest model response and their resolution so far.</summary>
    public List<PendingToolCall> PendingToolCalls { get; set; } = [];

    /// <summary>Visible assistant content produced so far (text, tool steps, notices).</summary>
    public List<MessagePart> Parts { get; set; } = [];

    public List<ToolCall> ToolCalls { get; set; } = [];
    public List<ToolResult> ToolResults { get; set; } = [];
    public List<Citation> Citations { get; set; } = [];
    public UsageRecord Usage { get; set; } = new();
    public CheckpointLimits Limits { get; set; } = new();

    /// <summary>Loop-detector counters (hashes of tool name + arguments + result), so repetition limits survive a resume.</summary>
    public Dictionary<string, int> LoopCounts { get; set; } = new(StringComparer.Ordinal);

    /// <summary>Agent-loop runtime consumed so far across all sessions of the run; the runtime limit is cumulative.</summary>
    public long ElapsedRuntimeMs { get; set; }

    public long Sequence { get; set; }
    public DateTime SavedAt { get; set; } = DateTime.UtcNow;

    /// <summary>Number of hard compactions so far and the latest validated snapshot (restored on resume).</summary>
    public int CompactionSequence { get; set; }

    public string? LastCompactionSnapshotId { get; set; }

    /// <summary>True once the run reached a final state; resumable state has been discarded.</summary>
    public bool Finalized { get; set; }

    public string? FinalStatus { get; set; }
}

public static class CheckpointPhases
{
    public const string Model = "model";
    public const string Tools = "tools";
}

public sealed class PendingToolCall
{
    public ToolCall Call { get; set; } = new();

    /// <summary>pending | completed</summary>
    public string Status { get; set; } = "pending";

    /// <summary>The result given to the model (bounded) once completed.</summary>
    public ToolResult? Result { get; set; }
}

public sealed class CheckpointLimits
{
    public int MaximumIterations { get; set; }
    public int MaximumToolCalls { get; set; }

    /// <summary>Cumulative runtime budget of the run (0 in checkpoints written before 0.4.0 = use the current setting).</summary>
    public int MaximumRuntimeSeconds { get; set; }
}

/// <summary>Why a run can or cannot be continued. Codes are stable; messages are user-facing.</summary>
public sealed record ResumeEligibility(
    bool CanResume,
    string Code,
    string Message,
    DateTime? CheckpointSavedAt = null,
    int? Iteration = null,
    int? MaximumIterations = null,
    bool ApprovalPending = false);
