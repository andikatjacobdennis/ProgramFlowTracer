using System.Globalization;

namespace DocGen.Core.Models;

/// <summary>
/// Languages the user can choose for DocGen's replies (Settings → Language &amp; region): every language-and-region
/// culture .NET knows (for example en-US, hi-IN, sw-KE). The choice becomes a system instruction, so the model writes in
/// that language and regional style; null means "match the language of the user's message".
/// </summary>
public static class ResponseLanguages
{
    private static readonly Lazy<IReadOnlyList<(string Tag, string Name)>> Cultures = new(() =>
        CultureInfo.GetCultures(CultureTypes.SpecificCultures)
            .Where(c => !string.IsNullOrEmpty(c.Name) && !c.EnglishName.StartsWith("Unknown", StringComparison.OrdinalIgnoreCase))
            .Select(c => (Tag: c.Name, Name: c.EnglishName))
            .DistinctBy(c => c.Tag, StringComparer.OrdinalIgnoreCase)
            .OrderBy(c => c.Name, StringComparer.OrdinalIgnoreCase)
            .ToList());

    public static IReadOnlyList<(string Tag, string Name)> All => Cultures.Value;

    public static bool IsValid(string? tag) => Normalize(tag) is not null;

    public static string? Normalize(string? tag)
        => tag is null ? null : All.FirstOrDefault(l => string.Equals(l.Tag, tag, StringComparison.OrdinalIgnoreCase)).Tag;

    /// <summary>The system instruction for a chosen language, or null for automatic.</summary>
    public static string? Instruction(string? tag)
    {
        var (code, name) = All.FirstOrDefault(l => string.Equals(l.Tag, tag, StringComparison.OrdinalIgnoreCase));
        if (code is null)
        {
            return null;
        }
        var style = code switch
        {
            "en-US" => " Use American spelling and usage (color, organize, center, license as a noun), US date format (MM/DD/YYYY), 12-hour time, US number format (1,234.56) and US units where units matter.",
            "en-GB" => " Use British spelling and usage (colour, organise, centre, licence as a noun), UK date format (DD/MM/YYYY), 24-hour time and metric units where units matter.",
            "en-IN" => " Use Indian English spelling (British-based), DD/MM/YYYY dates and the Indian number system (lakh, crore) where amounts matter.",
            _ => RegionalStyle(code),
        };
        return $"Response language: {name} ({code}), chosen by the user in Settings. Write every reply in this language even when the user or a file uses another one." + style +
               " Code, identifiers, commands, file paths and quoted text stay exactly as they are.";
    }

    /// <summary>Date and number conventions of the culture, so replies use the local formats.</summary>
    private static string RegionalStyle(string code)
    {
        try
        {
            var culture = CultureInfo.GetCultureInfo(code);
            var sample = new DateTime(2026, 12, 31);
            return $" Use the local conventions: dates like {sample.ToString("d", culture)}, numbers like {1234567.89.ToString("N2", culture)}.";
        }
        catch (CultureNotFoundException)
        {
            return "";
        }
    }
}

/// <summary>
/// The user's country (Settings → Language &amp; region): the full ISO 3166-1 list as of 2026. It tells the model which
/// local context to assume when it matters: currency, laws and regulations, taxes, holidays, phone and address
/// formats. India is the default.
/// </summary>
public static class UserCountries
{
    public const string Default = "IN";

    public static readonly IReadOnlyList<(string Code, string Name)> All =
    [
        ("AF", "Afghanistan"), ("AX", "Åland Islands"), ("AL", "Albania"), ("DZ", "Algeria"), ("AS", "American Samoa"), ("AD", "Andorra"),
        ("AO", "Angola"), ("AI", "Anguilla"), ("AQ", "Antarctica"), ("AG", "Antigua and Barbuda"), ("AR", "Argentina"), ("AM", "Armenia"),
        ("AW", "Aruba"), ("AU", "Australia"), ("AT", "Austria"), ("AZ", "Azerbaijan"), ("BS", "Bahamas"), ("BH", "Bahrain"),
        ("BD", "Bangladesh"), ("BB", "Barbados"), ("BY", "Belarus"), ("BE", "Belgium"), ("BZ", "Belize"), ("BJ", "Benin"),
        ("BM", "Bermuda"), ("BT", "Bhutan"), ("BO", "Bolivia"), ("BQ", "Bonaire, Sint Eustatius and Saba"), ("BA", "Bosnia and Herzegovina"),
        ("BW", "Botswana"), ("BV", "Bouvet Island"), ("BR", "Brazil"), ("IO", "British Indian Ocean Territory"), ("BN", "Brunei"),
        ("BG", "Bulgaria"), ("BF", "Burkina Faso"), ("BI", "Burundi"), ("CV", "Cabo Verde"), ("KH", "Cambodia"), ("CM", "Cameroon"),
        ("CA", "Canada"), ("KY", "Cayman Islands"), ("CF", "Central African Republic"), ("TD", "Chad"), ("CL", "Chile"), ("CN", "China"),
        ("CX", "Christmas Island"), ("CC", "Cocos (Keeling) Islands"), ("CO", "Colombia"), ("KM", "Comoros"), ("CG", "Congo"),
        ("CD", "Congo (Democratic Republic)"), ("CK", "Cook Islands"), ("CR", "Costa Rica"), ("CI", "Côte d'Ivoire"), ("HR", "Croatia"),
        ("CU", "Cuba"), ("CW", "Curaçao"), ("CY", "Cyprus"), ("CZ", "Czechia"), ("DK", "Denmark"), ("DJ", "Djibouti"), ("DM", "Dominica"),
        ("DO", "Dominican Republic"), ("EC", "Ecuador"), ("EG", "Egypt"), ("SV", "El Salvador"), ("GQ", "Equatorial Guinea"), ("ER", "Eritrea"),
        ("EE", "Estonia"), ("SZ", "Eswatini"), ("ET", "Ethiopia"), ("FK", "Falkland Islands"), ("FO", "Faroe Islands"), ("FJ", "Fiji"),
        ("FI", "Finland"), ("FR", "France"), ("GF", "French Guiana"), ("PF", "French Polynesia"), ("TF", "French Southern Territories"),
        ("GA", "Gabon"), ("GM", "Gambia"), ("GE", "Georgia"), ("DE", "Germany"), ("GH", "Ghana"), ("GI", "Gibraltar"), ("GR", "Greece"),
        ("GL", "Greenland"), ("GD", "Grenada"), ("GP", "Guadeloupe"), ("GU", "Guam"), ("GT", "Guatemala"), ("GG", "Guernsey"), ("GN", "Guinea"),
        ("GW", "Guinea-Bissau"), ("GY", "Guyana"), ("HT", "Haiti"), ("HM", "Heard Island and McDonald Islands"), ("VA", "Holy See"),
        ("HN", "Honduras"), ("HK", "Hong Kong"), ("HU", "Hungary"), ("IS", "Iceland"), ("IN", "India"), ("ID", "Indonesia"), ("IR", "Iran"),
        ("IQ", "Iraq"), ("IE", "Ireland"), ("IM", "Isle of Man"), ("IL", "Israel"), ("IT", "Italy"), ("JM", "Jamaica"), ("JP", "Japan"),
        ("JE", "Jersey"), ("JO", "Jordan"), ("KZ", "Kazakhstan"), ("KE", "Kenya"), ("KI", "Kiribati"), ("KP", "Korea (North)"),
        ("KR", "Korea (South)"), ("XK", "Kosovo"), ("KW", "Kuwait"), ("KG", "Kyrgyzstan"), ("LA", "Laos"), ("LV", "Latvia"), ("LB", "Lebanon"),
        ("LS", "Lesotho"), ("LR", "Liberia"), ("LY", "Libya"), ("LI", "Liechtenstein"), ("LT", "Lithuania"), ("LU", "Luxembourg"),
        ("MO", "Macao"), ("MG", "Madagascar"), ("MW", "Malawi"), ("MY", "Malaysia"), ("MV", "Maldives"), ("ML", "Mali"), ("MT", "Malta"),
        ("MH", "Marshall Islands"), ("MQ", "Martinique"), ("MR", "Mauritania"), ("MU", "Mauritius"), ("YT", "Mayotte"), ("MX", "Mexico"),
        ("FM", "Micronesia"), ("MD", "Moldova"), ("MC", "Monaco"), ("MN", "Mongolia"), ("ME", "Montenegro"), ("MS", "Montserrat"),
        ("MA", "Morocco"), ("MZ", "Mozambique"), ("MM", "Myanmar"), ("NA", "Namibia"), ("NR", "Nauru"), ("NP", "Nepal"), ("NL", "Netherlands"),
        ("NC", "New Caledonia"), ("NZ", "New Zealand"), ("NI", "Nicaragua"), ("NE", "Niger"), ("NG", "Nigeria"), ("NU", "Niue"),
        ("NF", "Norfolk Island"), ("MK", "North Macedonia"), ("MP", "Northern Mariana Islands"), ("NO", "Norway"), ("OM", "Oman"),
        ("PK", "Pakistan"), ("PW", "Palau"), ("PS", "Palestine"), ("PA", "Panama"), ("PG", "Papua New Guinea"), ("PY", "Paraguay"),
        ("PE", "Peru"), ("PH", "Philippines"), ("PN", "Pitcairn"), ("PL", "Poland"), ("PT", "Portugal"), ("PR", "Puerto Rico"), ("QA", "Qatar"),
        ("RE", "Réunion"), ("RO", "Romania"), ("RU", "Russia"), ("RW", "Rwanda"), ("BL", "Saint Barthélemy"),
        ("SH", "Saint Helena, Ascension and Tristan da Cunha"), ("KN", "Saint Kitts and Nevis"), ("LC", "Saint Lucia"), ("MF", "Saint Martin"),
        ("PM", "Saint Pierre and Miquelon"), ("VC", "Saint Vincent and the Grenadines"), ("WS", "Samoa"), ("SM", "San Marino"),
        ("ST", "São Tomé and Príncipe"), ("SA", "Saudi Arabia"), ("SN", "Senegal"), ("RS", "Serbia"), ("SC", "Seychelles"), ("SL", "Sierra Leone"),
        ("SG", "Singapore"), ("SX", "Sint Maarten"), ("SK", "Slovakia"), ("SI", "Slovenia"), ("SB", "Solomon Islands"), ("SO", "Somalia"),
        ("ZA", "South Africa"), ("GS", "South Georgia and the South Sandwich Islands"), ("SS", "South Sudan"), ("ES", "Spain"), ("LK", "Sri Lanka"),
        ("SD", "Sudan"), ("SR", "Suriname"), ("SJ", "Svalbard and Jan Mayen"), ("SE", "Sweden"), ("CH", "Switzerland"), ("SY", "Syria"),
        ("TW", "Taiwan"), ("TJ", "Tajikistan"), ("TZ", "Tanzania"), ("TH", "Thailand"), ("TL", "Timor-Leste"), ("TG", "Togo"), ("TK", "Tokelau"),
        ("TO", "Tonga"), ("TT", "Trinidad and Tobago"), ("TN", "Tunisia"), ("TR", "Türkiye"), ("TM", "Turkmenistan"),
        ("TC", "Turks and Caicos Islands"), ("TV", "Tuvalu"), ("UG", "Uganda"), ("UA", "Ukraine"), ("AE", "United Arab Emirates"),
        ("GB", "United Kingdom"), ("US", "United States"), ("UM", "United States Minor Outlying Islands"), ("UY", "Uruguay"),
        ("UZ", "Uzbekistan"), ("VU", "Vanuatu"), ("VE", "Venezuela"), ("VN", "Viet Nam"), ("VG", "Virgin Islands (British)"),
        ("VI", "Virgin Islands (U.S.)"), ("WF", "Wallis and Futuna"), ("EH", "Western Sahara"), ("YE", "Yemen"), ("ZM", "Zambia"), ("ZW", "Zimbabwe"),
    ];

    public static bool IsValid(string? code) => Normalize(code) is not null;

    public static string? Normalize(string? code)
        => code is null ? null : All.FirstOrDefault(c => string.Equals(c.Code, code, StringComparison.OrdinalIgnoreCase)).Code;

    /// <summary>The country's currency as .NET knows it (e.g. "Indian Rupee (₹, INR)"), or null.</summary>
    public static string? Currency(string code)
    {
        try
        {
            var region = new RegionInfo(code);
            return $"{region.CurrencyEnglishName} ({region.CurrencySymbol}, {region.ISOCurrencySymbol})";
        }
        catch (ArgumentException)
        {
            return null;
        }
    }

    /// <summary>The system instruction for the user's country, or null when none is set.</summary>
    public static string? Instruction(string? code)
    {
        var (found, name) = All.FirstOrDefault(c => string.Equals(c.Code, code, StringComparison.OrdinalIgnoreCase));
        if (found is null)
        {
            return null;
        }
        var currency = Currency(found) is { } c ? $" and use the {c}" : "";
        return $"User's country: {name}. When local context matters — money, prices, laws and regulations, taxes, holidays, phone numbers, addresses, " +
               $"sample data — assume {name}{currency} unless the user says otherwise.";
    }
}
