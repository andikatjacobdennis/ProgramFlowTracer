namespace DocGen.Core.Models;

/// <summary>
/// Durable continuation state written at a hard context compaction (data/runs/{runId}/compactions/{sequence}.json).
/// It is built mostly deterministically from DocGen's own records (run, tool calls and results, commands,
/// investigation, servers, browser) — never from hidden reasoning — and validated before the run switches to the
/// compacted context. Each snapshot combines the latest durable state with what happened since the previous one;
/// it does not summarise the previous summary.
/// </summary>
public sealed class ContextCompactionSnapshot
{
    public string Id { get; set; } = Ids.New();
    public string RunId { get; set; } = "";
    public string UserId { get; set; } = "";
    public string ConversationId { get; set; } = "";
    public int Sequence { get; set; }
    public string? PreviousSnapshotId { get; set; }
    public int Iteration { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>hard | manual</summary>
    public string Reason { get; set; } = "hard";

    public int PreviousEstimatedTokens { get; set; }
    public int CompactedEstimatedTokens { get; set; }
    public int Budget { get; set; }

    /// <summary>The run's task: the user request that started it (verbatim, bounded).</summary>
    public string Goal { get; set; } = "";

    /// <summary>Every user message seen by the run, verbatim (bounded per message).</summary>
    public List<string> UserRequirements { get; set; } = [];

    /// <summary>Constraints and instructions carried by the system prompt (kept verbatim in the compacted context).</summary>
    public string ConstraintsNote { get; set; } = "";

    /// <summary>Tool actions performed so far, derived from the run's tool calls and results (cumulative).</summary>
    public List<string> CompletedWork { get; set; } = [];

    public int CompletedWorkTotal { get; set; }
    public List<string> FilesChanged { get; set; } = [];
    public List<string> ImportantSymbols { get; set; } = [];
    public List<string> RelevantResults { get; set; } = [];
    public List<string> BlobReferences { get; set; } = [];
    public List<string> Errors { get; set; } = [];
    public List<string> PendingApprovals { get; set; } = [];

    /// <summary>Excerpts of the assistant's visible text (plans and conclusions it stated), most recent last.</summary>
    public List<string> AssistantNotes { get; set; } = [];

    public string NextIntendedAction { get; set; } = "";

    /// <summary>Sections supplied by DocGen services: investigation/RCA, commands and tests, servers, browser.</summary>
    public List<CompactionSection> Sections { get; set; } = [];

    /// <summary>Checks the snapshot passed before it was used.</summary>
    public List<string> Validation { get; set; } = [];
}

public sealed class CompactionSection
{
    /// <summary>investigation | commands | servers | browser | …</summary>
    public string Name { get; set; } = "";

    public string Title { get; set; } = "";
    public string Content { get; set; } = "";

    /// <summary>True when live state exists that the continued run must know about (validation requires the section).</summary>
    public bool Required { get; set; }

    /// <summary>Items that must appear in the rendered snapshot (e.g. command ids, server ids, hypothesis ids).</summary>
    public List<string> MustMention { get; set; } = [];
}

/// <summary>Trusted context for building a compaction section.</summary>
public sealed class CompactionContext
{
    public required string UserId { get; init; }
    public required string RunId { get; init; }
    public string? ConversationId { get; init; }
    public string? ProjectId { get; init; }
}
