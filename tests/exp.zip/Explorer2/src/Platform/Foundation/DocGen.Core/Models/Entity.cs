using System.Text.RegularExpressions;

namespace DocGen.Core.Models;

/// <summary>Base type for every persisted entity.</summary>
public abstract class Entity
{
    public string Id { get; set; } = Ids.New();
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>Optimistic concurrency version, incremented on every successful write.</summary>
    public long Version { get; set; }
}

/// <summary>An entity that belongs to exactly one user. Ownership is enforced server-side.</summary>
public interface IOwnedEntity
{
    string Id { get; }
    string UserId { get; }
}

/// <summary>Identifier helpers. Identifiers double as file names, so they are strictly validated.</summary>
public static partial class Ids
{
    public static string New() => Guid.NewGuid().ToString("N");

    public static bool IsValid(string? id) => id is not null && IdPattern().IsMatch(id);

    public static string Require(string? id, string name = "id")
    {
        if (!IsValid(id))
        {
            throw new Exceptions.ValidationException($"Invalid {name}.");
        }
        return id!;
    }

    [GeneratedRegex("^[A-Za-z0-9_-]{1,64}$")]
    private static partial Regex IdPattern();
}
