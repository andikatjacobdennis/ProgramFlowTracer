namespace DocGen.Core.Models;

/// <summary>
/// A persisted human-approval request (data/approvals/{id}.json). It holds only what is needed to show the
/// request and, if it is approved after a restart, to execute that single tool call once. The full
/// arguments are cleared as soon as the approval reaches a final state.
/// </summary>
public sealed class ApprovalRecord : Entity, IOwnedEntity
{
    public string UserId { get; set; } = "";
    public string RunId { get; set; } = "";
    public string ConversationId { get; set; } = "";
    public string ToolCallId { get; set; } = "";
    public string ToolName { get; set; } = "";
    public ToolRiskLevel RiskLevel { get; set; }

    /// <summary>Human description, e.g. "Write generated/notes.md".</summary>
    public string Action { get; set; } = "";

    /// <summary>Redacted, bounded argument preview for display.</summary>
    public string ArgumentsPreview { get; set; } = "";

    /// <summary>Raw tool arguments; kept only while the approval is actionable, then cleared.</summary>
    public string? Arguments { get; set; }

    public ApprovalStatus Status { get; set; } = ApprovalStatus.Pending;
    public DateTime ExpiresAt { get; set; }
    public DateTime? DecidedAt { get; set; }

    /// <summary>Set when a pending approval survived a restart; its original agent run is no longer active.</summary>
    public DateTime? RecoveredAt { get; set; }

    public DateTime? CompletedAt { get; set; }
    public string? ResultPreview { get; set; }
    public string? Note { get; set; }

    public bool IsFinal => Status is ApprovalStatus.Denied or ApprovalStatus.Expired or ApprovalStatus.Cancelled
        or ApprovalStatus.Completed or ApprovalStatus.Failed or ApprovalStatus.Interrupted;
}
