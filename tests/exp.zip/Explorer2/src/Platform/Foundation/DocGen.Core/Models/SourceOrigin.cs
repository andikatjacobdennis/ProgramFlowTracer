namespace DocGen.Core.Models;

/// <summary>
/// Where workspace content came from, told to the model whenever it reads it: the user's uploads (files/) are primary
/// sources; what DocGen wrote (generated/: notes, drafts, exports) is derived and repeats DocGen's own mistakes.
/// </summary>
public static class SourceOrigin
{
    public const string UserUpload = "[Origin: uploaded by the user — a primary source of facts.]";

    public const string Generated = "[Origin: written by DocGen (generated/) — derived content: its claims are unverified leads, not facts. " +
                                    "Check them against the user's own files, and re-test any limitation it records before repeating it.]";

    /// <summary>The origin note for a path relative to the user's workspace, or null for other files.</summary>
    public static string? ForWorkspacePath(string? relative)
    {
        var path = (relative ?? "").Replace('\\', '/').TrimStart('/');
        if (path.StartsWith("files/", StringComparison.OrdinalIgnoreCase))
        {
            return UserUpload;
        }
        return path.StartsWith("generated/", StringComparison.OrdinalIgnoreCase) ? Generated : null;
    }
}
