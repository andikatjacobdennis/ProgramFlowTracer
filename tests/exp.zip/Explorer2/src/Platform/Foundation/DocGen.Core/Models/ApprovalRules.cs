namespace DocGen.Core.Models;

/// <summary>
/// One kind of action the approval policy decides about, with whether it runs without a prompt in each approval mode
/// by default. Locked kinds always ask, whatever the mode or the user's rules say.
/// </summary>
public sealed record ApprovalCategory(string Key, string Label, string Description, bool Minimal, bool Balanced, bool Strict, bool Locked = false)
{
    public bool DefaultFor(string mode) => mode switch
    {
        ApprovalModes.Minimal => Minimal,
        ApprovalModes.Strict => Strict,
        _ => Balanced,
    };
}

/// <summary>
/// The kinds of actions that can need approval (Settings → Agent → Approvals). Each approval mode is a set of defaults;
/// an administrator can change any unlocked kind per mode (<see cref="ApplicationSettings.ApprovalRules"/>).
/// </summary>
public static class ApprovalCategories
{
    public const string ChatFolder = "chatFolder";
    public const string OtherFolders = "otherFolders";
    public const string WebReads = "webReads";
    public const string BrowseExternal = "browseExternal";
    public const string Install = "install";
    public const string Network = "network";
    public const string SystemChanges = "system";
    public const string Outbound = "outbound";
    public const string GitCommitPush = "gitCommitPush";
    public const string Destructive = "destructive";

    public static readonly IReadOnlyList<ApprovalCategory> All =
    [
        new(ChatFolder, "Work in this chat's folder",
            "Edits, builds, tests, migrations, scripts, local tools and dev servers in the workspace or the chat's working folder.",
            Minimal: true, Balanced: true, Strict: false),
        new(OtherFolders, "Work in other folders",
            "Edits and commands in registered folders other than the chat's working folder.",
            Minimal: true, Balanced: false, Strict: false),
        new(WebReads, "Reading the web",
            "Plain web page reads and searches (GET requests without credentials).",
            Minimal: true, Balanced: true, Strict: false),
        new(BrowseExternal, "Browsing external websites",
            "Opening and using external sites in DocGen's browser.",
            Minimal: true, Balanced: false, Strict: false),
        new(Install, "Installing software",
            "Package and tool installs: npm/pip/winget/choco install, dotnet tool install, Install-Module.",
            Minimal: false, Balanced: false, Strict: false),
        new(Network, "Commands that use the network",
            "Downloads, curl/wget, ssh/scp, cloud CLIs, web requests from scripts.",
            Minimal: false, Balanced: false, Strict: false),
        new(SystemChanges, "System changes",
            "Services, registry, scheduled tasks, permissions, credentials and other machine-wide settings.",
            Minimal: false, Balanced: false, Strict: false),
        new(Outbound, "Sending data out",
            "Uploads, API writes (POST/PUT/DELETE, requests with credentials) and TCP sends.",
            Minimal: false, Balanced: false, Strict: false),
        new(GitCommitPush, "Git commit and push",
            "Always asks: only you can decide to commit or publish code.",
            Minimal: false, Balanced: false, Strict: false, Locked: true),
        new(Destructive, "Destructive actions",
            "Always asks or is blocked: wiping disks, deleting accounts, anything DocGen cannot undo.",
            Minimal: false, Balanced: false, Strict: false, Locked: true),
    ];

    public static ApprovalCategory? Find(string? key) => All.FirstOrDefault(c => string.Equals(c.Key, key, StringComparison.OrdinalIgnoreCase));

    /// <summary>Whether actions of this kind run without a prompt in the current mode (the administrator's rule, else the mode default).</summary>
    public static bool RunsWithoutPrompt(ApplicationSettings app, string key)
    {
        var category = Find(key);
        if (category is null || category.Locked)
        {
            return false;
        }
        var mode = ApprovalModes.IsValid(app.ApprovalMode) ? app.ApprovalMode : ApprovalModes.Balanced;
        return app.ApprovalRules.TryGetValue(mode, out var rules) && rules.TryGetValue(category.Key, out var allow)
            ? allow
            : category.DefaultFor(mode);
    }
}
