namespace DocGen.Core.Models;

/// <summary>
/// A character to talk to in conversation mode: who they are, how they speak, which cartoon face and browser voice they
/// use. A conversation started with a persona answers in character, briefly and without tools.
/// </summary>
public sealed class Persona : Entity, IOwnedEntity
{
    public const int MaxNameLength = 60;
    public const int MaxTaglineLength = 120;
    public const int MaxProfileLength = 4000;
    public const int MaxStyleLength = 1000;
    public const int MaxGreetingLength = 300;

    public string UserId { get; set; } = "";
    public string Name { get; set; } = "";

    /// <summary>One line shown under the name ("Retired sea captain who loves a good story").</summary>
    public string Tagline { get; set; } = "";

    /// <summary>Id of a built-in cartoon face (wwwroot/js/avatars.js).</summary>
    public string Avatar { get; set; } = "";

    /// <summary>Who the persona is: background, personality, interests, what they know and care about.</summary>
    public string Profile { get; set; } = "";

    /// <summary>How they talk: tone, vocabulary, pace, habits.</summary>
    public string SpeakingStyle { get; set; } = "";

    /// <summary>First thing they say when a conversation starts (empty: the user speaks first).</summary>
    public string Greeting { get; set; } = "";

    /// <summary>Browser speech-synthesis voice name (empty: the browser's default voice for the language).</summary>
    public string Voice { get; set; } = "";

    /// <summary>Speaking rate (0.5–2) and pitch (0–2) for speech synthesis.</summary>
    public double Rate { get; set; } = 1;
    public double Pitch { get; set; } = 1;
}
