namespace DocGen.Core.Models;

public sealed class ToolCall
{
    public string Id { get; set; } = "call_" + Ids.New()[..12];
    public string Name { get; set; } = "";

    /// <summary>Raw JSON object of arguments as produced by the model. Untrusted.</summary>
    public string Arguments { get; set; } = "{}";
}

public sealed class ToolResult
{
    public string ToolCallId { get; set; } = "";
    public string ToolName { get; set; } = "";
    public bool Success { get; set; }
    public string Content { get; set; } = "";
    public string? Error { get; set; }
    public bool Truncated { get; set; }
    public List<Citation>? Citations { get; set; }

    /// <summary>Workspace/artifact changes made by the tool, shown on the Agent Run page.</summary>
    public List<FileChange>? FileChanges { get; set; }

    /// <summary>Observable activity records produced by the tool (command started/finished, browser actions…).</summary>
    public List<ActivityRecord>? Activities { get; set; }

    public static ToolResult Ok(ToolCall call, string content, List<Citation>? citations = null) => new()
    {
        ToolCallId = call.Id,
        ToolName = call.Name,
        Success = true,
        Content = content,
        Citations = citations,
    };

    public static ToolResult Fail(ToolCall call, string error) => new()
    {
        ToolCallId = call.Id,
        ToolName = call.Name,
        Success = false,
        Content = "Error: " + error,
        Error = error,
    };
}

/// <summary>Audit record of one tool invocation inside an agent run.</summary>
public sealed class ToolExecution
{
    public string Id { get; set; } = Ids.New();
    public string ToolCallId { get; set; } = "";
    public string ToolName { get; set; } = "";
    public ToolRiskLevel RiskLevel { get; set; }
    public PermissionDecision Decision { get; set; }
    public bool? ApprovedByUser { get; set; }
    public string? ApprovalId { get; set; }
    public string ArgumentsPreview { get; set; } = "";
    public ToolExecutionStatus Status { get; set; } = ToolExecutionStatus.Pending;
    public DateTime StartedAt { get; set; } = DateTime.UtcNow;
    public DateTime? CompletedAt { get; set; }
    public long DurationMs { get; set; }
    public string? ResultPreview { get; set; }
    public string? Error { get; set; }

    /// <summary>True once the tool was actually invoked. An interrupted execution that started has an unknown outcome.</summary>
    public bool? ExecutionStarted { get; set; }
}

/// <summary>
/// An externally observable action recorded in a run's activity history (commands, dev servers, browser actions,
/// context compaction). Activity records describe what DocGen did — never hidden reasoning.
/// </summary>
public sealed class ActivityRecord
{
    public string Id { get; set; } = Ids.New()[..12];

    /// <summary>Event name, e.g. command_completed, browser_navigated, context_compaction_completed.</summary>
    public string Type { get; set; } = "";

    public string Title { get; set; } = "";
    public string? Detail { get; set; }
    public string? ToolCallId { get; set; }

    /// <summary>Small structured facts (ids, URLs, exit codes, viewport…). Values are redacted and bounded.</summary>
    public Dictionary<string, string> Data { get; set; } = new(StringComparer.Ordinal);

    public DateTime At { get; set; } = DateTime.UtcNow;
}

/// <summary>A file or artifact created/modified by a tool, with line-count deltas.</summary>
public sealed class FileChange
{
    public string Path { get; set; } = "";

    /// <summary>created | modified | deleted | artifact</summary>
    public string Kind { get; set; } = "modified";

    public int LinesAdded { get; set; }
    public int LinesRemoved { get; set; }
    public string? ArtifactId { get; set; }
}

/// <summary>
/// One observable step of a run (model call, tool call, approval, error). This is what DocGen *did*,
/// never hidden model reasoning.
/// </summary>
public sealed class RunStep
{
    public string Id { get; set; } = Ids.New()[..12];

    /// <summary>model | tool | approval | notice | error</summary>
    public string Kind { get; set; } = "notice";

    public string Title { get; set; } = "";

    /// <summary>running | succeeded | failed | denied | waiting | cancelled</summary>
    public string Status { get; set; } = "running";

    public DateTime StartedAt { get; set; } = DateTime.UtcNow;
    public DateTime? CompletedAt { get; set; }
    public long DurationMs { get; set; }
    public string? ToolName { get; set; }
    public string? ToolCallId { get; set; }
    public ToolRiskLevel? RiskLevel { get; set; }

    /// <summary>Redacted argument preview (tools) — bounded.</summary>
    public string? Input { get; set; }

    /// <summary>Bounded output preview.</summary>
    public string? Output { get; set; }

    public List<FileChange>? FileChanges { get; set; }
}

/// <summary>Persistent record of one agent execution. Never contains hidden reasoning.</summary>
public sealed class AgentRun : Entity, IOwnedEntity
{
    public string UserId { get; set; } = "";
    public string ConversationId { get; set; } = "";
    public string? ProjectId { get; set; }

    /// <summary>Short human title derived from the user's request.</summary>
    public string Title { get; set; } = "";

    public List<RunStep> Steps { get; set; } = [];
    public string? UserMessageId { get; set; }
    public string? AssistantMessageId { get; set; }
    public string ModelId { get; set; } = "";
    public string ProviderId { get; set; } = "";
    public RunStatus Status { get; set; } = RunStatus.Running;
    public DateTime StartedAt { get; set; } = DateTime.UtcNow;
    public DateTime? CompletedAt { get; set; }
    public int Iterations { get; set; }
    public int ToolCallCount { get; set; }
    public List<ToolExecution> ToolExecutions { get; set; } = [];
    public UsageRecord Usage { get; set; } = new();
    public string? Error { get; set; }
    public string Source { get; set; } = "web";

    /// <summary>Why the run stopped abnormally (e.g. the process stopped). Null for normal completions.</summary>
    public string? InterruptionReason { get; set; }

    /// <summary>When startup reconciliation closed this run. Null if it finished normally.</summary>
    public DateTime? ReconciledAt { get; set; }

    /// <summary>How many times the run was continued after an interruption.</summary>
    public int ResumeCount { get; set; }

    public DateTime? LastResumedAt { get; set; }

    public RunTelemetry Telemetry { get; set; } = new();

    /// <summary>Activity history (bounded): commands, servers, browser actions, context pressure and compaction.</summary>
    public List<ActivityRecord> Activities { get; set; } = [];

    public const int MaxActivities = 1000;

    public void AddActivity(ActivityRecord activity)
    {
        Activities.Add(activity);
        if (Activities.Count > MaxActivities)
        {
            Activities.RemoveRange(0, Activities.Count - MaxActivities);
        }
    }
}

/// <summary>Token usage as reported by the provider. Null values mean "not reported" — never invented.</summary>
public sealed class UsageRecord
{
    public int? InputTokens { get; set; }
    public int? OutputTokens { get; set; }
    public int? TotalTokens { get; set; }

    /// <summary>Input tokens the provider served from its prompt cache (billed at a much lower rate); null when not reported.</summary>
    public int? CachedInputTokens { get; set; }
    public string? ModelId { get; set; }
    public string? ProviderId { get; set; }
    public long DurationMs { get; set; }

    public void Add(UsageRecord? other)
    {
        if (other is null)
        {
            return;
        }
        InputTokens = Sum(InputTokens, other.InputTokens);
        OutputTokens = Sum(OutputTokens, other.OutputTokens);
        CachedInputTokens = Sum(CachedInputTokens, other.CachedInputTokens);
        TotalTokens = Sum(TotalTokens, other.TotalTokens ?? Sum(other.InputTokens, other.OutputTokens));
        DurationMs += other.DurationMs;
    }

    public UsageRecord Clone() => (UsageRecord)MemberwiseClone();

    private static int? Sum(int? a, int? b) => a is null && b is null ? null : (a ?? 0) + (b ?? 0);
}

/// <summary>
/// Measured performance data for one run (shown on Run Details). Only observed values; nothing is estimated except
/// where named (context tokens use the documented chars/4 estimate).
/// </summary>
public sealed class RunTelemetry
{
    public int ModelCalls { get; set; }
    public long ModelTimeMs { get; set; }
    public int ToolCalls { get; set; }
    public long ToolTimeMs { get; set; }

    /// <summary>Wall-clock time the agent loop spent running, accumulated across resumes.</summary>
    public long RuntimeMs { get; set; }

    public int ContextTokensLast { get; set; }
    public int ContextTokensPeak { get; set; }

    /// <summary>Tool results replaced by a reference to keep the context inside its budget.</summary>
    public int ElidedToolResults { get; set; }

    public int ParallelBatches { get; set; }
    public int MaxParallelism { get; set; }
    public int GuardBlocks { get; set; }
    public int LargeArgumentsExternalized { get; set; }
    public Dictionary<string, ToolTelemetry> Tools { get; set; } = new(StringComparer.Ordinal);

    /// <summary>Skill usage in this run (null when no skills were available).</summary>
    public SkillTelemetry? Skills { get; set; }

    /// <summary>Estimated tokens per context section in the latest model call (system, pinned, history, tools…).</summary>
    public Dictionary<string, int> ContextSections { get; set; } = new(StringComparer.Ordinal);

    /// <summary>The model's context window (tokens) for the latest call.</summary>
    public int ContextCapacity { get; set; }

    /// <summary>Tokens reserved for the model's output.</summary>
    public int ReservedOutputTokens { get; set; }

    /// <summary>Input budget = min(configured maximum, capacity − reserved output).</summary>
    public int ContextBudget { get; set; }

    /// <summary>Estimated input tokens / budget for the latest call. Estimated: ~4 characters per token.</summary>
    public double ContextUtilization { get; set; }

    public double ContextUtilizationPeak { get; set; }

    public string ContextEstimateMethod { get; set; } = "estimated (~4 characters per token)";

    public int SoftCompactions { get; set; }
    public int HardCompactions { get; set; }
    public int FailedCompactions { get; set; }

    /// <summary>Per-call context history (bounded, most recent last).</summary>
    public List<ContextSample> ContextHistory { get; set; } = [];

    public void RecordContext(ContextSample sample)
    {
        ContextHistory.Add(sample);
        if (ContextHistory.Count > 200)
        {
            ContextHistory.RemoveRange(0, ContextHistory.Count - 200);
        }
    }

    public void RecordTool(string name, long durationMs, bool success)
    {
        ToolCalls++;
        ToolTimeMs += durationMs;
        if (!Tools.TryGetValue(name, out var stats))
        {
            stats = new ToolTelemetry();
            Tools[name] = stats;
        }
        stats.Count++;
        stats.TotalMs += durationMs;
        stats.MaxMs = Math.Max(stats.MaxMs, durationMs);
        if (!success)
        {
            stats.Failures++;
        }
    }
}

public sealed class ToolTelemetry
{
    public int Count { get; set; }
    public long TotalMs { get; set; }
    public long MaxMs { get; set; }
    public int Failures { get; set; }
}

/// <summary>Context accounting for one model call.</summary>
public sealed class ContextSample
{
    public int Iteration { get; set; }
    public int EstimatedTokens { get; set; }
    public int Budget { get; set; }
    public double Utilization { get; set; }

    /// <summary>none | soft | hard | manual | failed</summary>
    public string Action { get; set; } = "none";

    public int? TokensAfter { get; set; }
    public DateTime At { get; set; } = DateTime.UtcNow;
}

/// <summary>What skills cost and did in a run: counts and token estimates only, never skill or user content.</summary>
public sealed class SkillTelemetry
{
    /// <summary>Skills that were on (their metadata was in the system prompt).</summary>
    public int Available { get; set; }

    /// <summary>Estimated tokens of that metadata (the standing cost of installed skills).</summary>
    public int MetadataTokens { get; set; }

    public List<string> Activated { get; set; } = [];
    public List<string> Explicit { get; set; } = [];

    /// <summary>Estimated tokens of the instructions loaded (the cost of activation).</summary>
    public int InstructionTokens { get; set; }

    public int ResourceLoads { get; set; }
}
