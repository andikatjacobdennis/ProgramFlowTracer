using System.Text;
using System.Text.Json.Serialization;

namespace DocGen.Core.Models;

/// <summary>Conversation metadata. Messages are stored separately, one file per message.</summary>
public sealed class Conversation : Entity, IOwnedEntity
{
    public string UserId { get; set; } = "";
    public string Title { get; set; } = "New conversation";
    public string? ProjectId { get; set; }
    public bool Archived { get; set; }
    public string? ModelId { get; set; }

    /// <summary>The working folder (repository name) of this chat; null means the workspace. Set by the last request that named one.</summary>
    public string? Repository { get; set; }

    /// <summary>The working folder the last request ran in, so a switch (even one made before sending) is noticed.</summary>
    public string? LastRunRepository { get; set; }

    /// <summary>Skills used in this conversation, most recent first (the model is reminded of them on later turns).</summary>
    public List<string> ActiveSkills { get; set; } = [];

    /// <summary>Conversation mode: the persona who answers (in character, briefly, without tools). Fixed when the chat starts.</summary>
    public string? PersonaId { get; set; }

    /// <summary>Leaf of the currently displayed branch of the message tree.</summary>
    public string? ActiveLeafMessageId { get; set; }

    public int MessageCount { get; set; }
    public DateTime? LastMessageAt { get; set; }

    /// <summary>Deterministic summary of older messages that no longer fit the context window.</summary>
    public string? Summary { get; set; }

    public string? BranchedFromConversationId { get; set; }
    public string? BranchedFromMessageId { get; set; }
}

public sealed class Message : Entity, IOwnedEntity
{
    public string UserId { get; set; } = "";
    public string ConversationId { get; set; } = "";
    public string? ParentMessageId { get; set; }
    public MessageRole Role { get; set; }
    public List<MessagePart> Parts { get; set; } = [];
    public string? ModelId { get; set; }
    public string? ProviderId { get; set; }
    public string? RunId { get; set; }
    public UsageRecord? Usage { get; set; }
    public List<ToolCall> ToolCalls { get; set; } = [];
    public List<ToolResult> ToolResults { get; set; } = [];
    public List<Citation> Citations { get; set; } = [];

    /// <summary>Skills activated while writing this reply (shown as "Skills used"; no instructions or reasoning are stored).</summary>
    public List<SkillUse> SkillsUsed { get; set; } = [];
    public List<AttachmentRef> Attachments { get; set; } = [];
    public MessageStatus Status { get; set; } = MessageStatus.Complete;
    public string? Error { get; set; }

    /// <summary>Set when generation was cut off because the DocGen process stopped (partial content is kept).</summary>
    public DateTime? InterruptedAt { get; set; }

    /// <summary>Concatenated visible text of the message.</summary>
    [JsonIgnore]
    public string Text
    {
        get
        {
            var sb = new StringBuilder();
            foreach (var part in Parts)
            {
                if (part.Type == MessagePartType.Text && part.Text is not null)
                {
                    sb.Append(part.Text);
                }
            }
            return sb.ToString();
        }
    }

    public static Message CreateText(string userId, string conversationId, MessageRole role, string text, string? parentId) => new()
    {
        UserId = userId,
        ConversationId = conversationId,
        Role = role,
        ParentMessageId = parentId,
        Parts = [MessagePart.FromText(text)],
    };
}

public sealed class MessagePart
{
    public MessagePartType Type { get; set; }
    public string? Text { get; set; }
    public string? ToolCallId { get; set; }
    public string? ToolName { get; set; }

    public static MessagePart FromText(string text) => new() { Type = MessagePartType.Text, Text = text };
}

public sealed class AttachmentRef
{
    public string FileId { get; set; } = "";
    public string FileName { get; set; } = "";
    public string ContentType { get; set; } = "text/plain";
    public long SizeBytes { get; set; }
}

public sealed class Citation
{
    public string Title { get; set; } = "";
    public string? Url { get; set; }
    public string? Snippet { get; set; }
    public string? Source { get; set; }
}

/// <summary>A skill used in a reply: which one, where it came from, and whether the user picked it.</summary>
public sealed class SkillUse
{
    public string Id { get; set; } = "";
    public string DisplayName { get; set; } = "";

    /// <summary>built-in | workspace | personal</summary>
    public string Scope { get; set; } = "";

    public bool Explicit { get; set; }
}
