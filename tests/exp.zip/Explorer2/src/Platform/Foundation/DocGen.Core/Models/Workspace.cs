namespace DocGen.Core.Models;

public sealed class Project : Entity, IOwnedEntity
{
    public string UserId { get; set; } = "";
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";

    /// <summary>UI accent colour (blue | purple | red | orange | yellow | green | teal | gray).</summary>
    public string Color { get; set; } = "blue";

    /// <summary>Automatically added to the context of every conversation in the project.</summary>
    public string Instructions { get; set; } = "";

    public List<string> ConversationIds { get; set; } = [];
    public List<string> FileIds { get; set; } = [];
    public List<string> ArtifactIds { get; set; } = [];
}

/// <summary>Metadata for a file stored in a user's workspace. Content lives on disk, never in JSON.</summary>
public sealed class StoredFile : Entity, IOwnedEntity
{
    public string UserId { get; set; } = "";

    /// <summary>Sanitised display name supplied by the user. Never used as a physical path.</summary>
    public string FileName { get; set; } = "";

    /// <summary>Server-generated physical file name.</summary>
    public string StoredName { get; set; } = "";

    /// <summary>Path relative to the user's workspace root, e.g. files/{storedName}.</summary>
    public string RelativePath { get; set; } = "";

    public string ContentType { get; set; } = "text/plain";
    public long SizeBytes { get; set; }
    public string Sha256 { get; set; } = "";
    public string? ProjectId { get; set; }
    public string Source { get; set; } = "upload";
}

public sealed class Artifact : Entity, IOwnedEntity
{
    public string UserId { get; set; } = "";
    public string Title { get; set; } = "";
    public ArtifactType Type { get; set; } = ArtifactType.Markdown;
    public int CurrentVersion { get; set; }
    public string? ConversationId { get; set; }
    public string? ProjectId { get; set; }
    public List<ArtifactVersion> Versions { get; set; } = [];
}

public sealed class ArtifactVersion
{
    public int Number { get; set; }
    public string FileName { get; set; } = "";
    public long SizeBytes { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    /// <summary>user | agent</summary>
    public string CreatedBy { get; set; } = "user";
    public string? Note { get; set; }
}
