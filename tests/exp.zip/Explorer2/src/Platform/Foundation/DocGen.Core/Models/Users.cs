namespace DocGen.Core.Models;

public sealed class User : Entity
{
    public string UserName { get; set; } = "";
    public string NormalizedUserName { get; set; } = "";
    public string DisplayName { get; set; } = "";
    public string? Email { get; set; }

    /// <summary>PBKDF2 hash in a self-describing format. Never a plaintext password.</summary>
    public string PasswordHash { get; set; } = "";

    /// <summary>Rotated whenever credentials change; invalidates existing sessions.</summary>
    public string SecurityStamp { get; set; } = Ids.New();

    public bool IsAdmin { get; set; }

    /// <summary>SHA-256 hash of the user's TCP access token (the token itself is shown once).</summary>
    public string? TcpTokenHash { get; set; }
    public DateTime? TcpTokenCreatedAt { get; set; }

    public UserPreferences Preferences { get; set; } = new();
}

public sealed class UserPreferences
{
    /// <summary>light | dark | system</summary>
    public string Theme { get; set; } = "system";
    public string? DefaultModelId { get; set; }

    /// <summary>Reply language as a tag from <see cref="ResponseLanguages"/>; English (India) by default; null = match the user's message.</summary>
    public string? Language { get; set; } = "en-IN";

    /// <summary>Country code from <see cref="UserCountries"/>; India by default. Empty = no country context.</summary>
    public string? Country { get; set; } = UserCountries.Default;

    // Regional format (Windows 11 style). Null = follow the country / regional format / this PC.

    /// <summary>Culture whose date, time and number conventions are used (e.g. en-IN); null = the country's.</summary>
    public string? RegionalFormat { get; set; }

    /// <summary>Windows or IANA time zone id; null = this PC's time zone.</summary>
    public string? TimeZone { get; set; }

    public string? ShortDate { get; set; }
    public string? LongDate { get; set; }
    public string? ShortTime { get; set; }
    public string? LongTime { get; set; }

    /// <summary>Monday … Sunday; null = the regional format's.</summary>
    public string? FirstDayOfWeek { get; set; }

    /// <summary>metric | imperial; null = the regional format's.</summary>
    public string? Measurement { get; set; }

    /// <summary>ISO 4217 currency code (e.g. INR, USD); null = the country's currency.</summary>
    public string? Currency { get; set; }

    /// <summary>Terminal suggestions (grey text to accept with →): ai (history, then the model) | history | off.</summary>
    public string TerminalSuggestions { get; set; } = "ai";

    /// <summary>Model for AI terminal suggestions; null = the default model.</summary>
    public string? TerminalSuggestionModelId { get; set; }

    /// <summary>How long typing must pause before an AI suggestion is requested.</summary>
    public int TerminalSuggestionDelayMs { get; set; } = 400;

    /// <summary>Spell check (squiggly underlines) in text boxes.</summary>
    public bool SpellCheck { get; set; } = true;

    /// <summary>Whether the terminal was left open, per working folder (e.g. "workspace", a repository name).</summary>
    public Dictionary<string, bool> TerminalOpen { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}

/// <summary>A server-side login session referenced from the authentication cookie.</summary>
public sealed class Session : Entity, IOwnedEntity
{
    public string UserId { get; set; } = "";
    public DateTime ExpiresAt { get; set; }
    public string? UserAgent { get; set; }
    public string? IpAddress { get; set; }
    public bool Revoked { get; set; }
}
