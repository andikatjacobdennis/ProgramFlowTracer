namespace DocGen.Core.Models;

public enum MessageRole
{
    System,
    User,
    Assistant,
    Tool,
}

public enum MessageStatus
{
    Pending,
    Streaming,
    Complete,
    Cancelled,
    Error,
}

public enum MessagePartType
{
    Text,
    ToolCall,
    ToolResult,
    Notice,
}

public enum RunStatus
{
    Running,
    AwaitingApproval,
    Completed,
    Cancelled,
    Failed,
    LimitReached,

    /// <summary>The DocGen process stopped before the run finished (set by startup reconciliation).</summary>
    Interrupted,
}

public enum ToolRiskLevel
{
    ReadOnly,
    Write,
    External,
    Sensitive,
    Destructive,
}

public enum ToolExecutionStatus
{
    Pending,
    AwaitingApproval,
    Approved,
    Expired,
    Denied,
    Running,
    Succeeded,
    Failed,
    TimedOut,
    Cancelled,

    /// <summary>Execution may have started but its outcome was lost when the process stopped. Never retried automatically.</summary>
    Interrupted,
}

public enum PermissionDecision
{
    Allow,
    Ask,
    Deny,
}

public enum ArtifactType
{
    Text,
    Markdown,
    Html,
    Css,
    JavaScript,
    CSharp,
    Json,

    /// <summary>A screenshot (content is a data: URL). Created by browser verification, never by artifact_create.</summary>
    Image,
}

public static class ArtifactTypes
{
    public static string Extension(ArtifactType type) => type switch
    {
        ArtifactType.Markdown => ".md",
        ArtifactType.Html => ".html",
        ArtifactType.Css => ".css",
        ArtifactType.JavaScript => ".js",
        ArtifactType.CSharp => ".cs",
        ArtifactType.Json => ".json",
        ArtifactType.Image => ".img.txt",
        _ => ".txt",
    };
}

/// <summary>
/// Lifecycle of a persisted approval. Transitions are one-way and guarded, so an approved action can
/// execute at most once: Pending → Approved → Executing → Completed | Failed.
/// </summary>
public enum ApprovalStatus
{
    Pending,
    Approved,
    Denied,
    Expired,
    Cancelled,
    Executing,
    Completed,
    Failed,

    /// <summary>Approved or executing when the process stopped; never executed again automatically.</summary>
    Interrupted,
}
