using System.Globalization;
using System.Text.Json.Serialization;

namespace DocGen.Core.Models;

/// <summary>
/// The user's regional settings, resolved like Windows 11 (Settings → Time &amp; language → Language &amp; region):
/// a regional format (culture) that follows the country unless chosen, a time zone (this PC's unless chosen), and
/// optional overrides for short/long date, short/long time, the first day of the week and the measurement system.
/// </summary>
public sealed record RegionalSettings(
    string Format,
    string FormatName,
    string TimeZoneId,
    string TimeZoneName,
    string? IanaTimeZone,
    string ShortDate,
    string LongDate,
    string ShortTime,
    string LongTime,
    DayOfWeek FirstDayOfWeek,
    string Measurement,
    string? Currency,
    string? CurrencyCode = null,
    string? CurrencySymbol = null,
    string? CurrencyExample = null)
{
    [JsonIgnore]
    public CultureInfo Culture => CultureInfo.GetCultureInfo(Format);

    [JsonIgnore]
    public TimeZoneInfo TimeZone => Regional.FindTimeZone(TimeZoneId) ?? TimeZoneInfo.Local;
}

public static class Regional
{
    public const string Metric = "metric";
    public const string Imperial = "imperial";

    /// <summary>The regional format a country uses by default: English for that country when it exists, else its first culture.</summary>
    public static string DefaultFormatFor(string? country)
    {
        if (string.IsNullOrEmpty(country))
        {
            return CultureInfo.CurrentCulture.Name is { Length: > 0 } current ? current : "en-US";
        }
        var english = "en-" + country.ToUpperInvariant();
        if (IsValidFormat(english))
        {
            return english;
        }
        return CultureInfo.GetCultures(CultureTypes.SpecificCultures)
                   .FirstOrDefault(c => c.Name.EndsWith("-" + country, StringComparison.OrdinalIgnoreCase))?.Name
               ?? "en-US";
    }

    public static bool IsValidFormat(string? tag) => ResponseLanguages.Normalize(tag) is not null;

    public static TimeZoneInfo? FindTimeZone(string? id)
    {
        if (string.IsNullOrWhiteSpace(id))
        {
            return null;
        }
        try
        {
            return TimeZoneInfo.FindSystemTimeZoneById(id);
        }
        catch (Exception ex) when (ex is TimeZoneNotFoundException or InvalidTimeZoneException)
        {
            return null;
        }
    }

    /// <summary>A date/time pattern is accepted when it formats without error, is short, and uses only pattern letters and separators.</summary>
    public static bool IsValidPattern(string? pattern)
    {
        if (string.IsNullOrWhiteSpace(pattern) || pattern.Length > 40 || pattern.Any(c => char.IsControl(c)))
        {
            return false;
        }
        try
        {
            _ = new DateTime(2026, 12, 31, 15, 4, 5).ToString(pattern, CultureInfo.InvariantCulture);
            return true;
        }
        catch (FormatException)
        {
            return false;
        }
    }

    /// <summary>Resolves the user's settings: explicit choices first, then the regional format's own conventions.</summary>
    public static RegionalSettings Resolve(UserPreferences preferences)
    {
        var format = IsValidFormat(preferences.RegionalFormat) ? ResponseLanguages.Normalize(preferences.RegionalFormat)! : DefaultFormatFor(preferences.Country);
        var culture = CultureInfo.GetCultureInfo(format);
        var dtf = culture.DateTimeFormat;
        var zone = FindTimeZone(preferences.TimeZone) ?? TimeZoneInfo.Local;
        var iana = zone.HasIanaId ? zone.Id : TimeZoneInfo.TryConvertWindowsIdToIanaId(zone.Id, out var converted) ? converted : null;
        RegionInfo? region = null;
        try
        {
            region = new RegionInfo(format);
        }
        catch (ArgumentException)
        {
            // Neutral or unusual culture: no region information.
        }
        var measurement = preferences.Measurement is Metric or Imperial ? preferences.Measurement : region is { IsMetric: false } ? Imperial : Metric;
        // Currency: the user's choice, else the country's, else the regional format's.
        var code = FindCurrency(preferences.Currency)?.Code
                   ?? (string.IsNullOrEmpty(preferences.Country) ? null : CountryCurrency(preferences.Country))
                   ?? region?.ISOCurrencySymbol;
        var money = FindCurrency(code);
        var currency = money is null ? null : $"{money.Name} ({money.Symbol}, {money.Code})";
        return new RegionalSettings(
            format,
            culture.EnglishName,
            zone.Id,
            zone.DisplayName,
            iana,
            IsValidPattern(preferences.ShortDate) ? preferences.ShortDate! : dtf.ShortDatePattern,
            IsValidPattern(preferences.LongDate) ? preferences.LongDate! : dtf.LongDatePattern,
            IsValidPattern(preferences.ShortTime) ? preferences.ShortTime! : dtf.ShortTimePattern,
            IsValidPattern(preferences.LongTime) ? preferences.LongTime! : dtf.LongTimePattern,
            Enum.TryParse<DayOfWeek>(preferences.FirstDayOfWeek, ignoreCase: true, out var first) ? first : dtf.FirstDayOfWeek,
            measurement,
            currency,
            money?.Code,
            money?.Symbol,
            money is null ? null : FormatMoney(1234567.89m, culture, money.Symbol));
    }

    public sealed record CurrencyInfo(string Code, string Name, string Symbol);

    /// <summary>Every currency .NET knows (ISO 4217 code, English name, the symbol its own region uses).</summary>
    public static IReadOnlyList<CurrencyInfo> Currencies => CurrencyList.Value;

    private static readonly Lazy<IReadOnlyList<CurrencyInfo>> CurrencyList = new(() =>
        CultureInfo.GetCultures(CultureTypes.SpecificCultures)
            .Select(c => { try { return new RegionInfo(c.Name); } catch (ArgumentException) { return null; } })
            .Where(r => r is not null && r.ISOCurrencySymbol.Length == 3)
            .GroupBy(r => r!.ISOCurrencySymbol, StringComparer.OrdinalIgnoreCase)
            .Select(g => new CurrencyInfo(g.Key.ToUpperInvariant(), g.First()!.CurrencyEnglishName,
                // The symbol used in the currency's home region (₹ for INR from en-IN/hi-IN, $ for USD from en-US).
                g.GroupBy(r => r!.CurrencySymbol).OrderByDescending(s => s.Count()).First().Key))
            .OrderBy(c => c.Name, StringComparer.OrdinalIgnoreCase)
            .ToList());

    public static CurrencyInfo? FindCurrency(string? code)
        => string.IsNullOrWhiteSpace(code) ? null : Currencies.FirstOrDefault(c => string.Equals(c.Code, code.Trim(), StringComparison.OrdinalIgnoreCase));

    /// <summary>The currency of a country (ISO 3166 code), when .NET knows it.</summary>
    public static string? CountryCurrency(string country)
    {
        try
        {
            return new RegionInfo(country).ISOCurrencySymbol;
        }
        catch (ArgumentException)
        {
            return null;
        }
    }

    /// <summary>An amount in the regional format with the chosen currency's symbol (e.g. ₹12,34,567.89).</summary>
    public static string FormatMoney(decimal amount, CultureInfo culture, string symbol)
    {
        var format = (NumberFormatInfo)culture.NumberFormat.Clone();
        format.CurrencySymbol = symbol;
        return amount.ToString("C", format);
    }

    /// <summary>The system instruction: the user's current local date and time, and the formats to use for dates, times and numbers.</summary>
    /// <summary>The current time, appended to the newest user message (it changes every request; the prompt before it does not).</summary>
    public static string TimeNote(RegionalSettings? region, DateTimeOffset nowUtc)
    {
        if (region is null)
        {
            return $"[Current time: {nowUtc:yyyy-MM-dd HH:mm} UTC]";
        }
        var local = TimeZoneInfo.ConvertTime(nowUtc, region.TimeZone);
        return $"[Current time: {local.ToString(region.LongDate, region.Culture)} {local.ToString(region.ShortTime, region.Culture)} ({region.TimeZoneName}); {nowUtc:HH:mm} UTC]";
    }

    public static string Instruction(RegionalSettings region, DateTimeOffset nowUtc)
    {
        var culture = region.Culture;
        var local = TimeZoneInfo.ConvertTime(nowUtc, region.TimeZone);
        var offset = local.Offset;
        var sign = offset < TimeSpan.Zero ? "-" : "+";
        var sample = new DateTime(2026, 12, 31, 15, 4, 0);
        // Date only: the exact time goes with the newest message (see TimeNote), so this prompt stays identical all day and the
        // provider's prompt cache keeps serving the whole conversation after it.
        return $"User's local date: {local.ToString(region.LongDate, culture)} ({region.TimeZoneName}, UTC{sign}{offset:hh\\:mm}); the current " +
               $"time is given with the newest message. Use these, not UTC, for \"today\", \"now\" and deadlines. " +
               $"Regional formats ({region.FormatName}): short date {sample.ToString(region.ShortDate, culture)}, long date {sample.ToString(region.LongDate, culture)}, " +
               $"time {sample.ToString(region.ShortTime, culture)}, numbers {1234567.89.ToString("N2", culture)}, week starts on {region.FirstDayOfWeek}, " +
               $"{region.Measurement} units{(region.Currency is null ? "" : $", currency {region.Currency} written like {region.CurrencyExample}")}. Use these formats when you write dates, times, numbers and amounts for the user.";
    }

    /// <summary>The choices offered for one regional format, as Windows offers them (its own patterns plus common ones).</summary>
    public static object Options(string format)
    {
        var culture = CultureInfo.GetCultureInfo(IsValidFormat(format) ? ResponseLanguages.Normalize(format)! : "en-US");
        var dtf = culture.DateTimeFormat;
        var sample = new DateTime(2026, 12, 31, 15, 4, 5);
        object Choices(char kind, params string[] extra) => dtf.GetAllDateTimePatterns(kind).Concat(extra)
            .Distinct().Where(IsValidPattern).Take(20)
            .Select(p => new { pattern = p, example = sample.ToString(p, culture) });
        return new
        {
            format = culture.Name,
            shortDate = Choices('d', "dd-MM-yyyy", "dd/MM/yyyy", "dd.MM.yyyy", "MM/dd/yyyy", "yyyy-MM-dd", "d/M/yyyy", "d-M-yy"),
            longDate = Choices('D', "dddd, d MMMM yyyy", "d MMMM yyyy", "dddd, MMMM d, yyyy", "MMMM d, yyyy"),
            shortTime = Choices('t', "h:mm tt", "hh:mm tt", "HH:mm", "H:mm"),
            longTime = Choices('T', "h:mm:ss tt", "hh:mm:ss tt", "HH:mm:ss", "H:mm:ss"),
            currencies = Currencies.Select(c => new { code = c.Code, name = c.Name, symbol = c.Symbol, example = FormatMoney(1234567.89m, culture, c.Symbol) }),
            defaults = new { shortDate = dtf.ShortDatePattern, longDate = dtf.LongDatePattern, shortTime = dtf.ShortTimePattern, longTime = dtf.LongTimePattern, firstDayOfWeek = dtf.FirstDayOfWeek.ToString() },
        };
    }

    /// <summary>Every time zone this PC knows, with Windows display names.</summary>
    public static IEnumerable<object> TimeZones()
        => TimeZoneInfo.GetSystemTimeZones().Select(z => new { id = z.Id, name = z.DisplayName });
}
