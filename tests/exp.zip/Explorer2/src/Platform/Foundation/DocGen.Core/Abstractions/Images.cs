using System.Globalization;
using System.Text;

namespace DocGen.Core.Abstractions;

/// <summary>One recognised line of text in an image, with its bounding box in image pixels.</summary>
public sealed record ImageTextLine(string Text, double X, double Y, double Width, double Height);

/// <summary>OCR text and a classification of an image (document/screenshot, photo, diagram, graphic…).</summary>
public sealed class ImageAnalysis
{
    /// <summary>text-document | photo-of-text | graphic-with-text | photo-with-text | graphic | photo | unknown</summary>
    public string Kind { get; set; } = "unknown";

    public string KindLabel { get; set; } = "";
    public bool HasText { get; set; }
    public string Text { get; set; } = "";
    public List<ImageTextLine> Lines { get; set; } = [];
    public int WordCount { get; set; }
    public int Width { get; set; }
    public int Height { get; set; }

    /// <summary>Share of the image area covered by recognised words (0–1).</summary>
    public double TextCoverage { get; set; }

    /// <summary>Share of pixels in the 8 most common (quantised) colours: high for screenshots/graphics, low for photos.</summary>
    public double ColorFlatness { get; set; } = -1;

    public string? Language { get; set; }
    public string Engine { get; set; } = "";
    public string? Error { get; set; }
    public DateTime AnalyzedAt { get; set; } = DateTime.UtcNow;
}

/// <summary>Reads text from images (OCR) and classifies them. Implemented with the operating system's OCR engine.</summary>
public interface IImageAnalyzer
{
    bool IsImage(string fileName);

    Task<ImageAnalysis> AnalyzeAsync(string userId, string fullPath, CancellationToken cancellationToken);
}

/// <summary>An image described by a vision model: what it shows and its text. Error is set when the model could not do it.</summary>
public sealed record ImageDescription(string Text, string Engine, string? Error = null);

/// <summary>
/// Image understanding with a vision model (Settings → Agent → Images). Returns null when the administrator chose
/// Windows OCR; callers then (and whenever the description has an Error) use <see cref="IImageAnalyzer"/>.
/// </summary>
public interface IImageDescriber
{
    Task<ImageDescription?> DescribeAsync(string fullPath, string name, CancellationToken cancellationToken);
}

/// <summary>Plain-text description of an image analysis for the model and tools.</summary>
public static class ImageText
{
    public static string Describe(ImageAnalysis a, string name, int maxChars = 12_000)
    {
        if (a.Error is not null)
        {
            return $"{name}: {a.Error}";
        }
        var sb = new StringBuilder();
        sb.AppendLine(CultureInfo.InvariantCulture, $"{name}: {a.KindLabel} · {a.Width}×{a.Height} px · {a.WordCount} words in {a.Lines.Count} lines · text covers {a.TextCoverage:P1} · colour flatness {(a.ColorFlatness < 0 ? "n/a" : a.ColorFlatness.ToString("0.00", CultureInfo.InvariantCulture))} · {a.Engine}{(a.Language is null ? "" : $" ({a.Language})")}");
        if (a.HasText)
        {
            sb.AppendLine("Text (OCR, line by line; may contain recognition errors):");
            var text = a.Text.Length > maxChars ? a.Text[..maxChars] + "\n…[truncated]" : a.Text;
            sb.AppendLine(text);
        }
        else
        {
            sb.AppendLine("No meaningful text was found in the image.");
        }
        return sb.ToString().TrimEnd();
    }

}
