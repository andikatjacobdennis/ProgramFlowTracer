using DocGen.Core.Models;

namespace DocGen.Core.Abstractions;

// Repository contracts. Methods taking a userId enforce ownership and throw NotFoundException
// for resources that do not exist *or* belong to someone else.

public interface IUserRepository
{
    Task<User?> GetAsync(string id, CancellationToken ct = default);
    Task<User?> FindByUserNameAsync(string userName, CancellationToken ct = default);
    Task<User?> FindByTcpTokenHashAsync(string tokenHash, CancellationToken ct = default);
    Task<int> CountAsync(CancellationToken ct = default);
    Task<User> CreateAsync(User user, CancellationToken ct = default);
    Task<User> UpdateAsync(string id, Action<User> mutate, CancellationToken ct = default);
}

public interface ISessionRepository
{
    Task<Session> CreateAsync(Session session, CancellationToken ct = default);
    Task<Session?> GetAsync(string id, CancellationToken ct = default);
    Task RevokeAsync(string id, CancellationToken ct = default);
    Task RevokeAllAsync(string userId, CancellationToken ct = default);
}

public interface IConversationRepository
{
    Task<Conversation> CreateAsync(Conversation conversation, CancellationToken ct = default);
    Task<Conversation> GetAsync(string userId, string id, CancellationToken ct = default);
    Task<IReadOnlyList<Conversation>> ListAsync(string userId, bool includeArchived = false, string? projectId = null, CancellationToken ct = default);
    Task<Conversation> UpdateAsync(string userId, string id, Action<Conversation> mutate, CancellationToken ct = default);
    Task DeleteAsync(string userId, string id, CancellationToken ct = default);
}

public interface IMessageRepository
{
    Task<Message> CreateAsync(Message message, CancellationToken ct = default);
    Task<Message?> GetAsync(string conversationId, string messageId, CancellationToken ct = default);
    Task<Message> UpdateAsync(string conversationId, string messageId, Action<Message> mutate, CancellationToken ct = default);
    Task<IReadOnlyList<Message>> ListAsync(string conversationId, CancellationToken ct = default);
    Task DeleteAllAsync(string conversationId, CancellationToken ct = default);

    /// <summary>All messages (any conversation) with the given status. Used by startup reconciliation.</summary>
    Task<IReadOnlyList<Message>> ListByStatusAsync(MessageStatus status, CancellationToken ct = default);
}

public interface IProjectRepository
{
    Task<Project> CreateAsync(Project project, CancellationToken ct = default);
    Task<Project> GetAsync(string userId, string id, CancellationToken ct = default);
    Task<IReadOnlyList<Project>> ListAsync(string userId, CancellationToken ct = default);
    Task<Project> UpdateAsync(string userId, string id, Action<Project> mutate, CancellationToken ct = default);
    Task DeleteAsync(string userId, string id, CancellationToken ct = default);
}

public interface IPersonaRepository
{
    Task<Persona> CreateAsync(Persona persona, CancellationToken ct = default);
    Task<Persona> GetAsync(string userId, string id, CancellationToken ct = default);
    Task<IReadOnlyList<Persona>> ListAsync(string userId, CancellationToken ct = default);
    Task<Persona> UpdateAsync(string userId, string id, Action<Persona> mutate, CancellationToken ct = default);
    Task DeleteAsync(string userId, string id, CancellationToken ct = default);
}

public interface IRunRepository
{
    Task<AgentRun> CreateAsync(AgentRun run, CancellationToken ct = default);
    Task<AgentRun> GetAsync(string userId, string id, CancellationToken ct = default);
    Task SaveAsync(AgentRun run, CancellationToken ct = default);
    Task<IReadOnlyList<AgentRun>> ListAsync(string userId, int limit = 200, CancellationToken ct = default);

    /// <summary>All runs (any user) in one of the given states. Used by startup reconciliation.</summary>
    Task<IReadOnlyList<AgentRun>> ListByStatusAsync(IReadOnlyCollection<RunStatus> statuses, CancellationToken ct = default);

    /// <summary>
    /// Atomically applies <paramref name="apply"/> if the run (owned by <paramref name="userId"/>) is in one of
    /// <paramref name="from"/>. Returns the updated run, or null. Used as the "only one loop per run" claim.
    /// </summary>
    Task<AgentRun?> TryTransitionAsync(string userId, string runId, IReadOnlyCollection<RunStatus> from, Action<AgentRun> apply, CancellationToken ct = default);
}

public interface IArtifactService
{
    Task<Artifact> CreateAsync(string userId, string title, ArtifactType type, string content, string createdBy,
        string? conversationId = null, string? projectId = null, CancellationToken ct = default);
    Task<Artifact> GetAsync(string userId, string id, CancellationToken ct = default);
    Task<IReadOnlyList<Artifact>> ListAsync(string userId, string? projectId = null, CancellationToken ct = default);

    /// <summary>Reads a version's content (current version when null).</summary>
    Task<string> ReadContentAsync(string userId, string id, int? version = null, CancellationToken ct = default);

    /// <summary>Creates a new version. Previous versions are never modified or deleted.</summary>
    Task<Artifact> UpdateAsync(string userId, string id, string content, string createdBy, string? note = null,
        string? title = null, CancellationToken ct = default);

    Task DeleteAsync(string userId, string id, CancellationToken ct = default);
}

public interface IFileService
{
    string GetWorkspaceRoot(string userId);
    Task<StoredFile> SaveUploadAsync(string userId, string fileName, Stream content, string? projectId = null, CancellationToken ct = default);
    Task<StoredFile> GetAsync(string userId, string id, CancellationToken ct = default);
    Task<IReadOnlyList<StoredFile>> ListAsync(string userId, string? projectId = null, CancellationToken ct = default);
    Task<string> ReadTextAsync(string userId, string id, long maxBytes, CancellationToken ct = default);
    Task<Stream> OpenReadAsync(string userId, string id, CancellationToken ct = default);
    Task<StoredFile> UpdateAsync(string userId, string id, Action<StoredFile> mutate, CancellationToken ct = default);
    Task DeleteAsync(string userId, string id, CancellationToken ct = default);
}

public interface ISettingsService
{
    Task<ApplicationSettings> GetAppSettingsAsync(CancellationToken ct = default);
    Task<ApplicationSettings> UpdateAppSettingsAsync(Action<ApplicationSettings> mutate, CancellationToken ct = default);
    Task<IReadOnlyList<ProviderConfiguration>> GetProvidersAsync(CancellationToken ct = default);
    Task SaveProvidersAsync(IReadOnlyList<ProviderConfiguration> providers, CancellationToken ct = default);
    Task<IReadOnlyList<ModelConfiguration>> GetModelsAsync(CancellationToken ct = default);
    Task SaveModelsAsync(IReadOnlyList<ModelConfiguration> models, CancellationToken ct = default);

    /// <summary>Incremented whenever provider or model configuration changes.</summary>
    long ConfigurationGeneration { get; }
}

public sealed class SearchResult
{
    /// <summary>conversation | message | project | artifact | file</summary>
    public string Type { get; set; } = "";
    public string Id { get; set; } = "";
    public string Title { get; set; } = "";
    public string? Snippet { get; set; }
    public string? ConversationId { get; set; }
    public DateTime UpdatedAt { get; set; }
    public int Score { get; set; }
}

public interface ISearchService
{
    Task<IReadOnlyList<SearchResult>> SearchAsync(string userId, string query, int limit = 30, CancellationToken ct = default);
}

public interface IApprovalRepository
{
    Task<ApprovalRecord> CreateAsync(ApprovalRecord approval, CancellationToken ct = default);

    Task<ApprovalRecord?> GetAsync(string id, CancellationToken ct = default);

    /// <summary>
    /// Atomically applies <paramref name="apply"/> only if the approval is currently in one of
    /// <paramref name="from"/>. Returns the updated record, or null if the transition was not allowed
    /// (already decided, executed, expired…). This is the at-most-once guard for approved actions.
    /// </summary>
    Task<ApprovalRecord?> TryTransitionAsync(string id, IReadOnlyCollection<ApprovalStatus> from, Action<ApprovalRecord> apply, CancellationToken ct = default);

    Task<IReadOnlyList<ApprovalRecord>> ListByStatusAsync(IReadOnlyCollection<ApprovalStatus> statuses, string? userId = null, CancellationToken ct = default);
}

/// <summary>Validated compaction snapshots of a run (written atomically; never modified afterwards).</summary>
public interface ICompactionStore
{
    Task SaveAsync(ContextCompactionSnapshot snapshot, CancellationToken ct = default);
    Task<ContextCompactionSnapshot?> GetAsync(string runId, string snapshotId, CancellationToken ct = default);
    Task<IReadOnlyList<ContextCompactionSnapshot>> ListAsync(string runId, CancellationToken ct = default);
}

public interface IAgentCheckpointStore
{
    /// <summary>Atomically writes the checkpoint (the previous version is kept as a backup).</summary>
    Task SaveAsync(AgentCheckpoint checkpoint, CancellationToken ct = default);

    /// <summary>Returns the checkpoint, or null if none exists. Throws <see cref="Exceptions.StorageException"/> if unreadable.</summary>
    Task<AgentCheckpoint?> GetAsync(string runId, CancellationToken ct = default);

    /// <summary>Discards resumable state (messages, pending calls) and marks the checkpoint final, keeping audit metadata.</summary>
    Task FinalizeAsync(string runId, string finalStatus, int? finalIteration = null, CancellationToken ct = default);

    /// <summary>Read-modify-write under the checkpoint lock (used when a recovered approval adds its result).</summary>
    Task<AgentCheckpoint?> UpdateAsync(string runId, Action<AgentCheckpoint> mutate, CancellationToken ct = default);
}
