namespace DocGen.Core.Abstractions;

/// <summary>Event names streamed from the agent to clients (SSE event names / TCP event frames).</summary>
public static class AgentEventTypes
{
    public const string Start = "start";
    public const string Text = "text";
    public const string ToolStart = "tool_start";
    public const string ToolResult = "tool_result";
    public const string ApprovalRequired = "approval_required";
    public const string ApprovalResolved = "approval_resolved";
    public const string Usage = "usage";
    public const string Complete = "complete";

    /// <summary>A reasoning model is thinking: { chars } of hidden reasoning so far (progress only; never the reasoning itself).</summary>
    public const string Thinking = "thinking";

    /// <summary>A notice shown in the reply (e.g. the answer was cut off at the output limit): { text }.</summary>
    public const string Notice = "notice";
    public const string Error = "error";

    // Operational run lifecycle events (never model reasoning).
    public const string RunResumeRequested = "run_resume_requested";
    public const string RunResumed = "run_resumed";
    public const string CheckpointSaved = "checkpoint_saved";
    public const string RunInterrupted = "run_interrupted";
    public const string RunCompleted = "run_completed";

    // Context accounting and compaction (also stored as run activities).
    public const string ContextPressure = "context_pressure";
    public const string ContextSoftCompaction = "context_soft_compaction";
    public const string ContextCompactionStarted = "context_compaction_started";
    public const string ContextCompactionCompleted = "context_compaction_completed";
    public const string ContextCompactionFailed = "context_compaction_failed";

    /// <summary>Per model call: estimated context tokens, budget, capacity and thresholds (live indicator; not persisted).</summary>
    public const string ContextUsage = "context_usage";
}

/// <summary>Receives agent events. Implementations: SSE writer, TCP writer, test collector.</summary>
public interface IAgentEventSink
{
    ValueTask EmitAsync(string type, object payload, CancellationToken cancellationToken);
}

public sealed class NullAgentEventSink : IAgentEventSink
{
    public static readonly NullAgentEventSink Instance = new();

    public ValueTask EmitAsync(string type, object payload, CancellationToken cancellationToken) => ValueTask.CompletedTask;
}
