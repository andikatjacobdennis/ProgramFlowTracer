using DocGen.Core.Models;

namespace DocGen.Core.Abstractions;

/// <summary>
/// Content-addressed store for large tool outputs and runtime objects. Content is kept in full on disk; the model
/// only ever receives a summary plus a reference (<c>blob://{sha256}</c> or <c>runtime-object://{sha256}</c>) that it
/// can expand progressively (ranges, searches) through tools. Blobs are owned by one user.
/// </summary>
public interface IBlobStore
{
    Task<BlobInfo> PutAsync(string userId, string content, string kind, string? source, CancellationToken cancellationToken = default);

    Task<BlobInfo?> GetInfoAsync(string userId, string reference, CancellationToken cancellationToken = default);

    /// <summary>Absolute path of the blob content (for streaming analysis), or null if it does not exist or is not owned.</summary>
    string? GetContentPath(string userId, string reference);
}

public sealed class BlobInfo
{
    public string Hash { get; set; } = "";

    /// <summary>tool-output | runtime-object | command-output</summary>
    public string Kind { get; set; } = "tool-output";

    public string? Source { get; set; }
    public long SizeBytes { get; set; }
    public int LineCount { get; set; }
    public int EstimatedTokens { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public string Reference => (Kind == BlobKinds.RuntimeObject ? BlobKinds.RuntimeObjectScheme : BlobKinds.BlobScheme) + Hash;
}

public static class BlobKinds
{
    public const string ToolOutput = "tool-output";
    public const string RuntimeObject = "runtime-object";
    public const string CommandOutput = "command-output";
    public const string BlobScheme = "blob://";
    public const string RuntimeObjectScheme = "runtime-object://";

    /// <summary>Extracts the 64-hex hash from a blob:// or runtime-object:// reference (or a bare hash).</summary>
    public static string? ParseHash(string? reference)
    {
        if (string.IsNullOrWhiteSpace(reference))
        {
            return null;
        }
        var value = reference.Trim();
        if (value.StartsWith(BlobScheme, StringComparison.OrdinalIgnoreCase))
        {
            value = value[BlobScheme.Length..];
        }
        else if (value.StartsWith(RuntimeObjectScheme, StringComparison.OrdinalIgnoreCase))
        {
            value = value[RuntimeObjectScheme.Length..];
        }
        value = value.ToLowerInvariant();
        return value.Length == 64 && value.All(Uri.IsHexDigit) ? value : null;
    }
}

/// <summary>
/// A deterministic C# check that runs after permission evaluation and before a tool executes. A non-null result blocks
/// the call; the text is returned to the model as the tool result. Used for rules such as "never modify code while the
/// root cause of an active investigation is unconfirmed". The model cannot bypass a guard.
/// </summary>
public interface IToolExecutionGuard
{
    Task<string?> CheckAsync(IAgentTool tool, ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken);
}

/// <summary>
/// Supplies a pinned block of context (e.g. investigation memory) that is refreshed before every model call. Pinned
/// blocks are stored outside the transcript, so they survive context compaction and run resumption.
/// </summary>
public interface IContextContributor
{
    Task<string?> GetPinnedContextAsync(ToolExecutionContext context, CancellationToken cancellationToken);
}

/// <summary>Observes tool executions (e.g. to record evidence and inspected files for an active investigation).</summary>
public interface IToolExecutionObserver
{
    Task OnToolCompletedAsync(ToolCall call, ToolResult result, ToolExecutionContext context, long durationMs, CancellationToken cancellationToken);
}

/// <summary>
/// Supplies one deterministic section of a context-compaction snapshot from a DocGen service (investigation and RCA
/// state, commands and test results, development servers, browser sessions). Returns null when there is nothing to add.
/// </summary>
public interface ICompactionStateProvider
{
    Task<DocGen.Core.Models.CompactionSection?> GetSectionAsync(DocGen.Core.Models.CompactionContext context, CancellationToken cancellationToken);
}
