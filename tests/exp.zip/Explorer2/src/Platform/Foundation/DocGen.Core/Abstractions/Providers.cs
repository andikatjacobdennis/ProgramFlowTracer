using DocGen.Core.Models;

namespace DocGen.Core.Abstractions;

/// <summary>
/// A model provider adapter. All provider-specific wire formats live behind this interface;
/// the rest of DocGen never references a particular AI vendor.
/// </summary>
public interface IAIProvider
{
    string Id { get; }

    Task<ModelResponse> GenerateAsync(ModelRequest request, CancellationToken cancellationToken);

    IAsyncEnumerable<ModelStreamChunk> StreamAsync(ModelRequest request, CancellationToken cancellationToken);
}

public sealed class ModelRequest
{
    /// <summary>The identifier understood by the provider (ModelConfiguration.ProviderModelId).</summary>
    public string ModelId { get; set; } = "";

    public List<ModelMessage> Messages { get; set; } = [];
    public List<ToolDefinition> Tools { get; set; } = [];
    public int? MaxOutputTokens { get; set; }
    public double? Temperature { get; set; }
}

/// <summary>An image for a vision-capable model: media type (png/jpeg/gif/webp) and base64 data.</summary>
public sealed record ModelImage(string MediaType, string Base64, string Name);

public sealed class ModelMessage
{
    public MessageRole Role { get; set; }
    public string Content { get; set; } = "";

    /// <summary>Tool calls requested by an assistant turn.</summary>
    public List<ToolCall>? ToolCalls { get; set; }

    /// <summary>For Role=Tool: the call this message answers.</summary>
    public string? ToolCallId { get; set; }

    public string? ToolName { get; set; }

    /// <summary>Images sent with a user turn to a model that can view them (never persisted in checkpoints).</summary>
    public List<ModelImage>? Images { get; set; }

    public static ModelMessage System(string text) => new() { Role = MessageRole.System, Content = text };
    public static ModelMessage User(string text) => new() { Role = MessageRole.User, Content = text };
    public static ModelMessage Assistant(string text, List<ToolCall>? calls = null) =>
        new() { Role = MessageRole.Assistant, Content = text, ToolCalls = calls is { Count: > 0 } ? calls : null };
    public static ModelMessage Tool(ToolResult result) =>
        new() { Role = MessageRole.Tool, Content = result.Content, ToolCallId = result.ToolCallId, ToolName = result.ToolName };
}

public sealed record ToolDefinition(string Name, string Description, string InputSchema);

public sealed class ModelResponse
{
    public string Text { get; set; } = "";
    public List<ToolCall> ToolCalls { get; set; } = [];
    public UsageRecord? Usage { get; set; }
    public string? FinishReason { get; set; }
}

public enum StreamChunkKind
{
    TextDelta,

    /// <summary>A complete tool call. Adapters assemble partial deltas before emitting.</summary>
    ToolCall,

    Usage,
    Finish,

    /// <summary>
    /// Hidden reasoning from a reasoning model (a reasoning_content field). DocGen never shows or stores its content;
    /// only its length is used, to show that the model is working.
    /// </summary>
    Reasoning,
}

public sealed class ModelStreamChunk
{
    public StreamChunkKind Kind { get; init; }
    public string? Text { get; init; }
    public ToolCall? ToolCall { get; init; }
    public UsageRecord? Usage { get; init; }
    public string? FinishReason { get; init; }

    public static ModelStreamChunk Delta(string text) => new() { Kind = StreamChunkKind.TextDelta, Text = text };
    public static ModelStreamChunk Call(ToolCall call) => new() { Kind = StreamChunkKind.ToolCall, ToolCall = call };
    public static ModelStreamChunk UsageReport(UsageRecord usage) => new() { Kind = StreamChunkKind.Usage, Usage = usage };
    public static ModelStreamChunk Finished(string? reason) => new() { Kind = StreamChunkKind.Finish, FinishReason = reason };
}

/// <summary>Creates provider adapters from configuration. Rebuilt when provider settings change.</summary>
public interface IProviderRegistry
{
    Task<IAIProvider> GetAsync(string providerId, CancellationToken cancellationToken = default);

    Task<IReadOnlyList<ProviderConfiguration>> ListAsync(CancellationToken cancellationToken = default);
}

public interface IModelRegistry
{
    Task<IReadOnlyList<ModelConfiguration>> ListAsync(bool includeDisabled = false, CancellationToken cancellationToken = default);

    /// <summary>Resolves a requested model id (or the default) to an enabled model.</summary>
    Task<ModelConfiguration> ResolveAsync(string? modelId, CancellationToken cancellationToken = default);
}
