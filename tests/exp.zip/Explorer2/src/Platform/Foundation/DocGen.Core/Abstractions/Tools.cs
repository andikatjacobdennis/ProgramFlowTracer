using DocGen.Core.Models;

namespace DocGen.Core.Abstractions;

public interface IAgentTool
{
    string Name { get; }

    string Description { get; }

    /// <summary>JSON Schema (object) describing the arguments.</summary>
    string InputSchema { get; }

    ToolRiskLevel RiskLevel { get; }

    Task<ToolResult> ExecuteAsync(ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken);
}

/// <summary>Trusted, server-supplied context for a tool invocation. Never populated from model output.</summary>
public sealed class ToolExecutionContext
{
    public required string UserId { get; init; }
    public string? ConversationId { get; init; }
    public string? RunId { get; init; }
    public string? ProjectId { get; init; }

    /// <summary>Absolute path of the user's isolated workspace root.</summary>
    public required string WorkspaceRoot { get; init; }

    /// <summary>web | tcp | test</summary>
    public string Source { get; init; } = "web";

    /// <summary>The repository selected in the UI when the request was sent (untrusted; only a hint for context).</summary>
    public string? Repository { get; init; }

    /// <summary>
    /// The chat's working folder, resolved on the server from <see cref="Repository"/> (null: the workspace). Relative
    /// paths in the file tools resolve against it, as the code, Git and command tools already do.
    /// </summary>
    public WorkingFolder? WorkingFolder { get; init; }

    /// <summary>The working folder this conversation used before this request, when the user switched folders.</summary>
    public string? PreviousRepository { get; init; }

    /// <summary>A persona conversation: plain talk, so no repository context, engineering notes or tools.</summary>
    public bool Conversational { get; init; }

    /// <summary>The skills of this run: available, activated, and what they may use (null: no skills).</summary>
    public DocGen.Core.Skills.SkillSession? Skills { get; init; }
}

/// <summary>A folder a chat works in: the user's workspace or a repository the user may access.</summary>
public sealed record WorkingFolder(string Name, string Root, bool AllowWrite, bool AllowCommands, bool IsWorkspace);

/// <summary>Resolves a repository name to a folder this user may use; null when unknown or not permitted.</summary>
public interface IWorkingFolderResolver
{
    Task<WorkingFolder?> ResolveAsync(string userId, string? name, CancellationToken cancellationToken);
}

public interface IToolRegistry
{
    void Register(IAgentTool tool);

    IAgentTool? Get(string name);

    IReadOnlyList<IAgentTool> List();

    /// <summary>Validates a call's arguments against the tool schema. Empty when valid.</summary>
    IReadOnlyList<string> ValidateArguments(ToolCall call);

    /// <summary>Validates arguments, applies timeouts and output limits, and converts failures into results.</summary>
    Task<ToolResult> ExecuteAsync(ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken);
}

/// <summary>Deterministic permission policy. The model is never consulted.</summary>
public interface IPermissionManager
{
    Task<bool> IsEnabledAsync(string toolName, CancellationToken cancellationToken = default);

    Task<PermissionDecision> EvaluateAsync(IAgentTool tool, ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken = default);

    /// <summary>The decision that applies to a tool for interactive (web) use, for display on the Tools page.</summary>
    Task<PermissionDecision> DescribeAsync(IAgentTool tool, CancellationToken cancellationToken = default);

    /// <summary>
    /// Server-side risk assessment of one call (per-call risk for tools such as PowerShell) and the resulting decision.
    /// The model's own claims about risk are never used.
    /// </summary>
    Task<(PermissionDecision Decision, ToolRiskAssessment Assessment)> EvaluateDetailedAsync(IAgentTool tool, ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken = default);
}

/// <summary>
/// Explicit capabilities for powerful tools. Each maps to a per-role policy (DocGen:Permissions:Capabilities); a
/// capability decision can only make the risk-based decision stricter, never more permissive.
/// </summary>
public static class Capabilities
{
    public const string ExecutePowerShell = "ExecutePowerShell";
    public const string ExecuteProcess = "ExecuteProcess";
    public const string ManageDevelopmentServer = "ManageDevelopmentServer";
    public const string BrowserLocal = "BrowserLocal";
    public const string BrowserExternal = "BrowserExternal";
    public const string GitCommit = "GitCommit";
    public const string GitPush = "GitPush";

    public static readonly IReadOnlyList<string> All = [ExecutePowerShell, ExecuteProcess, ManageDevelopmentServer, BrowserLocal, BrowserExternal, GitCommit, GitPush];
}

/// <summary>Deterministic, server-side classification of a single tool call.</summary>
public sealed record ToolRiskAssessment(
    ToolRiskLevel Risk,
    string? Capability = null,
    IReadOnlyList<string>? Findings = null,
    string? DenyReason = null,
    string? Summary = null,
    bool Routine = false,
    bool SystemOrNetwork = false,
    string? Category = null)
{
    /// <summary>
    /// Routine, contained work decided by the server from the call's real target — e.g. edits and builds inside the user's
    /// own workspace, read-only commands, plain GET requests. In the "balanced" approval mode these run without a prompt;
    /// edits to registered repositories, mutating scripts, uploads, git commit/push and destructive actions still ask.
    /// SystemOrNetwork: the call installs software, uses the network or changes the system (services, registry, scheduled
    /// tasks, permissions, credentials) — it asks in every approval mode except where policy allows it outright.
    /// Category: the approval category when the tool knows it (e.g. "install", "network", "system"); otherwise the
    /// permission manager derives it (see ApprovalCategories).
    /// </summary>

    public static ToolRiskAssessment Static(IAgentTool tool) => new(tool.RiskLevel);
}

/// <summary>
/// A tool that knows which of its argument values are credentials (e.g. text typed into a password field). They are
/// masked in argument previews, approval prompts and run records, in addition to the generic secret redaction.
/// </summary>
public interface IArgumentRedactor
{
    string RedactArguments(string argumentsJson);
}

/// <summary>
/// A tool that acts only on explicit user intent (commit, push): every call needs the user's approval. Configuration,
/// runtime tool policies and capability policies can make it stricter (Deny) but can never turn the prompt off.
/// </summary>
public interface IUserIntentTool
{
}

/// <summary>A tool whose risk depends on the call (e.g. a read-only vs a mutating script).</summary>
public interface IDynamicRiskTool
{
    Task<ToolRiskAssessment> AssessAsync(ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken);
}

/// <summary>Pluggable web search backend. DocGen ships without one configured.</summary>
public interface IWebSearchProvider
{
    bool IsConfigured { get; }

    Task<IReadOnlyList<Citation>> SearchAsync(string query, int maxResults, CancellationToken cancellationToken);
}
