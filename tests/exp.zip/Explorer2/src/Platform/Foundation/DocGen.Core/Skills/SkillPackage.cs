using System.Text;
using System.Text.RegularExpressions;

namespace DocGen.Core.Skills;

/// <summary>
/// Reads and validates a skill package folder: SKILL.md plus optional references/, templates/, examples/, assets/ and
/// scripts/. Every path inside a package goes through <see cref="ResolveResource"/>, which refuses anything outside the
/// package (.., absolute paths, links), so a skill can only ever expose its own files.
/// </summary>
public static partial class SkillPackage
{
    /// <summary>The optional folders of a package, in the order they are listed to the model.</summary>
    public static readonly IReadOnlyList<string> Folders = ["references", "templates", "examples", "assets", "scripts"];

    private static readonly HashSet<string> RootFiles = new(StringComparer.OrdinalIgnoreCase) { "SKILL.md", "LICENSE", "LICENSE.md", "LICENSE.txt", "README.md" };

    private static readonly HashSet<string> TextExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".md", ".markdown", ".txt", ".json", ".yaml", ".yml", ".csv", ".tsv", ".html", ".htm", ".css", ".svg", ".xml", ".toml", ".ini",
        ".py", ".ps1", ".psm1", ".sh", ".js", ".mjs", ".ts", ".sql", ".cs", ".rb", ".r",
    };

    /// <summary>Files that can run on a machine: allowed only under scripts/, where DocGen lists but never runs them.</summary>
    private static readonly HashSet<string> Executable = new(StringComparer.OrdinalIgnoreCase)
    {
        ".exe", ".dll", ".com", ".scr", ".msi", ".msix", ".bat", ".cmd", ".ps1", ".psm1", ".vbs", ".vbe", ".wsf", ".hta", ".jar", ".sh",
        ".py", ".js", ".mjs", ".rb", ".pl", ".lnk", ".reg", ".so", ".dylib", ".app",
    };

    /// <summary>Reads the package at <paramref name="directory"/>. Problems become diagnostics; a manifest is always returned.</summary>
    /// <param name="knownTools">Tool names DocGen has (unknown ones in allowed_tools are reported); null skips the check.</param>
    public static SkillManifest Load(string directory, SkillScope scope, string? ownerUserId = null, IReadOnlySet<string>? knownTools = null)
    {
        directory = Path.GetFullPath(directory);
        var diagnostics = new List<SkillDiagnostic>();
        var folderName = Path.GetFileName(directory.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
        var skillMd = Path.Combine(directory, SkillParser.FileName);

        ParsedSkill parsed;
        var info = new FileInfo(skillMd);
        if (!info.Exists)
        {
            parsed = new ParsedSkill();
            parsed.Diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "missing-skill-md", "The package has no SKILL.md.", SkillParser.FileName));
        }
        else if (info.Length > SkillLimits.MaxSkillMdBytes)
        {
            parsed = new ParsedSkill();
            parsed.Diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "skill-md-too-large", $"SKILL.md is larger than {SkillLimits.MaxSkillMdBytes / 1024} KB.", SkillParser.FileName));
        }
        else if (IsLink(info))
        {
            parsed = new ParsedSkill();
            parsed.Diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "link", "SKILL.md is a link; packages must contain real files.", SkillParser.FileName));
        }
        else
        {
            parsed = SkillParser.Parse(File.ReadAllText(skillMd, Encoding.UTF8));
        }
        diagnostics.AddRange(parsed.Diagnostics);

        if (parsed.Id is { } id && SkillParser.IsValidId(id) && !string.Equals(id, folderName, StringComparison.Ordinal))
        {
            diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "name-folder-mismatch", $"\"name: {id}\" must match the package folder name \"{folderName}\".", SkillParser.FileName));
        }

        var resources = ScanFiles(directory, diagnostics);

        if (knownTools is not null)
        {
            foreach (var tool in parsed.AllowedTools.Where(t => !knownTools.Contains(t)))
            {
                diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Warning, "unknown-tool", $"allowed_tools lists \"{tool}\", which this DocGen does not have; it is ignored.", SkillParser.FileName));
            }
        }
        if (parsed.ProvidesTools.Count > 0 && scope != SkillScope.System)
        {
            diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Warning, "provides-tools-ignored", "provides_tools is only honoured for built-in skills; it is ignored.", SkillParser.FileName));
        }
        if (resources.Any(r => r.Folder == "scripts"))
        {
            diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Info, "scripts-not-run", "DocGen has no sandbox, so it never runs files in scripts/; the model can only read them.", "scripts"));
        }

        return new SkillManifest
        {
            Id = parsed.Id is { } pid && SkillParser.IsValidId(pid) ? pid : SanitizedFolderId(folderName),
            DisplayName = parsed.DisplayName ?? Title(parsed.Id ?? folderName),
            Description = parsed.Description is { Length: <= SkillLimits.MaxDescriptionLength } d ? d : "",
            Version = parsed.Version,
            Author = parsed.Author,
            Icon = parsed.Icon is { Length: <= 8 } icon && icon.IndexOfAny(['<', '>']) < 0 ? icon : null,
            License = parsed.License,
            Tags = parsed.Tags,
            AllowedTools = knownTools is null ? parsed.AllowedTools : parsed.AllowedTools.Where(knownTools.Contains).ToList(),
            ProvidesTools = scope == SkillScope.System ? parsed.ProvidesTools : [],
            Metadata = parsed.Metadata,
            Scope = scope,
            OwnerUserId = ownerUserId,
            Directory = directory,
            Resources = resources,
            Diagnostics = diagnostics,
            InstructionTokens = parsed.Body.Length / 4 + 1,
            UpdatedAt = info.Exists ? info.LastWriteTimeUtc : DateTime.MinValue,
        };
    }

    /// <summary>The instructions (SKILL.md body) of a package, read when the skill is activated.</summary>
    public static string ReadInstructions(SkillManifest skill)
    {
        var path = Path.Combine(skill.Directory, SkillParser.FileName);
        var info = new FileInfo(path);
        if (!info.Exists || info.Length > SkillLimits.MaxSkillMdBytes || IsLink(info))
        {
            throw new InvalidOperationException("The skill's SKILL.md is missing or no longer valid.");
        }
        var parsed = SkillParser.Parse(File.ReadAllText(path, Encoding.UTF8));
        if (!parsed.IsValid)
        {
            throw new InvalidOperationException("The skill's SKILL.md is no longer valid: " + parsed.Diagnostics.First(d => d.Severity == SkillDiagnosticSeverity.Error).Message);
        }
        return parsed.Body;
    }

    /// <summary>
    /// The absolute path of a file inside the package, or null when <paramref name="relativePath"/> is not one of its
    /// listed resources (so .., absolute paths, SKILL.md tricks and links are all refused).
    /// </summary>
    public static SkillResource? FindResource(SkillManifest skill, string? relativePath)
    {
        if (string.IsNullOrWhiteSpace(relativePath) || relativePath.Length > 300)
        {
            return null;
        }
        var normalized = relativePath.Trim().Replace('\\', '/').TrimStart('.', '/');
        if (relativePath.Contains("..", StringComparison.Ordinal) || Path.IsPathRooted(relativePath) || relativePath.Contains(':'))
        {
            return null;
        }
        return skill.Resources.FirstOrDefault(r => string.Equals(r.Path, normalized, StringComparison.OrdinalIgnoreCase));
    }

    /// <summary>The absolute path of a listed resource, re-checked against the package folder and for links.</summary>
    public static string ResolveResource(SkillManifest skill, SkillResource resource)
    {
        var root = Path.GetFullPath(skill.Directory).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        var full = Path.GetFullPath(Path.Combine(root, resource.Path.Replace('/', Path.DirectorySeparatorChar)));
        if (!full.StartsWith(root, StringComparison.OrdinalIgnoreCase))
        {
            throw new UnauthorizedAccessException("The resource is outside the skill package.");
        }
        var info = new FileInfo(full);
        if (!info.Exists || IsLink(info) || info.Length > SkillLimits.MaxFileBytes)
        {
            throw new FileNotFoundException("The resource is not available.");
        }
        return full;
    }

    /// <summary>Checks every file and folder in the package: layout, names, sizes, links, executables.</summary>
    private static List<SkillResource> ScanFiles(string directory, List<SkillDiagnostic> diagnostics)
    {
        var resources = new List<SkillResource>();
        if (!Directory.Exists(directory))
        {
            return resources;
        }
        long total = 0;
        var count = 0;
        var root = directory.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        var pending = new Stack<(string Path, int Depth)>();
        pending.Push((directory, 0));
        while (pending.Count > 0)
        {
            var (dir, depth) = pending.Pop();
            foreach (var entry in new DirectoryInfo(dir).EnumerateFileSystemInfos())
            {
                var relative = entry.FullName[root.Length..].Replace(Path.DirectorySeparatorChar, '/');
                if (IsLink(entry))
                {
                    diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "link", "Links are not allowed in skill packages.", relative));
                    continue;
                }
                if (!NamePattern().IsMatch(entry.Name))
                {
                    diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "invalid-file-name", "File and folder names may use letters, digits, spaces, dots, hyphens and underscores (no hidden files).", relative));
                    continue;
                }
                var top = relative.Split('/')[0];
                if (entry is DirectoryInfo)
                {
                    if (depth == 0 && !Folders.Contains(top, StringComparer.Ordinal))
                    {
                        diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "unexpected-folder", $"Unexpected folder; use {string.Join(", ", Folders)}.", relative));
                        continue;
                    }
                    if (depth + 1 > SkillLimits.MaxDepth)
                    {
                        diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "too-deep", $"Folders are nested more than {SkillLimits.MaxDepth} levels.", relative));
                        continue;
                    }
                    pending.Push((entry.FullName, depth + 1));
                    continue;
                }
                var file = (FileInfo)entry;
                if (++count > SkillLimits.MaxFiles)
                {
                    diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "too-many-files", $"More than {SkillLimits.MaxFiles} files."));
                    return resources;
                }
                total += file.Length;
                if (depth == 0)
                {
                    if (!RootFiles.Contains(file.Name))
                    {
                        diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "unexpected-file", "Only SKILL.md, README.md and LICENSE may be at the top of a package; put other files in a folder.", relative));
                    }
                    continue;
                }
                if (file.Length > SkillLimits.MaxFileBytes)
                {
                    diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "file-too-large", $"Larger than {SkillLimits.MaxFileBytes / 1024 / 1024} MB.", relative));
                    continue;
                }
                if (top != "scripts" && Executable.Contains(file.Extension))
                {
                    diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "executable-outside-scripts", "Executable or script files are only allowed in scripts/ (where DocGen never runs them).", relative));
                    continue;
                }
                resources.Add(new SkillResource(relative, top, file.Length, TextExtensions.Contains(file.Extension)));
            }
        }
        if (total > SkillLimits.MaxPackageBytes)
        {
            diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "package-too-large", $"The package is larger than {SkillLimits.MaxPackageBytes / 1024 / 1024} MB."));
        }
        return resources.OrderBy(r => Folders.ToList().IndexOf(r.Folder)).ThenBy(r => r.Path, StringComparer.OrdinalIgnoreCase).ToList();
    }

    public static bool IsLink(FileSystemInfo info) => info.LinkTarget is not null || info.Attributes.HasFlag(FileAttributes.ReparsePoint);

    private static string SanitizedFolderId(string folder)
    {
        var id = Regex.Replace(folder.ToLowerInvariant(), "[^a-z0-9]+", "-").Trim('-');
        return id.Length is > 0 and <= SkillLimits.MaxIdLength ? id : "invalid-skill";
    }

    private static string Title(string id) => string.Join(' ', id.Split('-', StringSplitOptions.RemoveEmptyEntries).Select(w => char.ToUpperInvariant(w[0]) + w[1..]));

    [GeneratedRegex("^[A-Za-z0-9][A-Za-z0-9._ -]{0,99}$")]
    private static partial Regex NamePattern();
}
