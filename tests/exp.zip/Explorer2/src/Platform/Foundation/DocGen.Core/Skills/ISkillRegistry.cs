namespace DocGen.Core.Skills;

/// <summary>What to install: a .zip of a package folder, or the text of a SKILL.md (a package with no other files).</summary>
public sealed record SkillInstallSource(Stream? Zip = null, string? SkillMd = null);

/// <summary>The outcome of validating (and possibly installing) a package.</summary>
/// <param name="Skill">The parsed package (null when it could not be read at all).</param>
public sealed record SkillInstallResult(SkillManifest? Skill, IReadOnlyList<SkillDiagnostic> Diagnostics, bool Installed)
{
    public bool IsValid => Skill is not null && Diagnostics.All(d => d.Severity != SkillDiagnosticSeverity.Error);
}

/// <summary>A resource read for the model or the UI: text (bounded) or, for binary files, only its description.</summary>
public sealed record SkillResourceContent(SkillResource Resource, string? Text, bool Truncated);

/// <summary>
/// The installed skills of this DocGen: built-in (System), shared by an administrator (Workspace) and personal (User).
/// Scans the package folders (cached, re-read when files change), resolves one skill per id for each user, tracks
/// which are turned on, and installs/removes packages. Instructions and resources are read on demand only.
/// </summary>
public interface ISkillRegistry
{
    /// <summary>Every skill this user can see (built-in, workspace and their own), including off, invalid and shadowed ones.</summary>
    Task<IReadOnlyList<SkillEntry>> ListAsync(string userId, CancellationToken cancellationToken = default);

    /// <summary>The skills this user can use now: turned on, valid, and one per id (User over Workspace over System).</summary>
    Task<IReadOnlyList<SkillManifest>> AvailableAsync(string userId, CancellationToken cancellationToken = default);

    /// <summary>A skill by id as this user sees it (the one in effect unless <paramref name="scope"/> picks another).</summary>
    Task<SkillEntry?> FindAsync(string userId, string id, SkillScope? scope = null, CancellationToken cancellationToken = default);

    /// <summary>Level 2: the instructions (SKILL.md body).</summary>
    Task<string> LoadInstructionsAsync(SkillManifest skill, CancellationToken cancellationToken = default);

    /// <summary>Level 3: one resource of a package (null when the path is not one of its files).</summary>
    Task<SkillResourceContent?> ReadResourceAsync(SkillManifest skill, string relativePath, int maxChars = SkillLimits.MaxResourceReadChars, CancellationToken cancellationToken = default);

    /// <summary>Validates a package without installing it.</summary>
    Task<SkillInstallResult> ValidateAsync(SkillInstallSource source, SkillScope scope, CancellationToken cancellationToken = default);

    /// <summary>
    /// Installs a package into <paramref name="scope"/> (User for <paramref name="userId"/>, or Workspace). Nothing is
    /// written unless the whole package is valid. Installed skills start turned off.
    /// </summary>
    Task<SkillInstallResult> InstallAsync(string userId, SkillScope scope, SkillInstallSource source, bool replace, CancellationToken cancellationToken = default);

    Task UninstallAsync(string userId, SkillScope scope, string id, CancellationToken cancellationToken = default);

    Task SetEnabledAsync(string userId, SkillScope scope, string id, bool enabled, CancellationToken cancellationToken = default);

    /// <summary>Null when no built-in skill provides <paramref name="toolName"/>; otherwise whether such a skill is turned on.</summary>
    Task<bool?> IsProvidedToolEnabledAsync(string toolName, CancellationToken cancellationToken = default);

    /// <summary>Tokens of the metadata listed in the system prompt for these skills (the cost of having them installed).</summary>
    static int MetadataTokens(IEnumerable<SkillManifest> skills) => skills.Sum(s => (s.Id.Length + Math.Min(s.Description.Length, 200) + 4) / 4 + 1);
}
