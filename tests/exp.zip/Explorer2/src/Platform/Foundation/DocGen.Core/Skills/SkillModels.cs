namespace DocGen.Core.Skills;

/// <summary>
/// Where a skill comes from. When the same id exists in several scopes, the most specific wins for that user:
/// <see cref="User"/> over <see cref="Workspace"/> over <see cref="System"/> (the others are listed as shadowed).
/// A per-project scope can be added later between Workspace and User without changing the package format.
/// </summary>
public enum SkillScope
{
    /// <summary>Shipped with DocGen (the skills/ folder next to the app). Reviewed with the code; may provide tools.</summary>
    System = 0,

    /// <summary>Installed by an administrator for everyone on this DocGen server.</summary>
    Workspace = 1,

    /// <summary>Installed by one user for themselves.</summary>
    User = 2,
}

public enum SkillDiagnosticSeverity
{
    Info,
    Warning,

    /// <summary>The skill cannot be used until this is fixed.</summary>
    Error,
}

/// <param name="Path">The file the finding is about (relative to the package), when it is about one file.</param>
public sealed record SkillDiagnostic(SkillDiagnosticSeverity Severity, string Code, string Message, string? Path = null);

/// <summary>A file in a skill package other than SKILL.md (a reference, template, example, asset or script).</summary>
/// <param name="Path">Relative path with forward slashes, e.g. "references/methodology.md".</param>
/// <param name="Folder">The top-level folder: references | templates | examples | assets | scripts.</param>
/// <param name="IsText">Text the model may read (by extension); binary files are never put into the model's context.</param>
public sealed record SkillResource(string Path, string Folder, long Bytes, bool IsText);

/// <summary>
/// A parsed skill package: its metadata (what the model sees before activation), where it lives and what was found
/// when it was validated. The instructions (SKILL.md body) are read only when the skill is activated.
/// </summary>
public sealed class SkillManifest
{
    public required string Id { get; init; }
    public required string DisplayName { get; init; }
    public required string Description { get; init; }
    public string? Version { get; init; }
    public string? Author { get; init; }
    public string? Icon { get; init; }
    public string? License { get; init; }
    public IReadOnlyList<string> Tags { get; init; } = [];

    /// <summary>
    /// Tools the skill's procedure uses. Declaring a tool grants nothing: the user's permissions and approval mode still
    /// decide. While a non-system skill is active, write/command/network tools it did not declare always ask first.
    /// </summary>
    public IReadOnlyList<string> AllowedTools { get; init; } = [];

    /// <summary>Tools that exist only while this skill is turned on (honoured for <see cref="SkillScope.System"/> skills only).</summary>
    public IReadOnlyList<string> ProvidesTools { get; init; } = [];

    public IReadOnlyDictionary<string, string> Metadata { get; init; } = new Dictionary<string, string>();

    public SkillScope Scope { get; init; }

    /// <summary>The owner of a <see cref="SkillScope.User"/> skill.</summary>
    public string? OwnerUserId { get; init; }

    /// <summary>Absolute path of the package folder (never sent to the model or to other users).</summary>
    public required string Directory { get; init; }

    public IReadOnlyList<SkillResource> Resources { get; init; } = [];
    public IReadOnlyList<SkillDiagnostic> Diagnostics { get; init; } = [];

    /// <summary>Estimated tokens of the instructions (what activation costs).</summary>
    public int InstructionTokens { get; init; }

    public DateTime UpdatedAt { get; init; }

    public bool IsValid => Diagnostics.All(d => d.Severity != SkillDiagnosticSeverity.Error);

    /// <summary>Unique key across scopes, e.g. "user:charts".</summary>
    public string Key => $"{Scope.ToString().ToLowerInvariant()}:{Id}";

    public string ScopeLabel => Scope switch
    {
        SkillScope.System => "built-in",
        SkillScope.Workspace => "workspace",
        _ => "personal",
    };
}

/// <summary>A skill as a user sees it: the package, whether it is on for them, and whether another scope hides it.</summary>
/// <param name="ShadowedBy">The scope whose skill with the same id is used instead (null: this one is used).</param>
public sealed record SkillEntry(SkillManifest Manifest, bool Enabled, SkillScope? ShadowedBy);

/// <summary>Size and shape limits for skill packages (they bound context use and what an installed package can hold).</summary>
public static class SkillLimits
{
    public const int MaxIdLength = 64;
    public const int MaxDisplayNameLength = 80;
    public const int MaxDescriptionLength = 1024;
    public const int MaxTags = 20;
    public const int MaxAllowedTools = 60;
    public const long MaxSkillMdBytes = 64 * 1024;
    public const int MaxInstructionChars = 40_000;
    public const int MaxFiles = 200;
    public const int MaxDepth = 4;
    public const long MaxFileBytes = 2 * 1024 * 1024;
    public const long MaxPackageBytes = 8 * 1024 * 1024;

    /// <summary>Most characters of one resource returned to the model in one read.</summary>
    public const int MaxResourceReadChars = 60_000;

    /// <summary>Skills that may be activated in one run (explicit and automatic together): stops activation loops.</summary>
    public const int MaxActivationsPerRun = 6;

    /// <summary>Skills listed by name and description in the system prompt; the rest are found with skill_search.</summary>
    public const int MaxListedInPrompt = 40;
}
