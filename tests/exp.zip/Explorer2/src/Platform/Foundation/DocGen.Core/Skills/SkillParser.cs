using System.Text;
using System.Text.RegularExpressions;

namespace DocGen.Core.Skills;

/// <summary>SKILL.md split into validated metadata and the instruction body.</summary>
public sealed class ParsedSkill
{
    public string? Id { get; init; }
    public string? DisplayName { get; init; }
    public string? Description { get; init; }
    public string? Version { get; init; }
    public string? Author { get; init; }
    public string? Icon { get; init; }
    public string? License { get; init; }
    public IReadOnlyList<string> Tags { get; init; } = [];
    public IReadOnlyList<string> AllowedTools { get; init; } = [];
    public IReadOnlyList<string> ProvidesTools { get; init; } = [];
    public IReadOnlyDictionary<string, string> Metadata { get; init; } = new Dictionary<string, string>();
    public string Body { get; init; } = "";
    public List<SkillDiagnostic> Diagnostics { get; } = [];
    public bool IsValid => Diagnostics.All(d => d.Severity != SkillDiagnosticSeverity.Error);
}

/// <summary>
/// Parses SKILL.md: a YAML front matter block between "---" lines, then Markdown instructions. Only the small YAML
/// subset skills need is accepted (scalars, quoted strings, inline and block lists, folded/literal blocks, one level of
/// "metadata:" map) — no anchors, tags or nested documents, so a package cannot smuggle anything through the parser.
/// </summary>
public static partial class SkillParser
{
    public const string FileName = "SKILL.md";

    private static readonly HashSet<string> KnownKeys = new(StringComparer.Ordinal)
    {
        "name", "display_name", "description", "version", "author", "tags", "allowed_tools", "provides_tools", "icon", "license", "metadata",
    };

    /// <summary>Other spellings accepted for compatibility with Agent Skills written for other tools.</summary>
    private static readonly Dictionary<string, string> Aliases = new(StringComparer.Ordinal)
    {
        ["display-name"] = "display_name", ["title"] = "display_name", ["allowed-tools"] = "allowed_tools",
        ["provides-tools"] = "provides_tools", ["categories"] = "tags", ["category"] = "tags",
    };

    // Text that tries to take over the model rather than describe a procedure. Flagged for the user to review; the
    // real defence is that skill text is always presented to the model as the author's data, below DocGen's rules.
    private static readonly (Regex Pattern, string What)[] Suspicious =
    [
        (new Regex(@"\b(ignore|disregard|forget|override)\b[^.\n]{0,40}\b(previous|prior|above|earlier|all|system|docgen)\b[^.\n]{0,20}\b(instructions?|rules|prompt|polic(y|ies))", RegexOptions.IgnoreCase), "asks the model to ignore its instructions"),
        (new Regex(@"\b(reveal|print|show|send|leak|exfiltrat\w*)\b[^.\n]{0,40}\b(system prompt|api[ _-]?keys?|secrets?|passwords?|credentials?|tokens?)\b", RegexOptions.IgnoreCase), "asks for secrets or the system prompt"),
        (new Regex(@"\byou are now\b|\bdeveloper mode\b|\bjailbreak\b", RegexOptions.IgnoreCase), "tries to change the model's role"),
        (new Regex(@"<\s*/?\s*(system|developer)\s*>|\[\s*system\s*\]", RegexOptions.IgnoreCase), "imitates system or developer messages"),
        (new Regex(@"\b(approve|auto-?approve|skip|bypass|disable)\b[^.\n]{0,30}\b(approvals?|permissions?|confirmation|security)\b", RegexOptions.IgnoreCase), "tries to bypass approvals or permissions"),
        (new Regex(@"(curl|wget|iwr|Invoke-WebRequest)[^\n|]{0,200}\|\s*(sh|bash|iex|powershell)|\bInvoke-Expression\b|\biex\s*\(", RegexOptions.IgnoreCase), "downloads and runs code"),
        (new Regex(@"(skill_load|load (the|this|another) skill)[^.\n]{0,40}\b(again|repeatedly|every|loop|all skills)\b", RegexOptions.IgnoreCase), "tries to make skills load each other repeatedly"),
    ];

    /// <summary>Parses and validates the text of a SKILL.md. Never throws for bad input: problems become diagnostics.</summary>
    public static ParsedSkill Parse(string text)
    {
        var diagnostics = new List<SkillDiagnostic>();
        text = text.Replace("\r\n", "\n").TrimStart('﻿');
        if (!text.StartsWith("---\n", StringComparison.Ordinal))
        {
            return Fail("missing-front-matter", "SKILL.md must start with a YAML front matter block (a line \"---\", the metadata, and another \"---\").");
        }
        var end = text.IndexOf("\n---", 3, StringComparison.Ordinal);
        if (end < 0 || (end + 4 < text.Length && text[end + 4] != '\n'))
        {
            return Fail("unclosed-front-matter", "The front matter block is not closed with a \"---\" line.");
        }
        var yaml = text[4..end];
        var body = end + 4 >= text.Length ? "" : text[(end + 5)..];

        var values = ParseYaml(yaml, diagnostics);
        var result = new ParsedSkill
        {
            Id = Scalar(values, "name"),
            DisplayName = Scalar(values, "display_name"),
            Description = Scalar(values, "description"),
            Version = Scalar(values, "version"),
            Author = Scalar(values, "author"),
            Icon = Scalar(values, "icon"),
            License = Scalar(values, "license"),
            Tags = List(values, "tags"),
            AllowedTools = List(values, "allowed_tools"),
            ProvidesTools = List(values, "provides_tools"),
            Metadata = values.TryGetValue("metadata", out var m) && m is Dictionary<string, string> map ? map : new Dictionary<string, string>(),
            Body = body.Trim('\n'),
        };
        result.Diagnostics.AddRange(diagnostics);
        Validate(result, values);
        return result;

        static ParsedSkill Fail(string code, string message)
        {
            var failed = new ParsedSkill();
            failed.Diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, code, message, FileName));
            return failed;
        }
    }

    private static void Validate(ParsedSkill s, Dictionary<string, object> values)
    {
        void Error(string code, string message) => s.Diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, code, message, FileName));
        void Warn(string code, string message) => s.Diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Warning, code, message, FileName));

        foreach (var key in values.Keys.Where(k => !KnownKeys.Contains(k)))
        {
            Warn("unknown-key", $"Unknown front matter key \"{key}\" is ignored.");
        }

        if (string.IsNullOrWhiteSpace(s.Id))
        {
            Error("missing-name", "\"name\" is required: the skill's id, e.g. financial-analysis.");
        }
        else if (!IsValidId(s.Id))
        {
            Error("invalid-name", $"\"name\" must be lowercase letters, digits and single hyphens (at most {SkillLimits.MaxIdLength} characters), e.g. financial-analysis.");
        }

        if (string.IsNullOrWhiteSpace(s.Description))
        {
            Error("missing-description", "\"description\" is required: what the skill does and when to use it (one or two sentences).");
        }
        else
        {
            if (s.Description.Length > SkillLimits.MaxDescriptionLength)
            {
                Error("description-too-long", $"\"description\" is longer than {SkillLimits.MaxDescriptionLength} characters.");
            }
            // The description goes into every system prompt: no markup, no line breaks.
            if (s.Description.IndexOfAny(['<', '>']) >= 0 || s.Description.Contains('\n'))
            {
                Error("description-markup", "\"description\" must be plain text on one line (no < or > characters).");
            }
        }

        if (s.DisplayName is { } display && (display.Length > SkillLimits.MaxDisplayNameLength || display.IndexOfAny(['<', '>', '\n']) >= 0))
        {
            Error("invalid-display-name", $"\"display_name\" must be plain text of at most {SkillLimits.MaxDisplayNameLength} characters.");
        }
        if (s.Version is { } version && !VersionPattern().IsMatch(version))
        {
            Warn("invalid-version", "\"version\" should look like 1.0.0.");
        }
        if (s.Author is { Length: > 100 })
        {
            Error("invalid-author", "\"author\" is longer than 100 characters.");
        }
        if (s.Icon is { } icon && (icon.Length > 8 || icon.IndexOfAny(['<', '>']) >= 0))
        {
            Warn("invalid-icon", "\"icon\" should be a single emoji; it is ignored.");
        }
        if (s.Tags.Count > SkillLimits.MaxTags)
        {
            Error("too-many-tags", $"At most {SkillLimits.MaxTags} tags.");
        }
        foreach (var tag in s.Tags.Where(t => !TagPattern().IsMatch(t)))
        {
            Error("invalid-tag", $"Tag \"{Short(tag)}\" must be lowercase letters, digits and hyphens (at most 32 characters).");
        }
        if (s.AllowedTools.Count > SkillLimits.MaxAllowedTools)
        {
            Error("too-many-tools", $"At most {SkillLimits.MaxAllowedTools} allowed tools.");
        }
        foreach (var tool in s.AllowedTools.Concat(s.ProvidesTools).Where(t => !ToolPattern().IsMatch(t)))
        {
            Error("invalid-tool-name", $"\"{Short(tool)}\" is not a valid tool name.");
        }

        if (string.IsNullOrWhiteSpace(s.Body))
        {
            Error("missing-instructions", "SKILL.md has no instructions after the front matter.");
        }
        else if (s.Body.Length > SkillLimits.MaxInstructionChars)
        {
            Error("instructions-too-long", $"The instructions are longer than {SkillLimits.MaxInstructionChars:N0} characters; move detail into references/ files the model loads when needed.");
        }
        foreach (var finding in ScanForInjection(s.Body + "\n" + s.Description))
        {
            Warn("suspicious-instructions", finding);
        }
    }

    /// <summary>Phrases that try to take over the model (for review; never a guarantee a package is safe).</summary>
    public static IEnumerable<string> ScanForInjection(string text)
    {
        foreach (var (pattern, what) in Suspicious)
        {
            if (pattern.Match(text) is { Success: true } match)
            {
                yield return $"The text {what}: \"{Short(match.Value)}\".";
            }
        }
    }

    public static bool IsValidId(string? id) => id is { Length: > 0 and <= SkillLimits.MaxIdLength } && IdPattern().IsMatch(id);

    private static string Short(string value) => value.Length <= 60 ? value : value[..57] + "…";

    private static string? Scalar(Dictionary<string, object> values, string key)
        => values.TryGetValue(key, out var v) ? v switch
        {
            string s when s.Trim().Length > 0 => s.Trim(),
            List<string> list when list.Count > 0 => string.Join(", ", list),
            _ => null,
        } : null;

    private static IReadOnlyList<string> List(Dictionary<string, object> values, string key)
        => values.TryGetValue(key, out var v) ? v switch
        {
            List<string> list => list.Select(x => x.Trim()).Where(x => x.Length > 0).Distinct(StringComparer.Ordinal).ToList(),
            // "allowed-tools: Read, Grep" (a single comma or space separated string, as other tools write it).
            string s => s.Split([',', ' '], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Distinct(StringComparer.Ordinal).ToList(),
            _ => [],
        } : [];

    /// <summary>The YAML subset: key: value | key: [a, b] | key: then "- item" lines | key: &gt; or | blocks | metadata: map.</summary>
    private static Dictionary<string, object> ParseYaml(string yaml, List<SkillDiagnostic> diagnostics)
    {
        var values = new Dictionary<string, object>(StringComparer.Ordinal);
        var lines = yaml.Split('\n');
        for (var i = 0; i < lines.Length; i++)
        {
            var line = lines[i];
            if (line.Trim().Length == 0 || line.TrimStart().StartsWith('#'))
            {
                continue;
            }
            if (char.IsWhiteSpace(line[0]) || line.StartsWith('-'))
            {
                diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "invalid-yaml", $"Front matter line {i + 2} is not \"key: value\".", FileName));
                continue;
            }
            var colon = line.IndexOf(':');
            if (colon <= 0)
            {
                diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "invalid-yaml", $"Front matter line {i + 2} is not \"key: value\".", FileName));
                continue;
            }
            var key = line[..colon].Trim();
            key = Aliases.GetValueOrDefault(key, key);
            var raw = line[(colon + 1)..].Trim();
            if (values.ContainsKey(key))
            {
                diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "duplicate-key", $"\"{key}\" appears more than once.", FileName));
                continue;
            }

            // Indented continuation lines belong to this key.
            var block = new List<string>();
            while (i + 1 < lines.Length && (lines[i + 1].Length == 0 || char.IsWhiteSpace(lines[i + 1][0]) || lines[i + 1].StartsWith("- ", StringComparison.Ordinal)))
            {
                if (lines[i + 1].StartsWith("- ", StringComparison.Ordinal) && raw.Length > 0)
                {
                    break;
                }
                block.Add(lines[++i]);
            }

            if (raw is ">" or "|" or ">-" or "|-")
            {
                var parts = block.Select(b => b.Trim()).ToList();
                values[key] = raw.StartsWith('>') ? string.Join(" ", parts.Where(p => p.Length > 0)) : string.Join("\n", parts).Trim();
            }
            else if (raw.Length == 0 && block.Any(b => b.TrimStart().StartsWith("- ", StringComparison.Ordinal) || b.Trim() == "-"))
            {
                values[key] = block.Where(b => b.Trim().Length > 0).Select(b => Unquote(b.Trim().TrimStart('-').Trim())).ToList();
            }
            else if (raw.Length == 0 && key == "metadata")
            {
                var map = new Dictionary<string, string>(StringComparer.Ordinal);
                foreach (var entry in block.Where(b => b.Trim().Length > 0))
                {
                    var c = entry.IndexOf(':');
                    if (c > 0 && map.Count < 30)
                    {
                        map[entry[..c].Trim()] = Unquote(entry[(c + 1)..].Trim());
                    }
                }
                values[key] = map;
            }
            else if (raw.StartsWith('[') && raw.EndsWith(']'))
            {
                values[key] = raw[1..^1].Split(',').Select(x => Unquote(x.Trim())).Where(x => x.Length > 0).ToList();
            }
            else
            {
                // A plain scalar may continue on indented lines (folded into one line).
                var text = new StringBuilder(Unquote(raw));
                foreach (var extra in block.Where(b => b.Trim().Length > 0))
                {
                    text.Append(' ').Append(extra.Trim());
                }
                values[key] = text.ToString();
            }
        }
        return values;
    }

    private static string Unquote(string value)
    {
        if (value.Length >= 2 && ((value[0] == '"' && value[^1] == '"') || (value[0] == '\'' && value[^1] == '\'')))
        {
            return value[1..^1].Replace("\\\"", "\"").Replace("''", "'");
        }
        // A trailing " # comment" on a plain scalar.
        var hash = value.IndexOf(" #", StringComparison.Ordinal);
        return hash >= 0 ? value[..hash].TrimEnd() : value;
    }

    [GeneratedRegex("^[a-z0-9]+(-[a-z0-9]+)*$")]
    private static partial Regex IdPattern();

    [GeneratedRegex("^[a-z0-9][a-z0-9-]{0,31}$")]
    private static partial Regex TagPattern();

    [GeneratedRegex("^[a-z_][a-z0-9_]{0,63}$")]
    private static partial Regex ToolPattern();

    [GeneratedRegex(@"^\d+(\.\d+){0,2}([-+][0-9A-Za-z.-]+)?$")]
    private static partial Regex VersionPattern();
}
