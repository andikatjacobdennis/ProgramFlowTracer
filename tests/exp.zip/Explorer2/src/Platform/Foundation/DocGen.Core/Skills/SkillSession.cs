namespace DocGen.Core.Skills;

/// <summary>A skill activated in the current run.</summary>
/// <param name="Explicit">The user picked it for this message (it outranks skills the model activated itself).</param>
public sealed record ActiveSkill(SkillManifest Skill, bool Explicit, DateTime ActivatedAt);

public enum SkillActivationOutcome
{
    Activated,
    AlreadyActive,
    NotAvailable,

    /// <summary>The run reached <see cref="SkillLimits.MaxActivationsPerRun"/> (stops skills loading skills in a loop).</summary>
    LimitReached,
}

/// <summary>
/// The skills of one run: which are available to this user (enabled, valid, one per id after scope precedence),
/// which were activated and how, and what they may use. Created by the chat orchestrator, read by the context builder,
/// the skill tools and the permission manager. Thread-safe: tools may run in parallel.
/// </summary>
public sealed class SkillSession(IReadOnlyList<SkillManifest> available, IReadOnlyList<string>? rememberedIds = null)
{
    private readonly object _gate = new();
    private readonly List<ActiveSkill> _active = [];
    private readonly Dictionary<string, string> _explicitInstructions = new(StringComparer.Ordinal);
    private int _activations;
    private int _resourceLoads;
    private int _instructionTokens;

    public static SkillSession Empty { get; } = new([]);

    /// <summary>Skills this user may use now, sorted by id (a stable order keeps the system prompt cacheable).</summary>
    public IReadOnlyList<SkillManifest> Available { get; } = available.OrderBy(s => s.Id, StringComparer.Ordinal).ToList();

    /// <summary>Skills used earlier in the conversation (their instructions are not in context any more).</summary>
    public IReadOnlyList<SkillManifest> Remembered { get; } = (rememberedIds ?? [])
        .Select(id => available.FirstOrDefault(s => s.Id == id)).OfType<SkillManifest>().ToList();

    public SkillManifest? Find(string? id) => Available.FirstOrDefault(s => string.Equals(s.Id, id?.Trim(), StringComparison.OrdinalIgnoreCase));

    public IReadOnlyList<ActiveSkill> Active
    {
        get { lock (_gate) { return _active.ToList(); } }
    }

    /// <summary>Instructions of the skills the user picked for this message (they go into the message's context).</summary>
    public IReadOnlyList<(SkillManifest Skill, string Instructions)> ExplicitInstructions
    {
        get
        {
            lock (_gate)
            {
                return _active.Where(a => a.Explicit && _explicitInstructions.ContainsKey(a.Skill.Id)).Select(a => (a.Skill, _explicitInstructions[a.Skill.Id])).ToList();
            }
        }
    }

    public int ResourceLoads { get { lock (_gate) { return _resourceLoads; } } }
    public int InstructionTokens { get { lock (_gate) { return _instructionTokens; } } }

    public SkillActivationOutcome Activate(SkillManifest skill, bool isExplicit, string? instructions = null)
    {
        lock (_gate)
        {
            if (!Available.Any(s => s.Key == skill.Key))
            {
                return SkillActivationOutcome.NotAvailable;
            }
            if (_active.Any(a => a.Skill.Key == skill.Key))
            {
                return SkillActivationOutcome.AlreadyActive;
            }
            if (_activations >= SkillLimits.MaxActivationsPerRun)
            {
                return SkillActivationOutcome.LimitReached;
            }
            _activations++;
            _instructionTokens += skill.InstructionTokens;
            _active.Add(new ActiveSkill(skill, isExplicit, DateTime.UtcNow));
            if (isExplicit && instructions is not null)
            {
                _explicitInstructions[skill.Id] = instructions;
            }
            return SkillActivationOutcome.Activated;
        }
    }

    public void RecordResourceLoad()
    {
        lock (_gate)
        {
            _resourceLoads++;
        }
    }

    /// <summary>
    /// Whether a call to <paramref name="toolName"/> must ask the user even when the approval mode would allow it: a
    /// skill that did not ship with DocGen is active and no active skill declared the tool. Declaring grants nothing
    /// beyond the normal policy; this only ever makes the policy stricter.
    /// </summary>
    public bool RequiresApprovalFor(string toolName)
    {
        lock (_gate)
        {
            return _active.Any(a => a.Skill.Scope != SkillScope.System)
                   && !_active.Any(a => a.Skill.AllowedTools.Contains(toolName, StringComparer.OrdinalIgnoreCase));
        }
    }

    /// <summary>
    /// The largest step and tool-call budgets an active <b>built-in</b> skill asks for (front matter metadata
    /// <c>max_steps</c> / <c>max_tool_calls</c>), for procedures that are long by nature (documenting a whole
    /// application). Installed and personal skills cannot ask; the agent loop caps the request (Agent:MaximumSkillSteps).
    /// </summary>
    public (int Steps, int ToolCalls, string? Skill) RequestedBudget
    {
        get
        {
            lock (_gate)
            {
                static int Read(SkillManifest s, string key) => s.Metadata.TryGetValue(key, out var v) && int.TryParse(v, out var n) && n > 0 ? n : 0;
                var system = _active.Where(a => a.Skill.Scope == SkillScope.System).Select(a => a.Skill).ToList();
                var steps = system.Select(s => Read(s, "max_steps")).DefaultIfEmpty(0).Max();
                var tools = system.Select(s => Read(s, "max_tool_calls")).DefaultIfEmpty(0).Max();
                return (steps, tools, system.Where(s => Read(s, "max_steps") == steps && steps > 0).Select(s => s.DisplayName).FirstOrDefault());
            }
        }
    }

    /// <summary>The non-built-in active skills (named in approval prompts).</summary>
    public IReadOnlyList<string> UntrustedActiveNames
    {
        get { lock (_gate) { return _active.Where(a => a.Skill.Scope != SkillScope.System).Select(a => a.Skill.DisplayName).ToList(); } }
    }

    /// <summary>Ids to remember on the conversation: this run's skills first, then earlier ones (at most 6).</summary>
    public List<string> RememberedAfterRun()
    {
        lock (_gate)
        {
            return _active.Select(a => a.Skill.Id).Concat(Remembered.Select(r => r.Id)).Distinct(StringComparer.Ordinal).Take(6).ToList();
        }
    }
}

/// <summary>Tools that only make sense when skills are available (not offered to the model when none are turned on).</summary>
public interface ISkillTool;
