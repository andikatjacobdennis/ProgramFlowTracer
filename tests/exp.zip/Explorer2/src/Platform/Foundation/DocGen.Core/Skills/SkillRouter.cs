using System.Text.RegularExpressions;

namespace DocGen.Core.Skills;

/// <param name="Score">Higher is a better match; only matches above the threshold are returned.</param>
/// <param name="Matched">The words that matched (for the "test" view and diagnostics, never shown to the model).</param>
public sealed record SkillMatch(SkillManifest Skill, double Score, IReadOnlyList<string> Matched);

/// <summary>
/// Cheap, deterministic skill matching: words of the request against each skill's id, tags and description, weighted
/// by how rare the word is among the installed skills. No model call and no embeddings. It only suggests — the model
/// reads the suggestion next to the request and decides whether to load the skill.
/// </summary>
public static partial class SkillRouter
{
    private static readonly HashSet<string> Stop = new(StringComparer.Ordinal)
    {
        "the", "and", "for", "with", "that", "this", "from", "into", "your", "you", "are", "can", "use", "using", "when", "what", "how", "make",
        "about", "some", "all", "any", "not", "but", "has", "have", "was", "were", "will", "would", "could", "should", "please", "want", "need",
        "give", "get", "also", "its", "their", "them", "then", "than", "there", "here", "which", "who", "why", "our", "out", "one", "two", "new",
        "create", "write", "help", "task", "tasks", "user", "users", "asks", "like", "just", "only", "more", "most", "very", "each", "other",
        "docgen", "skill", "skills",
    };

    public const double Threshold = 1.2;

    /// <summary>The best matching skills for a request, best first (at most <paramref name="max"/>).</summary>
    public static IReadOnlyList<SkillMatch> Rank(string request, IReadOnlyList<SkillManifest> skills, int max = 3, double threshold = Threshold)
    {
        var words = Words(request).ToHashSet(StringComparer.Ordinal);
        if (words.Count == 0 || skills.Count == 0)
        {
            return [];
        }
        // How many skills mention each word: a word every skill has ("files") says little.
        var documents = skills.Select(s => (Skill: s, Name: Words(s.Id.Replace('-', ' ') + " " + s.DisplayName).ToHashSet(StringComparer.Ordinal),
            Tags: s.Tags.SelectMany(t => Words(t.Replace('-', ' '))).ToHashSet(StringComparer.Ordinal),
            Description: Words(s.Description).ToHashSet(StringComparer.Ordinal))).ToList();
        double Idf(string word) => Math.Log(1 + (double)documents.Count / (1 + documents.Count(d => d.Name.Contains(word) || d.Tags.Contains(word) || d.Description.Contains(word))));

        var matches = new List<SkillMatch>();
        foreach (var d in documents)
        {
            double score = 0;
            var matched = new List<string>();
            foreach (var word in words)
            {
                var weight = d.Name.Contains(word) ? 3.0 : d.Tags.Contains(word) ? 2.0 : d.Description.Contains(word) ? 1.0 : 0;
                if (weight > 0)
                {
                    score += weight * Idf(word);
                    matched.Add(word);
                }
            }
            if (score >= threshold)
            {
                matches.Add(new SkillMatch(d.Skill, Math.Round(score, 2), matched));
            }
        }
        return matches.OrderByDescending(m => m.Score).ThenBy(m => m.Skill.Id, StringComparer.Ordinal).Take(max).ToList();
    }

    /// <summary>Lowercase word stems: "spreadsheets" and "spreadsheet" match, "charts"/"charting"/"chart" match.</summary>
    public static IEnumerable<string> Words(string? text)
    {
        if (string.IsNullOrEmpty(text))
        {
            yield break;
        }
        foreach (Match m in WordPattern().Matches(text.ToLowerInvariant()))
        {
            var w = m.Value;
            if (w.Length < 3 || Stop.Contains(w))
            {
                continue;
            }
            yield return Stem(w);
        }
    }

    private static string Stem(string w)
    {
        foreach (var suffix in new[] { "ations", "ation", "ings", "ing", "ies", "ed", "s" })
        {
            if (w.Length > suffix.Length + 3 && w.EndsWith(suffix, StringComparison.Ordinal) && !w.EndsWith("ss", StringComparison.Ordinal))
            {
                return suffix == "ies" ? w[..^3] + "y" : w[..^suffix.Length];
            }
        }
        return w;
    }

    [GeneratedRegex("[a-z0-9]+")]
    private static partial Regex WordPattern();
}
