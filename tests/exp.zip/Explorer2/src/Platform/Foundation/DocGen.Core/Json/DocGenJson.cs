using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace DocGen.Core.Json;

/// <summary>
/// Shared System.Text.Json configuration used for persistence, the HTTP API and the TCP protocol.
/// </summary>
public static class DocGenJson
{
    /// <summary>Indented options used for files on disk (easy to inspect by hand).</summary>
    public static readonly JsonSerializerOptions Storage = Create(indented: true);

    /// <summary>Compact options used on the wire (HTTP, SSE, TCP).</summary>
    public static readonly JsonSerializerOptions Wire = Create(indented: false);

    private static JsonSerializerOptions Create(bool indented)
    {
        var options = new JsonSerializerOptions(JsonSerializerDefaults.Web)
        {
            WriteIndented = indented,
            DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
            ReadCommentHandling = JsonCommentHandling.Skip,
            AllowTrailingCommas = true,
            MaxDepth = 64,
            // DocGen never embeds JSON inside HTML, so readable escaping is safe and keeps previews legible.
            Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
        };
        options.Converters.Add(new JsonStringEnumConverter(JsonNamingPolicy.CamelCase));
        options.MakeReadOnly(populateMissingResolver: true);
        return options;
    }

    /// <summary>Applies DocGen conventions to an externally owned options instance (e.g. ASP.NET Core MVC).</summary>
    public static void Configure(JsonSerializerOptions options)
    {
        options.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
        options.Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping;
        options.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
        options.Converters.Add(new JsonStringEnumConverter(JsonNamingPolicy.CamelCase));
    }
}
