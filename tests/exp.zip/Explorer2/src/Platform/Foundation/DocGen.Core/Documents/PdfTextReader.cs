using System.Globalization;
using System.IO.Compression;
using System.Text;
using System.Text.RegularExpressions;

namespace DocGen.Core.Documents;

/// <summary>Text of one PDF page.</summary>
public sealed record PdfPageText(int Number, string Text);

/// <summary>Text extracted from a PDF, with document properties and what could not be read.</summary>
public sealed class PdfDocumentText
{
    public List<PdfPageText> Pages { get; } = [];
    public Dictionary<string, string> Properties { get; } = [];
    public int PageCount { get; set; }
    public bool Encrypted { get; set; }
    public bool Truncated { get; set; }

    /// <summary>Why nothing (or not everything) could be read; null when extraction worked.</summary>
    public string? Error { get; set; }

    public bool HasText => Pages.Any(p => p.Text.Length > 0);
    public int WordCount => Pages.Sum(p => p.Text.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries).Length);

    /// <summary>All pages as text with "--- Page n ---" separators.</summary>
    public string ToText(int maxChars = int.MaxValue)
    {
        var sb = new StringBuilder();
        foreach (var page in Pages)
        {
            if (sb.Length >= maxChars)
            {
                break;
            }
            sb.Append("--- Page ").Append(page.Number).Append(" ---\n");
            sb.Append(page.Text.Length > 0 ? page.Text : "(no text on this page)").Append('\n');
        }
        return sb.Length > maxChars ? sb.ToString(0, maxChars) + "\n…[truncated]" : sb.ToString().TrimEnd();
    }
}

/// <summary>
/// Dependency-free PDF text extraction. It scans every object in the file (so damaged or incrementally saved
/// files still read), decodes object streams and the common filters (Flate, ASCIIHex, ASCII85), walks the page tree
/// with inherited resources and turns content-stream text operators into lines, mapping glyph codes through each
/// font's ToUnicode CMap or its simple encoding (WinAnsi, MacRoman, Standard, /Differences). Form XObjects are
/// followed; images are ignored (scanned PDFs have no text layer). All work is bounded: decoded bytes per stream and
/// in total, pages, object count and nesting depth, so hostile files cannot exhaust memory. Encrypted PDFs are
/// reported, not decrypted.
/// </summary>
public static partial class PdfTextReader
{
    public const int MaxStreamBytes = 32 * 1024 * 1024;
    public const long MaxTotalDecodedBytes = 256L * 1024 * 1024;
    public const int MaxPages = 3000;
    public const int MaxObjects = 500_000;
    public const int MaxOutputChars = 4_000_000;

    /// <summary>True when the file starts like a PDF (the header may follow a little junk).</summary>
    public static bool LooksLikePdf(ReadOnlySpan<byte> head)
    {
        var limit = Math.Min(head.Length, 1024);
        return head[..limit].IndexOf("%PDF-"u8) >= 0;
    }

    public static PdfDocumentText Read(string path, CancellationToken cancellationToken = default)
        => Read(File.ReadAllBytes(path), cancellationToken);

    public static PdfDocumentText Read(byte[] data, CancellationToken cancellationToken = default)
    {
        var result = new PdfDocumentText();
        if (!LooksLikePdf(data))
        {
            result.Error = "The file is not a PDF.";
            return result;
        }
        try
        {
            new Parser(data, result, cancellationToken).Run();
        }
        catch (OperationCanceledException)
        {
            throw;
        }
        catch (Exception ex) when (ex is FormatException or InvalidDataException or IndexOutOfRangeException or ArgumentException or InvalidOperationException or OverflowException)
        {
            result.Error ??= "The PDF is damaged and could not be read completely.";
        }
        if (result.Error is null && result.PageCount > 0 && !result.HasText)
        {
            result.Error = "The PDF has no text layer (it is probably scanned images); text extraction found nothing.";
        }
        return result;
    }

    // ---------- Object model ----------

    private sealed record Name(string Value);
    private sealed record Ref(int Number, int Generation);
    private sealed class Dict : Dictionary<string, object?> { }
    private sealed class PdfStream(Dict dictionary, int start, int length)
    {
        public Dict Dictionary { get; } = dictionary;
        public int Start { get; } = start;
        public int Length { get; set; } = length;
        public byte[]? Decoded { get; set; }
    }
    private sealed class Operator(string value)
    {
        public string Value { get; } = value;
    }

    // ---------- Lexer ----------

    private sealed class Lexer(byte[] data, int position, int end)
    {
        public int Position = position;
        private readonly int _end = Math.Min(end, data.Length);

        public bool AtEnd { get { SkipWhitespace(); return Position >= _end; } }

        private static bool IsWhite(byte b) => b is 0 or 9 or 10 or 12 or 13 or 32;
        private static bool IsDelimiter(byte b) => b is (byte)'(' or (byte)')' or (byte)'<' or (byte)'>' or (byte)'[' or (byte)']' or (byte)'{' or (byte)'}' or (byte)'/' or (byte)'%';

        public void SkipWhitespace()
        {
            while (Position < _end)
            {
                var b = data[Position];
                if (IsWhite(b))
                {
                    Position++;
                }
                else if (b == '%')
                {
                    while (Position < _end && data[Position] is not (10 or 13))
                    {
                        Position++;
                    }
                }
                else
                {
                    break;
                }
            }
        }

        /// <summary>Reads one object (or, in content streams, an operator). Resolves "n g R" references.</summary>
        public object? Next(int depth = 0)
        {
            if (depth > 64)
            {
                throw new FormatException("Nesting too deep.");
            }
            SkipWhitespace();
            if (Position >= _end)
            {
                return null;
            }
            var b = data[Position];
            switch (b)
            {
                case (byte)'/':
                    return new Name(ReadName());
                case (byte)'(':
                    return ReadLiteralString();
                case (byte)'<' when Position + 1 < _end && data[Position + 1] == '<':
                    return ReadDictionary(depth);
                case (byte)'<':
                    return ReadHexString();
                case (byte)'[':
                    {
                        Position++;
                        var list = new List<object?>();
                        while (true)
                        {
                            SkipWhitespace();
                            if (Position >= _end)
                            {
                                return list;
                            }
                            if (data[Position] == ']')
                            {
                                Position++;
                                return list;
                            }
                            var item = Next(depth + 1);
                            if (item is Operator { Value: "R" } && list.Count >= 2 && list[^2] is double n && list[^1] is double g)
                            {
                                list.RemoveRange(list.Count - 2, 2);
                                list.Add(new Ref((int)n, (int)g));
                            }
                            else
                            {
                                list.Add(item);
                            }
                            if (list.Count > 1_000_000)
                            {
                                throw new FormatException("Array too large.");
                            }
                        }
                    }
                case (byte)']' or (byte)'>' or (byte)')' or (byte)'{' or (byte)'}':
                    Position++;
                    return new Operator(((char)b).ToString());
            }
            if (b is (byte)'+' or (byte)'-' or (byte)'.' || (b >= '0' && b <= '9'))
            {
                var start = Position;
                Position++;
                while (Position < _end && (data[Position] is (byte)'.' || (data[Position] >= '0' && data[Position] <= '9')))
                {
                    Position++;
                }
                var text = Encoding.ASCII.GetString(data, start, Position - start);
                return double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out var value) ? value : 0d;
            }
            var wordStart = Position;
            while (Position < _end && !IsWhite(data[Position]) && !IsDelimiter(data[Position]))
            {
                Position++;
            }
            if (Position == wordStart)
            {
                Position++;
                return new Operator(((char)b).ToString());
            }
            var word = Encoding.ASCII.GetString(data, wordStart, Position - wordStart);
            return word switch
            {
                "true" => true,
                "false" => false,
                "null" => null,
                _ => new Operator(word),
            };
        }

        private string ReadName()
        {
            Position++;
            var sb = new StringBuilder();
            while (Position < _end && !IsWhite(data[Position]) && !IsDelimiter(data[Position]))
            {
                if (data[Position] == '#' && Position + 2 < _end && IsHex(data[Position + 1]) && IsHex(data[Position + 2]))
                {
                    sb.Append((char)Convert.ToByte(Encoding.ASCII.GetString(data, Position + 1, 2), 16));
                    Position += 3;
                    continue;
                }
                sb.Append((char)data[Position]);
                Position++;
            }
            return sb.ToString();
        }

        private static bool IsHex(byte b) => (b >= '0' && b <= '9') || (b >= 'a' && b <= 'f') || (b >= 'A' && b <= 'F');

        private byte[] ReadLiteralString()
        {
            Position++;
            var bytes = new List<byte>();
            var depth = 1;
            while (Position < _end)
            {
                var b = data[Position++];
                if (b == '\\' && Position < _end)
                {
                    var e = data[Position++];
                    switch (e)
                    {
                        case (byte)'n': bytes.Add(10); break;
                        case (byte)'r': bytes.Add(13); break;
                        case (byte)'t': bytes.Add(9); break;
                        case (byte)'b': bytes.Add(8); break;
                        case (byte)'f': bytes.Add(12); break;
                        case 13:
                            if (Position < _end && data[Position] == 10)
                            {
                                Position++;
                            }
                            break;
                        case 10:
                            break;
                        default:
                            if (e >= '0' && e <= '7')
                            {
                                var value = e - '0';
                                for (var i = 0; i < 2 && Position < _end && data[Position] >= '0' && data[Position] <= '7'; i++)
                                {
                                    value = value * 8 + (data[Position++] - '0');
                                }
                                bytes.Add((byte)value);
                            }
                            else
                            {
                                bytes.Add(e);
                            }
                            break;
                    }
                    continue;
                }
                if (b == '(')
                {
                    depth++;
                }
                else if (b == ')' && --depth == 0)
                {
                    break;
                }
                bytes.Add(b);
            }
            return [.. bytes];
        }

        private byte[] ReadHexString()
        {
            Position++;
            var hex = new StringBuilder();
            while (Position < _end && data[Position] != '>')
            {
                if (IsHex(data[Position]))
                {
                    hex.Append((char)data[Position]);
                }
                Position++;
            }
            Position++;
            if (hex.Length % 2 == 1)
            {
                hex.Append('0');
            }
            return Convert.FromHexString(hex.ToString());
        }

        private Dict ReadDictionary(int depth)
        {
            Position += 2;
            var dict = new Dict();
            while (true)
            {
                SkipWhitespace();
                if (Position >= _end)
                {
                    return dict;
                }
                if (data[Position] == '>' && Position + 1 < _end && data[Position + 1] == '>')
                {
                    Position += 2;
                    return dict;
                }
                var key = Next(depth + 1);
                if (key is not Name name)
                {
                    if (key is null && Position >= _end)
                    {
                        return dict;
                    }
                    continue; // Malformed entry: skip it.
                }
                var value = Next(depth + 1);
                // "n g R" inside a dictionary.
                if (value is double n)
                {
                    var save = Position;
                    var g = Next(depth + 1);
                    var r = g is double ? Next(depth + 1) : null;
                    if (g is double gen && r is Operator { Value: "R" })
                    {
                        value = new Ref((int)n, (int)gen);
                    }
                    else
                    {
                        Position = save;
                    }
                }
                dict[name.Value] = value;
            }
        }
    }

    // ---------- Parser ----------

    private sealed partial class Parser(byte[] data, PdfDocumentText result, CancellationToken ct)
    {
        private readonly Dictionary<int, object?> _objects = [];
        private readonly Dictionary<int, PdfStream> _streams = [];
        private readonly Dictionary<Dict, Font> _fonts = new(ReferenceEqualityComparer.Instance);
        private long _decoded;
        private int _outputChars;

        public void Run()
        {
            ScanObjects();
            ExpandObjectStreams();
            var trailer = FindTrailer();
            if (trailer?.TryGetValue("Encrypt", out var encrypt) == true && encrypt is not null)
            {
                result.Encrypted = true;
                result.Error = "The PDF is encrypted (password-protected or restricted), so its text cannot be read. Save or print it as an unprotected PDF and try again.";
                return;
            }
            ReadInfo(trailer);
            var pages = CollectPages(trailer);
            result.PageCount = pages.Count;
            var number = 0;
            foreach (var (page, resources) in pages)
            {
                ct.ThrowIfCancellationRequested();
                number++;
                if (_outputChars >= MaxOutputChars)
                {
                    result.Truncated = true;
                    break;
                }
                var text = new TextWriter();
                foreach (var content in ContentStreams(page))
                {
                    RunContent(content, resources, text, 0);
                }
                var pageText = text.ToString();
                _outputChars += pageText.Length;
                result.Pages.Add(new PdfPageText(number, pageText));
            }
        }

        // Every "n g obj" in the file; later definitions (incremental updates) replace earlier ones.
        [GeneratedRegex(@"(?<![0-9])(\d{1,7})\s+(\d{1,5})\s+obj\b", RegexOptions.CultureInvariant)]
        private static partial Regex ObjectHeader();

        private void ScanObjects()
        {
            var text = Encoding.Latin1.GetString(data);
            foreach (Match m in ObjectHeader().Matches(text))
            {
                ct.ThrowIfCancellationRequested();
                if (_objects.Count >= MaxObjects)
                {
                    result.Truncated = true;
                    break;
                }
                var number = int.Parse(m.Groups[1].Value, CultureInfo.InvariantCulture);
                var lexer = new Lexer(data, m.Index + m.Length, data.Length);
                object? value;
                try
                {
                    value = lexer.Next();
                }
                catch (FormatException)
                {
                    continue;
                }
                if (value is Dict dict)
                {
                    var save = lexer.Position;
                    if (lexer.Next() is Operator { Value: "stream" })
                    {
                        var start = lexer.Position;
                        if (start < data.Length && data[start] == 13)
                        {
                            start++;
                        }
                        if (start < data.Length && data[start] == 10)
                        {
                            start++;
                        }
                        var length = dict.TryGetValue("Length", out var l) && l is double d ? (int)d : -1;
                        if (length < 0 || start + length > data.Length || !EndsStream(start + length))
                        {
                            length = FindEndStream(start) - start;
                        }
                        var stream = new PdfStream(dict, start, Math.Max(0, length));
                        _streams[number] = stream;
                        _objects[number] = stream;
                        continue;
                    }
                    lexer.Position = save;
                }
                _objects[number] = value;
            }
        }

        private bool EndsStream(int position)
        {
            var lexer = new Lexer(data, position, Math.Min(data.Length, position + 32));
            return lexer.Next() is Operator { Value: "endstream" };
        }

        private int FindEndStream(int start)
        {
            var index = data.AsSpan(start).IndexOf("endstream"u8);
            if (index < 0)
            {
                return data.Length;
            }
            var end = start + index;
            while (end > start && data[end - 1] is 10 or 13)
            {
                end--;
            }
            return end;
        }

        private void ExpandObjectStreams()
        {
            foreach (var stream in _streams.Values.Where(s => Get(s.Dictionary, "Type") is Name { Value: "ObjStm" }).ToList())
            {
                ct.ThrowIfCancellationRequested();
                var bytes = Decode(stream);
                if (bytes is null)
                {
                    continue;
                }
                var count = (int)Number(Get(stream.Dictionary, "N"));
                var first = (int)Number(Get(stream.Dictionary, "First"));
                var header = new Lexer(bytes, 0, Math.Min(first, bytes.Length));
                var entries = new List<(int Number, int Offset)>();
                for (var i = 0; i < count && i < 100_000; i++)
                {
                    if (header.Next() is not double n || header.Next() is not double offset)
                    {
                        break;
                    }
                    entries.Add(((int)n, (int)offset));
                }
                foreach (var (number, offset) in entries)
                {
                    if (_objects.ContainsKey(number) || first + offset >= bytes.Length)
                    {
                        continue; // A direct definition (e.g. a later update) wins.
                    }
                    try
                    {
                        _objects[number] = new Lexer(bytes, first + offset, bytes.Length).Next();
                    }
                    catch (FormatException)
                    {
                        // Skip a damaged entry.
                    }
                }
            }
        }

        private Dict? FindTrailer()
        {
            Dict? trailer = null;
            var index = data.AsSpan().LastIndexOf("trailer"u8);
            if (index >= 0 && new Lexer(data, index + 7, data.Length).Next() is Dict d)
            {
                trailer = d;
            }
            // Cross-reference streams (PDF 1.5+) carry the trailer entries in their dictionary.
            var xref = _streams.Values.LastOrDefault(s => Get(s.Dictionary, "Type") is Name { Value: "XRef" })?.Dictionary;
            if (trailer is null || !trailer.ContainsKey("Root"))
            {
                trailer = xref ?? trailer;
            }
            else if (xref is not null && xref.ContainsKey("Encrypt") && !trailer.ContainsKey("Encrypt"))
            {
                trailer["Encrypt"] = xref["Encrypt"];
            }
            return trailer;
        }

        private void ReadInfo(Dict? trailer)
        {
            if (Resolve(Get(trailer, "Info")) is not Dict info)
            {
                return;
            }
            foreach (var key in new[] { "Title", "Author", "Subject", "Keywords", "Creator", "Producer" })
            {
                if (Resolve(Get(info, key)) is byte[] bytes && TextString(bytes) is { Length: > 0 } value)
                {
                    result.Properties[key] = value.Length > 300 ? value[..300] : value;
                }
            }
        }

        private List<(Dict Page, Dict? Resources)> CollectPages(Dict? trailer)
        {
            var pages = new List<(Dict, Dict?)>();
            var root = Resolve(Get(trailer, "Root")) as Dict
                       ?? _objects.Values.OfType<Dict>().LastOrDefault(d => Get(d, "Type") is Name { Value: "Catalog" });
            if (root is not null && Resolve(Get(root, "Pages")) is Dict tree)
            {
                Walk(tree, null, pages, new HashSet<Dict>(ReferenceEqualityComparer.Instance), 0);
            }
            if (pages.Count == 0)
            {
                // No usable page tree: fall back to every page object in file order.
                foreach (var dict in _objects.OrderBy(o => o.Key).Select(o => o.Value).OfType<Dict>().Where(d => Get(d, "Type") is Name { Value: "Page" }).Take(MaxPages))
                {
                    pages.Add((dict, Resolve(Get(dict, "Resources")) as Dict));
                }
            }
            return pages;
        }

        private void Walk(Dict node, Dict? inherited, List<(Dict, Dict?)> pages, HashSet<Dict> seen, int depth)
        {
            if (depth > 64 || !seen.Add(node) || pages.Count >= MaxPages)
            {
                if (pages.Count >= MaxPages)
                {
                    result.Truncated = true;
                }
                return;
            }
            var resources = Resolve(Get(node, "Resources")) as Dict ?? inherited;
            if (Resolve(Get(node, "Kids")) is List<object?> kids)
            {
                foreach (var kid in kids)
                {
                    if (Resolve(kid) is Dict child)
                    {
                        Walk(child, resources, pages, seen, depth + 1);
                    }
                }
            }
            else if (Get(node, "Type") is Name { Value: "Page" } || node.ContainsKey("Contents"))
            {
                pages.Add((node, resources));
            }
        }

        private IEnumerable<byte[]> ContentStreams(Dict page)
        {
            var contents = Resolve(Get(page, "Contents"));
            var list = contents is List<object?> array ? array.Select(Resolve) : [contents];
            foreach (var item in list)
            {
                if (item is PdfStream stream && Decode(stream) is { } bytes)
                {
                    yield return bytes;
                }
            }
        }

        // ---------- Content streams ----------

        private void RunContent(byte[] content, Dict? resources, TextWriter text, int depth)
        {
            if (depth > 8)
            {
                return;
            }
            var lexer = new Lexer(content, 0, content.Length);
            var operands = new List<object?>();
            Font? font = null;
            var fontSize = 1.0;
            var leading = 0.0;
            while (!lexer.AtEnd)
            {
                ct.ThrowIfCancellationRequested();
                object? token;
                try
                {
                    token = lexer.Next();
                }
                catch (FormatException)
                {
                    break;
                }
                if (token is not Operator op)
                {
                    if (operands.Count < 10_000)
                    {
                        operands.Add(token);
                    }
                    continue;
                }
                switch (op.Value)
                {
                    case "BT":
                        text.BeginText();
                        break;
                    case "Tf":
                        font = operands.Count >= 2 && operands[^2] is Name fontName ? FontFor(resources, fontName.Value) : null;
                        fontSize = operands.Count >= 1 ? Math.Abs(Number(operands[^1])) : 1;
                        break;
                    case "TL":
                        leading = operands.Count >= 1 ? Number(operands[^1]) : 0;
                        break;
                    case "Td":
                    case "TD":
                        if (operands.Count >= 2)
                        {
                            var tx = Number(operands[^2]);
                            var ty = Number(operands[^1]);
                            if (op.Value == "TD")
                            {
                                leading = -ty;
                            }
                            text.Move(tx, ty);
                        }
                        break;
                    case "Tm":
                        if (operands.Count >= 6)
                        {
                            text.SetMatrix(Number(operands[^2]), Number(operands[^1]));
                        }
                        break;
                    case "T*":
                        text.Move(0, -Math.Max(leading, fontSize));
                        break;
                    case "Tj":
                        if (operands.Count >= 1 && operands[^1] is byte[] s)
                        {
                            Show(s);
                        }
                        break;
                    case "'":
                    case "\"":
                        text.Move(0, -Math.Max(leading, fontSize));
                        if (operands.Count >= 1 && operands[^1] is byte[] s1)
                        {
                            Show(s1);
                        }
                        break;
                    case "TJ":
                        if (operands.Count >= 1 && operands[^1] is List<object?> parts)
                        {
                            foreach (var part in parts)
                            {
                                if (part is byte[] piece)
                                {
                                    Show(piece);
                                }
                                else if (part is double adjust)
                                {
                                    text.Advance(-adjust / 1000 * fontSize); // Negative adjustments move right (a gap).
                                }
                            }
                        }
                        break;
                    case "ET":
                        text.EndText();
                        break;
                    case "Do":
                        if (operands.Count >= 1 && operands[^1] is Name xname
                            && Resolve(Get(Resolve(Get(resources, "XObject")) as Dict, xname.Value)) is PdfStream form
                            && Get(form.Dictionary, "Subtype") is Name { Value: "Form" } && Decode(form) is { } formContent)
                        {
                            RunContent(formContent, Resolve(Get(form.Dictionary, "Resources")) as Dict ?? resources, text, depth + 1);
                        }
                        break;
                    case "BI":
                        SkipInlineImage(lexer, content);
                        break;
                }
                operands.Clear();
            }

            void Show(byte[] bytes)
            {
                var (value, units) = font is null ? (Encoding.Latin1.GetString(bytes), bytes.Length * 500.0) : font.Decode(bytes);
                text.Write(value, units / 1000 * fontSize, fontSize);
            }
        }

        private static void SkipInlineImage(Lexer lexer, byte[] content)
        {
            // Inline image data is binary: skip to the "EI" that ends it.
            var id = content.AsSpan(lexer.Position).IndexOf("ID"u8);
            if (id < 0)
            {
                lexer.Position = content.Length;
                return;
            }
            var from = lexer.Position + id + 2;
            for (var i = from; i + 1 < content.Length; i++)
            {
                if (content[i] == 'E' && content[i + 1] == 'I' && i > from && content[i - 1] is 32 or 10 or 13 or 9
                    && (i + 2 >= content.Length || content[i + 2] is 32 or 10 or 13 or 9))
                {
                    lexer.Position = i + 2;
                    return;
                }
            }
            lexer.Position = content.Length;
        }

        // ---------- Fonts ----------

        private Font? FontFor(Dict? resources, string name)
        {
            if (Resolve(Get(Resolve(Get(resources, "Font")) as Dict, name)) is not Dict dict)
            {
                return null;
            }
            if (!_fonts.TryGetValue(dict, out var font))
            {
                font = new Font(dict, this);
                _fonts[dict] = font;
            }
            return font;
        }

        private sealed class Font
        {
            private readonly Dictionary<int, string>? _unicode;
            private readonly int _bytesPerCode;
            private readonly string?[] _simple = new string?[256];
            private readonly bool _identityGuess;
            private readonly Dictionary<int, double> _widths = [];
            private readonly double _defaultWidth;

            public Font(Dict dict, Parser parser)
            {
                var subtype = (Get(dict, "Subtype") as Name)?.Value;
                var composite = subtype == "Type0";
                _bytesPerCode = composite ? 2 : 1;
                _defaultWidth = composite ? 1000 : 500;
                if (composite && parser.Resolve(Get(dict, "DescendantFonts")) is List<object?> descendants && descendants.Count > 0
                    && parser.Resolve(descendants[0]) is Dict cid)
                {
                    if (Get(cid, "DW") is double dw)
                    {
                        _defaultWidth = dw;
                    }
                    ReadCidWidths(parser.Resolve(Get(cid, "W")) as List<object?>, parser);
                }
                else if (parser.Resolve(Get(dict, "Widths")) is List<object?> widths)
                {
                    var firstChar = (int)Number(Get(dict, "FirstChar"));
                    for (var i = 0; i < widths.Count && i < 256; i++)
                    {
                        if (parser.Resolve(widths[i]) is double w)
                        {
                            _widths[firstChar + i] = w;
                        }
                    }
                    if (parser.Resolve(Get(dict, "FontDescriptor")) is Dict descriptor && Get(descriptor, "MissingWidth") is double missing && missing > 0)
                    {
                        _defaultWidth = missing;
                    }
                }
                if (parser.Resolve(Get(dict, "ToUnicode")) is PdfStream toUnicode && parser.Decode(toUnicode) is { } cmap)
                {
                    (_unicode, var width) = ParseCMap(cmap);
                    if (width > 0)
                    {
                        _bytesPerCode = width;
                    }
                }
                if (!composite)
                {
                    BuildSimpleEncoding(parser.Resolve(Get(dict, "Encoding")), parser);
                }
                else if (_unicode is null)
                {
                    _identityGuess = true; // No map: best effort treats 2-byte codes as UCS-2.
                }
            }

            private void BuildSimpleEncoding(object? encoding, Parser parser)
            {
                var baseName = encoding switch
                {
                    Name n => n.Value,
                    Dict d => (Get(d, "BaseEncoding") as Name)?.Value,
                    _ => null,
                };
                var codePage = baseName switch
                {
                    "MacRomanEncoding" => 10000,
                    _ => 1252,
                };
                var enc = CodePages.Value(codePage);
                for (var i = 0; i < 256; i++)
                {
                    _simple[i] = i < 32 ? null : enc.GetString([(byte)i]);
                }
                if (encoding is Dict dict && parser.Resolve(Get(dict, "Differences")) is List<object?> differences)
                {
                    var code = 0;
                    foreach (var item in differences)
                    {
                        if (item is double d)
                        {
                            code = (int)d;
                        }
                        else if (item is Name glyph && code is >= 0 and < 256)
                        {
                            _simple[code++] = GlyphNames.ToUnicode(glyph.Value);
                        }
                    }
                }
            }

            /// <summary>/W: "c [w1 w2 …]" (consecutive codes) or "cFirst cLast w" (a range).</summary>
            private void ReadCidWidths(List<object?>? w, Parser parser)
            {
                if (w is null)
                {
                    return;
                }
                for (var i = 0; i < w.Count;)
                {
                    if (parser.Resolve(w[i]) is not double first)
                    {
                        i++;
                        continue;
                    }
                    if (i + 1 < w.Count && parser.Resolve(w[i + 1]) is List<object?> list)
                    {
                        for (var k = 0; k < list.Count && _widths.Count < 200_000; k++)
                        {
                            if (parser.Resolve(list[k]) is double width)
                            {
                                _widths[(int)first + k] = width;
                            }
                        }
                        i += 2;
                    }
                    else if (i + 2 < w.Count && parser.Resolve(w[i + 1]) is double last && parser.Resolve(w[i + 2]) is double width)
                    {
                        for (var c = (int)first; c <= (int)last && c - (int)first < 65_536 && _widths.Count < 200_000; c++)
                        {
                            _widths[c] = width;
                        }
                        i += 3;
                    }
                    else
                    {
                        i++;
                    }
                }
            }

            /// <summary>Text for the codes in <paramref name="bytes"/> and their advance in glyph units (1/1000 em).</summary>
            public (string Text, double Units) Decode(byte[] bytes)
            {
                var sb = new StringBuilder(bytes.Length);
                var units = 0.0;
                for (var i = 0; i + _bytesPerCode <= bytes.Length; i += _bytesPerCode)
                {
                    var code = _bytesPerCode == 2 ? (bytes[i] << 8) | bytes[i + 1] : bytes[i];
                    units += _widths.TryGetValue(code, out var width) ? width : _defaultWidth;
                    if (_unicode is not null && _unicode.TryGetValue(code, out var mapped))
                    {
                        sb.Append(mapped);
                    }
                    else if (_bytesPerCode == 1)
                    {
                        sb.Append(_simple[code] ?? (code >= 32 ? ((char)code).ToString() : ""));
                    }
                    else if (_identityGuess && code >= 32 && code is < 0xD800 or > 0xDFFF)
                    {
                        sb.Append((char)code);
                    }
                }
                return (sb.ToString(), units);
            }
        }

        /// <summary>ToUnicode CMap: bfchar / bfrange entries and the code width from codespacerange.</summary>
        private static (Dictionary<int, string> Map, int Width) ParseCMap(byte[] cmap)
        {
            var map = new Dictionary<int, string>();
            var width = 0;
            var lexer = new Lexer(cmap, 0, cmap.Length);
            var operands = new List<object?>();
            while (!lexer.AtEnd && map.Count < 200_000)
            {
                object? token;
                try
                {
                    token = lexer.Next();
                }
                catch (FormatException)
                {
                    break;
                }
                if (token is not Operator op)
                {
                    operands.Add(token);
                    continue;
                }
                switch (op.Value)
                {
                    case "endcodespacerange":
                        if (operands.FirstOrDefault() is byte[] low)
                        {
                            width = Math.Clamp(low.Length, 1, 4);
                        }
                        break;
                    case "endbfchar":
                        for (var i = 0; i + 1 < operands.Count; i += 2)
                        {
                            if (operands[i] is byte[] src && operands[i + 1] is byte[] dst)
                            {
                                map[Code(src)] = Utf16(dst);
                                width = width == 0 ? src.Length : width;
                            }
                        }
                        break;
                    case "endbfrange":
                        for (var i = 0; i + 2 < operands.Count; i += 3)
                        {
                            if (operands[i] is not byte[] lo || operands[i + 1] is not byte[] hi)
                            {
                                continue;
                            }
                            var start = Code(lo);
                            var end = Math.Min(Code(hi), start + 65_535);
                            width = width == 0 ? lo.Length : width;
                            if (operands[i + 2] is byte[] dst && dst.Length >= 2)
                            {
                                var baseText = Utf16(dst);
                                for (var c = start; c <= end; c++)
                                {
                                    // Increment the last UTF-16 unit for each code in the range.
                                    map[c] = baseText[..^1] + (char)(baseText[^1] + (c - start));
                                }
                            }
                            else if (operands[i + 2] is List<object?> list)
                            {
                                for (var c = start; c <= end && c - start < list.Count; c++)
                                {
                                    if (list[c - start] is byte[] item)
                                    {
                                        map[c] = Utf16(item);
                                    }
                                }
                            }
                        }
                        break;
                }
                operands.Clear();
            }
            return (map, width);
        }

        private static int Code(byte[] bytes)
        {
            var code = 0;
            foreach (var b in bytes.Take(4))
            {
                code = (code << 8) | b;
            }
            return code;
        }

        private static string Utf16(byte[] bytes)
            => bytes.Length >= 2 ? Encoding.BigEndianUnicode.GetString(bytes, 0, bytes.Length - bytes.Length % 2) : Encoding.Latin1.GetString(bytes);

        /// <summary>PDF text strings: UTF-16BE with a byte-order mark, otherwise PDFDocEncoding (close to Latin-1).</summary>
        private static string TextString(byte[] bytes)
        {
            var text = bytes.Length >= 2 && bytes[0] == 0xFE && bytes[1] == 0xFF
                ? Encoding.BigEndianUnicode.GetString(bytes, 2, bytes.Length - 2)
                : Encoding.Latin1.GetString(bytes);
            return text.Replace("\0", "").Trim();
        }

        // ---------- Streams and filters ----------

        internal byte[]? Decode(PdfStream stream)
        {
            if (stream.Decoded is not null)
            {
                return stream.Decoded;
            }
            if (stream.Start + stream.Length > data.Length || stream.Length < 0)
            {
                return null;
            }
            var bytes = data.AsSpan(stream.Start, stream.Length).ToArray();
            var filters = Resolve(Get(stream.Dictionary, "Filter")) switch
            {
                Name n => [n.Value],
                List<object?> list => list.Select(Resolve).OfType<Name>().Select(n => n.Value).ToList(),
                _ => new List<string>(),
            };
            var parms = Resolve(Get(stream.Dictionary, "DecodeParms"));
            for (var i = 0; i < filters.Count; i++)
            {
                var p = parms is List<object?> pl ? (i < pl.Count ? Resolve(pl[i]) as Dict : null) : parms as Dict;
                bytes = filters[i] switch
                {
                    "FlateDecode" or "Fl" => Predict(Inflate(bytes), p),
                    "ASCIIHexDecode" or "AHx" => AsciiHex(bytes),
                    "ASCII85Decode" or "A85" => Ascii85(bytes),
                    _ => null!, // Images (DCT, JPX, CCITT, JBIG2) and LZW carry no text we can read.
                };
                if (bytes is null)
                {
                    return null;
                }
            }
            _decoded += bytes.Length;
            if (_decoded > MaxTotalDecodedBytes)
            {
                result.Truncated = true;
                throw new InvalidDataException("Decoded data limit reached.");
            }
            stream.Decoded = bytes;
            return bytes;
        }

        private byte[] Inflate(byte[] input)
        {
            foreach (var zlib in new[] { true, false })
            {
                try
                {
                    using var source = new MemoryStream(input);
                    using Stream inflater = zlib ? new ZLibStream(source, CompressionMode.Decompress) : new DeflateStream(source, CompressionMode.Decompress);
                    using var output = new MemoryStream();
                    var buffer = new byte[81920];
                    int read;
                    try
                    {
                        while ((read = inflater.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            output.Write(buffer, 0, read);
                            if (output.Length > MaxStreamBytes)
                            {
                                result.Truncated = true; // A decompression bomb stops here.
                                break;
                            }
                        }
                    }
                    catch (InvalidDataException) when (output.Length > 0)
                    {
                        // Truncated or damaged stream: keep what was decoded.
                    }
                    if (output.Length > 0 || zlib == false)
                    {
                        return output.ToArray();
                    }
                }
                catch (InvalidDataException)
                {
                    // Try raw deflate next (some writers omit the zlib header).
                }
            }
            return [];
        }

        /// <summary>PNG row predictors (predictor ≥ 10), used with Flate on some object/xref streams.</summary>
        private static byte[] Predict(byte[] data, Dict? parms)
        {
            var predictor = (int)Number(Get(parms, "Predictor"));
            if (predictor < 10)
            {
                return data;
            }
            var columns = Math.Max(1, (int)(Get(parms, "Columns") is double c ? c : 1));
            var colors = Math.Max(1, (int)(Get(parms, "Colors") is double k ? k : 1));
            var bits = Math.Max(1, (int)(Get(parms, "BitsPerComponent") is double b ? b : 8));
            var bpp = Math.Max(1, colors * bits / 8);
            var rowLength = (columns * colors * bits + 7) / 8;
            var output = new List<byte>(data.Length);
            var previous = new byte[rowLength];
            for (var pos = 0; pos + 1 + rowLength <= data.Length; pos += rowLength + 1)
            {
                var type = data[pos];
                var row = data.AsSpan(pos + 1, rowLength).ToArray();
                for (var i = 0; i < rowLength; i++)
                {
                    var left = i >= bpp ? row[i - bpp] : 0;
                    var up = previous[i];
                    var upLeft = i >= bpp ? previous[i - bpp] : 0;
                    row[i] = type switch
                    {
                        1 => (byte)(row[i] + left),
                        2 => (byte)(row[i] + up),
                        3 => (byte)(row[i] + (left + up) / 2),
                        4 => (byte)(row[i] + Paeth(left, up, upLeft)),
                        _ => row[i],
                    };
                }
                output.AddRange(row);
                previous = row;
            }
            return [.. output];
        }

        private static int Paeth(int a, int b, int c)
        {
            var p = a + b - c;
            var pa = Math.Abs(p - a);
            var pb = Math.Abs(p - b);
            var pc = Math.Abs(p - c);
            return pa <= pb && pa <= pc ? a : pb <= pc ? b : c;
        }

        private static byte[] AsciiHex(byte[] input)
        {
            var hex = new StringBuilder();
            foreach (var b in input)
            {
                if (b == '>')
                {
                    break;
                }
                if (Uri.IsHexDigit((char)b))
                {
                    hex.Append((char)b);
                }
            }
            if (hex.Length % 2 == 1)
            {
                hex.Append('0');
            }
            return Convert.FromHexString(hex.ToString());
        }

        private static byte[] Ascii85(byte[] input)
        {
            var output = new List<byte>();
            var group = new List<int>(5);
            foreach (var b in input)
            {
                if (b == '~')
                {
                    break;
                }
                if (b == 'z' && group.Count == 0)
                {
                    output.AddRange([0, 0, 0, 0]);
                    continue;
                }
                if (b < '!' || b > 'u')
                {
                    continue;
                }
                group.Add(b - '!');
                if (group.Count == 5)
                {
                    Flush(5);
                }
            }
            if (group.Count > 1)
            {
                var n = group.Count;
                while (group.Count < 5)
                {
                    group.Add(84);
                }
                Flush(n);
            }
            return [.. output];

            void Flush(int count)
            {
                long value = 0;
                foreach (var g in group)
                {
                    value = value * 85 + g;
                }
                var bytes = new[] { (byte)(value >> 24), (byte)(value >> 16), (byte)(value >> 8), (byte)value };
                output.AddRange(bytes.Take(count - 1));
                group.Clear();
            }
        }

        // ---------- Helpers ----------

        internal object? Resolve(object? value, int depth = 0)
        {
            while (value is Ref r && depth++ < 32)
            {
                value = _objects.TryGetValue(r.Number, out var target) ? target : null;
            }
            return value;
        }
    }

    private static object? Get(Dictionary<string, object?>? dict, string key) => dict is not null && dict.TryGetValue(key, out var v) ? v : null;

    private static double Number(object? value) => value is double d ? d : 0;

    /// <summary>
    /// Collects text into lines using the text position: a new line when the baseline changes, a space when there is a
    /// horizontal gap between the end of the previous text and the next (glyph advances come from the font's widths).
    /// Positions are kept in text space and survive BT/ET, so runs that continue a line are joined correctly.
    /// </summary>
    private sealed class TextWriter
    {
        private readonly StringBuilder _sb = new();
        private double _lineX;
        private double _lineY;
        private double _x;
        private double _lastEndX = double.NaN;
        private double _lastY = double.NaN;

        public void BeginText()
        {
            _lineX = _lineY = _x = 0; // BT resets the text matrix; the last written position is kept for comparison.
        }

        public void EndText()
        {
        }

        public void Move(double tx, double ty)
        {
            _lineX += tx;
            _lineY += ty;
            _x = _lineX;
        }

        public void SetMatrix(double x, double y)
        {
            _lineX = _x = x;
            _lineY = y;
        }

        public void Advance(double dx) => _x += dx;

        public void Write(string text, double advance, double fontSize)
        {
            if (text.Length == 0)
            {
                _x += advance;
                return;
            }
            var size = Math.Max(fontSize, 0.1);
            if (!double.IsNaN(_lastY))
            {
                if (Math.Abs(_lineY - _lastY) > size * 0.4)
                {
                    NewLine();
                }
                else
                {
                    var gap = _x - _lastEndX;
                    // A clear gap (or a jump back to an earlier column) separates words.
                    if ((gap > size * 0.15 || gap < -size * 2) && _sb.Length > 0 && _sb[^1] is not (' ' or '\n') && !char.IsWhiteSpace(text[0]))
                    {
                        _sb.Append(' ');
                    }
                }
            }
            foreach (var c in text)
            {
                if (c == '\r' || c == '\n')
                {
                    NewLine();
                }
                else if (c == '\t')
                {
                    _sb.Append(' ');
                }
                else if (!char.IsControl(c) || char.IsWhiteSpace(c))
                {
                    _sb.Append(c);
                }
            }
            _x += advance;
            _lastEndX = _x;
            _lastY = _lineY;
        }

        private void NewLine()
        {
            while (_sb.Length > 0 && _sb[^1] == ' ')
            {
                _sb.Length--;
            }
            if (_sb.Length > 0 && _sb[^1] != '\n')
            {
                _sb.Append('\n');
            }
        }

        public override string ToString()
        {
            var lines = _sb.ToString().Split('\n').Select(l => l.TrimEnd());
            return string.Join('\n', lines).Trim();
        }
    }

    private static class CodePages
    {
        public static Encoding Value(int codePage)
        {
            try
            {
                return codePage == 1252 ? Win1252.Instance : Encoding.GetEncoding(codePage);
            }
            catch (Exception ex) when (ex is ArgumentException or NotSupportedException)
            {
                return Win1252.Instance;
            }
        }
    }

    /// <summary>Windows-1252 without depending on the code-pages provider being registered.</summary>
    private sealed class Win1252 : Encoding
    {
        public static readonly Win1252 Instance = new();
        private static readonly char[] High =
        [
            '€', '\u0081', '‚', 'ƒ', '„', '…', '†', '‡', 'ˆ', '‰', 'Š', '‹', 'Œ', '\u008D', 'Ž', '\u008F',
            '\u0090', '‘', '’', '“', '”', '•', '–', '—', '˜', '™', 'š', '›', 'œ', '\u009D', 'ž', 'Ÿ',
        ];
        public override int GetByteCount(char[] chars, int index, int count) => count;
        public override int GetBytes(char[] chars, int charIndex, int charCount, byte[] bytes, int byteIndex) => throw new NotSupportedException();
        public override int GetCharCount(byte[] bytes, int index, int count) => count;
        public override int GetChars(byte[] bytes, int byteIndex, int byteCount, char[] chars, int charIndex)
        {
            for (var i = 0; i < byteCount; i++)
            {
                var b = bytes[byteIndex + i];
                chars[charIndex + i] = b is >= 0x80 and <= 0x9F ? High[b - 0x80] : (char)b;
            }
            return byteCount;
        }
        public override int GetMaxByteCount(int charCount) => charCount;
        public override int GetMaxCharCount(int byteCount) => byteCount;
    }

    /// <summary>Glyph names used in /Differences (a practical subset of the Adobe Glyph List).</summary>
    private static class GlyphNames
    {
        private static readonly Dictionary<string, string> Map = new(StringComparer.Ordinal)
        {
            ["space"] = " ", ["exclam"] = "!", ["quotedbl"] = "\"", ["numbersign"] = "#", ["dollar"] = "$", ["percent"] = "%", ["ampersand"] = "&",
            ["quotesingle"] = "'", ["quoteright"] = "’", ["quoteleft"] = "‘", ["parenleft"] = "(", ["parenright"] = ")", ["asterisk"] = "*",
            ["plus"] = "+", ["comma"] = ",", ["hyphen"] = "-", ["minus"] = "−", ["period"] = ".", ["slash"] = "/", ["colon"] = ":", ["semicolon"] = ";",
            ["less"] = "<", ["equal"] = "=", ["greater"] = ">", ["question"] = "?", ["at"] = "@", ["bracketleft"] = "[", ["backslash"] = "\\",
            ["bracketright"] = "]", ["asciicircum"] = "^", ["underscore"] = "_", ["grave"] = "`", ["braceleft"] = "{", ["bar"] = "|", ["braceright"] = "}",
            ["asciitilde"] = "~", ["bullet"] = "•", ["endash"] = "–", ["emdash"] = "—", ["ellipsis"] = "…", ["quotedblleft"] = "“",
            ["quotedblright"] = "”", ["quotesinglbase"] = "‚", ["quotedblbase"] = "„", ["trademark"] = "™", ["copyright"] = "©",
            ["registered"] = "®", ["degree"] = "°", ["fi"] = "fi", ["fl"] = "fl", ["ff"] = "ff", ["ffi"] = "ffi", ["ffl"] = "ffl",
            ["Euro"] = "€", ["sterling"] = "£", ["yen"] = "¥", ["section"] = "§", ["paragraph"] = "¶", ["dagger"] = "†",
            ["daggerdbl"] = "‡", ["nbspace"] = " ", ["zero"] = "0", ["one"] = "1", ["two"] = "2", ["three"] = "3", ["four"] = "4", ["five"] = "5",
            ["six"] = "6", ["seven"] = "7", ["eight"] = "8", ["nine"] = "9", ["eacute"] = "é", ["egrave"] = "è", ["aacute"] = "á",
            ["agrave"] = "à", ["ccedilla"] = "ç", ["odieresis"] = "ö", ["udieresis"] = "ü", ["adieresis"] = "ä", ["germandbls"] = "ß",
            ["ntilde"] = "ñ", ["checkmark"] = "✓",
        };

        public static string ToUnicode(string name)
        {
            if (Map.TryGetValue(name, out var value))
            {
                return value;
            }
            if (name.Length == 1)
            {
                return name;
            }
            if (name.StartsWith("uni", StringComparison.Ordinal) && name.Length >= 7
                && int.TryParse(name.AsSpan(3, 4), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var code))
            {
                return ((char)code).ToString();
            }
            if (name.Length >= 5 && name[0] == 'u' && int.TryParse(name.AsSpan(1), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out var code2) && code2 <= 0x10FFFF)
            {
                return char.ConvertFromUtf32(code2);
            }
            var dot = name.IndexOf('.');
            return dot > 0 ? ToUnicode(name[..dot]) : "";
        }
    }
}
