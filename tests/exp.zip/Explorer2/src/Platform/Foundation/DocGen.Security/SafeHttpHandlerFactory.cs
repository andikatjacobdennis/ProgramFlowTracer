using System.Net;
using System.Net.Sockets;
using DocGen.Core.Exceptions;

namespace DocGen.Security;

/// <summary>
/// Builds the primary handler for the agent's outbound HTTP client. The ConnectCallback re-validates the
/// actual IP being connected to, so a host that passes URL validation cannot later resolve to an internal
/// address. Automatic redirects are disabled; callers validate each hop.
/// </summary>
public static class SafeHttpHandlerFactory
{
    public static SocketsHttpHandler Create(NetworkDestinationValidator validator, TimeSpan connectTimeout) => new()
    {
        AllowAutoRedirect = false,
        UseCookies = false,
        UseProxy = false, // A proxy would bypass the IP checks performed below.
        AutomaticDecompression = DecompressionMethods.All,
        ConnectTimeout = connectTimeout,
        PooledConnectionLifetime = TimeSpan.FromMinutes(5),
        MaxResponseHeadersLength = 64, // KB
        ConnectCallback = async (context, cancellationToken) =>
        {
            var addresses = await validator.ResolveAllowedAsync(context.DnsEndPoint.Host, cancellationToken).ConfigureAwait(false);
            Exception? last = null;
            foreach (var address in addresses)
            {
                var socket = new Socket(address.AddressFamily, SocketType.Stream, ProtocolType.Tcp) { NoDelay = true };
                try
                {
                    await socket.ConnectAsync(new IPEndPoint(address, context.DnsEndPoint.Port), cancellationToken).ConfigureAwait(false);
                    return new NetworkStream(socket, ownsSocket: true);
                }
                catch (SocketException ex)
                {
                    socket.Dispose();
                    last = ex;
                }
                catch
                {
                    socket.Dispose();
                    throw;
                }
            }
            throw new NetworkException("Could not connect to the destination.", last, "CONNECT_FAILED");
        },
    };
}
