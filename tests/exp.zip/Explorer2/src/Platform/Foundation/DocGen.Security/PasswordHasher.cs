using System.Security.Cryptography;
using System.Text;

namespace DocGen.Security;

/// <summary>
/// PBKDF2-HMAC-SHA256 password hashing using the .NET built-in <see cref="Rfc2898DeriveBytes"/>.
/// Format: PBKDF2-SHA256${iterations}${saltBase64}${hashBase64}
/// </summary>
public sealed class PasswordHasher(int iterations = 210_000)
{
    private const string Prefix = "PBKDF2-SHA256";
    private const int SaltBytes = 16;
    private const int HashBytes = 32;

    public string Hash(string password)
    {
        ArgumentNullException.ThrowIfNull(password);
        var salt = RandomNumberGenerator.GetBytes(SaltBytes);
        var hash = Rfc2898DeriveBytes.Pbkdf2(Encoding.UTF8.GetBytes(password), salt, iterations, HashAlgorithmName.SHA256, HashBytes);
        return $"{Prefix}${iterations}${Convert.ToBase64String(salt)}${Convert.ToBase64String(hash)}";
    }

    public bool Verify(string password, string encoded)
    {
        if (string.IsNullOrEmpty(password) || string.IsNullOrEmpty(encoded))
        {
            return false;
        }

        var parts = encoded.Split('$');
        if (parts.Length != 4 || parts[0] != Prefix || !int.TryParse(parts[1], out var storedIterations) || storedIterations < 1)
        {
            return false;
        }

        try
        {
            var salt = Convert.FromBase64String(parts[2]);
            var expected = Convert.FromBase64String(parts[3]);
            var actual = Rfc2898DeriveBytes.Pbkdf2(Encoding.UTF8.GetBytes(password), salt, storedIterations, HashAlgorithmName.SHA256, expected.Length);
            return CryptographicOperations.FixedTimeEquals(actual, expected);
        }
        catch (FormatException)
        {
            return false;
        }
    }

    /// <summary>True when the stored hash uses fewer iterations than currently configured.</summary>
    public bool NeedsRehash(string encoded)
    {
        var parts = encoded.Split('$');
        return parts.Length != 4 || !int.TryParse(parts[1], out var stored) || stored < iterations;
    }
}

/// <summary>Random bearer tokens (e.g. TCP access tokens) stored only as SHA-256 hashes.</summary>
public static class AccessTokens
{
    public static string Generate() => "dgx_" + Convert.ToBase64String(RandomNumberGenerator.GetBytes(32))
        .Replace('+', '-').Replace('/', '_').TrimEnd('=');

    public static string HashToken(string token) => Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(token)));
}
