using DocGen.Core.Exceptions;

namespace DocGen.Security;

/// <summary>
/// Resolves user/model supplied relative paths inside a workspace root. Rejects absolute paths,
/// traversal ("../"), alternate data streams, device names, and symbolic links / junctions that
/// would lead outside the root.
/// </summary>
public static partial class WorkspacePathResolver
{
    private static readonly HashSet<string> ReservedNames = new(StringComparer.OrdinalIgnoreCase)
    {
        "CON", "PRN", "AUX", "NUL", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
        "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9",
        "CONIN$", "CONOUT$", "COM¹", "COM²", "COM³", "LPT¹", "LPT²", "LPT³",
    };

    /// <summary>Returns the absolute path for <paramref name="relativePath"/> or throws <see cref="ValidationException"/>.</summary>
    public static string Resolve(string workspaceRoot, string? relativePath)
    {
        var root = Path.GetFullPath(workspaceRoot).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        var candidate = (relativePath ?? "").Trim();

        if (candidate.Length == 0 || candidate is "." or "/" or "\\")
        {
            return root;
        }
        if (candidate.Length > 400)
        {
            throw new ValidationException("Path is too long.");
        }
        // A drive path (C:\…) used to be reported as "invalid characters", which models misread as a broken file name
        // and worked around with shell commands. Say what is wrong and what to pass instead.
        if (candidate.Length >= 3 && char.IsAsciiLetter(candidate[0]) && candidate[1] == ':' && candidate[2] is '\\' or '/')
        {
            throw new ValidationException("Absolute paths are not allowed. Use a path relative to the folder (and 'repository' to read another registered folder).");
        }
        if (candidate.Contains('\0') || candidate.Contains(':') || candidate.StartsWith('~'))
        {
            throw new ValidationException("Path contains invalid characters.");
        }

        var normalizedSeparators = candidate.Replace('\\', '/');
        if (normalizedSeparators.StartsWith('/') || Path.IsPathRooted(candidate) || normalizedSeparators.StartsWith("//", StringComparison.Ordinal))
        {
            throw new ValidationException("Absolute paths are not allowed. Use a path relative to the workspace.");
        }

        var segments = normalizedSeparators.Split('/', StringSplitOptions.RemoveEmptyEntries);
        foreach (var segment in segments)
        {
            if (segment is ".." || segment.Trim('.').Length == 0 && segment.Length > 1)
            {
                throw new ValidationException("Path traversal is not allowed.");
            }
            var baseName = segment.Split('.')[0];
            if (ReservedNames.Contains(baseName) || segment.EndsWith(' ') || segment.EndsWith('.') && segment != ".")
            {
                throw new ValidationException("Path contains a reserved or invalid name.");
            }
            if (segment.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0)
            {
                throw new ValidationException("Path contains invalid characters.");
            }
            if (ShortName().IsMatch(segment))
            {
                // 8.3 short names (GENERA~1) are aliases of other folders: they would slip past name-based protections.
                throw new ValidationException("Short (8.3) file names are not allowed; use the full name.");
            }
            if (string.Equals(segment, ".git", StringComparison.OrdinalIgnoreCase))
            {
                // Git's metadata is managed only by DocGen's own Git operations, never by file reads or writes.
                throw new ValidationException("Paths inside .git are not accessible.");
            }
        }

        var full = Path.GetFullPath(Path.Combine(root, Path.Combine(segments.Where(s => s != ".").ToArray())));
        if (!IsWithin(root, full))
        {
            throw new ValidationException("Path escapes the workspace.");
        }

        EnsureNoLinkEscape(root, full);
        return full;
    }

    public static bool IsWithin(string root, string path)
    {
        var normalizedRoot = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        var normalizedPath = Path.GetFullPath(path);
        return normalizedPath.StartsWith(normalizedRoot, StringComparison.OrdinalIgnoreCase)
               || string.Equals(normalizedPath.TrimEnd(Path.DirectorySeparatorChar), normalizedRoot.TrimEnd(Path.DirectorySeparatorChar), StringComparison.OrdinalIgnoreCase);
    }

    /// <summary>Converts an absolute path inside the root to a '/'-separated relative path.</summary>
    public static string ToRelative(string workspaceRoot, string fullPath)
        => Path.GetRelativePath(Path.GetFullPath(workspaceRoot), fullPath).Replace('\\', '/');

    /// <summary>Walks every existing component and rejects links whose targets resolve outside the root.</summary>
    private static void EnsureNoLinkEscape(string root, string full)
    {
        var current = root;
        var relative = Path.GetRelativePath(root, full);
        if (relative == ".")
        {
            return;
        }

        foreach (var segment in relative.Split(Path.DirectorySeparatorChar, StringSplitOptions.RemoveEmptyEntries))
        {
            current = Path.Combine(current, segment);
            FileSystemInfo? info = Directory.Exists(current) ? new DirectoryInfo(current) : File.Exists(current) ? new FileInfo(current) : null;
            if (info is null)
            {
                return; // Remaining components do not exist yet (e.g. a new file to write).
            }
            if (info.LinkTarget is not null || info.Attributes.HasFlag(FileAttributes.ReparsePoint))
            {
                var target = info.ResolveLinkTarget(returnFinalTarget: true);
                if (target is null || !IsWithin(root, target.FullName))
                {
                    throw new ValidationException("Symbolic links that leave the workspace are not allowed.");
                }
            }
        }
    }

    [System.Text.RegularExpressions.GeneratedRegex(@"^[^~.]{1,6}~\d{1,6}(?:\.[^.]{0,3})?$")]
    private static partial System.Text.RegularExpressions.Regex ShortName();
}
