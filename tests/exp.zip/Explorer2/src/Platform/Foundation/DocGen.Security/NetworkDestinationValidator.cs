using System.Net;
using System.Net.Sockets;
using DocGen.Core.Exceptions;
using DocGen.Core.Options;

namespace DocGen.Security;

/// <summary>
/// SSRF protection for agent-initiated HTTP requests. Validates schemes and host names up front and
/// validates every resolved IP address at connect time (defeating DNS rebinding).
/// </summary>
public sealed class NetworkDestinationValidator(HttpToolOptions options)
{
    private static readonly (IPAddress Network, int Prefix)[] BlockedV4 =
    [
        (IPAddress.Parse("0.0.0.0"), 8),        // "this" network
        (IPAddress.Parse("10.0.0.0"), 8),       // private
        (IPAddress.Parse("100.64.0.0"), 10),    // carrier-grade NAT
        (IPAddress.Parse("127.0.0.0"), 8),      // loopback
        (IPAddress.Parse("169.254.0.0"), 16),   // link-local incl. cloud metadata 169.254.169.254
        (IPAddress.Parse("172.16.0.0"), 12),    // private
        (IPAddress.Parse("192.0.0.0"), 24),     // IETF protocol assignments
        (IPAddress.Parse("192.0.2.0"), 24),     // documentation
        (IPAddress.Parse("192.168.0.0"), 16),   // private
        (IPAddress.Parse("198.18.0.0"), 15),    // benchmarking
        (IPAddress.Parse("198.51.100.0"), 24),  // documentation
        (IPAddress.Parse("203.0.113.0"), 24),   // documentation
        (IPAddress.Parse("224.0.0.0"), 4),      // multicast
        (IPAddress.Parse("240.0.0.0"), 4),      // reserved + broadcast
    ];

    private static readonly (IPAddress Network, int Prefix)[] BlockedV6 =
    [
        (IPAddress.Parse("::"), 128),           // unspecified
        (IPAddress.Parse("::1"), 128),          // loopback
        (IPAddress.Parse("fc00::"), 7),         // unique local
        (IPAddress.Parse("fe80::"), 10),        // link-local
        (IPAddress.Parse("ff00::"), 8),         // multicast
        (IPAddress.Parse("2001:db8::"), 32),    // documentation
        (IPAddress.Parse("64:ff9b::"), 96),     // NAT64 (can embed private v4)
        (IPAddress.Parse("fd00:ec2::254"), 128),// cloud metadata (IPv6)
    ];

    /// <summary>Validates the URL's scheme and host before any network activity.</summary>
    public Uri ValidateUrl(string? url)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri))
        {
            throw new NetworkException("The URL is not a valid absolute URL.", code: "INVALID_URL");
        }
        if (!options.AllowedSchemes.Contains(uri.Scheme, StringComparer.OrdinalIgnoreCase))
        {
            throw new NetworkException($"The URL scheme '{uri.Scheme}' is not allowed.", code: "BLOCKED_DESTINATION");
        }
        if (!string.IsNullOrEmpty(uri.UserInfo))
        {
            throw new NetworkException("URLs containing credentials are not allowed.", code: "BLOCKED_DESTINATION");
        }

        var host = uri.IdnHost.TrimEnd('.');
        if (IsExplicitlyAllowed(host))
        {
            return uri;
        }
        if (host.Equals("localhost", StringComparison.OrdinalIgnoreCase) || host.EndsWith(".localhost", StringComparison.OrdinalIgnoreCase)
            || host.EndsWith(".local", StringComparison.OrdinalIgnoreCase) || host.EndsWith(".internal", StringComparison.OrdinalIgnoreCase)
            || options.BlockedHosts.Contains(host, StringComparer.OrdinalIgnoreCase))
        {
            throw new NetworkException("Requests to local or internal hosts are blocked.", code: "BLOCKED_DESTINATION");
        }
        if (IPAddress.TryParse(uri.Host.Trim('[', ']'), out var literal) && IsBlocked(literal))
        {
            throw new NetworkException("Requests to private, loopback or link-local addresses are blocked.", code: "BLOCKED_DESTINATION");
        }
        return uri;
    }

    /// <summary>Resolves the host and returns only permitted addresses (throws if none remain).</summary>
    public async Task<IPAddress[]> ResolveAllowedAsync(string host, CancellationToken cancellationToken)
    {
        IPAddress[] addresses;
        if (IPAddress.TryParse(host.Trim('[', ']'), out var literal))
        {
            addresses = [literal];
        }
        else
        {
            try
            {
                addresses = await Dns.GetHostAddressesAsync(host, cancellationToken).ConfigureAwait(false);
            }
            catch (SocketException ex)
            {
                throw new NetworkException($"Could not resolve host '{host}'.", ex, "DNS_FAILURE");
            }
        }

        if (IsExplicitlyAllowed(host))
        {
            return addresses;
        }

        // Every resolved address must be public: a mix is treated as hostile.
        if (addresses.Length == 0 || addresses.Any(IsBlocked))
        {
            throw new NetworkException("The destination resolves to a blocked (private or internal) address.", code: "BLOCKED_DESTINATION");
        }
        return addresses;
    }

    public static bool IsBlocked(IPAddress address)
    {
        if (address.IsIPv4MappedToIPv6)
        {
            address = address.MapToIPv4();
        }

        var ranges = address.AddressFamily == AddressFamily.InterNetwork ? BlockedV4 : BlockedV6;
        if (address.AddressFamily is not (AddressFamily.InterNetwork or AddressFamily.InterNetworkV6))
        {
            return true;
        }
        if (address.AddressFamily == AddressFamily.InterNetworkV6 && (address.IsIPv6SiteLocal || address.IsIPv6LinkLocal || address.IsIPv6Multicast))
        {
            return true;
        }
        return ranges.Any(r => InRange(address, r.Network, r.Prefix));
    }

    private bool IsExplicitlyAllowed(string host) => options.AllowedPrivateHosts.Contains(host, StringComparer.OrdinalIgnoreCase);

    private static bool InRange(IPAddress address, IPAddress network, int prefix)
    {
        if (address.AddressFamily != network.AddressFamily)
        {
            return false;
        }
        var a = address.GetAddressBytes();
        var n = network.GetAddressBytes();
        var fullBytes = prefix / 8;
        for (var i = 0; i < fullBytes; i++)
        {
            if (a[i] != n[i])
            {
                return false;
            }
        }
        var remaining = prefix % 8;
        if (remaining == 0)
        {
            return true;
        }
        var mask = (byte)(0xFF << (8 - remaining));
        return (a[fullBytes] & mask) == (n[fullBytes] & mask);
    }
}
