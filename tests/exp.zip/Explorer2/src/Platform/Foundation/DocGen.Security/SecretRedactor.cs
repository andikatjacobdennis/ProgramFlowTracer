using System.Text.RegularExpressions;

namespace DocGen.Security;

/// <summary>
/// Central secret redaction used by logging, run records and tool argument previews.
/// </summary>
public static partial class SecretRedactor
{
    public const string Mask = "[REDACTED]";

    private static readonly HashSet<string> SensitiveNames = new(StringComparer.OrdinalIgnoreCase)
    {
        "authorization", "proxy-authorization", "cookie", "set-cookie", "x-api-key", "api-key", "apikey", "api_key",
        "password", "passwd", "pwd", "secret", "client_secret", "token", "access_token", "refresh_token", "id_token",
        "x-auth-token", "x-docgen-token", "currentpassword", "newpassword", "privatekey", "private_key",
    };

    public static bool IsSensitiveName(string? name)
    {
        if (string.IsNullOrEmpty(name))
        {
            return false;
        }
        if (SensitiveNames.Contains(name))
        {
            return true;
        }
        var lower = name.ToLowerInvariant();
        return lower.Contains("password") || lower.Contains("secret") || lower.Contains("apikey") || lower.Contains("api_key")
               || lower.Contains("api-key") || lower.EndsWith("token") || lower.Contains("credential");
    }

    /// <summary>Masks well-known secret shapes inside free text.</summary>
    public static string Redact(string? text)
    {
        if (string.IsNullOrEmpty(text))
        {
            return text ?? "";
        }
        var result = BearerPattern().Replace(text, m => m.Groups[1].Value + Mask);
        result = KeyValuePattern().Replace(result, m => m.Groups[1].Value + m.Groups[2].Value + Mask);
        result = JsonSecretPattern().Replace(result, m => m.Groups[1].Value + Mask + "\"");
        result = TokenShapePattern().Replace(result, Mask);
        result = JwtPattern().Replace(result, Mask);
        result = PemPrivateKeyPattern().Replace(result, Mask);
        return result;
    }

    public static IDictionary<string, string> RedactHeaders(IEnumerable<KeyValuePair<string, string>> headers)
        => headers.ToDictionary(h => h.Key, h => IsSensitiveName(h.Key) ? Mask : h.Value, StringComparer.OrdinalIgnoreCase);

    [GeneratedRegex(@"(\b(?:Bearer|Basic|Token)\s+)[A-Za-z0-9\-\._~\+/=]{8,}", RegexOptions.IgnoreCase)]
    private static partial Regex BearerPattern();

    // "=" but not "==" or "=>": "token == null" and "token => …" in code are a comparison and a lambda, not a value.
    [GeneratedRegex(@"(\b(?:password|passwd|pwd|secret|api[_-]?key|access[_-]?token|refresh[_-]?token|token|client[_-]?secret)\b)(\s*(?:=(?![=>])|:)\s*)(?!\[REDACTED\])[^\s&,;""']+", RegexOptions.IgnoreCase)]
    private static partial Regex KeyValuePattern();

    [GeneratedRegex(@"(""(?:password|passwd|secret|apiKey|api_key|accessToken|access_token|refreshToken|token|clientSecret|authorization)""\s*:\s*"")[^""]*""", RegexOptions.IgnoreCase)]
    private static partial Regex JsonSecretPattern();

    [GeneratedRegex(@"\b(?:sk-[A-Za-z0-9_\-]{16,}|dgx_[A-Za-z0-9_\-]{20,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{22,}|xox[abprs]-[A-Za-z0-9\-]{10,}|AKIA[0-9A-Z]{16}|AIza[0-9A-Za-z_\-]{30,}|gsk_[A-Za-z0-9]{20,}|ATATT[A-Za-z0-9_\-=]{20,})")]
    private static partial Regex TokenShapePattern();

    [GeneratedRegex(@"\beyJ[A-Za-z0-9_\-]{8,}\.eyJ[A-Za-z0-9_\-]{8,}\.[A-Za-z0-9_\-]{8,}")]
    private static partial Regex JwtPattern();

    [GeneratedRegex(@"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?(?:-----END [A-Z ]*PRIVATE KEY-----|$)")]
    private static partial Regex PemPrivateKeyPattern();
}
