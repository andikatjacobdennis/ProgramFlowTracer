using DocGen.Core.Abstractions;
using DocGen.Core.Models;
using DocGen.Core.Options;
using Microsoft.Extensions.Options;

namespace DocGen.Security;

/// <summary>
/// Deterministic tool permission policy. Decisions depend only on configuration (appsettings + the
/// runtime Tools page settings), the tool's declared or server-assessed risk, the capability policy for the user's
/// role, and the trusted execution context — never on model output.
/// </summary>
public sealed class PermissionManager(IOptionsMonitor<PermissionOptions> options, ISettingsService settings, IUserRepository? users = null,
    DocGen.Core.Skills.ISkillRegistry? skills = null) : IPermissionManager
{
    public async Task<bool> IsEnabledAsync(string toolName, CancellationToken cancellationToken = default)
    {
        if (options.CurrentValue.DisabledTools.Contains(toolName, StringComparer.OrdinalIgnoreCase))
        {
            return false;
        }
        var app = await settings.GetAppSettingsAsync(cancellationToken);
        if (app.DisabledTools.Contains(toolName, StringComparer.OrdinalIgnoreCase))
        {
            return false;
        }
        // A built-in skill's own tools (e.g. diagram_render) exist only while that skill is turned on.
        return skills is null || await skills.IsProvidedToolEnabledAsync(toolName, cancellationToken) != false;
    }

    public async Task<PermissionDecision> EvaluateAsync(IAgentTool tool, ToolCall call, ToolExecutionContext context, CancellationToken cancellationToken = default)
        => (await EvaluateDetailedAsync(tool, call, context, cancellationToken)).Decision;

    public async Task<(PermissionDecision Decision, ToolRiskAssessment Assessment)> EvaluateDetailedAsync(IAgentTool tool, ToolCall call, ToolExecutionContext context,
        CancellationToken cancellationToken = default)
    {
        ToolRiskAssessment assessment;
        try
        {
            assessment = tool is IDynamicRiskTool dynamic ? await dynamic.AssessAsync(call, context, cancellationToken) : ToolRiskAssessment.Static(tool);
        }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            // An assessment that cannot be made (invalid arguments, unknown path…) is never treated as low risk.
            assessment = new ToolRiskAssessment(ToolRiskLevel.Sensitive, Findings: ["risk could not be assessed: " + ex.Message]);
        }

        PermissionDecision decision;
        if (!await IsEnabledAsync(tool.Name, cancellationToken) || assessment.DenyReason is not null)
        {
            decision = PermissionDecision.Deny;
        }
        else
        {
            decision = await DecideAsync(tool.Name, assessment.Risk, cancellationToken);
            if (assessment.Capability is { } capability)
            {
                decision = Stricter(decision, await CapabilityDecisionAsync(capability, context.UserId, cancellationToken));
            }
            // Unattended channels (TCP) keep the strict policy: nobody is watching what runs.
            if (decision == PermissionDecision.Ask && context.Source != "tcp" && await IsRoutineAllowedAsync(tool, assessment, cancellationToken))
            {
                decision = PermissionDecision.Allow;
            }
        }

        // Skills never widen permissions, and a skill that did not ship with DocGen narrows them: while one is active,
        // a tool that changes something or reaches outside (write, command, network) and that no active skill declared
        // asks the user, whatever the approval mode. Read-only tools on local data are unaffected.
        if (decision == PermissionDecision.Allow && context.Skills is { } skillSession && skillSession.RequiresApprovalFor(tool.Name)
            && (assessment.Risk > ToolRiskLevel.ReadOnly || assessment.SystemOrNetwork))
        {
            decision = PermissionDecision.Ask;
            assessment = assessment with
            {
                Findings = [.. assessment.Findings ?? [], $"Asked because the skill {string.Join(", ", skillSession.UntrustedActiveNames)} is active and did not declare {tool.Name}."],
            };
        }

        // Commit/push-style tools always ask: the model and configuration cannot supply the user's intent.
        if (tool is IUserIntentTool && decision == PermissionDecision.Allow)
        {
            decision = PermissionDecision.Ask;
        }

        // Non-interactive channels (TCP) cannot show an approval prompt: anything needing approval is denied.
        if (decision == PermissionDecision.Ask && context.Source == "tcp")
        {
            decision = PermissionDecision.Deny;
        }
        return (decision, assessment);
    }

    public async Task<PermissionDecision> DescribeAsync(IAgentTool tool, CancellationToken cancellationToken = default)
    {
        if (!await IsEnabledAsync(tool.Name, cancellationToken))
        {
            return PermissionDecision.Deny;
        }
        return await DecideAsync(tool.Name, tool.RiskLevel, cancellationToken);
    }

    private async Task<PermissionDecision> DecideAsync(string toolName, ToolRiskLevel risk, CancellationToken cancellationToken)
    {
        var current = options.CurrentValue;
        var decision = Parse(current.RiskLevels.GetValueOrDefault(risk.ToString()), DefaultFor(risk));
        if (current.Tools.TryGetValue(toolName, out var configured))
        {
            decision = Parse(configured, decision);
        }

        var app = await settings.GetAppSettingsAsync(cancellationToken);
        if (app.ToolPolicies.FirstOrDefault(p => string.Equals(p.Key, toolName, StringComparison.OrdinalIgnoreCase)) is { Value: not null } runtime)
        {
            decision = Parse(runtime.Value, decision);
        }

        // Destructive actions can never be silently auto-approved by configuration.
        if (risk == ToolRiskLevel.Destructive && decision == PermissionDecision.Allow)
        {
            decision = PermissionDecision.Ask;
        }
        return decision;
    }

    /// <summary>
    /// Whether an "Ask" runs without a prompt: the call's approval category (see <see cref="ApprovalCategories"/>) under
    /// the current mode and the administrator's rules. Never for destructive risk or commit/push style tools, nor for a
    /// tool the administrator explicitly set to Ask on the Tools page. A capability or policy Deny stays Deny (only Ask
    /// is relaxed).
    /// </summary>
    private async Task<bool> IsRoutineAllowedAsync(IAgentTool tool, ToolRiskAssessment assessment, CancellationToken cancellationToken)
    {
        var app = await settings.GetAppSettingsAsync(cancellationToken);
        if (app.ToolPolicies.Any(p => string.Equals(p.Key, tool.Name, StringComparison.OrdinalIgnoreCase)))
        {
            return false;
        }
        return ApprovalCategories.RunsWithoutPrompt(app, Categorize(tool, assessment));
    }

    /// <summary>Which approval category a call belongs to, from the server's own assessment of it.</summary>
    public static string Categorize(IAgentTool tool, ToolRiskAssessment assessment)
    {
        if (tool is IUserIntentTool)
        {
            return ApprovalCategories.GitCommitPush;
        }
        if (assessment.Risk == ToolRiskLevel.Destructive)
        {
            return ApprovalCategories.Destructive;
        }
        if (ApprovalCategories.Find(assessment.Category) is { } known)
        {
            return known.Key;
        }
        if (assessment.SystemOrNetwork)
        {
            return ApprovalCategories.SystemChanges;
        }
        if (assessment.Capability == Capabilities.BrowserExternal)
        {
            return ApprovalCategories.BrowseExternal;
        }
        var local = assessment.Capability is not null || assessment.Risk != ToolRiskLevel.External;
        if (assessment.Routine)
        {
            return local ? ApprovalCategories.ChatFolder : ApprovalCategories.WebReads;
        }
        return local ? ApprovalCategories.OtherFolders : ApprovalCategories.Outbound;
    }

    /// <summary>The capability policy for the user's role. Unknown users and unknown capabilities are denied.</summary>
    public async Task<PermissionDecision> CapabilityDecisionAsync(string capability, string userId, CancellationToken cancellationToken)
    {
        if (!options.CurrentValue.Capabilities.TryGetValue(capability, out var policy))
        {
            return PermissionDecision.Deny;
        }
        var isAdmin = users is not null && await users.GetAsync(userId, cancellationToken) is { IsAdmin: true };
        return Parse(isAdmin ? policy.Administrators : policy.Users, PermissionDecision.Deny);
    }

    public static PermissionDecision Stricter(PermissionDecision a, PermissionDecision b)
        => a == PermissionDecision.Deny || b == PermissionDecision.Deny ? PermissionDecision.Deny
            : a == PermissionDecision.Ask || b == PermissionDecision.Ask ? PermissionDecision.Ask
            : PermissionDecision.Allow;

    public static PermissionDecision DefaultFor(ToolRiskLevel risk) => risk switch
    {
        ToolRiskLevel.ReadOnly or ToolRiskLevel.Write => PermissionDecision.Allow,
        ToolRiskLevel.Destructive => PermissionDecision.Deny,
        _ => PermissionDecision.Ask,
    };

    private static PermissionDecision Parse(string? value, PermissionDecision fallback)
        => Enum.TryParse<PermissionDecision>(value, ignoreCase: true, out var parsed) ? parsed : fallback;
}
