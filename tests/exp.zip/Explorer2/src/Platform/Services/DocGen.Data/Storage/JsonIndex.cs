namespace DocGen.Data.Storage;

/// <summary>
/// A small secondary index (e.g. data/indexes/conversations.json) holding lightweight summaries so that
/// listing a user's items does not require reading every entity. The index is a cache: if it is missing
/// or corrupt it is rebuilt from the entity files.
/// </summary>
public sealed class JsonIndex<TEntry> where TEntry : class
{
    private readonly IJsonStore _store;
    private readonly string _path;
    private readonly Func<TEntry, string> _key;
    private readonly Func<CancellationToken, Task<IEnumerable<TEntry>>> _rebuild;
    private Dictionary<string, TEntry>? _entries;
    private long _loadedGeneration;

    public JsonIndex(IJsonStore store, string path, Func<TEntry, string> key, Func<CancellationToken, Task<IEnumerable<TEntry>>> rebuild)
    {
        _store = store;
        _path = path;
        _key = key;
        _rebuild = rebuild;
    }

    public async Task<IReadOnlyList<TEntry>> QueryAsync(Func<TEntry, bool> predicate, CancellationToken ct = default)
    {
        await using (await _store.AcquireLockAsync(_path, ct).ConfigureAwait(false))
        {
            var entries = await LoadAsync(ct).ConfigureAwait(false);
            return entries.Values.Where(predicate).ToList();
        }
    }

    public async Task UpsertAsync(TEntry entry, CancellationToken ct = default)
    {
        await using (await _store.AcquireLockAsync(_path, ct).ConfigureAwait(false))
        {
            var entries = await LoadAsync(ct).ConfigureAwait(false);
            entries[_key(entry)] = entry;
            await PersistAsync(entries, ct).ConfigureAwait(false);
        }
    }

    public async Task RemoveAsync(string key, CancellationToken ct = default)
    {
        await using (await _store.AcquireLockAsync(_path, ct).ConfigureAwait(false))
        {
            var entries = await LoadAsync(ct).ConfigureAwait(false);
            if (entries.Remove(key))
            {
                await PersistAsync(entries, ct).ConfigureAwait(false);
            }
        }
    }

    private async Task<Dictionary<string, TEntry>> LoadAsync(CancellationToken ct)
    {
        // A reset of the store (factory reset) invalidates the cached entries.
        if (_entries is not null && _loadedGeneration == _store.Generation)
        {
            return _entries;
        }
        _loadedGeneration = _store.Generation;

        IndexDocument? doc = null;
        try
        {
            doc = await _store.ReadAsync<IndexDocument>(_path, ct).ConfigureAwait(false);
        }
        catch (Core.Exceptions.StorageException)
        {
            // Rebuild below.
        }

        if (doc is null)
        {
            var rebuilt = await _rebuild(ct).ConfigureAwait(false);
            _entries = rebuilt.ToDictionary(_key, StringComparer.Ordinal);
            await PersistAsync(_entries, ct).ConfigureAwait(false);
        }
        else
        {
            _entries = doc.Entries.ToDictionary(_key, StringComparer.Ordinal);
        }
        return _entries;
    }

    private Task PersistAsync(Dictionary<string, TEntry> entries, CancellationToken ct)
        => _store.WriteAsync(_path, new IndexDocument { UpdatedAt = DateTime.UtcNow, Entries = entries.Values.ToList() }, ct);

    private sealed class IndexDocument
    {
        public int SchemaVersion { get; set; } = 1;
        public DateTime UpdatedAt { get; set; }
        public List<TEntry> Entries { get; set; } = [];
    }
}
