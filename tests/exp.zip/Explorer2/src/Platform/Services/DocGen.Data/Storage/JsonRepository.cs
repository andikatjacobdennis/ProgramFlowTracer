using DocGen.Core.Exceptions;
using DocGen.Core.Models;

namespace DocGen.Data.Storage;

/// <summary>
/// Generic one-file-per-entity repository: {directory}/{id}.json.
/// Writes lock only the affected entity and use optimistic versioning.
/// </summary>
public class JsonRepository<T> where T : Entity
{
    private readonly IJsonStore _store;

    public JsonRepository(IJsonStore store, string directory)
    {
        _store = store;
        Directory = directory.TrimEnd('/');
    }

    public string Directory { get; }

    protected IJsonStore Store => _store;

    public string PathFor(string id) => $"{Directory}/{Ids.Require(id)}.json";

    public Task<T?> GetAsync(string id, CancellationToken ct = default)
        => Ids.IsValid(id) ? _store.ReadAsync<T>(PathFor(id), ct) : Task.FromResult<T?>(null);

    public async Task<T> CreateAsync(T entity, CancellationToken ct = default)
    {
        var path = PathFor(entity.Id);
        await using (await _store.AcquireLockAsync(path, ct).ConfigureAwait(false))
        {
            if (_store.Exists(path))
            {
                throw new StorageConcurrencyException("A resource with this id already exists.");
            }
            var now = DateTime.UtcNow;
            entity.CreatedAt = entity.CreatedAt == default ? now : entity.CreatedAt;
            entity.UpdatedAt = now;
            entity.Version = 1;
            await _store.WriteAsync(path, entity, ct).ConfigureAwait(false);
            return entity;
        }
    }

    /// <summary>Read-modify-write under the entity lock.</summary>
    public async Task<T> UpdateAsync(string id, Action<T> mutate, long? expectedVersion = null, CancellationToken ct = default)
    {
        var path = PathFor(id);
        await using (await _store.AcquireLockAsync(path, ct).ConfigureAwait(false))
        {
            var entity = await _store.ReadAsync<T>(path, ct).ConfigureAwait(false) ?? throw new NotFoundException(typeof(T).Name);
            if (expectedVersion is not null && entity.Version != expectedVersion)
            {
                throw new StorageConcurrencyException();
            }
            mutate(entity);
            entity.Id = id; // Identity is immutable.
            entity.Version++;
            entity.UpdatedAt = DateTime.UtcNow;
            await _store.WriteAsync(path, entity, ct).ConfigureAwait(false);
            return entity;
        }
    }

    /// <summary>Upsert with optimistic concurrency: the stored version must match the entity's version.</summary>
    public async Task<T> SaveAsync(T entity, CancellationToken ct = default)
    {
        var path = PathFor(entity.Id);
        await using (await _store.AcquireLockAsync(path, ct).ConfigureAwait(false))
        {
            var existing = await _store.ReadAsync<T>(path, ct).ConfigureAwait(false);
            if (existing is not null && existing.Version != entity.Version)
            {
                throw new StorageConcurrencyException();
            }
            entity.Version++;
            entity.UpdatedAt = DateTime.UtcNow;
            await _store.WriteAsync(path, entity, ct).ConfigureAwait(false);
            return entity;
        }
    }

    public async Task<bool> DeleteAsync(string id, CancellationToken ct = default)
    {
        var path = PathFor(id);
        await using (await _store.AcquireLockAsync(path, ct).ConfigureAwait(false))
        {
            return await _store.DeleteAsync(path, ct).ConfigureAwait(false);
        }
    }

    public async IAsyncEnumerable<T> EnumerateAsync([System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct = default)
    {
        foreach (var path in _store.EnumerateDocuments(Directory))
        {
            ct.ThrowIfCancellationRequested();
            T? item;
            try
            {
                item = await _store.ReadAsync<T>(path, ct).ConfigureAwait(false);
            }
            catch (StorageException)
            {
                continue; // A corrupt, unrecoverable document must not break listing.
            }
            if (item is not null)
            {
                yield return item;
            }
        }
    }

    public async Task<List<T>> ListAsync(Func<T, bool>? predicate = null, CancellationToken ct = default)
    {
        var list = new List<T>();
        await foreach (var item in EnumerateAsync(ct).ConfigureAwait(false))
        {
            if (predicate is null || predicate(item))
            {
                list.Add(item);
            }
        }
        return list;
    }

    /// <summary>Normalised, case-insensitive substring search over selected text.</summary>
    public Task<List<T>> SearchAsync(string query, Func<T, string?> text, Func<T, bool>? filter = null, CancellationToken ct = default)
    {
        var needle = TextSearch.Normalize(query);
        return ListAsync(e => (filter is null || filter(e)) && TextSearch.Normalize(text(e)).Contains(needle, StringComparison.Ordinal), ct);
    }
}
