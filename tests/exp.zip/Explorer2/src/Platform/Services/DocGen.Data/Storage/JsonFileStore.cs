using System.Diagnostics;
using System.Text;
using System.Text.Json;
using DocGen.Core.Exceptions;
using DocGen.Core.Json;
using Microsoft.Extensions.Logging;

namespace DocGen.Data.Storage;

public sealed class JsonFileStore : IJsonStore
{
    public const string TempSuffix = ".tmp";
    public const string BackupSuffix = ".bak";

    /// <summary>Short-lived cross-process write lock next to a document (deleted when released).</summary>
    public const string LockSuffix = ".lock";

    /// <summary>How long a writer waits for another process writing the same document.</summary>
    private static readonly TimeSpan CrossProcessLockTimeout = TimeSpan.FromSeconds(10);

    /// <summary>Hard ceiling on a single JSON document, preventing unbounded reads.</summary>
    public const long MaxDocumentBytes = 16 * 1024 * 1024;

    private static readonly UTF8Encoding Utf8 = new(encoderShouldEmitUTF8Identifier: false, throwOnInvalidBytes: true);

    private readonly KeyedLock _locks = new();
    private readonly KeyedLock _writeLocks = new();
    private readonly ILogger<JsonFileStore> _logger;
    private readonly string _root;
    private long _generation;

    public long Generation => Interlocked.Read(ref _generation);

    public JsonFileStore(string rootDirectory, ILogger<JsonFileStore> logger)
    {
        _root = Path.GetFullPath(rootDirectory);
        _logger = logger;
        Directory.CreateDirectory(_root);
    }

    public string RootDirectory => _root;

    public async Task<T?> ReadAsync<T>(string relativePath, CancellationToken cancellationToken = default) where T : class
    {
        var path = Resolve(relativePath);

        if (!File.Exists(path))
        {
            // A crash between "write temp" and "replace" can leave only the temp or backup file behind.
            return await TryRecoverMissingAsync<T>(path, cancellationToken).ConfigureAwait(false);
        }

        try
        {
            return await DeserializeFileAsync<T>(path, cancellationToken).ConfigureAwait(false);
        }
        catch (JsonException ex)
        {
            _logger.LogWarning(ex, "Corrupt JSON document {Path}; attempting recovery from backup", relativePath);
            var backup = path + BackupSuffix;
            if (File.Exists(backup))
            {
                T? recovered = null;
                try
                {
                    recovered = await DeserializeFileAsync<T>(backup, cancellationToken).ConfigureAwait(false);
                }
                catch (JsonException backupError)
                {
                    // The backup is corrupt too: report as unrecoverable below (never a raw JsonException).
                    _logger.LogWarning(backupError, "Backup of {Path} is also corrupt", relativePath);
                }
                if (recovered is not null)
                {
                    File.Copy(path, path + ".corrupt", overwrite: true);
                    File.Copy(backup, path, overwrite: true);
                    _logger.LogWarning("Recovered {Path} from backup", relativePath);
                    return recovered;
                }
            }
            throw new StorageException("A stored document is corrupt and could not be recovered.", ex);
        }
    }

    public async Task WriteAsync<T>(string relativePath, T value, CancellationToken cancellationToken = default) where T : class
    {
        var path = Resolve(relativePath);
        var bytes = JsonSerializer.SerializeToUtf8Bytes(value, DocGenJson.Storage);
        await WriteAtomicAsync(path, bytes, cancellationToken).ConfigureAwait(false);
    }

    public async Task<string?> ReadTextAsync(string relativePath, long maxBytes, CancellationToken cancellationToken = default)
    {
        var path = Resolve(relativePath);
        if (!File.Exists(path))
        {
            return null;
        }

        await using var stream = OpenRead(path);
        if (stream.Length > maxBytes)
        {
            throw new StorageException("The stored content exceeds the maximum readable size.");
        }
        using var reader = new StreamReader(stream, Encoding.UTF8);
        return await reader.ReadToEndAsync(cancellationToken).ConfigureAwait(false);
    }

    public Task WriteTextAsync(string relativePath, string content, CancellationToken cancellationToken = default)
        => WriteAtomicAsync(Resolve(relativePath), Utf8.GetBytes(content), cancellationToken);

    public bool Exists(string relativePath) => File.Exists(Resolve(relativePath));

    public Task<bool> DeleteAsync(string relativePath, CancellationToken cancellationToken = default)
    {
        var path = Resolve(relativePath);
        var existed = File.Exists(path);
        foreach (var candidate in new[] { path, path + TempSuffix, path + BackupSuffix })
        {
            if (File.Exists(candidate))
            {
                File.Delete(candidate);
            }
        }
        _logger.LogDebug("Deleted document {Path}", relativePath);
        return Task.FromResult(existed);
    }

    public Task DeleteDirectoryAsync(string relativeDirectory, CancellationToken cancellationToken = default)
    {
        var path = Resolve(relativeDirectory);
        if (Directory.Exists(path))
        {
            Directory.Delete(path, recursive: true);
            _logger.LogDebug("Deleted directory {Path}", relativeDirectory);
        }
        return Task.CompletedTask;
    }

    public IReadOnlyList<string> EnumerateDocuments(string relativeDirectory)
    {
        var dir = Resolve(relativeDirectory);
        if (!Directory.Exists(dir))
        {
            return [];
        }

        var prefix = relativeDirectory.TrimEnd('/');
        var results = new List<string>();
        foreach (var file in Directory.EnumerateFiles(dir, "*.json", SearchOption.TopDirectoryOnly))
        {
            results.Add(prefix + "/" + Path.GetFileName(file));
        }

        // Documents whose only surviving copy is a temp/backup file (interrupted write) are still visible.
        foreach (var orphan in Directory.EnumerateFiles(dir, "*.json" + TempSuffix).Concat(Directory.EnumerateFiles(dir, "*.json" + BackupSuffix)))
        {
            var name = Path.GetFileName(orphan);
            var doc = name[..name.LastIndexOf('.')];
            var rel = prefix + "/" + doc;
            if (!File.Exists(Path.Combine(dir, doc)) && !results.Contains(rel))
            {
                results.Add(rel);
            }
        }
        return results;
    }

    public IReadOnlyList<string> EnumerateDirectories(string relativeDirectory)
    {
        var dir = Resolve(relativeDirectory);
        return Directory.Exists(dir)
            ? Directory.EnumerateDirectories(dir).Select(Path.GetFileName).OfType<string>().ToList()
            : [];
    }

    public Task<IAsyncDisposable> AcquireLockAsync(string key, CancellationToken cancellationToken = default)
        => _locks.AcquireAsync(key, cancellationToken);

    public int RecoverAll()
    {
        var repaired = 0;
        foreach (var temp in Directory.EnumerateFiles(_root, "*" + TempSuffix, SearchOption.AllDirectories))
        {
            var target = temp[..^TempSuffix.Length];
            try
            {
                if (!File.Exists(target) && IsValidJsonOrText(temp))
                {
                    File.Move(temp, target);
                    _logger.LogWarning("Recovered interrupted write for {Path}", Path.GetRelativePath(_root, target));
                }
                else
                {
                    File.Delete(temp);
                }
                repaired++;
            }
            catch (IOException ex)
            {
                _logger.LogWarning(ex, "Could not repair temp file {Path}", temp);
            }
        }

        foreach (var backup in Directory.EnumerateFiles(_root, "*" + BackupSuffix, SearchOption.AllDirectories))
        {
            var target = backup[..^BackupSuffix.Length];
            if (!File.Exists(target))
            {
                File.Copy(backup, target);
                _logger.LogWarning("Restored missing document {Path} from backup", Path.GetRelativePath(_root, target));
                repaired++;
            }
        }
        return repaired;
    }

    public async Task<string> CreateBackupAsync(string backupRoot, CancellationToken cancellationToken = default)
    {
        var target = Path.Combine(Path.GetFullPath(backupRoot), "backup-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss"));
        var sw = Stopwatch.StartNew();
        var count = 0;
        foreach (var file in Directory.EnumerateFiles(_root, "*", SearchOption.AllDirectories))
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (file.EndsWith(TempSuffix, StringComparison.Ordinal) || file.EndsWith(LockSuffix, StringComparison.Ordinal))
            {
                continue;
            }
            var destination = Path.Combine(target, Path.GetRelativePath(_root, file));
            Directory.CreateDirectory(Path.GetDirectoryName(destination)!);
            await using var source = OpenRead(file);
            await using var dest = new FileStream(destination, FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, useAsync: true);
            await source.CopyToAsync(dest, cancellationToken).ConfigureAwait(false);
            count++;
        }
        _logger.LogInformation("Created data backup {BackupPath} with {FileCount} files in {DurationMs} ms", target, count, sw.ElapsedMilliseconds);
        return target;
    }

    public Task<IReadOnlyList<string>> ResetAsync(IReadOnlyCollection<string> keep, CancellationToken cancellationToken = default)
    {
        var kept = keep.Select(Resolve).ToList();
        var failures = new List<string>();
        bool IsKept(string full) => kept.Any(k => string.Equals(full, k, StringComparison.OrdinalIgnoreCase)
            || string.Equals(full, k + BackupSuffix, StringComparison.OrdinalIgnoreCase)
            || full.StartsWith(k + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase));
        bool HoldsKept(string dir) => kept.Any(k => k.StartsWith(dir + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase));

        void Clear(DirectoryInfo dir)
        {
            foreach (var file in dir.EnumerateFiles())
            {
                cancellationToken.ThrowIfCancellationRequested();
                if (IsKept(file.FullName))
                {
                    continue;
                }
                try
                {
                    file.Attributes = FileAttributes.Normal;
                    file.Delete();
                }
                catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
                {
                    failures.Add(Path.GetRelativePath(_root, file.FullName));
                }
            }
            foreach (var sub in dir.EnumerateDirectories())
            {
                if (IsKept(sub.FullName))
                {
                    continue;
                }
                if (sub.Attributes.HasFlag(FileAttributes.ReparsePoint))
                {
                    try { sub.Delete(); } catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { failures.Add(Path.GetRelativePath(_root, sub.FullName)); }
                    continue;
                }
                Clear(sub);
                if (!HoldsKept(sub.FullName))
                {
                    try
                    {
                        sub.Delete(recursive: false);
                    }
                    catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
                    {
                        // Something inside could not be deleted (already reported) or the folder is in use.
                    }
                }
            }
        }

        if (Directory.Exists(_root))
        {
            Clear(new DirectoryInfo(_root));
        }
        Interlocked.Increment(ref _generation);
        _logger.LogWarning("Data directory reset: kept {Kept}; {Failures} item(s) could not be deleted", string.Join(", ", keep), failures.Count);
        return Task.FromResult<IReadOnlyList<string>>(failures);
    }

    /// <summary>Resolves a relative path and guarantees it stays inside the data directory.</summary>
    private string Resolve(string relativePath)
    {
        if (string.IsNullOrWhiteSpace(relativePath) || Path.IsPathRooted(relativePath))
        {
            throw new StorageException("Invalid storage path.");
        }

        var full = Path.GetFullPath(Path.Combine(_root, relativePath));
        var rootWithSep = _root.EndsWith(Path.DirectorySeparatorChar) ? _root : _root + Path.DirectorySeparatorChar;
        if (!full.StartsWith(rootWithSep, StringComparison.OrdinalIgnoreCase) && !string.Equals(full, _root, StringComparison.OrdinalIgnoreCase))
        {
            throw new StorageException("Invalid storage path.");
        }
        return full;
    }

    private async Task WriteAtomicAsync(string path, byte[] bytes, CancellationToken cancellationToken)
    {
        var sw = Stopwatch.StartNew();
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var temp = path + TempSuffix;

        // Physical writes to one document are always serialised (separate from the logical resource locks
        // callers may hold), so two writers can never share the temp file.
        await using var writeLock = await _writeLocks.AcquireAsync(path, CancellationToken.None).ConfigureAwait(false);

        FileStream? processLock = null;
        try
        {
            // The in-memory lock covers this store instance only. Another DocGen process (or store instance) on the
            // same data directory would otherwise race on the temp file and fail with a sharing violation.
            processLock = await AcquireProcessLockAsync(path + LockSuffix, cancellationToken).ConfigureAwait(false);
            await using (var stream = new FileStream(temp, FileMode.Create, FileAccess.Write, FileShare.None, 4096, FileOptions.Asynchronous))
            {
                await stream.WriteAsync(bytes, cancellationToken).ConfigureAwait(false);
                await stream.FlushAsync(cancellationToken).ConfigureAwait(false);
                stream.Flush(flushToDisk: true);
            }

            await RetryIoAsync(() =>
            {
                if (File.Exists(path))
                {
                    File.Replace(temp, path, path + BackupSuffix, ignoreMetadataErrors: true);
                }
                else
                {
                    File.Move(temp, path);
                }
            }).ConfigureAwait(false);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or OperationCanceledException)
        {
            if (processLock is not null)
            {
                TryDelete(temp); // Only the lock holder may remove the temp file.
            }
            if (ex is OperationCanceledException)
            {
                throw;
            }
            _logger.LogError(ex, "Atomic write failed for {Path}", Path.GetRelativePath(_root, path));
            throw new StorageException("Failed to save data.", ex);
        }
        finally
        {
            if (processLock is not null)
            {
                await processLock.DisposeAsync().ConfigureAwait(false);
            }
        }

        _logger.LogDebug("Wrote {Path} ({Bytes} bytes) in {DurationMs} ms", Path.GetRelativePath(_root, path), bytes.Length, sw.ElapsedMilliseconds);
    }

    private async Task<T?> TryRecoverMissingAsync<T>(string path, CancellationToken cancellationToken) where T : class
    {
        foreach (var candidate in new[] { path + TempSuffix, path + BackupSuffix })
        {
            if (!File.Exists(candidate))
            {
                continue;
            }
            try
            {
                var value = await DeserializeFileAsync<T>(candidate, cancellationToken).ConfigureAwait(false);
                if (value is not null)
                {
                    File.Copy(candidate, path, overwrite: false);
                    _logger.LogWarning("Recovered missing document {Path} from {Source}", Path.GetRelativePath(_root, path), Path.GetExtension(candidate));
                    return value;
                }
            }
            catch (JsonException)
            {
                // Try the next candidate.
            }
            catch (IOException)
            {
                // Another reader recovered it first.
            }
        }
        return null;
    }

    private static async Task<T?> DeserializeFileAsync<T>(string path, CancellationToken cancellationToken) where T : class
    {
        for (var attempt = 0; ; attempt++)
        {
            try
            {
                await using var stream = OpenRead(path);
                if (stream.Length > MaxDocumentBytes)
                {
                    throw new StorageException("A stored document exceeds the maximum size.");
                }
                if (stream.Length == 0)
                {
                    throw new JsonException("Empty document.");
                }
                return await JsonSerializer.DeserializeAsync<T>(stream, DocGenJson.Storage, cancellationToken).ConfigureAwait(false);
            }
            catch (IOException) when (attempt < 5)
            {
                // The file may be mid-replace on Windows (sharing violation). Retry briefly.
                await Task.Delay(10 * (attempt + 1), cancellationToken).ConfigureAwait(false);
            }
            catch (FileNotFoundException) when (attempt < 5)
            {
                await Task.Delay(10 * (attempt + 1), cancellationToken).ConfigureAwait(false);
            }
        }
    }

    private static FileStream OpenRead(string path) =>
        new(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete, 4096, FileOptions.Asynchronous | FileOptions.SequentialScan);

    /// <summary>
    /// Opens the document's lock file exclusively (delete-on-close), waiting while another process holds it. The
    /// operating system releases it if the holder dies, so a crash never leaves the document locked.
    /// </summary>
    private static async Task<FileStream> AcquireProcessLockAsync(string lockPath, CancellationToken cancellationToken)
    {
        var deadline = DateTime.UtcNow + CrossProcessLockTimeout;
        for (var attempt = 0; ; attempt++)
        {
            try
            {
                return new FileStream(lockPath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None, 1, FileOptions.DeleteOnClose);
            }
            catch (Exception ex) when ((ex is IOException or UnauthorizedAccessException) && DateTime.UtcNow < deadline)
            {
                await Task.Delay(Math.Min(100, 5 * (attempt + 1)), cancellationToken).ConfigureAwait(false);
            }
        }
    }

    private static async Task RetryIoAsync(Action action)
    {
        for (var attempt = 0; ; attempt++)
        {
            try
            {
                action();
                return;
            }
            catch (IOException) when (attempt < 8)
            {
                // Readers hold the file briefly; File.Replace fails with a sharing violation on Windows.
                await Task.Delay(5 * (attempt + 1)).ConfigureAwait(false);
            }
            catch (UnauthorizedAccessException) when (attempt < 8)
            {
                await Task.Delay(5 * (attempt + 1)).ConfigureAwait(false);
            }
        }
    }

    private static bool IsValidJsonOrText(string path)
    {
        try
        {
            if (!path.EndsWith(".json" + TempSuffix, StringComparison.OrdinalIgnoreCase))
            {
                return new FileInfo(path).Length > 0;
            }
            using var stream = OpenRead(path);
            using var doc = JsonDocument.Parse(stream);
            return true;
        }
        catch (Exception ex) when (ex is JsonException or IOException)
        {
            return false;
        }
    }

    private static void TryDelete(string path)
    {
        try
        {
            if (File.Exists(path))
            {
                File.Delete(path);
            }
        }
        catch (IOException)
        {
            // Best effort; RecoverAll cleans up on next start.
        }
    }
}
