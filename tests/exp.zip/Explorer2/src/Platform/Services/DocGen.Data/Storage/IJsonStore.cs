namespace DocGen.Data.Storage;

/// <summary>
/// File-system backed document store. Paths are relative to the data directory and use '/' separators.
/// All writes are atomic (write temp → flush → replace) and keep a .bak of the previous version.
/// </summary>
public interface IJsonStore
{
    string RootDirectory { get; }

    Task<T?> ReadAsync<T>(string relativePath, CancellationToken cancellationToken = default) where T : class;

    Task WriteAsync<T>(string relativePath, T value, CancellationToken cancellationToken = default) where T : class;

    Task<string?> ReadTextAsync(string relativePath, long maxBytes, CancellationToken cancellationToken = default);

    Task WriteTextAsync(string relativePath, string content, CancellationToken cancellationToken = default);

    bool Exists(string relativePath);

    Task<bool> DeleteAsync(string relativePath, CancellationToken cancellationToken = default);

    Task DeleteDirectoryAsync(string relativeDirectory, CancellationToken cancellationToken = default);

    /// <summary>Relative paths of *.json documents directly inside a directory (temp/backup files excluded).</summary>
    IReadOnlyList<string> EnumerateDocuments(string relativeDirectory);

    /// <summary>Names of immediate sub-directories.</summary>
    IReadOnlyList<string> EnumerateDirectories(string relativeDirectory);

    /// <summary>Acquires the per-resource lock for a key (normally the document path).</summary>
    Task<IAsyncDisposable> AcquireLockAsync(string key, CancellationToken cancellationToken = default);

    /// <summary>Repairs documents left behind by an interrupted write. Returns the number of repairs.</summary>
    int RecoverAll();

    /// <summary>Copies the whole data directory into a timestamped backup folder. Returns its path.</summary>
    Task<string> CreateBackupAsync(string backupRoot, CancellationToken cancellationToken = default);

    /// <summary>Changes whenever <see cref="ResetAsync"/> runs: in-memory caches built from the store must reload.</summary>
    long Generation => 0;

    /// <summary>
    /// Deletes everything in the data directory except <paramref name="keep"/> (relative files or directories, with
    /// their .bak copies). Returns the relative paths that could not be deleted (e.g. files held open).
    /// </summary>
    Task<IReadOnlyList<string>> ResetAsync(IReadOnlyCollection<string> keep, CancellationToken cancellationToken = default)
        => throw new NotSupportedException("This store cannot be reset.");
}
