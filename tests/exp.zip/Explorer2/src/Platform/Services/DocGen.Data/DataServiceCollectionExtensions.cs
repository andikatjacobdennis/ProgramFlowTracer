using DocGen.Core.Abstractions;
using DocGen.Core.Options;
using DocGen.Data.Repositories;
using DocGen.Data.Services;
using DocGen.Data.Storage;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace DocGen.Data;

public static class DataServiceCollectionExtensions
{
    public static IServiceCollection AddDocGenData(this IServiceCollection services)
    {
        services.AddSingleton<IJsonStore>(sp => new JsonFileStore(
            sp.GetRequiredService<IOptions<DocGenOptions>>().Value.DataDirectory,
            sp.GetRequiredService<ILogger<JsonFileStore>>()));

        services.AddSingleton<IUserRepository, UserRepository>();
        services.AddSingleton<ISessionRepository, SessionRepository>();
        services.AddSingleton<IConversationRepository, ConversationRepository>();
        services.AddSingleton<IMessageRepository, MessageRepository>();
        services.AddSingleton<IProjectRepository, ProjectRepository>();
        services.AddSingleton<IPersonaRepository, PersonaRepository>();
        services.AddSingleton<DocGen.Core.Skills.ISkillRegistry>(sp => new SkillRegistry(sp.GetRequiredService<IOptions<DocGenOptions>>(), sp.GetRequiredService<ISettingsService>(),
            sp.GetRequiredService<IJsonStore>(), sp.GetRequiredService<ILogger<SkillRegistry>>(), sp));
        services.AddSingleton<IRunRepository, RunRepository>();
        services.AddSingleton<IApprovalRepository, ApprovalRepository>();
        services.AddSingleton<IAgentCheckpointStore, AgentCheckpointStore>();
        services.AddSingleton<ICompactionStore, CompactionStore>();
        services.AddSingleton<IArtifactService, ArtifactService>();
        services.AddSingleton<IFileService, FileService>();
        services.AddSingleton<ISettingsService, SettingsService>();
        services.AddSingleton<ISearchService, LocalSearchService>();
        services.AddSingleton<IBlobStore>(sp => new BlobStore(sp.GetRequiredService<IOptions<DocGenOptions>>().Value.DataDirectory));
        return services;
    }
}
