using DocGen.Core.Models;

namespace DocGen.Data.Services;

/// <summary>
/// First-run provider/model configuration. DocGen works out of the box with the built-in simulated
/// provider; real HTTP providers are included as disabled examples to be enabled in Settings.
/// </summary>
public static class DefaultConfiguration
{
    public const string DefaultModelId = "general";

    public static List<ProviderConfiguration> Providers() =>
    [
        new()
        {
            Id = "fake",
            DisplayName = "Offline simulator",
            Type = "fake",
            Streaming = true,
            Enabled = true,
        },
        new()
        {
            Id = "local",
            DisplayName = "Local chat-completions server",
            Type = "http",
            WireFormat = "chat-completions",
            BaseUrl = "http://localhost:11434",
            Endpoint = "/v1/chat/completions",
            ApiKeyEnvironmentVariable = null,
            TimeoutSeconds = 300,
            Enabled = false,
        },
        new()
        {
            Id = "hosted-chat",
            DisplayName = "Hosted chat-completions API",
            Type = "http",
            WireFormat = "chat-completions",
            BaseUrl = "https://api.example.com",
            Endpoint = "/v1/chat/completions",
            ApiKeyEnvironmentVariable = "DOCGEN_CHAT_API_KEY",
            TimeoutSeconds = 120,
            Enabled = false,
        },
        new()
        {
            Id = "hosted-messages",
            DisplayName = "Hosted messages API",
            Type = "http",
            WireFormat = "messages",
            BaseUrl = "https://api.example.com",
            Endpoint = "/v1/messages",
            ApiKeyEnvironmentVariable = "DOCGEN_MESSAGES_API_KEY",
            ApiKeyHeader = "x-api-key",
            ApiKeyPrefix = "",
            Headers = new() { ["api-version"] = "2023-06-01" },
            TimeoutSeconds = 120,
            Enabled = false,
        },
    ];

    public static List<ModelConfiguration> Models() =>
    [
        new()
        {
            Id = "general", ProviderId = "fake", ProviderModelId = "sim-general", DisplayName = "General",
            Description = "Balanced everyday assistant (simulated)", Icon = "sparkle", ContextWindow = 32_000, MaxOutputTokens = 4_096, SortOrder = 0,
        },
        new()
        {
            Id = "fast", ProviderId = "fake", ProviderModelId = "sim-fast", DisplayName = "Fast",
            Description = "Quick, short answers (simulated)", Icon = "bolt", ContextWindow = 16_000, MaxOutputTokens = 2_048, SortOrder = 1,
        },
        new()
        {
            Id = "reasoning", ProviderId = "fake", ProviderModelId = "sim-reasoning", DisplayName = "Reasoning",
            Description = "Step-by-step problem solving (simulated)", Icon = "brain", ContextWindow = 64_000, MaxOutputTokens = 8_192, SortOrder = 2,
        },
        new()
        {
            Id = "coding", ProviderId = "fake", ProviderModelId = "sim-coding", DisplayName = "Coding",
            Description = "Code-focused assistant (simulated)", Icon = "code", ContextWindow = 64_000, MaxOutputTokens = 8_192, SortOrder = 3,
        },
        new()
        {
            Id = "local-llama", ProviderId = "local", ProviderModelId = "llama3.1", DisplayName = "Local Llama",
            Description = "Model served by a local chat-completions server", Icon = "sparkle", ContextWindow = 32_000, MaxOutputTokens = 4_096, SortOrder = 10,
        },
        new()
        {
            Id = "hosted-chat-model", ProviderId = "hosted-chat", ProviderModelId = "your-model-id", DisplayName = "Hosted (chat-completions)",
            Description = "Configure the provider base URL and API key environment variable", Icon = "sparkle", ContextWindow = 128_000, MaxOutputTokens = 8_192, SortOrder = 11,
        },
        new()
        {
            Id = "hosted-messages-model", ProviderId = "hosted-messages", ProviderModelId = "your-model-id", DisplayName = "Hosted (messages)",
            Description = "Configure the provider base URL and API key environment variable", Icon = "sparkle", ContextWindow = 200_000, MaxOutputTokens = 8_192, SortOrder = 12,
        },
    ];
}
