using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Data.Storage;
using Microsoft.Extensions.Logging;

namespace DocGen.Data.Services;

/// <summary>
/// data/artifacts/{id}/artifact.json holds metadata; data/artifacts/{id}/versions/000001.md etc. hold content
/// in its native text format. Every update appends a version; old versions are never modified.
/// </summary>
public sealed class ArtifactService(IJsonStore store, ILogger<ArtifactService> logger) : IArtifactService
{
    public const int MaxArtifactChars = 2_000_000;

    private static string MetaPath(string id) => $"artifacts/{Ids.Require(id, "artifact id")}/artifact.json";

    private static string VersionPath(string id, string fileName) => $"artifacts/{Ids.Require(id, "artifact id")}/versions/{fileName}";

    public async Task<Artifact> CreateAsync(string userId, string title, ArtifactType type, string content, string createdBy,
        string? conversationId = null, string? projectId = null, CancellationToken ct = default)
    {
        Validate(title, content);
        var artifact = new Artifact
        {
            UserId = userId,
            Title = title.Trim(),
            Type = type,
            ConversationId = conversationId,
            ProjectId = projectId,
        };

        await using (await store.AcquireLockAsync(MetaPath(artifact.Id), ct))
        {
            var version = await WriteVersionAsync(artifact, content, createdBy, "Initial version", ct);
            artifact.Versions.Add(version);
            artifact.CurrentVersion = version.Number;
            artifact.Version = 1;
            await store.WriteAsync(MetaPath(artifact.Id), artifact, ct);
        }
        logger.LogInformation("Created artifact {ArtifactId} ({ArtifactType}) for {UserId}", artifact.Id, type, userId);
        return artifact;
    }

    public async Task<Artifact> GetAsync(string userId, string id, CancellationToken ct = default)
    {
        if (!Ids.IsValid(id))
        {
            throw new NotFoundException("Artifact");
        }
        var artifact = await store.ReadAsync<Artifact>(MetaPath(id), ct);
        if (artifact is null || artifact.UserId != userId)
        {
            throw new NotFoundException("Artifact");
        }
        return artifact;
    }

    public async Task<IReadOnlyList<Artifact>> ListAsync(string userId, string? projectId = null, CancellationToken ct = default)
    {
        var result = new List<Artifact>();
        foreach (var dir in store.EnumerateDirectories("artifacts"))
        {
            if (!Ids.IsValid(dir))
            {
                continue;
            }
            try
            {
                var artifact = await store.ReadAsync<Artifact>(MetaPath(dir), ct);
                if (artifact is not null && artifact.UserId == userId && (projectId is null || artifact.ProjectId == projectId))
                {
                    result.Add(artifact);
                }
            }
            catch (StorageException)
            {
                // Skip unrecoverable documents.
            }
        }
        return result.OrderByDescending(a => a.UpdatedAt).ToList();
    }

    public async Task<string> ReadContentAsync(string userId, string id, int? version = null, CancellationToken ct = default)
    {
        var artifact = await GetAsync(userId, id, ct);
        var number = version ?? artifact.CurrentVersion;
        var entry = artifact.Versions.FirstOrDefault(v => v.Number == number) ?? throw new NotFoundException("Artifact version");
        return await store.ReadTextAsync(VersionPath(id, entry.FileName), MaxArtifactChars * 4L, ct)
            ?? throw new NotFoundException("Artifact content");
    }

    public async Task<Artifact> UpdateAsync(string userId, string id, string content, string createdBy, string? note = null,
        string? title = null, CancellationToken ct = default)
    {
        Validate(title ?? "untitled", content);
        await using (await store.AcquireLockAsync(MetaPath(id), ct))
        {
            var artifact = await GetAsync(userId, id, ct);
            var version = await WriteVersionAsync(artifact, content, createdBy, note, ct);
            artifact.Versions.Add(version);
            artifact.CurrentVersion = version.Number;
            if (!string.IsNullOrWhiteSpace(title))
            {
                artifact.Title = title.Trim();
            }
            artifact.Version++;
            artifact.UpdatedAt = DateTime.UtcNow;
            await store.WriteAsync(MetaPath(id), artifact, ct);
            logger.LogInformation("Artifact {ArtifactId} updated to version {ArtifactVersion}", id, version.Number);
            return artifact;
        }
    }

    public async Task DeleteAsync(string userId, string id, CancellationToken ct = default)
    {
        await GetAsync(userId, id, ct);
        await using (await store.AcquireLockAsync(MetaPath(id), ct))
        {
            await store.DeleteDirectoryAsync($"artifacts/{id}", ct);
        }
        logger.LogInformation("Deleted artifact {ArtifactId}", id);
    }

    private async Task<ArtifactVersion> WriteVersionAsync(Artifact artifact, string content, string createdBy, string? note, CancellationToken ct)
    {
        var number = artifact.Versions.Count == 0 ? 1 : artifact.Versions.Max(v => v.Number) + 1;
        var fileName = number.ToString("D6") + ArtifactTypes.Extension(artifact.Type);
        var path = VersionPath(artifact.Id, fileName);
        if (store.Exists(path))
        {
            throw new StorageConcurrencyException("Artifact version already exists.");
        }
        await store.WriteTextAsync(path, content, ct);
        return new ArtifactVersion
        {
            Number = number,
            FileName = fileName,
            SizeBytes = System.Text.Encoding.UTF8.GetByteCount(content),
            CreatedBy = createdBy is "agent" ? "agent" : "user",
            Note = note?.Length > 500 ? note[..500] : note,
        };
    }

    private static void Validate(string title, string content)
    {
        if (string.IsNullOrWhiteSpace(title) || title.Length > 200)
        {
            throw new ValidationException("Artifact title must be between 1 and 200 characters.");
        }
        if (content.Length > MaxArtifactChars)
        {
            throw new ValidationException("Artifact content is too large.");
        }
    }
}
