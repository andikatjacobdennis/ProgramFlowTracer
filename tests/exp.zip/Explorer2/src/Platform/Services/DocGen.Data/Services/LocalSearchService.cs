using System.Diagnostics;
using DocGen.Core.Abstractions;
using DocGen.Core.Options;
using DocGen.Data.Storage;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace DocGen.Data.Services;

/// <summary>
/// Deliberately simple local search: normalised, case-insensitive substring matching over the caller's
/// conversation titles, message text, project names, artifact metadata and uploaded text files.
/// </summary>
public sealed class LocalSearchService(
    IConversationRepository conversations,
    IMessageRepository messages,
    IProjectRepository projects,
    IArtifactService artifacts,
    IFileService files,
    IOptions<DocGenOptions> options,
    ILogger<LocalSearchService> logger) : ISearchService
{
    private const int MaxConversationsScanned = 500;

    public async Task<IReadOnlyList<SearchResult>> SearchAsync(string userId, string query, int limit = 30, CancellationToken ct = default)
    {
        var needle = TextSearch.Normalize(query);
        if (needle.Length < 2)
        {
            return [];
        }

        var sw = Stopwatch.StartNew();
        var results = new List<SearchResult>();

        var userConversations = await conversations.ListAsync(userId, includeArchived: true, ct: ct);
        foreach (var conversation in userConversations.Take(MaxConversationsScanned))
        {
            ct.ThrowIfCancellationRequested();
            if (Matches(conversation.Title, needle))
            {
                results.Add(new SearchResult
                {
                    Type = "conversation", Id = conversation.Id, ConversationId = conversation.Id, Title = conversation.Title,
                    UpdatedAt = conversation.LastMessageAt ?? conversation.UpdatedAt, Score = 100,
                });
            }

            foreach (var message in await messages.ListAsync(conversation.Id, ct))
            {
                var text = message.Text;
                if (Matches(text, needle))
                {
                    results.Add(new SearchResult
                    {
                        Type = "message", Id = message.Id, ConversationId = conversation.Id, Title = conversation.Title,
                        Snippet = TextSearch.Snippet(text, needle), UpdatedAt = message.CreatedAt, Score = 50,
                    });
                }
            }
        }

        foreach (var project in await projects.ListAsync(userId, ct))
        {
            if (Matches(project.Name + " " + project.Description, needle))
            {
                results.Add(new SearchResult
                {
                    Type = "project", Id = project.Id, Title = project.Name,
                    Snippet = TextSearch.Snippet(project.Description, needle), UpdatedAt = project.UpdatedAt, Score = 90,
                });
            }
        }

        foreach (var artifact in await artifacts.ListAsync(userId, ct: ct))
        {
            if (Matches(artifact.Title + " " + artifact.Type, needle))
            {
                results.Add(new SearchResult
                {
                    Type = "artifact", Id = artifact.Id, ConversationId = artifact.ConversationId, Title = artifact.Title,
                    UpdatedAt = artifact.UpdatedAt, Score = 80,
                });
            }
        }

        var maxRead = Math.Min(options.Value.MaxFileReadBytes, 256 * 1024);
        foreach (var file in await files.ListAsync(userId, ct: ct))
        {
            string? snippet = null;
            var nameMatch = Matches(file.FileName, needle);
            if (!nameMatch)
            {
                var content = await files.ReadTextAsync(userId, file.Id, maxRead, ct);
                if (!Matches(content, needle))
                {
                    continue;
                }
                snippet = TextSearch.Snippet(content, needle);
            }
            results.Add(new SearchResult
            {
                Type = "file", Id = file.Id, Title = file.FileName, Snippet = snippet, UpdatedAt = file.UpdatedAt, Score = nameMatch ? 70 : 40,
            });
        }

        logger.LogDebug("Search for {UserId} returned {ResultCount} results in {DurationMs} ms", userId, results.Count, sw.ElapsedMilliseconds);
        return results.OrderByDescending(r => r.Score).ThenByDescending(r => r.UpdatedAt).Take(limit).ToList();
    }

    private static bool Matches(string? text, string needle) => TextSearch.Normalize(text).Contains(needle, StringComparison.Ordinal);
}
