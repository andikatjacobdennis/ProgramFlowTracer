using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using DocGen.Core.Abstractions;
using DocGen.Core.Json;
using DocGen.Core.Models;

namespace DocGen.Data.Services;

/// <summary>
/// Content-addressed, per-user blob storage: {data}/blobs/{userId}/{hash[..2]}/{hash}.txt plus a metadata document.
/// Identical content is stored once. Writes are atomic (temp → flush → rename).
/// </summary>
public sealed class BlobStore(string dataDirectory) : IBlobStore
{
    public async Task<BlobInfo> PutAsync(string userId, string content, string kind, string? source, CancellationToken cancellationToken = default)
    {
        var bytes = Encoding.UTF8.GetBytes(content);
        var hash = Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
        var (contentPath, metaPath) = PathsFor(userId, hash);
        if (File.Exists(contentPath) && File.Exists(metaPath))
        {
            return await ReadInfoAsync(metaPath, cancellationToken) ?? Describe(hash, kind, source, bytes, content);
        }
        Directory.CreateDirectory(Path.GetDirectoryName(contentPath)!);
        await WriteAtomicAsync(contentPath, bytes, cancellationToken);
        var info = Describe(hash, kind, source, bytes, content);
        await WriteAtomicAsync(metaPath, JsonSerializer.SerializeToUtf8Bytes(info, DocGenJson.Storage), cancellationToken);
        return info;
    }

    public async Task<BlobInfo?> GetInfoAsync(string userId, string reference, CancellationToken cancellationToken = default)
    {
        if (BlobKinds.ParseHash(reference) is not { } hash)
        {
            return null;
        }
        var (contentPath, metaPath) = PathsFor(userId, hash);
        return File.Exists(contentPath) ? await ReadInfoAsync(metaPath, cancellationToken) : null;
    }

    public string? GetContentPath(string userId, string reference)
    {
        if (BlobKinds.ParseHash(reference) is not { } hash)
        {
            return null;
        }
        var (contentPath, _) = PathsFor(userId, hash);
        return File.Exists(contentPath) ? contentPath : null;
    }

    private (string Content, string Meta) PathsFor(string userId, string hash)
    {
        var dir = Path.Combine(Path.GetFullPath(dataDirectory), "blobs", Ids.Require(userId, "user id"), hash[..2]);
        return (Path.Combine(dir, hash + ".txt"), Path.Combine(dir, hash + ".json"));
    }

    private static BlobInfo Describe(string hash, string kind, string? source, byte[] bytes, string content) => new()
    {
        Hash = hash,
        Kind = kind,
        Source = source is { Length: > 200 } ? source[..200] : source,
        SizeBytes = bytes.LongLength,
        LineCount = content.Length == 0 ? 0 : content.Count(c => c == '\n') + 1,
        EstimatedTokens = content.Length / 4 + 1,
    };

    private static async Task<BlobInfo?> ReadInfoAsync(string metaPath, CancellationToken ct)
    {
        try
        {
            await using var stream = File.OpenRead(metaPath);
            return await JsonSerializer.DeserializeAsync<BlobInfo>(stream, DocGenJson.Storage, ct);
        }
        catch (Exception ex) when (ex is JsonException or IOException)
        {
            return null;
        }
    }

    private static async Task WriteAtomicAsync(string path, byte[] bytes, CancellationToken ct)
    {
        var temp = path + "." + Guid.NewGuid().ToString("N")[..8] + ".partial";
        await using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None, 64 * 1024, FileOptions.Asynchronous))
        {
            await stream.WriteAsync(bytes, ct);
            await stream.FlushAsync(ct);
            stream.Flush(flushToDisk: true);
        }
        File.Move(temp, path, overwrite: true);
    }
}
