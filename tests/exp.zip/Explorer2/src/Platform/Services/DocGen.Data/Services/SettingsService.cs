using System.Text.Json;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Json;
using DocGen.Core.Models;
using DocGen.Data.Storage;
using Microsoft.Extensions.Logging;

namespace DocGen.Data.Services;

/// <summary>
/// data/settings/app.json, providers.json and models.json. Files are re-read on every access so that
/// hand edits take effect without a restart; defaults are written on first run.
/// </summary>
public sealed class SettingsService(IJsonStore store, ILogger<SettingsService> logger) : ISettingsService
{
    private const string AppPath = "settings/app.json";
    private const string ProvidersPath = "settings/providers.json";
    private const string ModelsPath = "settings/models.json";

    private long _generation;

    public long ConfigurationGeneration => Interlocked.Read(ref _generation);

    public async Task<ApplicationSettings> GetAppSettingsAsync(CancellationToken ct = default)
    {
        var settings = await store.ReadAsync<ApplicationSettings>(AppPath, ct);
        if (settings is null)
        {
            settings = new ApplicationSettings { DefaultModelId = DefaultConfiguration.DefaultModelId };
            await store.WriteAsync(AppPath, settings, ct);
        }
        return settings;
    }

    public async Task<ApplicationSettings> UpdateAppSettingsAsync(Action<ApplicationSettings> mutate, CancellationToken ct = default)
    {
        await using (await store.AcquireLockAsync(AppPath, ct))
        {
            var settings = await GetAppSettingsAsync(ct);
            mutate(settings);
            settings.Version++;
            await store.WriteAsync(AppPath, settings, ct);
            logger.LogInformation("Application settings updated to version {SettingsVersion}", settings.Version);
            return settings;
        }
    }

    public async Task<IReadOnlyList<ProviderConfiguration>> GetProvidersAsync(CancellationToken ct = default)
    {
        var doc = await store.ReadAsync<ProvidersDocument>(ProvidersPath, ct);
        if (doc is null)
        {
            doc = new ProvidersDocument { Providers = DefaultConfiguration.Providers() };
            await store.WriteAsync(ProvidersPath, doc, ct);
        }
        return doc.Providers;
    }

    public async Task SaveProvidersAsync(IReadOnlyList<ProviderConfiguration> providers, CancellationToken ct = default)
    {
        foreach (var provider in providers)
        {
            ValidateProvider(provider);
        }
        if (providers.Select(p => p.Id).Distinct(StringComparer.OrdinalIgnoreCase).Count() != providers.Count)
        {
            throw new ValidationException("Provider ids must be unique.");
        }
        await store.WriteAsync(ProvidersPath, new ProvidersDocument { Providers = providers.ToList() }, ct);
        Interlocked.Increment(ref _generation);
        logger.LogInformation("Provider configuration saved ({ProviderCount} providers)", providers.Count);
    }

    public async Task<IReadOnlyList<ModelConfiguration>> GetModelsAsync(CancellationToken ct = default)
    {
        var doc = await store.ReadAsync<ModelsDocument>(ModelsPath, ct);
        if (doc is null)
        {
            doc = new ModelsDocument { Models = DefaultConfiguration.Models() };
            await store.WriteAsync(ModelsPath, doc, ct);
        }
        return doc.Models;
    }

    public async Task SaveModelsAsync(IReadOnlyList<ModelConfiguration> models, CancellationToken ct = default)
    {
        foreach (var model in models)
        {
            if (!Ids.IsValid(model.Id.Replace('.', '-').Replace(':', '-')) || string.IsNullOrWhiteSpace(model.ProviderId))
            {
                throw new ValidationException($"Model '{model.Id}' needs a valid id and provider id.");
            }
            if (model.ContextWindow < 1024 || model.MaxOutputTokens < 1 || model.MaxOutputTokens >= model.ContextWindow)
            {
                throw new ValidationException($"Model '{model.Id}' has invalid token limits.");
            }
        }
        if (models.Select(m => m.Id).Distinct(StringComparer.OrdinalIgnoreCase).Count() != models.Count)
        {
            throw new ValidationException("Model ids must be unique.");
        }
        await store.WriteAsync(ModelsPath, new ModelsDocument { Models = models.ToList() }, ct);
        Interlocked.Increment(ref _generation);
        logger.LogInformation("Model configuration saved ({ModelCount} models)", models.Count);
    }

    private static void ValidateProvider(ProviderConfiguration provider)
    {
        if (!Ids.IsValid(provider.Id))
        {
            throw new ValidationException("Provider id may only contain letters, digits, '-' and '_'.");
        }
        if (provider.Type is not ("fake" or "http"))
        {
            throw new ValidationException($"Provider '{provider.Id}': type must be 'fake' or 'http'.");
        }
        if (provider.Type == "http")
        {
            if (!Uri.TryCreate(provider.BaseUrl, UriKind.Absolute, out var uri) || uri.Scheme is not ("http" or "https"))
            {
                throw new ValidationException($"Provider '{provider.Id}': BaseUrl must be an absolute http(s) URL.");
            }
            if (provider.WireFormat is not ("chat-completions" or "messages"))
            {
                throw new ValidationException($"Provider '{provider.Id}': wireFormat must be 'chat-completions' or 'messages'.");
            }
        }
        foreach (var header in provider.Headers.Keys)
        {
            // Secrets belong in environment variables, never in providers.json.
            if (header.Equals("Authorization", StringComparison.OrdinalIgnoreCase) || header.Contains("key", StringComparison.OrdinalIgnoreCase)
                || header.Contains("token", StringComparison.OrdinalIgnoreCase) || header.Contains("secret", StringComparison.OrdinalIgnoreCase))
            {
                throw new ValidationException($"Provider '{provider.Id}': secret headers must not be stored in configuration. Use ApiKeyEnvironmentVariable.");
            }
        }
        if (provider.TimeoutSeconds is < 1 or > 3600)
        {
            throw new ValidationException($"Provider '{provider.Id}': timeout must be between 1 and 3600 seconds.");
        }
    }

    public static string ToJson<T>(T value) => JsonSerializer.Serialize(value, DocGenJson.Storage);

    private sealed class ProvidersDocument
    {
        public List<ProviderConfiguration> Providers { get; set; } = [];
    }

    private sealed class ModelsDocument
    {
        public List<ModelConfiguration> Models { get; set; } = [];
    }
}
