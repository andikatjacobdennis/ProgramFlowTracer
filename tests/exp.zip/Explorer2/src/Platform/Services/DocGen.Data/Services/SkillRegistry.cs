using System.Collections.Concurrent;
using System.Diagnostics;
using System.IO.Compression;
using System.Text;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Core.Options;
using DocGen.Core.Skills;
using DocGen.Data.Storage;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace DocGen.Data.Services;

/// <summary>
/// Skill packages on disk:
/// <list type="bullet">
/// <item>System: <see cref="DocGenOptions.SkillsDirectory"/> (default: skills/ next to the app), shipped with DocGen.</item>
/// <item>Workspace: {data}/skills/workspace/&lt;id&gt;/, installed by an administrator for everyone.</item>
/// <item>User: {data}/skills/users/&lt;userId&gt;/&lt;id&gt;/, installed by that user.</item>
/// </list>
/// Built-in and workspace skills are turned on for everyone in Settings (<see cref="ApplicationSettings.EnabledSkills"/>);
/// personal skills per user ({data}/skills/users/&lt;userId&gt;/_state.json). Manifests are cached per folder and re-read
/// when SKILL.md or the folder changes; folders are rescanned at most every couple of seconds.
/// </summary>
public sealed class SkillRegistry : ISkillRegistry
{
    private const string StateFile = "_state.json";
    private static readonly TimeSpan RescanInterval = TimeSpan.FromSeconds(2);

    private readonly ISettingsService _settings;
    private readonly IJsonStore _store;
    private readonly IServiceProvider? _services;
    private readonly ILogger<SkillRegistry> _logger;
    private readonly string _systemRoot;
    private readonly string _skillsRoot;
    private readonly ConcurrentDictionary<string, (DateTime Stamp, SkillManifest Manifest)> _manifests = new(StringComparer.OrdinalIgnoreCase);
    private readonly ConcurrentDictionary<string, (long ScannedAt, IReadOnlyList<SkillManifest> Skills)> _roots = new(StringComparer.OrdinalIgnoreCase);
    private readonly SemaphoreSlim _installLock = new(1, 1);

    /// <param name="services">Used to look up the tool registry lazily (the permission manager needs this registry, and tools need permissions).</param>
    public SkillRegistry(IOptions<DocGenOptions> options, ISettingsService settings, IJsonStore store, ILogger<SkillRegistry> logger, IServiceProvider? services = null)
    {
        _settings = settings;
        _store = store;
        _services = services;
        _logger = logger;
        var configured = options.Value.SkillsDirectory;
        _systemRoot = Path.GetFullPath(string.IsNullOrWhiteSpace(configured) ? Path.Combine(AppContext.BaseDirectory, "skills") : configured);
        _skillsRoot = Path.Combine(store.RootDirectory, "skills");
    }

    private string WorkspaceRoot => Path.Combine(_skillsRoot, "workspace");
    private string UserRoot(string userId) => Path.Combine(_skillsRoot, "users", Ids.Require(userId, "userId"));
    private string StagingRoot => Path.Combine(_skillsRoot, "_staging");

    private string RootFor(SkillScope scope, string userId) => scope switch
    {
        SkillScope.Workspace => WorkspaceRoot,
        SkillScope.User => UserRoot(userId),
        _ => throw new ForbiddenException("Built-in skills are part of DocGen and cannot be changed here."),
    };

    public async Task<IReadOnlyList<SkillEntry>> ListAsync(string userId, CancellationToken cancellationToken = default)
    {
        var app = await _settings.GetAppSettingsAsync(cancellationToken);
        var userEnabled = await UserEnabledAsync(userId, cancellationToken);
        var system = Scan(_systemRoot, SkillScope.System, null);
        var workspace = Scan(WorkspaceRoot, SkillScope.Workspace, null);
        var user = Scan(UserRoot(userId), SkillScope.User, userId);

        var entries = new List<SkillEntry>();
        foreach (var skill in system.Concat(workspace).Concat(user))
        {
            var enabled = skill.Scope == SkillScope.User
                ? userEnabled.Contains(skill.Id)
                : app.EnabledSkills.Contains(skill.Id, StringComparer.OrdinalIgnoreCase);
            SkillScope? shadowedBy = skill.Scope switch
            {
                SkillScope.System when user.Any(u => u.Id == skill.Id) => SkillScope.User,
                SkillScope.System when workspace.Any(w => w.Id == skill.Id) => SkillScope.Workspace,
                SkillScope.Workspace when user.Any(u => u.Id == skill.Id) => SkillScope.User,
                _ => null,
            };
            entries.Add(new SkillEntry(skill, enabled, shadowedBy));
        }
        return entries.OrderBy(e => e.Manifest.Id, StringComparer.Ordinal).ThenByDescending(e => e.Manifest.Scope).ToList();
    }

    public async Task<IReadOnlyList<SkillManifest>> AvailableAsync(string userId, CancellationToken cancellationToken = default)
        => (await ListAsync(userId, cancellationToken)).Where(e => e.Enabled && e.ShadowedBy is null && e.Manifest.IsValid).Select(e => e.Manifest).ToList();

    public async Task<SkillEntry?> FindAsync(string userId, string id, SkillScope? scope = null, CancellationToken cancellationToken = default)
    {
        var all = await ListAsync(userId, cancellationToken);
        return scope is { } s
            ? all.FirstOrDefault(e => e.Manifest.Id == id && e.Manifest.Scope == s)
            : all.FirstOrDefault(e => e.Manifest.Id == id && e.ShadowedBy is null);
    }

    public Task<string> LoadInstructionsAsync(SkillManifest skill, CancellationToken cancellationToken = default)
    {
        try
        {
            return Task.FromResult(SkillPackage.ReadInstructions(skill));
        }
        catch (Exception ex) when (ex is InvalidOperationException or IOException)
        {
            throw new ValidationException($"The {skill.DisplayName} skill cannot be loaded: {ex.Message}");
        }
    }

    public async Task<SkillResourceContent?> ReadResourceAsync(SkillManifest skill, string relativePath, int maxChars = SkillLimits.MaxResourceReadChars,
        CancellationToken cancellationToken = default)
    {
        if (SkillPackage.FindResource(skill, relativePath) is not { } resource)
        {
            return null;
        }
        if (!resource.IsText)
        {
            return new SkillResourceContent(resource, null, false);
        }
        var path = SkillPackage.ResolveResource(skill, resource);
        var text = await File.ReadAllTextAsync(path, Encoding.UTF8, cancellationToken);
        var truncated = text.Length > maxChars;
        return new SkillResourceContent(resource, truncated ? text[..maxChars] : text, truncated);
    }

    public async Task<SkillInstallResult> ValidateAsync(SkillInstallSource source, SkillScope scope, CancellationToken cancellationToken = default)
    {
        var staging = await StageAsync(source, cancellationToken);
        try
        {
            return new SkillInstallResult(staging.Skill, staging.Diagnostics, Installed: false);
        }
        finally
        {
            TryDelete(staging.Folder);
        }
    }

    public async Task<SkillInstallResult> InstallAsync(string userId, SkillScope scope, SkillInstallSource source, bool replace, CancellationToken cancellationToken = default)
    {
        var root = RootFor(scope, userId);
        var staged = await StageAsync(source, cancellationToken);
        try
        {
            if (staged.Skill is not { } skill || staged.Diagnostics.Any(d => d.Severity == SkillDiagnosticSeverity.Error))
            {
                return new SkillInstallResult(staged.Skill, staged.Diagnostics, Installed: false);
            }
            await _installLock.WaitAsync(cancellationToken);
            try
            {
                Directory.CreateDirectory(root);
                var target = Path.Combine(root, skill.Id);
                if (Directory.Exists(target))
                {
                    if (!replace)
                    {
                        throw new ValidationException($"A skill named \"{skill.Id}\" is already installed here. Remove it first or choose to replace it.");
                    }
                    var old = Path.Combine(StagingRoot, "removed-" + Ids.New());
                    Directory.Move(target, old);
                    TryDelete(old);
                }
                Directory.Move(staged.PackageFolder!, target);
            }
            finally
            {
                _installLock.Release();
            }
            Invalidate(root);
            var installed = SkillPackage.Load(Path.Combine(root, skill.Id), scope, scope == SkillScope.User ? userId : null, KnownTools());
            _logger.LogInformation("skill_installed {SkillId} scope {Scope} ({Files} files, ~{Tokens} instruction tokens)", installed.Id, scope, installed.Resources.Count, installed.InstructionTokens);
            return new SkillInstallResult(installed, installed.Diagnostics, Installed: true);
        }
        finally
        {
            TryDelete(staged.Folder);
        }
    }

    public async Task UninstallAsync(string userId, SkillScope scope, string id, CancellationToken cancellationToken = default)
    {
        var root = RootFor(scope, userId);
        if (!SkillParser.IsValidId(id) || !Directory.Exists(Path.Combine(root, id)))
        {
            throw new NotFoundException("Skill");
        }
        await _installLock.WaitAsync(cancellationToken);
        try
        {
            var old = Path.Combine(StagingRoot, "removed-" + Ids.New());
            Directory.CreateDirectory(StagingRoot);
            Directory.Move(Path.Combine(root, id), old);
            TryDelete(old);
        }
        finally
        {
            _installLock.Release();
        }
        Invalidate(root);
        await SetEnabledCoreAsync(userId, scope, id, false, cancellationToken);
        _logger.LogInformation("skill_uninstalled {SkillId} scope {Scope}", id, scope);
    }

    public async Task SetEnabledAsync(string userId, SkillScope scope, string id, bool enabled, CancellationToken cancellationToken = default)
    {
        var entry = await FindAsync(userId, id, scope, cancellationToken) ?? throw new NotFoundException("Skill");
        if (enabled && !entry.Manifest.IsValid)
        {
            throw new ValidationException($"The {entry.Manifest.DisplayName} skill has errors and cannot be turned on: " +
                                          entry.Manifest.Diagnostics.First(d => d.Severity == SkillDiagnosticSeverity.Error).Message);
        }
        await SetEnabledCoreAsync(userId, scope, id, enabled, cancellationToken);
        _logger.LogInformation("skill_{Action} {SkillId} scope {Scope}", enabled ? "enabled" : "disabled", id, scope);
    }

    private async Task SetEnabledCoreAsync(string userId, SkillScope scope, string id, bool enabled, CancellationToken cancellationToken)
    {
        if (scope == SkillScope.User)
        {
            var path = $"skills/users/{Ids.Require(userId, "userId")}/{StateFile}";
            await using (await _store.AcquireLockAsync(path, cancellationToken))
            {
                var state = await _store.ReadAsync<UserSkillState>(path, cancellationToken) ?? new UserSkillState();
                state.Enabled.RemoveAll(x => x == id);
                if (enabled)
                {
                    state.Enabled.Add(id);
                }
                await _store.WriteAsync(path, state, cancellationToken);
            }
            return;
        }
        await _settings.UpdateAppSettingsAsync(s =>
        {
            s.EnabledSkills.RemoveAll(x => string.Equals(x, id, StringComparison.OrdinalIgnoreCase));
            if (enabled)
            {
                s.EnabledSkills.Add(id);
            }
        }, cancellationToken);
    }

    public async Task<bool?> IsProvidedToolEnabledAsync(string toolName, CancellationToken cancellationToken = default)
    {
        var providers = Scan(_systemRoot, SkillScope.System, null).Where(s => s.IsValid && s.ProvidesTools.Contains(toolName, StringComparer.OrdinalIgnoreCase)).ToList();
        if (providers.Count == 0)
        {
            return null;
        }
        var app = await _settings.GetAppSettingsAsync(cancellationToken);
        return providers.Any(p => app.EnabledSkills.Contains(p.Id, StringComparer.OrdinalIgnoreCase));
    }

    private async Task<HashSet<string>> UserEnabledAsync(string userId, CancellationToken cancellationToken)
        => (await _store.ReadAsync<UserSkillState>($"skills/users/{Ids.Require(userId, "userId")}/{StateFile}", cancellationToken))?.Enabled.ToHashSet(StringComparer.Ordinal) ?? [];

    private IReadOnlySet<string>? KnownTools()
        => (_services?.GetService(typeof(IToolRegistry)) as IToolRegistry)?.List().Select(t => t.Name).ToHashSet(StringComparer.Ordinal);

    /// <summary>The packages under one root, from the cache unless a folder or SKILL.md changed.</summary>
    private IReadOnlyList<SkillManifest> Scan(string root, SkillScope scope, string? owner)
    {
        var now = Stopwatch.GetTimestamp();
        if (_roots.TryGetValue(root, out var cached) && Stopwatch.GetElapsedTime(cached.ScannedAt, now) < RescanInterval)
        {
            return cached.Skills;
        }
        var skills = new List<SkillManifest>();
        if (Directory.Exists(root))
        {
            foreach (var dir in new DirectoryInfo(root).EnumerateDirectories())
            {
                if (dir.Name.StartsWith('_') || dir.Name.StartsWith('.') || SkillPackage.IsLink(dir))
                {
                    continue;
                }
                var skillMd = new FileInfo(Path.Combine(dir.FullName, SkillParser.FileName));
                var stamp = new DateTime(Math.Max(dir.LastWriteTimeUtc.Ticks, skillMd.Exists ? skillMd.LastWriteTimeUtc.Ticks : 0));
                if (_manifests.TryGetValue(dir.FullName, out var known) && known.Stamp == stamp)
                {
                    skills.Add(known.Manifest);
                    continue;
                }
                try
                {
                    var manifest = SkillPackage.Load(dir.FullName, scope, owner, KnownTools());
                    _manifests[dir.FullName] = (stamp, manifest);
                    skills.Add(manifest);
                    if (!manifest.IsValid)
                    {
                        _logger.LogWarning("Skill package {Folder} ({Scope}) is invalid: {Errors}", dir.Name, scope,
                            string.Join("; ", manifest.Diagnostics.Where(d => d.Severity == SkillDiagnosticSeverity.Error).Select(d => d.Code)));
                    }
                }
                catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
                {
                    _logger.LogWarning(ex, "Skill package {Folder} could not be read", dir.Name);
                }
            }
        }
        _roots[root] = (now, skills);
        return skills;
    }

    private void Invalidate(string root) => _roots.TryRemove(root, out _);

    private sealed record Staged(string Folder, string? PackageFolder, SkillManifest? Skill, IReadOnlyList<SkillDiagnostic> Diagnostics);

    /// <summary>Unpacks a source into a private staging folder and validates it there (nothing reaches a skill root yet).</summary>
    private async Task<Staged> StageAsync(SkillInstallSource source, CancellationToken cancellationToken)
    {
        var folder = Path.Combine(StagingRoot, Ids.New());
        var unpacked = Path.Combine(folder, "package");
        Directory.CreateDirectory(unpacked);
        var diagnostics = new List<SkillDiagnostic>();
        try
        {
            if (source.SkillMd is { } text)
            {
                if (Encoding.UTF8.GetByteCount(text) > SkillLimits.MaxSkillMdBytes)
                {
                    return new Staged(folder, null, null, [new SkillDiagnostic(SkillDiagnosticSeverity.Error, "skill-md-too-large", $"SKILL.md is larger than {SkillLimits.MaxSkillMdBytes / 1024} KB.")]);
                }
                await File.WriteAllTextAsync(Path.Combine(unpacked, SkillParser.FileName), text, new UTF8Encoding(false), cancellationToken);
            }
            else if (source.Zip is { } zip)
            {
                if (!await ExtractAsync(zip, unpacked, diagnostics, cancellationToken))
                {
                    return new Staged(folder, null, null, diagnostics);
                }
            }
            else
            {
                throw new ValidationException("Upload a .zip of the skill folder or paste the SKILL.md text.");
            }

            // The folder must be named after the skill: rename the staging copy to the id in SKILL.md.
            var parsed = SkillParser.Parse(await File.ReadAllTextAsync(Path.Combine(unpacked, SkillParser.FileName), cancellationToken));
            var packageFolder = unpacked;
            if (parsed.Id is { } id && SkillParser.IsValidId(id))
            {
                packageFolder = Path.Combine(folder, id);
                Directory.Move(unpacked, packageFolder);
            }
            var manifest = SkillPackage.Load(packageFolder, SkillScope.User, null, KnownTools());
            diagnostics.AddRange(manifest.Diagnostics);
            return new Staged(folder, packageFolder, manifest, diagnostics);
        }
        catch (FileNotFoundException)
        {
            diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "missing-skill-md", "The package has no SKILL.md at its top level."));
            return new Staged(folder, null, null, diagnostics);
        }
    }

    /// <summary>
    /// Extracts a zip safely: bounded entry count and sizes (including actual decompressed bytes, against zip bombs),
    /// no absolute or ".." paths, no links. A single top-level folder holding SKILL.md is unwrapped.
    /// </summary>
    private static async Task<bool> ExtractAsync(Stream zip, string destination, List<SkillDiagnostic> diagnostics, CancellationToken cancellationToken)
    {
        ZipArchive archive;
        try
        {
            archive = new ZipArchive(zip, ZipArchiveMode.Read, leaveOpen: true);
        }
        catch (InvalidDataException)
        {
            diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "invalid-zip", "The file is not a valid .zip archive."));
            return false;
        }
        using (archive)
        {
            var entries = archive.Entries.Where(e => !(e.FullName.EndsWith('/') && e.Length == 0)).ToList();
            if (entries.Count > SkillLimits.MaxFiles + 5)
            {
                diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "too-many-files", $"The archive has more than {SkillLimits.MaxFiles} files."));
                return false;
            }
            var names = entries.Select(e => e.FullName.Replace('\\', '/')).ToList();
            foreach (var (entry, name) in entries.Zip(names))
            {
                if (name.StartsWith('/') || name.Contains(':') || name.Split('/').Any(p => p is ".." or "."))
                {
                    diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "unsafe-path", "Archive entries must stay inside the package (no absolute or \"..\" paths).", name));
                }
                // Unix symlinks are stored as mode 0xA000 in the high bits of the external attributes.
                if (((entry.ExternalAttributes >> 16) & 0xF000) == 0xA000)
                {
                    diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "link", "Links are not allowed in skill packages.", name));
                }
            }
            if (diagnostics.Count > 0)
            {
                return false;
            }

            // Unwrap "my-skill/SKILL.md" (the usual way a folder is zipped).
            var prefix = "";
            if (!names.Contains(SkillParser.FileName))
            {
                var tops = names.Select(n => n.Split('/')[0]).Distinct().ToList();
                if (tops.Count == 1 && names.Contains($"{tops[0]}/{SkillParser.FileName}"))
                {
                    prefix = tops[0] + "/";
                }
                else
                {
                    diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "missing-skill-md", "The archive must contain SKILL.md at its top level (or inside one top-level folder)."));
                    return false;
                }
            }

            long total = 0;
            var root = Path.GetFullPath(destination).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
            foreach (var (entry, name) in entries.Zip(names))
            {
                if (!name.StartsWith(prefix, StringComparison.Ordinal) || name.EndsWith('/'))
                {
                    continue;
                }
                var relative = name[prefix.Length..];
                var target = Path.GetFullPath(Path.Combine(root, relative.Replace('/', Path.DirectorySeparatorChar)));
                if (!target.StartsWith(root, StringComparison.OrdinalIgnoreCase))
                {
                    diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "unsafe-path", "Archive entry points outside the package.", name));
                    return false;
                }
                Directory.CreateDirectory(Path.GetDirectoryName(target)!);
                await using var input = entry.Open();
                await using var output = File.Create(target);
                var buffer = new byte[81920];
                long written = 0;
                int read;
                while ((read = await input.ReadAsync(buffer, cancellationToken)) > 0)
                {
                    written += read;
                    total += read;
                    if (written > SkillLimits.MaxFileBytes || total > SkillLimits.MaxPackageBytes)
                    {
                        diagnostics.Add(new SkillDiagnostic(SkillDiagnosticSeverity.Error, "package-too-large",
                            $"The package unpacks to more than the limit ({SkillLimits.MaxFileBytes / 1024 / 1024} MB per file, {SkillLimits.MaxPackageBytes / 1024 / 1024} MB in total).", name));
                        return false;
                    }
                    await output.WriteAsync(buffer.AsMemory(0, read), cancellationToken);
                }
            }
            return true;
        }
    }

    private void TryDelete(string folder)
    {
        try
        {
            if (Directory.Exists(folder))
            {
                Directory.Delete(folder, recursive: true);
            }
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            _logger.LogWarning(ex, "Could not delete skill staging folder {Folder}", folder);
        }
    }

    private sealed class UserSkillState
    {
        public List<string> Enabled { get; set; } = [];
    }
}
