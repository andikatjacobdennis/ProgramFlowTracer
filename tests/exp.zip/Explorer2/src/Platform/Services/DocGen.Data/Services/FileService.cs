using System.Security.Cryptography;
using System.Text;
using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Core.Options;
using DocGen.Data.Storage;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace DocGen.Data.Services;

/// <summary>
/// Stores uploaded files in workspaces/{userId}/files/{generatedName} with metadata in data/files/{id}.json.
/// The user-supplied file name is only ever used for display.
/// </summary>
public sealed class FileService : IFileService
{
    private static readonly Dictionary<string, string> ContentTypes = new(StringComparer.OrdinalIgnoreCase)
    {
        [".txt"] = "text/plain",
        [".log"] = "text/plain",
        [".md"] = "text/markdown",
        [".json"] = "application/json",
        [".csv"] = "text/csv",
        [".cs"] = "text/x-csharp",
        [".js"] = "text/javascript",
        [".html"] = "text/html",
        [".css"] = "text/css",
        [".xml"] = "application/xml",
        [".yml"] = "application/yaml",
        [".yaml"] = "application/yaml",
        [".docx"] = "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        [".xlsx"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        [".pptx"] = "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        [".png"] = "image/png",
        [".jpg"] = "image/jpeg",
        [".jpeg"] = "image/jpeg",
        [".gif"] = "image/gif",
        [".bmp"] = "image/bmp",
        [".tif"] = "image/tiff",
        [".tiff"] = "image/tiff",
        [".webp"] = "image/webp",
        [".pdf"] = "application/pdf",
    };

    /// <summary>Image uploads: accepted only when the file starts with the matching image signature.</summary>
    public static bool IsImage(string fileName) => Path.GetExtension(fileName).ToLowerInvariant() is ".png" or ".jpg" or ".jpeg" or ".gif" or ".bmp" or ".tif" or ".tiff" or ".webp";

    /// <summary>The image content type for a file name, or null.</summary>
    public static string? ImageContentType(string fileName) => IsImage(fileName) ? ContentTypes[Path.GetExtension(fileName).ToLowerInvariant()] : null;

    /// <summary>PDF documents: accepted when the file has a PDF header; read as extracted text (see <see cref="DocGen.Core.Documents.PdfTextReader"/>).</summary>
    public static bool IsPdf(string fileName) => Path.GetExtension(fileName).Equals(".pdf", StringComparison.OrdinalIgnoreCase);

    /// <summary>Office Open XML documents: accepted as validated ZIP packages and read with the document tools, never as text.</summary>
    public static bool IsOfficeDocument(string fileName) => Path.GetExtension(fileName).ToLowerInvariant() is ".docx" or ".xlsx" or ".pptx";

    private readonly JsonRepository<StoredFile> _files;
    private readonly DocGenOptions _options;
    private readonly ILogger<FileService> _logger;
    private readonly string _workspaceRoot;

    public FileService(IJsonStore store, IOptions<DocGenOptions> options, ILogger<FileService> logger)
    {
        _files = new JsonRepository<StoredFile>(store, "files");
        _options = options.Value;
        _logger = logger;
        _workspaceRoot = Path.GetFullPath(_options.WorkspaceDirectory);
    }

    public string GetWorkspaceRoot(string userId)
    {
        var root = Path.Combine(_workspaceRoot, Ids.Require(userId, "user id"));
        Directory.CreateDirectory(Path.Combine(root, "files"));
        Directory.CreateDirectory(Path.Combine(root, "generated"));
        return root;
    }

    public async Task<StoredFile> SaveUploadAsync(string userId, string fileName, Stream content, string? projectId = null, CancellationToken ct = default)
    {
        var displayName = SanitizeFileName(fileName);
        var extension = Path.GetExtension(displayName).ToLowerInvariant();
        if (!_options.AllowedUploadExtensions.Contains(extension, StringComparer.OrdinalIgnoreCase))
        {
            throw new ValidationException($"Files of type '{extension}' are not supported. Allowed: {string.Join(", ", _options.AllowedUploadExtensions)}.");
        }

        var id = Ids.New();
        var storedName = id + extension;
        var relative = "files/" + storedName;
        var physical = Path.Combine(GetWorkspaceRoot(userId), "files", storedName);

        long size;
        string sha;
        try
        {
            (size, sha) = await CopyBoundedAsync(content, physical, _options.MaxUploadBytes, ct);
            if (IsOfficeDocument(displayName))
            {
                ValidateOfficePackage(physical);
            }
            else if (IsImage(displayName))
            {
                ValidateImage(physical, extension);
            }
            else if (IsPdf(displayName))
            {
                ValidatePdf(physical);
            }
            else
            {
                ValidateText(physical);
            }
        }
        catch
        {
            if (File.Exists(physical))
            {
                File.Delete(physical);
            }
            throw;
        }

        var file = new StoredFile
        {
            Id = id,
            UserId = userId,
            FileName = displayName,
            StoredName = storedName,
            RelativePath = relative,
            ContentType = ContentTypes.GetValueOrDefault(extension, "text/plain"),
            SizeBytes = size,
            Sha256 = sha,
            ProjectId = projectId,
        };
        await _files.CreateAsync(file, ct);
        _logger.LogInformation("Stored upload {FileId} ({SizeBytes} bytes, {Extension}) for {UserId}", id, size, extension, userId);
        return file;
    }

    public async Task<StoredFile> GetAsync(string userId, string id, CancellationToken ct = default)
    {
        var file = await _files.GetAsync(id, ct);
        if (file is null || file.UserId != userId)
        {
            throw new NotFoundException("File");
        }
        return file;
    }

    public async Task<IReadOnlyList<StoredFile>> ListAsync(string userId, string? projectId = null, CancellationToken ct = default)
        => (await _files.ListAsync(f => f.UserId == userId && (projectId is null || f.ProjectId == projectId), ct))
            .OrderByDescending(f => f.CreatedAt).ToList();

    public async Task<string> ReadTextAsync(string userId, string id, long maxBytes, CancellationToken ct = default)
    {
        var file = await GetAsync(userId, id, ct);
        if (IsPdf(file.FileName))
        {
            // PDFs are binary: their extracted text is what every reader (attachments, file_read) sees.
            var physical = Path.Combine(GetWorkspaceRoot(userId), "files", file.StoredName);
            if (!File.Exists(physical))
            {
                throw new NotFoundException("File content");
            }
            var doc = await Task.Run(() => DocGen.Core.Documents.PdfTextReader.Read(physical, ct), ct);
            var extracted = doc.HasText ? doc.ToText((int)Math.Min(maxBytes, int.MaxValue)) : "";
            return doc.Error is { } error && !doc.HasText ? $"[{error}]" : extracted;
        }
        await using var stream = await OpenReadAsync(userId, id, ct);
        var buffer = new byte[Math.Min(maxBytes, stream.Length)];
        await stream.ReadExactlyAsync(buffer, ct);
        var text = Encoding.UTF8.GetString(buffer);
        return stream.Length > maxBytes ? text + "\n…[truncated]" : text;
    }

    public async Task<Stream> OpenReadAsync(string userId, string id, CancellationToken ct = default)
    {
        var file = await GetAsync(userId, id, ct);
        var physical = Path.Combine(GetWorkspaceRoot(userId), "files", file.StoredName);
        if (!File.Exists(physical))
        {
            throw new NotFoundException("File content");
        }
        return new FileStream(physical, FileMode.Open, FileAccess.Read, FileShare.Read, 4096, useAsync: true);
    }

    public async Task<StoredFile> UpdateAsync(string userId, string id, Action<StoredFile> mutate, CancellationToken ct = default)
    {
        await GetAsync(userId, id, ct);
        return await _files.UpdateAsync(id, f =>
        {
            var (stored, relative, owner) = (f.StoredName, f.RelativePath, f.UserId);
            mutate(f);
            (f.StoredName, f.RelativePath, f.UserId) = (stored, relative, owner); // Physical location is immutable.
        }, ct: ct);
    }

    public async Task DeleteAsync(string userId, string id, CancellationToken ct = default)
    {
        var file = await GetAsync(userId, id, ct);
        var physical = Path.Combine(GetWorkspaceRoot(userId), "files", file.StoredName);
        if (File.Exists(physical))
        {
            File.Delete(physical);
        }
        await _files.DeleteAsync(id, ct);
        _logger.LogInformation("Deleted file {FileId} for {UserId}", id, userId);
    }

    /// <summary>Reduces a client-supplied name to a safe display name (no directories, no control characters).</summary>
    public static string SanitizeFileName(string? fileName)
    {
        var name = Path.GetFileName((fileName ?? "").Replace('\\', '/').Split('/').Last());
        var invalid = Path.GetInvalidFileNameChars();
        var sb = new StringBuilder();
        foreach (var c in name)
        {
            sb.Append(char.IsControl(c) || invalid.Contains(c) ? '_' : c);
        }
        var result = sb.ToString().Trim().Trim('.');
        if (result.Length == 0)
        {
            result = "file.txt";
        }
        return result.Length > 180 ? result[..140] + Path.GetExtension(result) : result;
    }

    private static async Task<(long Size, string Sha)> CopyBoundedAsync(Stream source, string destination, long maxBytes, CancellationToken ct)
    {
        using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
        var buffer = new byte[81920];
        long total = 0;
        await using var output = new FileStream(destination, FileMode.CreateNew, FileAccess.Write, FileShare.None, 81920, useAsync: true);
        int read;
        while ((read = await source.ReadAsync(buffer, ct)) > 0)
        {
            total += read;
            if (total > maxBytes)
            {
                throw new ValidationException($"The file exceeds the maximum upload size of {maxBytes / 1024} KB.");
            }
            hash.AppendData(buffer, 0, read);
            await output.WriteAsync(buffer.AsMemory(0, read), ct);
        }
        return (total, Convert.ToHexStringLower(hash.GetHashAndReset()));
    }

    /// <summary>The file must really be the image type its extension claims (magic bytes).</summary>
    private static void ValidateImage(string path, string extension)
    {
        var buffer = new byte[12];
        int read;
        using (var stream = File.OpenRead(path))
        {
            read = stream.Read(buffer, 0, buffer.Length);
        }
        var head = buffer[..read];
        bool Starts(params byte[] sig) => head.Length >= sig.Length && head.AsSpan(0, sig.Length).SequenceEqual(sig);
        var ok = extension switch
        {
            ".png" => Starts(0x89, 0x50, 0x4E, 0x47),
            ".jpg" or ".jpeg" => Starts(0xFF, 0xD8, 0xFF),
            ".gif" => Starts(0x47, 0x49, 0x46, 0x38),
            ".bmp" => Starts(0x42, 0x4D),
            ".tif" or ".tiff" => Starts(0x49, 0x49, 0x2A, 0x00) || Starts(0x4D, 0x4D, 0x00, 0x2A),
            ".webp" => Starts(0x52, 0x49, 0x46, 0x46) && head.Length >= 12 && head.AsSpan(8, 4).SequenceEqual("WEBP"u8),
            _ => false,
        };
        if (!ok)
        {
            throw new ValidationException($"The file is not a valid {extension.TrimStart('.').ToUpperInvariant()} image.");
        }
    }

    /// <summary>A PDF upload must start with the PDF header (never trust the extension or the client's content type).</summary>
    private static void ValidatePdf(string path)
    {
        var head = new byte[1024];
        using (var stream = File.OpenRead(path))
        {
            head = head[..stream.Read(head, 0, head.Length)];
        }
        if (!DocGen.Core.Documents.PdfTextReader.LooksLikePdf(head))
        {
            throw new ValidationException("The file is not a valid PDF.");
        }
    }

    /// <summary>An Office upload must be a ZIP package with [Content_Types].xml and a bounded number of parts.</summary>
    private static void ValidateOfficePackage(string path)
    {
        try
        {
            using var zip = System.IO.Compression.ZipFile.OpenRead(path);
            if (zip.Entries.Count is 0 or > 10_000 || zip.GetEntry("[Content_Types].xml") is null)
            {
                throw new ValidationException("The file is not a valid Office document.");
            }
        }
        catch (InvalidDataException)
        {
            throw new ValidationException("The file is not a valid Office document.");
        }
    }

    /// <summary>Only text-oriented files are accepted: must be valid UTF-8 without NUL bytes.</summary>
    private static void ValidateText(string path)
    {
        var strict = new UTF8Encoding(false, throwOnInvalidBytes: true);
        using var reader = new StreamReader(path, strict, detectEncodingFromByteOrderMarks: true);
        var buffer = new char[8192];
        try
        {
            int read;
            while ((read = reader.Read(buffer, 0, buffer.Length)) > 0)
            {
                if (Array.IndexOf(buffer, '\0', 0, read) >= 0)
                {
                    throw new ValidationException("Binary files are not supported.");
                }
            }
        }
        catch (DecoderFallbackException)
        {
            throw new ValidationException("The file is not valid UTF-8 text.");
        }
    }
}
