using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Data.Storage;

namespace DocGen.Data.Repositories;

/// <summary>
/// Messages live in data/messages/{conversationId}/{messageId}.json so that appending or streaming
/// into one message never rewrites the whole conversation. Callers must verify conversation ownership.
/// </summary>
public sealed class MessageRepository(IJsonStore store) : IMessageRepository
{
    private JsonRepository<Message> For(string conversationId) => new(store, $"messages/{Ids.Require(conversationId, "conversation id")}");

    public Task<Message> CreateAsync(Message message, CancellationToken ct = default) => For(message.ConversationId).CreateAsync(message, ct);

    public Task<Message?> GetAsync(string conversationId, string messageId, CancellationToken ct = default)
        => For(conversationId).GetAsync(messageId, ct);

    public async Task<Message> UpdateAsync(string conversationId, string messageId, Action<Message> mutate, CancellationToken ct = default)
    {
        try
        {
            return await For(conversationId).UpdateAsync(messageId, m =>
            {
                mutate(m);
                m.ConversationId = conversationId;
            }, ct: ct);
        }
        catch (NotFoundException)
        {
            throw new NotFoundException("Message");
        }
    }

    public async Task<IReadOnlyList<Message>> ListAsync(string conversationId, CancellationToken ct = default)
        => (await For(conversationId).ListAsync(ct: ct)).OrderBy(m => m.CreatedAt).ThenBy(m => m.Id, StringComparer.Ordinal).ToList();

    public Task DeleteAllAsync(string conversationId, CancellationToken ct = default)
        => store.DeleteDirectoryAsync($"messages/{Ids.Require(conversationId, "conversation id")}", ct);

    public async Task<IReadOnlyList<Message>> ListByStatusAsync(MessageStatus status, CancellationToken ct = default)
    {
        var result = new List<Message>();
        foreach (var conversationId in store.EnumerateDirectories("messages").Where(Ids.IsValid))
        {
            result.AddRange(await For(conversationId).ListAsync(m => m.Status == status, ct));
        }
        return result;
    }
}
