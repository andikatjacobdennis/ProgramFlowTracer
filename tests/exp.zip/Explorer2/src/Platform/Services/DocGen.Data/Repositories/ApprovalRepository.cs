using DocGen.Core.Abstractions;
using DocGen.Core.Models;
using DocGen.Data.Storage;

namespace DocGen.Data.Repositories;

/// <summary>Approvals in data/approvals/{id}.json. State changes happen under the per-approval lock.</summary>
public sealed class ApprovalRepository(IJsonStore store) : IApprovalRepository
{
    private readonly JsonRepository<ApprovalRecord> _approvals = new(store, "approvals");

    public Task<ApprovalRecord> CreateAsync(ApprovalRecord approval, CancellationToken ct = default) => _approvals.CreateAsync(approval, ct);

    public Task<ApprovalRecord?> GetAsync(string id, CancellationToken ct = default) => _approvals.GetAsync(id, ct);

    public async Task<ApprovalRecord?> TryTransitionAsync(string id, IReadOnlyCollection<ApprovalStatus> from, Action<ApprovalRecord> apply, CancellationToken ct = default)
    {
        if (!Ids.IsValid(id))
        {
            return null;
        }
        var path = _approvals.PathFor(id);
        await using (await store.AcquireLockAsync(path, ct))
        {
            var approval = await store.ReadAsync<ApprovalRecord>(path, ct);
            if (approval is null || !from.Contains(approval.Status))
            {
                return null;
            }
            apply(approval);
            approval.Id = id;
            approval.Version++;
            approval.UpdatedAt = DateTime.UtcNow;
            await store.WriteAsync(path, approval, ct);
            return approval;
        }
    }

    public async Task<IReadOnlyList<ApprovalRecord>> ListByStatusAsync(IReadOnlyCollection<ApprovalStatus> statuses, string? userId = null, CancellationToken ct = default)
        => (await _approvals.ListAsync(a => statuses.Contains(a.Status) && (userId is null || a.UserId == userId), ct))
            .OrderBy(a => a.CreatedAt).ToList();
}
