using DocGen.Core.Abstractions;
using DocGen.Core.Models;
using DocGen.Data.Storage;

namespace DocGen.Data.Repositories;

public sealed class SessionRepository(IJsonStore store) : ISessionRepository
{
    private readonly JsonRepository<Session> _sessions = new(store, "sessions");

    public Task<Session> CreateAsync(Session session, CancellationToken ct = default) => _sessions.CreateAsync(session, ct);

    public Task<Session?> GetAsync(string id, CancellationToken ct = default) => _sessions.GetAsync(id, ct);

    public async Task RevokeAsync(string id, CancellationToken ct = default)
    {
        if (await _sessions.GetAsync(id, ct) is not null)
        {
            await _sessions.DeleteAsync(id, ct);
        }
    }

    public async Task RevokeAllAsync(string userId, CancellationToken ct = default)
    {
        foreach (var session in await _sessions.ListAsync(s => s.UserId == userId || s.ExpiresAt < DateTime.UtcNow, ct))
        {
            await _sessions.DeleteAsync(session.Id, ct);
        }
    }
}
