using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Data.Storage;

namespace DocGen.Data.Repositories;

/// <summary>Agent runs in data/runs/{runId}.json.</summary>
public sealed class RunRepository(IJsonStore store) : IRunRepository
{
    private readonly JsonRepository<AgentRun> _runs = new(store, "runs");

    public Task<AgentRun> CreateAsync(AgentRun run, CancellationToken ct = default) => _runs.CreateAsync(run, ct);

    public async Task<AgentRun> GetAsync(string userId, string id, CancellationToken ct = default)
    {
        var run = await _runs.GetAsync(id, ct);
        if (run is null || run.UserId != userId)
        {
            throw new NotFoundException("Run");
        }
        return run;
    }

    public async Task SaveAsync(AgentRun run, CancellationToken ct = default)
    {
        // Runs are only written by the single agent loop that owns them, so last-writer-wins is safe;
        // the version is refreshed to avoid spurious conflicts.
        var path = _runs.PathFor(run.Id);
        await using (await store.AcquireLockAsync(path, ct))
        {
            var existing = await store.ReadAsync<AgentRun>(path, ct);
            run.Version = (existing?.Version ?? 0) + 1;
            run.UpdatedAt = DateTime.UtcNow;
            await store.WriteAsync(path, run, ct);
        }
    }

    public async Task<IReadOnlyList<AgentRun>> ListAsync(string userId, int limit = 200, CancellationToken ct = default)
        => (await _runs.ListAsync(r => r.UserId == userId, ct)).OrderByDescending(r => r.StartedAt).Take(limit).ToList();

    public async Task<IReadOnlyList<AgentRun>> ListByStatusAsync(IReadOnlyCollection<RunStatus> statuses, CancellationToken ct = default)
        => await _runs.ListAsync(r => statuses.Contains(r.Status), ct);

    public async Task<AgentRun?> TryTransitionAsync(string userId, string runId, IReadOnlyCollection<RunStatus> from, Action<AgentRun> apply, CancellationToken ct = default)
    {
        if (!Ids.IsValid(runId))
        {
            return null;
        }
        var path = _runs.PathFor(runId);
        await using (await store.AcquireLockAsync(path, ct))
        {
            var run = await store.ReadAsync<AgentRun>(path, ct);
            if (run is null || run.UserId != userId || !from.Contains(run.Status))
            {
                return null;
            }
            apply(run);
            run.Id = runId;
            run.UserId = userId;
            run.Version++;
            run.UpdatedAt = DateTime.UtcNow;
            await store.WriteAsync(path, run, ct);
            return run;
        }
    }
}
