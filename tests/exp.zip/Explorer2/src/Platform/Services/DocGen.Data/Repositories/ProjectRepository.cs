using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Data.Storage;

namespace DocGen.Data.Repositories;

public sealed class ProjectRepository : IProjectRepository
{
    private readonly JsonRepository<Project> _projects;
    private readonly JsonIndex<ProjectIndexEntry> _index;

    public ProjectRepository(IJsonStore store)
    {
        _projects = new JsonRepository<Project>(store, "projects");
        _index = new JsonIndex<ProjectIndexEntry>(store, "indexes/projects.json", e => e.Id, async ct =>
            (await _projects.ListAsync(ct: ct)).Select(ProjectIndexEntry.From));
    }

    public async Task<Project> CreateAsync(Project project, CancellationToken ct = default)
    {
        await _projects.CreateAsync(project, ct);
        await _index.UpsertAsync(ProjectIndexEntry.From(project), ct);
        return project;
    }

    public async Task<Project> GetAsync(string userId, string id, CancellationToken ct = default)
    {
        var project = await _projects.GetAsync(id, ct);
        if (project is null || project.UserId != userId)
        {
            throw new NotFoundException("Project");
        }
        return project;
    }

    public async Task<IReadOnlyList<Project>> ListAsync(string userId, CancellationToken ct = default)
    {
        var entries = await _index.QueryAsync(e => e.UserId == userId, ct);
        var result = new List<Project>();
        foreach (var entry in entries)
        {
            if (await _projects.GetAsync(entry.Id, ct) is { } project && project.UserId == userId)
            {
                result.Add(project);
            }
        }
        return result.OrderBy(p => p.Name, StringComparer.OrdinalIgnoreCase).ToList();
    }

    public async Task<Project> UpdateAsync(string userId, string id, Action<Project> mutate, CancellationToken ct = default)
    {
        await GetAsync(userId, id, ct);
        var updated = await _projects.UpdateAsync(id, p =>
        {
            mutate(p);
            p.UserId = userId;
        }, ct: ct);
        await _index.UpsertAsync(ProjectIndexEntry.From(updated), ct);
        return updated;
    }

    public async Task DeleteAsync(string userId, string id, CancellationToken ct = default)
    {
        await GetAsync(userId, id, ct);
        await _projects.DeleteAsync(id, ct);
        await _index.RemoveAsync(id, ct);
    }

    private sealed class ProjectIndexEntry
    {
        public string Id { get; set; } = "";
        public string UserId { get; set; } = "";
        public string Name { get; set; } = "";

        public static ProjectIndexEntry From(Project p) => new() { Id = p.Id, UserId = p.UserId, Name = p.Name };
    }
}
