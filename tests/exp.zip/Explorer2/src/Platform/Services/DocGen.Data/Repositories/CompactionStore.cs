using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Data.Storage;

namespace DocGen.Data.Repositories;

/// <summary>Compaction snapshots in data/runs/{runId}/compactions/{sequence}.json (atomic writes).</summary>
public sealed class CompactionStore(IJsonStore store) : ICompactionStore
{
    private static string Dir(string runId) => $"runs/{Ids.Require(runId, "run id")}/compactions";

    public Task SaveAsync(ContextCompactionSnapshot snapshot, CancellationToken ct = default)
        => store.WriteAsync($"{Dir(snapshot.RunId)}/{snapshot.Sequence:D4}-{Ids.Require(snapshot.Id, "snapshot id")}.json", snapshot, ct);

    public async Task<ContextCompactionSnapshot?> GetAsync(string runId, string snapshotId, CancellationToken ct = default)
        => (await ListAsync(runId, ct)).FirstOrDefault(s => s.Id == snapshotId);

    public async Task<IReadOnlyList<ContextCompactionSnapshot>> ListAsync(string runId, CancellationToken ct = default)
    {
        var list = new List<ContextCompactionSnapshot>();
        foreach (var path in store.EnumerateDocuments(Dir(runId)))
        {
            try
            {
                if (await store.ReadAsync<ContextCompactionSnapshot>(path, ct) is { } snapshot)
                {
                    list.Add(snapshot);
                }
            }
            catch (StorageException)
            {
            }
        }
        return list.OrderBy(s => s.Sequence).ToList();
    }
}
