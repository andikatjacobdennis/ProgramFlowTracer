using DocGen.Core.Abstractions;
using DocGen.Core.Models;
using DocGen.Data.Storage;

namespace DocGen.Data.Repositories;

/// <summary>
/// Checkpoints in data/runs/{runId}/checkpoint.json. Writes go through the atomic JSON store (temp → replace,
/// previous version kept as .bak), so a torn or corrupt write falls back to the last good checkpoint.
/// Each checkpoint is bounded before it is written.
/// </summary>
public sealed class AgentCheckpointStore(IJsonStore store) : IAgentCheckpointStore
{
    /// <summary>Upper bound on the characters of model-message content kept in a checkpoint.</summary>
    public const int MaxMessageChars = 600_000;
    public const int MaxMessages = 400;
    public const int MaxToolResultChars = 4_000;

    private static string PathFor(string runId) => $"runs/{Ids.Require(runId, "run id")}/checkpoint.json";

    public async Task SaveAsync(AgentCheckpoint checkpoint, CancellationToken ct = default)
    {
        var path = PathFor(checkpoint.RunId);
        await using (await store.AcquireLockAsync(path, ct))
        {
            var existing = await TryReadAsync(path, ct);
            checkpoint.Sequence = (existing?.Sequence ?? 0) + 1;
            checkpoint.SavedAt = DateTime.UtcNow;
            Bound(checkpoint);
            await store.WriteAsync(path, checkpoint, ct);
        }
    }

    public async Task<AgentCheckpoint?> GetAsync(string runId, CancellationToken ct = default)
        => Ids.IsValid(runId) ? await store.ReadAsync<AgentCheckpoint>(PathFor(runId), ct) : null;

    public async Task FinalizeAsync(string runId, string finalStatus, int? finalIteration = null, CancellationToken ct = default)
        => await UpdateAsync(runId, c =>
        {
            c.Iteration = finalIteration ?? c.Iteration;
            // Keep audit metadata only; the resumable conversation state is no longer needed.
            c.Finalized = true;
            c.FinalStatus = finalStatus;
            c.Messages = [];
            c.PendingToolCalls = [];
            c.Parts = [];
            c.ToolResults = [];
        }, ct);

    public async Task<AgentCheckpoint?> UpdateAsync(string runId, Action<AgentCheckpoint> mutate, CancellationToken ct = default)
    {
        if (!Ids.IsValid(runId))
        {
            return null;
        }
        var path = PathFor(runId);
        await using (await store.AcquireLockAsync(path, ct))
        {
            var checkpoint = await store.ReadAsync<AgentCheckpoint>(path, ct);
            if (checkpoint is null)
            {
                return null;
            }
            mutate(checkpoint);
            checkpoint.Sequence++;
            checkpoint.SavedAt = DateTime.UtcNow;
            Bound(checkpoint);
            await store.WriteAsync(path, checkpoint, ct);
            return checkpoint;
        }
    }

    private async Task<AgentCheckpoint?> TryReadAsync(string path, CancellationToken ct)
    {
        try
        {
            return await store.ReadAsync<AgentCheckpoint>(path, ct);
        }
        catch (Core.Exceptions.StorageException)
        {
            return null; // Unreadable previous checkpoint: the new one replaces it.
        }
    }

    /// <summary>Keeps the checkpoint bounded: oldest tool outputs are shortened first, then the oldest turns dropped.</summary>
    public static void Bound(AgentCheckpoint checkpoint)
    {
        foreach (var result in checkpoint.ToolResults.Where(r => r.Content.Length > MaxToolResultChars))
        {
            result.Content = result.Content[..MaxToolResultChars] + "…";
        }
        foreach (var pending in checkpoint.PendingToolCalls.Where(p => p.Result is { Content.Length: > MaxToolResultChars }))
        {
            pending.Result!.Content = pending.Result.Content[..MaxToolResultChars] + "…";
        }

        var messages = checkpoint.Messages;
        int Total() => messages.Sum(m => m.Content.Length + (m.ToolCalls?.Sum(c => c.Arguments.Length) ?? 0));

        foreach (var message in messages.Where(m => m.Role == MessageRole.Tool))
        {
            if (Total() <= MaxMessageChars)
            {
                break;
            }
            if (message.Content.Length > 300)
            {
                message.Content = message.Content[..300] + "\n…[older tool output removed from the checkpoint]";
            }
        }

        // Last resort: drop the oldest non-system turns. A dropped assistant turn takes its tool results with it,
        // so no provider ever sees a tool result without the call that produced it.
        while ((Total() > MaxMessageChars || messages.Count > MaxMessages) && messages.Count > 3)
        {
            var index = messages.FindIndex(1, m => m.Role != MessageRole.System);
            if (index < 0 || index >= messages.Count - 2)
            {
                break;
            }
            messages.RemoveAt(index);
            while (index < messages.Count - 1 && messages[index].Role == MessageRole.Tool)
            {
                messages.RemoveAt(index);
            }
        }
    }
}
