using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Data.Storage;

namespace DocGen.Data.Repositories;

/// <summary>
/// Conversation metadata in data/conversations/{id}.json plus a summary index in
/// data/indexes/conversations.json used to list a user's conversations without scanning everything.
/// </summary>
public sealed class ConversationRepository : IConversationRepository
{
    private readonly JsonRepository<Conversation> _conversations;
    private readonly JsonIndex<ConversationIndexEntry> _index;

    public ConversationRepository(IJsonStore store)
    {
        _conversations = new JsonRepository<Conversation>(store, "conversations");
        _index = new JsonIndex<ConversationIndexEntry>(store, "indexes/conversations.json", e => e.Id, async ct =>
            (await _conversations.ListAsync(ct: ct)).Select(ConversationIndexEntry.From));
    }

    public async Task<Conversation> CreateAsync(Conversation conversation, CancellationToken ct = default)
    {
        await _conversations.CreateAsync(conversation, ct);
        await _index.UpsertAsync(ConversationIndexEntry.From(conversation), ct);
        return conversation;
    }

    public async Task<Conversation> GetAsync(string userId, string id, CancellationToken ct = default)
    {
        var conversation = await _conversations.GetAsync(id, ct);
        if (conversation is null || conversation.UserId != userId)
        {
            throw new NotFoundException("Conversation");
        }
        return conversation;
    }

    public async Task<IReadOnlyList<Conversation>> ListAsync(string userId, bool includeArchived = false, string? projectId = null, CancellationToken ct = default)
    {
        var entries = await _index.QueryAsync(e =>
            e.UserId == userId
            && (includeArchived || !e.Archived)
            && (projectId is null || e.ProjectId == projectId), ct);

        var result = new List<Conversation>(entries.Count);
        foreach (var entry in entries)
        {
            var conversation = await _conversations.GetAsync(entry.Id, ct);
            if (conversation is not null && conversation.UserId == userId)
            {
                result.Add(conversation);
            }
        }
        return result.OrderByDescending(c => c.LastMessageAt ?? c.UpdatedAt).ToList();
    }

    public async Task<Conversation> UpdateAsync(string userId, string id, Action<Conversation> mutate, CancellationToken ct = default)
    {
        await GetAsync(userId, id, ct); // Ownership check before taking the write path.
        var updated = await _conversations.UpdateAsync(id, c =>
        {
            mutate(c);
            c.UserId = userId; // Ownership can never be transferred through an update.
        }, ct: ct);
        await _index.UpsertAsync(ConversationIndexEntry.From(updated), ct);
        return updated;
    }

    public async Task DeleteAsync(string userId, string id, CancellationToken ct = default)
    {
        await GetAsync(userId, id, ct);
        await _conversations.DeleteAsync(id, ct);
        await _index.RemoveAsync(id, ct);
    }

    private sealed class ConversationIndexEntry
    {
        public string Id { get; set; } = "";
        public string UserId { get; set; } = "";
        public string Title { get; set; } = "";
        public string? ProjectId { get; set; }
        public bool Archived { get; set; }
        public DateTime UpdatedAt { get; set; }

        public static ConversationIndexEntry From(Conversation c) => new()
        {
            Id = c.Id,
            UserId = c.UserId,
            Title = c.Title,
            ProjectId = c.ProjectId,
            Archived = c.Archived,
            UpdatedAt = c.UpdatedAt,
        };
    }
}
