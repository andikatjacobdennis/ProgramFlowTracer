using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Data.Storage;

namespace DocGen.Data.Repositories;

public sealed class PersonaRepository : IPersonaRepository
{
    private readonly JsonRepository<Persona> _personas;
    private readonly JsonIndex<PersonaIndexEntry> _index;

    public PersonaRepository(IJsonStore store)
    {
        _personas = new JsonRepository<Persona>(store, "personas");
        _index = new JsonIndex<PersonaIndexEntry>(store, "indexes/personas.json", e => e.Id, async ct =>
            (await _personas.ListAsync(ct: ct)).Select(PersonaIndexEntry.From));
    }

    public async Task<Persona> CreateAsync(Persona persona, CancellationToken ct = default)
    {
        await _personas.CreateAsync(persona, ct);
        await _index.UpsertAsync(PersonaIndexEntry.From(persona), ct);
        return persona;
    }

    public async Task<Persona> GetAsync(string userId, string id, CancellationToken ct = default)
    {
        var persona = await _personas.GetAsync(id, ct);
        if (persona is null || persona.UserId != userId)
        {
            throw new NotFoundException("Persona");
        }
        return persona;
    }

    public async Task<IReadOnlyList<Persona>> ListAsync(string userId, CancellationToken ct = default)
    {
        var entries = await _index.QueryAsync(e => e.UserId == userId, ct);
        var result = new List<Persona>();
        foreach (var entry in entries)
        {
            if (await _personas.GetAsync(entry.Id, ct) is { } persona && persona.UserId == userId)
            {
                result.Add(persona);
            }
        }
        return result.OrderBy(p => p.Name, StringComparer.OrdinalIgnoreCase).ToList();
    }

    public async Task<Persona> UpdateAsync(string userId, string id, Action<Persona> mutate, CancellationToken ct = default)
    {
        await GetAsync(userId, id, ct);
        var updated = await _personas.UpdateAsync(id, p =>
        {
            mutate(p);
            p.UserId = userId;
        }, ct: ct);
        await _index.UpsertAsync(PersonaIndexEntry.From(updated), ct);
        return updated;
    }

    public async Task DeleteAsync(string userId, string id, CancellationToken ct = default)
    {
        await GetAsync(userId, id, ct);
        await _personas.DeleteAsync(id, ct);
        await _index.RemoveAsync(id, ct);
    }

    private sealed class PersonaIndexEntry
    {
        public string Id { get; set; } = "";
        public string UserId { get; set; } = "";
        public string Name { get; set; } = "";

        public static PersonaIndexEntry From(Persona p) => new() { Id = p.Id, UserId = p.UserId, Name = p.Name };
    }
}
