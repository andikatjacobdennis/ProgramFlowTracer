using DocGen.Core.Abstractions;
using DocGen.Core.Exceptions;
using DocGen.Core.Models;
using DocGen.Data.Storage;

namespace DocGen.Data.Repositories;

public sealed class UserRepository : IUserRepository
{
    private readonly JsonRepository<User> _users;
    private readonly JsonIndex<UserIndexEntry> _index;
    private readonly IJsonStore _store;

    public UserRepository(IJsonStore store)
    {
        _store = store;
        _users = new JsonRepository<User>(store, "users");
        _index = new JsonIndex<UserIndexEntry>(store, "indexes/users.json", e => e.Id, async ct =>
            (await _users.ListAsync(ct: ct)).Select(UserIndexEntry.From));
    }

    public Task<User?> GetAsync(string id, CancellationToken ct = default) => _users.GetAsync(id, ct);

    public async Task<User?> FindByUserNameAsync(string userName, CancellationToken ct = default)
    {
        var normalized = Normalize(userName);
        var match = (await _index.QueryAsync(e => e.NormalizedUserName == normalized, ct)).FirstOrDefault();
        return match is null ? null : await _users.GetAsync(match.Id, ct);
    }

    public async Task<User?> FindByTcpTokenHashAsync(string tokenHash, CancellationToken ct = default)
    {
        var match = (await _index.QueryAsync(e => e.TcpTokenHash is not null && e.TcpTokenHash == tokenHash, ct)).FirstOrDefault();
        return match is null ? null : await _users.GetAsync(match.Id, ct);
    }

    public async Task<int> CountAsync(CancellationToken ct = default) => (await _index.QueryAsync(_ => true, ct)).Count;

    public async Task<User> CreateAsync(User user, CancellationToken ct = default)
    {
        user.NormalizedUserName = Normalize(user.UserName);
        // Serialise registrations so two requests cannot claim the same user name.
        await using (await _store.AcquireLockAsync("users:create", ct))
        {
            if (await FindByUserNameAsync(user.UserName, ct) is not null)
            {
                throw new ValidationException("That user name is already taken.");
            }
            await _users.CreateAsync(user, ct);
            await _index.UpsertAsync(UserIndexEntry.From(user), ct);
            return user;
        }
    }

    public async Task<User> UpdateAsync(string id, Action<User> mutate, CancellationToken ct = default)
    {
        var user = await _users.UpdateAsync(id, u =>
        {
            var userName = u.NormalizedUserName;
            mutate(u);
            u.NormalizedUserName = userName; // User names are immutable after registration.
        }, ct: ct);
        await _index.UpsertAsync(UserIndexEntry.From(user), ct);
        return user;
    }

    public static string Normalize(string userName) => userName.Trim().ToUpperInvariant();

    private sealed class UserIndexEntry
    {
        public string Id { get; set; } = "";
        public string NormalizedUserName { get; set; } = "";
        public string? TcpTokenHash { get; set; }

        public static UserIndexEntry From(User u) => new() { Id = u.Id, NormalizedUserName = u.NormalizedUserName, TcpTokenHash = u.TcpTokenHash };
    }
}
