@echo off
rem Runs installer\Build-Setup.ps1 with Windows PowerShell (no execution-policy change needed). Arguments are passed on,
rem for example: Build-Setup.cmd -Version 1.1.0
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0installer\Build-Setup.ps1" %*
if errorlevel 1 pause
