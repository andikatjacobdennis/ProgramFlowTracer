<#
.SYNOPSIS
    Builds the DocGen Explorer setup (setup.exe and DocGen.Explorer.Setup.msi) with Visual Studio.

.DESCRIPTION
    Publishes the app self-contained (the .NET runtime is inside DocGen.Explorer.exe) to installer\publish, then builds
    installer\DocGen.Explorer.Setup\DocGen.Explorer.Setup.vdproj in Release, which packages those files. setup.exe
    installs the Microsoft Edge WebView2 Runtime first when a PC does not have it.

    With -Version, the new version is written to Directory.Build.props (the program's file version) and to the setup
    project. The upgrade code never changes. Every build gets a product code of its own (PostBuild.js), so a setup
    replaces any installed earlier build — a lower version or the same version built again — and running the same
    setup again offers Repair and Remove.

    Needs Visual Studio with the "Microsoft Visual Studio Installer Projects" extension.

.PARAMETER Version
    The new version, major.minor.build (for example 1.1.0). Leave it out to build the current version again.

.EXAMPLE
    .\Build-Setup.ps1
.EXAMPLE
    .\Build-Setup.ps1 -Version 1.1.0
#>
param([string] $Version)
$ErrorActionPreference = 'Stop'

$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
# The setup's own solution: only the setup project, which packages the published files. (Building it from the whole
# solution made Visual Studio load and restore every app project, and log failures that did not matter.)
$solution = Join-Path $root 'installer\DocGen.Explorer.Setup.sln'
$setupProject = Join-Path $root 'installer\DocGen.Explorer.Setup\DocGen.Explorer.Setup.vdproj'
$props = Join-Path $root 'Directory.Build.props'
$output = Join-Path $root 'installer\DocGen.Explorer.Setup\Release'
$utf8Bom = New-Object System.Text.UTF8Encoding($true)

# Visual Studio: the newest installed one (devenv.com is the console form of devenv.exe).
$vswhere = Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
if (-not (Test-Path $vswhere)) { throw 'Visual Studio is not installed (vswhere.exe was not found).' }
$devenv = & $vswhere -latest -prerelease -products * -property productPath | Select-Object -First 1
if (-not $devenv) { throw 'Visual Studio is not installed.' }
$devenv = [IO.Path]::ChangeExtension($devenv, '.com')
$disableOutOfProc = Join-Path (Split-Path $devenv) 'CommonExtensions\Microsoft\VSI\DisableOutOfProcBuild\DisableOutOfProcBuild.exe'
if (-not (Test-Path $disableOutOfProc)) {
    throw 'The "Microsoft Visual Studio Installer Projects" extension is not installed in Visual Studio (Extensions > Manage Extensions).'
}

$project = [IO.File]::ReadAllText($setupProject)
$current = [regex]::Match($project, '"ProductVersion" = "8:([^"]+)"').Groups[1].Value

if ($Version -and $Version -ne $current) {
    if ($Version -notmatch '^\d{1,3}\.\d{1,3}\.\d{1,5}$') {
        throw "The version must be major.minor.build, for example 1.1.0 (Windows Installer compares only these three)."
    }
    if ([version]$Version -le [version]$current) {
        throw "The version must be higher than the current $current, or installing it will not replace the installed one."
    }
    $newCode = { '"8:{' + [guid]::NewGuid().ToString().ToUpperInvariant() + '}"' }
    $project = $project -replace '"ProductVersion" = "8:[^"]+"', "`"ProductVersion`" = `"8:$Version`""
    $project = [regex]::Replace($project, '(?<="ProductCode" = )"8:\{[0-9A-F-]+\}"', $newCode)
    $project = [regex]::Replace($project, '(?<="PackageCode" = )"8:\{[0-9A-F-]+\}"', $newCode)
    [IO.File]::WriteAllText($setupProject, $project, $utf8Bom)

    $text = [IO.File]::ReadAllText($props)
    [IO.File]::WriteAllText($props, ($text -replace '<Version>[^<]+</Version>', "<Version>$Version</Version>"), $utf8Bom)
    Write-Host "Version $current -> $Version (new product code; the upgrade code stays)."
    $current = $Version
}

if (-not (Test-Path (Join-Path $root 'secrets\providers.key'))) {
    Write-Warning 'secrets\providers.key is missing: this build cannot import providers files. Create it with scripts\New-ProvidersKey.cmd, or copy the team key there.'
}

# Visual Studio builds setup projects from the command line only with out-of-process builds off (once per PC). The tool
# must be run from its own folder.
Push-Location (Split-Path $disableOutOfProc)
try { & $disableOutOfProc | Out-Null } finally { Pop-Location }

# Publish the app here, not in a pre-build step of the setup project: Visual Studio checks that every file of the setup
# exists before it builds, so on a clean machine (a build server) installer\publish must already be filled, and
# publishing again during the build rewrites the files while Visual Studio is packaging them.
Write-Host "Publishing DocGen Explorer $current..."
# From an empty folder: a publish into an earlier one can leave out files it considers up to date there.
$publish = Join-Path $root 'installer\publish'
if (Test-Path $publish) { Remove-Item $publish -Recurse -Force }
& dotnet publish (Join-Path $root 'src\App\DocGen.Explorer\DocGen.Explorer.csproj') -p:PublishProfile=Installer -nologo
if ($LASTEXITCODE -ne 0) { throw "Publishing the app failed (exit code $LASTEXITCODE)." }
# The files the setup project packages.
foreach ($file in 'DocGen.Explorer.exe', 'Assets\mermaid\mermaid.min.js', 'Assets\mermaid\render.html', 'Assets\mermaid\LICENSE.txt') {
    if (-not (Test-Path (Join-Path $publish $file))) { throw "The publish did not produce $file." }
}

Write-Host "Building DocGen Explorer $current setup..."
if (Test-Path $output) { Remove-Item $output -Recurse -Force }
# Visual Studio's own log says why a build failed; on a build server the console shows little more than "Waiting for
# background operations to complete".
$log = Join-Path ([IO.Path]::GetTempPath()) 'DocGen.Explorer.Setup.build.log'
if (Test-Path $log) { Remove-Item $log -Force }
& $devenv $solution /Rebuild Release /Project $setupProject /Out $log
$exit = $LASTEXITCODE
if ($exit -ne 0) {
    if (Test-Path $log) { Write-Host '--- Visual Studio build log ---'; Get-Content $log | Write-Host }
    throw "The setup did not build (exit code $exit). The log is $log."
}

$msi = Join-Path $output 'DocGen.Explorer.Setup.msi'
if (-not (Test-Path $msi)) { throw "The build finished but $msi is missing." }
# Visual Studio reports success even when the post-build step fails; without it the setup cannot upgrade a build of the
# same version, and uninstalling leaves the cache.
if ((Get-Content $log -Raw) -notmatch 'PostBuild\.js: product code') {
    Get-Content $log | Write-Host
    throw "PostBuild.js did not finish (see the log above); the setup in $output is incomplete."
}
# What the MSI will do on install, upgrade, repair and uninstall, read from its tables.
Write-Host 'Checking the setup...'
& (Join-Path $PSScriptRoot 'Test-Setup.ps1') -Msi $msi
Write-Host ''
Write-Host "DocGen Explorer $current setup:"
Get-ChildItem $output -File | ForEach-Object { Write-Host ("  {0}  ({1:N1} MB)" -f $_.FullName, ($_.Length / 1MB)) }
Write-Host 'Give users both files; they run setup.exe.'
