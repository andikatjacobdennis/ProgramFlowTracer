<#
.SYNOPSIS
    Checks a built DocGen Explorer setup (DocGen.Explorer.Setup.msi) without installing it.

.DESCRIPTION
    Reads the MSI's tables and fails when the setup would not install, upgrade, repair or uninstall as intended:
    - the product code is the build's own (not the setup project's), the upgrade code is DocGen Explorer's;
    - earlier and same-version builds are removed, and only a higher installed version stops the setup;
    - the installed copy is removed before files are copied (RemoveExistingProducts right after InstallInitialize);
    - uninstalling (not upgrading) deletes the user's cache and speech audio, as the user, ignoring errors;
    - the program, its icon and the Mermaid files are installed; Start menu and desktop shortcuts point at the program,
      with the DocGen icon, and are not advertised.
    Run by the Release workflow after the setup is built; it can be run by hand on any built .msi.

.PARAMETER Msi
    The .msi to check. Default: installer\DocGen.Explorer.Setup\Release\DocGen.Explorer.Setup.msi.

.EXAMPLE
    .\Test-Setup.ps1
#>
param([string] $Msi)
$ErrorActionPreference = 'Stop'

$root = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
if (-not $Msi) { $Msi = Join-Path $root 'installer\DocGen.Explorer.Setup\Release\DocGen.Explorer.Setup.msi' }
$Msi = (Resolve-Path $Msi).Path
$project = [IO.File]::ReadAllText((Join-Path $root 'installer\DocGen.Explorer.Setup\DocGen.Explorer.Setup.vdproj'))
$projectCode = [regex]::Match($project, '"ProductCode" = "8:(\{[0-9A-F-]+\})"').Groups[1].Value
$upgradeCode = [regex]::Match($project, '"UpgradeCode" = "8:(\{[0-9A-F-]+\})"').Groups[1].Value

$installer = New-Object -ComObject WindowsInstaller.Installer
$db = $installer.OpenDatabase($Msi, 0)
function Rows([string] $sql, [int] $columns) {
    $view = $db.OpenView($sql)
    $null = $view.Execute()
    $rows = @()
    while ($record = $view.Fetch()) {
        $rows += , @(1..$columns | ForEach-Object { $record.StringData($_) })
    }
    $null = $view.Close()
    , $rows
}
function Property([string] $name) { $r = Rows "SELECT ``Value`` FROM ``Property`` WHERE ``Property`` = '$name'" 1; if ($r.Count) { $r[0][0] } else { $null } }
function StepOf([string] $action) { $r = Rows "SELECT ``Sequence`` FROM ``InstallExecuteSequence`` WHERE ``Action`` = '$action'" 1; if ($r.Count) { [int]$r[0][0] } else { -1 } }

$failures = @()
function Check([string] $name, [bool] $ok, [string] $detail = '') {
    if ($ok) { Write-Host "PASS  $name" } else { Write-Host "FAIL  $name $(if ($detail) { "($detail)" })"; $script:failures += $name }
}

$version = Property 'ProductVersion'
$productCode = Property 'ProductCode'
Check 'Product name, manufacturer and version' ((Property 'ProductName') -eq 'DocGen Explorer' -and (Property 'Manufacturer') -eq 'DocGen' -and $version -match '^\d+\.\d+\.\d+$') "$(Property 'ProductName'), $(Property 'Manufacturer'), $version"
Check 'The upgrade code is DocGen Explorer''s' ((Property 'UpgradeCode') -eq $upgradeCode) (Property 'UpgradeCode')
Check 'The build has a product code of its own' ($productCode -match '^\{[0-9A-F-]{36}\}$' -and $productCode -ne $projectCode) "$productCode (setup project $projectCode)"

$upgrade = Rows 'SELECT `UpgradeCode`, `VersionMin`, `VersionMax`, `Attributes`, `ActionProperty` FROM `Upgrade`' 5
$previous = @($upgrade | Where-Object { $_[4] -eq 'PREVIOUSVERSIONSINSTALLED' })
$newer = @($upgrade | Where-Object { $_[4] -eq 'NEWERPRODUCTFOUND' })
Check 'Earlier and same-version builds are removed (VersionMax inclusive)' ($previous.Count -eq 1 -and $previous[0][0] -eq $upgradeCode -and $previous[0][1] -eq '' -and $previous[0][2] -eq $version -and ([int]$previous[0][3] -band 512) -and -not ([int]$previous[0][3] -band 2)) (($previous | ForEach-Object { $_ -join ' | ' }) -join '; ')
Check 'Only a higher installed version stops the setup (detect only, VersionMin exclusive)' ($newer.Count -eq 1 -and $newer[0][1] -eq $version -and $newer[0][2] -eq '' -and [int]$newer[0][3] -eq 2) (($newer | ForEach-Object { $_ -join ' | ' }) -join '; ')
$cancel = Rows "SELECT ``Condition`` FROM ``InstallExecuteSequence`` WHERE ``Action`` = 'ERRCA_CANCELNEWERVERSION'" 1
Check 'A higher installed version is refused with a message' ($cancel.Count -eq 1 -and $cancel[0][0] -match 'NEWERPRODUCTFOUND' -and (Property 'VSDVERSIONMSG')) ($cancel | ForEach-Object { $_ -join '' })

$init = StepOf 'InstallInitialize'; $rep = StepOf 'RemoveExistingProducts'; $files = StepOf 'InstallFiles'
Check 'The installed copy is removed before files are copied' ($init -gt 0 -and $rep -gt $init -and $rep -lt (StepOf 'RemoveFiles') -and $rep -lt $files) "InstallInitialize $init, RemoveExistingProducts $rep, InstallFiles $files"

$actions = Rows 'SELECT `Action`, `Type`, `Source`, `Target` FROM `CustomAction`' 4
$cleanup = @($actions | Where-Object { $_[0] -eq 'DocGenRemoveCache' })
$data = @($actions | Where-Object { $_[0] -eq 'DocGenRemoveCacheData' })
Check 'Uninstall cleanup: deferred JScript, as the user, errors ignored' ($cleanup.Count -eq 1 -and [int]$cleanup[0][1] -eq (37 + 1024 + 64) -and $cleanup[0][3] -match 'DeleteFolder') ($cleanup | ForEach-Object { $_[1] })
Check 'Uninstall cleanup: the cache and the speech audio folders' ($data.Count -eq 1 -and [int]$data[0][1] -eq 51 -and $data[0][2] -eq 'DocGenRemoveCache' -and $data[0][3] -eq '[LocalAppDataFolder]DocGen.Explorer\cache|[TempFolder]DocGen.Explorer') ($data | ForEach-Object { $_[3] })
$steps = Rows "SELECT ``Action``, ``Condition``, ``Sequence`` FROM ``InstallExecuteSequence`` WHERE ``Action`` = 'DocGenRemoveCacheData' OR ``Action`` = 'DocGenRemoveCache'" 3
Check 'Uninstall cleanup runs on uninstall only, not on upgrade, after the files are removed' ($steps.Count -eq 2 -and @($steps | Where-Object { $_[1] -eq 'REMOVE~="ALL" AND NOT UPGRADINGPRODUCTCODE' -and [int]$_[2] -gt (StepOf 'RemoveFiles') -and [int]$_[2] -lt (StepOf 'InstallFiles') }).Count -eq 2) (($steps | ForEach-Object { $_ -join ' | ' }) -join '; ')

$installed = @((Rows 'SELECT `FileName` FROM `File`' 1) | ForEach-Object { ($_[0] -split '\|')[-1] } | Sort-Object)
Check 'Installed files: the program, its icon and the Mermaid files' (($installed -join ',') -eq 'DocGen.Explorer.exe,docgen.ico,LICENSE.txt,mermaid.min.js,render.html') ($installed -join ', ')
$shortcuts = Rows 'SELECT `Shortcut`, `Directory_`, `Target`, `Icon_` FROM `Shortcut`' 4
Check 'Two shortcuts (Start menu and desktop) with the DocGen icon' ($shortcuts.Count -eq 2 -and @($shortcuts | Where-Object { $_[3] -eq 'DocGen.ico' }).Count -eq 2) (($shortcuts | ForEach-Object { $_ -join ' | ' }) -join '; ')
Check 'Shortcuts point at the program, not advertised' ((Property 'DISABLEADVTSHORTCUTS') -eq '1')
Check 'Apps & features shows the DocGen icon' ((Property 'ARPPRODUCTICON') -eq 'DocGen.ico' -and (Rows "SELECT ``Name`` FROM ``Icon`` WHERE ``Name`` = 'DocGen.ico'" 1).Count -eq 1)
Check 'Installs for everyone by default, to Program Files\DocGen\DocGen Explorer' ((Property 'ALLUSERS') -eq '2' -and @($actions | Where-Object { $_[0] -eq 'DIRCA_TARGETDIR' -and $_[3] -eq '[ProgramFiles64Folder][Manufacturer]\[ProductName]' }).Count -eq 1)
Check 'The Repair/Remove page is in the setup' ((Rows "SELECT ``Dialog`` FROM ``Dialog`` WHERE ``Dialog`` = 'MaintenanceForm'" 1).Count -eq 1)

$null = [Runtime.InteropServices.Marshal]::ReleaseComObject($db)
$null = [Runtime.InteropServices.Marshal]::ReleaseComObject($installer)
[GC]::Collect()
[GC]::WaitForPendingFinalizers()
if ($failures.Count) { throw "$($failures.Count) setup check(s) failed: $($failures -join '; ')" }
Write-Host "The setup passed every check ($Msi)."
