<#
.SYNOPSIS
    Shows a DocGen Explorer settings file that is kept encrypted on this PC (for support).

.DESCRIPTION
    settings\ai.json (providers, models, API keys) and settings\confluence.json (sites, tokens) are encrypted with
    Windows DPAPI for the Windows user who ran DocGen Explorer: only that user, on that computer, can read them. Run
    this as that user. It prints the JSON, or writes it to -OutFile (which then holds keys in plain text: delete it).

.EXAMPLE
    .\Unprotect-SettingsFile.ps1 $env:LOCALAPPDATA\DocGen.Explorer\desktop\settings\confluence.json
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory, Position = 0)] [string] $Path,
    [string] $OutFile
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Security

$text = [IO.File]::ReadAllText([IO.Path]::GetFullPath($Path))
try { $envelope = $text | ConvertFrom-Json } catch { throw "$Path is not JSON." }
if ($envelope.format -ne 'docgen-protected-json') {
    Write-Warning "$Path is not encrypted (DocGen Explorer encrypts it the next time it reads it)."
    $json = $text
} else {
    $entropy = (New-Object Text.UTF8Encoding $false).GetBytes('DocGen.Explorer/settings/v1')
    try {
        $plain = [Security.Cryptography.ProtectedData]::Unprotect([Convert]::FromBase64String($envelope.data), $entropy, [Security.Cryptography.DataProtectionScope]::CurrentUser)
    } catch {
        throw 'This file was encrypted for another Windows user or computer and cannot be read here.'
    }
    $json = (New-Object Text.UTF8Encoding $false).GetString($plain)
}
if ($OutFile) {
    [IO.File]::WriteAllText([IO.Path]::GetFullPath($OutFile), $json, (New-Object Text.UTF8Encoding $false))
    Write-Host "Written to $OutFile. It holds keys in plain text: delete it when you are done."
} else {
    $json
}
