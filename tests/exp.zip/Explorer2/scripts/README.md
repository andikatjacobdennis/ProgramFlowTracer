# Scripts

PowerShell and batch scripts for preparing and supporting DocGen Explorer. They run in Windows PowerShell 5.1 (built
into Windows) and PowerShell 7. The `.cmd` files run the scripts beside them without changing the execution policy —
double-click one, or pass the same arguments as the script.

| Script | What it does |
|---|---|
| `providers\New-ProvidersKey.ps1` (`New-ProvidersKey.cmd`) | Creates the team key, `secrets\providers.key` (32 random bytes, base64). `secrets\` is not in git. Refuses to replace an existing key unless `-Force` (files encrypted with the old key can then no longer be read); `-KeyFile` writes elsewhere. |
| `providers\Protect-ProvidersFile.ps1` (`Encrypt-Providers.cmd`) | Encrypts a providers file (`.json`) to `.enc` with the team key. Only encrypted files can be imported. `-OutFile` and `-KeyFile` choose other paths. |
| `providers\Unprotect-ProvidersFile.ps1` (`Decrypt-Providers.cmd`) | Decrypts a `.enc` providers file back to `.json`, to read or change it. `-OutFile` and `-KeyFile` choose other paths. |
| `settings\Unprotect-SettingsFile.ps1` (`Show-Settings.cmd`) | Shows `settings\ai.json` or `settings\confluence.json`, which the app keeps encrypted for the Windows user. |
| `installer\Build-Setup.ps1` (`Build-Setup.cmd`) | Builds the setup (`setup.exe` and `DocGen.Explorer.Setup.msi`) with Visual Studio; `-Version 1.1.0` makes a new version that upgrades the installed one. See the README, *Setup for users*. |
| `installer\Test-Setup.ps1` | Checks a built `.msi` without installing it: its own product code, the upgrade and newer-version rules, removal of the installed copy before files are copied, the uninstall cleanup, the installed files and shortcuts. Build-Setup runs it after every build. |

## Providers files

DocGen Explorer imports **only encrypted providers files** (Settings → Providers and models → **Import from file…**),
so users can use only the providers a team gives them.

1. Once: `New-ProvidersKey.cmd` creates `secrets\providers.key`. Share it only with the people who build the app or
   prepare providers files — a file encrypted with one key cannot be imported by a build made with another.
2. Build DocGen Explorer: the key in `secrets\providers.key` is built into the app (without it, the app cannot import).
3. Copy `providers\ai-providers.release.json` to a name of your own (for example
   `providers\ai-providers.release.local.json` — ignored by git), fill in the keys, and encrypt it from the repository
   root (paths are relative to the folder you run it in):
   `scripts\Encrypt-Providers.cmd providers\ai-providers.release.local.json`
4. Give users the `.enc` file. To change it later, `Decrypt-Providers.cmd` it, edit, encrypt again, and delete the
   plain copy.

Format (`EncryptedJson` in the engine; `providers\ProvidersCrypto.ps1` here): AES-256-CBC with an HMAC-SHA256 over the
header, IV and ciphertext (encrypt-then-MAC), with separate encryption and MAC keys derived from the team key. A file
that was changed, or encrypted with another key, is refused.

## Settings on this PC

The app keeps `settings\ai.json` (providers, models, API keys) and `settings\confluence.json` (sites, tokens) encrypted
with Windows DPAPI for the current Windows user: another user, or another computer, cannot read them. Files from earlier
versions are encrypted the first time the app reads them, and their plain backups are removed.
