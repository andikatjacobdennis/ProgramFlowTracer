@echo off
rem Runs settings\Unprotect-SettingsFile.ps1 with Windows PowerShell (no execution-policy change needed). Arguments are passed on.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0settings\Unprotect-SettingsFile.ps1" %*
if errorlevel 1 pause
