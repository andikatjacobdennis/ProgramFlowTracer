@echo off
rem Runs providers\New-ProvidersKey.ps1 with Windows PowerShell (no execution-policy change needed). Arguments are passed on.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0providers\New-ProvidersKey.ps1" %*
if errorlevel 1 pause
