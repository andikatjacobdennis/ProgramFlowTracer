<#
.SYNOPSIS
    Encrypts a providers file so DocGen Explorer can import it.

.DESCRIPTION
    DocGen Explorer imports only encrypted providers files (Settings -> Providers and models -> Import from file...).
    This reads a plain providers file (JSON: providers, their models and keys), checks it is valid JSON with at least one
    provider, and writes it encrypted with the team key (secrets\providers.key, or -KeyFile) to <name>.enc beside it,
    or to -OutFile. Give users the .enc file; keep the plain file, which may hold API keys, to yourself.

.EXAMPLE
    .\Protect-ProvidersFile.ps1 ..\..\providers\ai-providers.release.local.json
.EXAMPLE
    .\Protect-ProvidersFile.ps1 -Path providers.json -OutFile \\share\docgen\ai-providers.enc
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory, Position = 0)] [string] $Path,
    [string] $OutFile,
    # Default: secrets\providers.key at the root of the solution.
    [string] $KeyFile
)
$ErrorActionPreference = 'Stop'
# (Windows PowerShell 5.1 has no $PSScriptRoot while it reads the parameters: the default is worked out here.)
if (-not $KeyFile) { $KeyFile = Join-Path $PSScriptRoot '..\..\secrets\providers.key' }
. (Join-Path $PSScriptRoot 'ProvidersCrypto.ps1')

$Path = [IO.Path]::GetFullPath($Path)
$json = [IO.File]::ReadAllText($Path)
try { $parsed = $json | ConvertFrom-Json } catch { throw "$Path is not valid JSON: $($_.Exception.Message)" }
if (-not $parsed.providers -or @($parsed.providers).Count -eq 0) { throw "$Path lists no providers (expected { ""providers"": [ ... ] })." }
$missingKeys = @($parsed.providers | Where-Object { $_.kind -ne 'simulator' -and -not $_.apiKey -and $_.baseUrl -notmatch '^https?://(127\.0\.0\.1|localhost)' } | ForEach-Object { $_.name })

if (-not $OutFile) { $OutFile = [IO.Path]::ChangeExtension($Path, '.enc') }
$key = Read-ProvidersKey $KeyFile
Write-Utf8 $OutFile (Protect-Json $json $key)

Write-Host "Encrypted $(@($parsed.providers).Count) provider(s) to $([IO.Path]::GetFullPath($OutFile)) (key id $(Get-KeyId $key))."
if ($missingKeys.Count -gt 0) { Write-Warning "No API key in the file for: $($missingKeys -join ', '). Users will have to paste one." }
