<#
    Shared by Protect-ProvidersFile.ps1 and Unprotect-ProvidersFile.ps1 (dot-sourced). The format matches
    src\Engine\DocGen.Explorer.Engine\Storage\EncryptedJson.cs:
        AES-256-CBC (PKCS7) with an HMAC-SHA256 over "docgen-encrypted-json/1" + IV + ciphertext (encrypt-then-MAC);
        the encryption and MAC keys are HMAC-SHA256(teamKey, "docgen/providers/encrypt" | "docgen/providers/mac").
    Works in Windows PowerShell 5.1 and PowerShell 7.
#>

$script:Format = 'docgen-encrypted-json'
$script:Version = 1
$script:Cipher = 'AES-256-CBC+HMAC-SHA256'

function Read-ProvidersKey([string] $KeyFile) {
    $KeyFile = [IO.Path]::GetFullPath($KeyFile)
    if (-not (Test-Path $KeyFile)) {
        throw "No providers key at $KeyFile. Create one with New-ProvidersKey.ps1, or put the team's key there."
    }
    try { $key = [Convert]::FromBase64String(([IO.File]::ReadAllText($KeyFile)).Trim()) }
    catch { throw "The providers key at $KeyFile is not base64." }
    if ($key.Length -ne 32) { throw "The providers key at $KeyFile must be 32 bytes." }
    return ,$key
}

function Get-Hmac([byte[]] $Key, [byte[]] $Data) {
    $hmac = New-Object Security.Cryptography.HMACSHA256 -ArgumentList (,$Key)
    try { return ,$hmac.ComputeHash($Data) } finally { $hmac.Dispose() }
}

function Get-DerivedKeys([byte[]] $Key) {
    $utf8 = New-Object Text.UTF8Encoding $false
    return @{
        Encrypt = Get-Hmac $Key $utf8.GetBytes('docgen/providers/encrypt')
        Mac     = Get-Hmac $Key $utf8.GetBytes('docgen/providers/mac')
    }
}

function Get-KeyId([byte[]] $Key) {
    $sha = [Security.Cryptography.SHA256]::Create()
    try { return (-join ($sha.ComputeHash($Key) | ForEach-Object { $_.ToString('x2') })).Substring(0, 16) } finally { $sha.Dispose() }
}

function Get-MacInput([byte[]] $Iv, [byte[]] $Data) {
    $header = (New-Object Text.UTF8Encoding $false).GetBytes("$script:Format/$script:Version")
    $all = New-Object byte[] ($header.Length + $Iv.Length + $Data.Length)
    [Array]::Copy($header, 0, $all, 0, $header.Length)
    [Array]::Copy($Iv, 0, $all, $header.Length, $Iv.Length)
    [Array]::Copy($Data, 0, $all, $header.Length + $Iv.Length, $Data.Length)
    return ,$all
}

function New-Aes([byte[]] $Key) {
    $aes = [Security.Cryptography.Aes]::Create()
    $aes.Mode = [Security.Cryptography.CipherMode]::CBC
    $aes.Padding = [Security.Cryptography.PaddingMode]::PKCS7
    $aes.Key = $Key
    return $aes
}

function Protect-Json([string] $Json, [byte[]] $Key) {
    $keys = Get-DerivedKeys $Key
    $aes = New-Aes $keys.Encrypt
    try {
        $aes.GenerateIV()
        $plain = (New-Object Text.UTF8Encoding $false).GetBytes($Json)
        $encryptor = $aes.CreateEncryptor()
        try { $data = $encryptor.TransformFinalBlock($plain, 0, $plain.Length) } finally { $encryptor.Dispose() }
        $iv = $aes.IV
    } finally { $aes.Dispose() }
    $mac = Get-Hmac $keys.Mac (Get-MacInput $iv $data)
    $envelope = [ordered]@{
        format  = $script:Format
        version = $script:Version
        cipher  = $script:Cipher
        keyId   = Get-KeyId $Key
        iv      = [Convert]::ToBase64String($iv)
        data    = [Convert]::ToBase64String($data)
        mac     = [Convert]::ToBase64String($mac)
    }
    return ($envelope | ConvertTo-Json)
}

function Unprotect-Json([string] $Text, [byte[]] $Key) {
    try { $envelope = $Text | ConvertFrom-Json } catch { throw 'This is not an encrypted providers file (it is not JSON).' }
    if ($envelope.format -ne $script:Format) { throw 'This is not an encrypted providers file.' }
    if ($envelope.version -ne $script:Version -or $envelope.cipher -ne $script:Cipher) { throw 'This file was encrypted in another format or by a newer version.' }
    if ($envelope.keyId -and $envelope.keyId -ne (Get-KeyId $Key)) { throw "This file was encrypted with another key (key id $($envelope.keyId))." }
    try {
        $iv = [Convert]::FromBase64String($envelope.iv)
        $data = [Convert]::FromBase64String($envelope.data)
        $mac = [Convert]::FromBase64String($envelope.mac)
    } catch { throw 'The encrypted file is damaged.' }
    $keys = Get-DerivedKeys $Key
    $expected = Get-Hmac $keys.Mac (Get-MacInput $iv $data)
    $difference = $mac.Length -bxor $expected.Length
    for ($i = 0; $i -lt [Math]::Min($mac.Length, $expected.Length); $i++) { $difference = $difference -bor ($mac[$i] -bxor $expected[$i]) }
    if ($difference -ne 0 -or $iv.Length -ne 16) { throw 'The encrypted file was changed after it was encrypted, or it was encrypted with another key.' }
    $aes = New-Aes $keys.Encrypt
    try {
        $aes.IV = $iv
        $decryptor = $aes.CreateDecryptor()
        try { $plain = $decryptor.TransformFinalBlock($data, 0, $data.Length) } finally { $decryptor.Dispose() }
    } finally { $aes.Dispose() }
    return (New-Object Text.UTF8Encoding $false).GetString($plain)
}

function Write-Utf8([string] $Path, [string] $Text) {
    [IO.File]::WriteAllText([IO.Path]::GetFullPath($Path), $Text, (New-Object Text.UTF8Encoding $false))
}
