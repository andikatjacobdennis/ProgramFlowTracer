<#
.SYNOPSIS
    Decrypts an encrypted providers file, to read or change it.

.DESCRIPTION
    Reads a file written by Protect-ProvidersFile.ps1 (or anything in the same format), checks it was not changed and
    was encrypted with the team key (secrets\providers.key, or -KeyFile), and writes the plain JSON to -OutFile, or to
    <name>.json beside it. The plain file may hold API keys: delete it when you are done (.gitignore keeps providers
    files other than the release file out of git).

.EXAMPLE
    .\Unprotect-ProvidersFile.ps1 ai-providers.enc
.EXAMPLE
    .\Unprotect-ProvidersFile.ps1 -Path ai-providers.enc -OutFile ai-providers.json
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory, Position = 0)] [string] $Path,
    [string] $OutFile,
    # Default: secrets\providers.key at the root of the solution.
    [string] $KeyFile
)
$ErrorActionPreference = 'Stop'
# (Windows PowerShell 5.1 has no $PSScriptRoot while it reads the parameters: the default is worked out here.)
if (-not $KeyFile) { $KeyFile = Join-Path $PSScriptRoot '..\..\secrets\providers.key' }
. (Join-Path $PSScriptRoot 'ProvidersCrypto.ps1')

$Path = [IO.Path]::GetFullPath($Path)
$key = Read-ProvidersKey $KeyFile
$json = Unprotect-Json ([IO.File]::ReadAllText($Path)) $key

if (-not $OutFile) { $OutFile = [IO.Path]::ChangeExtension($Path, '.json') }
if ([IO.Path]::GetFullPath($OutFile) -eq $Path) { throw 'Choose an -OutFile other than the encrypted file.' }
Write-Utf8 $OutFile $json
Write-Host "Decrypted to $([IO.Path]::GetFullPath($OutFile)). It may hold API keys: delete it when you are done."
