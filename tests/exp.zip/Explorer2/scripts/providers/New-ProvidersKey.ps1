<#
.SYNOPSIS
    Creates the team key that providers files are encrypted with.

.DESCRIPTION
    Writes 32 random bytes, as base64, to secrets\providers.key (or -KeyFile). The key is built into DocGen Explorer
    when the app is built, and Protect-ProvidersFile.ps1 / Unprotect-ProvidersFile.ps1 use it. Keep it out of git
    (.gitignore ignores secrets\) and share it only with the people who build the app or prepare providers files.
    A file encrypted with one key cannot be imported by a build made with another.

.EXAMPLE
    .\New-ProvidersKey.ps1
.EXAMPLE
    .\New-ProvidersKey.ps1 -KeyFile D:\keys\providers.key -Force
#>
[CmdletBinding()]
param(
    # Default: secrets\providers.key at the root of the solution.
    [string] $KeyFile,
    # Replaces an existing key. Files encrypted with the old key can then no longer be read.
    [switch] $Force
)
$ErrorActionPreference = 'Stop'
# (Windows PowerShell 5.1 has no $PSScriptRoot while it reads the parameters: the default is worked out here.)
if (-not $KeyFile) { $KeyFile = Join-Path $PSScriptRoot '..\..\secrets\providers.key' }

$KeyFile = [IO.Path]::GetFullPath($KeyFile)
if ((Test-Path $KeyFile) -and -not $Force) {
    throw "A key already exists at $KeyFile. Use -Force to replace it (files encrypted with the old key can then no longer be read)."
}
$folder = Split-Path $KeyFile -Parent
if (-not (Test-Path $folder)) { New-Item -ItemType Directory -Path $folder | Out-Null }

$key = New-Object byte[] 32
$random = [Security.Cryptography.RandomNumberGenerator]::Create()
try { $random.GetBytes($key) } finally { $random.Dispose() }
[IO.File]::WriteAllText($KeyFile, [Convert]::ToBase64String($key), (New-Object Text.UTF8Encoding $false))

$sha = [Security.Cryptography.SHA256]::Create()
try { $id = (-join ($sha.ComputeHash($key) | ForEach-Object { $_.ToString('x2') })).Substring(0, 16) } finally { $sha.Dispose() }
Write-Host "Providers key written to $KeyFile (key id $id)."
Write-Host "Rebuild DocGen Explorer so the app carries this key."
