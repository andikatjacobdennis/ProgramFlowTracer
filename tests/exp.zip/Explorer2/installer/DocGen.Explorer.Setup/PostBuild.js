// Runs after Visual Studio builds DocGen.Explorer.Setup.msi (the setup project's PostBuildEvent):
//   cscript //nologo PostBuild.js <the .msi> <docgen.ico>
//
// Visual Studio stores a shortcut's .ico in the MSI's Icon table under a name ending in .exe; Windows then reads it as a
// program, finds no icon in it, and the Start menu and desktop shortcuts show a blank one. This stores docgen.ico once
// as "DocGen.ico" and points the shortcuts and Apps & features at it.
//
// It also makes the shortcuts ordinary ones (DISABLEADVTSHORTCUTS): they point at DocGen.Explorer.exe itself, so they
// can be pinned to the taskbar, and starting the app never triggers a Windows Installer repair.
//
// Installing, upgrading, repairing and uninstalling:
// - Every build gets its own product code. Running the same setup again offers Repair and Remove; a different build —
//   a higher version, or the same version built again — replaces the installed one. (With one product code per version,
//   a rebuilt setup was refused: "another version of this product is already installed".)
// - Earlier and same-version builds are removed (Upgrade table, VersionMax inclusive); only a higher installed version
//   stops the setup. Visual Studio counted the same version as newer.
// - The installed copy is removed before the new files are copied (RemoveExistingProducts right after
//   InstallInitialize), so a rebuilt program of the same file version replaces the old one instead of being skipped.
// - Uninstalling (not upgrading) deletes, for the Windows user who uninstalls, what the program unpacked for itself:
//   %LOCALAPPDATA%\DocGen.Explorer\cache and %TEMP%\DocGen.Explorer. Settings, data folders and Whisper models stay.
var msiPath = WScript.Arguments(0);
var iconPath = WScript.Arguments(1);
var IconName = "DocGen.ico";

var installer = new ActiveXObject("WindowsInstaller.Installer");
var db = installer.OpenDatabase(msiPath, 1 /* msiOpenDatabaseModeTransact */);

function run(sql, record) {
    try {
        var view = db.OpenView(sql);
        view.Execute(record || null);
        view.Close();
    } catch (e) {
        // Exit code 1 fails the build (Build-Setup.ps1 checks it too).
        WScript.Echo("PostBuild.js: error: " + (e.message || e.description) + " in: " + sql);
        WScript.Quit(1);
    }
}

run("DELETE FROM `Icon`");
var icon = installer.CreateRecord(2);
icon.StringData(1) = IconName;
icon.SetStream(2, iconPath);
run("INSERT INTO `Icon` (`Name`, `Data`) VALUES (?, ?)", icon);

run("UPDATE `Shortcut` SET `Icon_` = '" + IconName + "', `IconIndex` = 0");
run("UPDATE `Property` SET `Value` = '" + IconName + "' WHERE `Property` = 'ARPPRODUCTICON'");
run("INSERT INTO `Property` (`Property`, `Value`) VALUES ('DISABLEADVTSHORTCUTS', '1')");

function property(name) {
    var view = db.OpenView("SELECT `Value` FROM `Property` WHERE `Property` = '" + name + "'");
    view.Execute();
    var record = view.Fetch();
    view.Close();
    if (record == null) {
        throw new Error("PostBuild.js: the MSI has no " + name + " property.");
    }
    return record.StringData(1);
}

// A product code of its own for this build.
var productCode = new ActiveXObject("Scriptlet.TypeLib").GUID.substr(0, 38).toUpperCase();
run("UPDATE `Property` SET `Value` = '" + productCode + "' WHERE `Property` = 'ProductCode'");

// Remove earlier and same-version builds (2 = msidbUpgradeAttributesOnlyDetect, 512 = ...VersionMaxInclusive); stop
// only for a higher version (min exclusive). The versions and attributes are the table's key, so the rows are replaced.
var version = property("ProductVersion");
var upgradeCode = property("UpgradeCode");
run("DELETE FROM `Upgrade`");
function upgrade(min, max, attributes, actionProperty) {
    var row = installer.CreateRecord(5);
    row.StringData(1) = upgradeCode;
    row.StringData(2) = min;
    row.StringData(3) = max;
    row.IntegerData(4) = attributes;
    row.StringData(5) = actionProperty;
    run("INSERT INTO `Upgrade` (`UpgradeCode`, `VersionMin`, `VersionMax`, `Attributes`, `ActionProperty`) VALUES (?, ?, ?, ?, ?)", row);
}
upgrade("", version, 512, "PREVIOUSVERSIONSINSTALLED");
upgrade(version, "", 2, "NEWERPRODUCTFOUND");

// The installed copy goes first, then the new files are copied.
run("UPDATE `InstallExecuteSequence` SET `Sequence` = 1525 WHERE `Action` = 'RemoveExistingProducts'");

// Uninstall: the user's unpacked cache and speech audio. Deferred, as the user (not the system account), its errors
// ignored (1024 = msidbCustomActionTypeInScript, 64 = ...Continue; 37 = JScript in the Target column, 51 = set a
// property: the deferred action reads its folders from CustomActionData).
var onUninstall = "REMOVE~=\"ALL\" AND NOT UPGRADINGPRODUCTCODE";
// Each folder on its own, and what happened is written to the setup log (msiexec /l*v).
var script =
    "function log(t){var r=Session.Installer.CreateRecord(0);r.StringData(0)=\"DocGenRemoveCache: \"+t;Session.Message(0x04000000,r);}" +
    "var f=new ActiveXObject(\"Scripting.FileSystemObject\"),d=Session.Property(\"CustomActionData\").split(\"|\"),p;" +
    "while(d.length){p=d.shift();if(!p)continue;" +
    "try{if(f.FolderExists(p)){f.DeleteFolder(p,true);log(\"removed \"+p);}else log(\"not there: \"+p);}" +
    "catch(e){log(\"could not remove \"+p+\": \"+e.message);}}";
var action = installer.CreateRecord(4);
action.StringData(1) = "DocGenRemoveCache";
action.IntegerData(2) = 37 + 1024 + 64;
action.StringData(3) = "";
action.StringData(4) = script;
run("INSERT INTO `CustomAction` (`Action`, `Type`, `Source`, `Target`) VALUES (?, ?, ?, ?)", action);
var data = installer.CreateRecord(4);
data.StringData(1) = "DocGenRemoveCacheData";
data.IntegerData(2) = 51;
data.StringData(3) = "DocGenRemoveCache";
data.StringData(4) = "[LocalAppDataFolder]DocGen.Explorer\\cache|[TempFolder]DocGen.Explorer";
run("INSERT INTO `CustomAction` (`Action`, `Type`, `Source`, `Target`) VALUES (?, ?, ?, ?)", data);
var step = installer.CreateRecord(3);
step.StringData(1) = "DocGenRemoveCacheData";
step.StringData(2) = onUninstall;
step.IntegerData(3) = 3540;
run("INSERT INTO `InstallExecuteSequence` (`Action`, `Condition`, `Sequence`) VALUES (?, ?, ?)", step);
step.StringData(1) = "DocGenRemoveCache";
step.IntegerData(3) = 3550;
run("INSERT INTO `InstallExecuteSequence` (`Action`, `Condition`, `Sequence`) VALUES (?, ?, ?)", step);

db.Commit();
WScript.Echo("PostBuild.js: shortcuts and Apps & features use " + IconName + "; shortcuts point at the program.");
WScript.Echo("PostBuild.js: product code " + productCode + "; replaces earlier and same-version builds; uninstalling removes the cache.");
