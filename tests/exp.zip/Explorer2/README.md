# DocGen Explorer

A Windows application for reading a code repository. It indexes a folder or a Git repository, shows its documentation
and files, draws a knowledge graph of what references what, generates study material, makes spoken conversations about
it, and answers questions grounded in its own evidence.

DocGen Explorer is a WPF (.NET 10) application built on the **DocGen platform** (`src/Platform`): a C# lexer and
declaration parser, an incremental code index, JSON storage and a model-provider layer.

## Contents

1. [Features](#features)
2. [Getting started](#getting-started)
3. [Solution layout](#solution-layout)
4. [Configuration](#configuration)
5. [How it works](#how-it-works)
6. [Data and usage](#data-and-usage)
7. [Setup for users](#setup-for-users)
8. [Branches, CI and releases](#branches-ci-and-releases)
9. [Look and feel](#look-and-feel)
10. [Security and privacy](#security-and-privacy)
11. [License](#license)

## Features

| Page | What it does |
|---|---|
| **Repositories** | Add a local folder, clone a Git repository (GitHub, Azure DevOps, any HTTPS/SSH remote), or create a new empty folder (optionally with `git init`) and open it; change a clone's branch. |
| **Documentation** | The repository's Markdown, plus generated Overview, Architecture, API and Operations pages. **Find** (Ctrl+F) marks every match in yellow, the current one in orange, with match case, whole word, regular expressions and Find all. Files and folders can be added, renamed, deleted (to the Recycle Bin) and **edited** with an Edit / Preview tab, as on GitHub; pointing at a file shows its details (size, dates, lines, encoding). Code can be selected (drag, double-click a word, triple-click a line) and copied, and is coloured for C#, shell, PowerShell, batch, CSS, Dockerfiles, Makefiles and more; a C# file with classes toggles to its **class diagram**, and a Markdown file to its rendered **Preview**. A **Changes** tab lists what changed since the last commit (staged and unstaged, as a folder tree with M/A/D/R/U) and opens each file's diff side by side or inline — selectable, copyable, editable in place with the comparison following as you type, with Undo changes — and compares two branches, as Visual Studio's Git Changes does. |
| **Graph** | A knowledge graph of projects, namespaces, types, files and docs, with scoping and automatic grouping. |
| **Indexing** | Progress of the nine-stage indexing pipeline; Confluence spaces to index with the repository. |
| **Ask** | The assistant, beside the documentation: answers from cited evidence, with a chat model or offline (evidence mode). Attach files and images to a question, dictate it (Whisper on this PC, or Windows' speech recognition), have answers read aloud with the word being said highlighted, summarise a selection or a diagram, and download an answer. Pasted pictures, files and long or structured text (JSON, XML, logs) become square attachment cards with their name, size and a preview; spelling mistakes are underlined and a click offers corrections; the magnifier searches the conversation (or earlier ones) with the words in yellow; while an answer is written the thread can be scrolled up to read. A rail at the right edge has a bar per question; pointing at it lists the questions, and choosing one scrolls to it. Architecture diagrams of a C# solution are drawn in layers. With the Test Fix skill turned on, **🧪** reproduces failing tests, fixes the cause in the local files and verifies it with the repository's own runner (see [Test Fix](#test-fix)). |
| **Learning** | Quizzes, spaced-repetition flashcards, learning paths, FAQ and a knowledge record. |
| **Studio** | Two to four personas discussing the repository, voiced and animated; saved as audio and Markdown. |
| **Personas** | Add, edit and remove the Studio personas (100 cartoon faces, eleven emotions). |
| **Talk** | A friendly persona conversation about the repository (Friendly Guide, Patient Teacher, Practical Developer, Code Detective, Product Companion): same grounded evidence as Ask, a different way of explaining; greetings, voice, its own conversations per repository. |
| **Token usage** | Every model call with tokens, cost and purpose; charts, a searchable, filterable, sortable table of calls, and CSV/JSON export. |
| **Logs** | The log of the explorer and its engine, newest first: search, a filter per column, levels, a time range (quick or from / to a date and time), columns to show or hide, sorting, pages and auto refresh. |
| **Settings** | Appearance, shortcuts, reading and writing (wheel scrolling, spelling, pasting, Find, file editing, file details, log refresh), voice and microphone, attachments, chat model, providers and models, skills, Confluence, prices, data and storage, factory reset. |
| **Help** | A help centre: search, topic cards, popular articles, and short task articles with mockups of the screens (small SVG, drawn by the app). Ask it a question ("where do I add a Confluence space to a repository?"): an answer card says where it is and how to do it, step by step, with links that go there — a page, a Settings page or an article. See [Help](#help). |

### Meet the personas

Five personas explain the repository in Talk, and each guides a topic of Help with a tip of their own. Studio
conversations and Learning's quiz host use the Studio personas instead (Personas page; four starters to begin with):

| Persona | Explains | Guides in Help |
|---|---|---|
| **Friendly Guide** | in everyday language, for anyone | Get started; Voice and microphone |
| **Patient Teacher** | step by step, new words explained | Repositories and indexing; Learning |
| **Practical Developer** | how it works and where to change it | Documentation and search; Diagrams; Keyboard |
| **Code Detective** | symptoms, likely causes, evidence, fixes | Ask the assistant; Attachments |
| **Product Companion** | user journeys and why features exist | Settings, AI and data |

A persona changes the tone, never the facts: every answer comes from the repository and cites it.

## Getting started

### Requirements

- Windows 10 (version 2004 or later) or Windows 11, 64-bit
- .NET 10 SDK (to build)
- Git on `PATH` (to clone repositories)
- Visual Studio with the **Microsoft Visual Studio Installer Projects** extension (only to build the setup)

### Build, run and test

```bash
dotnet build DocGen.Explorer.sln
```

```bash
dotnet run --project src/App/DocGen.Explorer
```

```bash
dotnet test DocGen.Explorer.sln
```

Always build the whole solution: `dotnet test` alone builds only the projects the tests reference, not the WPF app.

### Command-line options

| Option | Meaning |
|---|---|
| `--data <folder>` (or `-d`) | Use another data folder (default `%LOCALAPPDATA%\DocGen.Explorer\desktop`, or `DOCGEN_EXPLORER_DATA`). |
| `--uitest <folder> --add <sample repository>` | Walks every UI path by pressing the real buttons, menus, tabs and links (UI Automation): no repositories, a fresh one, an unindexed one, one whose folder was deleted, a narrow window. Checks each page loads without errors, every menu and dialog closes, and the header always leads back. Writes `ui-paths.md` and a screenshot per step; the exit code is the number of failures. Refuses a data folder that holds repositories, so give an empty scratch folder with `--data`. |
| `--add <path> --capture <folder> [--theme light\|dark]` | Registers and indexes a repository, saves a screenshot of every screen as PNG, and exits (for visual checks and documentation). |
| `--guide <folder> [--add <path>] [--providers <file>]` | Captures the end-user setup guide's screenshots (first start, providers before and after importing, Confluence, indexing, data and storage) with example values, and exits. Give an empty scratch folder with `--data`. |
| `--layout <folder> --add <path>` | Saves screenshots of the main layouts for checking spacing, and exits. |

## Solution layout

The folders on disk and the solution in Visual Studio have the same shape, grouped by layer. Each layer only references
the ones below it.

```
DocGen.Explorer.sln
├── src
│   ├── App
│   │   └── DocGen.Explorer              the WPF application (startup project)
│   ├── Engine
│   │   └── DocGen.Explorer.Engine       the explorer's engine
│   └── Platform
│       ├── Analysis
│       │   └── DocGen.Analysis          C# parser, code index, architecture tracer
│       ├── Services
│       │   ├── DocGen.Data              JSON store, settings
│       │   ├── DocGen.Providers         model providers (HTTP adapters, offline simulator)
│       │   ├── DocGen.Tools
│       │   └── DocGen.Network
│       └── Foundation
│           ├── DocGen.Core              models, abstractions, options, JSON
│           └── DocGen.Security
├── tests
│   └── DocGen.Explorer.Tests
├── installer
│   └── DocGen.Explorer.Setup            the setup (Visual Studio Installer Projects, .vdproj)
├── providers                            the team's providers files (only the release file is in git)
├── scripts                              build, encryption and support scripts
├── .github/workflows                    CI and Release pipelines
├── Directory.Build.props                version, company, shared build settings
└── LICENSE
```

| Project | What it is |
|---|---|
| `src/Platform/*/DocGen.*` | The platform: Core (models, abstractions), Security, Network, Data (JSON store, settings), Tools, Providers, Analysis (C# parser, code index, project parser, architecture tracer). |
| `src/Engine/DocGen.Explorer.Engine` | The explorer's engine: repositories, the indexing pipeline, documentation, chunking, embeddings, search, graph, assistant, learning, Studio, usage, exports, Confluence. |
| `src/App/DocGen.Explorer` | The WPF application (MVVM, no third-party UI packages). Uses Microsoft Edge's natural voices (online) or `System.Speech` for voice, Whisper.net for local dictation, and WebView2 with mermaid.js (MIT, bundled in `Assets/mermaid`) to draw Mermaid diagrams. |
| `tests/DocGen.Explorer.Tests` | MSTest tests over the engine, run against a generated sample repository. |

## Configuration

Everything is configured in the app's **Settings**. No environment variables are read for credentials.

### Chat models and providers

A new installation has **no providers** and runs entirely offline (evidence mode). Providers and models come **only
from an encrypted providers file** (`.enc`), imported in Settings → Providers and models → **Import from file…**. Only
the providers that file lists can be used.

- **Who makes the file:** your team. The build and the setup carry no providers. See
  [Encrypting the providers file](#encrypting-the-providers-file) below.
- **In the source tree:** `providers/` holds the team's files. Only
  [`ai-providers.release.json`](providers/ai-providers.release.json) (an example provider and Ollama, with empty `apiKey`s — a template for your own) is
  in git. `.gitignore` keeps every other providers file on the machine that has it, such as the development file or a
  copy with real keys.
- **What the file holds:** each provider's `id`, `name`, `kind` (`chat-completions`, `messages` or `simulator`),
  `baseUrl`, `endpoint`, `apiKey`, key header and prefix, extra headers, timeout and `models` (`id`, `providerModelId`,
  `displayName`, `contextWindow`, `maxOutputTokens`, and `supportsImages` for a model that can view attached images),
  and optionally a `defaultModel`.
- **Discovered models:** a provider with `"discoverModels": true` (Ollama) needs no `models`. The explorer asks the
  server itself (`GET <baseUrl>/api/tags`) at start, when Settings opens, after an import and with **Find models**. It
  leaves out models that cannot chat, keeps models you turned off, and keeps the last list when the server is
  unreachable.
- **Importing** checks the whole file and replaces the list. A provider listed without a key keeps the key already
  saved for it.
- **Editing after import:** only the API key, whether a provider or model is on, and removing a provider. The engine
  refuses any other change.
- **Storage:** `settings/ai.json`, encrypted with Windows DPAPI for the current user. The provider layer sends the key
  in the provider's auth header.

Each answer shows *Working through this*: the assistant's steps and, for reasoning models, the model's own reasoning
(`reasoning_content` streams and `<think>` blocks), live while it answers and saved with the conversation. An answer
that reaches the model's output limit is continued automatically (up to three times) from exactly where it stopped.

### Encrypting the providers file

`scripts\Encrypt-Providers.cmd` encrypts a providers file (`.json`) with the team key and writes a `.enc` file next to
it. Users import the `.enc` file.

**1. Once only, if `secrets\providers.key` doesn't exist yet:** create the team key.

```bash
scripts\New-ProvidersKey.cmd
```

Every setup you build includes the key from `secrets\providers.key`, and a file only imports into a build made with the
same key. Once a setup has been shared, don't create a new key: that setup could not import files encrypted with it.

**2. Make your own copy of the providers file** and fill in its keys, leaving the original unchanged. A name starting
with `ai-providers` keeps it out of git:

```bash
copy providers\ai-providers.release.json providers\ai-providers.release.local.json
```

**3. Encrypt it:**

```bash
scripts\Encrypt-Providers.cmd providers\ai-providers.release.local.json
```

This writes `providers\ai-providers.release.local.enc` and prints the key id it used. It warns if a provider has no
API key; Ollama on `localhost` doesn't need one. To choose the output name or location, add `-OutFile`:

```bash
scripts\Encrypt-Providers.cmd providers\ai-providers.release.local.json -OutFile C:\Share\ai-providers.enc
```

**4. Give users the `.enc` file.** They import it in Settings → Providers and models → **Import from file…**.

**To change it later:** decrypt it, edit the JSON, encrypt it again, then delete the plain copy, since it may hold API
keys:

```bash
scripts\Decrypt-Providers.cmd providers\ai-providers.release.local.enc
```

Keep `secrets\providers.key` private and backed up: without it, you can't make new files the shared setup can import.
Git ignores `secrets\`, providers files other than the release file, and `.enc` files, so none of them are committed by
mistake. The scripts are described in [scripts/README.md](scripts/README.md).

### Confluence

Settings → Confluence (under Integrations) keeps the Confluence sites in `settings/confluence.json`, encrypted with
DPAPI like the AI keys.

| Sign-in | Sent as |
|---|---|
| Confluence Cloud: email and API token | Basic auth |
| Server/Data Center: personal access token | Bearer token |
| None | No auth header |

**Test connection** calls `/rest/api/space` and explains the result (not Confluence, sign-in refused, or connected with
N spaces). A space added on a repository's Indexing page is read with the sign-in of the site whose address is the
longest prefix of the space's. Settings → Confluence → Syncing also sets the most pages read per space (1–10,000,
default 500) and the timeout (5–600 seconds, default 60).

Spaces are chosen per repository, in one place: the repository's Indexing page (Settings → Confluence keeps only the
sites and their sign-in, and points there). **Spaces this repository searches** lists the chosen ones by name, with
their key, site and how many pages the last sync read from each, and a button to remove each; **Sync** fetches their
pages and refreshes the index. Below, **Add spaces from your sites** lists every space the saved sites' sign-ins can
see (read page by page from `/rest/api/space`), with a tick box each: ticking adds a space, unticking removes it, and a
filter appears when there are many. A space can also be added by pasting its address.

### Skills

A skill is a folder with a `SKILL.md` (front matter: name, display name, description, icon, tags; then Markdown
instructions) and optional `references/`. It shapes how the assistant answers a kind of question.

- **Built in:** Architect, Code review, Debugging, Diagrams, Documentation writer, Word document, PowerPoint
  presentation and Test Fix (written to `<data>/skills/built-in/`). A skill with `metadata: explorer_default: off` is off until turned on; Test Fix is.
- **Settings → Skills:** turns each skill on or off, sets whether Ask reads the question first (and asks back when it is
  unclear), sets whether a question picks a skill automatically (the skill router
  matches the question's words against each skill's name, tags and description) and sets the trace size (up to 20–600
  steps, default 200; 2–16 calls deep, default 8). It also imports
  more skills from a folder, a `.zip` or a collection (a folder holding a `skills/` folder) into `<data>/skills/imported/`.
- **Capabilities:** a skill can add one (`metadata: explorer_capability: trace`). The Architect runs the static
  architecture trace on the scope the question names, following every call across projects and resolving interfaces
  through DI registrations. It answers with a program-flow table, the call chain, a sequence diagram and cross-project
  boundaries. The table is built from the trace itself, so it has every traced step (models condense long tables however
  they are asked): the model writes a `step-descriptions` block — one line per step and `# Phase` lines — and the
  explorer turns it into the table, keeping the trace's own description for any step the model left out. Debugging and Diagrams have the trace capability too; a flow question picks the Architect. An imported
  skill that replaces a built-in one keeps its capability. A skill can set `metadata: explorer_output: word` or
  `powerpoint`: its answers are written as a document or a deck, get the larger answer size, and show **Save as Word** or
  **Save as PowerPoint**, which saves the .docx or .pptx in one click with the Mermaid diagrams drawn as pictures. The
  Word document and PowerPoint presentation skills use it. A skill can also set `metadata: explorer_min_depth:
  <Quick…Expert>`, the least depth Auto uses for it.

### Test Fix

The Test Fix skill repairs failing tests in the local files and proves it with the repository's own runner. It is off
by default (Settings → Skills); turned on, **🧪** in Ask opens it. The question box and attachments take the failure
(test files, logs, stack traces); the panel takes the tests to run, the configuration and an optional command.

- **Workflow:** inspect → reproduce → diagnose → patch → apply → verify → report, repeated up to the attempt limit
  (Settings → Skills: attempts, time limit per command, apply changes, run commands).
- **Inspect:** the runner and frameworks come from the repository (solutions and test projects with MSTest, NUnit,
  xUnit; package.json test scripts with Jest, Vitest, Mocha; pytest; Maven and Gradle, wrappers first), with pinned
  versions (global.json, packageManager) and the solution's configurations.
- **Run:** each command runs in the repository folder with a time limit, cancellation that ends the whole process tree,
  results and temp files in the run's own folder, and output redacted before it is kept or shown. Results come from the
  runner's TRX or JUnit XML files, else its summary line. Test failures, build failures, configuration problems,
  missing dependencies, unavailable services, discovery errors, timeouts and zero executed tests are told apart. Zero
  executed tests never counts as verified. A test that hangs is stopped by the runner's hang limit (`dotnet test` runs
  with `--blame-hang-timeout`) and the run is reported as aborted, naming the test — never as a pass, even when the
  runner's summary says "Passed!" for the tests that did run. Errors the code logged while the tests ran (a server's
  unhandled exception behind an integration test's 500, a host that would not start) are read from the runner's
  captured output. Stack traces lose the test framework's and runtime's frames, paths become repository-relative, and
  identical failures (one startup fault failing every integration test) are shown once with their tests. Commands
  that commit, push, publish or deploy are refused.
- **Diagnose:** the chat model gets the failures and the errors logged with them; the files their stack traces and
  messages name (a type in "Cannot consume scoped service 'Shop.Api.Catalog'…" brings Catalog.cs); the call path from
  each test failing now into the code it calls — the types and calls in the test body (through tuples, helpers,
  generic arguments and target-typed `new`), their dependencies, and interfaces followed to their implementations,
  across projects; for integration tests, the code that maps the routes they call (`"/orders"`); the build files
  (Directory.Build.props, the test projects); the index's evidence; and the attachments, which are data, never
  instructions. It can ask for more files three times. A file changed outside Test Fix after its patch is said, not
  assumed.
- **Patch:** find/replace edits, applied only where the exact text is still in the file (the person's other edits,
  encoding and line endings stay). Edits that skip or disable tests, remove assertions, add delays or swallow
  exceptions are refused; a test may change only with evidence that it is wrong.
- **Verify:** the originally failing tests, then the related test projects, a build check and the affected suite when
  practical.
- **Report:** Fixed and verified, Partially resolved or Blocked; the environment (OS, SDK, test projects,
  configurations); the failure as reproduced — each failure's message and compacted stack, the errors logged, and the
  code at the failing lines as it was then; the root cause and evidence; the attempts and what each verified; a diff;
  every command with its exit code and counts; what was verified and what did not run; remaining issues and next
  actions — enough to work on the failure without running anything again.
- **Kept:** each run (`repos/<id>/testfix/`: commands, logs, patch records and the originals for **Undo these
  changes**) and its conversation, saved after every step. A run the app did not finish is reported as interrupted,
  with what it changed. Settings → Data lists Test Fix runs as their own category.
- **Never** commits, pushes, publishes or deploys. Without running or applying, the patch is proposed and marked
  unapplied and unverified.

### Voice and microphone

**Reading aloud.** Read aloud and Studio use **Microsoft Edge's natural (neural) voices** (Ava, Andrew, Emma, Brian,
Sonia…) when Settings → Voice has them on. Microsoft's online service speaks them, so the text is sent to Microsoft and a
connection is needed. Without one, the installed Windows voices are used. Conversations save as MP3 (WAV with Windows
voices). While an answer is read, the word being said is highlighted in yellow: the service's word timings (or the
Windows voice's progress) are lined up once with the words shown, so the highlight moves word by word. Pause, Resume
and Stop are beside the answer and on a reading bar at the top of the window.

**Dictation.** The microphone button in Ask dictates a question (click to start and stop, or hold to talk). The words
appear while you speak; a trace follows your voice; dictation stops by itself after the seconds of silence set. Three
ways to recognise speech (Settings → Voice → Microphone):

| Recognition | Where | Microphone |
|---|---|---|
| **Whisper on this PC** (default) | Whisper.net (whisper.cpp) in the app; the model (tiny.en, base.en, small.en or base) is downloaded once from Hugging Face into `%LOCALAPPDATA%\DocGen.Explorer\Models\whisper` | the one chosen in Settings |
| **Windows online speech recognition** | Microsoft's service, as Windows voice typing uses; needs *Online speech recognition* on in Windows | the Windows default |
| **Windows offline recogniser** | System.Speech on this PC | the one chosen in Settings |

Ollama has no speech models, so Whisper is the local engine. The microphone button shows only when dictation is on and a
microphone can be used.

### Git and Azure DevOps

Git URLs are cloned shallowly (`--depth 1`) into `clones/` in the data folder.

- **Accepted:** HTTPS and SSH addresses. For Azure DevOps, also `https://org@dev.azure.com/org/project/_git/repo` (the
  Clone button's form), `https://org.visualstudio.com/project/_git/repo`, `git@ssh.dev.azure.com:v3/org/project/repo`,
  and repository page links (trimmed after `_git/<repo>`; `version=GB<branch>` sets the branch).
- **No duplicates:** every form of one repository counts as the same repository, so it is not cloned twice.
- **Credentials** come from Git Credential Manager. URLs with a password or token are refused.
- **Branches:** repository cards show the source (local folder or Git clone) and a clone's branch. **Change branch…**
  lists the remote's branches, fetches the chosen one, checks it out and starts a full reindex.
- **Pull latest** (a clone's Indexing page) fetches the remote's new commits (`git pull --ff-only`) and refreshes the index.

## How it works

### Indexing

Indexing runs nine stages and keeps the result in memory and on disk. A refresh re-reads only what changed; a run can
be cancelled and the previous index stays in use.

| Stage | What it does |
|---|---|
| Scanning | Walks the repository with the ingestion filters (60+ languages; `bin`, `obj`, hidden and build folders, binaries and files over 2 MB skipped). Unchanged files (same size and time) are not re-read. |
| Classifying | Compares content hashes with the last run (changed / unchanged / removed) and updates the code index incrementally (C# symbols, projects, packages, DI registrations, configuration, endpoints, middleware). |
| ParsingDocumentation | Parses every Markdown file into a documentation page with its headings. |
| Chunking | Markdown by section, C# by type and member (doc comments included), everything else by overlapping 60-line windows. Bulk data (XML, JSON or CSV over 160 lines or 64 KB) gets one chunk with its path and head; settings files (`*.config`, `appsettings*.json`) are always read in full. |
| Embedding | `hashing-512`: offline, deterministic embeddings (identifier-aware terms and bigrams hashed into 512 signed buckets). |
| BuildingGraph | Repository, projects, namespaces, files, types, tests, Markdown files and documentation pages, linked by contains, declares, inherits, uses, calls, tests, references and mentions. |
| AnalyzingOkf | Operational facts: configuration keys and reads, endpoints, service registrations, middleware, packages, entry points. |
| DescribingGraph | One-line descriptions, from XML doc comments and the index, or written by the chat model when one is configured. |
| Finalizing | Writes the generated reference pages (Overview, Architecture, an API page per project, Operations) and the index. |

### Search

Search (header, Ctrl+K) fuses six rankings by reciprocal rank: symbol (fuzzy, over the code index), heading, file, exact
line, keyword (BM25) and semantic (embeddings). Each hit says how it matched.

### Assistant

The assistant retrieves evidence, fuses and diversifies it, and then answers:

- **Evidence:** the symbols the question names (resolved in the code index), their graph neighbours, BM25 and embedding
  matches, and intent-specific material.
- **With a chat model:** the model's answer streams in, written only from the cited evidence.
- **Without one (evidence mode):** a grounded answer is composed offline from the index. It covers what a type is, its
  members, what it derives from, uses and is used by, the exact lines where one type refers to another, Mermaid
  dependency diagrams, and configuration and test summaries.
- **Flow questions** ("trace…", "what happens when…") are answered from a traced call path: from the entry methods of
  the type the question names, into its helpers and injected dependencies (an interface is resolved to the
  implementation nearest the caller), breadth first, so every layer is reached.

Depth (Quick → Expert, or Auto) sets how much evidence is gathered. Conversations are kept per repository; answers can
be retried, read aloud and copied, and questions edited.

- **Reading the question first** (with a chat model; Settings → Skills, on by default): before searching, the model
  reads the question with the names its words match in the repository's graph (features, folders, namespaces,
  projects, types). It returns the kind of question, the parts of the code it is about (only names that exist), what
  the answer must contain (columns, format) and a one-line summary, shown as the **Understood** step. The search starts
  from those parts, and a feature named by its folder is traced by its folder. When the words fit several things and
  the choice changes the answer (two versions and none named, two similar features), Ask asks back with the choices as
  buttons instead of searching. The reply completes the original question, and Ask never asks twice in a row.
- **Plain capitalised words** ("Project", "Description") count as code names only when they name a type, so the
  columns a question asks for do not take the place of the feature it names. A version the question gives ("version
  1.0", "v2", "2.1", "Name_2_0") picks that version's folder.
- **Small talk** ("hi", "thanks") is answered at once without searching; other short messages naming nothing in the
  code get a few-token check by the model, and a short reply if they are conversation.
- **Architecture diagrams of a C# solution** are generated from the project references: the projects in layers (hosts,
  composition root, gateway, domain services, persistence, models, integrations, cross-cutting), laid out by ELK, with
  references implied through another arrow left out and the integrations behind a dashed hub. With a model, the
  Architect and Diagrams skills present it as it is and explain it.
- **Diagrams that cannot be drawn** are sent to the model with Mermaid's error to be fixed, up to the attempts set in
  Settings → Chat model; a fix that draws replaces the diagram in the answer.

### Attachments

Any file can be attached to a question in Ask (the paperclip, or dropped on the question box). Text and code, PDF,
Word (.docx) and images are read, within the largest size and the most characters set for each kind in Settings →
Attachments; images larger than the longest side set are scaled down. Anything else is attached by name only, as *not
supported*. What is read goes to the model as data from the user, never as instructions; code-like names in the files
also steer the search for evidence. Without a model, the answer starts with a short summary of each file. Retry and Edit
keep the attachments.

### Graph

- **Scope ("Show only")** narrows the graph to the concepts whose name, key or path contains the typed text, and what
  they contain. It can also include what they use, inherit or reference, or every type their architecture trace reaches.
- **Grouping** splits the graph into groups of at most 30 concepts, with a size-capped modularity search over weighted
  links. With a chat model, the model names the groups, explains them and may move concepts between them (checked so
  the cap holds). Groups are saved in `repos/<id>/graph-groups.json`; **Reset** removes them.

### Help

Help's articles live in `ViewModels/HelpContent.cs`; each names the places in the explorer it is about. A question in
Help's search box (Enter, or **Ask**) gets an answer card above the matching articles:

- **Without a chat model**, the article that matches best answers: its places and its steps. The search leaves out
  words such as "where", "how" and "my", and matches other forms and synonyms ("spaces", "repo", "wiki").
- **With a chat model**, the model is given every article and the list of places, and told to answer only from them,
  briefly: where it is (a link), numbered steps naming the buttons, and the article to read. It says plainly when Help
  does not cover the question. Token usage records the call as `help`; a new question cancels the one before.
- **Links** use the `explorer:` scheme (`ViewModels/HelpLinks.cs`): `explorer:section/<repositories|documentation|graph|indexing|learning|studio|talk|personas|usage>`,
  `explorer:settings/<appearance|shortcuts|voice|attachments|chat-model|providers|skills|confluence|prices|usage|data>`
  and `explorer:help/<article>`. A repository's page with no repository open goes to Repositories and says why.

### Learning, Studio and personas

- **Learning:** quizzes written offline from facts in the index and marked automatically; flashcards on SM-2 spaced
  repetition; learning paths in project-dependency order; a FAQ answered by the assistant; a knowledge record by topic.
- **Studio:** two to four personas discuss the repository, written by the model from retrieved evidence or scripted
  offline from the index. Each persona speaks in its own voice, and a conversation can be saved as audio and Markdown.
- **Persona pictures:** 100 cartoon faces drawn from SVG parts, each with eleven emotions plus talking and blinking
  frames. Studio lines are tagged `Name [emotion]: …` (or read from their words); during playback the speaker talks with
  the line's emotion and the listeners react.

## Data and usage

### Data folder

Everything the explorer derives lives in its data folder (default `%LOCALAPPDATA%\DocGen.Explorer\desktop`). Nothing is
ever written into a registered repository.

| Path | Contents |
|---|---|
| `repositories.json` | The registered repositories |
| `repos/<id>/` | Files, pages, chunks, vectors, graph, operational facts, generated pages, Ask (`conversations/`) and Talk (`talk/`) conversations, learning, Studio |
| `analysis/indexes/<id>/` | The code index |
| `settings/` | Settings (`ai.json` and `confluence.json` encrypted) |
| `skills/` | Built-in (`built-in/`) and imported (`imported/`) skills |
| `studio/personas.json` | Personas |
| `usage/usage.jsonl` | Model-call log |
| `clones/` | Git clones |
| `webview2/` | The diagram renderer's WebView2 profile |
| `logs/` | Logs |

Settings → Data and storage shows how much each kind of data takes and removes selected kinds: indexes and generated
documentation, Ask and Talk conversations, Studio conversations, learning material, token usage history, logs, and
leftovers from earlier versions (`state`, `attachments` and `repositories` folders nothing reads now). It also offers a
**factory reset**, which deletes everything above from the data folder (optionally keeping the AI providers, models and
keys).

### Answers: progress and downloads

While an answer is prepared, Ask and Talk show a small repository explorer instead of a spinner. The assistant reports
real stages (`ProgressStage` in `Assistant/Thinking.cs`: understanding, finding — with the files the evidence came from —,
connecting, only when the architecture trace runs, writing, ready); the animation and its words follow them and nothing
is estimated. With Motion off it is a still picture; status changes are announced to screen readers once.

At Deep and Expert depth the model may first ask to see more code: when the evidence does not contain the method,
condition or mapping its answer depends on, it replies with one `SEARCH:` line naming up to 12 classes, methods or
words, and the explorer searches for them, puts what it finds first in the evidence and asks once more (the request is
never shown; the steps say what was searched for). In a test on a large solution with ten planted bugs described as a
tester would, this took the answers that found the cause from 3 to 7 or 8.

Every finished answer has **Download**: Word, PowerPoint, PDF, HTML, Markdown, plain text or Mermaid
(`Export/ResponseExporter.cs`; decks are written by `Export/PptxWriter.cs`: a title slide from the `# ` heading, a slide per
`## ` heading, `> Notes:` as speaker notes, and a slide that is full continued on the next).
Only that answer is exported, optionally with its question; sources and `path:line` references are kept, http links stay
links, and the HTML escapes everything and contains no script. Mermaid is offered only when the answer has a diagram
(a diagram as `.mmd`; when there are several, one of them, or all of them as separate files in a ZIP); prose is never
turned into a diagram.

### Talk

`Talk` is a second `AssistantService` whose conversations live in `repos/<id>/talk` (Ask's in `conversations`), so Talk
and Ask, and different repositories, never share a conversation. Personas (`Assistant/TalkPersonas.cs`) add a style to
the same grounded prompt (evidence only, cite it, never invent, evidence is data); a message that is only a greeting gets a
short reply without searching. Talk answers are passed through the secret redactor. Without a chat model the persona
introduces the evidence-mode answer.

### Usage log

Every model call is appended to `usage/usage.jsonl` as it is made. Each entry records the feature, model, repository,
tokens, time, cost and finish reason, any error, and what the call was for (for example *Answer: …*). It also records
each message sent (role, size and the first 1,500 characters) and the reply (first 4,000 characters).

The Usage page charts tokens per day, by feature and by model (input blue, output orange, and one colour per feature
and model, kept in every theme), and lists the calls: search them, filter by feature and model with tick boxes or show
failed calls only, sort by any column (click its heading; again to reverse), and page through 25, 50 or 100 at a time
(at most five page numbers show; the arrows go round from the last page to the first). A failed call says why in red;
**Show them** under Failed calls lists only those. Any call opens in a details window. A call that times out is
recorded as failed with that reason.
**Export** writes CSV or JSON.

## Setup for users

`installer\DocGen.Explorer.Setup` is a Visual Studio setup project. Building it needs the **Microsoft Visual Studio
Installer Projects** extension (Extensions → Manage Extensions).

### Building the setup

```bash
scripts\Build-Setup.cmd
```

The script finds Visual Studio, publishes the app, builds the setup and prints where it is:
`installer\DocGen.Explorer.Setup\Release\setup.exe` and `DocGen.Explorer.Setup.msi`. Give users both files; they run
`setup.exe`. To build the setup in Visual Studio instead, publish the app first (step 1 below), then right-click
**DocGen.Explorer.Setup** (solution folder *Installer*) → **Build**. A normal solution build doesn't include the setup,
and `dotnet build` skips it.

For a new version, run `scripts\Build-Setup.cmd -Version 1.1.0`. It writes the version to `Directory.Build.props` and
the setup project, and refuses a version that is not higher than the current one. The upgrade code never changes; every build gets a product code of its own, so any newer build —
a higher version, or the same version built again — upgrades an installed copy in place.

### What the setup does

| | |
|---|---|
| Publisher | DocGen (in Apps & features, and in the program's file properties) |
| Installs to | `C:\Program Files\DocGen\DocGen Explorer` for all users of the PC by default (the folder page also offers Just me; 64-bit; administrator rights) |
| Frameworks | .NET 10 is inside `DocGen.Explorer.exe` (published self-contained, single file). `setup.exe` installs the Microsoft Edge WebView2 Runtime first when the PC lacks it (Windows 11 has it); Mermaid diagrams are drawn with it. |
| Shortcuts | Start menu and desktop, with the DocGen icon; the same icon in Apps & features |
| Upgrades | Another build of the same or a higher version removes the installed one first, then installs; installing a lower version over a higher one is refused |
| Repair | Running the same setup again (or Apps & features → DocGen Explorer → Modify) offers Repair and Remove; Repair puts back missing or damaged program files |
| Caches | The program unpacks mermaid.js with the ELK layout and the Whisper engine into `%LOCALAPPDATA%\DocGen.Explorer\cache\<kind>\<build>`, one folder per build, and deletes other builds' folders when it starts — a new build never reads files an older one left |
| Uninstall | Apps & features → DocGen Explorer. Removes the program, its shortcuts and, for the Windows user who uninstalls, the cache and `%TEMP%\DocGen.Explorer`. Data folders (`%LOCALAPPDATA%\DocGen.Explorer\desktop`), settings and keys, and downloaded Whisper models (`%LOCALAPPDATA%\DocGen.Explorer\Models\whisper`) are kept. To remove them, first use Settings → Data and storage → Factory reset (the data folder, settings and keys) and Settings → Voice → Microphone → Remove (each Whisper model). |
| Providers | The build includes the team's `secrets\providers.key` (see `scripts\README.md`). The setup contains no providers or keys; the team gives users the encrypted providers file. |

### How it is built

1. **Publish:** `dotnet publish src\App\DocGen.Explorer -p:PublishProfile=Installer`
   (`Properties\PublishProfiles\Installer.pubxml`) publishes the app into `installer\publish`. The build script does
   this before calling Visual Studio, because Visual Studio checks that the setup's files exist before it builds.
2. **Build:** Visual Studio packages the published files into the MSI and builds `setup.exe`.
3. **Post-build:** `installer\DocGen.Explorer.Setup\PostBuild.js` stores the icon in the MSI so Windows can show it
   (Visual Studio stores it under a name ending in `.exe`, which shows as a blank icon). It also makes the shortcuts
   point at the program itself, gives the build its own product code, removes an installed earlier or same-version
   build before copying files, and adds the uninstall step that deletes the cache. The build script fails when this
   step did not finish (Visual Studio reports success either way).
4. **Check:** `scripts\installer\Test-Setup.ps1` reads the built MSI's tables and fails the build unless installing,
   upgrading, repairing and uninstalling will behave as described above.

`installer\publish` and the setup's `Release` folder are ignored by git.

## Branches, CI and releases

### Branches

| Branch | Use |
|---|---|
| `main` | Always builds and passes its tests. Changes arrive by pull request. |
| `feature/<name>` | One change (for example `feature/confluence-export`). Branch from `main`, open a pull request into `main`. |
| `release/<major>.<minor>` | A release line (for example `release/1.0`), branched from `main` when a version is ready. Only fixes go in; fixes are merged back into `main`. |

Pushing a tag `v<major>.<minor>.<build>` (for example `v1.0.0`) publishes a release; tag a commit on the release branch.

### Pipelines

| Workflow | Runs on | What it does |
|---|---|---|
| **CI** (`.github/workflows/ci.yml`) | Pushes to `main`, `feature/**`, `release/**`; pull requests into `main` and `release/**`; by hand | Builds the solution in Release and runs the tests; in a second job walks every UI path of the app (`--uitest`) on a copy of one project of this repository. Uploads the test results, and the walk's `ui-paths.md` and screenshots. |
| **Release** (`.github/workflows/release.yml`) | A pushed `v*.*.*` tag; by hand for an existing tag (with **dry_run**: builds with a throwaway key and attaches the setup to the run, publishing nothing) | Runs the tests, installs the Visual Studio Installer Projects extension, builds the setup with `scripts\installer\Build-Setup.ps1 -Version <the tag's version, without the v>`, and publishes a GitHub release with `DocGen-Explorer-<version>-Setup.zip` (`setup.exe` and the MSI), the MSI on its own, and `SHA256SUMS.txt`. |

The Release workflow needs the repository secret **`PROVIDERS_KEY`**: the contents of `secrets\providers.key`, which is
built into the app. Add it under Settings → Secrets and variables → Actions.

### Releasing a version

```bash
git switch release/1.0
```

```bash
git tag -a v1.0.1 -m "DocGen Explorer 1.0.1"
```

```bash
git push origin v1.0.1
```

If the tag does not start the Release workflow, start it by hand for the tag (Actions → Release → Run workflow), or:

```bash
gh workflow run Release -f tag=v1.0.1
```

## Look and feel

The interface is calm and quiet: outline icons, thin borders, soft corners and small, even text. There are three
themes (Settings → Appearance, or the gear menu):

| Theme | Colours |
|---|---|
| Light | Pure greys, no hue at all; a charcoal accent (dark buttons, near-black links and selection). Code keeps its syntax colours and Token usage its chart colours, where colour carries meaning. |
| Follow Windows | Light or dark as Windows is set, with the Windows accent colour for buttons, links, selection and focus; changes when Windows' colours change. Each shade is picked so text stays readable (4.5:1). |
| Dark | Warm charcoal surfaces with the same structure. |

The app's own icon (window, taskbar, installer) keeps its original blue, so it never looks disabled; the logo inside
the header is grey to match the interface.

- **Shortcuts.** Settings → Shortcuts lists every shortcut with its icon. Click one and press the new keys; Escape
  stops, Backspace leaves it without keys, and keys taken from another shortcut leave that one without. Changes are
  saved in `settings/explorer.json` (only what differs from the defaults).

- **Title bar.** The header is the window's title bar: it shows the name and version once (also in the taskbar, e.g.
  "DocGen Explorer 1.0.0"), drags the window, double-click maximises, and minimise, maximise and close are at its right.
- **Window layout.** The window is built from panels — Repository (Docs, Files, Changes), the page and the Assistant —
  placed by a layout engine: drag a panel's header onto another panel's edge to dock it on that side, onto its middle to
  make a tab, or outside the window to float it in its own window; drag a divider to resize. Tabs are rearranged by
  dragging them along their strip (the header's sections, Docs · Files · Changes, a panel group's tabs) or with
  Ctrl+Shift+← / → on a focused tab; the orders are kept in the layout too. A header's ⋯ menu does
  the same without dragging. The layout is saved in `settings/layout.json`; ⚙ → Reset window layout puts it back and
  Lock or unlock the layout stops accidental drags. Settings → Appearance → Arrangement still picks the standard order
  of the three panels (a reset uses it).
- **MVVM.** The app is a Prism application (Prism.Unity): the engine, the main view model and the layout service are
  registered with the container, the panels are registered by their layout id in a module, view models derive from
  Prism's `BindableBase`, commands from its `DelegateCommandBase`, and layout changes travel on its event aggregator.
- **Size.** Text is small and even (body 13.5, documents and conversation 14, page titles 21). Ctrl+= makes the whole interface larger,
  Ctrl+- smaller and Ctrl+0 returns to 100% (80% to 200%; also Settings → Appearance → Size). Menus, drop-downs and
  tooltips scale with it, and the size is remembered.
- **Smooth text.** Text is laid out the way a browser lays it out (WPF's Ideal formatting), so it looks
  smooth and stays clean at every size.
- **No blur from shadows.** Menus and floating panels draw their shadow themselves (`Controls/ShadowBorder.cs`) instead of using a
  `DropShadowEffect`, which turns text into a bitmap and blurs it.
- **Send feedback.** Gear menu → Send feedback… writes `C:\DocGen-Feedback\DocGen-feedback-yyyy-MM-dd-HHmmss.zip`
  (Documents\DocGen-Feedback if C:\ does not allow it): screenshots of the open windows, what you wrote, the version,
  Windows and screen details, the explorer's state, `settings/explorer.json`, `repositories.json` and the last three
  logs. Keys and tokens are never included: `ai.json` and `confluence.json` are left out and the logs are already
  redacted.

| Resource | What it holds |
|---|---|
| `Themes/Light.xaml`, `Themes/Dark.xaml` | Colours, by meaning: `BackgroundApp`, `BackgroundSidebar`, `SurfacePanel`, `SurfaceHover`, `SurfaceSelected`, `TextPrimary`, `TextSecondary`, `BorderDefault`, `AccentPrimary`, `FocusRing`, links, status, diff, search match, selection and disabled colours, and the `Brush.*` names the screens use. Swapped at run time (Appearance). |
| `Themes/Tokens.xaml` | Fonts, the type scale, spacing (4 8 12 16 20 24 32), control heights, icon sizes, corner radii and timing. |
| `Themes/Controls.xaml` | The shared styles: text, buttons, inputs, chips, tabs, lists, the tree, menus, tooltips, scroll bars. |
| `Infrastructure/ThemeManager.cs` (`Icons`) | The one icon map; every screen takes its icons from it. |

The interface uses the Windows fonts; nothing is packaged:

| Use | Font | Fallback |
|---|---|---|
| Interface, conversation and documents | Segoe UI Variable Text | Segoe UI (Windows 10) |
| Large headings | Segoe UI Variable Display | Segoe UI |
| Code | Cascadia Mono | Consolas |
| Icons | Segoe Fluent Icons (an outline icon family) | Segoe MDL2 Assets |

The
conversation font has its own key (`Font.Conversation`), so it can be switched to a serif such as Sitka Text in one
place. Text colours meet 4.5:1 contrast on the surfaces they sit on; disabled controls keep a readable muted label.

## Security and privacy

- **Providers:** only providers from a file encrypted with the team key can be imported (AES-256-CBC with
  HMAC-SHA256, encrypt-then-MAC). A changed file, or one encrypted with another key, is refused.
- **Keys and tokens on the PC:** AI keys and Confluence tokens are stored encrypted with Windows DPAPI for the current
  user, so another user or another PC cannot read them.
- **Not in git:** the team key (`secrets/`), providers files other than the release file, encrypted files (`*.enc`)
  and build outputs. See `.gitignore`.
- **Release builds:** source paths are mapped to `/_/`, so the shipped program carries no local folder names or user
  names.
- **Voices:** with Edge natural voices on, text read aloud is sent to Microsoft. Model calls go only to the providers
  in the imported file.
- **Dictation:** Whisper and the Windows offline recogniser stay on the PC; Windows online speech recognition sends
  your voice to Microsoft. Attachments go only to the chosen chat model, as data.

## License

MIT, see [LICENSE](LICENSE). Mermaid (bundled in `src/App/DocGen.Explorer/Assets/mermaid`) and its ELK layout
(`Assets/mermaid/elk`) are MIT licensed; the Eclipse Layout Kernel (elkjs) inside it is under the Eclipse Public
License 2.0. Whisper.net is MIT licensed; Whisper models are downloaded from Hugging Face (MIT).
