using System.Text;
using System.Windows;
using System.Windows.Automation;
using System.Windows.Automation.Peers;
using System.Windows.Automation.Provider;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Threading;
using DocGen.Explorer.Controls;
using DocGen.Explorer.Engine.Models;
using DocGen.Explorer.ViewModels;

namespace DocGen.Explorer.Infrastructure;

/// <summary>
/// Walks every path a user can take through the explorer — by pressing the real buttons, menus and tabs through UI
/// Automation — and checks that no screen leaves them stuck: each page loads without errors, every menu opens and
/// closes, every dialog and window can be cancelled, empty states offer a way forward, and the header always offers a
/// way back. <c>DocGen.Explorer.exe --data &lt;empty scratch folder&gt; --uitest &lt;report folder&gt; --add &lt;sample repository&gt;</c>
/// writes ui-paths.md (and a screenshot per step) and exits with the number of failures.
/// </summary>
public sealed partial class UiPathTester
{
    private const string DataMarker = "uitest.data";

    private readonly Window _window;
    private readonly MainViewModel _main;
    private readonly string _folder;
    private readonly List<(string Path, bool Passed, string Detail)> _results = [];
    private readonly List<string> _errors = [];
    private int _shot;
    // Said beside a path that passed without checking everything (what this PC cannot do).
    private string? _note;
    private DependencyObject? _extraRoot;

    private UiPathTester(Window window, MainViewModel main, string folder)
    {
        _window = window;
        _main = main;
        _folder = folder;
        Logging.ErrorLogged += message => _errors.Add(message);
    }

    /// <summary>Runs the walk. Refuses a data folder that holds real data (it registers and removes repositories).</summary>
    public static async Task<int> RunAsync(Window window, MainViewModel main, string folder, string? samplePath)
    {
        Directory.CreateDirectory(folder);
        var root = main.Engine.Store.Root;
        var hasData = File.Exists(Path.Combine(root, "repositories.json")) && (await main.Engine.Repositories.ListAsync()).Count > 0;
        if (hasData && !File.Exists(Path.Combine(root, DataMarker)))
        {
            Logging.Info("UI path test refused: the data folder holds repositories. Use an empty scratch folder.");
            await File.WriteAllTextAsync(Path.Combine(folder, "ui-paths.md"), "Refused: the data folder holds repositories; run the UI path test on an empty scratch folder.\n");
            return 1;
        }
        await File.WriteAllTextAsync(Path.Combine(root, DataMarker), "Data folder used by the UI path test.");
        if (samplePath is null || !Directory.Exists(samplePath))
        {
            await File.WriteAllTextAsync(Path.Combine(folder, "ui-paths.md"), "Give a sample repository with --add.\n");
            return 1;
        }
        var tester = new UiPathTester(window, main, folder);
        try
        {
            await tester.WalkAsync(Path.GetFullPath(samplePath));
        }
        catch (Exception ex)
        {
            tester.Record("The walk itself", false, ex.ToString());
        }
        return await tester.WriteReportAsync();
    }

    // ---------------------------------------------------------------- the walk

    private async Task WalkAsync(string samplePath)
    {
        // The same window size on every screen (a build server's is small, and a narrow window folds the header's tabs
        // into a menu): the narrow layout has its own step below.
        _window.WindowState = WindowState.Normal;
        _window.Width = 1440;
        _window.Height = 900;
        await Settle(500);
        foreach (var repository in await _main.Engine.Repositories.ListAsync())
        {
            await _main.Engine.RemoveRepositoryAsync(repository.Id);
            _main.ForgetWorkspace(repository.Id);
        }
        await _main.Repositories.RefreshAsync();
        _main.Navigate(Section.Repositories);
        await Settle();

        // 1. Nothing registered yet.
        await Step("Start with no repositories: the Repositories page offers the add form", () =>
            Expect(_main.Section == Section.Repositories, "not on Repositories") ?? Expect(Find("Add and index") is not null, "no \"Add and index\""));
        foreach (var section in new[] { "Documentation", "Graph", "Learning", "Studio", "Indexing" })
        {
            await Step($"No repository: {section} (Ctrl shortcut) falls back to Repositories", () =>
            {
                _main.NavigateCommand.Execute(section);
                return Expect(_main.Section == Section.Repositories, $"went to {_main.Section}");
            });
        }
        await AppMenuWalkAsync("no repository");
        await PersonasEditorAsync();
        await SettingsDialogsAsync();

        // 2. Add the sample through the form, as a user would.
        _main.Navigate(Section.Repositories);
        await Settle();
        _main.Repositories.AddMode = "local";
        // Typed into the box, as a user would (typing makes the add button re-check whether it can run).
        if (CaptureRunner.FindAll<TextBox>(_window).FirstOrDefault(b => b.IsVisible && System.Windows.Data.BindingOperations.GetBinding(b, TextBox.TextProperty)?.Path.Path == "LocalPath") is { } pathBox)
        {
            pathBox.Text = samplePath;
        }
        else
        {
            _main.Repositories.LocalPath = samplePath;
        }
        System.Windows.Input.CommandManager.InvalidateRequerySuggested();
        await Settle();
        await Step("Add a local repository with Add and index: it opens and indexes", async () =>
        {
            var problem = await Click("Add and index");
            if (problem is not null)
            {
                return problem;
            }
            await WaitAsync(() => _main.Workspace is not null, 15);
            if (_main.Workspace is null)
            {
                return "no repository opened";
            }
            await WaitAsync(() => !_main.Engine.Indexing.IsRunning(_main.Workspace.Record.Id), 120);
            await Settle(800);
            return Expect(_main.Section == Section.Documentation, $"opened {_main.Section}");
        });

        // 3. The four tabs, and the pages behind them.
        foreach (var (tab, section) in new[] { ("Documentation", Section.Documentation), ("Graph", Section.Graph), ("Learning", Section.Learning), ("Studio", Section.Studio) })
        {
            await Step($"Tab {tab}", async () => await Click(tab) ?? Expect(_main.Section == section, $"on {_main.Section}"));
        }
        await Step("The Repository panel button hides the panel and says it will show it; pressed again it shows it", async () =>
        {
            var hide = _main.TreeToggleTooltip;
            var problem = await Click("Documentation") ?? await Click(hide);
            var icon = _main.TreeToggleIcon;
            problem ??= Expect(_main.TreeToggleTooltip != hide, $"the button still says \"{hide}\"");
            problem ??= await Click(_main.TreeToggleTooltip);
            problem ??= Expect(_main.TreeToggleIcon != icon, "the icon did not change back") ?? Expect(_main.TreeToggleTooltip == hide, "the list did not come back");
            if (problem is not null)
            {
                return problem;
            }
            // Closed with its X, then the assistant expanded over the page: the button still brings the panel back.
            _main.TreeVisible = false;
            _main.AssistantVisible = true;
            _main.AssistantExpanded = true;
            await Settle(300);
            problem = await Click("Show the Repository panel (Ctrl+B)");
            await Settle(300);
            var back = _main.ShowTreePane || _main.IsCompact;
            _main.AssistantExpanded = false;
            await Settle(200);
            return problem ?? Expect(back, "the Repository panel did not come back while the assistant was expanded");
        });
        await Step("Studio with no personas offers the starter personas; adding them fills the speakers", async () =>
        {
            _main.Navigate(Section.Studio);
            await Settle();
            if (_main.Workspace!.Studio.Speakers.Count > 0)
            {
                // Personas already exist (made earlier in the walk): then the empty state must not be offered.
                return Expect(Find("Add four starter personas") is null, "the starter offer shows although there are speakers");
            }
            return await Click("Add four starter personas") ?? await WaitForAsync(() => _main.Workspace.Studio.Speakers.Count >= 2, "no speakers appeared")
                ?? Expect(Find("Add four starter personas") is null, "the starter offer stayed after adding them");
        });
        await Step("Studio → Manage personas → ← Studio", async () =>
        {
            _main.Navigate(Section.Studio);
            await Settle();
            return await Click("Manage personas") ?? Expect(_main.Section == Section.Personas, "not on Personas")
                ?? await Click("← Studio") ?? Expect(_main.Section == Section.Studio, $"back on {_main.Section}");
        });
        await Step("Studio → Add persona opens the editor window; Cancel closes it", async () =>
        {
            _main.Navigate(Section.Studio);
            await Settle();
            return await ModalAsync("Add persona", "Cancel");
        });
        await Step("Studio → right-click a speaker → Edit persona… opens the editor window; closing it with the title bar returns", async () =>
        {
            _main.Navigate(Section.Studio);
            await Settle();
            var chip = CaptureRunner.FindAll<ToggleButton>(_window).FirstOrDefault(t => t.IsVisible && t.ContextMenu is not null);
            if (chip?.ContextMenu is not { } menu)
            {
                return "no speaker to right-click";
            }
            menu.PlacementTarget = chip;
            _extraRoot = menu;
            menu.IsOpen = true;
            // The menu's items appear once it has opened and laid out (longer on a busy PC).
            await WaitAsync(() => Find("Edit persona…") is not null, 5);
            try
            {
                return await ModalAsync("Edit persona…", null);
            }
            finally
            {
                _extraRoot = null;
                menu.IsOpen = false;
            }
        });

        // 3b. What the pages do: Learning's generators, the assistant, the graph, documentation and indexing.
        foreach (var (start, label) in new[] { ("Plan a path", "Plan path"), ("Create a quiz", "Create quiz"), ("Generate cards", "Generate cards"), ("Generate questions", "Generate questions") })
        {
            await Step($"Learning → {start} → {label} → ← Learning", async () =>
            {
                _main.Navigate(Section.Learning);
                await Settle();
                var learning = _main.Workspace!.Learning;
                var problem = await Click(start) ?? Expect(learning.Mode == "generate", $"mode {learning.Mode}") ?? await Click(label);
                if (problem is not null)
                {
                    return problem;
                }
                await WaitAsync(() => !learning.IsGenerating, 120);
                await Settle(600);
                problem = Expect(learning.Mode != "generate", "stayed on the form (nothing was made)");
                if (problem is null && start == "Create a quiz" && Find("Start") is { IsEnabled: true })
                {
                    problem = await Click("Start");
                }
                return problem ?? await Click("← Learning") ?? Expect(learning.Mode == "home", $"mode {learning.Mode} after ← Learning");
            });
        }
        await Step("Assistant: a suggested question is answered; a new conversation clears it", async () =>
        {
            _main.Navigate(Section.Documentation);
            await Settle();
            var assistant = _main.Workspace!.Assistant;
            if (!_main.AssistantVisible)
            {
                _main.ToggleAssistantCommand.Execute(null);
                await Settle();
            }
            var problem = await Click("Explain the architecture of this repository.");
            if (problem is not null)
            {
                return problem;
            }
            await WaitAsync(() => !assistant.IsBusy && assistant.Messages.Count >= 2, 90);
            // The buttons are enabled again once WPF re-checks its commands, just after the answer is in.
            await Settle();
            return Expect(assistant.Messages.Count >= 2, $"{assistant.Messages.Count} messages")
                ?? await Click("Start a new conversation") ?? Expect(assistant.Messages.Count == 0, "the conversation stayed");
        });
        await Step("Ask: the model box lists evidence mode and the providers' models; choosing one sets the chat model everywhere", async () =>
        {
            _main.Navigate(Section.Documentation);
            await Settle();
            var assistant = _main.Workspace!.Assistant;
            // A local provider of the walk's own (nothing listens there; only the choice is tested), so the box has a model
            // to choose besides evidence mode — the imported providers were removed earlier in the walk.
            var ai = await _main.Engine.Models.Ai.GetAsync();
            ai.Providers.Add(new Engine.Ai.AiProvider { Id = "uitest-local", Name = "UI test", BaseUrl = "http://127.0.0.1:9" });
            ai.Models.Add(new Engine.Ai.AiModel { Id = "uitest-model", ProviderId = "uitest-local", ProviderModelId = "uitest-model", DisplayName = "UI test model" });
            await _main.Engine.Models.Ai.SaveAsync(ai);
            try
            {
                await assistant.LoadAsync();
                await Settle();
                var box = CaptureRunner.FindAll<ComboBox>(_window).FirstOrDefault(c => c.IsVisible && AutomationProperties.GetName(c) == "Model");
                var problem = Expect(box is not null, "no model box in the composer")
                    ?? Expect(!CaptureRunner.FindAll<ComboBox>(_window).Any(c => c.IsVisible && AutomationProperties.GetName(c) == "Skill"), "the skill box is still there")
                    ?? Expect(assistant.ModelChoices.Count >= 1 && assistant.ModelChoices[0].Id is null, "evidence mode is not the first choice")
                    ?? Expect(assistant.ModelChoices.Any(c => c.Id == "uitest-model"), "a provider's model is not listed");
                if (problem is not null)
                {
                    return problem;
                }
                var before = (await _main.Engine.Models.GetExplorerSettingsAsync()).ChatModelId;
                var other = assistant.ModelChoices.First(c => c.Id != before);
                box!.SelectedItem = other;
                await WaitForChatModelAsync(other.Id);
                problem = Expect((await _main.Engine.Models.GetExplorerSettingsAsync()).ChatModelId == other.Id, "choosing in the box did not set the chat model");
                box.SelectedItem = assistant.ModelChoices.First(c => c.Id == before);
                await WaitForChatModelAsync(before);
                return problem ?? Expect((await _main.Engine.Models.GetExplorerSettingsAsync()).ChatModelId == before, "choosing back did not restore the chat model");
            }
            finally
            {
                ai = await _main.Engine.Models.Ai.GetAsync();
                ai.Providers.RemoveAll(p => p.Id == "uitest-local");
                ai.Models.RemoveAll(m => m.ProviderId == "uitest-local");
                await _main.Engine.Models.Ai.SaveAsync(ai);
                await assistant.LoadAsync();
            }
        });
        await Step("Ask: a model that cannot be reached is named, and the answer comes from the index instead; Stop ends a slow answer", async () =>
        {
            _main.Navigate(Section.Documentation);
            await Settle();
            var assistant = _main.Workspace!.Assistant;
            // Two local providers of the walk's own: nothing listens on the first; the second accepts and never answers.
            var closed = new System.Net.Sockets.TcpListener(System.Net.IPAddress.Loopback, 0);
            closed.Start();
            var closedPort = ((System.Net.IPEndPoint)closed.LocalEndpoint).Port;
            closed.Stop();
            var silent = new System.Net.Sockets.TcpListener(System.Net.IPAddress.Loopback, 0);
            silent.Start();
            var silentPort = ((System.Net.IPEndPoint)silent.LocalEndpoint).Port;
            var held = new List<System.Net.Sockets.TcpClient>();
            _ = Task.Run(async () =>
            {
                try
                {
                    while (true)
                    {
                        held.Add(await silent.AcceptTcpClientAsync());
                    }
                }
                catch (Exception ex) when (ex is System.Net.Sockets.SocketException or ObjectDisposedException or InvalidOperationException)
                {
                    // stopped
                }
            });
            var chosen = (await _main.Engine.Models.GetExplorerSettingsAsync()).ChatModelId;
            var ai = await _main.Engine.Models.Ai.GetAsync();
            ai.Providers.Add(new Engine.Ai.AiProvider { Id = "uitest-down", Name = "UI test (down)", BaseUrl = $"http://127.0.0.1:{closedPort}", TimeoutSeconds = 10 });
            ai.Providers.Add(new Engine.Ai.AiProvider { Id = "uitest-silent", Name = "UI test (silent)", BaseUrl = $"http://127.0.0.1:{silentPort}", TimeoutSeconds = 60 });
            ai.Models.Add(new Engine.Ai.AiModel { Id = "uitest-down", ProviderId = "uitest-down", ProviderModelId = "uitest-down", DisplayName = "UI test (down)" });
            ai.Models.Add(new Engine.Ai.AiModel { Id = "uitest-silent", ProviderId = "uitest-silent", ProviderModelId = "uitest-silent", DisplayName = "UI test (silent)" });
            await _main.Engine.Models.Ai.SaveAsync(ai);
            try
            {
                await _main.Engine.Models.UpdateExplorerSettingsAsync(s => s.ChatModelId = "uitest-down");
                await assistant.LoadAsync();
                await Send(assistant, "What does DocGenVersion contain?");
                var answer = assistant.Messages.LastOrDefault();
                var problem = Expect(answer is { IsAssistant: true } && answer.Text.Contains("The model could not answer", StringComparison.Ordinal), $"the failure is not named: {answer?.Text}")
                    ?? Expect(answer!.Text.Contains("DocGenVersion", StringComparison.Ordinal), "no answer from the index")
                    ?? Expect(!answer.CanResend, "an answer from the index offers Try again");
                if (problem is not null)
                {
                    return problem;
                }
                // The failure was logged on purpose; anything logged from here on still counts.
                _errors.Clear();

                await _main.Engine.Models.UpdateExplorerSettingsAsync(s => s.ChatModelId = "uitest-silent");
                await assistant.LoadAsync();
                assistant.Input = "What does DocGenVersion contain?";
                assistant.SendCommand.Execute(null);
                await WaitAsync(() => assistant.IsBusy, 5);
                await Settle(800);
                problem = Expect(assistant.IsBusy, "the slow answer did not start") ?? await Click("Stop answering");
                await WaitAsync(() => !assistant.IsBusy, 15);
                await Settle(400);
                return problem ?? Expect(!assistant.IsBusy, "Stop did not end the answer")
                    ?? Expect(assistant.Messages.LastOrDefault()?.Text.EndsWith("_Stopped._", StringComparison.Ordinal) == true, $"not marked stopped: {assistant.Messages.LastOrDefault()?.Text}");
            }
            finally
            {
                if (assistant.IsBusy)
                {
                    assistant.StopCommand.Execute(null);
                    await WaitAsync(() => !assistant.IsBusy, 10);
                }
                silent.Stop();
                foreach (var client in held.ToList())
                {
                    client.Dispose();
                }
                await _main.Engine.Models.UpdateExplorerSettingsAsync(s => s.ChatModelId = chosen);
                ai = await _main.Engine.Models.Ai.GetAsync();
                ai.Providers.RemoveAll(p => p.Id.StartsWith("uitest-", StringComparison.Ordinal));
                ai.Models.RemoveAll(m => m.ProviderId.StartsWith("uitest-", StringComparison.Ordinal));
                await _main.Engine.Models.Ai.SaveAsync(ai);
                await assistant.LoadAsync();
                if (Find("Start a new conversation") is { IsEnabled: true })
                {
                    await Click("Start a new conversation");
                }
            }
        });
        await Step("Graph → Group, then Reset", async () =>
        {
            _main.Navigate(Section.Graph);
            await Settle(800);
            var graph = _main.Workspace!.Graph;
            var problem = await Click("Group");
            if (problem is not null)
            {
                return problem;
            }
            await WaitAsync(() => graph.IsGrouped && !graph.IsGrouping, 60);
            await Settle(800);
            problem = Expect(graph.IsGrouped, "the graph was not grouped")
                ?? Expect(graph.Groups.Count > 0, "grouped into no groups");
            return problem ?? await Click("Reset") ?? Expect(!graph.IsGrouped, "Reset left the graph grouped");
        });
        await Step("Graph → Show only a folder: the part is shown and its cards are big enough to read their names; Whole repository returns", async () =>
        {
            _main.Navigate(Section.Graph);
            await Settle(800);
            var graph = _main.Workspace!.Graph;
            graph.ScopeText = "Models";
            graph.ApplyScopeCommand.Execute(null);
            await WaitAsync(() => graph.IsScoped && !graph.IsScoping && !graph.IsLayingOut, 60);
            await Settle(800);
            var canvas = CaptureRunner.FindAll<GraphCanvas>(_window).FirstOrDefault(c => c.IsVisible);
            var problem = Expect(graph.IsScoped, "Show only did not narrow the graph: " + graph.ScopeSummary)
                ?? Expect(canvas is not null, "no graph canvas")
                ?? Expect(canvas!.Scale > GraphCanvas.LabelScale, $"the part is drawn at {canvas.Scale:0.00}, too small for its names");
            return problem ?? await Click("Whole repository") ?? Expect(!graph.IsScoped, "Whole repository left the graph narrowed");
        });
        await Step("Documentation → Export menu opens and closes", async () =>
        {
            _main.Navigate(Section.Documentation);
            await Settle();
            // The menu is the button's own context menu (it is not in the window's tree).
            var menu = (Find("Export") as FrameworkElement)?.ContextMenu;
            var problem = Expect(menu is not null, "the Export button has no menu") ?? await Click("Export");
            await Settle();
            var open = menu?.IsOpen == true;
            var items = menu?.Items.OfType<MenuItem>().Select(i => i.Header as string).Where(h => h is not null).ToList() ?? [];
            if (menu is not null)
            {
                menu.IsOpen = false;
            }
            _window.Focus();
            System.Windows.Input.Keyboard.ClearFocus();
            await Settle();
            return problem ?? Expect(open, "the Export menu did not open")
                ?? Expect(items.Contains("This page as PDF") && items.Contains("All documentation as Word (.docx)"), "menu items: " + string.Join(", ", items))
                ?? Expect(menu?.IsOpen == false, "the Export menu did not close");
        });
        await Step("Indexing → a space added by its address is listed by name with its site, not as an address; its remove button removes it", async () =>
        {
            _main.Navigate(Section.Indexing);
            await Settle();
            var indexing = _main.Workspace!.Indexing;
            if (CaptureRunner.FindAll<TextBox>(_window).FirstOrDefault(b => b.IsVisible && AutomationProperties.GetName(b) == "A space's address") is not { } box)
            {
                return "no box for a space's address";
            }
            box.Text = "https://confluence.example.com/spaces/TEAM/overview";
            System.Windows.Input.CommandManager.InvalidateRequerySuggested();
            await Settle();
            var problem = await Click("Add");
            await WaitAsync(() => indexing.ChosenSpaces.Count == 1, 5);
            await Settle(400);
            var card = indexing.ChosenSpaces.FirstOrDefault();
            problem ??= Expect(card is not null, "the added space is not listed")
                ?? Expect(card!.Name == "TEAM" && card.Detail == "TEAM · confluence.example.com" && card.Pages == "Not synced yet", $"listed as {card.Name} / {card.Detail} / {card.Pages}")
                ?? Expect(Find("Remove TEAM") is not null, "no remove button named for the space")
                ?? Expect(Find("Sync") is { IsEnabled: true }, "no Sync beside the chosen spaces");
            if (problem is not null)
            {
                return problem;
            }
            await CaptureRunner.Shoot(_window, _folder, "indexing-chosen-space", () => { }, 100);
            problem = await Click("Remove TEAM");
            await WaitAsync(() => indexing.ChosenSpaces.Count == 0, 5);
            return problem ?? Expect(indexing.ChosenSpaces.Count == 0, "the space stayed after Remove")
                ?? Expect((await _main.Engine.Repositories.GetAsync(_main.Workspace.Record.Id))!.ConfluenceSpaces.Count == 0, "the repository still searches it");
        });
        await Step("Settings → Confluence no longer lists spaces: it says they are chosen on the repository's Indexing page and goes there", async () =>
        {
            _main.Navigate(Section.Settings);
            await Settle();
            _main.Settings.ShowPage(SettingsPages.Confluence);
            await Settle(600);
            var title = _main.Workspace!.Record.Title;
            var problem = Expect(!CaptureRunner.FindAll<Controls.ConfluenceSpacePicker>(_window).Any(p => p.IsVisible), "the spaces list is still on Settings → Confluence")
                ?? await Click("Choose spaces for " + title);
            await Settle();
            return problem ?? Expect(_main.Section == Section.Indexing, $"went to {_main.Section}");
        });
        await Step("Indexing → Confluence sites and sign-in… opens Settings → Confluence", async () =>
        {
            _main.Navigate(Section.Indexing);
            await Settle();
            return await Click("Confluence sites and sign-in…") ?? Expect(_main.Section == Section.Settings && _main.Settings.Page == SettingsPages.Confluence, $"on {_main.Section} / {_main.Settings.Page}");
        });
        await Step("Indexing → Refresh changed files runs and finishes", async () =>
        {
            _main.Navigate(Section.Indexing);
            await Settle();
            var id = _main.Workspace!.Record.Id;
            var before = (await _main.Engine.Repositories.GetAsync(id))!.LastIndexedAt;
            var problem = await Click("Refresh changed files");
            await WaitAsync(() => _main.Engine.Indexing.IsRunning(id), 5);
            await WaitAsync(() => !_main.Engine.Indexing.IsRunning(id), 120);
            var after = (await _main.Engine.Repositories.GetAsync(id))!;
            return problem ?? Expect(after.Status == RepositoryStatus.Indexed, $"status {after.Status}")
                ?? Expect(after.LastIndexedAt is { } at && (before is null || at > before), "the refresh did not finish a run");
        });

        // 4. The repository menu.
        await Step("Repository menu opens and lists the repository", async () =>
            await Click("Repository menu") ?? Expect(_main.RepositoryMenuOpen, "menu did not open")
            ?? ExpectButton(_main.Workspace!.Title) ?? ExpectButton("Indexing of this repository") ?? ExpectButton("All repositories") ?? ExpectButton("Add repository…"));
        await Step("Repository menu → Indexing of this repository", async () =>
            await Click("Repository menu") ?? await Click("Indexing of this repository") ?? Expect(_main.Section == Section.Indexing, $"on {_main.Section}") ?? Expect(!_main.RepositoryMenuOpen, "menu stayed open"));
        await Step("Repository menu closes again when its button is pressed twice", async () =>
            await Click("Repository menu") ?? await Click("Repository menu") ?? Expect(!_main.RepositoryMenuOpen, "menu stayed open"));
        await Step("Repository menu → All repositories", async () =>
            await Click("Repository menu") ?? await Click("All repositories") ?? Expect(_main.Section == Section.Repositories, $"on {_main.Section}"));
        await Step("Repositories → Open the card", async () =>
            await Click("Open") ?? Expect(_main.Section == Section.Documentation && _main.Workspace is not null, $"on {_main.Section}"));
        await Step("Repository menu → Add repository… shows the add form", async () =>
            await Click("Repository menu") ?? await Click("Add repository…") ?? Expect(_main.Section == Section.Repositories, $"on {_main.Section}") ?? Expect(Find("Add and index") is not null, "no add form"));

        await Step("Repositories with a repository: one Add repository button; it opens the form and hides itself; Close puts it back", async () =>
        {
            _main.Navigate(Section.Repositories);
            await Settle();
            var problem = Expect(Find("Add and index") is null, "the add form is open before it was asked for") ?? ExpectButton("Add repository")
                ?? await Click("Add repository") ?? Expect(Find("Add and index") is not null, "the form did not open")
                ?? Expect(Find("Add repository") is null, "the Add repository button stayed next to the open form")
                ?? await Click("Close the add form") ?? Expect(Find("Add and index") is null && Find("Add repository") is not null, "Close did not put the button back");
            return problem;
        });
        await Step("Documentation: Copy ▾ and Export ▾ menus instead of separate Copy link / Copy Markdown / Download buttons", async () =>
        {
            await _main.OpenRepositoryAsync(_main.Workspace!.Record, Section.Documentation);
            await Settle(600);
            var page = CaptureRunner.FindAll<Views.DocumentationView>(_window).FirstOrDefault(v => v.IsVisible);
            if (page is null)
            {
                return "the documentation page is not shown";
            }
            var separate = CaptureRunner.FindAll<ButtonBase>(page).Where(b => b.IsVisible).Select(b => Label(b))
                .Where(l => l is "Copy link" or "Copy Markdown" or "Download").ToList();
            var problem = Expect(separate.Count == 0, "still there: " + string.Join(", ", separate))
                ?? ExpectButton("Copy") ?? ExpectButton("Export") ?? ExpectButton("Ask");
            if (problem is null && Find("Copy") is { ContextMenu: { } copy })
            {
                problem = Expect(copy.Items.OfType<MenuItem>().Count() == 2, "Copy menu items: " + copy.Items.Count);
            }
            if (problem is null && Find("Export") is { ContextMenu: { } export })
            {
                problem = Expect(export.Items.OfType<MenuItem>().Any(i => (i.Header as string)?.Contains("Markdown") == true), "Export has no Markdown");
            }
            return problem;
        });

        // 5. A second repository, not indexed: switching to it, and its empty pages.
        var second = Path.Combine(Path.GetTempPath(), "docgen-uitest-" + Guid.NewGuid().ToString("N")[..8]);
        CopyFolder(samplePath, second);
        var secondRecord = await _main.Engine.Repositories.AddLocalAsync(second, "Not indexed yet");
        var firstRecord = _main.Workspace?.Record ?? (await _main.Engine.Repositories.ListAsync()).First(r => r.Id != secondRecord.Id);
        await _main.OpenRepositoryAsync(firstRecord, Section.Graph);
        await Settle();
        await Step("Repository menu switches repository and keeps the section", async () =>
            await Click("Repository menu") ?? await Click("Not indexed yet")
            ?? await WaitForAsync(() => _main.Workspace?.Record.Id == secondRecord.Id, "did not switch")
            ?? Expect(_main.Section == Section.Graph, $"on {_main.Section}"));
        await Step("A repository that was never indexed is indexed when it is opened", async () =>
        {
            await WaitAsync(() => !_main.Engine.Indexing.IsRunning(secondRecord.Id), 120);
            return Expect((await _main.Engine.Repositories.GetAsync(secondRecord.Id))?.Status == RepositoryStatus.Indexed, "it stayed unindexed");
        });
        foreach (var section in new[] { Section.Documentation, Section.Graph, Section.Learning, Section.Studio, Section.Indexing })
        {
            await Step($"The newly indexed repository: {section} loads", async () =>
            {
                _main.Navigate(section);
                await Settle(600);
                return Expect(_main.Section == section, $"on {_main.Section}");
            });
        }

        // 6. A repository whose folder has gone.
        var gone = Path.Combine(Path.GetTempPath(), "docgen-uitest-gone-" + Guid.NewGuid().ToString("N")[..8]);
        CopyFolder(samplePath, gone);
        var goneRecord = await _main.Engine.Repositories.AddLocalAsync(gone, "Folder removed");
        DeleteFolder(gone);
        await _main.OpenRepositoryAsync(goneRecord, Section.Indexing);
        await Settle();
        await Step("A repository whose folder was deleted: indexing fails with a message, and the header still leads away", async () =>
        {
            _errors.Clear();
            await _main.Engine.Indexing.RunAsync(goneRecord.Id, IndexMode.Full);
            await _main.Repositories.RefreshAsync();
            _main.Navigate(Section.Documentation);
            await Settle(600);
            _errors.Clear(); // the failure itself is expected and reported on the page
            return ExpectAnyButton("Index now", "Watch it on the Indexing page") ?? await Click("Repository menu") ?? await Click("All repositories")
                ?? Expect(_main.Section == Section.Repositories, $"on {_main.Section}");
        });

        // 7. Dialogs on the Repositories page can be cancelled.
        await Step("Repositories → Remove all… asks first; Cancel keeps everything", async () =>
        {
            _main.Navigate(Section.Repositories);
            await Settle();
            var before = (await _main.Engine.Repositories.ListAsync()).Count;
            return await Click("Remove all") ?? Expect(_main.Dialog is not null, "no confirmation") ?? await Click("Cancel")
                ?? Expect(_main.Dialog is null, "dialog stayed") ?? Expect((await _main.Engine.Repositories.ListAsync()).Count == before, "something was removed");
        });
        await Step("Repositories → Remove (card) asks first; Cancel keeps it", async () =>
        {
            var before = (await _main.Engine.Repositories.ListAsync()).Count;
            return await Click("Remove this repository") ?? Expect(_main.Dialog is not null, "no confirmation") ?? await Click("Cancel")
                ?? Expect((await _main.Engine.Repositories.ListAsync()).Count == before, "something was removed");
        });

        // 8. Search opens and closes.
        await _main.OpenRepositoryAsync(firstRecord, Section.Documentation);
        await Settle();
        await Step("Search shows results and closes again", async () =>
        {
            _main.SearchQuery = "average";
            await WaitAsync(() => _main.IsSearchOpen, 5);
            var opened = _main.IsSearchOpen;
            _main.CloseSearchCommand.Execute(null);
            await Settle();
            return Expect(opened, "results did not open") ?? Expect(!_main.IsSearchOpen, "results stayed open");
        });

        // 8b. Talk, and an answer's Download.
        async Task Send(AssistantViewModel vm, string text)
        {
            vm.Input = text;
            vm.SendCommand.Execute(null);
            for (var i = 0; i < 600 && (vm.IsBusy || vm.Input.Length > 0); i++)
            {
                await Task.Delay(100);
            }
            await Settle(600);
        }
        await Step("Talk opens on a persona's greeting and starter questions", async () =>
        {
            _main.Navigate(Section.Talk);
            await Settle(900);
            var talk = _main.Workspace!.Talk;
            var switcher = CaptureRunner.FindAll<ComboBox>(_window).Any(c => c.IsVisible && c.IsEnabled && AutomationProperties.GetName(c) == "Switch persona");
            return !talk.HasGreeting || talk.Suggestions.Count < 3 ? "no greeting or starter questions" : switcher ? null : "no persona switcher";
        });
        await Step("Talk: a greeting gets a short reply; switching persona keeps the conversation", async () =>
        {
            var talk = _main.Workspace!.Talk;
            await Send(talk, "Good morning!");
            if (talk.Messages.LastOrDefault() is not { IsAssistant: true } reply || !reply.Text.StartsWith("Good morning", StringComparison.Ordinal))
            {
                return "no reply to the greeting";
            }
            var count = talk.Messages.Count;
            talk.Persona = DocGen.Explorer.Engine.Assistant.TalkPersonas.Find("detective");
            await Settle();
            return talk.Messages.Count == count + 1 && talk.Messages[^1].IsNotice && talk.Title == "Code Detective" ? null : "the switch lost the conversation or was not noted";
        });
        await Step("Docs → select part of the page → Summarise selection answers in Ask", async () =>
        {
            _main.Navigate(Section.Documentation);
            await Settle(900);
            if (CaptureRunner.FindAll<FlowDocumentScrollViewer>(_window).FirstOrDefault(v => v.IsVisible && v.Name == "Viewer") is not { Document: { } document } page)
            {
                return "no page";
            }
            var from = document.ContentStart.GetPositionAtOffset(40) ?? document.ContentStart;
            page.Selection.Select(from, from.GetPositionAtOffset(700) ?? document.ContentEnd);
            var ask = _main.Workspace!.Assistant;
            var before = ask.Messages.Count;
            await SummariseSelection.SummariseAsync(page);
            await WaitAsync(() => !ask.IsBusy, 30);
            await Settle();
            return ask.Messages.Count == before + 2 && ask.Messages[^1].Text.Length > 20 && ask.Messages[^2].Text.StartsWith("Summarise this passage", StringComparison.Ordinal)
                ? null : $"no summary ({ask.Messages.Count - before} new messages)";
        });
        await Step("A C# solution's architecture diagram (layers, styles, the integrations hub) is drawn by mermaid.js with the ELK layout", async () =>
        {
            var projects = new List<DocGen.Analysis.Indexing.ProjectInfo>();
            void Add(string name, string? output, params string[] references)
                => projects.Add(new DocGen.Analysis.Indexing.ProjectInfo { Name = name, Path = $"src/{name}/{name}.csproj", OutputType = output,
                    ProjectReferences = references.Select(r => $"src/{r}/{r}.csproj").ToList() });
            // An enterprise service as real solutions are: hosts and wiring reference far more than they need to.
            string[] proxies = ["Proxy.Billing", "Proxy.Catalogue", "Proxy.Customer", "Proxy.Inventory", "Proxy.Pricing", "Proxy.Shipping", "Proxy.Tax"];
            Add("OrderingHost", "Exe", "HostCommon", "OrderDomain.Repository", "OrderDomain.DataStores", "UtilityComponent", "OrderDomain.Model", "Ordering.Messaging");
            Add("EventReceiverHost", "Exe", "OrderDomain.DataStores", "HostCommon", "UtilityComponent", "Ordering.Messaging");
            Add("HostCommon", null, ["Request.Listener", "OrderDomain.Services", "AuditDomain.Services", "OrderDomain.Repository", "OrderDomain.Infrastructure",
                .. proxies, "OrderDomain.Model", "CatalogueDomain.Model", "CatalogueDomain.Types", "UtilityComponent", "Ordering.Messaging"]);
            Add("Request.Listener", null, "OrderDomain.Services", "OrderDomain.Repository", "OrderDomain.Infrastructure", "OrderDomain.Model", "CatalogueDomain.Types", "UtilityComponent");
            Add("OrderDomain.Services", null, [.. proxies, "OrderDomain.Infrastructure", "OrderDomain.Model", "UtilityComponent"]);
            Add("AuditDomain.Services", null, "AuditDomain.Model", "Ordering.Messaging", "UtilityComponent");
            Add("OrderDomain.Repository", null, "OrderDomain.DataStores", "OrderDomain.Model", "UtilityComponent");
            Add("OrderDomain.Infrastructure", null, "OrderDomain.Model", "UtilityComponent");
            Add("OrderDomain.DataStores", null, "UtilityComponent");
            Add("OrderDomain.Model", null, "CatalogueDomain.Model", "Ordering.Messaging", "UtilityComponent");
            Add("AuditDomain.Model", null, "UtilityComponent");
            Add("CatalogueDomain.Types", null, "OrderDomain.Model", "UtilityComponent");
            Add("CatalogueDomain.Model", null, "UtilityComponent");
            foreach (var proxy in proxies)
            {
                Add(proxy, null, "CatalogueDomain.Model", "UtilityComponent");
            }
            Add("Ordering.Messaging", null, "UtilityComponent");
            Add("UtilityComponent", null);
            var code = new DocGen.Analysis.Indexing.CodeIndex(new DocGen.Analysis.Indexing.IndexManifest { Projects = projects }, [], "C:/repo");
            var answer = Engine.Search.SolutionArchitectureDiagram.Build(code);
            var mermaid = answer is null ? "" : System.Text.RegularExpressions.Regex.Match(answer, "```mermaid\n(.*?)\n```", System.Text.RegularExpressions.RegexOptions.Singleline).Groups[1].Value;
            if (!mermaid.Contains("OrderDomain_Services --> Integrations_All", StringComparison.Ordinal) || !mermaid.Contains("layout: elk", StringComparison.Ordinal))
            {
                return "the diagram was not generated as expected";
            }
            var image = await Controls.MermaidRenderer.RenderAsync(mermaid, dark: false);
            if (image.Image is { } picture)
            {
                // The drawing itself, for looking at the layout.
                var encoder = new System.Windows.Media.Imaging.PngBitmapEncoder();
                encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(picture));
                await using var file = File.Create(Path.Combine(_folder, "architecture-diagram.png"));
                encoder.Save(file);
                await File.WriteAllTextAsync(Path.Combine(_folder, "architecture-diagram.svg"), image.Svg ?? "");
            }
            return !Controls.MermaidRenderer.ElkAvailable ? "the ELK layout engine did not load"
                : image.Error is { } error ? "mermaid.js could not draw it: " + error
                : image.Image is null || image.Width < 200 ? "nothing was drawn"
                : null;
        });

        await Step("Ask → Test Fix: off by default (no 🧪); turned on in Settings → Skills, 🧪 opens its panel with tests, configuration and command; Close shuts it", async () =>
        {
            _main.Navigate(Section.Documentation);
            await Settle();
            var ask = _main.Workspace!.Assistant;
            await ask.LoadSkillsAsync();
            await Settle();
            var problem = Expect(!ask.CanTestFix && Find("Test Fix") is not { IsVisible: true }, "Test Fix is offered before it is turned on");
            await _main.Engine.Skills.SetEnabledAsync("test-fix", true);
            try
            {
                await ask.LoadSkillsAsync();
                await Settle(600);
                problem ??= Expect(ask.CanTestFix, "turning the skill on did not offer Test Fix") ?? await Click("Test Fix");
                await WaitAsync(() => ask.TestFixConfigurations.Count > 0, 20);
                await Settle(600);
                problem ??= Expect(ask.IsTestFixMode, "🧪 did not open Test Fix")
                    ?? Expect(Field<TextBox>("Tests to run"), "no box for the tests to run")
                    ?? Expect(Field<TextBox>("Test command"), "no box for the test command")
                    ?? Expect(Field<ComboBox>("Configuration"), "no configuration box")
                    ?? Expect(ask.TestFixConfigurations.Count > 0, "the repository's configurations are not offered")
                    ?? Expect(ask.InputHint.StartsWith("Describe the failure", StringComparison.Ordinal), "the question box does not ask for the failure");
                // A configuration can be chosen from the list (and shows), or typed.
                if (problem is null && FindField<ComboBox>("Configuration") is { } configurations)
                {
                    configurations.SelectedIndex = configurations.Items.Count - 1;
                    await Settle(200);
                    var chosen = configurations.SelectedItem as string ?? "";
                    var editor = configurations.Template.FindName("PART_EditableTextBox", configurations) as TextBox;
                    problem = Expect(chosen.Length > 0 && ask.TestFixConfiguration == chosen, $"choosing a configuration did not set it ({ask.TestFixConfiguration})")
                        ?? Expect(editor is { IsVisible: true } && editor.Text == chosen, "the chosen configuration does not show in the box");
                    await Settle(200);
                    await CaptureRunner.Shoot(_window, _folder, "test-fix-configuration", () => { }, 100);
                    configurations.Text = "QADebug";
                    await Settle(200);
                    problem ??= Expect(ask.TestFixConfiguration == "QADebug", "a typed configuration was not taken");
                    ask.TestFixConfiguration = "";
                }
                await CaptureRunner.Shoot(_window, _folder, "test-fix-panel", () => { }, 100);
                problem ??= await Click("Close Test Fix");
                await Settle();
                return problem ?? Expect(!ask.IsTestFixMode, "Close left Test Fix open");
            }
            finally
            {
                ask.IsTestFixMode = false;
                await _main.Engine.Skills.SetEnabledAsync("test-fix", false);
                await ask.LoadSkillsAsync();
            }
        });
        await Step("Ask → attached files: a log is read, a zip is attached as not supported; both go with the question and show on it", async () =>
        {
            _main.Navigate(Section.Documentation);
            _main.AssistantVisible = true;
            var ask = _main.Workspace!.Assistant;
            var folder = Path.Combine(_folder, "attachments");
            Directory.CreateDirectory(folder);
            var log = Path.Combine(folder, "failure.log");
            await File.WriteAllTextAsync(log, "Unhandled exception in Message.Validate: the role is missing");
            var zip = Path.Combine(folder, "bundle.zip");
            await File.WriteAllBytesAsync(zip, [0x50, 0x4B, 0x03, 0x04, 0, 0, 0, 1, 2, 3]);
            // A large picture: scaled down to the longest side set (1568 px), shown as a thumbnail.
            var big = Path.Combine(folder, "screenshot.png");
            var visual = new System.Windows.Media.DrawingVisual();
            using (var dc = visual.RenderOpen())
            {
                dc.DrawRectangle(new System.Windows.Media.LinearGradientBrush(System.Windows.Media.Colors.SteelBlue, System.Windows.Media.Colors.Gold, 30), null, new Rect(0, 0, 3000, 2000));
                dc.DrawEllipse(System.Windows.Media.Brushes.White, null, new Point(1500, 1000), 600, 400);
            }
            var bitmap = new System.Windows.Media.Imaging.RenderTargetBitmap(3000, 2000, 96, 96, System.Windows.Media.PixelFormats.Pbgra32);
            bitmap.Render(visual);
            var encoder = new System.Windows.Media.Imaging.PngBitmapEncoder();
            encoder.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(bitmap));
            await using (var file = File.Create(big))
            {
                encoder.Save(file);
            }
            await ask.AttachAsync([log, zip, big]);
            await Settle(400);
            var picture = ask.PendingAttachments.FirstOrDefault(c => c.Name == "screenshot.png");
            if (ask.PendingAttachments.Count != 3 || ask.PendingAttachments.Count(c => c.IsProblem) != 1
                || ask.PendingAttachments.First(c => c.IsProblem).CardDetail != "not supported")
            {
                return "the attachments were not shown as expected: " + string.Join(", ", ask.PendingAttachments.Select(c => $"{c.Name} ({c.Detail})"));
            }
            if (picture is not { HasThumbnail: true } || picture.Attachment.Note?.Contains("Scaled from 3000×2000 to 1568×1045", StringComparison.Ordinal) != true)
            {
                return "the large image was not scaled and shown: " + picture?.Attachment.Note;
            }
            // Its remove button appears on hover; here, it is pressed through the command.
            if (CaptureRunner.FindAll<Button>(_window).FirstOrDefault(b => b.Name == "Remove" && b.IsVisible) is null)
            {
                return "the attachment cards have no remove button";
            }
            await CaptureRunner.Shoot(_window, _folder, "attachments-pending", () => { }, 50);
            await Send(ask, "What went wrong?");
            await Settle(500);
            var question = ask.Messages.LastOrDefault(m => m.IsUser);
            var answer = ask.Messages.LastOrDefault();
            await CaptureRunner.Shoot(_window, _folder, "attachments-sent", () => { }, 50);
            return ask.HasPendingAttachments ? "the attachments stayed in the box after sending"
                : question is not { HasAttachments: true } || question.Attachments.Count != 3 ? "the question does not show its attachments"
                : answer is not { IsAssistant: true } || !answer.Text.Contains("failure.log", StringComparison.Ordinal) ? "the answer does not mention the attached file"
                : null;
        });

        await Step("Help: the home has topics and popular articles; search finds articles; an article shows its mockup, Was this helpful? and related articles", async () =>
        {
            _main.Navigate(Section.Help);
            var help = _main.Help;
            help.HomeCommand.Execute(null);
            await Settle(600);
            await CaptureRunner.Shoot(_window, _folder, "help-home", () => { }, 50);
            if (help.Topics.Count < 8 || help.Popular.Count < 4)
            {
                return "the help home has too few topics or popular articles";
            }
            var broken = new[] { "window", "attach", "dictate", "readaloud", "search", "recognition", "diagram", "architecture" }
                .Where(n => Controls.SvgDrawing.Illustration(n) is null).ToList();
            if (broken.Count > 0)
            {
                return "these illustrations could not be drawn: " + string.Join(", ", broken);
            }
            help.Query = "microphone";
            await Settle(400);
            await CaptureRunner.Shoot(_window, _folder, "help-search", () => { }, 50);
            if (help.Results.Count == 0 || help.Results[0].Id != "dictate")
            {
                return "searching for microphone did not find the dictation article first: " + string.Join(", ", help.Results.Select(r => r.Id));
            }
            help.OpenArticleCommand.Execute(help.Results[0]);
            await Settle(600);
            await CaptureRunner.Shoot(_window, _folder, "help-article", () => { }, 50);
            if (!help.IsArticle || help.Article is not { HasPicture: true } || !help.HasRelated || help.IsSearching)
            {
                return "the article page is not shown as expected";
            }
            help.HelpfulCommand.Execute("yes");
            if (help.Asking)
            {
                return "Was this helpful? did not thank";
            }
            var next = help.Next;
            if (next is null || help.Previous is null)
            {
                return "an article in the middle has no next or previous";
            }
            help.OpenArticleCommand.Execute(next);
            await Settle(300);
            if (help.Article != next || !help.Asking)
            {
                return "Next did not open the next article (with a fresh Was this helpful?)";
            }
            help.OpenTopicCommand.Execute(help.Topics[0]);
            await Settle(400);
            return help.IsTopic ? null : "a topic did not open";
        });
        await Step("Help: a question typed in the search box and asked gets an answer card with where and how; its Indexing link opens the repository's Indexing page", async () =>
        {
            _main.Navigate(Section.Help);
            var help = _main.Help;
            help.HomeCommand.Execute(null);
            await Settle(400);
            // Typed into the search box, as a user would, then Ask.
            if (CaptureRunner.FindAll<TextBox>(_window).FirstOrDefault(b => b.IsVisible && AutomationProperties.GetName(b) == "Search help") is not { } box)
            {
                return "no help search box";
            }
            box.Text = "where do I add a Confluence space to a repository";
            await Settle();
            var problem = await Click("Ask help");
            if (problem is not null)
            {
                return problem;
            }
            await WaitAsync(() => help.HasAnswer && !help.IsThinking, 60);
            await Settle(500);
            await CaptureRunner.Shoot(_window, _folder, "help-answer", () => { }, 50);
            problem = Expect(help.Answer is { Covered: true }, "no answer card")
                ?? Expect(help.Answer!.Places.Any(p => p.Link == "explorer:section/indexing"), "the answer does not link the Indexing page: " + string.Join(", ", help.Answer.Places.Select(p => p.Link)))
                ?? Expect(help.Answer.Markdown.Contains("Indexing of this repository", StringComparison.Ordinal), "the answer does not say where")
                ?? ExpectButton("Indexing of this repository");
            return problem ?? await Click("Indexing of this repository")
                ?? Expect(_main.Section == Section.Indexing, $"the link went to {_main.Section}")
                ?? Expect(Find("Confluence sites and sign-in…") is not null, "the Indexing page has no Confluence section");
        });

        await Step("Settings → Attachments lists each kind with its limits; Settings → Voice has the microphone options", async () =>
        {
            _main.Navigate(Section.Settings);
            var settings = _main.Settings;
            settings.ShowPage(ViewModels.SettingsPages.Attachments);
            await Settle(500);
            await CaptureRunner.Shoot(_window, _folder, "settings-attachments", () => { }, 50);
            if (settings.AttachmentRules.Count != 4 || settings.AttachmentRules.Any(r => !r.Enabled))
            {
                return "the kinds of attachment are not listed";
            }
            // A changed limit is saved; Restore the defaults puts it back.
            settings.AttachmentRules[0].MaxChars = "1234";
            settings.AttachmentRules[3].MaxPixels = "1000";
            await Settle(500);
            var saved = await _main.Engine.Models.GetExplorerSettingsAsync();
            if (Engine.Assistant.Attachments.RuleFor(saved.AttachmentRules, "text").MaxChars != 1234
                || Engine.Assistant.Attachments.RuleFor(saved.AttachmentRules, "image").MaxPixels != 1000)
            {
                return "a changed attachment limit was not saved";
            }
            settings.ResetAttachmentRulesCommand.Execute(null);
            await Settle(500);
            if (Engine.Assistant.Attachments.RuleFor((await _main.Engine.Models.GetExplorerSettingsAsync()).AttachmentRules, "text").MaxChars != 60_000)
            {
                return "Restore the defaults did not restore the attachment limits";
            }
            settings.ShowPage(ViewModels.SettingsPages.Voice);
            await Settle(500);
            await CaptureRunner.Shoot(_window, _folder, "settings-microphone", () => { }, 50);
            Logging.Info($"Microphones: {string.Join("; ", settings.MicrophoneChoices)}; languages: {string.Join(", ", settings.DictationLanguageChoices)}");
            if (settings.MicrophoneChoices.Count == 0 || settings.MicrophoneModeChoices.Count != 2)
            {
                return "the microphone options are missing";
            }
            // The defaults: Whisper first, click to start and stop first, stop after 5 s of silence.
            if (!settings.DictationEngineChoices[0].StartsWith("Whisper", StringComparison.Ordinal) || !settings.MicrophoneModeChoices[0].StartsWith("Click", StringComparison.Ordinal)
                || !_main.Speech.MicrophoneToggles || settings.SilenceStopSeconds != 5)
            {
                return "the microphone defaults are not Whisper, click to start and stop, and 5 s of silence";
            }
            // Dictation starts and stops with the chosen microphone (recorded here, passed to Windows speech recognition).
            foreach (var microphone in settings.MicrophoneChoices.Take(2))
            {
                settings.Microphone = microphone;
                if (!await _main.Speech.StartDictationAsync())
                {
                    Logging.Info($"Dictation could not start with {microphone} (no recogniser or microphone here).");
                    continue;
                }
                await Task.Delay(1200);
                var level = _main.Speech.MicrophoneLevel;
                var heard = await _main.Speech.StopDictationAsync();
                Logging.Info($"Dictation with {microphone}: level {level:0.000}, heard '{heard}'");
            }
            settings.Microphone = Microphone.WindowsDefault;

            // Whisper on this PC: its model is listed (installed or not); dictation records and transcribes when stopped.
            settings.DictationEngine = settings.DictationEngineChoices[0]; // Whisper (first, and the default)
            await Settle(400);
            await CaptureRunner.Shoot(_window, _folder, "settings-whisper", () => { }, 50);
            Logging.Info($"Whisper: {settings.WhisperModelStatus}");
            if (!settings.DictationIsWhisper || settings.WhisperModels.Count < 3)
            {
                return "the Whisper choice or its models are missing";
            }
            if (settings.WhisperModelInstalled)
            {
                if (!await _main.Speech.StartDictationAsync())
                {
                    return "Whisper dictation did not start with the model installed";
                }
                await Task.Delay(1500);
                var said = await _main.Speech.StopDictationAsync();
                Logging.Info($"Whisper dictation heard '{said}'");
            }
            settings.DictationEngine = settings.DictationEngineChoices[0];

            // Test microphone finishes (its button comes back), whatever Windows does.
            var test = settings.TestMicrophoneCommand;
            test.Execute(null);
            await Task.Delay(300);
            await WaitAsync(() => test.CanExecute(null), 30);
            Logging.Info($"Test microphone: {settings.MicrophoneTest}");
            if (!test.CanExecute(null) || settings.TestingMicrophone)
            {
                return "Test microphone did not finish (its button stayed disabled)";
            }

            // Silence: with nothing said for the seconds set, dictation in Ask stops by itself.
            settings.SilenceStopSeconds = 2;
            var asking = _main.Workspace!.Assistant;
            await asking.StartRecordingAsync();
            if (asking.IsRecording)
            {
                var started = DateTime.UtcNow;
                await WaitAsync(() => !asking.IsRecording, 20);
                Logging.Info($"Silence stop: recording {(asking.IsRecording ? "still on" : $"stopped after {(DateTime.UtcNow - started).TotalSeconds:0.0} s")}");
                if (asking.IsRecording)
                {
                    var level = _main.Speech.MicrophoneLevel;
                    await asking.StopRecordingAsync();
                    // Only a voice (well above the room's noise) may keep it listening.
                    if (level < 0.15)
                    {
                        return $"dictation did not stop after the seconds of silence set (level {level:0.000})";
                    }
                }
            }
            settings.SilenceStopSeconds = 5;

            // Dictation off: no microphone button in Ask; on again: it shows when a microphone can be used.
            settings.DictationEnabled = false;
            _main.Navigate(Section.Documentation);
            _main.AssistantVisible = true;
            await Settle(500);
            var mic = CaptureRunner.FindAll<Button>(_window).FirstOrDefault(b => b.Name == "MicButton");
            var hidden = mic is not { IsVisible: true };
            settings.DictationEnabled = true;
            await Settle(400);
            var shown = mic is { IsVisible: true } == _main.CanDictate;
            return !hidden ? "the microphone button still shows with dictation off"
                : !shown ? "the microphone button does not follow whether a microphone can be used"
                : null;
        });

        await Step("Ask → Read aloud highlights the word being said (only ever forward); the reading bar's Pause holds it, Resume carries on, Stop clears it", async () =>
        {
            _main.Navigate(Section.Documentation);
            _main.AssistantVisible = true;
            var ask = _main.Workspace!.Assistant;
            await Send(ask, "What is Message?");
            if (ask.Messages.LastOrDefault() is not { IsAssistant: true } answer
                || CaptureRunner.FindAll<Controls.MarkdownBlock>(_window).LastOrDefault(b => b.IsVisible && b.Markdown == answer.Text) is not { } shown)
            {
                return "no answer shown";
            }
            if (waveOutGetNumDevs() == 0)
            {
                // A build server: nothing to play to, so nothing is said and no word is highlighted.
                _note = "not checked: this PC has no audio output";
                return null;
            }
            var speech = _main.Speech;
            try
            {
                answer.ReadAloudCommand.Execute(null);
                await WaitAsync(() => shown.Highlight.Word is not null, 25);
                if (shown.Highlight.Word is null)
                {
                    return "no word was highlighted while reading";
                }
                await Settle(700);
                Logging.Info("Read aloud: " + shown.Highlight.Describe());
                if (!shown.Highlight.InView())
                {
                    return "the word being read is not in view: " + shown.Highlight.Describe();
                }
                await CaptureRunner.Shoot(_window, _folder, "read-aloud-highlight", () => { }, 50);
                // The reading bar: in view wherever one scrolls, with its own Pause.
                if (_window.FindName("ReadingBar") is not FrameworkElement bar || !bar.IsVisible || !_main.IsReadingAloud)
                {
                    return "the reading bar (Pause, Stop) is not shown while reading";
                }
                _main.ReadingPauseCommand.Execute(null);
                if (!speech.IsPaused || answer.PauseText != "Resume" || _main.ReadingPauseText != "Resume")
                {
                    return "Pause (in the reading bar) did not pause";
                }
                await Settle(300);
                var held = shown.Highlight.Word;
                await Settle(1200);
                if (shown.Highlight.Word != held)
                {
                    return "the highlight moved on while paused";
                }
                answer.PauseCommand.Execute(null);
                if (speech.IsPaused)
                {
                    return "Resume did not carry on";
                }
                // The highlight moves forward word by word: never back to an earlier copy of a word.
                var last = shown.Highlight.ShownIndex;
                for (var t = 0; t < 30; t++)
                {
                    await Task.Delay(50);
                    var now = shown.Highlight.ShownIndex;
                    if (now >= 0 && now < last)
                    {
                        return $"the highlight jumped back (word {last} to {now})";
                    }
                    last = Math.Max(last, now);
                }
                var after = shown.Highlight.Word;
                _main.ReadingStopCommand.Execute(null); // Stop, from the reading bar
                await Settle(400);
                if (_main.IsReadingAloud || bar.IsVisible)
                {
                    return "the reading bar stayed after Stop";
                }
                return shown.Highlight.Word is not null ? "the highlight stayed after Stop"
                    : answer.IsSpeaking ? "still reading after Stop"
                    : after is null ? "nothing was highlighted after Resume"
                    : null;
            }
            finally
            {
                speech.Stop();
            }
        });

        await Step("Ask → a diagram's Summarise writes the summary under it, kept with that answer", async () =>
        {
            _main.Navigate(Section.Documentation);
            _main.AssistantVisible = true;
            var ask = _main.Workspace!.Assistant;
            await Send(ask, "Generate a Mermaid diagram of what Message depends on.");
            if (ask.Messages.LastOrDefault() is not { IsAssistant: true } answer
                || CaptureRunner.FindAll<Controls.DiagramViewer>(_window).LastOrDefault(v => v.IsVisible) is not { SummariseRequested: { } summarise })
            {
                return "no diagram in the answer";
            }
            var count = ask.Messages.Count;
            summarise();
            await WaitAsync(() => answer.Message.DiagramSummaries is { Count: > 0 }, 30);
            await Settle(600);
            return answer.Message.DiagramSummaries is not { Count: > 0 } ? "no summary kept with the answer"
                : ask.Messages.Count != count ? "a new turn was added instead"
                : null;
        });
        await Step("Ask → a diagram's Download, inline and full screen, opens its formats: SVG, PNG, JPEG, BMP, GIF, TIFF and the Mermaid source", async () =>
        {
            _main.Navigate(Section.Documentation);
            _main.AssistantVisible = true;
            await Settle();
            if (CaptureRunner.FindAll<Controls.DiagramViewer>(_window).LastOrDefault(v => v.IsVisible) is not { } viewer)
            {
                return "no diagram on screen";
            }
            async Task<string?> OpenDownload(Controls.DiagramViewer on, string where)
            {
                var button = CaptureRunner.FindAll<Button>(on).FirstOrDefault(b => AutomationProperties.GetName(b) == "Download the diagram");
                if (button is null)
                {
                    return $"{where}: no Download button";
                }
                // As a click: through UI Automation, so the button's own Click runs.
                (new ButtonAutomationPeer(button).GetPattern(PatternInterface.Invoke) as IInvokeProvider)!.Invoke();
                await Settle(400);
                var menu = on.DownloadOpen;
                var items = menu?.Items.OfType<MenuItem>().Select(i => (i.Header as string ?? "").Split(' ')[0]).ToList() ?? [];
                var open = menu?.IsOpen == true;
                if (menu is not null)
                {
                    menu.IsOpen = false;
                }
                await Settle();
                return Expect(open, $"{where}: the Download menu did not open")
                    ?? Expect(new[] { "SVG", "PNG", "JPEG", "BMP", "GIF", "TIFF", "Mermaid" }.All(items.Contains), $"{where}: menu items {string.Join(", ", items)}")
                    ?? Expect(menu!.Items.OfType<MenuItem>().Where(i => (i.Header as string ?? "") is "PNG" or "JPEG" or "BMP").All(i => i.IsEnabled), $"{where}: the picture formats are disabled");
            }
            var problem = await OpenDownload(viewer, "inline");
            if (problem is not null)
            {
                return problem;
            }
            viewer.ShowFullScreen();
            await Settle(1200);
            if (Application.Current.Windows.OfType<Window>().LastOrDefault(w => w.Content is Controls.DiagramViewer) is not { } full)
            {
                return "full screen did not open";
            }
            try
            {
                return await OpenDownload((Controls.DiagramViewer)full.Content, "full screen");
            }
            finally
            {
                full.Close();
                await Settle();
            }
        });
        await Step("Ask → the question rail: a bar per question; pointing at it lists them by their first words; choosing one scrolls to it", async () =>
        {
            _main.Navigate(Section.Documentation);
            _main.AssistantVisible = true;
            var ask = _main.Workspace!.Assistant;
            if (Find("Start a new conversation") is { IsEnabled: true })
            {
                await Click("Start a new conversation");
            }
            string[] questions = ["What does DocGenVersion contain?", "What is Message?", "Explain the architecture of this repository."];
            foreach (var question in questions)
            {
                await Send(ask, question);
            }
            await Settle(600);
            if (CaptureRunner.FindAll<Controls.QuestionRail>(_window).FirstOrDefault(r => r.IsVisible) is not { } rail)
            {
                return "no question rail after three questions";
            }
            var problem = Expect(rail.Labels.Count == 3, $"{rail.Labels.Count} bars")
                ?? Expect(rail.Labels.SequenceEqual(questions.Select(Controls.QuestionRail.Label)), "labels: " + string.Join(" | ", rail.Labels))
                ?? Expect(rail.Current == 2, $"at the end the last question is current, not {rail.Current}");
            if (problem is not null)
            {
                return problem;
            }
            rail.RaiseEvent(new System.Windows.Input.MouseEventArgs(System.Windows.Input.Mouse.PrimaryDevice, 0) { RoutedEvent = UIElement.MouseEnterEvent });
            await Settle();
            problem = Expect(rail.IsListOpen, "pointing at the rail did not list the questions")
                ?? Expect(CaptureRunner.FindAll<Button>(rail).Count(b => AutomationProperties.GetName(b).StartsWith("Go to question: ", StringComparison.Ordinal)) == 3, "the list has no button per question");
            await CaptureRunner.Shoot(_window, _folder, "question-rail", () => { }, 100);
            var first = CaptureRunner.FindAll<Button>(rail).First(b => AutomationProperties.GetName(b) == "Go to question: " + Controls.QuestionRail.Label(questions[0]));
            (new ButtonAutomationPeer(first).GetPattern(PatternInterface.Invoke) as IInvokeProvider)!.Invoke();
            await Settle(600);
            var thread = CaptureRunner.FindAll<ScrollViewer>(_window).First(v => v.Name == "Thread" && v.IsVisible);
            problem ??= Expect(rail.Current == 0, $"choosing the first question made {rail.Current} current")
                ?? Expect(thread.VerticalOffset < thread.ScrollableHeight - 2, "the conversation did not scroll up to the first question");
            rail.RaiseEvent(new System.Windows.Input.MouseEventArgs(System.Windows.Input.Mouse.PrimaryDevice, 0) { RoutedEvent = UIElement.MouseLeaveEvent });
            await Settle();
            return problem ?? Expect(!rail.IsListOpen, "the list stayed open after the pointer left");
        });
        await Step("Ask → an answer's Download offers each format, Mermaid only with a diagram", async () =>
        {
            _main.Navigate(Section.Documentation);
            _main.AssistantVisible = true;
            var ask = _main.Workspace!.Assistant;
            await Send(ask, "What does DocGenVersion contain?");
            if (ask.Messages.LastOrDefault() is not { IsAssistant: true } answer)
            {
                return "no answer";
            }
            answer.DownloadCommand.Execute(null);
            await Settle();
            var download = answer.Download!;
            var mermaid = download.Formats.Single(f => f.Format == DocGen.Explorer.Engine.Export.ResponseFormat.Mermaid);
            var problem = download.Formats.Count != 7 ? "not every format"
                : mermaid.IsEnabled != download.Diagrams.Count > 0 ? "Mermaid is offered without a diagram (or refused with one)"
                : !mermaid.IsEnabled && mermaid.DisabledReason != "This response does not contain a Mermaid diagram." ? "no reason for the disabled Mermaid format"
                : ExpectButton("Save the download");
            download.IsOpen = false;
            return problem;
        });
        await Step("Ask → Word and PowerPoint downloads draw the answer's diagrams as pictures", async () =>
        {
            const string Flow = "flowchart LR\n  A[Request] --> B[Service] --> C[(Database)]";
            var drawn = await DiagramPictures.DrawAsync([Flow]);
            if (!drawn.ContainsKey(Flow))
            {
                return "the diagram was not drawn";
            }
            var export = new DocGen.Explorer.Engine.Export.ResponseExport($"# Request flow\n\nHow a request is served.\n\n## Flow\n\n```mermaid\n{Flow}\n```\n\n## Parts\n\n| Part | Role |\n|---|---|\n| Service | Serves it |\n",
                null, false, "Sample", null, DateTime.UtcNow, [], "evidence");
            foreach (var (format, picture) in new[] { (DocGen.Explorer.Engine.Export.ResponseFormat.PowerPoint, "ppt/media/image1.png"), (DocGen.Explorer.Engine.Export.ResponseFormat.Word, "word/media/image1.png") })
            {
                var bytes = DocGen.Explorer.Engine.Export.ResponseExporter.Write(export, format, drawn);
                await File.WriteAllBytesAsync(Path.Combine(_folder, "answer" + DocGen.Explorer.Engine.Export.ResponseExporter.Extension(format)), bytes);
                using var zip = new System.IO.Compression.ZipArchive(new MemoryStream(bytes));
                if (zip.GetEntry(picture) is not { Length: > 200 })
                {
                    return $"{format}: the diagram is not in the file as a picture";
                }
            }
            return null;
        });

        // 8b. Reading and writing: wheel, Find, selecting code, class diagrams, editing files, pasting, spelling, search, logs.
        await ReadingAndWritingAsync();

        // 9. The app menu with a repository open, and the panes.
        await AppMenuWalkAsync("with a repository");
        await Step("Usage → a call's details window opens and closes", async () =>
        {
            // A recorded call, so there is a row to open (the walk itself calls no model).
            await _main.Engine.Usage.RecordAsync(new UsageEntry { Feature = "assistant", Purpose = "UI test call", InputTokens = 12, OutputTokens = 34 });
            _main.Navigate(Section.Usage);
            await Settle(800);
            await WaitAsync(() => _main.Usage.Table.Rows.Count > 0, 5);
            return Expect(_main.Usage.Table.Rows.Count > 0, "the recorded call is not listed") ?? await ModalAsync("Call details", "Close");
        });
        await Step("The assistant can be hidden and shown again", async () =>
        {
            _main.Navigate(Section.Documentation);
            await Settle();
            var visible = _main.AssistantVisible;
            _main.ToggleAssistantCommand.Execute(null);
            await Settle();
            var problem = Expect(_main.AssistantVisible != visible, "did not toggle");
            if (!_main.AssistantVisible)
            {
                problem ??= await Click("Show the assistant") ?? Expect(_main.AssistantVisible, "the header button did not bring it back");
            }
            else
            {
                _main.ToggleAssistantCommand.Execute(null);
                await Settle();
            }
            return problem;
        });

        // 10. A narrow window: the tabs fold into a menu that still reaches every section.
        var width = _window.Width;
        var state = _window.WindowState;
        _window.WindowState = WindowState.Normal;
        _window.Width = 820;
        await Settle(800);
        await Step("Narrow window: the sections menu reaches every tab", async () =>
        {
            if (!_main.ShowSectionsMenu)
            {
                return "the tabs did not fold into the menu at 820 px";
            }
            foreach (var (tab, section) in new[] { ("Graph", Section.Graph), ("Learning", Section.Learning), ("Studio", Section.Studio), ("Documentation", Section.Documentation) })
            {
                var problem = await Click("Show the sections of this repository") ?? await Click(tab) ?? Expect(_main.Section == section, $"{tab}: on {_main.Section}");
                if (problem is not null)
                {
                    return problem;
                }
            }
            return null;
        });
        await AppMenuWalkAsync("narrow window");
        _window.Width = width;
        _window.WindowState = state;
        await Settle(600);

        // 11. Clean up what the walk added.
        foreach (var record in new[] { secondRecord, goneRecord })
        {
            await _main.Engine.RemoveRepositoryAsync(record.Id);
            _main.ForgetWorkspace(record.Id);
        }
        TryDelete(second);
        await _main.Repositories.RefreshAsync();
    }

    /// <summary>Every entry of the app menu, and every Settings page from its sidebar.</summary>
    private async Task AppMenuWalkAsync(string context)
    {
        foreach (var (item, section) in new[] { ("Settings", Section.Settings), ("Token usage", Section.Usage), ("Logs", Section.Logs), ("Personas", Section.Personas), ("Help", Section.Help) })
        {
            await Step($"App menu → {item} ({context})", async () =>
                await Click("Menu") ?? Expect(_main.AppMenuOpen, "menu did not open") ?? await Click(item)
                ?? Expect(_main.Section == section, $"on {_main.Section}") ?? Expect(!_main.AppMenuOpen, "menu stayed open"));
        }
        await Step($"App menu → theme and motion toggle and toggle back ({context})", async () =>
        {
            var theme = _main.ThemeMode;
            var motion = _main.ReduceMotion;
            // The menu stays open while its toggles are pressed.
            var problem = await Click("Menu") ?? Expect(_main.AppMenuOpen, "menu did not open");
            for (var i = 0; i < 3 && problem is null; i++)
            {
                problem = await Click(_main.ThemeMenuText) ?? Expect(_main.AppMenuOpen, "the menu closed on a toggle");
            }
            var back = problem ?? await Click(_main.MotionMenuText) ?? await Click(_main.MotionMenuText);
            return back ?? Expect(_main.ThemeMode == theme, $"theme {_main.ThemeMode} after a full cycle") ?? Expect(_main.ReduceMotion == motion, "motion did not come back");
        });
        if (context == "no repository")
        {
            _main.Navigate(Section.Settings);
            await Settle();
            foreach (var page in new[] { "Appearance", "Voice", "Chat model", "Providers and models", "Skills", "Confluence", "Prices", "Data and storage" })
            {
                await Step($"Settings sidebar → {page}", async () => await Click(page) ?? Expect(_main.Settings.Current?.Title == page, $"showing {_main.Settings.Current?.Title}"));
            }
            await Step("Settings sidebar → Token usage opens the Usage page", async () => await Click("Token usage") ?? Expect(_main.Section == Section.Usage, $"on {_main.Section}"));
            await Step("Personas without a repository: the header logo leads home", async () =>
            {
                _main.Navigate(Section.Personas);
                await Settle();
                return await Click("DocGen Explorer") ?? Expect(_main.Section == Section.Repositories, $"on {_main.Section}");
            });
        }
    }

    private async Task PersonasEditorAsync()
    {
        _main.Navigate(Section.Personas);
        await Settle();
        await Step("Personas → New persona opens the editor; Cancel closes it", async () =>
            await Click("New persona") ?? Expect(_main.Personas.IsEditing, "no editor") ?? await Click("Cancel") ?? Expect(!_main.Personas.IsEditing, "editor stayed"));
    }

    private async Task SettingsDialogsAsync()
    {
        _main.Navigate(Section.Settings);
        _main.Settings.ShowPage(SettingsPages.Data);
        await Settle(800);
        await Step("Settings → Factory reset… asks for the word; Cancel resets nothing", async () =>
            await Click("Factory reset…") ?? Expect(_main.Dialog is not null, "no dialog") ?? await Click("Cancel")
            ?? Expect(_main.Dialog is null, "dialog stayed") ?? Expect(!Engine.Storage.DataMaintenance.IsFactoryResetPending(_main.Engine.Store.Root), "a reset was scheduled"));
        await Step("Settings → Factory reset with the wrong word resets nothing", async () =>
        {
            var problem = await Click("Factory reset…");
            if (problem is not null || _main.Dialog is null)
            {
                return problem ?? "no dialog";
            }
            _main.Dialog.Input = "nope";
            return await Click("Reset and restart") ?? Expect(_main.Dialog is null, "dialog stayed")
                ?? Expect(!Engine.Storage.DataMaintenance.IsFactoryResetPending(_main.Engine.Store.Root), "a reset was scheduled");
        });
        await Step("Settings → Confluence with no sites: the address, email and token can be typed and saved straight away", async () =>
        {
            _main.Settings.ShowPage(SettingsPages.Confluence);
            await _main.Settings.Confluence.LoadAsync();
            await Settle(600);
            var confluence = _main.Settings.Confluence;
            var site = confluence.Sites.SingleOrDefault();
            if (site is null || !site.IsBlank || !site.IsExpanded)
            {
                return "no empty site form is open";
            }
            var problem = Expect(Visible("Site address") && Visible("Email"), "the address or email field is not shown") ?? await Click("Show / edit")
                ?? Expect(Visible("API token"), "no API token field after Show / edit");
            if (problem is not null)
            {
                return problem;
            }
            site.BaseUrl = "https://walk-test.atlassian.net/wiki";
            site.Email = "walk@example.com";
            site.ApiToken = "walk-token";
            problem = await Click("Save") ?? await WaitForAsync(() => !confluence.IsDirty, "Save left unsaved changes");
            var saved = await _main.Engine.Confluence.Settings.GetAsync();
            problem ??= Expect(saved.Sites.Count == 1 && saved.Sites[0].ApiToken == "walk-token", "the token was not saved");
            // Back to no sites.
            await _main.Engine.Confluence.Settings.SaveAsync(new Engine.Confluence.ConfluenceSettingsDocument());
            await confluence.LoadAsync();
            return problem;
        });
        await Step("Settings → Confluence → Add site shows its fields; Test explains a missing sign-in; Undo drops it", async () =>
        {
            _main.Settings.ShowPage(SettingsPages.Confluence);
            await Settle(600);
            var confluence = _main.Settings.Confluence;
            // Only the site being added is open, so its own Test connection is the one pressed.
            foreach (var open in confluence.Sites)
            {
                open.IsExpanded = false;
            }
            await Settle();
            var before = confluence.Sites.Count;
            var problem = await Click("Add site") ?? Expect(confluence.Sites.Count == before + 1, "no site was added")
                ?? Expect(_main.Settings.Groups.SelectMany(g => g.Items).Single(i => i.Key == SettingsPages.Confluence).HasBadge, "no unsaved-changes dot")
                ?? Expect(CaptureRunner.FindAll<TextBox>(_window).Any(b => b.IsVisible && AutomationProperties.GetName(b) == "Site address"), "no site address field");
            if (problem is not null)
            {
                return problem;
            }
            var site = confluence.Sites[^1];
            site.BaseUrl = "https://example.atlassian.net/wiki";
            await Settle();
            problem = await Click("Test connection");
            await WaitAsync(() => !site.IsTesting && site.TestResult is not null, 10);
            return problem ?? Expect(site.TestResult?.Contains("API token") == true, $"test said: {site.TestResult}")
                ?? await Click("Undo changes") ?? await WaitForAsync(() => confluence.Sites.Count == before && !confluence.IsDirty, "Undo kept the new site");
        });
        await Step("Settings → Remove selected… is unavailable until something is ticked", async () =>
        {
            _main.Settings.ShowPage(SettingsPages.Data);
            await Settle(600);
            return Expect(Find("Remove selected…") is { IsEnabled: false }, "it was enabled with nothing ticked");
        });
        await Step("Settings → Providers and models: no providers at first; Import from file… is the way in; nothing can be added by hand", async () =>
        {
            _main.Settings.ShowPage(SettingsPages.Providers);
            await _main.Settings.ActivateAsync();
            await Settle();
            return Expect(_main.Settings.Providers.Count == 0, $"{_main.Settings.Providers.Count} providers before any import")
                ?? ExpectButton("Import from file…") ?? Expect(Find("Save a template…") is null, "the build still offers a list of providers")
                ?? Expect(Find("Add provider") is null && Find("Add model") is null, "a way to add providers or models by hand is still there");
        });
        await Step("Settings → Providers and models: an imported provider is read-only except its key and on/off", async () =>
        {
            _main.Engine.Models.ProvidersKey ??= System.Security.Cryptography.RandomNumberGenerator.GetBytes(32);
            await _main.Engine.Models.ImportProvidersAsync(Engine.Storage.EncryptedJson.Encrypt("""
                { "providers": [ { "id": "cloud", "name": "Cloud AI", "kind": "chat-completions", "baseUrl": "https://api.cloud.example", "endpoint": "/chat/completions",
                  "apiKey": "sk-walk-test", "models": [ { "id": "cloud-chat", "displayName": "Cloud Chat" } ] } ] }
                """, _main.Engine.Models.ProvidersKey));
            await _main.Settings.ActivateAsync();
            _main.Settings.ShowPage(SettingsPages.Providers);
            await Settle();
            var provider = _main.Settings.Providers.SingleOrDefault();
            if (provider is null)
            {
                return "the imported provider is not listed";
            }
            provider.IsExpanded = true;
            provider.ShowKey = true;
            await Settle(500);
            var page = CaptureRunner.FindAll<Expander>(_window).FirstOrDefault(e => e.IsVisible && e.DataContext == provider);
            if (page is null)
            {
                return "the provider's card is not shown";
            }
            var editable = CaptureRunner.FindAll<TextBox>(page).Where(b => b.IsVisible && !b.IsReadOnly).Select(b => AutomationProperties.GetName(b)).ToList();
            var problem = Expect(editable.SequenceEqual(["API key"]), "editable fields: " + string.Join(", ", editable.Select(n => n.Length == 0 ? "(unnamed)" : n)))
                ?? ExpectButton("Remove provider") ?? ExpectButton("Use") ?? ExpectButton("Test");
            // Back to no providers, as a fresh installation.
            await _main.Engine.Models.RemoveProviderAsync("cloud");
            await _main.Settings.ActivateAsync();
            return problem;
        });
        await Step("Settings → Providers and models: Undo changes puts back an unsaved key; a pasted key is saved; Use chooses the model; Remove provider asks, then removes it", async () =>
        {
            var chosen = (await _main.Engine.Models.GetExplorerSettingsAsync()).ChatModelId;
            await _main.Engine.Models.ImportProvidersAsync(Engine.Storage.EncryptedJson.Encrypt("""
                { "providers": [ { "id": "cloud", "name": "Cloud AI", "kind": "chat-completions", "baseUrl": "https://api.cloud.example", "endpoint": "/chat/completions",
                  "apiKey": "sk-walk-test", "models": [ { "id": "cloud-chat", "displayName": "Cloud Chat" } ] } ] }
                """, _main.Engine.Models.ProvidersKey!));
            await _main.Settings.ActivateAsync();
            _main.Settings.ShowPage(SettingsPages.Providers);
            await Settle();
            ProviderEditorViewModel Card() => _main.Settings.Providers.Single(p => p.Id == "cloud");
            async Task<string> SavedKey() => (await _main.Engine.Models.Ai.GetAsync()).Providers.Single(p => p.Id == "cloud").ApiKey;
            try
            {
                Card().IsExpanded = true;
                Card().ApiKey = "sk-walk-unsaved";
                await Settle();
                var problem = Expect(_main.Settings.IsDirty, "editing the key did not mark the page changed") ?? await Click("Undo changes");
                await Settle(600);
                problem ??= Expect(Card().ApiKey == "sk-walk-test", "Undo changes did not put the key back") ?? Expect(!_main.Settings.IsDirty, "still marked changed after Undo");
                if (problem is not null)
                {
                    return problem;
                }
                Card().IsExpanded = true;
                Card().ApiKey = "sk-walk-saved";
                await Settle();
                problem = await Click("Save");
                await Settle(800);
                problem ??= Expect(await SavedKey() == "sk-walk-saved", "the pasted key was not saved") ?? Expect(!_main.Settings.IsDirty, "still marked changed after Save");
                if (problem is not null)
                {
                    return problem;
                }
                Card().Models.Single().UseCommand.Execute(null);
                await WaitForChatModelAsync("cloud-chat");
                problem = Expect((await _main.Engine.Models.GetExplorerSettingsAsync()).ChatModelId == "cloud-chat", "Use did not choose the model");
                if (problem is not null)
                {
                    return problem;
                }
                Card().RemoveCommand.Execute(null);
                await WaitAsync(() => _main.Dialog is not null, 5);
                problem = Expect(_main.Dialog is not null, "Remove provider did not ask first");
                _main.Dialog?.ConfirmCommand.Execute(null);
                for (var i = 0; i < 50 && (await _main.Engine.Models.Ai.GetAsync()).Providers.Any(p => p.Id == "cloud"); i++)
                {
                    await Task.Delay(100);
                }
                await Settle(500);
                return problem ?? Expect(!(await _main.Engine.Models.Ai.GetAsync()).Providers.Any(p => p.Id == "cloud"), "the provider is still saved")
                    ?? Expect(!_main.Settings.Providers.Any(p => p.Id == "cloud"), "the provider is still listed");
            }
            finally
            {
                if ((await _main.Engine.Models.Ai.GetAsync()).Providers.Any(p => p.Id == "cloud"))
                {
                    await _main.Engine.Models.RemoveProviderAsync("cloud");
                }
                await _main.Engine.Models.UpdateExplorerSettingsAsync(s => s.ChatModelId = chosen);
                await _main.Settings.ActivateAsync();
            }
        });
    }

    // ---------------------------------------------------------------- steps and checks

    private async Task Step(string path, Func<Task<string?>> action)
    {
        _errors.Clear();
        string? problem;
        try
        {
            problem = await action();
            await Settle();
        }
        catch (Exception ex)
        {
            problem = ex.GetType().Name + ": " + ex.Message;
        }
        // Wherever the user is now, they must have a way on: no dialog left over, the header's way home and its menu.
        problem ??= _errors.Count > 0 ? "error: " + string.Join(" | ", _errors.Take(3)) : null;
        if (problem is null && _main.Dialog is not null)
        {
            problem = "a dialog was left open";
        }
        problem ??= ExpectButton("DocGen Explorer") ?? ExpectButton("Menu") ?? NoRepeatedAddButtons();
        if (problem is null && _main.Workspace is not null && _main.ShowPanes)
        {
            problem = _main.ShowSectionsMenu ? ExpectButton("Show the sections of this repository") : ExpectButton("Graph");
        }
        await CaptureRunner.Shoot(_window, _folder, $"{++_shot:000}", () => { }, 100);
        Record(path, problem is null, problem ?? _note ?? "");
        _note = null;
        _main.CloseMenus();
        if (_main.Dialog is not null)
        {
            _main.Dialog.CancelCommand.Execute(null);
        }
    }

    private Task Step(string path, Func<string?> action) => Step(path, () => Task.FromResult(action()));

    private void Record(string path, bool passed, string detail)
    {
        _results.Add((path, passed, detail));
        Logging.Info($"UI path {(passed ? "PASS" : "FAIL")}: {path}{(passed ? "" : " — " + detail)}");
    }

    /// <summary>The same "Add …" button never shows twice on one screen (one way to add at a time).</summary>
    private string? NoRepeatedAddButtons()
    {
        var repeated = CaptureRunner.FindAll<ButtonBase>(_window).Where(b => b.IsVisible)
            .Select(b => Label(b)).Where(l => l.StartsWith("Add", StringComparison.Ordinal))
            .GroupBy(l => l).Where(g => g.Count() > 1).Select(g => $"\"{g.Key}\" ×{g.Count()}").ToList();
        return repeated.Count == 0 ? null : "repeated on screen: " + string.Join(", ", repeated);
    }

    private static string? Expect(bool condition, string problem) => condition ? null : problem;

    /// <summary>A text box with this name is on screen.</summary>
    private bool Visible(string name) => CaptureRunner.FindAll<TextBox>(_window).Any(b => b.IsVisible && AutomationProperties.GetName(b) == name);

    private string? ExpectButton(string label) => Find(label) is { IsEnabled: true } ? null : $"no enabled \"{label}\"";

    private string? ExpectAnyButton(params string[] labels)
        => labels.Any(l => Find(l) is { IsEnabled: true }) ? null : "no way forward: none of " + string.Join(", ", labels.Select(l => $"\"{l}\""));

    /// <summary>Presses a visible, enabled button, menu item, toggle or link by its label, as a user would.</summary>
    private async Task<string?> Click(string label)
    {
        if (Find(label) is null && FindLink(label) is { } link)
        {
            if (!link.IsEnabled)
            {
                return $"the link \"{label}\" is disabled";
            }
            _ = _window.Dispatcher.BeginInvoke(() =>
                (ContentElementAutomationPeer.CreatePeerForElement(link)?.GetPattern(PatternInterface.Invoke) as IInvokeProvider)?.Invoke(), DispatcherPriority.Input);
            await Settle(350);
            return null;
        }
        var target = Find(label);
        if (target is null)
        {
            return $"\"{label}\" is not on screen";
        }
        if (!target.IsEnabled)
        {
            return $"\"{label}\" is disabled";
        }
        // Posted, so a button that opens a modal window does not block the walk.
        _ = _window.Dispatcher.BeginInvoke(() =>
        {
            var peer = UIElementAutomationPeer.CreatePeerForElement(target);
            switch (peer?.GetPattern(PatternInterface.Invoke), peer?.GetPattern(PatternInterface.Toggle))
            {
                case (IInvokeProvider invoke, _):
                    invoke.Invoke();
                    break;
                case (_, IToggleProvider toggle):
                    toggle.Toggle();
                    break;
                default:
                    // A radio button or tab: chosen as a screen reader chooses it.
                    (peer?.GetPattern(PatternInterface.SelectionItem) as ISelectionItemProvider)?.Select();
                    break;
            }
        }, DispatcherPriority.Input);
        await Settle(350);
        return null;
    }

    /// <summary>A button opens a modal window; the walk closes it with <paramref name="closeLabel"/> (or the title bar when null).</summary>
    private async Task<string?> ModalAsync(string openLabel, string? closeLabel)
    {
        var before = Application.Current.Windows.Count;
        var problem = await Click(openLabel);
        if (problem is not null)
        {
            return problem;
        }
        await WaitAsync(() => Application.Current.Windows.Count > before, 5);
        var modal = Application.Current.Windows.OfType<Window>().FirstOrDefault(w => w != _window && w.IsVisible && w.Owner == _window);
        if (modal is null)
        {
            return $"\"{openLabel}\" opened no window";
        }
        await Settle(500);
        if (closeLabel is null)
        {
            modal.Close();
        }
        else if (FindIn(modal, closeLabel) is { } close)
        {
            (UIElementAutomationPeer.CreatePeerForElement(close)?.GetPattern(PatternInterface.Invoke) as IInvokeProvider)?.Invoke();
        }
        else
        {
            modal.Close();
            return $"the window has no \"{closeLabel}\"";
        }
        await WaitAsync(() => !modal.IsVisible, 5);
        return Expect(!modal.IsVisible, "the window did not close");
    }

    /// <summary>A visible field (text box, list) with this accessible name.</summary>
    private bool Field<T>(string name) where T : FrameworkElement => FindField<T>(name) is not null;

    private T? FindField<T>(string name) where T : FrameworkElement
        => CaptureRunner.FindAll<T>(_window).FirstOrDefault(f => f.IsVisible && AutomationProperties.GetName(f) == name);

    private Control? Find(string label)
    {
        // What is on top first: an open context menu, then open menus, then the window under them.
        var roots = new List<DependencyObject>();
        if (_extraRoot is not null)
        {
            roots.Add(_extraRoot);
        }
        roots.AddRange(CaptureRunner.FindPopups(_window).Where(p => p.IsOpen && p.Child is not null).Select(p => (DependencyObject)p.Child));
        roots.Add(_window);
        return roots.Select(r => FindIn(r, label)).FirstOrDefault(b => b is not null);
    }

    /// <summary>A link inside visible text.</summary>
    private System.Windows.Documents.Hyperlink? FindLink(string label)
    {
        var seen = new List<string>();
        foreach (var block in CaptureRunner.FindAll<TextBlock>(_window).Where(b => b.IsVisible))
        {
            foreach (var link in Links(block.Inlines))
            {
                var text = string.Concat(link.Inlines.OfType<System.Windows.Documents.Run>().Select(r => r.Text)).Trim();
                seen.Add(text);
                if (string.Equals(text, label, StringComparison.Ordinal))
                {
                    return link;
                }
            }
        }
        Logging.Info($"UI path: no link \"{label}\"; links on screen: {string.Join(", ", seen)}");
        return null;
    }

    private static IEnumerable<System.Windows.Documents.Hyperlink> Links(System.Windows.Documents.InlineCollection inlines)
    {
        foreach (var inline in inlines)
        {
            if (inline is System.Windows.Documents.Hyperlink link)
            {
                yield return link;
            }
            else if (inline is System.Windows.Documents.Span span)
            {
                foreach (var nested in Links(span.Inlines))
                {
                    yield return nested;
                }
            }
        }
    }

    private static Control? FindIn(DependencyObject root, string label)
    {
        var candidates = CaptureRunner.FindAll<Control>(root).Where(c => c is ButtonBase or MenuItem && c.IsVisible).ToList();
        return candidates.FirstOrDefault(b => string.Equals(Label(b), label, StringComparison.Ordinal))
            ?? candidates.FirstOrDefault(b => Label(b).StartsWith(label, StringComparison.Ordinal));
    }

    private static string Label(FrameworkElement element)
    {
        var name = AutomationProperties.GetName(element);
        if (!string.IsNullOrWhiteSpace(name))
        {
            return name.Trim();
        }
        if (element is MenuItem { Header: string header })
        {
            return header.Trim();
        }
        var text = element is ContentControl { Content: string content }
            ? content.Trim()
            : string.Join(" ", CaptureRunner.FindAll<TextBlock>(element).Select(t => t.Text).Where(t => !string.IsNullOrWhiteSpace(t) && t.Length > 1)).Trim();
        // An icon-only button is known by its tooltip, as a user hovering over it would.
        if (text.All(c => c is >= '' and <= '' || char.IsWhiteSpace(c)) && element.ToolTip is string tip)
        {
            return tip.Trim();
        }
        return text;
    }

    private async Task Settle(int ms = 250)
    {
        await Task.Delay(ms);
        await _window.Dispatcher.InvokeAsync(() => { }, DispatcherPriority.ApplicationIdle);
    }

    private static async Task WaitAsync(Func<bool> condition, int seconds)
    {
        for (var i = 0; i < seconds * 10 && !condition(); i++)
        {
            await Task.Delay(100);
        }
    }

    private static async Task<string?> WaitForAsync(Func<bool> condition, string problem)
    {
        await WaitAsync(condition, 10);
        return condition() ? null : problem;
    }

    /// <summary>Up to five seconds for the saved chat model to become <paramref name="id"/> (awaited: blocking on the read would hang the UI thread).</summary>
    private async Task WaitForChatModelAsync(string? id)
    {
        for (var i = 0; i < 50 && (await _main.Engine.Models.GetExplorerSettingsAsync()).ChatModelId != id; i++)
        {
            await Task.Delay(100);
        }
    }

    private async Task<int> WriteReportAsync()
    {
        var failed = _results.Count(r => !r.Passed);
        var md = new StringBuilder();
        md.AppendLine("# UI paths").AppendLine();
        md.AppendLine($"{_results.Count - failed} of {_results.Count} paths passed; {failed} failed. Screenshots are numbered by step.").AppendLine();
        md.AppendLine("| # | Path | Result | Detail |").AppendLine("|---|---|---|---|");
        for (var i = 0; i < _results.Count; i++)
        {
            var (path, passed, detail) = _results[i];
            md.AppendLine($"| {i + 1:000} | {path.Replace("|", "\\|")} | {(passed ? "pass" : "**FAIL**")} | {detail.Replace("|", "\\|").Replace("\n", " ")} |");
        }
        await File.WriteAllTextAsync(Path.Combine(_folder, "ui-paths.md"), md.ToString());
        Logging.Info($"UI path test: {_results.Count - failed} passed, {failed} failed.");
        return failed;
    }

    private static void CopyFolder(string from, string to)
    {
        foreach (var dir in Directory.EnumerateDirectories(from, "*", SearchOption.AllDirectories))
        {
            Directory.CreateDirectory(Path.Combine(to, Path.GetRelativePath(from, dir)));
        }
        Directory.CreateDirectory(to);
        foreach (var file in Directory.EnumerateFiles(from, "*", SearchOption.AllDirectories))
        {
            File.Copy(file, Path.Combine(to, Path.GetRelativePath(from, file)), overwrite: true);
        }
    }

    private static void TryDelete(string folder)
    {
        try
        {
            DeleteFolder(folder);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
        }
    }

    /// <summary>Deletes a folder and everything in it, read-only files included (a sample's .git objects are read-only).</summary>
    private static void DeleteFolder(string folder)
    {
        if (!Directory.Exists(folder))
        {
            return;
        }
        foreach (var file in Directory.EnumerateFiles(folder, "*", SearchOption.AllDirectories))
        {
            File.SetAttributes(file, FileAttributes.Normal);
        }
        Directory.Delete(folder, recursive: true);
    }

    /// <summary>How many audio outputs Windows has (none on a build server).</summary>
    [System.Runtime.InteropServices.DllImport("winmm.dll")]
    private static extern uint waveOutGetNumDevs();
}
