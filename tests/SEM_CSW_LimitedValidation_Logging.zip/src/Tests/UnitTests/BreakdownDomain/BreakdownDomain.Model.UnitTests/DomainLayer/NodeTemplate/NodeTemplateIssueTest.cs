using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Volvo.SoftwareBreakdown.BreakdownDomain.Infrastructure.Repositories;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Component;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Component.Tea2Plus;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Conditions;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Dependencies;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Node;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.NodeTemplate;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.NodeTemplate.ParameterCalculations;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.NodeTemplate.ParameterVerifications;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.NonDownloadableTemplate;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Notifications;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Parts;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.ProductDefinition;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Relations;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.RepositoryInterfaces;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Slot;
using Volvo.SoftwareBreakdown.BreakdownDomain.Model.Sources;
using Volvo.SoftwareBreakdown.TestUtilityComponent;

namespace Volvo.SoftwareBreakdown.BreakdownDomain.Model.UnitTests.DomainLayer.NodeTemplate
{
    [TestClass]
    public class NodeTemplateIssueTest
    {
        [TestMethod]
        public void CreateAndRead()
        {
            var context = Helper.CreateContext("1", "24", "pc");
            var nodeDefinition = new Tea2PlusNodeDefinition(1, 1, "1.1");
            const int id = 1;
            const int issueNumber = 1;
            const int documentNumber = 123456;
            var conditions = new List<BaseCondition>();
            var parentNodes = new List<Model.NodeTemplate.ParentNode>();
            var parameterGroups = new List<ParameterGroup>();

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<IComponent> components = new List<IComponent>();
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions1 = (IList<BaseCondition>)conditions;
            var parameterGroups1 = (IEnumerable<ParameterGroup>)parameterGroups;
            var original = new NodeTemplateIssue("guid1", id, documentNumber, issueNumber, "", "", templateType, context, 100.ToString(), true, parentNodes1, conditions1, parameterGroups1, components, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.InProgress, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<IComponent> components1 = new List<IComponent>();
            var parentNodes2 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions2 = (IList<BaseCondition>)conditions;
            var parameterGroups2 = (IEnumerable<ParameterGroup>)parameterGroups;
            var other = new NodeTemplateIssue("guid1", id, documentNumber, issueNumber, "", "", templateType1, context, 100.ToString(), false, parentNodes2, conditions2, parameterGroups2, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.InProgress, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var templateType2 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<IComponent> components2 = new List<IComponent>();
            var parentNodes3 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions3 = (IList<BaseCondition>)conditions;
            var parameterGroups3 = (IEnumerable<ParameterGroup>)parameterGroups;
            var different = new NodeTemplateIssue("guid2", 2, documentNumber, issueNumber, "", "", templateType2, context, 0.ToString(), false, parentNodes3, conditions3, parameterGroups3, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.InProgress, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            Assert.AreEqual(id, original.InternalId);
            Assert.AreEqual(documentNumber, original.DocumentNumber);
            Assert.AreEqual(issueNumber, original.IssueNumber);
            Assert.AreEqual(context, original.Context);
            Assert.AreEqual(nodeDefinition, original.TemplateType.NodeDefinition);
            Assert.AreEqual(conditions, original.Conditions);
            Assert.AreEqual("00123456.1", original.ToString());
            Assert.IsTrue(original.PerformsCanIdTransformation);
            Assert.AreEqual("100", original.DependencyContainerId);
            Assert.AreEqual(NodeTemplateStatus.InProgress, original.StatusCode);
            Assert.AreEqual(parentNodes, original.ParentNodes);
            Assert.IsTrue(original.ParameterGroups.SequenceEqual(parameterGroups));

            Assert.AreEqual(other, original);
            Assert.AreEqual("guid1".GetHashCode(), original.GetHashCode());
            Assert.AreNotEqual(different, original);
        }

        [TestMethod]
        public void CloneWithSubNodeTemplates()
        {
            var context = Helper.CreateContext("1", "24", "pc");
            var nodeDefinition = new Tea2PlusNodeDefinition(1, 1, "1.1");
            const int id = 1;
            const int issueNumber = 1;
            const int documentNumber = 123456;
            var conditions = new List<BaseCondition>();
            var parentNodes = new List<Model.NodeTemplate.ParentNode>();
            var parameterGroups1 = new List<ParameterGroup>() { new ParameterGroup("PG1", new List<BaseParameterVerification>(),
                new List<BaseParameterCalculation>(), new List<BaseCondition>())};
            var parameterGroups2 = new List<ParameterGroup>() { new ParameterGroup("PG2", new List<BaseParameterVerification>(),
                new List<BaseParameterCalculation>(), new List<BaseCondition>())};

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<IComponent> components = new List<IComponent>();
            var parentNodes3 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions3 = (IList<BaseCondition>)conditions;
            var parameterGroups3 = (IEnumerable<ParameterGroup>)parameterGroups1;
            var original = new NodeTemplateIssue("", id, documentNumber, issueNumber, "", "", templateType, context, 100.ToString(), true, parentNodes3, conditions3, parameterGroups3, components, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.InProgress, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes1 = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions1 = new List<BaseCondition>();
            IList<IComponent> components1 = new List<IComponent>();
            var parameterGroups4 = (IEnumerable<ParameterGroup>)parameterGroups2;
            var other = new NodeTemplateIssue("", id + 1, documentNumber + 1, issueNumber, "", "", templateType1, context, 100.ToString(), false, parentNodes1, conditions1, parameterGroups4, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.InProgress, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var templateType2 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes2 = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions2 = new List<BaseCondition>();
            IEnumerable<ParameterGroup> parameterGroups = new List<ParameterGroup>();
            IList<IComponent> components2 = new List<IComponent>();
            var different = new NodeTemplateIssue("", id + 2, documentNumber + 2, issueNumber, "", "", templateType2, context, 0.ToString(), false, parentNodes2, conditions2, parameterGroups, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.InProgress, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            var nodeTemplate = original.CloneWithSubTemplates(new List<NodeTemplateIssue>() { other, different }, true);

            var otherNodeTemplate = original.CloneWithSubTemplates(new List<NodeTemplateIssue>() { different, other }, true);

            Assert.AreEqual(nodeTemplate, otherNodeTemplate);
            Assert.AreNotEqual(nodeTemplate, original);
            Assert.AreNotEqual(original, nodeTemplate);

            Assert.AreEqual(original.Id, nodeTemplate.Id);
            Assert.AreEqual(original.DocumentNumber, nodeTemplate.DocumentNumber);
            Assert.AreEqual(original.IssueNumber, nodeTemplate.IssueNumber);
            Assert.AreEqual(original.TemplateType, nodeTemplate.TemplateType);
            Assert.AreEqual(original.Conditions, nodeTemplate.Conditions);
            Assert.AreEqual(original.PerformsCanIdTransformation, nodeTemplate.PerformsCanIdTransformation);
            Assert.AreEqual(original.DependencyContainerId, nodeTemplate.DependencyContainerId);
            Assert.AreEqual(original.StatusCode, nodeTemplate.StatusCode);
            Assert.AreEqual(original.ParentNodes, nodeTemplate.ParentNodes);
            Assert.IsTrue(nodeTemplate.ParameterGroups.SequenceEqual(parameterGroups1.Concat(parameterGroups2)));
            Assert.IsTrue(nodeTemplate.Components.SequenceEqual(original.Components));
        }

        [TestMethod]
        public void CloneWithSubNodeTemplates_PreexistingSubTemplates()
        {
            var context = Helper.CreateContext("1", "24", "pc");
            var nodeDefinition = new Tea2PlusNodeDefinition(1, 1, "1.1");
            const int id = 1;
            const int issueNumber = 1;
            const int documentNumber = 123456;
            var conditions = new List<BaseCondition>();
            var parentNodes = new List<Model.NodeTemplate.ParentNode>();
            var parameterGroups1 = new List<ParameterGroup>() { new ParameterGroup("PG1", new List<BaseParameterVerification>(),
                new List<BaseParameterCalculation>(), new List<BaseCondition>())};
            var parameterGroups2 = new List<ParameterGroup>() { new ParameterGroup("PG2", new List<BaseParameterVerification>(),
                new List<BaseParameterCalculation>(), new List<BaseCondition>())};

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<IComponent> components = new List<IComponent>();
            var parentNodes3 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions3 = (IList<BaseCondition>)conditions;
            var parameterGroups3 = (IEnumerable<ParameterGroup>)parameterGroups1;
            var original = new NodeTemplateIssue("", id, documentNumber, issueNumber, "", "", templateType, context, 100.ToString(), true, parentNodes3, conditions3, parameterGroups3, components, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.InProgress, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes1 = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions1 = new List<BaseCondition>();
            IList<IComponent> components1 = new List<IComponent>();
            var parameterGroups4 = (IEnumerable<ParameterGroup>)parameterGroups2;
            var other = new NodeTemplateIssue("", id + 1, documentNumber + 1, issueNumber, "", "", templateType1, context, 100.ToString(), false, parentNodes1, conditions1, parameterGroups4, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.InProgress, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var templateType2 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes2 = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions2 = new List<BaseCondition>();
            IEnumerable<ParameterGroup> parameterGroups = new List<ParameterGroup>();
            IList<IComponent> components2 = new List<IComponent>();
            var different = new NodeTemplateIssue("", id + 2, documentNumber + 2, issueNumber, "", "", templateType2, context, 0.ToString(), false, parentNodes2, conditions2, parameterGroups, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.InProgress, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            var intermediateNodeTemplate = original.CloneWithSubTemplates(new List<NodeTemplateIssue>() { other }, true);
            var nodeTemplate = intermediateNodeTemplate.CloneWithSubTemplates(new List<NodeTemplateIssue>() { different }, true);

            Assert.AreNotEqual(nodeTemplate, original);
            Assert.AreNotEqual(original, nodeTemplate);
            Assert.AreNotEqual(nodeTemplate, intermediateNodeTemplate);

            Assert.AreEqual(original.Id, nodeTemplate.Id);
            Assert.AreEqual(original.DocumentNumber, nodeTemplate.DocumentNumber);
            Assert.AreEqual(original.IssueNumber, nodeTemplate.IssueNumber);
            Assert.AreEqual(original.TemplateType, nodeTemplate.TemplateType);
            Assert.AreEqual(original.Conditions, nodeTemplate.Conditions);
            Assert.AreEqual(original.PerformsCanIdTransformation, nodeTemplate.PerformsCanIdTransformation);
            Assert.AreEqual(original.DependencyContainerId, nodeTemplate.DependencyContainerId);
            Assert.AreEqual(original.StatusCode, nodeTemplate.StatusCode);
            Assert.AreEqual(original.ParentNodes, nodeTemplate.ParentNodes);
            Assert.IsTrue(nodeTemplate.ParameterGroups.SequenceEqual(parameterGroups1.Concat(parameterGroups2)));
            Assert.IsTrue(nodeTemplate.Components.SequenceEqual(original.Components));
        }

        [TestMethod]
        public void Verify_that_ApplyNodeTemplateToNode_returns_no_notifications()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");

            IList<BaseCondition> conditions = new BaseCondition[] { new VariantCondition(new Variant("AAB", "112", "symbol_B", VariantFamilyType.Must)) };
            IList<BaseCondition> conditions1 = new BaseCondition[] { new VariantCondition(new Variant("AAC", "113", "symbol_C", VariantFamilyType.Must)) };
            IList<BaseCondition> conditions2 = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions3 = new BaseCondition[] { new VariantCondition(new Variant("AAD", "114", "symbol_D", VariantFamilyType.Must)) };
            IList<BaseCondition> conditions4 = new BaseCondition[] { new VariantCondition(new Variant("AAD", "114", "symbol_D", VariantFamilyType.Must)) };
            var components = new IComponent[]
            {
                new Tea2PlusMainSoftwareComponent("MSW",
                new[]
                {
                    new Tea2PlusMainSoftwareComponentItem(conditions2, new PartNumberArtifactVersion(771), 1, false, "")
                }, 0, 1, 2, false, NotProgrammableInAftermarketScenario.Never, false, false, null, null),
                new Tea2PlusComplementarySoftwareComponent("CSW", new[]
                    {
                        new Tea2PlusComplementarySoftwareComponentItem(conditions, new PartNumberArtifactVersion(772), 1, false, ""),
                        new Tea2PlusComplementarySoftwareComponentItem(conditions1, new PartNumberArtifactVersion(773), 1, false, "")
                    },
                1, 2, 3, false, NotProgrammableInAftermarketScenario.Never, false, false, null, null),
                new Tea2PlusSecondaryBootLoaderComponent("SBL", new []
                    {
                        new Tea2PlusSecondaryBootLoaderComponentItem(conditions4, new PartNumberArtifactVersion(774), 1, false, ""),
                    },
                2, 3, 4, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
                new Tea2PlusPrimaryBootLoaderComponent("PBL", new []
                    {
                        new Tea2PlusPrimaryBootLoaderComponentItem(conditions3, new PartNumberArtifactVersion(774), 1, false, ""),
                    },
                2, 3, 4, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true,
                nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions5 = new BaseCondition[] { new VariantCondition(new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must)) };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false, parentNodes, conditions5, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            newNodeTemplate.Components.SetParent(newNodeTemplate);

            /* Setup node */
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions6 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components2 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes1, conditions6, parameterGroups1, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, new List<NodeTemplateIssue>()
            {
                oldNodeTemplate
            }, new TestSource(), false);
            var projectStage = string.Empty;
            PartDecorator<BasePart> decoratedPart = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(774), 1, projectStage, false), 1);
            BaseSource source = new TestSource();
            node.AddSoftwareSlot(new Tea2PlusSecondaryBootLoaderSlot(new PartNumberArtifactVersion(774), "SBL_OLD", decoratedPart, source, 81, 34, 22, false, true, NotProgrammableInAftermarketScenario.Connected, 7707));
            var projectStage1 = string.Empty;
            PartDecorator<BasePart> decoratedPart1 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(775), 1, projectStage1, false), 1);
            BaseSource source1 = new TestSource();
            node.AddSoftwareSlot(new Tea2PlusPrimaryBootLoaderSlot(new PartNumberArtifactVersion(775), "PBL_OLD", decoratedPart1, source1, 81, 34, 22, false, true, NotProgrammableInAftermarketScenario.Connected, 7707));

            /* Some mocks */
            var projectStage2 = string.Empty;
            NonDownloadableComponentType type = new("guid", ComponentTypeCode.Tea2PlusHardware, "name", "desc", 0);
            var projectStage3 = string.Empty;
            NonDownloadableComponentType type1 = new("guid1", ComponentTypeCode.Tea2PlusSubHardware, "name1", "desc1", 0);
            var newHardware = new[]
            {
                new BillOfMaterialContent<PartDecorator<BaseHardwarePart>>(new FilledPartDecorator<BaseHardwarePart>(new ECUHardwarePart(new PartNumberArtifactVersion(111), 0, 1, projectStage2, type, null), 1)),
                new BillOfMaterialContent<PartDecorator<BaseHardwarePart>>(new FilledPartDecorator<BaseHardwarePart>(new SubHardwarePart(new PartNumberArtifactVersion(112), 0, 2, projectStage3, type1, null), 2)),
            };

            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Single().Equals(newNodeTemplate)),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(newHardware);

            var softwareConsistencyChecker = new Mock<ISoftwareConsistencyChecker>();

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);

            var productSpecification = new ProductSpecification(
                new[] { new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must), new Variant("AAB", "112", "symbol_B", VariantFamilyType.Must), new Variant("AAD", "114", "symbol_D", VariantFamilyType.Must) }, Array.Empty<string>(), "U1", null, null, null, "");

            var product = new Mock<IProduct>();
            product.Setup(p => p.RequestMetadata)
                .Returns(new RequestMetadata(new List<BaseNodeIdentification>(), false));
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();

            var newNode = newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                    hardwareConsistencyChecker.Object, softwareConsistencyChecker.Object, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected) as Tea2PlusNode;
            Assert.IsNotNull(newNode);

            Assert.AreEqual(4455, newNode.DocumentNumber);
            Assert.AreEqual(111.ToArtifactVersion(), newNode.Hardware.ArtifactVersion);
            Assert.AreEqual(112.ToArtifactVersion(), newNode.SubHardware[0].ArtifactVersion);
            Assert.AreEqual(771.ToArtifactVersion(), newNode.MainSoftware.ArtifactVersion);
            Assert.AreEqual(772.ToArtifactVersion(), newNode.ComplementarySoftwares[0].ArtifactVersion);
            Assert.AreEqual(774.ToArtifactVersion(), newNode.SecondaryBootLoader.ArtifactVersion);
            Assert.AreEqual(775.ToArtifactVersion(), newNode.PrimaryBootLoader.ArtifactVersion);

            Assert.AreEqual(0, newNode.Notifications.Count);
            Assert.AreEqual(0, newNode.Hardware.Notifications.Count);
            Assert.AreEqual(0, newNode.SubHardware[0].Notifications.Count);
            Assert.AreEqual(0, newNode.MainSoftware.Notifications.Count);
            Assert.AreEqual(0, newNode.ComplementarySoftwares[0].Notifications.Count);
            Assert.AreEqual(0, newNode.SecondaryBootLoader.Notifications.Count);
        }

        [TestMethod]
        public void Verify_that_ApplyNodeTemplateToNode_WithPrimaryBootLoader_returns_no_notifications()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");

            IList<BaseCondition> conditions = new BaseCondition[] { new VariantCondition(new Variant("AAB", "112", "symbol_B", VariantFamilyType.Must)) };
            IList<BaseCondition> conditions1 = new BaseCondition[] { new VariantCondition(new Variant("AAC", "113", "symbol_C", VariantFamilyType.Must)) };
            IList<BaseCondition> conditions2 = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions3 = new BaseCondition[] { new VariantCondition(new Variant("AAD", "114", "symbol_D", VariantFamilyType.Must)) };
            IList<BaseCondition> conditions4 = new BaseCondition[] { new VariantCondition(new Variant("AAD", "114", "symbol_D", VariantFamilyType.Must)) };
            var components = new IComponent[]
            {
                new Tea2PlusMainSoftwareComponent("MSW",
                new[]
                {
                    new Tea2PlusMainSoftwareComponentItem(conditions2, new PartNumberArtifactVersion(771), 1, false, "")
                }, 0, 1, 2, false, NotProgrammableInAftermarketScenario.Never, false, false, null, null),
                new Tea2PlusComplementarySoftwareComponent("CSW", new[]
                    {
                        new Tea2PlusComplementarySoftwareComponentItem(conditions, new PartNumberArtifactVersion(772), 1, false, ""),
                        new Tea2PlusComplementarySoftwareComponentItem(conditions1, new PartNumberArtifactVersion(773), 1, false, "")
                    },
                1, 2, 3, false, NotProgrammableInAftermarketScenario.Never, false, false, null, null),
                new Tea2PlusSecondaryBootLoaderComponent("SBL", new []
                    {
                        new Tea2PlusSecondaryBootLoaderComponentItem(conditions4, new PartNumberArtifactVersion(774), 1, false, ""),
                    },
                2, 3, 4, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
                new Tea2PlusPrimaryBootLoaderComponent("PBL", new []
                    {
                        new Tea2PlusPrimaryBootLoaderComponentItem(conditions3, new PartNumberArtifactVersion(774), 1, false, ""),
                    },
                2, 3, 4, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true,
                nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions5 = new BaseCondition[] { new VariantCondition(new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must)) };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false, parentNodes, conditions5, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            newNodeTemplate.Components.SetParent(newNodeTemplate);

            /* Setup node */
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions6 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components2 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes1, conditions6, parameterGroups1, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, oldNodeTemplate, new TestSource(), false);
            var projectStage = string.Empty;
            PartDecorator<BasePart> decoratedPart = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(774), 1, projectStage, false), 1);
            BaseSource source = new TestSource();
            node.AddSoftwareSlot(new Tea2PlusSecondaryBootLoaderSlot(new PartNumberArtifactVersion(774), "SBL_OLD", decoratedPart, source, 81, 34, 22, false, true, NotProgrammableInAftermarketScenario.Connected, 7707));
            var projectStage1 = string.Empty;
            PartDecorator<BasePart> decoratedPart1 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(775), 1, projectStage1, false), 1);
            BaseSource source1 = new TestSource();
            node.AddSoftwareSlot(new Tea2PlusPrimaryBootLoaderSlot(new PartNumberArtifactVersion(775), "PBL_OLD", decoratedPart1, source1, 81, 34, 22, false, true, NotProgrammableInAftermarketScenario.Connected, 7707));

            /* Some mocks */
            var projectStage2 = string.Empty;
            NonDownloadableComponentType type = new("guid", ComponentTypeCode.Tea2PlusHardware, "name", "desc", 0);
            var projectStage3 = string.Empty;
            NonDownloadableComponentType type1 = new("guid1", ComponentTypeCode.Tea2PlusSubHardware, "name1", "desc1", 0);
            var newHardware = new[]
            {
                new BillOfMaterialContent<PartDecorator<BaseHardwarePart>>(new FilledPartDecorator<BaseHardwarePart>(new ECUHardwarePart(new PartNumberArtifactVersion(111), 0, 1, projectStage2, type, null), 1)),
                new BillOfMaterialContent<PartDecorator<BaseHardwarePart>>(new FilledPartDecorator<BaseHardwarePart>(new SubHardwarePart(new PartNumberArtifactVersion(112), 0, 2, projectStage3, type1, null), 2)),
            };

            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Single().Equals(newNodeTemplate)),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(newHardware);

            var softwareConsistencyChecker = new Mock<ISoftwareConsistencyChecker>();

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);

            var productSpecification = new ProductSpecification(
                new[] { new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must), new Variant("AAB", "112", "symbol_B", VariantFamilyType.Must), new Variant("AAD", "114", "symbol_D", VariantFamilyType.Must) }, Array.Empty<string>(), "U1", null, null, null, "");

            var product = new Mock<IProduct>();
            product.Setup(p => p.RequestMetadata)
                .Returns(new RequestMetadata(new List<BaseNodeIdentification>(), false));
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();

            var newNode = newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                    hardwareConsistencyChecker.Object, softwareConsistencyChecker.Object, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected) as Tea2PlusNode;
            Assert.IsNotNull(newNode);

            Assert.AreEqual(4455, newNode.DocumentNumber);
            Assert.AreEqual(111.ToArtifactVersion(), newNode.Hardware.ArtifactVersion);
            Assert.AreEqual(112.ToArtifactVersion(), newNode.SubHardware[0].ArtifactVersion);
            Assert.AreEqual(771.ToArtifactVersion(), newNode.MainSoftware.ArtifactVersion);
            Assert.AreEqual(772.ToArtifactVersion(), newNode.ComplementarySoftwares[0].ArtifactVersion);
            Assert.AreEqual(774.ToArtifactVersion(), newNode.SecondaryBootLoader.ArtifactVersion);
            Assert.AreEqual(775.ToArtifactVersion(), newNode.PrimaryBootLoader.ArtifactVersion);

            Assert.AreEqual(0, newNode.Notifications.Count);
            Assert.AreEqual(0, newNode.Hardware.Notifications.Count);
            Assert.AreEqual(0, newNode.SubHardware[0].Notifications.Count);
            Assert.AreEqual(0, newNode.MainSoftware.Notifications.Count);
            Assert.AreEqual(0, newNode.ComplementarySoftwares[0].Notifications.Count);
            Assert.AreEqual(0, newNode.SecondaryBootLoader.Notifications.Count);
        }

        [TestMethod]
        public void Verify_that_ApplyNodeTemplateToNode_Include_ConditionNotifications_From_Sub_Templates()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");

            IList<BaseCondition> conditions = new BaseCondition[] { new VariantCondition(new Variant("AAB", "112", "symbol_B", VariantFamilyType.Must)) };
            IList<BaseCondition> conditions1 = new BaseCondition[] { new VariantCondition(new Variant("AAC", "113", "symbol_C", VariantFamilyType.Must)) };
            IList<BaseCondition> conditions2 = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions3 = new BaseCondition[] { new VariantCondition(new Variant("AAD", "114", "symbol_D", VariantFamilyType.Must)) };
            IList<BaseCondition> conditions4 = new BaseCondition[] { new VariantCondition(new Variant("AAD", "114", "symbol_D", VariantFamilyType.Must)) };
            var components = new IComponent[]
            {
                new Tea2PlusMainSoftwareComponent("MSW",
                new[]
                {
                    new Tea2PlusMainSoftwareComponentItem(conditions2, new PartNumberArtifactVersion(771), 1, false, "")
                }, 0, 1, 2, false, NotProgrammableInAftermarketScenario.Never, false, false, null, null),
                new Tea2PlusComplementarySoftwareComponent("CSW", new[]
                    {
                        new Tea2PlusComplementarySoftwareComponentItem(conditions, new PartNumberArtifactVersion(772), 1, false, ""),
                        new Tea2PlusComplementarySoftwareComponentItem(conditions1, new PartNumberArtifactVersion(773), 1, false, "")
                    },
                1, 2, 3, false, NotProgrammableInAftermarketScenario.Never, false, false, null, null),
                new Tea2PlusSecondaryBootLoaderComponent("SBL", new []
                    {
                        new Tea2PlusSecondaryBootLoaderComponentItem(conditions4, new PartNumberArtifactVersion(774), 1, false, ""),
                    },
                2, 3, 4, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
                new Tea2PlusPrimaryBootLoaderComponent("PBL", new []
                    {
                        new Tea2PlusPrimaryBootLoaderComponentItem(conditions3, new PartNumberArtifactVersion(774), 1, false, ""),
                    },
                2, 3, 4, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true,
                nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions5 = new BaseCondition[] { new VariantCondition(new Variant("XXX", "111", "symbol_X", VariantFamilyType.Must)) };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components2 = (IList<IComponent>)components;
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false, parentNodes, conditions5, parameterGroups, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            newNodeTemplate.Components.SetParent(newNodeTemplate);

            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true,
                nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions6 = new BaseCondition[]
                {new VariantCondition(new Variant("YYY", "111", "symbol_Y", VariantFamilyType.Must))};
            IList<IComponent> components1 = new List<IComponent>();
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var subNodeTemplate = new NodeTemplateIssue("", 11, 445511, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes1, conditions6, parameterGroups1, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            var nodeTemplate = newNodeTemplate.CloneWithSubTemplates(new List<NodeTemplateIssue>() { subNodeTemplate }, true);

            /* Setup node */
            var templateType2 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes2 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions7 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups2 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components3 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType2, context, 0.ToString(), false, parentNodes2, conditions7, parameterGroups2, components3, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, oldNodeTemplate, new TestSource(), false);
            var projectStage = string.Empty;
            PartDecorator<BasePart> decoratedPart = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(774), 1, projectStage, false), 1);
            BaseSource source = new TestSource();
            node.AddSoftwareSlot(new Tea2PlusSecondaryBootLoaderSlot(new PartNumberArtifactVersion(774), "SBL_OLD", decoratedPart, source, 81, 34, 22, false, true, NotProgrammableInAftermarketScenario.Connected, 7707));
            var projectStage1 = string.Empty;
            PartDecorator<BasePart> decoratedPart1 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(775), 1, projectStage1, false), 1);
            BaseSource source1 = new TestSource();
            node.AddSoftwareSlot(new Tea2PlusPrimaryBootLoaderSlot(new PartNumberArtifactVersion(775), "PBL_OLD", decoratedPart1, source1, 81, 34, 22, false, true, NotProgrammableInAftermarketScenario.Connected, 7707));

            /* Some mocks */
            var projectStage2 = string.Empty;
            NonDownloadableComponentType type = new("guid", ComponentTypeCode.Tea2PlusHardware, "name", "desc", 0);
            var projectStage3 = string.Empty;
            NonDownloadableComponentType type1 = new("guid1", ComponentTypeCode.Tea2PlusSubHardware, "name1", "desc1", 0);
            var newHardware = new[]
            {
                new BillOfMaterialContent<PartDecorator<BaseHardwarePart>>(new FilledPartDecorator<BaseHardwarePart>(new ECUHardwarePart(new PartNumberArtifactVersion(111), 0, 1, projectStage2, type, null), 1)),
                new BillOfMaterialContent<PartDecorator<BaseHardwarePart>>(new FilledPartDecorator<BaseHardwarePart>(new SubHardwarePart(new PartNumberArtifactVersion(112), 0, 2, projectStage3, type1, null), 2)),
            };

            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Any(w => w.Equals(nodeTemplate))),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(newHardware);

            var softwareConsistencyChecker = new Mock<ISoftwareConsistencyChecker>();

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);

            var productSpecification = new ProductSpecification(
                new[] { new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must), new Variant("AAB", "112", "symbol_B", VariantFamilyType.Must), new Variant("AAD", "114", "symbol_D", VariantFamilyType.Must) }, Array.Empty<string>(), "U1", null, null, null, "");

            var product = new Mock<IProduct>();
            product.Setup(p => p.RequestMetadata)
                .Returns(new RequestMetadata(new List<BaseNodeIdentification>(), false));
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();

            var newNode = nodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                    hardwareConsistencyChecker.Object, softwareConsistencyChecker.Object, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected) as Tea2PlusNode;
            Assert.IsNotNull(newNode);

            Assert.AreEqual(4455, newNode.DocumentNumber);
            Assert.AreEqual(111.ToArtifactVersion(), newNode.Hardware.ArtifactVersion);
            Assert.AreEqual(112.ToArtifactVersion(), newNode.SubHardware[0].ArtifactVersion);
            Assert.AreEqual(771.ToArtifactVersion(), newNode.MainSoftware.ArtifactVersion);
            Assert.AreEqual(772.ToArtifactVersion(), newNode.ComplementarySoftwares[0].ArtifactVersion);
            Assert.AreEqual(774.ToArtifactVersion(), newNode.SecondaryBootLoader.ArtifactVersion);
            Assert.AreEqual(775.ToArtifactVersion(), newNode.PrimaryBootLoader.ArtifactVersion);

            Assert.AreEqual(2, newNode.NodeVersionNotifications.Count);

            Assert.AreEqual("The node template 00004455 is not valid for this product because its variant condition does not match the product specification. The node template variant condition is based on variant families: XXX. This product has no variant specified for these families.", newNode.NodeVersionNotifications[0].GetReason());
            Assert.AreEqual("The node template 00445511 is not valid for this product because its variant condition does not match the product specification. The node template variant condition is based on variant families: YYY. This product has no variant specified for these families.", newNode.NodeVersionNotifications.Last().GetReason());

            Assert.AreEqual(0, newNode.Hardware.Notifications.Count);
            Assert.AreEqual(0, newNode.SubHardware[0].Notifications.Count);
            Assert.AreEqual(0, newNode.MainSoftware.Notifications.Count);
            Assert.AreEqual(0, newNode.ComplementarySoftwares[0].Notifications.Count);
            Assert.AreEqual(0, newNode.SecondaryBootLoader.Notifications.Count);
            Assert.AreEqual(0, newNode.PrimaryBootLoader.Notifications.Count);
        }

        [TestMethod]
        public void Verify_that_ApplyNodeTemplateToNode_returns_notification_on_mismatching_NodeTemplate()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true,
                nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions = new BaseCondition[] { new VariantCondition(new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must)) };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components = (IList<IComponent>)Array.Empty<IComponent>();
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false, parentNodes, conditions, parameterGroups, components, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            /* Setup node */
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions1 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes1, conditions1, parameterGroups1, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, oldNodeTemplate, new TestSource(), false);

            /* Some mocks */
            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Single().Equals(newNodeTemplate)),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(Array.Empty<BillOfMaterialContent<PartDecorator<BaseHardwarePart>>>());

            var softwareConsistencyChecker = new Mock<ISoftwareConsistencyChecker>();

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);

            var productSpecification = new ProductSpecification(Array.Empty<Variant>(), Array.Empty<string>(), "U1", null, null, null, "");

            var product = new Mock<IProduct>();
            product.Setup(p => p.RequestMetadata)
                .Returns(new RequestMetadata(new List<BaseNodeIdentification>(), false));
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();

            var newNode = newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                    hardwareConsistencyChecker.Object, softwareConsistencyChecker.Object, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected) as Tea2PlusNode;
            Assert.IsNotNull(newNode);

            var nodeTemplateMismatchNotification = newNode.NodeVersionNotifications.OfType<NodeTemplateMismatch>().SingleOrDefault();
            Assert.IsNotNull(nodeTemplateMismatchNotification);
        }

        [TestMethod]
        public void Verify_that_ApplyNodeTemplateToNode_correctly_assigns_anonymous_data_slots()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");

            IList<BaseCondition> conditions = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions1 = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions2 = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions3 = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions4 = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions5 = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions6 = new BaseCondition[] { new AlwaysMatchCondition() };
            var components = new IComponent[]
            {
                new Tea2PlusDataComponent("Data0", new[]
                {
                    new Tea2PlusDataComponentItem(conditions, new PartNumberArtifactVersion(111), 1, false, ""),
                    new Tea2PlusDataComponentItem(conditions1, new PartNumberArtifactVersion(222), 1, false, "")
                }, 0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, Array.Empty<Tea2PlusDataPatchComponent>(), false, null, null),

                new Tea2PlusDataComponent("Data1", new[]
                {
                    new Tea2PlusDataComponentItem(conditions2, new PartNumberArtifactVersion(222), 1, false, ""),
                    new Tea2PlusDataComponentItem(conditions3, new PartNumberArtifactVersion(333), 1, false, "")
                }, 0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, Array.Empty<Tea2PlusDataPatchComponent>(), false, null, null),

                new Tea2PlusDataComponent("Data2", new[]
                {
                    new Tea2PlusDataComponentItem(conditions4, new PartNumberArtifactVersion(444), 1, false, ""),
                    new Tea2PlusDataComponentItem(conditions5, new PartNumberArtifactVersion(555), 1, false, ""),
                    new Tea2PlusDataComponentItem(conditions6, new PartNumberArtifactVersion(111), 1, false, ""),
                }, 0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, Array.Empty<Tea2PlusDataPatchComponent>(), false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions7 = new BaseCondition[] { new AlwaysMatchCondition() };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false, parentNodes, conditions7, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            /* Setup node */
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions8 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components2 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes1, conditions8, parameterGroups1, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, oldNodeTemplate, new TestSource(), false);

            var projectStage = string.Empty;
            PartDecorator<BasePart> decoratedPart = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(111), 1, projectStage, false), 1);
            List<Tea2PlusDataPatchSlot> dataPatches = new();
            node.AnonymousSlots.Add(new Tea2PlusDataSlot(new PartNumberArtifactVersion(111), "DataSlot1", decoratedPart, null, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Never, dataPatches, 7707));

            var projectStage1 = string.Empty;
            PartDecorator<BasePart> decoratedPart1 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(222), 1, projectStage1, false), 1);
            List<Tea2PlusDataPatchSlot> dataPatches1 = new();
            node.AnonymousSlots.Add(new Tea2PlusDataSlot(new PartNumberArtifactVersion(222), "DataSlot2", decoratedPart1, null, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Never, dataPatches1, 7707));

            var projectStage2 = string.Empty;
            PartDecorator<BasePart> decoratedPart2 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(333), 1, projectStage2, false), 1);
            List<Tea2PlusDataPatchSlot> dataPatches2 = new();
            node.AnonymousSlots.Add(new Tea2PlusDataSlot(new PartNumberArtifactVersion(333), "DataSlot3", decoratedPart2, null, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Never, dataPatches2, 7707));

            /* Some mocks */
            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Single().Equals(newNodeTemplate)),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(Array.Empty<BillOfMaterialContent<PartDecorator<BaseHardwarePart>>>());

            var softwareConsistencyChecker = new Mock<ISoftwareConsistencyChecker>();

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);

            var productSpecification = new ProductSpecification(Array.Empty<Variant>(), Array.Empty<string>(), "U1", null, null, null, "");

            var product = new Mock<IProduct>();
            product.Setup(p => p.RequestMetadata)
                .Returns(new RequestMetadata(new List<BaseNodeIdentification>(), false));
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();

            var newNode = newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                    hardwareConsistencyChecker.Object, softwareConsistencyChecker.Object, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected) as Tea2PlusNode;
            Assert.IsNotNull(newNode);

            Assert.AreEqual(0, newNode.AnonymousSlots.Count);
            Assert.AreEqual(3, newNode.Data.Count);

            var data0 = newNode.Data.First(x => x.Name == "Data0");
            Assert.AreEqual(222.ToArtifactVersion(), data0.ArtifactVersion);

            var data1 = newNode.Data.First(x => x.Name == "Data1");
            Assert.AreEqual(333.ToArtifactVersion(), data1.ArtifactVersion);

            var data2 = newNode.Data.First(x => x.Name == "Data2");
            Assert.AreEqual(111.ToArtifactVersion(), data2.ArtifactVersion);
        }

        [TestMethod]
        public void Verify_that_ApplyNodeTemplateToNode_handles_unmatched_anonymous_slot()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");

            IList<BaseCondition> conditions = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions1 = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions2 = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions3 = new BaseCondition[] { new AlwaysMatchCondition() };
            var components = new IComponent[]
            {
                new Tea2PlusComplementarySoftwareComponent("CSW0", new[]
                {
                    new Tea2PlusComplementarySoftwareComponentItem(conditions, new PartNumberArtifactVersion(111), 1, false, ""),
                }, 0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
                new Tea2PlusComplementarySoftwareComponent("CSW1", new[]
                {
                    new Tea2PlusComplementarySoftwareComponentItem(conditions1, new PartNumberArtifactVersion(111), 1, false, ""),
                    new Tea2PlusComplementarySoftwareComponentItem(conditions2, new PartNumberArtifactVersion(333), 1, false, ""),
                }, 0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
                new Tea2PlusComplementarySoftwareComponent("CSW2", new[]
                {
                    new Tea2PlusComplementarySoftwareComponentItem(conditions3, new PartNumberArtifactVersion(333), 1, false, ""),
                }, 0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null)
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions4 = new BaseCondition[] { new AlwaysMatchCondition() };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false, parentNodes, conditions4, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            /* Setup node */
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions5 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components2 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes1, conditions5, parameterGroups1, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, oldNodeTemplate, new TestSource(), false);

            var projectStage = string.Empty;
            PartDecorator<BasePart> decoratedPart = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(111), 1, projectStage, false), 1);
            node.AnonymousSlots.Add(new Tea2PlusComplementarySoftwareSlot(new PartNumberArtifactVersion(111), "CswSlot1", decoratedPart, null, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Connected, 7707));

            var projectStage1 = string.Empty;
            PartDecorator<BasePart> decoratedPart1 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(222), 1, projectStage1, false), 1);
            node.AnonymousSlots.Add(new Tea2PlusComplementarySoftwareSlot(new PartNumberArtifactVersion(222), "CswSlot2", decoratedPart1, null, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Connected, 7707));

            var projectStage2 = string.Empty;
            PartDecorator<BasePart> decoratedPart2 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(333), 1, projectStage2, false), 1);
            node.AnonymousSlots.Add(new Tea2PlusComplementarySoftwareSlot(new PartNumberArtifactVersion(333), "CswSlot3", decoratedPart2, null, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Connected, 7707));

            /* Some mocks */
            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Single().Equals(newNodeTemplate)),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(Array.Empty<BillOfMaterialContent<PartDecorator<BaseHardwarePart>>>());

            var softwareConsistencyChecker = new Mock<ISoftwareConsistencyChecker>();

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);

            var productSpecification = new ProductSpecification(Array.Empty<Variant>(), Array.Empty<string>(), "U1", null, null, null, "");

            var product = new Mock<IProduct>();
            product.Setup(p => p.RequestMetadata)
                .Returns(new RequestMetadata(new List<BaseNodeIdentification>(), false));
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();

            var newNode = newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                    hardwareConsistencyChecker.Object, softwareConsistencyChecker.Object, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected) as Tea2PlusNode;
            Assert.IsNotNull(newNode);

            Assert.AreEqual(0, newNode.AnonymousSlots.Count);
            Assert.AreEqual(3, newNode.ComplementarySoftwares.Count);

            var csw0 = newNode.ComplementarySoftwares.First(x => x.Name == "CSW0");
            Assert.AreEqual(111.ToArtifactVersion(), csw0.ArtifactVersion);

            var csw1 = newNode.ComplementarySoftwares.First(x => x.Name == "CSW1");
            Assert.AreEqual(222.ToArtifactVersion(), csw1.ArtifactVersion);

            var csw2 = newNode.ComplementarySoftwares.First(x => x.Name == "CSW2");
            Assert.AreEqual(333.ToArtifactVersion(), csw2.ArtifactVersion);
        }

        [TestMethod]
        public void Verify_that_ApplyNodeTemplateToNode_handles_unknown_partnumber_in_component_when_assigning_AnonymousSlots()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");

            IList<BaseCondition> conditions = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions1 = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions2 = new BaseCondition[] { new AlwaysMatchCondition() };
            var components = new IComponent[]
            {
                new Tea2PlusComplementarySoftwareComponent("CSW0", new[]
                {
                    new Tea2PlusComplementarySoftwareComponentItem(conditions, new PartNumberArtifactVersion(111), 1, false, ""),
                }, 0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
                new Tea2PlusComplementarySoftwareComponent("CSW1", new[]
                {
                    new Tea2PlusComplementarySoftwareComponentItem(conditions1, new PartNumberArtifactVersion(999), 1, false, ""),
                }, 0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
                new Tea2PlusComplementarySoftwareComponent("CSW2", new[]
                {
                    new Tea2PlusComplementarySoftwareComponentItem(conditions2, new PartNumberArtifactVersion(333), 1, false, ""),
                }, 0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null)
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions3 = new BaseCondition[] { new AlwaysMatchCondition() };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false, parentNodes, conditions3, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            /* Setup node */
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions4 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components2 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes1, conditions4, parameterGroups1, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, oldNodeTemplate, new TestSource(), false);

            var projectStage = string.Empty;
            PartDecorator<BasePart> decoratedPart = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(111), 1, projectStage, false), 1);
            node.AnonymousSlots.Add(new Tea2PlusComplementarySoftwareSlot(new PartNumberArtifactVersion(111), "CswSlot1", decoratedPart, null, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Connected, 7707));

            var projectStage1 = string.Empty;
            PartDecorator<BasePart> decoratedPart1 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(999), 1, projectStage1, false), 1);
            node.AnonymousSlots.Add(new Tea2PlusComplementarySoftwareSlot(new PartNumberArtifactVersion(222), "CswSlot2", decoratedPart1, null, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Connected, 7707));

            var projectStage2 = string.Empty;
            PartDecorator<BasePart> decoratedPart2 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(333), 1, projectStage2, false), 1);
            node.AnonymousSlots.Add(new Tea2PlusComplementarySoftwareSlot(new PartNumberArtifactVersion(333), "CswSlot3", decoratedPart2, null, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Connected, 7707));

            /* Some mocks */
            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Single().Equals(newNodeTemplate)),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(Array.Empty<BillOfMaterialContent<PartDecorator<BaseHardwarePart>>>());

            var softwareConsistencyChecker = new Mock<ISoftwareConsistencyChecker>();

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);

            var productSpecification = new ProductSpecification(Array.Empty<Variant>(), Array.Empty<string>(), "U1", null, null, null, "");

            var product = new Mock<IProduct>();
            product.Setup(p => p.RequestMetadata)
                .Returns(new RequestMetadata(new List<BaseNodeIdentification>(), false));
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();

            var newNode = newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                    hardwareConsistencyChecker.Object, softwareConsistencyChecker.Object, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected) as Tea2PlusNode;
            Assert.IsNotNull(newNode);

            Assert.AreEqual(0, newNode.AnonymousSlots.Count);
            Assert.AreEqual(3, newNode.ComplementarySoftwares.Count);

            var csw0 = newNode.ComplementarySoftwares.First(x => x.Name == "CSW0");
            Assert.AreEqual(111.ToArtifactVersion(), csw0.ArtifactVersion);

            var csw1 = newNode.ComplementarySoftwares.First(x => x.Name == "CSW1");
            Assert.AreEqual(222.ToArtifactVersion(), csw1.ArtifactVersion);

            var csw2 = newNode.ComplementarySoftwares.First(x => x.Name == "CSW2");
            Assert.AreEqual(333.ToArtifactVersion(), csw2.ArtifactVersion);
        }

        [TestMethod]
        public void Verify_that_ApplyNodeTemplateToNode_handles_no_component_items_for_component_when_assigning_AnonymousSlots()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");

            IList<BaseCondition> conditions = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions1 = new BaseCondition[] { new AlwaysMatchCondition() };
            var components = new IComponent[]
            {
                new Tea2PlusComplementarySoftwareComponent("CSW0", new[]
                {
                    new Tea2PlusComplementarySoftwareComponentItem(conditions, new PartNumberArtifactVersion(111), 1, false, ""),
                }, 0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),

                new Tea2PlusComplementarySoftwareComponent("CSW1", new[]
                {
                    new Tea2PlusComplementarySoftwareComponentItem(conditions1, new PartNumberArtifactVersion(222), 1, false, ""),
                }, 0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),

                new Tea2PlusComplementarySoftwareComponent("CSW2", Array.Empty<Tea2PlusComplementarySoftwareComponentItem>(), 0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null)
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions2 = new BaseCondition[] { new AlwaysMatchCondition() };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false, parentNodes, conditions2, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            /* Setup node */
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions3 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components2 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes1, conditions3, parameterGroups1, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, oldNodeTemplate, new TestSource(), false);

            var projectStage = string.Empty;
            PartDecorator<BasePart> decoratedPart = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(111), 1, projectStage, false), 1);
            node.AnonymousSlots.Add(new Tea2PlusComplementarySoftwareSlot(new PartNumberArtifactVersion(111), "CswSlot1", decoratedPart, null, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Connected, 7707));

            var projectStage1 = string.Empty;
            PartDecorator<BasePart> decoratedPart1 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(333), 1, projectStage1, false), 1);
            node.AnonymousSlots.Add(new Tea2PlusComplementarySoftwareSlot(new PartNumberArtifactVersion(333), "CswSlot2", decoratedPart1, null, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Connected, 7707));

            var projectStage2 = string.Empty;
            PartDecorator<BasePart> decoratedPart2 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(222), 1, projectStage2, false), 1);
            node.AnonymousSlots.Add(new Tea2PlusComplementarySoftwareSlot(new PartNumberArtifactVersion(222), "CswSlot3", decoratedPart2, null, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Connected, 7707));

            /* Some mocks */
            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Single().Equals(newNodeTemplate)),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(Array.Empty<BillOfMaterialContent<PartDecorator<BaseHardwarePart>>>());

            var softwareConsistencyChecker = new Mock<ISoftwareConsistencyChecker>();

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);

            var productSpecification = new ProductSpecification(Array.Empty<Variant>(), Array.Empty<string>(), "U1", null, null, null, "");

            var product = new Mock<IProduct>();
            product.Setup(p => p.RequestMetadata)
                .Returns(new RequestMetadata(new List<BaseNodeIdentification>(), false));
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();

            var newNode = newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                    hardwareConsistencyChecker.Object, softwareConsistencyChecker.Object, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected) as Tea2PlusNode;
            Assert.IsNotNull(newNode);

            Assert.AreEqual(0, newNode.AnonymousSlots.Count);
            Assert.AreEqual(3, newNode.ComplementarySoftwares.Count);

            var csw0 = newNode.ComplementarySoftwares.First(x => x.Name == "CSW0");
            Assert.AreEqual(111.ToArtifactVersion(), csw0.ArtifactVersion);

            var csw1 = newNode.ComplementarySoftwares.First(x => x.Name == "CSW1");
            Assert.AreEqual(222.ToArtifactVersion(), csw1.ArtifactVersion);

            var csw2 = newNode.ComplementarySoftwares.First(x => x.Name == "CSW2");
            Assert.AreEqual(333.ToArtifactVersion(), csw2.ArtifactVersion);
        }

        [TestMethod]
        public void
            Verify_that_ApplyNodeTemplateToNode_matches_DataSlots_using_patch_partnumbers_when_assigning_AnonymousSlots()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");

            IList<BaseCondition> conditions = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions1 = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions2 = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions3 = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions4 = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions5 = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions6 = new BaseCondition[] { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions7 = new BaseCondition[] { new AlwaysMatchCondition() };
            var components = new IComponent[]
            {
                new Tea2PlusDataComponent("Data0", new[]
                {
                    new Tea2PlusDataComponentItem(conditions, new PartNumberArtifactVersion(333), 1, false, ""),
                }, 0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, new[]
                {
                    new Tea2PlusDataPatchComponent("patch1", new[] {new Tea2PlusDataPatchComponentItem(conditions3, new PartNumberArtifactVersion(1001), 1, "") }, 0, false, null, null),
                    new Tea2PlusDataPatchComponent("patch2", new[] {new Tea2PlusDataPatchComponentItem(conditions4, new PartNumberArtifactVersion(1002), 1, "") }, 0, false, null, null),
                }, false, null, null),

                new Tea2PlusDataComponent("Data1", new[]
                {
                    new Tea2PlusDataComponentItem(conditions1, new PartNumberArtifactVersion(222), 1, false, ""),
                }, 0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, new[]
                {
                    new Tea2PlusDataPatchComponent("patch3", new[] {new Tea2PlusDataPatchComponentItem(conditions5, new PartNumberArtifactVersion(1003), 1, "") }, 0, false, null, null),
                }, false, null, null),

                new Tea2PlusDataComponent("Data2", new[]
                {
                    new Tea2PlusDataComponentItem(conditions2, new PartNumberArtifactVersion(111), 1, false, ""),
                }, 0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, new[]
                {
                    new Tea2PlusDataPatchComponent("patch4", new[] {new Tea2PlusDataPatchComponentItem(conditions6, new PartNumberArtifactVersion(1004), 1, "") }, 0, false, null, null),
                    new Tea2PlusDataPatchComponent("patch5", new[] {new Tea2PlusDataPatchComponentItem(conditions7, new PartNumberArtifactVersion(1005), 1, "") }, 0, false, null, null),
                }, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions8 = new BaseCondition[] { new AlwaysMatchCondition() };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false, parentNodes, conditions8, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            newNodeTemplate.Components.SetParent(newNodeTemplate);

            /* Setup node */
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions9 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components2 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes1, conditions9, parameterGroups1, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var projectStage = string.Empty;
            var projectStage1 = string.Empty;
            var projectStage2 = string.Empty;
            PartDecorator<BasePart> decoratedPart7 = new EmptyPartDecorator<BasePart>(new SoftwarePart(new NullArtifactVersion(), 0, projectStage, false));
            BaseSource source = new TestSource();
            PartDecorator<BasePart> decoratedPart8 = new EmptyPartDecorator<BasePart>(new SoftwarePart(new NullArtifactVersion(), 0, projectStage1, false));
            BaseSource source1 = new TestSource();
            PartDecorator<BasePart> decoratedPart9 = new EmptyPartDecorator<BasePart>(new SoftwarePart(new NullArtifactVersion(), 0, projectStage2, false));
            BaseSource source2 = new TestSource();
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, oldNodeTemplate,
                new TestSource(), false)
            {
                SecondaryBootLoader = new Tea2PlusSecondaryBootLoaderSlot(new NullArtifactVersion(), "", decoratedPart7, source, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Never, 7707),
                PrimaryBootLoader = new Tea2PlusPrimaryBootLoaderSlot(new NullArtifactVersion(), "", decoratedPart8, source1, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Never, 7707),
                MainSoftware = new Tea2PlusMainSoftwareSlot(new NullArtifactVersion(), "", decoratedPart9, source2, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Never, 7707)
            };

            var projectStage3 = string.Empty;
            var projectStage4 = string.Empty;
            PartDecorator<BasePart> decoratedPart = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(1004), 1, projectStage4, false), 1);
            PartDecorator<BasePart> decoratedPart4 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(111), 1, projectStage3, false), 1);
            List<Tea2PlusDataPatchSlot> dataPatches = new()
            {
                new Tea2PlusDataPatchSlot(new PartNumberArtifactVersion(1004), "", decoratedPart, null, 0, 7707)
            };
            node.AnonymousSlots.Add(new Tea2PlusDataSlot(new PartNumberArtifactVersion(111), "DataSlot0", decoratedPart4, null, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Connected, dataPatches, 7707));

            var projectStage5 = string.Empty;
            var projectStage6 = string.Empty;
            PartDecorator<BasePart> decoratedPart1 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(1003), 1, projectStage6, false), 1);
            PartDecorator<BasePart> decoratedPart5 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(222), 1, projectStage5, false), 1);
            List<Tea2PlusDataPatchSlot> dataPatches1 = new()
            {
                new Tea2PlusDataPatchSlot(new PartNumberArtifactVersion(1003), "", decoratedPart1, null, 0, 7707)
            };
            node.AnonymousSlots.Add(new Tea2PlusDataSlot(new PartNumberArtifactVersion(222), "DataSlot1", decoratedPart5, null, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Connected, dataPatches1, 7707));

            var projectStage7 = string.Empty;
            var projectStage8 = string.Empty;
            var projectStage9 = string.Empty;
            PartDecorator<BasePart> decoratedPart2 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(1001), 1, projectStage8, false), 1);
            PartDecorator<BasePart> decoratedPart3 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(1002), 1, projectStage9, false), 1);
            PartDecorator<BasePart> decoratedPart6 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(333), 1, projectStage7, false), 1);
            List<Tea2PlusDataPatchSlot> dataPatches2 = new()
            {
                new Tea2PlusDataPatchSlot(new PartNumberArtifactVersion(1001), "", decoratedPart2, null, 0, 7707),
                new Tea2PlusDataPatchSlot(new PartNumberArtifactVersion(1002), "", decoratedPart3, null, 0, 7707)
            };
            node.AnonymousSlots.Add(new Tea2PlusDataSlot(new PartNumberArtifactVersion(333), "DataSlot2", decoratedPart6, null, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Connected, dataPatches2, 7707));

            /* Some mocks */
            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Single().Equals(newNodeTemplate)),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(Array.Empty<BillOfMaterialContent<PartDecorator<BaseHardwarePart>>>());

            var softwareConsistencyChecker = new SoftwareConsistencyChecker(null);

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);

            var productSpecification = new ProductSpecification(Array.Empty<Variant>(), Array.Empty<string>(), "U1", null, null, null, "");

            var product = new Mock<IProduct>();
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);
            product.Setup(p => p.RequestMetadata)
                .Returns(new RequestMetadata(new List<BaseNodeIdentification>(), false));

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();

            var newNode = newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                    hardwareConsistencyChecker.Object, softwareConsistencyChecker, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected) as Tea2PlusNode;
            Assert.IsNotNull(newNode);

            Assert.AreEqual(0, newNode.AnonymousSlots.Count);
            Assert.AreEqual(3, newNode.Data.Count);

            var data0 = newNode.Data.First(x => x.Name == "Data0");
            Assert.AreEqual(333.ToArtifactVersion(), data0.ArtifactVersion);
            Assert.AreEqual(2, data0.DataPatches.Count);
            Assert.AreEqual(1001.ToArtifactVersion(), data0.DataPatches[0].ArtifactVersion);
            Assert.AreEqual(1002.ToArtifactVersion(), data0.DataPatches[1].ArtifactVersion);
            Assert.AreEqual(0, data0.Notifications.OfType<SoftwarePartNotAllowed>().Count());

            var data1 = newNode.Data.First(x => x.Name == "Data1");
            Assert.AreEqual(222.ToArtifactVersion(), data1.ArtifactVersion);
            Assert.AreEqual(1, data1.DataPatches.Count);
            Assert.AreEqual(1003.ToArtifactVersion(), data1.DataPatches[0].ArtifactVersion);
            Assert.AreEqual(0, data1.Notifications.OfType<SoftwarePartNotAllowed>().Count());

            var data2 = newNode.Data.First(x => x.Name == "Data2");
            Assert.AreEqual(111.ToArtifactVersion(), data2.ArtifactVersion);
            Assert.AreEqual(1, data2.DataPatches.Count);
            Assert.AreEqual(1004.ToArtifactVersion(), data2.DataPatches[0].ArtifactVersion);
        }

        [TestMethod]
        public void Verify_that_ApplyNodeTemplateToNode_returns_notifications_on_mismatching_software()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");

            IList<BaseCondition> conditions = new BaseCondition[] { new VariantCondition(new Variant("DDD", "444", "symbol_D", VariantFamilyType.Must)) };
            IList<BaseCondition> conditions1 = new BaseCondition[] { new VariantCondition(new Variant("DDD", "444", "symbol_D", VariantFamilyType.Must)) };
            var components = new IComponent[]
            {
                new Tea2PlusSecondaryBootLoaderComponent("SBL", new []
                    {
                        new Tea2PlusSecondaryBootLoaderComponentItem(conditions1, new PartNumberArtifactVersion(774), 1, false, ""),
                    },
                2, 3, 4, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
                new Tea2PlusPrimaryBootLoaderComponent("PBL", new []
                    {
                        new Tea2PlusPrimaryBootLoaderComponentItem(conditions, new PartNumberArtifactVersion(775), 1, false, ""),
                    },
                2, 3, 4, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true,
                nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions2 = new BaseCondition[] { new VariantCondition(new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must)) };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false, parentNodes, conditions2, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            newNodeTemplate.Components.SetParent(newNodeTemplate);

            /* Setup node */
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions3 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components2 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes1, conditions3, parameterGroups1, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var projectStage = string.Empty;
            var projectStage1 = string.Empty;
            var projectStage2 = string.Empty;
            PartDecorator<BasePart> decoratedPart = new EmptyPartDecorator<BasePart>(new SoftwarePart(new NullArtifactVersion(), 0, projectStage, false));
            BaseSource source = new TestSource();
            PartDecorator<BasePart> decoratedPart2 = new EmptyPartDecorator<BasePart>(new SoftwarePart(new NullArtifactVersion(), 0, projectStage1, false));
            BaseSource source2 = new TestSource();
            PartDecorator<BasePart> decoratedPart4 = new EmptyPartDecorator<BasePart>(new SoftwarePart(new NullArtifactVersion(), 0, projectStage2, false));
            BaseSource source4 = new TestSource();
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, oldNodeTemplate,
                new TestSource(), false)
            {
                SecondaryBootLoader = new Tea2PlusSecondaryBootLoaderSlot(new NullArtifactVersion(), "", decoratedPart, source, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Never, 7707),
                PrimaryBootLoader = new Tea2PlusPrimaryBootLoaderSlot(new NullArtifactVersion(), "", decoratedPart2, source2, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Never, 7707),
                MainSoftware = new Tea2PlusMainSoftwareSlot(new NullArtifactVersion(), "", decoratedPart4, source4, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Never, 7707)
            };

            var projectStage3 = string.Empty;
            PartDecorator<BasePart> decoratedPart1 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(774), 1, projectStage3, false), 1);
            BaseSource source1 = new TestSource();
            node.AddSoftwareSlot(new Tea2PlusSecondaryBootLoaderSlot(new PartNumberArtifactVersion(774), "SBL_OLD", decoratedPart1, source1, 81, 34, 22, false, false, NotProgrammableInAftermarketScenario.Connected, 7707));
            var projectStage4 = string.Empty;
            PartDecorator<BasePart> decoratedPart3 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(775), 1, projectStage4, false), 1);
            BaseSource source3 = new TestSource();
            node.AddSoftwareSlot(new Tea2PlusPrimaryBootLoaderSlot(new PartNumberArtifactVersion(775), "PBL_OLD", decoratedPart3, source3, 81, 34, 22, false, false, NotProgrammableInAftermarketScenario.Connected, 7707));

            /* Some mocks */
            var projectStage5 = string.Empty;
            NonDownloadableComponentType type = new("guid", ComponentTypeCode.Tea2PlusHardware, "name", "desc", 0);
            var projectStage6 = string.Empty;
            NonDownloadableComponentType type1 = new("guid1", ComponentTypeCode.Tea2PlusSubHardware, "name1", "desc1", 0);
            var newHardware = new[]
            {
                new BillOfMaterialContent<PartDecorator<BaseHardwarePart>>(new FilledPartDecorator<BaseHardwarePart>(new ECUHardwarePart(new PartNumberArtifactVersion(111), 0, 1, projectStage5, type, null), 1)),
                new BillOfMaterialContent<PartDecorator<BaseHardwarePart>>(new FilledPartDecorator<BaseHardwarePart>(new SubHardwarePart(new PartNumberArtifactVersion(112), 0, 2, projectStage6, type1, null), 2)),
            };

            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Single().Equals(newNodeTemplate)),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(newHardware);

            var softwareConsistencyChecker = new SoftwareConsistencyChecker(null);

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);

            var productSpecification = new ProductSpecification(
                new[] { new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must), new Variant("AAB", "112", "symbol_B", VariantFamilyType.Must), new Variant("AAD", "114", "symbol_D", VariantFamilyType.Must) }, Array.Empty<string>(), "U1", null, null, null, "");

            var product = new Mock<IProduct>();
            product.Setup(p => p.RequestMetadata)
                .Returns(new RequestMetadata(new List<BaseNodeIdentification>(), false));
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();

            var newNode = newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                    hardwareConsistencyChecker.Object, softwareConsistencyChecker, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected) as Tea2PlusNode;
            Assert.IsNotNull(newNode);

            Assert.AreEqual(4455, newNode.DocumentNumber);
            Assert.AreEqual(774.ToArtifactVersion(), newNode.SecondaryBootLoader.ArtifactVersion);
            var softwarePartNotAllowedNotification =
                newNode.SecondaryBootLoader.Notifications.OfType<SoftwarePartNotAllowedForVariantCombination>().SingleOrDefault();
            Assert.IsNotNull(softwarePartNotAllowedNotification);
            Assert.AreEqual(775.ToArtifactVersion(), newNode.PrimaryBootLoader.ArtifactVersion);
            var softwarePartNotAllowedNotification2 =
                newNode.PrimaryBootLoader.Notifications.OfType<SoftwarePartNotAllowedForVariantCombination>().SingleOrDefault();
            Assert.IsNotNull(softwarePartNotAllowedNotification2);
        }

        [TestMethod]
        public void Verify_that_ApplyNodeTemplateToNode_returns_notifications_on_empty_slot()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");

            IList<BaseCondition> conditions = new BaseCondition[] { new VariantCondition(new Variant("DDD", "444", "symbol_D", VariantFamilyType.Must)) };
            IList<BaseCondition> conditions1 = new BaseCondition[] { new VariantCondition(new Variant("DDD", "444", "symbol_D", VariantFamilyType.Must)) };
            var components = new IComponent[]
            {
                new Tea2PlusSecondaryBootLoaderComponent("SBL", new []
                    {
                        new Tea2PlusSecondaryBootLoaderComponentItem(conditions1, new PartNumberArtifactVersion(774), 1, false, ""),
                    },
                2, 3, 4, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
                new Tea2PlusPrimaryBootLoaderComponent("PBL", new []
                    {
                        new Tea2PlusPrimaryBootLoaderComponentItem(conditions, new PartNumberArtifactVersion(774), 1, false, ""),
                    },
                2, 3, 4, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null)
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true,
                nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions2 = new BaseCondition[] { new VariantCondition(new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must)) };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false, parentNodes, conditions2, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            newNodeTemplate.Components.SetParent(newNodeTemplate);

            /* Setup node */
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions3 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components2 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes1, conditions3, parameterGroups1, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var projectStage = string.Empty;
            var projectStage1 = string.Empty;
            var projectStage2 = string.Empty;
            PartDecorator<BasePart> decoratedPart = new EmptyPartDecorator<BasePart>(new SoftwarePart(new NullArtifactVersion(), 0, projectStage, false));
            BaseSource source = new TestSource();
            PartDecorator<BasePart> decoratedPart2 = new EmptyPartDecorator<BasePart>(new SoftwarePart(new NullArtifactVersion(), 0, projectStage1, false));
            BaseSource source2 = new TestSource();
            PartDecorator<BasePart> decoratedPart4 = new EmptyPartDecorator<BasePart>(new SoftwarePart(new NullArtifactVersion(), 0, projectStage2, false));
            BaseSource source4 = new TestSource();
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, oldNodeTemplate,
                new TestSource(), false)
            {
                SecondaryBootLoader = new Tea2PlusSecondaryBootLoaderSlot(new NullArtifactVersion(), "", decoratedPart, source, 0, 0, 0, false, true, NotProgrammableInAftermarketScenario.Never, 7707),
                PrimaryBootLoader = new Tea2PlusPrimaryBootLoaderSlot(new NullArtifactVersion(), "", decoratedPart2, source2, 0, 0, 0, false, true, NotProgrammableInAftermarketScenario.Never, 7707),
                MainSoftware = new Tea2PlusMainSoftwareSlot(new NullArtifactVersion(), "", decoratedPart4, source4, 0, 0, 0, false, true, NotProgrammableInAftermarketScenario.Never, 7707)
            };

            var projectStage3 = string.Empty;
            PartDecorator<BasePart> decoratedPart1 = new IntentionallyEmptyPartDecorator<BasePart>(new SoftwarePart(new NullArtifactVersion(), 0, projectStage3, false));
            BaseSource source1 = new TestSource();
            node.AddSoftwareSlot(new Tea2PlusSecondaryBootLoaderSlot(new PartNumberArtifactVersion(774), "SBL_OLD", decoratedPart1, source1, 81, 34, 22, false, true, NotProgrammableInAftermarketScenario.Connected, 7707));
            var projectStage4 = string.Empty;
            PartDecorator<BasePart> decoratedPart3 = new IntentionallyEmptyPartDecorator<BasePart>(new SoftwarePart(new NullArtifactVersion(), 0, projectStage4, false));
            BaseSource source3 = new TestSource();
            node.AddSoftwareSlot(new Tea2PlusPrimaryBootLoaderSlot(new PartNumberArtifactVersion(775), "PBL_OLD", decoratedPart3, source3, 81, 34, 22, false, true, NotProgrammableInAftermarketScenario.Connected, 7707));

            /* Some mocks */
            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Single().Equals(newNodeTemplate)),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(Array.Empty<BillOfMaterialContent<PartDecorator<BaseHardwarePart>>>());

            var softwareConsistencyChecker = new SoftwareConsistencyChecker(null);

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);

            var productSpecification = new ProductSpecification(
                new[] { new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must) }, Array.Empty<string>(), "U1", null, null, null, "");

            var product = new Mock<IProduct>();
            product.Setup(p => p.RequestMetadata)
                .Returns(new RequestMetadata(new List<BaseNodeIdentification>(), false));
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();

            var newNode = newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                    hardwareConsistencyChecker.Object, softwareConsistencyChecker, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected) as Tea2PlusNode;
            Assert.IsNotNull(newNode);

            Assert.AreEqual(4455, newNode.DocumentNumber);
            var slotEmptyNotification =
                newNode.SecondaryBootLoader.Notifications.OfType<SlotEmpty>().SingleOrDefault();
            Assert.IsNotNull(slotEmptyNotification);
            var slotEmptyNotification2 =
                newNode.PrimaryBootLoader.Notifications.OfType<SlotEmpty>().SingleOrDefault();
            Assert.IsNotNull(slotEmptyNotification2);
        }

        [TestMethod]
        public void Verify_that_ApplyNodeTemplateToNode_returns_notifications_on_part_not_allowed()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");

            IList<BaseCondition> conditions = new BaseCondition[] { new AlwaysMatchCondition() };
            var components = new IComponent[]
            {
                new Tea2PlusMainSoftwareComponent("MSW",
                new[]
                {
                    new Tea2PlusMainSoftwareComponentItem(conditions, new PartNumberArtifactVersion(771), 1, false, "")
                }, 4, 2, 3, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true,
                nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions1 = new BaseCondition[] { new VariantCondition(new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must)) };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false, parentNodes, conditions1, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            newNodeTemplate.Components.SetParent(newNodeTemplate);

            /* Setup node */
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions2 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components2 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes1, conditions2, parameterGroups1, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var projectStage = string.Empty;
            var projectStage1 = string.Empty;
            var projectStage2 = string.Empty;
            PartDecorator<BasePart> decoratedPart = new EmptyPartDecorator<BasePart>(new SoftwarePart(new NullArtifactVersion(), 0, projectStage1, false));
            BaseSource source = new TestSource();
            PartDecorator<BasePart> decoratedPart1 = new EmptyPartDecorator<BasePart>(new SoftwarePart(new NullArtifactVersion(), 0, projectStage, false));
            BaseSource source1 = new TestSource();
            PartDecorator<BasePart> decoratedPart2 = new EmptyPartDecorator<BasePart>(new SoftwarePart(new NullArtifactVersion(), 0, projectStage2, false));
            BaseSource source2 = new TestSource();
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, oldNodeTemplate,
                new TestSource(), false)
            {
                PrimaryBootLoader = new Tea2PlusPrimaryBootLoaderSlot(new NullArtifactVersion(), "", decoratedPart1, source1, 0, 0, 0, false, true, NotProgrammableInAftermarketScenario.Never, 7707),
                SecondaryBootLoader = new Tea2PlusSecondaryBootLoaderSlot(new NullArtifactVersion(), "", decoratedPart, source, 0, 0, 0, false, true, NotProgrammableInAftermarketScenario.Never, 7707),
                MainSoftware = new Tea2PlusMainSoftwareSlot(new NullArtifactVersion(), "", decoratedPart2, source2, 0, 0, 0, false, true, NotProgrammableInAftermarketScenario.Never, 7707)
            };

            var projectStage3 = string.Empty;
            PartDecorator<BasePart> decoratedPart3 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(4435), 1, projectStage3, false), 1);
            BaseSource source3 = new TestSource();
            node.AddSoftwareSlot(new Tea2PlusMainSoftwareSlot(new PartNumberArtifactVersion(4435), "MSW", decoratedPart3, source3, 4, 1, 7, false, false, NotProgrammableInAftermarketScenario.Connected, 7707));

            /* Some mocks */
            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Single().Equals(newNodeTemplate)),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(Array.Empty<BillOfMaterialContent<PartDecorator<BaseHardwarePart>>>());

            var repository = new Mock<ISoftwareMetaDataLoader>();
            repository.Setup(mr => mr.LoadSoftwareMetaDataAsync(It.IsAny<ArtifactVersion>(), false))
            .Returns(Task.FromResult<SoftwareMetaData>(null));

            var repositoryCarrier = new Mock<IRepositoryCarrier>();
            repositoryCarrier.Setup(r => r.SoftwareMetaDataLoader).Returns(repository.Object);

            var softwareConsistencyChecker = new SoftwareConsistencyChecker(repositoryCarrier.Object);

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);

            var productSpecification = new ProductSpecification(
                new[] { new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must) }, Array.Empty<string>(), "U1", null, null, null, "");

            var product = new Mock<IProduct>();
            product.Setup(p => p.RequestMetadata)
                .Returns(new RequestMetadata(new List<BaseNodeIdentification>(), false));
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();

            var newNode = newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                    hardwareConsistencyChecker.Object, softwareConsistencyChecker, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected) as Tea2PlusNode;
            Assert.IsNotNull(newNode);

            Assert.AreEqual(4455, newNode.DocumentNumber);
            var softwarePartNotAllowedNotification =
                newNode.MainSoftware.Notifications.OfType<SoftwarePartNotAllowed>().SingleOrDefault();
            Assert.IsNotNull(softwarePartNotAllowedNotification);
        }

        [TestMethod]
        public void Verify_that_hardware_in_AnonymousSlots_are_handled()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true,
                nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions = new BaseCondition[] { new AlwaysMatchCondition() };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components = (IList<IComponent>)Array.Empty<IComponent>();
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false, parentNodes, conditions, parameterGroups, components, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            /* Setup node */
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions1 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes1, conditions1, parameterGroups1, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, oldNodeTemplate, new TestSource(), false);

            var projectStage = string.Empty;
            NonDownloadableComponentType type = new("", ComponentTypeCode.Tea2PlusHardware, "", "", 0);
            PartDecorator<BasePart> decoratedPart = new FilledPartDecorator<BasePart>(
                new ECUHardwarePart(new PartNumberArtifactVersion(999), 0, 1, projectStage, type, null), 1);
            BaseSource source = new TestSource();
            node.AnonymousSlots.Add(new Tea2PlusHardwareSlot(new PartNumberArtifactVersion(999), "HW?", decoratedPart, source));

            /* Some mocks */
            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Single().Equals(newNodeTemplate)),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(
                    (IList<BaseNodeIdentification> _, IList<NodeTemplateIssue> _,
                        IList<BillOfMaterialContent<BaseHardwarePart>> parts, Guid? _, IBillOfMaterial _, ICompatibleHardwareFilter _, bool _, bool _) =>
                    {
                        return
                            parts.Select(
                                x =>
                                    new BillOfMaterialContent<PartDecorator<BaseHardwarePart>>(
                                        new FilledPartDecorator<BaseHardwarePart>(x.Value, 1))).ToList();
                    });

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);

            var softwareConsistencyChecker = new Mock<ISoftwareConsistencyChecker>();

            var productSpecification = new ProductSpecification(
                Array.Empty<Variant>(), Array.Empty<string>(), "U1", null, null, null, "");

            var product = new Mock<IProduct>();
            product.Setup(p => p.RequestMetadata)
                .Returns(new RequestMetadata(new List<BaseNodeIdentification>(), false));
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();
            compatibleHardwareFilter.Setup(
                x =>
                    x.Filter(It.IsAny<BillOfMaterialContent<PartDecorator<BaseHardwarePart>>>(),
                        It.IsAny<IEnumerable<Tuple<BaseCondition, NonDownloadableVersionItem>>>()))
                .Returns(
                    (BillOfMaterialContent<PartDecorator<BaseHardwarePart>> _,
                        IEnumerable<Tuple<BaseCondition, NonDownloadableVersionItem>> items) => items);

            var newNode = newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                    hardwareConsistencyChecker.Object, softwareConsistencyChecker.Object, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected) as Tea2PlusNode;
            Assert.IsNotNull(newNode);

            Assert.IsNotNull(newNode.Hardware);
            Assert.AreEqual(999.ToArtifactVersion(), newNode.Hardware.ArtifactVersion);
        }

        [TestMethod]
        public void Verify_that_limited_validation_is_handled_correctly_when_it_is_not_set()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");

            IList<BaseCondition> conditions = new BaseCondition[] { new AlwaysMatchCondition() };
            var components = new IComponent[]
            {
                new Tea2PlusMainSoftwareComponent("MSW",
                new[]
                {
                    new Tea2PlusMainSoftwareComponentItem(conditions, new PartNumberArtifactVersion(771), 1, false, "")
                }, 4, 2, 3, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true,
                nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions1 = new BaseCondition[] { new VariantCondition(new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must)) };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false, parentNodes, conditions1, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            newNodeTemplate.Components.SetParent(newNodeTemplate);

            /* Setup node */
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions2 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components2 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes1, conditions2, parameterGroups1, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, oldNodeTemplate, new TestSource(), false);

            var projectStage = string.Empty;
            PartDecorator<BasePart> decoratedPart = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(4435), 1, projectStage, false), 1);
            BaseSource source = new TestSource();
            node.AddSoftwareSlot(new Tea2PlusMainSoftwareSlot(new PartNumberArtifactVersion(4435), "MSW", decoratedPart, source, 4, 1, 7, false, true, NotProgrammableInAftermarketScenario.Connected, 7707));

            /* Some mocks */
            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Single().Equals(newNodeTemplate)),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(Array.Empty<BillOfMaterialContent<PartDecorator<BaseHardwarePart>>>());

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);

            var softwareConsistencyChecker = new Mock<ISoftwareConsistencyChecker>();
            softwareConsistencyChecker.Setup(x =>
                x.CheckPartsInNode(It.IsAny<IProduct>(), It.IsAny<BaseCanNode>(),
                    It.IsAny<NodeTemplateIssue>(), false, It.IsAny<NotProgrammableInAftermarketScenario>())).Callback(
                        (IProduct _, BaseCanNode baseNode, NodeTemplateIssue _, bool _, NotProgrammableInAftermarketScenario _) => ((Tea2PlusNode)baseNode).MainSoftware.Notifications.Add(new TechnicalError("", "")));

            var productSpecification = new ProductSpecification(
                new[] { new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must) }, Array.Empty<string>(), "U1", null, null, null, "");

            var product = new Mock<IProduct>();
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);
            product.Setup(p => p.RequestMetadata)
                .Returns(new RequestMetadata(new List<BaseNodeIdentification>(), false));

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();

            var requestMetadata = new RequestMetadata(null, false);
            newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                hardwareConsistencyChecker.Object, softwareConsistencyChecker.Object, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected);

            Assert.IsFalse(requestMetadata.LimitedValidationUsed);
        }

        [TestMethod]
        public void Verify_that_LimitedValidationUsed_is_not_set_when_there_are_no_notifications()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");

            IList<BaseCondition> conditions = new BaseCondition[] { new AlwaysMatchCondition() };
            var components = new IComponent[]
            {
                new Tea2PlusMainSoftwareComponent("MSW",
                new[]
                {
                    new Tea2PlusMainSoftwareComponentItem(conditions, new PartNumberArtifactVersion(771), 1, false, "")
                }, 4, 2, 3, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true,
                nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions1 = new BaseCondition[] { new VariantCondition(new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must)) };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false, parentNodes, conditions1, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            /* Setup node */
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions2 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components2 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes1, conditions2, parameterGroups1, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, oldNodeTemplate, new TestSource(), false);

            var projectStage = string.Empty;
            PartDecorator<BasePart> decoratedPart = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(4435), 1, projectStage, false), 1);
            BaseSource source = new TestSource();
            node.AddSoftwareSlot(new Tea2PlusMainSoftwareSlot(new PartNumberArtifactVersion(4435), "MSW", decoratedPart, source, 4, 1, 7, false, true, NotProgrammableInAftermarketScenario.Connected, 7707));

            /* Some mocks */
            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Single().Equals(newNodeTemplate)),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(Array.Empty<BillOfMaterialContent<PartDecorator<BaseHardwarePart>>>());

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);
            var softwareConsistencyChecker = new Mock<ISoftwareConsistencyChecker>();

            var productSpecification = new ProductSpecification(
                new[] { new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must) }, Array.Empty<string>(), "U1", null, null, null, "");

            var product = new Mock<IProduct>();
            product.Setup(p => p.RequestMetadata)
                .Returns(new RequestMetadata(new List<BaseNodeIdentification>(), true));
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();

            var requestMetadata = new RequestMetadata(null, true);
            newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                hardwareConsistencyChecker.Object, softwareConsistencyChecker.Object, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected);

            Assert.IsFalse(requestMetadata.LimitedValidationUsed);
        }

        [TestMethod]
        public void Verify_that_LimitedValidationUsed_is_set_when_there_are_sub_hardware_slot_notifications()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");
            var components = new IComponent[]
            {
                new Tea2PlusSubHardwareComponent("", new List<Tea2PlusSubHardwareComponentItem>(), false, null, null)
            };

            var metaDataRepository = new Mock<IMetaDataRepository>();
            metaDataRepository.Setup(r => r.LoadAllNodeDefinitionsAsync(false)).Returns(
                Task.FromResult<IDictionary<int, BaseNodeDefinition>>(new Dictionary<int, BaseNodeDefinition>()
                {
                    { 1, nodeDefinition }
                }));
            metaDataRepository.Setup(r => r.LoadAllContextsAsync()).Returns(Task.FromResult<IDictionary<int, Context>>(new Dictionary<int, Context>()
            {
                { 1, context }
            }));

            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true,
                nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions1 = new BaseCondition[] { new AlwaysMatchCondition() };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components2 = (IList<IComponent>)components;
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes, conditions1, parameterGroups, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition,
                Array.Empty<ComponentTypeCode>());
            var hardwareTemplateType = new SoftwareTemplateType("guid2", "name2", false, false, nodeDefinition,
                Array.Empty<ComponentTypeCode>());

            /* Setup node */
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions2 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components3 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType, context, 0.ToString(), false, parentNodes1, conditions2, parameterGroups1, components3, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, oldNodeTemplate,
                new TestSource(), false);

            var projectStage = string.Empty;
            NonDownloadableComponentType type = new("", ComponentTypeCode.Tea2PlusSubHardware, "", "", 0);
            PartDecorator<BasePart> decoratedPart = new FilledPartDecorator<BasePart>(
                new SubHardwarePart(new PartNumberArtifactVersion(999), 0, 1, projectStage, type, null), 1);
            BaseSource source = new TestSource();
            var slot = new Tea2PlusSubHardwareSlot(new PartNumberArtifactVersion(999), "subHw", decoratedPart, source);
            node.SubHardware.Add(slot);

            /* Some mocks */
            IList<BaseCondition> conditions = new List<BaseCondition> { new AlwaysMatchCondition() };
            IList<IComponent> components1 = new List<IComponent>()
            {
                new Tea2PlusSubHardwareComponent("subhw1", new List<Tea2PlusSubHardwareComponentItem>()
                {
                    new Tea2PlusSubHardwareComponentItem(conditions, new PartNumberArtifactVersion(1), 1, false, "")
                }, false, null, null)
            };
            var version =
                new Model.NodeTemplate.NodeTemplate(0, "v1", new List<NodeTemplateIssue>()
                {
                    new NodeTemplateIssue("guidv1", 2, 0, 1, "v1", "", hardwareTemplateType, context, 0.ToString(), false, (IList<Model.NodeTemplate.ParentNode>)null, (IList<BaseCondition>)null, (IEnumerable<ParameterGroup>)null, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null)
                }, null);

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate> { version });
            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);

            var projectStage1 = string.Empty;
            NonDownloadableComponentType type1 = new("guid1", ComponentTypeCode.Tea2PlusSubHardware, "name1", "desc1", 0);
            var newHardware = new[]
            {
                new BillOfMaterialContent<PartDecorator<BaseHardwarePart>>(
                    new FilledPartDecorator<BaseHardwarePart>(
                        new SubHardwarePart(new PartNumberArtifactVersion(112), 0, 2, projectStage1, type1, null),
                        2), null, null, new List<BaseNotification> {new HardwareUndocumented(HardwareType.SubHardware, "name1", 1, "partname")}),
            };

            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Single().Equals(newNodeTemplate)),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(newHardware);

            var softwareConsistencyChecker = new Mock<ISoftwareConsistencyChecker>();
            var productSpecification = new ProductSpecification(
                Array.Empty<Variant>(), Array.Empty<string>(), "U1", null, null, null, "");

            var product = new Mock<IProduct>();
            product.Setup(p => p.RequestMetadata)
                .Returns(new RequestMetadata(new List<BaseNodeIdentification>(), true));
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();

            var requestMetadata = new RequestMetadata(null, true);
            var newNode = newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                    hardwareConsistencyChecker.Object, softwareConsistencyChecker.Object, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected) as Tea2PlusNode;
            Assert.IsNotNull(newNode);
            Assert.AreEqual(1, newNode.SubHardware.Count);
            Assert.AreEqual(0, newNode.SubHardware[0].Notifications.Count);
        }

        [TestMethod]
        public void Verify_that_LimitedValidationUsed_is_not_set_when_there_are_no_software_slot_notifications()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");

            IList<BaseCondition> conditions = new BaseCondition[] { new AlwaysMatchCondition() };
            var components = new IComponent[]
            {
                new Tea2PlusMainSoftwareComponent("MSW",
                new[]
                {
                    new Tea2PlusMainSoftwareComponentItem(conditions, new PartNumberArtifactVersion(771), 1, false, "")
                }, 4, 2, 3, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true,
                nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions1 = new BaseCondition[] { new VariantCondition(new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must)) };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false, parentNodes, conditions1, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            /* Setup node */
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions2 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components2 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes1, conditions2, parameterGroups1, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, oldNodeTemplate, new TestSource(), false);

            var projectStage = string.Empty;
            PartDecorator<BasePart> decoratedPart = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(4435), 1, projectStage, false), 1);
            BaseSource source = new TestSource();
            var tea2PlusMainSoftwareSlot = new Tea2PlusMainSoftwareSlot(new PartNumberArtifactVersion(4435), "MSW", decoratedPart, source, 4, 1, 7, false, true, NotProgrammableInAftermarketScenario.Connected, 7707);
            node.AddSoftwareSlot(tea2PlusMainSoftwareSlot);

            /* Some mocks */
            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Single().Equals(newNodeTemplate)),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(Array.Empty<BillOfMaterialContent<PartDecorator<BaseHardwarePart>>>());

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);
            var softwareConsistencyChecker = new Mock<ISoftwareConsistencyChecker>();

            var productSpecification = new ProductSpecification(
                new[] { new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must) }, Array.Empty<string>(), "U1", null, null, null, "");

            var product = new Mock<IProduct>();
            product.Setup(p => p.RequestMetadata)
                .Returns(new RequestMetadata(new List<BaseNodeIdentification>(), true));
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();

            var requestMetadata = new RequestMetadata(null, true);
            newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                    hardwareConsistencyChecker.Object, softwareConsistencyChecker.Object, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected);
            Assert.IsFalse(requestMetadata.LimitedValidationUsed);
        }

        [TestMethod]
        public void Verify_that_LimitedValidationUsed_is_set_when_there_are_software_slot_notifications()
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "EMS");

            IList<BaseCondition> conditions = new BaseCondition[] { new AlwaysMatchCondition() };
            var components = new IComponent[]
            {
                new Tea2PlusMainSoftwareComponent("MSW",
                new[]
                {
                    new Tea2PlusMainSoftwareComponentItem(conditions, new PartNumberArtifactVersion(771), 1, false, "")
                }, 4, 2, 3, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true,
                nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions1 = new BaseCondition[] { new VariantCondition(new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must)) };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false, parentNodes, conditions1, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            /* Setup node */
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var conditions2 = (IList<BaseCondition>)Array.Empty<BaseCondition>();
            var parameterGroups1 = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components2 = (IList<IComponent>)Array.Empty<IComponent>();
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType1, context, 0.ToString(), false, parentNodes1, conditions2, parameterGroups1, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, "EMS"), nodeDefinition, oldNodeTemplate, new TestSource(), false);
            var projectStage = string.Empty;
            PartDecorator<BasePart> decoratedPart = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(4435), 1, projectStage, false), 1);
            BaseSource source = new TestSource();
            node.AddSoftwareSlot(new Tea2PlusMainSoftwareSlot(new PartNumberArtifactVersion(4435), "MSW", decoratedPart, source, 4, 1, 7, false, true, NotProgrammableInAftermarketScenario.Connected, 7707));

            /* Some mocks */
            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.Is<IList<BaseNodeIdentification>>(y => Equals(y.Single(), node.NodeName)),
                It.Is<IList<NodeTemplateIssue>>(y => y.Single().Equals(newNodeTemplate)),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(Array.Empty<BillOfMaterialContent<PartDecorator<BaseHardwarePart>>>());

            var nonDownloadableTemplateContainer = new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer).Returns(nonDownloadableTemplateContainer);

            var softwareConsistencyChecker = new Mock<ISoftwareConsistencyChecker>();
            softwareConsistencyChecker.Setup(x =>
                x.CheckPartsInNode(It.IsAny<IProduct>(), It.IsAny<BaseCanNode>(),
                    It.IsAny<NodeTemplateIssue>(), false, It.IsAny<NotProgrammableInAftermarketScenario>())).Callback(
                        (IProduct _, BaseCanNode baseNode, NodeTemplateIssue _, bool _, NotProgrammableInAftermarketScenario _) => ((Tea2PlusNode)baseNode).MainSoftware.Notifications.Add(new TechnicalError("", "")));

            var productSpecification = new ProductSpecification(
                new[] { new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must) }, Array.Empty<string>(), "U1", null, null, null, "");

            var requestMetadata = new RequestMetadata(null, true);

            var product = new Mock<IProduct>();
            product.Setup(p => p.RequestMetadata)
                .Returns(requestMetadata);
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);

            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();

            var newNode = newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                    hardwareConsistencyChecker.Object, softwareConsistencyChecker.Object, false, compatibleHardwareFilter.Object, NotProgrammableInAftermarketScenario.Connected) as Tea2PlusNode;
            Assert.IsNotNull(newNode);
            Assert.IsNotNull(newNode.MainSoftware);
            Assert.AreEqual(0, newNode.MainSoftware.Notifications.Count);
            Assert.IsTrue(requestMetadata.LimitedValidationUsed);
        }

        [TestMethod]
        public void Verify_that_limited_validation_is_suppressed_for_SEM_complementary_software()
        {
            var (newNode, requestMetadata) = ApplyNodeTemplateWithNonProgrammableCswNotification("SEM");

            var csw = newNode.ComplementarySoftwares.Single(x => x.Name == "CSW");
            Assert.AreEqual(1, csw.Notifications.Count);
            Assert.IsFalse(requestMetadata.LimitedValidationUsed);
        }

        [TestMethod]
        public void Verify_that_limited_validation_is_still_applied_for_non_SEM_complementary_software()
        {
            var (newNode, requestMetadata) = ApplyNodeTemplateWithNonProgrammableCswNotification("EMS");

            var csw = newNode.ComplementarySoftwares.Single(x => x.Name == "CSW");
            Assert.AreEqual(0, csw.Notifications.Count);
            Assert.IsTrue(requestMetadata.LimitedValidationUsed);
        }

        private static (Tea2PlusNode newNode, RequestMetadata requestMetadata) ApplyNodeTemplateWithNonProgrammableCswNotification(string nodeName)
        {
            /* Setup new node template */
            var context = Helper.CreateContext("2", "U1", "context1", false, true);
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, nodeName);

            IList<BaseCondition> conditions = new BaseCondition[] { new AlwaysMatchCondition() };
            var components = new IComponent[]
            {
                new Tea2PlusComplementarySoftwareComponent("CSW",
                new[]
                {
                    new Tea2PlusComplementarySoftwareComponentItem(conditions, new PartNumberArtifactVersion(771), 1, false, "")
                }, 4, 2, 3, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true,
                nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions1 = new BaseCondition[] { new VariantCondition(new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must)) };
            var newNodeTemplate = new NodeTemplateIssue("", 1, 4455, 7, "", "", templateType, context, 0.ToString(), false,
                (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>(), conditions1,
                (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>(), (IList<IComponent>)components, true, true,
                (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            /* Setup node */
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var oldNodeTemplate = new NodeTemplateIssue("", 2, 9876, 7, "", "", templateType1, context, 0.ToString(), false,
                (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>(), (IList<BaseCondition>)Array.Empty<BaseCondition>(),
                (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>(), (IList<IComponent>)Array.Empty<IComponent>(), true, true,
                (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var node = new Tea2PlusNode(4455, new NodeName(2, 1, nodeName), nodeDefinition, oldNodeTemplate, new TestSource(), false);
            PartDecorator<BasePart> decoratedPart = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(4435), 1, string.Empty, false), 1);
            node.AddSoftwareSlot(new Tea2PlusComplementarySoftwareSlot(new PartNumberArtifactVersion(4435), "CSW", decoratedPart, new TestSource(), 4, 1, 7, false, true, NotProgrammableInAftermarketScenario.Connected, 7707));

            /* Some mocks */
            var hardwareConsistencyChecker = new Mock<IHardwareConsistencyChecker>();
            hardwareConsistencyChecker.Setup(x => x.CheckHardwareConsistency(
                It.IsAny<IList<BaseNodeIdentification>>(),
                It.IsAny<IList<NodeTemplateIssue>>(),
                It.IsAny<IList<BillOfMaterialContent<BaseHardwarePart>>>(),
                null,
                It.IsAny<IProductionBillOfMaterial>(), It.IsAny<ICompatibleHardwareFilter>(), true, false))
                .Returns(Array.Empty<BillOfMaterialContent<PartDecorator<BaseHardwarePart>>>());
            hardwareConsistencyChecker.Setup(x => x.HardwareContainer)
                .Returns(new NonDownloadableTemplateContainer(new List<Model.NodeTemplate.NodeTemplate>()));

            var softwareConsistencyChecker = new Mock<ISoftwareConsistencyChecker>();
            softwareConsistencyChecker.Setup(x =>
                x.CheckPartsInNode(It.IsAny<IProduct>(), It.IsAny<BaseCanNode>(),
                    It.IsAny<NodeTemplateIssue>(), false, It.IsAny<NotProgrammableInAftermarketScenario>())).Callback(
                        (IProduct _, BaseCanNode baseNode, NodeTemplateIssue _, bool _, NotProgrammableInAftermarketScenario _) =>
                            ((Tea2PlusNode)baseNode).ComplementarySoftwares.Single(x => x.Name == "CSW").Notifications.Add(new TechnicalError("", "")));

            var productSpecification = new ProductSpecification(
                new[] { new Variant("AAA", "111", "symbol_A", VariantFamilyType.Must) }, Array.Empty<string>(), "U1", null, null, null, "");

            var requestMetadata = new RequestMetadata(null, true);

            var product = new Mock<IProduct>();
            product.Setup(p => p.RequestMetadata).Returns(requestMetadata);
            product.Setup(p => p.ProductSpecification).Returns(productSpecification);

            var newNode = newNodeTemplate.ApplyNodeTemplateToNode(product.Object, node,
                hardwareConsistencyChecker.Object, softwareConsistencyChecker.Object, false,
                new Mock<ICompatibleHardwareFilter>().Object, NotProgrammableInAftermarketScenario.Connected) as Tea2PlusNode;

            Assert.IsNotNull(newNode);
            return (newNode, requestMetadata);
        }

        [TestMethod]
        public void Verify_that_AssignHardwareToNode_sets_slots()
        {
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "");
            var nonDownloadableTemplateType = new HardwareTemplateType("guid11", "n11", false, false, nodeDefinition.LogicalEcuDefinition,
                new List<ComponentTypeCode>());
            var context = new Context("0", new ProductClass("24", ""), "Ctx1",
                new BaseCondition[] { new AlwaysMatchCondition() }, Array.Empty<ParameterGroup>(), false, true, false, false, null, null);

            var hardwareVersion = new NonDownloadableVersion("hardwareguid1", "SomeHardware", context, nonDownloadableTemplateType, new NonDownloadableComponentType("", ComponentTypeCode.Tea2PlusHardware, "HardwareType", "", 0), "", new List<BaseCondition>() { new AlwaysMatchCondition() }, null,
                null, Array.Empty<NonDownloadableVersionItem>(), null);
            var subhardwareVersion = new NonDownloadableVersion("subhwguid1", "SubHwVersion1", context, nonDownloadableTemplateType, new NonDownloadableComponentType("", ComponentTypeCode.Tea2PlusSubHardware, "SubHwType1", "", 0), "", new List<BaseCondition>() { new AlwaysMatchCondition() },
                null,
                null, Array.Empty<NonDownloadableVersionItem>(), null);

            var nonDownloadableTemplateContainer = new Mock<INonDownloadableTemplateContainer>();
            nonDownloadableTemplateContainer.Setup(x => x.GetVersion("hardwareguid1"))
                .Returns(hardwareVersion);
            nonDownloadableTemplateContainer.Setup(x => x.GetVersion("subhwguid1"))
                .Returns(subhardwareVersion);

            var productSpecification = new Mock<IProductSpecification>();

            var product = new Mock<IProduct>();
            product.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);

            var conditionMatcher = new Mock<IConditionMatcher>();
            conditionMatcher.Setup(x => x.Execute(product.Object, hardwareVersion, true))
                    .Returns(new List<ItemConditionContainer<NonDownloadableVersionItem>>
                    {
                        new ItemConditionContainer<NonDownloadableVersionItem>
                        {
                            Condition = new VariantCondition(new Variant("AAA", "BBB", "Symbol1", VariantFamilyType.Can)),
                            Item = new NonDownloadableVersionItem((NonDownloadableVersion)null, 301, 1, "", null)
                        }
                    });

            IList<BaseCondition> conditions = new[] { new AlwaysMatchCondition() };
            var components = new IComponent[]
            {
                new Tea2PlusHardwareComponent("Component1", new List<Tea2PlusHardwareComponentItem>(), false, null, null),
                new Tea2PlusMainSoftwareComponent("MSW", new[] {new Tea2PlusMainSoftwareComponentItem(conditions, new PartNumberArtifactVersion(505), 1, false, "") },
                    1, 2, 3, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null)
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions2 = new BaseCondition[] { new AlwaysMatchCondition() };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var sut = new NodeTemplateIssue("", 0, 200, 3, "", "", templateType, context, 0.ToString(), true, parentNodes, conditions2, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            sut.Components.SetParent(sut);

            var originalNode = new Tea2PlusNode(199, new NodeName(2, 1, ""), nodeDefinition, null as NodeTemplateIssue, new TestSource(),
                false);

            var hardwareVersionGuids = new[] { "subhwguid1", "hardwareguid1" };
            IList<BaseCondition> conditions1 = new BaseCondition[] { new AlwaysMatchCondition() };
            conditionMatcher.Setup(x => x.Execute(product.Object, subhardwareVersion, true)).Returns(new[]
            {
                new ItemConditionContainer<NonDownloadableVersionItem>
                {
                    Condition = new AlwaysMatchCondition(),
                    Item =
                        new NonDownloadableVersionItem(subhardwareVersion, 404, 3, "", conditions1)
                }
            });

            var result =
                sut.AssignHardwareToNode(product.Object, originalNode,
                    nonDownloadableTemplateContainer.Object, conditionMatcher.Object, hardwareVersionGuids, false) as Tea2PlusNode;

            Assert.IsNotNull(result);
            Assert.AreEqual(200, result.DocumentNumber);
            Assert.AreEqual(originalNode.NodeName, result.NodeName);
            Assert.AreEqual(301, result.EcuHardwarePartNumber);

            Assert.AreEqual(1, result.SubHardware.Count);
            Assert.AreEqual(404.ToArtifactVersion(), result.SubHardware[0].ArtifactVersion);
            Assert.AreEqual(3, result.SubHardware[0].DecoratedPart.Value.Quantity);
            Assert.AreEqual(505.ToArtifactVersion(), result.MainSoftwareArtifactVersion);
        }

        [TestMethod]
        public void Verify_that_AssignHardwareToNode_only_applies_subhardware_for_current_nodedefinition()
        {
            var nodeDefinition = new Tea2PlusNodeDefinition(2, 1, "");
            var nonDownloadableTemplateType = new HardwareTemplateType("guid11", "n11", false, false, nodeDefinition.LogicalEcuDefinition,
                new List<ComponentTypeCode>());
            var nodeDefinition2 = new Tea2PlusNodeDefinition(6, 1, "");
            var nonDownloadableTemplateType2 = new HardwareTemplateType("guid22", "n11", false, false, nodeDefinition2.LogicalEcuDefinition,
                new List<ComponentTypeCode>());
            var context = new Context("0", new ProductClass("24", ""), "Ctx1",
                new BaseCondition[] { new AlwaysMatchCondition() }, Array.Empty<ParameterGroup>(), false, true, false, false, null, null);

            var hardwareVersion = new NonDownloadableVersion("", "SomeHardware", context, nonDownloadableTemplateType, new NonDownloadableComponentType("", ComponentTypeCode.Tea2PlusHardware, "HardwareType", "", 0), "", new List<BaseCondition>() { new AlwaysMatchCondition() }, null,
                null, Array.Empty<NonDownloadableVersionItem>(), null);

            var subhardwareVersion = new NonDownloadableVersion("", "SubHwVersion1", context, nonDownloadableTemplateType, new NonDownloadableComponentType("", ComponentTypeCode.Tea2PlusSubHardware, "SubHwType1", "", 0), "", new List<BaseCondition>() { new AlwaysMatchCondition() },
                null,
                null, Array.Empty<NonDownloadableVersionItem>(), null);

            var subhardwareVersionForIncorrectNode = new NonDownloadableVersion("", "SubHwVersion2", context, nonDownloadableTemplateType2, new NonDownloadableComponentType("", ComponentTypeCode.Tea2PlusSubHardware, "SubHwType2", "", 0), "", new List<BaseCondition>() { new AlwaysMatchCondition() },
                null,
                null, Array.Empty<NonDownloadableVersionItem>(), null);

            var nonDownloadableTemplateContainer = new Mock<INonDownloadableTemplateContainer>();
            nonDownloadableTemplateContainer.Setup(x => x.GetVersion("subhwguid1")).Returns(subhardwareVersion);
            nonDownloadableTemplateContainer.Setup(x => x.GetVersion("subhwguid2")).Returns(subhardwareVersionForIncorrectNode);
            nonDownloadableTemplateContainer.Setup(x => x.GetVersion("hardwareguid1")).Returns(hardwareVersion);

            var originalNode = new Tea2PlusNode(199, new NodeName(2, 1, ""), nodeDefinition, null as NodeTemplateIssue, new TestSource(),
                false);

            var productSpecification = new Mock<IProductSpecification>();

            var product = new Mock<IProduct>();
            product.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);

            var conditionMatcher = new Mock<IConditionMatcher>();
            conditionMatcher.Setup(x => x.Execute(product.Object, hardwareVersion, true)).Returns(new[]
            {
                new ItemConditionContainer<NonDownloadableVersionItem>
                {
                    Condition = new AlwaysMatchCondition(),
                    Item = new NonDownloadableVersionItem(hardwareVersion,999, 1, "", null)
                }
            });
            IList<BaseCondition> conditions = new BaseCondition[] { new AlwaysMatchCondition() };
            conditionMatcher.Setup(x => x.Execute(product.Object, subhardwareVersion, true)).Returns(new[]
            {
                new ItemConditionContainer<NonDownloadableVersionItem>
                {
                    Condition = new AlwaysMatchCondition(),
                    Item =
                        new NonDownloadableVersionItem(subhardwareVersion,404, 3, "", conditions)
                }
            });

            var subhardwareVersionGuids = new[] { "subhwguid2", "subhwguid1" };
            var components = new IComponent[]
            {
                new Tea2PlusHardwareComponent("Component1", new List<Tea2PlusHardwareComponentItem>(), false, null, null)
            };
            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<BaseCondition> conditions1 = new BaseCondition[] { new AlwaysMatchCondition() };
            var parentNodes = (IList<Model.NodeTemplate.ParentNode>)Array.Empty<Model.NodeTemplate.ParentNode>();
            var parameterGroups = (IEnumerable<ParameterGroup>)Array.Empty<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var sut = new NodeTemplateIssue("", 0, 200, 3, "", "", templateType, context, 0.ToString(), true, parentNodes, conditions1, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var result =
                sut.AssignHardwareToNode(product.Object, originalNode,
                    nonDownloadableTemplateContainer.Object, conditionMatcher.Object, subhardwareVersionGuids, false) as Tea2PlusNode;

            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.SubHardware.Count);
            Assert.AreEqual(404.ToArtifactVersion(), result.SubHardware[0].ArtifactVersion);
            Assert.AreEqual(3, result.SubHardware[0].DecoratedPart.Value.Quantity);
        }

        [TestMethod]
        public void IsAfterMarketEquivalent_IsEquivalent()
        {
            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            var parentNodes = new List<Model.NodeTemplate.ParentNode>();
            var conditions = new List<BaseCondition>();
            var parameterGroups = new List<ParameterGroup>();
            var components = new List<IComponent>();
            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions1 = (IList<BaseCondition>)conditions;
            var parameterGroups1 = (IEnumerable<ParameterGroup>)parameterGroups;
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes1, conditions1, parameterGroups1, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes2 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions2 = (IList<BaseCondition>)conditions;
            var parameterGroups2 = (IEnumerable<ParameterGroup>)parameterGroups;
            var components2 = (IList<IComponent>)components;
            var nodeTemplateIssueOther = new NodeTemplateIssue("", 2, 23456789, 1, "", "", templateType1, context, 1.ToString(), false, parentNodes2, conditions2, parameterGroups2, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            Assert.IsTrue(nodeTemplateIssue.IsAfterMarketEquivalent(nodeTemplateIssueOther));
        }

        [TestMethod]
        public void IsAfterMarketEquivalent_IsNotEquivalent_OtherIsNull()
        {
            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            var parentNodes = new List<Model.NodeTemplate.ParentNode>();
            var conditions = new List<BaseCondition>();
            var parameterGroups = new List<ParameterGroup>();
            var components = new List<IComponent>();
            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions1 = (IList<BaseCondition>)conditions;
            var parameterGroups1 = (IEnumerable<ParameterGroup>)parameterGroups;
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes1, conditions1, parameterGroups1, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            Assert.IsFalse(nodeTemplateIssue.IsAfterMarketEquivalent(null));
        }

        [TestMethod]
        public void IsAfterMarketEquivalent_IsNotEquivalent_ContextMismatch()
        {
            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            var parentNodes = new List<Model.NodeTemplate.ParentNode>();
            var conditions = new List<BaseCondition>();
            var parameterGroups = new List<ParameterGroup>();
            var components = new List<IComponent>();
            var templateType = new SoftwareTemplateType("guid1", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions1 = (IList<BaseCondition>)conditions;
            var parameterGroups1 = (IEnumerable<ParameterGroup>)parameterGroups;
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes1, conditions1, parameterGroups1, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var templateType1 = new SoftwareTemplateType("guid2", "name2", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes2 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions2 = (IList<BaseCondition>)conditions;
            var parameterGroups2 = (IEnumerable<ParameterGroup>)parameterGroups;
            var components2 = (IList<IComponent>)components;
            var nodeTemplateIssueOther = new NodeTemplateIssue("", 2, 23456789, 1, "", "", templateType1, context, 1.ToString(), false, parentNodes2, conditions2, parameterGroups2, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            Assert.IsFalse(nodeTemplateIssue.IsAfterMarketEquivalent(nodeTemplateIssueOther));
        }

        [TestMethod]
        public void IsAfterMarketEquivalent_IsNotEquivalent_NodeDefinitionMismatch()
        {
            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            var nodeDefinitionOther = new Tea2PlusNodeDefinition(2, 1, "2.1");
            var parentNodes = new List<Model.NodeTemplate.ParentNode>();
            var conditions = new List<BaseCondition>();
            var parameterGroups = new List<ParameterGroup>();
            var components = new List<IComponent>();
            var templateType = new SoftwareTemplateType("guid1", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions1 = (IList<BaseCondition>)conditions;
            var parameterGroups1 = (IEnumerable<ParameterGroup>)parameterGroups;
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes1, conditions1, parameterGroups1, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var templateType1 = new SoftwareTemplateType("guid2", "name2", true, true, nodeDefinitionOther, Array.Empty<ComponentTypeCode>());
            var parentNodes2 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions2 = (IList<BaseCondition>)conditions;
            var parameterGroups2 = (IEnumerable<ParameterGroup>)parameterGroups;
            var components2 = (IList<IComponent>)components;
            var nodeTemplateIssueOther = new NodeTemplateIssue("", 2, 23456789, 1, "", "", templateType1, context, 1.ToString(), false, parentNodes2, conditions2, parameterGroups2, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            Assert.IsFalse(nodeTemplateIssue.IsAfterMarketEquivalent(nodeTemplateIssueOther));
        }

        [TestMethod]
        public void IsAfterMarketEquivalent_IsNotEquivalent_ConditionsMismatch()
        {
            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            var parentNodes = new List<Model.NodeTemplate.ParentNode>();
            var conditions = new List<BaseCondition>();
            var otherConditions = new List<BaseCondition>() { new AlwaysMatchCondition() };
            var parameterGroups = new List<ParameterGroup>();
            var components = new List<IComponent>();
            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions1 = (IList<BaseCondition>)conditions;
            var parameterGroups1 = (IEnumerable<ParameterGroup>)parameterGroups;
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes1, conditions1, parameterGroups1, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes2 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions2 = (IList<BaseCondition>)otherConditions;
            var parameterGroups2 = (IEnumerable<ParameterGroup>)parameterGroups;
            var components2 = (IList<IComponent>)components;
            var nodeTemplateIssueOther = new NodeTemplateIssue("", 2, 23456789, 1, "", "", templateType1, context, 1.ToString(), false, parentNodes2, conditions2, parameterGroups2, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            Assert.IsFalse(nodeTemplateIssue.IsAfterMarketEquivalent(nodeTemplateIssueOther));
        }

        [TestMethod]
        public void IsAfterMarketEquivalent_IsNotEquivalent_ParentNodesMismatch()
        {
            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            var otherParentNodes = new List<Model.NodeTemplate.ParentNode>() { new Model.NodeTemplate.ParentNode(new List<BaseCondition>(), null) };
            var conditions = new List<BaseCondition>();
            var parentNodes = new List<Model.NodeTemplate.ParentNode>();
            var parameterGroups = new List<ParameterGroup>();
            var components = new List<IComponent>();
            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions1 = (IList<BaseCondition>)conditions;
            var parameterGroups1 = (IEnumerable<ParameterGroup>)parameterGroups;
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes1, conditions1, parameterGroups1, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes2 = (IList<Model.NodeTemplate.ParentNode>)otherParentNodes;
            var conditions2 = (IList<BaseCondition>)conditions;
            var parameterGroups2 = (IEnumerable<ParameterGroup>)parameterGroups;
            var components2 = (IList<IComponent>)components;
            var nodeTemplateIssueOther = new NodeTemplateIssue("", 2, 23456789, 1, "", "", templateType1, context, 1.ToString(), false, parentNodes2, conditions2, parameterGroups2, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            Assert.IsFalse(nodeTemplateIssue.IsAfterMarketEquivalent(nodeTemplateIssueOther));
        }

        [TestMethod]
        public void IsAfterMarketEquivalent_IsNotEquivalent_ParameterGroupsMismatch()
        {
            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            var conditions = new List<BaseCondition>();
            var parentNodes = new List<Model.NodeTemplate.ParentNode>();
            var parameterGroups = new List<ParameterGroup>();
            var otherParameterGroups = new List<ParameterGroup>() { new ParameterGroup("name", new List<BaseParameterVerification>(), new List<BaseParameterCalculation>(), new List<BaseCondition>()) };
            var components = new List<IComponent>();
            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions1 = (IList<BaseCondition>)conditions;
            var parameterGroups1 = (IEnumerable<ParameterGroup>)parameterGroups;
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes1, conditions1, parameterGroups1, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes2 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions2 = (IList<BaseCondition>)conditions;
            var parameterGroups2 = (IEnumerable<ParameterGroup>)otherParameterGroups;
            var components2 = (IList<IComponent>)components;
            var nodeTemplateIssueOther = new NodeTemplateIssue("", 2, 23456789, 1, "", "", templateType1, context, 1.ToString(), false, parentNodes2, conditions2, parameterGroups2, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            Assert.IsFalse(nodeTemplateIssue.IsAfterMarketEquivalent(nodeTemplateIssueOther));
        }

        [TestMethod]
        public void IsAfterMarketEquivalent_IsNotEquivalent_ComponentsMismatch()
        {
            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            var conditions = new List<BaseCondition>();
            var parentNodes = new List<Model.NodeTemplate.ParentNode>();
            var parameterGroups = new List<ParameterGroup>();
            var components = new List<IComponent>();
            var otherComponents = new List<IComponent>() { new Tea2PlusHardwareComponent("name", new List<Tea2PlusHardwareComponentItem>(), false, null, null) };
            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes1 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions1 = (IList<BaseCondition>)conditions;
            var parameterGroups1 = (IEnumerable<ParameterGroup>)parameterGroups;
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes1, conditions1, parameterGroups1, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            var parentNodes2 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions2 = (IList<BaseCondition>)conditions;
            var parameterGroups2 = (IEnumerable<ParameterGroup>)parameterGroups;
            var components2 = (IList<IComponent>)otherComponents;
            var nodeTemplateIssueOther = new NodeTemplateIssue("", 2, 23456789, 1, "", "", templateType1, context, 1.ToString(), false, parentNodes2, conditions2, parameterGroups2, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            Assert.IsFalse(nodeTemplateIssue.IsAfterMarketEquivalent(nodeTemplateIssueOther));
        }

        [TestMethod]
        public void DeriveCompatibilityCondition_NoComponents()
        {
            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();
            compatibleHardwareFilter.Setup(chf => chf.NodeTemplateIssueIsWithdrawn(It.IsAny<NodeTemplateIssue>()))
                .Returns(false);

            var productSpecification = new Mock<IProductSpecification>();

            var product = new Mock<IProduct>();

            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            var components = new List<IComponent>() { new Tea2PlusHardwareComponent("name", new List<Tea2PlusHardwareComponentItem>(), false, null, null) };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IEnumerable<ParameterGroup> parameterGroups = new List<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes, conditions, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            var result = nodeTemplateIssue.DeriveCompatibilityConditions(product.Object, compatibleHardwareFilter.Object);

            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(0, result.Single().Items.Count());

            productSpecification.VerifyAll();
            product.VerifyAll();
        }

        [TestMethod]
        public void DeriveCompatibilityCondition_OneFilledComponent()
        {
            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();
            compatibleHardwareFilter.Setup(chf => chf.NodeTemplateIssueIsWithdrawn(It.IsAny<NodeTemplateIssue>()))
                .Returns(false);

            var productSpecification = new Mock<IProductSpecification>();

            var product = new Mock<IProduct>();
            product.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);

            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            IList<BaseCondition> conditions = new List<BaseCondition>() { new AlwaysMatchCondition() };
            var components = new List<IComponent>()
            {
                new Tea2PlusHardwareComponent("name", new List<Tea2PlusHardwareComponentItem>(), false, null, null),
                new Tea2PlusPrimaryBootLoaderComponent("PBL1", new List<Tea2PlusPrimaryBootLoaderComponentItem>()
                {
                    new Tea2PlusPrimaryBootLoaderComponentItem(conditions, new PartNumberArtifactVersion(1000), 1, false, "P")
                },0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null)
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions1 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IEnumerable<ParameterGroup> parameterGroups = new List<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes, conditions1, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            foreach (var component in nodeTemplateIssue.Components)
            {
                component.SetParent(nodeTemplateIssue);
            }

            var result = nodeTemplateIssue.DeriveCompatibilityConditions(product.Object, compatibleHardwareFilter.Object);

            Assert.AreEqual(1, result.Count);
            var item1 = result.Single().Items.Single();
            Assert.AreEqual(1000.ToArtifactVersion(), item1.ArtifactVersion);
            Assert.AreEqual(1, item1.Quantity);
            Assert.AreEqual("PBL", item1.SlotType);
            Assert.AreEqual("PBL1", item1.SlotName);
            Assert.AreEqual("PBL1 software item from node template 12345678", item1.Source.ToString());

            productSpecification.VerifyAll();

            product.VerifyAll();
        }

        [TestMethod]
        public void DeriveCompatibilityCondition_OneOverflowComponent()
        {
            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();
            compatibleHardwareFilter.Setup(chf => chf.NodeTemplateIssueIsWithdrawn(It.IsAny<NodeTemplateIssue>()))
                .Returns(false);

            var productSpecification = new Mock<IProductSpecification>();

            var product = new Mock<IProduct>();
            product.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);

            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            IList<BaseCondition> conditions = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions1 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            var components = new List<IComponent>()
            {
                new Tea2PlusHardwareComponent("name", new List<Tea2PlusHardwareComponentItem>(), false, null, null),
                new Tea2PlusPrimaryBootLoaderComponent("PBL1", new List<Tea2PlusPrimaryBootLoaderComponentItem>()
                {
                    new Tea2PlusPrimaryBootLoaderComponentItem(conditions, new PartNumberArtifactVersion(1000), 1, false, "P"),
                    new Tea2PlusPrimaryBootLoaderComponentItem(conditions1, new PartNumberArtifactVersion(2000), 1, false, "P"),
                },0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null)
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions2 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IEnumerable<ParameterGroup> parameterGroups = new List<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes, conditions2, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            foreach (var component in nodeTemplateIssue.Components)
            {
                component.SetParent(nodeTemplateIssue);
            }

            var result = nodeTemplateIssue.DeriveCompatibilityConditions(product.Object, compatibleHardwareFilter.Object);

            Assert.AreEqual(2, result.Count);
            Assert.IsNotNull(result.Single(r => r.Items.Count() == 1 && r.Items.Any(i => Equals(i.ArtifactVersion, 1000.ToArtifactVersion()))));
            Assert.IsNotNull(result.Single(r => r.Items.Count() == 1 && r.Items.Any(i => Equals(i.ArtifactVersion, 2000.ToArtifactVersion()))));

            productSpecification.VerifyAll();

            product.VerifyAll();
        }

        [TestMethod]
        public void DeriveCompatibilityCondition_TwoOverflowComponents()
        {
            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();
            compatibleHardwareFilter.Setup(chf => chf.NodeTemplateIssueIsWithdrawn(It.IsAny<NodeTemplateIssue>()))
                .Returns(false);

            var productSpecification = new Mock<IProductSpecification>();

            var product = new Mock<IProduct>();
            product.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);

            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            IList<BaseCondition> conditions = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions1 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions2 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions3 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            var components = new List<IComponent>()
            {
                new Tea2PlusHardwareComponent("name", new List<Tea2PlusHardwareComponentItem>(), false, null, null),
                new Tea2PlusPrimaryBootLoaderComponent("PBL1", new List<Tea2PlusPrimaryBootLoaderComponentItem>()
                {
                    new Tea2PlusPrimaryBootLoaderComponentItem(conditions, new PartNumberArtifactVersion(1000), 1, false, "P"),
                    new Tea2PlusPrimaryBootLoaderComponentItem(conditions1, new PartNumberArtifactVersion(2000), 1, false, "P"),
                },0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
                new Tea2PlusSecondaryBootLoaderComponent("SBL1", new List<Tea2PlusSecondaryBootLoaderComponentItem>()
                {
                    new Tea2PlusSecondaryBootLoaderComponentItem(conditions2, new PartNumberArtifactVersion(3000), 1, false, "P"),
                    new Tea2PlusSecondaryBootLoaderComponentItem(conditions3, new PartNumberArtifactVersion(4000), 1, false, "P"),
                },0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null)
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions4 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IEnumerable<ParameterGroup> parameterGroups = new List<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes, conditions4, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            foreach (var component in nodeTemplateIssue.Components)
            {
                component.SetParent(nodeTemplateIssue);
            }

            var result = nodeTemplateIssue.DeriveCompatibilityConditions(product.Object, compatibleHardwareFilter.Object);

            Assert.AreEqual(4, result.Count);

            Assert.IsNotNull(result.Single(r => r.Items.Count() == 2 && r.Items.Any(i => Equals(i.ArtifactVersion, 1000.ToArtifactVersion())) &&
                                           r.Items.Any(i => Equals(i.ArtifactVersion, 3000.ToArtifactVersion()))));
            Assert.IsNotNull(result.Single(r => r.Items.Count() == 2 && r.Items.Any(i => Equals(i.ArtifactVersion, 2000.ToArtifactVersion())) &&
                                                r.Items.Any(i => Equals(i.ArtifactVersion, 3000.ToArtifactVersion()))));
            Assert.IsNotNull(result.Single(r => r.Items.Count() == 2 && r.Items.Any(i => Equals(i.ArtifactVersion, 1000.ToArtifactVersion())) &&
                                                r.Items.Any(i => Equals(i.ArtifactVersion, 4000.ToArtifactVersion()))));
            Assert.IsNotNull(result.Single(r => r.Items.Count() == 2 && r.Items.Any(i => Equals(i.ArtifactVersion, 2000.ToArtifactVersion())) &&
                                                r.Items.Any(i => Equals(i.ArtifactVersion, 4000.ToArtifactVersion()))));

            productSpecification.VerifyAll();

            product.VerifyAll();
        }

        [TestMethod]
        public void DeriveCompatibilityCondition_OneIntentionallyEmptyComponent()
        {
            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();
            compatibleHardwareFilter.Setup(chf => chf.NodeTemplateIssueIsWithdrawn(It.IsAny<NodeTemplateIssue>()))
                .Returns(false);

            var productSpecification = new Mock<IProductSpecification>();

            var product = new Mock<IProduct>();
            product.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);

            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            var components = new List<IComponent>()
            {
                new Tea2PlusHardwareComponent("name", new List<Tea2PlusHardwareComponentItem>(), false, null, null),
                new Tea2PlusPrimaryBootLoaderComponent("PBL1", new List<Tea2PlusPrimaryBootLoaderComponentItem>(),0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, true, false, null, null)
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IEnumerable<ParameterGroup> parameterGroups = new List<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes, conditions, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            foreach (var component in nodeTemplateIssue.Components)
            {
                component.SetParent(nodeTemplateIssue);
            }

            var result = nodeTemplateIssue.DeriveCompatibilityConditions(product.Object, compatibleHardwareFilter.Object);

            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(0, result.Single().Items.Count());

            productSpecification.VerifyAll();

            product.VerifyAll();
        }

        [TestMethod]
        public void DeriveCompatibilityCondition_OneEmptyComponent()
        {
            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();
            compatibleHardwareFilter.Setup(chf => chf.NodeTemplateIssueIsWithdrawn(It.IsAny<NodeTemplateIssue>()))
                .Returns(false);

            var productSpecification = new Mock<IProductSpecification>();

            var product = new Mock<IProduct>();
            product.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);

            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            var components = new List<IComponent>()
            {
                new Tea2PlusHardwareComponent("name", new List<Tea2PlusHardwareComponentItem>(), false, null, null),
                new Tea2PlusPrimaryBootLoaderComponent("PBL1", new List<Tea2PlusPrimaryBootLoaderComponentItem>(),0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null)
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IEnumerable<ParameterGroup> parameterGroups = new List<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes, conditions, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            foreach (var component in nodeTemplateIssue.Components)
            {
                component.SetParent(nodeTemplateIssue);
            }

            var result = nodeTemplateIssue.DeriveCompatibilityConditions(product.Object, compatibleHardwareFilter.Object);

            Assert.IsNull(result);

            productSpecification.VerifyAll();

            product.VerifyAll();
        }

        [TestMethod]
        public void DeriveCompatibilityCondition_TwoComponents_Filled_Filled()
        {
            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();
            compatibleHardwareFilter.Setup(chf => chf.NodeTemplateIssueIsWithdrawn(It.IsAny<NodeTemplateIssue>()))
                .Returns(false);

            var productSpecification = new Mock<IProductSpecification>();

            var product = new Mock<IProduct>();
            product.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);

            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            IList<BaseCondition> conditions = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions1 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            var components = new List<IComponent>()
            {
                new Tea2PlusHardwareComponent("name", new List<Tea2PlusHardwareComponentItem>(), false, null, null),
                new Tea2PlusPrimaryBootLoaderComponent("PBL1", new List<Tea2PlusPrimaryBootLoaderComponentItem>()
                {
                    new Tea2PlusPrimaryBootLoaderComponentItem(conditions, new PartNumberArtifactVersion(1000), 1, false, "P")
                },0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
                new Tea2PlusSecondaryBootLoaderComponent("SBL1", new List<Tea2PlusSecondaryBootLoaderComponentItem>()
                {
                    new Tea2PlusSecondaryBootLoaderComponentItem(conditions1, new PartNumberArtifactVersion(2000), 1, false, "P")
                },0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions2 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IEnumerable<ParameterGroup> parameterGroups = new List<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes, conditions2, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            foreach (var component in nodeTemplateIssue.Components)
            {
                component.SetParent(nodeTemplateIssue);
            }

            var result = nodeTemplateIssue.DeriveCompatibilityConditions(product.Object, compatibleHardwareFilter.Object);

            Assert.AreEqual(1, result.Count);
            Assert.AreEqual(2, result.Single().Items.Count());

            var item1 = result.Single().Items.Single(r => Equals(r.ArtifactVersion, 1000.ToArtifactVersion()));
            Assert.AreEqual(1000.ToArtifactVersion(), item1.ArtifactVersion);
            Assert.AreEqual(1, item1.Quantity);
            Assert.AreEqual("PBL", item1.SlotType);
            Assert.AreEqual("PBL1", item1.SlotName);
            Assert.AreEqual("PBL1 software item from node template 12345678", item1.Source.ToString());

            var item2 = result.Single().Items.Single(r => Equals(r.ArtifactVersion, 2000.ToArtifactVersion()));
            Assert.AreEqual(2000.ToArtifactVersion(), item2.ArtifactVersion);
            Assert.AreEqual(1, item2.Quantity);
            Assert.AreEqual("SBL", item2.SlotType);
            Assert.AreEqual("SBL1", item2.SlotName);
            Assert.AreEqual("SBL1 software item from node template 12345678", item2.Source.ToString());

            productSpecification.VerifyAll();

            product.VerifyAll();
        }

        [TestMethod]
        public void DeriveCompatibilityCondition_TwoComponents_Filled_Filled_NodeTemplateWithdrawn()
        {
            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();
            compatibleHardwareFilter.Setup(chf => chf.NodeTemplateIssueIsWithdrawn(It.IsAny<NodeTemplateIssue>()))
                .Returns(true);

            var productSpecification = new Mock<IProductSpecification>();

            var product = new Mock<IProduct>();

            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            IList<BaseCondition> conditions = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions1 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            var components = new List<IComponent>()
            {
                new Tea2PlusHardwareComponent("name", new List<Tea2PlusHardwareComponentItem>(), false, null, null),
                new Tea2PlusPrimaryBootLoaderComponent("PBL1", new List<Tea2PlusPrimaryBootLoaderComponentItem>()
                {
                    new Tea2PlusPrimaryBootLoaderComponentItem(conditions, new PartNumberArtifactVersion(1000), 1, false, "P")
                },0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
                new Tea2PlusSecondaryBootLoaderComponent("SBL1", new List<Tea2PlusSecondaryBootLoaderComponentItem>()
                {
                    new Tea2PlusSecondaryBootLoaderComponentItem(conditions1, new PartNumberArtifactVersion(2000), 1, false, "P")
                },0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions2 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IEnumerable<ParameterGroup> parameterGroups = new List<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes, conditions2, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            foreach (var component in nodeTemplateIssue.Components)
            {
                component.SetParent(nodeTemplateIssue);
            }

            var result = nodeTemplateIssue.DeriveCompatibilityConditions(product.Object, compatibleHardwareFilter.Object);

            Assert.IsNull(result);

            product.VerifyAll();
        }

        [TestMethod]
        public void DeriveCompatibilityCondition_TwoComponents_Empty_Filled()
        {
            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();
            compatibleHardwareFilter.Setup(chf => chf.NodeTemplateIssueIsWithdrawn(It.IsAny<NodeTemplateIssue>()))
                .Returns(false);

            var productSpecification = new Mock<IProductSpecification>();

            var product = new Mock<IProduct>();
            product.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);

            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            IList<BaseCondition> conditions = new List<BaseCondition>() { new AlwaysMatchCondition() };
            var components = new List<IComponent>()
            {
                new Tea2PlusHardwareComponent("name", new List<Tea2PlusHardwareComponentItem>(), false, null, null),
                new Tea2PlusPrimaryBootLoaderComponent("PBL1", new List<Tea2PlusPrimaryBootLoaderComponentItem>(),0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
                new Tea2PlusSecondaryBootLoaderComponent("SBL1", new List<Tea2PlusSecondaryBootLoaderComponentItem>()
                {
                    new Tea2PlusSecondaryBootLoaderComponentItem(conditions, new PartNumberArtifactVersion(2000), 1, false, "P")
                },0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions1 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IEnumerable<ParameterGroup> parameterGroups = new List<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes, conditions1, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            foreach (var component in nodeTemplateIssue.Components)
            {
                component.SetParent(nodeTemplateIssue);
            }

            var result = nodeTemplateIssue.DeriveCompatibilityConditions(product.Object, compatibleHardwareFilter.Object);

            Assert.IsNull(result);

            productSpecification.VerifyAll();

            product.VerifyAll();
        }

        [TestMethod]
        public void DeriveCompatibilityCondition_TwoComponents_Filled_Empty()
        {
            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();
            compatibleHardwareFilter.Setup(chf => chf.NodeTemplateIssueIsWithdrawn(It.IsAny<NodeTemplateIssue>()))
                .Returns(false);

            var productSpecification = new Mock<IProductSpecification>();

            var product = new Mock<IProduct>();
            product.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);

            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            IList<BaseCondition> conditions = new List<BaseCondition>() { new AlwaysMatchCondition() };
            var components = new List<IComponent>()
            {
                new Tea2PlusHardwareComponent("name", new List<Tea2PlusHardwareComponentItem>(), false, null, null),
                new Tea2PlusSecondaryBootLoaderComponent("SBL1", new List<Tea2PlusSecondaryBootLoaderComponentItem>()
                {
                    new Tea2PlusSecondaryBootLoaderComponentItem(conditions, new PartNumberArtifactVersion(2000), 1, false, "P")
                },0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
                new Tea2PlusPrimaryBootLoaderComponent("PBL1", new List<Tea2PlusPrimaryBootLoaderComponentItem>(),0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions1 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IEnumerable<ParameterGroup> parameterGroups = new List<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var nodeTemplateIssue = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes, conditions1, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            foreach (var component in nodeTemplateIssue.Components)
            {
                component.SetParent(nodeTemplateIssue);
            }

            var result = nodeTemplateIssue.DeriveCompatibilityConditions(product.Object, compatibleHardwareFilter.Object);

            Assert.IsNull(result);

            productSpecification.VerifyAll();

            product.VerifyAll();
        }

        //SelfAndSubNodeTemplateIssues
        [TestMethod]
        public void SelfAndSubNodeTemplateIssues()
        {
            var context = Helper.CreateContext("1", "24", "pc");
            var nodeDefinition = new Tea2PlusNodeDefinition(1, 1, "1.1");
            const int id = 1;
            const int issueNumber = 1;
            const int documentNumber = 123456;
            var conditions = new List<BaseCondition>();
            var parentNodes = new List<Model.NodeTemplate.ParentNode>();
            var parameterGroups1 = new List<ParameterGroup>() { new ParameterGroup("PG1", new List<BaseParameterVerification>(),
                new List<BaseParameterCalculation>(), new List<BaseCondition>())};
            var parameterGroups2 = new List<ParameterGroup>() { new ParameterGroup("PG2", new List<BaseParameterVerification>(),
                new List<BaseParameterCalculation>(), new List<BaseCondition>())};

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<IComponent> components = new List<IComponent>();
            var parentNodes3 = (IList<Model.NodeTemplate.ParentNode>)parentNodes;
            var conditions3 = (IList<BaseCondition>)conditions;
            var parameterGroups3 = (IEnumerable<ParameterGroup>)parameterGroups1;
            var original = new NodeTemplateIssue("guid1", id, documentNumber, issueNumber, "", "", templateType, context, 100.ToString(), true, parentNodes3, conditions3, parameterGroups3, components, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.InProgress, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            var templateType1 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes1 = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions1 = new List<BaseCondition>();
            IList<IComponent> components1 = new List<IComponent>();
            var parameterGroups4 = (IEnumerable<ParameterGroup>)parameterGroups2;
            var other = new NodeTemplateIssue("guid2", id + 1, documentNumber + 1, issueNumber, "", "", templateType1, context, 100.ToString(), false, parentNodes1, conditions1, parameterGroups4, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.InProgress, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            var templateType2 = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes2 = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions2 = new List<BaseCondition>();
            IEnumerable<ParameterGroup> parameterGroups = new List<ParameterGroup>();
            IList<IComponent> components2 = new List<IComponent>();
            var different = new NodeTemplateIssue("guid3", id + 2, documentNumber + 2, issueNumber, "", "", templateType2, context, 0.ToString(), false, parentNodes2, conditions2, parameterGroups, components2, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.InProgress, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);

            var nodeTemplate = original.CloneWithSubTemplates(new List<NodeTemplateIssue>() { other, different }, true);

            var list = nodeTemplate.SelfAndSubNodeTemplateIssues.ToList();

            Assert.AreEqual(3, list.Count);
            Assert.IsTrue(list.SequenceEqual(new List<NodeTemplateIssue>() { other, different, nodeTemplate }));
        }

        [TestMethod]
        public void MatchedSlots_NoSlotsToMatch()
        {
            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();
            compatibleHardwareFilter.Setup(chf => chf.NodeTemplateIssueIsWithdrawn(It.IsAny<NodeTemplateIssue>()))
                .Returns(false);

            var productSpecification = new Mock<IProductSpecification>();

            var product = new Mock<IProduct>();
            product.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);

            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            IList<BaseCondition> conditions = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions1 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            var components = new List<IComponent>()
            {
                new Tea2PlusPrimaryBootLoaderComponent("PBL1", new List<Tea2PlusPrimaryBootLoaderComponentItem>()
                {
                    new Tea2PlusPrimaryBootLoaderComponentItem(conditions, new PartNumberArtifactVersion(1000), 1, false, "P")
                },0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
                new Tea2PlusSecondaryBootLoaderComponent("SBL1", new List<Tea2PlusSecondaryBootLoaderComponentItem>()
                {
                    new Tea2PlusSecondaryBootLoaderComponentItem(conditions1, new PartNumberArtifactVersion(2000), 1, false, "P")
                },0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions2 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IEnumerable<ParameterGroup> parameterGroups = new List<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var sut = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes, conditions2, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            foreach (var component in sut.Components)
            {
                component.SetParent(sut);
            }

            var result = sut.MatchedSlots(product.Object, new List<BaseSlot>(), false);
            Assert.AreEqual(0, result.Count());

            product.VerifyAll();
        }

        [TestMethod]
        public void MatchedSlots_TwoMatches()
        {
            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();
            compatibleHardwareFilter.Setup(chf => chf.NodeTemplateIssueIsWithdrawn(It.IsAny<NodeTemplateIssue>()))
                .Returns(false);

            var productSpecification = new Mock<IProductSpecification>();

            var product = new Mock<IProduct>();
            product.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);

            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            IList<BaseCondition> conditions = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions1 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            var components = new List<IComponent>()
            {
                new Tea2PlusPrimaryBootLoaderComponent("PBL1", new List<Tea2PlusPrimaryBootLoaderComponentItem>()
                {
                    new Tea2PlusPrimaryBootLoaderComponentItem(conditions, new PartNumberArtifactVersion(1000), 1, false, "P")
                },0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
                new Tea2PlusSecondaryBootLoaderComponent("SBL1", new List<Tea2PlusSecondaryBootLoaderComponentItem>()
                {
                    new Tea2PlusSecondaryBootLoaderComponentItem(conditions1, new PartNumberArtifactVersion(2000), 1, false, "P")
                },0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions2 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IEnumerable<ParameterGroup> parameterGroups = new List<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var sut = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes, conditions2, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            foreach (var component in sut.Components)
            {
                component.SetParent(sut);
            }

            PartDecorator<BasePart> decoratedPart = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(2000), 1, "", false), 1);
            BaseSource source = new TestSource();
            PartDecorator<BasePart> decoratedPart1 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(1000), 1, "", false), 1);
            BaseSource source1 = new TestSource();
            var result = sut.MatchedSlots(product.Object, new List<BaseSlot>()
            {
                new Tea2PlusPrimaryBootLoaderSlot(new PartNumberArtifactVersion(1000), "PBL1", decoratedPart1, source1, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Never, 0),
                new Tea2PlusSecondaryBootLoaderSlot(new PartNumberArtifactVersion(2000), "SBL1", decoratedPart, source, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Never, 0),
            }, false);
            Assert.AreEqual(2, result.Count());

            product.VerifyAll();
        }

        [TestMethod]
        public void MatchedSlots_OneMatch()
        {
            var compatibleHardwareFilter = new Mock<ICompatibleHardwareFilter>();
            compatibleHardwareFilter.Setup(chf => chf.NodeTemplateIssueIsWithdrawn(It.IsAny<NodeTemplateIssue>()))
                .Returns(false);

            var productSpecification = new Mock<IProductSpecification>();

            var product = new Mock<IProduct>();
            product.Setup(p => p.ProductSpecification).Returns(productSpecification.Object);

            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(), Array.Empty<ParameterGroup>(), true, true, false, false, null, null);
            var requestedNode = new NodeName(1, 1, "1.1");
            var nodeDefinition = requestedNode.ToTea2PlusNodeDefinition();
            IList<BaseCondition> conditions = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IList<BaseCondition> conditions1 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            var components = new List<IComponent>()
            {
                new Tea2PlusPrimaryBootLoaderComponent("PBL1", new List<Tea2PlusPrimaryBootLoaderComponentItem>()
                {
                    new Tea2PlusPrimaryBootLoaderComponentItem(conditions, new PartNumberArtifactVersion(1000), 1, false, "P")
                },0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
                new Tea2PlusSecondaryBootLoaderComponent("SBL1", new List<Tea2PlusSecondaryBootLoaderComponentItem>()
                {
                    new Tea2PlusSecondaryBootLoaderComponentItem(conditions1, new PartNumberArtifactVersion(2000), 1, false, "P")
                },0, 0, 0, false, NotProgrammableInAftermarketScenario.Connected, false, false, null, null),
            };

            var templateType = new SoftwareTemplateType("guid!", "name1", true, true, nodeDefinition, Array.Empty<ComponentTypeCode>());
            IList<Model.NodeTemplate.ParentNode> parentNodes = new List<Model.NodeTemplate.ParentNode>();
            IList<BaseCondition> conditions2 = new List<BaseCondition>() { new AlwaysMatchCondition() };
            IEnumerable<ParameterGroup> parameterGroups = new List<ParameterGroup>();
            var components1 = (IList<IComponent>)components;
            var sut = new NodeTemplateIssue("", 1, 12345678, 1, "", "", templateType, context, 1.ToString(), false, parentNodes, conditions2, parameterGroups, components1, true, true, (string)null, (DateTime?)null, (DateTime?)null, NodeTemplateStatus.ReleasedPrd, (DateTime?)null, (DateTime?)null, (IList<NodePosition>)null);
            foreach (var component in sut.Components)
            {
                component.SetParent(sut);
            }

            PartDecorator<BasePart> decoratedPart = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(3000), 1, "", false), 1);
            BaseSource source = new TestSource();
            PartDecorator<BasePart> decoratedPart1 = new FilledPartDecorator<BasePart>(new SoftwarePart(new PartNumberArtifactVersion(1000), 1, "", false), 1);
            BaseSource source1 = new TestSource();
            var result = sut.MatchedSlots(product.Object, new List<BaseSlot>()
            {
                new Tea2PlusPrimaryBootLoaderSlot(new PartNumberArtifactVersion(1000), "PBL1", decoratedPart1, source1, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Never, 0),
                new Tea2PlusSecondaryBootLoaderSlot(new PartNumberArtifactVersion(3000), "SBL1", decoratedPart, source, 0, 0, 0, false, false, NotProgrammableInAftermarketScenario.Never, 0),
            }, false);
            Assert.AreEqual(1, result.Count());

            product.VerifyAll();
        }

        [TestMethod]
        public void CalculatePerformsCanIdTransformation_NoContext()
        {
            Assert.IsTrue(NodeTemplateIssue.CalculatePerformsCanIdTransformation(true, null, null));
            Assert.IsFalse(NodeTemplateIssue.CalculatePerformsCanIdTransformation(false, null, null));
        }

        [TestMethod]
        public void CalculatePerformsCanIdTransformation_ContextWithNoFlagForVmcu()
        {
            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(),
                new List<ParameterGroup>(), false, true, false, false, new List<TimeSetVariant>(), null);

            Assert.IsTrue(NodeTemplateIssue.CalculatePerformsCanIdTransformation(true, context, null));
            Assert.IsFalse(NodeTemplateIssue.CalculatePerformsCanIdTransformation(false, context, null));
        }

        [TestMethod]
        public void CalculatePerformsCanIdTransformation_ContextWithFlagForVmcu_NoTemplateType()
        {
            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(),
                new List<ParameterGroup>(), false, true, false, false, new List<TimeSetVariant>(), null);

            Assert.IsTrue(NodeTemplateIssue.CalculatePerformsCanIdTransformation(true, context, null));
            Assert.IsFalse(NodeTemplateIssue.CalculatePerformsCanIdTransformation(false, context, null));
        }

        [TestMethod]
        public void CalculatePerformsCanIdTransformation_ContextWithFlagForVmcu_TemplateTypesIsVmcu()
        {
            var context = CreateContext(6, 1);
            var templateType = CreateTemplateType(6, 1);

            Assert.IsTrue(NodeTemplateIssue.CalculatePerformsCanIdTransformation(true, context, templateType));
            Assert.IsTrue(NodeTemplateIssue.CalculatePerformsCanIdTransformation(false, context, templateType));
        }

        [TestMethod]
        public void CalculatePerformsCanIdTransformation_Context_TemplateTypesIsNotVmcu()
        {
            var context = CreateContext(1, 1);
            var templateType = CreateTemplateType(1, 1);

            Assert.IsTrue(NodeTemplateIssue.CalculatePerformsCanIdTransformation(true, context, templateType));
            Assert.IsTrue(NodeTemplateIssue.CalculatePerformsCanIdTransformation(false, context, templateType));
        }

        [TestMethod]
        public void CalculatePerformsCanIdTransformation_Context_TemplateTypesIsAnotherNodeFamily()
        {
            var context = CreateContext(2, 1);
            var templateType = CreateTemplateType(1, 1);

            Assert.IsFalse(NodeTemplateIssue.CalculatePerformsCanIdTransformation(true, context, templateType));
            Assert.IsFalse(NodeTemplateIssue.CalculatePerformsCanIdTransformation(false, context, templateType));
        }

        [TestMethod]
        public void CalculatePerformsCanIdTransformation_Context_TemplateTypesIsAnotherNodeType()
        {
            var context = CreateContext(1, 2);
            var templateType = CreateTemplateType(1, 1);

            Assert.IsFalse(NodeTemplateIssue.CalculatePerformsCanIdTransformation(true, context, templateType));
            Assert.IsFalse(NodeTemplateIssue.CalculatePerformsCanIdTransformation(false, context, templateType));
        }

        [TestMethod]
        public void CalculatePerformsCanIdTransformation_ContextNotSet()
        {
            var context = new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(),
                new List<ParameterGroup>(), false, true, false, false, new List<TimeSetVariant>(), null);

            var templateType = CreateTemplateType(1, 1);

            Assert.IsTrue(NodeTemplateIssue.CalculatePerformsCanIdTransformation(true, context, templateType));
            Assert.IsFalse(NodeTemplateIssue.CalculatePerformsCanIdTransformation(false, context, templateType));
        }

        private static TemplateType CreateTemplateType(short nodeFamily, short nodeType)
        {
            return new SoftwareTemplateType("guid1", "name1", true, true, new Tea2PlusNodeDefinition(nodeFamily, nodeType, $"{nodeFamily}.{nodeType}"), new List<ComponentTypeCode>());
        }

        private static Context CreateContext(short nodeFamily, short nodeType)
        {
            return new Context("1", new ProductClass("24", "24"), "24", new List<BaseCondition>(),
                            new List<ParameterGroup>(), false, true, false, false, new List<TimeSetVariant>(), new Tea2PlusNodeDefinition(nodeFamily, nodeType, $"{nodeFamily}.{nodeType}"));
        }
    }
}
